target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %callresult39 = alloca [16 x i8], align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %callresult86 = alloca [16 x i8], align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v513 = load i64, ptr %slot1, align 8
  %op514 = add i64 %v513, 32
  store i64 %op514, ptr %slot5, align 8
  %mem515 = alloca i8, i64 8, align 8
  %ptr516 = ptrtoint ptr %mem515 to i64
  store i64 %ptr516, ptr %slot6, align 8
  %mem517 = alloca i8, i64 8, align 8
  %ptr518 = ptrtoint ptr %mem517 to i64
  store i64 %ptr518, ptr %slot7, align 8
  %mem519 = alloca i8, i64 8, align 8
  %ptr520 = ptrtoint ptr %mem519 to i64
  store i64 %ptr520, ptr %slot8, align 8
  %mem521 = alloca i8, i64 8, align 8
  %ptr522 = ptrtoint ptr %mem521 to i64
  store i64 %ptr522, ptr %slot9, align 8
  %mem523 = alloca i8, i64 8, align 8
  %ptr524 = ptrtoint ptr %mem523 to i64
  store i64 %ptr524, ptr %slot10, align 8
  %mem525 = alloca i8, i64 8, align 8
  %ptr526 = ptrtoint ptr %mem525 to i64
  store i64 %ptr526, ptr %slot11, align 8
  %mem527 = alloca i8, i64 8, align 8
  %ptr528 = ptrtoint ptr %mem527 to i64
  store i64 %ptr528, ptr %slot12, align 8
  %mem529 = alloca i8, i64 8, align 8
  %ptr530 = ptrtoint ptr %mem529 to i64
  store i64 %ptr530, ptr %slot13, align 8
  %mem531 = alloca i8, i64 208, align 8
  %ptr532 = ptrtoint ptr %mem531 to i64
  store i64 %ptr532, ptr %slot14, align 8
  %mem533 = alloca i8, i64 208, align 8
  %ptr534 = ptrtoint ptr %mem533 to i64
  store i64 %ptr534, ptr %slot15, align 8
  %mem535 = alloca i8, i64 8, align 8
  %ptr536 = ptrtoint ptr %mem535 to i64
  store i64 %ptr536, ptr %slot16, align 8
  %mem537 = alloca i8, i64 8, align 8
  %ptr538 = ptrtoint ptr %mem537 to i64
  store i64 %ptr538, ptr %slot17, align 8
  %mem539 = alloca i8, i64 208, align 8
  %ptr540 = ptrtoint ptr %mem539 to i64
  store i64 %ptr540, ptr %slot18, align 8
  %mem541 = alloca i8, i64 8, align 8
  %ptr542 = ptrtoint ptr %mem541 to i64
  store i64 %ptr542, ptr %slot19, align 8
  %mem543 = alloca i8, i64 8, align 8
  %ptr544 = ptrtoint ptr %mem543 to i64
  store i64 %ptr544, ptr %slot20, align 8
  %mem545 = alloca i8, i64 8, align 8
  %ptr546 = ptrtoint ptr %mem545 to i64
  store i64 %ptr546, ptr %slot21, align 8
  %mem547 = alloca i8, i64 8, align 8
  %ptr548 = ptrtoint ptr %mem547 to i64
  store i64 %ptr548, ptr %slot22, align 8
  %mem549 = alloca i8, i64 8, align 8
  %ptr550 = ptrtoint ptr %mem549 to i64
  store i64 %ptr550, ptr %slot23, align 8
  %mem551 = alloca i8, i64 8, align 8
  %ptr552 = ptrtoint ptr %mem551 to i64
  store i64 %ptr552, ptr %slot24, align 8
  %mem553 = alloca i8, i64 8, align 8
  %ptr554 = ptrtoint ptr %mem553 to i64
  store i64 %ptr554, ptr %slot25, align 8
  %mem555 = alloca i8, i64 8, align 8
  %ptr556 = ptrtoint ptr %mem555 to i64
  store i64 %ptr556, ptr %slot26, align 8
  %mem557 = alloca i8, i64 8, align 8
  %ptr558 = ptrtoint ptr %mem557 to i64
  store i64 %ptr558, ptr %slot27, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem559 = alloca i8, i64 8, align 8
  %ptr560 = ptrtoint ptr %mem559 to i64
  store i64 %ptr560, ptr %slot28, align 8
  %v561 = load i64, ptr %slot1, align 8
  %op562 = add i64 %v561, 64
  store i64 %op562, ptr %slot29, align 8
  %v563 = load i64, ptr %slot29, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !4, !noalias !3
  store i64 %ld565, ptr %slot30, align 8
  %stack566 = call ptr @llvm.stacksave()
  %stackaddr567 = ptrtoint ptr %stack566 to i64
  %v568 = load i64, ptr %slot30, align 8
  %cmp569 = icmp ult i64 %stackaddr567, %v568
  %cv570 = zext i1 %cmp569 to i64
  store i64 %cv570, ptr %slot31, align 8
  %v571 = load i64, ptr %slot31, align 8
  %cond572 = icmp ne i64 %v571, 0
  br i1 %cond572, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v573 = load i64, ptr %slot1, align 8
  %p574 = inttoptr i64 %v573 to ptr
  call void @myl_qbe_fail_frame(ptr %p574) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v575 = load i64, ptr %slot22, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 0, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot2, align 8
  %v578 = load i64, ptr %slot19, align 8
  %p579 = inttoptr i64 %v578 to ptr
  store i64 %v577, ptr %p579, align 8, !alias.scope !3, !noalias !4
  %v580 = load i64, ptr %slot3, align 8
  %v581 = load i64, ptr %slot20, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot4, align 8
  %v584 = load i64, ptr %slot21, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i64 %v583, ptr %p585, align 8, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot1, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %call588 = call ptr @myl_qbe_heap(ptr %p587) nomerge, !dbg !112
  %calladdr589 = ptrtoint ptr %call588 to i64
  store i64 %calladdr589, ptr %slot32, align 8
  %v590 = load i64, ptr %slot1, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %call592 = call i64 @myl_qbe_region_mark(ptr %p591) nomerge, !dbg !112
  store i64 %call592, ptr %slot33, align 8
  %v593 = load i64, ptr %slot6, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 0, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot7, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i32 0, ptr %p596, align 4, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot8, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 0, ptr %p598, align 4, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot9, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i32 0, ptr %p600, align 4, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot10, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i32 0, ptr %p602, align 4, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot11, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i32 0, ptr %p604, align 4, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot12, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i32 0, ptr %p606, align 4, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot13, align 8
  %p608 = inttoptr i64 %v607 to ptr
  store i32 0, ptr %p608, align 4, !alias.scope !3, !noalias !4
  %v609 = load i64, ptr %slot7, align 8
  %p610 = inttoptr i64 %v609 to ptr
  store i32 2, ptr %p610, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v611 = load i64, ptr %slot19, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i64, ptr %p612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld613, ptr %slot34, align 8
  %v614 = load i64, ptr %slot34, align 8
  %v615 = load i64, ptr %slot25, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i64 %v614, ptr %p616, align 8, !alias.scope !3, !noalias !4
  %v617 = load i64, ptr %slot20, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %ld619 = load i64, ptr %p618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld619, ptr %slot35, align 8
  %v620 = load i64, ptr %slot35, align 8
  %v621 = load i64, ptr %slot26, align 8
  %p622 = inttoptr i64 %v621 to ptr
  store i64 %v620, ptr %p622, align 8, !alias.scope !3, !noalias !4
  %v623 = load i64, ptr %slot25, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i64, ptr %p624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld625, ptr %slot36, align 8
  %v626 = load i64, ptr %slot26, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %ld628 = load i64, ptr %p627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld628, ptr %slot37, align 8
  %v629 = load i64, ptr %slot1, align 8
  %v630 = load i64, ptr %slot36, align 8
  %v631 = load i64, ptr %slot37, align 8
  %call632 = call { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %v629, i64 %v630, i64 %v631) nomerge, !dbg !114
  store { i64, i64 } %call632, ptr %callresult39, align 8
  %addr633 = ptrtoint ptr %callresult39 to i64
  store i64 %addr633, ptr %slot38, align 8
  %v634 = load i64, ptr %slot38, align 8
  %v635 = load i64, ptr %slot25, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i64 %v634, ptr %p636, align 8, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot25, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i64, ptr %p638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld639, ptr %slot40, align 8
  %v640 = load i64, ptr %slot18, align 8
  store i64 %v640, ptr %slot41, align 8
  %v641 = load i64, ptr %slot32, align 8
  %v642 = load i64, ptr %slot41, align 8
  %v643 = load i64, ptr %slot40, align 8
  %call644 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_loan(i64 %v641, i64 %v642, i64 %v643) nomerge, !dbg !114
  store i32 %call644, ptr %slot42, align 8
  %v645 = load i32, ptr %slot42, align 8
  %cv646 = zext i32 %v645 to i64
  %cond647 = icmp ne i64 %cv646, 0
  br i1 %cond647, label %bb_rcsuccess17, label %bb_rcfailure17
bb_rcfailure17:
  %v648 = load i64, ptr %slot32, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %call650 = call i32 @myl_rc_take_failure(ptr %p649) nomerge, !dbg !114
  store i32 %call650, ptr %slot43, align 8
  %v651 = load i64, ptr %slot1, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %v653 = load i32, ptr %slot43, align 8
  %call654 = call i32 @myl_qbe_rc_status(ptr %p652, i32 %v653) nomerge, !dbg !114
  store i32 %call654, ptr %slot44, align 8
  br label %bb_failure
bb_rcsuccess17:
  %v655 = load i64, ptr %slot13, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i32 2, ptr %p656, align 4, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot13, align 8
  %p658 = inttoptr i64 %v657 to ptr
  store i32 16, ptr %p658, align 4, !alias.scope !3, !noalias !4
  %v659 = load i64, ptr %slot12, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i32 1, ptr %p660, align 4, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot8, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i32, ptr %p662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld663, ptr %slot45, align 8
  %v664 = load i32, ptr %slot45, align 8
  %cv665 = zext i32 %v664 to i64
  %cond666 = icmp ne i64 %cv665, 0
  br i1 %cond666, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v667 = load i64, ptr %slot8, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot14, align 8
  store i64 %v669, ptr %slot46, align 8
  %v670 = load i64, ptr %slot9, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i32, ptr %p671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld672, ptr %slot47, align 8
  %v673 = load i32, ptr %slot47, align 8
  %op674 = and i32 %v673, 28
  store i32 %op674, ptr %slot48, align 8
  %v675 = load i32, ptr %slot48, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v678 = load i64, ptr %slot32, align 8
  store i64 %v678, ptr %slot49, align 8
  %v679 = load i64, ptr %slot49, align 8
  %v680 = load i64, ptr %slot46, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v679, i64 %v680) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v681 = load i64, ptr %slot32, align 8
  store i64 %v681, ptr %slot50, align 8
  %v682 = load i64, ptr %slot50, align 8
  %v683 = load i64, ptr %slot46, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v682, i64 %v683) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v684 = load i64, ptr %slot14, align 8
  store i64 %v684, ptr %slot51, align 8
  %v685 = load i64, ptr %slot18, align 8
  store i64 %v685, ptr %slot52, align 8
  %v686 = load i64, ptr %slot52, align 8
  %v687 = load i64, ptr %slot51, align 8
  %p688 = inttoptr i64 %v686 to ptr
  %p689 = inttoptr i64 %v687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p689, ptr %p688, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v690 = load i64, ptr %slot9, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i32 2, ptr %p691, align 4, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot13, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %ld694 = load i32, ptr %p693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld694, ptr %slot53, align 8
  %v695 = load i32, ptr %slot53, align 8
  %v696 = load i64, ptr %slot9, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i32 %v695, ptr %p697, align 4, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot12, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i32 0, ptr %p699, align 4, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot8, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i32 1, ptr %p701, align 4, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot51, align 8
  %v703 = load i64, ptr %slot25, align 8
  %p704 = inttoptr i64 %v703 to ptr
  store i64 %v702, ptr %p704, align 8, !alias.scope !3, !noalias !4
  %v705 = load i64, ptr %slot25, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i64, ptr %p706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld707, ptr %slot54, align 8
  %v708 = load i64, ptr %slot54, align 8
  %op709 = add i64 %v708, 0
  store i64 %op709, ptr %slot55, align 8
  %v710 = load i64, ptr %slot55, align 8
  %p711 = inttoptr i64 %v710 to ptr
  %ld712 = load i64, ptr %p711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld712, ptr %slot56, align 8
  %v713 = load i64, ptr %slot56, align 8
  %v714 = load i64, ptr %slot25, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i64 %v713, ptr %p715, align 8, !alias.scope !3, !noalias !4
  %v716 = load i64, ptr %slot25, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot57, align 8
  %v719 = load i64, ptr %slot57, align 8
  %v720 = load i64, ptr %slot16, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i64 %v719, ptr %p721, align 8, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot16, align 8
  store i64 %v722, ptr %slot58, align 8
  %v723 = load i64, ptr %slot18, align 8
  store i64 %v723, ptr %slot59, align 8
  %v724 = load i64, ptr %slot58, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i64, ptr %p725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld726, ptr %slot60, align 8
  %v727 = load i64, ptr %slot60, align 8
  %cmp728 = icmp ne i64 %v727, 0
  %cv729 = zext i1 %cmp728 to i32
  store i32 %cv729, ptr %slot61, align 8
  %v730 = load i32, ptr %slot61, align 8
  %cv731 = zext i32 %v730 to i64
  %cond732 = icmp ne i64 %cv731, 0
  br i1 %cond732, label %bb_rcgnn47, label %bb_rcgstore47
bb_rcgnn47:
  %v733 = load i64, ptr %slot60, align 8
  %op734 = sub i64 %v733, 16
  store i64 %op734, ptr %slot62, align 8
  %v735 = load i64, ptr %slot60, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %rgep737 = getelementptr i8, ptr %p736, i64 -16
  %ld738 = load i64, ptr %rgep737, align 8, !alias.scope !9, !noalias !10
  store i64 %ld738, ptr %slot63, align 8
  %v739 = load i64, ptr %slot63, align 8
  %op740 = and i64 %v739, 4611686018427387906
  store i64 %op740, ptr %slot64, align 8
  %v741 = load i64, ptr %slot64, align 8
  %cmp742 = icmp ne i64 %v741, 0
  %cv743 = zext i1 %cmp742 to i32
  store i32 %cv743, ptr %slot65, align 8
  %v744 = load i32, ptr %slot65, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcgstore47, label %bb_rcginc47
bb_rcginc47:
  %v747 = load i64, ptr %slot60, align 8
  %op748 = sub i64 %v747, 24
  store i64 %op748, ptr %slot66, align 8
  %v749 = load i64, ptr %slot60, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %rgep751 = getelementptr i8, ptr %p750, i64 -24
  %ld752 = load i64, ptr %rgep751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld752, ptr %slot67, align 8
  %v753 = load i64, ptr %slot67, align 8
  %op754 = add i64 %v753, 1
  store i64 %op754, ptr %slot68, align 8
  %v755 = load i64, ptr %slot68, align 8
  %cmp756 = icmp eq i64 %v755, 0
  %cv757 = zext i1 %cmp756 to i32
  store i32 %cv757, ptr %slot69, align 8
  %v758 = load i32, ptr %slot69, align 8
  %cv759 = zext i32 %v758 to i64
  %cond760 = icmp ne i64 %cv759, 0
  br i1 %cond760, label %bb_rcglimit47, label %bb_rcgcapacity47
bb_rcglimit47:
  %v761 = load i64, ptr %slot1, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %call763 = call i32 @myl_qbe_rc_status(ptr %p762, i32 2) nomerge, !dbg !116
  store i32 %call763, ptr %slot70, align 8
  br label %bb_failure
bb_rcgcapacity47:
  %v764 = load i64, ptr %slot68, align 8
  %v765 = load i64, ptr %slot60, align 8
  %p766 = inttoptr i64 %v765 to ptr
  %rgep767 = getelementptr i8, ptr %p766, i64 -24
  store i64 %v764, ptr %rgep767, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore47
bb_rcgstore47:
  %v768 = load i64, ptr %slot60, align 8
  %v769 = load i64, ptr %slot59, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i64 %v768, ptr %p770, align 8, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot13, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i32 2, ptr %p772, align 4, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot13, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 16, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot12, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 1, ptr %p776, align 4, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot8, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot71, align 8
  %v780 = load i32, ptr %slot71, align 8
  %cv781 = zext i32 %v780 to i64
  %cond782 = icmp ne i64 %cv781, 0
  br i1 %cond782, label %bb_rcslotdrop63, label %bb_rcslotdone63
bb_rcslotdrop63:
  %v783 = load i64, ptr %slot8, align 8
  %p784 = inttoptr i64 %v783 to ptr
  store i32 0, ptr %p784, align 4, !alias.scope !3, !noalias !4
  %v785 = load i64, ptr %slot14, align 8
  store i64 %v785, ptr %slot72, align 8
  %v786 = load i64, ptr %slot9, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i32, ptr %p787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld788, ptr %slot73, align 8
  %v789 = load i32, ptr %slot73, align 8
  %op790 = and i32 %v789, 28
  store i32 %op790, ptr %slot74, align 8
  %v791 = load i32, ptr %slot74, align 8
  %cv792 = zext i32 %v791 to i64
  %cond793 = icmp ne i64 %cv792, 0
  br i1 %cond793, label %bb_rcslotrole63, label %bb_rcslotowner63
bb_rcslotrole63:
  %v794 = load i64, ptr %slot32, align 8
  store i64 %v794, ptr %slot75, align 8
  %v795 = load i64, ptr %slot75, align 8
  %v796 = load i64, ptr %slot72, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v795, i64 %v796) nomerge, !dbg !116
  br label %bb_rcslotdone63
bb_rcslotowner63:
  %v797 = load i64, ptr %slot32, align 8
  store i64 %v797, ptr %slot76, align 8
  %v798 = load i64, ptr %slot76, align 8
  %v799 = load i64, ptr %slot72, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v798, i64 %v799) nomerge, !dbg !116
  br label %bb_rcslotdone63
bb_rcslotdone63:
  %v800 = load i64, ptr %slot14, align 8
  store i64 %v800, ptr %slot77, align 8
  %v801 = load i64, ptr %slot18, align 8
  store i64 %v801, ptr %slot78, align 8
  %v802 = load i64, ptr %slot78, align 8
  %v803 = load i64, ptr %slot77, align 8
  %p804 = inttoptr i64 %v802 to ptr
  %p805 = inttoptr i64 %v803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p805, ptr %p804, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot9, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 2, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot13, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i32, ptr %p809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld810, ptr %slot79, align 8
  %v811 = load i32, ptr %slot79, align 8
  %v812 = load i64, ptr %slot9, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i32 %v811, ptr %p813, align 4, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot12, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i32 0, ptr %p815, align 4, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot8, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i32 1, ptr %p817, align 4, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot77, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot80, align 8
  %v821 = load i64, ptr %slot80, align 8
  %v822 = load i64, ptr %slot25, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 %v821, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot19, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %ld826 = load i64, ptr %p825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld826, ptr %slot81, align 8
  %v827 = load i64, ptr %slot81, align 8
  %v828 = load i64, ptr %slot26, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot21, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld832, ptr %slot82, align 8
  %v833 = load i64, ptr %slot82, align 8
  %v834 = load i64, ptr %slot27, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 %v833, ptr %p835, align 8, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot26, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot83, align 8
  %v839 = load i64, ptr %slot27, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot84, align 8
  %v842 = load i64, ptr %slot1, align 8
  %v843 = load i64, ptr %slot83, align 8
  %v844 = load i64, ptr %slot84, align 8
  %call845 = call { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %v842, i64 %v843, i64 %v844) nomerge, !dbg !118
  store { i64, i64 } %call845, ptr %callresult86, align 8
  %addr846 = ptrtoint ptr %callresult86 to i64
  store i64 %addr846, ptr %slot85, align 8
  %v847 = load i64, ptr %slot85, align 8
  %v848 = load i64, ptr %slot26, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i64 %v847, ptr %p849, align 8, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot26, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %ld852 = load i64, ptr %p851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld852, ptr %slot87, align 8
  %v853 = load i64, ptr %slot18, align 8
  store i64 %v853, ptr %slot88, align 8
  %v854 = load i64, ptr %slot32, align 8
  %v855 = load i64, ptr %slot88, align 8
  %v856 = load i64, ptr %slot87, align 8
  %call857 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_loan(i64 %v854, i64 %v855, i64 %v856) nomerge, !dbg !118
  store i32 %call857, ptr %slot89, align 8
  %v858 = load i32, ptr %slot89, align 8
  %cv859 = zext i32 %v858 to i64
  %cond860 = icmp ne i64 %cv859, 0
  br i1 %cond860, label %bb_rcsuccess87, label %bb_rcfailure87
bb_rcfailure87:
  %v861 = load i64, ptr %slot32, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %call863 = call i32 @myl_rc_take_failure(ptr %p862) nomerge, !dbg !118
  store i32 %call863, ptr %slot90, align 8
  %v864 = load i64, ptr %slot1, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %v866 = load i32, ptr %slot90, align 8
  %call867 = call i32 @myl_qbe_rc_status(ptr %p865, i32 %v866) nomerge, !dbg !118
  store i32 %call867, ptr %slot91, align 8
  br label %bb_failure
bb_rcsuccess87:
  %v868 = load i64, ptr %slot13, align 8
  %p869 = inttoptr i64 %v868 to ptr
  store i32 2, ptr %p869, align 4, !alias.scope !3, !noalias !4
  %v870 = load i64, ptr %slot13, align 8
  %p871 = inttoptr i64 %v870 to ptr
  store i32 16, ptr %p871, align 4, !alias.scope !3, !noalias !4
  %v872 = load i64, ptr %slot12, align 8
  %p873 = inttoptr i64 %v872 to ptr
  store i32 1, ptr %p873, align 4, !alias.scope !3, !noalias !4
  %v874 = load i64, ptr %slot10, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %ld876 = load i32, ptr %p875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld876, ptr %slot92, align 8
  %v877 = load i32, ptr %slot92, align 8
  %cv878 = zext i32 %v877 to i64
  %cond879 = icmp ne i64 %cv878, 0
  br i1 %cond879, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v880 = load i64, ptr %slot10, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i32 0, ptr %p881, align 4, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot15, align 8
  store i64 %v882, ptr %slot93, align 8
  %v883 = load i64, ptr %slot11, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %ld885 = load i32, ptr %p884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld885, ptr %slot94, align 8
  %v886 = load i32, ptr %slot94, align 8
  %op887 = and i32 %v886, 28
  store i32 %op887, ptr %slot95, align 8
  %v888 = load i32, ptr %slot95, align 8
  %cv889 = zext i32 %v888 to i64
  %cond890 = icmp ne i64 %cv889, 0
  br i1 %cond890, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v891 = load i64, ptr %slot32, align 8
  store i64 %v891, ptr %slot96, align 8
  %v892 = load i64, ptr %slot96, align 8
  %v893 = load i64, ptr %slot93, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v892, i64 %v893) nomerge, !dbg !118
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v894 = load i64, ptr %slot32, align 8
  store i64 %v894, ptr %slot97, align 8
  %v895 = load i64, ptr %slot97, align 8
  %v896 = load i64, ptr %slot93, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v895, i64 %v896) nomerge, !dbg !118
  br label %bb_rcslotdone95
bb_rcslotdone95:
  %v897 = load i64, ptr %slot15, align 8
  store i64 %v897, ptr %slot98, align 8
  %v898 = load i64, ptr %slot18, align 8
  store i64 %v898, ptr %slot99, align 8
  %v899 = load i64, ptr %slot99, align 8
  %v900 = load i64, ptr %slot98, align 8
  %p901 = inttoptr i64 %v899 to ptr
  %p902 = inttoptr i64 %v900 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p902, ptr %p901, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v903 = load i64, ptr %slot11, align 8
  %p904 = inttoptr i64 %v903 to ptr
  store i32 2, ptr %p904, align 4, !alias.scope !3, !noalias !4
  %v905 = load i64, ptr %slot13, align 8
  %p906 = inttoptr i64 %v905 to ptr
  %ld907 = load i32, ptr %p906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld907, ptr %slot100, align 8
  %v908 = load i32, ptr %slot100, align 8
  %v909 = load i64, ptr %slot11, align 8
  %p910 = inttoptr i64 %v909 to ptr
  store i32 %v908, ptr %p910, align 4, !alias.scope !3, !noalias !4
  %v911 = load i64, ptr %slot12, align 8
  %p912 = inttoptr i64 %v911 to ptr
  store i32 0, ptr %p912, align 4, !alias.scope !3, !noalias !4
  %v913 = load i64, ptr %slot10, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i32 1, ptr %p914, align 4, !alias.scope !3, !noalias !4
  %v915 = load i64, ptr %slot98, align 8
  %v916 = load i64, ptr %slot26, align 8
  %p917 = inttoptr i64 %v916 to ptr
  store i64 %v915, ptr %p917, align 8, !alias.scope !3, !noalias !4
  %v918 = load i64, ptr %slot26, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %ld920 = load i64, ptr %p919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld920, ptr %slot101, align 8
  %v921 = load i64, ptr %slot101, align 8
  %op922 = add i64 %v921, 0
  store i64 %op922, ptr %slot102, align 8
  %v923 = load i64, ptr %slot102, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i64, ptr %p924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld925, ptr %slot103, align 8
  %v926 = load i64, ptr %slot103, align 8
  %v927 = load i64, ptr %slot26, align 8
  %p928 = inttoptr i64 %v927 to ptr
  store i64 %v926, ptr %p928, align 8, !alias.scope !3, !noalias !4
  %v929 = load i64, ptr %slot26, align 8
  %p930 = inttoptr i64 %v929 to ptr
  %ld931 = load i64, ptr %p930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld931, ptr %slot104, align 8
  %v932 = load i64, ptr %slot104, align 8
  %v933 = load i64, ptr %slot17, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 %v932, ptr %p934, align 8, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot17, align 8
  store i64 %v935, ptr %slot105, align 8
  %v936 = load i64, ptr %slot18, align 8
  store i64 %v936, ptr %slot106, align 8
  %v937 = load i64, ptr %slot105, align 8
  %p938 = inttoptr i64 %v937 to ptr
  %ld939 = load i64, ptr %p938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld939, ptr %slot107, align 8
  %v940 = load i64, ptr %slot107, align 8
  %cmp941 = icmp ne i64 %v940, 0
  %cv942 = zext i1 %cmp941 to i32
  store i32 %cv942, ptr %slot108, align 8
  %v943 = load i32, ptr %slot108, align 8
  %cv944 = zext i32 %v943 to i64
  %cond945 = icmp ne i64 %cv944, 0
  br i1 %cond945, label %bb_rcgnn117, label %bb_rcgstore117
bb_rcgnn117:
  %v946 = load i64, ptr %slot107, align 8
  %op947 = sub i64 %v946, 16
  store i64 %op947, ptr %slot109, align 8
  %v948 = load i64, ptr %slot107, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %rgep950 = getelementptr i8, ptr %p949, i64 -16
  %ld951 = load i64, ptr %rgep950, align 8, !alias.scope !9, !noalias !10
  store i64 %ld951, ptr %slot110, align 8
  %v952 = load i64, ptr %slot110, align 8
  %op953 = and i64 %v952, 4611686018427387906
  store i64 %op953, ptr %slot111, align 8
  %v954 = load i64, ptr %slot111, align 8
  %cmp955 = icmp ne i64 %v954, 0
  %cv956 = zext i1 %cmp955 to i32
  store i32 %cv956, ptr %slot112, align 8
  %v957 = load i32, ptr %slot112, align 8
  %cv958 = zext i32 %v957 to i64
  %cond959 = icmp ne i64 %cv958, 0
  br i1 %cond959, label %bb_rcgstore117, label %bb_rcginc117
bb_rcginc117:
  %v960 = load i64, ptr %slot107, align 8
  %op961 = sub i64 %v960, 24
  store i64 %op961, ptr %slot113, align 8
  %v962 = load i64, ptr %slot107, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %rgep964 = getelementptr i8, ptr %p963, i64 -24
  %ld965 = load i64, ptr %rgep964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld965, ptr %slot114, align 8
  %v966 = load i64, ptr %slot114, align 8
  %op967 = add i64 %v966, 1
  store i64 %op967, ptr %slot115, align 8
  %v968 = load i64, ptr %slot115, align 8
  %cmp969 = icmp eq i64 %v968, 0
  %cv970 = zext i1 %cmp969 to i32
  store i32 %cv970, ptr %slot116, align 8
  %v971 = load i32, ptr %slot116, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcglimit117, label %bb_rcgcapacity117
bb_rcglimit117:
  %v974 = load i64, ptr %slot1, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %call976 = call i32 @myl_qbe_rc_status(ptr %p975, i32 2) nomerge, !dbg !120
  store i32 %call976, ptr %slot117, align 8
  br label %bb_failure
bb_rcgcapacity117:
  %v977 = load i64, ptr %slot115, align 8
  %v978 = load i64, ptr %slot107, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %rgep980 = getelementptr i8, ptr %p979, i64 -24
  store i64 %v977, ptr %rgep980, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore117
bb_rcgstore117:
  %v981 = load i64, ptr %slot107, align 8
  %v982 = load i64, ptr %slot106, align 8
  %p983 = inttoptr i64 %v982 to ptr
  store i64 %v981, ptr %p983, align 8, !alias.scope !3, !noalias !4
  %v984 = load i64, ptr %slot13, align 8
  %p985 = inttoptr i64 %v984 to ptr
  store i32 2, ptr %p985, align 4, !alias.scope !3, !noalias !4
  %v986 = load i64, ptr %slot13, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i32 16, ptr %p987, align 4, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot12, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i32 1, ptr %p989, align 4, !alias.scope !3, !noalias !4
  %v990 = load i64, ptr %slot10, align 8
  %p991 = inttoptr i64 %v990 to ptr
  %ld992 = load i32, ptr %p991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld992, ptr %slot118, align 8
  %v993 = load i32, ptr %slot118, align 8
  %cv994 = zext i32 %v993 to i64
  %cond995 = icmp ne i64 %cv994, 0
  br i1 %cond995, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v996 = load i64, ptr %slot10, align 8
  %p997 = inttoptr i64 %v996 to ptr
  store i32 0, ptr %p997, align 4, !alias.scope !3, !noalias !4
  %v998 = load i64, ptr %slot15, align 8
  store i64 %v998, ptr %slot119, align 8
  %v999 = load i64, ptr %slot11, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  %ld1001 = load i32, ptr %p1000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1001, ptr %slot120, align 8
  %v1002 = load i32, ptr %slot120, align 8
  %op1003 = and i32 %v1002, 28
  store i32 %op1003, ptr %slot121, align 8
  %v1004 = load i32, ptr %slot121, align 8
  %cv1005 = zext i32 %v1004 to i64
  %cond1006 = icmp ne i64 %cv1005, 0
  br i1 %cond1006, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1007 = load i64, ptr %slot32, align 8
  store i64 %v1007, ptr %slot122, align 8
  %v1008 = load i64, ptr %slot122, align 8
  %v1009 = load i64, ptr %slot119, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v1008, i64 %v1009) nomerge, !dbg !120
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1010 = load i64, ptr %slot32, align 8
  store i64 %v1010, ptr %slot123, align 8
  %v1011 = load i64, ptr %slot123, align 8
  %v1012 = load i64, ptr %slot119, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v1011, i64 %v1012) nomerge, !dbg !120
  br label %bb_rcslotdone133
bb_rcslotdone133:
  %v1013 = load i64, ptr %slot15, align 8
  store i64 %v1013, ptr %slot124, align 8
  %v1014 = load i64, ptr %slot18, align 8
  store i64 %v1014, ptr %slot125, align 8
  %v1015 = load i64, ptr %slot125, align 8
  %v1016 = load i64, ptr %slot124, align 8
  %p1017 = inttoptr i64 %v1015 to ptr
  %p1018 = inttoptr i64 %v1016 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1018, ptr %p1017, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1019 = load i64, ptr %slot11, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i32 2, ptr %p1020, align 4, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot13, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i32, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1023, ptr %slot126, align 8
  %v1024 = load i32, ptr %slot126, align 8
  %v1025 = load i64, ptr %slot11, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i32 %v1024, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot12, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i32 0, ptr %p1028, align 4, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot10, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i32 1, ptr %p1030, align 4, !alias.scope !3, !noalias !4
  %v1031 = load i64, ptr %slot124, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  %ld1033 = load i64, ptr %p1032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1033, ptr %slot127, align 8
  %v1034 = load i64, ptr %slot127, align 8
  %v1035 = load i64, ptr %slot26, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  store i64 %v1034, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  %v1037 = load i64, ptr %slot25, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %ld1039 = load i64, ptr %p1038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1039, ptr %slot128, align 8
  %v1040 = load i64, ptr %slot26, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot129, align 8
  %v1043 = load i64, ptr %slot25, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  %ld1045 = load i64, ptr %p1044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1045, ptr %slot130, align 8
  %v1046 = load i64, ptr %slot26, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i64, ptr %p1047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1048, ptr %slot131, align 8
  %v1049 = load i64, ptr %slot32, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %v1051 = load i64, ptr %slot130, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %v1053 = load i64, ptr %slot131, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  %call1055 = call ptr @myl_native_bytes_concat(ptr %p1050, ptr %p1052, ptr %p1054) nomerge, !dbg !122
  %calladdr1056 = ptrtoint ptr %call1055 to i64
  store i64 %calladdr1056, ptr %slot132, align 8
  %v1057 = load i64, ptr %slot132, align 8
  %cond1058 = icmp ne i64 %v1057, 0
  br i1 %cond1058, label %bb_success155, label %bb_failed155
bb_failed155:
  %v1059 = load i64, ptr %slot1, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1060) nomerge, !dbg !122
  unreachable
bb_success155:
  %v1061 = load i64, ptr %slot132, align 8
  %v1062 = load i64, ptr %slot25, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i64 %v1061, ptr %p1063, align 8, !alias.scope !3, !noalias !4
  %v1064 = load i64, ptr %slot25, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i64, ptr %p1065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1066, ptr %slot133, align 8
  %v1067 = load i64, ptr %slot133, align 8
  %v1068 = load i64, ptr %slot16, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i64 %v1067, ptr %p1069, align 8, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot16, align 8
  store i64 %v1070, ptr %slot134, align 8
  %v1071 = load i64, ptr %slot18, align 8
  store i64 %v1071, ptr %slot135, align 8
  %v1072 = load i64, ptr %slot134, align 8
  %v1073 = load i64, ptr %slot135, align 8
  %p1074 = inttoptr i64 %v1072 to ptr
  %p1075 = inttoptr i64 %v1073 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1075, ptr %p1074, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1076 = load i64, ptr %slot13, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  store i32 2, ptr %p1077, align 4, !alias.scope !3, !noalias !4
  %v1078 = load i64, ptr %slot12, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  store i32 1, ptr %p1079, align 4, !alias.scope !3, !noalias !4
  %v1080 = load i64, ptr %slot8, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  %ld1082 = load i32, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1082, ptr %slot136, align 8
  %v1083 = load i32, ptr %slot136, align 8
  %cv1084 = zext i32 %v1083 to i64
  %cond1085 = icmp ne i64 %cv1084, 0
  br i1 %cond1085, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v1086 = load i64, ptr %slot8, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i32 0, ptr %p1087, align 4, !alias.scope !3, !noalias !4
  %v1088 = load i64, ptr %slot14, align 8
  store i64 %v1088, ptr %slot137, align 8
  %v1089 = load i64, ptr %slot9, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %ld1091 = load i32, ptr %p1090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1091, ptr %slot138, align 8
  %v1092 = load i32, ptr %slot138, align 8
  %op1093 = and i32 %v1092, 28
  store i32 %op1093, ptr %slot139, align 8
  %v1094 = load i32, ptr %slot139, align 8
  %cv1095 = zext i32 %v1094 to i64
  %cond1096 = icmp ne i64 %cv1095, 0
  br i1 %cond1096, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v1097 = load i64, ptr %slot32, align 8
  store i64 %v1097, ptr %slot140, align 8
  %v1098 = load i64, ptr %slot137, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %ld1100 = load i64, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1100, ptr %slot141, align 8
  %v1101 = load i64, ptr %slot141, align 8
  %cmp1102 = icmp ne i64 %v1101, 0
  %cv1103 = zext i1 %cmp1102 to i32
  store i32 %cv1103, ptr %slot142, align 8
  %v1104 = load i32, ptr %slot142, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v1107 = load i64, ptr %slot141, align 8
  %op1108 = sub i64 %v1107, 16
  store i64 %op1108, ptr %slot143, align 8
  %v1109 = load i64, ptr %slot141, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  %rgep1111 = getelementptr i8, ptr %p1110, i64 -16
  %ld1112 = load i64, ptr %rgep1111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1112, ptr %slot144, align 8
  %v1113 = load i64, ptr %slot144, align 8
  %op1114 = and i64 %v1113, 4611686018427387906
  store i64 %op1114, ptr %slot145, align 8
  %v1115 = load i64, ptr %slot145, align 8
  %cmp1116 = icmp ne i64 %v1115, 0
  %cv1117 = zext i1 %cmp1116 to i32
  store i32 %cv1117, ptr %slot146, align 8
  %v1118 = load i32, ptr %slot146, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v1121 = load i64, ptr %slot141, align 8
  %op1122 = sub i64 %v1121, 24
  store i64 %op1122, ptr %slot147, align 8
  %v1123 = load i64, ptr %slot141, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %rgep1125 = getelementptr i8, ptr %p1124, i64 -24
  %ld1126 = load i64, ptr %rgep1125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1126, ptr %slot148, align 8
  %v1127 = load i64, ptr %slot148, align 8
  %op1128 = sub i64 %v1127, 1
  store i64 %op1128, ptr %slot149, align 8
  %v1129 = load i64, ptr %slot149, align 8
  %cmp1130 = icmp eq i64 %v1129, 0
  %cv1131 = zext i1 %cmp1130 to i32
  store i32 %cv1131, ptr %slot150, align 8
  %v1132 = load i32, ptr %slot150, align 8
  %cv1133 = zext i32 %v1132 to i64
  %cond1134 = icmp ne i64 %cv1133, 0
  br i1 %cond1134, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v1135 = load i64, ptr %slot141, align 8
  %op1136 = sub i64 %v1135, 32
  store i64 %op1136, ptr %slot151, align 8
  %v1137 = load i64, ptr %slot141, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %rgep1139 = getelementptr i8, ptr %p1138, i64 -32
  %ld1140 = load i64, ptr %rgep1139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1140, ptr %slot152, align 8
  %v1141 = load i64, ptr %slot152, align 8
  %cmp1142 = icmp ne i64 %v1141, 0
  %cv1143 = zext i1 %cmp1142 to i32
  store i32 %cv1143, ptr %slot153, align 8
  %v1144 = load i32, ptr %slot153, align 8
  %cv1145 = zext i32 %v1144 to i64
  %cond1146 = icmp ne i64 %cv1145, 0
  br i1 %cond1146, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v1147 = load i64, ptr %slot140, align 8
  %v1148 = load i64, ptr %slot137, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1147, i64 %v1148) nomerge, !dbg !122
  br label %bb_rcgdone179
bb_rcgdec179:
  %v1149 = load i64, ptr %slot149, align 8
  %v1150 = load i64, ptr %slot141, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %rgep1152 = getelementptr i8, ptr %p1151, i64 -24
  store i64 %v1149, ptr %rgep1152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v1153 = load i64, ptr %slot137, align 8
  %p1154 = inttoptr i64 %v1153 to ptr
  store i64 0, ptr %p1154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v1155 = load i64, ptr %slot32, align 8
  store i64 %v1155, ptr %slot154, align 8
  %v1156 = load i64, ptr %slot137, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %ld1158 = load i64, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1158, ptr %slot155, align 8
  %v1159 = load i64, ptr %slot155, align 8
  %cmp1160 = icmp ne i64 %v1159, 0
  %cv1161 = zext i1 %cmp1160 to i32
  store i32 %cv1161, ptr %slot156, align 8
  %v1162 = load i32, ptr %slot156, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcgnn194, label %bb_rcgdone194
bb_rcgnn194:
  %v1165 = load i64, ptr %slot155, align 8
  %op1166 = sub i64 %v1165, 16
  store i64 %op1166, ptr %slot157, align 8
  %v1167 = load i64, ptr %slot155, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  %rgep1169 = getelementptr i8, ptr %p1168, i64 -16
  %ld1170 = load i64, ptr %rgep1169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1170, ptr %slot158, align 8
  %v1171 = load i64, ptr %slot158, align 8
  %op1172 = and i64 %v1171, 4611686018427387906
  store i64 %op1172, ptr %slot159, align 8
  %v1173 = load i64, ptr %slot159, align 8
  %cmp1174 = icmp ne i64 %v1173, 0
  %cv1175 = zext i1 %cmp1174 to i32
  store i32 %cv1175, ptr %slot160, align 8
  %v1176 = load i32, ptr %slot160, align 8
  %cv1177 = zext i32 %v1176 to i64
  %cond1178 = icmp ne i64 %cv1177, 0
  br i1 %cond1178, label %bb_rcgclear194, label %bb_rcgcounted194
bb_rcgcounted194:
  %v1179 = load i64, ptr %slot155, align 8
  %op1180 = sub i64 %v1179, 32
  store i64 %op1180, ptr %slot161, align 8
  %v1181 = load i64, ptr %slot155, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %rgep1183 = getelementptr i8, ptr %p1182, i64 -32
  %ld1184 = load i64, ptr %rgep1183, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1184, ptr %slot162, align 8
  %v1185 = load i64, ptr %slot162, align 8
  %op1186 = sub i64 %v1185, 1
  store i64 %op1186, ptr %slot163, align 8
  %v1187 = load i64, ptr %slot163, align 8
  %cmp1188 = icmp eq i64 %v1187, 0
  %cv1189 = zext i1 %cmp1188 to i32
  store i32 %cv1189, ptr %slot164, align 8
  %v1190 = load i32, ptr %slot164, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcglast194, label %bb_rcgdec194
bb_rcglast194:
  %v1193 = load i64, ptr %slot155, align 8
  %op1194 = sub i64 %v1193, 24
  store i64 %op1194, ptr %slot165, align 8
  %v1195 = load i64, ptr %slot155, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %rgep1197 = getelementptr i8, ptr %p1196, i64 -24
  %ld1198 = load i64, ptr %rgep1197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1198, ptr %slot166, align 8
  %v1199 = load i64, ptr %slot166, align 8
  %cmp1200 = icmp ne i64 %v1199, 0
  %cv1201 = zext i1 %cmp1200 to i32
  store i32 %cv1201, ptr %slot167, align 8
  %v1202 = load i32, ptr %slot167, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcgdec194, label %bb_rcgslow194
bb_rcgslow194:
  %v1205 = load i64, ptr %slot154, align 8
  %v1206 = load i64, ptr %slot137, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1205, i64 %v1206) nomerge, !dbg !122
  br label %bb_rcgdone194
bb_rcgdec194:
  %v1207 = load i64, ptr %slot163, align 8
  %v1208 = load i64, ptr %slot155, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %rgep1210 = getelementptr i8, ptr %p1209, i64 -32
  store i64 %v1207, ptr %rgep1210, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear194
bb_rcgclear194:
  %v1211 = load i64, ptr %slot137, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i64 0, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone194
bb_rcgdone194:
  br label %bb_rcslotdone163
bb_rcslotdone163:
  %v1213 = load i64, ptr %slot10, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1215, ptr %slot168, align 8
  %v1216 = load i32, ptr %slot168, align 8
  %cv1217 = zext i32 %v1216 to i64
  %cond1218 = icmp ne i64 %cv1217, 0
  br i1 %cond1218, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1219 = load i64, ptr %slot10, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 0, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot15, align 8
  store i64 %v1221, ptr %slot169, align 8
  %v1222 = load i64, ptr %slot11, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i32, ptr %p1223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1224, ptr %slot170, align 8
  %v1225 = load i32, ptr %slot170, align 8
  %op1226 = and i32 %v1225, 28
  store i32 %op1226, ptr %slot171, align 8
  %v1227 = load i32, ptr %slot171, align 8
  %cv1228 = zext i32 %v1227 to i64
  %cond1229 = icmp ne i64 %cv1228, 0
  br i1 %cond1229, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1230 = load i64, ptr %slot32, align 8
  store i64 %v1230, ptr %slot172, align 8
  %v1231 = load i64, ptr %slot169, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  %ld1233 = load i64, ptr %p1232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1233, ptr %slot173, align 8
  %v1234 = load i64, ptr %slot173, align 8
  %cmp1235 = icmp ne i64 %v1234, 0
  %cv1236 = zext i1 %cmp1235 to i32
  store i32 %cv1236, ptr %slot174, align 8
  %v1237 = load i32, ptr %slot174, align 8
  %cv1238 = zext i32 %v1237 to i64
  %cond1239 = icmp ne i64 %cv1238, 0
  br i1 %cond1239, label %bb_rcgnn216, label %bb_rcgdone216
bb_rcgnn216:
  %v1240 = load i64, ptr %slot173, align 8
  %op1241 = sub i64 %v1240, 16
  store i64 %op1241, ptr %slot175, align 8
  %v1242 = load i64, ptr %slot173, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %rgep1244 = getelementptr i8, ptr %p1243, i64 -16
  %ld1245 = load i64, ptr %rgep1244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1245, ptr %slot176, align 8
  %v1246 = load i64, ptr %slot176, align 8
  %op1247 = and i64 %v1246, 4611686018427387906
  store i64 %op1247, ptr %slot177, align 8
  %v1248 = load i64, ptr %slot177, align 8
  %cmp1249 = icmp ne i64 %v1248, 0
  %cv1250 = zext i1 %cmp1249 to i32
  store i32 %cv1250, ptr %slot178, align 8
  %v1251 = load i32, ptr %slot178, align 8
  %cv1252 = zext i32 %v1251 to i64
  %cond1253 = icmp ne i64 %cv1252, 0
  br i1 %cond1253, label %bb_rcgclear216, label %bb_rcgcounted216
bb_rcgcounted216:
  %v1254 = load i64, ptr %slot173, align 8
  %op1255 = sub i64 %v1254, 24
  store i64 %op1255, ptr %slot179, align 8
  %v1256 = load i64, ptr %slot173, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %rgep1258 = getelementptr i8, ptr %p1257, i64 -24
  %ld1259 = load i64, ptr %rgep1258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1259, ptr %slot180, align 8
  %v1260 = load i64, ptr %slot180, align 8
  %op1261 = sub i64 %v1260, 1
  store i64 %op1261, ptr %slot181, align 8
  %v1262 = load i64, ptr %slot181, align 8
  %cmp1263 = icmp eq i64 %v1262, 0
  %cv1264 = zext i1 %cmp1263 to i32
  store i32 %cv1264, ptr %slot182, align 8
  %v1265 = load i32, ptr %slot182, align 8
  %cv1266 = zext i32 %v1265 to i64
  %cond1267 = icmp ne i64 %cv1266, 0
  br i1 %cond1267, label %bb_rcglast216, label %bb_rcgdec216
bb_rcglast216:
  %v1268 = load i64, ptr %slot173, align 8
  %op1269 = sub i64 %v1268, 32
  store i64 %op1269, ptr %slot183, align 8
  %v1270 = load i64, ptr %slot173, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %rgep1272 = getelementptr i8, ptr %p1271, i64 -32
  %ld1273 = load i64, ptr %rgep1272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1273, ptr %slot184, align 8
  %v1274 = load i64, ptr %slot184, align 8
  %cmp1275 = icmp ne i64 %v1274, 0
  %cv1276 = zext i1 %cmp1275 to i32
  store i32 %cv1276, ptr %slot185, align 8
  %v1277 = load i32, ptr %slot185, align 8
  %cv1278 = zext i32 %v1277 to i64
  %cond1279 = icmp ne i64 %cv1278, 0
  br i1 %cond1279, label %bb_rcgdec216, label %bb_rcgslow216
bb_rcgslow216:
  %v1280 = load i64, ptr %slot172, align 8
  %v1281 = load i64, ptr %slot169, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1280, i64 %v1281) nomerge, !dbg !122
  br label %bb_rcgdone216
bb_rcgdec216:
  %v1282 = load i64, ptr %slot181, align 8
  %v1283 = load i64, ptr %slot173, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %rgep1285 = getelementptr i8, ptr %p1284, i64 -24
  store i64 %v1282, ptr %rgep1285, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear216
bb_rcgclear216:
  %v1286 = load i64, ptr %slot169, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 0, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone216
bb_rcgdone216:
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1288 = load i64, ptr %slot32, align 8
  store i64 %v1288, ptr %slot186, align 8
  %v1289 = load i64, ptr %slot169, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %ld1291 = load i64, ptr %p1290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1291, ptr %slot187, align 8
  %v1292 = load i64, ptr %slot187, align 8
  %cmp1293 = icmp ne i64 %v1292, 0
  %cv1294 = zext i1 %cmp1293 to i32
  store i32 %cv1294, ptr %slot188, align 8
  %v1295 = load i32, ptr %slot188, align 8
  %cv1296 = zext i32 %v1295 to i64
  %cond1297 = icmp ne i64 %cv1296, 0
  br i1 %cond1297, label %bb_rcgnn231, label %bb_rcgdone231
bb_rcgnn231:
  %v1298 = load i64, ptr %slot187, align 8
  %op1299 = sub i64 %v1298, 16
  store i64 %op1299, ptr %slot189, align 8
  %v1300 = load i64, ptr %slot187, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  %rgep1302 = getelementptr i8, ptr %p1301, i64 -16
  %ld1303 = load i64, ptr %rgep1302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1303, ptr %slot190, align 8
  %v1304 = load i64, ptr %slot190, align 8
  %op1305 = and i64 %v1304, 4611686018427387906
  store i64 %op1305, ptr %slot191, align 8
  %v1306 = load i64, ptr %slot191, align 8
  %cmp1307 = icmp ne i64 %v1306, 0
  %cv1308 = zext i1 %cmp1307 to i32
  store i32 %cv1308, ptr %slot192, align 8
  %v1309 = load i32, ptr %slot192, align 8
  %cv1310 = zext i32 %v1309 to i64
  %cond1311 = icmp ne i64 %cv1310, 0
  br i1 %cond1311, label %bb_rcgclear231, label %bb_rcgcounted231
bb_rcgcounted231:
  %v1312 = load i64, ptr %slot187, align 8
  %op1313 = sub i64 %v1312, 32
  store i64 %op1313, ptr %slot193, align 8
  %v1314 = load i64, ptr %slot187, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %rgep1316 = getelementptr i8, ptr %p1315, i64 -32
  %ld1317 = load i64, ptr %rgep1316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1317, ptr %slot194, align 8
  %v1318 = load i64, ptr %slot194, align 8
  %op1319 = sub i64 %v1318, 1
  store i64 %op1319, ptr %slot195, align 8
  %v1320 = load i64, ptr %slot195, align 8
  %cmp1321 = icmp eq i64 %v1320, 0
  %cv1322 = zext i1 %cmp1321 to i32
  store i32 %cv1322, ptr %slot196, align 8
  %v1323 = load i32, ptr %slot196, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcglast231, label %bb_rcgdec231
bb_rcglast231:
  %v1326 = load i64, ptr %slot187, align 8
  %op1327 = sub i64 %v1326, 24
  store i64 %op1327, ptr %slot197, align 8
  %v1328 = load i64, ptr %slot187, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  %rgep1330 = getelementptr i8, ptr %p1329, i64 -24
  %ld1331 = load i64, ptr %rgep1330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1331, ptr %slot198, align 8
  %v1332 = load i64, ptr %slot198, align 8
  %cmp1333 = icmp ne i64 %v1332, 0
  %cv1334 = zext i1 %cmp1333 to i32
  store i32 %cv1334, ptr %slot199, align 8
  %v1335 = load i32, ptr %slot199, align 8
  %cv1336 = zext i32 %v1335 to i64
  %cond1337 = icmp ne i64 %cv1336, 0
  br i1 %cond1337, label %bb_rcgdec231, label %bb_rcgslow231
bb_rcgslow231:
  %v1338 = load i64, ptr %slot186, align 8
  %v1339 = load i64, ptr %slot169, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1338, i64 %v1339) nomerge, !dbg !122
  br label %bb_rcgdone231
bb_rcgdec231:
  %v1340 = load i64, ptr %slot195, align 8
  %v1341 = load i64, ptr %slot187, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %rgep1343 = getelementptr i8, ptr %p1342, i64 -32
  store i64 %v1340, ptr %rgep1343, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear231
bb_rcgclear231:
  %v1344 = load i64, ptr %slot169, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i64 0, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone231
bb_rcgdone231:
  br label %bb_rcslotdone200
bb_rcslotdone200:
  %v1346 = load i64, ptr %slot14, align 8
  store i64 %v1346, ptr %slot200, align 8
  %v1347 = load i64, ptr %slot18, align 8
  store i64 %v1347, ptr %slot201, align 8
  %v1348 = load i64, ptr %slot201, align 8
  %v1349 = load i64, ptr %slot200, align 8
  %p1350 = inttoptr i64 %v1348 to ptr
  %p1351 = inttoptr i64 %v1349 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1351, ptr %p1350, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot9, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i32 2, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  %v1354 = load i64, ptr %slot13, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  %ld1356 = load i32, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1356, ptr %slot202, align 8
  %v1357 = load i32, ptr %slot202, align 8
  %v1358 = load i64, ptr %slot9, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 %v1357, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot12, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  store i32 0, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  %v1362 = load i64, ptr %slot8, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i32 1, ptr %p1363, align 4, !alias.scope !3, !noalias !4
  %v1364 = load i64, ptr %slot200, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %ld1366 = load i64, ptr %p1365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1366, ptr %slot203, align 8
  %v1367 = load i64, ptr %slot203, align 8
  %v1368 = load i64, ptr %slot25, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  store i64 %v1367, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  %v1370 = load i64, ptr %slot25, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %ld1372 = load i64, ptr %p1371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1372, ptr %slot204, align 8
  %v1373 = load i64, ptr %slot204, align 8
  %v1374 = load i64, ptr %slot16, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i64 %v1373, ptr %p1375, align 8, !alias.scope !3, !noalias !4
  %v1376 = load i64, ptr %slot16, align 8
  store i64 %v1376, ptr %slot205, align 8
  %v1377 = load i64, ptr %slot8, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i32, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1379, ptr %slot206, align 8
  %v1380 = load i64, ptr %slot9, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  %ld1382 = load i32, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1382, ptr %slot207, align 8
  %v1383 = load i32, ptr %slot207, align 8
  %op1384 = and i32 %v1383, 24
  store i32 %op1384, ptr %slot207, align 8
  %v1385 = load i32, ptr %slot207, align 8
  %cmp1386 = icmp eq i32 %v1385, 0
  %cv1387 = zext i1 %cmp1386 to i32
  store i32 %cv1387, ptr %slot208, align 8
  %v1388 = load i32, ptr %slot206, align 8
  %v1389 = load i32, ptr %slot208, align 8
  %op1390 = and i32 %v1388, %v1389
  store i32 %op1390, ptr %slot209, align 8
  %v1391 = load i32, ptr %slot209, align 8
  %cv1392 = zext i32 %v1391 to i64
  %cond1393 = icmp ne i64 %cv1392, 0
  br i1 %cond1393, label %bb_rctake246, label %bb_rccopy246
bb_rctake246:
  %v1394 = load i64, ptr %slot18, align 8
  store i64 %v1394, ptr %slot210, align 8
  %v1395 = load i64, ptr %slot33, align 8
  store i64 %v1395, ptr %slot211, align 8
  %v1396 = load i64, ptr %slot205, align 8
  %v1397 = load i64, ptr %slot210, align 8
  %op1398 = sub i64 %v1396, %v1397
  store i64 %op1398, ptr %slot212, align 8
  %v1399 = load i64, ptr %slot210, align 8
  %v1400 = load i64, ptr %slot205, align 8
  %op1401 = sub i64 %v1399, %v1400
  store i64 %op1401, ptr %slot213, align 8
  %v1402 = load i64, ptr %slot212, align 8
  %cmp1403 = icmp ult i64 %v1402, 8
  %cv1404 = zext i1 %cmp1403 to i32
  store i32 %cv1404, ptr %slot214, align 8
  %v1405 = load i64, ptr %slot213, align 8
  %cmp1406 = icmp ult i64 %v1405, 8
  %cv1407 = zext i1 %cmp1406 to i32
  store i32 %cv1407, ptr %slot215, align 8
  %v1408 = load i32, ptr %slot214, align 8
  %v1409 = load i32, ptr %slot215, align 8
  %op1410 = or i32 %v1408, %v1409
  store i32 %op1410, ptr %slot216, align 8
  %v1411 = load i32, ptr %slot216, align 8
  %cv1412 = zext i32 %v1411 to i64
  %cond1413 = icmp ne i64 %cv1412, 0
  br i1 %cond1413, label %bb_rcmoveslow255, label %bb_rcmovecheck255
bb_rcmovecheck255:
  %v1414 = load i64, ptr %slot205, align 8
  %p1416 = inttoptr i64 %v1414 to ptr
  %gep1417 = getelementptr i8, ptr %p1416, i64 0
  %op1415 = ptrtoint ptr %gep1417 to i64
  store i64 %op1415, ptr %slot217, align 8
  %v1418 = load i64, ptr %slot217, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i64, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1420, ptr %slot218, align 8
  %v1421 = load i64, ptr %slot218, align 8
  %cmp1422 = icmp ne i64 %v1421, 0
  %cv1423 = zext i1 %cmp1422 to i32
  store i32 %cv1423, ptr %slot219, align 8
  %v1424 = load i32, ptr %slot219, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rcmoveheader263, label %bb_rcmovenext263
bb_rcmoveheader263:
  %v1427 = load i64, ptr %slot218, align 8
  %op1428 = sub i64 %v1427, 16
  store i64 %op1428, ptr %slot220, align 8
  %v1429 = load i64, ptr %slot218, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %rgep1431 = getelementptr i8, ptr %p1430, i64 -16
  %ld1432 = load i64, ptr %rgep1431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1432, ptr %slot221, align 8
  %v1433 = load i64, ptr %slot221, align 8
  %op1434 = and i64 %v1433, 5764607523034234881
  store i64 %op1434, ptr %slot222, align 8
  %v1435 = load i64, ptr %slot222, align 8
  %cmp1436 = icmp ne i64 %v1435, 0
  %cv1437 = zext i1 %cmp1436 to i32
  store i32 %cv1437, ptr %slot223, align 8
  %v1438 = load i32, ptr %slot223, align 8
  %cv1439 = zext i32 %v1438 to i64
  %cond1440 = icmp ne i64 %cv1439, 0
  br i1 %cond1440, label %bb_rcmoveslow255, label %bb_rcmovenext263
bb_rcmovenext263:
  %v1441 = load i64, ptr %slot205, align 8
  %v1442 = load i64, ptr %slot210, align 8
  %p1443 = inttoptr i64 %v1441 to ptr
  %p1444 = inttoptr i64 %v1442 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1444, ptr %p1443, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1445 = load i64, ptr %slot205, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  store i64 0, ptr %p1446, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved255
bb_rcmoveslow255:
  %v1447 = load i64, ptr %slot32, align 8
  %v1448 = load i64, ptr %slot210, align 8
  %v1449 = load i64, ptr %slot205, align 8
  %v1450 = load i64, ptr %slot211, align 8
  %cv1451 = trunc i64 %v1450 to i32
  %call1452 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1447, i64 %v1448, i64 %v1449, i32 %cv1451) nomerge, !dbg !124
  store i32 %call1452, ptr %slot224, align 8
  %v1453 = load i32, ptr %slot224, align 8
  %cv1454 = zext i32 %v1453 to i64
  %cond1455 = icmp ne i64 %cv1454, 0
  br i1 %cond1455, label %bb_rcsuccess270, label %bb_rcfailure270
bb_rcfailure270:
  %v1456 = load i64, ptr %slot32, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %call1458 = call i32 @myl_rc_take_failure(ptr %p1457) nomerge, !dbg !124
  store i32 %call1458, ptr %slot225, align 8
  %v1459 = load i64, ptr %slot1, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %v1461 = load i32, ptr %slot225, align 8
  %call1462 = call i32 @myl_qbe_rc_status(ptr %p1460, i32 %v1461) nomerge, !dbg !124
  store i32 %call1462, ptr %slot226, align 8
  br label %bb_failure
bb_rcsuccess270:
  br label %bb_rcmoved255
bb_rcmoved255:
  %v1463 = load i64, ptr %slot8, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i32 0, ptr %p1464, align 4, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot13, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i32 2, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot12, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i32 1, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared246
bb_rccopy246:
  %v1469 = load i64, ptr %slot18, align 8
  store i64 %v1469, ptr %slot227, align 8
  %v1470 = load i64, ptr %slot33, align 8
  store i64 %v1470, ptr %slot228, align 8
  %v1471 = load i64, ptr %slot205, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  %ld1473 = load i64, ptr %p1472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1473, ptr %slot229, align 8
  %v1474 = load i64, ptr %slot229, align 8
  %cmp1475 = icmp ne i64 %v1474, 0
  %cv1476 = zext i1 %cmp1475 to i32
  store i32 %cv1476, ptr %slot230, align 8
  %v1477 = load i32, ptr %slot230, align 8
  %cv1478 = zext i32 %v1477 to i64
  %cond1479 = icmp ne i64 %cv1478, 0
  br i1 %cond1479, label %bb_rcgnn279, label %bb_rcgplain279
bb_rcgnn279:
  %v1480 = load i64, ptr %slot229, align 8
  %op1481 = sub i64 %v1480, 16
  store i64 %op1481, ptr %slot231, align 8
  %v1482 = load i64, ptr %slot229, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %rgep1484 = getelementptr i8, ptr %p1483, i64 -16
  %ld1485 = load i64, ptr %rgep1484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1485, ptr %slot232, align 8
  %v1486 = load i64, ptr %slot232, align 8
  %op1487 = and i64 %v1486, 4611686018427387906
  store i64 %op1487, ptr %slot233, align 8
  %v1488 = load i64, ptr %slot233, align 8
  %cmp1489 = icmp ne i64 %v1488, 0
  %cv1490 = zext i1 %cmp1489 to i32
  store i32 %cv1490, ptr %slot234, align 8
  %v1491 = load i32, ptr %slot234, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcgspecial279, label %bb_rcginc279
bb_rcginc279:
  %v1494 = load i64, ptr %slot229, align 8
  %op1495 = sub i64 %v1494, 32
  store i64 %op1495, ptr %slot235, align 8
  %v1496 = load i64, ptr %slot229, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %rgep1498 = getelementptr i8, ptr %p1497, i64 -32
  %ld1499 = load i64, ptr %rgep1498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1499, ptr %slot236, align 8
  %v1500 = load i64, ptr %slot236, align 8
  %op1501 = add i64 %v1500, 1
  store i64 %op1501, ptr %slot237, align 8
  %v1502 = load i64, ptr %slot237, align 8
  %cmp1503 = icmp eq i64 %v1502, 0
  %cv1504 = zext i1 %cmp1503 to i32
  store i32 %cv1504, ptr %slot238, align 8
  %v1505 = load i32, ptr %slot238, align 8
  %cv1506 = zext i32 %v1505 to i64
  %cond1507 = icmp ne i64 %cv1506, 0
  br i1 %cond1507, label %bb_rcglimit279, label %bb_rcgcapacity279
bb_rcglimit279:
  %v1508 = load i64, ptr %slot1, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %call1510 = call i32 @myl_qbe_rc_status(ptr %p1509, i32 2) nomerge, !dbg !124
  store i32 %call1510, ptr %slot239, align 8
  br label %bb_failure
bb_rcgcapacity279:
  %v1511 = load i64, ptr %slot237, align 8
  %v1512 = load i64, ptr %slot229, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %rgep1514 = getelementptr i8, ptr %p1513, i64 -32
  store i64 %v1511, ptr %rgep1514, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain279
bb_rcgspecial279:
  %v1515 = load i64, ptr %slot232, align 8
  %op1516 = and i64 %v1515, 4611686018427387904
  store i64 %op1516, ptr %slot240, align 8
  %v1517 = load i64, ptr %slot240, align 8
  %cmp1518 = icmp ne i64 %v1517, 0
  %cv1519 = zext i1 %cmp1518 to i32
  store i32 %cv1519, ptr %slot241, align 8
  %v1520 = load i32, ptr %slot241, align 8
  %cv1521 = zext i32 %v1520 to i64
  %cond1522 = icmp ne i64 %cv1521, 0
  br i1 %cond1522, label %bb_rcgslow279, label %bb_rcgplain279
bb_rcgslow279:
  %v1523 = load i64, ptr %slot32, align 8
  %v1524 = load i64, ptr %slot227, align 8
  %v1525 = load i64, ptr %slot205, align 8
  %v1526 = load i64, ptr %slot228, align 8
  %cv1527 = trunc i64 %v1526 to i32
  %call1528 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v1523, i64 %v1524, i64 %v1525, i32 %cv1527) nomerge, !dbg !124
  store i32 %call1528, ptr %slot242, align 8
  %v1529 = load i32, ptr %slot242, align 8
  %cv1530 = zext i32 %v1529 to i64
  %cond1531 = icmp ne i64 %cv1530, 0
  br i1 %cond1531, label %bb_rcsuccess293, label %bb_rcfailure293
bb_rcfailure293:
  %v1532 = load i64, ptr %slot32, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %call1534 = call i32 @myl_rc_take_failure(ptr %p1533) nomerge, !dbg !124
  store i32 %call1534, ptr %slot243, align 8
  %v1535 = load i64, ptr %slot1, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %v1537 = load i32, ptr %slot243, align 8
  %call1538 = call i32 @myl_qbe_rc_status(ptr %p1536, i32 %v1537) nomerge, !dbg !124
  store i32 %call1538, ptr %slot244, align 8
  br label %bb_failure
bb_rcsuccess293:
  br label %bb_rcgdone279
bb_rcgplain279:
  %v1539 = load i64, ptr %slot229, align 8
  %v1540 = load i64, ptr %slot227, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i64 %v1539, ptr %p1541, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone279
bb_rcgdone279:
  %v1542 = load i64, ptr %slot13, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  store i32 2, ptr %p1543, align 4, !alias.scope !3, !noalias !4
  %v1544 = load i64, ptr %slot12, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i32 1, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  %v1546 = load i64, ptr %slot8, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %ld1548 = load i32, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1548, ptr %slot245, align 8
  %v1549 = load i32, ptr %slot245, align 8
  %cv1550 = zext i32 %v1549 to i64
  %cond1551 = icmp ne i64 %cv1550, 0
  br i1 %cond1551, label %bb_rcslotdrop300, label %bb_rcslotdone300
bb_rcslotdrop300:
  %v1552 = load i64, ptr %slot8, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i32 0, ptr %p1553, align 4, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot14, align 8
  store i64 %v1554, ptr %slot246, align 8
  %v1555 = load i64, ptr %slot9, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  %ld1557 = load i32, ptr %p1556, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1557, ptr %slot247, align 8
  %v1558 = load i32, ptr %slot247, align 8
  %op1559 = and i32 %v1558, 28
  store i32 %op1559, ptr %slot248, align 8
  %v1560 = load i32, ptr %slot248, align 8
  %cv1561 = zext i32 %v1560 to i64
  %cond1562 = icmp ne i64 %cv1561, 0
  br i1 %cond1562, label %bb_rcslotrole300, label %bb_rcslotowner300
bb_rcslotrole300:
  %v1563 = load i64, ptr %slot32, align 8
  store i64 %v1563, ptr %slot249, align 8
  %v1564 = load i64, ptr %slot246, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  %ld1566 = load i64, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1566, ptr %slot250, align 8
  %v1567 = load i64, ptr %slot250, align 8
  %cmp1568 = icmp ne i64 %v1567, 0
  %cv1569 = zext i1 %cmp1568 to i32
  store i32 %cv1569, ptr %slot251, align 8
  %v1570 = load i32, ptr %slot251, align 8
  %cv1571 = zext i32 %v1570 to i64
  %cond1572 = icmp ne i64 %cv1571, 0
  br i1 %cond1572, label %bb_rcgnn316, label %bb_rcgdone316
bb_rcgnn316:
  %v1573 = load i64, ptr %slot250, align 8
  %op1574 = sub i64 %v1573, 16
  store i64 %op1574, ptr %slot252, align 8
  %v1575 = load i64, ptr %slot250, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  %rgep1577 = getelementptr i8, ptr %p1576, i64 -16
  %ld1578 = load i64, ptr %rgep1577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1578, ptr %slot253, align 8
  %v1579 = load i64, ptr %slot253, align 8
  %op1580 = and i64 %v1579, 4611686018427387906
  store i64 %op1580, ptr %slot254, align 8
  %v1581 = load i64, ptr %slot254, align 8
  %cmp1582 = icmp ne i64 %v1581, 0
  %cv1583 = zext i1 %cmp1582 to i32
  store i32 %cv1583, ptr %slot255, align 8
  %v1584 = load i32, ptr %slot255, align 8
  %cv1585 = zext i32 %v1584 to i64
  %cond1586 = icmp ne i64 %cv1585, 0
  br i1 %cond1586, label %bb_rcgclear316, label %bb_rcgcounted316
bb_rcgcounted316:
  %v1587 = load i64, ptr %slot250, align 8
  %op1588 = sub i64 %v1587, 24
  store i64 %op1588, ptr %slot256, align 8
  %v1589 = load i64, ptr %slot250, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %rgep1591 = getelementptr i8, ptr %p1590, i64 -24
  %ld1592 = load i64, ptr %rgep1591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1592, ptr %slot257, align 8
  %v1593 = load i64, ptr %slot257, align 8
  %op1594 = sub i64 %v1593, 1
  store i64 %op1594, ptr %slot258, align 8
  %v1595 = load i64, ptr %slot258, align 8
  %cmp1596 = icmp eq i64 %v1595, 0
  %cv1597 = zext i1 %cmp1596 to i32
  store i32 %cv1597, ptr %slot259, align 8
  %v1598 = load i32, ptr %slot259, align 8
  %cv1599 = zext i32 %v1598 to i64
  %cond1600 = icmp ne i64 %cv1599, 0
  br i1 %cond1600, label %bb_rcglast316, label %bb_rcgdec316
bb_rcglast316:
  %v1601 = load i64, ptr %slot250, align 8
  %op1602 = sub i64 %v1601, 32
  store i64 %op1602, ptr %slot260, align 8
  %v1603 = load i64, ptr %slot250, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %rgep1605 = getelementptr i8, ptr %p1604, i64 -32
  %ld1606 = load i64, ptr %rgep1605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1606, ptr %slot261, align 8
  %v1607 = load i64, ptr %slot261, align 8
  %cmp1608 = icmp ne i64 %v1607, 0
  %cv1609 = zext i1 %cmp1608 to i32
  store i32 %cv1609, ptr %slot262, align 8
  %v1610 = load i32, ptr %slot262, align 8
  %cv1611 = zext i32 %v1610 to i64
  %cond1612 = icmp ne i64 %cv1611, 0
  br i1 %cond1612, label %bb_rcgdec316, label %bb_rcgslow316
bb_rcgslow316:
  %v1613 = load i64, ptr %slot249, align 8
  %v1614 = load i64, ptr %slot246, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1613, i64 %v1614) nomerge, !dbg !124
  br label %bb_rcgdone316
bb_rcgdec316:
  %v1615 = load i64, ptr %slot258, align 8
  %v1616 = load i64, ptr %slot250, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  %rgep1618 = getelementptr i8, ptr %p1617, i64 -24
  store i64 %v1615, ptr %rgep1618, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear316
bb_rcgclear316:
  %v1619 = load i64, ptr %slot246, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i64 0, ptr %p1620, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone316
bb_rcgdone316:
  br label %bb_rcslotdone300
bb_rcslotowner300:
  %v1621 = load i64, ptr %slot32, align 8
  store i64 %v1621, ptr %slot263, align 8
  %v1622 = load i64, ptr %slot246, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  %ld1624 = load i64, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1624, ptr %slot264, align 8
  %v1625 = load i64, ptr %slot264, align 8
  %cmp1626 = icmp ne i64 %v1625, 0
  %cv1627 = zext i1 %cmp1626 to i32
  store i32 %cv1627, ptr %slot265, align 8
  %v1628 = load i32, ptr %slot265, align 8
  %cv1629 = zext i32 %v1628 to i64
  %cond1630 = icmp ne i64 %cv1629, 0
  br i1 %cond1630, label %bb_rcgnn331, label %bb_rcgdone331
bb_rcgnn331:
  %v1631 = load i64, ptr %slot264, align 8
  %op1632 = sub i64 %v1631, 16
  store i64 %op1632, ptr %slot266, align 8
  %v1633 = load i64, ptr %slot264, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %rgep1635 = getelementptr i8, ptr %p1634, i64 -16
  %ld1636 = load i64, ptr %rgep1635, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1636, ptr %slot267, align 8
  %v1637 = load i64, ptr %slot267, align 8
  %op1638 = and i64 %v1637, 4611686018427387906
  store i64 %op1638, ptr %slot268, align 8
  %v1639 = load i64, ptr %slot268, align 8
  %cmp1640 = icmp ne i64 %v1639, 0
  %cv1641 = zext i1 %cmp1640 to i32
  store i32 %cv1641, ptr %slot269, align 8
  %v1642 = load i32, ptr %slot269, align 8
  %cv1643 = zext i32 %v1642 to i64
  %cond1644 = icmp ne i64 %cv1643, 0
  br i1 %cond1644, label %bb_rcgclear331, label %bb_rcgcounted331
bb_rcgcounted331:
  %v1645 = load i64, ptr %slot264, align 8
  %op1646 = sub i64 %v1645, 32
  store i64 %op1646, ptr %slot270, align 8
  %v1647 = load i64, ptr %slot264, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %rgep1649 = getelementptr i8, ptr %p1648, i64 -32
  %ld1650 = load i64, ptr %rgep1649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1650, ptr %slot271, align 8
  %v1651 = load i64, ptr %slot271, align 8
  %op1652 = sub i64 %v1651, 1
  store i64 %op1652, ptr %slot272, align 8
  %v1653 = load i64, ptr %slot272, align 8
  %cmp1654 = icmp eq i64 %v1653, 0
  %cv1655 = zext i1 %cmp1654 to i32
  store i32 %cv1655, ptr %slot273, align 8
  %v1656 = load i32, ptr %slot273, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcglast331, label %bb_rcgdec331
bb_rcglast331:
  %v1659 = load i64, ptr %slot264, align 8
  %op1660 = sub i64 %v1659, 24
  store i64 %op1660, ptr %slot274, align 8
  %v1661 = load i64, ptr %slot264, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %rgep1663 = getelementptr i8, ptr %p1662, i64 -24
  %ld1664 = load i64, ptr %rgep1663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1664, ptr %slot275, align 8
  %v1665 = load i64, ptr %slot275, align 8
  %cmp1666 = icmp ne i64 %v1665, 0
  %cv1667 = zext i1 %cmp1666 to i32
  store i32 %cv1667, ptr %slot276, align 8
  %v1668 = load i32, ptr %slot276, align 8
  %cv1669 = zext i32 %v1668 to i64
  %cond1670 = icmp ne i64 %cv1669, 0
  br i1 %cond1670, label %bb_rcgdec331, label %bb_rcgslow331
bb_rcgslow331:
  %v1671 = load i64, ptr %slot263, align 8
  %v1672 = load i64, ptr %slot246, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1671, i64 %v1672) nomerge, !dbg !124
  br label %bb_rcgdone331
bb_rcgdec331:
  %v1673 = load i64, ptr %slot272, align 8
  %v1674 = load i64, ptr %slot264, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  %rgep1676 = getelementptr i8, ptr %p1675, i64 -32
  store i64 %v1673, ptr %rgep1676, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear331
bb_rcgclear331:
  %v1677 = load i64, ptr %slot246, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i64 0, ptr %p1678, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone331
bb_rcgdone331:
  br label %bb_rcslotdone300
bb_rcslotdone300:
  br label %bb_rcprepared246
bb_rcprepared246:
  %v1679 = load i64, ptr %slot6, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i32, ptr %p1680, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1681, ptr %slot277, align 8
  %v1682 = load i32, ptr %slot277, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcslotdrop338, label %bb_rcslotdone338
bb_rcslotdrop338:
  %v1685 = load i64, ptr %slot6, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i32 0, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  %v1687 = load i64, ptr %slot22, align 8
  store i64 %v1687, ptr %slot278, align 8
  %v1688 = load i64, ptr %slot7, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %ld1690 = load i32, ptr %p1689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1690, ptr %slot279, align 8
  %v1691 = load i32, ptr %slot279, align 8
  %op1692 = and i32 %v1691, 28
  store i32 %op1692, ptr %slot280, align 8
  %v1693 = load i32, ptr %slot280, align 8
  %cv1694 = zext i32 %v1693 to i64
  %cond1695 = icmp ne i64 %cv1694, 0
  br i1 %cond1695, label %bb_rcslotrole338, label %bb_rcslotowner338
bb_rcslotrole338:
  %v1696 = load i64, ptr %slot32, align 8
  store i64 %v1696, ptr %slot281, align 8
  %v1697 = load i64, ptr %slot278, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  %ld1699 = load i64, ptr %p1698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1699, ptr %slot282, align 8
  %v1700 = load i64, ptr %slot282, align 8
  %cmp1701 = icmp ne i64 %v1700, 0
  %cv1702 = zext i1 %cmp1701 to i32
  store i32 %cv1702, ptr %slot283, align 8
  %v1703 = load i32, ptr %slot283, align 8
  %cv1704 = zext i32 %v1703 to i64
  %cond1705 = icmp ne i64 %cv1704, 0
  br i1 %cond1705, label %bb_rcgnn354, label %bb_rcgdone354
bb_rcgnn354:
  %v1706 = load i64, ptr %slot282, align 8
  %op1707 = sub i64 %v1706, 16
  store i64 %op1707, ptr %slot284, align 8
  %v1708 = load i64, ptr %slot282, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %rgep1710 = getelementptr i8, ptr %p1709, i64 -16
  %ld1711 = load i64, ptr %rgep1710, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1711, ptr %slot285, align 8
  %v1712 = load i64, ptr %slot285, align 8
  %op1713 = and i64 %v1712, 4611686018427387906
  store i64 %op1713, ptr %slot286, align 8
  %v1714 = load i64, ptr %slot286, align 8
  %cmp1715 = icmp ne i64 %v1714, 0
  %cv1716 = zext i1 %cmp1715 to i32
  store i32 %cv1716, ptr %slot287, align 8
  %v1717 = load i32, ptr %slot287, align 8
  %cv1718 = zext i32 %v1717 to i64
  %cond1719 = icmp ne i64 %cv1718, 0
  br i1 %cond1719, label %bb_rcgclear354, label %bb_rcgcounted354
bb_rcgcounted354:
  %v1720 = load i64, ptr %slot282, align 8
  %op1721 = sub i64 %v1720, 24
  store i64 %op1721, ptr %slot288, align 8
  %v1722 = load i64, ptr %slot282, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  %rgep1724 = getelementptr i8, ptr %p1723, i64 -24
  %ld1725 = load i64, ptr %rgep1724, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1725, ptr %slot289, align 8
  %v1726 = load i64, ptr %slot289, align 8
  %op1727 = sub i64 %v1726, 1
  store i64 %op1727, ptr %slot290, align 8
  %v1728 = load i64, ptr %slot290, align 8
  %cmp1729 = icmp eq i64 %v1728, 0
  %cv1730 = zext i1 %cmp1729 to i32
  store i32 %cv1730, ptr %slot291, align 8
  %v1731 = load i32, ptr %slot291, align 8
  %cv1732 = zext i32 %v1731 to i64
  %cond1733 = icmp ne i64 %cv1732, 0
  br i1 %cond1733, label %bb_rcglast354, label %bb_rcgdec354
bb_rcglast354:
  %v1734 = load i64, ptr %slot282, align 8
  %op1735 = sub i64 %v1734, 32
  store i64 %op1735, ptr %slot292, align 8
  %v1736 = load i64, ptr %slot282, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %rgep1738 = getelementptr i8, ptr %p1737, i64 -32
  %ld1739 = load i64, ptr %rgep1738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1739, ptr %slot293, align 8
  %v1740 = load i64, ptr %slot293, align 8
  %cmp1741 = icmp ne i64 %v1740, 0
  %cv1742 = zext i1 %cmp1741 to i32
  store i32 %cv1742, ptr %slot294, align 8
  %v1743 = load i32, ptr %slot294, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcgdec354, label %bb_rcgslow354
bb_rcgslow354:
  %v1746 = load i64, ptr %slot281, align 8
  %v1747 = load i64, ptr %slot278, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1746, i64 %v1747) nomerge, !dbg !124
  br label %bb_rcgdone354
bb_rcgdec354:
  %v1748 = load i64, ptr %slot290, align 8
  %v1749 = load i64, ptr %slot282, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %rgep1751 = getelementptr i8, ptr %p1750, i64 -24
  store i64 %v1748, ptr %rgep1751, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear354
bb_rcgclear354:
  %v1752 = load i64, ptr %slot278, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i64 0, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone354
bb_rcgdone354:
  br label %bb_rcslotdone338
bb_rcslotowner338:
  %v1754 = load i64, ptr %slot32, align 8
  store i64 %v1754, ptr %slot295, align 8
  %v1755 = load i64, ptr %slot278, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i64, ptr %p1756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1757, ptr %slot296, align 8
  %v1758 = load i64, ptr %slot296, align 8
  %cmp1759 = icmp ne i64 %v1758, 0
  %cv1760 = zext i1 %cmp1759 to i32
  store i32 %cv1760, ptr %slot297, align 8
  %v1761 = load i32, ptr %slot297, align 8
  %cv1762 = zext i32 %v1761 to i64
  %cond1763 = icmp ne i64 %cv1762, 0
  br i1 %cond1763, label %bb_rcgnn369, label %bb_rcgdone369
bb_rcgnn369:
  %v1764 = load i64, ptr %slot296, align 8
  %op1765 = sub i64 %v1764, 16
  store i64 %op1765, ptr %slot298, align 8
  %v1766 = load i64, ptr %slot296, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %rgep1768 = getelementptr i8, ptr %p1767, i64 -16
  %ld1769 = load i64, ptr %rgep1768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1769, ptr %slot299, align 8
  %v1770 = load i64, ptr %slot299, align 8
  %op1771 = and i64 %v1770, 4611686018427387906
  store i64 %op1771, ptr %slot300, align 8
  %v1772 = load i64, ptr %slot300, align 8
  %cmp1773 = icmp ne i64 %v1772, 0
  %cv1774 = zext i1 %cmp1773 to i32
  store i32 %cv1774, ptr %slot301, align 8
  %v1775 = load i32, ptr %slot301, align 8
  %cv1776 = zext i32 %v1775 to i64
  %cond1777 = icmp ne i64 %cv1776, 0
  br i1 %cond1777, label %bb_rcgclear369, label %bb_rcgcounted369
bb_rcgcounted369:
  %v1778 = load i64, ptr %slot296, align 8
  %op1779 = sub i64 %v1778, 32
  store i64 %op1779, ptr %slot302, align 8
  %v1780 = load i64, ptr %slot296, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %rgep1782 = getelementptr i8, ptr %p1781, i64 -32
  %ld1783 = load i64, ptr %rgep1782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1783, ptr %slot303, align 8
  %v1784 = load i64, ptr %slot303, align 8
  %op1785 = sub i64 %v1784, 1
  store i64 %op1785, ptr %slot304, align 8
  %v1786 = load i64, ptr %slot304, align 8
  %cmp1787 = icmp eq i64 %v1786, 0
  %cv1788 = zext i1 %cmp1787 to i32
  store i32 %cv1788, ptr %slot305, align 8
  %v1789 = load i32, ptr %slot305, align 8
  %cv1790 = zext i32 %v1789 to i64
  %cond1791 = icmp ne i64 %cv1790, 0
  br i1 %cond1791, label %bb_rcglast369, label %bb_rcgdec369
bb_rcglast369:
  %v1792 = load i64, ptr %slot296, align 8
  %op1793 = sub i64 %v1792, 24
  store i64 %op1793, ptr %slot306, align 8
  %v1794 = load i64, ptr %slot296, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %rgep1796 = getelementptr i8, ptr %p1795, i64 -24
  %ld1797 = load i64, ptr %rgep1796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1797, ptr %slot307, align 8
  %v1798 = load i64, ptr %slot307, align 8
  %cmp1799 = icmp ne i64 %v1798, 0
  %cv1800 = zext i1 %cmp1799 to i32
  store i32 %cv1800, ptr %slot308, align 8
  %v1801 = load i32, ptr %slot308, align 8
  %cv1802 = zext i32 %v1801 to i64
  %cond1803 = icmp ne i64 %cv1802, 0
  br i1 %cond1803, label %bb_rcgdec369, label %bb_rcgslow369
bb_rcgslow369:
  %v1804 = load i64, ptr %slot295, align 8
  %v1805 = load i64, ptr %slot278, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1804, i64 %v1805) nomerge, !dbg !124
  br label %bb_rcgdone369
bb_rcgdec369:
  %v1806 = load i64, ptr %slot304, align 8
  %v1807 = load i64, ptr %slot296, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %rgep1809 = getelementptr i8, ptr %p1808, i64 -32
  store i64 %v1806, ptr %rgep1809, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear369
bb_rcgclear369:
  %v1810 = load i64, ptr %slot278, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  store i64 0, ptr %p1811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone369
bb_rcgdone369:
  br label %bb_rcslotdone338
bb_rcslotdone338:
  %v1812 = load i64, ptr %slot22, align 8
  store i64 %v1812, ptr %slot309, align 8
  %v1813 = load i64, ptr %slot18, align 8
  store i64 %v1813, ptr %slot310, align 8
  %v1814 = load i64, ptr %slot310, align 8
  %v1815 = load i64, ptr %slot309, align 8
  %p1816 = inttoptr i64 %v1814 to ptr
  %p1817 = inttoptr i64 %v1815 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1817, ptr %p1816, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1818 = load i64, ptr %slot12, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  store i32 0, ptr %p1819, align 4, !alias.scope !3, !noalias !4
  %v1820 = load i64, ptr %slot7, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i32 2, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot13, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i32, ptr %p1823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1824, ptr %slot311, align 8
  %v1825 = load i32, ptr %slot311, align 8
  %v1826 = load i64, ptr %slot7, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  store i32 %v1825, ptr %p1827, align 4, !alias.scope !3, !noalias !4
  %v1828 = load i64, ptr %slot6, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i32 1, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot22, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %ld1832 = load i64, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1832, ptr %slot312, align 8
  %v1833 = load i64, ptr %slot312, align 8
  %v1834 = load i64, ptr %slot25, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  store i64 %v1833, ptr %p1835, align 8, !alias.scope !3, !noalias !4
  %v1836 = load i64, ptr %slot25, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot313, align 8
  %v1839 = load i64, ptr %slot1, align 8
  %v1840 = load i64, ptr %slot313, align 8
  %call1841 = call i64 @myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1(i64 %v1839, i64 %v1840) nomerge, !dbg !126
  store i64 %call1841, ptr %slot314, align 8
  %v1842 = load i64, ptr %slot314, align 8
  %v1843 = load i64, ptr %slot25, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  store i64 %v1842, ptr %p1844, align 8, !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot8, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i32, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1847, ptr %slot315, align 8
  %v1848 = load i32, ptr %slot315, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcslotdrop385, label %bb_rcslotdone385
bb_rcslotdrop385:
  %v1851 = load i64, ptr %slot8, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  store i32 0, ptr %p1852, align 4, !alias.scope !3, !noalias !4
  %v1853 = load i64, ptr %slot14, align 8
  store i64 %v1853, ptr %slot316, align 8
  %v1854 = load i64, ptr %slot9, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %ld1856 = load i32, ptr %p1855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1856, ptr %slot317, align 8
  %v1857 = load i32, ptr %slot317, align 8
  %op1858 = and i32 %v1857, 28
  store i32 %op1858, ptr %slot318, align 8
  %v1859 = load i32, ptr %slot318, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcslotrole385, label %bb_rcslotowner385
bb_rcslotrole385:
  %v1862 = load i64, ptr %slot32, align 8
  store i64 %v1862, ptr %slot319, align 8
  %v1863 = load i64, ptr %slot316, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1865, ptr %slot320, align 8
  %v1866 = load i64, ptr %slot320, align 8
  %cmp1867 = icmp ne i64 %v1866, 0
  %cv1868 = zext i1 %cmp1867 to i32
  store i32 %cv1868, ptr %slot321, align 8
  %v1869 = load i32, ptr %slot321, align 8
  %cv1870 = zext i32 %v1869 to i64
  %cond1871 = icmp ne i64 %cv1870, 0
  br i1 %cond1871, label %bb_rcgnn401, label %bb_rcgdone401
bb_rcgnn401:
  %v1872 = load i64, ptr %slot320, align 8
  %op1873 = sub i64 %v1872, 16
  store i64 %op1873, ptr %slot322, align 8
  %v1874 = load i64, ptr %slot320, align 8
  %p1875 = inttoptr i64 %v1874 to ptr
  %rgep1876 = getelementptr i8, ptr %p1875, i64 -16
  %ld1877 = load i64, ptr %rgep1876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1877, ptr %slot323, align 8
  %v1878 = load i64, ptr %slot323, align 8
  %op1879 = and i64 %v1878, 4611686018427387906
  store i64 %op1879, ptr %slot324, align 8
  %v1880 = load i64, ptr %slot324, align 8
  %cmp1881 = icmp ne i64 %v1880, 0
  %cv1882 = zext i1 %cmp1881 to i32
  store i32 %cv1882, ptr %slot325, align 8
  %v1883 = load i32, ptr %slot325, align 8
  %cv1884 = zext i32 %v1883 to i64
  %cond1885 = icmp ne i64 %cv1884, 0
  br i1 %cond1885, label %bb_rcgclear401, label %bb_rcgcounted401
bb_rcgcounted401:
  %v1886 = load i64, ptr %slot320, align 8
  %op1887 = sub i64 %v1886, 24
  store i64 %op1887, ptr %slot326, align 8
  %v1888 = load i64, ptr %slot320, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %rgep1890 = getelementptr i8, ptr %p1889, i64 -24
  %ld1891 = load i64, ptr %rgep1890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1891, ptr %slot327, align 8
  %v1892 = load i64, ptr %slot327, align 8
  %op1893 = sub i64 %v1892, 1
  store i64 %op1893, ptr %slot328, align 8
  %v1894 = load i64, ptr %slot328, align 8
  %cmp1895 = icmp eq i64 %v1894, 0
  %cv1896 = zext i1 %cmp1895 to i32
  store i32 %cv1896, ptr %slot329, align 8
  %v1897 = load i32, ptr %slot329, align 8
  %cv1898 = zext i32 %v1897 to i64
  %cond1899 = icmp ne i64 %cv1898, 0
  br i1 %cond1899, label %bb_rcglast401, label %bb_rcgdec401
bb_rcglast401:
  %v1900 = load i64, ptr %slot320, align 8
  %op1901 = sub i64 %v1900, 32
  store i64 %op1901, ptr %slot330, align 8
  %v1902 = load i64, ptr %slot320, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %rgep1904 = getelementptr i8, ptr %p1903, i64 -32
  %ld1905 = load i64, ptr %rgep1904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1905, ptr %slot331, align 8
  %v1906 = load i64, ptr %slot331, align 8
  %cmp1907 = icmp ne i64 %v1906, 0
  %cv1908 = zext i1 %cmp1907 to i32
  store i32 %cv1908, ptr %slot332, align 8
  %v1909 = load i32, ptr %slot332, align 8
  %cv1910 = zext i32 %v1909 to i64
  %cond1911 = icmp ne i64 %cv1910, 0
  br i1 %cond1911, label %bb_rcgdec401, label %bb_rcgslow401
bb_rcgslow401:
  %v1912 = load i64, ptr %slot319, align 8
  %v1913 = load i64, ptr %slot316, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1912, i64 %v1913) nomerge, !dbg !126
  br label %bb_rcgdone401
bb_rcgdec401:
  %v1914 = load i64, ptr %slot328, align 8
  %v1915 = load i64, ptr %slot320, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  %rgep1917 = getelementptr i8, ptr %p1916, i64 -24
  store i64 %v1914, ptr %rgep1917, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear401
bb_rcgclear401:
  %v1918 = load i64, ptr %slot316, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  store i64 0, ptr %p1919, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone401
bb_rcgdone401:
  br label %bb_rcslotdone385
bb_rcslotowner385:
  %v1920 = load i64, ptr %slot32, align 8
  store i64 %v1920, ptr %slot333, align 8
  %v1921 = load i64, ptr %slot316, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  %ld1923 = load i64, ptr %p1922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1923, ptr %slot334, align 8
  %v1924 = load i64, ptr %slot334, align 8
  %cmp1925 = icmp ne i64 %v1924, 0
  %cv1926 = zext i1 %cmp1925 to i32
  store i32 %cv1926, ptr %slot335, align 8
  %v1927 = load i32, ptr %slot335, align 8
  %cv1928 = zext i32 %v1927 to i64
  %cond1929 = icmp ne i64 %cv1928, 0
  br i1 %cond1929, label %bb_rcgnn416, label %bb_rcgdone416
bb_rcgnn416:
  %v1930 = load i64, ptr %slot334, align 8
  %op1931 = sub i64 %v1930, 16
  store i64 %op1931, ptr %slot336, align 8
  %v1932 = load i64, ptr %slot334, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %rgep1934 = getelementptr i8, ptr %p1933, i64 -16
  %ld1935 = load i64, ptr %rgep1934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1935, ptr %slot337, align 8
  %v1936 = load i64, ptr %slot337, align 8
  %op1937 = and i64 %v1936, 4611686018427387906
  store i64 %op1937, ptr %slot338, align 8
  %v1938 = load i64, ptr %slot338, align 8
  %cmp1939 = icmp ne i64 %v1938, 0
  %cv1940 = zext i1 %cmp1939 to i32
  store i32 %cv1940, ptr %slot339, align 8
  %v1941 = load i32, ptr %slot339, align 8
  %cv1942 = zext i32 %v1941 to i64
  %cond1943 = icmp ne i64 %cv1942, 0
  br i1 %cond1943, label %bb_rcgclear416, label %bb_rcgcounted416
bb_rcgcounted416:
  %v1944 = load i64, ptr %slot334, align 8
  %op1945 = sub i64 %v1944, 32
  store i64 %op1945, ptr %slot340, align 8
  %v1946 = load i64, ptr %slot334, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  %rgep1948 = getelementptr i8, ptr %p1947, i64 -32
  %ld1949 = load i64, ptr %rgep1948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1949, ptr %slot341, align 8
  %v1950 = load i64, ptr %slot341, align 8
  %op1951 = sub i64 %v1950, 1
  store i64 %op1951, ptr %slot342, align 8
  %v1952 = load i64, ptr %slot342, align 8
  %cmp1953 = icmp eq i64 %v1952, 0
  %cv1954 = zext i1 %cmp1953 to i32
  store i32 %cv1954, ptr %slot343, align 8
  %v1955 = load i32, ptr %slot343, align 8
  %cv1956 = zext i32 %v1955 to i64
  %cond1957 = icmp ne i64 %cv1956, 0
  br i1 %cond1957, label %bb_rcglast416, label %bb_rcgdec416
bb_rcglast416:
  %v1958 = load i64, ptr %slot334, align 8
  %op1959 = sub i64 %v1958, 24
  store i64 %op1959, ptr %slot344, align 8
  %v1960 = load i64, ptr %slot334, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %rgep1962 = getelementptr i8, ptr %p1961, i64 -24
  %ld1963 = load i64, ptr %rgep1962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1963, ptr %slot345, align 8
  %v1964 = load i64, ptr %slot345, align 8
  %cmp1965 = icmp ne i64 %v1964, 0
  %cv1966 = zext i1 %cmp1965 to i32
  store i32 %cv1966, ptr %slot346, align 8
  %v1967 = load i32, ptr %slot346, align 8
  %cv1968 = zext i32 %v1967 to i64
  %cond1969 = icmp ne i64 %cv1968, 0
  br i1 %cond1969, label %bb_rcgdec416, label %bb_rcgslow416
bb_rcgslow416:
  %v1970 = load i64, ptr %slot333, align 8
  %v1971 = load i64, ptr %slot316, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1970, i64 %v1971) nomerge, !dbg !126
  br label %bb_rcgdone416
bb_rcgdec416:
  %v1972 = load i64, ptr %slot342, align 8
  %v1973 = load i64, ptr %slot334, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  %rgep1975 = getelementptr i8, ptr %p1974, i64 -32
  store i64 %v1972, ptr %rgep1975, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear416
bb_rcgclear416:
  %v1976 = load i64, ptr %slot316, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  store i64 0, ptr %p1977, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone416
bb_rcgdone416:
  br label %bb_rcslotdone385
bb_rcslotdone385:
  %v1978 = load i64, ptr %slot25, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  %ld1980 = load i64, ptr %p1979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1980, ptr %slot347, align 8
  %v1981 = load i64, ptr %slot347, align 8
  %v1982 = load i64, ptr %slot23, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i64 %v1981, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot19, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i64, ptr %p1985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1986, ptr %slot348, align 8
  %v1987 = load i64, ptr %slot348, align 8
  %v1988 = load i64, ptr %slot25, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  store i64 %v1987, ptr %p1989, align 8, !alias.scope !3, !noalias !4
  %v1990 = load i64, ptr %slot22, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  %ld1992 = load i64, ptr %p1991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1992, ptr %slot349, align 8
  %v1993 = load i64, ptr %slot349, align 8
  %v1994 = load i64, ptr %slot26, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 %v1993, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot23, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot350, align 8
  %v1999 = load i64, ptr %slot350, align 8
  %v2000 = load i64, ptr %slot27, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i64 %v1999, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot25, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i64, ptr %p2003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2004, ptr %slot351, align 8
  %v2005 = load i64, ptr %slot26, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %ld2007 = load i64, ptr %p2006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2007, ptr %slot352, align 8
  %v2008 = load i64, ptr %slot27, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i64, ptr %p2009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2010, ptr %slot353, align 8
  %v2011 = load i64, ptr %slot1, align 8
  %v2012 = load i64, ptr %slot351, align 8
  %v2013 = load i64, ptr %slot352, align 8
  %v2014 = load i64, ptr %slot353, align 8
  %call2015 = call i64 @myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb(i64 %v2011, i64 %v2012, i64 %v2013, i64 %v2014) nomerge, !dbg !128
  store i64 %call2015, ptr %slot354, align 8
  %v2016 = load i64, ptr %slot354, align 8
  %v2017 = load i64, ptr %slot25, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i64 %v2016, ptr %p2018, align 8, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot8, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %ld2021 = load i32, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2021, ptr %slot355, align 8
  %v2022 = load i32, ptr %slot355, align 8
  %cv2023 = zext i32 %v2022 to i64
  %cond2024 = icmp ne i64 %cv2023, 0
  br i1 %cond2024, label %bb_rcslotdrop430, label %bb_rcslotdone430
bb_rcslotdrop430:
  %v2025 = load i64, ptr %slot8, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  store i32 0, ptr %p2026, align 4, !alias.scope !3, !noalias !4
  %v2027 = load i64, ptr %slot14, align 8
  store i64 %v2027, ptr %slot356, align 8
  %v2028 = load i64, ptr %slot9, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %ld2030 = load i32, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2030, ptr %slot357, align 8
  %v2031 = load i32, ptr %slot357, align 8
  %op2032 = and i32 %v2031, 28
  store i32 %op2032, ptr %slot358, align 8
  %v2033 = load i32, ptr %slot358, align 8
  %cv2034 = zext i32 %v2033 to i64
  %cond2035 = icmp ne i64 %cv2034, 0
  br i1 %cond2035, label %bb_rcslotrole430, label %bb_rcslotowner430
bb_rcslotrole430:
  %v2036 = load i64, ptr %slot32, align 8
  store i64 %v2036, ptr %slot359, align 8
  %v2037 = load i64, ptr %slot359, align 8
  %v2038 = load i64, ptr %slot356, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2037, i64 %v2038) nomerge, !dbg !128
  br label %bb_rcslotdone430
bb_rcslotowner430:
  %v2039 = load i64, ptr %slot32, align 8
  store i64 %v2039, ptr %slot360, align 8
  %v2040 = load i64, ptr %slot360, align 8
  %v2041 = load i64, ptr %slot356, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2040, i64 %v2041) nomerge, !dbg !128
  br label %bb_rcslotdone430
bb_rcslotdone430:
  %v2042 = load i64, ptr %slot10, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %ld2044 = load i32, ptr %p2043, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2044, ptr %slot361, align 8
  %v2045 = load i32, ptr %slot361, align 8
  %cv2046 = zext i32 %v2045 to i64
  %cond2047 = icmp ne i64 %cv2046, 0
  br i1 %cond2047, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v2048 = load i64, ptr %slot10, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i32 0, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  %v2050 = load i64, ptr %slot15, align 8
  store i64 %v2050, ptr %slot362, align 8
  %v2051 = load i64, ptr %slot11, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i32, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2053, ptr %slot363, align 8
  %v2054 = load i32, ptr %slot363, align 8
  %op2055 = and i32 %v2054, 28
  store i32 %op2055, ptr %slot364, align 8
  %v2056 = load i32, ptr %slot364, align 8
  %cv2057 = zext i32 %v2056 to i64
  %cond2058 = icmp ne i64 %cv2057, 0
  br i1 %cond2058, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v2059 = load i64, ptr %slot32, align 8
  store i64 %v2059, ptr %slot365, align 8
  %v2060 = load i64, ptr %slot362, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %ld2062 = load i64, ptr %p2061, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2062, ptr %slot366, align 8
  %v2063 = load i64, ptr %slot366, align 8
  %cmp2064 = icmp ne i64 %v2063, 0
  %cv2065 = zext i1 %cmp2064 to i32
  store i32 %cv2065, ptr %slot367, align 8
  %v2066 = load i32, ptr %slot367, align 8
  %cv2067 = zext i32 %v2066 to i64
  %cond2068 = icmp ne i64 %cv2067, 0
  br i1 %cond2068, label %bb_rcgnn455, label %bb_rcgdone455
bb_rcgnn455:
  %v2069 = load i64, ptr %slot366, align 8
  %op2070 = sub i64 %v2069, 16
  store i64 %op2070, ptr %slot368, align 8
  %v2071 = load i64, ptr %slot366, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %rgep2073 = getelementptr i8, ptr %p2072, i64 -16
  %ld2074 = load i64, ptr %rgep2073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2074, ptr %slot369, align 8
  %v2075 = load i64, ptr %slot369, align 8
  %op2076 = and i64 %v2075, 4611686018427387906
  store i64 %op2076, ptr %slot370, align 8
  %v2077 = load i64, ptr %slot370, align 8
  %cmp2078 = icmp ne i64 %v2077, 0
  %cv2079 = zext i1 %cmp2078 to i32
  store i32 %cv2079, ptr %slot371, align 8
  %v2080 = load i32, ptr %slot371, align 8
  %cv2081 = zext i32 %v2080 to i64
  %cond2082 = icmp ne i64 %cv2081, 0
  br i1 %cond2082, label %bb_rcgclear455, label %bb_rcgcounted455
bb_rcgcounted455:
  %v2083 = load i64, ptr %slot366, align 8
  %op2084 = sub i64 %v2083, 24
  store i64 %op2084, ptr %slot372, align 8
  %v2085 = load i64, ptr %slot366, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %rgep2087 = getelementptr i8, ptr %p2086, i64 -24
  %ld2088 = load i64, ptr %rgep2087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2088, ptr %slot373, align 8
  %v2089 = load i64, ptr %slot373, align 8
  %op2090 = sub i64 %v2089, 1
  store i64 %op2090, ptr %slot374, align 8
  %v2091 = load i64, ptr %slot374, align 8
  %cmp2092 = icmp eq i64 %v2091, 0
  %cv2093 = zext i1 %cmp2092 to i32
  store i32 %cv2093, ptr %slot375, align 8
  %v2094 = load i32, ptr %slot375, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcglast455, label %bb_rcgdec455
bb_rcglast455:
  %v2097 = load i64, ptr %slot366, align 8
  %op2098 = sub i64 %v2097, 32
  store i64 %op2098, ptr %slot376, align 8
  %v2099 = load i64, ptr %slot366, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %rgep2101 = getelementptr i8, ptr %p2100, i64 -32
  %ld2102 = load i64, ptr %rgep2101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2102, ptr %slot377, align 8
  %v2103 = load i64, ptr %slot377, align 8
  %cmp2104 = icmp ne i64 %v2103, 0
  %cv2105 = zext i1 %cmp2104 to i32
  store i32 %cv2105, ptr %slot378, align 8
  %v2106 = load i32, ptr %slot378, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_rcgdec455, label %bb_rcgslow455
bb_rcgslow455:
  %v2109 = load i64, ptr %slot365, align 8
  %v2110 = load i64, ptr %slot362, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2109, i64 %v2110) nomerge, !dbg !128
  br label %bb_rcgdone455
bb_rcgdec455:
  %v2111 = load i64, ptr %slot374, align 8
  %v2112 = load i64, ptr %slot366, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  %rgep2114 = getelementptr i8, ptr %p2113, i64 -24
  store i64 %v2111, ptr %rgep2114, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear455
bb_rcgclear455:
  %v2115 = load i64, ptr %slot362, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 0, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone455
bb_rcgdone455:
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v2117 = load i64, ptr %slot32, align 8
  store i64 %v2117, ptr %slot379, align 8
  %v2118 = load i64, ptr %slot362, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %ld2120 = load i64, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2120, ptr %slot380, align 8
  %v2121 = load i64, ptr %slot380, align 8
  %cmp2122 = icmp ne i64 %v2121, 0
  %cv2123 = zext i1 %cmp2122 to i32
  store i32 %cv2123, ptr %slot381, align 8
  %v2124 = load i32, ptr %slot381, align 8
  %cv2125 = zext i32 %v2124 to i64
  %cond2126 = icmp ne i64 %cv2125, 0
  br i1 %cond2126, label %bb_rcgnn470, label %bb_rcgdone470
bb_rcgnn470:
  %v2127 = load i64, ptr %slot380, align 8
  %op2128 = sub i64 %v2127, 16
  store i64 %op2128, ptr %slot382, align 8
  %v2129 = load i64, ptr %slot380, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %rgep2131 = getelementptr i8, ptr %p2130, i64 -16
  %ld2132 = load i64, ptr %rgep2131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2132, ptr %slot383, align 8
  %v2133 = load i64, ptr %slot383, align 8
  %op2134 = and i64 %v2133, 4611686018427387906
  store i64 %op2134, ptr %slot384, align 8
  %v2135 = load i64, ptr %slot384, align 8
  %cmp2136 = icmp ne i64 %v2135, 0
  %cv2137 = zext i1 %cmp2136 to i32
  store i32 %cv2137, ptr %slot385, align 8
  %v2138 = load i32, ptr %slot385, align 8
  %cv2139 = zext i32 %v2138 to i64
  %cond2140 = icmp ne i64 %cv2139, 0
  br i1 %cond2140, label %bb_rcgclear470, label %bb_rcgcounted470
bb_rcgcounted470:
  %v2141 = load i64, ptr %slot380, align 8
  %op2142 = sub i64 %v2141, 32
  store i64 %op2142, ptr %slot386, align 8
  %v2143 = load i64, ptr %slot380, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  %rgep2145 = getelementptr i8, ptr %p2144, i64 -32
  %ld2146 = load i64, ptr %rgep2145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2146, ptr %slot387, align 8
  %v2147 = load i64, ptr %slot387, align 8
  %op2148 = sub i64 %v2147, 1
  store i64 %op2148, ptr %slot388, align 8
  %v2149 = load i64, ptr %slot388, align 8
  %cmp2150 = icmp eq i64 %v2149, 0
  %cv2151 = zext i1 %cmp2150 to i32
  store i32 %cv2151, ptr %slot389, align 8
  %v2152 = load i32, ptr %slot389, align 8
  %cv2153 = zext i32 %v2152 to i64
  %cond2154 = icmp ne i64 %cv2153, 0
  br i1 %cond2154, label %bb_rcglast470, label %bb_rcgdec470
bb_rcglast470:
  %v2155 = load i64, ptr %slot380, align 8
  %op2156 = sub i64 %v2155, 24
  store i64 %op2156, ptr %slot390, align 8
  %v2157 = load i64, ptr %slot380, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  %rgep2159 = getelementptr i8, ptr %p2158, i64 -24
  %ld2160 = load i64, ptr %rgep2159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2160, ptr %slot391, align 8
  %v2161 = load i64, ptr %slot391, align 8
  %cmp2162 = icmp ne i64 %v2161, 0
  %cv2163 = zext i1 %cmp2162 to i32
  store i32 %cv2163, ptr %slot392, align 8
  %v2164 = load i32, ptr %slot392, align 8
  %cv2165 = zext i32 %v2164 to i64
  %cond2166 = icmp ne i64 %cv2165, 0
  br i1 %cond2166, label %bb_rcgdec470, label %bb_rcgslow470
bb_rcgslow470:
  %v2167 = load i64, ptr %slot379, align 8
  %v2168 = load i64, ptr %slot362, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2167, i64 %v2168) nomerge, !dbg !128
  br label %bb_rcgdone470
bb_rcgdec470:
  %v2169 = load i64, ptr %slot388, align 8
  %v2170 = load i64, ptr %slot380, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %rgep2172 = getelementptr i8, ptr %p2171, i64 -32
  store i64 %v2169, ptr %rgep2172, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear470
bb_rcgclear470:
  %v2173 = load i64, ptr %slot362, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  store i64 0, ptr %p2174, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone470
bb_rcgdone470:
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v2175 = load i64, ptr %slot25, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  %ld2177 = load i64, ptr %p2176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2177, ptr %slot393, align 8
  %v2178 = load i64, ptr %slot393, align 8
  %v2179 = load i64, ptr %slot24, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  store i64 %v2178, ptr %p2180, align 8, !alias.scope !3, !noalias !4
  %v2181 = load i64, ptr %slot24, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %ld2183 = load i64, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2183, ptr %slot394, align 8
  %v2184 = load i64, ptr %slot394, align 8
  %v2185 = load i64, ptr %slot25, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i64 %v2184, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot26, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i64 18446744073709551615, ptr %p2188, align 8, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot26, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i64, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2191, ptr %slot395, align 8
  %v2192 = load i64, ptr %slot25, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i64, ptr %p2193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2194, ptr %slot396, align 8
  %v2195 = load i64, ptr %slot396, align 8
  %v2196 = load i64, ptr %slot395, align 8
  %cmp2197 = icmp ne i64 %v2195, %v2196
  %cv2198 = zext i1 %cmp2197 to i64
  store i64 %cv2198, ptr %slot397, align 8
  %v2199 = load i64, ptr %slot397, align 8
  %v2200 = load i64, ptr %slot25, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i64 %v2199, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot25, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i64, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2204, ptr %slot398, align 8
  %v2205 = load i64, ptr %slot398, align 8
  %cond2206 = icmp ne i64 %v2205, 0
  br i1 %cond2206, label %bb_next480, label %bb_i24
bb_next480:
  %v2207 = load i64, ptr %slot24, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %ld2209 = load i64, ptr %p2208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2209, ptr %slot399, align 8
  %v2210 = load i64, ptr %slot399, align 8
  %v2211 = load i64, ptr %slot25, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  store i64 %v2210, ptr %p2212, align 8, !alias.scope !3, !noalias !4
  %v2213 = load i64, ptr %slot25, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i64, ptr %p2214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2215, ptr %slot400, align 8
  %v2216 = load i64, ptr %slot8, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %ld2218 = load i32, ptr %p2217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2218, ptr %slot401, align 8
  %v2219 = load i32, ptr %slot401, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcslotdrop484, label %bb_rcslotdone484
bb_rcslotdrop484:
  %v2222 = load i64, ptr %slot8, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i32 0, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone484
bb_rcslotdone484:
  %v2224 = load i64, ptr %slot6, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i32, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2226, ptr %slot402, align 8
  %v2227 = load i32, ptr %slot402, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcslotdrop487, label %bb_rcslotdone487
bb_rcslotdrop487:
  %v2230 = load i64, ptr %slot6, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  store i32 0, ptr %p2231, align 4, !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot22, align 8
  store i64 %v2232, ptr %slot403, align 8
  %v2233 = load i64, ptr %slot7, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i32, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2235, ptr %slot404, align 8
  %v2236 = load i32, ptr %slot404, align 8
  %op2237 = and i32 %v2236, 28
  store i32 %op2237, ptr %slot405, align 8
  %v2238 = load i32, ptr %slot405, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotrole487, label %bb_rcslotowner487
bb_rcslotrole487:
  %v2241 = load i64, ptr %slot32, align 8
  store i64 %v2241, ptr %slot406, align 8
  %v2242 = load i64, ptr %slot403, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %ld2244 = load i64, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2244, ptr %slot407, align 8
  %v2245 = load i64, ptr %slot407, align 8
  %cmp2246 = icmp ne i64 %v2245, 0
  %cv2247 = zext i1 %cmp2246 to i32
  store i32 %cv2247, ptr %slot408, align 8
  %v2248 = load i32, ptr %slot408, align 8
  %cv2249 = zext i32 %v2248 to i64
  %cond2250 = icmp ne i64 %cv2249, 0
  br i1 %cond2250, label %bb_rcgnn503, label %bb_rcgdone503
bb_rcgnn503:
  %v2251 = load i64, ptr %slot407, align 8
  %op2252 = sub i64 %v2251, 16
  store i64 %op2252, ptr %slot409, align 8
  %v2253 = load i64, ptr %slot407, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %rgep2255 = getelementptr i8, ptr %p2254, i64 -16
  %ld2256 = load i64, ptr %rgep2255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2256, ptr %slot410, align 8
  %v2257 = load i64, ptr %slot410, align 8
  %op2258 = and i64 %v2257, 4611686018427387906
  store i64 %op2258, ptr %slot411, align 8
  %v2259 = load i64, ptr %slot411, align 8
  %cmp2260 = icmp ne i64 %v2259, 0
  %cv2261 = zext i1 %cmp2260 to i32
  store i32 %cv2261, ptr %slot412, align 8
  %v2262 = load i32, ptr %slot412, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcgclear503, label %bb_rcgcounted503
bb_rcgcounted503:
  %v2265 = load i64, ptr %slot407, align 8
  %op2266 = sub i64 %v2265, 24
  store i64 %op2266, ptr %slot413, align 8
  %v2267 = load i64, ptr %slot407, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %rgep2269 = getelementptr i8, ptr %p2268, i64 -24
  %ld2270 = load i64, ptr %rgep2269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2270, ptr %slot414, align 8
  %v2271 = load i64, ptr %slot414, align 8
  %op2272 = sub i64 %v2271, 1
  store i64 %op2272, ptr %slot415, align 8
  %v2273 = load i64, ptr %slot415, align 8
  %cmp2274 = icmp eq i64 %v2273, 0
  %cv2275 = zext i1 %cmp2274 to i32
  store i32 %cv2275, ptr %slot416, align 8
  %v2276 = load i32, ptr %slot416, align 8
  %cv2277 = zext i32 %v2276 to i64
  %cond2278 = icmp ne i64 %cv2277, 0
  br i1 %cond2278, label %bb_rcglast503, label %bb_rcgdec503
bb_rcglast503:
  %v2279 = load i64, ptr %slot407, align 8
  %op2280 = sub i64 %v2279, 32
  store i64 %op2280, ptr %slot417, align 8
  %v2281 = load i64, ptr %slot407, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %rgep2283 = getelementptr i8, ptr %p2282, i64 -32
  %ld2284 = load i64, ptr %rgep2283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2284, ptr %slot418, align 8
  %v2285 = load i64, ptr %slot418, align 8
  %cmp2286 = icmp ne i64 %v2285, 0
  %cv2287 = zext i1 %cmp2286 to i32
  store i32 %cv2287, ptr %slot419, align 8
  %v2288 = load i32, ptr %slot419, align 8
  %cv2289 = zext i32 %v2288 to i64
  %cond2290 = icmp ne i64 %cv2289, 0
  br i1 %cond2290, label %bb_rcgdec503, label %bb_rcgslow503
bb_rcgslow503:
  %v2291 = load i64, ptr %slot406, align 8
  %v2292 = load i64, ptr %slot403, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2291, i64 %v2292) nomerge, !dbg !130
  br label %bb_rcgdone503
bb_rcgdec503:
  %v2293 = load i64, ptr %slot415, align 8
  %v2294 = load i64, ptr %slot407, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %rgep2296 = getelementptr i8, ptr %p2295, i64 -24
  store i64 %v2293, ptr %rgep2296, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear503
bb_rcgclear503:
  %v2297 = load i64, ptr %slot403, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 0, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone503
bb_rcgdone503:
  br label %bb_rcslotdone487
bb_rcslotowner487:
  %v2299 = load i64, ptr %slot32, align 8
  store i64 %v2299, ptr %slot420, align 8
  %v2300 = load i64, ptr %slot403, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %ld2302 = load i64, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2302, ptr %slot421, align 8
  %v2303 = load i64, ptr %slot421, align 8
  %cmp2304 = icmp ne i64 %v2303, 0
  %cv2305 = zext i1 %cmp2304 to i32
  store i32 %cv2305, ptr %slot422, align 8
  %v2306 = load i32, ptr %slot422, align 8
  %cv2307 = zext i32 %v2306 to i64
  %cond2308 = icmp ne i64 %cv2307, 0
  br i1 %cond2308, label %bb_rcgnn518, label %bb_rcgdone518
bb_rcgnn518:
  %v2309 = load i64, ptr %slot421, align 8
  %op2310 = sub i64 %v2309, 16
  store i64 %op2310, ptr %slot423, align 8
  %v2311 = load i64, ptr %slot421, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %rgep2313 = getelementptr i8, ptr %p2312, i64 -16
  %ld2314 = load i64, ptr %rgep2313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2314, ptr %slot424, align 8
  %v2315 = load i64, ptr %slot424, align 8
  %op2316 = and i64 %v2315, 4611686018427387906
  store i64 %op2316, ptr %slot425, align 8
  %v2317 = load i64, ptr %slot425, align 8
  %cmp2318 = icmp ne i64 %v2317, 0
  %cv2319 = zext i1 %cmp2318 to i32
  store i32 %cv2319, ptr %slot426, align 8
  %v2320 = load i32, ptr %slot426, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcgclear518, label %bb_rcgcounted518
bb_rcgcounted518:
  %v2323 = load i64, ptr %slot421, align 8
  %op2324 = sub i64 %v2323, 32
  store i64 %op2324, ptr %slot427, align 8
  %v2325 = load i64, ptr %slot421, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %rgep2327 = getelementptr i8, ptr %p2326, i64 -32
  %ld2328 = load i64, ptr %rgep2327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2328, ptr %slot428, align 8
  %v2329 = load i64, ptr %slot428, align 8
  %op2330 = sub i64 %v2329, 1
  store i64 %op2330, ptr %slot429, align 8
  %v2331 = load i64, ptr %slot429, align 8
  %cmp2332 = icmp eq i64 %v2331, 0
  %cv2333 = zext i1 %cmp2332 to i32
  store i32 %cv2333, ptr %slot430, align 8
  %v2334 = load i32, ptr %slot430, align 8
  %cv2335 = zext i32 %v2334 to i64
  %cond2336 = icmp ne i64 %cv2335, 0
  br i1 %cond2336, label %bb_rcglast518, label %bb_rcgdec518
bb_rcglast518:
  %v2337 = load i64, ptr %slot421, align 8
  %op2338 = sub i64 %v2337, 24
  store i64 %op2338, ptr %slot431, align 8
  %v2339 = load i64, ptr %slot421, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %rgep2341 = getelementptr i8, ptr %p2340, i64 -24
  %ld2342 = load i64, ptr %rgep2341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2342, ptr %slot432, align 8
  %v2343 = load i64, ptr %slot432, align 8
  %cmp2344 = icmp ne i64 %v2343, 0
  %cv2345 = zext i1 %cmp2344 to i32
  store i32 %cv2345, ptr %slot433, align 8
  %v2346 = load i32, ptr %slot433, align 8
  %cv2347 = zext i32 %v2346 to i64
  %cond2348 = icmp ne i64 %cv2347, 0
  br i1 %cond2348, label %bb_rcgdec518, label %bb_rcgslow518
bb_rcgslow518:
  %v2349 = load i64, ptr %slot420, align 8
  %v2350 = load i64, ptr %slot403, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2349, i64 %v2350) nomerge, !dbg !130
  br label %bb_rcgdone518
bb_rcgdec518:
  %v2351 = load i64, ptr %slot429, align 8
  %v2352 = load i64, ptr %slot421, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %rgep2354 = getelementptr i8, ptr %p2353, i64 -32
  store i64 %v2351, ptr %rgep2354, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear518
bb_rcgclear518:
  %v2355 = load i64, ptr %slot403, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i64 0, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone518
bb_rcgdone518:
  br label %bb_rcslotdone487
bb_rcslotdone487:
  %v2357 = load i64, ptr %slot400, align 8
  ret i64 %v2357
bb_i24:
  %v2358 = load i64, ptr %slot19, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %ld2360 = load i64, ptr %p2359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2360, ptr %slot434, align 8
  %v2361 = load i64, ptr %slot434, align 8
  %v2362 = load i64, ptr %slot25, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  store i64 %v2361, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  %v2364 = load i64, ptr %slot22, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %ld2366 = load i64, ptr %p2365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2366, ptr %slot435, align 8
  %v2367 = load i64, ptr %slot435, align 8
  %v2368 = load i64, ptr %slot26, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  store i64 %v2367, ptr %p2369, align 8, !alias.scope !3, !noalias !4
  %v2370 = load i64, ptr %slot23, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %ld2372 = load i64, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2372, ptr %slot436, align 8
  %v2373 = load i64, ptr %slot436, align 8
  %v2374 = load i64, ptr %slot27, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i64 %v2373, ptr %p2375, align 8, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot25, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  %ld2378 = load i64, ptr %p2377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2378, ptr %slot437, align 8
  %v2379 = load i64, ptr %slot26, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  %ld2381 = load i64, ptr %p2380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2381, ptr %slot438, align 8
  %v2382 = load i64, ptr %slot27, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i64, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2384, ptr %slot439, align 8
  %v2385 = load i64, ptr %slot1, align 8
  %v2386 = load i64, ptr %slot437, align 8
  %v2387 = load i64, ptr %slot438, align 8
  %v2388 = load i64, ptr %slot439, align 8
  %call2389 = call i64 @myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016(i64 %v2385, i64 %v2386, i64 %v2387, i64 %v2388) nomerge, !dbg !132
  store i64 %call2389, ptr %slot440, align 8
  %v2390 = load i64, ptr %slot440, align 8
  %v2391 = load i64, ptr %slot25, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i64 %v2390, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  %v2393 = load i64, ptr %slot8, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i32, ptr %p2394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2395, ptr %slot441, align 8
  %v2396 = load i32, ptr %slot441, align 8
  %cv2397 = zext i32 %v2396 to i64
  %cond2398 = icmp ne i64 %cv2397, 0
  br i1 %cond2398, label %bb_rcslotdrop540, label %bb_rcslotdone540
bb_rcslotdrop540:
  %v2399 = load i64, ptr %slot8, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  store i32 0, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  %v2401 = load i64, ptr %slot14, align 8
  store i64 %v2401, ptr %slot442, align 8
  %v2402 = load i64, ptr %slot9, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  %ld2404 = load i32, ptr %p2403, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2404, ptr %slot443, align 8
  %v2405 = load i32, ptr %slot443, align 8
  %op2406 = and i32 %v2405, 28
  store i32 %op2406, ptr %slot444, align 8
  %v2407 = load i32, ptr %slot444, align 8
  %cv2408 = zext i32 %v2407 to i64
  %cond2409 = icmp ne i64 %cv2408, 0
  br i1 %cond2409, label %bb_rcslotrole540, label %bb_rcslotowner540
bb_rcslotrole540:
  %v2410 = load i64, ptr %slot32, align 8
  store i64 %v2410, ptr %slot445, align 8
  %v2411 = load i64, ptr %slot445, align 8
  %v2412 = load i64, ptr %slot442, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2411, i64 %v2412) nomerge, !dbg !132
  br label %bb_rcslotdone540
bb_rcslotowner540:
  %v2413 = load i64, ptr %slot32, align 8
  store i64 %v2413, ptr %slot446, align 8
  %v2414 = load i64, ptr %slot446, align 8
  %v2415 = load i64, ptr %slot442, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2414, i64 %v2415) nomerge, !dbg !132
  br label %bb_rcslotdone540
bb_rcslotdone540:
  %v2416 = load i64, ptr %slot10, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %ld2418 = load i32, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2418, ptr %slot447, align 8
  %v2419 = load i32, ptr %slot447, align 8
  %cv2420 = zext i32 %v2419 to i64
  %cond2421 = icmp ne i64 %cv2420, 0
  br i1 %cond2421, label %bb_rcslotdrop549, label %bb_rcslotdone549
bb_rcslotdrop549:
  %v2422 = load i64, ptr %slot10, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  store i32 0, ptr %p2423, align 4, !alias.scope !3, !noalias !4
  %v2424 = load i64, ptr %slot15, align 8
  store i64 %v2424, ptr %slot448, align 8
  %v2425 = load i64, ptr %slot11, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %ld2427 = load i32, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2427, ptr %slot449, align 8
  %v2428 = load i32, ptr %slot449, align 8
  %op2429 = and i32 %v2428, 28
  store i32 %op2429, ptr %slot450, align 8
  %v2430 = load i32, ptr %slot450, align 8
  %cv2431 = zext i32 %v2430 to i64
  %cond2432 = icmp ne i64 %cv2431, 0
  br i1 %cond2432, label %bb_rcslotrole549, label %bb_rcslotowner549
bb_rcslotrole549:
  %v2433 = load i64, ptr %slot32, align 8
  store i64 %v2433, ptr %slot451, align 8
  %v2434 = load i64, ptr %slot448, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %ld2436 = load i64, ptr %p2435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2436, ptr %slot452, align 8
  %v2437 = load i64, ptr %slot452, align 8
  %cmp2438 = icmp ne i64 %v2437, 0
  %cv2439 = zext i1 %cmp2438 to i32
  store i32 %cv2439, ptr %slot453, align 8
  %v2440 = load i32, ptr %slot453, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rcgnn565, label %bb_rcgdone565
bb_rcgnn565:
  %v2443 = load i64, ptr %slot452, align 8
  %op2444 = sub i64 %v2443, 16
  store i64 %op2444, ptr %slot454, align 8
  %v2445 = load i64, ptr %slot452, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  %rgep2447 = getelementptr i8, ptr %p2446, i64 -16
  %ld2448 = load i64, ptr %rgep2447, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2448, ptr %slot455, align 8
  %v2449 = load i64, ptr %slot455, align 8
  %op2450 = and i64 %v2449, 4611686018427387906
  store i64 %op2450, ptr %slot456, align 8
  %v2451 = load i64, ptr %slot456, align 8
  %cmp2452 = icmp ne i64 %v2451, 0
  %cv2453 = zext i1 %cmp2452 to i32
  store i32 %cv2453, ptr %slot457, align 8
  %v2454 = load i32, ptr %slot457, align 8
  %cv2455 = zext i32 %v2454 to i64
  %cond2456 = icmp ne i64 %cv2455, 0
  br i1 %cond2456, label %bb_rcgclear565, label %bb_rcgcounted565
bb_rcgcounted565:
  %v2457 = load i64, ptr %slot452, align 8
  %op2458 = sub i64 %v2457, 24
  store i64 %op2458, ptr %slot458, align 8
  %v2459 = load i64, ptr %slot452, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %rgep2461 = getelementptr i8, ptr %p2460, i64 -24
  %ld2462 = load i64, ptr %rgep2461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2462, ptr %slot459, align 8
  %v2463 = load i64, ptr %slot459, align 8
  %op2464 = sub i64 %v2463, 1
  store i64 %op2464, ptr %slot460, align 8
  %v2465 = load i64, ptr %slot460, align 8
  %cmp2466 = icmp eq i64 %v2465, 0
  %cv2467 = zext i1 %cmp2466 to i32
  store i32 %cv2467, ptr %slot461, align 8
  %v2468 = load i32, ptr %slot461, align 8
  %cv2469 = zext i32 %v2468 to i64
  %cond2470 = icmp ne i64 %cv2469, 0
  br i1 %cond2470, label %bb_rcglast565, label %bb_rcgdec565
bb_rcglast565:
  %v2471 = load i64, ptr %slot452, align 8
  %op2472 = sub i64 %v2471, 32
  store i64 %op2472, ptr %slot462, align 8
  %v2473 = load i64, ptr %slot452, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %rgep2475 = getelementptr i8, ptr %p2474, i64 -32
  %ld2476 = load i64, ptr %rgep2475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2476, ptr %slot463, align 8
  %v2477 = load i64, ptr %slot463, align 8
  %cmp2478 = icmp ne i64 %v2477, 0
  %cv2479 = zext i1 %cmp2478 to i32
  store i32 %cv2479, ptr %slot464, align 8
  %v2480 = load i32, ptr %slot464, align 8
  %cv2481 = zext i32 %v2480 to i64
  %cond2482 = icmp ne i64 %cv2481, 0
  br i1 %cond2482, label %bb_rcgdec565, label %bb_rcgslow565
bb_rcgslow565:
  %v2483 = load i64, ptr %slot451, align 8
  %v2484 = load i64, ptr %slot448, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2483, i64 %v2484) nomerge, !dbg !132
  br label %bb_rcgdone565
bb_rcgdec565:
  %v2485 = load i64, ptr %slot460, align 8
  %v2486 = load i64, ptr %slot452, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %rgep2488 = getelementptr i8, ptr %p2487, i64 -24
  store i64 %v2485, ptr %rgep2488, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear565
bb_rcgclear565:
  %v2489 = load i64, ptr %slot448, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  store i64 0, ptr %p2490, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone565
bb_rcgdone565:
  br label %bb_rcslotdone549
bb_rcslotowner549:
  %v2491 = load i64, ptr %slot32, align 8
  store i64 %v2491, ptr %slot465, align 8
  %v2492 = load i64, ptr %slot448, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %ld2494 = load i64, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2494, ptr %slot466, align 8
  %v2495 = load i64, ptr %slot466, align 8
  %cmp2496 = icmp ne i64 %v2495, 0
  %cv2497 = zext i1 %cmp2496 to i32
  store i32 %cv2497, ptr %slot467, align 8
  %v2498 = load i32, ptr %slot467, align 8
  %cv2499 = zext i32 %v2498 to i64
  %cond2500 = icmp ne i64 %cv2499, 0
  br i1 %cond2500, label %bb_rcgnn580, label %bb_rcgdone580
bb_rcgnn580:
  %v2501 = load i64, ptr %slot466, align 8
  %op2502 = sub i64 %v2501, 16
  store i64 %op2502, ptr %slot468, align 8
  %v2503 = load i64, ptr %slot466, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  %rgep2505 = getelementptr i8, ptr %p2504, i64 -16
  %ld2506 = load i64, ptr %rgep2505, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2506, ptr %slot469, align 8
  %v2507 = load i64, ptr %slot469, align 8
  %op2508 = and i64 %v2507, 4611686018427387906
  store i64 %op2508, ptr %slot470, align 8
  %v2509 = load i64, ptr %slot470, align 8
  %cmp2510 = icmp ne i64 %v2509, 0
  %cv2511 = zext i1 %cmp2510 to i32
  store i32 %cv2511, ptr %slot471, align 8
  %v2512 = load i32, ptr %slot471, align 8
  %cv2513 = zext i32 %v2512 to i64
  %cond2514 = icmp ne i64 %cv2513, 0
  br i1 %cond2514, label %bb_rcgclear580, label %bb_rcgcounted580
bb_rcgcounted580:
  %v2515 = load i64, ptr %slot466, align 8
  %op2516 = sub i64 %v2515, 32
  store i64 %op2516, ptr %slot472, align 8
  %v2517 = load i64, ptr %slot466, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  %rgep2519 = getelementptr i8, ptr %p2518, i64 -32
  %ld2520 = load i64, ptr %rgep2519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2520, ptr %slot473, align 8
  %v2521 = load i64, ptr %slot473, align 8
  %op2522 = sub i64 %v2521, 1
  store i64 %op2522, ptr %slot474, align 8
  %v2523 = load i64, ptr %slot474, align 8
  %cmp2524 = icmp eq i64 %v2523, 0
  %cv2525 = zext i1 %cmp2524 to i32
  store i32 %cv2525, ptr %slot475, align 8
  %v2526 = load i32, ptr %slot475, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcglast580, label %bb_rcgdec580
bb_rcglast580:
  %v2529 = load i64, ptr %slot466, align 8
  %op2530 = sub i64 %v2529, 24
  store i64 %op2530, ptr %slot476, align 8
  %v2531 = load i64, ptr %slot466, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %rgep2533 = getelementptr i8, ptr %p2532, i64 -24
  %ld2534 = load i64, ptr %rgep2533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2534, ptr %slot477, align 8
  %v2535 = load i64, ptr %slot477, align 8
  %cmp2536 = icmp ne i64 %v2535, 0
  %cv2537 = zext i1 %cmp2536 to i32
  store i32 %cv2537, ptr %slot478, align 8
  %v2538 = load i32, ptr %slot478, align 8
  %cv2539 = zext i32 %v2538 to i64
  %cond2540 = icmp ne i64 %cv2539, 0
  br i1 %cond2540, label %bb_rcgdec580, label %bb_rcgslow580
bb_rcgslow580:
  %v2541 = load i64, ptr %slot465, align 8
  %v2542 = load i64, ptr %slot448, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2541, i64 %v2542) nomerge, !dbg !132
  br label %bb_rcgdone580
bb_rcgdec580:
  %v2543 = load i64, ptr %slot474, align 8
  %v2544 = load i64, ptr %slot466, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  %rgep2546 = getelementptr i8, ptr %p2545, i64 -32
  store i64 %v2543, ptr %rgep2546, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear580
bb_rcgclear580:
  %v2547 = load i64, ptr %slot448, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i64 0, ptr %p2548, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone580
bb_rcgdone580:
  br label %bb_rcslotdone549
bb_rcslotdone549:
  %v2549 = load i64, ptr %slot25, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %ld2551 = load i64, ptr %p2550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2551, ptr %slot479, align 8
  %v2552 = load i64, ptr %slot8, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %ld2554 = load i32, ptr %p2553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2554, ptr %slot480, align 8
  %v2555 = load i32, ptr %slot480, align 8
  %cv2556 = zext i32 %v2555 to i64
  %cond2557 = icmp ne i64 %cv2556, 0
  br i1 %cond2557, label %bb_rcslotdrop587, label %bb_rcslotdone587
bb_rcslotdrop587:
  %v2558 = load i64, ptr %slot8, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i32 0, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone587
bb_rcslotdone587:
  %v2560 = load i64, ptr %slot6, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot481, align 8
  %v2563 = load i32, ptr %slot481, align 8
  %cv2564 = zext i32 %v2563 to i64
  %cond2565 = icmp ne i64 %cv2564, 0
  br i1 %cond2565, label %bb_rcslotdrop590, label %bb_rcslotdone590
bb_rcslotdrop590:
  %v2566 = load i64, ptr %slot6, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i32 0, ptr %p2567, align 4, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot22, align 8
  store i64 %v2568, ptr %slot482, align 8
  %v2569 = load i64, ptr %slot7, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  %ld2571 = load i32, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2571, ptr %slot483, align 8
  %v2572 = load i32, ptr %slot483, align 8
  %op2573 = and i32 %v2572, 28
  store i32 %op2573, ptr %slot484, align 8
  %v2574 = load i32, ptr %slot484, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcslotrole590, label %bb_rcslotowner590
bb_rcslotrole590:
  %v2577 = load i64, ptr %slot32, align 8
  store i64 %v2577, ptr %slot485, align 8
  %v2578 = load i64, ptr %slot482, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  %ld2580 = load i64, ptr %p2579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2580, ptr %slot486, align 8
  %v2581 = load i64, ptr %slot486, align 8
  %cmp2582 = icmp ne i64 %v2581, 0
  %cv2583 = zext i1 %cmp2582 to i32
  store i32 %cv2583, ptr %slot487, align 8
  %v2584 = load i32, ptr %slot487, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcgnn606, label %bb_rcgdone606
bb_rcgnn606:
  %v2587 = load i64, ptr %slot486, align 8
  %op2588 = sub i64 %v2587, 16
  store i64 %op2588, ptr %slot488, align 8
  %v2589 = load i64, ptr %slot486, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  %rgep2591 = getelementptr i8, ptr %p2590, i64 -16
  %ld2592 = load i64, ptr %rgep2591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2592, ptr %slot489, align 8
  %v2593 = load i64, ptr %slot489, align 8
  %op2594 = and i64 %v2593, 4611686018427387906
  store i64 %op2594, ptr %slot490, align 8
  %v2595 = load i64, ptr %slot490, align 8
  %cmp2596 = icmp ne i64 %v2595, 0
  %cv2597 = zext i1 %cmp2596 to i32
  store i32 %cv2597, ptr %slot491, align 8
  %v2598 = load i32, ptr %slot491, align 8
  %cv2599 = zext i32 %v2598 to i64
  %cond2600 = icmp ne i64 %cv2599, 0
  br i1 %cond2600, label %bb_rcgclear606, label %bb_rcgcounted606
bb_rcgcounted606:
  %v2601 = load i64, ptr %slot486, align 8
  %op2602 = sub i64 %v2601, 24
  store i64 %op2602, ptr %slot492, align 8
  %v2603 = load i64, ptr %slot486, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %rgep2605 = getelementptr i8, ptr %p2604, i64 -24
  %ld2606 = load i64, ptr %rgep2605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2606, ptr %slot493, align 8
  %v2607 = load i64, ptr %slot493, align 8
  %op2608 = sub i64 %v2607, 1
  store i64 %op2608, ptr %slot494, align 8
  %v2609 = load i64, ptr %slot494, align 8
  %cmp2610 = icmp eq i64 %v2609, 0
  %cv2611 = zext i1 %cmp2610 to i32
  store i32 %cv2611, ptr %slot495, align 8
  %v2612 = load i32, ptr %slot495, align 8
  %cv2613 = zext i32 %v2612 to i64
  %cond2614 = icmp ne i64 %cv2613, 0
  br i1 %cond2614, label %bb_rcglast606, label %bb_rcgdec606
bb_rcglast606:
  %v2615 = load i64, ptr %slot486, align 8
  %op2616 = sub i64 %v2615, 32
  store i64 %op2616, ptr %slot496, align 8
  %v2617 = load i64, ptr %slot486, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %rgep2619 = getelementptr i8, ptr %p2618, i64 -32
  %ld2620 = load i64, ptr %rgep2619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2620, ptr %slot497, align 8
  %v2621 = load i64, ptr %slot497, align 8
  %cmp2622 = icmp ne i64 %v2621, 0
  %cv2623 = zext i1 %cmp2622 to i32
  store i32 %cv2623, ptr %slot498, align 8
  %v2624 = load i32, ptr %slot498, align 8
  %cv2625 = zext i32 %v2624 to i64
  %cond2626 = icmp ne i64 %cv2625, 0
  br i1 %cond2626, label %bb_rcgdec606, label %bb_rcgslow606
bb_rcgslow606:
  %v2627 = load i64, ptr %slot485, align 8
  %v2628 = load i64, ptr %slot482, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2627, i64 %v2628) nomerge, !dbg !134
  br label %bb_rcgdone606
bb_rcgdec606:
  %v2629 = load i64, ptr %slot494, align 8
  %v2630 = load i64, ptr %slot486, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %rgep2632 = getelementptr i8, ptr %p2631, i64 -24
  store i64 %v2629, ptr %rgep2632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear606
bb_rcgclear606:
  %v2633 = load i64, ptr %slot482, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i64 0, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone606
bb_rcgdone606:
  br label %bb_rcslotdone590
bb_rcslotowner590:
  %v2635 = load i64, ptr %slot32, align 8
  store i64 %v2635, ptr %slot499, align 8
  %v2636 = load i64, ptr %slot482, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i64, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2638, ptr %slot500, align 8
  %v2639 = load i64, ptr %slot500, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot501, align 8
  %v2642 = load i32, ptr %slot501, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcgnn621, label %bb_rcgdone621
bb_rcgnn621:
  %v2645 = load i64, ptr %slot500, align 8
  %op2646 = sub i64 %v2645, 16
  store i64 %op2646, ptr %slot502, align 8
  %v2647 = load i64, ptr %slot500, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -16
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot503, align 8
  %v2651 = load i64, ptr %slot503, align 8
  %op2652 = and i64 %v2651, 4611686018427387906
  store i64 %op2652, ptr %slot504, align 8
  %v2653 = load i64, ptr %slot504, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot505, align 8
  %v2656 = load i32, ptr %slot505, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcgclear621, label %bb_rcgcounted621
bb_rcgcounted621:
  %v2659 = load i64, ptr %slot500, align 8
  %op2660 = sub i64 %v2659, 32
  store i64 %op2660, ptr %slot506, align 8
  %v2661 = load i64, ptr %slot500, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -32
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot507, align 8
  %v2665 = load i64, ptr %slot507, align 8
  %op2666 = sub i64 %v2665, 1
  store i64 %op2666, ptr %slot508, align 8
  %v2667 = load i64, ptr %slot508, align 8
  %cmp2668 = icmp eq i64 %v2667, 0
  %cv2669 = zext i1 %cmp2668 to i32
  store i32 %cv2669, ptr %slot509, align 8
  %v2670 = load i32, ptr %slot509, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcglast621, label %bb_rcgdec621
bb_rcglast621:
  %v2673 = load i64, ptr %slot500, align 8
  %op2674 = sub i64 %v2673, 24
  store i64 %op2674, ptr %slot510, align 8
  %v2675 = load i64, ptr %slot500, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -24
  %ld2678 = load i64, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2678, ptr %slot511, align 8
  %v2679 = load i64, ptr %slot511, align 8
  %cmp2680 = icmp ne i64 %v2679, 0
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot512, align 8
  %v2682 = load i32, ptr %slot512, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcgdec621, label %bb_rcgslow621
bb_rcgslow621:
  %v2685 = load i64, ptr %slot499, align 8
  %v2686 = load i64, ptr %slot482, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2685, i64 %v2686) nomerge, !dbg !134
  br label %bb_rcgdone621
bb_rcgdec621:
  %v2687 = load i64, ptr %slot508, align 8
  %v2688 = load i64, ptr %slot500, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %rgep2690 = getelementptr i8, ptr %p2689, i64 -32
  store i64 %v2687, ptr %rgep2690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear621
bb_rcgclear621:
  %v2691 = load i64, ptr %slot482, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i64 0, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone621
bb_rcgdone621:
  br label %bb_rcslotdone590
bb_rcslotdone590:
  %v2693 = load i64, ptr %slot479, align 8
  ret i64 %v2693
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb(i64, i64, i64, i64)
declare i64 @myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016(i64, i64, i64, i64)
declare { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64, i64, i64)
declare i64 @myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1(i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64, i64)
declare i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_loan(i64, i64, i64)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069", linkageName: "myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 12877783420051625486, i64 0, !"myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!124 = !DILocation(line: 10, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!126 = !DILocation(line: 12, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!130 = !DILocation(line: 24, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
