target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %callresult35 = alloca [40 x i8], align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v57 = load i64, ptr %slot1, align 8
  %op58 = add i64 %v57, 32
  store i64 %op58, ptr %slot4, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot5, align 8
  %mem61 = alloca i8, i64 8, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot6, align 8
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot7, align 8
  %mem65 = alloca i8, i64 8, align 8
  %ptr66 = ptrtoint ptr %mem65 to i64
  store i64 %ptr66, ptr %slot8, align 8
  %mem67 = alloca i8, i64 312, align 8
  %ptr68 = ptrtoint ptr %mem67 to i64
  store i64 %ptr68, ptr %slot9, align 8
  %mem69 = alloca i8, i64 312, align 8
  %ptr70 = ptrtoint ptr %mem69 to i64
  store i64 %ptr70, ptr %slot10, align 8
  %mem71 = alloca i8, i64 8, align 8
  %ptr72 = ptrtoint ptr %mem71 to i64
  store i64 %ptr72, ptr %slot11, align 8
  %mem73 = alloca i8, i64 8, align 8
  %ptr74 = ptrtoint ptr %mem73 to i64
  store i64 %ptr74, ptr %slot12, align 8
  %mem75 = alloca i8, i64 8, align 8
  %ptr76 = ptrtoint ptr %mem75 to i64
  store i64 %ptr76, ptr %slot13, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot14, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot15, align 8
  %v81 = load i64, ptr %slot1, align 8
  %op82 = add i64 %v81, 64
  store i64 %op82, ptr %slot16, align 8
  %v83 = load i64, ptr %slot16, align 8
  %p84 = inttoptr i64 %v83 to ptr
  %ld85 = load i64, ptr %p84, align 8, !alias.scope !4, !noalias !3
  store i64 %ld85, ptr %slot17, align 8
  %stack86 = call ptr @llvm.stacksave()
  %stackaddr87 = ptrtoint ptr %stack86 to i64
  %v88 = load i64, ptr %slot17, align 8
  %cmp89 = icmp ult i64 %stackaddr87, %v88
  %cv90 = zext i1 %cmp89 to i64
  store i64 %cv90, ptr %slot18, align 8
  %v91 = load i64, ptr %slot18, align 8
  %cond92 = icmp ne i64 %v91, 0
  br i1 %cond92, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v93 = load i64, ptr %slot1, align 8
  %p94 = inttoptr i64 %v93 to ptr
  call void @myl_qbe_fail_frame(ptr %p94) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v95 = load i64, ptr %slot2, align 8
  %v96 = load i64, ptr %slot11, align 8
  %p97 = inttoptr i64 %v96 to ptr
  store i64 %v95, ptr %p97, align 8, !alias.scope !3, !noalias !4
  %v98 = load i64, ptr %slot3, align 8
  %v99 = load i64, ptr %slot12, align 8
  %p100 = inttoptr i64 %v99 to ptr
  store i64 %v98, ptr %p100, align 8, !alias.scope !3, !noalias !4
  %v101 = load i64, ptr %slot1, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %call103 = call ptr @myl_qbe_heap(ptr %p102) nomerge, !dbg !112
  %calladdr104 = ptrtoint ptr %call103 to i64
  store i64 %calladdr104, ptr %slot19, align 8
  %v105 = load i64, ptr %slot5, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i32 0, ptr %p106, align 4, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot6, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i32 0, ptr %p108, align 4, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot7, align 8
  %p110 = inttoptr i64 %v109 to ptr
  store i32 0, ptr %p110, align 4, !alias.scope !3, !noalias !4
  %v111 = load i64, ptr %slot8, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i32 0, ptr %p112, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v113 = load i64, ptr %slot11, align 8
  %p114 = inttoptr i64 %v113 to ptr
  %ld115 = load i64, ptr %p114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld115, ptr %slot20, align 8
  %v116 = load i64, ptr %slot20, align 8
  %v117 = load i64, ptr %slot13, align 8
  %p118 = inttoptr i64 %v117 to ptr
  store i64 %v116, ptr %p118, align 8, !alias.scope !3, !noalias !4
  %v119 = load i64, ptr %slot12, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i64, ptr %p120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld121, ptr %slot21, align 8
  %v122 = load i64, ptr %slot21, align 8
  %v123 = load i64, ptr %slot14, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i64 %v122, ptr %p124, align 8, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot13, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld127, ptr %slot22, align 8
  %v128 = load i64, ptr %slot14, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot23, align 8
  %v131 = load i64, ptr %slot1, align 8
  %v132 = load i64, ptr %slot22, align 8
  %v133 = load i64, ptr %slot23, align 8
  %call134 = call i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %v131, i64 %v132, i64 %v133) nomerge, !dbg !114
  store i64 %call134, ptr %slot24, align 8
  %v135 = load i64, ptr %slot24, align 8
  %v136 = load i64, ptr %slot13, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot5, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i32, ptr %p139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld140, ptr %slot25, align 8
  %v141 = load i32, ptr %slot25, align 8
  %cv142 = zext i32 %v141 to i64
  %cond143 = icmp ne i64 %cv142, 0
  br i1 %cond143, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v144 = load i64, ptr %slot5, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i32 0, ptr %p145, align 4, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot9, align 8
  store i64 %v146, ptr %slot26, align 8
  %v147 = load i64, ptr %slot6, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i32, ptr %p148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld149, ptr %slot27, align 8
  %v150 = load i32, ptr %slot27, align 8
  %op151 = and i32 %v150, 28
  store i32 %op151, ptr %slot28, align 8
  %v152 = load i32, ptr %slot28, align 8
  %cv153 = zext i32 %v152 to i64
  %cond154 = icmp ne i64 %cv153, 0
  br i1 %cond154, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v155 = load i64, ptr %slot19, align 8
  store i64 %v155, ptr %slot29, align 8
  %v156 = load i64, ptr %slot29, align 8
  %v157 = load i64, ptr %slot26, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v156, i64 %v157) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v158 = load i64, ptr %slot19, align 8
  store i64 %v158, ptr %slot30, align 8
  %v159 = load i64, ptr %slot30, align 8
  %v160 = load i64, ptr %slot26, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v159, i64 %v160) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v161 = load i64, ptr %slot13, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %ld163 = load i64, ptr %p162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld163, ptr %slot31, align 8
  %v164 = load i64, ptr %slot31, align 8
  %cond165 = icmp ne i64 %v164, 0
  br i1 %cond165, label %bb_next23, label %bb_i9
bb_next23:
  %v166 = load i64, ptr %slot11, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %ld168 = load i64, ptr %p167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld168, ptr %slot32, align 8
  %v169 = load i64, ptr %slot32, align 8
  %v170 = load i64, ptr %slot13, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i64 %v169, ptr %p171, align 8, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot13, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld174, ptr %slot33, align 8
  %v175 = load i64, ptr %slot1, align 8
  %v176 = load i64, ptr %slot33, align 8
  call void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8 %callresult35, i64 %v175, i64 %v176) nomerge, !dbg !116
  %addr177 = ptrtoint ptr %callresult35 to i64
  store i64 %addr177, ptr %slot34, align 8
  %v178 = load i64, ptr %slot34, align 8
  %v179 = load i64, ptr %slot13, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 %v178, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot13, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i64, ptr %p182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld183, ptr %slot36, align 8
  %v184 = load i64, ptr %slot10, align 8
  store i64 %v184, ptr %slot37, align 8
  %v185 = load i64, ptr %slot36, align 8
  %v186 = load i64, ptr %slot37, align 8
  %p187 = inttoptr i64 %v185 to ptr
  %p188 = inttoptr i64 %v186 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p188, ptr %p187, i64 40, i1 false)
  %v189 = load i64, ptr %slot8, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i32 2, ptr %p190, align 4, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot7, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i32 1, ptr %p192, align 4, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot5, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i32, ptr %p194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld195, ptr %slot38, align 8
  %v196 = load i32, ptr %slot38, align 8
  %cv197 = zext i32 %v196 to i64
  %cond198 = icmp ne i64 %cv197, 0
  br i1 %cond198, label %bb_rcslotdrop32, label %bb_rcslotdone32
bb_rcslotdrop32:
  %v199 = load i64, ptr %slot5, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i32 0, ptr %p200, align 4, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot9, align 8
  store i64 %v201, ptr %slot39, align 8
  %v202 = load i64, ptr %slot6, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i32, ptr %p203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld204, ptr %slot40, align 8
  %v205 = load i32, ptr %slot40, align 8
  %op206 = and i32 %v205, 28
  store i32 %op206, ptr %slot41, align 8
  %v207 = load i32, ptr %slot41, align 8
  %cv208 = zext i32 %v207 to i64
  %cond209 = icmp ne i64 %cv208, 0
  br i1 %cond209, label %bb_rcslotrole32, label %bb_rcslotowner32
bb_rcslotrole32:
  %v210 = load i64, ptr %slot19, align 8
  store i64 %v210, ptr %slot42, align 8
  %v211 = load i64, ptr %slot42, align 8
  %v212 = load i64, ptr %slot39, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v211, i64 %v212) nomerge, !dbg !116
  br label %bb_rcslotdone32
bb_rcslotowner32:
  %v213 = load i64, ptr %slot19, align 8
  store i64 %v213, ptr %slot43, align 8
  %v214 = load i64, ptr %slot43, align 8
  %v215 = load i64, ptr %slot39, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v214, i64 %v215) nomerge, !dbg !116
  br label %bb_rcslotdone32
bb_rcslotdone32:
  %v216 = load i64, ptr %slot9, align 8
  store i64 %v216, ptr %slot44, align 8
  %v217 = load i64, ptr %slot10, align 8
  store i64 %v217, ptr %slot45, align 8
  %v218 = load i64, ptr %slot45, align 8
  %v219 = load i64, ptr %slot44, align 8
  %p220 = inttoptr i64 %v218 to ptr
  %p221 = inttoptr i64 %v219 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p221, ptr %p220, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot6, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i32 2, ptr %p223, align 4, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot8, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i32, ptr %p225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld226, ptr %slot46, align 8
  %v227 = load i32, ptr %slot46, align 8
  %v228 = load i64, ptr %slot6, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i32 %v227, ptr %p229, align 4, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot7, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i32 0, ptr %p231, align 4, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot5, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i32 1, ptr %p233, align 4, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot44, align 8
  %v235 = load i64, ptr %slot13, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot5, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i32, ptr %p238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld239, ptr %slot47, align 8
  %v240 = load i32, ptr %slot47, align 8
  %cv241 = zext i32 %v240 to i64
  %cond242 = icmp ne i64 %cv241, 0
  br i1 %cond242, label %bb_rcslotdrop49, label %bb_rcslotdone49
bb_rcslotdrop49:
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 0, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot9, align 8
  store i64 %v245, ptr %slot48, align 8
  %v246 = load i64, ptr %slot6, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i32, ptr %p247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld248, ptr %slot49, align 8
  %v249 = load i32, ptr %slot49, align 8
  %op250 = and i32 %v249, 28
  store i32 %op250, ptr %slot50, align 8
  %v251 = load i32, ptr %slot50, align 8
  %cv252 = zext i32 %v251 to i64
  %cond253 = icmp ne i64 %cv252, 0
  br i1 %cond253, label %bb_rcslotrole49, label %bb_rcslotowner49
bb_rcslotrole49:
  %v254 = load i64, ptr %slot19, align 8
  store i64 %v254, ptr %slot51, align 8
  %v255 = load i64, ptr %slot51, align 8
  %v256 = load i64, ptr %slot48, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v255, i64 %v256) nomerge, !dbg !118
  br label %bb_rcslotdone49
bb_rcslotowner49:
  %v257 = load i64, ptr %slot19, align 8
  store i64 %v257, ptr %slot52, align 8
  %v258 = load i64, ptr %slot52, align 8
  %v259 = load i64, ptr %slot48, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v258, i64 %v259) nomerge, !dbg !118
  br label %bb_rcslotdone49
bb_rcslotdone49:
  %v260 = load i64, ptr %slot13, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 1, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot13, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot53, align 8
  %v265 = load i64, ptr %slot5, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i32, ptr %p266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld267, ptr %slot54, align 8
  %v268 = load i32, ptr %slot54, align 8
  %cv269 = zext i32 %v268 to i64
  %cond270 = icmp ne i64 %cv269, 0
  br i1 %cond270, label %bb_rcslotdrop59, label %bb_rcslotdone59
bb_rcslotdrop59:
  %v271 = load i64, ptr %slot5, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i32 0, ptr %p272, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone59
bb_rcslotdone59:
  %v273 = load i64, ptr %slot53, align 8
  ret i64 %v273
bb_i9:
  %v274 = load i64, ptr %slot13, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 0, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot13, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot55, align 8
  %v279 = load i64, ptr %slot5, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i32, ptr %p280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld281, ptr %slot56, align 8
  %v282 = load i32, ptr %slot56, align 8
  %cv283 = zext i32 %v282 to i64
  %cond284 = icmp ne i64 %cv283, 0
  br i1 %cond284, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v285 = load i64, ptr %slot5, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i32 0, ptr %p286, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone72
bb_rcslotdone72:
  %v287 = load i64, ptr %slot55, align 8
  ret i64 %v287
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64, i64, i64)
declare void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116", linkageName: "myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16637953224065020630, i64 0, !"myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
