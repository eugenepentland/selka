target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v97 = load i64, ptr %slot1, align 8
  %op98 = add i64 %v97, 32
  store i64 %op98, ptr %slot5, align 8
  %mem99 = alloca i8, i64 24, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot6, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot7, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot8, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot9, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot10, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot11, align 8
  %mem111 = alloca i8, i64 32, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot12, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot13, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot14, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot15, align 8
  %mem119 = alloca i8, i64 24, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot16, align 8
  %mem121 = alloca i8, i64 24, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot17, align 8
  %mem123 = alloca i8, i64 24, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot19, align 8
  %v127 = load i64, ptr %slot1, align 8
  %op128 = add i64 %v127, 64
  store i64 %op128, ptr %slot20, align 8
  %v129 = load i64, ptr %slot20, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !4, !noalias !3
  store i64 %ld131, ptr %slot21, align 8
  %stack132 = call ptr @llvm.stacksave()
  %stackaddr133 = ptrtoint ptr %stack132 to i64
  %v134 = load i64, ptr %slot21, align 8
  %cmp135 = icmp ult i64 %stackaddr133, %v134
  %cv136 = zext i1 %cmp135 to i64
  store i64 %cv136, ptr %slot22, align 8
  %v137 = load i64, ptr %slot22, align 8
  %cond138 = icmp ne i64 %v137, 0
  br i1 %cond138, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v139 = load i64, ptr %slot1, align 8
  %p140 = inttoptr i64 %v139 to ptr
  call void @myl_qbe_fail_frame(ptr %p140) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v141 = load i64, ptr %slot10, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 0, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot2, align 8
  %v144 = load i64, ptr %slot7, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot3, align 8
  %v147 = load i64, ptr %slot8, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot4, align 8
  %v150 = load i64, ptr %slot9, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v152 = load i64, ptr %slot7, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot23, align 8
  %v155 = load i64, ptr %slot23, align 8
  %v156 = load i64, ptr %slot13, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot13, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot24, align 8
  %v161 = load i64, ptr %slot24, align 8
  %op162 = add i64 %v161, 8
  store i64 %op162, ptr %slot25, align 8
  %v163 = load i64, ptr %slot25, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !4, !noalias !3
  store i64 %ld165, ptr %slot26, align 8
  %v166 = load i64, ptr %slot26, align 8
  %v167 = load i64, ptr %slot13, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot14, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 0, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot14, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot27, align 8
  %v174 = load i64, ptr %slot13, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot28, align 8
  %v177 = load i64, ptr %slot28, align 8
  %v178 = load i64, ptr %slot27, align 8
  %cmp179 = icmp eq i64 %v177, %v178
  %cv180 = zext i1 %cmp179 to i64
  store i64 %cv180, ptr %slot29, align 8
  %v181 = load i64, ptr %slot29, align 8
  %v182 = load i64, ptr %slot13, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot13, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot30, align 8
  %v187 = load i64, ptr %slot30, align 8
  %cond188 = icmp ne i64 %v187, 0
  br i1 %cond188, label %bb_next15, label %bb_i7
bb_next15:
  %v189 = load i64, ptr %slot16, align 8
  store i64 %v189, ptr %slot31, align 8
  %v190 = load i64, ptr %slot31, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i32 0, ptr %p191, align 4, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot31, align 8
  %v193 = load i64, ptr %slot13, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot13, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %ld197 = load i64, ptr %p196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld197, ptr %slot32, align 8
  %v198 = load i64, ptr %slot32, align 8
  %p199 = inttoptr i64 %v198 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p199, i64 24, i1 false)
  ret void
bb_i7:
  %v200 = load i64, ptr %slot7, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot33, align 8
  %v203 = load i64, ptr %slot33, align 8
  %v204 = load i64, ptr %slot13, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot13, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot34, align 8
  %v209 = load i64, ptr %slot34, align 8
  %op210 = add i64 %v209, 0
  store i64 %op210, ptr %slot35, align 8
  %v211 = load i64, ptr %slot35, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !4, !noalias !3
  store i64 %ld213, ptr %slot36, align 8
  %v214 = load i64, ptr %slot36, align 8
  %v215 = load i64, ptr %slot13, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot13, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot37, align 8
  %v220 = load i64, ptr %slot10, align 8
  store i64 %v220, ptr %slot38, align 8
  %v221 = load i64, ptr %slot37, align 8
  %v222 = load i64, ptr %slot38, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot7, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot39, align 8
  %v227 = load i64, ptr %slot39, align 8
  %v228 = load i64, ptr %slot13, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 %v227, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot13, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot40, align 8
  %v233 = load i64, ptr %slot40, align 8
  %op234 = add i64 %v233, 0
  store i64 %op234, ptr %slot41, align 8
  %v235 = load i64, ptr %slot41, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !4, !noalias !3
  store i64 %ld237, ptr %slot42, align 8
  %v238 = load i64, ptr %slot42, align 8
  %v239 = load i64, ptr %slot13, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i64 %v238, ptr %p240, align 8, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot8, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot43, align 8
  %v244 = load i64, ptr %slot43, align 8
  %v245 = load i64, ptr %slot14, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i64 %v244, ptr %p246, align 8, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot9, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot44, align 8
  %v250 = load i64, ptr %slot44, align 8
  %v251 = load i64, ptr %slot15, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot13, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot45, align 8
  %v256 = load i64, ptr %slot14, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot46, align 8
  %v259 = load i64, ptr %slot15, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot47, align 8
  %v262 = load i64, ptr %slot1, align 8
  %v263 = load i64, ptr %slot45, align 8
  %v264 = load i64, ptr %slot46, align 8
  %v265 = load i64, ptr %slot47, align 8
  %call266 = call i64 @myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d(i64 %v262, i64 %v263, i64 %v264, i64 %v265) nomerge, !dbg !112
  store i64 %call266, ptr %slot48, align 8
  %v267 = load i64, ptr %slot48, align 8
  %v268 = load i64, ptr %slot13, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot13, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot49, align 8
  %v273 = load i64, ptr %slot11, align 8
  store i64 %v273, ptr %slot50, align 8
  %v274 = load i64, ptr %slot49, align 8
  %v275 = load i64, ptr %slot50, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i64 %v274, ptr %p276, align 8, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot11, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot51, align 8
  %v280 = load i64, ptr %slot51, align 8
  %v281 = load i64, ptr %slot13, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 %v280, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot14, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 0, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot14, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot52, align 8
  %v288 = load i64, ptr %slot13, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot53, align 8
  %v291 = load i64, ptr %slot53, align 8
  %v292 = load i64, ptr %slot52, align 8
  %cmp293 = icmp slt i64 %v291, %v292
  %cv294 = zext i1 %cmp293 to i64
  store i64 %cv294, ptr %slot54, align 8
  %v295 = load i64, ptr %slot54, align 8
  %v296 = load i64, ptr %slot13, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot13, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %ld300 = load i64, ptr %p299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld300, ptr %slot55, align 8
  %v301 = load i64, ptr %slot55, align 8
  %cond302 = icmp ne i64 %v301, 0
  br i1 %cond302, label %bb_next40, label %bb_i25
bb_next40:
  %v303 = load i64, ptr %slot10, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot56, align 8
  %v306 = load i64, ptr %slot56, align 8
  %op307 = add i64 %v306, 0
  store i64 %op307, ptr %slot57, align 8
  %v308 = load i64, ptr %slot57, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %ld310 = load i64, ptr %p309, align 8, !alias.scope !6, !noalias !7
  store i64 %ld310, ptr %slot58, align 8
  %v311 = load i64, ptr %slot58, align 8
  %v312 = load i64, ptr %slot13, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i64 %v311, ptr %p313, align 8, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot13, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot59, align 8
  %v317 = load i64, ptr %slot59, align 8
  %cmp318 = icmp ugt i64 %v317, 9223372036854775807
  %cv319 = zext i1 %cmp318 to i64
  store i64 %cv319, ptr %slot60, align 8
  %v320 = load i64, ptr %slot60, align 8
  %cond321 = icmp ne i64 %v320, 0
  br i1 %cond321, label %bb_cast_overflow45, label %bb_cast_ok45
bb_cast_overflow45:
  %v322 = load i64, ptr %slot1, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %v324 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_cast(ptr %p323, i64 %v324, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok45:
  %v325 = load i64, ptr %slot59, align 8
  %v326 = load i64, ptr %slot13, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot11, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot61, align 8
  %v331 = load i64, ptr %slot61, align 8
  %v332 = load i64, ptr %slot14, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot14, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot62, align 8
  %v337 = load i64, ptr %slot13, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot63, align 8
  %v340 = load i64, ptr %slot63, align 8
  %v341 = load i64, ptr %slot62, align 8
  %ovpair343 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v340, i64 %v341)
  %op342 = extractvalue { i64, i1 } %ovpair343, 0
  %ov344 = extractvalue { i64, i1 } %ovpair343, 1
  store i64 %op342, ptr %slot64, align 8
  %v345 = load i64, ptr %slot63, align 8
  %v346 = load i64, ptr %slot64, align 8
  %op347 = xor i64 %v345, %v346
  store i64 %op347, ptr %slot65, align 8
  %v348 = load i64, ptr %slot62, align 8
  %v349 = load i64, ptr %slot64, align 8
  %op350 = xor i64 %v348, %v349
  store i64 %op350, ptr %slot66, align 8
  %v351 = load i64, ptr %slot65, align 8
  %v352 = load i64, ptr %slot66, align 8
  %op353 = and i64 %v351, %v352
  store i64 %op353, ptr %slot67, align 8
  %cv354 = zext i1 %ov344 to i64
  store i64 %cv354, ptr %slot68, align 8
  %v355 = load i64, ptr %slot68, align 8
  %cond356 = icmp ne i64 %v355, 0
  br i1 %cond356, label %bb_overflow49, label %bb_checked49
bb_overflow49:
  %v357 = load i64, ptr %slot1, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %v359 = load i64, ptr %slot63, align 8
  %v360 = load i64, ptr %slot62, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p358, i64 0, i64 %v359, i64 %v360, i64 64) nomerge, !dbg !116
  unreachable
bb_checked49:
  %v361 = load i64, ptr %slot64, align 8
  %v362 = load i64, ptr %slot13, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot13, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot69, align 8
  %v367 = load i64, ptr %slot11, align 8
  store i64 %v367, ptr %slot70, align 8
  %v368 = load i64, ptr %slot69, align 8
  %v369 = load i64, ptr %slot70, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i25:
  %v371 = load i64, ptr %slot11, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot71, align 8
  %v374 = load i64, ptr %slot71, align 8
  %v375 = load i64, ptr %slot13, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot10, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot72, align 8
  %v380 = load i64, ptr %slot13, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot73, align 8
  %v383 = load i64, ptr %slot72, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !6, !noalias !7
  store i64 %ld385, ptr %slot74, align 8
  %v386 = load i64, ptr %slot73, align 8
  %v387 = load i64, ptr %slot74, align 8
  %cmp388 = icmp ult i64 %v386, %v387
  %cv389 = zext i1 %cmp388 to i64
  store i64 %cv389, ptr %slot75, align 8
  %v390 = load i64, ptr %slot75, align 8
  %cond391 = icmp ne i64 %v390, 0
  br i1 %cond391, label %bb_success62, label %bb_failed62
bb_failed62:
  %v392 = load i64, ptr %slot1, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %v394 = load i64, ptr %slot73, align 8
  %v395 = load i64, ptr %slot74, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p393, i64 %v394, i64 %v395) nomerge, !dbg !118
  unreachable
bb_success62:
  %v396 = load i64, ptr %slot72, align 8
  %op397 = add i64 %v396, 32
  store i64 %op397, ptr %slot76, align 8
  %v398 = load i64, ptr %slot76, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !6, !noalias !7
  store i64 %ld400, ptr %slot77, align 8
  %v401 = load i64, ptr %slot73, align 8
  %op402 = mul i64 %v401, 32
  store i64 %op402, ptr %slot78, align 8
  %v403 = load i64, ptr %slot77, align 8
  %v404 = load i64, ptr %slot78, align 8
  %op405 = add i64 %v403, %v404
  store i64 %op405, ptr %slot79, align 8
  %v406 = load i64, ptr %slot79, align 8
  %v407 = load i64, ptr %slot13, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 %v406, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot13, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i64, ptr %p410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot80, align 8
  %v412 = load i64, ptr %slot12, align 8
  store i64 %v412, ptr %slot81, align 8
  %v413 = load i64, ptr %slot80, align 8
  %v414 = load i64, ptr %slot81, align 8
  %p415 = inttoptr i64 %v413 to ptr
  %p416 = inttoptr i64 %v414 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p416, ptr %p415, i64 32, i1 false), !alias.scope !10000000
  %v417 = load i64, ptr %slot12, align 8
  %v418 = load i64, ptr %slot13, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot13, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot82, align 8
  %v423 = load i64, ptr %slot82, align 8
  %op424 = add i64 %v423, 0
  store i64 %op424, ptr %slot83, align 8
  %v425 = load i64, ptr %slot83, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot84, align 8
  %v428 = load i64, ptr %slot84, align 8
  %v429 = load i64, ptr %slot13, align 8
  %p430 = inttoptr i64 %v429 to ptr
  store i64 %v428, ptr %p430, align 8, !alias.scope !3, !noalias !4
  %v431 = load i64, ptr %slot14, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i64 18446744073709551615, ptr %p432, align 8, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot14, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i64, ptr %p434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld435, ptr %slot85, align 8
  %v436 = load i64, ptr %slot13, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i64, ptr %p437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld438, ptr %slot86, align 8
  %v439 = load i64, ptr %slot86, align 8
  %v440 = load i64, ptr %slot85, align 8
  %cmp441 = icmp eq i64 %v439, %v440
  %cv442 = zext i1 %cmp441 to i64
  store i64 %cv442, ptr %slot87, align 8
  %v443 = load i64, ptr %slot87, align 8
  %v444 = load i64, ptr %slot13, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 %v443, ptr %p445, align 8, !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot13, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot88, align 8
  %v449 = load i64, ptr %slot88, align 8
  %cond450 = icmp ne i64 %v449, 0
  br i1 %cond450, label %bb_next76, label %bb_i35
bb_next76:
  %v451 = load i64, ptr %slot17, align 8
  store i64 %v451, ptr %slot89, align 8
  %v452 = load i64, ptr %slot89, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i32 0, ptr %p453, align 4, !alias.scope !3, !noalias !4
  %v454 = load i64, ptr %slot89, align 8
  %v455 = load i64, ptr %slot13, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i64 %v454, ptr %p456, align 8, !alias.scope !3, !noalias !4
  %v457 = load i64, ptr %slot13, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot90, align 8
  %v460 = load i64, ptr %slot90, align 8
  %p461 = inttoptr i64 %v460 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p461, i64 24, i1 false)
  ret void
bb_i35:
  %v462 = load i64, ptr %slot12, align 8
  %v463 = load i64, ptr %slot13, align 8
  %p464 = inttoptr i64 %v463 to ptr
  store i64 %v462, ptr %p464, align 8, !alias.scope !3, !noalias !4
  %v465 = load i64, ptr %slot13, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %ld467 = load i64, ptr %p466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld467, ptr %slot91, align 8
  %v468 = load i64, ptr %slot91, align 8
  %op469 = add i64 %v468, 16
  store i64 %op469, ptr %slot92, align 8
  %v470 = load i64, ptr %slot92, align 8
  %v471 = load i64, ptr %slot13, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot18, align 8
  store i64 %v473, ptr %slot93, align 8
  %v474 = load i64, ptr %slot93, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 1, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot93, align 8
  %p478 = inttoptr i64 %v476 to ptr
  %gep479 = getelementptr i8, ptr %p478, i64 8
  %op477 = ptrtoint ptr %gep479 to i64
  store i64 %op477, ptr %slot94, align 8
  %v480 = load i64, ptr %slot13, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld482, ptr %slot95, align 8
  %v483 = load i64, ptr %slot95, align 8
  %v484 = load i64, ptr %slot94, align 8
  %p485 = inttoptr i64 %v483 to ptr
  %p486 = inttoptr i64 %v484 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p486, ptr %p485, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v487 = load i64, ptr %slot93, align 8
  %v488 = load i64, ptr %slot13, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i64 %v487, ptr %p489, align 8, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot13, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot96, align 8
  %v493 = load i64, ptr %slot96, align 8
  %p494 = inttoptr i64 %v493 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p494, i64 24, i1 false)
  ret void
bb_failure:
  %v495 = load i64, ptr %slot6, align 8
  %p496 = inttoptr i64 %v495 to ptr
  call void @llvm.memset.p0.i64(ptr %p496, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v497 = load i64, ptr %slot6, align 8
  %p498 = inttoptr i64 %v497 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p498, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v499 = load i64, ptr %slot6, align 8
  %p500 = inttoptr i64 %v499 to ptr
  call void @llvm.memset.p0.i64(ptr %p500, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v501 = load i64, ptr %slot6, align 8
  %p502 = inttoptr i64 %v501 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p502, i64 24, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d(i64, i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 32v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3", linkageName: "myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17369613293211080457, i64 0, !"myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!112 = !DILocation(line: 15, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!114 = !DILocation(line: 22, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!116 = !DILocation(line: 24, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!118 = !DILocation(line: 27, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!120 = !DILocation(line: 39, column: 0, scope: !121)
