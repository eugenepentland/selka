target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %callresult21 = alloca [40 x i8], align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v31 = load i64, ptr %slot1, align 8
  %op32 = add i64 %v31, 32
  store i64 %op32, ptr %slot4, align 8
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot5, align 8
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot6, align 8
  %mem37 = alloca i8, i64 8, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot7, align 8
  %mem39 = alloca i8, i64 8, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot8, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot9, align 8
  %v43 = load i64, ptr %slot1, align 8
  %op44 = add i64 %v43, 64
  store i64 %op44, ptr %slot10, align 8
  %v45 = load i64, ptr %slot10, align 8
  %p46 = inttoptr i64 %v45 to ptr
  %ld47 = load i64, ptr %p46, align 8, !alias.scope !4, !noalias !3
  store i64 %ld47, ptr %slot11, align 8
  %stack48 = call ptr @llvm.stacksave()
  %stackaddr49 = ptrtoint ptr %stack48 to i64
  %v50 = load i64, ptr %slot11, align 8
  %cmp51 = icmp ult i64 %stackaddr49, %v50
  %cv52 = zext i1 %cmp51 to i64
  store i64 %cv52, ptr %slot12, align 8
  %v53 = load i64, ptr %slot12, align 8
  %cond54 = icmp ne i64 %v53, 0
  br i1 %cond54, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v55 = load i64, ptr %slot1, align 8
  %p56 = inttoptr i64 %v55 to ptr
  call void @myl_qbe_fail_frame(ptr %p56) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v57 = load i64, ptr %slot2, align 8
  %v58 = load i64, ptr %slot5, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot3, align 8
  %v61 = load i64, ptr %slot6, align 8
  %p62 = inttoptr i64 %v61 to ptr
  store i64 %v60, ptr %p62, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v63 = load i64, ptr %slot5, align 8
  %p64 = inttoptr i64 %v63 to ptr
  %ld65 = load i64, ptr %p64, align 8, !alias.scope !3, !noalias !4
  store i64 %ld65, ptr %slot13, align 8
  %v66 = load i64, ptr %slot13, align 8
  %v67 = load i64, ptr %slot7, align 8
  %p68 = inttoptr i64 %v67 to ptr
  store i64 %v66, ptr %p68, align 8, !alias.scope !3, !noalias !4
  %v69 = load i64, ptr %slot7, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !3, !noalias !4
  store i64 %ld71, ptr %slot14, align 8
  %v72 = load i64, ptr %slot1, align 8
  %v73 = load i64, ptr %slot14, align 8
  %call74 = call i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64 %v72, i64 %v73) nomerge, !dbg !112
  store i64 %call74, ptr %slot15, align 8
  %v75 = load i64, ptr %slot15, align 8
  %v76 = load i64, ptr %slot7, align 8
  %p77 = inttoptr i64 %v76 to ptr
  store i64 %v75, ptr %p77, align 8, !alias.scope !3, !noalias !4
  %v78 = load i64, ptr %slot7, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot16, align 8
  %v81 = load i64, ptr %slot16, align 8
  %cond82 = icmp ne i64 %v81, 0
  br i1 %cond82, label %bb_next21, label %bb_i5
bb_next21:
  %v83 = load i64, ptr %slot7, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 0, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot7, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot17, align 8
  %v88 = load i64, ptr %slot17, align 8
  ret i64 %v88
bb_i5:
  %v89 = load i64, ptr %slot5, align 8
  %p90 = inttoptr i64 %v89 to ptr
  %ld91 = load i64, ptr %p90, align 8, !alias.scope !3, !noalias !4
  store i64 %ld91, ptr %slot18, align 8
  %v92 = load i64, ptr %slot18, align 8
  %v93 = load i64, ptr %slot7, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 %v92, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot7, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i64, ptr %p96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld97, ptr %slot19, align 8
  %v98 = load i64, ptr %slot1, align 8
  %v99 = load i64, ptr %slot19, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult21, i64 %v98, i64 %v99) nomerge, !dbg !114
  %addr100 = ptrtoint ptr %callresult21 to i64
  store i64 %addr100, ptr %slot20, align 8
  %v101 = load i64, ptr %slot20, align 8
  %v102 = load i64, ptr %slot7, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 %v101, ptr %p103, align 8, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot7, align 8
  %p105 = inttoptr i64 %v104 to ptr
  %ld106 = load i64, ptr %p105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld106, ptr %slot22, align 8
  %v107 = load i64, ptr %slot22, align 8
  %op108 = add i64 %v107, 0
  store i64 %op108, ptr %slot23, align 8
  %v109 = load i64, ptr %slot23, align 8
  %v110 = load i64, ptr %slot7, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot24, align 8
  %v115 = load i64, ptr %slot24, align 8
  %v116 = load i64, ptr %slot8, align 8
  %p117 = inttoptr i64 %v116 to ptr
  store i64 %v115, ptr %p117, align 8, !alias.scope !3, !noalias !4
  %v118 = load i64, ptr %slot8, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot25, align 8
  %v121 = load i64, ptr %slot7, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot26, align 8
  %v124 = load i64, ptr %slot26, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i32, ptr %p125, align 4
  %ext127 = zext i32 %ld126 to i64
  store i64 %ext127, ptr %slot27, align 8
  %v128 = load i64, ptr %slot25, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i32, ptr %p129, align 4, !alias.scope !4, !noalias !3
  %ext131 = zext i32 %ld130 to i64
  store i64 %ext131, ptr %slot28, align 8
  %v132 = load i64, ptr %slot27, align 8
  %v133 = load i64, ptr %slot28, align 8
  %cmp134 = icmp eq i64 %v132, %v133
  %cv135 = zext i1 %cmp134 to i64
  store i64 %cv135, ptr %slot29, align 8
  %v136 = load i64, ptr %slot29, align 8
  %v137 = load i64, ptr %slot7, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot7, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot30, align 8
  %v142 = load i64, ptr %slot30, align 8
  ret i64 %v142
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255", linkageName: "myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5419835805873020912, i64 0, !"myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
