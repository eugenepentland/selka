target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v33 = load i64, ptr %slot1, align 8
  %op34 = add i64 %v33, 32
  store i64 %op34, ptr %slot4, align 8
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot5, align 8
  %mem37 = alloca i8, i64 8, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot6, align 8
  %mem39 = alloca i8, i64 8, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot7, align 8
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot8, align 8
  %mem43 = alloca i8, i64 40, align 8
  %ptr44 = ptrtoint ptr %mem43 to i64
  store i64 %ptr44, ptr %slot9, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem45 = alloca i8, i64 8, align 8
  %ptr46 = ptrtoint ptr %mem45 to i64
  store i64 %ptr46, ptr %slot10, align 8
  %v47 = load i64, ptr %slot1, align 8
  %op48 = add i64 %v47, 64
  store i64 %op48, ptr %slot11, align 8
  %v49 = load i64, ptr %slot11, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !4, !noalias !3
  store i64 %ld51, ptr %slot12, align 8
  %stack52 = call ptr @llvm.stacksave()
  %stackaddr53 = ptrtoint ptr %stack52 to i64
  %v54 = load i64, ptr %slot12, align 8
  %cmp55 = icmp ult i64 %stackaddr53, %v54
  %cv56 = zext i1 %cmp55 to i64
  store i64 %cv56, ptr %slot13, align 8
  %v57 = load i64, ptr %slot13, align 8
  %cond58 = icmp ne i64 %v57, 0
  br i1 %cond58, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v59 = load i64, ptr %slot1, align 8
  %p60 = inttoptr i64 %v59 to ptr
  call void @myl_qbe_fail_frame(ptr %p60) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v61 = load i64, ptr %slot2, align 8
  %v62 = load i64, ptr %slot5, align 8
  %p63 = inttoptr i64 %v62 to ptr
  store i64 %v61, ptr %p63, align 8, !alias.scope !3, !noalias !4
  %v64 = load i64, ptr %slot3, align 8
  %v65 = load i64, ptr %slot6, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 %v64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v67 = load i64, ptr %slot5, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot14, align 8
  %v71 = load i64, ptr %slot7, align 8
  %p72 = inttoptr i64 %v71 to ptr
  store i64 %v70, ptr %p72, align 8, !alias.scope !3, !noalias !4
  %v73 = load i64, ptr %slot7, align 8
  %p74 = inttoptr i64 %v73 to ptr
  %ld75 = load i64, ptr %p74, align 8, !alias.scope !3, !noalias !4
  store i64 %ld75, ptr %slot15, align 8
  %v76 = load i64, ptr %slot15, align 8
  %op77 = add i64 %v76, 288
  store i64 %op77, ptr %slot16, align 8
  %v78 = load i64, ptr %slot16, align 8
  %v79 = load i64, ptr %slot7, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot7, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot17, align 8
  %v84 = load i64, ptr %slot17, align 8
  %op85 = add i64 %v84, 0
  store i64 %op85, ptr %slot18, align 8
  %v86 = load i64, ptr %slot18, align 8
  %v87 = load i64, ptr %slot7, align 8
  %p88 = inttoptr i64 %v87 to ptr
  store i64 %v86, ptr %p88, align 8, !alias.scope !3, !noalias !4
  %v89 = load i64, ptr %slot7, align 8
  %p90 = inttoptr i64 %v89 to ptr
  %ld91 = load i64, ptr %p90, align 8, !alias.scope !3, !noalias !4
  store i64 %ld91, ptr %slot19, align 8
  %v92 = load i64, ptr %slot9, align 8
  store i64 %v92, ptr %slot20, align 8
  %v93 = load i64, ptr %slot19, align 8
  %v94 = load i64, ptr %slot20, align 8
  %p95 = inttoptr i64 %v93 to ptr
  %p96 = inttoptr i64 %v94 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p96, ptr %p95, i64 4, i1 false), !alias.scope !10000000
  %v97 = load i64, ptr %slot20, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i64 %v97, ptr %p99, align 8, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot6, align 8
  %p101 = inttoptr i64 %v100 to ptr
  %ld102 = load i64, ptr %p101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld102, ptr %slot21, align 8
  %v103 = load i64, ptr %slot21, align 8
  %v104 = load i64, ptr %slot8, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 %v103, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot8, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld108, ptr %slot22, align 8
  %v109 = load i64, ptr %slot7, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld111, ptr %slot23, align 8
  %v112 = load i64, ptr %slot23, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i32, ptr %p113, align 4, !alias.scope !3, !noalias !4
  %ext115 = zext i32 %ld114 to i64
  store i64 %ext115, ptr %slot24, align 8
  %v116 = load i64, ptr %slot22, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i32, ptr %p117, align 4, !alias.scope !4, !noalias !3
  %ext119 = zext i32 %ld118 to i64
  store i64 %ext119, ptr %slot25, align 8
  %v120 = load i64, ptr %slot24, align 8
  %v121 = load i64, ptr %slot25, align 8
  %cmp122 = icmp ne i64 %v120, %v121
  %cv123 = zext i1 %cmp122 to i64
  store i64 %cv123, ptr %slot26, align 8
  %v124 = load i64, ptr %slot26, align 8
  %v125 = load i64, ptr %slot7, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 %v124, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot7, align 8
  %p128 = inttoptr i64 %v127 to ptr
  %ld129 = load i64, ptr %p128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot27, align 8
  %v130 = load i64, ptr %slot27, align 8
  %cond131 = icmp ne i64 %v130, 0
  br i1 %cond131, label %bb_next40, label %bb_i8
bb_next40:
  %v132 = load i64, ptr %slot7, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 0, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot7, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot28, align 8
  %v137 = load i64, ptr %slot28, align 8
  ret i64 %v137
bb_i8:
  %v138 = load i64, ptr %slot5, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot29, align 8
  %v141 = load i64, ptr %slot29, align 8
  %v142 = load i64, ptr %slot7, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot7, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot30, align 8
  %v147 = load i64, ptr %slot1, align 8
  %v148 = load i64, ptr %slot30, align 8
  %call149 = call i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64 %v147, i64 %v148) nomerge, !dbg !112
  store i64 %call149, ptr %slot31, align 8
  %v150 = load i64, ptr %slot31, align 8
  %v151 = load i64, ptr %slot7, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot7, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 1, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot7, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot32, align 8
  %v158 = load i64, ptr %slot32, align 8
  ret i64 %v158
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d", linkageName: "myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9637326008798313652, i64 0, !"myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!112 = !DILocation(line: 10, column: 0, scope: !113)
