target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ccbcc6e57bcd0ab7ca8957ffda6c4aa19d79b91c5c4d4538975da6aeefc0b940(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v17 = load i64, ptr %slot1, align 8
  %op18 = add i64 %v17, 32
  store i64 %op18, ptr %slot3, align 8
  %mem19 = alloca i8, i64 8, align 8
  %ptr20 = ptrtoint ptr %mem19 to i64
  store i64 %ptr20, ptr %slot4, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot5, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot6, align 8
  %v25 = load i64, ptr %slot2, align 8
  %v26 = load i64, ptr %slot4, align 8
  %p27 = inttoptr i64 %v26 to ptr
  store i64 %v25, ptr %p27, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v28 = load i64, ptr %slot4, align 8
  %p29 = inttoptr i64 %v28 to ptr
  %ld30 = load i64, ptr %p29, align 8, !alias.scope !3, !noalias !4
  store i64 %ld30, ptr %slot7, align 8
  %v31 = load i64, ptr %slot7, align 8
  %v32 = load i64, ptr %slot5, align 8
  %p33 = inttoptr i64 %v32 to ptr
  store i64 %v31, ptr %p33, align 8, !alias.scope !3, !noalias !4
  %v34 = load i64, ptr %slot6, align 8
  %p35 = inttoptr i64 %v34 to ptr
  store i64 48, ptr %p35, align 8, !alias.scope !3, !noalias !4
  %v36 = load i64, ptr %slot6, align 8
  %p37 = inttoptr i64 %v36 to ptr
  %ld38 = load i64, ptr %p37, align 8, !alias.scope !3, !noalias !4
  store i64 %ld38, ptr %slot8, align 8
  %v39 = load i64, ptr %slot5, align 8
  %p40 = inttoptr i64 %v39 to ptr
  %ld41 = load i64, ptr %p40, align 8, !alias.scope !3, !noalias !4
  store i64 %ld41, ptr %slot9, align 8
  %v42 = load i64, ptr %slot9, align 8
  %v43 = load i64, ptr %slot8, align 8
  %cmp44 = icmp sge i64 %v42, %v43
  %cv45 = zext i1 %cmp44 to i64
  store i64 %cv45, ptr %slot10, align 8
  %v46 = load i64, ptr %slot10, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot5, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot11, align 8
  %v52 = load i64, ptr %slot11, align 8
  %cond53 = icmp ne i64 %v52, 0
  br i1 %cond53, label %bb_next5, label %bb_i8
bb_next5:
  %v54 = load i64, ptr %slot4, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !3, !noalias !4
  store i64 %ld56, ptr %slot12, align 8
  %v57 = load i64, ptr %slot12, align 8
  %v58 = load i64, ptr %slot5, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot6, align 8
  %p61 = inttoptr i64 %v60 to ptr
  store i64 57, ptr %p61, align 8, !alias.scope !3, !noalias !4
  %v62 = load i64, ptr %slot6, align 8
  %p63 = inttoptr i64 %v62 to ptr
  %ld64 = load i64, ptr %p63, align 8, !alias.scope !3, !noalias !4
  store i64 %ld64, ptr %slot13, align 8
  %v65 = load i64, ptr %slot5, align 8
  %p66 = inttoptr i64 %v65 to ptr
  %ld67 = load i64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  store i64 %ld67, ptr %slot14, align 8
  %v68 = load i64, ptr %slot14, align 8
  %v69 = load i64, ptr %slot13, align 8
  %cmp70 = icmp sle i64 %v68, %v69
  %cv71 = zext i1 %cmp70 to i64
  store i64 %cv71, ptr %slot15, align 8
  %v72 = load i64, ptr %slot15, align 8
  %v73 = load i64, ptr %slot5, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i8:
  %v75 = load i64, ptr %slot5, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 0, ptr %p76, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v77 = load i64, ptr %slot5, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot16, align 8
  %v80 = load i64, ptr %slot16, align 8
  ret i64 %v80
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
