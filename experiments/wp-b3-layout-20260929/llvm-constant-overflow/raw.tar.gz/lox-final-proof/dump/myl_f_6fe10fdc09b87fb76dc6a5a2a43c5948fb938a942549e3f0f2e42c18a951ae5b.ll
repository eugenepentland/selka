target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i32, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v72 = load i64, ptr %slot1, align 8
  %op73 = add i64 %v72, 32
  store i64 %op73, ptr %slot4, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot5, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot6, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot7, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot8, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot9, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot10, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot11, align 8
  %v88 = load i64, ptr %slot8, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 0, ptr %p89, align 8, !alias.scope !3, !noalias !4
  %v90 = load i64, ptr %slot2, align 8
  %v91 = load i64, ptr %slot6, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot3, align 8
  %v94 = load i64, ptr %slot7, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot1, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %call98 = call ptr @myl_qbe_heap(ptr %p97) nomerge, !dbg !110
  %calladdr99 = ptrtoint ptr %call98 to i64
  store i64 %calladdr99, ptr %slot12, align 8
  br label %bb_i0
bb_i0:
  %v100 = load i64, ptr %slot6, align 8
  %p101 = inttoptr i64 %v100 to ptr
  %ld102 = load i64, ptr %p101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld102, ptr %slot13, align 8
  %v103 = load i64, ptr %slot13, align 8
  %v104 = load i64, ptr %slot10, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 %v103, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot10, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld108, ptr %slot14, align 8
  %v109 = load i64, ptr %slot14, align 8
  %op110 = add i64 %v109, 176
  store i64 %op110, ptr %slot15, align 8
  %v111 = load i64, ptr %slot15, align 8
  %p112 = inttoptr i64 %v111 to ptr
  %ld113 = load i64, ptr %p112, align 8
  store i64 %ld113, ptr %slot16, align 8
  %v114 = load i64, ptr %slot16, align 8
  %v115 = load i64, ptr %slot10, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot10, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot17, align 8
  %v120 = load i64, ptr %slot6, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot18, align 8
  %v123 = load i64, ptr %slot18, align 8
  %op124 = add i64 %v123, 176
  store i64 %op124, ptr %slot19, align 8
  store i64 0, ptr %slot20, align 8
  %v125 = load i64, ptr %slot19, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !4, !noalias !3
  store i64 %ld127, ptr %slot21, align 8
  %v128 = load i64, ptr %slot21, align 8
  %cmp129 = icmp ne i64 %v128, 0
  %cv130 = zext i1 %cmp129 to i32
  store i32 %cv130, ptr %slot22, align 8
  %v131 = load i32, ptr %slot22, align 8
  %cv132 = zext i32 %v131 to i64
  %cond133 = icmp ne i64 %cv132, 0
  br i1 %cond133, label %bb_rcguniquenn57, label %bb_rcgunique57
bb_rcguniquenn57:
  %v134 = load i64, ptr %slot21, align 8
  %op135 = sub i64 %v134, 16
  store i64 %op135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot21, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %rgep138 = getelementptr i8, ptr %p137, i64 -16
  %ld139 = load i64, ptr %rgep138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld139, ptr %slot24, align 8
  %v140 = load i64, ptr %slot24, align 8
  %op141 = and i64 %v140, 6917529027641081858
  store i64 %op141, ptr %slot25, align 8
  %v142 = load i64, ptr %slot25, align 8
  %cmp143 = icmp ne i64 %v142, 0
  %cv144 = zext i1 %cmp143 to i32
  store i32 %cv144, ptr %slot26, align 8
  %v145 = load i32, ptr %slot26, align 8
  %cv146 = zext i32 %v145 to i64
  %cond147 = icmp ne i64 %cv146, 0
  br i1 %cond147, label %bb_rcguniqueslow57, label %bb_rcguniquecount57
bb_rcguniquecount57:
  %v148 = load i64, ptr %slot21, align 8
  %op149 = sub i64 %v148, 32
  store i64 %op149, ptr %slot27, align 8
  %v150 = load i64, ptr %slot21, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %rgep152 = getelementptr i8, ptr %p151, i64 -32
  %ld153 = load i64, ptr %rgep152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld153, ptr %slot28, align 8
  %v154 = load i64, ptr %slot28, align 8
  %cmp155 = icmp ult i64 %v154, 2
  %cv156 = zext i1 %cmp155 to i32
  store i32 %cv156, ptr %slot29, align 8
  %v157 = load i32, ptr %slot29, align 8
  %cv158 = zext i32 %v157 to i64
  %cond159 = icmp ne i64 %cv158, 0
  br i1 %cond159, label %bb_rcgunique57, label %bb_rcguniqueslow57
bb_rcguniqueslow57:
  %v160 = load i64, ptr %slot1, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %p162 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v163 = load i64, ptr %slot19, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %v165 = load i64, ptr %slot20, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %call167 = call i32 @myl_qbe_rc_unique_field(ptr %p161, ptr %p162, ptr %p164, ptr %p166) nomerge, !dbg !112
  store i32 %call167, ptr %slot30, align 8
  %v168 = load i32, ptr %slot30, align 8
  %cv169 = zext i32 %v168 to i64
  %cond170 = icmp ne i64 %cv169, 0
  br i1 %cond170, label %bb_rcunique67, label %bb_failure
bb_rcunique67:
  br label %bb_rcgunique57
bb_rcgunique57:
  %v171 = load i64, ptr %slot19, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !4, !noalias !3
  store i64 %ld173, ptr %slot31, align 8
  %v174 = load i64, ptr %slot31, align 8
  %v175 = load i64, ptr %slot10, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot10, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot32, align 8
  %v180 = load i64, ptr %slot32, align 8
  %v181 = load i64, ptr %slot8, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot6, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot33, align 8
  %v186 = load i64, ptr %slot33, align 8
  %v187 = load i64, ptr %slot10, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot10, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot34, align 8
  %v192 = load i64, ptr %slot34, align 8
  %op193 = add i64 %v192, 168
  store i64 %op193, ptr %slot35, align 8
  %v194 = load i64, ptr %slot35, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i64, ptr %p195, align 8
  store i64 %ld196, ptr %slot36, align 8
  %v197 = load i64, ptr %slot36, align 8
  %v198 = load i64, ptr %slot10, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i64 %v197, ptr %p199, align 8, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot8, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot37, align 8
  %v203 = load i64, ptr %slot10, align 8
  store i64 %v203, ptr %slot38, align 8
  %v204 = load i64, ptr %slot38, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot39, align 8
  %v207 = load i64, ptr %slot37, align 8
  %op208 = add i64 %v207, 0
  store i64 %op208, ptr %slot40, align 8
  %v209 = load i64, ptr %slot40, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !6, !noalias !7
  store i64 %ld211, ptr %slot41, align 8
  %v212 = load i64, ptr %slot37, align 8
  %op213 = add i64 %v212, 8
  store i64 %op213, ptr %slot42, align 8
  %v214 = load i64, ptr %slot42, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !6, !noalias !7
  store i64 %ld216, ptr %slot43, align 8
  %v217 = load i64, ptr %slot37, align 8
  %op218 = add i64 %v217, 16
  store i64 %op218, ptr %slot44, align 8
  %v219 = load i64, ptr %slot44, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !6, !noalias !7
  store i64 %ld221, ptr %slot45, align 8
  %v222 = load i64, ptr %slot41, align 8
  %v223 = load i64, ptr %slot43, align 8
  %cmp224 = icmp ult i64 %v222, %v223
  %cv225 = zext i1 %cmp224 to i32
  store i32 %cv225, ptr %slot46, align 8
  %v226 = load i64, ptr %slot45, align 8
  %cmp227 = icmp ne i64 %v226, 18446744073709551615
  %cv228 = zext i1 %cmp227 to i32
  store i32 %cv228, ptr %slot47, align 8
  %v229 = load i32, ptr %slot46, align 8
  %v230 = load i32, ptr %slot47, align 8
  %op231 = and i32 %v229, %v230
  store i32 %op231, ptr %slot48, align 8
  %v232 = load i32, ptr %slot48, align 8
  %cv233 = zext i32 %v232 to i64
  %cond234 = icmp ne i64 %cv233, 0
  br i1 %cond234, label %bb_rcappend_check87, label %bb_rcappend_slow87
bb_rcappend_check87:
  %v235 = load i64, ptr %slot12, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %v237 = load i64, ptr %slot37, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %call239 = call i32 @myl_rc_list_plain_ready(ptr %p236, ptr %p238) nomerge, !dbg !114
  store i32 %call239, ptr %slot49, align 8
  %v240 = load i32, ptr %slot49, align 8
  %cv241 = zext i32 %v240 to i64
  %cond242 = icmp ne i64 %cv241, 0
  br i1 %cond242, label %bb_rcappend_fast87, label %bb_rcappend_slow87
bb_rcappend_slow87:
  %v243 = load i64, ptr %slot38, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot50, align 8
  %v246 = load i64, ptr %slot50, align 8
  %v247 = load i64, ptr %slot5, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot5, align 8
  store i64 %v249, ptr %slot51, align 8
  %v250 = load i64, ptr %slot12, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %v252 = load i64, ptr %slot37, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %v254 = load i64, ptr %slot51, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %call256 = call i32 @myl_rc_list_append(ptr %p251, ptr %p253, ptr %p255) nomerge, !dbg !114
  store i32 %call256, ptr %slot52, align 8
  %v257 = load i32, ptr %slot52, align 8
  %cv258 = zext i32 %v257 to i64
  %cond259 = icmp ne i64 %cv258, 0
  br i1 %cond259, label %bb_success100, label %bb_failed100
bb_failed100:
  %v260 = load i64, ptr %slot1, align 8
  %p261 = inttoptr i64 %v260 to ptr
  call void @myl_qbe_fail_allocation(ptr %p261) nomerge, !dbg !114
  unreachable
bb_success100:
  br label %bb_rcappend_done87
bb_rcappend_fast87:
  %v262 = load i64, ptr %slot37, align 8
  %op263 = add i64 %v262, 32
  store i64 %op263, ptr %slot53, align 8
  %v264 = load i64, ptr %slot53, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !6, !noalias !7
  store i64 %ld266, ptr %slot54, align 8
  %v267 = load i64, ptr %slot41, align 8
  %op268 = mul i64 %v267, 8
  store i64 %op268, ptr %slot55, align 8
  %v269 = load i64, ptr %slot54, align 8
  %v270 = load i64, ptr %slot55, align 8
  %op271 = add i64 %v269, %v270
  store i64 %op271, ptr %slot56, align 8
  %v272 = load i64, ptr %slot39, align 8
  %v273 = load i64, ptr %slot54, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %v275 = load i64, ptr %slot55, align 8
  %egep276 = getelementptr i8, ptr %p274, i64 %v275
  store i64 %v272, ptr %egep276, align 8, !alias.scope !12, !noalias !13
  %v277 = load i64, ptr %slot37, align 8
  %op278 = add i64 %v277, 0
  store i64 %op278, ptr %slot57, align 8
  %v279 = load i64, ptr %slot41, align 8
  %op280 = add i64 %v279, 1
  store i64 %op280, ptr %slot58, align 8
  %v281 = load i64, ptr %slot58, align 8
  %v282 = load i64, ptr %slot57, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !6, !noalias !7
  %v284 = load i64, ptr %slot37, align 8
  %op285 = add i64 %v284, 16
  store i64 %op285, ptr %slot59, align 8
  %v286 = load i64, ptr %slot45, align 8
  %op287 = add i64 %v286, 1
  store i64 %op287, ptr %slot60, align 8
  %v288 = load i64, ptr %slot60, align 8
  %v289 = load i64, ptr %slot59, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done87
bb_rcappend_done87:
  %v291 = load i64, ptr %slot10, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 0, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot7, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot61, align 8
  %v296 = load i64, ptr %slot61, align 8
  %v297 = load i64, ptr %slot10, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot10, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot62, align 8
  %v302 = load i64, ptr %slot62, align 8
  %v303 = load i64, ptr %slot9, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i64 %v302, ptr %p304, align 8, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot6, align 8
  %p306 = inttoptr i64 %v305 to ptr
  %ld307 = load i64, ptr %p306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld307, ptr %slot63, align 8
  %v308 = load i64, ptr %slot63, align 8
  %v309 = load i64, ptr %slot10, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i64 %v308, ptr %p310, align 8, !alias.scope !3, !noalias !4
  %v311 = load i64, ptr %slot6, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %ld313 = load i64, ptr %p312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld313, ptr %slot64, align 8
  %v314 = load i64, ptr %slot64, align 8
  %v315 = load i64, ptr %slot10, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 %v314, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot6, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot65, align 8
  %v320 = load i64, ptr %slot65, align 8
  %v321 = load i64, ptr %slot10, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot9, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot66, align 8
  %v326 = load i64, ptr %slot66, align 8
  %v327 = load i64, ptr %slot11, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot6, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot67, align 8
  %v332 = load i64, ptr %slot67, align 8
  %v333 = load i64, ptr %slot10, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot9, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot68, align 8
  %v338 = load i64, ptr %slot6, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot69, align 8
  %v341 = load i64, ptr %slot69, align 8
  %op342 = add i64 %v341, 168
  store i64 %op342, ptr %slot70, align 8
  %v343 = load i64, ptr %slot68, align 8
  %v344 = load i64, ptr %slot70, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i64 %v343, ptr %p345, align 8, !alias.scope !4, !noalias !3
  %v346 = load i64, ptr %slot10, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i64 0, ptr %p347, align 8, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot10, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 0, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot10, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot71, align 8
  %v353 = load i64, ptr %slot71, align 8
  ret i64 %v353
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8

declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b", linkageName: "myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3476251353757281527, i64 0, !"myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
