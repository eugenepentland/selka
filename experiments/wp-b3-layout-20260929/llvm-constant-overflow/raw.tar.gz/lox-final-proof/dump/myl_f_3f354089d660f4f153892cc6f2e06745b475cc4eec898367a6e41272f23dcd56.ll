target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3f354089d660f4f153892cc6f2e06745b475cc4eec898367a6e41272f23dcd56(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i32, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i32, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v1182 = load i64, ptr %slot1, align 8
  %op1183 = add i64 %v1182, 32
  store i64 %op1183, ptr %slot5, align 8
  %mem1184 = alloca i8, i64 8, align 8
  %ptr1185 = ptrtoint ptr %mem1184 to i64
  store i64 %ptr1185, ptr %slot6, align 8
  %mem1186 = alloca i8, i64 8, align 8
  %ptr1187 = ptrtoint ptr %mem1186 to i64
  store i64 %ptr1187, ptr %slot7, align 8
  %mem1188 = alloca i8, i64 8, align 8
  %ptr1189 = ptrtoint ptr %mem1188 to i64
  store i64 %ptr1189, ptr %slot8, align 8
  %mem1190 = alloca i8, i64 8, align 8
  %ptr1191 = ptrtoint ptr %mem1190 to i64
  store i64 %ptr1191, ptr %slot9, align 8
  %mem1192 = alloca i8, i64 8, align 8
  %ptr1193 = ptrtoint ptr %mem1192 to i64
  store i64 %ptr1193, ptr %slot10, align 8
  %mem1194 = alloca i8, i64 8, align 8
  %ptr1195 = ptrtoint ptr %mem1194 to i64
  store i64 %ptr1195, ptr %slot11, align 8
  %mem1196 = alloca i8, i64 8, align 8
  %ptr1197 = ptrtoint ptr %mem1196 to i64
  store i64 %ptr1197, ptr %slot12, align 8
  %mem1198 = alloca i8, i64 8, align 8
  %ptr1199 = ptrtoint ptr %mem1198 to i64
  store i64 %ptr1199, ptr %slot13, align 8
  %mem1200 = alloca i8, i64 8, align 8
  %ptr1201 = ptrtoint ptr %mem1200 to i64
  store i64 %ptr1201, ptr %slot14, align 8
  %mem1202 = alloca i8, i64 8, align 8
  %ptr1203 = ptrtoint ptr %mem1202 to i64
  store i64 %ptr1203, ptr %slot15, align 8
  %mem1204 = alloca i8, i64 8, align 8
  %ptr1205 = ptrtoint ptr %mem1204 to i64
  store i64 %ptr1205, ptr %slot16, align 8
  %mem1206 = alloca i8, i64 8, align 8
  %ptr1207 = ptrtoint ptr %mem1206 to i64
  store i64 %ptr1207, ptr %slot17, align 8
  %mem1208 = alloca i8, i64 8, align 8
  %ptr1209 = ptrtoint ptr %mem1208 to i64
  store i64 %ptr1209, ptr %slot18, align 8
  %mem1210 = alloca i8, i64 8, align 8
  %ptr1211 = ptrtoint ptr %mem1210 to i64
  store i64 %ptr1211, ptr %slot19, align 8
  %mem1212 = alloca i8, i64 8, align 8
  %ptr1213 = ptrtoint ptr %mem1212 to i64
  store i64 %ptr1213, ptr %slot20, align 8
  %mem1214 = alloca i8, i64 8, align 8
  %ptr1215 = ptrtoint ptr %mem1214 to i64
  store i64 %ptr1215, ptr %slot21, align 8
  %mem1216 = alloca i8, i64 8, align 8
  %ptr1217 = ptrtoint ptr %mem1216 to i64
  store i64 %ptr1217, ptr %slot22, align 8
  %mem1218 = alloca i8, i64 8, align 8
  %ptr1219 = ptrtoint ptr %mem1218 to i64
  store i64 %ptr1219, ptr %slot23, align 8
  %mem1220 = alloca i8, i64 8, align 8
  %ptr1221 = ptrtoint ptr %mem1220 to i64
  store i64 %ptr1221, ptr %slot24, align 8
  %mem1222 = alloca i8, i64 104, align 8
  %ptr1223 = ptrtoint ptr %mem1222 to i64
  store i64 %ptr1223, ptr %slot25, align 8
  %mem1224 = alloca i8, i64 104, align 8
  %ptr1225 = ptrtoint ptr %mem1224 to i64
  store i64 %ptr1225, ptr %slot26, align 8
  %mem1226 = alloca i8, i64 40, align 8
  %ptr1227 = ptrtoint ptr %mem1226 to i64
  store i64 %ptr1227, ptr %slot27, align 8
  %mem1228 = alloca i8, i64 8, align 8
  %ptr1229 = ptrtoint ptr %mem1228 to i64
  store i64 %ptr1229, ptr %slot28, align 8
  %mem1230 = alloca i8, i64 8, align 8
  %ptr1231 = ptrtoint ptr %mem1230 to i64
  store i64 %ptr1231, ptr %slot29, align 8
  %mem1232 = alloca i8, i64 8, align 8
  %ptr1233 = ptrtoint ptr %mem1232 to i64
  store i64 %ptr1233, ptr %slot30, align 8
  %mem1234 = alloca i8, i64 104, align 8
  %ptr1235 = ptrtoint ptr %mem1234 to i64
  store i64 %ptr1235, ptr %slot31, align 8
  %mem1236 = alloca i8, i64 8, align 8
  %ptr1237 = ptrtoint ptr %mem1236 to i64
  store i64 %ptr1237, ptr %slot32, align 8
  %mem1238 = alloca i8, i64 8, align 8
  %ptr1239 = ptrtoint ptr %mem1238 to i64
  store i64 %ptr1239, ptr %slot33, align 8
  %mem1240 = alloca i8, i64 8, align 8
  %ptr1241 = ptrtoint ptr %mem1240 to i64
  store i64 %ptr1241, ptr %slot34, align 8
  %mem1242 = alloca i8, i64 8, align 8
  %ptr1243 = ptrtoint ptr %mem1242 to i64
  store i64 %ptr1243, ptr %slot35, align 8
  %mem1244 = alloca i8, i64 104, align 8
  %ptr1245 = ptrtoint ptr %mem1244 to i64
  store i64 %ptr1245, ptr %slot36, align 8
  %mem1246 = alloca i8, i64 8, align 8
  %ptr1247 = ptrtoint ptr %mem1246 to i64
  store i64 %ptr1247, ptr %slot37, align 8
  %mem1248 = alloca i8, i64 8, align 8
  %ptr1249 = ptrtoint ptr %mem1248 to i64
  store i64 %ptr1249, ptr %slot38, align 8
  %mem1250 = alloca i8, i64 8, align 8
  %ptr1251 = ptrtoint ptr %mem1250 to i64
  store i64 %ptr1251, ptr %slot39, align 8
  %mem1252 = alloca i8, i64 8, align 8
  %ptr1253 = ptrtoint ptr %mem1252 to i64
  store i64 %ptr1253, ptr %slot40, align 8
  %mem1254 = alloca i8, i64 8, align 8
  %ptr1255 = ptrtoint ptr %mem1254 to i64
  store i64 %ptr1255, ptr %slot41, align 8
  %mem1256 = alloca i8, i64 8, align 8
  %ptr1257 = ptrtoint ptr %mem1256 to i64
  store i64 %ptr1257, ptr %slot42, align 8
  %mem1258 = alloca i8, i64 8, align 8
  %ptr1259 = ptrtoint ptr %mem1258 to i64
  store i64 %ptr1259, ptr %slot43, align 8
  %mem1260 = alloca i8, i64 8, align 8
  %ptr1261 = ptrtoint ptr %mem1260 to i64
  store i64 %ptr1261, ptr %slot44, align 8
  %mem1262 = alloca i8, i64 8, align 8
  %ptr1263 = ptrtoint ptr %mem1262 to i64
  store i64 %ptr1263, ptr %slot45, align 8
  %mem1264 = alloca i8, i64 8, align 8
  %ptr1265 = ptrtoint ptr %mem1264 to i64
  store i64 %ptr1265, ptr %slot46, align 8
  %mem1266 = alloca i8, i64 8, align 8
  %ptr1267 = ptrtoint ptr %mem1266 to i64
  store i64 %ptr1267, ptr %slot47, align 8
  %mem1268 = alloca i8, i64 40, align 8
  %ptr1269 = ptrtoint ptr %mem1268 to i64
  store i64 %ptr1269, ptr %slot48, align 8
  %mem1270 = alloca i8, i64 40, align 8
  %ptr1271 = ptrtoint ptr %mem1270 to i64
  store i64 %ptr1271, ptr %slot49, align 8
  %mem1272 = alloca i8, i64 104, align 8
  %ptr1273 = ptrtoint ptr %mem1272 to i64
  store i64 %ptr1273, ptr %slot50, align 8
  %mem1274 = alloca i8, i64 104, align 8
  %ptr1275 = ptrtoint ptr %mem1274 to i64
  store i64 %ptr1275, ptr %slot51, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1276 = alloca i8, i64 8, align 8
  %ptr1277 = ptrtoint ptr %mem1276 to i64
  store i64 %ptr1277, ptr %slot52, align 8
  %v1278 = load i64, ptr %slot1, align 8
  %op1279 = add i64 %v1278, 64
  store i64 %op1279, ptr %slot53, align 8
  %v1280 = load i64, ptr %slot53, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  %ld1282 = load i64, ptr %p1281, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1282, ptr %slot54, align 8
  %stack1283 = call ptr @llvm.stacksave()
  %stackaddr1284 = ptrtoint ptr %stack1283 to i64
  %v1285 = load i64, ptr %slot54, align 8
  %cmp1286 = icmp ult i64 %stackaddr1284, %v1285
  %cv1287 = zext i1 %cmp1286 to i64
  store i64 %cv1287, ptr %slot55, align 8
  %v1288 = load i64, ptr %slot55, align 8
  %cond1289 = icmp ne i64 %v1288, 0
  br i1 %cond1289, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1290 = load i64, ptr %slot1, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  call void @myl_qbe_fail_frame(ptr %p1291) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1292 = load i64, ptr %slot35, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i64 0, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot38, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  store i64 0, ptr %p1295, align 8, !alias.scope !3, !noalias !4
  %v1296 = load i64, ptr %slot39, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i64 0, ptr %p1297, align 8, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot2, align 8
  %v1299 = load i64, ptr %slot32, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  store i64 %v1298, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  %v1301 = load i64, ptr %slot3, align 8
  %v1302 = load i64, ptr %slot33, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i64 %v1301, ptr %p1303, align 8, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot4, align 8
  %v1305 = load i64, ptr %slot34, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i64 %v1304, ptr %p1306, align 8, !alias.scope !3, !noalias !4
  %v1307 = load i64, ptr %slot1, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %call1309 = call ptr @myl_qbe_heap(ptr %p1308) nomerge, !dbg !112
  %calladdr1310 = ptrtoint ptr %call1309 to i64
  store i64 %calladdr1310, ptr %slot56, align 8
  %v1311 = load i64, ptr %slot1, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %call1313 = call i64 @myl_qbe_region_mark(ptr %p1312) nomerge, !dbg !112
  store i64 %call1313, ptr %slot57, align 8
  %v1314 = load i64, ptr %slot6, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  store i32 0, ptr %p1315, align 4, !alias.scope !3, !noalias !4
  %v1316 = load i64, ptr %slot7, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 0, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot8, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 0, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot9, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i32 0, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot10, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i32 0, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot11, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 0, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot12, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 0, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot13, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 0, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot14, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 0, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot15, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 0, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot16, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 0, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot17, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 0, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot18, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 0, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot19, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 0, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot20, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  store i32 0, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot21, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i32 0, ptr %p1345, align 4, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot22, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  store i32 0, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  %v1348 = load i64, ptr %slot23, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  store i32 0, ptr %p1349, align 4, !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot24, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  store i32 0, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot7, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i32 2, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  %v1354 = load i64, ptr %slot9, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  store i32 2, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  %v1356 = load i64, ptr %slot11, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i32 2, ptr %p1357, align 4, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot13, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 2, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1360 = load i64, ptr %slot32, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  %ld1362 = load i64, ptr %p1361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1362, ptr %slot58, align 8
  %v1363 = load i64, ptr %slot58, align 8
  %v1364 = load i64, ptr %slot41, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  store i64 %v1363, ptr %p1365, align 8, !alias.scope !3, !noalias !4
  %v1366 = load i64, ptr %slot41, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  %ld1368 = load i64, ptr %p1367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1368, ptr %slot59, align 8
  %v1369 = load i64, ptr %slot14, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i32, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1371, ptr %slot60, align 8
  %v1372 = load i64, ptr %slot15, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  %ld1374 = load i32, ptr %p1373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1374, ptr %slot61, align 8
  %v1375 = load i32, ptr %slot61, align 8
  %op1376 = and i32 %v1375, 24
  store i32 %op1376, ptr %slot61, align 8
  %v1377 = load i32, ptr %slot61, align 8
  %cmp1378 = icmp eq i32 %v1377, 0
  %cv1379 = zext i1 %cmp1378 to i32
  store i32 %cv1379, ptr %slot62, align 8
  %v1380 = load i32, ptr %slot60, align 8
  %v1381 = load i32, ptr %slot62, align 8
  %op1382 = and i32 %v1380, %v1381
  store i32 %op1382, ptr %slot63, align 8
  %v1383 = load i64, ptr %slot57, align 8
  store i64 %v1383, ptr %slot64, align 8
  %v1384 = load i32, ptr %slot63, align 8
  %op1385 = mul i32 %v1384, 4
  store i32 %op1385, ptr %slot65, align 8
  %v1386 = load i32, ptr %slot65, align 8
  %op1387 = or i32 %v1386, 0
  store i32 %op1387, ptr %slot66, align 8
  %v1388 = load i64, ptr %slot31, align 8
  store i64 %v1388, ptr %slot67, align 8
  %v1389 = load i64, ptr %slot56, align 8
  %v1390 = load i64, ptr %slot67, align 8
  %v1391 = load i64, ptr %slot59, align 8
  %v1392 = load i64, ptr %slot64, align 8
  %cv1393 = trunc i64 %v1392 to i32
  %v1394 = load i32, ptr %slot66, align 8
  %call1395 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_publish(i64 %v1389, i64 %v1390, i64 %v1391, i32 %cv1393, i32 %v1394) nomerge, !dbg !114
  store i32 %call1395, ptr %slot68, align 8
  %v1396 = load i32, ptr %slot68, align 8
  %cv1397 = zext i32 %v1396 to i64
  %cond1398 = icmp ne i64 %cv1397, 0
  br i1 %cond1398, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v1399 = load i64, ptr %slot56, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %call1401 = call i32 @myl_rc_take_failure(ptr %p1400) nomerge, !dbg !114
  store i32 %call1401, ptr %slot69, align 8
  %v1402 = load i64, ptr %slot1, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %v1404 = load i32, ptr %slot69, align 8
  %call1405 = call i32 @myl_qbe_rc_status(ptr %p1403, i32 %v1404) nomerge, !dbg !114
  store i32 %call1405, ptr %slot70, align 8
  br label %bb_failure
bb_rcsuccess29:
  %v1406 = load i32, ptr %slot63, align 8
  %cv1407 = zext i32 %v1406 to i64
  %cond1408 = icmp ne i64 %cv1407, 0
  br i1 %cond1408, label %bb_rchtaken32, label %bb_rchcopied32
bb_rchcopied32:
  %v1409 = load i64, ptr %slot14, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %ld1411 = load i32, ptr %p1410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1411, ptr %slot71, align 8
  %v1412 = load i32, ptr %slot71, align 8
  %cv1413 = zext i32 %v1412 to i64
  %cond1414 = icmp ne i64 %cv1413, 0
  br i1 %cond1414, label %bb_rcslotdrop35, label %bb_rcslotdone35
bb_rcslotdrop35:
  %v1415 = load i64, ptr %slot14, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i32 0, ptr %p1416, align 4, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot25, align 8
  store i64 %v1417, ptr %slot72, align 8
  %v1418 = load i64, ptr %slot15, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i32, ptr %p1419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1420, ptr %slot73, align 8
  %v1421 = load i32, ptr %slot73, align 8
  %op1422 = and i32 %v1421, 28
  store i32 %op1422, ptr %slot74, align 8
  %v1423 = load i32, ptr %slot74, align 8
  %cv1424 = zext i32 %v1423 to i64
  %cond1425 = icmp ne i64 %cv1424, 0
  br i1 %cond1425, label %bb_rcslotrole35, label %bb_rcslotowner35
bb_rcslotrole35:
  %v1426 = load i64, ptr %slot56, align 8
  store i64 %v1426, ptr %slot75, align 8
  %v1427 = load i64, ptr %slot75, align 8
  %v1428 = load i64, ptr %slot72, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v1427, i64 %v1428) nomerge, !dbg !114
  br label %bb_rcslotdone35
bb_rcslotowner35:
  %v1429 = load i64, ptr %slot56, align 8
  store i64 %v1429, ptr %slot76, align 8
  %v1430 = load i64, ptr %slot76, align 8
  %v1431 = load i64, ptr %slot72, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v1430, i64 %v1431) nomerge, !dbg !114
  br label %bb_rcslotdone35
bb_rcslotdone35:
  br label %bb_rchprepared32
bb_rchtaken32:
  %v1432 = load i64, ptr %slot14, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  store i32 0, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared32
bb_rchprepared32:
  %v1434 = load i64, ptr %slot23, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  store i32 2, ptr %p1435, align 4, !alias.scope !3, !noalias !4
  %v1436 = load i64, ptr %slot22, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i32 1, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot25, align 8
  store i64 %v1438, ptr %slot77, align 8
  %v1439 = load i64, ptr %slot31, align 8
  store i64 %v1439, ptr %slot78, align 8
  %v1440 = load i64, ptr %slot78, align 8
  %v1441 = load i64, ptr %slot77, align 8
  %p1442 = inttoptr i64 %v1440 to ptr
  %p1443 = inttoptr i64 %v1441 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1443, ptr %p1442, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot15, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 2, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot23, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  %ld1448 = load i32, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1448, ptr %slot79, align 8
  %v1449 = load i32, ptr %slot79, align 8
  %v1450 = load i64, ptr %slot15, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i32 %v1449, ptr %p1451, align 4, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot22, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 0, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot14, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  store i32 1, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  %v1456 = load i64, ptr %slot77, align 8
  %v1457 = load i64, ptr %slot41, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i64 %v1456, ptr %p1458, align 8, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot33, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i64, ptr %p1460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1461, ptr %slot80, align 8
  %v1462 = load i64, ptr %slot80, align 8
  %v1463 = load i64, ptr %slot42, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i64 %v1462, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot34, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  %ld1467 = load i64, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1467, ptr %slot81, align 8
  %v1468 = load i64, ptr %slot81, align 8
  %v1469 = load i64, ptr %slot43, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  store i64 %v1468, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  %v1471 = load i64, ptr %slot43, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  %ld1473 = load i64, ptr %p1472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1473, ptr %slot82, align 8
  %v1474 = load i64, ptr %slot18, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  %ld1476 = load i32, ptr %p1475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1476, ptr %slot83, align 8
  %v1477 = load i64, ptr %slot19, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i32, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1479, ptr %slot84, align 8
  %v1480 = load i32, ptr %slot84, align 8
  %op1481 = and i32 %v1480, 24
  store i32 %op1481, ptr %slot84, align 8
  %v1482 = load i32, ptr %slot84, align 8
  %cmp1483 = icmp eq i32 %v1482, 0
  %cv1484 = zext i1 %cmp1483 to i32
  store i32 %cv1484, ptr %slot85, align 8
  %v1485 = load i32, ptr %slot83, align 8
  %v1486 = load i32, ptr %slot85, align 8
  %op1487 = and i32 %v1485, %v1486
  store i32 %op1487, ptr %slot86, align 8
  %v1488 = load i64, ptr %slot57, align 8
  store i64 %v1488, ptr %slot87, align 8
  %v1489 = load i32, ptr %slot86, align 8
  %op1490 = mul i32 %v1489, 4
  store i32 %op1490, ptr %slot88, align 8
  %v1491 = load i32, ptr %slot88, align 8
  %op1492 = or i32 %v1491, 0
  store i32 %op1492, ptr %slot89, align 8
  %v1493 = load i64, ptr %slot31, align 8
  store i64 %v1493, ptr %slot90, align 8
  %v1494 = load i64, ptr %slot56, align 8
  %v1495 = load i64, ptr %slot90, align 8
  %v1496 = load i64, ptr %slot82, align 8
  %v1497 = load i64, ptr %slot87, align 8
  %cv1498 = trunc i64 %v1497 to i32
  %v1499 = load i32, ptr %slot89, align 8
  %call1500 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v1494, i64 %v1495, i64 %v1496, i32 %cv1498, i32 %v1499) nomerge, !dbg !116
  store i32 %call1500, ptr %slot91, align 8
  %v1501 = load i32, ptr %slot91, align 8
  %cv1502 = zext i32 %v1501 to i64
  %cond1503 = icmp ne i64 %cv1502, 0
  br i1 %cond1503, label %bb_rcsuccess69, label %bb_rcfailure69
bb_rcfailure69:
  %v1504 = load i64, ptr %slot56, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  %call1506 = call i32 @myl_rc_take_failure(ptr %p1505) nomerge, !dbg !116
  store i32 %call1506, ptr %slot92, align 8
  %v1507 = load i64, ptr %slot1, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  %v1509 = load i32, ptr %slot92, align 8
  %call1510 = call i32 @myl_qbe_rc_status(ptr %p1508, i32 %v1509) nomerge, !dbg !116
  store i32 %call1510, ptr %slot93, align 8
  br label %bb_failure
bb_rcsuccess69:
  %v1511 = load i32, ptr %slot86, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rchtaken72, label %bb_rchcopied72
bb_rchcopied72:
  %v1514 = load i64, ptr %slot18, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %ld1516 = load i32, ptr %p1515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1516, ptr %slot94, align 8
  %v1517 = load i32, ptr %slot94, align 8
  %cv1518 = zext i32 %v1517 to i64
  %cond1519 = icmp ne i64 %cv1518, 0
  br i1 %cond1519, label %bb_rcslotdrop75, label %bb_rcslotdone75
bb_rcslotdrop75:
  %v1520 = load i64, ptr %slot18, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  store i32 0, ptr %p1521, align 4, !alias.scope !3, !noalias !4
  %v1522 = load i64, ptr %slot27, align 8
  store i64 %v1522, ptr %slot95, align 8
  %v1523 = load i64, ptr %slot19, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  %ld1525 = load i32, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1525, ptr %slot96, align 8
  %v1526 = load i32, ptr %slot96, align 8
  %op1527 = and i32 %v1526, 28
  store i32 %op1527, ptr %slot97, align 8
  %v1528 = load i32, ptr %slot97, align 8
  %cv1529 = zext i32 %v1528 to i64
  %cond1530 = icmp ne i64 %cv1529, 0
  br i1 %cond1530, label %bb_rcslotrole75, label %bb_rcslotowner75
bb_rcslotrole75:
  %v1531 = load i64, ptr %slot56, align 8
  store i64 %v1531, ptr %slot98, align 8
  %v1532 = load i64, ptr %slot98, align 8
  %v1533 = load i64, ptr %slot95, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1532, i64 %v1533) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotowner75:
  %v1534 = load i64, ptr %slot56, align 8
  store i64 %v1534, ptr %slot99, align 8
  %v1535 = load i64, ptr %slot99, align 8
  %v1536 = load i64, ptr %slot95, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1535, i64 %v1536) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotdone75:
  br label %bb_rchprepared72
bb_rchtaken72:
  %v1537 = load i64, ptr %slot18, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  store i32 0, ptr %p1538, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared72
bb_rchprepared72:
  %v1539 = load i64, ptr %slot23, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  store i32 2, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  %v1541 = load i64, ptr %slot22, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i32 1, ptr %p1542, align 4, !alias.scope !3, !noalias !4
  %v1543 = load i64, ptr %slot27, align 8
  store i64 %v1543, ptr %slot100, align 8
  %v1544 = load i64, ptr %slot31, align 8
  store i64 %v1544, ptr %slot101, align 8
  %v1545 = load i64, ptr %slot101, align 8
  %v1546 = load i64, ptr %slot100, align 8
  %p1547 = inttoptr i64 %v1545 to ptr
  %p1548 = inttoptr i64 %v1546 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1548, ptr %p1547, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot19, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i32 2, ptr %p1550, align 4, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot23, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i32, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1553, ptr %slot102, align 8
  %v1554 = load i32, ptr %slot102, align 8
  %v1555 = load i64, ptr %slot19, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i32 %v1554, ptr %p1556, align 4, !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot22, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i32 0, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot18, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 1, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot100, align 8
  %v1562 = load i64, ptr %slot43, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  store i64 %v1561, ptr %p1563, align 8, !alias.scope !3, !noalias !4
  %v1564 = load i64, ptr %slot44, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 0, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot44, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  %ld1568 = load i64, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1568, ptr %slot103, align 8
  %v1569 = load i64, ptr %slot103, align 8
  %cmp1570 = icmp sge i64 %v1569, 0
  %cv1571 = zext i1 %cmp1570 to i64
  store i64 %cv1571, ptr %slot104, align 8
  %v1572 = load i64, ptr %slot104, align 8
  %cond1573 = icmp ne i64 %v1572, 0
  br i1 %cond1573, label %bb_success95, label %bb_failed95
bb_failed95:
  %v1574 = load i64, ptr %slot1, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1575) nomerge, !dbg !118
  unreachable
bb_success95:
  %v1576 = load i64, ptr %slot56, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %p1578 = inttoptr i64 ptrtoint (ptr @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e to i64) to ptr
  %v1579 = load i64, ptr %slot103, align 8
  %call1580 = call ptr @myl_native_list_new(ptr %p1577, ptr %p1578, i64 %v1579) nomerge, !dbg !118
  %calladdr1581 = ptrtoint ptr %call1580 to i64
  store i64 %calladdr1581, ptr %slot105, align 8
  %v1582 = load i64, ptr %slot105, align 8
  %cond1583 = icmp ne i64 %v1582, 0
  br i1 %cond1583, label %bb_success97, label %bb_failed97
bb_failed97:
  %v1584 = load i64, ptr %slot1, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1585) nomerge, !dbg !118
  unreachable
bb_success97:
  %v1586 = load i64, ptr %slot105, align 8
  %v1587 = load i64, ptr %slot44, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  store i64 %v1586, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  %v1589 = load i64, ptr %slot44, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %ld1591 = load i64, ptr %p1590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1591, ptr %slot106, align 8
  %v1592 = load i64, ptr %slot106, align 8
  %v1593 = load i64, ptr %slot30, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i64 %v1592, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot30, align 8
  store i64 %v1595, ptr %slot107, align 8
  %v1596 = load i64, ptr %slot31, align 8
  store i64 %v1596, ptr %slot108, align 8
  %v1597 = load i64, ptr %slot107, align 8
  %v1598 = load i64, ptr %slot108, align 8
  %p1599 = inttoptr i64 %v1597 to ptr
  %p1600 = inttoptr i64 %v1598 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1600, ptr %p1599, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1601 = load i64, ptr %slot23, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i32 2, ptr %p1602, align 4, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot22, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  store i32 1, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  %v1605 = load i64, ptr %slot28, align 8
  store i64 %v1605, ptr %slot109, align 8
  %v1606 = load i64, ptr %slot31, align 8
  store i64 %v1606, ptr %slot110, align 8
  %v1607 = load i64, ptr %slot110, align 8
  %v1608 = load i64, ptr %slot109, align 8
  %p1609 = inttoptr i64 %v1607 to ptr
  %p1610 = inttoptr i64 %v1608 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1610, ptr %p1609, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1611 = load i64, ptr %slot21, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  store i32 2, ptr %p1612, align 4, !alias.scope !3, !noalias !4
  %v1613 = load i64, ptr %slot23, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  %ld1615 = load i32, ptr %p1614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1615, ptr %slot111, align 8
  %v1616 = load i32, ptr %slot111, align 8
  %v1617 = load i64, ptr %slot21, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  store i32 %v1616, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  %v1619 = load i64, ptr %slot22, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i32 0, ptr %p1620, align 4, !alias.scope !3, !noalias !4
  %v1621 = load i64, ptr %slot20, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i32 1, ptr %p1622, align 4, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot109, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i64, ptr %p1624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1625, ptr %slot112, align 8
  %v1626 = load i64, ptr %slot112, align 8
  %v1627 = load i64, ptr %slot44, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  store i64 %v1626, ptr %p1628, align 8, !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot44, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i64, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1631, ptr %slot113, align 8
  %v1632 = load i64, ptr %slot113, align 8
  %v1633 = load i64, ptr %slot30, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 %v1632, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot30, align 8
  store i64 %v1635, ptr %slot114, align 8
  %v1636 = load i64, ptr %slot20, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i32, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1638, ptr %slot115, align 8
  %v1639 = load i64, ptr %slot21, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  %ld1641 = load i32, ptr %p1640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1641, ptr %slot116, align 8
  %v1642 = load i32, ptr %slot116, align 8
  %op1643 = and i32 %v1642, 24
  store i32 %op1643, ptr %slot116, align 8
  %v1644 = load i32, ptr %slot116, align 8
  %cmp1645 = icmp eq i32 %v1644, 0
  %cv1646 = zext i1 %cmp1645 to i32
  store i32 %cv1646, ptr %slot117, align 8
  %v1647 = load i32, ptr %slot115, align 8
  %v1648 = load i32, ptr %slot117, align 8
  %op1649 = and i32 %v1647, %v1648
  store i32 %op1649, ptr %slot118, align 8
  %v1650 = load i32, ptr %slot118, align 8
  %cv1651 = zext i32 %v1650 to i64
  %cond1652 = icmp ne i64 %cv1651, 0
  br i1 %cond1652, label %bb_rcprivateown120, label %bb_rcprivateloan120
bb_rcprivateown120:
  %v1653 = load i64, ptr %slot31, align 8
  store i64 %v1653, ptr %slot119, align 8
  %v1654 = load i64, ptr %slot57, align 8
  store i64 %v1654, ptr %slot120, align 8
  %v1655 = load i64, ptr %slot114, align 8
  %v1656 = load i64, ptr %slot119, align 8
  %op1657 = sub i64 %v1655, %v1656
  store i64 %op1657, ptr %slot121, align 8
  %v1658 = load i64, ptr %slot119, align 8
  %v1659 = load i64, ptr %slot114, align 8
  %op1660 = sub i64 %v1658, %v1659
  store i64 %op1660, ptr %slot122, align 8
  %v1661 = load i64, ptr %slot121, align 8
  %cmp1662 = icmp ult i64 %v1661, 8
  %cv1663 = zext i1 %cmp1662 to i32
  store i32 %cv1663, ptr %slot123, align 8
  %v1664 = load i64, ptr %slot122, align 8
  %cmp1665 = icmp ult i64 %v1664, 8
  %cv1666 = zext i1 %cmp1665 to i32
  store i32 %cv1666, ptr %slot124, align 8
  %v1667 = load i32, ptr %slot123, align 8
  %v1668 = load i32, ptr %slot124, align 8
  %op1669 = or i32 %v1667, %v1668
  store i32 %op1669, ptr %slot125, align 8
  %v1670 = load i32, ptr %slot125, align 8
  %cv1671 = zext i32 %v1670 to i64
  %cond1672 = icmp ne i64 %cv1671, 0
  br i1 %cond1672, label %bb_rcmoveslow123, label %bb_rcmovecheck123
bb_rcmovecheck123:
  %v1673 = load i64, ptr %slot114, align 8
  %p1675 = inttoptr i64 %v1673 to ptr
  %gep1676 = getelementptr i8, ptr %p1675, i64 0
  %op1674 = ptrtoint ptr %gep1676 to i64
  store i64 %op1674, ptr %slot126, align 8
  %v1677 = load i64, ptr %slot126, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  %ld1679 = load i64, ptr %p1678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1679, ptr %slot127, align 8
  %v1680 = load i64, ptr %slot127, align 8
  %cmp1681 = icmp ne i64 %v1680, 0
  %cv1682 = zext i1 %cmp1681 to i32
  store i32 %cv1682, ptr %slot128, align 8
  %v1683 = load i32, ptr %slot128, align 8
  %cv1684 = zext i32 %v1683 to i64
  %cond1685 = icmp ne i64 %cv1684, 0
  br i1 %cond1685, label %bb_rcmoveheader131, label %bb_rcmovenext131
bb_rcmoveheader131:
  %v1686 = load i64, ptr %slot127, align 8
  %op1687 = sub i64 %v1686, 16
  store i64 %op1687, ptr %slot129, align 8
  %v1688 = load i64, ptr %slot127, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %rgep1690 = getelementptr i8, ptr %p1689, i64 -16
  %ld1691 = load i64, ptr %rgep1690, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1691, ptr %slot130, align 8
  %v1692 = load i64, ptr %slot130, align 8
  %op1693 = and i64 %v1692, 5764607523034234881
  store i64 %op1693, ptr %slot131, align 8
  %v1694 = load i64, ptr %slot131, align 8
  %cmp1695 = icmp ne i64 %v1694, 0
  %cv1696 = zext i1 %cmp1695 to i32
  store i32 %cv1696, ptr %slot132, align 8
  %v1697 = load i32, ptr %slot132, align 8
  %cv1698 = zext i32 %v1697 to i64
  %cond1699 = icmp ne i64 %cv1698, 0
  br i1 %cond1699, label %bb_rcmoveslow123, label %bb_rcmovenext131
bb_rcmovenext131:
  %v1700 = load i64, ptr %slot114, align 8
  %v1701 = load i64, ptr %slot119, align 8
  %p1702 = inttoptr i64 %v1700 to ptr
  %p1703 = inttoptr i64 %v1701 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1703, ptr %p1702, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1704 = load i64, ptr %slot114, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i64 0, ptr %p1705, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved123
bb_rcmoveslow123:
  %v1706 = load i64, ptr %slot56, align 8
  %v1707 = load i64, ptr %slot119, align 8
  %v1708 = load i64, ptr %slot114, align 8
  %v1709 = load i64, ptr %slot120, align 8
  %cv1710 = trunc i64 %v1709 to i32
  %call1711 = call i32 @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_take(i64 %v1706, i64 %v1707, i64 %v1708, i32 %cv1710) nomerge, !dbg !120
  store i32 %call1711, ptr %slot133, align 8
  %v1712 = load i32, ptr %slot133, align 8
  %cv1713 = zext i32 %v1712 to i64
  %cond1714 = icmp ne i64 %cv1713, 0
  br i1 %cond1714, label %bb_rcsuccess138, label %bb_rcfailure138
bb_rcfailure138:
  %v1715 = load i64, ptr %slot56, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %call1717 = call i32 @myl_rc_take_failure(ptr %p1716) nomerge, !dbg !120
  store i32 %call1717, ptr %slot134, align 8
  %v1718 = load i64, ptr %slot1, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %v1720 = load i32, ptr %slot134, align 8
  %call1721 = call i32 @myl_qbe_rc_status(ptr %p1719, i32 %v1720) nomerge, !dbg !120
  store i32 %call1721, ptr %slot135, align 8
  br label %bb_failure
bb_rcsuccess138:
  br label %bb_rcmoved123
bb_rcmoved123:
  %v1722 = load i64, ptr %slot20, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i32 0, ptr %p1723, align 4, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot23, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 2, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot22, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 1, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivateloan120:
  %v1728 = load i64, ptr %slot20, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  %ld1730 = load i32, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1730, ptr %slot136, align 8
  %v1731 = load i64, ptr %slot21, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i32, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1733, ptr %slot137, align 8
  %v1734 = load i32, ptr %slot137, align 8
  %cmp1735 = icmp eq i32 %v1734, 16
  %cv1736 = zext i1 %cmp1735 to i32
  store i32 %cv1736, ptr %slot138, align 8
  %v1737 = load i32, ptr %slot138, align 8
  %v1738 = load i32, ptr %slot136, align 8
  %op1739 = and i32 %v1737, %v1738
  store i32 %op1739, ptr %slot138, align 8
  %v1740 = load i32, ptr %slot138, align 8
  %cv1741 = zext i32 %v1740 to i64
  %cond1742 = icmp ne i64 %cv1741, 0
  br i1 %cond1742, label %bb_rcprivatemove120, label %bb_rcprivatenew120
bb_rcprivatemove120:
  %v1743 = load i64, ptr %slot31, align 8
  store i64 %v1743, ptr %slot139, align 8
  %v1744 = load i64, ptr %slot114, align 8
  %v1745 = load i64, ptr %slot139, align 8
  %p1746 = inttoptr i64 %v1744 to ptr
  %p1747 = inttoptr i64 %v1745 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1747, ptr %p1746, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1748 = load i64, ptr %slot114, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  store i64 0, ptr %p1749, align 8, !alias.scope !3, !noalias !4
  %v1750 = load i64, ptr %slot23, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  store i32 2, ptr %p1751, align 4, !alias.scope !3, !noalias !4
  %v1752 = load i64, ptr %slot23, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i32 16, ptr %p1753, align 4, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot22, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 1, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot20, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  store i32 0, ptr %p1757, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivatenew120:
  %v1758 = load i64, ptr %slot31, align 8
  store i64 %v1758, ptr %slot140, align 8
  %v1759 = load i64, ptr %slot114, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %ld1761 = load i64, ptr %p1760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1761, ptr %slot141, align 8
  %v1762 = load i64, ptr %slot141, align 8
  %cmp1763 = icmp ne i64 %v1762, 0
  %cv1764 = zext i1 %cmp1763 to i32
  store i32 %cv1764, ptr %slot142, align 8
  %v1765 = load i32, ptr %slot142, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcgnn156, label %bb_rcgstore156
bb_rcgnn156:
  %v1768 = load i64, ptr %slot141, align 8
  %op1769 = sub i64 %v1768, 16
  store i64 %op1769, ptr %slot143, align 8
  %v1770 = load i64, ptr %slot141, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  %rgep1772 = getelementptr i8, ptr %p1771, i64 -16
  %ld1773 = load i64, ptr %rgep1772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1773, ptr %slot144, align 8
  %v1774 = load i64, ptr %slot144, align 8
  %op1775 = and i64 %v1774, 4611686018427387906
  store i64 %op1775, ptr %slot145, align 8
  %v1776 = load i64, ptr %slot145, align 8
  %cmp1777 = icmp ne i64 %v1776, 0
  %cv1778 = zext i1 %cmp1777 to i32
  store i32 %cv1778, ptr %slot146, align 8
  %v1779 = load i32, ptr %slot146, align 8
  %cv1780 = zext i32 %v1779 to i64
  %cond1781 = icmp ne i64 %cv1780, 0
  br i1 %cond1781, label %bb_rcgstore156, label %bb_rcginc156
bb_rcginc156:
  %v1782 = load i64, ptr %slot141, align 8
  %op1783 = sub i64 %v1782, 24
  store i64 %op1783, ptr %slot147, align 8
  %v1784 = load i64, ptr %slot141, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  %rgep1786 = getelementptr i8, ptr %p1785, i64 -24
  %ld1787 = load i64, ptr %rgep1786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1787, ptr %slot148, align 8
  %v1788 = load i64, ptr %slot148, align 8
  %op1789 = add i64 %v1788, 1
  store i64 %op1789, ptr %slot149, align 8
  %v1790 = load i64, ptr %slot149, align 8
  %cmp1791 = icmp eq i64 %v1790, 0
  %cv1792 = zext i1 %cmp1791 to i32
  store i32 %cv1792, ptr %slot150, align 8
  %v1793 = load i32, ptr %slot150, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcglimit156, label %bb_rcgcapacity156
bb_rcglimit156:
  %v1796 = load i64, ptr %slot1, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  %call1798 = call i32 @myl_qbe_rc_status(ptr %p1797, i32 2) nomerge, !dbg !120
  store i32 %call1798, ptr %slot151, align 8
  br label %bb_failure
bb_rcgcapacity156:
  %v1799 = load i64, ptr %slot149, align 8
  %v1800 = load i64, ptr %slot141, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %rgep1802 = getelementptr i8, ptr %p1801, i64 -24
  store i64 %v1799, ptr %rgep1802, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore156
bb_rcgstore156:
  %v1803 = load i64, ptr %slot141, align 8
  %v1804 = load i64, ptr %slot140, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  store i64 %v1803, ptr %p1805, align 8, !alias.scope !3, !noalias !4
  %v1806 = load i64, ptr %slot23, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i32 2, ptr %p1807, align 4, !alias.scope !3, !noalias !4
  %v1808 = load i64, ptr %slot23, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  store i32 16, ptr %p1809, align 4, !alias.scope !3, !noalias !4
  %v1810 = load i64, ptr %slot22, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  store i32 1, ptr %p1811, align 4, !alias.scope !3, !noalias !4
  %v1812 = load i64, ptr %slot20, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %ld1814 = load i32, ptr %p1813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1814, ptr %slot152, align 8
  %v1815 = load i32, ptr %slot152, align 8
  %cv1816 = zext i32 %v1815 to i64
  %cond1817 = icmp ne i64 %cv1816, 0
  br i1 %cond1817, label %bb_rcslotdrop172, label %bb_rcslotdone172
bb_rcslotdrop172:
  %v1818 = load i64, ptr %slot20, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  store i32 0, ptr %p1819, align 4, !alias.scope !3, !noalias !4
  %v1820 = load i64, ptr %slot28, align 8
  store i64 %v1820, ptr %slot153, align 8
  %v1821 = load i64, ptr %slot21, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  %ld1823 = load i32, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1823, ptr %slot154, align 8
  %v1824 = load i32, ptr %slot154, align 8
  %op1825 = and i32 %v1824, 28
  store i32 %op1825, ptr %slot155, align 8
  %v1826 = load i32, ptr %slot155, align 8
  %cv1827 = zext i32 %v1826 to i64
  %cond1828 = icmp ne i64 %cv1827, 0
  br i1 %cond1828, label %bb_rcslotrole172, label %bb_rcslotowner172
bb_rcslotrole172:
  %v1829 = load i64, ptr %slot56, align 8
  store i64 %v1829, ptr %slot156, align 8
  %v1830 = load i64, ptr %slot153, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %ld1832 = load i64, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1832, ptr %slot157, align 8
  %v1833 = load i64, ptr %slot157, align 8
  %cmp1834 = icmp ne i64 %v1833, 0
  %cv1835 = zext i1 %cmp1834 to i32
  store i32 %cv1835, ptr %slot158, align 8
  %v1836 = load i32, ptr %slot158, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcgnn188, label %bb_rcgdone188
bb_rcgnn188:
  %v1839 = load i64, ptr %slot157, align 8
  %op1840 = sub i64 %v1839, 16
  store i64 %op1840, ptr %slot159, align 8
  %v1841 = load i64, ptr %slot157, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %rgep1843 = getelementptr i8, ptr %p1842, i64 -16
  %ld1844 = load i64, ptr %rgep1843, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1844, ptr %slot160, align 8
  %v1845 = load i64, ptr %slot160, align 8
  %op1846 = and i64 %v1845, 4611686018427387906
  store i64 %op1846, ptr %slot161, align 8
  %v1847 = load i64, ptr %slot161, align 8
  %cmp1848 = icmp ne i64 %v1847, 0
  %cv1849 = zext i1 %cmp1848 to i32
  store i32 %cv1849, ptr %slot162, align 8
  %v1850 = load i32, ptr %slot162, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcgclear188, label %bb_rcgcounted188
bb_rcgcounted188:
  %v1853 = load i64, ptr %slot157, align 8
  %op1854 = sub i64 %v1853, 24
  store i64 %op1854, ptr %slot163, align 8
  %v1855 = load i64, ptr %slot157, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %rgep1857 = getelementptr i8, ptr %p1856, i64 -24
  %ld1858 = load i64, ptr %rgep1857, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1858, ptr %slot164, align 8
  %v1859 = load i64, ptr %slot164, align 8
  %op1860 = sub i64 %v1859, 1
  store i64 %op1860, ptr %slot165, align 8
  %v1861 = load i64, ptr %slot165, align 8
  %cmp1862 = icmp eq i64 %v1861, 0
  %cv1863 = zext i1 %cmp1862 to i32
  store i32 %cv1863, ptr %slot166, align 8
  %v1864 = load i32, ptr %slot166, align 8
  %cv1865 = zext i32 %v1864 to i64
  %cond1866 = icmp ne i64 %cv1865, 0
  br i1 %cond1866, label %bb_rcglast188, label %bb_rcgdec188
bb_rcglast188:
  %v1867 = load i64, ptr %slot157, align 8
  %op1868 = sub i64 %v1867, 32
  store i64 %op1868, ptr %slot167, align 8
  %v1869 = load i64, ptr %slot157, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %rgep1871 = getelementptr i8, ptr %p1870, i64 -32
  %ld1872 = load i64, ptr %rgep1871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1872, ptr %slot168, align 8
  %v1873 = load i64, ptr %slot168, align 8
  %cmp1874 = icmp ne i64 %v1873, 0
  %cv1875 = zext i1 %cmp1874 to i32
  store i32 %cv1875, ptr %slot169, align 8
  %v1876 = load i32, ptr %slot169, align 8
  %cv1877 = zext i32 %v1876 to i64
  %cond1878 = icmp ne i64 %cv1877, 0
  br i1 %cond1878, label %bb_rcgdec188, label %bb_rcgslow188
bb_rcgslow188:
  %v1879 = load i64, ptr %slot156, align 8
  %v1880 = load i64, ptr %slot153, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v1879, i64 %v1880) nomerge, !dbg !120
  br label %bb_rcgdone188
bb_rcgdec188:
  %v1881 = load i64, ptr %slot165, align 8
  %v1882 = load i64, ptr %slot157, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %rgep1884 = getelementptr i8, ptr %p1883, i64 -24
  store i64 %v1881, ptr %rgep1884, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear188
bb_rcgclear188:
  %v1885 = load i64, ptr %slot153, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i64 0, ptr %p1886, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone188
bb_rcgdone188:
  br label %bb_rcslotdone172
bb_rcslotowner172:
  %v1887 = load i64, ptr %slot56, align 8
  store i64 %v1887, ptr %slot170, align 8
  %v1888 = load i64, ptr %slot153, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %ld1890 = load i64, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1890, ptr %slot171, align 8
  %v1891 = load i64, ptr %slot171, align 8
  %cmp1892 = icmp ne i64 %v1891, 0
  %cv1893 = zext i1 %cmp1892 to i32
  store i32 %cv1893, ptr %slot172, align 8
  %v1894 = load i32, ptr %slot172, align 8
  %cv1895 = zext i32 %v1894 to i64
  %cond1896 = icmp ne i64 %cv1895, 0
  br i1 %cond1896, label %bb_rcgnn203, label %bb_rcgdone203
bb_rcgnn203:
  %v1897 = load i64, ptr %slot171, align 8
  %op1898 = sub i64 %v1897, 16
  store i64 %op1898, ptr %slot173, align 8
  %v1899 = load i64, ptr %slot171, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %rgep1901 = getelementptr i8, ptr %p1900, i64 -16
  %ld1902 = load i64, ptr %rgep1901, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1902, ptr %slot174, align 8
  %v1903 = load i64, ptr %slot174, align 8
  %op1904 = and i64 %v1903, 4611686018427387906
  store i64 %op1904, ptr %slot175, align 8
  %v1905 = load i64, ptr %slot175, align 8
  %cmp1906 = icmp ne i64 %v1905, 0
  %cv1907 = zext i1 %cmp1906 to i32
  store i32 %cv1907, ptr %slot176, align 8
  %v1908 = load i32, ptr %slot176, align 8
  %cv1909 = zext i32 %v1908 to i64
  %cond1910 = icmp ne i64 %cv1909, 0
  br i1 %cond1910, label %bb_rcgclear203, label %bb_rcgcounted203
bb_rcgcounted203:
  %v1911 = load i64, ptr %slot171, align 8
  %op1912 = sub i64 %v1911, 32
  store i64 %op1912, ptr %slot177, align 8
  %v1913 = load i64, ptr %slot171, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %rgep1915 = getelementptr i8, ptr %p1914, i64 -32
  %ld1916 = load i64, ptr %rgep1915, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1916, ptr %slot178, align 8
  %v1917 = load i64, ptr %slot178, align 8
  %op1918 = sub i64 %v1917, 1
  store i64 %op1918, ptr %slot179, align 8
  %v1919 = load i64, ptr %slot179, align 8
  %cmp1920 = icmp eq i64 %v1919, 0
  %cv1921 = zext i1 %cmp1920 to i32
  store i32 %cv1921, ptr %slot180, align 8
  %v1922 = load i32, ptr %slot180, align 8
  %cv1923 = zext i32 %v1922 to i64
  %cond1924 = icmp ne i64 %cv1923, 0
  br i1 %cond1924, label %bb_rcglast203, label %bb_rcgdec203
bb_rcglast203:
  %v1925 = load i64, ptr %slot171, align 8
  %op1926 = sub i64 %v1925, 24
  store i64 %op1926, ptr %slot181, align 8
  %v1927 = load i64, ptr %slot171, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %rgep1929 = getelementptr i8, ptr %p1928, i64 -24
  %ld1930 = load i64, ptr %rgep1929, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1930, ptr %slot182, align 8
  %v1931 = load i64, ptr %slot182, align 8
  %cmp1932 = icmp ne i64 %v1931, 0
  %cv1933 = zext i1 %cmp1932 to i32
  store i32 %cv1933, ptr %slot183, align 8
  %v1934 = load i32, ptr %slot183, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcgdec203, label %bb_rcgslow203
bb_rcgslow203:
  %v1937 = load i64, ptr %slot170, align 8
  %v1938 = load i64, ptr %slot153, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v1937, i64 %v1938) nomerge, !dbg !120
  br label %bb_rcgdone203
bb_rcgdec203:
  %v1939 = load i64, ptr %slot179, align 8
  %v1940 = load i64, ptr %slot171, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %rgep1942 = getelementptr i8, ptr %p1941, i64 -32
  store i64 %v1939, ptr %rgep1942, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear203
bb_rcgclear203:
  %v1943 = load i64, ptr %slot153, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i64 0, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone203
bb_rcgdone203:
  br label %bb_rcslotdone172
bb_rcslotdone172:
  br label %bb_rcprivateprepared120
bb_rcprivateprepared120:
  %v1945 = load i64, ptr %slot6, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %ld1947 = load i32, ptr %p1946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1947, ptr %slot184, align 8
  %v1948 = load i32, ptr %slot184, align 8
  %cv1949 = zext i32 %v1948 to i64
  %cond1950 = icmp ne i64 %cv1949, 0
  br i1 %cond1950, label %bb_rcslotdrop210, label %bb_rcslotdone210
bb_rcslotdrop210:
  %v1951 = load i64, ptr %slot6, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  store i32 0, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  %v1953 = load i64, ptr %slot35, align 8
  store i64 %v1953, ptr %slot185, align 8
  %v1954 = load i64, ptr %slot7, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  %ld1956 = load i32, ptr %p1955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1956, ptr %slot186, align 8
  %v1957 = load i32, ptr %slot186, align 8
  %op1958 = and i32 %v1957, 28
  store i32 %op1958, ptr %slot187, align 8
  %v1959 = load i32, ptr %slot187, align 8
  %cv1960 = zext i32 %v1959 to i64
  %cond1961 = icmp ne i64 %cv1960, 0
  br i1 %cond1961, label %bb_rcslotrole210, label %bb_rcslotowner210
bb_rcslotrole210:
  %v1962 = load i64, ptr %slot56, align 8
  store i64 %v1962, ptr %slot188, align 8
  %v1963 = load i64, ptr %slot185, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %ld1965 = load i64, ptr %p1964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1965, ptr %slot189, align 8
  %v1966 = load i64, ptr %slot189, align 8
  %cmp1967 = icmp ne i64 %v1966, 0
  %cv1968 = zext i1 %cmp1967 to i32
  store i32 %cv1968, ptr %slot190, align 8
  %v1969 = load i32, ptr %slot190, align 8
  %cv1970 = zext i32 %v1969 to i64
  %cond1971 = icmp ne i64 %cv1970, 0
  br i1 %cond1971, label %bb_rcgnn226, label %bb_rcgdone226
bb_rcgnn226:
  %v1972 = load i64, ptr %slot189, align 8
  %op1973 = sub i64 %v1972, 16
  store i64 %op1973, ptr %slot191, align 8
  %v1974 = load i64, ptr %slot189, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  %rgep1976 = getelementptr i8, ptr %p1975, i64 -16
  %ld1977 = load i64, ptr %rgep1976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1977, ptr %slot192, align 8
  %v1978 = load i64, ptr %slot192, align 8
  %op1979 = and i64 %v1978, 4611686018427387906
  store i64 %op1979, ptr %slot193, align 8
  %v1980 = load i64, ptr %slot193, align 8
  %cmp1981 = icmp ne i64 %v1980, 0
  %cv1982 = zext i1 %cmp1981 to i32
  store i32 %cv1982, ptr %slot194, align 8
  %v1983 = load i32, ptr %slot194, align 8
  %cv1984 = zext i32 %v1983 to i64
  %cond1985 = icmp ne i64 %cv1984, 0
  br i1 %cond1985, label %bb_rcgclear226, label %bb_rcgcounted226
bb_rcgcounted226:
  %v1986 = load i64, ptr %slot189, align 8
  %op1987 = sub i64 %v1986, 24
  store i64 %op1987, ptr %slot195, align 8
  %v1988 = load i64, ptr %slot189, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %rgep1990 = getelementptr i8, ptr %p1989, i64 -24
  %ld1991 = load i64, ptr %rgep1990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1991, ptr %slot196, align 8
  %v1992 = load i64, ptr %slot196, align 8
  %op1993 = sub i64 %v1992, 1
  store i64 %op1993, ptr %slot197, align 8
  %v1994 = load i64, ptr %slot197, align 8
  %cmp1995 = icmp eq i64 %v1994, 0
  %cv1996 = zext i1 %cmp1995 to i32
  store i32 %cv1996, ptr %slot198, align 8
  %v1997 = load i32, ptr %slot198, align 8
  %cv1998 = zext i32 %v1997 to i64
  %cond1999 = icmp ne i64 %cv1998, 0
  br i1 %cond1999, label %bb_rcglast226, label %bb_rcgdec226
bb_rcglast226:
  %v2000 = load i64, ptr %slot189, align 8
  %op2001 = sub i64 %v2000, 32
  store i64 %op2001, ptr %slot199, align 8
  %v2002 = load i64, ptr %slot189, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %rgep2004 = getelementptr i8, ptr %p2003, i64 -32
  %ld2005 = load i64, ptr %rgep2004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2005, ptr %slot200, align 8
  %v2006 = load i64, ptr %slot200, align 8
  %cmp2007 = icmp ne i64 %v2006, 0
  %cv2008 = zext i1 %cmp2007 to i32
  store i32 %cv2008, ptr %slot201, align 8
  %v2009 = load i32, ptr %slot201, align 8
  %cv2010 = zext i32 %v2009 to i64
  %cond2011 = icmp ne i64 %cv2010, 0
  br i1 %cond2011, label %bb_rcgdec226, label %bb_rcgslow226
bb_rcgslow226:
  %v2012 = load i64, ptr %slot188, align 8
  %v2013 = load i64, ptr %slot185, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v2012, i64 %v2013) nomerge, !dbg !120
  br label %bb_rcgdone226
bb_rcgdec226:
  %v2014 = load i64, ptr %slot197, align 8
  %v2015 = load i64, ptr %slot189, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  %rgep2017 = getelementptr i8, ptr %p2016, i64 -24
  store i64 %v2014, ptr %rgep2017, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear226
bb_rcgclear226:
  %v2018 = load i64, ptr %slot185, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i64 0, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone226
bb_rcgdone226:
  br label %bb_rcslotdone210
bb_rcslotowner210:
  %v2020 = load i64, ptr %slot56, align 8
  store i64 %v2020, ptr %slot202, align 8
  %v2021 = load i64, ptr %slot185, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i64, ptr %p2022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2023, ptr %slot203, align 8
  %v2024 = load i64, ptr %slot203, align 8
  %cmp2025 = icmp ne i64 %v2024, 0
  %cv2026 = zext i1 %cmp2025 to i32
  store i32 %cv2026, ptr %slot204, align 8
  %v2027 = load i32, ptr %slot204, align 8
  %cv2028 = zext i32 %v2027 to i64
  %cond2029 = icmp ne i64 %cv2028, 0
  br i1 %cond2029, label %bb_rcgnn241, label %bb_rcgdone241
bb_rcgnn241:
  %v2030 = load i64, ptr %slot203, align 8
  %op2031 = sub i64 %v2030, 16
  store i64 %op2031, ptr %slot205, align 8
  %v2032 = load i64, ptr %slot203, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %rgep2034 = getelementptr i8, ptr %p2033, i64 -16
  %ld2035 = load i64, ptr %rgep2034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2035, ptr %slot206, align 8
  %v2036 = load i64, ptr %slot206, align 8
  %op2037 = and i64 %v2036, 4611686018427387906
  store i64 %op2037, ptr %slot207, align 8
  %v2038 = load i64, ptr %slot207, align 8
  %cmp2039 = icmp ne i64 %v2038, 0
  %cv2040 = zext i1 %cmp2039 to i32
  store i32 %cv2040, ptr %slot208, align 8
  %v2041 = load i32, ptr %slot208, align 8
  %cv2042 = zext i32 %v2041 to i64
  %cond2043 = icmp ne i64 %cv2042, 0
  br i1 %cond2043, label %bb_rcgclear241, label %bb_rcgcounted241
bb_rcgcounted241:
  %v2044 = load i64, ptr %slot203, align 8
  %op2045 = sub i64 %v2044, 32
  store i64 %op2045, ptr %slot209, align 8
  %v2046 = load i64, ptr %slot203, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  %rgep2048 = getelementptr i8, ptr %p2047, i64 -32
  %ld2049 = load i64, ptr %rgep2048, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2049, ptr %slot210, align 8
  %v2050 = load i64, ptr %slot210, align 8
  %op2051 = sub i64 %v2050, 1
  store i64 %op2051, ptr %slot211, align 8
  %v2052 = load i64, ptr %slot211, align 8
  %cmp2053 = icmp eq i64 %v2052, 0
  %cv2054 = zext i1 %cmp2053 to i32
  store i32 %cv2054, ptr %slot212, align 8
  %v2055 = load i32, ptr %slot212, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcglast241, label %bb_rcgdec241
bb_rcglast241:
  %v2058 = load i64, ptr %slot203, align 8
  %op2059 = sub i64 %v2058, 24
  store i64 %op2059, ptr %slot213, align 8
  %v2060 = load i64, ptr %slot203, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %rgep2062 = getelementptr i8, ptr %p2061, i64 -24
  %ld2063 = load i64, ptr %rgep2062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2063, ptr %slot214, align 8
  %v2064 = load i64, ptr %slot214, align 8
  %cmp2065 = icmp ne i64 %v2064, 0
  %cv2066 = zext i1 %cmp2065 to i32
  store i32 %cv2066, ptr %slot215, align 8
  %v2067 = load i32, ptr %slot215, align 8
  %cv2068 = zext i32 %v2067 to i64
  %cond2069 = icmp ne i64 %cv2068, 0
  br i1 %cond2069, label %bb_rcgdec241, label %bb_rcgslow241
bb_rcgslow241:
  %v2070 = load i64, ptr %slot202, align 8
  %v2071 = load i64, ptr %slot185, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v2070, i64 %v2071) nomerge, !dbg !120
  br label %bb_rcgdone241
bb_rcgdec241:
  %v2072 = load i64, ptr %slot211, align 8
  %v2073 = load i64, ptr %slot203, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  %rgep2075 = getelementptr i8, ptr %p2074, i64 -32
  store i64 %v2072, ptr %rgep2075, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear241
bb_rcgclear241:
  %v2076 = load i64, ptr %slot185, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i64 0, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone241
bb_rcgdone241:
  br label %bb_rcslotdone210
bb_rcslotdone210:
  %v2078 = load i64, ptr %slot35, align 8
  store i64 %v2078, ptr %slot216, align 8
  %v2079 = load i64, ptr %slot31, align 8
  store i64 %v2079, ptr %slot217, align 8
  %v2080 = load i64, ptr %slot217, align 8
  %v2081 = load i64, ptr %slot216, align 8
  %p2082 = inttoptr i64 %v2080 to ptr
  %p2083 = inttoptr i64 %v2081 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2083, ptr %p2082, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot22, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i32 0, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot7, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 2, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot23, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i32, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2090, ptr %slot218, align 8
  %v2091 = load i32, ptr %slot218, align 8
  %v2092 = load i64, ptr %slot7, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  store i32 %v2091, ptr %p2093, align 4, !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot6, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 1, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot35, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  %ld2098 = load i64, ptr %p2097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2098, ptr %slot219, align 8
  %v2099 = load i64, ptr %slot219, align 8
  %v2100 = load i64, ptr %slot44, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  store i64 %v2099, ptr %p2101, align 8, !alias.scope !3, !noalias !4
  %v2102 = load i64, ptr %slot48, align 8
  store i64 %v2102, ptr %slot220, align 8
  %v2103 = load i64, ptr %slot220, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i32 0, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot220, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 0, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot220, align 8
  %v2108 = load i64, ptr %slot45, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i64 %v2107, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot49, align 8
  store i64 %v2110, ptr %slot221, align 8
  %v2111 = load i64, ptr %slot221, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i32 0, ptr %p2112, align 4, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot221, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  store i32 0, ptr %p2114, align 4, !alias.scope !3, !noalias !4
  %v2115 = load i64, ptr %slot221, align 8
  %v2116 = load i64, ptr %slot46, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  store i64 %v2115, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  %v2118 = load i64, ptr %slot47, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i64 0, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  %v2120 = load i64, ptr %slot50, align 8
  store i64 %v2120, ptr %slot222, align 8
  %v2121 = load i64, ptr %slot222, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  call void @llvm.memset.p0.i64(ptr %p2122, i8 0, i64 104, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v2123 = load i64, ptr %slot24, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  store i32 1, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  %v2125 = load i64, ptr %slot57, align 8
  store i64 %v2125, ptr %slot223, align 8
  %v2126 = load i64, ptr %slot41, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  %ld2128 = load i64, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2128, ptr %slot224, align 8
  %v2129 = load i64, ptr %slot222, align 8
  %p2131 = inttoptr i64 %v2129 to ptr
  %gep2132 = getelementptr i8, ptr %p2131, i64 0
  %op2130 = ptrtoint ptr %gep2132 to i64
  store i64 %op2130, ptr %slot225, align 8
  %v2133 = load i64, ptr %slot41, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  %ld2135 = load i64, ptr %p2134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2135, ptr %slot226, align 8
  %v2136 = load i64, ptr %slot14, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %ld2138 = load i32, ptr %p2137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2138, ptr %slot227, align 8
  %v2139 = load i64, ptr %slot15, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  %ld2141 = load i32, ptr %p2140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2141, ptr %slot228, align 8
  %v2142 = load i32, ptr %slot228, align 8
  %op2143 = and i32 %v2142, 24
  store i32 %op2143, ptr %slot228, align 8
  %v2144 = load i32, ptr %slot228, align 8
  %cmp2145 = icmp eq i32 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot229, align 8
  %v2147 = load i32, ptr %slot227, align 8
  %v2148 = load i32, ptr %slot229, align 8
  %op2149 = and i32 %v2147, %v2148
  store i32 %op2149, ptr %slot230, align 8
  %v2150 = load i32, ptr %slot230, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rctake262, label %bb_rccopy262
bb_rctake262:
  %v2153 = load i64, ptr %slot31, align 8
  store i64 %v2153, ptr %slot231, align 8
  %v2154 = load i64, ptr %slot57, align 8
  store i64 %v2154, ptr %slot232, align 8
  %v2155 = load i64, ptr %slot226, align 8
  %v2156 = load i64, ptr %slot231, align 8
  %op2157 = sub i64 %v2155, %v2156
  store i64 %op2157, ptr %slot233, align 8
  %v2158 = load i64, ptr %slot231, align 8
  %v2159 = load i64, ptr %slot226, align 8
  %op2160 = sub i64 %v2158, %v2159
  store i64 %op2160, ptr %slot234, align 8
  %v2161 = load i64, ptr %slot233, align 8
  %cmp2162 = icmp ult i64 %v2161, 32
  %cv2163 = zext i1 %cmp2162 to i32
  store i32 %cv2163, ptr %slot235, align 8
  %v2164 = load i64, ptr %slot234, align 8
  %cmp2165 = icmp ult i64 %v2164, 32
  %cv2166 = zext i1 %cmp2165 to i32
  store i32 %cv2166, ptr %slot236, align 8
  %v2167 = load i32, ptr %slot235, align 8
  %v2168 = load i32, ptr %slot236, align 8
  %op2169 = or i32 %v2167, %v2168
  store i32 %op2169, ptr %slot237, align 8
  %v2170 = load i32, ptr %slot237, align 8
  %cv2171 = zext i32 %v2170 to i64
  %cond2172 = icmp ne i64 %cv2171, 0
  br i1 %cond2172, label %bb_rcmoveslow271, label %bb_rcmovecheck271
bb_rcmovecheck271:
  %v2173 = load i64, ptr %slot226, align 8
  %op2174 = add i64 %v2173, 0
  store i64 %op2174, ptr %slot238, align 8
  %v2175 = load i64, ptr %slot238, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  %ld2177 = load i64, ptr %p2176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2177, ptr %slot239, align 8
  %v2178 = load i64, ptr %slot239, align 8
  %cmp2179 = icmp ne i64 %v2178, 0
  %cv2180 = zext i1 %cmp2179 to i32
  store i32 %cv2180, ptr %slot240, align 8
  %v2181 = load i32, ptr %slot240, align 8
  %cv2182 = zext i32 %v2181 to i64
  %cond2183 = icmp ne i64 %cv2182, 0
  br i1 %cond2183, label %bb_rcmoveheader279, label %bb_rcmovenext279
bb_rcmoveheader279:
  %v2184 = load i64, ptr %slot239, align 8
  %op2185 = sub i64 %v2184, 16
  store i64 %op2185, ptr %slot241, align 8
  %v2186 = load i64, ptr %slot239, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  %rgep2188 = getelementptr i8, ptr %p2187, i64 -16
  %ld2189 = load i64, ptr %rgep2188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2189, ptr %slot242, align 8
  %v2190 = load i64, ptr %slot242, align 8
  %op2191 = and i64 %v2190, 5764607523034234881
  store i64 %op2191, ptr %slot243, align 8
  %v2192 = load i64, ptr %slot243, align 8
  %cmp2193 = icmp ne i64 %v2192, 0
  %cv2194 = zext i1 %cmp2193 to i32
  store i32 %cv2194, ptr %slot244, align 8
  %v2195 = load i32, ptr %slot244, align 8
  %cv2196 = zext i32 %v2195 to i64
  %cond2197 = icmp ne i64 %cv2196, 0
  br i1 %cond2197, label %bb_rcmoveslow271, label %bb_rcmovenext279
bb_rcmovenext279:
  %v2198 = load i64, ptr %slot226, align 8
  %op2199 = add i64 %v2198, 8
  store i64 %op2199, ptr %slot245, align 8
  %v2200 = load i64, ptr %slot245, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %ld2202 = load i64, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2202, ptr %slot246, align 8
  %v2203 = load i64, ptr %slot246, align 8
  %cmp2204 = icmp ne i64 %v2203, 0
  %cv2205 = zext i1 %cmp2204 to i32
  store i32 %cv2205, ptr %slot247, align 8
  %v2206 = load i32, ptr %slot247, align 8
  %cv2207 = zext i32 %v2206 to i64
  %cond2208 = icmp ne i64 %cv2207, 0
  br i1 %cond2208, label %bb_rcmoveheader287, label %bb_rcmovenext287
bb_rcmoveheader287:
  %v2209 = load i64, ptr %slot246, align 8
  %op2210 = sub i64 %v2209, 16
  store i64 %op2210, ptr %slot248, align 8
  %v2211 = load i64, ptr %slot246, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  %rgep2213 = getelementptr i8, ptr %p2212, i64 -16
  %ld2214 = load i64, ptr %rgep2213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2214, ptr %slot249, align 8
  %v2215 = load i64, ptr %slot249, align 8
  %op2216 = and i64 %v2215, 5764607523034234881
  store i64 %op2216, ptr %slot250, align 8
  %v2217 = load i64, ptr %slot250, align 8
  %cmp2218 = icmp ne i64 %v2217, 0
  %cv2219 = zext i1 %cmp2218 to i32
  store i32 %cv2219, ptr %slot251, align 8
  %v2220 = load i32, ptr %slot251, align 8
  %cv2221 = zext i32 %v2220 to i64
  %cond2222 = icmp ne i64 %cv2221, 0
  br i1 %cond2222, label %bb_rcmoveslow271, label %bb_rcmovenext287
bb_rcmovenext287:
  %v2223 = load i64, ptr %slot226, align 8
  %op2224 = add i64 %v2223, 16
  store i64 %op2224, ptr %slot252, align 8
  %v2225 = load i64, ptr %slot252, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  %ld2227 = load i64, ptr %p2226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2227, ptr %slot253, align 8
  %v2228 = load i64, ptr %slot253, align 8
  %cmp2229 = icmp ne i64 %v2228, 0
  %cv2230 = zext i1 %cmp2229 to i32
  store i32 %cv2230, ptr %slot254, align 8
  %v2231 = load i32, ptr %slot254, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcmoveheader295, label %bb_rcmovenext295
bb_rcmoveheader295:
  %v2234 = load i64, ptr %slot253, align 8
  %op2235 = sub i64 %v2234, 16
  store i64 %op2235, ptr %slot255, align 8
  %v2236 = load i64, ptr %slot253, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %rgep2238 = getelementptr i8, ptr %p2237, i64 -16
  %ld2239 = load i64, ptr %rgep2238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2239, ptr %slot256, align 8
  %v2240 = load i64, ptr %slot256, align 8
  %op2241 = and i64 %v2240, 5764607523034234881
  store i64 %op2241, ptr %slot257, align 8
  %v2242 = load i64, ptr %slot257, align 8
  %cmp2243 = icmp ne i64 %v2242, 0
  %cv2244 = zext i1 %cmp2243 to i32
  store i32 %cv2244, ptr %slot258, align 8
  %v2245 = load i32, ptr %slot258, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcmoveslow271, label %bb_rcmovenext295
bb_rcmovenext295:
  %v2248 = load i64, ptr %slot226, align 8
  %op2249 = add i64 %v2248, 24
  store i64 %op2249, ptr %slot259, align 8
  %v2250 = load i64, ptr %slot259, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i64, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2252, ptr %slot260, align 8
  %v2253 = load i64, ptr %slot260, align 8
  %cmp2254 = icmp ne i64 %v2253, 0
  %cv2255 = zext i1 %cmp2254 to i32
  store i32 %cv2255, ptr %slot261, align 8
  %v2256 = load i32, ptr %slot261, align 8
  %cv2257 = zext i32 %v2256 to i64
  %cond2258 = icmp ne i64 %cv2257, 0
  br i1 %cond2258, label %bb_rcmoveheader303, label %bb_rcmovenext303
bb_rcmoveheader303:
  %v2259 = load i64, ptr %slot260, align 8
  %op2260 = sub i64 %v2259, 16
  store i64 %op2260, ptr %slot262, align 8
  %v2261 = load i64, ptr %slot260, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %rgep2263 = getelementptr i8, ptr %p2262, i64 -16
  %ld2264 = load i64, ptr %rgep2263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2264, ptr %slot263, align 8
  %v2265 = load i64, ptr %slot263, align 8
  %op2266 = and i64 %v2265, 5764607523034234881
  store i64 %op2266, ptr %slot264, align 8
  %v2267 = load i64, ptr %slot264, align 8
  %cmp2268 = icmp ne i64 %v2267, 0
  %cv2269 = zext i1 %cmp2268 to i32
  store i32 %cv2269, ptr %slot265, align 8
  %v2270 = load i32, ptr %slot265, align 8
  %cv2271 = zext i32 %v2270 to i64
  %cond2272 = icmp ne i64 %cv2271, 0
  br i1 %cond2272, label %bb_rcmoveslow271, label %bb_rcmovenext303
bb_rcmovenext303:
  %v2273 = load i64, ptr %slot226, align 8
  %v2274 = load i64, ptr %slot231, align 8
  %p2275 = inttoptr i64 %v2273 to ptr
  %p2276 = inttoptr i64 %v2274 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2276, ptr %p2275, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot226, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i64 0, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot226, align 8
  %op2280 = add i64 %v2279, 8
  store i64 %op2280, ptr %slot266, align 8
  %v2281 = load i64, ptr %slot266, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i64 0, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot226, align 8
  %op2284 = add i64 %v2283, 16
  store i64 %op2284, ptr %slot267, align 8
  %v2285 = load i64, ptr %slot267, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  store i64 0, ptr %p2286, align 8, !alias.scope !3, !noalias !4
  %v2287 = load i64, ptr %slot226, align 8
  %op2288 = add i64 %v2287, 24
  store i64 %op2288, ptr %slot268, align 8
  %v2289 = load i64, ptr %slot268, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i64 0, ptr %p2290, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved271
bb_rcmoveslow271:
  %v2291 = load i64, ptr %slot56, align 8
  %v2292 = load i64, ptr %slot231, align 8
  %v2293 = load i64, ptr %slot226, align 8
  %v2294 = load i64, ptr %slot232, align 8
  %cv2295 = trunc i64 %v2294 to i32
  %call2296 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64 %v2291, i64 %v2292, i64 %v2293, i32 %cv2295) nomerge, !dbg !122
  store i32 %call2296, ptr %slot269, align 8
  %v2297 = load i32, ptr %slot269, align 8
  %cv2298 = zext i32 %v2297 to i64
  %cond2299 = icmp ne i64 %cv2298, 0
  br i1 %cond2299, label %bb_rcsuccess313, label %bb_rcfailure313
bb_rcfailure313:
  %v2300 = load i64, ptr %slot56, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %call2302 = call i32 @myl_rc_take_failure(ptr %p2301) nomerge, !dbg !122
  store i32 %call2302, ptr %slot270, align 8
  %v2303 = load i64, ptr %slot1, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  %v2305 = load i32, ptr %slot270, align 8
  %call2306 = call i32 @myl_qbe_rc_status(ptr %p2304, i32 %v2305) nomerge, !dbg !122
  store i32 %call2306, ptr %slot271, align 8
  br label %bb_failure
bb_rcsuccess313:
  br label %bb_rcmoved271
bb_rcmoved271:
  %v2307 = load i64, ptr %slot14, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i32 0, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot23, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i32 2, ptr %p2310, align 4, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot22, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  store i32 1, ptr %p2312, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared262
bb_rccopy262:
  %v2313 = load i64, ptr %slot31, align 8
  store i64 %v2313, ptr %slot272, align 8
  %v2314 = load i64, ptr %slot57, align 8
  store i64 %v2314, ptr %slot273, align 8
  %v2315 = load i64, ptr %slot56, align 8
  %v2316 = load i64, ptr %slot272, align 8
  %v2317 = load i64, ptr %slot226, align 8
  %v2318 = load i64, ptr %slot273, align 8
  %cv2319 = trunc i64 %v2318 to i32
  %call2320 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_retain(i64 %v2315, i64 %v2316, i64 %v2317, i32 %cv2319) nomerge, !dbg !122
  store i32 %call2320, ptr %slot274, align 8
  %v2321 = load i32, ptr %slot274, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcsuccess322, label %bb_rcfailure322
bb_rcfailure322:
  %v2324 = load i64, ptr %slot56, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %call2326 = call i32 @myl_rc_take_failure(ptr %p2325) nomerge, !dbg !122
  store i32 %call2326, ptr %slot275, align 8
  %v2327 = load i64, ptr %slot1, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %v2329 = load i32, ptr %slot275, align 8
  %call2330 = call i32 @myl_qbe_rc_status(ptr %p2328, i32 %v2329) nomerge, !dbg !122
  store i32 %call2330, ptr %slot276, align 8
  br label %bb_failure
bb_rcsuccess322:
  %v2331 = load i64, ptr %slot23, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 2, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot22, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i32 1, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot14, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  %ld2337 = load i32, ptr %p2336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2337, ptr %slot277, align 8
  %v2338 = load i32, ptr %slot277, align 8
  %cv2339 = zext i32 %v2338 to i64
  %cond2340 = icmp ne i64 %cv2339, 0
  br i1 %cond2340, label %bb_rcslotdrop329, label %bb_rcslotdone329
bb_rcslotdrop329:
  %v2341 = load i64, ptr %slot14, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i32 0, ptr %p2342, align 4, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot25, align 8
  store i64 %v2343, ptr %slot278, align 8
  %v2344 = load i64, ptr %slot15, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  %ld2346 = load i32, ptr %p2345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2346, ptr %slot279, align 8
  %v2347 = load i32, ptr %slot279, align 8
  %op2348 = and i32 %v2347, 28
  store i32 %op2348, ptr %slot280, align 8
  %v2349 = load i32, ptr %slot280, align 8
  %cv2350 = zext i32 %v2349 to i64
  %cond2351 = icmp ne i64 %cv2350, 0
  br i1 %cond2351, label %bb_rcslotrole329, label %bb_rcslotowner329
bb_rcslotrole329:
  %v2352 = load i64, ptr %slot56, align 8
  store i64 %v2352, ptr %slot281, align 8
  %v2353 = load i64, ptr %slot281, align 8
  %v2354 = load i64, ptr %slot278, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v2353, i64 %v2354) nomerge, !dbg !122
  br label %bb_rcslotdone329
bb_rcslotowner329:
  %v2355 = load i64, ptr %slot56, align 8
  store i64 %v2355, ptr %slot282, align 8
  %v2356 = load i64, ptr %slot282, align 8
  %v2357 = load i64, ptr %slot278, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v2356, i64 %v2357) nomerge, !dbg !122
  br label %bb_rcslotdone329
bb_rcslotdone329:
  br label %bb_rcprepared262
bb_rcprepared262:
  %v2358 = load i64, ptr %slot31, align 8
  store i64 %v2358, ptr %slot283, align 8
  %v2359 = load i64, ptr %slot283, align 8
  %v2360 = load i64, ptr %slot225, align 8
  %p2361 = inttoptr i64 %v2359 to ptr
  %p2362 = inttoptr i64 %v2360 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2362, ptr %p2361, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2363 = load i64, ptr %slot22, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  store i32 0, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot42, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i64, ptr %p2366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2367, ptr %slot284, align 8
  %v2368 = load i64, ptr %slot284, align 8
  %v2369 = load i64, ptr %slot29, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  store i64 %v2368, ptr %p2370, align 8, !alias.scope !3, !noalias !4
  %v2371 = load i64, ptr %slot29, align 8
  store i64 %v2371, ptr %slot285, align 8
  %v2372 = load i64, ptr %slot222, align 8
  %p2374 = inttoptr i64 %v2372 to ptr
  %gep2375 = getelementptr i8, ptr %p2374, i64 32
  %op2373 = ptrtoint ptr %gep2375 to i64
  store i64 %op2373, ptr %slot286, align 8
  %v2376 = load i64, ptr %slot42, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  %ld2378 = load i64, ptr %p2377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2378, ptr %slot287, align 8
  %v2379 = load i64, ptr %slot287, align 8
  %v2380 = load i64, ptr %slot29, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i64 %v2379, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot29, align 8
  store i64 %v2382, ptr %slot288, align 8
  %v2383 = load i64, ptr %slot16, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i32, ptr %p2384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2385, ptr %slot289, align 8
  %v2386 = load i64, ptr %slot17, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %ld2388 = load i32, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2388, ptr %slot290, align 8
  %v2389 = load i32, ptr %slot290, align 8
  %op2390 = and i32 %v2389, 24
  store i32 %op2390, ptr %slot290, align 8
  %v2391 = load i32, ptr %slot290, align 8
  %cmp2392 = icmp eq i32 %v2391, 0
  %cv2393 = zext i1 %cmp2392 to i32
  store i32 %cv2393, ptr %slot291, align 8
  %v2394 = load i32, ptr %slot289, align 8
  %v2395 = load i32, ptr %slot291, align 8
  %op2396 = and i32 %v2394, %v2395
  store i32 %op2396, ptr %slot292, align 8
  %v2397 = load i32, ptr %slot292, align 8
  %cv2398 = zext i32 %v2397 to i64
  %cond2399 = icmp ne i64 %cv2398, 0
  br i1 %cond2399, label %bb_rctake343, label %bb_rccopy343
bb_rctake343:
  %v2400 = load i64, ptr %slot31, align 8
  store i64 %v2400, ptr %slot293, align 8
  %v2401 = load i64, ptr %slot57, align 8
  store i64 %v2401, ptr %slot294, align 8
  %v2402 = load i64, ptr %slot288, align 8
  %v2403 = load i64, ptr %slot293, align 8
  %op2404 = sub i64 %v2402, %v2403
  store i64 %op2404, ptr %slot295, align 8
  %v2405 = load i64, ptr %slot293, align 8
  %v2406 = load i64, ptr %slot288, align 8
  %op2407 = sub i64 %v2405, %v2406
  store i64 %op2407, ptr %slot296, align 8
  %v2408 = load i64, ptr %slot295, align 8
  %cmp2409 = icmp ult i64 %v2408, 8
  %cv2410 = zext i1 %cmp2409 to i32
  store i32 %cv2410, ptr %slot297, align 8
  %v2411 = load i64, ptr %slot296, align 8
  %cmp2412 = icmp ult i64 %v2411, 8
  %cv2413 = zext i1 %cmp2412 to i32
  store i32 %cv2413, ptr %slot298, align 8
  %v2414 = load i32, ptr %slot297, align 8
  %v2415 = load i32, ptr %slot298, align 8
  %op2416 = or i32 %v2414, %v2415
  store i32 %op2416, ptr %slot299, align 8
  %v2417 = load i32, ptr %slot299, align 8
  %cv2418 = zext i32 %v2417 to i64
  %cond2419 = icmp ne i64 %cv2418, 0
  br i1 %cond2419, label %bb_rcmoveslow352, label %bb_rcmovecheck352
bb_rcmovecheck352:
  %v2420 = load i64, ptr %slot288, align 8
  %p2422 = inttoptr i64 %v2420 to ptr
  %gep2423 = getelementptr i8, ptr %p2422, i64 0
  %op2421 = ptrtoint ptr %gep2423 to i64
  store i64 %op2421, ptr %slot300, align 8
  %v2424 = load i64, ptr %slot300, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  %ld2426 = load i64, ptr %p2425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2426, ptr %slot301, align 8
  %v2427 = load i64, ptr %slot301, align 8
  %cmp2428 = icmp ne i64 %v2427, 0
  %cv2429 = zext i1 %cmp2428 to i32
  store i32 %cv2429, ptr %slot302, align 8
  %v2430 = load i32, ptr %slot302, align 8
  %cv2431 = zext i32 %v2430 to i64
  %cond2432 = icmp ne i64 %cv2431, 0
  br i1 %cond2432, label %bb_rcmoveheader360, label %bb_rcmovenext360
bb_rcmoveheader360:
  %v2433 = load i64, ptr %slot301, align 8
  %op2434 = sub i64 %v2433, 16
  store i64 %op2434, ptr %slot303, align 8
  %v2435 = load i64, ptr %slot301, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %rgep2437 = getelementptr i8, ptr %p2436, i64 -16
  %ld2438 = load i64, ptr %rgep2437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2438, ptr %slot304, align 8
  %v2439 = load i64, ptr %slot304, align 8
  %op2440 = and i64 %v2439, 5764607523034234881
  store i64 %op2440, ptr %slot305, align 8
  %v2441 = load i64, ptr %slot305, align 8
  %cmp2442 = icmp ne i64 %v2441, 0
  %cv2443 = zext i1 %cmp2442 to i32
  store i32 %cv2443, ptr %slot306, align 8
  %v2444 = load i32, ptr %slot306, align 8
  %cv2445 = zext i32 %v2444 to i64
  %cond2446 = icmp ne i64 %cv2445, 0
  br i1 %cond2446, label %bb_rcmoveslow352, label %bb_rcmovenext360
bb_rcmovenext360:
  %v2447 = load i64, ptr %slot288, align 8
  %v2448 = load i64, ptr %slot293, align 8
  %p2449 = inttoptr i64 %v2447 to ptr
  %p2450 = inttoptr i64 %v2448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2450, ptr %p2449, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot288, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  store i64 0, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved352
bb_rcmoveslow352:
  %v2453 = load i64, ptr %slot56, align 8
  %v2454 = load i64, ptr %slot293, align 8
  %v2455 = load i64, ptr %slot288, align 8
  %v2456 = load i64, ptr %slot294, align 8
  %cv2457 = trunc i64 %v2456 to i32
  %call2458 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2453, i64 %v2454, i64 %v2455, i32 %cv2457) nomerge, !dbg !122
  store i32 %call2458, ptr %slot307, align 8
  %v2459 = load i32, ptr %slot307, align 8
  %cv2460 = zext i32 %v2459 to i64
  %cond2461 = icmp ne i64 %cv2460, 0
  br i1 %cond2461, label %bb_rcsuccess367, label %bb_rcfailure367
bb_rcfailure367:
  %v2462 = load i64, ptr %slot56, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %call2464 = call i32 @myl_rc_take_failure(ptr %p2463) nomerge, !dbg !122
  store i32 %call2464, ptr %slot308, align 8
  %v2465 = load i64, ptr %slot1, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  %v2467 = load i32, ptr %slot308, align 8
  %call2468 = call i32 @myl_qbe_rc_status(ptr %p2466, i32 %v2467) nomerge, !dbg !122
  store i32 %call2468, ptr %slot309, align 8
  br label %bb_failure
bb_rcsuccess367:
  br label %bb_rcmoved352
bb_rcmoved352:
  %v2469 = load i64, ptr %slot16, align 8
  %p2470 = inttoptr i64 %v2469 to ptr
  store i32 0, ptr %p2470, align 4, !alias.scope !3, !noalias !4
  %v2471 = load i64, ptr %slot23, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  store i32 2, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  %v2473 = load i64, ptr %slot22, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  store i32 1, ptr %p2474, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared343
bb_rccopy343:
  %v2475 = load i64, ptr %slot31, align 8
  store i64 %v2475, ptr %slot310, align 8
  %v2476 = load i64, ptr %slot57, align 8
  store i64 %v2476, ptr %slot311, align 8
  %v2477 = load i64, ptr %slot288, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  %ld2479 = load i64, ptr %p2478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2479, ptr %slot312, align 8
  %v2480 = load i64, ptr %slot312, align 8
  %cmp2481 = icmp ne i64 %v2480, 0
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot313, align 8
  %v2483 = load i32, ptr %slot313, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcgnn376, label %bb_rcgplain376
bb_rcgnn376:
  %v2486 = load i64, ptr %slot312, align 8
  %op2487 = sub i64 %v2486, 16
  store i64 %op2487, ptr %slot314, align 8
  %v2488 = load i64, ptr %slot312, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  %rgep2490 = getelementptr i8, ptr %p2489, i64 -16
  %ld2491 = load i64, ptr %rgep2490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2491, ptr %slot315, align 8
  %v2492 = load i64, ptr %slot315, align 8
  %op2493 = and i64 %v2492, 4611686018427387906
  store i64 %op2493, ptr %slot316, align 8
  %v2494 = load i64, ptr %slot316, align 8
  %cmp2495 = icmp ne i64 %v2494, 0
  %cv2496 = zext i1 %cmp2495 to i32
  store i32 %cv2496, ptr %slot317, align 8
  %v2497 = load i32, ptr %slot317, align 8
  %cv2498 = zext i32 %v2497 to i64
  %cond2499 = icmp ne i64 %cv2498, 0
  br i1 %cond2499, label %bb_rcgspecial376, label %bb_rcginc376
bb_rcginc376:
  %v2500 = load i64, ptr %slot312, align 8
  %op2501 = sub i64 %v2500, 32
  store i64 %op2501, ptr %slot318, align 8
  %v2502 = load i64, ptr %slot312, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %rgep2504 = getelementptr i8, ptr %p2503, i64 -32
  %ld2505 = load i64, ptr %rgep2504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2505, ptr %slot319, align 8
  %v2506 = load i64, ptr %slot319, align 8
  %op2507 = add i64 %v2506, 1
  store i64 %op2507, ptr %slot320, align 8
  %v2508 = load i64, ptr %slot320, align 8
  %cmp2509 = icmp eq i64 %v2508, 0
  %cv2510 = zext i1 %cmp2509 to i32
  store i32 %cv2510, ptr %slot321, align 8
  %v2511 = load i32, ptr %slot321, align 8
  %cv2512 = zext i32 %v2511 to i64
  %cond2513 = icmp ne i64 %cv2512, 0
  br i1 %cond2513, label %bb_rcglimit376, label %bb_rcgcapacity376
bb_rcglimit376:
  %v2514 = load i64, ptr %slot1, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %call2516 = call i32 @myl_qbe_rc_status(ptr %p2515, i32 2) nomerge, !dbg !122
  store i32 %call2516, ptr %slot322, align 8
  br label %bb_failure
bb_rcgcapacity376:
  %v2517 = load i64, ptr %slot320, align 8
  %v2518 = load i64, ptr %slot312, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  %rgep2520 = getelementptr i8, ptr %p2519, i64 -32
  store i64 %v2517, ptr %rgep2520, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain376
bb_rcgspecial376:
  %v2521 = load i64, ptr %slot315, align 8
  %op2522 = and i64 %v2521, 4611686018427387904
  store i64 %op2522, ptr %slot323, align 8
  %v2523 = load i64, ptr %slot323, align 8
  %cmp2524 = icmp ne i64 %v2523, 0
  %cv2525 = zext i1 %cmp2524 to i32
  store i32 %cv2525, ptr %slot324, align 8
  %v2526 = load i32, ptr %slot324, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcgslow376, label %bb_rcgplain376
bb_rcgslow376:
  %v2529 = load i64, ptr %slot56, align 8
  %v2530 = load i64, ptr %slot310, align 8
  %v2531 = load i64, ptr %slot288, align 8
  %v2532 = load i64, ptr %slot311, align 8
  %cv2533 = trunc i64 %v2532 to i32
  %call2534 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2529, i64 %v2530, i64 %v2531, i32 %cv2533) nomerge, !dbg !122
  store i32 %call2534, ptr %slot325, align 8
  %v2535 = load i32, ptr %slot325, align 8
  %cv2536 = zext i32 %v2535 to i64
  %cond2537 = icmp ne i64 %cv2536, 0
  br i1 %cond2537, label %bb_rcsuccess390, label %bb_rcfailure390
bb_rcfailure390:
  %v2538 = load i64, ptr %slot56, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %call2540 = call i32 @myl_rc_take_failure(ptr %p2539) nomerge, !dbg !122
  store i32 %call2540, ptr %slot326, align 8
  %v2541 = load i64, ptr %slot1, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %v2543 = load i32, ptr %slot326, align 8
  %call2544 = call i32 @myl_qbe_rc_status(ptr %p2542, i32 %v2543) nomerge, !dbg !122
  store i32 %call2544, ptr %slot327, align 8
  br label %bb_failure
bb_rcsuccess390:
  br label %bb_rcgdone376
bb_rcgplain376:
  %v2545 = load i64, ptr %slot312, align 8
  %v2546 = load i64, ptr %slot310, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  store i64 %v2545, ptr %p2547, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone376
bb_rcgdone376:
  %v2548 = load i64, ptr %slot23, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  store i32 2, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  %v2550 = load i64, ptr %slot22, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  store i32 1, ptr %p2551, align 4, !alias.scope !3, !noalias !4
  %v2552 = load i64, ptr %slot16, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %ld2554 = load i32, ptr %p2553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2554, ptr %slot328, align 8
  %v2555 = load i32, ptr %slot328, align 8
  %cv2556 = zext i32 %v2555 to i64
  %cond2557 = icmp ne i64 %cv2556, 0
  br i1 %cond2557, label %bb_rcslotdrop397, label %bb_rcslotdone397
bb_rcslotdrop397:
  %v2558 = load i64, ptr %slot16, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i32 0, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  %v2560 = load i64, ptr %slot26, align 8
  store i64 %v2560, ptr %slot329, align 8
  %v2561 = load i64, ptr %slot17, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  %ld2563 = load i32, ptr %p2562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2563, ptr %slot330, align 8
  %v2564 = load i32, ptr %slot330, align 8
  %op2565 = and i32 %v2564, 28
  store i32 %op2565, ptr %slot331, align 8
  %v2566 = load i32, ptr %slot331, align 8
  %cv2567 = zext i32 %v2566 to i64
  %cond2568 = icmp ne i64 %cv2567, 0
  br i1 %cond2568, label %bb_rcslotrole397, label %bb_rcslotowner397
bb_rcslotrole397:
  %v2569 = load i64, ptr %slot56, align 8
  store i64 %v2569, ptr %slot332, align 8
  %v2570 = load i64, ptr %slot329, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  %ld2572 = load i64, ptr %p2571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2572, ptr %slot333, align 8
  %v2573 = load i64, ptr %slot333, align 8
  %cmp2574 = icmp ne i64 %v2573, 0
  %cv2575 = zext i1 %cmp2574 to i32
  store i32 %cv2575, ptr %slot334, align 8
  %v2576 = load i32, ptr %slot334, align 8
  %cv2577 = zext i32 %v2576 to i64
  %cond2578 = icmp ne i64 %cv2577, 0
  br i1 %cond2578, label %bb_rcgnn413, label %bb_rcgdone413
bb_rcgnn413:
  %v2579 = load i64, ptr %slot333, align 8
  %op2580 = sub i64 %v2579, 16
  store i64 %op2580, ptr %slot335, align 8
  %v2581 = load i64, ptr %slot333, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %rgep2583 = getelementptr i8, ptr %p2582, i64 -16
  %ld2584 = load i64, ptr %rgep2583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2584, ptr %slot336, align 8
  %v2585 = load i64, ptr %slot336, align 8
  %op2586 = and i64 %v2585, 4611686018427387906
  store i64 %op2586, ptr %slot337, align 8
  %v2587 = load i64, ptr %slot337, align 8
  %cmp2588 = icmp ne i64 %v2587, 0
  %cv2589 = zext i1 %cmp2588 to i32
  store i32 %cv2589, ptr %slot338, align 8
  %v2590 = load i32, ptr %slot338, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcgclear413, label %bb_rcgcounted413
bb_rcgcounted413:
  %v2593 = load i64, ptr %slot333, align 8
  %op2594 = sub i64 %v2593, 24
  store i64 %op2594, ptr %slot339, align 8
  %v2595 = load i64, ptr %slot333, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %rgep2597 = getelementptr i8, ptr %p2596, i64 -24
  %ld2598 = load i64, ptr %rgep2597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2598, ptr %slot340, align 8
  %v2599 = load i64, ptr %slot340, align 8
  %op2600 = sub i64 %v2599, 1
  store i64 %op2600, ptr %slot341, align 8
  %v2601 = load i64, ptr %slot341, align 8
  %cmp2602 = icmp eq i64 %v2601, 0
  %cv2603 = zext i1 %cmp2602 to i32
  store i32 %cv2603, ptr %slot342, align 8
  %v2604 = load i32, ptr %slot342, align 8
  %cv2605 = zext i32 %v2604 to i64
  %cond2606 = icmp ne i64 %cv2605, 0
  br i1 %cond2606, label %bb_rcglast413, label %bb_rcgdec413
bb_rcglast413:
  %v2607 = load i64, ptr %slot333, align 8
  %op2608 = sub i64 %v2607, 32
  store i64 %op2608, ptr %slot343, align 8
  %v2609 = load i64, ptr %slot333, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %rgep2611 = getelementptr i8, ptr %p2610, i64 -32
  %ld2612 = load i64, ptr %rgep2611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2612, ptr %slot344, align 8
  %v2613 = load i64, ptr %slot344, align 8
  %cmp2614 = icmp ne i64 %v2613, 0
  %cv2615 = zext i1 %cmp2614 to i32
  store i32 %cv2615, ptr %slot345, align 8
  %v2616 = load i32, ptr %slot345, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcgdec413, label %bb_rcgslow413
bb_rcgslow413:
  %v2619 = load i64, ptr %slot332, align 8
  %v2620 = load i64, ptr %slot329, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2619, i64 %v2620) nomerge, !dbg !122
  br label %bb_rcgdone413
bb_rcgdec413:
  %v2621 = load i64, ptr %slot341, align 8
  %v2622 = load i64, ptr %slot333, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %rgep2624 = getelementptr i8, ptr %p2623, i64 -24
  store i64 %v2621, ptr %rgep2624, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear413
bb_rcgclear413:
  %v2625 = load i64, ptr %slot329, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 0, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone413
bb_rcgdone413:
  br label %bb_rcslotdone397
bb_rcslotowner397:
  %v2627 = load i64, ptr %slot56, align 8
  store i64 %v2627, ptr %slot346, align 8
  %v2628 = load i64, ptr %slot329, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %ld2630 = load i64, ptr %p2629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2630, ptr %slot347, align 8
  %v2631 = load i64, ptr %slot347, align 8
  %cmp2632 = icmp ne i64 %v2631, 0
  %cv2633 = zext i1 %cmp2632 to i32
  store i32 %cv2633, ptr %slot348, align 8
  %v2634 = load i32, ptr %slot348, align 8
  %cv2635 = zext i32 %v2634 to i64
  %cond2636 = icmp ne i64 %cv2635, 0
  br i1 %cond2636, label %bb_rcgnn428, label %bb_rcgdone428
bb_rcgnn428:
  %v2637 = load i64, ptr %slot347, align 8
  %op2638 = sub i64 %v2637, 16
  store i64 %op2638, ptr %slot349, align 8
  %v2639 = load i64, ptr %slot347, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  %rgep2641 = getelementptr i8, ptr %p2640, i64 -16
  %ld2642 = load i64, ptr %rgep2641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2642, ptr %slot350, align 8
  %v2643 = load i64, ptr %slot350, align 8
  %op2644 = and i64 %v2643, 4611686018427387906
  store i64 %op2644, ptr %slot351, align 8
  %v2645 = load i64, ptr %slot351, align 8
  %cmp2646 = icmp ne i64 %v2645, 0
  %cv2647 = zext i1 %cmp2646 to i32
  store i32 %cv2647, ptr %slot352, align 8
  %v2648 = load i32, ptr %slot352, align 8
  %cv2649 = zext i32 %v2648 to i64
  %cond2650 = icmp ne i64 %cv2649, 0
  br i1 %cond2650, label %bb_rcgclear428, label %bb_rcgcounted428
bb_rcgcounted428:
  %v2651 = load i64, ptr %slot347, align 8
  %op2652 = sub i64 %v2651, 32
  store i64 %op2652, ptr %slot353, align 8
  %v2653 = load i64, ptr %slot347, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  %rgep2655 = getelementptr i8, ptr %p2654, i64 -32
  %ld2656 = load i64, ptr %rgep2655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2656, ptr %slot354, align 8
  %v2657 = load i64, ptr %slot354, align 8
  %op2658 = sub i64 %v2657, 1
  store i64 %op2658, ptr %slot355, align 8
  %v2659 = load i64, ptr %slot355, align 8
  %cmp2660 = icmp eq i64 %v2659, 0
  %cv2661 = zext i1 %cmp2660 to i32
  store i32 %cv2661, ptr %slot356, align 8
  %v2662 = load i32, ptr %slot356, align 8
  %cv2663 = zext i32 %v2662 to i64
  %cond2664 = icmp ne i64 %cv2663, 0
  br i1 %cond2664, label %bb_rcglast428, label %bb_rcgdec428
bb_rcglast428:
  %v2665 = load i64, ptr %slot347, align 8
  %op2666 = sub i64 %v2665, 24
  store i64 %op2666, ptr %slot357, align 8
  %v2667 = load i64, ptr %slot347, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %rgep2669 = getelementptr i8, ptr %p2668, i64 -24
  %ld2670 = load i64, ptr %rgep2669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2670, ptr %slot358, align 8
  %v2671 = load i64, ptr %slot358, align 8
  %cmp2672 = icmp ne i64 %v2671, 0
  %cv2673 = zext i1 %cmp2672 to i32
  store i32 %cv2673, ptr %slot359, align 8
  %v2674 = load i32, ptr %slot359, align 8
  %cv2675 = zext i32 %v2674 to i64
  %cond2676 = icmp ne i64 %cv2675, 0
  br i1 %cond2676, label %bb_rcgdec428, label %bb_rcgslow428
bb_rcgslow428:
  %v2677 = load i64, ptr %slot346, align 8
  %v2678 = load i64, ptr %slot329, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2677, i64 %v2678) nomerge, !dbg !122
  br label %bb_rcgdone428
bb_rcgdec428:
  %v2679 = load i64, ptr %slot355, align 8
  %v2680 = load i64, ptr %slot347, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  %rgep2682 = getelementptr i8, ptr %p2681, i64 -32
  store i64 %v2679, ptr %rgep2682, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear428
bb_rcgclear428:
  %v2683 = load i64, ptr %slot329, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i64 0, ptr %p2684, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone428
bb_rcgdone428:
  br label %bb_rcslotdone397
bb_rcslotdone397:
  br label %bb_rcprepared343
bb_rcprepared343:
  %v2685 = load i64, ptr %slot31, align 8
  store i64 %v2685, ptr %slot360, align 8
  %v2686 = load i64, ptr %slot360, align 8
  %v2687 = load i64, ptr %slot286, align 8
  %p2688 = inttoptr i64 %v2686 to ptr
  %p2689 = inttoptr i64 %v2687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2689, ptr %p2688, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot22, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i32 0, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot43, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  %ld2694 = load i64, ptr %p2693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2694, ptr %slot361, align 8
  %v2695 = load i64, ptr %slot222, align 8
  %p2697 = inttoptr i64 %v2695 to ptr
  %gep2698 = getelementptr i8, ptr %p2697, i64 40
  %op2696 = ptrtoint ptr %gep2698 to i64
  store i64 %op2696, ptr %slot362, align 8
  %v2699 = load i64, ptr %slot43, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %ld2701 = load i64, ptr %p2700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2701, ptr %slot363, align 8
  %v2702 = load i64, ptr %slot18, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  %ld2704 = load i32, ptr %p2703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2704, ptr %slot364, align 8
  %v2705 = load i64, ptr %slot19, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %ld2707 = load i32, ptr %p2706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2707, ptr %slot365, align 8
  %v2708 = load i32, ptr %slot365, align 8
  %op2709 = and i32 %v2708, 24
  store i32 %op2709, ptr %slot365, align 8
  %v2710 = load i32, ptr %slot365, align 8
  %cmp2711 = icmp eq i32 %v2710, 0
  %cv2712 = zext i1 %cmp2711 to i32
  store i32 %cv2712, ptr %slot366, align 8
  %v2713 = load i32, ptr %slot364, align 8
  %v2714 = load i32, ptr %slot366, align 8
  %op2715 = and i32 %v2713, %v2714
  store i32 %op2715, ptr %slot367, align 8
  %v2716 = load i32, ptr %slot367, align 8
  %cv2717 = zext i32 %v2716 to i64
  %cond2718 = icmp ne i64 %cv2717, 0
  br i1 %cond2718, label %bb_rctake437, label %bb_rccopy437
bb_rctake437:
  %v2719 = load i64, ptr %slot31, align 8
  store i64 %v2719, ptr %slot368, align 8
  %v2720 = load i64, ptr %slot57, align 8
  store i64 %v2720, ptr %slot369, align 8
  %v2721 = load i64, ptr %slot363, align 8
  %v2722 = load i64, ptr %slot368, align 8
  %op2723 = sub i64 %v2721, %v2722
  store i64 %op2723, ptr %slot370, align 8
  %v2724 = load i64, ptr %slot368, align 8
  %v2725 = load i64, ptr %slot363, align 8
  %op2726 = sub i64 %v2724, %v2725
  store i64 %op2726, ptr %slot371, align 8
  %v2727 = load i64, ptr %slot370, align 8
  %cmp2728 = icmp ult i64 %v2727, 40
  %cv2729 = zext i1 %cmp2728 to i32
  store i32 %cv2729, ptr %slot372, align 8
  %v2730 = load i64, ptr %slot371, align 8
  %cmp2731 = icmp ult i64 %v2730, 40
  %cv2732 = zext i1 %cmp2731 to i32
  store i32 %cv2732, ptr %slot373, align 8
  %v2733 = load i32, ptr %slot372, align 8
  %v2734 = load i32, ptr %slot373, align 8
  %op2735 = or i32 %v2733, %v2734
  store i32 %op2735, ptr %slot374, align 8
  %v2736 = load i32, ptr %slot374, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcmoveslow446, label %bb_rcmovecheck446
bb_rcmovecheck446:
  %v2739 = load i64, ptr %slot363, align 8
  %op2740 = add i64 %v2739, 0
  store i64 %op2740, ptr %slot375, align 8
  %v2741 = load i64, ptr %slot375, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  %ld2743 = load i64, ptr %p2742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2743, ptr %slot376, align 8
  %v2744 = load i64, ptr %slot376, align 8
  %cmp2745 = icmp ne i64 %v2744, 0
  %cv2746 = zext i1 %cmp2745 to i32
  store i32 %cv2746, ptr %slot377, align 8
  %v2747 = load i32, ptr %slot377, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcmoveheader454, label %bb_rcmovenext454
bb_rcmoveheader454:
  %v2750 = load i64, ptr %slot376, align 8
  %op2751 = sub i64 %v2750, 16
  store i64 %op2751, ptr %slot378, align 8
  %v2752 = load i64, ptr %slot376, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %rgep2754 = getelementptr i8, ptr %p2753, i64 -16
  %ld2755 = load i64, ptr %rgep2754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2755, ptr %slot379, align 8
  %v2756 = load i64, ptr %slot379, align 8
  %op2757 = and i64 %v2756, 5764607523034234881
  store i64 %op2757, ptr %slot380, align 8
  %v2758 = load i64, ptr %slot380, align 8
  %cmp2759 = icmp ne i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot381, align 8
  %v2761 = load i32, ptr %slot381, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcmoveslow446, label %bb_rcmovenext454
bb_rcmovenext454:
  %v2764 = load i64, ptr %slot363, align 8
  %op2765 = add i64 %v2764, 8
  store i64 %op2765, ptr %slot382, align 8
  %v2766 = load i64, ptr %slot382, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %ld2768 = load i64, ptr %p2767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2768, ptr %slot383, align 8
  %v2769 = load i64, ptr %slot383, align 8
  %cmp2770 = icmp ne i64 %v2769, 0
  %cv2771 = zext i1 %cmp2770 to i32
  store i32 %cv2771, ptr %slot384, align 8
  %v2772 = load i32, ptr %slot384, align 8
  %cv2773 = zext i32 %v2772 to i64
  %cond2774 = icmp ne i64 %cv2773, 0
  br i1 %cond2774, label %bb_rcmoveheader462, label %bb_rcmovenext462
bb_rcmoveheader462:
  %v2775 = load i64, ptr %slot383, align 8
  %op2776 = sub i64 %v2775, 16
  store i64 %op2776, ptr %slot385, align 8
  %v2777 = load i64, ptr %slot383, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %rgep2779 = getelementptr i8, ptr %p2778, i64 -16
  %ld2780 = load i64, ptr %rgep2779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2780, ptr %slot386, align 8
  %v2781 = load i64, ptr %slot386, align 8
  %op2782 = and i64 %v2781, 5764607523034234881
  store i64 %op2782, ptr %slot387, align 8
  %v2783 = load i64, ptr %slot387, align 8
  %cmp2784 = icmp ne i64 %v2783, 0
  %cv2785 = zext i1 %cmp2784 to i32
  store i32 %cv2785, ptr %slot388, align 8
  %v2786 = load i32, ptr %slot388, align 8
  %cv2787 = zext i32 %v2786 to i64
  %cond2788 = icmp ne i64 %cv2787, 0
  br i1 %cond2788, label %bb_rcmoveslow446, label %bb_rcmovenext462
bb_rcmovenext462:
  %v2789 = load i64, ptr %slot363, align 8
  %v2790 = load i64, ptr %slot368, align 8
  %p2791 = inttoptr i64 %v2789 to ptr
  %p2792 = inttoptr i64 %v2790 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2792, ptr %p2791, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2793 = load i64, ptr %slot363, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i64 0, ptr %p2794, align 8, !alias.scope !3, !noalias !4
  %v2795 = load i64, ptr %slot363, align 8
  %op2796 = add i64 %v2795, 8
  store i64 %op2796, ptr %slot389, align 8
  %v2797 = load i64, ptr %slot389, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  store i64 0, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  %v2799 = load i64, ptr %slot363, align 8
  %op2800 = add i64 %v2799, 16
  store i64 %op2800, ptr %slot390, align 8
  %v2801 = load i64, ptr %slot390, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i64 0, ptr %p2802, align 8, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot363, align 8
  %op2804 = add i64 %v2803, 24
  store i64 %op2804, ptr %slot391, align 8
  %v2805 = load i64, ptr %slot391, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  store i64 0, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  %v2807 = load i64, ptr %slot363, align 8
  %op2808 = add i64 %v2807, 32
  store i64 %op2808, ptr %slot392, align 8
  %v2809 = load i64, ptr %slot392, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  store i64 0, ptr %p2810, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved446
bb_rcmoveslow446:
  %v2811 = load i64, ptr %slot56, align 8
  %v2812 = load i64, ptr %slot368, align 8
  %v2813 = load i64, ptr %slot363, align 8
  %v2814 = load i64, ptr %slot369, align 8
  %cv2815 = trunc i64 %v2814 to i32
  %call2816 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v2811, i64 %v2812, i64 %v2813, i32 %cv2815) nomerge, !dbg !122
  store i32 %call2816, ptr %slot393, align 8
  %v2817 = load i32, ptr %slot393, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcsuccess473, label %bb_rcfailure473
bb_rcfailure473:
  %v2820 = load i64, ptr %slot56, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %call2822 = call i32 @myl_rc_take_failure(ptr %p2821) nomerge, !dbg !122
  store i32 %call2822, ptr %slot394, align 8
  %v2823 = load i64, ptr %slot1, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %v2825 = load i32, ptr %slot394, align 8
  %call2826 = call i32 @myl_qbe_rc_status(ptr %p2824, i32 %v2825) nomerge, !dbg !122
  store i32 %call2826, ptr %slot395, align 8
  br label %bb_failure
bb_rcsuccess473:
  br label %bb_rcmoved446
bb_rcmoved446:
  %v2827 = load i64, ptr %slot18, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i32 0, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot23, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i32 2, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot22, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  store i32 1, ptr %p2832, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared437
bb_rccopy437:
  %v2833 = load i64, ptr %slot31, align 8
  store i64 %v2833, ptr %slot396, align 8
  %v2834 = load i64, ptr %slot57, align 8
  store i64 %v2834, ptr %slot397, align 8
  %v2835 = load i64, ptr %slot56, align 8
  %v2836 = load i64, ptr %slot396, align 8
  %v2837 = load i64, ptr %slot363, align 8
  %v2838 = load i64, ptr %slot397, align 8
  %cv2839 = trunc i64 %v2838 to i32
  %call2840 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64 %v2835, i64 %v2836, i64 %v2837, i32 %cv2839) nomerge, !dbg !122
  store i32 %call2840, ptr %slot398, align 8
  %v2841 = load i32, ptr %slot398, align 8
  %cv2842 = zext i32 %v2841 to i64
  %cond2843 = icmp ne i64 %cv2842, 0
  br i1 %cond2843, label %bb_rcsuccess482, label %bb_rcfailure482
bb_rcfailure482:
  %v2844 = load i64, ptr %slot56, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %call2846 = call i32 @myl_rc_take_failure(ptr %p2845) nomerge, !dbg !122
  store i32 %call2846, ptr %slot399, align 8
  %v2847 = load i64, ptr %slot1, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %v2849 = load i32, ptr %slot399, align 8
  %call2850 = call i32 @myl_qbe_rc_status(ptr %p2848, i32 %v2849) nomerge, !dbg !122
  store i32 %call2850, ptr %slot400, align 8
  br label %bb_failure
bb_rcsuccess482:
  %v2851 = load i64, ptr %slot23, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i32 2, ptr %p2852, align 4, !alias.scope !3, !noalias !4
  %v2853 = load i64, ptr %slot22, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 1, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot18, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  %ld2857 = load i32, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2857, ptr %slot401, align 8
  %v2858 = load i32, ptr %slot401, align 8
  %cv2859 = zext i32 %v2858 to i64
  %cond2860 = icmp ne i64 %cv2859, 0
  br i1 %cond2860, label %bb_rcslotdrop489, label %bb_rcslotdone489
bb_rcslotdrop489:
  %v2861 = load i64, ptr %slot18, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  store i32 0, ptr %p2862, align 4, !alias.scope !3, !noalias !4
  %v2863 = load i64, ptr %slot27, align 8
  store i64 %v2863, ptr %slot402, align 8
  %v2864 = load i64, ptr %slot19, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  %ld2866 = load i32, ptr %p2865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2866, ptr %slot403, align 8
  %v2867 = load i32, ptr %slot403, align 8
  %op2868 = and i32 %v2867, 28
  store i32 %op2868, ptr %slot404, align 8
  %v2869 = load i32, ptr %slot404, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcslotrole489, label %bb_rcslotowner489
bb_rcslotrole489:
  %v2872 = load i64, ptr %slot56, align 8
  store i64 %v2872, ptr %slot405, align 8
  %v2873 = load i64, ptr %slot405, align 8
  %v2874 = load i64, ptr %slot402, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2873, i64 %v2874) nomerge, !dbg !122
  br label %bb_rcslotdone489
bb_rcslotowner489:
  %v2875 = load i64, ptr %slot56, align 8
  store i64 %v2875, ptr %slot406, align 8
  %v2876 = load i64, ptr %slot406, align 8
  %v2877 = load i64, ptr %slot402, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2876, i64 %v2877) nomerge, !dbg !122
  br label %bb_rcslotdone489
bb_rcslotdone489:
  br label %bb_rcprepared437
bb_rcprepared437:
  %v2878 = load i64, ptr %slot31, align 8
  store i64 %v2878, ptr %slot407, align 8
  %v2879 = load i64, ptr %slot407, align 8
  %v2880 = load i64, ptr %slot362, align 8
  %p2881 = inttoptr i64 %v2879 to ptr
  %p2882 = inttoptr i64 %v2880 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2882, ptr %p2881, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot22, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i32 0, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot44, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %ld2887 = load i64, ptr %p2886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2887, ptr %slot408, align 8
  %v2888 = load i64, ptr %slot408, align 8
  %v2889 = load i64, ptr %slot30, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i64 %v2888, ptr %p2890, align 8, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot30, align 8
  store i64 %v2891, ptr %slot409, align 8
  %v2892 = load i64, ptr %slot222, align 8
  %p2894 = inttoptr i64 %v2892 to ptr
  %gep2895 = getelementptr i8, ptr %p2894, i64 80
  %op2893 = ptrtoint ptr %gep2895 to i64
  store i64 %op2893, ptr %slot410, align 8
  %v2896 = load i64, ptr %slot44, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %ld2898 = load i64, ptr %p2897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2898, ptr %slot411, align 8
  %v2899 = load i64, ptr %slot411, align 8
  %v2900 = load i64, ptr %slot30, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  store i64 %v2899, ptr %p2901, align 8, !alias.scope !3, !noalias !4
  %v2902 = load i64, ptr %slot30, align 8
  store i64 %v2902, ptr %slot412, align 8
  %v2903 = load i64, ptr %slot20, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  %ld2905 = load i32, ptr %p2904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2905, ptr %slot413, align 8
  %v2906 = load i64, ptr %slot21, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %ld2908 = load i32, ptr %p2907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2908, ptr %slot414, align 8
  %v2909 = load i32, ptr %slot414, align 8
  %op2910 = and i32 %v2909, 24
  store i32 %op2910, ptr %slot414, align 8
  %v2911 = load i32, ptr %slot414, align 8
  %cmp2912 = icmp eq i32 %v2911, 0
  %cv2913 = zext i1 %cmp2912 to i32
  store i32 %cv2913, ptr %slot415, align 8
  %v2914 = load i32, ptr %slot413, align 8
  %v2915 = load i32, ptr %slot415, align 8
  %op2916 = and i32 %v2914, %v2915
  store i32 %op2916, ptr %slot416, align 8
  %v2917 = load i32, ptr %slot416, align 8
  %cv2918 = zext i32 %v2917 to i64
  %cond2919 = icmp ne i64 %cv2918, 0
  br i1 %cond2919, label %bb_rctake503, label %bb_rccopy503
bb_rctake503:
  %v2920 = load i64, ptr %slot31, align 8
  store i64 %v2920, ptr %slot417, align 8
  %v2921 = load i64, ptr %slot57, align 8
  store i64 %v2921, ptr %slot418, align 8
  %v2922 = load i64, ptr %slot412, align 8
  %v2923 = load i64, ptr %slot417, align 8
  %op2924 = sub i64 %v2922, %v2923
  store i64 %op2924, ptr %slot419, align 8
  %v2925 = load i64, ptr %slot417, align 8
  %v2926 = load i64, ptr %slot412, align 8
  %op2927 = sub i64 %v2925, %v2926
  store i64 %op2927, ptr %slot420, align 8
  %v2928 = load i64, ptr %slot419, align 8
  %cmp2929 = icmp ult i64 %v2928, 8
  %cv2930 = zext i1 %cmp2929 to i32
  store i32 %cv2930, ptr %slot421, align 8
  %v2931 = load i64, ptr %slot420, align 8
  %cmp2932 = icmp ult i64 %v2931, 8
  %cv2933 = zext i1 %cmp2932 to i32
  store i32 %cv2933, ptr %slot422, align 8
  %v2934 = load i32, ptr %slot421, align 8
  %v2935 = load i32, ptr %slot422, align 8
  %op2936 = or i32 %v2934, %v2935
  store i32 %op2936, ptr %slot423, align 8
  %v2937 = load i32, ptr %slot423, align 8
  %cv2938 = zext i32 %v2937 to i64
  %cond2939 = icmp ne i64 %cv2938, 0
  br i1 %cond2939, label %bb_rcmoveslow512, label %bb_rcmovecheck512
bb_rcmovecheck512:
  %v2940 = load i64, ptr %slot412, align 8
  %p2942 = inttoptr i64 %v2940 to ptr
  %gep2943 = getelementptr i8, ptr %p2942, i64 0
  %op2941 = ptrtoint ptr %gep2943 to i64
  store i64 %op2941, ptr %slot424, align 8
  %v2944 = load i64, ptr %slot424, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  %ld2946 = load i64, ptr %p2945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2946, ptr %slot425, align 8
  %v2947 = load i64, ptr %slot425, align 8
  %cmp2948 = icmp ne i64 %v2947, 0
  %cv2949 = zext i1 %cmp2948 to i32
  store i32 %cv2949, ptr %slot426, align 8
  %v2950 = load i32, ptr %slot426, align 8
  %cv2951 = zext i32 %v2950 to i64
  %cond2952 = icmp ne i64 %cv2951, 0
  br i1 %cond2952, label %bb_rcmoveheader520, label %bb_rcmovenext520
bb_rcmoveheader520:
  %v2953 = load i64, ptr %slot425, align 8
  %op2954 = sub i64 %v2953, 16
  store i64 %op2954, ptr %slot427, align 8
  %v2955 = load i64, ptr %slot425, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  %rgep2957 = getelementptr i8, ptr %p2956, i64 -16
  %ld2958 = load i64, ptr %rgep2957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2958, ptr %slot428, align 8
  %v2959 = load i64, ptr %slot428, align 8
  %op2960 = and i64 %v2959, 5764607523034234881
  store i64 %op2960, ptr %slot429, align 8
  %v2961 = load i64, ptr %slot429, align 8
  %cmp2962 = icmp ne i64 %v2961, 0
  %cv2963 = zext i1 %cmp2962 to i32
  store i32 %cv2963, ptr %slot430, align 8
  %v2964 = load i32, ptr %slot430, align 8
  %cv2965 = zext i32 %v2964 to i64
  %cond2966 = icmp ne i64 %cv2965, 0
  br i1 %cond2966, label %bb_rcmoveslow512, label %bb_rcmovenext520
bb_rcmovenext520:
  %v2967 = load i64, ptr %slot412, align 8
  %v2968 = load i64, ptr %slot417, align 8
  %p2969 = inttoptr i64 %v2967 to ptr
  %p2970 = inttoptr i64 %v2968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2970, ptr %p2969, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2971 = load i64, ptr %slot412, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  store i64 0, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved512
bb_rcmoveslow512:
  %v2973 = load i64, ptr %slot56, align 8
  %v2974 = load i64, ptr %slot417, align 8
  %v2975 = load i64, ptr %slot412, align 8
  %v2976 = load i64, ptr %slot418, align 8
  %cv2977 = trunc i64 %v2976 to i32
  %call2978 = call i32 @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_take(i64 %v2973, i64 %v2974, i64 %v2975, i32 %cv2977) nomerge, !dbg !122
  store i32 %call2978, ptr %slot431, align 8
  %v2979 = load i32, ptr %slot431, align 8
  %cv2980 = zext i32 %v2979 to i64
  %cond2981 = icmp ne i64 %cv2980, 0
  br i1 %cond2981, label %bb_rcsuccess527, label %bb_rcfailure527
bb_rcfailure527:
  %v2982 = load i64, ptr %slot56, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %call2984 = call i32 @myl_rc_take_failure(ptr %p2983) nomerge, !dbg !122
  store i32 %call2984, ptr %slot432, align 8
  %v2985 = load i64, ptr %slot1, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %v2987 = load i32, ptr %slot432, align 8
  %call2988 = call i32 @myl_qbe_rc_status(ptr %p2986, i32 %v2987) nomerge, !dbg !122
  store i32 %call2988, ptr %slot433, align 8
  br label %bb_failure
bb_rcsuccess527:
  br label %bb_rcmoved512
bb_rcmoved512:
  %v2989 = load i64, ptr %slot20, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  store i32 0, ptr %p2990, align 4, !alias.scope !3, !noalias !4
  %v2991 = load i64, ptr %slot23, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  store i32 2, ptr %p2992, align 4, !alias.scope !3, !noalias !4
  %v2993 = load i64, ptr %slot22, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  store i32 1, ptr %p2994, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared503
bb_rccopy503:
  %v2995 = load i64, ptr %slot31, align 8
  store i64 %v2995, ptr %slot434, align 8
  %v2996 = load i64, ptr %slot57, align 8
  store i64 %v2996, ptr %slot435, align 8
  %v2997 = load i64, ptr %slot412, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %ld2999 = load i64, ptr %p2998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2999, ptr %slot436, align 8
  %v3000 = load i64, ptr %slot436, align 8
  %cmp3001 = icmp ne i64 %v3000, 0
  %cv3002 = zext i1 %cmp3001 to i32
  store i32 %cv3002, ptr %slot437, align 8
  %v3003 = load i32, ptr %slot437, align 8
  %cv3004 = zext i32 %v3003 to i64
  %cond3005 = icmp ne i64 %cv3004, 0
  br i1 %cond3005, label %bb_rcgnn536, label %bb_rcgplain536
bb_rcgnn536:
  %v3006 = load i64, ptr %slot436, align 8
  %op3007 = sub i64 %v3006, 16
  store i64 %op3007, ptr %slot438, align 8
  %v3008 = load i64, ptr %slot436, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  %rgep3010 = getelementptr i8, ptr %p3009, i64 -16
  %ld3011 = load i64, ptr %rgep3010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3011, ptr %slot439, align 8
  %v3012 = load i64, ptr %slot439, align 8
  %op3013 = and i64 %v3012, 4611686018427387906
  store i64 %op3013, ptr %slot440, align 8
  %v3014 = load i64, ptr %slot440, align 8
  %cmp3015 = icmp ne i64 %v3014, 0
  %cv3016 = zext i1 %cmp3015 to i32
  store i32 %cv3016, ptr %slot441, align 8
  %v3017 = load i32, ptr %slot441, align 8
  %cv3018 = zext i32 %v3017 to i64
  %cond3019 = icmp ne i64 %cv3018, 0
  br i1 %cond3019, label %bb_rcgspecial536, label %bb_rcginc536
bb_rcginc536:
  %v3020 = load i64, ptr %slot436, align 8
  %op3021 = sub i64 %v3020, 32
  store i64 %op3021, ptr %slot442, align 8
  %v3022 = load i64, ptr %slot436, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %rgep3024 = getelementptr i8, ptr %p3023, i64 -32
  %ld3025 = load i64, ptr %rgep3024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3025, ptr %slot443, align 8
  %v3026 = load i64, ptr %slot443, align 8
  %op3027 = add i64 %v3026, 1
  store i64 %op3027, ptr %slot444, align 8
  %v3028 = load i64, ptr %slot444, align 8
  %cmp3029 = icmp eq i64 %v3028, 0
  %cv3030 = zext i1 %cmp3029 to i32
  store i32 %cv3030, ptr %slot445, align 8
  %v3031 = load i32, ptr %slot445, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcglimit536, label %bb_rcgcapacity536
bb_rcglimit536:
  %v3034 = load i64, ptr %slot1, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %call3036 = call i32 @myl_qbe_rc_status(ptr %p3035, i32 2) nomerge, !dbg !122
  store i32 %call3036, ptr %slot446, align 8
  br label %bb_failure
bb_rcgcapacity536:
  %v3037 = load i64, ptr %slot444, align 8
  %v3038 = load i64, ptr %slot436, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %rgep3040 = getelementptr i8, ptr %p3039, i64 -32
  store i64 %v3037, ptr %rgep3040, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain536
bb_rcgspecial536:
  %v3041 = load i64, ptr %slot439, align 8
  %op3042 = and i64 %v3041, 4611686018427387904
  store i64 %op3042, ptr %slot447, align 8
  %v3043 = load i64, ptr %slot447, align 8
  %cmp3044 = icmp ne i64 %v3043, 0
  %cv3045 = zext i1 %cmp3044 to i32
  store i32 %cv3045, ptr %slot448, align 8
  %v3046 = load i32, ptr %slot448, align 8
  %cv3047 = zext i32 %v3046 to i64
  %cond3048 = icmp ne i64 %cv3047, 0
  br i1 %cond3048, label %bb_rcgslow536, label %bb_rcgplain536
bb_rcgslow536:
  %v3049 = load i64, ptr %slot56, align 8
  %v3050 = load i64, ptr %slot434, align 8
  %v3051 = load i64, ptr %slot412, align 8
  %v3052 = load i64, ptr %slot435, align 8
  %cv3053 = trunc i64 %v3052 to i32
  %call3054 = call i32 @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_retain(i64 %v3049, i64 %v3050, i64 %v3051, i32 %cv3053) nomerge, !dbg !122
  store i32 %call3054, ptr %slot449, align 8
  %v3055 = load i32, ptr %slot449, align 8
  %cv3056 = zext i32 %v3055 to i64
  %cond3057 = icmp ne i64 %cv3056, 0
  br i1 %cond3057, label %bb_rcsuccess550, label %bb_rcfailure550
bb_rcfailure550:
  %v3058 = load i64, ptr %slot56, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %call3060 = call i32 @myl_rc_take_failure(ptr %p3059) nomerge, !dbg !122
  store i32 %call3060, ptr %slot450, align 8
  %v3061 = load i64, ptr %slot1, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  %v3063 = load i32, ptr %slot450, align 8
  %call3064 = call i32 @myl_qbe_rc_status(ptr %p3062, i32 %v3063) nomerge, !dbg !122
  store i32 %call3064, ptr %slot451, align 8
  br label %bb_failure
bb_rcsuccess550:
  br label %bb_rcgdone536
bb_rcgplain536:
  %v3065 = load i64, ptr %slot436, align 8
  %v3066 = load i64, ptr %slot434, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  store i64 %v3065, ptr %p3067, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone536
bb_rcgdone536:
  %v3068 = load i64, ptr %slot23, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i32 2, ptr %p3069, align 4, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot22, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i32 1, ptr %p3071, align 4, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot20, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  %ld3074 = load i32, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3074, ptr %slot452, align 8
  %v3075 = load i32, ptr %slot452, align 8
  %cv3076 = zext i32 %v3075 to i64
  %cond3077 = icmp ne i64 %cv3076, 0
  br i1 %cond3077, label %bb_rcslotdrop557, label %bb_rcslotdone557
bb_rcslotdrop557:
  %v3078 = load i64, ptr %slot20, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i32 0, ptr %p3079, align 4, !alias.scope !3, !noalias !4
  %v3080 = load i64, ptr %slot28, align 8
  store i64 %v3080, ptr %slot453, align 8
  %v3081 = load i64, ptr %slot21, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %ld3083 = load i32, ptr %p3082, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3083, ptr %slot454, align 8
  %v3084 = load i32, ptr %slot454, align 8
  %op3085 = and i32 %v3084, 28
  store i32 %op3085, ptr %slot455, align 8
  %v3086 = load i32, ptr %slot455, align 8
  %cv3087 = zext i32 %v3086 to i64
  %cond3088 = icmp ne i64 %cv3087, 0
  br i1 %cond3088, label %bb_rcslotrole557, label %bb_rcslotowner557
bb_rcslotrole557:
  %v3089 = load i64, ptr %slot56, align 8
  store i64 %v3089, ptr %slot456, align 8
  %v3090 = load i64, ptr %slot453, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %ld3092 = load i64, ptr %p3091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3092, ptr %slot457, align 8
  %v3093 = load i64, ptr %slot457, align 8
  %cmp3094 = icmp ne i64 %v3093, 0
  %cv3095 = zext i1 %cmp3094 to i32
  store i32 %cv3095, ptr %slot458, align 8
  %v3096 = load i32, ptr %slot458, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcgnn573, label %bb_rcgdone573
bb_rcgnn573:
  %v3099 = load i64, ptr %slot457, align 8
  %op3100 = sub i64 %v3099, 16
  store i64 %op3100, ptr %slot459, align 8
  %v3101 = load i64, ptr %slot457, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %rgep3103 = getelementptr i8, ptr %p3102, i64 -16
  %ld3104 = load i64, ptr %rgep3103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3104, ptr %slot460, align 8
  %v3105 = load i64, ptr %slot460, align 8
  %op3106 = and i64 %v3105, 4611686018427387906
  store i64 %op3106, ptr %slot461, align 8
  %v3107 = load i64, ptr %slot461, align 8
  %cmp3108 = icmp ne i64 %v3107, 0
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot462, align 8
  %v3110 = load i32, ptr %slot462, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcgclear573, label %bb_rcgcounted573
bb_rcgcounted573:
  %v3113 = load i64, ptr %slot457, align 8
  %op3114 = sub i64 %v3113, 24
  store i64 %op3114, ptr %slot463, align 8
  %v3115 = load i64, ptr %slot457, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  %rgep3117 = getelementptr i8, ptr %p3116, i64 -24
  %ld3118 = load i64, ptr %rgep3117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3118, ptr %slot464, align 8
  %v3119 = load i64, ptr %slot464, align 8
  %op3120 = sub i64 %v3119, 1
  store i64 %op3120, ptr %slot465, align 8
  %v3121 = load i64, ptr %slot465, align 8
  %cmp3122 = icmp eq i64 %v3121, 0
  %cv3123 = zext i1 %cmp3122 to i32
  store i32 %cv3123, ptr %slot466, align 8
  %v3124 = load i32, ptr %slot466, align 8
  %cv3125 = zext i32 %v3124 to i64
  %cond3126 = icmp ne i64 %cv3125, 0
  br i1 %cond3126, label %bb_rcglast573, label %bb_rcgdec573
bb_rcglast573:
  %v3127 = load i64, ptr %slot457, align 8
  %op3128 = sub i64 %v3127, 32
  store i64 %op3128, ptr %slot467, align 8
  %v3129 = load i64, ptr %slot457, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  %rgep3131 = getelementptr i8, ptr %p3130, i64 -32
  %ld3132 = load i64, ptr %rgep3131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3132, ptr %slot468, align 8
  %v3133 = load i64, ptr %slot468, align 8
  %cmp3134 = icmp ne i64 %v3133, 0
  %cv3135 = zext i1 %cmp3134 to i32
  store i32 %cv3135, ptr %slot469, align 8
  %v3136 = load i32, ptr %slot469, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcgdec573, label %bb_rcgslow573
bb_rcgslow573:
  %v3139 = load i64, ptr %slot456, align 8
  %v3140 = load i64, ptr %slot453, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v3139, i64 %v3140) nomerge, !dbg !122
  br label %bb_rcgdone573
bb_rcgdec573:
  %v3141 = load i64, ptr %slot465, align 8
  %v3142 = load i64, ptr %slot457, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %rgep3144 = getelementptr i8, ptr %p3143, i64 -24
  store i64 %v3141, ptr %rgep3144, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear573
bb_rcgclear573:
  %v3145 = load i64, ptr %slot453, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  store i64 0, ptr %p3146, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone573
bb_rcgdone573:
  br label %bb_rcslotdone557
bb_rcslotowner557:
  %v3147 = load i64, ptr %slot56, align 8
  store i64 %v3147, ptr %slot470, align 8
  %v3148 = load i64, ptr %slot453, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  %ld3150 = load i64, ptr %p3149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3150, ptr %slot471, align 8
  %v3151 = load i64, ptr %slot471, align 8
  %cmp3152 = icmp ne i64 %v3151, 0
  %cv3153 = zext i1 %cmp3152 to i32
  store i32 %cv3153, ptr %slot472, align 8
  %v3154 = load i32, ptr %slot472, align 8
  %cv3155 = zext i32 %v3154 to i64
  %cond3156 = icmp ne i64 %cv3155, 0
  br i1 %cond3156, label %bb_rcgnn588, label %bb_rcgdone588
bb_rcgnn588:
  %v3157 = load i64, ptr %slot471, align 8
  %op3158 = sub i64 %v3157, 16
  store i64 %op3158, ptr %slot473, align 8
  %v3159 = load i64, ptr %slot471, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %rgep3161 = getelementptr i8, ptr %p3160, i64 -16
  %ld3162 = load i64, ptr %rgep3161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3162, ptr %slot474, align 8
  %v3163 = load i64, ptr %slot474, align 8
  %op3164 = and i64 %v3163, 4611686018427387906
  store i64 %op3164, ptr %slot475, align 8
  %v3165 = load i64, ptr %slot475, align 8
  %cmp3166 = icmp ne i64 %v3165, 0
  %cv3167 = zext i1 %cmp3166 to i32
  store i32 %cv3167, ptr %slot476, align 8
  %v3168 = load i32, ptr %slot476, align 8
  %cv3169 = zext i32 %v3168 to i64
  %cond3170 = icmp ne i64 %cv3169, 0
  br i1 %cond3170, label %bb_rcgclear588, label %bb_rcgcounted588
bb_rcgcounted588:
  %v3171 = load i64, ptr %slot471, align 8
  %op3172 = sub i64 %v3171, 32
  store i64 %op3172, ptr %slot477, align 8
  %v3173 = load i64, ptr %slot471, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  %rgep3175 = getelementptr i8, ptr %p3174, i64 -32
  %ld3176 = load i64, ptr %rgep3175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3176, ptr %slot478, align 8
  %v3177 = load i64, ptr %slot478, align 8
  %op3178 = sub i64 %v3177, 1
  store i64 %op3178, ptr %slot479, align 8
  %v3179 = load i64, ptr %slot479, align 8
  %cmp3180 = icmp eq i64 %v3179, 0
  %cv3181 = zext i1 %cmp3180 to i32
  store i32 %cv3181, ptr %slot480, align 8
  %v3182 = load i32, ptr %slot480, align 8
  %cv3183 = zext i32 %v3182 to i64
  %cond3184 = icmp ne i64 %cv3183, 0
  br i1 %cond3184, label %bb_rcglast588, label %bb_rcgdec588
bb_rcglast588:
  %v3185 = load i64, ptr %slot471, align 8
  %op3186 = sub i64 %v3185, 24
  store i64 %op3186, ptr %slot481, align 8
  %v3187 = load i64, ptr %slot471, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  %rgep3189 = getelementptr i8, ptr %p3188, i64 -24
  %ld3190 = load i64, ptr %rgep3189, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3190, ptr %slot482, align 8
  %v3191 = load i64, ptr %slot482, align 8
  %cmp3192 = icmp ne i64 %v3191, 0
  %cv3193 = zext i1 %cmp3192 to i32
  store i32 %cv3193, ptr %slot483, align 8
  %v3194 = load i32, ptr %slot483, align 8
  %cv3195 = zext i32 %v3194 to i64
  %cond3196 = icmp ne i64 %cv3195, 0
  br i1 %cond3196, label %bb_rcgdec588, label %bb_rcgslow588
bb_rcgslow588:
  %v3197 = load i64, ptr %slot470, align 8
  %v3198 = load i64, ptr %slot453, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v3197, i64 %v3198) nomerge, !dbg !122
  br label %bb_rcgdone588
bb_rcgdec588:
  %v3199 = load i64, ptr %slot479, align 8
  %v3200 = load i64, ptr %slot471, align 8
  %p3201 = inttoptr i64 %v3200 to ptr
  %rgep3202 = getelementptr i8, ptr %p3201, i64 -32
  store i64 %v3199, ptr %rgep3202, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear588
bb_rcgclear588:
  %v3203 = load i64, ptr %slot453, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  store i64 0, ptr %p3204, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone588
bb_rcgdone588:
  br label %bb_rcslotdone557
bb_rcslotdone557:
  br label %bb_rcprepared503
bb_rcprepared503:
  %v3205 = load i64, ptr %slot31, align 8
  store i64 %v3205, ptr %slot484, align 8
  %v3206 = load i64, ptr %slot484, align 8
  %v3207 = load i64, ptr %slot410, align 8
  %p3208 = inttoptr i64 %v3206 to ptr
  %p3209 = inttoptr i64 %v3207 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3209, ptr %p3208, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3210 = load i64, ptr %slot22, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i32 0, ptr %p3211, align 4, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot45, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot485, align 8
  %v3215 = load i64, ptr %slot222, align 8
  %p3217 = inttoptr i64 %v3215 to ptr
  %gep3218 = getelementptr i8, ptr %p3217, i64 88
  %op3216 = ptrtoint ptr %gep3218 to i64
  store i64 %op3216, ptr %slot486, align 8
  %v3219 = load i64, ptr %slot485, align 8
  %v3220 = load i64, ptr %slot486, align 8
  %p3221 = inttoptr i64 %v3219 to ptr
  %p3222 = inttoptr i64 %v3220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3222, ptr %p3221, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot46, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i64, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3225, ptr %slot487, align 8
  %v3226 = load i64, ptr %slot222, align 8
  %p3228 = inttoptr i64 %v3226 to ptr
  %gep3229 = getelementptr i8, ptr %p3228, i64 92
  %op3227 = ptrtoint ptr %gep3229 to i64
  store i64 %op3227, ptr %slot488, align 8
  %v3230 = load i64, ptr %slot487, align 8
  %v3231 = load i64, ptr %slot488, align 8
  %p3232 = inttoptr i64 %v3230 to ptr
  %p3233 = inttoptr i64 %v3231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3233, ptr %p3232, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot47, align 8
  store i64 %v3234, ptr %slot489, align 8
  %v3235 = load i64, ptr %slot222, align 8
  %p3237 = inttoptr i64 %v3235 to ptr
  %gep3238 = getelementptr i8, ptr %p3237, i64 96
  %op3236 = ptrtoint ptr %gep3238 to i64
  store i64 %op3236, ptr %slot490, align 8
  %v3239 = load i64, ptr %slot489, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %ld3241 = load i8, ptr %p3240, align 1, !alias.scope !3, !noalias !4
  %ext3242 = zext i8 %ld3241 to i64
  store i64 %ext3242, ptr %slot491, align 8
  %v3243 = load i64, ptr %slot491, align 8
  %cv3244 = trunc i64 %v3243 to i8
  %v3245 = load i64, ptr %slot490, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i8 %cv3244, ptr %p3246, align 1, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot222, align 8
  %v3248 = load i64, ptr %slot41, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i64 %v3247, ptr %p3249, align 8, !alias.scope !3, !noalias !4
  %v3250 = load i64, ptr %slot41, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %ld3252 = load i64, ptr %p3251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3252, ptr %slot492, align 8
  %v3253 = load i64, ptr %slot25, align 8
  store i64 %v3253, ptr %slot493, align 8
  %v3254 = load i64, ptr %slot492, align 8
  %v3255 = load i64, ptr %slot493, align 8
  %p3256 = inttoptr i64 %v3254 to ptr
  %p3257 = inttoptr i64 %v3255 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3257, ptr %p3256, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot15, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  store i32 2, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  %v3260 = load i64, ptr %slot14, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  store i32 1, ptr %p3261, align 4, !alias.scope !3, !noalias !4
  %v3262 = load i64, ptr %slot493, align 8
  %v3263 = load i64, ptr %slot41, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  store i64 %v3262, ptr %p3264, align 8, !alias.scope !3, !noalias !4
  %v3265 = load i64, ptr %slot41, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  %ld3267 = load i64, ptr %p3266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3267, ptr %slot494, align 8
  %v3268 = load i64, ptr %slot31, align 8
  store i64 %v3268, ptr %slot495, align 8
  %v3269 = load i64, ptr %slot57, align 8
  store i64 %v3269, ptr %slot496, align 8
  %v3270 = load i64, ptr %slot56, align 8
  %v3271 = load i64, ptr %slot495, align 8
  %v3272 = load i64, ptr %slot494, align 8
  %v3273 = load i64, ptr %slot496, align 8
  %cv3274 = trunc i64 %v3273 to i32
  %call3275 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v3270, i64 %v3271, i64 %v3272, i32 %cv3274) nomerge, !dbg !124
  store i32 %call3275, ptr %slot497, align 8
  %v3276 = load i32, ptr %slot497, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcsuccess609, label %bb_rcfailure609
bb_rcfailure609:
  %v3279 = load i64, ptr %slot56, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %call3281 = call i32 @myl_rc_take_failure(ptr %p3280) nomerge, !dbg !124
  store i32 %call3281, ptr %slot498, align 8
  %v3282 = load i64, ptr %slot1, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %v3284 = load i32, ptr %slot498, align 8
  %call3285 = call i32 @myl_qbe_rc_status(ptr %p3283, i32 %v3284) nomerge, !dbg !124
  store i32 %call3285, ptr %slot499, align 8
  br label %bb_failure
bb_rcsuccess609:
  %v3286 = load i64, ptr %slot14, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i32 0, ptr %p3287, align 4, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot23, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i32 2, ptr %p3289, align 4, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot22, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i32 1, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot8, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %ld3294 = load i32, ptr %p3293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3294, ptr %slot500, align 8
  %v3295 = load i32, ptr %slot500, align 8
  %cv3296 = zext i32 %v3295 to i64
  %cond3297 = icmp ne i64 %cv3296, 0
  br i1 %cond3297, label %bb_rcslotdrop618, label %bb_rcslotdone618
bb_rcslotdrop618:
  %v3298 = load i64, ptr %slot8, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i32 0, ptr %p3299, align 4, !alias.scope !3, !noalias !4
  %v3300 = load i64, ptr %slot36, align 8
  store i64 %v3300, ptr %slot501, align 8
  %v3301 = load i64, ptr %slot9, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  %ld3303 = load i32, ptr %p3302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3303, ptr %slot502, align 8
  %v3304 = load i32, ptr %slot502, align 8
  %op3305 = and i32 %v3304, 28
  store i32 %op3305, ptr %slot503, align 8
  %v3306 = load i32, ptr %slot503, align 8
  %cv3307 = zext i32 %v3306 to i64
  %cond3308 = icmp ne i64 %cv3307, 0
  br i1 %cond3308, label %bb_rcslotrole618, label %bb_rcslotowner618
bb_rcslotrole618:
  %v3309 = load i64, ptr %slot56, align 8
  store i64 %v3309, ptr %slot504, align 8
  %v3310 = load i64, ptr %slot504, align 8
  %v3311 = load i64, ptr %slot501, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3310, i64 %v3311) nomerge, !dbg !124
  br label %bb_rcslotdone618
bb_rcslotowner618:
  %v3312 = load i64, ptr %slot56, align 8
  store i64 %v3312, ptr %slot505, align 8
  %v3313 = load i64, ptr %slot505, align 8
  %v3314 = load i64, ptr %slot501, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3313, i64 %v3314) nomerge, !dbg !124
  br label %bb_rcslotdone618
bb_rcslotdone618:
  %v3315 = load i64, ptr %slot36, align 8
  store i64 %v3315, ptr %slot506, align 8
  %v3316 = load i64, ptr %slot31, align 8
  store i64 %v3316, ptr %slot507, align 8
  %v3317 = load i64, ptr %slot507, align 8
  %v3318 = load i64, ptr %slot506, align 8
  %p3319 = inttoptr i64 %v3317 to ptr
  %p3320 = inttoptr i64 %v3318 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3320, ptr %p3319, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot22, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  store i32 0, ptr %p3322, align 4, !alias.scope !3, !noalias !4
  %v3323 = load i64, ptr %slot9, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i32 2, ptr %p3324, align 4, !alias.scope !3, !noalias !4
  %v3325 = load i64, ptr %slot23, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  %ld3327 = load i32, ptr %p3326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3327, ptr %slot508, align 8
  %v3328 = load i32, ptr %slot508, align 8
  %v3329 = load i64, ptr %slot9, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i32 %v3328, ptr %p3330, align 4, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot8, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i32 1, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot6, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i32, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3335, ptr %slot509, align 8
  %v3336 = load i32, ptr %slot509, align 8
  %cv3337 = zext i32 %v3336 to i64
  %cond3338 = icmp ne i64 %cv3337, 0
  br i1 %cond3338, label %bb_rcslotdrop634, label %bb_rcslotdone634
bb_rcslotdrop634:
  %v3339 = load i64, ptr %slot6, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 0, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot35, align 8
  store i64 %v3341, ptr %slot510, align 8
  %v3342 = load i64, ptr %slot7, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %ld3344 = load i32, ptr %p3343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3344, ptr %slot511, align 8
  %v3345 = load i32, ptr %slot511, align 8
  %op3346 = and i32 %v3345, 28
  store i32 %op3346, ptr %slot512, align 8
  %v3347 = load i32, ptr %slot512, align 8
  %cv3348 = zext i32 %v3347 to i64
  %cond3349 = icmp ne i64 %cv3348, 0
  br i1 %cond3349, label %bb_rcslotrole634, label %bb_rcslotowner634
bb_rcslotrole634:
  %v3350 = load i64, ptr %slot56, align 8
  store i64 %v3350, ptr %slot513, align 8
  %v3351 = load i64, ptr %slot510, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %ld3353 = load i64, ptr %p3352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3353, ptr %slot514, align 8
  %v3354 = load i64, ptr %slot514, align 8
  %cmp3355 = icmp ne i64 %v3354, 0
  %cv3356 = zext i1 %cmp3355 to i32
  store i32 %cv3356, ptr %slot515, align 8
  %v3357 = load i32, ptr %slot515, align 8
  %cv3358 = zext i32 %v3357 to i64
  %cond3359 = icmp ne i64 %cv3358, 0
  br i1 %cond3359, label %bb_rcgnn650, label %bb_rcgdone650
bb_rcgnn650:
  %v3360 = load i64, ptr %slot514, align 8
  %op3361 = sub i64 %v3360, 16
  store i64 %op3361, ptr %slot516, align 8
  %v3362 = load i64, ptr %slot514, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %rgep3364 = getelementptr i8, ptr %p3363, i64 -16
  %ld3365 = load i64, ptr %rgep3364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3365, ptr %slot517, align 8
  %v3366 = load i64, ptr %slot517, align 8
  %op3367 = and i64 %v3366, 4611686018427387906
  store i64 %op3367, ptr %slot518, align 8
  %v3368 = load i64, ptr %slot518, align 8
  %cmp3369 = icmp ne i64 %v3368, 0
  %cv3370 = zext i1 %cmp3369 to i32
  store i32 %cv3370, ptr %slot519, align 8
  %v3371 = load i32, ptr %slot519, align 8
  %cv3372 = zext i32 %v3371 to i64
  %cond3373 = icmp ne i64 %cv3372, 0
  br i1 %cond3373, label %bb_rcgclear650, label %bb_rcgcounted650
bb_rcgcounted650:
  %v3374 = load i64, ptr %slot514, align 8
  %op3375 = sub i64 %v3374, 24
  store i64 %op3375, ptr %slot520, align 8
  %v3376 = load i64, ptr %slot514, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  %rgep3378 = getelementptr i8, ptr %p3377, i64 -24
  %ld3379 = load i64, ptr %rgep3378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3379, ptr %slot521, align 8
  %v3380 = load i64, ptr %slot521, align 8
  %op3381 = sub i64 %v3380, 1
  store i64 %op3381, ptr %slot522, align 8
  %v3382 = load i64, ptr %slot522, align 8
  %cmp3383 = icmp eq i64 %v3382, 0
  %cv3384 = zext i1 %cmp3383 to i32
  store i32 %cv3384, ptr %slot523, align 8
  %v3385 = load i32, ptr %slot523, align 8
  %cv3386 = zext i32 %v3385 to i64
  %cond3387 = icmp ne i64 %cv3386, 0
  br i1 %cond3387, label %bb_rcglast650, label %bb_rcgdec650
bb_rcglast650:
  %v3388 = load i64, ptr %slot514, align 8
  %op3389 = sub i64 %v3388, 32
  store i64 %op3389, ptr %slot524, align 8
  %v3390 = load i64, ptr %slot514, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %rgep3392 = getelementptr i8, ptr %p3391, i64 -32
  %ld3393 = load i64, ptr %rgep3392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3393, ptr %slot525, align 8
  %v3394 = load i64, ptr %slot525, align 8
  %cmp3395 = icmp ne i64 %v3394, 0
  %cv3396 = zext i1 %cmp3395 to i32
  store i32 %cv3396, ptr %slot526, align 8
  %v3397 = load i32, ptr %slot526, align 8
  %cv3398 = zext i32 %v3397 to i64
  %cond3399 = icmp ne i64 %cv3398, 0
  br i1 %cond3399, label %bb_rcgdec650, label %bb_rcgslow650
bb_rcgslow650:
  %v3400 = load i64, ptr %slot513, align 8
  %v3401 = load i64, ptr %slot510, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v3400, i64 %v3401) nomerge, !dbg !124
  br label %bb_rcgdone650
bb_rcgdec650:
  %v3402 = load i64, ptr %slot522, align 8
  %v3403 = load i64, ptr %slot514, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %rgep3405 = getelementptr i8, ptr %p3404, i64 -24
  store i64 %v3402, ptr %rgep3405, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear650
bb_rcgclear650:
  %v3406 = load i64, ptr %slot510, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i64 0, ptr %p3407, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone650
bb_rcgdone650:
  br label %bb_rcslotdone634
bb_rcslotowner634:
  %v3408 = load i64, ptr %slot56, align 8
  store i64 %v3408, ptr %slot527, align 8
  %v3409 = load i64, ptr %slot510, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i64, ptr %p3410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3411, ptr %slot528, align 8
  %v3412 = load i64, ptr %slot528, align 8
  %cmp3413 = icmp ne i64 %v3412, 0
  %cv3414 = zext i1 %cmp3413 to i32
  store i32 %cv3414, ptr %slot529, align 8
  %v3415 = load i32, ptr %slot529, align 8
  %cv3416 = zext i32 %v3415 to i64
  %cond3417 = icmp ne i64 %cv3416, 0
  br i1 %cond3417, label %bb_rcgnn665, label %bb_rcgdone665
bb_rcgnn665:
  %v3418 = load i64, ptr %slot528, align 8
  %op3419 = sub i64 %v3418, 16
  store i64 %op3419, ptr %slot530, align 8
  %v3420 = load i64, ptr %slot528, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  %rgep3422 = getelementptr i8, ptr %p3421, i64 -16
  %ld3423 = load i64, ptr %rgep3422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3423, ptr %slot531, align 8
  %v3424 = load i64, ptr %slot531, align 8
  %op3425 = and i64 %v3424, 4611686018427387906
  store i64 %op3425, ptr %slot532, align 8
  %v3426 = load i64, ptr %slot532, align 8
  %cmp3427 = icmp ne i64 %v3426, 0
  %cv3428 = zext i1 %cmp3427 to i32
  store i32 %cv3428, ptr %slot533, align 8
  %v3429 = load i32, ptr %slot533, align 8
  %cv3430 = zext i32 %v3429 to i64
  %cond3431 = icmp ne i64 %cv3430, 0
  br i1 %cond3431, label %bb_rcgclear665, label %bb_rcgcounted665
bb_rcgcounted665:
  %v3432 = load i64, ptr %slot528, align 8
  %op3433 = sub i64 %v3432, 32
  store i64 %op3433, ptr %slot534, align 8
  %v3434 = load i64, ptr %slot528, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %rgep3436 = getelementptr i8, ptr %p3435, i64 -32
  %ld3437 = load i64, ptr %rgep3436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3437, ptr %slot535, align 8
  %v3438 = load i64, ptr %slot535, align 8
  %op3439 = sub i64 %v3438, 1
  store i64 %op3439, ptr %slot536, align 8
  %v3440 = load i64, ptr %slot536, align 8
  %cmp3441 = icmp eq i64 %v3440, 0
  %cv3442 = zext i1 %cmp3441 to i32
  store i32 %cv3442, ptr %slot537, align 8
  %v3443 = load i32, ptr %slot537, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcglast665, label %bb_rcgdec665
bb_rcglast665:
  %v3446 = load i64, ptr %slot528, align 8
  %op3447 = sub i64 %v3446, 24
  store i64 %op3447, ptr %slot538, align 8
  %v3448 = load i64, ptr %slot528, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  %rgep3450 = getelementptr i8, ptr %p3449, i64 -24
  %ld3451 = load i64, ptr %rgep3450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3451, ptr %slot539, align 8
  %v3452 = load i64, ptr %slot539, align 8
  %cmp3453 = icmp ne i64 %v3452, 0
  %cv3454 = zext i1 %cmp3453 to i32
  store i32 %cv3454, ptr %slot540, align 8
  %v3455 = load i32, ptr %slot540, align 8
  %cv3456 = zext i32 %v3455 to i64
  %cond3457 = icmp ne i64 %cv3456, 0
  br i1 %cond3457, label %bb_rcgdec665, label %bb_rcgslow665
bb_rcgslow665:
  %v3458 = load i64, ptr %slot527, align 8
  %v3459 = load i64, ptr %slot510, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v3458, i64 %v3459) nomerge, !dbg !124
  br label %bb_rcgdone665
bb_rcgdec665:
  %v3460 = load i64, ptr %slot536, align 8
  %v3461 = load i64, ptr %slot528, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %rgep3463 = getelementptr i8, ptr %p3462, i64 -32
  store i64 %v3460, ptr %rgep3463, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear665
bb_rcgclear665:
  %v3464 = load i64, ptr %slot510, align 8
  %p3465 = inttoptr i64 %v3464 to ptr
  store i64 0, ptr %p3465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone665
bb_rcgdone665:
  br label %bb_rcslotdone634
bb_rcslotdone634:
  %v3466 = load i64, ptr %slot41, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  store i64 0, ptr %p3467, align 8, !alias.scope !3, !noalias !4
  %v3468 = load i64, ptr %slot41, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i64, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3470, ptr %slot541, align 8
  %v3471 = load i64, ptr %slot541, align 8
  %v3472 = load i64, ptr %slot37, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  store i64 %v3471, ptr %p3473, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_i17:
  %v3474 = load i64, ptr %slot37, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  %ld3476 = load i64, ptr %p3475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3476, ptr %slot542, align 8
  %v3477 = load i64, ptr %slot542, align 8
  %v3478 = load i64, ptr %slot41, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i64 %v3477, ptr %p3479, align 8, !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot36, align 8
  %v3481 = load i64, ptr %slot42, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i64 %v3480, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  %v3483 = load i64, ptr %slot42, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  %ld3485 = load i64, ptr %p3484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3485, ptr %slot543, align 8
  %v3486 = load i64, ptr %slot543, align 8
  %op3487 = add i64 %v3486, 0
  store i64 %op3487, ptr %slot544, align 8
  %v3488 = load i64, ptr %slot544, align 8
  %v3489 = load i64, ptr %slot42, align 8
  %p3490 = inttoptr i64 %v3489 to ptr
  store i64 %v3488, ptr %p3490, align 8, !alias.scope !3, !noalias !4
  %v3491 = load i64, ptr %slot16, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %ld3493 = load i32, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3493, ptr %slot545, align 8
  %v3494 = load i32, ptr %slot545, align 8
  %cv3495 = zext i32 %v3494 to i64
  %cond3496 = icmp ne i64 %cv3495, 0
  br i1 %cond3496, label %bb_rcslotdrop675, label %bb_rcslotdone675
bb_rcslotdrop675:
  %v3497 = load i64, ptr %slot16, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  store i32 0, ptr %p3498, align 4, !alias.scope !3, !noalias !4
  %v3499 = load i64, ptr %slot26, align 8
  store i64 %v3499, ptr %slot546, align 8
  %v3500 = load i64, ptr %slot17, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  %ld3502 = load i32, ptr %p3501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3502, ptr %slot547, align 8
  %v3503 = load i32, ptr %slot547, align 8
  %op3504 = and i32 %v3503, 28
  store i32 %op3504, ptr %slot548, align 8
  %v3505 = load i32, ptr %slot548, align 8
  %cv3506 = zext i32 %v3505 to i64
  %cond3507 = icmp ne i64 %cv3506, 0
  br i1 %cond3507, label %bb_rcslotrole675, label %bb_rcslotowner675
bb_rcslotrole675:
  %v3508 = load i64, ptr %slot56, align 8
  store i64 %v3508, ptr %slot549, align 8
  %v3509 = load i64, ptr %slot549, align 8
  %v3510 = load i64, ptr %slot546, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3509, i64 %v3510) nomerge, !dbg !126
  br label %bb_rcslotdone675
bb_rcslotowner675:
  %v3511 = load i64, ptr %slot56, align 8
  store i64 %v3511, ptr %slot550, align 8
  %v3512 = load i64, ptr %slot550, align 8
  %v3513 = load i64, ptr %slot546, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3512, i64 %v3513) nomerge, !dbg !126
  br label %bb_rcslotdone675
bb_rcslotdone675:
  %v3514 = load i64, ptr %slot42, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  %ld3516 = load i64, ptr %p3515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3516, ptr %slot551, align 8
  %v3517 = load i64, ptr %slot551, align 8
  %op3518 = add i64 %v3517, 24
  store i64 %op3518, ptr %slot552, align 8
  %v3519 = load i64, ptr %slot552, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  %ld3521 = load i64, ptr %p3520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3521, ptr %slot553, align 8
  %v3522 = load i64, ptr %slot553, align 8
  %v3523 = load i64, ptr %slot42, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  store i64 %v3522, ptr %p3524, align 8, !alias.scope !3, !noalias !4
  %v3525 = load i64, ptr %slot42, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  %ld3527 = load i64, ptr %p3526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3527, ptr %slot554, align 8
  %v3528 = load i64, ptr %slot554, align 8
  %v3529 = load i64, ptr %slot29, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  store i64 %v3528, ptr %p3530, align 8, !alias.scope !3, !noalias !4
  %v3531 = load i64, ptr %slot29, align 8
  store i64 %v3531, ptr %slot555, align 8
  %v3532 = load i64, ptr %slot31, align 8
  store i64 %v3532, ptr %slot556, align 8
  %v3533 = load i64, ptr %slot555, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %ld3535 = load i64, ptr %p3534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3535, ptr %slot557, align 8
  %v3536 = load i64, ptr %slot557, align 8
  %cmp3537 = icmp ne i64 %v3536, 0
  %cv3538 = zext i1 %cmp3537 to i32
  store i32 %cv3538, ptr %slot558, align 8
  %v3539 = load i32, ptr %slot558, align 8
  %cv3540 = zext i32 %v3539 to i64
  %cond3541 = icmp ne i64 %cv3540, 0
  br i1 %cond3541, label %bb_rcgnn689, label %bb_rcgstore689
bb_rcgnn689:
  %v3542 = load i64, ptr %slot557, align 8
  %op3543 = sub i64 %v3542, 16
  store i64 %op3543, ptr %slot559, align 8
  %v3544 = load i64, ptr %slot557, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %rgep3546 = getelementptr i8, ptr %p3545, i64 -16
  %ld3547 = load i64, ptr %rgep3546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3547, ptr %slot560, align 8
  %v3548 = load i64, ptr %slot560, align 8
  %op3549 = and i64 %v3548, 4611686018427387906
  store i64 %op3549, ptr %slot561, align 8
  %v3550 = load i64, ptr %slot561, align 8
  %cmp3551 = icmp ne i64 %v3550, 0
  %cv3552 = zext i1 %cmp3551 to i32
  store i32 %cv3552, ptr %slot562, align 8
  %v3553 = load i32, ptr %slot562, align 8
  %cv3554 = zext i32 %v3553 to i64
  %cond3555 = icmp ne i64 %cv3554, 0
  br i1 %cond3555, label %bb_rcgstore689, label %bb_rcginc689
bb_rcginc689:
  %v3556 = load i64, ptr %slot557, align 8
  %op3557 = sub i64 %v3556, 24
  store i64 %op3557, ptr %slot563, align 8
  %v3558 = load i64, ptr %slot557, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  %rgep3560 = getelementptr i8, ptr %p3559, i64 -24
  %ld3561 = load i64, ptr %rgep3560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3561, ptr %slot564, align 8
  %v3562 = load i64, ptr %slot564, align 8
  %op3563 = add i64 %v3562, 1
  store i64 %op3563, ptr %slot565, align 8
  %v3564 = load i64, ptr %slot565, align 8
  %cmp3565 = icmp eq i64 %v3564, 0
  %cv3566 = zext i1 %cmp3565 to i32
  store i32 %cv3566, ptr %slot566, align 8
  %v3567 = load i32, ptr %slot566, align 8
  %cv3568 = zext i32 %v3567 to i64
  %cond3569 = icmp ne i64 %cv3568, 0
  br i1 %cond3569, label %bb_rcglimit689, label %bb_rcgcapacity689
bb_rcglimit689:
  %v3570 = load i64, ptr %slot1, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %call3572 = call i32 @myl_qbe_rc_status(ptr %p3571, i32 2) nomerge, !dbg !128
  store i32 %call3572, ptr %slot567, align 8
  br label %bb_failure
bb_rcgcapacity689:
  %v3573 = load i64, ptr %slot565, align 8
  %v3574 = load i64, ptr %slot557, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %rgep3576 = getelementptr i8, ptr %p3575, i64 -24
  store i64 %v3573, ptr %rgep3576, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore689
bb_rcgstore689:
  %v3577 = load i64, ptr %slot557, align 8
  %v3578 = load i64, ptr %slot556, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  store i64 %v3577, ptr %p3579, align 8, !alias.scope !3, !noalias !4
  %v3580 = load i64, ptr %slot23, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  store i32 2, ptr %p3581, align 4, !alias.scope !3, !noalias !4
  %v3582 = load i64, ptr %slot23, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  store i32 16, ptr %p3583, align 4, !alias.scope !3, !noalias !4
  %v3584 = load i64, ptr %slot22, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i32 1, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  %v3586 = load i64, ptr %slot16, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i32, ptr %p3587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3588, ptr %slot568, align 8
  %v3589 = load i32, ptr %slot568, align 8
  %cv3590 = zext i32 %v3589 to i64
  %cond3591 = icmp ne i64 %cv3590, 0
  br i1 %cond3591, label %bb_rcslotdrop705, label %bb_rcslotdone705
bb_rcslotdrop705:
  %v3592 = load i64, ptr %slot16, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  store i32 0, ptr %p3593, align 4, !alias.scope !3, !noalias !4
  %v3594 = load i64, ptr %slot26, align 8
  store i64 %v3594, ptr %slot569, align 8
  %v3595 = load i64, ptr %slot17, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %ld3597 = load i32, ptr %p3596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3597, ptr %slot570, align 8
  %v3598 = load i32, ptr %slot570, align 8
  %op3599 = and i32 %v3598, 28
  store i32 %op3599, ptr %slot571, align 8
  %v3600 = load i32, ptr %slot571, align 8
  %cv3601 = zext i32 %v3600 to i64
  %cond3602 = icmp ne i64 %cv3601, 0
  br i1 %cond3602, label %bb_rcslotrole705, label %bb_rcslotowner705
bb_rcslotrole705:
  %v3603 = load i64, ptr %slot56, align 8
  store i64 %v3603, ptr %slot572, align 8
  %v3604 = load i64, ptr %slot572, align 8
  %v3605 = load i64, ptr %slot569, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v3604, i64 %v3605) nomerge, !dbg !128
  br label %bb_rcslotdone705
bb_rcslotowner705:
  %v3606 = load i64, ptr %slot56, align 8
  store i64 %v3606, ptr %slot573, align 8
  %v3607 = load i64, ptr %slot573, align 8
  %v3608 = load i64, ptr %slot569, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v3607, i64 %v3608) nomerge, !dbg !128
  br label %bb_rcslotdone705
bb_rcslotdone705:
  %v3609 = load i64, ptr %slot26, align 8
  store i64 %v3609, ptr %slot574, align 8
  %v3610 = load i64, ptr %slot31, align 8
  store i64 %v3610, ptr %slot575, align 8
  %v3611 = load i64, ptr %slot575, align 8
  %v3612 = load i64, ptr %slot574, align 8
  %p3613 = inttoptr i64 %v3611 to ptr
  %p3614 = inttoptr i64 %v3612 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3614, ptr %p3613, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot17, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  store i32 2, ptr %p3616, align 4, !alias.scope !3, !noalias !4
  %v3617 = load i64, ptr %slot23, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  %ld3619 = load i32, ptr %p3618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3619, ptr %slot576, align 8
  %v3620 = load i32, ptr %slot576, align 8
  %v3621 = load i64, ptr %slot17, align 8
  %p3622 = inttoptr i64 %v3621 to ptr
  store i32 %v3620, ptr %p3622, align 4, !alias.scope !3, !noalias !4
  %v3623 = load i64, ptr %slot22, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  store i32 0, ptr %p3624, align 4, !alias.scope !3, !noalias !4
  %v3625 = load i64, ptr %slot16, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i32 1, ptr %p3626, align 4, !alias.scope !3, !noalias !4
  %v3627 = load i64, ptr %slot574, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i64, ptr %p3628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3629, ptr %slot577, align 8
  %v3630 = load i64, ptr %slot577, align 8
  %v3631 = load i64, ptr %slot42, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  store i64 %v3630, ptr %p3632, align 8, !alias.scope !3, !noalias !4
  %v3633 = load i64, ptr %slot42, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  %ld3635 = load i64, ptr %p3634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3635, ptr %slot578, align 8
  %v3636 = load i64, ptr %slot578, align 8
  %v3637 = load i64, ptr %slot29, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i64 %v3636, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot29, align 8
  store i64 %v3639, ptr %slot579, align 8
  %v3640 = load i64, ptr %slot16, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot580, align 8
  %v3643 = load i64, ptr %slot17, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %ld3645 = load i32, ptr %p3644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3645, ptr %slot581, align 8
  %v3646 = load i32, ptr %slot581, align 8
  %op3647 = and i32 %v3646, 24
  store i32 %op3647, ptr %slot581, align 8
  %v3648 = load i32, ptr %slot581, align 8
  %cmp3649 = icmp eq i32 %v3648, 0
  %cv3650 = zext i1 %cmp3649 to i32
  store i32 %cv3650, ptr %slot582, align 8
  %v3651 = load i32, ptr %slot580, align 8
  %v3652 = load i32, ptr %slot582, align 8
  %op3653 = and i32 %v3651, %v3652
  store i32 %op3653, ptr %slot583, align 8
  %v3654 = load i32, ptr %slot583, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcprivateown729, label %bb_rcprivateloan729
bb_rcprivateown729:
  %v3657 = load i64, ptr %slot31, align 8
  store i64 %v3657, ptr %slot584, align 8
  %v3658 = load i64, ptr %slot57, align 8
  store i64 %v3658, ptr %slot585, align 8
  %v3659 = load i64, ptr %slot579, align 8
  %v3660 = load i64, ptr %slot584, align 8
  %op3661 = sub i64 %v3659, %v3660
  store i64 %op3661, ptr %slot586, align 8
  %v3662 = load i64, ptr %slot584, align 8
  %v3663 = load i64, ptr %slot579, align 8
  %op3664 = sub i64 %v3662, %v3663
  store i64 %op3664, ptr %slot587, align 8
  %v3665 = load i64, ptr %slot586, align 8
  %cmp3666 = icmp ult i64 %v3665, 8
  %cv3667 = zext i1 %cmp3666 to i32
  store i32 %cv3667, ptr %slot588, align 8
  %v3668 = load i64, ptr %slot587, align 8
  %cmp3669 = icmp ult i64 %v3668, 8
  %cv3670 = zext i1 %cmp3669 to i32
  store i32 %cv3670, ptr %slot589, align 8
  %v3671 = load i32, ptr %slot588, align 8
  %v3672 = load i32, ptr %slot589, align 8
  %op3673 = or i32 %v3671, %v3672
  store i32 %op3673, ptr %slot590, align 8
  %v3674 = load i32, ptr %slot590, align 8
  %cv3675 = zext i32 %v3674 to i64
  %cond3676 = icmp ne i64 %cv3675, 0
  br i1 %cond3676, label %bb_rcmoveslow732, label %bb_rcmovecheck732
bb_rcmovecheck732:
  %v3677 = load i64, ptr %slot579, align 8
  %p3679 = inttoptr i64 %v3677 to ptr
  %gep3680 = getelementptr i8, ptr %p3679, i64 0
  %op3678 = ptrtoint ptr %gep3680 to i64
  store i64 %op3678, ptr %slot591, align 8
  %v3681 = load i64, ptr %slot591, align 8
  %p3682 = inttoptr i64 %v3681 to ptr
  %ld3683 = load i64, ptr %p3682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3683, ptr %slot592, align 8
  %v3684 = load i64, ptr %slot592, align 8
  %cmp3685 = icmp ne i64 %v3684, 0
  %cv3686 = zext i1 %cmp3685 to i32
  store i32 %cv3686, ptr %slot593, align 8
  %v3687 = load i32, ptr %slot593, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcmoveheader740, label %bb_rcmovenext740
bb_rcmoveheader740:
  %v3690 = load i64, ptr %slot592, align 8
  %op3691 = sub i64 %v3690, 16
  store i64 %op3691, ptr %slot594, align 8
  %v3692 = load i64, ptr %slot592, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  %rgep3694 = getelementptr i8, ptr %p3693, i64 -16
  %ld3695 = load i64, ptr %rgep3694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3695, ptr %slot595, align 8
  %v3696 = load i64, ptr %slot595, align 8
  %op3697 = and i64 %v3696, 5764607523034234881
  store i64 %op3697, ptr %slot596, align 8
  %v3698 = load i64, ptr %slot596, align 8
  %cmp3699 = icmp ne i64 %v3698, 0
  %cv3700 = zext i1 %cmp3699 to i32
  store i32 %cv3700, ptr %slot597, align 8
  %v3701 = load i32, ptr %slot597, align 8
  %cv3702 = zext i32 %v3701 to i64
  %cond3703 = icmp ne i64 %cv3702, 0
  br i1 %cond3703, label %bb_rcmoveslow732, label %bb_rcmovenext740
bb_rcmovenext740:
  %v3704 = load i64, ptr %slot579, align 8
  %v3705 = load i64, ptr %slot584, align 8
  %p3706 = inttoptr i64 %v3704 to ptr
  %p3707 = inttoptr i64 %v3705 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3707, ptr %p3706, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3708 = load i64, ptr %slot579, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i64 0, ptr %p3709, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved732
bb_rcmoveslow732:
  %v3710 = load i64, ptr %slot56, align 8
  %v3711 = load i64, ptr %slot584, align 8
  %v3712 = load i64, ptr %slot579, align 8
  %v3713 = load i64, ptr %slot585, align 8
  %cv3714 = trunc i64 %v3713 to i32
  %call3715 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3710, i64 %v3711, i64 %v3712, i32 %cv3714) nomerge, !dbg !130
  store i32 %call3715, ptr %slot598, align 8
  %v3716 = load i32, ptr %slot598, align 8
  %cv3717 = zext i32 %v3716 to i64
  %cond3718 = icmp ne i64 %cv3717, 0
  br i1 %cond3718, label %bb_rcsuccess747, label %bb_rcfailure747
bb_rcfailure747:
  %v3719 = load i64, ptr %slot56, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %call3721 = call i32 @myl_rc_take_failure(ptr %p3720) nomerge, !dbg !130
  store i32 %call3721, ptr %slot599, align 8
  %v3722 = load i64, ptr %slot1, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  %v3724 = load i32, ptr %slot599, align 8
  %call3725 = call i32 @myl_qbe_rc_status(ptr %p3723, i32 %v3724) nomerge, !dbg !130
  store i32 %call3725, ptr %slot600, align 8
  br label %bb_failure
bb_rcsuccess747:
  br label %bb_rcmoved732
bb_rcmoved732:
  %v3726 = load i64, ptr %slot16, align 8
  %p3727 = inttoptr i64 %v3726 to ptr
  store i32 0, ptr %p3727, align 4, !alias.scope !3, !noalias !4
  %v3728 = load i64, ptr %slot23, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  store i32 2, ptr %p3729, align 4, !alias.scope !3, !noalias !4
  %v3730 = load i64, ptr %slot22, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  store i32 1, ptr %p3731, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared729
bb_rcprivateloan729:
  %v3732 = load i64, ptr %slot16, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  %ld3734 = load i32, ptr %p3733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3734, ptr %slot601, align 8
  %v3735 = load i64, ptr %slot17, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %ld3737 = load i32, ptr %p3736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3737, ptr %slot602, align 8
  %v3738 = load i32, ptr %slot602, align 8
  %cmp3739 = icmp eq i32 %v3738, 16
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot603, align 8
  %v3741 = load i32, ptr %slot603, align 8
  %v3742 = load i32, ptr %slot601, align 8
  %op3743 = and i32 %v3741, %v3742
  store i32 %op3743, ptr %slot603, align 8
  %v3744 = load i32, ptr %slot603, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcprivatemove729, label %bb_rcprivatenew729
bb_rcprivatemove729:
  %v3747 = load i64, ptr %slot31, align 8
  store i64 %v3747, ptr %slot604, align 8
  %v3748 = load i64, ptr %slot579, align 8
  %v3749 = load i64, ptr %slot604, align 8
  %p3750 = inttoptr i64 %v3748 to ptr
  %p3751 = inttoptr i64 %v3749 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3751, ptr %p3750, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3752 = load i64, ptr %slot579, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  store i64 0, ptr %p3753, align 8, !alias.scope !3, !noalias !4
  %v3754 = load i64, ptr %slot23, align 8
  %p3755 = inttoptr i64 %v3754 to ptr
  store i32 2, ptr %p3755, align 4, !alias.scope !3, !noalias !4
  %v3756 = load i64, ptr %slot23, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  store i32 16, ptr %p3757, align 4, !alias.scope !3, !noalias !4
  %v3758 = load i64, ptr %slot22, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i32 1, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot16, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  store i32 0, ptr %p3761, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared729
bb_rcprivatenew729:
  %v3762 = load i64, ptr %slot31, align 8
  store i64 %v3762, ptr %slot605, align 8
  %v3763 = load i64, ptr %slot579, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  %ld3765 = load i64, ptr %p3764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3765, ptr %slot606, align 8
  %v3766 = load i64, ptr %slot606, align 8
  %cmp3767 = icmp ne i64 %v3766, 0
  %cv3768 = zext i1 %cmp3767 to i32
  store i32 %cv3768, ptr %slot607, align 8
  %v3769 = load i32, ptr %slot607, align 8
  %cv3770 = zext i32 %v3769 to i64
  %cond3771 = icmp ne i64 %cv3770, 0
  br i1 %cond3771, label %bb_rcgnn765, label %bb_rcgstore765
bb_rcgnn765:
  %v3772 = load i64, ptr %slot606, align 8
  %op3773 = sub i64 %v3772, 16
  store i64 %op3773, ptr %slot608, align 8
  %v3774 = load i64, ptr %slot606, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  %rgep3776 = getelementptr i8, ptr %p3775, i64 -16
  %ld3777 = load i64, ptr %rgep3776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3777, ptr %slot609, align 8
  %v3778 = load i64, ptr %slot609, align 8
  %op3779 = and i64 %v3778, 4611686018427387906
  store i64 %op3779, ptr %slot610, align 8
  %v3780 = load i64, ptr %slot610, align 8
  %cmp3781 = icmp ne i64 %v3780, 0
  %cv3782 = zext i1 %cmp3781 to i32
  store i32 %cv3782, ptr %slot611, align 8
  %v3783 = load i32, ptr %slot611, align 8
  %cv3784 = zext i32 %v3783 to i64
  %cond3785 = icmp ne i64 %cv3784, 0
  br i1 %cond3785, label %bb_rcgstore765, label %bb_rcginc765
bb_rcginc765:
  %v3786 = load i64, ptr %slot606, align 8
  %op3787 = sub i64 %v3786, 24
  store i64 %op3787, ptr %slot612, align 8
  %v3788 = load i64, ptr %slot606, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %rgep3790 = getelementptr i8, ptr %p3789, i64 -24
  %ld3791 = load i64, ptr %rgep3790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3791, ptr %slot613, align 8
  %v3792 = load i64, ptr %slot613, align 8
  %op3793 = add i64 %v3792, 1
  store i64 %op3793, ptr %slot614, align 8
  %v3794 = load i64, ptr %slot614, align 8
  %cmp3795 = icmp eq i64 %v3794, 0
  %cv3796 = zext i1 %cmp3795 to i32
  store i32 %cv3796, ptr %slot615, align 8
  %v3797 = load i32, ptr %slot615, align 8
  %cv3798 = zext i32 %v3797 to i64
  %cond3799 = icmp ne i64 %cv3798, 0
  br i1 %cond3799, label %bb_rcglimit765, label %bb_rcgcapacity765
bb_rcglimit765:
  %v3800 = load i64, ptr %slot1, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  %call3802 = call i32 @myl_qbe_rc_status(ptr %p3801, i32 2) nomerge, !dbg !130
  store i32 %call3802, ptr %slot616, align 8
  br label %bb_failure
bb_rcgcapacity765:
  %v3803 = load i64, ptr %slot614, align 8
  %v3804 = load i64, ptr %slot606, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %rgep3806 = getelementptr i8, ptr %p3805, i64 -24
  store i64 %v3803, ptr %rgep3806, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore765
bb_rcgstore765:
  %v3807 = load i64, ptr %slot606, align 8
  %v3808 = load i64, ptr %slot605, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  store i64 %v3807, ptr %p3809, align 8, !alias.scope !3, !noalias !4
  %v3810 = load i64, ptr %slot23, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i32 2, ptr %p3811, align 4, !alias.scope !3, !noalias !4
  %v3812 = load i64, ptr %slot23, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  store i32 16, ptr %p3813, align 4, !alias.scope !3, !noalias !4
  %v3814 = load i64, ptr %slot22, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  store i32 1, ptr %p3815, align 4, !alias.scope !3, !noalias !4
  %v3816 = load i64, ptr %slot16, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  %ld3818 = load i32, ptr %p3817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3818, ptr %slot617, align 8
  %v3819 = load i32, ptr %slot617, align 8
  %cv3820 = zext i32 %v3819 to i64
  %cond3821 = icmp ne i64 %cv3820, 0
  br i1 %cond3821, label %bb_rcslotdrop781, label %bb_rcslotdone781
bb_rcslotdrop781:
  %v3822 = load i64, ptr %slot16, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  store i32 0, ptr %p3823, align 4, !alias.scope !3, !noalias !4
  %v3824 = load i64, ptr %slot26, align 8
  store i64 %v3824, ptr %slot618, align 8
  %v3825 = load i64, ptr %slot17, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %ld3827 = load i32, ptr %p3826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3827, ptr %slot619, align 8
  %v3828 = load i32, ptr %slot619, align 8
  %op3829 = and i32 %v3828, 28
  store i32 %op3829, ptr %slot620, align 8
  %v3830 = load i32, ptr %slot620, align 8
  %cv3831 = zext i32 %v3830 to i64
  %cond3832 = icmp ne i64 %cv3831, 0
  br i1 %cond3832, label %bb_rcslotrole781, label %bb_rcslotowner781
bb_rcslotrole781:
  %v3833 = load i64, ptr %slot56, align 8
  store i64 %v3833, ptr %slot621, align 8
  %v3834 = load i64, ptr %slot618, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  %ld3836 = load i64, ptr %p3835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3836, ptr %slot622, align 8
  %v3837 = load i64, ptr %slot622, align 8
  %cmp3838 = icmp ne i64 %v3837, 0
  %cv3839 = zext i1 %cmp3838 to i32
  store i32 %cv3839, ptr %slot623, align 8
  %v3840 = load i32, ptr %slot623, align 8
  %cv3841 = zext i32 %v3840 to i64
  %cond3842 = icmp ne i64 %cv3841, 0
  br i1 %cond3842, label %bb_rcgnn797, label %bb_rcgdone797
bb_rcgnn797:
  %v3843 = load i64, ptr %slot622, align 8
  %op3844 = sub i64 %v3843, 16
  store i64 %op3844, ptr %slot624, align 8
  %v3845 = load i64, ptr %slot622, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  %rgep3847 = getelementptr i8, ptr %p3846, i64 -16
  %ld3848 = load i64, ptr %rgep3847, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3848, ptr %slot625, align 8
  %v3849 = load i64, ptr %slot625, align 8
  %op3850 = and i64 %v3849, 4611686018427387906
  store i64 %op3850, ptr %slot626, align 8
  %v3851 = load i64, ptr %slot626, align 8
  %cmp3852 = icmp ne i64 %v3851, 0
  %cv3853 = zext i1 %cmp3852 to i32
  store i32 %cv3853, ptr %slot627, align 8
  %v3854 = load i32, ptr %slot627, align 8
  %cv3855 = zext i32 %v3854 to i64
  %cond3856 = icmp ne i64 %cv3855, 0
  br i1 %cond3856, label %bb_rcgclear797, label %bb_rcgcounted797
bb_rcgcounted797:
  %v3857 = load i64, ptr %slot622, align 8
  %op3858 = sub i64 %v3857, 24
  store i64 %op3858, ptr %slot628, align 8
  %v3859 = load i64, ptr %slot622, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  %rgep3861 = getelementptr i8, ptr %p3860, i64 -24
  %ld3862 = load i64, ptr %rgep3861, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3862, ptr %slot629, align 8
  %v3863 = load i64, ptr %slot629, align 8
  %op3864 = sub i64 %v3863, 1
  store i64 %op3864, ptr %slot630, align 8
  %v3865 = load i64, ptr %slot630, align 8
  %cmp3866 = icmp eq i64 %v3865, 0
  %cv3867 = zext i1 %cmp3866 to i32
  store i32 %cv3867, ptr %slot631, align 8
  %v3868 = load i32, ptr %slot631, align 8
  %cv3869 = zext i32 %v3868 to i64
  %cond3870 = icmp ne i64 %cv3869, 0
  br i1 %cond3870, label %bb_rcglast797, label %bb_rcgdec797
bb_rcglast797:
  %v3871 = load i64, ptr %slot622, align 8
  %op3872 = sub i64 %v3871, 32
  store i64 %op3872, ptr %slot632, align 8
  %v3873 = load i64, ptr %slot622, align 8
  %p3874 = inttoptr i64 %v3873 to ptr
  %rgep3875 = getelementptr i8, ptr %p3874, i64 -32
  %ld3876 = load i64, ptr %rgep3875, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3876, ptr %slot633, align 8
  %v3877 = load i64, ptr %slot633, align 8
  %cmp3878 = icmp ne i64 %v3877, 0
  %cv3879 = zext i1 %cmp3878 to i32
  store i32 %cv3879, ptr %slot634, align 8
  %v3880 = load i32, ptr %slot634, align 8
  %cv3881 = zext i32 %v3880 to i64
  %cond3882 = icmp ne i64 %cv3881, 0
  br i1 %cond3882, label %bb_rcgdec797, label %bb_rcgslow797
bb_rcgslow797:
  %v3883 = load i64, ptr %slot621, align 8
  %v3884 = load i64, ptr %slot618, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3883, i64 %v3884) nomerge, !dbg !130
  br label %bb_rcgdone797
bb_rcgdec797:
  %v3885 = load i64, ptr %slot630, align 8
  %v3886 = load i64, ptr %slot622, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %rgep3888 = getelementptr i8, ptr %p3887, i64 -24
  store i64 %v3885, ptr %rgep3888, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear797
bb_rcgclear797:
  %v3889 = load i64, ptr %slot618, align 8
  %p3890 = inttoptr i64 %v3889 to ptr
  store i64 0, ptr %p3890, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone797
bb_rcgdone797:
  br label %bb_rcslotdone781
bb_rcslotowner781:
  %v3891 = load i64, ptr %slot56, align 8
  store i64 %v3891, ptr %slot635, align 8
  %v3892 = load i64, ptr %slot618, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %ld3894 = load i64, ptr %p3893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3894, ptr %slot636, align 8
  %v3895 = load i64, ptr %slot636, align 8
  %cmp3896 = icmp ne i64 %v3895, 0
  %cv3897 = zext i1 %cmp3896 to i32
  store i32 %cv3897, ptr %slot637, align 8
  %v3898 = load i32, ptr %slot637, align 8
  %cv3899 = zext i32 %v3898 to i64
  %cond3900 = icmp ne i64 %cv3899, 0
  br i1 %cond3900, label %bb_rcgnn812, label %bb_rcgdone812
bb_rcgnn812:
  %v3901 = load i64, ptr %slot636, align 8
  %op3902 = sub i64 %v3901, 16
  store i64 %op3902, ptr %slot638, align 8
  %v3903 = load i64, ptr %slot636, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  %rgep3905 = getelementptr i8, ptr %p3904, i64 -16
  %ld3906 = load i64, ptr %rgep3905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3906, ptr %slot639, align 8
  %v3907 = load i64, ptr %slot639, align 8
  %op3908 = and i64 %v3907, 4611686018427387906
  store i64 %op3908, ptr %slot640, align 8
  %v3909 = load i64, ptr %slot640, align 8
  %cmp3910 = icmp ne i64 %v3909, 0
  %cv3911 = zext i1 %cmp3910 to i32
  store i32 %cv3911, ptr %slot641, align 8
  %v3912 = load i32, ptr %slot641, align 8
  %cv3913 = zext i32 %v3912 to i64
  %cond3914 = icmp ne i64 %cv3913, 0
  br i1 %cond3914, label %bb_rcgclear812, label %bb_rcgcounted812
bb_rcgcounted812:
  %v3915 = load i64, ptr %slot636, align 8
  %op3916 = sub i64 %v3915, 32
  store i64 %op3916, ptr %slot642, align 8
  %v3917 = load i64, ptr %slot636, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  %rgep3919 = getelementptr i8, ptr %p3918, i64 -32
  %ld3920 = load i64, ptr %rgep3919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3920, ptr %slot643, align 8
  %v3921 = load i64, ptr %slot643, align 8
  %op3922 = sub i64 %v3921, 1
  store i64 %op3922, ptr %slot644, align 8
  %v3923 = load i64, ptr %slot644, align 8
  %cmp3924 = icmp eq i64 %v3923, 0
  %cv3925 = zext i1 %cmp3924 to i32
  store i32 %cv3925, ptr %slot645, align 8
  %v3926 = load i32, ptr %slot645, align 8
  %cv3927 = zext i32 %v3926 to i64
  %cond3928 = icmp ne i64 %cv3927, 0
  br i1 %cond3928, label %bb_rcglast812, label %bb_rcgdec812
bb_rcglast812:
  %v3929 = load i64, ptr %slot636, align 8
  %op3930 = sub i64 %v3929, 24
  store i64 %op3930, ptr %slot646, align 8
  %v3931 = load i64, ptr %slot636, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  %rgep3933 = getelementptr i8, ptr %p3932, i64 -24
  %ld3934 = load i64, ptr %rgep3933, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3934, ptr %slot647, align 8
  %v3935 = load i64, ptr %slot647, align 8
  %cmp3936 = icmp ne i64 %v3935, 0
  %cv3937 = zext i1 %cmp3936 to i32
  store i32 %cv3937, ptr %slot648, align 8
  %v3938 = load i32, ptr %slot648, align 8
  %cv3939 = zext i32 %v3938 to i64
  %cond3940 = icmp ne i64 %cv3939, 0
  br i1 %cond3940, label %bb_rcgdec812, label %bb_rcgslow812
bb_rcgslow812:
  %v3941 = load i64, ptr %slot635, align 8
  %v3942 = load i64, ptr %slot618, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3941, i64 %v3942) nomerge, !dbg !130
  br label %bb_rcgdone812
bb_rcgdec812:
  %v3943 = load i64, ptr %slot644, align 8
  %v3944 = load i64, ptr %slot636, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  %rgep3946 = getelementptr i8, ptr %p3945, i64 -32
  store i64 %v3943, ptr %rgep3946, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear812
bb_rcgclear812:
  %v3947 = load i64, ptr %slot618, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  store i64 0, ptr %p3948, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone812
bb_rcgdone812:
  br label %bb_rcslotdone781
bb_rcslotdone781:
  br label %bb_rcprivateprepared729
bb_rcprivateprepared729:
  %v3949 = load i64, ptr %slot10, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  %ld3951 = load i32, ptr %p3950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3951, ptr %slot649, align 8
  %v3952 = load i32, ptr %slot649, align 8
  %cv3953 = zext i32 %v3952 to i64
  %cond3954 = icmp ne i64 %cv3953, 0
  br i1 %cond3954, label %bb_rcslotdrop819, label %bb_rcslotdone819
bb_rcslotdrop819:
  %v3955 = load i64, ptr %slot10, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  store i32 0, ptr %p3956, align 4, !alias.scope !3, !noalias !4
  %v3957 = load i64, ptr %slot38, align 8
  store i64 %v3957, ptr %slot650, align 8
  %v3958 = load i64, ptr %slot11, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  %ld3960 = load i32, ptr %p3959, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3960, ptr %slot651, align 8
  %v3961 = load i32, ptr %slot651, align 8
  %op3962 = and i32 %v3961, 28
  store i32 %op3962, ptr %slot652, align 8
  %v3963 = load i32, ptr %slot652, align 8
  %cv3964 = zext i32 %v3963 to i64
  %cond3965 = icmp ne i64 %cv3964, 0
  br i1 %cond3965, label %bb_rcslotrole819, label %bb_rcslotowner819
bb_rcslotrole819:
  %v3966 = load i64, ptr %slot56, align 8
  store i64 %v3966, ptr %slot653, align 8
  %v3967 = load i64, ptr %slot650, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  %ld3969 = load i64, ptr %p3968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3969, ptr %slot654, align 8
  %v3970 = load i64, ptr %slot654, align 8
  %cmp3971 = icmp ne i64 %v3970, 0
  %cv3972 = zext i1 %cmp3971 to i32
  store i32 %cv3972, ptr %slot655, align 8
  %v3973 = load i32, ptr %slot655, align 8
  %cv3974 = zext i32 %v3973 to i64
  %cond3975 = icmp ne i64 %cv3974, 0
  br i1 %cond3975, label %bb_rcgnn835, label %bb_rcgdone835
bb_rcgnn835:
  %v3976 = load i64, ptr %slot654, align 8
  %op3977 = sub i64 %v3976, 16
  store i64 %op3977, ptr %slot656, align 8
  %v3978 = load i64, ptr %slot654, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  %rgep3980 = getelementptr i8, ptr %p3979, i64 -16
  %ld3981 = load i64, ptr %rgep3980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3981, ptr %slot657, align 8
  %v3982 = load i64, ptr %slot657, align 8
  %op3983 = and i64 %v3982, 4611686018427387906
  store i64 %op3983, ptr %slot658, align 8
  %v3984 = load i64, ptr %slot658, align 8
  %cmp3985 = icmp ne i64 %v3984, 0
  %cv3986 = zext i1 %cmp3985 to i32
  store i32 %cv3986, ptr %slot659, align 8
  %v3987 = load i32, ptr %slot659, align 8
  %cv3988 = zext i32 %v3987 to i64
  %cond3989 = icmp ne i64 %cv3988, 0
  br i1 %cond3989, label %bb_rcgclear835, label %bb_rcgcounted835
bb_rcgcounted835:
  %v3990 = load i64, ptr %slot654, align 8
  %op3991 = sub i64 %v3990, 24
  store i64 %op3991, ptr %slot660, align 8
  %v3992 = load i64, ptr %slot654, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  %rgep3994 = getelementptr i8, ptr %p3993, i64 -24
  %ld3995 = load i64, ptr %rgep3994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3995, ptr %slot661, align 8
  %v3996 = load i64, ptr %slot661, align 8
  %op3997 = sub i64 %v3996, 1
  store i64 %op3997, ptr %slot662, align 8
  %v3998 = load i64, ptr %slot662, align 8
  %cmp3999 = icmp eq i64 %v3998, 0
  %cv4000 = zext i1 %cmp3999 to i32
  store i32 %cv4000, ptr %slot663, align 8
  %v4001 = load i32, ptr %slot663, align 8
  %cv4002 = zext i32 %v4001 to i64
  %cond4003 = icmp ne i64 %cv4002, 0
  br i1 %cond4003, label %bb_rcglast835, label %bb_rcgdec835
bb_rcglast835:
  %v4004 = load i64, ptr %slot654, align 8
  %op4005 = sub i64 %v4004, 32
  store i64 %op4005, ptr %slot664, align 8
  %v4006 = load i64, ptr %slot654, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %rgep4008 = getelementptr i8, ptr %p4007, i64 -32
  %ld4009 = load i64, ptr %rgep4008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4009, ptr %slot665, align 8
  %v4010 = load i64, ptr %slot665, align 8
  %cmp4011 = icmp ne i64 %v4010, 0
  %cv4012 = zext i1 %cmp4011 to i32
  store i32 %cv4012, ptr %slot666, align 8
  %v4013 = load i32, ptr %slot666, align 8
  %cv4014 = zext i32 %v4013 to i64
  %cond4015 = icmp ne i64 %cv4014, 0
  br i1 %cond4015, label %bb_rcgdec835, label %bb_rcgslow835
bb_rcgslow835:
  %v4016 = load i64, ptr %slot653, align 8
  %v4017 = load i64, ptr %slot650, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4016, i64 %v4017) nomerge, !dbg !130
  br label %bb_rcgdone835
bb_rcgdec835:
  %v4018 = load i64, ptr %slot662, align 8
  %v4019 = load i64, ptr %slot654, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %rgep4021 = getelementptr i8, ptr %p4020, i64 -24
  store i64 %v4018, ptr %rgep4021, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear835
bb_rcgclear835:
  %v4022 = load i64, ptr %slot650, align 8
  %p4023 = inttoptr i64 %v4022 to ptr
  store i64 0, ptr %p4023, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone835
bb_rcgdone835:
  br label %bb_rcslotdone819
bb_rcslotowner819:
  %v4024 = load i64, ptr %slot56, align 8
  store i64 %v4024, ptr %slot667, align 8
  %v4025 = load i64, ptr %slot650, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  %ld4027 = load i64, ptr %p4026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4027, ptr %slot668, align 8
  %v4028 = load i64, ptr %slot668, align 8
  %cmp4029 = icmp ne i64 %v4028, 0
  %cv4030 = zext i1 %cmp4029 to i32
  store i32 %cv4030, ptr %slot669, align 8
  %v4031 = load i32, ptr %slot669, align 8
  %cv4032 = zext i32 %v4031 to i64
  %cond4033 = icmp ne i64 %cv4032, 0
  br i1 %cond4033, label %bb_rcgnn850, label %bb_rcgdone850
bb_rcgnn850:
  %v4034 = load i64, ptr %slot668, align 8
  %op4035 = sub i64 %v4034, 16
  store i64 %op4035, ptr %slot670, align 8
  %v4036 = load i64, ptr %slot668, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  %rgep4038 = getelementptr i8, ptr %p4037, i64 -16
  %ld4039 = load i64, ptr %rgep4038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4039, ptr %slot671, align 8
  %v4040 = load i64, ptr %slot671, align 8
  %op4041 = and i64 %v4040, 4611686018427387906
  store i64 %op4041, ptr %slot672, align 8
  %v4042 = load i64, ptr %slot672, align 8
  %cmp4043 = icmp ne i64 %v4042, 0
  %cv4044 = zext i1 %cmp4043 to i32
  store i32 %cv4044, ptr %slot673, align 8
  %v4045 = load i32, ptr %slot673, align 8
  %cv4046 = zext i32 %v4045 to i64
  %cond4047 = icmp ne i64 %cv4046, 0
  br i1 %cond4047, label %bb_rcgclear850, label %bb_rcgcounted850
bb_rcgcounted850:
  %v4048 = load i64, ptr %slot668, align 8
  %op4049 = sub i64 %v4048, 32
  store i64 %op4049, ptr %slot674, align 8
  %v4050 = load i64, ptr %slot668, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  %rgep4052 = getelementptr i8, ptr %p4051, i64 -32
  %ld4053 = load i64, ptr %rgep4052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4053, ptr %slot675, align 8
  %v4054 = load i64, ptr %slot675, align 8
  %op4055 = sub i64 %v4054, 1
  store i64 %op4055, ptr %slot676, align 8
  %v4056 = load i64, ptr %slot676, align 8
  %cmp4057 = icmp eq i64 %v4056, 0
  %cv4058 = zext i1 %cmp4057 to i32
  store i32 %cv4058, ptr %slot677, align 8
  %v4059 = load i32, ptr %slot677, align 8
  %cv4060 = zext i32 %v4059 to i64
  %cond4061 = icmp ne i64 %cv4060, 0
  br i1 %cond4061, label %bb_rcglast850, label %bb_rcgdec850
bb_rcglast850:
  %v4062 = load i64, ptr %slot668, align 8
  %op4063 = sub i64 %v4062, 24
  store i64 %op4063, ptr %slot678, align 8
  %v4064 = load i64, ptr %slot668, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  %rgep4066 = getelementptr i8, ptr %p4065, i64 -24
  %ld4067 = load i64, ptr %rgep4066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4067, ptr %slot679, align 8
  %v4068 = load i64, ptr %slot679, align 8
  %cmp4069 = icmp ne i64 %v4068, 0
  %cv4070 = zext i1 %cmp4069 to i32
  store i32 %cv4070, ptr %slot680, align 8
  %v4071 = load i32, ptr %slot680, align 8
  %cv4072 = zext i32 %v4071 to i64
  %cond4073 = icmp ne i64 %cv4072, 0
  br i1 %cond4073, label %bb_rcgdec850, label %bb_rcgslow850
bb_rcgslow850:
  %v4074 = load i64, ptr %slot667, align 8
  %v4075 = load i64, ptr %slot650, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4074, i64 %v4075) nomerge, !dbg !130
  br label %bb_rcgdone850
bb_rcgdec850:
  %v4076 = load i64, ptr %slot676, align 8
  %v4077 = load i64, ptr %slot668, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %rgep4079 = getelementptr i8, ptr %p4078, i64 -32
  store i64 %v4076, ptr %rgep4079, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear850
bb_rcgclear850:
  %v4080 = load i64, ptr %slot650, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  store i64 0, ptr %p4081, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone850
bb_rcgdone850:
  br label %bb_rcslotdone819
bb_rcslotdone819:
  %v4082 = load i64, ptr %slot38, align 8
  store i64 %v4082, ptr %slot681, align 8
  %v4083 = load i64, ptr %slot31, align 8
  store i64 %v4083, ptr %slot682, align 8
  %v4084 = load i64, ptr %slot682, align 8
  %v4085 = load i64, ptr %slot681, align 8
  %p4086 = inttoptr i64 %v4084 to ptr
  %p4087 = inttoptr i64 %v4085 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4087, ptr %p4086, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4088 = load i64, ptr %slot22, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  store i32 0, ptr %p4089, align 4, !alias.scope !3, !noalias !4
  %v4090 = load i64, ptr %slot11, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  store i32 2, ptr %p4091, align 4, !alias.scope !3, !noalias !4
  %v4092 = load i64, ptr %slot23, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  %ld4094 = load i32, ptr %p4093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4094, ptr %slot683, align 8
  %v4095 = load i32, ptr %slot683, align 8
  %v4096 = load i64, ptr %slot11, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  store i32 %v4095, ptr %p4097, align 4, !alias.scope !3, !noalias !4
  %v4098 = load i64, ptr %slot10, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  store i32 1, ptr %p4099, align 4, !alias.scope !3, !noalias !4
  %v4100 = load i64, ptr %slot38, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  %ld4102 = load i64, ptr %p4101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4102, ptr %slot684, align 8
  %v4103 = load i64, ptr %slot684, align 8
  %op4104 = add i64 %v4103, 0
  store i64 %op4104, ptr %slot685, align 8
  %v4105 = load i64, ptr %slot685, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %ld4107 = load i64, ptr %p4106, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4107, ptr %slot686, align 8
  %v4108 = load i64, ptr %slot686, align 8
  %v4109 = load i64, ptr %slot42, align 8
  %p4110 = inttoptr i64 %v4109 to ptr
  store i64 %v4108, ptr %p4110, align 8, !alias.scope !3, !noalias !4
  %v4111 = load i64, ptr %slot42, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  %ld4113 = load i64, ptr %p4112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4113, ptr %slot687, align 8
  %v4114 = load i64, ptr %slot687, align 8
  %cmp4115 = icmp ugt i64 %v4114, 9223372036854775807
  %cv4116 = zext i1 %cmp4115 to i64
  store i64 %cv4116, ptr %slot688, align 8
  %v4117 = load i64, ptr %slot688, align 8
  %cond4118 = icmp ne i64 %v4117, 0
  br i1 %cond4118, label %bb_cast_overflow866, label %bb_cast_ok866
bb_cast_overflow866:
  %v4119 = load i64, ptr %slot1, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %v4121 = load i64, ptr %slot687, align 8
  call void @myl_qbe_fail_cast(ptr %p4120, i64 %v4121, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok866:
  %v4122 = load i64, ptr %slot687, align 8
  %v4123 = load i64, ptr %slot42, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  store i64 %v4122, ptr %p4124, align 8, !alias.scope !3, !noalias !4
  %v4125 = load i64, ptr %slot42, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %ld4127 = load i64, ptr %p4126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4127, ptr %slot689, align 8
  %v4128 = load i64, ptr %slot41, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  %ld4130 = load i64, ptr %p4129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4130, ptr %slot690, align 8
  %v4131 = load i64, ptr %slot690, align 8
  %v4132 = load i64, ptr %slot689, align 8
  %cmp4133 = icmp slt i64 %v4131, %v4132
  %cv4134 = zext i1 %cmp4133 to i64
  store i64 %cv4134, ptr %slot691, align 8
  %v4135 = load i64, ptr %slot691, align 8
  %v4136 = load i64, ptr %slot41, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  store i64 %v4135, ptr %p4137, align 8, !alias.scope !3, !noalias !4
  %v4138 = load i64, ptr %slot41, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  %ld4140 = load i64, ptr %p4139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4140, ptr %slot692, align 8
  %v4141 = load i64, ptr %slot692, align 8
  %cond4142 = icmp ne i64 %v4141, 0
  br i1 %cond4142, label %bb_next871, label %bb_i51
bb_next871:
  %v4143 = load i64, ptr %slot36, align 8
  %v4144 = load i64, ptr %slot41, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i64 %v4143, ptr %p4145, align 8, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot36, align 8
  %v4147 = load i64, ptr %slot51, align 8
  %p4148 = inttoptr i64 %v4146 to ptr
  %p4149 = inttoptr i64 %v4147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4149, ptr %p4148, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v4150 = load i64, ptr %slot51, align 8
  %v4151 = load i64, ptr %slot42, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  store i64 %v4150, ptr %p4152, align 8, !alias.scope !3, !noalias !4
  %v4153 = load i64, ptr %slot42, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  %ld4155 = load i64, ptr %p4154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4155, ptr %slot693, align 8
  %v4156 = load i64, ptr %slot693, align 8
  %op4157 = add i64 %v4156, 0
  store i64 %op4157, ptr %slot694, align 8
  %v4158 = load i64, ptr %slot694, align 8
  %v4159 = load i64, ptr %slot42, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  store i64 %v4158, ptr %p4160, align 8, !alias.scope !3, !noalias !4
  %v4161 = load i64, ptr %slot16, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %ld4163 = load i32, ptr %p4162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4163, ptr %slot695, align 8
  %v4164 = load i32, ptr %slot695, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcslotdrop875, label %bb_rcslotdone875
bb_rcslotdrop875:
  %v4167 = load i64, ptr %slot16, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  store i32 0, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  %v4169 = load i64, ptr %slot26, align 8
  store i64 %v4169, ptr %slot696, align 8
  %v4170 = load i64, ptr %slot17, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %ld4172 = load i32, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4172, ptr %slot697, align 8
  %v4173 = load i32, ptr %slot697, align 8
  %op4174 = and i32 %v4173, 28
  store i32 %op4174, ptr %slot698, align 8
  %v4175 = load i32, ptr %slot698, align 8
  %cv4176 = zext i32 %v4175 to i64
  %cond4177 = icmp ne i64 %cv4176, 0
  br i1 %cond4177, label %bb_rcslotrole875, label %bb_rcslotowner875
bb_rcslotrole875:
  %v4178 = load i64, ptr %slot56, align 8
  store i64 %v4178, ptr %slot699, align 8
  %v4179 = load i64, ptr %slot699, align 8
  %v4180 = load i64, ptr %slot696, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v4179, i64 %v4180) nomerge, !dbg !134
  br label %bb_rcslotdone875
bb_rcslotowner875:
  %v4181 = load i64, ptr %slot56, align 8
  store i64 %v4181, ptr %slot700, align 8
  %v4182 = load i64, ptr %slot700, align 8
  %v4183 = load i64, ptr %slot696, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v4182, i64 %v4183) nomerge, !dbg !134
  br label %bb_rcslotdone875
bb_rcslotdone875:
  %v4184 = load i64, ptr %slot42, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %ld4186 = load i64, ptr %p4185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4186, ptr %slot701, align 8
  %v4187 = load i64, ptr %slot701, align 8
  %op4188 = add i64 %v4187, 24
  store i64 %op4188, ptr %slot702, align 8
  %v4189 = load i64, ptr %slot702, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  %ld4191 = load i64, ptr %p4190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4191, ptr %slot703, align 8
  %v4192 = load i64, ptr %slot703, align 8
  %v4193 = load i64, ptr %slot42, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  store i64 %v4192, ptr %p4194, align 8, !alias.scope !3, !noalias !4
  %v4195 = load i64, ptr %slot42, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  %ld4197 = load i64, ptr %p4196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4197, ptr %slot704, align 8
  %v4198 = load i64, ptr %slot704, align 8
  %v4199 = load i64, ptr %slot29, align 8
  %p4200 = inttoptr i64 %v4199 to ptr
  store i64 %v4198, ptr %p4200, align 8, !alias.scope !3, !noalias !4
  %v4201 = load i64, ptr %slot29, align 8
  store i64 %v4201, ptr %slot705, align 8
  %v4202 = load i64, ptr %slot31, align 8
  store i64 %v4202, ptr %slot706, align 8
  %v4203 = load i64, ptr %slot705, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  %ld4205 = load i64, ptr %p4204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4205, ptr %slot707, align 8
  %v4206 = load i64, ptr %slot707, align 8
  %cmp4207 = icmp ne i64 %v4206, 0
  %cv4208 = zext i1 %cmp4207 to i32
  store i32 %cv4208, ptr %slot708, align 8
  %v4209 = load i32, ptr %slot708, align 8
  %cv4210 = zext i32 %v4209 to i64
  %cond4211 = icmp ne i64 %cv4210, 0
  br i1 %cond4211, label %bb_rcgnn889, label %bb_rcgstore889
bb_rcgnn889:
  %v4212 = load i64, ptr %slot707, align 8
  %op4213 = sub i64 %v4212, 16
  store i64 %op4213, ptr %slot709, align 8
  %v4214 = load i64, ptr %slot707, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  %rgep4216 = getelementptr i8, ptr %p4215, i64 -16
  %ld4217 = load i64, ptr %rgep4216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4217, ptr %slot710, align 8
  %v4218 = load i64, ptr %slot710, align 8
  %op4219 = and i64 %v4218, 4611686018427387906
  store i64 %op4219, ptr %slot711, align 8
  %v4220 = load i64, ptr %slot711, align 8
  %cmp4221 = icmp ne i64 %v4220, 0
  %cv4222 = zext i1 %cmp4221 to i32
  store i32 %cv4222, ptr %slot712, align 8
  %v4223 = load i32, ptr %slot712, align 8
  %cv4224 = zext i32 %v4223 to i64
  %cond4225 = icmp ne i64 %cv4224, 0
  br i1 %cond4225, label %bb_rcgstore889, label %bb_rcginc889
bb_rcginc889:
  %v4226 = load i64, ptr %slot707, align 8
  %op4227 = sub i64 %v4226, 24
  store i64 %op4227, ptr %slot713, align 8
  %v4228 = load i64, ptr %slot707, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  %rgep4230 = getelementptr i8, ptr %p4229, i64 -24
  %ld4231 = load i64, ptr %rgep4230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4231, ptr %slot714, align 8
  %v4232 = load i64, ptr %slot714, align 8
  %op4233 = add i64 %v4232, 1
  store i64 %op4233, ptr %slot715, align 8
  %v4234 = load i64, ptr %slot715, align 8
  %cmp4235 = icmp eq i64 %v4234, 0
  %cv4236 = zext i1 %cmp4235 to i32
  store i32 %cv4236, ptr %slot716, align 8
  %v4237 = load i32, ptr %slot716, align 8
  %cv4238 = zext i32 %v4237 to i64
  %cond4239 = icmp ne i64 %cv4238, 0
  br i1 %cond4239, label %bb_rcglimit889, label %bb_rcgcapacity889
bb_rcglimit889:
  %v4240 = load i64, ptr %slot1, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  %call4242 = call i32 @myl_qbe_rc_status(ptr %p4241, i32 2) nomerge, !dbg !136
  store i32 %call4242, ptr %slot717, align 8
  br label %bb_failure
bb_rcgcapacity889:
  %v4243 = load i64, ptr %slot715, align 8
  %v4244 = load i64, ptr %slot707, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %rgep4246 = getelementptr i8, ptr %p4245, i64 -24
  store i64 %v4243, ptr %rgep4246, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore889
bb_rcgstore889:
  %v4247 = load i64, ptr %slot707, align 8
  %v4248 = load i64, ptr %slot706, align 8
  %p4249 = inttoptr i64 %v4248 to ptr
  store i64 %v4247, ptr %p4249, align 8, !alias.scope !3, !noalias !4
  %v4250 = load i64, ptr %slot23, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  store i32 2, ptr %p4251, align 4, !alias.scope !3, !noalias !4
  %v4252 = load i64, ptr %slot23, align 8
  %p4253 = inttoptr i64 %v4252 to ptr
  store i32 16, ptr %p4253, align 4, !alias.scope !3, !noalias !4
  %v4254 = load i64, ptr %slot22, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  store i32 1, ptr %p4255, align 4, !alias.scope !3, !noalias !4
  %v4256 = load i64, ptr %slot16, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  %ld4258 = load i32, ptr %p4257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4258, ptr %slot718, align 8
  %v4259 = load i32, ptr %slot718, align 8
  %cv4260 = zext i32 %v4259 to i64
  %cond4261 = icmp ne i64 %cv4260, 0
  br i1 %cond4261, label %bb_rcslotdrop905, label %bb_rcslotdone905
bb_rcslotdrop905:
  %v4262 = load i64, ptr %slot16, align 8
  %p4263 = inttoptr i64 %v4262 to ptr
  store i32 0, ptr %p4263, align 4, !alias.scope !3, !noalias !4
  %v4264 = load i64, ptr %slot26, align 8
  store i64 %v4264, ptr %slot719, align 8
  %v4265 = load i64, ptr %slot17, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  %ld4267 = load i32, ptr %p4266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4267, ptr %slot720, align 8
  %v4268 = load i32, ptr %slot720, align 8
  %op4269 = and i32 %v4268, 28
  store i32 %op4269, ptr %slot721, align 8
  %v4270 = load i32, ptr %slot721, align 8
  %cv4271 = zext i32 %v4270 to i64
  %cond4272 = icmp ne i64 %cv4271, 0
  br i1 %cond4272, label %bb_rcslotrole905, label %bb_rcslotowner905
bb_rcslotrole905:
  %v4273 = load i64, ptr %slot56, align 8
  store i64 %v4273, ptr %slot722, align 8
  %v4274 = load i64, ptr %slot722, align 8
  %v4275 = load i64, ptr %slot719, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v4274, i64 %v4275) nomerge, !dbg !136
  br label %bb_rcslotdone905
bb_rcslotowner905:
  %v4276 = load i64, ptr %slot56, align 8
  store i64 %v4276, ptr %slot723, align 8
  %v4277 = load i64, ptr %slot723, align 8
  %v4278 = load i64, ptr %slot719, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v4277, i64 %v4278) nomerge, !dbg !136
  br label %bb_rcslotdone905
bb_rcslotdone905:
  %v4279 = load i64, ptr %slot26, align 8
  store i64 %v4279, ptr %slot724, align 8
  %v4280 = load i64, ptr %slot31, align 8
  store i64 %v4280, ptr %slot725, align 8
  %v4281 = load i64, ptr %slot725, align 8
  %v4282 = load i64, ptr %slot724, align 8
  %p4283 = inttoptr i64 %v4281 to ptr
  %p4284 = inttoptr i64 %v4282 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4284, ptr %p4283, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4285 = load i64, ptr %slot17, align 8
  %p4286 = inttoptr i64 %v4285 to ptr
  store i32 2, ptr %p4286, align 4, !alias.scope !3, !noalias !4
  %v4287 = load i64, ptr %slot23, align 8
  %p4288 = inttoptr i64 %v4287 to ptr
  %ld4289 = load i32, ptr %p4288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4289, ptr %slot726, align 8
  %v4290 = load i32, ptr %slot726, align 8
  %v4291 = load i64, ptr %slot17, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i32 %v4290, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot22, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 0, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot16, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  store i32 1, ptr %p4296, align 4, !alias.scope !3, !noalias !4
  %v4297 = load i64, ptr %slot724, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  %ld4299 = load i64, ptr %p4298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4299, ptr %slot727, align 8
  %v4300 = load i64, ptr %slot727, align 8
  %v4301 = load i64, ptr %slot42, align 8
  %p4302 = inttoptr i64 %v4301 to ptr
  store i64 %v4300, ptr %p4302, align 8, !alias.scope !3, !noalias !4
  %v4303 = load i64, ptr %slot42, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  %ld4305 = load i64, ptr %p4304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4305, ptr %slot728, align 8
  %v4306 = load i64, ptr %slot728, align 8
  %v4307 = load i64, ptr %slot29, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  store i64 %v4306, ptr %p4308, align 8, !alias.scope !3, !noalias !4
  %v4309 = load i64, ptr %slot29, align 8
  store i64 %v4309, ptr %slot729, align 8
  %v4310 = load i64, ptr %slot16, align 8
  %p4311 = inttoptr i64 %v4310 to ptr
  %ld4312 = load i32, ptr %p4311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4312, ptr %slot730, align 8
  %v4313 = load i64, ptr %slot17, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  %ld4315 = load i32, ptr %p4314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4315, ptr %slot731, align 8
  %v4316 = load i32, ptr %slot731, align 8
  %op4317 = and i32 %v4316, 24
  store i32 %op4317, ptr %slot731, align 8
  %v4318 = load i32, ptr %slot731, align 8
  %cmp4319 = icmp eq i32 %v4318, 0
  %cv4320 = zext i1 %cmp4319 to i32
  store i32 %cv4320, ptr %slot732, align 8
  %v4321 = load i32, ptr %slot730, align 8
  %v4322 = load i32, ptr %slot732, align 8
  %op4323 = and i32 %v4321, %v4322
  store i32 %op4323, ptr %slot733, align 8
  %v4324 = load i32, ptr %slot733, align 8
  %cv4325 = zext i32 %v4324 to i64
  %cond4326 = icmp ne i64 %cv4325, 0
  br i1 %cond4326, label %bb_rcprivateown929, label %bb_rcprivateloan929
bb_rcprivateown929:
  %v4327 = load i64, ptr %slot31, align 8
  store i64 %v4327, ptr %slot734, align 8
  %v4328 = load i64, ptr %slot57, align 8
  store i64 %v4328, ptr %slot735, align 8
  %v4329 = load i64, ptr %slot729, align 8
  %v4330 = load i64, ptr %slot734, align 8
  %op4331 = sub i64 %v4329, %v4330
  store i64 %op4331, ptr %slot736, align 8
  %v4332 = load i64, ptr %slot734, align 8
  %v4333 = load i64, ptr %slot729, align 8
  %op4334 = sub i64 %v4332, %v4333
  store i64 %op4334, ptr %slot737, align 8
  %v4335 = load i64, ptr %slot736, align 8
  %cmp4336 = icmp ult i64 %v4335, 8
  %cv4337 = zext i1 %cmp4336 to i32
  store i32 %cv4337, ptr %slot738, align 8
  %v4338 = load i64, ptr %slot737, align 8
  %cmp4339 = icmp ult i64 %v4338, 8
  %cv4340 = zext i1 %cmp4339 to i32
  store i32 %cv4340, ptr %slot739, align 8
  %v4341 = load i32, ptr %slot738, align 8
  %v4342 = load i32, ptr %slot739, align 8
  %op4343 = or i32 %v4341, %v4342
  store i32 %op4343, ptr %slot740, align 8
  %v4344 = load i32, ptr %slot740, align 8
  %cv4345 = zext i32 %v4344 to i64
  %cond4346 = icmp ne i64 %cv4345, 0
  br i1 %cond4346, label %bb_rcmoveslow932, label %bb_rcmovecheck932
bb_rcmovecheck932:
  %v4347 = load i64, ptr %slot729, align 8
  %p4349 = inttoptr i64 %v4347 to ptr
  %gep4350 = getelementptr i8, ptr %p4349, i64 0
  %op4348 = ptrtoint ptr %gep4350 to i64
  store i64 %op4348, ptr %slot741, align 8
  %v4351 = load i64, ptr %slot741, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %ld4353 = load i64, ptr %p4352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4353, ptr %slot742, align 8
  %v4354 = load i64, ptr %slot742, align 8
  %cmp4355 = icmp ne i64 %v4354, 0
  %cv4356 = zext i1 %cmp4355 to i32
  store i32 %cv4356, ptr %slot743, align 8
  %v4357 = load i32, ptr %slot743, align 8
  %cv4358 = zext i32 %v4357 to i64
  %cond4359 = icmp ne i64 %cv4358, 0
  br i1 %cond4359, label %bb_rcmoveheader940, label %bb_rcmovenext940
bb_rcmoveheader940:
  %v4360 = load i64, ptr %slot742, align 8
  %op4361 = sub i64 %v4360, 16
  store i64 %op4361, ptr %slot744, align 8
  %v4362 = load i64, ptr %slot742, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %rgep4364 = getelementptr i8, ptr %p4363, i64 -16
  %ld4365 = load i64, ptr %rgep4364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4365, ptr %slot745, align 8
  %v4366 = load i64, ptr %slot745, align 8
  %op4367 = and i64 %v4366, 5764607523034234881
  store i64 %op4367, ptr %slot746, align 8
  %v4368 = load i64, ptr %slot746, align 8
  %cmp4369 = icmp ne i64 %v4368, 0
  %cv4370 = zext i1 %cmp4369 to i32
  store i32 %cv4370, ptr %slot747, align 8
  %v4371 = load i32, ptr %slot747, align 8
  %cv4372 = zext i32 %v4371 to i64
  %cond4373 = icmp ne i64 %cv4372, 0
  br i1 %cond4373, label %bb_rcmoveslow932, label %bb_rcmovenext940
bb_rcmovenext940:
  %v4374 = load i64, ptr %slot729, align 8
  %v4375 = load i64, ptr %slot734, align 8
  %p4376 = inttoptr i64 %v4374 to ptr
  %p4377 = inttoptr i64 %v4375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4377, ptr %p4376, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4378 = load i64, ptr %slot729, align 8
  %p4379 = inttoptr i64 %v4378 to ptr
  store i64 0, ptr %p4379, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved932
bb_rcmoveslow932:
  %v4380 = load i64, ptr %slot56, align 8
  %v4381 = load i64, ptr %slot734, align 8
  %v4382 = load i64, ptr %slot729, align 8
  %v4383 = load i64, ptr %slot735, align 8
  %cv4384 = trunc i64 %v4383 to i32
  %call4385 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v4380, i64 %v4381, i64 %v4382, i32 %cv4384) nomerge, !dbg !138
  store i32 %call4385, ptr %slot748, align 8
  %v4386 = load i32, ptr %slot748, align 8
  %cv4387 = zext i32 %v4386 to i64
  %cond4388 = icmp ne i64 %cv4387, 0
  br i1 %cond4388, label %bb_rcsuccess947, label %bb_rcfailure947
bb_rcfailure947:
  %v4389 = load i64, ptr %slot56, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  %call4391 = call i32 @myl_rc_take_failure(ptr %p4390) nomerge, !dbg !138
  store i32 %call4391, ptr %slot749, align 8
  %v4392 = load i64, ptr %slot1, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %v4394 = load i32, ptr %slot749, align 8
  %call4395 = call i32 @myl_qbe_rc_status(ptr %p4393, i32 %v4394) nomerge, !dbg !138
  store i32 %call4395, ptr %slot750, align 8
  br label %bb_failure
bb_rcsuccess947:
  br label %bb_rcmoved932
bb_rcmoved932:
  %v4396 = load i64, ptr %slot16, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  store i32 0, ptr %p4397, align 4, !alias.scope !3, !noalias !4
  %v4398 = load i64, ptr %slot23, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  store i32 2, ptr %p4399, align 4, !alias.scope !3, !noalias !4
  %v4400 = load i64, ptr %slot22, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  store i32 1, ptr %p4401, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared929
bb_rcprivateloan929:
  %v4402 = load i64, ptr %slot16, align 8
  %p4403 = inttoptr i64 %v4402 to ptr
  %ld4404 = load i32, ptr %p4403, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4404, ptr %slot751, align 8
  %v4405 = load i64, ptr %slot17, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  %ld4407 = load i32, ptr %p4406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4407, ptr %slot752, align 8
  %v4408 = load i32, ptr %slot752, align 8
  %cmp4409 = icmp eq i32 %v4408, 16
  %cv4410 = zext i1 %cmp4409 to i32
  store i32 %cv4410, ptr %slot753, align 8
  %v4411 = load i32, ptr %slot753, align 8
  %v4412 = load i32, ptr %slot751, align 8
  %op4413 = and i32 %v4411, %v4412
  store i32 %op4413, ptr %slot753, align 8
  %v4414 = load i32, ptr %slot753, align 8
  %cv4415 = zext i32 %v4414 to i64
  %cond4416 = icmp ne i64 %cv4415, 0
  br i1 %cond4416, label %bb_rcprivatemove929, label %bb_rcprivatenew929
bb_rcprivatemove929:
  %v4417 = load i64, ptr %slot31, align 8
  store i64 %v4417, ptr %slot754, align 8
  %v4418 = load i64, ptr %slot729, align 8
  %v4419 = load i64, ptr %slot754, align 8
  %p4420 = inttoptr i64 %v4418 to ptr
  %p4421 = inttoptr i64 %v4419 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4421, ptr %p4420, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4422 = load i64, ptr %slot729, align 8
  %p4423 = inttoptr i64 %v4422 to ptr
  store i64 0, ptr %p4423, align 8, !alias.scope !3, !noalias !4
  %v4424 = load i64, ptr %slot23, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  store i32 2, ptr %p4425, align 4, !alias.scope !3, !noalias !4
  %v4426 = load i64, ptr %slot23, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  store i32 16, ptr %p4427, align 4, !alias.scope !3, !noalias !4
  %v4428 = load i64, ptr %slot22, align 8
  %p4429 = inttoptr i64 %v4428 to ptr
  store i32 1, ptr %p4429, align 4, !alias.scope !3, !noalias !4
  %v4430 = load i64, ptr %slot16, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  store i32 0, ptr %p4431, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared929
bb_rcprivatenew929:
  %v4432 = load i64, ptr %slot31, align 8
  store i64 %v4432, ptr %slot755, align 8
  %v4433 = load i64, ptr %slot729, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4435, ptr %slot756, align 8
  %v4436 = load i64, ptr %slot756, align 8
  %cmp4437 = icmp ne i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot757, align 8
  %v4439 = load i32, ptr %slot757, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcgnn965, label %bb_rcgstore965
bb_rcgnn965:
  %v4442 = load i64, ptr %slot756, align 8
  %op4443 = sub i64 %v4442, 16
  store i64 %op4443, ptr %slot758, align 8
  %v4444 = load i64, ptr %slot756, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %rgep4446 = getelementptr i8, ptr %p4445, i64 -16
  %ld4447 = load i64, ptr %rgep4446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4447, ptr %slot759, align 8
  %v4448 = load i64, ptr %slot759, align 8
  %op4449 = and i64 %v4448, 4611686018427387906
  store i64 %op4449, ptr %slot760, align 8
  %v4450 = load i64, ptr %slot760, align 8
  %cmp4451 = icmp ne i64 %v4450, 0
  %cv4452 = zext i1 %cmp4451 to i32
  store i32 %cv4452, ptr %slot761, align 8
  %v4453 = load i32, ptr %slot761, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcgstore965, label %bb_rcginc965
bb_rcginc965:
  %v4456 = load i64, ptr %slot756, align 8
  %op4457 = sub i64 %v4456, 24
  store i64 %op4457, ptr %slot762, align 8
  %v4458 = load i64, ptr %slot756, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %rgep4460 = getelementptr i8, ptr %p4459, i64 -24
  %ld4461 = load i64, ptr %rgep4460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4461, ptr %slot763, align 8
  %v4462 = load i64, ptr %slot763, align 8
  %op4463 = add i64 %v4462, 1
  store i64 %op4463, ptr %slot764, align 8
  %v4464 = load i64, ptr %slot764, align 8
  %cmp4465 = icmp eq i64 %v4464, 0
  %cv4466 = zext i1 %cmp4465 to i32
  store i32 %cv4466, ptr %slot765, align 8
  %v4467 = load i32, ptr %slot765, align 8
  %cv4468 = zext i32 %v4467 to i64
  %cond4469 = icmp ne i64 %cv4468, 0
  br i1 %cond4469, label %bb_rcglimit965, label %bb_rcgcapacity965
bb_rcglimit965:
  %v4470 = load i64, ptr %slot1, align 8
  %p4471 = inttoptr i64 %v4470 to ptr
  %call4472 = call i32 @myl_qbe_rc_status(ptr %p4471, i32 2) nomerge, !dbg !138
  store i32 %call4472, ptr %slot766, align 8
  br label %bb_failure
bb_rcgcapacity965:
  %v4473 = load i64, ptr %slot764, align 8
  %v4474 = load i64, ptr %slot756, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  %rgep4476 = getelementptr i8, ptr %p4475, i64 -24
  store i64 %v4473, ptr %rgep4476, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore965
bb_rcgstore965:
  %v4477 = load i64, ptr %slot756, align 8
  %v4478 = load i64, ptr %slot755, align 8
  %p4479 = inttoptr i64 %v4478 to ptr
  store i64 %v4477, ptr %p4479, align 8, !alias.scope !3, !noalias !4
  %v4480 = load i64, ptr %slot23, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  store i32 2, ptr %p4481, align 4, !alias.scope !3, !noalias !4
  %v4482 = load i64, ptr %slot23, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  store i32 16, ptr %p4483, align 4, !alias.scope !3, !noalias !4
  %v4484 = load i64, ptr %slot22, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  store i32 1, ptr %p4485, align 4, !alias.scope !3, !noalias !4
  %v4486 = load i64, ptr %slot16, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %ld4488 = load i32, ptr %p4487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4488, ptr %slot767, align 8
  %v4489 = load i32, ptr %slot767, align 8
  %cv4490 = zext i32 %v4489 to i64
  %cond4491 = icmp ne i64 %cv4490, 0
  br i1 %cond4491, label %bb_rcslotdrop981, label %bb_rcslotdone981
bb_rcslotdrop981:
  %v4492 = load i64, ptr %slot16, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  store i32 0, ptr %p4493, align 4, !alias.scope !3, !noalias !4
  %v4494 = load i64, ptr %slot26, align 8
  store i64 %v4494, ptr %slot768, align 8
  %v4495 = load i64, ptr %slot17, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  %ld4497 = load i32, ptr %p4496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4497, ptr %slot769, align 8
  %v4498 = load i32, ptr %slot769, align 8
  %op4499 = and i32 %v4498, 28
  store i32 %op4499, ptr %slot770, align 8
  %v4500 = load i32, ptr %slot770, align 8
  %cv4501 = zext i32 %v4500 to i64
  %cond4502 = icmp ne i64 %cv4501, 0
  br i1 %cond4502, label %bb_rcslotrole981, label %bb_rcslotowner981
bb_rcslotrole981:
  %v4503 = load i64, ptr %slot56, align 8
  store i64 %v4503, ptr %slot771, align 8
  %v4504 = load i64, ptr %slot768, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  %ld4506 = load i64, ptr %p4505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4506, ptr %slot772, align 8
  %v4507 = load i64, ptr %slot772, align 8
  %cmp4508 = icmp ne i64 %v4507, 0
  %cv4509 = zext i1 %cmp4508 to i32
  store i32 %cv4509, ptr %slot773, align 8
  %v4510 = load i32, ptr %slot773, align 8
  %cv4511 = zext i32 %v4510 to i64
  %cond4512 = icmp ne i64 %cv4511, 0
  br i1 %cond4512, label %bb_rcgnn997, label %bb_rcgdone997
bb_rcgnn997:
  %v4513 = load i64, ptr %slot772, align 8
  %op4514 = sub i64 %v4513, 16
  store i64 %op4514, ptr %slot774, align 8
  %v4515 = load i64, ptr %slot772, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  %rgep4517 = getelementptr i8, ptr %p4516, i64 -16
  %ld4518 = load i64, ptr %rgep4517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4518, ptr %slot775, align 8
  %v4519 = load i64, ptr %slot775, align 8
  %op4520 = and i64 %v4519, 4611686018427387906
  store i64 %op4520, ptr %slot776, align 8
  %v4521 = load i64, ptr %slot776, align 8
  %cmp4522 = icmp ne i64 %v4521, 0
  %cv4523 = zext i1 %cmp4522 to i32
  store i32 %cv4523, ptr %slot777, align 8
  %v4524 = load i32, ptr %slot777, align 8
  %cv4525 = zext i32 %v4524 to i64
  %cond4526 = icmp ne i64 %cv4525, 0
  br i1 %cond4526, label %bb_rcgclear997, label %bb_rcgcounted997
bb_rcgcounted997:
  %v4527 = load i64, ptr %slot772, align 8
  %op4528 = sub i64 %v4527, 24
  store i64 %op4528, ptr %slot778, align 8
  %v4529 = load i64, ptr %slot772, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  %rgep4531 = getelementptr i8, ptr %p4530, i64 -24
  %ld4532 = load i64, ptr %rgep4531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4532, ptr %slot779, align 8
  %v4533 = load i64, ptr %slot779, align 8
  %op4534 = sub i64 %v4533, 1
  store i64 %op4534, ptr %slot780, align 8
  %v4535 = load i64, ptr %slot780, align 8
  %cmp4536 = icmp eq i64 %v4535, 0
  %cv4537 = zext i1 %cmp4536 to i32
  store i32 %cv4537, ptr %slot781, align 8
  %v4538 = load i32, ptr %slot781, align 8
  %cv4539 = zext i32 %v4538 to i64
  %cond4540 = icmp ne i64 %cv4539, 0
  br i1 %cond4540, label %bb_rcglast997, label %bb_rcgdec997
bb_rcglast997:
  %v4541 = load i64, ptr %slot772, align 8
  %op4542 = sub i64 %v4541, 32
  store i64 %op4542, ptr %slot782, align 8
  %v4543 = load i64, ptr %slot772, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %rgep4545 = getelementptr i8, ptr %p4544, i64 -32
  %ld4546 = load i64, ptr %rgep4545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4546, ptr %slot783, align 8
  %v4547 = load i64, ptr %slot783, align 8
  %cmp4548 = icmp ne i64 %v4547, 0
  %cv4549 = zext i1 %cmp4548 to i32
  store i32 %cv4549, ptr %slot784, align 8
  %v4550 = load i32, ptr %slot784, align 8
  %cv4551 = zext i32 %v4550 to i64
  %cond4552 = icmp ne i64 %cv4551, 0
  br i1 %cond4552, label %bb_rcgdec997, label %bb_rcgslow997
bb_rcgslow997:
  %v4553 = load i64, ptr %slot771, align 8
  %v4554 = load i64, ptr %slot768, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4553, i64 %v4554) nomerge, !dbg !138
  br label %bb_rcgdone997
bb_rcgdec997:
  %v4555 = load i64, ptr %slot780, align 8
  %v4556 = load i64, ptr %slot772, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  %rgep4558 = getelementptr i8, ptr %p4557, i64 -24
  store i64 %v4555, ptr %rgep4558, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear997
bb_rcgclear997:
  %v4559 = load i64, ptr %slot768, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  store i64 0, ptr %p4560, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone997
bb_rcgdone997:
  br label %bb_rcslotdone981
bb_rcslotowner981:
  %v4561 = load i64, ptr %slot56, align 8
  store i64 %v4561, ptr %slot785, align 8
  %v4562 = load i64, ptr %slot768, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  %ld4564 = load i64, ptr %p4563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4564, ptr %slot786, align 8
  %v4565 = load i64, ptr %slot786, align 8
  %cmp4566 = icmp ne i64 %v4565, 0
  %cv4567 = zext i1 %cmp4566 to i32
  store i32 %cv4567, ptr %slot787, align 8
  %v4568 = load i32, ptr %slot787, align 8
  %cv4569 = zext i32 %v4568 to i64
  %cond4570 = icmp ne i64 %cv4569, 0
  br i1 %cond4570, label %bb_rcgnn1012, label %bb_rcgdone1012
bb_rcgnn1012:
  %v4571 = load i64, ptr %slot786, align 8
  %op4572 = sub i64 %v4571, 16
  store i64 %op4572, ptr %slot788, align 8
  %v4573 = load i64, ptr %slot786, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  %rgep4575 = getelementptr i8, ptr %p4574, i64 -16
  %ld4576 = load i64, ptr %rgep4575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4576, ptr %slot789, align 8
  %v4577 = load i64, ptr %slot789, align 8
  %op4578 = and i64 %v4577, 4611686018427387906
  store i64 %op4578, ptr %slot790, align 8
  %v4579 = load i64, ptr %slot790, align 8
  %cmp4580 = icmp ne i64 %v4579, 0
  %cv4581 = zext i1 %cmp4580 to i32
  store i32 %cv4581, ptr %slot791, align 8
  %v4582 = load i32, ptr %slot791, align 8
  %cv4583 = zext i32 %v4582 to i64
  %cond4584 = icmp ne i64 %cv4583, 0
  br i1 %cond4584, label %bb_rcgclear1012, label %bb_rcgcounted1012
bb_rcgcounted1012:
  %v4585 = load i64, ptr %slot786, align 8
  %op4586 = sub i64 %v4585, 32
  store i64 %op4586, ptr %slot792, align 8
  %v4587 = load i64, ptr %slot786, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  %rgep4589 = getelementptr i8, ptr %p4588, i64 -32
  %ld4590 = load i64, ptr %rgep4589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4590, ptr %slot793, align 8
  %v4591 = load i64, ptr %slot793, align 8
  %op4592 = sub i64 %v4591, 1
  store i64 %op4592, ptr %slot794, align 8
  %v4593 = load i64, ptr %slot794, align 8
  %cmp4594 = icmp eq i64 %v4593, 0
  %cv4595 = zext i1 %cmp4594 to i32
  store i32 %cv4595, ptr %slot795, align 8
  %v4596 = load i32, ptr %slot795, align 8
  %cv4597 = zext i32 %v4596 to i64
  %cond4598 = icmp ne i64 %cv4597, 0
  br i1 %cond4598, label %bb_rcglast1012, label %bb_rcgdec1012
bb_rcglast1012:
  %v4599 = load i64, ptr %slot786, align 8
  %op4600 = sub i64 %v4599, 24
  store i64 %op4600, ptr %slot796, align 8
  %v4601 = load i64, ptr %slot786, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  %rgep4603 = getelementptr i8, ptr %p4602, i64 -24
  %ld4604 = load i64, ptr %rgep4603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4604, ptr %slot797, align 8
  %v4605 = load i64, ptr %slot797, align 8
  %cmp4606 = icmp ne i64 %v4605, 0
  %cv4607 = zext i1 %cmp4606 to i32
  store i32 %cv4607, ptr %slot798, align 8
  %v4608 = load i32, ptr %slot798, align 8
  %cv4609 = zext i32 %v4608 to i64
  %cond4610 = icmp ne i64 %cv4609, 0
  br i1 %cond4610, label %bb_rcgdec1012, label %bb_rcgslow1012
bb_rcgslow1012:
  %v4611 = load i64, ptr %slot785, align 8
  %v4612 = load i64, ptr %slot768, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4611, i64 %v4612) nomerge, !dbg !138
  br label %bb_rcgdone1012
bb_rcgdec1012:
  %v4613 = load i64, ptr %slot794, align 8
  %v4614 = load i64, ptr %slot786, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  %rgep4616 = getelementptr i8, ptr %p4615, i64 -32
  store i64 %v4613, ptr %rgep4616, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1012
bb_rcgclear1012:
  %v4617 = load i64, ptr %slot768, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  store i64 0, ptr %p4618, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1012
bb_rcgdone1012:
  br label %bb_rcslotdone981
bb_rcslotdone981:
  br label %bb_rcprivateprepared929
bb_rcprivateprepared929:
  %v4619 = load i64, ptr %slot12, align 8
  %p4620 = inttoptr i64 %v4619 to ptr
  %ld4621 = load i32, ptr %p4620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4621, ptr %slot799, align 8
  %v4622 = load i32, ptr %slot799, align 8
  %cv4623 = zext i32 %v4622 to i64
  %cond4624 = icmp ne i64 %cv4623, 0
  br i1 %cond4624, label %bb_rcslotdrop1019, label %bb_rcslotdone1019
bb_rcslotdrop1019:
  %v4625 = load i64, ptr %slot12, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  store i32 0, ptr %p4626, align 4, !alias.scope !3, !noalias !4
  %v4627 = load i64, ptr %slot39, align 8
  store i64 %v4627, ptr %slot800, align 8
  %v4628 = load i64, ptr %slot13, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  %ld4630 = load i32, ptr %p4629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4630, ptr %slot801, align 8
  %v4631 = load i32, ptr %slot801, align 8
  %op4632 = and i32 %v4631, 28
  store i32 %op4632, ptr %slot802, align 8
  %v4633 = load i32, ptr %slot802, align 8
  %cv4634 = zext i32 %v4633 to i64
  %cond4635 = icmp ne i64 %cv4634, 0
  br i1 %cond4635, label %bb_rcslotrole1019, label %bb_rcslotowner1019
bb_rcslotrole1019:
  %v4636 = load i64, ptr %slot56, align 8
  store i64 %v4636, ptr %slot803, align 8
  %v4637 = load i64, ptr %slot800, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  %ld4639 = load i64, ptr %p4638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4639, ptr %slot804, align 8
  %v4640 = load i64, ptr %slot804, align 8
  %cmp4641 = icmp ne i64 %v4640, 0
  %cv4642 = zext i1 %cmp4641 to i32
  store i32 %cv4642, ptr %slot805, align 8
  %v4643 = load i32, ptr %slot805, align 8
  %cv4644 = zext i32 %v4643 to i64
  %cond4645 = icmp ne i64 %cv4644, 0
  br i1 %cond4645, label %bb_rcgnn1035, label %bb_rcgdone1035
bb_rcgnn1035:
  %v4646 = load i64, ptr %slot804, align 8
  %op4647 = sub i64 %v4646, 16
  store i64 %op4647, ptr %slot806, align 8
  %v4648 = load i64, ptr %slot804, align 8
  %p4649 = inttoptr i64 %v4648 to ptr
  %rgep4650 = getelementptr i8, ptr %p4649, i64 -16
  %ld4651 = load i64, ptr %rgep4650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4651, ptr %slot807, align 8
  %v4652 = load i64, ptr %slot807, align 8
  %op4653 = and i64 %v4652, 4611686018427387906
  store i64 %op4653, ptr %slot808, align 8
  %v4654 = load i64, ptr %slot808, align 8
  %cmp4655 = icmp ne i64 %v4654, 0
  %cv4656 = zext i1 %cmp4655 to i32
  store i32 %cv4656, ptr %slot809, align 8
  %v4657 = load i32, ptr %slot809, align 8
  %cv4658 = zext i32 %v4657 to i64
  %cond4659 = icmp ne i64 %cv4658, 0
  br i1 %cond4659, label %bb_rcgclear1035, label %bb_rcgcounted1035
bb_rcgcounted1035:
  %v4660 = load i64, ptr %slot804, align 8
  %op4661 = sub i64 %v4660, 24
  store i64 %op4661, ptr %slot810, align 8
  %v4662 = load i64, ptr %slot804, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  %rgep4664 = getelementptr i8, ptr %p4663, i64 -24
  %ld4665 = load i64, ptr %rgep4664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4665, ptr %slot811, align 8
  %v4666 = load i64, ptr %slot811, align 8
  %op4667 = sub i64 %v4666, 1
  store i64 %op4667, ptr %slot812, align 8
  %v4668 = load i64, ptr %slot812, align 8
  %cmp4669 = icmp eq i64 %v4668, 0
  %cv4670 = zext i1 %cmp4669 to i32
  store i32 %cv4670, ptr %slot813, align 8
  %v4671 = load i32, ptr %slot813, align 8
  %cv4672 = zext i32 %v4671 to i64
  %cond4673 = icmp ne i64 %cv4672, 0
  br i1 %cond4673, label %bb_rcglast1035, label %bb_rcgdec1035
bb_rcglast1035:
  %v4674 = load i64, ptr %slot804, align 8
  %op4675 = sub i64 %v4674, 32
  store i64 %op4675, ptr %slot814, align 8
  %v4676 = load i64, ptr %slot804, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  %rgep4678 = getelementptr i8, ptr %p4677, i64 -32
  %ld4679 = load i64, ptr %rgep4678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4679, ptr %slot815, align 8
  %v4680 = load i64, ptr %slot815, align 8
  %cmp4681 = icmp ne i64 %v4680, 0
  %cv4682 = zext i1 %cmp4681 to i32
  store i32 %cv4682, ptr %slot816, align 8
  %v4683 = load i32, ptr %slot816, align 8
  %cv4684 = zext i32 %v4683 to i64
  %cond4685 = icmp ne i64 %cv4684, 0
  br i1 %cond4685, label %bb_rcgdec1035, label %bb_rcgslow1035
bb_rcgslow1035:
  %v4686 = load i64, ptr %slot803, align 8
  %v4687 = load i64, ptr %slot800, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4686, i64 %v4687) nomerge, !dbg !138
  br label %bb_rcgdone1035
bb_rcgdec1035:
  %v4688 = load i64, ptr %slot812, align 8
  %v4689 = load i64, ptr %slot804, align 8
  %p4690 = inttoptr i64 %v4689 to ptr
  %rgep4691 = getelementptr i8, ptr %p4690, i64 -24
  store i64 %v4688, ptr %rgep4691, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1035
bb_rcgclear1035:
  %v4692 = load i64, ptr %slot800, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  store i64 0, ptr %p4693, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1035
bb_rcgdone1035:
  br label %bb_rcslotdone1019
bb_rcslotowner1019:
  %v4694 = load i64, ptr %slot56, align 8
  store i64 %v4694, ptr %slot817, align 8
  %v4695 = load i64, ptr %slot800, align 8
  %p4696 = inttoptr i64 %v4695 to ptr
  %ld4697 = load i64, ptr %p4696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4697, ptr %slot818, align 8
  %v4698 = load i64, ptr %slot818, align 8
  %cmp4699 = icmp ne i64 %v4698, 0
  %cv4700 = zext i1 %cmp4699 to i32
  store i32 %cv4700, ptr %slot819, align 8
  %v4701 = load i32, ptr %slot819, align 8
  %cv4702 = zext i32 %v4701 to i64
  %cond4703 = icmp ne i64 %cv4702, 0
  br i1 %cond4703, label %bb_rcgnn1050, label %bb_rcgdone1050
bb_rcgnn1050:
  %v4704 = load i64, ptr %slot818, align 8
  %op4705 = sub i64 %v4704, 16
  store i64 %op4705, ptr %slot820, align 8
  %v4706 = load i64, ptr %slot818, align 8
  %p4707 = inttoptr i64 %v4706 to ptr
  %rgep4708 = getelementptr i8, ptr %p4707, i64 -16
  %ld4709 = load i64, ptr %rgep4708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4709, ptr %slot821, align 8
  %v4710 = load i64, ptr %slot821, align 8
  %op4711 = and i64 %v4710, 4611686018427387906
  store i64 %op4711, ptr %slot822, align 8
  %v4712 = load i64, ptr %slot822, align 8
  %cmp4713 = icmp ne i64 %v4712, 0
  %cv4714 = zext i1 %cmp4713 to i32
  store i32 %cv4714, ptr %slot823, align 8
  %v4715 = load i32, ptr %slot823, align 8
  %cv4716 = zext i32 %v4715 to i64
  %cond4717 = icmp ne i64 %cv4716, 0
  br i1 %cond4717, label %bb_rcgclear1050, label %bb_rcgcounted1050
bb_rcgcounted1050:
  %v4718 = load i64, ptr %slot818, align 8
  %op4719 = sub i64 %v4718, 32
  store i64 %op4719, ptr %slot824, align 8
  %v4720 = load i64, ptr %slot818, align 8
  %p4721 = inttoptr i64 %v4720 to ptr
  %rgep4722 = getelementptr i8, ptr %p4721, i64 -32
  %ld4723 = load i64, ptr %rgep4722, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4723, ptr %slot825, align 8
  %v4724 = load i64, ptr %slot825, align 8
  %op4725 = sub i64 %v4724, 1
  store i64 %op4725, ptr %slot826, align 8
  %v4726 = load i64, ptr %slot826, align 8
  %cmp4727 = icmp eq i64 %v4726, 0
  %cv4728 = zext i1 %cmp4727 to i32
  store i32 %cv4728, ptr %slot827, align 8
  %v4729 = load i32, ptr %slot827, align 8
  %cv4730 = zext i32 %v4729 to i64
  %cond4731 = icmp ne i64 %cv4730, 0
  br i1 %cond4731, label %bb_rcglast1050, label %bb_rcgdec1050
bb_rcglast1050:
  %v4732 = load i64, ptr %slot818, align 8
  %op4733 = sub i64 %v4732, 24
  store i64 %op4733, ptr %slot828, align 8
  %v4734 = load i64, ptr %slot818, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  %rgep4736 = getelementptr i8, ptr %p4735, i64 -24
  %ld4737 = load i64, ptr %rgep4736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4737, ptr %slot829, align 8
  %v4738 = load i64, ptr %slot829, align 8
  %cmp4739 = icmp ne i64 %v4738, 0
  %cv4740 = zext i1 %cmp4739 to i32
  store i32 %cv4740, ptr %slot830, align 8
  %v4741 = load i32, ptr %slot830, align 8
  %cv4742 = zext i32 %v4741 to i64
  %cond4743 = icmp ne i64 %cv4742, 0
  br i1 %cond4743, label %bb_rcgdec1050, label %bb_rcgslow1050
bb_rcgslow1050:
  %v4744 = load i64, ptr %slot817, align 8
  %v4745 = load i64, ptr %slot800, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4744, i64 %v4745) nomerge, !dbg !138
  br label %bb_rcgdone1050
bb_rcgdec1050:
  %v4746 = load i64, ptr %slot826, align 8
  %v4747 = load i64, ptr %slot818, align 8
  %p4748 = inttoptr i64 %v4747 to ptr
  %rgep4749 = getelementptr i8, ptr %p4748, i64 -32
  store i64 %v4746, ptr %rgep4749, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1050
bb_rcgclear1050:
  %v4750 = load i64, ptr %slot800, align 8
  %p4751 = inttoptr i64 %v4750 to ptr
  store i64 0, ptr %p4751, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1050
bb_rcgdone1050:
  br label %bb_rcslotdone1019
bb_rcslotdone1019:
  %v4752 = load i64, ptr %slot39, align 8
  store i64 %v4752, ptr %slot831, align 8
  %v4753 = load i64, ptr %slot31, align 8
  store i64 %v4753, ptr %slot832, align 8
  %v4754 = load i64, ptr %slot832, align 8
  %v4755 = load i64, ptr %slot831, align 8
  %p4756 = inttoptr i64 %v4754 to ptr
  %p4757 = inttoptr i64 %v4755 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4757, ptr %p4756, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4758 = load i64, ptr %slot22, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  store i32 0, ptr %p4759, align 4, !alias.scope !3, !noalias !4
  %v4760 = load i64, ptr %slot13, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  store i32 2, ptr %p4761, align 4, !alias.scope !3, !noalias !4
  %v4762 = load i64, ptr %slot23, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %ld4764 = load i32, ptr %p4763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4764, ptr %slot833, align 8
  %v4765 = load i32, ptr %slot833, align 8
  %v4766 = load i64, ptr %slot13, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  store i32 %v4765, ptr %p4767, align 4, !alias.scope !3, !noalias !4
  %v4768 = load i64, ptr %slot12, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  store i32 1, ptr %p4769, align 4, !alias.scope !3, !noalias !4
  %v4770 = load i64, ptr %slot37, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  %ld4772 = load i64, ptr %p4771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4772, ptr %slot834, align 8
  %v4773 = load i64, ptr %slot834, align 8
  %v4774 = load i64, ptr %slot42, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  store i64 %v4773, ptr %p4775, align 8, !alias.scope !3, !noalias !4
  %v4776 = load i64, ptr %slot42, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %ld4778 = load i64, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4778, ptr %slot835, align 8
  %v4779 = load i64, ptr %slot835, align 8
  %v4780 = load i64, ptr %slot40, align 8
  %p4781 = inttoptr i64 %v4780 to ptr
  store i64 %v4779, ptr %p4781, align 8, !alias.scope !3, !noalias !4
  %v4782 = load i64, ptr %slot40, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  %ld4784 = load i64, ptr %p4783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4784, ptr %slot836, align 8
  %v4785 = load i64, ptr %slot836, align 8
  %v4786 = load i64, ptr %slot42, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i64 %v4785, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot43, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  store i64 0, ptr %p4789, align 8, !alias.scope !3, !noalias !4
  %v4790 = load i64, ptr %slot43, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  %ld4792 = load i64, ptr %p4791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4792, ptr %slot837, align 8
  %v4793 = load i64, ptr %slot42, align 8
  %p4794 = inttoptr i64 %v4793 to ptr
  %ld4795 = load i64, ptr %p4794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4795, ptr %slot838, align 8
  %v4796 = load i64, ptr %slot838, align 8
  %v4797 = load i64, ptr %slot837, align 8
  %cmp4798 = icmp slt i64 %v4796, %v4797
  %cv4799 = zext i1 %cmp4798 to i64
  store i64 %cv4799, ptr %slot839, align 8
  %v4800 = load i64, ptr %slot839, align 8
  %v4801 = load i64, ptr %slot42, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  store i64 %v4800, ptr %p4802, align 8, !alias.scope !3, !noalias !4
  %v4803 = load i64, ptr %slot42, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %ld4805 = load i64, ptr %p4804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4805, ptr %slot840, align 8
  %v4806 = load i64, ptr %slot840, align 8
  %cond4807 = icmp ne i64 %v4806, 0
  br i1 %cond4807, label %bb_next1068, label %bb_i42
bb_next1068:
  %v4808 = load i64, ptr %slot39, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  %ld4810 = load i64, ptr %p4809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4810, ptr %slot841, align 8
  %v4811 = load i64, ptr %slot841, align 8
  %op4812 = add i64 %v4811, 0
  store i64 %op4812, ptr %slot842, align 8
  %v4813 = load i64, ptr %slot842, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  %ld4815 = load i64, ptr %p4814, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4815, ptr %slot843, align 8
  %v4816 = load i64, ptr %slot843, align 8
  %v4817 = load i64, ptr %slot42, align 8
  %p4818 = inttoptr i64 %v4817 to ptr
  store i64 %v4816, ptr %p4818, align 8, !alias.scope !3, !noalias !4
  %v4819 = load i64, ptr %slot42, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  %ld4821 = load i64, ptr %p4820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4821, ptr %slot844, align 8
  %v4822 = load i64, ptr %slot844, align 8
  %cmp4823 = icmp ugt i64 %v4822, 9223372036854775807
  %cv4824 = zext i1 %cmp4823 to i64
  store i64 %cv4824, ptr %slot845, align 8
  %v4825 = load i64, ptr %slot845, align 8
  %cond4826 = icmp ne i64 %v4825, 0
  br i1 %cond4826, label %bb_cast_overflow1073, label %bb_cast_ok1073
bb_cast_overflow1073:
  %v4827 = load i64, ptr %slot1, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  %v4829 = load i64, ptr %slot844, align 8
  call void @myl_qbe_fail_cast(ptr %p4828, i64 %v4829, i64 320) nomerge, !dbg !140
  unreachable
bb_cast_ok1073:
  %v4830 = load i64, ptr %slot844, align 8
  %v4831 = load i64, ptr %slot42, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  store i64 %v4830, ptr %p4832, align 8, !alias.scope !3, !noalias !4
  %v4833 = load i64, ptr %slot40, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  %ld4835 = load i64, ptr %p4834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4835, ptr %slot846, align 8
  %v4836 = load i64, ptr %slot846, align 8
  %v4837 = load i64, ptr %slot43, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  store i64 %v4836, ptr %p4838, align 8, !alias.scope !3, !noalias !4
  %v4839 = load i64, ptr %slot43, align 8
  %p4840 = inttoptr i64 %v4839 to ptr
  %ld4841 = load i64, ptr %p4840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4841, ptr %slot847, align 8
  %v4842 = load i64, ptr %slot42, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  %ld4844 = load i64, ptr %p4843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4844, ptr %slot848, align 8
  %v4845 = load i64, ptr %slot848, align 8
  %v4846 = load i64, ptr %slot847, align 8
  %ovpair4848 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4845, i64 %v4846)
  %op4847 = extractvalue { i64, i1 } %ovpair4848, 0
  %ov4849 = extractvalue { i64, i1 } %ovpair4848, 1
  store i64 %op4847, ptr %slot849, align 8
  %v4850 = load i64, ptr %slot848, align 8
  %v4851 = load i64, ptr %slot849, align 8
  %op4852 = xor i64 %v4850, %v4851
  store i64 %op4852, ptr %slot850, align 8
  %v4853 = load i64, ptr %slot847, align 8
  %v4854 = load i64, ptr %slot849, align 8
  %op4855 = xor i64 %v4853, %v4854
  store i64 %op4855, ptr %slot851, align 8
  %v4856 = load i64, ptr %slot850, align 8
  %v4857 = load i64, ptr %slot851, align 8
  %op4858 = and i64 %v4856, %v4857
  store i64 %op4858, ptr %slot852, align 8
  %cv4859 = zext i1 %ov4849 to i64
  store i64 %cv4859, ptr %slot853, align 8
  %v4860 = load i64, ptr %slot853, align 8
  %cond4861 = icmp ne i64 %v4860, 0
  br i1 %cond4861, label %bb_overflow1077, label %bb_checked1077
bb_overflow1077:
  %v4862 = load i64, ptr %slot1, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  %v4864 = load i64, ptr %slot848, align 8
  %v4865 = load i64, ptr %slot847, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4863, i64 0, i64 %v4864, i64 %v4865, i64 64) nomerge, !dbg !142
  unreachable
bb_checked1077:
  %v4866 = load i64, ptr %slot849, align 8
  %v4867 = load i64, ptr %slot42, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  store i64 %v4866, ptr %p4868, align 8, !alias.scope !3, !noalias !4
  %v4869 = load i64, ptr %slot42, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i64, ptr %p4870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4871, ptr %slot854, align 8
  %v4872 = load i64, ptr %slot854, align 8
  %v4873 = load i64, ptr %slot40, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  store i64 %v4872, ptr %p4874, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  %v4875 = load i64, ptr %slot40, align 8
  %p4876 = inttoptr i64 %v4875 to ptr
  %ld4877 = load i64, ptr %p4876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4877, ptr %slot855, align 8
  %v4878 = load i64, ptr %slot855, align 8
  %v4879 = load i64, ptr %slot42, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  store i64 %v4878, ptr %p4880, align 8, !alias.scope !3, !noalias !4
  %v4881 = load i64, ptr %slot39, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  %ld4883 = load i64, ptr %p4882, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4883, ptr %slot856, align 8
  %v4884 = load i64, ptr %slot42, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %ld4886 = load i64, ptr %p4885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4886, ptr %slot857, align 8
  %v4887 = load i64, ptr %slot856, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %ld4889 = load i64, ptr %p4888, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4889, ptr %slot858, align 8
  %v4890 = load i64, ptr %slot857, align 8
  %v4891 = load i64, ptr %slot858, align 8
  %cmp4892 = icmp ult i64 %v4890, %v4891
  %cv4893 = zext i1 %cmp4892 to i64
  store i64 %cv4893, ptr %slot859, align 8
  %v4894 = load i64, ptr %slot859, align 8
  %cond4895 = icmp ne i64 %v4894, 0
  br i1 %cond4895, label %bb_success1089, label %bb_failed1089
bb_failed1089:
  %v4896 = load i64, ptr %slot1, align 8
  %p4897 = inttoptr i64 %v4896 to ptr
  %v4898 = load i64, ptr %slot857, align 8
  %v4899 = load i64, ptr %slot858, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4897, i64 %v4898, i64 %v4899) nomerge, !dbg !144
  unreachable
bb_success1089:
  %v4900 = load i64, ptr %slot856, align 8
  %op4901 = add i64 %v4900, 32
  store i64 %op4901, ptr %slot860, align 8
  %v4902 = load i64, ptr %slot860, align 8
  %p4903 = inttoptr i64 %v4902 to ptr
  %ld4904 = load i64, ptr %p4903, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4904, ptr %slot861, align 8
  %v4905 = load i64, ptr %slot857, align 8
  %op4906 = mul i64 %v4905, 8
  store i64 %op4906, ptr %slot862, align 8
  %v4907 = load i64, ptr %slot861, align 8
  %v4908 = load i64, ptr %slot862, align 8
  %op4909 = add i64 %v4907, %v4908
  store i64 %op4909, ptr %slot863, align 8
  %v4910 = load i64, ptr %slot861, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %v4912 = load i64, ptr %slot862, align 8
  %egep4913 = getelementptr i8, ptr %p4911, i64 %v4912
  %ld4914 = load i64, ptr %egep4913, align 8, !alias.scope !12, !noalias !13
  store i64 %ld4914, ptr %slot864, align 8
  %v4915 = load i64, ptr %slot864, align 8
  %v4916 = load i64, ptr %slot42, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  store i64 %v4915, ptr %p4917, align 8, !alias.scope !3, !noalias !4
  %v4918 = load i64, ptr %slot41, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  %ld4920 = load i64, ptr %p4919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4920, ptr %slot865, align 8
  %v4921 = load i64, ptr %slot42, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %ld4923 = load i64, ptr %p4922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4923, ptr %slot866, align 8
  %v4924 = load i64, ptr %slot1, align 8
  %v4925 = load i64, ptr %slot865, align 8
  %v4926 = load i64, ptr %slot866, align 8
  %call4927 = call i64 @myl_f_cb8ba6198d12c121b91c6eca86ed4537aaff0ed5acaf8eda6f904a4b0d563a06(i64 %v4924, i64 %v4925, i64 %v4926) nomerge, !dbg !146
  store i64 %call4927, ptr %slot867, align 8
  %v4928 = load i64, ptr %slot867, align 8
  %v4929 = load i64, ptr %slot41, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  store i64 %v4928, ptr %p4930, align 8, !alias.scope !3, !noalias !4
  %v4931 = load i64, ptr %slot14, align 8
  %p4932 = inttoptr i64 %v4931 to ptr
  %ld4933 = load i32, ptr %p4932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4933, ptr %slot868, align 8
  %v4934 = load i32, ptr %slot868, align 8
  %cv4935 = zext i32 %v4934 to i64
  %cond4936 = icmp ne i64 %cv4935, 0
  br i1 %cond4936, label %bb_rcslotdrop1100, label %bb_rcslotdone1100
bb_rcslotdrop1100:
  %v4937 = load i64, ptr %slot14, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  store i32 0, ptr %p4938, align 4, !alias.scope !3, !noalias !4
  %v4939 = load i64, ptr %slot25, align 8
  store i64 %v4939, ptr %slot869, align 8
  %v4940 = load i64, ptr %slot15, align 8
  %p4941 = inttoptr i64 %v4940 to ptr
  %ld4942 = load i32, ptr %p4941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4942, ptr %slot870, align 8
  %v4943 = load i32, ptr %slot870, align 8
  %op4944 = and i32 %v4943, 28
  store i32 %op4944, ptr %slot871, align 8
  %v4945 = load i32, ptr %slot871, align 8
  %cv4946 = zext i32 %v4945 to i64
  %cond4947 = icmp ne i64 %cv4946, 0
  br i1 %cond4947, label %bb_rcslotrole1100, label %bb_rcslotowner1100
bb_rcslotrole1100:
  %v4948 = load i64, ptr %slot56, align 8
  store i64 %v4948, ptr %slot872, align 8
  %v4949 = load i64, ptr %slot872, align 8
  %v4950 = load i64, ptr %slot869, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v4949, i64 %v4950) nomerge, !dbg !146
  br label %bb_rcslotdone1100
bb_rcslotowner1100:
  %v4951 = load i64, ptr %slot56, align 8
  store i64 %v4951, ptr %slot873, align 8
  %v4952 = load i64, ptr %slot873, align 8
  %v4953 = load i64, ptr %slot869, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v4952, i64 %v4953) nomerge, !dbg !146
  br label %bb_rcslotdone1100
bb_rcslotdone1100:
  %v4954 = load i64, ptr %slot37, align 8
  %p4955 = inttoptr i64 %v4954 to ptr
  %ld4956 = load i64, ptr %p4955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4956, ptr %slot874, align 8
  %v4957 = load i64, ptr %slot874, align 8
  %v4958 = load i64, ptr %slot41, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  store i64 %v4957, ptr %p4959, align 8, !alias.scope !3, !noalias !4
  %v4960 = load i64, ptr %slot42, align 8
  %p4961 = inttoptr i64 %v4960 to ptr
  store i64 1, ptr %p4961, align 8, !alias.scope !3, !noalias !4
  %v4962 = load i64, ptr %slot42, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  %ld4964 = load i64, ptr %p4963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4964, ptr %slot875, align 8
  %v4965 = load i64, ptr %slot41, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  %ld4967 = load i64, ptr %p4966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4967, ptr %slot876, align 8
  %v4968 = load i64, ptr %slot876, align 8
  %v4969 = load i64, ptr %slot875, align 8
  %ovpair4971 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4968, i64 %v4969)
  %op4970 = extractvalue { i64, i1 } %ovpair4971, 0
  %ov4972 = extractvalue { i64, i1 } %ovpair4971, 1
  store i64 %op4970, ptr %slot877, align 8
  %cv4973 = zext i1 %ov4972 to i64
  store i64 %cv4973, ptr %slot878, align 8
  %v4974 = load i64, ptr %slot878, align 8
  %cond4975 = icmp ne i64 %v4974, 0
  br i1 %cond4975, label %bb_overflow1110, label %bb_checked1110
bb_overflow1110:
  %v4976 = load i64, ptr %slot1, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  %v4978 = load i64, ptr %slot876, align 8
  %v4979 = load i64, ptr %slot875, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4977, i64 0, i64 %v4978, i64 %v4979, i64 64) nomerge, !dbg !148
  unreachable
bb_checked1110:
  %v4980 = load i64, ptr %slot877, align 8
  %v4981 = load i64, ptr %slot41, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  store i64 %v4980, ptr %p4982, align 8, !alias.scope !3, !noalias !4
  %v4983 = load i64, ptr %slot41, align 8
  %p4984 = inttoptr i64 %v4983 to ptr
  %ld4985 = load i64, ptr %p4984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4985, ptr %slot879, align 8
  %v4986 = load i64, ptr %slot879, align 8
  %v4987 = load i64, ptr %slot37, align 8
  %p4988 = inttoptr i64 %v4987 to ptr
  store i64 %v4986, ptr %p4988, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_i51:
  %v4989 = load i64, ptr %slot36, align 8
  %v4990 = load i64, ptr %slot41, align 8
  %p4991 = inttoptr i64 %v4990 to ptr
  store i64 %v4989, ptr %p4991, align 8, !alias.scope !3, !noalias !4
  %v4992 = load i64, ptr %slot41, align 8
  %p4993 = inttoptr i64 %v4992 to ptr
  %ld4994 = load i64, ptr %p4993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4994, ptr %slot880, align 8
  %v4995 = load i64, ptr %slot880, align 8
  %op4996 = add i64 %v4995, 0
  store i64 %op4996, ptr %slot881, align 8
  %v4997 = load i64, ptr %slot881, align 8
  %v4998 = load i64, ptr %slot41, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  store i64 %v4997, ptr %p4999, align 8, !alias.scope !3, !noalias !4
  %v5000 = load i64, ptr %slot14, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  %ld5002 = load i32, ptr %p5001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5002, ptr %slot882, align 8
  %v5003 = load i32, ptr %slot882, align 8
  %cv5004 = zext i32 %v5003 to i64
  %cond5005 = icmp ne i64 %cv5004, 0
  br i1 %cond5005, label %bb_rcslotdrop1117, label %bb_rcslotdone1117
bb_rcslotdrop1117:
  %v5006 = load i64, ptr %slot14, align 8
  %p5007 = inttoptr i64 %v5006 to ptr
  store i32 0, ptr %p5007, align 4, !alias.scope !3, !noalias !4
  %v5008 = load i64, ptr %slot25, align 8
  store i64 %v5008, ptr %slot883, align 8
  %v5009 = load i64, ptr %slot15, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  %ld5011 = load i32, ptr %p5010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5011, ptr %slot884, align 8
  %v5012 = load i32, ptr %slot884, align 8
  %op5013 = and i32 %v5012, 28
  store i32 %op5013, ptr %slot885, align 8
  %v5014 = load i32, ptr %slot885, align 8
  %cv5015 = zext i32 %v5014 to i64
  %cond5016 = icmp ne i64 %cv5015, 0
  br i1 %cond5016, label %bb_rcslotrole1117, label %bb_rcslotowner1117
bb_rcslotrole1117:
  %v5017 = load i64, ptr %slot56, align 8
  store i64 %v5017, ptr %slot886, align 8
  %v5018 = load i64, ptr %slot886, align 8
  %v5019 = load i64, ptr %slot883, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v5018, i64 %v5019) nomerge, !dbg !150
  br label %bb_rcslotdone1117
bb_rcslotowner1117:
  %v5020 = load i64, ptr %slot56, align 8
  store i64 %v5020, ptr %slot887, align 8
  %v5021 = load i64, ptr %slot887, align 8
  %v5022 = load i64, ptr %slot883, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v5021, i64 %v5022) nomerge, !dbg !150
  br label %bb_rcslotdone1117
bb_rcslotdone1117:
  %v5023 = load i64, ptr %slot41, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %ld5025 = load i64, ptr %p5024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5025, ptr %slot888, align 8
  %v5026 = load i64, ptr %slot14, align 8
  %p5027 = inttoptr i64 %v5026 to ptr
  %ld5028 = load i32, ptr %p5027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5028, ptr %slot889, align 8
  %v5029 = load i64, ptr %slot15, align 8
  %p5030 = inttoptr i64 %v5029 to ptr
  %ld5031 = load i32, ptr %p5030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5031, ptr %slot890, align 8
  %v5032 = load i32, ptr %slot890, align 8
  %op5033 = and i32 %v5032, 24
  store i32 %op5033, ptr %slot890, align 8
  %v5034 = load i32, ptr %slot890, align 8
  %cmp5035 = icmp eq i32 %v5034, 0
  %cv5036 = zext i1 %cmp5035 to i32
  store i32 %cv5036, ptr %slot891, align 8
  %v5037 = load i32, ptr %slot889, align 8
  %v5038 = load i32, ptr %slot891, align 8
  %op5039 = and i32 %v5037, %v5038
  store i32 %op5039, ptr %slot892, align 8
  %v5040 = load i64, ptr %slot57, align 8
  store i64 %v5040, ptr %slot893, align 8
  %v5041 = load i32, ptr %slot892, align 8
  %op5042 = mul i32 %v5041, 4
  store i32 %op5042, ptr %slot894, align 8
  %v5043 = load i32, ptr %slot894, align 8
  %op5044 = or i32 %v5043, 0
  store i32 %op5044, ptr %slot895, align 8
  %v5045 = load i64, ptr %slot31, align 8
  store i64 %v5045, ptr %slot896, align 8
  %v5046 = load i64, ptr %slot56, align 8
  %v5047 = load i64, ptr %slot896, align 8
  %v5048 = load i64, ptr %slot888, align 8
  %v5049 = load i64, ptr %slot893, align 8
  %cv5050 = trunc i64 %v5049 to i32
  %v5051 = load i32, ptr %slot895, align 8
  %call5052 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_publish(i64 %v5046, i64 %v5047, i64 %v5048, i32 %cv5050, i32 %v5051) nomerge, !dbg !152
  store i32 %call5052, ptr %slot897, align 8
  %v5053 = load i32, ptr %slot897, align 8
  %cv5054 = zext i32 %v5053 to i64
  %cond5055 = icmp ne i64 %cv5054, 0
  br i1 %cond5055, label %bb_rcsuccess1138, label %bb_rcfailure1138
bb_rcfailure1138:
  %v5056 = load i64, ptr %slot56, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %call5058 = call i32 @myl_rc_take_failure(ptr %p5057) nomerge, !dbg !152
  store i32 %call5058, ptr %slot898, align 8
  %v5059 = load i64, ptr %slot1, align 8
  %p5060 = inttoptr i64 %v5059 to ptr
  %v5061 = load i32, ptr %slot898, align 8
  %call5062 = call i32 @myl_qbe_rc_status(ptr %p5060, i32 %v5061) nomerge, !dbg !152
  store i32 %call5062, ptr %slot899, align 8
  br label %bb_failure
bb_rcsuccess1138:
  %v5063 = load i32, ptr %slot892, align 8
  %cv5064 = zext i32 %v5063 to i64
  %cond5065 = icmp ne i64 %cv5064, 0
  br i1 %cond5065, label %bb_rchtaken1141, label %bb_rchcopied1141
bb_rchcopied1141:
  %v5066 = load i64, ptr %slot14, align 8
  %p5067 = inttoptr i64 %v5066 to ptr
  %ld5068 = load i32, ptr %p5067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5068, ptr %slot900, align 8
  %v5069 = load i32, ptr %slot900, align 8
  %cv5070 = zext i32 %v5069 to i64
  %cond5071 = icmp ne i64 %cv5070, 0
  br i1 %cond5071, label %bb_rcslotdrop1144, label %bb_rcslotdone1144
bb_rcslotdrop1144:
  %v5072 = load i64, ptr %slot14, align 8
  %p5073 = inttoptr i64 %v5072 to ptr
  store i32 0, ptr %p5073, align 4, !alias.scope !3, !noalias !4
  %v5074 = load i64, ptr %slot25, align 8
  store i64 %v5074, ptr %slot901, align 8
  %v5075 = load i64, ptr %slot15, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  %ld5077 = load i32, ptr %p5076, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5077, ptr %slot902, align 8
  %v5078 = load i32, ptr %slot902, align 8
  %op5079 = and i32 %v5078, 28
  store i32 %op5079, ptr %slot903, align 8
  %v5080 = load i32, ptr %slot903, align 8
  %cv5081 = zext i32 %v5080 to i64
  %cond5082 = icmp ne i64 %cv5081, 0
  br i1 %cond5082, label %bb_rcslotrole1144, label %bb_rcslotowner1144
bb_rcslotrole1144:
  %v5083 = load i64, ptr %slot56, align 8
  store i64 %v5083, ptr %slot904, align 8
  %v5084 = load i64, ptr %slot904, align 8
  %v5085 = load i64, ptr %slot901, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v5084, i64 %v5085) nomerge, !dbg !152
  br label %bb_rcslotdone1144
bb_rcslotowner1144:
  %v5086 = load i64, ptr %slot56, align 8
  store i64 %v5086, ptr %slot905, align 8
  %v5087 = load i64, ptr %slot905, align 8
  %v5088 = load i64, ptr %slot901, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v5087, i64 %v5088) nomerge, !dbg !152
  br label %bb_rcslotdone1144
bb_rcslotdone1144:
  br label %bb_rchprepared1141
bb_rchtaken1141:
  %v5089 = load i64, ptr %slot14, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  store i32 0, ptr %p5090, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1141
bb_rchprepared1141:
  %v5091 = load i64, ptr %slot23, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i32 2, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  %v5093 = load i64, ptr %slot22, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  store i32 1, ptr %p5094, align 4, !alias.scope !3, !noalias !4
  %v5095 = load i64, ptr %slot25, align 8
  store i64 %v5095, ptr %slot906, align 8
  %v5096 = load i64, ptr %slot31, align 8
  store i64 %v5096, ptr %slot907, align 8
  %v5097 = load i64, ptr %slot907, align 8
  %v5098 = load i64, ptr %slot906, align 8
  %p5099 = inttoptr i64 %v5097 to ptr
  %p5100 = inttoptr i64 %v5098 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5100, ptr %p5099, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5101 = load i64, ptr %slot15, align 8
  %p5102 = inttoptr i64 %v5101 to ptr
  store i32 2, ptr %p5102, align 4, !alias.scope !3, !noalias !4
  %v5103 = load i64, ptr %slot23, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %ld5105 = load i32, ptr %p5104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5105, ptr %slot908, align 8
  %v5106 = load i32, ptr %slot908, align 8
  %v5107 = load i64, ptr %slot15, align 8
  %p5108 = inttoptr i64 %v5107 to ptr
  store i32 %v5106, ptr %p5108, align 4, !alias.scope !3, !noalias !4
  %v5109 = load i64, ptr %slot22, align 8
  %p5110 = inttoptr i64 %v5109 to ptr
  store i32 0, ptr %p5110, align 4, !alias.scope !3, !noalias !4
  %v5111 = load i64, ptr %slot14, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  store i32 1, ptr %p5112, align 4, !alias.scope !3, !noalias !4
  %v5113 = load i64, ptr %slot906, align 8
  %v5114 = load i64, ptr %slot41, align 8
  %p5115 = inttoptr i64 %v5114 to ptr
  store i64 %v5113, ptr %p5115, align 8, !alias.scope !3, !noalias !4
  %v5116 = load i64, ptr %slot41, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  %ld5118 = load i64, ptr %p5117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5118, ptr %slot909, align 8
  %v5119 = load i64, ptr %slot31, align 8
  store i64 %v5119, ptr %slot910, align 8
  %v5120 = load i64, ptr %slot57, align 8
  store i64 %v5120, ptr %slot911, align 8
  %v5121 = load i64, ptr %slot909, align 8
  %op5122 = add i64 %v5121, 0
  store i64 %op5122, ptr %slot912, align 8
  %v5123 = load i64, ptr %slot912, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  %ld5125 = load i64, ptr %p5124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5125, ptr %slot913, align 8
  %v5126 = load i64, ptr %slot913, align 8
  %cmp5127 = icmp ne i64 %v5126, 0
  %cv5128 = zext i1 %cmp5127 to i32
  store i32 %cv5128, ptr %slot914, align 8
  %v5129 = load i32, ptr %slot914, align 8
  %cv5130 = zext i32 %v5129 to i64
  %cond5131 = icmp ne i64 %cv5130, 0
  br i1 %cond5131, label %bb_rcmoveheader1168, label %bb_rcmovenext1168
bb_rcmoveheader1168:
  %v5132 = load i64, ptr %slot913, align 8
  %op5133 = sub i64 %v5132, 16
  store i64 %op5133, ptr %slot915, align 8
  %v5134 = load i64, ptr %slot913, align 8
  %p5135 = inttoptr i64 %v5134 to ptr
  %rgep5136 = getelementptr i8, ptr %p5135, i64 -16
  %ld5137 = load i64, ptr %rgep5136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5137, ptr %slot916, align 8
  %v5138 = load i64, ptr %slot916, align 8
  %op5139 = and i64 %v5138, 5764607523034234881
  store i64 %op5139, ptr %slot917, align 8
  %v5140 = load i64, ptr %slot917, align 8
  %cmp5141 = icmp ne i64 %v5140, 0
  %cv5142 = zext i1 %cmp5141 to i32
  store i32 %cv5142, ptr %slot918, align 8
  %v5143 = load i32, ptr %slot918, align 8
  %cv5144 = zext i32 %v5143 to i64
  %cond5145 = icmp ne i64 %cv5144, 0
  br i1 %cond5145, label %bb_rcmoveslow1165, label %bb_rcmovenext1168
bb_rcmovenext1168:
  %v5146 = load i64, ptr %slot909, align 8
  %op5147 = add i64 %v5146, 8
  store i64 %op5147, ptr %slot919, align 8
  %v5148 = load i64, ptr %slot919, align 8
  %p5149 = inttoptr i64 %v5148 to ptr
  %ld5150 = load i64, ptr %p5149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5150, ptr %slot920, align 8
  %v5151 = load i64, ptr %slot920, align 8
  %cmp5152 = icmp ne i64 %v5151, 0
  %cv5153 = zext i1 %cmp5152 to i32
  store i32 %cv5153, ptr %slot921, align 8
  %v5154 = load i32, ptr %slot921, align 8
  %cv5155 = zext i32 %v5154 to i64
  %cond5156 = icmp ne i64 %cv5155, 0
  br i1 %cond5156, label %bb_rcmoveheader1176, label %bb_rcmovenext1176
bb_rcmoveheader1176:
  %v5157 = load i64, ptr %slot920, align 8
  %op5158 = sub i64 %v5157, 16
  store i64 %op5158, ptr %slot922, align 8
  %v5159 = load i64, ptr %slot920, align 8
  %p5160 = inttoptr i64 %v5159 to ptr
  %rgep5161 = getelementptr i8, ptr %p5160, i64 -16
  %ld5162 = load i64, ptr %rgep5161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5162, ptr %slot923, align 8
  %v5163 = load i64, ptr %slot923, align 8
  %op5164 = and i64 %v5163, 5764607523034234881
  store i64 %op5164, ptr %slot924, align 8
  %v5165 = load i64, ptr %slot924, align 8
  %cmp5166 = icmp ne i64 %v5165, 0
  %cv5167 = zext i1 %cmp5166 to i32
  store i32 %cv5167, ptr %slot925, align 8
  %v5168 = load i32, ptr %slot925, align 8
  %cv5169 = zext i32 %v5168 to i64
  %cond5170 = icmp ne i64 %cv5169, 0
  br i1 %cond5170, label %bb_rcmoveslow1165, label %bb_rcmovenext1176
bb_rcmovenext1176:
  %v5171 = load i64, ptr %slot909, align 8
  %op5172 = add i64 %v5171, 16
  store i64 %op5172, ptr %slot926, align 8
  %v5173 = load i64, ptr %slot926, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  %ld5175 = load i64, ptr %p5174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5175, ptr %slot927, align 8
  %v5176 = load i64, ptr %slot927, align 8
  %cmp5177 = icmp ne i64 %v5176, 0
  %cv5178 = zext i1 %cmp5177 to i32
  store i32 %cv5178, ptr %slot928, align 8
  %v5179 = load i32, ptr %slot928, align 8
  %cv5180 = zext i32 %v5179 to i64
  %cond5181 = icmp ne i64 %cv5180, 0
  br i1 %cond5181, label %bb_rcmoveheader1184, label %bb_rcmovenext1184
bb_rcmoveheader1184:
  %v5182 = load i64, ptr %slot927, align 8
  %op5183 = sub i64 %v5182, 16
  store i64 %op5183, ptr %slot929, align 8
  %v5184 = load i64, ptr %slot927, align 8
  %p5185 = inttoptr i64 %v5184 to ptr
  %rgep5186 = getelementptr i8, ptr %p5185, i64 -16
  %ld5187 = load i64, ptr %rgep5186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5187, ptr %slot930, align 8
  %v5188 = load i64, ptr %slot930, align 8
  %op5189 = and i64 %v5188, 5764607523034234881
  store i64 %op5189, ptr %slot931, align 8
  %v5190 = load i64, ptr %slot931, align 8
  %cmp5191 = icmp ne i64 %v5190, 0
  %cv5192 = zext i1 %cmp5191 to i32
  store i32 %cv5192, ptr %slot932, align 8
  %v5193 = load i32, ptr %slot932, align 8
  %cv5194 = zext i32 %v5193 to i64
  %cond5195 = icmp ne i64 %cv5194, 0
  br i1 %cond5195, label %bb_rcmoveslow1165, label %bb_rcmovenext1184
bb_rcmovenext1184:
  %v5196 = load i64, ptr %slot909, align 8
  %op5197 = add i64 %v5196, 24
  store i64 %op5197, ptr %slot933, align 8
  %v5198 = load i64, ptr %slot933, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  %ld5200 = load i64, ptr %p5199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5200, ptr %slot934, align 8
  %v5201 = load i64, ptr %slot934, align 8
  %cmp5202 = icmp ne i64 %v5201, 0
  %cv5203 = zext i1 %cmp5202 to i32
  store i32 %cv5203, ptr %slot935, align 8
  %v5204 = load i32, ptr %slot935, align 8
  %cv5205 = zext i32 %v5204 to i64
  %cond5206 = icmp ne i64 %cv5205, 0
  br i1 %cond5206, label %bb_rcmoveheader1192, label %bb_rcmovenext1192
bb_rcmoveheader1192:
  %v5207 = load i64, ptr %slot934, align 8
  %op5208 = sub i64 %v5207, 16
  store i64 %op5208, ptr %slot936, align 8
  %v5209 = load i64, ptr %slot934, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  %rgep5211 = getelementptr i8, ptr %p5210, i64 -16
  %ld5212 = load i64, ptr %rgep5211, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5212, ptr %slot937, align 8
  %v5213 = load i64, ptr %slot937, align 8
  %op5214 = and i64 %v5213, 5764607523034234881
  store i64 %op5214, ptr %slot938, align 8
  %v5215 = load i64, ptr %slot938, align 8
  %cmp5216 = icmp ne i64 %v5215, 0
  %cv5217 = zext i1 %cmp5216 to i32
  store i32 %cv5217, ptr %slot939, align 8
  %v5218 = load i32, ptr %slot939, align 8
  %cv5219 = zext i32 %v5218 to i64
  %cond5220 = icmp ne i64 %cv5219, 0
  br i1 %cond5220, label %bb_rcmoveslow1165, label %bb_rcmovenext1192
bb_rcmovenext1192:
  %v5221 = load i64, ptr %slot909, align 8
  %v5222 = load i64, ptr %slot910, align 8
  %p5223 = inttoptr i64 %v5221 to ptr
  %p5224 = inttoptr i64 %v5222 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5224, ptr %p5223, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5225 = load i64, ptr %slot909, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  store i64 0, ptr %p5226, align 8, !alias.scope !3, !noalias !4
  %v5227 = load i64, ptr %slot909, align 8
  %op5228 = add i64 %v5227, 8
  store i64 %op5228, ptr %slot940, align 8
  %v5229 = load i64, ptr %slot940, align 8
  %p5230 = inttoptr i64 %v5229 to ptr
  store i64 0, ptr %p5230, align 8, !alias.scope !3, !noalias !4
  %v5231 = load i64, ptr %slot909, align 8
  %op5232 = add i64 %v5231, 16
  store i64 %op5232, ptr %slot941, align 8
  %v5233 = load i64, ptr %slot941, align 8
  %p5234 = inttoptr i64 %v5233 to ptr
  store i64 0, ptr %p5234, align 8, !alias.scope !3, !noalias !4
  %v5235 = load i64, ptr %slot909, align 8
  %op5236 = add i64 %v5235, 24
  store i64 %op5236, ptr %slot942, align 8
  %v5237 = load i64, ptr %slot942, align 8
  %p5238 = inttoptr i64 %v5237 to ptr
  store i64 0, ptr %p5238, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1165
bb_rcmoveslow1165:
  %v5239 = load i64, ptr %slot56, align 8
  %v5240 = load i64, ptr %slot910, align 8
  %v5241 = load i64, ptr %slot909, align 8
  %v5242 = load i64, ptr %slot911, align 8
  %cv5243 = trunc i64 %v5242 to i32
  %call5244 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64 %v5239, i64 %v5240, i64 %v5241, i32 %cv5243) nomerge, !dbg !154
  store i32 %call5244, ptr %slot943, align 8
  %v5245 = load i32, ptr %slot943, align 8
  %cv5246 = zext i32 %v5245 to i64
  %cond5247 = icmp ne i64 %cv5246, 0
  br i1 %cond5247, label %bb_rcsuccess1202, label %bb_rcfailure1202
bb_rcfailure1202:
  %v5248 = load i64, ptr %slot56, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  %call5250 = call i32 @myl_rc_take_failure(ptr %p5249) nomerge, !dbg !154
  store i32 %call5250, ptr %slot944, align 8
  %v5251 = load i64, ptr %slot1, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  %v5253 = load i32, ptr %slot944, align 8
  %call5254 = call i32 @myl_qbe_rc_status(ptr %p5252, i32 %v5253) nomerge, !dbg !154
  store i32 %call5254, ptr %slot945, align 8
  br label %bb_failure
bb_rcsuccess1202:
  br label %bb_rcmoved1165
bb_rcmoved1165:
  %v5255 = load i64, ptr %slot14, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  store i32 0, ptr %p5256, align 4, !alias.scope !3, !noalias !4
  %v5257 = load i64, ptr %slot23, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  store i32 2, ptr %p5258, align 4, !alias.scope !3, !noalias !4
  %v5259 = load i64, ptr %slot22, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  store i32 1, ptr %p5260, align 4, !alias.scope !3, !noalias !4
  %v5261 = load i64, ptr %slot32, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %ld5263 = load i64, ptr %p5262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5263, ptr %slot946, align 8
  %v5264 = load i64, ptr %slot946, align 8
  %op5265 = add i64 %v5264, 0
  store i64 %op5265, ptr %slot947, align 8
  %v5266 = load i64, ptr %slot56, align 8
  store i64 %v5266, ptr %slot948, align 8
  %v5267 = load i64, ptr %slot947, align 8
  %p5268 = inttoptr i64 %v5267 to ptr
  %ld5269 = load i64, ptr %p5268, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5269, ptr %slot949, align 8
  %v5270 = load i64, ptr %slot949, align 8
  %cmp5271 = icmp ne i64 %v5270, 0
  %cv5272 = zext i1 %cmp5271 to i32
  store i32 %cv5272, ptr %slot950, align 8
  %v5273 = load i32, ptr %slot950, align 8
  %cv5274 = zext i32 %v5273 to i64
  %cond5275 = icmp ne i64 %cv5274, 0
  br i1 %cond5275, label %bb_rcgnn1221, label %bb_rcgdone1221
bb_rcgnn1221:
  %v5276 = load i64, ptr %slot949, align 8
  %op5277 = sub i64 %v5276, 16
  store i64 %op5277, ptr %slot951, align 8
  %v5278 = load i64, ptr %slot949, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %rgep5280 = getelementptr i8, ptr %p5279, i64 -16
  %ld5281 = load i64, ptr %rgep5280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5281, ptr %slot952, align 8
  %v5282 = load i64, ptr %slot952, align 8
  %op5283 = and i64 %v5282, 4611686018427387906
  store i64 %op5283, ptr %slot953, align 8
  %v5284 = load i64, ptr %slot953, align 8
  %cmp5285 = icmp ne i64 %v5284, 0
  %cv5286 = zext i1 %cmp5285 to i32
  store i32 %cv5286, ptr %slot954, align 8
  %v5287 = load i32, ptr %slot954, align 8
  %cv5288 = zext i32 %v5287 to i64
  %cond5289 = icmp ne i64 %cv5288, 0
  br i1 %cond5289, label %bb_rcgclear1221, label %bb_rcgcounted1221
bb_rcgcounted1221:
  %v5290 = load i64, ptr %slot949, align 8
  %op5291 = sub i64 %v5290, 32
  store i64 %op5291, ptr %slot955, align 8
  %v5292 = load i64, ptr %slot949, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %rgep5294 = getelementptr i8, ptr %p5293, i64 -32
  %ld5295 = load i64, ptr %rgep5294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5295, ptr %slot956, align 8
  %v5296 = load i64, ptr %slot956, align 8
  %op5297 = sub i64 %v5296, 1
  store i64 %op5297, ptr %slot957, align 8
  %v5298 = load i64, ptr %slot957, align 8
  %cmp5299 = icmp eq i64 %v5298, 0
  %cv5300 = zext i1 %cmp5299 to i32
  store i32 %cv5300, ptr %slot958, align 8
  %v5301 = load i32, ptr %slot958, align 8
  %cv5302 = zext i32 %v5301 to i64
  %cond5303 = icmp ne i64 %cv5302, 0
  br i1 %cond5303, label %bb_rcglast1221, label %bb_rcgdec1221
bb_rcglast1221:
  %v5304 = load i64, ptr %slot949, align 8
  %op5305 = sub i64 %v5304, 24
  store i64 %op5305, ptr %slot959, align 8
  %v5306 = load i64, ptr %slot949, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  %rgep5308 = getelementptr i8, ptr %p5307, i64 -24
  %ld5309 = load i64, ptr %rgep5308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5309, ptr %slot960, align 8
  %v5310 = load i64, ptr %slot960, align 8
  %cmp5311 = icmp ne i64 %v5310, 0
  %cv5312 = zext i1 %cmp5311 to i32
  store i32 %cv5312, ptr %slot961, align 8
  %v5313 = load i32, ptr %slot961, align 8
  %cv5314 = zext i32 %v5313 to i64
  %cond5315 = icmp ne i64 %cv5314, 0
  br i1 %cond5315, label %bb_rcgdec1221, label %bb_rcgslow1221
bb_rcgslow1221:
  %v5316 = load i64, ptr %slot948, align 8
  %v5317 = load i64, ptr %slot947, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v5316, i64 %v5317) nomerge, !dbg !154
  br label %bb_rcgdone1221
bb_rcgdec1221:
  %v5318 = load i64, ptr %slot957, align 8
  %v5319 = load i64, ptr %slot949, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %rgep5321 = getelementptr i8, ptr %p5320, i64 -32
  store i64 %v5318, ptr %rgep5321, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1221
bb_rcgclear1221:
  %v5322 = load i64, ptr %slot947, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  store i64 0, ptr %p5323, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcgdone1221
bb_rcgdone1221:
  %v5324 = load i64, ptr %slot946, align 8
  %op5325 = add i64 %v5324, 8
  store i64 %op5325, ptr %slot962, align 8
  %v5326 = load i64, ptr %slot56, align 8
  store i64 %v5326, ptr %slot963, align 8
  %v5327 = load i64, ptr %slot962, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  %ld5329 = load i64, ptr %p5328, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5329, ptr %slot964, align 8
  %v5330 = load i64, ptr %slot964, align 8
  %cmp5331 = icmp ne i64 %v5330, 0
  %cv5332 = zext i1 %cmp5331 to i32
  store i32 %cv5332, ptr %slot965, align 8
  %v5333 = load i32, ptr %slot965, align 8
  %cv5334 = zext i32 %v5333 to i64
  %cond5335 = icmp ne i64 %cv5334, 0
  br i1 %cond5335, label %bb_rcgnn1237, label %bb_rcgdone1237
bb_rcgnn1237:
  %v5336 = load i64, ptr %slot964, align 8
  %op5337 = sub i64 %v5336, 16
  store i64 %op5337, ptr %slot966, align 8
  %v5338 = load i64, ptr %slot964, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  %rgep5340 = getelementptr i8, ptr %p5339, i64 -16
  %ld5341 = load i64, ptr %rgep5340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5341, ptr %slot967, align 8
  %v5342 = load i64, ptr %slot967, align 8
  %op5343 = and i64 %v5342, 4611686018427387906
  store i64 %op5343, ptr %slot968, align 8
  %v5344 = load i64, ptr %slot968, align 8
  %cmp5345 = icmp ne i64 %v5344, 0
  %cv5346 = zext i1 %cmp5345 to i32
  store i32 %cv5346, ptr %slot969, align 8
  %v5347 = load i32, ptr %slot969, align 8
  %cv5348 = zext i32 %v5347 to i64
  %cond5349 = icmp ne i64 %cv5348, 0
  br i1 %cond5349, label %bb_rcgclear1237, label %bb_rcgcounted1237
bb_rcgcounted1237:
  %v5350 = load i64, ptr %slot964, align 8
  %op5351 = sub i64 %v5350, 32
  store i64 %op5351, ptr %slot970, align 8
  %v5352 = load i64, ptr %slot964, align 8
  %p5353 = inttoptr i64 %v5352 to ptr
  %rgep5354 = getelementptr i8, ptr %p5353, i64 -32
  %ld5355 = load i64, ptr %rgep5354, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5355, ptr %slot971, align 8
  %v5356 = load i64, ptr %slot971, align 8
  %op5357 = sub i64 %v5356, 1
  store i64 %op5357, ptr %slot972, align 8
  %v5358 = load i64, ptr %slot972, align 8
  %cmp5359 = icmp eq i64 %v5358, 0
  %cv5360 = zext i1 %cmp5359 to i32
  store i32 %cv5360, ptr %slot973, align 8
  %v5361 = load i32, ptr %slot973, align 8
  %cv5362 = zext i32 %v5361 to i64
  %cond5363 = icmp ne i64 %cv5362, 0
  br i1 %cond5363, label %bb_rcglast1237, label %bb_rcgdec1237
bb_rcglast1237:
  %v5364 = load i64, ptr %slot964, align 8
  %op5365 = sub i64 %v5364, 24
  store i64 %op5365, ptr %slot974, align 8
  %v5366 = load i64, ptr %slot964, align 8
  %p5367 = inttoptr i64 %v5366 to ptr
  %rgep5368 = getelementptr i8, ptr %p5367, i64 -24
  %ld5369 = load i64, ptr %rgep5368, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5369, ptr %slot975, align 8
  %v5370 = load i64, ptr %slot975, align 8
  %cmp5371 = icmp ne i64 %v5370, 0
  %cv5372 = zext i1 %cmp5371 to i32
  store i32 %cv5372, ptr %slot976, align 8
  %v5373 = load i32, ptr %slot976, align 8
  %cv5374 = zext i32 %v5373 to i64
  %cond5375 = icmp ne i64 %cv5374, 0
  br i1 %cond5375, label %bb_rcgdec1237, label %bb_rcgslow1237
bb_rcgslow1237:
  %v5376 = load i64, ptr %slot963, align 8
  %v5377 = load i64, ptr %slot962, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64 %v5376, i64 %v5377) nomerge, !dbg !154
  br label %bb_rcgdone1237
bb_rcgdec1237:
  %v5378 = load i64, ptr %slot972, align 8
  %v5379 = load i64, ptr %slot964, align 8
  %p5380 = inttoptr i64 %v5379 to ptr
  %rgep5381 = getelementptr i8, ptr %p5380, i64 -32
  store i64 %v5378, ptr %rgep5381, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1237
bb_rcgclear1237:
  %v5382 = load i64, ptr %slot962, align 8
  %p5383 = inttoptr i64 %v5382 to ptr
  store i64 0, ptr %p5383, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcgdone1237
bb_rcgdone1237:
  %v5384 = load i64, ptr %slot946, align 8
  %op5385 = add i64 %v5384, 16
  store i64 %op5385, ptr %slot977, align 8
  %v5386 = load i64, ptr %slot56, align 8
  store i64 %v5386, ptr %slot978, align 8
  %v5387 = load i64, ptr %slot977, align 8
  %p5388 = inttoptr i64 %v5387 to ptr
  %ld5389 = load i64, ptr %p5388, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5389, ptr %slot979, align 8
  %v5390 = load i64, ptr %slot979, align 8
  %cmp5391 = icmp ne i64 %v5390, 0
  %cv5392 = zext i1 %cmp5391 to i32
  store i32 %cv5392, ptr %slot980, align 8
  %v5393 = load i32, ptr %slot980, align 8
  %cv5394 = zext i32 %v5393 to i64
  %cond5395 = icmp ne i64 %cv5394, 0
  br i1 %cond5395, label %bb_rcgnn1253, label %bb_rcgdone1253
bb_rcgnn1253:
  %v5396 = load i64, ptr %slot979, align 8
  %op5397 = sub i64 %v5396, 16
  store i64 %op5397, ptr %slot981, align 8
  %v5398 = load i64, ptr %slot979, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  %rgep5400 = getelementptr i8, ptr %p5399, i64 -16
  %ld5401 = load i64, ptr %rgep5400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5401, ptr %slot982, align 8
  %v5402 = load i64, ptr %slot982, align 8
  %op5403 = and i64 %v5402, 4611686018427387906
  store i64 %op5403, ptr %slot983, align 8
  %v5404 = load i64, ptr %slot983, align 8
  %cmp5405 = icmp ne i64 %v5404, 0
  %cv5406 = zext i1 %cmp5405 to i32
  store i32 %cv5406, ptr %slot984, align 8
  %v5407 = load i32, ptr %slot984, align 8
  %cv5408 = zext i32 %v5407 to i64
  %cond5409 = icmp ne i64 %cv5408, 0
  br i1 %cond5409, label %bb_rcgclear1253, label %bb_rcgcounted1253
bb_rcgcounted1253:
  %v5410 = load i64, ptr %slot979, align 8
  %op5411 = sub i64 %v5410, 32
  store i64 %op5411, ptr %slot985, align 8
  %v5412 = load i64, ptr %slot979, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  %rgep5414 = getelementptr i8, ptr %p5413, i64 -32
  %ld5415 = load i64, ptr %rgep5414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5415, ptr %slot986, align 8
  %v5416 = load i64, ptr %slot986, align 8
  %op5417 = sub i64 %v5416, 1
  store i64 %op5417, ptr %slot987, align 8
  %v5418 = load i64, ptr %slot987, align 8
  %cmp5419 = icmp eq i64 %v5418, 0
  %cv5420 = zext i1 %cmp5419 to i32
  store i32 %cv5420, ptr %slot988, align 8
  %v5421 = load i32, ptr %slot988, align 8
  %cv5422 = zext i32 %v5421 to i64
  %cond5423 = icmp ne i64 %cv5422, 0
  br i1 %cond5423, label %bb_rcglast1253, label %bb_rcgdec1253
bb_rcglast1253:
  %v5424 = load i64, ptr %slot979, align 8
  %op5425 = sub i64 %v5424, 24
  store i64 %op5425, ptr %slot989, align 8
  %v5426 = load i64, ptr %slot979, align 8
  %p5427 = inttoptr i64 %v5426 to ptr
  %rgep5428 = getelementptr i8, ptr %p5427, i64 -24
  %ld5429 = load i64, ptr %rgep5428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5429, ptr %slot990, align 8
  %v5430 = load i64, ptr %slot990, align 8
  %cmp5431 = icmp ne i64 %v5430, 0
  %cv5432 = zext i1 %cmp5431 to i32
  store i32 %cv5432, ptr %slot991, align 8
  %v5433 = load i32, ptr %slot991, align 8
  %cv5434 = zext i32 %v5433 to i64
  %cond5435 = icmp ne i64 %cv5434, 0
  br i1 %cond5435, label %bb_rcgdec1253, label %bb_rcgslow1253
bb_rcgslow1253:
  %v5436 = load i64, ptr %slot978, align 8
  %v5437 = load i64, ptr %slot977, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v5436, i64 %v5437) nomerge, !dbg !154
  br label %bb_rcgdone1253
bb_rcgdec1253:
  %v5438 = load i64, ptr %slot987, align 8
  %v5439 = load i64, ptr %slot979, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  %rgep5441 = getelementptr i8, ptr %p5440, i64 -32
  store i64 %v5438, ptr %rgep5441, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1253
bb_rcgclear1253:
  %v5442 = load i64, ptr %slot977, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  store i64 0, ptr %p5443, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcgdone1253
bb_rcgdone1253:
  %v5444 = load i64, ptr %slot946, align 8
  %op5445 = add i64 %v5444, 24
  store i64 %op5445, ptr %slot992, align 8
  %v5446 = load i64, ptr %slot56, align 8
  store i64 %v5446, ptr %slot993, align 8
  %v5447 = load i64, ptr %slot992, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  %ld5449 = load i64, ptr %p5448, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5449, ptr %slot994, align 8
  %v5450 = load i64, ptr %slot994, align 8
  %cmp5451 = icmp ne i64 %v5450, 0
  %cv5452 = zext i1 %cmp5451 to i32
  store i32 %cv5452, ptr %slot995, align 8
  %v5453 = load i32, ptr %slot995, align 8
  %cv5454 = zext i32 %v5453 to i64
  %cond5455 = icmp ne i64 %cv5454, 0
  br i1 %cond5455, label %bb_rcgnn1269, label %bb_rcgdone1269
bb_rcgnn1269:
  %v5456 = load i64, ptr %slot994, align 8
  %op5457 = sub i64 %v5456, 16
  store i64 %op5457, ptr %slot996, align 8
  %v5458 = load i64, ptr %slot994, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %rgep5460 = getelementptr i8, ptr %p5459, i64 -16
  %ld5461 = load i64, ptr %rgep5460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5461, ptr %slot997, align 8
  %v5462 = load i64, ptr %slot997, align 8
  %op5463 = and i64 %v5462, 4611686018427387906
  store i64 %op5463, ptr %slot998, align 8
  %v5464 = load i64, ptr %slot998, align 8
  %cmp5465 = icmp ne i64 %v5464, 0
  %cv5466 = zext i1 %cmp5465 to i32
  store i32 %cv5466, ptr %slot999, align 8
  %v5467 = load i32, ptr %slot999, align 8
  %cv5468 = zext i32 %v5467 to i64
  %cond5469 = icmp ne i64 %cv5468, 0
  br i1 %cond5469, label %bb_rcgclear1269, label %bb_rcgcounted1269
bb_rcgcounted1269:
  %v5470 = load i64, ptr %slot994, align 8
  %op5471 = sub i64 %v5470, 32
  store i64 %op5471, ptr %slot1000, align 8
  %v5472 = load i64, ptr %slot994, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  %rgep5474 = getelementptr i8, ptr %p5473, i64 -32
  %ld5475 = load i64, ptr %rgep5474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5475, ptr %slot1001, align 8
  %v5476 = load i64, ptr %slot1001, align 8
  %op5477 = sub i64 %v5476, 1
  store i64 %op5477, ptr %slot1002, align 8
  %v5478 = load i64, ptr %slot1002, align 8
  %cmp5479 = icmp eq i64 %v5478, 0
  %cv5480 = zext i1 %cmp5479 to i32
  store i32 %cv5480, ptr %slot1003, align 8
  %v5481 = load i32, ptr %slot1003, align 8
  %cv5482 = zext i32 %v5481 to i64
  %cond5483 = icmp ne i64 %cv5482, 0
  br i1 %cond5483, label %bb_rcglast1269, label %bb_rcgdec1269
bb_rcglast1269:
  %v5484 = load i64, ptr %slot994, align 8
  %op5485 = sub i64 %v5484, 24
  store i64 %op5485, ptr %slot1004, align 8
  %v5486 = load i64, ptr %slot994, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  %rgep5488 = getelementptr i8, ptr %p5487, i64 -24
  %ld5489 = load i64, ptr %rgep5488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5489, ptr %slot1005, align 8
  %v5490 = load i64, ptr %slot1005, align 8
  %cmp5491 = icmp ne i64 %v5490, 0
  %cv5492 = zext i1 %cmp5491 to i32
  store i32 %cv5492, ptr %slot1006, align 8
  %v5493 = load i32, ptr %slot1006, align 8
  %cv5494 = zext i32 %v5493 to i64
  %cond5495 = icmp ne i64 %cv5494, 0
  br i1 %cond5495, label %bb_rcgdec1269, label %bb_rcgslow1269
bb_rcgslow1269:
  %v5496 = load i64, ptr %slot993, align 8
  %v5497 = load i64, ptr %slot992, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5496, i64 %v5497) nomerge, !dbg !154
  br label %bb_rcgdone1269
bb_rcgdec1269:
  %v5498 = load i64, ptr %slot1002, align 8
  %v5499 = load i64, ptr %slot994, align 8
  %p5500 = inttoptr i64 %v5499 to ptr
  %rgep5501 = getelementptr i8, ptr %p5500, i64 -32
  store i64 %v5498, ptr %rgep5501, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1269
bb_rcgclear1269:
  %v5502 = load i64, ptr %slot992, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  store i64 0, ptr %p5503, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcgdone1269
bb_rcgdone1269:
  %v5504 = load i64, ptr %slot946, align 8
  %p5505 = inttoptr i64 %v5504 to ptr
  store i64 0, ptr %p5505, align 8, !alias.scope !4, !noalias !3
  %v5506 = load i64, ptr %slot946, align 8
  %op5507 = add i64 %v5506, 8
  store i64 %op5507, ptr %slot1007, align 8
  %v5508 = load i64, ptr %slot1007, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  store i64 0, ptr %p5509, align 8, !alias.scope !4, !noalias !3
  %v5510 = load i64, ptr %slot946, align 8
  %op5511 = add i64 %v5510, 16
  store i64 %op5511, ptr %slot1008, align 8
  %v5512 = load i64, ptr %slot1008, align 8
  %p5513 = inttoptr i64 %v5512 to ptr
  store i64 0, ptr %p5513, align 8, !alias.scope !4, !noalias !3
  %v5514 = load i64, ptr %slot946, align 8
  %op5515 = add i64 %v5514, 24
  store i64 %op5515, ptr %slot1009, align 8
  %v5516 = load i64, ptr %slot1009, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  store i64 0, ptr %p5517, align 8, !alias.scope !4, !noalias !3
  %v5518 = load i64, ptr %slot31, align 8
  store i64 %v5518, ptr %slot1010, align 8
  %v5519 = load i64, ptr %slot1010, align 8
  %v5520 = load i64, ptr %slot946, align 8
  %p5521 = inttoptr i64 %v5519 to ptr
  %p5522 = inttoptr i64 %v5520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5522, ptr %p5521, i64 32, i1 false), !alias.scope !10000000
  %v5523 = load i64, ptr %slot22, align 8
  %p5524 = inttoptr i64 %v5523 to ptr
  store i32 0, ptr %p5524, align 4, !alias.scope !3, !noalias !4
  %v5525 = load i64, ptr %slot36, align 8
  %v5526 = load i64, ptr %slot41, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  store i64 %v5525, ptr %p5527, align 8, !alias.scope !3, !noalias !4
  %v5528 = load i64, ptr %slot41, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %ld5530 = load i64, ptr %p5529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5530, ptr %slot1011, align 8
  %v5531 = load i64, ptr %slot1011, align 8
  %op5532 = add i64 %v5531, 40
  store i64 %op5532, ptr %slot1012, align 8
  %v5533 = load i64, ptr %slot1012, align 8
  %v5534 = load i64, ptr %slot41, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  store i64 %v5533, ptr %p5535, align 8, !alias.scope !3, !noalias !4
  %v5536 = load i64, ptr %slot14, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  %ld5538 = load i32, ptr %p5537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5538, ptr %slot1013, align 8
  %v5539 = load i32, ptr %slot1013, align 8
  %cv5540 = zext i32 %v5539 to i64
  %cond5541 = icmp ne i64 %cv5540, 0
  br i1 %cond5541, label %bb_rcslotdrop1282, label %bb_rcslotdone1282
bb_rcslotdrop1282:
  %v5542 = load i64, ptr %slot14, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  store i32 0, ptr %p5543, align 4, !alias.scope !3, !noalias !4
  %v5544 = load i64, ptr %slot25, align 8
  store i64 %v5544, ptr %slot1014, align 8
  %v5545 = load i64, ptr %slot15, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %ld5547 = load i32, ptr %p5546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5547, ptr %slot1015, align 8
  %v5548 = load i32, ptr %slot1015, align 8
  %op5549 = and i32 %v5548, 28
  store i32 %op5549, ptr %slot1016, align 8
  %v5550 = load i32, ptr %slot1016, align 8
  %cv5551 = zext i32 %v5550 to i64
  %cond5552 = icmp ne i64 %cv5551, 0
  br i1 %cond5552, label %bb_rcslotrole1282, label %bb_rcslotowner1282
bb_rcslotrole1282:
  %v5553 = load i64, ptr %slot56, align 8
  store i64 %v5553, ptr %slot1017, align 8
  %v5554 = load i64, ptr %slot1017, align 8
  %v5555 = load i64, ptr %slot1014, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v5554, i64 %v5555) nomerge, !dbg !156
  br label %bb_rcslotdone1282
bb_rcslotowner1282:
  %v5556 = load i64, ptr %slot56, align 8
  store i64 %v5556, ptr %slot1018, align 8
  %v5557 = load i64, ptr %slot1018, align 8
  %v5558 = load i64, ptr %slot1014, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v5557, i64 %v5558) nomerge, !dbg !156
  br label %bb_rcslotdone1282
bb_rcslotdone1282:
  %v5559 = load i64, ptr %slot41, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %ld5561 = load i64, ptr %p5560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5561, ptr %slot1019, align 8
  %v5562 = load i64, ptr %slot14, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %ld5564 = load i32, ptr %p5563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5564, ptr %slot1020, align 8
  %v5565 = load i64, ptr %slot15, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %ld5567 = load i32, ptr %p5566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5567, ptr %slot1021, align 8
  %v5568 = load i32, ptr %slot1021, align 8
  %op5569 = and i32 %v5568, 24
  store i32 %op5569, ptr %slot1021, align 8
  %v5570 = load i32, ptr %slot1021, align 8
  %cmp5571 = icmp eq i32 %v5570, 0
  %cv5572 = zext i1 %cmp5571 to i32
  store i32 %cv5572, ptr %slot1022, align 8
  %v5573 = load i32, ptr %slot1020, align 8
  %v5574 = load i32, ptr %slot1022, align 8
  %op5575 = and i32 %v5573, %v5574
  store i32 %op5575, ptr %slot1023, align 8
  %v5576 = load i64, ptr %slot57, align 8
  store i64 %v5576, ptr %slot1024, align 8
  %v5577 = load i32, ptr %slot1023, align 8
  %op5578 = mul i32 %v5577, 4
  store i32 %op5578, ptr %slot1025, align 8
  %v5579 = load i32, ptr %slot1025, align 8
  %op5580 = or i32 %v5579, 0
  store i32 %op5580, ptr %slot1026, align 8
  %v5581 = load i64, ptr %slot31, align 8
  store i64 %v5581, ptr %slot1027, align 8
  %v5582 = load i64, ptr %slot56, align 8
  %v5583 = load i64, ptr %slot1027, align 8
  %v5584 = load i64, ptr %slot1019, align 8
  %v5585 = load i64, ptr %slot1024, align 8
  %cv5586 = trunc i64 %v5585 to i32
  %v5587 = load i32, ptr %slot1026, align 8
  %call5588 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v5582, i64 %v5583, i64 %v5584, i32 %cv5586, i32 %v5587) nomerge, !dbg !158
  store i32 %call5588, ptr %slot1028, align 8
  %v5589 = load i32, ptr %slot1028, align 8
  %cv5590 = zext i32 %v5589 to i64
  %cond5591 = icmp ne i64 %cv5590, 0
  br i1 %cond5591, label %bb_rcsuccess1303, label %bb_rcfailure1303
bb_rcfailure1303:
  %v5592 = load i64, ptr %slot56, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  %call5594 = call i32 @myl_rc_take_failure(ptr %p5593) nomerge, !dbg !158
  store i32 %call5594, ptr %slot1029, align 8
  %v5595 = load i64, ptr %slot1, align 8
  %p5596 = inttoptr i64 %v5595 to ptr
  %v5597 = load i32, ptr %slot1029, align 8
  %call5598 = call i32 @myl_qbe_rc_status(ptr %p5596, i32 %v5597) nomerge, !dbg !158
  store i32 %call5598, ptr %slot1030, align 8
  br label %bb_failure
bb_rcsuccess1303:
  %v5599 = load i32, ptr %slot1023, align 8
  %cv5600 = zext i32 %v5599 to i64
  %cond5601 = icmp ne i64 %cv5600, 0
  br i1 %cond5601, label %bb_rchtaken1306, label %bb_rchcopied1306
bb_rchcopied1306:
  %v5602 = load i64, ptr %slot14, align 8
  %p5603 = inttoptr i64 %v5602 to ptr
  %ld5604 = load i32, ptr %p5603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5604, ptr %slot1031, align 8
  %v5605 = load i32, ptr %slot1031, align 8
  %cv5606 = zext i32 %v5605 to i64
  %cond5607 = icmp ne i64 %cv5606, 0
  br i1 %cond5607, label %bb_rcslotdrop1309, label %bb_rcslotdone1309
bb_rcslotdrop1309:
  %v5608 = load i64, ptr %slot14, align 8
  %p5609 = inttoptr i64 %v5608 to ptr
  store i32 0, ptr %p5609, align 4, !alias.scope !3, !noalias !4
  %v5610 = load i64, ptr %slot25, align 8
  store i64 %v5610, ptr %slot1032, align 8
  %v5611 = load i64, ptr %slot15, align 8
  %p5612 = inttoptr i64 %v5611 to ptr
  %ld5613 = load i32, ptr %p5612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5613, ptr %slot1033, align 8
  %v5614 = load i32, ptr %slot1033, align 8
  %op5615 = and i32 %v5614, 28
  store i32 %op5615, ptr %slot1034, align 8
  %v5616 = load i32, ptr %slot1034, align 8
  %cv5617 = zext i32 %v5616 to i64
  %cond5618 = icmp ne i64 %cv5617, 0
  br i1 %cond5618, label %bb_rcslotrole1309, label %bb_rcslotowner1309
bb_rcslotrole1309:
  %v5619 = load i64, ptr %slot56, align 8
  store i64 %v5619, ptr %slot1035, align 8
  %v5620 = load i64, ptr %slot1035, align 8
  %v5621 = load i64, ptr %slot1032, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v5620, i64 %v5621) nomerge, !dbg !158
  br label %bb_rcslotdone1309
bb_rcslotowner1309:
  %v5622 = load i64, ptr %slot56, align 8
  store i64 %v5622, ptr %slot1036, align 8
  %v5623 = load i64, ptr %slot1036, align 8
  %v5624 = load i64, ptr %slot1032, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5623, i64 %v5624) nomerge, !dbg !158
  br label %bb_rcslotdone1309
bb_rcslotdone1309:
  br label %bb_rchprepared1306
bb_rchtaken1306:
  %v5625 = load i64, ptr %slot14, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  store i32 0, ptr %p5626, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1306
bb_rchprepared1306:
  %v5627 = load i64, ptr %slot23, align 8
  %p5628 = inttoptr i64 %v5627 to ptr
  store i32 2, ptr %p5628, align 4, !alias.scope !3, !noalias !4
  %v5629 = load i64, ptr %slot22, align 8
  %p5630 = inttoptr i64 %v5629 to ptr
  store i32 1, ptr %p5630, align 4, !alias.scope !3, !noalias !4
  %v5631 = load i64, ptr %slot25, align 8
  store i64 %v5631, ptr %slot1037, align 8
  %v5632 = load i64, ptr %slot31, align 8
  store i64 %v5632, ptr %slot1038, align 8
  %v5633 = load i64, ptr %slot1038, align 8
  %v5634 = load i64, ptr %slot1037, align 8
  %p5635 = inttoptr i64 %v5633 to ptr
  %p5636 = inttoptr i64 %v5634 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5636, ptr %p5635, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5637 = load i64, ptr %slot15, align 8
  %p5638 = inttoptr i64 %v5637 to ptr
  store i32 2, ptr %p5638, align 4, !alias.scope !3, !noalias !4
  %v5639 = load i64, ptr %slot23, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  %ld5641 = load i32, ptr %p5640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5641, ptr %slot1039, align 8
  %v5642 = load i32, ptr %slot1039, align 8
  %v5643 = load i64, ptr %slot15, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  store i32 %v5642, ptr %p5644, align 4, !alias.scope !3, !noalias !4
  %v5645 = load i64, ptr %slot22, align 8
  %p5646 = inttoptr i64 %v5645 to ptr
  store i32 0, ptr %p5646, align 4, !alias.scope !3, !noalias !4
  %v5647 = load i64, ptr %slot14, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  store i32 1, ptr %p5648, align 4, !alias.scope !3, !noalias !4
  %v5649 = load i64, ptr %slot1037, align 8
  %v5650 = load i64, ptr %slot41, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  store i64 %v5649, ptr %p5651, align 8, !alias.scope !3, !noalias !4
  %v5652 = load i64, ptr %slot41, align 8
  %p5653 = inttoptr i64 %v5652 to ptr
  %ld5654 = load i64, ptr %p5653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5654, ptr %slot1040, align 8
  %v5655 = load i64, ptr %slot31, align 8
  store i64 %v5655, ptr %slot1041, align 8
  %v5656 = load i64, ptr %slot57, align 8
  store i64 %v5656, ptr %slot1042, align 8
  %v5657 = load i64, ptr %slot1040, align 8
  %op5658 = add i64 %v5657, 0
  store i64 %op5658, ptr %slot1043, align 8
  %v5659 = load i64, ptr %slot1043, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  %ld5661 = load i64, ptr %p5660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5661, ptr %slot1044, align 8
  %v5662 = load i64, ptr %slot1044, align 8
  %cmp5663 = icmp ne i64 %v5662, 0
  %cv5664 = zext i1 %cmp5663 to i32
  store i32 %cv5664, ptr %slot1045, align 8
  %v5665 = load i32, ptr %slot1045, align 8
  %cv5666 = zext i32 %v5665 to i64
  %cond5667 = icmp ne i64 %cv5666, 0
  br i1 %cond5667, label %bb_rcmoveheader1333, label %bb_rcmovenext1333
bb_rcmoveheader1333:
  %v5668 = load i64, ptr %slot1044, align 8
  %op5669 = sub i64 %v5668, 16
  store i64 %op5669, ptr %slot1046, align 8
  %v5670 = load i64, ptr %slot1044, align 8
  %p5671 = inttoptr i64 %v5670 to ptr
  %rgep5672 = getelementptr i8, ptr %p5671, i64 -16
  %ld5673 = load i64, ptr %rgep5672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5673, ptr %slot1047, align 8
  %v5674 = load i64, ptr %slot1047, align 8
  %op5675 = and i64 %v5674, 5764607523034234881
  store i64 %op5675, ptr %slot1048, align 8
  %v5676 = load i64, ptr %slot1048, align 8
  %cmp5677 = icmp ne i64 %v5676, 0
  %cv5678 = zext i1 %cmp5677 to i32
  store i32 %cv5678, ptr %slot1049, align 8
  %v5679 = load i32, ptr %slot1049, align 8
  %cv5680 = zext i32 %v5679 to i64
  %cond5681 = icmp ne i64 %cv5680, 0
  br i1 %cond5681, label %bb_rcmoveslow1330, label %bb_rcmovenext1333
bb_rcmovenext1333:
  %v5682 = load i64, ptr %slot1040, align 8
  %op5683 = add i64 %v5682, 8
  store i64 %op5683, ptr %slot1050, align 8
  %v5684 = load i64, ptr %slot1050, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  %ld5686 = load i64, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5686, ptr %slot1051, align 8
  %v5687 = load i64, ptr %slot1051, align 8
  %cmp5688 = icmp ne i64 %v5687, 0
  %cv5689 = zext i1 %cmp5688 to i32
  store i32 %cv5689, ptr %slot1052, align 8
  %v5690 = load i32, ptr %slot1052, align 8
  %cv5691 = zext i32 %v5690 to i64
  %cond5692 = icmp ne i64 %cv5691, 0
  br i1 %cond5692, label %bb_rcmoveheader1341, label %bb_rcmovenext1341
bb_rcmoveheader1341:
  %v5693 = load i64, ptr %slot1051, align 8
  %op5694 = sub i64 %v5693, 16
  store i64 %op5694, ptr %slot1053, align 8
  %v5695 = load i64, ptr %slot1051, align 8
  %p5696 = inttoptr i64 %v5695 to ptr
  %rgep5697 = getelementptr i8, ptr %p5696, i64 -16
  %ld5698 = load i64, ptr %rgep5697, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5698, ptr %slot1054, align 8
  %v5699 = load i64, ptr %slot1054, align 8
  %op5700 = and i64 %v5699, 5764607523034234881
  store i64 %op5700, ptr %slot1055, align 8
  %v5701 = load i64, ptr %slot1055, align 8
  %cmp5702 = icmp ne i64 %v5701, 0
  %cv5703 = zext i1 %cmp5702 to i32
  store i32 %cv5703, ptr %slot1056, align 8
  %v5704 = load i32, ptr %slot1056, align 8
  %cv5705 = zext i32 %v5704 to i64
  %cond5706 = icmp ne i64 %cv5705, 0
  br i1 %cond5706, label %bb_rcmoveslow1330, label %bb_rcmovenext1341
bb_rcmovenext1341:
  %v5707 = load i64, ptr %slot1040, align 8
  %v5708 = load i64, ptr %slot1041, align 8
  %p5709 = inttoptr i64 %v5707 to ptr
  %p5710 = inttoptr i64 %v5708 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5710, ptr %p5709, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot1040, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i64 0, ptr %p5712, align 8, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot1040, align 8
  %op5714 = add i64 %v5713, 8
  store i64 %op5714, ptr %slot1057, align 8
  %v5715 = load i64, ptr %slot1057, align 8
  %p5716 = inttoptr i64 %v5715 to ptr
  store i64 0, ptr %p5716, align 8, !alias.scope !3, !noalias !4
  %v5717 = load i64, ptr %slot1040, align 8
  %op5718 = add i64 %v5717, 16
  store i64 %op5718, ptr %slot1058, align 8
  %v5719 = load i64, ptr %slot1058, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  store i64 0, ptr %p5720, align 8, !alias.scope !3, !noalias !4
  %v5721 = load i64, ptr %slot1040, align 8
  %op5722 = add i64 %v5721, 24
  store i64 %op5722, ptr %slot1059, align 8
  %v5723 = load i64, ptr %slot1059, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  store i64 0, ptr %p5724, align 8, !alias.scope !3, !noalias !4
  %v5725 = load i64, ptr %slot1040, align 8
  %op5726 = add i64 %v5725, 32
  store i64 %op5726, ptr %slot1060, align 8
  %v5727 = load i64, ptr %slot1060, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  store i64 0, ptr %p5728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1330
bb_rcmoveslow1330:
  %v5729 = load i64, ptr %slot56, align 8
  %v5730 = load i64, ptr %slot1041, align 8
  %v5731 = load i64, ptr %slot1040, align 8
  %v5732 = load i64, ptr %slot1042, align 8
  %cv5733 = trunc i64 %v5732 to i32
  %call5734 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v5729, i64 %v5730, i64 %v5731, i32 %cv5733) nomerge, !dbg !160
  store i32 %call5734, ptr %slot1061, align 8
  %v5735 = load i32, ptr %slot1061, align 8
  %cv5736 = zext i32 %v5735 to i64
  %cond5737 = icmp ne i64 %cv5736, 0
  br i1 %cond5737, label %bb_rcsuccess1352, label %bb_rcfailure1352
bb_rcfailure1352:
  %v5738 = load i64, ptr %slot56, align 8
  %p5739 = inttoptr i64 %v5738 to ptr
  %call5740 = call i32 @myl_rc_take_failure(ptr %p5739) nomerge, !dbg !160
  store i32 %call5740, ptr %slot1062, align 8
  %v5741 = load i64, ptr %slot1, align 8
  %p5742 = inttoptr i64 %v5741 to ptr
  %v5743 = load i32, ptr %slot1062, align 8
  %call5744 = call i32 @myl_qbe_rc_status(ptr %p5742, i32 %v5743) nomerge, !dbg !160
  store i32 %call5744, ptr %slot1063, align 8
  br label %bb_failure
bb_rcsuccess1352:
  br label %bb_rcmoved1330
bb_rcmoved1330:
  %v5745 = load i64, ptr %slot14, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  store i32 0, ptr %p5746, align 4, !alias.scope !3, !noalias !4
  %v5747 = load i64, ptr %slot23, align 8
  %p5748 = inttoptr i64 %v5747 to ptr
  store i32 2, ptr %p5748, align 4, !alias.scope !3, !noalias !4
  %v5749 = load i64, ptr %slot22, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  store i32 1, ptr %p5750, align 4, !alias.scope !3, !noalias !4
  %v5751 = load i64, ptr %slot34, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  %ld5753 = load i64, ptr %p5752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5753, ptr %slot1064, align 8
  %v5754 = load i64, ptr %slot56, align 8
  store i64 %v5754, ptr %slot1065, align 8
  %v5755 = load i64, ptr %slot1065, align 8
  %v5756 = load i64, ptr %slot1064, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5755, i64 %v5756) nomerge, !dbg !160
  %v5757 = load i64, ptr %slot31, align 8
  store i64 %v5757, ptr %slot1066, align 8
  %v5758 = load i64, ptr %slot1066, align 8
  %v5759 = load i64, ptr %slot1064, align 8
  %p5760 = inttoptr i64 %v5758 to ptr
  %p5761 = inttoptr i64 %v5759 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5761, ptr %p5760, i64 40, i1 false), !alias.scope !10000000
  %v5762 = load i64, ptr %slot22, align 8
  %p5763 = inttoptr i64 %v5762 to ptr
  store i32 0, ptr %p5763, align 4, !alias.scope !3, !noalias !4
  %v5764 = load i64, ptr %slot36, align 8
  %v5765 = load i64, ptr %slot41, align 8
  %p5766 = inttoptr i64 %v5765 to ptr
  store i64 %v5764, ptr %p5766, align 8, !alias.scope !3, !noalias !4
  %v5767 = load i64, ptr %slot41, align 8
  %p5768 = inttoptr i64 %v5767 to ptr
  %ld5769 = load i64, ptr %p5768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5769, ptr %slot1067, align 8
  %v5770 = load i64, ptr %slot1067, align 8
  %op5771 = add i64 %v5770, 96
  store i64 %op5771, ptr %slot1068, align 8
  %v5772 = load i64, ptr %slot1068, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  %ld5774 = load i8, ptr %p5773, align 1, !alias.scope !3, !noalias !4
  %ext5775 = zext i8 %ld5774 to i64
  store i64 %ext5775, ptr %slot1069, align 8
  %v5776 = load i64, ptr %slot1069, align 8
  %v5777 = load i64, ptr %slot41, align 8
  %p5778 = inttoptr i64 %v5777 to ptr
  store i64 %v5776, ptr %p5778, align 8, !alias.scope !3, !noalias !4
  %v5779 = load i64, ptr %slot14, align 8
  %p5780 = inttoptr i64 %v5779 to ptr
  %ld5781 = load i32, ptr %p5780, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5781, ptr %slot1070, align 8
  %v5782 = load i32, ptr %slot1070, align 8
  %cv5783 = zext i32 %v5782 to i64
  %cond5784 = icmp ne i64 %cv5783, 0
  br i1 %cond5784, label %bb_rcslotdrop1367, label %bb_rcslotdone1367
bb_rcslotdrop1367:
  %v5785 = load i64, ptr %slot14, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  store i32 0, ptr %p5786, align 4, !alias.scope !3, !noalias !4
  %v5787 = load i64, ptr %slot25, align 8
  store i64 %v5787, ptr %slot1071, align 8
  %v5788 = load i64, ptr %slot15, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  %ld5790 = load i32, ptr %p5789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5790, ptr %slot1072, align 8
  %v5791 = load i32, ptr %slot1072, align 8
  %op5792 = and i32 %v5791, 28
  store i32 %op5792, ptr %slot1073, align 8
  %v5793 = load i32, ptr %slot1073, align 8
  %cv5794 = zext i32 %v5793 to i64
  %cond5795 = icmp ne i64 %cv5794, 0
  br i1 %cond5795, label %bb_rcslotrole1367, label %bb_rcslotowner1367
bb_rcslotrole1367:
  %v5796 = load i64, ptr %slot56, align 8
  store i64 %v5796, ptr %slot1074, align 8
  %v5797 = load i64, ptr %slot1074, align 8
  %v5798 = load i64, ptr %slot1071, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v5797, i64 %v5798) nomerge, !dbg !162
  br label %bb_rcslotdone1367
bb_rcslotowner1367:
  %v5799 = load i64, ptr %slot56, align 8
  store i64 %v5799, ptr %slot1075, align 8
  %v5800 = load i64, ptr %slot1075, align 8
  %v5801 = load i64, ptr %slot1071, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v5800, i64 %v5801) nomerge, !dbg !162
  br label %bb_rcslotdone1367
bb_rcslotdone1367:
  %v5802 = load i64, ptr %slot41, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i64, ptr %p5803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5804, ptr %slot1076, align 8
  %v5805 = load i64, ptr %slot1076, align 8
  %op5806 = xor i64 %v5805, 1
  store i64 %op5806, ptr %slot1077, align 8
  %v5807 = load i64, ptr %slot1077, align 8
  %v5808 = load i64, ptr %slot41, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  store i64 %v5807, ptr %p5809, align 8, !alias.scope !3, !noalias !4
  %v5810 = load i64, ptr %slot41, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  %ld5812 = load i64, ptr %p5811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5812, ptr %slot1078, align 8
  %v5813 = load i64, ptr %slot14, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  %ld5815 = load i32, ptr %p5814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5815, ptr %slot1079, align 8
  %v5816 = load i32, ptr %slot1079, align 8
  %cv5817 = zext i32 %v5816 to i64
  %cond5818 = icmp ne i64 %cv5817, 0
  br i1 %cond5818, label %bb_rcslotdrop1379, label %bb_rcslotdone1379
bb_rcslotdrop1379:
  %v5819 = load i64, ptr %slot14, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  store i32 0, ptr %p5820, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1379
bb_rcslotdone1379:
  %v5821 = load i64, ptr %slot12, align 8
  %p5822 = inttoptr i64 %v5821 to ptr
  %ld5823 = load i32, ptr %p5822, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5823, ptr %slot1080, align 8
  %v5824 = load i32, ptr %slot1080, align 8
  %cv5825 = zext i32 %v5824 to i64
  %cond5826 = icmp ne i64 %cv5825, 0
  br i1 %cond5826, label %bb_rcslotdrop1382, label %bb_rcslotdone1382
bb_rcslotdrop1382:
  %v5827 = load i64, ptr %slot12, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  store i32 0, ptr %p5828, align 4, !alias.scope !3, !noalias !4
  %v5829 = load i64, ptr %slot39, align 8
  store i64 %v5829, ptr %slot1081, align 8
  %v5830 = load i64, ptr %slot13, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  %ld5832 = load i32, ptr %p5831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5832, ptr %slot1082, align 8
  %v5833 = load i32, ptr %slot1082, align 8
  %op5834 = and i32 %v5833, 28
  store i32 %op5834, ptr %slot1083, align 8
  %v5835 = load i32, ptr %slot1083, align 8
  %cv5836 = zext i32 %v5835 to i64
  %cond5837 = icmp ne i64 %cv5836, 0
  br i1 %cond5837, label %bb_rcslotrole1382, label %bb_rcslotowner1382
bb_rcslotrole1382:
  %v5838 = load i64, ptr %slot56, align 8
  store i64 %v5838, ptr %slot1084, align 8
  %v5839 = load i64, ptr %slot1081, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  %ld5841 = load i64, ptr %p5840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5841, ptr %slot1085, align 8
  %v5842 = load i64, ptr %slot1085, align 8
  %cmp5843 = icmp ne i64 %v5842, 0
  %cv5844 = zext i1 %cmp5843 to i32
  store i32 %cv5844, ptr %slot1086, align 8
  %v5845 = load i32, ptr %slot1086, align 8
  %cv5846 = zext i32 %v5845 to i64
  %cond5847 = icmp ne i64 %cv5846, 0
  br i1 %cond5847, label %bb_rcgnn1398, label %bb_rcgdone1398
bb_rcgnn1398:
  %v5848 = load i64, ptr %slot1085, align 8
  %op5849 = sub i64 %v5848, 16
  store i64 %op5849, ptr %slot1087, align 8
  %v5850 = load i64, ptr %slot1085, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  %rgep5852 = getelementptr i8, ptr %p5851, i64 -16
  %ld5853 = load i64, ptr %rgep5852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5853, ptr %slot1088, align 8
  %v5854 = load i64, ptr %slot1088, align 8
  %op5855 = and i64 %v5854, 4611686018427387906
  store i64 %op5855, ptr %slot1089, align 8
  %v5856 = load i64, ptr %slot1089, align 8
  %cmp5857 = icmp ne i64 %v5856, 0
  %cv5858 = zext i1 %cmp5857 to i32
  store i32 %cv5858, ptr %slot1090, align 8
  %v5859 = load i32, ptr %slot1090, align 8
  %cv5860 = zext i32 %v5859 to i64
  %cond5861 = icmp ne i64 %cv5860, 0
  br i1 %cond5861, label %bb_rcgclear1398, label %bb_rcgcounted1398
bb_rcgcounted1398:
  %v5862 = load i64, ptr %slot1085, align 8
  %op5863 = sub i64 %v5862, 24
  store i64 %op5863, ptr %slot1091, align 8
  %v5864 = load i64, ptr %slot1085, align 8
  %p5865 = inttoptr i64 %v5864 to ptr
  %rgep5866 = getelementptr i8, ptr %p5865, i64 -24
  %ld5867 = load i64, ptr %rgep5866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5867, ptr %slot1092, align 8
  %v5868 = load i64, ptr %slot1092, align 8
  %op5869 = sub i64 %v5868, 1
  store i64 %op5869, ptr %slot1093, align 8
  %v5870 = load i64, ptr %slot1093, align 8
  %cmp5871 = icmp eq i64 %v5870, 0
  %cv5872 = zext i1 %cmp5871 to i32
  store i32 %cv5872, ptr %slot1094, align 8
  %v5873 = load i32, ptr %slot1094, align 8
  %cv5874 = zext i32 %v5873 to i64
  %cond5875 = icmp ne i64 %cv5874, 0
  br i1 %cond5875, label %bb_rcglast1398, label %bb_rcgdec1398
bb_rcglast1398:
  %v5876 = load i64, ptr %slot1085, align 8
  %op5877 = sub i64 %v5876, 32
  store i64 %op5877, ptr %slot1095, align 8
  %v5878 = load i64, ptr %slot1085, align 8
  %p5879 = inttoptr i64 %v5878 to ptr
  %rgep5880 = getelementptr i8, ptr %p5879, i64 -32
  %ld5881 = load i64, ptr %rgep5880, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5881, ptr %slot1096, align 8
  %v5882 = load i64, ptr %slot1096, align 8
  %cmp5883 = icmp ne i64 %v5882, 0
  %cv5884 = zext i1 %cmp5883 to i32
  store i32 %cv5884, ptr %slot1097, align 8
  %v5885 = load i32, ptr %slot1097, align 8
  %cv5886 = zext i32 %v5885 to i64
  %cond5887 = icmp ne i64 %cv5886, 0
  br i1 %cond5887, label %bb_rcgdec1398, label %bb_rcgslow1398
bb_rcgslow1398:
  %v5888 = load i64, ptr %slot1084, align 8
  %v5889 = load i64, ptr %slot1081, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5888, i64 %v5889) nomerge, !dbg !164
  br label %bb_rcgdone1398
bb_rcgdec1398:
  %v5890 = load i64, ptr %slot1093, align 8
  %v5891 = load i64, ptr %slot1085, align 8
  %p5892 = inttoptr i64 %v5891 to ptr
  %rgep5893 = getelementptr i8, ptr %p5892, i64 -24
  store i64 %v5890, ptr %rgep5893, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1398
bb_rcgclear1398:
  %v5894 = load i64, ptr %slot1081, align 8
  %p5895 = inttoptr i64 %v5894 to ptr
  store i64 0, ptr %p5895, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1398
bb_rcgdone1398:
  br label %bb_rcslotdone1382
bb_rcslotowner1382:
  %v5896 = load i64, ptr %slot56, align 8
  store i64 %v5896, ptr %slot1098, align 8
  %v5897 = load i64, ptr %slot1081, align 8
  %p5898 = inttoptr i64 %v5897 to ptr
  %ld5899 = load i64, ptr %p5898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5899, ptr %slot1099, align 8
  %v5900 = load i64, ptr %slot1099, align 8
  %cmp5901 = icmp ne i64 %v5900, 0
  %cv5902 = zext i1 %cmp5901 to i32
  store i32 %cv5902, ptr %slot1100, align 8
  %v5903 = load i32, ptr %slot1100, align 8
  %cv5904 = zext i32 %v5903 to i64
  %cond5905 = icmp ne i64 %cv5904, 0
  br i1 %cond5905, label %bb_rcgnn1413, label %bb_rcgdone1413
bb_rcgnn1413:
  %v5906 = load i64, ptr %slot1099, align 8
  %op5907 = sub i64 %v5906, 16
  store i64 %op5907, ptr %slot1101, align 8
  %v5908 = load i64, ptr %slot1099, align 8
  %p5909 = inttoptr i64 %v5908 to ptr
  %rgep5910 = getelementptr i8, ptr %p5909, i64 -16
  %ld5911 = load i64, ptr %rgep5910, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5911, ptr %slot1102, align 8
  %v5912 = load i64, ptr %slot1102, align 8
  %op5913 = and i64 %v5912, 4611686018427387906
  store i64 %op5913, ptr %slot1103, align 8
  %v5914 = load i64, ptr %slot1103, align 8
  %cmp5915 = icmp ne i64 %v5914, 0
  %cv5916 = zext i1 %cmp5915 to i32
  store i32 %cv5916, ptr %slot1104, align 8
  %v5917 = load i32, ptr %slot1104, align 8
  %cv5918 = zext i32 %v5917 to i64
  %cond5919 = icmp ne i64 %cv5918, 0
  br i1 %cond5919, label %bb_rcgclear1413, label %bb_rcgcounted1413
bb_rcgcounted1413:
  %v5920 = load i64, ptr %slot1099, align 8
  %op5921 = sub i64 %v5920, 32
  store i64 %op5921, ptr %slot1105, align 8
  %v5922 = load i64, ptr %slot1099, align 8
  %p5923 = inttoptr i64 %v5922 to ptr
  %rgep5924 = getelementptr i8, ptr %p5923, i64 -32
  %ld5925 = load i64, ptr %rgep5924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5925, ptr %slot1106, align 8
  %v5926 = load i64, ptr %slot1106, align 8
  %op5927 = sub i64 %v5926, 1
  store i64 %op5927, ptr %slot1107, align 8
  %v5928 = load i64, ptr %slot1107, align 8
  %cmp5929 = icmp eq i64 %v5928, 0
  %cv5930 = zext i1 %cmp5929 to i32
  store i32 %cv5930, ptr %slot1108, align 8
  %v5931 = load i32, ptr %slot1108, align 8
  %cv5932 = zext i32 %v5931 to i64
  %cond5933 = icmp ne i64 %cv5932, 0
  br i1 %cond5933, label %bb_rcglast1413, label %bb_rcgdec1413
bb_rcglast1413:
  %v5934 = load i64, ptr %slot1099, align 8
  %op5935 = sub i64 %v5934, 24
  store i64 %op5935, ptr %slot1109, align 8
  %v5936 = load i64, ptr %slot1099, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  %rgep5938 = getelementptr i8, ptr %p5937, i64 -24
  %ld5939 = load i64, ptr %rgep5938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5939, ptr %slot1110, align 8
  %v5940 = load i64, ptr %slot1110, align 8
  %cmp5941 = icmp ne i64 %v5940, 0
  %cv5942 = zext i1 %cmp5941 to i32
  store i32 %cv5942, ptr %slot1111, align 8
  %v5943 = load i32, ptr %slot1111, align 8
  %cv5944 = zext i32 %v5943 to i64
  %cond5945 = icmp ne i64 %cv5944, 0
  br i1 %cond5945, label %bb_rcgdec1413, label %bb_rcgslow1413
bb_rcgslow1413:
  %v5946 = load i64, ptr %slot1098, align 8
  %v5947 = load i64, ptr %slot1081, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5946, i64 %v5947) nomerge, !dbg !164
  br label %bb_rcgdone1413
bb_rcgdec1413:
  %v5948 = load i64, ptr %slot1107, align 8
  %v5949 = load i64, ptr %slot1099, align 8
  %p5950 = inttoptr i64 %v5949 to ptr
  %rgep5951 = getelementptr i8, ptr %p5950, i64 -32
  store i64 %v5948, ptr %rgep5951, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1413
bb_rcgclear1413:
  %v5952 = load i64, ptr %slot1081, align 8
  %p5953 = inttoptr i64 %v5952 to ptr
  store i64 0, ptr %p5953, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1413
bb_rcgdone1413:
  br label %bb_rcslotdone1382
bb_rcslotdone1382:
  %v5954 = load i64, ptr %slot10, align 8
  %p5955 = inttoptr i64 %v5954 to ptr
  %ld5956 = load i32, ptr %p5955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5956, ptr %slot1112, align 8
  %v5957 = load i32, ptr %slot1112, align 8
  %cv5958 = zext i32 %v5957 to i64
  %cond5959 = icmp ne i64 %cv5958, 0
  br i1 %cond5959, label %bb_rcslotdrop1419, label %bb_rcslotdone1419
bb_rcslotdrop1419:
  %v5960 = load i64, ptr %slot10, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  store i32 0, ptr %p5961, align 4, !alias.scope !3, !noalias !4
  %v5962 = load i64, ptr %slot38, align 8
  store i64 %v5962, ptr %slot1113, align 8
  %v5963 = load i64, ptr %slot11, align 8
  %p5964 = inttoptr i64 %v5963 to ptr
  %ld5965 = load i32, ptr %p5964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5965, ptr %slot1114, align 8
  %v5966 = load i32, ptr %slot1114, align 8
  %op5967 = and i32 %v5966, 28
  store i32 %op5967, ptr %slot1115, align 8
  %v5968 = load i32, ptr %slot1115, align 8
  %cv5969 = zext i32 %v5968 to i64
  %cond5970 = icmp ne i64 %cv5969, 0
  br i1 %cond5970, label %bb_rcslotrole1419, label %bb_rcslotowner1419
bb_rcslotrole1419:
  %v5971 = load i64, ptr %slot56, align 8
  store i64 %v5971, ptr %slot1116, align 8
  %v5972 = load i64, ptr %slot1113, align 8
  %p5973 = inttoptr i64 %v5972 to ptr
  %ld5974 = load i64, ptr %p5973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5974, ptr %slot1117, align 8
  %v5975 = load i64, ptr %slot1117, align 8
  %cmp5976 = icmp ne i64 %v5975, 0
  %cv5977 = zext i1 %cmp5976 to i32
  store i32 %cv5977, ptr %slot1118, align 8
  %v5978 = load i32, ptr %slot1118, align 8
  %cv5979 = zext i32 %v5978 to i64
  %cond5980 = icmp ne i64 %cv5979, 0
  br i1 %cond5980, label %bb_rcgnn1435, label %bb_rcgdone1435
bb_rcgnn1435:
  %v5981 = load i64, ptr %slot1117, align 8
  %op5982 = sub i64 %v5981, 16
  store i64 %op5982, ptr %slot1119, align 8
  %v5983 = load i64, ptr %slot1117, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %rgep5985 = getelementptr i8, ptr %p5984, i64 -16
  %ld5986 = load i64, ptr %rgep5985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5986, ptr %slot1120, align 8
  %v5987 = load i64, ptr %slot1120, align 8
  %op5988 = and i64 %v5987, 4611686018427387906
  store i64 %op5988, ptr %slot1121, align 8
  %v5989 = load i64, ptr %slot1121, align 8
  %cmp5990 = icmp ne i64 %v5989, 0
  %cv5991 = zext i1 %cmp5990 to i32
  store i32 %cv5991, ptr %slot1122, align 8
  %v5992 = load i32, ptr %slot1122, align 8
  %cv5993 = zext i32 %v5992 to i64
  %cond5994 = icmp ne i64 %cv5993, 0
  br i1 %cond5994, label %bb_rcgclear1435, label %bb_rcgcounted1435
bb_rcgcounted1435:
  %v5995 = load i64, ptr %slot1117, align 8
  %op5996 = sub i64 %v5995, 24
  store i64 %op5996, ptr %slot1123, align 8
  %v5997 = load i64, ptr %slot1117, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %rgep5999 = getelementptr i8, ptr %p5998, i64 -24
  %ld6000 = load i64, ptr %rgep5999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6000, ptr %slot1124, align 8
  %v6001 = load i64, ptr %slot1124, align 8
  %op6002 = sub i64 %v6001, 1
  store i64 %op6002, ptr %slot1125, align 8
  %v6003 = load i64, ptr %slot1125, align 8
  %cmp6004 = icmp eq i64 %v6003, 0
  %cv6005 = zext i1 %cmp6004 to i32
  store i32 %cv6005, ptr %slot1126, align 8
  %v6006 = load i32, ptr %slot1126, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcglast1435, label %bb_rcgdec1435
bb_rcglast1435:
  %v6009 = load i64, ptr %slot1117, align 8
  %op6010 = sub i64 %v6009, 32
  store i64 %op6010, ptr %slot1127, align 8
  %v6011 = load i64, ptr %slot1117, align 8
  %p6012 = inttoptr i64 %v6011 to ptr
  %rgep6013 = getelementptr i8, ptr %p6012, i64 -32
  %ld6014 = load i64, ptr %rgep6013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6014, ptr %slot1128, align 8
  %v6015 = load i64, ptr %slot1128, align 8
  %cmp6016 = icmp ne i64 %v6015, 0
  %cv6017 = zext i1 %cmp6016 to i32
  store i32 %cv6017, ptr %slot1129, align 8
  %v6018 = load i32, ptr %slot1129, align 8
  %cv6019 = zext i32 %v6018 to i64
  %cond6020 = icmp ne i64 %cv6019, 0
  br i1 %cond6020, label %bb_rcgdec1435, label %bb_rcgslow1435
bb_rcgslow1435:
  %v6021 = load i64, ptr %slot1116, align 8
  %v6022 = load i64, ptr %slot1113, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v6021, i64 %v6022) nomerge, !dbg !164
  br label %bb_rcgdone1435
bb_rcgdec1435:
  %v6023 = load i64, ptr %slot1125, align 8
  %v6024 = load i64, ptr %slot1117, align 8
  %p6025 = inttoptr i64 %v6024 to ptr
  %rgep6026 = getelementptr i8, ptr %p6025, i64 -24
  store i64 %v6023, ptr %rgep6026, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1435
bb_rcgclear1435:
  %v6027 = load i64, ptr %slot1113, align 8
  %p6028 = inttoptr i64 %v6027 to ptr
  store i64 0, ptr %p6028, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1435
bb_rcgdone1435:
  br label %bb_rcslotdone1419
bb_rcslotowner1419:
  %v6029 = load i64, ptr %slot56, align 8
  store i64 %v6029, ptr %slot1130, align 8
  %v6030 = load i64, ptr %slot1113, align 8
  %p6031 = inttoptr i64 %v6030 to ptr
  %ld6032 = load i64, ptr %p6031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6032, ptr %slot1131, align 8
  %v6033 = load i64, ptr %slot1131, align 8
  %cmp6034 = icmp ne i64 %v6033, 0
  %cv6035 = zext i1 %cmp6034 to i32
  store i32 %cv6035, ptr %slot1132, align 8
  %v6036 = load i32, ptr %slot1132, align 8
  %cv6037 = zext i32 %v6036 to i64
  %cond6038 = icmp ne i64 %cv6037, 0
  br i1 %cond6038, label %bb_rcgnn1450, label %bb_rcgdone1450
bb_rcgnn1450:
  %v6039 = load i64, ptr %slot1131, align 8
  %op6040 = sub i64 %v6039, 16
  store i64 %op6040, ptr %slot1133, align 8
  %v6041 = load i64, ptr %slot1131, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  %rgep6043 = getelementptr i8, ptr %p6042, i64 -16
  %ld6044 = load i64, ptr %rgep6043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6044, ptr %slot1134, align 8
  %v6045 = load i64, ptr %slot1134, align 8
  %op6046 = and i64 %v6045, 4611686018427387906
  store i64 %op6046, ptr %slot1135, align 8
  %v6047 = load i64, ptr %slot1135, align 8
  %cmp6048 = icmp ne i64 %v6047, 0
  %cv6049 = zext i1 %cmp6048 to i32
  store i32 %cv6049, ptr %slot1136, align 8
  %v6050 = load i32, ptr %slot1136, align 8
  %cv6051 = zext i32 %v6050 to i64
  %cond6052 = icmp ne i64 %cv6051, 0
  br i1 %cond6052, label %bb_rcgclear1450, label %bb_rcgcounted1450
bb_rcgcounted1450:
  %v6053 = load i64, ptr %slot1131, align 8
  %op6054 = sub i64 %v6053, 32
  store i64 %op6054, ptr %slot1137, align 8
  %v6055 = load i64, ptr %slot1131, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  %rgep6057 = getelementptr i8, ptr %p6056, i64 -32
  %ld6058 = load i64, ptr %rgep6057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6058, ptr %slot1138, align 8
  %v6059 = load i64, ptr %slot1138, align 8
  %op6060 = sub i64 %v6059, 1
  store i64 %op6060, ptr %slot1139, align 8
  %v6061 = load i64, ptr %slot1139, align 8
  %cmp6062 = icmp eq i64 %v6061, 0
  %cv6063 = zext i1 %cmp6062 to i32
  store i32 %cv6063, ptr %slot1140, align 8
  %v6064 = load i32, ptr %slot1140, align 8
  %cv6065 = zext i32 %v6064 to i64
  %cond6066 = icmp ne i64 %cv6065, 0
  br i1 %cond6066, label %bb_rcglast1450, label %bb_rcgdec1450
bb_rcglast1450:
  %v6067 = load i64, ptr %slot1131, align 8
  %op6068 = sub i64 %v6067, 24
  store i64 %op6068, ptr %slot1141, align 8
  %v6069 = load i64, ptr %slot1131, align 8
  %p6070 = inttoptr i64 %v6069 to ptr
  %rgep6071 = getelementptr i8, ptr %p6070, i64 -24
  %ld6072 = load i64, ptr %rgep6071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6072, ptr %slot1142, align 8
  %v6073 = load i64, ptr %slot1142, align 8
  %cmp6074 = icmp ne i64 %v6073, 0
  %cv6075 = zext i1 %cmp6074 to i32
  store i32 %cv6075, ptr %slot1143, align 8
  %v6076 = load i32, ptr %slot1143, align 8
  %cv6077 = zext i32 %v6076 to i64
  %cond6078 = icmp ne i64 %cv6077, 0
  br i1 %cond6078, label %bb_rcgdec1450, label %bb_rcgslow1450
bb_rcgslow1450:
  %v6079 = load i64, ptr %slot1130, align 8
  %v6080 = load i64, ptr %slot1113, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v6079, i64 %v6080) nomerge, !dbg !164
  br label %bb_rcgdone1450
bb_rcgdec1450:
  %v6081 = load i64, ptr %slot1139, align 8
  %v6082 = load i64, ptr %slot1131, align 8
  %p6083 = inttoptr i64 %v6082 to ptr
  %rgep6084 = getelementptr i8, ptr %p6083, i64 -32
  store i64 %v6081, ptr %rgep6084, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1450
bb_rcgclear1450:
  %v6085 = load i64, ptr %slot1113, align 8
  %p6086 = inttoptr i64 %v6085 to ptr
  store i64 0, ptr %p6086, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1450
bb_rcgdone1450:
  br label %bb_rcslotdone1419
bb_rcslotdone1419:
  %v6087 = load i64, ptr %slot8, align 8
  %p6088 = inttoptr i64 %v6087 to ptr
  %ld6089 = load i32, ptr %p6088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6089, ptr %slot1144, align 8
  %v6090 = load i32, ptr %slot1144, align 8
  %cv6091 = zext i32 %v6090 to i64
  %cond6092 = icmp ne i64 %cv6091, 0
  br i1 %cond6092, label %bb_rcslotdrop1456, label %bb_rcslotdone1456
bb_rcslotdrop1456:
  %v6093 = load i64, ptr %slot8, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  store i32 0, ptr %p6094, align 4, !alias.scope !3, !noalias !4
  %v6095 = load i64, ptr %slot36, align 8
  store i64 %v6095, ptr %slot1145, align 8
  %v6096 = load i64, ptr %slot9, align 8
  %p6097 = inttoptr i64 %v6096 to ptr
  %ld6098 = load i32, ptr %p6097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6098, ptr %slot1146, align 8
  %v6099 = load i32, ptr %slot1146, align 8
  %op6100 = and i32 %v6099, 28
  store i32 %op6100, ptr %slot1147, align 8
  %v6101 = load i32, ptr %slot1147, align 8
  %cv6102 = zext i32 %v6101 to i64
  %cond6103 = icmp ne i64 %cv6102, 0
  br i1 %cond6103, label %bb_rcslotrole1456, label %bb_rcslotowner1456
bb_rcslotrole1456:
  %v6104 = load i64, ptr %slot56, align 8
  store i64 %v6104, ptr %slot1148, align 8
  %v6105 = load i64, ptr %slot1148, align 8
  %v6106 = load i64, ptr %slot1145, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v6105, i64 %v6106) nomerge, !dbg !164
  br label %bb_rcslotdone1456
bb_rcslotowner1456:
  %v6107 = load i64, ptr %slot56, align 8
  store i64 %v6107, ptr %slot1149, align 8
  %v6108 = load i64, ptr %slot1149, align 8
  %v6109 = load i64, ptr %slot1145, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v6108, i64 %v6109) nomerge, !dbg !164
  br label %bb_rcslotdone1456
bb_rcslotdone1456:
  %v6110 = load i64, ptr %slot6, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  %ld6112 = load i32, ptr %p6111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6112, ptr %slot1150, align 8
  %v6113 = load i32, ptr %slot1150, align 8
  %cv6114 = zext i32 %v6113 to i64
  %cond6115 = icmp ne i64 %cv6114, 0
  br i1 %cond6115, label %bb_rcslotdrop1465, label %bb_rcslotdone1465
bb_rcslotdrop1465:
  %v6116 = load i64, ptr %slot6, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  store i32 0, ptr %p6117, align 4, !alias.scope !3, !noalias !4
  %v6118 = load i64, ptr %slot35, align 8
  store i64 %v6118, ptr %slot1151, align 8
  %v6119 = load i64, ptr %slot7, align 8
  %p6120 = inttoptr i64 %v6119 to ptr
  %ld6121 = load i32, ptr %p6120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6121, ptr %slot1152, align 8
  %v6122 = load i32, ptr %slot1152, align 8
  %op6123 = and i32 %v6122, 28
  store i32 %op6123, ptr %slot1153, align 8
  %v6124 = load i32, ptr %slot1153, align 8
  %cv6125 = zext i32 %v6124 to i64
  %cond6126 = icmp ne i64 %cv6125, 0
  br i1 %cond6126, label %bb_rcslotrole1465, label %bb_rcslotowner1465
bb_rcslotrole1465:
  %v6127 = load i64, ptr %slot56, align 8
  store i64 %v6127, ptr %slot1154, align 8
  %v6128 = load i64, ptr %slot1151, align 8
  %p6129 = inttoptr i64 %v6128 to ptr
  %ld6130 = load i64, ptr %p6129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6130, ptr %slot1155, align 8
  %v6131 = load i64, ptr %slot1155, align 8
  %cmp6132 = icmp ne i64 %v6131, 0
  %cv6133 = zext i1 %cmp6132 to i32
  store i32 %cv6133, ptr %slot1156, align 8
  %v6134 = load i32, ptr %slot1156, align 8
  %cv6135 = zext i32 %v6134 to i64
  %cond6136 = icmp ne i64 %cv6135, 0
  br i1 %cond6136, label %bb_rcgnn1481, label %bb_rcgdone1481
bb_rcgnn1481:
  %v6137 = load i64, ptr %slot1155, align 8
  %op6138 = sub i64 %v6137, 16
  store i64 %op6138, ptr %slot1157, align 8
  %v6139 = load i64, ptr %slot1155, align 8
  %p6140 = inttoptr i64 %v6139 to ptr
  %rgep6141 = getelementptr i8, ptr %p6140, i64 -16
  %ld6142 = load i64, ptr %rgep6141, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6142, ptr %slot1158, align 8
  %v6143 = load i64, ptr %slot1158, align 8
  %op6144 = and i64 %v6143, 4611686018427387906
  store i64 %op6144, ptr %slot1159, align 8
  %v6145 = load i64, ptr %slot1159, align 8
  %cmp6146 = icmp ne i64 %v6145, 0
  %cv6147 = zext i1 %cmp6146 to i32
  store i32 %cv6147, ptr %slot1160, align 8
  %v6148 = load i32, ptr %slot1160, align 8
  %cv6149 = zext i32 %v6148 to i64
  %cond6150 = icmp ne i64 %cv6149, 0
  br i1 %cond6150, label %bb_rcgclear1481, label %bb_rcgcounted1481
bb_rcgcounted1481:
  %v6151 = load i64, ptr %slot1155, align 8
  %op6152 = sub i64 %v6151, 24
  store i64 %op6152, ptr %slot1161, align 8
  %v6153 = load i64, ptr %slot1155, align 8
  %p6154 = inttoptr i64 %v6153 to ptr
  %rgep6155 = getelementptr i8, ptr %p6154, i64 -24
  %ld6156 = load i64, ptr %rgep6155, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6156, ptr %slot1162, align 8
  %v6157 = load i64, ptr %slot1162, align 8
  %op6158 = sub i64 %v6157, 1
  store i64 %op6158, ptr %slot1163, align 8
  %v6159 = load i64, ptr %slot1163, align 8
  %cmp6160 = icmp eq i64 %v6159, 0
  %cv6161 = zext i1 %cmp6160 to i32
  store i32 %cv6161, ptr %slot1164, align 8
  %v6162 = load i32, ptr %slot1164, align 8
  %cv6163 = zext i32 %v6162 to i64
  %cond6164 = icmp ne i64 %cv6163, 0
  br i1 %cond6164, label %bb_rcglast1481, label %bb_rcgdec1481
bb_rcglast1481:
  %v6165 = load i64, ptr %slot1155, align 8
  %op6166 = sub i64 %v6165, 32
  store i64 %op6166, ptr %slot1165, align 8
  %v6167 = load i64, ptr %slot1155, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  %rgep6169 = getelementptr i8, ptr %p6168, i64 -32
  %ld6170 = load i64, ptr %rgep6169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6170, ptr %slot1166, align 8
  %v6171 = load i64, ptr %slot1166, align 8
  %cmp6172 = icmp ne i64 %v6171, 0
  %cv6173 = zext i1 %cmp6172 to i32
  store i32 %cv6173, ptr %slot1167, align 8
  %v6174 = load i32, ptr %slot1167, align 8
  %cv6175 = zext i32 %v6174 to i64
  %cond6176 = icmp ne i64 %cv6175, 0
  br i1 %cond6176, label %bb_rcgdec1481, label %bb_rcgslow1481
bb_rcgslow1481:
  %v6177 = load i64, ptr %slot1154, align 8
  %v6178 = load i64, ptr %slot1151, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v6177, i64 %v6178) nomerge, !dbg !164
  br label %bb_rcgdone1481
bb_rcgdec1481:
  %v6179 = load i64, ptr %slot1163, align 8
  %v6180 = load i64, ptr %slot1155, align 8
  %p6181 = inttoptr i64 %v6180 to ptr
  %rgep6182 = getelementptr i8, ptr %p6181, i64 -24
  store i64 %v6179, ptr %rgep6182, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1481
bb_rcgclear1481:
  %v6183 = load i64, ptr %slot1151, align 8
  %p6184 = inttoptr i64 %v6183 to ptr
  store i64 0, ptr %p6184, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1481
bb_rcgdone1481:
  br label %bb_rcslotdone1465
bb_rcslotowner1465:
  %v6185 = load i64, ptr %slot56, align 8
  store i64 %v6185, ptr %slot1168, align 8
  %v6186 = load i64, ptr %slot1151, align 8
  %p6187 = inttoptr i64 %v6186 to ptr
  %ld6188 = load i64, ptr %p6187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6188, ptr %slot1169, align 8
  %v6189 = load i64, ptr %slot1169, align 8
  %cmp6190 = icmp ne i64 %v6189, 0
  %cv6191 = zext i1 %cmp6190 to i32
  store i32 %cv6191, ptr %slot1170, align 8
  %v6192 = load i32, ptr %slot1170, align 8
  %cv6193 = zext i32 %v6192 to i64
  %cond6194 = icmp ne i64 %cv6193, 0
  br i1 %cond6194, label %bb_rcgnn1496, label %bb_rcgdone1496
bb_rcgnn1496:
  %v6195 = load i64, ptr %slot1169, align 8
  %op6196 = sub i64 %v6195, 16
  store i64 %op6196, ptr %slot1171, align 8
  %v6197 = load i64, ptr %slot1169, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  %rgep6199 = getelementptr i8, ptr %p6198, i64 -16
  %ld6200 = load i64, ptr %rgep6199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6200, ptr %slot1172, align 8
  %v6201 = load i64, ptr %slot1172, align 8
  %op6202 = and i64 %v6201, 4611686018427387906
  store i64 %op6202, ptr %slot1173, align 8
  %v6203 = load i64, ptr %slot1173, align 8
  %cmp6204 = icmp ne i64 %v6203, 0
  %cv6205 = zext i1 %cmp6204 to i32
  store i32 %cv6205, ptr %slot1174, align 8
  %v6206 = load i32, ptr %slot1174, align 8
  %cv6207 = zext i32 %v6206 to i64
  %cond6208 = icmp ne i64 %cv6207, 0
  br i1 %cond6208, label %bb_rcgclear1496, label %bb_rcgcounted1496
bb_rcgcounted1496:
  %v6209 = load i64, ptr %slot1169, align 8
  %op6210 = sub i64 %v6209, 32
  store i64 %op6210, ptr %slot1175, align 8
  %v6211 = load i64, ptr %slot1169, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %rgep6213 = getelementptr i8, ptr %p6212, i64 -32
  %ld6214 = load i64, ptr %rgep6213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6214, ptr %slot1176, align 8
  %v6215 = load i64, ptr %slot1176, align 8
  %op6216 = sub i64 %v6215, 1
  store i64 %op6216, ptr %slot1177, align 8
  %v6217 = load i64, ptr %slot1177, align 8
  %cmp6218 = icmp eq i64 %v6217, 0
  %cv6219 = zext i1 %cmp6218 to i32
  store i32 %cv6219, ptr %slot1178, align 8
  %v6220 = load i32, ptr %slot1178, align 8
  %cv6221 = zext i32 %v6220 to i64
  %cond6222 = icmp ne i64 %cv6221, 0
  br i1 %cond6222, label %bb_rcglast1496, label %bb_rcgdec1496
bb_rcglast1496:
  %v6223 = load i64, ptr %slot1169, align 8
  %op6224 = sub i64 %v6223, 24
  store i64 %op6224, ptr %slot1179, align 8
  %v6225 = load i64, ptr %slot1169, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  %rgep6227 = getelementptr i8, ptr %p6226, i64 -24
  %ld6228 = load i64, ptr %rgep6227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6228, ptr %slot1180, align 8
  %v6229 = load i64, ptr %slot1180, align 8
  %cmp6230 = icmp ne i64 %v6229, 0
  %cv6231 = zext i1 %cmp6230 to i32
  store i32 %cv6231, ptr %slot1181, align 8
  %v6232 = load i32, ptr %slot1181, align 8
  %cv6233 = zext i32 %v6232 to i64
  %cond6234 = icmp ne i64 %cv6233, 0
  br i1 %cond6234, label %bb_rcgdec1496, label %bb_rcgslow1496
bb_rcgslow1496:
  %v6235 = load i64, ptr %slot1168, align 8
  %v6236 = load i64, ptr %slot1151, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v6235, i64 %v6236) nomerge, !dbg !164
  br label %bb_rcgdone1496
bb_rcgdec1496:
  %v6237 = load i64, ptr %slot1177, align 8
  %v6238 = load i64, ptr %slot1169, align 8
  %p6239 = inttoptr i64 %v6238 to ptr
  %rgep6240 = getelementptr i8, ptr %p6239, i64 -32
  store i64 %v6237, ptr %rgep6240, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1496
bb_rcgclear1496:
  %v6241 = load i64, ptr %slot1151, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  store i64 0, ptr %p6242, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1496
bb_rcgdone1496:
  br label %bb_rcslotdone1465
bb_rcslotdone1465:
  %v6243 = load i64, ptr %slot1078, align 8
  ret i64 %v6243
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_cb8ba6198d12c121b91c6eca86ed4537aaff0ed5acaf8eda6f904a4b0d563a06(i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64, i64)
declare i32 @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64, i64)
declare void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64, i64, i64, i32)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64, i64, i64, i32)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)
declare void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3f354089d660f4f153892cc6f2e06745b475cc4eec898367a6e41272f23dcd56", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3f354089d660f4f153892cc6f2e06745b475cc4eec898367a6e41272f23dcd56", linkageName: "myl_f_3f354089d660f4f153892cc6f2e06745b475cc4eec898367a6e41272f23dcd56", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9933161476313238838, i64 0, !"myl_f_3f354089d660f4f153892cc6f2e06745b475cc4eec898367a6e41272f23dcd56"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!122 = !DILocation(line: 14, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!130 = !DILocation(line: 22, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!136 = !DILocation(line: 30, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!138 = !DILocation(line: 31, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!140 = !DILocation(line: 39, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!142 = !DILocation(line: 41, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!144 = !DILocation(line: 44, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!146 = !DILocation(line: 45, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!148 = !DILocation(line: 49, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!150 = !DILocation(line: 53, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!152 = !DILocation(line: 54, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!154 = !DILocation(line: 55, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!156 = !DILocation(line: 57, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!158 = !DILocation(line: 58, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!160 = !DILocation(line: 59, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!162 = !DILocation(line: 61, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!164 = !DILocation(line: 63, column: 0, scope: !165)
