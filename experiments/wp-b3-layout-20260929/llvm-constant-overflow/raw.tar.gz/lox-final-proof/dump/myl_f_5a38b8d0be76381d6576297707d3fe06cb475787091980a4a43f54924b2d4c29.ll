target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %callresult15 = alloca [40 x i8], align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v25 = load i64, ptr %slot1, align 8
  %op26 = add i64 %v25, 32
  store i64 %op26, ptr %slot3, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot4, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot5, align 8
  %mem31 = alloca i8, i64 8, align 8
  %ptr32 = ptrtoint ptr %mem31 to i64
  store i64 %ptr32, ptr %slot6, align 8
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot7, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot8, align 8
  %v37 = load i64, ptr %slot1, align 8
  %op38 = add i64 %v37, 64
  store i64 %op38, ptr %slot9, align 8
  %v39 = load i64, ptr %slot9, align 8
  %p40 = inttoptr i64 %v39 to ptr
  %ld41 = load i64, ptr %p40, align 8, !alias.scope !4, !noalias !3
  store i64 %ld41, ptr %slot10, align 8
  %stack42 = call ptr @llvm.stacksave()
  %stackaddr43 = ptrtoint ptr %stack42 to i64
  %v44 = load i64, ptr %slot10, align 8
  %cmp45 = icmp ult i64 %stackaddr43, %v44
  %cv46 = zext i1 %cmp45 to i64
  store i64 %cv46, ptr %slot11, align 8
  %v47 = load i64, ptr %slot11, align 8
  %cond48 = icmp ne i64 %v47, 0
  br i1 %cond48, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v49 = load i64, ptr %slot1, align 8
  %p50 = inttoptr i64 %v49 to ptr
  call void @myl_qbe_fail_frame(ptr %p50) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v51 = load i64, ptr %slot2, align 8
  %v52 = load i64, ptr %slot4, align 8
  %p53 = inttoptr i64 %v52 to ptr
  store i64 %v51, ptr %p53, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v54 = load i64, ptr %slot4, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !3, !noalias !4
  store i64 %ld56, ptr %slot12, align 8
  %v57 = load i64, ptr %slot12, align 8
  %v58 = load i64, ptr %slot5, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot5, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %ld62 = load i64, ptr %p61, align 8, !alias.scope !3, !noalias !4
  store i64 %ld62, ptr %slot13, align 8
  %v63 = load i64, ptr %slot1, align 8
  %v64 = load i64, ptr %slot13, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult15, i64 %v63, i64 %v64) nomerge, !dbg !112
  %addr65 = ptrtoint ptr %callresult15 to i64
  store i64 %addr65, ptr %slot14, align 8
  %v66 = load i64, ptr %slot14, align 8
  %v67 = load i64, ptr %slot5, align 8
  %p68 = inttoptr i64 %v67 to ptr
  store i64 %v66, ptr %p68, align 8, !alias.scope !3, !noalias !4
  %v69 = load i64, ptr %slot5, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !3, !noalias !4
  store i64 %ld71, ptr %slot16, align 8
  %v72 = load i64, ptr %slot16, align 8
  %op73 = add i64 %v72, 0
  store i64 %op73, ptr %slot17, align 8
  %v74 = load i64, ptr %slot17, align 8
  %v75 = load i64, ptr %slot5, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot7, align 8
  store i64 %v77, ptr %slot18, align 8
  %v78 = load i64, ptr %slot18, align 8
  %p79 = inttoptr i64 %v78 to ptr
  store i32 0, ptr %p79, align 4, !alias.scope !3, !noalias !4
  %v80 = load i64, ptr %slot18, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i32 39, ptr %p81, align 4, !alias.scope !3, !noalias !4
  %v82 = load i64, ptr %slot18, align 8
  %v83 = load i64, ptr %slot6, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 %v82, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot6, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot19, align 8
  %v88 = load i64, ptr %slot5, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot20, align 8
  %v91 = load i64, ptr %slot20, align 8
  %p92 = inttoptr i64 %v91 to ptr
  %ld93 = load i32, ptr %p92, align 4
  %ext94 = zext i32 %ld93 to i64
  store i64 %ext94, ptr %slot21, align 8
  %v95 = load i64, ptr %slot19, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i32, ptr %p96, align 4, !alias.scope !3, !noalias !4
  %ext98 = zext i32 %ld97 to i64
  store i64 %ext98, ptr %slot22, align 8
  %v99 = load i64, ptr %slot21, align 8
  %v100 = load i64, ptr %slot22, align 8
  %cmp101 = icmp eq i64 %v99, %v100
  %cv102 = zext i1 %cmp101 to i64
  store i64 %cv102, ptr %slot23, align 8
  %v103 = load i64, ptr %slot23, align 8
  %v104 = load i64, ptr %slot5, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 %v103, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot5, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld108, ptr %slot24, align 8
  %v109 = load i64, ptr %slot24, align 8
  ret i64 %v109
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29", linkageName: "myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6852491287494347102, i64 0, !"myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
