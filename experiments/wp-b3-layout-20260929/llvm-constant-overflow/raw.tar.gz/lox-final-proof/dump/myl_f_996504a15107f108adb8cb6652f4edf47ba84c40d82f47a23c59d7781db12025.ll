target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %callresult181 = alloca [80 x i8], align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %callresult213 = alloca [80 x i8], align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %callresult245 = alloca [80 x i8], align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %callresult277 = alloca [80 x i8], align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %callresult309 = alloca [80 x i8], align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %callresult341 = alloca [80 x i8], align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %callresult373 = alloca [80 x i8], align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %callresult405 = alloca [80 x i8], align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v431 = load i64, ptr %slot1, align 8
  %op432 = add i64 %v431, 32
  store i64 %op432, ptr %slot4, align 8
  %mem433 = alloca i8, i64 80, align 8
  %ptr434 = ptrtoint ptr %mem433 to i64
  store i64 %ptr434, ptr %slot5, align 8
  %mem435 = alloca i8, i64 8, align 8
  %ptr436 = ptrtoint ptr %mem435 to i64
  store i64 %ptr436, ptr %slot6, align 8
  %mem437 = alloca i8, i64 8, align 8
  %ptr438 = ptrtoint ptr %mem437 to i64
  store i64 %ptr438, ptr %slot7, align 8
  %mem439 = alloca i8, i64 8, align 8
  %ptr440 = ptrtoint ptr %mem439 to i64
  store i64 %ptr440, ptr %slot8, align 8
  %mem441 = alloca i8, i64 8, align 8
  %ptr442 = ptrtoint ptr %mem441 to i64
  store i64 %ptr442, ptr %slot9, align 8
  %mem443 = alloca i8, i64 104, align 8
  %ptr444 = ptrtoint ptr %mem443 to i64
  store i64 %ptr444, ptr %slot10, align 8
  %mem445 = alloca i8, i64 104, align 8
  %ptr446 = ptrtoint ptr %mem445 to i64
  store i64 %ptr446, ptr %slot11, align 8
  %mem447 = alloca i8, i64 8, align 8
  %ptr448 = ptrtoint ptr %mem447 to i64
  store i64 %ptr448, ptr %slot12, align 8
  %mem449 = alloca i8, i64 8, align 8
  %ptr450 = ptrtoint ptr %mem449 to i64
  store i64 %ptr450, ptr %slot13, align 8
  %mem451 = alloca i8, i64 8, align 8
  %ptr452 = ptrtoint ptr %mem451 to i64
  store i64 %ptr452, ptr %slot14, align 8
  %mem453 = alloca i8, i64 8, align 8
  %ptr454 = ptrtoint ptr %mem453 to i64
  store i64 %ptr454, ptr %slot15, align 8
  %mem455 = alloca i8, i64 80, align 8
  %ptr456 = ptrtoint ptr %mem455 to i64
  store i64 %ptr456, ptr %slot16, align 8
  %mem457 = alloca i8, i64 8, align 8
  %ptr458 = ptrtoint ptr %mem457 to i64
  store i64 %ptr458, ptr %slot17, align 8
  %mem459 = alloca i8, i64 8, align 8
  %ptr460 = ptrtoint ptr %mem459 to i64
  store i64 %ptr460, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem461 = alloca i8, i64 8, align 8
  %ptr462 = ptrtoint ptr %mem461 to i64
  store i64 %ptr462, ptr %slot19, align 8
  %v463 = load i64, ptr %slot1, align 8
  %op464 = add i64 %v463, 64
  store i64 %op464, ptr %slot20, align 8
  %v465 = load i64, ptr %slot20, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %ld467 = load i64, ptr %p466, align 8, !alias.scope !4, !noalias !3
  store i64 %ld467, ptr %slot21, align 8
  %stack468 = call ptr @llvm.stacksave()
  %stackaddr469 = ptrtoint ptr %stack468 to i64
  %v470 = load i64, ptr %slot21, align 8
  %cmp471 = icmp ult i64 %stackaddr469, %v470
  %cv472 = zext i1 %cmp471 to i64
  store i64 %cv472, ptr %slot22, align 8
  %v473 = load i64, ptr %slot22, align 8
  %cond474 = icmp ne i64 %v473, 0
  br i1 %cond474, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v475 = load i64, ptr %slot1, align 8
  %p476 = inttoptr i64 %v475 to ptr
  call void @myl_qbe_fail_frame(ptr %p476) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v477 = load i64, ptr %slot14, align 8
  %p478 = inttoptr i64 %v477 to ptr
  store i64 0, ptr %p478, align 8, !alias.scope !3, !noalias !4
  %v479 = load i64, ptr %slot2, align 8
  %v480 = load i64, ptr %slot12, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i64 %v479, ptr %p481, align 8, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot3, align 8
  %v483 = load i64, ptr %slot13, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i64 %v482, ptr %p484, align 8, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot1, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %call487 = call ptr @myl_qbe_heap(ptr %p486) nomerge, !dbg !112
  %calladdr488 = ptrtoint ptr %call487 to i64
  store i64 %calladdr488, ptr %slot23, align 8
  %v489 = load i64, ptr %slot1, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %call491 = call i64 @myl_qbe_region_mark(ptr %p490) nomerge, !dbg !112
  store i64 %call491, ptr %slot24, align 8
  %v492 = load i64, ptr %slot6, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 0, ptr %p493, align 4, !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot7, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i32 0, ptr %p495, align 4, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot8, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i32 0, ptr %p497, align 4, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot9, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i32 0, ptr %p499, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v500 = load i64, ptr %slot12, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot25, align 8
  %v503 = load i64, ptr %slot25, align 8
  %v504 = load i64, ptr %slot17, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i64 %v503, ptr %p505, align 8, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot17, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %ld508 = load i64, ptr %p507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld508, ptr %slot26, align 8
  %v509 = load i64, ptr %slot26, align 8
  %op510 = add i64 %v509, 0
  store i64 %op510, ptr %slot27, align 8
  %v511 = load i64, ptr %slot27, align 8
  %v512 = load i64, ptr %slot17, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 %v511, ptr %p513, align 8, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot6, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ld516 = load i32, ptr %p515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld516, ptr %slot28, align 8
  %v517 = load i32, ptr %slot28, align 8
  %cv518 = zext i32 %v517 to i64
  %cond519 = icmp ne i64 %cv518, 0
  br i1 %cond519, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v520 = load i64, ptr %slot6, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 0, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot10, align 8
  store i64 %v522, ptr %slot29, align 8
  %v523 = load i64, ptr %slot7, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i32, ptr %p524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld525, ptr %slot30, align 8
  %v526 = load i32, ptr %slot30, align 8
  %op527 = and i32 %v526, 28
  store i32 %op527, ptr %slot31, align 8
  %v528 = load i32, ptr %slot31, align 8
  %cv529 = zext i32 %v528 to i64
  %cond530 = icmp ne i64 %cv529, 0
  br i1 %cond530, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v531 = load i64, ptr %slot23, align 8
  store i64 %v531, ptr %slot32, align 8
  %v532 = load i64, ptr %slot32, align 8
  %v533 = load i64, ptr %slot29, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v532, i64 %v533) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v534 = load i64, ptr %slot23, align 8
  store i64 %v534, ptr %slot33, align 8
  %v535 = load i64, ptr %slot33, align 8
  %v536 = load i64, ptr %slot29, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v535, i64 %v536) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v537 = load i64, ptr %slot17, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i64, ptr %p538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld539, ptr %slot34, align 8
  %v540 = load i64, ptr %slot34, align 8
  %op541 = add i64 %v540, 8
  store i64 %op541, ptr %slot35, align 8
  %v542 = load i64, ptr %slot35, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !4, !noalias !3
  store i64 %ld544, ptr %slot36, align 8
  %v545 = load i64, ptr %slot36, align 8
  %v546 = load i64, ptr %slot17, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot6, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i32, ptr %p549, align 4, !alias.scope !3, !noalias !4
  store i32 %ld550, ptr %slot37, align 8
  %v551 = load i32, ptr %slot37, align 8
  %cv552 = zext i32 %v551 to i64
  %cond553 = icmp ne i64 %cv552, 0
  br i1 %cond553, label %bb_rcslotdrop27, label %bb_rcslotdone27
bb_rcslotdrop27:
  %v554 = load i64, ptr %slot6, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i32 0, ptr %p555, align 4, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot10, align 8
  store i64 %v556, ptr %slot38, align 8
  %v557 = load i64, ptr %slot7, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i32, ptr %p558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld559, ptr %slot39, align 8
  %v560 = load i32, ptr %slot39, align 8
  %op561 = and i32 %v560, 28
  store i32 %op561, ptr %slot40, align 8
  %v562 = load i32, ptr %slot40, align 8
  %cv563 = zext i32 %v562 to i64
  %cond564 = icmp ne i64 %cv563, 0
  br i1 %cond564, label %bb_rcslotrole27, label %bb_rcslotowner27
bb_rcslotrole27:
  %v565 = load i64, ptr %slot23, align 8
  store i64 %v565, ptr %slot41, align 8
  %v566 = load i64, ptr %slot41, align 8
  %v567 = load i64, ptr %slot38, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v566, i64 %v567) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotowner27:
  %v568 = load i64, ptr %slot23, align 8
  store i64 %v568, ptr %slot42, align 8
  %v569 = load i64, ptr %slot42, align 8
  %v570 = load i64, ptr %slot38, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v569, i64 %v570) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotdone27:
  %v571 = load i64, ptr %slot17, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot43, align 8
  %v574 = load i64, ptr %slot43, align 8
  %v575 = load i64, ptr %slot14, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot13, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot44, align 8
  %v580 = load i64, ptr %slot44, align 8
  %v581 = load i64, ptr %slot17, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot17, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot45, align 8
  %v586 = load i64, ptr %slot45, align 8
  %v587 = load i64, ptr %slot15, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot15, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld591, ptr %slot46, align 8
  %v592 = load i64, ptr %slot46, align 8
  %v593 = load i64, ptr %slot17, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 %v592, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot18, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i64 0, ptr %p596, align 8, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot18, align 8
  %p598 = inttoptr i64 %v597 to ptr
  %ld599 = load i64, ptr %p598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld599, ptr %slot47, align 8
  %v600 = load i64, ptr %slot17, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i64, ptr %p601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld602, ptr %slot48, align 8
  %v603 = load i64, ptr %slot48, align 8
  %v604 = load i64, ptr %slot47, align 8
  %cmp605 = icmp slt i64 %v603, %v604
  %cv606 = zext i1 %cmp605 to i64
  store i64 %cv606, ptr %slot49, align 8
  %v607 = load i64, ptr %slot49, align 8
  %v608 = load i64, ptr %slot17, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i64 %v607, ptr %p609, align 8, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot17, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot50, align 8
  %v613 = load i64, ptr %slot50, align 8
  %cond614 = icmp ne i64 %v613, 0
  br i1 %cond614, label %bb_next42, label %bb_i15
bb_next42:
  %v615 = load i64, ptr %slot14, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %ld617 = load i64, ptr %p616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld617, ptr %slot51, align 8
  %v618 = load i64, ptr %slot51, align 8
  %op619 = add i64 %v618, 0
  store i64 %op619, ptr %slot52, align 8
  %v620 = load i64, ptr %slot52, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !6, !noalias !7
  store i64 %ld622, ptr %slot53, align 8
  %v623 = load i64, ptr %slot53, align 8
  %v624 = load i64, ptr %slot17, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i64 %v623, ptr %p625, align 8, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot17, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %ld628 = load i64, ptr %p627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld628, ptr %slot54, align 8
  %v629 = load i64, ptr %slot54, align 8
  %cmp630 = icmp ugt i64 %v629, 9223372036854775807
  %cv631 = zext i1 %cmp630 to i64
  store i64 %cv631, ptr %slot55, align 8
  %v632 = load i64, ptr %slot55, align 8
  %cond633 = icmp ne i64 %v632, 0
  br i1 %cond633, label %bb_cast_overflow47, label %bb_cast_ok47
bb_cast_overflow47:
  %v634 = load i64, ptr %slot1, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %v636 = load i64, ptr %slot54, align 8
  call void @myl_qbe_fail_cast(ptr %p635, i64 %v636, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok47:
  %v637 = load i64, ptr %slot54, align 8
  %v638 = load i64, ptr %slot17, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i64 %v637, ptr %p639, align 8, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot15, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot56, align 8
  %v643 = load i64, ptr %slot56, align 8
  %v644 = load i64, ptr %slot18, align 8
  %p645 = inttoptr i64 %v644 to ptr
  store i64 %v643, ptr %p645, align 8, !alias.scope !3, !noalias !4
  %v646 = load i64, ptr %slot18, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %ld648 = load i64, ptr %p647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld648, ptr %slot57, align 8
  %v649 = load i64, ptr %slot17, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %ld651 = load i64, ptr %p650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld651, ptr %slot58, align 8
  %v652 = load i64, ptr %slot58, align 8
  %v653 = load i64, ptr %slot57, align 8
  %ovpair655 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v652, i64 %v653)
  %op654 = extractvalue { i64, i1 } %ovpair655, 0
  %ov656 = extractvalue { i64, i1 } %ovpair655, 1
  store i64 %op654, ptr %slot59, align 8
  %v657 = load i64, ptr %slot58, align 8
  %v658 = load i64, ptr %slot59, align 8
  %op659 = xor i64 %v657, %v658
  store i64 %op659, ptr %slot60, align 8
  %v660 = load i64, ptr %slot57, align 8
  %v661 = load i64, ptr %slot59, align 8
  %op662 = xor i64 %v660, %v661
  store i64 %op662, ptr %slot61, align 8
  %v663 = load i64, ptr %slot60, align 8
  %v664 = load i64, ptr %slot61, align 8
  %op665 = and i64 %v663, %v664
  store i64 %op665, ptr %slot62, align 8
  %cv666 = zext i1 %ov656 to i64
  store i64 %cv666, ptr %slot63, align 8
  %v667 = load i64, ptr %slot63, align 8
  %cond668 = icmp ne i64 %v667, 0
  br i1 %cond668, label %bb_overflow51, label %bb_checked51
bb_overflow51:
  %v669 = load i64, ptr %slot1, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %v671 = load i64, ptr %slot58, align 8
  %v672 = load i64, ptr %slot57, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p670, i64 0, i64 %v671, i64 %v672, i64 64) nomerge, !dbg !120
  unreachable
bb_checked51:
  %v673 = load i64, ptr %slot59, align 8
  %v674 = load i64, ptr %slot17, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot17, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot64, align 8
  %v679 = load i64, ptr %slot64, align 8
  %v680 = load i64, ptr %slot15, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v682 = load i64, ptr %slot15, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot65, align 8
  %v685 = load i64, ptr %slot65, align 8
  %v686 = load i64, ptr %slot17, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot14, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot66, align 8
  %v691 = load i64, ptr %slot17, align 8
  %p692 = inttoptr i64 %v691 to ptr
  %ld693 = load i64, ptr %p692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld693, ptr %slot67, align 8
  %v694 = load i64, ptr %slot66, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !6, !noalias !7
  store i64 %ld696, ptr %slot68, align 8
  %v697 = load i64, ptr %slot67, align 8
  %v698 = load i64, ptr %slot68, align 8
  %cmp699 = icmp ult i64 %v697, %v698
  %cv700 = zext i1 %cmp699 to i64
  store i64 %cv700, ptr %slot69, align 8
  %v701 = load i64, ptr %slot69, align 8
  %cond702 = icmp ne i64 %v701, 0
  br i1 %cond702, label %bb_success63, label %bb_failed63
bb_failed63:
  %v703 = load i64, ptr %slot1, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %v705 = load i64, ptr %slot67, align 8
  %v706 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p704, i64 %v705, i64 %v706) nomerge, !dbg !122
  unreachable
bb_success63:
  %v707 = load i64, ptr %slot66, align 8
  %op708 = add i64 %v707, 32
  store i64 %op708, ptr %slot70, align 8
  %v709 = load i64, ptr %slot70, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %ld711 = load i64, ptr %p710, align 8, !alias.scope !6, !noalias !7
  store i64 %ld711, ptr %slot71, align 8
  %v712 = load i64, ptr %slot67, align 8
  %op713 = mul i64 %v712, 88
  store i64 %op713, ptr %slot72, align 8
  %v714 = load i64, ptr %slot71, align 8
  %v715 = load i64, ptr %slot72, align 8
  %op716 = add i64 %v714, %v715
  store i64 %op716, ptr %slot73, align 8
  %v717 = load i64, ptr %slot73, align 8
  %v718 = load i64, ptr %slot17, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i64 %v717, ptr %p719, align 8, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot17, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i64, ptr %p721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld722, ptr %slot74, align 8
  %v723 = load i64, ptr %slot74, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %ld725 = load i32, ptr %p724, align 4, !alias.scope !12, !noalias !13
  %ext726 = zext i32 %ld725 to i64
  store i64 %ext726, ptr %slot75, align 8
  %v727 = load i64, ptr %slot75, align 8
  %cmp728 = icmp eq i64 %v727, 0
  %cv729 = zext i1 %cmp728 to i64
  store i64 %cv729, ptr %slot76, align 8
  %v730 = load i64, ptr %slot76, align 8
  %cond731 = icmp ne i64 %v730, 0
  br i1 %cond731, label %bb_rcarm70, label %bb_rcarmnext70
bb_rcarm70:
  %v732 = load i64, ptr %slot6, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i32, ptr %p733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld734, ptr %slot77, align 8
  %v735 = load i32, ptr %slot77, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v738 = load i64, ptr %slot6, align 8
  %p739 = inttoptr i64 %v738 to ptr
  store i32 0, ptr %p739, align 4, !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot10, align 8
  store i64 %v740, ptr %slot78, align 8
  %v741 = load i64, ptr %slot7, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i32, ptr %p742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld743, ptr %slot79, align 8
  %v744 = load i32, ptr %slot79, align 8
  %op745 = and i32 %v744, 28
  store i32 %op745, ptr %slot80, align 8
  %v746 = load i32, ptr %slot80, align 8
  %cv747 = zext i32 %v746 to i64
  %cond748 = icmp ne i64 %cv747, 0
  br i1 %cond748, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v749 = load i64, ptr %slot23, align 8
  store i64 %v749, ptr %slot81, align 8
  %v750 = load i64, ptr %slot81, align 8
  %v751 = load i64, ptr %slot78, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v750, i64 %v751) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v752 = load i64, ptr %slot23, align 8
  store i64 %v752, ptr %slot82, align 8
  %v753 = load i64, ptr %slot82, align 8
  %v754 = load i64, ptr %slot78, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v753, i64 %v754) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotdone73:
  br label %bb_i24
bb_rcarmnext70:
  %v755 = load i64, ptr %slot75, align 8
  %cmp756 = icmp eq i64 %v755, 1
  %cv757 = zext i1 %cmp756 to i64
  store i64 %cv757, ptr %slot83, align 8
  %v758 = load i64, ptr %slot83, align 8
  %cond759 = icmp ne i64 %v758, 0
  br i1 %cond759, label %bb_rcarm80, label %bb_rcarmnext80
bb_rcarm80:
  %v760 = load i64, ptr %slot74, align 8
  %op761 = add i64 %v760, 8
  store i64 %op761, ptr %slot84, align 8
  %v762 = load i64, ptr %slot84, align 8
  %v763 = load i64, ptr %slot16, align 8
  %p764 = inttoptr i64 %v762 to ptr
  %p765 = inttoptr i64 %v763 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p765, ptr %p764, i64 80, i1 false), !alias.scope !10000000
  %v766 = load i64, ptr %slot6, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %ld768 = load i32, ptr %p767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld768, ptr %slot85, align 8
  %v769 = load i32, ptr %slot85, align 8
  %cv770 = zext i32 %v769 to i64
  %cond771 = icmp ne i64 %cv770, 0
  br i1 %cond771, label %bb_rcslotdrop94, label %bb_rcslotdone94
bb_rcslotdrop94:
  %v772 = load i64, ptr %slot6, align 8
  %p773 = inttoptr i64 %v772 to ptr
  store i32 0, ptr %p773, align 4, !alias.scope !3, !noalias !4
  %v774 = load i64, ptr %slot10, align 8
  store i64 %v774, ptr %slot86, align 8
  %v775 = load i64, ptr %slot7, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %ld777 = load i32, ptr %p776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld777, ptr %slot87, align 8
  %v778 = load i32, ptr %slot87, align 8
  %op779 = and i32 %v778, 28
  store i32 %op779, ptr %slot88, align 8
  %v780 = load i32, ptr %slot88, align 8
  %cv781 = zext i32 %v780 to i64
  %cond782 = icmp ne i64 %cv781, 0
  br i1 %cond782, label %bb_rcslotrole94, label %bb_rcslotowner94
bb_rcslotrole94:
  %v783 = load i64, ptr %slot23, align 8
  store i64 %v783, ptr %slot89, align 8
  %v784 = load i64, ptr %slot89, align 8
  %v785 = load i64, ptr %slot86, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v784, i64 %v785) nomerge, !dbg !124
  br label %bb_rcslotdone94
bb_rcslotowner94:
  %v786 = load i64, ptr %slot23, align 8
  store i64 %v786, ptr %slot90, align 8
  %v787 = load i64, ptr %slot90, align 8
  %v788 = load i64, ptr %slot86, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v787, i64 %v788) nomerge, !dbg !124
  br label %bb_rcslotdone94
bb_rcslotdone94:
  br label %bb_i18
bb_rcarmnext80:
  %v789 = load i64, ptr %slot75, align 8
  %cmp790 = icmp eq i64 %v789, 2
  %cv791 = zext i1 %cmp790 to i64
  store i64 %cv791, ptr %slot91, align 8
  %v792 = load i64, ptr %slot91, align 8
  %cond793 = icmp ne i64 %v792, 0
  br i1 %cond793, label %bb_rcarm101, label %bb_rcarmnext101
bb_rcarm101:
  %v794 = load i64, ptr %slot6, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i32, ptr %p795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld796, ptr %slot92, align 8
  %v797 = load i32, ptr %slot92, align 8
  %cv798 = zext i32 %v797 to i64
  %cond799 = icmp ne i64 %cv798, 0
  br i1 %cond799, label %bb_rcslotdrop104, label %bb_rcslotdone104
bb_rcslotdrop104:
  %v800 = load i64, ptr %slot6, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 0, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot10, align 8
  store i64 %v802, ptr %slot93, align 8
  %v803 = load i64, ptr %slot7, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i32, ptr %p804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld805, ptr %slot94, align 8
  %v806 = load i32, ptr %slot94, align 8
  %op807 = and i32 %v806, 28
  store i32 %op807, ptr %slot95, align 8
  %v808 = load i32, ptr %slot95, align 8
  %cv809 = zext i32 %v808 to i64
  %cond810 = icmp ne i64 %cv809, 0
  br i1 %cond810, label %bb_rcslotrole104, label %bb_rcslotowner104
bb_rcslotrole104:
  %v811 = load i64, ptr %slot23, align 8
  store i64 %v811, ptr %slot96, align 8
  %v812 = load i64, ptr %slot96, align 8
  %v813 = load i64, ptr %slot93, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v812, i64 %v813) nomerge, !dbg !124
  br label %bb_rcslotdone104
bb_rcslotowner104:
  %v814 = load i64, ptr %slot23, align 8
  store i64 %v814, ptr %slot97, align 8
  %v815 = load i64, ptr %slot97, align 8
  %v816 = load i64, ptr %slot93, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v815, i64 %v816) nomerge, !dbg !124
  br label %bb_rcslotdone104
bb_rcslotdone104:
  br label %bb_i30
bb_rcarmnext101:
  %v817 = load i64, ptr %slot75, align 8
  %cmp818 = icmp eq i64 %v817, 3
  %cv819 = zext i1 %cmp818 to i64
  store i64 %cv819, ptr %slot98, align 8
  %v820 = load i64, ptr %slot98, align 8
  %cond821 = icmp ne i64 %v820, 0
  br i1 %cond821, label %bb_rcarm111, label %bb_rcarmnext111
bb_rcarm111:
  %v822 = load i64, ptr %slot6, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i32, ptr %p823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld824, ptr %slot99, align 8
  %v825 = load i32, ptr %slot99, align 8
  %cv826 = zext i32 %v825 to i64
  %cond827 = icmp ne i64 %cv826, 0
  br i1 %cond827, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v828 = load i64, ptr %slot6, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i32 0, ptr %p829, align 4, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot10, align 8
  store i64 %v830, ptr %slot100, align 8
  %v831 = load i64, ptr %slot7, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %ld833 = load i32, ptr %p832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld833, ptr %slot101, align 8
  %v834 = load i32, ptr %slot101, align 8
  %op835 = and i32 %v834, 28
  store i32 %op835, ptr %slot102, align 8
  %v836 = load i32, ptr %slot102, align 8
  %cv837 = zext i32 %v836 to i64
  %cond838 = icmp ne i64 %cv837, 0
  br i1 %cond838, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v839 = load i64, ptr %slot23, align 8
  store i64 %v839, ptr %slot103, align 8
  %v840 = load i64, ptr %slot103, align 8
  %v841 = load i64, ptr %slot100, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v840, i64 %v841) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v842 = load i64, ptr %slot23, align 8
  store i64 %v842, ptr %slot104, align 8
  %v843 = load i64, ptr %slot104, align 8
  %v844 = load i64, ptr %slot100, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v843, i64 %v844) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotdone114:
  br label %bb_i36
bb_rcarmnext111:
  %v845 = load i64, ptr %slot75, align 8
  %cmp846 = icmp eq i64 %v845, 4
  %cv847 = zext i1 %cmp846 to i64
  store i64 %cv847, ptr %slot105, align 8
  %v848 = load i64, ptr %slot105, align 8
  %cond849 = icmp ne i64 %v848, 0
  br i1 %cond849, label %bb_rcarm121, label %bb_rcarmnext121
bb_rcarm121:
  %v850 = load i64, ptr %slot6, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %ld852 = load i32, ptr %p851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld852, ptr %slot106, align 8
  %v853 = load i32, ptr %slot106, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v856 = load i64, ptr %slot6, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 0, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot10, align 8
  store i64 %v858, ptr %slot107, align 8
  %v859 = load i64, ptr %slot7, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i32, ptr %p860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld861, ptr %slot108, align 8
  %v862 = load i32, ptr %slot108, align 8
  %op863 = and i32 %v862, 28
  store i32 %op863, ptr %slot109, align 8
  %v864 = load i32, ptr %slot109, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v867 = load i64, ptr %slot23, align 8
  store i64 %v867, ptr %slot110, align 8
  %v868 = load i64, ptr %slot110, align 8
  %v869 = load i64, ptr %slot107, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v868, i64 %v869) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v870 = load i64, ptr %slot23, align 8
  store i64 %v870, ptr %slot111, align 8
  %v871 = load i64, ptr %slot111, align 8
  %v872 = load i64, ptr %slot107, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v871, i64 %v872) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotdone124:
  br label %bb_i42
bb_rcarmnext121:
  %v873 = load i64, ptr %slot75, align 8
  %cmp874 = icmp eq i64 %v873, 5
  %cv875 = zext i1 %cmp874 to i64
  store i64 %cv875, ptr %slot112, align 8
  %v876 = load i64, ptr %slot112, align 8
  %cond877 = icmp ne i64 %v876, 0
  br i1 %cond877, label %bb_rcarm131, label %bb_rcarmnext131
bb_rcarm131:
  %v878 = load i64, ptr %slot6, align 8
  %p879 = inttoptr i64 %v878 to ptr
  %ld880 = load i32, ptr %p879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld880, ptr %slot113, align 8
  %v881 = load i32, ptr %slot113, align 8
  %cv882 = zext i32 %v881 to i64
  %cond883 = icmp ne i64 %cv882, 0
  br i1 %cond883, label %bb_rcslotdrop134, label %bb_rcslotdone134
bb_rcslotdrop134:
  %v884 = load i64, ptr %slot6, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i32 0, ptr %p885, align 4, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot10, align 8
  store i64 %v886, ptr %slot114, align 8
  %v887 = load i64, ptr %slot7, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %ld889 = load i32, ptr %p888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld889, ptr %slot115, align 8
  %v890 = load i32, ptr %slot115, align 8
  %op891 = and i32 %v890, 28
  store i32 %op891, ptr %slot116, align 8
  %v892 = load i32, ptr %slot116, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcslotrole134, label %bb_rcslotowner134
bb_rcslotrole134:
  %v895 = load i64, ptr %slot23, align 8
  store i64 %v895, ptr %slot117, align 8
  %v896 = load i64, ptr %slot117, align 8
  %v897 = load i64, ptr %slot114, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v896, i64 %v897) nomerge, !dbg !124
  br label %bb_rcslotdone134
bb_rcslotowner134:
  %v898 = load i64, ptr %slot23, align 8
  store i64 %v898, ptr %slot118, align 8
  %v899 = load i64, ptr %slot118, align 8
  %v900 = load i64, ptr %slot114, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v899, i64 %v900) nomerge, !dbg !124
  br label %bb_rcslotdone134
bb_rcslotdone134:
  br label %bb_i48
bb_rcarmnext131:
  %v901 = load i64, ptr %slot75, align 8
  %cmp902 = icmp eq i64 %v901, 6
  %cv903 = zext i1 %cmp902 to i64
  store i64 %cv903, ptr %slot119, align 8
  %v904 = load i64, ptr %slot119, align 8
  %cond905 = icmp ne i64 %v904, 0
  br i1 %cond905, label %bb_rcarm141, label %bb_rcarmnext141
bb_rcarm141:
  %v906 = load i64, ptr %slot6, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i32, ptr %p907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld908, ptr %slot120, align 8
  %v909 = load i32, ptr %slot120, align 8
  %cv910 = zext i32 %v909 to i64
  %cond911 = icmp ne i64 %cv910, 0
  br i1 %cond911, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v912 = load i64, ptr %slot6, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 0, ptr %p913, align 4, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot10, align 8
  store i64 %v914, ptr %slot121, align 8
  %v915 = load i64, ptr %slot7, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i32, ptr %p916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld917, ptr %slot122, align 8
  %v918 = load i32, ptr %slot122, align 8
  %op919 = and i32 %v918, 28
  store i32 %op919, ptr %slot123, align 8
  %v920 = load i32, ptr %slot123, align 8
  %cv921 = zext i32 %v920 to i64
  %cond922 = icmp ne i64 %cv921, 0
  br i1 %cond922, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v923 = load i64, ptr %slot23, align 8
  store i64 %v923, ptr %slot124, align 8
  %v924 = load i64, ptr %slot124, align 8
  %v925 = load i64, ptr %slot121, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v924, i64 %v925) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v926 = load i64, ptr %slot23, align 8
  store i64 %v926, ptr %slot125, align 8
  %v927 = load i64, ptr %slot125, align 8
  %v928 = load i64, ptr %slot121, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v927, i64 %v928) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotdone144:
  br label %bb_i54
bb_rcarmnext141:
  %v929 = load i64, ptr %slot75, align 8
  %cmp930 = icmp eq i64 %v929, 7
  %cv931 = zext i1 %cmp930 to i64
  store i64 %cv931, ptr %slot126, align 8
  %v932 = load i64, ptr %slot126, align 8
  %cond933 = icmp ne i64 %v932, 0
  br i1 %cond933, label %bb_rcarm151, label %bb_rcarmnext151
bb_rcarm151:
  %v934 = load i64, ptr %slot6, align 8
  %p935 = inttoptr i64 %v934 to ptr
  %ld936 = load i32, ptr %p935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld936, ptr %slot127, align 8
  %v937 = load i32, ptr %slot127, align 8
  %cv938 = zext i32 %v937 to i64
  %cond939 = icmp ne i64 %cv938, 0
  br i1 %cond939, label %bb_rcslotdrop154, label %bb_rcslotdone154
bb_rcslotdrop154:
  %v940 = load i64, ptr %slot6, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i32 0, ptr %p941, align 4, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot10, align 8
  store i64 %v942, ptr %slot128, align 8
  %v943 = load i64, ptr %slot7, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %ld945 = load i32, ptr %p944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld945, ptr %slot129, align 8
  %v946 = load i32, ptr %slot129, align 8
  %op947 = and i32 %v946, 28
  store i32 %op947, ptr %slot130, align 8
  %v948 = load i32, ptr %slot130, align 8
  %cv949 = zext i32 %v948 to i64
  %cond950 = icmp ne i64 %cv949, 0
  br i1 %cond950, label %bb_rcslotrole154, label %bb_rcslotowner154
bb_rcslotrole154:
  %v951 = load i64, ptr %slot23, align 8
  store i64 %v951, ptr %slot131, align 8
  %v952 = load i64, ptr %slot131, align 8
  %v953 = load i64, ptr %slot128, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v952, i64 %v953) nomerge, !dbg !124
  br label %bb_rcslotdone154
bb_rcslotowner154:
  %v954 = load i64, ptr %slot23, align 8
  store i64 %v954, ptr %slot132, align 8
  %v955 = load i64, ptr %slot132, align 8
  %v956 = load i64, ptr %slot128, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v955, i64 %v956) nomerge, !dbg !124
  br label %bb_rcslotdone154
bb_rcslotdone154:
  br label %bb_i60
bb_rcarmnext151:
  %v957 = load i64, ptr %slot75, align 8
  %cmp958 = icmp eq i64 %v957, 8
  %cv959 = zext i1 %cmp958 to i64
  store i64 %cv959, ptr %slot133, align 8
  %v960 = load i64, ptr %slot133, align 8
  %cond961 = icmp ne i64 %v960, 0
  br i1 %cond961, label %bb_rcarm161, label %bb_rcarmnext161
bb_rcarm161:
  %v962 = load i64, ptr %slot6, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i32, ptr %p963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld964, ptr %slot134, align 8
  %v965 = load i32, ptr %slot134, align 8
  %cv966 = zext i32 %v965 to i64
  %cond967 = icmp ne i64 %cv966, 0
  br i1 %cond967, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v968 = load i64, ptr %slot6, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i32 0, ptr %p969, align 4, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot10, align 8
  store i64 %v970, ptr %slot135, align 8
  %v971 = load i64, ptr %slot7, align 8
  %p972 = inttoptr i64 %v971 to ptr
  %ld973 = load i32, ptr %p972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld973, ptr %slot136, align 8
  %v974 = load i32, ptr %slot136, align 8
  %op975 = and i32 %v974, 28
  store i32 %op975, ptr %slot137, align 8
  %v976 = load i32, ptr %slot137, align 8
  %cv977 = zext i32 %v976 to i64
  %cond978 = icmp ne i64 %cv977, 0
  br i1 %cond978, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v979 = load i64, ptr %slot23, align 8
  store i64 %v979, ptr %slot138, align 8
  %v980 = load i64, ptr %slot138, align 8
  %v981 = load i64, ptr %slot135, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v980, i64 %v981) nomerge, !dbg !124
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v982 = load i64, ptr %slot23, align 8
  store i64 %v982, ptr %slot139, align 8
  %v983 = load i64, ptr %slot139, align 8
  %v984 = load i64, ptr %slot135, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v983, i64 %v984) nomerge, !dbg !124
  br label %bb_rcslotdone164
bb_rcslotdone164:
  br label %bb_i66
bb_rcarmnext161:
  br label %bb_failure
bb_i18:
  %v985 = load i64, ptr %slot16, align 8
  %v986 = load i64, ptr %slot17, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i64 %v985, ptr %p987, align 8, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot16, align 8
  %v989 = load i64, ptr %slot17, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 %v988, ptr %p990, align 8, !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot17, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i64, ptr %p992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld993, ptr %slot140, align 8
  %v994 = load i64, ptr %slot6, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i32, ptr %p995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld996, ptr %slot141, align 8
  %v997 = load i64, ptr %slot7, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %ld999 = load i32, ptr %p998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld999, ptr %slot142, align 8
  %v1000 = load i32, ptr %slot142, align 8
  %op1001 = and i32 %v1000, 24
  store i32 %op1001, ptr %slot142, align 8
  %v1002 = load i32, ptr %slot142, align 8
  %cmp1003 = icmp eq i32 %v1002, 0
  %cv1004 = zext i1 %cmp1003 to i32
  store i32 %cv1004, ptr %slot143, align 8
  %v1005 = load i32, ptr %slot141, align 8
  %v1006 = load i32, ptr %slot143, align 8
  %op1007 = and i32 %v1005, %v1006
  store i32 %op1007, ptr %slot144, align 8
  %v1008 = load i64, ptr %slot24, align 8
  store i64 %v1008, ptr %slot145, align 8
  %v1009 = load i32, ptr %slot144, align 8
  %op1010 = mul i32 %v1009, 4
  store i32 %op1010, ptr %slot146, align 8
  %v1011 = load i32, ptr %slot146, align 8
  %op1012 = or i32 %v1011, 0
  store i32 %op1012, ptr %slot147, align 8
  %v1013 = load i64, ptr %slot11, align 8
  store i64 %v1013, ptr %slot148, align 8
  %v1014 = load i64, ptr %slot23, align 8
  %v1015 = load i64, ptr %slot148, align 8
  %v1016 = load i64, ptr %slot140, align 8
  %v1017 = load i64, ptr %slot145, align 8
  %cv1018 = trunc i64 %v1017 to i32
  %v1019 = load i32, ptr %slot147, align 8
  %call1020 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_publish(i64 %v1014, i64 %v1015, i64 %v1016, i32 %cv1018, i32 %v1019) nomerge, !dbg !126
  store i32 %call1020, ptr %slot149, align 8
  %v1021 = load i32, ptr %slot149, align 8
  %cv1022 = zext i32 %v1021 to i64
  %cond1023 = icmp ne i64 %cv1022, 0
  br i1 %cond1023, label %bb_rcsuccess185, label %bb_rcfailure185
bb_rcfailure185:
  %v1024 = load i64, ptr %slot23, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %call1026 = call i32 @myl_rc_take_failure(ptr %p1025) nomerge, !dbg !126
  store i32 %call1026, ptr %slot150, align 8
  %v1027 = load i64, ptr %slot1, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  %v1029 = load i32, ptr %slot150, align 8
  %call1030 = call i32 @myl_qbe_rc_status(ptr %p1028, i32 %v1029) nomerge, !dbg !126
  store i32 %call1030, ptr %slot151, align 8
  br label %bb_failure
bb_rcsuccess185:
  %v1031 = load i32, ptr %slot144, align 8
  %cv1032 = zext i32 %v1031 to i64
  %cond1033 = icmp ne i64 %cv1032, 0
  br i1 %cond1033, label %bb_rchtaken188, label %bb_rchcopied188
bb_rchcopied188:
  %v1034 = load i64, ptr %slot6, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i32, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1036, ptr %slot152, align 8
  %v1037 = load i32, ptr %slot152, align 8
  %cv1038 = zext i32 %v1037 to i64
  %cond1039 = icmp ne i64 %cv1038, 0
  br i1 %cond1039, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v1040 = load i64, ptr %slot6, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  store i32 0, ptr %p1041, align 4, !alias.scope !3, !noalias !4
  %v1042 = load i64, ptr %slot10, align 8
  store i64 %v1042, ptr %slot153, align 8
  %v1043 = load i64, ptr %slot7, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  %ld1045 = load i32, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1045, ptr %slot154, align 8
  %v1046 = load i32, ptr %slot154, align 8
  %op1047 = and i32 %v1046, 28
  store i32 %op1047, ptr %slot155, align 8
  %v1048 = load i32, ptr %slot155, align 8
  %cv1049 = zext i32 %v1048 to i64
  %cond1050 = icmp ne i64 %cv1049, 0
  br i1 %cond1050, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v1051 = load i64, ptr %slot23, align 8
  store i64 %v1051, ptr %slot156, align 8
  %v1052 = load i64, ptr %slot156, align 8
  %v1053 = load i64, ptr %slot153, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1052, i64 %v1053) nomerge, !dbg !126
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v1054 = load i64, ptr %slot23, align 8
  store i64 %v1054, ptr %slot157, align 8
  %v1055 = load i64, ptr %slot157, align 8
  %v1056 = load i64, ptr %slot153, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1055, i64 %v1056) nomerge, !dbg !126
  br label %bb_rcslotdone191
bb_rcslotdone191:
  br label %bb_rchprepared188
bb_rchtaken188:
  %v1057 = load i64, ptr %slot6, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 0, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared188
bb_rchprepared188:
  %v1059 = load i64, ptr %slot9, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  store i32 2, ptr %p1060, align 4, !alias.scope !3, !noalias !4
  %v1061 = load i64, ptr %slot8, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i32 1, ptr %p1062, align 4, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot10, align 8
  store i64 %v1063, ptr %slot158, align 8
  %v1064 = load i64, ptr %slot11, align 8
  store i64 %v1064, ptr %slot159, align 8
  %v1065 = load i64, ptr %slot159, align 8
  %v1066 = load i64, ptr %slot158, align 8
  %p1067 = inttoptr i64 %v1065 to ptr
  %p1068 = inttoptr i64 %v1066 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1068, ptr %p1067, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot7, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i32 2, ptr %p1070, align 4, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot9, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  %ld1073 = load i32, ptr %p1072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1073, ptr %slot160, align 8
  %v1074 = load i32, ptr %slot160, align 8
  %v1075 = load i64, ptr %slot7, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i32 %v1074, ptr %p1076, align 4, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot8, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  store i32 0, ptr %p1078, align 4, !alias.scope !3, !noalias !4
  %v1079 = load i64, ptr %slot6, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i32 1, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  %v1081 = load i64, ptr %slot158, align 8
  %v1082 = load i64, ptr %slot17, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i64 %v1081, ptr %p1083, align 8, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot17, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i64, ptr %p1085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1086, ptr %slot161, align 8
  %v1087 = load i64, ptr %slot17, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %ld1089 = load i64, ptr %p1088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1089, ptr %slot162, align 8
  %v1090 = load i64, ptr %slot11, align 8
  store i64 %v1090, ptr %slot163, align 8
  %v1091 = load i64, ptr %slot24, align 8
  store i64 %v1091, ptr %slot164, align 8
  %v1092 = load i64, ptr %slot23, align 8
  %v1093 = load i64, ptr %slot163, align 8
  %v1094 = load i64, ptr %slot162, align 8
  %v1095 = load i64, ptr %slot164, align 8
  %cv1096 = trunc i64 %v1095 to i32
  %call1097 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1092, i64 %v1093, i64 %v1094, i32 %cv1096) nomerge, !dbg !128
  store i32 %call1097, ptr %slot165, align 8
  %v1098 = load i32, ptr %slot165, align 8
  %cv1099 = zext i32 %v1098 to i64
  %cond1100 = icmp ne i64 %cv1099, 0
  br i1 %cond1100, label %bb_rcsuccess214, label %bb_rcfailure214
bb_rcfailure214:
  %v1101 = load i64, ptr %slot23, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %call1103 = call i32 @myl_rc_take_failure(ptr %p1102) nomerge, !dbg !128
  store i32 %call1103, ptr %slot166, align 8
  %v1104 = load i64, ptr %slot1, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  %v1106 = load i32, ptr %slot166, align 8
  %call1107 = call i32 @myl_qbe_rc_status(ptr %p1105, i32 %v1106) nomerge, !dbg !128
  store i32 %call1107, ptr %slot167, align 8
  br label %bb_failure
bb_rcsuccess214:
  %v1108 = load i64, ptr %slot6, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i32 0, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  %v1110 = load i64, ptr %slot9, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 2, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot8, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i32 1, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot11, align 8
  store i64 %v1114, ptr %slot168, align 8
  %v1115 = load i64, ptr %slot8, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  store i32 0, ptr %p1116, align 4, !alias.scope !3, !noalias !4
  %v1117 = load i64, ptr %slot6, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i32, ptr %p1118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1119, ptr %slot169, align 8
  %v1120 = load i32, ptr %slot169, align 8
  %cv1121 = zext i32 %v1120 to i64
  %cond1122 = icmp ne i64 %cv1121, 0
  br i1 %cond1122, label %bb_rcslotdrop224, label %bb_rcslotdone224
bb_rcslotdrop224:
  %v1123 = load i64, ptr %slot6, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i32 0, ptr %p1124, align 4, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot10, align 8
  store i64 %v1125, ptr %slot170, align 8
  %v1126 = load i64, ptr %slot7, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  %ld1128 = load i32, ptr %p1127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1128, ptr %slot171, align 8
  %v1129 = load i32, ptr %slot171, align 8
  %op1130 = and i32 %v1129, 28
  store i32 %op1130, ptr %slot172, align 8
  %v1131 = load i32, ptr %slot172, align 8
  %cv1132 = zext i32 %v1131 to i64
  %cond1133 = icmp ne i64 %cv1132, 0
  br i1 %cond1133, label %bb_rcslotrole224, label %bb_rcslotowner224
bb_rcslotrole224:
  %v1134 = load i64, ptr %slot23, align 8
  store i64 %v1134, ptr %slot173, align 8
  %v1135 = load i64, ptr %slot173, align 8
  %v1136 = load i64, ptr %slot170, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1135, i64 %v1136) nomerge, !dbg !128
  br label %bb_rcslotdone224
bb_rcslotowner224:
  %v1137 = load i64, ptr %slot23, align 8
  store i64 %v1137, ptr %slot174, align 8
  %v1138 = load i64, ptr %slot174, align 8
  %v1139 = load i64, ptr %slot170, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1138, i64 %v1139) nomerge, !dbg !128
  br label %bb_rcslotdone224
bb_rcslotdone224:
  %v1140 = load i64, ptr %slot168, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1141, i64 80, i1 false)
  ret void
bb_i24:
  %v1142 = load i64, ptr %slot17, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i64 0, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  %v1144 = load i64, ptr %slot17, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %ld1146 = load i64, ptr %p1145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1146, ptr %slot175, align 8
  %v1147 = load i64, ptr %slot175, align 8
  %cond1148 = icmp ne i64 %v1147, 0
  br i1 %cond1148, label %bb_success287, label %bb_failed287
bb_failed287:
  %v1149 = load i64, ptr %slot1, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  call void @myl_qbe_fail_assert(ptr %p1150) nomerge, !dbg !130
  unreachable
bb_success287:
  %v1151 = load i64, ptr %slot12, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %ld1153 = load i64, ptr %p1152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1153, ptr %slot176, align 8
  %v1154 = load i64, ptr %slot176, align 8
  %v1155 = load i64, ptr %slot17, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  store i64 %v1154, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  %v1157 = load i64, ptr %slot13, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  %ld1159 = load i64, ptr %p1158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1159, ptr %slot177, align 8
  %v1160 = load i64, ptr %slot177, align 8
  %v1161 = load i64, ptr %slot18, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  store i64 %v1160, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot17, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1165, ptr %slot178, align 8
  %v1166 = load i64, ptr %slot18, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i64, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1168, ptr %slot179, align 8
  %v1169 = load i64, ptr %slot1, align 8
  %v1170 = load i64, ptr %slot178, align 8
  %v1171 = load i64, ptr %slot179, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult181, i64 %v1169, i64 %v1170, i64 %v1171) nomerge, !dbg !132
  %addr1172 = ptrtoint ptr %callresult181 to i64
  store i64 %addr1172, ptr %slot180, align 8
  %v1173 = load i64, ptr %slot180, align 8
  %v1174 = load i64, ptr %slot17, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i64 %v1173, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot17, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  %ld1178 = load i64, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1178, ptr %slot182, align 8
  %v1179 = load i64, ptr %slot11, align 8
  store i64 %v1179, ptr %slot183, align 8
  %v1180 = load i64, ptr %slot182, align 8
  %v1181 = load i64, ptr %slot183, align 8
  %p1182 = inttoptr i64 %v1180 to ptr
  %p1183 = inttoptr i64 %v1181 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1183, ptr %p1182, i64 80, i1 false)
  %v1184 = load i64, ptr %slot9, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i32 2, ptr %p1185, align 4, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot8, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i32 1, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot6, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  %ld1190 = load i32, ptr %p1189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1190, ptr %slot184, align 8
  %v1191 = load i32, ptr %slot184, align 8
  %cv1192 = zext i32 %v1191 to i64
  %cond1193 = icmp ne i64 %cv1192, 0
  br i1 %cond1193, label %bb_rcslotdrop299, label %bb_rcslotdone299
bb_rcslotdrop299:
  %v1194 = load i64, ptr %slot6, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i32 0, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot10, align 8
  store i64 %v1196, ptr %slot185, align 8
  %v1197 = load i64, ptr %slot7, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %ld1199 = load i32, ptr %p1198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1199, ptr %slot186, align 8
  %v1200 = load i32, ptr %slot186, align 8
  %op1201 = and i32 %v1200, 28
  store i32 %op1201, ptr %slot187, align 8
  %v1202 = load i32, ptr %slot187, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcslotrole299, label %bb_rcslotowner299
bb_rcslotrole299:
  %v1205 = load i64, ptr %slot23, align 8
  store i64 %v1205, ptr %slot188, align 8
  %v1206 = load i64, ptr %slot188, align 8
  %v1207 = load i64, ptr %slot185, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1206, i64 %v1207) nomerge, !dbg !132
  br label %bb_rcslotdone299
bb_rcslotowner299:
  %v1208 = load i64, ptr %slot23, align 8
  store i64 %v1208, ptr %slot189, align 8
  %v1209 = load i64, ptr %slot189, align 8
  %v1210 = load i64, ptr %slot185, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1209, i64 %v1210) nomerge, !dbg !132
  br label %bb_rcslotdone299
bb_rcslotdone299:
  %v1211 = load i64, ptr %slot10, align 8
  store i64 %v1211, ptr %slot190, align 8
  %v1212 = load i64, ptr %slot11, align 8
  store i64 %v1212, ptr %slot191, align 8
  %v1213 = load i64, ptr %slot191, align 8
  %v1214 = load i64, ptr %slot190, align 8
  %p1215 = inttoptr i64 %v1213 to ptr
  %p1216 = inttoptr i64 %v1214 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1216, ptr %p1215, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1217 = load i64, ptr %slot7, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  store i32 2, ptr %p1218, align 4, !alias.scope !3, !noalias !4
  %v1219 = load i64, ptr %slot9, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  %ld1221 = load i32, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1221, ptr %slot192, align 8
  %v1222 = load i32, ptr %slot192, align 8
  %v1223 = load i64, ptr %slot7, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i32 %v1222, ptr %p1224, align 4, !alias.scope !3, !noalias !4
  %v1225 = load i64, ptr %slot8, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  store i32 0, ptr %p1226, align 4, !alias.scope !3, !noalias !4
  %v1227 = load i64, ptr %slot6, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  store i32 1, ptr %p1228, align 4, !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot190, align 8
  %v1230 = load i64, ptr %slot17, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i64 %v1229, ptr %p1231, align 8, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot17, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  %ld1234 = load i64, ptr %p1233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1234, ptr %slot193, align 8
  %v1235 = load i64, ptr %slot17, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i64, ptr %p1236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1237, ptr %slot194, align 8
  %v1238 = load i64, ptr %slot11, align 8
  store i64 %v1238, ptr %slot195, align 8
  %v1239 = load i64, ptr %slot24, align 8
  store i64 %v1239, ptr %slot196, align 8
  %v1240 = load i64, ptr %slot23, align 8
  %v1241 = load i64, ptr %slot195, align 8
  %v1242 = load i64, ptr %slot194, align 8
  %v1243 = load i64, ptr %slot196, align 8
  %cv1244 = trunc i64 %v1243 to i32
  %call1245 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1240, i64 %v1241, i64 %v1242, i32 %cv1244) nomerge, !dbg !134
  store i32 %call1245, ptr %slot197, align 8
  %v1246 = load i32, ptr %slot197, align 8
  %cv1247 = zext i32 %v1246 to i64
  %cond1248 = icmp ne i64 %cv1247, 0
  br i1 %cond1248, label %bb_rcsuccess319, label %bb_rcfailure319
bb_rcfailure319:
  %v1249 = load i64, ptr %slot23, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %call1251 = call i32 @myl_rc_take_failure(ptr %p1250) nomerge, !dbg !134
  store i32 %call1251, ptr %slot198, align 8
  %v1252 = load i64, ptr %slot1, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %v1254 = load i32, ptr %slot198, align 8
  %call1255 = call i32 @myl_qbe_rc_status(ptr %p1253, i32 %v1254) nomerge, !dbg !134
  store i32 %call1255, ptr %slot199, align 8
  br label %bb_failure
bb_rcsuccess319:
  %v1256 = load i64, ptr %slot6, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  store i32 0, ptr %p1257, align 4, !alias.scope !3, !noalias !4
  %v1258 = load i64, ptr %slot9, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  store i32 2, ptr %p1259, align 4, !alias.scope !3, !noalias !4
  %v1260 = load i64, ptr %slot8, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i32 1, ptr %p1261, align 4, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot11, align 8
  store i64 %v1262, ptr %slot200, align 8
  %v1263 = load i64, ptr %slot8, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i32 0, ptr %p1264, align 4, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot6, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %ld1267 = load i32, ptr %p1266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1267, ptr %slot201, align 8
  %v1268 = load i32, ptr %slot201, align 8
  %cv1269 = zext i32 %v1268 to i64
  %cond1270 = icmp ne i64 %cv1269, 0
  br i1 %cond1270, label %bb_rcslotdrop329, label %bb_rcslotdone329
bb_rcslotdrop329:
  %v1271 = load i64, ptr %slot6, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  store i32 0, ptr %p1272, align 4, !alias.scope !3, !noalias !4
  %v1273 = load i64, ptr %slot10, align 8
  store i64 %v1273, ptr %slot202, align 8
  %v1274 = load i64, ptr %slot7, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %ld1276 = load i32, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1276, ptr %slot203, align 8
  %v1277 = load i32, ptr %slot203, align 8
  %op1278 = and i32 %v1277, 28
  store i32 %op1278, ptr %slot204, align 8
  %v1279 = load i32, ptr %slot204, align 8
  %cv1280 = zext i32 %v1279 to i64
  %cond1281 = icmp ne i64 %cv1280, 0
  br i1 %cond1281, label %bb_rcslotrole329, label %bb_rcslotowner329
bb_rcslotrole329:
  %v1282 = load i64, ptr %slot23, align 8
  store i64 %v1282, ptr %slot205, align 8
  %v1283 = load i64, ptr %slot205, align 8
  %v1284 = load i64, ptr %slot202, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1283, i64 %v1284) nomerge, !dbg !134
  br label %bb_rcslotdone329
bb_rcslotowner329:
  %v1285 = load i64, ptr %slot23, align 8
  store i64 %v1285, ptr %slot206, align 8
  %v1286 = load i64, ptr %slot206, align 8
  %v1287 = load i64, ptr %slot202, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1286, i64 %v1287) nomerge, !dbg !134
  br label %bb_rcslotdone329
bb_rcslotdone329:
  %v1288 = load i64, ptr %slot200, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1289, i64 80, i1 false)
  ret void
bb_i30:
  %v1290 = load i64, ptr %slot17, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i64 0, ptr %p1291, align 8, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot17, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  %ld1294 = load i64, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1294, ptr %slot207, align 8
  %v1295 = load i64, ptr %slot207, align 8
  %cond1296 = icmp ne i64 %v1295, 0
  br i1 %cond1296, label %bb_success392, label %bb_failed392
bb_failed392:
  %v1297 = load i64, ptr %slot1, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  call void @myl_qbe_fail_assert(ptr %p1298) nomerge, !dbg !136
  unreachable
bb_success392:
  %v1299 = load i64, ptr %slot12, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  %ld1301 = load i64, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1301, ptr %slot208, align 8
  %v1302 = load i64, ptr %slot208, align 8
  %v1303 = load i64, ptr %slot17, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  store i64 %v1302, ptr %p1304, align 8, !alias.scope !3, !noalias !4
  %v1305 = load i64, ptr %slot13, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %ld1307 = load i64, ptr %p1306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1307, ptr %slot209, align 8
  %v1308 = load i64, ptr %slot209, align 8
  %v1309 = load i64, ptr %slot18, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i64 %v1308, ptr %p1310, align 8, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot17, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %ld1313 = load i64, ptr %p1312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1313, ptr %slot210, align 8
  %v1314 = load i64, ptr %slot18, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i64, ptr %p1315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1316, ptr %slot211, align 8
  %v1317 = load i64, ptr %slot1, align 8
  %v1318 = load i64, ptr %slot210, align 8
  %v1319 = load i64, ptr %slot211, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult213, i64 %v1317, i64 %v1318, i64 %v1319) nomerge, !dbg !138
  %addr1320 = ptrtoint ptr %callresult213 to i64
  store i64 %addr1320, ptr %slot212, align 8
  %v1321 = load i64, ptr %slot212, align 8
  %v1322 = load i64, ptr %slot17, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i64 %v1321, ptr %p1323, align 8, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot17, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i64, ptr %p1325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1326, ptr %slot214, align 8
  %v1327 = load i64, ptr %slot11, align 8
  store i64 %v1327, ptr %slot215, align 8
  %v1328 = load i64, ptr %slot214, align 8
  %v1329 = load i64, ptr %slot215, align 8
  %p1330 = inttoptr i64 %v1328 to ptr
  %p1331 = inttoptr i64 %v1329 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1331, ptr %p1330, i64 80, i1 false)
  %v1332 = load i64, ptr %slot9, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 2, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot8, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 1, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot6, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %ld1338 = load i32, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1338, ptr %slot216, align 8
  %v1339 = load i32, ptr %slot216, align 8
  %cv1340 = zext i32 %v1339 to i64
  %cond1341 = icmp ne i64 %cv1340, 0
  br i1 %cond1341, label %bb_rcslotdrop404, label %bb_rcslotdone404
bb_rcslotdrop404:
  %v1342 = load i64, ptr %slot6, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  store i32 0, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot10, align 8
  store i64 %v1344, ptr %slot217, align 8
  %v1345 = load i64, ptr %slot7, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i32, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1347, ptr %slot218, align 8
  %v1348 = load i32, ptr %slot218, align 8
  %op1349 = and i32 %v1348, 28
  store i32 %op1349, ptr %slot219, align 8
  %v1350 = load i32, ptr %slot219, align 8
  %cv1351 = zext i32 %v1350 to i64
  %cond1352 = icmp ne i64 %cv1351, 0
  br i1 %cond1352, label %bb_rcslotrole404, label %bb_rcslotowner404
bb_rcslotrole404:
  %v1353 = load i64, ptr %slot23, align 8
  store i64 %v1353, ptr %slot220, align 8
  %v1354 = load i64, ptr %slot220, align 8
  %v1355 = load i64, ptr %slot217, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1354, i64 %v1355) nomerge, !dbg !138
  br label %bb_rcslotdone404
bb_rcslotowner404:
  %v1356 = load i64, ptr %slot23, align 8
  store i64 %v1356, ptr %slot221, align 8
  %v1357 = load i64, ptr %slot221, align 8
  %v1358 = load i64, ptr %slot217, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1357, i64 %v1358) nomerge, !dbg !138
  br label %bb_rcslotdone404
bb_rcslotdone404:
  %v1359 = load i64, ptr %slot10, align 8
  store i64 %v1359, ptr %slot222, align 8
  %v1360 = load i64, ptr %slot11, align 8
  store i64 %v1360, ptr %slot223, align 8
  %v1361 = load i64, ptr %slot223, align 8
  %v1362 = load i64, ptr %slot222, align 8
  %p1363 = inttoptr i64 %v1361 to ptr
  %p1364 = inttoptr i64 %v1362 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1364, ptr %p1363, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot7, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 2, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot9, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %ld1369 = load i32, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1369, ptr %slot224, align 8
  %v1370 = load i32, ptr %slot224, align 8
  %v1371 = load i64, ptr %slot7, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 %v1370, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot8, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 0, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot6, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 1, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot222, align 8
  %v1378 = load i64, ptr %slot17, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 %v1377, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot17, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  %ld1382 = load i64, ptr %p1381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1382, ptr %slot225, align 8
  %v1383 = load i64, ptr %slot17, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %ld1385 = load i64, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1385, ptr %slot226, align 8
  %v1386 = load i64, ptr %slot11, align 8
  store i64 %v1386, ptr %slot227, align 8
  %v1387 = load i64, ptr %slot24, align 8
  store i64 %v1387, ptr %slot228, align 8
  %v1388 = load i64, ptr %slot23, align 8
  %v1389 = load i64, ptr %slot227, align 8
  %v1390 = load i64, ptr %slot226, align 8
  %v1391 = load i64, ptr %slot228, align 8
  %cv1392 = trunc i64 %v1391 to i32
  %call1393 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1388, i64 %v1389, i64 %v1390, i32 %cv1392) nomerge, !dbg !140
  store i32 %call1393, ptr %slot229, align 8
  %v1394 = load i32, ptr %slot229, align 8
  %cv1395 = zext i32 %v1394 to i64
  %cond1396 = icmp ne i64 %cv1395, 0
  br i1 %cond1396, label %bb_rcsuccess424, label %bb_rcfailure424
bb_rcfailure424:
  %v1397 = load i64, ptr %slot23, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  %call1399 = call i32 @myl_rc_take_failure(ptr %p1398) nomerge, !dbg !140
  store i32 %call1399, ptr %slot230, align 8
  %v1400 = load i64, ptr %slot1, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %v1402 = load i32, ptr %slot230, align 8
  %call1403 = call i32 @myl_qbe_rc_status(ptr %p1401, i32 %v1402) nomerge, !dbg !140
  store i32 %call1403, ptr %slot231, align 8
  br label %bb_failure
bb_rcsuccess424:
  %v1404 = load i64, ptr %slot6, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 0, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot9, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i32 2, ptr %p1407, align 4, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot8, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i32 1, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  %v1410 = load i64, ptr %slot11, align 8
  store i64 %v1410, ptr %slot232, align 8
  %v1411 = load i64, ptr %slot8, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  store i32 0, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  %v1413 = load i64, ptr %slot6, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  %ld1415 = load i32, ptr %p1414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1415, ptr %slot233, align 8
  %v1416 = load i32, ptr %slot233, align 8
  %cv1417 = zext i32 %v1416 to i64
  %cond1418 = icmp ne i64 %cv1417, 0
  br i1 %cond1418, label %bb_rcslotdrop434, label %bb_rcslotdone434
bb_rcslotdrop434:
  %v1419 = load i64, ptr %slot6, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i32 0, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot10, align 8
  store i64 %v1421, ptr %slot234, align 8
  %v1422 = load i64, ptr %slot7, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  %ld1424 = load i32, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1424, ptr %slot235, align 8
  %v1425 = load i32, ptr %slot235, align 8
  %op1426 = and i32 %v1425, 28
  store i32 %op1426, ptr %slot236, align 8
  %v1427 = load i32, ptr %slot236, align 8
  %cv1428 = zext i32 %v1427 to i64
  %cond1429 = icmp ne i64 %cv1428, 0
  br i1 %cond1429, label %bb_rcslotrole434, label %bb_rcslotowner434
bb_rcslotrole434:
  %v1430 = load i64, ptr %slot23, align 8
  store i64 %v1430, ptr %slot237, align 8
  %v1431 = load i64, ptr %slot237, align 8
  %v1432 = load i64, ptr %slot234, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1431, i64 %v1432) nomerge, !dbg !140
  br label %bb_rcslotdone434
bb_rcslotowner434:
  %v1433 = load i64, ptr %slot23, align 8
  store i64 %v1433, ptr %slot238, align 8
  %v1434 = load i64, ptr %slot238, align 8
  %v1435 = load i64, ptr %slot234, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1434, i64 %v1435) nomerge, !dbg !140
  br label %bb_rcslotdone434
bb_rcslotdone434:
  %v1436 = load i64, ptr %slot232, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1437, i64 80, i1 false)
  ret void
bb_i36:
  %v1438 = load i64, ptr %slot17, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  store i64 0, ptr %p1439, align 8, !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot17, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i64, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1442, ptr %slot239, align 8
  %v1443 = load i64, ptr %slot239, align 8
  %cond1444 = icmp ne i64 %v1443, 0
  br i1 %cond1444, label %bb_success497, label %bb_failed497
bb_failed497:
  %v1445 = load i64, ptr %slot1, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  call void @myl_qbe_fail_assert(ptr %p1446) nomerge, !dbg !142
  unreachable
bb_success497:
  %v1447 = load i64, ptr %slot12, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i64, ptr %p1448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1449, ptr %slot240, align 8
  %v1450 = load i64, ptr %slot240, align 8
  %v1451 = load i64, ptr %slot17, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  store i64 %v1450, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  %v1453 = load i64, ptr %slot13, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %ld1455 = load i64, ptr %p1454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1455, ptr %slot241, align 8
  %v1456 = load i64, ptr %slot241, align 8
  %v1457 = load i64, ptr %slot18, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i64 %v1456, ptr %p1458, align 8, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot17, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i64, ptr %p1460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1461, ptr %slot242, align 8
  %v1462 = load i64, ptr %slot18, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1464, ptr %slot243, align 8
  %v1465 = load i64, ptr %slot1, align 8
  %v1466 = load i64, ptr %slot242, align 8
  %v1467 = load i64, ptr %slot243, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult245, i64 %v1465, i64 %v1466, i64 %v1467) nomerge, !dbg !144
  %addr1468 = ptrtoint ptr %callresult245 to i64
  store i64 %addr1468, ptr %slot244, align 8
  %v1469 = load i64, ptr %slot244, align 8
  %v1470 = load i64, ptr %slot17, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  store i64 %v1469, ptr %p1471, align 8, !alias.scope !3, !noalias !4
  %v1472 = load i64, ptr %slot17, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  %ld1474 = load i64, ptr %p1473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1474, ptr %slot246, align 8
  %v1475 = load i64, ptr %slot11, align 8
  store i64 %v1475, ptr %slot247, align 8
  %v1476 = load i64, ptr %slot246, align 8
  %v1477 = load i64, ptr %slot247, align 8
  %p1478 = inttoptr i64 %v1476 to ptr
  %p1479 = inttoptr i64 %v1477 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1479, ptr %p1478, i64 80, i1 false)
  %v1480 = load i64, ptr %slot9, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i32 2, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  %v1482 = load i64, ptr %slot8, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i32 1, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  %v1484 = load i64, ptr %slot6, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i32, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1486, ptr %slot248, align 8
  %v1487 = load i32, ptr %slot248, align 8
  %cv1488 = zext i32 %v1487 to i64
  %cond1489 = icmp ne i64 %cv1488, 0
  br i1 %cond1489, label %bb_rcslotdrop509, label %bb_rcslotdone509
bb_rcslotdrop509:
  %v1490 = load i64, ptr %slot6, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i32 0, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot10, align 8
  store i64 %v1492, ptr %slot249, align 8
  %v1493 = load i64, ptr %slot7, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  %ld1495 = load i32, ptr %p1494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1495, ptr %slot250, align 8
  %v1496 = load i32, ptr %slot250, align 8
  %op1497 = and i32 %v1496, 28
  store i32 %op1497, ptr %slot251, align 8
  %v1498 = load i32, ptr %slot251, align 8
  %cv1499 = zext i32 %v1498 to i64
  %cond1500 = icmp ne i64 %cv1499, 0
  br i1 %cond1500, label %bb_rcslotrole509, label %bb_rcslotowner509
bb_rcslotrole509:
  %v1501 = load i64, ptr %slot23, align 8
  store i64 %v1501, ptr %slot252, align 8
  %v1502 = load i64, ptr %slot252, align 8
  %v1503 = load i64, ptr %slot249, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1502, i64 %v1503) nomerge, !dbg !144
  br label %bb_rcslotdone509
bb_rcslotowner509:
  %v1504 = load i64, ptr %slot23, align 8
  store i64 %v1504, ptr %slot253, align 8
  %v1505 = load i64, ptr %slot253, align 8
  %v1506 = load i64, ptr %slot249, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1505, i64 %v1506) nomerge, !dbg !144
  br label %bb_rcslotdone509
bb_rcslotdone509:
  %v1507 = load i64, ptr %slot10, align 8
  store i64 %v1507, ptr %slot254, align 8
  %v1508 = load i64, ptr %slot11, align 8
  store i64 %v1508, ptr %slot255, align 8
  %v1509 = load i64, ptr %slot255, align 8
  %v1510 = load i64, ptr %slot254, align 8
  %p1511 = inttoptr i64 %v1509 to ptr
  %p1512 = inttoptr i64 %v1510 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1512, ptr %p1511, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1513 = load i64, ptr %slot7, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  store i32 2, ptr %p1514, align 4, !alias.scope !3, !noalias !4
  %v1515 = load i64, ptr %slot9, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %ld1517 = load i32, ptr %p1516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1517, ptr %slot256, align 8
  %v1518 = load i32, ptr %slot256, align 8
  %v1519 = load i64, ptr %slot7, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  store i32 %v1518, ptr %p1520, align 4, !alias.scope !3, !noalias !4
  %v1521 = load i64, ptr %slot8, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i32 0, ptr %p1522, align 4, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot6, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 1, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot254, align 8
  %v1526 = load i64, ptr %slot17, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  store i64 %v1525, ptr %p1527, align 8, !alias.scope !3, !noalias !4
  %v1528 = load i64, ptr %slot17, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %ld1530 = load i64, ptr %p1529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1530, ptr %slot257, align 8
  %v1531 = load i64, ptr %slot17, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %ld1533 = load i64, ptr %p1532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1533, ptr %slot258, align 8
  %v1534 = load i64, ptr %slot11, align 8
  store i64 %v1534, ptr %slot259, align 8
  %v1535 = load i64, ptr %slot24, align 8
  store i64 %v1535, ptr %slot260, align 8
  %v1536 = load i64, ptr %slot23, align 8
  %v1537 = load i64, ptr %slot259, align 8
  %v1538 = load i64, ptr %slot258, align 8
  %v1539 = load i64, ptr %slot260, align 8
  %cv1540 = trunc i64 %v1539 to i32
  %call1541 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1536, i64 %v1537, i64 %v1538, i32 %cv1540) nomerge, !dbg !146
  store i32 %call1541, ptr %slot261, align 8
  %v1542 = load i32, ptr %slot261, align 8
  %cv1543 = zext i32 %v1542 to i64
  %cond1544 = icmp ne i64 %cv1543, 0
  br i1 %cond1544, label %bb_rcsuccess529, label %bb_rcfailure529
bb_rcfailure529:
  %v1545 = load i64, ptr %slot23, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %call1547 = call i32 @myl_rc_take_failure(ptr %p1546) nomerge, !dbg !146
  store i32 %call1547, ptr %slot262, align 8
  %v1548 = load i64, ptr %slot1, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %v1550 = load i32, ptr %slot262, align 8
  %call1551 = call i32 @myl_qbe_rc_status(ptr %p1549, i32 %v1550) nomerge, !dbg !146
  store i32 %call1551, ptr %slot263, align 8
  br label %bb_failure
bb_rcsuccess529:
  %v1552 = load i64, ptr %slot6, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i32 0, ptr %p1553, align 4, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot9, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  store i32 2, ptr %p1555, align 4, !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot8, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i32 1, ptr %p1557, align 4, !alias.scope !3, !noalias !4
  %v1558 = load i64, ptr %slot11, align 8
  store i64 %v1558, ptr %slot264, align 8
  %v1559 = load i64, ptr %slot8, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 0, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot6, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %ld1563 = load i32, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1563, ptr %slot265, align 8
  %v1564 = load i32, ptr %slot265, align 8
  %cv1565 = zext i32 %v1564 to i64
  %cond1566 = icmp ne i64 %cv1565, 0
  br i1 %cond1566, label %bb_rcslotdrop539, label %bb_rcslotdone539
bb_rcslotdrop539:
  %v1567 = load i64, ptr %slot6, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i32 0, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot10, align 8
  store i64 %v1569, ptr %slot266, align 8
  %v1570 = load i64, ptr %slot7, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  %ld1572 = load i32, ptr %p1571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1572, ptr %slot267, align 8
  %v1573 = load i32, ptr %slot267, align 8
  %op1574 = and i32 %v1573, 28
  store i32 %op1574, ptr %slot268, align 8
  %v1575 = load i32, ptr %slot268, align 8
  %cv1576 = zext i32 %v1575 to i64
  %cond1577 = icmp ne i64 %cv1576, 0
  br i1 %cond1577, label %bb_rcslotrole539, label %bb_rcslotowner539
bb_rcslotrole539:
  %v1578 = load i64, ptr %slot23, align 8
  store i64 %v1578, ptr %slot269, align 8
  %v1579 = load i64, ptr %slot269, align 8
  %v1580 = load i64, ptr %slot266, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1579, i64 %v1580) nomerge, !dbg !146
  br label %bb_rcslotdone539
bb_rcslotowner539:
  %v1581 = load i64, ptr %slot23, align 8
  store i64 %v1581, ptr %slot270, align 8
  %v1582 = load i64, ptr %slot270, align 8
  %v1583 = load i64, ptr %slot266, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1582, i64 %v1583) nomerge, !dbg !146
  br label %bb_rcslotdone539
bb_rcslotdone539:
  %v1584 = load i64, ptr %slot264, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1585, i64 80, i1 false)
  ret void
bb_i42:
  %v1586 = load i64, ptr %slot17, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  store i64 0, ptr %p1587, align 8, !alias.scope !3, !noalias !4
  %v1588 = load i64, ptr %slot17, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  %ld1590 = load i64, ptr %p1589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1590, ptr %slot271, align 8
  %v1591 = load i64, ptr %slot271, align 8
  %cond1592 = icmp ne i64 %v1591, 0
  br i1 %cond1592, label %bb_success602, label %bb_failed602
bb_failed602:
  %v1593 = load i64, ptr %slot1, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  call void @myl_qbe_fail_assert(ptr %p1594) nomerge, !dbg !148
  unreachable
bb_success602:
  %v1595 = load i64, ptr %slot12, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i64, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1597, ptr %slot272, align 8
  %v1598 = load i64, ptr %slot272, align 8
  %v1599 = load i64, ptr %slot17, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  store i64 %v1598, ptr %p1600, align 8, !alias.scope !3, !noalias !4
  %v1601 = load i64, ptr %slot13, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %ld1603 = load i64, ptr %p1602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1603, ptr %slot273, align 8
  %v1604 = load i64, ptr %slot273, align 8
  %v1605 = load i64, ptr %slot18, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i64 %v1604, ptr %p1606, align 8, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot17, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  %ld1609 = load i64, ptr %p1608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1609, ptr %slot274, align 8
  %v1610 = load i64, ptr %slot18, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i64, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1612, ptr %slot275, align 8
  %v1613 = load i64, ptr %slot1, align 8
  %v1614 = load i64, ptr %slot274, align 8
  %v1615 = load i64, ptr %slot275, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult277, i64 %v1613, i64 %v1614, i64 %v1615) nomerge, !dbg !150
  %addr1616 = ptrtoint ptr %callresult277 to i64
  store i64 %addr1616, ptr %slot276, align 8
  %v1617 = load i64, ptr %slot276, align 8
  %v1618 = load i64, ptr %slot17, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i64 %v1617, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot17, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %ld1622 = load i64, ptr %p1621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1622, ptr %slot278, align 8
  %v1623 = load i64, ptr %slot11, align 8
  store i64 %v1623, ptr %slot279, align 8
  %v1624 = load i64, ptr %slot278, align 8
  %v1625 = load i64, ptr %slot279, align 8
  %p1626 = inttoptr i64 %v1624 to ptr
  %p1627 = inttoptr i64 %v1625 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1627, ptr %p1626, i64 80, i1 false)
  %v1628 = load i64, ptr %slot9, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 2, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot8, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 1, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot6, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot280, align 8
  %v1635 = load i32, ptr %slot280, align 8
  %cv1636 = zext i32 %v1635 to i64
  %cond1637 = icmp ne i64 %cv1636, 0
  br i1 %cond1637, label %bb_rcslotdrop614, label %bb_rcslotdone614
bb_rcslotdrop614:
  %v1638 = load i64, ptr %slot6, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 0, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot10, align 8
  store i64 %v1640, ptr %slot281, align 8
  %v1641 = load i64, ptr %slot7, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i32, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1643, ptr %slot282, align 8
  %v1644 = load i32, ptr %slot282, align 8
  %op1645 = and i32 %v1644, 28
  store i32 %op1645, ptr %slot283, align 8
  %v1646 = load i32, ptr %slot283, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcslotrole614, label %bb_rcslotowner614
bb_rcslotrole614:
  %v1649 = load i64, ptr %slot23, align 8
  store i64 %v1649, ptr %slot284, align 8
  %v1650 = load i64, ptr %slot284, align 8
  %v1651 = load i64, ptr %slot281, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1650, i64 %v1651) nomerge, !dbg !150
  br label %bb_rcslotdone614
bb_rcslotowner614:
  %v1652 = load i64, ptr %slot23, align 8
  store i64 %v1652, ptr %slot285, align 8
  %v1653 = load i64, ptr %slot285, align 8
  %v1654 = load i64, ptr %slot281, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1653, i64 %v1654) nomerge, !dbg !150
  br label %bb_rcslotdone614
bb_rcslotdone614:
  %v1655 = load i64, ptr %slot10, align 8
  store i64 %v1655, ptr %slot286, align 8
  %v1656 = load i64, ptr %slot11, align 8
  store i64 %v1656, ptr %slot287, align 8
  %v1657 = load i64, ptr %slot287, align 8
  %v1658 = load i64, ptr %slot286, align 8
  %p1659 = inttoptr i64 %v1657 to ptr
  %p1660 = inttoptr i64 %v1658 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1660, ptr %p1659, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot7, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  store i32 2, ptr %p1662, align 4, !alias.scope !3, !noalias !4
  %v1663 = load i64, ptr %slot9, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %ld1665 = load i32, ptr %p1664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1665, ptr %slot288, align 8
  %v1666 = load i32, ptr %slot288, align 8
  %v1667 = load i64, ptr %slot7, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  store i32 %v1666, ptr %p1668, align 4, !alias.scope !3, !noalias !4
  %v1669 = load i64, ptr %slot8, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i32 0, ptr %p1670, align 4, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot6, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i32 1, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  %v1673 = load i64, ptr %slot286, align 8
  %v1674 = load i64, ptr %slot17, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 %v1673, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot17, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %ld1678 = load i64, ptr %p1677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1678, ptr %slot289, align 8
  %v1679 = load i64, ptr %slot17, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i64, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1681, ptr %slot290, align 8
  %v1682 = load i64, ptr %slot11, align 8
  store i64 %v1682, ptr %slot291, align 8
  %v1683 = load i64, ptr %slot24, align 8
  store i64 %v1683, ptr %slot292, align 8
  %v1684 = load i64, ptr %slot23, align 8
  %v1685 = load i64, ptr %slot291, align 8
  %v1686 = load i64, ptr %slot290, align 8
  %v1687 = load i64, ptr %slot292, align 8
  %cv1688 = trunc i64 %v1687 to i32
  %call1689 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1684, i64 %v1685, i64 %v1686, i32 %cv1688) nomerge, !dbg !152
  store i32 %call1689, ptr %slot293, align 8
  %v1690 = load i32, ptr %slot293, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcsuccess634, label %bb_rcfailure634
bb_rcfailure634:
  %v1693 = load i64, ptr %slot23, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %call1695 = call i32 @myl_rc_take_failure(ptr %p1694) nomerge, !dbg !152
  store i32 %call1695, ptr %slot294, align 8
  %v1696 = load i64, ptr %slot1, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %v1698 = load i32, ptr %slot294, align 8
  %call1699 = call i32 @myl_qbe_rc_status(ptr %p1697, i32 %v1698) nomerge, !dbg !152
  store i32 %call1699, ptr %slot295, align 8
  br label %bb_failure
bb_rcsuccess634:
  %v1700 = load i64, ptr %slot6, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  store i32 0, ptr %p1701, align 4, !alias.scope !3, !noalias !4
  %v1702 = load i64, ptr %slot9, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  store i32 2, ptr %p1703, align 4, !alias.scope !3, !noalias !4
  %v1704 = load i64, ptr %slot8, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i32 1, ptr %p1705, align 4, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot11, align 8
  store i64 %v1706, ptr %slot296, align 8
  %v1707 = load i64, ptr %slot8, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 0, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot6, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i32, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1711, ptr %slot297, align 8
  %v1712 = load i32, ptr %slot297, align 8
  %cv1713 = zext i32 %v1712 to i64
  %cond1714 = icmp ne i64 %cv1713, 0
  br i1 %cond1714, label %bb_rcslotdrop644, label %bb_rcslotdone644
bb_rcslotdrop644:
  %v1715 = load i64, ptr %slot6, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 0, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot10, align 8
  store i64 %v1717, ptr %slot298, align 8
  %v1718 = load i64, ptr %slot7, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %ld1720 = load i32, ptr %p1719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1720, ptr %slot299, align 8
  %v1721 = load i32, ptr %slot299, align 8
  %op1722 = and i32 %v1721, 28
  store i32 %op1722, ptr %slot300, align 8
  %v1723 = load i32, ptr %slot300, align 8
  %cv1724 = zext i32 %v1723 to i64
  %cond1725 = icmp ne i64 %cv1724, 0
  br i1 %cond1725, label %bb_rcslotrole644, label %bb_rcslotowner644
bb_rcslotrole644:
  %v1726 = load i64, ptr %slot23, align 8
  store i64 %v1726, ptr %slot301, align 8
  %v1727 = load i64, ptr %slot301, align 8
  %v1728 = load i64, ptr %slot298, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1727, i64 %v1728) nomerge, !dbg !152
  br label %bb_rcslotdone644
bb_rcslotowner644:
  %v1729 = load i64, ptr %slot23, align 8
  store i64 %v1729, ptr %slot302, align 8
  %v1730 = load i64, ptr %slot302, align 8
  %v1731 = load i64, ptr %slot298, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1730, i64 %v1731) nomerge, !dbg !152
  br label %bb_rcslotdone644
bb_rcslotdone644:
  %v1732 = load i64, ptr %slot296, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1733, i64 80, i1 false)
  ret void
bb_i48:
  %v1734 = load i64, ptr %slot17, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  store i64 0, ptr %p1735, align 8, !alias.scope !3, !noalias !4
  %v1736 = load i64, ptr %slot17, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i64, ptr %p1737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1738, ptr %slot303, align 8
  %v1739 = load i64, ptr %slot303, align 8
  %cond1740 = icmp ne i64 %v1739, 0
  br i1 %cond1740, label %bb_success707, label %bb_failed707
bb_failed707:
  %v1741 = load i64, ptr %slot1, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  call void @myl_qbe_fail_assert(ptr %p1742) nomerge, !dbg !154
  unreachable
bb_success707:
  %v1743 = load i64, ptr %slot12, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot304, align 8
  %v1746 = load i64, ptr %slot304, align 8
  %v1747 = load i64, ptr %slot17, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i64 %v1746, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot13, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot305, align 8
  %v1752 = load i64, ptr %slot305, align 8
  %v1753 = load i64, ptr %slot18, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i64 %v1752, ptr %p1754, align 8, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot17, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i64, ptr %p1756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1757, ptr %slot306, align 8
  %v1758 = load i64, ptr %slot18, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i64, ptr %p1759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1760, ptr %slot307, align 8
  %v1761 = load i64, ptr %slot1, align 8
  %v1762 = load i64, ptr %slot306, align 8
  %v1763 = load i64, ptr %slot307, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult309, i64 %v1761, i64 %v1762, i64 %v1763) nomerge, !dbg !156
  %addr1764 = ptrtoint ptr %callresult309 to i64
  store i64 %addr1764, ptr %slot308, align 8
  %v1765 = load i64, ptr %slot308, align 8
  %v1766 = load i64, ptr %slot17, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  store i64 %v1765, ptr %p1767, align 8, !alias.scope !3, !noalias !4
  %v1768 = load i64, ptr %slot17, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %ld1770 = load i64, ptr %p1769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1770, ptr %slot310, align 8
  %v1771 = load i64, ptr %slot11, align 8
  store i64 %v1771, ptr %slot311, align 8
  %v1772 = load i64, ptr %slot310, align 8
  %v1773 = load i64, ptr %slot311, align 8
  %p1774 = inttoptr i64 %v1772 to ptr
  %p1775 = inttoptr i64 %v1773 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1775, ptr %p1774, i64 80, i1 false)
  %v1776 = load i64, ptr %slot9, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  store i32 2, ptr %p1777, align 4, !alias.scope !3, !noalias !4
  %v1778 = load i64, ptr %slot8, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i32 1, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot6, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i32, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1782, ptr %slot312, align 8
  %v1783 = load i32, ptr %slot312, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rcslotdrop719, label %bb_rcslotdone719
bb_rcslotdrop719:
  %v1786 = load i64, ptr %slot6, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  store i32 0, ptr %p1787, align 4, !alias.scope !3, !noalias !4
  %v1788 = load i64, ptr %slot10, align 8
  store i64 %v1788, ptr %slot313, align 8
  %v1789 = load i64, ptr %slot7, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i32, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1791, ptr %slot314, align 8
  %v1792 = load i32, ptr %slot314, align 8
  %op1793 = and i32 %v1792, 28
  store i32 %op1793, ptr %slot315, align 8
  %v1794 = load i32, ptr %slot315, align 8
  %cv1795 = zext i32 %v1794 to i64
  %cond1796 = icmp ne i64 %cv1795, 0
  br i1 %cond1796, label %bb_rcslotrole719, label %bb_rcslotowner719
bb_rcslotrole719:
  %v1797 = load i64, ptr %slot23, align 8
  store i64 %v1797, ptr %slot316, align 8
  %v1798 = load i64, ptr %slot316, align 8
  %v1799 = load i64, ptr %slot313, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1798, i64 %v1799) nomerge, !dbg !156
  br label %bb_rcslotdone719
bb_rcslotowner719:
  %v1800 = load i64, ptr %slot23, align 8
  store i64 %v1800, ptr %slot317, align 8
  %v1801 = load i64, ptr %slot317, align 8
  %v1802 = load i64, ptr %slot313, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1801, i64 %v1802) nomerge, !dbg !156
  br label %bb_rcslotdone719
bb_rcslotdone719:
  %v1803 = load i64, ptr %slot10, align 8
  store i64 %v1803, ptr %slot318, align 8
  %v1804 = load i64, ptr %slot11, align 8
  store i64 %v1804, ptr %slot319, align 8
  %v1805 = load i64, ptr %slot319, align 8
  %v1806 = load i64, ptr %slot318, align 8
  %p1807 = inttoptr i64 %v1805 to ptr
  %p1808 = inttoptr i64 %v1806 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1808, ptr %p1807, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot7, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 2, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot9, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i32, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1813, ptr %slot320, align 8
  %v1814 = load i32, ptr %slot320, align 8
  %v1815 = load i64, ptr %slot7, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 %v1814, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot8, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot6, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i32 1, ptr %p1820, align 4, !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot318, align 8
  %v1822 = load i64, ptr %slot17, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  store i64 %v1821, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  %v1824 = load i64, ptr %slot17, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  %ld1826 = load i64, ptr %p1825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1826, ptr %slot321, align 8
  %v1827 = load i64, ptr %slot17, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i64, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1829, ptr %slot322, align 8
  %v1830 = load i64, ptr %slot11, align 8
  store i64 %v1830, ptr %slot323, align 8
  %v1831 = load i64, ptr %slot24, align 8
  store i64 %v1831, ptr %slot324, align 8
  %v1832 = load i64, ptr %slot23, align 8
  %v1833 = load i64, ptr %slot323, align 8
  %v1834 = load i64, ptr %slot322, align 8
  %v1835 = load i64, ptr %slot324, align 8
  %cv1836 = trunc i64 %v1835 to i32
  %call1837 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1832, i64 %v1833, i64 %v1834, i32 %cv1836) nomerge, !dbg !158
  store i32 %call1837, ptr %slot325, align 8
  %v1838 = load i32, ptr %slot325, align 8
  %cv1839 = zext i32 %v1838 to i64
  %cond1840 = icmp ne i64 %cv1839, 0
  br i1 %cond1840, label %bb_rcsuccess739, label %bb_rcfailure739
bb_rcfailure739:
  %v1841 = load i64, ptr %slot23, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %call1843 = call i32 @myl_rc_take_failure(ptr %p1842) nomerge, !dbg !158
  store i32 %call1843, ptr %slot326, align 8
  %v1844 = load i64, ptr %slot1, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %v1846 = load i32, ptr %slot326, align 8
  %call1847 = call i32 @myl_qbe_rc_status(ptr %p1845, i32 %v1846) nomerge, !dbg !158
  store i32 %call1847, ptr %slot327, align 8
  br label %bb_failure
bb_rcsuccess739:
  %v1848 = load i64, ptr %slot6, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  store i32 0, ptr %p1849, align 4, !alias.scope !3, !noalias !4
  %v1850 = load i64, ptr %slot9, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i32 2, ptr %p1851, align 4, !alias.scope !3, !noalias !4
  %v1852 = load i64, ptr %slot8, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  store i32 1, ptr %p1853, align 4, !alias.scope !3, !noalias !4
  %v1854 = load i64, ptr %slot11, align 8
  store i64 %v1854, ptr %slot328, align 8
  %v1855 = load i64, ptr %slot8, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 0, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot6, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  %ld1859 = load i32, ptr %p1858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1859, ptr %slot329, align 8
  %v1860 = load i32, ptr %slot329, align 8
  %cv1861 = zext i32 %v1860 to i64
  %cond1862 = icmp ne i64 %cv1861, 0
  br i1 %cond1862, label %bb_rcslotdrop749, label %bb_rcslotdone749
bb_rcslotdrop749:
  %v1863 = load i64, ptr %slot6, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  store i32 0, ptr %p1864, align 4, !alias.scope !3, !noalias !4
  %v1865 = load i64, ptr %slot10, align 8
  store i64 %v1865, ptr %slot330, align 8
  %v1866 = load i64, ptr %slot7, align 8
  %p1867 = inttoptr i64 %v1866 to ptr
  %ld1868 = load i32, ptr %p1867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1868, ptr %slot331, align 8
  %v1869 = load i32, ptr %slot331, align 8
  %op1870 = and i32 %v1869, 28
  store i32 %op1870, ptr %slot332, align 8
  %v1871 = load i32, ptr %slot332, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcslotrole749, label %bb_rcslotowner749
bb_rcslotrole749:
  %v1874 = load i64, ptr %slot23, align 8
  store i64 %v1874, ptr %slot333, align 8
  %v1875 = load i64, ptr %slot333, align 8
  %v1876 = load i64, ptr %slot330, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v1875, i64 %v1876) nomerge, !dbg !158
  br label %bb_rcslotdone749
bb_rcslotowner749:
  %v1877 = load i64, ptr %slot23, align 8
  store i64 %v1877, ptr %slot334, align 8
  %v1878 = load i64, ptr %slot334, align 8
  %v1879 = load i64, ptr %slot330, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v1878, i64 %v1879) nomerge, !dbg !158
  br label %bb_rcslotdone749
bb_rcslotdone749:
  %v1880 = load i64, ptr %slot328, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1881, i64 80, i1 false)
  ret void
bb_i54:
  %v1882 = load i64, ptr %slot17, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  store i64 0, ptr %p1883, align 8, !alias.scope !3, !noalias !4
  %v1884 = load i64, ptr %slot17, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  %ld1886 = load i64, ptr %p1885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1886, ptr %slot335, align 8
  %v1887 = load i64, ptr %slot335, align 8
  %cond1888 = icmp ne i64 %v1887, 0
  br i1 %cond1888, label %bb_success812, label %bb_failed812
bb_failed812:
  %v1889 = load i64, ptr %slot1, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  call void @myl_qbe_fail_assert(ptr %p1890) nomerge, !dbg !160
  unreachable
bb_success812:
  %v1891 = load i64, ptr %slot12, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %ld1893 = load i64, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1893, ptr %slot336, align 8
  %v1894 = load i64, ptr %slot336, align 8
  %v1895 = load i64, ptr %slot17, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i64 %v1894, ptr %p1896, align 8, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot13, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  %ld1899 = load i64, ptr %p1898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1899, ptr %slot337, align 8
  %v1900 = load i64, ptr %slot337, align 8
  %v1901 = load i64, ptr %slot18, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i64 %v1900, ptr %p1902, align 8, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot17, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  %ld1905 = load i64, ptr %p1904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1905, ptr %slot338, align 8
  %v1906 = load i64, ptr %slot18, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  %ld1908 = load i64, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1908, ptr %slot339, align 8
  %v1909 = load i64, ptr %slot1, align 8
  %v1910 = load i64, ptr %slot338, align 8
  %v1911 = load i64, ptr %slot339, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult341, i64 %v1909, i64 %v1910, i64 %v1911) nomerge, !dbg !162
  %addr1912 = ptrtoint ptr %callresult341 to i64
  store i64 %addr1912, ptr %slot340, align 8
  %v1913 = load i64, ptr %slot340, align 8
  %v1914 = load i64, ptr %slot17, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i64 %v1913, ptr %p1915, align 8, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot17, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i64, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1918, ptr %slot342, align 8
  %v1919 = load i64, ptr %slot11, align 8
  store i64 %v1919, ptr %slot343, align 8
  %v1920 = load i64, ptr %slot342, align 8
  %v1921 = load i64, ptr %slot343, align 8
  %p1922 = inttoptr i64 %v1920 to ptr
  %p1923 = inttoptr i64 %v1921 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1923, ptr %p1922, i64 80, i1 false)
  %v1924 = load i64, ptr %slot9, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  store i32 2, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  %v1926 = load i64, ptr %slot8, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  store i32 1, ptr %p1927, align 4, !alias.scope !3, !noalias !4
  %v1928 = load i64, ptr %slot6, align 8
  %p1929 = inttoptr i64 %v1928 to ptr
  %ld1930 = load i32, ptr %p1929, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1930, ptr %slot344, align 8
  %v1931 = load i32, ptr %slot344, align 8
  %cv1932 = zext i32 %v1931 to i64
  %cond1933 = icmp ne i64 %cv1932, 0
  br i1 %cond1933, label %bb_rcslotdrop824, label %bb_rcslotdone824
bb_rcslotdrop824:
  %v1934 = load i64, ptr %slot6, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i32 0, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot10, align 8
  store i64 %v1936, ptr %slot345, align 8
  %v1937 = load i64, ptr %slot7, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i32, ptr %p1938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1939, ptr %slot346, align 8
  %v1940 = load i32, ptr %slot346, align 8
  %op1941 = and i32 %v1940, 28
  store i32 %op1941, ptr %slot347, align 8
  %v1942 = load i32, ptr %slot347, align 8
  %cv1943 = zext i32 %v1942 to i64
  %cond1944 = icmp ne i64 %cv1943, 0
  br i1 %cond1944, label %bb_rcslotrole824, label %bb_rcslotowner824
bb_rcslotrole824:
  %v1945 = load i64, ptr %slot23, align 8
  store i64 %v1945, ptr %slot348, align 8
  %v1946 = load i64, ptr %slot348, align 8
  %v1947 = load i64, ptr %slot345, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1946, i64 %v1947) nomerge, !dbg !162
  br label %bb_rcslotdone824
bb_rcslotowner824:
  %v1948 = load i64, ptr %slot23, align 8
  store i64 %v1948, ptr %slot349, align 8
  %v1949 = load i64, ptr %slot349, align 8
  %v1950 = load i64, ptr %slot345, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1949, i64 %v1950) nomerge, !dbg !162
  br label %bb_rcslotdone824
bb_rcslotdone824:
  %v1951 = load i64, ptr %slot10, align 8
  store i64 %v1951, ptr %slot350, align 8
  %v1952 = load i64, ptr %slot11, align 8
  store i64 %v1952, ptr %slot351, align 8
  %v1953 = load i64, ptr %slot351, align 8
  %v1954 = load i64, ptr %slot350, align 8
  %p1955 = inttoptr i64 %v1953 to ptr
  %p1956 = inttoptr i64 %v1954 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1956, ptr %p1955, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot7, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i32 2, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot9, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i32, ptr %p1960, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1961, ptr %slot352, align 8
  %v1962 = load i32, ptr %slot352, align 8
  %v1963 = load i64, ptr %slot7, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  store i32 %v1962, ptr %p1964, align 4, !alias.scope !3, !noalias !4
  %v1965 = load i64, ptr %slot8, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i32 0, ptr %p1966, align 4, !alias.scope !3, !noalias !4
  %v1967 = load i64, ptr %slot6, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  store i32 1, ptr %p1968, align 4, !alias.scope !3, !noalias !4
  %v1969 = load i64, ptr %slot350, align 8
  %v1970 = load i64, ptr %slot17, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  store i64 %v1969, ptr %p1971, align 8, !alias.scope !3, !noalias !4
  %v1972 = load i64, ptr %slot17, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  %ld1974 = load i64, ptr %p1973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1974, ptr %slot353, align 8
  %v1975 = load i64, ptr %slot17, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  %ld1977 = load i64, ptr %p1976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1977, ptr %slot354, align 8
  %v1978 = load i64, ptr %slot11, align 8
  store i64 %v1978, ptr %slot355, align 8
  %v1979 = load i64, ptr %slot24, align 8
  store i64 %v1979, ptr %slot356, align 8
  %v1980 = load i64, ptr %slot23, align 8
  %v1981 = load i64, ptr %slot355, align 8
  %v1982 = load i64, ptr %slot354, align 8
  %v1983 = load i64, ptr %slot356, align 8
  %cv1984 = trunc i64 %v1983 to i32
  %call1985 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v1980, i64 %v1981, i64 %v1982, i32 %cv1984) nomerge, !dbg !164
  store i32 %call1985, ptr %slot357, align 8
  %v1986 = load i32, ptr %slot357, align 8
  %cv1987 = zext i32 %v1986 to i64
  %cond1988 = icmp ne i64 %cv1987, 0
  br i1 %cond1988, label %bb_rcsuccess844, label %bb_rcfailure844
bb_rcfailure844:
  %v1989 = load i64, ptr %slot23, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  %call1991 = call i32 @myl_rc_take_failure(ptr %p1990) nomerge, !dbg !164
  store i32 %call1991, ptr %slot358, align 8
  %v1992 = load i64, ptr %slot1, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %v1994 = load i32, ptr %slot358, align 8
  %call1995 = call i32 @myl_qbe_rc_status(ptr %p1993, i32 %v1994) nomerge, !dbg !164
  store i32 %call1995, ptr %slot359, align 8
  br label %bb_failure
bb_rcsuccess844:
  %v1996 = load i64, ptr %slot6, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i32 0, ptr %p1997, align 4, !alias.scope !3, !noalias !4
  %v1998 = load i64, ptr %slot9, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i32 2, ptr %p1999, align 4, !alias.scope !3, !noalias !4
  %v2000 = load i64, ptr %slot8, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i32 1, ptr %p2001, align 4, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot11, align 8
  store i64 %v2002, ptr %slot360, align 8
  %v2003 = load i64, ptr %slot8, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  store i32 0, ptr %p2004, align 4, !alias.scope !3, !noalias !4
  %v2005 = load i64, ptr %slot6, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %ld2007 = load i32, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2007, ptr %slot361, align 8
  %v2008 = load i32, ptr %slot361, align 8
  %cv2009 = zext i32 %v2008 to i64
  %cond2010 = icmp ne i64 %cv2009, 0
  br i1 %cond2010, label %bb_rcslotdrop854, label %bb_rcslotdone854
bb_rcslotdrop854:
  %v2011 = load i64, ptr %slot6, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i32 0, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot10, align 8
  store i64 %v2013, ptr %slot362, align 8
  %v2014 = load i64, ptr %slot7, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %ld2016 = load i32, ptr %p2015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2016, ptr %slot363, align 8
  %v2017 = load i32, ptr %slot363, align 8
  %op2018 = and i32 %v2017, 28
  store i32 %op2018, ptr %slot364, align 8
  %v2019 = load i32, ptr %slot364, align 8
  %cv2020 = zext i32 %v2019 to i64
  %cond2021 = icmp ne i64 %cv2020, 0
  br i1 %cond2021, label %bb_rcslotrole854, label %bb_rcslotowner854
bb_rcslotrole854:
  %v2022 = load i64, ptr %slot23, align 8
  store i64 %v2022, ptr %slot365, align 8
  %v2023 = load i64, ptr %slot365, align 8
  %v2024 = load i64, ptr %slot362, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v2023, i64 %v2024) nomerge, !dbg !164
  br label %bb_rcslotdone854
bb_rcslotowner854:
  %v2025 = load i64, ptr %slot23, align 8
  store i64 %v2025, ptr %slot366, align 8
  %v2026 = load i64, ptr %slot366, align 8
  %v2027 = load i64, ptr %slot362, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v2026, i64 %v2027) nomerge, !dbg !164
  br label %bb_rcslotdone854
bb_rcslotdone854:
  %v2028 = load i64, ptr %slot360, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2029, i64 80, i1 false)
  ret void
bb_i60:
  %v2030 = load i64, ptr %slot17, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  store i64 0, ptr %p2031, align 8, !alias.scope !3, !noalias !4
  %v2032 = load i64, ptr %slot17, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %ld2034 = load i64, ptr %p2033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2034, ptr %slot367, align 8
  %v2035 = load i64, ptr %slot367, align 8
  %cond2036 = icmp ne i64 %v2035, 0
  br i1 %cond2036, label %bb_success917, label %bb_failed917
bb_failed917:
  %v2037 = load i64, ptr %slot1, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  call void @myl_qbe_fail_assert(ptr %p2038) nomerge, !dbg !166
  unreachable
bb_success917:
  %v2039 = load i64, ptr %slot12, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %ld2041 = load i64, ptr %p2040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2041, ptr %slot368, align 8
  %v2042 = load i64, ptr %slot368, align 8
  %v2043 = load i64, ptr %slot17, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  store i64 %v2042, ptr %p2044, align 8, !alias.scope !3, !noalias !4
  %v2045 = load i64, ptr %slot13, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  %ld2047 = load i64, ptr %p2046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2047, ptr %slot369, align 8
  %v2048 = load i64, ptr %slot369, align 8
  %v2049 = load i64, ptr %slot18, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i64 %v2048, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot17, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i64, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2053, ptr %slot370, align 8
  %v2054 = load i64, ptr %slot18, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  %ld2056 = load i64, ptr %p2055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2056, ptr %slot371, align 8
  %v2057 = load i64, ptr %slot1, align 8
  %v2058 = load i64, ptr %slot370, align 8
  %v2059 = load i64, ptr %slot371, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult373, i64 %v2057, i64 %v2058, i64 %v2059) nomerge, !dbg !168
  %addr2060 = ptrtoint ptr %callresult373 to i64
  store i64 %addr2060, ptr %slot372, align 8
  %v2061 = load i64, ptr %slot372, align 8
  %v2062 = load i64, ptr %slot17, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  store i64 %v2061, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  %v2064 = load i64, ptr %slot17, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  %ld2066 = load i64, ptr %p2065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2066, ptr %slot374, align 8
  %v2067 = load i64, ptr %slot11, align 8
  store i64 %v2067, ptr %slot375, align 8
  %v2068 = load i64, ptr %slot374, align 8
  %v2069 = load i64, ptr %slot375, align 8
  %p2070 = inttoptr i64 %v2068 to ptr
  %p2071 = inttoptr i64 %v2069 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2071, ptr %p2070, i64 80, i1 false)
  %v2072 = load i64, ptr %slot9, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i32 2, ptr %p2073, align 4, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot8, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i32 1, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot6, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %ld2078 = load i32, ptr %p2077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2078, ptr %slot376, align 8
  %v2079 = load i32, ptr %slot376, align 8
  %cv2080 = zext i32 %v2079 to i64
  %cond2081 = icmp ne i64 %cv2080, 0
  br i1 %cond2081, label %bb_rcslotdrop929, label %bb_rcslotdone929
bb_rcslotdrop929:
  %v2082 = load i64, ptr %slot6, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i32 0, ptr %p2083, align 4, !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot10, align 8
  store i64 %v2084, ptr %slot377, align 8
  %v2085 = load i64, ptr %slot7, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i32, ptr %p2086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2087, ptr %slot378, align 8
  %v2088 = load i32, ptr %slot378, align 8
  %op2089 = and i32 %v2088, 28
  store i32 %op2089, ptr %slot379, align 8
  %v2090 = load i32, ptr %slot379, align 8
  %cv2091 = zext i32 %v2090 to i64
  %cond2092 = icmp ne i64 %cv2091, 0
  br i1 %cond2092, label %bb_rcslotrole929, label %bb_rcslotowner929
bb_rcslotrole929:
  %v2093 = load i64, ptr %slot23, align 8
  store i64 %v2093, ptr %slot380, align 8
  %v2094 = load i64, ptr %slot380, align 8
  %v2095 = load i64, ptr %slot377, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2094, i64 %v2095) nomerge, !dbg !168
  br label %bb_rcslotdone929
bb_rcslotowner929:
  %v2096 = load i64, ptr %slot23, align 8
  store i64 %v2096, ptr %slot381, align 8
  %v2097 = load i64, ptr %slot381, align 8
  %v2098 = load i64, ptr %slot377, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2097, i64 %v2098) nomerge, !dbg !168
  br label %bb_rcslotdone929
bb_rcslotdone929:
  %v2099 = load i64, ptr %slot10, align 8
  store i64 %v2099, ptr %slot382, align 8
  %v2100 = load i64, ptr %slot11, align 8
  store i64 %v2100, ptr %slot383, align 8
  %v2101 = load i64, ptr %slot383, align 8
  %v2102 = load i64, ptr %slot382, align 8
  %p2103 = inttoptr i64 %v2101 to ptr
  %p2104 = inttoptr i64 %v2102 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2104, ptr %p2103, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot7, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 2, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot9, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i32, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2109, ptr %slot384, align 8
  %v2110 = load i32, ptr %slot384, align 8
  %v2111 = load i64, ptr %slot7, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i32 %v2110, ptr %p2112, align 4, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot8, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  store i32 0, ptr %p2114, align 4, !alias.scope !3, !noalias !4
  %v2115 = load i64, ptr %slot6, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i32 1, ptr %p2116, align 4, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot382, align 8
  %v2118 = load i64, ptr %slot17, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i64 %v2117, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  %v2120 = load i64, ptr %slot17, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i64, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2122, ptr %slot385, align 8
  %v2123 = load i64, ptr %slot17, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  %ld2125 = load i64, ptr %p2124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2125, ptr %slot386, align 8
  %v2126 = load i64, ptr %slot11, align 8
  store i64 %v2126, ptr %slot387, align 8
  %v2127 = load i64, ptr %slot24, align 8
  store i64 %v2127, ptr %slot388, align 8
  %v2128 = load i64, ptr %slot23, align 8
  %v2129 = load i64, ptr %slot387, align 8
  %v2130 = load i64, ptr %slot386, align 8
  %v2131 = load i64, ptr %slot388, align 8
  %cv2132 = trunc i64 %v2131 to i32
  %call2133 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v2128, i64 %v2129, i64 %v2130, i32 %cv2132) nomerge, !dbg !170
  store i32 %call2133, ptr %slot389, align 8
  %v2134 = load i32, ptr %slot389, align 8
  %cv2135 = zext i32 %v2134 to i64
  %cond2136 = icmp ne i64 %cv2135, 0
  br i1 %cond2136, label %bb_rcsuccess949, label %bb_rcfailure949
bb_rcfailure949:
  %v2137 = load i64, ptr %slot23, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %call2139 = call i32 @myl_rc_take_failure(ptr %p2138) nomerge, !dbg !170
  store i32 %call2139, ptr %slot390, align 8
  %v2140 = load i64, ptr %slot1, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %v2142 = load i32, ptr %slot390, align 8
  %call2143 = call i32 @myl_qbe_rc_status(ptr %p2141, i32 %v2142) nomerge, !dbg !170
  store i32 %call2143, ptr %slot391, align 8
  br label %bb_failure
bb_rcsuccess949:
  %v2144 = load i64, ptr %slot6, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  store i32 0, ptr %p2145, align 4, !alias.scope !3, !noalias !4
  %v2146 = load i64, ptr %slot9, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  store i32 2, ptr %p2147, align 4, !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot8, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  store i32 1, ptr %p2149, align 4, !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot11, align 8
  store i64 %v2150, ptr %slot392, align 8
  %v2151 = load i64, ptr %slot8, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i32 0, ptr %p2152, align 4, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot6, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i32, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2155, ptr %slot393, align 8
  %v2156 = load i32, ptr %slot393, align 8
  %cv2157 = zext i32 %v2156 to i64
  %cond2158 = icmp ne i64 %cv2157, 0
  br i1 %cond2158, label %bb_rcslotdrop959, label %bb_rcslotdone959
bb_rcslotdrop959:
  %v2159 = load i64, ptr %slot6, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  store i32 0, ptr %p2160, align 4, !alias.scope !3, !noalias !4
  %v2161 = load i64, ptr %slot10, align 8
  store i64 %v2161, ptr %slot394, align 8
  %v2162 = load i64, ptr %slot7, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  %ld2164 = load i32, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2164, ptr %slot395, align 8
  %v2165 = load i32, ptr %slot395, align 8
  %op2166 = and i32 %v2165, 28
  store i32 %op2166, ptr %slot396, align 8
  %v2167 = load i32, ptr %slot396, align 8
  %cv2168 = zext i32 %v2167 to i64
  %cond2169 = icmp ne i64 %cv2168, 0
  br i1 %cond2169, label %bb_rcslotrole959, label %bb_rcslotowner959
bb_rcslotrole959:
  %v2170 = load i64, ptr %slot23, align 8
  store i64 %v2170, ptr %slot397, align 8
  %v2171 = load i64, ptr %slot397, align 8
  %v2172 = load i64, ptr %slot394, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v2171, i64 %v2172) nomerge, !dbg !170
  br label %bb_rcslotdone959
bb_rcslotowner959:
  %v2173 = load i64, ptr %slot23, align 8
  store i64 %v2173, ptr %slot398, align 8
  %v2174 = load i64, ptr %slot398, align 8
  %v2175 = load i64, ptr %slot394, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v2174, i64 %v2175) nomerge, !dbg !170
  br label %bb_rcslotdone959
bb_rcslotdone959:
  %v2176 = load i64, ptr %slot392, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2177, i64 80, i1 false)
  ret void
bb_i66:
  %v2178 = load i64, ptr %slot17, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  store i64 0, ptr %p2179, align 8, !alias.scope !3, !noalias !4
  %v2180 = load i64, ptr %slot17, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %ld2182 = load i64, ptr %p2181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2182, ptr %slot399, align 8
  %v2183 = load i64, ptr %slot399, align 8
  %cond2184 = icmp ne i64 %v2183, 0
  br i1 %cond2184, label %bb_success1022, label %bb_failed1022
bb_failed1022:
  %v2185 = load i64, ptr %slot1, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  call void @myl_qbe_fail_assert(ptr %p2186) nomerge, !dbg !172
  unreachable
bb_success1022:
  %v2187 = load i64, ptr %slot12, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  %ld2189 = load i64, ptr %p2188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2189, ptr %slot400, align 8
  %v2190 = load i64, ptr %slot400, align 8
  %v2191 = load i64, ptr %slot17, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  store i64 %v2190, ptr %p2192, align 8, !alias.scope !3, !noalias !4
  %v2193 = load i64, ptr %slot13, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %ld2195 = load i64, ptr %p2194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2195, ptr %slot401, align 8
  %v2196 = load i64, ptr %slot401, align 8
  %v2197 = load i64, ptr %slot18, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i64 %v2196, ptr %p2198, align 8, !alias.scope !3, !noalias !4
  %v2199 = load i64, ptr %slot17, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot402, align 8
  %v2202 = load i64, ptr %slot18, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i64, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2204, ptr %slot403, align 8
  %v2205 = load i64, ptr %slot1, align 8
  %v2206 = load i64, ptr %slot402, align 8
  %v2207 = load i64, ptr %slot403, align 8
  call void @myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025(ptr sret([80 x i8]) align 8 %callresult405, i64 %v2205, i64 %v2206, i64 %v2207) nomerge, !dbg !174
  %addr2208 = ptrtoint ptr %callresult405 to i64
  store i64 %addr2208, ptr %slot404, align 8
  %v2209 = load i64, ptr %slot404, align 8
  %v2210 = load i64, ptr %slot17, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  store i64 %v2209, ptr %p2211, align 8, !alias.scope !3, !noalias !4
  %v2212 = load i64, ptr %slot17, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %ld2214 = load i64, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2214, ptr %slot406, align 8
  %v2215 = load i64, ptr %slot11, align 8
  store i64 %v2215, ptr %slot407, align 8
  %v2216 = load i64, ptr %slot406, align 8
  %v2217 = load i64, ptr %slot407, align 8
  %p2218 = inttoptr i64 %v2216 to ptr
  %p2219 = inttoptr i64 %v2217 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2219, ptr %p2218, i64 80, i1 false)
  %v2220 = load i64, ptr %slot9, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i32 2, ptr %p2221, align 4, !alias.scope !3, !noalias !4
  %v2222 = load i64, ptr %slot8, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i32 1, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot6, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i32, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2226, ptr %slot408, align 8
  %v2227 = load i32, ptr %slot408, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcslotdrop1034, label %bb_rcslotdone1034
bb_rcslotdrop1034:
  %v2230 = load i64, ptr %slot6, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  store i32 0, ptr %p2231, align 4, !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot10, align 8
  store i64 %v2232, ptr %slot409, align 8
  %v2233 = load i64, ptr %slot7, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i32, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2235, ptr %slot410, align 8
  %v2236 = load i32, ptr %slot410, align 8
  %op2237 = and i32 %v2236, 28
  store i32 %op2237, ptr %slot411, align 8
  %v2238 = load i32, ptr %slot411, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotrole1034, label %bb_rcslotowner1034
bb_rcslotrole1034:
  %v2241 = load i64, ptr %slot23, align 8
  store i64 %v2241, ptr %slot412, align 8
  %v2242 = load i64, ptr %slot412, align 8
  %v2243 = load i64, ptr %slot409, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2242, i64 %v2243) nomerge, !dbg !174
  br label %bb_rcslotdone1034
bb_rcslotowner1034:
  %v2244 = load i64, ptr %slot23, align 8
  store i64 %v2244, ptr %slot413, align 8
  %v2245 = load i64, ptr %slot413, align 8
  %v2246 = load i64, ptr %slot409, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2245, i64 %v2246) nomerge, !dbg !174
  br label %bb_rcslotdone1034
bb_rcslotdone1034:
  %v2247 = load i64, ptr %slot10, align 8
  store i64 %v2247, ptr %slot414, align 8
  %v2248 = load i64, ptr %slot11, align 8
  store i64 %v2248, ptr %slot415, align 8
  %v2249 = load i64, ptr %slot415, align 8
  %v2250 = load i64, ptr %slot414, align 8
  %p2251 = inttoptr i64 %v2249 to ptr
  %p2252 = inttoptr i64 %v2250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2252, ptr %p2251, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot7, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i32 2, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot9, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %ld2257 = load i32, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2257, ptr %slot416, align 8
  %v2258 = load i32, ptr %slot416, align 8
  %v2259 = load i64, ptr %slot7, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i32 %v2258, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot8, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  store i32 0, ptr %p2262, align 4, !alias.scope !3, !noalias !4
  %v2263 = load i64, ptr %slot6, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i32 1, ptr %p2264, align 4, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot414, align 8
  %v2266 = load i64, ptr %slot17, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  store i64 %v2265, ptr %p2267, align 8, !alias.scope !3, !noalias !4
  %v2268 = load i64, ptr %slot17, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %ld2270 = load i64, ptr %p2269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2270, ptr %slot417, align 8
  %v2271 = load i64, ptr %slot17, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  %ld2273 = load i64, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2273, ptr %slot418, align 8
  %v2274 = load i64, ptr %slot11, align 8
  store i64 %v2274, ptr %slot419, align 8
  %v2275 = load i64, ptr %slot24, align 8
  store i64 %v2275, ptr %slot420, align 8
  %v2276 = load i64, ptr %slot23, align 8
  %v2277 = load i64, ptr %slot419, align 8
  %v2278 = load i64, ptr %slot418, align 8
  %v2279 = load i64, ptr %slot420, align 8
  %cv2280 = trunc i64 %v2279 to i32
  %call2281 = call i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64 %v2276, i64 %v2277, i64 %v2278, i32 %cv2280) nomerge, !dbg !176
  store i32 %call2281, ptr %slot421, align 8
  %v2282 = load i32, ptr %slot421, align 8
  %cv2283 = zext i32 %v2282 to i64
  %cond2284 = icmp ne i64 %cv2283, 0
  br i1 %cond2284, label %bb_rcsuccess1054, label %bb_rcfailure1054
bb_rcfailure1054:
  %v2285 = load i64, ptr %slot23, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %call2287 = call i32 @myl_rc_take_failure(ptr %p2286) nomerge, !dbg !176
  store i32 %call2287, ptr %slot422, align 8
  %v2288 = load i64, ptr %slot1, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  %v2290 = load i32, ptr %slot422, align 8
  %call2291 = call i32 @myl_qbe_rc_status(ptr %p2289, i32 %v2290) nomerge, !dbg !176
  store i32 %call2291, ptr %slot423, align 8
  br label %bb_failure
bb_rcsuccess1054:
  %v2292 = load i64, ptr %slot6, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i32 0, ptr %p2293, align 4, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot9, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i32 2, ptr %p2295, align 4, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot8, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i32 1, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  %v2298 = load i64, ptr %slot11, align 8
  store i64 %v2298, ptr %slot424, align 8
  %v2299 = load i64, ptr %slot8, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  store i32 0, ptr %p2300, align 4, !alias.scope !3, !noalias !4
  %v2301 = load i64, ptr %slot6, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %ld2303 = load i32, ptr %p2302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2303, ptr %slot425, align 8
  %v2304 = load i32, ptr %slot425, align 8
  %cv2305 = zext i32 %v2304 to i64
  %cond2306 = icmp ne i64 %cv2305, 0
  br i1 %cond2306, label %bb_rcslotdrop1064, label %bb_rcslotdone1064
bb_rcslotdrop1064:
  %v2307 = load i64, ptr %slot6, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i32 0, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot10, align 8
  store i64 %v2309, ptr %slot426, align 8
  %v2310 = load i64, ptr %slot7, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %ld2312 = load i32, ptr %p2311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2312, ptr %slot427, align 8
  %v2313 = load i32, ptr %slot427, align 8
  %op2314 = and i32 %v2313, 28
  store i32 %op2314, ptr %slot428, align 8
  %v2315 = load i32, ptr %slot428, align 8
  %cv2316 = zext i32 %v2315 to i64
  %cond2317 = icmp ne i64 %cv2316, 0
  br i1 %cond2317, label %bb_rcslotrole1064, label %bb_rcslotowner1064
bb_rcslotrole1064:
  %v2318 = load i64, ptr %slot23, align 8
  store i64 %v2318, ptr %slot429, align 8
  %v2319 = load i64, ptr %slot429, align 8
  %v2320 = load i64, ptr %slot426, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64 %v2319, i64 %v2320) nomerge, !dbg !176
  br label %bb_rcslotdone1064
bb_rcslotowner1064:
  %v2321 = load i64, ptr %slot23, align 8
  store i64 %v2321, ptr %slot430, align 8
  %v2322 = load i64, ptr %slot430, align 8
  %v2323 = load i64, ptr %slot426, align 8
  call void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64 %v2322, i64 %v2323) nomerge, !dbg !176
  br label %bb_rcslotdone1064
bb_rcslotdone1064:
  %v2324 = load i64, ptr %slot424, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2325, i64 80, i1 false)
  ret void
bb_failure:
  %v2326 = load i64, ptr %slot5, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  call void @llvm.memset.p0.i64(ptr %p2327, i8 0, i64 80, i1 false), !alias.scope !3, !noalias !4, !dbg !176
  %v2328 = load i64, ptr %slot5, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2329, i64 80, i1 false)
  ret void
bb_entry_failure:
  %v2330 = load i64, ptr %slot5, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  call void @llvm.memset.p0.i64(ptr %p2331, i8 0, i64 80, i1 false), !alias.scope !3, !noalias !4, !dbg !176
  %v2332 = load i64, ptr %slot5, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2333, i64 80, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_drop(i64, i64)
declare i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_take(i64, i64, i64, i32)
declare void @myl_t_936ef1df8ee9b22aeeca81bdacc17d611f5ed2ee4d8f92454f4592a600eb217d_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025", linkageName: "myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2669082752185175069, i64 0, !"myl_f_996504a15107f108adb8cb6652f4edf47ba84c40d82f47a23c59d7781db12025"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!128 = !DILocation(line: 24, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!136 = !DILocation(line: 32, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!140 = !DILocation(line: 36, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!142 = !DILocation(line: 38, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!144 = !DILocation(line: 41, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!146 = !DILocation(line: 42, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!148 = !DILocation(line: 44, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!150 = !DILocation(line: 47, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!152 = !DILocation(line: 48, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!154 = !DILocation(line: 50, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!156 = !DILocation(line: 53, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!158 = !DILocation(line: 54, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!160 = !DILocation(line: 56, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!162 = !DILocation(line: 59, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!164 = !DILocation(line: 60, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!166 = !DILocation(line: 62, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!168 = !DILocation(line: 65, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!170 = !DILocation(line: 66, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!172 = !DILocation(line: 68, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!174 = !DILocation(line: 71, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!176 = !DILocation(line: 72, column: 0, scope: !177)
