target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %callresult41 = alloca [24 x i8], align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %callresult315 = alloca [16 x i8], align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %callresult511 = alloca [16 x i8], align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v615 = load i64, ptr %slot1, align 8
  %op616 = add i64 %v615, 32
  store i64 %op616, ptr %slot4, align 8
  %mem617 = alloca i8, i64 24, align 8
  %ptr618 = ptrtoint ptr %mem617 to i64
  store i64 %ptr618, ptr %slot5, align 8
  %mem619 = alloca i8, i64 8, align 8
  %ptr620 = ptrtoint ptr %mem619 to i64
  store i64 %ptr620, ptr %slot6, align 8
  %mem621 = alloca i8, i64 8, align 8
  %ptr622 = ptrtoint ptr %mem621 to i64
  store i64 %ptr622, ptr %slot7, align 8
  %mem623 = alloca i8, i64 8, align 8
  %ptr624 = ptrtoint ptr %mem623 to i64
  store i64 %ptr624, ptr %slot8, align 8
  %mem625 = alloca i8, i64 8, align 8
  %ptr626 = ptrtoint ptr %mem625 to i64
  store i64 %ptr626, ptr %slot9, align 8
  %mem627 = alloca i8, i64 8, align 8
  %ptr628 = ptrtoint ptr %mem627 to i64
  store i64 %ptr628, ptr %slot10, align 8
  %mem629 = alloca i8, i64 8, align 8
  %ptr630 = ptrtoint ptr %mem629 to i64
  store i64 %ptr630, ptr %slot11, align 8
  %mem631 = alloca i8, i64 8, align 8
  %ptr632 = ptrtoint ptr %mem631 to i64
  store i64 %ptr632, ptr %slot12, align 8
  %mem633 = alloca i8, i64 304, align 8
  %ptr634 = ptrtoint ptr %mem633 to i64
  store i64 %ptr634, ptr %slot13, align 8
  %mem635 = alloca i8, i64 8, align 8
  %ptr636 = ptrtoint ptr %mem635 to i64
  store i64 %ptr636, ptr %slot14, align 8
  %mem637 = alloca i8, i64 304, align 8
  %ptr638 = ptrtoint ptr %mem637 to i64
  store i64 %ptr638, ptr %slot15, align 8
  %mem639 = alloca i8, i64 8, align 8
  %ptr640 = ptrtoint ptr %mem639 to i64
  store i64 %ptr640, ptr %slot16, align 8
  %mem641 = alloca i8, i64 8, align 8
  %ptr642 = ptrtoint ptr %mem641 to i64
  store i64 %ptr642, ptr %slot17, align 8
  %mem643 = alloca i8, i64 8, align 8
  %ptr644 = ptrtoint ptr %mem643 to i64
  store i64 %ptr644, ptr %slot18, align 8
  %mem645 = alloca i8, i64 8, align 8
  %ptr646 = ptrtoint ptr %mem645 to i64
  store i64 %ptr646, ptr %slot19, align 8
  %mem647 = alloca i8, i64 8, align 8
  %ptr648 = ptrtoint ptr %mem647 to i64
  store i64 %ptr648, ptr %slot20, align 8
  %mem649 = alloca i8, i64 64, align 8
  %ptr650 = ptrtoint ptr %mem649 to i64
  store i64 %ptr650, ptr %slot21, align 8
  %mem651 = alloca i8, i64 8, align 8
  %ptr652 = ptrtoint ptr %mem651 to i64
  store i64 %ptr652, ptr %slot22, align 8
  %mem653 = alloca i8, i64 8, align 8
  %ptr654 = ptrtoint ptr %mem653 to i64
  store i64 %ptr654, ptr %slot23, align 8
  %mem655 = alloca i8, i64 8, align 8
  %ptr656 = ptrtoint ptr %mem655 to i64
  store i64 %ptr656, ptr %slot24, align 8
  %mem657 = alloca i8, i64 8, align 8
  %ptr658 = ptrtoint ptr %mem657 to i64
  store i64 %ptr658, ptr %slot25, align 8
  %mem659 = alloca i8, i64 8, align 8
  %ptr660 = ptrtoint ptr %mem659 to i64
  store i64 %ptr660, ptr %slot26, align 8
  %mem661 = alloca i8, i64 24, align 8
  %ptr662 = ptrtoint ptr %mem661 to i64
  store i64 %ptr662, ptr %slot27, align 8
  %mem663 = alloca i8, i64 24, align 8
  %ptr664 = ptrtoint ptr %mem663 to i64
  store i64 %ptr664, ptr %slot28, align 8
  %mem665 = alloca i8, i64 24, align 8
  %ptr666 = ptrtoint ptr %mem665 to i64
  store i64 %ptr666, ptr %slot29, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem667 = alloca i8, i64 8, align 8
  %ptr668 = ptrtoint ptr %mem667 to i64
  store i64 %ptr668, ptr %slot30, align 8
  %v669 = load i64, ptr %slot1, align 8
  %op670 = add i64 %v669, 64
  store i64 %op670, ptr %slot31, align 8
  %v671 = load i64, ptr %slot31, align 8
  %p672 = inttoptr i64 %v671 to ptr
  %ld673 = load i64, ptr %p672, align 8, !alias.scope !4, !noalias !3
  store i64 %ld673, ptr %slot32, align 8
  %stack674 = call ptr @llvm.stacksave()
  %stackaddr675 = ptrtoint ptr %stack674 to i64
  %v676 = load i64, ptr %slot32, align 8
  %cmp677 = icmp ult i64 %stackaddr675, %v676
  %cv678 = zext i1 %cmp677 to i64
  store i64 %cv678, ptr %slot33, align 8
  %v679 = load i64, ptr %slot33, align 8
  %cond680 = icmp ne i64 %v679, 0
  br i1 %cond680, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v681 = load i64, ptr %slot1, align 8
  %p682 = inttoptr i64 %v681 to ptr
  call void @myl_qbe_fail_frame(ptr %p682) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v683 = load i64, ptr %slot19, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i64 0, ptr %p684, align 8, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot23, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 0, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot2, align 8
  %v688 = load i64, ptr %slot16, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 %v687, ptr %p689, align 8, !alias.scope !3, !noalias !4
  %v690 = load i64, ptr %slot3, align 8
  %v691 = load i64, ptr %slot17, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot1, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %call695 = call ptr @myl_qbe_heap(ptr %p694) nomerge, !dbg !112
  %calladdr696 = ptrtoint ptr %call695 to i64
  store i64 %calladdr696, ptr %slot34, align 8
  %v697 = load i64, ptr %slot1, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %call699 = call i64 @myl_qbe_region_mark(ptr %p698) nomerge, !dbg !112
  store i64 %call699, ptr %slot35, align 8
  %v700 = load i64, ptr %slot6, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i32 0, ptr %p701, align 4, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot7, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i32 0, ptr %p703, align 4, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot8, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i32 0, ptr %p705, align 4, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot9, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i32 0, ptr %p707, align 4, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot10, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i32 0, ptr %p709, align 4, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot11, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i32 0, ptr %p711, align 4, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot12, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i32 0, ptr %p713, align 4, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot7, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i32 2, ptr %p715, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v716 = load i64, ptr %slot16, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot36, align 8
  %v719 = load i64, ptr %slot36, align 8
  %v720 = load i64, ptr %slot25, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i64 %v719, ptr %p721, align 8, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot17, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %ld724 = load i64, ptr %p723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld724, ptr %slot37, align 8
  %v725 = load i64, ptr %slot37, align 8
  %v726 = load i64, ptr %slot26, align 8
  %p727 = inttoptr i64 %v726 to ptr
  store i64 %v725, ptr %p727, align 8, !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot25, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %ld730 = load i64, ptr %p729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld730, ptr %slot38, align 8
  %v731 = load i64, ptr %slot26, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i64, ptr %p732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld733, ptr %slot39, align 8
  %v734 = load i64, ptr %slot1, align 8
  %v735 = load i64, ptr %slot38, align 8
  %v736 = load i64, ptr %slot39, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult41, i64 %v734, i64 %v735, i64 %v736) nomerge, !dbg !114
  %addr737 = ptrtoint ptr %callresult41 to i64
  store i64 %addr737, ptr %slot40, align 8
  %v738 = load i64, ptr %slot40, align 8
  %v739 = load i64, ptr %slot25, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i64 %v738, ptr %p740, align 8, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot25, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld743, ptr %slot42, align 8
  %v744 = load i64, ptr %slot15, align 8
  store i64 %v744, ptr %slot43, align 8
  %v745 = load i64, ptr %slot42, align 8
  %v746 = load i64, ptr %slot43, align 8
  %p747 = inttoptr i64 %v745 to ptr
  %p748 = inttoptr i64 %v746 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p748, ptr %p747, i64 24, i1 false)
  %v749 = load i64, ptr %slot11, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i32 2, ptr %p750, align 4, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot10, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i32 1, ptr %p752, align 4, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot8, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ld755 = load i32, ptr %p754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld755, ptr %slot44, align 8
  %v756 = load i32, ptr %slot44, align 8
  %cv757 = zext i32 %v756 to i64
  %cond758 = icmp ne i64 %cv757, 0
  br i1 %cond758, label %bb_rcslotdrop22, label %bb_rcslotdone22
bb_rcslotdrop22:
  %v759 = load i64, ptr %slot8, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i32 0, ptr %p760, align 4, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot13, align 8
  store i64 %v761, ptr %slot45, align 8
  %v762 = load i64, ptr %slot9, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %ld764 = load i32, ptr %p763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld764, ptr %slot46, align 8
  %v765 = load i32, ptr %slot46, align 8
  %op766 = and i32 %v765, 28
  store i32 %op766, ptr %slot47, align 8
  %v767 = load i32, ptr %slot47, align 8
  %cv768 = zext i32 %v767 to i64
  %cond769 = icmp ne i64 %cv768, 0
  br i1 %cond769, label %bb_rcslotrole22, label %bb_rcslotowner22
bb_rcslotrole22:
  %v770 = load i64, ptr %slot34, align 8
  store i64 %v770, ptr %slot48, align 8
  %v771 = load i64, ptr %slot48, align 8
  %v772 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v771, i64 %v772) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotowner22:
  %v773 = load i64, ptr %slot34, align 8
  store i64 %v773, ptr %slot49, align 8
  %v774 = load i64, ptr %slot49, align 8
  %v775 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v774, i64 %v775) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotdone22:
  %v776 = load i64, ptr %slot13, align 8
  store i64 %v776, ptr %slot50, align 8
  %v777 = load i64, ptr %slot15, align 8
  store i64 %v777, ptr %slot51, align 8
  %v778 = load i64, ptr %slot51, align 8
  %v779 = load i64, ptr %slot50, align 8
  %p780 = inttoptr i64 %v778 to ptr
  %p781 = inttoptr i64 %v779 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p781, ptr %p780, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot9, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i32 2, ptr %p783, align 4, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot11, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %ld786 = load i32, ptr %p785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld786, ptr %slot52, align 8
  %v787 = load i32, ptr %slot52, align 8
  %v788 = load i64, ptr %slot9, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 %v787, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot10, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i32 0, ptr %p791, align 4, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot8, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i32 1, ptr %p793, align 4, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot50, align 8
  %v795 = load i64, ptr %slot25, align 8
  %p796 = inttoptr i64 %v795 to ptr
  store i64 %v794, ptr %p796, align 8, !alias.scope !3, !noalias !4
  %v797 = load i64, ptr %slot25, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %ld799 = load i64, ptr %p798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld799, ptr %slot53, align 8
  %v800 = load i64, ptr %slot53, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i32, ptr %p801, align 4
  %ext803 = zext i32 %ld802 to i64
  store i64 %ext803, ptr %slot54, align 8
  %v804 = load i64, ptr %slot54, align 8
  %cmp805 = icmp eq i64 %v804, 0
  %cv806 = zext i1 %cmp805 to i64
  store i64 %cv806, ptr %slot55, align 8
  %v807 = load i64, ptr %slot55, align 8
  %cond808 = icmp ne i64 %v807, 0
  br i1 %cond808, label %bb_rctryok38, label %bb_rctryerror38
bb_rctryerror38:
  %p809 = inttoptr i64 ptrtoint (ptr @myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p809, i64 12884901891) "call-inline-cost"="0", !dbg !116
  %v810 = load i64, ptr %slot53, align 8
  %op811 = add i64 %v810, 8
  store i64 %op811, ptr %slot56, align 8
  %v812 = load i64, ptr %slot27, align 8
  store i64 %v812, ptr %slot57, align 8
  %v813 = load i64, ptr %slot57, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i64 0, ptr %p814, align 8, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot57, align 8
  %p817 = inttoptr i64 %v815 to ptr
  %gep818 = getelementptr i8, ptr %p817, i64 8
  %op816 = ptrtoint ptr %gep818 to i64
  store i64 %op816, ptr %slot58, align 8
  %v819 = load i64, ptr %slot58, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i64 0, ptr %p820, align 8, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot57, align 8
  %p823 = inttoptr i64 %v821 to ptr
  %gep824 = getelementptr i8, ptr %p823, i64 16
  %op822 = ptrtoint ptr %gep824 to i64
  store i64 %op822, ptr %slot59, align 8
  %v825 = load i64, ptr %slot59, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i64 0, ptr %p826, align 8, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot57, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 1, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot57, align 8
  %p831 = inttoptr i64 %v829 to ptr
  %gep832 = getelementptr i8, ptr %p831, i64 8
  %op830 = ptrtoint ptr %gep832 to i64
  store i64 %op830, ptr %slot60, align 8
  %v833 = load i64, ptr %slot12, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i32 1, ptr %p834, align 4, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot35, align 8
  store i64 %v835, ptr %slot61, align 8
  %v836 = load i64, ptr %slot34, align 8
  %v837 = load i64, ptr %slot60, align 8
  %v838 = load i64, ptr %slot56, align 8
  %v839 = load i64, ptr %slot61, align 8
  %cv840 = trunc i64 %v839 to i32
  %call841 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v836, i64 %v837, i64 %v838, i32 %cv840) nomerge, !dbg !116
  store i32 %call841, ptr %slot62, align 8
  %v842 = load i32, ptr %slot62, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcsuccess49, label %bb_rcfailure49
bb_rcfailure49:
  %v845 = load i64, ptr %slot34, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %call847 = call i32 @myl_rc_take_failure(ptr %p846) nomerge, !dbg !116
  store i32 %call847, ptr %slot63, align 8
  %v848 = load i64, ptr %slot1, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %v850 = load i32, ptr %slot63, align 8
  %call851 = call i32 @myl_qbe_rc_status(ptr %p849, i32 %v850) nomerge, !dbg !116
  store i32 %call851, ptr %slot64, align 8
  br label %bb_failure
bb_rcsuccess49:
  %v852 = load i64, ptr %slot57, align 8
  %v853 = load i64, ptr %slot25, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i64 %v852, ptr %p854, align 8, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot25, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i64, ptr %p856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld857, ptr %slot65, align 8
  %v858 = load i64, ptr %slot15, align 8
  store i64 %v858, ptr %slot66, align 8
  %v859 = load i64, ptr %slot65, align 8
  %v860 = load i64, ptr %slot66, align 8
  %p861 = inttoptr i64 %v859 to ptr
  %p862 = inttoptr i64 %v860 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p862, ptr %p861, i64 24, i1 false)
  %v863 = load i64, ptr %slot11, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i32 2, ptr %p864, align 4, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot10, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i32 1, ptr %p866, align 4, !alias.scope !3, !noalias !4
  %v867 = load i64, ptr %slot8, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %ld869 = load i32, ptr %p868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld869, ptr %slot67, align 8
  %v870 = load i32, ptr %slot67, align 8
  %cv871 = zext i32 %v870 to i64
  %cond872 = icmp ne i64 %cv871, 0
  br i1 %cond872, label %bb_rcslotdrop58, label %bb_rcslotdone58
bb_rcslotdrop58:
  %v873 = load i64, ptr %slot8, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i32 0, ptr %p874, align 4, !alias.scope !3, !noalias !4
  %v875 = load i64, ptr %slot13, align 8
  store i64 %v875, ptr %slot68, align 8
  %v876 = load i64, ptr %slot9, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i32, ptr %p877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld878, ptr %slot69, align 8
  %v879 = load i32, ptr %slot69, align 8
  %op880 = and i32 %v879, 28
  store i32 %op880, ptr %slot70, align 8
  %v881 = load i32, ptr %slot70, align 8
  %cv882 = zext i32 %v881 to i64
  %cond883 = icmp ne i64 %cv882, 0
  br i1 %cond883, label %bb_rcslotrole58, label %bb_rcslotowner58
bb_rcslotrole58:
  %v884 = load i64, ptr %slot34, align 8
  store i64 %v884, ptr %slot71, align 8
  %v885 = load i64, ptr %slot71, align 8
  %v886 = load i64, ptr %slot68, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v885, i64 %v886) nomerge, !dbg !116
  br label %bb_rcslotdone58
bb_rcslotowner58:
  %v887 = load i64, ptr %slot34, align 8
  store i64 %v887, ptr %slot72, align 8
  %v888 = load i64, ptr %slot72, align 8
  %v889 = load i64, ptr %slot68, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v888, i64 %v889) nomerge, !dbg !116
  br label %bb_rcslotdone58
bb_rcslotdone58:
  %v890 = load i64, ptr %slot13, align 8
  store i64 %v890, ptr %slot73, align 8
  %v891 = load i64, ptr %slot15, align 8
  store i64 %v891, ptr %slot74, align 8
  %v892 = load i64, ptr %slot74, align 8
  %v893 = load i64, ptr %slot73, align 8
  %p894 = inttoptr i64 %v892 to ptr
  %p895 = inttoptr i64 %v893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p895, ptr %p894, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot9, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 2, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot11, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %ld900 = load i32, ptr %p899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld900, ptr %slot75, align 8
  %v901 = load i32, ptr %slot75, align 8
  %v902 = load i64, ptr %slot9, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i32 %v901, ptr %p903, align 4, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot10, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 0, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot8, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 1, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot73, align 8
  %v909 = load i64, ptr %slot25, align 8
  %p910 = inttoptr i64 %v909 to ptr
  store i64 %v908, ptr %p910, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_rctryok38:
  %v911 = load i64, ptr %slot27, align 8
  store i64 %v911, ptr %slot76, align 8
  %v912 = load i64, ptr %slot12, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 1, ptr %p913, align 4, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot53, align 8
  %op915 = add i64 %v914, 8
  store i64 %op915, ptr %slot77, align 8
  %v916 = load i64, ptr %slot35, align 8
  store i64 %v916, ptr %slot78, align 8
  store i64 0, ptr %slot79, align 8
  store i64 0, ptr %slot80, align 8
  %v917 = load i64, ptr %slot80, align 8
  %v918 = load i64, ptr %slot25, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i64 %v917, ptr %p919, align 8, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot8, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ld922 = load i32, ptr %p921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld922, ptr %slot81, align 8
  %v923 = load i32, ptr %slot81, align 8
  %cv924 = zext i32 %v923 to i64
  %cond925 = icmp ne i64 %cv924, 0
  br i1 %cond925, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v926 = load i64, ptr %slot8, align 8
  %p927 = inttoptr i64 %v926 to ptr
  store i32 0, ptr %p927, align 4, !alias.scope !3, !noalias !4
  %v928 = load i64, ptr %slot13, align 8
  store i64 %v928, ptr %slot82, align 8
  %v929 = load i64, ptr %slot9, align 8
  %p930 = inttoptr i64 %v929 to ptr
  %ld931 = load i32, ptr %p930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld931, ptr %slot83, align 8
  %v932 = load i32, ptr %slot83, align 8
  %op933 = and i32 %v932, 28
  store i32 %op933, ptr %slot84, align 8
  %v934 = load i32, ptr %slot84, align 8
  %cv935 = zext i32 %v934 to i64
  %cond936 = icmp ne i64 %cv935, 0
  br i1 %cond936, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v937 = load i64, ptr %slot34, align 8
  store i64 %v937, ptr %slot85, align 8
  %v938 = load i64, ptr %slot85, align 8
  %v939 = load i64, ptr %slot82, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v938, i64 %v939) nomerge, !dbg !116
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v940 = load i64, ptr %slot34, align 8
  store i64 %v940, ptr %slot86, align 8
  %v941 = load i64, ptr %slot86, align 8
  %v942 = load i64, ptr %slot82, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v941, i64 %v942) nomerge, !dbg !116
  br label %bb_rcslotdone82
bb_rcslotdone82:
  br label %bb_i6
bb_i5:
  %v943 = load i64, ptr %slot25, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %ld945 = load i64, ptr %p944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld945, ptr %slot87, align 8
  %v946 = load i64, ptr %slot25, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %ld948 = load i64, ptr %p947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld948, ptr %slot88, align 8
  %v949 = load i64, ptr %slot8, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ld951 = load i32, ptr %p950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld951, ptr %slot89, align 8
  %v952 = load i64, ptr %slot9, align 8
  %p953 = inttoptr i64 %v952 to ptr
  %ld954 = load i32, ptr %p953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld954, ptr %slot90, align 8
  %v955 = load i32, ptr %slot90, align 8
  %op956 = and i32 %v955, 24
  store i32 %op956, ptr %slot90, align 8
  %v957 = load i32, ptr %slot90, align 8
  %cmp958 = icmp eq i32 %v957, 0
  %cv959 = zext i1 %cmp958 to i32
  store i32 %cv959, ptr %slot91, align 8
  %v960 = load i32, ptr %slot89, align 8
  %v961 = load i32, ptr %slot91, align 8
  %op962 = and i32 %v960, %v961
  store i32 %op962, ptr %slot92, align 8
  %v963 = load i32, ptr %slot92, align 8
  %cv964 = zext i32 %v963 to i64
  %cond965 = icmp ne i64 %cv964, 0
  br i1 %cond965, label %bb_rctake91, label %bb_rccopy91
bb_rctake91:
  %v966 = load i64, ptr %slot15, align 8
  store i64 %v966, ptr %slot93, align 8
  %v967 = load i64, ptr %slot35, align 8
  store i64 %v967, ptr %slot94, align 8
  %v968 = load i64, ptr %slot34, align 8
  %v969 = load i64, ptr %slot93, align 8
  %v970 = load i64, ptr %slot88, align 8
  %v971 = load i64, ptr %slot94, align 8
  %cv972 = trunc i64 %v971 to i32
  %call973 = call i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_take(i64 %v968, i64 %v969, i64 %v970, i32 %cv972) nomerge, !dbg !118
  store i32 %call973, ptr %slot95, align 8
  %v974 = load i32, ptr %slot95, align 8
  %cv975 = zext i32 %v974 to i64
  %cond976 = icmp ne i64 %cv975, 0
  br i1 %cond976, label %bb_rcsuccess101, label %bb_rcfailure101
bb_rcfailure101:
  %v977 = load i64, ptr %slot34, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %call979 = call i32 @myl_rc_take_failure(ptr %p978) nomerge, !dbg !118
  store i32 %call979, ptr %slot96, align 8
  %v980 = load i64, ptr %slot1, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %v982 = load i32, ptr %slot96, align 8
  %call983 = call i32 @myl_qbe_rc_status(ptr %p981, i32 %v982) nomerge, !dbg !118
  store i32 %call983, ptr %slot97, align 8
  br label %bb_failure
bb_rcsuccess101:
  %v984 = load i64, ptr %slot8, align 8
  %p985 = inttoptr i64 %v984 to ptr
  store i32 0, ptr %p985, align 4, !alias.scope !3, !noalias !4
  %v986 = load i64, ptr %slot11, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i32 2, ptr %p987, align 4, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot10, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i32 1, ptr %p989, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared91
bb_rccopy91:
  %v990 = load i64, ptr %slot15, align 8
  store i64 %v990, ptr %slot98, align 8
  %v991 = load i64, ptr %slot35, align 8
  store i64 %v991, ptr %slot99, align 8
  %v992 = load i64, ptr %slot34, align 8
  %v993 = load i64, ptr %slot98, align 8
  %v994 = load i64, ptr %slot88, align 8
  %v995 = load i64, ptr %slot99, align 8
  %cv996 = trunc i64 %v995 to i32
  %call997 = call i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_retain(i64 %v992, i64 %v993, i64 %v994, i32 %cv996) nomerge, !dbg !118
  store i32 %call997, ptr %slot100, align 8
  %v998 = load i32, ptr %slot100, align 8
  %cv999 = zext i32 %v998 to i64
  %cond1000 = icmp ne i64 %cv999, 0
  br i1 %cond1000, label %bb_rcsuccess110, label %bb_rcfailure110
bb_rcfailure110:
  %v1001 = load i64, ptr %slot34, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %call1003 = call i32 @myl_rc_take_failure(ptr %p1002) nomerge, !dbg !118
  store i32 %call1003, ptr %slot101, align 8
  %v1004 = load i64, ptr %slot1, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  %v1006 = load i32, ptr %slot101, align 8
  %call1007 = call i32 @myl_qbe_rc_status(ptr %p1005, i32 %v1006) nomerge, !dbg !118
  store i32 %call1007, ptr %slot102, align 8
  br label %bb_failure
bb_rcsuccess110:
  %v1008 = load i64, ptr %slot11, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i32 2, ptr %p1009, align 4, !alias.scope !3, !noalias !4
  %v1010 = load i64, ptr %slot10, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  store i32 1, ptr %p1011, align 4, !alias.scope !3, !noalias !4
  %v1012 = load i64, ptr %slot8, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %ld1014 = load i32, ptr %p1013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1014, ptr %slot103, align 8
  %v1015 = load i32, ptr %slot103, align 8
  %cv1016 = zext i32 %v1015 to i64
  %cond1017 = icmp ne i64 %cv1016, 0
  br i1 %cond1017, label %bb_rcslotdrop117, label %bb_rcslotdone117
bb_rcslotdrop117:
  %v1018 = load i64, ptr %slot8, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  store i32 0, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  %v1020 = load i64, ptr %slot13, align 8
  store i64 %v1020, ptr %slot104, align 8
  %v1021 = load i64, ptr %slot9, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i32, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1023, ptr %slot105, align 8
  %v1024 = load i32, ptr %slot105, align 8
  %op1025 = and i32 %v1024, 28
  store i32 %op1025, ptr %slot106, align 8
  %v1026 = load i32, ptr %slot106, align 8
  %cv1027 = zext i32 %v1026 to i64
  %cond1028 = icmp ne i64 %cv1027, 0
  br i1 %cond1028, label %bb_rcslotrole117, label %bb_rcslotowner117
bb_rcslotrole117:
  %v1029 = load i64, ptr %slot34, align 8
  store i64 %v1029, ptr %slot107, align 8
  %v1030 = load i64, ptr %slot107, align 8
  %v1031 = load i64, ptr %slot104, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v1030, i64 %v1031) nomerge, !dbg !118
  br label %bb_rcslotdone117
bb_rcslotowner117:
  %v1032 = load i64, ptr %slot34, align 8
  store i64 %v1032, ptr %slot108, align 8
  %v1033 = load i64, ptr %slot108, align 8
  %v1034 = load i64, ptr %slot104, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v1033, i64 %v1034) nomerge, !dbg !118
  br label %bb_rcslotdone117
bb_rcslotdone117:
  br label %bb_rcprepared91
bb_rcprepared91:
  %v1035 = load i64, ptr %slot15, align 8
  store i64 %v1035, ptr %slot109, align 8
  %v1036 = load i64, ptr %slot10, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i32 0, ptr %p1037, align 4, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot8, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %ld1040 = load i32, ptr %p1039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1040, ptr %slot110, align 8
  %v1041 = load i32, ptr %slot110, align 8
  %cv1042 = zext i32 %v1041 to i64
  %cond1043 = icmp ne i64 %cv1042, 0
  br i1 %cond1043, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1044 = load i64, ptr %slot8, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 0, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot13, align 8
  store i64 %v1046, ptr %slot111, align 8
  %v1047 = load i64, ptr %slot9, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  %ld1049 = load i32, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1049, ptr %slot112, align 8
  %v1050 = load i32, ptr %slot112, align 8
  %op1051 = and i32 %v1050, 28
  store i32 %op1051, ptr %slot113, align 8
  %v1052 = load i32, ptr %slot113, align 8
  %cv1053 = zext i32 %v1052 to i64
  %cond1054 = icmp ne i64 %cv1053, 0
  br i1 %cond1054, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1055 = load i64, ptr %slot34, align 8
  store i64 %v1055, ptr %slot114, align 8
  %v1056 = load i64, ptr %slot114, align 8
  %v1057 = load i64, ptr %slot111, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v1056, i64 %v1057) nomerge, !dbg !118
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1058 = load i64, ptr %slot34, align 8
  store i64 %v1058, ptr %slot115, align 8
  %v1059 = load i64, ptr %slot115, align 8
  %v1060 = load i64, ptr %slot111, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v1059, i64 %v1060) nomerge, !dbg !118
  br label %bb_rcslotdone128
bb_rcslotdone128:
  %v1061 = load i64, ptr %slot6, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %ld1063 = load i32, ptr %p1062, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1063, ptr %slot116, align 8
  %v1064 = load i32, ptr %slot116, align 8
  %cv1065 = zext i32 %v1064 to i64
  %cond1066 = icmp ne i64 %cv1065, 0
  br i1 %cond1066, label %bb_rcslotdrop174, label %bb_rcslotdone174
bb_rcslotdrop174:
  %v1067 = load i64, ptr %slot6, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i32 0, ptr %p1068, align 4, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot21, align 8
  store i64 %v1069, ptr %slot117, align 8
  %v1070 = load i64, ptr %slot7, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %ld1072 = load i32, ptr %p1071, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1072, ptr %slot118, align 8
  %v1073 = load i32, ptr %slot118, align 8
  %op1074 = and i32 %v1073, 28
  store i32 %op1074, ptr %slot119, align 8
  %v1075 = load i32, ptr %slot119, align 8
  %cv1076 = zext i32 %v1075 to i64
  %cond1077 = icmp ne i64 %cv1076, 0
  br i1 %cond1077, label %bb_rcslotrole174, label %bb_rcslotowner174
bb_rcslotrole174:
  %v1078 = load i64, ptr %slot34, align 8
  store i64 %v1078, ptr %slot120, align 8
  %v1079 = load i64, ptr %slot120, align 8
  %v1080 = load i64, ptr %slot117, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v1079, i64 %v1080) nomerge, !dbg !118
  br label %bb_rcslotdone174
bb_rcslotowner174:
  %v1081 = load i64, ptr %slot34, align 8
  store i64 %v1081, ptr %slot121, align 8
  %v1082 = load i64, ptr %slot121, align 8
  %v1083 = load i64, ptr %slot117, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v1082, i64 %v1083) nomerge, !dbg !118
  br label %bb_rcslotdone174
bb_rcslotdone174:
  %v1084 = load i64, ptr %slot109, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1085, i64 24, i1 false)
  ret void
bb_i6:
  %v1086 = load i64, ptr %slot25, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i64 0, ptr %p1087, align 8, !alias.scope !3, !noalias !4
  %v1088 = load i64, ptr %slot25, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  %ld1090 = load i64, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1090, ptr %slot122, align 8
  %v1091 = load i64, ptr %slot122, align 8
  %v1092 = load i64, ptr %slot18, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  store i64 %v1091, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  %v1094 = load i64, ptr %slot16, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %ld1096 = load i64, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1096, ptr %slot123, align 8
  %v1097 = load i64, ptr %slot123, align 8
  %v1098 = load i64, ptr %slot25, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i64 %v1097, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  %v1100 = load i64, ptr %slot25, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i64, ptr %p1101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1102, ptr %slot124, align 8
  %v1103 = load i64, ptr %slot124, align 8
  %op1104 = add i64 %v1103, 0
  store i64 %op1104, ptr %slot125, align 8
  %v1105 = load i64, ptr %slot125, align 8
  %v1106 = load i64, ptr %slot25, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  store i64 %v1105, ptr %p1107, align 8, !alias.scope !3, !noalias !4
  %v1108 = load i64, ptr %slot8, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %ld1110 = load i32, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1110, ptr %slot126, align 8
  %v1111 = load i32, ptr %slot126, align 8
  %cv1112 = zext i32 %v1111 to i64
  %cond1113 = icmp ne i64 %cv1112, 0
  br i1 %cond1113, label %bb_rcslotdrop233, label %bb_rcslotdone233
bb_rcslotdrop233:
  %v1114 = load i64, ptr %slot8, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i32 0, ptr %p1115, align 4, !alias.scope !3, !noalias !4
  %v1116 = load i64, ptr %slot13, align 8
  store i64 %v1116, ptr %slot127, align 8
  %v1117 = load i64, ptr %slot9, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i32, ptr %p1118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1119, ptr %slot128, align 8
  %v1120 = load i32, ptr %slot128, align 8
  %op1121 = and i32 %v1120, 28
  store i32 %op1121, ptr %slot129, align 8
  %v1122 = load i32, ptr %slot129, align 8
  %cv1123 = zext i32 %v1122 to i64
  %cond1124 = icmp ne i64 %cv1123, 0
  br i1 %cond1124, label %bb_rcslotrole233, label %bb_rcslotowner233
bb_rcslotrole233:
  %v1125 = load i64, ptr %slot34, align 8
  store i64 %v1125, ptr %slot130, align 8
  %v1126 = load i64, ptr %slot130, align 8
  %v1127 = load i64, ptr %slot127, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1126, i64 %v1127) nomerge, !dbg !120
  br label %bb_rcslotdone233
bb_rcslotowner233:
  %v1128 = load i64, ptr %slot34, align 8
  store i64 %v1128, ptr %slot131, align 8
  %v1129 = load i64, ptr %slot131, align 8
  %v1130 = load i64, ptr %slot127, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1129, i64 %v1130) nomerge, !dbg !120
  br label %bb_rcslotdone233
bb_rcslotdone233:
  %v1131 = load i64, ptr %slot25, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %ld1133 = load i64, ptr %p1132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1133, ptr %slot132, align 8
  %v1134 = load i64, ptr %slot132, align 8
  %op1135 = add i64 %v1134, 0
  store i64 %op1135, ptr %slot133, align 8
  %v1136 = load i64, ptr %slot133, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  %ld1138 = load i64, ptr %p1137, align 8
  store i64 %ld1138, ptr %slot134, align 8
  %v1139 = load i64, ptr %slot134, align 8
  %v1140 = load i64, ptr %slot25, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 %v1139, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot8, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i32, ptr %p1143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1144, ptr %slot135, align 8
  %v1145 = load i32, ptr %slot135, align 8
  %cv1146 = zext i32 %v1145 to i64
  %cond1147 = icmp ne i64 %cv1146, 0
  br i1 %cond1147, label %bb_rcslotdrop245, label %bb_rcslotdone245
bb_rcslotdrop245:
  %v1148 = load i64, ptr %slot8, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i32 0, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot13, align 8
  store i64 %v1150, ptr %slot136, align 8
  %v1151 = load i64, ptr %slot9, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %ld1153 = load i32, ptr %p1152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1153, ptr %slot137, align 8
  %v1154 = load i32, ptr %slot137, align 8
  %op1155 = and i32 %v1154, 28
  store i32 %op1155, ptr %slot138, align 8
  %v1156 = load i32, ptr %slot138, align 8
  %cv1157 = zext i32 %v1156 to i64
  %cond1158 = icmp ne i64 %cv1157, 0
  br i1 %cond1158, label %bb_rcslotrole245, label %bb_rcslotowner245
bb_rcslotrole245:
  %v1159 = load i64, ptr %slot34, align 8
  store i64 %v1159, ptr %slot139, align 8
  %v1160 = load i64, ptr %slot139, align 8
  %v1161 = load i64, ptr %slot136, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v1160, i64 %v1161) nomerge, !dbg !122
  br label %bb_rcslotdone245
bb_rcslotowner245:
  %v1162 = load i64, ptr %slot34, align 8
  store i64 %v1162, ptr %slot140, align 8
  %v1163 = load i64, ptr %slot140, align 8
  %v1164 = load i64, ptr %slot136, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v1163, i64 %v1164) nomerge, !dbg !122
  br label %bb_rcslotdone245
bb_rcslotdone245:
  %v1165 = load i64, ptr %slot25, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i64, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1167, ptr %slot141, align 8
  %v1168 = load i64, ptr %slot141, align 8
  %v1169 = load i64, ptr %slot19, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i64 %v1168, ptr %p1170, align 8, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot17, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  %ld1173 = load i64, ptr %p1172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1173, ptr %slot142, align 8
  %v1174 = load i64, ptr %slot142, align 8
  %v1175 = load i64, ptr %slot25, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i64 %v1174, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot25, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i64, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1179, ptr %slot143, align 8
  %v1180 = load i64, ptr %slot143, align 8
  %v1181 = load i64, ptr %slot20, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i64 %v1180, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot20, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i64, ptr %p1184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1185, ptr %slot144, align 8
  %v1186 = load i64, ptr %slot144, align 8
  %v1187 = load i64, ptr %slot25, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i64 %v1186, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot26, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  store i64 0, ptr %p1190, align 8, !alias.scope !3, !noalias !4
  %v1191 = load i64, ptr %slot26, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i64, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1193, ptr %slot145, align 8
  %v1194 = load i64, ptr %slot25, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  %ld1196 = load i64, ptr %p1195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1196, ptr %slot146, align 8
  %v1197 = load i64, ptr %slot146, align 8
  %v1198 = load i64, ptr %slot145, align 8
  %cmp1199 = icmp slt i64 %v1197, %v1198
  %cv1200 = zext i1 %cmp1199 to i64
  store i64 %cv1200, ptr %slot147, align 8
  %v1201 = load i64, ptr %slot147, align 8
  %v1202 = load i64, ptr %slot25, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i64 %v1201, ptr %p1203, align 8, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot25, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %ld1206 = load i64, ptr %p1205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1206, ptr %slot148, align 8
  %v1207 = load i64, ptr %slot148, align 8
  %cond1208 = icmp ne i64 %v1207, 0
  br i1 %cond1208, label %bb_next260, label %bb_i24
bb_next260:
  %v1209 = load i64, ptr %slot19, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  %ld1211 = load i64, ptr %p1210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1211, ptr %slot149, align 8
  %v1212 = load i64, ptr %slot149, align 8
  %op1213 = add i64 %v1212, 0
  store i64 %op1213, ptr %slot150, align 8
  %v1214 = load i64, ptr %slot150, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %ld1216 = load i64, ptr %p1215, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1216, ptr %slot151, align 8
  %v1217 = load i64, ptr %slot151, align 8
  %v1218 = load i64, ptr %slot25, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i64 %v1217, ptr %p1219, align 8, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot25, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  %ld1222 = load i64, ptr %p1221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1222, ptr %slot152, align 8
  %v1223 = load i64, ptr %slot152, align 8
  %cmp1224 = icmp ugt i64 %v1223, 9223372036854775807
  %cv1225 = zext i1 %cmp1224 to i64
  store i64 %cv1225, ptr %slot153, align 8
  %v1226 = load i64, ptr %slot153, align 8
  %cond1227 = icmp ne i64 %v1226, 0
  br i1 %cond1227, label %bb_cast_overflow265, label %bb_cast_ok265
bb_cast_overflow265:
  %v1228 = load i64, ptr %slot1, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %v1230 = load i64, ptr %slot152, align 8
  call void @myl_qbe_fail_cast(ptr %p1229, i64 %v1230, i64 320) nomerge, !dbg !124
  unreachable
bb_cast_ok265:
  %v1231 = load i64, ptr %slot152, align 8
  %v1232 = load i64, ptr %slot25, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i64 %v1231, ptr %p1233, align 8, !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot20, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  %ld1236 = load i64, ptr %p1235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1236, ptr %slot154, align 8
  %v1237 = load i64, ptr %slot154, align 8
  %v1238 = load i64, ptr %slot26, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i64 %v1237, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot26, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  %ld1242 = load i64, ptr %p1241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1242, ptr %slot155, align 8
  %v1243 = load i64, ptr %slot25, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %ld1245 = load i64, ptr %p1244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1245, ptr %slot156, align 8
  %v1246 = load i64, ptr %slot156, align 8
  %v1247 = load i64, ptr %slot155, align 8
  %ovpair1249 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1246, i64 %v1247)
  %op1248 = extractvalue { i64, i1 } %ovpair1249, 0
  %ov1250 = extractvalue { i64, i1 } %ovpair1249, 1
  store i64 %op1248, ptr %slot157, align 8
  %v1251 = load i64, ptr %slot156, align 8
  %v1252 = load i64, ptr %slot157, align 8
  %op1253 = xor i64 %v1251, %v1252
  store i64 %op1253, ptr %slot158, align 8
  %v1254 = load i64, ptr %slot155, align 8
  %v1255 = load i64, ptr %slot157, align 8
  %op1256 = xor i64 %v1254, %v1255
  store i64 %op1256, ptr %slot159, align 8
  %v1257 = load i64, ptr %slot158, align 8
  %v1258 = load i64, ptr %slot159, align 8
  %op1259 = and i64 %v1257, %v1258
  store i64 %op1259, ptr %slot160, align 8
  %cv1260 = zext i1 %ov1250 to i64
  store i64 %cv1260, ptr %slot161, align 8
  %v1261 = load i64, ptr %slot161, align 8
  %cond1262 = icmp ne i64 %v1261, 0
  br i1 %cond1262, label %bb_overflow269, label %bb_checked269
bb_overflow269:
  %v1263 = load i64, ptr %slot1, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %v1265 = load i64, ptr %slot156, align 8
  %v1266 = load i64, ptr %slot155, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1264, i64 0, i64 %v1265, i64 %v1266, i64 64) nomerge, !dbg !126
  unreachable
bb_checked269:
  %v1267 = load i64, ptr %slot157, align 8
  %v1268 = load i64, ptr %slot25, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i64 %v1267, ptr %p1269, align 8, !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot25, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i64, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1272, ptr %slot162, align 8
  %v1273 = load i64, ptr %slot162, align 8
  %v1274 = load i64, ptr %slot20, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i64 %v1273, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v1276 = load i64, ptr %slot20, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %ld1278 = load i64, ptr %p1277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1278, ptr %slot163, align 8
  %v1279 = load i64, ptr %slot163, align 8
  %v1280 = load i64, ptr %slot25, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i64 %v1279, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot19, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  %ld1284 = load i64, ptr %p1283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1284, ptr %slot164, align 8
  %v1285 = load i64, ptr %slot25, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  %ld1287 = load i64, ptr %p1286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1287, ptr %slot165, align 8
  %v1288 = load i64, ptr %slot164, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i64, ptr %p1289, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1290, ptr %slot166, align 8
  %v1291 = load i64, ptr %slot165, align 8
  %v1292 = load i64, ptr %slot166, align 8
  %cmp1293 = icmp ult i64 %v1291, %v1292
  %cv1294 = zext i1 %cmp1293 to i64
  store i64 %cv1294, ptr %slot167, align 8
  %v1295 = load i64, ptr %slot167, align 8
  %cond1296 = icmp ne i64 %v1295, 0
  br i1 %cond1296, label %bb_success281, label %bb_failed281
bb_failed281:
  %v1297 = load i64, ptr %slot1, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %v1299 = load i64, ptr %slot165, align 8
  %v1300 = load i64, ptr %slot166, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1298, i64 %v1299, i64 %v1300) nomerge, !dbg !128
  unreachable
bb_success281:
  %v1301 = load i64, ptr %slot164, align 8
  %op1302 = add i64 %v1301, 32
  store i64 %op1302, ptr %slot168, align 8
  %v1303 = load i64, ptr %slot168, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i64, ptr %p1304, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1305, ptr %slot169, align 8
  %v1306 = load i64, ptr %slot165, align 8
  %op1307 = mul i64 %v1306, 112
  store i64 %op1307, ptr %slot170, align 8
  %v1308 = load i64, ptr %slot169, align 8
  %v1309 = load i64, ptr %slot170, align 8
  %op1310 = add i64 %v1308, %v1309
  store i64 %op1310, ptr %slot171, align 8
  %v1311 = load i64, ptr %slot171, align 8
  %v1312 = load i64, ptr %slot25, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i64 %v1311, ptr %p1313, align 8, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot25, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i64, ptr %p1315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1316, ptr %slot172, align 8
  %v1317 = load i64, ptr %slot15, align 8
  store i64 %v1317, ptr %slot173, align 8
  %v1318 = load i64, ptr %slot34, align 8
  %v1319 = load i64, ptr %slot173, align 8
  %v1320 = load i64, ptr %slot172, align 8
  %call1321 = call i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64 %v1318, i64 %v1319, i64 %v1320) nomerge, !dbg !128
  store i32 %call1321, ptr %slot174, align 8
  %v1322 = load i32, ptr %slot174, align 8
  %cv1323 = zext i32 %v1322 to i64
  %cond1324 = icmp ne i64 %cv1323, 0
  br i1 %cond1324, label %bb_rcsuccess289, label %bb_rcfailure289
bb_rcfailure289:
  %v1325 = load i64, ptr %slot34, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  %call1327 = call i32 @myl_rc_take_failure(ptr %p1326) nomerge, !dbg !128
  store i32 %call1327, ptr %slot175, align 8
  %v1328 = load i64, ptr %slot1, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  %v1330 = load i32, ptr %slot175, align 8
  %call1331 = call i32 @myl_qbe_rc_status(ptr %p1329, i32 %v1330) nomerge, !dbg !128
  store i32 %call1331, ptr %slot176, align 8
  br label %bb_failure
bb_rcsuccess289:
  %v1332 = load i64, ptr %slot11, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 2, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot11, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 16, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot10, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 1, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot13, align 8
  store i64 %v1338, ptr %slot177, align 8
  %v1339 = load i64, ptr %slot15, align 8
  store i64 %v1339, ptr %slot178, align 8
  %v1340 = load i64, ptr %slot178, align 8
  %v1341 = load i64, ptr %slot177, align 8
  %p1342 = inttoptr i64 %v1340 to ptr
  %p1343 = inttoptr i64 %v1341 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1343, ptr %p1342, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot9, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i32 2, ptr %p1345, align 4, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot11, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot179, align 8
  %v1349 = load i32, ptr %slot179, align 8
  %v1350 = load i64, ptr %slot9, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  store i32 %v1349, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot10, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i32 0, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  %v1354 = load i64, ptr %slot8, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  store i32 1, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  %v1356 = load i64, ptr %slot177, align 8
  %v1357 = load i64, ptr %slot25, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i64 %v1356, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot25, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %ld1361 = load i64, ptr %p1360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1361, ptr %slot180, align 8
  %v1362 = load i64, ptr %slot180, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %ld1364 = load i32, ptr %p1363, align 4
  %ext1365 = zext i32 %ld1364 to i64
  store i64 %ext1365, ptr %slot181, align 8
  %v1366 = load i64, ptr %slot181, align 8
  %cmp1367 = icmp eq i64 %v1366, 0
  %cv1368 = zext i1 %cmp1367 to i64
  store i64 %cv1368, ptr %slot182, align 8
  %v1369 = load i64, ptr %slot182, align 8
  %cond1370 = icmp ne i64 %v1369, 0
  br i1 %cond1370, label %bb_rcarm305, label %bb_rcarmnext305
bb_rcarm305:
  %v1371 = load i64, ptr %slot8, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  %ld1373 = load i32, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1373, ptr %slot183, align 8
  %v1374 = load i32, ptr %slot183, align 8
  %cv1375 = zext i32 %v1374 to i64
  %cond1376 = icmp ne i64 %cv1375, 0
  br i1 %cond1376, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1377 = load i64, ptr %slot8, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i32 0, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  %v1379 = load i64, ptr %slot13, align 8
  store i64 %v1379, ptr %slot184, align 8
  %v1380 = load i64, ptr %slot9, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  %ld1382 = load i32, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1382, ptr %slot185, align 8
  %v1383 = load i32, ptr %slot185, align 8
  %op1384 = and i32 %v1383, 28
  store i32 %op1384, ptr %slot186, align 8
  %v1385 = load i32, ptr %slot186, align 8
  %cv1386 = zext i32 %v1385 to i64
  %cond1387 = icmp ne i64 %cv1386, 0
  br i1 %cond1387, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1388 = load i64, ptr %slot34, align 8
  store i64 %v1388, ptr %slot187, align 8
  %v1389 = load i64, ptr %slot187, align 8
  %v1390 = load i64, ptr %slot184, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1389, i64 %v1390) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1391 = load i64, ptr %slot34, align 8
  store i64 %v1391, ptr %slot188, align 8
  %v1392 = load i64, ptr %slot188, align 8
  %v1393 = load i64, ptr %slot184, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1392, i64 %v1393) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotdone308:
  br label %bb_i33
bb_rcarmnext305:
  %v1394 = load i64, ptr %slot181, align 8
  %cmp1395 = icmp eq i64 %v1394, 1
  %cv1396 = zext i1 %cmp1395 to i64
  store i64 %cv1396, ptr %slot189, align 8
  %v1397 = load i64, ptr %slot189, align 8
  %cond1398 = icmp ne i64 %v1397, 0
  br i1 %cond1398, label %bb_rcarm315, label %bb_rcarmnext315
bb_rcarm315:
  %v1399 = load i64, ptr %slot8, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i32, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1401, ptr %slot190, align 8
  %v1402 = load i32, ptr %slot190, align 8
  %cv1403 = zext i32 %v1402 to i64
  %cond1404 = icmp ne i64 %cv1403, 0
  br i1 %cond1404, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v1405 = load i64, ptr %slot8, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i32 0, ptr %p1406, align 4, !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot13, align 8
  store i64 %v1407, ptr %slot191, align 8
  %v1408 = load i64, ptr %slot9, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i32, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1410, ptr %slot192, align 8
  %v1411 = load i32, ptr %slot192, align 8
  %op1412 = and i32 %v1411, 28
  store i32 %op1412, ptr %slot193, align 8
  %v1413 = load i32, ptr %slot193, align 8
  %cv1414 = zext i32 %v1413 to i64
  %cond1415 = icmp ne i64 %cv1414, 0
  br i1 %cond1415, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v1416 = load i64, ptr %slot34, align 8
  store i64 %v1416, ptr %slot194, align 8
  %v1417 = load i64, ptr %slot194, align 8
  %v1418 = load i64, ptr %slot191, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1417, i64 %v1418) nomerge, !dbg !130
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v1419 = load i64, ptr %slot34, align 8
  store i64 %v1419, ptr %slot195, align 8
  %v1420 = load i64, ptr %slot195, align 8
  %v1421 = load i64, ptr %slot191, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1420, i64 %v1421) nomerge, !dbg !130
  br label %bb_rcslotdone318
bb_rcslotdone318:
  br label %bb_i34
bb_rcarmnext315:
  %v1422 = load i64, ptr %slot181, align 8
  %cmp1423 = icmp eq i64 %v1422, 2
  %cv1424 = zext i1 %cmp1423 to i64
  store i64 %cv1424, ptr %slot196, align 8
  %v1425 = load i64, ptr %slot196, align 8
  %cond1426 = icmp ne i64 %v1425, 0
  br i1 %cond1426, label %bb_rcarm325, label %bb_rcarmnext325
bb_rcarm325:
  %v1427 = load i64, ptr %slot8, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %ld1429 = load i32, ptr %p1428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1429, ptr %slot197, align 8
  %v1430 = load i32, ptr %slot197, align 8
  %cv1431 = zext i32 %v1430 to i64
  %cond1432 = icmp ne i64 %cv1431, 0
  br i1 %cond1432, label %bb_rcslotdrop328, label %bb_rcslotdone328
bb_rcslotdrop328:
  %v1433 = load i64, ptr %slot8, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i32 0, ptr %p1434, align 4, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot13, align 8
  store i64 %v1435, ptr %slot198, align 8
  %v1436 = load i64, ptr %slot9, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %ld1438 = load i32, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1438, ptr %slot199, align 8
  %v1439 = load i32, ptr %slot199, align 8
  %op1440 = and i32 %v1439, 28
  store i32 %op1440, ptr %slot200, align 8
  %v1441 = load i32, ptr %slot200, align 8
  %cv1442 = zext i32 %v1441 to i64
  %cond1443 = icmp ne i64 %cv1442, 0
  br i1 %cond1443, label %bb_rcslotrole328, label %bb_rcslotowner328
bb_rcslotrole328:
  %v1444 = load i64, ptr %slot34, align 8
  store i64 %v1444, ptr %slot201, align 8
  %v1445 = load i64, ptr %slot201, align 8
  %v1446 = load i64, ptr %slot198, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1445, i64 %v1446) nomerge, !dbg !130
  br label %bb_rcslotdone328
bb_rcslotowner328:
  %v1447 = load i64, ptr %slot34, align 8
  store i64 %v1447, ptr %slot202, align 8
  %v1448 = load i64, ptr %slot202, align 8
  %v1449 = load i64, ptr %slot198, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1448, i64 %v1449) nomerge, !dbg !130
  br label %bb_rcslotdone328
bb_rcslotdone328:
  br label %bb_i35
bb_rcarmnext325:
  %v1450 = load i64, ptr %slot181, align 8
  %cmp1451 = icmp eq i64 %v1450, 3
  %cv1452 = zext i1 %cmp1451 to i64
  store i64 %cv1452, ptr %slot203, align 8
  %v1453 = load i64, ptr %slot203, align 8
  %cond1454 = icmp ne i64 %v1453, 0
  br i1 %cond1454, label %bb_rcarm335, label %bb_rcarmnext335
bb_rcarm335:
  %v1455 = load i64, ptr %slot8, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  %ld1457 = load i32, ptr %p1456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1457, ptr %slot204, align 8
  %v1458 = load i32, ptr %slot204, align 8
  %cv1459 = zext i32 %v1458 to i64
  %cond1460 = icmp ne i64 %cv1459, 0
  br i1 %cond1460, label %bb_rcslotdrop338, label %bb_rcslotdone338
bb_rcslotdrop338:
  %v1461 = load i64, ptr %slot8, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  store i32 0, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  %v1463 = load i64, ptr %slot13, align 8
  store i64 %v1463, ptr %slot205, align 8
  %v1464 = load i64, ptr %slot9, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i32, ptr %p1465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1466, ptr %slot206, align 8
  %v1467 = load i32, ptr %slot206, align 8
  %op1468 = and i32 %v1467, 28
  store i32 %op1468, ptr %slot207, align 8
  %v1469 = load i32, ptr %slot207, align 8
  %cv1470 = zext i32 %v1469 to i64
  %cond1471 = icmp ne i64 %cv1470, 0
  br i1 %cond1471, label %bb_rcslotrole338, label %bb_rcslotowner338
bb_rcslotrole338:
  %v1472 = load i64, ptr %slot34, align 8
  store i64 %v1472, ptr %slot208, align 8
  %v1473 = load i64, ptr %slot208, align 8
  %v1474 = load i64, ptr %slot205, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1473, i64 %v1474) nomerge, !dbg !130
  br label %bb_rcslotdone338
bb_rcslotowner338:
  %v1475 = load i64, ptr %slot34, align 8
  store i64 %v1475, ptr %slot209, align 8
  %v1476 = load i64, ptr %slot209, align 8
  %v1477 = load i64, ptr %slot205, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1476, i64 %v1477) nomerge, !dbg !130
  br label %bb_rcslotdone338
bb_rcslotdone338:
  br label %bb_i36
bb_rcarmnext335:
  %v1478 = load i64, ptr %slot181, align 8
  %cmp1479 = icmp eq i64 %v1478, 4
  %cv1480 = zext i1 %cmp1479 to i64
  store i64 %cv1480, ptr %slot210, align 8
  %v1481 = load i64, ptr %slot210, align 8
  %cond1482 = icmp ne i64 %v1481, 0
  br i1 %cond1482, label %bb_rcarm345, label %bb_rcarmnext345
bb_rcarm345:
  %v1483 = load i64, ptr %slot8, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %ld1485 = load i32, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1485, ptr %slot211, align 8
  %v1486 = load i32, ptr %slot211, align 8
  %cv1487 = zext i32 %v1486 to i64
  %cond1488 = icmp ne i64 %cv1487, 0
  br i1 %cond1488, label %bb_rcslotdrop348, label %bb_rcslotdone348
bb_rcslotdrop348:
  %v1489 = load i64, ptr %slot8, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i32 0, ptr %p1490, align 4, !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot13, align 8
  store i64 %v1491, ptr %slot212, align 8
  %v1492 = load i64, ptr %slot9, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %ld1494 = load i32, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1494, ptr %slot213, align 8
  %v1495 = load i32, ptr %slot213, align 8
  %op1496 = and i32 %v1495, 28
  store i32 %op1496, ptr %slot214, align 8
  %v1497 = load i32, ptr %slot214, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcslotrole348, label %bb_rcslotowner348
bb_rcslotrole348:
  %v1500 = load i64, ptr %slot34, align 8
  store i64 %v1500, ptr %slot215, align 8
  %v1501 = load i64, ptr %slot215, align 8
  %v1502 = load i64, ptr %slot212, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1501, i64 %v1502) nomerge, !dbg !130
  br label %bb_rcslotdone348
bb_rcslotowner348:
  %v1503 = load i64, ptr %slot34, align 8
  store i64 %v1503, ptr %slot216, align 8
  %v1504 = load i64, ptr %slot216, align 8
  %v1505 = load i64, ptr %slot212, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1504, i64 %v1505) nomerge, !dbg !130
  br label %bb_rcslotdone348
bb_rcslotdone348:
  br label %bb_i37
bb_rcarmnext345:
  %v1506 = load i64, ptr %slot181, align 8
  %cmp1507 = icmp eq i64 %v1506, 5
  %cv1508 = zext i1 %cmp1507 to i64
  store i64 %cv1508, ptr %slot217, align 8
  %v1509 = load i64, ptr %slot217, align 8
  %cond1510 = icmp ne i64 %v1509, 0
  br i1 %cond1510, label %bb_rcarm355, label %bb_rcarmnext355
bb_rcarm355:
  %v1511 = load i64, ptr %slot8, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %ld1513 = load i32, ptr %p1512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1513, ptr %slot218, align 8
  %v1514 = load i32, ptr %slot218, align 8
  %cv1515 = zext i32 %v1514 to i64
  %cond1516 = icmp ne i64 %cv1515, 0
  br i1 %cond1516, label %bb_rcslotdrop358, label %bb_rcslotdone358
bb_rcslotdrop358:
  %v1517 = load i64, ptr %slot8, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  store i32 0, ptr %p1518, align 4, !alias.scope !3, !noalias !4
  %v1519 = load i64, ptr %slot13, align 8
  store i64 %v1519, ptr %slot219, align 8
  %v1520 = load i64, ptr %slot9, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %ld1522 = load i32, ptr %p1521, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1522, ptr %slot220, align 8
  %v1523 = load i32, ptr %slot220, align 8
  %op1524 = and i32 %v1523, 28
  store i32 %op1524, ptr %slot221, align 8
  %v1525 = load i32, ptr %slot221, align 8
  %cv1526 = zext i32 %v1525 to i64
  %cond1527 = icmp ne i64 %cv1526, 0
  br i1 %cond1527, label %bb_rcslotrole358, label %bb_rcslotowner358
bb_rcslotrole358:
  %v1528 = load i64, ptr %slot34, align 8
  store i64 %v1528, ptr %slot222, align 8
  %v1529 = load i64, ptr %slot222, align 8
  %v1530 = load i64, ptr %slot219, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1529, i64 %v1530) nomerge, !dbg !130
  br label %bb_rcslotdone358
bb_rcslotowner358:
  %v1531 = load i64, ptr %slot34, align 8
  store i64 %v1531, ptr %slot223, align 8
  %v1532 = load i64, ptr %slot223, align 8
  %v1533 = load i64, ptr %slot219, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1532, i64 %v1533) nomerge, !dbg !130
  br label %bb_rcslotdone358
bb_rcslotdone358:
  br label %bb_i38
bb_rcarmnext355:
  %v1534 = load i64, ptr %slot181, align 8
  %cmp1535 = icmp eq i64 %v1534, 6
  %cv1536 = zext i1 %cmp1535 to i64
  store i64 %cv1536, ptr %slot224, align 8
  %v1537 = load i64, ptr %slot224, align 8
  %cond1538 = icmp ne i64 %v1537, 0
  br i1 %cond1538, label %bb_rcarm365, label %bb_rcarmnext365
bb_rcarm365:
  %v1539 = load i64, ptr %slot8, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %ld1541 = load i32, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1541, ptr %slot225, align 8
  %v1542 = load i32, ptr %slot225, align 8
  %cv1543 = zext i32 %v1542 to i64
  %cond1544 = icmp ne i64 %cv1543, 0
  br i1 %cond1544, label %bb_rcslotdrop368, label %bb_rcslotdone368
bb_rcslotdrop368:
  %v1545 = load i64, ptr %slot8, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i32 0, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  %v1547 = load i64, ptr %slot13, align 8
  store i64 %v1547, ptr %slot226, align 8
  %v1548 = load i64, ptr %slot9, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %ld1550 = load i32, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1550, ptr %slot227, align 8
  %v1551 = load i32, ptr %slot227, align 8
  %op1552 = and i32 %v1551, 28
  store i32 %op1552, ptr %slot228, align 8
  %v1553 = load i32, ptr %slot228, align 8
  %cv1554 = zext i32 %v1553 to i64
  %cond1555 = icmp ne i64 %cv1554, 0
  br i1 %cond1555, label %bb_rcslotrole368, label %bb_rcslotowner368
bb_rcslotrole368:
  %v1556 = load i64, ptr %slot34, align 8
  store i64 %v1556, ptr %slot229, align 8
  %v1557 = load i64, ptr %slot229, align 8
  %v1558 = load i64, ptr %slot226, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1557, i64 %v1558) nomerge, !dbg !130
  br label %bb_rcslotdone368
bb_rcslotowner368:
  %v1559 = load i64, ptr %slot34, align 8
  store i64 %v1559, ptr %slot230, align 8
  %v1560 = load i64, ptr %slot230, align 8
  %v1561 = load i64, ptr %slot226, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1560, i64 %v1561) nomerge, !dbg !130
  br label %bb_rcslotdone368
bb_rcslotdone368:
  br label %bb_i39
bb_rcarmnext365:
  %v1562 = load i64, ptr %slot181, align 8
  %cmp1563 = icmp eq i64 %v1562, 7
  %cv1564 = zext i1 %cmp1563 to i64
  store i64 %cv1564, ptr %slot231, align 8
  %v1565 = load i64, ptr %slot231, align 8
  %cond1566 = icmp ne i64 %v1565, 0
  br i1 %cond1566, label %bb_rcarm375, label %bb_rcarmnext375
bb_rcarm375:
  %v1567 = load i64, ptr %slot8, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  %ld1569 = load i32, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1569, ptr %slot232, align 8
  %v1570 = load i32, ptr %slot232, align 8
  %cv1571 = zext i32 %v1570 to i64
  %cond1572 = icmp ne i64 %cv1571, 0
  br i1 %cond1572, label %bb_rcslotdrop378, label %bb_rcslotdone378
bb_rcslotdrop378:
  %v1573 = load i64, ptr %slot8, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i32 0, ptr %p1574, align 4, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot13, align 8
  store i64 %v1575, ptr %slot233, align 8
  %v1576 = load i64, ptr %slot9, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %ld1578 = load i32, ptr %p1577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1578, ptr %slot234, align 8
  %v1579 = load i32, ptr %slot234, align 8
  %op1580 = and i32 %v1579, 28
  store i32 %op1580, ptr %slot235, align 8
  %v1581 = load i32, ptr %slot235, align 8
  %cv1582 = zext i32 %v1581 to i64
  %cond1583 = icmp ne i64 %cv1582, 0
  br i1 %cond1583, label %bb_rcslotrole378, label %bb_rcslotowner378
bb_rcslotrole378:
  %v1584 = load i64, ptr %slot34, align 8
  store i64 %v1584, ptr %slot236, align 8
  %v1585 = load i64, ptr %slot236, align 8
  %v1586 = load i64, ptr %slot233, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1585, i64 %v1586) nomerge, !dbg !130
  br label %bb_rcslotdone378
bb_rcslotowner378:
  %v1587 = load i64, ptr %slot34, align 8
  store i64 %v1587, ptr %slot237, align 8
  %v1588 = load i64, ptr %slot237, align 8
  %v1589 = load i64, ptr %slot233, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1588, i64 %v1589) nomerge, !dbg !130
  br label %bb_rcslotdone378
bb_rcslotdone378:
  br label %bb_i40
bb_rcarmnext375:
  %v1590 = load i64, ptr %slot181, align 8
  %cmp1591 = icmp eq i64 %v1590, 8
  %cv1592 = zext i1 %cmp1591 to i64
  store i64 %cv1592, ptr %slot238, align 8
  %v1593 = load i64, ptr %slot238, align 8
  %cond1594 = icmp ne i64 %v1593, 0
  br i1 %cond1594, label %bb_rcarm385, label %bb_rcarmnext385
bb_rcarm385:
  %v1595 = load i64, ptr %slot8, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i32, ptr %p1596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1597, ptr %slot239, align 8
  %v1598 = load i32, ptr %slot239, align 8
  %cv1599 = zext i32 %v1598 to i64
  %cond1600 = icmp ne i64 %cv1599, 0
  br i1 %cond1600, label %bb_rcslotdrop388, label %bb_rcslotdone388
bb_rcslotdrop388:
  %v1601 = load i64, ptr %slot8, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i32 0, ptr %p1602, align 4, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot13, align 8
  store i64 %v1603, ptr %slot240, align 8
  %v1604 = load i64, ptr %slot9, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  %ld1606 = load i32, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1606, ptr %slot241, align 8
  %v1607 = load i32, ptr %slot241, align 8
  %op1608 = and i32 %v1607, 28
  store i32 %op1608, ptr %slot242, align 8
  %v1609 = load i32, ptr %slot242, align 8
  %cv1610 = zext i32 %v1609 to i64
  %cond1611 = icmp ne i64 %cv1610, 0
  br i1 %cond1611, label %bb_rcslotrole388, label %bb_rcslotowner388
bb_rcslotrole388:
  %v1612 = load i64, ptr %slot34, align 8
  store i64 %v1612, ptr %slot243, align 8
  %v1613 = load i64, ptr %slot243, align 8
  %v1614 = load i64, ptr %slot240, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1613, i64 %v1614) nomerge, !dbg !130
  br label %bb_rcslotdone388
bb_rcslotowner388:
  %v1615 = load i64, ptr %slot34, align 8
  store i64 %v1615, ptr %slot244, align 8
  %v1616 = load i64, ptr %slot244, align 8
  %v1617 = load i64, ptr %slot240, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1616, i64 %v1617) nomerge, !dbg !130
  br label %bb_rcslotdone388
bb_rcslotdone388:
  br label %bb_i41
bb_rcarmnext385:
  %v1618 = load i64, ptr %slot181, align 8
  %cmp1619 = icmp eq i64 %v1618, 9
  %cv1620 = zext i1 %cmp1619 to i64
  store i64 %cv1620, ptr %slot245, align 8
  %v1621 = load i64, ptr %slot245, align 8
  %cond1622 = icmp ne i64 %v1621, 0
  br i1 %cond1622, label %bb_rcarm395, label %bb_rcarmnext395
bb_rcarm395:
  %v1623 = load i64, ptr %slot8, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i32, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1625, ptr %slot246, align 8
  %v1626 = load i32, ptr %slot246, align 8
  %cv1627 = zext i32 %v1626 to i64
  %cond1628 = icmp ne i64 %cv1627, 0
  br i1 %cond1628, label %bb_rcslotdrop398, label %bb_rcslotdone398
bb_rcslotdrop398:
  %v1629 = load i64, ptr %slot8, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  store i32 0, ptr %p1630, align 4, !alias.scope !3, !noalias !4
  %v1631 = load i64, ptr %slot13, align 8
  store i64 %v1631, ptr %slot247, align 8
  %v1632 = load i64, ptr %slot9, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot248, align 8
  %v1635 = load i32, ptr %slot248, align 8
  %op1636 = and i32 %v1635, 28
  store i32 %op1636, ptr %slot249, align 8
  %v1637 = load i32, ptr %slot249, align 8
  %cv1638 = zext i32 %v1637 to i64
  %cond1639 = icmp ne i64 %cv1638, 0
  br i1 %cond1639, label %bb_rcslotrole398, label %bb_rcslotowner398
bb_rcslotrole398:
  %v1640 = load i64, ptr %slot34, align 8
  store i64 %v1640, ptr %slot250, align 8
  %v1641 = load i64, ptr %slot250, align 8
  %v1642 = load i64, ptr %slot247, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1641, i64 %v1642) nomerge, !dbg !130
  br label %bb_rcslotdone398
bb_rcslotowner398:
  %v1643 = load i64, ptr %slot34, align 8
  store i64 %v1643, ptr %slot251, align 8
  %v1644 = load i64, ptr %slot251, align 8
  %v1645 = load i64, ptr %slot247, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1644, i64 %v1645) nomerge, !dbg !130
  br label %bb_rcslotdone398
bb_rcslotdone398:
  br label %bb_i42
bb_rcarmnext395:
  %v1646 = load i64, ptr %slot181, align 8
  %cmp1647 = icmp eq i64 %v1646, 10
  %cv1648 = zext i1 %cmp1647 to i64
  store i64 %cv1648, ptr %slot252, align 8
  %v1649 = load i64, ptr %slot252, align 8
  %cond1650 = icmp ne i64 %v1649, 0
  br i1 %cond1650, label %bb_rcarm405, label %bb_rcarmnext405
bb_rcarm405:
  %v1651 = load i64, ptr %slot8, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %ld1653 = load i32, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1653, ptr %slot253, align 8
  %v1654 = load i32, ptr %slot253, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcslotdrop408, label %bb_rcslotdone408
bb_rcslotdrop408:
  %v1657 = load i64, ptr %slot8, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i32 0, ptr %p1658, align 4, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot13, align 8
  store i64 %v1659, ptr %slot254, align 8
  %v1660 = load i64, ptr %slot9, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i32, ptr %p1661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1662, ptr %slot255, align 8
  %v1663 = load i32, ptr %slot255, align 8
  %op1664 = and i32 %v1663, 28
  store i32 %op1664, ptr %slot256, align 8
  %v1665 = load i32, ptr %slot256, align 8
  %cv1666 = zext i32 %v1665 to i64
  %cond1667 = icmp ne i64 %cv1666, 0
  br i1 %cond1667, label %bb_rcslotrole408, label %bb_rcslotowner408
bb_rcslotrole408:
  %v1668 = load i64, ptr %slot34, align 8
  store i64 %v1668, ptr %slot257, align 8
  %v1669 = load i64, ptr %slot257, align 8
  %v1670 = load i64, ptr %slot254, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1669, i64 %v1670) nomerge, !dbg !130
  br label %bb_rcslotdone408
bb_rcslotowner408:
  %v1671 = load i64, ptr %slot34, align 8
  store i64 %v1671, ptr %slot258, align 8
  %v1672 = load i64, ptr %slot258, align 8
  %v1673 = load i64, ptr %slot254, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1672, i64 %v1673) nomerge, !dbg !130
  br label %bb_rcslotdone408
bb_rcslotdone408:
  br label %bb_i43
bb_rcarmnext405:
  %v1674 = load i64, ptr %slot181, align 8
  %cmp1675 = icmp eq i64 %v1674, 11
  %cv1676 = zext i1 %cmp1675 to i64
  store i64 %cv1676, ptr %slot259, align 8
  %v1677 = load i64, ptr %slot259, align 8
  %cond1678 = icmp ne i64 %v1677, 0
  br i1 %cond1678, label %bb_rcarm415, label %bb_rcarmnext415
bb_rcarm415:
  %v1679 = load i64, ptr %slot15, align 8
  store i64 %v1679, ptr %slot260, align 8
  %v1680 = load i64, ptr %slot180, align 8
  %op1681 = add i64 %v1680, 8
  store i64 %op1681, ptr %slot261, align 8
  %v1682 = load i64, ptr %slot35, align 8
  store i64 %v1682, ptr %slot262, align 8
  %v1683 = load i64, ptr %slot34, align 8
  %v1684 = load i64, ptr %slot260, align 8
  %v1685 = load i64, ptr %slot261, align 8
  %v1686 = load i64, ptr %slot262, align 8
  %cv1687 = trunc i64 %v1686 to i32
  %call1688 = call i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64 %v1683, i64 %v1684, i64 %v1685, i32 %cv1687) nomerge, !dbg !130
  store i32 %call1688, ptr %slot263, align 8
  %v1689 = load i32, ptr %slot263, align 8
  %cv1690 = zext i32 %v1689 to i64
  %cond1691 = icmp ne i64 %cv1690, 0
  br i1 %cond1691, label %bb_rcsuccess420, label %bb_rcfailure420
bb_rcfailure420:
  %v1692 = load i64, ptr %slot34, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %call1694 = call i32 @myl_rc_take_failure(ptr %p1693) nomerge, !dbg !130
  store i32 %call1694, ptr %slot264, align 8
  %v1695 = load i64, ptr %slot1, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %v1697 = load i32, ptr %slot264, align 8
  %call1698 = call i32 @myl_qbe_rc_status(ptr %p1696, i32 %v1697) nomerge, !dbg !130
  store i32 %call1698, ptr %slot265, align 8
  br label %bb_failure
bb_rcsuccess420:
  %v1699 = load i64, ptr %slot11, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 2, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot10, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 1, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot6, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  %ld1705 = load i32, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1705, ptr %slot266, align 8
  %v1706 = load i32, ptr %slot266, align 8
  %cv1707 = zext i32 %v1706 to i64
  %cond1708 = icmp ne i64 %cv1707, 0
  br i1 %cond1708, label %bb_rcslotdrop427, label %bb_rcslotdone427
bb_rcslotdrop427:
  %v1709 = load i64, ptr %slot6, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i32 0, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot21, align 8
  store i64 %v1711, ptr %slot267, align 8
  %v1712 = load i64, ptr %slot7, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i32, ptr %p1713, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1714, ptr %slot268, align 8
  %v1715 = load i32, ptr %slot268, align 8
  %op1716 = and i32 %v1715, 28
  store i32 %op1716, ptr %slot269, align 8
  %v1717 = load i32, ptr %slot269, align 8
  %cv1718 = zext i32 %v1717 to i64
  %cond1719 = icmp ne i64 %cv1718, 0
  br i1 %cond1719, label %bb_rcslotrole427, label %bb_rcslotowner427
bb_rcslotrole427:
  %v1720 = load i64, ptr %slot34, align 8
  store i64 %v1720, ptr %slot270, align 8
  %v1721 = load i64, ptr %slot270, align 8
  %v1722 = load i64, ptr %slot267, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v1721, i64 %v1722) nomerge, !dbg !130
  br label %bb_rcslotdone427
bb_rcslotowner427:
  %v1723 = load i64, ptr %slot34, align 8
  store i64 %v1723, ptr %slot271, align 8
  %v1724 = load i64, ptr %slot271, align 8
  %v1725 = load i64, ptr %slot267, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v1724, i64 %v1725) nomerge, !dbg !130
  br label %bb_rcslotdone427
bb_rcslotdone427:
  %v1726 = load i64, ptr %slot260, align 8
  %v1727 = load i64, ptr %slot21, align 8
  %p1728 = inttoptr i64 %v1726 to ptr
  %p1729 = inttoptr i64 %v1727 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1729, ptr %p1728, i64 64, i1 false), !alias.scope !3, !noalias !4
  %v1730 = load i64, ptr %slot10, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  store i32 0, ptr %p1731, align 4, !alias.scope !3, !noalias !4
  %v1732 = load i64, ptr %slot21, align 8
  store i64 %v1732, ptr %slot272, align 8
  %v1733 = load i64, ptr %slot7, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 2, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot6, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i32 1, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  %v1737 = load i64, ptr %slot8, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  %ld1739 = load i32, ptr %p1738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1739, ptr %slot273, align 8
  %v1740 = load i32, ptr %slot273, align 8
  %cv1741 = zext i32 %v1740 to i64
  %cond1742 = icmp ne i64 %cv1741, 0
  br i1 %cond1742, label %bb_rcslotdrop440, label %bb_rcslotdone440
bb_rcslotdrop440:
  %v1743 = load i64, ptr %slot8, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i32 0, ptr %p1744, align 4, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot13, align 8
  store i64 %v1745, ptr %slot274, align 8
  %v1746 = load i64, ptr %slot9, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i32, ptr %p1747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1748, ptr %slot275, align 8
  %v1749 = load i32, ptr %slot275, align 8
  %op1750 = and i32 %v1749, 28
  store i32 %op1750, ptr %slot276, align 8
  %v1751 = load i32, ptr %slot276, align 8
  %cv1752 = zext i32 %v1751 to i64
  %cond1753 = icmp ne i64 %cv1752, 0
  br i1 %cond1753, label %bb_rcslotrole440, label %bb_rcslotowner440
bb_rcslotrole440:
  %v1754 = load i64, ptr %slot34, align 8
  store i64 %v1754, ptr %slot277, align 8
  %v1755 = load i64, ptr %slot277, align 8
  %v1756 = load i64, ptr %slot274, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1755, i64 %v1756) nomerge, !dbg !130
  br label %bb_rcslotdone440
bb_rcslotowner440:
  %v1757 = load i64, ptr %slot34, align 8
  store i64 %v1757, ptr %slot278, align 8
  %v1758 = load i64, ptr %slot278, align 8
  %v1759 = load i64, ptr %slot274, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1758, i64 %v1759) nomerge, !dbg !130
  br label %bb_rcslotdone440
bb_rcslotdone440:
  br label %bb_i27
bb_rcarmnext415:
  br label %bb_failure
bb_i27:
  %v1760 = load i64, ptr %slot21, align 8
  %v1761 = load i64, ptr %slot25, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  store i64 %v1760, ptr %p1762, align 8, !alias.scope !3, !noalias !4
  %v1763 = load i64, ptr %slot25, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %ld1765 = load i64, ptr %p1764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1765, ptr %slot279, align 8
  %v1766 = load i64, ptr %slot279, align 8
  %op1767 = add i64 %v1766, 0
  store i64 %op1767, ptr %slot280, align 8
  %v1768 = load i64, ptr %slot280, align 8
  %v1769 = load i64, ptr %slot25, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  store i64 %v1768, ptr %p1770, align 8, !alias.scope !3, !noalias !4
  %v1771 = load i64, ptr %slot8, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  %ld1773 = load i32, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1773, ptr %slot281, align 8
  %v1774 = load i32, ptr %slot281, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcslotdrop451, label %bb_rcslotdone451
bb_rcslotdrop451:
  %v1777 = load i64, ptr %slot8, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  store i32 0, ptr %p1778, align 4, !alias.scope !3, !noalias !4
  %v1779 = load i64, ptr %slot13, align 8
  store i64 %v1779, ptr %slot282, align 8
  %v1780 = load i64, ptr %slot9, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i32, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1782, ptr %slot283, align 8
  %v1783 = load i32, ptr %slot283, align 8
  %op1784 = and i32 %v1783, 28
  store i32 %op1784, ptr %slot284, align 8
  %v1785 = load i32, ptr %slot284, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcslotrole451, label %bb_rcslotowner451
bb_rcslotrole451:
  %v1788 = load i64, ptr %slot34, align 8
  store i64 %v1788, ptr %slot285, align 8
  %v1789 = load i64, ptr %slot285, align 8
  %v1790 = load i64, ptr %slot282, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v1789, i64 %v1790) nomerge, !dbg !132
  br label %bb_rcslotdone451
bb_rcslotowner451:
  %v1791 = load i64, ptr %slot34, align 8
  store i64 %v1791, ptr %slot286, align 8
  %v1792 = load i64, ptr %slot286, align 8
  %v1793 = load i64, ptr %slot282, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v1792, i64 %v1793) nomerge, !dbg !132
  br label %bb_rcslotdone451
bb_rcslotdone451:
  %v1794 = load i64, ptr %slot25, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %ld1796 = load i64, ptr %p1795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1796, ptr %slot287, align 8
  %v1797 = load i64, ptr %slot287, align 8
  %op1798 = add i64 %v1797, 24
  store i64 %op1798, ptr %slot288, align 8
  %v1799 = load i64, ptr %slot288, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %ld1801 = load i64, ptr %p1800, align 8
  store i64 %ld1801, ptr %slot289, align 8
  %v1802 = load i64, ptr %slot289, align 8
  %v1803 = load i64, ptr %slot25, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i64 %v1802, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot8, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  %ld1807 = load i32, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1807, ptr %slot290, align 8
  %v1808 = load i32, ptr %slot290, align 8
  %cv1809 = zext i32 %v1808 to i64
  %cond1810 = icmp ne i64 %cv1809, 0
  br i1 %cond1810, label %bb_rcslotdrop463, label %bb_rcslotdone463
bb_rcslotdrop463:
  %v1811 = load i64, ptr %slot8, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i32 0, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot13, align 8
  store i64 %v1813, ptr %slot291, align 8
  %v1814 = load i64, ptr %slot9, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  %ld1816 = load i32, ptr %p1815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1816, ptr %slot292, align 8
  %v1817 = load i32, ptr %slot292, align 8
  %op1818 = and i32 %v1817, 28
  store i32 %op1818, ptr %slot293, align 8
  %v1819 = load i32, ptr %slot293, align 8
  %cv1820 = zext i32 %v1819 to i64
  %cond1821 = icmp ne i64 %cv1820, 0
  br i1 %cond1821, label %bb_rcslotrole463, label %bb_rcslotowner463
bb_rcslotrole463:
  %v1822 = load i64, ptr %slot34, align 8
  store i64 %v1822, ptr %slot294, align 8
  %v1823 = load i64, ptr %slot294, align 8
  %v1824 = load i64, ptr %slot291, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1823, i64 %v1824) nomerge, !dbg !134
  br label %bb_rcslotdone463
bb_rcslotowner463:
  %v1825 = load i64, ptr %slot34, align 8
  store i64 %v1825, ptr %slot295, align 8
  %v1826 = load i64, ptr %slot295, align 8
  %v1827 = load i64, ptr %slot291, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1826, i64 %v1827) nomerge, !dbg !134
  br label %bb_rcslotdone463
bb_rcslotdone463:
  %v1828 = load i64, ptr %slot25, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  %ld1830 = load i64, ptr %p1829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1830, ptr %slot296, align 8
  %v1831 = load i64, ptr %slot296, align 8
  %v1832 = load i64, ptr %slot18, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  store i64 %v1831, ptr %p1833, align 8, !alias.scope !3, !noalias !4
  %v1834 = load i64, ptr %slot6, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %ld1836 = load i32, ptr %p1835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1836, ptr %slot297, align 8
  %v1837 = load i32, ptr %slot297, align 8
  %cv1838 = zext i32 %v1837 to i64
  %cond1839 = icmp ne i64 %cv1838, 0
  br i1 %cond1839, label %bb_rcslotdrop473, label %bb_rcslotdone473
bb_rcslotdrop473:
  %v1840 = load i64, ptr %slot6, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i32 0, ptr %p1841, align 4, !alias.scope !3, !noalias !4
  %v1842 = load i64, ptr %slot21, align 8
  store i64 %v1842, ptr %slot298, align 8
  %v1843 = load i64, ptr %slot7, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %ld1845 = load i32, ptr %p1844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1845, ptr %slot299, align 8
  %v1846 = load i32, ptr %slot299, align 8
  %op1847 = and i32 %v1846, 28
  store i32 %op1847, ptr %slot300, align 8
  %v1848 = load i32, ptr %slot300, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcslotrole473, label %bb_rcslotowner473
bb_rcslotrole473:
  %v1851 = load i64, ptr %slot34, align 8
  store i64 %v1851, ptr %slot301, align 8
  %v1852 = load i64, ptr %slot301, align 8
  %v1853 = load i64, ptr %slot298, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v1852, i64 %v1853) nomerge, !dbg !136
  br label %bb_rcslotdone473
bb_rcslotowner473:
  %v1854 = load i64, ptr %slot34, align 8
  store i64 %v1854, ptr %slot302, align 8
  %v1855 = load i64, ptr %slot302, align 8
  %v1856 = load i64, ptr %slot298, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v1855, i64 %v1856) nomerge, !dbg !136
  br label %bb_rcslotdone473
bb_rcslotdone473:
  br label %bb_i44
bb_i33:
  br label %bb_i44
bb_i34:
  br label %bb_i44
bb_i35:
  br label %bb_i44
bb_i36:
  br label %bb_i44
bb_i37:
  br label %bb_i44
bb_i38:
  br label %bb_i44
bb_i39:
  br label %bb_i44
bb_i40:
  br label %bb_i44
bb_i41:
  br label %bb_i44
bb_i42:
  br label %bb_i44
bb_i43:
  br label %bb_i44
bb_i44:
  %v1857 = load i64, ptr %slot16, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  %ld1859 = load i64, ptr %p1858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1859, ptr %slot303, align 8
  %v1860 = load i64, ptr %slot303, align 8
  %v1861 = load i64, ptr %slot25, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  store i64 %v1860, ptr %p1862, align 8, !alias.scope !3, !noalias !4
  %v1863 = load i64, ptr %slot25, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1865, ptr %slot304, align 8
  %v1866 = load i64, ptr %slot304, align 8
  %op1867 = add i64 %v1866, 32
  store i64 %op1867, ptr %slot305, align 8
  %v1868 = load i64, ptr %slot305, align 8
  %v1869 = load i64, ptr %slot25, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  store i64 %v1868, ptr %p1870, align 8, !alias.scope !3, !noalias !4
  %v1871 = load i64, ptr %slot8, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  %ld1873 = load i32, ptr %p1872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1873, ptr %slot306, align 8
  %v1874 = load i32, ptr %slot306, align 8
  %cv1875 = zext i32 %v1874 to i64
  %cond1876 = icmp ne i64 %cv1875, 0
  br i1 %cond1876, label %bb_rcslotdrop485, label %bb_rcslotdone485
bb_rcslotdrop485:
  %v1877 = load i64, ptr %slot8, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i32 0, ptr %p1878, align 4, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot13, align 8
  store i64 %v1879, ptr %slot307, align 8
  %v1880 = load i64, ptr %slot9, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %ld1882 = load i32, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1882, ptr %slot308, align 8
  %v1883 = load i32, ptr %slot308, align 8
  %op1884 = and i32 %v1883, 28
  store i32 %op1884, ptr %slot309, align 8
  %v1885 = load i32, ptr %slot309, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcslotrole485, label %bb_rcslotowner485
bb_rcslotrole485:
  %v1888 = load i64, ptr %slot34, align 8
  store i64 %v1888, ptr %slot310, align 8
  %v1889 = load i64, ptr %slot310, align 8
  %v1890 = load i64, ptr %slot307, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1889, i64 %v1890) nomerge, !dbg !138
  br label %bb_rcslotdone485
bb_rcslotowner485:
  %v1891 = load i64, ptr %slot34, align 8
  store i64 %v1891, ptr %slot311, align 8
  %v1892 = load i64, ptr %slot311, align 8
  %v1893 = load i64, ptr %slot307, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1892, i64 %v1893) nomerge, !dbg !138
  br label %bb_rcslotdone485
bb_rcslotdone485:
  %v1894 = load i64, ptr %slot26, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 0, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot25, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i64, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1898, ptr %slot312, align 8
  %v1899 = load i64, ptr %slot26, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot313, align 8
  %v1902 = load i64, ptr %slot1, align 8
  %v1903 = load i64, ptr %slot312, align 8
  %v1904 = load i64, ptr %slot313, align 8
  %call1905 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1902, i64 %v1903, i64 %v1904) nomerge, !dbg !140
  store { i64, i64 } %call1905, ptr %callresult315, align 8
  %addr1906 = ptrtoint ptr %callresult315 to i64
  store i64 %addr1906, ptr %slot314, align 8
  %v1907 = load i64, ptr %slot314, align 8
  %v1908 = load i64, ptr %slot25, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i64 %v1907, ptr %p1909, align 8, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot8, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i32, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1912, ptr %slot316, align 8
  %v1913 = load i32, ptr %slot316, align 8
  %cv1914 = zext i32 %v1913 to i64
  %cond1915 = icmp ne i64 %cv1914, 0
  br i1 %cond1915, label %bb_rcslotdrop497, label %bb_rcslotdone497
bb_rcslotdrop497:
  %v1916 = load i64, ptr %slot8, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i32 0, ptr %p1917, align 4, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot13, align 8
  store i64 %v1918, ptr %slot317, align 8
  %v1919 = load i64, ptr %slot9, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i32, ptr %p1920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1921, ptr %slot318, align 8
  %v1922 = load i32, ptr %slot318, align 8
  %op1923 = and i32 %v1922, 28
  store i32 %op1923, ptr %slot319, align 8
  %v1924 = load i32, ptr %slot319, align 8
  %cv1925 = zext i32 %v1924 to i64
  %cond1926 = icmp ne i64 %cv1925, 0
  br i1 %cond1926, label %bb_rcslotrole497, label %bb_rcslotowner497
bb_rcslotrole497:
  %v1927 = load i64, ptr %slot34, align 8
  store i64 %v1927, ptr %slot320, align 8
  %v1928 = load i64, ptr %slot320, align 8
  %v1929 = load i64, ptr %slot317, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1928, i64 %v1929) nomerge, !dbg !140
  br label %bb_rcslotdone497
bb_rcslotowner497:
  %v1930 = load i64, ptr %slot34, align 8
  store i64 %v1930, ptr %slot321, align 8
  %v1931 = load i64, ptr %slot321, align 8
  %v1932 = load i64, ptr %slot317, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1931, i64 %v1932) nomerge, !dbg !140
  br label %bb_rcslotdone497
bb_rcslotdone497:
  %v1933 = load i64, ptr %slot25, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i64, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1935, ptr %slot322, align 8
  %v1936 = load i64, ptr %slot322, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  %ld1938 = load i32, ptr %p1937, align 4
  %ext1939 = zext i32 %ld1938 to i64
  store i64 %ext1939, ptr %slot323, align 8
  %v1940 = load i64, ptr %slot323, align 8
  %cmp1941 = icmp eq i64 %v1940, 0
  %cv1942 = zext i1 %cmp1941 to i64
  store i64 %cv1942, ptr %slot324, align 8
  %v1943 = load i64, ptr %slot324, align 8
  %cond1944 = icmp ne i64 %v1943, 0
  br i1 %cond1944, label %bb_rcarm506, label %bb_rcarmnext506
bb_rcarm506:
  br label %bb_i81
bb_rcarmnext506:
  %v1945 = load i64, ptr %slot323, align 8
  %cmp1946 = icmp eq i64 %v1945, 1
  %cv1947 = zext i1 %cmp1946 to i64
  store i64 %cv1947, ptr %slot325, align 8
  %v1948 = load i64, ptr %slot325, align 8
  %cond1949 = icmp ne i64 %v1948, 0
  br i1 %cond1949, label %bb_rcarm507, label %bb_rcarmnext507
bb_rcarm507:
  br label %bb_i82
bb_rcarmnext507:
  %v1950 = load i64, ptr %slot323, align 8
  %cmp1951 = icmp eq i64 %v1950, 2
  %cv1952 = zext i1 %cmp1951 to i64
  store i64 %cv1952, ptr %slot326, align 8
  %v1953 = load i64, ptr %slot326, align 8
  %cond1954 = icmp ne i64 %v1953, 0
  br i1 %cond1954, label %bb_rcarm508, label %bb_rcarmnext508
bb_rcarm508:
  br label %bb_i83
bb_rcarmnext508:
  %v1955 = load i64, ptr %slot323, align 8
  %cmp1956 = icmp eq i64 %v1955, 3
  %cv1957 = zext i1 %cmp1956 to i64
  store i64 %cv1957, ptr %slot327, align 8
  %v1958 = load i64, ptr %slot327, align 8
  %cond1959 = icmp ne i64 %v1958, 0
  br i1 %cond1959, label %bb_rcarm509, label %bb_rcarmnext509
bb_rcarm509:
  %v1960 = load i64, ptr %slot15, align 8
  store i64 %v1960, ptr %slot328, align 8
  %v1961 = load i64, ptr %slot322, align 8
  %op1962 = add i64 %v1961, 8
  store i64 %op1962, ptr %slot329, align 8
  %v1963 = load i64, ptr %slot35, align 8
  store i64 %v1963, ptr %slot330, align 8
  %v1964 = load i64, ptr %slot329, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8
  store i64 %ld1966, ptr %slot331, align 8
  %v1967 = load i64, ptr %slot331, align 8
  %v1968 = load i64, ptr %slot328, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  store i64 %v1967, ptr %p1969, align 8, !alias.scope !3, !noalias !4
  %v1970 = load i64, ptr %slot11, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  store i32 0, ptr %p1971, align 4, !alias.scope !3, !noalias !4
  %v1972 = load i64, ptr %slot10, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i32 1, ptr %p1973, align 4, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot328, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  %ld1976 = load i64, ptr %p1975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1976, ptr %slot332, align 8
  %v1977 = load i64, ptr %slot332, align 8
  %v1978 = load i64, ptr %slot22, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  store i64 %v1977, ptr %p1979, align 8, !alias.scope !3, !noalias !4
  %v1980 = load i64, ptr %slot10, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i32 0, ptr %p1981, align 4, !alias.scope !3, !noalias !4
  br label %bb_i49
bb_rcarmnext509:
  br label %bb_failure
bb_i49:
  %v1982 = load i64, ptr %slot16, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %ld1984 = load i64, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1984, ptr %slot333, align 8
  %v1985 = load i64, ptr %slot333, align 8
  %v1986 = load i64, ptr %slot25, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  store i64 %v1985, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  %v1988 = load i64, ptr %slot25, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %ld1990 = load i64, ptr %p1989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1990, ptr %slot334, align 8
  %v1991 = load i64, ptr %slot334, align 8
  %op1992 = add i64 %v1991, 32
  store i64 %op1992, ptr %slot335, align 8
  %v1993 = load i64, ptr %slot335, align 8
  %v1994 = load i64, ptr %slot25, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 %v1993, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot8, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i32, ptr %p1997, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1998, ptr %slot336, align 8
  %v1999 = load i32, ptr %slot336, align 8
  %cv2000 = zext i32 %v1999 to i64
  %cond2001 = icmp ne i64 %cv2000, 0
  br i1 %cond2001, label %bb_rcslotdrop523, label %bb_rcslotdone523
bb_rcslotdrop523:
  %v2002 = load i64, ptr %slot8, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  store i32 0, ptr %p2003, align 4, !alias.scope !3, !noalias !4
  %v2004 = load i64, ptr %slot13, align 8
  store i64 %v2004, ptr %slot337, align 8
  %v2005 = load i64, ptr %slot9, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %ld2007 = load i32, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2007, ptr %slot338, align 8
  %v2008 = load i32, ptr %slot338, align 8
  %op2009 = and i32 %v2008, 28
  store i32 %op2009, ptr %slot339, align 8
  %v2010 = load i32, ptr %slot339, align 8
  %cv2011 = zext i32 %v2010 to i64
  %cond2012 = icmp ne i64 %cv2011, 0
  br i1 %cond2012, label %bb_rcslotrole523, label %bb_rcslotowner523
bb_rcslotrole523:
  %v2013 = load i64, ptr %slot34, align 8
  store i64 %v2013, ptr %slot340, align 8
  %v2014 = load i64, ptr %slot340, align 8
  %v2015 = load i64, ptr %slot337, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2014, i64 %v2015) nomerge, !dbg !142
  br label %bb_rcslotdone523
bb_rcslotowner523:
  %v2016 = load i64, ptr %slot34, align 8
  store i64 %v2016, ptr %slot341, align 8
  %v2017 = load i64, ptr %slot341, align 8
  %v2018 = load i64, ptr %slot337, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2017, i64 %v2018) nomerge, !dbg !142
  br label %bb_rcslotdone523
bb_rcslotdone523:
  %v2019 = load i64, ptr %slot25, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %ld2021 = load i64, ptr %p2020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2021, ptr %slot342, align 8
  %v2022 = load i64, ptr %slot342, align 8
  %op2023 = add i64 %v2022, 0
  store i64 %op2023, ptr %slot343, align 8
  %v2024 = load i64, ptr %slot343, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %ld2026 = load i64, ptr %p2025, align 8
  store i64 %ld2026, ptr %slot344, align 8
  %v2027 = load i64, ptr %slot344, align 8
  %v2028 = load i64, ptr %slot25, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  store i64 %v2027, ptr %p2029, align 8, !alias.scope !3, !noalias !4
  %v2030 = load i64, ptr %slot8, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i32, ptr %p2031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2032, ptr %slot345, align 8
  %v2033 = load i32, ptr %slot345, align 8
  %cv2034 = zext i32 %v2033 to i64
  %cond2035 = icmp ne i64 %cv2034, 0
  br i1 %cond2035, label %bb_rcslotdrop535, label %bb_rcslotdone535
bb_rcslotdrop535:
  %v2036 = load i64, ptr %slot8, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  store i32 0, ptr %p2037, align 4, !alias.scope !3, !noalias !4
  %v2038 = load i64, ptr %slot13, align 8
  store i64 %v2038, ptr %slot346, align 8
  %v2039 = load i64, ptr %slot9, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %ld2041 = load i32, ptr %p2040, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2041, ptr %slot347, align 8
  %v2042 = load i32, ptr %slot347, align 8
  %op2043 = and i32 %v2042, 28
  store i32 %op2043, ptr %slot348, align 8
  %v2044 = load i32, ptr %slot348, align 8
  %cv2045 = zext i32 %v2044 to i64
  %cond2046 = icmp ne i64 %cv2045, 0
  br i1 %cond2046, label %bb_rcslotrole535, label %bb_rcslotowner535
bb_rcslotrole535:
  %v2047 = load i64, ptr %slot34, align 8
  store i64 %v2047, ptr %slot349, align 8
  %v2048 = load i64, ptr %slot349, align 8
  %v2049 = load i64, ptr %slot346, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2048, i64 %v2049) nomerge, !dbg !144
  br label %bb_rcslotdone535
bb_rcslotowner535:
  %v2050 = load i64, ptr %slot34, align 8
  store i64 %v2050, ptr %slot350, align 8
  %v2051 = load i64, ptr %slot350, align 8
  %v2052 = load i64, ptr %slot346, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2051, i64 %v2052) nomerge, !dbg !144
  br label %bb_rcslotdone535
bb_rcslotdone535:
  %v2053 = load i64, ptr %slot25, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %ld2055 = load i64, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2055, ptr %slot351, align 8
  %v2056 = load i64, ptr %slot351, align 8
  %v2057 = load i64, ptr %slot23, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i64 %v2056, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot22, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  %ld2061 = load i64, ptr %p2060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2061, ptr %slot352, align 8
  %v2062 = load i64, ptr %slot352, align 8
  %v2063 = load i64, ptr %slot25, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  store i64 %v2062, ptr %p2064, align 8, !alias.scope !3, !noalias !4
  %v2065 = load i64, ptr %slot25, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  %ld2067 = load i64, ptr %p2066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2067, ptr %slot353, align 8
  %v2068 = load i64, ptr %slot353, align 8
  %v2069 = load i64, ptr %slot24, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i64 %v2068, ptr %p2070, align 8, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot24, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %ld2073 = load i64, ptr %p2072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2073, ptr %slot354, align 8
  %v2074 = load i64, ptr %slot354, align 8
  %v2075 = load i64, ptr %slot25, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  store i64 %v2074, ptr %p2076, align 8, !alias.scope !3, !noalias !4
  %v2077 = load i64, ptr %slot26, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  store i64 0, ptr %p2078, align 8, !alias.scope !3, !noalias !4
  %v2079 = load i64, ptr %slot26, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %ld2081 = load i64, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2081, ptr %slot355, align 8
  %v2082 = load i64, ptr %slot25, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  %ld2084 = load i64, ptr %p2083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2084, ptr %slot356, align 8
  %v2085 = load i64, ptr %slot356, align 8
  %v2086 = load i64, ptr %slot355, align 8
  %cmp2087 = icmp slt i64 %v2085, %v2086
  %cv2088 = zext i1 %cmp2087 to i64
  store i64 %cv2088, ptr %slot357, align 8
  %v2089 = load i64, ptr %slot357, align 8
  %v2090 = load i64, ptr %slot25, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i64 %v2089, ptr %p2091, align 8, !alias.scope !3, !noalias !4
  %v2092 = load i64, ptr %slot25, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %ld2094 = load i64, ptr %p2093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2094, ptr %slot358, align 8
  %v2095 = load i64, ptr %slot358, align 8
  %cond2096 = icmp ne i64 %v2095, 0
  br i1 %cond2096, label %bb_next550, label %bb_i64
bb_next550:
  %v2097 = load i64, ptr %slot23, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ld2099 = load i64, ptr %p2098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2099, ptr %slot359, align 8
  %v2100 = load i64, ptr %slot359, align 8
  %op2101 = add i64 %v2100, 0
  store i64 %op2101, ptr %slot360, align 8
  %v2102 = load i64, ptr %slot360, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  %ld2104 = load i64, ptr %p2103, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2104, ptr %slot361, align 8
  %v2105 = load i64, ptr %slot361, align 8
  %v2106 = load i64, ptr %slot25, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i64 %v2105, ptr %p2107, align 8, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot25, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %ld2110 = load i64, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2110, ptr %slot362, align 8
  %v2111 = load i64, ptr %slot362, align 8
  %cmp2112 = icmp ugt i64 %v2111, 9223372036854775807
  %cv2113 = zext i1 %cmp2112 to i64
  store i64 %cv2113, ptr %slot363, align 8
  %v2114 = load i64, ptr %slot363, align 8
  %cond2115 = icmp ne i64 %v2114, 0
  br i1 %cond2115, label %bb_cast_overflow555, label %bb_cast_ok555
bb_cast_overflow555:
  %v2116 = load i64, ptr %slot1, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %v2118 = load i64, ptr %slot362, align 8
  call void @myl_qbe_fail_cast(ptr %p2117, i64 %v2118, i64 320) nomerge, !dbg !146
  unreachable
bb_cast_ok555:
  %v2119 = load i64, ptr %slot362, align 8
  %v2120 = load i64, ptr %slot25, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i64 %v2119, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot24, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i64, ptr %p2123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2124, ptr %slot364, align 8
  %v2125 = load i64, ptr %slot364, align 8
  %v2126 = load i64, ptr %slot26, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  store i64 %v2125, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  %v2128 = load i64, ptr %slot26, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %ld2130 = load i64, ptr %p2129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2130, ptr %slot365, align 8
  %v2131 = load i64, ptr %slot25, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i64, ptr %p2132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2133, ptr %slot366, align 8
  %v2134 = load i64, ptr %slot366, align 8
  %v2135 = load i64, ptr %slot365, align 8
  %ovpair2137 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2134, i64 %v2135)
  %op2136 = extractvalue { i64, i1 } %ovpair2137, 0
  %ov2138 = extractvalue { i64, i1 } %ovpair2137, 1
  store i64 %op2136, ptr %slot367, align 8
  %v2139 = load i64, ptr %slot366, align 8
  %v2140 = load i64, ptr %slot367, align 8
  %op2141 = xor i64 %v2139, %v2140
  store i64 %op2141, ptr %slot368, align 8
  %v2142 = load i64, ptr %slot365, align 8
  %v2143 = load i64, ptr %slot367, align 8
  %op2144 = xor i64 %v2142, %v2143
  store i64 %op2144, ptr %slot369, align 8
  %v2145 = load i64, ptr %slot368, align 8
  %v2146 = load i64, ptr %slot369, align 8
  %op2147 = and i64 %v2145, %v2146
  store i64 %op2147, ptr %slot370, align 8
  %cv2148 = zext i1 %ov2138 to i64
  store i64 %cv2148, ptr %slot371, align 8
  %v2149 = load i64, ptr %slot371, align 8
  %cond2150 = icmp ne i64 %v2149, 0
  br i1 %cond2150, label %bb_overflow559, label %bb_checked559
bb_overflow559:
  %v2151 = load i64, ptr %slot1, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %v2153 = load i64, ptr %slot366, align 8
  %v2154 = load i64, ptr %slot365, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2152, i64 0, i64 %v2153, i64 %v2154, i64 64) nomerge, !dbg !148
  unreachable
bb_checked559:
  %v2155 = load i64, ptr %slot367, align 8
  %v2156 = load i64, ptr %slot25, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  store i64 %v2155, ptr %p2157, align 8, !alias.scope !3, !noalias !4
  %v2158 = load i64, ptr %slot25, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %ld2160 = load i64, ptr %p2159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2160, ptr %slot372, align 8
  %v2161 = load i64, ptr %slot372, align 8
  %v2162 = load i64, ptr %slot24, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i64 %v2161, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  br label %bb_i64
bb_i64:
  %v2164 = load i64, ptr %slot24, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  %ld2166 = load i64, ptr %p2165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2166, ptr %slot373, align 8
  %v2167 = load i64, ptr %slot373, align 8
  %v2168 = load i64, ptr %slot25, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  store i64 %v2167, ptr %p2169, align 8, !alias.scope !3, !noalias !4
  %v2170 = load i64, ptr %slot23, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %ld2172 = load i64, ptr %p2171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2172, ptr %slot374, align 8
  %v2173 = load i64, ptr %slot25, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %ld2175 = load i64, ptr %p2174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2175, ptr %slot375, align 8
  %v2176 = load i64, ptr %slot374, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2178, ptr %slot376, align 8
  %v2179 = load i64, ptr %slot375, align 8
  %v2180 = load i64, ptr %slot376, align 8
  %cmp2181 = icmp ult i64 %v2179, %v2180
  %cv2182 = zext i1 %cmp2181 to i64
  store i64 %cv2182, ptr %slot377, align 8
  %v2183 = load i64, ptr %slot377, align 8
  %cond2184 = icmp ne i64 %v2183, 0
  br i1 %cond2184, label %bb_success571, label %bb_failed571
bb_failed571:
  %v2185 = load i64, ptr %slot1, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %v2187 = load i64, ptr %slot375, align 8
  %v2188 = load i64, ptr %slot376, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2186, i64 %v2187, i64 %v2188) nomerge, !dbg !150
  unreachable
bb_success571:
  %v2189 = load i64, ptr %slot374, align 8
  %op2190 = add i64 %v2189, 32
  store i64 %op2190, ptr %slot378, align 8
  %v2191 = load i64, ptr %slot378, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i64, ptr %p2192, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2193, ptr %slot379, align 8
  %v2194 = load i64, ptr %slot375, align 8
  %op2195 = mul i64 %v2194, 56
  store i64 %op2195, ptr %slot380, align 8
  %v2196 = load i64, ptr %slot379, align 8
  %v2197 = load i64, ptr %slot380, align 8
  %op2198 = add i64 %v2196, %v2197
  store i64 %op2198, ptr %slot381, align 8
  %v2199 = load i64, ptr %slot381, align 8
  %v2200 = load i64, ptr %slot25, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i64 %v2199, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot25, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i64, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2204, ptr %slot382, align 8
  %v2205 = load i64, ptr %slot15, align 8
  store i64 %v2205, ptr %slot383, align 8
  %v2206 = load i64, ptr %slot34, align 8
  %v2207 = load i64, ptr %slot383, align 8
  %v2208 = load i64, ptr %slot382, align 8
  %call2209 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v2206, i64 %v2207, i64 %v2208) nomerge, !dbg !150
  store i32 %call2209, ptr %slot384, align 8
  %v2210 = load i32, ptr %slot384, align 8
  %cv2211 = zext i32 %v2210 to i64
  %cond2212 = icmp ne i64 %cv2211, 0
  br i1 %cond2212, label %bb_rcsuccess579, label %bb_rcfailure579
bb_rcfailure579:
  %v2213 = load i64, ptr %slot34, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %call2215 = call i32 @myl_rc_take_failure(ptr %p2214) nomerge, !dbg !150
  store i32 %call2215, ptr %slot385, align 8
  %v2216 = load i64, ptr %slot1, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %v2218 = load i32, ptr %slot385, align 8
  %call2219 = call i32 @myl_qbe_rc_status(ptr %p2217, i32 %v2218) nomerge, !dbg !150
  store i32 %call2219, ptr %slot386, align 8
  br label %bb_failure
bb_rcsuccess579:
  %v2220 = load i64, ptr %slot11, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i32 2, ptr %p2221, align 4, !alias.scope !3, !noalias !4
  %v2222 = load i64, ptr %slot11, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i32 16, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot10, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  store i32 1, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  %v2226 = load i64, ptr %slot13, align 8
  store i64 %v2226, ptr %slot387, align 8
  %v2227 = load i64, ptr %slot15, align 8
  store i64 %v2227, ptr %slot388, align 8
  %v2228 = load i64, ptr %slot388, align 8
  %v2229 = load i64, ptr %slot387, align 8
  %p2230 = inttoptr i64 %v2228 to ptr
  %p2231 = inttoptr i64 %v2229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2231, ptr %p2230, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot9, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  store i32 2, ptr %p2233, align 4, !alias.scope !3, !noalias !4
  %v2234 = load i64, ptr %slot11, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  %ld2236 = load i32, ptr %p2235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2236, ptr %slot389, align 8
  %v2237 = load i32, ptr %slot389, align 8
  %v2238 = load i64, ptr %slot9, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  store i32 %v2237, ptr %p2239, align 4, !alias.scope !3, !noalias !4
  %v2240 = load i64, ptr %slot10, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i32 0, ptr %p2241, align 4, !alias.scope !3, !noalias !4
  %v2242 = load i64, ptr %slot8, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i32 1, ptr %p2243, align 4, !alias.scope !3, !noalias !4
  %v2244 = load i64, ptr %slot387, align 8
  %v2245 = load i64, ptr %slot25, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i64 %v2244, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot25, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i64, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2249, ptr %slot390, align 8
  %v2250 = load i64, ptr %slot390, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i32, ptr %p2251, align 4
  %ext2253 = zext i32 %ld2252 to i64
  store i64 %ext2253, ptr %slot391, align 8
  %v2254 = load i64, ptr %slot391, align 8
  %cmp2255 = icmp eq i64 %v2254, 0
  %cv2256 = zext i1 %cmp2255 to i64
  store i64 %cv2256, ptr %slot392, align 8
  %v2257 = load i64, ptr %slot392, align 8
  %cond2258 = icmp ne i64 %v2257, 0
  br i1 %cond2258, label %bb_rcarm595, label %bb_rcarmnext595
bb_rcarm595:
  %v2259 = load i64, ptr %slot8, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %ld2261 = load i32, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2261, ptr %slot393, align 8
  %v2262 = load i32, ptr %slot393, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcslotdrop598, label %bb_rcslotdone598
bb_rcslotdrop598:
  %v2265 = load i64, ptr %slot8, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i32 0, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot13, align 8
  store i64 %v2267, ptr %slot394, align 8
  %v2268 = load i64, ptr %slot9, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %ld2270 = load i32, ptr %p2269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2270, ptr %slot395, align 8
  %v2271 = load i32, ptr %slot395, align 8
  %op2272 = and i32 %v2271, 28
  store i32 %op2272, ptr %slot396, align 8
  %v2273 = load i32, ptr %slot396, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcslotrole598, label %bb_rcslotowner598
bb_rcslotrole598:
  %v2276 = load i64, ptr %slot34, align 8
  store i64 %v2276, ptr %slot397, align 8
  %v2277 = load i64, ptr %slot397, align 8
  %v2278 = load i64, ptr %slot394, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2277, i64 %v2278) nomerge, !dbg !152
  br label %bb_rcslotdone598
bb_rcslotowner598:
  %v2279 = load i64, ptr %slot34, align 8
  store i64 %v2279, ptr %slot398, align 8
  %v2280 = load i64, ptr %slot398, align 8
  %v2281 = load i64, ptr %slot394, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2280, i64 %v2281) nomerge, !dbg !152
  br label %bb_rcslotdone598
bb_rcslotdone598:
  br label %bb_i70
bb_rcarmnext595:
  %v2282 = load i64, ptr %slot391, align 8
  %cmp2283 = icmp eq i64 %v2282, 1
  %cv2284 = zext i1 %cmp2283 to i64
  store i64 %cv2284, ptr %slot399, align 8
  %v2285 = load i64, ptr %slot399, align 8
  %cond2286 = icmp ne i64 %v2285, 0
  br i1 %cond2286, label %bb_rcarm605, label %bb_rcarmnext605
bb_rcarm605:
  %v2287 = load i64, ptr %slot8, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  %ld2289 = load i32, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2289, ptr %slot400, align 8
  %v2290 = load i32, ptr %slot400, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcslotdrop608, label %bb_rcslotdone608
bb_rcslotdrop608:
  %v2293 = load i64, ptr %slot8, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  store i32 0, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  %v2295 = load i64, ptr %slot13, align 8
  store i64 %v2295, ptr %slot401, align 8
  %v2296 = load i64, ptr %slot9, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i32, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2298, ptr %slot402, align 8
  %v2299 = load i32, ptr %slot402, align 8
  %op2300 = and i32 %v2299, 28
  store i32 %op2300, ptr %slot403, align 8
  %v2301 = load i32, ptr %slot403, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcslotrole608, label %bb_rcslotowner608
bb_rcslotrole608:
  %v2304 = load i64, ptr %slot34, align 8
  store i64 %v2304, ptr %slot404, align 8
  %v2305 = load i64, ptr %slot404, align 8
  %v2306 = load i64, ptr %slot401, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2305, i64 %v2306) nomerge, !dbg !152
  br label %bb_rcslotdone608
bb_rcslotowner608:
  %v2307 = load i64, ptr %slot34, align 8
  store i64 %v2307, ptr %slot405, align 8
  %v2308 = load i64, ptr %slot405, align 8
  %v2309 = load i64, ptr %slot401, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2308, i64 %v2309) nomerge, !dbg !152
  br label %bb_rcslotdone608
bb_rcslotdone608:
  br label %bb_i71
bb_rcarmnext605:
  %v2310 = load i64, ptr %slot391, align 8
  %cmp2311 = icmp eq i64 %v2310, 2
  %cv2312 = zext i1 %cmp2311 to i64
  store i64 %cv2312, ptr %slot406, align 8
  %v2313 = load i64, ptr %slot406, align 8
  %cond2314 = icmp ne i64 %v2313, 0
  br i1 %cond2314, label %bb_rcarm615, label %bb_rcarmnext615
bb_rcarm615:
  %v2315 = load i64, ptr %slot8, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  %ld2317 = load i32, ptr %p2316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2317, ptr %slot407, align 8
  %v2318 = load i32, ptr %slot407, align 8
  %cv2319 = zext i32 %v2318 to i64
  %cond2320 = icmp ne i64 %cv2319, 0
  br i1 %cond2320, label %bb_rcslotdrop618, label %bb_rcslotdone618
bb_rcslotdrop618:
  %v2321 = load i64, ptr %slot8, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i32 0, ptr %p2322, align 4, !alias.scope !3, !noalias !4
  %v2323 = load i64, ptr %slot13, align 8
  store i64 %v2323, ptr %slot408, align 8
  %v2324 = load i64, ptr %slot9, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i32, ptr %p2325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2326, ptr %slot409, align 8
  %v2327 = load i32, ptr %slot409, align 8
  %op2328 = and i32 %v2327, 28
  store i32 %op2328, ptr %slot410, align 8
  %v2329 = load i32, ptr %slot410, align 8
  %cv2330 = zext i32 %v2329 to i64
  %cond2331 = icmp ne i64 %cv2330, 0
  br i1 %cond2331, label %bb_rcslotrole618, label %bb_rcslotowner618
bb_rcslotrole618:
  %v2332 = load i64, ptr %slot34, align 8
  store i64 %v2332, ptr %slot411, align 8
  %v2333 = load i64, ptr %slot411, align 8
  %v2334 = load i64, ptr %slot408, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2333, i64 %v2334) nomerge, !dbg !152
  br label %bb_rcslotdone618
bb_rcslotowner618:
  %v2335 = load i64, ptr %slot34, align 8
  store i64 %v2335, ptr %slot412, align 8
  %v2336 = load i64, ptr %slot412, align 8
  %v2337 = load i64, ptr %slot408, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2336, i64 %v2337) nomerge, !dbg !152
  br label %bb_rcslotdone618
bb_rcslotdone618:
  br label %bb_i72
bb_rcarmnext615:
  %v2338 = load i64, ptr %slot391, align 8
  %cmp2339 = icmp eq i64 %v2338, 3
  %cv2340 = zext i1 %cmp2339 to i64
  store i64 %cv2340, ptr %slot413, align 8
  %v2341 = load i64, ptr %slot413, align 8
  %cond2342 = icmp ne i64 %v2341, 0
  br i1 %cond2342, label %bb_rcarm625, label %bb_rcarmnext625
bb_rcarm625:
  %v2343 = load i64, ptr %slot8, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i32, ptr %p2344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2345, ptr %slot414, align 8
  %v2346 = load i32, ptr %slot414, align 8
  %cv2347 = zext i32 %v2346 to i64
  %cond2348 = icmp ne i64 %cv2347, 0
  br i1 %cond2348, label %bb_rcslotdrop628, label %bb_rcslotdone628
bb_rcslotdrop628:
  %v2349 = load i64, ptr %slot8, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i32 0, ptr %p2350, align 4, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot13, align 8
  store i64 %v2351, ptr %slot415, align 8
  %v2352 = load i64, ptr %slot9, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %ld2354 = load i32, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2354, ptr %slot416, align 8
  %v2355 = load i32, ptr %slot416, align 8
  %op2356 = and i32 %v2355, 28
  store i32 %op2356, ptr %slot417, align 8
  %v2357 = load i32, ptr %slot417, align 8
  %cv2358 = zext i32 %v2357 to i64
  %cond2359 = icmp ne i64 %cv2358, 0
  br i1 %cond2359, label %bb_rcslotrole628, label %bb_rcslotowner628
bb_rcslotrole628:
  %v2360 = load i64, ptr %slot34, align 8
  store i64 %v2360, ptr %slot418, align 8
  %v2361 = load i64, ptr %slot418, align 8
  %v2362 = load i64, ptr %slot415, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2361, i64 %v2362) nomerge, !dbg !152
  br label %bb_rcslotdone628
bb_rcslotowner628:
  %v2363 = load i64, ptr %slot34, align 8
  store i64 %v2363, ptr %slot419, align 8
  %v2364 = load i64, ptr %slot419, align 8
  %v2365 = load i64, ptr %slot415, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2364, i64 %v2365) nomerge, !dbg !152
  br label %bb_rcslotdone628
bb_rcslotdone628:
  br label %bb_i73
bb_rcarmnext625:
  %v2366 = load i64, ptr %slot391, align 8
  %cmp2367 = icmp eq i64 %v2366, 4
  %cv2368 = zext i1 %cmp2367 to i64
  store i64 %cv2368, ptr %slot420, align 8
  %v2369 = load i64, ptr %slot420, align 8
  %cond2370 = icmp ne i64 %v2369, 0
  br i1 %cond2370, label %bb_rcarm635, label %bb_rcarmnext635
bb_rcarm635:
  %v2371 = load i64, ptr %slot8, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  %ld2373 = load i32, ptr %p2372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2373, ptr %slot421, align 8
  %v2374 = load i32, ptr %slot421, align 8
  %cv2375 = zext i32 %v2374 to i64
  %cond2376 = icmp ne i64 %cv2375, 0
  br i1 %cond2376, label %bb_rcslotdrop638, label %bb_rcslotdone638
bb_rcslotdrop638:
  %v2377 = load i64, ptr %slot8, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i32 0, ptr %p2378, align 4, !alias.scope !3, !noalias !4
  %v2379 = load i64, ptr %slot13, align 8
  store i64 %v2379, ptr %slot422, align 8
  %v2380 = load i64, ptr %slot9, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i32, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2382, ptr %slot423, align 8
  %v2383 = load i32, ptr %slot423, align 8
  %op2384 = and i32 %v2383, 28
  store i32 %op2384, ptr %slot424, align 8
  %v2385 = load i32, ptr %slot424, align 8
  %cv2386 = zext i32 %v2385 to i64
  %cond2387 = icmp ne i64 %cv2386, 0
  br i1 %cond2387, label %bb_rcslotrole638, label %bb_rcslotowner638
bb_rcslotrole638:
  %v2388 = load i64, ptr %slot34, align 8
  store i64 %v2388, ptr %slot425, align 8
  %v2389 = load i64, ptr %slot425, align 8
  %v2390 = load i64, ptr %slot422, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2389, i64 %v2390) nomerge, !dbg !152
  br label %bb_rcslotdone638
bb_rcslotowner638:
  %v2391 = load i64, ptr %slot34, align 8
  store i64 %v2391, ptr %slot426, align 8
  %v2392 = load i64, ptr %slot426, align 8
  %v2393 = load i64, ptr %slot422, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2392, i64 %v2393) nomerge, !dbg !152
  br label %bb_rcslotdone638
bb_rcslotdone638:
  br label %bb_i74
bb_rcarmnext635:
  %v2394 = load i64, ptr %slot391, align 8
  %cmp2395 = icmp eq i64 %v2394, 5
  %cv2396 = zext i1 %cmp2395 to i64
  store i64 %cv2396, ptr %slot427, align 8
  %v2397 = load i64, ptr %slot427, align 8
  %cond2398 = icmp ne i64 %v2397, 0
  br i1 %cond2398, label %bb_rcarm645, label %bb_rcarmnext645
bb_rcarm645:
  %v2399 = load i64, ptr %slot8, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i32, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2401, ptr %slot428, align 8
  %v2402 = load i32, ptr %slot428, align 8
  %cv2403 = zext i32 %v2402 to i64
  %cond2404 = icmp ne i64 %cv2403, 0
  br i1 %cond2404, label %bb_rcslotdrop648, label %bb_rcslotdone648
bb_rcslotdrop648:
  %v2405 = load i64, ptr %slot8, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 0, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot13, align 8
  store i64 %v2407, ptr %slot429, align 8
  %v2408 = load i64, ptr %slot9, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %ld2410 = load i32, ptr %p2409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2410, ptr %slot430, align 8
  %v2411 = load i32, ptr %slot430, align 8
  %op2412 = and i32 %v2411, 28
  store i32 %op2412, ptr %slot431, align 8
  %v2413 = load i32, ptr %slot431, align 8
  %cv2414 = zext i32 %v2413 to i64
  %cond2415 = icmp ne i64 %cv2414, 0
  br i1 %cond2415, label %bb_rcslotrole648, label %bb_rcslotowner648
bb_rcslotrole648:
  %v2416 = load i64, ptr %slot34, align 8
  store i64 %v2416, ptr %slot432, align 8
  %v2417 = load i64, ptr %slot432, align 8
  %v2418 = load i64, ptr %slot429, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2417, i64 %v2418) nomerge, !dbg !152
  br label %bb_rcslotdone648
bb_rcslotowner648:
  %v2419 = load i64, ptr %slot34, align 8
  store i64 %v2419, ptr %slot433, align 8
  %v2420 = load i64, ptr %slot433, align 8
  %v2421 = load i64, ptr %slot429, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2420, i64 %v2421) nomerge, !dbg !152
  br label %bb_rcslotdone648
bb_rcslotdone648:
  br label %bb_i75
bb_rcarmnext645:
  %v2422 = load i64, ptr %slot391, align 8
  %cmp2423 = icmp eq i64 %v2422, 6
  %cv2424 = zext i1 %cmp2423 to i64
  store i64 %cv2424, ptr %slot434, align 8
  %v2425 = load i64, ptr %slot434, align 8
  %cond2426 = icmp ne i64 %v2425, 0
  br i1 %cond2426, label %bb_rcarm655, label %bb_rcarmnext655
bb_rcarm655:
  %v2427 = load i64, ptr %slot8, align 8
  %p2428 = inttoptr i64 %v2427 to ptr
  %ld2429 = load i32, ptr %p2428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2429, ptr %slot435, align 8
  %v2430 = load i32, ptr %slot435, align 8
  %cv2431 = zext i32 %v2430 to i64
  %cond2432 = icmp ne i64 %cv2431, 0
  br i1 %cond2432, label %bb_rcslotdrop658, label %bb_rcslotdone658
bb_rcslotdrop658:
  %v2433 = load i64, ptr %slot8, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i32 0, ptr %p2434, align 4, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot13, align 8
  store i64 %v2435, ptr %slot436, align 8
  %v2436 = load i64, ptr %slot9, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %ld2438 = load i32, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2438, ptr %slot437, align 8
  %v2439 = load i32, ptr %slot437, align 8
  %op2440 = and i32 %v2439, 28
  store i32 %op2440, ptr %slot438, align 8
  %v2441 = load i32, ptr %slot438, align 8
  %cv2442 = zext i32 %v2441 to i64
  %cond2443 = icmp ne i64 %cv2442, 0
  br i1 %cond2443, label %bb_rcslotrole658, label %bb_rcslotowner658
bb_rcslotrole658:
  %v2444 = load i64, ptr %slot34, align 8
  store i64 %v2444, ptr %slot439, align 8
  %v2445 = load i64, ptr %slot439, align 8
  %v2446 = load i64, ptr %slot436, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2445, i64 %v2446) nomerge, !dbg !152
  br label %bb_rcslotdone658
bb_rcslotowner658:
  %v2447 = load i64, ptr %slot34, align 8
  store i64 %v2447, ptr %slot440, align 8
  %v2448 = load i64, ptr %slot440, align 8
  %v2449 = load i64, ptr %slot436, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2448, i64 %v2449) nomerge, !dbg !152
  br label %bb_rcslotdone658
bb_rcslotdone658:
  br label %bb_i67
bb_rcarmnext655:
  %v2450 = load i64, ptr %slot391, align 8
  %cmp2451 = icmp eq i64 %v2450, 7
  %cv2452 = zext i1 %cmp2451 to i64
  store i64 %cv2452, ptr %slot441, align 8
  %v2453 = load i64, ptr %slot441, align 8
  %cond2454 = icmp ne i64 %v2453, 0
  br i1 %cond2454, label %bb_rcarm665, label %bb_rcarmnext665
bb_rcarm665:
  %v2455 = load i64, ptr %slot8, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i32, ptr %p2456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2457, ptr %slot442, align 8
  %v2458 = load i32, ptr %slot442, align 8
  %cv2459 = zext i32 %v2458 to i64
  %cond2460 = icmp ne i64 %cv2459, 0
  br i1 %cond2460, label %bb_rcslotdrop668, label %bb_rcslotdone668
bb_rcslotdrop668:
  %v2461 = load i64, ptr %slot8, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  store i32 0, ptr %p2462, align 4, !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot13, align 8
  store i64 %v2463, ptr %slot443, align 8
  %v2464 = load i64, ptr %slot9, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  %ld2466 = load i32, ptr %p2465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2466, ptr %slot444, align 8
  %v2467 = load i32, ptr %slot444, align 8
  %op2468 = and i32 %v2467, 28
  store i32 %op2468, ptr %slot445, align 8
  %v2469 = load i32, ptr %slot445, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rcslotrole668, label %bb_rcslotowner668
bb_rcslotrole668:
  %v2472 = load i64, ptr %slot34, align 8
  store i64 %v2472, ptr %slot446, align 8
  %v2473 = load i64, ptr %slot446, align 8
  %v2474 = load i64, ptr %slot443, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2473, i64 %v2474) nomerge, !dbg !152
  br label %bb_rcslotdone668
bb_rcslotowner668:
  %v2475 = load i64, ptr %slot34, align 8
  store i64 %v2475, ptr %slot447, align 8
  %v2476 = load i64, ptr %slot447, align 8
  %v2477 = load i64, ptr %slot443, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2476, i64 %v2477) nomerge, !dbg !152
  br label %bb_rcslotdone668
bb_rcslotdone668:
  br label %bb_i76
bb_rcarmnext665:
  %v2478 = load i64, ptr %slot391, align 8
  %cmp2479 = icmp eq i64 %v2478, 8
  %cv2480 = zext i1 %cmp2479 to i64
  store i64 %cv2480, ptr %slot448, align 8
  %v2481 = load i64, ptr %slot448, align 8
  %cond2482 = icmp ne i64 %v2481, 0
  br i1 %cond2482, label %bb_rcarm675, label %bb_rcarmnext675
bb_rcarm675:
  %v2483 = load i64, ptr %slot8, align 8
  %p2484 = inttoptr i64 %v2483 to ptr
  %ld2485 = load i32, ptr %p2484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2485, ptr %slot449, align 8
  %v2486 = load i32, ptr %slot449, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcslotdrop678, label %bb_rcslotdone678
bb_rcslotdrop678:
  %v2489 = load i64, ptr %slot8, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  store i32 0, ptr %p2490, align 4, !alias.scope !3, !noalias !4
  %v2491 = load i64, ptr %slot13, align 8
  store i64 %v2491, ptr %slot450, align 8
  %v2492 = load i64, ptr %slot9, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %ld2494 = load i32, ptr %p2493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2494, ptr %slot451, align 8
  %v2495 = load i32, ptr %slot451, align 8
  %op2496 = and i32 %v2495, 28
  store i32 %op2496, ptr %slot452, align 8
  %v2497 = load i32, ptr %slot452, align 8
  %cv2498 = zext i32 %v2497 to i64
  %cond2499 = icmp ne i64 %cv2498, 0
  br i1 %cond2499, label %bb_rcslotrole678, label %bb_rcslotowner678
bb_rcslotrole678:
  %v2500 = load i64, ptr %slot34, align 8
  store i64 %v2500, ptr %slot453, align 8
  %v2501 = load i64, ptr %slot453, align 8
  %v2502 = load i64, ptr %slot450, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2501, i64 %v2502) nomerge, !dbg !152
  br label %bb_rcslotdone678
bb_rcslotowner678:
  %v2503 = load i64, ptr %slot34, align 8
  store i64 %v2503, ptr %slot454, align 8
  %v2504 = load i64, ptr %slot454, align 8
  %v2505 = load i64, ptr %slot450, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2504, i64 %v2505) nomerge, !dbg !152
  br label %bb_rcslotdone678
bb_rcslotdone678:
  br label %bb_i77
bb_rcarmnext675:
  %v2506 = load i64, ptr %slot391, align 8
  %cmp2507 = icmp eq i64 %v2506, 9
  %cv2508 = zext i1 %cmp2507 to i64
  store i64 %cv2508, ptr %slot455, align 8
  %v2509 = load i64, ptr %slot455, align 8
  %cond2510 = icmp ne i64 %v2509, 0
  br i1 %cond2510, label %bb_rcarm685, label %bb_rcarmnext685
bb_rcarm685:
  %v2511 = load i64, ptr %slot8, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %ld2513 = load i32, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2513, ptr %slot456, align 8
  %v2514 = load i32, ptr %slot456, align 8
  %cv2515 = zext i32 %v2514 to i64
  %cond2516 = icmp ne i64 %cv2515, 0
  br i1 %cond2516, label %bb_rcslotdrop688, label %bb_rcslotdone688
bb_rcslotdrop688:
  %v2517 = load i64, ptr %slot8, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 0, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot13, align 8
  store i64 %v2519, ptr %slot457, align 8
  %v2520 = load i64, ptr %slot9, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  %ld2522 = load i32, ptr %p2521, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2522, ptr %slot458, align 8
  %v2523 = load i32, ptr %slot458, align 8
  %op2524 = and i32 %v2523, 28
  store i32 %op2524, ptr %slot459, align 8
  %v2525 = load i32, ptr %slot459, align 8
  %cv2526 = zext i32 %v2525 to i64
  %cond2527 = icmp ne i64 %cv2526, 0
  br i1 %cond2527, label %bb_rcslotrole688, label %bb_rcslotowner688
bb_rcslotrole688:
  %v2528 = load i64, ptr %slot34, align 8
  store i64 %v2528, ptr %slot460, align 8
  %v2529 = load i64, ptr %slot460, align 8
  %v2530 = load i64, ptr %slot457, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2529, i64 %v2530) nomerge, !dbg !152
  br label %bb_rcslotdone688
bb_rcslotowner688:
  %v2531 = load i64, ptr %slot34, align 8
  store i64 %v2531, ptr %slot461, align 8
  %v2532 = load i64, ptr %slot461, align 8
  %v2533 = load i64, ptr %slot457, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2532, i64 %v2533) nomerge, !dbg !152
  br label %bb_rcslotdone688
bb_rcslotdone688:
  br label %bb_i78
bb_rcarmnext685:
  %v2534 = load i64, ptr %slot391, align 8
  %cmp2535 = icmp eq i64 %v2534, 10
  %cv2536 = zext i1 %cmp2535 to i64
  store i64 %cv2536, ptr %slot462, align 8
  %v2537 = load i64, ptr %slot462, align 8
  %cond2538 = icmp ne i64 %v2537, 0
  br i1 %cond2538, label %bb_rcarm695, label %bb_rcarmnext695
bb_rcarm695:
  %v2539 = load i64, ptr %slot8, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %ld2541 = load i32, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2541, ptr %slot463, align 8
  %v2542 = load i32, ptr %slot463, align 8
  %cv2543 = zext i32 %v2542 to i64
  %cond2544 = icmp ne i64 %cv2543, 0
  br i1 %cond2544, label %bb_rcslotdrop698, label %bb_rcslotdone698
bb_rcslotdrop698:
  %v2545 = load i64, ptr %slot8, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  store i32 0, ptr %p2546, align 4, !alias.scope !3, !noalias !4
  %v2547 = load i64, ptr %slot13, align 8
  store i64 %v2547, ptr %slot464, align 8
  %v2548 = load i64, ptr %slot9, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  %ld2550 = load i32, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2550, ptr %slot465, align 8
  %v2551 = load i32, ptr %slot465, align 8
  %op2552 = and i32 %v2551, 28
  store i32 %op2552, ptr %slot466, align 8
  %v2553 = load i32, ptr %slot466, align 8
  %cv2554 = zext i32 %v2553 to i64
  %cond2555 = icmp ne i64 %cv2554, 0
  br i1 %cond2555, label %bb_rcslotrole698, label %bb_rcslotowner698
bb_rcslotrole698:
  %v2556 = load i64, ptr %slot34, align 8
  store i64 %v2556, ptr %slot467, align 8
  %v2557 = load i64, ptr %slot467, align 8
  %v2558 = load i64, ptr %slot464, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2557, i64 %v2558) nomerge, !dbg !152
  br label %bb_rcslotdone698
bb_rcslotowner698:
  %v2559 = load i64, ptr %slot34, align 8
  store i64 %v2559, ptr %slot468, align 8
  %v2560 = load i64, ptr %slot468, align 8
  %v2561 = load i64, ptr %slot464, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2560, i64 %v2561) nomerge, !dbg !152
  br label %bb_rcslotdone698
bb_rcslotdone698:
  br label %bb_i79
bb_rcarmnext695:
  br label %bb_failure
bb_i67:
  %v2562 = load i64, ptr %slot22, align 8
  %p2563 = inttoptr i64 %v2562 to ptr
  %ld2564 = load i64, ptr %p2563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2564, ptr %slot469, align 8
  %v2565 = load i64, ptr %slot469, align 8
  %v2566 = load i64, ptr %slot25, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i64 %v2565, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot28, align 8
  store i64 %v2568, ptr %slot470, align 8
  %v2569 = load i64, ptr %slot470, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i64 0, ptr %p2570, align 8, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot470, align 8
  %p2573 = inttoptr i64 %v2571 to ptr
  %gep2574 = getelementptr i8, ptr %p2573, i64 8
  %op2572 = ptrtoint ptr %gep2574 to i64
  store i64 %op2572, ptr %slot471, align 8
  %v2575 = load i64, ptr %slot471, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  store i64 0, ptr %p2576, align 8, !alias.scope !3, !noalias !4
  %v2577 = load i64, ptr %slot470, align 8
  %p2579 = inttoptr i64 %v2577 to ptr
  %gep2580 = getelementptr i8, ptr %p2579, i64 16
  %op2578 = ptrtoint ptr %gep2580 to i64
  store i64 %op2578, ptr %slot472, align 8
  %v2581 = load i64, ptr %slot472, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i64 0, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot470, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  store i32 0, ptr %p2584, align 4, !alias.scope !3, !noalias !4
  %v2585 = load i64, ptr %slot12, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i32 1, ptr %p2586, align 4, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot25, align 8
  store i64 %v2587, ptr %slot473, align 8
  %v2588 = load i64, ptr %slot470, align 8
  %p2590 = inttoptr i64 %v2588 to ptr
  %gep2591 = getelementptr i8, ptr %p2590, i64 8
  %op2589 = ptrtoint ptr %gep2591 to i64
  store i64 %op2589, ptr %slot474, align 8
  %v2592 = load i64, ptr %slot35, align 8
  store i64 %v2592, ptr %slot475, align 8
  %v2593 = load i64, ptr %slot473, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %ld2595 = load i64, ptr %p2594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2595, ptr %slot476, align 8
  %v2596 = load i64, ptr %slot476, align 8
  %v2597 = load i64, ptr %slot474, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i64 %v2596, ptr %p2598, align 8, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot470, align 8
  %v2600 = load i64, ptr %slot25, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  store i64 %v2599, ptr %p2601, align 8, !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot25, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  %ld2604 = load i64, ptr %p2603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2604, ptr %slot477, align 8
  %v2605 = load i64, ptr %slot13, align 8
  store i64 %v2605, ptr %slot478, align 8
  %v2606 = load i64, ptr %slot477, align 8
  %v2607 = load i64, ptr %slot478, align 8
  %p2608 = inttoptr i64 %v2606 to ptr
  %p2609 = inttoptr i64 %v2607 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2609, ptr %p2608, i64 24, i1 false)
  %v2610 = load i64, ptr %slot9, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 2, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot8, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i32 1, ptr %p2613, align 4, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot478, align 8
  %v2615 = load i64, ptr %slot25, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i64 %v2614, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot25, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2619, ptr %slot479, align 8
  %v2620 = load i64, ptr %slot25, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %ld2622 = load i64, ptr %p2621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2622, ptr %slot480, align 8
  %v2623 = load i64, ptr %slot15, align 8
  store i64 %v2623, ptr %slot481, align 8
  %v2624 = load i64, ptr %slot35, align 8
  store i64 %v2624, ptr %slot482, align 8
  %v2625 = load i64, ptr %slot34, align 8
  %v2626 = load i64, ptr %slot481, align 8
  %v2627 = load i64, ptr %slot480, align 8
  %v2628 = load i64, ptr %slot482, align 8
  %cv2629 = trunc i64 %v2628 to i32
  %call2630 = call i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_take(i64 %v2625, i64 %v2626, i64 %v2627, i32 %cv2629) nomerge, !dbg !154
  store i32 %call2630, ptr %slot483, align 8
  %v2631 = load i32, ptr %slot483, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcsuccess724, label %bb_rcfailure724
bb_rcfailure724:
  %v2634 = load i64, ptr %slot34, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %call2636 = call i32 @myl_rc_take_failure(ptr %p2635) nomerge, !dbg !154
  store i32 %call2636, ptr %slot484, align 8
  %v2637 = load i64, ptr %slot1, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %v2639 = load i32, ptr %slot484, align 8
  %call2640 = call i32 @myl_qbe_rc_status(ptr %p2638, i32 %v2639) nomerge, !dbg !154
  store i32 %call2640, ptr %slot485, align 8
  br label %bb_failure
bb_rcsuccess724:
  %v2641 = load i64, ptr %slot8, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  store i32 0, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot11, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i32 2, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot10, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i32 1, ptr %p2646, align 4, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot15, align 8
  store i64 %v2647, ptr %slot486, align 8
  %v2648 = load i64, ptr %slot10, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i32 0, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot8, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot487, align 8
  %v2653 = load i32, ptr %slot487, align 8
  %cv2654 = zext i32 %v2653 to i64
  %cond2655 = icmp ne i64 %cv2654, 0
  br i1 %cond2655, label %bb_rcslotdrop734, label %bb_rcslotdone734
bb_rcslotdrop734:
  %v2656 = load i64, ptr %slot8, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  store i32 0, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  %v2658 = load i64, ptr %slot13, align 8
  store i64 %v2658, ptr %slot488, align 8
  %v2659 = load i64, ptr %slot9, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %ld2661 = load i32, ptr %p2660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2661, ptr %slot489, align 8
  %v2662 = load i32, ptr %slot489, align 8
  %op2663 = and i32 %v2662, 28
  store i32 %op2663, ptr %slot490, align 8
  %v2664 = load i32, ptr %slot490, align 8
  %cv2665 = zext i32 %v2664 to i64
  %cond2666 = icmp ne i64 %cv2665, 0
  br i1 %cond2666, label %bb_rcslotrole734, label %bb_rcslotowner734
bb_rcslotrole734:
  %v2667 = load i64, ptr %slot34, align 8
  store i64 %v2667, ptr %slot491, align 8
  %v2668 = load i64, ptr %slot491, align 8
  %v2669 = load i64, ptr %slot488, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v2668, i64 %v2669) nomerge, !dbg !154
  br label %bb_rcslotdone734
bb_rcslotowner734:
  %v2670 = load i64, ptr %slot34, align 8
  store i64 %v2670, ptr %slot492, align 8
  %v2671 = load i64, ptr %slot492, align 8
  %v2672 = load i64, ptr %slot488, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v2671, i64 %v2672) nomerge, !dbg !154
  br label %bb_rcslotdone734
bb_rcslotdone734:
  %v2673 = load i64, ptr %slot6, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  %ld2675 = load i32, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2675, ptr %slot493, align 8
  %v2676 = load i32, ptr %slot493, align 8
  %cv2677 = zext i32 %v2676 to i64
  %cond2678 = icmp ne i64 %cv2677, 0
  br i1 %cond2678, label %bb_rcslotdrop780, label %bb_rcslotdone780
bb_rcslotdrop780:
  %v2679 = load i64, ptr %slot6, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  store i32 0, ptr %p2680, align 4, !alias.scope !3, !noalias !4
  %v2681 = load i64, ptr %slot21, align 8
  store i64 %v2681, ptr %slot494, align 8
  %v2682 = load i64, ptr %slot7, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  %ld2684 = load i32, ptr %p2683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2684, ptr %slot495, align 8
  %v2685 = load i32, ptr %slot495, align 8
  %op2686 = and i32 %v2685, 28
  store i32 %op2686, ptr %slot496, align 8
  %v2687 = load i32, ptr %slot496, align 8
  %cv2688 = zext i32 %v2687 to i64
  %cond2689 = icmp ne i64 %cv2688, 0
  br i1 %cond2689, label %bb_rcslotrole780, label %bb_rcslotowner780
bb_rcslotrole780:
  %v2690 = load i64, ptr %slot34, align 8
  store i64 %v2690, ptr %slot497, align 8
  %v2691 = load i64, ptr %slot497, align 8
  %v2692 = load i64, ptr %slot494, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v2691, i64 %v2692) nomerge, !dbg !154
  br label %bb_rcslotdone780
bb_rcslotowner780:
  %v2693 = load i64, ptr %slot34, align 8
  store i64 %v2693, ptr %slot498, align 8
  %v2694 = load i64, ptr %slot498, align 8
  %v2695 = load i64, ptr %slot494, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v2694, i64 %v2695) nomerge, !dbg !154
  br label %bb_rcslotdone780
bb_rcslotdone780:
  %v2696 = load i64, ptr %slot486, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2697, i64 24, i1 false)
  ret void
bb_i70:
  br label %bb_i80
bb_i71:
  br label %bb_i80
bb_i72:
  br label %bb_i80
bb_i73:
  br label %bb_i80
bb_i74:
  br label %bb_i80
bb_i75:
  br label %bb_i80
bb_i76:
  br label %bb_i80
bb_i77:
  br label %bb_i80
bb_i78:
  br label %bb_i80
bb_i79:
  br label %bb_i80
bb_i80:
  br label %bb_i84
bb_i81:
  br label %bb_i84
bb_i82:
  br label %bb_i84
bb_i83:
  br label %bb_i84
bb_i84:
  %p2698 = inttoptr i64 ptrtoint (ptr @myl_lit_2988f248bcf7fecf94868b447d50e1ca761d4666b8875670525fa0e5a4347a5f to i64) to ptr
  %ld2699 = load i64, ptr %p2698, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2699, ptr %slot499, align 8
  %v2700 = load i64, ptr %slot499, align 8
  %v2701 = load i64, ptr %slot25, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i64 %v2700, ptr %p2702, align 8, !alias.scope !3, !noalias !4
  %v2703 = load i64, ptr %slot25, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  %ld2705 = load i64, ptr %p2704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2705, ptr %slot500, align 8
  %v2706 = load i64, ptr %slot500, align 8
  %v2707 = load i64, ptr %slot14, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  store i64 %v2706, ptr %p2708, align 8, !alias.scope !3, !noalias !4
  %v2709 = load i64, ptr %slot14, align 8
  store i64 %v2709, ptr %slot501, align 8
  %v2710 = load i64, ptr %slot15, align 8
  store i64 %v2710, ptr %slot502, align 8
  %v2711 = load i64, ptr %slot501, align 8
  %v2712 = load i64, ptr %slot502, align 8
  %p2713 = inttoptr i64 %v2711 to ptr
  %p2714 = inttoptr i64 %v2712 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2714, ptr %p2713, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2715 = load i64, ptr %slot11, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  store i32 2, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot10, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  store i32 1, ptr %p2718, align 4, !alias.scope !3, !noalias !4
  %v2719 = load i64, ptr %slot13, align 8
  store i64 %v2719, ptr %slot503, align 8
  %v2720 = load i64, ptr %slot15, align 8
  store i64 %v2720, ptr %slot504, align 8
  %v2721 = load i64, ptr %slot504, align 8
  %v2722 = load i64, ptr %slot503, align 8
  %p2723 = inttoptr i64 %v2721 to ptr
  %p2724 = inttoptr i64 %v2722 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2724, ptr %p2723, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2725 = load i64, ptr %slot9, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i32 2, ptr %p2726, align 4, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot11, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i32, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2729, ptr %slot505, align 8
  %v2730 = load i32, ptr %slot505, align 8
  %v2731 = load i64, ptr %slot9, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  store i32 %v2730, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  %v2733 = load i64, ptr %slot10, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i32 0, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot8, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i32 1, ptr %p2736, align 4, !alias.scope !3, !noalias !4
  %v2737 = load i64, ptr %slot503, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %ld2739 = load i64, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2739, ptr %slot506, align 8
  %v2740 = load i64, ptr %slot506, align 8
  %v2741 = load i64, ptr %slot25, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i64 %v2740, ptr %p2742, align 8, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot18, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %ld2745 = load i64, ptr %p2744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2745, ptr %slot507, align 8
  %v2746 = load i64, ptr %slot507, align 8
  %v2747 = load i64, ptr %slot26, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i64 %v2746, ptr %p2748, align 8, !alias.scope !3, !noalias !4
  %v2749 = load i64, ptr %slot25, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %ld2751 = load i64, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2751, ptr %slot508, align 8
  %v2752 = load i64, ptr %slot26, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %ld2754 = load i64, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2754, ptr %slot509, align 8
  %v2755 = load i64, ptr %slot1, align 8
  %v2756 = load i64, ptr %slot508, align 8
  %v2757 = load i64, ptr %slot509, align 8
  %call2758 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v2755, i64 %v2756, i64 %v2757) nomerge, !dbg !156
  store { i64, i64 } %call2758, ptr %callresult511, align 8
  %addr2759 = ptrtoint ptr %callresult511 to i64
  store i64 %addr2759, ptr %slot510, align 8
  %v2760 = load i64, ptr %slot510, align 8
  %v2761 = load i64, ptr %slot25, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  store i64 %v2760, ptr %p2762, align 8, !alias.scope !3, !noalias !4
  %v2763 = load i64, ptr %slot25, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot512, align 8
  %v2766 = load i64, ptr %slot15, align 8
  store i64 %v2766, ptr %slot513, align 8
  %v2767 = load i64, ptr %slot34, align 8
  %v2768 = load i64, ptr %slot513, align 8
  %v2769 = load i64, ptr %slot512, align 8
  %call2770 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v2767, i64 %v2768, i64 %v2769) nomerge, !dbg !156
  store i32 %call2770, ptr %slot514, align 8
  %v2771 = load i32, ptr %slot514, align 8
  %cv2772 = zext i32 %v2771 to i64
  %cond2773 = icmp ne i64 %cv2772, 0
  br i1 %cond2773, label %bb_rcsuccess856, label %bb_rcfailure856
bb_rcfailure856:
  %v2774 = load i64, ptr %slot34, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %call2776 = call i32 @myl_rc_take_failure(ptr %p2775) nomerge, !dbg !156
  store i32 %call2776, ptr %slot515, align 8
  %v2777 = load i64, ptr %slot1, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %v2779 = load i32, ptr %slot515, align 8
  %call2780 = call i32 @myl_qbe_rc_status(ptr %p2778, i32 %v2779) nomerge, !dbg !156
  store i32 %call2780, ptr %slot516, align 8
  br label %bb_failure
bb_rcsuccess856:
  %v2781 = load i64, ptr %slot11, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i32 2, ptr %p2782, align 4, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot11, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 16, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot10, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  store i32 1, ptr %p2786, align 4, !alias.scope !3, !noalias !4
  %v2787 = load i64, ptr %slot8, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  %ld2789 = load i32, ptr %p2788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2789, ptr %slot517, align 8
  %v2790 = load i32, ptr %slot517, align 8
  %cv2791 = zext i32 %v2790 to i64
  %cond2792 = icmp ne i64 %cv2791, 0
  br i1 %cond2792, label %bb_rcslotdrop864, label %bb_rcslotdone864
bb_rcslotdrop864:
  %v2793 = load i64, ptr %slot8, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i32 0, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  %v2795 = load i64, ptr %slot13, align 8
  store i64 %v2795, ptr %slot518, align 8
  %v2796 = load i64, ptr %slot9, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %ld2798 = load i32, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2798, ptr %slot519, align 8
  %v2799 = load i32, ptr %slot519, align 8
  %op2800 = and i32 %v2799, 28
  store i32 %op2800, ptr %slot520, align 8
  %v2801 = load i32, ptr %slot520, align 8
  %cv2802 = zext i32 %v2801 to i64
  %cond2803 = icmp ne i64 %cv2802, 0
  br i1 %cond2803, label %bb_rcslotrole864, label %bb_rcslotowner864
bb_rcslotrole864:
  %v2804 = load i64, ptr %slot34, align 8
  store i64 %v2804, ptr %slot521, align 8
  %v2805 = load i64, ptr %slot518, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %ld2807 = load i64, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2807, ptr %slot522, align 8
  %v2808 = load i64, ptr %slot522, align 8
  %cmp2809 = icmp ne i64 %v2808, 0
  %cv2810 = zext i1 %cmp2809 to i32
  store i32 %cv2810, ptr %slot523, align 8
  %v2811 = load i32, ptr %slot523, align 8
  %cv2812 = zext i32 %v2811 to i64
  %cond2813 = icmp ne i64 %cv2812, 0
  br i1 %cond2813, label %bb_rcgnn880, label %bb_rcgdone880
bb_rcgnn880:
  %v2814 = load i64, ptr %slot522, align 8
  %op2815 = sub i64 %v2814, 16
  store i64 %op2815, ptr %slot524, align 8
  %v2816 = load i64, ptr %slot522, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  %rgep2818 = getelementptr i8, ptr %p2817, i64 -16
  %ld2819 = load i64, ptr %rgep2818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2819, ptr %slot525, align 8
  %v2820 = load i64, ptr %slot525, align 8
  %op2821 = and i64 %v2820, 4611686018427387906
  store i64 %op2821, ptr %slot526, align 8
  %v2822 = load i64, ptr %slot526, align 8
  %cmp2823 = icmp ne i64 %v2822, 0
  %cv2824 = zext i1 %cmp2823 to i32
  store i32 %cv2824, ptr %slot527, align 8
  %v2825 = load i32, ptr %slot527, align 8
  %cv2826 = zext i32 %v2825 to i64
  %cond2827 = icmp ne i64 %cv2826, 0
  br i1 %cond2827, label %bb_rcgclear880, label %bb_rcgcounted880
bb_rcgcounted880:
  %v2828 = load i64, ptr %slot522, align 8
  %op2829 = sub i64 %v2828, 24
  store i64 %op2829, ptr %slot528, align 8
  %v2830 = load i64, ptr %slot522, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %rgep2832 = getelementptr i8, ptr %p2831, i64 -24
  %ld2833 = load i64, ptr %rgep2832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2833, ptr %slot529, align 8
  %v2834 = load i64, ptr %slot529, align 8
  %op2835 = sub i64 %v2834, 1
  store i64 %op2835, ptr %slot530, align 8
  %v2836 = load i64, ptr %slot530, align 8
  %cmp2837 = icmp eq i64 %v2836, 0
  %cv2838 = zext i1 %cmp2837 to i32
  store i32 %cv2838, ptr %slot531, align 8
  %v2839 = load i32, ptr %slot531, align 8
  %cv2840 = zext i32 %v2839 to i64
  %cond2841 = icmp ne i64 %cv2840, 0
  br i1 %cond2841, label %bb_rcglast880, label %bb_rcgdec880
bb_rcglast880:
  %v2842 = load i64, ptr %slot522, align 8
  %op2843 = sub i64 %v2842, 32
  store i64 %op2843, ptr %slot532, align 8
  %v2844 = load i64, ptr %slot522, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %rgep2846 = getelementptr i8, ptr %p2845, i64 -32
  %ld2847 = load i64, ptr %rgep2846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2847, ptr %slot533, align 8
  %v2848 = load i64, ptr %slot533, align 8
  %cmp2849 = icmp ne i64 %v2848, 0
  %cv2850 = zext i1 %cmp2849 to i32
  store i32 %cv2850, ptr %slot534, align 8
  %v2851 = load i32, ptr %slot534, align 8
  %cv2852 = zext i32 %v2851 to i64
  %cond2853 = icmp ne i64 %cv2852, 0
  br i1 %cond2853, label %bb_rcgdec880, label %bb_rcgslow880
bb_rcgslow880:
  %v2854 = load i64, ptr %slot521, align 8
  %v2855 = load i64, ptr %slot518, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2854, i64 %v2855) nomerge, !dbg !156
  br label %bb_rcgdone880
bb_rcgdec880:
  %v2856 = load i64, ptr %slot530, align 8
  %v2857 = load i64, ptr %slot522, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %rgep2859 = getelementptr i8, ptr %p2858, i64 -24
  store i64 %v2856, ptr %rgep2859, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear880
bb_rcgclear880:
  %v2860 = load i64, ptr %slot518, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  store i64 0, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone880
bb_rcgdone880:
  br label %bb_rcslotdone864
bb_rcslotowner864:
  %v2862 = load i64, ptr %slot34, align 8
  store i64 %v2862, ptr %slot535, align 8
  %v2863 = load i64, ptr %slot518, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  %ld2865 = load i64, ptr %p2864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2865, ptr %slot536, align 8
  %v2866 = load i64, ptr %slot536, align 8
  %cmp2867 = icmp ne i64 %v2866, 0
  %cv2868 = zext i1 %cmp2867 to i32
  store i32 %cv2868, ptr %slot537, align 8
  %v2869 = load i32, ptr %slot537, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcgnn895, label %bb_rcgdone895
bb_rcgnn895:
  %v2872 = load i64, ptr %slot536, align 8
  %op2873 = sub i64 %v2872, 16
  store i64 %op2873, ptr %slot538, align 8
  %v2874 = load i64, ptr %slot536, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %rgep2876 = getelementptr i8, ptr %p2875, i64 -16
  %ld2877 = load i64, ptr %rgep2876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2877, ptr %slot539, align 8
  %v2878 = load i64, ptr %slot539, align 8
  %op2879 = and i64 %v2878, 4611686018427387906
  store i64 %op2879, ptr %slot540, align 8
  %v2880 = load i64, ptr %slot540, align 8
  %cmp2881 = icmp ne i64 %v2880, 0
  %cv2882 = zext i1 %cmp2881 to i32
  store i32 %cv2882, ptr %slot541, align 8
  %v2883 = load i32, ptr %slot541, align 8
  %cv2884 = zext i32 %v2883 to i64
  %cond2885 = icmp ne i64 %cv2884, 0
  br i1 %cond2885, label %bb_rcgclear895, label %bb_rcgcounted895
bb_rcgcounted895:
  %v2886 = load i64, ptr %slot536, align 8
  %op2887 = sub i64 %v2886, 32
  store i64 %op2887, ptr %slot542, align 8
  %v2888 = load i64, ptr %slot536, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  %rgep2890 = getelementptr i8, ptr %p2889, i64 -32
  %ld2891 = load i64, ptr %rgep2890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2891, ptr %slot543, align 8
  %v2892 = load i64, ptr %slot543, align 8
  %op2893 = sub i64 %v2892, 1
  store i64 %op2893, ptr %slot544, align 8
  %v2894 = load i64, ptr %slot544, align 8
  %cmp2895 = icmp eq i64 %v2894, 0
  %cv2896 = zext i1 %cmp2895 to i32
  store i32 %cv2896, ptr %slot545, align 8
  %v2897 = load i32, ptr %slot545, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcglast895, label %bb_rcgdec895
bb_rcglast895:
  %v2900 = load i64, ptr %slot536, align 8
  %op2901 = sub i64 %v2900, 24
  store i64 %op2901, ptr %slot546, align 8
  %v2902 = load i64, ptr %slot536, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -24
  %ld2905 = load i64, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2905, ptr %slot547, align 8
  %v2906 = load i64, ptr %slot547, align 8
  %cmp2907 = icmp ne i64 %v2906, 0
  %cv2908 = zext i1 %cmp2907 to i32
  store i32 %cv2908, ptr %slot548, align 8
  %v2909 = load i32, ptr %slot548, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcgdec895, label %bb_rcgslow895
bb_rcgslow895:
  %v2912 = load i64, ptr %slot535, align 8
  %v2913 = load i64, ptr %slot518, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2912, i64 %v2913) nomerge, !dbg !156
  br label %bb_rcgdone895
bb_rcgdec895:
  %v2914 = load i64, ptr %slot544, align 8
  %v2915 = load i64, ptr %slot536, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %rgep2917 = getelementptr i8, ptr %p2916, i64 -32
  store i64 %v2914, ptr %rgep2917, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear895
bb_rcgclear895:
  %v2918 = load i64, ptr %slot518, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  store i64 0, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone895
bb_rcgdone895:
  br label %bb_rcslotdone864
bb_rcslotdone864:
  %v2920 = load i64, ptr %slot13, align 8
  store i64 %v2920, ptr %slot549, align 8
  %v2921 = load i64, ptr %slot15, align 8
  store i64 %v2921, ptr %slot550, align 8
  %v2922 = load i64, ptr %slot550, align 8
  %v2923 = load i64, ptr %slot549, align 8
  %p2924 = inttoptr i64 %v2922 to ptr
  %p2925 = inttoptr i64 %v2923 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2925, ptr %p2924, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2926 = load i64, ptr %slot9, align 8
  %p2927 = inttoptr i64 %v2926 to ptr
  store i32 2, ptr %p2927, align 4, !alias.scope !3, !noalias !4
  %v2928 = load i64, ptr %slot11, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %ld2930 = load i32, ptr %p2929, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2930, ptr %slot551, align 8
  %v2931 = load i32, ptr %slot551, align 8
  %v2932 = load i64, ptr %slot9, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  store i32 %v2931, ptr %p2933, align 4, !alias.scope !3, !noalias !4
  %v2934 = load i64, ptr %slot10, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  store i32 0, ptr %p2935, align 4, !alias.scope !3, !noalias !4
  %v2936 = load i64, ptr %slot8, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i32 1, ptr %p2937, align 4, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot549, align 8
  %v2939 = load i64, ptr %slot25, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i64 %v2938, ptr %p2940, align 8, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot29, align 8
  store i64 %v2941, ptr %slot552, align 8
  %v2942 = load i64, ptr %slot552, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  store i64 0, ptr %p2943, align 8, !alias.scope !3, !noalias !4
  %v2944 = load i64, ptr %slot552, align 8
  %p2946 = inttoptr i64 %v2944 to ptr
  %gep2947 = getelementptr i8, ptr %p2946, i64 8
  %op2945 = ptrtoint ptr %gep2947 to i64
  store i64 %op2945, ptr %slot553, align 8
  %v2948 = load i64, ptr %slot553, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  store i64 0, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  %v2950 = load i64, ptr %slot552, align 8
  %p2952 = inttoptr i64 %v2950 to ptr
  %gep2953 = getelementptr i8, ptr %p2952, i64 16
  %op2951 = ptrtoint ptr %gep2953 to i64
  store i64 %op2951, ptr %slot554, align 8
  %v2954 = load i64, ptr %slot554, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  store i64 0, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  %v2956 = load i64, ptr %slot552, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  store i32 1, ptr %p2957, align 4, !alias.scope !3, !noalias !4
  %v2958 = load i64, ptr %slot12, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  store i32 1, ptr %p2959, align 4, !alias.scope !3, !noalias !4
  %v2960 = load i64, ptr %slot25, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  %ld2962 = load i64, ptr %p2961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2962, ptr %slot555, align 8
  %v2963 = load i64, ptr %slot552, align 8
  %p2965 = inttoptr i64 %v2963 to ptr
  %gep2966 = getelementptr i8, ptr %p2965, i64 8
  %op2964 = ptrtoint ptr %gep2966 to i64
  store i64 %op2964, ptr %slot556, align 8
  %v2967 = load i64, ptr %slot35, align 8
  store i64 %v2967, ptr %slot557, align 8
  %v2968 = load i64, ptr %slot25, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %ld2970 = load i64, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2970, ptr %slot558, align 8
  %v2971 = load i64, ptr %slot8, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i32, ptr %p2972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2973, ptr %slot559, align 8
  %v2974 = load i64, ptr %slot9, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  %ld2976 = load i32, ptr %p2975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2976, ptr %slot560, align 8
  %v2977 = load i32, ptr %slot560, align 8
  %op2978 = and i32 %v2977, 24
  store i32 %op2978, ptr %slot560, align 8
  %v2979 = load i32, ptr %slot560, align 8
  %cmp2980 = icmp eq i32 %v2979, 0
  %cv2981 = zext i1 %cmp2980 to i32
  store i32 %cv2981, ptr %slot561, align 8
  %v2982 = load i32, ptr %slot559, align 8
  %v2983 = load i32, ptr %slot561, align 8
  %op2984 = and i32 %v2982, %v2983
  store i32 %op2984, ptr %slot562, align 8
  %v2985 = load i32, ptr %slot562, align 8
  %cv2986 = zext i32 %v2985 to i64
  %cond2987 = icmp ne i64 %cv2986, 0
  br i1 %cond2987, label %bb_rctake916, label %bb_rccopy916
bb_rctake916:
  %v2988 = load i64, ptr %slot15, align 8
  store i64 %v2988, ptr %slot563, align 8
  %v2989 = load i64, ptr %slot35, align 8
  store i64 %v2989, ptr %slot564, align 8
  %v2990 = load i64, ptr %slot558, align 8
  %v2991 = load i64, ptr %slot563, align 8
  %op2992 = sub i64 %v2990, %v2991
  store i64 %op2992, ptr %slot565, align 8
  %v2993 = load i64, ptr %slot563, align 8
  %v2994 = load i64, ptr %slot558, align 8
  %op2995 = sub i64 %v2993, %v2994
  store i64 %op2995, ptr %slot566, align 8
  %v2996 = load i64, ptr %slot565, align 8
  %cmp2997 = icmp ult i64 %v2996, 16
  %cv2998 = zext i1 %cmp2997 to i32
  store i32 %cv2998, ptr %slot567, align 8
  %v2999 = load i64, ptr %slot566, align 8
  %cmp3000 = icmp ult i64 %v2999, 16
  %cv3001 = zext i1 %cmp3000 to i32
  store i32 %cv3001, ptr %slot568, align 8
  %v3002 = load i32, ptr %slot567, align 8
  %v3003 = load i32, ptr %slot568, align 8
  %op3004 = or i32 %v3002, %v3003
  store i32 %op3004, ptr %slot569, align 8
  %v3005 = load i32, ptr %slot569, align 8
  %cv3006 = zext i32 %v3005 to i64
  %cond3007 = icmp ne i64 %cv3006, 0
  br i1 %cond3007, label %bb_rcmoveslow925, label %bb_rcmovecheck925
bb_rcmovecheck925:
  %v3008 = load i64, ptr %slot558, align 8
  %op3009 = add i64 %v3008, 0
  store i64 %op3009, ptr %slot570, align 8
  %v3010 = load i64, ptr %slot570, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %ld3012 = load i64, ptr %p3011, align 8
  store i64 %ld3012, ptr %slot571, align 8
  %v3013 = load i64, ptr %slot571, align 8
  %cmp3014 = icmp ne i64 %v3013, 0
  %cv3015 = zext i1 %cmp3014 to i32
  store i32 %cv3015, ptr %slot572, align 8
  %v3016 = load i32, ptr %slot572, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcmoveheader933, label %bb_rcmovenext933
bb_rcmoveheader933:
  %v3019 = load i64, ptr %slot571, align 8
  %op3020 = sub i64 %v3019, 16
  store i64 %op3020, ptr %slot573, align 8
  %v3021 = load i64, ptr %slot571, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %rgep3023 = getelementptr i8, ptr %p3022, i64 -16
  %ld3024 = load i64, ptr %rgep3023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3024, ptr %slot574, align 8
  %v3025 = load i64, ptr %slot574, align 8
  %op3026 = and i64 %v3025, 5764607523034234881
  store i64 %op3026, ptr %slot575, align 8
  %v3027 = load i64, ptr %slot575, align 8
  %cmp3028 = icmp ne i64 %v3027, 0
  %cv3029 = zext i1 %cmp3028 to i32
  store i32 %cv3029, ptr %slot576, align 8
  %v3030 = load i32, ptr %slot576, align 8
  %cv3031 = zext i32 %v3030 to i64
  %cond3032 = icmp ne i64 %cv3031, 0
  br i1 %cond3032, label %bb_rcmoveslow925, label %bb_rcmovenext933
bb_rcmovenext933:
  %v3033 = load i64, ptr %slot558, align 8
  %v3034 = load i64, ptr %slot563, align 8
  %p3035 = inttoptr i64 %v3033 to ptr
  %p3036 = inttoptr i64 %v3034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3036, ptr %p3035, i64 16, i1 false)
  %v3037 = load i64, ptr %slot558, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  store i64 0, ptr %p3038, align 8
  %v3039 = load i64, ptr %slot558, align 8
  %op3040 = add i64 %v3039, 8
  store i64 %op3040, ptr %slot577, align 8
  %v3041 = load i64, ptr %slot577, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  store i64 0, ptr %p3042, align 8
  br label %bb_rcmoved925
bb_rcmoveslow925:
  %v3043 = load i64, ptr %slot34, align 8
  %v3044 = load i64, ptr %slot563, align 8
  %v3045 = load i64, ptr %slot558, align 8
  %v3046 = load i64, ptr %slot564, align 8
  %cv3047 = trunc i64 %v3046 to i32
  %call3048 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v3043, i64 %v3044, i64 %v3045, i32 %cv3047) nomerge, !dbg !158
  store i32 %call3048, ptr %slot578, align 8
  %v3049 = load i32, ptr %slot578, align 8
  %cv3050 = zext i32 %v3049 to i64
  %cond3051 = icmp ne i64 %cv3050, 0
  br i1 %cond3051, label %bb_rcsuccess941, label %bb_rcfailure941
bb_rcfailure941:
  %v3052 = load i64, ptr %slot34, align 8
  %p3053 = inttoptr i64 %v3052 to ptr
  %call3054 = call i32 @myl_rc_take_failure(ptr %p3053) nomerge, !dbg !158
  store i32 %call3054, ptr %slot579, align 8
  %v3055 = load i64, ptr %slot1, align 8
  %p3056 = inttoptr i64 %v3055 to ptr
  %v3057 = load i32, ptr %slot579, align 8
  %call3058 = call i32 @myl_qbe_rc_status(ptr %p3056, i32 %v3057) nomerge, !dbg !158
  store i32 %call3058, ptr %slot580, align 8
  br label %bb_failure
bb_rcsuccess941:
  br label %bb_rcmoved925
bb_rcmoved925:
  %v3059 = load i64, ptr %slot8, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  store i32 0, ptr %p3060, align 4, !alias.scope !3, !noalias !4
  %v3061 = load i64, ptr %slot11, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  store i32 2, ptr %p3062, align 4, !alias.scope !3, !noalias !4
  %v3063 = load i64, ptr %slot10, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  store i32 1, ptr %p3064, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared916
bb_rccopy916:
  %v3065 = load i64, ptr %slot15, align 8
  store i64 %v3065, ptr %slot581, align 8
  %v3066 = load i64, ptr %slot35, align 8
  store i64 %v3066, ptr %slot582, align 8
  %v3067 = load i64, ptr %slot34, align 8
  %v3068 = load i64, ptr %slot581, align 8
  %v3069 = load i64, ptr %slot558, align 8
  %v3070 = load i64, ptr %slot582, align 8
  %cv3071 = trunc i64 %v3070 to i32
  %call3072 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v3067, i64 %v3068, i64 %v3069, i32 %cv3071) nomerge, !dbg !158
  store i32 %call3072, ptr %slot583, align 8
  %v3073 = load i32, ptr %slot583, align 8
  %cv3074 = zext i32 %v3073 to i64
  %cond3075 = icmp ne i64 %cv3074, 0
  br i1 %cond3075, label %bb_rcsuccess950, label %bb_rcfailure950
bb_rcfailure950:
  %v3076 = load i64, ptr %slot34, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %call3078 = call i32 @myl_rc_take_failure(ptr %p3077) nomerge, !dbg !158
  store i32 %call3078, ptr %slot584, align 8
  %v3079 = load i64, ptr %slot1, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  %v3081 = load i32, ptr %slot584, align 8
  %call3082 = call i32 @myl_qbe_rc_status(ptr %p3080, i32 %v3081) nomerge, !dbg !158
  store i32 %call3082, ptr %slot585, align 8
  br label %bb_failure
bb_rcsuccess950:
  %v3083 = load i64, ptr %slot11, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  store i32 2, ptr %p3084, align 4, !alias.scope !3, !noalias !4
  %v3085 = load i64, ptr %slot10, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  store i32 1, ptr %p3086, align 4, !alias.scope !3, !noalias !4
  %v3087 = load i64, ptr %slot8, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i32, ptr %p3088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3089, ptr %slot586, align 8
  %v3090 = load i32, ptr %slot586, align 8
  %cv3091 = zext i32 %v3090 to i64
  %cond3092 = icmp ne i64 %cv3091, 0
  br i1 %cond3092, label %bb_rcslotdrop957, label %bb_rcslotdone957
bb_rcslotdrop957:
  %v3093 = load i64, ptr %slot8, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  store i32 0, ptr %p3094, align 4, !alias.scope !3, !noalias !4
  %v3095 = load i64, ptr %slot13, align 8
  store i64 %v3095, ptr %slot587, align 8
  %v3096 = load i64, ptr %slot9, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i32, ptr %p3097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3098, ptr %slot588, align 8
  %v3099 = load i32, ptr %slot588, align 8
  %op3100 = and i32 %v3099, 28
  store i32 %op3100, ptr %slot589, align 8
  %v3101 = load i32, ptr %slot589, align 8
  %cv3102 = zext i32 %v3101 to i64
  %cond3103 = icmp ne i64 %cv3102, 0
  br i1 %cond3103, label %bb_rcslotrole957, label %bb_rcslotowner957
bb_rcslotrole957:
  %v3104 = load i64, ptr %slot34, align 8
  store i64 %v3104, ptr %slot590, align 8
  %v3105 = load i64, ptr %slot590, align 8
  %v3106 = load i64, ptr %slot587, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v3105, i64 %v3106) nomerge, !dbg !158
  br label %bb_rcslotdone957
bb_rcslotowner957:
  %v3107 = load i64, ptr %slot34, align 8
  store i64 %v3107, ptr %slot591, align 8
  %v3108 = load i64, ptr %slot591, align 8
  %v3109 = load i64, ptr %slot587, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v3108, i64 %v3109) nomerge, !dbg !158
  br label %bb_rcslotdone957
bb_rcslotdone957:
  br label %bb_rcprepared916
bb_rcprepared916:
  %v3110 = load i64, ptr %slot15, align 8
  store i64 %v3110, ptr %slot592, align 8
  %v3111 = load i64, ptr %slot592, align 8
  %v3112 = load i64, ptr %slot556, align 8
  %p3113 = inttoptr i64 %v3111 to ptr
  %p3114 = inttoptr i64 %v3112 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3114, ptr %p3113, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3115 = load i64, ptr %slot10, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  store i32 0, ptr %p3116, align 4, !alias.scope !3, !noalias !4
  %v3117 = load i64, ptr %slot552, align 8
  %v3118 = load i64, ptr %slot25, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  store i64 %v3117, ptr %p3119, align 8, !alias.scope !3, !noalias !4
  %p3120 = inttoptr i64 ptrtoint (ptr @myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p3120, i64 87) "call-inline-cost"="0", !dbg !158
  %v3121 = load i64, ptr %slot25, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %ld3123 = load i64, ptr %p3122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3123, ptr %slot593, align 8
  %v3124 = load i64, ptr %slot13, align 8
  store i64 %v3124, ptr %slot594, align 8
  %v3125 = load i64, ptr %slot593, align 8
  %v3126 = load i64, ptr %slot594, align 8
  %p3127 = inttoptr i64 %v3125 to ptr
  %p3128 = inttoptr i64 %v3126 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3128, ptr %p3127, i64 24, i1 false)
  %v3129 = load i64, ptr %slot9, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  store i32 2, ptr %p3130, align 4, !alias.scope !3, !noalias !4
  %v3131 = load i64, ptr %slot8, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i32 1, ptr %p3132, align 4, !alias.scope !3, !noalias !4
  %v3133 = load i64, ptr %slot594, align 8
  %v3134 = load i64, ptr %slot25, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i64 %v3133, ptr %p3135, align 8, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot25, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %ld3138 = load i64, ptr %p3137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3138, ptr %slot595, align 8
  %v3139 = load i64, ptr %slot25, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  %ld3141 = load i64, ptr %p3140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3141, ptr %slot596, align 8
  %v3142 = load i64, ptr %slot15, align 8
  store i64 %v3142, ptr %slot597, align 8
  %v3143 = load i64, ptr %slot35, align 8
  store i64 %v3143, ptr %slot598, align 8
  %v3144 = load i64, ptr %slot34, align 8
  %v3145 = load i64, ptr %slot597, align 8
  %v3146 = load i64, ptr %slot596, align 8
  %v3147 = load i64, ptr %slot598, align 8
  %cv3148 = trunc i64 %v3147 to i32
  %call3149 = call i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_take(i64 %v3144, i64 %v3145, i64 %v3146, i32 %cv3148) nomerge, !dbg !160
  store i32 %call3149, ptr %slot599, align 8
  %v3150 = load i32, ptr %slot599, align 8
  %cv3151 = zext i32 %v3150 to i64
  %cond3152 = icmp ne i64 %cv3151, 0
  br i1 %cond3152, label %bb_rcsuccess975, label %bb_rcfailure975
bb_rcfailure975:
  %v3153 = load i64, ptr %slot34, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %call3155 = call i32 @myl_rc_take_failure(ptr %p3154) nomerge, !dbg !160
  store i32 %call3155, ptr %slot600, align 8
  %v3156 = load i64, ptr %slot1, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  %v3158 = load i32, ptr %slot600, align 8
  %call3159 = call i32 @myl_qbe_rc_status(ptr %p3157, i32 %v3158) nomerge, !dbg !160
  store i32 %call3159, ptr %slot601, align 8
  br label %bb_failure
bb_rcsuccess975:
  %v3160 = load i64, ptr %slot8, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  store i32 0, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  %v3162 = load i64, ptr %slot11, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  store i32 2, ptr %p3163, align 4, !alias.scope !3, !noalias !4
  %v3164 = load i64, ptr %slot10, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  store i32 1, ptr %p3165, align 4, !alias.scope !3, !noalias !4
  %v3166 = load i64, ptr %slot15, align 8
  store i64 %v3166, ptr %slot602, align 8
  %v3167 = load i64, ptr %slot10, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  store i32 0, ptr %p3168, align 4, !alias.scope !3, !noalias !4
  %v3169 = load i64, ptr %slot8, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %ld3171 = load i32, ptr %p3170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3171, ptr %slot603, align 8
  %v3172 = load i32, ptr %slot603, align 8
  %cv3173 = zext i32 %v3172 to i64
  %cond3174 = icmp ne i64 %cv3173, 0
  br i1 %cond3174, label %bb_rcslotdrop985, label %bb_rcslotdone985
bb_rcslotdrop985:
  %v3175 = load i64, ptr %slot8, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i32 0, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot13, align 8
  store i64 %v3177, ptr %slot604, align 8
  %v3178 = load i64, ptr %slot9, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  %ld3180 = load i32, ptr %p3179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3180, ptr %slot605, align 8
  %v3181 = load i32, ptr %slot605, align 8
  %op3182 = and i32 %v3181, 28
  store i32 %op3182, ptr %slot606, align 8
  %v3183 = load i32, ptr %slot606, align 8
  %cv3184 = zext i32 %v3183 to i64
  %cond3185 = icmp ne i64 %cv3184, 0
  br i1 %cond3185, label %bb_rcslotrole985, label %bb_rcslotowner985
bb_rcslotrole985:
  %v3186 = load i64, ptr %slot34, align 8
  store i64 %v3186, ptr %slot607, align 8
  %v3187 = load i64, ptr %slot607, align 8
  %v3188 = load i64, ptr %slot604, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v3187, i64 %v3188) nomerge, !dbg !160
  br label %bb_rcslotdone985
bb_rcslotowner985:
  %v3189 = load i64, ptr %slot34, align 8
  store i64 %v3189, ptr %slot608, align 8
  %v3190 = load i64, ptr %slot608, align 8
  %v3191 = load i64, ptr %slot604, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v3190, i64 %v3191) nomerge, !dbg !160
  br label %bb_rcslotdone985
bb_rcslotdone985:
  %v3192 = load i64, ptr %slot6, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  %ld3194 = load i32, ptr %p3193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3194, ptr %slot609, align 8
  %v3195 = load i32, ptr %slot609, align 8
  %cv3196 = zext i32 %v3195 to i64
  %cond3197 = icmp ne i64 %cv3196, 0
  br i1 %cond3197, label %bb_rcslotdrop1031, label %bb_rcslotdone1031
bb_rcslotdrop1031:
  %v3198 = load i64, ptr %slot6, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  store i32 0, ptr %p3199, align 4, !alias.scope !3, !noalias !4
  %v3200 = load i64, ptr %slot21, align 8
  store i64 %v3200, ptr %slot610, align 8
  %v3201 = load i64, ptr %slot7, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %ld3203 = load i32, ptr %p3202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3203, ptr %slot611, align 8
  %v3204 = load i32, ptr %slot611, align 8
  %op3205 = and i32 %v3204, 28
  store i32 %op3205, ptr %slot612, align 8
  %v3206 = load i32, ptr %slot612, align 8
  %cv3207 = zext i32 %v3206 to i64
  %cond3208 = icmp ne i64 %cv3207, 0
  br i1 %cond3208, label %bb_rcslotrole1031, label %bb_rcslotowner1031
bb_rcslotrole1031:
  %v3209 = load i64, ptr %slot34, align 8
  store i64 %v3209, ptr %slot613, align 8
  %v3210 = load i64, ptr %slot613, align 8
  %v3211 = load i64, ptr %slot610, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3210, i64 %v3211) nomerge, !dbg !160
  br label %bb_rcslotdone1031
bb_rcslotowner1031:
  %v3212 = load i64, ptr %slot34, align 8
  store i64 %v3212, ptr %slot614, align 8
  %v3213 = load i64, ptr %slot614, align 8
  %v3214 = load i64, ptr %slot610, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3213, i64 %v3214) nomerge, !dbg !160
  br label %bb_rcslotdone1031
bb_rcslotdone1031:
  %v3215 = load i64, ptr %slot602, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3216, i64 24, i1 false)
  ret void
bb_failure:
  %v3217 = load i64, ptr %slot5, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  call void @llvm.memset.p0.i64(ptr %p3218, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !160
  %v3219 = load i64, ptr %slot5, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3220, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v3221 = load i64, ptr %slot5, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  call void @llvm.memset.p0.i64(ptr %p3222, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !160
  %v3223 = load i64, ptr %slot5, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3224, i64 24, i1 false)
  ret void
}

@myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b_meta = external global i8, align 8
@myl_lit_2988f248bcf7fecf94868b447d50e1ca761d4666b8875670525fa0e5a4347a5f = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64, i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64, i64)
declare i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64, i64)
declare i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b", linkageName: "myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5734452167748766478, i64 0, !"myl_f_456f52086262ab4527f9c37879b8830717fbe4903882a41068dd575e023b862b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!120 = !DILocation(line: 11, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!136 = !DILocation(line: 32, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!138 = !DILocation(line: 46, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!140 = !DILocation(line: 48, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!142 = !DILocation(line: 51, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!144 = !DILocation(line: 52, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!146 = !DILocation(line: 61, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!148 = !DILocation(line: 63, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!150 = !DILocation(line: 66, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!152 = !DILocation(line: 67, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!154 = !DILocation(line: 70, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!156 = !DILocation(line: 87, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!158 = !DILocation(line: 88, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!160 = !DILocation(line: 89, column: 0, scope: !161)
