target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v251 = load i64, ptr %slot1, align 8
  %op252 = add i64 %v251, 32
  store i64 %op252, ptr %slot3, align 8
  %mem253 = alloca i8, i64 40, align 8
  %ptr254 = ptrtoint ptr %mem253 to i64
  store i64 %ptr254, ptr %slot4, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot5, align 8
  %mem257 = alloca i8, i64 8, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot6, align 8
  %mem259 = alloca i8, i64 8, align 8
  %ptr260 = ptrtoint ptr %mem259 to i64
  store i64 %ptr260, ptr %slot7, align 8
  %mem261 = alloca i8, i64 8, align 8
  %ptr262 = ptrtoint ptr %mem261 to i64
  store i64 %ptr262, ptr %slot8, align 8
  %mem263 = alloca i8, i64 8, align 8
  %ptr264 = ptrtoint ptr %mem263 to i64
  store i64 %ptr264, ptr %slot9, align 8
  %mem265 = alloca i8, i64 8, align 8
  %ptr266 = ptrtoint ptr %mem265 to i64
  store i64 %ptr266, ptr %slot10, align 8
  %mem267 = alloca i8, i64 8, align 8
  %ptr268 = ptrtoint ptr %mem267 to i64
  store i64 %ptr268, ptr %slot11, align 8
  %mem269 = alloca i8, i64 40, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot12, align 8
  %mem271 = alloca i8, i64 8, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot13, align 8
  %mem273 = alloca i8, i64 8, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot14, align 8
  %mem275 = alloca i8, i64 8, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot15, align 8
  %mem277 = alloca i8, i64 40, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot16, align 8
  %mem279 = alloca i8, i64 8, align 8
  %ptr280 = ptrtoint ptr %mem279 to i64
  store i64 %ptr280, ptr %slot17, align 8
  %mem281 = alloca i8, i64 8, align 8
  %ptr282 = ptrtoint ptr %mem281 to i64
  store i64 %ptr282, ptr %slot18, align 8
  %mem283 = alloca i8, i64 8, align 8
  %ptr284 = ptrtoint ptr %mem283 to i64
  store i64 %ptr284, ptr %slot19, align 8
  %mem285 = alloca i8, i64 8, align 8
  %ptr286 = ptrtoint ptr %mem285 to i64
  store i64 %ptr286, ptr %slot20, align 8
  %mem287 = alloca i8, i64 8, align 8
  %ptr288 = ptrtoint ptr %mem287 to i64
  store i64 %ptr288, ptr %slot21, align 8
  %mem289 = alloca i8, i64 8, align 8
  %ptr290 = ptrtoint ptr %mem289 to i64
  store i64 %ptr290, ptr %slot22, align 8
  %mem291 = alloca i8, i64 40, align 8
  %ptr292 = ptrtoint ptr %mem291 to i64
  store i64 %ptr292, ptr %slot23, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem293 = alloca i8, i64 8, align 8
  %ptr294 = ptrtoint ptr %mem293 to i64
  store i64 %ptr294, ptr %slot24, align 8
  %v295 = load i64, ptr %slot1, align 8
  %op296 = add i64 %v295, 64
  store i64 %op296, ptr %slot25, align 8
  %v297 = load i64, ptr %slot25, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !4, !noalias !3
  store i64 %ld299, ptr %slot26, align 8
  %stack300 = call ptr @llvm.stacksave()
  %stackaddr301 = ptrtoint ptr %stack300 to i64
  %v302 = load i64, ptr %slot26, align 8
  %cmp303 = icmp ult i64 %stackaddr301, %v302
  %cv304 = zext i1 %cmp303 to i64
  store i64 %cv304, ptr %slot27, align 8
  %v305 = load i64, ptr %slot27, align 8
  %cond306 = icmp ne i64 %v305, 0
  br i1 %cond306, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v307 = load i64, ptr %slot1, align 8
  %p308 = inttoptr i64 %v307 to ptr
  call void @myl_qbe_fail_frame(ptr %p308) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v309 = load i64, ptr %slot2, align 8
  %v310 = load i64, ptr %slot17, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 %v309, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot1, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %call314 = call ptr @myl_qbe_heap(ptr %p313) nomerge, !dbg !112
  %calladdr315 = ptrtoint ptr %call314 to i64
  store i64 %calladdr315, ptr %slot28, align 8
  %v316 = load i64, ptr %slot1, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %call318 = call i64 @myl_qbe_region_mark(ptr %p317) nomerge, !dbg !112
  store i64 %call318, ptr %slot29, align 8
  %v319 = load i64, ptr %slot5, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot6, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 0, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot7, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 0, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot8, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 0, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot9, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 0, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot10, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i32 0, ptr %p330, align 4, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot11, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 0, ptr %p332, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v333 = load i64, ptr %slot1, align 8
  %call334 = call i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64 %v333) nomerge, !dbg !112
  store i64 %call334, ptr %slot30, align 8
  %v335 = load i64, ptr %slot30, align 8
  %v336 = load i64, ptr %slot18, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 %v335, ptr %p337, align 8, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot18, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot31, align 8
  %v341 = load i64, ptr %slot31, align 8
  %v342 = load i64, ptr %slot14, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot14, align 8
  store i64 %v344, ptr %slot32, align 8
  %v345 = load i64, ptr %slot16, align 8
  store i64 %v345, ptr %slot33, align 8
  %v346 = load i64, ptr %slot32, align 8
  %v347 = load i64, ptr %slot33, align 8
  %p348 = inttoptr i64 %v346 to ptr
  %p349 = inttoptr i64 %v347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p349, ptr %p348, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot10, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 2, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot9, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot12, align 8
  store i64 %v354, ptr %slot34, align 8
  %v355 = load i64, ptr %slot16, align 8
  store i64 %v355, ptr %slot35, align 8
  %v356 = load i64, ptr %slot35, align 8
  %v357 = load i64, ptr %slot34, align 8
  %p358 = inttoptr i64 %v356 to ptr
  %p359 = inttoptr i64 %v357 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p359, ptr %p358, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot6, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i32 2, ptr %p361, align 4, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot10, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i32, ptr %p363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld364, ptr %slot36, align 8
  %v365 = load i32, ptr %slot36, align 8
  %v366 = load i64, ptr %slot6, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i32 %v365, ptr %p367, align 4, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot9, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 0, ptr %p369, align 4, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i32 1, ptr %p371, align 4, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot34, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot37, align 8
  %v375 = load i64, ptr %slot37, align 8
  %v376 = load i64, ptr %slot18, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 %v375, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot1, align 8
  %call379 = call i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64 %v378) nomerge, !dbg !114
  store i64 %call379, ptr %slot38, align 8
  %v380 = load i64, ptr %slot38, align 8
  %v381 = load i64, ptr %slot19, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot19, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot39, align 8
  %v386 = load i64, ptr %slot39, align 8
  %v387 = load i64, ptr %slot15, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i64 %v386, ptr %p388, align 8, !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot15, align 8
  store i64 %v389, ptr %slot40, align 8
  %v390 = load i64, ptr %slot16, align 8
  store i64 %v390, ptr %slot41, align 8
  %v391 = load i64, ptr %slot40, align 8
  %v392 = load i64, ptr %slot41, align 8
  %p393 = inttoptr i64 %v391 to ptr
  %p394 = inttoptr i64 %v392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p394, ptr %p393, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot10, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i32 2, ptr %p396, align 4, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot9, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i32 1, ptr %p398, align 4, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot13, align 8
  store i64 %v399, ptr %slot42, align 8
  %v400 = load i64, ptr %slot16, align 8
  store i64 %v400, ptr %slot43, align 8
  %v401 = load i64, ptr %slot43, align 8
  %v402 = load i64, ptr %slot42, align 8
  %p403 = inttoptr i64 %v401 to ptr
  %p404 = inttoptr i64 %v402 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p404, ptr %p403, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot8, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i32 2, ptr %p406, align 4, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot10, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i32, ptr %p408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld409, ptr %slot44, align 8
  %v410 = load i32, ptr %slot44, align 8
  %v411 = load i64, ptr %slot8, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 %v410, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot9, align 8
  %p414 = inttoptr i64 %v413 to ptr
  store i32 0, ptr %p414, align 4, !alias.scope !3, !noalias !4
  %v415 = load i64, ptr %slot7, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i32 1, ptr %p416, align 4, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot42, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot45, align 8
  %v420 = load i64, ptr %slot45, align 8
  %v421 = load i64, ptr %slot19, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot17, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot46, align 8
  %v426 = load i64, ptr %slot46, align 8
  %v427 = load i64, ptr %slot20, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i64 %v426, ptr %p428, align 8, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot17, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot47, align 8
  %v432 = load i64, ptr %slot47, align 8
  %v433 = load i64, ptr %slot21, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot22, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i64 1, ptr %p436, align 8, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot23, align 8
  store i64 %v437, ptr %slot48, align 8
  %v438 = load i64, ptr %slot48, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 0, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot48, align 8
  %p442 = inttoptr i64 %v440 to ptr
  %gep443 = getelementptr i8, ptr %p442, i64 8
  %op441 = ptrtoint ptr %gep443 to i64
  store i64 %op441, ptr %slot49, align 8
  %v444 = load i64, ptr %slot49, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 0, ptr %p445, align 8, !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot48, align 8
  %p448 = inttoptr i64 %v446 to ptr
  %gep449 = getelementptr i8, ptr %p448, i64 16
  %op447 = ptrtoint ptr %gep449 to i64
  store i64 %op447, ptr %slot50, align 8
  %v450 = load i64, ptr %slot50, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 0, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot48, align 8
  %p454 = inttoptr i64 %v452 to ptr
  %gep455 = getelementptr i8, ptr %p454, i64 24
  %op453 = ptrtoint ptr %gep455 to i64
  store i64 %op453, ptr %slot51, align 8
  %v456 = load i64, ptr %slot51, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 0, ptr %p457, align 8, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot48, align 8
  %p460 = inttoptr i64 %v458 to ptr
  %gep461 = getelementptr i8, ptr %p460, i64 32
  %op459 = ptrtoint ptr %gep461 to i64
  store i64 %op459, ptr %slot52, align 8
  %v462 = load i64, ptr %slot52, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 0, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot11, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i32 1, ptr %p465, align 4, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot29, align 8
  store i64 %v466, ptr %slot53, align 8
  %v467 = load i64, ptr %slot18, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %ld469 = load i64, ptr %p468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld469, ptr %slot54, align 8
  %v470 = load i64, ptr %slot54, align 8
  %v471 = load i64, ptr %slot14, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot14, align 8
  store i64 %v473, ptr %slot55, align 8
  %v474 = load i64, ptr %slot48, align 8
  %p476 = inttoptr i64 %v474 to ptr
  %gep477 = getelementptr i8, ptr %p476, i64 0
  %op475 = ptrtoint ptr %gep477 to i64
  store i64 %op475, ptr %slot56, align 8
  %v478 = load i64, ptr %slot18, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot57, align 8
  %v481 = load i64, ptr %slot57, align 8
  %v482 = load i64, ptr %slot14, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i64 %v481, ptr %p483, align 8, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot14, align 8
  store i64 %v484, ptr %slot58, align 8
  %v485 = load i64, ptr %slot5, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i32, ptr %p486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld487, ptr %slot59, align 8
  %v488 = load i64, ptr %slot6, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %ld490 = load i32, ptr %p489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld490, ptr %slot60, align 8
  %v491 = load i32, ptr %slot60, align 8
  %op492 = and i32 %v491, 24
  store i32 %op492, ptr %slot60, align 8
  %v493 = load i32, ptr %slot60, align 8
  %cmp494 = icmp eq i32 %v493, 0
  %cv495 = zext i1 %cmp494 to i32
  store i32 %cv495, ptr %slot61, align 8
  %v496 = load i32, ptr %slot59, align 8
  %v497 = load i32, ptr %slot61, align 8
  %op498 = and i32 %v496, %v497
  store i32 %op498, ptr %slot62, align 8
  %v499 = load i32, ptr %slot62, align 8
  %cv500 = zext i32 %v499 to i64
  %cond501 = icmp ne i64 %cv500, 0
  br i1 %cond501, label %bb_rctake52, label %bb_rccopy52
bb_rctake52:
  %v502 = load i64, ptr %slot16, align 8
  store i64 %v502, ptr %slot63, align 8
  %v503 = load i64, ptr %slot29, align 8
  store i64 %v503, ptr %slot64, align 8
  %v504 = load i64, ptr %slot58, align 8
  %v505 = load i64, ptr %slot63, align 8
  %op506 = sub i64 %v504, %v505
  store i64 %op506, ptr %slot65, align 8
  %v507 = load i64, ptr %slot63, align 8
  %v508 = load i64, ptr %slot58, align 8
  %op509 = sub i64 %v507, %v508
  store i64 %op509, ptr %slot66, align 8
  %v510 = load i64, ptr %slot65, align 8
  %cmp511 = icmp ult i64 %v510, 8
  %cv512 = zext i1 %cmp511 to i32
  store i32 %cv512, ptr %slot67, align 8
  %v513 = load i64, ptr %slot66, align 8
  %cmp514 = icmp ult i64 %v513, 8
  %cv515 = zext i1 %cmp514 to i32
  store i32 %cv515, ptr %slot68, align 8
  %v516 = load i32, ptr %slot67, align 8
  %v517 = load i32, ptr %slot68, align 8
  %op518 = or i32 %v516, %v517
  store i32 %op518, ptr %slot69, align 8
  %v519 = load i32, ptr %slot69, align 8
  %cv520 = zext i32 %v519 to i64
  %cond521 = icmp ne i64 %cv520, 0
  br i1 %cond521, label %bb_rcmoveslow61, label %bb_rcmovecheck61
bb_rcmovecheck61:
  %v522 = load i64, ptr %slot58, align 8
  %p524 = inttoptr i64 %v522 to ptr
  %gep525 = getelementptr i8, ptr %p524, i64 0
  %op523 = ptrtoint ptr %gep525 to i64
  store i64 %op523, ptr %slot70, align 8
  %v526 = load i64, ptr %slot70, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot71, align 8
  %v529 = load i64, ptr %slot71, align 8
  %cmp530 = icmp ne i64 %v529, 0
  %cv531 = zext i1 %cmp530 to i32
  store i32 %cv531, ptr %slot72, align 8
  %v532 = load i32, ptr %slot72, align 8
  %cv533 = zext i32 %v532 to i64
  %cond534 = icmp ne i64 %cv533, 0
  br i1 %cond534, label %bb_rcmoveheader69, label %bb_rcmovenext69
bb_rcmoveheader69:
  %v535 = load i64, ptr %slot71, align 8
  %op536 = sub i64 %v535, 16
  store i64 %op536, ptr %slot73, align 8
  %v537 = load i64, ptr %slot71, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %rgep539 = getelementptr i8, ptr %p538, i64 -16
  %ld540 = load i64, ptr %rgep539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld540, ptr %slot74, align 8
  %v541 = load i64, ptr %slot74, align 8
  %op542 = and i64 %v541, 5764607523034234881
  store i64 %op542, ptr %slot75, align 8
  %v543 = load i64, ptr %slot75, align 8
  %cmp544 = icmp ne i64 %v543, 0
  %cv545 = zext i1 %cmp544 to i32
  store i32 %cv545, ptr %slot76, align 8
  %v546 = load i32, ptr %slot76, align 8
  %cv547 = zext i32 %v546 to i64
  %cond548 = icmp ne i64 %cv547, 0
  br i1 %cond548, label %bb_rcmoveslow61, label %bb_rcmovenext69
bb_rcmovenext69:
  %v549 = load i64, ptr %slot58, align 8
  %v550 = load i64, ptr %slot63, align 8
  %p551 = inttoptr i64 %v549 to ptr
  %p552 = inttoptr i64 %v550 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p552, ptr %p551, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot58, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i64 0, ptr %p554, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved61
bb_rcmoveslow61:
  %v555 = load i64, ptr %slot28, align 8
  %v556 = load i64, ptr %slot63, align 8
  %v557 = load i64, ptr %slot58, align 8
  %v558 = load i64, ptr %slot64, align 8
  %cv559 = trunc i64 %v558 to i32
  %call560 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v555, i64 %v556, i64 %v557, i32 %cv559) nomerge, !dbg !116
  store i32 %call560, ptr %slot77, align 8
  %v561 = load i32, ptr %slot77, align 8
  %cv562 = zext i32 %v561 to i64
  %cond563 = icmp ne i64 %cv562, 0
  br i1 %cond563, label %bb_rcsuccess76, label %bb_rcfailure76
bb_rcfailure76:
  %v564 = load i64, ptr %slot28, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %call566 = call i32 @myl_rc_take_failure(ptr %p565) nomerge, !dbg !116
  store i32 %call566, ptr %slot78, align 8
  %v567 = load i64, ptr %slot1, align 8
  %p568 = inttoptr i64 %v567 to ptr
  %v569 = load i32, ptr %slot78, align 8
  %call570 = call i32 @myl_qbe_rc_status(ptr %p568, i32 %v569) nomerge, !dbg !116
  store i32 %call570, ptr %slot79, align 8
  br label %bb_failure
bb_rcsuccess76:
  br label %bb_rcmoved61
bb_rcmoved61:
  %v571 = load i64, ptr %slot5, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 0, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot10, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 2, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot9, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 1, ptr %p576, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared52
bb_rccopy52:
  %v577 = load i64, ptr %slot16, align 8
  store i64 %v577, ptr %slot80, align 8
  %v578 = load i64, ptr %slot29, align 8
  store i64 %v578, ptr %slot81, align 8
  %v579 = load i64, ptr %slot58, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i64, ptr %p580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld581, ptr %slot82, align 8
  %v582 = load i64, ptr %slot82, align 8
  %cmp583 = icmp ne i64 %v582, 0
  %cv584 = zext i1 %cmp583 to i32
  store i32 %cv584, ptr %slot83, align 8
  %v585 = load i32, ptr %slot83, align 8
  %cv586 = zext i32 %v585 to i64
  %cond587 = icmp ne i64 %cv586, 0
  br i1 %cond587, label %bb_rcgnn85, label %bb_rcgplain85
bb_rcgnn85:
  %v588 = load i64, ptr %slot82, align 8
  %op589 = sub i64 %v588, 16
  store i64 %op589, ptr %slot84, align 8
  %v590 = load i64, ptr %slot82, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %rgep592 = getelementptr i8, ptr %p591, i64 -16
  %ld593 = load i64, ptr %rgep592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld593, ptr %slot85, align 8
  %v594 = load i64, ptr %slot85, align 8
  %op595 = and i64 %v594, 4611686018427387906
  store i64 %op595, ptr %slot86, align 8
  %v596 = load i64, ptr %slot86, align 8
  %cmp597 = icmp ne i64 %v596, 0
  %cv598 = zext i1 %cmp597 to i32
  store i32 %cv598, ptr %slot87, align 8
  %v599 = load i32, ptr %slot87, align 8
  %cv600 = zext i32 %v599 to i64
  %cond601 = icmp ne i64 %cv600, 0
  br i1 %cond601, label %bb_rcgspecial85, label %bb_rcginc85
bb_rcginc85:
  %v602 = load i64, ptr %slot82, align 8
  %op603 = sub i64 %v602, 32
  store i64 %op603, ptr %slot88, align 8
  %v604 = load i64, ptr %slot82, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %rgep606 = getelementptr i8, ptr %p605, i64 -32
  %ld607 = load i64, ptr %rgep606, align 8, !alias.scope !9, !noalias !10
  store i64 %ld607, ptr %slot89, align 8
  %v608 = load i64, ptr %slot89, align 8
  %op609 = add i64 %v608, 1
  store i64 %op609, ptr %slot90, align 8
  %v610 = load i64, ptr %slot90, align 8
  %cmp611 = icmp eq i64 %v610, 0
  %cv612 = zext i1 %cmp611 to i32
  store i32 %cv612, ptr %slot91, align 8
  %v613 = load i32, ptr %slot91, align 8
  %cv614 = zext i32 %v613 to i64
  %cond615 = icmp ne i64 %cv614, 0
  br i1 %cond615, label %bb_rcglimit85, label %bb_rcgcapacity85
bb_rcglimit85:
  %v616 = load i64, ptr %slot1, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %call618 = call i32 @myl_qbe_rc_status(ptr %p617, i32 2) nomerge, !dbg !116
  store i32 %call618, ptr %slot92, align 8
  br label %bb_failure
bb_rcgcapacity85:
  %v619 = load i64, ptr %slot90, align 8
  %v620 = load i64, ptr %slot82, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %rgep622 = getelementptr i8, ptr %p621, i64 -32
  store i64 %v619, ptr %rgep622, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain85
bb_rcgspecial85:
  %v623 = load i64, ptr %slot85, align 8
  %op624 = and i64 %v623, 4611686018427387904
  store i64 %op624, ptr %slot93, align 8
  %v625 = load i64, ptr %slot93, align 8
  %cmp626 = icmp ne i64 %v625, 0
  %cv627 = zext i1 %cmp626 to i32
  store i32 %cv627, ptr %slot94, align 8
  %v628 = load i32, ptr %slot94, align 8
  %cv629 = zext i32 %v628 to i64
  %cond630 = icmp ne i64 %cv629, 0
  br i1 %cond630, label %bb_rcgslow85, label %bb_rcgplain85
bb_rcgslow85:
  %v631 = load i64, ptr %slot28, align 8
  %v632 = load i64, ptr %slot80, align 8
  %v633 = load i64, ptr %slot58, align 8
  %v634 = load i64, ptr %slot81, align 8
  %cv635 = trunc i64 %v634 to i32
  %call636 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v631, i64 %v632, i64 %v633, i32 %cv635) nomerge, !dbg !116
  store i32 %call636, ptr %slot95, align 8
  %v637 = load i32, ptr %slot95, align 8
  %cv638 = zext i32 %v637 to i64
  %cond639 = icmp ne i64 %cv638, 0
  br i1 %cond639, label %bb_rcsuccess99, label %bb_rcfailure99
bb_rcfailure99:
  %v640 = load i64, ptr %slot28, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %call642 = call i32 @myl_rc_take_failure(ptr %p641) nomerge, !dbg !116
  store i32 %call642, ptr %slot96, align 8
  %v643 = load i64, ptr %slot1, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %v645 = load i32, ptr %slot96, align 8
  %call646 = call i32 @myl_qbe_rc_status(ptr %p644, i32 %v645) nomerge, !dbg !116
  store i32 %call646, ptr %slot97, align 8
  br label %bb_failure
bb_rcsuccess99:
  br label %bb_rcgdone85
bb_rcgplain85:
  %v647 = load i64, ptr %slot82, align 8
  %v648 = load i64, ptr %slot80, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i64 %v647, ptr %p649, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone85
bb_rcgdone85:
  %v650 = load i64, ptr %slot10, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i32 2, ptr %p651, align 4, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot9, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i32 1, ptr %p653, align 4, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot5, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i32, ptr %p655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld656, ptr %slot98, align 8
  %v657 = load i32, ptr %slot98, align 8
  %cv658 = zext i32 %v657 to i64
  %cond659 = icmp ne i64 %cv658, 0
  br i1 %cond659, label %bb_rcslotdrop106, label %bb_rcslotdone106
bb_rcslotdrop106:
  %v660 = load i64, ptr %slot5, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i32 0, ptr %p661, align 4, !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot12, align 8
  store i64 %v662, ptr %slot99, align 8
  %v663 = load i64, ptr %slot6, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i32, ptr %p664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld665, ptr %slot100, align 8
  %v666 = load i32, ptr %slot100, align 8
  %op667 = and i32 %v666, 28
  store i32 %op667, ptr %slot101, align 8
  %v668 = load i32, ptr %slot101, align 8
  %cv669 = zext i32 %v668 to i64
  %cond670 = icmp ne i64 %cv669, 0
  br i1 %cond670, label %bb_rcslotrole106, label %bb_rcslotowner106
bb_rcslotrole106:
  %v671 = load i64, ptr %slot28, align 8
  store i64 %v671, ptr %slot102, align 8
  %v672 = load i64, ptr %slot99, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld674, ptr %slot103, align 8
  %v675 = load i64, ptr %slot103, align 8
  %cmp676 = icmp ne i64 %v675, 0
  %cv677 = zext i1 %cmp676 to i32
  store i32 %cv677, ptr %slot104, align 8
  %v678 = load i32, ptr %slot104, align 8
  %cv679 = zext i32 %v678 to i64
  %cond680 = icmp ne i64 %cv679, 0
  br i1 %cond680, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v681 = load i64, ptr %slot103, align 8
  %op682 = sub i64 %v681, 16
  store i64 %op682, ptr %slot105, align 8
  %v683 = load i64, ptr %slot103, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %rgep685 = getelementptr i8, ptr %p684, i64 -16
  %ld686 = load i64, ptr %rgep685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld686, ptr %slot106, align 8
  %v687 = load i64, ptr %slot106, align 8
  %op688 = and i64 %v687, 4611686018427387906
  store i64 %op688, ptr %slot107, align 8
  %v689 = load i64, ptr %slot107, align 8
  %cmp690 = icmp ne i64 %v689, 0
  %cv691 = zext i1 %cmp690 to i32
  store i32 %cv691, ptr %slot108, align 8
  %v692 = load i32, ptr %slot108, align 8
  %cv693 = zext i32 %v692 to i64
  %cond694 = icmp ne i64 %cv693, 0
  br i1 %cond694, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v695 = load i64, ptr %slot103, align 8
  %op696 = sub i64 %v695, 24
  store i64 %op696, ptr %slot109, align 8
  %v697 = load i64, ptr %slot103, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %rgep699 = getelementptr i8, ptr %p698, i64 -24
  %ld700 = load i64, ptr %rgep699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld700, ptr %slot110, align 8
  %v701 = load i64, ptr %slot110, align 8
  %op702 = sub i64 %v701, 1
  store i64 %op702, ptr %slot111, align 8
  %v703 = load i64, ptr %slot111, align 8
  %cmp704 = icmp eq i64 %v703, 0
  %cv705 = zext i1 %cmp704 to i32
  store i32 %cv705, ptr %slot112, align 8
  %v706 = load i32, ptr %slot112, align 8
  %cv707 = zext i32 %v706 to i64
  %cond708 = icmp ne i64 %cv707, 0
  br i1 %cond708, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v709 = load i64, ptr %slot103, align 8
  %op710 = sub i64 %v709, 32
  store i64 %op710, ptr %slot113, align 8
  %v711 = load i64, ptr %slot103, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %rgep713 = getelementptr i8, ptr %p712, i64 -32
  %ld714 = load i64, ptr %rgep713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld714, ptr %slot114, align 8
  %v715 = load i64, ptr %slot114, align 8
  %cmp716 = icmp ne i64 %v715, 0
  %cv717 = zext i1 %cmp716 to i32
  store i32 %cv717, ptr %slot115, align 8
  %v718 = load i32, ptr %slot115, align 8
  %cv719 = zext i32 %v718 to i64
  %cond720 = icmp ne i64 %cv719, 0
  br i1 %cond720, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v721 = load i64, ptr %slot102, align 8
  %v722 = load i64, ptr %slot99, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v721, i64 %v722) nomerge, !dbg !116
  br label %bb_rcgdone122
bb_rcgdec122:
  %v723 = load i64, ptr %slot111, align 8
  %v724 = load i64, ptr %slot103, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %rgep726 = getelementptr i8, ptr %p725, i64 -24
  store i64 %v723, ptr %rgep726, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v727 = load i64, ptr %slot99, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 0, ptr %p728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone106
bb_rcslotowner106:
  %v729 = load i64, ptr %slot28, align 8
  store i64 %v729, ptr %slot116, align 8
  %v730 = load i64, ptr %slot99, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot117, align 8
  %v733 = load i64, ptr %slot117, align 8
  %cmp734 = icmp ne i64 %v733, 0
  %cv735 = zext i1 %cmp734 to i32
  store i32 %cv735, ptr %slot118, align 8
  %v736 = load i32, ptr %slot118, align 8
  %cv737 = zext i32 %v736 to i64
  %cond738 = icmp ne i64 %cv737, 0
  br i1 %cond738, label %bb_rcgnn137, label %bb_rcgdone137
bb_rcgnn137:
  %v739 = load i64, ptr %slot117, align 8
  %op740 = sub i64 %v739, 16
  store i64 %op740, ptr %slot119, align 8
  %v741 = load i64, ptr %slot117, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %rgep743 = getelementptr i8, ptr %p742, i64 -16
  %ld744 = load i64, ptr %rgep743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld744, ptr %slot120, align 8
  %v745 = load i64, ptr %slot120, align 8
  %op746 = and i64 %v745, 4611686018427387906
  store i64 %op746, ptr %slot121, align 8
  %v747 = load i64, ptr %slot121, align 8
  %cmp748 = icmp ne i64 %v747, 0
  %cv749 = zext i1 %cmp748 to i32
  store i32 %cv749, ptr %slot122, align 8
  %v750 = load i32, ptr %slot122, align 8
  %cv751 = zext i32 %v750 to i64
  %cond752 = icmp ne i64 %cv751, 0
  br i1 %cond752, label %bb_rcgclear137, label %bb_rcgcounted137
bb_rcgcounted137:
  %v753 = load i64, ptr %slot117, align 8
  %op754 = sub i64 %v753, 32
  store i64 %op754, ptr %slot123, align 8
  %v755 = load i64, ptr %slot117, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %rgep757 = getelementptr i8, ptr %p756, i64 -32
  %ld758 = load i64, ptr %rgep757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld758, ptr %slot124, align 8
  %v759 = load i64, ptr %slot124, align 8
  %op760 = sub i64 %v759, 1
  store i64 %op760, ptr %slot125, align 8
  %v761 = load i64, ptr %slot125, align 8
  %cmp762 = icmp eq i64 %v761, 0
  %cv763 = zext i1 %cmp762 to i32
  store i32 %cv763, ptr %slot126, align 8
  %v764 = load i32, ptr %slot126, align 8
  %cv765 = zext i32 %v764 to i64
  %cond766 = icmp ne i64 %cv765, 0
  br i1 %cond766, label %bb_rcglast137, label %bb_rcgdec137
bb_rcglast137:
  %v767 = load i64, ptr %slot117, align 8
  %op768 = sub i64 %v767, 24
  store i64 %op768, ptr %slot127, align 8
  %v769 = load i64, ptr %slot117, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %rgep771 = getelementptr i8, ptr %p770, i64 -24
  %ld772 = load i64, ptr %rgep771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld772, ptr %slot128, align 8
  %v773 = load i64, ptr %slot128, align 8
  %cmp774 = icmp ne i64 %v773, 0
  %cv775 = zext i1 %cmp774 to i32
  store i32 %cv775, ptr %slot129, align 8
  %v776 = load i32, ptr %slot129, align 8
  %cv777 = zext i32 %v776 to i64
  %cond778 = icmp ne i64 %cv777, 0
  br i1 %cond778, label %bb_rcgdec137, label %bb_rcgslow137
bb_rcgslow137:
  %v779 = load i64, ptr %slot116, align 8
  %v780 = load i64, ptr %slot99, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v779, i64 %v780) nomerge, !dbg !116
  br label %bb_rcgdone137
bb_rcgdec137:
  %v781 = load i64, ptr %slot125, align 8
  %v782 = load i64, ptr %slot117, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %rgep784 = getelementptr i8, ptr %p783, i64 -32
  store i64 %v781, ptr %rgep784, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear137
bb_rcgclear137:
  %v785 = load i64, ptr %slot99, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i64 0, ptr %p786, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone137
bb_rcgdone137:
  br label %bb_rcslotdone106
bb_rcslotdone106:
  br label %bb_rcprepared52
bb_rcprepared52:
  %v787 = load i64, ptr %slot16, align 8
  store i64 %v787, ptr %slot130, align 8
  %v788 = load i64, ptr %slot130, align 8
  %v789 = load i64, ptr %slot56, align 8
  %p790 = inttoptr i64 %v788 to ptr
  %p791 = inttoptr i64 %v789 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p791, ptr %p790, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot9, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i32 0, ptr %p793, align 4, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot19, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld796, ptr %slot131, align 8
  %v797 = load i64, ptr %slot131, align 8
  %v798 = load i64, ptr %slot15, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot15, align 8
  store i64 %v800, ptr %slot132, align 8
  %v801 = load i64, ptr %slot48, align 8
  %p803 = inttoptr i64 %v801 to ptr
  %gep804 = getelementptr i8, ptr %p803, i64 8
  %op802 = ptrtoint ptr %gep804 to i64
  store i64 %op802, ptr %slot133, align 8
  %v805 = load i64, ptr %slot19, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot134, align 8
  %v808 = load i64, ptr %slot134, align 8
  %v809 = load i64, ptr %slot15, align 8
  %p810 = inttoptr i64 %v809 to ptr
  store i64 %v808, ptr %p810, align 8, !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot15, align 8
  store i64 %v811, ptr %slot135, align 8
  %v812 = load i64, ptr %slot7, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i32, ptr %p813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld814, ptr %slot136, align 8
  %v815 = load i64, ptr %slot8, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %ld817 = load i32, ptr %p816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld817, ptr %slot137, align 8
  %v818 = load i32, ptr %slot137, align 8
  %op819 = and i32 %v818, 24
  store i32 %op819, ptr %slot137, align 8
  %v820 = load i32, ptr %slot137, align 8
  %cmp821 = icmp eq i32 %v820, 0
  %cv822 = zext i1 %cmp821 to i32
  store i32 %cv822, ptr %slot138, align 8
  %v823 = load i32, ptr %slot136, align 8
  %v824 = load i32, ptr %slot138, align 8
  %op825 = and i32 %v823, %v824
  store i32 %op825, ptr %slot139, align 8
  %v826 = load i32, ptr %slot139, align 8
  %cv827 = zext i32 %v826 to i64
  %cond828 = icmp ne i64 %cv827, 0
  br i1 %cond828, label %bb_rctake148, label %bb_rccopy148
bb_rctake148:
  %v829 = load i64, ptr %slot16, align 8
  store i64 %v829, ptr %slot140, align 8
  %v830 = load i64, ptr %slot29, align 8
  store i64 %v830, ptr %slot141, align 8
  %v831 = load i64, ptr %slot135, align 8
  %v832 = load i64, ptr %slot140, align 8
  %op833 = sub i64 %v831, %v832
  store i64 %op833, ptr %slot142, align 8
  %v834 = load i64, ptr %slot140, align 8
  %v835 = load i64, ptr %slot135, align 8
  %op836 = sub i64 %v834, %v835
  store i64 %op836, ptr %slot143, align 8
  %v837 = load i64, ptr %slot142, align 8
  %cmp838 = icmp ult i64 %v837, 8
  %cv839 = zext i1 %cmp838 to i32
  store i32 %cv839, ptr %slot144, align 8
  %v840 = load i64, ptr %slot143, align 8
  %cmp841 = icmp ult i64 %v840, 8
  %cv842 = zext i1 %cmp841 to i32
  store i32 %cv842, ptr %slot145, align 8
  %v843 = load i32, ptr %slot144, align 8
  %v844 = load i32, ptr %slot145, align 8
  %op845 = or i32 %v843, %v844
  store i32 %op845, ptr %slot146, align 8
  %v846 = load i32, ptr %slot146, align 8
  %cv847 = zext i32 %v846 to i64
  %cond848 = icmp ne i64 %cv847, 0
  br i1 %cond848, label %bb_rcmoveslow157, label %bb_rcmovecheck157
bb_rcmovecheck157:
  %v849 = load i64, ptr %slot135, align 8
  %p851 = inttoptr i64 %v849 to ptr
  %gep852 = getelementptr i8, ptr %p851, i64 0
  %op850 = ptrtoint ptr %gep852 to i64
  store i64 %op850, ptr %slot147, align 8
  %v853 = load i64, ptr %slot147, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot148, align 8
  %v856 = load i64, ptr %slot148, align 8
  %cmp857 = icmp ne i64 %v856, 0
  %cv858 = zext i1 %cmp857 to i32
  store i32 %cv858, ptr %slot149, align 8
  %v859 = load i32, ptr %slot149, align 8
  %cv860 = zext i32 %v859 to i64
  %cond861 = icmp ne i64 %cv860, 0
  br i1 %cond861, label %bb_rcmoveheader165, label %bb_rcmovenext165
bb_rcmoveheader165:
  %v862 = load i64, ptr %slot148, align 8
  %op863 = sub i64 %v862, 16
  store i64 %op863, ptr %slot150, align 8
  %v864 = load i64, ptr %slot148, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %rgep866 = getelementptr i8, ptr %p865, i64 -16
  %ld867 = load i64, ptr %rgep866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld867, ptr %slot151, align 8
  %v868 = load i64, ptr %slot151, align 8
  %op869 = and i64 %v868, 5764607523034234881
  store i64 %op869, ptr %slot152, align 8
  %v870 = load i64, ptr %slot152, align 8
  %cmp871 = icmp ne i64 %v870, 0
  %cv872 = zext i1 %cmp871 to i32
  store i32 %cv872, ptr %slot153, align 8
  %v873 = load i32, ptr %slot153, align 8
  %cv874 = zext i32 %v873 to i64
  %cond875 = icmp ne i64 %cv874, 0
  br i1 %cond875, label %bb_rcmoveslow157, label %bb_rcmovenext165
bb_rcmovenext165:
  %v876 = load i64, ptr %slot135, align 8
  %v877 = load i64, ptr %slot140, align 8
  %p878 = inttoptr i64 %v876 to ptr
  %p879 = inttoptr i64 %v877 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p879, ptr %p878, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v880 = load i64, ptr %slot135, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 0, ptr %p881, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved157
bb_rcmoveslow157:
  %v882 = load i64, ptr %slot28, align 8
  %v883 = load i64, ptr %slot140, align 8
  %v884 = load i64, ptr %slot135, align 8
  %v885 = load i64, ptr %slot141, align 8
  %cv886 = trunc i64 %v885 to i32
  %call887 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v882, i64 %v883, i64 %v884, i32 %cv886) nomerge, !dbg !116
  store i32 %call887, ptr %slot154, align 8
  %v888 = load i32, ptr %slot154, align 8
  %cv889 = zext i32 %v888 to i64
  %cond890 = icmp ne i64 %cv889, 0
  br i1 %cond890, label %bb_rcsuccess172, label %bb_rcfailure172
bb_rcfailure172:
  %v891 = load i64, ptr %slot28, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %call893 = call i32 @myl_rc_take_failure(ptr %p892) nomerge, !dbg !116
  store i32 %call893, ptr %slot155, align 8
  %v894 = load i64, ptr %slot1, align 8
  %p895 = inttoptr i64 %v894 to ptr
  %v896 = load i32, ptr %slot155, align 8
  %call897 = call i32 @myl_qbe_rc_status(ptr %p895, i32 %v896) nomerge, !dbg !116
  store i32 %call897, ptr %slot156, align 8
  br label %bb_failure
bb_rcsuccess172:
  br label %bb_rcmoved157
bb_rcmoved157:
  %v898 = load i64, ptr %slot7, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 0, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot10, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i32 2, ptr %p901, align 4, !alias.scope !3, !noalias !4
  %v902 = load i64, ptr %slot9, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i32 1, ptr %p903, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared148
bb_rccopy148:
  %v904 = load i64, ptr %slot16, align 8
  store i64 %v904, ptr %slot157, align 8
  %v905 = load i64, ptr %slot29, align 8
  store i64 %v905, ptr %slot158, align 8
  %v906 = load i64, ptr %slot135, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i64, ptr %p907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld908, ptr %slot159, align 8
  %v909 = load i64, ptr %slot159, align 8
  %cmp910 = icmp ne i64 %v909, 0
  %cv911 = zext i1 %cmp910 to i32
  store i32 %cv911, ptr %slot160, align 8
  %v912 = load i32, ptr %slot160, align 8
  %cv913 = zext i32 %v912 to i64
  %cond914 = icmp ne i64 %cv913, 0
  br i1 %cond914, label %bb_rcgnn181, label %bb_rcgplain181
bb_rcgnn181:
  %v915 = load i64, ptr %slot159, align 8
  %op916 = sub i64 %v915, 16
  store i64 %op916, ptr %slot161, align 8
  %v917 = load i64, ptr %slot159, align 8
  %p918 = inttoptr i64 %v917 to ptr
  %rgep919 = getelementptr i8, ptr %p918, i64 -16
  %ld920 = load i64, ptr %rgep919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld920, ptr %slot162, align 8
  %v921 = load i64, ptr %slot162, align 8
  %op922 = and i64 %v921, 4611686018427387906
  store i64 %op922, ptr %slot163, align 8
  %v923 = load i64, ptr %slot163, align 8
  %cmp924 = icmp ne i64 %v923, 0
  %cv925 = zext i1 %cmp924 to i32
  store i32 %cv925, ptr %slot164, align 8
  %v926 = load i32, ptr %slot164, align 8
  %cv927 = zext i32 %v926 to i64
  %cond928 = icmp ne i64 %cv927, 0
  br i1 %cond928, label %bb_rcgspecial181, label %bb_rcginc181
bb_rcginc181:
  %v929 = load i64, ptr %slot159, align 8
  %op930 = sub i64 %v929, 32
  store i64 %op930, ptr %slot165, align 8
  %v931 = load i64, ptr %slot159, align 8
  %p932 = inttoptr i64 %v931 to ptr
  %rgep933 = getelementptr i8, ptr %p932, i64 -32
  %ld934 = load i64, ptr %rgep933, align 8, !alias.scope !9, !noalias !10
  store i64 %ld934, ptr %slot166, align 8
  %v935 = load i64, ptr %slot166, align 8
  %op936 = add i64 %v935, 1
  store i64 %op936, ptr %slot167, align 8
  %v937 = load i64, ptr %slot167, align 8
  %cmp938 = icmp eq i64 %v937, 0
  %cv939 = zext i1 %cmp938 to i32
  store i32 %cv939, ptr %slot168, align 8
  %v940 = load i32, ptr %slot168, align 8
  %cv941 = zext i32 %v940 to i64
  %cond942 = icmp ne i64 %cv941, 0
  br i1 %cond942, label %bb_rcglimit181, label %bb_rcgcapacity181
bb_rcglimit181:
  %v943 = load i64, ptr %slot1, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %call945 = call i32 @myl_qbe_rc_status(ptr %p944, i32 2) nomerge, !dbg !116
  store i32 %call945, ptr %slot169, align 8
  br label %bb_failure
bb_rcgcapacity181:
  %v946 = load i64, ptr %slot167, align 8
  %v947 = load i64, ptr %slot159, align 8
  %p948 = inttoptr i64 %v947 to ptr
  %rgep949 = getelementptr i8, ptr %p948, i64 -32
  store i64 %v946, ptr %rgep949, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain181
bb_rcgspecial181:
  %v950 = load i64, ptr %slot162, align 8
  %op951 = and i64 %v950, 4611686018427387904
  store i64 %op951, ptr %slot170, align 8
  %v952 = load i64, ptr %slot170, align 8
  %cmp953 = icmp ne i64 %v952, 0
  %cv954 = zext i1 %cmp953 to i32
  store i32 %cv954, ptr %slot171, align 8
  %v955 = load i32, ptr %slot171, align 8
  %cv956 = zext i32 %v955 to i64
  %cond957 = icmp ne i64 %cv956, 0
  br i1 %cond957, label %bb_rcgslow181, label %bb_rcgplain181
bb_rcgslow181:
  %v958 = load i64, ptr %slot28, align 8
  %v959 = load i64, ptr %slot157, align 8
  %v960 = load i64, ptr %slot135, align 8
  %v961 = load i64, ptr %slot158, align 8
  %cv962 = trunc i64 %v961 to i32
  %call963 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v958, i64 %v959, i64 %v960, i32 %cv962) nomerge, !dbg !116
  store i32 %call963, ptr %slot172, align 8
  %v964 = load i32, ptr %slot172, align 8
  %cv965 = zext i32 %v964 to i64
  %cond966 = icmp ne i64 %cv965, 0
  br i1 %cond966, label %bb_rcsuccess195, label %bb_rcfailure195
bb_rcfailure195:
  %v967 = load i64, ptr %slot28, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %call969 = call i32 @myl_rc_take_failure(ptr %p968) nomerge, !dbg !116
  store i32 %call969, ptr %slot173, align 8
  %v970 = load i64, ptr %slot1, align 8
  %p971 = inttoptr i64 %v970 to ptr
  %v972 = load i32, ptr %slot173, align 8
  %call973 = call i32 @myl_qbe_rc_status(ptr %p971, i32 %v972) nomerge, !dbg !116
  store i32 %call973, ptr %slot174, align 8
  br label %bb_failure
bb_rcsuccess195:
  br label %bb_rcgdone181
bb_rcgplain181:
  %v974 = load i64, ptr %slot159, align 8
  %v975 = load i64, ptr %slot157, align 8
  %p976 = inttoptr i64 %v975 to ptr
  store i64 %v974, ptr %p976, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone181
bb_rcgdone181:
  %v977 = load i64, ptr %slot10, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i32 2, ptr %p978, align 4, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot9, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i32 1, ptr %p980, align 4, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot7, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %ld983 = load i32, ptr %p982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld983, ptr %slot175, align 8
  %v984 = load i32, ptr %slot175, align 8
  %cv985 = zext i32 %v984 to i64
  %cond986 = icmp ne i64 %cv985, 0
  br i1 %cond986, label %bb_rcslotdrop202, label %bb_rcslotdone202
bb_rcslotdrop202:
  %v987 = load i64, ptr %slot7, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i32 0, ptr %p988, align 4, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot13, align 8
  store i64 %v989, ptr %slot176, align 8
  %v990 = load i64, ptr %slot8, align 8
  %p991 = inttoptr i64 %v990 to ptr
  %ld992 = load i32, ptr %p991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld992, ptr %slot177, align 8
  %v993 = load i32, ptr %slot177, align 8
  %op994 = and i32 %v993, 28
  store i32 %op994, ptr %slot178, align 8
  %v995 = load i32, ptr %slot178, align 8
  %cv996 = zext i32 %v995 to i64
  %cond997 = icmp ne i64 %cv996, 0
  br i1 %cond997, label %bb_rcslotrole202, label %bb_rcslotowner202
bb_rcslotrole202:
  %v998 = load i64, ptr %slot28, align 8
  store i64 %v998, ptr %slot179, align 8
  %v999 = load i64, ptr %slot176, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  %ld1001 = load i64, ptr %p1000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1001, ptr %slot180, align 8
  %v1002 = load i64, ptr %slot180, align 8
  %cmp1003 = icmp ne i64 %v1002, 0
  %cv1004 = zext i1 %cmp1003 to i32
  store i32 %cv1004, ptr %slot181, align 8
  %v1005 = load i32, ptr %slot181, align 8
  %cv1006 = zext i32 %v1005 to i64
  %cond1007 = icmp ne i64 %cv1006, 0
  br i1 %cond1007, label %bb_rcgnn218, label %bb_rcgdone218
bb_rcgnn218:
  %v1008 = load i64, ptr %slot180, align 8
  %op1009 = sub i64 %v1008, 16
  store i64 %op1009, ptr %slot182, align 8
  %v1010 = load i64, ptr %slot180, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %rgep1012 = getelementptr i8, ptr %p1011, i64 -16
  %ld1013 = load i64, ptr %rgep1012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1013, ptr %slot183, align 8
  %v1014 = load i64, ptr %slot183, align 8
  %op1015 = and i64 %v1014, 4611686018427387906
  store i64 %op1015, ptr %slot184, align 8
  %v1016 = load i64, ptr %slot184, align 8
  %cmp1017 = icmp ne i64 %v1016, 0
  %cv1018 = zext i1 %cmp1017 to i32
  store i32 %cv1018, ptr %slot185, align 8
  %v1019 = load i32, ptr %slot185, align 8
  %cv1020 = zext i32 %v1019 to i64
  %cond1021 = icmp ne i64 %cv1020, 0
  br i1 %cond1021, label %bb_rcgclear218, label %bb_rcgcounted218
bb_rcgcounted218:
  %v1022 = load i64, ptr %slot180, align 8
  %op1023 = sub i64 %v1022, 24
  store i64 %op1023, ptr %slot186, align 8
  %v1024 = load i64, ptr %slot180, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %rgep1026 = getelementptr i8, ptr %p1025, i64 -24
  %ld1027 = load i64, ptr %rgep1026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1027, ptr %slot187, align 8
  %v1028 = load i64, ptr %slot187, align 8
  %op1029 = sub i64 %v1028, 1
  store i64 %op1029, ptr %slot188, align 8
  %v1030 = load i64, ptr %slot188, align 8
  %cmp1031 = icmp eq i64 %v1030, 0
  %cv1032 = zext i1 %cmp1031 to i32
  store i32 %cv1032, ptr %slot189, align 8
  %v1033 = load i32, ptr %slot189, align 8
  %cv1034 = zext i32 %v1033 to i64
  %cond1035 = icmp ne i64 %cv1034, 0
  br i1 %cond1035, label %bb_rcglast218, label %bb_rcgdec218
bb_rcglast218:
  %v1036 = load i64, ptr %slot180, align 8
  %op1037 = sub i64 %v1036, 32
  store i64 %op1037, ptr %slot190, align 8
  %v1038 = load i64, ptr %slot180, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %rgep1040 = getelementptr i8, ptr %p1039, i64 -32
  %ld1041 = load i64, ptr %rgep1040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1041, ptr %slot191, align 8
  %v1042 = load i64, ptr %slot191, align 8
  %cmp1043 = icmp ne i64 %v1042, 0
  %cv1044 = zext i1 %cmp1043 to i32
  store i32 %cv1044, ptr %slot192, align 8
  %v1045 = load i32, ptr %slot192, align 8
  %cv1046 = zext i32 %v1045 to i64
  %cond1047 = icmp ne i64 %cv1046, 0
  br i1 %cond1047, label %bb_rcgdec218, label %bb_rcgslow218
bb_rcgslow218:
  %v1048 = load i64, ptr %slot179, align 8
  %v1049 = load i64, ptr %slot176, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1048, i64 %v1049) nomerge, !dbg !116
  br label %bb_rcgdone218
bb_rcgdec218:
  %v1050 = load i64, ptr %slot188, align 8
  %v1051 = load i64, ptr %slot180, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %rgep1053 = getelementptr i8, ptr %p1052, i64 -24
  store i64 %v1050, ptr %rgep1053, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear218
bb_rcgclear218:
  %v1054 = load i64, ptr %slot176, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  store i64 0, ptr %p1055, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone218
bb_rcgdone218:
  br label %bb_rcslotdone202
bb_rcslotowner202:
  %v1056 = load i64, ptr %slot28, align 8
  store i64 %v1056, ptr %slot193, align 8
  %v1057 = load i64, ptr %slot176, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  %ld1059 = load i64, ptr %p1058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1059, ptr %slot194, align 8
  %v1060 = load i64, ptr %slot194, align 8
  %cmp1061 = icmp ne i64 %v1060, 0
  %cv1062 = zext i1 %cmp1061 to i32
  store i32 %cv1062, ptr %slot195, align 8
  %v1063 = load i32, ptr %slot195, align 8
  %cv1064 = zext i32 %v1063 to i64
  %cond1065 = icmp ne i64 %cv1064, 0
  br i1 %cond1065, label %bb_rcgnn233, label %bb_rcgdone233
bb_rcgnn233:
  %v1066 = load i64, ptr %slot194, align 8
  %op1067 = sub i64 %v1066, 16
  store i64 %op1067, ptr %slot196, align 8
  %v1068 = load i64, ptr %slot194, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  %rgep1070 = getelementptr i8, ptr %p1069, i64 -16
  %ld1071 = load i64, ptr %rgep1070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1071, ptr %slot197, align 8
  %v1072 = load i64, ptr %slot197, align 8
  %op1073 = and i64 %v1072, 4611686018427387906
  store i64 %op1073, ptr %slot198, align 8
  %v1074 = load i64, ptr %slot198, align 8
  %cmp1075 = icmp ne i64 %v1074, 0
  %cv1076 = zext i1 %cmp1075 to i32
  store i32 %cv1076, ptr %slot199, align 8
  %v1077 = load i32, ptr %slot199, align 8
  %cv1078 = zext i32 %v1077 to i64
  %cond1079 = icmp ne i64 %cv1078, 0
  br i1 %cond1079, label %bb_rcgclear233, label %bb_rcgcounted233
bb_rcgcounted233:
  %v1080 = load i64, ptr %slot194, align 8
  %op1081 = sub i64 %v1080, 32
  store i64 %op1081, ptr %slot200, align 8
  %v1082 = load i64, ptr %slot194, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  %rgep1084 = getelementptr i8, ptr %p1083, i64 -32
  %ld1085 = load i64, ptr %rgep1084, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1085, ptr %slot201, align 8
  %v1086 = load i64, ptr %slot201, align 8
  %op1087 = sub i64 %v1086, 1
  store i64 %op1087, ptr %slot202, align 8
  %v1088 = load i64, ptr %slot202, align 8
  %cmp1089 = icmp eq i64 %v1088, 0
  %cv1090 = zext i1 %cmp1089 to i32
  store i32 %cv1090, ptr %slot203, align 8
  %v1091 = load i32, ptr %slot203, align 8
  %cv1092 = zext i32 %v1091 to i64
  %cond1093 = icmp ne i64 %cv1092, 0
  br i1 %cond1093, label %bb_rcglast233, label %bb_rcgdec233
bb_rcglast233:
  %v1094 = load i64, ptr %slot194, align 8
  %op1095 = sub i64 %v1094, 24
  store i64 %op1095, ptr %slot204, align 8
  %v1096 = load i64, ptr %slot194, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  %rgep1098 = getelementptr i8, ptr %p1097, i64 -24
  %ld1099 = load i64, ptr %rgep1098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1099, ptr %slot205, align 8
  %v1100 = load i64, ptr %slot205, align 8
  %cmp1101 = icmp ne i64 %v1100, 0
  %cv1102 = zext i1 %cmp1101 to i32
  store i32 %cv1102, ptr %slot206, align 8
  %v1103 = load i32, ptr %slot206, align 8
  %cv1104 = zext i32 %v1103 to i64
  %cond1105 = icmp ne i64 %cv1104, 0
  br i1 %cond1105, label %bb_rcgdec233, label %bb_rcgslow233
bb_rcgslow233:
  %v1106 = load i64, ptr %slot193, align 8
  %v1107 = load i64, ptr %slot176, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1106, i64 %v1107) nomerge, !dbg !116
  br label %bb_rcgdone233
bb_rcgdec233:
  %v1108 = load i64, ptr %slot202, align 8
  %v1109 = load i64, ptr %slot194, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  %rgep1111 = getelementptr i8, ptr %p1110, i64 -32
  store i64 %v1108, ptr %rgep1111, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear233
bb_rcgclear233:
  %v1112 = load i64, ptr %slot176, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i64 0, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone233
bb_rcgdone233:
  br label %bb_rcslotdone202
bb_rcslotdone202:
  br label %bb_rcprepared148
bb_rcprepared148:
  %v1114 = load i64, ptr %slot16, align 8
  store i64 %v1114, ptr %slot207, align 8
  %v1115 = load i64, ptr %slot207, align 8
  %v1116 = load i64, ptr %slot133, align 8
  %p1117 = inttoptr i64 %v1115 to ptr
  %p1118 = inttoptr i64 %v1116 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1118, ptr %p1117, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot9, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  store i32 0, ptr %p1120, align 4, !alias.scope !3, !noalias !4
  %v1121 = load i64, ptr %slot20, align 8
  store i64 %v1121, ptr %slot208, align 8
  %v1122 = load i64, ptr %slot48, align 8
  %p1124 = inttoptr i64 %v1122 to ptr
  %gep1125 = getelementptr i8, ptr %p1124, i64 16
  %op1123 = ptrtoint ptr %gep1125 to i64
  store i64 %op1123, ptr %slot209, align 8
  %v1126 = load i64, ptr %slot208, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  %ld1128 = load i64, ptr %p1127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1128, ptr %slot210, align 8
  %v1129 = load i64, ptr %slot210, align 8
  %v1130 = load i64, ptr %slot209, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i64 %v1129, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot21, align 8
  store i64 %v1132, ptr %slot211, align 8
  %v1133 = load i64, ptr %slot48, align 8
  %p1135 = inttoptr i64 %v1133 to ptr
  %gep1136 = getelementptr i8, ptr %p1135, i64 24
  %op1134 = ptrtoint ptr %gep1136 to i64
  store i64 %op1134, ptr %slot212, align 8
  %v1137 = load i64, ptr %slot211, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %ld1139 = load i64, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1139, ptr %slot213, align 8
  %v1140 = load i64, ptr %slot213, align 8
  %v1141 = load i64, ptr %slot212, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i64 %v1140, ptr %p1142, align 8, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot22, align 8
  store i64 %v1143, ptr %slot214, align 8
  %v1144 = load i64, ptr %slot48, align 8
  %p1146 = inttoptr i64 %v1144 to ptr
  %gep1147 = getelementptr i8, ptr %p1146, i64 32
  %op1145 = ptrtoint ptr %gep1147 to i64
  store i64 %op1145, ptr %slot215, align 8
  %v1148 = load i64, ptr %slot214, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i8, ptr %p1149, align 1, !alias.scope !3, !noalias !4
  %ext1151 = zext i8 %ld1150 to i64
  store i64 %ext1151, ptr %slot216, align 8
  %v1152 = load i64, ptr %slot216, align 8
  %cv1153 = trunc i64 %v1152 to i8
  %v1154 = load i64, ptr %slot215, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i8 %cv1153, ptr %p1155, align 1, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot48, align 8
  %v1157 = load i64, ptr %slot18, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  store i64 %v1156, ptr %p1158, align 8, !alias.scope !3, !noalias !4
  %v1159 = load i64, ptr %slot18, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i64, ptr %p1160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1161, ptr %slot217, align 8
  %v1162 = load i64, ptr %slot12, align 8
  store i64 %v1162, ptr %slot218, align 8
  %v1163 = load i64, ptr %slot217, align 8
  %v1164 = load i64, ptr %slot218, align 8
  %p1165 = inttoptr i64 %v1163 to ptr
  %p1166 = inttoptr i64 %v1164 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1166, ptr %p1165, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot6, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i32 2, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot5, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 1, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot218, align 8
  %v1172 = load i64, ptr %slot18, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i64 %v1171, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot18, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot219, align 8
  %v1177 = load i64, ptr %slot18, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i64, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1179, ptr %slot220, align 8
  %v1180 = load i64, ptr %slot16, align 8
  store i64 %v1180, ptr %slot221, align 8
  %v1181 = load i64, ptr %slot29, align 8
  store i64 %v1181, ptr %slot222, align 8
  %v1182 = load i64, ptr %slot220, align 8
  %op1183 = add i64 %v1182, 0
  store i64 %op1183, ptr %slot223, align 8
  %v1184 = load i64, ptr %slot223, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  %ld1186 = load i64, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1186, ptr %slot224, align 8
  %v1187 = load i64, ptr %slot224, align 8
  %cmp1188 = icmp ne i64 %v1187, 0
  %cv1189 = zext i1 %cmp1188 to i32
  store i32 %cv1189, ptr %slot225, align 8
  %v1190 = load i32, ptr %slot225, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcmoveheader259, label %bb_rcmovenext259
bb_rcmoveheader259:
  %v1193 = load i64, ptr %slot224, align 8
  %op1194 = sub i64 %v1193, 16
  store i64 %op1194, ptr %slot226, align 8
  %v1195 = load i64, ptr %slot224, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %rgep1197 = getelementptr i8, ptr %p1196, i64 -16
  %ld1198 = load i64, ptr %rgep1197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1198, ptr %slot227, align 8
  %v1199 = load i64, ptr %slot227, align 8
  %op1200 = and i64 %v1199, 5764607523034234881
  store i64 %op1200, ptr %slot228, align 8
  %v1201 = load i64, ptr %slot228, align 8
  %cmp1202 = icmp ne i64 %v1201, 0
  %cv1203 = zext i1 %cmp1202 to i32
  store i32 %cv1203, ptr %slot229, align 8
  %v1204 = load i32, ptr %slot229, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcmoveslow256, label %bb_rcmovenext259
bb_rcmovenext259:
  %v1207 = load i64, ptr %slot220, align 8
  %op1208 = add i64 %v1207, 8
  store i64 %op1208, ptr %slot230, align 8
  %v1209 = load i64, ptr %slot230, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  %ld1211 = load i64, ptr %p1210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1211, ptr %slot231, align 8
  %v1212 = load i64, ptr %slot231, align 8
  %cmp1213 = icmp ne i64 %v1212, 0
  %cv1214 = zext i1 %cmp1213 to i32
  store i32 %cv1214, ptr %slot232, align 8
  %v1215 = load i32, ptr %slot232, align 8
  %cv1216 = zext i32 %v1215 to i64
  %cond1217 = icmp ne i64 %cv1216, 0
  br i1 %cond1217, label %bb_rcmoveheader267, label %bb_rcmovenext267
bb_rcmoveheader267:
  %v1218 = load i64, ptr %slot231, align 8
  %op1219 = sub i64 %v1218, 16
  store i64 %op1219, ptr %slot233, align 8
  %v1220 = load i64, ptr %slot231, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  %rgep1222 = getelementptr i8, ptr %p1221, i64 -16
  %ld1223 = load i64, ptr %rgep1222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1223, ptr %slot234, align 8
  %v1224 = load i64, ptr %slot234, align 8
  %op1225 = and i64 %v1224, 5764607523034234881
  store i64 %op1225, ptr %slot235, align 8
  %v1226 = load i64, ptr %slot235, align 8
  %cmp1227 = icmp ne i64 %v1226, 0
  %cv1228 = zext i1 %cmp1227 to i32
  store i32 %cv1228, ptr %slot236, align 8
  %v1229 = load i32, ptr %slot236, align 8
  %cv1230 = zext i32 %v1229 to i64
  %cond1231 = icmp ne i64 %cv1230, 0
  br i1 %cond1231, label %bb_rcmoveslow256, label %bb_rcmovenext267
bb_rcmovenext267:
  %v1232 = load i64, ptr %slot220, align 8
  %v1233 = load i64, ptr %slot221, align 8
  %p1234 = inttoptr i64 %v1232 to ptr
  %p1235 = inttoptr i64 %v1233 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1235, ptr %p1234, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot220, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i64 0, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot220, align 8
  %op1239 = add i64 %v1238, 8
  store i64 %op1239, ptr %slot237, align 8
  %v1240 = load i64, ptr %slot237, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i64 0, ptr %p1241, align 8, !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot220, align 8
  %op1243 = add i64 %v1242, 16
  store i64 %op1243, ptr %slot238, align 8
  %v1244 = load i64, ptr %slot238, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  store i64 0, ptr %p1245, align 8, !alias.scope !3, !noalias !4
  %v1246 = load i64, ptr %slot220, align 8
  %op1247 = add i64 %v1246, 24
  store i64 %op1247, ptr %slot239, align 8
  %v1248 = load i64, ptr %slot239, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i64 0, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot220, align 8
  %op1251 = add i64 %v1250, 32
  store i64 %op1251, ptr %slot240, align 8
  %v1252 = load i64, ptr %slot240, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  store i64 0, ptr %p1253, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved256
bb_rcmoveslow256:
  %v1254 = load i64, ptr %slot28, align 8
  %v1255 = load i64, ptr %slot221, align 8
  %v1256 = load i64, ptr %slot220, align 8
  %v1257 = load i64, ptr %slot222, align 8
  %cv1258 = trunc i64 %v1257 to i32
  %call1259 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v1254, i64 %v1255, i64 %v1256, i32 %cv1258) nomerge, !dbg !118
  store i32 %call1259, ptr %slot241, align 8
  %v1260 = load i32, ptr %slot241, align 8
  %cv1261 = zext i32 %v1260 to i64
  %cond1262 = icmp ne i64 %cv1261, 0
  br i1 %cond1262, label %bb_rcsuccess278, label %bb_rcfailure278
bb_rcfailure278:
  %v1263 = load i64, ptr %slot28, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %call1265 = call i32 @myl_rc_take_failure(ptr %p1264) nomerge, !dbg !118
  store i32 %call1265, ptr %slot242, align 8
  %v1266 = load i64, ptr %slot1, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %v1268 = load i32, ptr %slot242, align 8
  %call1269 = call i32 @myl_qbe_rc_status(ptr %p1267, i32 %v1268) nomerge, !dbg !118
  store i32 %call1269, ptr %slot243, align 8
  br label %bb_failure
bb_rcsuccess278:
  br label %bb_rcmoved256
bb_rcmoved256:
  %v1270 = load i64, ptr %slot5, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i32 0, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot10, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  store i32 2, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  %v1274 = load i64, ptr %slot9, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i32 1, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot16, align 8
  store i64 %v1276, ptr %slot244, align 8
  %v1277 = load i64, ptr %slot9, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  store i32 0, ptr %p1278, align 4, !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot5, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %ld1281 = load i32, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1281, ptr %slot245, align 8
  %v1282 = load i32, ptr %slot245, align 8
  %cv1283 = zext i32 %v1282 to i64
  %cond1284 = icmp ne i64 %cv1283, 0
  br i1 %cond1284, label %bb_rcslotdrop288, label %bb_rcslotdone288
bb_rcslotdrop288:
  %v1285 = load i64, ptr %slot5, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  store i32 0, ptr %p1286, align 4, !alias.scope !3, !noalias !4
  %v1287 = load i64, ptr %slot12, align 8
  store i64 %v1287, ptr %slot246, align 8
  %v1288 = load i64, ptr %slot6, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i32, ptr %p1289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1290, ptr %slot247, align 8
  %v1291 = load i32, ptr %slot247, align 8
  %op1292 = and i32 %v1291, 28
  store i32 %op1292, ptr %slot248, align 8
  %v1293 = load i32, ptr %slot248, align 8
  %cv1294 = zext i32 %v1293 to i64
  %cond1295 = icmp ne i64 %cv1294, 0
  br i1 %cond1295, label %bb_rcslotrole288, label %bb_rcslotowner288
bb_rcslotrole288:
  %v1296 = load i64, ptr %slot28, align 8
  store i64 %v1296, ptr %slot249, align 8
  %v1297 = load i64, ptr %slot249, align 8
  %v1298 = load i64, ptr %slot246, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1297, i64 %v1298) nomerge, !dbg !118
  br label %bb_rcslotdone288
bb_rcslotowner288:
  %v1299 = load i64, ptr %slot28, align 8
  store i64 %v1299, ptr %slot250, align 8
  %v1300 = load i64, ptr %slot250, align 8
  %v1301 = load i64, ptr %slot246, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1300, i64 %v1301) nomerge, !dbg !118
  br label %bb_rcslotdone288
bb_rcslotdone288:
  %v1302 = load i64, ptr %slot244, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1303, i64 40, i1 false)
  ret void
bb_failure:
  %v1304 = load i64, ptr %slot4, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  call void @llvm.memset.p0.i64(ptr %p1305, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v1306 = load i64, ptr %slot4, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1307, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v1308 = load i64, ptr %slot4, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  call void @llvm.memset.p0.i64(ptr %p1309, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v1310 = load i64, ptr %slot4, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1311, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770", linkageName: "myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3884025056867911587, i64 0, !"myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
