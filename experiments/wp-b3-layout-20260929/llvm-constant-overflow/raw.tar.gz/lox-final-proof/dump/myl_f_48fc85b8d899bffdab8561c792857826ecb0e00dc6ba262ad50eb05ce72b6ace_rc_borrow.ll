target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v52 = load i64, ptr %slot1, align 8
  %op53 = add i64 %v52, 32
  store i64 %op53, ptr %slot3, align 8
  %mem54 = alloca i8, i64 40, align 8
  %ptr55 = ptrtoint ptr %mem54 to i64
  store i64 %ptr55, ptr %slot4, align 8
  %mem56 = alloca i8, i64 8, align 8
  %ptr57 = ptrtoint ptr %mem56 to i64
  store i64 %ptr57, ptr %slot5, align 8
  %mem58 = alloca i8, i64 8, align 8
  %ptr59 = ptrtoint ptr %mem58 to i64
  store i64 %ptr59, ptr %slot6, align 8
  %mem60 = alloca i8, i64 8, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot7, align 8
  %mem62 = alloca i8, i64 8, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot8, align 8
  %mem64 = alloca i8, i64 8, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot9, align 8
  %v66 = load i64, ptr %slot6, align 8
  %p67 = inttoptr i64 %v66 to ptr
  store i64 0, ptr %p67, align 8, !alias.scope !3, !noalias !4
  %v68 = load i64, ptr %slot2, align 8
  %v69 = load i64, ptr %slot5, align 8
  %p70 = inttoptr i64 %v69 to ptr
  store i64 %v68, ptr %p70, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v71 = load i64, ptr %slot5, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !3, !noalias !4
  store i64 %ld73, ptr %slot10, align 8
  %v74 = load i64, ptr %slot10, align 8
  %v75 = load i64, ptr %slot8, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot8, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot11, align 8
  %v80 = load i64, ptr %slot11, align 8
  %op81 = add i64 %v80, 256
  store i64 %op81, ptr %slot12, align 8
  %v82 = load i64, ptr %slot12, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !4, !noalias !3
  store i64 %ld84, ptr %slot13, align 8
  %v85 = load i64, ptr %slot13, align 8
  %v86 = load i64, ptr %slot8, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot8, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot14, align 8
  %v91 = load i64, ptr %slot6, align 8
  store i64 %v91, ptr %slot15, align 8
  %v92 = load i64, ptr %slot14, align 8
  %v93 = load i64, ptr %slot15, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 %v92, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot5, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i64, ptr %p96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld97, ptr %slot16, align 8
  %v98 = load i64, ptr %slot16, align 8
  %v99 = load i64, ptr %slot8, align 8
  %p100 = inttoptr i64 %v99 to ptr
  store i64 %v98, ptr %p100, align 8, !alias.scope !3, !noalias !4
  %v101 = load i64, ptr %slot8, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld103, ptr %slot17, align 8
  %v104 = load i64, ptr %slot17, align 8
  %op105 = add i64 %v104, 264
  store i64 %op105, ptr %slot18, align 8
  %v106 = load i64, ptr %slot18, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !4, !noalias !3
  store i64 %ld108, ptr %slot19, align 8
  %v109 = load i64, ptr %slot19, align 8
  %v110 = load i64, ptr %slot8, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot8, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot20, align 8
  %v115 = load i64, ptr %slot7, align 8
  store i64 %v115, ptr %slot21, align 8
  %v116 = load i64, ptr %slot20, align 8
  %v117 = load i64, ptr %slot21, align 8
  %p118 = inttoptr i64 %v117 to ptr
  store i64 %v116, ptr %p118, align 8, !alias.scope !3, !noalias !4
  %v119 = load i64, ptr %slot7, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i64, ptr %p120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld121, ptr %slot22, align 8
  %v122 = load i64, ptr %slot22, align 8
  %v123 = load i64, ptr %slot8, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i64 %v122, ptr %p124, align 8, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot9, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 0, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot9, align 8
  %p128 = inttoptr i64 %v127 to ptr
  %ld129 = load i64, ptr %p128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot23, align 8
  %v130 = load i64, ptr %slot8, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %ld132 = load i64, ptr %p131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld132, ptr %slot24, align 8
  %v133 = load i64, ptr %slot24, align 8
  %v134 = load i64, ptr %slot23, align 8
  %cmp135 = icmp slt i64 %v133, %v134
  %cv136 = zext i1 %cmp135 to i64
  store i64 %cv136, ptr %slot25, align 8
  %v137 = load i64, ptr %slot25, align 8
  %v138 = load i64, ptr %slot8, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 %v137, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot8, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot26, align 8
  %v143 = load i64, ptr %slot26, align 8
  %cond144 = icmp ne i64 %v143, 0
  br i1 %cond144, label %bb_next19, label %bb_i15
bb_next19:
  %v145 = load i64, ptr %slot6, align 8
  %p146 = inttoptr i64 %v145 to ptr
  %ld147 = load i64, ptr %p146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld147, ptr %slot27, align 8
  %v148 = load i64, ptr %slot27, align 8
  %op149 = add i64 %v148, 0
  store i64 %op149, ptr %slot28, align 8
  %v150 = load i64, ptr %slot28, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !6, !noalias !7
  store i64 %ld152, ptr %slot29, align 8
  %v153 = load i64, ptr %slot29, align 8
  %v154 = load i64, ptr %slot8, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 %v153, ptr %p155, align 8, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot8, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot30, align 8
  %v159 = load i64, ptr %slot30, align 8
  %cmp160 = icmp ugt i64 %v159, 9223372036854775807
  %cv161 = zext i1 %cmp160 to i64
  store i64 %cv161, ptr %slot31, align 8
  %v162 = load i64, ptr %slot31, align 8
  %cond163 = icmp ne i64 %v162, 0
  br i1 %cond163, label %bb_cast_overflow24, label %bb_cast_ok24
bb_cast_overflow24:
  %v164 = load i64, ptr %slot1, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %v166 = load i64, ptr %slot30, align 8
  call void @myl_qbe_fail_cast(ptr %p165, i64 %v166, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok24:
  %v167 = load i64, ptr %slot30, align 8
  %v168 = load i64, ptr %slot8, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 %v167, ptr %p169, align 8, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot7, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld172, ptr %slot32, align 8
  %v173 = load i64, ptr %slot32, align 8
  %v174 = load i64, ptr %slot9, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 %v173, ptr %p175, align 8, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot9, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %ld178 = load i64, ptr %p177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld178, ptr %slot33, align 8
  %v179 = load i64, ptr %slot8, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot34, align 8
  %v182 = load i64, ptr %slot34, align 8
  %v183 = load i64, ptr %slot33, align 8
  %ovpair185 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v182, i64 %v183)
  %op184 = extractvalue { i64, i1 } %ovpair185, 0
  %ov186 = extractvalue { i64, i1 } %ovpair185, 1
  store i64 %op184, ptr %slot35, align 8
  %v187 = load i64, ptr %slot34, align 8
  %v188 = load i64, ptr %slot35, align 8
  %op189 = xor i64 %v187, %v188
  store i64 %op189, ptr %slot36, align 8
  %v190 = load i64, ptr %slot33, align 8
  %v191 = load i64, ptr %slot35, align 8
  %op192 = xor i64 %v190, %v191
  store i64 %op192, ptr %slot37, align 8
  %v193 = load i64, ptr %slot36, align 8
  %v194 = load i64, ptr %slot37, align 8
  %op195 = and i64 %v193, %v194
  store i64 %op195, ptr %slot38, align 8
  %cv196 = zext i1 %ov186 to i64
  store i64 %cv196, ptr %slot39, align 8
  %v197 = load i64, ptr %slot39, align 8
  %cond198 = icmp ne i64 %v197, 0
  br i1 %cond198, label %bb_overflow28, label %bb_checked28
bb_overflow28:
  %v199 = load i64, ptr %slot1, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %v201 = load i64, ptr %slot34, align 8
  %v202 = load i64, ptr %slot33, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p200, i64 0, i64 %v201, i64 %v202, i64 64) nomerge, !dbg !112
  unreachable
bb_checked28:
  %v203 = load i64, ptr %slot35, align 8
  %v204 = load i64, ptr %slot8, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot8, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot40, align 8
  %v209 = load i64, ptr %slot7, align 8
  store i64 %v209, ptr %slot41, align 8
  %v210 = load i64, ptr %slot40, align 8
  %v211 = load i64, ptr %slot41, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i64 %v210, ptr %p212, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v213 = load i64, ptr %slot7, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld215, ptr %slot42, align 8
  %v216 = load i64, ptr %slot42, align 8
  %v217 = load i64, ptr %slot8, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot6, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot43, align 8
  %v222 = load i64, ptr %slot8, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot44, align 8
  %v225 = load i64, ptr %slot43, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !6, !noalias !7
  store i64 %ld227, ptr %slot45, align 8
  %v228 = load i64, ptr %slot44, align 8
  %v229 = load i64, ptr %slot45, align 8
  %cmp230 = icmp ult i64 %v228, %v229
  %cv231 = zext i1 %cmp230 to i64
  store i64 %cv231, ptr %slot46, align 8
  %v232 = load i64, ptr %slot46, align 8
  %cond233 = icmp ne i64 %v232, 0
  br i1 %cond233, label %bb_success41, label %bb_failed41
bb_failed41:
  %v234 = load i64, ptr %slot1, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %v236 = load i64, ptr %slot44, align 8
  %v237 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p235, i64 %v236, i64 %v237) nomerge, !dbg !114
  unreachable
bb_success41:
  %v238 = load i64, ptr %slot43, align 8
  %op239 = add i64 %v238, 32
  store i64 %op239, ptr %slot47, align 8
  %v240 = load i64, ptr %slot47, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !6, !noalias !7
  store i64 %ld242, ptr %slot48, align 8
  %v243 = load i64, ptr %slot44, align 8
  %op244 = mul i64 %v243, 40
  store i64 %op244, ptr %slot49, align 8
  %v245 = load i64, ptr %slot48, align 8
  %v246 = load i64, ptr %slot49, align 8
  %op247 = add i64 %v245, %v246
  store i64 %op247, ptr %slot50, align 8
  %v248 = load i64, ptr %slot50, align 8
  %v249 = load i64, ptr %slot8, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot8, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot51, align 8
  %v254 = load i64, ptr %slot51, align 8
  %p255 = inttoptr i64 %v254 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p255, i64 40, i1 false)
  ret void
bb_failure:
  %v256 = load i64, ptr %slot4, align 8
  %p257 = inttoptr i64 %v256 to ptr
  call void @llvm.memset.p0.i64(ptr %p257, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v258 = load i64, ptr %slot4, align 8
  %p259 = inttoptr i64 %v258 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p259, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v260 = load i64, ptr %slot4, align 8
  %p261 = inttoptr i64 %v260 to ptr
  call void @llvm.memset.p0.i64(ptr %p261, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v262 = load i64, ptr %slot4, align 8
  %p263 = inttoptr i64 %v262 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p263, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow", linkageName: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16719617145510656701, i64 0, !"myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!110 = !DILocation(line: 12, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!112 = !DILocation(line: 14, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!114 = !DILocation(line: 17, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!116 = !DILocation(line: 18, column: 0, scope: !117)
