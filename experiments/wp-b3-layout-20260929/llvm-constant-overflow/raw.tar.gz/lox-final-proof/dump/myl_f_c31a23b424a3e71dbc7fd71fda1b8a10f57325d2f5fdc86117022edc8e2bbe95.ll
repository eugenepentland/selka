target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c31a23b424a3e71dbc7fd71fda1b8a10f57325d2f5fdc86117022edc8e2bbe95(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v42 = load i64, ptr %slot1, align 8
  %op43 = add i64 %v42, 32
  store i64 %op43, ptr %slot4, align 8
  %mem44 = alloca i8, i64 8, align 8
  %ptr45 = ptrtoint ptr %mem44 to i64
  store i64 %ptr45, ptr %slot5, align 8
  %mem46 = alloca i8, i64 8, align 8
  %ptr47 = ptrtoint ptr %mem46 to i64
  store i64 %ptr47, ptr %slot6, align 8
  %mem48 = alloca i8, i64 8, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot7, align 8
  %mem50 = alloca i8, i64 8, align 8
  %ptr51 = ptrtoint ptr %mem50 to i64
  store i64 %ptr51, ptr %slot8, align 8
  %mem52 = alloca i8, i64 8, align 8
  %ptr53 = ptrtoint ptr %mem52 to i64
  store i64 %ptr53, ptr %slot9, align 8
  %v54 = load i64, ptr %slot2, align 8
  %v55 = load i64, ptr %slot5, align 8
  %p56 = inttoptr i64 %v55 to ptr
  store i64 %v54, ptr %p56, align 8, !alias.scope !3, !noalias !4
  %v57 = load i64, ptr %slot3, align 8
  %v58 = load i64, ptr %slot6, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot1, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %call62 = call ptr @myl_qbe_heap(ptr %p61) nomerge, !dbg !110
  %calladdr63 = ptrtoint ptr %call62 to i64
  store i64 %calladdr63, ptr %slot10, align 8
  br label %bb_i0
bb_i0:
  %v64 = load i64, ptr %slot6, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i64, ptr %p65, align 8, !alias.scope !3, !noalias !4
  store i64 %ld66, ptr %slot11, align 8
  %v67 = load i64, ptr %slot11, align 8
  %v68 = load i64, ptr %slot7, align 8
  %p69 = inttoptr i64 %v68 to ptr
  store i64 %v67, ptr %p69, align 8, !alias.scope !3, !noalias !4
  %v70 = load i64, ptr %slot8, align 8
  %p71 = inttoptr i64 %v70 to ptr
  store i64 0, ptr %p71, align 8, !alias.scope !3, !noalias !4
  %v72 = load i64, ptr %slot6, align 8
  %p73 = inttoptr i64 %v72 to ptr
  %ld74 = load i64, ptr %p73, align 8, !alias.scope !3, !noalias !4
  store i64 %ld74, ptr %slot12, align 8
  %v75 = load i64, ptr %slot12, align 8
  %v76 = load i64, ptr %slot9, align 8
  %p77 = inttoptr i64 %v76 to ptr
  store i64 %v75, ptr %p77, align 8, !alias.scope !3, !noalias !4
  %v78 = load i64, ptr %slot9, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot13, align 8
  %v81 = load i64, ptr %slot13, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !6, !noalias !7
  store i64 %ld83, ptr %slot14, align 8
  %v84 = load i64, ptr %slot14, align 8
  %v85 = load i64, ptr %slot9, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  %v87 = load i64, ptr %slot5, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %ld89 = load i64, ptr %p88, align 8, !alias.scope !3, !noalias !4
  store i64 %ld89, ptr %slot15, align 8
  %v90 = load i64, ptr %slot7, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot16, align 8
  %v93 = load i64, ptr %slot8, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot17, align 8
  %v96 = load i64, ptr %slot9, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot18, align 8
  %v99 = load i64, ptr %slot15, align 8
  %op100 = add i64 %v99, 8
  store i64 %op100, ptr %slot19, align 8
  %v101 = load i64, ptr %slot17, align 8
  %cmp102 = icmp sge i64 %v101, 0
  %cv103 = zext i1 %cmp102 to i64
  store i64 %cv103, ptr %slot20, align 8
  %v104 = load i64, ptr %slot20, align 8
  %cond105 = icmp ne i64 %v104, 0
  br i1 %cond105, label %bb_buf_start48, label %bb_buf_refused48
bb_buf_start48:
  %v106 = load i64, ptr %slot17, align 8
  %v107 = load i64, ptr %slot18, align 8
  %cmp108 = icmp sle i64 %v106, %v107
  %cv109 = zext i1 %cmp108 to i64
  store i64 %cv109, ptr %slot21, align 8
  %v110 = load i64, ptr %slot21, align 8
  %cond111 = icmp ne i64 %v110, 0
  br i1 %cond111, label %bb_buf_order48, label %bb_buf_refused48
bb_buf_order48:
  %v112 = load i64, ptr %slot16, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !6, !noalias !7
  store i64 %ld114, ptr %slot22, align 8
  %v115 = load i64, ptr %slot18, align 8
  %v116 = load i64, ptr %slot22, align 8
  %cmp117 = icmp ule i64 %v115, %v116
  %cv118 = zext i1 %cmp117 to i64
  store i64 %cv118, ptr %slot23, align 8
  %v119 = load i64, ptr %slot23, align 8
  %cond120 = icmp ne i64 %v119, 0
  br i1 %cond120, label %bb_buf_bound48, label %bb_buf_refused48
bb_buf_bound48:
  %v121 = load i64, ptr %slot15, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !6, !noalias !7
  store i64 %ld123, ptr %slot24, align 8
  %v124 = load i64, ptr %slot19, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !6, !noalias !7
  store i64 %ld126, ptr %slot25, align 8
  %v127 = load i64, ptr %slot18, align 8
  %v128 = load i64, ptr %slot17, align 8
  %op129 = sub i64 %v127, %v128
  store i64 %op129, ptr %slot26, align 8
  %v130 = load i64, ptr %slot25, align 8
  %v131 = load i64, ptr %slot24, align 8
  %op132 = sub i64 %v130, %v131
  store i64 %op132, ptr %slot27, align 8
  %v133 = load i64, ptr %slot26, align 8
  %v134 = load i64, ptr %slot27, align 8
  %cmp135 = icmp ult i64 %v133, %v134
  %cv136 = zext i1 %cmp135 to i64
  store i64 %cv136, ptr %slot28, align 8
  %v137 = load i64, ptr %slot28, align 8
  %cond138 = icmp ne i64 %v137, 0
  br i1 %cond138, label %bb_buf_fast48, label %bb_buf_slow48
bb_buf_slow48:
  %v139 = load i64, ptr %slot10, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %v141 = load i64, ptr %slot15, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %v143 = load i64, ptr %slot16, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %v145 = load i64, ptr %slot17, align 8
  %v146 = load i64, ptr %slot18, align 8
  %call147 = call i32 @myl_native_bytes_buffer_append_range(ptr %p140, ptr %p142, ptr %p144, i64 %v145, i64 %v146) nomerge, !dbg !112
  store i32 %call147, ptr %slot29, align 8
  %v148 = load i32, ptr %slot29, align 8
  %ext149 = zext i32 %v148 to i64
  store i64 %ext149, ptr %slot30, align 8
  %v150 = load i64, ptr %slot30, align 8
  %cmp151 = icmp ne i64 %v150, 0
  %cv152 = zext i1 %cmp151 to i64
  store i64 %cv152, ptr %slot31, align 8
  %v153 = load i64, ptr %slot31, align 8
  %cond154 = icmp ne i64 %v153, 0
  br i1 %cond154, label %bb_success62, label %bb_failed62
bb_failed62:
  %v155 = load i64, ptr %slot1, align 8
  %p156 = inttoptr i64 %v155 to ptr
  call void @myl_qbe_fail_allocation(ptr %p156) nomerge, !dbg !112
  unreachable
bb_success62:
  %v157 = load i32, ptr %slot29, align 8
  %cmp158 = icmp eq i32 %v157, 1
  %cv159 = zext i1 %cmp158 to i32
  store i32 %cv159, ptr %slot32, align 8
  %v160 = load i32, ptr %slot32, align 8
  %ext161 = zext i32 %v160 to i64
  store i64 %ext161, ptr %slot33, align 8
  %v162 = load i64, ptr %slot33, align 8
  %v163 = load i64, ptr %slot7, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done48
bb_buf_fast48:
  %v165 = load i64, ptr %slot15, align 8
  %op166 = add i64 %v165, 32
  store i64 %op166, ptr %slot34, align 8
  %v167 = load i64, ptr %slot16, align 8
  %op168 = add i64 %v167, 32
  store i64 %op168, ptr %slot35, align 8
  %v169 = load i64, ptr %slot34, align 8
  %p170 = inttoptr i64 %v169 to ptr
  %ld171 = load i64, ptr %p170, align 8, !alias.scope !6, !noalias !7
  store i64 %ld171, ptr %slot36, align 8
  %v172 = load i64, ptr %slot36, align 8
  %v173 = load i64, ptr %slot24, align 8
  %op174 = add i64 %v172, %v173
  store i64 %op174, ptr %slot37, align 8
  %v175 = load i64, ptr %slot35, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !6, !noalias !7
  store i64 %ld177, ptr %slot38, align 8
  %v178 = load i64, ptr %slot38, align 8
  %v179 = load i64, ptr %slot17, align 8
  %op180 = add i64 %v178, %v179
  store i64 %op180, ptr %slot39, align 8
  %v181 = load i64, ptr %slot37, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %v183 = load i64, ptr %slot39, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %v185 = load i64, ptr %slot26, align 8
  call void @myl_native_bytes_copy_octets(ptr %p182, ptr %p184, i64 %v185) nomerge, !dbg !112
  %v186 = load i64, ptr %slot24, align 8
  %v187 = load i64, ptr %slot26, align 8
  %op188 = add i64 %v186, %v187
  store i64 %op188, ptr %slot40, align 8
  %v189 = load i64, ptr %slot40, align 8
  %v190 = load i64, ptr %slot15, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 %v189, ptr %p191, align 8, !alias.scope !6, !noalias !7
  %v192 = load i64, ptr %slot7, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 1, ptr %p193, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done48
bb_buf_refused48:
  %v194 = load i64, ptr %slot7, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done48
bb_buf_done48:
  %v196 = load i64, ptr %slot7, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 0, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot7, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot41, align 8
  %v201 = load i64, ptr %slot41, align 8
  ret i64 %v201
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare i32 @myl_native_bytes_buffer_append_range(ptr, ptr, ptr, i64, i64)
declare void @myl_native_bytes_copy_octets(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c31a23b424a3e71dbc7fd71fda1b8a10f57325d2f5fdc86117022edc8e2bbe95", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c31a23b424a3e71dbc7fd71fda1b8a10f57325d2f5fdc86117022edc8e2bbe95", linkageName: "myl_f_c31a23b424a3e71dbc7fd71fda1b8a10f57325d2f5fdc86117022edc8e2bbe95", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4186987497696134971, i64 0, !"myl_f_c31a23b424a3e71dbc7fd71fda1b8a10f57325d2f5fdc86117022edc8e2bbe95"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
