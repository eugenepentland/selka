target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow(ptr sret([32 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v22 = load i64, ptr %slot1, align 8
  %op23 = add i64 %v22, 32
  store i64 %op23, ptr %slot3, align 8
  %mem24 = alloca i8, i64 32, align 8
  %ptr25 = ptrtoint ptr %mem24 to i64
  store i64 %ptr25, ptr %slot4, align 8
  %mem26 = alloca i8, i64 8, align 8
  %ptr27 = ptrtoint ptr %mem26 to i64
  store i64 %ptr27, ptr %slot5, align 8
  %mem28 = alloca i8, i64 8, align 8
  %ptr29 = ptrtoint ptr %mem28 to i64
  store i64 %ptr29, ptr %slot6, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot7, align 8
  %mem32 = alloca i8, i64 8, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot8, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot9, align 8
  %mem36 = alloca i8, i64 32, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot10, align 8
  %v38 = load i64, ptr %slot2, align 8
  %v39 = load i64, ptr %slot5, align 8
  %p40 = inttoptr i64 %v39 to ptr
  store i64 %v38, ptr %p40, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v41 = load i64, ptr %slot5, align 8
  %p42 = inttoptr i64 %v41 to ptr
  %ld43 = load i64, ptr %p42, align 8, !alias.scope !3, !noalias !4
  store i64 %ld43, ptr %slot11, align 8
  %v44 = load i64, ptr %slot11, align 8
  %v45 = load i64, ptr %slot6, align 8
  %p46 = inttoptr i64 %v45 to ptr
  store i64 %v44, ptr %p46, align 8, !alias.scope !3, !noalias !4
  %v47 = load i64, ptr %slot7, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 0, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot8, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 0, ptr %p50, align 8, !alias.scope !3, !noalias !4
  %v51 = load i64, ptr %slot9, align 8
  %p52 = inttoptr i64 %v51 to ptr
  store i64 1, ptr %p52, align 8, !alias.scope !3, !noalias !4
  %v53 = load i64, ptr %slot10, align 8
  store i64 %v53, ptr %slot12, align 8
  %v54 = load i64, ptr %slot12, align 8
  %p56 = inttoptr i64 %v54 to ptr
  %gep57 = getelementptr i8, ptr %p56, i64 0
  %op55 = ptrtoint ptr %gep57 to i64
  store i64 %op55, ptr %slot13, align 8
  %v58 = load i64, ptr %slot6, align 8
  %p59 = inttoptr i64 %v58 to ptr
  %ld60 = load i64, ptr %p59, align 8, !alias.scope !3, !noalias !4
  store i64 %ld60, ptr %slot14, align 8
  %v61 = load i64, ptr %slot14, align 8
  %v62 = load i64, ptr %slot13, align 8
  %p63 = inttoptr i64 %v62 to ptr
  store i64 %v61, ptr %p63, align 8, !alias.scope !3, !noalias !4
  %v64 = load i64, ptr %slot12, align 8
  %p66 = inttoptr i64 %v64 to ptr
  %gep67 = getelementptr i8, ptr %p66, i64 8
  %op65 = ptrtoint ptr %gep67 to i64
  store i64 %op65, ptr %slot15, align 8
  %v68 = load i64, ptr %slot7, align 8
  %p69 = inttoptr i64 %v68 to ptr
  %ld70 = load i64, ptr %p69, align 8, !alias.scope !3, !noalias !4
  store i64 %ld70, ptr %slot16, align 8
  %v71 = load i64, ptr %slot16, align 8
  %v72 = load i64, ptr %slot15, align 8
  %p73 = inttoptr i64 %v72 to ptr
  store i64 %v71, ptr %p73, align 8, !alias.scope !3, !noalias !4
  %v74 = load i64, ptr %slot12, align 8
  %p76 = inttoptr i64 %v74 to ptr
  %gep77 = getelementptr i8, ptr %p76, i64 16
  %op75 = ptrtoint ptr %gep77 to i64
  store i64 %op75, ptr %slot17, align 8
  %v78 = load i64, ptr %slot8, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot18, align 8
  %v81 = load i64, ptr %slot18, align 8
  %v82 = load i64, ptr %slot17, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 %v81, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot12, align 8
  %p86 = inttoptr i64 %v84 to ptr
  %gep87 = getelementptr i8, ptr %p86, i64 24
  %op85 = ptrtoint ptr %gep87 to i64
  store i64 %op85, ptr %slot19, align 8
  %v88 = load i64, ptr %slot9, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot20, align 8
  %v91 = load i64, ptr %slot20, align 8
  %v92 = load i64, ptr %slot19, align 8
  %p93 = inttoptr i64 %v92 to ptr
  store i64 %v91, ptr %p93, align 8, !alias.scope !3, !noalias !4
  %v94 = load i64, ptr %slot12, align 8
  %v95 = load i64, ptr %slot6, align 8
  %p96 = inttoptr i64 %v95 to ptr
  store i64 %v94, ptr %p96, align 8, !alias.scope !3, !noalias !4
  %v97 = load i64, ptr %slot6, align 8
  %p98 = inttoptr i64 %v97 to ptr
  %ld99 = load i64, ptr %p98, align 8, !alias.scope !3, !noalias !4
  store i64 %ld99, ptr %slot21, align 8
  %v100 = load i64, ptr %slot21, align 8
  %p101 = inttoptr i64 %v100 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p101, i64 32, i1 false)
  ret void
bb_failure:
  %v102 = load i64, ptr %slot4, align 8
  %p103 = inttoptr i64 %v102 to ptr
  call void @llvm.memset.p0.i64(ptr %p103, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v104 = load i64, ptr %slot4, align 8
  %p105 = inttoptr i64 %v104 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p105, i64 32, i1 false)
  ret void
bb_entry_failure:
  %v106 = load i64, ptr %slot4, align 8
  %p107 = inttoptr i64 %v106 to ptr
  call void @llvm.memset.p0.i64(ptr %p107, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v108 = load i64, ptr %slot4, align 8
  %p109 = inttoptr i64 %v108 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p109, i64 32, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow", linkageName: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7077964188072026064, i64 0, !"myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!110 = !DILocation(line: 6, column: 0, scope: !111)
