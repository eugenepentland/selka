target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v16 = load i64, ptr %slot1, align 8
  %op17 = add i64 %v16, 32
  store i64 %op17, ptr %slot3, align 8
  %mem18 = alloca i8, i64 8, align 8
  %ptr19 = ptrtoint ptr %mem18 to i64
  store i64 %ptr19, ptr %slot4, align 8
  %mem20 = alloca i8, i64 8, align 8
  %ptr21 = ptrtoint ptr %mem20 to i64
  store i64 %ptr21, ptr %slot5, align 8
  %mem22 = alloca i8, i64 8, align 8
  %ptr23 = ptrtoint ptr %mem22 to i64
  store i64 %ptr23, ptr %slot6, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem24 = alloca i8, i64 8, align 8
  %ptr25 = ptrtoint ptr %mem24 to i64
  store i64 %ptr25, ptr %slot7, align 8
  %v26 = load i64, ptr %slot1, align 8
  %op27 = add i64 %v26, 64
  store i64 %op27, ptr %slot8, align 8
  %v28 = load i64, ptr %slot8, align 8
  %p29 = inttoptr i64 %v28 to ptr
  %ld30 = load i64, ptr %p29, align 8, !alias.scope !4, !noalias !3
  store i64 %ld30, ptr %slot9, align 8
  %stack31 = call ptr @llvm.stacksave()
  %stackaddr32 = ptrtoint ptr %stack31 to i64
  %v33 = load i64, ptr %slot9, align 8
  %cmp34 = icmp ult i64 %stackaddr32, %v33
  %cv35 = zext i1 %cmp34 to i64
  store i64 %cv35, ptr %slot10, align 8
  %v36 = load i64, ptr %slot10, align 8
  %cond37 = icmp ne i64 %v36, 0
  br i1 %cond37, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v38 = load i64, ptr %slot1, align 8
  %p39 = inttoptr i64 %v38 to ptr
  call void @myl_qbe_fail_frame(ptr %p39) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v40 = load i64, ptr %slot2, align 8
  %v41 = load i64, ptr %slot4, align 8
  %p42 = inttoptr i64 %v41 to ptr
  store i64 %v40, ptr %p42, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v43 = load i64, ptr %slot4, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !3, !noalias !4
  store i64 %ld45, ptr %slot11, align 8
  %v46 = load i64, ptr %slot11, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot6, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 1, ptr %p50, align 8, !alias.scope !3, !noalias !4
  %v51 = load i64, ptr %slot5, align 8
  %p52 = inttoptr i64 %v51 to ptr
  %ld53 = load i64, ptr %p52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld53, ptr %slot12, align 8
  %v54 = load i64, ptr %slot6, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !3, !noalias !4
  store i64 %ld56, ptr %slot13, align 8
  %v57 = load i64, ptr %slot1, align 8
  %v58 = load i64, ptr %slot12, align 8
  %v59 = load i64, ptr %slot13, align 8
  %call60 = call i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64 %v57, i64 %v58, i64 %v59) nomerge, !dbg !112
  store i64 %call60, ptr %slot14, align 8
  %v61 = load i64, ptr %slot14, align 8
  %v62 = load i64, ptr %slot5, align 8
  %p63 = inttoptr i64 %v62 to ptr
  store i64 %v61, ptr %p63, align 8, !alias.scope !3, !noalias !4
  %v64 = load i64, ptr %slot5, align 8
  %p65 = inttoptr i64 %v64 to ptr
  store i64 0, ptr %p65, align 8, !alias.scope !3, !noalias !4
  %v66 = load i64, ptr %slot5, align 8
  %p67 = inttoptr i64 %v66 to ptr
  %ld68 = load i64, ptr %p67, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot15, align 8
  %v69 = load i64, ptr %slot15, align 8
  ret i64 %v69
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65", linkageName: "myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11804701586486033781, i64 0, !"myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
