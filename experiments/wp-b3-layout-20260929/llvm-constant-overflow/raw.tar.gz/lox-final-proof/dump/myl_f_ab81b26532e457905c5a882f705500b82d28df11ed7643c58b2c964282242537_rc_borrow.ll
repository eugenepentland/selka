target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %callresult18 = alloca [16 x i8], align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v23 = load i64, ptr %slot1, align 8
  %op24 = add i64 %v23, 32
  store i64 %op24, ptr %slot4, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot5, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot6, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot7, align 8
  %mem31 = alloca i8, i64 8, align 8
  %ptr32 = ptrtoint ptr %mem31 to i64
  store i64 %ptr32, ptr %slot8, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot9, align 8
  %v35 = load i64, ptr %slot1, align 8
  %op36 = add i64 %v35, 64
  store i64 %op36, ptr %slot10, align 8
  %v37 = load i64, ptr %slot10, align 8
  %p38 = inttoptr i64 %v37 to ptr
  %ld39 = load i64, ptr %p38, align 8, !alias.scope !4, !noalias !3
  store i64 %ld39, ptr %slot11, align 8
  %stack40 = call ptr @llvm.stacksave()
  %stackaddr41 = ptrtoint ptr %stack40 to i64
  %v42 = load i64, ptr %slot11, align 8
  %cmp43 = icmp ult i64 %stackaddr41, %v42
  %cv44 = zext i1 %cmp43 to i64
  store i64 %cv44, ptr %slot12, align 8
  %v45 = load i64, ptr %slot12, align 8
  %cond46 = icmp ne i64 %v45, 0
  br i1 %cond46, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v47 = load i64, ptr %slot1, align 8
  %p48 = inttoptr i64 %v47 to ptr
  call void @myl_qbe_fail_frame(ptr %p48) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v49 = load i64, ptr %slot2, align 8
  %v50 = load i64, ptr %slot5, align 8
  %p51 = inttoptr i64 %v50 to ptr
  store i64 %v49, ptr %p51, align 8, !alias.scope !3, !noalias !4
  %v52 = load i64, ptr %slot3, align 8
  %v53 = load i64, ptr %slot6, align 8
  %p54 = inttoptr i64 %v53 to ptr
  store i64 %v52, ptr %p54, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v55 = load i64, ptr %slot5, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %ld57 = load i64, ptr %p56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld57, ptr %slot13, align 8
  %v58 = load i64, ptr %slot13, align 8
  %v59 = load i64, ptr %slot7, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 %v58, ptr %p60, align 8, !alias.scope !3, !noalias !4
  %v61 = load i64, ptr %slot6, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot14, align 8
  %v64 = load i64, ptr %slot14, align 8
  %v65 = load i64, ptr %slot8, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 %v64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot7, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot15, align 8
  %v70 = load i64, ptr %slot8, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !3, !noalias !4
  store i64 %ld72, ptr %slot16, align 8
  %v73 = load i64, ptr %slot1, align 8
  %v74 = load i64, ptr %slot15, align 8
  %v75 = load i64, ptr %slot16, align 8
  %call76 = call { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %v73, i64 %v74, i64 %v75) nomerge, !dbg !112
  store { i64, i64 } %call76, ptr %callresult18, align 8
  %addr77 = ptrtoint ptr %callresult18 to i64
  store i64 %addr77, ptr %slot17, align 8
  %v78 = load i64, ptr %slot17, align 8
  %v79 = load i64, ptr %slot7, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot7, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot19, align 8
  %v84 = load i64, ptr %slot19, align 8
  %op85 = add i64 %v84, 0
  store i64 %op85, ptr %slot20, align 8
  %v86 = load i64, ptr %slot20, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %ld88 = load i64, ptr %p87, align 8
  store i64 %ld88, ptr %slot21, align 8
  %v89 = load i64, ptr %slot21, align 8
  %v90 = load i64, ptr %slot7, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 %v89, ptr %p91, align 8, !alias.scope !3, !noalias !4
  %v92 = load i64, ptr %slot7, align 8
  %p93 = inttoptr i64 %v92 to ptr
  %ld94 = load i64, ptr %p93, align 8, !alias.scope !3, !noalias !4
  store i64 %ld94, ptr %slot22, align 8
  %v95 = load i64, ptr %slot22, align 8
  ret i64 %v95
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow", linkageName: "myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4167595456290290296, i64 0, !"myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
