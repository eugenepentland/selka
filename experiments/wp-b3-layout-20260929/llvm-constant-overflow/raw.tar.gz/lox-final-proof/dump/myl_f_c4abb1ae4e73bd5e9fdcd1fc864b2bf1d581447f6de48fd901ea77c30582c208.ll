target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208(ptr sret([48 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %callresult209 = alloca [48 x i8], align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %callresult257 = alloca [48 x i8], align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %callresult305 = alloca [48 x i8], align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %callresult353 = alloca [48 x i8], align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %callresult401 = alloca [48 x i8], align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %callresult449 = alloca [48 x i8], align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %callresult497 = alloca [48 x i8], align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %callresult545 = alloca [48 x i8], align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %callresult593 = alloca [48 x i8], align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %callresult641 = alloca [48 x i8], align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v687 = load i64, ptr %slot1, align 8
  %op688 = add i64 %v687, 32
  store i64 %op688, ptr %slot4, align 8
  %mem689 = alloca i8, i64 48, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot5, align 8
  %mem691 = alloca i8, i64 8, align 8
  %ptr692 = ptrtoint ptr %mem691 to i64
  store i64 %ptr692, ptr %slot6, align 8
  %mem693 = alloca i8, i64 8, align 8
  %ptr694 = ptrtoint ptr %mem693 to i64
  store i64 %ptr694, ptr %slot7, align 8
  %mem695 = alloca i8, i64 8, align 8
  %ptr696 = ptrtoint ptr %mem695 to i64
  store i64 %ptr696, ptr %slot8, align 8
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot9, align 8
  %mem699 = alloca i8, i64 208, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot10, align 8
  %mem701 = alloca i8, i64 208, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot11, align 8
  %mem703 = alloca i8, i64 8, align 8
  %ptr704 = ptrtoint ptr %mem703 to i64
  store i64 %ptr704, ptr %slot12, align 8
  %mem705 = alloca i8, i64 8, align 8
  %ptr706 = ptrtoint ptr %mem705 to i64
  store i64 %ptr706, ptr %slot13, align 8
  %mem707 = alloca i8, i64 8, align 8
  %ptr708 = ptrtoint ptr %mem707 to i64
  store i64 %ptr708, ptr %slot14, align 8
  %mem709 = alloca i8, i64 8, align 8
  %ptr710 = ptrtoint ptr %mem709 to i64
  store i64 %ptr710, ptr %slot15, align 8
  %mem711 = alloca i8, i64 48, align 8
  %ptr712 = ptrtoint ptr %mem711 to i64
  store i64 %ptr712, ptr %slot16, align 8
  %mem713 = alloca i8, i64 8, align 8
  %ptr714 = ptrtoint ptr %mem713 to i64
  store i64 %ptr714, ptr %slot17, align 8
  %mem715 = alloca i8, i64 8, align 8
  %ptr716 = ptrtoint ptr %mem715 to i64
  store i64 %ptr716, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem717 = alloca i8, i64 8, align 8
  %ptr718 = ptrtoint ptr %mem717 to i64
  store i64 %ptr718, ptr %slot19, align 8
  %v719 = load i64, ptr %slot1, align 8
  %op720 = add i64 %v719, 64
  store i64 %op720, ptr %slot20, align 8
  %v721 = load i64, ptr %slot20, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i64, ptr %p722, align 8, !alias.scope !4, !noalias !3
  store i64 %ld723, ptr %slot21, align 8
  %stack724 = call ptr @llvm.stacksave()
  %stackaddr725 = ptrtoint ptr %stack724 to i64
  %v726 = load i64, ptr %slot21, align 8
  %cmp727 = icmp ult i64 %stackaddr725, %v726
  %cv728 = zext i1 %cmp727 to i64
  store i64 %cv728, ptr %slot22, align 8
  %v729 = load i64, ptr %slot22, align 8
  %cond730 = icmp ne i64 %v729, 0
  br i1 %cond730, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v731 = load i64, ptr %slot1, align 8
  %p732 = inttoptr i64 %v731 to ptr
  call void @myl_qbe_fail_frame(ptr %p732) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v733 = load i64, ptr %slot14, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 0, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot2, align 8
  %v736 = load i64, ptr %slot12, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i64 %v735, ptr %p737, align 8, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot3, align 8
  %v739 = load i64, ptr %slot13, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i64 %v738, ptr %p740, align 8, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot1, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %call743 = call ptr @myl_qbe_heap(ptr %p742) nomerge, !dbg !112
  %calladdr744 = ptrtoint ptr %call743 to i64
  store i64 %calladdr744, ptr %slot23, align 8
  %v745 = load i64, ptr %slot1, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %call747 = call i64 @myl_qbe_region_mark(ptr %p746) nomerge, !dbg !112
  store i64 %call747, ptr %slot24, align 8
  %v748 = load i64, ptr %slot6, align 8
  %p749 = inttoptr i64 %v748 to ptr
  store i32 0, ptr %p749, align 4, !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot7, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i32 0, ptr %p751, align 4, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot8, align 8
  %p753 = inttoptr i64 %v752 to ptr
  store i32 0, ptr %p753, align 4, !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot9, align 8
  %p755 = inttoptr i64 %v754 to ptr
  store i32 0, ptr %p755, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v756 = load i64, ptr %slot12, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %ld758 = load i64, ptr %p757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld758, ptr %slot25, align 8
  %v759 = load i64, ptr %slot25, align 8
  %v760 = load i64, ptr %slot17, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i64 %v759, ptr %p761, align 8, !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot17, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %ld764 = load i64, ptr %p763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld764, ptr %slot26, align 8
  %v765 = load i64, ptr %slot26, align 8
  %op766 = add i64 %v765, 0
  store i64 %op766, ptr %slot27, align 8
  %v767 = load i64, ptr %slot27, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i64, ptr %p768, align 8, !alias.scope !4, !noalias !3
  store i64 %ld769, ptr %slot28, align 8
  %v770 = load i64, ptr %slot28, align 8
  %v771 = load i64, ptr %slot17, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i64 %v770, ptr %p772, align 8, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot6, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %ld775 = load i32, ptr %p774, align 4, !alias.scope !3, !noalias !4
  store i32 %ld775, ptr %slot29, align 8
  %v776 = load i32, ptr %slot29, align 8
  %cv777 = zext i32 %v776 to i64
  %cond778 = icmp ne i64 %cv777, 0
  br i1 %cond778, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v779 = load i64, ptr %slot6, align 8
  %p780 = inttoptr i64 %v779 to ptr
  store i32 0, ptr %p780, align 4, !alias.scope !3, !noalias !4
  %v781 = load i64, ptr %slot10, align 8
  store i64 %v781, ptr %slot30, align 8
  %v782 = load i64, ptr %slot7, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %ld784 = load i32, ptr %p783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld784, ptr %slot31, align 8
  %v785 = load i32, ptr %slot31, align 8
  %op786 = and i32 %v785, 28
  store i32 %op786, ptr %slot32, align 8
  %v787 = load i32, ptr %slot32, align 8
  %cv788 = zext i32 %v787 to i64
  %cond789 = icmp ne i64 %cv788, 0
  br i1 %cond789, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v790 = load i64, ptr %slot23, align 8
  store i64 %v790, ptr %slot33, align 8
  %v791 = load i64, ptr %slot33, align 8
  %v792 = load i64, ptr %slot30, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v791, i64 %v792) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v793 = load i64, ptr %slot23, align 8
  store i64 %v793, ptr %slot34, align 8
  %v794 = load i64, ptr %slot34, align 8
  %v795 = load i64, ptr %slot30, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v794, i64 %v795) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v796 = load i64, ptr %slot17, align 8
  %p797 = inttoptr i64 %v796 to ptr
  %ld798 = load i64, ptr %p797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld798, ptr %slot35, align 8
  %v799 = load i64, ptr %slot35, align 8
  %v800 = load i64, ptr %slot14, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i64 %v799, ptr %p801, align 8, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot13, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i64, ptr %p803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld804, ptr %slot36, align 8
  %v805 = load i64, ptr %slot36, align 8
  %v806 = load i64, ptr %slot17, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i64 %v805, ptr %p807, align 8, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot17, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot37, align 8
  %v811 = load i64, ptr %slot37, align 8
  %v812 = load i64, ptr %slot15, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i64 %v811, ptr %p813, align 8, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot15, align 8
  %p815 = inttoptr i64 %v814 to ptr
  %ld816 = load i64, ptr %p815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld816, ptr %slot38, align 8
  %v817 = load i64, ptr %slot38, align 8
  %v818 = load i64, ptr %slot17, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i64 %v817, ptr %p819, align 8, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot18, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 0, ptr %p821, align 8, !alias.scope !3, !noalias !4
  %v822 = load i64, ptr %slot18, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot39, align 8
  %v825 = load i64, ptr %slot17, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld827, ptr %slot40, align 8
  %v828 = load i64, ptr %slot40, align 8
  %v829 = load i64, ptr %slot39, align 8
  %cmp830 = icmp slt i64 %v828, %v829
  %cv831 = zext i1 %cmp830 to i64
  store i64 %cv831, ptr %slot41, align 8
  %v832 = load i64, ptr %slot41, align 8
  %v833 = load i64, ptr %slot17, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i64 %v832, ptr %p834, align 8, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot17, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i64, ptr %p836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld837, ptr %slot42, align 8
  %v838 = load i64, ptr %slot42, align 8
  %cond839 = icmp ne i64 %v838, 0
  br i1 %cond839, label %bb_next31, label %bb_i14
bb_next31:
  %v840 = load i64, ptr %slot14, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i64, ptr %p841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld842, ptr %slot43, align 8
  %v843 = load i64, ptr %slot43, align 8
  %op844 = add i64 %v843, 0
  store i64 %op844, ptr %slot44, align 8
  %v845 = load i64, ptr %slot44, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !6, !noalias !7
  store i64 %ld847, ptr %slot45, align 8
  %v848 = load i64, ptr %slot45, align 8
  %v849 = load i64, ptr %slot17, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i64 %v848, ptr %p850, align 8, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot17, align 8
  %p852 = inttoptr i64 %v851 to ptr
  %ld853 = load i64, ptr %p852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld853, ptr %slot46, align 8
  %v854 = load i64, ptr %slot46, align 8
  %cmp855 = icmp ugt i64 %v854, 9223372036854775807
  %cv856 = zext i1 %cmp855 to i64
  store i64 %cv856, ptr %slot47, align 8
  %v857 = load i64, ptr %slot47, align 8
  %cond858 = icmp ne i64 %v857, 0
  br i1 %cond858, label %bb_cast_overflow36, label %bb_cast_ok36
bb_cast_overflow36:
  %v859 = load i64, ptr %slot1, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %v861 = load i64, ptr %slot46, align 8
  call void @myl_qbe_fail_cast(ptr %p860, i64 %v861, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok36:
  %v862 = load i64, ptr %slot46, align 8
  %v863 = load i64, ptr %slot17, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i64 %v862, ptr %p864, align 8, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot15, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot48, align 8
  %v868 = load i64, ptr %slot48, align 8
  %v869 = load i64, ptr %slot18, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i64 %v868, ptr %p870, align 8, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot18, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %ld873 = load i64, ptr %p872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld873, ptr %slot49, align 8
  %v874 = load i64, ptr %slot17, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %ld876 = load i64, ptr %p875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld876, ptr %slot50, align 8
  %v877 = load i64, ptr %slot50, align 8
  %v878 = load i64, ptr %slot49, align 8
  %ovpair880 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v877, i64 %v878)
  %op879 = extractvalue { i64, i1 } %ovpair880, 0
  %ov881 = extractvalue { i64, i1 } %ovpair880, 1
  store i64 %op879, ptr %slot51, align 8
  %v882 = load i64, ptr %slot50, align 8
  %v883 = load i64, ptr %slot51, align 8
  %op884 = xor i64 %v882, %v883
  store i64 %op884, ptr %slot52, align 8
  %v885 = load i64, ptr %slot49, align 8
  %v886 = load i64, ptr %slot51, align 8
  %op887 = xor i64 %v885, %v886
  store i64 %op887, ptr %slot53, align 8
  %v888 = load i64, ptr %slot52, align 8
  %v889 = load i64, ptr %slot53, align 8
  %op890 = and i64 %v888, %v889
  store i64 %op890, ptr %slot54, align 8
  %cv891 = zext i1 %ov881 to i64
  store i64 %cv891, ptr %slot55, align 8
  %v892 = load i64, ptr %slot55, align 8
  %cond893 = icmp ne i64 %v892, 0
  br i1 %cond893, label %bb_overflow40, label %bb_checked40
bb_overflow40:
  %v894 = load i64, ptr %slot1, align 8
  %p895 = inttoptr i64 %v894 to ptr
  %v896 = load i64, ptr %slot50, align 8
  %v897 = load i64, ptr %slot49, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p895, i64 0, i64 %v896, i64 %v897, i64 64) nomerge, !dbg !118
  unreachable
bb_checked40:
  %v898 = load i64, ptr %slot51, align 8
  %v899 = load i64, ptr %slot17, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 %v898, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot17, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i64, ptr %p902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld903, ptr %slot56, align 8
  %v904 = load i64, ptr %slot56, align 8
  %v905 = load i64, ptr %slot15, align 8
  %p906 = inttoptr i64 %v905 to ptr
  store i64 %v904, ptr %p906, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v907 = load i64, ptr %slot15, align 8
  %p908 = inttoptr i64 %v907 to ptr
  %ld909 = load i64, ptr %p908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld909, ptr %slot57, align 8
  %v910 = load i64, ptr %slot57, align 8
  %v911 = load i64, ptr %slot17, align 8
  %p912 = inttoptr i64 %v911 to ptr
  store i64 %v910, ptr %p912, align 8, !alias.scope !3, !noalias !4
  %v913 = load i64, ptr %slot14, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %ld915 = load i64, ptr %p914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld915, ptr %slot58, align 8
  %v916 = load i64, ptr %slot17, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %ld918 = load i64, ptr %p917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld918, ptr %slot59, align 8
  %v919 = load i64, ptr %slot58, align 8
  %p920 = inttoptr i64 %v919 to ptr
  %ld921 = load i64, ptr %p920, align 8, !alias.scope !6, !noalias !7
  store i64 %ld921, ptr %slot60, align 8
  %v922 = load i64, ptr %slot59, align 8
  %v923 = load i64, ptr %slot60, align 8
  %cmp924 = icmp ult i64 %v922, %v923
  %cv925 = zext i1 %cmp924 to i64
  store i64 %cv925, ptr %slot61, align 8
  %v926 = load i64, ptr %slot61, align 8
  %cond927 = icmp ne i64 %v926, 0
  br i1 %cond927, label %bb_success52, label %bb_failed52
bb_failed52:
  %v928 = load i64, ptr %slot1, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %v930 = load i64, ptr %slot59, align 8
  %v931 = load i64, ptr %slot60, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p929, i64 %v930, i64 %v931) nomerge, !dbg !120
  unreachable
bb_success52:
  %v932 = load i64, ptr %slot58, align 8
  %op933 = add i64 %v932, 32
  store i64 %op933, ptr %slot62, align 8
  %v934 = load i64, ptr %slot62, align 8
  %p935 = inttoptr i64 %v934 to ptr
  %ld936 = load i64, ptr %p935, align 8, !alias.scope !6, !noalias !7
  store i64 %ld936, ptr %slot63, align 8
  %v937 = load i64, ptr %slot59, align 8
  %op938 = mul i64 %v937, 56
  store i64 %op938, ptr %slot64, align 8
  %v939 = load i64, ptr %slot63, align 8
  %v940 = load i64, ptr %slot64, align 8
  %op941 = add i64 %v939, %v940
  store i64 %op941, ptr %slot65, align 8
  %v942 = load i64, ptr %slot65, align 8
  %v943 = load i64, ptr %slot17, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i64 %v942, ptr %p944, align 8, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot17, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i64, ptr %p946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld947, ptr %slot66, align 8
  %v948 = load i64, ptr %slot66, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i32, ptr %p949, align 4, !alias.scope !12, !noalias !13
  %ext951 = zext i32 %ld950 to i64
  store i64 %ext951, ptr %slot67, align 8
  %v952 = load i64, ptr %slot67, align 8
  %cmp953 = icmp eq i64 %v952, 0
  %cv954 = zext i1 %cmp953 to i64
  store i64 %cv954, ptr %slot68, align 8
  %v955 = load i64, ptr %slot68, align 8
  %cond956 = icmp ne i64 %v955, 0
  br i1 %cond956, label %bb_rcarm59, label %bb_rcarmnext59
bb_rcarm59:
  %v957 = load i64, ptr %slot6, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ld959 = load i32, ptr %p958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld959, ptr %slot69, align 8
  %v960 = load i32, ptr %slot69, align 8
  %cv961 = zext i32 %v960 to i64
  %cond962 = icmp ne i64 %cv961, 0
  br i1 %cond962, label %bb_rcslotdrop62, label %bb_rcslotdone62
bb_rcslotdrop62:
  %v963 = load i64, ptr %slot6, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i32 0, ptr %p964, align 4, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot10, align 8
  store i64 %v965, ptr %slot70, align 8
  %v966 = load i64, ptr %slot7, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %ld968 = load i32, ptr %p967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld968, ptr %slot71, align 8
  %v969 = load i32, ptr %slot71, align 8
  %op970 = and i32 %v969, 28
  store i32 %op970, ptr %slot72, align 8
  %v971 = load i32, ptr %slot72, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcslotrole62, label %bb_rcslotowner62
bb_rcslotrole62:
  %v974 = load i64, ptr %slot23, align 8
  store i64 %v974, ptr %slot73, align 8
  %v975 = load i64, ptr %slot73, align 8
  %v976 = load i64, ptr %slot70, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v975, i64 %v976) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotowner62:
  %v977 = load i64, ptr %slot23, align 8
  store i64 %v977, ptr %slot74, align 8
  %v978 = load i64, ptr %slot74, align 8
  %v979 = load i64, ptr %slot70, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v978, i64 %v979) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotdone62:
  br label %bb_i23
bb_rcarmnext59:
  %v980 = load i64, ptr %slot67, align 8
  %cmp981 = icmp eq i64 %v980, 1
  %cv982 = zext i1 %cmp981 to i64
  store i64 %cv982, ptr %slot75, align 8
  %v983 = load i64, ptr %slot75, align 8
  %cond984 = icmp ne i64 %v983, 0
  br i1 %cond984, label %bb_rcarm69, label %bb_rcarmnext69
bb_rcarm69:
  %v985 = load i64, ptr %slot6, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %ld987 = load i32, ptr %p986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld987, ptr %slot76, align 8
  %v988 = load i32, ptr %slot76, align 8
  %cv989 = zext i32 %v988 to i64
  %cond990 = icmp ne i64 %cv989, 0
  br i1 %cond990, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v991 = load i64, ptr %slot6, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i32 0, ptr %p992, align 4, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot10, align 8
  store i64 %v993, ptr %slot77, align 8
  %v994 = load i64, ptr %slot7, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i32, ptr %p995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld996, ptr %slot78, align 8
  %v997 = load i32, ptr %slot78, align 8
  %op998 = and i32 %v997, 28
  store i32 %op998, ptr %slot79, align 8
  %v999 = load i32, ptr %slot79, align 8
  %cv1000 = zext i32 %v999 to i64
  %cond1001 = icmp ne i64 %cv1000, 0
  br i1 %cond1001, label %bb_rcslotrole72, label %bb_rcslotowner72
bb_rcslotrole72:
  %v1002 = load i64, ptr %slot23, align 8
  store i64 %v1002, ptr %slot80, align 8
  %v1003 = load i64, ptr %slot80, align 8
  %v1004 = load i64, ptr %slot77, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1003, i64 %v1004) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotowner72:
  %v1005 = load i64, ptr %slot23, align 8
  store i64 %v1005, ptr %slot81, align 8
  %v1006 = load i64, ptr %slot81, align 8
  %v1007 = load i64, ptr %slot77, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1006, i64 %v1007) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotdone72:
  br label %bb_i27
bb_rcarmnext69:
  %v1008 = load i64, ptr %slot67, align 8
  %cmp1009 = icmp eq i64 %v1008, 2
  %cv1010 = zext i1 %cmp1009 to i64
  store i64 %cv1010, ptr %slot82, align 8
  %v1011 = load i64, ptr %slot82, align 8
  %cond1012 = icmp ne i64 %v1011, 0
  br i1 %cond1012, label %bb_rcarm79, label %bb_rcarmnext79
bb_rcarm79:
  %v1013 = load i64, ptr %slot66, align 8
  %op1014 = add i64 %v1013, 8
  store i64 %op1014, ptr %slot83, align 8
  %v1015 = load i64, ptr %slot83, align 8
  %v1016 = load i64, ptr %slot16, align 8
  %p1017 = inttoptr i64 %v1015 to ptr
  %p1018 = inttoptr i64 %v1016 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1018, ptr %p1017, i64 48, i1 false), !alias.scope !10000000
  %v1019 = load i64, ptr %slot6, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  %ld1021 = load i32, ptr %p1020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1021, ptr %slot84, align 8
  %v1022 = load i32, ptr %slot84, align 8
  %cv1023 = zext i32 %v1022 to i64
  %cond1024 = icmp ne i64 %cv1023, 0
  br i1 %cond1024, label %bb_rcslotdrop93, label %bb_rcslotdone93
bb_rcslotdrop93:
  %v1025 = load i64, ptr %slot6, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i32 0, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot10, align 8
  store i64 %v1027, ptr %slot85, align 8
  %v1028 = load i64, ptr %slot7, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  %ld1030 = load i32, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1030, ptr %slot86, align 8
  %v1031 = load i32, ptr %slot86, align 8
  %op1032 = and i32 %v1031, 28
  store i32 %op1032, ptr %slot87, align 8
  %v1033 = load i32, ptr %slot87, align 8
  %cv1034 = zext i32 %v1033 to i64
  %cond1035 = icmp ne i64 %cv1034, 0
  br i1 %cond1035, label %bb_rcslotrole93, label %bb_rcslotowner93
bb_rcslotrole93:
  %v1036 = load i64, ptr %slot23, align 8
  store i64 %v1036, ptr %slot88, align 8
  %v1037 = load i64, ptr %slot88, align 8
  %v1038 = load i64, ptr %slot85, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1037, i64 %v1038) nomerge, !dbg !122
  br label %bb_rcslotdone93
bb_rcslotowner93:
  %v1039 = load i64, ptr %slot23, align 8
  store i64 %v1039, ptr %slot89, align 8
  %v1040 = load i64, ptr %slot89, align 8
  %v1041 = load i64, ptr %slot85, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1040, i64 %v1041) nomerge, !dbg !122
  br label %bb_rcslotdone93
bb_rcslotdone93:
  br label %bb_i17
bb_rcarmnext79:
  %v1042 = load i64, ptr %slot67, align 8
  %cmp1043 = icmp eq i64 %v1042, 3
  %cv1044 = zext i1 %cmp1043 to i64
  store i64 %cv1044, ptr %slot90, align 8
  %v1045 = load i64, ptr %slot90, align 8
  %cond1046 = icmp ne i64 %v1045, 0
  br i1 %cond1046, label %bb_rcarm100, label %bb_rcarmnext100
bb_rcarm100:
  %v1047 = load i64, ptr %slot6, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  %ld1049 = load i32, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1049, ptr %slot91, align 8
  %v1050 = load i32, ptr %slot91, align 8
  %cv1051 = zext i32 %v1050 to i64
  %cond1052 = icmp ne i64 %cv1051, 0
  br i1 %cond1052, label %bb_rcslotdrop103, label %bb_rcslotdone103
bb_rcslotdrop103:
  %v1053 = load i64, ptr %slot6, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 0, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot10, align 8
  store i64 %v1055, ptr %slot92, align 8
  %v1056 = load i64, ptr %slot7, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  %ld1058 = load i32, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1058, ptr %slot93, align 8
  %v1059 = load i32, ptr %slot93, align 8
  %op1060 = and i32 %v1059, 28
  store i32 %op1060, ptr %slot94, align 8
  %v1061 = load i32, ptr %slot94, align 8
  %cv1062 = zext i32 %v1061 to i64
  %cond1063 = icmp ne i64 %cv1062, 0
  br i1 %cond1063, label %bb_rcslotrole103, label %bb_rcslotowner103
bb_rcslotrole103:
  %v1064 = load i64, ptr %slot23, align 8
  store i64 %v1064, ptr %slot95, align 8
  %v1065 = load i64, ptr %slot95, align 8
  %v1066 = load i64, ptr %slot92, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1065, i64 %v1066) nomerge, !dbg !122
  br label %bb_rcslotdone103
bb_rcslotowner103:
  %v1067 = load i64, ptr %slot23, align 8
  store i64 %v1067, ptr %slot96, align 8
  %v1068 = load i64, ptr %slot96, align 8
  %v1069 = load i64, ptr %slot92, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1068, i64 %v1069) nomerge, !dbg !122
  br label %bb_rcslotdone103
bb_rcslotdone103:
  br label %bb_i31
bb_rcarmnext100:
  %v1070 = load i64, ptr %slot67, align 8
  %cmp1071 = icmp eq i64 %v1070, 4
  %cv1072 = zext i1 %cmp1071 to i64
  store i64 %cv1072, ptr %slot97, align 8
  %v1073 = load i64, ptr %slot97, align 8
  %cond1074 = icmp ne i64 %v1073, 0
  br i1 %cond1074, label %bb_rcarm110, label %bb_rcarmnext110
bb_rcarm110:
  %v1075 = load i64, ptr %slot6, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  %ld1077 = load i32, ptr %p1076, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1077, ptr %slot98, align 8
  %v1078 = load i32, ptr %slot98, align 8
  %cv1079 = zext i32 %v1078 to i64
  %cond1080 = icmp ne i64 %cv1079, 0
  br i1 %cond1080, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v1081 = load i64, ptr %slot6, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i32 0, ptr %p1082, align 4, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot10, align 8
  store i64 %v1083, ptr %slot99, align 8
  %v1084 = load i64, ptr %slot7, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i32, ptr %p1085, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1086, ptr %slot100, align 8
  %v1087 = load i32, ptr %slot100, align 8
  %op1088 = and i32 %v1087, 28
  store i32 %op1088, ptr %slot101, align 8
  %v1089 = load i32, ptr %slot101, align 8
  %cv1090 = zext i32 %v1089 to i64
  %cond1091 = icmp ne i64 %cv1090, 0
  br i1 %cond1091, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v1092 = load i64, ptr %slot23, align 8
  store i64 %v1092, ptr %slot102, align 8
  %v1093 = load i64, ptr %slot102, align 8
  %v1094 = load i64, ptr %slot99, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1093, i64 %v1094) nomerge, !dbg !122
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v1095 = load i64, ptr %slot23, align 8
  store i64 %v1095, ptr %slot103, align 8
  %v1096 = load i64, ptr %slot103, align 8
  %v1097 = load i64, ptr %slot99, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1096, i64 %v1097) nomerge, !dbg !122
  br label %bb_rcslotdone113
bb_rcslotdone113:
  br label %bb_i35
bb_rcarmnext110:
  %v1098 = load i64, ptr %slot67, align 8
  %cmp1099 = icmp eq i64 %v1098, 5
  %cv1100 = zext i1 %cmp1099 to i64
  store i64 %cv1100, ptr %slot104, align 8
  %v1101 = load i64, ptr %slot104, align 8
  %cond1102 = icmp ne i64 %v1101, 0
  br i1 %cond1102, label %bb_rcarm120, label %bb_rcarmnext120
bb_rcarm120:
  %v1103 = load i64, ptr %slot6, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %ld1105 = load i32, ptr %p1104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1105, ptr %slot105, align 8
  %v1106 = load i32, ptr %slot105, align 8
  %cv1107 = zext i32 %v1106 to i64
  %cond1108 = icmp ne i64 %cv1107, 0
  br i1 %cond1108, label %bb_rcslotdrop123, label %bb_rcslotdone123
bb_rcslotdrop123:
  %v1109 = load i64, ptr %slot6, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  store i32 0, ptr %p1110, align 4, !alias.scope !3, !noalias !4
  %v1111 = load i64, ptr %slot10, align 8
  store i64 %v1111, ptr %slot106, align 8
  %v1112 = load i64, ptr %slot7, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %ld1114 = load i32, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1114, ptr %slot107, align 8
  %v1115 = load i32, ptr %slot107, align 8
  %op1116 = and i32 %v1115, 28
  store i32 %op1116, ptr %slot108, align 8
  %v1117 = load i32, ptr %slot108, align 8
  %cv1118 = zext i32 %v1117 to i64
  %cond1119 = icmp ne i64 %cv1118, 0
  br i1 %cond1119, label %bb_rcslotrole123, label %bb_rcslotowner123
bb_rcslotrole123:
  %v1120 = load i64, ptr %slot23, align 8
  store i64 %v1120, ptr %slot109, align 8
  %v1121 = load i64, ptr %slot109, align 8
  %v1122 = load i64, ptr %slot106, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1121, i64 %v1122) nomerge, !dbg !122
  br label %bb_rcslotdone123
bb_rcslotowner123:
  %v1123 = load i64, ptr %slot23, align 8
  store i64 %v1123, ptr %slot110, align 8
  %v1124 = load i64, ptr %slot110, align 8
  %v1125 = load i64, ptr %slot106, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1124, i64 %v1125) nomerge, !dbg !122
  br label %bb_rcslotdone123
bb_rcslotdone123:
  br label %bb_i39
bb_rcarmnext120:
  %v1126 = load i64, ptr %slot67, align 8
  %cmp1127 = icmp eq i64 %v1126, 6
  %cv1128 = zext i1 %cmp1127 to i64
  store i64 %cv1128, ptr %slot111, align 8
  %v1129 = load i64, ptr %slot111, align 8
  %cond1130 = icmp ne i64 %v1129, 0
  br i1 %cond1130, label %bb_rcarm130, label %bb_rcarmnext130
bb_rcarm130:
  %v1131 = load i64, ptr %slot6, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %ld1133 = load i32, ptr %p1132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1133, ptr %slot112, align 8
  %v1134 = load i32, ptr %slot112, align 8
  %cv1135 = zext i32 %v1134 to i64
  %cond1136 = icmp ne i64 %cv1135, 0
  br i1 %cond1136, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v1137 = load i64, ptr %slot6, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i32 0, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot10, align 8
  store i64 %v1139, ptr %slot113, align 8
  %v1140 = load i64, ptr %slot7, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot114, align 8
  %v1143 = load i32, ptr %slot114, align 8
  %op1144 = and i32 %v1143, 28
  store i32 %op1144, ptr %slot115, align 8
  %v1145 = load i32, ptr %slot115, align 8
  %cv1146 = zext i32 %v1145 to i64
  %cond1147 = icmp ne i64 %cv1146, 0
  br i1 %cond1147, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1148 = load i64, ptr %slot23, align 8
  store i64 %v1148, ptr %slot116, align 8
  %v1149 = load i64, ptr %slot116, align 8
  %v1150 = load i64, ptr %slot113, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1149, i64 %v1150) nomerge, !dbg !122
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1151 = load i64, ptr %slot23, align 8
  store i64 %v1151, ptr %slot117, align 8
  %v1152 = load i64, ptr %slot117, align 8
  %v1153 = load i64, ptr %slot113, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1152, i64 %v1153) nomerge, !dbg !122
  br label %bb_rcslotdone133
bb_rcslotdone133:
  br label %bb_i43
bb_rcarmnext130:
  %v1154 = load i64, ptr %slot67, align 8
  %cmp1155 = icmp eq i64 %v1154, 7
  %cv1156 = zext i1 %cmp1155 to i64
  store i64 %cv1156, ptr %slot118, align 8
  %v1157 = load i64, ptr %slot118, align 8
  %cond1158 = icmp ne i64 %v1157, 0
  br i1 %cond1158, label %bb_rcarm140, label %bb_rcarmnext140
bb_rcarm140:
  %v1159 = load i64, ptr %slot6, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i32, ptr %p1160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1161, ptr %slot119, align 8
  %v1162 = load i32, ptr %slot119, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v1165 = load i64, ptr %slot6, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i32 0, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot10, align 8
  store i64 %v1167, ptr %slot120, align 8
  %v1168 = load i64, ptr %slot7, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i32, ptr %p1169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1170, ptr %slot121, align 8
  %v1171 = load i32, ptr %slot121, align 8
  %op1172 = and i32 %v1171, 28
  store i32 %op1172, ptr %slot122, align 8
  %v1173 = load i32, ptr %slot122, align 8
  %cv1174 = zext i32 %v1173 to i64
  %cond1175 = icmp ne i64 %cv1174, 0
  br i1 %cond1175, label %bb_rcslotrole143, label %bb_rcslotowner143
bb_rcslotrole143:
  %v1176 = load i64, ptr %slot23, align 8
  store i64 %v1176, ptr %slot123, align 8
  %v1177 = load i64, ptr %slot123, align 8
  %v1178 = load i64, ptr %slot120, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1177, i64 %v1178) nomerge, !dbg !122
  br label %bb_rcslotdone143
bb_rcslotowner143:
  %v1179 = load i64, ptr %slot23, align 8
  store i64 %v1179, ptr %slot124, align 8
  %v1180 = load i64, ptr %slot124, align 8
  %v1181 = load i64, ptr %slot120, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1180, i64 %v1181) nomerge, !dbg !122
  br label %bb_rcslotdone143
bb_rcslotdone143:
  br label %bb_i47
bb_rcarmnext140:
  %v1182 = load i64, ptr %slot67, align 8
  %cmp1183 = icmp eq i64 %v1182, 8
  %cv1184 = zext i1 %cmp1183 to i64
  store i64 %cv1184, ptr %slot125, align 8
  %v1185 = load i64, ptr %slot125, align 8
  %cond1186 = icmp ne i64 %v1185, 0
  br i1 %cond1186, label %bb_rcarm150, label %bb_rcarmnext150
bb_rcarm150:
  %v1187 = load i64, ptr %slot6, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot126, align 8
  %v1190 = load i32, ptr %slot126, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v1193 = load i64, ptr %slot6, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i32 0, ptr %p1194, align 4, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot10, align 8
  store i64 %v1195, ptr %slot127, align 8
  %v1196 = load i64, ptr %slot7, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i32, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1198, ptr %slot128, align 8
  %v1199 = load i32, ptr %slot128, align 8
  %op1200 = and i32 %v1199, 28
  store i32 %op1200, ptr %slot129, align 8
  %v1201 = load i32, ptr %slot129, align 8
  %cv1202 = zext i32 %v1201 to i64
  %cond1203 = icmp ne i64 %cv1202, 0
  br i1 %cond1203, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v1204 = load i64, ptr %slot23, align 8
  store i64 %v1204, ptr %slot130, align 8
  %v1205 = load i64, ptr %slot130, align 8
  %v1206 = load i64, ptr %slot127, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1205, i64 %v1206) nomerge, !dbg !122
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v1207 = load i64, ptr %slot23, align 8
  store i64 %v1207, ptr %slot131, align 8
  %v1208 = load i64, ptr %slot131, align 8
  %v1209 = load i64, ptr %slot127, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1208, i64 %v1209) nomerge, !dbg !122
  br label %bb_rcslotdone153
bb_rcslotdone153:
  br label %bb_i51
bb_rcarmnext150:
  %v1210 = load i64, ptr %slot67, align 8
  %cmp1211 = icmp eq i64 %v1210, 9
  %cv1212 = zext i1 %cmp1211 to i64
  store i64 %cv1212, ptr %slot132, align 8
  %v1213 = load i64, ptr %slot132, align 8
  %cond1214 = icmp ne i64 %v1213, 0
  br i1 %cond1214, label %bb_rcarm160, label %bb_rcarmnext160
bb_rcarm160:
  %v1215 = load i64, ptr %slot6, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  %ld1217 = load i32, ptr %p1216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1217, ptr %slot133, align 8
  %v1218 = load i32, ptr %slot133, align 8
  %cv1219 = zext i32 %v1218 to i64
  %cond1220 = icmp ne i64 %cv1219, 0
  br i1 %cond1220, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v1221 = load i64, ptr %slot6, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i32 0, ptr %p1222, align 4, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot10, align 8
  store i64 %v1223, ptr %slot134, align 8
  %v1224 = load i64, ptr %slot7, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i32, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1226, ptr %slot135, align 8
  %v1227 = load i32, ptr %slot135, align 8
  %op1228 = and i32 %v1227, 28
  store i32 %op1228, ptr %slot136, align 8
  %v1229 = load i32, ptr %slot136, align 8
  %cv1230 = zext i32 %v1229 to i64
  %cond1231 = icmp ne i64 %cv1230, 0
  br i1 %cond1231, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v1232 = load i64, ptr %slot23, align 8
  store i64 %v1232, ptr %slot137, align 8
  %v1233 = load i64, ptr %slot137, align 8
  %v1234 = load i64, ptr %slot134, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1233, i64 %v1234) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v1235 = load i64, ptr %slot23, align 8
  store i64 %v1235, ptr %slot138, align 8
  %v1236 = load i64, ptr %slot138, align 8
  %v1237 = load i64, ptr %slot134, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1236, i64 %v1237) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotdone163:
  br label %bb_i55
bb_rcarmnext160:
  %v1238 = load i64, ptr %slot67, align 8
  %cmp1239 = icmp eq i64 %v1238, 10
  %cv1240 = zext i1 %cmp1239 to i64
  store i64 %cv1240, ptr %slot139, align 8
  %v1241 = load i64, ptr %slot139, align 8
  %cond1242 = icmp ne i64 %v1241, 0
  br i1 %cond1242, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  %v1243 = load i64, ptr %slot6, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %ld1245 = load i32, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1245, ptr %slot140, align 8
  %v1246 = load i32, ptr %slot140, align 8
  %cv1247 = zext i32 %v1246 to i64
  %cond1248 = icmp ne i64 %cv1247, 0
  br i1 %cond1248, label %bb_rcslotdrop173, label %bb_rcslotdone173
bb_rcslotdrop173:
  %v1249 = load i64, ptr %slot6, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  store i32 0, ptr %p1250, align 4, !alias.scope !3, !noalias !4
  %v1251 = load i64, ptr %slot10, align 8
  store i64 %v1251, ptr %slot141, align 8
  %v1252 = load i64, ptr %slot7, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %ld1254 = load i32, ptr %p1253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1254, ptr %slot142, align 8
  %v1255 = load i32, ptr %slot142, align 8
  %op1256 = and i32 %v1255, 28
  store i32 %op1256, ptr %slot143, align 8
  %v1257 = load i32, ptr %slot143, align 8
  %cv1258 = zext i32 %v1257 to i64
  %cond1259 = icmp ne i64 %cv1258, 0
  br i1 %cond1259, label %bb_rcslotrole173, label %bb_rcslotowner173
bb_rcslotrole173:
  %v1260 = load i64, ptr %slot23, align 8
  store i64 %v1260, ptr %slot144, align 8
  %v1261 = load i64, ptr %slot144, align 8
  %v1262 = load i64, ptr %slot141, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1261, i64 %v1262) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotowner173:
  %v1263 = load i64, ptr %slot23, align 8
  store i64 %v1263, ptr %slot145, align 8
  %v1264 = load i64, ptr %slot145, align 8
  %v1265 = load i64, ptr %slot141, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1264, i64 %v1265) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotdone173:
  br label %bb_i59
bb_rcarmnext170:
  br label %bb_failure
bb_i17:
  %v1266 = load i64, ptr %slot16, align 8
  %v1267 = load i64, ptr %slot17, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  store i64 %v1266, ptr %p1268, align 8, !alias.scope !3, !noalias !4
  %v1269 = load i64, ptr %slot16, align 8
  %v1270 = load i64, ptr %slot17, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i64 %v1269, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot17, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i64, ptr %p1273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1274, ptr %slot146, align 8
  %v1275 = load i64, ptr %slot6, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i32, ptr %p1276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1277, ptr %slot147, align 8
  %v1278 = load i64, ptr %slot7, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i32, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1280, ptr %slot148, align 8
  %v1281 = load i32, ptr %slot148, align 8
  %op1282 = and i32 %v1281, 24
  store i32 %op1282, ptr %slot148, align 8
  %v1283 = load i32, ptr %slot148, align 8
  %cmp1284 = icmp eq i32 %v1283, 0
  %cv1285 = zext i1 %cmp1284 to i32
  store i32 %cv1285, ptr %slot149, align 8
  %v1286 = load i32, ptr %slot147, align 8
  %v1287 = load i32, ptr %slot149, align 8
  %op1288 = and i32 %v1286, %v1287
  store i32 %op1288, ptr %slot150, align 8
  %v1289 = load i64, ptr %slot24, align 8
  store i64 %v1289, ptr %slot151, align 8
  %v1290 = load i32, ptr %slot150, align 8
  %op1291 = mul i32 %v1290, 4
  store i32 %op1291, ptr %slot152, align 8
  %v1292 = load i32, ptr %slot152, align 8
  %op1293 = or i32 %v1292, 0
  store i32 %op1293, ptr %slot153, align 8
  %v1294 = load i64, ptr %slot11, align 8
  store i64 %v1294, ptr %slot154, align 8
  %v1295 = load i64, ptr %slot23, align 8
  %v1296 = load i64, ptr %slot154, align 8
  %v1297 = load i64, ptr %slot146, align 8
  %v1298 = load i64, ptr %slot151, align 8
  %cv1299 = trunc i64 %v1298 to i32
  %v1300 = load i32, ptr %slot153, align 8
  %call1301 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v1295, i64 %v1296, i64 %v1297, i32 %cv1299, i32 %v1300) nomerge, !dbg !124
  store i32 %call1301, ptr %slot155, align 8
  %v1302 = load i32, ptr %slot155, align 8
  %cv1303 = zext i32 %v1302 to i64
  %cond1304 = icmp ne i64 %cv1303, 0
  br i1 %cond1304, label %bb_rcsuccess194, label %bb_rcfailure194
bb_rcfailure194:
  %v1305 = load i64, ptr %slot23, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %call1307 = call i32 @myl_rc_take_failure(ptr %p1306) nomerge, !dbg !124
  store i32 %call1307, ptr %slot156, align 8
  %v1308 = load i64, ptr %slot1, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  %v1310 = load i32, ptr %slot156, align 8
  %call1311 = call i32 @myl_qbe_rc_status(ptr %p1309, i32 %v1310) nomerge, !dbg !124
  store i32 %call1311, ptr %slot157, align 8
  br label %bb_failure
bb_rcsuccess194:
  %v1312 = load i32, ptr %slot150, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rchtaken197, label %bb_rchcopied197
bb_rchcopied197:
  %v1315 = load i64, ptr %slot6, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  %ld1317 = load i32, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1317, ptr %slot158, align 8
  %v1318 = load i32, ptr %slot158, align 8
  %cv1319 = zext i32 %v1318 to i64
  %cond1320 = icmp ne i64 %cv1319, 0
  br i1 %cond1320, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1321 = load i64, ptr %slot6, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i32 0, ptr %p1322, align 4, !alias.scope !3, !noalias !4
  %v1323 = load i64, ptr %slot10, align 8
  store i64 %v1323, ptr %slot159, align 8
  %v1324 = load i64, ptr %slot7, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i32, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1326, ptr %slot160, align 8
  %v1327 = load i32, ptr %slot160, align 8
  %op1328 = and i32 %v1327, 28
  store i32 %op1328, ptr %slot161, align 8
  %v1329 = load i32, ptr %slot161, align 8
  %cv1330 = zext i32 %v1329 to i64
  %cond1331 = icmp ne i64 %cv1330, 0
  br i1 %cond1331, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1332 = load i64, ptr %slot23, align 8
  store i64 %v1332, ptr %slot162, align 8
  %v1333 = load i64, ptr %slot162, align 8
  %v1334 = load i64, ptr %slot159, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v1333, i64 %v1334) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1335 = load i64, ptr %slot23, align 8
  store i64 %v1335, ptr %slot163, align 8
  %v1336 = load i64, ptr %slot163, align 8
  %v1337 = load i64, ptr %slot159, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v1336, i64 %v1337) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotdone200:
  br label %bb_rchprepared197
bb_rchtaken197:
  %v1338 = load i64, ptr %slot6, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 0, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared197
bb_rchprepared197:
  %v1340 = load i64, ptr %slot9, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 2, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot8, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  store i32 1, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot10, align 8
  store i64 %v1344, ptr %slot164, align 8
  %v1345 = load i64, ptr %slot11, align 8
  store i64 %v1345, ptr %slot165, align 8
  %v1346 = load i64, ptr %slot165, align 8
  %v1347 = load i64, ptr %slot164, align 8
  %p1348 = inttoptr i64 %v1346 to ptr
  %p1349 = inttoptr i64 %v1347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1349, ptr %p1348, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot7, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  store i32 2, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot9, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  %ld1354 = load i32, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1354, ptr %slot166, align 8
  %v1355 = load i32, ptr %slot166, align 8
  %v1356 = load i64, ptr %slot7, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i32 %v1355, ptr %p1357, align 4, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot8, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 0, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot6, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  store i32 1, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  %v1362 = load i64, ptr %slot164, align 8
  %v1363 = load i64, ptr %slot17, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  store i64 %v1362, ptr %p1364, align 8, !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot17, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  %ld1367 = load i64, ptr %p1366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1367, ptr %slot167, align 8
  %v1368 = load i64, ptr %slot17, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %ld1370 = load i64, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1370, ptr %slot168, align 8
  %v1371 = load i64, ptr %slot11, align 8
  store i64 %v1371, ptr %slot169, align 8
  %v1372 = load i64, ptr %slot24, align 8
  store i64 %v1372, ptr %slot170, align 8
  %v1373 = load i64, ptr %slot168, align 8
  %op1374 = add i64 %v1373, 16
  store i64 %op1374, ptr %slot171, align 8
  %v1375 = load i64, ptr %slot171, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot172, align 8
  %v1378 = load i64, ptr %slot172, align 8
  %cmp1379 = icmp ne i64 %v1378, 0
  %cv1380 = zext i1 %cmp1379 to i32
  store i32 %cv1380, ptr %slot173, align 8
  %v1381 = load i32, ptr %slot173, align 8
  %cv1382 = zext i32 %v1381 to i64
  %cond1383 = icmp ne i64 %cv1382, 0
  br i1 %cond1383, label %bb_rcmoveheader225, label %bb_rcmovenext225
bb_rcmoveheader225:
  %v1384 = load i64, ptr %slot172, align 8
  %op1385 = sub i64 %v1384, 16
  store i64 %op1385, ptr %slot174, align 8
  %v1386 = load i64, ptr %slot172, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %rgep1388 = getelementptr i8, ptr %p1387, i64 -16
  %ld1389 = load i64, ptr %rgep1388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1389, ptr %slot175, align 8
  %v1390 = load i64, ptr %slot175, align 8
  %op1391 = and i64 %v1390, 5764607523034234881
  store i64 %op1391, ptr %slot176, align 8
  %v1392 = load i64, ptr %slot176, align 8
  %cmp1393 = icmp ne i64 %v1392, 0
  %cv1394 = zext i1 %cmp1393 to i32
  store i32 %cv1394, ptr %slot177, align 8
  %v1395 = load i32, ptr %slot177, align 8
  %cv1396 = zext i32 %v1395 to i64
  %cond1397 = icmp ne i64 %cv1396, 0
  br i1 %cond1397, label %bb_rcmoveslow222, label %bb_rcmovenext225
bb_rcmovenext225:
  %v1398 = load i64, ptr %slot168, align 8
  %op1399 = add i64 %v1398, 24
  store i64 %op1399, ptr %slot178, align 8
  %v1400 = load i64, ptr %slot178, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %ld1402 = load i64, ptr %p1401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1402, ptr %slot179, align 8
  %v1403 = load i64, ptr %slot179, align 8
  %cmp1404 = icmp ne i64 %v1403, 0
  %cv1405 = zext i1 %cmp1404 to i32
  store i32 %cv1405, ptr %slot180, align 8
  %v1406 = load i32, ptr %slot180, align 8
  %cv1407 = zext i32 %v1406 to i64
  %cond1408 = icmp ne i64 %cv1407, 0
  br i1 %cond1408, label %bb_rcmoveheader233, label %bb_rcmovenext233
bb_rcmoveheader233:
  %v1409 = load i64, ptr %slot179, align 8
  %op1410 = sub i64 %v1409, 16
  store i64 %op1410, ptr %slot181, align 8
  %v1411 = load i64, ptr %slot179, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %rgep1413 = getelementptr i8, ptr %p1412, i64 -16
  %ld1414 = load i64, ptr %rgep1413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1414, ptr %slot182, align 8
  %v1415 = load i64, ptr %slot182, align 8
  %op1416 = and i64 %v1415, 5764607523034234881
  store i64 %op1416, ptr %slot183, align 8
  %v1417 = load i64, ptr %slot183, align 8
  %cmp1418 = icmp ne i64 %v1417, 0
  %cv1419 = zext i1 %cmp1418 to i32
  store i32 %cv1419, ptr %slot184, align 8
  %v1420 = load i32, ptr %slot184, align 8
  %cv1421 = zext i32 %v1420 to i64
  %cond1422 = icmp ne i64 %cv1421, 0
  br i1 %cond1422, label %bb_rcmoveslow222, label %bb_rcmovenext233
bb_rcmovenext233:
  %v1423 = load i64, ptr %slot168, align 8
  %op1424 = add i64 %v1423, 32
  store i64 %op1424, ptr %slot185, align 8
  %v1425 = load i64, ptr %slot185, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  %ld1427 = load i64, ptr %p1426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1427, ptr %slot186, align 8
  %v1428 = load i64, ptr %slot186, align 8
  %cmp1429 = icmp ne i64 %v1428, 0
  %cv1430 = zext i1 %cmp1429 to i32
  store i32 %cv1430, ptr %slot187, align 8
  %v1431 = load i32, ptr %slot187, align 8
  %cv1432 = zext i32 %v1431 to i64
  %cond1433 = icmp ne i64 %cv1432, 0
  br i1 %cond1433, label %bb_rcmoveheader241, label %bb_rcmovenext241
bb_rcmoveheader241:
  %v1434 = load i64, ptr %slot186, align 8
  %op1435 = sub i64 %v1434, 16
  store i64 %op1435, ptr %slot188, align 8
  %v1436 = load i64, ptr %slot186, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %rgep1438 = getelementptr i8, ptr %p1437, i64 -16
  %ld1439 = load i64, ptr %rgep1438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1439, ptr %slot189, align 8
  %v1440 = load i64, ptr %slot189, align 8
  %op1441 = and i64 %v1440, 5764607523034234881
  store i64 %op1441, ptr %slot190, align 8
  %v1442 = load i64, ptr %slot190, align 8
  %cmp1443 = icmp ne i64 %v1442, 0
  %cv1444 = zext i1 %cmp1443 to i32
  store i32 %cv1444, ptr %slot191, align 8
  %v1445 = load i32, ptr %slot191, align 8
  %cv1446 = zext i32 %v1445 to i64
  %cond1447 = icmp ne i64 %cv1446, 0
  br i1 %cond1447, label %bb_rcmoveslow222, label %bb_rcmovenext241
bb_rcmovenext241:
  %v1448 = load i64, ptr %slot168, align 8
  %v1449 = load i64, ptr %slot169, align 8
  %p1450 = inttoptr i64 %v1448 to ptr
  %p1451 = inttoptr i64 %v1449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1451, ptr %p1450, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot168, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i64 0, ptr %p1453, align 8, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot168, align 8
  %op1455 = add i64 %v1454, 8
  store i64 %op1455, ptr %slot192, align 8
  %v1456 = load i64, ptr %slot192, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  store i64 0, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  %v1458 = load i64, ptr %slot168, align 8
  %op1459 = add i64 %v1458, 16
  store i64 %op1459, ptr %slot193, align 8
  %v1460 = load i64, ptr %slot193, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  store i64 0, ptr %p1461, align 8, !alias.scope !3, !noalias !4
  %v1462 = load i64, ptr %slot168, align 8
  %op1463 = add i64 %v1462, 24
  store i64 %op1463, ptr %slot194, align 8
  %v1464 = load i64, ptr %slot194, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  store i64 0, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  %v1466 = load i64, ptr %slot168, align 8
  %op1467 = add i64 %v1466, 32
  store i64 %op1467, ptr %slot195, align 8
  %v1468 = load i64, ptr %slot195, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  store i64 0, ptr %p1469, align 8, !alias.scope !3, !noalias !4
  %v1470 = load i64, ptr %slot168, align 8
  %op1471 = add i64 %v1470, 40
  store i64 %op1471, ptr %slot196, align 8
  %v1472 = load i64, ptr %slot196, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  store i64 0, ptr %p1473, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved222
bb_rcmoveslow222:
  %v1474 = load i64, ptr %slot23, align 8
  %v1475 = load i64, ptr %slot169, align 8
  %v1476 = load i64, ptr %slot168, align 8
  %v1477 = load i64, ptr %slot170, align 8
  %cv1478 = trunc i64 %v1477 to i32
  %call1479 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v1474, i64 %v1475, i64 %v1476, i32 %cv1478) nomerge, !dbg !126
  store i32 %call1479, ptr %slot197, align 8
  %v1480 = load i32, ptr %slot197, align 8
  %cv1481 = zext i32 %v1480 to i64
  %cond1482 = icmp ne i64 %cv1481, 0
  br i1 %cond1482, label %bb_rcsuccess253, label %bb_rcfailure253
bb_rcfailure253:
  %v1483 = load i64, ptr %slot23, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %call1485 = call i32 @myl_rc_take_failure(ptr %p1484) nomerge, !dbg !126
  store i32 %call1485, ptr %slot198, align 8
  %v1486 = load i64, ptr %slot1, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %v1488 = load i32, ptr %slot198, align 8
  %call1489 = call i32 @myl_qbe_rc_status(ptr %p1487, i32 %v1488) nomerge, !dbg !126
  store i32 %call1489, ptr %slot199, align 8
  br label %bb_failure
bb_rcsuccess253:
  br label %bb_rcmoved222
bb_rcmoved222:
  %v1490 = load i64, ptr %slot6, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i32 0, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot9, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  store i32 2, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  %v1494 = load i64, ptr %slot8, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  store i32 1, ptr %p1495, align 4, !alias.scope !3, !noalias !4
  %v1496 = load i64, ptr %slot11, align 8
  store i64 %v1496, ptr %slot200, align 8
  %v1497 = load i64, ptr %slot8, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i32 0, ptr %p1498, align 4, !alias.scope !3, !noalias !4
  %v1499 = load i64, ptr %slot6, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %ld1501 = load i32, ptr %p1500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1501, ptr %slot201, align 8
  %v1502 = load i32, ptr %slot201, align 8
  %cv1503 = zext i32 %v1502 to i64
  %cond1504 = icmp ne i64 %cv1503, 0
  br i1 %cond1504, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v1505 = load i64, ptr %slot6, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i32 0, ptr %p1506, align 4, !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot10, align 8
  store i64 %v1507, ptr %slot202, align 8
  %v1508 = load i64, ptr %slot7, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i32, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1510, ptr %slot203, align 8
  %v1511 = load i32, ptr %slot203, align 8
  %op1512 = and i32 %v1511, 28
  store i32 %op1512, ptr %slot204, align 8
  %v1513 = load i32, ptr %slot204, align 8
  %cv1514 = zext i32 %v1513 to i64
  %cond1515 = icmp ne i64 %cv1514, 0
  br i1 %cond1515, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v1516 = load i64, ptr %slot23, align 8
  store i64 %v1516, ptr %slot205, align 8
  %v1517 = load i64, ptr %slot205, align 8
  %v1518 = load i64, ptr %slot202, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v1517, i64 %v1518) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v1519 = load i64, ptr %slot23, align 8
  store i64 %v1519, ptr %slot206, align 8
  %v1520 = load i64, ptr %slot206, align 8
  %v1521 = load i64, ptr %slot202, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v1520, i64 %v1521) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotdone263:
  %v1522 = load i64, ptr %slot200, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1523, i64 48, i1 false)
  ret void
bb_i23:
  %v1524 = load i64, ptr %slot17, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i64 0, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot17, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %ld1528 = load i64, ptr %p1527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1528, ptr %slot207, align 8
  %v1529 = load i64, ptr %slot207, align 8
  %cond1530 = icmp ne i64 %v1529, 0
  br i1 %cond1530, label %bb_success326, label %bb_failed326
bb_failed326:
  %v1531 = load i64, ptr %slot1, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  call void @myl_qbe_fail_assert(ptr %p1532) nomerge, !dbg !128
  unreachable
bb_success326:
  %v1533 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult209, i64 %v1533) nomerge, !dbg !130
  %addr1534 = ptrtoint ptr %callresult209 to i64
  store i64 %addr1534, ptr %slot208, align 8
  %v1535 = load i64, ptr %slot208, align 8
  %v1536 = load i64, ptr %slot17, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i64 %v1535, ptr %p1537, align 8, !alias.scope !3, !noalias !4
  %v1538 = load i64, ptr %slot17, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  %ld1540 = load i64, ptr %p1539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1540, ptr %slot210, align 8
  %v1541 = load i64, ptr %slot11, align 8
  store i64 %v1541, ptr %slot211, align 8
  %v1542 = load i64, ptr %slot210, align 8
  %v1543 = load i64, ptr %slot211, align 8
  %p1544 = inttoptr i64 %v1542 to ptr
  %p1545 = inttoptr i64 %v1543 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1545, ptr %p1544, i64 48, i1 false)
  %v1546 = load i64, ptr %slot9, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i32 2, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  %v1548 = load i64, ptr %slot8, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i32 1, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot10, align 8
  store i64 %v1550, ptr %slot212, align 8
  %v1551 = load i64, ptr %slot11, align 8
  store i64 %v1551, ptr %slot213, align 8
  %v1552 = load i64, ptr %slot213, align 8
  %v1553 = load i64, ptr %slot212, align 8
  %p1554 = inttoptr i64 %v1552 to ptr
  %p1555 = inttoptr i64 %v1553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1555, ptr %p1554, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot7, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i32 2, ptr %p1557, align 4, !alias.scope !3, !noalias !4
  %v1558 = load i64, ptr %slot9, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %ld1560 = load i32, ptr %p1559, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1560, ptr %slot214, align 8
  %v1561 = load i32, ptr %slot214, align 8
  %v1562 = load i64, ptr %slot7, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  store i32 %v1561, ptr %p1563, align 4, !alias.scope !3, !noalias !4
  %v1564 = load i64, ptr %slot8, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i32 0, ptr %p1565, align 4, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot6, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i32 1, ptr %p1567, align 4, !alias.scope !3, !noalias !4
  %v1568 = load i64, ptr %slot212, align 8
  %v1569 = load i64, ptr %slot17, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i64 %v1568, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot17, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  %ld1573 = load i64, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1573, ptr %slot215, align 8
  %v1574 = load i64, ptr %slot17, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %ld1576 = load i64, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1576, ptr %slot216, align 8
  %v1577 = load i64, ptr %slot11, align 8
  store i64 %v1577, ptr %slot217, align 8
  %v1578 = load i64, ptr %slot24, align 8
  store i64 %v1578, ptr %slot218, align 8
  %v1579 = load i64, ptr %slot216, align 8
  %op1580 = add i64 %v1579, 16
  store i64 %op1580, ptr %slot219, align 8
  %v1581 = load i64, ptr %slot219, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  %ld1583 = load i64, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1583, ptr %slot220, align 8
  %v1584 = load i64, ptr %slot220, align 8
  %cmp1585 = icmp ne i64 %v1584, 0
  %cv1586 = zext i1 %cmp1585 to i32
  store i32 %cv1586, ptr %slot221, align 8
  %v1587 = load i32, ptr %slot221, align 8
  %cv1588 = zext i32 %v1587 to i64
  %cond1589 = icmp ne i64 %cv1588, 0
  br i1 %cond1589, label %bb_rcmoveheader347, label %bb_rcmovenext347
bb_rcmoveheader347:
  %v1590 = load i64, ptr %slot220, align 8
  %op1591 = sub i64 %v1590, 16
  store i64 %op1591, ptr %slot222, align 8
  %v1592 = load i64, ptr %slot220, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %rgep1594 = getelementptr i8, ptr %p1593, i64 -16
  %ld1595 = load i64, ptr %rgep1594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1595, ptr %slot223, align 8
  %v1596 = load i64, ptr %slot223, align 8
  %op1597 = and i64 %v1596, 5764607523034234881
  store i64 %op1597, ptr %slot224, align 8
  %v1598 = load i64, ptr %slot224, align 8
  %cmp1599 = icmp ne i64 %v1598, 0
  %cv1600 = zext i1 %cmp1599 to i32
  store i32 %cv1600, ptr %slot225, align 8
  %v1601 = load i32, ptr %slot225, align 8
  %cv1602 = zext i32 %v1601 to i64
  %cond1603 = icmp ne i64 %cv1602, 0
  br i1 %cond1603, label %bb_rcmoveslow344, label %bb_rcmovenext347
bb_rcmovenext347:
  %v1604 = load i64, ptr %slot216, align 8
  %op1605 = add i64 %v1604, 24
  store i64 %op1605, ptr %slot226, align 8
  %v1606 = load i64, ptr %slot226, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i64, ptr %p1607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1608, ptr %slot227, align 8
  %v1609 = load i64, ptr %slot227, align 8
  %cmp1610 = icmp ne i64 %v1609, 0
  %cv1611 = zext i1 %cmp1610 to i32
  store i32 %cv1611, ptr %slot228, align 8
  %v1612 = load i32, ptr %slot228, align 8
  %cv1613 = zext i32 %v1612 to i64
  %cond1614 = icmp ne i64 %cv1613, 0
  br i1 %cond1614, label %bb_rcmoveheader355, label %bb_rcmovenext355
bb_rcmoveheader355:
  %v1615 = load i64, ptr %slot227, align 8
  %op1616 = sub i64 %v1615, 16
  store i64 %op1616, ptr %slot229, align 8
  %v1617 = load i64, ptr %slot227, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %rgep1619 = getelementptr i8, ptr %p1618, i64 -16
  %ld1620 = load i64, ptr %rgep1619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1620, ptr %slot230, align 8
  %v1621 = load i64, ptr %slot230, align 8
  %op1622 = and i64 %v1621, 5764607523034234881
  store i64 %op1622, ptr %slot231, align 8
  %v1623 = load i64, ptr %slot231, align 8
  %cmp1624 = icmp ne i64 %v1623, 0
  %cv1625 = zext i1 %cmp1624 to i32
  store i32 %cv1625, ptr %slot232, align 8
  %v1626 = load i32, ptr %slot232, align 8
  %cv1627 = zext i32 %v1626 to i64
  %cond1628 = icmp ne i64 %cv1627, 0
  br i1 %cond1628, label %bb_rcmoveslow344, label %bb_rcmovenext355
bb_rcmovenext355:
  %v1629 = load i64, ptr %slot216, align 8
  %op1630 = add i64 %v1629, 32
  store i64 %op1630, ptr %slot233, align 8
  %v1631 = load i64, ptr %slot233, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  %ld1633 = load i64, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1633, ptr %slot234, align 8
  %v1634 = load i64, ptr %slot234, align 8
  %cmp1635 = icmp ne i64 %v1634, 0
  %cv1636 = zext i1 %cmp1635 to i32
  store i32 %cv1636, ptr %slot235, align 8
  %v1637 = load i32, ptr %slot235, align 8
  %cv1638 = zext i32 %v1637 to i64
  %cond1639 = icmp ne i64 %cv1638, 0
  br i1 %cond1639, label %bb_rcmoveheader363, label %bb_rcmovenext363
bb_rcmoveheader363:
  %v1640 = load i64, ptr %slot234, align 8
  %op1641 = sub i64 %v1640, 16
  store i64 %op1641, ptr %slot236, align 8
  %v1642 = load i64, ptr %slot234, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  %rgep1644 = getelementptr i8, ptr %p1643, i64 -16
  %ld1645 = load i64, ptr %rgep1644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1645, ptr %slot237, align 8
  %v1646 = load i64, ptr %slot237, align 8
  %op1647 = and i64 %v1646, 5764607523034234881
  store i64 %op1647, ptr %slot238, align 8
  %v1648 = load i64, ptr %slot238, align 8
  %cmp1649 = icmp ne i64 %v1648, 0
  %cv1650 = zext i1 %cmp1649 to i32
  store i32 %cv1650, ptr %slot239, align 8
  %v1651 = load i32, ptr %slot239, align 8
  %cv1652 = zext i32 %v1651 to i64
  %cond1653 = icmp ne i64 %cv1652, 0
  br i1 %cond1653, label %bb_rcmoveslow344, label %bb_rcmovenext363
bb_rcmovenext363:
  %v1654 = load i64, ptr %slot216, align 8
  %v1655 = load i64, ptr %slot217, align 8
  %p1656 = inttoptr i64 %v1654 to ptr
  %p1657 = inttoptr i64 %v1655 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1657, ptr %p1656, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1658 = load i64, ptr %slot216, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i64 0, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot216, align 8
  %op1661 = add i64 %v1660, 8
  store i64 %op1661, ptr %slot240, align 8
  %v1662 = load i64, ptr %slot240, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i64 0, ptr %p1663, align 8, !alias.scope !3, !noalias !4
  %v1664 = load i64, ptr %slot216, align 8
  %op1665 = add i64 %v1664, 16
  store i64 %op1665, ptr %slot241, align 8
  %v1666 = load i64, ptr %slot241, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 0, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot216, align 8
  %op1669 = add i64 %v1668, 24
  store i64 %op1669, ptr %slot242, align 8
  %v1670 = load i64, ptr %slot242, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 0, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot216, align 8
  %op1673 = add i64 %v1672, 32
  store i64 %op1673, ptr %slot243, align 8
  %v1674 = load i64, ptr %slot243, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot216, align 8
  %op1677 = add i64 %v1676, 40
  store i64 %op1677, ptr %slot244, align 8
  %v1678 = load i64, ptr %slot244, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  store i64 0, ptr %p1679, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved344
bb_rcmoveslow344:
  %v1680 = load i64, ptr %slot23, align 8
  %v1681 = load i64, ptr %slot217, align 8
  %v1682 = load i64, ptr %slot216, align 8
  %v1683 = load i64, ptr %slot218, align 8
  %cv1684 = trunc i64 %v1683 to i32
  %call1685 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v1680, i64 %v1681, i64 %v1682, i32 %cv1684) nomerge, !dbg !132
  store i32 %call1685, ptr %slot245, align 8
  %v1686 = load i32, ptr %slot245, align 8
  %cv1687 = zext i32 %v1686 to i64
  %cond1688 = icmp ne i64 %cv1687, 0
  br i1 %cond1688, label %bb_rcsuccess375, label %bb_rcfailure375
bb_rcfailure375:
  %v1689 = load i64, ptr %slot23, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %call1691 = call i32 @myl_rc_take_failure(ptr %p1690) nomerge, !dbg !132
  store i32 %call1691, ptr %slot246, align 8
  %v1692 = load i64, ptr %slot1, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %v1694 = load i32, ptr %slot246, align 8
  %call1695 = call i32 @myl_qbe_rc_status(ptr %p1693, i32 %v1694) nomerge, !dbg !132
  store i32 %call1695, ptr %slot247, align 8
  br label %bb_failure
bb_rcsuccess375:
  br label %bb_rcmoved344
bb_rcmoved344:
  %v1696 = load i64, ptr %slot6, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i32 0, ptr %p1697, align 4, !alias.scope !3, !noalias !4
  %v1698 = load i64, ptr %slot9, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  store i32 2, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  %v1700 = load i64, ptr %slot8, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  store i32 1, ptr %p1701, align 4, !alias.scope !3, !noalias !4
  %v1702 = load i64, ptr %slot11, align 8
  store i64 %v1702, ptr %slot248, align 8
  %v1703 = load i64, ptr %slot8, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 0, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot6, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %ld1707 = load i32, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1707, ptr %slot249, align 8
  %v1708 = load i32, ptr %slot249, align 8
  %cv1709 = zext i32 %v1708 to i64
  %cond1710 = icmp ne i64 %cv1709, 0
  br i1 %cond1710, label %bb_rcslotdrop385, label %bb_rcslotdone385
bb_rcslotdrop385:
  %v1711 = load i64, ptr %slot6, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot10, align 8
  store i64 %v1713, ptr %slot250, align 8
  %v1714 = load i64, ptr %slot7, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  %ld1716 = load i32, ptr %p1715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1716, ptr %slot251, align 8
  %v1717 = load i32, ptr %slot251, align 8
  %op1718 = and i32 %v1717, 28
  store i32 %op1718, ptr %slot252, align 8
  %v1719 = load i32, ptr %slot252, align 8
  %cv1720 = zext i32 %v1719 to i64
  %cond1721 = icmp ne i64 %cv1720, 0
  br i1 %cond1721, label %bb_rcslotrole385, label %bb_rcslotowner385
bb_rcslotrole385:
  %v1722 = load i64, ptr %slot23, align 8
  store i64 %v1722, ptr %slot253, align 8
  %v1723 = load i64, ptr %slot253, align 8
  %v1724 = load i64, ptr %slot250, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v1723, i64 %v1724) nomerge, !dbg !132
  br label %bb_rcslotdone385
bb_rcslotowner385:
  %v1725 = load i64, ptr %slot23, align 8
  store i64 %v1725, ptr %slot254, align 8
  %v1726 = load i64, ptr %slot254, align 8
  %v1727 = load i64, ptr %slot250, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v1726, i64 %v1727) nomerge, !dbg !132
  br label %bb_rcslotdone385
bb_rcslotdone385:
  %v1728 = load i64, ptr %slot248, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1729, i64 48, i1 false)
  ret void
bb_i27:
  %v1730 = load i64, ptr %slot17, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  store i64 0, ptr %p1731, align 8, !alias.scope !3, !noalias !4
  %v1732 = load i64, ptr %slot17, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  %ld1734 = load i64, ptr %p1733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1734, ptr %slot255, align 8
  %v1735 = load i64, ptr %slot255, align 8
  %cond1736 = icmp ne i64 %v1735, 0
  br i1 %cond1736, label %bb_success448, label %bb_failed448
bb_failed448:
  %v1737 = load i64, ptr %slot1, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  call void @myl_qbe_fail_assert(ptr %p1738) nomerge, !dbg !134
  unreachable
bb_success448:
  %v1739 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult257, i64 %v1739) nomerge, !dbg !136
  %addr1740 = ptrtoint ptr %callresult257 to i64
  store i64 %addr1740, ptr %slot256, align 8
  %v1741 = load i64, ptr %slot256, align 8
  %v1742 = load i64, ptr %slot17, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  store i64 %v1741, ptr %p1743, align 8, !alias.scope !3, !noalias !4
  %v1744 = load i64, ptr %slot17, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %ld1746 = load i64, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1746, ptr %slot258, align 8
  %v1747 = load i64, ptr %slot11, align 8
  store i64 %v1747, ptr %slot259, align 8
  %v1748 = load i64, ptr %slot258, align 8
  %v1749 = load i64, ptr %slot259, align 8
  %p1750 = inttoptr i64 %v1748 to ptr
  %p1751 = inttoptr i64 %v1749 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1751, ptr %p1750, i64 48, i1 false)
  %v1752 = load i64, ptr %slot9, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i32 2, ptr %p1753, align 4, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot8, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 1, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot10, align 8
  store i64 %v1756, ptr %slot260, align 8
  %v1757 = load i64, ptr %slot11, align 8
  store i64 %v1757, ptr %slot261, align 8
  %v1758 = load i64, ptr %slot261, align 8
  %v1759 = load i64, ptr %slot260, align 8
  %p1760 = inttoptr i64 %v1758 to ptr
  %p1761 = inttoptr i64 %v1759 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1761, ptr %p1760, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot7, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i32 2, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot9, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i32, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1766, ptr %slot262, align 8
  %v1767 = load i32, ptr %slot262, align 8
  %v1768 = load i64, ptr %slot7, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  store i32 %v1767, ptr %p1769, align 4, !alias.scope !3, !noalias !4
  %v1770 = load i64, ptr %slot8, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  store i32 0, ptr %p1771, align 4, !alias.scope !3, !noalias !4
  %v1772 = load i64, ptr %slot6, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i32 1, ptr %p1773, align 4, !alias.scope !3, !noalias !4
  %v1774 = load i64, ptr %slot260, align 8
  %v1775 = load i64, ptr %slot17, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  store i64 %v1774, ptr %p1776, align 8, !alias.scope !3, !noalias !4
  %v1777 = load i64, ptr %slot17, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  %ld1779 = load i64, ptr %p1778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1779, ptr %slot263, align 8
  %v1780 = load i64, ptr %slot17, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i64, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1782, ptr %slot264, align 8
  %v1783 = load i64, ptr %slot11, align 8
  store i64 %v1783, ptr %slot265, align 8
  %v1784 = load i64, ptr %slot24, align 8
  store i64 %v1784, ptr %slot266, align 8
  %v1785 = load i64, ptr %slot264, align 8
  %op1786 = add i64 %v1785, 16
  store i64 %op1786, ptr %slot267, align 8
  %v1787 = load i64, ptr %slot267, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i64, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1789, ptr %slot268, align 8
  %v1790 = load i64, ptr %slot268, align 8
  %cmp1791 = icmp ne i64 %v1790, 0
  %cv1792 = zext i1 %cmp1791 to i32
  store i32 %cv1792, ptr %slot269, align 8
  %v1793 = load i32, ptr %slot269, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcmoveheader469, label %bb_rcmovenext469
bb_rcmoveheader469:
  %v1796 = load i64, ptr %slot268, align 8
  %op1797 = sub i64 %v1796, 16
  store i64 %op1797, ptr %slot270, align 8
  %v1798 = load i64, ptr %slot268, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  %rgep1800 = getelementptr i8, ptr %p1799, i64 -16
  %ld1801 = load i64, ptr %rgep1800, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1801, ptr %slot271, align 8
  %v1802 = load i64, ptr %slot271, align 8
  %op1803 = and i64 %v1802, 5764607523034234881
  store i64 %op1803, ptr %slot272, align 8
  %v1804 = load i64, ptr %slot272, align 8
  %cmp1805 = icmp ne i64 %v1804, 0
  %cv1806 = zext i1 %cmp1805 to i32
  store i32 %cv1806, ptr %slot273, align 8
  %v1807 = load i32, ptr %slot273, align 8
  %cv1808 = zext i32 %v1807 to i64
  %cond1809 = icmp ne i64 %cv1808, 0
  br i1 %cond1809, label %bb_rcmoveslow466, label %bb_rcmovenext469
bb_rcmovenext469:
  %v1810 = load i64, ptr %slot264, align 8
  %op1811 = add i64 %v1810, 24
  store i64 %op1811, ptr %slot274, align 8
  %v1812 = load i64, ptr %slot274, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %ld1814 = load i64, ptr %p1813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1814, ptr %slot275, align 8
  %v1815 = load i64, ptr %slot275, align 8
  %cmp1816 = icmp ne i64 %v1815, 0
  %cv1817 = zext i1 %cmp1816 to i32
  store i32 %cv1817, ptr %slot276, align 8
  %v1818 = load i32, ptr %slot276, align 8
  %cv1819 = zext i32 %v1818 to i64
  %cond1820 = icmp ne i64 %cv1819, 0
  br i1 %cond1820, label %bb_rcmoveheader477, label %bb_rcmovenext477
bb_rcmoveheader477:
  %v1821 = load i64, ptr %slot275, align 8
  %op1822 = sub i64 %v1821, 16
  store i64 %op1822, ptr %slot277, align 8
  %v1823 = load i64, ptr %slot275, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %rgep1825 = getelementptr i8, ptr %p1824, i64 -16
  %ld1826 = load i64, ptr %rgep1825, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1826, ptr %slot278, align 8
  %v1827 = load i64, ptr %slot278, align 8
  %op1828 = and i64 %v1827, 5764607523034234881
  store i64 %op1828, ptr %slot279, align 8
  %v1829 = load i64, ptr %slot279, align 8
  %cmp1830 = icmp ne i64 %v1829, 0
  %cv1831 = zext i1 %cmp1830 to i32
  store i32 %cv1831, ptr %slot280, align 8
  %v1832 = load i32, ptr %slot280, align 8
  %cv1833 = zext i32 %v1832 to i64
  %cond1834 = icmp ne i64 %cv1833, 0
  br i1 %cond1834, label %bb_rcmoveslow466, label %bb_rcmovenext477
bb_rcmovenext477:
  %v1835 = load i64, ptr %slot264, align 8
  %op1836 = add i64 %v1835, 32
  store i64 %op1836, ptr %slot281, align 8
  %v1837 = load i64, ptr %slot281, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  %ld1839 = load i64, ptr %p1838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1839, ptr %slot282, align 8
  %v1840 = load i64, ptr %slot282, align 8
  %cmp1841 = icmp ne i64 %v1840, 0
  %cv1842 = zext i1 %cmp1841 to i32
  store i32 %cv1842, ptr %slot283, align 8
  %v1843 = load i32, ptr %slot283, align 8
  %cv1844 = zext i32 %v1843 to i64
  %cond1845 = icmp ne i64 %cv1844, 0
  br i1 %cond1845, label %bb_rcmoveheader485, label %bb_rcmovenext485
bb_rcmoveheader485:
  %v1846 = load i64, ptr %slot282, align 8
  %op1847 = sub i64 %v1846, 16
  store i64 %op1847, ptr %slot284, align 8
  %v1848 = load i64, ptr %slot282, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  %rgep1850 = getelementptr i8, ptr %p1849, i64 -16
  %ld1851 = load i64, ptr %rgep1850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1851, ptr %slot285, align 8
  %v1852 = load i64, ptr %slot285, align 8
  %op1853 = and i64 %v1852, 5764607523034234881
  store i64 %op1853, ptr %slot286, align 8
  %v1854 = load i64, ptr %slot286, align 8
  %cmp1855 = icmp ne i64 %v1854, 0
  %cv1856 = zext i1 %cmp1855 to i32
  store i32 %cv1856, ptr %slot287, align 8
  %v1857 = load i32, ptr %slot287, align 8
  %cv1858 = zext i32 %v1857 to i64
  %cond1859 = icmp ne i64 %cv1858, 0
  br i1 %cond1859, label %bb_rcmoveslow466, label %bb_rcmovenext485
bb_rcmovenext485:
  %v1860 = load i64, ptr %slot264, align 8
  %v1861 = load i64, ptr %slot265, align 8
  %p1862 = inttoptr i64 %v1860 to ptr
  %p1863 = inttoptr i64 %v1861 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1863, ptr %p1862, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot264, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  store i64 0, ptr %p1865, align 8, !alias.scope !3, !noalias !4
  %v1866 = load i64, ptr %slot264, align 8
  %op1867 = add i64 %v1866, 8
  store i64 %op1867, ptr %slot288, align 8
  %v1868 = load i64, ptr %slot288, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i64 0, ptr %p1869, align 8, !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot264, align 8
  %op1871 = add i64 %v1870, 16
  store i64 %op1871, ptr %slot289, align 8
  %v1872 = load i64, ptr %slot289, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  store i64 0, ptr %p1873, align 8, !alias.scope !3, !noalias !4
  %v1874 = load i64, ptr %slot264, align 8
  %op1875 = add i64 %v1874, 24
  store i64 %op1875, ptr %slot290, align 8
  %v1876 = load i64, ptr %slot290, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i64 0, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot264, align 8
  %op1879 = add i64 %v1878, 32
  store i64 %op1879, ptr %slot291, align 8
  %v1880 = load i64, ptr %slot291, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i64 0, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  %v1882 = load i64, ptr %slot264, align 8
  %op1883 = add i64 %v1882, 40
  store i64 %op1883, ptr %slot292, align 8
  %v1884 = load i64, ptr %slot292, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i64 0, ptr %p1885, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved466
bb_rcmoveslow466:
  %v1886 = load i64, ptr %slot23, align 8
  %v1887 = load i64, ptr %slot265, align 8
  %v1888 = load i64, ptr %slot264, align 8
  %v1889 = load i64, ptr %slot266, align 8
  %cv1890 = trunc i64 %v1889 to i32
  %call1891 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v1886, i64 %v1887, i64 %v1888, i32 %cv1890) nomerge, !dbg !138
  store i32 %call1891, ptr %slot293, align 8
  %v1892 = load i32, ptr %slot293, align 8
  %cv1893 = zext i32 %v1892 to i64
  %cond1894 = icmp ne i64 %cv1893, 0
  br i1 %cond1894, label %bb_rcsuccess497, label %bb_rcfailure497
bb_rcfailure497:
  %v1895 = load i64, ptr %slot23, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  %call1897 = call i32 @myl_rc_take_failure(ptr %p1896) nomerge, !dbg !138
  store i32 %call1897, ptr %slot294, align 8
  %v1898 = load i64, ptr %slot1, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %v1900 = load i32, ptr %slot294, align 8
  %call1901 = call i32 @myl_qbe_rc_status(ptr %p1899, i32 %v1900) nomerge, !dbg !138
  store i32 %call1901, ptr %slot295, align 8
  br label %bb_failure
bb_rcsuccess497:
  br label %bb_rcmoved466
bb_rcmoved466:
  %v1902 = load i64, ptr %slot6, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i32 0, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot9, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 2, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot8, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 1, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot11, align 8
  store i64 %v1908, ptr %slot296, align 8
  %v1909 = load i64, ptr %slot8, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i32 0, ptr %p1910, align 4, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot6, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %ld1913 = load i32, ptr %p1912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1913, ptr %slot297, align 8
  %v1914 = load i32, ptr %slot297, align 8
  %cv1915 = zext i32 %v1914 to i64
  %cond1916 = icmp ne i64 %cv1915, 0
  br i1 %cond1916, label %bb_rcslotdrop507, label %bb_rcslotdone507
bb_rcslotdrop507:
  %v1917 = load i64, ptr %slot6, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i32 0, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot10, align 8
  store i64 %v1919, ptr %slot298, align 8
  %v1920 = load i64, ptr %slot7, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  %ld1922 = load i32, ptr %p1921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1922, ptr %slot299, align 8
  %v1923 = load i32, ptr %slot299, align 8
  %op1924 = and i32 %v1923, 28
  store i32 %op1924, ptr %slot300, align 8
  %v1925 = load i32, ptr %slot300, align 8
  %cv1926 = zext i32 %v1925 to i64
  %cond1927 = icmp ne i64 %cv1926, 0
  br i1 %cond1927, label %bb_rcslotrole507, label %bb_rcslotowner507
bb_rcslotrole507:
  %v1928 = load i64, ptr %slot23, align 8
  store i64 %v1928, ptr %slot301, align 8
  %v1929 = load i64, ptr %slot301, align 8
  %v1930 = load i64, ptr %slot298, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v1929, i64 %v1930) nomerge, !dbg !138
  br label %bb_rcslotdone507
bb_rcslotowner507:
  %v1931 = load i64, ptr %slot23, align 8
  store i64 %v1931, ptr %slot302, align 8
  %v1932 = load i64, ptr %slot302, align 8
  %v1933 = load i64, ptr %slot298, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v1932, i64 %v1933) nomerge, !dbg !138
  br label %bb_rcslotdone507
bb_rcslotdone507:
  %v1934 = load i64, ptr %slot296, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1935, i64 48, i1 false)
  ret void
bb_i31:
  %v1936 = load i64, ptr %slot17, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  store i64 0, ptr %p1937, align 8, !alias.scope !3, !noalias !4
  %v1938 = load i64, ptr %slot17, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %ld1940 = load i64, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1940, ptr %slot303, align 8
  %v1941 = load i64, ptr %slot303, align 8
  %cond1942 = icmp ne i64 %v1941, 0
  br i1 %cond1942, label %bb_success570, label %bb_failed570
bb_failed570:
  %v1943 = load i64, ptr %slot1, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  call void @myl_qbe_fail_assert(ptr %p1944) nomerge, !dbg !140
  unreachable
bb_success570:
  %v1945 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult305, i64 %v1945) nomerge, !dbg !142
  %addr1946 = ptrtoint ptr %callresult305 to i64
  store i64 %addr1946, ptr %slot304, align 8
  %v1947 = load i64, ptr %slot304, align 8
  %v1948 = load i64, ptr %slot17, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i64 %v1947, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot17, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %ld1952 = load i64, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1952, ptr %slot306, align 8
  %v1953 = load i64, ptr %slot11, align 8
  store i64 %v1953, ptr %slot307, align 8
  %v1954 = load i64, ptr %slot306, align 8
  %v1955 = load i64, ptr %slot307, align 8
  %p1956 = inttoptr i64 %v1954 to ptr
  %p1957 = inttoptr i64 %v1955 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1957, ptr %p1956, i64 48, i1 false)
  %v1958 = load i64, ptr %slot9, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  store i32 2, ptr %p1959, align 4, !alias.scope !3, !noalias !4
  %v1960 = load i64, ptr %slot8, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  store i32 1, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  %v1962 = load i64, ptr %slot10, align 8
  store i64 %v1962, ptr %slot308, align 8
  %v1963 = load i64, ptr %slot11, align 8
  store i64 %v1963, ptr %slot309, align 8
  %v1964 = load i64, ptr %slot309, align 8
  %v1965 = load i64, ptr %slot308, align 8
  %p1966 = inttoptr i64 %v1964 to ptr
  %p1967 = inttoptr i64 %v1965 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1967, ptr %p1966, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1968 = load i64, ptr %slot7, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  store i32 2, ptr %p1969, align 4, !alias.scope !3, !noalias !4
  %v1970 = load i64, ptr %slot9, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  %ld1972 = load i32, ptr %p1971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1972, ptr %slot310, align 8
  %v1973 = load i32, ptr %slot310, align 8
  %v1974 = load i64, ptr %slot7, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i32 %v1973, ptr %p1975, align 4, !alias.scope !3, !noalias !4
  %v1976 = load i64, ptr %slot8, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  store i32 0, ptr %p1977, align 4, !alias.scope !3, !noalias !4
  %v1978 = load i64, ptr %slot6, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  store i32 1, ptr %p1979, align 4, !alias.scope !3, !noalias !4
  %v1980 = load i64, ptr %slot308, align 8
  %v1981 = load i64, ptr %slot17, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  store i64 %v1980, ptr %p1982, align 8, !alias.scope !3, !noalias !4
  %v1983 = load i64, ptr %slot17, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %ld1985 = load i64, ptr %p1984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1985, ptr %slot311, align 8
  %v1986 = load i64, ptr %slot17, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  %ld1988 = load i64, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1988, ptr %slot312, align 8
  %v1989 = load i64, ptr %slot11, align 8
  store i64 %v1989, ptr %slot313, align 8
  %v1990 = load i64, ptr %slot24, align 8
  store i64 %v1990, ptr %slot314, align 8
  %v1991 = load i64, ptr %slot312, align 8
  %op1992 = add i64 %v1991, 16
  store i64 %op1992, ptr %slot315, align 8
  %v1993 = load i64, ptr %slot315, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %ld1995 = load i64, ptr %p1994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1995, ptr %slot316, align 8
  %v1996 = load i64, ptr %slot316, align 8
  %cmp1997 = icmp ne i64 %v1996, 0
  %cv1998 = zext i1 %cmp1997 to i32
  store i32 %cv1998, ptr %slot317, align 8
  %v1999 = load i32, ptr %slot317, align 8
  %cv2000 = zext i32 %v1999 to i64
  %cond2001 = icmp ne i64 %cv2000, 0
  br i1 %cond2001, label %bb_rcmoveheader591, label %bb_rcmovenext591
bb_rcmoveheader591:
  %v2002 = load i64, ptr %slot316, align 8
  %op2003 = sub i64 %v2002, 16
  store i64 %op2003, ptr %slot318, align 8
  %v2004 = load i64, ptr %slot316, align 8
  %p2005 = inttoptr i64 %v2004 to ptr
  %rgep2006 = getelementptr i8, ptr %p2005, i64 -16
  %ld2007 = load i64, ptr %rgep2006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2007, ptr %slot319, align 8
  %v2008 = load i64, ptr %slot319, align 8
  %op2009 = and i64 %v2008, 5764607523034234881
  store i64 %op2009, ptr %slot320, align 8
  %v2010 = load i64, ptr %slot320, align 8
  %cmp2011 = icmp ne i64 %v2010, 0
  %cv2012 = zext i1 %cmp2011 to i32
  store i32 %cv2012, ptr %slot321, align 8
  %v2013 = load i32, ptr %slot321, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcmoveslow588, label %bb_rcmovenext591
bb_rcmovenext591:
  %v2016 = load i64, ptr %slot312, align 8
  %op2017 = add i64 %v2016, 24
  store i64 %op2017, ptr %slot322, align 8
  %v2018 = load i64, ptr %slot322, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %ld2020 = load i64, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2020, ptr %slot323, align 8
  %v2021 = load i64, ptr %slot323, align 8
  %cmp2022 = icmp ne i64 %v2021, 0
  %cv2023 = zext i1 %cmp2022 to i32
  store i32 %cv2023, ptr %slot324, align 8
  %v2024 = load i32, ptr %slot324, align 8
  %cv2025 = zext i32 %v2024 to i64
  %cond2026 = icmp ne i64 %cv2025, 0
  br i1 %cond2026, label %bb_rcmoveheader599, label %bb_rcmovenext599
bb_rcmoveheader599:
  %v2027 = load i64, ptr %slot323, align 8
  %op2028 = sub i64 %v2027, 16
  store i64 %op2028, ptr %slot325, align 8
  %v2029 = load i64, ptr %slot323, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  %rgep2031 = getelementptr i8, ptr %p2030, i64 -16
  %ld2032 = load i64, ptr %rgep2031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2032, ptr %slot326, align 8
  %v2033 = load i64, ptr %slot326, align 8
  %op2034 = and i64 %v2033, 5764607523034234881
  store i64 %op2034, ptr %slot327, align 8
  %v2035 = load i64, ptr %slot327, align 8
  %cmp2036 = icmp ne i64 %v2035, 0
  %cv2037 = zext i1 %cmp2036 to i32
  store i32 %cv2037, ptr %slot328, align 8
  %v2038 = load i32, ptr %slot328, align 8
  %cv2039 = zext i32 %v2038 to i64
  %cond2040 = icmp ne i64 %cv2039, 0
  br i1 %cond2040, label %bb_rcmoveslow588, label %bb_rcmovenext599
bb_rcmovenext599:
  %v2041 = load i64, ptr %slot312, align 8
  %op2042 = add i64 %v2041, 32
  store i64 %op2042, ptr %slot329, align 8
  %v2043 = load i64, ptr %slot329, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %ld2045 = load i64, ptr %p2044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2045, ptr %slot330, align 8
  %v2046 = load i64, ptr %slot330, align 8
  %cmp2047 = icmp ne i64 %v2046, 0
  %cv2048 = zext i1 %cmp2047 to i32
  store i32 %cv2048, ptr %slot331, align 8
  %v2049 = load i32, ptr %slot331, align 8
  %cv2050 = zext i32 %v2049 to i64
  %cond2051 = icmp ne i64 %cv2050, 0
  br i1 %cond2051, label %bb_rcmoveheader607, label %bb_rcmovenext607
bb_rcmoveheader607:
  %v2052 = load i64, ptr %slot330, align 8
  %op2053 = sub i64 %v2052, 16
  store i64 %op2053, ptr %slot332, align 8
  %v2054 = load i64, ptr %slot330, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  %rgep2056 = getelementptr i8, ptr %p2055, i64 -16
  %ld2057 = load i64, ptr %rgep2056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2057, ptr %slot333, align 8
  %v2058 = load i64, ptr %slot333, align 8
  %op2059 = and i64 %v2058, 5764607523034234881
  store i64 %op2059, ptr %slot334, align 8
  %v2060 = load i64, ptr %slot334, align 8
  %cmp2061 = icmp ne i64 %v2060, 0
  %cv2062 = zext i1 %cmp2061 to i32
  store i32 %cv2062, ptr %slot335, align 8
  %v2063 = load i32, ptr %slot335, align 8
  %cv2064 = zext i32 %v2063 to i64
  %cond2065 = icmp ne i64 %cv2064, 0
  br i1 %cond2065, label %bb_rcmoveslow588, label %bb_rcmovenext607
bb_rcmovenext607:
  %v2066 = load i64, ptr %slot312, align 8
  %v2067 = load i64, ptr %slot313, align 8
  %p2068 = inttoptr i64 %v2066 to ptr
  %p2069 = inttoptr i64 %v2067 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2069, ptr %p2068, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2070 = load i64, ptr %slot312, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i64 0, ptr %p2071, align 8, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot312, align 8
  %op2073 = add i64 %v2072, 8
  store i64 %op2073, ptr %slot336, align 8
  %v2074 = load i64, ptr %slot336, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i64 0, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot312, align 8
  %op2077 = add i64 %v2076, 16
  store i64 %op2077, ptr %slot337, align 8
  %v2078 = load i64, ptr %slot337, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i64 0, ptr %p2079, align 8, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot312, align 8
  %op2081 = add i64 %v2080, 24
  store i64 %op2081, ptr %slot338, align 8
  %v2082 = load i64, ptr %slot338, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i64 0, ptr %p2083, align 8, !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot312, align 8
  %op2085 = add i64 %v2084, 32
  store i64 %op2085, ptr %slot339, align 8
  %v2086 = load i64, ptr %slot339, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i64 0, ptr %p2087, align 8, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot312, align 8
  %op2089 = add i64 %v2088, 40
  store i64 %op2089, ptr %slot340, align 8
  %v2090 = load i64, ptr %slot340, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i64 0, ptr %p2091, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved588
bb_rcmoveslow588:
  %v2092 = load i64, ptr %slot23, align 8
  %v2093 = load i64, ptr %slot313, align 8
  %v2094 = load i64, ptr %slot312, align 8
  %v2095 = load i64, ptr %slot314, align 8
  %cv2096 = trunc i64 %v2095 to i32
  %call2097 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2092, i64 %v2093, i64 %v2094, i32 %cv2096) nomerge, !dbg !144
  store i32 %call2097, ptr %slot341, align 8
  %v2098 = load i32, ptr %slot341, align 8
  %cv2099 = zext i32 %v2098 to i64
  %cond2100 = icmp ne i64 %cv2099, 0
  br i1 %cond2100, label %bb_rcsuccess619, label %bb_rcfailure619
bb_rcfailure619:
  %v2101 = load i64, ptr %slot23, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %call2103 = call i32 @myl_rc_take_failure(ptr %p2102) nomerge, !dbg !144
  store i32 %call2103, ptr %slot342, align 8
  %v2104 = load i64, ptr %slot1, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %v2106 = load i32, ptr %slot342, align 8
  %call2107 = call i32 @myl_qbe_rc_status(ptr %p2105, i32 %v2106) nomerge, !dbg !144
  store i32 %call2107, ptr %slot343, align 8
  br label %bb_failure
bb_rcsuccess619:
  br label %bb_rcmoved588
bb_rcmoved588:
  %v2108 = load i64, ptr %slot6, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i32 0, ptr %p2109, align 4, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot9, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  store i32 2, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  %v2112 = load i64, ptr %slot8, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i32 1, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot11, align 8
  store i64 %v2114, ptr %slot344, align 8
  %v2115 = load i64, ptr %slot8, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i32 0, ptr %p2116, align 4, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot6, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i32, ptr %p2118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2119, ptr %slot345, align 8
  %v2120 = load i32, ptr %slot345, align 8
  %cv2121 = zext i32 %v2120 to i64
  %cond2122 = icmp ne i64 %cv2121, 0
  br i1 %cond2122, label %bb_rcslotdrop629, label %bb_rcslotdone629
bb_rcslotdrop629:
  %v2123 = load i64, ptr %slot6, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  store i32 0, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  %v2125 = load i64, ptr %slot10, align 8
  store i64 %v2125, ptr %slot346, align 8
  %v2126 = load i64, ptr %slot7, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  %ld2128 = load i32, ptr %p2127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2128, ptr %slot347, align 8
  %v2129 = load i32, ptr %slot347, align 8
  %op2130 = and i32 %v2129, 28
  store i32 %op2130, ptr %slot348, align 8
  %v2131 = load i32, ptr %slot348, align 8
  %cv2132 = zext i32 %v2131 to i64
  %cond2133 = icmp ne i64 %cv2132, 0
  br i1 %cond2133, label %bb_rcslotrole629, label %bb_rcslotowner629
bb_rcslotrole629:
  %v2134 = load i64, ptr %slot23, align 8
  store i64 %v2134, ptr %slot349, align 8
  %v2135 = load i64, ptr %slot349, align 8
  %v2136 = load i64, ptr %slot346, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2135, i64 %v2136) nomerge, !dbg !144
  br label %bb_rcslotdone629
bb_rcslotowner629:
  %v2137 = load i64, ptr %slot23, align 8
  store i64 %v2137, ptr %slot350, align 8
  %v2138 = load i64, ptr %slot350, align 8
  %v2139 = load i64, ptr %slot346, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2138, i64 %v2139) nomerge, !dbg !144
  br label %bb_rcslotdone629
bb_rcslotdone629:
  %v2140 = load i64, ptr %slot344, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2141, i64 48, i1 false)
  ret void
bb_i35:
  %v2142 = load i64, ptr %slot17, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i64 0, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot17, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %ld2146 = load i64, ptr %p2145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2146, ptr %slot351, align 8
  %v2147 = load i64, ptr %slot351, align 8
  %cond2148 = icmp ne i64 %v2147, 0
  br i1 %cond2148, label %bb_success692, label %bb_failed692
bb_failed692:
  %v2149 = load i64, ptr %slot1, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  call void @myl_qbe_fail_assert(ptr %p2150) nomerge, !dbg !146
  unreachable
bb_success692:
  %v2151 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult353, i64 %v2151) nomerge, !dbg !148
  %addr2152 = ptrtoint ptr %callresult353 to i64
  store i64 %addr2152, ptr %slot352, align 8
  %v2153 = load i64, ptr %slot352, align 8
  %v2154 = load i64, ptr %slot17, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  store i64 %v2153, ptr %p2155, align 8, !alias.scope !3, !noalias !4
  %v2156 = load i64, ptr %slot17, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %ld2158 = load i64, ptr %p2157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2158, ptr %slot354, align 8
  %v2159 = load i64, ptr %slot11, align 8
  store i64 %v2159, ptr %slot355, align 8
  %v2160 = load i64, ptr %slot354, align 8
  %v2161 = load i64, ptr %slot355, align 8
  %p2162 = inttoptr i64 %v2160 to ptr
  %p2163 = inttoptr i64 %v2161 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2163, ptr %p2162, i64 48, i1 false)
  %v2164 = load i64, ptr %slot9, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 2, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot8, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i32 1, ptr %p2167, align 4, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot10, align 8
  store i64 %v2168, ptr %slot356, align 8
  %v2169 = load i64, ptr %slot11, align 8
  store i64 %v2169, ptr %slot357, align 8
  %v2170 = load i64, ptr %slot357, align 8
  %v2171 = load i64, ptr %slot356, align 8
  %p2172 = inttoptr i64 %v2170 to ptr
  %p2173 = inttoptr i64 %v2171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2173, ptr %p2172, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot7, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 2, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot9, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i32, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2178, ptr %slot358, align 8
  %v2179 = load i32, ptr %slot358, align 8
  %v2180 = load i64, ptr %slot7, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 %v2179, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot8, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 0, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot6, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  store i32 1, ptr %p2185, align 4, !alias.scope !3, !noalias !4
  %v2186 = load i64, ptr %slot356, align 8
  %v2187 = load i64, ptr %slot17, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i64 %v2186, ptr %p2188, align 8, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot17, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i64, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2191, ptr %slot359, align 8
  %v2192 = load i64, ptr %slot17, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i64, ptr %p2193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2194, ptr %slot360, align 8
  %v2195 = load i64, ptr %slot11, align 8
  store i64 %v2195, ptr %slot361, align 8
  %v2196 = load i64, ptr %slot24, align 8
  store i64 %v2196, ptr %slot362, align 8
  %v2197 = load i64, ptr %slot360, align 8
  %op2198 = add i64 %v2197, 16
  store i64 %op2198, ptr %slot363, align 8
  %v2199 = load i64, ptr %slot363, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot364, align 8
  %v2202 = load i64, ptr %slot364, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot365, align 8
  %v2205 = load i32, ptr %slot365, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcmoveheader713, label %bb_rcmovenext713
bb_rcmoveheader713:
  %v2208 = load i64, ptr %slot364, align 8
  %op2209 = sub i64 %v2208, 16
  store i64 %op2209, ptr %slot366, align 8
  %v2210 = load i64, ptr %slot364, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -16
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot367, align 8
  %v2214 = load i64, ptr %slot367, align 8
  %op2215 = and i64 %v2214, 5764607523034234881
  store i64 %op2215, ptr %slot368, align 8
  %v2216 = load i64, ptr %slot368, align 8
  %cmp2217 = icmp ne i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot369, align 8
  %v2219 = load i32, ptr %slot369, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcmoveslow710, label %bb_rcmovenext713
bb_rcmovenext713:
  %v2222 = load i64, ptr %slot360, align 8
  %op2223 = add i64 %v2222, 24
  store i64 %op2223, ptr %slot370, align 8
  %v2224 = load i64, ptr %slot370, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i64, ptr %p2225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2226, ptr %slot371, align 8
  %v2227 = load i64, ptr %slot371, align 8
  %cmp2228 = icmp ne i64 %v2227, 0
  %cv2229 = zext i1 %cmp2228 to i32
  store i32 %cv2229, ptr %slot372, align 8
  %v2230 = load i32, ptr %slot372, align 8
  %cv2231 = zext i32 %v2230 to i64
  %cond2232 = icmp ne i64 %cv2231, 0
  br i1 %cond2232, label %bb_rcmoveheader721, label %bb_rcmovenext721
bb_rcmoveheader721:
  %v2233 = load i64, ptr %slot371, align 8
  %op2234 = sub i64 %v2233, 16
  store i64 %op2234, ptr %slot373, align 8
  %v2235 = load i64, ptr %slot371, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %rgep2237 = getelementptr i8, ptr %p2236, i64 -16
  %ld2238 = load i64, ptr %rgep2237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2238, ptr %slot374, align 8
  %v2239 = load i64, ptr %slot374, align 8
  %op2240 = and i64 %v2239, 5764607523034234881
  store i64 %op2240, ptr %slot375, align 8
  %v2241 = load i64, ptr %slot375, align 8
  %cmp2242 = icmp ne i64 %v2241, 0
  %cv2243 = zext i1 %cmp2242 to i32
  store i32 %cv2243, ptr %slot376, align 8
  %v2244 = load i32, ptr %slot376, align 8
  %cv2245 = zext i32 %v2244 to i64
  %cond2246 = icmp ne i64 %cv2245, 0
  br i1 %cond2246, label %bb_rcmoveslow710, label %bb_rcmovenext721
bb_rcmovenext721:
  %v2247 = load i64, ptr %slot360, align 8
  %op2248 = add i64 %v2247, 32
  store i64 %op2248, ptr %slot377, align 8
  %v2249 = load i64, ptr %slot377, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  %ld2251 = load i64, ptr %p2250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2251, ptr %slot378, align 8
  %v2252 = load i64, ptr %slot378, align 8
  %cmp2253 = icmp ne i64 %v2252, 0
  %cv2254 = zext i1 %cmp2253 to i32
  store i32 %cv2254, ptr %slot379, align 8
  %v2255 = load i32, ptr %slot379, align 8
  %cv2256 = zext i32 %v2255 to i64
  %cond2257 = icmp ne i64 %cv2256, 0
  br i1 %cond2257, label %bb_rcmoveheader729, label %bb_rcmovenext729
bb_rcmoveheader729:
  %v2258 = load i64, ptr %slot378, align 8
  %op2259 = sub i64 %v2258, 16
  store i64 %op2259, ptr %slot380, align 8
  %v2260 = load i64, ptr %slot378, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  %rgep2262 = getelementptr i8, ptr %p2261, i64 -16
  %ld2263 = load i64, ptr %rgep2262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2263, ptr %slot381, align 8
  %v2264 = load i64, ptr %slot381, align 8
  %op2265 = and i64 %v2264, 5764607523034234881
  store i64 %op2265, ptr %slot382, align 8
  %v2266 = load i64, ptr %slot382, align 8
  %cmp2267 = icmp ne i64 %v2266, 0
  %cv2268 = zext i1 %cmp2267 to i32
  store i32 %cv2268, ptr %slot383, align 8
  %v2269 = load i32, ptr %slot383, align 8
  %cv2270 = zext i32 %v2269 to i64
  %cond2271 = icmp ne i64 %cv2270, 0
  br i1 %cond2271, label %bb_rcmoveslow710, label %bb_rcmovenext729
bb_rcmovenext729:
  %v2272 = load i64, ptr %slot360, align 8
  %v2273 = load i64, ptr %slot361, align 8
  %p2274 = inttoptr i64 %v2272 to ptr
  %p2275 = inttoptr i64 %v2273 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2275, ptr %p2274, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot360, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i64 0, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  %v2278 = load i64, ptr %slot360, align 8
  %op2279 = add i64 %v2278, 8
  store i64 %op2279, ptr %slot384, align 8
  %v2280 = load i64, ptr %slot384, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i64 0, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot360, align 8
  %op2283 = add i64 %v2282, 16
  store i64 %op2283, ptr %slot385, align 8
  %v2284 = load i64, ptr %slot385, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i64 0, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot360, align 8
  %op2287 = add i64 %v2286, 24
  store i64 %op2287, ptr %slot386, align 8
  %v2288 = load i64, ptr %slot386, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 0, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot360, align 8
  %op2291 = add i64 %v2290, 32
  store i64 %op2291, ptr %slot387, align 8
  %v2292 = load i64, ptr %slot387, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i64 0, ptr %p2293, align 8, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot360, align 8
  %op2295 = add i64 %v2294, 40
  store i64 %op2295, ptr %slot388, align 8
  %v2296 = load i64, ptr %slot388, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i64 0, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved710
bb_rcmoveslow710:
  %v2298 = load i64, ptr %slot23, align 8
  %v2299 = load i64, ptr %slot361, align 8
  %v2300 = load i64, ptr %slot360, align 8
  %v2301 = load i64, ptr %slot362, align 8
  %cv2302 = trunc i64 %v2301 to i32
  %call2303 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2298, i64 %v2299, i64 %v2300, i32 %cv2302) nomerge, !dbg !150
  store i32 %call2303, ptr %slot389, align 8
  %v2304 = load i32, ptr %slot389, align 8
  %cv2305 = zext i32 %v2304 to i64
  %cond2306 = icmp ne i64 %cv2305, 0
  br i1 %cond2306, label %bb_rcsuccess741, label %bb_rcfailure741
bb_rcfailure741:
  %v2307 = load i64, ptr %slot23, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %call2309 = call i32 @myl_rc_take_failure(ptr %p2308) nomerge, !dbg !150
  store i32 %call2309, ptr %slot390, align 8
  %v2310 = load i64, ptr %slot1, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %v2312 = load i32, ptr %slot390, align 8
  %call2313 = call i32 @myl_qbe_rc_status(ptr %p2311, i32 %v2312) nomerge, !dbg !150
  store i32 %call2313, ptr %slot391, align 8
  br label %bb_failure
bb_rcsuccess741:
  br label %bb_rcmoved710
bb_rcmoved710:
  %v2314 = load i64, ptr %slot6, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 0, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot9, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  store i32 2, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  %v2318 = load i64, ptr %slot8, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  store i32 1, ptr %p2319, align 4, !alias.scope !3, !noalias !4
  %v2320 = load i64, ptr %slot11, align 8
  store i64 %v2320, ptr %slot392, align 8
  %v2321 = load i64, ptr %slot8, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i32 0, ptr %p2322, align 4, !alias.scope !3, !noalias !4
  %v2323 = load i64, ptr %slot6, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  %ld2325 = load i32, ptr %p2324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2325, ptr %slot393, align 8
  %v2326 = load i32, ptr %slot393, align 8
  %cv2327 = zext i32 %v2326 to i64
  %cond2328 = icmp ne i64 %cv2327, 0
  br i1 %cond2328, label %bb_rcslotdrop751, label %bb_rcslotdone751
bb_rcslotdrop751:
  %v2329 = load i64, ptr %slot6, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  store i32 0, ptr %p2330, align 4, !alias.scope !3, !noalias !4
  %v2331 = load i64, ptr %slot10, align 8
  store i64 %v2331, ptr %slot394, align 8
  %v2332 = load i64, ptr %slot7, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %ld2334 = load i32, ptr %p2333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2334, ptr %slot395, align 8
  %v2335 = load i32, ptr %slot395, align 8
  %op2336 = and i32 %v2335, 28
  store i32 %op2336, ptr %slot396, align 8
  %v2337 = load i32, ptr %slot396, align 8
  %cv2338 = zext i32 %v2337 to i64
  %cond2339 = icmp ne i64 %cv2338, 0
  br i1 %cond2339, label %bb_rcslotrole751, label %bb_rcslotowner751
bb_rcslotrole751:
  %v2340 = load i64, ptr %slot23, align 8
  store i64 %v2340, ptr %slot397, align 8
  %v2341 = load i64, ptr %slot397, align 8
  %v2342 = load i64, ptr %slot394, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2341, i64 %v2342) nomerge, !dbg !150
  br label %bb_rcslotdone751
bb_rcslotowner751:
  %v2343 = load i64, ptr %slot23, align 8
  store i64 %v2343, ptr %slot398, align 8
  %v2344 = load i64, ptr %slot398, align 8
  %v2345 = load i64, ptr %slot394, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2344, i64 %v2345) nomerge, !dbg !150
  br label %bb_rcslotdone751
bb_rcslotdone751:
  %v2346 = load i64, ptr %slot392, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2347, i64 48, i1 false)
  ret void
bb_i39:
  %v2348 = load i64, ptr %slot17, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  store i64 0, ptr %p2349, align 8, !alias.scope !3, !noalias !4
  %v2350 = load i64, ptr %slot17, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  %ld2352 = load i64, ptr %p2351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2352, ptr %slot399, align 8
  %v2353 = load i64, ptr %slot399, align 8
  %cond2354 = icmp ne i64 %v2353, 0
  br i1 %cond2354, label %bb_success814, label %bb_failed814
bb_failed814:
  %v2355 = load i64, ptr %slot1, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  call void @myl_qbe_fail_assert(ptr %p2356) nomerge, !dbg !152
  unreachable
bb_success814:
  %v2357 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult401, i64 %v2357) nomerge, !dbg !154
  %addr2358 = ptrtoint ptr %callresult401 to i64
  store i64 %addr2358, ptr %slot400, align 8
  %v2359 = load i64, ptr %slot400, align 8
  %v2360 = load i64, ptr %slot17, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  store i64 %v2359, ptr %p2361, align 8, !alias.scope !3, !noalias !4
  %v2362 = load i64, ptr %slot17, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %ld2364 = load i64, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2364, ptr %slot402, align 8
  %v2365 = load i64, ptr %slot11, align 8
  store i64 %v2365, ptr %slot403, align 8
  %v2366 = load i64, ptr %slot402, align 8
  %v2367 = load i64, ptr %slot403, align 8
  %p2368 = inttoptr i64 %v2366 to ptr
  %p2369 = inttoptr i64 %v2367 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2369, ptr %p2368, i64 48, i1 false)
  %v2370 = load i64, ptr %slot9, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i32 2, ptr %p2371, align 4, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot8, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i32 1, ptr %p2373, align 4, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot10, align 8
  store i64 %v2374, ptr %slot404, align 8
  %v2375 = load i64, ptr %slot11, align 8
  store i64 %v2375, ptr %slot405, align 8
  %v2376 = load i64, ptr %slot405, align 8
  %v2377 = load i64, ptr %slot404, align 8
  %p2378 = inttoptr i64 %v2376 to ptr
  %p2379 = inttoptr i64 %v2377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2379, ptr %p2378, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot7, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i32 2, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot9, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i32, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2384, ptr %slot406, align 8
  %v2385 = load i32, ptr %slot406, align 8
  %v2386 = load i64, ptr %slot7, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i32 %v2385, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot8, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  store i32 0, ptr %p2389, align 4, !alias.scope !3, !noalias !4
  %v2390 = load i64, ptr %slot6, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i32 1, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  %v2392 = load i64, ptr %slot404, align 8
  %v2393 = load i64, ptr %slot17, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  store i64 %v2392, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  %v2395 = load i64, ptr %slot17, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  %ld2397 = load i64, ptr %p2396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2397, ptr %slot407, align 8
  %v2398 = load i64, ptr %slot17, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  %ld2400 = load i64, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2400, ptr %slot408, align 8
  %v2401 = load i64, ptr %slot11, align 8
  store i64 %v2401, ptr %slot409, align 8
  %v2402 = load i64, ptr %slot24, align 8
  store i64 %v2402, ptr %slot410, align 8
  %v2403 = load i64, ptr %slot408, align 8
  %op2404 = add i64 %v2403, 16
  store i64 %op2404, ptr %slot411, align 8
  %v2405 = load i64, ptr %slot411, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  %ld2407 = load i64, ptr %p2406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2407, ptr %slot412, align 8
  %v2408 = load i64, ptr %slot412, align 8
  %cmp2409 = icmp ne i64 %v2408, 0
  %cv2410 = zext i1 %cmp2409 to i32
  store i32 %cv2410, ptr %slot413, align 8
  %v2411 = load i32, ptr %slot413, align 8
  %cv2412 = zext i32 %v2411 to i64
  %cond2413 = icmp ne i64 %cv2412, 0
  br i1 %cond2413, label %bb_rcmoveheader835, label %bb_rcmovenext835
bb_rcmoveheader835:
  %v2414 = load i64, ptr %slot412, align 8
  %op2415 = sub i64 %v2414, 16
  store i64 %op2415, ptr %slot414, align 8
  %v2416 = load i64, ptr %slot412, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %rgep2418 = getelementptr i8, ptr %p2417, i64 -16
  %ld2419 = load i64, ptr %rgep2418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2419, ptr %slot415, align 8
  %v2420 = load i64, ptr %slot415, align 8
  %op2421 = and i64 %v2420, 5764607523034234881
  store i64 %op2421, ptr %slot416, align 8
  %v2422 = load i64, ptr %slot416, align 8
  %cmp2423 = icmp ne i64 %v2422, 0
  %cv2424 = zext i1 %cmp2423 to i32
  store i32 %cv2424, ptr %slot417, align 8
  %v2425 = load i32, ptr %slot417, align 8
  %cv2426 = zext i32 %v2425 to i64
  %cond2427 = icmp ne i64 %cv2426, 0
  br i1 %cond2427, label %bb_rcmoveslow832, label %bb_rcmovenext835
bb_rcmovenext835:
  %v2428 = load i64, ptr %slot408, align 8
  %op2429 = add i64 %v2428, 24
  store i64 %op2429, ptr %slot418, align 8
  %v2430 = load i64, ptr %slot418, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i64, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2432, ptr %slot419, align 8
  %v2433 = load i64, ptr %slot419, align 8
  %cmp2434 = icmp ne i64 %v2433, 0
  %cv2435 = zext i1 %cmp2434 to i32
  store i32 %cv2435, ptr %slot420, align 8
  %v2436 = load i32, ptr %slot420, align 8
  %cv2437 = zext i32 %v2436 to i64
  %cond2438 = icmp ne i64 %cv2437, 0
  br i1 %cond2438, label %bb_rcmoveheader843, label %bb_rcmovenext843
bb_rcmoveheader843:
  %v2439 = load i64, ptr %slot419, align 8
  %op2440 = sub i64 %v2439, 16
  store i64 %op2440, ptr %slot421, align 8
  %v2441 = load i64, ptr %slot419, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  %rgep2443 = getelementptr i8, ptr %p2442, i64 -16
  %ld2444 = load i64, ptr %rgep2443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2444, ptr %slot422, align 8
  %v2445 = load i64, ptr %slot422, align 8
  %op2446 = and i64 %v2445, 5764607523034234881
  store i64 %op2446, ptr %slot423, align 8
  %v2447 = load i64, ptr %slot423, align 8
  %cmp2448 = icmp ne i64 %v2447, 0
  %cv2449 = zext i1 %cmp2448 to i32
  store i32 %cv2449, ptr %slot424, align 8
  %v2450 = load i32, ptr %slot424, align 8
  %cv2451 = zext i32 %v2450 to i64
  %cond2452 = icmp ne i64 %cv2451, 0
  br i1 %cond2452, label %bb_rcmoveslow832, label %bb_rcmovenext843
bb_rcmovenext843:
  %v2453 = load i64, ptr %slot408, align 8
  %op2454 = add i64 %v2453, 32
  store i64 %op2454, ptr %slot425, align 8
  %v2455 = load i64, ptr %slot425, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i64, ptr %p2456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2457, ptr %slot426, align 8
  %v2458 = load i64, ptr %slot426, align 8
  %cmp2459 = icmp ne i64 %v2458, 0
  %cv2460 = zext i1 %cmp2459 to i32
  store i32 %cv2460, ptr %slot427, align 8
  %v2461 = load i32, ptr %slot427, align 8
  %cv2462 = zext i32 %v2461 to i64
  %cond2463 = icmp ne i64 %cv2462, 0
  br i1 %cond2463, label %bb_rcmoveheader851, label %bb_rcmovenext851
bb_rcmoveheader851:
  %v2464 = load i64, ptr %slot426, align 8
  %op2465 = sub i64 %v2464, 16
  store i64 %op2465, ptr %slot428, align 8
  %v2466 = load i64, ptr %slot426, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %rgep2468 = getelementptr i8, ptr %p2467, i64 -16
  %ld2469 = load i64, ptr %rgep2468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2469, ptr %slot429, align 8
  %v2470 = load i64, ptr %slot429, align 8
  %op2471 = and i64 %v2470, 5764607523034234881
  store i64 %op2471, ptr %slot430, align 8
  %v2472 = load i64, ptr %slot430, align 8
  %cmp2473 = icmp ne i64 %v2472, 0
  %cv2474 = zext i1 %cmp2473 to i32
  store i32 %cv2474, ptr %slot431, align 8
  %v2475 = load i32, ptr %slot431, align 8
  %cv2476 = zext i32 %v2475 to i64
  %cond2477 = icmp ne i64 %cv2476, 0
  br i1 %cond2477, label %bb_rcmoveslow832, label %bb_rcmovenext851
bb_rcmovenext851:
  %v2478 = load i64, ptr %slot408, align 8
  %v2479 = load i64, ptr %slot409, align 8
  %p2480 = inttoptr i64 %v2478 to ptr
  %p2481 = inttoptr i64 %v2479 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2481, ptr %p2480, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot408, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i64 0, ptr %p2483, align 8, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot408, align 8
  %op2485 = add i64 %v2484, 8
  store i64 %op2485, ptr %slot432, align 8
  %v2486 = load i64, ptr %slot432, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i64 0, ptr %p2487, align 8, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot408, align 8
  %op2489 = add i64 %v2488, 16
  store i64 %op2489, ptr %slot433, align 8
  %v2490 = load i64, ptr %slot433, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  store i64 0, ptr %p2491, align 8, !alias.scope !3, !noalias !4
  %v2492 = load i64, ptr %slot408, align 8
  %op2493 = add i64 %v2492, 24
  store i64 %op2493, ptr %slot434, align 8
  %v2494 = load i64, ptr %slot434, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i64 0, ptr %p2495, align 8, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot408, align 8
  %op2497 = add i64 %v2496, 32
  store i64 %op2497, ptr %slot435, align 8
  %v2498 = load i64, ptr %slot435, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  store i64 0, ptr %p2499, align 8, !alias.scope !3, !noalias !4
  %v2500 = load i64, ptr %slot408, align 8
  %op2501 = add i64 %v2500, 40
  store i64 %op2501, ptr %slot436, align 8
  %v2502 = load i64, ptr %slot436, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  store i64 0, ptr %p2503, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved832
bb_rcmoveslow832:
  %v2504 = load i64, ptr %slot23, align 8
  %v2505 = load i64, ptr %slot409, align 8
  %v2506 = load i64, ptr %slot408, align 8
  %v2507 = load i64, ptr %slot410, align 8
  %cv2508 = trunc i64 %v2507 to i32
  %call2509 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2504, i64 %v2505, i64 %v2506, i32 %cv2508) nomerge, !dbg !156
  store i32 %call2509, ptr %slot437, align 8
  %v2510 = load i32, ptr %slot437, align 8
  %cv2511 = zext i32 %v2510 to i64
  %cond2512 = icmp ne i64 %cv2511, 0
  br i1 %cond2512, label %bb_rcsuccess863, label %bb_rcfailure863
bb_rcfailure863:
  %v2513 = load i64, ptr %slot23, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %call2515 = call i32 @myl_rc_take_failure(ptr %p2514) nomerge, !dbg !156
  store i32 %call2515, ptr %slot438, align 8
  %v2516 = load i64, ptr %slot1, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  %v2518 = load i32, ptr %slot438, align 8
  %call2519 = call i32 @myl_qbe_rc_status(ptr %p2517, i32 %v2518) nomerge, !dbg !156
  store i32 %call2519, ptr %slot439, align 8
  br label %bb_failure
bb_rcsuccess863:
  br label %bb_rcmoved832
bb_rcmoved832:
  %v2520 = load i64, ptr %slot6, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  store i32 0, ptr %p2521, align 4, !alias.scope !3, !noalias !4
  %v2522 = load i64, ptr %slot9, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i32 2, ptr %p2523, align 4, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot8, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  store i32 1, ptr %p2525, align 4, !alias.scope !3, !noalias !4
  %v2526 = load i64, ptr %slot11, align 8
  store i64 %v2526, ptr %slot440, align 8
  %v2527 = load i64, ptr %slot8, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i32 0, ptr %p2528, align 4, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot6, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i32, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2531, ptr %slot441, align 8
  %v2532 = load i32, ptr %slot441, align 8
  %cv2533 = zext i32 %v2532 to i64
  %cond2534 = icmp ne i64 %cv2533, 0
  br i1 %cond2534, label %bb_rcslotdrop873, label %bb_rcslotdone873
bb_rcslotdrop873:
  %v2535 = load i64, ptr %slot6, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 0, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  %v2537 = load i64, ptr %slot10, align 8
  store i64 %v2537, ptr %slot442, align 8
  %v2538 = load i64, ptr %slot7, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %ld2540 = load i32, ptr %p2539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2540, ptr %slot443, align 8
  %v2541 = load i32, ptr %slot443, align 8
  %op2542 = and i32 %v2541, 28
  store i32 %op2542, ptr %slot444, align 8
  %v2543 = load i32, ptr %slot444, align 8
  %cv2544 = zext i32 %v2543 to i64
  %cond2545 = icmp ne i64 %cv2544, 0
  br i1 %cond2545, label %bb_rcslotrole873, label %bb_rcslotowner873
bb_rcslotrole873:
  %v2546 = load i64, ptr %slot23, align 8
  store i64 %v2546, ptr %slot445, align 8
  %v2547 = load i64, ptr %slot445, align 8
  %v2548 = load i64, ptr %slot442, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2547, i64 %v2548) nomerge, !dbg !156
  br label %bb_rcslotdone873
bb_rcslotowner873:
  %v2549 = load i64, ptr %slot23, align 8
  store i64 %v2549, ptr %slot446, align 8
  %v2550 = load i64, ptr %slot446, align 8
  %v2551 = load i64, ptr %slot442, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2550, i64 %v2551) nomerge, !dbg !156
  br label %bb_rcslotdone873
bb_rcslotdone873:
  %v2552 = load i64, ptr %slot440, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2553, i64 48, i1 false)
  ret void
bb_i43:
  %v2554 = load i64, ptr %slot17, align 8
  %p2555 = inttoptr i64 %v2554 to ptr
  store i64 0, ptr %p2555, align 8, !alias.scope !3, !noalias !4
  %v2556 = load i64, ptr %slot17, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i64, ptr %p2557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2558, ptr %slot447, align 8
  %v2559 = load i64, ptr %slot447, align 8
  %cond2560 = icmp ne i64 %v2559, 0
  br i1 %cond2560, label %bb_success936, label %bb_failed936
bb_failed936:
  %v2561 = load i64, ptr %slot1, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  call void @myl_qbe_fail_assert(ptr %p2562) nomerge, !dbg !158
  unreachable
bb_success936:
  %v2563 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult449, i64 %v2563) nomerge, !dbg !160
  %addr2564 = ptrtoint ptr %callresult449 to i64
  store i64 %addr2564, ptr %slot448, align 8
  %v2565 = load i64, ptr %slot448, align 8
  %v2566 = load i64, ptr %slot17, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i64 %v2565, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot17, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  %ld2570 = load i64, ptr %p2569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2570, ptr %slot450, align 8
  %v2571 = load i64, ptr %slot11, align 8
  store i64 %v2571, ptr %slot451, align 8
  %v2572 = load i64, ptr %slot450, align 8
  %v2573 = load i64, ptr %slot451, align 8
  %p2574 = inttoptr i64 %v2572 to ptr
  %p2575 = inttoptr i64 %v2573 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2575, ptr %p2574, i64 48, i1 false)
  %v2576 = load i64, ptr %slot9, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  store i32 2, ptr %p2577, align 4, !alias.scope !3, !noalias !4
  %v2578 = load i64, ptr %slot8, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  store i32 1, ptr %p2579, align 4, !alias.scope !3, !noalias !4
  %v2580 = load i64, ptr %slot10, align 8
  store i64 %v2580, ptr %slot452, align 8
  %v2581 = load i64, ptr %slot11, align 8
  store i64 %v2581, ptr %slot453, align 8
  %v2582 = load i64, ptr %slot453, align 8
  %v2583 = load i64, ptr %slot452, align 8
  %p2584 = inttoptr i64 %v2582 to ptr
  %p2585 = inttoptr i64 %v2583 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2585, ptr %p2584, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2586 = load i64, ptr %slot7, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  store i32 2, ptr %p2587, align 4, !alias.scope !3, !noalias !4
  %v2588 = load i64, ptr %slot9, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %ld2590 = load i32, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2590, ptr %slot454, align 8
  %v2591 = load i32, ptr %slot454, align 8
  %v2592 = load i64, ptr %slot7, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  store i32 %v2591, ptr %p2593, align 4, !alias.scope !3, !noalias !4
  %v2594 = load i64, ptr %slot8, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  store i32 0, ptr %p2595, align 4, !alias.scope !3, !noalias !4
  %v2596 = load i64, ptr %slot6, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  store i32 1, ptr %p2597, align 4, !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot452, align 8
  %v2599 = load i64, ptr %slot17, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  store i64 %v2598, ptr %p2600, align 8, !alias.scope !3, !noalias !4
  %v2601 = load i64, ptr %slot17, align 8
  %p2602 = inttoptr i64 %v2601 to ptr
  %ld2603 = load i64, ptr %p2602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2603, ptr %slot455, align 8
  %v2604 = load i64, ptr %slot17, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i64, ptr %p2605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2606, ptr %slot456, align 8
  %v2607 = load i64, ptr %slot11, align 8
  store i64 %v2607, ptr %slot457, align 8
  %v2608 = load i64, ptr %slot24, align 8
  store i64 %v2608, ptr %slot458, align 8
  %v2609 = load i64, ptr %slot456, align 8
  %op2610 = add i64 %v2609, 16
  store i64 %op2610, ptr %slot459, align 8
  %v2611 = load i64, ptr %slot459, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i64, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2613, ptr %slot460, align 8
  %v2614 = load i64, ptr %slot460, align 8
  %cmp2615 = icmp ne i64 %v2614, 0
  %cv2616 = zext i1 %cmp2615 to i32
  store i32 %cv2616, ptr %slot461, align 8
  %v2617 = load i32, ptr %slot461, align 8
  %cv2618 = zext i32 %v2617 to i64
  %cond2619 = icmp ne i64 %cv2618, 0
  br i1 %cond2619, label %bb_rcmoveheader957, label %bb_rcmovenext957
bb_rcmoveheader957:
  %v2620 = load i64, ptr %slot460, align 8
  %op2621 = sub i64 %v2620, 16
  store i64 %op2621, ptr %slot462, align 8
  %v2622 = load i64, ptr %slot460, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %rgep2624 = getelementptr i8, ptr %p2623, i64 -16
  %ld2625 = load i64, ptr %rgep2624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2625, ptr %slot463, align 8
  %v2626 = load i64, ptr %slot463, align 8
  %op2627 = and i64 %v2626, 5764607523034234881
  store i64 %op2627, ptr %slot464, align 8
  %v2628 = load i64, ptr %slot464, align 8
  %cmp2629 = icmp ne i64 %v2628, 0
  %cv2630 = zext i1 %cmp2629 to i32
  store i32 %cv2630, ptr %slot465, align 8
  %v2631 = load i32, ptr %slot465, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcmoveslow954, label %bb_rcmovenext957
bb_rcmovenext957:
  %v2634 = load i64, ptr %slot456, align 8
  %op2635 = add i64 %v2634, 24
  store i64 %op2635, ptr %slot466, align 8
  %v2636 = load i64, ptr %slot466, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i64, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2638, ptr %slot467, align 8
  %v2639 = load i64, ptr %slot467, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot468, align 8
  %v2642 = load i32, ptr %slot468, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcmoveheader965, label %bb_rcmovenext965
bb_rcmoveheader965:
  %v2645 = load i64, ptr %slot467, align 8
  %op2646 = sub i64 %v2645, 16
  store i64 %op2646, ptr %slot469, align 8
  %v2647 = load i64, ptr %slot467, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -16
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot470, align 8
  %v2651 = load i64, ptr %slot470, align 8
  %op2652 = and i64 %v2651, 5764607523034234881
  store i64 %op2652, ptr %slot471, align 8
  %v2653 = load i64, ptr %slot471, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot472, align 8
  %v2656 = load i32, ptr %slot472, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcmoveslow954, label %bb_rcmovenext965
bb_rcmovenext965:
  %v2659 = load i64, ptr %slot456, align 8
  %op2660 = add i64 %v2659, 32
  store i64 %op2660, ptr %slot473, align 8
  %v2661 = load i64, ptr %slot473, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %ld2663 = load i64, ptr %p2662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2663, ptr %slot474, align 8
  %v2664 = load i64, ptr %slot474, align 8
  %cmp2665 = icmp ne i64 %v2664, 0
  %cv2666 = zext i1 %cmp2665 to i32
  store i32 %cv2666, ptr %slot475, align 8
  %v2667 = load i32, ptr %slot475, align 8
  %cv2668 = zext i32 %v2667 to i64
  %cond2669 = icmp ne i64 %cv2668, 0
  br i1 %cond2669, label %bb_rcmoveheader973, label %bb_rcmovenext973
bb_rcmoveheader973:
  %v2670 = load i64, ptr %slot474, align 8
  %op2671 = sub i64 %v2670, 16
  store i64 %op2671, ptr %slot476, align 8
  %v2672 = load i64, ptr %slot474, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  %rgep2674 = getelementptr i8, ptr %p2673, i64 -16
  %ld2675 = load i64, ptr %rgep2674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2675, ptr %slot477, align 8
  %v2676 = load i64, ptr %slot477, align 8
  %op2677 = and i64 %v2676, 5764607523034234881
  store i64 %op2677, ptr %slot478, align 8
  %v2678 = load i64, ptr %slot478, align 8
  %cmp2679 = icmp ne i64 %v2678, 0
  %cv2680 = zext i1 %cmp2679 to i32
  store i32 %cv2680, ptr %slot479, align 8
  %v2681 = load i32, ptr %slot479, align 8
  %cv2682 = zext i32 %v2681 to i64
  %cond2683 = icmp ne i64 %cv2682, 0
  br i1 %cond2683, label %bb_rcmoveslow954, label %bb_rcmovenext973
bb_rcmovenext973:
  %v2684 = load i64, ptr %slot456, align 8
  %v2685 = load i64, ptr %slot457, align 8
  %p2686 = inttoptr i64 %v2684 to ptr
  %p2687 = inttoptr i64 %v2685 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2687, ptr %p2686, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2688 = load i64, ptr %slot456, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i64 0, ptr %p2689, align 8, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot456, align 8
  %op2691 = add i64 %v2690, 8
  store i64 %op2691, ptr %slot480, align 8
  %v2692 = load i64, ptr %slot480, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i64 0, ptr %p2693, align 8, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot456, align 8
  %op2695 = add i64 %v2694, 16
  store i64 %op2695, ptr %slot481, align 8
  %v2696 = load i64, ptr %slot481, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i64 0, ptr %p2697, align 8, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot456, align 8
  %op2699 = add i64 %v2698, 24
  store i64 %op2699, ptr %slot482, align 8
  %v2700 = load i64, ptr %slot482, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  store i64 0, ptr %p2701, align 8, !alias.scope !3, !noalias !4
  %v2702 = load i64, ptr %slot456, align 8
  %op2703 = add i64 %v2702, 32
  store i64 %op2703, ptr %slot483, align 8
  %v2704 = load i64, ptr %slot483, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i64 0, ptr %p2705, align 8, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot456, align 8
  %op2707 = add i64 %v2706, 40
  store i64 %op2707, ptr %slot484, align 8
  %v2708 = load i64, ptr %slot484, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  store i64 0, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved954
bb_rcmoveslow954:
  %v2710 = load i64, ptr %slot23, align 8
  %v2711 = load i64, ptr %slot457, align 8
  %v2712 = load i64, ptr %slot456, align 8
  %v2713 = load i64, ptr %slot458, align 8
  %cv2714 = trunc i64 %v2713 to i32
  %call2715 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2710, i64 %v2711, i64 %v2712, i32 %cv2714) nomerge, !dbg !162
  store i32 %call2715, ptr %slot485, align 8
  %v2716 = load i32, ptr %slot485, align 8
  %cv2717 = zext i32 %v2716 to i64
  %cond2718 = icmp ne i64 %cv2717, 0
  br i1 %cond2718, label %bb_rcsuccess985, label %bb_rcfailure985
bb_rcfailure985:
  %v2719 = load i64, ptr %slot23, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %call2721 = call i32 @myl_rc_take_failure(ptr %p2720) nomerge, !dbg !162
  store i32 %call2721, ptr %slot486, align 8
  %v2722 = load i64, ptr %slot1, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %v2724 = load i32, ptr %slot486, align 8
  %call2725 = call i32 @myl_qbe_rc_status(ptr %p2723, i32 %v2724) nomerge, !dbg !162
  store i32 %call2725, ptr %slot487, align 8
  br label %bb_failure
bb_rcsuccess985:
  br label %bb_rcmoved954
bb_rcmoved954:
  %v2726 = load i64, ptr %slot6, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i32 0, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot9, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  store i32 2, ptr %p2729, align 4, !alias.scope !3, !noalias !4
  %v2730 = load i64, ptr %slot8, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  store i32 1, ptr %p2731, align 4, !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot11, align 8
  store i64 %v2732, ptr %slot488, align 8
  %v2733 = load i64, ptr %slot8, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i32 0, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot6, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  %ld2737 = load i32, ptr %p2736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2737, ptr %slot489, align 8
  %v2738 = load i32, ptr %slot489, align 8
  %cv2739 = zext i32 %v2738 to i64
  %cond2740 = icmp ne i64 %cv2739, 0
  br i1 %cond2740, label %bb_rcslotdrop995, label %bb_rcslotdone995
bb_rcslotdrop995:
  %v2741 = load i64, ptr %slot6, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i32 0, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot10, align 8
  store i64 %v2743, ptr %slot490, align 8
  %v2744 = load i64, ptr %slot7, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  %ld2746 = load i32, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2746, ptr %slot491, align 8
  %v2747 = load i32, ptr %slot491, align 8
  %op2748 = and i32 %v2747, 28
  store i32 %op2748, ptr %slot492, align 8
  %v2749 = load i32, ptr %slot492, align 8
  %cv2750 = zext i32 %v2749 to i64
  %cond2751 = icmp ne i64 %cv2750, 0
  br i1 %cond2751, label %bb_rcslotrole995, label %bb_rcslotowner995
bb_rcslotrole995:
  %v2752 = load i64, ptr %slot23, align 8
  store i64 %v2752, ptr %slot493, align 8
  %v2753 = load i64, ptr %slot493, align 8
  %v2754 = load i64, ptr %slot490, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2753, i64 %v2754) nomerge, !dbg !162
  br label %bb_rcslotdone995
bb_rcslotowner995:
  %v2755 = load i64, ptr %slot23, align 8
  store i64 %v2755, ptr %slot494, align 8
  %v2756 = load i64, ptr %slot494, align 8
  %v2757 = load i64, ptr %slot490, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2756, i64 %v2757) nomerge, !dbg !162
  br label %bb_rcslotdone995
bb_rcslotdone995:
  %v2758 = load i64, ptr %slot488, align 8
  %p2759 = inttoptr i64 %v2758 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2759, i64 48, i1 false)
  ret void
bb_i47:
  %v2760 = load i64, ptr %slot17, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  store i64 0, ptr %p2761, align 8, !alias.scope !3, !noalias !4
  %v2762 = load i64, ptr %slot17, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  %ld2764 = load i64, ptr %p2763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2764, ptr %slot495, align 8
  %v2765 = load i64, ptr %slot495, align 8
  %cond2766 = icmp ne i64 %v2765, 0
  br i1 %cond2766, label %bb_success1058, label %bb_failed1058
bb_failed1058:
  %v2767 = load i64, ptr %slot1, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  call void @myl_qbe_fail_assert(ptr %p2768) nomerge, !dbg !164
  unreachable
bb_success1058:
  %v2769 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult497, i64 %v2769) nomerge, !dbg !166
  %addr2770 = ptrtoint ptr %callresult497 to i64
  store i64 %addr2770, ptr %slot496, align 8
  %v2771 = load i64, ptr %slot496, align 8
  %v2772 = load i64, ptr %slot17, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  store i64 %v2771, ptr %p2773, align 8, !alias.scope !3, !noalias !4
  %v2774 = load i64, ptr %slot17, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %ld2776 = load i64, ptr %p2775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2776, ptr %slot498, align 8
  %v2777 = load i64, ptr %slot11, align 8
  store i64 %v2777, ptr %slot499, align 8
  %v2778 = load i64, ptr %slot498, align 8
  %v2779 = load i64, ptr %slot499, align 8
  %p2780 = inttoptr i64 %v2778 to ptr
  %p2781 = inttoptr i64 %v2779 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2781, ptr %p2780, i64 48, i1 false)
  %v2782 = load i64, ptr %slot9, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i32 2, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot8, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  store i32 1, ptr %p2785, align 4, !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot10, align 8
  store i64 %v2786, ptr %slot500, align 8
  %v2787 = load i64, ptr %slot11, align 8
  store i64 %v2787, ptr %slot501, align 8
  %v2788 = load i64, ptr %slot501, align 8
  %v2789 = load i64, ptr %slot500, align 8
  %p2790 = inttoptr i64 %v2788 to ptr
  %p2791 = inttoptr i64 %v2789 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2791, ptr %p2790, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2792 = load i64, ptr %slot7, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  store i32 2, ptr %p2793, align 4, !alias.scope !3, !noalias !4
  %v2794 = load i64, ptr %slot9, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %ld2796 = load i32, ptr %p2795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2796, ptr %slot502, align 8
  %v2797 = load i32, ptr %slot502, align 8
  %v2798 = load i64, ptr %slot7, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  store i32 %v2797, ptr %p2799, align 4, !alias.scope !3, !noalias !4
  %v2800 = load i64, ptr %slot8, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  store i32 0, ptr %p2801, align 4, !alias.scope !3, !noalias !4
  %v2802 = load i64, ptr %slot6, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  store i32 1, ptr %p2803, align 4, !alias.scope !3, !noalias !4
  %v2804 = load i64, ptr %slot500, align 8
  %v2805 = load i64, ptr %slot17, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  store i64 %v2804, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  %v2807 = load i64, ptr %slot17, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  %ld2809 = load i64, ptr %p2808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2809, ptr %slot503, align 8
  %v2810 = load i64, ptr %slot17, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  %ld2812 = load i64, ptr %p2811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2812, ptr %slot504, align 8
  %v2813 = load i64, ptr %slot11, align 8
  store i64 %v2813, ptr %slot505, align 8
  %v2814 = load i64, ptr %slot24, align 8
  store i64 %v2814, ptr %slot506, align 8
  %v2815 = load i64, ptr %slot504, align 8
  %op2816 = add i64 %v2815, 16
  store i64 %op2816, ptr %slot507, align 8
  %v2817 = load i64, ptr %slot507, align 8
  %p2818 = inttoptr i64 %v2817 to ptr
  %ld2819 = load i64, ptr %p2818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2819, ptr %slot508, align 8
  %v2820 = load i64, ptr %slot508, align 8
  %cmp2821 = icmp ne i64 %v2820, 0
  %cv2822 = zext i1 %cmp2821 to i32
  store i32 %cv2822, ptr %slot509, align 8
  %v2823 = load i32, ptr %slot509, align 8
  %cv2824 = zext i32 %v2823 to i64
  %cond2825 = icmp ne i64 %cv2824, 0
  br i1 %cond2825, label %bb_rcmoveheader1079, label %bb_rcmovenext1079
bb_rcmoveheader1079:
  %v2826 = load i64, ptr %slot508, align 8
  %op2827 = sub i64 %v2826, 16
  store i64 %op2827, ptr %slot510, align 8
  %v2828 = load i64, ptr %slot508, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  %rgep2830 = getelementptr i8, ptr %p2829, i64 -16
  %ld2831 = load i64, ptr %rgep2830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2831, ptr %slot511, align 8
  %v2832 = load i64, ptr %slot511, align 8
  %op2833 = and i64 %v2832, 5764607523034234881
  store i64 %op2833, ptr %slot512, align 8
  %v2834 = load i64, ptr %slot512, align 8
  %cmp2835 = icmp ne i64 %v2834, 0
  %cv2836 = zext i1 %cmp2835 to i32
  store i32 %cv2836, ptr %slot513, align 8
  %v2837 = load i32, ptr %slot513, align 8
  %cv2838 = zext i32 %v2837 to i64
  %cond2839 = icmp ne i64 %cv2838, 0
  br i1 %cond2839, label %bb_rcmoveslow1076, label %bb_rcmovenext1079
bb_rcmovenext1079:
  %v2840 = load i64, ptr %slot504, align 8
  %op2841 = add i64 %v2840, 24
  store i64 %op2841, ptr %slot514, align 8
  %v2842 = load i64, ptr %slot514, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %ld2844 = load i64, ptr %p2843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2844, ptr %slot515, align 8
  %v2845 = load i64, ptr %slot515, align 8
  %cmp2846 = icmp ne i64 %v2845, 0
  %cv2847 = zext i1 %cmp2846 to i32
  store i32 %cv2847, ptr %slot516, align 8
  %v2848 = load i32, ptr %slot516, align 8
  %cv2849 = zext i32 %v2848 to i64
  %cond2850 = icmp ne i64 %cv2849, 0
  br i1 %cond2850, label %bb_rcmoveheader1087, label %bb_rcmovenext1087
bb_rcmoveheader1087:
  %v2851 = load i64, ptr %slot515, align 8
  %op2852 = sub i64 %v2851, 16
  store i64 %op2852, ptr %slot517, align 8
  %v2853 = load i64, ptr %slot515, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  %rgep2855 = getelementptr i8, ptr %p2854, i64 -16
  %ld2856 = load i64, ptr %rgep2855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2856, ptr %slot518, align 8
  %v2857 = load i64, ptr %slot518, align 8
  %op2858 = and i64 %v2857, 5764607523034234881
  store i64 %op2858, ptr %slot519, align 8
  %v2859 = load i64, ptr %slot519, align 8
  %cmp2860 = icmp ne i64 %v2859, 0
  %cv2861 = zext i1 %cmp2860 to i32
  store i32 %cv2861, ptr %slot520, align 8
  %v2862 = load i32, ptr %slot520, align 8
  %cv2863 = zext i32 %v2862 to i64
  %cond2864 = icmp ne i64 %cv2863, 0
  br i1 %cond2864, label %bb_rcmoveslow1076, label %bb_rcmovenext1087
bb_rcmovenext1087:
  %v2865 = load i64, ptr %slot504, align 8
  %op2866 = add i64 %v2865, 32
  store i64 %op2866, ptr %slot521, align 8
  %v2867 = load i64, ptr %slot521, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %ld2869 = load i64, ptr %p2868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2869, ptr %slot522, align 8
  %v2870 = load i64, ptr %slot522, align 8
  %cmp2871 = icmp ne i64 %v2870, 0
  %cv2872 = zext i1 %cmp2871 to i32
  store i32 %cv2872, ptr %slot523, align 8
  %v2873 = load i32, ptr %slot523, align 8
  %cv2874 = zext i32 %v2873 to i64
  %cond2875 = icmp ne i64 %cv2874, 0
  br i1 %cond2875, label %bb_rcmoveheader1095, label %bb_rcmovenext1095
bb_rcmoveheader1095:
  %v2876 = load i64, ptr %slot522, align 8
  %op2877 = sub i64 %v2876, 16
  store i64 %op2877, ptr %slot524, align 8
  %v2878 = load i64, ptr %slot522, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %rgep2880 = getelementptr i8, ptr %p2879, i64 -16
  %ld2881 = load i64, ptr %rgep2880, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2881, ptr %slot525, align 8
  %v2882 = load i64, ptr %slot525, align 8
  %op2883 = and i64 %v2882, 5764607523034234881
  store i64 %op2883, ptr %slot526, align 8
  %v2884 = load i64, ptr %slot526, align 8
  %cmp2885 = icmp ne i64 %v2884, 0
  %cv2886 = zext i1 %cmp2885 to i32
  store i32 %cv2886, ptr %slot527, align 8
  %v2887 = load i32, ptr %slot527, align 8
  %cv2888 = zext i32 %v2887 to i64
  %cond2889 = icmp ne i64 %cv2888, 0
  br i1 %cond2889, label %bb_rcmoveslow1076, label %bb_rcmovenext1095
bb_rcmovenext1095:
  %v2890 = load i64, ptr %slot504, align 8
  %v2891 = load i64, ptr %slot505, align 8
  %p2892 = inttoptr i64 %v2890 to ptr
  %p2893 = inttoptr i64 %v2891 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2893, ptr %p2892, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2894 = load i64, ptr %slot504, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  store i64 0, ptr %p2895, align 8, !alias.scope !3, !noalias !4
  %v2896 = load i64, ptr %slot504, align 8
  %op2897 = add i64 %v2896, 8
  store i64 %op2897, ptr %slot528, align 8
  %v2898 = load i64, ptr %slot528, align 8
  %p2899 = inttoptr i64 %v2898 to ptr
  store i64 0, ptr %p2899, align 8, !alias.scope !3, !noalias !4
  %v2900 = load i64, ptr %slot504, align 8
  %op2901 = add i64 %v2900, 16
  store i64 %op2901, ptr %slot529, align 8
  %v2902 = load i64, ptr %slot529, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  store i64 0, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  %v2904 = load i64, ptr %slot504, align 8
  %op2905 = add i64 %v2904, 24
  store i64 %op2905, ptr %slot530, align 8
  %v2906 = load i64, ptr %slot530, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  store i64 0, ptr %p2907, align 8, !alias.scope !3, !noalias !4
  %v2908 = load i64, ptr %slot504, align 8
  %op2909 = add i64 %v2908, 32
  store i64 %op2909, ptr %slot531, align 8
  %v2910 = load i64, ptr %slot531, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  store i64 0, ptr %p2911, align 8, !alias.scope !3, !noalias !4
  %v2912 = load i64, ptr %slot504, align 8
  %op2913 = add i64 %v2912, 40
  store i64 %op2913, ptr %slot532, align 8
  %v2914 = load i64, ptr %slot532, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  store i64 0, ptr %p2915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1076
bb_rcmoveslow1076:
  %v2916 = load i64, ptr %slot23, align 8
  %v2917 = load i64, ptr %slot505, align 8
  %v2918 = load i64, ptr %slot504, align 8
  %v2919 = load i64, ptr %slot506, align 8
  %cv2920 = trunc i64 %v2919 to i32
  %call2921 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2916, i64 %v2917, i64 %v2918, i32 %cv2920) nomerge, !dbg !168
  store i32 %call2921, ptr %slot533, align 8
  %v2922 = load i32, ptr %slot533, align 8
  %cv2923 = zext i32 %v2922 to i64
  %cond2924 = icmp ne i64 %cv2923, 0
  br i1 %cond2924, label %bb_rcsuccess1107, label %bb_rcfailure1107
bb_rcfailure1107:
  %v2925 = load i64, ptr %slot23, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %call2927 = call i32 @myl_rc_take_failure(ptr %p2926) nomerge, !dbg !168
  store i32 %call2927, ptr %slot534, align 8
  %v2928 = load i64, ptr %slot1, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %v2930 = load i32, ptr %slot534, align 8
  %call2931 = call i32 @myl_qbe_rc_status(ptr %p2929, i32 %v2930) nomerge, !dbg !168
  store i32 %call2931, ptr %slot535, align 8
  br label %bb_failure
bb_rcsuccess1107:
  br label %bb_rcmoved1076
bb_rcmoved1076:
  %v2932 = load i64, ptr %slot6, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  store i32 0, ptr %p2933, align 4, !alias.scope !3, !noalias !4
  %v2934 = load i64, ptr %slot9, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  store i32 2, ptr %p2935, align 4, !alias.scope !3, !noalias !4
  %v2936 = load i64, ptr %slot8, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i32 1, ptr %p2937, align 4, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot11, align 8
  store i64 %v2938, ptr %slot536, align 8
  %v2939 = load i64, ptr %slot8, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i32 0, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot6, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  %ld2943 = load i32, ptr %p2942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2943, ptr %slot537, align 8
  %v2944 = load i32, ptr %slot537, align 8
  %cv2945 = zext i32 %v2944 to i64
  %cond2946 = icmp ne i64 %cv2945, 0
  br i1 %cond2946, label %bb_rcslotdrop1117, label %bb_rcslotdone1117
bb_rcslotdrop1117:
  %v2947 = load i64, ptr %slot6, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  store i32 0, ptr %p2948, align 4, !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot10, align 8
  store i64 %v2949, ptr %slot538, align 8
  %v2950 = load i64, ptr %slot7, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  %ld2952 = load i32, ptr %p2951, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2952, ptr %slot539, align 8
  %v2953 = load i32, ptr %slot539, align 8
  %op2954 = and i32 %v2953, 28
  store i32 %op2954, ptr %slot540, align 8
  %v2955 = load i32, ptr %slot540, align 8
  %cv2956 = zext i32 %v2955 to i64
  %cond2957 = icmp ne i64 %cv2956, 0
  br i1 %cond2957, label %bb_rcslotrole1117, label %bb_rcslotowner1117
bb_rcslotrole1117:
  %v2958 = load i64, ptr %slot23, align 8
  store i64 %v2958, ptr %slot541, align 8
  %v2959 = load i64, ptr %slot541, align 8
  %v2960 = load i64, ptr %slot538, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2959, i64 %v2960) nomerge, !dbg !168
  br label %bb_rcslotdone1117
bb_rcslotowner1117:
  %v2961 = load i64, ptr %slot23, align 8
  store i64 %v2961, ptr %slot542, align 8
  %v2962 = load i64, ptr %slot542, align 8
  %v2963 = load i64, ptr %slot538, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2962, i64 %v2963) nomerge, !dbg !168
  br label %bb_rcslotdone1117
bb_rcslotdone1117:
  %v2964 = load i64, ptr %slot536, align 8
  %p2965 = inttoptr i64 %v2964 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2965, i64 48, i1 false)
  ret void
bb_i51:
  %v2966 = load i64, ptr %slot17, align 8
  %p2967 = inttoptr i64 %v2966 to ptr
  store i64 0, ptr %p2967, align 8, !alias.scope !3, !noalias !4
  %v2968 = load i64, ptr %slot17, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %ld2970 = load i64, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2970, ptr %slot543, align 8
  %v2971 = load i64, ptr %slot543, align 8
  %cond2972 = icmp ne i64 %v2971, 0
  br i1 %cond2972, label %bb_success1180, label %bb_failed1180
bb_failed1180:
  %v2973 = load i64, ptr %slot1, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  call void @myl_qbe_fail_assert(ptr %p2974) nomerge, !dbg !170
  unreachable
bb_success1180:
  %v2975 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult545, i64 %v2975) nomerge, !dbg !172
  %addr2976 = ptrtoint ptr %callresult545 to i64
  store i64 %addr2976, ptr %slot544, align 8
  %v2977 = load i64, ptr %slot544, align 8
  %v2978 = load i64, ptr %slot17, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i64 %v2977, ptr %p2979, align 8, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot17, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  %ld2982 = load i64, ptr %p2981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2982, ptr %slot546, align 8
  %v2983 = load i64, ptr %slot11, align 8
  store i64 %v2983, ptr %slot547, align 8
  %v2984 = load i64, ptr %slot546, align 8
  %v2985 = load i64, ptr %slot547, align 8
  %p2986 = inttoptr i64 %v2984 to ptr
  %p2987 = inttoptr i64 %v2985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2987, ptr %p2986, i64 48, i1 false)
  %v2988 = load i64, ptr %slot9, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  store i32 2, ptr %p2989, align 4, !alias.scope !3, !noalias !4
  %v2990 = load i64, ptr %slot8, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  store i32 1, ptr %p2991, align 4, !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot10, align 8
  store i64 %v2992, ptr %slot548, align 8
  %v2993 = load i64, ptr %slot11, align 8
  store i64 %v2993, ptr %slot549, align 8
  %v2994 = load i64, ptr %slot549, align 8
  %v2995 = load i64, ptr %slot548, align 8
  %p2996 = inttoptr i64 %v2994 to ptr
  %p2997 = inttoptr i64 %v2995 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2997, ptr %p2996, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2998 = load i64, ptr %slot7, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i32 2, ptr %p2999, align 4, !alias.scope !3, !noalias !4
  %v3000 = load i64, ptr %slot9, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %ld3002 = load i32, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3002, ptr %slot550, align 8
  %v3003 = load i32, ptr %slot550, align 8
  %v3004 = load i64, ptr %slot7, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i32 %v3003, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot8, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 0, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot6, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i32 1, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot548, align 8
  %v3011 = load i64, ptr %slot17, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  store i64 %v3010, ptr %p3012, align 8, !alias.scope !3, !noalias !4
  %v3013 = load i64, ptr %slot17, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i64, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3015, ptr %slot551, align 8
  %v3016 = load i64, ptr %slot17, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  %ld3018 = load i64, ptr %p3017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3018, ptr %slot552, align 8
  %v3019 = load i64, ptr %slot11, align 8
  store i64 %v3019, ptr %slot553, align 8
  %v3020 = load i64, ptr %slot24, align 8
  store i64 %v3020, ptr %slot554, align 8
  %v3021 = load i64, ptr %slot552, align 8
  %op3022 = add i64 %v3021, 16
  store i64 %op3022, ptr %slot555, align 8
  %v3023 = load i64, ptr %slot555, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  %ld3025 = load i64, ptr %p3024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3025, ptr %slot556, align 8
  %v3026 = load i64, ptr %slot556, align 8
  %cmp3027 = icmp ne i64 %v3026, 0
  %cv3028 = zext i1 %cmp3027 to i32
  store i32 %cv3028, ptr %slot557, align 8
  %v3029 = load i32, ptr %slot557, align 8
  %cv3030 = zext i32 %v3029 to i64
  %cond3031 = icmp ne i64 %cv3030, 0
  br i1 %cond3031, label %bb_rcmoveheader1201, label %bb_rcmovenext1201
bb_rcmoveheader1201:
  %v3032 = load i64, ptr %slot556, align 8
  %op3033 = sub i64 %v3032, 16
  store i64 %op3033, ptr %slot558, align 8
  %v3034 = load i64, ptr %slot556, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %rgep3036 = getelementptr i8, ptr %p3035, i64 -16
  %ld3037 = load i64, ptr %rgep3036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3037, ptr %slot559, align 8
  %v3038 = load i64, ptr %slot559, align 8
  %op3039 = and i64 %v3038, 5764607523034234881
  store i64 %op3039, ptr %slot560, align 8
  %v3040 = load i64, ptr %slot560, align 8
  %cmp3041 = icmp ne i64 %v3040, 0
  %cv3042 = zext i1 %cmp3041 to i32
  store i32 %cv3042, ptr %slot561, align 8
  %v3043 = load i32, ptr %slot561, align 8
  %cv3044 = zext i32 %v3043 to i64
  %cond3045 = icmp ne i64 %cv3044, 0
  br i1 %cond3045, label %bb_rcmoveslow1198, label %bb_rcmovenext1201
bb_rcmovenext1201:
  %v3046 = load i64, ptr %slot552, align 8
  %op3047 = add i64 %v3046, 24
  store i64 %op3047, ptr %slot562, align 8
  %v3048 = load i64, ptr %slot562, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i64, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3050, ptr %slot563, align 8
  %v3051 = load i64, ptr %slot563, align 8
  %cmp3052 = icmp ne i64 %v3051, 0
  %cv3053 = zext i1 %cmp3052 to i32
  store i32 %cv3053, ptr %slot564, align 8
  %v3054 = load i32, ptr %slot564, align 8
  %cv3055 = zext i32 %v3054 to i64
  %cond3056 = icmp ne i64 %cv3055, 0
  br i1 %cond3056, label %bb_rcmoveheader1209, label %bb_rcmovenext1209
bb_rcmoveheader1209:
  %v3057 = load i64, ptr %slot563, align 8
  %op3058 = sub i64 %v3057, 16
  store i64 %op3058, ptr %slot565, align 8
  %v3059 = load i64, ptr %slot563, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %rgep3061 = getelementptr i8, ptr %p3060, i64 -16
  %ld3062 = load i64, ptr %rgep3061, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3062, ptr %slot566, align 8
  %v3063 = load i64, ptr %slot566, align 8
  %op3064 = and i64 %v3063, 5764607523034234881
  store i64 %op3064, ptr %slot567, align 8
  %v3065 = load i64, ptr %slot567, align 8
  %cmp3066 = icmp ne i64 %v3065, 0
  %cv3067 = zext i1 %cmp3066 to i32
  store i32 %cv3067, ptr %slot568, align 8
  %v3068 = load i32, ptr %slot568, align 8
  %cv3069 = zext i32 %v3068 to i64
  %cond3070 = icmp ne i64 %cv3069, 0
  br i1 %cond3070, label %bb_rcmoveslow1198, label %bb_rcmovenext1209
bb_rcmovenext1209:
  %v3071 = load i64, ptr %slot552, align 8
  %op3072 = add i64 %v3071, 32
  store i64 %op3072, ptr %slot569, align 8
  %v3073 = load i64, ptr %slot569, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  %ld3075 = load i64, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3075, ptr %slot570, align 8
  %v3076 = load i64, ptr %slot570, align 8
  %cmp3077 = icmp ne i64 %v3076, 0
  %cv3078 = zext i1 %cmp3077 to i32
  store i32 %cv3078, ptr %slot571, align 8
  %v3079 = load i32, ptr %slot571, align 8
  %cv3080 = zext i32 %v3079 to i64
  %cond3081 = icmp ne i64 %cv3080, 0
  br i1 %cond3081, label %bb_rcmoveheader1217, label %bb_rcmovenext1217
bb_rcmoveheader1217:
  %v3082 = load i64, ptr %slot570, align 8
  %op3083 = sub i64 %v3082, 16
  store i64 %op3083, ptr %slot572, align 8
  %v3084 = load i64, ptr %slot570, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  %rgep3086 = getelementptr i8, ptr %p3085, i64 -16
  %ld3087 = load i64, ptr %rgep3086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3087, ptr %slot573, align 8
  %v3088 = load i64, ptr %slot573, align 8
  %op3089 = and i64 %v3088, 5764607523034234881
  store i64 %op3089, ptr %slot574, align 8
  %v3090 = load i64, ptr %slot574, align 8
  %cmp3091 = icmp ne i64 %v3090, 0
  %cv3092 = zext i1 %cmp3091 to i32
  store i32 %cv3092, ptr %slot575, align 8
  %v3093 = load i32, ptr %slot575, align 8
  %cv3094 = zext i32 %v3093 to i64
  %cond3095 = icmp ne i64 %cv3094, 0
  br i1 %cond3095, label %bb_rcmoveslow1198, label %bb_rcmovenext1217
bb_rcmovenext1217:
  %v3096 = load i64, ptr %slot552, align 8
  %v3097 = load i64, ptr %slot553, align 8
  %p3098 = inttoptr i64 %v3096 to ptr
  %p3099 = inttoptr i64 %v3097 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3099, ptr %p3098, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3100 = load i64, ptr %slot552, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  store i64 0, ptr %p3101, align 8, !alias.scope !3, !noalias !4
  %v3102 = load i64, ptr %slot552, align 8
  %op3103 = add i64 %v3102, 8
  store i64 %op3103, ptr %slot576, align 8
  %v3104 = load i64, ptr %slot576, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  store i64 0, ptr %p3105, align 8, !alias.scope !3, !noalias !4
  %v3106 = load i64, ptr %slot552, align 8
  %op3107 = add i64 %v3106, 16
  store i64 %op3107, ptr %slot577, align 8
  %v3108 = load i64, ptr %slot577, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i64 0, ptr %p3109, align 8, !alias.scope !3, !noalias !4
  %v3110 = load i64, ptr %slot552, align 8
  %op3111 = add i64 %v3110, 24
  store i64 %op3111, ptr %slot578, align 8
  %v3112 = load i64, ptr %slot578, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  store i64 0, ptr %p3113, align 8, !alias.scope !3, !noalias !4
  %v3114 = load i64, ptr %slot552, align 8
  %op3115 = add i64 %v3114, 32
  store i64 %op3115, ptr %slot579, align 8
  %v3116 = load i64, ptr %slot579, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  store i64 0, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  %v3118 = load i64, ptr %slot552, align 8
  %op3119 = add i64 %v3118, 40
  store i64 %op3119, ptr %slot580, align 8
  %v3120 = load i64, ptr %slot580, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 0, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1198
bb_rcmoveslow1198:
  %v3122 = load i64, ptr %slot23, align 8
  %v3123 = load i64, ptr %slot553, align 8
  %v3124 = load i64, ptr %slot552, align 8
  %v3125 = load i64, ptr %slot554, align 8
  %cv3126 = trunc i64 %v3125 to i32
  %call3127 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3122, i64 %v3123, i64 %v3124, i32 %cv3126) nomerge, !dbg !174
  store i32 %call3127, ptr %slot581, align 8
  %v3128 = load i32, ptr %slot581, align 8
  %cv3129 = zext i32 %v3128 to i64
  %cond3130 = icmp ne i64 %cv3129, 0
  br i1 %cond3130, label %bb_rcsuccess1229, label %bb_rcfailure1229
bb_rcfailure1229:
  %v3131 = load i64, ptr %slot23, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  %call3133 = call i32 @myl_rc_take_failure(ptr %p3132) nomerge, !dbg !174
  store i32 %call3133, ptr %slot582, align 8
  %v3134 = load i64, ptr %slot1, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  %v3136 = load i32, ptr %slot582, align 8
  %call3137 = call i32 @myl_qbe_rc_status(ptr %p3135, i32 %v3136) nomerge, !dbg !174
  store i32 %call3137, ptr %slot583, align 8
  br label %bb_failure
bb_rcsuccess1229:
  br label %bb_rcmoved1198
bb_rcmoved1198:
  %v3138 = load i64, ptr %slot6, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  store i32 0, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot9, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i32 2, ptr %p3141, align 4, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot8, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  store i32 1, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  %v3144 = load i64, ptr %slot11, align 8
  store i64 %v3144, ptr %slot584, align 8
  %v3145 = load i64, ptr %slot8, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  store i32 0, ptr %p3146, align 4, !alias.scope !3, !noalias !4
  %v3147 = load i64, ptr %slot6, align 8
  %p3148 = inttoptr i64 %v3147 to ptr
  %ld3149 = load i32, ptr %p3148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3149, ptr %slot585, align 8
  %v3150 = load i32, ptr %slot585, align 8
  %cv3151 = zext i32 %v3150 to i64
  %cond3152 = icmp ne i64 %cv3151, 0
  br i1 %cond3152, label %bb_rcslotdrop1239, label %bb_rcslotdone1239
bb_rcslotdrop1239:
  %v3153 = load i64, ptr %slot6, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  store i32 0, ptr %p3154, align 4, !alias.scope !3, !noalias !4
  %v3155 = load i64, ptr %slot10, align 8
  store i64 %v3155, ptr %slot586, align 8
  %v3156 = load i64, ptr %slot7, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  %ld3158 = load i32, ptr %p3157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3158, ptr %slot587, align 8
  %v3159 = load i32, ptr %slot587, align 8
  %op3160 = and i32 %v3159, 28
  store i32 %op3160, ptr %slot588, align 8
  %v3161 = load i32, ptr %slot588, align 8
  %cv3162 = zext i32 %v3161 to i64
  %cond3163 = icmp ne i64 %cv3162, 0
  br i1 %cond3163, label %bb_rcslotrole1239, label %bb_rcslotowner1239
bb_rcslotrole1239:
  %v3164 = load i64, ptr %slot23, align 8
  store i64 %v3164, ptr %slot589, align 8
  %v3165 = load i64, ptr %slot589, align 8
  %v3166 = load i64, ptr %slot586, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3165, i64 %v3166) nomerge, !dbg !174
  br label %bb_rcslotdone1239
bb_rcslotowner1239:
  %v3167 = load i64, ptr %slot23, align 8
  store i64 %v3167, ptr %slot590, align 8
  %v3168 = load i64, ptr %slot590, align 8
  %v3169 = load i64, ptr %slot586, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3168, i64 %v3169) nomerge, !dbg !174
  br label %bb_rcslotdone1239
bb_rcslotdone1239:
  %v3170 = load i64, ptr %slot584, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3171, i64 48, i1 false)
  ret void
bb_i55:
  %v3172 = load i64, ptr %slot17, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  store i64 0, ptr %p3173, align 8, !alias.scope !3, !noalias !4
  %v3174 = load i64, ptr %slot17, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i64, ptr %p3175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3176, ptr %slot591, align 8
  %v3177 = load i64, ptr %slot591, align 8
  %cond3178 = icmp ne i64 %v3177, 0
  br i1 %cond3178, label %bb_success1302, label %bb_failed1302
bb_failed1302:
  %v3179 = load i64, ptr %slot1, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  call void @myl_qbe_fail_assert(ptr %p3180) nomerge, !dbg !176
  unreachable
bb_success1302:
  %v3181 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult593, i64 %v3181) nomerge, !dbg !178
  %addr3182 = ptrtoint ptr %callresult593 to i64
  store i64 %addr3182, ptr %slot592, align 8
  %v3183 = load i64, ptr %slot592, align 8
  %v3184 = load i64, ptr %slot17, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i64 %v3183, ptr %p3185, align 8, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot17, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  %ld3188 = load i64, ptr %p3187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3188, ptr %slot594, align 8
  %v3189 = load i64, ptr %slot11, align 8
  store i64 %v3189, ptr %slot595, align 8
  %v3190 = load i64, ptr %slot594, align 8
  %v3191 = load i64, ptr %slot595, align 8
  %p3192 = inttoptr i64 %v3190 to ptr
  %p3193 = inttoptr i64 %v3191 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3193, ptr %p3192, i64 48, i1 false)
  %v3194 = load i64, ptr %slot9, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  store i32 2, ptr %p3195, align 4, !alias.scope !3, !noalias !4
  %v3196 = load i64, ptr %slot8, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  store i32 1, ptr %p3197, align 4, !alias.scope !3, !noalias !4
  %v3198 = load i64, ptr %slot10, align 8
  store i64 %v3198, ptr %slot596, align 8
  %v3199 = load i64, ptr %slot11, align 8
  store i64 %v3199, ptr %slot597, align 8
  %v3200 = load i64, ptr %slot597, align 8
  %v3201 = load i64, ptr %slot596, align 8
  %p3202 = inttoptr i64 %v3200 to ptr
  %p3203 = inttoptr i64 %v3201 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3203, ptr %p3202, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot7, align 8
  %p3205 = inttoptr i64 %v3204 to ptr
  store i32 2, ptr %p3205, align 4, !alias.scope !3, !noalias !4
  %v3206 = load i64, ptr %slot9, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %ld3208 = load i32, ptr %p3207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3208, ptr %slot598, align 8
  %v3209 = load i32, ptr %slot598, align 8
  %v3210 = load i64, ptr %slot7, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i32 %v3209, ptr %p3211, align 4, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot8, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 0, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  %v3214 = load i64, ptr %slot6, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  store i32 1, ptr %p3215, align 4, !alias.scope !3, !noalias !4
  %v3216 = load i64, ptr %slot596, align 8
  %v3217 = load i64, ptr %slot17, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i64 %v3216, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot17, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  %ld3221 = load i64, ptr %p3220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3221, ptr %slot599, align 8
  %v3222 = load i64, ptr %slot17, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  %ld3224 = load i64, ptr %p3223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3224, ptr %slot600, align 8
  %v3225 = load i64, ptr %slot11, align 8
  store i64 %v3225, ptr %slot601, align 8
  %v3226 = load i64, ptr %slot24, align 8
  store i64 %v3226, ptr %slot602, align 8
  %v3227 = load i64, ptr %slot600, align 8
  %op3228 = add i64 %v3227, 16
  store i64 %op3228, ptr %slot603, align 8
  %v3229 = load i64, ptr %slot603, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %ld3231 = load i64, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3231, ptr %slot604, align 8
  %v3232 = load i64, ptr %slot604, align 8
  %cmp3233 = icmp ne i64 %v3232, 0
  %cv3234 = zext i1 %cmp3233 to i32
  store i32 %cv3234, ptr %slot605, align 8
  %v3235 = load i32, ptr %slot605, align 8
  %cv3236 = zext i32 %v3235 to i64
  %cond3237 = icmp ne i64 %cv3236, 0
  br i1 %cond3237, label %bb_rcmoveheader1323, label %bb_rcmovenext1323
bb_rcmoveheader1323:
  %v3238 = load i64, ptr %slot604, align 8
  %op3239 = sub i64 %v3238, 16
  store i64 %op3239, ptr %slot606, align 8
  %v3240 = load i64, ptr %slot604, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %rgep3242 = getelementptr i8, ptr %p3241, i64 -16
  %ld3243 = load i64, ptr %rgep3242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3243, ptr %slot607, align 8
  %v3244 = load i64, ptr %slot607, align 8
  %op3245 = and i64 %v3244, 5764607523034234881
  store i64 %op3245, ptr %slot608, align 8
  %v3246 = load i64, ptr %slot608, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot609, align 8
  %v3249 = load i32, ptr %slot609, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcmoveslow1320, label %bb_rcmovenext1323
bb_rcmovenext1323:
  %v3252 = load i64, ptr %slot600, align 8
  %op3253 = add i64 %v3252, 24
  store i64 %op3253, ptr %slot610, align 8
  %v3254 = load i64, ptr %slot610, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %ld3256 = load i64, ptr %p3255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3256, ptr %slot611, align 8
  %v3257 = load i64, ptr %slot611, align 8
  %cmp3258 = icmp ne i64 %v3257, 0
  %cv3259 = zext i1 %cmp3258 to i32
  store i32 %cv3259, ptr %slot612, align 8
  %v3260 = load i32, ptr %slot612, align 8
  %cv3261 = zext i32 %v3260 to i64
  %cond3262 = icmp ne i64 %cv3261, 0
  br i1 %cond3262, label %bb_rcmoveheader1331, label %bb_rcmovenext1331
bb_rcmoveheader1331:
  %v3263 = load i64, ptr %slot611, align 8
  %op3264 = sub i64 %v3263, 16
  store i64 %op3264, ptr %slot613, align 8
  %v3265 = load i64, ptr %slot611, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  %rgep3267 = getelementptr i8, ptr %p3266, i64 -16
  %ld3268 = load i64, ptr %rgep3267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3268, ptr %slot614, align 8
  %v3269 = load i64, ptr %slot614, align 8
  %op3270 = and i64 %v3269, 5764607523034234881
  store i64 %op3270, ptr %slot615, align 8
  %v3271 = load i64, ptr %slot615, align 8
  %cmp3272 = icmp ne i64 %v3271, 0
  %cv3273 = zext i1 %cmp3272 to i32
  store i32 %cv3273, ptr %slot616, align 8
  %v3274 = load i32, ptr %slot616, align 8
  %cv3275 = zext i32 %v3274 to i64
  %cond3276 = icmp ne i64 %cv3275, 0
  br i1 %cond3276, label %bb_rcmoveslow1320, label %bb_rcmovenext1331
bb_rcmovenext1331:
  %v3277 = load i64, ptr %slot600, align 8
  %op3278 = add i64 %v3277, 32
  store i64 %op3278, ptr %slot617, align 8
  %v3279 = load i64, ptr %slot617, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %ld3281 = load i64, ptr %p3280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3281, ptr %slot618, align 8
  %v3282 = load i64, ptr %slot618, align 8
  %cmp3283 = icmp ne i64 %v3282, 0
  %cv3284 = zext i1 %cmp3283 to i32
  store i32 %cv3284, ptr %slot619, align 8
  %v3285 = load i32, ptr %slot619, align 8
  %cv3286 = zext i32 %v3285 to i64
  %cond3287 = icmp ne i64 %cv3286, 0
  br i1 %cond3287, label %bb_rcmoveheader1339, label %bb_rcmovenext1339
bb_rcmoveheader1339:
  %v3288 = load i64, ptr %slot618, align 8
  %op3289 = sub i64 %v3288, 16
  store i64 %op3289, ptr %slot620, align 8
  %v3290 = load i64, ptr %slot618, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %rgep3292 = getelementptr i8, ptr %p3291, i64 -16
  %ld3293 = load i64, ptr %rgep3292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3293, ptr %slot621, align 8
  %v3294 = load i64, ptr %slot621, align 8
  %op3295 = and i64 %v3294, 5764607523034234881
  store i64 %op3295, ptr %slot622, align 8
  %v3296 = load i64, ptr %slot622, align 8
  %cmp3297 = icmp ne i64 %v3296, 0
  %cv3298 = zext i1 %cmp3297 to i32
  store i32 %cv3298, ptr %slot623, align 8
  %v3299 = load i32, ptr %slot623, align 8
  %cv3300 = zext i32 %v3299 to i64
  %cond3301 = icmp ne i64 %cv3300, 0
  br i1 %cond3301, label %bb_rcmoveslow1320, label %bb_rcmovenext1339
bb_rcmovenext1339:
  %v3302 = load i64, ptr %slot600, align 8
  %v3303 = load i64, ptr %slot601, align 8
  %p3304 = inttoptr i64 %v3302 to ptr
  %p3305 = inttoptr i64 %v3303 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3305, ptr %p3304, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot600, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i64 0, ptr %p3307, align 8, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot600, align 8
  %op3309 = add i64 %v3308, 8
  store i64 %op3309, ptr %slot624, align 8
  %v3310 = load i64, ptr %slot624, align 8
  %p3311 = inttoptr i64 %v3310 to ptr
  store i64 0, ptr %p3311, align 8, !alias.scope !3, !noalias !4
  %v3312 = load i64, ptr %slot600, align 8
  %op3313 = add i64 %v3312, 16
  store i64 %op3313, ptr %slot625, align 8
  %v3314 = load i64, ptr %slot625, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  store i64 0, ptr %p3315, align 8, !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot600, align 8
  %op3317 = add i64 %v3316, 24
  store i64 %op3317, ptr %slot626, align 8
  %v3318 = load i64, ptr %slot626, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i64 0, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot600, align 8
  %op3321 = add i64 %v3320, 32
  store i64 %op3321, ptr %slot627, align 8
  %v3322 = load i64, ptr %slot627, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i64 0, ptr %p3323, align 8, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot600, align 8
  %op3325 = add i64 %v3324, 40
  store i64 %op3325, ptr %slot628, align 8
  %v3326 = load i64, ptr %slot628, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  store i64 0, ptr %p3327, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1320
bb_rcmoveslow1320:
  %v3328 = load i64, ptr %slot23, align 8
  %v3329 = load i64, ptr %slot601, align 8
  %v3330 = load i64, ptr %slot600, align 8
  %v3331 = load i64, ptr %slot602, align 8
  %cv3332 = trunc i64 %v3331 to i32
  %call3333 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3328, i64 %v3329, i64 %v3330, i32 %cv3332) nomerge, !dbg !180
  store i32 %call3333, ptr %slot629, align 8
  %v3334 = load i32, ptr %slot629, align 8
  %cv3335 = zext i32 %v3334 to i64
  %cond3336 = icmp ne i64 %cv3335, 0
  br i1 %cond3336, label %bb_rcsuccess1351, label %bb_rcfailure1351
bb_rcfailure1351:
  %v3337 = load i64, ptr %slot23, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  %call3339 = call i32 @myl_rc_take_failure(ptr %p3338) nomerge, !dbg !180
  store i32 %call3339, ptr %slot630, align 8
  %v3340 = load i64, ptr %slot1, align 8
  %p3341 = inttoptr i64 %v3340 to ptr
  %v3342 = load i32, ptr %slot630, align 8
  %call3343 = call i32 @myl_qbe_rc_status(ptr %p3341, i32 %v3342) nomerge, !dbg !180
  store i32 %call3343, ptr %slot631, align 8
  br label %bb_failure
bb_rcsuccess1351:
  br label %bb_rcmoved1320
bb_rcmoved1320:
  %v3344 = load i64, ptr %slot6, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  store i32 0, ptr %p3345, align 4, !alias.scope !3, !noalias !4
  %v3346 = load i64, ptr %slot9, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  store i32 2, ptr %p3347, align 4, !alias.scope !3, !noalias !4
  %v3348 = load i64, ptr %slot8, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  store i32 1, ptr %p3349, align 4, !alias.scope !3, !noalias !4
  %v3350 = load i64, ptr %slot11, align 8
  store i64 %v3350, ptr %slot632, align 8
  %v3351 = load i64, ptr %slot8, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  store i32 0, ptr %p3352, align 4, !alias.scope !3, !noalias !4
  %v3353 = load i64, ptr %slot6, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  %ld3355 = load i32, ptr %p3354, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3355, ptr %slot633, align 8
  %v3356 = load i32, ptr %slot633, align 8
  %cv3357 = zext i32 %v3356 to i64
  %cond3358 = icmp ne i64 %cv3357, 0
  br i1 %cond3358, label %bb_rcslotdrop1361, label %bb_rcslotdone1361
bb_rcslotdrop1361:
  %v3359 = load i64, ptr %slot6, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  store i32 0, ptr %p3360, align 4, !alias.scope !3, !noalias !4
  %v3361 = load i64, ptr %slot10, align 8
  store i64 %v3361, ptr %slot634, align 8
  %v3362 = load i64, ptr %slot7, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %ld3364 = load i32, ptr %p3363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3364, ptr %slot635, align 8
  %v3365 = load i32, ptr %slot635, align 8
  %op3366 = and i32 %v3365, 28
  store i32 %op3366, ptr %slot636, align 8
  %v3367 = load i32, ptr %slot636, align 8
  %cv3368 = zext i32 %v3367 to i64
  %cond3369 = icmp ne i64 %cv3368, 0
  br i1 %cond3369, label %bb_rcslotrole1361, label %bb_rcslotowner1361
bb_rcslotrole1361:
  %v3370 = load i64, ptr %slot23, align 8
  store i64 %v3370, ptr %slot637, align 8
  %v3371 = load i64, ptr %slot637, align 8
  %v3372 = load i64, ptr %slot634, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3371, i64 %v3372) nomerge, !dbg !180
  br label %bb_rcslotdone1361
bb_rcslotowner1361:
  %v3373 = load i64, ptr %slot23, align 8
  store i64 %v3373, ptr %slot638, align 8
  %v3374 = load i64, ptr %slot638, align 8
  %v3375 = load i64, ptr %slot634, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3374, i64 %v3375) nomerge, !dbg !180
  br label %bb_rcslotdone1361
bb_rcslotdone1361:
  %v3376 = load i64, ptr %slot632, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3377, i64 48, i1 false)
  ret void
bb_i59:
  %v3378 = load i64, ptr %slot17, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  store i64 0, ptr %p3379, align 8, !alias.scope !3, !noalias !4
  %v3380 = load i64, ptr %slot17, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  %ld3382 = load i64, ptr %p3381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3382, ptr %slot639, align 8
  %v3383 = load i64, ptr %slot639, align 8
  %cond3384 = icmp ne i64 %v3383, 0
  br i1 %cond3384, label %bb_success1424, label %bb_failed1424
bb_failed1424:
  %v3385 = load i64, ptr %slot1, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  call void @myl_qbe_fail_assert(ptr %p3386) nomerge, !dbg !182
  unreachable
bb_success1424:
  %v3387 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult641, i64 %v3387) nomerge, !dbg !184
  %addr3388 = ptrtoint ptr %callresult641 to i64
  store i64 %addr3388, ptr %slot640, align 8
  %v3389 = load i64, ptr %slot640, align 8
  %v3390 = load i64, ptr %slot17, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  store i64 %v3389, ptr %p3391, align 8, !alias.scope !3, !noalias !4
  %v3392 = load i64, ptr %slot17, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %ld3394 = load i64, ptr %p3393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3394, ptr %slot642, align 8
  %v3395 = load i64, ptr %slot11, align 8
  store i64 %v3395, ptr %slot643, align 8
  %v3396 = load i64, ptr %slot642, align 8
  %v3397 = load i64, ptr %slot643, align 8
  %p3398 = inttoptr i64 %v3396 to ptr
  %p3399 = inttoptr i64 %v3397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3399, ptr %p3398, i64 48, i1 false)
  %v3400 = load i64, ptr %slot9, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  store i32 2, ptr %p3401, align 4, !alias.scope !3, !noalias !4
  %v3402 = load i64, ptr %slot8, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  store i32 1, ptr %p3403, align 4, !alias.scope !3, !noalias !4
  %v3404 = load i64, ptr %slot10, align 8
  store i64 %v3404, ptr %slot644, align 8
  %v3405 = load i64, ptr %slot11, align 8
  store i64 %v3405, ptr %slot645, align 8
  %v3406 = load i64, ptr %slot645, align 8
  %v3407 = load i64, ptr %slot644, align 8
  %p3408 = inttoptr i64 %v3406 to ptr
  %p3409 = inttoptr i64 %v3407 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3409, ptr %p3408, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3410 = load i64, ptr %slot7, align 8
  %p3411 = inttoptr i64 %v3410 to ptr
  store i32 2, ptr %p3411, align 4, !alias.scope !3, !noalias !4
  %v3412 = load i64, ptr %slot9, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  %ld3414 = load i32, ptr %p3413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3414, ptr %slot646, align 8
  %v3415 = load i32, ptr %slot646, align 8
  %v3416 = load i64, ptr %slot7, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  store i32 %v3415, ptr %p3417, align 4, !alias.scope !3, !noalias !4
  %v3418 = load i64, ptr %slot8, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  store i32 0, ptr %p3419, align 4, !alias.scope !3, !noalias !4
  %v3420 = load i64, ptr %slot6, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  store i32 1, ptr %p3421, align 4, !alias.scope !3, !noalias !4
  %v3422 = load i64, ptr %slot644, align 8
  %v3423 = load i64, ptr %slot17, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i64 %v3422, ptr %p3424, align 8, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot17, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  %ld3427 = load i64, ptr %p3426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3427, ptr %slot647, align 8
  %v3428 = load i64, ptr %slot17, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  %ld3430 = load i64, ptr %p3429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3430, ptr %slot648, align 8
  %v3431 = load i64, ptr %slot11, align 8
  store i64 %v3431, ptr %slot649, align 8
  %v3432 = load i64, ptr %slot24, align 8
  store i64 %v3432, ptr %slot650, align 8
  %v3433 = load i64, ptr %slot648, align 8
  %op3434 = add i64 %v3433, 16
  store i64 %op3434, ptr %slot651, align 8
  %v3435 = load i64, ptr %slot651, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %ld3437 = load i64, ptr %p3436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3437, ptr %slot652, align 8
  %v3438 = load i64, ptr %slot652, align 8
  %cmp3439 = icmp ne i64 %v3438, 0
  %cv3440 = zext i1 %cmp3439 to i32
  store i32 %cv3440, ptr %slot653, align 8
  %v3441 = load i32, ptr %slot653, align 8
  %cv3442 = zext i32 %v3441 to i64
  %cond3443 = icmp ne i64 %cv3442, 0
  br i1 %cond3443, label %bb_rcmoveheader1445, label %bb_rcmovenext1445
bb_rcmoveheader1445:
  %v3444 = load i64, ptr %slot652, align 8
  %op3445 = sub i64 %v3444, 16
  store i64 %op3445, ptr %slot654, align 8
  %v3446 = load i64, ptr %slot652, align 8
  %p3447 = inttoptr i64 %v3446 to ptr
  %rgep3448 = getelementptr i8, ptr %p3447, i64 -16
  %ld3449 = load i64, ptr %rgep3448, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3449, ptr %slot655, align 8
  %v3450 = load i64, ptr %slot655, align 8
  %op3451 = and i64 %v3450, 5764607523034234881
  store i64 %op3451, ptr %slot656, align 8
  %v3452 = load i64, ptr %slot656, align 8
  %cmp3453 = icmp ne i64 %v3452, 0
  %cv3454 = zext i1 %cmp3453 to i32
  store i32 %cv3454, ptr %slot657, align 8
  %v3455 = load i32, ptr %slot657, align 8
  %cv3456 = zext i32 %v3455 to i64
  %cond3457 = icmp ne i64 %cv3456, 0
  br i1 %cond3457, label %bb_rcmoveslow1442, label %bb_rcmovenext1445
bb_rcmovenext1445:
  %v3458 = load i64, ptr %slot648, align 8
  %op3459 = add i64 %v3458, 24
  store i64 %op3459, ptr %slot658, align 8
  %v3460 = load i64, ptr %slot658, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  %ld3462 = load i64, ptr %p3461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3462, ptr %slot659, align 8
  %v3463 = load i64, ptr %slot659, align 8
  %cmp3464 = icmp ne i64 %v3463, 0
  %cv3465 = zext i1 %cmp3464 to i32
  store i32 %cv3465, ptr %slot660, align 8
  %v3466 = load i32, ptr %slot660, align 8
  %cv3467 = zext i32 %v3466 to i64
  %cond3468 = icmp ne i64 %cv3467, 0
  br i1 %cond3468, label %bb_rcmoveheader1453, label %bb_rcmovenext1453
bb_rcmoveheader1453:
  %v3469 = load i64, ptr %slot659, align 8
  %op3470 = sub i64 %v3469, 16
  store i64 %op3470, ptr %slot661, align 8
  %v3471 = load i64, ptr %slot659, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  %rgep3473 = getelementptr i8, ptr %p3472, i64 -16
  %ld3474 = load i64, ptr %rgep3473, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3474, ptr %slot662, align 8
  %v3475 = load i64, ptr %slot662, align 8
  %op3476 = and i64 %v3475, 5764607523034234881
  store i64 %op3476, ptr %slot663, align 8
  %v3477 = load i64, ptr %slot663, align 8
  %cmp3478 = icmp ne i64 %v3477, 0
  %cv3479 = zext i1 %cmp3478 to i32
  store i32 %cv3479, ptr %slot664, align 8
  %v3480 = load i32, ptr %slot664, align 8
  %cv3481 = zext i32 %v3480 to i64
  %cond3482 = icmp ne i64 %cv3481, 0
  br i1 %cond3482, label %bb_rcmoveslow1442, label %bb_rcmovenext1453
bb_rcmovenext1453:
  %v3483 = load i64, ptr %slot648, align 8
  %op3484 = add i64 %v3483, 32
  store i64 %op3484, ptr %slot665, align 8
  %v3485 = load i64, ptr %slot665, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  %ld3487 = load i64, ptr %p3486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3487, ptr %slot666, align 8
  %v3488 = load i64, ptr %slot666, align 8
  %cmp3489 = icmp ne i64 %v3488, 0
  %cv3490 = zext i1 %cmp3489 to i32
  store i32 %cv3490, ptr %slot667, align 8
  %v3491 = load i32, ptr %slot667, align 8
  %cv3492 = zext i32 %v3491 to i64
  %cond3493 = icmp ne i64 %cv3492, 0
  br i1 %cond3493, label %bb_rcmoveheader1461, label %bb_rcmovenext1461
bb_rcmoveheader1461:
  %v3494 = load i64, ptr %slot666, align 8
  %op3495 = sub i64 %v3494, 16
  store i64 %op3495, ptr %slot668, align 8
  %v3496 = load i64, ptr %slot666, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %rgep3498 = getelementptr i8, ptr %p3497, i64 -16
  %ld3499 = load i64, ptr %rgep3498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3499, ptr %slot669, align 8
  %v3500 = load i64, ptr %slot669, align 8
  %op3501 = and i64 %v3500, 5764607523034234881
  store i64 %op3501, ptr %slot670, align 8
  %v3502 = load i64, ptr %slot670, align 8
  %cmp3503 = icmp ne i64 %v3502, 0
  %cv3504 = zext i1 %cmp3503 to i32
  store i32 %cv3504, ptr %slot671, align 8
  %v3505 = load i32, ptr %slot671, align 8
  %cv3506 = zext i32 %v3505 to i64
  %cond3507 = icmp ne i64 %cv3506, 0
  br i1 %cond3507, label %bb_rcmoveslow1442, label %bb_rcmovenext1461
bb_rcmovenext1461:
  %v3508 = load i64, ptr %slot648, align 8
  %v3509 = load i64, ptr %slot649, align 8
  %p3510 = inttoptr i64 %v3508 to ptr
  %p3511 = inttoptr i64 %v3509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3511, ptr %p3510, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot648, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  store i64 0, ptr %p3513, align 8, !alias.scope !3, !noalias !4
  %v3514 = load i64, ptr %slot648, align 8
  %op3515 = add i64 %v3514, 8
  store i64 %op3515, ptr %slot672, align 8
  %v3516 = load i64, ptr %slot672, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  store i64 0, ptr %p3517, align 8, !alias.scope !3, !noalias !4
  %v3518 = load i64, ptr %slot648, align 8
  %op3519 = add i64 %v3518, 16
  store i64 %op3519, ptr %slot673, align 8
  %v3520 = load i64, ptr %slot673, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  store i64 0, ptr %p3521, align 8, !alias.scope !3, !noalias !4
  %v3522 = load i64, ptr %slot648, align 8
  %op3523 = add i64 %v3522, 24
  store i64 %op3523, ptr %slot674, align 8
  %v3524 = load i64, ptr %slot674, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  store i64 0, ptr %p3525, align 8, !alias.scope !3, !noalias !4
  %v3526 = load i64, ptr %slot648, align 8
  %op3527 = add i64 %v3526, 32
  store i64 %op3527, ptr %slot675, align 8
  %v3528 = load i64, ptr %slot675, align 8
  %p3529 = inttoptr i64 %v3528 to ptr
  store i64 0, ptr %p3529, align 8, !alias.scope !3, !noalias !4
  %v3530 = load i64, ptr %slot648, align 8
  %op3531 = add i64 %v3530, 40
  store i64 %op3531, ptr %slot676, align 8
  %v3532 = load i64, ptr %slot676, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  store i64 0, ptr %p3533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1442
bb_rcmoveslow1442:
  %v3534 = load i64, ptr %slot23, align 8
  %v3535 = load i64, ptr %slot649, align 8
  %v3536 = load i64, ptr %slot648, align 8
  %v3537 = load i64, ptr %slot650, align 8
  %cv3538 = trunc i64 %v3537 to i32
  %call3539 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3534, i64 %v3535, i64 %v3536, i32 %cv3538) nomerge, !dbg !186
  store i32 %call3539, ptr %slot677, align 8
  %v3540 = load i32, ptr %slot677, align 8
  %cv3541 = zext i32 %v3540 to i64
  %cond3542 = icmp ne i64 %cv3541, 0
  br i1 %cond3542, label %bb_rcsuccess1473, label %bb_rcfailure1473
bb_rcfailure1473:
  %v3543 = load i64, ptr %slot23, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %call3545 = call i32 @myl_rc_take_failure(ptr %p3544) nomerge, !dbg !186
  store i32 %call3545, ptr %slot678, align 8
  %v3546 = load i64, ptr %slot1, align 8
  %p3547 = inttoptr i64 %v3546 to ptr
  %v3548 = load i32, ptr %slot678, align 8
  %call3549 = call i32 @myl_qbe_rc_status(ptr %p3547, i32 %v3548) nomerge, !dbg !186
  store i32 %call3549, ptr %slot679, align 8
  br label %bb_failure
bb_rcsuccess1473:
  br label %bb_rcmoved1442
bb_rcmoved1442:
  %v3550 = load i64, ptr %slot6, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  store i32 0, ptr %p3551, align 4, !alias.scope !3, !noalias !4
  %v3552 = load i64, ptr %slot9, align 8
  %p3553 = inttoptr i64 %v3552 to ptr
  store i32 2, ptr %p3553, align 4, !alias.scope !3, !noalias !4
  %v3554 = load i64, ptr %slot8, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  store i32 1, ptr %p3555, align 4, !alias.scope !3, !noalias !4
  %v3556 = load i64, ptr %slot11, align 8
  store i64 %v3556, ptr %slot680, align 8
  %v3557 = load i64, ptr %slot8, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  store i32 0, ptr %p3558, align 4, !alias.scope !3, !noalias !4
  %v3559 = load i64, ptr %slot6, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  %ld3561 = load i32, ptr %p3560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3561, ptr %slot681, align 8
  %v3562 = load i32, ptr %slot681, align 8
  %cv3563 = zext i32 %v3562 to i64
  %cond3564 = icmp ne i64 %cv3563, 0
  br i1 %cond3564, label %bb_rcslotdrop1483, label %bb_rcslotdone1483
bb_rcslotdrop1483:
  %v3565 = load i64, ptr %slot6, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  store i32 0, ptr %p3566, align 4, !alias.scope !3, !noalias !4
  %v3567 = load i64, ptr %slot10, align 8
  store i64 %v3567, ptr %slot682, align 8
  %v3568 = load i64, ptr %slot7, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  %ld3570 = load i32, ptr %p3569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3570, ptr %slot683, align 8
  %v3571 = load i32, ptr %slot683, align 8
  %op3572 = and i32 %v3571, 28
  store i32 %op3572, ptr %slot684, align 8
  %v3573 = load i32, ptr %slot684, align 8
  %cv3574 = zext i32 %v3573 to i64
  %cond3575 = icmp ne i64 %cv3574, 0
  br i1 %cond3575, label %bb_rcslotrole1483, label %bb_rcslotowner1483
bb_rcslotrole1483:
  %v3576 = load i64, ptr %slot23, align 8
  store i64 %v3576, ptr %slot685, align 8
  %v3577 = load i64, ptr %slot685, align 8
  %v3578 = load i64, ptr %slot682, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3577, i64 %v3578) nomerge, !dbg !186
  br label %bb_rcslotdone1483
bb_rcslotowner1483:
  %v3579 = load i64, ptr %slot23, align 8
  store i64 %v3579, ptr %slot686, align 8
  %v3580 = load i64, ptr %slot686, align 8
  %v3581 = load i64, ptr %slot682, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3580, i64 %v3581) nomerge, !dbg !186
  br label %bb_rcslotdone1483
bb_rcslotdone1483:
  %v3582 = load i64, ptr %slot680, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3583, i64 48, i1 false)
  ret void
bb_failure:
  %v3584 = load i64, ptr %slot5, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  call void @llvm.memset.p0.i64(ptr %p3585, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !186
  %v3586 = load i64, ptr %slot5, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3587, i64 48, i1 false)
  ret void
bb_entry_failure:
  %v3588 = load i64, ptr %slot5, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  call void @llvm.memset.p0.i64(ptr %p3589, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !186
  %v3590 = load i64, ptr %slot5, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3591, i64 48, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8, i64)
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208", linkageName: "myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11544332925456106878, i64 0, !"myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!132 = !DILocation(line: 27, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!136 = !DILocation(line: 30, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!138 = !DILocation(line: 31, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!140 = !DILocation(line: 33, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!142 = !DILocation(line: 34, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!144 = !DILocation(line: 35, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!146 = !DILocation(line: 37, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!148 = !DILocation(line: 38, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!150 = !DILocation(line: 39, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!152 = !DILocation(line: 41, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!154 = !DILocation(line: 42, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!156 = !DILocation(line: 43, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!158 = !DILocation(line: 45, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!160 = !DILocation(line: 46, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!162 = !DILocation(line: 47, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!164 = !DILocation(line: 49, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!166 = !DILocation(line: 50, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!168 = !DILocation(line: 51, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!170 = !DILocation(line: 53, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!172 = !DILocation(line: 54, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!174 = !DILocation(line: 55, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!176 = !DILocation(line: 57, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!178 = !DILocation(line: 58, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!180 = !DILocation(line: 59, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!182 = !DILocation(line: 61, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!184 = !DILocation(line: 62, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!186 = !DILocation(line: 63, column: 0, scope: !187)
