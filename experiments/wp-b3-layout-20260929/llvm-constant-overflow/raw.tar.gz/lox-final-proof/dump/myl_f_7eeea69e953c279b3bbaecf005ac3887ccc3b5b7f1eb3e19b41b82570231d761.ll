target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_7eeea69e953c279b3bbaecf005ac3887ccc3b5b7f1eb3e19b41b82570231d761(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i32, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i32, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i32, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i32, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i32, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i32, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i32, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i32, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i32, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i32, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i32, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i32, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i32, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i32, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i32, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i32, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i32, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i32, align 8
  %slot1470 = alloca i32, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i32, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i32, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i32, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i32, align 8
  %slot1535 = alloca i32, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i32, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i32, align 8
  %slot1552 = alloca i32, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i32, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i32, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i32, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i32, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i64, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i32, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i32, align 8
  %slot1579 = alloca i32, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i64, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i32, align 8
  %slot1588 = alloca i32, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i32, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i32, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i32, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i32, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i32, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i32, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i32, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i32, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i64, align 8
  %slot1619 = alloca i32, align 8
  %slot1620 = alloca i32, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i32, align 8
  %slot1623 = alloca i32, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i32, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i32, align 8
  %slot1629 = alloca i32, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i32, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i32, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i32, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i32, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i32, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i32, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i32, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i32, align 8
  %slot1658 = alloca i32, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i32, align 8
  %slot1661 = alloca i32, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i32, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i32, align 8
  %slot1667 = alloca i32, align 8
  %slot1668 = alloca i64, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i32, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i32, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i32, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i32, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i32, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i32, align 8
  %slot1699 = alloca i32, align 8
  %slot1700 = alloca i64, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i32, align 8
  %slot1703 = alloca i64, align 8
  %slot1704 = alloca i32, align 8
  %slot1705 = alloca i32, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i32, align 8
  %slot1709 = alloca i64, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i32, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i64, align 8
  %slot1719 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1720 = load i64, ptr %slot1, align 8
  %op1721 = add i64 %v1720, 32
  store i64 %op1721, ptr %slot4, align 8
  %mem1722 = alloca i8, i64 8, align 8
  %ptr1723 = ptrtoint ptr %mem1722 to i64
  store i64 %ptr1723, ptr %slot5, align 8
  %mem1724 = alloca i8, i64 8, align 8
  %ptr1725 = ptrtoint ptr %mem1724 to i64
  store i64 %ptr1725, ptr %slot6, align 8
  %mem1726 = alloca i8, i64 8, align 8
  %ptr1727 = ptrtoint ptr %mem1726 to i64
  store i64 %ptr1727, ptr %slot7, align 8
  %mem1728 = alloca i8, i64 8, align 8
  %ptr1729 = ptrtoint ptr %mem1728 to i64
  store i64 %ptr1729, ptr %slot8, align 8
  %mem1730 = alloca i8, i64 8, align 8
  %ptr1731 = ptrtoint ptr %mem1730 to i64
  store i64 %ptr1731, ptr %slot9, align 8
  %mem1732 = alloca i8, i64 8, align 8
  %ptr1733 = ptrtoint ptr %mem1732 to i64
  store i64 %ptr1733, ptr %slot10, align 8
  %mem1734 = alloca i8, i64 8, align 8
  %ptr1735 = ptrtoint ptr %mem1734 to i64
  store i64 %ptr1735, ptr %slot11, align 8
  %mem1736 = alloca i8, i64 8, align 8
  %ptr1737 = ptrtoint ptr %mem1736 to i64
  store i64 %ptr1737, ptr %slot12, align 8
  %mem1738 = alloca i8, i64 8, align 8
  %ptr1739 = ptrtoint ptr %mem1738 to i64
  store i64 %ptr1739, ptr %slot13, align 8
  %mem1740 = alloca i8, i64 8, align 8
  %ptr1741 = ptrtoint ptr %mem1740 to i64
  store i64 %ptr1741, ptr %slot14, align 8
  %mem1742 = alloca i8, i64 8, align 8
  %ptr1743 = ptrtoint ptr %mem1742 to i64
  store i64 %ptr1743, ptr %slot15, align 8
  %mem1744 = alloca i8, i64 8, align 8
  %ptr1745 = ptrtoint ptr %mem1744 to i64
  store i64 %ptr1745, ptr %slot16, align 8
  %mem1746 = alloca i8, i64 8, align 8
  %ptr1747 = ptrtoint ptr %mem1746 to i64
  store i64 %ptr1747, ptr %slot17, align 8
  %mem1748 = alloca i8, i64 8, align 8
  %ptr1749 = ptrtoint ptr %mem1748 to i64
  store i64 %ptr1749, ptr %slot18, align 8
  %mem1750 = alloca i8, i64 8, align 8
  %ptr1751 = ptrtoint ptr %mem1750 to i64
  store i64 %ptr1751, ptr %slot19, align 8
  %mem1752 = alloca i8, i64 8, align 8
  %ptr1753 = ptrtoint ptr %mem1752 to i64
  store i64 %ptr1753, ptr %slot20, align 8
  %mem1754 = alloca i8, i64 8, align 8
  %ptr1755 = ptrtoint ptr %mem1754 to i64
  store i64 %ptr1755, ptr %slot21, align 8
  %mem1756 = alloca i8, i64 8, align 8
  %ptr1757 = ptrtoint ptr %mem1756 to i64
  store i64 %ptr1757, ptr %slot22, align 8
  %mem1758 = alloca i8, i64 8, align 8
  %ptr1759 = ptrtoint ptr %mem1758 to i64
  store i64 %ptr1759, ptr %slot23, align 8
  %mem1760 = alloca i8, i64 8, align 8
  %ptr1761 = ptrtoint ptr %mem1760 to i64
  store i64 %ptr1761, ptr %slot24, align 8
  %mem1762 = alloca i8, i64 8, align 8
  %ptr1763 = ptrtoint ptr %mem1762 to i64
  store i64 %ptr1763, ptr %slot25, align 8
  %mem1764 = alloca i8, i64 8, align 8
  %ptr1765 = ptrtoint ptr %mem1764 to i64
  store i64 %ptr1765, ptr %slot26, align 8
  %mem1766 = alloca i8, i64 8, align 8
  %ptr1767 = ptrtoint ptr %mem1766 to i64
  store i64 %ptr1767, ptr %slot27, align 8
  %mem1768 = alloca i8, i64 8, align 8
  %ptr1769 = ptrtoint ptr %mem1768 to i64
  store i64 %ptr1769, ptr %slot28, align 8
  %mem1770 = alloca i8, i64 208, align 8
  %ptr1771 = ptrtoint ptr %mem1770 to i64
  store i64 %ptr1771, ptr %slot29, align 8
  %mem1772 = alloca i8, i64 48, align 8
  %ptr1773 = ptrtoint ptr %mem1772 to i64
  store i64 %ptr1773, ptr %slot30, align 8
  %mem1774 = alloca i8, i64 8, align 8
  %ptr1775 = ptrtoint ptr %mem1774 to i64
  store i64 %ptr1775, ptr %slot31, align 8
  %mem1776 = alloca i8, i64 208, align 8
  %ptr1777 = ptrtoint ptr %mem1776 to i64
  store i64 %ptr1777, ptr %slot32, align 8
  %mem1778 = alloca i8, i64 8, align 8
  %ptr1779 = ptrtoint ptr %mem1778 to i64
  store i64 %ptr1779, ptr %slot33, align 8
  %mem1780 = alloca i8, i64 8, align 8
  %ptr1781 = ptrtoint ptr %mem1780 to i64
  store i64 %ptr1781, ptr %slot34, align 8
  %mem1782 = alloca i8, i64 16, align 8
  %ptr1783 = ptrtoint ptr %mem1782 to i64
  store i64 %ptr1783, ptr %slot35, align 8
  %mem1784 = alloca i8, i64 8, align 8
  %ptr1785 = ptrtoint ptr %mem1784 to i64
  store i64 %ptr1785, ptr %slot36, align 8
  %mem1786 = alloca i8, i64 8, align 8
  %ptr1787 = ptrtoint ptr %mem1786 to i64
  store i64 %ptr1787, ptr %slot37, align 8
  %mem1788 = alloca i8, i64 24, align 8
  %ptr1789 = ptrtoint ptr %mem1788 to i64
  store i64 %ptr1789, ptr %slot38, align 8
  %mem1790 = alloca i8, i64 24, align 8
  %ptr1791 = ptrtoint ptr %mem1790 to i64
  store i64 %ptr1791, ptr %slot39, align 8
  %mem1792 = alloca i8, i64 16, align 8
  %ptr1793 = ptrtoint ptr %mem1792 to i64
  store i64 %ptr1793, ptr %slot40, align 8
  %mem1794 = alloca i8, i64 8, align 8
  %ptr1795 = ptrtoint ptr %mem1794 to i64
  store i64 %ptr1795, ptr %slot41, align 8
  %mem1796 = alloca i8, i64 8, align 8
  %ptr1797 = ptrtoint ptr %mem1796 to i64
  store i64 %ptr1797, ptr %slot42, align 8
  %mem1798 = alloca i8, i64 8, align 8
  %ptr1799 = ptrtoint ptr %mem1798 to i64
  store i64 %ptr1799, ptr %slot43, align 8
  %mem1800 = alloca i8, i64 8, align 8
  %ptr1801 = ptrtoint ptr %mem1800 to i64
  store i64 %ptr1801, ptr %slot44, align 8
  %mem1802 = alloca i8, i64 48, align 8
  %ptr1803 = ptrtoint ptr %mem1802 to i64
  store i64 %ptr1803, ptr %slot45, align 8
  %mem1804 = alloca i8, i64 8, align 8
  %ptr1805 = ptrtoint ptr %mem1804 to i64
  store i64 %ptr1805, ptr %slot46, align 8
  %mem1806 = alloca i8, i64 8, align 8
  %ptr1807 = ptrtoint ptr %mem1806 to i64
  store i64 %ptr1807, ptr %slot47, align 8
  %mem1808 = alloca i8, i64 8, align 8
  %ptr1809 = ptrtoint ptr %mem1808 to i64
  store i64 %ptr1809, ptr %slot48, align 8
  %mem1810 = alloca i8, i64 16, align 8
  %ptr1811 = ptrtoint ptr %mem1810 to i64
  store i64 %ptr1811, ptr %slot49, align 8
  %mem1812 = alloca i8, i64 32, align 8
  %ptr1813 = ptrtoint ptr %mem1812 to i64
  store i64 %ptr1813, ptr %slot50, align 8
  %mem1814 = alloca i8, i64 24, align 8
  %ptr1815 = ptrtoint ptr %mem1814 to i64
  store i64 %ptr1815, ptr %slot51, align 8
  %mem1816 = alloca i8, i64 16, align 8
  %ptr1817 = ptrtoint ptr %mem1816 to i64
  store i64 %ptr1817, ptr %slot52, align 8
  %mem1818 = alloca i8, i64 8, align 8
  %ptr1819 = ptrtoint ptr %mem1818 to i64
  store i64 %ptr1819, ptr %slot53, align 8
  %mem1820 = alloca i8, i64 8, align 8
  %ptr1821 = ptrtoint ptr %mem1820 to i64
  store i64 %ptr1821, ptr %slot54, align 8
  %mem1822 = alloca i8, i64 8, align 8
  %ptr1823 = ptrtoint ptr %mem1822 to i64
  store i64 %ptr1823, ptr %slot55, align 8
  %mem1824 = alloca i8, i64 16, align 8
  %ptr1825 = ptrtoint ptr %mem1824 to i64
  store i64 %ptr1825, ptr %slot56, align 8
  %mem1826 = alloca i8, i64 32, align 8
  %ptr1827 = ptrtoint ptr %mem1826 to i64
  store i64 %ptr1827, ptr %slot57, align 8
  %mem1828 = alloca i8, i64 8, align 8
  %ptr1829 = ptrtoint ptr %mem1828 to i64
  store i64 %ptr1829, ptr %slot58, align 8
  %mem1830 = alloca i8, i64 8, align 8
  %ptr1831 = ptrtoint ptr %mem1830 to i64
  store i64 %ptr1831, ptr %slot59, align 8
  %mem1832 = alloca i8, i64 208, align 8
  %ptr1833 = ptrtoint ptr %mem1832 to i64
  store i64 %ptr1833, ptr %slot60, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1834 = alloca i8, i64 8, align 8
  %ptr1835 = ptrtoint ptr %mem1834 to i64
  store i64 %ptr1835, ptr %slot61, align 8
  %v1836 = load i64, ptr %slot1, align 8
  %op1837 = add i64 %v1836, 64
  store i64 %op1837, ptr %slot62, align 8
  %v1838 = load i64, ptr %slot62, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  %ld1840 = load i64, ptr %p1839, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1840, ptr %slot63, align 8
  %stack1841 = call ptr @llvm.stacksave()
  %stackaddr1842 = ptrtoint ptr %stack1841 to i64
  %v1843 = load i64, ptr %slot63, align 8
  %cmp1844 = icmp ult i64 %stackaddr1842, %v1843
  %cv1845 = zext i1 %cmp1844 to i64
  store i64 %cv1845, ptr %slot64, align 8
  %v1846 = load i64, ptr %slot64, align 8
  %cond1847 = icmp ne i64 %v1846, 0
  br i1 %cond1847, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1848 = load i64, ptr %slot1, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  call void @myl_qbe_fail_frame(ptr %p1849) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1850 = load i64, ptr %slot36, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i64 0, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  %v1852 = load i64, ptr %slot41, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  store i64 0, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  %v1854 = load i64, ptr %slot46, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  store i64 0, ptr %p1855, align 8, !alias.scope !3, !noalias !4
  %v1856 = load i64, ptr %slot53, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  store i64 0, ptr %p1857, align 8, !alias.scope !3, !noalias !4
  %v1858 = load i64, ptr %slot2, align 8
  %v1859 = load i64, ptr %slot33, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  store i64 %v1858, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  %v1861 = load i64, ptr %slot3, align 8
  %v1862 = load i64, ptr %slot34, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i64 %v1861, ptr %p1863, align 8, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot1, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %call1866 = call ptr @myl_qbe_heap(ptr %p1865) nomerge, !dbg !112
  %calladdr1867 = ptrtoint ptr %call1866 to i64
  store i64 %calladdr1867, ptr %slot65, align 8
  %v1868 = load i64, ptr %slot1, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  %call1870 = call i64 @myl_qbe_region_mark(ptr %p1869) nomerge, !dbg !112
  store i64 %call1870, ptr %slot66, align 8
  %v1871 = load i64, ptr %slot5, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  store i32 0, ptr %p1872, align 4, !alias.scope !3, !noalias !4
  %v1873 = load i64, ptr %slot6, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i32 0, ptr %p1874, align 4, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot7, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  store i32 0, ptr %p1876, align 4, !alias.scope !3, !noalias !4
  %v1877 = load i64, ptr %slot8, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i32 0, ptr %p1878, align 4, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot9, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  store i32 0, ptr %p1880, align 4, !alias.scope !3, !noalias !4
  %v1881 = load i64, ptr %slot10, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i32 0, ptr %p1882, align 4, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot11, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  store i32 0, ptr %p1884, align 4, !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot12, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i32 0, ptr %p1886, align 4, !alias.scope !3, !noalias !4
  %v1887 = load i64, ptr %slot13, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i32 0, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot14, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i32 0, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot15, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i32 0, ptr %p1892, align 4, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot16, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  store i32 0, ptr %p1894, align 4, !alias.scope !3, !noalias !4
  %v1895 = load i64, ptr %slot17, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i32 0, ptr %p1896, align 4, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot18, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  store i32 0, ptr %p1898, align 4, !alias.scope !3, !noalias !4
  %v1899 = load i64, ptr %slot19, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  store i32 0, ptr %p1900, align 4, !alias.scope !3, !noalias !4
  %v1901 = load i64, ptr %slot20, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i32 0, ptr %p1902, align 4, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot21, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i32 0, ptr %p1904, align 4, !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot22, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i32 0, ptr %p1906, align 4, !alias.scope !3, !noalias !4
  %v1907 = load i64, ptr %slot23, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i32 0, ptr %p1908, align 4, !alias.scope !3, !noalias !4
  %v1909 = load i64, ptr %slot24, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i32 0, ptr %p1910, align 4, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot25, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  store i32 0, ptr %p1912, align 4, !alias.scope !3, !noalias !4
  %v1913 = load i64, ptr %slot26, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i32 0, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot27, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  store i32 0, ptr %p1916, align 4, !alias.scope !3, !noalias !4
  %v1917 = load i64, ptr %slot28, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i32 0, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot6, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i32 2, ptr %p1920, align 4, !alias.scope !3, !noalias !4
  %v1921 = load i64, ptr %slot8, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i32 2, ptr %p1922, align 4, !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot10, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i32 2, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot12, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i32 2, ptr %p1926, align 4, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot14, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  store i32 2, ptr %p1928, align 4, !alias.scope !3, !noalias !4
  %v1929 = load i64, ptr %slot16, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i32 2, ptr %p1930, align 4, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot18, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i32 2, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot20, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i32 2, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  %v1935 = load i64, ptr %slot22, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i32 2, ptr %p1936, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1937 = load i64, ptr %slot33, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i64, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1939, ptr %slot67, align 8
  %v1940 = load i64, ptr %slot67, align 8
  %v1941 = load i64, ptr %slot60, align 8
  %p1942 = inttoptr i64 %v1940 to ptr
  %p1943 = inttoptr i64 %v1941 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1943, ptr %p1942, i64 208, i1 false), !alias.scope !10000000
  %v1944 = load i64, ptr %slot60, align 8
  %v1945 = load i64, ptr %slot58, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  store i64 %v1944, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  %v1947 = load i64, ptr %slot58, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %ld1949 = load i64, ptr %p1948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1949, ptr %slot68, align 8
  %v1950 = load i64, ptr %slot68, align 8
  %op1951 = add i64 %v1950, 8
  store i64 %op1951, ptr %slot69, align 8
  %v1952 = load i64, ptr %slot69, align 8
  %v1953 = load i64, ptr %slot58, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 %v1952, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot5, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i32, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1957, ptr %slot70, align 8
  %v1958 = load i32, ptr %slot70, align 8
  %cv1959 = zext i32 %v1958 to i64
  %cond1960 = icmp ne i64 %cv1959, 0
  br i1 %cond1960, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v1961 = load i64, ptr %slot5, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  store i32 0, ptr %p1962, align 4, !alias.scope !3, !noalias !4
  %v1963 = load i64, ptr %slot35, align 8
  store i64 %v1963, ptr %slot71, align 8
  %v1964 = load i64, ptr %slot6, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i32, ptr %p1965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1966, ptr %slot72, align 8
  %v1967 = load i32, ptr %slot72, align 8
  %op1968 = and i32 %v1967, 28
  store i32 %op1968, ptr %slot73, align 8
  %v1969 = load i32, ptr %slot73, align 8
  %cv1970 = zext i32 %v1969 to i64
  %cond1971 = icmp ne i64 %cv1970, 0
  br i1 %cond1971, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v1972 = load i64, ptr %slot65, align 8
  store i64 %v1972, ptr %slot74, align 8
  %v1973 = load i64, ptr %slot74, align 8
  %v1974 = load i64, ptr %slot71, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v1973, i64 %v1974) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v1975 = load i64, ptr %slot65, align 8
  store i64 %v1975, ptr %slot75, align 8
  %v1976 = load i64, ptr %slot75, align 8
  %v1977 = load i64, ptr %slot71, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v1976, i64 %v1977) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v1978 = load i64, ptr %slot33, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  %ld1980 = load i64, ptr %p1979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1980, ptr %slot76, align 8
  %v1981 = load i64, ptr %slot76, align 8
  %op1982 = add i64 %v1981, 8
  store i64 %op1982, ptr %slot77, align 8
  %v1983 = load i64, ptr %slot35, align 8
  store i64 %v1983, ptr %slot78, align 8
  %v1984 = load i64, ptr %slot77, align 8
  %v1985 = load i64, ptr %slot78, align 8
  %p1986 = inttoptr i64 %v1984 to ptr
  %p1987 = inttoptr i64 %v1985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1987, ptr %p1986, i64 16, i1 false), !alias.scope !10000000
  %v1988 = load i64, ptr %slot77, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  store i64 0, ptr %p1989, align 8, !alias.scope !4, !noalias !3
  %v1990 = load i64, ptr %slot77, align 8
  %op1991 = add i64 %v1990, 8
  store i64 %op1991, ptr %slot79, align 8
  %v1992 = load i64, ptr %slot79, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  store i64 0, ptr %p1993, align 8, !alias.scope !4, !noalias !3
  %v1994 = load i64, ptr %slot5, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i32 1, ptr %p1995, align 4, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot33, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot80, align 8
  %v1999 = load i64, ptr %slot80, align 8
  %v2000 = load i64, ptr %slot58, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i64 %v1999, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot58, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i64, ptr %p2003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2004, ptr %slot81, align 8
  %v2005 = load i64, ptr %slot81, align 8
  %op2006 = add i64 %v2005, 0
  store i64 %op2006, ptr %slot82, align 8
  %v2007 = load i64, ptr %slot82, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %ld2009 = load i64, ptr %p2008, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2009, ptr %slot83, align 8
  %v2010 = load i64, ptr %slot83, align 8
  %v2011 = load i64, ptr %slot58, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i64 %v2010, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot23, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %ld2015 = load i32, ptr %p2014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2015, ptr %slot84, align 8
  %v2016 = load i32, ptr %slot84, align 8
  %cv2017 = zext i32 %v2016 to i64
  %cond2018 = icmp ne i64 %cv2017, 0
  br i1 %cond2018, label %bb_rcslotdrop43, label %bb_rcslotdone43
bb_rcslotdrop43:
  %v2019 = load i64, ptr %slot23, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i32 0, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot29, align 8
  store i64 %v2021, ptr %slot85, align 8
  %v2022 = load i64, ptr %slot24, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  %ld2024 = load i32, ptr %p2023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2024, ptr %slot86, align 8
  %v2025 = load i32, ptr %slot86, align 8
  %op2026 = and i32 %v2025, 28
  store i32 %op2026, ptr %slot87, align 8
  %v2027 = load i32, ptr %slot87, align 8
  %cv2028 = zext i32 %v2027 to i64
  %cond2029 = icmp ne i64 %cv2028, 0
  br i1 %cond2029, label %bb_rcslotrole43, label %bb_rcslotowner43
bb_rcslotrole43:
  %v2030 = load i64, ptr %slot65, align 8
  store i64 %v2030, ptr %slot88, align 8
  %v2031 = load i64, ptr %slot88, align 8
  %v2032 = load i64, ptr %slot85, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2031, i64 %v2032) nomerge, !dbg !116
  br label %bb_rcslotdone43
bb_rcslotowner43:
  %v2033 = load i64, ptr %slot65, align 8
  store i64 %v2033, ptr %slot89, align 8
  %v2034 = load i64, ptr %slot89, align 8
  %v2035 = load i64, ptr %slot85, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2034, i64 %v2035) nomerge, !dbg !116
  br label %bb_rcslotdone43
bb_rcslotdone43:
  %v2036 = load i64, ptr %slot58, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %ld2038 = load i64, ptr %p2037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2038, ptr %slot90, align 8
  %v2039 = load i64, ptr %slot90, align 8
  %v2040 = load i64, ptr %slot36, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  store i64 %v2039, ptr %p2041, align 8, !alias.scope !3, !noalias !4
  %v2042 = load i64, ptr %slot34, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %ld2044 = load i64, ptr %p2043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2044, ptr %slot91, align 8
  %v2045 = load i64, ptr %slot91, align 8
  %v2046 = load i64, ptr %slot58, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i64 %v2045, ptr %p2047, align 8, !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot58, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  %ld2050 = load i64, ptr %p2049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2050, ptr %slot92, align 8
  %v2051 = load i64, ptr %slot92, align 8
  %v2052 = load i64, ptr %slot37, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i64 %v2051, ptr %p2053, align 8, !alias.scope !3, !noalias !4
  %v2054 = load i64, ptr %slot37, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  %ld2056 = load i64, ptr %p2055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2056, ptr %slot93, align 8
  %v2057 = load i64, ptr %slot93, align 8
  %v2058 = load i64, ptr %slot58, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i64 %v2057, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  %v2060 = load i64, ptr %slot59, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  store i64 0, ptr %p2061, align 8, !alias.scope !3, !noalias !4
  %v2062 = load i64, ptr %slot59, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2064, ptr %slot94, align 8
  %v2065 = load i64, ptr %slot58, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  %ld2067 = load i64, ptr %p2066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2067, ptr %slot95, align 8
  %v2068 = load i64, ptr %slot95, align 8
  %v2069 = load i64, ptr %slot94, align 8
  %cmp2070 = icmp slt i64 %v2068, %v2069
  %cv2071 = zext i1 %cmp2070 to i64
  store i64 %cv2071, ptr %slot96, align 8
  %v2072 = load i64, ptr %slot96, align 8
  %v2073 = load i64, ptr %slot58, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  store i64 %v2072, ptr %p2074, align 8, !alias.scope !3, !noalias !4
  %v2075 = load i64, ptr %slot58, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %ld2077 = load i64, ptr %p2076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2077, ptr %slot97, align 8
  %v2078 = load i64, ptr %slot97, align 8
  %cond2079 = icmp ne i64 %v2078, 0
  br i1 %cond2079, label %bb_next58, label %bb_i18
bb_next58:
  %v2080 = load i64, ptr %slot36, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %ld2082 = load i64, ptr %p2081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2082, ptr %slot98, align 8
  %v2083 = load i64, ptr %slot98, align 8
  %op2084 = add i64 %v2083, 0
  store i64 %op2084, ptr %slot99, align 8
  %v2085 = load i64, ptr %slot99, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i64, ptr %p2086, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2087, ptr %slot100, align 8
  %v2088 = load i64, ptr %slot100, align 8
  %v2089 = load i64, ptr %slot58, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i64 %v2088, ptr %p2090, align 8, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot58, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i64, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2093, ptr %slot101, align 8
  %v2094 = load i64, ptr %slot101, align 8
  %cmp2095 = icmp ugt i64 %v2094, 9223372036854775807
  %cv2096 = zext i1 %cmp2095 to i64
  store i64 %cv2096, ptr %slot102, align 8
  %v2097 = load i64, ptr %slot102, align 8
  %cond2098 = icmp ne i64 %v2097, 0
  br i1 %cond2098, label %bb_cast_overflow63, label %bb_cast_ok63
bb_cast_overflow63:
  %v2099 = load i64, ptr %slot1, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %v2101 = load i64, ptr %slot101, align 8
  call void @myl_qbe_fail_cast(ptr %p2100, i64 %v2101, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok63:
  %v2102 = load i64, ptr %slot101, align 8
  %v2103 = load i64, ptr %slot58, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i64 %v2102, ptr %p2104, align 8, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot37, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  %ld2107 = load i64, ptr %p2106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2107, ptr %slot103, align 8
  %v2108 = load i64, ptr %slot103, align 8
  %v2109 = load i64, ptr %slot59, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i64 %v2108, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot59, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot104, align 8
  %v2114 = load i64, ptr %slot58, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i64, ptr %p2115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2116, ptr %slot105, align 8
  %v2117 = load i64, ptr %slot105, align 8
  %v2118 = load i64, ptr %slot104, align 8
  %ovpair2120 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2117, i64 %v2118)
  %op2119 = extractvalue { i64, i1 } %ovpair2120, 0
  %ov2121 = extractvalue { i64, i1 } %ovpair2120, 1
  store i64 %op2119, ptr %slot106, align 8
  %v2122 = load i64, ptr %slot105, align 8
  %v2123 = load i64, ptr %slot106, align 8
  %op2124 = xor i64 %v2122, %v2123
  store i64 %op2124, ptr %slot107, align 8
  %v2125 = load i64, ptr %slot104, align 8
  %v2126 = load i64, ptr %slot106, align 8
  %op2127 = xor i64 %v2125, %v2126
  store i64 %op2127, ptr %slot108, align 8
  %v2128 = load i64, ptr %slot107, align 8
  %v2129 = load i64, ptr %slot108, align 8
  %op2130 = and i64 %v2128, %v2129
  store i64 %op2130, ptr %slot109, align 8
  %cv2131 = zext i1 %ov2121 to i64
  store i64 %cv2131, ptr %slot110, align 8
  %v2132 = load i64, ptr %slot110, align 8
  %cond2133 = icmp ne i64 %v2132, 0
  br i1 %cond2133, label %bb_overflow67, label %bb_checked67
bb_overflow67:
  %v2134 = load i64, ptr %slot1, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  %v2136 = load i64, ptr %slot105, align 8
  %v2137 = load i64, ptr %slot104, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2135, i64 0, i64 %v2136, i64 %v2137, i64 64) nomerge, !dbg !120
  unreachable
bb_checked67:
  %v2138 = load i64, ptr %slot106, align 8
  %v2139 = load i64, ptr %slot58, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  store i64 %v2138, ptr %p2140, align 8, !alias.scope !3, !noalias !4
  %v2141 = load i64, ptr %slot58, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  %ld2143 = load i64, ptr %p2142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2143, ptr %slot111, align 8
  %v2144 = load i64, ptr %slot111, align 8
  %v2145 = load i64, ptr %slot37, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  store i64 %v2144, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i18:
  %v2147 = load i64, ptr %slot37, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i64, ptr %p2148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2149, ptr %slot112, align 8
  %v2150 = load i64, ptr %slot112, align 8
  %v2151 = load i64, ptr %slot58, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 %v2150, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot36, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i64, ptr %p2154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2155, ptr %slot113, align 8
  %v2156 = load i64, ptr %slot58, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %ld2158 = load i64, ptr %p2157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2158, ptr %slot114, align 8
  %v2159 = load i64, ptr %slot113, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %ld2161 = load i64, ptr %p2160, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2161, ptr %slot115, align 8
  %v2162 = load i64, ptr %slot114, align 8
  %v2163 = load i64, ptr %slot115, align 8
  %cmp2164 = icmp ult i64 %v2162, %v2163
  %cv2165 = zext i1 %cmp2164 to i64
  store i64 %cv2165, ptr %slot116, align 8
  %v2166 = load i64, ptr %slot116, align 8
  %cond2167 = icmp ne i64 %v2166, 0
  br i1 %cond2167, label %bb_success79, label %bb_failed79
bb_failed79:
  %v2168 = load i64, ptr %slot1, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %v2170 = load i64, ptr %slot114, align 8
  %v2171 = load i64, ptr %slot115, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2169, i64 %v2170, i64 %v2171) nomerge, !dbg !122
  unreachable
bb_success79:
  %v2172 = load i64, ptr %slot113, align 8
  %op2173 = add i64 %v2172, 32
  store i64 %op2173, ptr %slot117, align 8
  %v2174 = load i64, ptr %slot117, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %ld2176 = load i64, ptr %p2175, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2176, ptr %slot118, align 8
  %v2177 = load i64, ptr %slot114, align 8
  %op2178 = mul i64 %v2177, 56
  store i64 %op2178, ptr %slot119, align 8
  %v2179 = load i64, ptr %slot118, align 8
  %v2180 = load i64, ptr %slot119, align 8
  %op2181 = add i64 %v2179, %v2180
  store i64 %op2181, ptr %slot120, align 8
  %v2182 = load i64, ptr %slot120, align 8
  %v2183 = load i64, ptr %slot58, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i64 %v2182, ptr %p2184, align 8, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot58, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot121, align 8
  %v2188 = load i64, ptr %slot32, align 8
  store i64 %v2188, ptr %slot122, align 8
  %v2189 = load i64, ptr %slot65, align 8
  %v2190 = load i64, ptr %slot122, align 8
  %v2191 = load i64, ptr %slot121, align 8
  %call2192 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v2189, i64 %v2190, i64 %v2191) nomerge, !dbg !122
  store i32 %call2192, ptr %slot123, align 8
  %v2193 = load i32, ptr %slot123, align 8
  %cv2194 = zext i32 %v2193 to i64
  %cond2195 = icmp ne i64 %cv2194, 0
  br i1 %cond2195, label %bb_rcsuccess87, label %bb_rcfailure87
bb_rcfailure87:
  %v2196 = load i64, ptr %slot65, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %call2198 = call i32 @myl_rc_take_failure(ptr %p2197) nomerge, !dbg !122
  store i32 %call2198, ptr %slot124, align 8
  %v2199 = load i64, ptr %slot1, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %v2201 = load i32, ptr %slot124, align 8
  %call2202 = call i32 @myl_qbe_rc_status(ptr %p2200, i32 %v2201) nomerge, !dbg !122
  store i32 %call2202, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess87:
  %v2203 = load i64, ptr %slot28, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  store i32 2, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  %v2205 = load i64, ptr %slot28, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i32 16, ptr %p2206, align 4, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot27, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  store i32 1, ptr %p2208, align 4, !alias.scope !3, !noalias !4
  %v2209 = load i64, ptr %slot29, align 8
  store i64 %v2209, ptr %slot126, align 8
  %v2210 = load i64, ptr %slot32, align 8
  store i64 %v2210, ptr %slot127, align 8
  %v2211 = load i64, ptr %slot127, align 8
  %v2212 = load i64, ptr %slot126, align 8
  %p2213 = inttoptr i64 %v2211 to ptr
  %p2214 = inttoptr i64 %v2212 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2214, ptr %p2213, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2215 = load i64, ptr %slot24, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  store i32 2, ptr %p2216, align 4, !alias.scope !3, !noalias !4
  %v2217 = load i64, ptr %slot28, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  %ld2219 = load i32, ptr %p2218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2219, ptr %slot128, align 8
  %v2220 = load i32, ptr %slot128, align 8
  %v2221 = load i64, ptr %slot24, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  store i32 %v2220, ptr %p2222, align 4, !alias.scope !3, !noalias !4
  %v2223 = load i64, ptr %slot27, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  store i32 0, ptr %p2224, align 4, !alias.scope !3, !noalias !4
  %v2225 = load i64, ptr %slot23, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  store i32 1, ptr %p2226, align 4, !alias.scope !3, !noalias !4
  %v2227 = load i64, ptr %slot126, align 8
  %v2228 = load i64, ptr %slot58, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  store i64 %v2227, ptr %p2229, align 8, !alias.scope !3, !noalias !4
  %v2230 = load i64, ptr %slot58, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  %ld2232 = load i64, ptr %p2231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2232, ptr %slot129, align 8
  %v2233 = load i64, ptr %slot129, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i32, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  %ext2236 = zext i32 %ld2235 to i64
  store i64 %ext2236, ptr %slot130, align 8
  %v2237 = load i64, ptr %slot130, align 8
  %cmp2238 = icmp eq i64 %v2237, 0
  %cv2239 = zext i1 %cmp2238 to i64
  store i64 %cv2239, ptr %slot131, align 8
  %v2240 = load i64, ptr %slot131, align 8
  %cond2241 = icmp ne i64 %v2240, 0
  br i1 %cond2241, label %bb_rcarm103, label %bb_rcarmnext103
bb_rcarm103:
  %v2242 = load i64, ptr %slot23, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %ld2244 = load i32, ptr %p2243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2244, ptr %slot132, align 8
  %v2245 = load i32, ptr %slot132, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcslotdrop106, label %bb_rcslotdone106
bb_rcslotdrop106:
  %v2248 = load i64, ptr %slot23, align 8
  %p2249 = inttoptr i64 %v2248 to ptr
  store i32 0, ptr %p2249, align 4, !alias.scope !3, !noalias !4
  %v2250 = load i64, ptr %slot29, align 8
  store i64 %v2250, ptr %slot133, align 8
  %v2251 = load i64, ptr %slot24, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %ld2253 = load i32, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2253, ptr %slot134, align 8
  %v2254 = load i32, ptr %slot134, align 8
  %op2255 = and i32 %v2254, 28
  store i32 %op2255, ptr %slot135, align 8
  %v2256 = load i32, ptr %slot135, align 8
  %cv2257 = zext i32 %v2256 to i64
  %cond2258 = icmp ne i64 %cv2257, 0
  br i1 %cond2258, label %bb_rcslotrole106, label %bb_rcslotowner106
bb_rcslotrole106:
  %v2259 = load i64, ptr %slot65, align 8
  store i64 %v2259, ptr %slot136, align 8
  %v2260 = load i64, ptr %slot136, align 8
  %v2261 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2260, i64 %v2261) nomerge, !dbg !124
  br label %bb_rcslotdone106
bb_rcslotowner106:
  %v2262 = load i64, ptr %slot65, align 8
  store i64 %v2262, ptr %slot137, align 8
  %v2263 = load i64, ptr %slot137, align 8
  %v2264 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2263, i64 %v2264) nomerge, !dbg !124
  br label %bb_rcslotdone106
bb_rcslotdone106:
  br label %bb_i195
bb_rcarmnext103:
  %v2265 = load i64, ptr %slot130, align 8
  %cmp2266 = icmp eq i64 %v2265, 1
  %cv2267 = zext i1 %cmp2266 to i64
  store i64 %cv2267, ptr %slot138, align 8
  %v2268 = load i64, ptr %slot138, align 8
  %cond2269 = icmp ne i64 %v2268, 0
  br i1 %cond2269, label %bb_rcarm113, label %bb_rcarmnext113
bb_rcarm113:
  %v2270 = load i64, ptr %slot23, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %ld2272 = load i32, ptr %p2271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2272, ptr %slot139, align 8
  %v2273 = load i32, ptr %slot139, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcslotdrop116, label %bb_rcslotdone116
bb_rcslotdrop116:
  %v2276 = load i64, ptr %slot23, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i32 0, ptr %p2277, align 4, !alias.scope !3, !noalias !4
  %v2278 = load i64, ptr %slot29, align 8
  store i64 %v2278, ptr %slot140, align 8
  %v2279 = load i64, ptr %slot24, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %ld2281 = load i32, ptr %p2280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2281, ptr %slot141, align 8
  %v2282 = load i32, ptr %slot141, align 8
  %op2283 = and i32 %v2282, 28
  store i32 %op2283, ptr %slot142, align 8
  %v2284 = load i32, ptr %slot142, align 8
  %cv2285 = zext i32 %v2284 to i64
  %cond2286 = icmp ne i64 %cv2285, 0
  br i1 %cond2286, label %bb_rcslotrole116, label %bb_rcslotowner116
bb_rcslotrole116:
  %v2287 = load i64, ptr %slot65, align 8
  store i64 %v2287, ptr %slot143, align 8
  %v2288 = load i64, ptr %slot143, align 8
  %v2289 = load i64, ptr %slot140, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2288, i64 %v2289) nomerge, !dbg !124
  br label %bb_rcslotdone116
bb_rcslotowner116:
  %v2290 = load i64, ptr %slot65, align 8
  store i64 %v2290, ptr %slot144, align 8
  %v2291 = load i64, ptr %slot144, align 8
  %v2292 = load i64, ptr %slot140, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2291, i64 %v2292) nomerge, !dbg !124
  br label %bb_rcslotdone116
bb_rcslotdone116:
  br label %bb_i196
bb_rcarmnext113:
  %v2293 = load i64, ptr %slot130, align 8
  %cmp2294 = icmp eq i64 %v2293, 2
  %cv2295 = zext i1 %cmp2294 to i64
  store i64 %cv2295, ptr %slot145, align 8
  %v2296 = load i64, ptr %slot145, align 8
  %cond2297 = icmp ne i64 %v2296, 0
  br i1 %cond2297, label %bb_rcarm123, label %bb_rcarmnext123
bb_rcarm123:
  %v2298 = load i64, ptr %slot32, align 8
  store i64 %v2298, ptr %slot146, align 8
  %v2299 = load i64, ptr %slot129, align 8
  %op2300 = add i64 %v2299, 8
  store i64 %op2300, ptr %slot147, align 8
  %v2301 = load i64, ptr %slot66, align 8
  store i64 %v2301, ptr %slot148, align 8
  %v2302 = load i64, ptr %slot65, align 8
  %v2303 = load i64, ptr %slot146, align 8
  %v2304 = load i64, ptr %slot147, align 8
  %v2305 = load i64, ptr %slot148, align 8
  %cv2306 = trunc i64 %v2305 to i32
  %call2307 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v2302, i64 %v2303, i64 %v2304, i32 %cv2306) nomerge, !dbg !124
  store i32 %call2307, ptr %slot149, align 8
  %v2308 = load i32, ptr %slot149, align 8
  %cv2309 = zext i32 %v2308 to i64
  %cond2310 = icmp ne i64 %cv2309, 0
  br i1 %cond2310, label %bb_rcsuccess128, label %bb_rcfailure128
bb_rcfailure128:
  %v2311 = load i64, ptr %slot65, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %call2313 = call i32 @myl_rc_take_failure(ptr %p2312) nomerge, !dbg !124
  store i32 %call2313, ptr %slot150, align 8
  %v2314 = load i64, ptr %slot1, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %v2316 = load i32, ptr %slot150, align 8
  %call2317 = call i32 @myl_qbe_rc_status(ptr %p2315, i32 %v2316) nomerge, !dbg !124
  store i32 %call2317, ptr %slot151, align 8
  br label %bb_failure
bb_rcsuccess128:
  %v2318 = load i64, ptr %slot28, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  store i32 2, ptr %p2319, align 4, !alias.scope !3, !noalias !4
  %v2320 = load i64, ptr %slot27, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  store i32 1, ptr %p2321, align 4, !alias.scope !3, !noalias !4
  %v2322 = load i64, ptr %slot15, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  %ld2324 = load i32, ptr %p2323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2324, ptr %slot152, align 8
  %v2325 = load i32, ptr %slot152, align 8
  %cv2326 = zext i32 %v2325 to i64
  %cond2327 = icmp ne i64 %cv2326, 0
  br i1 %cond2327, label %bb_rcslotdrop135, label %bb_rcslotdone135
bb_rcslotdrop135:
  %v2328 = load i64, ptr %slot15, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  store i32 0, ptr %p2329, align 4, !alias.scope !3, !noalias !4
  %v2330 = load i64, ptr %slot45, align 8
  store i64 %v2330, ptr %slot153, align 8
  %v2331 = load i64, ptr %slot16, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i32, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2333, ptr %slot154, align 8
  %v2334 = load i32, ptr %slot154, align 8
  %op2335 = and i32 %v2334, 28
  store i32 %op2335, ptr %slot155, align 8
  %v2336 = load i32, ptr %slot155, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotrole135, label %bb_rcslotowner135
bb_rcslotrole135:
  %v2339 = load i64, ptr %slot65, align 8
  store i64 %v2339, ptr %slot156, align 8
  %v2340 = load i64, ptr %slot156, align 8
  %v2341 = load i64, ptr %slot153, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2340, i64 %v2341) nomerge, !dbg !124
  br label %bb_rcslotdone135
bb_rcslotowner135:
  %v2342 = load i64, ptr %slot65, align 8
  store i64 %v2342, ptr %slot157, align 8
  %v2343 = load i64, ptr %slot157, align 8
  %v2344 = load i64, ptr %slot153, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2343, i64 %v2344) nomerge, !dbg !124
  br label %bb_rcslotdone135
bb_rcslotdone135:
  %v2345 = load i64, ptr %slot146, align 8
  %v2346 = load i64, ptr %slot45, align 8
  %p2347 = inttoptr i64 %v2345 to ptr
  %p2348 = inttoptr i64 %v2346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2348, ptr %p2347, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot27, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i32 0, ptr %p2350, align 4, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot45, align 8
  store i64 %v2351, ptr %slot158, align 8
  %v2352 = load i64, ptr %slot16, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  store i32 2, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot15, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  store i32 1, ptr %p2355, align 4, !alias.scope !3, !noalias !4
  %v2356 = load i64, ptr %slot23, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  %ld2358 = load i32, ptr %p2357, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2358, ptr %slot159, align 8
  %v2359 = load i32, ptr %slot159, align 8
  %cv2360 = zext i32 %v2359 to i64
  %cond2361 = icmp ne i64 %cv2360, 0
  br i1 %cond2361, label %bb_rcslotdrop148, label %bb_rcslotdone148
bb_rcslotdrop148:
  %v2362 = load i64, ptr %slot23, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  store i32 0, ptr %p2363, align 4, !alias.scope !3, !noalias !4
  %v2364 = load i64, ptr %slot29, align 8
  store i64 %v2364, ptr %slot160, align 8
  %v2365 = load i64, ptr %slot24, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i32, ptr %p2366, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2367, ptr %slot161, align 8
  %v2368 = load i32, ptr %slot161, align 8
  %op2369 = and i32 %v2368, 28
  store i32 %op2369, ptr %slot162, align 8
  %v2370 = load i32, ptr %slot162, align 8
  %cv2371 = zext i32 %v2370 to i64
  %cond2372 = icmp ne i64 %cv2371, 0
  br i1 %cond2372, label %bb_rcslotrole148, label %bb_rcslotowner148
bb_rcslotrole148:
  %v2373 = load i64, ptr %slot65, align 8
  store i64 %v2373, ptr %slot163, align 8
  %v2374 = load i64, ptr %slot163, align 8
  %v2375 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2374, i64 %v2375) nomerge, !dbg !124
  br label %bb_rcslotdone148
bb_rcslotowner148:
  %v2376 = load i64, ptr %slot65, align 8
  store i64 %v2376, ptr %slot164, align 8
  %v2377 = load i64, ptr %slot164, align 8
  %v2378 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2377, i64 %v2378) nomerge, !dbg !124
  br label %bb_rcslotdone148
bb_rcslotdone148:
  br label %bb_i91
bb_rcarmnext123:
  %v2379 = load i64, ptr %slot130, align 8
  %cmp2380 = icmp eq i64 %v2379, 3
  %cv2381 = zext i1 %cmp2380 to i64
  store i64 %cv2381, ptr %slot165, align 8
  %v2382 = load i64, ptr %slot165, align 8
  %cond2383 = icmp ne i64 %v2382, 0
  br i1 %cond2383, label %bb_rcarm155, label %bb_rcarmnext155
bb_rcarm155:
  %v2384 = load i64, ptr %slot23, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %ld2386 = load i32, ptr %p2385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2386, ptr %slot166, align 8
  %v2387 = load i32, ptr %slot166, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcslotdrop158, label %bb_rcslotdone158
bb_rcslotdrop158:
  %v2390 = load i64, ptr %slot23, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i32 0, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  %v2392 = load i64, ptr %slot29, align 8
  store i64 %v2392, ptr %slot167, align 8
  %v2393 = load i64, ptr %slot24, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i32, ptr %p2394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2395, ptr %slot168, align 8
  %v2396 = load i32, ptr %slot168, align 8
  %op2397 = and i32 %v2396, 28
  store i32 %op2397, ptr %slot169, align 8
  %v2398 = load i32, ptr %slot169, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcslotrole158, label %bb_rcslotowner158
bb_rcslotrole158:
  %v2401 = load i64, ptr %slot65, align 8
  store i64 %v2401, ptr %slot170, align 8
  %v2402 = load i64, ptr %slot170, align 8
  %v2403 = load i64, ptr %slot167, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2402, i64 %v2403) nomerge, !dbg !124
  br label %bb_rcslotdone158
bb_rcslotowner158:
  %v2404 = load i64, ptr %slot65, align 8
  store i64 %v2404, ptr %slot171, align 8
  %v2405 = load i64, ptr %slot171, align 8
  %v2406 = load i64, ptr %slot167, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2405, i64 %v2406) nomerge, !dbg !124
  br label %bb_rcslotdone158
bb_rcslotdone158:
  br label %bb_i197
bb_rcarmnext155:
  %v2407 = load i64, ptr %slot130, align 8
  %cmp2408 = icmp eq i64 %v2407, 4
  %cv2409 = zext i1 %cmp2408 to i64
  store i64 %cv2409, ptr %slot172, align 8
  %v2410 = load i64, ptr %slot172, align 8
  %cond2411 = icmp ne i64 %v2410, 0
  br i1 %cond2411, label %bb_rcarm165, label %bb_rcarmnext165
bb_rcarm165:
  %v2412 = load i64, ptr %slot32, align 8
  store i64 %v2412, ptr %slot173, align 8
  %v2413 = load i64, ptr %slot129, align 8
  %op2414 = add i64 %v2413, 8
  store i64 %op2414, ptr %slot174, align 8
  %v2415 = load i64, ptr %slot66, align 8
  store i64 %v2415, ptr %slot175, align 8
  %v2416 = load i64, ptr %slot65, align 8
  %v2417 = load i64, ptr %slot173, align 8
  %v2418 = load i64, ptr %slot174, align 8
  %v2419 = load i64, ptr %slot175, align 8
  %cv2420 = trunc i64 %v2419 to i32
  %call2421 = call i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_retain(i64 %v2416, i64 %v2417, i64 %v2418, i32 %cv2420) nomerge, !dbg !124
  store i32 %call2421, ptr %slot176, align 8
  %v2422 = load i32, ptr %slot176, align 8
  %cv2423 = zext i32 %v2422 to i64
  %cond2424 = icmp ne i64 %cv2423, 0
  br i1 %cond2424, label %bb_rcsuccess170, label %bb_rcfailure170
bb_rcfailure170:
  %v2425 = load i64, ptr %slot65, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %call2427 = call i32 @myl_rc_take_failure(ptr %p2426) nomerge, !dbg !124
  store i32 %call2427, ptr %slot177, align 8
  %v2428 = load i64, ptr %slot1, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %v2430 = load i32, ptr %slot177, align 8
  %call2431 = call i32 @myl_qbe_rc_status(ptr %p2429, i32 %v2430) nomerge, !dbg !124
  store i32 %call2431, ptr %slot178, align 8
  br label %bb_failure
bb_rcsuccess170:
  %v2432 = load i64, ptr %slot28, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i32 2, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot27, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  store i32 1, ptr %p2435, align 4, !alias.scope !3, !noalias !4
  %v2436 = load i64, ptr %slot11, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %ld2438 = load i32, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2438, ptr %slot179, align 8
  %v2439 = load i32, ptr %slot179, align 8
  %cv2440 = zext i32 %v2439 to i64
  %cond2441 = icmp ne i64 %cv2440, 0
  br i1 %cond2441, label %bb_rcslotdrop177, label %bb_rcslotdone177
bb_rcslotdrop177:
  %v2442 = load i64, ptr %slot11, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 0, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot40, align 8
  store i64 %v2444, ptr %slot180, align 8
  %v2445 = load i64, ptr %slot12, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  %ld2447 = load i32, ptr %p2446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2447, ptr %slot181, align 8
  %v2448 = load i32, ptr %slot181, align 8
  %op2449 = and i32 %v2448, 28
  store i32 %op2449, ptr %slot182, align 8
  %v2450 = load i32, ptr %slot182, align 8
  %cv2451 = zext i32 %v2450 to i64
  %cond2452 = icmp ne i64 %cv2451, 0
  br i1 %cond2452, label %bb_rcslotrole177, label %bb_rcslotowner177
bb_rcslotrole177:
  %v2453 = load i64, ptr %slot65, align 8
  store i64 %v2453, ptr %slot183, align 8
  %v2454 = load i64, ptr %slot183, align 8
  %v2455 = load i64, ptr %slot180, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v2454, i64 %v2455) nomerge, !dbg !124
  br label %bb_rcslotdone177
bb_rcslotowner177:
  %v2456 = load i64, ptr %slot65, align 8
  store i64 %v2456, ptr %slot184, align 8
  %v2457 = load i64, ptr %slot184, align 8
  %v2458 = load i64, ptr %slot180, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v2457, i64 %v2458) nomerge, !dbg !124
  br label %bb_rcslotdone177
bb_rcslotdone177:
  %v2459 = load i64, ptr %slot173, align 8
  %v2460 = load i64, ptr %slot40, align 8
  %p2461 = inttoptr i64 %v2459 to ptr
  %p2462 = inttoptr i64 %v2460 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2462, ptr %p2461, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot27, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 0, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  %v2465 = load i64, ptr %slot40, align 8
  store i64 %v2465, ptr %slot185, align 8
  %v2466 = load i64, ptr %slot12, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  store i32 2, ptr %p2467, align 4, !alias.scope !3, !noalias !4
  %v2468 = load i64, ptr %slot11, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 1, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot23, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  %ld2472 = load i32, ptr %p2471, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2472, ptr %slot186, align 8
  %v2473 = load i32, ptr %slot186, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcslotdrop190, label %bb_rcslotdone190
bb_rcslotdrop190:
  %v2476 = load i64, ptr %slot23, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i32 0, ptr %p2477, align 4, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot29, align 8
  store i64 %v2478, ptr %slot187, align 8
  %v2479 = load i64, ptr %slot24, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  %ld2481 = load i32, ptr %p2480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2481, ptr %slot188, align 8
  %v2482 = load i32, ptr %slot188, align 8
  %op2483 = and i32 %v2482, 28
  store i32 %op2483, ptr %slot189, align 8
  %v2484 = load i32, ptr %slot189, align 8
  %cv2485 = zext i32 %v2484 to i64
  %cond2486 = icmp ne i64 %cv2485, 0
  br i1 %cond2486, label %bb_rcslotrole190, label %bb_rcslotowner190
bb_rcslotrole190:
  %v2487 = load i64, ptr %slot65, align 8
  store i64 %v2487, ptr %slot190, align 8
  %v2488 = load i64, ptr %slot190, align 8
  %v2489 = load i64, ptr %slot187, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2488, i64 %v2489) nomerge, !dbg !124
  br label %bb_rcslotdone190
bb_rcslotowner190:
  %v2490 = load i64, ptr %slot65, align 8
  store i64 %v2490, ptr %slot191, align 8
  %v2491 = load i64, ptr %slot191, align 8
  %v2492 = load i64, ptr %slot187, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2491, i64 %v2492) nomerge, !dbg !124
  br label %bb_rcslotdone190
bb_rcslotdone190:
  br label %bb_i51
bb_rcarmnext165:
  %v2493 = load i64, ptr %slot130, align 8
  %cmp2494 = icmp eq i64 %v2493, 5
  %cv2495 = zext i1 %cmp2494 to i64
  store i64 %cv2495, ptr %slot192, align 8
  %v2496 = load i64, ptr %slot192, align 8
  %cond2497 = icmp ne i64 %v2496, 0
  br i1 %cond2497, label %bb_rcarm197, label %bb_rcarmnext197
bb_rcarm197:
  %v2498 = load i64, ptr %slot32, align 8
  store i64 %v2498, ptr %slot193, align 8
  %v2499 = load i64, ptr %slot129, align 8
  %op2500 = add i64 %v2499, 8
  store i64 %op2500, ptr %slot194, align 8
  %v2501 = load i64, ptr %slot66, align 8
  store i64 %v2501, ptr %slot195, align 8
  %v2502 = load i64, ptr %slot194, align 8
  %v2503 = load i64, ptr %slot193, align 8
  %p2504 = inttoptr i64 %v2502 to ptr
  %p2505 = inttoptr i64 %v2503 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2505, ptr %p2504, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2506 = load i64, ptr %slot28, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  store i32 0, ptr %p2507, align 4, !alias.scope !3, !noalias !4
  %v2508 = load i64, ptr %slot27, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  store i32 1, ptr %p2509, align 4, !alias.scope !3, !noalias !4
  %v2510 = load i64, ptr %slot193, align 8
  %v2511 = load i64, ptr %slot50, align 8
  %p2512 = inttoptr i64 %v2510 to ptr
  %p2513 = inttoptr i64 %v2511 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2513, ptr %p2512, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot27, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  store i32 0, ptr %p2515, align 4, !alias.scope !3, !noalias !4
  %v2516 = load i64, ptr %slot23, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  %ld2518 = load i32, ptr %p2517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2518, ptr %slot196, align 8
  %v2519 = load i32, ptr %slot196, align 8
  %cv2520 = zext i32 %v2519 to i64
  %cond2521 = icmp ne i64 %cv2520, 0
  br i1 %cond2521, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v2522 = load i64, ptr %slot23, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i32 0, ptr %p2523, align 4, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot29, align 8
  store i64 %v2524, ptr %slot197, align 8
  %v2525 = load i64, ptr %slot24, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  %ld2527 = load i32, ptr %p2526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2527, ptr %slot198, align 8
  %v2528 = load i32, ptr %slot198, align 8
  %op2529 = and i32 %v2528, 28
  store i32 %op2529, ptr %slot199, align 8
  %v2530 = load i32, ptr %slot199, align 8
  %cv2531 = zext i32 %v2530 to i64
  %cond2532 = icmp ne i64 %cv2531, 0
  br i1 %cond2532, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v2533 = load i64, ptr %slot65, align 8
  store i64 %v2533, ptr %slot200, align 8
  %v2534 = load i64, ptr %slot200, align 8
  %v2535 = load i64, ptr %slot197, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2534, i64 %v2535) nomerge, !dbg !124
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v2536 = load i64, ptr %slot65, align 8
  store i64 %v2536, ptr %slot201, align 8
  %v2537 = load i64, ptr %slot201, align 8
  %v2538 = load i64, ptr %slot197, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2537, i64 %v2538) nomerge, !dbg !124
  br label %bb_rcslotdone206
bb_rcslotdone206:
  br label %bb_i132
bb_rcarmnext197:
  %v2539 = load i64, ptr %slot130, align 8
  %cmp2540 = icmp eq i64 %v2539, 6
  %cv2541 = zext i1 %cmp2540 to i64
  store i64 %cv2541, ptr %slot202, align 8
  %v2542 = load i64, ptr %slot202, align 8
  %cond2543 = icmp ne i64 %v2542, 0
  br i1 %cond2543, label %bb_rcarm213, label %bb_rcarmnext213
bb_rcarm213:
  %v2544 = load i64, ptr %slot32, align 8
  store i64 %v2544, ptr %slot203, align 8
  %v2545 = load i64, ptr %slot129, align 8
  %op2546 = add i64 %v2545, 8
  store i64 %op2546, ptr %slot204, align 8
  %v2547 = load i64, ptr %slot66, align 8
  store i64 %v2547, ptr %slot205, align 8
  %v2548 = load i64, ptr %slot65, align 8
  %v2549 = load i64, ptr %slot203, align 8
  %v2550 = load i64, ptr %slot204, align 8
  %v2551 = load i64, ptr %slot205, align 8
  %cv2552 = trunc i64 %v2551 to i32
  %call2553 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v2548, i64 %v2549, i64 %v2550, i32 %cv2552) nomerge, !dbg !124
  store i32 %call2553, ptr %slot206, align 8
  %v2554 = load i32, ptr %slot206, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcsuccess218, label %bb_rcfailure218
bb_rcfailure218:
  %v2557 = load i64, ptr %slot65, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  %call2559 = call i32 @myl_rc_take_failure(ptr %p2558) nomerge, !dbg !124
  store i32 %call2559, ptr %slot207, align 8
  %v2560 = load i64, ptr %slot1, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %v2562 = load i32, ptr %slot207, align 8
  %call2563 = call i32 @myl_qbe_rc_status(ptr %p2561, i32 %v2562) nomerge, !dbg !124
  store i32 %call2563, ptr %slot208, align 8
  br label %bb_failure
bb_rcsuccess218:
  %v2564 = load i64, ptr %slot28, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  store i32 2, ptr %p2565, align 4, !alias.scope !3, !noalias !4
  %v2566 = load i64, ptr %slot27, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i32 1, ptr %p2567, align 4, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot7, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  %ld2570 = load i32, ptr %p2569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2570, ptr %slot209, align 8
  %v2571 = load i32, ptr %slot209, align 8
  %cv2572 = zext i32 %v2571 to i64
  %cond2573 = icmp ne i64 %cv2572, 0
  br i1 %cond2573, label %bb_rcslotdrop225, label %bb_rcslotdone225
bb_rcslotdrop225:
  %v2574 = load i64, ptr %slot7, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  store i32 0, ptr %p2575, align 4, !alias.scope !3, !noalias !4
  %v2576 = load i64, ptr %slot38, align 8
  store i64 %v2576, ptr %slot210, align 8
  %v2577 = load i64, ptr %slot8, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i32, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2579, ptr %slot211, align 8
  %v2580 = load i32, ptr %slot211, align 8
  %op2581 = and i32 %v2580, 28
  store i32 %op2581, ptr %slot212, align 8
  %v2582 = load i32, ptr %slot212, align 8
  %cv2583 = zext i32 %v2582 to i64
  %cond2584 = icmp ne i64 %cv2583, 0
  br i1 %cond2584, label %bb_rcslotrole225, label %bb_rcslotowner225
bb_rcslotrole225:
  %v2585 = load i64, ptr %slot65, align 8
  store i64 %v2585, ptr %slot213, align 8
  %v2586 = load i64, ptr %slot213, align 8
  %v2587 = load i64, ptr %slot210, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2586, i64 %v2587) nomerge, !dbg !124
  br label %bb_rcslotdone225
bb_rcslotowner225:
  %v2588 = load i64, ptr %slot65, align 8
  store i64 %v2588, ptr %slot214, align 8
  %v2589 = load i64, ptr %slot214, align 8
  %v2590 = load i64, ptr %slot210, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2589, i64 %v2590) nomerge, !dbg !124
  br label %bb_rcslotdone225
bb_rcslotdone225:
  %v2591 = load i64, ptr %slot203, align 8
  %v2592 = load i64, ptr %slot38, align 8
  %p2593 = inttoptr i64 %v2591 to ptr
  %p2594 = inttoptr i64 %v2592 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2594, ptr %p2593, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2595 = load i64, ptr %slot27, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  store i32 0, ptr %p2596, align 4, !alias.scope !3, !noalias !4
  %v2597 = load i64, ptr %slot38, align 8
  store i64 %v2597, ptr %slot215, align 8
  %v2598 = load i64, ptr %slot8, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  store i32 2, ptr %p2599, align 4, !alias.scope !3, !noalias !4
  %v2600 = load i64, ptr %slot7, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  store i32 1, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot23, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  %ld2604 = load i32, ptr %p2603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2604, ptr %slot216, align 8
  %v2605 = load i32, ptr %slot216, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcslotdrop238, label %bb_rcslotdone238
bb_rcslotdrop238:
  %v2608 = load i64, ptr %slot23, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i32 0, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot29, align 8
  store i64 %v2610, ptr %slot217, align 8
  %v2611 = load i64, ptr %slot24, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i32, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2613, ptr %slot218, align 8
  %v2614 = load i32, ptr %slot218, align 8
  %op2615 = and i32 %v2614, 28
  store i32 %op2615, ptr %slot219, align 8
  %v2616 = load i32, ptr %slot219, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcslotrole238, label %bb_rcslotowner238
bb_rcslotrole238:
  %v2619 = load i64, ptr %slot65, align 8
  store i64 %v2619, ptr %slot220, align 8
  %v2620 = load i64, ptr %slot220, align 8
  %v2621 = load i64, ptr %slot217, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2620, i64 %v2621) nomerge, !dbg !124
  br label %bb_rcslotdone238
bb_rcslotowner238:
  %v2622 = load i64, ptr %slot65, align 8
  store i64 %v2622, ptr %slot221, align 8
  %v2623 = load i64, ptr %slot221, align 8
  %v2624 = load i64, ptr %slot217, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2623, i64 %v2624) nomerge, !dbg !124
  br label %bb_rcslotdone238
bb_rcslotdone238:
  br label %bb_i21
bb_rcarmnext213:
  %v2625 = load i64, ptr %slot130, align 8
  %cmp2626 = icmp eq i64 %v2625, 7
  %cv2627 = zext i1 %cmp2626 to i64
  store i64 %cv2627, ptr %slot222, align 8
  %v2628 = load i64, ptr %slot222, align 8
  %cond2629 = icmp ne i64 %v2628, 0
  br i1 %cond2629, label %bb_rcarm245, label %bb_rcarmnext245
bb_rcarm245:
  %v2630 = load i64, ptr %slot32, align 8
  store i64 %v2630, ptr %slot223, align 8
  %v2631 = load i64, ptr %slot129, align 8
  %op2632 = add i64 %v2631, 8
  store i64 %op2632, ptr %slot224, align 8
  %v2633 = load i64, ptr %slot66, align 8
  store i64 %v2633, ptr %slot225, align 8
  %v2634 = load i64, ptr %slot65, align 8
  %v2635 = load i64, ptr %slot223, align 8
  %v2636 = load i64, ptr %slot224, align 8
  %v2637 = load i64, ptr %slot225, align 8
  %cv2638 = trunc i64 %v2637 to i32
  %call2639 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v2634, i64 %v2635, i64 %v2636, i32 %cv2638) nomerge, !dbg !124
  store i32 %call2639, ptr %slot226, align 8
  %v2640 = load i32, ptr %slot226, align 8
  %cv2641 = zext i32 %v2640 to i64
  %cond2642 = icmp ne i64 %cv2641, 0
  br i1 %cond2642, label %bb_rcsuccess250, label %bb_rcfailure250
bb_rcfailure250:
  %v2643 = load i64, ptr %slot65, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  %call2645 = call i32 @myl_rc_take_failure(ptr %p2644) nomerge, !dbg !124
  store i32 %call2645, ptr %slot227, align 8
  %v2646 = load i64, ptr %slot1, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  %v2648 = load i32, ptr %slot227, align 8
  %call2649 = call i32 @myl_qbe_rc_status(ptr %p2647, i32 %v2648) nomerge, !dbg !124
  store i32 %call2649, ptr %slot228, align 8
  br label %bb_failure
bb_rcsuccess250:
  %v2650 = load i64, ptr %slot28, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i32 2, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot27, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i32 1, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  %v2654 = load i64, ptr %slot9, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %ld2656 = load i32, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2656, ptr %slot229, align 8
  %v2657 = load i32, ptr %slot229, align 8
  %cv2658 = zext i32 %v2657 to i64
  %cond2659 = icmp ne i64 %cv2658, 0
  br i1 %cond2659, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v2660 = load i64, ptr %slot9, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  store i32 0, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  %v2662 = load i64, ptr %slot39, align 8
  store i64 %v2662, ptr %slot230, align 8
  %v2663 = load i64, ptr %slot10, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  %ld2665 = load i32, ptr %p2664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2665, ptr %slot231, align 8
  %v2666 = load i32, ptr %slot231, align 8
  %op2667 = and i32 %v2666, 28
  store i32 %op2667, ptr %slot232, align 8
  %v2668 = load i32, ptr %slot232, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcslotrole257, label %bb_rcslotowner257
bb_rcslotrole257:
  %v2671 = load i64, ptr %slot65, align 8
  store i64 %v2671, ptr %slot233, align 8
  %v2672 = load i64, ptr %slot233, align 8
  %v2673 = load i64, ptr %slot230, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2672, i64 %v2673) nomerge, !dbg !124
  br label %bb_rcslotdone257
bb_rcslotowner257:
  %v2674 = load i64, ptr %slot65, align 8
  store i64 %v2674, ptr %slot234, align 8
  %v2675 = load i64, ptr %slot234, align 8
  %v2676 = load i64, ptr %slot230, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2675, i64 %v2676) nomerge, !dbg !124
  br label %bb_rcslotdone257
bb_rcslotdone257:
  %v2677 = load i64, ptr %slot223, align 8
  %v2678 = load i64, ptr %slot39, align 8
  %p2679 = inttoptr i64 %v2677 to ptr
  %p2680 = inttoptr i64 %v2678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2680, ptr %p2679, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2681 = load i64, ptr %slot27, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  store i32 0, ptr %p2682, align 4, !alias.scope !3, !noalias !4
  %v2683 = load i64, ptr %slot39, align 8
  store i64 %v2683, ptr %slot235, align 8
  %v2684 = load i64, ptr %slot10, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i32 2, ptr %p2685, align 4, !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot9, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  store i32 1, ptr %p2687, align 4, !alias.scope !3, !noalias !4
  %v2688 = load i64, ptr %slot23, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %ld2690 = load i32, ptr %p2689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2690, ptr %slot236, align 8
  %v2691 = load i32, ptr %slot236, align 8
  %cv2692 = zext i32 %v2691 to i64
  %cond2693 = icmp ne i64 %cv2692, 0
  br i1 %cond2693, label %bb_rcslotdrop270, label %bb_rcslotdone270
bb_rcslotdrop270:
  %v2694 = load i64, ptr %slot23, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i32 0, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot29, align 8
  store i64 %v2696, ptr %slot237, align 8
  %v2697 = load i64, ptr %slot24, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %ld2699 = load i32, ptr %p2698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2699, ptr %slot238, align 8
  %v2700 = load i32, ptr %slot238, align 8
  %op2701 = and i32 %v2700, 28
  store i32 %op2701, ptr %slot239, align 8
  %v2702 = load i32, ptr %slot239, align 8
  %cv2703 = zext i32 %v2702 to i64
  %cond2704 = icmp ne i64 %cv2703, 0
  br i1 %cond2704, label %bb_rcslotrole270, label %bb_rcslotowner270
bb_rcslotrole270:
  %v2705 = load i64, ptr %slot65, align 8
  store i64 %v2705, ptr %slot240, align 8
  %v2706 = load i64, ptr %slot240, align 8
  %v2707 = load i64, ptr %slot237, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2706, i64 %v2707) nomerge, !dbg !124
  br label %bb_rcslotdone270
bb_rcslotowner270:
  %v2708 = load i64, ptr %slot65, align 8
  store i64 %v2708, ptr %slot241, align 8
  %v2709 = load i64, ptr %slot241, align 8
  %v2710 = load i64, ptr %slot237, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2709, i64 %v2710) nomerge, !dbg !124
  br label %bb_rcslotdone270
bb_rcslotdone270:
  br label %bb_i36
bb_rcarmnext245:
  %v2711 = load i64, ptr %slot130, align 8
  %cmp2712 = icmp eq i64 %v2711, 8
  %cv2713 = zext i1 %cmp2712 to i64
  store i64 %cv2713, ptr %slot242, align 8
  %v2714 = load i64, ptr %slot242, align 8
  %cond2715 = icmp ne i64 %v2714, 0
  br i1 %cond2715, label %bb_rcarm277, label %bb_rcarmnext277
bb_rcarm277:
  %v2716 = load i64, ptr %slot32, align 8
  store i64 %v2716, ptr %slot243, align 8
  %v2717 = load i64, ptr %slot129, align 8
  %op2718 = add i64 %v2717, 8
  store i64 %op2718, ptr %slot244, align 8
  %v2719 = load i64, ptr %slot66, align 8
  store i64 %v2719, ptr %slot245, align 8
  %v2720 = load i64, ptr %slot244, align 8
  %v2721 = load i64, ptr %slot243, align 8
  %p2722 = inttoptr i64 %v2720 to ptr
  %p2723 = inttoptr i64 %v2721 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2723, ptr %p2722, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2724 = load i64, ptr %slot28, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  store i32 0, ptr %p2725, align 4, !alias.scope !3, !noalias !4
  %v2726 = load i64, ptr %slot27, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i32 1, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot243, align 8
  %v2729 = load i64, ptr %slot51, align 8
  %p2730 = inttoptr i64 %v2728 to ptr
  %p2731 = inttoptr i64 %v2729 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2731, ptr %p2730, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot27, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  store i32 0, ptr %p2733, align 4, !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot23, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  %ld2736 = load i32, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2736, ptr %slot246, align 8
  %v2737 = load i32, ptr %slot246, align 8
  %cv2738 = zext i32 %v2737 to i64
  %cond2739 = icmp ne i64 %cv2738, 0
  br i1 %cond2739, label %bb_rcslotdrop286, label %bb_rcslotdone286
bb_rcslotdrop286:
  %v2740 = load i64, ptr %slot23, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  store i32 0, ptr %p2741, align 4, !alias.scope !3, !noalias !4
  %v2742 = load i64, ptr %slot29, align 8
  store i64 %v2742, ptr %slot247, align 8
  %v2743 = load i64, ptr %slot24, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %ld2745 = load i32, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2745, ptr %slot248, align 8
  %v2746 = load i32, ptr %slot248, align 8
  %op2747 = and i32 %v2746, 28
  store i32 %op2747, ptr %slot249, align 8
  %v2748 = load i32, ptr %slot249, align 8
  %cv2749 = zext i32 %v2748 to i64
  %cond2750 = icmp ne i64 %cv2749, 0
  br i1 %cond2750, label %bb_rcslotrole286, label %bb_rcslotowner286
bb_rcslotrole286:
  %v2751 = load i64, ptr %slot65, align 8
  store i64 %v2751, ptr %slot250, align 8
  %v2752 = load i64, ptr %slot250, align 8
  %v2753 = load i64, ptr %slot247, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2752, i64 %v2753) nomerge, !dbg !124
  br label %bb_rcslotdone286
bb_rcslotowner286:
  %v2754 = load i64, ptr %slot65, align 8
  store i64 %v2754, ptr %slot251, align 8
  %v2755 = load i64, ptr %slot251, align 8
  %v2756 = load i64, ptr %slot247, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2755, i64 %v2756) nomerge, !dbg !124
  br label %bb_rcslotdone286
bb_rcslotdone286:
  br label %bb_i138
bb_rcarmnext277:
  %v2757 = load i64, ptr %slot130, align 8
  %cmp2758 = icmp eq i64 %v2757, 9
  %cv2759 = zext i1 %cmp2758 to i64
  store i64 %cv2759, ptr %slot252, align 8
  %v2760 = load i64, ptr %slot252, align 8
  %cond2761 = icmp ne i64 %v2760, 0
  br i1 %cond2761, label %bb_rcarm293, label %bb_rcarmnext293
bb_rcarm293:
  %v2762 = load i64, ptr %slot32, align 8
  store i64 %v2762, ptr %slot253, align 8
  %v2763 = load i64, ptr %slot129, align 8
  %op2764 = add i64 %v2763, 8
  store i64 %op2764, ptr %slot254, align 8
  %v2765 = load i64, ptr %slot66, align 8
  store i64 %v2765, ptr %slot255, align 8
  %v2766 = load i64, ptr %slot65, align 8
  %v2767 = load i64, ptr %slot253, align 8
  %v2768 = load i64, ptr %slot254, align 8
  %v2769 = load i64, ptr %slot255, align 8
  %cv2770 = trunc i64 %v2769 to i32
  %call2771 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_retain(i64 %v2766, i64 %v2767, i64 %v2768, i32 %cv2770) nomerge, !dbg !124
  store i32 %call2771, ptr %slot256, align 8
  %v2772 = load i32, ptr %slot256, align 8
  %cv2773 = zext i32 %v2772 to i64
  %cond2774 = icmp ne i64 %cv2773, 0
  br i1 %cond2774, label %bb_rcsuccess298, label %bb_rcfailure298
bb_rcfailure298:
  %v2775 = load i64, ptr %slot65, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %call2777 = call i32 @myl_rc_take_failure(ptr %p2776) nomerge, !dbg !124
  store i32 %call2777, ptr %slot257, align 8
  %v2778 = load i64, ptr %slot1, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %v2780 = load i32, ptr %slot257, align 8
  %call2781 = call i32 @myl_qbe_rc_status(ptr %p2779, i32 %v2780) nomerge, !dbg !124
  store i32 %call2781, ptr %slot258, align 8
  br label %bb_failure
bb_rcsuccess298:
  %v2782 = load i64, ptr %slot28, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i32 2, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot27, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  store i32 1, ptr %p2785, align 4, !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot19, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  %ld2788 = load i32, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2788, ptr %slot259, align 8
  %v2789 = load i32, ptr %slot259, align 8
  %cv2790 = zext i32 %v2789 to i64
  %cond2791 = icmp ne i64 %cv2790, 0
  br i1 %cond2791, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v2792 = load i64, ptr %slot19, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  store i32 0, ptr %p2793, align 4, !alias.scope !3, !noalias !4
  %v2794 = load i64, ptr %slot52, align 8
  store i64 %v2794, ptr %slot260, align 8
  %v2795 = load i64, ptr %slot20, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %ld2797 = load i32, ptr %p2796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2797, ptr %slot261, align 8
  %v2798 = load i32, ptr %slot261, align 8
  %op2799 = and i32 %v2798, 28
  store i32 %op2799, ptr %slot262, align 8
  %v2800 = load i32, ptr %slot262, align 8
  %cv2801 = zext i32 %v2800 to i64
  %cond2802 = icmp ne i64 %cv2801, 0
  br i1 %cond2802, label %bb_rcslotrole305, label %bb_rcslotowner305
bb_rcslotrole305:
  %v2803 = load i64, ptr %slot65, align 8
  store i64 %v2803, ptr %slot263, align 8
  %v2804 = load i64, ptr %slot263, align 8
  %v2805 = load i64, ptr %slot260, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2804, i64 %v2805) nomerge, !dbg !124
  br label %bb_rcslotdone305
bb_rcslotowner305:
  %v2806 = load i64, ptr %slot65, align 8
  store i64 %v2806, ptr %slot264, align 8
  %v2807 = load i64, ptr %slot264, align 8
  %v2808 = load i64, ptr %slot260, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2807, i64 %v2808) nomerge, !dbg !124
  br label %bb_rcslotdone305
bb_rcslotdone305:
  %v2809 = load i64, ptr %slot253, align 8
  %v2810 = load i64, ptr %slot52, align 8
  %p2811 = inttoptr i64 %v2809 to ptr
  %p2812 = inttoptr i64 %v2810 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2812, ptr %p2811, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2813 = load i64, ptr %slot27, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  store i32 0, ptr %p2814, align 4, !alias.scope !3, !noalias !4
  %v2815 = load i64, ptr %slot52, align 8
  store i64 %v2815, ptr %slot265, align 8
  %v2816 = load i64, ptr %slot20, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i32 2, ptr %p2817, align 4, !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot19, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  store i32 1, ptr %p2819, align 4, !alias.scope !3, !noalias !4
  %v2820 = load i64, ptr %slot23, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %ld2822 = load i32, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2822, ptr %slot266, align 8
  %v2823 = load i32, ptr %slot266, align 8
  %cv2824 = zext i32 %v2823 to i64
  %cond2825 = icmp ne i64 %cv2824, 0
  br i1 %cond2825, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v2826 = load i64, ptr %slot23, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i32 0, ptr %p2827, align 4, !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot29, align 8
  store i64 %v2828, ptr %slot267, align 8
  %v2829 = load i64, ptr %slot24, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  %ld2831 = load i32, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2831, ptr %slot268, align 8
  %v2832 = load i32, ptr %slot268, align 8
  %op2833 = and i32 %v2832, 28
  store i32 %op2833, ptr %slot269, align 8
  %v2834 = load i32, ptr %slot269, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v2837 = load i64, ptr %slot65, align 8
  store i64 %v2837, ptr %slot270, align 8
  %v2838 = load i64, ptr %slot270, align 8
  %v2839 = load i64, ptr %slot267, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2838, i64 %v2839) nomerge, !dbg !124
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v2840 = load i64, ptr %slot65, align 8
  store i64 %v2840, ptr %slot271, align 8
  %v2841 = load i64, ptr %slot271, align 8
  %v2842 = load i64, ptr %slot267, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2841, i64 %v2842) nomerge, !dbg !124
  br label %bb_rcslotdone318
bb_rcslotdone318:
  br label %bb_i149
bb_rcarmnext293:
  %v2843 = load i64, ptr %slot130, align 8
  %cmp2844 = icmp eq i64 %v2843, 10
  %cv2845 = zext i1 %cmp2844 to i64
  store i64 %cv2845, ptr %slot272, align 8
  %v2846 = load i64, ptr %slot272, align 8
  %cond2847 = icmp ne i64 %v2846, 0
  br i1 %cond2847, label %bb_rcarm325, label %bb_rcarmnext325
bb_rcarm325:
  %v2848 = load i64, ptr %slot32, align 8
  store i64 %v2848, ptr %slot273, align 8
  %v2849 = load i64, ptr %slot129, align 8
  %op2850 = add i64 %v2849, 8
  store i64 %op2850, ptr %slot274, align 8
  %v2851 = load i64, ptr %slot66, align 8
  store i64 %v2851, ptr %slot275, align 8
  %v2852 = load i64, ptr %slot274, align 8
  %v2853 = load i64, ptr %slot273, align 8
  %p2854 = inttoptr i64 %v2852 to ptr
  %p2855 = inttoptr i64 %v2853 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2855, ptr %p2854, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2856 = load i64, ptr %slot28, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i32 0, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot27, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i32 1, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot273, align 8
  %v2861 = load i64, ptr %slot57, align 8
  %p2862 = inttoptr i64 %v2860 to ptr
  %p2863 = inttoptr i64 %v2861 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2863, ptr %p2862, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot27, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i32 0, ptr %p2865, align 4, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot23, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  %ld2868 = load i32, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2868, ptr %slot276, align 8
  %v2869 = load i32, ptr %slot276, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcslotdrop334, label %bb_rcslotdone334
bb_rcslotdrop334:
  %v2872 = load i64, ptr %slot23, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  store i32 0, ptr %p2873, align 4, !alias.scope !3, !noalias !4
  %v2874 = load i64, ptr %slot29, align 8
  store i64 %v2874, ptr %slot277, align 8
  %v2875 = load i64, ptr %slot24, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %ld2877 = load i32, ptr %p2876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2877, ptr %slot278, align 8
  %v2878 = load i32, ptr %slot278, align 8
  %op2879 = and i32 %v2878, 28
  store i32 %op2879, ptr %slot279, align 8
  %v2880 = load i32, ptr %slot279, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcslotrole334, label %bb_rcslotowner334
bb_rcslotrole334:
  %v2883 = load i64, ptr %slot65, align 8
  store i64 %v2883, ptr %slot280, align 8
  %v2884 = load i64, ptr %slot280, align 8
  %v2885 = load i64, ptr %slot277, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2884, i64 %v2885) nomerge, !dbg !124
  br label %bb_rcslotdone334
bb_rcslotowner334:
  %v2886 = load i64, ptr %slot65, align 8
  store i64 %v2886, ptr %slot281, align 8
  %v2887 = load i64, ptr %slot281, align 8
  %v2888 = load i64, ptr %slot277, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2887, i64 %v2888) nomerge, !dbg !124
  br label %bb_rcslotdone334
bb_rcslotdone334:
  br label %bb_i189
bb_rcarmnext325:
  br label %bb_failure
bb_i21:
  %v2889 = load i64, ptr %slot38, align 8
  %v2890 = load i64, ptr %slot58, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  store i64 %v2889, ptr %p2891, align 8, !alias.scope !3, !noalias !4
  %v2892 = load i64, ptr %slot7, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  %ld2894 = load i32, ptr %p2893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2894, ptr %slot282, align 8
  %v2895 = load i64, ptr %slot8, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  %ld2897 = load i32, ptr %p2896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2897, ptr %slot283, align 8
  %v2898 = load i32, ptr %slot283, align 8
  %op2899 = and i32 %v2898, 24
  store i32 %op2899, ptr %slot283, align 8
  %v2900 = load i32, ptr %slot283, align 8
  %cmp2901 = icmp eq i32 %v2900, 0
  %cv2902 = zext i1 %cmp2901 to i32
  store i32 %cv2902, ptr %slot284, align 8
  %v2903 = load i32, ptr %slot282, align 8
  %v2904 = load i32, ptr %slot284, align 8
  %op2905 = and i32 %v2903, %v2904
  store i32 %op2905, ptr %slot285, align 8
  %v2906 = load i32, ptr %slot285, align 8
  %cv2907 = zext i32 %v2906 to i64
  %cond2908 = icmp ne i64 %cv2907, 0
  br i1 %cond2908, label %bb_rcselfkept347, label %bb_rcselfstore347
bb_rcselfstore347:
  %v2909 = load i64, ptr %slot58, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  %ld2911 = load i64, ptr %p2910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2911, ptr %slot286, align 8
  %v2912 = load i64, ptr %slot23, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  %ld2914 = load i32, ptr %p2913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2914, ptr %slot287, align 8
  %v2915 = load i64, ptr %slot24, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %ld2917 = load i32, ptr %p2916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2917, ptr %slot288, align 8
  %v2918 = load i32, ptr %slot288, align 8
  %op2919 = and i32 %v2918, 24
  store i32 %op2919, ptr %slot288, align 8
  %v2920 = load i32, ptr %slot288, align 8
  %cmp2921 = icmp eq i32 %v2920, 0
  %cv2922 = zext i1 %cmp2921 to i32
  store i32 %cv2922, ptr %slot289, align 8
  %v2923 = load i32, ptr %slot287, align 8
  %v2924 = load i32, ptr %slot289, align 8
  %op2925 = and i32 %v2923, %v2924
  store i32 %op2925, ptr %slot290, align 8
  %v2926 = load i32, ptr %slot290, align 8
  %cv2927 = zext i32 %v2926 to i64
  %cond2928 = icmp ne i64 %cv2927, 0
  br i1 %cond2928, label %bb_rctake349, label %bb_rccopy349
bb_rctake349:
  %v2929 = load i64, ptr %slot32, align 8
  store i64 %v2929, ptr %slot291, align 8
  %v2930 = load i64, ptr %slot66, align 8
  store i64 %v2930, ptr %slot292, align 8
  %v2931 = load i64, ptr %slot286, align 8
  %v2932 = load i64, ptr %slot291, align 8
  %op2933 = sub i64 %v2931, %v2932
  store i64 %op2933, ptr %slot293, align 8
  %v2934 = load i64, ptr %slot291, align 8
  %v2935 = load i64, ptr %slot286, align 8
  %op2936 = sub i64 %v2934, %v2935
  store i64 %op2936, ptr %slot294, align 8
  %v2937 = load i64, ptr %slot293, align 8
  %cmp2938 = icmp ult i64 %v2937, 24
  %cv2939 = zext i1 %cmp2938 to i32
  store i32 %cv2939, ptr %slot295, align 8
  %v2940 = load i64, ptr %slot294, align 8
  %cmp2941 = icmp ult i64 %v2940, 24
  %cv2942 = zext i1 %cmp2941 to i32
  store i32 %cv2942, ptr %slot296, align 8
  %v2943 = load i32, ptr %slot295, align 8
  %v2944 = load i32, ptr %slot296, align 8
  %op2945 = or i32 %v2943, %v2944
  store i32 %op2945, ptr %slot297, align 8
  %v2946 = load i32, ptr %slot297, align 8
  %cv2947 = zext i32 %v2946 to i64
  %cond2948 = icmp ne i64 %cv2947, 0
  br i1 %cond2948, label %bb_rcmoveslow358, label %bb_rcmovecheck358
bb_rcmovecheck358:
  %v2949 = load i64, ptr %slot286, align 8
  %op2950 = add i64 %v2949, 8
  store i64 %op2950, ptr %slot298, align 8
  %v2951 = load i64, ptr %slot298, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot299, align 8
  %v2954 = load i64, ptr %slot299, align 8
  %cmp2955 = icmp ne i64 %v2954, 0
  %cv2956 = zext i1 %cmp2955 to i32
  store i32 %cv2956, ptr %slot300, align 8
  %v2957 = load i32, ptr %slot300, align 8
  %cv2958 = zext i32 %v2957 to i64
  %cond2959 = icmp ne i64 %cv2958, 0
  br i1 %cond2959, label %bb_rcmoveheader366, label %bb_rcmovenext366
bb_rcmoveheader366:
  %v2960 = load i64, ptr %slot299, align 8
  %op2961 = sub i64 %v2960, 16
  store i64 %op2961, ptr %slot301, align 8
  %v2962 = load i64, ptr %slot299, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  %rgep2964 = getelementptr i8, ptr %p2963, i64 -16
  %ld2965 = load i64, ptr %rgep2964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2965, ptr %slot302, align 8
  %v2966 = load i64, ptr %slot302, align 8
  %op2967 = and i64 %v2966, 5764607523034234881
  store i64 %op2967, ptr %slot303, align 8
  %v2968 = load i64, ptr %slot303, align 8
  %cmp2969 = icmp ne i64 %v2968, 0
  %cv2970 = zext i1 %cmp2969 to i32
  store i32 %cv2970, ptr %slot304, align 8
  %v2971 = load i32, ptr %slot304, align 8
  %cv2972 = zext i32 %v2971 to i64
  %cond2973 = icmp ne i64 %cv2972, 0
  br i1 %cond2973, label %bb_rcmoveslow358, label %bb_rcmovenext366
bb_rcmovenext366:
  %v2974 = load i64, ptr %slot286, align 8
  %v2975 = load i64, ptr %slot291, align 8
  %p2976 = inttoptr i64 %v2974 to ptr
  %p2977 = inttoptr i64 %v2975 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2977, ptr %p2976, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot286, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i64 0, ptr %p2979, align 8, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot286, align 8
  %op2981 = add i64 %v2980, 8
  store i64 %op2981, ptr %slot305, align 8
  %v2982 = load i64, ptr %slot305, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i64 0, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot286, align 8
  %op2985 = add i64 %v2984, 16
  store i64 %op2985, ptr %slot306, align 8
  %v2986 = load i64, ptr %slot306, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  store i64 0, ptr %p2987, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved358
bb_rcmoveslow358:
  %v2988 = load i64, ptr %slot65, align 8
  %v2989 = load i64, ptr %slot291, align 8
  %v2990 = load i64, ptr %slot286, align 8
  %v2991 = load i64, ptr %slot292, align 8
  %cv2992 = trunc i64 %v2991 to i32
  %call2993 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2988, i64 %v2989, i64 %v2990, i32 %cv2992) nomerge, !dbg !126
  store i32 %call2993, ptr %slot307, align 8
  %v2994 = load i32, ptr %slot307, align 8
  %cv2995 = zext i32 %v2994 to i64
  %cond2996 = icmp ne i64 %cv2995, 0
  br i1 %cond2996, label %bb_rcsuccess375, label %bb_rcfailure375
bb_rcfailure375:
  %v2997 = load i64, ptr %slot65, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %call2999 = call i32 @myl_rc_take_failure(ptr %p2998) nomerge, !dbg !126
  store i32 %call2999, ptr %slot308, align 8
  %v3000 = load i64, ptr %slot1, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %v3002 = load i32, ptr %slot308, align 8
  %call3003 = call i32 @myl_qbe_rc_status(ptr %p3001, i32 %v3002) nomerge, !dbg !126
  store i32 %call3003, ptr %slot309, align 8
  br label %bb_failure
bb_rcsuccess375:
  br label %bb_rcmoved358
bb_rcmoved358:
  %v3004 = load i64, ptr %slot23, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i32 0, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot28, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 2, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot27, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i32 1, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared349
bb_rccopy349:
  %v3010 = load i64, ptr %slot32, align 8
  store i64 %v3010, ptr %slot310, align 8
  %v3011 = load i64, ptr %slot66, align 8
  store i64 %v3011, ptr %slot311, align 8
  %v3012 = load i64, ptr %slot65, align 8
  %v3013 = load i64, ptr %slot310, align 8
  %v3014 = load i64, ptr %slot286, align 8
  %v3015 = load i64, ptr %slot311, align 8
  %cv3016 = trunc i64 %v3015 to i32
  %call3017 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v3012, i64 %v3013, i64 %v3014, i32 %cv3016) nomerge, !dbg !126
  store i32 %call3017, ptr %slot312, align 8
  %v3018 = load i32, ptr %slot312, align 8
  %cv3019 = zext i32 %v3018 to i64
  %cond3020 = icmp ne i64 %cv3019, 0
  br i1 %cond3020, label %bb_rcsuccess384, label %bb_rcfailure384
bb_rcfailure384:
  %v3021 = load i64, ptr %slot65, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %call3023 = call i32 @myl_rc_take_failure(ptr %p3022) nomerge, !dbg !126
  store i32 %call3023, ptr %slot313, align 8
  %v3024 = load i64, ptr %slot1, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  %v3026 = load i32, ptr %slot313, align 8
  %call3027 = call i32 @myl_qbe_rc_status(ptr %p3025, i32 %v3026) nomerge, !dbg !126
  store i32 %call3027, ptr %slot314, align 8
  br label %bb_failure
bb_rcsuccess384:
  %v3028 = load i64, ptr %slot28, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  store i32 2, ptr %p3029, align 4, !alias.scope !3, !noalias !4
  %v3030 = load i64, ptr %slot27, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  store i32 1, ptr %p3031, align 4, !alias.scope !3, !noalias !4
  %v3032 = load i64, ptr %slot23, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  %ld3034 = load i32, ptr %p3033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3034, ptr %slot315, align 8
  %v3035 = load i32, ptr %slot315, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcslotdrop391, label %bb_rcslotdone391
bb_rcslotdrop391:
  %v3038 = load i64, ptr %slot23, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  store i32 0, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  %v3040 = load i64, ptr %slot29, align 8
  store i64 %v3040, ptr %slot316, align 8
  %v3041 = load i64, ptr %slot24, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  %ld3043 = load i32, ptr %p3042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3043, ptr %slot317, align 8
  %v3044 = load i32, ptr %slot317, align 8
  %op3045 = and i32 %v3044, 28
  store i32 %op3045, ptr %slot318, align 8
  %v3046 = load i32, ptr %slot318, align 8
  %cv3047 = zext i32 %v3046 to i64
  %cond3048 = icmp ne i64 %cv3047, 0
  br i1 %cond3048, label %bb_rcslotrole391, label %bb_rcslotowner391
bb_rcslotrole391:
  %v3049 = load i64, ptr %slot65, align 8
  store i64 %v3049, ptr %slot319, align 8
  %v3050 = load i64, ptr %slot319, align 8
  %v3051 = load i64, ptr %slot316, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3050, i64 %v3051) nomerge, !dbg !126
  br label %bb_rcslotdone391
bb_rcslotowner391:
  %v3052 = load i64, ptr %slot316, align 8
  %p3054 = inttoptr i64 %v3052 to ptr
  %gep3055 = getelementptr i8, ptr %p3054, i64 8
  %op3053 = ptrtoint ptr %gep3055 to i64
  store i64 %op3053, ptr %slot320, align 8
  %v3056 = load i64, ptr %slot65, align 8
  store i64 %v3056, ptr %slot321, align 8
  %v3057 = load i64, ptr %slot320, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %ld3059 = load i64, ptr %p3058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3059, ptr %slot322, align 8
  %v3060 = load i64, ptr %slot322, align 8
  %cmp3061 = icmp ne i64 %v3060, 0
  %cv3062 = zext i1 %cmp3061 to i32
  store i32 %cv3062, ptr %slot323, align 8
  %v3063 = load i32, ptr %slot323, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcgnn409, label %bb_rcgdone409
bb_rcgnn409:
  %v3066 = load i64, ptr %slot322, align 8
  %op3067 = sub i64 %v3066, 16
  store i64 %op3067, ptr %slot324, align 8
  %v3068 = load i64, ptr %slot322, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -16
  %ld3071 = load i64, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3071, ptr %slot325, align 8
  %v3072 = load i64, ptr %slot325, align 8
  %op3073 = and i64 %v3072, 4611686018427387906
  store i64 %op3073, ptr %slot326, align 8
  %v3074 = load i64, ptr %slot326, align 8
  %cmp3075 = icmp ne i64 %v3074, 0
  %cv3076 = zext i1 %cmp3075 to i32
  store i32 %cv3076, ptr %slot327, align 8
  %v3077 = load i32, ptr %slot327, align 8
  %cv3078 = zext i32 %v3077 to i64
  %cond3079 = icmp ne i64 %cv3078, 0
  br i1 %cond3079, label %bb_rcgclear409, label %bb_rcgcounted409
bb_rcgcounted409:
  %v3080 = load i64, ptr %slot322, align 8
  %op3081 = sub i64 %v3080, 32
  store i64 %op3081, ptr %slot328, align 8
  %v3082 = load i64, ptr %slot322, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %rgep3084 = getelementptr i8, ptr %p3083, i64 -32
  %ld3085 = load i64, ptr %rgep3084, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3085, ptr %slot329, align 8
  %v3086 = load i64, ptr %slot329, align 8
  %op3087 = sub i64 %v3086, 1
  store i64 %op3087, ptr %slot330, align 8
  %v3088 = load i64, ptr %slot330, align 8
  %cmp3089 = icmp eq i64 %v3088, 0
  %cv3090 = zext i1 %cmp3089 to i32
  store i32 %cv3090, ptr %slot331, align 8
  %v3091 = load i32, ptr %slot331, align 8
  %cv3092 = zext i32 %v3091 to i64
  %cond3093 = icmp ne i64 %cv3092, 0
  br i1 %cond3093, label %bb_rcglast409, label %bb_rcgdec409
bb_rcglast409:
  %v3094 = load i64, ptr %slot322, align 8
  %op3095 = sub i64 %v3094, 24
  store i64 %op3095, ptr %slot332, align 8
  %v3096 = load i64, ptr %slot322, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %rgep3098 = getelementptr i8, ptr %p3097, i64 -24
  %ld3099 = load i64, ptr %rgep3098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3099, ptr %slot333, align 8
  %v3100 = load i64, ptr %slot333, align 8
  %cmp3101 = icmp ne i64 %v3100, 0
  %cv3102 = zext i1 %cmp3101 to i32
  store i32 %cv3102, ptr %slot334, align 8
  %v3103 = load i32, ptr %slot334, align 8
  %cv3104 = zext i32 %v3103 to i64
  %cond3105 = icmp ne i64 %cv3104, 0
  br i1 %cond3105, label %bb_rcgdec409, label %bb_rcgslow409
bb_rcgslow409:
  %v3106 = load i64, ptr %slot321, align 8
  %v3107 = load i64, ptr %slot320, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3106, i64 %v3107) nomerge, !dbg !126
  br label %bb_rcgdone409
bb_rcgdec409:
  %v3108 = load i64, ptr %slot330, align 8
  %v3109 = load i64, ptr %slot322, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %rgep3111 = getelementptr i8, ptr %p3110, i64 -32
  store i64 %v3108, ptr %rgep3111, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear409
bb_rcgclear409:
  %v3112 = load i64, ptr %slot320, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  store i64 0, ptr %p3113, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone409
bb_rcgdone409:
  %v3114 = load i64, ptr %slot316, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  store i64 0, ptr %p3115, align 8, !alias.scope !3, !noalias !4
  %v3116 = load i64, ptr %slot316, align 8
  %p3118 = inttoptr i64 %v3116 to ptr
  %gep3119 = getelementptr i8, ptr %p3118, i64 8
  %op3117 = ptrtoint ptr %gep3119 to i64
  store i64 %op3117, ptr %slot335, align 8
  %v3120 = load i64, ptr %slot335, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 0, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot316, align 8
  %p3124 = inttoptr i64 %v3122 to ptr
  %gep3125 = getelementptr i8, ptr %p3124, i64 16
  %op3123 = ptrtoint ptr %gep3125 to i64
  store i64 %op3123, ptr %slot336, align 8
  %v3126 = load i64, ptr %slot336, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  store i64 0, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone391
bb_rcslotdone391:
  br label %bb_rcprepared349
bb_rcprepared349:
  %v3128 = load i64, ptr %slot7, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %ld3130 = load i32, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3130, ptr %slot337, align 8
  %v3131 = load i32, ptr %slot337, align 8
  %cv3132 = zext i32 %v3131 to i64
  %cond3133 = icmp ne i64 %cv3132, 0
  br i1 %cond3133, label %bb_rcslotdrop418, label %bb_rcslotdone418
bb_rcslotdrop418:
  %v3134 = load i64, ptr %slot7, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 0, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot38, align 8
  store i64 %v3136, ptr %slot338, align 8
  %v3137 = load i64, ptr %slot8, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  %ld3139 = load i32, ptr %p3138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3139, ptr %slot339, align 8
  %v3140 = load i32, ptr %slot339, align 8
  %op3141 = and i32 %v3140, 28
  store i32 %op3141, ptr %slot340, align 8
  %v3142 = load i32, ptr %slot340, align 8
  %cv3143 = zext i32 %v3142 to i64
  %cond3144 = icmp ne i64 %cv3143, 0
  br i1 %cond3144, label %bb_rcslotrole418, label %bb_rcslotowner418
bb_rcslotrole418:
  %v3145 = load i64, ptr %slot65, align 8
  store i64 %v3145, ptr %slot341, align 8
  %v3146 = load i64, ptr %slot341, align 8
  %v3147 = load i64, ptr %slot338, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3146, i64 %v3147) nomerge, !dbg !126
  br label %bb_rcslotdone418
bb_rcslotowner418:
  %v3148 = load i64, ptr %slot338, align 8
  %p3150 = inttoptr i64 %v3148 to ptr
  %gep3151 = getelementptr i8, ptr %p3150, i64 8
  %op3149 = ptrtoint ptr %gep3151 to i64
  store i64 %op3149, ptr %slot342, align 8
  %v3152 = load i64, ptr %slot65, align 8
  store i64 %v3152, ptr %slot343, align 8
  %v3153 = load i64, ptr %slot342, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %ld3155 = load i64, ptr %p3154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3155, ptr %slot344, align 8
  %v3156 = load i64, ptr %slot344, align 8
  %cmp3157 = icmp ne i64 %v3156, 0
  %cv3158 = zext i1 %cmp3157 to i32
  store i32 %cv3158, ptr %slot345, align 8
  %v3159 = load i32, ptr %slot345, align 8
  %cv3160 = zext i32 %v3159 to i64
  %cond3161 = icmp ne i64 %cv3160, 0
  br i1 %cond3161, label %bb_rcgnn436, label %bb_rcgdone436
bb_rcgnn436:
  %v3162 = load i64, ptr %slot344, align 8
  %op3163 = sub i64 %v3162, 16
  store i64 %op3163, ptr %slot346, align 8
  %v3164 = load i64, ptr %slot344, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %rgep3166 = getelementptr i8, ptr %p3165, i64 -16
  %ld3167 = load i64, ptr %rgep3166, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3167, ptr %slot347, align 8
  %v3168 = load i64, ptr %slot347, align 8
  %op3169 = and i64 %v3168, 4611686018427387906
  store i64 %op3169, ptr %slot348, align 8
  %v3170 = load i64, ptr %slot348, align 8
  %cmp3171 = icmp ne i64 %v3170, 0
  %cv3172 = zext i1 %cmp3171 to i32
  store i32 %cv3172, ptr %slot349, align 8
  %v3173 = load i32, ptr %slot349, align 8
  %cv3174 = zext i32 %v3173 to i64
  %cond3175 = icmp ne i64 %cv3174, 0
  br i1 %cond3175, label %bb_rcgclear436, label %bb_rcgcounted436
bb_rcgcounted436:
  %v3176 = load i64, ptr %slot344, align 8
  %op3177 = sub i64 %v3176, 32
  store i64 %op3177, ptr %slot350, align 8
  %v3178 = load i64, ptr %slot344, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  %rgep3180 = getelementptr i8, ptr %p3179, i64 -32
  %ld3181 = load i64, ptr %rgep3180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3181, ptr %slot351, align 8
  %v3182 = load i64, ptr %slot351, align 8
  %op3183 = sub i64 %v3182, 1
  store i64 %op3183, ptr %slot352, align 8
  %v3184 = load i64, ptr %slot352, align 8
  %cmp3185 = icmp eq i64 %v3184, 0
  %cv3186 = zext i1 %cmp3185 to i32
  store i32 %cv3186, ptr %slot353, align 8
  %v3187 = load i32, ptr %slot353, align 8
  %cv3188 = zext i32 %v3187 to i64
  %cond3189 = icmp ne i64 %cv3188, 0
  br i1 %cond3189, label %bb_rcglast436, label %bb_rcgdec436
bb_rcglast436:
  %v3190 = load i64, ptr %slot344, align 8
  %op3191 = sub i64 %v3190, 24
  store i64 %op3191, ptr %slot354, align 8
  %v3192 = load i64, ptr %slot344, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  %rgep3194 = getelementptr i8, ptr %p3193, i64 -24
  %ld3195 = load i64, ptr %rgep3194, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3195, ptr %slot355, align 8
  %v3196 = load i64, ptr %slot355, align 8
  %cmp3197 = icmp ne i64 %v3196, 0
  %cv3198 = zext i1 %cmp3197 to i32
  store i32 %cv3198, ptr %slot356, align 8
  %v3199 = load i32, ptr %slot356, align 8
  %cv3200 = zext i32 %v3199 to i64
  %cond3201 = icmp ne i64 %cv3200, 0
  br i1 %cond3201, label %bb_rcgdec436, label %bb_rcgslow436
bb_rcgslow436:
  %v3202 = load i64, ptr %slot343, align 8
  %v3203 = load i64, ptr %slot342, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3202, i64 %v3203) nomerge, !dbg !126
  br label %bb_rcgdone436
bb_rcgdec436:
  %v3204 = load i64, ptr %slot352, align 8
  %v3205 = load i64, ptr %slot344, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %rgep3207 = getelementptr i8, ptr %p3206, i64 -32
  store i64 %v3204, ptr %rgep3207, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear436
bb_rcgclear436:
  %v3208 = load i64, ptr %slot342, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  store i64 0, ptr %p3209, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone436
bb_rcgdone436:
  %v3210 = load i64, ptr %slot338, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i64 0, ptr %p3211, align 8, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot338, align 8
  %p3214 = inttoptr i64 %v3212 to ptr
  %gep3215 = getelementptr i8, ptr %p3214, i64 8
  %op3213 = ptrtoint ptr %gep3215 to i64
  store i64 %op3213, ptr %slot357, align 8
  %v3216 = load i64, ptr %slot357, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i64 0, ptr %p3217, align 8, !alias.scope !3, !noalias !4
  %v3218 = load i64, ptr %slot338, align 8
  %p3220 = inttoptr i64 %v3218 to ptr
  %gep3221 = getelementptr i8, ptr %p3220, i64 16
  %op3219 = ptrtoint ptr %gep3221 to i64
  store i64 %op3219, ptr %slot358, align 8
  %v3222 = load i64, ptr %slot358, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  store i64 0, ptr %p3223, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone418
bb_rcslotdone418:
  %v3224 = load i64, ptr %slot38, align 8
  store i64 %v3224, ptr %slot359, align 8
  %v3225 = load i64, ptr %slot32, align 8
  store i64 %v3225, ptr %slot360, align 8
  %v3226 = load i64, ptr %slot360, align 8
  %v3227 = load i64, ptr %slot359, align 8
  %p3228 = inttoptr i64 %v3226 to ptr
  %p3229 = inttoptr i64 %v3227 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3229, ptr %p3228, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3230 = load i64, ptr %slot27, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  store i32 0, ptr %p3231, align 4, !alias.scope !3, !noalias !4
  %v3232 = load i64, ptr %slot8, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i32 2, ptr %p3233, align 4, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot28, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  %ld3236 = load i32, ptr %p3235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3236, ptr %slot361, align 8
  %v3237 = load i32, ptr %slot361, align 8
  %v3238 = load i64, ptr %slot8, align 8
  %p3239 = inttoptr i64 %v3238 to ptr
  store i32 %v3237, ptr %p3239, align 4, !alias.scope !3, !noalias !4
  %v3240 = load i64, ptr %slot7, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i32 1, ptr %p3241, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept347
bb_rcselfkept347:
  %v3242 = load i64, ptr %slot35, align 8
  %v3243 = load i64, ptr %slot58, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i64 %v3242, ptr %p3244, align 8, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot38, align 8
  %v3246 = load i64, ptr %slot59, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  store i64 %v3245, ptr %p3247, align 8, !alias.scope !3, !noalias !4
  %v3248 = load i64, ptr %slot59, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %ld3250 = load i64, ptr %p3249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3250, ptr %slot362, align 8
  %v3251 = load i64, ptr %slot362, align 8
  %op3252 = add i64 %v3251, 0
  store i64 %op3252, ptr %slot363, align 8
  %v3253 = load i64, ptr %slot363, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %ld3255 = load i64, ptr %p3254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3255, ptr %slot364, align 8
  %v3256 = load i64, ptr %slot364, align 8
  %v3257 = load i64, ptr %slot59, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  store i64 %v3256, ptr %p3258, align 8, !alias.scope !3, !noalias !4
  %v3259 = load i64, ptr %slot25, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i32, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3261, ptr %slot365, align 8
  %v3262 = load i32, ptr %slot365, align 8
  %cv3263 = zext i32 %v3262 to i64
  %cond3264 = icmp ne i64 %cv3263, 0
  br i1 %cond3264, label %bb_rcslotdrop454, label %bb_rcslotdone454
bb_rcslotdrop454:
  %v3265 = load i64, ptr %slot25, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  store i32 0, ptr %p3266, align 4, !alias.scope !3, !noalias !4
  %v3267 = load i64, ptr %slot30, align 8
  store i64 %v3267, ptr %slot366, align 8
  %v3268 = load i64, ptr %slot26, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %ld3270 = load i32, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3270, ptr %slot367, align 8
  %v3271 = load i32, ptr %slot367, align 8
  %op3272 = and i32 %v3271, 28
  store i32 %op3272, ptr %slot368, align 8
  %v3273 = load i32, ptr %slot368, align 8
  %cv3274 = zext i32 %v3273 to i64
  %cond3275 = icmp ne i64 %cv3274, 0
  br i1 %cond3275, label %bb_rcslotrole454, label %bb_rcslotowner454
bb_rcslotrole454:
  %v3276 = load i64, ptr %slot65, align 8
  store i64 %v3276, ptr %slot369, align 8
  %v3277 = load i64, ptr %slot369, align 8
  %v3278 = load i64, ptr %slot366, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3277, i64 %v3278) nomerge, !dbg !128
  br label %bb_rcslotdone454
bb_rcslotowner454:
  %v3279 = load i64, ptr %slot65, align 8
  store i64 %v3279, ptr %slot370, align 8
  %v3280 = load i64, ptr %slot370, align 8
  %v3281 = load i64, ptr %slot366, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3280, i64 %v3281) nomerge, !dbg !128
  br label %bb_rcslotdone454
bb_rcslotdone454:
  %v3282 = load i64, ptr %slot58, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %ld3284 = load i64, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3284, ptr %slot371, align 8
  %v3285 = load i64, ptr %slot59, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  %ld3287 = load i64, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3287, ptr %slot372, align 8
  %v3288 = load i64, ptr %slot1, align 8
  %v3289 = load i64, ptr %slot371, align 8
  %v3290 = load i64, ptr %slot372, align 8
  %call3291 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v3288, i64 %v3289, i64 %v3290) nomerge, !dbg !130
  store i64 %call3291, ptr %slot373, align 8
  %v3292 = load i64, ptr %slot373, align 8
  %v3293 = load i64, ptr %slot58, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i64 %v3292, ptr %p3294, align 8, !alias.scope !3, !noalias !4
  %v3295 = load i64, ptr %slot23, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %ld3297 = load i32, ptr %p3296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3297, ptr %slot374, align 8
  %v3298 = load i32, ptr %slot374, align 8
  %cv3299 = zext i32 %v3298 to i64
  %cond3300 = icmp ne i64 %cv3299, 0
  br i1 %cond3300, label %bb_rcslotdrop466, label %bb_rcslotdone466
bb_rcslotdrop466:
  %v3301 = load i64, ptr %slot23, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  store i32 0, ptr %p3302, align 4, !alias.scope !3, !noalias !4
  %v3303 = load i64, ptr %slot29, align 8
  store i64 %v3303, ptr %slot375, align 8
  %v3304 = load i64, ptr %slot24, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  %ld3306 = load i32, ptr %p3305, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3306, ptr %slot376, align 8
  %v3307 = load i32, ptr %slot376, align 8
  %op3308 = and i32 %v3307, 28
  store i32 %op3308, ptr %slot377, align 8
  %v3309 = load i32, ptr %slot377, align 8
  %cv3310 = zext i32 %v3309 to i64
  %cond3311 = icmp ne i64 %cv3310, 0
  br i1 %cond3311, label %bb_rcslotrole466, label %bb_rcslotowner466
bb_rcslotrole466:
  %v3312 = load i64, ptr %slot65, align 8
  store i64 %v3312, ptr %slot378, align 8
  %v3313 = load i64, ptr %slot378, align 8
  %v3314 = load i64, ptr %slot375, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v3313, i64 %v3314) nomerge, !dbg !130
  br label %bb_rcslotdone466
bb_rcslotowner466:
  %v3315 = load i64, ptr %slot65, align 8
  store i64 %v3315, ptr %slot379, align 8
  %v3316 = load i64, ptr %slot379, align 8
  %v3317 = load i64, ptr %slot375, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v3316, i64 %v3317) nomerge, !dbg !130
  br label %bb_rcslotdone466
bb_rcslotdone466:
  %v3318 = load i64, ptr %slot35, align 8
  %v3319 = load i64, ptr %slot58, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i64 %v3318, ptr %p3320, align 8, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot38, align 8
  %v3322 = load i64, ptr %slot59, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i64 %v3321, ptr %p3323, align 8, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot59, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %ld3326 = load i64, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3326, ptr %slot380, align 8
  %v3327 = load i64, ptr %slot380, align 8
  %op3328 = add i64 %v3327, 8
  store i64 %op3328, ptr %slot381, align 8
  %v3329 = load i64, ptr %slot381, align 8
  %v3330 = load i64, ptr %slot59, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  store i64 %v3329, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  %v3332 = load i64, ptr %slot59, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot382, align 8
  %v3335 = load i64, ptr %slot32, align 8
  store i64 %v3335, ptr %slot383, align 8
  %v3336 = load i64, ptr %slot65, align 8
  %v3337 = load i64, ptr %slot383, align 8
  %v3338 = load i64, ptr %slot382, align 8
  %call3339 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v3336, i64 %v3337, i64 %v3338) nomerge, !dbg !132
  store i32 %call3339, ptr %slot384, align 8
  %v3340 = load i32, ptr %slot384, align 8
  %cv3341 = zext i32 %v3340 to i64
  %cond3342 = icmp ne i64 %cv3341, 0
  br i1 %cond3342, label %bb_rcsuccess478, label %bb_rcfailure478
bb_rcfailure478:
  %v3343 = load i64, ptr %slot65, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  %call3345 = call i32 @myl_rc_take_failure(ptr %p3344) nomerge, !dbg !132
  store i32 %call3345, ptr %slot385, align 8
  %v3346 = load i64, ptr %slot1, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  %v3348 = load i32, ptr %slot385, align 8
  %call3349 = call i32 @myl_qbe_rc_status(ptr %p3347, i32 %v3348) nomerge, !dbg !132
  store i32 %call3349, ptr %slot386, align 8
  br label %bb_failure
bb_rcsuccess478:
  %v3350 = load i64, ptr %slot28, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  store i32 2, ptr %p3351, align 4, !alias.scope !3, !noalias !4
  %v3352 = load i64, ptr %slot28, align 8
  %p3353 = inttoptr i64 %v3352 to ptr
  store i32 16, ptr %p3353, align 4, !alias.scope !3, !noalias !4
  %v3354 = load i64, ptr %slot27, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  store i32 1, ptr %p3355, align 4, !alias.scope !3, !noalias !4
  %v3356 = load i64, ptr %slot25, align 8
  %p3357 = inttoptr i64 %v3356 to ptr
  %ld3358 = load i32, ptr %p3357, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3358, ptr %slot387, align 8
  %v3359 = load i32, ptr %slot387, align 8
  %cv3360 = zext i32 %v3359 to i64
  %cond3361 = icmp ne i64 %cv3360, 0
  br i1 %cond3361, label %bb_rcslotdrop486, label %bb_rcslotdone486
bb_rcslotdrop486:
  %v3362 = load i64, ptr %slot25, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  store i32 0, ptr %p3363, align 4, !alias.scope !3, !noalias !4
  %v3364 = load i64, ptr %slot30, align 8
  store i64 %v3364, ptr %slot388, align 8
  %v3365 = load i64, ptr %slot26, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  %ld3367 = load i32, ptr %p3366, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3367, ptr %slot389, align 8
  %v3368 = load i32, ptr %slot389, align 8
  %op3369 = and i32 %v3368, 28
  store i32 %op3369, ptr %slot390, align 8
  %v3370 = load i32, ptr %slot390, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcslotrole486, label %bb_rcslotowner486
bb_rcslotrole486:
  %v3373 = load i64, ptr %slot65, align 8
  store i64 %v3373, ptr %slot391, align 8
  %v3374 = load i64, ptr %slot391, align 8
  %v3375 = load i64, ptr %slot388, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3374, i64 %v3375) nomerge, !dbg !132
  br label %bb_rcslotdone486
bb_rcslotowner486:
  %v3376 = load i64, ptr %slot65, align 8
  store i64 %v3376, ptr %slot392, align 8
  %v3377 = load i64, ptr %slot392, align 8
  %v3378 = load i64, ptr %slot388, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3377, i64 %v3378) nomerge, !dbg !132
  br label %bb_rcslotdone486
bb_rcslotdone486:
  %v3379 = load i64, ptr %slot30, align 8
  store i64 %v3379, ptr %slot393, align 8
  %v3380 = load i64, ptr %slot32, align 8
  store i64 %v3380, ptr %slot394, align 8
  %v3381 = load i64, ptr %slot394, align 8
  %v3382 = load i64, ptr %slot393, align 8
  %p3383 = inttoptr i64 %v3381 to ptr
  %p3384 = inttoptr i64 %v3382 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3384, ptr %p3383, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3385 = load i64, ptr %slot26, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i32 2, ptr %p3386, align 4, !alias.scope !3, !noalias !4
  %v3387 = load i64, ptr %slot28, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i32, ptr %p3388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3389, ptr %slot395, align 8
  %v3390 = load i32, ptr %slot395, align 8
  %v3391 = load i64, ptr %slot26, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i32 %v3390, ptr %p3392, align 4, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot27, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 0, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot25, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  store i32 1, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  %v3397 = load i64, ptr %slot393, align 8
  %v3398 = load i64, ptr %slot59, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  store i64 %v3397, ptr %p3399, align 8, !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot58, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  %ld3402 = load i64, ptr %p3401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3402, ptr %slot396, align 8
  %v3403 = load i64, ptr %slot59, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %ld3405 = load i64, ptr %p3404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3405, ptr %slot397, align 8
  %v3406 = load i64, ptr %slot1, align 8
  %v3407 = load i64, ptr %slot396, align 8
  %v3408 = load i64, ptr %slot397, align 8
  %call3409 = call i64 @myl_f_f0393a69ddd4c3d9aed35cdcfaedcd9f0376ae1fd953f70833a16f0c06c4cd97(i64 %v3406, i64 %v3407, i64 %v3408) nomerge, !dbg !134
  store i64 %call3409, ptr %slot398, align 8
  %v3410 = load i64, ptr %slot398, align 8
  %v3411 = load i64, ptr %slot58, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  store i64 %v3410, ptr %p3412, align 8, !alias.scope !3, !noalias !4
  %v3413 = load i64, ptr %slot23, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  %ld3415 = load i32, ptr %p3414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3415, ptr %slot399, align 8
  %v3416 = load i32, ptr %slot399, align 8
  %cv3417 = zext i32 %v3416 to i64
  %cond3418 = icmp ne i64 %cv3417, 0
  br i1 %cond3418, label %bb_rcslotdrop506, label %bb_rcslotdone506
bb_rcslotdrop506:
  %v3419 = load i64, ptr %slot23, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  store i32 0, ptr %p3420, align 4, !alias.scope !3, !noalias !4
  %v3421 = load i64, ptr %slot29, align 8
  store i64 %v3421, ptr %slot400, align 8
  %v3422 = load i64, ptr %slot24, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  %ld3424 = load i32, ptr %p3423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3424, ptr %slot401, align 8
  %v3425 = load i32, ptr %slot401, align 8
  %op3426 = and i32 %v3425, 28
  store i32 %op3426, ptr %slot402, align 8
  %v3427 = load i32, ptr %slot402, align 8
  %cv3428 = zext i32 %v3427 to i64
  %cond3429 = icmp ne i64 %cv3428, 0
  br i1 %cond3429, label %bb_rcslotrole506, label %bb_rcslotowner506
bb_rcslotrole506:
  %v3430 = load i64, ptr %slot65, align 8
  store i64 %v3430, ptr %slot403, align 8
  %v3431 = load i64, ptr %slot403, align 8
  %v3432 = load i64, ptr %slot400, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v3431, i64 %v3432) nomerge, !dbg !134
  br label %bb_rcslotdone506
bb_rcslotowner506:
  %v3433 = load i64, ptr %slot65, align 8
  store i64 %v3433, ptr %slot404, align 8
  %v3434 = load i64, ptr %slot404, align 8
  %v3435 = load i64, ptr %slot400, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v3434, i64 %v3435) nomerge, !dbg !134
  br label %bb_rcslotdone506
bb_rcslotdone506:
  %v3436 = load i64, ptr %slot25, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %ld3438 = load i32, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3438, ptr %slot405, align 8
  %v3439 = load i32, ptr %slot405, align 8
  %cv3440 = zext i32 %v3439 to i64
  %cond3441 = icmp ne i64 %cv3440, 0
  br i1 %cond3441, label %bb_rcslotdrop515, label %bb_rcslotdone515
bb_rcslotdrop515:
  %v3442 = load i64, ptr %slot25, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  store i32 0, ptr %p3443, align 4, !alias.scope !3, !noalias !4
  %v3444 = load i64, ptr %slot30, align 8
  store i64 %v3444, ptr %slot406, align 8
  %v3445 = load i64, ptr %slot26, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  %ld3447 = load i32, ptr %p3446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3447, ptr %slot407, align 8
  %v3448 = load i32, ptr %slot407, align 8
  %op3449 = and i32 %v3448, 28
  store i32 %op3449, ptr %slot408, align 8
  %v3450 = load i32, ptr %slot408, align 8
  %cv3451 = zext i32 %v3450 to i64
  %cond3452 = icmp ne i64 %cv3451, 0
  br i1 %cond3452, label %bb_rcslotrole515, label %bb_rcslotowner515
bb_rcslotrole515:
  %v3453 = load i64, ptr %slot65, align 8
  store i64 %v3453, ptr %slot409, align 8
  %v3454 = load i64, ptr %slot409, align 8
  %v3455 = load i64, ptr %slot406, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3454, i64 %v3455) nomerge, !dbg !134
  br label %bb_rcslotdone515
bb_rcslotowner515:
  %v3456 = load i64, ptr %slot65, align 8
  store i64 %v3456, ptr %slot410, align 8
  %v3457 = load i64, ptr %slot410, align 8
  %v3458 = load i64, ptr %slot406, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3457, i64 %v3458) nomerge, !dbg !134
  br label %bb_rcslotdone515
bb_rcslotdone515:
  %v3459 = load i64, ptr %slot7, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  %ld3461 = load i32, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3461, ptr %slot411, align 8
  %v3462 = load i32, ptr %slot411, align 8
  %cv3463 = zext i32 %v3462 to i64
  %cond3464 = icmp ne i64 %cv3463, 0
  br i1 %cond3464, label %bb_rcslotdrop524, label %bb_rcslotdone524
bb_rcslotdrop524:
  %v3465 = load i64, ptr %slot7, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i32 0, ptr %p3466, align 4, !alias.scope !3, !noalias !4
  %v3467 = load i64, ptr %slot38, align 8
  store i64 %v3467, ptr %slot412, align 8
  %v3468 = load i64, ptr %slot8, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i32, ptr %p3469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3470, ptr %slot413, align 8
  %v3471 = load i32, ptr %slot413, align 8
  %op3472 = and i32 %v3471, 28
  store i32 %op3472, ptr %slot414, align 8
  %v3473 = load i32, ptr %slot414, align 8
  %cv3474 = zext i32 %v3473 to i64
  %cond3475 = icmp ne i64 %cv3474, 0
  br i1 %cond3475, label %bb_rcslotrole524, label %bb_rcslotowner524
bb_rcslotrole524:
  %v3476 = load i64, ptr %slot65, align 8
  store i64 %v3476, ptr %slot415, align 8
  %v3477 = load i64, ptr %slot415, align 8
  %v3478 = load i64, ptr %slot412, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3477, i64 %v3478) nomerge, !dbg !136
  br label %bb_rcslotdone524
bb_rcslotowner524:
  %v3479 = load i64, ptr %slot412, align 8
  %p3481 = inttoptr i64 %v3479 to ptr
  %gep3482 = getelementptr i8, ptr %p3481, i64 8
  %op3480 = ptrtoint ptr %gep3482 to i64
  store i64 %op3480, ptr %slot416, align 8
  %v3483 = load i64, ptr %slot65, align 8
  store i64 %v3483, ptr %slot417, align 8
  %v3484 = load i64, ptr %slot416, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %ld3486 = load i64, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3486, ptr %slot418, align 8
  %v3487 = load i64, ptr %slot418, align 8
  %cmp3488 = icmp ne i64 %v3487, 0
  %cv3489 = zext i1 %cmp3488 to i32
  store i32 %cv3489, ptr %slot419, align 8
  %v3490 = load i32, ptr %slot419, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcgnn542, label %bb_rcgdone542
bb_rcgnn542:
  %v3493 = load i64, ptr %slot418, align 8
  %op3494 = sub i64 %v3493, 16
  store i64 %op3494, ptr %slot420, align 8
  %v3495 = load i64, ptr %slot418, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %rgep3497 = getelementptr i8, ptr %p3496, i64 -16
  %ld3498 = load i64, ptr %rgep3497, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3498, ptr %slot421, align 8
  %v3499 = load i64, ptr %slot421, align 8
  %op3500 = and i64 %v3499, 4611686018427387906
  store i64 %op3500, ptr %slot422, align 8
  %v3501 = load i64, ptr %slot422, align 8
  %cmp3502 = icmp ne i64 %v3501, 0
  %cv3503 = zext i1 %cmp3502 to i32
  store i32 %cv3503, ptr %slot423, align 8
  %v3504 = load i32, ptr %slot423, align 8
  %cv3505 = zext i32 %v3504 to i64
  %cond3506 = icmp ne i64 %cv3505, 0
  br i1 %cond3506, label %bb_rcgclear542, label %bb_rcgcounted542
bb_rcgcounted542:
  %v3507 = load i64, ptr %slot418, align 8
  %op3508 = sub i64 %v3507, 32
  store i64 %op3508, ptr %slot424, align 8
  %v3509 = load i64, ptr %slot418, align 8
  %p3510 = inttoptr i64 %v3509 to ptr
  %rgep3511 = getelementptr i8, ptr %p3510, i64 -32
  %ld3512 = load i64, ptr %rgep3511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3512, ptr %slot425, align 8
  %v3513 = load i64, ptr %slot425, align 8
  %op3514 = sub i64 %v3513, 1
  store i64 %op3514, ptr %slot426, align 8
  %v3515 = load i64, ptr %slot426, align 8
  %cmp3516 = icmp eq i64 %v3515, 0
  %cv3517 = zext i1 %cmp3516 to i32
  store i32 %cv3517, ptr %slot427, align 8
  %v3518 = load i32, ptr %slot427, align 8
  %cv3519 = zext i32 %v3518 to i64
  %cond3520 = icmp ne i64 %cv3519, 0
  br i1 %cond3520, label %bb_rcglast542, label %bb_rcgdec542
bb_rcglast542:
  %v3521 = load i64, ptr %slot418, align 8
  %op3522 = sub i64 %v3521, 24
  store i64 %op3522, ptr %slot428, align 8
  %v3523 = load i64, ptr %slot418, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %rgep3525 = getelementptr i8, ptr %p3524, i64 -24
  %ld3526 = load i64, ptr %rgep3525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3526, ptr %slot429, align 8
  %v3527 = load i64, ptr %slot429, align 8
  %cmp3528 = icmp ne i64 %v3527, 0
  %cv3529 = zext i1 %cmp3528 to i32
  store i32 %cv3529, ptr %slot430, align 8
  %v3530 = load i32, ptr %slot430, align 8
  %cv3531 = zext i32 %v3530 to i64
  %cond3532 = icmp ne i64 %cv3531, 0
  br i1 %cond3532, label %bb_rcgdec542, label %bb_rcgslow542
bb_rcgslow542:
  %v3533 = load i64, ptr %slot417, align 8
  %v3534 = load i64, ptr %slot416, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3533, i64 %v3534) nomerge, !dbg !136
  br label %bb_rcgdone542
bb_rcgdec542:
  %v3535 = load i64, ptr %slot426, align 8
  %v3536 = load i64, ptr %slot418, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  %rgep3538 = getelementptr i8, ptr %p3537, i64 -32
  store i64 %v3535, ptr %rgep3538, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear542
bb_rcgclear542:
  %v3539 = load i64, ptr %slot416, align 8
  %p3540 = inttoptr i64 %v3539 to ptr
  store i64 0, ptr %p3540, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone542
bb_rcgdone542:
  %v3541 = load i64, ptr %slot412, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  store i64 0, ptr %p3542, align 8, !alias.scope !3, !noalias !4
  %v3543 = load i64, ptr %slot412, align 8
  %p3545 = inttoptr i64 %v3543 to ptr
  %gep3546 = getelementptr i8, ptr %p3545, i64 8
  %op3544 = ptrtoint ptr %gep3546 to i64
  store i64 %op3544, ptr %slot431, align 8
  %v3547 = load i64, ptr %slot431, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  store i64 0, ptr %p3548, align 8, !alias.scope !3, !noalias !4
  %v3549 = load i64, ptr %slot412, align 8
  %p3551 = inttoptr i64 %v3549 to ptr
  %gep3552 = getelementptr i8, ptr %p3551, i64 16
  %op3550 = ptrtoint ptr %gep3552 to i64
  store i64 %op3550, ptr %slot432, align 8
  %v3553 = load i64, ptr %slot432, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  store i64 0, ptr %p3554, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone524
bb_rcslotdone524:
  br label %bb_i198
bb_i36:
  %v3555 = load i64, ptr %slot39, align 8
  %v3556 = load i64, ptr %slot58, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  store i64 %v3555, ptr %p3557, align 8, !alias.scope !3, !noalias !4
  %v3558 = load i64, ptr %slot9, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  %ld3560 = load i32, ptr %p3559, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3560, ptr %slot433, align 8
  %v3561 = load i64, ptr %slot10, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  %ld3563 = load i32, ptr %p3562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3563, ptr %slot434, align 8
  %v3564 = load i32, ptr %slot434, align 8
  %op3565 = and i32 %v3564, 24
  store i32 %op3565, ptr %slot434, align 8
  %v3566 = load i32, ptr %slot434, align 8
  %cmp3567 = icmp eq i32 %v3566, 0
  %cv3568 = zext i1 %cmp3567 to i32
  store i32 %cv3568, ptr %slot435, align 8
  %v3569 = load i32, ptr %slot433, align 8
  %v3570 = load i32, ptr %slot435, align 8
  %op3571 = and i32 %v3569, %v3570
  store i32 %op3571, ptr %slot436, align 8
  %v3572 = load i32, ptr %slot436, align 8
  %cv3573 = zext i32 %v3572 to i64
  %cond3574 = icmp ne i64 %cv3573, 0
  br i1 %cond3574, label %bb_rcselfkept554, label %bb_rcselfstore554
bb_rcselfstore554:
  %v3575 = load i64, ptr %slot58, align 8
  %p3576 = inttoptr i64 %v3575 to ptr
  %ld3577 = load i64, ptr %p3576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3577, ptr %slot437, align 8
  %v3578 = load i64, ptr %slot23, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  %ld3580 = load i32, ptr %p3579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3580, ptr %slot438, align 8
  %v3581 = load i64, ptr %slot24, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %ld3583 = load i32, ptr %p3582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3583, ptr %slot439, align 8
  %v3584 = load i32, ptr %slot439, align 8
  %op3585 = and i32 %v3584, 24
  store i32 %op3585, ptr %slot439, align 8
  %v3586 = load i32, ptr %slot439, align 8
  %cmp3587 = icmp eq i32 %v3586, 0
  %cv3588 = zext i1 %cmp3587 to i32
  store i32 %cv3588, ptr %slot440, align 8
  %v3589 = load i32, ptr %slot438, align 8
  %v3590 = load i32, ptr %slot440, align 8
  %op3591 = and i32 %v3589, %v3590
  store i32 %op3591, ptr %slot441, align 8
  %v3592 = load i32, ptr %slot441, align 8
  %cv3593 = zext i32 %v3592 to i64
  %cond3594 = icmp ne i64 %cv3593, 0
  br i1 %cond3594, label %bb_rctake556, label %bb_rccopy556
bb_rctake556:
  %v3595 = load i64, ptr %slot32, align 8
  store i64 %v3595, ptr %slot442, align 8
  %v3596 = load i64, ptr %slot66, align 8
  store i64 %v3596, ptr %slot443, align 8
  %v3597 = load i64, ptr %slot437, align 8
  %v3598 = load i64, ptr %slot442, align 8
  %op3599 = sub i64 %v3597, %v3598
  store i64 %op3599, ptr %slot444, align 8
  %v3600 = load i64, ptr %slot442, align 8
  %v3601 = load i64, ptr %slot437, align 8
  %op3602 = sub i64 %v3600, %v3601
  store i64 %op3602, ptr %slot445, align 8
  %v3603 = load i64, ptr %slot444, align 8
  %cmp3604 = icmp ult i64 %v3603, 24
  %cv3605 = zext i1 %cmp3604 to i32
  store i32 %cv3605, ptr %slot446, align 8
  %v3606 = load i64, ptr %slot445, align 8
  %cmp3607 = icmp ult i64 %v3606, 24
  %cv3608 = zext i1 %cmp3607 to i32
  store i32 %cv3608, ptr %slot447, align 8
  %v3609 = load i32, ptr %slot446, align 8
  %v3610 = load i32, ptr %slot447, align 8
  %op3611 = or i32 %v3609, %v3610
  store i32 %op3611, ptr %slot448, align 8
  %v3612 = load i32, ptr %slot448, align 8
  %cv3613 = zext i32 %v3612 to i64
  %cond3614 = icmp ne i64 %cv3613, 0
  br i1 %cond3614, label %bb_rcmoveslow565, label %bb_rcmovecheck565
bb_rcmovecheck565:
  %v3615 = load i64, ptr %slot437, align 8
  %op3616 = add i64 %v3615, 8
  store i64 %op3616, ptr %slot449, align 8
  %v3617 = load i64, ptr %slot449, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  %ld3619 = load i64, ptr %p3618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3619, ptr %slot450, align 8
  %v3620 = load i64, ptr %slot450, align 8
  %cmp3621 = icmp ne i64 %v3620, 0
  %cv3622 = zext i1 %cmp3621 to i32
  store i32 %cv3622, ptr %slot451, align 8
  %v3623 = load i32, ptr %slot451, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcmoveheader573, label %bb_rcmovenext573
bb_rcmoveheader573:
  %v3626 = load i64, ptr %slot450, align 8
  %op3627 = sub i64 %v3626, 16
  store i64 %op3627, ptr %slot452, align 8
  %v3628 = load i64, ptr %slot450, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  %rgep3630 = getelementptr i8, ptr %p3629, i64 -16
  %ld3631 = load i64, ptr %rgep3630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3631, ptr %slot453, align 8
  %v3632 = load i64, ptr %slot453, align 8
  %op3633 = and i64 %v3632, 5764607523034234881
  store i64 %op3633, ptr %slot454, align 8
  %v3634 = load i64, ptr %slot454, align 8
  %cmp3635 = icmp ne i64 %v3634, 0
  %cv3636 = zext i1 %cmp3635 to i32
  store i32 %cv3636, ptr %slot455, align 8
  %v3637 = load i32, ptr %slot455, align 8
  %cv3638 = zext i32 %v3637 to i64
  %cond3639 = icmp ne i64 %cv3638, 0
  br i1 %cond3639, label %bb_rcmoveslow565, label %bb_rcmovenext573
bb_rcmovenext573:
  %v3640 = load i64, ptr %slot437, align 8
  %v3641 = load i64, ptr %slot442, align 8
  %p3642 = inttoptr i64 %v3640 to ptr
  %p3643 = inttoptr i64 %v3641 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3643, ptr %p3642, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3644 = load i64, ptr %slot437, align 8
  %p3645 = inttoptr i64 %v3644 to ptr
  store i64 0, ptr %p3645, align 8, !alias.scope !3, !noalias !4
  %v3646 = load i64, ptr %slot437, align 8
  %op3647 = add i64 %v3646, 8
  store i64 %op3647, ptr %slot456, align 8
  %v3648 = load i64, ptr %slot456, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  store i64 0, ptr %p3649, align 8, !alias.scope !3, !noalias !4
  %v3650 = load i64, ptr %slot437, align 8
  %op3651 = add i64 %v3650, 16
  store i64 %op3651, ptr %slot457, align 8
  %v3652 = load i64, ptr %slot457, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  store i64 0, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved565
bb_rcmoveslow565:
  %v3654 = load i64, ptr %slot65, align 8
  %v3655 = load i64, ptr %slot442, align 8
  %v3656 = load i64, ptr %slot437, align 8
  %v3657 = load i64, ptr %slot443, align 8
  %cv3658 = trunc i64 %v3657 to i32
  %call3659 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v3654, i64 %v3655, i64 %v3656, i32 %cv3658) nomerge, !dbg !138
  store i32 %call3659, ptr %slot458, align 8
  %v3660 = load i32, ptr %slot458, align 8
  %cv3661 = zext i32 %v3660 to i64
  %cond3662 = icmp ne i64 %cv3661, 0
  br i1 %cond3662, label %bb_rcsuccess582, label %bb_rcfailure582
bb_rcfailure582:
  %v3663 = load i64, ptr %slot65, align 8
  %p3664 = inttoptr i64 %v3663 to ptr
  %call3665 = call i32 @myl_rc_take_failure(ptr %p3664) nomerge, !dbg !138
  store i32 %call3665, ptr %slot459, align 8
  %v3666 = load i64, ptr %slot1, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  %v3668 = load i32, ptr %slot459, align 8
  %call3669 = call i32 @myl_qbe_rc_status(ptr %p3667, i32 %v3668) nomerge, !dbg !138
  store i32 %call3669, ptr %slot460, align 8
  br label %bb_failure
bb_rcsuccess582:
  br label %bb_rcmoved565
bb_rcmoved565:
  %v3670 = load i64, ptr %slot23, align 8
  %p3671 = inttoptr i64 %v3670 to ptr
  store i32 0, ptr %p3671, align 4, !alias.scope !3, !noalias !4
  %v3672 = load i64, ptr %slot28, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  store i32 2, ptr %p3673, align 4, !alias.scope !3, !noalias !4
  %v3674 = load i64, ptr %slot27, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  store i32 1, ptr %p3675, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared556
bb_rccopy556:
  %v3676 = load i64, ptr %slot32, align 8
  store i64 %v3676, ptr %slot461, align 8
  %v3677 = load i64, ptr %slot66, align 8
  store i64 %v3677, ptr %slot462, align 8
  %v3678 = load i64, ptr %slot65, align 8
  %v3679 = load i64, ptr %slot461, align 8
  %v3680 = load i64, ptr %slot437, align 8
  %v3681 = load i64, ptr %slot462, align 8
  %cv3682 = trunc i64 %v3681 to i32
  %call3683 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v3678, i64 %v3679, i64 %v3680, i32 %cv3682) nomerge, !dbg !138
  store i32 %call3683, ptr %slot463, align 8
  %v3684 = load i32, ptr %slot463, align 8
  %cv3685 = zext i32 %v3684 to i64
  %cond3686 = icmp ne i64 %cv3685, 0
  br i1 %cond3686, label %bb_rcsuccess591, label %bb_rcfailure591
bb_rcfailure591:
  %v3687 = load i64, ptr %slot65, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %call3689 = call i32 @myl_rc_take_failure(ptr %p3688) nomerge, !dbg !138
  store i32 %call3689, ptr %slot464, align 8
  %v3690 = load i64, ptr %slot1, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %v3692 = load i32, ptr %slot464, align 8
  %call3693 = call i32 @myl_qbe_rc_status(ptr %p3691, i32 %v3692) nomerge, !dbg !138
  store i32 %call3693, ptr %slot465, align 8
  br label %bb_failure
bb_rcsuccess591:
  %v3694 = load i64, ptr %slot28, align 8
  %p3695 = inttoptr i64 %v3694 to ptr
  store i32 2, ptr %p3695, align 4, !alias.scope !3, !noalias !4
  %v3696 = load i64, ptr %slot27, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  store i32 1, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  %v3698 = load i64, ptr %slot23, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  %ld3700 = load i32, ptr %p3699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3700, ptr %slot466, align 8
  %v3701 = load i32, ptr %slot466, align 8
  %cv3702 = zext i32 %v3701 to i64
  %cond3703 = icmp ne i64 %cv3702, 0
  br i1 %cond3703, label %bb_rcslotdrop598, label %bb_rcslotdone598
bb_rcslotdrop598:
  %v3704 = load i64, ptr %slot23, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  store i32 0, ptr %p3705, align 4, !alias.scope !3, !noalias !4
  %v3706 = load i64, ptr %slot29, align 8
  store i64 %v3706, ptr %slot467, align 8
  %v3707 = load i64, ptr %slot24, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  %ld3709 = load i32, ptr %p3708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3709, ptr %slot468, align 8
  %v3710 = load i32, ptr %slot468, align 8
  %op3711 = and i32 %v3710, 28
  store i32 %op3711, ptr %slot469, align 8
  %v3712 = load i32, ptr %slot469, align 8
  %cv3713 = zext i32 %v3712 to i64
  %cond3714 = icmp ne i64 %cv3713, 0
  br i1 %cond3714, label %bb_rcslotrole598, label %bb_rcslotowner598
bb_rcslotrole598:
  %v3715 = load i64, ptr %slot65, align 8
  store i64 %v3715, ptr %slot470, align 8
  %v3716 = load i64, ptr %slot470, align 8
  %v3717 = load i64, ptr %slot467, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3716, i64 %v3717) nomerge, !dbg !138
  br label %bb_rcslotdone598
bb_rcslotowner598:
  %v3718 = load i64, ptr %slot467, align 8
  %p3720 = inttoptr i64 %v3718 to ptr
  %gep3721 = getelementptr i8, ptr %p3720, i64 8
  %op3719 = ptrtoint ptr %gep3721 to i64
  store i64 %op3719, ptr %slot471, align 8
  %v3722 = load i64, ptr %slot65, align 8
  store i64 %v3722, ptr %slot472, align 8
  %v3723 = load i64, ptr %slot471, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i64, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3725, ptr %slot473, align 8
  %v3726 = load i64, ptr %slot473, align 8
  %cmp3727 = icmp ne i64 %v3726, 0
  %cv3728 = zext i1 %cmp3727 to i32
  store i32 %cv3728, ptr %slot474, align 8
  %v3729 = load i32, ptr %slot474, align 8
  %cv3730 = zext i32 %v3729 to i64
  %cond3731 = icmp ne i64 %cv3730, 0
  br i1 %cond3731, label %bb_rcgnn616, label %bb_rcgdone616
bb_rcgnn616:
  %v3732 = load i64, ptr %slot473, align 8
  %op3733 = sub i64 %v3732, 16
  store i64 %op3733, ptr %slot475, align 8
  %v3734 = load i64, ptr %slot473, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %rgep3736 = getelementptr i8, ptr %p3735, i64 -16
  %ld3737 = load i64, ptr %rgep3736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3737, ptr %slot476, align 8
  %v3738 = load i64, ptr %slot476, align 8
  %op3739 = and i64 %v3738, 4611686018427387906
  store i64 %op3739, ptr %slot477, align 8
  %v3740 = load i64, ptr %slot477, align 8
  %cmp3741 = icmp ne i64 %v3740, 0
  %cv3742 = zext i1 %cmp3741 to i32
  store i32 %cv3742, ptr %slot478, align 8
  %v3743 = load i32, ptr %slot478, align 8
  %cv3744 = zext i32 %v3743 to i64
  %cond3745 = icmp ne i64 %cv3744, 0
  br i1 %cond3745, label %bb_rcgclear616, label %bb_rcgcounted616
bb_rcgcounted616:
  %v3746 = load i64, ptr %slot473, align 8
  %op3747 = sub i64 %v3746, 32
  store i64 %op3747, ptr %slot479, align 8
  %v3748 = load i64, ptr %slot473, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %rgep3750 = getelementptr i8, ptr %p3749, i64 -32
  %ld3751 = load i64, ptr %rgep3750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3751, ptr %slot480, align 8
  %v3752 = load i64, ptr %slot480, align 8
  %op3753 = sub i64 %v3752, 1
  store i64 %op3753, ptr %slot481, align 8
  %v3754 = load i64, ptr %slot481, align 8
  %cmp3755 = icmp eq i64 %v3754, 0
  %cv3756 = zext i1 %cmp3755 to i32
  store i32 %cv3756, ptr %slot482, align 8
  %v3757 = load i32, ptr %slot482, align 8
  %cv3758 = zext i32 %v3757 to i64
  %cond3759 = icmp ne i64 %cv3758, 0
  br i1 %cond3759, label %bb_rcglast616, label %bb_rcgdec616
bb_rcglast616:
  %v3760 = load i64, ptr %slot473, align 8
  %op3761 = sub i64 %v3760, 24
  store i64 %op3761, ptr %slot483, align 8
  %v3762 = load i64, ptr %slot473, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %rgep3764 = getelementptr i8, ptr %p3763, i64 -24
  %ld3765 = load i64, ptr %rgep3764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3765, ptr %slot484, align 8
  %v3766 = load i64, ptr %slot484, align 8
  %cmp3767 = icmp ne i64 %v3766, 0
  %cv3768 = zext i1 %cmp3767 to i32
  store i32 %cv3768, ptr %slot485, align 8
  %v3769 = load i32, ptr %slot485, align 8
  %cv3770 = zext i32 %v3769 to i64
  %cond3771 = icmp ne i64 %cv3770, 0
  br i1 %cond3771, label %bb_rcgdec616, label %bb_rcgslow616
bb_rcgslow616:
  %v3772 = load i64, ptr %slot472, align 8
  %v3773 = load i64, ptr %slot471, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3772, i64 %v3773) nomerge, !dbg !138
  br label %bb_rcgdone616
bb_rcgdec616:
  %v3774 = load i64, ptr %slot481, align 8
  %v3775 = load i64, ptr %slot473, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %rgep3777 = getelementptr i8, ptr %p3776, i64 -32
  store i64 %v3774, ptr %rgep3777, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear616
bb_rcgclear616:
  %v3778 = load i64, ptr %slot471, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  store i64 0, ptr %p3779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone616
bb_rcgdone616:
  %v3780 = load i64, ptr %slot467, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  store i64 0, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  %v3782 = load i64, ptr %slot467, align 8
  %p3784 = inttoptr i64 %v3782 to ptr
  %gep3785 = getelementptr i8, ptr %p3784, i64 8
  %op3783 = ptrtoint ptr %gep3785 to i64
  store i64 %op3783, ptr %slot486, align 8
  %v3786 = load i64, ptr %slot486, align 8
  %p3787 = inttoptr i64 %v3786 to ptr
  store i64 0, ptr %p3787, align 8, !alias.scope !3, !noalias !4
  %v3788 = load i64, ptr %slot467, align 8
  %p3790 = inttoptr i64 %v3788 to ptr
  %gep3791 = getelementptr i8, ptr %p3790, i64 16
  %op3789 = ptrtoint ptr %gep3791 to i64
  store i64 %op3789, ptr %slot487, align 8
  %v3792 = load i64, ptr %slot487, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  store i64 0, ptr %p3793, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone598
bb_rcslotdone598:
  br label %bb_rcprepared556
bb_rcprepared556:
  %v3794 = load i64, ptr %slot9, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  %ld3796 = load i32, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3796, ptr %slot488, align 8
  %v3797 = load i32, ptr %slot488, align 8
  %cv3798 = zext i32 %v3797 to i64
  %cond3799 = icmp ne i64 %cv3798, 0
  br i1 %cond3799, label %bb_rcslotdrop625, label %bb_rcslotdone625
bb_rcslotdrop625:
  %v3800 = load i64, ptr %slot9, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  store i32 0, ptr %p3801, align 4, !alias.scope !3, !noalias !4
  %v3802 = load i64, ptr %slot39, align 8
  store i64 %v3802, ptr %slot489, align 8
  %v3803 = load i64, ptr %slot10, align 8
  %p3804 = inttoptr i64 %v3803 to ptr
  %ld3805 = load i32, ptr %p3804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3805, ptr %slot490, align 8
  %v3806 = load i32, ptr %slot490, align 8
  %op3807 = and i32 %v3806, 28
  store i32 %op3807, ptr %slot491, align 8
  %v3808 = load i32, ptr %slot491, align 8
  %cv3809 = zext i32 %v3808 to i64
  %cond3810 = icmp ne i64 %cv3809, 0
  br i1 %cond3810, label %bb_rcslotrole625, label %bb_rcslotowner625
bb_rcslotrole625:
  %v3811 = load i64, ptr %slot65, align 8
  store i64 %v3811, ptr %slot492, align 8
  %v3812 = load i64, ptr %slot492, align 8
  %v3813 = load i64, ptr %slot489, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3812, i64 %v3813) nomerge, !dbg !138
  br label %bb_rcslotdone625
bb_rcslotowner625:
  %v3814 = load i64, ptr %slot489, align 8
  %p3816 = inttoptr i64 %v3814 to ptr
  %gep3817 = getelementptr i8, ptr %p3816, i64 8
  %op3815 = ptrtoint ptr %gep3817 to i64
  store i64 %op3815, ptr %slot493, align 8
  %v3818 = load i64, ptr %slot65, align 8
  store i64 %v3818, ptr %slot494, align 8
  %v3819 = load i64, ptr %slot493, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i64, ptr %p3820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3821, ptr %slot495, align 8
  %v3822 = load i64, ptr %slot495, align 8
  %cmp3823 = icmp ne i64 %v3822, 0
  %cv3824 = zext i1 %cmp3823 to i32
  store i32 %cv3824, ptr %slot496, align 8
  %v3825 = load i32, ptr %slot496, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcgnn643, label %bb_rcgdone643
bb_rcgnn643:
  %v3828 = load i64, ptr %slot495, align 8
  %op3829 = sub i64 %v3828, 16
  store i64 %op3829, ptr %slot497, align 8
  %v3830 = load i64, ptr %slot495, align 8
  %p3831 = inttoptr i64 %v3830 to ptr
  %rgep3832 = getelementptr i8, ptr %p3831, i64 -16
  %ld3833 = load i64, ptr %rgep3832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3833, ptr %slot498, align 8
  %v3834 = load i64, ptr %slot498, align 8
  %op3835 = and i64 %v3834, 4611686018427387906
  store i64 %op3835, ptr %slot499, align 8
  %v3836 = load i64, ptr %slot499, align 8
  %cmp3837 = icmp ne i64 %v3836, 0
  %cv3838 = zext i1 %cmp3837 to i32
  store i32 %cv3838, ptr %slot500, align 8
  %v3839 = load i32, ptr %slot500, align 8
  %cv3840 = zext i32 %v3839 to i64
  %cond3841 = icmp ne i64 %cv3840, 0
  br i1 %cond3841, label %bb_rcgclear643, label %bb_rcgcounted643
bb_rcgcounted643:
  %v3842 = load i64, ptr %slot495, align 8
  %op3843 = sub i64 %v3842, 32
  store i64 %op3843, ptr %slot501, align 8
  %v3844 = load i64, ptr %slot495, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  %rgep3846 = getelementptr i8, ptr %p3845, i64 -32
  %ld3847 = load i64, ptr %rgep3846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3847, ptr %slot502, align 8
  %v3848 = load i64, ptr %slot502, align 8
  %op3849 = sub i64 %v3848, 1
  store i64 %op3849, ptr %slot503, align 8
  %v3850 = load i64, ptr %slot503, align 8
  %cmp3851 = icmp eq i64 %v3850, 0
  %cv3852 = zext i1 %cmp3851 to i32
  store i32 %cv3852, ptr %slot504, align 8
  %v3853 = load i32, ptr %slot504, align 8
  %cv3854 = zext i32 %v3853 to i64
  %cond3855 = icmp ne i64 %cv3854, 0
  br i1 %cond3855, label %bb_rcglast643, label %bb_rcgdec643
bb_rcglast643:
  %v3856 = load i64, ptr %slot495, align 8
  %op3857 = sub i64 %v3856, 24
  store i64 %op3857, ptr %slot505, align 8
  %v3858 = load i64, ptr %slot495, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %rgep3860 = getelementptr i8, ptr %p3859, i64 -24
  %ld3861 = load i64, ptr %rgep3860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3861, ptr %slot506, align 8
  %v3862 = load i64, ptr %slot506, align 8
  %cmp3863 = icmp ne i64 %v3862, 0
  %cv3864 = zext i1 %cmp3863 to i32
  store i32 %cv3864, ptr %slot507, align 8
  %v3865 = load i32, ptr %slot507, align 8
  %cv3866 = zext i32 %v3865 to i64
  %cond3867 = icmp ne i64 %cv3866, 0
  br i1 %cond3867, label %bb_rcgdec643, label %bb_rcgslow643
bb_rcgslow643:
  %v3868 = load i64, ptr %slot494, align 8
  %v3869 = load i64, ptr %slot493, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3868, i64 %v3869) nomerge, !dbg !138
  br label %bb_rcgdone643
bb_rcgdec643:
  %v3870 = load i64, ptr %slot503, align 8
  %v3871 = load i64, ptr %slot495, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %rgep3873 = getelementptr i8, ptr %p3872, i64 -32
  store i64 %v3870, ptr %rgep3873, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear643
bb_rcgclear643:
  %v3874 = load i64, ptr %slot493, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  store i64 0, ptr %p3875, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone643
bb_rcgdone643:
  %v3876 = load i64, ptr %slot489, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  store i64 0, ptr %p3877, align 8, !alias.scope !3, !noalias !4
  %v3878 = load i64, ptr %slot489, align 8
  %p3880 = inttoptr i64 %v3878 to ptr
  %gep3881 = getelementptr i8, ptr %p3880, i64 8
  %op3879 = ptrtoint ptr %gep3881 to i64
  store i64 %op3879, ptr %slot508, align 8
  %v3882 = load i64, ptr %slot508, align 8
  %p3883 = inttoptr i64 %v3882 to ptr
  store i64 0, ptr %p3883, align 8, !alias.scope !3, !noalias !4
  %v3884 = load i64, ptr %slot489, align 8
  %p3886 = inttoptr i64 %v3884 to ptr
  %gep3887 = getelementptr i8, ptr %p3886, i64 16
  %op3885 = ptrtoint ptr %gep3887 to i64
  store i64 %op3885, ptr %slot509, align 8
  %v3888 = load i64, ptr %slot509, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  store i64 0, ptr %p3889, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone625
bb_rcslotdone625:
  %v3890 = load i64, ptr %slot39, align 8
  store i64 %v3890, ptr %slot510, align 8
  %v3891 = load i64, ptr %slot32, align 8
  store i64 %v3891, ptr %slot511, align 8
  %v3892 = load i64, ptr %slot511, align 8
  %v3893 = load i64, ptr %slot510, align 8
  %p3894 = inttoptr i64 %v3892 to ptr
  %p3895 = inttoptr i64 %v3893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3895, ptr %p3894, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3896 = load i64, ptr %slot27, align 8
  %p3897 = inttoptr i64 %v3896 to ptr
  store i32 0, ptr %p3897, align 4, !alias.scope !3, !noalias !4
  %v3898 = load i64, ptr %slot10, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  store i32 2, ptr %p3899, align 4, !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot28, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  %ld3902 = load i32, ptr %p3901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3902, ptr %slot512, align 8
  %v3903 = load i32, ptr %slot512, align 8
  %v3904 = load i64, ptr %slot10, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  store i32 %v3903, ptr %p3905, align 4, !alias.scope !3, !noalias !4
  %v3906 = load i64, ptr %slot9, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  store i32 1, ptr %p3907, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept554
bb_rcselfkept554:
  %v3908 = load i64, ptr %slot35, align 8
  %v3909 = load i64, ptr %slot58, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  store i64 %v3908, ptr %p3910, align 8, !alias.scope !3, !noalias !4
  %v3911 = load i64, ptr %slot39, align 8
  %v3912 = load i64, ptr %slot59, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i64 %v3911, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  %v3914 = load i64, ptr %slot59, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  %ld3916 = load i64, ptr %p3915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3916, ptr %slot513, align 8
  %v3917 = load i64, ptr %slot513, align 8
  %op3918 = add i64 %v3917, 0
  store i64 %op3918, ptr %slot514, align 8
  %v3919 = load i64, ptr %slot514, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %ld3921 = load i64, ptr %p3920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3921, ptr %slot515, align 8
  %v3922 = load i64, ptr %slot515, align 8
  %v3923 = load i64, ptr %slot59, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 %v3922, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  %v3925 = load i64, ptr %slot25, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %ld3927 = load i32, ptr %p3926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3927, ptr %slot516, align 8
  %v3928 = load i32, ptr %slot516, align 8
  %cv3929 = zext i32 %v3928 to i64
  %cond3930 = icmp ne i64 %cv3929, 0
  br i1 %cond3930, label %bb_rcslotdrop661, label %bb_rcslotdone661
bb_rcslotdrop661:
  %v3931 = load i64, ptr %slot25, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  store i32 0, ptr %p3932, align 4, !alias.scope !3, !noalias !4
  %v3933 = load i64, ptr %slot30, align 8
  store i64 %v3933, ptr %slot517, align 8
  %v3934 = load i64, ptr %slot26, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  %ld3936 = load i32, ptr %p3935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3936, ptr %slot518, align 8
  %v3937 = load i32, ptr %slot518, align 8
  %op3938 = and i32 %v3937, 28
  store i32 %op3938, ptr %slot519, align 8
  %v3939 = load i32, ptr %slot519, align 8
  %cv3940 = zext i32 %v3939 to i64
  %cond3941 = icmp ne i64 %cv3940, 0
  br i1 %cond3941, label %bb_rcslotrole661, label %bb_rcslotowner661
bb_rcslotrole661:
  %v3942 = load i64, ptr %slot65, align 8
  store i64 %v3942, ptr %slot520, align 8
  %v3943 = load i64, ptr %slot520, align 8
  %v3944 = load i64, ptr %slot517, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3943, i64 %v3944) nomerge, !dbg !140
  br label %bb_rcslotdone661
bb_rcslotowner661:
  %v3945 = load i64, ptr %slot65, align 8
  store i64 %v3945, ptr %slot521, align 8
  %v3946 = load i64, ptr %slot521, align 8
  %v3947 = load i64, ptr %slot517, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3946, i64 %v3947) nomerge, !dbg !140
  br label %bb_rcslotdone661
bb_rcslotdone661:
  %v3948 = load i64, ptr %slot58, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  %ld3950 = load i64, ptr %p3949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3950, ptr %slot522, align 8
  %v3951 = load i64, ptr %slot59, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  %ld3953 = load i64, ptr %p3952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3953, ptr %slot523, align 8
  %v3954 = load i64, ptr %slot1, align 8
  %v3955 = load i64, ptr %slot522, align 8
  %v3956 = load i64, ptr %slot523, align 8
  %call3957 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v3954, i64 %v3955, i64 %v3956) nomerge, !dbg !142
  store i64 %call3957, ptr %slot524, align 8
  %v3958 = load i64, ptr %slot524, align 8
  %v3959 = load i64, ptr %slot58, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i64 %v3958, ptr %p3960, align 8, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot23, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  %ld3963 = load i32, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3963, ptr %slot525, align 8
  %v3964 = load i32, ptr %slot525, align 8
  %cv3965 = zext i32 %v3964 to i64
  %cond3966 = icmp ne i64 %cv3965, 0
  br i1 %cond3966, label %bb_rcslotdrop673, label %bb_rcslotdone673
bb_rcslotdrop673:
  %v3967 = load i64, ptr %slot23, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  store i32 0, ptr %p3968, align 4, !alias.scope !3, !noalias !4
  %v3969 = load i64, ptr %slot29, align 8
  store i64 %v3969, ptr %slot526, align 8
  %v3970 = load i64, ptr %slot24, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i32, ptr %p3971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3972, ptr %slot527, align 8
  %v3973 = load i32, ptr %slot527, align 8
  %op3974 = and i32 %v3973, 28
  store i32 %op3974, ptr %slot528, align 8
  %v3975 = load i32, ptr %slot528, align 8
  %cv3976 = zext i32 %v3975 to i64
  %cond3977 = icmp ne i64 %cv3976, 0
  br i1 %cond3977, label %bb_rcslotrole673, label %bb_rcslotowner673
bb_rcslotrole673:
  %v3978 = load i64, ptr %slot65, align 8
  store i64 %v3978, ptr %slot529, align 8
  %v3979 = load i64, ptr %slot529, align 8
  %v3980 = load i64, ptr %slot526, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v3979, i64 %v3980) nomerge, !dbg !142
  br label %bb_rcslotdone673
bb_rcslotowner673:
  %v3981 = load i64, ptr %slot65, align 8
  store i64 %v3981, ptr %slot530, align 8
  %v3982 = load i64, ptr %slot530, align 8
  %v3983 = load i64, ptr %slot526, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v3982, i64 %v3983) nomerge, !dbg !142
  br label %bb_rcslotdone673
bb_rcslotdone673:
  %v3984 = load i64, ptr %slot35, align 8
  %v3985 = load i64, ptr %slot58, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  store i64 %v3984, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  %v3987 = load i64, ptr %slot39, align 8
  %v3988 = load i64, ptr %slot59, align 8
  %p3989 = inttoptr i64 %v3988 to ptr
  store i64 %v3987, ptr %p3989, align 8, !alias.scope !3, !noalias !4
  %v3990 = load i64, ptr %slot59, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  %ld3992 = load i64, ptr %p3991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3992, ptr %slot531, align 8
  %v3993 = load i64, ptr %slot531, align 8
  %op3994 = add i64 %v3993, 8
  store i64 %op3994, ptr %slot532, align 8
  %v3995 = load i64, ptr %slot532, align 8
  %v3996 = load i64, ptr %slot59, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  store i64 %v3995, ptr %p3997, align 8, !alias.scope !3, !noalias !4
  %v3998 = load i64, ptr %slot59, align 8
  %p3999 = inttoptr i64 %v3998 to ptr
  %ld4000 = load i64, ptr %p3999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4000, ptr %slot533, align 8
  %v4001 = load i64, ptr %slot32, align 8
  store i64 %v4001, ptr %slot534, align 8
  %v4002 = load i64, ptr %slot65, align 8
  %v4003 = load i64, ptr %slot534, align 8
  %v4004 = load i64, ptr %slot533, align 8
  %call4005 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v4002, i64 %v4003, i64 %v4004) nomerge, !dbg !144
  store i32 %call4005, ptr %slot535, align 8
  %v4006 = load i32, ptr %slot535, align 8
  %cv4007 = zext i32 %v4006 to i64
  %cond4008 = icmp ne i64 %cv4007, 0
  br i1 %cond4008, label %bb_rcsuccess685, label %bb_rcfailure685
bb_rcfailure685:
  %v4009 = load i64, ptr %slot65, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %call4011 = call i32 @myl_rc_take_failure(ptr %p4010) nomerge, !dbg !144
  store i32 %call4011, ptr %slot536, align 8
  %v4012 = load i64, ptr %slot1, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  %v4014 = load i32, ptr %slot536, align 8
  %call4015 = call i32 @myl_qbe_rc_status(ptr %p4013, i32 %v4014) nomerge, !dbg !144
  store i32 %call4015, ptr %slot537, align 8
  br label %bb_failure
bb_rcsuccess685:
  %v4016 = load i64, ptr %slot28, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  store i32 2, ptr %p4017, align 4, !alias.scope !3, !noalias !4
  %v4018 = load i64, ptr %slot28, align 8
  %p4019 = inttoptr i64 %v4018 to ptr
  store i32 16, ptr %p4019, align 4, !alias.scope !3, !noalias !4
  %v4020 = load i64, ptr %slot27, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  store i32 1, ptr %p4021, align 4, !alias.scope !3, !noalias !4
  %v4022 = load i64, ptr %slot25, align 8
  %p4023 = inttoptr i64 %v4022 to ptr
  %ld4024 = load i32, ptr %p4023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4024, ptr %slot538, align 8
  %v4025 = load i32, ptr %slot538, align 8
  %cv4026 = zext i32 %v4025 to i64
  %cond4027 = icmp ne i64 %cv4026, 0
  br i1 %cond4027, label %bb_rcslotdrop693, label %bb_rcslotdone693
bb_rcslotdrop693:
  %v4028 = load i64, ptr %slot25, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  store i32 0, ptr %p4029, align 4, !alias.scope !3, !noalias !4
  %v4030 = load i64, ptr %slot30, align 8
  store i64 %v4030, ptr %slot539, align 8
  %v4031 = load i64, ptr %slot26, align 8
  %p4032 = inttoptr i64 %v4031 to ptr
  %ld4033 = load i32, ptr %p4032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4033, ptr %slot540, align 8
  %v4034 = load i32, ptr %slot540, align 8
  %op4035 = and i32 %v4034, 28
  store i32 %op4035, ptr %slot541, align 8
  %v4036 = load i32, ptr %slot541, align 8
  %cv4037 = zext i32 %v4036 to i64
  %cond4038 = icmp ne i64 %cv4037, 0
  br i1 %cond4038, label %bb_rcslotrole693, label %bb_rcslotowner693
bb_rcslotrole693:
  %v4039 = load i64, ptr %slot65, align 8
  store i64 %v4039, ptr %slot542, align 8
  %v4040 = load i64, ptr %slot542, align 8
  %v4041 = load i64, ptr %slot539, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4040, i64 %v4041) nomerge, !dbg !144
  br label %bb_rcslotdone693
bb_rcslotowner693:
  %v4042 = load i64, ptr %slot65, align 8
  store i64 %v4042, ptr %slot543, align 8
  %v4043 = load i64, ptr %slot543, align 8
  %v4044 = load i64, ptr %slot539, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4043, i64 %v4044) nomerge, !dbg !144
  br label %bb_rcslotdone693
bb_rcslotdone693:
  %v4045 = load i64, ptr %slot30, align 8
  store i64 %v4045, ptr %slot544, align 8
  %v4046 = load i64, ptr %slot32, align 8
  store i64 %v4046, ptr %slot545, align 8
  %v4047 = load i64, ptr %slot545, align 8
  %v4048 = load i64, ptr %slot544, align 8
  %p4049 = inttoptr i64 %v4047 to ptr
  %p4050 = inttoptr i64 %v4048 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4050, ptr %p4049, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4051 = load i64, ptr %slot26, align 8
  %p4052 = inttoptr i64 %v4051 to ptr
  store i32 2, ptr %p4052, align 4, !alias.scope !3, !noalias !4
  %v4053 = load i64, ptr %slot28, align 8
  %p4054 = inttoptr i64 %v4053 to ptr
  %ld4055 = load i32, ptr %p4054, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4055, ptr %slot546, align 8
  %v4056 = load i32, ptr %slot546, align 8
  %v4057 = load i64, ptr %slot26, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  store i32 %v4056, ptr %p4058, align 4, !alias.scope !3, !noalias !4
  %v4059 = load i64, ptr %slot27, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  store i32 0, ptr %p4060, align 4, !alias.scope !3, !noalias !4
  %v4061 = load i64, ptr %slot25, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  store i32 1, ptr %p4062, align 4, !alias.scope !3, !noalias !4
  %v4063 = load i64, ptr %slot544, align 8
  %v4064 = load i64, ptr %slot59, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  store i64 %v4063, ptr %p4065, align 8, !alias.scope !3, !noalias !4
  %v4066 = load i64, ptr %slot58, align 8
  %p4067 = inttoptr i64 %v4066 to ptr
  %ld4068 = load i64, ptr %p4067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4068, ptr %slot547, align 8
  %v4069 = load i64, ptr %slot59, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %ld4071 = load i64, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4071, ptr %slot548, align 8
  %v4072 = load i64, ptr %slot1, align 8
  %v4073 = load i64, ptr %slot547, align 8
  %v4074 = load i64, ptr %slot548, align 8
  %call4075 = call i64 @myl_f_f0393a69ddd4c3d9aed35cdcfaedcd9f0376ae1fd953f70833a16f0c06c4cd97(i64 %v4072, i64 %v4073, i64 %v4074) nomerge, !dbg !146
  store i64 %call4075, ptr %slot549, align 8
  %v4076 = load i64, ptr %slot549, align 8
  %v4077 = load i64, ptr %slot58, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  store i64 %v4076, ptr %p4078, align 8, !alias.scope !3, !noalias !4
  %v4079 = load i64, ptr %slot23, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  %ld4081 = load i32, ptr %p4080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4081, ptr %slot550, align 8
  %v4082 = load i32, ptr %slot550, align 8
  %cv4083 = zext i32 %v4082 to i64
  %cond4084 = icmp ne i64 %cv4083, 0
  br i1 %cond4084, label %bb_rcslotdrop713, label %bb_rcslotdone713
bb_rcslotdrop713:
  %v4085 = load i64, ptr %slot23, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  store i32 0, ptr %p4086, align 4, !alias.scope !3, !noalias !4
  %v4087 = load i64, ptr %slot29, align 8
  store i64 %v4087, ptr %slot551, align 8
  %v4088 = load i64, ptr %slot24, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %ld4090 = load i32, ptr %p4089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4090, ptr %slot552, align 8
  %v4091 = load i32, ptr %slot552, align 8
  %op4092 = and i32 %v4091, 28
  store i32 %op4092, ptr %slot553, align 8
  %v4093 = load i32, ptr %slot553, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcslotrole713, label %bb_rcslotowner713
bb_rcslotrole713:
  %v4096 = load i64, ptr %slot65, align 8
  store i64 %v4096, ptr %slot554, align 8
  %v4097 = load i64, ptr %slot554, align 8
  %v4098 = load i64, ptr %slot551, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v4097, i64 %v4098) nomerge, !dbg !146
  br label %bb_rcslotdone713
bb_rcslotowner713:
  %v4099 = load i64, ptr %slot65, align 8
  store i64 %v4099, ptr %slot555, align 8
  %v4100 = load i64, ptr %slot555, align 8
  %v4101 = load i64, ptr %slot551, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v4100, i64 %v4101) nomerge, !dbg !146
  br label %bb_rcslotdone713
bb_rcslotdone713:
  %v4102 = load i64, ptr %slot25, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %ld4104 = load i32, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4104, ptr %slot556, align 8
  %v4105 = load i32, ptr %slot556, align 8
  %cv4106 = zext i32 %v4105 to i64
  %cond4107 = icmp ne i64 %cv4106, 0
  br i1 %cond4107, label %bb_rcslotdrop722, label %bb_rcslotdone722
bb_rcslotdrop722:
  %v4108 = load i64, ptr %slot25, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  store i32 0, ptr %p4109, align 4, !alias.scope !3, !noalias !4
  %v4110 = load i64, ptr %slot30, align 8
  store i64 %v4110, ptr %slot557, align 8
  %v4111 = load i64, ptr %slot26, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  %ld4113 = load i32, ptr %p4112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4113, ptr %slot558, align 8
  %v4114 = load i32, ptr %slot558, align 8
  %op4115 = and i32 %v4114, 28
  store i32 %op4115, ptr %slot559, align 8
  %v4116 = load i32, ptr %slot559, align 8
  %cv4117 = zext i32 %v4116 to i64
  %cond4118 = icmp ne i64 %cv4117, 0
  br i1 %cond4118, label %bb_rcslotrole722, label %bb_rcslotowner722
bb_rcslotrole722:
  %v4119 = load i64, ptr %slot65, align 8
  store i64 %v4119, ptr %slot560, align 8
  %v4120 = load i64, ptr %slot560, align 8
  %v4121 = load i64, ptr %slot557, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4120, i64 %v4121) nomerge, !dbg !146
  br label %bb_rcslotdone722
bb_rcslotowner722:
  %v4122 = load i64, ptr %slot65, align 8
  store i64 %v4122, ptr %slot561, align 8
  %v4123 = load i64, ptr %slot561, align 8
  %v4124 = load i64, ptr %slot557, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4123, i64 %v4124) nomerge, !dbg !146
  br label %bb_rcslotdone722
bb_rcslotdone722:
  %v4125 = load i64, ptr %slot9, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %ld4127 = load i32, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4127, ptr %slot562, align 8
  %v4128 = load i32, ptr %slot562, align 8
  %cv4129 = zext i32 %v4128 to i64
  %cond4130 = icmp ne i64 %cv4129, 0
  br i1 %cond4130, label %bb_rcslotdrop731, label %bb_rcslotdone731
bb_rcslotdrop731:
  %v4131 = load i64, ptr %slot9, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  store i32 0, ptr %p4132, align 4, !alias.scope !3, !noalias !4
  %v4133 = load i64, ptr %slot39, align 8
  store i64 %v4133, ptr %slot563, align 8
  %v4134 = load i64, ptr %slot10, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i32, ptr %p4135, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4136, ptr %slot564, align 8
  %v4137 = load i32, ptr %slot564, align 8
  %op4138 = and i32 %v4137, 28
  store i32 %op4138, ptr %slot565, align 8
  %v4139 = load i32, ptr %slot565, align 8
  %cv4140 = zext i32 %v4139 to i64
  %cond4141 = icmp ne i64 %cv4140, 0
  br i1 %cond4141, label %bb_rcslotrole731, label %bb_rcslotowner731
bb_rcslotrole731:
  %v4142 = load i64, ptr %slot65, align 8
  store i64 %v4142, ptr %slot566, align 8
  %v4143 = load i64, ptr %slot566, align 8
  %v4144 = load i64, ptr %slot563, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4143, i64 %v4144) nomerge, !dbg !148
  br label %bb_rcslotdone731
bb_rcslotowner731:
  %v4145 = load i64, ptr %slot563, align 8
  %p4147 = inttoptr i64 %v4145 to ptr
  %gep4148 = getelementptr i8, ptr %p4147, i64 8
  %op4146 = ptrtoint ptr %gep4148 to i64
  store i64 %op4146, ptr %slot567, align 8
  %v4149 = load i64, ptr %slot65, align 8
  store i64 %v4149, ptr %slot568, align 8
  %v4150 = load i64, ptr %slot567, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  %ld4152 = load i64, ptr %p4151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4152, ptr %slot569, align 8
  %v4153 = load i64, ptr %slot569, align 8
  %cmp4154 = icmp ne i64 %v4153, 0
  %cv4155 = zext i1 %cmp4154 to i32
  store i32 %cv4155, ptr %slot570, align 8
  %v4156 = load i32, ptr %slot570, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcgnn749, label %bb_rcgdone749
bb_rcgnn749:
  %v4159 = load i64, ptr %slot569, align 8
  %op4160 = sub i64 %v4159, 16
  store i64 %op4160, ptr %slot571, align 8
  %v4161 = load i64, ptr %slot569, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %rgep4163 = getelementptr i8, ptr %p4162, i64 -16
  %ld4164 = load i64, ptr %rgep4163, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4164, ptr %slot572, align 8
  %v4165 = load i64, ptr %slot572, align 8
  %op4166 = and i64 %v4165, 4611686018427387906
  store i64 %op4166, ptr %slot573, align 8
  %v4167 = load i64, ptr %slot573, align 8
  %cmp4168 = icmp ne i64 %v4167, 0
  %cv4169 = zext i1 %cmp4168 to i32
  store i32 %cv4169, ptr %slot574, align 8
  %v4170 = load i32, ptr %slot574, align 8
  %cv4171 = zext i32 %v4170 to i64
  %cond4172 = icmp ne i64 %cv4171, 0
  br i1 %cond4172, label %bb_rcgclear749, label %bb_rcgcounted749
bb_rcgcounted749:
  %v4173 = load i64, ptr %slot569, align 8
  %op4174 = sub i64 %v4173, 32
  store i64 %op4174, ptr %slot575, align 8
  %v4175 = load i64, ptr %slot569, align 8
  %p4176 = inttoptr i64 %v4175 to ptr
  %rgep4177 = getelementptr i8, ptr %p4176, i64 -32
  %ld4178 = load i64, ptr %rgep4177, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4178, ptr %slot576, align 8
  %v4179 = load i64, ptr %slot576, align 8
  %op4180 = sub i64 %v4179, 1
  store i64 %op4180, ptr %slot577, align 8
  %v4181 = load i64, ptr %slot577, align 8
  %cmp4182 = icmp eq i64 %v4181, 0
  %cv4183 = zext i1 %cmp4182 to i32
  store i32 %cv4183, ptr %slot578, align 8
  %v4184 = load i32, ptr %slot578, align 8
  %cv4185 = zext i32 %v4184 to i64
  %cond4186 = icmp ne i64 %cv4185, 0
  br i1 %cond4186, label %bb_rcglast749, label %bb_rcgdec749
bb_rcglast749:
  %v4187 = load i64, ptr %slot569, align 8
  %op4188 = sub i64 %v4187, 24
  store i64 %op4188, ptr %slot579, align 8
  %v4189 = load i64, ptr %slot569, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  %rgep4191 = getelementptr i8, ptr %p4190, i64 -24
  %ld4192 = load i64, ptr %rgep4191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4192, ptr %slot580, align 8
  %v4193 = load i64, ptr %slot580, align 8
  %cmp4194 = icmp ne i64 %v4193, 0
  %cv4195 = zext i1 %cmp4194 to i32
  store i32 %cv4195, ptr %slot581, align 8
  %v4196 = load i32, ptr %slot581, align 8
  %cv4197 = zext i32 %v4196 to i64
  %cond4198 = icmp ne i64 %cv4197, 0
  br i1 %cond4198, label %bb_rcgdec749, label %bb_rcgslow749
bb_rcgslow749:
  %v4199 = load i64, ptr %slot568, align 8
  %v4200 = load i64, ptr %slot567, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4199, i64 %v4200) nomerge, !dbg !148
  br label %bb_rcgdone749
bb_rcgdec749:
  %v4201 = load i64, ptr %slot577, align 8
  %v4202 = load i64, ptr %slot569, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  %rgep4204 = getelementptr i8, ptr %p4203, i64 -32
  store i64 %v4201, ptr %rgep4204, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear749
bb_rcgclear749:
  %v4205 = load i64, ptr %slot567, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  store i64 0, ptr %p4206, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone749
bb_rcgdone749:
  %v4207 = load i64, ptr %slot563, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  store i64 0, ptr %p4208, align 8, !alias.scope !3, !noalias !4
  %v4209 = load i64, ptr %slot563, align 8
  %p4211 = inttoptr i64 %v4209 to ptr
  %gep4212 = getelementptr i8, ptr %p4211, i64 8
  %op4210 = ptrtoint ptr %gep4212 to i64
  store i64 %op4210, ptr %slot582, align 8
  %v4213 = load i64, ptr %slot582, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  store i64 0, ptr %p4214, align 8, !alias.scope !3, !noalias !4
  %v4215 = load i64, ptr %slot563, align 8
  %p4217 = inttoptr i64 %v4215 to ptr
  %gep4218 = getelementptr i8, ptr %p4217, i64 16
  %op4216 = ptrtoint ptr %gep4218 to i64
  store i64 %op4216, ptr %slot583, align 8
  %v4219 = load i64, ptr %slot583, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  store i64 0, ptr %p4220, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone731
bb_rcslotdone731:
  br label %bb_i198
bb_i51:
  %v4221 = load i64, ptr %slot40, align 8
  %v4222 = load i64, ptr %slot58, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  store i64 %v4221, ptr %p4223, align 8, !alias.scope !3, !noalias !4
  %v4224 = load i64, ptr %slot11, align 8
  %p4225 = inttoptr i64 %v4224 to ptr
  %ld4226 = load i32, ptr %p4225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4226, ptr %slot584, align 8
  %v4227 = load i64, ptr %slot12, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  %ld4229 = load i32, ptr %p4228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4229, ptr %slot585, align 8
  %v4230 = load i32, ptr %slot585, align 8
  %op4231 = and i32 %v4230, 24
  store i32 %op4231, ptr %slot585, align 8
  %v4232 = load i32, ptr %slot585, align 8
  %cmp4233 = icmp eq i32 %v4232, 0
  %cv4234 = zext i1 %cmp4233 to i32
  store i32 %cv4234, ptr %slot586, align 8
  %v4235 = load i32, ptr %slot584, align 8
  %v4236 = load i32, ptr %slot586, align 8
  %op4237 = and i32 %v4235, %v4236
  store i32 %op4237, ptr %slot587, align 8
  %v4238 = load i32, ptr %slot587, align 8
  %cv4239 = zext i32 %v4238 to i64
  %cond4240 = icmp ne i64 %cv4239, 0
  br i1 %cond4240, label %bb_rcselfkept761, label %bb_rcselfstore761
bb_rcselfstore761:
  %v4241 = load i64, ptr %slot58, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %ld4243 = load i64, ptr %p4242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4243, ptr %slot588, align 8
  %v4244 = load i64, ptr %slot23, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %ld4246 = load i32, ptr %p4245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4246, ptr %slot589, align 8
  %v4247 = load i64, ptr %slot24, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %ld4249 = load i32, ptr %p4248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4249, ptr %slot590, align 8
  %v4250 = load i32, ptr %slot590, align 8
  %op4251 = and i32 %v4250, 24
  store i32 %op4251, ptr %slot590, align 8
  %v4252 = load i32, ptr %slot590, align 8
  %cmp4253 = icmp eq i32 %v4252, 0
  %cv4254 = zext i1 %cmp4253 to i32
  store i32 %cv4254, ptr %slot591, align 8
  %v4255 = load i32, ptr %slot589, align 8
  %v4256 = load i32, ptr %slot591, align 8
  %op4257 = and i32 %v4255, %v4256
  store i32 %op4257, ptr %slot592, align 8
  %v4258 = load i32, ptr %slot592, align 8
  %cv4259 = zext i32 %v4258 to i64
  %cond4260 = icmp ne i64 %cv4259, 0
  br i1 %cond4260, label %bb_rctake763, label %bb_rccopy763
bb_rctake763:
  %v4261 = load i64, ptr %slot32, align 8
  store i64 %v4261, ptr %slot593, align 8
  %v4262 = load i64, ptr %slot66, align 8
  store i64 %v4262, ptr %slot594, align 8
  %v4263 = load i64, ptr %slot588, align 8
  %v4264 = load i64, ptr %slot593, align 8
  %op4265 = sub i64 %v4263, %v4264
  store i64 %op4265, ptr %slot595, align 8
  %v4266 = load i64, ptr %slot593, align 8
  %v4267 = load i64, ptr %slot588, align 8
  %op4268 = sub i64 %v4266, %v4267
  store i64 %op4268, ptr %slot596, align 8
  %v4269 = load i64, ptr %slot595, align 8
  %cmp4270 = icmp ult i64 %v4269, 16
  %cv4271 = zext i1 %cmp4270 to i32
  store i32 %cv4271, ptr %slot597, align 8
  %v4272 = load i64, ptr %slot596, align 8
  %cmp4273 = icmp ult i64 %v4272, 16
  %cv4274 = zext i1 %cmp4273 to i32
  store i32 %cv4274, ptr %slot598, align 8
  %v4275 = load i32, ptr %slot597, align 8
  %v4276 = load i32, ptr %slot598, align 8
  %op4277 = or i32 %v4275, %v4276
  store i32 %op4277, ptr %slot599, align 8
  %v4278 = load i32, ptr %slot599, align 8
  %cv4279 = zext i32 %v4278 to i64
  %cond4280 = icmp ne i64 %cv4279, 0
  br i1 %cond4280, label %bb_rcmoveslow772, label %bb_rcmovecheck772
bb_rcmovecheck772:
  %v4281 = load i64, ptr %slot588, align 8
  %op4282 = add i64 %v4281, 8
  store i64 %op4282, ptr %slot600, align 8
  %v4283 = load i64, ptr %slot600, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  %ld4285 = load i64, ptr %p4284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4285, ptr %slot601, align 8
  %v4286 = load i64, ptr %slot601, align 8
  %cmp4287 = icmp ne i64 %v4286, 0
  %cv4288 = zext i1 %cmp4287 to i32
  store i32 %cv4288, ptr %slot602, align 8
  %v4289 = load i32, ptr %slot602, align 8
  %cv4290 = zext i32 %v4289 to i64
  %cond4291 = icmp ne i64 %cv4290, 0
  br i1 %cond4291, label %bb_rcmoveheader780, label %bb_rcmovenext780
bb_rcmoveheader780:
  %v4292 = load i64, ptr %slot601, align 8
  %op4293 = sub i64 %v4292, 16
  store i64 %op4293, ptr %slot603, align 8
  %v4294 = load i64, ptr %slot601, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  %rgep4296 = getelementptr i8, ptr %p4295, i64 -16
  %ld4297 = load i64, ptr %rgep4296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4297, ptr %slot604, align 8
  %v4298 = load i64, ptr %slot604, align 8
  %op4299 = and i64 %v4298, 5764607523034234881
  store i64 %op4299, ptr %slot605, align 8
  %v4300 = load i64, ptr %slot605, align 8
  %cmp4301 = icmp ne i64 %v4300, 0
  %cv4302 = zext i1 %cmp4301 to i32
  store i32 %cv4302, ptr %slot606, align 8
  %v4303 = load i32, ptr %slot606, align 8
  %cv4304 = zext i32 %v4303 to i64
  %cond4305 = icmp ne i64 %cv4304, 0
  br i1 %cond4305, label %bb_rcmoveslow772, label %bb_rcmovenext780
bb_rcmovenext780:
  %v4306 = load i64, ptr %slot588, align 8
  %v4307 = load i64, ptr %slot593, align 8
  %p4308 = inttoptr i64 %v4306 to ptr
  %p4309 = inttoptr i64 %v4307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4309, ptr %p4308, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4310 = load i64, ptr %slot588, align 8
  %p4311 = inttoptr i64 %v4310 to ptr
  store i64 0, ptr %p4311, align 8, !alias.scope !3, !noalias !4
  %v4312 = load i64, ptr %slot588, align 8
  %op4313 = add i64 %v4312, 8
  store i64 %op4313, ptr %slot607, align 8
  %v4314 = load i64, ptr %slot607, align 8
  %p4315 = inttoptr i64 %v4314 to ptr
  store i64 0, ptr %p4315, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved772
bb_rcmoveslow772:
  %v4316 = load i64, ptr %slot65, align 8
  %v4317 = load i64, ptr %slot593, align 8
  %v4318 = load i64, ptr %slot588, align 8
  %v4319 = load i64, ptr %slot594, align 8
  %cv4320 = trunc i64 %v4319 to i32
  %call4321 = call i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64 %v4316, i64 %v4317, i64 %v4318, i32 %cv4320) nomerge, !dbg !150
  store i32 %call4321, ptr %slot608, align 8
  %v4322 = load i32, ptr %slot608, align 8
  %cv4323 = zext i32 %v4322 to i64
  %cond4324 = icmp ne i64 %cv4323, 0
  br i1 %cond4324, label %bb_rcsuccess788, label %bb_rcfailure788
bb_rcfailure788:
  %v4325 = load i64, ptr %slot65, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  %call4327 = call i32 @myl_rc_take_failure(ptr %p4326) nomerge, !dbg !150
  store i32 %call4327, ptr %slot609, align 8
  %v4328 = load i64, ptr %slot1, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %v4330 = load i32, ptr %slot609, align 8
  %call4331 = call i32 @myl_qbe_rc_status(ptr %p4329, i32 %v4330) nomerge, !dbg !150
  store i32 %call4331, ptr %slot610, align 8
  br label %bb_failure
bb_rcsuccess788:
  br label %bb_rcmoved772
bb_rcmoved772:
  %v4332 = load i64, ptr %slot23, align 8
  %p4333 = inttoptr i64 %v4332 to ptr
  store i32 0, ptr %p4333, align 4, !alias.scope !3, !noalias !4
  %v4334 = load i64, ptr %slot28, align 8
  %p4335 = inttoptr i64 %v4334 to ptr
  store i32 2, ptr %p4335, align 4, !alias.scope !3, !noalias !4
  %v4336 = load i64, ptr %slot27, align 8
  %p4337 = inttoptr i64 %v4336 to ptr
  store i32 1, ptr %p4337, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared763
bb_rccopy763:
  %v4338 = load i64, ptr %slot32, align 8
  store i64 %v4338, ptr %slot611, align 8
  %v4339 = load i64, ptr %slot66, align 8
  store i64 %v4339, ptr %slot612, align 8
  %v4340 = load i64, ptr %slot65, align 8
  %v4341 = load i64, ptr %slot611, align 8
  %v4342 = load i64, ptr %slot588, align 8
  %v4343 = load i64, ptr %slot612, align 8
  %cv4344 = trunc i64 %v4343 to i32
  %call4345 = call i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_retain(i64 %v4340, i64 %v4341, i64 %v4342, i32 %cv4344) nomerge, !dbg !150
  store i32 %call4345, ptr %slot613, align 8
  %v4346 = load i32, ptr %slot613, align 8
  %cv4347 = zext i32 %v4346 to i64
  %cond4348 = icmp ne i64 %cv4347, 0
  br i1 %cond4348, label %bb_rcsuccess797, label %bb_rcfailure797
bb_rcfailure797:
  %v4349 = load i64, ptr %slot65, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  %call4351 = call i32 @myl_rc_take_failure(ptr %p4350) nomerge, !dbg !150
  store i32 %call4351, ptr %slot614, align 8
  %v4352 = load i64, ptr %slot1, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  %v4354 = load i32, ptr %slot614, align 8
  %call4355 = call i32 @myl_qbe_rc_status(ptr %p4353, i32 %v4354) nomerge, !dbg !150
  store i32 %call4355, ptr %slot615, align 8
  br label %bb_failure
bb_rcsuccess797:
  %v4356 = load i64, ptr %slot28, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  store i32 2, ptr %p4357, align 4, !alias.scope !3, !noalias !4
  %v4358 = load i64, ptr %slot27, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  store i32 1, ptr %p4359, align 4, !alias.scope !3, !noalias !4
  %v4360 = load i64, ptr %slot23, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  %ld4362 = load i32, ptr %p4361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4362, ptr %slot616, align 8
  %v4363 = load i32, ptr %slot616, align 8
  %cv4364 = zext i32 %v4363 to i64
  %cond4365 = icmp ne i64 %cv4364, 0
  br i1 %cond4365, label %bb_rcslotdrop804, label %bb_rcslotdone804
bb_rcslotdrop804:
  %v4366 = load i64, ptr %slot23, align 8
  %p4367 = inttoptr i64 %v4366 to ptr
  store i32 0, ptr %p4367, align 4, !alias.scope !3, !noalias !4
  %v4368 = load i64, ptr %slot29, align 8
  store i64 %v4368, ptr %slot617, align 8
  %v4369 = load i64, ptr %slot24, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  %ld4371 = load i32, ptr %p4370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4371, ptr %slot618, align 8
  %v4372 = load i32, ptr %slot618, align 8
  %op4373 = and i32 %v4372, 28
  store i32 %op4373, ptr %slot619, align 8
  %v4374 = load i32, ptr %slot619, align 8
  %cv4375 = zext i32 %v4374 to i64
  %cond4376 = icmp ne i64 %cv4375, 0
  br i1 %cond4376, label %bb_rcslotrole804, label %bb_rcslotowner804
bb_rcslotrole804:
  %v4377 = load i64, ptr %slot65, align 8
  store i64 %v4377, ptr %slot620, align 8
  %v4378 = load i64, ptr %slot620, align 8
  %v4379 = load i64, ptr %slot617, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v4378, i64 %v4379) nomerge, !dbg !150
  br label %bb_rcslotdone804
bb_rcslotowner804:
  %v4380 = load i64, ptr %slot617, align 8
  %p4382 = inttoptr i64 %v4380 to ptr
  %gep4383 = getelementptr i8, ptr %p4382, i64 8
  %op4381 = ptrtoint ptr %gep4383 to i64
  store i64 %op4381, ptr %slot621, align 8
  %v4384 = load i64, ptr %slot65, align 8
  store i64 %v4384, ptr %slot622, align 8
  %v4385 = load i64, ptr %slot621, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  %ld4387 = load i64, ptr %p4386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4387, ptr %slot623, align 8
  %v4388 = load i64, ptr %slot623, align 8
  %cmp4389 = icmp ne i64 %v4388, 0
  %cv4390 = zext i1 %cmp4389 to i32
  store i32 %cv4390, ptr %slot624, align 8
  %v4391 = load i32, ptr %slot624, align 8
  %cv4392 = zext i32 %v4391 to i64
  %cond4393 = icmp ne i64 %cv4392, 0
  br i1 %cond4393, label %bb_rcgnn822, label %bb_rcgdone822
bb_rcgnn822:
  %v4394 = load i64, ptr %slot623, align 8
  %op4395 = sub i64 %v4394, 16
  store i64 %op4395, ptr %slot625, align 8
  %v4396 = load i64, ptr %slot623, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %rgep4398 = getelementptr i8, ptr %p4397, i64 -16
  %ld4399 = load i64, ptr %rgep4398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4399, ptr %slot626, align 8
  %v4400 = load i64, ptr %slot626, align 8
  %op4401 = and i64 %v4400, 4611686018427387906
  store i64 %op4401, ptr %slot627, align 8
  %v4402 = load i64, ptr %slot627, align 8
  %cmp4403 = icmp ne i64 %v4402, 0
  %cv4404 = zext i1 %cmp4403 to i32
  store i32 %cv4404, ptr %slot628, align 8
  %v4405 = load i32, ptr %slot628, align 8
  %cv4406 = zext i32 %v4405 to i64
  %cond4407 = icmp ne i64 %cv4406, 0
  br i1 %cond4407, label %bb_rcgclear822, label %bb_rcgcounted822
bb_rcgcounted822:
  %v4408 = load i64, ptr %slot623, align 8
  %op4409 = sub i64 %v4408, 32
  store i64 %op4409, ptr %slot629, align 8
  %v4410 = load i64, ptr %slot623, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  %rgep4412 = getelementptr i8, ptr %p4411, i64 -32
  %ld4413 = load i64, ptr %rgep4412, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4413, ptr %slot630, align 8
  %v4414 = load i64, ptr %slot630, align 8
  %op4415 = sub i64 %v4414, 1
  store i64 %op4415, ptr %slot631, align 8
  %v4416 = load i64, ptr %slot631, align 8
  %cmp4417 = icmp eq i64 %v4416, 0
  %cv4418 = zext i1 %cmp4417 to i32
  store i32 %cv4418, ptr %slot632, align 8
  %v4419 = load i32, ptr %slot632, align 8
  %cv4420 = zext i32 %v4419 to i64
  %cond4421 = icmp ne i64 %cv4420, 0
  br i1 %cond4421, label %bb_rcglast822, label %bb_rcgdec822
bb_rcglast822:
  %v4422 = load i64, ptr %slot623, align 8
  %op4423 = sub i64 %v4422, 24
  store i64 %op4423, ptr %slot633, align 8
  %v4424 = load i64, ptr %slot623, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %rgep4426 = getelementptr i8, ptr %p4425, i64 -24
  %ld4427 = load i64, ptr %rgep4426, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4427, ptr %slot634, align 8
  %v4428 = load i64, ptr %slot634, align 8
  %cmp4429 = icmp ne i64 %v4428, 0
  %cv4430 = zext i1 %cmp4429 to i32
  store i32 %cv4430, ptr %slot635, align 8
  %v4431 = load i32, ptr %slot635, align 8
  %cv4432 = zext i32 %v4431 to i64
  %cond4433 = icmp ne i64 %cv4432, 0
  br i1 %cond4433, label %bb_rcgdec822, label %bb_rcgslow822
bb_rcgslow822:
  %v4434 = load i64, ptr %slot622, align 8
  %v4435 = load i64, ptr %slot621, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4434, i64 %v4435) nomerge, !dbg !150
  br label %bb_rcgdone822
bb_rcgdec822:
  %v4436 = load i64, ptr %slot631, align 8
  %v4437 = load i64, ptr %slot623, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  %rgep4439 = getelementptr i8, ptr %p4438, i64 -32
  store i64 %v4436, ptr %rgep4439, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear822
bb_rcgclear822:
  %v4440 = load i64, ptr %slot621, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  store i64 0, ptr %p4441, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone822
bb_rcgdone822:
  %v4442 = load i64, ptr %slot617, align 8
  %p4443 = inttoptr i64 %v4442 to ptr
  store i64 0, ptr %p4443, align 8, !alias.scope !3, !noalias !4
  %v4444 = load i64, ptr %slot617, align 8
  %p4446 = inttoptr i64 %v4444 to ptr
  %gep4447 = getelementptr i8, ptr %p4446, i64 8
  %op4445 = ptrtoint ptr %gep4447 to i64
  store i64 %op4445, ptr %slot636, align 8
  %v4448 = load i64, ptr %slot636, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  store i64 0, ptr %p4449, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone804
bb_rcslotdone804:
  br label %bb_rcprepared763
bb_rcprepared763:
  %v4450 = load i64, ptr %slot11, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %ld4452 = load i32, ptr %p4451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4452, ptr %slot637, align 8
  %v4453 = load i32, ptr %slot637, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcslotdrop830, label %bb_rcslotdone830
bb_rcslotdrop830:
  %v4456 = load i64, ptr %slot11, align 8
  %p4457 = inttoptr i64 %v4456 to ptr
  store i32 0, ptr %p4457, align 4, !alias.scope !3, !noalias !4
  %v4458 = load i64, ptr %slot40, align 8
  store i64 %v4458, ptr %slot638, align 8
  %v4459 = load i64, ptr %slot12, align 8
  %p4460 = inttoptr i64 %v4459 to ptr
  %ld4461 = load i32, ptr %p4460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4461, ptr %slot639, align 8
  %v4462 = load i32, ptr %slot639, align 8
  %op4463 = and i32 %v4462, 28
  store i32 %op4463, ptr %slot640, align 8
  %v4464 = load i32, ptr %slot640, align 8
  %cv4465 = zext i32 %v4464 to i64
  %cond4466 = icmp ne i64 %cv4465, 0
  br i1 %cond4466, label %bb_rcslotrole830, label %bb_rcslotowner830
bb_rcslotrole830:
  %v4467 = load i64, ptr %slot65, align 8
  store i64 %v4467, ptr %slot641, align 8
  %v4468 = load i64, ptr %slot641, align 8
  %v4469 = load i64, ptr %slot638, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v4468, i64 %v4469) nomerge, !dbg !150
  br label %bb_rcslotdone830
bb_rcslotowner830:
  %v4470 = load i64, ptr %slot638, align 8
  %p4472 = inttoptr i64 %v4470 to ptr
  %gep4473 = getelementptr i8, ptr %p4472, i64 8
  %op4471 = ptrtoint ptr %gep4473 to i64
  store i64 %op4471, ptr %slot642, align 8
  %v4474 = load i64, ptr %slot65, align 8
  store i64 %v4474, ptr %slot643, align 8
  %v4475 = load i64, ptr %slot642, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  %ld4477 = load i64, ptr %p4476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4477, ptr %slot644, align 8
  %v4478 = load i64, ptr %slot644, align 8
  %cmp4479 = icmp ne i64 %v4478, 0
  %cv4480 = zext i1 %cmp4479 to i32
  store i32 %cv4480, ptr %slot645, align 8
  %v4481 = load i32, ptr %slot645, align 8
  %cv4482 = zext i32 %v4481 to i64
  %cond4483 = icmp ne i64 %cv4482, 0
  br i1 %cond4483, label %bb_rcgnn848, label %bb_rcgdone848
bb_rcgnn848:
  %v4484 = load i64, ptr %slot644, align 8
  %op4485 = sub i64 %v4484, 16
  store i64 %op4485, ptr %slot646, align 8
  %v4486 = load i64, ptr %slot644, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %rgep4488 = getelementptr i8, ptr %p4487, i64 -16
  %ld4489 = load i64, ptr %rgep4488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4489, ptr %slot647, align 8
  %v4490 = load i64, ptr %slot647, align 8
  %op4491 = and i64 %v4490, 4611686018427387906
  store i64 %op4491, ptr %slot648, align 8
  %v4492 = load i64, ptr %slot648, align 8
  %cmp4493 = icmp ne i64 %v4492, 0
  %cv4494 = zext i1 %cmp4493 to i32
  store i32 %cv4494, ptr %slot649, align 8
  %v4495 = load i32, ptr %slot649, align 8
  %cv4496 = zext i32 %v4495 to i64
  %cond4497 = icmp ne i64 %cv4496, 0
  br i1 %cond4497, label %bb_rcgclear848, label %bb_rcgcounted848
bb_rcgcounted848:
  %v4498 = load i64, ptr %slot644, align 8
  %op4499 = sub i64 %v4498, 32
  store i64 %op4499, ptr %slot650, align 8
  %v4500 = load i64, ptr %slot644, align 8
  %p4501 = inttoptr i64 %v4500 to ptr
  %rgep4502 = getelementptr i8, ptr %p4501, i64 -32
  %ld4503 = load i64, ptr %rgep4502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4503, ptr %slot651, align 8
  %v4504 = load i64, ptr %slot651, align 8
  %op4505 = sub i64 %v4504, 1
  store i64 %op4505, ptr %slot652, align 8
  %v4506 = load i64, ptr %slot652, align 8
  %cmp4507 = icmp eq i64 %v4506, 0
  %cv4508 = zext i1 %cmp4507 to i32
  store i32 %cv4508, ptr %slot653, align 8
  %v4509 = load i32, ptr %slot653, align 8
  %cv4510 = zext i32 %v4509 to i64
  %cond4511 = icmp ne i64 %cv4510, 0
  br i1 %cond4511, label %bb_rcglast848, label %bb_rcgdec848
bb_rcglast848:
  %v4512 = load i64, ptr %slot644, align 8
  %op4513 = sub i64 %v4512, 24
  store i64 %op4513, ptr %slot654, align 8
  %v4514 = load i64, ptr %slot644, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  %rgep4516 = getelementptr i8, ptr %p4515, i64 -24
  %ld4517 = load i64, ptr %rgep4516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4517, ptr %slot655, align 8
  %v4518 = load i64, ptr %slot655, align 8
  %cmp4519 = icmp ne i64 %v4518, 0
  %cv4520 = zext i1 %cmp4519 to i32
  store i32 %cv4520, ptr %slot656, align 8
  %v4521 = load i32, ptr %slot656, align 8
  %cv4522 = zext i32 %v4521 to i64
  %cond4523 = icmp ne i64 %cv4522, 0
  br i1 %cond4523, label %bb_rcgdec848, label %bb_rcgslow848
bb_rcgslow848:
  %v4524 = load i64, ptr %slot643, align 8
  %v4525 = load i64, ptr %slot642, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4524, i64 %v4525) nomerge, !dbg !150
  br label %bb_rcgdone848
bb_rcgdec848:
  %v4526 = load i64, ptr %slot652, align 8
  %v4527 = load i64, ptr %slot644, align 8
  %p4528 = inttoptr i64 %v4527 to ptr
  %rgep4529 = getelementptr i8, ptr %p4528, i64 -32
  store i64 %v4526, ptr %rgep4529, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear848
bb_rcgclear848:
  %v4530 = load i64, ptr %slot642, align 8
  %p4531 = inttoptr i64 %v4530 to ptr
  store i64 0, ptr %p4531, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone848
bb_rcgdone848:
  %v4532 = load i64, ptr %slot638, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  store i64 0, ptr %p4533, align 8, !alias.scope !3, !noalias !4
  %v4534 = load i64, ptr %slot638, align 8
  %p4536 = inttoptr i64 %v4534 to ptr
  %gep4537 = getelementptr i8, ptr %p4536, i64 8
  %op4535 = ptrtoint ptr %gep4537 to i64
  store i64 %op4535, ptr %slot657, align 8
  %v4538 = load i64, ptr %slot657, align 8
  %p4539 = inttoptr i64 %v4538 to ptr
  store i64 0, ptr %p4539, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone830
bb_rcslotdone830:
  %v4540 = load i64, ptr %slot40, align 8
  store i64 %v4540, ptr %slot658, align 8
  %v4541 = load i64, ptr %slot32, align 8
  store i64 %v4541, ptr %slot659, align 8
  %v4542 = load i64, ptr %slot659, align 8
  %v4543 = load i64, ptr %slot658, align 8
  %p4544 = inttoptr i64 %v4542 to ptr
  %p4545 = inttoptr i64 %v4543 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4545, ptr %p4544, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4546 = load i64, ptr %slot27, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  store i32 0, ptr %p4547, align 4, !alias.scope !3, !noalias !4
  %v4548 = load i64, ptr %slot12, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  store i32 2, ptr %p4549, align 4, !alias.scope !3, !noalias !4
  %v4550 = load i64, ptr %slot28, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  %ld4552 = load i32, ptr %p4551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4552, ptr %slot660, align 8
  %v4553 = load i32, ptr %slot660, align 8
  %v4554 = load i64, ptr %slot12, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  store i32 %v4553, ptr %p4555, align 4, !alias.scope !3, !noalias !4
  %v4556 = load i64, ptr %slot11, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  store i32 1, ptr %p4557, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept761
bb_rcselfkept761:
  %v4558 = load i64, ptr %slot35, align 8
  %v4559 = load i64, ptr %slot58, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  store i64 %v4558, ptr %p4560, align 8, !alias.scope !3, !noalias !4
  %v4561 = load i64, ptr %slot40, align 8
  %v4562 = load i64, ptr %slot59, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  store i64 %v4561, ptr %p4563, align 8, !alias.scope !3, !noalias !4
  %v4564 = load i64, ptr %slot59, align 8
  %p4565 = inttoptr i64 %v4564 to ptr
  %ld4566 = load i64, ptr %p4565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4566, ptr %slot661, align 8
  %v4567 = load i64, ptr %slot661, align 8
  %op4568 = add i64 %v4567, 0
  store i64 %op4568, ptr %slot662, align 8
  %v4569 = load i64, ptr %slot662, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  %ld4571 = load i64, ptr %p4570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4571, ptr %slot663, align 8
  %v4572 = load i64, ptr %slot663, align 8
  %v4573 = load i64, ptr %slot59, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  store i64 %v4572, ptr %p4574, align 8, !alias.scope !3, !noalias !4
  %v4575 = load i64, ptr %slot25, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  %ld4577 = load i32, ptr %p4576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4577, ptr %slot664, align 8
  %v4578 = load i32, ptr %slot664, align 8
  %cv4579 = zext i32 %v4578 to i64
  %cond4580 = icmp ne i64 %cv4579, 0
  br i1 %cond4580, label %bb_rcslotdrop865, label %bb_rcslotdone865
bb_rcslotdrop865:
  %v4581 = load i64, ptr %slot25, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  store i32 0, ptr %p4582, align 4, !alias.scope !3, !noalias !4
  %v4583 = load i64, ptr %slot30, align 8
  store i64 %v4583, ptr %slot665, align 8
  %v4584 = load i64, ptr %slot26, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  %ld4586 = load i32, ptr %p4585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4586, ptr %slot666, align 8
  %v4587 = load i32, ptr %slot666, align 8
  %op4588 = and i32 %v4587, 28
  store i32 %op4588, ptr %slot667, align 8
  %v4589 = load i32, ptr %slot667, align 8
  %cv4590 = zext i32 %v4589 to i64
  %cond4591 = icmp ne i64 %cv4590, 0
  br i1 %cond4591, label %bb_rcslotrole865, label %bb_rcslotowner865
bb_rcslotrole865:
  %v4592 = load i64, ptr %slot65, align 8
  store i64 %v4592, ptr %slot668, align 8
  %v4593 = load i64, ptr %slot668, align 8
  %v4594 = load i64, ptr %slot665, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v4593, i64 %v4594) nomerge, !dbg !152
  br label %bb_rcslotdone865
bb_rcslotowner865:
  %v4595 = load i64, ptr %slot65, align 8
  store i64 %v4595, ptr %slot669, align 8
  %v4596 = load i64, ptr %slot669, align 8
  %v4597 = load i64, ptr %slot665, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v4596, i64 %v4597) nomerge, !dbg !152
  br label %bb_rcslotdone865
bb_rcslotdone865:
  %v4598 = load i64, ptr %slot58, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i64, ptr %p4599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4600, ptr %slot670, align 8
  %v4601 = load i64, ptr %slot59, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  %ld4603 = load i64, ptr %p4602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4603, ptr %slot671, align 8
  %v4604 = load i64, ptr %slot1, align 8
  %v4605 = load i64, ptr %slot670, align 8
  %v4606 = load i64, ptr %slot671, align 8
  %call4607 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v4604, i64 %v4605, i64 %v4606) nomerge, !dbg !154
  store i64 %call4607, ptr %slot672, align 8
  %v4608 = load i64, ptr %slot672, align 8
  %v4609 = load i64, ptr %slot58, align 8
  %p4610 = inttoptr i64 %v4609 to ptr
  store i64 %v4608, ptr %p4610, align 8, !alias.scope !3, !noalias !4
  %v4611 = load i64, ptr %slot23, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  %ld4613 = load i32, ptr %p4612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4613, ptr %slot673, align 8
  %v4614 = load i32, ptr %slot673, align 8
  %cv4615 = zext i32 %v4614 to i64
  %cond4616 = icmp ne i64 %cv4615, 0
  br i1 %cond4616, label %bb_rcslotdrop877, label %bb_rcslotdone877
bb_rcslotdrop877:
  %v4617 = load i64, ptr %slot23, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  store i32 0, ptr %p4618, align 4, !alias.scope !3, !noalias !4
  %v4619 = load i64, ptr %slot29, align 8
  store i64 %v4619, ptr %slot674, align 8
  %v4620 = load i64, ptr %slot24, align 8
  %p4621 = inttoptr i64 %v4620 to ptr
  %ld4622 = load i32, ptr %p4621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4622, ptr %slot675, align 8
  %v4623 = load i32, ptr %slot675, align 8
  %op4624 = and i32 %v4623, 28
  store i32 %op4624, ptr %slot676, align 8
  %v4625 = load i32, ptr %slot676, align 8
  %cv4626 = zext i32 %v4625 to i64
  %cond4627 = icmp ne i64 %cv4626, 0
  br i1 %cond4627, label %bb_rcslotrole877, label %bb_rcslotowner877
bb_rcslotrole877:
  %v4628 = load i64, ptr %slot65, align 8
  store i64 %v4628, ptr %slot677, align 8
  %v4629 = load i64, ptr %slot677, align 8
  %v4630 = load i64, ptr %slot674, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v4629, i64 %v4630) nomerge, !dbg !154
  br label %bb_rcslotdone877
bb_rcslotowner877:
  %v4631 = load i64, ptr %slot65, align 8
  store i64 %v4631, ptr %slot678, align 8
  %v4632 = load i64, ptr %slot678, align 8
  %v4633 = load i64, ptr %slot674, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v4632, i64 %v4633) nomerge, !dbg !154
  br label %bb_rcslotdone877
bb_rcslotdone877:
  %v4634 = load i64, ptr %slot40, align 8
  %v4635 = load i64, ptr %slot58, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i64 %v4634, ptr %p4636, align 8, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot58, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  %ld4639 = load i64, ptr %p4638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4639, ptr %slot679, align 8
  %v4640 = load i64, ptr %slot679, align 8
  %op4641 = add i64 %v4640, 8
  store i64 %op4641, ptr %slot680, align 8
  %v4642 = load i64, ptr %slot680, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  %ld4644 = load i64, ptr %p4643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4644, ptr %slot681, align 8
  %v4645 = load i64, ptr %slot681, align 8
  %v4646 = load i64, ptr %slot58, align 8
  %p4647 = inttoptr i64 %v4646 to ptr
  store i64 %v4645, ptr %p4647, align 8, !alias.scope !3, !noalias !4
  %v4648 = load i64, ptr %slot58, align 8
  %p4649 = inttoptr i64 %v4648 to ptr
  %ld4650 = load i64, ptr %p4649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4650, ptr %slot682, align 8
  %v4651 = load i64, ptr %slot682, align 8
  %v4652 = load i64, ptr %slot31, align 8
  %p4653 = inttoptr i64 %v4652 to ptr
  store i64 %v4651, ptr %p4653, align 8, !alias.scope !3, !noalias !4
  %v4654 = load i64, ptr %slot31, align 8
  store i64 %v4654, ptr %slot683, align 8
  %v4655 = load i64, ptr %slot32, align 8
  store i64 %v4655, ptr %slot684, align 8
  %v4656 = load i64, ptr %slot683, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %ld4658 = load i64, ptr %p4657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4658, ptr %slot685, align 8
  %v4659 = load i64, ptr %slot685, align 8
  %cmp4660 = icmp ne i64 %v4659, 0
  %cv4661 = zext i1 %cmp4660 to i32
  store i32 %cv4661, ptr %slot686, align 8
  %v4662 = load i32, ptr %slot686, align 8
  %cv4663 = zext i32 %v4662 to i64
  %cond4664 = icmp ne i64 %cv4663, 0
  br i1 %cond4664, label %bb_rcgnn891, label %bb_rcgstore891
bb_rcgnn891:
  %v4665 = load i64, ptr %slot685, align 8
  %op4666 = sub i64 %v4665, 16
  store i64 %op4666, ptr %slot687, align 8
  %v4667 = load i64, ptr %slot685, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %rgep4669 = getelementptr i8, ptr %p4668, i64 -16
  %ld4670 = load i64, ptr %rgep4669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4670, ptr %slot688, align 8
  %v4671 = load i64, ptr %slot688, align 8
  %op4672 = and i64 %v4671, 4611686018427387906
  store i64 %op4672, ptr %slot689, align 8
  %v4673 = load i64, ptr %slot689, align 8
  %cmp4674 = icmp ne i64 %v4673, 0
  %cv4675 = zext i1 %cmp4674 to i32
  store i32 %cv4675, ptr %slot690, align 8
  %v4676 = load i32, ptr %slot690, align 8
  %cv4677 = zext i32 %v4676 to i64
  %cond4678 = icmp ne i64 %cv4677, 0
  br i1 %cond4678, label %bb_rcgstore891, label %bb_rcginc891
bb_rcginc891:
  %v4679 = load i64, ptr %slot685, align 8
  %op4680 = sub i64 %v4679, 24
  store i64 %op4680, ptr %slot691, align 8
  %v4681 = load i64, ptr %slot685, align 8
  %p4682 = inttoptr i64 %v4681 to ptr
  %rgep4683 = getelementptr i8, ptr %p4682, i64 -24
  %ld4684 = load i64, ptr %rgep4683, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4684, ptr %slot692, align 8
  %v4685 = load i64, ptr %slot692, align 8
  %op4686 = add i64 %v4685, 1
  store i64 %op4686, ptr %slot693, align 8
  %v4687 = load i64, ptr %slot693, align 8
  %cmp4688 = icmp eq i64 %v4687, 0
  %cv4689 = zext i1 %cmp4688 to i32
  store i32 %cv4689, ptr %slot694, align 8
  %v4690 = load i32, ptr %slot694, align 8
  %cv4691 = zext i32 %v4690 to i64
  %cond4692 = icmp ne i64 %cv4691, 0
  br i1 %cond4692, label %bb_rcglimit891, label %bb_rcgcapacity891
bb_rcglimit891:
  %v4693 = load i64, ptr %slot1, align 8
  %p4694 = inttoptr i64 %v4693 to ptr
  %call4695 = call i32 @myl_qbe_rc_status(ptr %p4694, i32 2) nomerge, !dbg !156
  store i32 %call4695, ptr %slot695, align 8
  br label %bb_failure
bb_rcgcapacity891:
  %v4696 = load i64, ptr %slot693, align 8
  %v4697 = load i64, ptr %slot685, align 8
  %p4698 = inttoptr i64 %v4697 to ptr
  %rgep4699 = getelementptr i8, ptr %p4698, i64 -24
  store i64 %v4696, ptr %rgep4699, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore891
bb_rcgstore891:
  %v4700 = load i64, ptr %slot685, align 8
  %v4701 = load i64, ptr %slot684, align 8
  %p4702 = inttoptr i64 %v4701 to ptr
  store i64 %v4700, ptr %p4702, align 8, !alias.scope !3, !noalias !4
  %v4703 = load i64, ptr %slot28, align 8
  %p4704 = inttoptr i64 %v4703 to ptr
  store i32 2, ptr %p4704, align 4, !alias.scope !3, !noalias !4
  %v4705 = load i64, ptr %slot28, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  store i32 16, ptr %p4706, align 4, !alias.scope !3, !noalias !4
  %v4707 = load i64, ptr %slot27, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  store i32 1, ptr %p4708, align 4, !alias.scope !3, !noalias !4
  %v4709 = load i64, ptr %slot23, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  %ld4711 = load i32, ptr %p4710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4711, ptr %slot696, align 8
  %v4712 = load i32, ptr %slot696, align 8
  %cv4713 = zext i32 %v4712 to i64
  %cond4714 = icmp ne i64 %cv4713, 0
  br i1 %cond4714, label %bb_rcslotdrop907, label %bb_rcslotdone907
bb_rcslotdrop907:
  %v4715 = load i64, ptr %slot23, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i32 0, ptr %p4716, align 4, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot29, align 8
  store i64 %v4717, ptr %slot697, align 8
  %v4718 = load i64, ptr %slot24, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %ld4720 = load i32, ptr %p4719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4720, ptr %slot698, align 8
  %v4721 = load i32, ptr %slot698, align 8
  %op4722 = and i32 %v4721, 28
  store i32 %op4722, ptr %slot699, align 8
  %v4723 = load i32, ptr %slot699, align 8
  %cv4724 = zext i32 %v4723 to i64
  %cond4725 = icmp ne i64 %cv4724, 0
  br i1 %cond4725, label %bb_rcslotrole907, label %bb_rcslotowner907
bb_rcslotrole907:
  %v4726 = load i64, ptr %slot65, align 8
  store i64 %v4726, ptr %slot700, align 8
  %v4727 = load i64, ptr %slot700, align 8
  %v4728 = load i64, ptr %slot697, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v4727, i64 %v4728) nomerge, !dbg !156
  br label %bb_rcslotdone907
bb_rcslotowner907:
  %v4729 = load i64, ptr %slot65, align 8
  store i64 %v4729, ptr %slot701, align 8
  %v4730 = load i64, ptr %slot701, align 8
  %v4731 = load i64, ptr %slot697, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v4730, i64 %v4731) nomerge, !dbg !156
  br label %bb_rcslotdone907
bb_rcslotdone907:
  %v4732 = load i64, ptr %slot29, align 8
  store i64 %v4732, ptr %slot702, align 8
  %v4733 = load i64, ptr %slot32, align 8
  store i64 %v4733, ptr %slot703, align 8
  %v4734 = load i64, ptr %slot703, align 8
  %v4735 = load i64, ptr %slot702, align 8
  %p4736 = inttoptr i64 %v4734 to ptr
  %p4737 = inttoptr i64 %v4735 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4737, ptr %p4736, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4738 = load i64, ptr %slot24, align 8
  %p4739 = inttoptr i64 %v4738 to ptr
  store i32 2, ptr %p4739, align 4, !alias.scope !3, !noalias !4
  %v4740 = load i64, ptr %slot28, align 8
  %p4741 = inttoptr i64 %v4740 to ptr
  %ld4742 = load i32, ptr %p4741, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4742, ptr %slot704, align 8
  %v4743 = load i32, ptr %slot704, align 8
  %v4744 = load i64, ptr %slot24, align 8
  %p4745 = inttoptr i64 %v4744 to ptr
  store i32 %v4743, ptr %p4745, align 4, !alias.scope !3, !noalias !4
  %v4746 = load i64, ptr %slot27, align 8
  %p4747 = inttoptr i64 %v4746 to ptr
  store i32 0, ptr %p4747, align 4, !alias.scope !3, !noalias !4
  %v4748 = load i64, ptr %slot23, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  store i32 1, ptr %p4749, align 4, !alias.scope !3, !noalias !4
  %v4750 = load i64, ptr %slot702, align 8
  %p4751 = inttoptr i64 %v4750 to ptr
  %ld4752 = load i64, ptr %p4751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4752, ptr %slot705, align 8
  %v4753 = load i64, ptr %slot705, align 8
  %v4754 = load i64, ptr %slot58, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  store i64 %v4753, ptr %p4755, align 8, !alias.scope !3, !noalias !4
  %v4756 = load i64, ptr %slot58, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  %ld4758 = load i64, ptr %p4757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4758, ptr %slot706, align 8
  %v4759 = load i64, ptr %slot32, align 8
  store i64 %v4759, ptr %slot707, align 8
  %v4760 = load i64, ptr %slot706, align 8
  %cmp4761 = icmp ne i64 %v4760, 0
  %cv4762 = zext i1 %cmp4761 to i32
  store i32 %cv4762, ptr %slot708, align 8
  %v4763 = load i32, ptr %slot708, align 8
  %cv4764 = zext i32 %v4763 to i64
  %cond4765 = icmp ne i64 %cv4764, 0
  br i1 %cond4765, label %bb_rcgnn927, label %bb_rcgstore927
bb_rcgnn927:
  %v4766 = load i64, ptr %slot706, align 8
  %op4767 = sub i64 %v4766, 16
  store i64 %op4767, ptr %slot709, align 8
  %v4768 = load i64, ptr %slot706, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  %rgep4770 = getelementptr i8, ptr %p4769, i64 -16
  %ld4771 = load i64, ptr %rgep4770, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4771, ptr %slot710, align 8
  %v4772 = load i64, ptr %slot710, align 8
  %op4773 = and i64 %v4772, 4611686018427387906
  store i64 %op4773, ptr %slot711, align 8
  %v4774 = load i64, ptr %slot711, align 8
  %cmp4775 = icmp ne i64 %v4774, 0
  %cv4776 = zext i1 %cmp4775 to i32
  store i32 %cv4776, ptr %slot712, align 8
  %v4777 = load i32, ptr %slot712, align 8
  %cv4778 = zext i32 %v4777 to i64
  %cond4779 = icmp ne i64 %cv4778, 0
  br i1 %cond4779, label %bb_rcgstore927, label %bb_rcginc927
bb_rcginc927:
  %v4780 = load i64, ptr %slot706, align 8
  %op4781 = sub i64 %v4780, 24
  store i64 %op4781, ptr %slot713, align 8
  %v4782 = load i64, ptr %slot706, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  %rgep4784 = getelementptr i8, ptr %p4783, i64 -24
  %ld4785 = load i64, ptr %rgep4784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4785, ptr %slot714, align 8
  %v4786 = load i64, ptr %slot714, align 8
  %op4787 = add i64 %v4786, 1
  store i64 %op4787, ptr %slot715, align 8
  %v4788 = load i64, ptr %slot715, align 8
  %cmp4789 = icmp eq i64 %v4788, 0
  %cv4790 = zext i1 %cmp4789 to i32
  store i32 %cv4790, ptr %slot716, align 8
  %v4791 = load i32, ptr %slot716, align 8
  %cv4792 = zext i32 %v4791 to i64
  %cond4793 = icmp ne i64 %cv4792, 0
  br i1 %cond4793, label %bb_rcglimit927, label %bb_rcgcapacity927
bb_rcglimit927:
  %v4794 = load i64, ptr %slot1, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %call4796 = call i32 @myl_qbe_rc_status(ptr %p4795, i32 2) nomerge, !dbg !158
  store i32 %call4796, ptr %slot717, align 8
  br label %bb_failure
bb_rcgcapacity927:
  %v4797 = load i64, ptr %slot715, align 8
  %v4798 = load i64, ptr %slot706, align 8
  %p4799 = inttoptr i64 %v4798 to ptr
  %rgep4800 = getelementptr i8, ptr %p4799, i64 -24
  store i64 %v4797, ptr %rgep4800, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore927
bb_rcgstore927:
  %v4801 = load i64, ptr %slot706, align 8
  %v4802 = load i64, ptr %slot707, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  store i64 %v4801, ptr %p4803, align 8, !alias.scope !3, !noalias !4
  %v4804 = load i64, ptr %slot28, align 8
  %p4805 = inttoptr i64 %v4804 to ptr
  store i32 2, ptr %p4805, align 4, !alias.scope !3, !noalias !4
  %v4806 = load i64, ptr %slot28, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  store i32 8, ptr %p4807, align 4, !alias.scope !3, !noalias !4
  %v4808 = load i64, ptr %slot27, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  store i32 1, ptr %p4809, align 4, !alias.scope !3, !noalias !4
  %v4810 = load i64, ptr %slot23, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  %ld4812 = load i32, ptr %p4811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4812, ptr %slot718, align 8
  %v4813 = load i32, ptr %slot718, align 8
  %cv4814 = zext i32 %v4813 to i64
  %cond4815 = icmp ne i64 %cv4814, 0
  br i1 %cond4815, label %bb_rcslotdrop943, label %bb_rcslotdone943
bb_rcslotdrop943:
  %v4816 = load i64, ptr %slot23, align 8
  %p4817 = inttoptr i64 %v4816 to ptr
  store i32 0, ptr %p4817, align 4, !alias.scope !3, !noalias !4
  %v4818 = load i64, ptr %slot29, align 8
  store i64 %v4818, ptr %slot719, align 8
  %v4819 = load i64, ptr %slot24, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  %ld4821 = load i32, ptr %p4820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4821, ptr %slot720, align 8
  %v4822 = load i32, ptr %slot720, align 8
  %op4823 = and i32 %v4822, 28
  store i32 %op4823, ptr %slot721, align 8
  %v4824 = load i32, ptr %slot721, align 8
  %cv4825 = zext i32 %v4824 to i64
  %cond4826 = icmp ne i64 %cv4825, 0
  br i1 %cond4826, label %bb_rcslotrole943, label %bb_rcslotowner943
bb_rcslotrole943:
  %v4827 = load i64, ptr %slot65, align 8
  store i64 %v4827, ptr %slot722, align 8
  %v4828 = load i64, ptr %slot719, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  %ld4830 = load i64, ptr %p4829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4830, ptr %slot723, align 8
  %v4831 = load i64, ptr %slot723, align 8
  %cmp4832 = icmp ne i64 %v4831, 0
  %cv4833 = zext i1 %cmp4832 to i32
  store i32 %cv4833, ptr %slot724, align 8
  %v4834 = load i32, ptr %slot724, align 8
  %cv4835 = zext i32 %v4834 to i64
  %cond4836 = icmp ne i64 %cv4835, 0
  br i1 %cond4836, label %bb_rcgnn959, label %bb_rcgdone959
bb_rcgnn959:
  %v4837 = load i64, ptr %slot723, align 8
  %op4838 = sub i64 %v4837, 16
  store i64 %op4838, ptr %slot725, align 8
  %v4839 = load i64, ptr %slot723, align 8
  %p4840 = inttoptr i64 %v4839 to ptr
  %rgep4841 = getelementptr i8, ptr %p4840, i64 -16
  %ld4842 = load i64, ptr %rgep4841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4842, ptr %slot726, align 8
  %v4843 = load i64, ptr %slot726, align 8
  %op4844 = and i64 %v4843, 4611686018427387906
  store i64 %op4844, ptr %slot727, align 8
  %v4845 = load i64, ptr %slot727, align 8
  %cmp4846 = icmp ne i64 %v4845, 0
  %cv4847 = zext i1 %cmp4846 to i32
  store i32 %cv4847, ptr %slot728, align 8
  %v4848 = load i32, ptr %slot728, align 8
  %cv4849 = zext i32 %v4848 to i64
  %cond4850 = icmp ne i64 %cv4849, 0
  br i1 %cond4850, label %bb_rcgclear959, label %bb_rcgcounted959
bb_rcgcounted959:
  %v4851 = load i64, ptr %slot723, align 8
  %op4852 = sub i64 %v4851, 24
  store i64 %op4852, ptr %slot729, align 8
  %v4853 = load i64, ptr %slot723, align 8
  %p4854 = inttoptr i64 %v4853 to ptr
  %rgep4855 = getelementptr i8, ptr %p4854, i64 -24
  %ld4856 = load i64, ptr %rgep4855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4856, ptr %slot730, align 8
  %v4857 = load i64, ptr %slot730, align 8
  %op4858 = sub i64 %v4857, 1
  store i64 %op4858, ptr %slot731, align 8
  %v4859 = load i64, ptr %slot731, align 8
  %cmp4860 = icmp eq i64 %v4859, 0
  %cv4861 = zext i1 %cmp4860 to i32
  store i32 %cv4861, ptr %slot732, align 8
  %v4862 = load i32, ptr %slot732, align 8
  %cv4863 = zext i32 %v4862 to i64
  %cond4864 = icmp ne i64 %cv4863, 0
  br i1 %cond4864, label %bb_rcglast959, label %bb_rcgdec959
bb_rcglast959:
  %v4865 = load i64, ptr %slot723, align 8
  %op4866 = sub i64 %v4865, 32
  store i64 %op4866, ptr %slot733, align 8
  %v4867 = load i64, ptr %slot723, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  %rgep4869 = getelementptr i8, ptr %p4868, i64 -32
  %ld4870 = load i64, ptr %rgep4869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4870, ptr %slot734, align 8
  %v4871 = load i64, ptr %slot734, align 8
  %cmp4872 = icmp ne i64 %v4871, 0
  %cv4873 = zext i1 %cmp4872 to i32
  store i32 %cv4873, ptr %slot735, align 8
  %v4874 = load i32, ptr %slot735, align 8
  %cv4875 = zext i32 %v4874 to i64
  %cond4876 = icmp ne i64 %cv4875, 0
  br i1 %cond4876, label %bb_rcgdec959, label %bb_rcgslow959
bb_rcgslow959:
  %v4877 = load i64, ptr %slot722, align 8
  %v4878 = load i64, ptr %slot719, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4877, i64 %v4878) nomerge, !dbg !158
  br label %bb_rcgdone959
bb_rcgdec959:
  %v4879 = load i64, ptr %slot731, align 8
  %v4880 = load i64, ptr %slot723, align 8
  %p4881 = inttoptr i64 %v4880 to ptr
  %rgep4882 = getelementptr i8, ptr %p4881, i64 -24
  store i64 %v4879, ptr %rgep4882, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear959
bb_rcgclear959:
  %v4883 = load i64, ptr %slot719, align 8
  %p4884 = inttoptr i64 %v4883 to ptr
  store i64 0, ptr %p4884, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone959
bb_rcgdone959:
  br label %bb_rcslotdone943
bb_rcslotowner943:
  %v4885 = load i64, ptr %slot65, align 8
  store i64 %v4885, ptr %slot736, align 8
  %v4886 = load i64, ptr %slot719, align 8
  %p4887 = inttoptr i64 %v4886 to ptr
  %ld4888 = load i64, ptr %p4887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4888, ptr %slot737, align 8
  %v4889 = load i64, ptr %slot737, align 8
  %cmp4890 = icmp ne i64 %v4889, 0
  %cv4891 = zext i1 %cmp4890 to i32
  store i32 %cv4891, ptr %slot738, align 8
  %v4892 = load i32, ptr %slot738, align 8
  %cv4893 = zext i32 %v4892 to i64
  %cond4894 = icmp ne i64 %cv4893, 0
  br i1 %cond4894, label %bb_rcgnn974, label %bb_rcgdone974
bb_rcgnn974:
  %v4895 = load i64, ptr %slot737, align 8
  %op4896 = sub i64 %v4895, 16
  store i64 %op4896, ptr %slot739, align 8
  %v4897 = load i64, ptr %slot737, align 8
  %p4898 = inttoptr i64 %v4897 to ptr
  %rgep4899 = getelementptr i8, ptr %p4898, i64 -16
  %ld4900 = load i64, ptr %rgep4899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4900, ptr %slot740, align 8
  %v4901 = load i64, ptr %slot740, align 8
  %op4902 = and i64 %v4901, 4611686018427387906
  store i64 %op4902, ptr %slot741, align 8
  %v4903 = load i64, ptr %slot741, align 8
  %cmp4904 = icmp ne i64 %v4903, 0
  %cv4905 = zext i1 %cmp4904 to i32
  store i32 %cv4905, ptr %slot742, align 8
  %v4906 = load i32, ptr %slot742, align 8
  %cv4907 = zext i32 %v4906 to i64
  %cond4908 = icmp ne i64 %cv4907, 0
  br i1 %cond4908, label %bb_rcgclear974, label %bb_rcgcounted974
bb_rcgcounted974:
  %v4909 = load i64, ptr %slot737, align 8
  %op4910 = sub i64 %v4909, 32
  store i64 %op4910, ptr %slot743, align 8
  %v4911 = load i64, ptr %slot737, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  %rgep4913 = getelementptr i8, ptr %p4912, i64 -32
  %ld4914 = load i64, ptr %rgep4913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4914, ptr %slot744, align 8
  %v4915 = load i64, ptr %slot744, align 8
  %op4916 = sub i64 %v4915, 1
  store i64 %op4916, ptr %slot745, align 8
  %v4917 = load i64, ptr %slot745, align 8
  %cmp4918 = icmp eq i64 %v4917, 0
  %cv4919 = zext i1 %cmp4918 to i32
  store i32 %cv4919, ptr %slot746, align 8
  %v4920 = load i32, ptr %slot746, align 8
  %cv4921 = zext i32 %v4920 to i64
  %cond4922 = icmp ne i64 %cv4921, 0
  br i1 %cond4922, label %bb_rcglast974, label %bb_rcgdec974
bb_rcglast974:
  %v4923 = load i64, ptr %slot737, align 8
  %op4924 = sub i64 %v4923, 24
  store i64 %op4924, ptr %slot747, align 8
  %v4925 = load i64, ptr %slot737, align 8
  %p4926 = inttoptr i64 %v4925 to ptr
  %rgep4927 = getelementptr i8, ptr %p4926, i64 -24
  %ld4928 = load i64, ptr %rgep4927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4928, ptr %slot748, align 8
  %v4929 = load i64, ptr %slot748, align 8
  %cmp4930 = icmp ne i64 %v4929, 0
  %cv4931 = zext i1 %cmp4930 to i32
  store i32 %cv4931, ptr %slot749, align 8
  %v4932 = load i32, ptr %slot749, align 8
  %cv4933 = zext i32 %v4932 to i64
  %cond4934 = icmp ne i64 %cv4933, 0
  br i1 %cond4934, label %bb_rcgdec974, label %bb_rcgslow974
bb_rcgslow974:
  %v4935 = load i64, ptr %slot736, align 8
  %v4936 = load i64, ptr %slot719, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4935, i64 %v4936) nomerge, !dbg !158
  br label %bb_rcgdone974
bb_rcgdec974:
  %v4937 = load i64, ptr %slot745, align 8
  %v4938 = load i64, ptr %slot737, align 8
  %p4939 = inttoptr i64 %v4938 to ptr
  %rgep4940 = getelementptr i8, ptr %p4939, i64 -32
  store i64 %v4937, ptr %rgep4940, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear974
bb_rcgclear974:
  %v4941 = load i64, ptr %slot719, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  store i64 0, ptr %p4942, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone974
bb_rcgdone974:
  br label %bb_rcslotdone943
bb_rcslotdone943:
  %v4943 = load i64, ptr %slot29, align 8
  store i64 %v4943, ptr %slot750, align 8
  %v4944 = load i64, ptr %slot32, align 8
  store i64 %v4944, ptr %slot751, align 8
  %v4945 = load i64, ptr %slot751, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  %ld4947 = load i64, ptr %p4946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4947, ptr %slot752, align 8
  %v4948 = load i64, ptr %slot752, align 8
  %v4949 = load i64, ptr %slot750, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  store i64 %v4948, ptr %p4950, align 8, !alias.scope !3, !noalias !4
  %v4951 = load i64, ptr %slot24, align 8
  %p4952 = inttoptr i64 %v4951 to ptr
  store i32 2, ptr %p4952, align 4, !alias.scope !3, !noalias !4
  %v4953 = load i64, ptr %slot24, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  store i32 8, ptr %p4954, align 4, !alias.scope !3, !noalias !4
  %v4955 = load i64, ptr %slot23, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  store i32 1, ptr %p4956, align 4, !alias.scope !3, !noalias !4
  %v4957 = load i64, ptr %slot27, align 8
  %p4958 = inttoptr i64 %v4957 to ptr
  store i32 0, ptr %p4958, align 4, !alias.scope !3, !noalias !4
  %v4959 = load i64, ptr %slot752, align 8
  %v4960 = load i64, ptr %slot58, align 8
  %p4961 = inttoptr i64 %v4960 to ptr
  store i64 %v4959, ptr %p4961, align 8, !alias.scope !3, !noalias !4
  %v4962 = load i64, ptr %slot32, align 8
  store i64 %v4962, ptr %slot753, align 8
  %v4963 = load i64, ptr %slot58, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  %ld4965 = load i64, ptr %p4964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4965, ptr %slot754, align 8
  %v4966 = load i64, ptr %slot754, align 8
  %v4967 = load i64, ptr %slot753, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  store i64 %v4966, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  %v4969 = load i64, ptr %slot28, align 8
  %p4970 = inttoptr i64 %v4969 to ptr
  store i32 2, ptr %p4970, align 4, !alias.scope !3, !noalias !4
  %v4971 = load i64, ptr %slot28, align 8
  %p4972 = inttoptr i64 %v4971 to ptr
  store i32 8, ptr %p4972, align 4, !alias.scope !3, !noalias !4
  %v4973 = load i64, ptr %slot27, align 8
  %p4974 = inttoptr i64 %v4973 to ptr
  store i32 1, ptr %p4974, align 4, !alias.scope !3, !noalias !4
  %v4975 = load i64, ptr %slot23, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  store i32 0, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  %v4977 = load i64, ptr %slot13, align 8
  %p4978 = inttoptr i64 %v4977 to ptr
  %ld4979 = load i32, ptr %p4978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4979, ptr %slot755, align 8
  %v4980 = load i32, ptr %slot755, align 8
  %cv4981 = zext i32 %v4980 to i64
  %cond4982 = icmp ne i64 %cv4981, 0
  br i1 %cond4982, label %bb_rcslotdrop993, label %bb_rcslotdone993
bb_rcslotdrop993:
  %v4983 = load i64, ptr %slot13, align 8
  %p4984 = inttoptr i64 %v4983 to ptr
  store i32 0, ptr %p4984, align 4, !alias.scope !3, !noalias !4
  %v4985 = load i64, ptr %slot41, align 8
  store i64 %v4985, ptr %slot756, align 8
  %v4986 = load i64, ptr %slot14, align 8
  %p4987 = inttoptr i64 %v4986 to ptr
  %ld4988 = load i32, ptr %p4987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4988, ptr %slot757, align 8
  %v4989 = load i32, ptr %slot757, align 8
  %op4990 = and i32 %v4989, 28
  store i32 %op4990, ptr %slot758, align 8
  %v4991 = load i32, ptr %slot758, align 8
  %cv4992 = zext i32 %v4991 to i64
  %cond4993 = icmp ne i64 %cv4992, 0
  br i1 %cond4993, label %bb_rcslotrole993, label %bb_rcslotowner993
bb_rcslotrole993:
  %v4994 = load i64, ptr %slot65, align 8
  store i64 %v4994, ptr %slot759, align 8
  %v4995 = load i64, ptr %slot756, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %ld4997 = load i64, ptr %p4996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4997, ptr %slot760, align 8
  %v4998 = load i64, ptr %slot760, align 8
  %cmp4999 = icmp ne i64 %v4998, 0
  %cv5000 = zext i1 %cmp4999 to i32
  store i32 %cv5000, ptr %slot761, align 8
  %v5001 = load i32, ptr %slot761, align 8
  %cv5002 = zext i32 %v5001 to i64
  %cond5003 = icmp ne i64 %cv5002, 0
  br i1 %cond5003, label %bb_rcgnn1009, label %bb_rcgdone1009
bb_rcgnn1009:
  %v5004 = load i64, ptr %slot760, align 8
  %op5005 = sub i64 %v5004, 16
  store i64 %op5005, ptr %slot762, align 8
  %v5006 = load i64, ptr %slot760, align 8
  %p5007 = inttoptr i64 %v5006 to ptr
  %rgep5008 = getelementptr i8, ptr %p5007, i64 -16
  %ld5009 = load i64, ptr %rgep5008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5009, ptr %slot763, align 8
  %v5010 = load i64, ptr %slot763, align 8
  %op5011 = and i64 %v5010, 4611686018427387906
  store i64 %op5011, ptr %slot764, align 8
  %v5012 = load i64, ptr %slot764, align 8
  %cmp5013 = icmp ne i64 %v5012, 0
  %cv5014 = zext i1 %cmp5013 to i32
  store i32 %cv5014, ptr %slot765, align 8
  %v5015 = load i32, ptr %slot765, align 8
  %cv5016 = zext i32 %v5015 to i64
  %cond5017 = icmp ne i64 %cv5016, 0
  br i1 %cond5017, label %bb_rcgclear1009, label %bb_rcgcounted1009
bb_rcgcounted1009:
  %v5018 = load i64, ptr %slot760, align 8
  %op5019 = sub i64 %v5018, 24
  store i64 %op5019, ptr %slot766, align 8
  %v5020 = load i64, ptr %slot760, align 8
  %p5021 = inttoptr i64 %v5020 to ptr
  %rgep5022 = getelementptr i8, ptr %p5021, i64 -24
  %ld5023 = load i64, ptr %rgep5022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5023, ptr %slot767, align 8
  %v5024 = load i64, ptr %slot767, align 8
  %op5025 = sub i64 %v5024, 1
  store i64 %op5025, ptr %slot768, align 8
  %v5026 = load i64, ptr %slot768, align 8
  %cmp5027 = icmp eq i64 %v5026, 0
  %cv5028 = zext i1 %cmp5027 to i32
  store i32 %cv5028, ptr %slot769, align 8
  %v5029 = load i32, ptr %slot769, align 8
  %cv5030 = zext i32 %v5029 to i64
  %cond5031 = icmp ne i64 %cv5030, 0
  br i1 %cond5031, label %bb_rcglast1009, label %bb_rcgdec1009
bb_rcglast1009:
  %v5032 = load i64, ptr %slot760, align 8
  %op5033 = sub i64 %v5032, 32
  store i64 %op5033, ptr %slot770, align 8
  %v5034 = load i64, ptr %slot760, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  %rgep5036 = getelementptr i8, ptr %p5035, i64 -32
  %ld5037 = load i64, ptr %rgep5036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5037, ptr %slot771, align 8
  %v5038 = load i64, ptr %slot771, align 8
  %cmp5039 = icmp ne i64 %v5038, 0
  %cv5040 = zext i1 %cmp5039 to i32
  store i32 %cv5040, ptr %slot772, align 8
  %v5041 = load i32, ptr %slot772, align 8
  %cv5042 = zext i32 %v5041 to i64
  %cond5043 = icmp ne i64 %cv5042, 0
  br i1 %cond5043, label %bb_rcgdec1009, label %bb_rcgslow1009
bb_rcgslow1009:
  %v5044 = load i64, ptr %slot759, align 8
  %v5045 = load i64, ptr %slot756, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5044, i64 %v5045) nomerge, !dbg !158
  br label %bb_rcgdone1009
bb_rcgdec1009:
  %v5046 = load i64, ptr %slot768, align 8
  %v5047 = load i64, ptr %slot760, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %rgep5049 = getelementptr i8, ptr %p5048, i64 -24
  store i64 %v5046, ptr %rgep5049, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1009
bb_rcgclear1009:
  %v5050 = load i64, ptr %slot756, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  store i64 0, ptr %p5051, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1009
bb_rcgdone1009:
  br label %bb_rcslotdone993
bb_rcslotowner993:
  %v5052 = load i64, ptr %slot65, align 8
  store i64 %v5052, ptr %slot773, align 8
  %v5053 = load i64, ptr %slot756, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %ld5055 = load i64, ptr %p5054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5055, ptr %slot774, align 8
  %v5056 = load i64, ptr %slot774, align 8
  %cmp5057 = icmp ne i64 %v5056, 0
  %cv5058 = zext i1 %cmp5057 to i32
  store i32 %cv5058, ptr %slot775, align 8
  %v5059 = load i32, ptr %slot775, align 8
  %cv5060 = zext i32 %v5059 to i64
  %cond5061 = icmp ne i64 %cv5060, 0
  br i1 %cond5061, label %bb_rcgnn1024, label %bb_rcgdone1024
bb_rcgnn1024:
  %v5062 = load i64, ptr %slot774, align 8
  %op5063 = sub i64 %v5062, 16
  store i64 %op5063, ptr %slot776, align 8
  %v5064 = load i64, ptr %slot774, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  %rgep5066 = getelementptr i8, ptr %p5065, i64 -16
  %ld5067 = load i64, ptr %rgep5066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5067, ptr %slot777, align 8
  %v5068 = load i64, ptr %slot777, align 8
  %op5069 = and i64 %v5068, 4611686018427387906
  store i64 %op5069, ptr %slot778, align 8
  %v5070 = load i64, ptr %slot778, align 8
  %cmp5071 = icmp ne i64 %v5070, 0
  %cv5072 = zext i1 %cmp5071 to i32
  store i32 %cv5072, ptr %slot779, align 8
  %v5073 = load i32, ptr %slot779, align 8
  %cv5074 = zext i32 %v5073 to i64
  %cond5075 = icmp ne i64 %cv5074, 0
  br i1 %cond5075, label %bb_rcgclear1024, label %bb_rcgcounted1024
bb_rcgcounted1024:
  %v5076 = load i64, ptr %slot774, align 8
  %op5077 = sub i64 %v5076, 32
  store i64 %op5077, ptr %slot780, align 8
  %v5078 = load i64, ptr %slot774, align 8
  %p5079 = inttoptr i64 %v5078 to ptr
  %rgep5080 = getelementptr i8, ptr %p5079, i64 -32
  %ld5081 = load i64, ptr %rgep5080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5081, ptr %slot781, align 8
  %v5082 = load i64, ptr %slot781, align 8
  %op5083 = sub i64 %v5082, 1
  store i64 %op5083, ptr %slot782, align 8
  %v5084 = load i64, ptr %slot782, align 8
  %cmp5085 = icmp eq i64 %v5084, 0
  %cv5086 = zext i1 %cmp5085 to i32
  store i32 %cv5086, ptr %slot783, align 8
  %v5087 = load i32, ptr %slot783, align 8
  %cv5088 = zext i32 %v5087 to i64
  %cond5089 = icmp ne i64 %cv5088, 0
  br i1 %cond5089, label %bb_rcglast1024, label %bb_rcgdec1024
bb_rcglast1024:
  %v5090 = load i64, ptr %slot774, align 8
  %op5091 = sub i64 %v5090, 24
  store i64 %op5091, ptr %slot784, align 8
  %v5092 = load i64, ptr %slot774, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  %rgep5094 = getelementptr i8, ptr %p5093, i64 -24
  %ld5095 = load i64, ptr %rgep5094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5095, ptr %slot785, align 8
  %v5096 = load i64, ptr %slot785, align 8
  %cmp5097 = icmp ne i64 %v5096, 0
  %cv5098 = zext i1 %cmp5097 to i32
  store i32 %cv5098, ptr %slot786, align 8
  %v5099 = load i32, ptr %slot786, align 8
  %cv5100 = zext i32 %v5099 to i64
  %cond5101 = icmp ne i64 %cv5100, 0
  br i1 %cond5101, label %bb_rcgdec1024, label %bb_rcgslow1024
bb_rcgslow1024:
  %v5102 = load i64, ptr %slot773, align 8
  %v5103 = load i64, ptr %slot756, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5102, i64 %v5103) nomerge, !dbg !158
  br label %bb_rcgdone1024
bb_rcgdec1024:
  %v5104 = load i64, ptr %slot782, align 8
  %v5105 = load i64, ptr %slot774, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %rgep5107 = getelementptr i8, ptr %p5106, i64 -32
  store i64 %v5104, ptr %rgep5107, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1024
bb_rcgclear1024:
  %v5108 = load i64, ptr %slot756, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  store i64 0, ptr %p5109, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1024
bb_rcgdone1024:
  br label %bb_rcslotdone993
bb_rcslotdone993:
  %v5110 = load i64, ptr %slot41, align 8
  store i64 %v5110, ptr %slot787, align 8
  %v5111 = load i64, ptr %slot753, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  %ld5113 = load i64, ptr %p5112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5113, ptr %slot788, align 8
  %v5114 = load i64, ptr %slot788, align 8
  %v5115 = load i64, ptr %slot787, align 8
  %p5116 = inttoptr i64 %v5115 to ptr
  store i64 %v5114, ptr %p5116, align 8, !alias.scope !3, !noalias !4
  %v5117 = load i64, ptr %slot14, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  store i32 2, ptr %p5118, align 4, !alias.scope !3, !noalias !4
  %v5119 = load i64, ptr %slot14, align 8
  %p5120 = inttoptr i64 %v5119 to ptr
  store i32 8, ptr %p5120, align 4, !alias.scope !3, !noalias !4
  %v5121 = load i64, ptr %slot13, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  store i32 1, ptr %p5122, align 4, !alias.scope !3, !noalias !4
  %v5123 = load i64, ptr %slot27, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i32 0, ptr %p5124, align 4, !alias.scope !3, !noalias !4
  %v5125 = load i64, ptr %slot58, align 8
  %p5126 = inttoptr i64 %v5125 to ptr
  store i64 0, ptr %p5126, align 8, !alias.scope !3, !noalias !4
  %v5127 = load i64, ptr %slot58, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  %ld5129 = load i64, ptr %p5128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5129, ptr %slot789, align 8
  %v5130 = load i64, ptr %slot789, align 8
  %v5131 = load i64, ptr %slot42, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  store i64 %v5130, ptr %p5132, align 8, !alias.scope !3, !noalias !4
  %v5133 = load i64, ptr %slot41, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  %ld5135 = load i64, ptr %p5134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5135, ptr %slot790, align 8
  %v5136 = load i64, ptr %slot790, align 8
  %op5137 = add i64 %v5136, 0
  store i64 %op5137, ptr %slot791, align 8
  %v5138 = load i64, ptr %slot791, align 8
  %p5139 = inttoptr i64 %v5138 to ptr
  %ld5140 = load i64, ptr %p5139, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5140, ptr %slot792, align 8
  %v5141 = load i64, ptr %slot792, align 8
  %v5142 = load i64, ptr %slot58, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  store i64 %v5141, ptr %p5143, align 8, !alias.scope !3, !noalias !4
  %v5144 = load i64, ptr %slot58, align 8
  %p5145 = inttoptr i64 %v5144 to ptr
  %ld5146 = load i64, ptr %p5145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5146, ptr %slot793, align 8
  %v5147 = load i64, ptr %slot793, align 8
  %cmp5148 = icmp ugt i64 %v5147, 9223372036854775807
  %cv5149 = zext i1 %cmp5148 to i64
  store i64 %cv5149, ptr %slot794, align 8
  %v5150 = load i64, ptr %slot794, align 8
  %cond5151 = icmp ne i64 %v5150, 0
  br i1 %cond5151, label %bb_cast_overflow1040, label %bb_cast_ok1040
bb_cast_overflow1040:
  %v5152 = load i64, ptr %slot1, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  %v5154 = load i64, ptr %slot793, align 8
  call void @myl_qbe_fail_cast(ptr %p5153, i64 %v5154, i64 320) nomerge, !dbg !160
  unreachable
bb_cast_ok1040:
  %v5155 = load i64, ptr %slot793, align 8
  %v5156 = load i64, ptr %slot58, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  store i64 %v5155, ptr %p5157, align 8, !alias.scope !3, !noalias !4
  %v5158 = load i64, ptr %slot58, align 8
  %p5159 = inttoptr i64 %v5158 to ptr
  %ld5160 = load i64, ptr %p5159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5160, ptr %slot795, align 8
  %v5161 = load i64, ptr %slot795, align 8
  %v5162 = load i64, ptr %slot43, align 8
  %p5163 = inttoptr i64 %v5162 to ptr
  store i64 %v5161, ptr %p5163, align 8, !alias.scope !3, !noalias !4
  br label %bb_i67
bb_i67:
  %v5164 = load i64, ptr %slot42, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  %ld5166 = load i64, ptr %p5165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5166, ptr %slot796, align 8
  %v5167 = load i64, ptr %slot796, align 8
  %v5168 = load i64, ptr %slot58, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  store i64 %v5167, ptr %p5169, align 8, !alias.scope !3, !noalias !4
  %v5170 = load i64, ptr %slot43, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %ld5172 = load i64, ptr %p5171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5172, ptr %slot797, align 8
  %v5173 = load i64, ptr %slot797, align 8
  %v5174 = load i64, ptr %slot59, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  store i64 %v5173, ptr %p5175, align 8, !alias.scope !3, !noalias !4
  %v5176 = load i64, ptr %slot59, align 8
  %p5177 = inttoptr i64 %v5176 to ptr
  %ld5178 = load i64, ptr %p5177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5178, ptr %slot798, align 8
  %v5179 = load i64, ptr %slot58, align 8
  %p5180 = inttoptr i64 %v5179 to ptr
  %ld5181 = load i64, ptr %p5180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5181, ptr %slot799, align 8
  %v5182 = load i64, ptr %slot799, align 8
  %v5183 = load i64, ptr %slot798, align 8
  %cmp5184 = icmp slt i64 %v5182, %v5183
  %cv5185 = zext i1 %cmp5184 to i64
  store i64 %cv5185, ptr %slot800, align 8
  %v5186 = load i64, ptr %slot800, align 8
  %v5187 = load i64, ptr %slot58, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  store i64 %v5186, ptr %p5188, align 8, !alias.scope !3, !noalias !4
  %v5189 = load i64, ptr %slot58, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  %ld5191 = load i64, ptr %p5190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5191, ptr %slot801, align 8
  %v5192 = load i64, ptr %slot801, align 8
  %cond5193 = icmp ne i64 %v5192, 0
  br i1 %cond5193, label %bb_next1048, label %bb_i89
bb_next1048:
  %v5194 = load i64, ptr %slot43, align 8
  %p5195 = inttoptr i64 %v5194 to ptr
  %ld5196 = load i64, ptr %p5195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5196, ptr %slot802, align 8
  %v5197 = load i64, ptr %slot802, align 8
  %v5198 = load i64, ptr %slot58, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  store i64 %v5197, ptr %p5199, align 8, !alias.scope !3, !noalias !4
  %v5200 = load i64, ptr %slot41, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  %ld5202 = load i64, ptr %p5201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5202, ptr %slot803, align 8
  %v5203 = load i64, ptr %slot58, align 8
  %p5204 = inttoptr i64 %v5203 to ptr
  %ld5205 = load i64, ptr %p5204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5205, ptr %slot804, align 8
  %v5206 = load i64, ptr %slot803, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  %ld5208 = load i64, ptr %p5207, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5208, ptr %slot805, align 8
  %v5209 = load i64, ptr %slot805, align 8
  %v5210 = load i64, ptr %slot804, align 8
  %cmp5211 = icmp eq i64 %v5209, %v5210
  %cv5212 = zext i1 %cmp5211 to i64
  store i64 %cv5212, ptr %slot806, align 8
  %v5213 = load i64, ptr %slot806, align 8
  %cond5214 = icmp ne i64 %v5213, 0
  br i1 %cond5214, label %bb_success1053, label %bb_failed1053
bb_failed1053:
  %v5215 = load i64, ptr %slot1, align 8
  %p5216 = inttoptr i64 %v5215 to ptr
  call void @myl_qbe_fail_iteration(ptr %p5216) nomerge, !dbg !162
  unreachable
bb_success1053:
  %v5217 = load i64, ptr %slot58, align 8
  %p5218 = inttoptr i64 %v5217 to ptr
  store i64 0, ptr %p5218, align 8, !alias.scope !3, !noalias !4
  %v5219 = load i64, ptr %slot42, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  %ld5221 = load i64, ptr %p5220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5221, ptr %slot807, align 8
  %v5222 = load i64, ptr %slot807, align 8
  %v5223 = load i64, ptr %slot58, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  store i64 %v5222, ptr %p5224, align 8, !alias.scope !3, !noalias !4
  %v5225 = load i64, ptr %slot41, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  %ld5227 = load i64, ptr %p5226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5227, ptr %slot808, align 8
  %v5228 = load i64, ptr %slot58, align 8
  %p5229 = inttoptr i64 %v5228 to ptr
  %ld5230 = load i64, ptr %p5229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5230, ptr %slot809, align 8
  %v5231 = load i64, ptr %slot808, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  %ld5233 = load i64, ptr %p5232, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5233, ptr %slot810, align 8
  %v5234 = load i64, ptr %slot809, align 8
  %v5235 = load i64, ptr %slot810, align 8
  %cmp5236 = icmp ult i64 %v5234, %v5235
  %cv5237 = zext i1 %cmp5236 to i64
  store i64 %cv5237, ptr %slot811, align 8
  %v5238 = load i64, ptr %slot811, align 8
  %cond5239 = icmp ne i64 %v5238, 0
  br i1 %cond5239, label %bb_success1060, label %bb_failed1060
bb_failed1060:
  %v5240 = load i64, ptr %slot1, align 8
  %p5241 = inttoptr i64 %v5240 to ptr
  %v5242 = load i64, ptr %slot809, align 8
  %v5243 = load i64, ptr %slot810, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5241, i64 %v5242, i64 %v5243) nomerge, !dbg !164
  unreachable
bb_success1060:
  %v5244 = load i64, ptr %slot808, align 8
  %op5245 = add i64 %v5244, 32
  store i64 %op5245, ptr %slot812, align 8
  %v5246 = load i64, ptr %slot812, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  %ld5248 = load i64, ptr %p5247, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5248, ptr %slot813, align 8
  %v5249 = load i64, ptr %slot809, align 8
  %op5250 = mul i64 %v5249, 8
  store i64 %op5250, ptr %slot814, align 8
  %v5251 = load i64, ptr %slot813, align 8
  %v5252 = load i64, ptr %slot814, align 8
  %op5253 = add i64 %v5251, %v5252
  store i64 %op5253, ptr %slot815, align 8
  %v5254 = load i64, ptr %slot813, align 8
  %p5255 = inttoptr i64 %v5254 to ptr
  %v5256 = load i64, ptr %slot814, align 8
  %egep5257 = getelementptr i8, ptr %p5255, i64 %v5256
  %ld5258 = load i64, ptr %egep5257, align 8, !alias.scope !12, !noalias !13
  store i64 %ld5258, ptr %slot816, align 8
  %v5259 = load i64, ptr %slot816, align 8
  %v5260 = load i64, ptr %slot58, align 8
  %p5261 = inttoptr i64 %v5260 to ptr
  store i64 %v5259, ptr %p5261, align 8, !alias.scope !3, !noalias !4
  %v5262 = load i64, ptr %slot58, align 8
  %p5263 = inttoptr i64 %v5262 to ptr
  %ld5264 = load i64, ptr %p5263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5264, ptr %slot817, align 8
  %v5265 = load i64, ptr %slot817, align 8
  %v5266 = load i64, ptr %slot44, align 8
  %p5267 = inttoptr i64 %v5266 to ptr
  store i64 %v5265, ptr %p5267, align 8, !alias.scope !3, !noalias !4
  %v5268 = load i64, ptr %slot35, align 8
  %v5269 = load i64, ptr %slot58, align 8
  %p5270 = inttoptr i64 %v5269 to ptr
  store i64 %v5268, ptr %p5270, align 8, !alias.scope !3, !noalias !4
  %v5271 = load i64, ptr %slot44, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  %ld5273 = load i64, ptr %p5272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5273, ptr %slot818, align 8
  %v5274 = load i64, ptr %slot818, align 8
  %v5275 = load i64, ptr %slot59, align 8
  %p5276 = inttoptr i64 %v5275 to ptr
  store i64 %v5274, ptr %p5276, align 8, !alias.scope !3, !noalias !4
  %v5277 = load i64, ptr %slot58, align 8
  %p5278 = inttoptr i64 %v5277 to ptr
  %ld5279 = load i64, ptr %p5278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5279, ptr %slot819, align 8
  %v5280 = load i64, ptr %slot59, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  %ld5282 = load i64, ptr %p5281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5282, ptr %slot820, align 8
  %v5283 = load i64, ptr %slot1, align 8
  %v5284 = load i64, ptr %slot819, align 8
  %v5285 = load i64, ptr %slot820, align 8
  %call5286 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v5283, i64 %v5284, i64 %v5285) nomerge, !dbg !166
  store i64 %call5286, ptr %slot821, align 8
  %v5287 = load i64, ptr %slot821, align 8
  %v5288 = load i64, ptr %slot58, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  store i64 %v5287, ptr %p5289, align 8, !alias.scope !3, !noalias !4
  %v5290 = load i64, ptr %slot23, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  %ld5292 = load i32, ptr %p5291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5292, ptr %slot822, align 8
  %v5293 = load i32, ptr %slot822, align 8
  %cv5294 = zext i32 %v5293 to i64
  %cond5295 = icmp ne i64 %cv5294, 0
  br i1 %cond5295, label %bb_rcslotdrop1073, label %bb_rcslotdone1073
bb_rcslotdrop1073:
  %v5296 = load i64, ptr %slot23, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  store i32 0, ptr %p5297, align 4, !alias.scope !3, !noalias !4
  %v5298 = load i64, ptr %slot29, align 8
  store i64 %v5298, ptr %slot823, align 8
  %v5299 = load i64, ptr %slot24, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  %ld5301 = load i32, ptr %p5300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5301, ptr %slot824, align 8
  %v5302 = load i32, ptr %slot824, align 8
  %op5303 = and i32 %v5302, 28
  store i32 %op5303, ptr %slot825, align 8
  %v5304 = load i32, ptr %slot825, align 8
  %cv5305 = zext i32 %v5304 to i64
  %cond5306 = icmp ne i64 %cv5305, 0
  br i1 %cond5306, label %bb_rcslotrole1073, label %bb_rcslotowner1073
bb_rcslotrole1073:
  %v5307 = load i64, ptr %slot65, align 8
  store i64 %v5307, ptr %slot826, align 8
  %v5308 = load i64, ptr %slot826, align 8
  %v5309 = load i64, ptr %slot823, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v5308, i64 %v5309) nomerge, !dbg !166
  br label %bb_rcslotdone1073
bb_rcslotowner1073:
  %v5310 = load i64, ptr %slot65, align 8
  store i64 %v5310, ptr %slot827, align 8
  %v5311 = load i64, ptr %slot827, align 8
  %v5312 = load i64, ptr %slot823, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v5311, i64 %v5312) nomerge, !dbg !166
  br label %bb_rcslotdone1073
bb_rcslotdone1073:
  %v5313 = load i64, ptr %slot43, align 8
  %p5314 = inttoptr i64 %v5313 to ptr
  %ld5315 = load i64, ptr %p5314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5315, ptr %slot828, align 8
  %v5316 = load i64, ptr %slot828, align 8
  %v5317 = load i64, ptr %slot58, align 8
  %p5318 = inttoptr i64 %v5317 to ptr
  store i64 %v5316, ptr %p5318, align 8, !alias.scope !3, !noalias !4
  %v5319 = load i64, ptr %slot41, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %ld5321 = load i64, ptr %p5320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5321, ptr %slot829, align 8
  %v5322 = load i64, ptr %slot58, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  %ld5324 = load i64, ptr %p5323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5324, ptr %slot830, align 8
  %v5325 = load i64, ptr %slot829, align 8
  %p5326 = inttoptr i64 %v5325 to ptr
  %ld5327 = load i64, ptr %p5326, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5327, ptr %slot831, align 8
  %v5328 = load i64, ptr %slot831, align 8
  %v5329 = load i64, ptr %slot830, align 8
  %cmp5330 = icmp eq i64 %v5328, %v5329
  %cv5331 = zext i1 %cmp5330 to i64
  store i64 %cv5331, ptr %slot832, align 8
  %v5332 = load i64, ptr %slot832, align 8
  %cond5333 = icmp ne i64 %v5332, 0
  br i1 %cond5333, label %bb_success1085, label %bb_failed1085
bb_failed1085:
  %v5334 = load i64, ptr %slot1, align 8
  %p5335 = inttoptr i64 %v5334 to ptr
  call void @myl_qbe_fail_iteration(ptr %p5335) nomerge, !dbg !168
  unreachable
bb_success1085:
  %v5336 = load i64, ptr %slot58, align 8
  %p5337 = inttoptr i64 %v5336 to ptr
  store i64 0, ptr %p5337, align 8, !alias.scope !3, !noalias !4
  %v5338 = load i64, ptr %slot42, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  %ld5340 = load i64, ptr %p5339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5340, ptr %slot833, align 8
  %v5341 = load i64, ptr %slot833, align 8
  %v5342 = load i64, ptr %slot58, align 8
  %p5343 = inttoptr i64 %v5342 to ptr
  store i64 %v5341, ptr %p5343, align 8, !alias.scope !3, !noalias !4
  %v5344 = load i64, ptr %slot59, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  store i64 1, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  %v5346 = load i64, ptr %slot59, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  %ld5348 = load i64, ptr %p5347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5348, ptr %slot834, align 8
  %v5349 = load i64, ptr %slot58, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  %ld5351 = load i64, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5351, ptr %slot835, align 8
  %v5352 = load i64, ptr %slot835, align 8
  %v5353 = load i64, ptr %slot834, align 8
  %ovpair5355 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5352, i64 %v5353)
  %op5354 = extractvalue { i64, i1 } %ovpair5355, 0
  %ov5356 = extractvalue { i64, i1 } %ovpair5355, 1
  store i64 %op5354, ptr %slot836, align 8
  %cv5357 = zext i1 %ov5356 to i64
  store i64 %cv5357, ptr %slot837, align 8
  %v5358 = load i64, ptr %slot837, align 8
  %cond5359 = icmp ne i64 %v5358, 0
  br i1 %cond5359, label %bb_overflow1089, label %bb_checked1089
bb_overflow1089:
  %v5360 = load i64, ptr %slot1, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %v5362 = load i64, ptr %slot835, align 8
  %v5363 = load i64, ptr %slot834, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5361, i64 0, i64 %v5362, i64 %v5363, i64 64) nomerge, !dbg !170
  unreachable
bb_checked1089:
  %v5364 = load i64, ptr %slot836, align 8
  %v5365 = load i64, ptr %slot58, align 8
  %p5366 = inttoptr i64 %v5365 to ptr
  store i64 %v5364, ptr %p5366, align 8, !alias.scope !3, !noalias !4
  %v5367 = load i64, ptr %slot58, align 8
  %p5368 = inttoptr i64 %v5367 to ptr
  %ld5369 = load i64, ptr %p5368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5369, ptr %slot838, align 8
  %v5370 = load i64, ptr %slot838, align 8
  %v5371 = load i64, ptr %slot42, align 8
  %p5372 = inttoptr i64 %v5371 to ptr
  store i64 %v5370, ptr %p5372, align 8, !alias.scope !3, !noalias !4
  br label %bb_i67
bb_i89:
  %v5373 = load i64, ptr %slot11, align 8
  %p5374 = inttoptr i64 %v5373 to ptr
  %ld5375 = load i32, ptr %p5374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5375, ptr %slot839, align 8
  %v5376 = load i32, ptr %slot839, align 8
  %cv5377 = zext i32 %v5376 to i64
  %cond5378 = icmp ne i64 %cv5377, 0
  br i1 %cond5378, label %bb_rcslotdrop1094, label %bb_rcslotdone1094
bb_rcslotdrop1094:
  %v5379 = load i64, ptr %slot11, align 8
  %p5380 = inttoptr i64 %v5379 to ptr
  store i32 0, ptr %p5380, align 4, !alias.scope !3, !noalias !4
  %v5381 = load i64, ptr %slot40, align 8
  store i64 %v5381, ptr %slot840, align 8
  %v5382 = load i64, ptr %slot12, align 8
  %p5383 = inttoptr i64 %v5382 to ptr
  %ld5384 = load i32, ptr %p5383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5384, ptr %slot841, align 8
  %v5385 = load i32, ptr %slot841, align 8
  %op5386 = and i32 %v5385, 28
  store i32 %op5386, ptr %slot842, align 8
  %v5387 = load i32, ptr %slot842, align 8
  %cv5388 = zext i32 %v5387 to i64
  %cond5389 = icmp ne i64 %cv5388, 0
  br i1 %cond5389, label %bb_rcslotrole1094, label %bb_rcslotowner1094
bb_rcslotrole1094:
  %v5390 = load i64, ptr %slot65, align 8
  store i64 %v5390, ptr %slot843, align 8
  %v5391 = load i64, ptr %slot843, align 8
  %v5392 = load i64, ptr %slot840, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v5391, i64 %v5392) nomerge, !dbg !172
  br label %bb_rcslotdone1094
bb_rcslotowner1094:
  %v5393 = load i64, ptr %slot840, align 8
  %p5395 = inttoptr i64 %v5393 to ptr
  %gep5396 = getelementptr i8, ptr %p5395, i64 8
  %op5394 = ptrtoint ptr %gep5396 to i64
  store i64 %op5394, ptr %slot844, align 8
  %v5397 = load i64, ptr %slot65, align 8
  store i64 %v5397, ptr %slot845, align 8
  %v5398 = load i64, ptr %slot844, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  %ld5400 = load i64, ptr %p5399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5400, ptr %slot846, align 8
  %v5401 = load i64, ptr %slot846, align 8
  %cmp5402 = icmp ne i64 %v5401, 0
  %cv5403 = zext i1 %cmp5402 to i32
  store i32 %cv5403, ptr %slot847, align 8
  %v5404 = load i32, ptr %slot847, align 8
  %cv5405 = zext i32 %v5404 to i64
  %cond5406 = icmp ne i64 %cv5405, 0
  br i1 %cond5406, label %bb_rcgnn1112, label %bb_rcgdone1112
bb_rcgnn1112:
  %v5407 = load i64, ptr %slot846, align 8
  %op5408 = sub i64 %v5407, 16
  store i64 %op5408, ptr %slot848, align 8
  %v5409 = load i64, ptr %slot846, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  %rgep5411 = getelementptr i8, ptr %p5410, i64 -16
  %ld5412 = load i64, ptr %rgep5411, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5412, ptr %slot849, align 8
  %v5413 = load i64, ptr %slot849, align 8
  %op5414 = and i64 %v5413, 4611686018427387906
  store i64 %op5414, ptr %slot850, align 8
  %v5415 = load i64, ptr %slot850, align 8
  %cmp5416 = icmp ne i64 %v5415, 0
  %cv5417 = zext i1 %cmp5416 to i32
  store i32 %cv5417, ptr %slot851, align 8
  %v5418 = load i32, ptr %slot851, align 8
  %cv5419 = zext i32 %v5418 to i64
  %cond5420 = icmp ne i64 %cv5419, 0
  br i1 %cond5420, label %bb_rcgclear1112, label %bb_rcgcounted1112
bb_rcgcounted1112:
  %v5421 = load i64, ptr %slot846, align 8
  %op5422 = sub i64 %v5421, 32
  store i64 %op5422, ptr %slot852, align 8
  %v5423 = load i64, ptr %slot846, align 8
  %p5424 = inttoptr i64 %v5423 to ptr
  %rgep5425 = getelementptr i8, ptr %p5424, i64 -32
  %ld5426 = load i64, ptr %rgep5425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5426, ptr %slot853, align 8
  %v5427 = load i64, ptr %slot853, align 8
  %op5428 = sub i64 %v5427, 1
  store i64 %op5428, ptr %slot854, align 8
  %v5429 = load i64, ptr %slot854, align 8
  %cmp5430 = icmp eq i64 %v5429, 0
  %cv5431 = zext i1 %cmp5430 to i32
  store i32 %cv5431, ptr %slot855, align 8
  %v5432 = load i32, ptr %slot855, align 8
  %cv5433 = zext i32 %v5432 to i64
  %cond5434 = icmp ne i64 %cv5433, 0
  br i1 %cond5434, label %bb_rcglast1112, label %bb_rcgdec1112
bb_rcglast1112:
  %v5435 = load i64, ptr %slot846, align 8
  %op5436 = sub i64 %v5435, 24
  store i64 %op5436, ptr %slot856, align 8
  %v5437 = load i64, ptr %slot846, align 8
  %p5438 = inttoptr i64 %v5437 to ptr
  %rgep5439 = getelementptr i8, ptr %p5438, i64 -24
  %ld5440 = load i64, ptr %rgep5439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5440, ptr %slot857, align 8
  %v5441 = load i64, ptr %slot857, align 8
  %cmp5442 = icmp ne i64 %v5441, 0
  %cv5443 = zext i1 %cmp5442 to i32
  store i32 %cv5443, ptr %slot858, align 8
  %v5444 = load i32, ptr %slot858, align 8
  %cv5445 = zext i32 %v5444 to i64
  %cond5446 = icmp ne i64 %cv5445, 0
  br i1 %cond5446, label %bb_rcgdec1112, label %bb_rcgslow1112
bb_rcgslow1112:
  %v5447 = load i64, ptr %slot845, align 8
  %v5448 = load i64, ptr %slot844, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5447, i64 %v5448) nomerge, !dbg !172
  br label %bb_rcgdone1112
bb_rcgdec1112:
  %v5449 = load i64, ptr %slot854, align 8
  %v5450 = load i64, ptr %slot846, align 8
  %p5451 = inttoptr i64 %v5450 to ptr
  %rgep5452 = getelementptr i8, ptr %p5451, i64 -32
  store i64 %v5449, ptr %rgep5452, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1112
bb_rcgclear1112:
  %v5453 = load i64, ptr %slot844, align 8
  %p5454 = inttoptr i64 %v5453 to ptr
  store i64 0, ptr %p5454, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1112
bb_rcgdone1112:
  %v5455 = load i64, ptr %slot840, align 8
  %p5456 = inttoptr i64 %v5455 to ptr
  store i64 0, ptr %p5456, align 8, !alias.scope !3, !noalias !4
  %v5457 = load i64, ptr %slot840, align 8
  %p5459 = inttoptr i64 %v5457 to ptr
  %gep5460 = getelementptr i8, ptr %p5459, i64 8
  %op5458 = ptrtoint ptr %gep5460 to i64
  store i64 %op5458, ptr %slot859, align 8
  %v5461 = load i64, ptr %slot859, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  store i64 0, ptr %p5462, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1094
bb_rcslotdone1094:
  br label %bb_i198
bb_i91:
  %v5463 = load i64, ptr %slot45, align 8
  %v5464 = load i64, ptr %slot58, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i64 %v5463, ptr %p5465, align 8, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot15, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %ld5468 = load i32, ptr %p5467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5468, ptr %slot860, align 8
  %v5469 = load i64, ptr %slot16, align 8
  %p5470 = inttoptr i64 %v5469 to ptr
  %ld5471 = load i32, ptr %p5470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5471, ptr %slot861, align 8
  %v5472 = load i32, ptr %slot861, align 8
  %op5473 = and i32 %v5472, 24
  store i32 %op5473, ptr %slot861, align 8
  %v5474 = load i32, ptr %slot861, align 8
  %cmp5475 = icmp eq i32 %v5474, 0
  %cv5476 = zext i1 %cmp5475 to i32
  store i32 %cv5476, ptr %slot862, align 8
  %v5477 = load i32, ptr %slot860, align 8
  %v5478 = load i32, ptr %slot862, align 8
  %op5479 = and i32 %v5477, %v5478
  store i32 %op5479, ptr %slot863, align 8
  %v5480 = load i32, ptr %slot863, align 8
  %cv5481 = zext i32 %v5480 to i64
  %cond5482 = icmp ne i64 %cv5481, 0
  br i1 %cond5482, label %bb_rcselfkept1123, label %bb_rcselfstore1123
bb_rcselfstore1123:
  %v5483 = load i64, ptr %slot58, align 8
  %p5484 = inttoptr i64 %v5483 to ptr
  %ld5485 = load i64, ptr %p5484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5485, ptr %slot864, align 8
  %v5486 = load i64, ptr %slot23, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  %ld5488 = load i32, ptr %p5487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5488, ptr %slot865, align 8
  %v5489 = load i64, ptr %slot24, align 8
  %p5490 = inttoptr i64 %v5489 to ptr
  %ld5491 = load i32, ptr %p5490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5491, ptr %slot866, align 8
  %v5492 = load i32, ptr %slot866, align 8
  %op5493 = and i32 %v5492, 24
  store i32 %op5493, ptr %slot866, align 8
  %v5494 = load i32, ptr %slot866, align 8
  %cmp5495 = icmp eq i32 %v5494, 0
  %cv5496 = zext i1 %cmp5495 to i32
  store i32 %cv5496, ptr %slot867, align 8
  %v5497 = load i32, ptr %slot865, align 8
  %v5498 = load i32, ptr %slot867, align 8
  %op5499 = and i32 %v5497, %v5498
  store i32 %op5499, ptr %slot868, align 8
  %v5500 = load i32, ptr %slot868, align 8
  %cv5501 = zext i32 %v5500 to i64
  %cond5502 = icmp ne i64 %cv5501, 0
  br i1 %cond5502, label %bb_rctake1125, label %bb_rccopy1125
bb_rctake1125:
  %v5503 = load i64, ptr %slot32, align 8
  store i64 %v5503, ptr %slot869, align 8
  %v5504 = load i64, ptr %slot66, align 8
  store i64 %v5504, ptr %slot870, align 8
  %v5505 = load i64, ptr %slot864, align 8
  %v5506 = load i64, ptr %slot869, align 8
  %op5507 = sub i64 %v5505, %v5506
  store i64 %op5507, ptr %slot871, align 8
  %v5508 = load i64, ptr %slot869, align 8
  %v5509 = load i64, ptr %slot864, align 8
  %op5510 = sub i64 %v5508, %v5509
  store i64 %op5510, ptr %slot872, align 8
  %v5511 = load i64, ptr %slot871, align 8
  %cmp5512 = icmp ult i64 %v5511, 48
  %cv5513 = zext i1 %cmp5512 to i32
  store i32 %cv5513, ptr %slot873, align 8
  %v5514 = load i64, ptr %slot872, align 8
  %cmp5515 = icmp ult i64 %v5514, 48
  %cv5516 = zext i1 %cmp5515 to i32
  store i32 %cv5516, ptr %slot874, align 8
  %v5517 = load i32, ptr %slot873, align 8
  %v5518 = load i32, ptr %slot874, align 8
  %op5519 = or i32 %v5517, %v5518
  store i32 %op5519, ptr %slot875, align 8
  %v5520 = load i32, ptr %slot875, align 8
  %cv5521 = zext i32 %v5520 to i64
  %cond5522 = icmp ne i64 %cv5521, 0
  br i1 %cond5522, label %bb_rcmoveslow1134, label %bb_rcmovecheck1134
bb_rcmovecheck1134:
  %v5523 = load i64, ptr %slot864, align 8
  %op5524 = add i64 %v5523, 16
  store i64 %op5524, ptr %slot876, align 8
  %v5525 = load i64, ptr %slot876, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  %ld5527 = load i64, ptr %p5526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5527, ptr %slot877, align 8
  %v5528 = load i64, ptr %slot877, align 8
  %cmp5529 = icmp ne i64 %v5528, 0
  %cv5530 = zext i1 %cmp5529 to i32
  store i32 %cv5530, ptr %slot878, align 8
  %v5531 = load i32, ptr %slot878, align 8
  %cv5532 = zext i32 %v5531 to i64
  %cond5533 = icmp ne i64 %cv5532, 0
  br i1 %cond5533, label %bb_rcmoveheader1142, label %bb_rcmovenext1142
bb_rcmoveheader1142:
  %v5534 = load i64, ptr %slot877, align 8
  %op5535 = sub i64 %v5534, 16
  store i64 %op5535, ptr %slot879, align 8
  %v5536 = load i64, ptr %slot877, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  %rgep5538 = getelementptr i8, ptr %p5537, i64 -16
  %ld5539 = load i64, ptr %rgep5538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5539, ptr %slot880, align 8
  %v5540 = load i64, ptr %slot880, align 8
  %op5541 = and i64 %v5540, 5764607523034234881
  store i64 %op5541, ptr %slot881, align 8
  %v5542 = load i64, ptr %slot881, align 8
  %cmp5543 = icmp ne i64 %v5542, 0
  %cv5544 = zext i1 %cmp5543 to i32
  store i32 %cv5544, ptr %slot882, align 8
  %v5545 = load i32, ptr %slot882, align 8
  %cv5546 = zext i32 %v5545 to i64
  %cond5547 = icmp ne i64 %cv5546, 0
  br i1 %cond5547, label %bb_rcmoveslow1134, label %bb_rcmovenext1142
bb_rcmovenext1142:
  %v5548 = load i64, ptr %slot864, align 8
  %op5549 = add i64 %v5548, 24
  store i64 %op5549, ptr %slot883, align 8
  %v5550 = load i64, ptr %slot883, align 8
  %p5551 = inttoptr i64 %v5550 to ptr
  %ld5552 = load i64, ptr %p5551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5552, ptr %slot884, align 8
  %v5553 = load i64, ptr %slot884, align 8
  %cmp5554 = icmp ne i64 %v5553, 0
  %cv5555 = zext i1 %cmp5554 to i32
  store i32 %cv5555, ptr %slot885, align 8
  %v5556 = load i32, ptr %slot885, align 8
  %cv5557 = zext i32 %v5556 to i64
  %cond5558 = icmp ne i64 %cv5557, 0
  br i1 %cond5558, label %bb_rcmoveheader1150, label %bb_rcmovenext1150
bb_rcmoveheader1150:
  %v5559 = load i64, ptr %slot884, align 8
  %op5560 = sub i64 %v5559, 16
  store i64 %op5560, ptr %slot886, align 8
  %v5561 = load i64, ptr %slot884, align 8
  %p5562 = inttoptr i64 %v5561 to ptr
  %rgep5563 = getelementptr i8, ptr %p5562, i64 -16
  %ld5564 = load i64, ptr %rgep5563, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5564, ptr %slot887, align 8
  %v5565 = load i64, ptr %slot887, align 8
  %op5566 = and i64 %v5565, 5764607523034234881
  store i64 %op5566, ptr %slot888, align 8
  %v5567 = load i64, ptr %slot888, align 8
  %cmp5568 = icmp ne i64 %v5567, 0
  %cv5569 = zext i1 %cmp5568 to i32
  store i32 %cv5569, ptr %slot889, align 8
  %v5570 = load i32, ptr %slot889, align 8
  %cv5571 = zext i32 %v5570 to i64
  %cond5572 = icmp ne i64 %cv5571, 0
  br i1 %cond5572, label %bb_rcmoveslow1134, label %bb_rcmovenext1150
bb_rcmovenext1150:
  %v5573 = load i64, ptr %slot864, align 8
  %op5574 = add i64 %v5573, 32
  store i64 %op5574, ptr %slot890, align 8
  %v5575 = load i64, ptr %slot890, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  %ld5577 = load i64, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5577, ptr %slot891, align 8
  %v5578 = load i64, ptr %slot891, align 8
  %cmp5579 = icmp ne i64 %v5578, 0
  %cv5580 = zext i1 %cmp5579 to i32
  store i32 %cv5580, ptr %slot892, align 8
  %v5581 = load i32, ptr %slot892, align 8
  %cv5582 = zext i32 %v5581 to i64
  %cond5583 = icmp ne i64 %cv5582, 0
  br i1 %cond5583, label %bb_rcmoveheader1158, label %bb_rcmovenext1158
bb_rcmoveheader1158:
  %v5584 = load i64, ptr %slot891, align 8
  %op5585 = sub i64 %v5584, 16
  store i64 %op5585, ptr %slot893, align 8
  %v5586 = load i64, ptr %slot891, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %rgep5588 = getelementptr i8, ptr %p5587, i64 -16
  %ld5589 = load i64, ptr %rgep5588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5589, ptr %slot894, align 8
  %v5590 = load i64, ptr %slot894, align 8
  %op5591 = and i64 %v5590, 5764607523034234881
  store i64 %op5591, ptr %slot895, align 8
  %v5592 = load i64, ptr %slot895, align 8
  %cmp5593 = icmp ne i64 %v5592, 0
  %cv5594 = zext i1 %cmp5593 to i32
  store i32 %cv5594, ptr %slot896, align 8
  %v5595 = load i32, ptr %slot896, align 8
  %cv5596 = zext i32 %v5595 to i64
  %cond5597 = icmp ne i64 %cv5596, 0
  br i1 %cond5597, label %bb_rcmoveslow1134, label %bb_rcmovenext1158
bb_rcmovenext1158:
  %v5598 = load i64, ptr %slot864, align 8
  %v5599 = load i64, ptr %slot869, align 8
  %p5600 = inttoptr i64 %v5598 to ptr
  %p5601 = inttoptr i64 %v5599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5601, ptr %p5600, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5602 = load i64, ptr %slot864, align 8
  %p5603 = inttoptr i64 %v5602 to ptr
  store i64 0, ptr %p5603, align 8, !alias.scope !3, !noalias !4
  %v5604 = load i64, ptr %slot864, align 8
  %op5605 = add i64 %v5604, 8
  store i64 %op5605, ptr %slot897, align 8
  %v5606 = load i64, ptr %slot897, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  store i64 0, ptr %p5607, align 8, !alias.scope !3, !noalias !4
  %v5608 = load i64, ptr %slot864, align 8
  %op5609 = add i64 %v5608, 16
  store i64 %op5609, ptr %slot898, align 8
  %v5610 = load i64, ptr %slot898, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  store i64 0, ptr %p5611, align 8, !alias.scope !3, !noalias !4
  %v5612 = load i64, ptr %slot864, align 8
  %op5613 = add i64 %v5612, 24
  store i64 %op5613, ptr %slot899, align 8
  %v5614 = load i64, ptr %slot899, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  store i64 0, ptr %p5615, align 8, !alias.scope !3, !noalias !4
  %v5616 = load i64, ptr %slot864, align 8
  %op5617 = add i64 %v5616, 32
  store i64 %op5617, ptr %slot900, align 8
  %v5618 = load i64, ptr %slot900, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  store i64 0, ptr %p5619, align 8, !alias.scope !3, !noalias !4
  %v5620 = load i64, ptr %slot864, align 8
  %op5621 = add i64 %v5620, 40
  store i64 %op5621, ptr %slot901, align 8
  %v5622 = load i64, ptr %slot901, align 8
  %p5623 = inttoptr i64 %v5622 to ptr
  store i64 0, ptr %p5623, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1134
bb_rcmoveslow1134:
  %v5624 = load i64, ptr %slot65, align 8
  %v5625 = load i64, ptr %slot869, align 8
  %v5626 = load i64, ptr %slot864, align 8
  %v5627 = load i64, ptr %slot870, align 8
  %cv5628 = trunc i64 %v5627 to i32
  %call5629 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v5624, i64 %v5625, i64 %v5626, i32 %cv5628) nomerge, !dbg !174
  store i32 %call5629, ptr %slot902, align 8
  %v5630 = load i32, ptr %slot902, align 8
  %cv5631 = zext i32 %v5630 to i64
  %cond5632 = icmp ne i64 %cv5631, 0
  br i1 %cond5632, label %bb_rcsuccess1170, label %bb_rcfailure1170
bb_rcfailure1170:
  %v5633 = load i64, ptr %slot65, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  %call5635 = call i32 @myl_rc_take_failure(ptr %p5634) nomerge, !dbg !174
  store i32 %call5635, ptr %slot903, align 8
  %v5636 = load i64, ptr %slot1, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  %v5638 = load i32, ptr %slot903, align 8
  %call5639 = call i32 @myl_qbe_rc_status(ptr %p5637, i32 %v5638) nomerge, !dbg !174
  store i32 %call5639, ptr %slot904, align 8
  br label %bb_failure
bb_rcsuccess1170:
  br label %bb_rcmoved1134
bb_rcmoved1134:
  %v5640 = load i64, ptr %slot23, align 8
  %p5641 = inttoptr i64 %v5640 to ptr
  store i32 0, ptr %p5641, align 4, !alias.scope !3, !noalias !4
  %v5642 = load i64, ptr %slot28, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  store i32 2, ptr %p5643, align 4, !alias.scope !3, !noalias !4
  %v5644 = load i64, ptr %slot27, align 8
  %p5645 = inttoptr i64 %v5644 to ptr
  store i32 1, ptr %p5645, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1125
bb_rccopy1125:
  %v5646 = load i64, ptr %slot32, align 8
  store i64 %v5646, ptr %slot905, align 8
  %v5647 = load i64, ptr %slot66, align 8
  store i64 %v5647, ptr %slot906, align 8
  %v5648 = load i64, ptr %slot65, align 8
  %v5649 = load i64, ptr %slot905, align 8
  %v5650 = load i64, ptr %slot864, align 8
  %v5651 = load i64, ptr %slot906, align 8
  %cv5652 = trunc i64 %v5651 to i32
  %call5653 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v5648, i64 %v5649, i64 %v5650, i32 %cv5652) nomerge, !dbg !174
  store i32 %call5653, ptr %slot907, align 8
  %v5654 = load i32, ptr %slot907, align 8
  %cv5655 = zext i32 %v5654 to i64
  %cond5656 = icmp ne i64 %cv5655, 0
  br i1 %cond5656, label %bb_rcsuccess1179, label %bb_rcfailure1179
bb_rcfailure1179:
  %v5657 = load i64, ptr %slot65, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  %call5659 = call i32 @myl_rc_take_failure(ptr %p5658) nomerge, !dbg !174
  store i32 %call5659, ptr %slot908, align 8
  %v5660 = load i64, ptr %slot1, align 8
  %p5661 = inttoptr i64 %v5660 to ptr
  %v5662 = load i32, ptr %slot908, align 8
  %call5663 = call i32 @myl_qbe_rc_status(ptr %p5661, i32 %v5662) nomerge, !dbg !174
  store i32 %call5663, ptr %slot909, align 8
  br label %bb_failure
bb_rcsuccess1179:
  %v5664 = load i64, ptr %slot28, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  store i32 2, ptr %p5665, align 4, !alias.scope !3, !noalias !4
  %v5666 = load i64, ptr %slot27, align 8
  %p5667 = inttoptr i64 %v5666 to ptr
  store i32 1, ptr %p5667, align 4, !alias.scope !3, !noalias !4
  %v5668 = load i64, ptr %slot23, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  %ld5670 = load i32, ptr %p5669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5670, ptr %slot910, align 8
  %v5671 = load i32, ptr %slot910, align 8
  %cv5672 = zext i32 %v5671 to i64
  %cond5673 = icmp ne i64 %cv5672, 0
  br i1 %cond5673, label %bb_rcslotdrop1186, label %bb_rcslotdone1186
bb_rcslotdrop1186:
  %v5674 = load i64, ptr %slot23, align 8
  %p5675 = inttoptr i64 %v5674 to ptr
  store i32 0, ptr %p5675, align 4, !alias.scope !3, !noalias !4
  %v5676 = load i64, ptr %slot29, align 8
  store i64 %v5676, ptr %slot911, align 8
  %v5677 = load i64, ptr %slot24, align 8
  %p5678 = inttoptr i64 %v5677 to ptr
  %ld5679 = load i32, ptr %p5678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5679, ptr %slot912, align 8
  %v5680 = load i32, ptr %slot912, align 8
  %op5681 = and i32 %v5680, 28
  store i32 %op5681, ptr %slot913, align 8
  %v5682 = load i32, ptr %slot913, align 8
  %cv5683 = zext i32 %v5682 to i64
  %cond5684 = icmp ne i64 %cv5683, 0
  br i1 %cond5684, label %bb_rcslotrole1186, label %bb_rcslotowner1186
bb_rcslotrole1186:
  %v5685 = load i64, ptr %slot65, align 8
  store i64 %v5685, ptr %slot914, align 8
  %v5686 = load i64, ptr %slot914, align 8
  %v5687 = load i64, ptr %slot911, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v5686, i64 %v5687) nomerge, !dbg !174
  br label %bb_rcslotdone1186
bb_rcslotowner1186:
  %v5688 = load i64, ptr %slot911, align 8
  %p5690 = inttoptr i64 %v5688 to ptr
  %gep5691 = getelementptr i8, ptr %p5690, i64 16
  %op5689 = ptrtoint ptr %gep5691 to i64
  store i64 %op5689, ptr %slot915, align 8
  %v5692 = load i64, ptr %slot65, align 8
  store i64 %v5692, ptr %slot916, align 8
  %v5693 = load i64, ptr %slot915, align 8
  %p5694 = inttoptr i64 %v5693 to ptr
  %ld5695 = load i64, ptr %p5694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5695, ptr %slot917, align 8
  %v5696 = load i64, ptr %slot917, align 8
  %cmp5697 = icmp ne i64 %v5696, 0
  %cv5698 = zext i1 %cmp5697 to i32
  store i32 %cv5698, ptr %slot918, align 8
  %v5699 = load i32, ptr %slot918, align 8
  %cv5700 = zext i32 %v5699 to i64
  %cond5701 = icmp ne i64 %cv5700, 0
  br i1 %cond5701, label %bb_rcgnn1204, label %bb_rcgdone1204
bb_rcgnn1204:
  %v5702 = load i64, ptr %slot917, align 8
  %op5703 = sub i64 %v5702, 16
  store i64 %op5703, ptr %slot919, align 8
  %v5704 = load i64, ptr %slot917, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  %rgep5706 = getelementptr i8, ptr %p5705, i64 -16
  %ld5707 = load i64, ptr %rgep5706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5707, ptr %slot920, align 8
  %v5708 = load i64, ptr %slot920, align 8
  %op5709 = and i64 %v5708, 4611686018427387906
  store i64 %op5709, ptr %slot921, align 8
  %v5710 = load i64, ptr %slot921, align 8
  %cmp5711 = icmp ne i64 %v5710, 0
  %cv5712 = zext i1 %cmp5711 to i32
  store i32 %cv5712, ptr %slot922, align 8
  %v5713 = load i32, ptr %slot922, align 8
  %cv5714 = zext i32 %v5713 to i64
  %cond5715 = icmp ne i64 %cv5714, 0
  br i1 %cond5715, label %bb_rcgclear1204, label %bb_rcgcounted1204
bb_rcgcounted1204:
  %v5716 = load i64, ptr %slot917, align 8
  %op5717 = sub i64 %v5716, 32
  store i64 %op5717, ptr %slot923, align 8
  %v5718 = load i64, ptr %slot917, align 8
  %p5719 = inttoptr i64 %v5718 to ptr
  %rgep5720 = getelementptr i8, ptr %p5719, i64 -32
  %ld5721 = load i64, ptr %rgep5720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5721, ptr %slot924, align 8
  %v5722 = load i64, ptr %slot924, align 8
  %op5723 = sub i64 %v5722, 1
  store i64 %op5723, ptr %slot925, align 8
  %v5724 = load i64, ptr %slot925, align 8
  %cmp5725 = icmp eq i64 %v5724, 0
  %cv5726 = zext i1 %cmp5725 to i32
  store i32 %cv5726, ptr %slot926, align 8
  %v5727 = load i32, ptr %slot926, align 8
  %cv5728 = zext i32 %v5727 to i64
  %cond5729 = icmp ne i64 %cv5728, 0
  br i1 %cond5729, label %bb_rcglast1204, label %bb_rcgdec1204
bb_rcglast1204:
  %v5730 = load i64, ptr %slot917, align 8
  %op5731 = sub i64 %v5730, 24
  store i64 %op5731, ptr %slot927, align 8
  %v5732 = load i64, ptr %slot917, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  %rgep5734 = getelementptr i8, ptr %p5733, i64 -24
  %ld5735 = load i64, ptr %rgep5734, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5735, ptr %slot928, align 8
  %v5736 = load i64, ptr %slot928, align 8
  %cmp5737 = icmp ne i64 %v5736, 0
  %cv5738 = zext i1 %cmp5737 to i32
  store i32 %cv5738, ptr %slot929, align 8
  %v5739 = load i32, ptr %slot929, align 8
  %cv5740 = zext i32 %v5739 to i64
  %cond5741 = icmp ne i64 %cv5740, 0
  br i1 %cond5741, label %bb_rcgdec1204, label %bb_rcgslow1204
bb_rcgslow1204:
  %v5742 = load i64, ptr %slot916, align 8
  %v5743 = load i64, ptr %slot915, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5742, i64 %v5743) nomerge, !dbg !174
  br label %bb_rcgdone1204
bb_rcgdec1204:
  %v5744 = load i64, ptr %slot925, align 8
  %v5745 = load i64, ptr %slot917, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %rgep5747 = getelementptr i8, ptr %p5746, i64 -32
  store i64 %v5744, ptr %rgep5747, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1204
bb_rcgclear1204:
  %v5748 = load i64, ptr %slot915, align 8
  %p5749 = inttoptr i64 %v5748 to ptr
  store i64 0, ptr %p5749, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1204
bb_rcgdone1204:
  %v5750 = load i64, ptr %slot911, align 8
  %p5752 = inttoptr i64 %v5750 to ptr
  %gep5753 = getelementptr i8, ptr %p5752, i64 24
  %op5751 = ptrtoint ptr %gep5753 to i64
  store i64 %op5751, ptr %slot930, align 8
  %v5754 = load i64, ptr %slot65, align 8
  store i64 %v5754, ptr %slot931, align 8
  %v5755 = load i64, ptr %slot930, align 8
  %p5756 = inttoptr i64 %v5755 to ptr
  %ld5757 = load i64, ptr %p5756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5757, ptr %slot932, align 8
  %v5758 = load i64, ptr %slot932, align 8
  %cmp5759 = icmp ne i64 %v5758, 0
  %cv5760 = zext i1 %cmp5759 to i32
  store i32 %cv5760, ptr %slot933, align 8
  %v5761 = load i32, ptr %slot933, align 8
  %cv5762 = zext i32 %v5761 to i64
  %cond5763 = icmp ne i64 %cv5762, 0
  br i1 %cond5763, label %bb_rcgnn1220, label %bb_rcgdone1220
bb_rcgnn1220:
  %v5764 = load i64, ptr %slot932, align 8
  %op5765 = sub i64 %v5764, 16
  store i64 %op5765, ptr %slot934, align 8
  %v5766 = load i64, ptr %slot932, align 8
  %p5767 = inttoptr i64 %v5766 to ptr
  %rgep5768 = getelementptr i8, ptr %p5767, i64 -16
  %ld5769 = load i64, ptr %rgep5768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5769, ptr %slot935, align 8
  %v5770 = load i64, ptr %slot935, align 8
  %op5771 = and i64 %v5770, 4611686018427387906
  store i64 %op5771, ptr %slot936, align 8
  %v5772 = load i64, ptr %slot936, align 8
  %cmp5773 = icmp ne i64 %v5772, 0
  %cv5774 = zext i1 %cmp5773 to i32
  store i32 %cv5774, ptr %slot937, align 8
  %v5775 = load i32, ptr %slot937, align 8
  %cv5776 = zext i32 %v5775 to i64
  %cond5777 = icmp ne i64 %cv5776, 0
  br i1 %cond5777, label %bb_rcgclear1220, label %bb_rcgcounted1220
bb_rcgcounted1220:
  %v5778 = load i64, ptr %slot932, align 8
  %op5779 = sub i64 %v5778, 32
  store i64 %op5779, ptr %slot938, align 8
  %v5780 = load i64, ptr %slot932, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  %rgep5782 = getelementptr i8, ptr %p5781, i64 -32
  %ld5783 = load i64, ptr %rgep5782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5783, ptr %slot939, align 8
  %v5784 = load i64, ptr %slot939, align 8
  %op5785 = sub i64 %v5784, 1
  store i64 %op5785, ptr %slot940, align 8
  %v5786 = load i64, ptr %slot940, align 8
  %cmp5787 = icmp eq i64 %v5786, 0
  %cv5788 = zext i1 %cmp5787 to i32
  store i32 %cv5788, ptr %slot941, align 8
  %v5789 = load i32, ptr %slot941, align 8
  %cv5790 = zext i32 %v5789 to i64
  %cond5791 = icmp ne i64 %cv5790, 0
  br i1 %cond5791, label %bb_rcglast1220, label %bb_rcgdec1220
bb_rcglast1220:
  %v5792 = load i64, ptr %slot932, align 8
  %op5793 = sub i64 %v5792, 24
  store i64 %op5793, ptr %slot942, align 8
  %v5794 = load i64, ptr %slot932, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  %rgep5796 = getelementptr i8, ptr %p5795, i64 -24
  %ld5797 = load i64, ptr %rgep5796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5797, ptr %slot943, align 8
  %v5798 = load i64, ptr %slot943, align 8
  %cmp5799 = icmp ne i64 %v5798, 0
  %cv5800 = zext i1 %cmp5799 to i32
  store i32 %cv5800, ptr %slot944, align 8
  %v5801 = load i32, ptr %slot944, align 8
  %cv5802 = zext i32 %v5801 to i64
  %cond5803 = icmp ne i64 %cv5802, 0
  br i1 %cond5803, label %bb_rcgdec1220, label %bb_rcgslow1220
bb_rcgslow1220:
  %v5804 = load i64, ptr %slot931, align 8
  %v5805 = load i64, ptr %slot930, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5804, i64 %v5805) nomerge, !dbg !174
  br label %bb_rcgdone1220
bb_rcgdec1220:
  %v5806 = load i64, ptr %slot940, align 8
  %v5807 = load i64, ptr %slot932, align 8
  %p5808 = inttoptr i64 %v5807 to ptr
  %rgep5809 = getelementptr i8, ptr %p5808, i64 -32
  store i64 %v5806, ptr %rgep5809, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1220
bb_rcgclear1220:
  %v5810 = load i64, ptr %slot930, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  store i64 0, ptr %p5811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1220
bb_rcgdone1220:
  %v5812 = load i64, ptr %slot911, align 8
  %p5814 = inttoptr i64 %v5812 to ptr
  %gep5815 = getelementptr i8, ptr %p5814, i64 32
  %op5813 = ptrtoint ptr %gep5815 to i64
  store i64 %op5813, ptr %slot945, align 8
  %v5816 = load i64, ptr %slot65, align 8
  store i64 %v5816, ptr %slot946, align 8
  %v5817 = load i64, ptr %slot945, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  %ld5819 = load i64, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5819, ptr %slot947, align 8
  %v5820 = load i64, ptr %slot947, align 8
  %cmp5821 = icmp ne i64 %v5820, 0
  %cv5822 = zext i1 %cmp5821 to i32
  store i32 %cv5822, ptr %slot948, align 8
  %v5823 = load i32, ptr %slot948, align 8
  %cv5824 = zext i32 %v5823 to i64
  %cond5825 = icmp ne i64 %cv5824, 0
  br i1 %cond5825, label %bb_rcgnn1236, label %bb_rcgdone1236
bb_rcgnn1236:
  %v5826 = load i64, ptr %slot947, align 8
  %op5827 = sub i64 %v5826, 16
  store i64 %op5827, ptr %slot949, align 8
  %v5828 = load i64, ptr %slot947, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  %rgep5830 = getelementptr i8, ptr %p5829, i64 -16
  %ld5831 = load i64, ptr %rgep5830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5831, ptr %slot950, align 8
  %v5832 = load i64, ptr %slot950, align 8
  %op5833 = and i64 %v5832, 4611686018427387906
  store i64 %op5833, ptr %slot951, align 8
  %v5834 = load i64, ptr %slot951, align 8
  %cmp5835 = icmp ne i64 %v5834, 0
  %cv5836 = zext i1 %cmp5835 to i32
  store i32 %cv5836, ptr %slot952, align 8
  %v5837 = load i32, ptr %slot952, align 8
  %cv5838 = zext i32 %v5837 to i64
  %cond5839 = icmp ne i64 %cv5838, 0
  br i1 %cond5839, label %bb_rcgclear1236, label %bb_rcgcounted1236
bb_rcgcounted1236:
  %v5840 = load i64, ptr %slot947, align 8
  %op5841 = sub i64 %v5840, 32
  store i64 %op5841, ptr %slot953, align 8
  %v5842 = load i64, ptr %slot947, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  %rgep5844 = getelementptr i8, ptr %p5843, i64 -32
  %ld5845 = load i64, ptr %rgep5844, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5845, ptr %slot954, align 8
  %v5846 = load i64, ptr %slot954, align 8
  %op5847 = sub i64 %v5846, 1
  store i64 %op5847, ptr %slot955, align 8
  %v5848 = load i64, ptr %slot955, align 8
  %cmp5849 = icmp eq i64 %v5848, 0
  %cv5850 = zext i1 %cmp5849 to i32
  store i32 %cv5850, ptr %slot956, align 8
  %v5851 = load i32, ptr %slot956, align 8
  %cv5852 = zext i32 %v5851 to i64
  %cond5853 = icmp ne i64 %cv5852, 0
  br i1 %cond5853, label %bb_rcglast1236, label %bb_rcgdec1236
bb_rcglast1236:
  %v5854 = load i64, ptr %slot947, align 8
  %op5855 = sub i64 %v5854, 24
  store i64 %op5855, ptr %slot957, align 8
  %v5856 = load i64, ptr %slot947, align 8
  %p5857 = inttoptr i64 %v5856 to ptr
  %rgep5858 = getelementptr i8, ptr %p5857, i64 -24
  %ld5859 = load i64, ptr %rgep5858, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5859, ptr %slot958, align 8
  %v5860 = load i64, ptr %slot958, align 8
  %cmp5861 = icmp ne i64 %v5860, 0
  %cv5862 = zext i1 %cmp5861 to i32
  store i32 %cv5862, ptr %slot959, align 8
  %v5863 = load i32, ptr %slot959, align 8
  %cv5864 = zext i32 %v5863 to i64
  %cond5865 = icmp ne i64 %cv5864, 0
  br i1 %cond5865, label %bb_rcgdec1236, label %bb_rcgslow1236
bb_rcgslow1236:
  %v5866 = load i64, ptr %slot946, align 8
  %v5867 = load i64, ptr %slot945, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v5866, i64 %v5867) nomerge, !dbg !174
  br label %bb_rcgdone1236
bb_rcgdec1236:
  %v5868 = load i64, ptr %slot955, align 8
  %v5869 = load i64, ptr %slot947, align 8
  %p5870 = inttoptr i64 %v5869 to ptr
  %rgep5871 = getelementptr i8, ptr %p5870, i64 -32
  store i64 %v5868, ptr %rgep5871, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1236
bb_rcgclear1236:
  %v5872 = load i64, ptr %slot945, align 8
  %p5873 = inttoptr i64 %v5872 to ptr
  store i64 0, ptr %p5873, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1236
bb_rcgdone1236:
  %v5874 = load i64, ptr %slot911, align 8
  %p5875 = inttoptr i64 %v5874 to ptr
  store i64 0, ptr %p5875, align 8, !alias.scope !3, !noalias !4
  %v5876 = load i64, ptr %slot911, align 8
  %p5878 = inttoptr i64 %v5876 to ptr
  %gep5879 = getelementptr i8, ptr %p5878, i64 8
  %op5877 = ptrtoint ptr %gep5879 to i64
  store i64 %op5877, ptr %slot960, align 8
  %v5880 = load i64, ptr %slot960, align 8
  %p5881 = inttoptr i64 %v5880 to ptr
  store i64 0, ptr %p5881, align 8, !alias.scope !3, !noalias !4
  %v5882 = load i64, ptr %slot911, align 8
  %p5884 = inttoptr i64 %v5882 to ptr
  %gep5885 = getelementptr i8, ptr %p5884, i64 16
  %op5883 = ptrtoint ptr %gep5885 to i64
  store i64 %op5883, ptr %slot961, align 8
  %v5886 = load i64, ptr %slot961, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  store i64 0, ptr %p5887, align 8, !alias.scope !3, !noalias !4
  %v5888 = load i64, ptr %slot911, align 8
  %p5890 = inttoptr i64 %v5888 to ptr
  %gep5891 = getelementptr i8, ptr %p5890, i64 24
  %op5889 = ptrtoint ptr %gep5891 to i64
  store i64 %op5889, ptr %slot962, align 8
  %v5892 = load i64, ptr %slot962, align 8
  %p5893 = inttoptr i64 %v5892 to ptr
  store i64 0, ptr %p5893, align 8, !alias.scope !3, !noalias !4
  %v5894 = load i64, ptr %slot911, align 8
  %p5896 = inttoptr i64 %v5894 to ptr
  %gep5897 = getelementptr i8, ptr %p5896, i64 32
  %op5895 = ptrtoint ptr %gep5897 to i64
  store i64 %op5895, ptr %slot963, align 8
  %v5898 = load i64, ptr %slot963, align 8
  %p5899 = inttoptr i64 %v5898 to ptr
  store i64 0, ptr %p5899, align 8, !alias.scope !3, !noalias !4
  %v5900 = load i64, ptr %slot911, align 8
  %p5902 = inttoptr i64 %v5900 to ptr
  %gep5903 = getelementptr i8, ptr %p5902, i64 40
  %op5901 = ptrtoint ptr %gep5903 to i64
  store i64 %op5901, ptr %slot964, align 8
  %v5904 = load i64, ptr %slot964, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  store i64 0, ptr %p5905, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1186
bb_rcslotdone1186:
  br label %bb_rcprepared1125
bb_rcprepared1125:
  %v5906 = load i64, ptr %slot15, align 8
  %p5907 = inttoptr i64 %v5906 to ptr
  %ld5908 = load i32, ptr %p5907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5908, ptr %slot965, align 8
  %v5909 = load i32, ptr %slot965, align 8
  %cv5910 = zext i32 %v5909 to i64
  %cond5911 = icmp ne i64 %cv5910, 0
  br i1 %cond5911, label %bb_rcslotdrop1248, label %bb_rcslotdone1248
bb_rcslotdrop1248:
  %v5912 = load i64, ptr %slot15, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  store i32 0, ptr %p5913, align 4, !alias.scope !3, !noalias !4
  %v5914 = load i64, ptr %slot45, align 8
  store i64 %v5914, ptr %slot966, align 8
  %v5915 = load i64, ptr %slot16, align 8
  %p5916 = inttoptr i64 %v5915 to ptr
  %ld5917 = load i32, ptr %p5916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5917, ptr %slot967, align 8
  %v5918 = load i32, ptr %slot967, align 8
  %op5919 = and i32 %v5918, 28
  store i32 %op5919, ptr %slot968, align 8
  %v5920 = load i32, ptr %slot968, align 8
  %cv5921 = zext i32 %v5920 to i64
  %cond5922 = icmp ne i64 %cv5921, 0
  br i1 %cond5922, label %bb_rcslotrole1248, label %bb_rcslotowner1248
bb_rcslotrole1248:
  %v5923 = load i64, ptr %slot65, align 8
  store i64 %v5923, ptr %slot969, align 8
  %v5924 = load i64, ptr %slot969, align 8
  %v5925 = load i64, ptr %slot966, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v5924, i64 %v5925) nomerge, !dbg !174
  br label %bb_rcslotdone1248
bb_rcslotowner1248:
  %v5926 = load i64, ptr %slot966, align 8
  %p5928 = inttoptr i64 %v5926 to ptr
  %gep5929 = getelementptr i8, ptr %p5928, i64 16
  %op5927 = ptrtoint ptr %gep5929 to i64
  store i64 %op5927, ptr %slot970, align 8
  %v5930 = load i64, ptr %slot65, align 8
  store i64 %v5930, ptr %slot971, align 8
  %v5931 = load i64, ptr %slot970, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  %ld5933 = load i64, ptr %p5932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5933, ptr %slot972, align 8
  %v5934 = load i64, ptr %slot972, align 8
  %cmp5935 = icmp ne i64 %v5934, 0
  %cv5936 = zext i1 %cmp5935 to i32
  store i32 %cv5936, ptr %slot973, align 8
  %v5937 = load i32, ptr %slot973, align 8
  %cv5938 = zext i32 %v5937 to i64
  %cond5939 = icmp ne i64 %cv5938, 0
  br i1 %cond5939, label %bb_rcgnn1266, label %bb_rcgdone1266
bb_rcgnn1266:
  %v5940 = load i64, ptr %slot972, align 8
  %op5941 = sub i64 %v5940, 16
  store i64 %op5941, ptr %slot974, align 8
  %v5942 = load i64, ptr %slot972, align 8
  %p5943 = inttoptr i64 %v5942 to ptr
  %rgep5944 = getelementptr i8, ptr %p5943, i64 -16
  %ld5945 = load i64, ptr %rgep5944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5945, ptr %slot975, align 8
  %v5946 = load i64, ptr %slot975, align 8
  %op5947 = and i64 %v5946, 4611686018427387906
  store i64 %op5947, ptr %slot976, align 8
  %v5948 = load i64, ptr %slot976, align 8
  %cmp5949 = icmp ne i64 %v5948, 0
  %cv5950 = zext i1 %cmp5949 to i32
  store i32 %cv5950, ptr %slot977, align 8
  %v5951 = load i32, ptr %slot977, align 8
  %cv5952 = zext i32 %v5951 to i64
  %cond5953 = icmp ne i64 %cv5952, 0
  br i1 %cond5953, label %bb_rcgclear1266, label %bb_rcgcounted1266
bb_rcgcounted1266:
  %v5954 = load i64, ptr %slot972, align 8
  %op5955 = sub i64 %v5954, 32
  store i64 %op5955, ptr %slot978, align 8
  %v5956 = load i64, ptr %slot972, align 8
  %p5957 = inttoptr i64 %v5956 to ptr
  %rgep5958 = getelementptr i8, ptr %p5957, i64 -32
  %ld5959 = load i64, ptr %rgep5958, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5959, ptr %slot979, align 8
  %v5960 = load i64, ptr %slot979, align 8
  %op5961 = sub i64 %v5960, 1
  store i64 %op5961, ptr %slot980, align 8
  %v5962 = load i64, ptr %slot980, align 8
  %cmp5963 = icmp eq i64 %v5962, 0
  %cv5964 = zext i1 %cmp5963 to i32
  store i32 %cv5964, ptr %slot981, align 8
  %v5965 = load i32, ptr %slot981, align 8
  %cv5966 = zext i32 %v5965 to i64
  %cond5967 = icmp ne i64 %cv5966, 0
  br i1 %cond5967, label %bb_rcglast1266, label %bb_rcgdec1266
bb_rcglast1266:
  %v5968 = load i64, ptr %slot972, align 8
  %op5969 = sub i64 %v5968, 24
  store i64 %op5969, ptr %slot982, align 8
  %v5970 = load i64, ptr %slot972, align 8
  %p5971 = inttoptr i64 %v5970 to ptr
  %rgep5972 = getelementptr i8, ptr %p5971, i64 -24
  %ld5973 = load i64, ptr %rgep5972, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5973, ptr %slot983, align 8
  %v5974 = load i64, ptr %slot983, align 8
  %cmp5975 = icmp ne i64 %v5974, 0
  %cv5976 = zext i1 %cmp5975 to i32
  store i32 %cv5976, ptr %slot984, align 8
  %v5977 = load i32, ptr %slot984, align 8
  %cv5978 = zext i32 %v5977 to i64
  %cond5979 = icmp ne i64 %cv5978, 0
  br i1 %cond5979, label %bb_rcgdec1266, label %bb_rcgslow1266
bb_rcgslow1266:
  %v5980 = load i64, ptr %slot971, align 8
  %v5981 = load i64, ptr %slot970, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5980, i64 %v5981) nomerge, !dbg !174
  br label %bb_rcgdone1266
bb_rcgdec1266:
  %v5982 = load i64, ptr %slot980, align 8
  %v5983 = load i64, ptr %slot972, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %rgep5985 = getelementptr i8, ptr %p5984, i64 -32
  store i64 %v5982, ptr %rgep5985, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1266
bb_rcgclear1266:
  %v5986 = load i64, ptr %slot970, align 8
  %p5987 = inttoptr i64 %v5986 to ptr
  store i64 0, ptr %p5987, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1266
bb_rcgdone1266:
  %v5988 = load i64, ptr %slot966, align 8
  %p5990 = inttoptr i64 %v5988 to ptr
  %gep5991 = getelementptr i8, ptr %p5990, i64 24
  %op5989 = ptrtoint ptr %gep5991 to i64
  store i64 %op5989, ptr %slot985, align 8
  %v5992 = load i64, ptr %slot65, align 8
  store i64 %v5992, ptr %slot986, align 8
  %v5993 = load i64, ptr %slot985, align 8
  %p5994 = inttoptr i64 %v5993 to ptr
  %ld5995 = load i64, ptr %p5994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5995, ptr %slot987, align 8
  %v5996 = load i64, ptr %slot987, align 8
  %cmp5997 = icmp ne i64 %v5996, 0
  %cv5998 = zext i1 %cmp5997 to i32
  store i32 %cv5998, ptr %slot988, align 8
  %v5999 = load i32, ptr %slot988, align 8
  %cv6000 = zext i32 %v5999 to i64
  %cond6001 = icmp ne i64 %cv6000, 0
  br i1 %cond6001, label %bb_rcgnn1282, label %bb_rcgdone1282
bb_rcgnn1282:
  %v6002 = load i64, ptr %slot987, align 8
  %op6003 = sub i64 %v6002, 16
  store i64 %op6003, ptr %slot989, align 8
  %v6004 = load i64, ptr %slot987, align 8
  %p6005 = inttoptr i64 %v6004 to ptr
  %rgep6006 = getelementptr i8, ptr %p6005, i64 -16
  %ld6007 = load i64, ptr %rgep6006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6007, ptr %slot990, align 8
  %v6008 = load i64, ptr %slot990, align 8
  %op6009 = and i64 %v6008, 4611686018427387906
  store i64 %op6009, ptr %slot991, align 8
  %v6010 = load i64, ptr %slot991, align 8
  %cmp6011 = icmp ne i64 %v6010, 0
  %cv6012 = zext i1 %cmp6011 to i32
  store i32 %cv6012, ptr %slot992, align 8
  %v6013 = load i32, ptr %slot992, align 8
  %cv6014 = zext i32 %v6013 to i64
  %cond6015 = icmp ne i64 %cv6014, 0
  br i1 %cond6015, label %bb_rcgclear1282, label %bb_rcgcounted1282
bb_rcgcounted1282:
  %v6016 = load i64, ptr %slot987, align 8
  %op6017 = sub i64 %v6016, 32
  store i64 %op6017, ptr %slot993, align 8
  %v6018 = load i64, ptr %slot987, align 8
  %p6019 = inttoptr i64 %v6018 to ptr
  %rgep6020 = getelementptr i8, ptr %p6019, i64 -32
  %ld6021 = load i64, ptr %rgep6020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6021, ptr %slot994, align 8
  %v6022 = load i64, ptr %slot994, align 8
  %op6023 = sub i64 %v6022, 1
  store i64 %op6023, ptr %slot995, align 8
  %v6024 = load i64, ptr %slot995, align 8
  %cmp6025 = icmp eq i64 %v6024, 0
  %cv6026 = zext i1 %cmp6025 to i32
  store i32 %cv6026, ptr %slot996, align 8
  %v6027 = load i32, ptr %slot996, align 8
  %cv6028 = zext i32 %v6027 to i64
  %cond6029 = icmp ne i64 %cv6028, 0
  br i1 %cond6029, label %bb_rcglast1282, label %bb_rcgdec1282
bb_rcglast1282:
  %v6030 = load i64, ptr %slot987, align 8
  %op6031 = sub i64 %v6030, 24
  store i64 %op6031, ptr %slot997, align 8
  %v6032 = load i64, ptr %slot987, align 8
  %p6033 = inttoptr i64 %v6032 to ptr
  %rgep6034 = getelementptr i8, ptr %p6033, i64 -24
  %ld6035 = load i64, ptr %rgep6034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6035, ptr %slot998, align 8
  %v6036 = load i64, ptr %slot998, align 8
  %cmp6037 = icmp ne i64 %v6036, 0
  %cv6038 = zext i1 %cmp6037 to i32
  store i32 %cv6038, ptr %slot999, align 8
  %v6039 = load i32, ptr %slot999, align 8
  %cv6040 = zext i32 %v6039 to i64
  %cond6041 = icmp ne i64 %cv6040, 0
  br i1 %cond6041, label %bb_rcgdec1282, label %bb_rcgslow1282
bb_rcgslow1282:
  %v6042 = load i64, ptr %slot986, align 8
  %v6043 = load i64, ptr %slot985, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v6042, i64 %v6043) nomerge, !dbg !174
  br label %bb_rcgdone1282
bb_rcgdec1282:
  %v6044 = load i64, ptr %slot995, align 8
  %v6045 = load i64, ptr %slot987, align 8
  %p6046 = inttoptr i64 %v6045 to ptr
  %rgep6047 = getelementptr i8, ptr %p6046, i64 -32
  store i64 %v6044, ptr %rgep6047, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1282
bb_rcgclear1282:
  %v6048 = load i64, ptr %slot985, align 8
  %p6049 = inttoptr i64 %v6048 to ptr
  store i64 0, ptr %p6049, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1282
bb_rcgdone1282:
  %v6050 = load i64, ptr %slot966, align 8
  %p6052 = inttoptr i64 %v6050 to ptr
  %gep6053 = getelementptr i8, ptr %p6052, i64 32
  %op6051 = ptrtoint ptr %gep6053 to i64
  store i64 %op6051, ptr %slot1000, align 8
  %v6054 = load i64, ptr %slot65, align 8
  store i64 %v6054, ptr %slot1001, align 8
  %v6055 = load i64, ptr %slot1000, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  %ld6057 = load i64, ptr %p6056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6057, ptr %slot1002, align 8
  %v6058 = load i64, ptr %slot1002, align 8
  %cmp6059 = icmp ne i64 %v6058, 0
  %cv6060 = zext i1 %cmp6059 to i32
  store i32 %cv6060, ptr %slot1003, align 8
  %v6061 = load i32, ptr %slot1003, align 8
  %cv6062 = zext i32 %v6061 to i64
  %cond6063 = icmp ne i64 %cv6062, 0
  br i1 %cond6063, label %bb_rcgnn1298, label %bb_rcgdone1298
bb_rcgnn1298:
  %v6064 = load i64, ptr %slot1002, align 8
  %op6065 = sub i64 %v6064, 16
  store i64 %op6065, ptr %slot1004, align 8
  %v6066 = load i64, ptr %slot1002, align 8
  %p6067 = inttoptr i64 %v6066 to ptr
  %rgep6068 = getelementptr i8, ptr %p6067, i64 -16
  %ld6069 = load i64, ptr %rgep6068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6069, ptr %slot1005, align 8
  %v6070 = load i64, ptr %slot1005, align 8
  %op6071 = and i64 %v6070, 4611686018427387906
  store i64 %op6071, ptr %slot1006, align 8
  %v6072 = load i64, ptr %slot1006, align 8
  %cmp6073 = icmp ne i64 %v6072, 0
  %cv6074 = zext i1 %cmp6073 to i32
  store i32 %cv6074, ptr %slot1007, align 8
  %v6075 = load i32, ptr %slot1007, align 8
  %cv6076 = zext i32 %v6075 to i64
  %cond6077 = icmp ne i64 %cv6076, 0
  br i1 %cond6077, label %bb_rcgclear1298, label %bb_rcgcounted1298
bb_rcgcounted1298:
  %v6078 = load i64, ptr %slot1002, align 8
  %op6079 = sub i64 %v6078, 32
  store i64 %op6079, ptr %slot1008, align 8
  %v6080 = load i64, ptr %slot1002, align 8
  %p6081 = inttoptr i64 %v6080 to ptr
  %rgep6082 = getelementptr i8, ptr %p6081, i64 -32
  %ld6083 = load i64, ptr %rgep6082, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6083, ptr %slot1009, align 8
  %v6084 = load i64, ptr %slot1009, align 8
  %op6085 = sub i64 %v6084, 1
  store i64 %op6085, ptr %slot1010, align 8
  %v6086 = load i64, ptr %slot1010, align 8
  %cmp6087 = icmp eq i64 %v6086, 0
  %cv6088 = zext i1 %cmp6087 to i32
  store i32 %cv6088, ptr %slot1011, align 8
  %v6089 = load i32, ptr %slot1011, align 8
  %cv6090 = zext i32 %v6089 to i64
  %cond6091 = icmp ne i64 %cv6090, 0
  br i1 %cond6091, label %bb_rcglast1298, label %bb_rcgdec1298
bb_rcglast1298:
  %v6092 = load i64, ptr %slot1002, align 8
  %op6093 = sub i64 %v6092, 24
  store i64 %op6093, ptr %slot1012, align 8
  %v6094 = load i64, ptr %slot1002, align 8
  %p6095 = inttoptr i64 %v6094 to ptr
  %rgep6096 = getelementptr i8, ptr %p6095, i64 -24
  %ld6097 = load i64, ptr %rgep6096, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6097, ptr %slot1013, align 8
  %v6098 = load i64, ptr %slot1013, align 8
  %cmp6099 = icmp ne i64 %v6098, 0
  %cv6100 = zext i1 %cmp6099 to i32
  store i32 %cv6100, ptr %slot1014, align 8
  %v6101 = load i32, ptr %slot1014, align 8
  %cv6102 = zext i32 %v6101 to i64
  %cond6103 = icmp ne i64 %cv6102, 0
  br i1 %cond6103, label %bb_rcgdec1298, label %bb_rcgslow1298
bb_rcgslow1298:
  %v6104 = load i64, ptr %slot1001, align 8
  %v6105 = load i64, ptr %slot1000, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v6104, i64 %v6105) nomerge, !dbg !174
  br label %bb_rcgdone1298
bb_rcgdec1298:
  %v6106 = load i64, ptr %slot1010, align 8
  %v6107 = load i64, ptr %slot1002, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %rgep6109 = getelementptr i8, ptr %p6108, i64 -32
  store i64 %v6106, ptr %rgep6109, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1298
bb_rcgclear1298:
  %v6110 = load i64, ptr %slot1000, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  store i64 0, ptr %p6111, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1298
bb_rcgdone1298:
  %v6112 = load i64, ptr %slot966, align 8
  %p6113 = inttoptr i64 %v6112 to ptr
  store i64 0, ptr %p6113, align 8, !alias.scope !3, !noalias !4
  %v6114 = load i64, ptr %slot966, align 8
  %p6116 = inttoptr i64 %v6114 to ptr
  %gep6117 = getelementptr i8, ptr %p6116, i64 8
  %op6115 = ptrtoint ptr %gep6117 to i64
  store i64 %op6115, ptr %slot1015, align 8
  %v6118 = load i64, ptr %slot1015, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  store i64 0, ptr %p6119, align 8, !alias.scope !3, !noalias !4
  %v6120 = load i64, ptr %slot966, align 8
  %p6122 = inttoptr i64 %v6120 to ptr
  %gep6123 = getelementptr i8, ptr %p6122, i64 16
  %op6121 = ptrtoint ptr %gep6123 to i64
  store i64 %op6121, ptr %slot1016, align 8
  %v6124 = load i64, ptr %slot1016, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  store i64 0, ptr %p6125, align 8, !alias.scope !3, !noalias !4
  %v6126 = load i64, ptr %slot966, align 8
  %p6128 = inttoptr i64 %v6126 to ptr
  %gep6129 = getelementptr i8, ptr %p6128, i64 24
  %op6127 = ptrtoint ptr %gep6129 to i64
  store i64 %op6127, ptr %slot1017, align 8
  %v6130 = load i64, ptr %slot1017, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  store i64 0, ptr %p6131, align 8, !alias.scope !3, !noalias !4
  %v6132 = load i64, ptr %slot966, align 8
  %p6134 = inttoptr i64 %v6132 to ptr
  %gep6135 = getelementptr i8, ptr %p6134, i64 32
  %op6133 = ptrtoint ptr %gep6135 to i64
  store i64 %op6133, ptr %slot1018, align 8
  %v6136 = load i64, ptr %slot1018, align 8
  %p6137 = inttoptr i64 %v6136 to ptr
  store i64 0, ptr %p6137, align 8, !alias.scope !3, !noalias !4
  %v6138 = load i64, ptr %slot966, align 8
  %p6140 = inttoptr i64 %v6138 to ptr
  %gep6141 = getelementptr i8, ptr %p6140, i64 40
  %op6139 = ptrtoint ptr %gep6141 to i64
  store i64 %op6139, ptr %slot1019, align 8
  %v6142 = load i64, ptr %slot1019, align 8
  %p6143 = inttoptr i64 %v6142 to ptr
  store i64 0, ptr %p6143, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1248
bb_rcslotdone1248:
  %v6144 = load i64, ptr %slot45, align 8
  store i64 %v6144, ptr %slot1020, align 8
  %v6145 = load i64, ptr %slot32, align 8
  store i64 %v6145, ptr %slot1021, align 8
  %v6146 = load i64, ptr %slot1021, align 8
  %v6147 = load i64, ptr %slot1020, align 8
  %p6148 = inttoptr i64 %v6146 to ptr
  %p6149 = inttoptr i64 %v6147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6149, ptr %p6148, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6150 = load i64, ptr %slot27, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  store i32 0, ptr %p6151, align 4, !alias.scope !3, !noalias !4
  %v6152 = load i64, ptr %slot16, align 8
  %p6153 = inttoptr i64 %v6152 to ptr
  store i32 2, ptr %p6153, align 4, !alias.scope !3, !noalias !4
  %v6154 = load i64, ptr %slot28, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  %ld6156 = load i32, ptr %p6155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6156, ptr %slot1022, align 8
  %v6157 = load i32, ptr %slot1022, align 8
  %v6158 = load i64, ptr %slot16, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  store i32 %v6157, ptr %p6159, align 4, !alias.scope !3, !noalias !4
  %v6160 = load i64, ptr %slot15, align 8
  %p6161 = inttoptr i64 %v6160 to ptr
  store i32 1, ptr %p6161, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept1123
bb_rcselfkept1123:
  %v6162 = load i64, ptr %slot35, align 8
  %v6163 = load i64, ptr %slot58, align 8
  %p6164 = inttoptr i64 %v6163 to ptr
  store i64 %v6162, ptr %p6164, align 8, !alias.scope !3, !noalias !4
  %v6165 = load i64, ptr %slot45, align 8
  %v6166 = load i64, ptr %slot59, align 8
  %p6167 = inttoptr i64 %v6166 to ptr
  store i64 %v6165, ptr %p6167, align 8, !alias.scope !3, !noalias !4
  %v6168 = load i64, ptr %slot59, align 8
  %p6169 = inttoptr i64 %v6168 to ptr
  %ld6170 = load i64, ptr %p6169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6170, ptr %slot1023, align 8
  %v6171 = load i64, ptr %slot1023, align 8
  %op6172 = add i64 %v6171, 40
  store i64 %op6172, ptr %slot1024, align 8
  %v6173 = load i64, ptr %slot1024, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %ld6175 = load i64, ptr %p6174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6175, ptr %slot1025, align 8
  %v6176 = load i64, ptr %slot1025, align 8
  %v6177 = load i64, ptr %slot59, align 8
  %p6178 = inttoptr i64 %v6177 to ptr
  store i64 %v6176, ptr %p6178, align 8, !alias.scope !3, !noalias !4
  %v6179 = load i64, ptr %slot25, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  %ld6181 = load i32, ptr %p6180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6181, ptr %slot1026, align 8
  %v6182 = load i32, ptr %slot1026, align 8
  %cv6183 = zext i32 %v6182 to i64
  %cond6184 = icmp ne i64 %cv6183, 0
  br i1 %cond6184, label %bb_rcslotdrop1319, label %bb_rcslotdone1319
bb_rcslotdrop1319:
  %v6185 = load i64, ptr %slot25, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  store i32 0, ptr %p6186, align 4, !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot30, align 8
  store i64 %v6187, ptr %slot1027, align 8
  %v6188 = load i64, ptr %slot26, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %ld6190 = load i32, ptr %p6189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6190, ptr %slot1028, align 8
  %v6191 = load i32, ptr %slot1028, align 8
  %op6192 = and i32 %v6191, 28
  store i32 %op6192, ptr %slot1029, align 8
  %v6193 = load i32, ptr %slot1029, align 8
  %cv6194 = zext i32 %v6193 to i64
  %cond6195 = icmp ne i64 %cv6194, 0
  br i1 %cond6195, label %bb_rcslotrole1319, label %bb_rcslotowner1319
bb_rcslotrole1319:
  %v6196 = load i64, ptr %slot65, align 8
  store i64 %v6196, ptr %slot1030, align 8
  %v6197 = load i64, ptr %slot1030, align 8
  %v6198 = load i64, ptr %slot1027, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6197, i64 %v6198) nomerge, !dbg !176
  br label %bb_rcslotdone1319
bb_rcslotowner1319:
  %v6199 = load i64, ptr %slot65, align 8
  store i64 %v6199, ptr %slot1031, align 8
  %v6200 = load i64, ptr %slot1031, align 8
  %v6201 = load i64, ptr %slot1027, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6200, i64 %v6201) nomerge, !dbg !176
  br label %bb_rcslotdone1319
bb_rcslotdone1319:
  %v6202 = load i64, ptr %slot58, align 8
  %p6203 = inttoptr i64 %v6202 to ptr
  %ld6204 = load i64, ptr %p6203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6204, ptr %slot1032, align 8
  %v6205 = load i64, ptr %slot59, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  %ld6207 = load i64, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6207, ptr %slot1033, align 8
  %v6208 = load i64, ptr %slot1, align 8
  %v6209 = load i64, ptr %slot1032, align 8
  %v6210 = load i64, ptr %slot1033, align 8
  %call6211 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v6208, i64 %v6209, i64 %v6210) nomerge, !dbg !178
  store i64 %call6211, ptr %slot1034, align 8
  %v6212 = load i64, ptr %slot1034, align 8
  %v6213 = load i64, ptr %slot58, align 8
  %p6214 = inttoptr i64 %v6213 to ptr
  store i64 %v6212, ptr %p6214, align 8, !alias.scope !3, !noalias !4
  %v6215 = load i64, ptr %slot23, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  %ld6217 = load i32, ptr %p6216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6217, ptr %slot1035, align 8
  %v6218 = load i32, ptr %slot1035, align 8
  %cv6219 = zext i32 %v6218 to i64
  %cond6220 = icmp ne i64 %cv6219, 0
  br i1 %cond6220, label %bb_rcslotdrop1331, label %bb_rcslotdone1331
bb_rcslotdrop1331:
  %v6221 = load i64, ptr %slot23, align 8
  %p6222 = inttoptr i64 %v6221 to ptr
  store i32 0, ptr %p6222, align 4, !alias.scope !3, !noalias !4
  %v6223 = load i64, ptr %slot29, align 8
  store i64 %v6223, ptr %slot1036, align 8
  %v6224 = load i64, ptr %slot24, align 8
  %p6225 = inttoptr i64 %v6224 to ptr
  %ld6226 = load i32, ptr %p6225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6226, ptr %slot1037, align 8
  %v6227 = load i32, ptr %slot1037, align 8
  %op6228 = and i32 %v6227, 28
  store i32 %op6228, ptr %slot1038, align 8
  %v6229 = load i32, ptr %slot1038, align 8
  %cv6230 = zext i32 %v6229 to i64
  %cond6231 = icmp ne i64 %cv6230, 0
  br i1 %cond6231, label %bb_rcslotrole1331, label %bb_rcslotowner1331
bb_rcslotrole1331:
  %v6232 = load i64, ptr %slot65, align 8
  store i64 %v6232, ptr %slot1039, align 8
  %v6233 = load i64, ptr %slot1039, align 8
  %v6234 = load i64, ptr %slot1036, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v6233, i64 %v6234) nomerge, !dbg !178
  br label %bb_rcslotdone1331
bb_rcslotowner1331:
  %v6235 = load i64, ptr %slot65, align 8
  store i64 %v6235, ptr %slot1040, align 8
  %v6236 = load i64, ptr %slot1040, align 8
  %v6237 = load i64, ptr %slot1036, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v6236, i64 %v6237) nomerge, !dbg !178
  br label %bb_rcslotdone1331
bb_rcslotdone1331:
  %v6238 = load i64, ptr %slot45, align 8
  %v6239 = load i64, ptr %slot58, align 8
  %p6240 = inttoptr i64 %v6239 to ptr
  store i64 %v6238, ptr %p6240, align 8, !alias.scope !3, !noalias !4
  %v6241 = load i64, ptr %slot58, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  %ld6243 = load i64, ptr %p6242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6243, ptr %slot1041, align 8
  %v6244 = load i64, ptr %slot1041, align 8
  %op6245 = add i64 %v6244, 16
  store i64 %op6245, ptr %slot1042, align 8
  %v6246 = load i64, ptr %slot1042, align 8
  %v6247 = load i64, ptr %slot58, align 8
  %p6248 = inttoptr i64 %v6247 to ptr
  store i64 %v6246, ptr %p6248, align 8, !alias.scope !3, !noalias !4
  %v6249 = load i64, ptr %slot23, align 8
  %p6250 = inttoptr i64 %v6249 to ptr
  %ld6251 = load i32, ptr %p6250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6251, ptr %slot1043, align 8
  %v6252 = load i32, ptr %slot1043, align 8
  %cv6253 = zext i32 %v6252 to i64
  %cond6254 = icmp ne i64 %cv6253, 0
  br i1 %cond6254, label %bb_rcslotdrop1342, label %bb_rcslotdone1342
bb_rcslotdrop1342:
  %v6255 = load i64, ptr %slot23, align 8
  %p6256 = inttoptr i64 %v6255 to ptr
  store i32 0, ptr %p6256, align 4, !alias.scope !3, !noalias !4
  %v6257 = load i64, ptr %slot29, align 8
  store i64 %v6257, ptr %slot1044, align 8
  %v6258 = load i64, ptr %slot24, align 8
  %p6259 = inttoptr i64 %v6258 to ptr
  %ld6260 = load i32, ptr %p6259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6260, ptr %slot1045, align 8
  %v6261 = load i32, ptr %slot1045, align 8
  %op6262 = and i32 %v6261, 28
  store i32 %op6262, ptr %slot1046, align 8
  %v6263 = load i32, ptr %slot1046, align 8
  %cv6264 = zext i32 %v6263 to i64
  %cond6265 = icmp ne i64 %cv6264, 0
  br i1 %cond6265, label %bb_rcslotrole1342, label %bb_rcslotowner1342
bb_rcslotrole1342:
  %v6266 = load i64, ptr %slot65, align 8
  store i64 %v6266, ptr %slot1047, align 8
  %v6267 = load i64, ptr %slot1047, align 8
  %v6268 = load i64, ptr %slot1044, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6267, i64 %v6268) nomerge, !dbg !180
  br label %bb_rcslotdone1342
bb_rcslotowner1342:
  %v6269 = load i64, ptr %slot65, align 8
  store i64 %v6269, ptr %slot1048, align 8
  %v6270 = load i64, ptr %slot1048, align 8
  %v6271 = load i64, ptr %slot1044, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6270, i64 %v6271) nomerge, !dbg !180
  br label %bb_rcslotdone1342
bb_rcslotdone1342:
  %v6272 = load i64, ptr %slot58, align 8
  %p6273 = inttoptr i64 %v6272 to ptr
  %ld6274 = load i64, ptr %p6273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6274, ptr %slot1049, align 8
  %v6275 = load i64, ptr %slot1049, align 8
  %op6276 = add i64 %v6275, 16
  store i64 %op6276, ptr %slot1050, align 8
  %v6277 = load i64, ptr %slot1050, align 8
  %p6278 = inttoptr i64 %v6277 to ptr
  %ld6279 = load i64, ptr %p6278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6279, ptr %slot1051, align 8
  %v6280 = load i64, ptr %slot1051, align 8
  %v6281 = load i64, ptr %slot58, align 8
  %p6282 = inttoptr i64 %v6281 to ptr
  store i64 %v6280, ptr %p6282, align 8, !alias.scope !3, !noalias !4
  %v6283 = load i64, ptr %slot58, align 8
  %p6284 = inttoptr i64 %v6283 to ptr
  %ld6285 = load i64, ptr %p6284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6285, ptr %slot1052, align 8
  %v6286 = load i64, ptr %slot1052, align 8
  %v6287 = load i64, ptr %slot31, align 8
  %p6288 = inttoptr i64 %v6287 to ptr
  store i64 %v6286, ptr %p6288, align 8, !alias.scope !3, !noalias !4
  %v6289 = load i64, ptr %slot31, align 8
  store i64 %v6289, ptr %slot1053, align 8
  %v6290 = load i64, ptr %slot32, align 8
  store i64 %v6290, ptr %slot1054, align 8
  %v6291 = load i64, ptr %slot1053, align 8
  %p6292 = inttoptr i64 %v6291 to ptr
  %ld6293 = load i64, ptr %p6292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6293, ptr %slot1055, align 8
  %v6294 = load i64, ptr %slot1055, align 8
  %cmp6295 = icmp ne i64 %v6294, 0
  %cv6296 = zext i1 %cmp6295 to i32
  store i32 %cv6296, ptr %slot1056, align 8
  %v6297 = load i32, ptr %slot1056, align 8
  %cv6298 = zext i32 %v6297 to i64
  %cond6299 = icmp ne i64 %cv6298, 0
  br i1 %cond6299, label %bb_rcgnn1356, label %bb_rcgstore1356
bb_rcgnn1356:
  %v6300 = load i64, ptr %slot1055, align 8
  %op6301 = sub i64 %v6300, 16
  store i64 %op6301, ptr %slot1057, align 8
  %v6302 = load i64, ptr %slot1055, align 8
  %p6303 = inttoptr i64 %v6302 to ptr
  %rgep6304 = getelementptr i8, ptr %p6303, i64 -16
  %ld6305 = load i64, ptr %rgep6304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6305, ptr %slot1058, align 8
  %v6306 = load i64, ptr %slot1058, align 8
  %op6307 = and i64 %v6306, 4611686018427387906
  store i64 %op6307, ptr %slot1059, align 8
  %v6308 = load i64, ptr %slot1059, align 8
  %cmp6309 = icmp ne i64 %v6308, 0
  %cv6310 = zext i1 %cmp6309 to i32
  store i32 %cv6310, ptr %slot1060, align 8
  %v6311 = load i32, ptr %slot1060, align 8
  %cv6312 = zext i32 %v6311 to i64
  %cond6313 = icmp ne i64 %cv6312, 0
  br i1 %cond6313, label %bb_rcgstore1356, label %bb_rcginc1356
bb_rcginc1356:
  %v6314 = load i64, ptr %slot1055, align 8
  %op6315 = sub i64 %v6314, 24
  store i64 %op6315, ptr %slot1061, align 8
  %v6316 = load i64, ptr %slot1055, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  %rgep6318 = getelementptr i8, ptr %p6317, i64 -24
  %ld6319 = load i64, ptr %rgep6318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6319, ptr %slot1062, align 8
  %v6320 = load i64, ptr %slot1062, align 8
  %op6321 = add i64 %v6320, 1
  store i64 %op6321, ptr %slot1063, align 8
  %v6322 = load i64, ptr %slot1063, align 8
  %cmp6323 = icmp eq i64 %v6322, 0
  %cv6324 = zext i1 %cmp6323 to i32
  store i32 %cv6324, ptr %slot1064, align 8
  %v6325 = load i32, ptr %slot1064, align 8
  %cv6326 = zext i32 %v6325 to i64
  %cond6327 = icmp ne i64 %cv6326, 0
  br i1 %cond6327, label %bb_rcglimit1356, label %bb_rcgcapacity1356
bb_rcglimit1356:
  %v6328 = load i64, ptr %slot1, align 8
  %p6329 = inttoptr i64 %v6328 to ptr
  %call6330 = call i32 @myl_qbe_rc_status(ptr %p6329, i32 2) nomerge, !dbg !182
  store i32 %call6330, ptr %slot1065, align 8
  br label %bb_failure
bb_rcgcapacity1356:
  %v6331 = load i64, ptr %slot1063, align 8
  %v6332 = load i64, ptr %slot1055, align 8
  %p6333 = inttoptr i64 %v6332 to ptr
  %rgep6334 = getelementptr i8, ptr %p6333, i64 -24
  store i64 %v6331, ptr %rgep6334, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1356
bb_rcgstore1356:
  %v6335 = load i64, ptr %slot1055, align 8
  %v6336 = load i64, ptr %slot1054, align 8
  %p6337 = inttoptr i64 %v6336 to ptr
  store i64 %v6335, ptr %p6337, align 8, !alias.scope !3, !noalias !4
  %v6338 = load i64, ptr %slot28, align 8
  %p6339 = inttoptr i64 %v6338 to ptr
  store i32 2, ptr %p6339, align 4, !alias.scope !3, !noalias !4
  %v6340 = load i64, ptr %slot28, align 8
  %p6341 = inttoptr i64 %v6340 to ptr
  store i32 16, ptr %p6341, align 4, !alias.scope !3, !noalias !4
  %v6342 = load i64, ptr %slot27, align 8
  %p6343 = inttoptr i64 %v6342 to ptr
  store i32 1, ptr %p6343, align 4, !alias.scope !3, !noalias !4
  %v6344 = load i64, ptr %slot23, align 8
  %p6345 = inttoptr i64 %v6344 to ptr
  %ld6346 = load i32, ptr %p6345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6346, ptr %slot1066, align 8
  %v6347 = load i32, ptr %slot1066, align 8
  %cv6348 = zext i32 %v6347 to i64
  %cond6349 = icmp ne i64 %cv6348, 0
  br i1 %cond6349, label %bb_rcslotdrop1372, label %bb_rcslotdone1372
bb_rcslotdrop1372:
  %v6350 = load i64, ptr %slot23, align 8
  %p6351 = inttoptr i64 %v6350 to ptr
  store i32 0, ptr %p6351, align 4, !alias.scope !3, !noalias !4
  %v6352 = load i64, ptr %slot29, align 8
  store i64 %v6352, ptr %slot1067, align 8
  %v6353 = load i64, ptr %slot24, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  %ld6355 = load i32, ptr %p6354, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6355, ptr %slot1068, align 8
  %v6356 = load i32, ptr %slot1068, align 8
  %op6357 = and i32 %v6356, 28
  store i32 %op6357, ptr %slot1069, align 8
  %v6358 = load i32, ptr %slot1069, align 8
  %cv6359 = zext i32 %v6358 to i64
  %cond6360 = icmp ne i64 %cv6359, 0
  br i1 %cond6360, label %bb_rcslotrole1372, label %bb_rcslotowner1372
bb_rcslotrole1372:
  %v6361 = load i64, ptr %slot65, align 8
  store i64 %v6361, ptr %slot1070, align 8
  %v6362 = load i64, ptr %slot1070, align 8
  %v6363 = load i64, ptr %slot1067, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v6362, i64 %v6363) nomerge, !dbg !182
  br label %bb_rcslotdone1372
bb_rcslotowner1372:
  %v6364 = load i64, ptr %slot65, align 8
  store i64 %v6364, ptr %slot1071, align 8
  %v6365 = load i64, ptr %slot1071, align 8
  %v6366 = load i64, ptr %slot1067, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v6365, i64 %v6366) nomerge, !dbg !182
  br label %bb_rcslotdone1372
bb_rcslotdone1372:
  %v6367 = load i64, ptr %slot29, align 8
  store i64 %v6367, ptr %slot1072, align 8
  %v6368 = load i64, ptr %slot32, align 8
  store i64 %v6368, ptr %slot1073, align 8
  %v6369 = load i64, ptr %slot1073, align 8
  %v6370 = load i64, ptr %slot1072, align 8
  %p6371 = inttoptr i64 %v6369 to ptr
  %p6372 = inttoptr i64 %v6370 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6372, ptr %p6371, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6373 = load i64, ptr %slot24, align 8
  %p6374 = inttoptr i64 %v6373 to ptr
  store i32 2, ptr %p6374, align 4, !alias.scope !3, !noalias !4
  %v6375 = load i64, ptr %slot28, align 8
  %p6376 = inttoptr i64 %v6375 to ptr
  %ld6377 = load i32, ptr %p6376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6377, ptr %slot1074, align 8
  %v6378 = load i32, ptr %slot1074, align 8
  %v6379 = load i64, ptr %slot24, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  store i32 %v6378, ptr %p6380, align 4, !alias.scope !3, !noalias !4
  %v6381 = load i64, ptr %slot27, align 8
  %p6382 = inttoptr i64 %v6381 to ptr
  store i32 0, ptr %p6382, align 4, !alias.scope !3, !noalias !4
  %v6383 = load i64, ptr %slot23, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  store i32 1, ptr %p6384, align 4, !alias.scope !3, !noalias !4
  %v6385 = load i64, ptr %slot1072, align 8
  %p6386 = inttoptr i64 %v6385 to ptr
  %ld6387 = load i64, ptr %p6386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6387, ptr %slot1075, align 8
  %v6388 = load i64, ptr %slot1075, align 8
  %v6389 = load i64, ptr %slot58, align 8
  %p6390 = inttoptr i64 %v6389 to ptr
  store i64 %v6388, ptr %p6390, align 8, !alias.scope !3, !noalias !4
  %v6391 = load i64, ptr %slot58, align 8
  %p6392 = inttoptr i64 %v6391 to ptr
  %ld6393 = load i64, ptr %p6392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6393, ptr %slot1076, align 8
  %v6394 = load i64, ptr %slot32, align 8
  store i64 %v6394, ptr %slot1077, align 8
  %v6395 = load i64, ptr %slot1076, align 8
  %cmp6396 = icmp ne i64 %v6395, 0
  %cv6397 = zext i1 %cmp6396 to i32
  store i32 %cv6397, ptr %slot1078, align 8
  %v6398 = load i32, ptr %slot1078, align 8
  %cv6399 = zext i32 %v6398 to i64
  %cond6400 = icmp ne i64 %cv6399, 0
  br i1 %cond6400, label %bb_rcgnn1392, label %bb_rcgstore1392
bb_rcgnn1392:
  %v6401 = load i64, ptr %slot1076, align 8
  %op6402 = sub i64 %v6401, 16
  store i64 %op6402, ptr %slot1079, align 8
  %v6403 = load i64, ptr %slot1076, align 8
  %p6404 = inttoptr i64 %v6403 to ptr
  %rgep6405 = getelementptr i8, ptr %p6404, i64 -16
  %ld6406 = load i64, ptr %rgep6405, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6406, ptr %slot1080, align 8
  %v6407 = load i64, ptr %slot1080, align 8
  %op6408 = and i64 %v6407, 4611686018427387906
  store i64 %op6408, ptr %slot1081, align 8
  %v6409 = load i64, ptr %slot1081, align 8
  %cmp6410 = icmp ne i64 %v6409, 0
  %cv6411 = zext i1 %cmp6410 to i32
  store i32 %cv6411, ptr %slot1082, align 8
  %v6412 = load i32, ptr %slot1082, align 8
  %cv6413 = zext i32 %v6412 to i64
  %cond6414 = icmp ne i64 %cv6413, 0
  br i1 %cond6414, label %bb_rcgstore1392, label %bb_rcginc1392
bb_rcginc1392:
  %v6415 = load i64, ptr %slot1076, align 8
  %op6416 = sub i64 %v6415, 24
  store i64 %op6416, ptr %slot1083, align 8
  %v6417 = load i64, ptr %slot1076, align 8
  %p6418 = inttoptr i64 %v6417 to ptr
  %rgep6419 = getelementptr i8, ptr %p6418, i64 -24
  %ld6420 = load i64, ptr %rgep6419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6420, ptr %slot1084, align 8
  %v6421 = load i64, ptr %slot1084, align 8
  %op6422 = add i64 %v6421, 1
  store i64 %op6422, ptr %slot1085, align 8
  %v6423 = load i64, ptr %slot1085, align 8
  %cmp6424 = icmp eq i64 %v6423, 0
  %cv6425 = zext i1 %cmp6424 to i32
  store i32 %cv6425, ptr %slot1086, align 8
  %v6426 = load i32, ptr %slot1086, align 8
  %cv6427 = zext i32 %v6426 to i64
  %cond6428 = icmp ne i64 %cv6427, 0
  br i1 %cond6428, label %bb_rcglimit1392, label %bb_rcgcapacity1392
bb_rcglimit1392:
  %v6429 = load i64, ptr %slot1, align 8
  %p6430 = inttoptr i64 %v6429 to ptr
  %call6431 = call i32 @myl_qbe_rc_status(ptr %p6430, i32 2) nomerge, !dbg !184
  store i32 %call6431, ptr %slot1087, align 8
  br label %bb_failure
bb_rcgcapacity1392:
  %v6432 = load i64, ptr %slot1085, align 8
  %v6433 = load i64, ptr %slot1076, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  %rgep6435 = getelementptr i8, ptr %p6434, i64 -24
  store i64 %v6432, ptr %rgep6435, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1392
bb_rcgstore1392:
  %v6436 = load i64, ptr %slot1076, align 8
  %v6437 = load i64, ptr %slot1077, align 8
  %p6438 = inttoptr i64 %v6437 to ptr
  store i64 %v6436, ptr %p6438, align 8, !alias.scope !3, !noalias !4
  %v6439 = load i64, ptr %slot28, align 8
  %p6440 = inttoptr i64 %v6439 to ptr
  store i32 2, ptr %p6440, align 4, !alias.scope !3, !noalias !4
  %v6441 = load i64, ptr %slot28, align 8
  %p6442 = inttoptr i64 %v6441 to ptr
  store i32 8, ptr %p6442, align 4, !alias.scope !3, !noalias !4
  %v6443 = load i64, ptr %slot27, align 8
  %p6444 = inttoptr i64 %v6443 to ptr
  store i32 1, ptr %p6444, align 4, !alias.scope !3, !noalias !4
  %v6445 = load i64, ptr %slot23, align 8
  %p6446 = inttoptr i64 %v6445 to ptr
  %ld6447 = load i32, ptr %p6446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6447, ptr %slot1088, align 8
  %v6448 = load i32, ptr %slot1088, align 8
  %cv6449 = zext i32 %v6448 to i64
  %cond6450 = icmp ne i64 %cv6449, 0
  br i1 %cond6450, label %bb_rcslotdrop1408, label %bb_rcslotdone1408
bb_rcslotdrop1408:
  %v6451 = load i64, ptr %slot23, align 8
  %p6452 = inttoptr i64 %v6451 to ptr
  store i32 0, ptr %p6452, align 4, !alias.scope !3, !noalias !4
  %v6453 = load i64, ptr %slot29, align 8
  store i64 %v6453, ptr %slot1089, align 8
  %v6454 = load i64, ptr %slot24, align 8
  %p6455 = inttoptr i64 %v6454 to ptr
  %ld6456 = load i32, ptr %p6455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6456, ptr %slot1090, align 8
  %v6457 = load i32, ptr %slot1090, align 8
  %op6458 = and i32 %v6457, 28
  store i32 %op6458, ptr %slot1091, align 8
  %v6459 = load i32, ptr %slot1091, align 8
  %cv6460 = zext i32 %v6459 to i64
  %cond6461 = icmp ne i64 %cv6460, 0
  br i1 %cond6461, label %bb_rcslotrole1408, label %bb_rcslotowner1408
bb_rcslotrole1408:
  %v6462 = load i64, ptr %slot65, align 8
  store i64 %v6462, ptr %slot1092, align 8
  %v6463 = load i64, ptr %slot1089, align 8
  %p6464 = inttoptr i64 %v6463 to ptr
  %ld6465 = load i64, ptr %p6464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6465, ptr %slot1093, align 8
  %v6466 = load i64, ptr %slot1093, align 8
  %cmp6467 = icmp ne i64 %v6466, 0
  %cv6468 = zext i1 %cmp6467 to i32
  store i32 %cv6468, ptr %slot1094, align 8
  %v6469 = load i32, ptr %slot1094, align 8
  %cv6470 = zext i32 %v6469 to i64
  %cond6471 = icmp ne i64 %cv6470, 0
  br i1 %cond6471, label %bb_rcgnn1424, label %bb_rcgdone1424
bb_rcgnn1424:
  %v6472 = load i64, ptr %slot1093, align 8
  %op6473 = sub i64 %v6472, 16
  store i64 %op6473, ptr %slot1095, align 8
  %v6474 = load i64, ptr %slot1093, align 8
  %p6475 = inttoptr i64 %v6474 to ptr
  %rgep6476 = getelementptr i8, ptr %p6475, i64 -16
  %ld6477 = load i64, ptr %rgep6476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6477, ptr %slot1096, align 8
  %v6478 = load i64, ptr %slot1096, align 8
  %op6479 = and i64 %v6478, 4611686018427387906
  store i64 %op6479, ptr %slot1097, align 8
  %v6480 = load i64, ptr %slot1097, align 8
  %cmp6481 = icmp ne i64 %v6480, 0
  %cv6482 = zext i1 %cmp6481 to i32
  store i32 %cv6482, ptr %slot1098, align 8
  %v6483 = load i32, ptr %slot1098, align 8
  %cv6484 = zext i32 %v6483 to i64
  %cond6485 = icmp ne i64 %cv6484, 0
  br i1 %cond6485, label %bb_rcgclear1424, label %bb_rcgcounted1424
bb_rcgcounted1424:
  %v6486 = load i64, ptr %slot1093, align 8
  %op6487 = sub i64 %v6486, 24
  store i64 %op6487, ptr %slot1099, align 8
  %v6488 = load i64, ptr %slot1093, align 8
  %p6489 = inttoptr i64 %v6488 to ptr
  %rgep6490 = getelementptr i8, ptr %p6489, i64 -24
  %ld6491 = load i64, ptr %rgep6490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6491, ptr %slot1100, align 8
  %v6492 = load i64, ptr %slot1100, align 8
  %op6493 = sub i64 %v6492, 1
  store i64 %op6493, ptr %slot1101, align 8
  %v6494 = load i64, ptr %slot1101, align 8
  %cmp6495 = icmp eq i64 %v6494, 0
  %cv6496 = zext i1 %cmp6495 to i32
  store i32 %cv6496, ptr %slot1102, align 8
  %v6497 = load i32, ptr %slot1102, align 8
  %cv6498 = zext i32 %v6497 to i64
  %cond6499 = icmp ne i64 %cv6498, 0
  br i1 %cond6499, label %bb_rcglast1424, label %bb_rcgdec1424
bb_rcglast1424:
  %v6500 = load i64, ptr %slot1093, align 8
  %op6501 = sub i64 %v6500, 32
  store i64 %op6501, ptr %slot1103, align 8
  %v6502 = load i64, ptr %slot1093, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  %rgep6504 = getelementptr i8, ptr %p6503, i64 -32
  %ld6505 = load i64, ptr %rgep6504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6505, ptr %slot1104, align 8
  %v6506 = load i64, ptr %slot1104, align 8
  %cmp6507 = icmp ne i64 %v6506, 0
  %cv6508 = zext i1 %cmp6507 to i32
  store i32 %cv6508, ptr %slot1105, align 8
  %v6509 = load i32, ptr %slot1105, align 8
  %cv6510 = zext i32 %v6509 to i64
  %cond6511 = icmp ne i64 %cv6510, 0
  br i1 %cond6511, label %bb_rcgdec1424, label %bb_rcgslow1424
bb_rcgslow1424:
  %v6512 = load i64, ptr %slot1092, align 8
  %v6513 = load i64, ptr %slot1089, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v6512, i64 %v6513) nomerge, !dbg !184
  br label %bb_rcgdone1424
bb_rcgdec1424:
  %v6514 = load i64, ptr %slot1101, align 8
  %v6515 = load i64, ptr %slot1093, align 8
  %p6516 = inttoptr i64 %v6515 to ptr
  %rgep6517 = getelementptr i8, ptr %p6516, i64 -24
  store i64 %v6514, ptr %rgep6517, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1424
bb_rcgclear1424:
  %v6518 = load i64, ptr %slot1089, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  store i64 0, ptr %p6519, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1424
bb_rcgdone1424:
  br label %bb_rcslotdone1408
bb_rcslotowner1408:
  %v6520 = load i64, ptr %slot65, align 8
  store i64 %v6520, ptr %slot1106, align 8
  %v6521 = load i64, ptr %slot1089, align 8
  %p6522 = inttoptr i64 %v6521 to ptr
  %ld6523 = load i64, ptr %p6522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6523, ptr %slot1107, align 8
  %v6524 = load i64, ptr %slot1107, align 8
  %cmp6525 = icmp ne i64 %v6524, 0
  %cv6526 = zext i1 %cmp6525 to i32
  store i32 %cv6526, ptr %slot1108, align 8
  %v6527 = load i32, ptr %slot1108, align 8
  %cv6528 = zext i32 %v6527 to i64
  %cond6529 = icmp ne i64 %cv6528, 0
  br i1 %cond6529, label %bb_rcgnn1439, label %bb_rcgdone1439
bb_rcgnn1439:
  %v6530 = load i64, ptr %slot1107, align 8
  %op6531 = sub i64 %v6530, 16
  store i64 %op6531, ptr %slot1109, align 8
  %v6532 = load i64, ptr %slot1107, align 8
  %p6533 = inttoptr i64 %v6532 to ptr
  %rgep6534 = getelementptr i8, ptr %p6533, i64 -16
  %ld6535 = load i64, ptr %rgep6534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6535, ptr %slot1110, align 8
  %v6536 = load i64, ptr %slot1110, align 8
  %op6537 = and i64 %v6536, 4611686018427387906
  store i64 %op6537, ptr %slot1111, align 8
  %v6538 = load i64, ptr %slot1111, align 8
  %cmp6539 = icmp ne i64 %v6538, 0
  %cv6540 = zext i1 %cmp6539 to i32
  store i32 %cv6540, ptr %slot1112, align 8
  %v6541 = load i32, ptr %slot1112, align 8
  %cv6542 = zext i32 %v6541 to i64
  %cond6543 = icmp ne i64 %cv6542, 0
  br i1 %cond6543, label %bb_rcgclear1439, label %bb_rcgcounted1439
bb_rcgcounted1439:
  %v6544 = load i64, ptr %slot1107, align 8
  %op6545 = sub i64 %v6544, 32
  store i64 %op6545, ptr %slot1113, align 8
  %v6546 = load i64, ptr %slot1107, align 8
  %p6547 = inttoptr i64 %v6546 to ptr
  %rgep6548 = getelementptr i8, ptr %p6547, i64 -32
  %ld6549 = load i64, ptr %rgep6548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6549, ptr %slot1114, align 8
  %v6550 = load i64, ptr %slot1114, align 8
  %op6551 = sub i64 %v6550, 1
  store i64 %op6551, ptr %slot1115, align 8
  %v6552 = load i64, ptr %slot1115, align 8
  %cmp6553 = icmp eq i64 %v6552, 0
  %cv6554 = zext i1 %cmp6553 to i32
  store i32 %cv6554, ptr %slot1116, align 8
  %v6555 = load i32, ptr %slot1116, align 8
  %cv6556 = zext i32 %v6555 to i64
  %cond6557 = icmp ne i64 %cv6556, 0
  br i1 %cond6557, label %bb_rcglast1439, label %bb_rcgdec1439
bb_rcglast1439:
  %v6558 = load i64, ptr %slot1107, align 8
  %op6559 = sub i64 %v6558, 24
  store i64 %op6559, ptr %slot1117, align 8
  %v6560 = load i64, ptr %slot1107, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  %rgep6562 = getelementptr i8, ptr %p6561, i64 -24
  %ld6563 = load i64, ptr %rgep6562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6563, ptr %slot1118, align 8
  %v6564 = load i64, ptr %slot1118, align 8
  %cmp6565 = icmp ne i64 %v6564, 0
  %cv6566 = zext i1 %cmp6565 to i32
  store i32 %cv6566, ptr %slot1119, align 8
  %v6567 = load i32, ptr %slot1119, align 8
  %cv6568 = zext i32 %v6567 to i64
  %cond6569 = icmp ne i64 %cv6568, 0
  br i1 %cond6569, label %bb_rcgdec1439, label %bb_rcgslow1439
bb_rcgslow1439:
  %v6570 = load i64, ptr %slot1106, align 8
  %v6571 = load i64, ptr %slot1089, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v6570, i64 %v6571) nomerge, !dbg !184
  br label %bb_rcgdone1439
bb_rcgdec1439:
  %v6572 = load i64, ptr %slot1115, align 8
  %v6573 = load i64, ptr %slot1107, align 8
  %p6574 = inttoptr i64 %v6573 to ptr
  %rgep6575 = getelementptr i8, ptr %p6574, i64 -32
  store i64 %v6572, ptr %rgep6575, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1439
bb_rcgclear1439:
  %v6576 = load i64, ptr %slot1089, align 8
  %p6577 = inttoptr i64 %v6576 to ptr
  store i64 0, ptr %p6577, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1439
bb_rcgdone1439:
  br label %bb_rcslotdone1408
bb_rcslotdone1408:
  %v6578 = load i64, ptr %slot29, align 8
  store i64 %v6578, ptr %slot1120, align 8
  %v6579 = load i64, ptr %slot32, align 8
  store i64 %v6579, ptr %slot1121, align 8
  %v6580 = load i64, ptr %slot1121, align 8
  %p6581 = inttoptr i64 %v6580 to ptr
  %ld6582 = load i64, ptr %p6581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6582, ptr %slot1122, align 8
  %v6583 = load i64, ptr %slot1122, align 8
  %v6584 = load i64, ptr %slot1120, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  store i64 %v6583, ptr %p6585, align 8, !alias.scope !3, !noalias !4
  %v6586 = load i64, ptr %slot24, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  store i32 2, ptr %p6587, align 4, !alias.scope !3, !noalias !4
  %v6588 = load i64, ptr %slot24, align 8
  %p6589 = inttoptr i64 %v6588 to ptr
  store i32 8, ptr %p6589, align 4, !alias.scope !3, !noalias !4
  %v6590 = load i64, ptr %slot23, align 8
  %p6591 = inttoptr i64 %v6590 to ptr
  store i32 1, ptr %p6591, align 4, !alias.scope !3, !noalias !4
  %v6592 = load i64, ptr %slot27, align 8
  %p6593 = inttoptr i64 %v6592 to ptr
  store i32 0, ptr %p6593, align 4, !alias.scope !3, !noalias !4
  %v6594 = load i64, ptr %slot1122, align 8
  %v6595 = load i64, ptr %slot58, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  store i64 %v6594, ptr %p6596, align 8, !alias.scope !3, !noalias !4
  %v6597 = load i64, ptr %slot32, align 8
  store i64 %v6597, ptr %slot1123, align 8
  %v6598 = load i64, ptr %slot58, align 8
  %p6599 = inttoptr i64 %v6598 to ptr
  %ld6600 = load i64, ptr %p6599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6600, ptr %slot1124, align 8
  %v6601 = load i64, ptr %slot1124, align 8
  %v6602 = load i64, ptr %slot1123, align 8
  %p6603 = inttoptr i64 %v6602 to ptr
  store i64 %v6601, ptr %p6603, align 8, !alias.scope !3, !noalias !4
  %v6604 = load i64, ptr %slot28, align 8
  %p6605 = inttoptr i64 %v6604 to ptr
  store i32 2, ptr %p6605, align 4, !alias.scope !3, !noalias !4
  %v6606 = load i64, ptr %slot28, align 8
  %p6607 = inttoptr i64 %v6606 to ptr
  store i32 8, ptr %p6607, align 4, !alias.scope !3, !noalias !4
  %v6608 = load i64, ptr %slot27, align 8
  %p6609 = inttoptr i64 %v6608 to ptr
  store i32 1, ptr %p6609, align 4, !alias.scope !3, !noalias !4
  %v6610 = load i64, ptr %slot23, align 8
  %p6611 = inttoptr i64 %v6610 to ptr
  store i32 0, ptr %p6611, align 4, !alias.scope !3, !noalias !4
  %v6612 = load i64, ptr %slot17, align 8
  %p6613 = inttoptr i64 %v6612 to ptr
  %ld6614 = load i32, ptr %p6613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6614, ptr %slot1125, align 8
  %v6615 = load i32, ptr %slot1125, align 8
  %cv6616 = zext i32 %v6615 to i64
  %cond6617 = icmp ne i64 %cv6616, 0
  br i1 %cond6617, label %bb_rcslotdrop1458, label %bb_rcslotdone1458
bb_rcslotdrop1458:
  %v6618 = load i64, ptr %slot17, align 8
  %p6619 = inttoptr i64 %v6618 to ptr
  store i32 0, ptr %p6619, align 4, !alias.scope !3, !noalias !4
  %v6620 = load i64, ptr %slot46, align 8
  store i64 %v6620, ptr %slot1126, align 8
  %v6621 = load i64, ptr %slot18, align 8
  %p6622 = inttoptr i64 %v6621 to ptr
  %ld6623 = load i32, ptr %p6622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6623, ptr %slot1127, align 8
  %v6624 = load i32, ptr %slot1127, align 8
  %op6625 = and i32 %v6624, 28
  store i32 %op6625, ptr %slot1128, align 8
  %v6626 = load i32, ptr %slot1128, align 8
  %cv6627 = zext i32 %v6626 to i64
  %cond6628 = icmp ne i64 %cv6627, 0
  br i1 %cond6628, label %bb_rcslotrole1458, label %bb_rcslotowner1458
bb_rcslotrole1458:
  %v6629 = load i64, ptr %slot65, align 8
  store i64 %v6629, ptr %slot1129, align 8
  %v6630 = load i64, ptr %slot1126, align 8
  %p6631 = inttoptr i64 %v6630 to ptr
  %ld6632 = load i64, ptr %p6631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6632, ptr %slot1130, align 8
  %v6633 = load i64, ptr %slot1130, align 8
  %cmp6634 = icmp ne i64 %v6633, 0
  %cv6635 = zext i1 %cmp6634 to i32
  store i32 %cv6635, ptr %slot1131, align 8
  %v6636 = load i32, ptr %slot1131, align 8
  %cv6637 = zext i32 %v6636 to i64
  %cond6638 = icmp ne i64 %cv6637, 0
  br i1 %cond6638, label %bb_rcgnn1474, label %bb_rcgdone1474
bb_rcgnn1474:
  %v6639 = load i64, ptr %slot1130, align 8
  %op6640 = sub i64 %v6639, 16
  store i64 %op6640, ptr %slot1132, align 8
  %v6641 = load i64, ptr %slot1130, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  %rgep6643 = getelementptr i8, ptr %p6642, i64 -16
  %ld6644 = load i64, ptr %rgep6643, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6644, ptr %slot1133, align 8
  %v6645 = load i64, ptr %slot1133, align 8
  %op6646 = and i64 %v6645, 4611686018427387906
  store i64 %op6646, ptr %slot1134, align 8
  %v6647 = load i64, ptr %slot1134, align 8
  %cmp6648 = icmp ne i64 %v6647, 0
  %cv6649 = zext i1 %cmp6648 to i32
  store i32 %cv6649, ptr %slot1135, align 8
  %v6650 = load i32, ptr %slot1135, align 8
  %cv6651 = zext i32 %v6650 to i64
  %cond6652 = icmp ne i64 %cv6651, 0
  br i1 %cond6652, label %bb_rcgclear1474, label %bb_rcgcounted1474
bb_rcgcounted1474:
  %v6653 = load i64, ptr %slot1130, align 8
  %op6654 = sub i64 %v6653, 24
  store i64 %op6654, ptr %slot1136, align 8
  %v6655 = load i64, ptr %slot1130, align 8
  %p6656 = inttoptr i64 %v6655 to ptr
  %rgep6657 = getelementptr i8, ptr %p6656, i64 -24
  %ld6658 = load i64, ptr %rgep6657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6658, ptr %slot1137, align 8
  %v6659 = load i64, ptr %slot1137, align 8
  %op6660 = sub i64 %v6659, 1
  store i64 %op6660, ptr %slot1138, align 8
  %v6661 = load i64, ptr %slot1138, align 8
  %cmp6662 = icmp eq i64 %v6661, 0
  %cv6663 = zext i1 %cmp6662 to i32
  store i32 %cv6663, ptr %slot1139, align 8
  %v6664 = load i32, ptr %slot1139, align 8
  %cv6665 = zext i32 %v6664 to i64
  %cond6666 = icmp ne i64 %cv6665, 0
  br i1 %cond6666, label %bb_rcglast1474, label %bb_rcgdec1474
bb_rcglast1474:
  %v6667 = load i64, ptr %slot1130, align 8
  %op6668 = sub i64 %v6667, 32
  store i64 %op6668, ptr %slot1140, align 8
  %v6669 = load i64, ptr %slot1130, align 8
  %p6670 = inttoptr i64 %v6669 to ptr
  %rgep6671 = getelementptr i8, ptr %p6670, i64 -32
  %ld6672 = load i64, ptr %rgep6671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6672, ptr %slot1141, align 8
  %v6673 = load i64, ptr %slot1141, align 8
  %cmp6674 = icmp ne i64 %v6673, 0
  %cv6675 = zext i1 %cmp6674 to i32
  store i32 %cv6675, ptr %slot1142, align 8
  %v6676 = load i32, ptr %slot1142, align 8
  %cv6677 = zext i32 %v6676 to i64
  %cond6678 = icmp ne i64 %cv6677, 0
  br i1 %cond6678, label %bb_rcgdec1474, label %bb_rcgslow1474
bb_rcgslow1474:
  %v6679 = load i64, ptr %slot1129, align 8
  %v6680 = load i64, ptr %slot1126, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v6679, i64 %v6680) nomerge, !dbg !184
  br label %bb_rcgdone1474
bb_rcgdec1474:
  %v6681 = load i64, ptr %slot1138, align 8
  %v6682 = load i64, ptr %slot1130, align 8
  %p6683 = inttoptr i64 %v6682 to ptr
  %rgep6684 = getelementptr i8, ptr %p6683, i64 -24
  store i64 %v6681, ptr %rgep6684, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1474
bb_rcgclear1474:
  %v6685 = load i64, ptr %slot1126, align 8
  %p6686 = inttoptr i64 %v6685 to ptr
  store i64 0, ptr %p6686, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1474
bb_rcgdone1474:
  br label %bb_rcslotdone1458
bb_rcslotowner1458:
  %v6687 = load i64, ptr %slot65, align 8
  store i64 %v6687, ptr %slot1143, align 8
  %v6688 = load i64, ptr %slot1126, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  %ld6690 = load i64, ptr %p6689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6690, ptr %slot1144, align 8
  %v6691 = load i64, ptr %slot1144, align 8
  %cmp6692 = icmp ne i64 %v6691, 0
  %cv6693 = zext i1 %cmp6692 to i32
  store i32 %cv6693, ptr %slot1145, align 8
  %v6694 = load i32, ptr %slot1145, align 8
  %cv6695 = zext i32 %v6694 to i64
  %cond6696 = icmp ne i64 %cv6695, 0
  br i1 %cond6696, label %bb_rcgnn1489, label %bb_rcgdone1489
bb_rcgnn1489:
  %v6697 = load i64, ptr %slot1144, align 8
  %op6698 = sub i64 %v6697, 16
  store i64 %op6698, ptr %slot1146, align 8
  %v6699 = load i64, ptr %slot1144, align 8
  %p6700 = inttoptr i64 %v6699 to ptr
  %rgep6701 = getelementptr i8, ptr %p6700, i64 -16
  %ld6702 = load i64, ptr %rgep6701, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6702, ptr %slot1147, align 8
  %v6703 = load i64, ptr %slot1147, align 8
  %op6704 = and i64 %v6703, 4611686018427387906
  store i64 %op6704, ptr %slot1148, align 8
  %v6705 = load i64, ptr %slot1148, align 8
  %cmp6706 = icmp ne i64 %v6705, 0
  %cv6707 = zext i1 %cmp6706 to i32
  store i32 %cv6707, ptr %slot1149, align 8
  %v6708 = load i32, ptr %slot1149, align 8
  %cv6709 = zext i32 %v6708 to i64
  %cond6710 = icmp ne i64 %cv6709, 0
  br i1 %cond6710, label %bb_rcgclear1489, label %bb_rcgcounted1489
bb_rcgcounted1489:
  %v6711 = load i64, ptr %slot1144, align 8
  %op6712 = sub i64 %v6711, 32
  store i64 %op6712, ptr %slot1150, align 8
  %v6713 = load i64, ptr %slot1144, align 8
  %p6714 = inttoptr i64 %v6713 to ptr
  %rgep6715 = getelementptr i8, ptr %p6714, i64 -32
  %ld6716 = load i64, ptr %rgep6715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6716, ptr %slot1151, align 8
  %v6717 = load i64, ptr %slot1151, align 8
  %op6718 = sub i64 %v6717, 1
  store i64 %op6718, ptr %slot1152, align 8
  %v6719 = load i64, ptr %slot1152, align 8
  %cmp6720 = icmp eq i64 %v6719, 0
  %cv6721 = zext i1 %cmp6720 to i32
  store i32 %cv6721, ptr %slot1153, align 8
  %v6722 = load i32, ptr %slot1153, align 8
  %cv6723 = zext i32 %v6722 to i64
  %cond6724 = icmp ne i64 %cv6723, 0
  br i1 %cond6724, label %bb_rcglast1489, label %bb_rcgdec1489
bb_rcglast1489:
  %v6725 = load i64, ptr %slot1144, align 8
  %op6726 = sub i64 %v6725, 24
  store i64 %op6726, ptr %slot1154, align 8
  %v6727 = load i64, ptr %slot1144, align 8
  %p6728 = inttoptr i64 %v6727 to ptr
  %rgep6729 = getelementptr i8, ptr %p6728, i64 -24
  %ld6730 = load i64, ptr %rgep6729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6730, ptr %slot1155, align 8
  %v6731 = load i64, ptr %slot1155, align 8
  %cmp6732 = icmp ne i64 %v6731, 0
  %cv6733 = zext i1 %cmp6732 to i32
  store i32 %cv6733, ptr %slot1156, align 8
  %v6734 = load i32, ptr %slot1156, align 8
  %cv6735 = zext i32 %v6734 to i64
  %cond6736 = icmp ne i64 %cv6735, 0
  br i1 %cond6736, label %bb_rcgdec1489, label %bb_rcgslow1489
bb_rcgslow1489:
  %v6737 = load i64, ptr %slot1143, align 8
  %v6738 = load i64, ptr %slot1126, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v6737, i64 %v6738) nomerge, !dbg !184
  br label %bb_rcgdone1489
bb_rcgdec1489:
  %v6739 = load i64, ptr %slot1152, align 8
  %v6740 = load i64, ptr %slot1144, align 8
  %p6741 = inttoptr i64 %v6740 to ptr
  %rgep6742 = getelementptr i8, ptr %p6741, i64 -32
  store i64 %v6739, ptr %rgep6742, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1489
bb_rcgclear1489:
  %v6743 = load i64, ptr %slot1126, align 8
  %p6744 = inttoptr i64 %v6743 to ptr
  store i64 0, ptr %p6744, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1489
bb_rcgdone1489:
  br label %bb_rcslotdone1458
bb_rcslotdone1458:
  %v6745 = load i64, ptr %slot46, align 8
  store i64 %v6745, ptr %slot1157, align 8
  %v6746 = load i64, ptr %slot1123, align 8
  %p6747 = inttoptr i64 %v6746 to ptr
  %ld6748 = load i64, ptr %p6747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6748, ptr %slot1158, align 8
  %v6749 = load i64, ptr %slot1158, align 8
  %v6750 = load i64, ptr %slot1157, align 8
  %p6751 = inttoptr i64 %v6750 to ptr
  store i64 %v6749, ptr %p6751, align 8, !alias.scope !3, !noalias !4
  %v6752 = load i64, ptr %slot18, align 8
  %p6753 = inttoptr i64 %v6752 to ptr
  store i32 2, ptr %p6753, align 4, !alias.scope !3, !noalias !4
  %v6754 = load i64, ptr %slot18, align 8
  %p6755 = inttoptr i64 %v6754 to ptr
  store i32 8, ptr %p6755, align 4, !alias.scope !3, !noalias !4
  %v6756 = load i64, ptr %slot17, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  store i32 1, ptr %p6757, align 4, !alias.scope !3, !noalias !4
  %v6758 = load i64, ptr %slot27, align 8
  %p6759 = inttoptr i64 %v6758 to ptr
  store i32 0, ptr %p6759, align 4, !alias.scope !3, !noalias !4
  %v6760 = load i64, ptr %slot58, align 8
  %p6761 = inttoptr i64 %v6760 to ptr
  store i64 0, ptr %p6761, align 8, !alias.scope !3, !noalias !4
  %v6762 = load i64, ptr %slot58, align 8
  %p6763 = inttoptr i64 %v6762 to ptr
  %ld6764 = load i64, ptr %p6763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6764, ptr %slot1159, align 8
  %v6765 = load i64, ptr %slot1159, align 8
  %v6766 = load i64, ptr %slot47, align 8
  %p6767 = inttoptr i64 %v6766 to ptr
  store i64 %v6765, ptr %p6767, align 8, !alias.scope !3, !noalias !4
  %v6768 = load i64, ptr %slot46, align 8
  %p6769 = inttoptr i64 %v6768 to ptr
  %ld6770 = load i64, ptr %p6769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6770, ptr %slot1160, align 8
  %v6771 = load i64, ptr %slot1160, align 8
  %op6772 = add i64 %v6771, 0
  store i64 %op6772, ptr %slot1161, align 8
  %v6773 = load i64, ptr %slot1161, align 8
  %p6774 = inttoptr i64 %v6773 to ptr
  %ld6775 = load i64, ptr %p6774, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6775, ptr %slot1162, align 8
  %v6776 = load i64, ptr %slot1162, align 8
  %v6777 = load i64, ptr %slot58, align 8
  %p6778 = inttoptr i64 %v6777 to ptr
  store i64 %v6776, ptr %p6778, align 8, !alias.scope !3, !noalias !4
  %v6779 = load i64, ptr %slot58, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  %ld6781 = load i64, ptr %p6780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6781, ptr %slot1163, align 8
  %v6782 = load i64, ptr %slot1163, align 8
  %cmp6783 = icmp ugt i64 %v6782, 9223372036854775807
  %cv6784 = zext i1 %cmp6783 to i64
  store i64 %cv6784, ptr %slot1164, align 8
  %v6785 = load i64, ptr %slot1164, align 8
  %cond6786 = icmp ne i64 %v6785, 0
  br i1 %cond6786, label %bb_cast_overflow1505, label %bb_cast_ok1505
bb_cast_overflow1505:
  %v6787 = load i64, ptr %slot1, align 8
  %p6788 = inttoptr i64 %v6787 to ptr
  %v6789 = load i64, ptr %slot1163, align 8
  call void @myl_qbe_fail_cast(ptr %p6788, i64 %v6789, i64 320) nomerge, !dbg !186
  unreachable
bb_cast_ok1505:
  %v6790 = load i64, ptr %slot1163, align 8
  %v6791 = load i64, ptr %slot58, align 8
  %p6792 = inttoptr i64 %v6791 to ptr
  store i64 %v6790, ptr %p6792, align 8, !alias.scope !3, !noalias !4
  %v6793 = load i64, ptr %slot58, align 8
  %p6794 = inttoptr i64 %v6793 to ptr
  %ld6795 = load i64, ptr %p6794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6795, ptr %slot1165, align 8
  %v6796 = load i64, ptr %slot1165, align 8
  %v6797 = load i64, ptr %slot48, align 8
  %p6798 = inttoptr i64 %v6797 to ptr
  store i64 %v6796, ptr %p6798, align 8, !alias.scope !3, !noalias !4
  br label %bb_i108
bb_i108:
  %v6799 = load i64, ptr %slot47, align 8
  %p6800 = inttoptr i64 %v6799 to ptr
  %ld6801 = load i64, ptr %p6800, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6801, ptr %slot1166, align 8
  %v6802 = load i64, ptr %slot1166, align 8
  %v6803 = load i64, ptr %slot58, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  store i64 %v6802, ptr %p6804, align 8, !alias.scope !3, !noalias !4
  %v6805 = load i64, ptr %slot48, align 8
  %p6806 = inttoptr i64 %v6805 to ptr
  %ld6807 = load i64, ptr %p6806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6807, ptr %slot1167, align 8
  %v6808 = load i64, ptr %slot1167, align 8
  %v6809 = load i64, ptr %slot59, align 8
  %p6810 = inttoptr i64 %v6809 to ptr
  store i64 %v6808, ptr %p6810, align 8, !alias.scope !3, !noalias !4
  %v6811 = load i64, ptr %slot59, align 8
  %p6812 = inttoptr i64 %v6811 to ptr
  %ld6813 = load i64, ptr %p6812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6813, ptr %slot1168, align 8
  %v6814 = load i64, ptr %slot58, align 8
  %p6815 = inttoptr i64 %v6814 to ptr
  %ld6816 = load i64, ptr %p6815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6816, ptr %slot1169, align 8
  %v6817 = load i64, ptr %slot1169, align 8
  %v6818 = load i64, ptr %slot1168, align 8
  %cmp6819 = icmp slt i64 %v6817, %v6818
  %cv6820 = zext i1 %cmp6819 to i64
  store i64 %cv6820, ptr %slot1170, align 8
  %v6821 = load i64, ptr %slot1170, align 8
  %v6822 = load i64, ptr %slot58, align 8
  %p6823 = inttoptr i64 %v6822 to ptr
  store i64 %v6821, ptr %p6823, align 8, !alias.scope !3, !noalias !4
  %v6824 = load i64, ptr %slot58, align 8
  %p6825 = inttoptr i64 %v6824 to ptr
  %ld6826 = load i64, ptr %p6825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6826, ptr %slot1171, align 8
  %v6827 = load i64, ptr %slot1171, align 8
  %cond6828 = icmp ne i64 %v6827, 0
  br i1 %cond6828, label %bb_next1513, label %bb_i130
bb_next1513:
  %v6829 = load i64, ptr %slot48, align 8
  %p6830 = inttoptr i64 %v6829 to ptr
  %ld6831 = load i64, ptr %p6830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6831, ptr %slot1172, align 8
  %v6832 = load i64, ptr %slot1172, align 8
  %v6833 = load i64, ptr %slot58, align 8
  %p6834 = inttoptr i64 %v6833 to ptr
  store i64 %v6832, ptr %p6834, align 8, !alias.scope !3, !noalias !4
  %v6835 = load i64, ptr %slot46, align 8
  %p6836 = inttoptr i64 %v6835 to ptr
  %ld6837 = load i64, ptr %p6836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6837, ptr %slot1173, align 8
  %v6838 = load i64, ptr %slot58, align 8
  %p6839 = inttoptr i64 %v6838 to ptr
  %ld6840 = load i64, ptr %p6839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6840, ptr %slot1174, align 8
  %v6841 = load i64, ptr %slot1173, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  %ld6843 = load i64, ptr %p6842, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6843, ptr %slot1175, align 8
  %v6844 = load i64, ptr %slot1175, align 8
  %v6845 = load i64, ptr %slot1174, align 8
  %cmp6846 = icmp eq i64 %v6844, %v6845
  %cv6847 = zext i1 %cmp6846 to i64
  store i64 %cv6847, ptr %slot1176, align 8
  %v6848 = load i64, ptr %slot1176, align 8
  %cond6849 = icmp ne i64 %v6848, 0
  br i1 %cond6849, label %bb_success1518, label %bb_failed1518
bb_failed1518:
  %v6850 = load i64, ptr %slot1, align 8
  %p6851 = inttoptr i64 %v6850 to ptr
  call void @myl_qbe_fail_iteration(ptr %p6851) nomerge, !dbg !188
  unreachable
bb_success1518:
  %v6852 = load i64, ptr %slot58, align 8
  %p6853 = inttoptr i64 %v6852 to ptr
  store i64 0, ptr %p6853, align 8, !alias.scope !3, !noalias !4
  %v6854 = load i64, ptr %slot47, align 8
  %p6855 = inttoptr i64 %v6854 to ptr
  %ld6856 = load i64, ptr %p6855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6856, ptr %slot1177, align 8
  %v6857 = load i64, ptr %slot1177, align 8
  %v6858 = load i64, ptr %slot58, align 8
  %p6859 = inttoptr i64 %v6858 to ptr
  store i64 %v6857, ptr %p6859, align 8, !alias.scope !3, !noalias !4
  %v6860 = load i64, ptr %slot46, align 8
  %p6861 = inttoptr i64 %v6860 to ptr
  %ld6862 = load i64, ptr %p6861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6862, ptr %slot1178, align 8
  %v6863 = load i64, ptr %slot58, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  %ld6865 = load i64, ptr %p6864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6865, ptr %slot1179, align 8
  %v6866 = load i64, ptr %slot1178, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  %ld6868 = load i64, ptr %p6867, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6868, ptr %slot1180, align 8
  %v6869 = load i64, ptr %slot1179, align 8
  %v6870 = load i64, ptr %slot1180, align 8
  %cmp6871 = icmp ult i64 %v6869, %v6870
  %cv6872 = zext i1 %cmp6871 to i64
  store i64 %cv6872, ptr %slot1181, align 8
  %v6873 = load i64, ptr %slot1181, align 8
  %cond6874 = icmp ne i64 %v6873, 0
  br i1 %cond6874, label %bb_success1525, label %bb_failed1525
bb_failed1525:
  %v6875 = load i64, ptr %slot1, align 8
  %p6876 = inttoptr i64 %v6875 to ptr
  %v6877 = load i64, ptr %slot1179, align 8
  %v6878 = load i64, ptr %slot1180, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p6876, i64 %v6877, i64 %v6878) nomerge, !dbg !190
  unreachable
bb_success1525:
  %v6879 = load i64, ptr %slot1178, align 8
  %op6880 = add i64 %v6879, 32
  store i64 %op6880, ptr %slot1182, align 8
  %v6881 = load i64, ptr %slot1182, align 8
  %p6882 = inttoptr i64 %v6881 to ptr
  %ld6883 = load i64, ptr %p6882, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6883, ptr %slot1183, align 8
  %v6884 = load i64, ptr %slot1179, align 8
  %op6885 = mul i64 %v6884, 16
  store i64 %op6885, ptr %slot1184, align 8
  %v6886 = load i64, ptr %slot1183, align 8
  %v6887 = load i64, ptr %slot1184, align 8
  %op6888 = add i64 %v6886, %v6887
  store i64 %op6888, ptr %slot1185, align 8
  %v6889 = load i64, ptr %slot1185, align 8
  %v6890 = load i64, ptr %slot58, align 8
  %p6891 = inttoptr i64 %v6890 to ptr
  store i64 %v6889, ptr %p6891, align 8, !alias.scope !3, !noalias !4
  %v6892 = load i64, ptr %slot58, align 8
  %p6893 = inttoptr i64 %v6892 to ptr
  %ld6894 = load i64, ptr %p6893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6894, ptr %slot1186, align 8
  %v6895 = load i64, ptr %slot1186, align 8
  %v6896 = load i64, ptr %slot49, align 8
  %p6897 = inttoptr i64 %v6895 to ptr
  %p6898 = inttoptr i64 %v6896 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6898, ptr %p6897, i64 16, i1 false), !alias.scope !10000001
  %v6899 = load i64, ptr %slot35, align 8
  %v6900 = load i64, ptr %slot58, align 8
  %p6901 = inttoptr i64 %v6900 to ptr
  store i64 %v6899, ptr %p6901, align 8, !alias.scope !3, !noalias !4
  %v6902 = load i64, ptr %slot49, align 8
  %v6903 = load i64, ptr %slot59, align 8
  %p6904 = inttoptr i64 %v6903 to ptr
  store i64 %v6902, ptr %p6904, align 8, !alias.scope !3, !noalias !4
  %v6905 = load i64, ptr %slot58, align 8
  %p6906 = inttoptr i64 %v6905 to ptr
  %ld6907 = load i64, ptr %p6906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6907, ptr %slot1187, align 8
  %v6908 = load i64, ptr %slot59, align 8
  %p6909 = inttoptr i64 %v6908 to ptr
  %ld6910 = load i64, ptr %p6909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6910, ptr %slot1188, align 8
  %v6911 = load i64, ptr %slot1, align 8
  %v6912 = load i64, ptr %slot1187, align 8
  %v6913 = load i64, ptr %slot1188, align 8
  %call6914 = call i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64 %v6911, i64 %v6912, i64 %v6913) nomerge, !dbg !192
  store i64 %call6914, ptr %slot1189, align 8
  %v6915 = load i64, ptr %slot1189, align 8
  %v6916 = load i64, ptr %slot58, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  store i64 %v6915, ptr %p6917, align 8, !alias.scope !3, !noalias !4
  %v6918 = load i64, ptr %slot23, align 8
  %p6919 = inttoptr i64 %v6918 to ptr
  %ld6920 = load i32, ptr %p6919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6920, ptr %slot1190, align 8
  %v6921 = load i32, ptr %slot1190, align 8
  %cv6922 = zext i32 %v6921 to i64
  %cond6923 = icmp ne i64 %cv6922, 0
  br i1 %cond6923, label %bb_rcslotdrop1536, label %bb_rcslotdone1536
bb_rcslotdrop1536:
  %v6924 = load i64, ptr %slot23, align 8
  %p6925 = inttoptr i64 %v6924 to ptr
  store i32 0, ptr %p6925, align 4, !alias.scope !3, !noalias !4
  %v6926 = load i64, ptr %slot29, align 8
  store i64 %v6926, ptr %slot1191, align 8
  %v6927 = load i64, ptr %slot24, align 8
  %p6928 = inttoptr i64 %v6927 to ptr
  %ld6929 = load i32, ptr %p6928, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6929, ptr %slot1192, align 8
  %v6930 = load i32, ptr %slot1192, align 8
  %op6931 = and i32 %v6930, 28
  store i32 %op6931, ptr %slot1193, align 8
  %v6932 = load i32, ptr %slot1193, align 8
  %cv6933 = zext i32 %v6932 to i64
  %cond6934 = icmp ne i64 %cv6933, 0
  br i1 %cond6934, label %bb_rcslotrole1536, label %bb_rcslotowner1536
bb_rcslotrole1536:
  %v6935 = load i64, ptr %slot65, align 8
  store i64 %v6935, ptr %slot1194, align 8
  %v6936 = load i64, ptr %slot1194, align 8
  %v6937 = load i64, ptr %slot1191, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v6936, i64 %v6937) nomerge, !dbg !192
  br label %bb_rcslotdone1536
bb_rcslotowner1536:
  %v6938 = load i64, ptr %slot65, align 8
  store i64 %v6938, ptr %slot1195, align 8
  %v6939 = load i64, ptr %slot1195, align 8
  %v6940 = load i64, ptr %slot1191, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v6939, i64 %v6940) nomerge, !dbg !192
  br label %bb_rcslotdone1536
bb_rcslotdone1536:
  %v6941 = load i64, ptr %slot48, align 8
  %p6942 = inttoptr i64 %v6941 to ptr
  %ld6943 = load i64, ptr %p6942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6943, ptr %slot1196, align 8
  %v6944 = load i64, ptr %slot1196, align 8
  %v6945 = load i64, ptr %slot58, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  store i64 %v6944, ptr %p6946, align 8, !alias.scope !3, !noalias !4
  %v6947 = load i64, ptr %slot46, align 8
  %p6948 = inttoptr i64 %v6947 to ptr
  %ld6949 = load i64, ptr %p6948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6949, ptr %slot1197, align 8
  %v6950 = load i64, ptr %slot58, align 8
  %p6951 = inttoptr i64 %v6950 to ptr
  %ld6952 = load i64, ptr %p6951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6952, ptr %slot1198, align 8
  %v6953 = load i64, ptr %slot1197, align 8
  %p6954 = inttoptr i64 %v6953 to ptr
  %ld6955 = load i64, ptr %p6954, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6955, ptr %slot1199, align 8
  %v6956 = load i64, ptr %slot1199, align 8
  %v6957 = load i64, ptr %slot1198, align 8
  %cmp6958 = icmp eq i64 %v6956, %v6957
  %cv6959 = zext i1 %cmp6958 to i64
  store i64 %cv6959, ptr %slot1200, align 8
  %v6960 = load i64, ptr %slot1200, align 8
  %cond6961 = icmp ne i64 %v6960, 0
  br i1 %cond6961, label %bb_success1548, label %bb_failed1548
bb_failed1548:
  %v6962 = load i64, ptr %slot1, align 8
  %p6963 = inttoptr i64 %v6962 to ptr
  call void @myl_qbe_fail_iteration(ptr %p6963) nomerge, !dbg !194
  unreachable
bb_success1548:
  %v6964 = load i64, ptr %slot58, align 8
  %p6965 = inttoptr i64 %v6964 to ptr
  store i64 0, ptr %p6965, align 8, !alias.scope !3, !noalias !4
  %v6966 = load i64, ptr %slot47, align 8
  %p6967 = inttoptr i64 %v6966 to ptr
  %ld6968 = load i64, ptr %p6967, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6968, ptr %slot1201, align 8
  %v6969 = load i64, ptr %slot1201, align 8
  %v6970 = load i64, ptr %slot58, align 8
  %p6971 = inttoptr i64 %v6970 to ptr
  store i64 %v6969, ptr %p6971, align 8, !alias.scope !3, !noalias !4
  %v6972 = load i64, ptr %slot59, align 8
  %p6973 = inttoptr i64 %v6972 to ptr
  store i64 1, ptr %p6973, align 8, !alias.scope !3, !noalias !4
  %v6974 = load i64, ptr %slot59, align 8
  %p6975 = inttoptr i64 %v6974 to ptr
  %ld6976 = load i64, ptr %p6975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6976, ptr %slot1202, align 8
  %v6977 = load i64, ptr %slot58, align 8
  %p6978 = inttoptr i64 %v6977 to ptr
  %ld6979 = load i64, ptr %p6978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6979, ptr %slot1203, align 8
  %v6980 = load i64, ptr %slot1203, align 8
  %v6981 = load i64, ptr %slot1202, align 8
  %ovpair6983 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6980, i64 %v6981)
  %op6982 = extractvalue { i64, i1 } %ovpair6983, 0
  %ov6984 = extractvalue { i64, i1 } %ovpair6983, 1
  store i64 %op6982, ptr %slot1204, align 8
  %cv6985 = zext i1 %ov6984 to i64
  store i64 %cv6985, ptr %slot1205, align 8
  %v6986 = load i64, ptr %slot1205, align 8
  %cond6987 = icmp ne i64 %v6986, 0
  br i1 %cond6987, label %bb_overflow1552, label %bb_checked1552
bb_overflow1552:
  %v6988 = load i64, ptr %slot1, align 8
  %p6989 = inttoptr i64 %v6988 to ptr
  %v6990 = load i64, ptr %slot1203, align 8
  %v6991 = load i64, ptr %slot1202, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p6989, i64 0, i64 %v6990, i64 %v6991, i64 64) nomerge, !dbg !196
  unreachable
bb_checked1552:
  %v6992 = load i64, ptr %slot1204, align 8
  %v6993 = load i64, ptr %slot58, align 8
  %p6994 = inttoptr i64 %v6993 to ptr
  store i64 %v6992, ptr %p6994, align 8, !alias.scope !3, !noalias !4
  %v6995 = load i64, ptr %slot58, align 8
  %p6996 = inttoptr i64 %v6995 to ptr
  %ld6997 = load i64, ptr %p6996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6997, ptr %slot1206, align 8
  %v6998 = load i64, ptr %slot1206, align 8
  %v6999 = load i64, ptr %slot47, align 8
  %p7000 = inttoptr i64 %v6999 to ptr
  store i64 %v6998, ptr %p7000, align 8, !alias.scope !3, !noalias !4
  br label %bb_i108
bb_i130:
  %v7001 = load i64, ptr %slot15, align 8
  %p7002 = inttoptr i64 %v7001 to ptr
  %ld7003 = load i32, ptr %p7002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7003, ptr %slot1207, align 8
  %v7004 = load i32, ptr %slot1207, align 8
  %cv7005 = zext i32 %v7004 to i64
  %cond7006 = icmp ne i64 %cv7005, 0
  br i1 %cond7006, label %bb_rcslotdrop1557, label %bb_rcslotdone1557
bb_rcslotdrop1557:
  %v7007 = load i64, ptr %slot15, align 8
  %p7008 = inttoptr i64 %v7007 to ptr
  store i32 0, ptr %p7008, align 4, !alias.scope !3, !noalias !4
  %v7009 = load i64, ptr %slot45, align 8
  store i64 %v7009, ptr %slot1208, align 8
  %v7010 = load i64, ptr %slot16, align 8
  %p7011 = inttoptr i64 %v7010 to ptr
  %ld7012 = load i32, ptr %p7011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7012, ptr %slot1209, align 8
  %v7013 = load i32, ptr %slot1209, align 8
  %op7014 = and i32 %v7013, 28
  store i32 %op7014, ptr %slot1210, align 8
  %v7015 = load i32, ptr %slot1210, align 8
  %cv7016 = zext i32 %v7015 to i64
  %cond7017 = icmp ne i64 %cv7016, 0
  br i1 %cond7017, label %bb_rcslotrole1557, label %bb_rcslotowner1557
bb_rcslotrole1557:
  %v7018 = load i64, ptr %slot65, align 8
  store i64 %v7018, ptr %slot1211, align 8
  %v7019 = load i64, ptr %slot1211, align 8
  %v7020 = load i64, ptr %slot1208, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v7019, i64 %v7020) nomerge, !dbg !198
  br label %bb_rcslotdone1557
bb_rcslotowner1557:
  %v7021 = load i64, ptr %slot1208, align 8
  %p7023 = inttoptr i64 %v7021 to ptr
  %gep7024 = getelementptr i8, ptr %p7023, i64 16
  %op7022 = ptrtoint ptr %gep7024 to i64
  store i64 %op7022, ptr %slot1212, align 8
  %v7025 = load i64, ptr %slot65, align 8
  store i64 %v7025, ptr %slot1213, align 8
  %v7026 = load i64, ptr %slot1212, align 8
  %p7027 = inttoptr i64 %v7026 to ptr
  %ld7028 = load i64, ptr %p7027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7028, ptr %slot1214, align 8
  %v7029 = load i64, ptr %slot1214, align 8
  %cmp7030 = icmp ne i64 %v7029, 0
  %cv7031 = zext i1 %cmp7030 to i32
  store i32 %cv7031, ptr %slot1215, align 8
  %v7032 = load i32, ptr %slot1215, align 8
  %cv7033 = zext i32 %v7032 to i64
  %cond7034 = icmp ne i64 %cv7033, 0
  br i1 %cond7034, label %bb_rcgnn1575, label %bb_rcgdone1575
bb_rcgnn1575:
  %v7035 = load i64, ptr %slot1214, align 8
  %op7036 = sub i64 %v7035, 16
  store i64 %op7036, ptr %slot1216, align 8
  %v7037 = load i64, ptr %slot1214, align 8
  %p7038 = inttoptr i64 %v7037 to ptr
  %rgep7039 = getelementptr i8, ptr %p7038, i64 -16
  %ld7040 = load i64, ptr %rgep7039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7040, ptr %slot1217, align 8
  %v7041 = load i64, ptr %slot1217, align 8
  %op7042 = and i64 %v7041, 4611686018427387906
  store i64 %op7042, ptr %slot1218, align 8
  %v7043 = load i64, ptr %slot1218, align 8
  %cmp7044 = icmp ne i64 %v7043, 0
  %cv7045 = zext i1 %cmp7044 to i32
  store i32 %cv7045, ptr %slot1219, align 8
  %v7046 = load i32, ptr %slot1219, align 8
  %cv7047 = zext i32 %v7046 to i64
  %cond7048 = icmp ne i64 %cv7047, 0
  br i1 %cond7048, label %bb_rcgclear1575, label %bb_rcgcounted1575
bb_rcgcounted1575:
  %v7049 = load i64, ptr %slot1214, align 8
  %op7050 = sub i64 %v7049, 32
  store i64 %op7050, ptr %slot1220, align 8
  %v7051 = load i64, ptr %slot1214, align 8
  %p7052 = inttoptr i64 %v7051 to ptr
  %rgep7053 = getelementptr i8, ptr %p7052, i64 -32
  %ld7054 = load i64, ptr %rgep7053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7054, ptr %slot1221, align 8
  %v7055 = load i64, ptr %slot1221, align 8
  %op7056 = sub i64 %v7055, 1
  store i64 %op7056, ptr %slot1222, align 8
  %v7057 = load i64, ptr %slot1222, align 8
  %cmp7058 = icmp eq i64 %v7057, 0
  %cv7059 = zext i1 %cmp7058 to i32
  store i32 %cv7059, ptr %slot1223, align 8
  %v7060 = load i32, ptr %slot1223, align 8
  %cv7061 = zext i32 %v7060 to i64
  %cond7062 = icmp ne i64 %cv7061, 0
  br i1 %cond7062, label %bb_rcglast1575, label %bb_rcgdec1575
bb_rcglast1575:
  %v7063 = load i64, ptr %slot1214, align 8
  %op7064 = sub i64 %v7063, 24
  store i64 %op7064, ptr %slot1224, align 8
  %v7065 = load i64, ptr %slot1214, align 8
  %p7066 = inttoptr i64 %v7065 to ptr
  %rgep7067 = getelementptr i8, ptr %p7066, i64 -24
  %ld7068 = load i64, ptr %rgep7067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7068, ptr %slot1225, align 8
  %v7069 = load i64, ptr %slot1225, align 8
  %cmp7070 = icmp ne i64 %v7069, 0
  %cv7071 = zext i1 %cmp7070 to i32
  store i32 %cv7071, ptr %slot1226, align 8
  %v7072 = load i32, ptr %slot1226, align 8
  %cv7073 = zext i32 %v7072 to i64
  %cond7074 = icmp ne i64 %cv7073, 0
  br i1 %cond7074, label %bb_rcgdec1575, label %bb_rcgslow1575
bb_rcgslow1575:
  %v7075 = load i64, ptr %slot1213, align 8
  %v7076 = load i64, ptr %slot1212, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7075, i64 %v7076) nomerge, !dbg !198
  br label %bb_rcgdone1575
bb_rcgdec1575:
  %v7077 = load i64, ptr %slot1222, align 8
  %v7078 = load i64, ptr %slot1214, align 8
  %p7079 = inttoptr i64 %v7078 to ptr
  %rgep7080 = getelementptr i8, ptr %p7079, i64 -32
  store i64 %v7077, ptr %rgep7080, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1575
bb_rcgclear1575:
  %v7081 = load i64, ptr %slot1212, align 8
  %p7082 = inttoptr i64 %v7081 to ptr
  store i64 0, ptr %p7082, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1575
bb_rcgdone1575:
  %v7083 = load i64, ptr %slot1208, align 8
  %p7085 = inttoptr i64 %v7083 to ptr
  %gep7086 = getelementptr i8, ptr %p7085, i64 24
  %op7084 = ptrtoint ptr %gep7086 to i64
  store i64 %op7084, ptr %slot1227, align 8
  %v7087 = load i64, ptr %slot65, align 8
  store i64 %v7087, ptr %slot1228, align 8
  %v7088 = load i64, ptr %slot1227, align 8
  %p7089 = inttoptr i64 %v7088 to ptr
  %ld7090 = load i64, ptr %p7089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7090, ptr %slot1229, align 8
  %v7091 = load i64, ptr %slot1229, align 8
  %cmp7092 = icmp ne i64 %v7091, 0
  %cv7093 = zext i1 %cmp7092 to i32
  store i32 %cv7093, ptr %slot1230, align 8
  %v7094 = load i32, ptr %slot1230, align 8
  %cv7095 = zext i32 %v7094 to i64
  %cond7096 = icmp ne i64 %cv7095, 0
  br i1 %cond7096, label %bb_rcgnn1591, label %bb_rcgdone1591
bb_rcgnn1591:
  %v7097 = load i64, ptr %slot1229, align 8
  %op7098 = sub i64 %v7097, 16
  store i64 %op7098, ptr %slot1231, align 8
  %v7099 = load i64, ptr %slot1229, align 8
  %p7100 = inttoptr i64 %v7099 to ptr
  %rgep7101 = getelementptr i8, ptr %p7100, i64 -16
  %ld7102 = load i64, ptr %rgep7101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7102, ptr %slot1232, align 8
  %v7103 = load i64, ptr %slot1232, align 8
  %op7104 = and i64 %v7103, 4611686018427387906
  store i64 %op7104, ptr %slot1233, align 8
  %v7105 = load i64, ptr %slot1233, align 8
  %cmp7106 = icmp ne i64 %v7105, 0
  %cv7107 = zext i1 %cmp7106 to i32
  store i32 %cv7107, ptr %slot1234, align 8
  %v7108 = load i32, ptr %slot1234, align 8
  %cv7109 = zext i32 %v7108 to i64
  %cond7110 = icmp ne i64 %cv7109, 0
  br i1 %cond7110, label %bb_rcgclear1591, label %bb_rcgcounted1591
bb_rcgcounted1591:
  %v7111 = load i64, ptr %slot1229, align 8
  %op7112 = sub i64 %v7111, 32
  store i64 %op7112, ptr %slot1235, align 8
  %v7113 = load i64, ptr %slot1229, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  %rgep7115 = getelementptr i8, ptr %p7114, i64 -32
  %ld7116 = load i64, ptr %rgep7115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7116, ptr %slot1236, align 8
  %v7117 = load i64, ptr %slot1236, align 8
  %op7118 = sub i64 %v7117, 1
  store i64 %op7118, ptr %slot1237, align 8
  %v7119 = load i64, ptr %slot1237, align 8
  %cmp7120 = icmp eq i64 %v7119, 0
  %cv7121 = zext i1 %cmp7120 to i32
  store i32 %cv7121, ptr %slot1238, align 8
  %v7122 = load i32, ptr %slot1238, align 8
  %cv7123 = zext i32 %v7122 to i64
  %cond7124 = icmp ne i64 %cv7123, 0
  br i1 %cond7124, label %bb_rcglast1591, label %bb_rcgdec1591
bb_rcglast1591:
  %v7125 = load i64, ptr %slot1229, align 8
  %op7126 = sub i64 %v7125, 24
  store i64 %op7126, ptr %slot1239, align 8
  %v7127 = load i64, ptr %slot1229, align 8
  %p7128 = inttoptr i64 %v7127 to ptr
  %rgep7129 = getelementptr i8, ptr %p7128, i64 -24
  %ld7130 = load i64, ptr %rgep7129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7130, ptr %slot1240, align 8
  %v7131 = load i64, ptr %slot1240, align 8
  %cmp7132 = icmp ne i64 %v7131, 0
  %cv7133 = zext i1 %cmp7132 to i32
  store i32 %cv7133, ptr %slot1241, align 8
  %v7134 = load i32, ptr %slot1241, align 8
  %cv7135 = zext i32 %v7134 to i64
  %cond7136 = icmp ne i64 %cv7135, 0
  br i1 %cond7136, label %bb_rcgdec1591, label %bb_rcgslow1591
bb_rcgslow1591:
  %v7137 = load i64, ptr %slot1228, align 8
  %v7138 = load i64, ptr %slot1227, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7137, i64 %v7138) nomerge, !dbg !198
  br label %bb_rcgdone1591
bb_rcgdec1591:
  %v7139 = load i64, ptr %slot1237, align 8
  %v7140 = load i64, ptr %slot1229, align 8
  %p7141 = inttoptr i64 %v7140 to ptr
  %rgep7142 = getelementptr i8, ptr %p7141, i64 -32
  store i64 %v7139, ptr %rgep7142, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1591
bb_rcgclear1591:
  %v7143 = load i64, ptr %slot1227, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  store i64 0, ptr %p7144, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1591
bb_rcgdone1591:
  %v7145 = load i64, ptr %slot1208, align 8
  %p7147 = inttoptr i64 %v7145 to ptr
  %gep7148 = getelementptr i8, ptr %p7147, i64 32
  %op7146 = ptrtoint ptr %gep7148 to i64
  store i64 %op7146, ptr %slot1242, align 8
  %v7149 = load i64, ptr %slot65, align 8
  store i64 %v7149, ptr %slot1243, align 8
  %v7150 = load i64, ptr %slot1242, align 8
  %p7151 = inttoptr i64 %v7150 to ptr
  %ld7152 = load i64, ptr %p7151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7152, ptr %slot1244, align 8
  %v7153 = load i64, ptr %slot1244, align 8
  %cmp7154 = icmp ne i64 %v7153, 0
  %cv7155 = zext i1 %cmp7154 to i32
  store i32 %cv7155, ptr %slot1245, align 8
  %v7156 = load i32, ptr %slot1245, align 8
  %cv7157 = zext i32 %v7156 to i64
  %cond7158 = icmp ne i64 %cv7157, 0
  br i1 %cond7158, label %bb_rcgnn1607, label %bb_rcgdone1607
bb_rcgnn1607:
  %v7159 = load i64, ptr %slot1244, align 8
  %op7160 = sub i64 %v7159, 16
  store i64 %op7160, ptr %slot1246, align 8
  %v7161 = load i64, ptr %slot1244, align 8
  %p7162 = inttoptr i64 %v7161 to ptr
  %rgep7163 = getelementptr i8, ptr %p7162, i64 -16
  %ld7164 = load i64, ptr %rgep7163, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7164, ptr %slot1247, align 8
  %v7165 = load i64, ptr %slot1247, align 8
  %op7166 = and i64 %v7165, 4611686018427387906
  store i64 %op7166, ptr %slot1248, align 8
  %v7167 = load i64, ptr %slot1248, align 8
  %cmp7168 = icmp ne i64 %v7167, 0
  %cv7169 = zext i1 %cmp7168 to i32
  store i32 %cv7169, ptr %slot1249, align 8
  %v7170 = load i32, ptr %slot1249, align 8
  %cv7171 = zext i32 %v7170 to i64
  %cond7172 = icmp ne i64 %cv7171, 0
  br i1 %cond7172, label %bb_rcgclear1607, label %bb_rcgcounted1607
bb_rcgcounted1607:
  %v7173 = load i64, ptr %slot1244, align 8
  %op7174 = sub i64 %v7173, 32
  store i64 %op7174, ptr %slot1250, align 8
  %v7175 = load i64, ptr %slot1244, align 8
  %p7176 = inttoptr i64 %v7175 to ptr
  %rgep7177 = getelementptr i8, ptr %p7176, i64 -32
  %ld7178 = load i64, ptr %rgep7177, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7178, ptr %slot1251, align 8
  %v7179 = load i64, ptr %slot1251, align 8
  %op7180 = sub i64 %v7179, 1
  store i64 %op7180, ptr %slot1252, align 8
  %v7181 = load i64, ptr %slot1252, align 8
  %cmp7182 = icmp eq i64 %v7181, 0
  %cv7183 = zext i1 %cmp7182 to i32
  store i32 %cv7183, ptr %slot1253, align 8
  %v7184 = load i32, ptr %slot1253, align 8
  %cv7185 = zext i32 %v7184 to i64
  %cond7186 = icmp ne i64 %cv7185, 0
  br i1 %cond7186, label %bb_rcglast1607, label %bb_rcgdec1607
bb_rcglast1607:
  %v7187 = load i64, ptr %slot1244, align 8
  %op7188 = sub i64 %v7187, 24
  store i64 %op7188, ptr %slot1254, align 8
  %v7189 = load i64, ptr %slot1244, align 8
  %p7190 = inttoptr i64 %v7189 to ptr
  %rgep7191 = getelementptr i8, ptr %p7190, i64 -24
  %ld7192 = load i64, ptr %rgep7191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7192, ptr %slot1255, align 8
  %v7193 = load i64, ptr %slot1255, align 8
  %cmp7194 = icmp ne i64 %v7193, 0
  %cv7195 = zext i1 %cmp7194 to i32
  store i32 %cv7195, ptr %slot1256, align 8
  %v7196 = load i32, ptr %slot1256, align 8
  %cv7197 = zext i32 %v7196 to i64
  %cond7198 = icmp ne i64 %cv7197, 0
  br i1 %cond7198, label %bb_rcgdec1607, label %bb_rcgslow1607
bb_rcgslow1607:
  %v7199 = load i64, ptr %slot1243, align 8
  %v7200 = load i64, ptr %slot1242, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v7199, i64 %v7200) nomerge, !dbg !198
  br label %bb_rcgdone1607
bb_rcgdec1607:
  %v7201 = load i64, ptr %slot1252, align 8
  %v7202 = load i64, ptr %slot1244, align 8
  %p7203 = inttoptr i64 %v7202 to ptr
  %rgep7204 = getelementptr i8, ptr %p7203, i64 -32
  store i64 %v7201, ptr %rgep7204, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1607
bb_rcgclear1607:
  %v7205 = load i64, ptr %slot1242, align 8
  %p7206 = inttoptr i64 %v7205 to ptr
  store i64 0, ptr %p7206, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1607
bb_rcgdone1607:
  %v7207 = load i64, ptr %slot1208, align 8
  %p7208 = inttoptr i64 %v7207 to ptr
  store i64 0, ptr %p7208, align 8, !alias.scope !3, !noalias !4
  %v7209 = load i64, ptr %slot1208, align 8
  %p7211 = inttoptr i64 %v7209 to ptr
  %gep7212 = getelementptr i8, ptr %p7211, i64 8
  %op7210 = ptrtoint ptr %gep7212 to i64
  store i64 %op7210, ptr %slot1257, align 8
  %v7213 = load i64, ptr %slot1257, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  store i64 0, ptr %p7214, align 8, !alias.scope !3, !noalias !4
  %v7215 = load i64, ptr %slot1208, align 8
  %p7217 = inttoptr i64 %v7215 to ptr
  %gep7218 = getelementptr i8, ptr %p7217, i64 16
  %op7216 = ptrtoint ptr %gep7218 to i64
  store i64 %op7216, ptr %slot1258, align 8
  %v7219 = load i64, ptr %slot1258, align 8
  %p7220 = inttoptr i64 %v7219 to ptr
  store i64 0, ptr %p7220, align 8, !alias.scope !3, !noalias !4
  %v7221 = load i64, ptr %slot1208, align 8
  %p7223 = inttoptr i64 %v7221 to ptr
  %gep7224 = getelementptr i8, ptr %p7223, i64 24
  %op7222 = ptrtoint ptr %gep7224 to i64
  store i64 %op7222, ptr %slot1259, align 8
  %v7225 = load i64, ptr %slot1259, align 8
  %p7226 = inttoptr i64 %v7225 to ptr
  store i64 0, ptr %p7226, align 8, !alias.scope !3, !noalias !4
  %v7227 = load i64, ptr %slot1208, align 8
  %p7229 = inttoptr i64 %v7227 to ptr
  %gep7230 = getelementptr i8, ptr %p7229, i64 32
  %op7228 = ptrtoint ptr %gep7230 to i64
  store i64 %op7228, ptr %slot1260, align 8
  %v7231 = load i64, ptr %slot1260, align 8
  %p7232 = inttoptr i64 %v7231 to ptr
  store i64 0, ptr %p7232, align 8, !alias.scope !3, !noalias !4
  %v7233 = load i64, ptr %slot1208, align 8
  %p7235 = inttoptr i64 %v7233 to ptr
  %gep7236 = getelementptr i8, ptr %p7235, i64 40
  %op7234 = ptrtoint ptr %gep7236 to i64
  store i64 %op7234, ptr %slot1261, align 8
  %v7237 = load i64, ptr %slot1261, align 8
  %p7238 = inttoptr i64 %v7237 to ptr
  store i64 0, ptr %p7238, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1557
bb_rcslotdone1557:
  br label %bb_i198
bb_i132:
  %v7239 = load i64, ptr %slot35, align 8
  %v7240 = load i64, ptr %slot58, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  store i64 %v7239, ptr %p7241, align 8, !alias.scope !3, !noalias !4
  %v7242 = load i64, ptr %slot50, align 8
  %v7243 = load i64, ptr %slot59, align 8
  %p7244 = inttoptr i64 %v7243 to ptr
  store i64 %v7242, ptr %p7244, align 8, !alias.scope !3, !noalias !4
  %v7245 = load i64, ptr %slot59, align 8
  %p7246 = inttoptr i64 %v7245 to ptr
  %ld7247 = load i64, ptr %p7246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7247, ptr %slot1262, align 8
  %v7248 = load i64, ptr %slot1262, align 8
  %op7249 = add i64 %v7248, 8
  store i64 %op7249, ptr %slot1263, align 8
  %v7250 = load i64, ptr %slot1263, align 8
  %v7251 = load i64, ptr %slot59, align 8
  %p7252 = inttoptr i64 %v7251 to ptr
  store i64 %v7250, ptr %p7252, align 8, !alias.scope !3, !noalias !4
  %v7253 = load i64, ptr %slot58, align 8
  %p7254 = inttoptr i64 %v7253 to ptr
  %ld7255 = load i64, ptr %p7254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7255, ptr %slot1264, align 8
  %v7256 = load i64, ptr %slot59, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  %ld7258 = load i64, ptr %p7257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7258, ptr %slot1265, align 8
  %v7259 = load i64, ptr %slot1, align 8
  %v7260 = load i64, ptr %slot1264, align 8
  %v7261 = load i64, ptr %slot1265, align 8
  %call7262 = call i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64 %v7259, i64 %v7260, i64 %v7261) nomerge, !dbg !200
  store i64 %call7262, ptr %slot1266, align 8
  %v7263 = load i64, ptr %slot1266, align 8
  %v7264 = load i64, ptr %slot58, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  store i64 %v7263, ptr %p7265, align 8, !alias.scope !3, !noalias !4
  %v7266 = load i64, ptr %slot23, align 8
  %p7267 = inttoptr i64 %v7266 to ptr
  %ld7268 = load i32, ptr %p7267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7268, ptr %slot1267, align 8
  %v7269 = load i32, ptr %slot1267, align 8
  %cv7270 = zext i32 %v7269 to i64
  %cond7271 = icmp ne i64 %cv7270, 0
  br i1 %cond7271, label %bb_rcslotdrop1623, label %bb_rcslotdone1623
bb_rcslotdrop1623:
  %v7272 = load i64, ptr %slot23, align 8
  %p7273 = inttoptr i64 %v7272 to ptr
  store i32 0, ptr %p7273, align 4, !alias.scope !3, !noalias !4
  %v7274 = load i64, ptr %slot29, align 8
  store i64 %v7274, ptr %slot1268, align 8
  %v7275 = load i64, ptr %slot24, align 8
  %p7276 = inttoptr i64 %v7275 to ptr
  %ld7277 = load i32, ptr %p7276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7277, ptr %slot1269, align 8
  %v7278 = load i32, ptr %slot1269, align 8
  %op7279 = and i32 %v7278, 28
  store i32 %op7279, ptr %slot1270, align 8
  %v7280 = load i32, ptr %slot1270, align 8
  %cv7281 = zext i32 %v7280 to i64
  %cond7282 = icmp ne i64 %cv7281, 0
  br i1 %cond7282, label %bb_rcslotrole1623, label %bb_rcslotowner1623
bb_rcslotrole1623:
  %v7283 = load i64, ptr %slot65, align 8
  store i64 %v7283, ptr %slot1271, align 8
  %v7284 = load i64, ptr %slot1271, align 8
  %v7285 = load i64, ptr %slot1268, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v7284, i64 %v7285) nomerge, !dbg !200
  br label %bb_rcslotdone1623
bb_rcslotowner1623:
  %v7286 = load i64, ptr %slot65, align 8
  store i64 %v7286, ptr %slot1272, align 8
  %v7287 = load i64, ptr %slot1272, align 8
  %v7288 = load i64, ptr %slot1268, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v7287, i64 %v7288) nomerge, !dbg !200
  br label %bb_rcslotdone1623
bb_rcslotdone1623:
  br label %bb_i198
bb_i138:
  %v7289 = load i64, ptr %slot35, align 8
  %v7290 = load i64, ptr %slot58, align 8
  %p7291 = inttoptr i64 %v7290 to ptr
  store i64 %v7289, ptr %p7291, align 8, !alias.scope !3, !noalias !4
  %v7292 = load i64, ptr %slot51, align 8
  %v7293 = load i64, ptr %slot59, align 8
  %p7294 = inttoptr i64 %v7293 to ptr
  store i64 %v7292, ptr %p7294, align 8, !alias.scope !3, !noalias !4
  %v7295 = load i64, ptr %slot59, align 8
  %p7296 = inttoptr i64 %v7295 to ptr
  %ld7297 = load i64, ptr %p7296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7297, ptr %slot1273, align 8
  %v7298 = load i64, ptr %slot1273, align 8
  %op7299 = add i64 %v7298, 0
  store i64 %op7299, ptr %slot1274, align 8
  %v7300 = load i64, ptr %slot1274, align 8
  %v7301 = load i64, ptr %slot59, align 8
  %p7302 = inttoptr i64 %v7301 to ptr
  store i64 %v7300, ptr %p7302, align 8, !alias.scope !3, !noalias !4
  %v7303 = load i64, ptr %slot58, align 8
  %p7304 = inttoptr i64 %v7303 to ptr
  %ld7305 = load i64, ptr %p7304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7305, ptr %slot1275, align 8
  %v7306 = load i64, ptr %slot59, align 8
  %p7307 = inttoptr i64 %v7306 to ptr
  %ld7308 = load i64, ptr %p7307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7308, ptr %slot1276, align 8
  %v7309 = load i64, ptr %slot1, align 8
  %v7310 = load i64, ptr %slot1275, align 8
  %v7311 = load i64, ptr %slot1276, align 8
  %call7312 = call i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64 %v7309, i64 %v7310, i64 %v7311) nomerge, !dbg !202
  store i64 %call7312, ptr %slot1277, align 8
  %v7313 = load i64, ptr %slot1277, align 8
  %v7314 = load i64, ptr %slot58, align 8
  %p7315 = inttoptr i64 %v7314 to ptr
  store i64 %v7313, ptr %p7315, align 8, !alias.scope !3, !noalias !4
  %v7316 = load i64, ptr %slot23, align 8
  %p7317 = inttoptr i64 %v7316 to ptr
  %ld7318 = load i32, ptr %p7317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7318, ptr %slot1278, align 8
  %v7319 = load i32, ptr %slot1278, align 8
  %cv7320 = zext i32 %v7319 to i64
  %cond7321 = icmp ne i64 %cv7320, 0
  br i1 %cond7321, label %bb_rcslotdrop1637, label %bb_rcslotdone1637
bb_rcslotdrop1637:
  %v7322 = load i64, ptr %slot23, align 8
  %p7323 = inttoptr i64 %v7322 to ptr
  store i32 0, ptr %p7323, align 4, !alias.scope !3, !noalias !4
  %v7324 = load i64, ptr %slot29, align 8
  store i64 %v7324, ptr %slot1279, align 8
  %v7325 = load i64, ptr %slot24, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  %ld7327 = load i32, ptr %p7326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7327, ptr %slot1280, align 8
  %v7328 = load i32, ptr %slot1280, align 8
  %op7329 = and i32 %v7328, 28
  store i32 %op7329, ptr %slot1281, align 8
  %v7330 = load i32, ptr %slot1281, align 8
  %cv7331 = zext i32 %v7330 to i64
  %cond7332 = icmp ne i64 %cv7331, 0
  br i1 %cond7332, label %bb_rcslotrole1637, label %bb_rcslotowner1637
bb_rcslotrole1637:
  %v7333 = load i64, ptr %slot65, align 8
  store i64 %v7333, ptr %slot1282, align 8
  %v7334 = load i64, ptr %slot1282, align 8
  %v7335 = load i64, ptr %slot1279, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v7334, i64 %v7335) nomerge, !dbg !202
  br label %bb_rcslotdone1637
bb_rcslotowner1637:
  %v7336 = load i64, ptr %slot65, align 8
  store i64 %v7336, ptr %slot1283, align 8
  %v7337 = load i64, ptr %slot1283, align 8
  %v7338 = load i64, ptr %slot1279, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v7337, i64 %v7338) nomerge, !dbg !202
  br label %bb_rcslotdone1637
bb_rcslotdone1637:
  %v7339 = load i64, ptr %slot35, align 8
  %v7340 = load i64, ptr %slot58, align 8
  %p7341 = inttoptr i64 %v7340 to ptr
  store i64 %v7339, ptr %p7341, align 8, !alias.scope !3, !noalias !4
  %v7342 = load i64, ptr %slot51, align 8
  %v7343 = load i64, ptr %slot59, align 8
  %p7344 = inttoptr i64 %v7343 to ptr
  store i64 %v7342, ptr %p7344, align 8, !alias.scope !3, !noalias !4
  %v7345 = load i64, ptr %slot59, align 8
  %p7346 = inttoptr i64 %v7345 to ptr
  %ld7347 = load i64, ptr %p7346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7347, ptr %slot1284, align 8
  %v7348 = load i64, ptr %slot1284, align 8
  %op7349 = add i64 %v7348, 16
  store i64 %op7349, ptr %slot1285, align 8
  %v7350 = load i64, ptr %slot1285, align 8
  %p7351 = inttoptr i64 %v7350 to ptr
  %ld7352 = load i64, ptr %p7351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7352, ptr %slot1286, align 8
  %v7353 = load i64, ptr %slot1286, align 8
  %v7354 = load i64, ptr %slot59, align 8
  %p7355 = inttoptr i64 %v7354 to ptr
  store i64 %v7353, ptr %p7355, align 8, !alias.scope !3, !noalias !4
  %v7356 = load i64, ptr %slot58, align 8
  %p7357 = inttoptr i64 %v7356 to ptr
  %ld7358 = load i64, ptr %p7357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7358, ptr %slot1287, align 8
  %v7359 = load i64, ptr %slot59, align 8
  %p7360 = inttoptr i64 %v7359 to ptr
  %ld7361 = load i64, ptr %p7360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7361, ptr %slot1288, align 8
  %v7362 = load i64, ptr %slot1, align 8
  %v7363 = load i64, ptr %slot1287, align 8
  %v7364 = load i64, ptr %slot1288, align 8
  %call7365 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v7362, i64 %v7363, i64 %v7364) nomerge, !dbg !204
  store i64 %call7365, ptr %slot1289, align 8
  %v7366 = load i64, ptr %slot1289, align 8
  %v7367 = load i64, ptr %slot58, align 8
  %p7368 = inttoptr i64 %v7367 to ptr
  store i64 %v7366, ptr %p7368, align 8, !alias.scope !3, !noalias !4
  %v7369 = load i64, ptr %slot23, align 8
  %p7370 = inttoptr i64 %v7369 to ptr
  %ld7371 = load i32, ptr %p7370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7371, ptr %slot1290, align 8
  %v7372 = load i32, ptr %slot1290, align 8
  %cv7373 = zext i32 %v7372 to i64
  %cond7374 = icmp ne i64 %cv7373, 0
  br i1 %cond7374, label %bb_rcslotdrop1652, label %bb_rcslotdone1652
bb_rcslotdrop1652:
  %v7375 = load i64, ptr %slot23, align 8
  %p7376 = inttoptr i64 %v7375 to ptr
  store i32 0, ptr %p7376, align 4, !alias.scope !3, !noalias !4
  %v7377 = load i64, ptr %slot29, align 8
  store i64 %v7377, ptr %slot1291, align 8
  %v7378 = load i64, ptr %slot24, align 8
  %p7379 = inttoptr i64 %v7378 to ptr
  %ld7380 = load i32, ptr %p7379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7380, ptr %slot1292, align 8
  %v7381 = load i32, ptr %slot1292, align 8
  %op7382 = and i32 %v7381, 28
  store i32 %op7382, ptr %slot1293, align 8
  %v7383 = load i32, ptr %slot1293, align 8
  %cv7384 = zext i32 %v7383 to i64
  %cond7385 = icmp ne i64 %cv7384, 0
  br i1 %cond7385, label %bb_rcslotrole1652, label %bb_rcslotowner1652
bb_rcslotrole1652:
  %v7386 = load i64, ptr %slot65, align 8
  store i64 %v7386, ptr %slot1294, align 8
  %v7387 = load i64, ptr %slot1294, align 8
  %v7388 = load i64, ptr %slot1291, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v7387, i64 %v7388) nomerge, !dbg !204
  br label %bb_rcslotdone1652
bb_rcslotowner1652:
  %v7389 = load i64, ptr %slot65, align 8
  store i64 %v7389, ptr %slot1295, align 8
  %v7390 = load i64, ptr %slot1295, align 8
  %v7391 = load i64, ptr %slot1291, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v7390, i64 %v7391) nomerge, !dbg !204
  br label %bb_rcslotdone1652
bb_rcslotdone1652:
  br label %bb_i198
bb_i149:
  %v7392 = load i64, ptr %slot52, align 8
  %v7393 = load i64, ptr %slot58, align 8
  %p7394 = inttoptr i64 %v7393 to ptr
  store i64 %v7392, ptr %p7394, align 8, !alias.scope !3, !noalias !4
  %v7395 = load i64, ptr %slot19, align 8
  %p7396 = inttoptr i64 %v7395 to ptr
  %ld7397 = load i32, ptr %p7396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7397, ptr %slot1296, align 8
  %v7398 = load i64, ptr %slot20, align 8
  %p7399 = inttoptr i64 %v7398 to ptr
  %ld7400 = load i32, ptr %p7399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7400, ptr %slot1297, align 8
  %v7401 = load i32, ptr %slot1297, align 8
  %op7402 = and i32 %v7401, 24
  store i32 %op7402, ptr %slot1297, align 8
  %v7403 = load i32, ptr %slot1297, align 8
  %cmp7404 = icmp eq i32 %v7403, 0
  %cv7405 = zext i1 %cmp7404 to i32
  store i32 %cv7405, ptr %slot1298, align 8
  %v7406 = load i32, ptr %slot1296, align 8
  %v7407 = load i32, ptr %slot1298, align 8
  %op7408 = and i32 %v7406, %v7407
  store i32 %op7408, ptr %slot1299, align 8
  %v7409 = load i32, ptr %slot1299, align 8
  %cv7410 = zext i32 %v7409 to i64
  %cond7411 = icmp ne i64 %cv7410, 0
  br i1 %cond7411, label %bb_rcselfkept1665, label %bb_rcselfstore1665
bb_rcselfstore1665:
  %v7412 = load i64, ptr %slot58, align 8
  %p7413 = inttoptr i64 %v7412 to ptr
  %ld7414 = load i64, ptr %p7413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7414, ptr %slot1300, align 8
  %v7415 = load i64, ptr %slot23, align 8
  %p7416 = inttoptr i64 %v7415 to ptr
  %ld7417 = load i32, ptr %p7416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7417, ptr %slot1301, align 8
  %v7418 = load i64, ptr %slot24, align 8
  %p7419 = inttoptr i64 %v7418 to ptr
  %ld7420 = load i32, ptr %p7419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7420, ptr %slot1302, align 8
  %v7421 = load i32, ptr %slot1302, align 8
  %op7422 = and i32 %v7421, 24
  store i32 %op7422, ptr %slot1302, align 8
  %v7423 = load i32, ptr %slot1302, align 8
  %cmp7424 = icmp eq i32 %v7423, 0
  %cv7425 = zext i1 %cmp7424 to i32
  store i32 %cv7425, ptr %slot1303, align 8
  %v7426 = load i32, ptr %slot1301, align 8
  %v7427 = load i32, ptr %slot1303, align 8
  %op7428 = and i32 %v7426, %v7427
  store i32 %op7428, ptr %slot1304, align 8
  %v7429 = load i32, ptr %slot1304, align 8
  %cv7430 = zext i32 %v7429 to i64
  %cond7431 = icmp ne i64 %cv7430, 0
  br i1 %cond7431, label %bb_rctake1667, label %bb_rccopy1667
bb_rctake1667:
  %v7432 = load i64, ptr %slot32, align 8
  store i64 %v7432, ptr %slot1305, align 8
  %v7433 = load i64, ptr %slot66, align 8
  store i64 %v7433, ptr %slot1306, align 8
  %v7434 = load i64, ptr %slot1300, align 8
  %v7435 = load i64, ptr %slot1305, align 8
  %op7436 = sub i64 %v7434, %v7435
  store i64 %op7436, ptr %slot1307, align 8
  %v7437 = load i64, ptr %slot1305, align 8
  %v7438 = load i64, ptr %slot1300, align 8
  %op7439 = sub i64 %v7437, %v7438
  store i64 %op7439, ptr %slot1308, align 8
  %v7440 = load i64, ptr %slot1307, align 8
  %cmp7441 = icmp ult i64 %v7440, 16
  %cv7442 = zext i1 %cmp7441 to i32
  store i32 %cv7442, ptr %slot1309, align 8
  %v7443 = load i64, ptr %slot1308, align 8
  %cmp7444 = icmp ult i64 %v7443, 16
  %cv7445 = zext i1 %cmp7444 to i32
  store i32 %cv7445, ptr %slot1310, align 8
  %v7446 = load i32, ptr %slot1309, align 8
  %v7447 = load i32, ptr %slot1310, align 8
  %op7448 = or i32 %v7446, %v7447
  store i32 %op7448, ptr %slot1311, align 8
  %v7449 = load i32, ptr %slot1311, align 8
  %cv7450 = zext i32 %v7449 to i64
  %cond7451 = icmp ne i64 %cv7450, 0
  br i1 %cond7451, label %bb_rcmoveslow1676, label %bb_rcmovecheck1676
bb_rcmovecheck1676:
  %v7452 = load i64, ptr %slot1300, align 8
  %op7453 = add i64 %v7452, 8
  store i64 %op7453, ptr %slot1312, align 8
  %v7454 = load i64, ptr %slot1312, align 8
  %p7455 = inttoptr i64 %v7454 to ptr
  %ld7456 = load i64, ptr %p7455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7456, ptr %slot1313, align 8
  %v7457 = load i64, ptr %slot1313, align 8
  %cmp7458 = icmp ne i64 %v7457, 0
  %cv7459 = zext i1 %cmp7458 to i32
  store i32 %cv7459, ptr %slot1314, align 8
  %v7460 = load i32, ptr %slot1314, align 8
  %cv7461 = zext i32 %v7460 to i64
  %cond7462 = icmp ne i64 %cv7461, 0
  br i1 %cond7462, label %bb_rcmoveheader1684, label %bb_rcmovenext1684
bb_rcmoveheader1684:
  %v7463 = load i64, ptr %slot1313, align 8
  %op7464 = sub i64 %v7463, 16
  store i64 %op7464, ptr %slot1315, align 8
  %v7465 = load i64, ptr %slot1313, align 8
  %p7466 = inttoptr i64 %v7465 to ptr
  %rgep7467 = getelementptr i8, ptr %p7466, i64 -16
  %ld7468 = load i64, ptr %rgep7467, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7468, ptr %slot1316, align 8
  %v7469 = load i64, ptr %slot1316, align 8
  %op7470 = and i64 %v7469, 5764607523034234881
  store i64 %op7470, ptr %slot1317, align 8
  %v7471 = load i64, ptr %slot1317, align 8
  %cmp7472 = icmp ne i64 %v7471, 0
  %cv7473 = zext i1 %cmp7472 to i32
  store i32 %cv7473, ptr %slot1318, align 8
  %v7474 = load i32, ptr %slot1318, align 8
  %cv7475 = zext i32 %v7474 to i64
  %cond7476 = icmp ne i64 %cv7475, 0
  br i1 %cond7476, label %bb_rcmoveslow1676, label %bb_rcmovenext1684
bb_rcmovenext1684:
  %v7477 = load i64, ptr %slot1300, align 8
  %v7478 = load i64, ptr %slot1305, align 8
  %p7479 = inttoptr i64 %v7477 to ptr
  %p7480 = inttoptr i64 %v7478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7480, ptr %p7479, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7481 = load i64, ptr %slot1300, align 8
  %p7482 = inttoptr i64 %v7481 to ptr
  store i64 0, ptr %p7482, align 8, !alias.scope !3, !noalias !4
  %v7483 = load i64, ptr %slot1300, align 8
  %op7484 = add i64 %v7483, 8
  store i64 %op7484, ptr %slot1319, align 8
  %v7485 = load i64, ptr %slot1319, align 8
  %p7486 = inttoptr i64 %v7485 to ptr
  store i64 0, ptr %p7486, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1676
bb_rcmoveslow1676:
  %v7487 = load i64, ptr %slot65, align 8
  %v7488 = load i64, ptr %slot1305, align 8
  %v7489 = load i64, ptr %slot1300, align 8
  %v7490 = load i64, ptr %slot1306, align 8
  %cv7491 = trunc i64 %v7490 to i32
  %call7492 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v7487, i64 %v7488, i64 %v7489, i32 %cv7491) nomerge, !dbg !206
  store i32 %call7492, ptr %slot1320, align 8
  %v7493 = load i32, ptr %slot1320, align 8
  %cv7494 = zext i32 %v7493 to i64
  %cond7495 = icmp ne i64 %cv7494, 0
  br i1 %cond7495, label %bb_rcsuccess1692, label %bb_rcfailure1692
bb_rcfailure1692:
  %v7496 = load i64, ptr %slot65, align 8
  %p7497 = inttoptr i64 %v7496 to ptr
  %call7498 = call i32 @myl_rc_take_failure(ptr %p7497) nomerge, !dbg !206
  store i32 %call7498, ptr %slot1321, align 8
  %v7499 = load i64, ptr %slot1, align 8
  %p7500 = inttoptr i64 %v7499 to ptr
  %v7501 = load i32, ptr %slot1321, align 8
  %call7502 = call i32 @myl_qbe_rc_status(ptr %p7500, i32 %v7501) nomerge, !dbg !206
  store i32 %call7502, ptr %slot1322, align 8
  br label %bb_failure
bb_rcsuccess1692:
  br label %bb_rcmoved1676
bb_rcmoved1676:
  %v7503 = load i64, ptr %slot23, align 8
  %p7504 = inttoptr i64 %v7503 to ptr
  store i32 0, ptr %p7504, align 4, !alias.scope !3, !noalias !4
  %v7505 = load i64, ptr %slot28, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  store i32 2, ptr %p7506, align 4, !alias.scope !3, !noalias !4
  %v7507 = load i64, ptr %slot27, align 8
  %p7508 = inttoptr i64 %v7507 to ptr
  store i32 1, ptr %p7508, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1667
bb_rccopy1667:
  %v7509 = load i64, ptr %slot32, align 8
  store i64 %v7509, ptr %slot1323, align 8
  %v7510 = load i64, ptr %slot66, align 8
  store i64 %v7510, ptr %slot1324, align 8
  %v7511 = load i64, ptr %slot65, align 8
  %v7512 = load i64, ptr %slot1323, align 8
  %v7513 = load i64, ptr %slot1300, align 8
  %v7514 = load i64, ptr %slot1324, align 8
  %cv7515 = trunc i64 %v7514 to i32
  %call7516 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_retain(i64 %v7511, i64 %v7512, i64 %v7513, i32 %cv7515) nomerge, !dbg !206
  store i32 %call7516, ptr %slot1325, align 8
  %v7517 = load i32, ptr %slot1325, align 8
  %cv7518 = zext i32 %v7517 to i64
  %cond7519 = icmp ne i64 %cv7518, 0
  br i1 %cond7519, label %bb_rcsuccess1701, label %bb_rcfailure1701
bb_rcfailure1701:
  %v7520 = load i64, ptr %slot65, align 8
  %p7521 = inttoptr i64 %v7520 to ptr
  %call7522 = call i32 @myl_rc_take_failure(ptr %p7521) nomerge, !dbg !206
  store i32 %call7522, ptr %slot1326, align 8
  %v7523 = load i64, ptr %slot1, align 8
  %p7524 = inttoptr i64 %v7523 to ptr
  %v7525 = load i32, ptr %slot1326, align 8
  %call7526 = call i32 @myl_qbe_rc_status(ptr %p7524, i32 %v7525) nomerge, !dbg !206
  store i32 %call7526, ptr %slot1327, align 8
  br label %bb_failure
bb_rcsuccess1701:
  %v7527 = load i64, ptr %slot28, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  store i32 2, ptr %p7528, align 4, !alias.scope !3, !noalias !4
  %v7529 = load i64, ptr %slot27, align 8
  %p7530 = inttoptr i64 %v7529 to ptr
  store i32 1, ptr %p7530, align 4, !alias.scope !3, !noalias !4
  %v7531 = load i64, ptr %slot23, align 8
  %p7532 = inttoptr i64 %v7531 to ptr
  %ld7533 = load i32, ptr %p7532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7533, ptr %slot1328, align 8
  %v7534 = load i32, ptr %slot1328, align 8
  %cv7535 = zext i32 %v7534 to i64
  %cond7536 = icmp ne i64 %cv7535, 0
  br i1 %cond7536, label %bb_rcslotdrop1708, label %bb_rcslotdone1708
bb_rcslotdrop1708:
  %v7537 = load i64, ptr %slot23, align 8
  %p7538 = inttoptr i64 %v7537 to ptr
  store i32 0, ptr %p7538, align 4, !alias.scope !3, !noalias !4
  %v7539 = load i64, ptr %slot29, align 8
  store i64 %v7539, ptr %slot1329, align 8
  %v7540 = load i64, ptr %slot24, align 8
  %p7541 = inttoptr i64 %v7540 to ptr
  %ld7542 = load i32, ptr %p7541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7542, ptr %slot1330, align 8
  %v7543 = load i32, ptr %slot1330, align 8
  %op7544 = and i32 %v7543, 28
  store i32 %op7544, ptr %slot1331, align 8
  %v7545 = load i32, ptr %slot1331, align 8
  %cv7546 = zext i32 %v7545 to i64
  %cond7547 = icmp ne i64 %cv7546, 0
  br i1 %cond7547, label %bb_rcslotrole1708, label %bb_rcslotowner1708
bb_rcslotrole1708:
  %v7548 = load i64, ptr %slot65, align 8
  store i64 %v7548, ptr %slot1332, align 8
  %v7549 = load i64, ptr %slot1332, align 8
  %v7550 = load i64, ptr %slot1329, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v7549, i64 %v7550) nomerge, !dbg !206
  br label %bb_rcslotdone1708
bb_rcslotowner1708:
  %v7551 = load i64, ptr %slot1329, align 8
  %p7553 = inttoptr i64 %v7551 to ptr
  %gep7554 = getelementptr i8, ptr %p7553, i64 8
  %op7552 = ptrtoint ptr %gep7554 to i64
  store i64 %op7552, ptr %slot1333, align 8
  %v7555 = load i64, ptr %slot65, align 8
  store i64 %v7555, ptr %slot1334, align 8
  %v7556 = load i64, ptr %slot1333, align 8
  %p7557 = inttoptr i64 %v7556 to ptr
  %ld7558 = load i64, ptr %p7557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7558, ptr %slot1335, align 8
  %v7559 = load i64, ptr %slot1335, align 8
  %cmp7560 = icmp ne i64 %v7559, 0
  %cv7561 = zext i1 %cmp7560 to i32
  store i32 %cv7561, ptr %slot1336, align 8
  %v7562 = load i32, ptr %slot1336, align 8
  %cv7563 = zext i32 %v7562 to i64
  %cond7564 = icmp ne i64 %cv7563, 0
  br i1 %cond7564, label %bb_rcgnn1726, label %bb_rcgdone1726
bb_rcgnn1726:
  %v7565 = load i64, ptr %slot1335, align 8
  %op7566 = sub i64 %v7565, 16
  store i64 %op7566, ptr %slot1337, align 8
  %v7567 = load i64, ptr %slot1335, align 8
  %p7568 = inttoptr i64 %v7567 to ptr
  %rgep7569 = getelementptr i8, ptr %p7568, i64 -16
  %ld7570 = load i64, ptr %rgep7569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7570, ptr %slot1338, align 8
  %v7571 = load i64, ptr %slot1338, align 8
  %op7572 = and i64 %v7571, 4611686018427387906
  store i64 %op7572, ptr %slot1339, align 8
  %v7573 = load i64, ptr %slot1339, align 8
  %cmp7574 = icmp ne i64 %v7573, 0
  %cv7575 = zext i1 %cmp7574 to i32
  store i32 %cv7575, ptr %slot1340, align 8
  %v7576 = load i32, ptr %slot1340, align 8
  %cv7577 = zext i32 %v7576 to i64
  %cond7578 = icmp ne i64 %cv7577, 0
  br i1 %cond7578, label %bb_rcgclear1726, label %bb_rcgcounted1726
bb_rcgcounted1726:
  %v7579 = load i64, ptr %slot1335, align 8
  %op7580 = sub i64 %v7579, 32
  store i64 %op7580, ptr %slot1341, align 8
  %v7581 = load i64, ptr %slot1335, align 8
  %p7582 = inttoptr i64 %v7581 to ptr
  %rgep7583 = getelementptr i8, ptr %p7582, i64 -32
  %ld7584 = load i64, ptr %rgep7583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7584, ptr %slot1342, align 8
  %v7585 = load i64, ptr %slot1342, align 8
  %op7586 = sub i64 %v7585, 1
  store i64 %op7586, ptr %slot1343, align 8
  %v7587 = load i64, ptr %slot1343, align 8
  %cmp7588 = icmp eq i64 %v7587, 0
  %cv7589 = zext i1 %cmp7588 to i32
  store i32 %cv7589, ptr %slot1344, align 8
  %v7590 = load i32, ptr %slot1344, align 8
  %cv7591 = zext i32 %v7590 to i64
  %cond7592 = icmp ne i64 %cv7591, 0
  br i1 %cond7592, label %bb_rcglast1726, label %bb_rcgdec1726
bb_rcglast1726:
  %v7593 = load i64, ptr %slot1335, align 8
  %op7594 = sub i64 %v7593, 24
  store i64 %op7594, ptr %slot1345, align 8
  %v7595 = load i64, ptr %slot1335, align 8
  %p7596 = inttoptr i64 %v7595 to ptr
  %rgep7597 = getelementptr i8, ptr %p7596, i64 -24
  %ld7598 = load i64, ptr %rgep7597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7598, ptr %slot1346, align 8
  %v7599 = load i64, ptr %slot1346, align 8
  %cmp7600 = icmp ne i64 %v7599, 0
  %cv7601 = zext i1 %cmp7600 to i32
  store i32 %cv7601, ptr %slot1347, align 8
  %v7602 = load i32, ptr %slot1347, align 8
  %cv7603 = zext i32 %v7602 to i64
  %cond7604 = icmp ne i64 %cv7603, 0
  br i1 %cond7604, label %bb_rcgdec1726, label %bb_rcgslow1726
bb_rcgslow1726:
  %v7605 = load i64, ptr %slot1334, align 8
  %v7606 = load i64, ptr %slot1333, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v7605, i64 %v7606) nomerge, !dbg !206
  br label %bb_rcgdone1726
bb_rcgdec1726:
  %v7607 = load i64, ptr %slot1343, align 8
  %v7608 = load i64, ptr %slot1335, align 8
  %p7609 = inttoptr i64 %v7608 to ptr
  %rgep7610 = getelementptr i8, ptr %p7609, i64 -32
  store i64 %v7607, ptr %rgep7610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1726
bb_rcgclear1726:
  %v7611 = load i64, ptr %slot1333, align 8
  %p7612 = inttoptr i64 %v7611 to ptr
  store i64 0, ptr %p7612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1726
bb_rcgdone1726:
  %v7613 = load i64, ptr %slot1329, align 8
  %p7614 = inttoptr i64 %v7613 to ptr
  store i64 0, ptr %p7614, align 8, !alias.scope !3, !noalias !4
  %v7615 = load i64, ptr %slot1329, align 8
  %p7617 = inttoptr i64 %v7615 to ptr
  %gep7618 = getelementptr i8, ptr %p7617, i64 8
  %op7616 = ptrtoint ptr %gep7618 to i64
  store i64 %op7616, ptr %slot1348, align 8
  %v7619 = load i64, ptr %slot1348, align 8
  %p7620 = inttoptr i64 %v7619 to ptr
  store i64 0, ptr %p7620, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1708
bb_rcslotdone1708:
  br label %bb_rcprepared1667
bb_rcprepared1667:
  %v7621 = load i64, ptr %slot19, align 8
  %p7622 = inttoptr i64 %v7621 to ptr
  %ld7623 = load i32, ptr %p7622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7623, ptr %slot1349, align 8
  %v7624 = load i32, ptr %slot1349, align 8
  %cv7625 = zext i32 %v7624 to i64
  %cond7626 = icmp ne i64 %cv7625, 0
  br i1 %cond7626, label %bb_rcslotdrop1734, label %bb_rcslotdone1734
bb_rcslotdrop1734:
  %v7627 = load i64, ptr %slot19, align 8
  %p7628 = inttoptr i64 %v7627 to ptr
  store i32 0, ptr %p7628, align 4, !alias.scope !3, !noalias !4
  %v7629 = load i64, ptr %slot52, align 8
  store i64 %v7629, ptr %slot1350, align 8
  %v7630 = load i64, ptr %slot20, align 8
  %p7631 = inttoptr i64 %v7630 to ptr
  %ld7632 = load i32, ptr %p7631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7632, ptr %slot1351, align 8
  %v7633 = load i32, ptr %slot1351, align 8
  %op7634 = and i32 %v7633, 28
  store i32 %op7634, ptr %slot1352, align 8
  %v7635 = load i32, ptr %slot1352, align 8
  %cv7636 = zext i32 %v7635 to i64
  %cond7637 = icmp ne i64 %cv7636, 0
  br i1 %cond7637, label %bb_rcslotrole1734, label %bb_rcslotowner1734
bb_rcslotrole1734:
  %v7638 = load i64, ptr %slot65, align 8
  store i64 %v7638, ptr %slot1353, align 8
  %v7639 = load i64, ptr %slot1353, align 8
  %v7640 = load i64, ptr %slot1350, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v7639, i64 %v7640) nomerge, !dbg !206
  br label %bb_rcslotdone1734
bb_rcslotowner1734:
  %v7641 = load i64, ptr %slot1350, align 8
  %p7643 = inttoptr i64 %v7641 to ptr
  %gep7644 = getelementptr i8, ptr %p7643, i64 8
  %op7642 = ptrtoint ptr %gep7644 to i64
  store i64 %op7642, ptr %slot1354, align 8
  %v7645 = load i64, ptr %slot65, align 8
  store i64 %v7645, ptr %slot1355, align 8
  %v7646 = load i64, ptr %slot1354, align 8
  %p7647 = inttoptr i64 %v7646 to ptr
  %ld7648 = load i64, ptr %p7647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7648, ptr %slot1356, align 8
  %v7649 = load i64, ptr %slot1356, align 8
  %cmp7650 = icmp ne i64 %v7649, 0
  %cv7651 = zext i1 %cmp7650 to i32
  store i32 %cv7651, ptr %slot1357, align 8
  %v7652 = load i32, ptr %slot1357, align 8
  %cv7653 = zext i32 %v7652 to i64
  %cond7654 = icmp ne i64 %cv7653, 0
  br i1 %cond7654, label %bb_rcgnn1752, label %bb_rcgdone1752
bb_rcgnn1752:
  %v7655 = load i64, ptr %slot1356, align 8
  %op7656 = sub i64 %v7655, 16
  store i64 %op7656, ptr %slot1358, align 8
  %v7657 = load i64, ptr %slot1356, align 8
  %p7658 = inttoptr i64 %v7657 to ptr
  %rgep7659 = getelementptr i8, ptr %p7658, i64 -16
  %ld7660 = load i64, ptr %rgep7659, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7660, ptr %slot1359, align 8
  %v7661 = load i64, ptr %slot1359, align 8
  %op7662 = and i64 %v7661, 4611686018427387906
  store i64 %op7662, ptr %slot1360, align 8
  %v7663 = load i64, ptr %slot1360, align 8
  %cmp7664 = icmp ne i64 %v7663, 0
  %cv7665 = zext i1 %cmp7664 to i32
  store i32 %cv7665, ptr %slot1361, align 8
  %v7666 = load i32, ptr %slot1361, align 8
  %cv7667 = zext i32 %v7666 to i64
  %cond7668 = icmp ne i64 %cv7667, 0
  br i1 %cond7668, label %bb_rcgclear1752, label %bb_rcgcounted1752
bb_rcgcounted1752:
  %v7669 = load i64, ptr %slot1356, align 8
  %op7670 = sub i64 %v7669, 32
  store i64 %op7670, ptr %slot1362, align 8
  %v7671 = load i64, ptr %slot1356, align 8
  %p7672 = inttoptr i64 %v7671 to ptr
  %rgep7673 = getelementptr i8, ptr %p7672, i64 -32
  %ld7674 = load i64, ptr %rgep7673, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7674, ptr %slot1363, align 8
  %v7675 = load i64, ptr %slot1363, align 8
  %op7676 = sub i64 %v7675, 1
  store i64 %op7676, ptr %slot1364, align 8
  %v7677 = load i64, ptr %slot1364, align 8
  %cmp7678 = icmp eq i64 %v7677, 0
  %cv7679 = zext i1 %cmp7678 to i32
  store i32 %cv7679, ptr %slot1365, align 8
  %v7680 = load i32, ptr %slot1365, align 8
  %cv7681 = zext i32 %v7680 to i64
  %cond7682 = icmp ne i64 %cv7681, 0
  br i1 %cond7682, label %bb_rcglast1752, label %bb_rcgdec1752
bb_rcglast1752:
  %v7683 = load i64, ptr %slot1356, align 8
  %op7684 = sub i64 %v7683, 24
  store i64 %op7684, ptr %slot1366, align 8
  %v7685 = load i64, ptr %slot1356, align 8
  %p7686 = inttoptr i64 %v7685 to ptr
  %rgep7687 = getelementptr i8, ptr %p7686, i64 -24
  %ld7688 = load i64, ptr %rgep7687, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7688, ptr %slot1367, align 8
  %v7689 = load i64, ptr %slot1367, align 8
  %cmp7690 = icmp ne i64 %v7689, 0
  %cv7691 = zext i1 %cmp7690 to i32
  store i32 %cv7691, ptr %slot1368, align 8
  %v7692 = load i32, ptr %slot1368, align 8
  %cv7693 = zext i32 %v7692 to i64
  %cond7694 = icmp ne i64 %cv7693, 0
  br i1 %cond7694, label %bb_rcgdec1752, label %bb_rcgslow1752
bb_rcgslow1752:
  %v7695 = load i64, ptr %slot1355, align 8
  %v7696 = load i64, ptr %slot1354, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v7695, i64 %v7696) nomerge, !dbg !206
  br label %bb_rcgdone1752
bb_rcgdec1752:
  %v7697 = load i64, ptr %slot1364, align 8
  %v7698 = load i64, ptr %slot1356, align 8
  %p7699 = inttoptr i64 %v7698 to ptr
  %rgep7700 = getelementptr i8, ptr %p7699, i64 -32
  store i64 %v7697, ptr %rgep7700, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1752
bb_rcgclear1752:
  %v7701 = load i64, ptr %slot1354, align 8
  %p7702 = inttoptr i64 %v7701 to ptr
  store i64 0, ptr %p7702, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1752
bb_rcgdone1752:
  %v7703 = load i64, ptr %slot1350, align 8
  %p7704 = inttoptr i64 %v7703 to ptr
  store i64 0, ptr %p7704, align 8, !alias.scope !3, !noalias !4
  %v7705 = load i64, ptr %slot1350, align 8
  %p7707 = inttoptr i64 %v7705 to ptr
  %gep7708 = getelementptr i8, ptr %p7707, i64 8
  %op7706 = ptrtoint ptr %gep7708 to i64
  store i64 %op7706, ptr %slot1369, align 8
  %v7709 = load i64, ptr %slot1369, align 8
  %p7710 = inttoptr i64 %v7709 to ptr
  store i64 0, ptr %p7710, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1734
bb_rcslotdone1734:
  %v7711 = load i64, ptr %slot52, align 8
  store i64 %v7711, ptr %slot1370, align 8
  %v7712 = load i64, ptr %slot32, align 8
  store i64 %v7712, ptr %slot1371, align 8
  %v7713 = load i64, ptr %slot1371, align 8
  %v7714 = load i64, ptr %slot1370, align 8
  %p7715 = inttoptr i64 %v7713 to ptr
  %p7716 = inttoptr i64 %v7714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7716, ptr %p7715, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7717 = load i64, ptr %slot27, align 8
  %p7718 = inttoptr i64 %v7717 to ptr
  store i32 0, ptr %p7718, align 4, !alias.scope !3, !noalias !4
  %v7719 = load i64, ptr %slot20, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  store i32 2, ptr %p7720, align 4, !alias.scope !3, !noalias !4
  %v7721 = load i64, ptr %slot28, align 8
  %p7722 = inttoptr i64 %v7721 to ptr
  %ld7723 = load i32, ptr %p7722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7723, ptr %slot1372, align 8
  %v7724 = load i32, ptr %slot1372, align 8
  %v7725 = load i64, ptr %slot20, align 8
  %p7726 = inttoptr i64 %v7725 to ptr
  store i32 %v7724, ptr %p7726, align 4, !alias.scope !3, !noalias !4
  %v7727 = load i64, ptr %slot19, align 8
  %p7728 = inttoptr i64 %v7727 to ptr
  store i32 1, ptr %p7728, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept1665
bb_rcselfkept1665:
  %v7729 = load i64, ptr %slot35, align 8
  %v7730 = load i64, ptr %slot58, align 8
  %p7731 = inttoptr i64 %v7730 to ptr
  store i64 %v7729, ptr %p7731, align 8, !alias.scope !3, !noalias !4
  %v7732 = load i64, ptr %slot52, align 8
  %v7733 = load i64, ptr %slot59, align 8
  %p7734 = inttoptr i64 %v7733 to ptr
  store i64 %v7732, ptr %p7734, align 8, !alias.scope !3, !noalias !4
  %v7735 = load i64, ptr %slot59, align 8
  %p7736 = inttoptr i64 %v7735 to ptr
  %ld7737 = load i64, ptr %p7736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7737, ptr %slot1373, align 8
  %v7738 = load i64, ptr %slot1373, align 8
  %op7739 = add i64 %v7738, 0
  store i64 %op7739, ptr %slot1374, align 8
  %v7740 = load i64, ptr %slot1374, align 8
  %p7741 = inttoptr i64 %v7740 to ptr
  %ld7742 = load i64, ptr %p7741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7742, ptr %slot1375, align 8
  %v7743 = load i64, ptr %slot1375, align 8
  %v7744 = load i64, ptr %slot59, align 8
  %p7745 = inttoptr i64 %v7744 to ptr
  store i64 %v7743, ptr %p7745, align 8, !alias.scope !3, !noalias !4
  %v7746 = load i64, ptr %slot25, align 8
  %p7747 = inttoptr i64 %v7746 to ptr
  %ld7748 = load i32, ptr %p7747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7748, ptr %slot1376, align 8
  %v7749 = load i32, ptr %slot1376, align 8
  %cv7750 = zext i32 %v7749 to i64
  %cond7751 = icmp ne i64 %cv7750, 0
  br i1 %cond7751, label %bb_rcslotdrop1769, label %bb_rcslotdone1769
bb_rcslotdrop1769:
  %v7752 = load i64, ptr %slot25, align 8
  %p7753 = inttoptr i64 %v7752 to ptr
  store i32 0, ptr %p7753, align 4, !alias.scope !3, !noalias !4
  %v7754 = load i64, ptr %slot30, align 8
  store i64 %v7754, ptr %slot1377, align 8
  %v7755 = load i64, ptr %slot26, align 8
  %p7756 = inttoptr i64 %v7755 to ptr
  %ld7757 = load i32, ptr %p7756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7757, ptr %slot1378, align 8
  %v7758 = load i32, ptr %slot1378, align 8
  %op7759 = and i32 %v7758, 28
  store i32 %op7759, ptr %slot1379, align 8
  %v7760 = load i32, ptr %slot1379, align 8
  %cv7761 = zext i32 %v7760 to i64
  %cond7762 = icmp ne i64 %cv7761, 0
  br i1 %cond7762, label %bb_rcslotrole1769, label %bb_rcslotowner1769
bb_rcslotrole1769:
  %v7763 = load i64, ptr %slot65, align 8
  store i64 %v7763, ptr %slot1380, align 8
  %v7764 = load i64, ptr %slot1380, align 8
  %v7765 = load i64, ptr %slot1377, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v7764, i64 %v7765) nomerge, !dbg !208
  br label %bb_rcslotdone1769
bb_rcslotowner1769:
  %v7766 = load i64, ptr %slot65, align 8
  store i64 %v7766, ptr %slot1381, align 8
  %v7767 = load i64, ptr %slot1381, align 8
  %v7768 = load i64, ptr %slot1377, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v7767, i64 %v7768) nomerge, !dbg !208
  br label %bb_rcslotdone1769
bb_rcslotdone1769:
  %v7769 = load i64, ptr %slot58, align 8
  %p7770 = inttoptr i64 %v7769 to ptr
  %ld7771 = load i64, ptr %p7770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7771, ptr %slot1382, align 8
  %v7772 = load i64, ptr %slot59, align 8
  %p7773 = inttoptr i64 %v7772 to ptr
  %ld7774 = load i64, ptr %p7773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7774, ptr %slot1383, align 8
  %v7775 = load i64, ptr %slot1, align 8
  %v7776 = load i64, ptr %slot1382, align 8
  %v7777 = load i64, ptr %slot1383, align 8
  %call7778 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v7775, i64 %v7776, i64 %v7777) nomerge, !dbg !210
  store i64 %call7778, ptr %slot1384, align 8
  %v7779 = load i64, ptr %slot1384, align 8
  %v7780 = load i64, ptr %slot58, align 8
  %p7781 = inttoptr i64 %v7780 to ptr
  store i64 %v7779, ptr %p7781, align 8, !alias.scope !3, !noalias !4
  %v7782 = load i64, ptr %slot23, align 8
  %p7783 = inttoptr i64 %v7782 to ptr
  %ld7784 = load i32, ptr %p7783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7784, ptr %slot1385, align 8
  %v7785 = load i32, ptr %slot1385, align 8
  %cv7786 = zext i32 %v7785 to i64
  %cond7787 = icmp ne i64 %cv7786, 0
  br i1 %cond7787, label %bb_rcslotdrop1781, label %bb_rcslotdone1781
bb_rcslotdrop1781:
  %v7788 = load i64, ptr %slot23, align 8
  %p7789 = inttoptr i64 %v7788 to ptr
  store i32 0, ptr %p7789, align 4, !alias.scope !3, !noalias !4
  %v7790 = load i64, ptr %slot29, align 8
  store i64 %v7790, ptr %slot1386, align 8
  %v7791 = load i64, ptr %slot24, align 8
  %p7792 = inttoptr i64 %v7791 to ptr
  %ld7793 = load i32, ptr %p7792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7793, ptr %slot1387, align 8
  %v7794 = load i32, ptr %slot1387, align 8
  %op7795 = and i32 %v7794, 28
  store i32 %op7795, ptr %slot1388, align 8
  %v7796 = load i32, ptr %slot1388, align 8
  %cv7797 = zext i32 %v7796 to i64
  %cond7798 = icmp ne i64 %cv7797, 0
  br i1 %cond7798, label %bb_rcslotrole1781, label %bb_rcslotowner1781
bb_rcslotrole1781:
  %v7799 = load i64, ptr %slot65, align 8
  store i64 %v7799, ptr %slot1389, align 8
  %v7800 = load i64, ptr %slot1389, align 8
  %v7801 = load i64, ptr %slot1386, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v7800, i64 %v7801) nomerge, !dbg !210
  br label %bb_rcslotdone1781
bb_rcslotowner1781:
  %v7802 = load i64, ptr %slot65, align 8
  store i64 %v7802, ptr %slot1390, align 8
  %v7803 = load i64, ptr %slot1390, align 8
  %v7804 = load i64, ptr %slot1386, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v7803, i64 %v7804) nomerge, !dbg !210
  br label %bb_rcslotdone1781
bb_rcslotdone1781:
  %v7805 = load i64, ptr %slot52, align 8
  %v7806 = load i64, ptr %slot58, align 8
  %p7807 = inttoptr i64 %v7806 to ptr
  store i64 %v7805, ptr %p7807, align 8, !alias.scope !3, !noalias !4
  %v7808 = load i64, ptr %slot58, align 8
  %p7809 = inttoptr i64 %v7808 to ptr
  %ld7810 = load i64, ptr %p7809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7810, ptr %slot1391, align 8
  %v7811 = load i64, ptr %slot1391, align 8
  %op7812 = add i64 %v7811, 8
  store i64 %op7812, ptr %slot1392, align 8
  %v7813 = load i64, ptr %slot1392, align 8
  %p7814 = inttoptr i64 %v7813 to ptr
  %ld7815 = load i64, ptr %p7814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7815, ptr %slot1393, align 8
  %v7816 = load i64, ptr %slot1393, align 8
  %v7817 = load i64, ptr %slot58, align 8
  %p7818 = inttoptr i64 %v7817 to ptr
  store i64 %v7816, ptr %p7818, align 8, !alias.scope !3, !noalias !4
  %v7819 = load i64, ptr %slot58, align 8
  %p7820 = inttoptr i64 %v7819 to ptr
  %ld7821 = load i64, ptr %p7820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7821, ptr %slot1394, align 8
  %v7822 = load i64, ptr %slot1394, align 8
  %v7823 = load i64, ptr %slot31, align 8
  %p7824 = inttoptr i64 %v7823 to ptr
  store i64 %v7822, ptr %p7824, align 8, !alias.scope !3, !noalias !4
  %v7825 = load i64, ptr %slot31, align 8
  store i64 %v7825, ptr %slot1395, align 8
  %v7826 = load i64, ptr %slot32, align 8
  store i64 %v7826, ptr %slot1396, align 8
  %v7827 = load i64, ptr %slot1395, align 8
  %p7828 = inttoptr i64 %v7827 to ptr
  %ld7829 = load i64, ptr %p7828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7829, ptr %slot1397, align 8
  %v7830 = load i64, ptr %slot1397, align 8
  %cmp7831 = icmp ne i64 %v7830, 0
  %cv7832 = zext i1 %cmp7831 to i32
  store i32 %cv7832, ptr %slot1398, align 8
  %v7833 = load i32, ptr %slot1398, align 8
  %cv7834 = zext i32 %v7833 to i64
  %cond7835 = icmp ne i64 %cv7834, 0
  br i1 %cond7835, label %bb_rcgnn1795, label %bb_rcgstore1795
bb_rcgnn1795:
  %v7836 = load i64, ptr %slot1397, align 8
  %op7837 = sub i64 %v7836, 16
  store i64 %op7837, ptr %slot1399, align 8
  %v7838 = load i64, ptr %slot1397, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  %rgep7840 = getelementptr i8, ptr %p7839, i64 -16
  %ld7841 = load i64, ptr %rgep7840, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7841, ptr %slot1400, align 8
  %v7842 = load i64, ptr %slot1400, align 8
  %op7843 = and i64 %v7842, 4611686018427387906
  store i64 %op7843, ptr %slot1401, align 8
  %v7844 = load i64, ptr %slot1401, align 8
  %cmp7845 = icmp ne i64 %v7844, 0
  %cv7846 = zext i1 %cmp7845 to i32
  store i32 %cv7846, ptr %slot1402, align 8
  %v7847 = load i32, ptr %slot1402, align 8
  %cv7848 = zext i32 %v7847 to i64
  %cond7849 = icmp ne i64 %cv7848, 0
  br i1 %cond7849, label %bb_rcgstore1795, label %bb_rcginc1795
bb_rcginc1795:
  %v7850 = load i64, ptr %slot1397, align 8
  %op7851 = sub i64 %v7850, 24
  store i64 %op7851, ptr %slot1403, align 8
  %v7852 = load i64, ptr %slot1397, align 8
  %p7853 = inttoptr i64 %v7852 to ptr
  %rgep7854 = getelementptr i8, ptr %p7853, i64 -24
  %ld7855 = load i64, ptr %rgep7854, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7855, ptr %slot1404, align 8
  %v7856 = load i64, ptr %slot1404, align 8
  %op7857 = add i64 %v7856, 1
  store i64 %op7857, ptr %slot1405, align 8
  %v7858 = load i64, ptr %slot1405, align 8
  %cmp7859 = icmp eq i64 %v7858, 0
  %cv7860 = zext i1 %cmp7859 to i32
  store i32 %cv7860, ptr %slot1406, align 8
  %v7861 = load i32, ptr %slot1406, align 8
  %cv7862 = zext i32 %v7861 to i64
  %cond7863 = icmp ne i64 %cv7862, 0
  br i1 %cond7863, label %bb_rcglimit1795, label %bb_rcgcapacity1795
bb_rcglimit1795:
  %v7864 = load i64, ptr %slot1, align 8
  %p7865 = inttoptr i64 %v7864 to ptr
  %call7866 = call i32 @myl_qbe_rc_status(ptr %p7865, i32 2) nomerge, !dbg !212
  store i32 %call7866, ptr %slot1407, align 8
  br label %bb_failure
bb_rcgcapacity1795:
  %v7867 = load i64, ptr %slot1405, align 8
  %v7868 = load i64, ptr %slot1397, align 8
  %p7869 = inttoptr i64 %v7868 to ptr
  %rgep7870 = getelementptr i8, ptr %p7869, i64 -24
  store i64 %v7867, ptr %rgep7870, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1795
bb_rcgstore1795:
  %v7871 = load i64, ptr %slot1397, align 8
  %v7872 = load i64, ptr %slot1396, align 8
  %p7873 = inttoptr i64 %v7872 to ptr
  store i64 %v7871, ptr %p7873, align 8, !alias.scope !3, !noalias !4
  %v7874 = load i64, ptr %slot28, align 8
  %p7875 = inttoptr i64 %v7874 to ptr
  store i32 2, ptr %p7875, align 4, !alias.scope !3, !noalias !4
  %v7876 = load i64, ptr %slot28, align 8
  %p7877 = inttoptr i64 %v7876 to ptr
  store i32 16, ptr %p7877, align 4, !alias.scope !3, !noalias !4
  %v7878 = load i64, ptr %slot27, align 8
  %p7879 = inttoptr i64 %v7878 to ptr
  store i32 1, ptr %p7879, align 4, !alias.scope !3, !noalias !4
  %v7880 = load i64, ptr %slot23, align 8
  %p7881 = inttoptr i64 %v7880 to ptr
  %ld7882 = load i32, ptr %p7881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7882, ptr %slot1408, align 8
  %v7883 = load i32, ptr %slot1408, align 8
  %cv7884 = zext i32 %v7883 to i64
  %cond7885 = icmp ne i64 %cv7884, 0
  br i1 %cond7885, label %bb_rcslotdrop1811, label %bb_rcslotdone1811
bb_rcslotdrop1811:
  %v7886 = load i64, ptr %slot23, align 8
  %p7887 = inttoptr i64 %v7886 to ptr
  store i32 0, ptr %p7887, align 4, !alias.scope !3, !noalias !4
  %v7888 = load i64, ptr %slot29, align 8
  store i64 %v7888, ptr %slot1409, align 8
  %v7889 = load i64, ptr %slot24, align 8
  %p7890 = inttoptr i64 %v7889 to ptr
  %ld7891 = load i32, ptr %p7890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7891, ptr %slot1410, align 8
  %v7892 = load i32, ptr %slot1410, align 8
  %op7893 = and i32 %v7892, 28
  store i32 %op7893, ptr %slot1411, align 8
  %v7894 = load i32, ptr %slot1411, align 8
  %cv7895 = zext i32 %v7894 to i64
  %cond7896 = icmp ne i64 %cv7895, 0
  br i1 %cond7896, label %bb_rcslotrole1811, label %bb_rcslotowner1811
bb_rcslotrole1811:
  %v7897 = load i64, ptr %slot65, align 8
  store i64 %v7897, ptr %slot1412, align 8
  %v7898 = load i64, ptr %slot1412, align 8
  %v7899 = load i64, ptr %slot1409, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v7898, i64 %v7899) nomerge, !dbg !212
  br label %bb_rcslotdone1811
bb_rcslotowner1811:
  %v7900 = load i64, ptr %slot65, align 8
  store i64 %v7900, ptr %slot1413, align 8
  %v7901 = load i64, ptr %slot1413, align 8
  %v7902 = load i64, ptr %slot1409, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v7901, i64 %v7902) nomerge, !dbg !212
  br label %bb_rcslotdone1811
bb_rcslotdone1811:
  %v7903 = load i64, ptr %slot29, align 8
  store i64 %v7903, ptr %slot1414, align 8
  %v7904 = load i64, ptr %slot32, align 8
  store i64 %v7904, ptr %slot1415, align 8
  %v7905 = load i64, ptr %slot1415, align 8
  %v7906 = load i64, ptr %slot1414, align 8
  %p7907 = inttoptr i64 %v7905 to ptr
  %p7908 = inttoptr i64 %v7906 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7908, ptr %p7907, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7909 = load i64, ptr %slot24, align 8
  %p7910 = inttoptr i64 %v7909 to ptr
  store i32 2, ptr %p7910, align 4, !alias.scope !3, !noalias !4
  %v7911 = load i64, ptr %slot28, align 8
  %p7912 = inttoptr i64 %v7911 to ptr
  %ld7913 = load i32, ptr %p7912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7913, ptr %slot1416, align 8
  %v7914 = load i32, ptr %slot1416, align 8
  %v7915 = load i64, ptr %slot24, align 8
  %p7916 = inttoptr i64 %v7915 to ptr
  store i32 %v7914, ptr %p7916, align 4, !alias.scope !3, !noalias !4
  %v7917 = load i64, ptr %slot27, align 8
  %p7918 = inttoptr i64 %v7917 to ptr
  store i32 0, ptr %p7918, align 4, !alias.scope !3, !noalias !4
  %v7919 = load i64, ptr %slot23, align 8
  %p7920 = inttoptr i64 %v7919 to ptr
  store i32 1, ptr %p7920, align 4, !alias.scope !3, !noalias !4
  %v7921 = load i64, ptr %slot1414, align 8
  %p7922 = inttoptr i64 %v7921 to ptr
  %ld7923 = load i64, ptr %p7922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7923, ptr %slot1417, align 8
  %v7924 = load i64, ptr %slot1417, align 8
  %v7925 = load i64, ptr %slot58, align 8
  %p7926 = inttoptr i64 %v7925 to ptr
  store i64 %v7924, ptr %p7926, align 8, !alias.scope !3, !noalias !4
  %v7927 = load i64, ptr %slot58, align 8
  %p7928 = inttoptr i64 %v7927 to ptr
  %ld7929 = load i64, ptr %p7928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7929, ptr %slot1418, align 8
  %v7930 = load i64, ptr %slot32, align 8
  store i64 %v7930, ptr %slot1419, align 8
  %v7931 = load i64, ptr %slot1418, align 8
  %cmp7932 = icmp ne i64 %v7931, 0
  %cv7933 = zext i1 %cmp7932 to i32
  store i32 %cv7933, ptr %slot1420, align 8
  %v7934 = load i32, ptr %slot1420, align 8
  %cv7935 = zext i32 %v7934 to i64
  %cond7936 = icmp ne i64 %cv7935, 0
  br i1 %cond7936, label %bb_rcgnn1831, label %bb_rcgstore1831
bb_rcgnn1831:
  %v7937 = load i64, ptr %slot1418, align 8
  %op7938 = sub i64 %v7937, 16
  store i64 %op7938, ptr %slot1421, align 8
  %v7939 = load i64, ptr %slot1418, align 8
  %p7940 = inttoptr i64 %v7939 to ptr
  %rgep7941 = getelementptr i8, ptr %p7940, i64 -16
  %ld7942 = load i64, ptr %rgep7941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7942, ptr %slot1422, align 8
  %v7943 = load i64, ptr %slot1422, align 8
  %op7944 = and i64 %v7943, 4611686018427387906
  store i64 %op7944, ptr %slot1423, align 8
  %v7945 = load i64, ptr %slot1423, align 8
  %cmp7946 = icmp ne i64 %v7945, 0
  %cv7947 = zext i1 %cmp7946 to i32
  store i32 %cv7947, ptr %slot1424, align 8
  %v7948 = load i32, ptr %slot1424, align 8
  %cv7949 = zext i32 %v7948 to i64
  %cond7950 = icmp ne i64 %cv7949, 0
  br i1 %cond7950, label %bb_rcgstore1831, label %bb_rcginc1831
bb_rcginc1831:
  %v7951 = load i64, ptr %slot1418, align 8
  %op7952 = sub i64 %v7951, 24
  store i64 %op7952, ptr %slot1425, align 8
  %v7953 = load i64, ptr %slot1418, align 8
  %p7954 = inttoptr i64 %v7953 to ptr
  %rgep7955 = getelementptr i8, ptr %p7954, i64 -24
  %ld7956 = load i64, ptr %rgep7955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7956, ptr %slot1426, align 8
  %v7957 = load i64, ptr %slot1426, align 8
  %op7958 = add i64 %v7957, 1
  store i64 %op7958, ptr %slot1427, align 8
  %v7959 = load i64, ptr %slot1427, align 8
  %cmp7960 = icmp eq i64 %v7959, 0
  %cv7961 = zext i1 %cmp7960 to i32
  store i32 %cv7961, ptr %slot1428, align 8
  %v7962 = load i32, ptr %slot1428, align 8
  %cv7963 = zext i32 %v7962 to i64
  %cond7964 = icmp ne i64 %cv7963, 0
  br i1 %cond7964, label %bb_rcglimit1831, label %bb_rcgcapacity1831
bb_rcglimit1831:
  %v7965 = load i64, ptr %slot1, align 8
  %p7966 = inttoptr i64 %v7965 to ptr
  %call7967 = call i32 @myl_qbe_rc_status(ptr %p7966, i32 2) nomerge, !dbg !214
  store i32 %call7967, ptr %slot1429, align 8
  br label %bb_failure
bb_rcgcapacity1831:
  %v7968 = load i64, ptr %slot1427, align 8
  %v7969 = load i64, ptr %slot1418, align 8
  %p7970 = inttoptr i64 %v7969 to ptr
  %rgep7971 = getelementptr i8, ptr %p7970, i64 -24
  store i64 %v7968, ptr %rgep7971, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1831
bb_rcgstore1831:
  %v7972 = load i64, ptr %slot1418, align 8
  %v7973 = load i64, ptr %slot1419, align 8
  %p7974 = inttoptr i64 %v7973 to ptr
  store i64 %v7972, ptr %p7974, align 8, !alias.scope !3, !noalias !4
  %v7975 = load i64, ptr %slot28, align 8
  %p7976 = inttoptr i64 %v7975 to ptr
  store i32 2, ptr %p7976, align 4, !alias.scope !3, !noalias !4
  %v7977 = load i64, ptr %slot28, align 8
  %p7978 = inttoptr i64 %v7977 to ptr
  store i32 8, ptr %p7978, align 4, !alias.scope !3, !noalias !4
  %v7979 = load i64, ptr %slot27, align 8
  %p7980 = inttoptr i64 %v7979 to ptr
  store i32 1, ptr %p7980, align 4, !alias.scope !3, !noalias !4
  %v7981 = load i64, ptr %slot23, align 8
  %p7982 = inttoptr i64 %v7981 to ptr
  %ld7983 = load i32, ptr %p7982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7983, ptr %slot1430, align 8
  %v7984 = load i32, ptr %slot1430, align 8
  %cv7985 = zext i32 %v7984 to i64
  %cond7986 = icmp ne i64 %cv7985, 0
  br i1 %cond7986, label %bb_rcslotdrop1847, label %bb_rcslotdone1847
bb_rcslotdrop1847:
  %v7987 = load i64, ptr %slot23, align 8
  %p7988 = inttoptr i64 %v7987 to ptr
  store i32 0, ptr %p7988, align 4, !alias.scope !3, !noalias !4
  %v7989 = load i64, ptr %slot29, align 8
  store i64 %v7989, ptr %slot1431, align 8
  %v7990 = load i64, ptr %slot24, align 8
  %p7991 = inttoptr i64 %v7990 to ptr
  %ld7992 = load i32, ptr %p7991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7992, ptr %slot1432, align 8
  %v7993 = load i32, ptr %slot1432, align 8
  %op7994 = and i32 %v7993, 28
  store i32 %op7994, ptr %slot1433, align 8
  %v7995 = load i32, ptr %slot1433, align 8
  %cv7996 = zext i32 %v7995 to i64
  %cond7997 = icmp ne i64 %cv7996, 0
  br i1 %cond7997, label %bb_rcslotrole1847, label %bb_rcslotowner1847
bb_rcslotrole1847:
  %v7998 = load i64, ptr %slot65, align 8
  store i64 %v7998, ptr %slot1434, align 8
  %v7999 = load i64, ptr %slot1431, align 8
  %p8000 = inttoptr i64 %v7999 to ptr
  %ld8001 = load i64, ptr %p8000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8001, ptr %slot1435, align 8
  %v8002 = load i64, ptr %slot1435, align 8
  %cmp8003 = icmp ne i64 %v8002, 0
  %cv8004 = zext i1 %cmp8003 to i32
  store i32 %cv8004, ptr %slot1436, align 8
  %v8005 = load i32, ptr %slot1436, align 8
  %cv8006 = zext i32 %v8005 to i64
  %cond8007 = icmp ne i64 %cv8006, 0
  br i1 %cond8007, label %bb_rcgnn1863, label %bb_rcgdone1863
bb_rcgnn1863:
  %v8008 = load i64, ptr %slot1435, align 8
  %op8009 = sub i64 %v8008, 16
  store i64 %op8009, ptr %slot1437, align 8
  %v8010 = load i64, ptr %slot1435, align 8
  %p8011 = inttoptr i64 %v8010 to ptr
  %rgep8012 = getelementptr i8, ptr %p8011, i64 -16
  %ld8013 = load i64, ptr %rgep8012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8013, ptr %slot1438, align 8
  %v8014 = load i64, ptr %slot1438, align 8
  %op8015 = and i64 %v8014, 4611686018427387906
  store i64 %op8015, ptr %slot1439, align 8
  %v8016 = load i64, ptr %slot1439, align 8
  %cmp8017 = icmp ne i64 %v8016, 0
  %cv8018 = zext i1 %cmp8017 to i32
  store i32 %cv8018, ptr %slot1440, align 8
  %v8019 = load i32, ptr %slot1440, align 8
  %cv8020 = zext i32 %v8019 to i64
  %cond8021 = icmp ne i64 %cv8020, 0
  br i1 %cond8021, label %bb_rcgclear1863, label %bb_rcgcounted1863
bb_rcgcounted1863:
  %v8022 = load i64, ptr %slot1435, align 8
  %op8023 = sub i64 %v8022, 24
  store i64 %op8023, ptr %slot1441, align 8
  %v8024 = load i64, ptr %slot1435, align 8
  %p8025 = inttoptr i64 %v8024 to ptr
  %rgep8026 = getelementptr i8, ptr %p8025, i64 -24
  %ld8027 = load i64, ptr %rgep8026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8027, ptr %slot1442, align 8
  %v8028 = load i64, ptr %slot1442, align 8
  %op8029 = sub i64 %v8028, 1
  store i64 %op8029, ptr %slot1443, align 8
  %v8030 = load i64, ptr %slot1443, align 8
  %cmp8031 = icmp eq i64 %v8030, 0
  %cv8032 = zext i1 %cmp8031 to i32
  store i32 %cv8032, ptr %slot1444, align 8
  %v8033 = load i32, ptr %slot1444, align 8
  %cv8034 = zext i32 %v8033 to i64
  %cond8035 = icmp ne i64 %cv8034, 0
  br i1 %cond8035, label %bb_rcglast1863, label %bb_rcgdec1863
bb_rcglast1863:
  %v8036 = load i64, ptr %slot1435, align 8
  %op8037 = sub i64 %v8036, 32
  store i64 %op8037, ptr %slot1445, align 8
  %v8038 = load i64, ptr %slot1435, align 8
  %p8039 = inttoptr i64 %v8038 to ptr
  %rgep8040 = getelementptr i8, ptr %p8039, i64 -32
  %ld8041 = load i64, ptr %rgep8040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8041, ptr %slot1446, align 8
  %v8042 = load i64, ptr %slot1446, align 8
  %cmp8043 = icmp ne i64 %v8042, 0
  %cv8044 = zext i1 %cmp8043 to i32
  store i32 %cv8044, ptr %slot1447, align 8
  %v8045 = load i32, ptr %slot1447, align 8
  %cv8046 = zext i32 %v8045 to i64
  %cond8047 = icmp ne i64 %cv8046, 0
  br i1 %cond8047, label %bb_rcgdec1863, label %bb_rcgslow1863
bb_rcgslow1863:
  %v8048 = load i64, ptr %slot1434, align 8
  %v8049 = load i64, ptr %slot1431, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v8048, i64 %v8049) nomerge, !dbg !214
  br label %bb_rcgdone1863
bb_rcgdec1863:
  %v8050 = load i64, ptr %slot1443, align 8
  %v8051 = load i64, ptr %slot1435, align 8
  %p8052 = inttoptr i64 %v8051 to ptr
  %rgep8053 = getelementptr i8, ptr %p8052, i64 -24
  store i64 %v8050, ptr %rgep8053, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1863
bb_rcgclear1863:
  %v8054 = load i64, ptr %slot1431, align 8
  %p8055 = inttoptr i64 %v8054 to ptr
  store i64 0, ptr %p8055, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1863
bb_rcgdone1863:
  br label %bb_rcslotdone1847
bb_rcslotowner1847:
  %v8056 = load i64, ptr %slot65, align 8
  store i64 %v8056, ptr %slot1448, align 8
  %v8057 = load i64, ptr %slot1431, align 8
  %p8058 = inttoptr i64 %v8057 to ptr
  %ld8059 = load i64, ptr %p8058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8059, ptr %slot1449, align 8
  %v8060 = load i64, ptr %slot1449, align 8
  %cmp8061 = icmp ne i64 %v8060, 0
  %cv8062 = zext i1 %cmp8061 to i32
  store i32 %cv8062, ptr %slot1450, align 8
  %v8063 = load i32, ptr %slot1450, align 8
  %cv8064 = zext i32 %v8063 to i64
  %cond8065 = icmp ne i64 %cv8064, 0
  br i1 %cond8065, label %bb_rcgnn1878, label %bb_rcgdone1878
bb_rcgnn1878:
  %v8066 = load i64, ptr %slot1449, align 8
  %op8067 = sub i64 %v8066, 16
  store i64 %op8067, ptr %slot1451, align 8
  %v8068 = load i64, ptr %slot1449, align 8
  %p8069 = inttoptr i64 %v8068 to ptr
  %rgep8070 = getelementptr i8, ptr %p8069, i64 -16
  %ld8071 = load i64, ptr %rgep8070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8071, ptr %slot1452, align 8
  %v8072 = load i64, ptr %slot1452, align 8
  %op8073 = and i64 %v8072, 4611686018427387906
  store i64 %op8073, ptr %slot1453, align 8
  %v8074 = load i64, ptr %slot1453, align 8
  %cmp8075 = icmp ne i64 %v8074, 0
  %cv8076 = zext i1 %cmp8075 to i32
  store i32 %cv8076, ptr %slot1454, align 8
  %v8077 = load i32, ptr %slot1454, align 8
  %cv8078 = zext i32 %v8077 to i64
  %cond8079 = icmp ne i64 %cv8078, 0
  br i1 %cond8079, label %bb_rcgclear1878, label %bb_rcgcounted1878
bb_rcgcounted1878:
  %v8080 = load i64, ptr %slot1449, align 8
  %op8081 = sub i64 %v8080, 32
  store i64 %op8081, ptr %slot1455, align 8
  %v8082 = load i64, ptr %slot1449, align 8
  %p8083 = inttoptr i64 %v8082 to ptr
  %rgep8084 = getelementptr i8, ptr %p8083, i64 -32
  %ld8085 = load i64, ptr %rgep8084, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8085, ptr %slot1456, align 8
  %v8086 = load i64, ptr %slot1456, align 8
  %op8087 = sub i64 %v8086, 1
  store i64 %op8087, ptr %slot1457, align 8
  %v8088 = load i64, ptr %slot1457, align 8
  %cmp8089 = icmp eq i64 %v8088, 0
  %cv8090 = zext i1 %cmp8089 to i32
  store i32 %cv8090, ptr %slot1458, align 8
  %v8091 = load i32, ptr %slot1458, align 8
  %cv8092 = zext i32 %v8091 to i64
  %cond8093 = icmp ne i64 %cv8092, 0
  br i1 %cond8093, label %bb_rcglast1878, label %bb_rcgdec1878
bb_rcglast1878:
  %v8094 = load i64, ptr %slot1449, align 8
  %op8095 = sub i64 %v8094, 24
  store i64 %op8095, ptr %slot1459, align 8
  %v8096 = load i64, ptr %slot1449, align 8
  %p8097 = inttoptr i64 %v8096 to ptr
  %rgep8098 = getelementptr i8, ptr %p8097, i64 -24
  %ld8099 = load i64, ptr %rgep8098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8099, ptr %slot1460, align 8
  %v8100 = load i64, ptr %slot1460, align 8
  %cmp8101 = icmp ne i64 %v8100, 0
  %cv8102 = zext i1 %cmp8101 to i32
  store i32 %cv8102, ptr %slot1461, align 8
  %v8103 = load i32, ptr %slot1461, align 8
  %cv8104 = zext i32 %v8103 to i64
  %cond8105 = icmp ne i64 %cv8104, 0
  br i1 %cond8105, label %bb_rcgdec1878, label %bb_rcgslow1878
bb_rcgslow1878:
  %v8106 = load i64, ptr %slot1448, align 8
  %v8107 = load i64, ptr %slot1431, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v8106, i64 %v8107) nomerge, !dbg !214
  br label %bb_rcgdone1878
bb_rcgdec1878:
  %v8108 = load i64, ptr %slot1457, align 8
  %v8109 = load i64, ptr %slot1449, align 8
  %p8110 = inttoptr i64 %v8109 to ptr
  %rgep8111 = getelementptr i8, ptr %p8110, i64 -32
  store i64 %v8108, ptr %rgep8111, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1878
bb_rcgclear1878:
  %v8112 = load i64, ptr %slot1431, align 8
  %p8113 = inttoptr i64 %v8112 to ptr
  store i64 0, ptr %p8113, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1878
bb_rcgdone1878:
  br label %bb_rcslotdone1847
bb_rcslotdone1847:
  %v8114 = load i64, ptr %slot29, align 8
  store i64 %v8114, ptr %slot1462, align 8
  %v8115 = load i64, ptr %slot32, align 8
  store i64 %v8115, ptr %slot1463, align 8
  %v8116 = load i64, ptr %slot1463, align 8
  %p8117 = inttoptr i64 %v8116 to ptr
  %ld8118 = load i64, ptr %p8117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8118, ptr %slot1464, align 8
  %v8119 = load i64, ptr %slot1464, align 8
  %v8120 = load i64, ptr %slot1462, align 8
  %p8121 = inttoptr i64 %v8120 to ptr
  store i64 %v8119, ptr %p8121, align 8, !alias.scope !3, !noalias !4
  %v8122 = load i64, ptr %slot24, align 8
  %p8123 = inttoptr i64 %v8122 to ptr
  store i32 2, ptr %p8123, align 4, !alias.scope !3, !noalias !4
  %v8124 = load i64, ptr %slot24, align 8
  %p8125 = inttoptr i64 %v8124 to ptr
  store i32 8, ptr %p8125, align 4, !alias.scope !3, !noalias !4
  %v8126 = load i64, ptr %slot23, align 8
  %p8127 = inttoptr i64 %v8126 to ptr
  store i32 1, ptr %p8127, align 4, !alias.scope !3, !noalias !4
  %v8128 = load i64, ptr %slot27, align 8
  %p8129 = inttoptr i64 %v8128 to ptr
  store i32 0, ptr %p8129, align 4, !alias.scope !3, !noalias !4
  %v8130 = load i64, ptr %slot1464, align 8
  %v8131 = load i64, ptr %slot58, align 8
  %p8132 = inttoptr i64 %v8131 to ptr
  store i64 %v8130, ptr %p8132, align 8, !alias.scope !3, !noalias !4
  %v8133 = load i64, ptr %slot32, align 8
  store i64 %v8133, ptr %slot1465, align 8
  %v8134 = load i64, ptr %slot58, align 8
  %p8135 = inttoptr i64 %v8134 to ptr
  %ld8136 = load i64, ptr %p8135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8136, ptr %slot1466, align 8
  %v8137 = load i64, ptr %slot1466, align 8
  %v8138 = load i64, ptr %slot1465, align 8
  %p8139 = inttoptr i64 %v8138 to ptr
  store i64 %v8137, ptr %p8139, align 8, !alias.scope !3, !noalias !4
  %v8140 = load i64, ptr %slot28, align 8
  %p8141 = inttoptr i64 %v8140 to ptr
  store i32 2, ptr %p8141, align 4, !alias.scope !3, !noalias !4
  %v8142 = load i64, ptr %slot28, align 8
  %p8143 = inttoptr i64 %v8142 to ptr
  store i32 8, ptr %p8143, align 4, !alias.scope !3, !noalias !4
  %v8144 = load i64, ptr %slot27, align 8
  %p8145 = inttoptr i64 %v8144 to ptr
  store i32 1, ptr %p8145, align 4, !alias.scope !3, !noalias !4
  %v8146 = load i64, ptr %slot23, align 8
  %p8147 = inttoptr i64 %v8146 to ptr
  store i32 0, ptr %p8147, align 4, !alias.scope !3, !noalias !4
  %v8148 = load i64, ptr %slot21, align 8
  %p8149 = inttoptr i64 %v8148 to ptr
  %ld8150 = load i32, ptr %p8149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8150, ptr %slot1467, align 8
  %v8151 = load i32, ptr %slot1467, align 8
  %cv8152 = zext i32 %v8151 to i64
  %cond8153 = icmp ne i64 %cv8152, 0
  br i1 %cond8153, label %bb_rcslotdrop1897, label %bb_rcslotdone1897
bb_rcslotdrop1897:
  %v8154 = load i64, ptr %slot21, align 8
  %p8155 = inttoptr i64 %v8154 to ptr
  store i32 0, ptr %p8155, align 4, !alias.scope !3, !noalias !4
  %v8156 = load i64, ptr %slot53, align 8
  store i64 %v8156, ptr %slot1468, align 8
  %v8157 = load i64, ptr %slot22, align 8
  %p8158 = inttoptr i64 %v8157 to ptr
  %ld8159 = load i32, ptr %p8158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8159, ptr %slot1469, align 8
  %v8160 = load i32, ptr %slot1469, align 8
  %op8161 = and i32 %v8160, 28
  store i32 %op8161, ptr %slot1470, align 8
  %v8162 = load i32, ptr %slot1470, align 8
  %cv8163 = zext i32 %v8162 to i64
  %cond8164 = icmp ne i64 %cv8163, 0
  br i1 %cond8164, label %bb_rcslotrole1897, label %bb_rcslotowner1897
bb_rcslotrole1897:
  %v8165 = load i64, ptr %slot65, align 8
  store i64 %v8165, ptr %slot1471, align 8
  %v8166 = load i64, ptr %slot1468, align 8
  %p8167 = inttoptr i64 %v8166 to ptr
  %ld8168 = load i64, ptr %p8167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8168, ptr %slot1472, align 8
  %v8169 = load i64, ptr %slot1472, align 8
  %cmp8170 = icmp ne i64 %v8169, 0
  %cv8171 = zext i1 %cmp8170 to i32
  store i32 %cv8171, ptr %slot1473, align 8
  %v8172 = load i32, ptr %slot1473, align 8
  %cv8173 = zext i32 %v8172 to i64
  %cond8174 = icmp ne i64 %cv8173, 0
  br i1 %cond8174, label %bb_rcgnn1913, label %bb_rcgdone1913
bb_rcgnn1913:
  %v8175 = load i64, ptr %slot1472, align 8
  %op8176 = sub i64 %v8175, 16
  store i64 %op8176, ptr %slot1474, align 8
  %v8177 = load i64, ptr %slot1472, align 8
  %p8178 = inttoptr i64 %v8177 to ptr
  %rgep8179 = getelementptr i8, ptr %p8178, i64 -16
  %ld8180 = load i64, ptr %rgep8179, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8180, ptr %slot1475, align 8
  %v8181 = load i64, ptr %slot1475, align 8
  %op8182 = and i64 %v8181, 4611686018427387906
  store i64 %op8182, ptr %slot1476, align 8
  %v8183 = load i64, ptr %slot1476, align 8
  %cmp8184 = icmp ne i64 %v8183, 0
  %cv8185 = zext i1 %cmp8184 to i32
  store i32 %cv8185, ptr %slot1477, align 8
  %v8186 = load i32, ptr %slot1477, align 8
  %cv8187 = zext i32 %v8186 to i64
  %cond8188 = icmp ne i64 %cv8187, 0
  br i1 %cond8188, label %bb_rcgclear1913, label %bb_rcgcounted1913
bb_rcgcounted1913:
  %v8189 = load i64, ptr %slot1472, align 8
  %op8190 = sub i64 %v8189, 24
  store i64 %op8190, ptr %slot1478, align 8
  %v8191 = load i64, ptr %slot1472, align 8
  %p8192 = inttoptr i64 %v8191 to ptr
  %rgep8193 = getelementptr i8, ptr %p8192, i64 -24
  %ld8194 = load i64, ptr %rgep8193, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8194, ptr %slot1479, align 8
  %v8195 = load i64, ptr %slot1479, align 8
  %op8196 = sub i64 %v8195, 1
  store i64 %op8196, ptr %slot1480, align 8
  %v8197 = load i64, ptr %slot1480, align 8
  %cmp8198 = icmp eq i64 %v8197, 0
  %cv8199 = zext i1 %cmp8198 to i32
  store i32 %cv8199, ptr %slot1481, align 8
  %v8200 = load i32, ptr %slot1481, align 8
  %cv8201 = zext i32 %v8200 to i64
  %cond8202 = icmp ne i64 %cv8201, 0
  br i1 %cond8202, label %bb_rcglast1913, label %bb_rcgdec1913
bb_rcglast1913:
  %v8203 = load i64, ptr %slot1472, align 8
  %op8204 = sub i64 %v8203, 32
  store i64 %op8204, ptr %slot1482, align 8
  %v8205 = load i64, ptr %slot1472, align 8
  %p8206 = inttoptr i64 %v8205 to ptr
  %rgep8207 = getelementptr i8, ptr %p8206, i64 -32
  %ld8208 = load i64, ptr %rgep8207, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8208, ptr %slot1483, align 8
  %v8209 = load i64, ptr %slot1483, align 8
  %cmp8210 = icmp ne i64 %v8209, 0
  %cv8211 = zext i1 %cmp8210 to i32
  store i32 %cv8211, ptr %slot1484, align 8
  %v8212 = load i32, ptr %slot1484, align 8
  %cv8213 = zext i32 %v8212 to i64
  %cond8214 = icmp ne i64 %cv8213, 0
  br i1 %cond8214, label %bb_rcgdec1913, label %bb_rcgslow1913
bb_rcgslow1913:
  %v8215 = load i64, ptr %slot1471, align 8
  %v8216 = load i64, ptr %slot1468, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v8215, i64 %v8216) nomerge, !dbg !214
  br label %bb_rcgdone1913
bb_rcgdec1913:
  %v8217 = load i64, ptr %slot1480, align 8
  %v8218 = load i64, ptr %slot1472, align 8
  %p8219 = inttoptr i64 %v8218 to ptr
  %rgep8220 = getelementptr i8, ptr %p8219, i64 -24
  store i64 %v8217, ptr %rgep8220, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1913
bb_rcgclear1913:
  %v8221 = load i64, ptr %slot1468, align 8
  %p8222 = inttoptr i64 %v8221 to ptr
  store i64 0, ptr %p8222, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1913
bb_rcgdone1913:
  br label %bb_rcslotdone1897
bb_rcslotowner1897:
  %v8223 = load i64, ptr %slot65, align 8
  store i64 %v8223, ptr %slot1485, align 8
  %v8224 = load i64, ptr %slot1468, align 8
  %p8225 = inttoptr i64 %v8224 to ptr
  %ld8226 = load i64, ptr %p8225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8226, ptr %slot1486, align 8
  %v8227 = load i64, ptr %slot1486, align 8
  %cmp8228 = icmp ne i64 %v8227, 0
  %cv8229 = zext i1 %cmp8228 to i32
  store i32 %cv8229, ptr %slot1487, align 8
  %v8230 = load i32, ptr %slot1487, align 8
  %cv8231 = zext i32 %v8230 to i64
  %cond8232 = icmp ne i64 %cv8231, 0
  br i1 %cond8232, label %bb_rcgnn1928, label %bb_rcgdone1928
bb_rcgnn1928:
  %v8233 = load i64, ptr %slot1486, align 8
  %op8234 = sub i64 %v8233, 16
  store i64 %op8234, ptr %slot1488, align 8
  %v8235 = load i64, ptr %slot1486, align 8
  %p8236 = inttoptr i64 %v8235 to ptr
  %rgep8237 = getelementptr i8, ptr %p8236, i64 -16
  %ld8238 = load i64, ptr %rgep8237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8238, ptr %slot1489, align 8
  %v8239 = load i64, ptr %slot1489, align 8
  %op8240 = and i64 %v8239, 4611686018427387906
  store i64 %op8240, ptr %slot1490, align 8
  %v8241 = load i64, ptr %slot1490, align 8
  %cmp8242 = icmp ne i64 %v8241, 0
  %cv8243 = zext i1 %cmp8242 to i32
  store i32 %cv8243, ptr %slot1491, align 8
  %v8244 = load i32, ptr %slot1491, align 8
  %cv8245 = zext i32 %v8244 to i64
  %cond8246 = icmp ne i64 %cv8245, 0
  br i1 %cond8246, label %bb_rcgclear1928, label %bb_rcgcounted1928
bb_rcgcounted1928:
  %v8247 = load i64, ptr %slot1486, align 8
  %op8248 = sub i64 %v8247, 32
  store i64 %op8248, ptr %slot1492, align 8
  %v8249 = load i64, ptr %slot1486, align 8
  %p8250 = inttoptr i64 %v8249 to ptr
  %rgep8251 = getelementptr i8, ptr %p8250, i64 -32
  %ld8252 = load i64, ptr %rgep8251, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8252, ptr %slot1493, align 8
  %v8253 = load i64, ptr %slot1493, align 8
  %op8254 = sub i64 %v8253, 1
  store i64 %op8254, ptr %slot1494, align 8
  %v8255 = load i64, ptr %slot1494, align 8
  %cmp8256 = icmp eq i64 %v8255, 0
  %cv8257 = zext i1 %cmp8256 to i32
  store i32 %cv8257, ptr %slot1495, align 8
  %v8258 = load i32, ptr %slot1495, align 8
  %cv8259 = zext i32 %v8258 to i64
  %cond8260 = icmp ne i64 %cv8259, 0
  br i1 %cond8260, label %bb_rcglast1928, label %bb_rcgdec1928
bb_rcglast1928:
  %v8261 = load i64, ptr %slot1486, align 8
  %op8262 = sub i64 %v8261, 24
  store i64 %op8262, ptr %slot1496, align 8
  %v8263 = load i64, ptr %slot1486, align 8
  %p8264 = inttoptr i64 %v8263 to ptr
  %rgep8265 = getelementptr i8, ptr %p8264, i64 -24
  %ld8266 = load i64, ptr %rgep8265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8266, ptr %slot1497, align 8
  %v8267 = load i64, ptr %slot1497, align 8
  %cmp8268 = icmp ne i64 %v8267, 0
  %cv8269 = zext i1 %cmp8268 to i32
  store i32 %cv8269, ptr %slot1498, align 8
  %v8270 = load i32, ptr %slot1498, align 8
  %cv8271 = zext i32 %v8270 to i64
  %cond8272 = icmp ne i64 %cv8271, 0
  br i1 %cond8272, label %bb_rcgdec1928, label %bb_rcgslow1928
bb_rcgslow1928:
  %v8273 = load i64, ptr %slot1485, align 8
  %v8274 = load i64, ptr %slot1468, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v8273, i64 %v8274) nomerge, !dbg !214
  br label %bb_rcgdone1928
bb_rcgdec1928:
  %v8275 = load i64, ptr %slot1494, align 8
  %v8276 = load i64, ptr %slot1486, align 8
  %p8277 = inttoptr i64 %v8276 to ptr
  %rgep8278 = getelementptr i8, ptr %p8277, i64 -32
  store i64 %v8275, ptr %rgep8278, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1928
bb_rcgclear1928:
  %v8279 = load i64, ptr %slot1468, align 8
  %p8280 = inttoptr i64 %v8279 to ptr
  store i64 0, ptr %p8280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1928
bb_rcgdone1928:
  br label %bb_rcslotdone1897
bb_rcslotdone1897:
  %v8281 = load i64, ptr %slot53, align 8
  store i64 %v8281, ptr %slot1499, align 8
  %v8282 = load i64, ptr %slot1465, align 8
  %p8283 = inttoptr i64 %v8282 to ptr
  %ld8284 = load i64, ptr %p8283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8284, ptr %slot1500, align 8
  %v8285 = load i64, ptr %slot1500, align 8
  %v8286 = load i64, ptr %slot1499, align 8
  %p8287 = inttoptr i64 %v8286 to ptr
  store i64 %v8285, ptr %p8287, align 8, !alias.scope !3, !noalias !4
  %v8288 = load i64, ptr %slot22, align 8
  %p8289 = inttoptr i64 %v8288 to ptr
  store i32 2, ptr %p8289, align 4, !alias.scope !3, !noalias !4
  %v8290 = load i64, ptr %slot22, align 8
  %p8291 = inttoptr i64 %v8290 to ptr
  store i32 8, ptr %p8291, align 4, !alias.scope !3, !noalias !4
  %v8292 = load i64, ptr %slot21, align 8
  %p8293 = inttoptr i64 %v8292 to ptr
  store i32 1, ptr %p8293, align 4, !alias.scope !3, !noalias !4
  %v8294 = load i64, ptr %slot27, align 8
  %p8295 = inttoptr i64 %v8294 to ptr
  store i32 0, ptr %p8295, align 4, !alias.scope !3, !noalias !4
  %v8296 = load i64, ptr %slot58, align 8
  %p8297 = inttoptr i64 %v8296 to ptr
  store i64 0, ptr %p8297, align 8, !alias.scope !3, !noalias !4
  %v8298 = load i64, ptr %slot58, align 8
  %p8299 = inttoptr i64 %v8298 to ptr
  %ld8300 = load i64, ptr %p8299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8300, ptr %slot1501, align 8
  %v8301 = load i64, ptr %slot1501, align 8
  %v8302 = load i64, ptr %slot54, align 8
  %p8303 = inttoptr i64 %v8302 to ptr
  store i64 %v8301, ptr %p8303, align 8, !alias.scope !3, !noalias !4
  %v8304 = load i64, ptr %slot53, align 8
  %p8305 = inttoptr i64 %v8304 to ptr
  %ld8306 = load i64, ptr %p8305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8306, ptr %slot1502, align 8
  %v8307 = load i64, ptr %slot1502, align 8
  %op8308 = add i64 %v8307, 0
  store i64 %op8308, ptr %slot1503, align 8
  %v8309 = load i64, ptr %slot1503, align 8
  %p8310 = inttoptr i64 %v8309 to ptr
  %ld8311 = load i64, ptr %p8310, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8311, ptr %slot1504, align 8
  %v8312 = load i64, ptr %slot1504, align 8
  %v8313 = load i64, ptr %slot58, align 8
  %p8314 = inttoptr i64 %v8313 to ptr
  store i64 %v8312, ptr %p8314, align 8, !alias.scope !3, !noalias !4
  %v8315 = load i64, ptr %slot58, align 8
  %p8316 = inttoptr i64 %v8315 to ptr
  %ld8317 = load i64, ptr %p8316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8317, ptr %slot1505, align 8
  %v8318 = load i64, ptr %slot1505, align 8
  %cmp8319 = icmp ugt i64 %v8318, 9223372036854775807
  %cv8320 = zext i1 %cmp8319 to i64
  store i64 %cv8320, ptr %slot1506, align 8
  %v8321 = load i64, ptr %slot1506, align 8
  %cond8322 = icmp ne i64 %v8321, 0
  br i1 %cond8322, label %bb_cast_overflow1944, label %bb_cast_ok1944
bb_cast_overflow1944:
  %v8323 = load i64, ptr %slot1, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  %v8325 = load i64, ptr %slot1505, align 8
  call void @myl_qbe_fail_cast(ptr %p8324, i64 %v8325, i64 320) nomerge, !dbg !216
  unreachable
bb_cast_ok1944:
  %v8326 = load i64, ptr %slot1505, align 8
  %v8327 = load i64, ptr %slot58, align 8
  %p8328 = inttoptr i64 %v8327 to ptr
  store i64 %v8326, ptr %p8328, align 8, !alias.scope !3, !noalias !4
  %v8329 = load i64, ptr %slot58, align 8
  %p8330 = inttoptr i64 %v8329 to ptr
  %ld8331 = load i64, ptr %p8330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8331, ptr %slot1507, align 8
  %v8332 = load i64, ptr %slot1507, align 8
  %v8333 = load i64, ptr %slot55, align 8
  %p8334 = inttoptr i64 %v8333 to ptr
  store i64 %v8332, ptr %p8334, align 8, !alias.scope !3, !noalias !4
  br label %bb_i165
bb_i165:
  %v8335 = load i64, ptr %slot54, align 8
  %p8336 = inttoptr i64 %v8335 to ptr
  %ld8337 = load i64, ptr %p8336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8337, ptr %slot1508, align 8
  %v8338 = load i64, ptr %slot1508, align 8
  %v8339 = load i64, ptr %slot58, align 8
  %p8340 = inttoptr i64 %v8339 to ptr
  store i64 %v8338, ptr %p8340, align 8, !alias.scope !3, !noalias !4
  %v8341 = load i64, ptr %slot55, align 8
  %p8342 = inttoptr i64 %v8341 to ptr
  %ld8343 = load i64, ptr %p8342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8343, ptr %slot1509, align 8
  %v8344 = load i64, ptr %slot1509, align 8
  %v8345 = load i64, ptr %slot59, align 8
  %p8346 = inttoptr i64 %v8345 to ptr
  store i64 %v8344, ptr %p8346, align 8, !alias.scope !3, !noalias !4
  %v8347 = load i64, ptr %slot59, align 8
  %p8348 = inttoptr i64 %v8347 to ptr
  %ld8349 = load i64, ptr %p8348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8349, ptr %slot1510, align 8
  %v8350 = load i64, ptr %slot58, align 8
  %p8351 = inttoptr i64 %v8350 to ptr
  %ld8352 = load i64, ptr %p8351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8352, ptr %slot1511, align 8
  %v8353 = load i64, ptr %slot1511, align 8
  %v8354 = load i64, ptr %slot1510, align 8
  %cmp8355 = icmp slt i64 %v8353, %v8354
  %cv8356 = zext i1 %cmp8355 to i64
  store i64 %cv8356, ptr %slot1512, align 8
  %v8357 = load i64, ptr %slot1512, align 8
  %v8358 = load i64, ptr %slot58, align 8
  %p8359 = inttoptr i64 %v8358 to ptr
  store i64 %v8357, ptr %p8359, align 8, !alias.scope !3, !noalias !4
  %v8360 = load i64, ptr %slot58, align 8
  %p8361 = inttoptr i64 %v8360 to ptr
  %ld8362 = load i64, ptr %p8361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8362, ptr %slot1513, align 8
  %v8363 = load i64, ptr %slot1513, align 8
  %cond8364 = icmp ne i64 %v8363, 0
  br i1 %cond8364, label %bb_next1952, label %bb_i187
bb_next1952:
  %v8365 = load i64, ptr %slot55, align 8
  %p8366 = inttoptr i64 %v8365 to ptr
  %ld8367 = load i64, ptr %p8366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8367, ptr %slot1514, align 8
  %v8368 = load i64, ptr %slot1514, align 8
  %v8369 = load i64, ptr %slot58, align 8
  %p8370 = inttoptr i64 %v8369 to ptr
  store i64 %v8368, ptr %p8370, align 8, !alias.scope !3, !noalias !4
  %v8371 = load i64, ptr %slot53, align 8
  %p8372 = inttoptr i64 %v8371 to ptr
  %ld8373 = load i64, ptr %p8372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8373, ptr %slot1515, align 8
  %v8374 = load i64, ptr %slot58, align 8
  %p8375 = inttoptr i64 %v8374 to ptr
  %ld8376 = load i64, ptr %p8375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8376, ptr %slot1516, align 8
  %v8377 = load i64, ptr %slot1515, align 8
  %p8378 = inttoptr i64 %v8377 to ptr
  %ld8379 = load i64, ptr %p8378, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8379, ptr %slot1517, align 8
  %v8380 = load i64, ptr %slot1517, align 8
  %v8381 = load i64, ptr %slot1516, align 8
  %cmp8382 = icmp eq i64 %v8380, %v8381
  %cv8383 = zext i1 %cmp8382 to i64
  store i64 %cv8383, ptr %slot1518, align 8
  %v8384 = load i64, ptr %slot1518, align 8
  %cond8385 = icmp ne i64 %v8384, 0
  br i1 %cond8385, label %bb_success1957, label %bb_failed1957
bb_failed1957:
  %v8386 = load i64, ptr %slot1, align 8
  %p8387 = inttoptr i64 %v8386 to ptr
  call void @myl_qbe_fail_iteration(ptr %p8387) nomerge, !dbg !218
  unreachable
bb_success1957:
  %v8388 = load i64, ptr %slot58, align 8
  %p8389 = inttoptr i64 %v8388 to ptr
  store i64 0, ptr %p8389, align 8, !alias.scope !3, !noalias !4
  %v8390 = load i64, ptr %slot54, align 8
  %p8391 = inttoptr i64 %v8390 to ptr
  %ld8392 = load i64, ptr %p8391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8392, ptr %slot1519, align 8
  %v8393 = load i64, ptr %slot1519, align 8
  %v8394 = load i64, ptr %slot58, align 8
  %p8395 = inttoptr i64 %v8394 to ptr
  store i64 %v8393, ptr %p8395, align 8, !alias.scope !3, !noalias !4
  %v8396 = load i64, ptr %slot53, align 8
  %p8397 = inttoptr i64 %v8396 to ptr
  %ld8398 = load i64, ptr %p8397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8398, ptr %slot1520, align 8
  %v8399 = load i64, ptr %slot58, align 8
  %p8400 = inttoptr i64 %v8399 to ptr
  %ld8401 = load i64, ptr %p8400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8401, ptr %slot1521, align 8
  %v8402 = load i64, ptr %slot1520, align 8
  %p8403 = inttoptr i64 %v8402 to ptr
  %ld8404 = load i64, ptr %p8403, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8404, ptr %slot1522, align 8
  %v8405 = load i64, ptr %slot1521, align 8
  %v8406 = load i64, ptr %slot1522, align 8
  %cmp8407 = icmp ult i64 %v8405, %v8406
  %cv8408 = zext i1 %cmp8407 to i64
  store i64 %cv8408, ptr %slot1523, align 8
  %v8409 = load i64, ptr %slot1523, align 8
  %cond8410 = icmp ne i64 %v8409, 0
  br i1 %cond8410, label %bb_success1964, label %bb_failed1964
bb_failed1964:
  %v8411 = load i64, ptr %slot1, align 8
  %p8412 = inttoptr i64 %v8411 to ptr
  %v8413 = load i64, ptr %slot1521, align 8
  %v8414 = load i64, ptr %slot1522, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p8412, i64 %v8413, i64 %v8414) nomerge, !dbg !220
  unreachable
bb_success1964:
  %v8415 = load i64, ptr %slot1520, align 8
  %op8416 = add i64 %v8415, 32
  store i64 %op8416, ptr %slot1524, align 8
  %v8417 = load i64, ptr %slot1524, align 8
  %p8418 = inttoptr i64 %v8417 to ptr
  %ld8419 = load i64, ptr %p8418, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8419, ptr %slot1525, align 8
  %v8420 = load i64, ptr %slot1521, align 8
  %op8421 = mul i64 %v8420, 16
  store i64 %op8421, ptr %slot1526, align 8
  %v8422 = load i64, ptr %slot1525, align 8
  %v8423 = load i64, ptr %slot1526, align 8
  %op8424 = add i64 %v8422, %v8423
  store i64 %op8424, ptr %slot1527, align 8
  %v8425 = load i64, ptr %slot1527, align 8
  %v8426 = load i64, ptr %slot58, align 8
  %p8427 = inttoptr i64 %v8426 to ptr
  store i64 %v8425, ptr %p8427, align 8, !alias.scope !3, !noalias !4
  %v8428 = load i64, ptr %slot58, align 8
  %p8429 = inttoptr i64 %v8428 to ptr
  %ld8430 = load i64, ptr %p8429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8430, ptr %slot1528, align 8
  %v8431 = load i64, ptr %slot1528, align 8
  %v8432 = load i64, ptr %slot56, align 8
  %p8433 = inttoptr i64 %v8431 to ptr
  %p8434 = inttoptr i64 %v8432 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8434, ptr %p8433, i64 16, i1 false), !alias.scope !10000001
  %v8435 = load i64, ptr %slot35, align 8
  %v8436 = load i64, ptr %slot58, align 8
  %p8437 = inttoptr i64 %v8436 to ptr
  store i64 %v8435, ptr %p8437, align 8, !alias.scope !3, !noalias !4
  %v8438 = load i64, ptr %slot56, align 8
  %v8439 = load i64, ptr %slot59, align 8
  %p8440 = inttoptr i64 %v8439 to ptr
  store i64 %v8438, ptr %p8440, align 8, !alias.scope !3, !noalias !4
  %v8441 = load i64, ptr %slot58, align 8
  %p8442 = inttoptr i64 %v8441 to ptr
  %ld8443 = load i64, ptr %p8442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8443, ptr %slot1529, align 8
  %v8444 = load i64, ptr %slot59, align 8
  %p8445 = inttoptr i64 %v8444 to ptr
  %ld8446 = load i64, ptr %p8445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8446, ptr %slot1530, align 8
  %v8447 = load i64, ptr %slot1, align 8
  %v8448 = load i64, ptr %slot1529, align 8
  %v8449 = load i64, ptr %slot1530, align 8
  %call8450 = call i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64 %v8447, i64 %v8448, i64 %v8449) nomerge, !dbg !222
  store i64 %call8450, ptr %slot1531, align 8
  %v8451 = load i64, ptr %slot1531, align 8
  %v8452 = load i64, ptr %slot58, align 8
  %p8453 = inttoptr i64 %v8452 to ptr
  store i64 %v8451, ptr %p8453, align 8, !alias.scope !3, !noalias !4
  %v8454 = load i64, ptr %slot23, align 8
  %p8455 = inttoptr i64 %v8454 to ptr
  %ld8456 = load i32, ptr %p8455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8456, ptr %slot1532, align 8
  %v8457 = load i32, ptr %slot1532, align 8
  %cv8458 = zext i32 %v8457 to i64
  %cond8459 = icmp ne i64 %cv8458, 0
  br i1 %cond8459, label %bb_rcslotdrop1975, label %bb_rcslotdone1975
bb_rcslotdrop1975:
  %v8460 = load i64, ptr %slot23, align 8
  %p8461 = inttoptr i64 %v8460 to ptr
  store i32 0, ptr %p8461, align 4, !alias.scope !3, !noalias !4
  %v8462 = load i64, ptr %slot29, align 8
  store i64 %v8462, ptr %slot1533, align 8
  %v8463 = load i64, ptr %slot24, align 8
  %p8464 = inttoptr i64 %v8463 to ptr
  %ld8465 = load i32, ptr %p8464, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8465, ptr %slot1534, align 8
  %v8466 = load i32, ptr %slot1534, align 8
  %op8467 = and i32 %v8466, 28
  store i32 %op8467, ptr %slot1535, align 8
  %v8468 = load i32, ptr %slot1535, align 8
  %cv8469 = zext i32 %v8468 to i64
  %cond8470 = icmp ne i64 %cv8469, 0
  br i1 %cond8470, label %bb_rcslotrole1975, label %bb_rcslotowner1975
bb_rcslotrole1975:
  %v8471 = load i64, ptr %slot65, align 8
  store i64 %v8471, ptr %slot1536, align 8
  %v8472 = load i64, ptr %slot1536, align 8
  %v8473 = load i64, ptr %slot1533, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v8472, i64 %v8473) nomerge, !dbg !222
  br label %bb_rcslotdone1975
bb_rcslotowner1975:
  %v8474 = load i64, ptr %slot65, align 8
  store i64 %v8474, ptr %slot1537, align 8
  %v8475 = load i64, ptr %slot1537, align 8
  %v8476 = load i64, ptr %slot1533, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v8475, i64 %v8476) nomerge, !dbg !222
  br label %bb_rcslotdone1975
bb_rcslotdone1975:
  %v8477 = load i64, ptr %slot55, align 8
  %p8478 = inttoptr i64 %v8477 to ptr
  %ld8479 = load i64, ptr %p8478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8479, ptr %slot1538, align 8
  %v8480 = load i64, ptr %slot1538, align 8
  %v8481 = load i64, ptr %slot58, align 8
  %p8482 = inttoptr i64 %v8481 to ptr
  store i64 %v8480, ptr %p8482, align 8, !alias.scope !3, !noalias !4
  %v8483 = load i64, ptr %slot53, align 8
  %p8484 = inttoptr i64 %v8483 to ptr
  %ld8485 = load i64, ptr %p8484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8485, ptr %slot1539, align 8
  %v8486 = load i64, ptr %slot58, align 8
  %p8487 = inttoptr i64 %v8486 to ptr
  %ld8488 = load i64, ptr %p8487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8488, ptr %slot1540, align 8
  %v8489 = load i64, ptr %slot1539, align 8
  %p8490 = inttoptr i64 %v8489 to ptr
  %ld8491 = load i64, ptr %p8490, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8491, ptr %slot1541, align 8
  %v8492 = load i64, ptr %slot1541, align 8
  %v8493 = load i64, ptr %slot1540, align 8
  %cmp8494 = icmp eq i64 %v8492, %v8493
  %cv8495 = zext i1 %cmp8494 to i64
  store i64 %cv8495, ptr %slot1542, align 8
  %v8496 = load i64, ptr %slot1542, align 8
  %cond8497 = icmp ne i64 %v8496, 0
  br i1 %cond8497, label %bb_success1987, label %bb_failed1987
bb_failed1987:
  %v8498 = load i64, ptr %slot1, align 8
  %p8499 = inttoptr i64 %v8498 to ptr
  call void @myl_qbe_fail_iteration(ptr %p8499) nomerge, !dbg !224
  unreachable
bb_success1987:
  %v8500 = load i64, ptr %slot58, align 8
  %p8501 = inttoptr i64 %v8500 to ptr
  store i64 0, ptr %p8501, align 8, !alias.scope !3, !noalias !4
  %v8502 = load i64, ptr %slot54, align 8
  %p8503 = inttoptr i64 %v8502 to ptr
  %ld8504 = load i64, ptr %p8503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8504, ptr %slot1543, align 8
  %v8505 = load i64, ptr %slot1543, align 8
  %v8506 = load i64, ptr %slot58, align 8
  %p8507 = inttoptr i64 %v8506 to ptr
  store i64 %v8505, ptr %p8507, align 8, !alias.scope !3, !noalias !4
  %v8508 = load i64, ptr %slot59, align 8
  %p8509 = inttoptr i64 %v8508 to ptr
  store i64 1, ptr %p8509, align 8, !alias.scope !3, !noalias !4
  %v8510 = load i64, ptr %slot59, align 8
  %p8511 = inttoptr i64 %v8510 to ptr
  %ld8512 = load i64, ptr %p8511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8512, ptr %slot1544, align 8
  %v8513 = load i64, ptr %slot58, align 8
  %p8514 = inttoptr i64 %v8513 to ptr
  %ld8515 = load i64, ptr %p8514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8515, ptr %slot1545, align 8
  %v8516 = load i64, ptr %slot1545, align 8
  %v8517 = load i64, ptr %slot1544, align 8
  %ovpair8519 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v8516, i64 %v8517)
  %op8518 = extractvalue { i64, i1 } %ovpair8519, 0
  %ov8520 = extractvalue { i64, i1 } %ovpair8519, 1
  store i64 %op8518, ptr %slot1546, align 8
  %cv8521 = zext i1 %ov8520 to i64
  store i64 %cv8521, ptr %slot1547, align 8
  %v8522 = load i64, ptr %slot1547, align 8
  %cond8523 = icmp ne i64 %v8522, 0
  br i1 %cond8523, label %bb_overflow1991, label %bb_checked1991
bb_overflow1991:
  %v8524 = load i64, ptr %slot1, align 8
  %p8525 = inttoptr i64 %v8524 to ptr
  %v8526 = load i64, ptr %slot1545, align 8
  %v8527 = load i64, ptr %slot1544, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p8525, i64 0, i64 %v8526, i64 %v8527, i64 64) nomerge, !dbg !226
  unreachable
bb_checked1991:
  %v8528 = load i64, ptr %slot1546, align 8
  %v8529 = load i64, ptr %slot58, align 8
  %p8530 = inttoptr i64 %v8529 to ptr
  store i64 %v8528, ptr %p8530, align 8, !alias.scope !3, !noalias !4
  %v8531 = load i64, ptr %slot58, align 8
  %p8532 = inttoptr i64 %v8531 to ptr
  %ld8533 = load i64, ptr %p8532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8533, ptr %slot1548, align 8
  %v8534 = load i64, ptr %slot1548, align 8
  %v8535 = load i64, ptr %slot54, align 8
  %p8536 = inttoptr i64 %v8535 to ptr
  store i64 %v8534, ptr %p8536, align 8, !alias.scope !3, !noalias !4
  br label %bb_i165
bb_i187:
  %v8537 = load i64, ptr %slot19, align 8
  %p8538 = inttoptr i64 %v8537 to ptr
  %ld8539 = load i32, ptr %p8538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8539, ptr %slot1549, align 8
  %v8540 = load i32, ptr %slot1549, align 8
  %cv8541 = zext i32 %v8540 to i64
  %cond8542 = icmp ne i64 %cv8541, 0
  br i1 %cond8542, label %bb_rcslotdrop1996, label %bb_rcslotdone1996
bb_rcslotdrop1996:
  %v8543 = load i64, ptr %slot19, align 8
  %p8544 = inttoptr i64 %v8543 to ptr
  store i32 0, ptr %p8544, align 4, !alias.scope !3, !noalias !4
  %v8545 = load i64, ptr %slot52, align 8
  store i64 %v8545, ptr %slot1550, align 8
  %v8546 = load i64, ptr %slot20, align 8
  %p8547 = inttoptr i64 %v8546 to ptr
  %ld8548 = load i32, ptr %p8547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8548, ptr %slot1551, align 8
  %v8549 = load i32, ptr %slot1551, align 8
  %op8550 = and i32 %v8549, 28
  store i32 %op8550, ptr %slot1552, align 8
  %v8551 = load i32, ptr %slot1552, align 8
  %cv8552 = zext i32 %v8551 to i64
  %cond8553 = icmp ne i64 %cv8552, 0
  br i1 %cond8553, label %bb_rcslotrole1996, label %bb_rcslotowner1996
bb_rcslotrole1996:
  %v8554 = load i64, ptr %slot65, align 8
  store i64 %v8554, ptr %slot1553, align 8
  %v8555 = load i64, ptr %slot1553, align 8
  %v8556 = load i64, ptr %slot1550, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v8555, i64 %v8556) nomerge, !dbg !228
  br label %bb_rcslotdone1996
bb_rcslotowner1996:
  %v8557 = load i64, ptr %slot1550, align 8
  %p8559 = inttoptr i64 %v8557 to ptr
  %gep8560 = getelementptr i8, ptr %p8559, i64 8
  %op8558 = ptrtoint ptr %gep8560 to i64
  store i64 %op8558, ptr %slot1554, align 8
  %v8561 = load i64, ptr %slot65, align 8
  store i64 %v8561, ptr %slot1555, align 8
  %v8562 = load i64, ptr %slot1554, align 8
  %p8563 = inttoptr i64 %v8562 to ptr
  %ld8564 = load i64, ptr %p8563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8564, ptr %slot1556, align 8
  %v8565 = load i64, ptr %slot1556, align 8
  %cmp8566 = icmp ne i64 %v8565, 0
  %cv8567 = zext i1 %cmp8566 to i32
  store i32 %cv8567, ptr %slot1557, align 8
  %v8568 = load i32, ptr %slot1557, align 8
  %cv8569 = zext i32 %v8568 to i64
  %cond8570 = icmp ne i64 %cv8569, 0
  br i1 %cond8570, label %bb_rcgnn2014, label %bb_rcgdone2014
bb_rcgnn2014:
  %v8571 = load i64, ptr %slot1556, align 8
  %op8572 = sub i64 %v8571, 16
  store i64 %op8572, ptr %slot1558, align 8
  %v8573 = load i64, ptr %slot1556, align 8
  %p8574 = inttoptr i64 %v8573 to ptr
  %rgep8575 = getelementptr i8, ptr %p8574, i64 -16
  %ld8576 = load i64, ptr %rgep8575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8576, ptr %slot1559, align 8
  %v8577 = load i64, ptr %slot1559, align 8
  %op8578 = and i64 %v8577, 4611686018427387906
  store i64 %op8578, ptr %slot1560, align 8
  %v8579 = load i64, ptr %slot1560, align 8
  %cmp8580 = icmp ne i64 %v8579, 0
  %cv8581 = zext i1 %cmp8580 to i32
  store i32 %cv8581, ptr %slot1561, align 8
  %v8582 = load i32, ptr %slot1561, align 8
  %cv8583 = zext i32 %v8582 to i64
  %cond8584 = icmp ne i64 %cv8583, 0
  br i1 %cond8584, label %bb_rcgclear2014, label %bb_rcgcounted2014
bb_rcgcounted2014:
  %v8585 = load i64, ptr %slot1556, align 8
  %op8586 = sub i64 %v8585, 32
  store i64 %op8586, ptr %slot1562, align 8
  %v8587 = load i64, ptr %slot1556, align 8
  %p8588 = inttoptr i64 %v8587 to ptr
  %rgep8589 = getelementptr i8, ptr %p8588, i64 -32
  %ld8590 = load i64, ptr %rgep8589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8590, ptr %slot1563, align 8
  %v8591 = load i64, ptr %slot1563, align 8
  %op8592 = sub i64 %v8591, 1
  store i64 %op8592, ptr %slot1564, align 8
  %v8593 = load i64, ptr %slot1564, align 8
  %cmp8594 = icmp eq i64 %v8593, 0
  %cv8595 = zext i1 %cmp8594 to i32
  store i32 %cv8595, ptr %slot1565, align 8
  %v8596 = load i32, ptr %slot1565, align 8
  %cv8597 = zext i32 %v8596 to i64
  %cond8598 = icmp ne i64 %cv8597, 0
  br i1 %cond8598, label %bb_rcglast2014, label %bb_rcgdec2014
bb_rcglast2014:
  %v8599 = load i64, ptr %slot1556, align 8
  %op8600 = sub i64 %v8599, 24
  store i64 %op8600, ptr %slot1566, align 8
  %v8601 = load i64, ptr %slot1556, align 8
  %p8602 = inttoptr i64 %v8601 to ptr
  %rgep8603 = getelementptr i8, ptr %p8602, i64 -24
  %ld8604 = load i64, ptr %rgep8603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8604, ptr %slot1567, align 8
  %v8605 = load i64, ptr %slot1567, align 8
  %cmp8606 = icmp ne i64 %v8605, 0
  %cv8607 = zext i1 %cmp8606 to i32
  store i32 %cv8607, ptr %slot1568, align 8
  %v8608 = load i32, ptr %slot1568, align 8
  %cv8609 = zext i32 %v8608 to i64
  %cond8610 = icmp ne i64 %cv8609, 0
  br i1 %cond8610, label %bb_rcgdec2014, label %bb_rcgslow2014
bb_rcgslow2014:
  %v8611 = load i64, ptr %slot1555, align 8
  %v8612 = load i64, ptr %slot1554, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v8611, i64 %v8612) nomerge, !dbg !228
  br label %bb_rcgdone2014
bb_rcgdec2014:
  %v8613 = load i64, ptr %slot1564, align 8
  %v8614 = load i64, ptr %slot1556, align 8
  %p8615 = inttoptr i64 %v8614 to ptr
  %rgep8616 = getelementptr i8, ptr %p8615, i64 -32
  store i64 %v8613, ptr %rgep8616, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2014
bb_rcgclear2014:
  %v8617 = load i64, ptr %slot1554, align 8
  %p8618 = inttoptr i64 %v8617 to ptr
  store i64 0, ptr %p8618, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2014
bb_rcgdone2014:
  %v8619 = load i64, ptr %slot1550, align 8
  %p8620 = inttoptr i64 %v8619 to ptr
  store i64 0, ptr %p8620, align 8, !alias.scope !3, !noalias !4
  %v8621 = load i64, ptr %slot1550, align 8
  %p8623 = inttoptr i64 %v8621 to ptr
  %gep8624 = getelementptr i8, ptr %p8623, i64 8
  %op8622 = ptrtoint ptr %gep8624 to i64
  store i64 %op8622, ptr %slot1569, align 8
  %v8625 = load i64, ptr %slot1569, align 8
  %p8626 = inttoptr i64 %v8625 to ptr
  store i64 0, ptr %p8626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1996
bb_rcslotdone1996:
  br label %bb_i198
bb_i189:
  %v8627 = load i64, ptr %slot35, align 8
  %v8628 = load i64, ptr %slot58, align 8
  %p8629 = inttoptr i64 %v8628 to ptr
  store i64 %v8627, ptr %p8629, align 8, !alias.scope !3, !noalias !4
  %v8630 = load i64, ptr %slot57, align 8
  %v8631 = load i64, ptr %slot59, align 8
  %p8632 = inttoptr i64 %v8631 to ptr
  store i64 %v8630, ptr %p8632, align 8, !alias.scope !3, !noalias !4
  %v8633 = load i64, ptr %slot59, align 8
  %p8634 = inttoptr i64 %v8633 to ptr
  %ld8635 = load i64, ptr %p8634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8635, ptr %slot1570, align 8
  %v8636 = load i64, ptr %slot1570, align 8
  %op8637 = add i64 %v8636, 16
  store i64 %op8637, ptr %slot1571, align 8
  %v8638 = load i64, ptr %slot1571, align 8
  %p8639 = inttoptr i64 %v8638 to ptr
  %ld8640 = load i64, ptr %p8639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8640, ptr %slot1572, align 8
  %v8641 = load i64, ptr %slot1572, align 8
  %v8642 = load i64, ptr %slot59, align 8
  %p8643 = inttoptr i64 %v8642 to ptr
  store i64 %v8641, ptr %p8643, align 8, !alias.scope !3, !noalias !4
  %v8644 = load i64, ptr %slot58, align 8
  %p8645 = inttoptr i64 %v8644 to ptr
  %ld8646 = load i64, ptr %p8645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8646, ptr %slot1573, align 8
  %v8647 = load i64, ptr %slot59, align 8
  %p8648 = inttoptr i64 %v8647 to ptr
  %ld8649 = load i64, ptr %p8648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8649, ptr %slot1574, align 8
  %v8650 = load i64, ptr %slot1, align 8
  %v8651 = load i64, ptr %slot1573, align 8
  %v8652 = load i64, ptr %slot1574, align 8
  %call8653 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v8650, i64 %v8651, i64 %v8652) nomerge, !dbg !230
  store i64 %call8653, ptr %slot1575, align 8
  %v8654 = load i64, ptr %slot1575, align 8
  %v8655 = load i64, ptr %slot58, align 8
  %p8656 = inttoptr i64 %v8655 to ptr
  store i64 %v8654, ptr %p8656, align 8, !alias.scope !3, !noalias !4
  %v8657 = load i64, ptr %slot23, align 8
  %p8658 = inttoptr i64 %v8657 to ptr
  %ld8659 = load i32, ptr %p8658, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8659, ptr %slot1576, align 8
  %v8660 = load i32, ptr %slot1576, align 8
  %cv8661 = zext i32 %v8660 to i64
  %cond8662 = icmp ne i64 %cv8661, 0
  br i1 %cond8662, label %bb_rcslotdrop2027, label %bb_rcslotdone2027
bb_rcslotdrop2027:
  %v8663 = load i64, ptr %slot23, align 8
  %p8664 = inttoptr i64 %v8663 to ptr
  store i32 0, ptr %p8664, align 4, !alias.scope !3, !noalias !4
  %v8665 = load i64, ptr %slot29, align 8
  store i64 %v8665, ptr %slot1577, align 8
  %v8666 = load i64, ptr %slot24, align 8
  %p8667 = inttoptr i64 %v8666 to ptr
  %ld8668 = load i32, ptr %p8667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8668, ptr %slot1578, align 8
  %v8669 = load i32, ptr %slot1578, align 8
  %op8670 = and i32 %v8669, 28
  store i32 %op8670, ptr %slot1579, align 8
  %v8671 = load i32, ptr %slot1579, align 8
  %cv8672 = zext i32 %v8671 to i64
  %cond8673 = icmp ne i64 %cv8672, 0
  br i1 %cond8673, label %bb_rcslotrole2027, label %bb_rcslotowner2027
bb_rcslotrole2027:
  %v8674 = load i64, ptr %slot65, align 8
  store i64 %v8674, ptr %slot1580, align 8
  %v8675 = load i64, ptr %slot1580, align 8
  %v8676 = load i64, ptr %slot1577, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v8675, i64 %v8676) nomerge, !dbg !230
  br label %bb_rcslotdone2027
bb_rcslotowner2027:
  %v8677 = load i64, ptr %slot65, align 8
  store i64 %v8677, ptr %slot1581, align 8
  %v8678 = load i64, ptr %slot1581, align 8
  %v8679 = load i64, ptr %slot1577, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v8678, i64 %v8679) nomerge, !dbg !230
  br label %bb_rcslotdone2027
bb_rcslotdone2027:
  br label %bb_i198
bb_i195:
  br label %bb_i198
bb_i196:
  br label %bb_i198
bb_i197:
  br label %bb_i198
bb_i198:
  %v8680 = load i64, ptr %slot33, align 8
  %p8681 = inttoptr i64 %v8680 to ptr
  %ld8682 = load i64, ptr %p8681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8682, ptr %slot1582, align 8
  %v8683 = load i64, ptr %slot1582, align 8
  %op8684 = add i64 %v8683, 8
  store i64 %op8684, ptr %slot1583, align 8
  %v8685 = load i64, ptr %slot35, align 8
  store i64 %v8685, ptr %slot1584, align 8
  %v8686 = load i64, ptr %slot1584, align 8
  %v8687 = load i64, ptr %slot1583, align 8
  %p8688 = inttoptr i64 %v8686 to ptr
  %p8689 = inttoptr i64 %v8687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8689, ptr %p8688, i64 16, i1 false), !alias.scope !10000000
  %v8690 = load i64, ptr %slot1584, align 8
  %p8691 = inttoptr i64 %v8690 to ptr
  store i64 0, ptr %p8691, align 8, !alias.scope !3, !noalias !4
  %v8692 = load i64, ptr %slot1584, align 8
  %p8694 = inttoptr i64 %v8692 to ptr
  %gep8695 = getelementptr i8, ptr %p8694, i64 8
  %op8693 = ptrtoint ptr %gep8695 to i64
  store i64 %op8693, ptr %slot1585, align 8
  %v8696 = load i64, ptr %slot1585, align 8
  %p8697 = inttoptr i64 %v8696 to ptr
  store i64 0, ptr %p8697, align 8, !alias.scope !3, !noalias !4
  %v8698 = load i64, ptr %slot5, align 8
  %p8699 = inttoptr i64 %v8698 to ptr
  store i32 0, ptr %p8699, align 4, !alias.scope !3, !noalias !4
  %v8700 = load i64, ptr %slot58, align 8
  %p8701 = inttoptr i64 %v8700 to ptr
  store i64 0, ptr %p8701, align 8, !alias.scope !3, !noalias !4
  %v8702 = load i64, ptr %slot58, align 8
  %p8703 = inttoptr i64 %v8702 to ptr
  store i64 0, ptr %p8703, align 8, !alias.scope !3, !noalias !4
  %v8704 = load i64, ptr %slot58, align 8
  %p8705 = inttoptr i64 %v8704 to ptr
  %ld8706 = load i64, ptr %p8705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8706, ptr %slot1586, align 8
  %v8707 = load i64, ptr %slot23, align 8
  %p8708 = inttoptr i64 %v8707 to ptr
  %ld8709 = load i32, ptr %p8708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8709, ptr %slot1587, align 8
  %v8710 = load i32, ptr %slot1587, align 8
  %cv8711 = zext i32 %v8710 to i64
  %cond8712 = icmp ne i64 %cv8711, 0
  br i1 %cond8712, label %bb_rcslotdrop2042, label %bb_rcslotdone2042
bb_rcslotdrop2042:
  %v8713 = load i64, ptr %slot23, align 8
  %p8714 = inttoptr i64 %v8713 to ptr
  store i32 0, ptr %p8714, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2042
bb_rcslotdone2042:
  %v8715 = load i64, ptr %slot21, align 8
  %p8716 = inttoptr i64 %v8715 to ptr
  %ld8717 = load i32, ptr %p8716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8717, ptr %slot1588, align 8
  %v8718 = load i32, ptr %slot1588, align 8
  %cv8719 = zext i32 %v8718 to i64
  %cond8720 = icmp ne i64 %cv8719, 0
  br i1 %cond8720, label %bb_rcslotdrop2063, label %bb_rcslotdone2063
bb_rcslotdrop2063:
  %v8721 = load i64, ptr %slot21, align 8
  %p8722 = inttoptr i64 %v8721 to ptr
  store i32 0, ptr %p8722, align 4, !alias.scope !3, !noalias !4
  %v8723 = load i64, ptr %slot53, align 8
  store i64 %v8723, ptr %slot1589, align 8
  %v8724 = load i64, ptr %slot22, align 8
  %p8725 = inttoptr i64 %v8724 to ptr
  %ld8726 = load i32, ptr %p8725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8726, ptr %slot1590, align 8
  %v8727 = load i32, ptr %slot1590, align 8
  %op8728 = and i32 %v8727, 28
  store i32 %op8728, ptr %slot1591, align 8
  %v8729 = load i32, ptr %slot1591, align 8
  %cv8730 = zext i32 %v8729 to i64
  %cond8731 = icmp ne i64 %cv8730, 0
  br i1 %cond8731, label %bb_rcslotrole2063, label %bb_rcslotowner2063
bb_rcslotrole2063:
  %v8732 = load i64, ptr %slot65, align 8
  store i64 %v8732, ptr %slot1592, align 8
  %v8733 = load i64, ptr %slot1589, align 8
  %p8734 = inttoptr i64 %v8733 to ptr
  %ld8735 = load i64, ptr %p8734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8735, ptr %slot1593, align 8
  %v8736 = load i64, ptr %slot1593, align 8
  %cmp8737 = icmp ne i64 %v8736, 0
  %cv8738 = zext i1 %cmp8737 to i32
  store i32 %cv8738, ptr %slot1594, align 8
  %v8739 = load i32, ptr %slot1594, align 8
  %cv8740 = zext i32 %v8739 to i64
  %cond8741 = icmp ne i64 %cv8740, 0
  br i1 %cond8741, label %bb_rcgnn2079, label %bb_rcgdone2079
bb_rcgnn2079:
  %v8742 = load i64, ptr %slot1593, align 8
  %op8743 = sub i64 %v8742, 16
  store i64 %op8743, ptr %slot1595, align 8
  %v8744 = load i64, ptr %slot1593, align 8
  %p8745 = inttoptr i64 %v8744 to ptr
  %rgep8746 = getelementptr i8, ptr %p8745, i64 -16
  %ld8747 = load i64, ptr %rgep8746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8747, ptr %slot1596, align 8
  %v8748 = load i64, ptr %slot1596, align 8
  %op8749 = and i64 %v8748, 4611686018427387906
  store i64 %op8749, ptr %slot1597, align 8
  %v8750 = load i64, ptr %slot1597, align 8
  %cmp8751 = icmp ne i64 %v8750, 0
  %cv8752 = zext i1 %cmp8751 to i32
  store i32 %cv8752, ptr %slot1598, align 8
  %v8753 = load i32, ptr %slot1598, align 8
  %cv8754 = zext i32 %v8753 to i64
  %cond8755 = icmp ne i64 %cv8754, 0
  br i1 %cond8755, label %bb_rcgclear2079, label %bb_rcgcounted2079
bb_rcgcounted2079:
  %v8756 = load i64, ptr %slot1593, align 8
  %op8757 = sub i64 %v8756, 24
  store i64 %op8757, ptr %slot1599, align 8
  %v8758 = load i64, ptr %slot1593, align 8
  %p8759 = inttoptr i64 %v8758 to ptr
  %rgep8760 = getelementptr i8, ptr %p8759, i64 -24
  %ld8761 = load i64, ptr %rgep8760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8761, ptr %slot1600, align 8
  %v8762 = load i64, ptr %slot1600, align 8
  %op8763 = sub i64 %v8762, 1
  store i64 %op8763, ptr %slot1601, align 8
  %v8764 = load i64, ptr %slot1601, align 8
  %cmp8765 = icmp eq i64 %v8764, 0
  %cv8766 = zext i1 %cmp8765 to i32
  store i32 %cv8766, ptr %slot1602, align 8
  %v8767 = load i32, ptr %slot1602, align 8
  %cv8768 = zext i32 %v8767 to i64
  %cond8769 = icmp ne i64 %cv8768, 0
  br i1 %cond8769, label %bb_rcglast2079, label %bb_rcgdec2079
bb_rcglast2079:
  %v8770 = load i64, ptr %slot1593, align 8
  %op8771 = sub i64 %v8770, 32
  store i64 %op8771, ptr %slot1603, align 8
  %v8772 = load i64, ptr %slot1593, align 8
  %p8773 = inttoptr i64 %v8772 to ptr
  %rgep8774 = getelementptr i8, ptr %p8773, i64 -32
  %ld8775 = load i64, ptr %rgep8774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8775, ptr %slot1604, align 8
  %v8776 = load i64, ptr %slot1604, align 8
  %cmp8777 = icmp ne i64 %v8776, 0
  %cv8778 = zext i1 %cmp8777 to i32
  store i32 %cv8778, ptr %slot1605, align 8
  %v8779 = load i32, ptr %slot1605, align 8
  %cv8780 = zext i32 %v8779 to i64
  %cond8781 = icmp ne i64 %cv8780, 0
  br i1 %cond8781, label %bb_rcgdec2079, label %bb_rcgslow2079
bb_rcgslow2079:
  %v8782 = load i64, ptr %slot1592, align 8
  %v8783 = load i64, ptr %slot1589, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v8782, i64 %v8783) nomerge, !dbg !232
  br label %bb_rcgdone2079
bb_rcgdec2079:
  %v8784 = load i64, ptr %slot1601, align 8
  %v8785 = load i64, ptr %slot1593, align 8
  %p8786 = inttoptr i64 %v8785 to ptr
  %rgep8787 = getelementptr i8, ptr %p8786, i64 -24
  store i64 %v8784, ptr %rgep8787, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2079
bb_rcgclear2079:
  %v8788 = load i64, ptr %slot1589, align 8
  %p8789 = inttoptr i64 %v8788 to ptr
  store i64 0, ptr %p8789, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2079
bb_rcgdone2079:
  br label %bb_rcslotdone2063
bb_rcslotowner2063:
  %v8790 = load i64, ptr %slot65, align 8
  store i64 %v8790, ptr %slot1606, align 8
  %v8791 = load i64, ptr %slot1589, align 8
  %p8792 = inttoptr i64 %v8791 to ptr
  %ld8793 = load i64, ptr %p8792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8793, ptr %slot1607, align 8
  %v8794 = load i64, ptr %slot1607, align 8
  %cmp8795 = icmp ne i64 %v8794, 0
  %cv8796 = zext i1 %cmp8795 to i32
  store i32 %cv8796, ptr %slot1608, align 8
  %v8797 = load i32, ptr %slot1608, align 8
  %cv8798 = zext i32 %v8797 to i64
  %cond8799 = icmp ne i64 %cv8798, 0
  br i1 %cond8799, label %bb_rcgnn2094, label %bb_rcgdone2094
bb_rcgnn2094:
  %v8800 = load i64, ptr %slot1607, align 8
  %op8801 = sub i64 %v8800, 16
  store i64 %op8801, ptr %slot1609, align 8
  %v8802 = load i64, ptr %slot1607, align 8
  %p8803 = inttoptr i64 %v8802 to ptr
  %rgep8804 = getelementptr i8, ptr %p8803, i64 -16
  %ld8805 = load i64, ptr %rgep8804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8805, ptr %slot1610, align 8
  %v8806 = load i64, ptr %slot1610, align 8
  %op8807 = and i64 %v8806, 4611686018427387906
  store i64 %op8807, ptr %slot1611, align 8
  %v8808 = load i64, ptr %slot1611, align 8
  %cmp8809 = icmp ne i64 %v8808, 0
  %cv8810 = zext i1 %cmp8809 to i32
  store i32 %cv8810, ptr %slot1612, align 8
  %v8811 = load i32, ptr %slot1612, align 8
  %cv8812 = zext i32 %v8811 to i64
  %cond8813 = icmp ne i64 %cv8812, 0
  br i1 %cond8813, label %bb_rcgclear2094, label %bb_rcgcounted2094
bb_rcgcounted2094:
  %v8814 = load i64, ptr %slot1607, align 8
  %op8815 = sub i64 %v8814, 32
  store i64 %op8815, ptr %slot1613, align 8
  %v8816 = load i64, ptr %slot1607, align 8
  %p8817 = inttoptr i64 %v8816 to ptr
  %rgep8818 = getelementptr i8, ptr %p8817, i64 -32
  %ld8819 = load i64, ptr %rgep8818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8819, ptr %slot1614, align 8
  %v8820 = load i64, ptr %slot1614, align 8
  %op8821 = sub i64 %v8820, 1
  store i64 %op8821, ptr %slot1615, align 8
  %v8822 = load i64, ptr %slot1615, align 8
  %cmp8823 = icmp eq i64 %v8822, 0
  %cv8824 = zext i1 %cmp8823 to i32
  store i32 %cv8824, ptr %slot1616, align 8
  %v8825 = load i32, ptr %slot1616, align 8
  %cv8826 = zext i32 %v8825 to i64
  %cond8827 = icmp ne i64 %cv8826, 0
  br i1 %cond8827, label %bb_rcglast2094, label %bb_rcgdec2094
bb_rcglast2094:
  %v8828 = load i64, ptr %slot1607, align 8
  %op8829 = sub i64 %v8828, 24
  store i64 %op8829, ptr %slot1617, align 8
  %v8830 = load i64, ptr %slot1607, align 8
  %p8831 = inttoptr i64 %v8830 to ptr
  %rgep8832 = getelementptr i8, ptr %p8831, i64 -24
  %ld8833 = load i64, ptr %rgep8832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8833, ptr %slot1618, align 8
  %v8834 = load i64, ptr %slot1618, align 8
  %cmp8835 = icmp ne i64 %v8834, 0
  %cv8836 = zext i1 %cmp8835 to i32
  store i32 %cv8836, ptr %slot1619, align 8
  %v8837 = load i32, ptr %slot1619, align 8
  %cv8838 = zext i32 %v8837 to i64
  %cond8839 = icmp ne i64 %cv8838, 0
  br i1 %cond8839, label %bb_rcgdec2094, label %bb_rcgslow2094
bb_rcgslow2094:
  %v8840 = load i64, ptr %slot1606, align 8
  %v8841 = load i64, ptr %slot1589, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v8840, i64 %v8841) nomerge, !dbg !232
  br label %bb_rcgdone2094
bb_rcgdec2094:
  %v8842 = load i64, ptr %slot1615, align 8
  %v8843 = load i64, ptr %slot1607, align 8
  %p8844 = inttoptr i64 %v8843 to ptr
  %rgep8845 = getelementptr i8, ptr %p8844, i64 -32
  store i64 %v8842, ptr %rgep8845, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2094
bb_rcgclear2094:
  %v8846 = load i64, ptr %slot1589, align 8
  %p8847 = inttoptr i64 %v8846 to ptr
  store i64 0, ptr %p8847, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2094
bb_rcgdone2094:
  br label %bb_rcslotdone2063
bb_rcslotdone2063:
  %v8848 = load i64, ptr %slot19, align 8
  %p8849 = inttoptr i64 %v8848 to ptr
  %ld8850 = load i32, ptr %p8849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8850, ptr %slot1620, align 8
  %v8851 = load i32, ptr %slot1620, align 8
  %cv8852 = zext i32 %v8851 to i64
  %cond8853 = icmp ne i64 %cv8852, 0
  br i1 %cond8853, label %bb_rcslotdrop2100, label %bb_rcslotdone2100
bb_rcslotdrop2100:
  %v8854 = load i64, ptr %slot19, align 8
  %p8855 = inttoptr i64 %v8854 to ptr
  store i32 0, ptr %p8855, align 4, !alias.scope !3, !noalias !4
  %v8856 = load i64, ptr %slot52, align 8
  store i64 %v8856, ptr %slot1621, align 8
  %v8857 = load i64, ptr %slot20, align 8
  %p8858 = inttoptr i64 %v8857 to ptr
  %ld8859 = load i32, ptr %p8858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8859, ptr %slot1622, align 8
  %v8860 = load i32, ptr %slot1622, align 8
  %op8861 = and i32 %v8860, 28
  store i32 %op8861, ptr %slot1623, align 8
  %v8862 = load i32, ptr %slot1623, align 8
  %cv8863 = zext i32 %v8862 to i64
  %cond8864 = icmp ne i64 %cv8863, 0
  br i1 %cond8864, label %bb_rcslotrole2100, label %bb_rcslotowner2100
bb_rcslotrole2100:
  %v8865 = load i64, ptr %slot65, align 8
  store i64 %v8865, ptr %slot1624, align 8
  %v8866 = load i64, ptr %slot1624, align 8
  %v8867 = load i64, ptr %slot1621, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v8866, i64 %v8867) nomerge, !dbg !232
  br label %bb_rcslotdone2100
bb_rcslotowner2100:
  %v8868 = load i64, ptr %slot65, align 8
  store i64 %v8868, ptr %slot1625, align 8
  %v8869 = load i64, ptr %slot1625, align 8
  %v8870 = load i64, ptr %slot1621, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v8869, i64 %v8870) nomerge, !dbg !232
  br label %bb_rcslotdone2100
bb_rcslotdone2100:
  %v8871 = load i64, ptr %slot17, align 8
  %p8872 = inttoptr i64 %v8871 to ptr
  %ld8873 = load i32, ptr %p8872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8873, ptr %slot1626, align 8
  %v8874 = load i32, ptr %slot1626, align 8
  %cv8875 = zext i32 %v8874 to i64
  %cond8876 = icmp ne i64 %cv8875, 0
  br i1 %cond8876, label %bb_rcslotdrop2109, label %bb_rcslotdone2109
bb_rcslotdrop2109:
  %v8877 = load i64, ptr %slot17, align 8
  %p8878 = inttoptr i64 %v8877 to ptr
  store i32 0, ptr %p8878, align 4, !alias.scope !3, !noalias !4
  %v8879 = load i64, ptr %slot46, align 8
  store i64 %v8879, ptr %slot1627, align 8
  %v8880 = load i64, ptr %slot18, align 8
  %p8881 = inttoptr i64 %v8880 to ptr
  %ld8882 = load i32, ptr %p8881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8882, ptr %slot1628, align 8
  %v8883 = load i32, ptr %slot1628, align 8
  %op8884 = and i32 %v8883, 28
  store i32 %op8884, ptr %slot1629, align 8
  %v8885 = load i32, ptr %slot1629, align 8
  %cv8886 = zext i32 %v8885 to i64
  %cond8887 = icmp ne i64 %cv8886, 0
  br i1 %cond8887, label %bb_rcslotrole2109, label %bb_rcslotowner2109
bb_rcslotrole2109:
  %v8888 = load i64, ptr %slot65, align 8
  store i64 %v8888, ptr %slot1630, align 8
  %v8889 = load i64, ptr %slot1627, align 8
  %p8890 = inttoptr i64 %v8889 to ptr
  %ld8891 = load i64, ptr %p8890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8891, ptr %slot1631, align 8
  %v8892 = load i64, ptr %slot1631, align 8
  %cmp8893 = icmp ne i64 %v8892, 0
  %cv8894 = zext i1 %cmp8893 to i32
  store i32 %cv8894, ptr %slot1632, align 8
  %v8895 = load i32, ptr %slot1632, align 8
  %cv8896 = zext i32 %v8895 to i64
  %cond8897 = icmp ne i64 %cv8896, 0
  br i1 %cond8897, label %bb_rcgnn2125, label %bb_rcgdone2125
bb_rcgnn2125:
  %v8898 = load i64, ptr %slot1631, align 8
  %op8899 = sub i64 %v8898, 16
  store i64 %op8899, ptr %slot1633, align 8
  %v8900 = load i64, ptr %slot1631, align 8
  %p8901 = inttoptr i64 %v8900 to ptr
  %rgep8902 = getelementptr i8, ptr %p8901, i64 -16
  %ld8903 = load i64, ptr %rgep8902, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8903, ptr %slot1634, align 8
  %v8904 = load i64, ptr %slot1634, align 8
  %op8905 = and i64 %v8904, 4611686018427387906
  store i64 %op8905, ptr %slot1635, align 8
  %v8906 = load i64, ptr %slot1635, align 8
  %cmp8907 = icmp ne i64 %v8906, 0
  %cv8908 = zext i1 %cmp8907 to i32
  store i32 %cv8908, ptr %slot1636, align 8
  %v8909 = load i32, ptr %slot1636, align 8
  %cv8910 = zext i32 %v8909 to i64
  %cond8911 = icmp ne i64 %cv8910, 0
  br i1 %cond8911, label %bb_rcgclear2125, label %bb_rcgcounted2125
bb_rcgcounted2125:
  %v8912 = load i64, ptr %slot1631, align 8
  %op8913 = sub i64 %v8912, 24
  store i64 %op8913, ptr %slot1637, align 8
  %v8914 = load i64, ptr %slot1631, align 8
  %p8915 = inttoptr i64 %v8914 to ptr
  %rgep8916 = getelementptr i8, ptr %p8915, i64 -24
  %ld8917 = load i64, ptr %rgep8916, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8917, ptr %slot1638, align 8
  %v8918 = load i64, ptr %slot1638, align 8
  %op8919 = sub i64 %v8918, 1
  store i64 %op8919, ptr %slot1639, align 8
  %v8920 = load i64, ptr %slot1639, align 8
  %cmp8921 = icmp eq i64 %v8920, 0
  %cv8922 = zext i1 %cmp8921 to i32
  store i32 %cv8922, ptr %slot1640, align 8
  %v8923 = load i32, ptr %slot1640, align 8
  %cv8924 = zext i32 %v8923 to i64
  %cond8925 = icmp ne i64 %cv8924, 0
  br i1 %cond8925, label %bb_rcglast2125, label %bb_rcgdec2125
bb_rcglast2125:
  %v8926 = load i64, ptr %slot1631, align 8
  %op8927 = sub i64 %v8926, 32
  store i64 %op8927, ptr %slot1641, align 8
  %v8928 = load i64, ptr %slot1631, align 8
  %p8929 = inttoptr i64 %v8928 to ptr
  %rgep8930 = getelementptr i8, ptr %p8929, i64 -32
  %ld8931 = load i64, ptr %rgep8930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8931, ptr %slot1642, align 8
  %v8932 = load i64, ptr %slot1642, align 8
  %cmp8933 = icmp ne i64 %v8932, 0
  %cv8934 = zext i1 %cmp8933 to i32
  store i32 %cv8934, ptr %slot1643, align 8
  %v8935 = load i32, ptr %slot1643, align 8
  %cv8936 = zext i32 %v8935 to i64
  %cond8937 = icmp ne i64 %cv8936, 0
  br i1 %cond8937, label %bb_rcgdec2125, label %bb_rcgslow2125
bb_rcgslow2125:
  %v8938 = load i64, ptr %slot1630, align 8
  %v8939 = load i64, ptr %slot1627, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v8938, i64 %v8939) nomerge, !dbg !232
  br label %bb_rcgdone2125
bb_rcgdec2125:
  %v8940 = load i64, ptr %slot1639, align 8
  %v8941 = load i64, ptr %slot1631, align 8
  %p8942 = inttoptr i64 %v8941 to ptr
  %rgep8943 = getelementptr i8, ptr %p8942, i64 -24
  store i64 %v8940, ptr %rgep8943, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2125
bb_rcgclear2125:
  %v8944 = load i64, ptr %slot1627, align 8
  %p8945 = inttoptr i64 %v8944 to ptr
  store i64 0, ptr %p8945, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2125
bb_rcgdone2125:
  br label %bb_rcslotdone2109
bb_rcslotowner2109:
  %v8946 = load i64, ptr %slot65, align 8
  store i64 %v8946, ptr %slot1644, align 8
  %v8947 = load i64, ptr %slot1627, align 8
  %p8948 = inttoptr i64 %v8947 to ptr
  %ld8949 = load i64, ptr %p8948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8949, ptr %slot1645, align 8
  %v8950 = load i64, ptr %slot1645, align 8
  %cmp8951 = icmp ne i64 %v8950, 0
  %cv8952 = zext i1 %cmp8951 to i32
  store i32 %cv8952, ptr %slot1646, align 8
  %v8953 = load i32, ptr %slot1646, align 8
  %cv8954 = zext i32 %v8953 to i64
  %cond8955 = icmp ne i64 %cv8954, 0
  br i1 %cond8955, label %bb_rcgnn2140, label %bb_rcgdone2140
bb_rcgnn2140:
  %v8956 = load i64, ptr %slot1645, align 8
  %op8957 = sub i64 %v8956, 16
  store i64 %op8957, ptr %slot1647, align 8
  %v8958 = load i64, ptr %slot1645, align 8
  %p8959 = inttoptr i64 %v8958 to ptr
  %rgep8960 = getelementptr i8, ptr %p8959, i64 -16
  %ld8961 = load i64, ptr %rgep8960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8961, ptr %slot1648, align 8
  %v8962 = load i64, ptr %slot1648, align 8
  %op8963 = and i64 %v8962, 4611686018427387906
  store i64 %op8963, ptr %slot1649, align 8
  %v8964 = load i64, ptr %slot1649, align 8
  %cmp8965 = icmp ne i64 %v8964, 0
  %cv8966 = zext i1 %cmp8965 to i32
  store i32 %cv8966, ptr %slot1650, align 8
  %v8967 = load i32, ptr %slot1650, align 8
  %cv8968 = zext i32 %v8967 to i64
  %cond8969 = icmp ne i64 %cv8968, 0
  br i1 %cond8969, label %bb_rcgclear2140, label %bb_rcgcounted2140
bb_rcgcounted2140:
  %v8970 = load i64, ptr %slot1645, align 8
  %op8971 = sub i64 %v8970, 32
  store i64 %op8971, ptr %slot1651, align 8
  %v8972 = load i64, ptr %slot1645, align 8
  %p8973 = inttoptr i64 %v8972 to ptr
  %rgep8974 = getelementptr i8, ptr %p8973, i64 -32
  %ld8975 = load i64, ptr %rgep8974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8975, ptr %slot1652, align 8
  %v8976 = load i64, ptr %slot1652, align 8
  %op8977 = sub i64 %v8976, 1
  store i64 %op8977, ptr %slot1653, align 8
  %v8978 = load i64, ptr %slot1653, align 8
  %cmp8979 = icmp eq i64 %v8978, 0
  %cv8980 = zext i1 %cmp8979 to i32
  store i32 %cv8980, ptr %slot1654, align 8
  %v8981 = load i32, ptr %slot1654, align 8
  %cv8982 = zext i32 %v8981 to i64
  %cond8983 = icmp ne i64 %cv8982, 0
  br i1 %cond8983, label %bb_rcglast2140, label %bb_rcgdec2140
bb_rcglast2140:
  %v8984 = load i64, ptr %slot1645, align 8
  %op8985 = sub i64 %v8984, 24
  store i64 %op8985, ptr %slot1655, align 8
  %v8986 = load i64, ptr %slot1645, align 8
  %p8987 = inttoptr i64 %v8986 to ptr
  %rgep8988 = getelementptr i8, ptr %p8987, i64 -24
  %ld8989 = load i64, ptr %rgep8988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8989, ptr %slot1656, align 8
  %v8990 = load i64, ptr %slot1656, align 8
  %cmp8991 = icmp ne i64 %v8990, 0
  %cv8992 = zext i1 %cmp8991 to i32
  store i32 %cv8992, ptr %slot1657, align 8
  %v8993 = load i32, ptr %slot1657, align 8
  %cv8994 = zext i32 %v8993 to i64
  %cond8995 = icmp ne i64 %cv8994, 0
  br i1 %cond8995, label %bb_rcgdec2140, label %bb_rcgslow2140
bb_rcgslow2140:
  %v8996 = load i64, ptr %slot1644, align 8
  %v8997 = load i64, ptr %slot1627, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v8996, i64 %v8997) nomerge, !dbg !232
  br label %bb_rcgdone2140
bb_rcgdec2140:
  %v8998 = load i64, ptr %slot1653, align 8
  %v8999 = load i64, ptr %slot1645, align 8
  %p9000 = inttoptr i64 %v8999 to ptr
  %rgep9001 = getelementptr i8, ptr %p9000, i64 -32
  store i64 %v8998, ptr %rgep9001, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2140
bb_rcgclear2140:
  %v9002 = load i64, ptr %slot1627, align 8
  %p9003 = inttoptr i64 %v9002 to ptr
  store i64 0, ptr %p9003, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2140
bb_rcgdone2140:
  br label %bb_rcslotdone2109
bb_rcslotdone2109:
  %v9004 = load i64, ptr %slot15, align 8
  %p9005 = inttoptr i64 %v9004 to ptr
  %ld9006 = load i32, ptr %p9005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9006, ptr %slot1658, align 8
  %v9007 = load i32, ptr %slot1658, align 8
  %cv9008 = zext i32 %v9007 to i64
  %cond9009 = icmp ne i64 %cv9008, 0
  br i1 %cond9009, label %bb_rcslotdrop2146, label %bb_rcslotdone2146
bb_rcslotdrop2146:
  %v9010 = load i64, ptr %slot15, align 8
  %p9011 = inttoptr i64 %v9010 to ptr
  store i32 0, ptr %p9011, align 4, !alias.scope !3, !noalias !4
  %v9012 = load i64, ptr %slot45, align 8
  store i64 %v9012, ptr %slot1659, align 8
  %v9013 = load i64, ptr %slot16, align 8
  %p9014 = inttoptr i64 %v9013 to ptr
  %ld9015 = load i32, ptr %p9014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9015, ptr %slot1660, align 8
  %v9016 = load i32, ptr %slot1660, align 8
  %op9017 = and i32 %v9016, 28
  store i32 %op9017, ptr %slot1661, align 8
  %v9018 = load i32, ptr %slot1661, align 8
  %cv9019 = zext i32 %v9018 to i64
  %cond9020 = icmp ne i64 %cv9019, 0
  br i1 %cond9020, label %bb_rcslotrole2146, label %bb_rcslotowner2146
bb_rcslotrole2146:
  %v9021 = load i64, ptr %slot65, align 8
  store i64 %v9021, ptr %slot1662, align 8
  %v9022 = load i64, ptr %slot1662, align 8
  %v9023 = load i64, ptr %slot1659, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v9022, i64 %v9023) nomerge, !dbg !232
  br label %bb_rcslotdone2146
bb_rcslotowner2146:
  %v9024 = load i64, ptr %slot65, align 8
  store i64 %v9024, ptr %slot1663, align 8
  %v9025 = load i64, ptr %slot1663, align 8
  %v9026 = load i64, ptr %slot1659, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v9025, i64 %v9026) nomerge, !dbg !232
  br label %bb_rcslotdone2146
bb_rcslotdone2146:
  %v9027 = load i64, ptr %slot13, align 8
  %p9028 = inttoptr i64 %v9027 to ptr
  %ld9029 = load i32, ptr %p9028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9029, ptr %slot1664, align 8
  %v9030 = load i32, ptr %slot1664, align 8
  %cv9031 = zext i32 %v9030 to i64
  %cond9032 = icmp ne i64 %cv9031, 0
  br i1 %cond9032, label %bb_rcslotdrop2155, label %bb_rcslotdone2155
bb_rcslotdrop2155:
  %v9033 = load i64, ptr %slot13, align 8
  %p9034 = inttoptr i64 %v9033 to ptr
  store i32 0, ptr %p9034, align 4, !alias.scope !3, !noalias !4
  %v9035 = load i64, ptr %slot41, align 8
  store i64 %v9035, ptr %slot1665, align 8
  %v9036 = load i64, ptr %slot14, align 8
  %p9037 = inttoptr i64 %v9036 to ptr
  %ld9038 = load i32, ptr %p9037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9038, ptr %slot1666, align 8
  %v9039 = load i32, ptr %slot1666, align 8
  %op9040 = and i32 %v9039, 28
  store i32 %op9040, ptr %slot1667, align 8
  %v9041 = load i32, ptr %slot1667, align 8
  %cv9042 = zext i32 %v9041 to i64
  %cond9043 = icmp ne i64 %cv9042, 0
  br i1 %cond9043, label %bb_rcslotrole2155, label %bb_rcslotowner2155
bb_rcslotrole2155:
  %v9044 = load i64, ptr %slot65, align 8
  store i64 %v9044, ptr %slot1668, align 8
  %v9045 = load i64, ptr %slot1665, align 8
  %p9046 = inttoptr i64 %v9045 to ptr
  %ld9047 = load i64, ptr %p9046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9047, ptr %slot1669, align 8
  %v9048 = load i64, ptr %slot1669, align 8
  %cmp9049 = icmp ne i64 %v9048, 0
  %cv9050 = zext i1 %cmp9049 to i32
  store i32 %cv9050, ptr %slot1670, align 8
  %v9051 = load i32, ptr %slot1670, align 8
  %cv9052 = zext i32 %v9051 to i64
  %cond9053 = icmp ne i64 %cv9052, 0
  br i1 %cond9053, label %bb_rcgnn2171, label %bb_rcgdone2171
bb_rcgnn2171:
  %v9054 = load i64, ptr %slot1669, align 8
  %op9055 = sub i64 %v9054, 16
  store i64 %op9055, ptr %slot1671, align 8
  %v9056 = load i64, ptr %slot1669, align 8
  %p9057 = inttoptr i64 %v9056 to ptr
  %rgep9058 = getelementptr i8, ptr %p9057, i64 -16
  %ld9059 = load i64, ptr %rgep9058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9059, ptr %slot1672, align 8
  %v9060 = load i64, ptr %slot1672, align 8
  %op9061 = and i64 %v9060, 4611686018427387906
  store i64 %op9061, ptr %slot1673, align 8
  %v9062 = load i64, ptr %slot1673, align 8
  %cmp9063 = icmp ne i64 %v9062, 0
  %cv9064 = zext i1 %cmp9063 to i32
  store i32 %cv9064, ptr %slot1674, align 8
  %v9065 = load i32, ptr %slot1674, align 8
  %cv9066 = zext i32 %v9065 to i64
  %cond9067 = icmp ne i64 %cv9066, 0
  br i1 %cond9067, label %bb_rcgclear2171, label %bb_rcgcounted2171
bb_rcgcounted2171:
  %v9068 = load i64, ptr %slot1669, align 8
  %op9069 = sub i64 %v9068, 24
  store i64 %op9069, ptr %slot1675, align 8
  %v9070 = load i64, ptr %slot1669, align 8
  %p9071 = inttoptr i64 %v9070 to ptr
  %rgep9072 = getelementptr i8, ptr %p9071, i64 -24
  %ld9073 = load i64, ptr %rgep9072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9073, ptr %slot1676, align 8
  %v9074 = load i64, ptr %slot1676, align 8
  %op9075 = sub i64 %v9074, 1
  store i64 %op9075, ptr %slot1677, align 8
  %v9076 = load i64, ptr %slot1677, align 8
  %cmp9077 = icmp eq i64 %v9076, 0
  %cv9078 = zext i1 %cmp9077 to i32
  store i32 %cv9078, ptr %slot1678, align 8
  %v9079 = load i32, ptr %slot1678, align 8
  %cv9080 = zext i32 %v9079 to i64
  %cond9081 = icmp ne i64 %cv9080, 0
  br i1 %cond9081, label %bb_rcglast2171, label %bb_rcgdec2171
bb_rcglast2171:
  %v9082 = load i64, ptr %slot1669, align 8
  %op9083 = sub i64 %v9082, 32
  store i64 %op9083, ptr %slot1679, align 8
  %v9084 = load i64, ptr %slot1669, align 8
  %p9085 = inttoptr i64 %v9084 to ptr
  %rgep9086 = getelementptr i8, ptr %p9085, i64 -32
  %ld9087 = load i64, ptr %rgep9086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9087, ptr %slot1680, align 8
  %v9088 = load i64, ptr %slot1680, align 8
  %cmp9089 = icmp ne i64 %v9088, 0
  %cv9090 = zext i1 %cmp9089 to i32
  store i32 %cv9090, ptr %slot1681, align 8
  %v9091 = load i32, ptr %slot1681, align 8
  %cv9092 = zext i32 %v9091 to i64
  %cond9093 = icmp ne i64 %cv9092, 0
  br i1 %cond9093, label %bb_rcgdec2171, label %bb_rcgslow2171
bb_rcgslow2171:
  %v9094 = load i64, ptr %slot1668, align 8
  %v9095 = load i64, ptr %slot1665, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v9094, i64 %v9095) nomerge, !dbg !232
  br label %bb_rcgdone2171
bb_rcgdec2171:
  %v9096 = load i64, ptr %slot1677, align 8
  %v9097 = load i64, ptr %slot1669, align 8
  %p9098 = inttoptr i64 %v9097 to ptr
  %rgep9099 = getelementptr i8, ptr %p9098, i64 -24
  store i64 %v9096, ptr %rgep9099, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2171
bb_rcgclear2171:
  %v9100 = load i64, ptr %slot1665, align 8
  %p9101 = inttoptr i64 %v9100 to ptr
  store i64 0, ptr %p9101, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2171
bb_rcgdone2171:
  br label %bb_rcslotdone2155
bb_rcslotowner2155:
  %v9102 = load i64, ptr %slot65, align 8
  store i64 %v9102, ptr %slot1682, align 8
  %v9103 = load i64, ptr %slot1665, align 8
  %p9104 = inttoptr i64 %v9103 to ptr
  %ld9105 = load i64, ptr %p9104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9105, ptr %slot1683, align 8
  %v9106 = load i64, ptr %slot1683, align 8
  %cmp9107 = icmp ne i64 %v9106, 0
  %cv9108 = zext i1 %cmp9107 to i32
  store i32 %cv9108, ptr %slot1684, align 8
  %v9109 = load i32, ptr %slot1684, align 8
  %cv9110 = zext i32 %v9109 to i64
  %cond9111 = icmp ne i64 %cv9110, 0
  br i1 %cond9111, label %bb_rcgnn2186, label %bb_rcgdone2186
bb_rcgnn2186:
  %v9112 = load i64, ptr %slot1683, align 8
  %op9113 = sub i64 %v9112, 16
  store i64 %op9113, ptr %slot1685, align 8
  %v9114 = load i64, ptr %slot1683, align 8
  %p9115 = inttoptr i64 %v9114 to ptr
  %rgep9116 = getelementptr i8, ptr %p9115, i64 -16
  %ld9117 = load i64, ptr %rgep9116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9117, ptr %slot1686, align 8
  %v9118 = load i64, ptr %slot1686, align 8
  %op9119 = and i64 %v9118, 4611686018427387906
  store i64 %op9119, ptr %slot1687, align 8
  %v9120 = load i64, ptr %slot1687, align 8
  %cmp9121 = icmp ne i64 %v9120, 0
  %cv9122 = zext i1 %cmp9121 to i32
  store i32 %cv9122, ptr %slot1688, align 8
  %v9123 = load i32, ptr %slot1688, align 8
  %cv9124 = zext i32 %v9123 to i64
  %cond9125 = icmp ne i64 %cv9124, 0
  br i1 %cond9125, label %bb_rcgclear2186, label %bb_rcgcounted2186
bb_rcgcounted2186:
  %v9126 = load i64, ptr %slot1683, align 8
  %op9127 = sub i64 %v9126, 32
  store i64 %op9127, ptr %slot1689, align 8
  %v9128 = load i64, ptr %slot1683, align 8
  %p9129 = inttoptr i64 %v9128 to ptr
  %rgep9130 = getelementptr i8, ptr %p9129, i64 -32
  %ld9131 = load i64, ptr %rgep9130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9131, ptr %slot1690, align 8
  %v9132 = load i64, ptr %slot1690, align 8
  %op9133 = sub i64 %v9132, 1
  store i64 %op9133, ptr %slot1691, align 8
  %v9134 = load i64, ptr %slot1691, align 8
  %cmp9135 = icmp eq i64 %v9134, 0
  %cv9136 = zext i1 %cmp9135 to i32
  store i32 %cv9136, ptr %slot1692, align 8
  %v9137 = load i32, ptr %slot1692, align 8
  %cv9138 = zext i32 %v9137 to i64
  %cond9139 = icmp ne i64 %cv9138, 0
  br i1 %cond9139, label %bb_rcglast2186, label %bb_rcgdec2186
bb_rcglast2186:
  %v9140 = load i64, ptr %slot1683, align 8
  %op9141 = sub i64 %v9140, 24
  store i64 %op9141, ptr %slot1693, align 8
  %v9142 = load i64, ptr %slot1683, align 8
  %p9143 = inttoptr i64 %v9142 to ptr
  %rgep9144 = getelementptr i8, ptr %p9143, i64 -24
  %ld9145 = load i64, ptr %rgep9144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9145, ptr %slot1694, align 8
  %v9146 = load i64, ptr %slot1694, align 8
  %cmp9147 = icmp ne i64 %v9146, 0
  %cv9148 = zext i1 %cmp9147 to i32
  store i32 %cv9148, ptr %slot1695, align 8
  %v9149 = load i32, ptr %slot1695, align 8
  %cv9150 = zext i32 %v9149 to i64
  %cond9151 = icmp ne i64 %cv9150, 0
  br i1 %cond9151, label %bb_rcgdec2186, label %bb_rcgslow2186
bb_rcgslow2186:
  %v9152 = load i64, ptr %slot1682, align 8
  %v9153 = load i64, ptr %slot1665, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v9152, i64 %v9153) nomerge, !dbg !232
  br label %bb_rcgdone2186
bb_rcgdec2186:
  %v9154 = load i64, ptr %slot1691, align 8
  %v9155 = load i64, ptr %slot1683, align 8
  %p9156 = inttoptr i64 %v9155 to ptr
  %rgep9157 = getelementptr i8, ptr %p9156, i64 -32
  store i64 %v9154, ptr %rgep9157, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2186
bb_rcgclear2186:
  %v9158 = load i64, ptr %slot1665, align 8
  %p9159 = inttoptr i64 %v9158 to ptr
  store i64 0, ptr %p9159, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2186
bb_rcgdone2186:
  br label %bb_rcslotdone2155
bb_rcslotdone2155:
  %v9160 = load i64, ptr %slot11, align 8
  %p9161 = inttoptr i64 %v9160 to ptr
  %ld9162 = load i32, ptr %p9161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9162, ptr %slot1696, align 8
  %v9163 = load i32, ptr %slot1696, align 8
  %cv9164 = zext i32 %v9163 to i64
  %cond9165 = icmp ne i64 %cv9164, 0
  br i1 %cond9165, label %bb_rcslotdrop2192, label %bb_rcslotdone2192
bb_rcslotdrop2192:
  %v9166 = load i64, ptr %slot11, align 8
  %p9167 = inttoptr i64 %v9166 to ptr
  store i32 0, ptr %p9167, align 4, !alias.scope !3, !noalias !4
  %v9168 = load i64, ptr %slot40, align 8
  store i64 %v9168, ptr %slot1697, align 8
  %v9169 = load i64, ptr %slot12, align 8
  %p9170 = inttoptr i64 %v9169 to ptr
  %ld9171 = load i32, ptr %p9170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9171, ptr %slot1698, align 8
  %v9172 = load i32, ptr %slot1698, align 8
  %op9173 = and i32 %v9172, 28
  store i32 %op9173, ptr %slot1699, align 8
  %v9174 = load i32, ptr %slot1699, align 8
  %cv9175 = zext i32 %v9174 to i64
  %cond9176 = icmp ne i64 %cv9175, 0
  br i1 %cond9176, label %bb_rcslotrole2192, label %bb_rcslotowner2192
bb_rcslotrole2192:
  %v9177 = load i64, ptr %slot65, align 8
  store i64 %v9177, ptr %slot1700, align 8
  %v9178 = load i64, ptr %slot1700, align 8
  %v9179 = load i64, ptr %slot1697, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v9178, i64 %v9179) nomerge, !dbg !232
  br label %bb_rcslotdone2192
bb_rcslotowner2192:
  %v9180 = load i64, ptr %slot65, align 8
  store i64 %v9180, ptr %slot1701, align 8
  %v9181 = load i64, ptr %slot1701, align 8
  %v9182 = load i64, ptr %slot1697, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v9181, i64 %v9182) nomerge, !dbg !232
  br label %bb_rcslotdone2192
bb_rcslotdone2192:
  %v9183 = load i64, ptr %slot9, align 8
  %p9184 = inttoptr i64 %v9183 to ptr
  %ld9185 = load i32, ptr %p9184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9185, ptr %slot1702, align 8
  %v9186 = load i32, ptr %slot1702, align 8
  %cv9187 = zext i32 %v9186 to i64
  %cond9188 = icmp ne i64 %cv9187, 0
  br i1 %cond9188, label %bb_rcslotdrop2201, label %bb_rcslotdone2201
bb_rcslotdrop2201:
  %v9189 = load i64, ptr %slot9, align 8
  %p9190 = inttoptr i64 %v9189 to ptr
  store i32 0, ptr %p9190, align 4, !alias.scope !3, !noalias !4
  %v9191 = load i64, ptr %slot39, align 8
  store i64 %v9191, ptr %slot1703, align 8
  %v9192 = load i64, ptr %slot10, align 8
  %p9193 = inttoptr i64 %v9192 to ptr
  %ld9194 = load i32, ptr %p9193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9194, ptr %slot1704, align 8
  %v9195 = load i32, ptr %slot1704, align 8
  %op9196 = and i32 %v9195, 28
  store i32 %op9196, ptr %slot1705, align 8
  %v9197 = load i32, ptr %slot1705, align 8
  %cv9198 = zext i32 %v9197 to i64
  %cond9199 = icmp ne i64 %cv9198, 0
  br i1 %cond9199, label %bb_rcslotrole2201, label %bb_rcslotowner2201
bb_rcslotrole2201:
  %v9200 = load i64, ptr %slot65, align 8
  store i64 %v9200, ptr %slot1706, align 8
  %v9201 = load i64, ptr %slot1706, align 8
  %v9202 = load i64, ptr %slot1703, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v9201, i64 %v9202) nomerge, !dbg !232
  br label %bb_rcslotdone2201
bb_rcslotowner2201:
  %v9203 = load i64, ptr %slot65, align 8
  store i64 %v9203, ptr %slot1707, align 8
  %v9204 = load i64, ptr %slot1707, align 8
  %v9205 = load i64, ptr %slot1703, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v9204, i64 %v9205) nomerge, !dbg !232
  br label %bb_rcslotdone2201
bb_rcslotdone2201:
  %v9206 = load i64, ptr %slot7, align 8
  %p9207 = inttoptr i64 %v9206 to ptr
  %ld9208 = load i32, ptr %p9207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9208, ptr %slot1708, align 8
  %v9209 = load i32, ptr %slot1708, align 8
  %cv9210 = zext i32 %v9209 to i64
  %cond9211 = icmp ne i64 %cv9210, 0
  br i1 %cond9211, label %bb_rcslotdrop2210, label %bb_rcslotdone2210
bb_rcslotdrop2210:
  %v9212 = load i64, ptr %slot7, align 8
  %p9213 = inttoptr i64 %v9212 to ptr
  store i32 0, ptr %p9213, align 4, !alias.scope !3, !noalias !4
  %v9214 = load i64, ptr %slot38, align 8
  store i64 %v9214, ptr %slot1709, align 8
  %v9215 = load i64, ptr %slot8, align 8
  %p9216 = inttoptr i64 %v9215 to ptr
  %ld9217 = load i32, ptr %p9216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9217, ptr %slot1710, align 8
  %v9218 = load i32, ptr %slot1710, align 8
  %op9219 = and i32 %v9218, 28
  store i32 %op9219, ptr %slot1711, align 8
  %v9220 = load i32, ptr %slot1711, align 8
  %cv9221 = zext i32 %v9220 to i64
  %cond9222 = icmp ne i64 %cv9221, 0
  br i1 %cond9222, label %bb_rcslotrole2210, label %bb_rcslotowner2210
bb_rcslotrole2210:
  %v9223 = load i64, ptr %slot65, align 8
  store i64 %v9223, ptr %slot1712, align 8
  %v9224 = load i64, ptr %slot1712, align 8
  %v9225 = load i64, ptr %slot1709, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v9224, i64 %v9225) nomerge, !dbg !232
  br label %bb_rcslotdone2210
bb_rcslotowner2210:
  %v9226 = load i64, ptr %slot65, align 8
  store i64 %v9226, ptr %slot1713, align 8
  %v9227 = load i64, ptr %slot1713, align 8
  %v9228 = load i64, ptr %slot1709, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v9227, i64 %v9228) nomerge, !dbg !232
  br label %bb_rcslotdone2210
bb_rcslotdone2210:
  %v9229 = load i64, ptr %slot5, align 8
  %p9230 = inttoptr i64 %v9229 to ptr
  %ld9231 = load i32, ptr %p9230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9231, ptr %slot1714, align 8
  %v9232 = load i32, ptr %slot1714, align 8
  %cv9233 = zext i32 %v9232 to i64
  %cond9234 = icmp ne i64 %cv9233, 0
  br i1 %cond9234, label %bb_rcslotdrop2256, label %bb_rcslotdone2256
bb_rcslotdrop2256:
  %v9235 = load i64, ptr %slot5, align 8
  %p9236 = inttoptr i64 %v9235 to ptr
  store i32 0, ptr %p9236, align 4, !alias.scope !3, !noalias !4
  %v9237 = load i64, ptr %slot35, align 8
  store i64 %v9237, ptr %slot1715, align 8
  %v9238 = load i64, ptr %slot6, align 8
  %p9239 = inttoptr i64 %v9238 to ptr
  %ld9240 = load i32, ptr %p9239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9240, ptr %slot1716, align 8
  %v9241 = load i32, ptr %slot1716, align 8
  %op9242 = and i32 %v9241, 28
  store i32 %op9242, ptr %slot1717, align 8
  %v9243 = load i32, ptr %slot1717, align 8
  %cv9244 = zext i32 %v9243 to i64
  %cond9245 = icmp ne i64 %cv9244, 0
  br i1 %cond9245, label %bb_rcslotrole2256, label %bb_rcslotowner2256
bb_rcslotrole2256:
  %v9246 = load i64, ptr %slot65, align 8
  store i64 %v9246, ptr %slot1718, align 8
  %v9247 = load i64, ptr %slot1718, align 8
  %v9248 = load i64, ptr %slot1715, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v9247, i64 %v9248) nomerge, !dbg !232
  br label %bb_rcslotdone2256
bb_rcslotowner2256:
  %v9249 = load i64, ptr %slot65, align 8
  store i64 %v9249, ptr %slot1719, align 8
  %v9250 = load i64, ptr %slot1719, align 8
  %v9251 = load i64, ptr %slot1715, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v9250, i64 %v9251) nomerge, !dbg !232
  br label %bb_rcslotdone2256
bb_rcslotdone2256:
  %v9252 = load i64, ptr %slot1586, align 8
  ret i64 %v9252
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64, i64, i64)
declare i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64, i64, i64)
declare i64 @myl_f_f0393a69ddd4c3d9aed35cdcfaedcd9f0376ae1fd953f70833a16f0c06c4cd97(i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64, i64)
declare void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64, i64)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64, i64, i64, i32)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64, i64)
declare i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64, i64, i64, i32)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11, !14}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11, !14}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5, !14}
!14 = distinct !{!14, !0, !"element 16v"}
!15 = !{!14}
!16 = !{!1, !5, !11}
!10000000 = !{!1, !2}
!10000001 = !{!1, !14}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_7eeea69e953c279b3bbaecf005ac3887ccc3b5b7f1eb3e19b41b82570231d761", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_7eeea69e953c279b3bbaecf005ac3887ccc3b5b7f1eb3e19b41b82570231d761", linkageName: "myl_f_7eeea69e953c279b3bbaecf005ac3887ccc3b5b7f1eb3e19b41b82570231d761", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13424280688608399015, i64 0, !"myl_f_7eeea69e953c279b3bbaecf005ac3887ccc3b5b7f1eb3e19b41b82570231d761"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!118 = !DILocation(line: 15, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!120 = !DILocation(line: 17, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!122 = !DILocation(line: 20, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!126 = !DILocation(line: 24, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!128 = !DILocation(line: 27, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!130 = !DILocation(line: 28, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!134 = !DILocation(line: 33, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!136 = !DILocation(line: 35, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!140 = !DILocation(line: 42, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!142 = !DILocation(line: 43, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!144 = !DILocation(line: 47, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!146 = !DILocation(line: 48, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!148 = !DILocation(line: 50, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!150 = !DILocation(line: 54, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!152 = !DILocation(line: 57, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!154 = !DILocation(line: 58, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!156 = !DILocation(line: 61, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!158 = !DILocation(line: 62, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!160 = !DILocation(line: 66, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!162 = !DILocation(line: 73, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!164 = !DILocation(line: 76, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!166 = !DILocation(line: 80, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!168 = !DILocation(line: 83, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!170 = !DILocation(line: 87, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!172 = !DILocation(line: 90, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!174 = !DILocation(line: 94, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!176 = !DILocation(line: 97, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!178 = !DILocation(line: 98, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647343)
!180 = !DILocation(line: 101, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!182 = !DILocation(line: 102, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647359)
!184 = !DILocation(line: 103, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!186 = !DILocation(line: 107, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!188 = !DILocation(line: 114, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!190 = !DILocation(line: 117, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647503)
!192 = !DILocation(line: 121, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!194 = !DILocation(line: 124, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!196 = !DILocation(line: 128, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647583)
!198 = !DILocation(line: 131, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647623)
!200 = !DILocation(line: 136, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647671)
!202 = !DILocation(line: 142, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647711)
!204 = !DILocation(line: 147, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647751)
!206 = !DILocation(line: 152, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647775)
!208 = !DILocation(line: 155, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647783)
!210 = !DILocation(line: 156, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647807)
!212 = !DILocation(line: 159, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647815)
!214 = !DILocation(line: 160, column: 0, scope: !215)
!217 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647847)
!216 = !DILocation(line: 164, column: 0, scope: !217)
!219 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647903)
!218 = !DILocation(line: 171, column: 0, scope: !219)
!221 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647927)
!220 = !DILocation(line: 174, column: 0, scope: !221)
!223 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647959)
!222 = !DILocation(line: 178, column: 0, scope: !223)
!225 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647983)
!224 = !DILocation(line: 181, column: 0, scope: !225)
!227 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648015)
!226 = !DILocation(line: 185, column: 0, scope: !227)
!229 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648039)
!228 = !DILocation(line: 188, column: 0, scope: !229)
!231 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648079)
!230 = !DILocation(line: 193, column: 0, scope: !231)
!233 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648239)
!232 = !DILocation(line: 213, column: 0, scope: !233)
