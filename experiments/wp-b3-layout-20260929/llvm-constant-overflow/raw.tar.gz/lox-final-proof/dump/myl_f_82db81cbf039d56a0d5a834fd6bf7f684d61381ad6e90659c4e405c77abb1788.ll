target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %callresult397 = alloca [24 x i8], align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v669 = load i64, ptr %slot1, align 8
  %op670 = add i64 %v669, 32
  store i64 %op670, ptr %slot4, align 8
  %mem671 = alloca i8, i64 24, align 8
  %ptr672 = ptrtoint ptr %mem671 to i64
  store i64 %ptr672, ptr %slot5, align 8
  %mem673 = alloca i8, i64 8, align 8
  %ptr674 = ptrtoint ptr %mem673 to i64
  store i64 %ptr674, ptr %slot6, align 8
  %mem675 = alloca i8, i64 8, align 8
  %ptr676 = ptrtoint ptr %mem675 to i64
  store i64 %ptr676, ptr %slot7, align 8
  %mem677 = alloca i8, i64 8, align 8
  %ptr678 = ptrtoint ptr %mem677 to i64
  store i64 %ptr678, ptr %slot8, align 8
  %mem679 = alloca i8, i64 8, align 8
  %ptr680 = ptrtoint ptr %mem679 to i64
  store i64 %ptr680, ptr %slot9, align 8
  %mem681 = alloca i8, i64 8, align 8
  %ptr682 = ptrtoint ptr %mem681 to i64
  store i64 %ptr682, ptr %slot10, align 8
  %mem683 = alloca i8, i64 8, align 8
  %ptr684 = ptrtoint ptr %mem683 to i64
  store i64 %ptr684, ptr %slot11, align 8
  %mem685 = alloca i8, i64 8, align 8
  %ptr686 = ptrtoint ptr %mem685 to i64
  store i64 %ptr686, ptr %slot12, align 8
  %mem687 = alloca i8, i64 8, align 8
  %ptr688 = ptrtoint ptr %mem687 to i64
  store i64 %ptr688, ptr %slot13, align 8
  %mem689 = alloca i8, i64 8, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot14, align 8
  %mem691 = alloca i8, i64 304, align 8
  %ptr692 = ptrtoint ptr %mem691 to i64
  store i64 %ptr692, ptr %slot15, align 8
  %mem693 = alloca i8, i64 8, align 8
  %ptr694 = ptrtoint ptr %mem693 to i64
  store i64 %ptr694, ptr %slot16, align 8
  %mem695 = alloca i8, i64 304, align 8
  %ptr696 = ptrtoint ptr %mem695 to i64
  store i64 %ptr696, ptr %slot17, align 8
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot18, align 8
  %mem699 = alloca i8, i64 8, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot19, align 8
  %mem701 = alloca i8, i64 8, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot20, align 8
  %mem703 = alloca i8, i64 8, align 8
  %ptr704 = ptrtoint ptr %mem703 to i64
  store i64 %ptr704, ptr %slot21, align 8
  %mem705 = alloca i8, i64 16, align 8
  %ptr706 = ptrtoint ptr %mem705 to i64
  store i64 %ptr706, ptr %slot22, align 8
  %mem707 = alloca i8, i64 8, align 8
  %ptr708 = ptrtoint ptr %mem707 to i64
  store i64 %ptr708, ptr %slot23, align 8
  %mem709 = alloca i8, i64 8, align 8
  %ptr710 = ptrtoint ptr %mem709 to i64
  store i64 %ptr710, ptr %slot24, align 8
  %mem711 = alloca i8, i64 8, align 8
  %ptr712 = ptrtoint ptr %mem711 to i64
  store i64 %ptr712, ptr %slot25, align 8
  %mem713 = alloca i8, i64 8, align 8
  %ptr714 = ptrtoint ptr %mem713 to i64
  store i64 %ptr714, ptr %slot26, align 8
  %mem715 = alloca i8, i64 8, align 8
  %ptr716 = ptrtoint ptr %mem715 to i64
  store i64 %ptr716, ptr %slot27, align 8
  %mem717 = alloca i8, i64 8, align 8
  %ptr718 = ptrtoint ptr %mem717 to i64
  store i64 %ptr718, ptr %slot28, align 8
  %mem719 = alloca i8, i64 8, align 8
  %ptr720 = ptrtoint ptr %mem719 to i64
  store i64 %ptr720, ptr %slot29, align 8
  %mem721 = alloca i8, i64 24, align 8
  %ptr722 = ptrtoint ptr %mem721 to i64
  store i64 %ptr722, ptr %slot30, align 8
  %mem723 = alloca i8, i64 8, align 8
  %ptr724 = ptrtoint ptr %mem723 to i64
  store i64 %ptr724, ptr %slot31, align 8
  %mem725 = alloca i8, i64 24, align 8
  %ptr726 = ptrtoint ptr %mem725 to i64
  store i64 %ptr726, ptr %slot32, align 8
  %mem727 = alloca i8, i64 8, align 8
  %ptr728 = ptrtoint ptr %mem727 to i64
  store i64 %ptr728, ptr %slot33, align 8
  %mem729 = alloca i8, i64 24, align 8
  %ptr730 = ptrtoint ptr %mem729 to i64
  store i64 %ptr730, ptr %slot34, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem731 = alloca i8, i64 8, align 8
  %ptr732 = ptrtoint ptr %mem731 to i64
  store i64 %ptr732, ptr %slot35, align 8
  %v733 = load i64, ptr %slot1, align 8
  %op734 = add i64 %v733, 64
  store i64 %op734, ptr %slot36, align 8
  %v735 = load i64, ptr %slot36, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !4, !noalias !3
  store i64 %ld737, ptr %slot37, align 8
  %stack738 = call ptr @llvm.stacksave()
  %stackaddr739 = ptrtoint ptr %stack738 to i64
  %v740 = load i64, ptr %slot37, align 8
  %cmp741 = icmp ult i64 %stackaddr739, %v740
  %cv742 = zext i1 %cmp741 to i64
  store i64 %cv742, ptr %slot38, align 8
  %v743 = load i64, ptr %slot38, align 8
  %cond744 = icmp ne i64 %v743, 0
  br i1 %cond744, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v745 = load i64, ptr %slot1, align 8
  %p746 = inttoptr i64 %v745 to ptr
  call void @myl_qbe_fail_frame(ptr %p746) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v747 = load i64, ptr %slot20, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i64 0, ptr %p748, align 8, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot23, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 0, ptr %p750, align 8, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot2, align 8
  %v752 = load i64, ptr %slot18, align 8
  %p753 = inttoptr i64 %v752 to ptr
  store i64 %v751, ptr %p753, align 8, !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot3, align 8
  %v755 = load i64, ptr %slot19, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i64 %v754, ptr %p756, align 8, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot1, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %call759 = call ptr @myl_qbe_heap(ptr %p758) nomerge, !dbg !112
  %calladdr760 = ptrtoint ptr %call759 to i64
  store i64 %calladdr760, ptr %slot39, align 8
  %v761 = load i64, ptr %slot1, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %call763 = call i64 @myl_qbe_region_mark(ptr %p762) nomerge, !dbg !112
  store i64 %call763, ptr %slot40, align 8
  %v764 = load i64, ptr %slot6, align 8
  %p765 = inttoptr i64 %v764 to ptr
  store i32 0, ptr %p765, align 4, !alias.scope !3, !noalias !4
  %v766 = load i64, ptr %slot7, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 0, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot8, align 8
  %p769 = inttoptr i64 %v768 to ptr
  store i32 0, ptr %p769, align 4, !alias.scope !3, !noalias !4
  %v770 = load i64, ptr %slot9, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i32 0, ptr %p771, align 4, !alias.scope !3, !noalias !4
  %v772 = load i64, ptr %slot10, align 8
  %p773 = inttoptr i64 %v772 to ptr
  store i32 0, ptr %p773, align 4, !alias.scope !3, !noalias !4
  %v774 = load i64, ptr %slot11, align 8
  %p775 = inttoptr i64 %v774 to ptr
  store i32 0, ptr %p775, align 4, !alias.scope !3, !noalias !4
  %v776 = load i64, ptr %slot12, align 8
  %p777 = inttoptr i64 %v776 to ptr
  store i32 0, ptr %p777, align 4, !alias.scope !3, !noalias !4
  %v778 = load i64, ptr %slot13, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 0, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot14, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i32 0, ptr %p781, align 4, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot7, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i32 2, ptr %p783, align 4, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot9, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i32 2, ptr %p785, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v786 = load i64, ptr %slot18, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i64, ptr %p787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld788, ptr %slot41, align 8
  %v789 = load i64, ptr %slot41, align 8
  %v790 = load i64, ptr %slot28, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i64 %v789, ptr %p791, align 8, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot28, align 8
  %p793 = inttoptr i64 %v792 to ptr
  %ld794 = load i64, ptr %p793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld794, ptr %slot42, align 8
  %v795 = load i64, ptr %slot42, align 8
  %op796 = add i64 %v795, 0
  store i64 %op796, ptr %slot43, align 8
  %v797 = load i64, ptr %slot43, align 8
  %v798 = load i64, ptr %slot28, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot10, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i32, ptr %p801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld802, ptr %slot44, align 8
  %v803 = load i32, ptr %slot44, align 8
  %cv804 = zext i32 %v803 to i64
  %cond805 = icmp ne i64 %cv804, 0
  br i1 %cond805, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v806 = load i64, ptr %slot10, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 0, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot15, align 8
  store i64 %v808, ptr %slot45, align 8
  %v809 = load i64, ptr %slot11, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i32, ptr %p810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld811, ptr %slot46, align 8
  %v812 = load i32, ptr %slot46, align 8
  %op813 = and i32 %v812, 28
  store i32 %op813, ptr %slot47, align 8
  %v814 = load i32, ptr %slot47, align 8
  %cv815 = zext i32 %v814 to i64
  %cond816 = icmp ne i64 %cv815, 0
  br i1 %cond816, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v817 = load i64, ptr %slot39, align 8
  store i64 %v817, ptr %slot48, align 8
  %v818 = load i64, ptr %slot48, align 8
  %v819 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v818, i64 %v819) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v820 = load i64, ptr %slot39, align 8
  store i64 %v820, ptr %slot49, align 8
  %v821 = load i64, ptr %slot49, align 8
  %v822 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v821, i64 %v822) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v823 = load i64, ptr %slot28, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot50, align 8
  %v826 = load i64, ptr %slot50, align 8
  %op827 = add i64 %v826, 8
  store i64 %op827, ptr %slot51, align 8
  %v828 = load i64, ptr %slot51, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i64, ptr %p829, align 8, !alias.scope !4, !noalias !3
  store i64 %ld830, ptr %slot52, align 8
  %v831 = load i64, ptr %slot52, align 8
  %v832 = load i64, ptr %slot28, align 8
  %p833 = inttoptr i64 %v832 to ptr
  store i64 %v831, ptr %p833, align 8, !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot10, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %ld836 = load i32, ptr %p835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld836, ptr %slot53, align 8
  %v837 = load i32, ptr %slot53, align 8
  %cv838 = zext i32 %v837 to i64
  %cond839 = icmp ne i64 %cv838, 0
  br i1 %cond839, label %bb_rcslotdrop28, label %bb_rcslotdone28
bb_rcslotdrop28:
  %v840 = load i64, ptr %slot10, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i32 0, ptr %p841, align 4, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot15, align 8
  store i64 %v842, ptr %slot54, align 8
  %v843 = load i64, ptr %slot11, align 8
  %p844 = inttoptr i64 %v843 to ptr
  %ld845 = load i32, ptr %p844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld845, ptr %slot55, align 8
  %v846 = load i32, ptr %slot55, align 8
  %op847 = and i32 %v846, 28
  store i32 %op847, ptr %slot56, align 8
  %v848 = load i32, ptr %slot56, align 8
  %cv849 = zext i32 %v848 to i64
  %cond850 = icmp ne i64 %cv849, 0
  br i1 %cond850, label %bb_rcslotrole28, label %bb_rcslotowner28
bb_rcslotrole28:
  %v851 = load i64, ptr %slot39, align 8
  store i64 %v851, ptr %slot57, align 8
  %v852 = load i64, ptr %slot57, align 8
  %v853 = load i64, ptr %slot54, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v852, i64 %v853) nomerge, !dbg !116
  br label %bb_rcslotdone28
bb_rcslotowner28:
  %v854 = load i64, ptr %slot39, align 8
  store i64 %v854, ptr %slot58, align 8
  %v855 = load i64, ptr %slot58, align 8
  %v856 = load i64, ptr %slot54, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v855, i64 %v856) nomerge, !dbg !116
  br label %bb_rcslotdone28
bb_rcslotdone28:
  %v857 = load i64, ptr %slot28, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i64, ptr %p858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld859, ptr %slot59, align 8
  %v860 = load i64, ptr %slot59, align 8
  %v861 = load i64, ptr %slot20, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i64 %v860, ptr %p862, align 8, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot19, align 8
  %p864 = inttoptr i64 %v863 to ptr
  %ld865 = load i64, ptr %p864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld865, ptr %slot60, align 8
  %v866 = load i64, ptr %slot60, align 8
  %v867 = load i64, ptr %slot28, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i64 %v866, ptr %p868, align 8, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot28, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i64, ptr %p870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld871, ptr %slot61, align 8
  %v872 = load i64, ptr %slot61, align 8
  %v873 = load i64, ptr %slot21, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i64 %v872, ptr %p874, align 8, !alias.scope !3, !noalias !4
  %v875 = load i64, ptr %slot21, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %ld877 = load i64, ptr %p876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld877, ptr %slot62, align 8
  %v878 = load i64, ptr %slot62, align 8
  %v879 = load i64, ptr %slot28, align 8
  %p880 = inttoptr i64 %v879 to ptr
  store i64 %v878, ptr %p880, align 8, !alias.scope !3, !noalias !4
  %v881 = load i64, ptr %slot29, align 8
  %p882 = inttoptr i64 %v881 to ptr
  store i64 0, ptr %p882, align 8, !alias.scope !3, !noalias !4
  %v883 = load i64, ptr %slot29, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %ld885 = load i64, ptr %p884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld885, ptr %slot63, align 8
  %v886 = load i64, ptr %slot28, align 8
  %p887 = inttoptr i64 %v886 to ptr
  %ld888 = load i64, ptr %p887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld888, ptr %slot64, align 8
  %v889 = load i64, ptr %slot64, align 8
  %v890 = load i64, ptr %slot63, align 8
  %cmp891 = icmp slt i64 %v889, %v890
  %cv892 = zext i1 %cmp891 to i64
  store i64 %cv892, ptr %slot65, align 8
  %v893 = load i64, ptr %slot65, align 8
  %v894 = load i64, ptr %slot28, align 8
  %p895 = inttoptr i64 %v894 to ptr
  store i64 %v893, ptr %p895, align 8, !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot28, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %ld898 = load i64, ptr %p897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld898, ptr %slot66, align 8
  %v899 = load i64, ptr %slot66, align 8
  %cond900 = icmp ne i64 %v899, 0
  br i1 %cond900, label %bb_next43, label %bb_i15
bb_next43:
  %v901 = load i64, ptr %slot20, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i64, ptr %p902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld903, ptr %slot67, align 8
  %v904 = load i64, ptr %slot67, align 8
  %op905 = add i64 %v904, 0
  store i64 %op905, ptr %slot68, align 8
  %v906 = load i64, ptr %slot68, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i64, ptr %p907, align 8, !alias.scope !6, !noalias !7
  store i64 %ld908, ptr %slot69, align 8
  %v909 = load i64, ptr %slot69, align 8
  %v910 = load i64, ptr %slot28, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i64 %v909, ptr %p911, align 8, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot28, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i64, ptr %p913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld914, ptr %slot70, align 8
  %v915 = load i64, ptr %slot70, align 8
  %cmp916 = icmp ugt i64 %v915, 9223372036854775807
  %cv917 = zext i1 %cmp916 to i64
  store i64 %cv917, ptr %slot71, align 8
  %v918 = load i64, ptr %slot71, align 8
  %cond919 = icmp ne i64 %v918, 0
  br i1 %cond919, label %bb_cast_overflow48, label %bb_cast_ok48
bb_cast_overflow48:
  %v920 = load i64, ptr %slot1, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %v922 = load i64, ptr %slot70, align 8
  call void @myl_qbe_fail_cast(ptr %p921, i64 %v922, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok48:
  %v923 = load i64, ptr %slot70, align 8
  %v924 = load i64, ptr %slot28, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i64 %v923, ptr %p925, align 8, !alias.scope !3, !noalias !4
  %v926 = load i64, ptr %slot21, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i64, ptr %p927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld928, ptr %slot72, align 8
  %v929 = load i64, ptr %slot72, align 8
  %v930 = load i64, ptr %slot29, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i64 %v929, ptr %p931, align 8, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot29, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %ld934 = load i64, ptr %p933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld934, ptr %slot73, align 8
  %v935 = load i64, ptr %slot28, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i64, ptr %p936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld937, ptr %slot74, align 8
  %v938 = load i64, ptr %slot74, align 8
  %v939 = load i64, ptr %slot73, align 8
  %ovpair941 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v938, i64 %v939)
  %op940 = extractvalue { i64, i1 } %ovpair941, 0
  %ov942 = extractvalue { i64, i1 } %ovpair941, 1
  store i64 %op940, ptr %slot75, align 8
  %v943 = load i64, ptr %slot74, align 8
  %v944 = load i64, ptr %slot75, align 8
  %op945 = xor i64 %v943, %v944
  store i64 %op945, ptr %slot76, align 8
  %v946 = load i64, ptr %slot73, align 8
  %v947 = load i64, ptr %slot75, align 8
  %op948 = xor i64 %v946, %v947
  store i64 %op948, ptr %slot77, align 8
  %v949 = load i64, ptr %slot76, align 8
  %v950 = load i64, ptr %slot77, align 8
  %op951 = and i64 %v949, %v950
  store i64 %op951, ptr %slot78, align 8
  %cv952 = zext i1 %ov942 to i64
  store i64 %cv952, ptr %slot79, align 8
  %v953 = load i64, ptr %slot79, align 8
  %cond954 = icmp ne i64 %v953, 0
  br i1 %cond954, label %bb_overflow52, label %bb_checked52
bb_overflow52:
  %v955 = load i64, ptr %slot1, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %v957 = load i64, ptr %slot74, align 8
  %v958 = load i64, ptr %slot73, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p956, i64 0, i64 %v957, i64 %v958, i64 64) nomerge, !dbg !120
  unreachable
bb_checked52:
  %v959 = load i64, ptr %slot75, align 8
  %v960 = load i64, ptr %slot28, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i64 %v959, ptr %p961, align 8, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot28, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i64, ptr %p963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld964, ptr %slot80, align 8
  %v965 = load i64, ptr %slot80, align 8
  %v966 = load i64, ptr %slot21, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i64 %v965, ptr %p967, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v968 = load i64, ptr %slot21, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %ld970 = load i64, ptr %p969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld970, ptr %slot81, align 8
  %v971 = load i64, ptr %slot81, align 8
  %v972 = load i64, ptr %slot28, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i64 %v971, ptr %p973, align 8, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot20, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %ld976 = load i64, ptr %p975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld976, ptr %slot82, align 8
  %v977 = load i64, ptr %slot28, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %ld979 = load i64, ptr %p978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld979, ptr %slot83, align 8
  %v980 = load i64, ptr %slot82, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i64, ptr %p981, align 8, !alias.scope !6, !noalias !7
  store i64 %ld982, ptr %slot84, align 8
  %v983 = load i64, ptr %slot83, align 8
  %v984 = load i64, ptr %slot84, align 8
  %cmp985 = icmp ult i64 %v983, %v984
  %cv986 = zext i1 %cmp985 to i64
  store i64 %cv986, ptr %slot85, align 8
  %v987 = load i64, ptr %slot85, align 8
  %cond988 = icmp ne i64 %v987, 0
  br i1 %cond988, label %bb_success64, label %bb_failed64
bb_failed64:
  %v989 = load i64, ptr %slot1, align 8
  %p990 = inttoptr i64 %v989 to ptr
  %v991 = load i64, ptr %slot83, align 8
  %v992 = load i64, ptr %slot84, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p990, i64 %v991, i64 %v992) nomerge, !dbg !122
  unreachable
bb_success64:
  %v993 = load i64, ptr %slot82, align 8
  %op994 = add i64 %v993, 32
  store i64 %op994, ptr %slot86, align 8
  %v995 = load i64, ptr %slot86, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i64, ptr %p996, align 8, !alias.scope !6, !noalias !7
  store i64 %ld997, ptr %slot87, align 8
  %v998 = load i64, ptr %slot83, align 8
  %op999 = mul i64 %v998, 88
  store i64 %op999, ptr %slot88, align 8
  %v1000 = load i64, ptr %slot87, align 8
  %v1001 = load i64, ptr %slot88, align 8
  %op1002 = add i64 %v1000, %v1001
  store i64 %op1002, ptr %slot89, align 8
  %v1003 = load i64, ptr %slot89, align 8
  %v1004 = load i64, ptr %slot28, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  store i64 %v1003, ptr %p1005, align 8, !alias.scope !3, !noalias !4
  %v1006 = load i64, ptr %slot28, align 8
  %p1007 = inttoptr i64 %v1006 to ptr
  %ld1008 = load i64, ptr %p1007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1008, ptr %slot90, align 8
  %v1009 = load i64, ptr %slot17, align 8
  store i64 %v1009, ptr %slot91, align 8
  %v1010 = load i64, ptr %slot39, align 8
  %v1011 = load i64, ptr %slot91, align 8
  %v1012 = load i64, ptr %slot90, align 8
  %call1013 = call i32 @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_loan(i64 %v1010, i64 %v1011, i64 %v1012) nomerge, !dbg !122
  store i32 %call1013, ptr %slot92, align 8
  %v1014 = load i32, ptr %slot92, align 8
  %cv1015 = zext i32 %v1014 to i64
  %cond1016 = icmp ne i64 %cv1015, 0
  br i1 %cond1016, label %bb_rcsuccess72, label %bb_rcfailure72
bb_rcfailure72:
  %v1017 = load i64, ptr %slot39, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %call1019 = call i32 @myl_rc_take_failure(ptr %p1018) nomerge, !dbg !122
  store i32 %call1019, ptr %slot93, align 8
  %v1020 = load i64, ptr %slot1, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %v1022 = load i32, ptr %slot93, align 8
  %call1023 = call i32 @myl_qbe_rc_status(ptr %p1021, i32 %v1022) nomerge, !dbg !122
  store i32 %call1023, ptr %slot94, align 8
  br label %bb_failure
bb_rcsuccess72:
  %v1024 = load i64, ptr %slot13, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  store i32 2, ptr %p1025, align 4, !alias.scope !3, !noalias !4
  %v1026 = load i64, ptr %slot13, align 8
  %p1027 = inttoptr i64 %v1026 to ptr
  store i32 16, ptr %p1027, align 4, !alias.scope !3, !noalias !4
  %v1028 = load i64, ptr %slot12, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i32 1, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot15, align 8
  store i64 %v1030, ptr %slot95, align 8
  %v1031 = load i64, ptr %slot17, align 8
  store i64 %v1031, ptr %slot96, align 8
  %v1032 = load i64, ptr %slot96, align 8
  %v1033 = load i64, ptr %slot95, align 8
  %p1034 = inttoptr i64 %v1032 to ptr
  %p1035 = inttoptr i64 %v1033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1035, ptr %p1034, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot11, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i32 2, ptr %p1037, align 4, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot13, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %ld1040 = load i32, ptr %p1039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1040, ptr %slot97, align 8
  %v1041 = load i32, ptr %slot97, align 8
  %v1042 = load i64, ptr %slot11, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 %v1041, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot12, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 0, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot10, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  store i32 1, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  %v1048 = load i64, ptr %slot95, align 8
  %v1049 = load i64, ptr %slot28, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i64 %v1048, ptr %p1050, align 8, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot28, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %ld1053 = load i64, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1053, ptr %slot98, align 8
  %v1054 = load i64, ptr %slot98, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %ld1056 = load i32, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  %ext1057 = zext i32 %ld1056 to i64
  store i64 %ext1057, ptr %slot99, align 8
  %v1058 = load i64, ptr %slot99, align 8
  %cmp1059 = icmp eq i64 %v1058, 0
  %cv1060 = zext i1 %cmp1059 to i64
  store i64 %cv1060, ptr %slot100, align 8
  %v1061 = load i64, ptr %slot100, align 8
  %cond1062 = icmp ne i64 %v1061, 0
  br i1 %cond1062, label %bb_rcarm88, label %bb_rcarmnext88
bb_rcarm88:
  %v1063 = load i64, ptr %slot17, align 8
  store i64 %v1063, ptr %slot101, align 8
  %v1064 = load i64, ptr %slot98, align 8
  %op1065 = add i64 %v1064, 8
  store i64 %op1065, ptr %slot102, align 8
  %v1066 = load i64, ptr %slot40, align 8
  store i64 %v1066, ptr %slot103, align 8
  %v1067 = load i64, ptr %slot39, align 8
  %v1068 = load i64, ptr %slot101, align 8
  %v1069 = load i64, ptr %slot102, align 8
  %v1070 = load i64, ptr %slot103, align 8
  %cv1071 = trunc i64 %v1070 to i32
  %call1072 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64 %v1067, i64 %v1068, i64 %v1069, i32 %cv1071) nomerge, !dbg !124
  store i32 %call1072, ptr %slot104, align 8
  %v1073 = load i32, ptr %slot104, align 8
  %cv1074 = zext i32 %v1073 to i64
  %cond1075 = icmp ne i64 %cv1074, 0
  br i1 %cond1075, label %bb_rcsuccess93, label %bb_rcfailure93
bb_rcfailure93:
  %v1076 = load i64, ptr %slot39, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %call1078 = call i32 @myl_rc_take_failure(ptr %p1077) nomerge, !dbg !124
  store i32 %call1078, ptr %slot105, align 8
  %v1079 = load i64, ptr %slot1, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %v1081 = load i32, ptr %slot105, align 8
  %call1082 = call i32 @myl_qbe_rc_status(ptr %p1080, i32 %v1081) nomerge, !dbg !124
  store i32 %call1082, ptr %slot106, align 8
  br label %bb_failure
bb_rcsuccess93:
  %v1083 = load i64, ptr %slot13, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i32 2, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot12, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i32 1, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot6, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %ld1089 = load i32, ptr %p1088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1089, ptr %slot107, align 8
  %v1090 = load i32, ptr %slot107, align 8
  %cv1091 = zext i32 %v1090 to i64
  %cond1092 = icmp ne i64 %cv1091, 0
  br i1 %cond1092, label %bb_rcslotdrop100, label %bb_rcslotdone100
bb_rcslotdrop100:
  %v1093 = load i64, ptr %slot6, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  store i32 0, ptr %p1094, align 4, !alias.scope !3, !noalias !4
  %v1095 = load i64, ptr %slot22, align 8
  store i64 %v1095, ptr %slot108, align 8
  %v1096 = load i64, ptr %slot7, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  %ld1098 = load i32, ptr %p1097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1098, ptr %slot109, align 8
  %v1099 = load i32, ptr %slot109, align 8
  %op1100 = and i32 %v1099, 28
  store i32 %op1100, ptr %slot110, align 8
  %v1101 = load i32, ptr %slot110, align 8
  %cv1102 = zext i32 %v1101 to i64
  %cond1103 = icmp ne i64 %cv1102, 0
  br i1 %cond1103, label %bb_rcslotrole100, label %bb_rcslotowner100
bb_rcslotrole100:
  %v1104 = load i64, ptr %slot39, align 8
  store i64 %v1104, ptr %slot111, align 8
  %v1105 = load i64, ptr %slot111, align 8
  %v1106 = load i64, ptr %slot108, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1105, i64 %v1106) nomerge, !dbg !124
  br label %bb_rcslotdone100
bb_rcslotowner100:
  %v1107 = load i64, ptr %slot39, align 8
  store i64 %v1107, ptr %slot112, align 8
  %v1108 = load i64, ptr %slot112, align 8
  %v1109 = load i64, ptr %slot108, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v1108, i64 %v1109) nomerge, !dbg !124
  br label %bb_rcslotdone100
bb_rcslotdone100:
  %v1110 = load i64, ptr %slot101, align 8
  %v1111 = load i64, ptr %slot22, align 8
  %p1112 = inttoptr i64 %v1110 to ptr
  %p1113 = inttoptr i64 %v1111 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1113, ptr %p1112, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot12, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i32 0, ptr %p1115, align 4, !alias.scope !3, !noalias !4
  %v1116 = load i64, ptr %slot22, align 8
  store i64 %v1116, ptr %slot113, align 8
  %v1117 = load i64, ptr %slot7, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  store i32 2, ptr %p1118, align 4, !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot6, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  store i32 1, ptr %p1120, align 4, !alias.scope !3, !noalias !4
  %v1121 = load i64, ptr %slot10, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  %ld1123 = load i32, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1123, ptr %slot114, align 8
  %v1124 = load i32, ptr %slot114, align 8
  %cv1125 = zext i32 %v1124 to i64
  %cond1126 = icmp ne i64 %cv1125, 0
  br i1 %cond1126, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v1127 = load i64, ptr %slot10, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i32 0, ptr %p1128, align 4, !alias.scope !3, !noalias !4
  %v1129 = load i64, ptr %slot15, align 8
  store i64 %v1129, ptr %slot115, align 8
  %v1130 = load i64, ptr %slot11, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %ld1132 = load i32, ptr %p1131, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1132, ptr %slot116, align 8
  %v1133 = load i32, ptr %slot116, align 8
  %op1134 = and i32 %v1133, 28
  store i32 %op1134, ptr %slot117, align 8
  %v1135 = load i32, ptr %slot117, align 8
  %cv1136 = zext i32 %v1135 to i64
  %cond1137 = icmp ne i64 %cv1136, 0
  br i1 %cond1137, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v1138 = load i64, ptr %slot39, align 8
  store i64 %v1138, ptr %slot118, align 8
  %v1139 = load i64, ptr %slot118, align 8
  %v1140 = load i64, ptr %slot115, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1139, i64 %v1140) nomerge, !dbg !124
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v1141 = load i64, ptr %slot39, align 8
  store i64 %v1141, ptr %slot119, align 8
  %v1142 = load i64, ptr %slot119, align 8
  %v1143 = load i64, ptr %slot115, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1142, i64 %v1143) nomerge, !dbg !124
  br label %bb_rcslotdone113
bb_rcslotdone113:
  br label %bb_i18
bb_rcarmnext88:
  %v1144 = load i64, ptr %slot99, align 8
  %cmp1145 = icmp eq i64 %v1144, 1
  %cv1146 = zext i1 %cmp1145 to i64
  store i64 %cv1146, ptr %slot120, align 8
  %v1147 = load i64, ptr %slot120, align 8
  %cond1148 = icmp ne i64 %v1147, 0
  br i1 %cond1148, label %bb_rcarm120, label %bb_rcarmnext120
bb_rcarm120:
  %v1149 = load i64, ptr %slot10, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i32, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1151, ptr %slot121, align 8
  %v1152 = load i32, ptr %slot121, align 8
  %cv1153 = zext i32 %v1152 to i64
  %cond1154 = icmp ne i64 %cv1153, 0
  br i1 %cond1154, label %bb_rcslotdrop123, label %bb_rcslotdone123
bb_rcslotdrop123:
  %v1155 = load i64, ptr %slot10, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  store i32 0, ptr %p1156, align 4, !alias.scope !3, !noalias !4
  %v1157 = load i64, ptr %slot15, align 8
  store i64 %v1157, ptr %slot122, align 8
  %v1158 = load i64, ptr %slot11, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i32, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1160, ptr %slot123, align 8
  %v1161 = load i32, ptr %slot123, align 8
  %op1162 = and i32 %v1161, 28
  store i32 %op1162, ptr %slot124, align 8
  %v1163 = load i32, ptr %slot124, align 8
  %cv1164 = zext i32 %v1163 to i64
  %cond1165 = icmp ne i64 %cv1164, 0
  br i1 %cond1165, label %bb_rcslotrole123, label %bb_rcslotowner123
bb_rcslotrole123:
  %v1166 = load i64, ptr %slot39, align 8
  store i64 %v1166, ptr %slot125, align 8
  %v1167 = load i64, ptr %slot125, align 8
  %v1168 = load i64, ptr %slot122, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1167, i64 %v1168) nomerge, !dbg !124
  br label %bb_rcslotdone123
bb_rcslotowner123:
  %v1169 = load i64, ptr %slot39, align 8
  store i64 %v1169, ptr %slot126, align 8
  %v1170 = load i64, ptr %slot126, align 8
  %v1171 = load i64, ptr %slot122, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1170, i64 %v1171) nomerge, !dbg !124
  br label %bb_rcslotdone123
bb_rcslotdone123:
  br label %bb_i63
bb_rcarmnext120:
  %v1172 = load i64, ptr %slot99, align 8
  %cmp1173 = icmp eq i64 %v1172, 2
  %cv1174 = zext i1 %cmp1173 to i64
  store i64 %cv1174, ptr %slot127, align 8
  %v1175 = load i64, ptr %slot127, align 8
  %cond1176 = icmp ne i64 %v1175, 0
  br i1 %cond1176, label %bb_rcarm130, label %bb_rcarmnext130
bb_rcarm130:
  %v1177 = load i64, ptr %slot10, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i32, ptr %p1178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1179, ptr %slot128, align 8
  %v1180 = load i32, ptr %slot128, align 8
  %cv1181 = zext i32 %v1180 to i64
  %cond1182 = icmp ne i64 %cv1181, 0
  br i1 %cond1182, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v1183 = load i64, ptr %slot10, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  store i32 0, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot15, align 8
  store i64 %v1185, ptr %slot129, align 8
  %v1186 = load i64, ptr %slot11, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i32, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1188, ptr %slot130, align 8
  %v1189 = load i32, ptr %slot130, align 8
  %op1190 = and i32 %v1189, 28
  store i32 %op1190, ptr %slot131, align 8
  %v1191 = load i32, ptr %slot131, align 8
  %cv1192 = zext i32 %v1191 to i64
  %cond1193 = icmp ne i64 %cv1192, 0
  br i1 %cond1193, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1194 = load i64, ptr %slot39, align 8
  store i64 %v1194, ptr %slot132, align 8
  %v1195 = load i64, ptr %slot132, align 8
  %v1196 = load i64, ptr %slot129, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1195, i64 %v1196) nomerge, !dbg !124
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1197 = load i64, ptr %slot39, align 8
  store i64 %v1197, ptr %slot133, align 8
  %v1198 = load i64, ptr %slot133, align 8
  %v1199 = load i64, ptr %slot129, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1198, i64 %v1199) nomerge, !dbg !124
  br label %bb_rcslotdone133
bb_rcslotdone133:
  br label %bb_i64
bb_rcarmnext130:
  %v1200 = load i64, ptr %slot99, align 8
  %cmp1201 = icmp eq i64 %v1200, 3
  %cv1202 = zext i1 %cmp1201 to i64
  store i64 %cv1202, ptr %slot134, align 8
  %v1203 = load i64, ptr %slot134, align 8
  %cond1204 = icmp ne i64 %v1203, 0
  br i1 %cond1204, label %bb_rcarm140, label %bb_rcarmnext140
bb_rcarm140:
  %v1205 = load i64, ptr %slot10, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %ld1207 = load i32, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1207, ptr %slot135, align 8
  %v1208 = load i32, ptr %slot135, align 8
  %cv1209 = zext i32 %v1208 to i64
  %cond1210 = icmp ne i64 %cv1209, 0
  br i1 %cond1210, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v1211 = load i64, ptr %slot10, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i32 0, ptr %p1212, align 4, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot15, align 8
  store i64 %v1213, ptr %slot136, align 8
  %v1214 = load i64, ptr %slot11, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %ld1216 = load i32, ptr %p1215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1216, ptr %slot137, align 8
  %v1217 = load i32, ptr %slot137, align 8
  %op1218 = and i32 %v1217, 28
  store i32 %op1218, ptr %slot138, align 8
  %v1219 = load i32, ptr %slot138, align 8
  %cv1220 = zext i32 %v1219 to i64
  %cond1221 = icmp ne i64 %cv1220, 0
  br i1 %cond1221, label %bb_rcslotrole143, label %bb_rcslotowner143
bb_rcslotrole143:
  %v1222 = load i64, ptr %slot39, align 8
  store i64 %v1222, ptr %slot139, align 8
  %v1223 = load i64, ptr %slot139, align 8
  %v1224 = load i64, ptr %slot136, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1223, i64 %v1224) nomerge, !dbg !124
  br label %bb_rcslotdone143
bb_rcslotowner143:
  %v1225 = load i64, ptr %slot39, align 8
  store i64 %v1225, ptr %slot140, align 8
  %v1226 = load i64, ptr %slot140, align 8
  %v1227 = load i64, ptr %slot136, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1226, i64 %v1227) nomerge, !dbg !124
  br label %bb_rcslotdone143
bb_rcslotdone143:
  br label %bb_i65
bb_rcarmnext140:
  %v1228 = load i64, ptr %slot99, align 8
  %cmp1229 = icmp eq i64 %v1228, 4
  %cv1230 = zext i1 %cmp1229 to i64
  store i64 %cv1230, ptr %slot141, align 8
  %v1231 = load i64, ptr %slot141, align 8
  %cond1232 = icmp ne i64 %v1231, 0
  br i1 %cond1232, label %bb_rcarm150, label %bb_rcarmnext150
bb_rcarm150:
  %v1233 = load i64, ptr %slot10, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  %ld1235 = load i32, ptr %p1234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1235, ptr %slot142, align 8
  %v1236 = load i32, ptr %slot142, align 8
  %cv1237 = zext i32 %v1236 to i64
  %cond1238 = icmp ne i64 %cv1237, 0
  br i1 %cond1238, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v1239 = load i64, ptr %slot10, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i32 0, ptr %p1240, align 4, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot15, align 8
  store i64 %v1241, ptr %slot143, align 8
  %v1242 = load i64, ptr %slot11, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %ld1244 = load i32, ptr %p1243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1244, ptr %slot144, align 8
  %v1245 = load i32, ptr %slot144, align 8
  %op1246 = and i32 %v1245, 28
  store i32 %op1246, ptr %slot145, align 8
  %v1247 = load i32, ptr %slot145, align 8
  %cv1248 = zext i32 %v1247 to i64
  %cond1249 = icmp ne i64 %cv1248, 0
  br i1 %cond1249, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v1250 = load i64, ptr %slot39, align 8
  store i64 %v1250, ptr %slot146, align 8
  %v1251 = load i64, ptr %slot146, align 8
  %v1252 = load i64, ptr %slot143, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1251, i64 %v1252) nomerge, !dbg !124
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v1253 = load i64, ptr %slot39, align 8
  store i64 %v1253, ptr %slot147, align 8
  %v1254 = load i64, ptr %slot147, align 8
  %v1255 = load i64, ptr %slot143, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1254, i64 %v1255) nomerge, !dbg !124
  br label %bb_rcslotdone153
bb_rcslotdone153:
  br label %bb_i66
bb_rcarmnext150:
  %v1256 = load i64, ptr %slot99, align 8
  %cmp1257 = icmp eq i64 %v1256, 5
  %cv1258 = zext i1 %cmp1257 to i64
  store i64 %cv1258, ptr %slot148, align 8
  %v1259 = load i64, ptr %slot148, align 8
  %cond1260 = icmp ne i64 %v1259, 0
  br i1 %cond1260, label %bb_rcarm160, label %bb_rcarmnext160
bb_rcarm160:
  %v1261 = load i64, ptr %slot10, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %ld1263 = load i32, ptr %p1262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1263, ptr %slot149, align 8
  %v1264 = load i32, ptr %slot149, align 8
  %cv1265 = zext i32 %v1264 to i64
  %cond1266 = icmp ne i64 %cv1265, 0
  br i1 %cond1266, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v1267 = load i64, ptr %slot10, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  store i32 0, ptr %p1268, align 4, !alias.scope !3, !noalias !4
  %v1269 = load i64, ptr %slot15, align 8
  store i64 %v1269, ptr %slot150, align 8
  %v1270 = load i64, ptr %slot11, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i32, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1272, ptr %slot151, align 8
  %v1273 = load i32, ptr %slot151, align 8
  %op1274 = and i32 %v1273, 28
  store i32 %op1274, ptr %slot152, align 8
  %v1275 = load i32, ptr %slot152, align 8
  %cv1276 = zext i32 %v1275 to i64
  %cond1277 = icmp ne i64 %cv1276, 0
  br i1 %cond1277, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v1278 = load i64, ptr %slot39, align 8
  store i64 %v1278, ptr %slot153, align 8
  %v1279 = load i64, ptr %slot153, align 8
  %v1280 = load i64, ptr %slot150, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1279, i64 %v1280) nomerge, !dbg !124
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v1281 = load i64, ptr %slot39, align 8
  store i64 %v1281, ptr %slot154, align 8
  %v1282 = load i64, ptr %slot154, align 8
  %v1283 = load i64, ptr %slot150, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1282, i64 %v1283) nomerge, !dbg !124
  br label %bb_rcslotdone163
bb_rcslotdone163:
  br label %bb_i67
bb_rcarmnext160:
  %v1284 = load i64, ptr %slot99, align 8
  %cmp1285 = icmp eq i64 %v1284, 6
  %cv1286 = zext i1 %cmp1285 to i64
  store i64 %cv1286, ptr %slot155, align 8
  %v1287 = load i64, ptr %slot155, align 8
  %cond1288 = icmp ne i64 %v1287, 0
  br i1 %cond1288, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  %v1289 = load i64, ptr %slot10, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %ld1291 = load i32, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1291, ptr %slot156, align 8
  %v1292 = load i32, ptr %slot156, align 8
  %cv1293 = zext i32 %v1292 to i64
  %cond1294 = icmp ne i64 %cv1293, 0
  br i1 %cond1294, label %bb_rcslotdrop173, label %bb_rcslotdone173
bb_rcslotdrop173:
  %v1295 = load i64, ptr %slot10, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i32 0, ptr %p1296, align 4, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot15, align 8
  store i64 %v1297, ptr %slot157, align 8
  %v1298 = load i64, ptr %slot11, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  %ld1300 = load i32, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1300, ptr %slot158, align 8
  %v1301 = load i32, ptr %slot158, align 8
  %op1302 = and i32 %v1301, 28
  store i32 %op1302, ptr %slot159, align 8
  %v1303 = load i32, ptr %slot159, align 8
  %cv1304 = zext i32 %v1303 to i64
  %cond1305 = icmp ne i64 %cv1304, 0
  br i1 %cond1305, label %bb_rcslotrole173, label %bb_rcslotowner173
bb_rcslotrole173:
  %v1306 = load i64, ptr %slot39, align 8
  store i64 %v1306, ptr %slot160, align 8
  %v1307 = load i64, ptr %slot160, align 8
  %v1308 = load i64, ptr %slot157, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1307, i64 %v1308) nomerge, !dbg !124
  br label %bb_rcslotdone173
bb_rcslotowner173:
  %v1309 = load i64, ptr %slot39, align 8
  store i64 %v1309, ptr %slot161, align 8
  %v1310 = load i64, ptr %slot161, align 8
  %v1311 = load i64, ptr %slot157, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1310, i64 %v1311) nomerge, !dbg !124
  br label %bb_rcslotdone173
bb_rcslotdone173:
  br label %bb_i68
bb_rcarmnext170:
  %v1312 = load i64, ptr %slot99, align 8
  %cmp1313 = icmp eq i64 %v1312, 7
  %cv1314 = zext i1 %cmp1313 to i64
  store i64 %cv1314, ptr %slot162, align 8
  %v1315 = load i64, ptr %slot162, align 8
  %cond1316 = icmp ne i64 %v1315, 0
  br i1 %cond1316, label %bb_rcarm180, label %bb_rcarmnext180
bb_rcarm180:
  %v1317 = load i64, ptr %slot10, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  %ld1319 = load i32, ptr %p1318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1319, ptr %slot163, align 8
  %v1320 = load i32, ptr %slot163, align 8
  %cv1321 = zext i32 %v1320 to i64
  %cond1322 = icmp ne i64 %cv1321, 0
  br i1 %cond1322, label %bb_rcslotdrop183, label %bb_rcslotdone183
bb_rcslotdrop183:
  %v1323 = load i64, ptr %slot10, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  store i32 0, ptr %p1324, align 4, !alias.scope !3, !noalias !4
  %v1325 = load i64, ptr %slot15, align 8
  store i64 %v1325, ptr %slot164, align 8
  %v1326 = load i64, ptr %slot11, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  %ld1328 = load i32, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1328, ptr %slot165, align 8
  %v1329 = load i32, ptr %slot165, align 8
  %op1330 = and i32 %v1329, 28
  store i32 %op1330, ptr %slot166, align 8
  %v1331 = load i32, ptr %slot166, align 8
  %cv1332 = zext i32 %v1331 to i64
  %cond1333 = icmp ne i64 %cv1332, 0
  br i1 %cond1333, label %bb_rcslotrole183, label %bb_rcslotowner183
bb_rcslotrole183:
  %v1334 = load i64, ptr %slot39, align 8
  store i64 %v1334, ptr %slot167, align 8
  %v1335 = load i64, ptr %slot167, align 8
  %v1336 = load i64, ptr %slot164, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1335, i64 %v1336) nomerge, !dbg !124
  br label %bb_rcslotdone183
bb_rcslotowner183:
  %v1337 = load i64, ptr %slot39, align 8
  store i64 %v1337, ptr %slot168, align 8
  %v1338 = load i64, ptr %slot168, align 8
  %v1339 = load i64, ptr %slot164, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1338, i64 %v1339) nomerge, !dbg !124
  br label %bb_rcslotdone183
bb_rcslotdone183:
  br label %bb_i69
bb_rcarmnext180:
  %v1340 = load i64, ptr %slot99, align 8
  %cmp1341 = icmp eq i64 %v1340, 8
  %cv1342 = zext i1 %cmp1341 to i64
  store i64 %cv1342, ptr %slot169, align 8
  %v1343 = load i64, ptr %slot169, align 8
  %cond1344 = icmp ne i64 %v1343, 0
  br i1 %cond1344, label %bb_rcarm190, label %bb_rcarmnext190
bb_rcarm190:
  %v1345 = load i64, ptr %slot10, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i32, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1347, ptr %slot170, align 8
  %v1348 = load i32, ptr %slot170, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcslotdrop193, label %bb_rcslotdone193
bb_rcslotdrop193:
  %v1351 = load i64, ptr %slot10, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i32 0, ptr %p1352, align 4, !alias.scope !3, !noalias !4
  %v1353 = load i64, ptr %slot15, align 8
  store i64 %v1353, ptr %slot171, align 8
  %v1354 = load i64, ptr %slot11, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  %ld1356 = load i32, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1356, ptr %slot172, align 8
  %v1357 = load i32, ptr %slot172, align 8
  %op1358 = and i32 %v1357, 28
  store i32 %op1358, ptr %slot173, align 8
  %v1359 = load i32, ptr %slot173, align 8
  %cv1360 = zext i32 %v1359 to i64
  %cond1361 = icmp ne i64 %cv1360, 0
  br i1 %cond1361, label %bb_rcslotrole193, label %bb_rcslotowner193
bb_rcslotrole193:
  %v1362 = load i64, ptr %slot39, align 8
  store i64 %v1362, ptr %slot174, align 8
  %v1363 = load i64, ptr %slot174, align 8
  %v1364 = load i64, ptr %slot171, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1363, i64 %v1364) nomerge, !dbg !124
  br label %bb_rcslotdone193
bb_rcslotowner193:
  %v1365 = load i64, ptr %slot39, align 8
  store i64 %v1365, ptr %slot175, align 8
  %v1366 = load i64, ptr %slot175, align 8
  %v1367 = load i64, ptr %slot171, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1366, i64 %v1367) nomerge, !dbg !124
  br label %bb_rcslotdone193
bb_rcslotdone193:
  br label %bb_i70
bb_rcarmnext190:
  br label %bb_failure
bb_i18:
  %v1368 = load i64, ptr %slot22, align 8
  %v1369 = load i64, ptr %slot28, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  store i64 %v1368, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot6, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  %ld1373 = load i32, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1373, ptr %slot176, align 8
  %v1374 = load i64, ptr %slot7, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  %ld1376 = load i32, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1376, ptr %slot177, align 8
  %v1377 = load i32, ptr %slot177, align 8
  %op1378 = and i32 %v1377, 24
  store i32 %op1378, ptr %slot177, align 8
  %v1379 = load i32, ptr %slot177, align 8
  %cmp1380 = icmp eq i32 %v1379, 0
  %cv1381 = zext i1 %cmp1380 to i32
  store i32 %cv1381, ptr %slot178, align 8
  %v1382 = load i32, ptr %slot176, align 8
  %v1383 = load i32, ptr %slot178, align 8
  %op1384 = and i32 %v1382, %v1383
  store i32 %op1384, ptr %slot179, align 8
  %v1385 = load i32, ptr %slot179, align 8
  %cv1386 = zext i32 %v1385 to i64
  %cond1387 = icmp ne i64 %cv1386, 0
  br i1 %cond1387, label %bb_rcselfkept206, label %bb_rcselfstore206
bb_rcselfstore206:
  %v1388 = load i64, ptr %slot28, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i64, ptr %p1389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1390, ptr %slot180, align 8
  %v1391 = load i64, ptr %slot10, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i32, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1393, ptr %slot181, align 8
  %v1394 = load i64, ptr %slot11, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %ld1396 = load i32, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1396, ptr %slot182, align 8
  %v1397 = load i32, ptr %slot182, align 8
  %op1398 = and i32 %v1397, 24
  store i32 %op1398, ptr %slot182, align 8
  %v1399 = load i32, ptr %slot182, align 8
  %cmp1400 = icmp eq i32 %v1399, 0
  %cv1401 = zext i1 %cmp1400 to i32
  store i32 %cv1401, ptr %slot183, align 8
  %v1402 = load i32, ptr %slot181, align 8
  %v1403 = load i32, ptr %slot183, align 8
  %op1404 = and i32 %v1402, %v1403
  store i32 %op1404, ptr %slot184, align 8
  %v1405 = load i32, ptr %slot184, align 8
  %cv1406 = zext i32 %v1405 to i64
  %cond1407 = icmp ne i64 %cv1406, 0
  br i1 %cond1407, label %bb_rctake208, label %bb_rccopy208
bb_rctake208:
  %v1408 = load i64, ptr %slot17, align 8
  store i64 %v1408, ptr %slot185, align 8
  %v1409 = load i64, ptr %slot40, align 8
  store i64 %v1409, ptr %slot186, align 8
  %v1410 = load i64, ptr %slot180, align 8
  %v1411 = load i64, ptr %slot185, align 8
  %op1412 = sub i64 %v1410, %v1411
  store i64 %op1412, ptr %slot187, align 8
  %v1413 = load i64, ptr %slot185, align 8
  %v1414 = load i64, ptr %slot180, align 8
  %op1415 = sub i64 %v1413, %v1414
  store i64 %op1415, ptr %slot188, align 8
  %v1416 = load i64, ptr %slot187, align 8
  %cmp1417 = icmp ult i64 %v1416, 16
  %cv1418 = zext i1 %cmp1417 to i32
  store i32 %cv1418, ptr %slot189, align 8
  %v1419 = load i64, ptr %slot188, align 8
  %cmp1420 = icmp ult i64 %v1419, 16
  %cv1421 = zext i1 %cmp1420 to i32
  store i32 %cv1421, ptr %slot190, align 8
  %v1422 = load i32, ptr %slot189, align 8
  %v1423 = load i32, ptr %slot190, align 8
  %op1424 = or i32 %v1422, %v1423
  store i32 %op1424, ptr %slot191, align 8
  %v1425 = load i32, ptr %slot191, align 8
  %cv1426 = zext i32 %v1425 to i64
  %cond1427 = icmp ne i64 %cv1426, 0
  br i1 %cond1427, label %bb_rcmoveslow217, label %bb_rcmovecheck217
bb_rcmovecheck217:
  %v1428 = load i64, ptr %slot180, align 8
  %op1429 = add i64 %v1428, 0
  store i64 %op1429, ptr %slot192, align 8
  %v1430 = load i64, ptr %slot192, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i64, ptr %p1431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1432, ptr %slot193, align 8
  %v1433 = load i64, ptr %slot193, align 8
  %cmp1434 = icmp ne i64 %v1433, 0
  %cv1435 = zext i1 %cmp1434 to i32
  store i32 %cv1435, ptr %slot194, align 8
  %v1436 = load i32, ptr %slot194, align 8
  %cv1437 = zext i32 %v1436 to i64
  %cond1438 = icmp ne i64 %cv1437, 0
  br i1 %cond1438, label %bb_rcmoveheader225, label %bb_rcmovenext225
bb_rcmoveheader225:
  %v1439 = load i64, ptr %slot193, align 8
  %op1440 = sub i64 %v1439, 16
  store i64 %op1440, ptr %slot195, align 8
  %v1441 = load i64, ptr %slot193, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  %rgep1443 = getelementptr i8, ptr %p1442, i64 -16
  %ld1444 = load i64, ptr %rgep1443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1444, ptr %slot196, align 8
  %v1445 = load i64, ptr %slot196, align 8
  %op1446 = and i64 %v1445, 5764607523034234881
  store i64 %op1446, ptr %slot197, align 8
  %v1447 = load i64, ptr %slot197, align 8
  %cmp1448 = icmp ne i64 %v1447, 0
  %cv1449 = zext i1 %cmp1448 to i32
  store i32 %cv1449, ptr %slot198, align 8
  %v1450 = load i32, ptr %slot198, align 8
  %cv1451 = zext i32 %v1450 to i64
  %cond1452 = icmp ne i64 %cv1451, 0
  br i1 %cond1452, label %bb_rcmoveslow217, label %bb_rcmovenext225
bb_rcmovenext225:
  %v1453 = load i64, ptr %slot180, align 8
  %v1454 = load i64, ptr %slot185, align 8
  %p1455 = inttoptr i64 %v1453 to ptr
  %p1456 = inttoptr i64 %v1454 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1456, ptr %p1455, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1457 = load i64, ptr %slot180, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i64 0, ptr %p1458, align 8, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot180, align 8
  %op1460 = add i64 %v1459, 8
  store i64 %op1460, ptr %slot199, align 8
  %v1461 = load i64, ptr %slot199, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  store i64 0, ptr %p1462, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved217
bb_rcmoveslow217:
  %v1463 = load i64, ptr %slot39, align 8
  %v1464 = load i64, ptr %slot185, align 8
  %v1465 = load i64, ptr %slot180, align 8
  %v1466 = load i64, ptr %slot186, align 8
  %cv1467 = trunc i64 %v1466 to i32
  %call1468 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64 %v1463, i64 %v1464, i64 %v1465, i32 %cv1467) nomerge, !dbg !126
  store i32 %call1468, ptr %slot200, align 8
  %v1469 = load i32, ptr %slot200, align 8
  %cv1470 = zext i32 %v1469 to i64
  %cond1471 = icmp ne i64 %cv1470, 0
  br i1 %cond1471, label %bb_rcsuccess233, label %bb_rcfailure233
bb_rcfailure233:
  %v1472 = load i64, ptr %slot39, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  %call1474 = call i32 @myl_rc_take_failure(ptr %p1473) nomerge, !dbg !126
  store i32 %call1474, ptr %slot201, align 8
  %v1475 = load i64, ptr %slot1, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %v1477 = load i32, ptr %slot201, align 8
  %call1478 = call i32 @myl_qbe_rc_status(ptr %p1476, i32 %v1477) nomerge, !dbg !126
  store i32 %call1478, ptr %slot202, align 8
  br label %bb_failure
bb_rcsuccess233:
  br label %bb_rcmoved217
bb_rcmoved217:
  %v1479 = load i64, ptr %slot10, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i32 0, ptr %p1480, align 4, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot13, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 2, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot12, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i32 1, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared208
bb_rccopy208:
  %v1485 = load i64, ptr %slot17, align 8
  store i64 %v1485, ptr %slot203, align 8
  %v1486 = load i64, ptr %slot40, align 8
  store i64 %v1486, ptr %slot204, align 8
  %v1487 = load i64, ptr %slot39, align 8
  %v1488 = load i64, ptr %slot203, align 8
  %v1489 = load i64, ptr %slot180, align 8
  %v1490 = load i64, ptr %slot204, align 8
  %cv1491 = trunc i64 %v1490 to i32
  %call1492 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64 %v1487, i64 %v1488, i64 %v1489, i32 %cv1491) nomerge, !dbg !126
  store i32 %call1492, ptr %slot205, align 8
  %v1493 = load i32, ptr %slot205, align 8
  %cv1494 = zext i32 %v1493 to i64
  %cond1495 = icmp ne i64 %cv1494, 0
  br i1 %cond1495, label %bb_rcsuccess242, label %bb_rcfailure242
bb_rcfailure242:
  %v1496 = load i64, ptr %slot39, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %call1498 = call i32 @myl_rc_take_failure(ptr %p1497) nomerge, !dbg !126
  store i32 %call1498, ptr %slot206, align 8
  %v1499 = load i64, ptr %slot1, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %v1501 = load i32, ptr %slot206, align 8
  %call1502 = call i32 @myl_qbe_rc_status(ptr %p1500, i32 %v1501) nomerge, !dbg !126
  store i32 %call1502, ptr %slot207, align 8
  br label %bb_failure
bb_rcsuccess242:
  %v1503 = load i64, ptr %slot13, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i32 2, ptr %p1504, align 4, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot12, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i32 1, ptr %p1506, align 4, !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot10, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  %ld1509 = load i32, ptr %p1508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1509, ptr %slot208, align 8
  %v1510 = load i32, ptr %slot208, align 8
  %cv1511 = zext i32 %v1510 to i64
  %cond1512 = icmp ne i64 %cv1511, 0
  br i1 %cond1512, label %bb_rcslotdrop249, label %bb_rcslotdone249
bb_rcslotdrop249:
  %v1513 = load i64, ptr %slot10, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  store i32 0, ptr %p1514, align 4, !alias.scope !3, !noalias !4
  %v1515 = load i64, ptr %slot15, align 8
  store i64 %v1515, ptr %slot209, align 8
  %v1516 = load i64, ptr %slot11, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %ld1518 = load i32, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1518, ptr %slot210, align 8
  %v1519 = load i32, ptr %slot210, align 8
  %op1520 = and i32 %v1519, 28
  store i32 %op1520, ptr %slot211, align 8
  %v1521 = load i32, ptr %slot211, align 8
  %cv1522 = zext i32 %v1521 to i64
  %cond1523 = icmp ne i64 %cv1522, 0
  br i1 %cond1523, label %bb_rcslotrole249, label %bb_rcslotowner249
bb_rcslotrole249:
  %v1524 = load i64, ptr %slot39, align 8
  store i64 %v1524, ptr %slot212, align 8
  %v1525 = load i64, ptr %slot212, align 8
  %v1526 = load i64, ptr %slot209, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1525, i64 %v1526) nomerge, !dbg !126
  br label %bb_rcslotdone249
bb_rcslotowner249:
  %v1527 = load i64, ptr %slot209, align 8
  %p1529 = inttoptr i64 %v1527 to ptr
  %gep1530 = getelementptr i8, ptr %p1529, i64 0
  %op1528 = ptrtoint ptr %gep1530 to i64
  store i64 %op1528, ptr %slot213, align 8
  %v1531 = load i64, ptr %slot39, align 8
  store i64 %v1531, ptr %slot214, align 8
  %v1532 = load i64, ptr %slot213, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %ld1534 = load i64, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1534, ptr %slot215, align 8
  %v1535 = load i64, ptr %slot215, align 8
  %cmp1536 = icmp ne i64 %v1535, 0
  %cv1537 = zext i1 %cmp1536 to i32
  store i32 %cv1537, ptr %slot216, align 8
  %v1538 = load i32, ptr %slot216, align 8
  %cv1539 = zext i32 %v1538 to i64
  %cond1540 = icmp ne i64 %cv1539, 0
  br i1 %cond1540, label %bb_rcgnn267, label %bb_rcgdone267
bb_rcgnn267:
  %v1541 = load i64, ptr %slot215, align 8
  %op1542 = sub i64 %v1541, 16
  store i64 %op1542, ptr %slot217, align 8
  %v1543 = load i64, ptr %slot215, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %rgep1545 = getelementptr i8, ptr %p1544, i64 -16
  %ld1546 = load i64, ptr %rgep1545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1546, ptr %slot218, align 8
  %v1547 = load i64, ptr %slot218, align 8
  %op1548 = and i64 %v1547, 4611686018427387906
  store i64 %op1548, ptr %slot219, align 8
  %v1549 = load i64, ptr %slot219, align 8
  %cmp1550 = icmp ne i64 %v1549, 0
  %cv1551 = zext i1 %cmp1550 to i32
  store i32 %cv1551, ptr %slot220, align 8
  %v1552 = load i32, ptr %slot220, align 8
  %cv1553 = zext i32 %v1552 to i64
  %cond1554 = icmp ne i64 %cv1553, 0
  br i1 %cond1554, label %bb_rcgclear267, label %bb_rcgcounted267
bb_rcgcounted267:
  %v1555 = load i64, ptr %slot215, align 8
  %op1556 = sub i64 %v1555, 32
  store i64 %op1556, ptr %slot221, align 8
  %v1557 = load i64, ptr %slot215, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %rgep1559 = getelementptr i8, ptr %p1558, i64 -32
  %ld1560 = load i64, ptr %rgep1559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1560, ptr %slot222, align 8
  %v1561 = load i64, ptr %slot222, align 8
  %op1562 = sub i64 %v1561, 1
  store i64 %op1562, ptr %slot223, align 8
  %v1563 = load i64, ptr %slot223, align 8
  %cmp1564 = icmp eq i64 %v1563, 0
  %cv1565 = zext i1 %cmp1564 to i32
  store i32 %cv1565, ptr %slot224, align 8
  %v1566 = load i32, ptr %slot224, align 8
  %cv1567 = zext i32 %v1566 to i64
  %cond1568 = icmp ne i64 %cv1567, 0
  br i1 %cond1568, label %bb_rcglast267, label %bb_rcgdec267
bb_rcglast267:
  %v1569 = load i64, ptr %slot215, align 8
  %op1570 = sub i64 %v1569, 24
  store i64 %op1570, ptr %slot225, align 8
  %v1571 = load i64, ptr %slot215, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  %rgep1573 = getelementptr i8, ptr %p1572, i64 -24
  %ld1574 = load i64, ptr %rgep1573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1574, ptr %slot226, align 8
  %v1575 = load i64, ptr %slot226, align 8
  %cmp1576 = icmp ne i64 %v1575, 0
  %cv1577 = zext i1 %cmp1576 to i32
  store i32 %cv1577, ptr %slot227, align 8
  %v1578 = load i32, ptr %slot227, align 8
  %cv1579 = zext i32 %v1578 to i64
  %cond1580 = icmp ne i64 %cv1579, 0
  br i1 %cond1580, label %bb_rcgdec267, label %bb_rcgslow267
bb_rcgslow267:
  %v1581 = load i64, ptr %slot214, align 8
  %v1582 = load i64, ptr %slot213, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1581, i64 %v1582) nomerge, !dbg !126
  br label %bb_rcgdone267
bb_rcgdec267:
  %v1583 = load i64, ptr %slot223, align 8
  %v1584 = load i64, ptr %slot215, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %rgep1586 = getelementptr i8, ptr %p1585, i64 -32
  store i64 %v1583, ptr %rgep1586, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear267
bb_rcgclear267:
  %v1587 = load i64, ptr %slot213, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  store i64 0, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone267
bb_rcgdone267:
  %v1589 = load i64, ptr %slot209, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i64 0, ptr %p1590, align 8, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot209, align 8
  %p1593 = inttoptr i64 %v1591 to ptr
  %gep1594 = getelementptr i8, ptr %p1593, i64 8
  %op1592 = ptrtoint ptr %gep1594 to i64
  store i64 %op1592, ptr %slot228, align 8
  %v1595 = load i64, ptr %slot228, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  store i64 0, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone249
bb_rcslotdone249:
  br label %bb_rcprepared208
bb_rcprepared208:
  %v1597 = load i64, ptr %slot6, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %ld1599 = load i32, ptr %p1598, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1599, ptr %slot229, align 8
  %v1600 = load i32, ptr %slot229, align 8
  %cv1601 = zext i32 %v1600 to i64
  %cond1602 = icmp ne i64 %cv1601, 0
  br i1 %cond1602, label %bb_rcslotdrop275, label %bb_rcslotdone275
bb_rcslotdrop275:
  %v1603 = load i64, ptr %slot6, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  store i32 0, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  %v1605 = load i64, ptr %slot22, align 8
  store i64 %v1605, ptr %slot230, align 8
  %v1606 = load i64, ptr %slot7, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i32, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1608, ptr %slot231, align 8
  %v1609 = load i32, ptr %slot231, align 8
  %op1610 = and i32 %v1609, 28
  store i32 %op1610, ptr %slot232, align 8
  %v1611 = load i32, ptr %slot232, align 8
  %cv1612 = zext i32 %v1611 to i64
  %cond1613 = icmp ne i64 %cv1612, 0
  br i1 %cond1613, label %bb_rcslotrole275, label %bb_rcslotowner275
bb_rcslotrole275:
  %v1614 = load i64, ptr %slot39, align 8
  store i64 %v1614, ptr %slot233, align 8
  %v1615 = load i64, ptr %slot233, align 8
  %v1616 = load i64, ptr %slot230, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1615, i64 %v1616) nomerge, !dbg !126
  br label %bb_rcslotdone275
bb_rcslotowner275:
  %v1617 = load i64, ptr %slot230, align 8
  %p1619 = inttoptr i64 %v1617 to ptr
  %gep1620 = getelementptr i8, ptr %p1619, i64 0
  %op1618 = ptrtoint ptr %gep1620 to i64
  store i64 %op1618, ptr %slot234, align 8
  %v1621 = load i64, ptr %slot39, align 8
  store i64 %v1621, ptr %slot235, align 8
  %v1622 = load i64, ptr %slot234, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  %ld1624 = load i64, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1624, ptr %slot236, align 8
  %v1625 = load i64, ptr %slot236, align 8
  %cmp1626 = icmp ne i64 %v1625, 0
  %cv1627 = zext i1 %cmp1626 to i32
  store i32 %cv1627, ptr %slot237, align 8
  %v1628 = load i32, ptr %slot237, align 8
  %cv1629 = zext i32 %v1628 to i64
  %cond1630 = icmp ne i64 %cv1629, 0
  br i1 %cond1630, label %bb_rcgnn293, label %bb_rcgdone293
bb_rcgnn293:
  %v1631 = load i64, ptr %slot236, align 8
  %op1632 = sub i64 %v1631, 16
  store i64 %op1632, ptr %slot238, align 8
  %v1633 = load i64, ptr %slot236, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %rgep1635 = getelementptr i8, ptr %p1634, i64 -16
  %ld1636 = load i64, ptr %rgep1635, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1636, ptr %slot239, align 8
  %v1637 = load i64, ptr %slot239, align 8
  %op1638 = and i64 %v1637, 4611686018427387906
  store i64 %op1638, ptr %slot240, align 8
  %v1639 = load i64, ptr %slot240, align 8
  %cmp1640 = icmp ne i64 %v1639, 0
  %cv1641 = zext i1 %cmp1640 to i32
  store i32 %cv1641, ptr %slot241, align 8
  %v1642 = load i32, ptr %slot241, align 8
  %cv1643 = zext i32 %v1642 to i64
  %cond1644 = icmp ne i64 %cv1643, 0
  br i1 %cond1644, label %bb_rcgclear293, label %bb_rcgcounted293
bb_rcgcounted293:
  %v1645 = load i64, ptr %slot236, align 8
  %op1646 = sub i64 %v1645, 32
  store i64 %op1646, ptr %slot242, align 8
  %v1647 = load i64, ptr %slot236, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %rgep1649 = getelementptr i8, ptr %p1648, i64 -32
  %ld1650 = load i64, ptr %rgep1649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1650, ptr %slot243, align 8
  %v1651 = load i64, ptr %slot243, align 8
  %op1652 = sub i64 %v1651, 1
  store i64 %op1652, ptr %slot244, align 8
  %v1653 = load i64, ptr %slot244, align 8
  %cmp1654 = icmp eq i64 %v1653, 0
  %cv1655 = zext i1 %cmp1654 to i32
  store i32 %cv1655, ptr %slot245, align 8
  %v1656 = load i32, ptr %slot245, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcglast293, label %bb_rcgdec293
bb_rcglast293:
  %v1659 = load i64, ptr %slot236, align 8
  %op1660 = sub i64 %v1659, 24
  store i64 %op1660, ptr %slot246, align 8
  %v1661 = load i64, ptr %slot236, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %rgep1663 = getelementptr i8, ptr %p1662, i64 -24
  %ld1664 = load i64, ptr %rgep1663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1664, ptr %slot247, align 8
  %v1665 = load i64, ptr %slot247, align 8
  %cmp1666 = icmp ne i64 %v1665, 0
  %cv1667 = zext i1 %cmp1666 to i32
  store i32 %cv1667, ptr %slot248, align 8
  %v1668 = load i32, ptr %slot248, align 8
  %cv1669 = zext i32 %v1668 to i64
  %cond1670 = icmp ne i64 %cv1669, 0
  br i1 %cond1670, label %bb_rcgdec293, label %bb_rcgslow293
bb_rcgslow293:
  %v1671 = load i64, ptr %slot235, align 8
  %v1672 = load i64, ptr %slot234, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1671, i64 %v1672) nomerge, !dbg !126
  br label %bb_rcgdone293
bb_rcgdec293:
  %v1673 = load i64, ptr %slot244, align 8
  %v1674 = load i64, ptr %slot236, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  %rgep1676 = getelementptr i8, ptr %p1675, i64 -32
  store i64 %v1673, ptr %rgep1676, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear293
bb_rcgclear293:
  %v1677 = load i64, ptr %slot234, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i64 0, ptr %p1678, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone293
bb_rcgdone293:
  %v1679 = load i64, ptr %slot230, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  store i64 0, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  %v1681 = load i64, ptr %slot230, align 8
  %p1683 = inttoptr i64 %v1681 to ptr
  %gep1684 = getelementptr i8, ptr %p1683, i64 8
  %op1682 = ptrtoint ptr %gep1684 to i64
  store i64 %op1682, ptr %slot249, align 8
  %v1685 = load i64, ptr %slot249, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i64 0, ptr %p1686, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone275
bb_rcslotdone275:
  %v1687 = load i64, ptr %slot22, align 8
  store i64 %v1687, ptr %slot250, align 8
  %v1688 = load i64, ptr %slot17, align 8
  store i64 %v1688, ptr %slot251, align 8
  %v1689 = load i64, ptr %slot251, align 8
  %v1690 = load i64, ptr %slot250, align 8
  %p1691 = inttoptr i64 %v1689 to ptr
  %p1692 = inttoptr i64 %v1690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1692, ptr %p1691, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot12, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot7, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 2, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot13, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  %ld1699 = load i32, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1699, ptr %slot252, align 8
  %v1700 = load i32, ptr %slot252, align 8
  %v1701 = load i64, ptr %slot7, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 %v1700, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot6, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 1, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept206
bb_rcselfkept206:
  %v1705 = load i64, ptr %slot22, align 8
  %v1706 = load i64, ptr %slot28, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  store i64 %v1705, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  %v1708 = load i64, ptr %slot28, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %ld1710 = load i64, ptr %p1709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1710, ptr %slot253, align 8
  %v1711 = load i64, ptr %slot253, align 8
  %op1712 = add i64 %v1711, 0
  store i64 %op1712, ptr %slot254, align 8
  %v1713 = load i64, ptr %slot254, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  %ld1715 = load i64, ptr %p1714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1715, ptr %slot255, align 8
  %v1716 = load i64, ptr %slot255, align 8
  %v1717 = load i64, ptr %slot28, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i64 %v1716, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot28, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %ld1721 = load i64, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1721, ptr %slot256, align 8
  %v1722 = load i64, ptr %slot256, align 8
  %v1723 = load i64, ptr %slot16, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i64 %v1722, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot16, align 8
  store i64 %v1725, ptr %slot257, align 8
  %v1726 = load i64, ptr %slot17, align 8
  store i64 %v1726, ptr %slot258, align 8
  %v1727 = load i64, ptr %slot257, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %ld1729 = load i64, ptr %p1728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1729, ptr %slot259, align 8
  %v1730 = load i64, ptr %slot259, align 8
  %cmp1731 = icmp ne i64 %v1730, 0
  %cv1732 = zext i1 %cmp1731 to i32
  store i32 %cv1732, ptr %slot260, align 8
  %v1733 = load i32, ptr %slot260, align 8
  %cv1734 = zext i32 %v1733 to i64
  %cond1735 = icmp ne i64 %cv1734, 0
  br i1 %cond1735, label %bb_rcgnn312, label %bb_rcgstore312
bb_rcgnn312:
  %v1736 = load i64, ptr %slot259, align 8
  %op1737 = sub i64 %v1736, 16
  store i64 %op1737, ptr %slot261, align 8
  %v1738 = load i64, ptr %slot259, align 8
  %p1739 = inttoptr i64 %v1738 to ptr
  %rgep1740 = getelementptr i8, ptr %p1739, i64 -16
  %ld1741 = load i64, ptr %rgep1740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1741, ptr %slot262, align 8
  %v1742 = load i64, ptr %slot262, align 8
  %op1743 = and i64 %v1742, 4611686018427387906
  store i64 %op1743, ptr %slot263, align 8
  %v1744 = load i64, ptr %slot263, align 8
  %cmp1745 = icmp ne i64 %v1744, 0
  %cv1746 = zext i1 %cmp1745 to i32
  store i32 %cv1746, ptr %slot264, align 8
  %v1747 = load i32, ptr %slot264, align 8
  %cv1748 = zext i32 %v1747 to i64
  %cond1749 = icmp ne i64 %cv1748, 0
  br i1 %cond1749, label %bb_rcgstore312, label %bb_rcginc312
bb_rcginc312:
  %v1750 = load i64, ptr %slot259, align 8
  %op1751 = sub i64 %v1750, 24
  store i64 %op1751, ptr %slot265, align 8
  %v1752 = load i64, ptr %slot259, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  %rgep1754 = getelementptr i8, ptr %p1753, i64 -24
  %ld1755 = load i64, ptr %rgep1754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1755, ptr %slot266, align 8
  %v1756 = load i64, ptr %slot266, align 8
  %op1757 = add i64 %v1756, 1
  store i64 %op1757, ptr %slot267, align 8
  %v1758 = load i64, ptr %slot267, align 8
  %cmp1759 = icmp eq i64 %v1758, 0
  %cv1760 = zext i1 %cmp1759 to i32
  store i32 %cv1760, ptr %slot268, align 8
  %v1761 = load i32, ptr %slot268, align 8
  %cv1762 = zext i32 %v1761 to i64
  %cond1763 = icmp ne i64 %cv1762, 0
  br i1 %cond1763, label %bb_rcglimit312, label %bb_rcgcapacity312
bb_rcglimit312:
  %v1764 = load i64, ptr %slot1, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %call1766 = call i32 @myl_qbe_rc_status(ptr %p1765, i32 2) nomerge, !dbg !128
  store i32 %call1766, ptr %slot269, align 8
  br label %bb_failure
bb_rcgcapacity312:
  %v1767 = load i64, ptr %slot267, align 8
  %v1768 = load i64, ptr %slot259, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %rgep1770 = getelementptr i8, ptr %p1769, i64 -24
  store i64 %v1767, ptr %rgep1770, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore312
bb_rcgstore312:
  %v1771 = load i64, ptr %slot259, align 8
  %v1772 = load i64, ptr %slot258, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i64 %v1771, ptr %p1773, align 8, !alias.scope !3, !noalias !4
  %v1774 = load i64, ptr %slot13, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  store i32 2, ptr %p1775, align 4, !alias.scope !3, !noalias !4
  %v1776 = load i64, ptr %slot13, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  store i32 16, ptr %p1777, align 4, !alias.scope !3, !noalias !4
  %v1778 = load i64, ptr %slot12, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i32 1, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot10, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i32, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1782, ptr %slot270, align 8
  %v1783 = load i32, ptr %slot270, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rcslotdrop328, label %bb_rcslotdone328
bb_rcslotdrop328:
  %v1786 = load i64, ptr %slot10, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  store i32 0, ptr %p1787, align 4, !alias.scope !3, !noalias !4
  %v1788 = load i64, ptr %slot15, align 8
  store i64 %v1788, ptr %slot271, align 8
  %v1789 = load i64, ptr %slot11, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i32, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1791, ptr %slot272, align 8
  %v1792 = load i32, ptr %slot272, align 8
  %op1793 = and i32 %v1792, 28
  store i32 %op1793, ptr %slot273, align 8
  %v1794 = load i32, ptr %slot273, align 8
  %cv1795 = zext i32 %v1794 to i64
  %cond1796 = icmp ne i64 %cv1795, 0
  br i1 %cond1796, label %bb_rcslotrole328, label %bb_rcslotowner328
bb_rcslotrole328:
  %v1797 = load i64, ptr %slot39, align 8
  store i64 %v1797, ptr %slot274, align 8
  %v1798 = load i64, ptr %slot274, align 8
  %v1799 = load i64, ptr %slot271, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1798, i64 %v1799) nomerge, !dbg !128
  br label %bb_rcslotdone328
bb_rcslotowner328:
  %v1800 = load i64, ptr %slot39, align 8
  store i64 %v1800, ptr %slot275, align 8
  %v1801 = load i64, ptr %slot275, align 8
  %v1802 = load i64, ptr %slot271, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v1801, i64 %v1802) nomerge, !dbg !128
  br label %bb_rcslotdone328
bb_rcslotdone328:
  %v1803 = load i64, ptr %slot15, align 8
  store i64 %v1803, ptr %slot276, align 8
  %v1804 = load i64, ptr %slot17, align 8
  store i64 %v1804, ptr %slot277, align 8
  %v1805 = load i64, ptr %slot277, align 8
  %v1806 = load i64, ptr %slot276, align 8
  %p1807 = inttoptr i64 %v1805 to ptr
  %p1808 = inttoptr i64 %v1806 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1808, ptr %p1807, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot11, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 2, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot13, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i32, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1813, ptr %slot278, align 8
  %v1814 = load i32, ptr %slot278, align 8
  %v1815 = load i64, ptr %slot11, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 %v1814, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot12, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot10, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i32 1, ptr %p1820, align 4, !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot276, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  %ld1823 = load i64, ptr %p1822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1823, ptr %slot279, align 8
  %v1824 = load i64, ptr %slot279, align 8
  %v1825 = load i64, ptr %slot28, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i64 %v1824, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot28, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i64, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1829, ptr %slot280, align 8
  %v1830 = load i64, ptr %slot17, align 8
  store i64 %v1830, ptr %slot281, align 8
  %v1831 = load i64, ptr %slot280, align 8
  %cmp1832 = icmp ne i64 %v1831, 0
  %cv1833 = zext i1 %cmp1832 to i32
  store i32 %cv1833, ptr %slot282, align 8
  %v1834 = load i32, ptr %slot282, align 8
  %cv1835 = zext i32 %v1834 to i64
  %cond1836 = icmp ne i64 %cv1835, 0
  br i1 %cond1836, label %bb_rcgnn348, label %bb_rcgstore348
bb_rcgnn348:
  %v1837 = load i64, ptr %slot280, align 8
  %op1838 = sub i64 %v1837, 16
  store i64 %op1838, ptr %slot283, align 8
  %v1839 = load i64, ptr %slot280, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  %rgep1841 = getelementptr i8, ptr %p1840, i64 -16
  %ld1842 = load i64, ptr %rgep1841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1842, ptr %slot284, align 8
  %v1843 = load i64, ptr %slot284, align 8
  %op1844 = and i64 %v1843, 4611686018427387906
  store i64 %op1844, ptr %slot285, align 8
  %v1845 = load i64, ptr %slot285, align 8
  %cmp1846 = icmp ne i64 %v1845, 0
  %cv1847 = zext i1 %cmp1846 to i32
  store i32 %cv1847, ptr %slot286, align 8
  %v1848 = load i32, ptr %slot286, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcgstore348, label %bb_rcginc348
bb_rcginc348:
  %v1851 = load i64, ptr %slot280, align 8
  %op1852 = sub i64 %v1851, 24
  store i64 %op1852, ptr %slot287, align 8
  %v1853 = load i64, ptr %slot280, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  %rgep1855 = getelementptr i8, ptr %p1854, i64 -24
  %ld1856 = load i64, ptr %rgep1855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1856, ptr %slot288, align 8
  %v1857 = load i64, ptr %slot288, align 8
  %op1858 = add i64 %v1857, 1
  store i64 %op1858, ptr %slot289, align 8
  %v1859 = load i64, ptr %slot289, align 8
  %cmp1860 = icmp eq i64 %v1859, 0
  %cv1861 = zext i1 %cmp1860 to i32
  store i32 %cv1861, ptr %slot290, align 8
  %v1862 = load i32, ptr %slot290, align 8
  %cv1863 = zext i32 %v1862 to i64
  %cond1864 = icmp ne i64 %cv1863, 0
  br i1 %cond1864, label %bb_rcglimit348, label %bb_rcgcapacity348
bb_rcglimit348:
  %v1865 = load i64, ptr %slot1, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %call1867 = call i32 @myl_qbe_rc_status(ptr %p1866, i32 2) nomerge, !dbg !130
  store i32 %call1867, ptr %slot291, align 8
  br label %bb_failure
bb_rcgcapacity348:
  %v1868 = load i64, ptr %slot289, align 8
  %v1869 = load i64, ptr %slot280, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %rgep1871 = getelementptr i8, ptr %p1870, i64 -24
  store i64 %v1868, ptr %rgep1871, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore348
bb_rcgstore348:
  %v1872 = load i64, ptr %slot280, align 8
  %v1873 = load i64, ptr %slot281, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i64 %v1872, ptr %p1874, align 8, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot13, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  store i32 2, ptr %p1876, align 4, !alias.scope !3, !noalias !4
  %v1877 = load i64, ptr %slot13, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i32 8, ptr %p1878, align 4, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot12, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  store i32 1, ptr %p1880, align 4, !alias.scope !3, !noalias !4
  %v1881 = load i64, ptr %slot10, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  %ld1883 = load i32, ptr %p1882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1883, ptr %slot292, align 8
  %v1884 = load i32, ptr %slot292, align 8
  %cv1885 = zext i32 %v1884 to i64
  %cond1886 = icmp ne i64 %cv1885, 0
  br i1 %cond1886, label %bb_rcslotdrop364, label %bb_rcslotdone364
bb_rcslotdrop364:
  %v1887 = load i64, ptr %slot10, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i32 0, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot15, align 8
  store i64 %v1889, ptr %slot293, align 8
  %v1890 = load i64, ptr %slot11, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %ld1892 = load i32, ptr %p1891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1892, ptr %slot294, align 8
  %v1893 = load i32, ptr %slot294, align 8
  %op1894 = and i32 %v1893, 28
  store i32 %op1894, ptr %slot295, align 8
  %v1895 = load i32, ptr %slot295, align 8
  %cv1896 = zext i32 %v1895 to i64
  %cond1897 = icmp ne i64 %cv1896, 0
  br i1 %cond1897, label %bb_rcslotrole364, label %bb_rcslotowner364
bb_rcslotrole364:
  %v1898 = load i64, ptr %slot39, align 8
  store i64 %v1898, ptr %slot296, align 8
  %v1899 = load i64, ptr %slot293, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot297, align 8
  %v1902 = load i64, ptr %slot297, align 8
  %cmp1903 = icmp ne i64 %v1902, 0
  %cv1904 = zext i1 %cmp1903 to i32
  store i32 %cv1904, ptr %slot298, align 8
  %v1905 = load i32, ptr %slot298, align 8
  %cv1906 = zext i32 %v1905 to i64
  %cond1907 = icmp ne i64 %cv1906, 0
  br i1 %cond1907, label %bb_rcgnn380, label %bb_rcgdone380
bb_rcgnn380:
  %v1908 = load i64, ptr %slot297, align 8
  %op1909 = sub i64 %v1908, 16
  store i64 %op1909, ptr %slot299, align 8
  %v1910 = load i64, ptr %slot297, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %rgep1912 = getelementptr i8, ptr %p1911, i64 -16
  %ld1913 = load i64, ptr %rgep1912, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1913, ptr %slot300, align 8
  %v1914 = load i64, ptr %slot300, align 8
  %op1915 = and i64 %v1914, 4611686018427387906
  store i64 %op1915, ptr %slot301, align 8
  %v1916 = load i64, ptr %slot301, align 8
  %cmp1917 = icmp ne i64 %v1916, 0
  %cv1918 = zext i1 %cmp1917 to i32
  store i32 %cv1918, ptr %slot302, align 8
  %v1919 = load i32, ptr %slot302, align 8
  %cv1920 = zext i32 %v1919 to i64
  %cond1921 = icmp ne i64 %cv1920, 0
  br i1 %cond1921, label %bb_rcgclear380, label %bb_rcgcounted380
bb_rcgcounted380:
  %v1922 = load i64, ptr %slot297, align 8
  %op1923 = sub i64 %v1922, 24
  store i64 %op1923, ptr %slot303, align 8
  %v1924 = load i64, ptr %slot297, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %rgep1926 = getelementptr i8, ptr %p1925, i64 -24
  %ld1927 = load i64, ptr %rgep1926, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1927, ptr %slot304, align 8
  %v1928 = load i64, ptr %slot304, align 8
  %op1929 = sub i64 %v1928, 1
  store i64 %op1929, ptr %slot305, align 8
  %v1930 = load i64, ptr %slot305, align 8
  %cmp1931 = icmp eq i64 %v1930, 0
  %cv1932 = zext i1 %cmp1931 to i32
  store i32 %cv1932, ptr %slot306, align 8
  %v1933 = load i32, ptr %slot306, align 8
  %cv1934 = zext i32 %v1933 to i64
  %cond1935 = icmp ne i64 %cv1934, 0
  br i1 %cond1935, label %bb_rcglast380, label %bb_rcgdec380
bb_rcglast380:
  %v1936 = load i64, ptr %slot297, align 8
  %op1937 = sub i64 %v1936, 32
  store i64 %op1937, ptr %slot307, align 8
  %v1938 = load i64, ptr %slot297, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %rgep1940 = getelementptr i8, ptr %p1939, i64 -32
  %ld1941 = load i64, ptr %rgep1940, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1941, ptr %slot308, align 8
  %v1942 = load i64, ptr %slot308, align 8
  %cmp1943 = icmp ne i64 %v1942, 0
  %cv1944 = zext i1 %cmp1943 to i32
  store i32 %cv1944, ptr %slot309, align 8
  %v1945 = load i32, ptr %slot309, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcgdec380, label %bb_rcgslow380
bb_rcgslow380:
  %v1948 = load i64, ptr %slot296, align 8
  %v1949 = load i64, ptr %slot293, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1948, i64 %v1949) nomerge, !dbg !130
  br label %bb_rcgdone380
bb_rcgdec380:
  %v1950 = load i64, ptr %slot305, align 8
  %v1951 = load i64, ptr %slot297, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %rgep1953 = getelementptr i8, ptr %p1952, i64 -24
  store i64 %v1950, ptr %rgep1953, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear380
bb_rcgclear380:
  %v1954 = load i64, ptr %slot293, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i64 0, ptr %p1955, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone380
bb_rcgdone380:
  br label %bb_rcslotdone364
bb_rcslotowner364:
  %v1956 = load i64, ptr %slot39, align 8
  store i64 %v1956, ptr %slot310, align 8
  %v1957 = load i64, ptr %slot293, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %ld1959 = load i64, ptr %p1958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1959, ptr %slot311, align 8
  %v1960 = load i64, ptr %slot311, align 8
  %cmp1961 = icmp ne i64 %v1960, 0
  %cv1962 = zext i1 %cmp1961 to i32
  store i32 %cv1962, ptr %slot312, align 8
  %v1963 = load i32, ptr %slot312, align 8
  %cv1964 = zext i32 %v1963 to i64
  %cond1965 = icmp ne i64 %cv1964, 0
  br i1 %cond1965, label %bb_rcgnn395, label %bb_rcgdone395
bb_rcgnn395:
  %v1966 = load i64, ptr %slot311, align 8
  %op1967 = sub i64 %v1966, 16
  store i64 %op1967, ptr %slot313, align 8
  %v1968 = load i64, ptr %slot311, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  %rgep1970 = getelementptr i8, ptr %p1969, i64 -16
  %ld1971 = load i64, ptr %rgep1970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1971, ptr %slot314, align 8
  %v1972 = load i64, ptr %slot314, align 8
  %op1973 = and i64 %v1972, 4611686018427387906
  store i64 %op1973, ptr %slot315, align 8
  %v1974 = load i64, ptr %slot315, align 8
  %cmp1975 = icmp ne i64 %v1974, 0
  %cv1976 = zext i1 %cmp1975 to i32
  store i32 %cv1976, ptr %slot316, align 8
  %v1977 = load i32, ptr %slot316, align 8
  %cv1978 = zext i32 %v1977 to i64
  %cond1979 = icmp ne i64 %cv1978, 0
  br i1 %cond1979, label %bb_rcgclear395, label %bb_rcgcounted395
bb_rcgcounted395:
  %v1980 = load i64, ptr %slot311, align 8
  %op1981 = sub i64 %v1980, 32
  store i64 %op1981, ptr %slot317, align 8
  %v1982 = load i64, ptr %slot311, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %rgep1984 = getelementptr i8, ptr %p1983, i64 -32
  %ld1985 = load i64, ptr %rgep1984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1985, ptr %slot318, align 8
  %v1986 = load i64, ptr %slot318, align 8
  %op1987 = sub i64 %v1986, 1
  store i64 %op1987, ptr %slot319, align 8
  %v1988 = load i64, ptr %slot319, align 8
  %cmp1989 = icmp eq i64 %v1988, 0
  %cv1990 = zext i1 %cmp1989 to i32
  store i32 %cv1990, ptr %slot320, align 8
  %v1991 = load i32, ptr %slot320, align 8
  %cv1992 = zext i32 %v1991 to i64
  %cond1993 = icmp ne i64 %cv1992, 0
  br i1 %cond1993, label %bb_rcglast395, label %bb_rcgdec395
bb_rcglast395:
  %v1994 = load i64, ptr %slot311, align 8
  %op1995 = sub i64 %v1994, 24
  store i64 %op1995, ptr %slot321, align 8
  %v1996 = load i64, ptr %slot311, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %rgep1998 = getelementptr i8, ptr %p1997, i64 -24
  %ld1999 = load i64, ptr %rgep1998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1999, ptr %slot322, align 8
  %v2000 = load i64, ptr %slot322, align 8
  %cmp2001 = icmp ne i64 %v2000, 0
  %cv2002 = zext i1 %cmp2001 to i32
  store i32 %cv2002, ptr %slot323, align 8
  %v2003 = load i32, ptr %slot323, align 8
  %cv2004 = zext i32 %v2003 to i64
  %cond2005 = icmp ne i64 %cv2004, 0
  br i1 %cond2005, label %bb_rcgdec395, label %bb_rcgslow395
bb_rcgslow395:
  %v2006 = load i64, ptr %slot310, align 8
  %v2007 = load i64, ptr %slot293, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2006, i64 %v2007) nomerge, !dbg !130
  br label %bb_rcgdone395
bb_rcgdec395:
  %v2008 = load i64, ptr %slot319, align 8
  %v2009 = load i64, ptr %slot311, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %rgep2011 = getelementptr i8, ptr %p2010, i64 -32
  store i64 %v2008, ptr %rgep2011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear395
bb_rcgclear395:
  %v2012 = load i64, ptr %slot293, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  store i64 0, ptr %p2013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone395
bb_rcgdone395:
  br label %bb_rcslotdone364
bb_rcslotdone364:
  %v2014 = load i64, ptr %slot15, align 8
  store i64 %v2014, ptr %slot324, align 8
  %v2015 = load i64, ptr %slot17, align 8
  store i64 %v2015, ptr %slot325, align 8
  %v2016 = load i64, ptr %slot325, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %ld2018 = load i64, ptr %p2017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2018, ptr %slot326, align 8
  %v2019 = load i64, ptr %slot326, align 8
  %v2020 = load i64, ptr %slot324, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  store i64 %v2019, ptr %p2021, align 8, !alias.scope !3, !noalias !4
  %v2022 = load i64, ptr %slot11, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  store i32 2, ptr %p2023, align 4, !alias.scope !3, !noalias !4
  %v2024 = load i64, ptr %slot11, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  store i32 8, ptr %p2025, align 4, !alias.scope !3, !noalias !4
  %v2026 = load i64, ptr %slot10, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  store i32 1, ptr %p2027, align 4, !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot12, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  store i32 0, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  %v2030 = load i64, ptr %slot326, align 8
  %v2031 = load i64, ptr %slot28, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i64 %v2030, ptr %p2032, align 8, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot17, align 8
  store i64 %v2033, ptr %slot327, align 8
  %v2034 = load i64, ptr %slot28, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %ld2036 = load i64, ptr %p2035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2036, ptr %slot328, align 8
  %v2037 = load i64, ptr %slot328, align 8
  %v2038 = load i64, ptr %slot327, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i64 %v2037, ptr %p2039, align 8, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot13, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  store i32 2, ptr %p2041, align 4, !alias.scope !3, !noalias !4
  %v2042 = load i64, ptr %slot13, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  store i32 8, ptr %p2043, align 4, !alias.scope !3, !noalias !4
  %v2044 = load i64, ptr %slot12, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  store i32 1, ptr %p2045, align 4, !alias.scope !3, !noalias !4
  %v2046 = load i64, ptr %slot10, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i32 0, ptr %p2047, align 4, !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot8, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  %ld2050 = load i32, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2050, ptr %slot329, align 8
  %v2051 = load i32, ptr %slot329, align 8
  %cv2052 = zext i32 %v2051 to i64
  %cond2053 = icmp ne i64 %cv2052, 0
  br i1 %cond2053, label %bb_rcslotdrop414, label %bb_rcslotdone414
bb_rcslotdrop414:
  %v2054 = load i64, ptr %slot8, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  store i32 0, ptr %p2055, align 4, !alias.scope !3, !noalias !4
  %v2056 = load i64, ptr %slot23, align 8
  store i64 %v2056, ptr %slot330, align 8
  %v2057 = load i64, ptr %slot9, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i32, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2059, ptr %slot331, align 8
  %v2060 = load i32, ptr %slot331, align 8
  %op2061 = and i32 %v2060, 28
  store i32 %op2061, ptr %slot332, align 8
  %v2062 = load i32, ptr %slot332, align 8
  %cv2063 = zext i32 %v2062 to i64
  %cond2064 = icmp ne i64 %cv2063, 0
  br i1 %cond2064, label %bb_rcslotrole414, label %bb_rcslotowner414
bb_rcslotrole414:
  %v2065 = load i64, ptr %slot39, align 8
  store i64 %v2065, ptr %slot333, align 8
  %v2066 = load i64, ptr %slot330, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  %ld2068 = load i64, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2068, ptr %slot334, align 8
  %v2069 = load i64, ptr %slot334, align 8
  %cmp2070 = icmp ne i64 %v2069, 0
  %cv2071 = zext i1 %cmp2070 to i32
  store i32 %cv2071, ptr %slot335, align 8
  %v2072 = load i32, ptr %slot335, align 8
  %cv2073 = zext i32 %v2072 to i64
  %cond2074 = icmp ne i64 %cv2073, 0
  br i1 %cond2074, label %bb_rcgnn430, label %bb_rcgdone430
bb_rcgnn430:
  %v2075 = load i64, ptr %slot334, align 8
  %op2076 = sub i64 %v2075, 16
  store i64 %op2076, ptr %slot336, align 8
  %v2077 = load i64, ptr %slot334, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %rgep2079 = getelementptr i8, ptr %p2078, i64 -16
  %ld2080 = load i64, ptr %rgep2079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2080, ptr %slot337, align 8
  %v2081 = load i64, ptr %slot337, align 8
  %op2082 = and i64 %v2081, 4611686018427387906
  store i64 %op2082, ptr %slot338, align 8
  %v2083 = load i64, ptr %slot338, align 8
  %cmp2084 = icmp ne i64 %v2083, 0
  %cv2085 = zext i1 %cmp2084 to i32
  store i32 %cv2085, ptr %slot339, align 8
  %v2086 = load i32, ptr %slot339, align 8
  %cv2087 = zext i32 %v2086 to i64
  %cond2088 = icmp ne i64 %cv2087, 0
  br i1 %cond2088, label %bb_rcgclear430, label %bb_rcgcounted430
bb_rcgcounted430:
  %v2089 = load i64, ptr %slot334, align 8
  %op2090 = sub i64 %v2089, 24
  store i64 %op2090, ptr %slot340, align 8
  %v2091 = load i64, ptr %slot334, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %rgep2093 = getelementptr i8, ptr %p2092, i64 -24
  %ld2094 = load i64, ptr %rgep2093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2094, ptr %slot341, align 8
  %v2095 = load i64, ptr %slot341, align 8
  %op2096 = sub i64 %v2095, 1
  store i64 %op2096, ptr %slot342, align 8
  %v2097 = load i64, ptr %slot342, align 8
  %cmp2098 = icmp eq i64 %v2097, 0
  %cv2099 = zext i1 %cmp2098 to i32
  store i32 %cv2099, ptr %slot343, align 8
  %v2100 = load i32, ptr %slot343, align 8
  %cv2101 = zext i32 %v2100 to i64
  %cond2102 = icmp ne i64 %cv2101, 0
  br i1 %cond2102, label %bb_rcglast430, label %bb_rcgdec430
bb_rcglast430:
  %v2103 = load i64, ptr %slot334, align 8
  %op2104 = sub i64 %v2103, 32
  store i64 %op2104, ptr %slot344, align 8
  %v2105 = load i64, ptr %slot334, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  %rgep2107 = getelementptr i8, ptr %p2106, i64 -32
  %ld2108 = load i64, ptr %rgep2107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2108, ptr %slot345, align 8
  %v2109 = load i64, ptr %slot345, align 8
  %cmp2110 = icmp ne i64 %v2109, 0
  %cv2111 = zext i1 %cmp2110 to i32
  store i32 %cv2111, ptr %slot346, align 8
  %v2112 = load i32, ptr %slot346, align 8
  %cv2113 = zext i32 %v2112 to i64
  %cond2114 = icmp ne i64 %cv2113, 0
  br i1 %cond2114, label %bb_rcgdec430, label %bb_rcgslow430
bb_rcgslow430:
  %v2115 = load i64, ptr %slot333, align 8
  %v2116 = load i64, ptr %slot330, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2115, i64 %v2116) nomerge, !dbg !130
  br label %bb_rcgdone430
bb_rcgdec430:
  %v2117 = load i64, ptr %slot342, align 8
  %v2118 = load i64, ptr %slot334, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %rgep2120 = getelementptr i8, ptr %p2119, i64 -24
  store i64 %v2117, ptr %rgep2120, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear430
bb_rcgclear430:
  %v2121 = load i64, ptr %slot330, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  store i64 0, ptr %p2122, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone430
bb_rcgdone430:
  br label %bb_rcslotdone414
bb_rcslotowner414:
  %v2123 = load i64, ptr %slot39, align 8
  store i64 %v2123, ptr %slot347, align 8
  %v2124 = load i64, ptr %slot330, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %ld2126 = load i64, ptr %p2125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2126, ptr %slot348, align 8
  %v2127 = load i64, ptr %slot348, align 8
  %cmp2128 = icmp ne i64 %v2127, 0
  %cv2129 = zext i1 %cmp2128 to i32
  store i32 %cv2129, ptr %slot349, align 8
  %v2130 = load i32, ptr %slot349, align 8
  %cv2131 = zext i32 %v2130 to i64
  %cond2132 = icmp ne i64 %cv2131, 0
  br i1 %cond2132, label %bb_rcgnn445, label %bb_rcgdone445
bb_rcgnn445:
  %v2133 = load i64, ptr %slot348, align 8
  %op2134 = sub i64 %v2133, 16
  store i64 %op2134, ptr %slot350, align 8
  %v2135 = load i64, ptr %slot348, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  %rgep2137 = getelementptr i8, ptr %p2136, i64 -16
  %ld2138 = load i64, ptr %rgep2137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2138, ptr %slot351, align 8
  %v2139 = load i64, ptr %slot351, align 8
  %op2140 = and i64 %v2139, 4611686018427387906
  store i64 %op2140, ptr %slot352, align 8
  %v2141 = load i64, ptr %slot352, align 8
  %cmp2142 = icmp ne i64 %v2141, 0
  %cv2143 = zext i1 %cmp2142 to i32
  store i32 %cv2143, ptr %slot353, align 8
  %v2144 = load i32, ptr %slot353, align 8
  %cv2145 = zext i32 %v2144 to i64
  %cond2146 = icmp ne i64 %cv2145, 0
  br i1 %cond2146, label %bb_rcgclear445, label %bb_rcgcounted445
bb_rcgcounted445:
  %v2147 = load i64, ptr %slot348, align 8
  %op2148 = sub i64 %v2147, 32
  store i64 %op2148, ptr %slot354, align 8
  %v2149 = load i64, ptr %slot348, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  %rgep2151 = getelementptr i8, ptr %p2150, i64 -32
  %ld2152 = load i64, ptr %rgep2151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2152, ptr %slot355, align 8
  %v2153 = load i64, ptr %slot355, align 8
  %op2154 = sub i64 %v2153, 1
  store i64 %op2154, ptr %slot356, align 8
  %v2155 = load i64, ptr %slot356, align 8
  %cmp2156 = icmp eq i64 %v2155, 0
  %cv2157 = zext i1 %cmp2156 to i32
  store i32 %cv2157, ptr %slot357, align 8
  %v2158 = load i32, ptr %slot357, align 8
  %cv2159 = zext i32 %v2158 to i64
  %cond2160 = icmp ne i64 %cv2159, 0
  br i1 %cond2160, label %bb_rcglast445, label %bb_rcgdec445
bb_rcglast445:
  %v2161 = load i64, ptr %slot348, align 8
  %op2162 = sub i64 %v2161, 24
  store i64 %op2162, ptr %slot358, align 8
  %v2163 = load i64, ptr %slot348, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %rgep2165 = getelementptr i8, ptr %p2164, i64 -24
  %ld2166 = load i64, ptr %rgep2165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2166, ptr %slot359, align 8
  %v2167 = load i64, ptr %slot359, align 8
  %cmp2168 = icmp ne i64 %v2167, 0
  %cv2169 = zext i1 %cmp2168 to i32
  store i32 %cv2169, ptr %slot360, align 8
  %v2170 = load i32, ptr %slot360, align 8
  %cv2171 = zext i32 %v2170 to i64
  %cond2172 = icmp ne i64 %cv2171, 0
  br i1 %cond2172, label %bb_rcgdec445, label %bb_rcgslow445
bb_rcgslow445:
  %v2173 = load i64, ptr %slot347, align 8
  %v2174 = load i64, ptr %slot330, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2173, i64 %v2174) nomerge, !dbg !130
  br label %bb_rcgdone445
bb_rcgdec445:
  %v2175 = load i64, ptr %slot356, align 8
  %v2176 = load i64, ptr %slot348, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %rgep2178 = getelementptr i8, ptr %p2177, i64 -32
  store i64 %v2175, ptr %rgep2178, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear445
bb_rcgclear445:
  %v2179 = load i64, ptr %slot330, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  store i64 0, ptr %p2180, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone445
bb_rcgdone445:
  br label %bb_rcslotdone414
bb_rcslotdone414:
  %v2181 = load i64, ptr %slot23, align 8
  store i64 %v2181, ptr %slot361, align 8
  %v2182 = load i64, ptr %slot327, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %ld2184 = load i64, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2184, ptr %slot362, align 8
  %v2185 = load i64, ptr %slot362, align 8
  %v2186 = load i64, ptr %slot361, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  store i64 %v2185, ptr %p2187, align 8, !alias.scope !3, !noalias !4
  %v2188 = load i64, ptr %slot9, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i32 2, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot9, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i32 8, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot8, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  store i32 1, ptr %p2193, align 4, !alias.scope !3, !noalias !4
  %v2194 = load i64, ptr %slot12, align 8
  %p2195 = inttoptr i64 %v2194 to ptr
  store i32 0, ptr %p2195, align 4, !alias.scope !3, !noalias !4
  %v2196 = load i64, ptr %slot28, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i64 0, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot28, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  %ld2200 = load i64, ptr %p2199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2200, ptr %slot363, align 8
  %v2201 = load i64, ptr %slot363, align 8
  %v2202 = load i64, ptr %slot24, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  store i64 %v2201, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  %v2204 = load i64, ptr %slot23, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %ld2206 = load i64, ptr %p2205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2206, ptr %slot364, align 8
  %v2207 = load i64, ptr %slot364, align 8
  %op2208 = add i64 %v2207, 0
  store i64 %op2208, ptr %slot365, align 8
  %v2209 = load i64, ptr %slot365, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  %ld2211 = load i64, ptr %p2210, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2211, ptr %slot366, align 8
  %v2212 = load i64, ptr %slot366, align 8
  %v2213 = load i64, ptr %slot28, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  store i64 %v2212, ptr %p2214, align 8, !alias.scope !3, !noalias !4
  %v2215 = load i64, ptr %slot28, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  %ld2217 = load i64, ptr %p2216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2217, ptr %slot367, align 8
  %v2218 = load i64, ptr %slot367, align 8
  %cmp2219 = icmp ugt i64 %v2218, 9223372036854775807
  %cv2220 = zext i1 %cmp2219 to i64
  store i64 %cv2220, ptr %slot368, align 8
  %v2221 = load i64, ptr %slot368, align 8
  %cond2222 = icmp ne i64 %v2221, 0
  br i1 %cond2222, label %bb_cast_overflow461, label %bb_cast_ok461
bb_cast_overflow461:
  %v2223 = load i64, ptr %slot1, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %v2225 = load i64, ptr %slot367, align 8
  call void @myl_qbe_fail_cast(ptr %p2224, i64 %v2225, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok461:
  %v2226 = load i64, ptr %slot367, align 8
  %v2227 = load i64, ptr %slot28, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  store i64 %v2226, ptr %p2228, align 8, !alias.scope !3, !noalias !4
  %v2229 = load i64, ptr %slot28, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i64, ptr %p2230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2231, ptr %slot369, align 8
  %v2232 = load i64, ptr %slot369, align 8
  %v2233 = load i64, ptr %slot25, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i64 %v2232, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i29:
  %v2235 = load i64, ptr %slot24, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i64, ptr %p2236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2237, ptr %slot370, align 8
  %v2238 = load i64, ptr %slot370, align 8
  %v2239 = load i64, ptr %slot28, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i64 %v2238, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  %v2241 = load i64, ptr %slot25, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %ld2243 = load i64, ptr %p2242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2243, ptr %slot371, align 8
  %v2244 = load i64, ptr %slot371, align 8
  %v2245 = load i64, ptr %slot29, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i64 %v2244, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot29, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i64, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2249, ptr %slot372, align 8
  %v2250 = load i64, ptr %slot28, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i64, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2252, ptr %slot373, align 8
  %v2253 = load i64, ptr %slot373, align 8
  %v2254 = load i64, ptr %slot372, align 8
  %cmp2255 = icmp slt i64 %v2253, %v2254
  %cv2256 = zext i1 %cmp2255 to i64
  store i64 %cv2256, ptr %slot374, align 8
  %v2257 = load i64, ptr %slot374, align 8
  %v2258 = load i64, ptr %slot28, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  store i64 %v2257, ptr %p2259, align 8, !alias.scope !3, !noalias !4
  %v2260 = load i64, ptr %slot28, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  %ld2262 = load i64, ptr %p2261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2262, ptr %slot375, align 8
  %v2263 = load i64, ptr %slot375, align 8
  %cond2264 = icmp ne i64 %v2263, 0
  br i1 %cond2264, label %bb_next469, label %bb_i61
bb_next469:
  %v2265 = load i64, ptr %slot25, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot376, align 8
  %v2268 = load i64, ptr %slot376, align 8
  %v2269 = load i64, ptr %slot28, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i64 %v2268, ptr %p2270, align 8, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot23, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  %ld2273 = load i64, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2273, ptr %slot377, align 8
  %v2274 = load i64, ptr %slot28, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  %ld2276 = load i64, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2276, ptr %slot378, align 8
  %v2277 = load i64, ptr %slot377, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i64, ptr %p2278, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2279, ptr %slot379, align 8
  %v2280 = load i64, ptr %slot379, align 8
  %v2281 = load i64, ptr %slot378, align 8
  %cmp2282 = icmp eq i64 %v2280, %v2281
  %cv2283 = zext i1 %cmp2282 to i64
  store i64 %cv2283, ptr %slot380, align 8
  %v2284 = load i64, ptr %slot380, align 8
  %cond2285 = icmp ne i64 %v2284, 0
  br i1 %cond2285, label %bb_success474, label %bb_failed474
bb_failed474:
  %v2286 = load i64, ptr %slot1, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  call void @myl_qbe_fail_iteration(ptr %p2287) nomerge, !dbg !134
  unreachable
bb_success474:
  %v2288 = load i64, ptr %slot28, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 0, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot24, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot381, align 8
  %v2293 = load i64, ptr %slot381, align 8
  %v2294 = load i64, ptr %slot28, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i64 %v2293, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot23, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i64, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2298, ptr %slot382, align 8
  %v2299 = load i64, ptr %slot28, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i64, ptr %p2300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2301, ptr %slot383, align 8
  %v2302 = load i64, ptr %slot382, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %ld2304 = load i64, ptr %p2303, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2304, ptr %slot384, align 8
  %v2305 = load i64, ptr %slot383, align 8
  %v2306 = load i64, ptr %slot384, align 8
  %cmp2307 = icmp ult i64 %v2305, %v2306
  %cv2308 = zext i1 %cmp2307 to i64
  store i64 %cv2308, ptr %slot385, align 8
  %v2309 = load i64, ptr %slot385, align 8
  %cond2310 = icmp ne i64 %v2309, 0
  br i1 %cond2310, label %bb_success481, label %bb_failed481
bb_failed481:
  %v2311 = load i64, ptr %slot1, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %v2313 = load i64, ptr %slot383, align 8
  %v2314 = load i64, ptr %slot384, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2312, i64 %v2313, i64 %v2314) nomerge, !dbg !136
  unreachable
bb_success481:
  %v2315 = load i64, ptr %slot382, align 8
  %op2316 = add i64 %v2315, 32
  store i64 %op2316, ptr %slot386, align 8
  %v2317 = load i64, ptr %slot386, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %ld2319 = load i64, ptr %p2318, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2319, ptr %slot387, align 8
  %v2320 = load i64, ptr %slot383, align 8
  %op2321 = mul i64 %v2320, 8
  store i64 %op2321, ptr %slot388, align 8
  %v2322 = load i64, ptr %slot387, align 8
  %v2323 = load i64, ptr %slot388, align 8
  %op2324 = add i64 %v2322, %v2323
  store i64 %op2324, ptr %slot389, align 8
  %v2325 = load i64, ptr %slot387, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %v2327 = load i64, ptr %slot388, align 8
  %egep2328 = getelementptr i8, ptr %p2326, i64 %v2327
  %ld2329 = load i64, ptr %egep2328, align 8, !alias.scope !12, !noalias !13
  store i64 %ld2329, ptr %slot390, align 8
  %v2330 = load i64, ptr %slot390, align 8
  %v2331 = load i64, ptr %slot28, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i64 %v2330, ptr %p2332, align 8, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot28, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i64, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2335, ptr %slot391, align 8
  %v2336 = load i64, ptr %slot391, align 8
  %v2337 = load i64, ptr %slot26, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  store i64 %v2336, ptr %p2338, align 8, !alias.scope !3, !noalias !4
  %v2339 = load i64, ptr %slot18, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %ld2341 = load i64, ptr %p2340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2341, ptr %slot392, align 8
  %v2342 = load i64, ptr %slot392, align 8
  %v2343 = load i64, ptr %slot28, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  store i64 %v2342, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot26, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %ld2347 = load i64, ptr %p2346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2347, ptr %slot393, align 8
  %v2348 = load i64, ptr %slot393, align 8
  %v2349 = load i64, ptr %slot29, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot28, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i64, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2353, ptr %slot394, align 8
  %v2354 = load i64, ptr %slot29, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %ld2356 = load i64, ptr %p2355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2356, ptr %slot395, align 8
  %v2357 = load i64, ptr %slot1, align 8
  %v2358 = load i64, ptr %slot394, align 8
  %v2359 = load i64, ptr %slot395, align 8
  call void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8 %callresult397, i64 %v2357, i64 %v2358, i64 %v2359) nomerge, !dbg !138
  %addr2360 = ptrtoint ptr %callresult397 to i64
  store i64 %addr2360, ptr %slot396, align 8
  %v2361 = load i64, ptr %slot396, align 8
  %v2362 = load i64, ptr %slot28, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  store i64 %v2361, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  %v2364 = load i64, ptr %slot28, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %ld2366 = load i64, ptr %p2365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2366, ptr %slot398, align 8
  %v2367 = load i64, ptr %slot17, align 8
  store i64 %v2367, ptr %slot399, align 8
  %v2368 = load i64, ptr %slot398, align 8
  %v2369 = load i64, ptr %slot399, align 8
  %p2370 = inttoptr i64 %v2368 to ptr
  %p2371 = inttoptr i64 %v2369 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2371, ptr %p2370, i64 24, i1 false)
  %v2372 = load i64, ptr %slot13, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i32 2, ptr %p2373, align 4, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot12, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i32 1, ptr %p2375, align 4, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot10, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  %ld2378 = load i32, ptr %p2377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2378, ptr %slot400, align 8
  %v2379 = load i32, ptr %slot400, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcslotdrop499, label %bb_rcslotdone499
bb_rcslotdrop499:
  %v2382 = load i64, ptr %slot10, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i32 0, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot15, align 8
  store i64 %v2384, ptr %slot401, align 8
  %v2385 = load i64, ptr %slot11, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i32, ptr %p2386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2387, ptr %slot402, align 8
  %v2388 = load i32, ptr %slot402, align 8
  %op2389 = and i32 %v2388, 28
  store i32 %op2389, ptr %slot403, align 8
  %v2390 = load i32, ptr %slot403, align 8
  %cv2391 = zext i32 %v2390 to i64
  %cond2392 = icmp ne i64 %cv2391, 0
  br i1 %cond2392, label %bb_rcslotrole499, label %bb_rcslotowner499
bb_rcslotrole499:
  %v2393 = load i64, ptr %slot39, align 8
  store i64 %v2393, ptr %slot404, align 8
  %v2394 = load i64, ptr %slot404, align 8
  %v2395 = load i64, ptr %slot401, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2394, i64 %v2395) nomerge, !dbg !138
  br label %bb_rcslotdone499
bb_rcslotowner499:
  %v2396 = load i64, ptr %slot39, align 8
  store i64 %v2396, ptr %slot405, align 8
  %v2397 = load i64, ptr %slot405, align 8
  %v2398 = load i64, ptr %slot401, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2397, i64 %v2398) nomerge, !dbg !138
  br label %bb_rcslotdone499
bb_rcslotdone499:
  %v2399 = load i64, ptr %slot15, align 8
  store i64 %v2399, ptr %slot406, align 8
  %v2400 = load i64, ptr %slot17, align 8
  store i64 %v2400, ptr %slot407, align 8
  %v2401 = load i64, ptr %slot407, align 8
  %v2402 = load i64, ptr %slot406, align 8
  %p2403 = inttoptr i64 %v2401 to ptr
  %p2404 = inttoptr i64 %v2402 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2404, ptr %p2403, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot11, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 2, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot13, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  %ld2409 = load i32, ptr %p2408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2409, ptr %slot408, align 8
  %v2410 = load i32, ptr %slot408, align 8
  %v2411 = load i64, ptr %slot11, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  store i32 %v2410, ptr %p2412, align 4, !alias.scope !3, !noalias !4
  %v2413 = load i64, ptr %slot12, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 0, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot10, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  store i32 1, ptr %p2416, align 4, !alias.scope !3, !noalias !4
  %v2417 = load i64, ptr %slot406, align 8
  %v2418 = load i64, ptr %slot28, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  store i64 %v2417, ptr %p2419, align 8, !alias.scope !3, !noalias !4
  %v2420 = load i64, ptr %slot28, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %ld2422 = load i64, ptr %p2421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2422, ptr %slot409, align 8
  %v2423 = load i64, ptr %slot409, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %ld2425 = load i32, ptr %p2424, align 4, !alias.scope !3, !noalias !4
  %ext2426 = zext i32 %ld2425 to i64
  store i64 %ext2426, ptr %slot410, align 8
  %v2427 = load i64, ptr %slot410, align 8
  %cmp2428 = icmp eq i64 %v2427, 0
  %cv2429 = zext i1 %cmp2428 to i64
  store i64 %cv2429, ptr %slot411, align 8
  %v2430 = load i64, ptr %slot411, align 8
  %cond2431 = icmp ne i64 %v2430, 0
  br i1 %cond2431, label %bb_rctryok515, label %bb_rctryerror515
bb_rctryerror515:
  %p2432 = inttoptr i64 ptrtoint (ptr @myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2432, i64 12884901930) "call-inline-cost"="0", !dbg !140
  %v2433 = load i64, ptr %slot409, align 8
  %op2434 = add i64 %v2433, 8
  store i64 %op2434, ptr %slot412, align 8
  %v2435 = load i64, ptr %slot30, align 8
  store i64 %v2435, ptr %slot413, align 8
  %v2436 = load i64, ptr %slot413, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  store i64 0, ptr %p2437, align 8, !alias.scope !3, !noalias !4
  %v2438 = load i64, ptr %slot413, align 8
  %p2440 = inttoptr i64 %v2438 to ptr
  %gep2441 = getelementptr i8, ptr %p2440, i64 8
  %op2439 = ptrtoint ptr %gep2441 to i64
  store i64 %op2439, ptr %slot414, align 8
  %v2442 = load i64, ptr %slot414, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i64 0, ptr %p2443, align 8, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot413, align 8
  %p2446 = inttoptr i64 %v2444 to ptr
  %gep2447 = getelementptr i8, ptr %p2446, i64 16
  %op2445 = ptrtoint ptr %gep2447 to i64
  store i64 %op2445, ptr %slot415, align 8
  %v2448 = load i64, ptr %slot415, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  store i64 0, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  %v2450 = load i64, ptr %slot413, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  store i32 1, ptr %p2451, align 4, !alias.scope !3, !noalias !4
  %v2452 = load i64, ptr %slot413, align 8
  %p2454 = inttoptr i64 %v2452 to ptr
  %gep2455 = getelementptr i8, ptr %p2454, i64 8
  %op2453 = ptrtoint ptr %gep2455 to i64
  store i64 %op2453, ptr %slot416, align 8
  %v2456 = load i64, ptr %slot14, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  store i32 1, ptr %p2457, align 4, !alias.scope !3, !noalias !4
  %v2458 = load i64, ptr %slot40, align 8
  store i64 %v2458, ptr %slot417, align 8
  %v2459 = load i64, ptr %slot39, align 8
  %v2460 = load i64, ptr %slot416, align 8
  %v2461 = load i64, ptr %slot412, align 8
  %v2462 = load i64, ptr %slot417, align 8
  %cv2463 = trunc i64 %v2462 to i32
  %call2464 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2459, i64 %v2460, i64 %v2461, i32 %cv2463) nomerge, !dbg !140
  store i32 %call2464, ptr %slot418, align 8
  %v2465 = load i32, ptr %slot418, align 8
  %cv2466 = zext i32 %v2465 to i64
  %cond2467 = icmp ne i64 %cv2466, 0
  br i1 %cond2467, label %bb_rcsuccess526, label %bb_rcfailure526
bb_rcfailure526:
  %v2468 = load i64, ptr %slot39, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  %call2470 = call i32 @myl_rc_take_failure(ptr %p2469) nomerge, !dbg !140
  store i32 %call2470, ptr %slot419, align 8
  %v2471 = load i64, ptr %slot1, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %v2473 = load i32, ptr %slot419, align 8
  %call2474 = call i32 @myl_qbe_rc_status(ptr %p2472, i32 %v2473) nomerge, !dbg !140
  store i32 %call2474, ptr %slot420, align 8
  br label %bb_failure
bb_rcsuccess526:
  %v2475 = load i64, ptr %slot413, align 8
  %v2476 = load i64, ptr %slot28, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i64 %v2475, ptr %p2477, align 8, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot28, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %ld2480 = load i64, ptr %p2479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2480, ptr %slot421, align 8
  %v2481 = load i64, ptr %slot17, align 8
  store i64 %v2481, ptr %slot422, align 8
  %v2482 = load i64, ptr %slot421, align 8
  %v2483 = load i64, ptr %slot422, align 8
  %p2484 = inttoptr i64 %v2482 to ptr
  %p2485 = inttoptr i64 %v2483 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2485, ptr %p2484, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot13, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i32 2, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot12, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i32 1, ptr %p2489, align 4, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot10, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %ld2492 = load i32, ptr %p2491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2492, ptr %slot423, align 8
  %v2493 = load i32, ptr %slot423, align 8
  %cv2494 = zext i32 %v2493 to i64
  %cond2495 = icmp ne i64 %cv2494, 0
  br i1 %cond2495, label %bb_rcslotdrop535, label %bb_rcslotdone535
bb_rcslotdrop535:
  %v2496 = load i64, ptr %slot10, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 0, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot15, align 8
  store i64 %v2498, ptr %slot424, align 8
  %v2499 = load i64, ptr %slot11, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i32, ptr %p2500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2501, ptr %slot425, align 8
  %v2502 = load i32, ptr %slot425, align 8
  %op2503 = and i32 %v2502, 28
  store i32 %op2503, ptr %slot426, align 8
  %v2504 = load i32, ptr %slot426, align 8
  %cv2505 = zext i32 %v2504 to i64
  %cond2506 = icmp ne i64 %cv2505, 0
  br i1 %cond2506, label %bb_rcslotrole535, label %bb_rcslotowner535
bb_rcslotrole535:
  %v2507 = load i64, ptr %slot39, align 8
  store i64 %v2507, ptr %slot427, align 8
  %v2508 = load i64, ptr %slot427, align 8
  %v2509 = load i64, ptr %slot424, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2508, i64 %v2509) nomerge, !dbg !140
  br label %bb_rcslotdone535
bb_rcslotowner535:
  %v2510 = load i64, ptr %slot39, align 8
  store i64 %v2510, ptr %slot428, align 8
  %v2511 = load i64, ptr %slot428, align 8
  %v2512 = load i64, ptr %slot424, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2511, i64 %v2512) nomerge, !dbg !140
  br label %bb_rcslotdone535
bb_rcslotdone535:
  %v2513 = load i64, ptr %slot15, align 8
  store i64 %v2513, ptr %slot429, align 8
  %v2514 = load i64, ptr %slot17, align 8
  store i64 %v2514, ptr %slot430, align 8
  %v2515 = load i64, ptr %slot430, align 8
  %v2516 = load i64, ptr %slot429, align 8
  %p2517 = inttoptr i64 %v2515 to ptr
  %p2518 = inttoptr i64 %v2516 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2518, ptr %p2517, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot11, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 2, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot13, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  %ld2523 = load i32, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2523, ptr %slot431, align 8
  %v2524 = load i32, ptr %slot431, align 8
  %v2525 = load i64, ptr %slot11, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i32 %v2524, ptr %p2526, align 4, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot12, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i32 0, ptr %p2528, align 4, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot10, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  store i32 1, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  %v2531 = load i64, ptr %slot429, align 8
  %v2532 = load i64, ptr %slot28, align 8
  %p2533 = inttoptr i64 %v2532 to ptr
  store i64 %v2531, ptr %p2533, align 8, !alias.scope !3, !noalias !4
  br label %bb_i44
bb_rctryok515:
  %v2534 = load i64, ptr %slot30, align 8
  store i64 %v2534, ptr %slot432, align 8
  %v2535 = load i64, ptr %slot432, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 0, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  %v2537 = load i64, ptr %slot14, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 1, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot409, align 8
  %op2540 = add i64 %v2539, 8
  store i64 %op2540, ptr %slot433, align 8
  %v2541 = load i64, ptr %slot40, align 8
  store i64 %v2541, ptr %slot434, align 8
  %v2542 = load i64, ptr %slot433, align 8
  %v2543 = load i64, ptr %slot432, align 8
  %p2544 = inttoptr i64 %v2542 to ptr
  %p2545 = inttoptr i64 %v2543 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2545, ptr %p2544, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2546 = load i64, ptr %slot432, align 8
  %v2547 = load i64, ptr %slot28, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i64 %v2546, ptr %p2548, align 8, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot10, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %ld2551 = load i32, ptr %p2550, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2551, ptr %slot435, align 8
  %v2552 = load i32, ptr %slot435, align 8
  %cv2553 = zext i32 %v2552 to i64
  %cond2554 = icmp ne i64 %cv2553, 0
  br i1 %cond2554, label %bb_rcslotdrop557, label %bb_rcslotdone557
bb_rcslotdrop557:
  %v2555 = load i64, ptr %slot10, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  store i32 0, ptr %p2556, align 4, !alias.scope !3, !noalias !4
  %v2557 = load i64, ptr %slot15, align 8
  store i64 %v2557, ptr %slot436, align 8
  %v2558 = load i64, ptr %slot11, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  %ld2560 = load i32, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2560, ptr %slot437, align 8
  %v2561 = load i32, ptr %slot437, align 8
  %op2562 = and i32 %v2561, 28
  store i32 %op2562, ptr %slot438, align 8
  %v2563 = load i32, ptr %slot438, align 8
  %cv2564 = zext i32 %v2563 to i64
  %cond2565 = icmp ne i64 %cv2564, 0
  br i1 %cond2565, label %bb_rcslotrole557, label %bb_rcslotowner557
bb_rcslotrole557:
  %v2566 = load i64, ptr %slot39, align 8
  store i64 %v2566, ptr %slot439, align 8
  %v2567 = load i64, ptr %slot439, align 8
  %v2568 = load i64, ptr %slot436, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2567, i64 %v2568) nomerge, !dbg !140
  br label %bb_rcslotdone557
bb_rcslotowner557:
  %v2569 = load i64, ptr %slot39, align 8
  store i64 %v2569, ptr %slot440, align 8
  %v2570 = load i64, ptr %slot440, align 8
  %v2571 = load i64, ptr %slot436, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2570, i64 %v2571) nomerge, !dbg !140
  br label %bb_rcslotdone557
bb_rcslotdone557:
  br label %bb_i45
bb_i44:
  %v2572 = load i64, ptr %slot28, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  %ld2574 = load i64, ptr %p2573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2574, ptr %slot441, align 8
  %v2575 = load i64, ptr %slot28, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  %ld2577 = load i64, ptr %p2576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2577, ptr %slot442, align 8
  %v2578 = load i64, ptr %slot10, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  %ld2580 = load i32, ptr %p2579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2580, ptr %slot443, align 8
  %v2581 = load i64, ptr %slot11, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %ld2583 = load i32, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2583, ptr %slot444, align 8
  %v2584 = load i32, ptr %slot444, align 8
  %op2585 = and i32 %v2584, 24
  store i32 %op2585, ptr %slot444, align 8
  %v2586 = load i32, ptr %slot444, align 8
  %cmp2587 = icmp eq i32 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i32
  store i32 %cv2588, ptr %slot445, align 8
  %v2589 = load i32, ptr %slot443, align 8
  %v2590 = load i32, ptr %slot445, align 8
  %op2591 = and i32 %v2589, %v2590
  store i32 %op2591, ptr %slot446, align 8
  %v2592 = load i32, ptr %slot446, align 8
  %cv2593 = zext i32 %v2592 to i64
  %cond2594 = icmp ne i64 %cv2593, 0
  br i1 %cond2594, label %bb_rctake566, label %bb_rccopy566
bb_rctake566:
  %v2595 = load i64, ptr %slot17, align 8
  store i64 %v2595, ptr %slot447, align 8
  %v2596 = load i64, ptr %slot40, align 8
  store i64 %v2596, ptr %slot448, align 8
  %v2597 = load i64, ptr %slot39, align 8
  %v2598 = load i64, ptr %slot447, align 8
  %v2599 = load i64, ptr %slot442, align 8
  %v2600 = load i64, ptr %slot448, align 8
  %cv2601 = trunc i64 %v2600 to i32
  %call2602 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2597, i64 %v2598, i64 %v2599, i32 %cv2601) nomerge, !dbg !142
  store i32 %call2602, ptr %slot449, align 8
  %v2603 = load i32, ptr %slot449, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcsuccess576, label %bb_rcfailure576
bb_rcfailure576:
  %v2606 = load i64, ptr %slot39, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  %call2608 = call i32 @myl_rc_take_failure(ptr %p2607) nomerge, !dbg !142
  store i32 %call2608, ptr %slot450, align 8
  %v2609 = load i64, ptr %slot1, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %v2611 = load i32, ptr %slot450, align 8
  %call2612 = call i32 @myl_qbe_rc_status(ptr %p2610, i32 %v2611) nomerge, !dbg !142
  store i32 %call2612, ptr %slot451, align 8
  br label %bb_failure
bb_rcsuccess576:
  %v2613 = load i64, ptr %slot10, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i32 0, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot13, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i32 2, ptr %p2616, align 4, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot12, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  store i32 1, ptr %p2618, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared566
bb_rccopy566:
  %v2619 = load i64, ptr %slot17, align 8
  store i64 %v2619, ptr %slot452, align 8
  %v2620 = load i64, ptr %slot40, align 8
  store i64 %v2620, ptr %slot453, align 8
  %v2621 = load i64, ptr %slot39, align 8
  %v2622 = load i64, ptr %slot452, align 8
  %v2623 = load i64, ptr %slot442, align 8
  %v2624 = load i64, ptr %slot453, align 8
  %cv2625 = trunc i64 %v2624 to i32
  %call2626 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v2621, i64 %v2622, i64 %v2623, i32 %cv2625) nomerge, !dbg !142
  store i32 %call2626, ptr %slot454, align 8
  %v2627 = load i32, ptr %slot454, align 8
  %cv2628 = zext i32 %v2627 to i64
  %cond2629 = icmp ne i64 %cv2628, 0
  br i1 %cond2629, label %bb_rcsuccess585, label %bb_rcfailure585
bb_rcfailure585:
  %v2630 = load i64, ptr %slot39, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %call2632 = call i32 @myl_rc_take_failure(ptr %p2631) nomerge, !dbg !142
  store i32 %call2632, ptr %slot455, align 8
  %v2633 = load i64, ptr %slot1, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %v2635 = load i32, ptr %slot455, align 8
  %call2636 = call i32 @myl_qbe_rc_status(ptr %p2634, i32 %v2635) nomerge, !dbg !142
  store i32 %call2636, ptr %slot456, align 8
  br label %bb_failure
bb_rcsuccess585:
  %v2637 = load i64, ptr %slot13, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 2, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot12, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 1, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot10, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %ld2643 = load i32, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2643, ptr %slot457, align 8
  %v2644 = load i32, ptr %slot457, align 8
  %cv2645 = zext i32 %v2644 to i64
  %cond2646 = icmp ne i64 %cv2645, 0
  br i1 %cond2646, label %bb_rcslotdrop592, label %bb_rcslotdone592
bb_rcslotdrop592:
  %v2647 = load i64, ptr %slot10, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  store i32 0, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  %v2649 = load i64, ptr %slot15, align 8
  store i64 %v2649, ptr %slot458, align 8
  %v2650 = load i64, ptr %slot11, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot459, align 8
  %v2653 = load i32, ptr %slot459, align 8
  %op2654 = and i32 %v2653, 28
  store i32 %op2654, ptr %slot460, align 8
  %v2655 = load i32, ptr %slot460, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcslotrole592, label %bb_rcslotowner592
bb_rcslotrole592:
  %v2658 = load i64, ptr %slot39, align 8
  store i64 %v2658, ptr %slot461, align 8
  %v2659 = load i64, ptr %slot461, align 8
  %v2660 = load i64, ptr %slot458, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2659, i64 %v2660) nomerge, !dbg !142
  br label %bb_rcslotdone592
bb_rcslotowner592:
  %v2661 = load i64, ptr %slot39, align 8
  store i64 %v2661, ptr %slot462, align 8
  %v2662 = load i64, ptr %slot462, align 8
  %v2663 = load i64, ptr %slot458, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2662, i64 %v2663) nomerge, !dbg !142
  br label %bb_rcslotdone592
bb_rcslotdone592:
  br label %bb_rcprepared566
bb_rcprepared566:
  %v2664 = load i64, ptr %slot17, align 8
  store i64 %v2664, ptr %slot463, align 8
  %v2665 = load i64, ptr %slot12, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i32 0, ptr %p2666, align 4, !alias.scope !3, !noalias !4
  %v2667 = load i64, ptr %slot10, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %ld2669 = load i32, ptr %p2668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2669, ptr %slot464, align 8
  %v2670 = load i32, ptr %slot464, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcslotdrop603, label %bb_rcslotdone603
bb_rcslotdrop603:
  %v2673 = load i64, ptr %slot10, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  store i32 0, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  %v2675 = load i64, ptr %slot15, align 8
  store i64 %v2675, ptr %slot465, align 8
  %v2676 = load i64, ptr %slot11, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  %ld2678 = load i32, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2678, ptr %slot466, align 8
  %v2679 = load i32, ptr %slot466, align 8
  %op2680 = and i32 %v2679, 28
  store i32 %op2680, ptr %slot467, align 8
  %v2681 = load i32, ptr %slot467, align 8
  %cv2682 = zext i32 %v2681 to i64
  %cond2683 = icmp ne i64 %cv2682, 0
  br i1 %cond2683, label %bb_rcslotrole603, label %bb_rcslotowner603
bb_rcslotrole603:
  %v2684 = load i64, ptr %slot39, align 8
  store i64 %v2684, ptr %slot468, align 8
  %v2685 = load i64, ptr %slot468, align 8
  %v2686 = load i64, ptr %slot465, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2685, i64 %v2686) nomerge, !dbg !142
  br label %bb_rcslotdone603
bb_rcslotowner603:
  %v2687 = load i64, ptr %slot39, align 8
  store i64 %v2687, ptr %slot469, align 8
  %v2688 = load i64, ptr %slot469, align 8
  %v2689 = load i64, ptr %slot465, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2688, i64 %v2689) nomerge, !dbg !142
  br label %bb_rcslotdone603
bb_rcslotdone603:
  %v2690 = load i64, ptr %slot8, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i32, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2692, ptr %slot470, align 8
  %v2693 = load i32, ptr %slot470, align 8
  %cv2694 = zext i32 %v2693 to i64
  %cond2695 = icmp ne i64 %cv2694, 0
  br i1 %cond2695, label %bb_rcslotdrop612, label %bb_rcslotdone612
bb_rcslotdrop612:
  %v2696 = load i64, ptr %slot8, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i32 0, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot23, align 8
  store i64 %v2698, ptr %slot471, align 8
  %v2699 = load i64, ptr %slot9, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %ld2701 = load i32, ptr %p2700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2701, ptr %slot472, align 8
  %v2702 = load i32, ptr %slot472, align 8
  %op2703 = and i32 %v2702, 28
  store i32 %op2703, ptr %slot473, align 8
  %v2704 = load i32, ptr %slot473, align 8
  %cv2705 = zext i32 %v2704 to i64
  %cond2706 = icmp ne i64 %cv2705, 0
  br i1 %cond2706, label %bb_rcslotrole612, label %bb_rcslotowner612
bb_rcslotrole612:
  %v2707 = load i64, ptr %slot39, align 8
  store i64 %v2707, ptr %slot474, align 8
  %v2708 = load i64, ptr %slot471, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i64, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2710, ptr %slot475, align 8
  %v2711 = load i64, ptr %slot475, align 8
  %cmp2712 = icmp ne i64 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot476, align 8
  %v2714 = load i32, ptr %slot476, align 8
  %cv2715 = zext i32 %v2714 to i64
  %cond2716 = icmp ne i64 %cv2715, 0
  br i1 %cond2716, label %bb_rcgnn628, label %bb_rcgdone628
bb_rcgnn628:
  %v2717 = load i64, ptr %slot475, align 8
  %op2718 = sub i64 %v2717, 16
  store i64 %op2718, ptr %slot477, align 8
  %v2719 = load i64, ptr %slot475, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %rgep2721 = getelementptr i8, ptr %p2720, i64 -16
  %ld2722 = load i64, ptr %rgep2721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2722, ptr %slot478, align 8
  %v2723 = load i64, ptr %slot478, align 8
  %op2724 = and i64 %v2723, 4611686018427387906
  store i64 %op2724, ptr %slot479, align 8
  %v2725 = load i64, ptr %slot479, align 8
  %cmp2726 = icmp ne i64 %v2725, 0
  %cv2727 = zext i1 %cmp2726 to i32
  store i32 %cv2727, ptr %slot480, align 8
  %v2728 = load i32, ptr %slot480, align 8
  %cv2729 = zext i32 %v2728 to i64
  %cond2730 = icmp ne i64 %cv2729, 0
  br i1 %cond2730, label %bb_rcgclear628, label %bb_rcgcounted628
bb_rcgcounted628:
  %v2731 = load i64, ptr %slot475, align 8
  %op2732 = sub i64 %v2731, 24
  store i64 %op2732, ptr %slot481, align 8
  %v2733 = load i64, ptr %slot475, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %rgep2735 = getelementptr i8, ptr %p2734, i64 -24
  %ld2736 = load i64, ptr %rgep2735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2736, ptr %slot482, align 8
  %v2737 = load i64, ptr %slot482, align 8
  %op2738 = sub i64 %v2737, 1
  store i64 %op2738, ptr %slot483, align 8
  %v2739 = load i64, ptr %slot483, align 8
  %cmp2740 = icmp eq i64 %v2739, 0
  %cv2741 = zext i1 %cmp2740 to i32
  store i32 %cv2741, ptr %slot484, align 8
  %v2742 = load i32, ptr %slot484, align 8
  %cv2743 = zext i32 %v2742 to i64
  %cond2744 = icmp ne i64 %cv2743, 0
  br i1 %cond2744, label %bb_rcglast628, label %bb_rcgdec628
bb_rcglast628:
  %v2745 = load i64, ptr %slot475, align 8
  %op2746 = sub i64 %v2745, 32
  store i64 %op2746, ptr %slot485, align 8
  %v2747 = load i64, ptr %slot475, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  %rgep2749 = getelementptr i8, ptr %p2748, i64 -32
  %ld2750 = load i64, ptr %rgep2749, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2750, ptr %slot486, align 8
  %v2751 = load i64, ptr %slot486, align 8
  %cmp2752 = icmp ne i64 %v2751, 0
  %cv2753 = zext i1 %cmp2752 to i32
  store i32 %cv2753, ptr %slot487, align 8
  %v2754 = load i32, ptr %slot487, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcgdec628, label %bb_rcgslow628
bb_rcgslow628:
  %v2757 = load i64, ptr %slot474, align 8
  %v2758 = load i64, ptr %slot471, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2757, i64 %v2758) nomerge, !dbg !142
  br label %bb_rcgdone628
bb_rcgdec628:
  %v2759 = load i64, ptr %slot483, align 8
  %v2760 = load i64, ptr %slot475, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %rgep2762 = getelementptr i8, ptr %p2761, i64 -24
  store i64 %v2759, ptr %rgep2762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear628
bb_rcgclear628:
  %v2763 = load i64, ptr %slot471, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  store i64 0, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone628
bb_rcgdone628:
  br label %bb_rcslotdone612
bb_rcslotowner612:
  %v2765 = load i64, ptr %slot39, align 8
  store i64 %v2765, ptr %slot488, align 8
  %v2766 = load i64, ptr %slot471, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %ld2768 = load i64, ptr %p2767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2768, ptr %slot489, align 8
  %v2769 = load i64, ptr %slot489, align 8
  %cmp2770 = icmp ne i64 %v2769, 0
  %cv2771 = zext i1 %cmp2770 to i32
  store i32 %cv2771, ptr %slot490, align 8
  %v2772 = load i32, ptr %slot490, align 8
  %cv2773 = zext i32 %v2772 to i64
  %cond2774 = icmp ne i64 %cv2773, 0
  br i1 %cond2774, label %bb_rcgnn643, label %bb_rcgdone643
bb_rcgnn643:
  %v2775 = load i64, ptr %slot489, align 8
  %op2776 = sub i64 %v2775, 16
  store i64 %op2776, ptr %slot491, align 8
  %v2777 = load i64, ptr %slot489, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %rgep2779 = getelementptr i8, ptr %p2778, i64 -16
  %ld2780 = load i64, ptr %rgep2779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2780, ptr %slot492, align 8
  %v2781 = load i64, ptr %slot492, align 8
  %op2782 = and i64 %v2781, 4611686018427387906
  store i64 %op2782, ptr %slot493, align 8
  %v2783 = load i64, ptr %slot493, align 8
  %cmp2784 = icmp ne i64 %v2783, 0
  %cv2785 = zext i1 %cmp2784 to i32
  store i32 %cv2785, ptr %slot494, align 8
  %v2786 = load i32, ptr %slot494, align 8
  %cv2787 = zext i32 %v2786 to i64
  %cond2788 = icmp ne i64 %cv2787, 0
  br i1 %cond2788, label %bb_rcgclear643, label %bb_rcgcounted643
bb_rcgcounted643:
  %v2789 = load i64, ptr %slot489, align 8
  %op2790 = sub i64 %v2789, 32
  store i64 %op2790, ptr %slot495, align 8
  %v2791 = load i64, ptr %slot489, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %rgep2793 = getelementptr i8, ptr %p2792, i64 -32
  %ld2794 = load i64, ptr %rgep2793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2794, ptr %slot496, align 8
  %v2795 = load i64, ptr %slot496, align 8
  %op2796 = sub i64 %v2795, 1
  store i64 %op2796, ptr %slot497, align 8
  %v2797 = load i64, ptr %slot497, align 8
  %cmp2798 = icmp eq i64 %v2797, 0
  %cv2799 = zext i1 %cmp2798 to i32
  store i32 %cv2799, ptr %slot498, align 8
  %v2800 = load i32, ptr %slot498, align 8
  %cv2801 = zext i32 %v2800 to i64
  %cond2802 = icmp ne i64 %cv2801, 0
  br i1 %cond2802, label %bb_rcglast643, label %bb_rcgdec643
bb_rcglast643:
  %v2803 = load i64, ptr %slot489, align 8
  %op2804 = sub i64 %v2803, 24
  store i64 %op2804, ptr %slot499, align 8
  %v2805 = load i64, ptr %slot489, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %rgep2807 = getelementptr i8, ptr %p2806, i64 -24
  %ld2808 = load i64, ptr %rgep2807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2808, ptr %slot500, align 8
  %v2809 = load i64, ptr %slot500, align 8
  %cmp2810 = icmp ne i64 %v2809, 0
  %cv2811 = zext i1 %cmp2810 to i32
  store i32 %cv2811, ptr %slot501, align 8
  %v2812 = load i32, ptr %slot501, align 8
  %cv2813 = zext i32 %v2812 to i64
  %cond2814 = icmp ne i64 %cv2813, 0
  br i1 %cond2814, label %bb_rcgdec643, label %bb_rcgslow643
bb_rcgslow643:
  %v2815 = load i64, ptr %slot488, align 8
  %v2816 = load i64, ptr %slot471, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2815, i64 %v2816) nomerge, !dbg !142
  br label %bb_rcgdone643
bb_rcgdec643:
  %v2817 = load i64, ptr %slot497, align 8
  %v2818 = load i64, ptr %slot489, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  %rgep2820 = getelementptr i8, ptr %p2819, i64 -32
  store i64 %v2817, ptr %rgep2820, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear643
bb_rcgclear643:
  %v2821 = load i64, ptr %slot471, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  store i64 0, ptr %p2822, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone643
bb_rcgdone643:
  br label %bb_rcslotdone612
bb_rcslotdone612:
  %v2823 = load i64, ptr %slot6, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %ld2825 = load i32, ptr %p2824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2825, ptr %slot502, align 8
  %v2826 = load i32, ptr %slot502, align 8
  %cv2827 = zext i32 %v2826 to i64
  %cond2828 = icmp ne i64 %cv2827, 0
  br i1 %cond2828, label %bb_rcslotdrop649, label %bb_rcslotdone649
bb_rcslotdrop649:
  %v2829 = load i64, ptr %slot6, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i32 0, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot22, align 8
  store i64 %v2831, ptr %slot503, align 8
  %v2832 = load i64, ptr %slot7, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i32, ptr %p2833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2834, ptr %slot504, align 8
  %v2835 = load i32, ptr %slot504, align 8
  %op2836 = and i32 %v2835, 28
  store i32 %op2836, ptr %slot505, align 8
  %v2837 = load i32, ptr %slot505, align 8
  %cv2838 = zext i32 %v2837 to i64
  %cond2839 = icmp ne i64 %cv2838, 0
  br i1 %cond2839, label %bb_rcslotrole649, label %bb_rcslotowner649
bb_rcslotrole649:
  %v2840 = load i64, ptr %slot39, align 8
  store i64 %v2840, ptr %slot506, align 8
  %v2841 = load i64, ptr %slot506, align 8
  %v2842 = load i64, ptr %slot503, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v2841, i64 %v2842) nomerge, !dbg !142
  br label %bb_rcslotdone649
bb_rcslotowner649:
  %v2843 = load i64, ptr %slot39, align 8
  store i64 %v2843, ptr %slot507, align 8
  %v2844 = load i64, ptr %slot507, align 8
  %v2845 = load i64, ptr %slot503, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v2844, i64 %v2845) nomerge, !dbg !142
  br label %bb_rcslotdone649
bb_rcslotdone649:
  %v2846 = load i64, ptr %slot463, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2847, i64 24, i1 false)
  ret void
bb_i45:
  %v2848 = load i64, ptr %slot28, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  %ld2850 = load i64, ptr %p2849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2850, ptr %slot508, align 8
  %v2851 = load i64, ptr %slot508, align 8
  %v2852 = load i64, ptr %slot27, align 8
  %p2853 = inttoptr i64 %v2851 to ptr
  %p2854 = inttoptr i64 %v2852 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2854, ptr %p2853, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot27, align 8
  %v2856 = load i64, ptr %slot28, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i64 %v2855, ptr %p2857, align 8, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot31, align 8
  store i64 %v2858, ptr %slot509, align 8
  %v2859 = load i64, ptr %slot509, align 8
  %p2860 = inttoptr i64 %v2859 to ptr
  store i32 0, ptr %p2860, align 4, !alias.scope !3, !noalias !4
  %v2861 = load i64, ptr %slot509, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  store i32 1, ptr %p2862, align 4, !alias.scope !3, !noalias !4
  %v2863 = load i64, ptr %slot509, align 8
  %v2864 = load i64, ptr %slot29, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i64 %v2863, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot29, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  %ld2868 = load i64, ptr %p2867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2868, ptr %slot510, align 8
  %v2869 = load i64, ptr %slot28, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  %ld2871 = load i64, ptr %p2870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2871, ptr %slot511, align 8
  %v2872 = load i64, ptr %slot511, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %ld2874 = load i32, ptr %p2873, align 4, !alias.scope !3, !noalias !4
  %ext2875 = zext i32 %ld2874 to i64
  store i64 %ext2875, ptr %slot512, align 8
  %v2876 = load i64, ptr %slot510, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %ld2878 = load i32, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  %ext2879 = zext i32 %ld2878 to i64
  store i64 %ext2879, ptr %slot513, align 8
  %v2880 = load i64, ptr %slot512, align 8
  %v2881 = load i64, ptr %slot513, align 8
  %cmp2882 = icmp eq i64 %v2880, %v2881
  %cv2883 = zext i1 %cmp2882 to i64
  store i64 %cv2883, ptr %slot514, align 8
  %v2884 = load i64, ptr %slot514, align 8
  %v2885 = load i64, ptr %slot28, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  store i64 %v2884, ptr %p2886, align 8, !alias.scope !3, !noalias !4
  %v2887 = load i64, ptr %slot28, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %ld2889 = load i64, ptr %p2888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2889, ptr %slot515, align 8
  %v2890 = load i64, ptr %slot515, align 8
  %cond2891 = icmp ne i64 %v2890, 0
  br i1 %cond2891, label %bb_next710, label %bb_i53
bb_next710:
  %v2892 = load i64, ptr %slot27, align 8
  %v2893 = load i64, ptr %slot28, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  store i64 %v2892, ptr %p2894, align 8, !alias.scope !3, !noalias !4
  %v2895 = load i64, ptr %slot32, align 8
  store i64 %v2895, ptr %slot516, align 8
  %v2896 = load i64, ptr %slot516, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  store i64 0, ptr %p2897, align 8, !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot516, align 8
  %p2900 = inttoptr i64 %v2898 to ptr
  %gep2901 = getelementptr i8, ptr %p2900, i64 8
  %op2899 = ptrtoint ptr %gep2901 to i64
  store i64 %op2899, ptr %slot517, align 8
  %v2902 = load i64, ptr %slot517, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  store i64 0, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  %v2904 = load i64, ptr %slot516, align 8
  %p2906 = inttoptr i64 %v2904 to ptr
  %gep2907 = getelementptr i8, ptr %p2906, i64 16
  %op2905 = ptrtoint ptr %gep2907 to i64
  store i64 %op2905, ptr %slot518, align 8
  %v2908 = load i64, ptr %slot518, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  store i64 0, ptr %p2909, align 8, !alias.scope !3, !noalias !4
  %v2910 = load i64, ptr %slot516, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  store i32 0, ptr %p2911, align 4, !alias.scope !3, !noalias !4
  %v2912 = load i64, ptr %slot14, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i32 1, ptr %p2913, align 4, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot28, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %ld2916 = load i64, ptr %p2915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2916, ptr %slot519, align 8
  %v2917 = load i64, ptr %slot516, align 8
  %p2919 = inttoptr i64 %v2917 to ptr
  %gep2920 = getelementptr i8, ptr %p2919, i64 8
  %op2918 = ptrtoint ptr %gep2920 to i64
  store i64 %op2918, ptr %slot520, align 8
  %v2921 = load i64, ptr %slot40, align 8
  store i64 %v2921, ptr %slot521, align 8
  %v2922 = load i64, ptr %slot519, align 8
  %v2923 = load i64, ptr %slot520, align 8
  %p2924 = inttoptr i64 %v2922 to ptr
  %p2925 = inttoptr i64 %v2923 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2925, ptr %p2924, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2926 = load i64, ptr %slot516, align 8
  %v2927 = load i64, ptr %slot28, align 8
  %p2928 = inttoptr i64 %v2927 to ptr
  store i64 %v2926, ptr %p2928, align 8, !alias.scope !3, !noalias !4
  %v2929 = load i64, ptr %slot28, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %ld2931 = load i64, ptr %p2930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2931, ptr %slot522, align 8
  %v2932 = load i64, ptr %slot15, align 8
  store i64 %v2932, ptr %slot523, align 8
  %v2933 = load i64, ptr %slot522, align 8
  %v2934 = load i64, ptr %slot523, align 8
  %p2935 = inttoptr i64 %v2933 to ptr
  %p2936 = inttoptr i64 %v2934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2936, ptr %p2935, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot11, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  store i32 2, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  %v2939 = load i64, ptr %slot10, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i32 1, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot523, align 8
  %v2942 = load i64, ptr %slot28, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  store i64 %v2941, ptr %p2943, align 8, !alias.scope !3, !noalias !4
  %v2944 = load i64, ptr %slot28, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  %ld2946 = load i64, ptr %p2945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2946, ptr %slot524, align 8
  %v2947 = load i64, ptr %slot28, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %ld2949 = load i64, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2949, ptr %slot525, align 8
  %v2950 = load i64, ptr %slot17, align 8
  store i64 %v2950, ptr %slot526, align 8
  %v2951 = load i64, ptr %slot40, align 8
  store i64 %v2951, ptr %slot527, align 8
  %v2952 = load i64, ptr %slot39, align 8
  %v2953 = load i64, ptr %slot526, align 8
  %v2954 = load i64, ptr %slot525, align 8
  %v2955 = load i64, ptr %slot527, align 8
  %cv2956 = trunc i64 %v2955 to i32
  %call2957 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2952, i64 %v2953, i64 %v2954, i32 %cv2956) nomerge, !dbg !144
  store i32 %call2957, ptr %slot528, align 8
  %v2958 = load i32, ptr %slot528, align 8
  %cv2959 = zext i32 %v2958 to i64
  %cond2960 = icmp ne i64 %cv2959, 0
  br i1 %cond2960, label %bb_rcsuccess727, label %bb_rcfailure727
bb_rcfailure727:
  %v2961 = load i64, ptr %slot39, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  %call2963 = call i32 @myl_rc_take_failure(ptr %p2962) nomerge, !dbg !144
  store i32 %call2963, ptr %slot529, align 8
  %v2964 = load i64, ptr %slot1, align 8
  %p2965 = inttoptr i64 %v2964 to ptr
  %v2966 = load i32, ptr %slot529, align 8
  %call2967 = call i32 @myl_qbe_rc_status(ptr %p2965, i32 %v2966) nomerge, !dbg !144
  store i32 %call2967, ptr %slot530, align 8
  br label %bb_failure
bb_rcsuccess727:
  %v2968 = load i64, ptr %slot10, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 0, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot13, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  store i32 2, ptr %p2971, align 4, !alias.scope !3, !noalias !4
  %v2972 = load i64, ptr %slot12, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  store i32 1, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  %v2974 = load i64, ptr %slot17, align 8
  store i64 %v2974, ptr %slot531, align 8
  %v2975 = load i64, ptr %slot12, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  store i32 0, ptr %p2976, align 4, !alias.scope !3, !noalias !4
  %v2977 = load i64, ptr %slot10, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  %ld2979 = load i32, ptr %p2978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2979, ptr %slot532, align 8
  %v2980 = load i32, ptr %slot532, align 8
  %cv2981 = zext i32 %v2980 to i64
  %cond2982 = icmp ne i64 %cv2981, 0
  br i1 %cond2982, label %bb_rcslotdrop737, label %bb_rcslotdone737
bb_rcslotdrop737:
  %v2983 = load i64, ptr %slot10, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  store i32 0, ptr %p2984, align 4, !alias.scope !3, !noalias !4
  %v2985 = load i64, ptr %slot15, align 8
  store i64 %v2985, ptr %slot533, align 8
  %v2986 = load i64, ptr %slot11, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ld2988 = load i32, ptr %p2987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2988, ptr %slot534, align 8
  %v2989 = load i32, ptr %slot534, align 8
  %op2990 = and i32 %v2989, 28
  store i32 %op2990, ptr %slot535, align 8
  %v2991 = load i32, ptr %slot535, align 8
  %cv2992 = zext i32 %v2991 to i64
  %cond2993 = icmp ne i64 %cv2992, 0
  br i1 %cond2993, label %bb_rcslotrole737, label %bb_rcslotowner737
bb_rcslotrole737:
  %v2994 = load i64, ptr %slot39, align 8
  store i64 %v2994, ptr %slot536, align 8
  %v2995 = load i64, ptr %slot536, align 8
  %v2996 = load i64, ptr %slot533, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2995, i64 %v2996) nomerge, !dbg !144
  br label %bb_rcslotdone737
bb_rcslotowner737:
  %v2997 = load i64, ptr %slot39, align 8
  store i64 %v2997, ptr %slot537, align 8
  %v2998 = load i64, ptr %slot537, align 8
  %v2999 = load i64, ptr %slot533, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2998, i64 %v2999) nomerge, !dbg !144
  br label %bb_rcslotdone737
bb_rcslotdone737:
  %v3000 = load i64, ptr %slot8, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %ld3002 = load i32, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3002, ptr %slot538, align 8
  %v3003 = load i32, ptr %slot538, align 8
  %cv3004 = zext i32 %v3003 to i64
  %cond3005 = icmp ne i64 %cv3004, 0
  br i1 %cond3005, label %bb_rcslotdrop746, label %bb_rcslotdone746
bb_rcslotdrop746:
  %v3006 = load i64, ptr %slot8, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 0, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot23, align 8
  store i64 %v3008, ptr %slot539, align 8
  %v3009 = load i64, ptr %slot9, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %ld3011 = load i32, ptr %p3010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3011, ptr %slot540, align 8
  %v3012 = load i32, ptr %slot540, align 8
  %op3013 = and i32 %v3012, 28
  store i32 %op3013, ptr %slot541, align 8
  %v3014 = load i32, ptr %slot541, align 8
  %cv3015 = zext i32 %v3014 to i64
  %cond3016 = icmp ne i64 %cv3015, 0
  br i1 %cond3016, label %bb_rcslotrole746, label %bb_rcslotowner746
bb_rcslotrole746:
  %v3017 = load i64, ptr %slot39, align 8
  store i64 %v3017, ptr %slot542, align 8
  %v3018 = load i64, ptr %slot539, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  %ld3020 = load i64, ptr %p3019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3020, ptr %slot543, align 8
  %v3021 = load i64, ptr %slot543, align 8
  %cmp3022 = icmp ne i64 %v3021, 0
  %cv3023 = zext i1 %cmp3022 to i32
  store i32 %cv3023, ptr %slot544, align 8
  %v3024 = load i32, ptr %slot544, align 8
  %cv3025 = zext i32 %v3024 to i64
  %cond3026 = icmp ne i64 %cv3025, 0
  br i1 %cond3026, label %bb_rcgnn762, label %bb_rcgdone762
bb_rcgnn762:
  %v3027 = load i64, ptr %slot543, align 8
  %op3028 = sub i64 %v3027, 16
  store i64 %op3028, ptr %slot545, align 8
  %v3029 = load i64, ptr %slot543, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  %rgep3031 = getelementptr i8, ptr %p3030, i64 -16
  %ld3032 = load i64, ptr %rgep3031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3032, ptr %slot546, align 8
  %v3033 = load i64, ptr %slot546, align 8
  %op3034 = and i64 %v3033, 4611686018427387906
  store i64 %op3034, ptr %slot547, align 8
  %v3035 = load i64, ptr %slot547, align 8
  %cmp3036 = icmp ne i64 %v3035, 0
  %cv3037 = zext i1 %cmp3036 to i32
  store i32 %cv3037, ptr %slot548, align 8
  %v3038 = load i32, ptr %slot548, align 8
  %cv3039 = zext i32 %v3038 to i64
  %cond3040 = icmp ne i64 %cv3039, 0
  br i1 %cond3040, label %bb_rcgclear762, label %bb_rcgcounted762
bb_rcgcounted762:
  %v3041 = load i64, ptr %slot543, align 8
  %op3042 = sub i64 %v3041, 24
  store i64 %op3042, ptr %slot549, align 8
  %v3043 = load i64, ptr %slot543, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %rgep3045 = getelementptr i8, ptr %p3044, i64 -24
  %ld3046 = load i64, ptr %rgep3045, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3046, ptr %slot550, align 8
  %v3047 = load i64, ptr %slot550, align 8
  %op3048 = sub i64 %v3047, 1
  store i64 %op3048, ptr %slot551, align 8
  %v3049 = load i64, ptr %slot551, align 8
  %cmp3050 = icmp eq i64 %v3049, 0
  %cv3051 = zext i1 %cmp3050 to i32
  store i32 %cv3051, ptr %slot552, align 8
  %v3052 = load i32, ptr %slot552, align 8
  %cv3053 = zext i32 %v3052 to i64
  %cond3054 = icmp ne i64 %cv3053, 0
  br i1 %cond3054, label %bb_rcglast762, label %bb_rcgdec762
bb_rcglast762:
  %v3055 = load i64, ptr %slot543, align 8
  %op3056 = sub i64 %v3055, 32
  store i64 %op3056, ptr %slot553, align 8
  %v3057 = load i64, ptr %slot543, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %rgep3059 = getelementptr i8, ptr %p3058, i64 -32
  %ld3060 = load i64, ptr %rgep3059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3060, ptr %slot554, align 8
  %v3061 = load i64, ptr %slot554, align 8
  %cmp3062 = icmp ne i64 %v3061, 0
  %cv3063 = zext i1 %cmp3062 to i32
  store i32 %cv3063, ptr %slot555, align 8
  %v3064 = load i32, ptr %slot555, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcgdec762, label %bb_rcgslow762
bb_rcgslow762:
  %v3067 = load i64, ptr %slot542, align 8
  %v3068 = load i64, ptr %slot539, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3067, i64 %v3068) nomerge, !dbg !144
  br label %bb_rcgdone762
bb_rcgdec762:
  %v3069 = load i64, ptr %slot551, align 8
  %v3070 = load i64, ptr %slot543, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %rgep3072 = getelementptr i8, ptr %p3071, i64 -24
  store i64 %v3069, ptr %rgep3072, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear762
bb_rcgclear762:
  %v3073 = load i64, ptr %slot539, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  store i64 0, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone762
bb_rcgdone762:
  br label %bb_rcslotdone746
bb_rcslotowner746:
  %v3075 = load i64, ptr %slot39, align 8
  store i64 %v3075, ptr %slot556, align 8
  %v3076 = load i64, ptr %slot539, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %ld3078 = load i64, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3078, ptr %slot557, align 8
  %v3079 = load i64, ptr %slot557, align 8
  %cmp3080 = icmp ne i64 %v3079, 0
  %cv3081 = zext i1 %cmp3080 to i32
  store i32 %cv3081, ptr %slot558, align 8
  %v3082 = load i32, ptr %slot558, align 8
  %cv3083 = zext i32 %v3082 to i64
  %cond3084 = icmp ne i64 %cv3083, 0
  br i1 %cond3084, label %bb_rcgnn777, label %bb_rcgdone777
bb_rcgnn777:
  %v3085 = load i64, ptr %slot557, align 8
  %op3086 = sub i64 %v3085, 16
  store i64 %op3086, ptr %slot559, align 8
  %v3087 = load i64, ptr %slot557, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %rgep3089 = getelementptr i8, ptr %p3088, i64 -16
  %ld3090 = load i64, ptr %rgep3089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3090, ptr %slot560, align 8
  %v3091 = load i64, ptr %slot560, align 8
  %op3092 = and i64 %v3091, 4611686018427387906
  store i64 %op3092, ptr %slot561, align 8
  %v3093 = load i64, ptr %slot561, align 8
  %cmp3094 = icmp ne i64 %v3093, 0
  %cv3095 = zext i1 %cmp3094 to i32
  store i32 %cv3095, ptr %slot562, align 8
  %v3096 = load i32, ptr %slot562, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcgclear777, label %bb_rcgcounted777
bb_rcgcounted777:
  %v3099 = load i64, ptr %slot557, align 8
  %op3100 = sub i64 %v3099, 32
  store i64 %op3100, ptr %slot563, align 8
  %v3101 = load i64, ptr %slot557, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %rgep3103 = getelementptr i8, ptr %p3102, i64 -32
  %ld3104 = load i64, ptr %rgep3103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3104, ptr %slot564, align 8
  %v3105 = load i64, ptr %slot564, align 8
  %op3106 = sub i64 %v3105, 1
  store i64 %op3106, ptr %slot565, align 8
  %v3107 = load i64, ptr %slot565, align 8
  %cmp3108 = icmp eq i64 %v3107, 0
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot566, align 8
  %v3110 = load i32, ptr %slot566, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcglast777, label %bb_rcgdec777
bb_rcglast777:
  %v3113 = load i64, ptr %slot557, align 8
  %op3114 = sub i64 %v3113, 24
  store i64 %op3114, ptr %slot567, align 8
  %v3115 = load i64, ptr %slot557, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  %rgep3117 = getelementptr i8, ptr %p3116, i64 -24
  %ld3118 = load i64, ptr %rgep3117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3118, ptr %slot568, align 8
  %v3119 = load i64, ptr %slot568, align 8
  %cmp3120 = icmp ne i64 %v3119, 0
  %cv3121 = zext i1 %cmp3120 to i32
  store i32 %cv3121, ptr %slot569, align 8
  %v3122 = load i32, ptr %slot569, align 8
  %cv3123 = zext i32 %v3122 to i64
  %cond3124 = icmp ne i64 %cv3123, 0
  br i1 %cond3124, label %bb_rcgdec777, label %bb_rcgslow777
bb_rcgslow777:
  %v3125 = load i64, ptr %slot556, align 8
  %v3126 = load i64, ptr %slot539, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3125, i64 %v3126) nomerge, !dbg !144
  br label %bb_rcgdone777
bb_rcgdec777:
  %v3127 = load i64, ptr %slot565, align 8
  %v3128 = load i64, ptr %slot557, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %rgep3130 = getelementptr i8, ptr %p3129, i64 -32
  store i64 %v3127, ptr %rgep3130, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear777
bb_rcgclear777:
  %v3131 = load i64, ptr %slot539, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i64 0, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone777
bb_rcgdone777:
  br label %bb_rcslotdone746
bb_rcslotdone746:
  %v3133 = load i64, ptr %slot6, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  %ld3135 = load i32, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3135, ptr %slot570, align 8
  %v3136 = load i32, ptr %slot570, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcslotdrop783, label %bb_rcslotdone783
bb_rcslotdrop783:
  %v3139 = load i64, ptr %slot6, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  store i32 0, ptr %p3140, align 4, !alias.scope !3, !noalias !4
  %v3141 = load i64, ptr %slot22, align 8
  store i64 %v3141, ptr %slot571, align 8
  %v3142 = load i64, ptr %slot7, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot572, align 8
  %v3145 = load i32, ptr %slot572, align 8
  %op3146 = and i32 %v3145, 28
  store i32 %op3146, ptr %slot573, align 8
  %v3147 = load i32, ptr %slot573, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_rcslotrole783, label %bb_rcslotowner783
bb_rcslotrole783:
  %v3150 = load i64, ptr %slot39, align 8
  store i64 %v3150, ptr %slot574, align 8
  %v3151 = load i64, ptr %slot574, align 8
  %v3152 = load i64, ptr %slot571, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3151, i64 %v3152) nomerge, !dbg !144
  br label %bb_rcslotdone783
bb_rcslotowner783:
  %v3153 = load i64, ptr %slot39, align 8
  store i64 %v3153, ptr %slot575, align 8
  %v3154 = load i64, ptr %slot575, align 8
  %v3155 = load i64, ptr %slot571, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3154, i64 %v3155) nomerge, !dbg !144
  br label %bb_rcslotdone783
bb_rcslotdone783:
  %v3156 = load i64, ptr %slot531, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3157, i64 24, i1 false)
  ret void
bb_i53:
  %v3158 = load i64, ptr %slot25, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %ld3160 = load i64, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3160, ptr %slot576, align 8
  %v3161 = load i64, ptr %slot576, align 8
  %v3162 = load i64, ptr %slot28, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  store i64 %v3161, ptr %p3163, align 8, !alias.scope !3, !noalias !4
  %v3164 = load i64, ptr %slot23, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i64, ptr %p3165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3166, ptr %slot577, align 8
  %v3167 = load i64, ptr %slot28, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %ld3169 = load i64, ptr %p3168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3169, ptr %slot578, align 8
  %v3170 = load i64, ptr %slot577, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  %ld3172 = load i64, ptr %p3171, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3172, ptr %slot579, align 8
  %v3173 = load i64, ptr %slot579, align 8
  %v3174 = load i64, ptr %slot578, align 8
  %cmp3175 = icmp eq i64 %v3173, %v3174
  %cv3176 = zext i1 %cmp3175 to i64
  store i64 %cv3176, ptr %slot580, align 8
  %v3177 = load i64, ptr %slot580, align 8
  %cond3178 = icmp ne i64 %v3177, 0
  br i1 %cond3178, label %bb_success841, label %bb_failed841
bb_failed841:
  %v3179 = load i64, ptr %slot1, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  call void @myl_qbe_fail_iteration(ptr %p3180) nomerge, !dbg !146
  unreachable
bb_success841:
  %v3181 = load i64, ptr %slot28, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  store i64 0, ptr %p3182, align 8, !alias.scope !3, !noalias !4
  %v3183 = load i64, ptr %slot24, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %ld3185 = load i64, ptr %p3184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3185, ptr %slot581, align 8
  %v3186 = load i64, ptr %slot581, align 8
  %v3187 = load i64, ptr %slot28, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  store i64 %v3186, ptr %p3188, align 8, !alias.scope !3, !noalias !4
  %v3189 = load i64, ptr %slot29, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 1, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot29, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  %ld3193 = load i64, ptr %p3192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3193, ptr %slot582, align 8
  %v3194 = load i64, ptr %slot28, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  %ld3196 = load i64, ptr %p3195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3196, ptr %slot583, align 8
  %v3197 = load i64, ptr %slot583, align 8
  %v3198 = load i64, ptr %slot582, align 8
  %ovpair3200 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3197, i64 %v3198)
  %op3199 = extractvalue { i64, i1 } %ovpair3200, 0
  %ov3201 = extractvalue { i64, i1 } %ovpair3200, 1
  store i64 %op3199, ptr %slot584, align 8
  %cv3202 = zext i1 %ov3201 to i64
  store i64 %cv3202, ptr %slot585, align 8
  %v3203 = load i64, ptr %slot585, align 8
  %cond3204 = icmp ne i64 %v3203, 0
  br i1 %cond3204, label %bb_overflow845, label %bb_checked845
bb_overflow845:
  %v3205 = load i64, ptr %slot1, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %v3207 = load i64, ptr %slot583, align 8
  %v3208 = load i64, ptr %slot582, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3206, i64 0, i64 %v3207, i64 %v3208, i64 64) nomerge, !dbg !148
  unreachable
bb_checked845:
  %v3209 = load i64, ptr %slot584, align 8
  %v3210 = load i64, ptr %slot28, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i64 %v3209, ptr %p3211, align 8, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot28, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot586, align 8
  %v3215 = load i64, ptr %slot586, align 8
  %v3216 = load i64, ptr %slot24, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i64 %v3215, ptr %p3217, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i61:
  %v3218 = load i64, ptr %slot6, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %ld3220 = load i32, ptr %p3219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3220, ptr %slot587, align 8
  %v3221 = load i32, ptr %slot587, align 8
  %cv3222 = zext i32 %v3221 to i64
  %cond3223 = icmp ne i64 %cv3222, 0
  br i1 %cond3223, label %bb_rcslotdrop850, label %bb_rcslotdone850
bb_rcslotdrop850:
  %v3224 = load i64, ptr %slot6, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  store i32 0, ptr %p3225, align 4, !alias.scope !3, !noalias !4
  %v3226 = load i64, ptr %slot22, align 8
  store i64 %v3226, ptr %slot588, align 8
  %v3227 = load i64, ptr %slot7, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  %ld3229 = load i32, ptr %p3228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3229, ptr %slot589, align 8
  %v3230 = load i32, ptr %slot589, align 8
  %op3231 = and i32 %v3230, 28
  store i32 %op3231, ptr %slot590, align 8
  %v3232 = load i32, ptr %slot590, align 8
  %cv3233 = zext i32 %v3232 to i64
  %cond3234 = icmp ne i64 %cv3233, 0
  br i1 %cond3234, label %bb_rcslotrole850, label %bb_rcslotowner850
bb_rcslotrole850:
  %v3235 = load i64, ptr %slot39, align 8
  store i64 %v3235, ptr %slot591, align 8
  %v3236 = load i64, ptr %slot591, align 8
  %v3237 = load i64, ptr %slot588, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3236, i64 %v3237) nomerge, !dbg !150
  br label %bb_rcslotdone850
bb_rcslotowner850:
  %v3238 = load i64, ptr %slot588, align 8
  %p3240 = inttoptr i64 %v3238 to ptr
  %gep3241 = getelementptr i8, ptr %p3240, i64 0
  %op3239 = ptrtoint ptr %gep3241 to i64
  store i64 %op3239, ptr %slot592, align 8
  %v3242 = load i64, ptr %slot39, align 8
  store i64 %v3242, ptr %slot593, align 8
  %v3243 = load i64, ptr %slot592, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %ld3245 = load i64, ptr %p3244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3245, ptr %slot594, align 8
  %v3246 = load i64, ptr %slot594, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot595, align 8
  %v3249 = load i32, ptr %slot595, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcgnn868, label %bb_rcgdone868
bb_rcgnn868:
  %v3252 = load i64, ptr %slot594, align 8
  %op3253 = sub i64 %v3252, 16
  store i64 %op3253, ptr %slot596, align 8
  %v3254 = load i64, ptr %slot594, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %rgep3256 = getelementptr i8, ptr %p3255, i64 -16
  %ld3257 = load i64, ptr %rgep3256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3257, ptr %slot597, align 8
  %v3258 = load i64, ptr %slot597, align 8
  %op3259 = and i64 %v3258, 4611686018427387906
  store i64 %op3259, ptr %slot598, align 8
  %v3260 = load i64, ptr %slot598, align 8
  %cmp3261 = icmp ne i64 %v3260, 0
  %cv3262 = zext i1 %cmp3261 to i32
  store i32 %cv3262, ptr %slot599, align 8
  %v3263 = load i32, ptr %slot599, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcgclear868, label %bb_rcgcounted868
bb_rcgcounted868:
  %v3266 = load i64, ptr %slot594, align 8
  %op3267 = sub i64 %v3266, 32
  store i64 %op3267, ptr %slot600, align 8
  %v3268 = load i64, ptr %slot594, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %rgep3270 = getelementptr i8, ptr %p3269, i64 -32
  %ld3271 = load i64, ptr %rgep3270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3271, ptr %slot601, align 8
  %v3272 = load i64, ptr %slot601, align 8
  %op3273 = sub i64 %v3272, 1
  store i64 %op3273, ptr %slot602, align 8
  %v3274 = load i64, ptr %slot602, align 8
  %cmp3275 = icmp eq i64 %v3274, 0
  %cv3276 = zext i1 %cmp3275 to i32
  store i32 %cv3276, ptr %slot603, align 8
  %v3277 = load i32, ptr %slot603, align 8
  %cv3278 = zext i32 %v3277 to i64
  %cond3279 = icmp ne i64 %cv3278, 0
  br i1 %cond3279, label %bb_rcglast868, label %bb_rcgdec868
bb_rcglast868:
  %v3280 = load i64, ptr %slot594, align 8
  %op3281 = sub i64 %v3280, 24
  store i64 %op3281, ptr %slot604, align 8
  %v3282 = load i64, ptr %slot594, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %rgep3284 = getelementptr i8, ptr %p3283, i64 -24
  %ld3285 = load i64, ptr %rgep3284, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3285, ptr %slot605, align 8
  %v3286 = load i64, ptr %slot605, align 8
  %cmp3287 = icmp ne i64 %v3286, 0
  %cv3288 = zext i1 %cmp3287 to i32
  store i32 %cv3288, ptr %slot606, align 8
  %v3289 = load i32, ptr %slot606, align 8
  %cv3290 = zext i32 %v3289 to i64
  %cond3291 = icmp ne i64 %cv3290, 0
  br i1 %cond3291, label %bb_rcgdec868, label %bb_rcgslow868
bb_rcgslow868:
  %v3292 = load i64, ptr %slot593, align 8
  %v3293 = load i64, ptr %slot592, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3292, i64 %v3293) nomerge, !dbg !150
  br label %bb_rcgdone868
bb_rcgdec868:
  %v3294 = load i64, ptr %slot602, align 8
  %v3295 = load i64, ptr %slot594, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %rgep3297 = getelementptr i8, ptr %p3296, i64 -32
  store i64 %v3294, ptr %rgep3297, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear868
bb_rcgclear868:
  %v3298 = load i64, ptr %slot592, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i64 0, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone868
bb_rcgdone868:
  %v3300 = load i64, ptr %slot588, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i64 0, ptr %p3301, align 8, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot588, align 8
  %p3304 = inttoptr i64 %v3302 to ptr
  %gep3305 = getelementptr i8, ptr %p3304, i64 8
  %op3303 = ptrtoint ptr %gep3305 to i64
  store i64 %op3303, ptr %slot607, align 8
  %v3306 = load i64, ptr %slot607, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i64 0, ptr %p3307, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone850
bb_rcslotdone850:
  br label %bb_i71
bb_i63:
  br label %bb_i71
bb_i64:
  br label %bb_i71
bb_i65:
  br label %bb_i71
bb_i66:
  br label %bb_i71
bb_i67:
  br label %bb_i71
bb_i68:
  br label %bb_i71
bb_i69:
  br label %bb_i71
bb_i70:
  br label %bb_i71
bb_i71:
  %v3308 = load i64, ptr %slot33, align 8
  store i64 %v3308, ptr %slot608, align 8
  %v3309 = load i64, ptr %slot608, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i32 0, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot608, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 0, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot608, align 8
  %v3314 = load i64, ptr %slot28, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  store i64 %v3313, ptr %p3315, align 8, !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot34, align 8
  store i64 %v3316, ptr %slot609, align 8
  %v3317 = load i64, ptr %slot609, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  store i64 0, ptr %p3318, align 8, !alias.scope !3, !noalias !4
  %v3319 = load i64, ptr %slot609, align 8
  %p3321 = inttoptr i64 %v3319 to ptr
  %gep3322 = getelementptr i8, ptr %p3321, i64 8
  %op3320 = ptrtoint ptr %gep3322 to i64
  store i64 %op3320, ptr %slot610, align 8
  %v3323 = load i64, ptr %slot610, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i64 0, ptr %p3324, align 8, !alias.scope !3, !noalias !4
  %v3325 = load i64, ptr %slot609, align 8
  %p3327 = inttoptr i64 %v3325 to ptr
  %gep3328 = getelementptr i8, ptr %p3327, i64 16
  %op3326 = ptrtoint ptr %gep3328 to i64
  store i64 %op3326, ptr %slot611, align 8
  %v3329 = load i64, ptr %slot611, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i64 0, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot609, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i32 0, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot14, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  store i32 1, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  %v3335 = load i64, ptr %slot28, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  %ld3337 = load i64, ptr %p3336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3337, ptr %slot612, align 8
  %v3338 = load i64, ptr %slot609, align 8
  %p3340 = inttoptr i64 %v3338 to ptr
  %gep3341 = getelementptr i8, ptr %p3340, i64 8
  %op3339 = ptrtoint ptr %gep3341 to i64
  store i64 %op3339, ptr %slot613, align 8
  %v3342 = load i64, ptr %slot40, align 8
  store i64 %v3342, ptr %slot614, align 8
  %v3343 = load i64, ptr %slot612, align 8
  %v3344 = load i64, ptr %slot613, align 8
  %p3345 = inttoptr i64 %v3343 to ptr
  %p3346 = inttoptr i64 %v3344 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3346, ptr %p3345, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v3347 = load i64, ptr %slot609, align 8
  %v3348 = load i64, ptr %slot28, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  store i64 %v3347, ptr %p3349, align 8, !alias.scope !3, !noalias !4
  %v3350 = load i64, ptr %slot28, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i64, ptr %p3351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3352, ptr %slot615, align 8
  %v3353 = load i64, ptr %slot15, align 8
  store i64 %v3353, ptr %slot616, align 8
  %v3354 = load i64, ptr %slot615, align 8
  %v3355 = load i64, ptr %slot616, align 8
  %p3356 = inttoptr i64 %v3354 to ptr
  %p3357 = inttoptr i64 %v3355 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3357, ptr %p3356, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3358 = load i64, ptr %slot11, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  store i32 2, ptr %p3359, align 4, !alias.scope !3, !noalias !4
  %v3360 = load i64, ptr %slot10, align 8
  %p3361 = inttoptr i64 %v3360 to ptr
  store i32 1, ptr %p3361, align 4, !alias.scope !3, !noalias !4
  %v3362 = load i64, ptr %slot616, align 8
  %v3363 = load i64, ptr %slot28, align 8
  %p3364 = inttoptr i64 %v3363 to ptr
  store i64 %v3362, ptr %p3364, align 8, !alias.scope !3, !noalias !4
  %v3365 = load i64, ptr %slot28, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  %ld3367 = load i64, ptr %p3366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3367, ptr %slot617, align 8
  %v3368 = load i64, ptr %slot28, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  %ld3370 = load i64, ptr %p3369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3370, ptr %slot618, align 8
  %v3371 = load i64, ptr %slot17, align 8
  store i64 %v3371, ptr %slot619, align 8
  %v3372 = load i64, ptr %slot40, align 8
  store i64 %v3372, ptr %slot620, align 8
  %v3373 = load i64, ptr %slot39, align 8
  %v3374 = load i64, ptr %slot619, align 8
  %v3375 = load i64, ptr %slot618, align 8
  %v3376 = load i64, ptr %slot620, align 8
  %cv3377 = trunc i64 %v3376 to i32
  %call3378 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3373, i64 %v3374, i64 %v3375, i32 %cv3377) nomerge, !dbg !152
  store i32 %call3378, ptr %slot621, align 8
  %v3379 = load i32, ptr %slot621, align 8
  %cv3380 = zext i32 %v3379 to i64
  %cond3381 = icmp ne i64 %cv3380, 0
  br i1 %cond3381, label %bb_rcsuccess891, label %bb_rcfailure891
bb_rcfailure891:
  %v3382 = load i64, ptr %slot39, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  %call3384 = call i32 @myl_rc_take_failure(ptr %p3383) nomerge, !dbg !152
  store i32 %call3384, ptr %slot622, align 8
  %v3385 = load i64, ptr %slot1, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  %v3387 = load i32, ptr %slot622, align 8
  %call3388 = call i32 @myl_qbe_rc_status(ptr %p3386, i32 %v3387) nomerge, !dbg !152
  store i32 %call3388, ptr %slot623, align 8
  br label %bb_failure
bb_rcsuccess891:
  %v3389 = load i64, ptr %slot10, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  store i32 0, ptr %p3390, align 4, !alias.scope !3, !noalias !4
  %v3391 = load i64, ptr %slot13, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i32 2, ptr %p3392, align 4, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot12, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 1, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot17, align 8
  store i64 %v3395, ptr %slot624, align 8
  %v3396 = load i64, ptr %slot12, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  store i32 0, ptr %p3397, align 4, !alias.scope !3, !noalias !4
  %v3398 = load i64, ptr %slot10, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  %ld3400 = load i32, ptr %p3399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3400, ptr %slot625, align 8
  %v3401 = load i32, ptr %slot625, align 8
  %cv3402 = zext i32 %v3401 to i64
  %cond3403 = icmp ne i64 %cv3402, 0
  br i1 %cond3403, label %bb_rcslotdrop901, label %bb_rcslotdone901
bb_rcslotdrop901:
  %v3404 = load i64, ptr %slot10, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  store i32 0, ptr %p3405, align 4, !alias.scope !3, !noalias !4
  %v3406 = load i64, ptr %slot15, align 8
  store i64 %v3406, ptr %slot626, align 8
  %v3407 = load i64, ptr %slot11, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  %ld3409 = load i32, ptr %p3408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3409, ptr %slot627, align 8
  %v3410 = load i32, ptr %slot627, align 8
  %op3411 = and i32 %v3410, 28
  store i32 %op3411, ptr %slot628, align 8
  %v3412 = load i32, ptr %slot628, align 8
  %cv3413 = zext i32 %v3412 to i64
  %cond3414 = icmp ne i64 %cv3413, 0
  br i1 %cond3414, label %bb_rcslotrole901, label %bb_rcslotowner901
bb_rcslotrole901:
  %v3415 = load i64, ptr %slot39, align 8
  store i64 %v3415, ptr %slot629, align 8
  %v3416 = load i64, ptr %slot629, align 8
  %v3417 = load i64, ptr %slot626, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3416, i64 %v3417) nomerge, !dbg !152
  br label %bb_rcslotdone901
bb_rcslotowner901:
  %v3418 = load i64, ptr %slot39, align 8
  store i64 %v3418, ptr %slot630, align 8
  %v3419 = load i64, ptr %slot630, align 8
  %v3420 = load i64, ptr %slot626, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3419, i64 %v3420) nomerge, !dbg !152
  br label %bb_rcslotdone901
bb_rcslotdone901:
  %v3421 = load i64, ptr %slot8, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %ld3423 = load i32, ptr %p3422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3423, ptr %slot631, align 8
  %v3424 = load i32, ptr %slot631, align 8
  %cv3425 = zext i32 %v3424 to i64
  %cond3426 = icmp ne i64 %cv3425, 0
  br i1 %cond3426, label %bb_rcslotdrop910, label %bb_rcslotdone910
bb_rcslotdrop910:
  %v3427 = load i64, ptr %slot8, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  store i32 0, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  %v3429 = load i64, ptr %slot23, align 8
  store i64 %v3429, ptr %slot632, align 8
  %v3430 = load i64, ptr %slot9, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i32, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3432, ptr %slot633, align 8
  %v3433 = load i32, ptr %slot633, align 8
  %op3434 = and i32 %v3433, 28
  store i32 %op3434, ptr %slot634, align 8
  %v3435 = load i32, ptr %slot634, align 8
  %cv3436 = zext i32 %v3435 to i64
  %cond3437 = icmp ne i64 %cv3436, 0
  br i1 %cond3437, label %bb_rcslotrole910, label %bb_rcslotowner910
bb_rcslotrole910:
  %v3438 = load i64, ptr %slot39, align 8
  store i64 %v3438, ptr %slot635, align 8
  %v3439 = load i64, ptr %slot632, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %ld3441 = load i64, ptr %p3440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3441, ptr %slot636, align 8
  %v3442 = load i64, ptr %slot636, align 8
  %cmp3443 = icmp ne i64 %v3442, 0
  %cv3444 = zext i1 %cmp3443 to i32
  store i32 %cv3444, ptr %slot637, align 8
  %v3445 = load i32, ptr %slot637, align 8
  %cv3446 = zext i32 %v3445 to i64
  %cond3447 = icmp ne i64 %cv3446, 0
  br i1 %cond3447, label %bb_rcgnn926, label %bb_rcgdone926
bb_rcgnn926:
  %v3448 = load i64, ptr %slot636, align 8
  %op3449 = sub i64 %v3448, 16
  store i64 %op3449, ptr %slot638, align 8
  %v3450 = load i64, ptr %slot636, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %rgep3452 = getelementptr i8, ptr %p3451, i64 -16
  %ld3453 = load i64, ptr %rgep3452, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3453, ptr %slot639, align 8
  %v3454 = load i64, ptr %slot639, align 8
  %op3455 = and i64 %v3454, 4611686018427387906
  store i64 %op3455, ptr %slot640, align 8
  %v3456 = load i64, ptr %slot640, align 8
  %cmp3457 = icmp ne i64 %v3456, 0
  %cv3458 = zext i1 %cmp3457 to i32
  store i32 %cv3458, ptr %slot641, align 8
  %v3459 = load i32, ptr %slot641, align 8
  %cv3460 = zext i32 %v3459 to i64
  %cond3461 = icmp ne i64 %cv3460, 0
  br i1 %cond3461, label %bb_rcgclear926, label %bb_rcgcounted926
bb_rcgcounted926:
  %v3462 = load i64, ptr %slot636, align 8
  %op3463 = sub i64 %v3462, 24
  store i64 %op3463, ptr %slot642, align 8
  %v3464 = load i64, ptr %slot636, align 8
  %p3465 = inttoptr i64 %v3464 to ptr
  %rgep3466 = getelementptr i8, ptr %p3465, i64 -24
  %ld3467 = load i64, ptr %rgep3466, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3467, ptr %slot643, align 8
  %v3468 = load i64, ptr %slot643, align 8
  %op3469 = sub i64 %v3468, 1
  store i64 %op3469, ptr %slot644, align 8
  %v3470 = load i64, ptr %slot644, align 8
  %cmp3471 = icmp eq i64 %v3470, 0
  %cv3472 = zext i1 %cmp3471 to i32
  store i32 %cv3472, ptr %slot645, align 8
  %v3473 = load i32, ptr %slot645, align 8
  %cv3474 = zext i32 %v3473 to i64
  %cond3475 = icmp ne i64 %cv3474, 0
  br i1 %cond3475, label %bb_rcglast926, label %bb_rcgdec926
bb_rcglast926:
  %v3476 = load i64, ptr %slot636, align 8
  %op3477 = sub i64 %v3476, 32
  store i64 %op3477, ptr %slot646, align 8
  %v3478 = load i64, ptr %slot636, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  %rgep3480 = getelementptr i8, ptr %p3479, i64 -32
  %ld3481 = load i64, ptr %rgep3480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3481, ptr %slot647, align 8
  %v3482 = load i64, ptr %slot647, align 8
  %cmp3483 = icmp ne i64 %v3482, 0
  %cv3484 = zext i1 %cmp3483 to i32
  store i32 %cv3484, ptr %slot648, align 8
  %v3485 = load i32, ptr %slot648, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcgdec926, label %bb_rcgslow926
bb_rcgslow926:
  %v3488 = load i64, ptr %slot635, align 8
  %v3489 = load i64, ptr %slot632, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3488, i64 %v3489) nomerge, !dbg !152
  br label %bb_rcgdone926
bb_rcgdec926:
  %v3490 = load i64, ptr %slot644, align 8
  %v3491 = load i64, ptr %slot636, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %rgep3493 = getelementptr i8, ptr %p3492, i64 -24
  store i64 %v3490, ptr %rgep3493, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear926
bb_rcgclear926:
  %v3494 = load i64, ptr %slot632, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  store i64 0, ptr %p3495, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone926
bb_rcgdone926:
  br label %bb_rcslotdone910
bb_rcslotowner910:
  %v3496 = load i64, ptr %slot39, align 8
  store i64 %v3496, ptr %slot649, align 8
  %v3497 = load i64, ptr %slot632, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  %ld3499 = load i64, ptr %p3498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3499, ptr %slot650, align 8
  %v3500 = load i64, ptr %slot650, align 8
  %cmp3501 = icmp ne i64 %v3500, 0
  %cv3502 = zext i1 %cmp3501 to i32
  store i32 %cv3502, ptr %slot651, align 8
  %v3503 = load i32, ptr %slot651, align 8
  %cv3504 = zext i32 %v3503 to i64
  %cond3505 = icmp ne i64 %cv3504, 0
  br i1 %cond3505, label %bb_rcgnn941, label %bb_rcgdone941
bb_rcgnn941:
  %v3506 = load i64, ptr %slot650, align 8
  %op3507 = sub i64 %v3506, 16
  store i64 %op3507, ptr %slot652, align 8
  %v3508 = load i64, ptr %slot650, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %rgep3510 = getelementptr i8, ptr %p3509, i64 -16
  %ld3511 = load i64, ptr %rgep3510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3511, ptr %slot653, align 8
  %v3512 = load i64, ptr %slot653, align 8
  %op3513 = and i64 %v3512, 4611686018427387906
  store i64 %op3513, ptr %slot654, align 8
  %v3514 = load i64, ptr %slot654, align 8
  %cmp3515 = icmp ne i64 %v3514, 0
  %cv3516 = zext i1 %cmp3515 to i32
  store i32 %cv3516, ptr %slot655, align 8
  %v3517 = load i32, ptr %slot655, align 8
  %cv3518 = zext i32 %v3517 to i64
  %cond3519 = icmp ne i64 %cv3518, 0
  br i1 %cond3519, label %bb_rcgclear941, label %bb_rcgcounted941
bb_rcgcounted941:
  %v3520 = load i64, ptr %slot650, align 8
  %op3521 = sub i64 %v3520, 32
  store i64 %op3521, ptr %slot656, align 8
  %v3522 = load i64, ptr %slot650, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  %rgep3524 = getelementptr i8, ptr %p3523, i64 -32
  %ld3525 = load i64, ptr %rgep3524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3525, ptr %slot657, align 8
  %v3526 = load i64, ptr %slot657, align 8
  %op3527 = sub i64 %v3526, 1
  store i64 %op3527, ptr %slot658, align 8
  %v3528 = load i64, ptr %slot658, align 8
  %cmp3529 = icmp eq i64 %v3528, 0
  %cv3530 = zext i1 %cmp3529 to i32
  store i32 %cv3530, ptr %slot659, align 8
  %v3531 = load i32, ptr %slot659, align 8
  %cv3532 = zext i32 %v3531 to i64
  %cond3533 = icmp ne i64 %cv3532, 0
  br i1 %cond3533, label %bb_rcglast941, label %bb_rcgdec941
bb_rcglast941:
  %v3534 = load i64, ptr %slot650, align 8
  %op3535 = sub i64 %v3534, 24
  store i64 %op3535, ptr %slot660, align 8
  %v3536 = load i64, ptr %slot650, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  %rgep3538 = getelementptr i8, ptr %p3537, i64 -24
  %ld3539 = load i64, ptr %rgep3538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3539, ptr %slot661, align 8
  %v3540 = load i64, ptr %slot661, align 8
  %cmp3541 = icmp ne i64 %v3540, 0
  %cv3542 = zext i1 %cmp3541 to i32
  store i32 %cv3542, ptr %slot662, align 8
  %v3543 = load i32, ptr %slot662, align 8
  %cv3544 = zext i32 %v3543 to i64
  %cond3545 = icmp ne i64 %cv3544, 0
  br i1 %cond3545, label %bb_rcgdec941, label %bb_rcgslow941
bb_rcgslow941:
  %v3546 = load i64, ptr %slot649, align 8
  %v3547 = load i64, ptr %slot632, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3546, i64 %v3547) nomerge, !dbg !152
  br label %bb_rcgdone941
bb_rcgdec941:
  %v3548 = load i64, ptr %slot658, align 8
  %v3549 = load i64, ptr %slot650, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %rgep3551 = getelementptr i8, ptr %p3550, i64 -32
  store i64 %v3548, ptr %rgep3551, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear941
bb_rcgclear941:
  %v3552 = load i64, ptr %slot632, align 8
  %p3553 = inttoptr i64 %v3552 to ptr
  store i64 0, ptr %p3553, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone941
bb_rcgdone941:
  br label %bb_rcslotdone910
bb_rcslotdone910:
  %v3554 = load i64, ptr %slot6, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  %ld3556 = load i32, ptr %p3555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3556, ptr %slot663, align 8
  %v3557 = load i32, ptr %slot663, align 8
  %cv3558 = zext i32 %v3557 to i64
  %cond3559 = icmp ne i64 %cv3558, 0
  br i1 %cond3559, label %bb_rcslotdrop947, label %bb_rcslotdone947
bb_rcslotdrop947:
  %v3560 = load i64, ptr %slot6, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i32 0, ptr %p3561, align 4, !alias.scope !3, !noalias !4
  %v3562 = load i64, ptr %slot22, align 8
  store i64 %v3562, ptr %slot664, align 8
  %v3563 = load i64, ptr %slot7, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i32, ptr %p3564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3565, ptr %slot665, align 8
  %v3566 = load i32, ptr %slot665, align 8
  %op3567 = and i32 %v3566, 28
  store i32 %op3567, ptr %slot666, align 8
  %v3568 = load i32, ptr %slot666, align 8
  %cv3569 = zext i32 %v3568 to i64
  %cond3570 = icmp ne i64 %cv3569, 0
  br i1 %cond3570, label %bb_rcslotrole947, label %bb_rcslotowner947
bb_rcslotrole947:
  %v3571 = load i64, ptr %slot39, align 8
  store i64 %v3571, ptr %slot667, align 8
  %v3572 = load i64, ptr %slot667, align 8
  %v3573 = load i64, ptr %slot664, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3572, i64 %v3573) nomerge, !dbg !152
  br label %bb_rcslotdone947
bb_rcslotowner947:
  %v3574 = load i64, ptr %slot39, align 8
  store i64 %v3574, ptr %slot668, align 8
  %v3575 = load i64, ptr %slot668, align 8
  %v3576 = load i64, ptr %slot664, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3575, i64 %v3576) nomerge, !dbg !152
  br label %bb_rcslotdone947
bb_rcslotdone947:
  %v3577 = load i64, ptr %slot624, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3578, i64 24, i1 false)
  ret void
bb_failure:
  %v3579 = load i64, ptr %slot5, align 8
  %p3580 = inttoptr i64 %v3579 to ptr
  call void @llvm.memset.p0.i64(ptr %p3580, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !152
  %v3581 = load i64, ptr %slot5, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3582, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v3583 = load i64, ptr %slot5, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  call void @llvm.memset.p0.i64(ptr %p3584, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !152
  %v3585 = load i64, ptr %slot5, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3586, i64 24, i1 false)
  ret void
}

@myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64, i64)
declare i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare i32 @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_loan(i64, i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788", linkageName: "myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7757275231440649711, i64 0, !"myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!128 = !DILocation(line: 23, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!130 = !DILocation(line: 24, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!134 = !DILocation(line: 35, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!136 = !DILocation(line: 38, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!138 = !DILocation(line: 42, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!140 = !DILocation(line: 43, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!142 = !DILocation(line: 45, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!144 = !DILocation(line: 53, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!146 = !DILocation(line: 55, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!148 = !DILocation(line: 59, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!150 = !DILocation(line: 62, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!152 = !DILocation(line: 74, column: 0, scope: !153)
