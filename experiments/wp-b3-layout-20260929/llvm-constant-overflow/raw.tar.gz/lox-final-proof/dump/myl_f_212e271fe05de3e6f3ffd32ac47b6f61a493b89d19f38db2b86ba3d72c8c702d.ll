target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %callresult316 = alloca [24 x i8], align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %callresult506 = alloca [24 x i8], align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %callresult855 = alloca [24 x i8], align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i32, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i32, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i32, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i32, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i32, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i32, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i32, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i32, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i32, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i32, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i32, align 8
  %slot1371 = alloca i32, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i32, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i32, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i32, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i32, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i32, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i32, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i32, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i32, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i32, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i32, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i32, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i32, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i32, align 8
  %slot1469 = alloca i32, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i64, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i32, align 8
  %slot1483 = alloca i32, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i32, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i32, align 8
  %slot1489 = alloca i32, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i32, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i32, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i32, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i32, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i32, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i32, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i32, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i32, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i32, align 8
  %slot1531 = alloca i32, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i32, align 8
  %slot1537 = alloca i32, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i32, align 8
  %slot1540 = alloca i32, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i32, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i32, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i32, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i32, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i32, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i32, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i32, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i32, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i64, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i32, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i32, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i32, align 8
  %slot1583 = alloca i32, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i32, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i64, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i32, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i32, align 8
  %slot1597 = alloca i32, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i32, align 8
  %slot1600 = alloca i32, align 8
  %slot1601 = alloca i32, align 8
  %slot1602 = alloca i32, align 8
  %slot1603 = alloca i32, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i32, align 8
  %slot1606 = alloca i32, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i32, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i32, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i32, align 8
  %slot1618 = alloca i64, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i32, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i32, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i32, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i32, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i32, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i32, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i32, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i32, align 8
  %slot1645 = alloca i32, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i32, align 8
  %slot1651 = alloca i32, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i32, align 8
  %slot1654 = alloca i32, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i32, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i32, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i32, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i64, align 8
  %slot1671 = alloca i32, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i32, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i32, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i32, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i64, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i64, align 8
  %slot1689 = alloca i32, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i32, align 8
  %slot1693 = alloca i32, align 8
  %slot1694 = alloca i32, align 8
  %slot1695 = alloca i32, align 8
  %slot1696 = alloca i64, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i64, align 8
  %slot1700 = alloca i32, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i64, align 8
  %slot1704 = alloca i32, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i32, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i64, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i32, align 8
  %slot1713 = alloca i32, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i32, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i32, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i64, align 8
  %slot1725 = alloca i32, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i64, align 8
  %slot1728 = alloca i64, align 8
  %slot1729 = alloca i32, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i64, align 8
  %slot1732 = alloca i32, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i32, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i32, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i64, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i32, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i32, align 8
  %slot1747 = alloca i64, align 8
  %slot1748 = alloca i64, align 8
  %slot1749 = alloca i32, align 8
  %slot1750 = alloca i64, align 8
  %slot1751 = alloca i64, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i32, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i64, align 8
  %slot1756 = alloca i32, align 8
  %slot1757 = alloca i32, align 8
  %slot1758 = alloca i64, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i64, align 8
  %slot1762 = alloca i32, align 8
  %slot1763 = alloca i32, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i32, align 8
  %slot1766 = alloca i32, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i32, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i64, align 8
  %slot1773 = alloca i32, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i64, align 8
  %slot1777 = alloca i32, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i64, align 8
  %slot1780 = alloca i32, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i64, align 8
  %slot1783 = alloca i32, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i64, align 8
  %slot1787 = alloca i32, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i64, align 8
  %slot1790 = alloca i64, align 8
  %slot1791 = alloca i32, align 8
  %slot1792 = alloca i64, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i32, align 8
  %slot1795 = alloca i64, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i64, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i64, align 8
  %slot1801 = alloca i64, align 8
  %slot1802 = alloca i32, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i32, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i64, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i64, align 8
  %slot1812 = alloca i32, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i64, align 8
  %slot1816 = alloca i32, align 8
  %slot1817 = alloca i64, align 8
  %slot1818 = alloca i64, align 8
  %slot1819 = alloca i32, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i32, align 8
  %slot1823 = alloca i64, align 8
  %slot1824 = alloca i64, align 8
  %slot1825 = alloca i64, align 8
  %slot1826 = alloca i32, align 8
  %slot1827 = alloca i64, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i32, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i64, align 8
  %slot1833 = alloca i32, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i64, align 8
  %slot1836 = alloca i32, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i64, align 8
  %slot1840 = alloca i32, align 8
  %slot1841 = alloca i32, align 8
  %slot1842 = alloca i32, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i64, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i64, align 8
  %slot1848 = alloca i32, align 8
  %slot1849 = alloca i32, align 8
  %slot1850 = alloca i32, align 8
  %slot1851 = alloca i64, align 8
  %slot1852 = alloca i64, align 8
  %slot1853 = alloca i32, align 8
  %slot1854 = alloca i64, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i64, align 8
  %slot1857 = alloca i32, align 8
  %slot1858 = alloca i32, align 8
  %slot1859 = alloca i32, align 8
  %slot1860 = alloca i32, align 8
  %slot1861 = alloca i32, align 8
  %slot1862 = alloca i32, align 8
  %slot1863 = alloca i32, align 8
  %slot1864 = alloca i64, align 8
  %slot1865 = alloca i64, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i32, align 8
  %slot1868 = alloca i64, align 8
  %slot1869 = alloca i64, align 8
  %slot1870 = alloca i64, align 8
  %slot1871 = alloca i32, align 8
  %slot1872 = alloca i64, align 8
  %slot1873 = alloca i64, align 8
  %slot1874 = alloca i64, align 8
  %slot1875 = alloca i32, align 8
  %slot1876 = alloca i32, align 8
  %slot1877 = alloca i32, align 8
  %slot1878 = alloca i64, align 8
  %slot1879 = alloca i32, align 8
  %slot1880 = alloca i32, align 8
  %slot1881 = alloca i64, align 8
  %slot1882 = alloca i64, align 8
  %slot1883 = alloca i32, align 8
  %slot1884 = alloca i64, align 8
  %slot1885 = alloca i64, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i32, align 8
  %slot1888 = alloca i64, align 8
  %slot1889 = alloca i64, align 8
  %slot1890 = alloca i64, align 8
  %slot1891 = alloca i32, align 8
  %slot1892 = alloca i64, align 8
  %slot1893 = alloca i64, align 8
  %slot1894 = alloca i32, align 8
  %slot1895 = alloca i64, align 8
  %slot1896 = alloca i64, align 8
  %slot1897 = alloca i32, align 8
  %slot1898 = alloca i64, align 8
  %slot1899 = alloca i64, align 8
  %slot1900 = alloca i64, align 8
  %slot1901 = alloca i32, align 8
  %slot1902 = alloca i64, align 8
  %slot1903 = alloca i64, align 8
  %slot1904 = alloca i64, align 8
  %slot1905 = alloca i32, align 8
  %slot1906 = alloca i64, align 8
  %slot1907 = alloca i64, align 8
  %slot1908 = alloca i32, align 8
  %slot1909 = alloca i32, align 8
  %slot1910 = alloca i64, align 8
  %slot1911 = alloca i32, align 8
  %slot1912 = alloca i32, align 8
  %slot1913 = alloca i64, align 8
  %slot1914 = alloca i64, align 8
  %slot1915 = alloca i32, align 8
  %slot1916 = alloca i64, align 8
  %slot1917 = alloca i64, align 8
  %slot1918 = alloca i64, align 8
  %slot1919 = alloca i32, align 8
  %slot1920 = alloca i64, align 8
  %slot1921 = alloca i64, align 8
  %slot1922 = alloca i64, align 8
  %slot1923 = alloca i32, align 8
  %slot1924 = alloca i64, align 8
  %slot1925 = alloca i64, align 8
  %slot1926 = alloca i32, align 8
  %slot1927 = alloca i64, align 8
  %slot1928 = alloca i64, align 8
  %slot1929 = alloca i32, align 8
  %slot1930 = alloca i64, align 8
  %slot1931 = alloca i64, align 8
  %slot1932 = alloca i64, align 8
  %slot1933 = alloca i32, align 8
  %slot1934 = alloca i64, align 8
  %slot1935 = alloca i64, align 8
  %slot1936 = alloca i64, align 8
  %slot1937 = alloca i32, align 8
  %slot1938 = alloca i64, align 8
  %slot1939 = alloca i64, align 8
  %slot1940 = alloca i32, align 8
  %slot1941 = alloca i64, align 8
  %slot1942 = alloca i64, align 8
  %slot1943 = alloca i32, align 8
  %slot1944 = alloca i32, align 8
  %slot1945 = alloca i64, align 8
  %slot1946 = alloca i32, align 8
  %slot1947 = alloca i32, align 8
  %slot1948 = alloca i64, align 8
  %slot1949 = alloca i64, align 8
  %slot1950 = alloca i32, align 8
  %slot1951 = alloca i64, align 8
  %slot1952 = alloca i64, align 8
  %slot1953 = alloca i64, align 8
  %slot1954 = alloca i32, align 8
  %slot1955 = alloca i64, align 8
  %slot1956 = alloca i64, align 8
  %slot1957 = alloca i64, align 8
  %slot1958 = alloca i32, align 8
  %slot1959 = alloca i64, align 8
  %slot1960 = alloca i64, align 8
  %slot1961 = alloca i32, align 8
  %slot1962 = alloca i64, align 8
  %slot1963 = alloca i64, align 8
  %slot1964 = alloca i32, align 8
  %slot1965 = alloca i64, align 8
  %slot1966 = alloca i64, align 8
  %slot1967 = alloca i64, align 8
  %slot1968 = alloca i32, align 8
  %slot1969 = alloca i64, align 8
  %slot1970 = alloca i64, align 8
  %slot1971 = alloca i64, align 8
  %slot1972 = alloca i32, align 8
  %slot1973 = alloca i64, align 8
  %slot1974 = alloca i64, align 8
  %slot1975 = alloca i32, align 8
  %slot1976 = alloca i32, align 8
  %slot1977 = alloca i64, align 8
  %slot1978 = alloca i32, align 8
  %slot1979 = alloca i32, align 8
  %slot1980 = alloca i64, align 8
  %slot1981 = alloca i64, align 8
  %slot1982 = alloca i32, align 8
  %slot1983 = alloca i64, align 8
  %slot1984 = alloca i64, align 8
  %slot1985 = alloca i64, align 8
  %slot1986 = alloca i32, align 8
  %slot1987 = alloca i64, align 8
  %slot1988 = alloca i64, align 8
  %slot1989 = alloca i64, align 8
  %slot1990 = alloca i32, align 8
  %slot1991 = alloca i64, align 8
  %slot1992 = alloca i64, align 8
  %slot1993 = alloca i32, align 8
  %slot1994 = alloca i64, align 8
  %slot1995 = alloca i64, align 8
  %slot1996 = alloca i32, align 8
  %slot1997 = alloca i64, align 8
  %slot1998 = alloca i64, align 8
  %slot1999 = alloca i64, align 8
  %slot2000 = alloca i32, align 8
  %slot2001 = alloca i64, align 8
  %slot2002 = alloca i64, align 8
  %slot2003 = alloca i64, align 8
  %slot2004 = alloca i32, align 8
  %slot2005 = alloca i64, align 8
  %slot2006 = alloca i64, align 8
  %slot2007 = alloca i32, align 8
  %slot2008 = alloca i64, align 8
  %slot2009 = alloca i64, align 8
  %slot2010 = alloca i64, align 8
  %slot2011 = alloca i64, align 8
  %slot2012 = alloca i64, align 8
  %slot2013 = alloca i64, align 8
  %slot2014 = alloca i64, align 8
  %slot2015 = alloca i64, align 8
  %slot2016 = alloca i32, align 8
  %slot2017 = alloca i64, align 8
  %slot2018 = alloca i64, align 8
  %slot2019 = alloca i64, align 8
  %slot2020 = alloca i64, align 8
  %slot2021 = alloca i64, align 8
  %callresult2022 = alloca [16 x i8], align 8
  %slot2023 = alloca i64, align 8
  %slot2024 = alloca i64, align 8
  %slot2025 = alloca i32, align 8
  %slot2026 = alloca i32, align 8
  %slot2027 = alloca i32, align 8
  %slot2028 = alloca i32, align 8
  %slot2029 = alloca i64, align 8
  %slot2030 = alloca i32, align 8
  %slot2031 = alloca i32, align 8
  %slot2032 = alloca i64, align 8
  %slot2033 = alloca i64, align 8
  %slot2034 = alloca i32, align 8
  %slot2035 = alloca i64, align 8
  %slot2036 = alloca i64, align 8
  %slot2037 = alloca i64, align 8
  %slot2038 = alloca i32, align 8
  %slot2039 = alloca i64, align 8
  %slot2040 = alloca i64, align 8
  %slot2041 = alloca i64, align 8
  %slot2042 = alloca i32, align 8
  %slot2043 = alloca i64, align 8
  %slot2044 = alloca i64, align 8
  %slot2045 = alloca i32, align 8
  %slot2046 = alloca i64, align 8
  %slot2047 = alloca i64, align 8
  %slot2048 = alloca i32, align 8
  %slot2049 = alloca i64, align 8
  %slot2050 = alloca i64, align 8
  %slot2051 = alloca i64, align 8
  %slot2052 = alloca i32, align 8
  %slot2053 = alloca i64, align 8
  %slot2054 = alloca i64, align 8
  %slot2055 = alloca i64, align 8
  %slot2056 = alloca i32, align 8
  %slot2057 = alloca i64, align 8
  %slot2058 = alloca i64, align 8
  %slot2059 = alloca i32, align 8
  %slot2060 = alloca i64, align 8
  %slot2061 = alloca i64, align 8
  %slot2062 = alloca i32, align 8
  %slot2063 = alloca i64, align 8
  %slot2064 = alloca i64, align 8
  %slot2065 = alloca i64, align 8
  %slot2066 = alloca i64, align 8
  %slot2067 = alloca i64, align 8
  %slot2068 = alloca i64, align 8
  %slot2069 = alloca i64, align 8
  %slot2070 = alloca i32, align 8
  %slot2071 = alloca i32, align 8
  %slot2072 = alloca i32, align 8
  %slot2073 = alloca i32, align 8
  %slot2074 = alloca i64, align 8
  %slot2075 = alloca i64, align 8
  %slot2076 = alloca i64, align 8
  %slot2077 = alloca i64, align 8
  %slot2078 = alloca i32, align 8
  %slot2079 = alloca i32, align 8
  %slot2080 = alloca i32, align 8
  %slot2081 = alloca i64, align 8
  %slot2082 = alloca i64, align 8
  %slot2083 = alloca i32, align 8
  %slot2084 = alloca i64, align 8
  %slot2085 = alloca i64, align 8
  %slot2086 = alloca i64, align 8
  %slot2087 = alloca i32, align 8
  %slot2088 = alloca i64, align 8
  %slot2089 = alloca i32, align 8
  %slot2090 = alloca i32, align 8
  %slot2091 = alloca i32, align 8
  %slot2092 = alloca i64, align 8
  %slot2093 = alloca i64, align 8
  %slot2094 = alloca i32, align 8
  %slot2095 = alloca i32, align 8
  %slot2096 = alloca i32, align 8
  %slot2097 = alloca i32, align 8
  %slot2098 = alloca i64, align 8
  %slot2099 = alloca i32, align 8
  %slot2100 = alloca i32, align 8
  %slot2101 = alloca i64, align 8
  %slot2102 = alloca i64, align 8
  %slot2103 = alloca i64, align 8
  %slot2104 = alloca i64, align 8
  %slot2105 = alloca i64, align 8
  %slot2106 = alloca i64, align 8
  %slot2107 = alloca i64, align 8
  %slot2108 = alloca i64, align 8
  %slot2109 = alloca i64, align 8
  %slot2110 = alloca i32, align 8
  %slot2111 = alloca i32, align 8
  %slot2112 = alloca i32, align 8
  %slot2113 = alloca i64, align 8
  %slot2114 = alloca i32, align 8
  %slot2115 = alloca i64, align 8
  %slot2116 = alloca i32, align 8
  %slot2117 = alloca i32, align 8
  %slot2118 = alloca i64, align 8
  %slot2119 = alloca i64, align 8
  %slot2120 = alloca i32, align 8
  %slot2121 = alloca i64, align 8
  %slot2122 = alloca i32, align 8
  %slot2123 = alloca i32, align 8
  %slot2124 = alloca i64, align 8
  %slot2125 = alloca i64, align 8
  %slot2126 = alloca i32, align 8
  %slot2127 = alloca i64, align 8
  %slot2128 = alloca i32, align 8
  %slot2129 = alloca i32, align 8
  %slot2130 = alloca i64, align 8
  %slot2131 = alloca i64, align 8
  %slot2132 = alloca i32, align 8
  %slot2133 = alloca i64, align 8
  %slot2134 = alloca i64, align 8
  %slot2135 = alloca i64, align 8
  %slot2136 = alloca i32, align 8
  %slot2137 = alloca i64, align 8
  %slot2138 = alloca i64, align 8
  %slot2139 = alloca i64, align 8
  %slot2140 = alloca i32, align 8
  %slot2141 = alloca i64, align 8
  %slot2142 = alloca i64, align 8
  %slot2143 = alloca i32, align 8
  %slot2144 = alloca i64, align 8
  %slot2145 = alloca i64, align 8
  %slot2146 = alloca i32, align 8
  %slot2147 = alloca i64, align 8
  %slot2148 = alloca i64, align 8
  %slot2149 = alloca i64, align 8
  %slot2150 = alloca i32, align 8
  %slot2151 = alloca i64, align 8
  %slot2152 = alloca i64, align 8
  %slot2153 = alloca i64, align 8
  %slot2154 = alloca i32, align 8
  %slot2155 = alloca i64, align 8
  %slot2156 = alloca i64, align 8
  %slot2157 = alloca i32, align 8
  %slot2158 = alloca i32, align 8
  %slot2159 = alloca i64, align 8
  %slot2160 = alloca i32, align 8
  %slot2161 = alloca i32, align 8
  %slot2162 = alloca i64, align 8
  %slot2163 = alloca i64, align 8
  %slot2164 = alloca i32, align 8
  %slot2165 = alloca i64, align 8
  %slot2166 = alloca i64, align 8
  %slot2167 = alloca i64, align 8
  %slot2168 = alloca i32, align 8
  %slot2169 = alloca i64, align 8
  %slot2170 = alloca i64, align 8
  %slot2171 = alloca i64, align 8
  %slot2172 = alloca i32, align 8
  %slot2173 = alloca i64, align 8
  %slot2174 = alloca i64, align 8
  %slot2175 = alloca i32, align 8
  %slot2176 = alloca i64, align 8
  %slot2177 = alloca i64, align 8
  %slot2178 = alloca i32, align 8
  %slot2179 = alloca i64, align 8
  %slot2180 = alloca i64, align 8
  %slot2181 = alloca i64, align 8
  %slot2182 = alloca i32, align 8
  %slot2183 = alloca i64, align 8
  %slot2184 = alloca i64, align 8
  %slot2185 = alloca i64, align 8
  %slot2186 = alloca i32, align 8
  %slot2187 = alloca i64, align 8
  %slot2188 = alloca i64, align 8
  %slot2189 = alloca i32, align 8
  %slot2190 = alloca i32, align 8
  %slot2191 = alloca i64, align 8
  %slot2192 = alloca i32, align 8
  %slot2193 = alloca i32, align 8
  %slot2194 = alloca i64, align 8
  %slot2195 = alloca i64, align 8
  %slot2196 = alloca i32, align 8
  %slot2197 = alloca i64, align 8
  %slot2198 = alloca i64, align 8
  %slot2199 = alloca i64, align 8
  %slot2200 = alloca i32, align 8
  %slot2201 = alloca i64, align 8
  %slot2202 = alloca i64, align 8
  %slot2203 = alloca i64, align 8
  %slot2204 = alloca i32, align 8
  %slot2205 = alloca i64, align 8
  %slot2206 = alloca i64, align 8
  %slot2207 = alloca i32, align 8
  %slot2208 = alloca i64, align 8
  %slot2209 = alloca i64, align 8
  %slot2210 = alloca i32, align 8
  %slot2211 = alloca i64, align 8
  %slot2212 = alloca i64, align 8
  %slot2213 = alloca i64, align 8
  %slot2214 = alloca i32, align 8
  %slot2215 = alloca i64, align 8
  %slot2216 = alloca i64, align 8
  %slot2217 = alloca i64, align 8
  %slot2218 = alloca i32, align 8
  %slot2219 = alloca i64, align 8
  %slot2220 = alloca i64, align 8
  %slot2221 = alloca i32, align 8
  %slot2222 = alloca i32, align 8
  %slot2223 = alloca i64, align 8
  %slot2224 = alloca i32, align 8
  %slot2225 = alloca i32, align 8
  %slot2226 = alloca i64, align 8
  %slot2227 = alloca i64, align 8
  %slot2228 = alloca i64, align 8
  %slot2229 = alloca i64, align 8
  %slot2230 = alloca i64, align 8
  %slot2231 = alloca i32, align 8
  %slot2232 = alloca i64, align 8
  %slot2233 = alloca i32, align 8
  %slot2234 = alloca i32, align 8
  %slot2235 = alloca i64, align 8
  %slot2236 = alloca i64, align 8
  %slot2237 = alloca i64, align 8
  %slot2238 = alloca i64, align 8
  %slot2239 = alloca i64, align 8
  %slot2240 = alloca i64, align 8
  %slot2241 = alloca i64, align 8
  %slot2242 = alloca i64, align 8
  %slot2243 = alloca i64, align 8
  %slot2244 = alloca i64, align 8
  %slot2245 = alloca i64, align 8
  %slot2246 = alloca i64, align 8
  %callresult2247 = alloca [16 x i8], align 8
  %slot2248 = alloca i64, align 8
  %slot2249 = alloca i64, align 8
  %slot2250 = alloca i64, align 8
  %slot2251 = alloca i64, align 8
  %slot2252 = alloca i32, align 8
  %slot2253 = alloca i64, align 8
  %slot2254 = alloca i32, align 8
  %slot2255 = alloca i32, align 8
  %slot2256 = alloca i64, align 8
  %slot2257 = alloca i64, align 8
  %slot2258 = alloca i64, align 8
  %slot2259 = alloca i64, align 8
  %slot2260 = alloca i64, align 8
  %slot2261 = alloca i64, align 8
  %slot2262 = alloca i64, align 8
  %slot2263 = alloca i64, align 8
  %slot2264 = alloca i64, align 8
  %slot2265 = alloca i64, align 8
  %slot2266 = alloca i64, align 8
  %slot2267 = alloca i64, align 8
  %slot2268 = alloca i64, align 8
  %slot2269 = alloca i64, align 8
  %slot2270 = alloca i64, align 8
  %slot2271 = alloca i64, align 8
  %slot2272 = alloca i64, align 8
  %slot2273 = alloca i64, align 8
  %slot2274 = alloca i32, align 8
  %slot2275 = alloca i32, align 8
  %slot2276 = alloca i32, align 8
  %slot2277 = alloca i64, align 8
  %slot2278 = alloca i32, align 8
  %slot2279 = alloca i64, align 8
  %slot2280 = alloca i32, align 8
  %slot2281 = alloca i32, align 8
  %slot2282 = alloca i64, align 8
  %slot2283 = alloca i64, align 8
  %slot2284 = alloca i32, align 8
  %slot2285 = alloca i64, align 8
  %slot2286 = alloca i32, align 8
  %slot2287 = alloca i32, align 8
  %slot2288 = alloca i64, align 8
  %slot2289 = alloca i64, align 8
  %slot2290 = alloca i32, align 8
  %slot2291 = alloca i64, align 8
  %slot2292 = alloca i32, align 8
  %slot2293 = alloca i32, align 8
  %slot2294 = alloca i64, align 8
  %slot2295 = alloca i64, align 8
  %slot2296 = alloca i32, align 8
  %slot2297 = alloca i64, align 8
  %slot2298 = alloca i64, align 8
  %slot2299 = alloca i64, align 8
  %slot2300 = alloca i32, align 8
  %slot2301 = alloca i64, align 8
  %slot2302 = alloca i64, align 8
  %slot2303 = alloca i64, align 8
  %slot2304 = alloca i32, align 8
  %slot2305 = alloca i64, align 8
  %slot2306 = alloca i64, align 8
  %slot2307 = alloca i32, align 8
  %slot2308 = alloca i64, align 8
  %slot2309 = alloca i64, align 8
  %slot2310 = alloca i32, align 8
  %slot2311 = alloca i64, align 8
  %slot2312 = alloca i64, align 8
  %slot2313 = alloca i64, align 8
  %slot2314 = alloca i32, align 8
  %slot2315 = alloca i64, align 8
  %slot2316 = alloca i64, align 8
  %slot2317 = alloca i64, align 8
  %slot2318 = alloca i32, align 8
  %slot2319 = alloca i64, align 8
  %slot2320 = alloca i64, align 8
  %slot2321 = alloca i32, align 8
  %slot2322 = alloca i32, align 8
  %slot2323 = alloca i64, align 8
  %slot2324 = alloca i32, align 8
  %slot2325 = alloca i32, align 8
  %slot2326 = alloca i64, align 8
  %slot2327 = alloca i64, align 8
  %slot2328 = alloca i32, align 8
  %slot2329 = alloca i64, align 8
  %slot2330 = alloca i64, align 8
  %slot2331 = alloca i64, align 8
  %slot2332 = alloca i32, align 8
  %slot2333 = alloca i64, align 8
  %slot2334 = alloca i64, align 8
  %slot2335 = alloca i64, align 8
  %slot2336 = alloca i32, align 8
  %slot2337 = alloca i64, align 8
  %slot2338 = alloca i64, align 8
  %slot2339 = alloca i32, align 8
  %slot2340 = alloca i64, align 8
  %slot2341 = alloca i64, align 8
  %slot2342 = alloca i32, align 8
  %slot2343 = alloca i64, align 8
  %slot2344 = alloca i64, align 8
  %slot2345 = alloca i64, align 8
  %slot2346 = alloca i32, align 8
  %slot2347 = alloca i64, align 8
  %slot2348 = alloca i64, align 8
  %slot2349 = alloca i64, align 8
  %slot2350 = alloca i32, align 8
  %slot2351 = alloca i64, align 8
  %slot2352 = alloca i64, align 8
  %slot2353 = alloca i32, align 8
  %slot2354 = alloca i32, align 8
  %slot2355 = alloca i64, align 8
  %slot2356 = alloca i32, align 8
  %slot2357 = alloca i32, align 8
  %slot2358 = alloca i64, align 8
  %slot2359 = alloca i64, align 8
  %slot2360 = alloca i32, align 8
  %slot2361 = alloca i64, align 8
  %slot2362 = alloca i64, align 8
  %slot2363 = alloca i64, align 8
  %slot2364 = alloca i32, align 8
  %slot2365 = alloca i64, align 8
  %slot2366 = alloca i64, align 8
  %slot2367 = alloca i64, align 8
  %slot2368 = alloca i32, align 8
  %slot2369 = alloca i64, align 8
  %slot2370 = alloca i64, align 8
  %slot2371 = alloca i32, align 8
  %slot2372 = alloca i64, align 8
  %slot2373 = alloca i64, align 8
  %slot2374 = alloca i32, align 8
  %slot2375 = alloca i64, align 8
  %slot2376 = alloca i64, align 8
  %slot2377 = alloca i64, align 8
  %slot2378 = alloca i32, align 8
  %slot2379 = alloca i64, align 8
  %slot2380 = alloca i64, align 8
  %slot2381 = alloca i64, align 8
  %slot2382 = alloca i32, align 8
  %slot2383 = alloca i64, align 8
  %slot2384 = alloca i64, align 8
  %slot2385 = alloca i32, align 8
  %slot2386 = alloca i32, align 8
  %slot2387 = alloca i64, align 8
  %slot2388 = alloca i32, align 8
  %slot2389 = alloca i32, align 8
  %slot2390 = alloca i64, align 8
  %slot2391 = alloca i64, align 8
  %slot2392 = alloca i64, align 8
  %slot2393 = alloca i64, align 8
  %slot2394 = alloca i64, align 8
  %slot2395 = alloca i64, align 8
  %slot2396 = alloca i64, align 8
  %slot2397 = alloca i64, align 8
  %slot2398 = alloca i32, align 8
  %slot2399 = alloca i64, align 8
  %slot2400 = alloca i64, align 8
  %slot2401 = alloca i64, align 8
  %slot2402 = alloca i64, align 8
  %slot2403 = alloca i64, align 8
  %callresult2404 = alloca [16 x i8], align 8
  %slot2405 = alloca i64, align 8
  %slot2406 = alloca i64, align 8
  %slot2407 = alloca i32, align 8
  %slot2408 = alloca i32, align 8
  %slot2409 = alloca i32, align 8
  %slot2410 = alloca i32, align 8
  %slot2411 = alloca i64, align 8
  %slot2412 = alloca i32, align 8
  %slot2413 = alloca i32, align 8
  %slot2414 = alloca i64, align 8
  %slot2415 = alloca i64, align 8
  %slot2416 = alloca i32, align 8
  %slot2417 = alloca i64, align 8
  %slot2418 = alloca i64, align 8
  %slot2419 = alloca i64, align 8
  %slot2420 = alloca i32, align 8
  %slot2421 = alloca i64, align 8
  %slot2422 = alloca i64, align 8
  %slot2423 = alloca i64, align 8
  %slot2424 = alloca i32, align 8
  %slot2425 = alloca i64, align 8
  %slot2426 = alloca i64, align 8
  %slot2427 = alloca i32, align 8
  %slot2428 = alloca i64, align 8
  %slot2429 = alloca i64, align 8
  %slot2430 = alloca i32, align 8
  %slot2431 = alloca i64, align 8
  %slot2432 = alloca i64, align 8
  %slot2433 = alloca i64, align 8
  %slot2434 = alloca i32, align 8
  %slot2435 = alloca i64, align 8
  %slot2436 = alloca i64, align 8
  %slot2437 = alloca i64, align 8
  %slot2438 = alloca i32, align 8
  %slot2439 = alloca i64, align 8
  %slot2440 = alloca i64, align 8
  %slot2441 = alloca i32, align 8
  %slot2442 = alloca i64, align 8
  %slot2443 = alloca i64, align 8
  %slot2444 = alloca i32, align 8
  %slot2445 = alloca i64, align 8
  %slot2446 = alloca i64, align 8
  %slot2447 = alloca i64, align 8
  %slot2448 = alloca i64, align 8
  %slot2449 = alloca i64, align 8
  %slot2450 = alloca i64, align 8
  %slot2451 = alloca i64, align 8
  %slot2452 = alloca i32, align 8
  %slot2453 = alloca i32, align 8
  %slot2454 = alloca i32, align 8
  %slot2455 = alloca i32, align 8
  %slot2456 = alloca i64, align 8
  %slot2457 = alloca i64, align 8
  %slot2458 = alloca i64, align 8
  %slot2459 = alloca i64, align 8
  %slot2460 = alloca i32, align 8
  %slot2461 = alloca i32, align 8
  %slot2462 = alloca i32, align 8
  %slot2463 = alloca i64, align 8
  %slot2464 = alloca i64, align 8
  %slot2465 = alloca i32, align 8
  %slot2466 = alloca i64, align 8
  %slot2467 = alloca i64, align 8
  %slot2468 = alloca i64, align 8
  %slot2469 = alloca i32, align 8
  %slot2470 = alloca i64, align 8
  %slot2471 = alloca i32, align 8
  %slot2472 = alloca i32, align 8
  %slot2473 = alloca i32, align 8
  %slot2474 = alloca i64, align 8
  %slot2475 = alloca i64, align 8
  %slot2476 = alloca i32, align 8
  %slot2477 = alloca i32, align 8
  %slot2478 = alloca i32, align 8
  %slot2479 = alloca i32, align 8
  %slot2480 = alloca i64, align 8
  %slot2481 = alloca i32, align 8
  %slot2482 = alloca i32, align 8
  %slot2483 = alloca i64, align 8
  %slot2484 = alloca i64, align 8
  %slot2485 = alloca i64, align 8
  %slot2486 = alloca i64, align 8
  %slot2487 = alloca i64, align 8
  %slot2488 = alloca i64, align 8
  %slot2489 = alloca i64, align 8
  %slot2490 = alloca i64, align 8
  %slot2491 = alloca i64, align 8
  %slot2492 = alloca i32, align 8
  %slot2493 = alloca i32, align 8
  %slot2494 = alloca i32, align 8
  %slot2495 = alloca i64, align 8
  %slot2496 = alloca i32, align 8
  %slot2497 = alloca i64, align 8
  %slot2498 = alloca i32, align 8
  %slot2499 = alloca i32, align 8
  %slot2500 = alloca i64, align 8
  %slot2501 = alloca i64, align 8
  %slot2502 = alloca i32, align 8
  %slot2503 = alloca i64, align 8
  %slot2504 = alloca i32, align 8
  %slot2505 = alloca i32, align 8
  %slot2506 = alloca i64, align 8
  %slot2507 = alloca i64, align 8
  %slot2508 = alloca i32, align 8
  %slot2509 = alloca i64, align 8
  %slot2510 = alloca i32, align 8
  %slot2511 = alloca i32, align 8
  %slot2512 = alloca i64, align 8
  %slot2513 = alloca i64, align 8
  %slot2514 = alloca i32, align 8
  %slot2515 = alloca i64, align 8
  %slot2516 = alloca i64, align 8
  %slot2517 = alloca i64, align 8
  %slot2518 = alloca i32, align 8
  %slot2519 = alloca i64, align 8
  %slot2520 = alloca i64, align 8
  %slot2521 = alloca i64, align 8
  %slot2522 = alloca i32, align 8
  %slot2523 = alloca i64, align 8
  %slot2524 = alloca i64, align 8
  %slot2525 = alloca i32, align 8
  %slot2526 = alloca i64, align 8
  %slot2527 = alloca i64, align 8
  %slot2528 = alloca i32, align 8
  %slot2529 = alloca i64, align 8
  %slot2530 = alloca i64, align 8
  %slot2531 = alloca i64, align 8
  %slot2532 = alloca i32, align 8
  %slot2533 = alloca i64, align 8
  %slot2534 = alloca i64, align 8
  %slot2535 = alloca i64, align 8
  %slot2536 = alloca i32, align 8
  %slot2537 = alloca i64, align 8
  %slot2538 = alloca i64, align 8
  %slot2539 = alloca i32, align 8
  %slot2540 = alloca i32, align 8
  %slot2541 = alloca i64, align 8
  %slot2542 = alloca i32, align 8
  %slot2543 = alloca i32, align 8
  %slot2544 = alloca i64, align 8
  %slot2545 = alloca i64, align 8
  %slot2546 = alloca i32, align 8
  %slot2547 = alloca i64, align 8
  %slot2548 = alloca i64, align 8
  %slot2549 = alloca i64, align 8
  %slot2550 = alloca i32, align 8
  %slot2551 = alloca i64, align 8
  %slot2552 = alloca i64, align 8
  %slot2553 = alloca i64, align 8
  %slot2554 = alloca i32, align 8
  %slot2555 = alloca i64, align 8
  %slot2556 = alloca i64, align 8
  %slot2557 = alloca i32, align 8
  %slot2558 = alloca i64, align 8
  %slot2559 = alloca i64, align 8
  %slot2560 = alloca i32, align 8
  %slot2561 = alloca i64, align 8
  %slot2562 = alloca i64, align 8
  %slot2563 = alloca i64, align 8
  %slot2564 = alloca i32, align 8
  %slot2565 = alloca i64, align 8
  %slot2566 = alloca i64, align 8
  %slot2567 = alloca i64, align 8
  %slot2568 = alloca i32, align 8
  %slot2569 = alloca i64, align 8
  %slot2570 = alloca i64, align 8
  %slot2571 = alloca i32, align 8
  %slot2572 = alloca i32, align 8
  %slot2573 = alloca i64, align 8
  %slot2574 = alloca i32, align 8
  %slot2575 = alloca i32, align 8
  %slot2576 = alloca i64, align 8
  %slot2577 = alloca i64, align 8
  %slot2578 = alloca i32, align 8
  %slot2579 = alloca i64, align 8
  %slot2580 = alloca i64, align 8
  %slot2581 = alloca i64, align 8
  %slot2582 = alloca i32, align 8
  %slot2583 = alloca i64, align 8
  %slot2584 = alloca i64, align 8
  %slot2585 = alloca i64, align 8
  %slot2586 = alloca i32, align 8
  %slot2587 = alloca i64, align 8
  %slot2588 = alloca i64, align 8
  %slot2589 = alloca i32, align 8
  %slot2590 = alloca i64, align 8
  %slot2591 = alloca i64, align 8
  %slot2592 = alloca i32, align 8
  %slot2593 = alloca i64, align 8
  %slot2594 = alloca i64, align 8
  %slot2595 = alloca i64, align 8
  %slot2596 = alloca i32, align 8
  %slot2597 = alloca i64, align 8
  %slot2598 = alloca i64, align 8
  %slot2599 = alloca i64, align 8
  %slot2600 = alloca i32, align 8
  %slot2601 = alloca i64, align 8
  %slot2602 = alloca i64, align 8
  %slot2603 = alloca i32, align 8
  %slot2604 = alloca i32, align 8
  %slot2605 = alloca i64, align 8
  %slot2606 = alloca i32, align 8
  %slot2607 = alloca i32, align 8
  %slot2608 = alloca i64, align 8
  %slot2609 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v2610 = load i64, ptr %slot1, align 8
  %op2611 = add i64 %v2610, 32
  store i64 %op2611, ptr %slot5, align 8
  %mem2612 = alloca i8, i64 24, align 8
  %ptr2613 = ptrtoint ptr %mem2612 to i64
  store i64 %ptr2613, ptr %slot6, align 8
  %mem2614 = alloca i8, i64 8, align 8
  %ptr2615 = ptrtoint ptr %mem2614 to i64
  store i64 %ptr2615, ptr %slot7, align 8
  %mem2616 = alloca i8, i64 8, align 8
  %ptr2617 = ptrtoint ptr %mem2616 to i64
  store i64 %ptr2617, ptr %slot8, align 8
  %mem2618 = alloca i8, i64 8, align 8
  %ptr2619 = ptrtoint ptr %mem2618 to i64
  store i64 %ptr2619, ptr %slot9, align 8
  %mem2620 = alloca i8, i64 8, align 8
  %ptr2621 = ptrtoint ptr %mem2620 to i64
  store i64 %ptr2621, ptr %slot10, align 8
  %mem2622 = alloca i8, i64 8, align 8
  %ptr2623 = ptrtoint ptr %mem2622 to i64
  store i64 %ptr2623, ptr %slot11, align 8
  %mem2624 = alloca i8, i64 8, align 8
  %ptr2625 = ptrtoint ptr %mem2624 to i64
  store i64 %ptr2625, ptr %slot12, align 8
  %mem2626 = alloca i8, i64 8, align 8
  %ptr2627 = ptrtoint ptr %mem2626 to i64
  store i64 %ptr2627, ptr %slot13, align 8
  %mem2628 = alloca i8, i64 8, align 8
  %ptr2629 = ptrtoint ptr %mem2628 to i64
  store i64 %ptr2629, ptr %slot14, align 8
  %mem2630 = alloca i8, i64 8, align 8
  %ptr2631 = ptrtoint ptr %mem2630 to i64
  store i64 %ptr2631, ptr %slot15, align 8
  %mem2632 = alloca i8, i64 8, align 8
  %ptr2633 = ptrtoint ptr %mem2632 to i64
  store i64 %ptr2633, ptr %slot16, align 8
  %mem2634 = alloca i8, i64 8, align 8
  %ptr2635 = ptrtoint ptr %mem2634 to i64
  store i64 %ptr2635, ptr %slot17, align 8
  %mem2636 = alloca i8, i64 8, align 8
  %ptr2637 = ptrtoint ptr %mem2636 to i64
  store i64 %ptr2637, ptr %slot18, align 8
  %mem2638 = alloca i8, i64 8, align 8
  %ptr2639 = ptrtoint ptr %mem2638 to i64
  store i64 %ptr2639, ptr %slot19, align 8
  %mem2640 = alloca i8, i64 8, align 8
  %ptr2641 = ptrtoint ptr %mem2640 to i64
  store i64 %ptr2641, ptr %slot20, align 8
  %mem2642 = alloca i8, i64 8, align 8
  %ptr2643 = ptrtoint ptr %mem2642 to i64
  store i64 %ptr2643, ptr %slot21, align 8
  %mem2644 = alloca i8, i64 304, align 8
  %ptr2645 = ptrtoint ptr %mem2644 to i64
  store i64 %ptr2645, ptr %slot22, align 8
  %mem2646 = alloca i8, i64 8, align 8
  %ptr2647 = ptrtoint ptr %mem2646 to i64
  store i64 %ptr2647, ptr %slot23, align 8
  %mem2648 = alloca i8, i64 304, align 8
  %ptr2649 = ptrtoint ptr %mem2648 to i64
  store i64 %ptr2649, ptr %slot24, align 8
  %mem2650 = alloca i8, i64 8, align 8
  %ptr2651 = ptrtoint ptr %mem2650 to i64
  store i64 %ptr2651, ptr %slot25, align 8
  %mem2652 = alloca i8, i64 8, align 8
  %ptr2653 = ptrtoint ptr %mem2652 to i64
  store i64 %ptr2653, ptr %slot26, align 8
  %mem2654 = alloca i8, i64 8, align 8
  %ptr2655 = ptrtoint ptr %mem2654 to i64
  store i64 %ptr2655, ptr %slot27, align 8
  %mem2656 = alloca i8, i64 8, align 8
  %ptr2657 = ptrtoint ptr %mem2656 to i64
  store i64 %ptr2657, ptr %slot28, align 8
  %mem2658 = alloca i8, i64 8, align 8
  %ptr2659 = ptrtoint ptr %mem2658 to i64
  store i64 %ptr2659, ptr %slot29, align 8
  %mem2660 = alloca i8, i64 8, align 8
  %ptr2661 = ptrtoint ptr %mem2660 to i64
  store i64 %ptr2661, ptr %slot30, align 8
  %mem2662 = alloca i8, i64 8, align 8
  %ptr2663 = ptrtoint ptr %mem2662 to i64
  store i64 %ptr2663, ptr %slot31, align 8
  %mem2664 = alloca i8, i64 8, align 8
  %ptr2665 = ptrtoint ptr %mem2664 to i64
  store i64 %ptr2665, ptr %slot32, align 8
  %mem2666 = alloca i8, i64 8, align 8
  %ptr2667 = ptrtoint ptr %mem2666 to i64
  store i64 %ptr2667, ptr %slot33, align 8
  %mem2668 = alloca i8, i64 8, align 8
  %ptr2669 = ptrtoint ptr %mem2668 to i64
  store i64 %ptr2669, ptr %slot34, align 8
  %mem2670 = alloca i8, i64 32, align 8
  %ptr2671 = ptrtoint ptr %mem2670 to i64
  store i64 %ptr2671, ptr %slot35, align 8
  %mem2672 = alloca i8, i64 8, align 8
  %ptr2673 = ptrtoint ptr %mem2672 to i64
  store i64 %ptr2673, ptr %slot36, align 8
  %mem2674 = alloca i8, i64 16, align 8
  %ptr2675 = ptrtoint ptr %mem2674 to i64
  store i64 %ptr2675, ptr %slot37, align 8
  %mem2676 = alloca i8, i64 208, align 8
  %ptr2677 = ptrtoint ptr %mem2676 to i64
  store i64 %ptr2677, ptr %slot38, align 8
  %mem2678 = alloca i8, i64 16, align 8
  %ptr2679 = ptrtoint ptr %mem2678 to i64
  store i64 %ptr2679, ptr %slot39, align 8
  %mem2680 = alloca i8, i64 8, align 8
  %ptr2681 = ptrtoint ptr %mem2680 to i64
  store i64 %ptr2681, ptr %slot40, align 8
  %mem2682 = alloca i8, i64 8, align 8
  %ptr2683 = ptrtoint ptr %mem2682 to i64
  store i64 %ptr2683, ptr %slot41, align 8
  %mem2684 = alloca i8, i64 8, align 8
  %ptr2685 = ptrtoint ptr %mem2684 to i64
  store i64 %ptr2685, ptr %slot42, align 8
  %mem2686 = alloca i8, i64 208, align 8
  %ptr2687 = ptrtoint ptr %mem2686 to i64
  store i64 %ptr2687, ptr %slot43, align 8
  %mem2688 = alloca i8, i64 8, align 8
  %ptr2689 = ptrtoint ptr %mem2688 to i64
  store i64 %ptr2689, ptr %slot44, align 8
  %mem2690 = alloca i8, i64 8, align 8
  %ptr2691 = ptrtoint ptr %mem2690 to i64
  store i64 %ptr2691, ptr %slot45, align 8
  %mem2692 = alloca i8, i64 8, align 8
  %ptr2693 = ptrtoint ptr %mem2692 to i64
  store i64 %ptr2693, ptr %slot46, align 8
  %mem2694 = alloca i8, i64 8, align 8
  %ptr2695 = ptrtoint ptr %mem2694 to i64
  store i64 %ptr2695, ptr %slot47, align 8
  %mem2696 = alloca i8, i64 8, align 8
  %ptr2697 = ptrtoint ptr %mem2696 to i64
  store i64 %ptr2697, ptr %slot48, align 8
  %mem2698 = alloca i8, i64 8, align 8
  %ptr2699 = ptrtoint ptr %mem2698 to i64
  store i64 %ptr2699, ptr %slot49, align 8
  %mem2700 = alloca i8, i64 24, align 8
  %ptr2701 = ptrtoint ptr %mem2700 to i64
  store i64 %ptr2701, ptr %slot50, align 8
  %mem2702 = alloca i8, i64 24, align 8
  %ptr2703 = ptrtoint ptr %mem2702 to i64
  store i64 %ptr2703, ptr %slot51, align 8
  %mem2704 = alloca i8, i64 304, align 8
  %ptr2705 = ptrtoint ptr %mem2704 to i64
  store i64 %ptr2705, ptr %slot52, align 8
  %mem2706 = alloca i8, i64 24, align 8
  %ptr2707 = ptrtoint ptr %mem2706 to i64
  store i64 %ptr2707, ptr %slot53, align 8
  %mem2708 = alloca i8, i64 24, align 8
  %ptr2709 = ptrtoint ptr %mem2708 to i64
  store i64 %ptr2709, ptr %slot54, align 8
  %mem2710 = alloca i8, i64 304, align 8
  %ptr2711 = ptrtoint ptr %mem2710 to i64
  store i64 %ptr2711, ptr %slot55, align 8
  %mem2712 = alloca i8, i64 208, align 8
  %ptr2713 = ptrtoint ptr %mem2712 to i64
  store i64 %ptr2713, ptr %slot56, align 8
  %mem2714 = alloca i8, i64 24, align 8
  %ptr2715 = ptrtoint ptr %mem2714 to i64
  store i64 %ptr2715, ptr %slot57, align 8
  %mem2716 = alloca i8, i64 24, align 8
  %ptr2717 = ptrtoint ptr %mem2716 to i64
  store i64 %ptr2717, ptr %slot58, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem2718 = alloca i8, i64 8, align 8
  %ptr2719 = ptrtoint ptr %mem2718 to i64
  store i64 %ptr2719, ptr %slot59, align 8
  %v2720 = load i64, ptr %slot1, align 8
  %op2721 = add i64 %v2720, 64
  store i64 %op2721, ptr %slot60, align 8
  %v2722 = load i64, ptr %slot60, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %ld2724 = load i64, ptr %p2723, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2724, ptr %slot61, align 8
  %stack2725 = call ptr @llvm.stacksave()
  %stackaddr2726 = ptrtoint ptr %stack2725 to i64
  %v2727 = load i64, ptr %slot61, align 8
  %cmp2728 = icmp ult i64 %stackaddr2726, %v2727
  %cv2729 = zext i1 %cmp2728 to i64
  store i64 %cv2729, ptr %slot62, align 8
  %v2730 = load i64, ptr %slot62, align 8
  %cond2731 = icmp ne i64 %v2730, 0
  br i1 %cond2731, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v2732 = load i64, ptr %slot1, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  call void @myl_qbe_fail_frame(ptr %p2733) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v2734 = load i64, ptr %slot30, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  store i64 0, ptr %p2735, align 8, !alias.scope !3, !noalias !4
  %v2736 = load i64, ptr %slot33, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  store i64 0, ptr %p2737, align 8, !alias.scope !3, !noalias !4
  %v2738 = load i64, ptr %slot40, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  store i64 0, ptr %p2739, align 8, !alias.scope !3, !noalias !4
  %v2740 = load i64, ptr %slot41, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  store i64 0, ptr %p2741, align 8, !alias.scope !3, !noalias !4
  %v2742 = load i64, ptr %slot42, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  store i64 0, ptr %p2743, align 8, !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot2, align 8
  %v2745 = load i64, ptr %slot26, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  store i64 %v2744, ptr %p2746, align 8, !alias.scope !3, !noalias !4
  %v2747 = load i64, ptr %slot3, align 8
  %v2748 = load i64, ptr %slot27, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  store i64 %v2747, ptr %p2749, align 8, !alias.scope !3, !noalias !4
  %v2750 = load i64, ptr %slot4, align 8
  %v2751 = load i64, ptr %slot28, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  store i64 %v2750, ptr %p2752, align 8, !alias.scope !3, !noalias !4
  %v2753 = load i64, ptr %slot1, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %call2755 = call ptr @myl_qbe_heap(ptr %p2754) nomerge, !dbg !112
  %calladdr2756 = ptrtoint ptr %call2755 to i64
  store i64 %calladdr2756, ptr %slot63, align 8
  %v2757 = load i64, ptr %slot1, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %call2759 = call i64 @myl_qbe_region_mark(ptr %p2758) nomerge, !dbg !112
  store i64 %call2759, ptr %slot64, align 8
  %v2760 = load i64, ptr %slot7, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  store i32 0, ptr %p2761, align 4, !alias.scope !3, !noalias !4
  %v2762 = load i64, ptr %slot8, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  store i32 0, ptr %p2763, align 4, !alias.scope !3, !noalias !4
  %v2764 = load i64, ptr %slot9, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  store i32 0, ptr %p2765, align 4, !alias.scope !3, !noalias !4
  %v2766 = load i64, ptr %slot10, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  store i32 0, ptr %p2767, align 4, !alias.scope !3, !noalias !4
  %v2768 = load i64, ptr %slot11, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  store i32 0, ptr %p2769, align 4, !alias.scope !3, !noalias !4
  %v2770 = load i64, ptr %slot12, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  store i32 0, ptr %p2771, align 4, !alias.scope !3, !noalias !4
  %v2772 = load i64, ptr %slot13, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  store i32 0, ptr %p2773, align 4, !alias.scope !3, !noalias !4
  %v2774 = load i64, ptr %slot14, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  store i32 0, ptr %p2775, align 4, !alias.scope !3, !noalias !4
  %v2776 = load i64, ptr %slot15, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  store i32 0, ptr %p2777, align 4, !alias.scope !3, !noalias !4
  %v2778 = load i64, ptr %slot16, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  store i32 0, ptr %p2779, align 4, !alias.scope !3, !noalias !4
  %v2780 = load i64, ptr %slot17, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  store i32 0, ptr %p2781, align 4, !alias.scope !3, !noalias !4
  %v2782 = load i64, ptr %slot18, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i32 0, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot19, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  store i32 0, ptr %p2785, align 4, !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot20, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i32 0, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot21, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i32 0, ptr %p2789, align 4, !alias.scope !3, !noalias !4
  %v2790 = load i64, ptr %slot8, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  store i32 2, ptr %p2791, align 4, !alias.scope !3, !noalias !4
  %v2792 = load i64, ptr %slot10, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  store i32 2, ptr %p2793, align 4, !alias.scope !3, !noalias !4
  %v2794 = load i64, ptr %slot12, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  store i32 2, ptr %p2795, align 4, !alias.scope !3, !noalias !4
  %v2796 = load i64, ptr %slot14, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  store i32 2, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  %v2798 = load i64, ptr %slot16, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  store i32 2, ptr %p2799, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v2800 = load i64, ptr %slot26, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2802, ptr %slot65, align 8
  %v2803 = load i64, ptr %slot65, align 8
  %v2804 = load i64, ptr %slot44, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i64 %v2803, ptr %p2805, align 8, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot44, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %ld2808 = load i64, ptr %p2807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2808, ptr %slot66, align 8
  %v2809 = load i64, ptr %slot66, align 8
  %op2810 = add i64 %v2809, 32
  store i64 %op2810, ptr %slot67, align 8
  %v2811 = load i64, ptr %slot67, align 8
  %v2812 = load i64, ptr %slot44, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i64 %v2811, ptr %p2813, align 8, !alias.scope !3, !noalias !4
  %v2814 = load i64, ptr %slot17, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i32, ptr %p2815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2816, ptr %slot68, align 8
  %v2817 = load i32, ptr %slot68, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v2820 = load i64, ptr %slot17, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  store i32 0, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  %v2822 = load i64, ptr %slot22, align 8
  store i64 %v2822, ptr %slot69, align 8
  %v2823 = load i64, ptr %slot18, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %ld2825 = load i32, ptr %p2824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2825, ptr %slot70, align 8
  %v2826 = load i32, ptr %slot70, align 8
  %op2827 = and i32 %v2826, 28
  store i32 %op2827, ptr %slot71, align 8
  %v2828 = load i32, ptr %slot71, align 8
  %cv2829 = zext i32 %v2828 to i64
  %cond2830 = icmp ne i64 %cv2829, 0
  br i1 %cond2830, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v2831 = load i64, ptr %slot63, align 8
  store i64 %v2831, ptr %slot72, align 8
  %v2832 = load i64, ptr %slot72, align 8
  %v2833 = load i64, ptr %slot69, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2832, i64 %v2833) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v2834 = load i64, ptr %slot63, align 8
  store i64 %v2834, ptr %slot73, align 8
  %v2835 = load i64, ptr %slot73, align 8
  %v2836 = load i64, ptr %slot69, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2835, i64 %v2836) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v2837 = load i64, ptr %slot44, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %ld2839 = load i64, ptr %p2838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2839, ptr %slot74, align 8
  %v2840 = load i64, ptr %slot74, align 8
  %op2841 = add i64 %v2840, 128
  store i64 %op2841, ptr %slot75, align 8
  %v2842 = load i64, ptr %slot75, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %ld2844 = load i64, ptr %p2843, align 8
  store i64 %ld2844, ptr %slot76, align 8
  %v2845 = load i64, ptr %slot76, align 8
  %v2846 = load i64, ptr %slot44, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i64 %v2845, ptr %p2847, align 8, !alias.scope !3, !noalias !4
  %v2848 = load i64, ptr %slot17, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  %ld2850 = load i32, ptr %p2849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2850, ptr %slot77, align 8
  %v2851 = load i32, ptr %slot77, align 8
  %cv2852 = zext i32 %v2851 to i64
  %cond2853 = icmp ne i64 %cv2852, 0
  br i1 %cond2853, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v2854 = load i64, ptr %slot17, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  store i32 0, ptr %p2855, align 4, !alias.scope !3, !noalias !4
  %v2856 = load i64, ptr %slot22, align 8
  store i64 %v2856, ptr %slot78, align 8
  %v2857 = load i64, ptr %slot18, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %ld2859 = load i32, ptr %p2858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2859, ptr %slot79, align 8
  %v2860 = load i32, ptr %slot79, align 8
  %op2861 = and i32 %v2860, 28
  store i32 %op2861, ptr %slot80, align 8
  %v2862 = load i32, ptr %slot80, align 8
  %cv2863 = zext i32 %v2862 to i64
  %cond2864 = icmp ne i64 %cv2863, 0
  br i1 %cond2864, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v2865 = load i64, ptr %slot63, align 8
  store i64 %v2865, ptr %slot81, align 8
  %v2866 = load i64, ptr %slot81, align 8
  %v2867 = load i64, ptr %slot78, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2866, i64 %v2867) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v2868 = load i64, ptr %slot63, align 8
  store i64 %v2868, ptr %slot82, align 8
  %v2869 = load i64, ptr %slot82, align 8
  %v2870 = load i64, ptr %slot78, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2869, i64 %v2870) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v2871 = load i64, ptr %slot27, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  %ld2873 = load i64, ptr %p2872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2873, ptr %slot83, align 8
  %v2874 = load i64, ptr %slot83, align 8
  %v2875 = load i64, ptr %slot45, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  store i64 %v2874, ptr %p2876, align 8, !alias.scope !3, !noalias !4
  %v2877 = load i64, ptr %slot45, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i64, ptr %p2878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2879, ptr %slot84, align 8
  %v2880 = load i64, ptr %slot44, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %ld2882 = load i64, ptr %p2881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2882, ptr %slot85, align 8
  %v2883 = load i64, ptr %slot85, align 8
  %v2884 = load i64, ptr %slot84, align 8
  %ovpair2886 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2883, i64 %v2884)
  %op2885 = extractvalue { i64, i1 } %ovpair2886, 0
  %ov2887 = extractvalue { i64, i1 } %ovpair2886, 1
  store i64 %op2885, ptr %slot86, align 8
  %v2888 = load i64, ptr %slot85, align 8
  %v2889 = load i64, ptr %slot84, align 8
  %op2890 = xor i64 %v2888, %v2889
  store i64 %op2890, ptr %slot87, align 8
  %v2891 = load i64, ptr %slot85, align 8
  %v2892 = load i64, ptr %slot86, align 8
  %op2893 = xor i64 %v2891, %v2892
  store i64 %op2893, ptr %slot88, align 8
  %v2894 = load i64, ptr %slot87, align 8
  %v2895 = load i64, ptr %slot88, align 8
  %op2896 = and i64 %v2894, %v2895
  store i64 %op2896, ptr %slot89, align 8
  %cv2897 = zext i1 %ov2887 to i64
  store i64 %cv2897, ptr %slot90, align 8
  %v2898 = load i64, ptr %slot90, align 8
  %cond2899 = icmp ne i64 %v2898, 0
  br i1 %cond2899, label %bb_overflow46, label %bb_checked46
bb_overflow46:
  %v2900 = load i64, ptr %slot1, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  %v2902 = load i64, ptr %slot85, align 8
  %v2903 = load i64, ptr %slot84, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2901, i64 1, i64 %v2902, i64 %v2903, i64 64) nomerge, !dbg !118
  unreachable
bb_checked46:
  %v2904 = load i64, ptr %slot86, align 8
  %v2905 = load i64, ptr %slot44, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  store i64 %v2904, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  %v2907 = load i64, ptr %slot45, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  store i64 1, ptr %p2908, align 8, !alias.scope !3, !noalias !4
  %v2909 = load i64, ptr %slot45, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  %ld2911 = load i64, ptr %p2910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2911, ptr %slot91, align 8
  %v2912 = load i64, ptr %slot44, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  %ld2914 = load i64, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2914, ptr %slot92, align 8
  %v2915 = load i64, ptr %slot92, align 8
  %v2916 = load i64, ptr %slot91, align 8
  %ovpair2918 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2915, i64 %v2916)
  %op2917 = extractvalue { i64, i1 } %ovpair2918, 0
  %ov2919 = extractvalue { i64, i1 } %ovpair2918, 1
  store i64 %op2917, ptr %slot93, align 8
  %cv2920 = zext i1 %ov2919 to i64
  store i64 %cv2920, ptr %slot94, align 8
  %v2921 = load i64, ptr %slot94, align 8
  %cond2922 = icmp ne i64 %v2921, 0
  br i1 %cond2922, label %bb_overflow53, label %bb_checked53
bb_overflow53:
  %v2923 = load i64, ptr %slot1, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %v2925 = load i64, ptr %slot92, align 8
  %v2926 = load i64, ptr %slot91, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2924, i64 1, i64 %v2925, i64 %v2926, i64 64) nomerge, !dbg !120
  unreachable
bb_checked53:
  %v2927 = load i64, ptr %slot93, align 8
  %v2928 = load i64, ptr %slot44, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  store i64 %v2927, ptr %p2929, align 8, !alias.scope !3, !noalias !4
  %v2930 = load i64, ptr %slot44, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %ld2932 = load i64, ptr %p2931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2932, ptr %slot95, align 8
  %v2933 = load i64, ptr %slot95, align 8
  %v2934 = load i64, ptr %slot29, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  store i64 %v2933, ptr %p2935, align 8, !alias.scope !3, !noalias !4
  %v2936 = load i64, ptr %slot26, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  %ld2938 = load i64, ptr %p2937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2938, ptr %slot96, align 8
  %v2939 = load i64, ptr %slot96, align 8
  %v2940 = load i64, ptr %slot44, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  store i64 %v2939, ptr %p2941, align 8, !alias.scope !3, !noalias !4
  %v2942 = load i64, ptr %slot44, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %ld2944 = load i64, ptr %p2943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2944, ptr %slot97, align 8
  %v2945 = load i64, ptr %slot97, align 8
  %op2946 = add i64 %v2945, 32
  store i64 %op2946, ptr %slot98, align 8
  %v2947 = load i64, ptr %slot98, align 8
  %v2948 = load i64, ptr %slot44, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  store i64 %v2947, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  %v2950 = load i64, ptr %slot17, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  %ld2952 = load i32, ptr %p2951, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2952, ptr %slot99, align 8
  %v2953 = load i32, ptr %slot99, align 8
  %cv2954 = zext i32 %v2953 to i64
  %cond2955 = icmp ne i64 %cv2954, 0
  br i1 %cond2955, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v2956 = load i64, ptr %slot17, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  store i32 0, ptr %p2957, align 4, !alias.scope !3, !noalias !4
  %v2958 = load i64, ptr %slot22, align 8
  store i64 %v2958, ptr %slot100, align 8
  %v2959 = load i64, ptr %slot18, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  %ld2961 = load i32, ptr %p2960, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2961, ptr %slot101, align 8
  %v2962 = load i32, ptr %slot101, align 8
  %op2963 = and i32 %v2962, 28
  store i32 %op2963, ptr %slot102, align 8
  %v2964 = load i32, ptr %slot102, align 8
  %cv2965 = zext i32 %v2964 to i64
  %cond2966 = icmp ne i64 %cv2965, 0
  br i1 %cond2966, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v2967 = load i64, ptr %slot63, align 8
  store i64 %v2967, ptr %slot103, align 8
  %v2968 = load i64, ptr %slot103, align 8
  %v2969 = load i64, ptr %slot100, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2968, i64 %v2969) nomerge, !dbg !122
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v2970 = load i64, ptr %slot63, align 8
  store i64 %v2970, ptr %slot104, align 8
  %v2971 = load i64, ptr %slot104, align 8
  %v2972 = load i64, ptr %slot100, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2971, i64 %v2972) nomerge, !dbg !122
  br label %bb_rcslotdone61
bb_rcslotdone61:
  %v2973 = load i64, ptr %slot44, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  %ld2975 = load i64, ptr %p2974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2975, ptr %slot105, align 8
  %v2976 = load i64, ptr %slot105, align 8
  %op2977 = add i64 %v2976, 120
  store i64 %op2977, ptr %slot106, align 8
  %v2978 = load i64, ptr %slot106, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %ld2980 = load i64, ptr %p2979, align 8
  store i64 %ld2980, ptr %slot107, align 8
  %v2981 = load i64, ptr %slot107, align 8
  %v2982 = load i64, ptr %slot44, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i64 %v2981, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot17, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  %ld2986 = load i32, ptr %p2985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2986, ptr %slot108, align 8
  %v2987 = load i32, ptr %slot108, align 8
  %cv2988 = zext i32 %v2987 to i64
  %cond2989 = icmp ne i64 %cv2988, 0
  br i1 %cond2989, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v2990 = load i64, ptr %slot17, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  store i32 0, ptr %p2991, align 4, !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot22, align 8
  store i64 %v2992, ptr %slot109, align 8
  %v2993 = load i64, ptr %slot18, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %ld2995 = load i32, ptr %p2994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2995, ptr %slot110, align 8
  %v2996 = load i32, ptr %slot110, align 8
  %op2997 = and i32 %v2996, 28
  store i32 %op2997, ptr %slot111, align 8
  %v2998 = load i32, ptr %slot111, align 8
  %cv2999 = zext i32 %v2998 to i64
  %cond3000 = icmp ne i64 %cv2999, 0
  br i1 %cond3000, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v3001 = load i64, ptr %slot63, align 8
  store i64 %v3001, ptr %slot112, align 8
  %v3002 = load i64, ptr %slot112, align 8
  %v3003 = load i64, ptr %slot109, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3002, i64 %v3003) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v3004 = load i64, ptr %slot63, align 8
  store i64 %v3004, ptr %slot113, align 8
  %v3005 = load i64, ptr %slot113, align 8
  %v3006 = load i64, ptr %slot109, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3005, i64 %v3006) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotdone73:
  %v3007 = load i64, ptr %slot44, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %ld3009 = load i64, ptr %p3008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3009, ptr %slot114, align 8
  %v3010 = load i64, ptr %slot114, align 8
  %v3011 = load i64, ptr %slot30, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  store i64 %v3010, ptr %p3012, align 8, !alias.scope !3, !noalias !4
  %v3013 = load i64, ptr %slot29, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i64, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3015, ptr %slot115, align 8
  %v3016 = load i64, ptr %slot115, align 8
  %v3017 = load i64, ptr %slot44, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  store i64 %v3016, ptr %p3018, align 8, !alias.scope !3, !noalias !4
  %v3019 = load i64, ptr %slot44, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i64, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3021, ptr %slot116, align 8
  %v3022 = load i64, ptr %slot116, align 8
  %v3023 = load i64, ptr %slot31, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  store i64 %v3022, ptr %p3024, align 8, !alias.scope !3, !noalias !4
  %v3025 = load i64, ptr %slot31, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  %ld3027 = load i64, ptr %p3026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3027, ptr %slot117, align 8
  %v3028 = load i64, ptr %slot117, align 8
  %v3029 = load i64, ptr %slot44, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  store i64 %v3028, ptr %p3030, align 8, !alias.scope !3, !noalias !4
  %v3031 = load i64, ptr %slot45, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  store i64 0, ptr %p3032, align 8, !alias.scope !3, !noalias !4
  %v3033 = load i64, ptr %slot45, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  %ld3035 = load i64, ptr %p3034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3035, ptr %slot118, align 8
  %v3036 = load i64, ptr %slot44, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %ld3038 = load i64, ptr %p3037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3038, ptr %slot119, align 8
  %v3039 = load i64, ptr %slot119, align 8
  %v3040 = load i64, ptr %slot118, align 8
  %cmp3041 = icmp slt i64 %v3039, %v3040
  %cv3042 = zext i1 %cmp3041 to i64
  store i64 %cv3042, ptr %slot120, align 8
  %v3043 = load i64, ptr %slot120, align 8
  %v3044 = load i64, ptr %slot44, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  store i64 %v3043, ptr %p3045, align 8, !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot44, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  %ld3048 = load i64, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3048, ptr %slot121, align 8
  %v3049 = load i64, ptr %slot121, align 8
  %cond3050 = icmp ne i64 %v3049, 0
  br i1 %cond3050, label %bb_next88, label %bb_i23
bb_next88:
  %v3051 = load i64, ptr %slot30, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %ld3053 = load i64, ptr %p3052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3053, ptr %slot122, align 8
  %v3054 = load i64, ptr %slot122, align 8
  %op3055 = add i64 %v3054, 0
  store i64 %op3055, ptr %slot123, align 8
  %v3056 = load i64, ptr %slot123, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  %ld3058 = load i64, ptr %p3057, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3058, ptr %slot124, align 8
  %v3059 = load i64, ptr %slot124, align 8
  %v3060 = load i64, ptr %slot44, align 8
  %p3061 = inttoptr i64 %v3060 to ptr
  store i64 %v3059, ptr %p3061, align 8, !alias.scope !3, !noalias !4
  %v3062 = load i64, ptr %slot44, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %ld3064 = load i64, ptr %p3063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3064, ptr %slot125, align 8
  %v3065 = load i64, ptr %slot125, align 8
  %cmp3066 = icmp ugt i64 %v3065, 9223372036854775807
  %cv3067 = zext i1 %cmp3066 to i64
  store i64 %cv3067, ptr %slot126, align 8
  %v3068 = load i64, ptr %slot126, align 8
  %cond3069 = icmp ne i64 %v3068, 0
  br i1 %cond3069, label %bb_cast_overflow93, label %bb_cast_ok93
bb_cast_overflow93:
  %v3070 = load i64, ptr %slot1, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %v3072 = load i64, ptr %slot125, align 8
  call void @myl_qbe_fail_cast(ptr %p3071, i64 %v3072, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok93:
  %v3073 = load i64, ptr %slot125, align 8
  %v3074 = load i64, ptr %slot44, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i64 %v3073, ptr %p3075, align 8, !alias.scope !3, !noalias !4
  %v3076 = load i64, ptr %slot31, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %ld3078 = load i64, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3078, ptr %slot127, align 8
  %v3079 = load i64, ptr %slot127, align 8
  %v3080 = load i64, ptr %slot45, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  store i64 %v3079, ptr %p3081, align 8, !alias.scope !3, !noalias !4
  %v3082 = load i64, ptr %slot45, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %ld3084 = load i64, ptr %p3083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3084, ptr %slot128, align 8
  %v3085 = load i64, ptr %slot44, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  %ld3087 = load i64, ptr %p3086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3087, ptr %slot129, align 8
  %v3088 = load i64, ptr %slot129, align 8
  %v3089 = load i64, ptr %slot128, align 8
  %ovpair3091 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3088, i64 %v3089)
  %op3090 = extractvalue { i64, i1 } %ovpair3091, 0
  %ov3092 = extractvalue { i64, i1 } %ovpair3091, 1
  store i64 %op3090, ptr %slot130, align 8
  %v3093 = load i64, ptr %slot129, align 8
  %v3094 = load i64, ptr %slot130, align 8
  %op3095 = xor i64 %v3093, %v3094
  store i64 %op3095, ptr %slot131, align 8
  %v3096 = load i64, ptr %slot128, align 8
  %v3097 = load i64, ptr %slot130, align 8
  %op3098 = xor i64 %v3096, %v3097
  store i64 %op3098, ptr %slot132, align 8
  %v3099 = load i64, ptr %slot131, align 8
  %v3100 = load i64, ptr %slot132, align 8
  %op3101 = and i64 %v3099, %v3100
  store i64 %op3101, ptr %slot133, align 8
  %cv3102 = zext i1 %ov3092 to i64
  store i64 %cv3102, ptr %slot134, align 8
  %v3103 = load i64, ptr %slot134, align 8
  %cond3104 = icmp ne i64 %v3103, 0
  br i1 %cond3104, label %bb_overflow97, label %bb_checked97
bb_overflow97:
  %v3105 = load i64, ptr %slot1, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %v3107 = load i64, ptr %slot129, align 8
  %v3108 = load i64, ptr %slot128, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3106, i64 0, i64 %v3107, i64 %v3108, i64 64) nomerge, !dbg !128
  unreachable
bb_checked97:
  %v3109 = load i64, ptr %slot130, align 8
  %v3110 = load i64, ptr %slot44, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  store i64 %v3109, ptr %p3111, align 8, !alias.scope !3, !noalias !4
  %v3112 = load i64, ptr %slot44, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  %ld3114 = load i64, ptr %p3113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3114, ptr %slot135, align 8
  %v3115 = load i64, ptr %slot135, align 8
  %v3116 = load i64, ptr %slot31, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  store i64 %v3115, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  br label %bb_i23
bb_i23:
  %v3118 = load i64, ptr %slot31, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  %ld3120 = load i64, ptr %p3119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3120, ptr %slot136, align 8
  %v3121 = load i64, ptr %slot136, align 8
  %v3122 = load i64, ptr %slot44, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  store i64 %v3121, ptr %p3123, align 8, !alias.scope !3, !noalias !4
  %v3124 = load i64, ptr %slot30, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %ld3126 = load i64, ptr %p3125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3126, ptr %slot137, align 8
  %v3127 = load i64, ptr %slot44, align 8
  %p3128 = inttoptr i64 %v3127 to ptr
  %ld3129 = load i64, ptr %p3128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3129, ptr %slot138, align 8
  %v3130 = load i64, ptr %slot137, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %ld3132 = load i64, ptr %p3131, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3132, ptr %slot139, align 8
  %v3133 = load i64, ptr %slot138, align 8
  %v3134 = load i64, ptr %slot139, align 8
  %cmp3135 = icmp ult i64 %v3133, %v3134
  %cv3136 = zext i1 %cmp3135 to i64
  store i64 %cv3136, ptr %slot140, align 8
  %v3137 = load i64, ptr %slot140, align 8
  %cond3138 = icmp ne i64 %v3137, 0
  br i1 %cond3138, label %bb_success109, label %bb_failed109
bb_failed109:
  %v3139 = load i64, ptr %slot1, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  %v3141 = load i64, ptr %slot138, align 8
  %v3142 = load i64, ptr %slot139, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3140, i64 %v3141, i64 %v3142) nomerge, !dbg !130
  unreachable
bb_success109:
  %v3143 = load i64, ptr %slot137, align 8
  %op3144 = add i64 %v3143, 32
  store i64 %op3144, ptr %slot141, align 8
  %v3145 = load i64, ptr %slot141, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %ld3147 = load i64, ptr %p3146, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3147, ptr %slot142, align 8
  %v3148 = load i64, ptr %slot138, align 8
  %op3149 = mul i64 %v3148, 16
  store i64 %op3149, ptr %slot143, align 8
  %v3150 = load i64, ptr %slot142, align 8
  %v3151 = load i64, ptr %slot143, align 8
  %op3152 = add i64 %v3150, %v3151
  store i64 %op3152, ptr %slot144, align 8
  %v3153 = load i64, ptr %slot144, align 8
  %v3154 = load i64, ptr %slot44, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  store i64 %v3153, ptr %p3155, align 8, !alias.scope !3, !noalias !4
  %v3156 = load i64, ptr %slot44, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  %ld3158 = load i64, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3158, ptr %slot145, align 8
  %v3159 = load i64, ptr %slot145, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %ld3161 = load i32, ptr %p3160, align 4
  %ext3162 = zext i32 %ld3161 to i64
  store i64 %ext3162, ptr %slot146, align 8
  %v3163 = load i64, ptr %slot146, align 8
  %cmp3164 = icmp eq i64 %v3163, 0
  %cv3165 = zext i1 %cmp3164 to i64
  store i64 %cv3165, ptr %slot147, align 8
  %v3166 = load i64, ptr %slot147, align 8
  %cond3167 = icmp ne i64 %v3166, 0
  br i1 %cond3167, label %bb_rcarm116, label %bb_rcarmnext116
bb_rcarm116:
  br label %bb_i170
bb_rcarmnext116:
  %v3168 = load i64, ptr %slot146, align 8
  %cmp3169 = icmp eq i64 %v3168, 1
  %cv3170 = zext i1 %cmp3169 to i64
  store i64 %cv3170, ptr %slot148, align 8
  %v3171 = load i64, ptr %slot148, align 8
  %cond3172 = icmp ne i64 %v3171, 0
  br i1 %cond3172, label %bb_rcarm117, label %bb_rcarmnext117
bb_rcarm117:
  br label %bb_i171
bb_rcarmnext117:
  %v3173 = load i64, ptr %slot146, align 8
  %cmp3174 = icmp eq i64 %v3173, 2
  %cv3175 = zext i1 %cmp3174 to i64
  store i64 %cv3175, ptr %slot149, align 8
  %v3176 = load i64, ptr %slot149, align 8
  %cond3177 = icmp ne i64 %v3176, 0
  br i1 %cond3177, label %bb_rcarm118, label %bb_rcarmnext118
bb_rcarm118:
  br label %bb_i172
bb_rcarmnext118:
  %v3178 = load i64, ptr %slot146, align 8
  %cmp3179 = icmp eq i64 %v3178, 3
  %cv3180 = zext i1 %cmp3179 to i64
  store i64 %cv3180, ptr %slot150, align 8
  %v3181 = load i64, ptr %slot150, align 8
  %cond3182 = icmp ne i64 %v3181, 0
  br i1 %cond3182, label %bb_rcarm119, label %bb_rcarmnext119
bb_rcarm119:
  %v3183 = load i64, ptr %slot24, align 8
  store i64 %v3183, ptr %slot151, align 8
  %v3184 = load i64, ptr %slot145, align 8
  %op3185 = add i64 %v3184, 8
  store i64 %op3185, ptr %slot152, align 8
  %v3186 = load i64, ptr %slot64, align 8
  store i64 %v3186, ptr %slot153, align 8
  %v3187 = load i64, ptr %slot152, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  %ld3189 = load i64, ptr %p3188, align 8
  store i64 %ld3189, ptr %slot154, align 8
  %v3190 = load i64, ptr %slot154, align 8
  %v3191 = load i64, ptr %slot151, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  store i64 %v3190, ptr %p3192, align 8, !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot20, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i32 0, ptr %p3194, align 4, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot19, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i32 1, ptr %p3196, align 4, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot151, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %ld3199 = load i64, ptr %p3198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3199, ptr %slot155, align 8
  %v3200 = load i64, ptr %slot155, align 8
  %v3201 = load i64, ptr %slot32, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  store i64 %v3200, ptr %p3202, align 8, !alias.scope !3, !noalias !4
  %v3203 = load i64, ptr %slot19, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  store i32 0, ptr %p3204, align 4, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_rcarmnext119:
  br label %bb_failure
bb_i26:
  %v3205 = load i64, ptr %slot26, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i64, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3207, ptr %slot156, align 8
  %v3208 = load i64, ptr %slot156, align 8
  %v3209 = load i64, ptr %slot44, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 %v3208, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  %v3211 = load i64, ptr %slot44, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i64, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3213, ptr %slot157, align 8
  %v3214 = load i64, ptr %slot157, align 8
  %op3215 = add i64 %v3214, 32
  store i64 %op3215, ptr %slot158, align 8
  %v3216 = load i64, ptr %slot158, align 8
  %v3217 = load i64, ptr %slot44, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i64 %v3216, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot17, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  %ld3221 = load i32, ptr %p3220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3221, ptr %slot159, align 8
  %v3222 = load i32, ptr %slot159, align 8
  %cv3223 = zext i32 %v3222 to i64
  %cond3224 = icmp ne i64 %cv3223, 0
  br i1 %cond3224, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v3225 = load i64, ptr %slot17, align 8
  %p3226 = inttoptr i64 %v3225 to ptr
  store i32 0, ptr %p3226, align 4, !alias.scope !3, !noalias !4
  %v3227 = load i64, ptr %slot22, align 8
  store i64 %v3227, ptr %slot160, align 8
  %v3228 = load i64, ptr %slot18, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  %ld3230 = load i32, ptr %p3229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3230, ptr %slot161, align 8
  %v3231 = load i32, ptr %slot161, align 8
  %op3232 = and i32 %v3231, 28
  store i32 %op3232, ptr %slot162, align 8
  %v3233 = load i32, ptr %slot162, align 8
  %cv3234 = zext i32 %v3233 to i64
  %cond3235 = icmp ne i64 %cv3234, 0
  br i1 %cond3235, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v3236 = load i64, ptr %slot63, align 8
  store i64 %v3236, ptr %slot163, align 8
  %v3237 = load i64, ptr %slot163, align 8
  %v3238 = load i64, ptr %slot160, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3237, i64 %v3238) nomerge, !dbg !132
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v3239 = load i64, ptr %slot63, align 8
  store i64 %v3239, ptr %slot164, align 8
  %v3240 = load i64, ptr %slot164, align 8
  %v3241 = load i64, ptr %slot160, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3240, i64 %v3241) nomerge, !dbg !132
  br label %bb_rcslotdone133
bb_rcslotdone133:
  %v3242 = load i64, ptr %slot44, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %ld3244 = load i64, ptr %p3243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3244, ptr %slot165, align 8
  %v3245 = load i64, ptr %slot165, align 8
  %op3246 = add i64 %v3245, 0
  store i64 %op3246, ptr %slot166, align 8
  %v3247 = load i64, ptr %slot166, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  %ld3249 = load i64, ptr %p3248, align 8
  store i64 %ld3249, ptr %slot167, align 8
  %v3250 = load i64, ptr %slot167, align 8
  %v3251 = load i64, ptr %slot44, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  store i64 %v3250, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  %v3253 = load i64, ptr %slot17, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %ld3255 = load i32, ptr %p3254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3255, ptr %slot168, align 8
  %v3256 = load i32, ptr %slot168, align 8
  %cv3257 = zext i32 %v3256 to i64
  %cond3258 = icmp ne i64 %cv3257, 0
  br i1 %cond3258, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v3259 = load i64, ptr %slot17, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  store i32 0, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  %v3261 = load i64, ptr %slot22, align 8
  store i64 %v3261, ptr %slot169, align 8
  %v3262 = load i64, ptr %slot18, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %ld3264 = load i32, ptr %p3263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3264, ptr %slot170, align 8
  %v3265 = load i32, ptr %slot170, align 8
  %op3266 = and i32 %v3265, 28
  store i32 %op3266, ptr %slot171, align 8
  %v3267 = load i32, ptr %slot171, align 8
  %cv3268 = zext i32 %v3267 to i64
  %cond3269 = icmp ne i64 %cv3268, 0
  br i1 %cond3269, label %bb_rcslotrole145, label %bb_rcslotowner145
bb_rcslotrole145:
  %v3270 = load i64, ptr %slot63, align 8
  store i64 %v3270, ptr %slot172, align 8
  %v3271 = load i64, ptr %slot172, align 8
  %v3272 = load i64, ptr %slot169, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3271, i64 %v3272) nomerge, !dbg !134
  br label %bb_rcslotdone145
bb_rcslotowner145:
  %v3273 = load i64, ptr %slot63, align 8
  store i64 %v3273, ptr %slot173, align 8
  %v3274 = load i64, ptr %slot173, align 8
  %v3275 = load i64, ptr %slot169, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3274, i64 %v3275) nomerge, !dbg !134
  br label %bb_rcslotdone145
bb_rcslotdone145:
  %v3276 = load i64, ptr %slot44, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  %ld3278 = load i64, ptr %p3277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3278, ptr %slot174, align 8
  %v3279 = load i64, ptr %slot174, align 8
  %v3280 = load i64, ptr %slot33, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i64 %v3279, ptr %p3281, align 8, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot32, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %ld3284 = load i64, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3284, ptr %slot175, align 8
  %v3285 = load i64, ptr %slot175, align 8
  %v3286 = load i64, ptr %slot44, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i64 %v3285, ptr %p3287, align 8, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot44, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  %ld3290 = load i64, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3290, ptr %slot176, align 8
  %v3291 = load i64, ptr %slot176, align 8
  %v3292 = load i64, ptr %slot34, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  store i64 %v3291, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  %v3294 = load i64, ptr %slot34, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  %ld3296 = load i64, ptr %p3295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3296, ptr %slot177, align 8
  %v3297 = load i64, ptr %slot177, align 8
  %v3298 = load i64, ptr %slot44, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i64 %v3297, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  %v3300 = load i64, ptr %slot45, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i64 0, ptr %p3301, align 8, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot45, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %ld3304 = load i64, ptr %p3303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3304, ptr %slot178, align 8
  %v3305 = load i64, ptr %slot44, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i64, ptr %p3306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3307, ptr %slot179, align 8
  %v3308 = load i64, ptr %slot179, align 8
  %v3309 = load i64, ptr %slot178, align 8
  %cmp3310 = icmp slt i64 %v3308, %v3309
  %cv3311 = zext i1 %cmp3310 to i64
  store i64 %cv3311, ptr %slot180, align 8
  %v3312 = load i64, ptr %slot180, align 8
  %v3313 = load i64, ptr %slot44, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i64 %v3312, ptr %p3314, align 8, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot44, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  %ld3317 = load i64, ptr %p3316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3317, ptr %slot181, align 8
  %v3318 = load i64, ptr %slot181, align 8
  %cond3319 = icmp ne i64 %v3318, 0
  br i1 %cond3319, label %bb_next160, label %bb_i41
bb_next160:
  %v3320 = load i64, ptr %slot33, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %ld3322 = load i64, ptr %p3321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3322, ptr %slot182, align 8
  %v3323 = load i64, ptr %slot182, align 8
  %op3324 = add i64 %v3323, 0
  store i64 %op3324, ptr %slot183, align 8
  %v3325 = load i64, ptr %slot183, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  %ld3327 = load i64, ptr %p3326, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3327, ptr %slot184, align 8
  %v3328 = load i64, ptr %slot184, align 8
  %v3329 = load i64, ptr %slot44, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i64 %v3328, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot44, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %ld3333 = load i64, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3333, ptr %slot185, align 8
  %v3334 = load i64, ptr %slot185, align 8
  %cmp3335 = icmp ugt i64 %v3334, 9223372036854775807
  %cv3336 = zext i1 %cmp3335 to i64
  store i64 %cv3336, ptr %slot186, align 8
  %v3337 = load i64, ptr %slot186, align 8
  %cond3338 = icmp ne i64 %v3337, 0
  br i1 %cond3338, label %bb_cast_overflow165, label %bb_cast_ok165
bb_cast_overflow165:
  %v3339 = load i64, ptr %slot1, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %v3341 = load i64, ptr %slot185, align 8
  call void @myl_qbe_fail_cast(ptr %p3340, i64 %v3341, i64 320) nomerge, !dbg !136
  unreachable
bb_cast_ok165:
  %v3342 = load i64, ptr %slot185, align 8
  %v3343 = load i64, ptr %slot44, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  store i64 %v3342, ptr %p3344, align 8, !alias.scope !3, !noalias !4
  %v3345 = load i64, ptr %slot34, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  %ld3347 = load i64, ptr %p3346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3347, ptr %slot187, align 8
  %v3348 = load i64, ptr %slot187, align 8
  %v3349 = load i64, ptr %slot45, align 8
  %p3350 = inttoptr i64 %v3349 to ptr
  store i64 %v3348, ptr %p3350, align 8, !alias.scope !3, !noalias !4
  %v3351 = load i64, ptr %slot45, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %ld3353 = load i64, ptr %p3352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3353, ptr %slot188, align 8
  %v3354 = load i64, ptr %slot44, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  %ld3356 = load i64, ptr %p3355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3356, ptr %slot189, align 8
  %v3357 = load i64, ptr %slot189, align 8
  %v3358 = load i64, ptr %slot188, align 8
  %ovpair3360 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3357, i64 %v3358)
  %op3359 = extractvalue { i64, i1 } %ovpair3360, 0
  %ov3361 = extractvalue { i64, i1 } %ovpair3360, 1
  store i64 %op3359, ptr %slot190, align 8
  %v3362 = load i64, ptr %slot189, align 8
  %v3363 = load i64, ptr %slot190, align 8
  %op3364 = xor i64 %v3362, %v3363
  store i64 %op3364, ptr %slot191, align 8
  %v3365 = load i64, ptr %slot188, align 8
  %v3366 = load i64, ptr %slot190, align 8
  %op3367 = xor i64 %v3365, %v3366
  store i64 %op3367, ptr %slot192, align 8
  %v3368 = load i64, ptr %slot191, align 8
  %v3369 = load i64, ptr %slot192, align 8
  %op3370 = and i64 %v3368, %v3369
  store i64 %op3370, ptr %slot193, align 8
  %cv3371 = zext i1 %ov3361 to i64
  store i64 %cv3371, ptr %slot194, align 8
  %v3372 = load i64, ptr %slot194, align 8
  %cond3373 = icmp ne i64 %v3372, 0
  br i1 %cond3373, label %bb_overflow169, label %bb_checked169
bb_overflow169:
  %v3374 = load i64, ptr %slot1, align 8
  %p3375 = inttoptr i64 %v3374 to ptr
  %v3376 = load i64, ptr %slot189, align 8
  %v3377 = load i64, ptr %slot188, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3375, i64 0, i64 %v3376, i64 %v3377, i64 64) nomerge, !dbg !138
  unreachable
bb_checked169:
  %v3378 = load i64, ptr %slot190, align 8
  %v3379 = load i64, ptr %slot44, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i64 %v3378, ptr %p3380, align 8, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot44, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i64, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3383, ptr %slot195, align 8
  %v3384 = load i64, ptr %slot195, align 8
  %v3385 = load i64, ptr %slot34, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i64 %v3384, ptr %p3386, align 8, !alias.scope !3, !noalias !4
  br label %bb_i41
bb_i41:
  %v3387 = load i64, ptr %slot34, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i64, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3389, ptr %slot196, align 8
  %v3390 = load i64, ptr %slot196, align 8
  %v3391 = load i64, ptr %slot44, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i64 %v3390, ptr %p3392, align 8, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot33, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %ld3395 = load i64, ptr %p3394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3395, ptr %slot197, align 8
  %v3396 = load i64, ptr %slot44, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %ld3398 = load i64, ptr %p3397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3398, ptr %slot198, align 8
  %v3399 = load i64, ptr %slot197, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %ld3401 = load i64, ptr %p3400, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3401, ptr %slot199, align 8
  %v3402 = load i64, ptr %slot198, align 8
  %v3403 = load i64, ptr %slot199, align 8
  %cmp3404 = icmp ult i64 %v3402, %v3403
  %cv3405 = zext i1 %cmp3404 to i64
  store i64 %cv3405, ptr %slot200, align 8
  %v3406 = load i64, ptr %slot200, align 8
  %cond3407 = icmp ne i64 %v3406, 0
  br i1 %cond3407, label %bb_success181, label %bb_failed181
bb_failed181:
  %v3408 = load i64, ptr %slot1, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  %v3410 = load i64, ptr %slot198, align 8
  %v3411 = load i64, ptr %slot199, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3409, i64 %v3410, i64 %v3411) nomerge, !dbg !140
  unreachable
bb_success181:
  %v3412 = load i64, ptr %slot197, align 8
  %op3413 = add i64 %v3412, 32
  store i64 %op3413, ptr %slot201, align 8
  %v3414 = load i64, ptr %slot201, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %ld3416 = load i64, ptr %p3415, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3416, ptr %slot202, align 8
  %v3417 = load i64, ptr %slot198, align 8
  %op3418 = mul i64 %v3417, 56
  store i64 %op3418, ptr %slot203, align 8
  %v3419 = load i64, ptr %slot202, align 8
  %v3420 = load i64, ptr %slot203, align 8
  %op3421 = add i64 %v3419, %v3420
  store i64 %op3421, ptr %slot204, align 8
  %v3422 = load i64, ptr %slot204, align 8
  %v3423 = load i64, ptr %slot44, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i64 %v3422, ptr %p3424, align 8, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot44, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  %ld3427 = load i64, ptr %p3426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3427, ptr %slot205, align 8
  %v3428 = load i64, ptr %slot24, align 8
  store i64 %v3428, ptr %slot206, align 8
  %v3429 = load i64, ptr %slot63, align 8
  %v3430 = load i64, ptr %slot206, align 8
  %v3431 = load i64, ptr %slot205, align 8
  %call3432 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v3429, i64 %v3430, i64 %v3431) nomerge, !dbg !140
  store i32 %call3432, ptr %slot207, align 8
  %v3433 = load i32, ptr %slot207, align 8
  %cv3434 = zext i32 %v3433 to i64
  %cond3435 = icmp ne i64 %cv3434, 0
  br i1 %cond3435, label %bb_rcsuccess189, label %bb_rcfailure189
bb_rcfailure189:
  %v3436 = load i64, ptr %slot63, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %call3438 = call i32 @myl_rc_take_failure(ptr %p3437) nomerge, !dbg !140
  store i32 %call3438, ptr %slot208, align 8
  %v3439 = load i64, ptr %slot1, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %v3441 = load i32, ptr %slot208, align 8
  %call3442 = call i32 @myl_qbe_rc_status(ptr %p3440, i32 %v3441) nomerge, !dbg !140
  store i32 %call3442, ptr %slot209, align 8
  br label %bb_failure
bb_rcsuccess189:
  %v3443 = load i64, ptr %slot20, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  store i32 2, ptr %p3444, align 4, !alias.scope !3, !noalias !4
  %v3445 = load i64, ptr %slot20, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  store i32 16, ptr %p3446, align 4, !alias.scope !3, !noalias !4
  %v3447 = load i64, ptr %slot19, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  store i32 1, ptr %p3448, align 4, !alias.scope !3, !noalias !4
  %v3449 = load i64, ptr %slot22, align 8
  store i64 %v3449, ptr %slot210, align 8
  %v3450 = load i64, ptr %slot24, align 8
  store i64 %v3450, ptr %slot211, align 8
  %v3451 = load i64, ptr %slot211, align 8
  %v3452 = load i64, ptr %slot210, align 8
  %p3453 = inttoptr i64 %v3451 to ptr
  %p3454 = inttoptr i64 %v3452 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3454, ptr %p3453, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v3455 = load i64, ptr %slot18, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i32 2, ptr %p3456, align 4, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot20, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  %ld3459 = load i32, ptr %p3458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3459, ptr %slot212, align 8
  %v3460 = load i32, ptr %slot212, align 8
  %v3461 = load i64, ptr %slot18, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  store i32 %v3460, ptr %p3462, align 4, !alias.scope !3, !noalias !4
  %v3463 = load i64, ptr %slot19, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  store i32 0, ptr %p3464, align 4, !alias.scope !3, !noalias !4
  %v3465 = load i64, ptr %slot17, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i32 1, ptr %p3466, align 4, !alias.scope !3, !noalias !4
  %v3467 = load i64, ptr %slot210, align 8
  %v3468 = load i64, ptr %slot44, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  store i64 %v3467, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  %v3470 = load i64, ptr %slot44, align 8
  %p3471 = inttoptr i64 %v3470 to ptr
  %ld3472 = load i64, ptr %p3471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3472, ptr %slot213, align 8
  %v3473 = load i64, ptr %slot213, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %ld3475 = load i32, ptr %p3474, align 4
  %ext3476 = zext i32 %ld3475 to i64
  store i64 %ext3476, ptr %slot214, align 8
  %v3477 = load i64, ptr %slot214, align 8
  %cmp3478 = icmp eq i64 %v3477, 0
  %cv3479 = zext i1 %cmp3478 to i64
  store i64 %cv3479, ptr %slot215, align 8
  %v3480 = load i64, ptr %slot215, align 8
  %cond3481 = icmp ne i64 %v3480, 0
  br i1 %cond3481, label %bb_rcarm205, label %bb_rcarmnext205
bb_rcarm205:
  %v3482 = load i64, ptr %slot17, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i32, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3484, ptr %slot216, align 8
  %v3485 = load i32, ptr %slot216, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcslotdrop208, label %bb_rcslotdone208
bb_rcslotdrop208:
  %v3488 = load i64, ptr %slot17, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i32 0, ptr %p3489, align 4, !alias.scope !3, !noalias !4
  %v3490 = load i64, ptr %slot22, align 8
  store i64 %v3490, ptr %slot217, align 8
  %v3491 = load i64, ptr %slot18, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %ld3493 = load i32, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3493, ptr %slot218, align 8
  %v3494 = load i32, ptr %slot218, align 8
  %op3495 = and i32 %v3494, 28
  store i32 %op3495, ptr %slot219, align 8
  %v3496 = load i32, ptr %slot219, align 8
  %cv3497 = zext i32 %v3496 to i64
  %cond3498 = icmp ne i64 %cv3497, 0
  br i1 %cond3498, label %bb_rcslotrole208, label %bb_rcslotowner208
bb_rcslotrole208:
  %v3499 = load i64, ptr %slot63, align 8
  store i64 %v3499, ptr %slot220, align 8
  %v3500 = load i64, ptr %slot220, align 8
  %v3501 = load i64, ptr %slot217, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3500, i64 %v3501) nomerge, !dbg !142
  br label %bb_rcslotdone208
bb_rcslotowner208:
  %v3502 = load i64, ptr %slot63, align 8
  store i64 %v3502, ptr %slot221, align 8
  %v3503 = load i64, ptr %slot221, align 8
  %v3504 = load i64, ptr %slot217, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3503, i64 %v3504) nomerge, !dbg !142
  br label %bb_rcslotdone208
bb_rcslotdone208:
  br label %bb_i161
bb_rcarmnext205:
  %v3505 = load i64, ptr %slot214, align 8
  %cmp3506 = icmp eq i64 %v3505, 1
  %cv3507 = zext i1 %cmp3506 to i64
  store i64 %cv3507, ptr %slot222, align 8
  %v3508 = load i64, ptr %slot222, align 8
  %cond3509 = icmp ne i64 %v3508, 0
  br i1 %cond3509, label %bb_rcarm215, label %bb_rcarmnext215
bb_rcarm215:
  %v3510 = load i64, ptr %slot17, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  %ld3512 = load i32, ptr %p3511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3512, ptr %slot223, align 8
  %v3513 = load i32, ptr %slot223, align 8
  %cv3514 = zext i32 %v3513 to i64
  %cond3515 = icmp ne i64 %cv3514, 0
  br i1 %cond3515, label %bb_rcslotdrop218, label %bb_rcslotdone218
bb_rcslotdrop218:
  %v3516 = load i64, ptr %slot17, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  store i32 0, ptr %p3517, align 4, !alias.scope !3, !noalias !4
  %v3518 = load i64, ptr %slot22, align 8
  store i64 %v3518, ptr %slot224, align 8
  %v3519 = load i64, ptr %slot18, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  %ld3521 = load i32, ptr %p3520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3521, ptr %slot225, align 8
  %v3522 = load i32, ptr %slot225, align 8
  %op3523 = and i32 %v3522, 28
  store i32 %op3523, ptr %slot226, align 8
  %v3524 = load i32, ptr %slot226, align 8
  %cv3525 = zext i32 %v3524 to i64
  %cond3526 = icmp ne i64 %cv3525, 0
  br i1 %cond3526, label %bb_rcslotrole218, label %bb_rcslotowner218
bb_rcslotrole218:
  %v3527 = load i64, ptr %slot63, align 8
  store i64 %v3527, ptr %slot227, align 8
  %v3528 = load i64, ptr %slot227, align 8
  %v3529 = load i64, ptr %slot224, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3528, i64 %v3529) nomerge, !dbg !142
  br label %bb_rcslotdone218
bb_rcslotowner218:
  %v3530 = load i64, ptr %slot63, align 8
  store i64 %v3530, ptr %slot228, align 8
  %v3531 = load i64, ptr %slot228, align 8
  %v3532 = load i64, ptr %slot224, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3531, i64 %v3532) nomerge, !dbg !142
  br label %bb_rcslotdone218
bb_rcslotdone218:
  br label %bb_i162
bb_rcarmnext215:
  %v3533 = load i64, ptr %slot214, align 8
  %cmp3534 = icmp eq i64 %v3533, 2
  %cv3535 = zext i1 %cmp3534 to i64
  store i64 %cv3535, ptr %slot229, align 8
  %v3536 = load i64, ptr %slot229, align 8
  %cond3537 = icmp ne i64 %v3536, 0
  br i1 %cond3537, label %bb_rcarm225, label %bb_rcarmnext225
bb_rcarm225:
  %v3538 = load i64, ptr %slot17, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  %ld3540 = load i32, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3540, ptr %slot230, align 8
  %v3541 = load i32, ptr %slot230, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcslotdrop228, label %bb_rcslotdone228
bb_rcslotdrop228:
  %v3544 = load i64, ptr %slot17, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  store i32 0, ptr %p3545, align 4, !alias.scope !3, !noalias !4
  %v3546 = load i64, ptr %slot22, align 8
  store i64 %v3546, ptr %slot231, align 8
  %v3547 = load i64, ptr %slot18, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %ld3549 = load i32, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3549, ptr %slot232, align 8
  %v3550 = load i32, ptr %slot232, align 8
  %op3551 = and i32 %v3550, 28
  store i32 %op3551, ptr %slot233, align 8
  %v3552 = load i32, ptr %slot233, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcslotrole228, label %bb_rcslotowner228
bb_rcslotrole228:
  %v3555 = load i64, ptr %slot63, align 8
  store i64 %v3555, ptr %slot234, align 8
  %v3556 = load i64, ptr %slot234, align 8
  %v3557 = load i64, ptr %slot231, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3556, i64 %v3557) nomerge, !dbg !142
  br label %bb_rcslotdone228
bb_rcslotowner228:
  %v3558 = load i64, ptr %slot63, align 8
  store i64 %v3558, ptr %slot235, align 8
  %v3559 = load i64, ptr %slot235, align 8
  %v3560 = load i64, ptr %slot231, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3559, i64 %v3560) nomerge, !dbg !142
  br label %bb_rcslotdone228
bb_rcslotdone228:
  br label %bb_i163
bb_rcarmnext225:
  %v3561 = load i64, ptr %slot214, align 8
  %cmp3562 = icmp eq i64 %v3561, 3
  %cv3563 = zext i1 %cmp3562 to i64
  store i64 %cv3563, ptr %slot236, align 8
  %v3564 = load i64, ptr %slot236, align 8
  %cond3565 = icmp ne i64 %v3564, 0
  br i1 %cond3565, label %bb_rcarm235, label %bb_rcarmnext235
bb_rcarm235:
  %v3566 = load i64, ptr %slot24, align 8
  store i64 %v3566, ptr %slot237, align 8
  %v3567 = load i64, ptr %slot213, align 8
  %op3568 = add i64 %v3567, 8
  store i64 %op3568, ptr %slot238, align 8
  %v3569 = load i64, ptr %slot64, align 8
  store i64 %v3569, ptr %slot239, align 8
  %v3570 = load i64, ptr %slot238, align 8
  %v3571 = load i64, ptr %slot237, align 8
  %p3572 = inttoptr i64 %v3570 to ptr
  %p3573 = inttoptr i64 %v3571 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3573, ptr %p3572, i64 16, i1 false)
  %v3574 = load i64, ptr %slot20, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  store i32 0, ptr %p3575, align 4, !alias.scope !3, !noalias !4
  %v3576 = load i64, ptr %slot19, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  store i32 1, ptr %p3577, align 4, !alias.scope !3, !noalias !4
  %v3578 = load i64, ptr %slot237, align 8
  %v3579 = load i64, ptr %slot39, align 8
  %p3580 = inttoptr i64 %v3578 to ptr
  %p3581 = inttoptr i64 %v3579 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3581, ptr %p3580, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3582 = load i64, ptr %slot19, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  store i32 0, ptr %p3583, align 4, !alias.scope !3, !noalias !4
  %v3584 = load i64, ptr %slot17, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  %ld3586 = load i32, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3586, ptr %slot240, align 8
  %v3587 = load i32, ptr %slot240, align 8
  %cv3588 = zext i32 %v3587 to i64
  %cond3589 = icmp ne i64 %cv3588, 0
  br i1 %cond3589, label %bb_rcslotdrop244, label %bb_rcslotdone244
bb_rcslotdrop244:
  %v3590 = load i64, ptr %slot17, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  store i32 0, ptr %p3591, align 4, !alias.scope !3, !noalias !4
  %v3592 = load i64, ptr %slot22, align 8
  store i64 %v3592, ptr %slot241, align 8
  %v3593 = load i64, ptr %slot18, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  %ld3595 = load i32, ptr %p3594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3595, ptr %slot242, align 8
  %v3596 = load i32, ptr %slot242, align 8
  %op3597 = and i32 %v3596, 28
  store i32 %op3597, ptr %slot243, align 8
  %v3598 = load i32, ptr %slot243, align 8
  %cv3599 = zext i32 %v3598 to i64
  %cond3600 = icmp ne i64 %cv3599, 0
  br i1 %cond3600, label %bb_rcslotrole244, label %bb_rcslotowner244
bb_rcslotrole244:
  %v3601 = load i64, ptr %slot63, align 8
  store i64 %v3601, ptr %slot244, align 8
  %v3602 = load i64, ptr %slot244, align 8
  %v3603 = load i64, ptr %slot241, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3602, i64 %v3603) nomerge, !dbg !142
  br label %bb_rcslotdone244
bb_rcslotowner244:
  %v3604 = load i64, ptr %slot63, align 8
  store i64 %v3604, ptr %slot245, align 8
  %v3605 = load i64, ptr %slot245, align 8
  %v3606 = load i64, ptr %slot241, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3605, i64 %v3606) nomerge, !dbg !142
  br label %bb_rcslotdone244
bb_rcslotdone244:
  br label %bb_i97
bb_rcarmnext235:
  %v3607 = load i64, ptr %slot214, align 8
  %cmp3608 = icmp eq i64 %v3607, 4
  %cv3609 = zext i1 %cmp3608 to i64
  store i64 %cv3609, ptr %slot246, align 8
  %v3610 = load i64, ptr %slot246, align 8
  %cond3611 = icmp ne i64 %v3610, 0
  br i1 %cond3611, label %bb_rcarm251, label %bb_rcarmnext251
bb_rcarm251:
  %v3612 = load i64, ptr %slot17, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  %ld3614 = load i32, ptr %p3613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3614, ptr %slot247, align 8
  %v3615 = load i32, ptr %slot247, align 8
  %cv3616 = zext i32 %v3615 to i64
  %cond3617 = icmp ne i64 %cv3616, 0
  br i1 %cond3617, label %bb_rcslotdrop254, label %bb_rcslotdone254
bb_rcslotdrop254:
  %v3618 = load i64, ptr %slot17, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i32 0, ptr %p3619, align 4, !alias.scope !3, !noalias !4
  %v3620 = load i64, ptr %slot22, align 8
  store i64 %v3620, ptr %slot248, align 8
  %v3621 = load i64, ptr %slot18, align 8
  %p3622 = inttoptr i64 %v3621 to ptr
  %ld3623 = load i32, ptr %p3622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3623, ptr %slot249, align 8
  %v3624 = load i32, ptr %slot249, align 8
  %op3625 = and i32 %v3624, 28
  store i32 %op3625, ptr %slot250, align 8
  %v3626 = load i32, ptr %slot250, align 8
  %cv3627 = zext i32 %v3626 to i64
  %cond3628 = icmp ne i64 %cv3627, 0
  br i1 %cond3628, label %bb_rcslotrole254, label %bb_rcslotowner254
bb_rcslotrole254:
  %v3629 = load i64, ptr %slot63, align 8
  store i64 %v3629, ptr %slot251, align 8
  %v3630 = load i64, ptr %slot251, align 8
  %v3631 = load i64, ptr %slot248, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3630, i64 %v3631) nomerge, !dbg !142
  br label %bb_rcslotdone254
bb_rcslotowner254:
  %v3632 = load i64, ptr %slot63, align 8
  store i64 %v3632, ptr %slot252, align 8
  %v3633 = load i64, ptr %slot252, align 8
  %v3634 = load i64, ptr %slot248, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3633, i64 %v3634) nomerge, !dbg !142
  br label %bb_rcslotdone254
bb_rcslotdone254:
  br label %bb_i164
bb_rcarmnext251:
  %v3635 = load i64, ptr %slot214, align 8
  %cmp3636 = icmp eq i64 %v3635, 5
  %cv3637 = zext i1 %cmp3636 to i64
  store i64 %cv3637, ptr %slot253, align 8
  %v3638 = load i64, ptr %slot253, align 8
  %cond3639 = icmp ne i64 %v3638, 0
  br i1 %cond3639, label %bb_rcarm261, label %bb_rcarmnext261
bb_rcarm261:
  %v3640 = load i64, ptr %slot17, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot254, align 8
  %v3643 = load i32, ptr %slot254, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v3646 = load i64, ptr %slot17, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  store i32 0, ptr %p3647, align 4, !alias.scope !3, !noalias !4
  %v3648 = load i64, ptr %slot22, align 8
  store i64 %v3648, ptr %slot255, align 8
  %v3649 = load i64, ptr %slot18, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i32, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3651, ptr %slot256, align 8
  %v3652 = load i32, ptr %slot256, align 8
  %op3653 = and i32 %v3652, 28
  store i32 %op3653, ptr %slot257, align 8
  %v3654 = load i32, ptr %slot257, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v3657 = load i64, ptr %slot63, align 8
  store i64 %v3657, ptr %slot258, align 8
  %v3658 = load i64, ptr %slot258, align 8
  %v3659 = load i64, ptr %slot255, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3658, i64 %v3659) nomerge, !dbg !142
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v3660 = load i64, ptr %slot63, align 8
  store i64 %v3660, ptr %slot259, align 8
  %v3661 = load i64, ptr %slot259, align 8
  %v3662 = load i64, ptr %slot255, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3661, i64 %v3662) nomerge, !dbg !142
  br label %bb_rcslotdone264
bb_rcslotdone264:
  br label %bb_i165
bb_rcarmnext261:
  %v3663 = load i64, ptr %slot214, align 8
  %cmp3664 = icmp eq i64 %v3663, 6
  %cv3665 = zext i1 %cmp3664 to i64
  store i64 %cv3665, ptr %slot260, align 8
  %v3666 = load i64, ptr %slot260, align 8
  %cond3667 = icmp ne i64 %v3666, 0
  br i1 %cond3667, label %bb_rcarm271, label %bb_rcarmnext271
bb_rcarm271:
  %v3668 = load i64, ptr %slot17, align 8
  %p3669 = inttoptr i64 %v3668 to ptr
  %ld3670 = load i32, ptr %p3669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3670, ptr %slot261, align 8
  %v3671 = load i32, ptr %slot261, align 8
  %cv3672 = zext i32 %v3671 to i64
  %cond3673 = icmp ne i64 %cv3672, 0
  br i1 %cond3673, label %bb_rcslotdrop274, label %bb_rcslotdone274
bb_rcslotdrop274:
  %v3674 = load i64, ptr %slot17, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  store i32 0, ptr %p3675, align 4, !alias.scope !3, !noalias !4
  %v3676 = load i64, ptr %slot22, align 8
  store i64 %v3676, ptr %slot262, align 8
  %v3677 = load i64, ptr %slot18, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %ld3679 = load i32, ptr %p3678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3679, ptr %slot263, align 8
  %v3680 = load i32, ptr %slot263, align 8
  %op3681 = and i32 %v3680, 28
  store i32 %op3681, ptr %slot264, align 8
  %v3682 = load i32, ptr %slot264, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcslotrole274, label %bb_rcslotowner274
bb_rcslotrole274:
  %v3685 = load i64, ptr %slot63, align 8
  store i64 %v3685, ptr %slot265, align 8
  %v3686 = load i64, ptr %slot265, align 8
  %v3687 = load i64, ptr %slot262, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3686, i64 %v3687) nomerge, !dbg !142
  br label %bb_rcslotdone274
bb_rcslotowner274:
  %v3688 = load i64, ptr %slot63, align 8
  store i64 %v3688, ptr %slot266, align 8
  %v3689 = load i64, ptr %slot266, align 8
  %v3690 = load i64, ptr %slot262, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3689, i64 %v3690) nomerge, !dbg !142
  br label %bb_rcslotdone274
bb_rcslotdone274:
  br label %bb_i91
bb_rcarmnext271:
  %v3691 = load i64, ptr %slot214, align 8
  %cmp3692 = icmp eq i64 %v3691, 7
  %cv3693 = zext i1 %cmp3692 to i64
  store i64 %cv3693, ptr %slot267, align 8
  %v3694 = load i64, ptr %slot267, align 8
  %cond3695 = icmp ne i64 %v3694, 0
  br i1 %cond3695, label %bb_rcarm281, label %bb_rcarmnext281
bb_rcarm281:
  %v3696 = load i64, ptr %slot17, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i32, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3698, ptr %slot268, align 8
  %v3699 = load i32, ptr %slot268, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcslotdrop284, label %bb_rcslotdone284
bb_rcslotdrop284:
  %v3702 = load i64, ptr %slot17, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  store i32 0, ptr %p3703, align 4, !alias.scope !3, !noalias !4
  %v3704 = load i64, ptr %slot22, align 8
  store i64 %v3704, ptr %slot269, align 8
  %v3705 = load i64, ptr %slot18, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %ld3707 = load i32, ptr %p3706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3707, ptr %slot270, align 8
  %v3708 = load i32, ptr %slot270, align 8
  %op3709 = and i32 %v3708, 28
  store i32 %op3709, ptr %slot271, align 8
  %v3710 = load i32, ptr %slot271, align 8
  %cv3711 = zext i32 %v3710 to i64
  %cond3712 = icmp ne i64 %cv3711, 0
  br i1 %cond3712, label %bb_rcslotrole284, label %bb_rcslotowner284
bb_rcslotrole284:
  %v3713 = load i64, ptr %slot63, align 8
  store i64 %v3713, ptr %slot272, align 8
  %v3714 = load i64, ptr %slot272, align 8
  %v3715 = load i64, ptr %slot269, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3714, i64 %v3715) nomerge, !dbg !142
  br label %bb_rcslotdone284
bb_rcslotowner284:
  %v3716 = load i64, ptr %slot63, align 8
  store i64 %v3716, ptr %slot273, align 8
  %v3717 = load i64, ptr %slot273, align 8
  %v3718 = load i64, ptr %slot269, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3717, i64 %v3718) nomerge, !dbg !142
  br label %bb_rcslotdone284
bb_rcslotdone284:
  br label %bb_i166
bb_rcarmnext281:
  %v3719 = load i64, ptr %slot214, align 8
  %cmp3720 = icmp eq i64 %v3719, 8
  %cv3721 = zext i1 %cmp3720 to i64
  store i64 %cv3721, ptr %slot274, align 8
  %v3722 = load i64, ptr %slot274, align 8
  %cond3723 = icmp ne i64 %v3722, 0
  br i1 %cond3723, label %bb_rcarm291, label %bb_rcarmnext291
bb_rcarm291:
  %v3724 = load i64, ptr %slot17, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  %ld3726 = load i32, ptr %p3725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3726, ptr %slot275, align 8
  %v3727 = load i32, ptr %slot275, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rcslotdrop294, label %bb_rcslotdone294
bb_rcslotdrop294:
  %v3730 = load i64, ptr %slot17, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  store i32 0, ptr %p3731, align 4, !alias.scope !3, !noalias !4
  %v3732 = load i64, ptr %slot22, align 8
  store i64 %v3732, ptr %slot276, align 8
  %v3733 = load i64, ptr %slot18, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  %ld3735 = load i32, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3735, ptr %slot277, align 8
  %v3736 = load i32, ptr %slot277, align 8
  %op3737 = and i32 %v3736, 28
  store i32 %op3737, ptr %slot278, align 8
  %v3738 = load i32, ptr %slot278, align 8
  %cv3739 = zext i32 %v3738 to i64
  %cond3740 = icmp ne i64 %cv3739, 0
  br i1 %cond3740, label %bb_rcslotrole294, label %bb_rcslotowner294
bb_rcslotrole294:
  %v3741 = load i64, ptr %slot63, align 8
  store i64 %v3741, ptr %slot279, align 8
  %v3742 = load i64, ptr %slot279, align 8
  %v3743 = load i64, ptr %slot276, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3742, i64 %v3743) nomerge, !dbg !142
  br label %bb_rcslotdone294
bb_rcslotowner294:
  %v3744 = load i64, ptr %slot63, align 8
  store i64 %v3744, ptr %slot280, align 8
  %v3745 = load i64, ptr %slot280, align 8
  %v3746 = load i64, ptr %slot276, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3745, i64 %v3746) nomerge, !dbg !142
  br label %bb_rcslotdone294
bb_rcslotdone294:
  br label %bb_i167
bb_rcarmnext291:
  %v3747 = load i64, ptr %slot214, align 8
  %cmp3748 = icmp eq i64 %v3747, 9
  %cv3749 = zext i1 %cmp3748 to i64
  store i64 %cv3749, ptr %slot281, align 8
  %v3750 = load i64, ptr %slot281, align 8
  %cond3751 = icmp ne i64 %v3750, 0
  br i1 %cond3751, label %bb_rcarm301, label %bb_rcarmnext301
bb_rcarm301:
  %v3752 = load i64, ptr %slot17, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  %ld3754 = load i32, ptr %p3753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3754, ptr %slot282, align 8
  %v3755 = load i32, ptr %slot282, align 8
  %cv3756 = zext i32 %v3755 to i64
  %cond3757 = icmp ne i64 %cv3756, 0
  br i1 %cond3757, label %bb_rcslotdrop304, label %bb_rcslotdone304
bb_rcslotdrop304:
  %v3758 = load i64, ptr %slot17, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i32 0, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot22, align 8
  store i64 %v3760, ptr %slot283, align 8
  %v3761 = load i64, ptr %slot18, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %ld3763 = load i32, ptr %p3762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3763, ptr %slot284, align 8
  %v3764 = load i32, ptr %slot284, align 8
  %op3765 = and i32 %v3764, 28
  store i32 %op3765, ptr %slot285, align 8
  %v3766 = load i32, ptr %slot285, align 8
  %cv3767 = zext i32 %v3766 to i64
  %cond3768 = icmp ne i64 %cv3767, 0
  br i1 %cond3768, label %bb_rcslotrole304, label %bb_rcslotowner304
bb_rcslotrole304:
  %v3769 = load i64, ptr %slot63, align 8
  store i64 %v3769, ptr %slot286, align 8
  %v3770 = load i64, ptr %slot286, align 8
  %v3771 = load i64, ptr %slot283, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3770, i64 %v3771) nomerge, !dbg !142
  br label %bb_rcslotdone304
bb_rcslotowner304:
  %v3772 = load i64, ptr %slot63, align 8
  store i64 %v3772, ptr %slot287, align 8
  %v3773 = load i64, ptr %slot287, align 8
  %v3774 = load i64, ptr %slot283, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3773, i64 %v3774) nomerge, !dbg !142
  br label %bb_rcslotdone304
bb_rcslotdone304:
  br label %bb_i168
bb_rcarmnext301:
  %v3775 = load i64, ptr %slot214, align 8
  %cmp3776 = icmp eq i64 %v3775, 10
  %cv3777 = zext i1 %cmp3776 to i64
  store i64 %cv3777, ptr %slot288, align 8
  %v3778 = load i64, ptr %slot288, align 8
  %cond3779 = icmp ne i64 %v3778, 0
  br i1 %cond3779, label %bb_rcarm311, label %bb_rcarmnext311
bb_rcarm311:
  %v3780 = load i64, ptr %slot24, align 8
  store i64 %v3780, ptr %slot289, align 8
  %v3781 = load i64, ptr %slot213, align 8
  %op3782 = add i64 %v3781, 8
  store i64 %op3782, ptr %slot290, align 8
  %v3783 = load i64, ptr %slot64, align 8
  store i64 %v3783, ptr %slot291, align 8
  %v3784 = load i64, ptr %slot290, align 8
  %v3785 = load i64, ptr %slot289, align 8
  %p3786 = inttoptr i64 %v3784 to ptr
  %p3787 = inttoptr i64 %v3785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3787, ptr %p3786, i64 32, i1 false)
  %v3788 = load i64, ptr %slot20, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  store i32 0, ptr %p3789, align 4, !alias.scope !3, !noalias !4
  %v3790 = load i64, ptr %slot19, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  store i32 1, ptr %p3791, align 4, !alias.scope !3, !noalias !4
  %v3792 = load i64, ptr %slot289, align 8
  %v3793 = load i64, ptr %slot35, align 8
  %p3794 = inttoptr i64 %v3792 to ptr
  %p3795 = inttoptr i64 %v3793 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3795, ptr %p3794, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot19, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  store i32 0, ptr %p3797, align 4, !alias.scope !3, !noalias !4
  %v3798 = load i64, ptr %slot17, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i32, ptr %p3799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3800, ptr %slot292, align 8
  %v3801 = load i32, ptr %slot292, align 8
  %cv3802 = zext i32 %v3801 to i64
  %cond3803 = icmp ne i64 %cv3802, 0
  br i1 %cond3803, label %bb_rcslotdrop320, label %bb_rcslotdone320
bb_rcslotdrop320:
  %v3804 = load i64, ptr %slot17, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i32 0, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot22, align 8
  store i64 %v3806, ptr %slot293, align 8
  %v3807 = load i64, ptr %slot18, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %ld3809 = load i32, ptr %p3808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3809, ptr %slot294, align 8
  %v3810 = load i32, ptr %slot294, align 8
  %op3811 = and i32 %v3810, 28
  store i32 %op3811, ptr %slot295, align 8
  %v3812 = load i32, ptr %slot295, align 8
  %cv3813 = zext i32 %v3812 to i64
  %cond3814 = icmp ne i64 %cv3813, 0
  br i1 %cond3814, label %bb_rcslotrole320, label %bb_rcslotowner320
bb_rcslotrole320:
  %v3815 = load i64, ptr %slot63, align 8
  store i64 %v3815, ptr %slot296, align 8
  %v3816 = load i64, ptr %slot296, align 8
  %v3817 = load i64, ptr %slot293, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3816, i64 %v3817) nomerge, !dbg !142
  br label %bb_rcslotdone320
bb_rcslotowner320:
  %v3818 = load i64, ptr %slot63, align 8
  store i64 %v3818, ptr %slot297, align 8
  %v3819 = load i64, ptr %slot297, align 8
  %v3820 = load i64, ptr %slot293, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3819, i64 %v3820) nomerge, !dbg !142
  br label %bb_rcslotdone320
bb_rcslotdone320:
  br label %bb_i44
bb_rcarmnext311:
  br label %bb_failure
bb_i44:
  %v3821 = load i64, ptr %slot26, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  %ld3823 = load i64, ptr %p3822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3823, ptr %slot298, align 8
  %v3824 = load i64, ptr %slot298, align 8
  %v3825 = load i64, ptr %slot44, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i64 %v3824, ptr %p3826, align 8, !alias.scope !3, !noalias !4
  %v3827 = load i64, ptr %slot35, align 8
  %v3828 = load i64, ptr %slot45, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i64 %v3827, ptr %p3829, align 8, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot35, align 8
  %v3831 = load i64, ptr %slot46, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  store i64 %v3830, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  %v3833 = load i64, ptr %slot46, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %ld3835 = load i64, ptr %p3834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3835, ptr %slot299, align 8
  %v3836 = load i64, ptr %slot299, align 8
  %op3837 = add i64 %v3836, 16
  store i64 %op3837, ptr %slot300, align 8
  %v3838 = load i64, ptr %slot300, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  %ld3840 = load i64, ptr %p3839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3840, ptr %slot301, align 8
  %v3841 = load i64, ptr %slot301, align 8
  %v3842 = load i64, ptr %slot46, align 8
  %p3843 = inttoptr i64 %v3842 to ptr
  store i64 %v3841, ptr %p3843, align 8, !alias.scope !3, !noalias !4
  %v3844 = load i64, ptr %slot27, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  %ld3846 = load i64, ptr %p3845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3846, ptr %slot302, align 8
  %v3847 = load i64, ptr %slot302, align 8
  %v3848 = load i64, ptr %slot47, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  store i64 %v3847, ptr %p3849, align 8, !alias.scope !3, !noalias !4
  %v3850 = load i64, ptr %slot29, align 8
  %p3851 = inttoptr i64 %v3850 to ptr
  %ld3852 = load i64, ptr %p3851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3852, ptr %slot303, align 8
  %v3853 = load i64, ptr %slot303, align 8
  %v3854 = load i64, ptr %slot48, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  store i64 %v3853, ptr %p3855, align 8, !alias.scope !3, !noalias !4
  %v3856 = load i64, ptr %slot49, align 8
  %p3857 = inttoptr i64 %v3856 to ptr
  store i64 1, ptr %p3857, align 8, !alias.scope !3, !noalias !4
  %v3858 = load i64, ptr %slot49, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %ld3860 = load i64, ptr %p3859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3860, ptr %slot304, align 8
  %v3861 = load i64, ptr %slot48, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot305, align 8
  %v3864 = load i64, ptr %slot305, align 8
  %v3865 = load i64, ptr %slot304, align 8
  %ovpair3867 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3864, i64 %v3865)
  %op3866 = extractvalue { i64, i1 } %ovpair3867, 0
  %ov3868 = extractvalue { i64, i1 } %ovpair3867, 1
  store i64 %op3866, ptr %slot306, align 8
  %cv3869 = zext i1 %ov3868 to i64
  store i64 %cv3869, ptr %slot307, align 8
  %v3870 = load i64, ptr %slot307, align 8
  %cond3871 = icmp ne i64 %v3870, 0
  br i1 %cond3871, label %bb_overflow335, label %bb_checked335
bb_overflow335:
  %v3872 = load i64, ptr %slot1, align 8
  %p3873 = inttoptr i64 %v3872 to ptr
  %v3874 = load i64, ptr %slot305, align 8
  %v3875 = load i64, ptr %slot304, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3873, i64 0, i64 %v3874, i64 %v3875, i64 64) nomerge, !dbg !144
  unreachable
bb_checked335:
  %v3876 = load i64, ptr %slot306, align 8
  %v3877 = load i64, ptr %slot48, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i64 %v3876, ptr %p3878, align 8, !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot28, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %ld3881 = load i64, ptr %p3880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3881, ptr %slot308, align 8
  %v3882 = load i64, ptr %slot308, align 8
  %v3883 = load i64, ptr %slot49, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  store i64 %v3882, ptr %p3884, align 8, !alias.scope !3, !noalias !4
  %v3885 = load i64, ptr %slot44, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  %ld3887 = load i64, ptr %p3886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3887, ptr %slot309, align 8
  %v3888 = load i64, ptr %slot45, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  %ld3890 = load i64, ptr %p3889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3890, ptr %slot310, align 8
  %v3891 = load i64, ptr %slot46, align 8
  %p3892 = inttoptr i64 %v3891 to ptr
  %ld3893 = load i64, ptr %p3892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3893, ptr %slot311, align 8
  %v3894 = load i64, ptr %slot47, align 8
  %p3895 = inttoptr i64 %v3894 to ptr
  %ld3896 = load i64, ptr %p3895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3896, ptr %slot312, align 8
  %v3897 = load i64, ptr %slot48, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %ld3899 = load i64, ptr %p3898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3899, ptr %slot313, align 8
  %v3900 = load i64, ptr %slot49, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  %ld3902 = load i64, ptr %p3901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3902, ptr %slot314, align 8
  %v3903 = load i64, ptr %slot1, align 8
  %v3904 = load i64, ptr %slot309, align 8
  %v3905 = load i64, ptr %slot310, align 8
  %v3906 = load i64, ptr %slot311, align 8
  %v3907 = load i64, ptr %slot312, align 8
  %v3908 = load i64, ptr %slot313, align 8
  %v3909 = load i64, ptr %slot314, align 8
  call void @myl_f_3ea6e9e7e7e3f3c99e8bd3ee87e61bb9473edc3368079bda3cc736a65b3decbc(ptr sret([24 x i8]) align 8 %callresult316, i64 %v3903, i64 %v3904, i64 %v3905, i64 %v3906, i64 %v3907, i64 %v3908, i64 %v3909) nomerge, !dbg !146
  %addr3910 = ptrtoint ptr %callresult316 to i64
  store i64 %addr3910, ptr %slot315, align 8
  %v3911 = load i64, ptr %slot315, align 8
  %v3912 = load i64, ptr %slot44, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i64 %v3911, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  %v3914 = load i64, ptr %slot44, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  %ld3916 = load i64, ptr %p3915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3916, ptr %slot317, align 8
  %v3917 = load i64, ptr %slot24, align 8
  store i64 %v3917, ptr %slot318, align 8
  %v3918 = load i64, ptr %slot317, align 8
  %v3919 = load i64, ptr %slot318, align 8
  %p3920 = inttoptr i64 %v3918 to ptr
  %p3921 = inttoptr i64 %v3919 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3921, ptr %p3920, i64 24, i1 false)
  %v3922 = load i64, ptr %slot20, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  store i32 2, ptr %p3923, align 4, !alias.scope !3, !noalias !4
  %v3924 = load i64, ptr %slot19, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  store i32 1, ptr %p3925, align 4, !alias.scope !3, !noalias !4
  %v3926 = load i64, ptr %slot17, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  %ld3928 = load i32, ptr %p3927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3928, ptr %slot319, align 8
  %v3929 = load i32, ptr %slot319, align 8
  %cv3930 = zext i32 %v3929 to i64
  %cond3931 = icmp ne i64 %cv3930, 0
  br i1 %cond3931, label %bb_rcslotdrop351, label %bb_rcslotdone351
bb_rcslotdrop351:
  %v3932 = load i64, ptr %slot17, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  store i32 0, ptr %p3933, align 4, !alias.scope !3, !noalias !4
  %v3934 = load i64, ptr %slot22, align 8
  store i64 %v3934, ptr %slot320, align 8
  %v3935 = load i64, ptr %slot18, align 8
  %p3936 = inttoptr i64 %v3935 to ptr
  %ld3937 = load i32, ptr %p3936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3937, ptr %slot321, align 8
  %v3938 = load i32, ptr %slot321, align 8
  %op3939 = and i32 %v3938, 28
  store i32 %op3939, ptr %slot322, align 8
  %v3940 = load i32, ptr %slot322, align 8
  %cv3941 = zext i32 %v3940 to i64
  %cond3942 = icmp ne i64 %cv3941, 0
  br i1 %cond3942, label %bb_rcslotrole351, label %bb_rcslotowner351
bb_rcslotrole351:
  %v3943 = load i64, ptr %slot63, align 8
  store i64 %v3943, ptr %slot323, align 8
  %v3944 = load i64, ptr %slot323, align 8
  %v3945 = load i64, ptr %slot320, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3944, i64 %v3945) nomerge, !dbg !146
  br label %bb_rcslotdone351
bb_rcslotowner351:
  %v3946 = load i64, ptr %slot63, align 8
  store i64 %v3946, ptr %slot324, align 8
  %v3947 = load i64, ptr %slot324, align 8
  %v3948 = load i64, ptr %slot320, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3947, i64 %v3948) nomerge, !dbg !146
  br label %bb_rcslotdone351
bb_rcslotdone351:
  %v3949 = load i64, ptr %slot22, align 8
  store i64 %v3949, ptr %slot325, align 8
  %v3950 = load i64, ptr %slot24, align 8
  store i64 %v3950, ptr %slot326, align 8
  %v3951 = load i64, ptr %slot326, align 8
  %v3952 = load i64, ptr %slot325, align 8
  %p3953 = inttoptr i64 %v3951 to ptr
  %p3954 = inttoptr i64 %v3952 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3954, ptr %p3953, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3955 = load i64, ptr %slot18, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  store i32 2, ptr %p3956, align 4, !alias.scope !3, !noalias !4
  %v3957 = load i64, ptr %slot20, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i32, ptr %p3958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3959, ptr %slot327, align 8
  %v3960 = load i32, ptr %slot327, align 8
  %v3961 = load i64, ptr %slot18, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 %v3960, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot19, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 0, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot17, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  store i32 1, ptr %p3966, align 4, !alias.scope !3, !noalias !4
  %v3967 = load i64, ptr %slot325, align 8
  %v3968 = load i64, ptr %slot44, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i64 %v3967, ptr %p3969, align 8, !alias.scope !3, !noalias !4
  %v3970 = load i64, ptr %slot44, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i64, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3972, ptr %slot328, align 8
  %v3973 = load i64, ptr %slot328, align 8
  %p3974 = inttoptr i64 %v3973 to ptr
  %ld3975 = load i32, ptr %p3974, align 4
  %ext3976 = zext i32 %ld3975 to i64
  store i64 %ext3976, ptr %slot329, align 8
  %v3977 = load i64, ptr %slot329, align 8
  %cmp3978 = icmp eq i64 %v3977, 0
  %cv3979 = zext i1 %cmp3978 to i64
  store i64 %cv3979, ptr %slot330, align 8
  %v3980 = load i64, ptr %slot330, align 8
  %cond3981 = icmp ne i64 %v3980, 0
  br i1 %cond3981, label %bb_rctryok367, label %bb_rctryerror367
bb_rctryerror367:
  %p3982 = inttoptr i64 ptrtoint (ptr @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3982, i64 12884901942) "call-inline-cost"="0", !dbg !148
  %v3983 = load i64, ptr %slot328, align 8
  %op3984 = add i64 %v3983, 8
  store i64 %op3984, ptr %slot331, align 8
  %v3985 = load i64, ptr %slot50, align 8
  store i64 %v3985, ptr %slot332, align 8
  %v3986 = load i64, ptr %slot332, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  store i64 0, ptr %p3987, align 8, !alias.scope !3, !noalias !4
  %v3988 = load i64, ptr %slot332, align 8
  %p3990 = inttoptr i64 %v3988 to ptr
  %gep3991 = getelementptr i8, ptr %p3990, i64 8
  %op3989 = ptrtoint ptr %gep3991 to i64
  store i64 %op3989, ptr %slot333, align 8
  %v3992 = load i64, ptr %slot333, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  store i64 0, ptr %p3993, align 8, !alias.scope !3, !noalias !4
  %v3994 = load i64, ptr %slot332, align 8
  %p3996 = inttoptr i64 %v3994 to ptr
  %gep3997 = getelementptr i8, ptr %p3996, i64 16
  %op3995 = ptrtoint ptr %gep3997 to i64
  store i64 %op3995, ptr %slot334, align 8
  %v3998 = load i64, ptr %slot334, align 8
  %p3999 = inttoptr i64 %v3998 to ptr
  store i64 0, ptr %p3999, align 8, !alias.scope !3, !noalias !4
  %v4000 = load i64, ptr %slot332, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  store i32 1, ptr %p4001, align 4, !alias.scope !3, !noalias !4
  %v4002 = load i64, ptr %slot332, align 8
  %p4004 = inttoptr i64 %v4002 to ptr
  %gep4005 = getelementptr i8, ptr %p4004, i64 8
  %op4003 = ptrtoint ptr %gep4005 to i64
  store i64 %op4003, ptr %slot335, align 8
  %v4006 = load i64, ptr %slot21, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  store i32 1, ptr %p4007, align 4, !alias.scope !3, !noalias !4
  %v4008 = load i64, ptr %slot64, align 8
  store i64 %v4008, ptr %slot336, align 8
  %v4009 = load i64, ptr %slot63, align 8
  %v4010 = load i64, ptr %slot335, align 8
  %v4011 = load i64, ptr %slot331, align 8
  %v4012 = load i64, ptr %slot336, align 8
  %cv4013 = trunc i64 %v4012 to i32
  %call4014 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v4009, i64 %v4010, i64 %v4011, i32 %cv4013) nomerge, !dbg !148
  store i32 %call4014, ptr %slot337, align 8
  %v4015 = load i32, ptr %slot337, align 8
  %cv4016 = zext i32 %v4015 to i64
  %cond4017 = icmp ne i64 %cv4016, 0
  br i1 %cond4017, label %bb_rcsuccess378, label %bb_rcfailure378
bb_rcfailure378:
  %v4018 = load i64, ptr %slot63, align 8
  %p4019 = inttoptr i64 %v4018 to ptr
  %call4020 = call i32 @myl_rc_take_failure(ptr %p4019) nomerge, !dbg !148
  store i32 %call4020, ptr %slot338, align 8
  %v4021 = load i64, ptr %slot1, align 8
  %p4022 = inttoptr i64 %v4021 to ptr
  %v4023 = load i32, ptr %slot338, align 8
  %call4024 = call i32 @myl_qbe_rc_status(ptr %p4022, i32 %v4023) nomerge, !dbg !148
  store i32 %call4024, ptr %slot339, align 8
  br label %bb_failure
bb_rcsuccess378:
  %v4025 = load i64, ptr %slot332, align 8
  %v4026 = load i64, ptr %slot44, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  store i64 %v4025, ptr %p4027, align 8, !alias.scope !3, !noalias !4
  %v4028 = load i64, ptr %slot44, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  %ld4030 = load i64, ptr %p4029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4030, ptr %slot340, align 8
  %v4031 = load i64, ptr %slot24, align 8
  store i64 %v4031, ptr %slot341, align 8
  %v4032 = load i64, ptr %slot340, align 8
  %v4033 = load i64, ptr %slot341, align 8
  %p4034 = inttoptr i64 %v4032 to ptr
  %p4035 = inttoptr i64 %v4033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4035, ptr %p4034, i64 24, i1 false)
  %v4036 = load i64, ptr %slot20, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  store i32 2, ptr %p4037, align 4, !alias.scope !3, !noalias !4
  %v4038 = load i64, ptr %slot19, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 1, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot17, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i32, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4042, ptr %slot342, align 8
  %v4043 = load i32, ptr %slot342, align 8
  %cv4044 = zext i32 %v4043 to i64
  %cond4045 = icmp ne i64 %cv4044, 0
  br i1 %cond4045, label %bb_rcslotdrop387, label %bb_rcslotdone387
bb_rcslotdrop387:
  %v4046 = load i64, ptr %slot17, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  store i32 0, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  %v4048 = load i64, ptr %slot22, align 8
  store i64 %v4048, ptr %slot343, align 8
  %v4049 = load i64, ptr %slot18, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %ld4051 = load i32, ptr %p4050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4051, ptr %slot344, align 8
  %v4052 = load i32, ptr %slot344, align 8
  %op4053 = and i32 %v4052, 28
  store i32 %op4053, ptr %slot345, align 8
  %v4054 = load i32, ptr %slot345, align 8
  %cv4055 = zext i32 %v4054 to i64
  %cond4056 = icmp ne i64 %cv4055, 0
  br i1 %cond4056, label %bb_rcslotrole387, label %bb_rcslotowner387
bb_rcslotrole387:
  %v4057 = load i64, ptr %slot63, align 8
  store i64 %v4057, ptr %slot346, align 8
  %v4058 = load i64, ptr %slot346, align 8
  %v4059 = load i64, ptr %slot343, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v4058, i64 %v4059) nomerge, !dbg !148
  br label %bb_rcslotdone387
bb_rcslotowner387:
  %v4060 = load i64, ptr %slot63, align 8
  store i64 %v4060, ptr %slot347, align 8
  %v4061 = load i64, ptr %slot347, align 8
  %v4062 = load i64, ptr %slot343, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v4061, i64 %v4062) nomerge, !dbg !148
  br label %bb_rcslotdone387
bb_rcslotdone387:
  %v4063 = load i64, ptr %slot22, align 8
  store i64 %v4063, ptr %slot348, align 8
  %v4064 = load i64, ptr %slot24, align 8
  store i64 %v4064, ptr %slot349, align 8
  %v4065 = load i64, ptr %slot349, align 8
  %v4066 = load i64, ptr %slot348, align 8
  %p4067 = inttoptr i64 %v4065 to ptr
  %p4068 = inttoptr i64 %v4066 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4068, ptr %p4067, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4069 = load i64, ptr %slot18, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  store i32 2, ptr %p4070, align 4, !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot20, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %ld4073 = load i32, ptr %p4072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4073, ptr %slot350, align 8
  %v4074 = load i32, ptr %slot350, align 8
  %v4075 = load i64, ptr %slot18, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  store i32 %v4074, ptr %p4076, align 4, !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot19, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  store i32 0, ptr %p4078, align 4, !alias.scope !3, !noalias !4
  %v4079 = load i64, ptr %slot17, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  store i32 1, ptr %p4080, align 4, !alias.scope !3, !noalias !4
  %v4081 = load i64, ptr %slot348, align 8
  %v4082 = load i64, ptr %slot44, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  store i64 %v4081, ptr %p4083, align 8, !alias.scope !3, !noalias !4
  br label %bb_i56
bb_rctryok367:
  %v4084 = load i64, ptr %slot50, align 8
  store i64 %v4084, ptr %slot351, align 8
  %v4085 = load i64, ptr %slot351, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  store i64 0, ptr %p4086, align 8, !alias.scope !3, !noalias !4
  %v4087 = load i64, ptr %slot21, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  store i32 1, ptr %p4088, align 4, !alias.scope !3, !noalias !4
  %v4089 = load i64, ptr %slot328, align 8
  %op4090 = add i64 %v4089, 8
  store i64 %op4090, ptr %slot352, align 8
  %v4091 = load i64, ptr %slot64, align 8
  store i64 %v4091, ptr %slot353, align 8
  %v4092 = load i64, ptr %slot352, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  %ld4094 = load i64, ptr %p4093, align 8
  store i64 %ld4094, ptr %slot354, align 8
  %v4095 = load i64, ptr %slot354, align 8
  %v4096 = load i64, ptr %slot351, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  store i64 %v4095, ptr %p4097, align 8, !alias.scope !3, !noalias !4
  %v4098 = load i64, ptr %slot351, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %ld4100 = load i64, ptr %p4099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4100, ptr %slot355, align 8
  %v4101 = load i64, ptr %slot355, align 8
  %v4102 = load i64, ptr %slot44, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  store i64 %v4101, ptr %p4103, align 8, !alias.scope !3, !noalias !4
  %v4104 = load i64, ptr %slot17, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  %ld4106 = load i32, ptr %p4105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4106, ptr %slot356, align 8
  %v4107 = load i32, ptr %slot356, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcslotdrop411, label %bb_rcslotdone411
bb_rcslotdrop411:
  %v4110 = load i64, ptr %slot17, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  store i32 0, ptr %p4111, align 4, !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot22, align 8
  store i64 %v4112, ptr %slot357, align 8
  %v4113 = load i64, ptr %slot18, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %ld4115 = load i32, ptr %p4114, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4115, ptr %slot358, align 8
  %v4116 = load i32, ptr %slot358, align 8
  %op4117 = and i32 %v4116, 28
  store i32 %op4117, ptr %slot359, align 8
  %v4118 = load i32, ptr %slot359, align 8
  %cv4119 = zext i32 %v4118 to i64
  %cond4120 = icmp ne i64 %cv4119, 0
  br i1 %cond4120, label %bb_rcslotrole411, label %bb_rcslotowner411
bb_rcslotrole411:
  %v4121 = load i64, ptr %slot63, align 8
  store i64 %v4121, ptr %slot360, align 8
  %v4122 = load i64, ptr %slot360, align 8
  %v4123 = load i64, ptr %slot357, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v4122, i64 %v4123) nomerge, !dbg !148
  br label %bb_rcslotdone411
bb_rcslotowner411:
  %v4124 = load i64, ptr %slot63, align 8
  store i64 %v4124, ptr %slot361, align 8
  %v4125 = load i64, ptr %slot361, align 8
  %v4126 = load i64, ptr %slot357, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v4125, i64 %v4126) nomerge, !dbg !148
  br label %bb_rcslotdone411
bb_rcslotdone411:
  br label %bb_i57
bb_i56:
  %v4127 = load i64, ptr %slot44, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  %ld4129 = load i64, ptr %p4128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4129, ptr %slot362, align 8
  %v4130 = load i64, ptr %slot44, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  %ld4132 = load i64, ptr %p4131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4132, ptr %slot363, align 8
  %v4133 = load i64, ptr %slot17, align 8
  %p4134 = inttoptr i64 %v4133 to ptr
  %ld4135 = load i32, ptr %p4134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4135, ptr %slot364, align 8
  %v4136 = load i64, ptr %slot18, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  %ld4138 = load i32, ptr %p4137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4138, ptr %slot365, align 8
  %v4139 = load i32, ptr %slot365, align 8
  %op4140 = and i32 %v4139, 24
  store i32 %op4140, ptr %slot365, align 8
  %v4141 = load i32, ptr %slot365, align 8
  %cmp4142 = icmp eq i32 %v4141, 0
  %cv4143 = zext i1 %cmp4142 to i32
  store i32 %cv4143, ptr %slot366, align 8
  %v4144 = load i32, ptr %slot364, align 8
  %v4145 = load i32, ptr %slot366, align 8
  %op4146 = and i32 %v4144, %v4145
  store i32 %op4146, ptr %slot367, align 8
  %v4147 = load i32, ptr %slot367, align 8
  %cv4148 = zext i32 %v4147 to i64
  %cond4149 = icmp ne i64 %cv4148, 0
  br i1 %cond4149, label %bb_rctake420, label %bb_rccopy420
bb_rctake420:
  %v4150 = load i64, ptr %slot24, align 8
  store i64 %v4150, ptr %slot368, align 8
  %v4151 = load i64, ptr %slot64, align 8
  store i64 %v4151, ptr %slot369, align 8
  %v4152 = load i64, ptr %slot63, align 8
  %v4153 = load i64, ptr %slot368, align 8
  %v4154 = load i64, ptr %slot363, align 8
  %v4155 = load i64, ptr %slot369, align 8
  %cv4156 = trunc i64 %v4155 to i32
  %call4157 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4152, i64 %v4153, i64 %v4154, i32 %cv4156) nomerge, !dbg !150
  store i32 %call4157, ptr %slot370, align 8
  %v4158 = load i32, ptr %slot370, align 8
  %cv4159 = zext i32 %v4158 to i64
  %cond4160 = icmp ne i64 %cv4159, 0
  br i1 %cond4160, label %bb_rcsuccess430, label %bb_rcfailure430
bb_rcfailure430:
  %v4161 = load i64, ptr %slot63, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %call4163 = call i32 @myl_rc_take_failure(ptr %p4162) nomerge, !dbg !150
  store i32 %call4163, ptr %slot371, align 8
  %v4164 = load i64, ptr %slot1, align 8
  %p4165 = inttoptr i64 %v4164 to ptr
  %v4166 = load i32, ptr %slot371, align 8
  %call4167 = call i32 @myl_qbe_rc_status(ptr %p4165, i32 %v4166) nomerge, !dbg !150
  store i32 %call4167, ptr %slot372, align 8
  br label %bb_failure
bb_rcsuccess430:
  %v4168 = load i64, ptr %slot17, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  store i32 0, ptr %p4169, align 4, !alias.scope !3, !noalias !4
  %v4170 = load i64, ptr %slot20, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  store i32 2, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  %v4172 = load i64, ptr %slot19, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  store i32 1, ptr %p4173, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared420
bb_rccopy420:
  %v4174 = load i64, ptr %slot24, align 8
  store i64 %v4174, ptr %slot373, align 8
  %v4175 = load i64, ptr %slot64, align 8
  store i64 %v4175, ptr %slot374, align 8
  %v4176 = load i64, ptr %slot63, align 8
  %v4177 = load i64, ptr %slot373, align 8
  %v4178 = load i64, ptr %slot363, align 8
  %v4179 = load i64, ptr %slot374, align 8
  %cv4180 = trunc i64 %v4179 to i32
  %call4181 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v4176, i64 %v4177, i64 %v4178, i32 %cv4180) nomerge, !dbg !150
  store i32 %call4181, ptr %slot375, align 8
  %v4182 = load i32, ptr %slot375, align 8
  %cv4183 = zext i32 %v4182 to i64
  %cond4184 = icmp ne i64 %cv4183, 0
  br i1 %cond4184, label %bb_rcsuccess439, label %bb_rcfailure439
bb_rcfailure439:
  %v4185 = load i64, ptr %slot63, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  %call4187 = call i32 @myl_rc_take_failure(ptr %p4186) nomerge, !dbg !150
  store i32 %call4187, ptr %slot376, align 8
  %v4188 = load i64, ptr %slot1, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  %v4190 = load i32, ptr %slot376, align 8
  %call4191 = call i32 @myl_qbe_rc_status(ptr %p4189, i32 %v4190) nomerge, !dbg !150
  store i32 %call4191, ptr %slot377, align 8
  br label %bb_failure
bb_rcsuccess439:
  %v4192 = load i64, ptr %slot20, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  store i32 2, ptr %p4193, align 4, !alias.scope !3, !noalias !4
  %v4194 = load i64, ptr %slot19, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  store i32 1, ptr %p4195, align 4, !alias.scope !3, !noalias !4
  %v4196 = load i64, ptr %slot17, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  %ld4198 = load i32, ptr %p4197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4198, ptr %slot378, align 8
  %v4199 = load i32, ptr %slot378, align 8
  %cv4200 = zext i32 %v4199 to i64
  %cond4201 = icmp ne i64 %cv4200, 0
  br i1 %cond4201, label %bb_rcslotdrop446, label %bb_rcslotdone446
bb_rcslotdrop446:
  %v4202 = load i64, ptr %slot17, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  store i32 0, ptr %p4203, align 4, !alias.scope !3, !noalias !4
  %v4204 = load i64, ptr %slot22, align 8
  store i64 %v4204, ptr %slot379, align 8
  %v4205 = load i64, ptr %slot18, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %ld4207 = load i32, ptr %p4206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4207, ptr %slot380, align 8
  %v4208 = load i32, ptr %slot380, align 8
  %op4209 = and i32 %v4208, 28
  store i32 %op4209, ptr %slot381, align 8
  %v4210 = load i32, ptr %slot381, align 8
  %cv4211 = zext i32 %v4210 to i64
  %cond4212 = icmp ne i64 %cv4211, 0
  br i1 %cond4212, label %bb_rcslotrole446, label %bb_rcslotowner446
bb_rcslotrole446:
  %v4213 = load i64, ptr %slot63, align 8
  store i64 %v4213, ptr %slot382, align 8
  %v4214 = load i64, ptr %slot382, align 8
  %v4215 = load i64, ptr %slot379, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4214, i64 %v4215) nomerge, !dbg !150
  br label %bb_rcslotdone446
bb_rcslotowner446:
  %v4216 = load i64, ptr %slot63, align 8
  store i64 %v4216, ptr %slot383, align 8
  %v4217 = load i64, ptr %slot383, align 8
  %v4218 = load i64, ptr %slot379, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4217, i64 %v4218) nomerge, !dbg !150
  br label %bb_rcslotdone446
bb_rcslotdone446:
  br label %bb_rcprepared420
bb_rcprepared420:
  %v4219 = load i64, ptr %slot24, align 8
  store i64 %v4219, ptr %slot384, align 8
  %v4220 = load i64, ptr %slot19, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  store i32 0, ptr %p4221, align 4, !alias.scope !3, !noalias !4
  %v4222 = load i64, ptr %slot17, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  %ld4224 = load i32, ptr %p4223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4224, ptr %slot385, align 8
  %v4225 = load i32, ptr %slot385, align 8
  %cv4226 = zext i32 %v4225 to i64
  %cond4227 = icmp ne i64 %cv4226, 0
  br i1 %cond4227, label %bb_rcslotdrop457, label %bb_rcslotdone457
bb_rcslotdrop457:
  %v4228 = load i64, ptr %slot17, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  store i32 0, ptr %p4229, align 4, !alias.scope !3, !noalias !4
  %v4230 = load i64, ptr %slot22, align 8
  store i64 %v4230, ptr %slot386, align 8
  %v4231 = load i64, ptr %slot18, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i32, ptr %p4232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4233, ptr %slot387, align 8
  %v4234 = load i32, ptr %slot387, align 8
  %op4235 = and i32 %v4234, 28
  store i32 %op4235, ptr %slot388, align 8
  %v4236 = load i32, ptr %slot388, align 8
  %cv4237 = zext i32 %v4236 to i64
  %cond4238 = icmp ne i64 %cv4237, 0
  br i1 %cond4238, label %bb_rcslotrole457, label %bb_rcslotowner457
bb_rcslotrole457:
  %v4239 = load i64, ptr %slot63, align 8
  store i64 %v4239, ptr %slot389, align 8
  %v4240 = load i64, ptr %slot389, align 8
  %v4241 = load i64, ptr %slot386, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4240, i64 %v4241) nomerge, !dbg !150
  br label %bb_rcslotdone457
bb_rcslotowner457:
  %v4242 = load i64, ptr %slot63, align 8
  store i64 %v4242, ptr %slot390, align 8
  %v4243 = load i64, ptr %slot390, align 8
  %v4244 = load i64, ptr %slot386, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4243, i64 %v4244) nomerge, !dbg !150
  br label %bb_rcslotdone457
bb_rcslotdone457:
  %v4245 = load i64, ptr %slot15, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  %ld4247 = load i32, ptr %p4246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4247, ptr %slot391, align 8
  %v4248 = load i32, ptr %slot391, align 8
  %cv4249 = zext i32 %v4248 to i64
  %cond4250 = icmp ne i64 %cv4249, 0
  br i1 %cond4250, label %bb_rcslotdrop484, label %bb_rcslotdone484
bb_rcslotdrop484:
  %v4251 = load i64, ptr %slot15, align 8
  %p4252 = inttoptr i64 %v4251 to ptr
  store i32 0, ptr %p4252, align 4, !alias.scope !3, !noalias !4
  %v4253 = load i64, ptr %slot43, align 8
  store i64 %v4253, ptr %slot392, align 8
  %v4254 = load i64, ptr %slot16, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  %ld4256 = load i32, ptr %p4255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4256, ptr %slot393, align 8
  %v4257 = load i32, ptr %slot393, align 8
  %op4258 = and i32 %v4257, 28
  store i32 %op4258, ptr %slot394, align 8
  %v4259 = load i32, ptr %slot394, align 8
  %cv4260 = zext i32 %v4259 to i64
  %cond4261 = icmp ne i64 %cv4260, 0
  br i1 %cond4261, label %bb_rcslotrole484, label %bb_rcslotowner484
bb_rcslotrole484:
  %v4262 = load i64, ptr %slot63, align 8
  store i64 %v4262, ptr %slot395, align 8
  %v4263 = load i64, ptr %slot395, align 8
  %v4264 = load i64, ptr %slot392, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4263, i64 %v4264) nomerge, !dbg !150
  br label %bb_rcslotdone484
bb_rcslotowner484:
  %v4265 = load i64, ptr %slot63, align 8
  store i64 %v4265, ptr %slot396, align 8
  %v4266 = load i64, ptr %slot396, align 8
  %v4267 = load i64, ptr %slot392, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4266, i64 %v4267) nomerge, !dbg !150
  br label %bb_rcslotdone484
bb_rcslotdone484:
  %v4268 = load i64, ptr %slot13, align 8
  %p4269 = inttoptr i64 %v4268 to ptr
  %ld4270 = load i32, ptr %p4269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4270, ptr %slot397, align 8
  %v4271 = load i32, ptr %slot397, align 8
  %cv4272 = zext i32 %v4271 to i64
  %cond4273 = icmp ne i64 %cv4272, 0
  br i1 %cond4273, label %bb_rcslotdrop493, label %bb_rcslotdone493
bb_rcslotdrop493:
  %v4274 = load i64, ptr %slot13, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  store i32 0, ptr %p4275, align 4, !alias.scope !3, !noalias !4
  %v4276 = load i64, ptr %slot42, align 8
  store i64 %v4276, ptr %slot398, align 8
  %v4277 = load i64, ptr %slot14, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %ld4279 = load i32, ptr %p4278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4279, ptr %slot399, align 8
  %v4280 = load i32, ptr %slot399, align 8
  %op4281 = and i32 %v4280, 28
  store i32 %op4281, ptr %slot400, align 8
  %v4282 = load i32, ptr %slot400, align 8
  %cv4283 = zext i32 %v4282 to i64
  %cond4284 = icmp ne i64 %cv4283, 0
  br i1 %cond4284, label %bb_rcslotrole493, label %bb_rcslotowner493
bb_rcslotrole493:
  %v4285 = load i64, ptr %slot63, align 8
  store i64 %v4285, ptr %slot401, align 8
  %v4286 = load i64, ptr %slot398, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  %ld4288 = load i64, ptr %p4287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4288, ptr %slot402, align 8
  %v4289 = load i64, ptr %slot402, align 8
  %cmp4290 = icmp ne i64 %v4289, 0
  %cv4291 = zext i1 %cmp4290 to i32
  store i32 %cv4291, ptr %slot403, align 8
  %v4292 = load i32, ptr %slot403, align 8
  %cv4293 = zext i32 %v4292 to i64
  %cond4294 = icmp ne i64 %cv4293, 0
  br i1 %cond4294, label %bb_rcgnn509, label %bb_rcgdone509
bb_rcgnn509:
  %v4295 = load i64, ptr %slot402, align 8
  %op4296 = sub i64 %v4295, 16
  store i64 %op4296, ptr %slot404, align 8
  %v4297 = load i64, ptr %slot402, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  %rgep4299 = getelementptr i8, ptr %p4298, i64 -16
  %ld4300 = load i64, ptr %rgep4299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4300, ptr %slot405, align 8
  %v4301 = load i64, ptr %slot405, align 8
  %op4302 = and i64 %v4301, 4611686018427387906
  store i64 %op4302, ptr %slot406, align 8
  %v4303 = load i64, ptr %slot406, align 8
  %cmp4304 = icmp ne i64 %v4303, 0
  %cv4305 = zext i1 %cmp4304 to i32
  store i32 %cv4305, ptr %slot407, align 8
  %v4306 = load i32, ptr %slot407, align 8
  %cv4307 = zext i32 %v4306 to i64
  %cond4308 = icmp ne i64 %cv4307, 0
  br i1 %cond4308, label %bb_rcgclear509, label %bb_rcgcounted509
bb_rcgcounted509:
  %v4309 = load i64, ptr %slot402, align 8
  %op4310 = sub i64 %v4309, 24
  store i64 %op4310, ptr %slot408, align 8
  %v4311 = load i64, ptr %slot402, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  %rgep4313 = getelementptr i8, ptr %p4312, i64 -24
  %ld4314 = load i64, ptr %rgep4313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4314, ptr %slot409, align 8
  %v4315 = load i64, ptr %slot409, align 8
  %op4316 = sub i64 %v4315, 1
  store i64 %op4316, ptr %slot410, align 8
  %v4317 = load i64, ptr %slot410, align 8
  %cmp4318 = icmp eq i64 %v4317, 0
  %cv4319 = zext i1 %cmp4318 to i32
  store i32 %cv4319, ptr %slot411, align 8
  %v4320 = load i32, ptr %slot411, align 8
  %cv4321 = zext i32 %v4320 to i64
  %cond4322 = icmp ne i64 %cv4321, 0
  br i1 %cond4322, label %bb_rcglast509, label %bb_rcgdec509
bb_rcglast509:
  %v4323 = load i64, ptr %slot402, align 8
  %op4324 = sub i64 %v4323, 32
  store i64 %op4324, ptr %slot412, align 8
  %v4325 = load i64, ptr %slot402, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  %rgep4327 = getelementptr i8, ptr %p4326, i64 -32
  %ld4328 = load i64, ptr %rgep4327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4328, ptr %slot413, align 8
  %v4329 = load i64, ptr %slot413, align 8
  %cmp4330 = icmp ne i64 %v4329, 0
  %cv4331 = zext i1 %cmp4330 to i32
  store i32 %cv4331, ptr %slot414, align 8
  %v4332 = load i32, ptr %slot414, align 8
  %cv4333 = zext i32 %v4332 to i64
  %cond4334 = icmp ne i64 %cv4333, 0
  br i1 %cond4334, label %bb_rcgdec509, label %bb_rcgslow509
bb_rcgslow509:
  %v4335 = load i64, ptr %slot401, align 8
  %v4336 = load i64, ptr %slot398, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4335, i64 %v4336) nomerge, !dbg !150
  br label %bb_rcgdone509
bb_rcgdec509:
  %v4337 = load i64, ptr %slot410, align 8
  %v4338 = load i64, ptr %slot402, align 8
  %p4339 = inttoptr i64 %v4338 to ptr
  %rgep4340 = getelementptr i8, ptr %p4339, i64 -24
  store i64 %v4337, ptr %rgep4340, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear509
bb_rcgclear509:
  %v4341 = load i64, ptr %slot398, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  store i64 0, ptr %p4342, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone509
bb_rcgdone509:
  br label %bb_rcslotdone493
bb_rcslotowner493:
  %v4343 = load i64, ptr %slot63, align 8
  store i64 %v4343, ptr %slot415, align 8
  %v4344 = load i64, ptr %slot398, align 8
  %p4345 = inttoptr i64 %v4344 to ptr
  %ld4346 = load i64, ptr %p4345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4346, ptr %slot416, align 8
  %v4347 = load i64, ptr %slot416, align 8
  %cmp4348 = icmp ne i64 %v4347, 0
  %cv4349 = zext i1 %cmp4348 to i32
  store i32 %cv4349, ptr %slot417, align 8
  %v4350 = load i32, ptr %slot417, align 8
  %cv4351 = zext i32 %v4350 to i64
  %cond4352 = icmp ne i64 %cv4351, 0
  br i1 %cond4352, label %bb_rcgnn524, label %bb_rcgdone524
bb_rcgnn524:
  %v4353 = load i64, ptr %slot416, align 8
  %op4354 = sub i64 %v4353, 16
  store i64 %op4354, ptr %slot418, align 8
  %v4355 = load i64, ptr %slot416, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  %rgep4357 = getelementptr i8, ptr %p4356, i64 -16
  %ld4358 = load i64, ptr %rgep4357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4358, ptr %slot419, align 8
  %v4359 = load i64, ptr %slot419, align 8
  %op4360 = and i64 %v4359, 4611686018427387906
  store i64 %op4360, ptr %slot420, align 8
  %v4361 = load i64, ptr %slot420, align 8
  %cmp4362 = icmp ne i64 %v4361, 0
  %cv4363 = zext i1 %cmp4362 to i32
  store i32 %cv4363, ptr %slot421, align 8
  %v4364 = load i32, ptr %slot421, align 8
  %cv4365 = zext i32 %v4364 to i64
  %cond4366 = icmp ne i64 %cv4365, 0
  br i1 %cond4366, label %bb_rcgclear524, label %bb_rcgcounted524
bb_rcgcounted524:
  %v4367 = load i64, ptr %slot416, align 8
  %op4368 = sub i64 %v4367, 32
  store i64 %op4368, ptr %slot422, align 8
  %v4369 = load i64, ptr %slot416, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  %rgep4371 = getelementptr i8, ptr %p4370, i64 -32
  %ld4372 = load i64, ptr %rgep4371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4372, ptr %slot423, align 8
  %v4373 = load i64, ptr %slot423, align 8
  %op4374 = sub i64 %v4373, 1
  store i64 %op4374, ptr %slot424, align 8
  %v4375 = load i64, ptr %slot424, align 8
  %cmp4376 = icmp eq i64 %v4375, 0
  %cv4377 = zext i1 %cmp4376 to i32
  store i32 %cv4377, ptr %slot425, align 8
  %v4378 = load i32, ptr %slot425, align 8
  %cv4379 = zext i32 %v4378 to i64
  %cond4380 = icmp ne i64 %cv4379, 0
  br i1 %cond4380, label %bb_rcglast524, label %bb_rcgdec524
bb_rcglast524:
  %v4381 = load i64, ptr %slot416, align 8
  %op4382 = sub i64 %v4381, 24
  store i64 %op4382, ptr %slot426, align 8
  %v4383 = load i64, ptr %slot416, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  %rgep4385 = getelementptr i8, ptr %p4384, i64 -24
  %ld4386 = load i64, ptr %rgep4385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4386, ptr %slot427, align 8
  %v4387 = load i64, ptr %slot427, align 8
  %cmp4388 = icmp ne i64 %v4387, 0
  %cv4389 = zext i1 %cmp4388 to i32
  store i32 %cv4389, ptr %slot428, align 8
  %v4390 = load i32, ptr %slot428, align 8
  %cv4391 = zext i32 %v4390 to i64
  %cond4392 = icmp ne i64 %cv4391, 0
  br i1 %cond4392, label %bb_rcgdec524, label %bb_rcgslow524
bb_rcgslow524:
  %v4393 = load i64, ptr %slot415, align 8
  %v4394 = load i64, ptr %slot398, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4393, i64 %v4394) nomerge, !dbg !150
  br label %bb_rcgdone524
bb_rcgdec524:
  %v4395 = load i64, ptr %slot424, align 8
  %v4396 = load i64, ptr %slot416, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %rgep4398 = getelementptr i8, ptr %p4397, i64 -32
  store i64 %v4395, ptr %rgep4398, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear524
bb_rcgclear524:
  %v4399 = load i64, ptr %slot398, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i64 0, ptr %p4400, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone524
bb_rcgdone524:
  br label %bb_rcslotdone493
bb_rcslotdone493:
  %v4401 = load i64, ptr %slot11, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i32, ptr %p4402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4403, ptr %slot429, align 8
  %v4404 = load i32, ptr %slot429, align 8
  %cv4405 = zext i32 %v4404 to i64
  %cond4406 = icmp ne i64 %cv4405, 0
  br i1 %cond4406, label %bb_rcslotdrop530, label %bb_rcslotdone530
bb_rcslotdrop530:
  %v4407 = load i64, ptr %slot11, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  store i32 0, ptr %p4408, align 4, !alias.scope !3, !noalias !4
  %v4409 = load i64, ptr %slot41, align 8
  store i64 %v4409, ptr %slot430, align 8
  %v4410 = load i64, ptr %slot12, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  %ld4412 = load i32, ptr %p4411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4412, ptr %slot431, align 8
  %v4413 = load i32, ptr %slot431, align 8
  %op4414 = and i32 %v4413, 28
  store i32 %op4414, ptr %slot432, align 8
  %v4415 = load i32, ptr %slot432, align 8
  %cv4416 = zext i32 %v4415 to i64
  %cond4417 = icmp ne i64 %cv4416, 0
  br i1 %cond4417, label %bb_rcslotrole530, label %bb_rcslotowner530
bb_rcslotrole530:
  %v4418 = load i64, ptr %slot63, align 8
  store i64 %v4418, ptr %slot433, align 8
  %v4419 = load i64, ptr %slot430, align 8
  %p4420 = inttoptr i64 %v4419 to ptr
  %ld4421 = load i64, ptr %p4420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4421, ptr %slot434, align 8
  %v4422 = load i64, ptr %slot434, align 8
  %cmp4423 = icmp ne i64 %v4422, 0
  %cv4424 = zext i1 %cmp4423 to i32
  store i32 %cv4424, ptr %slot435, align 8
  %v4425 = load i32, ptr %slot435, align 8
  %cv4426 = zext i32 %v4425 to i64
  %cond4427 = icmp ne i64 %cv4426, 0
  br i1 %cond4427, label %bb_rcgnn546, label %bb_rcgdone546
bb_rcgnn546:
  %v4428 = load i64, ptr %slot434, align 8
  %op4429 = sub i64 %v4428, 16
  store i64 %op4429, ptr %slot436, align 8
  %v4430 = load i64, ptr %slot434, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  %rgep4432 = getelementptr i8, ptr %p4431, i64 -16
  %ld4433 = load i64, ptr %rgep4432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4433, ptr %slot437, align 8
  %v4434 = load i64, ptr %slot437, align 8
  %op4435 = and i64 %v4434, 4611686018427387906
  store i64 %op4435, ptr %slot438, align 8
  %v4436 = load i64, ptr %slot438, align 8
  %cmp4437 = icmp ne i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot439, align 8
  %v4439 = load i32, ptr %slot439, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcgclear546, label %bb_rcgcounted546
bb_rcgcounted546:
  %v4442 = load i64, ptr %slot434, align 8
  %op4443 = sub i64 %v4442, 24
  store i64 %op4443, ptr %slot440, align 8
  %v4444 = load i64, ptr %slot434, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %rgep4446 = getelementptr i8, ptr %p4445, i64 -24
  %ld4447 = load i64, ptr %rgep4446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4447, ptr %slot441, align 8
  %v4448 = load i64, ptr %slot441, align 8
  %op4449 = sub i64 %v4448, 1
  store i64 %op4449, ptr %slot442, align 8
  %v4450 = load i64, ptr %slot442, align 8
  %cmp4451 = icmp eq i64 %v4450, 0
  %cv4452 = zext i1 %cmp4451 to i32
  store i32 %cv4452, ptr %slot443, align 8
  %v4453 = load i32, ptr %slot443, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcglast546, label %bb_rcgdec546
bb_rcglast546:
  %v4456 = load i64, ptr %slot434, align 8
  %op4457 = sub i64 %v4456, 32
  store i64 %op4457, ptr %slot444, align 8
  %v4458 = load i64, ptr %slot434, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %rgep4460 = getelementptr i8, ptr %p4459, i64 -32
  %ld4461 = load i64, ptr %rgep4460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4461, ptr %slot445, align 8
  %v4462 = load i64, ptr %slot445, align 8
  %cmp4463 = icmp ne i64 %v4462, 0
  %cv4464 = zext i1 %cmp4463 to i32
  store i32 %cv4464, ptr %slot446, align 8
  %v4465 = load i32, ptr %slot446, align 8
  %cv4466 = zext i32 %v4465 to i64
  %cond4467 = icmp ne i64 %cv4466, 0
  br i1 %cond4467, label %bb_rcgdec546, label %bb_rcgslow546
bb_rcgslow546:
  %v4468 = load i64, ptr %slot433, align 8
  %v4469 = load i64, ptr %slot430, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4468, i64 %v4469) nomerge, !dbg !150
  br label %bb_rcgdone546
bb_rcgdec546:
  %v4470 = load i64, ptr %slot442, align 8
  %v4471 = load i64, ptr %slot434, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %rgep4473 = getelementptr i8, ptr %p4472, i64 -24
  store i64 %v4470, ptr %rgep4473, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear546
bb_rcgclear546:
  %v4474 = load i64, ptr %slot430, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  store i64 0, ptr %p4475, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone546
bb_rcgdone546:
  br label %bb_rcslotdone530
bb_rcslotowner530:
  %v4476 = load i64, ptr %slot63, align 8
  store i64 %v4476, ptr %slot447, align 8
  %v4477 = load i64, ptr %slot430, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  %ld4479 = load i64, ptr %p4478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4479, ptr %slot448, align 8
  %v4480 = load i64, ptr %slot448, align 8
  %cmp4481 = icmp ne i64 %v4480, 0
  %cv4482 = zext i1 %cmp4481 to i32
  store i32 %cv4482, ptr %slot449, align 8
  %v4483 = load i32, ptr %slot449, align 8
  %cv4484 = zext i32 %v4483 to i64
  %cond4485 = icmp ne i64 %cv4484, 0
  br i1 %cond4485, label %bb_rcgnn561, label %bb_rcgdone561
bb_rcgnn561:
  %v4486 = load i64, ptr %slot448, align 8
  %op4487 = sub i64 %v4486, 16
  store i64 %op4487, ptr %slot450, align 8
  %v4488 = load i64, ptr %slot448, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  %rgep4490 = getelementptr i8, ptr %p4489, i64 -16
  %ld4491 = load i64, ptr %rgep4490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4491, ptr %slot451, align 8
  %v4492 = load i64, ptr %slot451, align 8
  %op4493 = and i64 %v4492, 4611686018427387906
  store i64 %op4493, ptr %slot452, align 8
  %v4494 = load i64, ptr %slot452, align 8
  %cmp4495 = icmp ne i64 %v4494, 0
  %cv4496 = zext i1 %cmp4495 to i32
  store i32 %cv4496, ptr %slot453, align 8
  %v4497 = load i32, ptr %slot453, align 8
  %cv4498 = zext i32 %v4497 to i64
  %cond4499 = icmp ne i64 %cv4498, 0
  br i1 %cond4499, label %bb_rcgclear561, label %bb_rcgcounted561
bb_rcgcounted561:
  %v4500 = load i64, ptr %slot448, align 8
  %op4501 = sub i64 %v4500, 32
  store i64 %op4501, ptr %slot454, align 8
  %v4502 = load i64, ptr %slot448, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  %rgep4504 = getelementptr i8, ptr %p4503, i64 -32
  %ld4505 = load i64, ptr %rgep4504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4505, ptr %slot455, align 8
  %v4506 = load i64, ptr %slot455, align 8
  %op4507 = sub i64 %v4506, 1
  store i64 %op4507, ptr %slot456, align 8
  %v4508 = load i64, ptr %slot456, align 8
  %cmp4509 = icmp eq i64 %v4508, 0
  %cv4510 = zext i1 %cmp4509 to i32
  store i32 %cv4510, ptr %slot457, align 8
  %v4511 = load i32, ptr %slot457, align 8
  %cv4512 = zext i32 %v4511 to i64
  %cond4513 = icmp ne i64 %cv4512, 0
  br i1 %cond4513, label %bb_rcglast561, label %bb_rcgdec561
bb_rcglast561:
  %v4514 = load i64, ptr %slot448, align 8
  %op4515 = sub i64 %v4514, 24
  store i64 %op4515, ptr %slot458, align 8
  %v4516 = load i64, ptr %slot448, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  %rgep4518 = getelementptr i8, ptr %p4517, i64 -24
  %ld4519 = load i64, ptr %rgep4518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4519, ptr %slot459, align 8
  %v4520 = load i64, ptr %slot459, align 8
  %cmp4521 = icmp ne i64 %v4520, 0
  %cv4522 = zext i1 %cmp4521 to i32
  store i32 %cv4522, ptr %slot460, align 8
  %v4523 = load i32, ptr %slot460, align 8
  %cv4524 = zext i32 %v4523 to i64
  %cond4525 = icmp ne i64 %cv4524, 0
  br i1 %cond4525, label %bb_rcgdec561, label %bb_rcgslow561
bb_rcgslow561:
  %v4526 = load i64, ptr %slot447, align 8
  %v4527 = load i64, ptr %slot430, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4526, i64 %v4527) nomerge, !dbg !150
  br label %bb_rcgdone561
bb_rcgdec561:
  %v4528 = load i64, ptr %slot456, align 8
  %v4529 = load i64, ptr %slot448, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  %rgep4531 = getelementptr i8, ptr %p4530, i64 -32
  store i64 %v4528, ptr %rgep4531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear561
bb_rcgclear561:
  %v4532 = load i64, ptr %slot430, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  store i64 0, ptr %p4533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone561
bb_rcgdone561:
  br label %bb_rcslotdone530
bb_rcslotdone530:
  %v4534 = load i64, ptr %slot9, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  %ld4536 = load i32, ptr %p4535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4536, ptr %slot461, align 8
  %v4537 = load i32, ptr %slot461, align 8
  %cv4538 = zext i32 %v4537 to i64
  %cond4539 = icmp ne i64 %cv4538, 0
  br i1 %cond4539, label %bb_rcslotdrop567, label %bb_rcslotdone567
bb_rcslotdrop567:
  %v4540 = load i64, ptr %slot9, align 8
  %p4541 = inttoptr i64 %v4540 to ptr
  store i32 0, ptr %p4541, align 4, !alias.scope !3, !noalias !4
  %v4542 = load i64, ptr %slot40, align 8
  store i64 %v4542, ptr %slot462, align 8
  %v4543 = load i64, ptr %slot10, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %ld4545 = load i32, ptr %p4544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4545, ptr %slot463, align 8
  %v4546 = load i32, ptr %slot463, align 8
  %op4547 = and i32 %v4546, 28
  store i32 %op4547, ptr %slot464, align 8
  %v4548 = load i32, ptr %slot464, align 8
  %cv4549 = zext i32 %v4548 to i64
  %cond4550 = icmp ne i64 %cv4549, 0
  br i1 %cond4550, label %bb_rcslotrole567, label %bb_rcslotowner567
bb_rcslotrole567:
  %v4551 = load i64, ptr %slot63, align 8
  store i64 %v4551, ptr %slot465, align 8
  %v4552 = load i64, ptr %slot462, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %ld4554 = load i64, ptr %p4553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4554, ptr %slot466, align 8
  %v4555 = load i64, ptr %slot466, align 8
  %cmp4556 = icmp ne i64 %v4555, 0
  %cv4557 = zext i1 %cmp4556 to i32
  store i32 %cv4557, ptr %slot467, align 8
  %v4558 = load i32, ptr %slot467, align 8
  %cv4559 = zext i32 %v4558 to i64
  %cond4560 = icmp ne i64 %cv4559, 0
  br i1 %cond4560, label %bb_rcgnn583, label %bb_rcgdone583
bb_rcgnn583:
  %v4561 = load i64, ptr %slot466, align 8
  %op4562 = sub i64 %v4561, 16
  store i64 %op4562, ptr %slot468, align 8
  %v4563 = load i64, ptr %slot466, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  %rgep4565 = getelementptr i8, ptr %p4564, i64 -16
  %ld4566 = load i64, ptr %rgep4565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4566, ptr %slot469, align 8
  %v4567 = load i64, ptr %slot469, align 8
  %op4568 = and i64 %v4567, 4611686018427387906
  store i64 %op4568, ptr %slot470, align 8
  %v4569 = load i64, ptr %slot470, align 8
  %cmp4570 = icmp ne i64 %v4569, 0
  %cv4571 = zext i1 %cmp4570 to i32
  store i32 %cv4571, ptr %slot471, align 8
  %v4572 = load i32, ptr %slot471, align 8
  %cv4573 = zext i32 %v4572 to i64
  %cond4574 = icmp ne i64 %cv4573, 0
  br i1 %cond4574, label %bb_rcgclear583, label %bb_rcgcounted583
bb_rcgcounted583:
  %v4575 = load i64, ptr %slot466, align 8
  %op4576 = sub i64 %v4575, 24
  store i64 %op4576, ptr %slot472, align 8
  %v4577 = load i64, ptr %slot466, align 8
  %p4578 = inttoptr i64 %v4577 to ptr
  %rgep4579 = getelementptr i8, ptr %p4578, i64 -24
  %ld4580 = load i64, ptr %rgep4579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4580, ptr %slot473, align 8
  %v4581 = load i64, ptr %slot473, align 8
  %op4582 = sub i64 %v4581, 1
  store i64 %op4582, ptr %slot474, align 8
  %v4583 = load i64, ptr %slot474, align 8
  %cmp4584 = icmp eq i64 %v4583, 0
  %cv4585 = zext i1 %cmp4584 to i32
  store i32 %cv4585, ptr %slot475, align 8
  %v4586 = load i32, ptr %slot475, align 8
  %cv4587 = zext i32 %v4586 to i64
  %cond4588 = icmp ne i64 %cv4587, 0
  br i1 %cond4588, label %bb_rcglast583, label %bb_rcgdec583
bb_rcglast583:
  %v4589 = load i64, ptr %slot466, align 8
  %op4590 = sub i64 %v4589, 32
  store i64 %op4590, ptr %slot476, align 8
  %v4591 = load i64, ptr %slot466, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  %rgep4593 = getelementptr i8, ptr %p4592, i64 -32
  %ld4594 = load i64, ptr %rgep4593, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4594, ptr %slot477, align 8
  %v4595 = load i64, ptr %slot477, align 8
  %cmp4596 = icmp ne i64 %v4595, 0
  %cv4597 = zext i1 %cmp4596 to i32
  store i32 %cv4597, ptr %slot478, align 8
  %v4598 = load i32, ptr %slot478, align 8
  %cv4599 = zext i32 %v4598 to i64
  %cond4600 = icmp ne i64 %cv4599, 0
  br i1 %cond4600, label %bb_rcgdec583, label %bb_rcgslow583
bb_rcgslow583:
  %v4601 = load i64, ptr %slot465, align 8
  %v4602 = load i64, ptr %slot462, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v4601, i64 %v4602) nomerge, !dbg !150
  br label %bb_rcgdone583
bb_rcgdec583:
  %v4603 = load i64, ptr %slot474, align 8
  %v4604 = load i64, ptr %slot466, align 8
  %p4605 = inttoptr i64 %v4604 to ptr
  %rgep4606 = getelementptr i8, ptr %p4605, i64 -24
  store i64 %v4603, ptr %rgep4606, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear583
bb_rcgclear583:
  %v4607 = load i64, ptr %slot462, align 8
  %p4608 = inttoptr i64 %v4607 to ptr
  store i64 0, ptr %p4608, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone583
bb_rcgdone583:
  br label %bb_rcslotdone567
bb_rcslotowner567:
  %v4609 = load i64, ptr %slot63, align 8
  store i64 %v4609, ptr %slot479, align 8
  %v4610 = load i64, ptr %slot462, align 8
  %p4611 = inttoptr i64 %v4610 to ptr
  %ld4612 = load i64, ptr %p4611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4612, ptr %slot480, align 8
  %v4613 = load i64, ptr %slot480, align 8
  %cmp4614 = icmp ne i64 %v4613, 0
  %cv4615 = zext i1 %cmp4614 to i32
  store i32 %cv4615, ptr %slot481, align 8
  %v4616 = load i32, ptr %slot481, align 8
  %cv4617 = zext i32 %v4616 to i64
  %cond4618 = icmp ne i64 %cv4617, 0
  br i1 %cond4618, label %bb_rcgnn598, label %bb_rcgdone598
bb_rcgnn598:
  %v4619 = load i64, ptr %slot480, align 8
  %op4620 = sub i64 %v4619, 16
  store i64 %op4620, ptr %slot482, align 8
  %v4621 = load i64, ptr %slot480, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %rgep4623 = getelementptr i8, ptr %p4622, i64 -16
  %ld4624 = load i64, ptr %rgep4623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4624, ptr %slot483, align 8
  %v4625 = load i64, ptr %slot483, align 8
  %op4626 = and i64 %v4625, 4611686018427387906
  store i64 %op4626, ptr %slot484, align 8
  %v4627 = load i64, ptr %slot484, align 8
  %cmp4628 = icmp ne i64 %v4627, 0
  %cv4629 = zext i1 %cmp4628 to i32
  store i32 %cv4629, ptr %slot485, align 8
  %v4630 = load i32, ptr %slot485, align 8
  %cv4631 = zext i32 %v4630 to i64
  %cond4632 = icmp ne i64 %cv4631, 0
  br i1 %cond4632, label %bb_rcgclear598, label %bb_rcgcounted598
bb_rcgcounted598:
  %v4633 = load i64, ptr %slot480, align 8
  %op4634 = sub i64 %v4633, 32
  store i64 %op4634, ptr %slot486, align 8
  %v4635 = load i64, ptr %slot480, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  %rgep4637 = getelementptr i8, ptr %p4636, i64 -32
  %ld4638 = load i64, ptr %rgep4637, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4638, ptr %slot487, align 8
  %v4639 = load i64, ptr %slot487, align 8
  %op4640 = sub i64 %v4639, 1
  store i64 %op4640, ptr %slot488, align 8
  %v4641 = load i64, ptr %slot488, align 8
  %cmp4642 = icmp eq i64 %v4641, 0
  %cv4643 = zext i1 %cmp4642 to i32
  store i32 %cv4643, ptr %slot489, align 8
  %v4644 = load i32, ptr %slot489, align 8
  %cv4645 = zext i32 %v4644 to i64
  %cond4646 = icmp ne i64 %cv4645, 0
  br i1 %cond4646, label %bb_rcglast598, label %bb_rcgdec598
bb_rcglast598:
  %v4647 = load i64, ptr %slot480, align 8
  %op4648 = sub i64 %v4647, 24
  store i64 %op4648, ptr %slot490, align 8
  %v4649 = load i64, ptr %slot480, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  %rgep4651 = getelementptr i8, ptr %p4650, i64 -24
  %ld4652 = load i64, ptr %rgep4651, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4652, ptr %slot491, align 8
  %v4653 = load i64, ptr %slot491, align 8
  %cmp4654 = icmp ne i64 %v4653, 0
  %cv4655 = zext i1 %cmp4654 to i32
  store i32 %cv4655, ptr %slot492, align 8
  %v4656 = load i32, ptr %slot492, align 8
  %cv4657 = zext i32 %v4656 to i64
  %cond4658 = icmp ne i64 %cv4657, 0
  br i1 %cond4658, label %bb_rcgdec598, label %bb_rcgslow598
bb_rcgslow598:
  %v4659 = load i64, ptr %slot479, align 8
  %v4660 = load i64, ptr %slot462, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4659, i64 %v4660) nomerge, !dbg !150
  br label %bb_rcgdone598
bb_rcgdec598:
  %v4661 = load i64, ptr %slot488, align 8
  %v4662 = load i64, ptr %slot480, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  %rgep4664 = getelementptr i8, ptr %p4663, i64 -32
  store i64 %v4661, ptr %rgep4664, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear598
bb_rcgclear598:
  %v4665 = load i64, ptr %slot462, align 8
  %p4666 = inttoptr i64 %v4665 to ptr
  store i64 0, ptr %p4666, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone598
bb_rcgdone598:
  br label %bb_rcslotdone567
bb_rcslotdone567:
  %v4667 = load i64, ptr %slot7, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %ld4669 = load i32, ptr %p4668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4669, ptr %slot493, align 8
  %v4670 = load i32, ptr %slot493, align 8
  %cv4671 = zext i32 %v4670 to i64
  %cond4672 = icmp ne i64 %cv4671, 0
  br i1 %cond4672, label %bb_rcslotdrop622, label %bb_rcslotdone622
bb_rcslotdrop622:
  %v4673 = load i64, ptr %slot7, align 8
  %p4674 = inttoptr i64 %v4673 to ptr
  store i32 0, ptr %p4674, align 4, !alias.scope !3, !noalias !4
  %v4675 = load i64, ptr %slot38, align 8
  store i64 %v4675, ptr %slot494, align 8
  %v4676 = load i64, ptr %slot8, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  %ld4678 = load i32, ptr %p4677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4678, ptr %slot495, align 8
  %v4679 = load i32, ptr %slot495, align 8
  %op4680 = and i32 %v4679, 28
  store i32 %op4680, ptr %slot496, align 8
  %v4681 = load i32, ptr %slot496, align 8
  %cv4682 = zext i32 %v4681 to i64
  %cond4683 = icmp ne i64 %cv4682, 0
  br i1 %cond4683, label %bb_rcslotrole622, label %bb_rcslotowner622
bb_rcslotrole622:
  %v4684 = load i64, ptr %slot63, align 8
  store i64 %v4684, ptr %slot497, align 8
  %v4685 = load i64, ptr %slot497, align 8
  %v4686 = load i64, ptr %slot494, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4685, i64 %v4686) nomerge, !dbg !150
  br label %bb_rcslotdone622
bb_rcslotowner622:
  %v4687 = load i64, ptr %slot63, align 8
  store i64 %v4687, ptr %slot498, align 8
  %v4688 = load i64, ptr %slot498, align 8
  %v4689 = load i64, ptr %slot494, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4688, i64 %v4689) nomerge, !dbg !150
  br label %bb_rcslotdone622
bb_rcslotdone622:
  %v4690 = load i64, ptr %slot384, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4691, i64 24, i1 false)
  ret void
bb_i57:
  %v4692 = load i64, ptr %slot44, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i64, ptr %p4693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4694, ptr %slot499, align 8
  %v4695 = load i64, ptr %slot499, align 8
  %v4696 = load i64, ptr %slot36, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  store i64 %v4695, ptr %p4697, align 8, !alias.scope !3, !noalias !4
  %v4698 = load i64, ptr %slot26, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  %ld4700 = load i64, ptr %p4699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4700, ptr %slot500, align 8
  %v4701 = load i64, ptr %slot500, align 8
  %v4702 = load i64, ptr %slot44, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  store i64 %v4701, ptr %p4703, align 8, !alias.scope !3, !noalias !4
  %v4704 = load i64, ptr %slot35, align 8
  %v4705 = load i64, ptr %slot45, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  store i64 %v4704, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  %v4707 = load i64, ptr %slot36, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  %ld4709 = load i64, ptr %p4708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4709, ptr %slot501, align 8
  %v4710 = load i64, ptr %slot501, align 8
  %v4711 = load i64, ptr %slot46, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  store i64 %v4710, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  %v4713 = load i64, ptr %slot44, align 8
  %p4714 = inttoptr i64 %v4713 to ptr
  %ld4715 = load i64, ptr %p4714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4715, ptr %slot502, align 8
  %v4716 = load i64, ptr %slot45, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  %ld4718 = load i64, ptr %p4717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4718, ptr %slot503, align 8
  %v4719 = load i64, ptr %slot46, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i64, ptr %p4720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4721, ptr %slot504, align 8
  %v4722 = load i64, ptr %slot1, align 8
  %v4723 = load i64, ptr %slot502, align 8
  %v4724 = load i64, ptr %slot503, align 8
  %v4725 = load i64, ptr %slot504, align 8
  call void @myl_f_e8c749c10445dc457f5775bb824164c0e2bada77ed66473babb0974281a32427(ptr sret([24 x i8]) align 8 %callresult506, i64 %v4722, i64 %v4723, i64 %v4724, i64 %v4725) nomerge, !dbg !152
  %addr4726 = ptrtoint ptr %callresult506 to i64
  store i64 %addr4726, ptr %slot505, align 8
  %v4727 = load i64, ptr %slot505, align 8
  %v4728 = load i64, ptr %slot44, align 8
  %p4729 = inttoptr i64 %v4728 to ptr
  store i64 %v4727, ptr %p4729, align 8, !alias.scope !3, !noalias !4
  %v4730 = load i64, ptr %slot44, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  %ld4732 = load i64, ptr %p4731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4732, ptr %slot507, align 8
  %v4733 = load i64, ptr %slot24, align 8
  store i64 %v4733, ptr %slot508, align 8
  %v4734 = load i64, ptr %slot507, align 8
  %v4735 = load i64, ptr %slot508, align 8
  %p4736 = inttoptr i64 %v4734 to ptr
  %p4737 = inttoptr i64 %v4735 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4737, ptr %p4736, i64 24, i1 false)
  %v4738 = load i64, ptr %slot20, align 8
  %p4739 = inttoptr i64 %v4738 to ptr
  store i32 2, ptr %p4739, align 4, !alias.scope !3, !noalias !4
  %v4740 = load i64, ptr %slot19, align 8
  %p4741 = inttoptr i64 %v4740 to ptr
  store i32 1, ptr %p4741, align 4, !alias.scope !3, !noalias !4
  %v4742 = load i64, ptr %slot17, align 8
  %p4743 = inttoptr i64 %v4742 to ptr
  %ld4744 = load i32, ptr %p4743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4744, ptr %slot509, align 8
  %v4745 = load i32, ptr %slot509, align 8
  %cv4746 = zext i32 %v4745 to i64
  %cond4747 = icmp ne i64 %cv4746, 0
  br i1 %cond4747, label %bb_rcslotdrop725, label %bb_rcslotdone725
bb_rcslotdrop725:
  %v4748 = load i64, ptr %slot17, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  store i32 0, ptr %p4749, align 4, !alias.scope !3, !noalias !4
  %v4750 = load i64, ptr %slot22, align 8
  store i64 %v4750, ptr %slot510, align 8
  %v4751 = load i64, ptr %slot18, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  %ld4753 = load i32, ptr %p4752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4753, ptr %slot511, align 8
  %v4754 = load i32, ptr %slot511, align 8
  %op4755 = and i32 %v4754, 28
  store i32 %op4755, ptr %slot512, align 8
  %v4756 = load i32, ptr %slot512, align 8
  %cv4757 = zext i32 %v4756 to i64
  %cond4758 = icmp ne i64 %cv4757, 0
  br i1 %cond4758, label %bb_rcslotrole725, label %bb_rcslotowner725
bb_rcslotrole725:
  %v4759 = load i64, ptr %slot63, align 8
  store i64 %v4759, ptr %slot513, align 8
  %v4760 = load i64, ptr %slot513, align 8
  %v4761 = load i64, ptr %slot510, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4760, i64 %v4761) nomerge, !dbg !152
  br label %bb_rcslotdone725
bb_rcslotowner725:
  %v4762 = load i64, ptr %slot63, align 8
  store i64 %v4762, ptr %slot514, align 8
  %v4763 = load i64, ptr %slot514, align 8
  %v4764 = load i64, ptr %slot510, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4763, i64 %v4764) nomerge, !dbg !152
  br label %bb_rcslotdone725
bb_rcslotdone725:
  %v4765 = load i64, ptr %slot22, align 8
  store i64 %v4765, ptr %slot515, align 8
  %v4766 = load i64, ptr %slot24, align 8
  store i64 %v4766, ptr %slot516, align 8
  %v4767 = load i64, ptr %slot516, align 8
  %v4768 = load i64, ptr %slot515, align 8
  %p4769 = inttoptr i64 %v4767 to ptr
  %p4770 = inttoptr i64 %v4768 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4770, ptr %p4769, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4771 = load i64, ptr %slot18, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  store i32 2, ptr %p4772, align 4, !alias.scope !3, !noalias !4
  %v4773 = load i64, ptr %slot20, align 8
  %p4774 = inttoptr i64 %v4773 to ptr
  %ld4775 = load i32, ptr %p4774, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4775, ptr %slot517, align 8
  %v4776 = load i32, ptr %slot517, align 8
  %v4777 = load i64, ptr %slot18, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  store i32 %v4776, ptr %p4778, align 4, !alias.scope !3, !noalias !4
  %v4779 = load i64, ptr %slot19, align 8
  %p4780 = inttoptr i64 %v4779 to ptr
  store i32 0, ptr %p4780, align 4, !alias.scope !3, !noalias !4
  %v4781 = load i64, ptr %slot17, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  store i32 1, ptr %p4782, align 4, !alias.scope !3, !noalias !4
  %v4783 = load i64, ptr %slot515, align 8
  %v4784 = load i64, ptr %slot44, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i64 %v4783, ptr %p4785, align 8, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot44, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  %ld4788 = load i64, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4788, ptr %slot518, align 8
  %v4789 = load i64, ptr %slot518, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  %ld4791 = load i32, ptr %p4790, align 4
  %ext4792 = zext i32 %ld4791 to i64
  store i64 %ext4792, ptr %slot519, align 8
  %v4793 = load i64, ptr %slot519, align 8
  %cmp4794 = icmp eq i64 %v4793, 0
  %cv4795 = zext i1 %cmp4794 to i64
  store i64 %cv4795, ptr %slot520, align 8
  %v4796 = load i64, ptr %slot520, align 8
  %cond4797 = icmp ne i64 %v4796, 0
  br i1 %cond4797, label %bb_rctryok741, label %bb_rctryerror741
bb_rctryerror741:
  %p4798 = inttoptr i64 ptrtoint (ptr @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4798, i64 12884901950) "call-inline-cost"="0", !dbg !154
  %v4799 = load i64, ptr %slot518, align 8
  %op4800 = add i64 %v4799, 8
  store i64 %op4800, ptr %slot521, align 8
  %v4801 = load i64, ptr %slot51, align 8
  store i64 %v4801, ptr %slot522, align 8
  %v4802 = load i64, ptr %slot522, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  store i64 0, ptr %p4803, align 8, !alias.scope !3, !noalias !4
  %v4804 = load i64, ptr %slot522, align 8
  %p4806 = inttoptr i64 %v4804 to ptr
  %gep4807 = getelementptr i8, ptr %p4806, i64 8
  %op4805 = ptrtoint ptr %gep4807 to i64
  store i64 %op4805, ptr %slot523, align 8
  %v4808 = load i64, ptr %slot523, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  store i64 0, ptr %p4809, align 8, !alias.scope !3, !noalias !4
  %v4810 = load i64, ptr %slot522, align 8
  %p4812 = inttoptr i64 %v4810 to ptr
  %gep4813 = getelementptr i8, ptr %p4812, i64 16
  %op4811 = ptrtoint ptr %gep4813 to i64
  store i64 %op4811, ptr %slot524, align 8
  %v4814 = load i64, ptr %slot524, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  store i64 0, ptr %p4815, align 8, !alias.scope !3, !noalias !4
  %v4816 = load i64, ptr %slot522, align 8
  %p4817 = inttoptr i64 %v4816 to ptr
  store i32 1, ptr %p4817, align 4, !alias.scope !3, !noalias !4
  %v4818 = load i64, ptr %slot522, align 8
  %p4820 = inttoptr i64 %v4818 to ptr
  %gep4821 = getelementptr i8, ptr %p4820, i64 8
  %op4819 = ptrtoint ptr %gep4821 to i64
  store i64 %op4819, ptr %slot525, align 8
  %v4822 = load i64, ptr %slot21, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  store i32 1, ptr %p4823, align 4, !alias.scope !3, !noalias !4
  %v4824 = load i64, ptr %slot64, align 8
  store i64 %v4824, ptr %slot526, align 8
  %v4825 = load i64, ptr %slot63, align 8
  %v4826 = load i64, ptr %slot525, align 8
  %v4827 = load i64, ptr %slot521, align 8
  %v4828 = load i64, ptr %slot526, align 8
  %cv4829 = trunc i64 %v4828 to i32
  %call4830 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v4825, i64 %v4826, i64 %v4827, i32 %cv4829) nomerge, !dbg !154
  store i32 %call4830, ptr %slot527, align 8
  %v4831 = load i32, ptr %slot527, align 8
  %cv4832 = zext i32 %v4831 to i64
  %cond4833 = icmp ne i64 %cv4832, 0
  br i1 %cond4833, label %bb_rcsuccess752, label %bb_rcfailure752
bb_rcfailure752:
  %v4834 = load i64, ptr %slot63, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  %call4836 = call i32 @myl_rc_take_failure(ptr %p4835) nomerge, !dbg !154
  store i32 %call4836, ptr %slot528, align 8
  %v4837 = load i64, ptr %slot1, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %v4839 = load i32, ptr %slot528, align 8
  %call4840 = call i32 @myl_qbe_rc_status(ptr %p4838, i32 %v4839) nomerge, !dbg !154
  store i32 %call4840, ptr %slot529, align 8
  br label %bb_failure
bb_rcsuccess752:
  %v4841 = load i64, ptr %slot522, align 8
  %v4842 = load i64, ptr %slot44, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  store i64 %v4841, ptr %p4843, align 8, !alias.scope !3, !noalias !4
  %v4844 = load i64, ptr %slot44, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  %ld4846 = load i64, ptr %p4845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4846, ptr %slot530, align 8
  %v4847 = load i64, ptr %slot24, align 8
  store i64 %v4847, ptr %slot531, align 8
  %v4848 = load i64, ptr %slot530, align 8
  %v4849 = load i64, ptr %slot531, align 8
  %p4850 = inttoptr i64 %v4848 to ptr
  %p4851 = inttoptr i64 %v4849 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4851, ptr %p4850, i64 24, i1 false)
  %v4852 = load i64, ptr %slot20, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  store i32 2, ptr %p4853, align 4, !alias.scope !3, !noalias !4
  %v4854 = load i64, ptr %slot19, align 8
  %p4855 = inttoptr i64 %v4854 to ptr
  store i32 1, ptr %p4855, align 4, !alias.scope !3, !noalias !4
  %v4856 = load i64, ptr %slot17, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  %ld4858 = load i32, ptr %p4857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4858, ptr %slot532, align 8
  %v4859 = load i32, ptr %slot532, align 8
  %cv4860 = zext i32 %v4859 to i64
  %cond4861 = icmp ne i64 %cv4860, 0
  br i1 %cond4861, label %bb_rcslotdrop761, label %bb_rcslotdone761
bb_rcslotdrop761:
  %v4862 = load i64, ptr %slot17, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  store i32 0, ptr %p4863, align 4, !alias.scope !3, !noalias !4
  %v4864 = load i64, ptr %slot22, align 8
  store i64 %v4864, ptr %slot533, align 8
  %v4865 = load i64, ptr %slot18, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %ld4867 = load i32, ptr %p4866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4867, ptr %slot534, align 8
  %v4868 = load i32, ptr %slot534, align 8
  %op4869 = and i32 %v4868, 28
  store i32 %op4869, ptr %slot535, align 8
  %v4870 = load i32, ptr %slot535, align 8
  %cv4871 = zext i32 %v4870 to i64
  %cond4872 = icmp ne i64 %cv4871, 0
  br i1 %cond4872, label %bb_rcslotrole761, label %bb_rcslotowner761
bb_rcslotrole761:
  %v4873 = load i64, ptr %slot63, align 8
  store i64 %v4873, ptr %slot536, align 8
  %v4874 = load i64, ptr %slot536, align 8
  %v4875 = load i64, ptr %slot533, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64 %v4874, i64 %v4875) nomerge, !dbg !154
  br label %bb_rcslotdone761
bb_rcslotowner761:
  %v4876 = load i64, ptr %slot63, align 8
  store i64 %v4876, ptr %slot537, align 8
  %v4877 = load i64, ptr %slot537, align 8
  %v4878 = load i64, ptr %slot533, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64 %v4877, i64 %v4878) nomerge, !dbg !154
  br label %bb_rcslotdone761
bb_rcslotdone761:
  %v4879 = load i64, ptr %slot22, align 8
  store i64 %v4879, ptr %slot538, align 8
  %v4880 = load i64, ptr %slot24, align 8
  store i64 %v4880, ptr %slot539, align 8
  %v4881 = load i64, ptr %slot539, align 8
  %v4882 = load i64, ptr %slot538, align 8
  %p4883 = inttoptr i64 %v4881 to ptr
  %p4884 = inttoptr i64 %v4882 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4884, ptr %p4883, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4885 = load i64, ptr %slot18, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  store i32 2, ptr %p4886, align 4, !alias.scope !3, !noalias !4
  %v4887 = load i64, ptr %slot20, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %ld4889 = load i32, ptr %p4888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4889, ptr %slot540, align 8
  %v4890 = load i32, ptr %slot540, align 8
  %v4891 = load i64, ptr %slot18, align 8
  %p4892 = inttoptr i64 %v4891 to ptr
  store i32 %v4890, ptr %p4892, align 4, !alias.scope !3, !noalias !4
  %v4893 = load i64, ptr %slot19, align 8
  %p4894 = inttoptr i64 %v4893 to ptr
  store i32 0, ptr %p4894, align 4, !alias.scope !3, !noalias !4
  %v4895 = load i64, ptr %slot17, align 8
  %p4896 = inttoptr i64 %v4895 to ptr
  store i32 1, ptr %p4896, align 4, !alias.scope !3, !noalias !4
  %v4897 = load i64, ptr %slot538, align 8
  %v4898 = load i64, ptr %slot44, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  store i64 %v4897, ptr %p4899, align 8, !alias.scope !3, !noalias !4
  br label %bb_i64
bb_rctryok741:
  %v4900 = load i64, ptr %slot51, align 8
  store i64 %v4900, ptr %slot541, align 8
  %v4901 = load i64, ptr %slot541, align 8
  %p4902 = inttoptr i64 %v4901 to ptr
  store i64 0, ptr %p4902, align 8, !alias.scope !3, !noalias !4
  %v4903 = load i64, ptr %slot541, align 8
  %p4905 = inttoptr i64 %v4903 to ptr
  %gep4906 = getelementptr i8, ptr %p4905, i64 8
  %op4904 = ptrtoint ptr %gep4906 to i64
  store i64 %op4904, ptr %slot542, align 8
  %v4907 = load i64, ptr %slot542, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  store i64 0, ptr %p4908, align 8, !alias.scope !3, !noalias !4
  %v4909 = load i64, ptr %slot21, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  store i32 1, ptr %p4910, align 4, !alias.scope !3, !noalias !4
  %v4911 = load i64, ptr %slot518, align 8
  %op4912 = add i64 %v4911, 8
  store i64 %op4912, ptr %slot543, align 8
  %v4913 = load i64, ptr %slot64, align 8
  store i64 %v4913, ptr %slot544, align 8
  %v4914 = load i64, ptr %slot543, align 8
  %v4915 = load i64, ptr %slot541, align 8
  %p4916 = inttoptr i64 %v4914 to ptr
  %p4917 = inttoptr i64 %v4915 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4917, ptr %p4916, i64 16, i1 false)
  %v4918 = load i64, ptr %slot541, align 8
  %v4919 = load i64, ptr %slot44, align 8
  %p4920 = inttoptr i64 %v4919 to ptr
  store i64 %v4918, ptr %p4920, align 8, !alias.scope !3, !noalias !4
  %v4921 = load i64, ptr %slot17, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %ld4923 = load i32, ptr %p4922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4923, ptr %slot545, align 8
  %v4924 = load i32, ptr %slot545, align 8
  %cv4925 = zext i32 %v4924 to i64
  %cond4926 = icmp ne i64 %cv4925, 0
  br i1 %cond4926, label %bb_rcslotdrop784, label %bb_rcslotdone784
bb_rcslotdrop784:
  %v4927 = load i64, ptr %slot17, align 8
  %p4928 = inttoptr i64 %v4927 to ptr
  store i32 0, ptr %p4928, align 4, !alias.scope !3, !noalias !4
  %v4929 = load i64, ptr %slot22, align 8
  store i64 %v4929, ptr %slot546, align 8
  %v4930 = load i64, ptr %slot18, align 8
  %p4931 = inttoptr i64 %v4930 to ptr
  %ld4932 = load i32, ptr %p4931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4932, ptr %slot547, align 8
  %v4933 = load i32, ptr %slot547, align 8
  %op4934 = and i32 %v4933, 28
  store i32 %op4934, ptr %slot548, align 8
  %v4935 = load i32, ptr %slot548, align 8
  %cv4936 = zext i32 %v4935 to i64
  %cond4937 = icmp ne i64 %cv4936, 0
  br i1 %cond4937, label %bb_rcslotrole784, label %bb_rcslotowner784
bb_rcslotrole784:
  %v4938 = load i64, ptr %slot63, align 8
  store i64 %v4938, ptr %slot549, align 8
  %v4939 = load i64, ptr %slot549, align 8
  %v4940 = load i64, ptr %slot546, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64 %v4939, i64 %v4940) nomerge, !dbg !154
  br label %bb_rcslotdone784
bb_rcslotowner784:
  %v4941 = load i64, ptr %slot63, align 8
  store i64 %v4941, ptr %slot550, align 8
  %v4942 = load i64, ptr %slot550, align 8
  %v4943 = load i64, ptr %slot546, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64 %v4942, i64 %v4943) nomerge, !dbg !154
  br label %bb_rcslotdone784
bb_rcslotdone784:
  br label %bb_i65
bb_i64:
  %v4944 = load i64, ptr %slot44, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  %ld4946 = load i64, ptr %p4945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4946, ptr %slot551, align 8
  %v4947 = load i64, ptr %slot44, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  %ld4949 = load i64, ptr %p4948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4949, ptr %slot552, align 8
  %v4950 = load i64, ptr %slot17, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  %ld4952 = load i32, ptr %p4951, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4952, ptr %slot553, align 8
  %v4953 = load i64, ptr %slot18, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  %ld4955 = load i32, ptr %p4954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4955, ptr %slot554, align 8
  %v4956 = load i32, ptr %slot554, align 8
  %op4957 = and i32 %v4956, 24
  store i32 %op4957, ptr %slot554, align 8
  %v4958 = load i32, ptr %slot554, align 8
  %cmp4959 = icmp eq i32 %v4958, 0
  %cv4960 = zext i1 %cmp4959 to i32
  store i32 %cv4960, ptr %slot555, align 8
  %v4961 = load i32, ptr %slot553, align 8
  %v4962 = load i32, ptr %slot555, align 8
  %op4963 = and i32 %v4961, %v4962
  store i32 %op4963, ptr %slot556, align 8
  %v4964 = load i32, ptr %slot556, align 8
  %cv4965 = zext i32 %v4964 to i64
  %cond4966 = icmp ne i64 %cv4965, 0
  br i1 %cond4966, label %bb_rctake793, label %bb_rccopy793
bb_rctake793:
  %v4967 = load i64, ptr %slot24, align 8
  store i64 %v4967, ptr %slot557, align 8
  %v4968 = load i64, ptr %slot64, align 8
  store i64 %v4968, ptr %slot558, align 8
  %v4969 = load i64, ptr %slot63, align 8
  %v4970 = load i64, ptr %slot557, align 8
  %v4971 = load i64, ptr %slot552, align 8
  %v4972 = load i64, ptr %slot558, align 8
  %cv4973 = trunc i64 %v4972 to i32
  %call4974 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4969, i64 %v4970, i64 %v4971, i32 %cv4973) nomerge, !dbg !156
  store i32 %call4974, ptr %slot559, align 8
  %v4975 = load i32, ptr %slot559, align 8
  %cv4976 = zext i32 %v4975 to i64
  %cond4977 = icmp ne i64 %cv4976, 0
  br i1 %cond4977, label %bb_rcsuccess803, label %bb_rcfailure803
bb_rcfailure803:
  %v4978 = load i64, ptr %slot63, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %call4980 = call i32 @myl_rc_take_failure(ptr %p4979) nomerge, !dbg !156
  store i32 %call4980, ptr %slot560, align 8
  %v4981 = load i64, ptr %slot1, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  %v4983 = load i32, ptr %slot560, align 8
  %call4984 = call i32 @myl_qbe_rc_status(ptr %p4982, i32 %v4983) nomerge, !dbg !156
  store i32 %call4984, ptr %slot561, align 8
  br label %bb_failure
bb_rcsuccess803:
  %v4985 = load i64, ptr %slot17, align 8
  %p4986 = inttoptr i64 %v4985 to ptr
  store i32 0, ptr %p4986, align 4, !alias.scope !3, !noalias !4
  %v4987 = load i64, ptr %slot20, align 8
  %p4988 = inttoptr i64 %v4987 to ptr
  store i32 2, ptr %p4988, align 4, !alias.scope !3, !noalias !4
  %v4989 = load i64, ptr %slot19, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  store i32 1, ptr %p4990, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared793
bb_rccopy793:
  %v4991 = load i64, ptr %slot24, align 8
  store i64 %v4991, ptr %slot562, align 8
  %v4992 = load i64, ptr %slot64, align 8
  store i64 %v4992, ptr %slot563, align 8
  %v4993 = load i64, ptr %slot63, align 8
  %v4994 = load i64, ptr %slot562, align 8
  %v4995 = load i64, ptr %slot552, align 8
  %v4996 = load i64, ptr %slot563, align 8
  %cv4997 = trunc i64 %v4996 to i32
  %call4998 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v4993, i64 %v4994, i64 %v4995, i32 %cv4997) nomerge, !dbg !156
  store i32 %call4998, ptr %slot564, align 8
  %v4999 = load i32, ptr %slot564, align 8
  %cv5000 = zext i32 %v4999 to i64
  %cond5001 = icmp ne i64 %cv5000, 0
  br i1 %cond5001, label %bb_rcsuccess812, label %bb_rcfailure812
bb_rcfailure812:
  %v5002 = load i64, ptr %slot63, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  %call5004 = call i32 @myl_rc_take_failure(ptr %p5003) nomerge, !dbg !156
  store i32 %call5004, ptr %slot565, align 8
  %v5005 = load i64, ptr %slot1, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  %v5007 = load i32, ptr %slot565, align 8
  %call5008 = call i32 @myl_qbe_rc_status(ptr %p5006, i32 %v5007) nomerge, !dbg !156
  store i32 %call5008, ptr %slot566, align 8
  br label %bb_failure
bb_rcsuccess812:
  %v5009 = load i64, ptr %slot20, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  store i32 2, ptr %p5010, align 4, !alias.scope !3, !noalias !4
  %v5011 = load i64, ptr %slot19, align 8
  %p5012 = inttoptr i64 %v5011 to ptr
  store i32 1, ptr %p5012, align 4, !alias.scope !3, !noalias !4
  %v5013 = load i64, ptr %slot17, align 8
  %p5014 = inttoptr i64 %v5013 to ptr
  %ld5015 = load i32, ptr %p5014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5015, ptr %slot567, align 8
  %v5016 = load i32, ptr %slot567, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcslotdrop819, label %bb_rcslotdone819
bb_rcslotdrop819:
  %v5019 = load i64, ptr %slot17, align 8
  %p5020 = inttoptr i64 %v5019 to ptr
  store i32 0, ptr %p5020, align 4, !alias.scope !3, !noalias !4
  %v5021 = load i64, ptr %slot22, align 8
  store i64 %v5021, ptr %slot568, align 8
  %v5022 = load i64, ptr %slot18, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i32, ptr %p5023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5024, ptr %slot569, align 8
  %v5025 = load i32, ptr %slot569, align 8
  %op5026 = and i32 %v5025, 28
  store i32 %op5026, ptr %slot570, align 8
  %v5027 = load i32, ptr %slot570, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcslotrole819, label %bb_rcslotowner819
bb_rcslotrole819:
  %v5030 = load i64, ptr %slot63, align 8
  store i64 %v5030, ptr %slot571, align 8
  %v5031 = load i64, ptr %slot571, align 8
  %v5032 = load i64, ptr %slot568, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5031, i64 %v5032) nomerge, !dbg !156
  br label %bb_rcslotdone819
bb_rcslotowner819:
  %v5033 = load i64, ptr %slot63, align 8
  store i64 %v5033, ptr %slot572, align 8
  %v5034 = load i64, ptr %slot572, align 8
  %v5035 = load i64, ptr %slot568, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5034, i64 %v5035) nomerge, !dbg !156
  br label %bb_rcslotdone819
bb_rcslotdone819:
  br label %bb_rcprepared793
bb_rcprepared793:
  %v5036 = load i64, ptr %slot24, align 8
  store i64 %v5036, ptr %slot573, align 8
  %v5037 = load i64, ptr %slot19, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  store i32 0, ptr %p5038, align 4, !alias.scope !3, !noalias !4
  %v5039 = load i64, ptr %slot17, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  %ld5041 = load i32, ptr %p5040, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5041, ptr %slot574, align 8
  %v5042 = load i32, ptr %slot574, align 8
  %cv5043 = zext i32 %v5042 to i64
  %cond5044 = icmp ne i64 %cv5043, 0
  br i1 %cond5044, label %bb_rcslotdrop830, label %bb_rcslotdone830
bb_rcslotdrop830:
  %v5045 = load i64, ptr %slot17, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  store i32 0, ptr %p5046, align 4, !alias.scope !3, !noalias !4
  %v5047 = load i64, ptr %slot22, align 8
  store i64 %v5047, ptr %slot575, align 8
  %v5048 = load i64, ptr %slot18, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %ld5050 = load i32, ptr %p5049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5050, ptr %slot576, align 8
  %v5051 = load i32, ptr %slot576, align 8
  %op5052 = and i32 %v5051, 28
  store i32 %op5052, ptr %slot577, align 8
  %v5053 = load i32, ptr %slot577, align 8
  %cv5054 = zext i32 %v5053 to i64
  %cond5055 = icmp ne i64 %cv5054, 0
  br i1 %cond5055, label %bb_rcslotrole830, label %bb_rcslotowner830
bb_rcslotrole830:
  %v5056 = load i64, ptr %slot63, align 8
  store i64 %v5056, ptr %slot578, align 8
  %v5057 = load i64, ptr %slot578, align 8
  %v5058 = load i64, ptr %slot575, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5057, i64 %v5058) nomerge, !dbg !156
  br label %bb_rcslotdone830
bb_rcslotowner830:
  %v5059 = load i64, ptr %slot63, align 8
  store i64 %v5059, ptr %slot579, align 8
  %v5060 = load i64, ptr %slot579, align 8
  %v5061 = load i64, ptr %slot575, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5060, i64 %v5061) nomerge, !dbg !156
  br label %bb_rcslotdone830
bb_rcslotdone830:
  %v5062 = load i64, ptr %slot15, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  %ld5064 = load i32, ptr %p5063, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5064, ptr %slot580, align 8
  %v5065 = load i32, ptr %slot580, align 8
  %cv5066 = zext i32 %v5065 to i64
  %cond5067 = icmp ne i64 %cv5066, 0
  br i1 %cond5067, label %bb_rcslotdrop857, label %bb_rcslotdone857
bb_rcslotdrop857:
  %v5068 = load i64, ptr %slot15, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  store i32 0, ptr %p5069, align 4, !alias.scope !3, !noalias !4
  %v5070 = load i64, ptr %slot43, align 8
  store i64 %v5070, ptr %slot581, align 8
  %v5071 = load i64, ptr %slot16, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  %ld5073 = load i32, ptr %p5072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5073, ptr %slot582, align 8
  %v5074 = load i32, ptr %slot582, align 8
  %op5075 = and i32 %v5074, 28
  store i32 %op5075, ptr %slot583, align 8
  %v5076 = load i32, ptr %slot583, align 8
  %cv5077 = zext i32 %v5076 to i64
  %cond5078 = icmp ne i64 %cv5077, 0
  br i1 %cond5078, label %bb_rcslotrole857, label %bb_rcslotowner857
bb_rcslotrole857:
  %v5079 = load i64, ptr %slot63, align 8
  store i64 %v5079, ptr %slot584, align 8
  %v5080 = load i64, ptr %slot584, align 8
  %v5081 = load i64, ptr %slot581, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5080, i64 %v5081) nomerge, !dbg !156
  br label %bb_rcslotdone857
bb_rcslotowner857:
  %v5082 = load i64, ptr %slot63, align 8
  store i64 %v5082, ptr %slot585, align 8
  %v5083 = load i64, ptr %slot585, align 8
  %v5084 = load i64, ptr %slot581, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5083, i64 %v5084) nomerge, !dbg !156
  br label %bb_rcslotdone857
bb_rcslotdone857:
  %v5085 = load i64, ptr %slot13, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %ld5087 = load i32, ptr %p5086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5087, ptr %slot586, align 8
  %v5088 = load i32, ptr %slot586, align 8
  %cv5089 = zext i32 %v5088 to i64
  %cond5090 = icmp ne i64 %cv5089, 0
  br i1 %cond5090, label %bb_rcslotdrop866, label %bb_rcslotdone866
bb_rcslotdrop866:
  %v5091 = load i64, ptr %slot13, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i32 0, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  %v5093 = load i64, ptr %slot42, align 8
  store i64 %v5093, ptr %slot587, align 8
  %v5094 = load i64, ptr %slot14, align 8
  %p5095 = inttoptr i64 %v5094 to ptr
  %ld5096 = load i32, ptr %p5095, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5096, ptr %slot588, align 8
  %v5097 = load i32, ptr %slot588, align 8
  %op5098 = and i32 %v5097, 28
  store i32 %op5098, ptr %slot589, align 8
  %v5099 = load i32, ptr %slot589, align 8
  %cv5100 = zext i32 %v5099 to i64
  %cond5101 = icmp ne i64 %cv5100, 0
  br i1 %cond5101, label %bb_rcslotrole866, label %bb_rcslotowner866
bb_rcslotrole866:
  %v5102 = load i64, ptr %slot63, align 8
  store i64 %v5102, ptr %slot590, align 8
  %v5103 = load i64, ptr %slot587, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %ld5105 = load i64, ptr %p5104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5105, ptr %slot591, align 8
  %v5106 = load i64, ptr %slot591, align 8
  %cmp5107 = icmp ne i64 %v5106, 0
  %cv5108 = zext i1 %cmp5107 to i32
  store i32 %cv5108, ptr %slot592, align 8
  %v5109 = load i32, ptr %slot592, align 8
  %cv5110 = zext i32 %v5109 to i64
  %cond5111 = icmp ne i64 %cv5110, 0
  br i1 %cond5111, label %bb_rcgnn882, label %bb_rcgdone882
bb_rcgnn882:
  %v5112 = load i64, ptr %slot591, align 8
  %op5113 = sub i64 %v5112, 16
  store i64 %op5113, ptr %slot593, align 8
  %v5114 = load i64, ptr %slot591, align 8
  %p5115 = inttoptr i64 %v5114 to ptr
  %rgep5116 = getelementptr i8, ptr %p5115, i64 -16
  %ld5117 = load i64, ptr %rgep5116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5117, ptr %slot594, align 8
  %v5118 = load i64, ptr %slot594, align 8
  %op5119 = and i64 %v5118, 4611686018427387906
  store i64 %op5119, ptr %slot595, align 8
  %v5120 = load i64, ptr %slot595, align 8
  %cmp5121 = icmp ne i64 %v5120, 0
  %cv5122 = zext i1 %cmp5121 to i32
  store i32 %cv5122, ptr %slot596, align 8
  %v5123 = load i32, ptr %slot596, align 8
  %cv5124 = zext i32 %v5123 to i64
  %cond5125 = icmp ne i64 %cv5124, 0
  br i1 %cond5125, label %bb_rcgclear882, label %bb_rcgcounted882
bb_rcgcounted882:
  %v5126 = load i64, ptr %slot591, align 8
  %op5127 = sub i64 %v5126, 24
  store i64 %op5127, ptr %slot597, align 8
  %v5128 = load i64, ptr %slot591, align 8
  %p5129 = inttoptr i64 %v5128 to ptr
  %rgep5130 = getelementptr i8, ptr %p5129, i64 -24
  %ld5131 = load i64, ptr %rgep5130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5131, ptr %slot598, align 8
  %v5132 = load i64, ptr %slot598, align 8
  %op5133 = sub i64 %v5132, 1
  store i64 %op5133, ptr %slot599, align 8
  %v5134 = load i64, ptr %slot599, align 8
  %cmp5135 = icmp eq i64 %v5134, 0
  %cv5136 = zext i1 %cmp5135 to i32
  store i32 %cv5136, ptr %slot600, align 8
  %v5137 = load i32, ptr %slot600, align 8
  %cv5138 = zext i32 %v5137 to i64
  %cond5139 = icmp ne i64 %cv5138, 0
  br i1 %cond5139, label %bb_rcglast882, label %bb_rcgdec882
bb_rcglast882:
  %v5140 = load i64, ptr %slot591, align 8
  %op5141 = sub i64 %v5140, 32
  store i64 %op5141, ptr %slot601, align 8
  %v5142 = load i64, ptr %slot591, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  %rgep5144 = getelementptr i8, ptr %p5143, i64 -32
  %ld5145 = load i64, ptr %rgep5144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5145, ptr %slot602, align 8
  %v5146 = load i64, ptr %slot602, align 8
  %cmp5147 = icmp ne i64 %v5146, 0
  %cv5148 = zext i1 %cmp5147 to i32
  store i32 %cv5148, ptr %slot603, align 8
  %v5149 = load i32, ptr %slot603, align 8
  %cv5150 = zext i32 %v5149 to i64
  %cond5151 = icmp ne i64 %cv5150, 0
  br i1 %cond5151, label %bb_rcgdec882, label %bb_rcgslow882
bb_rcgslow882:
  %v5152 = load i64, ptr %slot590, align 8
  %v5153 = load i64, ptr %slot587, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5152, i64 %v5153) nomerge, !dbg !156
  br label %bb_rcgdone882
bb_rcgdec882:
  %v5154 = load i64, ptr %slot599, align 8
  %v5155 = load i64, ptr %slot591, align 8
  %p5156 = inttoptr i64 %v5155 to ptr
  %rgep5157 = getelementptr i8, ptr %p5156, i64 -24
  store i64 %v5154, ptr %rgep5157, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear882
bb_rcgclear882:
  %v5158 = load i64, ptr %slot587, align 8
  %p5159 = inttoptr i64 %v5158 to ptr
  store i64 0, ptr %p5159, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone882
bb_rcgdone882:
  br label %bb_rcslotdone866
bb_rcslotowner866:
  %v5160 = load i64, ptr %slot63, align 8
  store i64 %v5160, ptr %slot604, align 8
  %v5161 = load i64, ptr %slot587, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  %ld5163 = load i64, ptr %p5162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5163, ptr %slot605, align 8
  %v5164 = load i64, ptr %slot605, align 8
  %cmp5165 = icmp ne i64 %v5164, 0
  %cv5166 = zext i1 %cmp5165 to i32
  store i32 %cv5166, ptr %slot606, align 8
  %v5167 = load i32, ptr %slot606, align 8
  %cv5168 = zext i32 %v5167 to i64
  %cond5169 = icmp ne i64 %cv5168, 0
  br i1 %cond5169, label %bb_rcgnn897, label %bb_rcgdone897
bb_rcgnn897:
  %v5170 = load i64, ptr %slot605, align 8
  %op5171 = sub i64 %v5170, 16
  store i64 %op5171, ptr %slot607, align 8
  %v5172 = load i64, ptr %slot605, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  %rgep5174 = getelementptr i8, ptr %p5173, i64 -16
  %ld5175 = load i64, ptr %rgep5174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5175, ptr %slot608, align 8
  %v5176 = load i64, ptr %slot608, align 8
  %op5177 = and i64 %v5176, 4611686018427387906
  store i64 %op5177, ptr %slot609, align 8
  %v5178 = load i64, ptr %slot609, align 8
  %cmp5179 = icmp ne i64 %v5178, 0
  %cv5180 = zext i1 %cmp5179 to i32
  store i32 %cv5180, ptr %slot610, align 8
  %v5181 = load i32, ptr %slot610, align 8
  %cv5182 = zext i32 %v5181 to i64
  %cond5183 = icmp ne i64 %cv5182, 0
  br i1 %cond5183, label %bb_rcgclear897, label %bb_rcgcounted897
bb_rcgcounted897:
  %v5184 = load i64, ptr %slot605, align 8
  %op5185 = sub i64 %v5184, 32
  store i64 %op5185, ptr %slot611, align 8
  %v5186 = load i64, ptr %slot605, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %rgep5188 = getelementptr i8, ptr %p5187, i64 -32
  %ld5189 = load i64, ptr %rgep5188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5189, ptr %slot612, align 8
  %v5190 = load i64, ptr %slot612, align 8
  %op5191 = sub i64 %v5190, 1
  store i64 %op5191, ptr %slot613, align 8
  %v5192 = load i64, ptr %slot613, align 8
  %cmp5193 = icmp eq i64 %v5192, 0
  %cv5194 = zext i1 %cmp5193 to i32
  store i32 %cv5194, ptr %slot614, align 8
  %v5195 = load i32, ptr %slot614, align 8
  %cv5196 = zext i32 %v5195 to i64
  %cond5197 = icmp ne i64 %cv5196, 0
  br i1 %cond5197, label %bb_rcglast897, label %bb_rcgdec897
bb_rcglast897:
  %v5198 = load i64, ptr %slot605, align 8
  %op5199 = sub i64 %v5198, 24
  store i64 %op5199, ptr %slot615, align 8
  %v5200 = load i64, ptr %slot605, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  %rgep5202 = getelementptr i8, ptr %p5201, i64 -24
  %ld5203 = load i64, ptr %rgep5202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5203, ptr %slot616, align 8
  %v5204 = load i64, ptr %slot616, align 8
  %cmp5205 = icmp ne i64 %v5204, 0
  %cv5206 = zext i1 %cmp5205 to i32
  store i32 %cv5206, ptr %slot617, align 8
  %v5207 = load i32, ptr %slot617, align 8
  %cv5208 = zext i32 %v5207 to i64
  %cond5209 = icmp ne i64 %cv5208, 0
  br i1 %cond5209, label %bb_rcgdec897, label %bb_rcgslow897
bb_rcgslow897:
  %v5210 = load i64, ptr %slot604, align 8
  %v5211 = load i64, ptr %slot587, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5210, i64 %v5211) nomerge, !dbg !156
  br label %bb_rcgdone897
bb_rcgdec897:
  %v5212 = load i64, ptr %slot613, align 8
  %v5213 = load i64, ptr %slot605, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %rgep5215 = getelementptr i8, ptr %p5214, i64 -32
  store i64 %v5212, ptr %rgep5215, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear897
bb_rcgclear897:
  %v5216 = load i64, ptr %slot587, align 8
  %p5217 = inttoptr i64 %v5216 to ptr
  store i64 0, ptr %p5217, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone897
bb_rcgdone897:
  br label %bb_rcslotdone866
bb_rcslotdone866:
  %v5218 = load i64, ptr %slot11, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %ld5220 = load i32, ptr %p5219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5220, ptr %slot618, align 8
  %v5221 = load i32, ptr %slot618, align 8
  %cv5222 = zext i32 %v5221 to i64
  %cond5223 = icmp ne i64 %cv5222, 0
  br i1 %cond5223, label %bb_rcslotdrop903, label %bb_rcslotdone903
bb_rcslotdrop903:
  %v5224 = load i64, ptr %slot11, align 8
  %p5225 = inttoptr i64 %v5224 to ptr
  store i32 0, ptr %p5225, align 4, !alias.scope !3, !noalias !4
  %v5226 = load i64, ptr %slot41, align 8
  store i64 %v5226, ptr %slot619, align 8
  %v5227 = load i64, ptr %slot12, align 8
  %p5228 = inttoptr i64 %v5227 to ptr
  %ld5229 = load i32, ptr %p5228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5229, ptr %slot620, align 8
  %v5230 = load i32, ptr %slot620, align 8
  %op5231 = and i32 %v5230, 28
  store i32 %op5231, ptr %slot621, align 8
  %v5232 = load i32, ptr %slot621, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcslotrole903, label %bb_rcslotowner903
bb_rcslotrole903:
  %v5235 = load i64, ptr %slot63, align 8
  store i64 %v5235, ptr %slot622, align 8
  %v5236 = load i64, ptr %slot619, align 8
  %p5237 = inttoptr i64 %v5236 to ptr
  %ld5238 = load i64, ptr %p5237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5238, ptr %slot623, align 8
  %v5239 = load i64, ptr %slot623, align 8
  %cmp5240 = icmp ne i64 %v5239, 0
  %cv5241 = zext i1 %cmp5240 to i32
  store i32 %cv5241, ptr %slot624, align 8
  %v5242 = load i32, ptr %slot624, align 8
  %cv5243 = zext i32 %v5242 to i64
  %cond5244 = icmp ne i64 %cv5243, 0
  br i1 %cond5244, label %bb_rcgnn919, label %bb_rcgdone919
bb_rcgnn919:
  %v5245 = load i64, ptr %slot623, align 8
  %op5246 = sub i64 %v5245, 16
  store i64 %op5246, ptr %slot625, align 8
  %v5247 = load i64, ptr %slot623, align 8
  %p5248 = inttoptr i64 %v5247 to ptr
  %rgep5249 = getelementptr i8, ptr %p5248, i64 -16
  %ld5250 = load i64, ptr %rgep5249, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5250, ptr %slot626, align 8
  %v5251 = load i64, ptr %slot626, align 8
  %op5252 = and i64 %v5251, 4611686018427387906
  store i64 %op5252, ptr %slot627, align 8
  %v5253 = load i64, ptr %slot627, align 8
  %cmp5254 = icmp ne i64 %v5253, 0
  %cv5255 = zext i1 %cmp5254 to i32
  store i32 %cv5255, ptr %slot628, align 8
  %v5256 = load i32, ptr %slot628, align 8
  %cv5257 = zext i32 %v5256 to i64
  %cond5258 = icmp ne i64 %cv5257, 0
  br i1 %cond5258, label %bb_rcgclear919, label %bb_rcgcounted919
bb_rcgcounted919:
  %v5259 = load i64, ptr %slot623, align 8
  %op5260 = sub i64 %v5259, 24
  store i64 %op5260, ptr %slot629, align 8
  %v5261 = load i64, ptr %slot623, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %rgep5263 = getelementptr i8, ptr %p5262, i64 -24
  %ld5264 = load i64, ptr %rgep5263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5264, ptr %slot630, align 8
  %v5265 = load i64, ptr %slot630, align 8
  %op5266 = sub i64 %v5265, 1
  store i64 %op5266, ptr %slot631, align 8
  %v5267 = load i64, ptr %slot631, align 8
  %cmp5268 = icmp eq i64 %v5267, 0
  %cv5269 = zext i1 %cmp5268 to i32
  store i32 %cv5269, ptr %slot632, align 8
  %v5270 = load i32, ptr %slot632, align 8
  %cv5271 = zext i32 %v5270 to i64
  %cond5272 = icmp ne i64 %cv5271, 0
  br i1 %cond5272, label %bb_rcglast919, label %bb_rcgdec919
bb_rcglast919:
  %v5273 = load i64, ptr %slot623, align 8
  %op5274 = sub i64 %v5273, 32
  store i64 %op5274, ptr %slot633, align 8
  %v5275 = load i64, ptr %slot623, align 8
  %p5276 = inttoptr i64 %v5275 to ptr
  %rgep5277 = getelementptr i8, ptr %p5276, i64 -32
  %ld5278 = load i64, ptr %rgep5277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5278, ptr %slot634, align 8
  %v5279 = load i64, ptr %slot634, align 8
  %cmp5280 = icmp ne i64 %v5279, 0
  %cv5281 = zext i1 %cmp5280 to i32
  store i32 %cv5281, ptr %slot635, align 8
  %v5282 = load i32, ptr %slot635, align 8
  %cv5283 = zext i32 %v5282 to i64
  %cond5284 = icmp ne i64 %cv5283, 0
  br i1 %cond5284, label %bb_rcgdec919, label %bb_rcgslow919
bb_rcgslow919:
  %v5285 = load i64, ptr %slot622, align 8
  %v5286 = load i64, ptr %slot619, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5285, i64 %v5286) nomerge, !dbg !156
  br label %bb_rcgdone919
bb_rcgdec919:
  %v5287 = load i64, ptr %slot631, align 8
  %v5288 = load i64, ptr %slot623, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  %rgep5290 = getelementptr i8, ptr %p5289, i64 -24
  store i64 %v5287, ptr %rgep5290, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear919
bb_rcgclear919:
  %v5291 = load i64, ptr %slot619, align 8
  %p5292 = inttoptr i64 %v5291 to ptr
  store i64 0, ptr %p5292, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone919
bb_rcgdone919:
  br label %bb_rcslotdone903
bb_rcslotowner903:
  %v5293 = load i64, ptr %slot63, align 8
  store i64 %v5293, ptr %slot636, align 8
  %v5294 = load i64, ptr %slot619, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %ld5296 = load i64, ptr %p5295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5296, ptr %slot637, align 8
  %v5297 = load i64, ptr %slot637, align 8
  %cmp5298 = icmp ne i64 %v5297, 0
  %cv5299 = zext i1 %cmp5298 to i32
  store i32 %cv5299, ptr %slot638, align 8
  %v5300 = load i32, ptr %slot638, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcgnn934, label %bb_rcgdone934
bb_rcgnn934:
  %v5303 = load i64, ptr %slot637, align 8
  %op5304 = sub i64 %v5303, 16
  store i64 %op5304, ptr %slot639, align 8
  %v5305 = load i64, ptr %slot637, align 8
  %p5306 = inttoptr i64 %v5305 to ptr
  %rgep5307 = getelementptr i8, ptr %p5306, i64 -16
  %ld5308 = load i64, ptr %rgep5307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5308, ptr %slot640, align 8
  %v5309 = load i64, ptr %slot640, align 8
  %op5310 = and i64 %v5309, 4611686018427387906
  store i64 %op5310, ptr %slot641, align 8
  %v5311 = load i64, ptr %slot641, align 8
  %cmp5312 = icmp ne i64 %v5311, 0
  %cv5313 = zext i1 %cmp5312 to i32
  store i32 %cv5313, ptr %slot642, align 8
  %v5314 = load i32, ptr %slot642, align 8
  %cv5315 = zext i32 %v5314 to i64
  %cond5316 = icmp ne i64 %cv5315, 0
  br i1 %cond5316, label %bb_rcgclear934, label %bb_rcgcounted934
bb_rcgcounted934:
  %v5317 = load i64, ptr %slot637, align 8
  %op5318 = sub i64 %v5317, 32
  store i64 %op5318, ptr %slot643, align 8
  %v5319 = load i64, ptr %slot637, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %rgep5321 = getelementptr i8, ptr %p5320, i64 -32
  %ld5322 = load i64, ptr %rgep5321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5322, ptr %slot644, align 8
  %v5323 = load i64, ptr %slot644, align 8
  %op5324 = sub i64 %v5323, 1
  store i64 %op5324, ptr %slot645, align 8
  %v5325 = load i64, ptr %slot645, align 8
  %cmp5326 = icmp eq i64 %v5325, 0
  %cv5327 = zext i1 %cmp5326 to i32
  store i32 %cv5327, ptr %slot646, align 8
  %v5328 = load i32, ptr %slot646, align 8
  %cv5329 = zext i32 %v5328 to i64
  %cond5330 = icmp ne i64 %cv5329, 0
  br i1 %cond5330, label %bb_rcglast934, label %bb_rcgdec934
bb_rcglast934:
  %v5331 = load i64, ptr %slot637, align 8
  %op5332 = sub i64 %v5331, 24
  store i64 %op5332, ptr %slot647, align 8
  %v5333 = load i64, ptr %slot637, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  %rgep5335 = getelementptr i8, ptr %p5334, i64 -24
  %ld5336 = load i64, ptr %rgep5335, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5336, ptr %slot648, align 8
  %v5337 = load i64, ptr %slot648, align 8
  %cmp5338 = icmp ne i64 %v5337, 0
  %cv5339 = zext i1 %cmp5338 to i32
  store i32 %cv5339, ptr %slot649, align 8
  %v5340 = load i32, ptr %slot649, align 8
  %cv5341 = zext i32 %v5340 to i64
  %cond5342 = icmp ne i64 %cv5341, 0
  br i1 %cond5342, label %bb_rcgdec934, label %bb_rcgslow934
bb_rcgslow934:
  %v5343 = load i64, ptr %slot636, align 8
  %v5344 = load i64, ptr %slot619, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5343, i64 %v5344) nomerge, !dbg !156
  br label %bb_rcgdone934
bb_rcgdec934:
  %v5345 = load i64, ptr %slot645, align 8
  %v5346 = load i64, ptr %slot637, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  %rgep5348 = getelementptr i8, ptr %p5347, i64 -32
  store i64 %v5345, ptr %rgep5348, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear934
bb_rcgclear934:
  %v5349 = load i64, ptr %slot619, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  store i64 0, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone934
bb_rcgdone934:
  br label %bb_rcslotdone903
bb_rcslotdone903:
  %v5351 = load i64, ptr %slot9, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i32, ptr %p5352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5353, ptr %slot650, align 8
  %v5354 = load i32, ptr %slot650, align 8
  %cv5355 = zext i32 %v5354 to i64
  %cond5356 = icmp ne i64 %cv5355, 0
  br i1 %cond5356, label %bb_rcslotdrop940, label %bb_rcslotdone940
bb_rcslotdrop940:
  %v5357 = load i64, ptr %slot9, align 8
  %p5358 = inttoptr i64 %v5357 to ptr
  store i32 0, ptr %p5358, align 4, !alias.scope !3, !noalias !4
  %v5359 = load i64, ptr %slot40, align 8
  store i64 %v5359, ptr %slot651, align 8
  %v5360 = load i64, ptr %slot10, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %ld5362 = load i32, ptr %p5361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5362, ptr %slot652, align 8
  %v5363 = load i32, ptr %slot652, align 8
  %op5364 = and i32 %v5363, 28
  store i32 %op5364, ptr %slot653, align 8
  %v5365 = load i32, ptr %slot653, align 8
  %cv5366 = zext i32 %v5365 to i64
  %cond5367 = icmp ne i64 %cv5366, 0
  br i1 %cond5367, label %bb_rcslotrole940, label %bb_rcslotowner940
bb_rcslotrole940:
  %v5368 = load i64, ptr %slot63, align 8
  store i64 %v5368, ptr %slot654, align 8
  %v5369 = load i64, ptr %slot651, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  %ld5371 = load i64, ptr %p5370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5371, ptr %slot655, align 8
  %v5372 = load i64, ptr %slot655, align 8
  %cmp5373 = icmp ne i64 %v5372, 0
  %cv5374 = zext i1 %cmp5373 to i32
  store i32 %cv5374, ptr %slot656, align 8
  %v5375 = load i32, ptr %slot656, align 8
  %cv5376 = zext i32 %v5375 to i64
  %cond5377 = icmp ne i64 %cv5376, 0
  br i1 %cond5377, label %bb_rcgnn956, label %bb_rcgdone956
bb_rcgnn956:
  %v5378 = load i64, ptr %slot655, align 8
  %op5379 = sub i64 %v5378, 16
  store i64 %op5379, ptr %slot657, align 8
  %v5380 = load i64, ptr %slot655, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %rgep5382 = getelementptr i8, ptr %p5381, i64 -16
  %ld5383 = load i64, ptr %rgep5382, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5383, ptr %slot658, align 8
  %v5384 = load i64, ptr %slot658, align 8
  %op5385 = and i64 %v5384, 4611686018427387906
  store i64 %op5385, ptr %slot659, align 8
  %v5386 = load i64, ptr %slot659, align 8
  %cmp5387 = icmp ne i64 %v5386, 0
  %cv5388 = zext i1 %cmp5387 to i32
  store i32 %cv5388, ptr %slot660, align 8
  %v5389 = load i32, ptr %slot660, align 8
  %cv5390 = zext i32 %v5389 to i64
  %cond5391 = icmp ne i64 %cv5390, 0
  br i1 %cond5391, label %bb_rcgclear956, label %bb_rcgcounted956
bb_rcgcounted956:
  %v5392 = load i64, ptr %slot655, align 8
  %op5393 = sub i64 %v5392, 24
  store i64 %op5393, ptr %slot661, align 8
  %v5394 = load i64, ptr %slot655, align 8
  %p5395 = inttoptr i64 %v5394 to ptr
  %rgep5396 = getelementptr i8, ptr %p5395, i64 -24
  %ld5397 = load i64, ptr %rgep5396, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5397, ptr %slot662, align 8
  %v5398 = load i64, ptr %slot662, align 8
  %op5399 = sub i64 %v5398, 1
  store i64 %op5399, ptr %slot663, align 8
  %v5400 = load i64, ptr %slot663, align 8
  %cmp5401 = icmp eq i64 %v5400, 0
  %cv5402 = zext i1 %cmp5401 to i32
  store i32 %cv5402, ptr %slot664, align 8
  %v5403 = load i32, ptr %slot664, align 8
  %cv5404 = zext i32 %v5403 to i64
  %cond5405 = icmp ne i64 %cv5404, 0
  br i1 %cond5405, label %bb_rcglast956, label %bb_rcgdec956
bb_rcglast956:
  %v5406 = load i64, ptr %slot655, align 8
  %op5407 = sub i64 %v5406, 32
  store i64 %op5407, ptr %slot665, align 8
  %v5408 = load i64, ptr %slot655, align 8
  %p5409 = inttoptr i64 %v5408 to ptr
  %rgep5410 = getelementptr i8, ptr %p5409, i64 -32
  %ld5411 = load i64, ptr %rgep5410, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5411, ptr %slot666, align 8
  %v5412 = load i64, ptr %slot666, align 8
  %cmp5413 = icmp ne i64 %v5412, 0
  %cv5414 = zext i1 %cmp5413 to i32
  store i32 %cv5414, ptr %slot667, align 8
  %v5415 = load i32, ptr %slot667, align 8
  %cv5416 = zext i32 %v5415 to i64
  %cond5417 = icmp ne i64 %cv5416, 0
  br i1 %cond5417, label %bb_rcgdec956, label %bb_rcgslow956
bb_rcgslow956:
  %v5418 = load i64, ptr %slot654, align 8
  %v5419 = load i64, ptr %slot651, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v5418, i64 %v5419) nomerge, !dbg !156
  br label %bb_rcgdone956
bb_rcgdec956:
  %v5420 = load i64, ptr %slot663, align 8
  %v5421 = load i64, ptr %slot655, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %rgep5423 = getelementptr i8, ptr %p5422, i64 -24
  store i64 %v5420, ptr %rgep5423, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear956
bb_rcgclear956:
  %v5424 = load i64, ptr %slot651, align 8
  %p5425 = inttoptr i64 %v5424 to ptr
  store i64 0, ptr %p5425, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone956
bb_rcgdone956:
  br label %bb_rcslotdone940
bb_rcslotowner940:
  %v5426 = load i64, ptr %slot63, align 8
  store i64 %v5426, ptr %slot668, align 8
  %v5427 = load i64, ptr %slot651, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %ld5429 = load i64, ptr %p5428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5429, ptr %slot669, align 8
  %v5430 = load i64, ptr %slot669, align 8
  %cmp5431 = icmp ne i64 %v5430, 0
  %cv5432 = zext i1 %cmp5431 to i32
  store i32 %cv5432, ptr %slot670, align 8
  %v5433 = load i32, ptr %slot670, align 8
  %cv5434 = zext i32 %v5433 to i64
  %cond5435 = icmp ne i64 %cv5434, 0
  br i1 %cond5435, label %bb_rcgnn971, label %bb_rcgdone971
bb_rcgnn971:
  %v5436 = load i64, ptr %slot669, align 8
  %op5437 = sub i64 %v5436, 16
  store i64 %op5437, ptr %slot671, align 8
  %v5438 = load i64, ptr %slot669, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %rgep5440 = getelementptr i8, ptr %p5439, i64 -16
  %ld5441 = load i64, ptr %rgep5440, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5441, ptr %slot672, align 8
  %v5442 = load i64, ptr %slot672, align 8
  %op5443 = and i64 %v5442, 4611686018427387906
  store i64 %op5443, ptr %slot673, align 8
  %v5444 = load i64, ptr %slot673, align 8
  %cmp5445 = icmp ne i64 %v5444, 0
  %cv5446 = zext i1 %cmp5445 to i32
  store i32 %cv5446, ptr %slot674, align 8
  %v5447 = load i32, ptr %slot674, align 8
  %cv5448 = zext i32 %v5447 to i64
  %cond5449 = icmp ne i64 %cv5448, 0
  br i1 %cond5449, label %bb_rcgclear971, label %bb_rcgcounted971
bb_rcgcounted971:
  %v5450 = load i64, ptr %slot669, align 8
  %op5451 = sub i64 %v5450, 32
  store i64 %op5451, ptr %slot675, align 8
  %v5452 = load i64, ptr %slot669, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  %rgep5454 = getelementptr i8, ptr %p5453, i64 -32
  %ld5455 = load i64, ptr %rgep5454, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5455, ptr %slot676, align 8
  %v5456 = load i64, ptr %slot676, align 8
  %op5457 = sub i64 %v5456, 1
  store i64 %op5457, ptr %slot677, align 8
  %v5458 = load i64, ptr %slot677, align 8
  %cmp5459 = icmp eq i64 %v5458, 0
  %cv5460 = zext i1 %cmp5459 to i32
  store i32 %cv5460, ptr %slot678, align 8
  %v5461 = load i32, ptr %slot678, align 8
  %cv5462 = zext i32 %v5461 to i64
  %cond5463 = icmp ne i64 %cv5462, 0
  br i1 %cond5463, label %bb_rcglast971, label %bb_rcgdec971
bb_rcglast971:
  %v5464 = load i64, ptr %slot669, align 8
  %op5465 = sub i64 %v5464, 24
  store i64 %op5465, ptr %slot679, align 8
  %v5466 = load i64, ptr %slot669, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %rgep5468 = getelementptr i8, ptr %p5467, i64 -24
  %ld5469 = load i64, ptr %rgep5468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5469, ptr %slot680, align 8
  %v5470 = load i64, ptr %slot680, align 8
  %cmp5471 = icmp ne i64 %v5470, 0
  %cv5472 = zext i1 %cmp5471 to i32
  store i32 %cv5472, ptr %slot681, align 8
  %v5473 = load i32, ptr %slot681, align 8
  %cv5474 = zext i32 %v5473 to i64
  %cond5475 = icmp ne i64 %cv5474, 0
  br i1 %cond5475, label %bb_rcgdec971, label %bb_rcgslow971
bb_rcgslow971:
  %v5476 = load i64, ptr %slot668, align 8
  %v5477 = load i64, ptr %slot651, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v5476, i64 %v5477) nomerge, !dbg !156
  br label %bb_rcgdone971
bb_rcgdec971:
  %v5478 = load i64, ptr %slot677, align 8
  %v5479 = load i64, ptr %slot669, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %rgep5481 = getelementptr i8, ptr %p5480, i64 -32
  store i64 %v5478, ptr %rgep5481, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear971
bb_rcgclear971:
  %v5482 = load i64, ptr %slot651, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  store i64 0, ptr %p5483, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone971
bb_rcgdone971:
  br label %bb_rcslotdone940
bb_rcslotdone940:
  %v5484 = load i64, ptr %slot7, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %ld5486 = load i32, ptr %p5485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5486, ptr %slot682, align 8
  %v5487 = load i32, ptr %slot682, align 8
  %cv5488 = zext i32 %v5487 to i64
  %cond5489 = icmp ne i64 %cv5488, 0
  br i1 %cond5489, label %bb_rcslotdrop995, label %bb_rcslotdone995
bb_rcslotdrop995:
  %v5490 = load i64, ptr %slot7, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  store i32 0, ptr %p5491, align 4, !alias.scope !3, !noalias !4
  %v5492 = load i64, ptr %slot38, align 8
  store i64 %v5492, ptr %slot683, align 8
  %v5493 = load i64, ptr %slot8, align 8
  %p5494 = inttoptr i64 %v5493 to ptr
  %ld5495 = load i32, ptr %p5494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5495, ptr %slot684, align 8
  %v5496 = load i32, ptr %slot684, align 8
  %op5497 = and i32 %v5496, 28
  store i32 %op5497, ptr %slot685, align 8
  %v5498 = load i32, ptr %slot685, align 8
  %cv5499 = zext i32 %v5498 to i64
  %cond5500 = icmp ne i64 %cv5499, 0
  br i1 %cond5500, label %bb_rcslotrole995, label %bb_rcslotowner995
bb_rcslotrole995:
  %v5501 = load i64, ptr %slot63, align 8
  store i64 %v5501, ptr %slot686, align 8
  %v5502 = load i64, ptr %slot686, align 8
  %v5503 = load i64, ptr %slot683, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5502, i64 %v5503) nomerge, !dbg !156
  br label %bb_rcslotdone995
bb_rcslotowner995:
  %v5504 = load i64, ptr %slot63, align 8
  store i64 %v5504, ptr %slot687, align 8
  %v5505 = load i64, ptr %slot687, align 8
  %v5506 = load i64, ptr %slot683, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5505, i64 %v5506) nomerge, !dbg !156
  br label %bb_rcslotdone995
bb_rcslotdone995:
  %v5507 = load i64, ptr %slot573, align 8
  %p5508 = inttoptr i64 %v5507 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5508, i64 24, i1 false)
  ret void
bb_i65:
  %v5509 = load i64, ptr %slot44, align 8
  %p5510 = inttoptr i64 %v5509 to ptr
  %ld5511 = load i64, ptr %p5510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5511, ptr %slot688, align 8
  %v5512 = load i64, ptr %slot688, align 8
  %v5513 = load i64, ptr %slot37, align 8
  %p5514 = inttoptr i64 %v5512 to ptr
  %p5515 = inttoptr i64 %v5513 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5515, ptr %p5514, i64 16, i1 false)
  %v5516 = load i64, ptr %slot26, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %ld5518 = load i64, ptr %p5517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5518, ptr %slot689, align 8
  %v5519 = load i64, ptr %slot689, align 8
  %v5520 = load i64, ptr %slot52, align 8
  %p5521 = inttoptr i64 %v5519 to ptr
  %p5522 = inttoptr i64 %v5520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5522, ptr %p5521, i64 304, i1 false), !alias.scope !10000000
  %v5523 = load i64, ptr %slot52, align 8
  %v5524 = load i64, ptr %slot44, align 8
  %p5525 = inttoptr i64 %v5524 to ptr
  store i64 %v5523, ptr %p5525, align 8, !alias.scope !3, !noalias !4
  %v5526 = load i64, ptr %slot44, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  %ld5528 = load i64, ptr %p5527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5528, ptr %slot690, align 8
  %v5529 = load i64, ptr %slot690, align 8
  %op5530 = add i64 %v5529, 32
  store i64 %op5530, ptr %slot691, align 8
  %v5531 = load i64, ptr %slot691, align 8
  %v5532 = load i64, ptr %slot44, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  store i64 %v5531, ptr %p5533, align 8, !alias.scope !3, !noalias !4
  %v5534 = load i64, ptr %slot7, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  %ld5536 = load i32, ptr %p5535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5536, ptr %slot692, align 8
  %v5537 = load i32, ptr %slot692, align 8
  %cv5538 = zext i32 %v5537 to i64
  %cond5539 = icmp ne i64 %cv5538, 0
  br i1 %cond5539, label %bb_rcslotdrop1091, label %bb_rcslotdone1091
bb_rcslotdrop1091:
  %v5540 = load i64, ptr %slot7, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  store i32 0, ptr %p5541, align 4, !alias.scope !3, !noalias !4
  %v5542 = load i64, ptr %slot38, align 8
  store i64 %v5542, ptr %slot693, align 8
  %v5543 = load i64, ptr %slot8, align 8
  %p5544 = inttoptr i64 %v5543 to ptr
  %ld5545 = load i32, ptr %p5544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5545, ptr %slot694, align 8
  %v5546 = load i32, ptr %slot694, align 8
  %op5547 = and i32 %v5546, 28
  store i32 %op5547, ptr %slot695, align 8
  %v5548 = load i32, ptr %slot695, align 8
  %cv5549 = zext i32 %v5548 to i64
  %cond5550 = icmp ne i64 %cv5549, 0
  br i1 %cond5550, label %bb_rcslotrole1091, label %bb_rcslotowner1091
bb_rcslotrole1091:
  %v5551 = load i64, ptr %slot63, align 8
  store i64 %v5551, ptr %slot696, align 8
  %v5552 = load i64, ptr %slot696, align 8
  %v5553 = load i64, ptr %slot693, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5552, i64 %v5553) nomerge, !dbg !158
  br label %bb_rcslotdone1091
bb_rcslotowner1091:
  %v5554 = load i64, ptr %slot63, align 8
  store i64 %v5554, ptr %slot697, align 8
  %v5555 = load i64, ptr %slot697, align 8
  %v5556 = load i64, ptr %slot693, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5555, i64 %v5556) nomerge, !dbg !158
  br label %bb_rcslotdone1091
bb_rcslotdone1091:
  %v5557 = load i64, ptr %slot26, align 8
  %p5558 = inttoptr i64 %v5557 to ptr
  %ld5559 = load i64, ptr %p5558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5559, ptr %slot698, align 8
  %v5560 = load i64, ptr %slot698, align 8
  %op5561 = add i64 %v5560, 32
  store i64 %op5561, ptr %slot699, align 8
  %v5562 = load i64, ptr %slot38, align 8
  store i64 %v5562, ptr %slot700, align 8
  %v5563 = load i64, ptr %slot699, align 8
  %v5564 = load i64, ptr %slot700, align 8
  %p5565 = inttoptr i64 %v5563 to ptr
  %p5566 = inttoptr i64 %v5564 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5566, ptr %p5565, i64 208, i1 false), !alias.scope !10000000
  %v5567 = load i64, ptr %slot699, align 8
  %p5568 = inttoptr i64 %v5567 to ptr
  call void @llvm.memset.p0.i64(ptr %p5568, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !158
  %v5569 = load i64, ptr %slot7, align 8
  %p5570 = inttoptr i64 %v5569 to ptr
  store i32 1, ptr %p5570, align 4, !alias.scope !3, !noalias !4
  %v5571 = load i64, ptr %slot38, align 8
  %v5572 = load i64, ptr %slot44, align 8
  %p5573 = inttoptr i64 %v5572 to ptr
  store i64 %v5571, ptr %p5573, align 8, !alias.scope !3, !noalias !4
  %v5574 = load i64, ptr %slot27, align 8
  %p5575 = inttoptr i64 %v5574 to ptr
  %ld5576 = load i64, ptr %p5575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5576, ptr %slot701, align 8
  %v5577 = load i64, ptr %slot701, align 8
  %v5578 = load i64, ptr %slot45, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  store i64 %v5577, ptr %p5579, align 8, !alias.scope !3, !noalias !4
  %v5580 = load i64, ptr %slot37, align 8
  %v5581 = load i64, ptr %slot46, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  store i64 %v5580, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  %v5583 = load i64, ptr %slot44, align 8
  %p5584 = inttoptr i64 %v5583 to ptr
  %ld5585 = load i64, ptr %p5584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5585, ptr %slot702, align 8
  %v5586 = load i64, ptr %slot45, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i64, ptr %p5587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5588, ptr %slot703, align 8
  %v5589 = load i64, ptr %slot46, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %ld5591 = load i64, ptr %p5590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5591, ptr %slot704, align 8
  %v5592 = load i64, ptr %slot1, align 8
  %v5593 = load i64, ptr %slot702, align 8
  %v5594 = load i64, ptr %slot703, align 8
  %v5595 = load i64, ptr %slot704, align 8
  %call5596 = call i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64 %v5592, i64 %v5593, i64 %v5594, i64 %v5595) nomerge, !dbg !160
  store i64 %call5596, ptr %slot705, align 8
  %v5597 = load i64, ptr %slot705, align 8
  %v5598 = load i64, ptr %slot44, align 8
  %p5599 = inttoptr i64 %v5598 to ptr
  store i64 %v5597, ptr %p5599, align 8, !alias.scope !3, !noalias !4
  %v5600 = load i64, ptr %slot17, align 8
  %p5601 = inttoptr i64 %v5600 to ptr
  %ld5602 = load i32, ptr %p5601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5602, ptr %slot706, align 8
  %v5603 = load i32, ptr %slot706, align 8
  %cv5604 = zext i32 %v5603 to i64
  %cond5605 = icmp ne i64 %cv5604, 0
  br i1 %cond5605, label %bb_rcslotdrop1109, label %bb_rcslotdone1109
bb_rcslotdrop1109:
  %v5606 = load i64, ptr %slot17, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  store i32 0, ptr %p5607, align 4, !alias.scope !3, !noalias !4
  %v5608 = load i64, ptr %slot22, align 8
  store i64 %v5608, ptr %slot707, align 8
  %v5609 = load i64, ptr %slot18, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  %ld5611 = load i32, ptr %p5610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5611, ptr %slot708, align 8
  %v5612 = load i32, ptr %slot708, align 8
  %op5613 = and i32 %v5612, 28
  store i32 %op5613, ptr %slot709, align 8
  %v5614 = load i32, ptr %slot709, align 8
  %cv5615 = zext i32 %v5614 to i64
  %cond5616 = icmp ne i64 %cv5615, 0
  br i1 %cond5616, label %bb_rcslotrole1109, label %bb_rcslotowner1109
bb_rcslotrole1109:
  %v5617 = load i64, ptr %slot63, align 8
  store i64 %v5617, ptr %slot710, align 8
  %v5618 = load i64, ptr %slot710, align 8
  %v5619 = load i64, ptr %slot707, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5618, i64 %v5619) nomerge, !dbg !160
  br label %bb_rcslotdone1109
bb_rcslotowner1109:
  %v5620 = load i64, ptr %slot63, align 8
  store i64 %v5620, ptr %slot711, align 8
  %v5621 = load i64, ptr %slot711, align 8
  %v5622 = load i64, ptr %slot707, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5621, i64 %v5622) nomerge, !dbg !160
  br label %bb_rcslotdone1109
bb_rcslotdone1109:
  %v5623 = load i64, ptr %slot26, align 8
  %p5624 = inttoptr i64 %v5623 to ptr
  %ld5625 = load i64, ptr %p5624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5625, ptr %slot712, align 8
  %v5626 = load i64, ptr %slot712, align 8
  %op5627 = add i64 %v5626, 32
  store i64 %op5627, ptr %slot713, align 8
  %v5628 = load i64, ptr %slot38, align 8
  store i64 %v5628, ptr %slot714, align 8
  %v5629 = load i64, ptr %slot714, align 8
  %v5630 = load i64, ptr %slot713, align 8
  %p5631 = inttoptr i64 %v5629 to ptr
  %p5632 = inttoptr i64 %v5630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5632, ptr %p5631, i64 208, i1 false), !alias.scope !10000000
  %v5633 = load i64, ptr %slot714, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  call void @llvm.memset.p0.i64(ptr %p5634, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !162
  %v5635 = load i64, ptr %slot7, align 8
  %p5636 = inttoptr i64 %v5635 to ptr
  store i32 0, ptr %p5636, align 4, !alias.scope !3, !noalias !4
  %v5637 = load i64, ptr %slot44, align 8
  %p5638 = inttoptr i64 %v5637 to ptr
  store i64 0, ptr %p5638, align 8, !alias.scope !3, !noalias !4
  %v5639 = load i64, ptr %slot44, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  store i64 0, ptr %p5640, align 8, !alias.scope !3, !noalias !4
  %v5641 = load i64, ptr %slot53, align 8
  store i64 %v5641, ptr %slot715, align 8
  %v5642 = load i64, ptr %slot715, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  store i64 0, ptr %p5643, align 8, !alias.scope !3, !noalias !4
  %v5644 = load i64, ptr %slot715, align 8
  %p5646 = inttoptr i64 %v5644 to ptr
  %gep5647 = getelementptr i8, ptr %p5646, i64 8
  %op5645 = ptrtoint ptr %gep5647 to i64
  store i64 %op5645, ptr %slot716, align 8
  %v5648 = load i64, ptr %slot716, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  store i64 0, ptr %p5649, align 8, !alias.scope !3, !noalias !4
  %v5650 = load i64, ptr %slot715, align 8
  %p5652 = inttoptr i64 %v5650 to ptr
  %gep5653 = getelementptr i8, ptr %p5652, i64 16
  %op5651 = ptrtoint ptr %gep5653 to i64
  store i64 %op5651, ptr %slot717, align 8
  %v5654 = load i64, ptr %slot717, align 8
  %p5655 = inttoptr i64 %v5654 to ptr
  store i64 0, ptr %p5655, align 8, !alias.scope !3, !noalias !4
  %v5656 = load i64, ptr %slot715, align 8
  %p5657 = inttoptr i64 %v5656 to ptr
  store i32 0, ptr %p5657, align 4, !alias.scope !3, !noalias !4
  %v5658 = load i64, ptr %slot21, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  store i32 1, ptr %p5659, align 4, !alias.scope !3, !noalias !4
  %v5660 = load i64, ptr %slot44, align 8
  store i64 %v5660, ptr %slot718, align 8
  %v5661 = load i64, ptr %slot715, align 8
  %p5663 = inttoptr i64 %v5661 to ptr
  %gep5664 = getelementptr i8, ptr %p5663, i64 8
  %op5662 = ptrtoint ptr %gep5664 to i64
  store i64 %op5662, ptr %slot719, align 8
  %v5665 = load i64, ptr %slot64, align 8
  store i64 %v5665, ptr %slot720, align 8
  store i64 0, ptr %slot721, align 8
  %v5666 = load i64, ptr %slot715, align 8
  %v5667 = load i64, ptr %slot44, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  store i64 %v5666, ptr %p5668, align 8, !alias.scope !3, !noalias !4
  %v5669 = load i64, ptr %slot44, align 8
  %p5670 = inttoptr i64 %v5669 to ptr
  %ld5671 = load i64, ptr %p5670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5671, ptr %slot722, align 8
  %v5672 = load i64, ptr %slot22, align 8
  store i64 %v5672, ptr %slot723, align 8
  %v5673 = load i64, ptr %slot722, align 8
  %v5674 = load i64, ptr %slot723, align 8
  %p5675 = inttoptr i64 %v5673 to ptr
  %p5676 = inttoptr i64 %v5674 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5676, ptr %p5675, i64 24, i1 false)
  %v5677 = load i64, ptr %slot18, align 8
  %p5678 = inttoptr i64 %v5677 to ptr
  store i32 2, ptr %p5678, align 4, !alias.scope !3, !noalias !4
  %v5679 = load i64, ptr %slot17, align 8
  %p5680 = inttoptr i64 %v5679 to ptr
  store i32 1, ptr %p5680, align 4, !alias.scope !3, !noalias !4
  %v5681 = load i64, ptr %slot723, align 8
  %v5682 = load i64, ptr %slot44, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  store i64 %v5681, ptr %p5683, align 8, !alias.scope !3, !noalias !4
  %v5684 = load i64, ptr %slot44, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  %ld5686 = load i64, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5686, ptr %slot724, align 8
  %v5687 = load i64, ptr %slot44, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  %ld5689 = load i64, ptr %p5688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5689, ptr %slot725, align 8
  %v5690 = load i64, ptr %slot24, align 8
  store i64 %v5690, ptr %slot726, align 8
  %v5691 = load i64, ptr %slot64, align 8
  store i64 %v5691, ptr %slot727, align 8
  %v5692 = load i64, ptr %slot63, align 8
  %v5693 = load i64, ptr %slot726, align 8
  %v5694 = load i64, ptr %slot725, align 8
  %v5695 = load i64, ptr %slot727, align 8
  %cv5696 = trunc i64 %v5695 to i32
  %call5697 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v5692, i64 %v5693, i64 %v5694, i32 %cv5696) nomerge, !dbg !164
  store i32 %call5697, ptr %slot728, align 8
  %v5698 = load i32, ptr %slot728, align 8
  %cv5699 = zext i32 %v5698 to i64
  %cond5700 = icmp ne i64 %cv5699, 0
  br i1 %cond5700, label %bb_rcsuccess1138, label %bb_rcfailure1138
bb_rcfailure1138:
  %v5701 = load i64, ptr %slot63, align 8
  %p5702 = inttoptr i64 %v5701 to ptr
  %call5703 = call i32 @myl_rc_take_failure(ptr %p5702) nomerge, !dbg !164
  store i32 %call5703, ptr %slot729, align 8
  %v5704 = load i64, ptr %slot1, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  %v5706 = load i32, ptr %slot729, align 8
  %call5707 = call i32 @myl_qbe_rc_status(ptr %p5705, i32 %v5706) nomerge, !dbg !164
  store i32 %call5707, ptr %slot730, align 8
  br label %bb_failure
bb_rcsuccess1138:
  %v5708 = load i64, ptr %slot17, align 8
  %p5709 = inttoptr i64 %v5708 to ptr
  store i32 0, ptr %p5709, align 4, !alias.scope !3, !noalias !4
  %v5710 = load i64, ptr %slot20, align 8
  %p5711 = inttoptr i64 %v5710 to ptr
  store i32 2, ptr %p5711, align 4, !alias.scope !3, !noalias !4
  %v5712 = load i64, ptr %slot19, align 8
  %p5713 = inttoptr i64 %v5712 to ptr
  store i32 1, ptr %p5713, align 4, !alias.scope !3, !noalias !4
  %v5714 = load i64, ptr %slot24, align 8
  store i64 %v5714, ptr %slot731, align 8
  %v5715 = load i64, ptr %slot19, align 8
  %p5716 = inttoptr i64 %v5715 to ptr
  store i32 0, ptr %p5716, align 4, !alias.scope !3, !noalias !4
  %v5717 = load i64, ptr %slot17, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  %ld5719 = load i32, ptr %p5718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5719, ptr %slot732, align 8
  %v5720 = load i32, ptr %slot732, align 8
  %cv5721 = zext i32 %v5720 to i64
  %cond5722 = icmp ne i64 %cv5721, 0
  br i1 %cond5722, label %bb_rcslotdrop1148, label %bb_rcslotdone1148
bb_rcslotdrop1148:
  %v5723 = load i64, ptr %slot17, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  store i32 0, ptr %p5724, align 4, !alias.scope !3, !noalias !4
  %v5725 = load i64, ptr %slot22, align 8
  store i64 %v5725, ptr %slot733, align 8
  %v5726 = load i64, ptr %slot18, align 8
  %p5727 = inttoptr i64 %v5726 to ptr
  %ld5728 = load i32, ptr %p5727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5728, ptr %slot734, align 8
  %v5729 = load i32, ptr %slot734, align 8
  %op5730 = and i32 %v5729, 28
  store i32 %op5730, ptr %slot735, align 8
  %v5731 = load i32, ptr %slot735, align 8
  %cv5732 = zext i32 %v5731 to i64
  %cond5733 = icmp ne i64 %cv5732, 0
  br i1 %cond5733, label %bb_rcslotrole1148, label %bb_rcslotowner1148
bb_rcslotrole1148:
  %v5734 = load i64, ptr %slot63, align 8
  store i64 %v5734, ptr %slot736, align 8
  %v5735 = load i64, ptr %slot736, align 8
  %v5736 = load i64, ptr %slot733, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5735, i64 %v5736) nomerge, !dbg !164
  br label %bb_rcslotdone1148
bb_rcslotowner1148:
  %v5737 = load i64, ptr %slot63, align 8
  store i64 %v5737, ptr %slot737, align 8
  %v5738 = load i64, ptr %slot737, align 8
  %v5739 = load i64, ptr %slot733, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5738, i64 %v5739) nomerge, !dbg !164
  br label %bb_rcslotdone1148
bb_rcslotdone1148:
  %v5740 = load i64, ptr %slot15, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  %ld5742 = load i32, ptr %p5741, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5742, ptr %slot738, align 8
  %v5743 = load i32, ptr %slot738, align 8
  %cv5744 = zext i32 %v5743 to i64
  %cond5745 = icmp ne i64 %cv5744, 0
  br i1 %cond5745, label %bb_rcslotdrop1175, label %bb_rcslotdone1175
bb_rcslotdrop1175:
  %v5746 = load i64, ptr %slot15, align 8
  %p5747 = inttoptr i64 %v5746 to ptr
  store i32 0, ptr %p5747, align 4, !alias.scope !3, !noalias !4
  %v5748 = load i64, ptr %slot43, align 8
  store i64 %v5748, ptr %slot739, align 8
  %v5749 = load i64, ptr %slot16, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  %ld5751 = load i32, ptr %p5750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5751, ptr %slot740, align 8
  %v5752 = load i32, ptr %slot740, align 8
  %op5753 = and i32 %v5752, 28
  store i32 %op5753, ptr %slot741, align 8
  %v5754 = load i32, ptr %slot741, align 8
  %cv5755 = zext i32 %v5754 to i64
  %cond5756 = icmp ne i64 %cv5755, 0
  br i1 %cond5756, label %bb_rcslotrole1175, label %bb_rcslotowner1175
bb_rcslotrole1175:
  %v5757 = load i64, ptr %slot63, align 8
  store i64 %v5757, ptr %slot742, align 8
  %v5758 = load i64, ptr %slot742, align 8
  %v5759 = load i64, ptr %slot739, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5758, i64 %v5759) nomerge, !dbg !164
  br label %bb_rcslotdone1175
bb_rcslotowner1175:
  %v5760 = load i64, ptr %slot63, align 8
  store i64 %v5760, ptr %slot743, align 8
  %v5761 = load i64, ptr %slot743, align 8
  %v5762 = load i64, ptr %slot739, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5761, i64 %v5762) nomerge, !dbg !164
  br label %bb_rcslotdone1175
bb_rcslotdone1175:
  %v5763 = load i64, ptr %slot13, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  %ld5765 = load i32, ptr %p5764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5765, ptr %slot744, align 8
  %v5766 = load i32, ptr %slot744, align 8
  %cv5767 = zext i32 %v5766 to i64
  %cond5768 = icmp ne i64 %cv5767, 0
  br i1 %cond5768, label %bb_rcslotdrop1184, label %bb_rcslotdone1184
bb_rcslotdrop1184:
  %v5769 = load i64, ptr %slot13, align 8
  %p5770 = inttoptr i64 %v5769 to ptr
  store i32 0, ptr %p5770, align 4, !alias.scope !3, !noalias !4
  %v5771 = load i64, ptr %slot42, align 8
  store i64 %v5771, ptr %slot745, align 8
  %v5772 = load i64, ptr %slot14, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  %ld5774 = load i32, ptr %p5773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5774, ptr %slot746, align 8
  %v5775 = load i32, ptr %slot746, align 8
  %op5776 = and i32 %v5775, 28
  store i32 %op5776, ptr %slot747, align 8
  %v5777 = load i32, ptr %slot747, align 8
  %cv5778 = zext i32 %v5777 to i64
  %cond5779 = icmp ne i64 %cv5778, 0
  br i1 %cond5779, label %bb_rcslotrole1184, label %bb_rcslotowner1184
bb_rcslotrole1184:
  %v5780 = load i64, ptr %slot63, align 8
  store i64 %v5780, ptr %slot748, align 8
  %v5781 = load i64, ptr %slot745, align 8
  %p5782 = inttoptr i64 %v5781 to ptr
  %ld5783 = load i64, ptr %p5782, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5783, ptr %slot749, align 8
  %v5784 = load i64, ptr %slot749, align 8
  %cmp5785 = icmp ne i64 %v5784, 0
  %cv5786 = zext i1 %cmp5785 to i32
  store i32 %cv5786, ptr %slot750, align 8
  %v5787 = load i32, ptr %slot750, align 8
  %cv5788 = zext i32 %v5787 to i64
  %cond5789 = icmp ne i64 %cv5788, 0
  br i1 %cond5789, label %bb_rcgnn1200, label %bb_rcgdone1200
bb_rcgnn1200:
  %v5790 = load i64, ptr %slot749, align 8
  %op5791 = sub i64 %v5790, 16
  store i64 %op5791, ptr %slot751, align 8
  %v5792 = load i64, ptr %slot749, align 8
  %p5793 = inttoptr i64 %v5792 to ptr
  %rgep5794 = getelementptr i8, ptr %p5793, i64 -16
  %ld5795 = load i64, ptr %rgep5794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5795, ptr %slot752, align 8
  %v5796 = load i64, ptr %slot752, align 8
  %op5797 = and i64 %v5796, 4611686018427387906
  store i64 %op5797, ptr %slot753, align 8
  %v5798 = load i64, ptr %slot753, align 8
  %cmp5799 = icmp ne i64 %v5798, 0
  %cv5800 = zext i1 %cmp5799 to i32
  store i32 %cv5800, ptr %slot754, align 8
  %v5801 = load i32, ptr %slot754, align 8
  %cv5802 = zext i32 %v5801 to i64
  %cond5803 = icmp ne i64 %cv5802, 0
  br i1 %cond5803, label %bb_rcgclear1200, label %bb_rcgcounted1200
bb_rcgcounted1200:
  %v5804 = load i64, ptr %slot749, align 8
  %op5805 = sub i64 %v5804, 24
  store i64 %op5805, ptr %slot755, align 8
  %v5806 = load i64, ptr %slot749, align 8
  %p5807 = inttoptr i64 %v5806 to ptr
  %rgep5808 = getelementptr i8, ptr %p5807, i64 -24
  %ld5809 = load i64, ptr %rgep5808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5809, ptr %slot756, align 8
  %v5810 = load i64, ptr %slot756, align 8
  %op5811 = sub i64 %v5810, 1
  store i64 %op5811, ptr %slot757, align 8
  %v5812 = load i64, ptr %slot757, align 8
  %cmp5813 = icmp eq i64 %v5812, 0
  %cv5814 = zext i1 %cmp5813 to i32
  store i32 %cv5814, ptr %slot758, align 8
  %v5815 = load i32, ptr %slot758, align 8
  %cv5816 = zext i32 %v5815 to i64
  %cond5817 = icmp ne i64 %cv5816, 0
  br i1 %cond5817, label %bb_rcglast1200, label %bb_rcgdec1200
bb_rcglast1200:
  %v5818 = load i64, ptr %slot749, align 8
  %op5819 = sub i64 %v5818, 32
  store i64 %op5819, ptr %slot759, align 8
  %v5820 = load i64, ptr %slot749, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  %rgep5822 = getelementptr i8, ptr %p5821, i64 -32
  %ld5823 = load i64, ptr %rgep5822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5823, ptr %slot760, align 8
  %v5824 = load i64, ptr %slot760, align 8
  %cmp5825 = icmp ne i64 %v5824, 0
  %cv5826 = zext i1 %cmp5825 to i32
  store i32 %cv5826, ptr %slot761, align 8
  %v5827 = load i32, ptr %slot761, align 8
  %cv5828 = zext i32 %v5827 to i64
  %cond5829 = icmp ne i64 %cv5828, 0
  br i1 %cond5829, label %bb_rcgdec1200, label %bb_rcgslow1200
bb_rcgslow1200:
  %v5830 = load i64, ptr %slot748, align 8
  %v5831 = load i64, ptr %slot745, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5830, i64 %v5831) nomerge, !dbg !164
  br label %bb_rcgdone1200
bb_rcgdec1200:
  %v5832 = load i64, ptr %slot757, align 8
  %v5833 = load i64, ptr %slot749, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  %rgep5835 = getelementptr i8, ptr %p5834, i64 -24
  store i64 %v5832, ptr %rgep5835, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1200
bb_rcgclear1200:
  %v5836 = load i64, ptr %slot745, align 8
  %p5837 = inttoptr i64 %v5836 to ptr
  store i64 0, ptr %p5837, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1200
bb_rcgdone1200:
  br label %bb_rcslotdone1184
bb_rcslotowner1184:
  %v5838 = load i64, ptr %slot63, align 8
  store i64 %v5838, ptr %slot762, align 8
  %v5839 = load i64, ptr %slot745, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  %ld5841 = load i64, ptr %p5840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5841, ptr %slot763, align 8
  %v5842 = load i64, ptr %slot763, align 8
  %cmp5843 = icmp ne i64 %v5842, 0
  %cv5844 = zext i1 %cmp5843 to i32
  store i32 %cv5844, ptr %slot764, align 8
  %v5845 = load i32, ptr %slot764, align 8
  %cv5846 = zext i32 %v5845 to i64
  %cond5847 = icmp ne i64 %cv5846, 0
  br i1 %cond5847, label %bb_rcgnn1215, label %bb_rcgdone1215
bb_rcgnn1215:
  %v5848 = load i64, ptr %slot763, align 8
  %op5849 = sub i64 %v5848, 16
  store i64 %op5849, ptr %slot765, align 8
  %v5850 = load i64, ptr %slot763, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  %rgep5852 = getelementptr i8, ptr %p5851, i64 -16
  %ld5853 = load i64, ptr %rgep5852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5853, ptr %slot766, align 8
  %v5854 = load i64, ptr %slot766, align 8
  %op5855 = and i64 %v5854, 4611686018427387906
  store i64 %op5855, ptr %slot767, align 8
  %v5856 = load i64, ptr %slot767, align 8
  %cmp5857 = icmp ne i64 %v5856, 0
  %cv5858 = zext i1 %cmp5857 to i32
  store i32 %cv5858, ptr %slot768, align 8
  %v5859 = load i32, ptr %slot768, align 8
  %cv5860 = zext i32 %v5859 to i64
  %cond5861 = icmp ne i64 %cv5860, 0
  br i1 %cond5861, label %bb_rcgclear1215, label %bb_rcgcounted1215
bb_rcgcounted1215:
  %v5862 = load i64, ptr %slot763, align 8
  %op5863 = sub i64 %v5862, 32
  store i64 %op5863, ptr %slot769, align 8
  %v5864 = load i64, ptr %slot763, align 8
  %p5865 = inttoptr i64 %v5864 to ptr
  %rgep5866 = getelementptr i8, ptr %p5865, i64 -32
  %ld5867 = load i64, ptr %rgep5866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5867, ptr %slot770, align 8
  %v5868 = load i64, ptr %slot770, align 8
  %op5869 = sub i64 %v5868, 1
  store i64 %op5869, ptr %slot771, align 8
  %v5870 = load i64, ptr %slot771, align 8
  %cmp5871 = icmp eq i64 %v5870, 0
  %cv5872 = zext i1 %cmp5871 to i32
  store i32 %cv5872, ptr %slot772, align 8
  %v5873 = load i32, ptr %slot772, align 8
  %cv5874 = zext i32 %v5873 to i64
  %cond5875 = icmp ne i64 %cv5874, 0
  br i1 %cond5875, label %bb_rcglast1215, label %bb_rcgdec1215
bb_rcglast1215:
  %v5876 = load i64, ptr %slot763, align 8
  %op5877 = sub i64 %v5876, 24
  store i64 %op5877, ptr %slot773, align 8
  %v5878 = load i64, ptr %slot763, align 8
  %p5879 = inttoptr i64 %v5878 to ptr
  %rgep5880 = getelementptr i8, ptr %p5879, i64 -24
  %ld5881 = load i64, ptr %rgep5880, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5881, ptr %slot774, align 8
  %v5882 = load i64, ptr %slot774, align 8
  %cmp5883 = icmp ne i64 %v5882, 0
  %cv5884 = zext i1 %cmp5883 to i32
  store i32 %cv5884, ptr %slot775, align 8
  %v5885 = load i32, ptr %slot775, align 8
  %cv5886 = zext i32 %v5885 to i64
  %cond5887 = icmp ne i64 %cv5886, 0
  br i1 %cond5887, label %bb_rcgdec1215, label %bb_rcgslow1215
bb_rcgslow1215:
  %v5888 = load i64, ptr %slot762, align 8
  %v5889 = load i64, ptr %slot745, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5888, i64 %v5889) nomerge, !dbg !164
  br label %bb_rcgdone1215
bb_rcgdec1215:
  %v5890 = load i64, ptr %slot771, align 8
  %v5891 = load i64, ptr %slot763, align 8
  %p5892 = inttoptr i64 %v5891 to ptr
  %rgep5893 = getelementptr i8, ptr %p5892, i64 -32
  store i64 %v5890, ptr %rgep5893, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1215
bb_rcgclear1215:
  %v5894 = load i64, ptr %slot745, align 8
  %p5895 = inttoptr i64 %v5894 to ptr
  store i64 0, ptr %p5895, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1215
bb_rcgdone1215:
  br label %bb_rcslotdone1184
bb_rcslotdone1184:
  %v5896 = load i64, ptr %slot11, align 8
  %p5897 = inttoptr i64 %v5896 to ptr
  %ld5898 = load i32, ptr %p5897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5898, ptr %slot776, align 8
  %v5899 = load i32, ptr %slot776, align 8
  %cv5900 = zext i32 %v5899 to i64
  %cond5901 = icmp ne i64 %cv5900, 0
  br i1 %cond5901, label %bb_rcslotdrop1221, label %bb_rcslotdone1221
bb_rcslotdrop1221:
  %v5902 = load i64, ptr %slot11, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  store i32 0, ptr %p5903, align 4, !alias.scope !3, !noalias !4
  %v5904 = load i64, ptr %slot41, align 8
  store i64 %v5904, ptr %slot777, align 8
  %v5905 = load i64, ptr %slot12, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  %ld5907 = load i32, ptr %p5906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5907, ptr %slot778, align 8
  %v5908 = load i32, ptr %slot778, align 8
  %op5909 = and i32 %v5908, 28
  store i32 %op5909, ptr %slot779, align 8
  %v5910 = load i32, ptr %slot779, align 8
  %cv5911 = zext i32 %v5910 to i64
  %cond5912 = icmp ne i64 %cv5911, 0
  br i1 %cond5912, label %bb_rcslotrole1221, label %bb_rcslotowner1221
bb_rcslotrole1221:
  %v5913 = load i64, ptr %slot63, align 8
  store i64 %v5913, ptr %slot780, align 8
  %v5914 = load i64, ptr %slot777, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  %ld5916 = load i64, ptr %p5915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5916, ptr %slot781, align 8
  %v5917 = load i64, ptr %slot781, align 8
  %cmp5918 = icmp ne i64 %v5917, 0
  %cv5919 = zext i1 %cmp5918 to i32
  store i32 %cv5919, ptr %slot782, align 8
  %v5920 = load i32, ptr %slot782, align 8
  %cv5921 = zext i32 %v5920 to i64
  %cond5922 = icmp ne i64 %cv5921, 0
  br i1 %cond5922, label %bb_rcgnn1237, label %bb_rcgdone1237
bb_rcgnn1237:
  %v5923 = load i64, ptr %slot781, align 8
  %op5924 = sub i64 %v5923, 16
  store i64 %op5924, ptr %slot783, align 8
  %v5925 = load i64, ptr %slot781, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %rgep5927 = getelementptr i8, ptr %p5926, i64 -16
  %ld5928 = load i64, ptr %rgep5927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5928, ptr %slot784, align 8
  %v5929 = load i64, ptr %slot784, align 8
  %op5930 = and i64 %v5929, 4611686018427387906
  store i64 %op5930, ptr %slot785, align 8
  %v5931 = load i64, ptr %slot785, align 8
  %cmp5932 = icmp ne i64 %v5931, 0
  %cv5933 = zext i1 %cmp5932 to i32
  store i32 %cv5933, ptr %slot786, align 8
  %v5934 = load i32, ptr %slot786, align 8
  %cv5935 = zext i32 %v5934 to i64
  %cond5936 = icmp ne i64 %cv5935, 0
  br i1 %cond5936, label %bb_rcgclear1237, label %bb_rcgcounted1237
bb_rcgcounted1237:
  %v5937 = load i64, ptr %slot781, align 8
  %op5938 = sub i64 %v5937, 24
  store i64 %op5938, ptr %slot787, align 8
  %v5939 = load i64, ptr %slot781, align 8
  %p5940 = inttoptr i64 %v5939 to ptr
  %rgep5941 = getelementptr i8, ptr %p5940, i64 -24
  %ld5942 = load i64, ptr %rgep5941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5942, ptr %slot788, align 8
  %v5943 = load i64, ptr %slot788, align 8
  %op5944 = sub i64 %v5943, 1
  store i64 %op5944, ptr %slot789, align 8
  %v5945 = load i64, ptr %slot789, align 8
  %cmp5946 = icmp eq i64 %v5945, 0
  %cv5947 = zext i1 %cmp5946 to i32
  store i32 %cv5947, ptr %slot790, align 8
  %v5948 = load i32, ptr %slot790, align 8
  %cv5949 = zext i32 %v5948 to i64
  %cond5950 = icmp ne i64 %cv5949, 0
  br i1 %cond5950, label %bb_rcglast1237, label %bb_rcgdec1237
bb_rcglast1237:
  %v5951 = load i64, ptr %slot781, align 8
  %op5952 = sub i64 %v5951, 32
  store i64 %op5952, ptr %slot791, align 8
  %v5953 = load i64, ptr %slot781, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  %rgep5955 = getelementptr i8, ptr %p5954, i64 -32
  %ld5956 = load i64, ptr %rgep5955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5956, ptr %slot792, align 8
  %v5957 = load i64, ptr %slot792, align 8
  %cmp5958 = icmp ne i64 %v5957, 0
  %cv5959 = zext i1 %cmp5958 to i32
  store i32 %cv5959, ptr %slot793, align 8
  %v5960 = load i32, ptr %slot793, align 8
  %cv5961 = zext i32 %v5960 to i64
  %cond5962 = icmp ne i64 %cv5961, 0
  br i1 %cond5962, label %bb_rcgdec1237, label %bb_rcgslow1237
bb_rcgslow1237:
  %v5963 = load i64, ptr %slot780, align 8
  %v5964 = load i64, ptr %slot777, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5963, i64 %v5964) nomerge, !dbg !164
  br label %bb_rcgdone1237
bb_rcgdec1237:
  %v5965 = load i64, ptr %slot789, align 8
  %v5966 = load i64, ptr %slot781, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  %rgep5968 = getelementptr i8, ptr %p5967, i64 -24
  store i64 %v5965, ptr %rgep5968, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1237
bb_rcgclear1237:
  %v5969 = load i64, ptr %slot777, align 8
  %p5970 = inttoptr i64 %v5969 to ptr
  store i64 0, ptr %p5970, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1237
bb_rcgdone1237:
  br label %bb_rcslotdone1221
bb_rcslotowner1221:
  %v5971 = load i64, ptr %slot63, align 8
  store i64 %v5971, ptr %slot794, align 8
  %v5972 = load i64, ptr %slot777, align 8
  %p5973 = inttoptr i64 %v5972 to ptr
  %ld5974 = load i64, ptr %p5973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5974, ptr %slot795, align 8
  %v5975 = load i64, ptr %slot795, align 8
  %cmp5976 = icmp ne i64 %v5975, 0
  %cv5977 = zext i1 %cmp5976 to i32
  store i32 %cv5977, ptr %slot796, align 8
  %v5978 = load i32, ptr %slot796, align 8
  %cv5979 = zext i32 %v5978 to i64
  %cond5980 = icmp ne i64 %cv5979, 0
  br i1 %cond5980, label %bb_rcgnn1252, label %bb_rcgdone1252
bb_rcgnn1252:
  %v5981 = load i64, ptr %slot795, align 8
  %op5982 = sub i64 %v5981, 16
  store i64 %op5982, ptr %slot797, align 8
  %v5983 = load i64, ptr %slot795, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %rgep5985 = getelementptr i8, ptr %p5984, i64 -16
  %ld5986 = load i64, ptr %rgep5985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5986, ptr %slot798, align 8
  %v5987 = load i64, ptr %slot798, align 8
  %op5988 = and i64 %v5987, 4611686018427387906
  store i64 %op5988, ptr %slot799, align 8
  %v5989 = load i64, ptr %slot799, align 8
  %cmp5990 = icmp ne i64 %v5989, 0
  %cv5991 = zext i1 %cmp5990 to i32
  store i32 %cv5991, ptr %slot800, align 8
  %v5992 = load i32, ptr %slot800, align 8
  %cv5993 = zext i32 %v5992 to i64
  %cond5994 = icmp ne i64 %cv5993, 0
  br i1 %cond5994, label %bb_rcgclear1252, label %bb_rcgcounted1252
bb_rcgcounted1252:
  %v5995 = load i64, ptr %slot795, align 8
  %op5996 = sub i64 %v5995, 32
  store i64 %op5996, ptr %slot801, align 8
  %v5997 = load i64, ptr %slot795, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %rgep5999 = getelementptr i8, ptr %p5998, i64 -32
  %ld6000 = load i64, ptr %rgep5999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6000, ptr %slot802, align 8
  %v6001 = load i64, ptr %slot802, align 8
  %op6002 = sub i64 %v6001, 1
  store i64 %op6002, ptr %slot803, align 8
  %v6003 = load i64, ptr %slot803, align 8
  %cmp6004 = icmp eq i64 %v6003, 0
  %cv6005 = zext i1 %cmp6004 to i32
  store i32 %cv6005, ptr %slot804, align 8
  %v6006 = load i32, ptr %slot804, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcglast1252, label %bb_rcgdec1252
bb_rcglast1252:
  %v6009 = load i64, ptr %slot795, align 8
  %op6010 = sub i64 %v6009, 24
  store i64 %op6010, ptr %slot805, align 8
  %v6011 = load i64, ptr %slot795, align 8
  %p6012 = inttoptr i64 %v6011 to ptr
  %rgep6013 = getelementptr i8, ptr %p6012, i64 -24
  %ld6014 = load i64, ptr %rgep6013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6014, ptr %slot806, align 8
  %v6015 = load i64, ptr %slot806, align 8
  %cmp6016 = icmp ne i64 %v6015, 0
  %cv6017 = zext i1 %cmp6016 to i32
  store i32 %cv6017, ptr %slot807, align 8
  %v6018 = load i32, ptr %slot807, align 8
  %cv6019 = zext i32 %v6018 to i64
  %cond6020 = icmp ne i64 %cv6019, 0
  br i1 %cond6020, label %bb_rcgdec1252, label %bb_rcgslow1252
bb_rcgslow1252:
  %v6021 = load i64, ptr %slot794, align 8
  %v6022 = load i64, ptr %slot777, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6021, i64 %v6022) nomerge, !dbg !164
  br label %bb_rcgdone1252
bb_rcgdec1252:
  %v6023 = load i64, ptr %slot803, align 8
  %v6024 = load i64, ptr %slot795, align 8
  %p6025 = inttoptr i64 %v6024 to ptr
  %rgep6026 = getelementptr i8, ptr %p6025, i64 -32
  store i64 %v6023, ptr %rgep6026, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1252
bb_rcgclear1252:
  %v6027 = load i64, ptr %slot777, align 8
  %p6028 = inttoptr i64 %v6027 to ptr
  store i64 0, ptr %p6028, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1252
bb_rcgdone1252:
  br label %bb_rcslotdone1221
bb_rcslotdone1221:
  %v6029 = load i64, ptr %slot9, align 8
  %p6030 = inttoptr i64 %v6029 to ptr
  %ld6031 = load i32, ptr %p6030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6031, ptr %slot808, align 8
  %v6032 = load i32, ptr %slot808, align 8
  %cv6033 = zext i32 %v6032 to i64
  %cond6034 = icmp ne i64 %cv6033, 0
  br i1 %cond6034, label %bb_rcslotdrop1258, label %bb_rcslotdone1258
bb_rcslotdrop1258:
  %v6035 = load i64, ptr %slot9, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  store i32 0, ptr %p6036, align 4, !alias.scope !3, !noalias !4
  %v6037 = load i64, ptr %slot40, align 8
  store i64 %v6037, ptr %slot809, align 8
  %v6038 = load i64, ptr %slot10, align 8
  %p6039 = inttoptr i64 %v6038 to ptr
  %ld6040 = load i32, ptr %p6039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6040, ptr %slot810, align 8
  %v6041 = load i32, ptr %slot810, align 8
  %op6042 = and i32 %v6041, 28
  store i32 %op6042, ptr %slot811, align 8
  %v6043 = load i32, ptr %slot811, align 8
  %cv6044 = zext i32 %v6043 to i64
  %cond6045 = icmp ne i64 %cv6044, 0
  br i1 %cond6045, label %bb_rcslotrole1258, label %bb_rcslotowner1258
bb_rcslotrole1258:
  %v6046 = load i64, ptr %slot63, align 8
  store i64 %v6046, ptr %slot812, align 8
  %v6047 = load i64, ptr %slot809, align 8
  %p6048 = inttoptr i64 %v6047 to ptr
  %ld6049 = load i64, ptr %p6048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6049, ptr %slot813, align 8
  %v6050 = load i64, ptr %slot813, align 8
  %cmp6051 = icmp ne i64 %v6050, 0
  %cv6052 = zext i1 %cmp6051 to i32
  store i32 %cv6052, ptr %slot814, align 8
  %v6053 = load i32, ptr %slot814, align 8
  %cv6054 = zext i32 %v6053 to i64
  %cond6055 = icmp ne i64 %cv6054, 0
  br i1 %cond6055, label %bb_rcgnn1274, label %bb_rcgdone1274
bb_rcgnn1274:
  %v6056 = load i64, ptr %slot813, align 8
  %op6057 = sub i64 %v6056, 16
  store i64 %op6057, ptr %slot815, align 8
  %v6058 = load i64, ptr %slot813, align 8
  %p6059 = inttoptr i64 %v6058 to ptr
  %rgep6060 = getelementptr i8, ptr %p6059, i64 -16
  %ld6061 = load i64, ptr %rgep6060, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6061, ptr %slot816, align 8
  %v6062 = load i64, ptr %slot816, align 8
  %op6063 = and i64 %v6062, 4611686018427387906
  store i64 %op6063, ptr %slot817, align 8
  %v6064 = load i64, ptr %slot817, align 8
  %cmp6065 = icmp ne i64 %v6064, 0
  %cv6066 = zext i1 %cmp6065 to i32
  store i32 %cv6066, ptr %slot818, align 8
  %v6067 = load i32, ptr %slot818, align 8
  %cv6068 = zext i32 %v6067 to i64
  %cond6069 = icmp ne i64 %cv6068, 0
  br i1 %cond6069, label %bb_rcgclear1274, label %bb_rcgcounted1274
bb_rcgcounted1274:
  %v6070 = load i64, ptr %slot813, align 8
  %op6071 = sub i64 %v6070, 24
  store i64 %op6071, ptr %slot819, align 8
  %v6072 = load i64, ptr %slot813, align 8
  %p6073 = inttoptr i64 %v6072 to ptr
  %rgep6074 = getelementptr i8, ptr %p6073, i64 -24
  %ld6075 = load i64, ptr %rgep6074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6075, ptr %slot820, align 8
  %v6076 = load i64, ptr %slot820, align 8
  %op6077 = sub i64 %v6076, 1
  store i64 %op6077, ptr %slot821, align 8
  %v6078 = load i64, ptr %slot821, align 8
  %cmp6079 = icmp eq i64 %v6078, 0
  %cv6080 = zext i1 %cmp6079 to i32
  store i32 %cv6080, ptr %slot822, align 8
  %v6081 = load i32, ptr %slot822, align 8
  %cv6082 = zext i32 %v6081 to i64
  %cond6083 = icmp ne i64 %cv6082, 0
  br i1 %cond6083, label %bb_rcglast1274, label %bb_rcgdec1274
bb_rcglast1274:
  %v6084 = load i64, ptr %slot813, align 8
  %op6085 = sub i64 %v6084, 32
  store i64 %op6085, ptr %slot823, align 8
  %v6086 = load i64, ptr %slot813, align 8
  %p6087 = inttoptr i64 %v6086 to ptr
  %rgep6088 = getelementptr i8, ptr %p6087, i64 -32
  %ld6089 = load i64, ptr %rgep6088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6089, ptr %slot824, align 8
  %v6090 = load i64, ptr %slot824, align 8
  %cmp6091 = icmp ne i64 %v6090, 0
  %cv6092 = zext i1 %cmp6091 to i32
  store i32 %cv6092, ptr %slot825, align 8
  %v6093 = load i32, ptr %slot825, align 8
  %cv6094 = zext i32 %v6093 to i64
  %cond6095 = icmp ne i64 %cv6094, 0
  br i1 %cond6095, label %bb_rcgdec1274, label %bb_rcgslow1274
bb_rcgslow1274:
  %v6096 = load i64, ptr %slot812, align 8
  %v6097 = load i64, ptr %slot809, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v6096, i64 %v6097) nomerge, !dbg !164
  br label %bb_rcgdone1274
bb_rcgdec1274:
  %v6098 = load i64, ptr %slot821, align 8
  %v6099 = load i64, ptr %slot813, align 8
  %p6100 = inttoptr i64 %v6099 to ptr
  %rgep6101 = getelementptr i8, ptr %p6100, i64 -24
  store i64 %v6098, ptr %rgep6101, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1274
bb_rcgclear1274:
  %v6102 = load i64, ptr %slot809, align 8
  %p6103 = inttoptr i64 %v6102 to ptr
  store i64 0, ptr %p6103, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1274
bb_rcgdone1274:
  br label %bb_rcslotdone1258
bb_rcslotowner1258:
  %v6104 = load i64, ptr %slot63, align 8
  store i64 %v6104, ptr %slot826, align 8
  %v6105 = load i64, ptr %slot809, align 8
  %p6106 = inttoptr i64 %v6105 to ptr
  %ld6107 = load i64, ptr %p6106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6107, ptr %slot827, align 8
  %v6108 = load i64, ptr %slot827, align 8
  %cmp6109 = icmp ne i64 %v6108, 0
  %cv6110 = zext i1 %cmp6109 to i32
  store i32 %cv6110, ptr %slot828, align 8
  %v6111 = load i32, ptr %slot828, align 8
  %cv6112 = zext i32 %v6111 to i64
  %cond6113 = icmp ne i64 %cv6112, 0
  br i1 %cond6113, label %bb_rcgnn1289, label %bb_rcgdone1289
bb_rcgnn1289:
  %v6114 = load i64, ptr %slot827, align 8
  %op6115 = sub i64 %v6114, 16
  store i64 %op6115, ptr %slot829, align 8
  %v6116 = load i64, ptr %slot827, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  %rgep6118 = getelementptr i8, ptr %p6117, i64 -16
  %ld6119 = load i64, ptr %rgep6118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6119, ptr %slot830, align 8
  %v6120 = load i64, ptr %slot830, align 8
  %op6121 = and i64 %v6120, 4611686018427387906
  store i64 %op6121, ptr %slot831, align 8
  %v6122 = load i64, ptr %slot831, align 8
  %cmp6123 = icmp ne i64 %v6122, 0
  %cv6124 = zext i1 %cmp6123 to i32
  store i32 %cv6124, ptr %slot832, align 8
  %v6125 = load i32, ptr %slot832, align 8
  %cv6126 = zext i32 %v6125 to i64
  %cond6127 = icmp ne i64 %cv6126, 0
  br i1 %cond6127, label %bb_rcgclear1289, label %bb_rcgcounted1289
bb_rcgcounted1289:
  %v6128 = load i64, ptr %slot827, align 8
  %op6129 = sub i64 %v6128, 32
  store i64 %op6129, ptr %slot833, align 8
  %v6130 = load i64, ptr %slot827, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  %rgep6132 = getelementptr i8, ptr %p6131, i64 -32
  %ld6133 = load i64, ptr %rgep6132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6133, ptr %slot834, align 8
  %v6134 = load i64, ptr %slot834, align 8
  %op6135 = sub i64 %v6134, 1
  store i64 %op6135, ptr %slot835, align 8
  %v6136 = load i64, ptr %slot835, align 8
  %cmp6137 = icmp eq i64 %v6136, 0
  %cv6138 = zext i1 %cmp6137 to i32
  store i32 %cv6138, ptr %slot836, align 8
  %v6139 = load i32, ptr %slot836, align 8
  %cv6140 = zext i32 %v6139 to i64
  %cond6141 = icmp ne i64 %cv6140, 0
  br i1 %cond6141, label %bb_rcglast1289, label %bb_rcgdec1289
bb_rcglast1289:
  %v6142 = load i64, ptr %slot827, align 8
  %op6143 = sub i64 %v6142, 24
  store i64 %op6143, ptr %slot837, align 8
  %v6144 = load i64, ptr %slot827, align 8
  %p6145 = inttoptr i64 %v6144 to ptr
  %rgep6146 = getelementptr i8, ptr %p6145, i64 -24
  %ld6147 = load i64, ptr %rgep6146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6147, ptr %slot838, align 8
  %v6148 = load i64, ptr %slot838, align 8
  %cmp6149 = icmp ne i64 %v6148, 0
  %cv6150 = zext i1 %cmp6149 to i32
  store i32 %cv6150, ptr %slot839, align 8
  %v6151 = load i32, ptr %slot839, align 8
  %cv6152 = zext i32 %v6151 to i64
  %cond6153 = icmp ne i64 %cv6152, 0
  br i1 %cond6153, label %bb_rcgdec1289, label %bb_rcgslow1289
bb_rcgslow1289:
  %v6154 = load i64, ptr %slot826, align 8
  %v6155 = load i64, ptr %slot809, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6154, i64 %v6155) nomerge, !dbg !164
  br label %bb_rcgdone1289
bb_rcgdec1289:
  %v6156 = load i64, ptr %slot835, align 8
  %v6157 = load i64, ptr %slot827, align 8
  %p6158 = inttoptr i64 %v6157 to ptr
  %rgep6159 = getelementptr i8, ptr %p6158, i64 -32
  store i64 %v6156, ptr %rgep6159, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1289
bb_rcgclear1289:
  %v6160 = load i64, ptr %slot809, align 8
  %p6161 = inttoptr i64 %v6160 to ptr
  store i64 0, ptr %p6161, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1289
bb_rcgdone1289:
  br label %bb_rcslotdone1258
bb_rcslotdone1258:
  %v6162 = load i64, ptr %slot7, align 8
  %p6163 = inttoptr i64 %v6162 to ptr
  %ld6164 = load i32, ptr %p6163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6164, ptr %slot840, align 8
  %v6165 = load i32, ptr %slot840, align 8
  %cv6166 = zext i32 %v6165 to i64
  %cond6167 = icmp ne i64 %cv6166, 0
  br i1 %cond6167, label %bb_rcslotdrop1313, label %bb_rcslotdone1313
bb_rcslotdrop1313:
  %v6168 = load i64, ptr %slot7, align 8
  %p6169 = inttoptr i64 %v6168 to ptr
  store i32 0, ptr %p6169, align 4, !alias.scope !3, !noalias !4
  %v6170 = load i64, ptr %slot38, align 8
  store i64 %v6170, ptr %slot841, align 8
  %v6171 = load i64, ptr %slot8, align 8
  %p6172 = inttoptr i64 %v6171 to ptr
  %ld6173 = load i32, ptr %p6172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6173, ptr %slot842, align 8
  %v6174 = load i32, ptr %slot842, align 8
  %op6175 = and i32 %v6174, 28
  store i32 %op6175, ptr %slot843, align 8
  %v6176 = load i32, ptr %slot843, align 8
  %cv6177 = zext i32 %v6176 to i64
  %cond6178 = icmp ne i64 %cv6177, 0
  br i1 %cond6178, label %bb_rcslotrole1313, label %bb_rcslotowner1313
bb_rcslotrole1313:
  %v6179 = load i64, ptr %slot63, align 8
  store i64 %v6179, ptr %slot844, align 8
  %v6180 = load i64, ptr %slot844, align 8
  %v6181 = load i64, ptr %slot841, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6180, i64 %v6181) nomerge, !dbg !164
  br label %bb_rcslotdone1313
bb_rcslotowner1313:
  %v6182 = load i64, ptr %slot63, align 8
  store i64 %v6182, ptr %slot845, align 8
  %v6183 = load i64, ptr %slot845, align 8
  %v6184 = load i64, ptr %slot841, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6183, i64 %v6184) nomerge, !dbg !164
  br label %bb_rcslotdone1313
bb_rcslotdone1313:
  %v6185 = load i64, ptr %slot731, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6186, i64 24, i1 false)
  ret void
bb_i91:
  %v6187 = load i64, ptr %slot26, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i64, ptr %p6188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6189, ptr %slot846, align 8
  %v6190 = load i64, ptr %slot846, align 8
  %v6191 = load i64, ptr %slot44, align 8
  %p6192 = inttoptr i64 %v6191 to ptr
  store i64 %v6190, ptr %p6192, align 8, !alias.scope !3, !noalias !4
  %v6193 = load i64, ptr %slot32, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  %ld6195 = load i64, ptr %p6194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6195, ptr %slot847, align 8
  %v6196 = load i64, ptr %slot847, align 8
  %v6197 = load i64, ptr %slot45, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  store i64 %v6196, ptr %p6198, align 8, !alias.scope !3, !noalias !4
  %v6199 = load i64, ptr %slot27, align 8
  %p6200 = inttoptr i64 %v6199 to ptr
  %ld6201 = load i64, ptr %p6200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6201, ptr %slot848, align 8
  %v6202 = load i64, ptr %slot848, align 8
  %v6203 = load i64, ptr %slot46, align 8
  %p6204 = inttoptr i64 %v6203 to ptr
  store i64 %v6202, ptr %p6204, align 8, !alias.scope !3, !noalias !4
  %v6205 = load i64, ptr %slot28, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  %ld6207 = load i64, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6207, ptr %slot849, align 8
  %v6208 = load i64, ptr %slot849, align 8
  %v6209 = load i64, ptr %slot47, align 8
  %p6210 = inttoptr i64 %v6209 to ptr
  store i64 %v6208, ptr %p6210, align 8, !alias.scope !3, !noalias !4
  %v6211 = load i64, ptr %slot44, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %ld6213 = load i64, ptr %p6212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6213, ptr %slot850, align 8
  %v6214 = load i64, ptr %slot45, align 8
  %p6215 = inttoptr i64 %v6214 to ptr
  %ld6216 = load i64, ptr %p6215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6216, ptr %slot851, align 8
  %v6217 = load i64, ptr %slot46, align 8
  %p6218 = inttoptr i64 %v6217 to ptr
  %ld6219 = load i64, ptr %p6218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6219, ptr %slot852, align 8
  %v6220 = load i64, ptr %slot47, align 8
  %p6221 = inttoptr i64 %v6220 to ptr
  %ld6222 = load i64, ptr %p6221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6222, ptr %slot853, align 8
  %v6223 = load i64, ptr %slot1, align 8
  %v6224 = load i64, ptr %slot850, align 8
  %v6225 = load i64, ptr %slot851, align 8
  %v6226 = load i64, ptr %slot852, align 8
  %v6227 = load i64, ptr %slot853, align 8
  call void @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd(ptr sret([24 x i8]) align 8 %callresult855, i64 %v6223, i64 %v6224, i64 %v6225, i64 %v6226, i64 %v6227) nomerge, !dbg !166
  %addr6228 = ptrtoint ptr %callresult855 to i64
  store i64 %addr6228, ptr %slot854, align 8
  %v6229 = load i64, ptr %slot854, align 8
  %v6230 = load i64, ptr %slot44, align 8
  %p6231 = inttoptr i64 %v6230 to ptr
  store i64 %v6229, ptr %p6231, align 8, !alias.scope !3, !noalias !4
  %v6232 = load i64, ptr %slot44, align 8
  %p6233 = inttoptr i64 %v6232 to ptr
  %ld6234 = load i64, ptr %p6233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6234, ptr %slot856, align 8
  %v6235 = load i64, ptr %slot24, align 8
  store i64 %v6235, ptr %slot857, align 8
  %v6236 = load i64, ptr %slot856, align 8
  %v6237 = load i64, ptr %slot857, align 8
  %p6238 = inttoptr i64 %v6236 to ptr
  %p6239 = inttoptr i64 %v6237 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6239, ptr %p6238, i64 24, i1 false)
  %v6240 = load i64, ptr %slot20, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  store i32 2, ptr %p6241, align 4, !alias.scope !3, !noalias !4
  %v6242 = load i64, ptr %slot19, align 8
  %p6243 = inttoptr i64 %v6242 to ptr
  store i32 1, ptr %p6243, align 4, !alias.scope !3, !noalias !4
  %v6244 = load i64, ptr %slot17, align 8
  %p6245 = inttoptr i64 %v6244 to ptr
  %ld6246 = load i32, ptr %p6245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6246, ptr %slot858, align 8
  %v6247 = load i32, ptr %slot858, align 8
  %cv6248 = zext i32 %v6247 to i64
  %cond6249 = icmp ne i64 %cv6248, 0
  br i1 %cond6249, label %bb_rcslotdrop1418, label %bb_rcslotdone1418
bb_rcslotdrop1418:
  %v6250 = load i64, ptr %slot17, align 8
  %p6251 = inttoptr i64 %v6250 to ptr
  store i32 0, ptr %p6251, align 4, !alias.scope !3, !noalias !4
  %v6252 = load i64, ptr %slot22, align 8
  store i64 %v6252, ptr %slot859, align 8
  %v6253 = load i64, ptr %slot18, align 8
  %p6254 = inttoptr i64 %v6253 to ptr
  %ld6255 = load i32, ptr %p6254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6255, ptr %slot860, align 8
  %v6256 = load i32, ptr %slot860, align 8
  %op6257 = and i32 %v6256, 28
  store i32 %op6257, ptr %slot861, align 8
  %v6258 = load i32, ptr %slot861, align 8
  %cv6259 = zext i32 %v6258 to i64
  %cond6260 = icmp ne i64 %cv6259, 0
  br i1 %cond6260, label %bb_rcslotrole1418, label %bb_rcslotowner1418
bb_rcslotrole1418:
  %v6261 = load i64, ptr %slot63, align 8
  store i64 %v6261, ptr %slot862, align 8
  %v6262 = load i64, ptr %slot862, align 8
  %v6263 = load i64, ptr %slot859, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v6262, i64 %v6263) nomerge, !dbg !166
  br label %bb_rcslotdone1418
bb_rcslotowner1418:
  %v6264 = load i64, ptr %slot63, align 8
  store i64 %v6264, ptr %slot863, align 8
  %v6265 = load i64, ptr %slot863, align 8
  %v6266 = load i64, ptr %slot859, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v6265, i64 %v6266) nomerge, !dbg !166
  br label %bb_rcslotdone1418
bb_rcslotdone1418:
  %v6267 = load i64, ptr %slot22, align 8
  store i64 %v6267, ptr %slot864, align 8
  %v6268 = load i64, ptr %slot24, align 8
  store i64 %v6268, ptr %slot865, align 8
  %v6269 = load i64, ptr %slot865, align 8
  %v6270 = load i64, ptr %slot864, align 8
  %p6271 = inttoptr i64 %v6269 to ptr
  %p6272 = inttoptr i64 %v6270 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6272, ptr %p6271, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6273 = load i64, ptr %slot18, align 8
  %p6274 = inttoptr i64 %v6273 to ptr
  store i32 2, ptr %p6274, align 4, !alias.scope !3, !noalias !4
  %v6275 = load i64, ptr %slot20, align 8
  %p6276 = inttoptr i64 %v6275 to ptr
  %ld6277 = load i32, ptr %p6276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6277, ptr %slot866, align 8
  %v6278 = load i32, ptr %slot866, align 8
  %v6279 = load i64, ptr %slot18, align 8
  %p6280 = inttoptr i64 %v6279 to ptr
  store i32 %v6278, ptr %p6280, align 4, !alias.scope !3, !noalias !4
  %v6281 = load i64, ptr %slot19, align 8
  %p6282 = inttoptr i64 %v6281 to ptr
  store i32 0, ptr %p6282, align 4, !alias.scope !3, !noalias !4
  %v6283 = load i64, ptr %slot17, align 8
  %p6284 = inttoptr i64 %v6283 to ptr
  store i32 1, ptr %p6284, align 4, !alias.scope !3, !noalias !4
  %v6285 = load i64, ptr %slot864, align 8
  %v6286 = load i64, ptr %slot44, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  store i64 %v6285, ptr %p6287, align 8, !alias.scope !3, !noalias !4
  %v6288 = load i64, ptr %slot44, align 8
  %p6289 = inttoptr i64 %v6288 to ptr
  %ld6290 = load i64, ptr %p6289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6290, ptr %slot867, align 8
  %v6291 = load i64, ptr %slot867, align 8
  %p6292 = inttoptr i64 %v6291 to ptr
  %ld6293 = load i32, ptr %p6292, align 4
  %ext6294 = zext i32 %ld6293 to i64
  store i64 %ext6294, ptr %slot868, align 8
  %v6295 = load i64, ptr %slot868, align 8
  %cmp6296 = icmp eq i64 %v6295, 1
  %cv6297 = zext i1 %cmp6296 to i64
  store i64 %cv6297, ptr %slot869, align 8
  %v6298 = load i64, ptr %slot869, align 8
  %cond6299 = icmp ne i64 %v6298, 0
  br i1 %cond6299, label %bb_errtrace1435, label %bb_errtraced1435
bb_errtrace1435:
  %p6300 = inttoptr i64 ptrtoint (ptr @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p6300, i64 8589934688) "call-inline-cost"="0", !dbg !168
  br label %bb_errtraced1435
bb_errtraced1435:
  %v6301 = load i64, ptr %slot44, align 8
  %p6302 = inttoptr i64 %v6301 to ptr
  %ld6303 = load i64, ptr %p6302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6303, ptr %slot870, align 8
  %v6304 = load i64, ptr %slot24, align 8
  store i64 %v6304, ptr %slot871, align 8
  %v6305 = load i64, ptr %slot64, align 8
  store i64 %v6305, ptr %slot872, align 8
  %v6306 = load i64, ptr %slot63, align 8
  %v6307 = load i64, ptr %slot871, align 8
  %v6308 = load i64, ptr %slot870, align 8
  %v6309 = load i64, ptr %slot872, align 8
  %cv6310 = trunc i64 %v6309 to i32
  %call6311 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v6306, i64 %v6307, i64 %v6308, i32 %cv6310) nomerge, !dbg !168
  store i32 %call6311, ptr %slot873, align 8
  %v6312 = load i32, ptr %slot873, align 8
  %cv6313 = zext i32 %v6312 to i64
  %cond6314 = icmp ne i64 %cv6313, 0
  br i1 %cond6314, label %bb_rcsuccess1440, label %bb_rcfailure1440
bb_rcfailure1440:
  %v6315 = load i64, ptr %slot63, align 8
  %p6316 = inttoptr i64 %v6315 to ptr
  %call6317 = call i32 @myl_rc_take_failure(ptr %p6316) nomerge, !dbg !168
  store i32 %call6317, ptr %slot874, align 8
  %v6318 = load i64, ptr %slot1, align 8
  %p6319 = inttoptr i64 %v6318 to ptr
  %v6320 = load i32, ptr %slot874, align 8
  %call6321 = call i32 @myl_qbe_rc_status(ptr %p6319, i32 %v6320) nomerge, !dbg !168
  store i32 %call6321, ptr %slot875, align 8
  br label %bb_failure
bb_rcsuccess1440:
  %v6322 = load i64, ptr %slot17, align 8
  %p6323 = inttoptr i64 %v6322 to ptr
  store i32 0, ptr %p6323, align 4, !alias.scope !3, !noalias !4
  %v6324 = load i64, ptr %slot20, align 8
  %p6325 = inttoptr i64 %v6324 to ptr
  store i32 2, ptr %p6325, align 4, !alias.scope !3, !noalias !4
  %v6326 = load i64, ptr %slot19, align 8
  %p6327 = inttoptr i64 %v6326 to ptr
  store i32 1, ptr %p6327, align 4, !alias.scope !3, !noalias !4
  %v6328 = load i64, ptr %slot24, align 8
  store i64 %v6328, ptr %slot876, align 8
  %v6329 = load i64, ptr %slot19, align 8
  %p6330 = inttoptr i64 %v6329 to ptr
  store i32 0, ptr %p6330, align 4, !alias.scope !3, !noalias !4
  %v6331 = load i64, ptr %slot17, align 8
  %p6332 = inttoptr i64 %v6331 to ptr
  %ld6333 = load i32, ptr %p6332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6333, ptr %slot877, align 8
  %v6334 = load i32, ptr %slot877, align 8
  %cv6335 = zext i32 %v6334 to i64
  %cond6336 = icmp ne i64 %cv6335, 0
  br i1 %cond6336, label %bb_rcslotdrop1450, label %bb_rcslotdone1450
bb_rcslotdrop1450:
  %v6337 = load i64, ptr %slot17, align 8
  %p6338 = inttoptr i64 %v6337 to ptr
  store i32 0, ptr %p6338, align 4, !alias.scope !3, !noalias !4
  %v6339 = load i64, ptr %slot22, align 8
  store i64 %v6339, ptr %slot878, align 8
  %v6340 = load i64, ptr %slot18, align 8
  %p6341 = inttoptr i64 %v6340 to ptr
  %ld6342 = load i32, ptr %p6341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6342, ptr %slot879, align 8
  %v6343 = load i32, ptr %slot879, align 8
  %op6344 = and i32 %v6343, 28
  store i32 %op6344, ptr %slot880, align 8
  %v6345 = load i32, ptr %slot880, align 8
  %cv6346 = zext i32 %v6345 to i64
  %cond6347 = icmp ne i64 %cv6346, 0
  br i1 %cond6347, label %bb_rcslotrole1450, label %bb_rcslotowner1450
bb_rcslotrole1450:
  %v6348 = load i64, ptr %slot63, align 8
  store i64 %v6348, ptr %slot881, align 8
  %v6349 = load i64, ptr %slot881, align 8
  %v6350 = load i64, ptr %slot878, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6349, i64 %v6350) nomerge, !dbg !168
  br label %bb_rcslotdone1450
bb_rcslotowner1450:
  %v6351 = load i64, ptr %slot63, align 8
  store i64 %v6351, ptr %slot882, align 8
  %v6352 = load i64, ptr %slot882, align 8
  %v6353 = load i64, ptr %slot878, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6352, i64 %v6353) nomerge, !dbg !168
  br label %bb_rcslotdone1450
bb_rcslotdone1450:
  %v6354 = load i64, ptr %slot15, align 8
  %p6355 = inttoptr i64 %v6354 to ptr
  %ld6356 = load i32, ptr %p6355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6356, ptr %slot883, align 8
  %v6357 = load i32, ptr %slot883, align 8
  %cv6358 = zext i32 %v6357 to i64
  %cond6359 = icmp ne i64 %cv6358, 0
  br i1 %cond6359, label %bb_rcslotdrop1477, label %bb_rcslotdone1477
bb_rcslotdrop1477:
  %v6360 = load i64, ptr %slot15, align 8
  %p6361 = inttoptr i64 %v6360 to ptr
  store i32 0, ptr %p6361, align 4, !alias.scope !3, !noalias !4
  %v6362 = load i64, ptr %slot43, align 8
  store i64 %v6362, ptr %slot884, align 8
  %v6363 = load i64, ptr %slot16, align 8
  %p6364 = inttoptr i64 %v6363 to ptr
  %ld6365 = load i32, ptr %p6364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6365, ptr %slot885, align 8
  %v6366 = load i32, ptr %slot885, align 8
  %op6367 = and i32 %v6366, 28
  store i32 %op6367, ptr %slot886, align 8
  %v6368 = load i32, ptr %slot886, align 8
  %cv6369 = zext i32 %v6368 to i64
  %cond6370 = icmp ne i64 %cv6369, 0
  br i1 %cond6370, label %bb_rcslotrole1477, label %bb_rcslotowner1477
bb_rcslotrole1477:
  %v6371 = load i64, ptr %slot63, align 8
  store i64 %v6371, ptr %slot887, align 8
  %v6372 = load i64, ptr %slot887, align 8
  %v6373 = load i64, ptr %slot884, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6372, i64 %v6373) nomerge, !dbg !168
  br label %bb_rcslotdone1477
bb_rcslotowner1477:
  %v6374 = load i64, ptr %slot63, align 8
  store i64 %v6374, ptr %slot888, align 8
  %v6375 = load i64, ptr %slot888, align 8
  %v6376 = load i64, ptr %slot884, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6375, i64 %v6376) nomerge, !dbg !168
  br label %bb_rcslotdone1477
bb_rcslotdone1477:
  %v6377 = load i64, ptr %slot13, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  %ld6379 = load i32, ptr %p6378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6379, ptr %slot889, align 8
  %v6380 = load i32, ptr %slot889, align 8
  %cv6381 = zext i32 %v6380 to i64
  %cond6382 = icmp ne i64 %cv6381, 0
  br i1 %cond6382, label %bb_rcslotdrop1486, label %bb_rcslotdone1486
bb_rcslotdrop1486:
  %v6383 = load i64, ptr %slot13, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  store i32 0, ptr %p6384, align 4, !alias.scope !3, !noalias !4
  %v6385 = load i64, ptr %slot42, align 8
  store i64 %v6385, ptr %slot890, align 8
  %v6386 = load i64, ptr %slot14, align 8
  %p6387 = inttoptr i64 %v6386 to ptr
  %ld6388 = load i32, ptr %p6387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6388, ptr %slot891, align 8
  %v6389 = load i32, ptr %slot891, align 8
  %op6390 = and i32 %v6389, 28
  store i32 %op6390, ptr %slot892, align 8
  %v6391 = load i32, ptr %slot892, align 8
  %cv6392 = zext i32 %v6391 to i64
  %cond6393 = icmp ne i64 %cv6392, 0
  br i1 %cond6393, label %bb_rcslotrole1486, label %bb_rcslotowner1486
bb_rcslotrole1486:
  %v6394 = load i64, ptr %slot63, align 8
  store i64 %v6394, ptr %slot893, align 8
  %v6395 = load i64, ptr %slot890, align 8
  %p6396 = inttoptr i64 %v6395 to ptr
  %ld6397 = load i64, ptr %p6396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6397, ptr %slot894, align 8
  %v6398 = load i64, ptr %slot894, align 8
  %cmp6399 = icmp ne i64 %v6398, 0
  %cv6400 = zext i1 %cmp6399 to i32
  store i32 %cv6400, ptr %slot895, align 8
  %v6401 = load i32, ptr %slot895, align 8
  %cv6402 = zext i32 %v6401 to i64
  %cond6403 = icmp ne i64 %cv6402, 0
  br i1 %cond6403, label %bb_rcgnn1502, label %bb_rcgdone1502
bb_rcgnn1502:
  %v6404 = load i64, ptr %slot894, align 8
  %op6405 = sub i64 %v6404, 16
  store i64 %op6405, ptr %slot896, align 8
  %v6406 = load i64, ptr %slot894, align 8
  %p6407 = inttoptr i64 %v6406 to ptr
  %rgep6408 = getelementptr i8, ptr %p6407, i64 -16
  %ld6409 = load i64, ptr %rgep6408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6409, ptr %slot897, align 8
  %v6410 = load i64, ptr %slot897, align 8
  %op6411 = and i64 %v6410, 4611686018427387906
  store i64 %op6411, ptr %slot898, align 8
  %v6412 = load i64, ptr %slot898, align 8
  %cmp6413 = icmp ne i64 %v6412, 0
  %cv6414 = zext i1 %cmp6413 to i32
  store i32 %cv6414, ptr %slot899, align 8
  %v6415 = load i32, ptr %slot899, align 8
  %cv6416 = zext i32 %v6415 to i64
  %cond6417 = icmp ne i64 %cv6416, 0
  br i1 %cond6417, label %bb_rcgclear1502, label %bb_rcgcounted1502
bb_rcgcounted1502:
  %v6418 = load i64, ptr %slot894, align 8
  %op6419 = sub i64 %v6418, 24
  store i64 %op6419, ptr %slot900, align 8
  %v6420 = load i64, ptr %slot894, align 8
  %p6421 = inttoptr i64 %v6420 to ptr
  %rgep6422 = getelementptr i8, ptr %p6421, i64 -24
  %ld6423 = load i64, ptr %rgep6422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6423, ptr %slot901, align 8
  %v6424 = load i64, ptr %slot901, align 8
  %op6425 = sub i64 %v6424, 1
  store i64 %op6425, ptr %slot902, align 8
  %v6426 = load i64, ptr %slot902, align 8
  %cmp6427 = icmp eq i64 %v6426, 0
  %cv6428 = zext i1 %cmp6427 to i32
  store i32 %cv6428, ptr %slot903, align 8
  %v6429 = load i32, ptr %slot903, align 8
  %cv6430 = zext i32 %v6429 to i64
  %cond6431 = icmp ne i64 %cv6430, 0
  br i1 %cond6431, label %bb_rcglast1502, label %bb_rcgdec1502
bb_rcglast1502:
  %v6432 = load i64, ptr %slot894, align 8
  %op6433 = sub i64 %v6432, 32
  store i64 %op6433, ptr %slot904, align 8
  %v6434 = load i64, ptr %slot894, align 8
  %p6435 = inttoptr i64 %v6434 to ptr
  %rgep6436 = getelementptr i8, ptr %p6435, i64 -32
  %ld6437 = load i64, ptr %rgep6436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6437, ptr %slot905, align 8
  %v6438 = load i64, ptr %slot905, align 8
  %cmp6439 = icmp ne i64 %v6438, 0
  %cv6440 = zext i1 %cmp6439 to i32
  store i32 %cv6440, ptr %slot906, align 8
  %v6441 = load i32, ptr %slot906, align 8
  %cv6442 = zext i32 %v6441 to i64
  %cond6443 = icmp ne i64 %cv6442, 0
  br i1 %cond6443, label %bb_rcgdec1502, label %bb_rcgslow1502
bb_rcgslow1502:
  %v6444 = load i64, ptr %slot893, align 8
  %v6445 = load i64, ptr %slot890, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6444, i64 %v6445) nomerge, !dbg !168
  br label %bb_rcgdone1502
bb_rcgdec1502:
  %v6446 = load i64, ptr %slot902, align 8
  %v6447 = load i64, ptr %slot894, align 8
  %p6448 = inttoptr i64 %v6447 to ptr
  %rgep6449 = getelementptr i8, ptr %p6448, i64 -24
  store i64 %v6446, ptr %rgep6449, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1502
bb_rcgclear1502:
  %v6450 = load i64, ptr %slot890, align 8
  %p6451 = inttoptr i64 %v6450 to ptr
  store i64 0, ptr %p6451, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1502
bb_rcgdone1502:
  br label %bb_rcslotdone1486
bb_rcslotowner1486:
  %v6452 = load i64, ptr %slot63, align 8
  store i64 %v6452, ptr %slot907, align 8
  %v6453 = load i64, ptr %slot890, align 8
  %p6454 = inttoptr i64 %v6453 to ptr
  %ld6455 = load i64, ptr %p6454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6455, ptr %slot908, align 8
  %v6456 = load i64, ptr %slot908, align 8
  %cmp6457 = icmp ne i64 %v6456, 0
  %cv6458 = zext i1 %cmp6457 to i32
  store i32 %cv6458, ptr %slot909, align 8
  %v6459 = load i32, ptr %slot909, align 8
  %cv6460 = zext i32 %v6459 to i64
  %cond6461 = icmp ne i64 %cv6460, 0
  br i1 %cond6461, label %bb_rcgnn1517, label %bb_rcgdone1517
bb_rcgnn1517:
  %v6462 = load i64, ptr %slot908, align 8
  %op6463 = sub i64 %v6462, 16
  store i64 %op6463, ptr %slot910, align 8
  %v6464 = load i64, ptr %slot908, align 8
  %p6465 = inttoptr i64 %v6464 to ptr
  %rgep6466 = getelementptr i8, ptr %p6465, i64 -16
  %ld6467 = load i64, ptr %rgep6466, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6467, ptr %slot911, align 8
  %v6468 = load i64, ptr %slot911, align 8
  %op6469 = and i64 %v6468, 4611686018427387906
  store i64 %op6469, ptr %slot912, align 8
  %v6470 = load i64, ptr %slot912, align 8
  %cmp6471 = icmp ne i64 %v6470, 0
  %cv6472 = zext i1 %cmp6471 to i32
  store i32 %cv6472, ptr %slot913, align 8
  %v6473 = load i32, ptr %slot913, align 8
  %cv6474 = zext i32 %v6473 to i64
  %cond6475 = icmp ne i64 %cv6474, 0
  br i1 %cond6475, label %bb_rcgclear1517, label %bb_rcgcounted1517
bb_rcgcounted1517:
  %v6476 = load i64, ptr %slot908, align 8
  %op6477 = sub i64 %v6476, 32
  store i64 %op6477, ptr %slot914, align 8
  %v6478 = load i64, ptr %slot908, align 8
  %p6479 = inttoptr i64 %v6478 to ptr
  %rgep6480 = getelementptr i8, ptr %p6479, i64 -32
  %ld6481 = load i64, ptr %rgep6480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6481, ptr %slot915, align 8
  %v6482 = load i64, ptr %slot915, align 8
  %op6483 = sub i64 %v6482, 1
  store i64 %op6483, ptr %slot916, align 8
  %v6484 = load i64, ptr %slot916, align 8
  %cmp6485 = icmp eq i64 %v6484, 0
  %cv6486 = zext i1 %cmp6485 to i32
  store i32 %cv6486, ptr %slot917, align 8
  %v6487 = load i32, ptr %slot917, align 8
  %cv6488 = zext i32 %v6487 to i64
  %cond6489 = icmp ne i64 %cv6488, 0
  br i1 %cond6489, label %bb_rcglast1517, label %bb_rcgdec1517
bb_rcglast1517:
  %v6490 = load i64, ptr %slot908, align 8
  %op6491 = sub i64 %v6490, 24
  store i64 %op6491, ptr %slot918, align 8
  %v6492 = load i64, ptr %slot908, align 8
  %p6493 = inttoptr i64 %v6492 to ptr
  %rgep6494 = getelementptr i8, ptr %p6493, i64 -24
  %ld6495 = load i64, ptr %rgep6494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6495, ptr %slot919, align 8
  %v6496 = load i64, ptr %slot919, align 8
  %cmp6497 = icmp ne i64 %v6496, 0
  %cv6498 = zext i1 %cmp6497 to i32
  store i32 %cv6498, ptr %slot920, align 8
  %v6499 = load i32, ptr %slot920, align 8
  %cv6500 = zext i32 %v6499 to i64
  %cond6501 = icmp ne i64 %cv6500, 0
  br i1 %cond6501, label %bb_rcgdec1517, label %bb_rcgslow1517
bb_rcgslow1517:
  %v6502 = load i64, ptr %slot907, align 8
  %v6503 = load i64, ptr %slot890, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6502, i64 %v6503) nomerge, !dbg !168
  br label %bb_rcgdone1517
bb_rcgdec1517:
  %v6504 = load i64, ptr %slot916, align 8
  %v6505 = load i64, ptr %slot908, align 8
  %p6506 = inttoptr i64 %v6505 to ptr
  %rgep6507 = getelementptr i8, ptr %p6506, i64 -32
  store i64 %v6504, ptr %rgep6507, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1517
bb_rcgclear1517:
  %v6508 = load i64, ptr %slot890, align 8
  %p6509 = inttoptr i64 %v6508 to ptr
  store i64 0, ptr %p6509, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1517
bb_rcgdone1517:
  br label %bb_rcslotdone1486
bb_rcslotdone1486:
  %v6510 = load i64, ptr %slot11, align 8
  %p6511 = inttoptr i64 %v6510 to ptr
  %ld6512 = load i32, ptr %p6511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6512, ptr %slot921, align 8
  %v6513 = load i32, ptr %slot921, align 8
  %cv6514 = zext i32 %v6513 to i64
  %cond6515 = icmp ne i64 %cv6514, 0
  br i1 %cond6515, label %bb_rcslotdrop1523, label %bb_rcslotdone1523
bb_rcslotdrop1523:
  %v6516 = load i64, ptr %slot11, align 8
  %p6517 = inttoptr i64 %v6516 to ptr
  store i32 0, ptr %p6517, align 4, !alias.scope !3, !noalias !4
  %v6518 = load i64, ptr %slot41, align 8
  store i64 %v6518, ptr %slot922, align 8
  %v6519 = load i64, ptr %slot12, align 8
  %p6520 = inttoptr i64 %v6519 to ptr
  %ld6521 = load i32, ptr %p6520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6521, ptr %slot923, align 8
  %v6522 = load i32, ptr %slot923, align 8
  %op6523 = and i32 %v6522, 28
  store i32 %op6523, ptr %slot924, align 8
  %v6524 = load i32, ptr %slot924, align 8
  %cv6525 = zext i32 %v6524 to i64
  %cond6526 = icmp ne i64 %cv6525, 0
  br i1 %cond6526, label %bb_rcslotrole1523, label %bb_rcslotowner1523
bb_rcslotrole1523:
  %v6527 = load i64, ptr %slot63, align 8
  store i64 %v6527, ptr %slot925, align 8
  %v6528 = load i64, ptr %slot922, align 8
  %p6529 = inttoptr i64 %v6528 to ptr
  %ld6530 = load i64, ptr %p6529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6530, ptr %slot926, align 8
  %v6531 = load i64, ptr %slot926, align 8
  %cmp6532 = icmp ne i64 %v6531, 0
  %cv6533 = zext i1 %cmp6532 to i32
  store i32 %cv6533, ptr %slot927, align 8
  %v6534 = load i32, ptr %slot927, align 8
  %cv6535 = zext i32 %v6534 to i64
  %cond6536 = icmp ne i64 %cv6535, 0
  br i1 %cond6536, label %bb_rcgnn1539, label %bb_rcgdone1539
bb_rcgnn1539:
  %v6537 = load i64, ptr %slot926, align 8
  %op6538 = sub i64 %v6537, 16
  store i64 %op6538, ptr %slot928, align 8
  %v6539 = load i64, ptr %slot926, align 8
  %p6540 = inttoptr i64 %v6539 to ptr
  %rgep6541 = getelementptr i8, ptr %p6540, i64 -16
  %ld6542 = load i64, ptr %rgep6541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6542, ptr %slot929, align 8
  %v6543 = load i64, ptr %slot929, align 8
  %op6544 = and i64 %v6543, 4611686018427387906
  store i64 %op6544, ptr %slot930, align 8
  %v6545 = load i64, ptr %slot930, align 8
  %cmp6546 = icmp ne i64 %v6545, 0
  %cv6547 = zext i1 %cmp6546 to i32
  store i32 %cv6547, ptr %slot931, align 8
  %v6548 = load i32, ptr %slot931, align 8
  %cv6549 = zext i32 %v6548 to i64
  %cond6550 = icmp ne i64 %cv6549, 0
  br i1 %cond6550, label %bb_rcgclear1539, label %bb_rcgcounted1539
bb_rcgcounted1539:
  %v6551 = load i64, ptr %slot926, align 8
  %op6552 = sub i64 %v6551, 24
  store i64 %op6552, ptr %slot932, align 8
  %v6553 = load i64, ptr %slot926, align 8
  %p6554 = inttoptr i64 %v6553 to ptr
  %rgep6555 = getelementptr i8, ptr %p6554, i64 -24
  %ld6556 = load i64, ptr %rgep6555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6556, ptr %slot933, align 8
  %v6557 = load i64, ptr %slot933, align 8
  %op6558 = sub i64 %v6557, 1
  store i64 %op6558, ptr %slot934, align 8
  %v6559 = load i64, ptr %slot934, align 8
  %cmp6560 = icmp eq i64 %v6559, 0
  %cv6561 = zext i1 %cmp6560 to i32
  store i32 %cv6561, ptr %slot935, align 8
  %v6562 = load i32, ptr %slot935, align 8
  %cv6563 = zext i32 %v6562 to i64
  %cond6564 = icmp ne i64 %cv6563, 0
  br i1 %cond6564, label %bb_rcglast1539, label %bb_rcgdec1539
bb_rcglast1539:
  %v6565 = load i64, ptr %slot926, align 8
  %op6566 = sub i64 %v6565, 32
  store i64 %op6566, ptr %slot936, align 8
  %v6567 = load i64, ptr %slot926, align 8
  %p6568 = inttoptr i64 %v6567 to ptr
  %rgep6569 = getelementptr i8, ptr %p6568, i64 -32
  %ld6570 = load i64, ptr %rgep6569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6570, ptr %slot937, align 8
  %v6571 = load i64, ptr %slot937, align 8
  %cmp6572 = icmp ne i64 %v6571, 0
  %cv6573 = zext i1 %cmp6572 to i32
  store i32 %cv6573, ptr %slot938, align 8
  %v6574 = load i32, ptr %slot938, align 8
  %cv6575 = zext i32 %v6574 to i64
  %cond6576 = icmp ne i64 %cv6575, 0
  br i1 %cond6576, label %bb_rcgdec1539, label %bb_rcgslow1539
bb_rcgslow1539:
  %v6577 = load i64, ptr %slot925, align 8
  %v6578 = load i64, ptr %slot922, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6577, i64 %v6578) nomerge, !dbg !168
  br label %bb_rcgdone1539
bb_rcgdec1539:
  %v6579 = load i64, ptr %slot934, align 8
  %v6580 = load i64, ptr %slot926, align 8
  %p6581 = inttoptr i64 %v6580 to ptr
  %rgep6582 = getelementptr i8, ptr %p6581, i64 -24
  store i64 %v6579, ptr %rgep6582, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1539
bb_rcgclear1539:
  %v6583 = load i64, ptr %slot922, align 8
  %p6584 = inttoptr i64 %v6583 to ptr
  store i64 0, ptr %p6584, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1539
bb_rcgdone1539:
  br label %bb_rcslotdone1523
bb_rcslotowner1523:
  %v6585 = load i64, ptr %slot63, align 8
  store i64 %v6585, ptr %slot939, align 8
  %v6586 = load i64, ptr %slot922, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  %ld6588 = load i64, ptr %p6587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6588, ptr %slot940, align 8
  %v6589 = load i64, ptr %slot940, align 8
  %cmp6590 = icmp ne i64 %v6589, 0
  %cv6591 = zext i1 %cmp6590 to i32
  store i32 %cv6591, ptr %slot941, align 8
  %v6592 = load i32, ptr %slot941, align 8
  %cv6593 = zext i32 %v6592 to i64
  %cond6594 = icmp ne i64 %cv6593, 0
  br i1 %cond6594, label %bb_rcgnn1554, label %bb_rcgdone1554
bb_rcgnn1554:
  %v6595 = load i64, ptr %slot940, align 8
  %op6596 = sub i64 %v6595, 16
  store i64 %op6596, ptr %slot942, align 8
  %v6597 = load i64, ptr %slot940, align 8
  %p6598 = inttoptr i64 %v6597 to ptr
  %rgep6599 = getelementptr i8, ptr %p6598, i64 -16
  %ld6600 = load i64, ptr %rgep6599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6600, ptr %slot943, align 8
  %v6601 = load i64, ptr %slot943, align 8
  %op6602 = and i64 %v6601, 4611686018427387906
  store i64 %op6602, ptr %slot944, align 8
  %v6603 = load i64, ptr %slot944, align 8
  %cmp6604 = icmp ne i64 %v6603, 0
  %cv6605 = zext i1 %cmp6604 to i32
  store i32 %cv6605, ptr %slot945, align 8
  %v6606 = load i32, ptr %slot945, align 8
  %cv6607 = zext i32 %v6606 to i64
  %cond6608 = icmp ne i64 %cv6607, 0
  br i1 %cond6608, label %bb_rcgclear1554, label %bb_rcgcounted1554
bb_rcgcounted1554:
  %v6609 = load i64, ptr %slot940, align 8
  %op6610 = sub i64 %v6609, 32
  store i64 %op6610, ptr %slot946, align 8
  %v6611 = load i64, ptr %slot940, align 8
  %p6612 = inttoptr i64 %v6611 to ptr
  %rgep6613 = getelementptr i8, ptr %p6612, i64 -32
  %ld6614 = load i64, ptr %rgep6613, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6614, ptr %slot947, align 8
  %v6615 = load i64, ptr %slot947, align 8
  %op6616 = sub i64 %v6615, 1
  store i64 %op6616, ptr %slot948, align 8
  %v6617 = load i64, ptr %slot948, align 8
  %cmp6618 = icmp eq i64 %v6617, 0
  %cv6619 = zext i1 %cmp6618 to i32
  store i32 %cv6619, ptr %slot949, align 8
  %v6620 = load i32, ptr %slot949, align 8
  %cv6621 = zext i32 %v6620 to i64
  %cond6622 = icmp ne i64 %cv6621, 0
  br i1 %cond6622, label %bb_rcglast1554, label %bb_rcgdec1554
bb_rcglast1554:
  %v6623 = load i64, ptr %slot940, align 8
  %op6624 = sub i64 %v6623, 24
  store i64 %op6624, ptr %slot950, align 8
  %v6625 = load i64, ptr %slot940, align 8
  %p6626 = inttoptr i64 %v6625 to ptr
  %rgep6627 = getelementptr i8, ptr %p6626, i64 -24
  %ld6628 = load i64, ptr %rgep6627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6628, ptr %slot951, align 8
  %v6629 = load i64, ptr %slot951, align 8
  %cmp6630 = icmp ne i64 %v6629, 0
  %cv6631 = zext i1 %cmp6630 to i32
  store i32 %cv6631, ptr %slot952, align 8
  %v6632 = load i32, ptr %slot952, align 8
  %cv6633 = zext i32 %v6632 to i64
  %cond6634 = icmp ne i64 %cv6633, 0
  br i1 %cond6634, label %bb_rcgdec1554, label %bb_rcgslow1554
bb_rcgslow1554:
  %v6635 = load i64, ptr %slot939, align 8
  %v6636 = load i64, ptr %slot922, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6635, i64 %v6636) nomerge, !dbg !168
  br label %bb_rcgdone1554
bb_rcgdec1554:
  %v6637 = load i64, ptr %slot948, align 8
  %v6638 = load i64, ptr %slot940, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  %rgep6640 = getelementptr i8, ptr %p6639, i64 -32
  store i64 %v6637, ptr %rgep6640, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1554
bb_rcgclear1554:
  %v6641 = load i64, ptr %slot922, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  store i64 0, ptr %p6642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1554
bb_rcgdone1554:
  br label %bb_rcslotdone1523
bb_rcslotdone1523:
  %v6643 = load i64, ptr %slot9, align 8
  %p6644 = inttoptr i64 %v6643 to ptr
  %ld6645 = load i32, ptr %p6644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6645, ptr %slot953, align 8
  %v6646 = load i32, ptr %slot953, align 8
  %cv6647 = zext i32 %v6646 to i64
  %cond6648 = icmp ne i64 %cv6647, 0
  br i1 %cond6648, label %bb_rcslotdrop1560, label %bb_rcslotdone1560
bb_rcslotdrop1560:
  %v6649 = load i64, ptr %slot9, align 8
  %p6650 = inttoptr i64 %v6649 to ptr
  store i32 0, ptr %p6650, align 4, !alias.scope !3, !noalias !4
  %v6651 = load i64, ptr %slot40, align 8
  store i64 %v6651, ptr %slot954, align 8
  %v6652 = load i64, ptr %slot10, align 8
  %p6653 = inttoptr i64 %v6652 to ptr
  %ld6654 = load i32, ptr %p6653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6654, ptr %slot955, align 8
  %v6655 = load i32, ptr %slot955, align 8
  %op6656 = and i32 %v6655, 28
  store i32 %op6656, ptr %slot956, align 8
  %v6657 = load i32, ptr %slot956, align 8
  %cv6658 = zext i32 %v6657 to i64
  %cond6659 = icmp ne i64 %cv6658, 0
  br i1 %cond6659, label %bb_rcslotrole1560, label %bb_rcslotowner1560
bb_rcslotrole1560:
  %v6660 = load i64, ptr %slot63, align 8
  store i64 %v6660, ptr %slot957, align 8
  %v6661 = load i64, ptr %slot954, align 8
  %p6662 = inttoptr i64 %v6661 to ptr
  %ld6663 = load i64, ptr %p6662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6663, ptr %slot958, align 8
  %v6664 = load i64, ptr %slot958, align 8
  %cmp6665 = icmp ne i64 %v6664, 0
  %cv6666 = zext i1 %cmp6665 to i32
  store i32 %cv6666, ptr %slot959, align 8
  %v6667 = load i32, ptr %slot959, align 8
  %cv6668 = zext i32 %v6667 to i64
  %cond6669 = icmp ne i64 %cv6668, 0
  br i1 %cond6669, label %bb_rcgnn1576, label %bb_rcgdone1576
bb_rcgnn1576:
  %v6670 = load i64, ptr %slot958, align 8
  %op6671 = sub i64 %v6670, 16
  store i64 %op6671, ptr %slot960, align 8
  %v6672 = load i64, ptr %slot958, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  %rgep6674 = getelementptr i8, ptr %p6673, i64 -16
  %ld6675 = load i64, ptr %rgep6674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6675, ptr %slot961, align 8
  %v6676 = load i64, ptr %slot961, align 8
  %op6677 = and i64 %v6676, 4611686018427387906
  store i64 %op6677, ptr %slot962, align 8
  %v6678 = load i64, ptr %slot962, align 8
  %cmp6679 = icmp ne i64 %v6678, 0
  %cv6680 = zext i1 %cmp6679 to i32
  store i32 %cv6680, ptr %slot963, align 8
  %v6681 = load i32, ptr %slot963, align 8
  %cv6682 = zext i32 %v6681 to i64
  %cond6683 = icmp ne i64 %cv6682, 0
  br i1 %cond6683, label %bb_rcgclear1576, label %bb_rcgcounted1576
bb_rcgcounted1576:
  %v6684 = load i64, ptr %slot958, align 8
  %op6685 = sub i64 %v6684, 24
  store i64 %op6685, ptr %slot964, align 8
  %v6686 = load i64, ptr %slot958, align 8
  %p6687 = inttoptr i64 %v6686 to ptr
  %rgep6688 = getelementptr i8, ptr %p6687, i64 -24
  %ld6689 = load i64, ptr %rgep6688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6689, ptr %slot965, align 8
  %v6690 = load i64, ptr %slot965, align 8
  %op6691 = sub i64 %v6690, 1
  store i64 %op6691, ptr %slot966, align 8
  %v6692 = load i64, ptr %slot966, align 8
  %cmp6693 = icmp eq i64 %v6692, 0
  %cv6694 = zext i1 %cmp6693 to i32
  store i32 %cv6694, ptr %slot967, align 8
  %v6695 = load i32, ptr %slot967, align 8
  %cv6696 = zext i32 %v6695 to i64
  %cond6697 = icmp ne i64 %cv6696, 0
  br i1 %cond6697, label %bb_rcglast1576, label %bb_rcgdec1576
bb_rcglast1576:
  %v6698 = load i64, ptr %slot958, align 8
  %op6699 = sub i64 %v6698, 32
  store i64 %op6699, ptr %slot968, align 8
  %v6700 = load i64, ptr %slot958, align 8
  %p6701 = inttoptr i64 %v6700 to ptr
  %rgep6702 = getelementptr i8, ptr %p6701, i64 -32
  %ld6703 = load i64, ptr %rgep6702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6703, ptr %slot969, align 8
  %v6704 = load i64, ptr %slot969, align 8
  %cmp6705 = icmp ne i64 %v6704, 0
  %cv6706 = zext i1 %cmp6705 to i32
  store i32 %cv6706, ptr %slot970, align 8
  %v6707 = load i32, ptr %slot970, align 8
  %cv6708 = zext i32 %v6707 to i64
  %cond6709 = icmp ne i64 %cv6708, 0
  br i1 %cond6709, label %bb_rcgdec1576, label %bb_rcgslow1576
bb_rcgslow1576:
  %v6710 = load i64, ptr %slot957, align 8
  %v6711 = load i64, ptr %slot954, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v6710, i64 %v6711) nomerge, !dbg !168
  br label %bb_rcgdone1576
bb_rcgdec1576:
  %v6712 = load i64, ptr %slot966, align 8
  %v6713 = load i64, ptr %slot958, align 8
  %p6714 = inttoptr i64 %v6713 to ptr
  %rgep6715 = getelementptr i8, ptr %p6714, i64 -24
  store i64 %v6712, ptr %rgep6715, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1576
bb_rcgclear1576:
  %v6716 = load i64, ptr %slot954, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  store i64 0, ptr %p6717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1576
bb_rcgdone1576:
  br label %bb_rcslotdone1560
bb_rcslotowner1560:
  %v6718 = load i64, ptr %slot63, align 8
  store i64 %v6718, ptr %slot971, align 8
  %v6719 = load i64, ptr %slot954, align 8
  %p6720 = inttoptr i64 %v6719 to ptr
  %ld6721 = load i64, ptr %p6720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6721, ptr %slot972, align 8
  %v6722 = load i64, ptr %slot972, align 8
  %cmp6723 = icmp ne i64 %v6722, 0
  %cv6724 = zext i1 %cmp6723 to i32
  store i32 %cv6724, ptr %slot973, align 8
  %v6725 = load i32, ptr %slot973, align 8
  %cv6726 = zext i32 %v6725 to i64
  %cond6727 = icmp ne i64 %cv6726, 0
  br i1 %cond6727, label %bb_rcgnn1591, label %bb_rcgdone1591
bb_rcgnn1591:
  %v6728 = load i64, ptr %slot972, align 8
  %op6729 = sub i64 %v6728, 16
  store i64 %op6729, ptr %slot974, align 8
  %v6730 = load i64, ptr %slot972, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  %rgep6732 = getelementptr i8, ptr %p6731, i64 -16
  %ld6733 = load i64, ptr %rgep6732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6733, ptr %slot975, align 8
  %v6734 = load i64, ptr %slot975, align 8
  %op6735 = and i64 %v6734, 4611686018427387906
  store i64 %op6735, ptr %slot976, align 8
  %v6736 = load i64, ptr %slot976, align 8
  %cmp6737 = icmp ne i64 %v6736, 0
  %cv6738 = zext i1 %cmp6737 to i32
  store i32 %cv6738, ptr %slot977, align 8
  %v6739 = load i32, ptr %slot977, align 8
  %cv6740 = zext i32 %v6739 to i64
  %cond6741 = icmp ne i64 %cv6740, 0
  br i1 %cond6741, label %bb_rcgclear1591, label %bb_rcgcounted1591
bb_rcgcounted1591:
  %v6742 = load i64, ptr %slot972, align 8
  %op6743 = sub i64 %v6742, 32
  store i64 %op6743, ptr %slot978, align 8
  %v6744 = load i64, ptr %slot972, align 8
  %p6745 = inttoptr i64 %v6744 to ptr
  %rgep6746 = getelementptr i8, ptr %p6745, i64 -32
  %ld6747 = load i64, ptr %rgep6746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6747, ptr %slot979, align 8
  %v6748 = load i64, ptr %slot979, align 8
  %op6749 = sub i64 %v6748, 1
  store i64 %op6749, ptr %slot980, align 8
  %v6750 = load i64, ptr %slot980, align 8
  %cmp6751 = icmp eq i64 %v6750, 0
  %cv6752 = zext i1 %cmp6751 to i32
  store i32 %cv6752, ptr %slot981, align 8
  %v6753 = load i32, ptr %slot981, align 8
  %cv6754 = zext i32 %v6753 to i64
  %cond6755 = icmp ne i64 %cv6754, 0
  br i1 %cond6755, label %bb_rcglast1591, label %bb_rcgdec1591
bb_rcglast1591:
  %v6756 = load i64, ptr %slot972, align 8
  %op6757 = sub i64 %v6756, 24
  store i64 %op6757, ptr %slot982, align 8
  %v6758 = load i64, ptr %slot972, align 8
  %p6759 = inttoptr i64 %v6758 to ptr
  %rgep6760 = getelementptr i8, ptr %p6759, i64 -24
  %ld6761 = load i64, ptr %rgep6760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6761, ptr %slot983, align 8
  %v6762 = load i64, ptr %slot983, align 8
  %cmp6763 = icmp ne i64 %v6762, 0
  %cv6764 = zext i1 %cmp6763 to i32
  store i32 %cv6764, ptr %slot984, align 8
  %v6765 = load i32, ptr %slot984, align 8
  %cv6766 = zext i32 %v6765 to i64
  %cond6767 = icmp ne i64 %cv6766, 0
  br i1 %cond6767, label %bb_rcgdec1591, label %bb_rcgslow1591
bb_rcgslow1591:
  %v6768 = load i64, ptr %slot971, align 8
  %v6769 = load i64, ptr %slot954, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6768, i64 %v6769) nomerge, !dbg !168
  br label %bb_rcgdone1591
bb_rcgdec1591:
  %v6770 = load i64, ptr %slot980, align 8
  %v6771 = load i64, ptr %slot972, align 8
  %p6772 = inttoptr i64 %v6771 to ptr
  %rgep6773 = getelementptr i8, ptr %p6772, i64 -32
  store i64 %v6770, ptr %rgep6773, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1591
bb_rcgclear1591:
  %v6774 = load i64, ptr %slot954, align 8
  %p6775 = inttoptr i64 %v6774 to ptr
  store i64 0, ptr %p6775, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1591
bb_rcgdone1591:
  br label %bb_rcslotdone1560
bb_rcslotdone1560:
  %v6776 = load i64, ptr %slot7, align 8
  %p6777 = inttoptr i64 %v6776 to ptr
  %ld6778 = load i32, ptr %p6777, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6778, ptr %slot985, align 8
  %v6779 = load i32, ptr %slot985, align 8
  %cv6780 = zext i32 %v6779 to i64
  %cond6781 = icmp ne i64 %cv6780, 0
  br i1 %cond6781, label %bb_rcslotdrop1615, label %bb_rcslotdone1615
bb_rcslotdrop1615:
  %v6782 = load i64, ptr %slot7, align 8
  %p6783 = inttoptr i64 %v6782 to ptr
  store i32 0, ptr %p6783, align 4, !alias.scope !3, !noalias !4
  %v6784 = load i64, ptr %slot38, align 8
  store i64 %v6784, ptr %slot986, align 8
  %v6785 = load i64, ptr %slot8, align 8
  %p6786 = inttoptr i64 %v6785 to ptr
  %ld6787 = load i32, ptr %p6786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6787, ptr %slot987, align 8
  %v6788 = load i32, ptr %slot987, align 8
  %op6789 = and i32 %v6788, 28
  store i32 %op6789, ptr %slot988, align 8
  %v6790 = load i32, ptr %slot988, align 8
  %cv6791 = zext i32 %v6790 to i64
  %cond6792 = icmp ne i64 %cv6791, 0
  br i1 %cond6792, label %bb_rcslotrole1615, label %bb_rcslotowner1615
bb_rcslotrole1615:
  %v6793 = load i64, ptr %slot63, align 8
  store i64 %v6793, ptr %slot989, align 8
  %v6794 = load i64, ptr %slot989, align 8
  %v6795 = load i64, ptr %slot986, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6794, i64 %v6795) nomerge, !dbg !168
  br label %bb_rcslotdone1615
bb_rcslotowner1615:
  %v6796 = load i64, ptr %slot63, align 8
  store i64 %v6796, ptr %slot990, align 8
  %v6797 = load i64, ptr %slot990, align 8
  %v6798 = load i64, ptr %slot986, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6797, i64 %v6798) nomerge, !dbg !168
  br label %bb_rcslotdone1615
bb_rcslotdone1615:
  %v6799 = load i64, ptr %slot876, align 8
  %p6800 = inttoptr i64 %v6799 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6800, i64 24, i1 false)
  ret void
bb_i97:
  %v6801 = load i64, ptr %slot27, align 8
  %p6802 = inttoptr i64 %v6801 to ptr
  %ld6803 = load i64, ptr %p6802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6803, ptr %slot991, align 8
  %v6804 = load i64, ptr %slot991, align 8
  %v6805 = load i64, ptr %slot44, align 8
  %p6806 = inttoptr i64 %v6805 to ptr
  store i64 %v6804, ptr %p6806, align 8, !alias.scope !3, !noalias !4
  %v6807 = load i64, ptr %slot39, align 8
  %v6808 = load i64, ptr %slot45, align 8
  %p6809 = inttoptr i64 %v6808 to ptr
  store i64 %v6807, ptr %p6809, align 8, !alias.scope !3, !noalias !4
  %v6810 = load i64, ptr %slot45, align 8
  %p6811 = inttoptr i64 %v6810 to ptr
  %ld6812 = load i64, ptr %p6811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6812, ptr %slot992, align 8
  %v6813 = load i64, ptr %slot992, align 8
  %op6814 = add i64 %v6813, 8
  store i64 %op6814, ptr %slot993, align 8
  %v6815 = load i64, ptr %slot993, align 8
  %p6816 = inttoptr i64 %v6815 to ptr
  %ld6817 = load i64, ptr %p6816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6817, ptr %slot994, align 8
  %v6818 = load i64, ptr %slot994, align 8
  %v6819 = load i64, ptr %slot45, align 8
  %p6820 = inttoptr i64 %v6819 to ptr
  store i64 %v6818, ptr %p6820, align 8, !alias.scope !3, !noalias !4
  %v6821 = load i64, ptr %slot45, align 8
  %p6822 = inttoptr i64 %v6821 to ptr
  %ld6823 = load i64, ptr %p6822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6823, ptr %slot995, align 8
  %v6824 = load i64, ptr %slot44, align 8
  %p6825 = inttoptr i64 %v6824 to ptr
  %ld6826 = load i64, ptr %p6825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6826, ptr %slot996, align 8
  %v6827 = load i64, ptr %slot996, align 8
  %v6828 = load i64, ptr %slot995, align 8
  %cmp6829 = icmp ne i64 %v6827, %v6828
  %cv6830 = zext i1 %cmp6829 to i64
  store i64 %cv6830, ptr %slot997, align 8
  %v6831 = load i64, ptr %slot997, align 8
  %v6832 = load i64, ptr %slot44, align 8
  %p6833 = inttoptr i64 %v6832 to ptr
  store i64 %v6831, ptr %p6833, align 8, !alias.scope !3, !noalias !4
  %v6834 = load i64, ptr %slot44, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  %ld6836 = load i64, ptr %p6835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6836, ptr %slot998, align 8
  %v6837 = load i64, ptr %slot998, align 8
  %cond6838 = icmp ne i64 %v6837, 0
  br i1 %cond6838, label %bb_next1713, label %bb_i133
bb_next1713:
  %p6839 = inttoptr i64 ptrtoint (ptr @myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a to i64) to ptr
  %ld6840 = load i64, ptr %p6839, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6840, ptr %slot999, align 8
  %v6841 = load i64, ptr %slot999, align 8
  %v6842 = load i64, ptr %slot44, align 8
  %p6843 = inttoptr i64 %v6842 to ptr
  store i64 %v6841, ptr %p6843, align 8, !alias.scope !3, !noalias !4
  %v6844 = load i64, ptr %slot44, align 8
  %p6845 = inttoptr i64 %v6844 to ptr
  %ld6846 = load i64, ptr %p6845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6846, ptr %slot1000, align 8
  %v6847 = load i64, ptr %slot1000, align 8
  %v6848 = load i64, ptr %slot23, align 8
  %p6849 = inttoptr i64 %v6848 to ptr
  store i64 %v6847, ptr %p6849, align 8, !alias.scope !3, !noalias !4
  %v6850 = load i64, ptr %slot23, align 8
  store i64 %v6850, ptr %slot1001, align 8
  %v6851 = load i64, ptr %slot24, align 8
  store i64 %v6851, ptr %slot1002, align 8
  %v6852 = load i64, ptr %slot1001, align 8
  %v6853 = load i64, ptr %slot1002, align 8
  %p6854 = inttoptr i64 %v6852 to ptr
  %p6855 = inttoptr i64 %v6853 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6855, ptr %p6854, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6856 = load i64, ptr %slot20, align 8
  %p6857 = inttoptr i64 %v6856 to ptr
  store i32 2, ptr %p6857, align 4, !alias.scope !3, !noalias !4
  %v6858 = load i64, ptr %slot19, align 8
  %p6859 = inttoptr i64 %v6858 to ptr
  store i32 1, ptr %p6859, align 4, !alias.scope !3, !noalias !4
  %v6860 = load i64, ptr %slot22, align 8
  store i64 %v6860, ptr %slot1003, align 8
  %v6861 = load i64, ptr %slot24, align 8
  store i64 %v6861, ptr %slot1004, align 8
  %v6862 = load i64, ptr %slot1004, align 8
  %v6863 = load i64, ptr %slot1003, align 8
  %p6864 = inttoptr i64 %v6862 to ptr
  %p6865 = inttoptr i64 %v6863 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6865, ptr %p6864, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6866 = load i64, ptr %slot18, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  store i32 2, ptr %p6867, align 4, !alias.scope !3, !noalias !4
  %v6868 = load i64, ptr %slot20, align 8
  %p6869 = inttoptr i64 %v6868 to ptr
  %ld6870 = load i32, ptr %p6869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6870, ptr %slot1005, align 8
  %v6871 = load i32, ptr %slot1005, align 8
  %v6872 = load i64, ptr %slot18, align 8
  %p6873 = inttoptr i64 %v6872 to ptr
  store i32 %v6871, ptr %p6873, align 4, !alias.scope !3, !noalias !4
  %v6874 = load i64, ptr %slot19, align 8
  %p6875 = inttoptr i64 %v6874 to ptr
  store i32 0, ptr %p6875, align 4, !alias.scope !3, !noalias !4
  %v6876 = load i64, ptr %slot17, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  store i32 1, ptr %p6877, align 4, !alias.scope !3, !noalias !4
  %v6878 = load i64, ptr %slot1003, align 8
  %p6879 = inttoptr i64 %v6878 to ptr
  %ld6880 = load i64, ptr %p6879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6880, ptr %slot1006, align 8
  %v6881 = load i64, ptr %slot1006, align 8
  %v6882 = load i64, ptr %slot44, align 8
  %p6883 = inttoptr i64 %v6882 to ptr
  store i64 %v6881, ptr %p6883, align 8, !alias.scope !3, !noalias !4
  %v6884 = load i64, ptr %slot44, align 8
  %p6885 = inttoptr i64 %v6884 to ptr
  %ld6886 = load i64, ptr %p6885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6886, ptr %slot1007, align 8
  %v6887 = load i64, ptr %slot1007, align 8
  %v6888 = load i64, ptr %slot23, align 8
  %p6889 = inttoptr i64 %v6888 to ptr
  store i64 %v6887, ptr %p6889, align 8, !alias.scope !3, !noalias !4
  %v6890 = load i64, ptr %slot23, align 8
  store i64 %v6890, ptr %slot1008, align 8
  %v6891 = load i64, ptr %slot17, align 8
  %p6892 = inttoptr i64 %v6891 to ptr
  %ld6893 = load i32, ptr %p6892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6893, ptr %slot1009, align 8
  %v6894 = load i64, ptr %slot18, align 8
  %p6895 = inttoptr i64 %v6894 to ptr
  %ld6896 = load i32, ptr %p6895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6896, ptr %slot1010, align 8
  %v6897 = load i32, ptr %slot1010, align 8
  %op6898 = and i32 %v6897, 24
  store i32 %op6898, ptr %slot1010, align 8
  %v6899 = load i32, ptr %slot1010, align 8
  %cmp6900 = icmp eq i32 %v6899, 0
  %cv6901 = zext i1 %cmp6900 to i32
  store i32 %cv6901, ptr %slot1011, align 8
  %v6902 = load i32, ptr %slot1009, align 8
  %v6903 = load i32, ptr %slot1011, align 8
  %op6904 = and i32 %v6902, %v6903
  store i32 %op6904, ptr %slot1012, align 8
  %v6905 = load i32, ptr %slot1012, align 8
  %cv6906 = zext i32 %v6905 to i64
  %cond6907 = icmp ne i64 %cv6906, 0
  br i1 %cond6907, label %bb_rcprivateown1737, label %bb_rcprivateloan1737
bb_rcprivateown1737:
  %v6908 = load i64, ptr %slot24, align 8
  store i64 %v6908, ptr %slot1013, align 8
  %v6909 = load i64, ptr %slot64, align 8
  store i64 %v6909, ptr %slot1014, align 8
  %v6910 = load i64, ptr %slot1008, align 8
  %v6911 = load i64, ptr %slot1013, align 8
  %op6912 = sub i64 %v6910, %v6911
  store i64 %op6912, ptr %slot1015, align 8
  %v6913 = load i64, ptr %slot1013, align 8
  %v6914 = load i64, ptr %slot1008, align 8
  %op6915 = sub i64 %v6913, %v6914
  store i64 %op6915, ptr %slot1016, align 8
  %v6916 = load i64, ptr %slot1015, align 8
  %cmp6917 = icmp ult i64 %v6916, 8
  %cv6918 = zext i1 %cmp6917 to i32
  store i32 %cv6918, ptr %slot1017, align 8
  %v6919 = load i64, ptr %slot1016, align 8
  %cmp6920 = icmp ult i64 %v6919, 8
  %cv6921 = zext i1 %cmp6920 to i32
  store i32 %cv6921, ptr %slot1018, align 8
  %v6922 = load i32, ptr %slot1017, align 8
  %v6923 = load i32, ptr %slot1018, align 8
  %op6924 = or i32 %v6922, %v6923
  store i32 %op6924, ptr %slot1019, align 8
  %v6925 = load i32, ptr %slot1019, align 8
  %cv6926 = zext i32 %v6925 to i64
  %cond6927 = icmp ne i64 %cv6926, 0
  br i1 %cond6927, label %bb_rcmoveslow1740, label %bb_rcmovecheck1740
bb_rcmovecheck1740:
  %v6928 = load i64, ptr %slot1008, align 8
  %p6930 = inttoptr i64 %v6928 to ptr
  %gep6931 = getelementptr i8, ptr %p6930, i64 0
  %op6929 = ptrtoint ptr %gep6931 to i64
  store i64 %op6929, ptr %slot1020, align 8
  %v6932 = load i64, ptr %slot1020, align 8
  %p6933 = inttoptr i64 %v6932 to ptr
  %ld6934 = load i64, ptr %p6933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6934, ptr %slot1021, align 8
  %v6935 = load i64, ptr %slot1021, align 8
  %cmp6936 = icmp ne i64 %v6935, 0
  %cv6937 = zext i1 %cmp6936 to i32
  store i32 %cv6937, ptr %slot1022, align 8
  %v6938 = load i32, ptr %slot1022, align 8
  %cv6939 = zext i32 %v6938 to i64
  %cond6940 = icmp ne i64 %cv6939, 0
  br i1 %cond6940, label %bb_rcmoveheader1748, label %bb_rcmovenext1748
bb_rcmoveheader1748:
  %v6941 = load i64, ptr %slot1021, align 8
  %op6942 = sub i64 %v6941, 16
  store i64 %op6942, ptr %slot1023, align 8
  %v6943 = load i64, ptr %slot1021, align 8
  %p6944 = inttoptr i64 %v6943 to ptr
  %rgep6945 = getelementptr i8, ptr %p6944, i64 -16
  %ld6946 = load i64, ptr %rgep6945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6946, ptr %slot1024, align 8
  %v6947 = load i64, ptr %slot1024, align 8
  %op6948 = and i64 %v6947, 5764607523034234881
  store i64 %op6948, ptr %slot1025, align 8
  %v6949 = load i64, ptr %slot1025, align 8
  %cmp6950 = icmp ne i64 %v6949, 0
  %cv6951 = zext i1 %cmp6950 to i32
  store i32 %cv6951, ptr %slot1026, align 8
  %v6952 = load i32, ptr %slot1026, align 8
  %cv6953 = zext i32 %v6952 to i64
  %cond6954 = icmp ne i64 %cv6953, 0
  br i1 %cond6954, label %bb_rcmoveslow1740, label %bb_rcmovenext1748
bb_rcmovenext1748:
  %v6955 = load i64, ptr %slot1008, align 8
  %v6956 = load i64, ptr %slot1013, align 8
  %p6957 = inttoptr i64 %v6955 to ptr
  %p6958 = inttoptr i64 %v6956 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6958, ptr %p6957, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6959 = load i64, ptr %slot1008, align 8
  %p6960 = inttoptr i64 %v6959 to ptr
  store i64 0, ptr %p6960, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1740
bb_rcmoveslow1740:
  %v6961 = load i64, ptr %slot63, align 8
  %v6962 = load i64, ptr %slot1013, align 8
  %v6963 = load i64, ptr %slot1008, align 8
  %v6964 = load i64, ptr %slot1014, align 8
  %cv6965 = trunc i64 %v6964 to i32
  %call6966 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v6961, i64 %v6962, i64 %v6963, i32 %cv6965) nomerge, !dbg !170
  store i32 %call6966, ptr %slot1027, align 8
  %v6967 = load i32, ptr %slot1027, align 8
  %cv6968 = zext i32 %v6967 to i64
  %cond6969 = icmp ne i64 %cv6968, 0
  br i1 %cond6969, label %bb_rcsuccess1755, label %bb_rcfailure1755
bb_rcfailure1755:
  %v6970 = load i64, ptr %slot63, align 8
  %p6971 = inttoptr i64 %v6970 to ptr
  %call6972 = call i32 @myl_rc_take_failure(ptr %p6971) nomerge, !dbg !170
  store i32 %call6972, ptr %slot1028, align 8
  %v6973 = load i64, ptr %slot1, align 8
  %p6974 = inttoptr i64 %v6973 to ptr
  %v6975 = load i32, ptr %slot1028, align 8
  %call6976 = call i32 @myl_qbe_rc_status(ptr %p6974, i32 %v6975) nomerge, !dbg !170
  store i32 %call6976, ptr %slot1029, align 8
  br label %bb_failure
bb_rcsuccess1755:
  br label %bb_rcmoved1740
bb_rcmoved1740:
  %v6977 = load i64, ptr %slot17, align 8
  %p6978 = inttoptr i64 %v6977 to ptr
  store i32 0, ptr %p6978, align 4, !alias.scope !3, !noalias !4
  %v6979 = load i64, ptr %slot20, align 8
  %p6980 = inttoptr i64 %v6979 to ptr
  store i32 2, ptr %p6980, align 4, !alias.scope !3, !noalias !4
  %v6981 = load i64, ptr %slot19, align 8
  %p6982 = inttoptr i64 %v6981 to ptr
  store i32 1, ptr %p6982, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1737
bb_rcprivateloan1737:
  %v6983 = load i64, ptr %slot17, align 8
  %p6984 = inttoptr i64 %v6983 to ptr
  %ld6985 = load i32, ptr %p6984, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6985, ptr %slot1030, align 8
  %v6986 = load i64, ptr %slot18, align 8
  %p6987 = inttoptr i64 %v6986 to ptr
  %ld6988 = load i32, ptr %p6987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6988, ptr %slot1031, align 8
  %v6989 = load i32, ptr %slot1031, align 8
  %cmp6990 = icmp eq i32 %v6989, 16
  %cv6991 = zext i1 %cmp6990 to i32
  store i32 %cv6991, ptr %slot1032, align 8
  %v6992 = load i32, ptr %slot1032, align 8
  %v6993 = load i32, ptr %slot1030, align 8
  %op6994 = and i32 %v6992, %v6993
  store i32 %op6994, ptr %slot1032, align 8
  %v6995 = load i32, ptr %slot1032, align 8
  %cv6996 = zext i32 %v6995 to i64
  %cond6997 = icmp ne i64 %cv6996, 0
  br i1 %cond6997, label %bb_rcprivatemove1737, label %bb_rcprivatenew1737
bb_rcprivatemove1737:
  %v6998 = load i64, ptr %slot24, align 8
  store i64 %v6998, ptr %slot1033, align 8
  %v6999 = load i64, ptr %slot1008, align 8
  %v7000 = load i64, ptr %slot1033, align 8
  %p7001 = inttoptr i64 %v6999 to ptr
  %p7002 = inttoptr i64 %v7000 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7002, ptr %p7001, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7003 = load i64, ptr %slot1008, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  store i64 0, ptr %p7004, align 8, !alias.scope !3, !noalias !4
  %v7005 = load i64, ptr %slot20, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  store i32 2, ptr %p7006, align 4, !alias.scope !3, !noalias !4
  %v7007 = load i64, ptr %slot20, align 8
  %p7008 = inttoptr i64 %v7007 to ptr
  store i32 16, ptr %p7008, align 4, !alias.scope !3, !noalias !4
  %v7009 = load i64, ptr %slot19, align 8
  %p7010 = inttoptr i64 %v7009 to ptr
  store i32 1, ptr %p7010, align 4, !alias.scope !3, !noalias !4
  %v7011 = load i64, ptr %slot17, align 8
  %p7012 = inttoptr i64 %v7011 to ptr
  store i32 0, ptr %p7012, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1737
bb_rcprivatenew1737:
  %v7013 = load i64, ptr %slot24, align 8
  store i64 %v7013, ptr %slot1034, align 8
  %v7014 = load i64, ptr %slot1008, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  %ld7016 = load i64, ptr %p7015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7016, ptr %slot1035, align 8
  %v7017 = load i64, ptr %slot1035, align 8
  %cmp7018 = icmp ne i64 %v7017, 0
  %cv7019 = zext i1 %cmp7018 to i32
  store i32 %cv7019, ptr %slot1036, align 8
  %v7020 = load i32, ptr %slot1036, align 8
  %cv7021 = zext i32 %v7020 to i64
  %cond7022 = icmp ne i64 %cv7021, 0
  br i1 %cond7022, label %bb_rcgnn1773, label %bb_rcgstore1773
bb_rcgnn1773:
  %v7023 = load i64, ptr %slot1035, align 8
  %op7024 = sub i64 %v7023, 16
  store i64 %op7024, ptr %slot1037, align 8
  %v7025 = load i64, ptr %slot1035, align 8
  %p7026 = inttoptr i64 %v7025 to ptr
  %rgep7027 = getelementptr i8, ptr %p7026, i64 -16
  %ld7028 = load i64, ptr %rgep7027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7028, ptr %slot1038, align 8
  %v7029 = load i64, ptr %slot1038, align 8
  %op7030 = and i64 %v7029, 4611686018427387906
  store i64 %op7030, ptr %slot1039, align 8
  %v7031 = load i64, ptr %slot1039, align 8
  %cmp7032 = icmp ne i64 %v7031, 0
  %cv7033 = zext i1 %cmp7032 to i32
  store i32 %cv7033, ptr %slot1040, align 8
  %v7034 = load i32, ptr %slot1040, align 8
  %cv7035 = zext i32 %v7034 to i64
  %cond7036 = icmp ne i64 %cv7035, 0
  br i1 %cond7036, label %bb_rcgstore1773, label %bb_rcginc1773
bb_rcginc1773:
  %v7037 = load i64, ptr %slot1035, align 8
  %op7038 = sub i64 %v7037, 24
  store i64 %op7038, ptr %slot1041, align 8
  %v7039 = load i64, ptr %slot1035, align 8
  %p7040 = inttoptr i64 %v7039 to ptr
  %rgep7041 = getelementptr i8, ptr %p7040, i64 -24
  %ld7042 = load i64, ptr %rgep7041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7042, ptr %slot1042, align 8
  %v7043 = load i64, ptr %slot1042, align 8
  %op7044 = add i64 %v7043, 1
  store i64 %op7044, ptr %slot1043, align 8
  %v7045 = load i64, ptr %slot1043, align 8
  %cmp7046 = icmp eq i64 %v7045, 0
  %cv7047 = zext i1 %cmp7046 to i32
  store i32 %cv7047, ptr %slot1044, align 8
  %v7048 = load i32, ptr %slot1044, align 8
  %cv7049 = zext i32 %v7048 to i64
  %cond7050 = icmp ne i64 %cv7049, 0
  br i1 %cond7050, label %bb_rcglimit1773, label %bb_rcgcapacity1773
bb_rcglimit1773:
  %v7051 = load i64, ptr %slot1, align 8
  %p7052 = inttoptr i64 %v7051 to ptr
  %call7053 = call i32 @myl_qbe_rc_status(ptr %p7052, i32 2) nomerge, !dbg !170
  store i32 %call7053, ptr %slot1045, align 8
  br label %bb_failure
bb_rcgcapacity1773:
  %v7054 = load i64, ptr %slot1043, align 8
  %v7055 = load i64, ptr %slot1035, align 8
  %p7056 = inttoptr i64 %v7055 to ptr
  %rgep7057 = getelementptr i8, ptr %p7056, i64 -24
  store i64 %v7054, ptr %rgep7057, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1773
bb_rcgstore1773:
  %v7058 = load i64, ptr %slot1035, align 8
  %v7059 = load i64, ptr %slot1034, align 8
  %p7060 = inttoptr i64 %v7059 to ptr
  store i64 %v7058, ptr %p7060, align 8, !alias.scope !3, !noalias !4
  %v7061 = load i64, ptr %slot20, align 8
  %p7062 = inttoptr i64 %v7061 to ptr
  store i32 2, ptr %p7062, align 4, !alias.scope !3, !noalias !4
  %v7063 = load i64, ptr %slot20, align 8
  %p7064 = inttoptr i64 %v7063 to ptr
  store i32 16, ptr %p7064, align 4, !alias.scope !3, !noalias !4
  %v7065 = load i64, ptr %slot19, align 8
  %p7066 = inttoptr i64 %v7065 to ptr
  store i32 1, ptr %p7066, align 4, !alias.scope !3, !noalias !4
  %v7067 = load i64, ptr %slot17, align 8
  %p7068 = inttoptr i64 %v7067 to ptr
  %ld7069 = load i32, ptr %p7068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7069, ptr %slot1046, align 8
  %v7070 = load i32, ptr %slot1046, align 8
  %cv7071 = zext i32 %v7070 to i64
  %cond7072 = icmp ne i64 %cv7071, 0
  br i1 %cond7072, label %bb_rcslotdrop1789, label %bb_rcslotdone1789
bb_rcslotdrop1789:
  %v7073 = load i64, ptr %slot17, align 8
  %p7074 = inttoptr i64 %v7073 to ptr
  store i32 0, ptr %p7074, align 4, !alias.scope !3, !noalias !4
  %v7075 = load i64, ptr %slot22, align 8
  store i64 %v7075, ptr %slot1047, align 8
  %v7076 = load i64, ptr %slot18, align 8
  %p7077 = inttoptr i64 %v7076 to ptr
  %ld7078 = load i32, ptr %p7077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7078, ptr %slot1048, align 8
  %v7079 = load i32, ptr %slot1048, align 8
  %op7080 = and i32 %v7079, 28
  store i32 %op7080, ptr %slot1049, align 8
  %v7081 = load i32, ptr %slot1049, align 8
  %cv7082 = zext i32 %v7081 to i64
  %cond7083 = icmp ne i64 %cv7082, 0
  br i1 %cond7083, label %bb_rcslotrole1789, label %bb_rcslotowner1789
bb_rcslotrole1789:
  %v7084 = load i64, ptr %slot63, align 8
  store i64 %v7084, ptr %slot1050, align 8
  %v7085 = load i64, ptr %slot1047, align 8
  %p7086 = inttoptr i64 %v7085 to ptr
  %ld7087 = load i64, ptr %p7086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7087, ptr %slot1051, align 8
  %v7088 = load i64, ptr %slot1051, align 8
  %cmp7089 = icmp ne i64 %v7088, 0
  %cv7090 = zext i1 %cmp7089 to i32
  store i32 %cv7090, ptr %slot1052, align 8
  %v7091 = load i32, ptr %slot1052, align 8
  %cv7092 = zext i32 %v7091 to i64
  %cond7093 = icmp ne i64 %cv7092, 0
  br i1 %cond7093, label %bb_rcgnn1805, label %bb_rcgdone1805
bb_rcgnn1805:
  %v7094 = load i64, ptr %slot1051, align 8
  %op7095 = sub i64 %v7094, 16
  store i64 %op7095, ptr %slot1053, align 8
  %v7096 = load i64, ptr %slot1051, align 8
  %p7097 = inttoptr i64 %v7096 to ptr
  %rgep7098 = getelementptr i8, ptr %p7097, i64 -16
  %ld7099 = load i64, ptr %rgep7098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7099, ptr %slot1054, align 8
  %v7100 = load i64, ptr %slot1054, align 8
  %op7101 = and i64 %v7100, 4611686018427387906
  store i64 %op7101, ptr %slot1055, align 8
  %v7102 = load i64, ptr %slot1055, align 8
  %cmp7103 = icmp ne i64 %v7102, 0
  %cv7104 = zext i1 %cmp7103 to i32
  store i32 %cv7104, ptr %slot1056, align 8
  %v7105 = load i32, ptr %slot1056, align 8
  %cv7106 = zext i32 %v7105 to i64
  %cond7107 = icmp ne i64 %cv7106, 0
  br i1 %cond7107, label %bb_rcgclear1805, label %bb_rcgcounted1805
bb_rcgcounted1805:
  %v7108 = load i64, ptr %slot1051, align 8
  %op7109 = sub i64 %v7108, 24
  store i64 %op7109, ptr %slot1057, align 8
  %v7110 = load i64, ptr %slot1051, align 8
  %p7111 = inttoptr i64 %v7110 to ptr
  %rgep7112 = getelementptr i8, ptr %p7111, i64 -24
  %ld7113 = load i64, ptr %rgep7112, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7113, ptr %slot1058, align 8
  %v7114 = load i64, ptr %slot1058, align 8
  %op7115 = sub i64 %v7114, 1
  store i64 %op7115, ptr %slot1059, align 8
  %v7116 = load i64, ptr %slot1059, align 8
  %cmp7117 = icmp eq i64 %v7116, 0
  %cv7118 = zext i1 %cmp7117 to i32
  store i32 %cv7118, ptr %slot1060, align 8
  %v7119 = load i32, ptr %slot1060, align 8
  %cv7120 = zext i32 %v7119 to i64
  %cond7121 = icmp ne i64 %cv7120, 0
  br i1 %cond7121, label %bb_rcglast1805, label %bb_rcgdec1805
bb_rcglast1805:
  %v7122 = load i64, ptr %slot1051, align 8
  %op7123 = sub i64 %v7122, 32
  store i64 %op7123, ptr %slot1061, align 8
  %v7124 = load i64, ptr %slot1051, align 8
  %p7125 = inttoptr i64 %v7124 to ptr
  %rgep7126 = getelementptr i8, ptr %p7125, i64 -32
  %ld7127 = load i64, ptr %rgep7126, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7127, ptr %slot1062, align 8
  %v7128 = load i64, ptr %slot1062, align 8
  %cmp7129 = icmp ne i64 %v7128, 0
  %cv7130 = zext i1 %cmp7129 to i32
  store i32 %cv7130, ptr %slot1063, align 8
  %v7131 = load i32, ptr %slot1063, align 8
  %cv7132 = zext i32 %v7131 to i64
  %cond7133 = icmp ne i64 %cv7132, 0
  br i1 %cond7133, label %bb_rcgdec1805, label %bb_rcgslow1805
bb_rcgslow1805:
  %v7134 = load i64, ptr %slot1050, align 8
  %v7135 = load i64, ptr %slot1047, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7134, i64 %v7135) nomerge, !dbg !170
  br label %bb_rcgdone1805
bb_rcgdec1805:
  %v7136 = load i64, ptr %slot1059, align 8
  %v7137 = load i64, ptr %slot1051, align 8
  %p7138 = inttoptr i64 %v7137 to ptr
  %rgep7139 = getelementptr i8, ptr %p7138, i64 -24
  store i64 %v7136, ptr %rgep7139, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1805
bb_rcgclear1805:
  %v7140 = load i64, ptr %slot1047, align 8
  %p7141 = inttoptr i64 %v7140 to ptr
  store i64 0, ptr %p7141, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1805
bb_rcgdone1805:
  br label %bb_rcslotdone1789
bb_rcslotowner1789:
  %v7142 = load i64, ptr %slot63, align 8
  store i64 %v7142, ptr %slot1064, align 8
  %v7143 = load i64, ptr %slot1047, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  %ld7145 = load i64, ptr %p7144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7145, ptr %slot1065, align 8
  %v7146 = load i64, ptr %slot1065, align 8
  %cmp7147 = icmp ne i64 %v7146, 0
  %cv7148 = zext i1 %cmp7147 to i32
  store i32 %cv7148, ptr %slot1066, align 8
  %v7149 = load i32, ptr %slot1066, align 8
  %cv7150 = zext i32 %v7149 to i64
  %cond7151 = icmp ne i64 %cv7150, 0
  br i1 %cond7151, label %bb_rcgnn1820, label %bb_rcgdone1820
bb_rcgnn1820:
  %v7152 = load i64, ptr %slot1065, align 8
  %op7153 = sub i64 %v7152, 16
  store i64 %op7153, ptr %slot1067, align 8
  %v7154 = load i64, ptr %slot1065, align 8
  %p7155 = inttoptr i64 %v7154 to ptr
  %rgep7156 = getelementptr i8, ptr %p7155, i64 -16
  %ld7157 = load i64, ptr %rgep7156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7157, ptr %slot1068, align 8
  %v7158 = load i64, ptr %slot1068, align 8
  %op7159 = and i64 %v7158, 4611686018427387906
  store i64 %op7159, ptr %slot1069, align 8
  %v7160 = load i64, ptr %slot1069, align 8
  %cmp7161 = icmp ne i64 %v7160, 0
  %cv7162 = zext i1 %cmp7161 to i32
  store i32 %cv7162, ptr %slot1070, align 8
  %v7163 = load i32, ptr %slot1070, align 8
  %cv7164 = zext i32 %v7163 to i64
  %cond7165 = icmp ne i64 %cv7164, 0
  br i1 %cond7165, label %bb_rcgclear1820, label %bb_rcgcounted1820
bb_rcgcounted1820:
  %v7166 = load i64, ptr %slot1065, align 8
  %op7167 = sub i64 %v7166, 32
  store i64 %op7167, ptr %slot1071, align 8
  %v7168 = load i64, ptr %slot1065, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  %rgep7170 = getelementptr i8, ptr %p7169, i64 -32
  %ld7171 = load i64, ptr %rgep7170, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7171, ptr %slot1072, align 8
  %v7172 = load i64, ptr %slot1072, align 8
  %op7173 = sub i64 %v7172, 1
  store i64 %op7173, ptr %slot1073, align 8
  %v7174 = load i64, ptr %slot1073, align 8
  %cmp7175 = icmp eq i64 %v7174, 0
  %cv7176 = zext i1 %cmp7175 to i32
  store i32 %cv7176, ptr %slot1074, align 8
  %v7177 = load i32, ptr %slot1074, align 8
  %cv7178 = zext i32 %v7177 to i64
  %cond7179 = icmp ne i64 %cv7178, 0
  br i1 %cond7179, label %bb_rcglast1820, label %bb_rcgdec1820
bb_rcglast1820:
  %v7180 = load i64, ptr %slot1065, align 8
  %op7181 = sub i64 %v7180, 24
  store i64 %op7181, ptr %slot1075, align 8
  %v7182 = load i64, ptr %slot1065, align 8
  %p7183 = inttoptr i64 %v7182 to ptr
  %rgep7184 = getelementptr i8, ptr %p7183, i64 -24
  %ld7185 = load i64, ptr %rgep7184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7185, ptr %slot1076, align 8
  %v7186 = load i64, ptr %slot1076, align 8
  %cmp7187 = icmp ne i64 %v7186, 0
  %cv7188 = zext i1 %cmp7187 to i32
  store i32 %cv7188, ptr %slot1077, align 8
  %v7189 = load i32, ptr %slot1077, align 8
  %cv7190 = zext i32 %v7189 to i64
  %cond7191 = icmp ne i64 %cv7190, 0
  br i1 %cond7191, label %bb_rcgdec1820, label %bb_rcgslow1820
bb_rcgslow1820:
  %v7192 = load i64, ptr %slot1064, align 8
  %v7193 = load i64, ptr %slot1047, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7192, i64 %v7193) nomerge, !dbg !170
  br label %bb_rcgdone1820
bb_rcgdec1820:
  %v7194 = load i64, ptr %slot1073, align 8
  %v7195 = load i64, ptr %slot1065, align 8
  %p7196 = inttoptr i64 %v7195 to ptr
  %rgep7197 = getelementptr i8, ptr %p7196, i64 -32
  store i64 %v7194, ptr %rgep7197, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1820
bb_rcgclear1820:
  %v7198 = load i64, ptr %slot1047, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  store i64 0, ptr %p7199, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1820
bb_rcgdone1820:
  br label %bb_rcslotdone1789
bb_rcslotdone1789:
  br label %bb_rcprivateprepared1737
bb_rcprivateprepared1737:
  %v7200 = load i64, ptr %slot11, align 8
  %p7201 = inttoptr i64 %v7200 to ptr
  %ld7202 = load i32, ptr %p7201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7202, ptr %slot1078, align 8
  %v7203 = load i32, ptr %slot1078, align 8
  %cv7204 = zext i32 %v7203 to i64
  %cond7205 = icmp ne i64 %cv7204, 0
  br i1 %cond7205, label %bb_rcslotdrop1827, label %bb_rcslotdone1827
bb_rcslotdrop1827:
  %v7206 = load i64, ptr %slot11, align 8
  %p7207 = inttoptr i64 %v7206 to ptr
  store i32 0, ptr %p7207, align 4, !alias.scope !3, !noalias !4
  %v7208 = load i64, ptr %slot41, align 8
  store i64 %v7208, ptr %slot1079, align 8
  %v7209 = load i64, ptr %slot12, align 8
  %p7210 = inttoptr i64 %v7209 to ptr
  %ld7211 = load i32, ptr %p7210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7211, ptr %slot1080, align 8
  %v7212 = load i32, ptr %slot1080, align 8
  %op7213 = and i32 %v7212, 28
  store i32 %op7213, ptr %slot1081, align 8
  %v7214 = load i32, ptr %slot1081, align 8
  %cv7215 = zext i32 %v7214 to i64
  %cond7216 = icmp ne i64 %cv7215, 0
  br i1 %cond7216, label %bb_rcslotrole1827, label %bb_rcslotowner1827
bb_rcslotrole1827:
  %v7217 = load i64, ptr %slot63, align 8
  store i64 %v7217, ptr %slot1082, align 8
  %v7218 = load i64, ptr %slot1079, align 8
  %p7219 = inttoptr i64 %v7218 to ptr
  %ld7220 = load i64, ptr %p7219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7220, ptr %slot1083, align 8
  %v7221 = load i64, ptr %slot1083, align 8
  %cmp7222 = icmp ne i64 %v7221, 0
  %cv7223 = zext i1 %cmp7222 to i32
  store i32 %cv7223, ptr %slot1084, align 8
  %v7224 = load i32, ptr %slot1084, align 8
  %cv7225 = zext i32 %v7224 to i64
  %cond7226 = icmp ne i64 %cv7225, 0
  br i1 %cond7226, label %bb_rcgnn1843, label %bb_rcgdone1843
bb_rcgnn1843:
  %v7227 = load i64, ptr %slot1083, align 8
  %op7228 = sub i64 %v7227, 16
  store i64 %op7228, ptr %slot1085, align 8
  %v7229 = load i64, ptr %slot1083, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  %rgep7231 = getelementptr i8, ptr %p7230, i64 -16
  %ld7232 = load i64, ptr %rgep7231, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7232, ptr %slot1086, align 8
  %v7233 = load i64, ptr %slot1086, align 8
  %op7234 = and i64 %v7233, 4611686018427387906
  store i64 %op7234, ptr %slot1087, align 8
  %v7235 = load i64, ptr %slot1087, align 8
  %cmp7236 = icmp ne i64 %v7235, 0
  %cv7237 = zext i1 %cmp7236 to i32
  store i32 %cv7237, ptr %slot1088, align 8
  %v7238 = load i32, ptr %slot1088, align 8
  %cv7239 = zext i32 %v7238 to i64
  %cond7240 = icmp ne i64 %cv7239, 0
  br i1 %cond7240, label %bb_rcgclear1843, label %bb_rcgcounted1843
bb_rcgcounted1843:
  %v7241 = load i64, ptr %slot1083, align 8
  %op7242 = sub i64 %v7241, 24
  store i64 %op7242, ptr %slot1089, align 8
  %v7243 = load i64, ptr %slot1083, align 8
  %p7244 = inttoptr i64 %v7243 to ptr
  %rgep7245 = getelementptr i8, ptr %p7244, i64 -24
  %ld7246 = load i64, ptr %rgep7245, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7246, ptr %slot1090, align 8
  %v7247 = load i64, ptr %slot1090, align 8
  %op7248 = sub i64 %v7247, 1
  store i64 %op7248, ptr %slot1091, align 8
  %v7249 = load i64, ptr %slot1091, align 8
  %cmp7250 = icmp eq i64 %v7249, 0
  %cv7251 = zext i1 %cmp7250 to i32
  store i32 %cv7251, ptr %slot1092, align 8
  %v7252 = load i32, ptr %slot1092, align 8
  %cv7253 = zext i32 %v7252 to i64
  %cond7254 = icmp ne i64 %cv7253, 0
  br i1 %cond7254, label %bb_rcglast1843, label %bb_rcgdec1843
bb_rcglast1843:
  %v7255 = load i64, ptr %slot1083, align 8
  %op7256 = sub i64 %v7255, 32
  store i64 %op7256, ptr %slot1093, align 8
  %v7257 = load i64, ptr %slot1083, align 8
  %p7258 = inttoptr i64 %v7257 to ptr
  %rgep7259 = getelementptr i8, ptr %p7258, i64 -32
  %ld7260 = load i64, ptr %rgep7259, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7260, ptr %slot1094, align 8
  %v7261 = load i64, ptr %slot1094, align 8
  %cmp7262 = icmp ne i64 %v7261, 0
  %cv7263 = zext i1 %cmp7262 to i32
  store i32 %cv7263, ptr %slot1095, align 8
  %v7264 = load i32, ptr %slot1095, align 8
  %cv7265 = zext i32 %v7264 to i64
  %cond7266 = icmp ne i64 %cv7265, 0
  br i1 %cond7266, label %bb_rcgdec1843, label %bb_rcgslow1843
bb_rcgslow1843:
  %v7267 = load i64, ptr %slot1082, align 8
  %v7268 = load i64, ptr %slot1079, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7267, i64 %v7268) nomerge, !dbg !170
  br label %bb_rcgdone1843
bb_rcgdec1843:
  %v7269 = load i64, ptr %slot1091, align 8
  %v7270 = load i64, ptr %slot1083, align 8
  %p7271 = inttoptr i64 %v7270 to ptr
  %rgep7272 = getelementptr i8, ptr %p7271, i64 -24
  store i64 %v7269, ptr %rgep7272, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1843
bb_rcgclear1843:
  %v7273 = load i64, ptr %slot1079, align 8
  %p7274 = inttoptr i64 %v7273 to ptr
  store i64 0, ptr %p7274, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1843
bb_rcgdone1843:
  br label %bb_rcslotdone1827
bb_rcslotowner1827:
  %v7275 = load i64, ptr %slot63, align 8
  store i64 %v7275, ptr %slot1096, align 8
  %v7276 = load i64, ptr %slot1079, align 8
  %p7277 = inttoptr i64 %v7276 to ptr
  %ld7278 = load i64, ptr %p7277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7278, ptr %slot1097, align 8
  %v7279 = load i64, ptr %slot1097, align 8
  %cmp7280 = icmp ne i64 %v7279, 0
  %cv7281 = zext i1 %cmp7280 to i32
  store i32 %cv7281, ptr %slot1098, align 8
  %v7282 = load i32, ptr %slot1098, align 8
  %cv7283 = zext i32 %v7282 to i64
  %cond7284 = icmp ne i64 %cv7283, 0
  br i1 %cond7284, label %bb_rcgnn1858, label %bb_rcgdone1858
bb_rcgnn1858:
  %v7285 = load i64, ptr %slot1097, align 8
  %op7286 = sub i64 %v7285, 16
  store i64 %op7286, ptr %slot1099, align 8
  %v7287 = load i64, ptr %slot1097, align 8
  %p7288 = inttoptr i64 %v7287 to ptr
  %rgep7289 = getelementptr i8, ptr %p7288, i64 -16
  %ld7290 = load i64, ptr %rgep7289, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7290, ptr %slot1100, align 8
  %v7291 = load i64, ptr %slot1100, align 8
  %op7292 = and i64 %v7291, 4611686018427387906
  store i64 %op7292, ptr %slot1101, align 8
  %v7293 = load i64, ptr %slot1101, align 8
  %cmp7294 = icmp ne i64 %v7293, 0
  %cv7295 = zext i1 %cmp7294 to i32
  store i32 %cv7295, ptr %slot1102, align 8
  %v7296 = load i32, ptr %slot1102, align 8
  %cv7297 = zext i32 %v7296 to i64
  %cond7298 = icmp ne i64 %cv7297, 0
  br i1 %cond7298, label %bb_rcgclear1858, label %bb_rcgcounted1858
bb_rcgcounted1858:
  %v7299 = load i64, ptr %slot1097, align 8
  %op7300 = sub i64 %v7299, 32
  store i64 %op7300, ptr %slot1103, align 8
  %v7301 = load i64, ptr %slot1097, align 8
  %p7302 = inttoptr i64 %v7301 to ptr
  %rgep7303 = getelementptr i8, ptr %p7302, i64 -32
  %ld7304 = load i64, ptr %rgep7303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7304, ptr %slot1104, align 8
  %v7305 = load i64, ptr %slot1104, align 8
  %op7306 = sub i64 %v7305, 1
  store i64 %op7306, ptr %slot1105, align 8
  %v7307 = load i64, ptr %slot1105, align 8
  %cmp7308 = icmp eq i64 %v7307, 0
  %cv7309 = zext i1 %cmp7308 to i32
  store i32 %cv7309, ptr %slot1106, align 8
  %v7310 = load i32, ptr %slot1106, align 8
  %cv7311 = zext i32 %v7310 to i64
  %cond7312 = icmp ne i64 %cv7311, 0
  br i1 %cond7312, label %bb_rcglast1858, label %bb_rcgdec1858
bb_rcglast1858:
  %v7313 = load i64, ptr %slot1097, align 8
  %op7314 = sub i64 %v7313, 24
  store i64 %op7314, ptr %slot1107, align 8
  %v7315 = load i64, ptr %slot1097, align 8
  %p7316 = inttoptr i64 %v7315 to ptr
  %rgep7317 = getelementptr i8, ptr %p7316, i64 -24
  %ld7318 = load i64, ptr %rgep7317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7318, ptr %slot1108, align 8
  %v7319 = load i64, ptr %slot1108, align 8
  %cmp7320 = icmp ne i64 %v7319, 0
  %cv7321 = zext i1 %cmp7320 to i32
  store i32 %cv7321, ptr %slot1109, align 8
  %v7322 = load i32, ptr %slot1109, align 8
  %cv7323 = zext i32 %v7322 to i64
  %cond7324 = icmp ne i64 %cv7323, 0
  br i1 %cond7324, label %bb_rcgdec1858, label %bb_rcgslow1858
bb_rcgslow1858:
  %v7325 = load i64, ptr %slot1096, align 8
  %v7326 = load i64, ptr %slot1079, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7325, i64 %v7326) nomerge, !dbg !170
  br label %bb_rcgdone1858
bb_rcgdec1858:
  %v7327 = load i64, ptr %slot1105, align 8
  %v7328 = load i64, ptr %slot1097, align 8
  %p7329 = inttoptr i64 %v7328 to ptr
  %rgep7330 = getelementptr i8, ptr %p7329, i64 -32
  store i64 %v7327, ptr %rgep7330, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1858
bb_rcgclear1858:
  %v7331 = load i64, ptr %slot1079, align 8
  %p7332 = inttoptr i64 %v7331 to ptr
  store i64 0, ptr %p7332, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1858
bb_rcgdone1858:
  br label %bb_rcslotdone1827
bb_rcslotdone1827:
  %v7333 = load i64, ptr %slot41, align 8
  store i64 %v7333, ptr %slot1110, align 8
  %v7334 = load i64, ptr %slot24, align 8
  store i64 %v7334, ptr %slot1111, align 8
  %v7335 = load i64, ptr %slot1111, align 8
  %v7336 = load i64, ptr %slot1110, align 8
  %p7337 = inttoptr i64 %v7335 to ptr
  %p7338 = inttoptr i64 %v7336 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7338, ptr %p7337, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7339 = load i64, ptr %slot19, align 8
  %p7340 = inttoptr i64 %v7339 to ptr
  store i32 0, ptr %p7340, align 4, !alias.scope !3, !noalias !4
  %v7341 = load i64, ptr %slot12, align 8
  %p7342 = inttoptr i64 %v7341 to ptr
  store i32 2, ptr %p7342, align 4, !alias.scope !3, !noalias !4
  %v7343 = load i64, ptr %slot20, align 8
  %p7344 = inttoptr i64 %v7343 to ptr
  %ld7345 = load i32, ptr %p7344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7345, ptr %slot1112, align 8
  %v7346 = load i32, ptr %slot1112, align 8
  %v7347 = load i64, ptr %slot12, align 8
  %p7348 = inttoptr i64 %v7347 to ptr
  store i32 %v7346, ptr %p7348, align 4, !alias.scope !3, !noalias !4
  %v7349 = load i64, ptr %slot11, align 8
  %p7350 = inttoptr i64 %v7349 to ptr
  store i32 1, ptr %p7350, align 4, !alias.scope !3, !noalias !4
  %v7351 = load i64, ptr %slot44, align 8
  %p7352 = inttoptr i64 %v7351 to ptr
  store i64 5, ptr %p7352, align 8, !alias.scope !3, !noalias !4
  %v7353 = load i64, ptr %slot44, align 8
  %p7354 = inttoptr i64 %v7353 to ptr
  %ld7355 = load i64, ptr %p7354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7355, ptr %slot1113, align 8
  %v7356 = load i64, ptr %slot1113, align 8
  %cmp7357 = icmp sge i64 %v7356, 0
  %cv7358 = zext i1 %cmp7357 to i64
  store i64 %cv7358, ptr %slot1114, align 8
  %v7359 = load i64, ptr %slot1114, align 8
  %cond7360 = icmp ne i64 %v7359, 0
  br i1 %cond7360, label %bb_success1871, label %bb_failed1871
bb_failed1871:
  %v7361 = load i64, ptr %slot1, align 8
  %p7362 = inttoptr i64 %v7361 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p7362) nomerge, !dbg !172
  unreachable
bb_success1871:
  %v7363 = load i64, ptr %slot63, align 8
  %p7364 = inttoptr i64 %v7363 to ptr
  %p7365 = inttoptr i64 ptrtoint (ptr @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a to i64) to ptr
  %v7366 = load i64, ptr %slot1113, align 8
  %call7367 = call ptr @myl_native_list_new(ptr %p7364, ptr %p7365, i64 %v7366) nomerge, !dbg !172
  %calladdr7368 = ptrtoint ptr %call7367 to i64
  store i64 %calladdr7368, ptr %slot1115, align 8
  %v7369 = load i64, ptr %slot1115, align 8
  %cond7370 = icmp ne i64 %v7369, 0
  br i1 %cond7370, label %bb_success1873, label %bb_failed1873
bb_failed1873:
  %v7371 = load i64, ptr %slot1, align 8
  %p7372 = inttoptr i64 %v7371 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7372) nomerge, !dbg !172
  unreachable
bb_success1873:
  %v7373 = load i64, ptr %slot1115, align 8
  %v7374 = load i64, ptr %slot44, align 8
  %p7375 = inttoptr i64 %v7374 to ptr
  store i64 %v7373, ptr %p7375, align 8, !alias.scope !3, !noalias !4
  %v7376 = load i64, ptr %slot44, align 8
  %p7377 = inttoptr i64 %v7376 to ptr
  %ld7378 = load i64, ptr %p7377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7378, ptr %slot1116, align 8
  %v7379 = load i64, ptr %slot1116, align 8
  %v7380 = load i64, ptr %slot23, align 8
  %p7381 = inttoptr i64 %v7380 to ptr
  store i64 %v7379, ptr %p7381, align 8, !alias.scope !3, !noalias !4
  %v7382 = load i64, ptr %slot23, align 8
  store i64 %v7382, ptr %slot1117, align 8
  %v7383 = load i64, ptr %slot24, align 8
  store i64 %v7383, ptr %slot1118, align 8
  %v7384 = load i64, ptr %slot1117, align 8
  %v7385 = load i64, ptr %slot1118, align 8
  %p7386 = inttoptr i64 %v7384 to ptr
  %p7387 = inttoptr i64 %v7385 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7387, ptr %p7386, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7388 = load i64, ptr %slot20, align 8
  %p7389 = inttoptr i64 %v7388 to ptr
  store i32 2, ptr %p7389, align 4, !alias.scope !3, !noalias !4
  %v7390 = load i64, ptr %slot19, align 8
  %p7391 = inttoptr i64 %v7390 to ptr
  store i32 1, ptr %p7391, align 4, !alias.scope !3, !noalias !4
  %v7392 = load i64, ptr %slot22, align 8
  store i64 %v7392, ptr %slot1119, align 8
  %v7393 = load i64, ptr %slot24, align 8
  store i64 %v7393, ptr %slot1120, align 8
  %v7394 = load i64, ptr %slot1120, align 8
  %v7395 = load i64, ptr %slot1119, align 8
  %p7396 = inttoptr i64 %v7394 to ptr
  %p7397 = inttoptr i64 %v7395 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7397, ptr %p7396, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7398 = load i64, ptr %slot18, align 8
  %p7399 = inttoptr i64 %v7398 to ptr
  store i32 2, ptr %p7399, align 4, !alias.scope !3, !noalias !4
  %v7400 = load i64, ptr %slot20, align 8
  %p7401 = inttoptr i64 %v7400 to ptr
  %ld7402 = load i32, ptr %p7401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7402, ptr %slot1121, align 8
  %v7403 = load i32, ptr %slot1121, align 8
  %v7404 = load i64, ptr %slot18, align 8
  %p7405 = inttoptr i64 %v7404 to ptr
  store i32 %v7403, ptr %p7405, align 4, !alias.scope !3, !noalias !4
  %v7406 = load i64, ptr %slot19, align 8
  %p7407 = inttoptr i64 %v7406 to ptr
  store i32 0, ptr %p7407, align 4, !alias.scope !3, !noalias !4
  %v7408 = load i64, ptr %slot17, align 8
  %p7409 = inttoptr i64 %v7408 to ptr
  store i32 1, ptr %p7409, align 4, !alias.scope !3, !noalias !4
  %v7410 = load i64, ptr %slot1119, align 8
  %p7411 = inttoptr i64 %v7410 to ptr
  %ld7412 = load i64, ptr %p7411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7412, ptr %slot1122, align 8
  %v7413 = load i64, ptr %slot1122, align 8
  %v7414 = load i64, ptr %slot44, align 8
  %p7415 = inttoptr i64 %v7414 to ptr
  store i64 %v7413, ptr %p7415, align 8, !alias.scope !3, !noalias !4
  %v7416 = load i64, ptr %slot44, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  %ld7418 = load i64, ptr %p7417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7418, ptr %slot1123, align 8
  %v7419 = load i64, ptr %slot1123, align 8
  %v7420 = load i64, ptr %slot23, align 8
  %p7421 = inttoptr i64 %v7420 to ptr
  store i64 %v7419, ptr %p7421, align 8, !alias.scope !3, !noalias !4
  %v7422 = load i64, ptr %slot23, align 8
  store i64 %v7422, ptr %slot1124, align 8
  %v7423 = load i64, ptr %slot17, align 8
  %p7424 = inttoptr i64 %v7423 to ptr
  %ld7425 = load i32, ptr %p7424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7425, ptr %slot1125, align 8
  %v7426 = load i64, ptr %slot18, align 8
  %p7427 = inttoptr i64 %v7426 to ptr
  %ld7428 = load i32, ptr %p7427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7428, ptr %slot1126, align 8
  %v7429 = load i32, ptr %slot1126, align 8
  %op7430 = and i32 %v7429, 24
  store i32 %op7430, ptr %slot1126, align 8
  %v7431 = load i32, ptr %slot1126, align 8
  %cmp7432 = icmp eq i32 %v7431, 0
  %cv7433 = zext i1 %cmp7432 to i32
  store i32 %cv7433, ptr %slot1127, align 8
  %v7434 = load i32, ptr %slot1125, align 8
  %v7435 = load i32, ptr %slot1127, align 8
  %op7436 = and i32 %v7434, %v7435
  store i32 %op7436, ptr %slot1128, align 8
  %v7437 = load i32, ptr %slot1128, align 8
  %cv7438 = zext i32 %v7437 to i64
  %cond7439 = icmp ne i64 %cv7438, 0
  br i1 %cond7439, label %bb_rcprivateown1896, label %bb_rcprivateloan1896
bb_rcprivateown1896:
  %v7440 = load i64, ptr %slot24, align 8
  store i64 %v7440, ptr %slot1129, align 8
  %v7441 = load i64, ptr %slot64, align 8
  store i64 %v7441, ptr %slot1130, align 8
  %v7442 = load i64, ptr %slot1124, align 8
  %v7443 = load i64, ptr %slot1129, align 8
  %op7444 = sub i64 %v7442, %v7443
  store i64 %op7444, ptr %slot1131, align 8
  %v7445 = load i64, ptr %slot1129, align 8
  %v7446 = load i64, ptr %slot1124, align 8
  %op7447 = sub i64 %v7445, %v7446
  store i64 %op7447, ptr %slot1132, align 8
  %v7448 = load i64, ptr %slot1131, align 8
  %cmp7449 = icmp ult i64 %v7448, 8
  %cv7450 = zext i1 %cmp7449 to i32
  store i32 %cv7450, ptr %slot1133, align 8
  %v7451 = load i64, ptr %slot1132, align 8
  %cmp7452 = icmp ult i64 %v7451, 8
  %cv7453 = zext i1 %cmp7452 to i32
  store i32 %cv7453, ptr %slot1134, align 8
  %v7454 = load i32, ptr %slot1133, align 8
  %v7455 = load i32, ptr %slot1134, align 8
  %op7456 = or i32 %v7454, %v7455
  store i32 %op7456, ptr %slot1135, align 8
  %v7457 = load i32, ptr %slot1135, align 8
  %cv7458 = zext i32 %v7457 to i64
  %cond7459 = icmp ne i64 %cv7458, 0
  br i1 %cond7459, label %bb_rcmoveslow1899, label %bb_rcmovecheck1899
bb_rcmovecheck1899:
  %v7460 = load i64, ptr %slot1124, align 8
  %p7462 = inttoptr i64 %v7460 to ptr
  %gep7463 = getelementptr i8, ptr %p7462, i64 0
  %op7461 = ptrtoint ptr %gep7463 to i64
  store i64 %op7461, ptr %slot1136, align 8
  %v7464 = load i64, ptr %slot1136, align 8
  %p7465 = inttoptr i64 %v7464 to ptr
  %ld7466 = load i64, ptr %p7465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7466, ptr %slot1137, align 8
  %v7467 = load i64, ptr %slot1137, align 8
  %cmp7468 = icmp ne i64 %v7467, 0
  %cv7469 = zext i1 %cmp7468 to i32
  store i32 %cv7469, ptr %slot1138, align 8
  %v7470 = load i32, ptr %slot1138, align 8
  %cv7471 = zext i32 %v7470 to i64
  %cond7472 = icmp ne i64 %cv7471, 0
  br i1 %cond7472, label %bb_rcmoveheader1907, label %bb_rcmovenext1907
bb_rcmoveheader1907:
  %v7473 = load i64, ptr %slot1137, align 8
  %op7474 = sub i64 %v7473, 16
  store i64 %op7474, ptr %slot1139, align 8
  %v7475 = load i64, ptr %slot1137, align 8
  %p7476 = inttoptr i64 %v7475 to ptr
  %rgep7477 = getelementptr i8, ptr %p7476, i64 -16
  %ld7478 = load i64, ptr %rgep7477, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7478, ptr %slot1140, align 8
  %v7479 = load i64, ptr %slot1140, align 8
  %op7480 = and i64 %v7479, 5764607523034234881
  store i64 %op7480, ptr %slot1141, align 8
  %v7481 = load i64, ptr %slot1141, align 8
  %cmp7482 = icmp ne i64 %v7481, 0
  %cv7483 = zext i1 %cmp7482 to i32
  store i32 %cv7483, ptr %slot1142, align 8
  %v7484 = load i32, ptr %slot1142, align 8
  %cv7485 = zext i32 %v7484 to i64
  %cond7486 = icmp ne i64 %cv7485, 0
  br i1 %cond7486, label %bb_rcmoveslow1899, label %bb_rcmovenext1907
bb_rcmovenext1907:
  %v7487 = load i64, ptr %slot1124, align 8
  %v7488 = load i64, ptr %slot1129, align 8
  %p7489 = inttoptr i64 %v7487 to ptr
  %p7490 = inttoptr i64 %v7488 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7490, ptr %p7489, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7491 = load i64, ptr %slot1124, align 8
  %p7492 = inttoptr i64 %v7491 to ptr
  store i64 0, ptr %p7492, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1899
bb_rcmoveslow1899:
  %v7493 = load i64, ptr %slot63, align 8
  %v7494 = load i64, ptr %slot1129, align 8
  %v7495 = load i64, ptr %slot1124, align 8
  %v7496 = load i64, ptr %slot1130, align 8
  %cv7497 = trunc i64 %v7496 to i32
  %call7498 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64 %v7493, i64 %v7494, i64 %v7495, i32 %cv7497) nomerge, !dbg !174
  store i32 %call7498, ptr %slot1143, align 8
  %v7499 = load i32, ptr %slot1143, align 8
  %cv7500 = zext i32 %v7499 to i64
  %cond7501 = icmp ne i64 %cv7500, 0
  br i1 %cond7501, label %bb_rcsuccess1914, label %bb_rcfailure1914
bb_rcfailure1914:
  %v7502 = load i64, ptr %slot63, align 8
  %p7503 = inttoptr i64 %v7502 to ptr
  %call7504 = call i32 @myl_rc_take_failure(ptr %p7503) nomerge, !dbg !174
  store i32 %call7504, ptr %slot1144, align 8
  %v7505 = load i64, ptr %slot1, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  %v7507 = load i32, ptr %slot1144, align 8
  %call7508 = call i32 @myl_qbe_rc_status(ptr %p7506, i32 %v7507) nomerge, !dbg !174
  store i32 %call7508, ptr %slot1145, align 8
  br label %bb_failure
bb_rcsuccess1914:
  br label %bb_rcmoved1899
bb_rcmoved1899:
  %v7509 = load i64, ptr %slot17, align 8
  %p7510 = inttoptr i64 %v7509 to ptr
  store i32 0, ptr %p7510, align 4, !alias.scope !3, !noalias !4
  %v7511 = load i64, ptr %slot20, align 8
  %p7512 = inttoptr i64 %v7511 to ptr
  store i32 2, ptr %p7512, align 4, !alias.scope !3, !noalias !4
  %v7513 = load i64, ptr %slot19, align 8
  %p7514 = inttoptr i64 %v7513 to ptr
  store i32 1, ptr %p7514, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1896
bb_rcprivateloan1896:
  %v7515 = load i64, ptr %slot17, align 8
  %p7516 = inttoptr i64 %v7515 to ptr
  %ld7517 = load i32, ptr %p7516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7517, ptr %slot1146, align 8
  %v7518 = load i64, ptr %slot18, align 8
  %p7519 = inttoptr i64 %v7518 to ptr
  %ld7520 = load i32, ptr %p7519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7520, ptr %slot1147, align 8
  %v7521 = load i32, ptr %slot1147, align 8
  %cmp7522 = icmp eq i32 %v7521, 16
  %cv7523 = zext i1 %cmp7522 to i32
  store i32 %cv7523, ptr %slot1148, align 8
  %v7524 = load i32, ptr %slot1148, align 8
  %v7525 = load i32, ptr %slot1146, align 8
  %op7526 = and i32 %v7524, %v7525
  store i32 %op7526, ptr %slot1148, align 8
  %v7527 = load i32, ptr %slot1148, align 8
  %cv7528 = zext i32 %v7527 to i64
  %cond7529 = icmp ne i64 %cv7528, 0
  br i1 %cond7529, label %bb_rcprivatemove1896, label %bb_rcprivatenew1896
bb_rcprivatemove1896:
  %v7530 = load i64, ptr %slot24, align 8
  store i64 %v7530, ptr %slot1149, align 8
  %v7531 = load i64, ptr %slot1124, align 8
  %v7532 = load i64, ptr %slot1149, align 8
  %p7533 = inttoptr i64 %v7531 to ptr
  %p7534 = inttoptr i64 %v7532 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7534, ptr %p7533, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7535 = load i64, ptr %slot1124, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  store i64 0, ptr %p7536, align 8, !alias.scope !3, !noalias !4
  %v7537 = load i64, ptr %slot20, align 8
  %p7538 = inttoptr i64 %v7537 to ptr
  store i32 2, ptr %p7538, align 4, !alias.scope !3, !noalias !4
  %v7539 = load i64, ptr %slot20, align 8
  %p7540 = inttoptr i64 %v7539 to ptr
  store i32 16, ptr %p7540, align 4, !alias.scope !3, !noalias !4
  %v7541 = load i64, ptr %slot19, align 8
  %p7542 = inttoptr i64 %v7541 to ptr
  store i32 1, ptr %p7542, align 4, !alias.scope !3, !noalias !4
  %v7543 = load i64, ptr %slot17, align 8
  %p7544 = inttoptr i64 %v7543 to ptr
  store i32 0, ptr %p7544, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1896
bb_rcprivatenew1896:
  %v7545 = load i64, ptr %slot24, align 8
  store i64 %v7545, ptr %slot1150, align 8
  %v7546 = load i64, ptr %slot1124, align 8
  %p7547 = inttoptr i64 %v7546 to ptr
  %ld7548 = load i64, ptr %p7547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7548, ptr %slot1151, align 8
  %v7549 = load i64, ptr %slot1151, align 8
  %cmp7550 = icmp ne i64 %v7549, 0
  %cv7551 = zext i1 %cmp7550 to i32
  store i32 %cv7551, ptr %slot1152, align 8
  %v7552 = load i32, ptr %slot1152, align 8
  %cv7553 = zext i32 %v7552 to i64
  %cond7554 = icmp ne i64 %cv7553, 0
  br i1 %cond7554, label %bb_rcgnn1932, label %bb_rcgstore1932
bb_rcgnn1932:
  %v7555 = load i64, ptr %slot1151, align 8
  %op7556 = sub i64 %v7555, 16
  store i64 %op7556, ptr %slot1153, align 8
  %v7557 = load i64, ptr %slot1151, align 8
  %p7558 = inttoptr i64 %v7557 to ptr
  %rgep7559 = getelementptr i8, ptr %p7558, i64 -16
  %ld7560 = load i64, ptr %rgep7559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7560, ptr %slot1154, align 8
  %v7561 = load i64, ptr %slot1154, align 8
  %op7562 = and i64 %v7561, 4611686018427387906
  store i64 %op7562, ptr %slot1155, align 8
  %v7563 = load i64, ptr %slot1155, align 8
  %cmp7564 = icmp ne i64 %v7563, 0
  %cv7565 = zext i1 %cmp7564 to i32
  store i32 %cv7565, ptr %slot1156, align 8
  %v7566 = load i32, ptr %slot1156, align 8
  %cv7567 = zext i32 %v7566 to i64
  %cond7568 = icmp ne i64 %cv7567, 0
  br i1 %cond7568, label %bb_rcgstore1932, label %bb_rcginc1932
bb_rcginc1932:
  %v7569 = load i64, ptr %slot1151, align 8
  %op7570 = sub i64 %v7569, 24
  store i64 %op7570, ptr %slot1157, align 8
  %v7571 = load i64, ptr %slot1151, align 8
  %p7572 = inttoptr i64 %v7571 to ptr
  %rgep7573 = getelementptr i8, ptr %p7572, i64 -24
  %ld7574 = load i64, ptr %rgep7573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7574, ptr %slot1158, align 8
  %v7575 = load i64, ptr %slot1158, align 8
  %op7576 = add i64 %v7575, 1
  store i64 %op7576, ptr %slot1159, align 8
  %v7577 = load i64, ptr %slot1159, align 8
  %cmp7578 = icmp eq i64 %v7577, 0
  %cv7579 = zext i1 %cmp7578 to i32
  store i32 %cv7579, ptr %slot1160, align 8
  %v7580 = load i32, ptr %slot1160, align 8
  %cv7581 = zext i32 %v7580 to i64
  %cond7582 = icmp ne i64 %cv7581, 0
  br i1 %cond7582, label %bb_rcglimit1932, label %bb_rcgcapacity1932
bb_rcglimit1932:
  %v7583 = load i64, ptr %slot1, align 8
  %p7584 = inttoptr i64 %v7583 to ptr
  %call7585 = call i32 @myl_qbe_rc_status(ptr %p7584, i32 2) nomerge, !dbg !174
  store i32 %call7585, ptr %slot1161, align 8
  br label %bb_failure
bb_rcgcapacity1932:
  %v7586 = load i64, ptr %slot1159, align 8
  %v7587 = load i64, ptr %slot1151, align 8
  %p7588 = inttoptr i64 %v7587 to ptr
  %rgep7589 = getelementptr i8, ptr %p7588, i64 -24
  store i64 %v7586, ptr %rgep7589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1932
bb_rcgstore1932:
  %v7590 = load i64, ptr %slot1151, align 8
  %v7591 = load i64, ptr %slot1150, align 8
  %p7592 = inttoptr i64 %v7591 to ptr
  store i64 %v7590, ptr %p7592, align 8, !alias.scope !3, !noalias !4
  %v7593 = load i64, ptr %slot20, align 8
  %p7594 = inttoptr i64 %v7593 to ptr
  store i32 2, ptr %p7594, align 4, !alias.scope !3, !noalias !4
  %v7595 = load i64, ptr %slot20, align 8
  %p7596 = inttoptr i64 %v7595 to ptr
  store i32 16, ptr %p7596, align 4, !alias.scope !3, !noalias !4
  %v7597 = load i64, ptr %slot19, align 8
  %p7598 = inttoptr i64 %v7597 to ptr
  store i32 1, ptr %p7598, align 4, !alias.scope !3, !noalias !4
  %v7599 = load i64, ptr %slot17, align 8
  %p7600 = inttoptr i64 %v7599 to ptr
  %ld7601 = load i32, ptr %p7600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7601, ptr %slot1162, align 8
  %v7602 = load i32, ptr %slot1162, align 8
  %cv7603 = zext i32 %v7602 to i64
  %cond7604 = icmp ne i64 %cv7603, 0
  br i1 %cond7604, label %bb_rcslotdrop1948, label %bb_rcslotdone1948
bb_rcslotdrop1948:
  %v7605 = load i64, ptr %slot17, align 8
  %p7606 = inttoptr i64 %v7605 to ptr
  store i32 0, ptr %p7606, align 4, !alias.scope !3, !noalias !4
  %v7607 = load i64, ptr %slot22, align 8
  store i64 %v7607, ptr %slot1163, align 8
  %v7608 = load i64, ptr %slot18, align 8
  %p7609 = inttoptr i64 %v7608 to ptr
  %ld7610 = load i32, ptr %p7609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7610, ptr %slot1164, align 8
  %v7611 = load i32, ptr %slot1164, align 8
  %op7612 = and i32 %v7611, 28
  store i32 %op7612, ptr %slot1165, align 8
  %v7613 = load i32, ptr %slot1165, align 8
  %cv7614 = zext i32 %v7613 to i64
  %cond7615 = icmp ne i64 %cv7614, 0
  br i1 %cond7615, label %bb_rcslotrole1948, label %bb_rcslotowner1948
bb_rcslotrole1948:
  %v7616 = load i64, ptr %slot63, align 8
  store i64 %v7616, ptr %slot1166, align 8
  %v7617 = load i64, ptr %slot1163, align 8
  %p7618 = inttoptr i64 %v7617 to ptr
  %ld7619 = load i64, ptr %p7618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7619, ptr %slot1167, align 8
  %v7620 = load i64, ptr %slot1167, align 8
  %cmp7621 = icmp ne i64 %v7620, 0
  %cv7622 = zext i1 %cmp7621 to i32
  store i32 %cv7622, ptr %slot1168, align 8
  %v7623 = load i32, ptr %slot1168, align 8
  %cv7624 = zext i32 %v7623 to i64
  %cond7625 = icmp ne i64 %cv7624, 0
  br i1 %cond7625, label %bb_rcgnn1964, label %bb_rcgdone1964
bb_rcgnn1964:
  %v7626 = load i64, ptr %slot1167, align 8
  %op7627 = sub i64 %v7626, 16
  store i64 %op7627, ptr %slot1169, align 8
  %v7628 = load i64, ptr %slot1167, align 8
  %p7629 = inttoptr i64 %v7628 to ptr
  %rgep7630 = getelementptr i8, ptr %p7629, i64 -16
  %ld7631 = load i64, ptr %rgep7630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7631, ptr %slot1170, align 8
  %v7632 = load i64, ptr %slot1170, align 8
  %op7633 = and i64 %v7632, 4611686018427387906
  store i64 %op7633, ptr %slot1171, align 8
  %v7634 = load i64, ptr %slot1171, align 8
  %cmp7635 = icmp ne i64 %v7634, 0
  %cv7636 = zext i1 %cmp7635 to i32
  store i32 %cv7636, ptr %slot1172, align 8
  %v7637 = load i32, ptr %slot1172, align 8
  %cv7638 = zext i32 %v7637 to i64
  %cond7639 = icmp ne i64 %cv7638, 0
  br i1 %cond7639, label %bb_rcgclear1964, label %bb_rcgcounted1964
bb_rcgcounted1964:
  %v7640 = load i64, ptr %slot1167, align 8
  %op7641 = sub i64 %v7640, 24
  store i64 %op7641, ptr %slot1173, align 8
  %v7642 = load i64, ptr %slot1167, align 8
  %p7643 = inttoptr i64 %v7642 to ptr
  %rgep7644 = getelementptr i8, ptr %p7643, i64 -24
  %ld7645 = load i64, ptr %rgep7644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7645, ptr %slot1174, align 8
  %v7646 = load i64, ptr %slot1174, align 8
  %op7647 = sub i64 %v7646, 1
  store i64 %op7647, ptr %slot1175, align 8
  %v7648 = load i64, ptr %slot1175, align 8
  %cmp7649 = icmp eq i64 %v7648, 0
  %cv7650 = zext i1 %cmp7649 to i32
  store i32 %cv7650, ptr %slot1176, align 8
  %v7651 = load i32, ptr %slot1176, align 8
  %cv7652 = zext i32 %v7651 to i64
  %cond7653 = icmp ne i64 %cv7652, 0
  br i1 %cond7653, label %bb_rcglast1964, label %bb_rcgdec1964
bb_rcglast1964:
  %v7654 = load i64, ptr %slot1167, align 8
  %op7655 = sub i64 %v7654, 32
  store i64 %op7655, ptr %slot1177, align 8
  %v7656 = load i64, ptr %slot1167, align 8
  %p7657 = inttoptr i64 %v7656 to ptr
  %rgep7658 = getelementptr i8, ptr %p7657, i64 -32
  %ld7659 = load i64, ptr %rgep7658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7659, ptr %slot1178, align 8
  %v7660 = load i64, ptr %slot1178, align 8
  %cmp7661 = icmp ne i64 %v7660, 0
  %cv7662 = zext i1 %cmp7661 to i32
  store i32 %cv7662, ptr %slot1179, align 8
  %v7663 = load i32, ptr %slot1179, align 8
  %cv7664 = zext i32 %v7663 to i64
  %cond7665 = icmp ne i64 %cv7664, 0
  br i1 %cond7665, label %bb_rcgdec1964, label %bb_rcgslow1964
bb_rcgslow1964:
  %v7666 = load i64, ptr %slot1166, align 8
  %v7667 = load i64, ptr %slot1163, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v7666, i64 %v7667) nomerge, !dbg !174
  br label %bb_rcgdone1964
bb_rcgdec1964:
  %v7668 = load i64, ptr %slot1175, align 8
  %v7669 = load i64, ptr %slot1167, align 8
  %p7670 = inttoptr i64 %v7669 to ptr
  %rgep7671 = getelementptr i8, ptr %p7670, i64 -24
  store i64 %v7668, ptr %rgep7671, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1964
bb_rcgclear1964:
  %v7672 = load i64, ptr %slot1163, align 8
  %p7673 = inttoptr i64 %v7672 to ptr
  store i64 0, ptr %p7673, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1964
bb_rcgdone1964:
  br label %bb_rcslotdone1948
bb_rcslotowner1948:
  %v7674 = load i64, ptr %slot63, align 8
  store i64 %v7674, ptr %slot1180, align 8
  %v7675 = load i64, ptr %slot1163, align 8
  %p7676 = inttoptr i64 %v7675 to ptr
  %ld7677 = load i64, ptr %p7676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7677, ptr %slot1181, align 8
  %v7678 = load i64, ptr %slot1181, align 8
  %cmp7679 = icmp ne i64 %v7678, 0
  %cv7680 = zext i1 %cmp7679 to i32
  store i32 %cv7680, ptr %slot1182, align 8
  %v7681 = load i32, ptr %slot1182, align 8
  %cv7682 = zext i32 %v7681 to i64
  %cond7683 = icmp ne i64 %cv7682, 0
  br i1 %cond7683, label %bb_rcgnn1979, label %bb_rcgdone1979
bb_rcgnn1979:
  %v7684 = load i64, ptr %slot1181, align 8
  %op7685 = sub i64 %v7684, 16
  store i64 %op7685, ptr %slot1183, align 8
  %v7686 = load i64, ptr %slot1181, align 8
  %p7687 = inttoptr i64 %v7686 to ptr
  %rgep7688 = getelementptr i8, ptr %p7687, i64 -16
  %ld7689 = load i64, ptr %rgep7688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7689, ptr %slot1184, align 8
  %v7690 = load i64, ptr %slot1184, align 8
  %op7691 = and i64 %v7690, 4611686018427387906
  store i64 %op7691, ptr %slot1185, align 8
  %v7692 = load i64, ptr %slot1185, align 8
  %cmp7693 = icmp ne i64 %v7692, 0
  %cv7694 = zext i1 %cmp7693 to i32
  store i32 %cv7694, ptr %slot1186, align 8
  %v7695 = load i32, ptr %slot1186, align 8
  %cv7696 = zext i32 %v7695 to i64
  %cond7697 = icmp ne i64 %cv7696, 0
  br i1 %cond7697, label %bb_rcgclear1979, label %bb_rcgcounted1979
bb_rcgcounted1979:
  %v7698 = load i64, ptr %slot1181, align 8
  %op7699 = sub i64 %v7698, 32
  store i64 %op7699, ptr %slot1187, align 8
  %v7700 = load i64, ptr %slot1181, align 8
  %p7701 = inttoptr i64 %v7700 to ptr
  %rgep7702 = getelementptr i8, ptr %p7701, i64 -32
  %ld7703 = load i64, ptr %rgep7702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7703, ptr %slot1188, align 8
  %v7704 = load i64, ptr %slot1188, align 8
  %op7705 = sub i64 %v7704, 1
  store i64 %op7705, ptr %slot1189, align 8
  %v7706 = load i64, ptr %slot1189, align 8
  %cmp7707 = icmp eq i64 %v7706, 0
  %cv7708 = zext i1 %cmp7707 to i32
  store i32 %cv7708, ptr %slot1190, align 8
  %v7709 = load i32, ptr %slot1190, align 8
  %cv7710 = zext i32 %v7709 to i64
  %cond7711 = icmp ne i64 %cv7710, 0
  br i1 %cond7711, label %bb_rcglast1979, label %bb_rcgdec1979
bb_rcglast1979:
  %v7712 = load i64, ptr %slot1181, align 8
  %op7713 = sub i64 %v7712, 24
  store i64 %op7713, ptr %slot1191, align 8
  %v7714 = load i64, ptr %slot1181, align 8
  %p7715 = inttoptr i64 %v7714 to ptr
  %rgep7716 = getelementptr i8, ptr %p7715, i64 -24
  %ld7717 = load i64, ptr %rgep7716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7717, ptr %slot1192, align 8
  %v7718 = load i64, ptr %slot1192, align 8
  %cmp7719 = icmp ne i64 %v7718, 0
  %cv7720 = zext i1 %cmp7719 to i32
  store i32 %cv7720, ptr %slot1193, align 8
  %v7721 = load i32, ptr %slot1193, align 8
  %cv7722 = zext i32 %v7721 to i64
  %cond7723 = icmp ne i64 %cv7722, 0
  br i1 %cond7723, label %bb_rcgdec1979, label %bb_rcgslow1979
bb_rcgslow1979:
  %v7724 = load i64, ptr %slot1180, align 8
  %v7725 = load i64, ptr %slot1163, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v7724, i64 %v7725) nomerge, !dbg !174
  br label %bb_rcgdone1979
bb_rcgdec1979:
  %v7726 = load i64, ptr %slot1189, align 8
  %v7727 = load i64, ptr %slot1181, align 8
  %p7728 = inttoptr i64 %v7727 to ptr
  %rgep7729 = getelementptr i8, ptr %p7728, i64 -32
  store i64 %v7726, ptr %rgep7729, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1979
bb_rcgclear1979:
  %v7730 = load i64, ptr %slot1163, align 8
  %p7731 = inttoptr i64 %v7730 to ptr
  store i64 0, ptr %p7731, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1979
bb_rcgdone1979:
  br label %bb_rcslotdone1948
bb_rcslotdone1948:
  br label %bb_rcprivateprepared1896
bb_rcprivateprepared1896:
  %v7732 = load i64, ptr %slot9, align 8
  %p7733 = inttoptr i64 %v7732 to ptr
  %ld7734 = load i32, ptr %p7733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7734, ptr %slot1194, align 8
  %v7735 = load i32, ptr %slot1194, align 8
  %cv7736 = zext i32 %v7735 to i64
  %cond7737 = icmp ne i64 %cv7736, 0
  br i1 %cond7737, label %bb_rcslotdrop1986, label %bb_rcslotdone1986
bb_rcslotdrop1986:
  %v7738 = load i64, ptr %slot9, align 8
  %p7739 = inttoptr i64 %v7738 to ptr
  store i32 0, ptr %p7739, align 4, !alias.scope !3, !noalias !4
  %v7740 = load i64, ptr %slot40, align 8
  store i64 %v7740, ptr %slot1195, align 8
  %v7741 = load i64, ptr %slot10, align 8
  %p7742 = inttoptr i64 %v7741 to ptr
  %ld7743 = load i32, ptr %p7742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7743, ptr %slot1196, align 8
  %v7744 = load i32, ptr %slot1196, align 8
  %op7745 = and i32 %v7744, 28
  store i32 %op7745, ptr %slot1197, align 8
  %v7746 = load i32, ptr %slot1197, align 8
  %cv7747 = zext i32 %v7746 to i64
  %cond7748 = icmp ne i64 %cv7747, 0
  br i1 %cond7748, label %bb_rcslotrole1986, label %bb_rcslotowner1986
bb_rcslotrole1986:
  %v7749 = load i64, ptr %slot63, align 8
  store i64 %v7749, ptr %slot1198, align 8
  %v7750 = load i64, ptr %slot1195, align 8
  %p7751 = inttoptr i64 %v7750 to ptr
  %ld7752 = load i64, ptr %p7751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7752, ptr %slot1199, align 8
  %v7753 = load i64, ptr %slot1199, align 8
  %cmp7754 = icmp ne i64 %v7753, 0
  %cv7755 = zext i1 %cmp7754 to i32
  store i32 %cv7755, ptr %slot1200, align 8
  %v7756 = load i32, ptr %slot1200, align 8
  %cv7757 = zext i32 %v7756 to i64
  %cond7758 = icmp ne i64 %cv7757, 0
  br i1 %cond7758, label %bb_rcgnn2002, label %bb_rcgdone2002
bb_rcgnn2002:
  %v7759 = load i64, ptr %slot1199, align 8
  %op7760 = sub i64 %v7759, 16
  store i64 %op7760, ptr %slot1201, align 8
  %v7761 = load i64, ptr %slot1199, align 8
  %p7762 = inttoptr i64 %v7761 to ptr
  %rgep7763 = getelementptr i8, ptr %p7762, i64 -16
  %ld7764 = load i64, ptr %rgep7763, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7764, ptr %slot1202, align 8
  %v7765 = load i64, ptr %slot1202, align 8
  %op7766 = and i64 %v7765, 4611686018427387906
  store i64 %op7766, ptr %slot1203, align 8
  %v7767 = load i64, ptr %slot1203, align 8
  %cmp7768 = icmp ne i64 %v7767, 0
  %cv7769 = zext i1 %cmp7768 to i32
  store i32 %cv7769, ptr %slot1204, align 8
  %v7770 = load i32, ptr %slot1204, align 8
  %cv7771 = zext i32 %v7770 to i64
  %cond7772 = icmp ne i64 %cv7771, 0
  br i1 %cond7772, label %bb_rcgclear2002, label %bb_rcgcounted2002
bb_rcgcounted2002:
  %v7773 = load i64, ptr %slot1199, align 8
  %op7774 = sub i64 %v7773, 24
  store i64 %op7774, ptr %slot1205, align 8
  %v7775 = load i64, ptr %slot1199, align 8
  %p7776 = inttoptr i64 %v7775 to ptr
  %rgep7777 = getelementptr i8, ptr %p7776, i64 -24
  %ld7778 = load i64, ptr %rgep7777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7778, ptr %slot1206, align 8
  %v7779 = load i64, ptr %slot1206, align 8
  %op7780 = sub i64 %v7779, 1
  store i64 %op7780, ptr %slot1207, align 8
  %v7781 = load i64, ptr %slot1207, align 8
  %cmp7782 = icmp eq i64 %v7781, 0
  %cv7783 = zext i1 %cmp7782 to i32
  store i32 %cv7783, ptr %slot1208, align 8
  %v7784 = load i32, ptr %slot1208, align 8
  %cv7785 = zext i32 %v7784 to i64
  %cond7786 = icmp ne i64 %cv7785, 0
  br i1 %cond7786, label %bb_rcglast2002, label %bb_rcgdec2002
bb_rcglast2002:
  %v7787 = load i64, ptr %slot1199, align 8
  %op7788 = sub i64 %v7787, 32
  store i64 %op7788, ptr %slot1209, align 8
  %v7789 = load i64, ptr %slot1199, align 8
  %p7790 = inttoptr i64 %v7789 to ptr
  %rgep7791 = getelementptr i8, ptr %p7790, i64 -32
  %ld7792 = load i64, ptr %rgep7791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7792, ptr %slot1210, align 8
  %v7793 = load i64, ptr %slot1210, align 8
  %cmp7794 = icmp ne i64 %v7793, 0
  %cv7795 = zext i1 %cmp7794 to i32
  store i32 %cv7795, ptr %slot1211, align 8
  %v7796 = load i32, ptr %slot1211, align 8
  %cv7797 = zext i32 %v7796 to i64
  %cond7798 = icmp ne i64 %cv7797, 0
  br i1 %cond7798, label %bb_rcgdec2002, label %bb_rcgslow2002
bb_rcgslow2002:
  %v7799 = load i64, ptr %slot1198, align 8
  %v7800 = load i64, ptr %slot1195, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v7799, i64 %v7800) nomerge, !dbg !174
  br label %bb_rcgdone2002
bb_rcgdec2002:
  %v7801 = load i64, ptr %slot1207, align 8
  %v7802 = load i64, ptr %slot1199, align 8
  %p7803 = inttoptr i64 %v7802 to ptr
  %rgep7804 = getelementptr i8, ptr %p7803, i64 -24
  store i64 %v7801, ptr %rgep7804, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2002
bb_rcgclear2002:
  %v7805 = load i64, ptr %slot1195, align 8
  %p7806 = inttoptr i64 %v7805 to ptr
  store i64 0, ptr %p7806, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2002
bb_rcgdone2002:
  br label %bb_rcslotdone1986
bb_rcslotowner1986:
  %v7807 = load i64, ptr %slot63, align 8
  store i64 %v7807, ptr %slot1212, align 8
  %v7808 = load i64, ptr %slot1195, align 8
  %p7809 = inttoptr i64 %v7808 to ptr
  %ld7810 = load i64, ptr %p7809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7810, ptr %slot1213, align 8
  %v7811 = load i64, ptr %slot1213, align 8
  %cmp7812 = icmp ne i64 %v7811, 0
  %cv7813 = zext i1 %cmp7812 to i32
  store i32 %cv7813, ptr %slot1214, align 8
  %v7814 = load i32, ptr %slot1214, align 8
  %cv7815 = zext i32 %v7814 to i64
  %cond7816 = icmp ne i64 %cv7815, 0
  br i1 %cond7816, label %bb_rcgnn2017, label %bb_rcgdone2017
bb_rcgnn2017:
  %v7817 = load i64, ptr %slot1213, align 8
  %op7818 = sub i64 %v7817, 16
  store i64 %op7818, ptr %slot1215, align 8
  %v7819 = load i64, ptr %slot1213, align 8
  %p7820 = inttoptr i64 %v7819 to ptr
  %rgep7821 = getelementptr i8, ptr %p7820, i64 -16
  %ld7822 = load i64, ptr %rgep7821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7822, ptr %slot1216, align 8
  %v7823 = load i64, ptr %slot1216, align 8
  %op7824 = and i64 %v7823, 4611686018427387906
  store i64 %op7824, ptr %slot1217, align 8
  %v7825 = load i64, ptr %slot1217, align 8
  %cmp7826 = icmp ne i64 %v7825, 0
  %cv7827 = zext i1 %cmp7826 to i32
  store i32 %cv7827, ptr %slot1218, align 8
  %v7828 = load i32, ptr %slot1218, align 8
  %cv7829 = zext i32 %v7828 to i64
  %cond7830 = icmp ne i64 %cv7829, 0
  br i1 %cond7830, label %bb_rcgclear2017, label %bb_rcgcounted2017
bb_rcgcounted2017:
  %v7831 = load i64, ptr %slot1213, align 8
  %op7832 = sub i64 %v7831, 32
  store i64 %op7832, ptr %slot1219, align 8
  %v7833 = load i64, ptr %slot1213, align 8
  %p7834 = inttoptr i64 %v7833 to ptr
  %rgep7835 = getelementptr i8, ptr %p7834, i64 -32
  %ld7836 = load i64, ptr %rgep7835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7836, ptr %slot1220, align 8
  %v7837 = load i64, ptr %slot1220, align 8
  %op7838 = sub i64 %v7837, 1
  store i64 %op7838, ptr %slot1221, align 8
  %v7839 = load i64, ptr %slot1221, align 8
  %cmp7840 = icmp eq i64 %v7839, 0
  %cv7841 = zext i1 %cmp7840 to i32
  store i32 %cv7841, ptr %slot1222, align 8
  %v7842 = load i32, ptr %slot1222, align 8
  %cv7843 = zext i32 %v7842 to i64
  %cond7844 = icmp ne i64 %cv7843, 0
  br i1 %cond7844, label %bb_rcglast2017, label %bb_rcgdec2017
bb_rcglast2017:
  %v7845 = load i64, ptr %slot1213, align 8
  %op7846 = sub i64 %v7845, 24
  store i64 %op7846, ptr %slot1223, align 8
  %v7847 = load i64, ptr %slot1213, align 8
  %p7848 = inttoptr i64 %v7847 to ptr
  %rgep7849 = getelementptr i8, ptr %p7848, i64 -24
  %ld7850 = load i64, ptr %rgep7849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7850, ptr %slot1224, align 8
  %v7851 = load i64, ptr %slot1224, align 8
  %cmp7852 = icmp ne i64 %v7851, 0
  %cv7853 = zext i1 %cmp7852 to i32
  store i32 %cv7853, ptr %slot1225, align 8
  %v7854 = load i32, ptr %slot1225, align 8
  %cv7855 = zext i32 %v7854 to i64
  %cond7856 = icmp ne i64 %cv7855, 0
  br i1 %cond7856, label %bb_rcgdec2017, label %bb_rcgslow2017
bb_rcgslow2017:
  %v7857 = load i64, ptr %slot1212, align 8
  %v7858 = load i64, ptr %slot1195, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v7857, i64 %v7858) nomerge, !dbg !174
  br label %bb_rcgdone2017
bb_rcgdec2017:
  %v7859 = load i64, ptr %slot1221, align 8
  %v7860 = load i64, ptr %slot1213, align 8
  %p7861 = inttoptr i64 %v7860 to ptr
  %rgep7862 = getelementptr i8, ptr %p7861, i64 -32
  store i64 %v7859, ptr %rgep7862, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2017
bb_rcgclear2017:
  %v7863 = load i64, ptr %slot1195, align 8
  %p7864 = inttoptr i64 %v7863 to ptr
  store i64 0, ptr %p7864, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2017
bb_rcgdone2017:
  br label %bb_rcslotdone1986
bb_rcslotdone1986:
  %v7865 = load i64, ptr %slot40, align 8
  store i64 %v7865, ptr %slot1226, align 8
  %v7866 = load i64, ptr %slot24, align 8
  store i64 %v7866, ptr %slot1227, align 8
  %v7867 = load i64, ptr %slot1227, align 8
  %v7868 = load i64, ptr %slot1226, align 8
  %p7869 = inttoptr i64 %v7867 to ptr
  %p7870 = inttoptr i64 %v7868 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7870, ptr %p7869, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7871 = load i64, ptr %slot19, align 8
  %p7872 = inttoptr i64 %v7871 to ptr
  store i32 0, ptr %p7872, align 4, !alias.scope !3, !noalias !4
  %v7873 = load i64, ptr %slot10, align 8
  %p7874 = inttoptr i64 %v7873 to ptr
  store i32 2, ptr %p7874, align 4, !alias.scope !3, !noalias !4
  %v7875 = load i64, ptr %slot20, align 8
  %p7876 = inttoptr i64 %v7875 to ptr
  %ld7877 = load i32, ptr %p7876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7877, ptr %slot1228, align 8
  %v7878 = load i32, ptr %slot1228, align 8
  %v7879 = load i64, ptr %slot10, align 8
  %p7880 = inttoptr i64 %v7879 to ptr
  store i32 %v7878, ptr %p7880, align 4, !alias.scope !3, !noalias !4
  %v7881 = load i64, ptr %slot9, align 8
  %p7882 = inttoptr i64 %v7881 to ptr
  store i32 1, ptr %p7882, align 4, !alias.scope !3, !noalias !4
  %p7883 = inttoptr i64 ptrtoint (ptr @myl_lit_30bdecd870d597c62d1c30c02882c43b1f27244eec6e99c1398f7fc84cf4ce25 to i64) to ptr
  %ld7884 = load i64, ptr %p7883, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7884, ptr %slot1229, align 8
  %v7885 = load i64, ptr %slot1229, align 8
  %v7886 = load i64, ptr %slot44, align 8
  %p7887 = inttoptr i64 %v7886 to ptr
  store i64 %v7885, ptr %p7887, align 8, !alias.scope !3, !noalias !4
  %v7888 = load i64, ptr %slot44, align 8
  %p7889 = inttoptr i64 %v7888 to ptr
  %ld7890 = load i64, ptr %p7889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7890, ptr %slot1230, align 8
  %v7891 = load i64, ptr %slot1230, align 8
  %v7892 = load i64, ptr %slot23, align 8
  %p7893 = inttoptr i64 %v7892 to ptr
  store i64 %v7891, ptr %p7893, align 8, !alias.scope !3, !noalias !4
  %v7894 = load i64, ptr %slot23, align 8
  store i64 %v7894, ptr %slot1231, align 8
  %v7895 = load i64, ptr %slot24, align 8
  store i64 %v7895, ptr %slot1232, align 8
  %v7896 = load i64, ptr %slot1231, align 8
  %v7897 = load i64, ptr %slot1232, align 8
  %p7898 = inttoptr i64 %v7896 to ptr
  %p7899 = inttoptr i64 %v7897 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7899, ptr %p7898, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7900 = load i64, ptr %slot20, align 8
  %p7901 = inttoptr i64 %v7900 to ptr
  store i32 2, ptr %p7901, align 4, !alias.scope !3, !noalias !4
  %v7902 = load i64, ptr %slot19, align 8
  %p7903 = inttoptr i64 %v7902 to ptr
  store i32 1, ptr %p7903, align 4, !alias.scope !3, !noalias !4
  %v7904 = load i64, ptr %slot22, align 8
  store i64 %v7904, ptr %slot1233, align 8
  %v7905 = load i64, ptr %slot24, align 8
  store i64 %v7905, ptr %slot1234, align 8
  %v7906 = load i64, ptr %slot1234, align 8
  %v7907 = load i64, ptr %slot1233, align 8
  %p7908 = inttoptr i64 %v7906 to ptr
  %p7909 = inttoptr i64 %v7907 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7909, ptr %p7908, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7910 = load i64, ptr %slot18, align 8
  %p7911 = inttoptr i64 %v7910 to ptr
  store i32 2, ptr %p7911, align 4, !alias.scope !3, !noalias !4
  %v7912 = load i64, ptr %slot20, align 8
  %p7913 = inttoptr i64 %v7912 to ptr
  %ld7914 = load i32, ptr %p7913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7914, ptr %slot1235, align 8
  %v7915 = load i32, ptr %slot1235, align 8
  %v7916 = load i64, ptr %slot18, align 8
  %p7917 = inttoptr i64 %v7916 to ptr
  store i32 %v7915, ptr %p7917, align 4, !alias.scope !3, !noalias !4
  %v7918 = load i64, ptr %slot19, align 8
  %p7919 = inttoptr i64 %v7918 to ptr
  store i32 0, ptr %p7919, align 4, !alias.scope !3, !noalias !4
  %v7920 = load i64, ptr %slot17, align 8
  %p7921 = inttoptr i64 %v7920 to ptr
  store i32 1, ptr %p7921, align 4, !alias.scope !3, !noalias !4
  %v7922 = load i64, ptr %slot1233, align 8
  %p7923 = inttoptr i64 %v7922 to ptr
  %ld7924 = load i64, ptr %p7923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7924, ptr %slot1236, align 8
  %v7925 = load i64, ptr %slot1236, align 8
  %v7926 = load i64, ptr %slot44, align 8
  %p7927 = inttoptr i64 %v7926 to ptr
  store i64 %v7925, ptr %p7927, align 8, !alias.scope !3, !noalias !4
  %v7928 = load i64, ptr %slot40, align 8
  store i64 %v7928, ptr %slot1237, align 8
  %v7929 = load i64, ptr %slot10, align 8
  %p7930 = inttoptr i64 %v7929 to ptr
  %ld7931 = load i32, ptr %p7930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7931, ptr %slot1238, align 8
  %v7932 = load i32, ptr %slot1238, align 8
  %cmp7933 = icmp eq i32 %v7932, 16
  %cv7934 = zext i1 %cmp7933 to i32
  store i32 %cv7934, ptr %slot1239, align 8
  %v7935 = load i64, ptr %slot9, align 8
  %p7936 = inttoptr i64 %v7935 to ptr
  %ld7937 = load i32, ptr %p7936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7937, ptr %slot1240, align 8
  %v7938 = load i32, ptr %slot1240, align 8
  %v7939 = load i32, ptr %slot1239, align 8
  %op7940 = and i32 %v7938, %v7939
  store i32 %op7940, ptr %slot1241, align 8
  %v7941 = load i32, ptr %slot1241, align 8
  %cv7942 = zext i32 %v7941 to i64
  %cond7943 = icmp ne i64 %cv7942, 0
  br i1 %cond7943, label %bb_rcownlocal2050, label %bb_rcownedlocal2050
bb_rcownlocal2050:
  %v7944 = load i64, ptr %slot40, align 8
  store i64 %v7944, ptr %slot1242, align 8
  %v7945 = load i64, ptr %slot24, align 8
  store i64 %v7945, ptr %slot1243, align 8
  %v7946 = load i64, ptr %slot64, align 8
  store i64 %v7946, ptr %slot1244, align 8
  %v7947 = load i64, ptr %slot1242, align 8
  %p7948 = inttoptr i64 %v7947 to ptr
  %ld7949 = load i64, ptr %p7948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7949, ptr %slot1245, align 8
  %v7950 = load i64, ptr %slot1245, align 8
  %cmp7951 = icmp ne i64 %v7950, 0
  %cv7952 = zext i1 %cmp7951 to i32
  store i32 %cv7952, ptr %slot1246, align 8
  %v7953 = load i32, ptr %slot1246, align 8
  %cv7954 = zext i32 %v7953 to i64
  %cond7955 = icmp ne i64 %cv7954, 0
  br i1 %cond7955, label %bb_rcgnn2057, label %bb_rcgplain2057
bb_rcgnn2057:
  %v7956 = load i64, ptr %slot1245, align 8
  %op7957 = sub i64 %v7956, 16
  store i64 %op7957, ptr %slot1247, align 8
  %v7958 = load i64, ptr %slot1245, align 8
  %p7959 = inttoptr i64 %v7958 to ptr
  %rgep7960 = getelementptr i8, ptr %p7959, i64 -16
  %ld7961 = load i64, ptr %rgep7960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7961, ptr %slot1248, align 8
  %v7962 = load i64, ptr %slot1248, align 8
  %op7963 = and i64 %v7962, 4611686018427387906
  store i64 %op7963, ptr %slot1249, align 8
  %v7964 = load i64, ptr %slot1249, align 8
  %cmp7965 = icmp ne i64 %v7964, 0
  %cv7966 = zext i1 %cmp7965 to i32
  store i32 %cv7966, ptr %slot1250, align 8
  %v7967 = load i32, ptr %slot1250, align 8
  %cv7968 = zext i32 %v7967 to i64
  %cond7969 = icmp ne i64 %cv7968, 0
  br i1 %cond7969, label %bb_rcgspecial2057, label %bb_rcginc2057
bb_rcginc2057:
  %v7970 = load i64, ptr %slot1245, align 8
  %op7971 = sub i64 %v7970, 32
  store i64 %op7971, ptr %slot1251, align 8
  %v7972 = load i64, ptr %slot1245, align 8
  %p7973 = inttoptr i64 %v7972 to ptr
  %rgep7974 = getelementptr i8, ptr %p7973, i64 -32
  %ld7975 = load i64, ptr %rgep7974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7975, ptr %slot1252, align 8
  %v7976 = load i64, ptr %slot1252, align 8
  %op7977 = add i64 %v7976, 1
  store i64 %op7977, ptr %slot1253, align 8
  %v7978 = load i64, ptr %slot1253, align 8
  %cmp7979 = icmp eq i64 %v7978, 0
  %cv7980 = zext i1 %cmp7979 to i32
  store i32 %cv7980, ptr %slot1254, align 8
  %v7981 = load i32, ptr %slot1254, align 8
  %cv7982 = zext i32 %v7981 to i64
  %cond7983 = icmp ne i64 %cv7982, 0
  br i1 %cond7983, label %bb_rcglimit2057, label %bb_rcgcapacity2057
bb_rcglimit2057:
  %v7984 = load i64, ptr %slot1, align 8
  %p7985 = inttoptr i64 %v7984 to ptr
  %call7986 = call i32 @myl_qbe_rc_status(ptr %p7985, i32 2) nomerge, !dbg !176
  store i32 %call7986, ptr %slot1255, align 8
  br label %bb_failure
bb_rcgcapacity2057:
  %v7987 = load i64, ptr %slot1253, align 8
  %v7988 = load i64, ptr %slot1245, align 8
  %p7989 = inttoptr i64 %v7988 to ptr
  %rgep7990 = getelementptr i8, ptr %p7989, i64 -32
  store i64 %v7987, ptr %rgep7990, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2057
bb_rcgspecial2057:
  %v7991 = load i64, ptr %slot1248, align 8
  %op7992 = and i64 %v7991, 4611686018427387904
  store i64 %op7992, ptr %slot1256, align 8
  %v7993 = load i64, ptr %slot1256, align 8
  %cmp7994 = icmp ne i64 %v7993, 0
  %cv7995 = zext i1 %cmp7994 to i32
  store i32 %cv7995, ptr %slot1257, align 8
  %v7996 = load i32, ptr %slot1257, align 8
  %cv7997 = zext i32 %v7996 to i64
  %cond7998 = icmp ne i64 %cv7997, 0
  br i1 %cond7998, label %bb_rcgslow2057, label %bb_rcgplain2057
bb_rcgslow2057:
  %v7999 = load i64, ptr %slot63, align 8
  %v8000 = load i64, ptr %slot1243, align 8
  %v8001 = load i64, ptr %slot1242, align 8
  %v8002 = load i64, ptr %slot1244, align 8
  %cv8003 = trunc i64 %v8002 to i32
  %call8004 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v7999, i64 %v8000, i64 %v8001, i32 %cv8003) nomerge, !dbg !176
  store i32 %call8004, ptr %slot1258, align 8
  %v8005 = load i32, ptr %slot1258, align 8
  %cv8006 = zext i32 %v8005 to i64
  %cond8007 = icmp ne i64 %cv8006, 0
  br i1 %cond8007, label %bb_rcsuccess2071, label %bb_rcfailure2071
bb_rcfailure2071:
  %v8008 = load i64, ptr %slot63, align 8
  %p8009 = inttoptr i64 %v8008 to ptr
  %call8010 = call i32 @myl_rc_take_failure(ptr %p8009) nomerge, !dbg !176
  store i32 %call8010, ptr %slot1259, align 8
  %v8011 = load i64, ptr %slot1, align 8
  %p8012 = inttoptr i64 %v8011 to ptr
  %v8013 = load i32, ptr %slot1259, align 8
  %call8014 = call i32 @myl_qbe_rc_status(ptr %p8012, i32 %v8013) nomerge, !dbg !176
  store i32 %call8014, ptr %slot1260, align 8
  br label %bb_failure
bb_rcsuccess2071:
  br label %bb_rcgdone2057
bb_rcgplain2057:
  %v8015 = load i64, ptr %slot1245, align 8
  %v8016 = load i64, ptr %slot1243, align 8
  %p8017 = inttoptr i64 %v8016 to ptr
  store i64 %v8015, ptr %p8017, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2057
bb_rcgdone2057:
  %v8018 = load i64, ptr %slot20, align 8
  %p8019 = inttoptr i64 %v8018 to ptr
  store i32 2, ptr %p8019, align 4, !alias.scope !3, !noalias !4
  %v8020 = load i64, ptr %slot19, align 8
  %p8021 = inttoptr i64 %v8020 to ptr
  store i32 1, ptr %p8021, align 4, !alias.scope !3, !noalias !4
  %v8022 = load i64, ptr %slot9, align 8
  %p8023 = inttoptr i64 %v8022 to ptr
  %ld8024 = load i32, ptr %p8023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8024, ptr %slot1261, align 8
  %v8025 = load i32, ptr %slot1261, align 8
  %cv8026 = zext i32 %v8025 to i64
  %cond8027 = icmp ne i64 %cv8026, 0
  br i1 %cond8027, label %bb_rcslotdrop2078, label %bb_rcslotdone2078
bb_rcslotdrop2078:
  %v8028 = load i64, ptr %slot9, align 8
  %p8029 = inttoptr i64 %v8028 to ptr
  store i32 0, ptr %p8029, align 4, !alias.scope !3, !noalias !4
  %v8030 = load i64, ptr %slot40, align 8
  store i64 %v8030, ptr %slot1262, align 8
  %v8031 = load i64, ptr %slot10, align 8
  %p8032 = inttoptr i64 %v8031 to ptr
  %ld8033 = load i32, ptr %p8032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8033, ptr %slot1263, align 8
  %v8034 = load i32, ptr %slot1263, align 8
  %op8035 = and i32 %v8034, 28
  store i32 %op8035, ptr %slot1264, align 8
  %v8036 = load i32, ptr %slot1264, align 8
  %cv8037 = zext i32 %v8036 to i64
  %cond8038 = icmp ne i64 %cv8037, 0
  br i1 %cond8038, label %bb_rcslotrole2078, label %bb_rcslotowner2078
bb_rcslotrole2078:
  %v8039 = load i64, ptr %slot63, align 8
  store i64 %v8039, ptr %slot1265, align 8
  %v8040 = load i64, ptr %slot1262, align 8
  %p8041 = inttoptr i64 %v8040 to ptr
  %ld8042 = load i64, ptr %p8041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8042, ptr %slot1266, align 8
  %v8043 = load i64, ptr %slot1266, align 8
  %cmp8044 = icmp ne i64 %v8043, 0
  %cv8045 = zext i1 %cmp8044 to i32
  store i32 %cv8045, ptr %slot1267, align 8
  %v8046 = load i32, ptr %slot1267, align 8
  %cv8047 = zext i32 %v8046 to i64
  %cond8048 = icmp ne i64 %cv8047, 0
  br i1 %cond8048, label %bb_rcgnn2094, label %bb_rcgdone2094
bb_rcgnn2094:
  %v8049 = load i64, ptr %slot1266, align 8
  %op8050 = sub i64 %v8049, 16
  store i64 %op8050, ptr %slot1268, align 8
  %v8051 = load i64, ptr %slot1266, align 8
  %p8052 = inttoptr i64 %v8051 to ptr
  %rgep8053 = getelementptr i8, ptr %p8052, i64 -16
  %ld8054 = load i64, ptr %rgep8053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8054, ptr %slot1269, align 8
  %v8055 = load i64, ptr %slot1269, align 8
  %op8056 = and i64 %v8055, 4611686018427387906
  store i64 %op8056, ptr %slot1270, align 8
  %v8057 = load i64, ptr %slot1270, align 8
  %cmp8058 = icmp ne i64 %v8057, 0
  %cv8059 = zext i1 %cmp8058 to i32
  store i32 %cv8059, ptr %slot1271, align 8
  %v8060 = load i32, ptr %slot1271, align 8
  %cv8061 = zext i32 %v8060 to i64
  %cond8062 = icmp ne i64 %cv8061, 0
  br i1 %cond8062, label %bb_rcgclear2094, label %bb_rcgcounted2094
bb_rcgcounted2094:
  %v8063 = load i64, ptr %slot1266, align 8
  %op8064 = sub i64 %v8063, 24
  store i64 %op8064, ptr %slot1272, align 8
  %v8065 = load i64, ptr %slot1266, align 8
  %p8066 = inttoptr i64 %v8065 to ptr
  %rgep8067 = getelementptr i8, ptr %p8066, i64 -24
  %ld8068 = load i64, ptr %rgep8067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8068, ptr %slot1273, align 8
  %v8069 = load i64, ptr %slot1273, align 8
  %op8070 = sub i64 %v8069, 1
  store i64 %op8070, ptr %slot1274, align 8
  %v8071 = load i64, ptr %slot1274, align 8
  %cmp8072 = icmp eq i64 %v8071, 0
  %cv8073 = zext i1 %cmp8072 to i32
  store i32 %cv8073, ptr %slot1275, align 8
  %v8074 = load i32, ptr %slot1275, align 8
  %cv8075 = zext i32 %v8074 to i64
  %cond8076 = icmp ne i64 %cv8075, 0
  br i1 %cond8076, label %bb_rcglast2094, label %bb_rcgdec2094
bb_rcglast2094:
  %v8077 = load i64, ptr %slot1266, align 8
  %op8078 = sub i64 %v8077, 32
  store i64 %op8078, ptr %slot1276, align 8
  %v8079 = load i64, ptr %slot1266, align 8
  %p8080 = inttoptr i64 %v8079 to ptr
  %rgep8081 = getelementptr i8, ptr %p8080, i64 -32
  %ld8082 = load i64, ptr %rgep8081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8082, ptr %slot1277, align 8
  %v8083 = load i64, ptr %slot1277, align 8
  %cmp8084 = icmp ne i64 %v8083, 0
  %cv8085 = zext i1 %cmp8084 to i32
  store i32 %cv8085, ptr %slot1278, align 8
  %v8086 = load i32, ptr %slot1278, align 8
  %cv8087 = zext i32 %v8086 to i64
  %cond8088 = icmp ne i64 %cv8087, 0
  br i1 %cond8088, label %bb_rcgdec2094, label %bb_rcgslow2094
bb_rcgslow2094:
  %v8089 = load i64, ptr %slot1265, align 8
  %v8090 = load i64, ptr %slot1262, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v8089, i64 %v8090) nomerge, !dbg !176
  br label %bb_rcgdone2094
bb_rcgdec2094:
  %v8091 = load i64, ptr %slot1274, align 8
  %v8092 = load i64, ptr %slot1266, align 8
  %p8093 = inttoptr i64 %v8092 to ptr
  %rgep8094 = getelementptr i8, ptr %p8093, i64 -24
  store i64 %v8091, ptr %rgep8094, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2094
bb_rcgclear2094:
  %v8095 = load i64, ptr %slot1262, align 8
  %p8096 = inttoptr i64 %v8095 to ptr
  store i64 0, ptr %p8096, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2094
bb_rcgdone2094:
  br label %bb_rcslotdone2078
bb_rcslotowner2078:
  %v8097 = load i64, ptr %slot63, align 8
  store i64 %v8097, ptr %slot1279, align 8
  %v8098 = load i64, ptr %slot1262, align 8
  %p8099 = inttoptr i64 %v8098 to ptr
  %ld8100 = load i64, ptr %p8099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8100, ptr %slot1280, align 8
  %v8101 = load i64, ptr %slot1280, align 8
  %cmp8102 = icmp ne i64 %v8101, 0
  %cv8103 = zext i1 %cmp8102 to i32
  store i32 %cv8103, ptr %slot1281, align 8
  %v8104 = load i32, ptr %slot1281, align 8
  %cv8105 = zext i32 %v8104 to i64
  %cond8106 = icmp ne i64 %cv8105, 0
  br i1 %cond8106, label %bb_rcgnn2109, label %bb_rcgdone2109
bb_rcgnn2109:
  %v8107 = load i64, ptr %slot1280, align 8
  %op8108 = sub i64 %v8107, 16
  store i64 %op8108, ptr %slot1282, align 8
  %v8109 = load i64, ptr %slot1280, align 8
  %p8110 = inttoptr i64 %v8109 to ptr
  %rgep8111 = getelementptr i8, ptr %p8110, i64 -16
  %ld8112 = load i64, ptr %rgep8111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8112, ptr %slot1283, align 8
  %v8113 = load i64, ptr %slot1283, align 8
  %op8114 = and i64 %v8113, 4611686018427387906
  store i64 %op8114, ptr %slot1284, align 8
  %v8115 = load i64, ptr %slot1284, align 8
  %cmp8116 = icmp ne i64 %v8115, 0
  %cv8117 = zext i1 %cmp8116 to i32
  store i32 %cv8117, ptr %slot1285, align 8
  %v8118 = load i32, ptr %slot1285, align 8
  %cv8119 = zext i32 %v8118 to i64
  %cond8120 = icmp ne i64 %cv8119, 0
  br i1 %cond8120, label %bb_rcgclear2109, label %bb_rcgcounted2109
bb_rcgcounted2109:
  %v8121 = load i64, ptr %slot1280, align 8
  %op8122 = sub i64 %v8121, 32
  store i64 %op8122, ptr %slot1286, align 8
  %v8123 = load i64, ptr %slot1280, align 8
  %p8124 = inttoptr i64 %v8123 to ptr
  %rgep8125 = getelementptr i8, ptr %p8124, i64 -32
  %ld8126 = load i64, ptr %rgep8125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8126, ptr %slot1287, align 8
  %v8127 = load i64, ptr %slot1287, align 8
  %op8128 = sub i64 %v8127, 1
  store i64 %op8128, ptr %slot1288, align 8
  %v8129 = load i64, ptr %slot1288, align 8
  %cmp8130 = icmp eq i64 %v8129, 0
  %cv8131 = zext i1 %cmp8130 to i32
  store i32 %cv8131, ptr %slot1289, align 8
  %v8132 = load i32, ptr %slot1289, align 8
  %cv8133 = zext i32 %v8132 to i64
  %cond8134 = icmp ne i64 %cv8133, 0
  br i1 %cond8134, label %bb_rcglast2109, label %bb_rcgdec2109
bb_rcglast2109:
  %v8135 = load i64, ptr %slot1280, align 8
  %op8136 = sub i64 %v8135, 24
  store i64 %op8136, ptr %slot1290, align 8
  %v8137 = load i64, ptr %slot1280, align 8
  %p8138 = inttoptr i64 %v8137 to ptr
  %rgep8139 = getelementptr i8, ptr %p8138, i64 -24
  %ld8140 = load i64, ptr %rgep8139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8140, ptr %slot1291, align 8
  %v8141 = load i64, ptr %slot1291, align 8
  %cmp8142 = icmp ne i64 %v8141, 0
  %cv8143 = zext i1 %cmp8142 to i32
  store i32 %cv8143, ptr %slot1292, align 8
  %v8144 = load i32, ptr %slot1292, align 8
  %cv8145 = zext i32 %v8144 to i64
  %cond8146 = icmp ne i64 %cv8145, 0
  br i1 %cond8146, label %bb_rcgdec2109, label %bb_rcgslow2109
bb_rcgslow2109:
  %v8147 = load i64, ptr %slot1279, align 8
  %v8148 = load i64, ptr %slot1262, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v8147, i64 %v8148) nomerge, !dbg !176
  br label %bb_rcgdone2109
bb_rcgdec2109:
  %v8149 = load i64, ptr %slot1288, align 8
  %v8150 = load i64, ptr %slot1280, align 8
  %p8151 = inttoptr i64 %v8150 to ptr
  %rgep8152 = getelementptr i8, ptr %p8151, i64 -32
  store i64 %v8149, ptr %rgep8152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2109
bb_rcgclear2109:
  %v8153 = load i64, ptr %slot1262, align 8
  %p8154 = inttoptr i64 %v8153 to ptr
  store i64 0, ptr %p8154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2109
bb_rcgdone2109:
  br label %bb_rcslotdone2078
bb_rcslotdone2078:
  %v8155 = load i64, ptr %slot24, align 8
  store i64 %v8155, ptr %slot1293, align 8
  %v8156 = load i64, ptr %slot1293, align 8
  %v8157 = load i64, ptr %slot1242, align 8
  %p8158 = inttoptr i64 %v8156 to ptr
  %p8159 = inttoptr i64 %v8157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8159, ptr %p8158, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8160 = load i64, ptr %slot10, align 8
  %p8161 = inttoptr i64 %v8160 to ptr
  store i32 2, ptr %p8161, align 4, !alias.scope !3, !noalias !4
  %v8162 = load i64, ptr %slot9, align 8
  %p8163 = inttoptr i64 %v8162 to ptr
  store i32 1, ptr %p8163, align 4, !alias.scope !3, !noalias !4
  %v8164 = load i64, ptr %slot19, align 8
  %p8165 = inttoptr i64 %v8164 to ptr
  store i32 0, ptr %p8165, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2050
bb_rcownedlocal2050:
  %v8166 = load i64, ptr %slot10, align 8
  %p8167 = inttoptr i64 %v8166 to ptr
  store i32 2, ptr %p8167, align 4, !alias.scope !3, !noalias !4
  %v8168 = load i64, ptr %slot1237, align 8
  %p8169 = inttoptr i64 %v8168 to ptr
  %ld8170 = load i64, ptr %p8169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8170, ptr %slot1294, align 8
  %v8171 = load i64, ptr %slot1294, align 8
  %cmp8172 = icmp ne i64 %v8171, 0
  %cv8173 = zext i1 %cmp8172 to i32
  store i32 %cv8173, ptr %slot1295, align 8
  %v8174 = load i32, ptr %slot1295, align 8
  %cv8175 = zext i32 %v8174 to i64
  %cond8176 = icmp ne i64 %cv8175, 0
  br i1 %cond8176, label %bb_rcguniquenn2118, label %bb_rcgunique2118
bb_rcguniquenn2118:
  %v8177 = load i64, ptr %slot1294, align 8
  %op8178 = sub i64 %v8177, 16
  store i64 %op8178, ptr %slot1296, align 8
  %v8179 = load i64, ptr %slot1294, align 8
  %p8180 = inttoptr i64 %v8179 to ptr
  %rgep8181 = getelementptr i8, ptr %p8180, i64 -16
  %ld8182 = load i64, ptr %rgep8181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8182, ptr %slot1297, align 8
  %v8183 = load i64, ptr %slot1297, align 8
  %op8184 = and i64 %v8183, 6917529027641081858
  store i64 %op8184, ptr %slot1298, align 8
  %v8185 = load i64, ptr %slot1298, align 8
  %cmp8186 = icmp ne i64 %v8185, 0
  %cv8187 = zext i1 %cmp8186 to i32
  store i32 %cv8187, ptr %slot1299, align 8
  %v8188 = load i32, ptr %slot1299, align 8
  %cv8189 = zext i32 %v8188 to i64
  %cond8190 = icmp ne i64 %cv8189, 0
  br i1 %cond8190, label %bb_rcguniqueslow2118, label %bb_rcguniquecount2118
bb_rcguniquecount2118:
  %v8191 = load i64, ptr %slot1294, align 8
  %op8192 = sub i64 %v8191, 32
  store i64 %op8192, ptr %slot1300, align 8
  %v8193 = load i64, ptr %slot1294, align 8
  %p8194 = inttoptr i64 %v8193 to ptr
  %rgep8195 = getelementptr i8, ptr %p8194, i64 -32
  %ld8196 = load i64, ptr %rgep8195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8196, ptr %slot1301, align 8
  %v8197 = load i64, ptr %slot1301, align 8
  %cmp8198 = icmp ult i64 %v8197, 2
  %cv8199 = zext i1 %cmp8198 to i32
  store i32 %cv8199, ptr %slot1302, align 8
  %v8200 = load i32, ptr %slot1302, align 8
  %cv8201 = zext i32 %v8200 to i64
  %cond8202 = icmp ne i64 %cv8201, 0
  br i1 %cond8202, label %bb_rcgunique2118, label %bb_rcguniqueslow2118
bb_rcguniqueslow2118:
  %v8203 = load i64, ptr %slot1, align 8
  %p8204 = inttoptr i64 %v8203 to ptr
  %p8205 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v8206 = load i64, ptr %slot1237, align 8
  %p8207 = inttoptr i64 %v8206 to ptr
  %v8208 = load i64, ptr %slot9, align 8
  %p8209 = inttoptr i64 %v8208 to ptr
  %call8210 = call i32 @myl_qbe_rc_unique_local(ptr %p8204, ptr %p8205, ptr %p8207, ptr %p8209) nomerge, !dbg !176
  store i32 %call8210, ptr %slot1303, align 8
  %v8211 = load i32, ptr %slot1303, align 8
  %cv8212 = zext i32 %v8211 to i64
  %cond8213 = icmp ne i64 %cv8212, 0
  br i1 %cond8213, label %bb_rcunique2129, label %bb_failure
bb_rcunique2129:
  br label %bb_rcgunique2118
bb_rcgunique2118:
  %v8214 = load i64, ptr %slot40, align 8
  %p8215 = inttoptr i64 %v8214 to ptr
  %ld8216 = load i64, ptr %p8215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8216, ptr %slot1304, align 8
  %v8217 = load i64, ptr %slot44, align 8
  store i64 %v8217, ptr %slot1305, align 8
  %v8218 = load i64, ptr %slot1305, align 8
  %p8219 = inttoptr i64 %v8218 to ptr
  %ld8220 = load i64, ptr %p8219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8220, ptr %slot1306, align 8
  %v8221 = load i64, ptr %slot1306, align 8
  %v8222 = load i64, ptr %slot25, align 8
  %p8223 = inttoptr i64 %v8222 to ptr
  store i64 %v8221, ptr %p8223, align 8, !alias.scope !3, !noalias !4
  %v8224 = load i64, ptr %slot25, align 8
  store i64 %v8224, ptr %slot1307, align 8
  %v8225 = load i64, ptr %slot63, align 8
  %v8226 = load i64, ptr %slot1304, align 8
  %v8227 = load i64, ptr %slot1307, align 8
  %call8228 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v8225, i64 %v8226, i64 %v8227) nomerge, !dbg !176
  store i32 %call8228, ptr %slot1308, align 8
  %v8229 = load i32, ptr %slot1308, align 8
  %cv8230 = zext i32 %v8229 to i64
  %cond8231 = icmp ne i64 %cv8230, 0
  br i1 %cond8231, label %bb_success2135, label %bb_failed2135
bb_failed2135:
  %v8232 = load i64, ptr %slot1, align 8
  %p8233 = inttoptr i64 %v8232 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8233) nomerge, !dbg !176
  unreachable
bb_success2135:
  %v8234 = load i64, ptr %slot44, align 8
  %p8235 = inttoptr i64 %v8234 to ptr
  store i64 0, ptr %p8235, align 8, !alias.scope !3, !noalias !4
  %v8236 = load i64, ptr %slot17, align 8
  %p8237 = inttoptr i64 %v8236 to ptr
  %ld8238 = load i32, ptr %p8237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8238, ptr %slot1309, align 8
  %v8239 = load i32, ptr %slot1309, align 8
  %cv8240 = zext i32 %v8239 to i64
  %cond8241 = icmp ne i64 %cv8240, 0
  br i1 %cond8241, label %bb_rcslotdrop2138, label %bb_rcslotdone2138
bb_rcslotdrop2138:
  %v8242 = load i64, ptr %slot17, align 8
  %p8243 = inttoptr i64 %v8242 to ptr
  store i32 0, ptr %p8243, align 4, !alias.scope !3, !noalias !4
  %v8244 = load i64, ptr %slot22, align 8
  store i64 %v8244, ptr %slot1310, align 8
  %v8245 = load i64, ptr %slot18, align 8
  %p8246 = inttoptr i64 %v8245 to ptr
  %ld8247 = load i32, ptr %p8246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8247, ptr %slot1311, align 8
  %v8248 = load i32, ptr %slot1311, align 8
  %op8249 = and i32 %v8248, 28
  store i32 %op8249, ptr %slot1312, align 8
  %v8250 = load i32, ptr %slot1312, align 8
  %cv8251 = zext i32 %v8250 to i64
  %cond8252 = icmp ne i64 %cv8251, 0
  br i1 %cond8252, label %bb_rcslotrole2138, label %bb_rcslotowner2138
bb_rcslotrole2138:
  %v8253 = load i64, ptr %slot63, align 8
  store i64 %v8253, ptr %slot1313, align 8
  %v8254 = load i64, ptr %slot1310, align 8
  %p8255 = inttoptr i64 %v8254 to ptr
  %ld8256 = load i64, ptr %p8255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8256, ptr %slot1314, align 8
  %v8257 = load i64, ptr %slot1314, align 8
  %cmp8258 = icmp ne i64 %v8257, 0
  %cv8259 = zext i1 %cmp8258 to i32
  store i32 %cv8259, ptr %slot1315, align 8
  %v8260 = load i32, ptr %slot1315, align 8
  %cv8261 = zext i32 %v8260 to i64
  %cond8262 = icmp ne i64 %cv8261, 0
  br i1 %cond8262, label %bb_rcgnn2154, label %bb_rcgdone2154
bb_rcgnn2154:
  %v8263 = load i64, ptr %slot1314, align 8
  %op8264 = sub i64 %v8263, 16
  store i64 %op8264, ptr %slot1316, align 8
  %v8265 = load i64, ptr %slot1314, align 8
  %p8266 = inttoptr i64 %v8265 to ptr
  %rgep8267 = getelementptr i8, ptr %p8266, i64 -16
  %ld8268 = load i64, ptr %rgep8267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8268, ptr %slot1317, align 8
  %v8269 = load i64, ptr %slot1317, align 8
  %op8270 = and i64 %v8269, 4611686018427387906
  store i64 %op8270, ptr %slot1318, align 8
  %v8271 = load i64, ptr %slot1318, align 8
  %cmp8272 = icmp ne i64 %v8271, 0
  %cv8273 = zext i1 %cmp8272 to i32
  store i32 %cv8273, ptr %slot1319, align 8
  %v8274 = load i32, ptr %slot1319, align 8
  %cv8275 = zext i32 %v8274 to i64
  %cond8276 = icmp ne i64 %cv8275, 0
  br i1 %cond8276, label %bb_rcgclear2154, label %bb_rcgcounted2154
bb_rcgcounted2154:
  %v8277 = load i64, ptr %slot1314, align 8
  %op8278 = sub i64 %v8277, 24
  store i64 %op8278, ptr %slot1320, align 8
  %v8279 = load i64, ptr %slot1314, align 8
  %p8280 = inttoptr i64 %v8279 to ptr
  %rgep8281 = getelementptr i8, ptr %p8280, i64 -24
  %ld8282 = load i64, ptr %rgep8281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8282, ptr %slot1321, align 8
  %v8283 = load i64, ptr %slot1321, align 8
  %op8284 = sub i64 %v8283, 1
  store i64 %op8284, ptr %slot1322, align 8
  %v8285 = load i64, ptr %slot1322, align 8
  %cmp8286 = icmp eq i64 %v8285, 0
  %cv8287 = zext i1 %cmp8286 to i32
  store i32 %cv8287, ptr %slot1323, align 8
  %v8288 = load i32, ptr %slot1323, align 8
  %cv8289 = zext i32 %v8288 to i64
  %cond8290 = icmp ne i64 %cv8289, 0
  br i1 %cond8290, label %bb_rcglast2154, label %bb_rcgdec2154
bb_rcglast2154:
  %v8291 = load i64, ptr %slot1314, align 8
  %op8292 = sub i64 %v8291, 32
  store i64 %op8292, ptr %slot1324, align 8
  %v8293 = load i64, ptr %slot1314, align 8
  %p8294 = inttoptr i64 %v8293 to ptr
  %rgep8295 = getelementptr i8, ptr %p8294, i64 -32
  %ld8296 = load i64, ptr %rgep8295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8296, ptr %slot1325, align 8
  %v8297 = load i64, ptr %slot1325, align 8
  %cmp8298 = icmp ne i64 %v8297, 0
  %cv8299 = zext i1 %cmp8298 to i32
  store i32 %cv8299, ptr %slot1326, align 8
  %v8300 = load i32, ptr %slot1326, align 8
  %cv8301 = zext i32 %v8300 to i64
  %cond8302 = icmp ne i64 %cv8301, 0
  br i1 %cond8302, label %bb_rcgdec2154, label %bb_rcgslow2154
bb_rcgslow2154:
  %v8303 = load i64, ptr %slot1313, align 8
  %v8304 = load i64, ptr %slot1310, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8303, i64 %v8304) nomerge, !dbg !176
  br label %bb_rcgdone2154
bb_rcgdec2154:
  %v8305 = load i64, ptr %slot1322, align 8
  %v8306 = load i64, ptr %slot1314, align 8
  %p8307 = inttoptr i64 %v8306 to ptr
  %rgep8308 = getelementptr i8, ptr %p8307, i64 -24
  store i64 %v8305, ptr %rgep8308, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2154
bb_rcgclear2154:
  %v8309 = load i64, ptr %slot1310, align 8
  %p8310 = inttoptr i64 %v8309 to ptr
  store i64 0, ptr %p8310, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2154
bb_rcgdone2154:
  br label %bb_rcslotdone2138
bb_rcslotowner2138:
  %v8311 = load i64, ptr %slot63, align 8
  store i64 %v8311, ptr %slot1327, align 8
  %v8312 = load i64, ptr %slot1310, align 8
  %p8313 = inttoptr i64 %v8312 to ptr
  %ld8314 = load i64, ptr %p8313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8314, ptr %slot1328, align 8
  %v8315 = load i64, ptr %slot1328, align 8
  %cmp8316 = icmp ne i64 %v8315, 0
  %cv8317 = zext i1 %cmp8316 to i32
  store i32 %cv8317, ptr %slot1329, align 8
  %v8318 = load i32, ptr %slot1329, align 8
  %cv8319 = zext i32 %v8318 to i64
  %cond8320 = icmp ne i64 %cv8319, 0
  br i1 %cond8320, label %bb_rcgnn2169, label %bb_rcgdone2169
bb_rcgnn2169:
  %v8321 = load i64, ptr %slot1328, align 8
  %op8322 = sub i64 %v8321, 16
  store i64 %op8322, ptr %slot1330, align 8
  %v8323 = load i64, ptr %slot1328, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  %rgep8325 = getelementptr i8, ptr %p8324, i64 -16
  %ld8326 = load i64, ptr %rgep8325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8326, ptr %slot1331, align 8
  %v8327 = load i64, ptr %slot1331, align 8
  %op8328 = and i64 %v8327, 4611686018427387906
  store i64 %op8328, ptr %slot1332, align 8
  %v8329 = load i64, ptr %slot1332, align 8
  %cmp8330 = icmp ne i64 %v8329, 0
  %cv8331 = zext i1 %cmp8330 to i32
  store i32 %cv8331, ptr %slot1333, align 8
  %v8332 = load i32, ptr %slot1333, align 8
  %cv8333 = zext i32 %v8332 to i64
  %cond8334 = icmp ne i64 %cv8333, 0
  br i1 %cond8334, label %bb_rcgclear2169, label %bb_rcgcounted2169
bb_rcgcounted2169:
  %v8335 = load i64, ptr %slot1328, align 8
  %op8336 = sub i64 %v8335, 32
  store i64 %op8336, ptr %slot1334, align 8
  %v8337 = load i64, ptr %slot1328, align 8
  %p8338 = inttoptr i64 %v8337 to ptr
  %rgep8339 = getelementptr i8, ptr %p8338, i64 -32
  %ld8340 = load i64, ptr %rgep8339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8340, ptr %slot1335, align 8
  %v8341 = load i64, ptr %slot1335, align 8
  %op8342 = sub i64 %v8341, 1
  store i64 %op8342, ptr %slot1336, align 8
  %v8343 = load i64, ptr %slot1336, align 8
  %cmp8344 = icmp eq i64 %v8343, 0
  %cv8345 = zext i1 %cmp8344 to i32
  store i32 %cv8345, ptr %slot1337, align 8
  %v8346 = load i32, ptr %slot1337, align 8
  %cv8347 = zext i32 %v8346 to i64
  %cond8348 = icmp ne i64 %cv8347, 0
  br i1 %cond8348, label %bb_rcglast2169, label %bb_rcgdec2169
bb_rcglast2169:
  %v8349 = load i64, ptr %slot1328, align 8
  %op8350 = sub i64 %v8349, 24
  store i64 %op8350, ptr %slot1338, align 8
  %v8351 = load i64, ptr %slot1328, align 8
  %p8352 = inttoptr i64 %v8351 to ptr
  %rgep8353 = getelementptr i8, ptr %p8352, i64 -24
  %ld8354 = load i64, ptr %rgep8353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8354, ptr %slot1339, align 8
  %v8355 = load i64, ptr %slot1339, align 8
  %cmp8356 = icmp ne i64 %v8355, 0
  %cv8357 = zext i1 %cmp8356 to i32
  store i32 %cv8357, ptr %slot1340, align 8
  %v8358 = load i32, ptr %slot1340, align 8
  %cv8359 = zext i32 %v8358 to i64
  %cond8360 = icmp ne i64 %cv8359, 0
  br i1 %cond8360, label %bb_rcgdec2169, label %bb_rcgslow2169
bb_rcgslow2169:
  %v8361 = load i64, ptr %slot1327, align 8
  %v8362 = load i64, ptr %slot1310, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8361, i64 %v8362) nomerge, !dbg !176
  br label %bb_rcgdone2169
bb_rcgdec2169:
  %v8363 = load i64, ptr %slot1336, align 8
  %v8364 = load i64, ptr %slot1328, align 8
  %p8365 = inttoptr i64 %v8364 to ptr
  %rgep8366 = getelementptr i8, ptr %p8365, i64 -32
  store i64 %v8363, ptr %rgep8366, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2169
bb_rcgclear2169:
  %v8367 = load i64, ptr %slot1310, align 8
  %p8368 = inttoptr i64 %v8367 to ptr
  store i64 0, ptr %p8368, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2169
bb_rcgdone2169:
  br label %bb_rcslotdone2138
bb_rcslotdone2138:
  %v8369 = load i64, ptr %slot39, align 8
  %v8370 = load i64, ptr %slot44, align 8
  %p8371 = inttoptr i64 %v8370 to ptr
  store i64 %v8369, ptr %p8371, align 8, !alias.scope !3, !noalias !4
  %v8372 = load i64, ptr %slot44, align 8
  %p8373 = inttoptr i64 %v8372 to ptr
  %ld8374 = load i64, ptr %p8373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8374, ptr %slot1341, align 8
  %v8375 = load i64, ptr %slot1341, align 8
  %op8376 = add i64 %v8375, 8
  store i64 %op8376, ptr %slot1342, align 8
  %v8377 = load i64, ptr %slot1342, align 8
  %p8378 = inttoptr i64 %v8377 to ptr
  %ld8379 = load i64, ptr %p8378, align 8
  store i64 %ld8379, ptr %slot1343, align 8
  %v8380 = load i64, ptr %slot1343, align 8
  %v8381 = load i64, ptr %slot44, align 8
  %p8382 = inttoptr i64 %v8381 to ptr
  store i64 %v8380, ptr %p8382, align 8, !alias.scope !3, !noalias !4
  %v8383 = load i64, ptr %slot44, align 8
  %p8384 = inttoptr i64 %v8383 to ptr
  %ld8385 = load i64, ptr %p8384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8385, ptr %slot1344, align 8
  %v8386 = load i64, ptr %slot63, align 8
  %p8387 = inttoptr i64 %v8386 to ptr
  %v8388 = load i64, ptr %slot1344, align 8
  %p8389 = inttoptr i64 %v8388 to ptr
  %call8390 = call ptr @myl_native_text_scalar(ptr %p8387, ptr %p8389, i32 0) nomerge, !dbg !178
  %calladdr8391 = ptrtoint ptr %call8390 to i64
  store i64 %calladdr8391, ptr %slot1345, align 8
  %v8392 = load i64, ptr %slot1345, align 8
  %cond8393 = icmp ne i64 %v8392, 0
  br i1 %cond8393, label %bb_success2178, label %bb_failed2178
bb_failed2178:
  %v8394 = load i64, ptr %slot1, align 8
  %p8395 = inttoptr i64 %v8394 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8395) nomerge, !dbg !178
  unreachable
bb_success2178:
  %v8396 = load i64, ptr %slot1345, align 8
  %v8397 = load i64, ptr %slot44, align 8
  %p8398 = inttoptr i64 %v8397 to ptr
  store i64 %v8396, ptr %p8398, align 8, !alias.scope !3, !noalias !4
  %v8399 = load i64, ptr %slot44, align 8
  %p8400 = inttoptr i64 %v8399 to ptr
  %ld8401 = load i64, ptr %p8400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8401, ptr %slot1346, align 8
  %v8402 = load i64, ptr %slot1346, align 8
  %v8403 = load i64, ptr %slot23, align 8
  %p8404 = inttoptr i64 %v8403 to ptr
  store i64 %v8402, ptr %p8404, align 8, !alias.scope !3, !noalias !4
  %v8405 = load i64, ptr %slot23, align 8
  store i64 %v8405, ptr %slot1347, align 8
  %v8406 = load i64, ptr %slot24, align 8
  store i64 %v8406, ptr %slot1348, align 8
  %v8407 = load i64, ptr %slot1347, align 8
  %v8408 = load i64, ptr %slot1348, align 8
  %p8409 = inttoptr i64 %v8407 to ptr
  %p8410 = inttoptr i64 %v8408 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8410, ptr %p8409, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8411 = load i64, ptr %slot20, align 8
  %p8412 = inttoptr i64 %v8411 to ptr
  store i32 2, ptr %p8412, align 4, !alias.scope !3, !noalias !4
  %v8413 = load i64, ptr %slot19, align 8
  %p8414 = inttoptr i64 %v8413 to ptr
  store i32 1, ptr %p8414, align 4, !alias.scope !3, !noalias !4
  %v8415 = load i64, ptr %slot22, align 8
  store i64 %v8415, ptr %slot1349, align 8
  %v8416 = load i64, ptr %slot24, align 8
  store i64 %v8416, ptr %slot1350, align 8
  %v8417 = load i64, ptr %slot1350, align 8
  %v8418 = load i64, ptr %slot1349, align 8
  %p8419 = inttoptr i64 %v8417 to ptr
  %p8420 = inttoptr i64 %v8418 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8420, ptr %p8419, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8421 = load i64, ptr %slot18, align 8
  %p8422 = inttoptr i64 %v8421 to ptr
  store i32 2, ptr %p8422, align 4, !alias.scope !3, !noalias !4
  %v8423 = load i64, ptr %slot20, align 8
  %p8424 = inttoptr i64 %v8423 to ptr
  %ld8425 = load i32, ptr %p8424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8425, ptr %slot1351, align 8
  %v8426 = load i32, ptr %slot1351, align 8
  %v8427 = load i64, ptr %slot18, align 8
  %p8428 = inttoptr i64 %v8427 to ptr
  store i32 %v8426, ptr %p8428, align 4, !alias.scope !3, !noalias !4
  %v8429 = load i64, ptr %slot19, align 8
  %p8430 = inttoptr i64 %v8429 to ptr
  store i32 0, ptr %p8430, align 4, !alias.scope !3, !noalias !4
  %v8431 = load i64, ptr %slot17, align 8
  %p8432 = inttoptr i64 %v8431 to ptr
  store i32 1, ptr %p8432, align 4, !alias.scope !3, !noalias !4
  %v8433 = load i64, ptr %slot1349, align 8
  %p8434 = inttoptr i64 %v8433 to ptr
  %ld8435 = load i64, ptr %p8434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8435, ptr %slot1352, align 8
  %v8436 = load i64, ptr %slot1352, align 8
  %v8437 = load i64, ptr %slot44, align 8
  %p8438 = inttoptr i64 %v8437 to ptr
  store i64 %v8436, ptr %p8438, align 8, !alias.scope !3, !noalias !4
  %v8439 = load i64, ptr %slot40, align 8
  store i64 %v8439, ptr %slot1353, align 8
  %v8440 = load i64, ptr %slot10, align 8
  %p8441 = inttoptr i64 %v8440 to ptr
  %ld8442 = load i32, ptr %p8441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8442, ptr %slot1354, align 8
  %v8443 = load i32, ptr %slot1354, align 8
  %cmp8444 = icmp eq i32 %v8443, 16
  %cv8445 = zext i1 %cmp8444 to i32
  store i32 %cv8445, ptr %slot1355, align 8
  %v8446 = load i64, ptr %slot9, align 8
  %p8447 = inttoptr i64 %v8446 to ptr
  %ld8448 = load i32, ptr %p8447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8448, ptr %slot1356, align 8
  %v8449 = load i32, ptr %slot1356, align 8
  %v8450 = load i32, ptr %slot1355, align 8
  %op8451 = and i32 %v8449, %v8450
  store i32 %op8451, ptr %slot1357, align 8
  %v8452 = load i32, ptr %slot1357, align 8
  %cv8453 = zext i32 %v8452 to i64
  %cond8454 = icmp ne i64 %cv8453, 0
  br i1 %cond8454, label %bb_rcownlocal2199, label %bb_rcownedlocal2199
bb_rcownlocal2199:
  %v8455 = load i64, ptr %slot40, align 8
  store i64 %v8455, ptr %slot1358, align 8
  %v8456 = load i64, ptr %slot24, align 8
  store i64 %v8456, ptr %slot1359, align 8
  %v8457 = load i64, ptr %slot64, align 8
  store i64 %v8457, ptr %slot1360, align 8
  %v8458 = load i64, ptr %slot1358, align 8
  %p8459 = inttoptr i64 %v8458 to ptr
  %ld8460 = load i64, ptr %p8459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8460, ptr %slot1361, align 8
  %v8461 = load i64, ptr %slot1361, align 8
  %cmp8462 = icmp ne i64 %v8461, 0
  %cv8463 = zext i1 %cmp8462 to i32
  store i32 %cv8463, ptr %slot1362, align 8
  %v8464 = load i32, ptr %slot1362, align 8
  %cv8465 = zext i32 %v8464 to i64
  %cond8466 = icmp ne i64 %cv8465, 0
  br i1 %cond8466, label %bb_rcgnn2206, label %bb_rcgplain2206
bb_rcgnn2206:
  %v8467 = load i64, ptr %slot1361, align 8
  %op8468 = sub i64 %v8467, 16
  store i64 %op8468, ptr %slot1363, align 8
  %v8469 = load i64, ptr %slot1361, align 8
  %p8470 = inttoptr i64 %v8469 to ptr
  %rgep8471 = getelementptr i8, ptr %p8470, i64 -16
  %ld8472 = load i64, ptr %rgep8471, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8472, ptr %slot1364, align 8
  %v8473 = load i64, ptr %slot1364, align 8
  %op8474 = and i64 %v8473, 4611686018427387906
  store i64 %op8474, ptr %slot1365, align 8
  %v8475 = load i64, ptr %slot1365, align 8
  %cmp8476 = icmp ne i64 %v8475, 0
  %cv8477 = zext i1 %cmp8476 to i32
  store i32 %cv8477, ptr %slot1366, align 8
  %v8478 = load i32, ptr %slot1366, align 8
  %cv8479 = zext i32 %v8478 to i64
  %cond8480 = icmp ne i64 %cv8479, 0
  br i1 %cond8480, label %bb_rcgspecial2206, label %bb_rcginc2206
bb_rcginc2206:
  %v8481 = load i64, ptr %slot1361, align 8
  %op8482 = sub i64 %v8481, 32
  store i64 %op8482, ptr %slot1367, align 8
  %v8483 = load i64, ptr %slot1361, align 8
  %p8484 = inttoptr i64 %v8483 to ptr
  %rgep8485 = getelementptr i8, ptr %p8484, i64 -32
  %ld8486 = load i64, ptr %rgep8485, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8486, ptr %slot1368, align 8
  %v8487 = load i64, ptr %slot1368, align 8
  %op8488 = add i64 %v8487, 1
  store i64 %op8488, ptr %slot1369, align 8
  %v8489 = load i64, ptr %slot1369, align 8
  %cmp8490 = icmp eq i64 %v8489, 0
  %cv8491 = zext i1 %cmp8490 to i32
  store i32 %cv8491, ptr %slot1370, align 8
  %v8492 = load i32, ptr %slot1370, align 8
  %cv8493 = zext i32 %v8492 to i64
  %cond8494 = icmp ne i64 %cv8493, 0
  br i1 %cond8494, label %bb_rcglimit2206, label %bb_rcgcapacity2206
bb_rcglimit2206:
  %v8495 = load i64, ptr %slot1, align 8
  %p8496 = inttoptr i64 %v8495 to ptr
  %call8497 = call i32 @myl_qbe_rc_status(ptr %p8496, i32 2) nomerge, !dbg !180
  store i32 %call8497, ptr %slot1371, align 8
  br label %bb_failure
bb_rcgcapacity2206:
  %v8498 = load i64, ptr %slot1369, align 8
  %v8499 = load i64, ptr %slot1361, align 8
  %p8500 = inttoptr i64 %v8499 to ptr
  %rgep8501 = getelementptr i8, ptr %p8500, i64 -32
  store i64 %v8498, ptr %rgep8501, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2206
bb_rcgspecial2206:
  %v8502 = load i64, ptr %slot1364, align 8
  %op8503 = and i64 %v8502, 4611686018427387904
  store i64 %op8503, ptr %slot1372, align 8
  %v8504 = load i64, ptr %slot1372, align 8
  %cmp8505 = icmp ne i64 %v8504, 0
  %cv8506 = zext i1 %cmp8505 to i32
  store i32 %cv8506, ptr %slot1373, align 8
  %v8507 = load i32, ptr %slot1373, align 8
  %cv8508 = zext i32 %v8507 to i64
  %cond8509 = icmp ne i64 %cv8508, 0
  br i1 %cond8509, label %bb_rcgslow2206, label %bb_rcgplain2206
bb_rcgslow2206:
  %v8510 = load i64, ptr %slot63, align 8
  %v8511 = load i64, ptr %slot1359, align 8
  %v8512 = load i64, ptr %slot1358, align 8
  %v8513 = load i64, ptr %slot1360, align 8
  %cv8514 = trunc i64 %v8513 to i32
  %call8515 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v8510, i64 %v8511, i64 %v8512, i32 %cv8514) nomerge, !dbg !180
  store i32 %call8515, ptr %slot1374, align 8
  %v8516 = load i32, ptr %slot1374, align 8
  %cv8517 = zext i32 %v8516 to i64
  %cond8518 = icmp ne i64 %cv8517, 0
  br i1 %cond8518, label %bb_rcsuccess2220, label %bb_rcfailure2220
bb_rcfailure2220:
  %v8519 = load i64, ptr %slot63, align 8
  %p8520 = inttoptr i64 %v8519 to ptr
  %call8521 = call i32 @myl_rc_take_failure(ptr %p8520) nomerge, !dbg !180
  store i32 %call8521, ptr %slot1375, align 8
  %v8522 = load i64, ptr %slot1, align 8
  %p8523 = inttoptr i64 %v8522 to ptr
  %v8524 = load i32, ptr %slot1375, align 8
  %call8525 = call i32 @myl_qbe_rc_status(ptr %p8523, i32 %v8524) nomerge, !dbg !180
  store i32 %call8525, ptr %slot1376, align 8
  br label %bb_failure
bb_rcsuccess2220:
  br label %bb_rcgdone2206
bb_rcgplain2206:
  %v8526 = load i64, ptr %slot1361, align 8
  %v8527 = load i64, ptr %slot1359, align 8
  %p8528 = inttoptr i64 %v8527 to ptr
  store i64 %v8526, ptr %p8528, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2206
bb_rcgdone2206:
  %v8529 = load i64, ptr %slot20, align 8
  %p8530 = inttoptr i64 %v8529 to ptr
  store i32 2, ptr %p8530, align 4, !alias.scope !3, !noalias !4
  %v8531 = load i64, ptr %slot19, align 8
  %p8532 = inttoptr i64 %v8531 to ptr
  store i32 1, ptr %p8532, align 4, !alias.scope !3, !noalias !4
  %v8533 = load i64, ptr %slot9, align 8
  %p8534 = inttoptr i64 %v8533 to ptr
  %ld8535 = load i32, ptr %p8534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8535, ptr %slot1377, align 8
  %v8536 = load i32, ptr %slot1377, align 8
  %cv8537 = zext i32 %v8536 to i64
  %cond8538 = icmp ne i64 %cv8537, 0
  br i1 %cond8538, label %bb_rcslotdrop2227, label %bb_rcslotdone2227
bb_rcslotdrop2227:
  %v8539 = load i64, ptr %slot9, align 8
  %p8540 = inttoptr i64 %v8539 to ptr
  store i32 0, ptr %p8540, align 4, !alias.scope !3, !noalias !4
  %v8541 = load i64, ptr %slot40, align 8
  store i64 %v8541, ptr %slot1378, align 8
  %v8542 = load i64, ptr %slot10, align 8
  %p8543 = inttoptr i64 %v8542 to ptr
  %ld8544 = load i32, ptr %p8543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8544, ptr %slot1379, align 8
  %v8545 = load i32, ptr %slot1379, align 8
  %op8546 = and i32 %v8545, 28
  store i32 %op8546, ptr %slot1380, align 8
  %v8547 = load i32, ptr %slot1380, align 8
  %cv8548 = zext i32 %v8547 to i64
  %cond8549 = icmp ne i64 %cv8548, 0
  br i1 %cond8549, label %bb_rcslotrole2227, label %bb_rcslotowner2227
bb_rcslotrole2227:
  %v8550 = load i64, ptr %slot63, align 8
  store i64 %v8550, ptr %slot1381, align 8
  %v8551 = load i64, ptr %slot1378, align 8
  %p8552 = inttoptr i64 %v8551 to ptr
  %ld8553 = load i64, ptr %p8552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8553, ptr %slot1382, align 8
  %v8554 = load i64, ptr %slot1382, align 8
  %cmp8555 = icmp ne i64 %v8554, 0
  %cv8556 = zext i1 %cmp8555 to i32
  store i32 %cv8556, ptr %slot1383, align 8
  %v8557 = load i32, ptr %slot1383, align 8
  %cv8558 = zext i32 %v8557 to i64
  %cond8559 = icmp ne i64 %cv8558, 0
  br i1 %cond8559, label %bb_rcgnn2243, label %bb_rcgdone2243
bb_rcgnn2243:
  %v8560 = load i64, ptr %slot1382, align 8
  %op8561 = sub i64 %v8560, 16
  store i64 %op8561, ptr %slot1384, align 8
  %v8562 = load i64, ptr %slot1382, align 8
  %p8563 = inttoptr i64 %v8562 to ptr
  %rgep8564 = getelementptr i8, ptr %p8563, i64 -16
  %ld8565 = load i64, ptr %rgep8564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8565, ptr %slot1385, align 8
  %v8566 = load i64, ptr %slot1385, align 8
  %op8567 = and i64 %v8566, 4611686018427387906
  store i64 %op8567, ptr %slot1386, align 8
  %v8568 = load i64, ptr %slot1386, align 8
  %cmp8569 = icmp ne i64 %v8568, 0
  %cv8570 = zext i1 %cmp8569 to i32
  store i32 %cv8570, ptr %slot1387, align 8
  %v8571 = load i32, ptr %slot1387, align 8
  %cv8572 = zext i32 %v8571 to i64
  %cond8573 = icmp ne i64 %cv8572, 0
  br i1 %cond8573, label %bb_rcgclear2243, label %bb_rcgcounted2243
bb_rcgcounted2243:
  %v8574 = load i64, ptr %slot1382, align 8
  %op8575 = sub i64 %v8574, 24
  store i64 %op8575, ptr %slot1388, align 8
  %v8576 = load i64, ptr %slot1382, align 8
  %p8577 = inttoptr i64 %v8576 to ptr
  %rgep8578 = getelementptr i8, ptr %p8577, i64 -24
  %ld8579 = load i64, ptr %rgep8578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8579, ptr %slot1389, align 8
  %v8580 = load i64, ptr %slot1389, align 8
  %op8581 = sub i64 %v8580, 1
  store i64 %op8581, ptr %slot1390, align 8
  %v8582 = load i64, ptr %slot1390, align 8
  %cmp8583 = icmp eq i64 %v8582, 0
  %cv8584 = zext i1 %cmp8583 to i32
  store i32 %cv8584, ptr %slot1391, align 8
  %v8585 = load i32, ptr %slot1391, align 8
  %cv8586 = zext i32 %v8585 to i64
  %cond8587 = icmp ne i64 %cv8586, 0
  br i1 %cond8587, label %bb_rcglast2243, label %bb_rcgdec2243
bb_rcglast2243:
  %v8588 = load i64, ptr %slot1382, align 8
  %op8589 = sub i64 %v8588, 32
  store i64 %op8589, ptr %slot1392, align 8
  %v8590 = load i64, ptr %slot1382, align 8
  %p8591 = inttoptr i64 %v8590 to ptr
  %rgep8592 = getelementptr i8, ptr %p8591, i64 -32
  %ld8593 = load i64, ptr %rgep8592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8593, ptr %slot1393, align 8
  %v8594 = load i64, ptr %slot1393, align 8
  %cmp8595 = icmp ne i64 %v8594, 0
  %cv8596 = zext i1 %cmp8595 to i32
  store i32 %cv8596, ptr %slot1394, align 8
  %v8597 = load i32, ptr %slot1394, align 8
  %cv8598 = zext i32 %v8597 to i64
  %cond8599 = icmp ne i64 %cv8598, 0
  br i1 %cond8599, label %bb_rcgdec2243, label %bb_rcgslow2243
bb_rcgslow2243:
  %v8600 = load i64, ptr %slot1381, align 8
  %v8601 = load i64, ptr %slot1378, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v8600, i64 %v8601) nomerge, !dbg !180
  br label %bb_rcgdone2243
bb_rcgdec2243:
  %v8602 = load i64, ptr %slot1390, align 8
  %v8603 = load i64, ptr %slot1382, align 8
  %p8604 = inttoptr i64 %v8603 to ptr
  %rgep8605 = getelementptr i8, ptr %p8604, i64 -24
  store i64 %v8602, ptr %rgep8605, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2243
bb_rcgclear2243:
  %v8606 = load i64, ptr %slot1378, align 8
  %p8607 = inttoptr i64 %v8606 to ptr
  store i64 0, ptr %p8607, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2243
bb_rcgdone2243:
  br label %bb_rcslotdone2227
bb_rcslotowner2227:
  %v8608 = load i64, ptr %slot63, align 8
  store i64 %v8608, ptr %slot1395, align 8
  %v8609 = load i64, ptr %slot1378, align 8
  %p8610 = inttoptr i64 %v8609 to ptr
  %ld8611 = load i64, ptr %p8610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8611, ptr %slot1396, align 8
  %v8612 = load i64, ptr %slot1396, align 8
  %cmp8613 = icmp ne i64 %v8612, 0
  %cv8614 = zext i1 %cmp8613 to i32
  store i32 %cv8614, ptr %slot1397, align 8
  %v8615 = load i32, ptr %slot1397, align 8
  %cv8616 = zext i32 %v8615 to i64
  %cond8617 = icmp ne i64 %cv8616, 0
  br i1 %cond8617, label %bb_rcgnn2258, label %bb_rcgdone2258
bb_rcgnn2258:
  %v8618 = load i64, ptr %slot1396, align 8
  %op8619 = sub i64 %v8618, 16
  store i64 %op8619, ptr %slot1398, align 8
  %v8620 = load i64, ptr %slot1396, align 8
  %p8621 = inttoptr i64 %v8620 to ptr
  %rgep8622 = getelementptr i8, ptr %p8621, i64 -16
  %ld8623 = load i64, ptr %rgep8622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8623, ptr %slot1399, align 8
  %v8624 = load i64, ptr %slot1399, align 8
  %op8625 = and i64 %v8624, 4611686018427387906
  store i64 %op8625, ptr %slot1400, align 8
  %v8626 = load i64, ptr %slot1400, align 8
  %cmp8627 = icmp ne i64 %v8626, 0
  %cv8628 = zext i1 %cmp8627 to i32
  store i32 %cv8628, ptr %slot1401, align 8
  %v8629 = load i32, ptr %slot1401, align 8
  %cv8630 = zext i32 %v8629 to i64
  %cond8631 = icmp ne i64 %cv8630, 0
  br i1 %cond8631, label %bb_rcgclear2258, label %bb_rcgcounted2258
bb_rcgcounted2258:
  %v8632 = load i64, ptr %slot1396, align 8
  %op8633 = sub i64 %v8632, 32
  store i64 %op8633, ptr %slot1402, align 8
  %v8634 = load i64, ptr %slot1396, align 8
  %p8635 = inttoptr i64 %v8634 to ptr
  %rgep8636 = getelementptr i8, ptr %p8635, i64 -32
  %ld8637 = load i64, ptr %rgep8636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8637, ptr %slot1403, align 8
  %v8638 = load i64, ptr %slot1403, align 8
  %op8639 = sub i64 %v8638, 1
  store i64 %op8639, ptr %slot1404, align 8
  %v8640 = load i64, ptr %slot1404, align 8
  %cmp8641 = icmp eq i64 %v8640, 0
  %cv8642 = zext i1 %cmp8641 to i32
  store i32 %cv8642, ptr %slot1405, align 8
  %v8643 = load i32, ptr %slot1405, align 8
  %cv8644 = zext i32 %v8643 to i64
  %cond8645 = icmp ne i64 %cv8644, 0
  br i1 %cond8645, label %bb_rcglast2258, label %bb_rcgdec2258
bb_rcglast2258:
  %v8646 = load i64, ptr %slot1396, align 8
  %op8647 = sub i64 %v8646, 24
  store i64 %op8647, ptr %slot1406, align 8
  %v8648 = load i64, ptr %slot1396, align 8
  %p8649 = inttoptr i64 %v8648 to ptr
  %rgep8650 = getelementptr i8, ptr %p8649, i64 -24
  %ld8651 = load i64, ptr %rgep8650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8651, ptr %slot1407, align 8
  %v8652 = load i64, ptr %slot1407, align 8
  %cmp8653 = icmp ne i64 %v8652, 0
  %cv8654 = zext i1 %cmp8653 to i32
  store i32 %cv8654, ptr %slot1408, align 8
  %v8655 = load i32, ptr %slot1408, align 8
  %cv8656 = zext i32 %v8655 to i64
  %cond8657 = icmp ne i64 %cv8656, 0
  br i1 %cond8657, label %bb_rcgdec2258, label %bb_rcgslow2258
bb_rcgslow2258:
  %v8658 = load i64, ptr %slot1395, align 8
  %v8659 = load i64, ptr %slot1378, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v8658, i64 %v8659) nomerge, !dbg !180
  br label %bb_rcgdone2258
bb_rcgdec2258:
  %v8660 = load i64, ptr %slot1404, align 8
  %v8661 = load i64, ptr %slot1396, align 8
  %p8662 = inttoptr i64 %v8661 to ptr
  %rgep8663 = getelementptr i8, ptr %p8662, i64 -32
  store i64 %v8660, ptr %rgep8663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2258
bb_rcgclear2258:
  %v8664 = load i64, ptr %slot1378, align 8
  %p8665 = inttoptr i64 %v8664 to ptr
  store i64 0, ptr %p8665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2258
bb_rcgdone2258:
  br label %bb_rcslotdone2227
bb_rcslotdone2227:
  %v8666 = load i64, ptr %slot24, align 8
  store i64 %v8666, ptr %slot1409, align 8
  %v8667 = load i64, ptr %slot1409, align 8
  %v8668 = load i64, ptr %slot1358, align 8
  %p8669 = inttoptr i64 %v8667 to ptr
  %p8670 = inttoptr i64 %v8668 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8670, ptr %p8669, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8671 = load i64, ptr %slot10, align 8
  %p8672 = inttoptr i64 %v8671 to ptr
  store i32 2, ptr %p8672, align 4, !alias.scope !3, !noalias !4
  %v8673 = load i64, ptr %slot9, align 8
  %p8674 = inttoptr i64 %v8673 to ptr
  store i32 1, ptr %p8674, align 4, !alias.scope !3, !noalias !4
  %v8675 = load i64, ptr %slot19, align 8
  %p8676 = inttoptr i64 %v8675 to ptr
  store i32 0, ptr %p8676, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2199
bb_rcownedlocal2199:
  %v8677 = load i64, ptr %slot10, align 8
  %p8678 = inttoptr i64 %v8677 to ptr
  store i32 2, ptr %p8678, align 4, !alias.scope !3, !noalias !4
  %v8679 = load i64, ptr %slot1353, align 8
  %p8680 = inttoptr i64 %v8679 to ptr
  %ld8681 = load i64, ptr %p8680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8681, ptr %slot1410, align 8
  %v8682 = load i64, ptr %slot1410, align 8
  %cmp8683 = icmp ne i64 %v8682, 0
  %cv8684 = zext i1 %cmp8683 to i32
  store i32 %cv8684, ptr %slot1411, align 8
  %v8685 = load i32, ptr %slot1411, align 8
  %cv8686 = zext i32 %v8685 to i64
  %cond8687 = icmp ne i64 %cv8686, 0
  br i1 %cond8687, label %bb_rcguniquenn2267, label %bb_rcgunique2267
bb_rcguniquenn2267:
  %v8688 = load i64, ptr %slot1410, align 8
  %op8689 = sub i64 %v8688, 16
  store i64 %op8689, ptr %slot1412, align 8
  %v8690 = load i64, ptr %slot1410, align 8
  %p8691 = inttoptr i64 %v8690 to ptr
  %rgep8692 = getelementptr i8, ptr %p8691, i64 -16
  %ld8693 = load i64, ptr %rgep8692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8693, ptr %slot1413, align 8
  %v8694 = load i64, ptr %slot1413, align 8
  %op8695 = and i64 %v8694, 6917529027641081858
  store i64 %op8695, ptr %slot1414, align 8
  %v8696 = load i64, ptr %slot1414, align 8
  %cmp8697 = icmp ne i64 %v8696, 0
  %cv8698 = zext i1 %cmp8697 to i32
  store i32 %cv8698, ptr %slot1415, align 8
  %v8699 = load i32, ptr %slot1415, align 8
  %cv8700 = zext i32 %v8699 to i64
  %cond8701 = icmp ne i64 %cv8700, 0
  br i1 %cond8701, label %bb_rcguniqueslow2267, label %bb_rcguniquecount2267
bb_rcguniquecount2267:
  %v8702 = load i64, ptr %slot1410, align 8
  %op8703 = sub i64 %v8702, 32
  store i64 %op8703, ptr %slot1416, align 8
  %v8704 = load i64, ptr %slot1410, align 8
  %p8705 = inttoptr i64 %v8704 to ptr
  %rgep8706 = getelementptr i8, ptr %p8705, i64 -32
  %ld8707 = load i64, ptr %rgep8706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8707, ptr %slot1417, align 8
  %v8708 = load i64, ptr %slot1417, align 8
  %cmp8709 = icmp ult i64 %v8708, 2
  %cv8710 = zext i1 %cmp8709 to i32
  store i32 %cv8710, ptr %slot1418, align 8
  %v8711 = load i32, ptr %slot1418, align 8
  %cv8712 = zext i32 %v8711 to i64
  %cond8713 = icmp ne i64 %cv8712, 0
  br i1 %cond8713, label %bb_rcgunique2267, label %bb_rcguniqueslow2267
bb_rcguniqueslow2267:
  %v8714 = load i64, ptr %slot1, align 8
  %p8715 = inttoptr i64 %v8714 to ptr
  %p8716 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v8717 = load i64, ptr %slot1353, align 8
  %p8718 = inttoptr i64 %v8717 to ptr
  %v8719 = load i64, ptr %slot9, align 8
  %p8720 = inttoptr i64 %v8719 to ptr
  %call8721 = call i32 @myl_qbe_rc_unique_local(ptr %p8715, ptr %p8716, ptr %p8718, ptr %p8720) nomerge, !dbg !180
  store i32 %call8721, ptr %slot1419, align 8
  %v8722 = load i32, ptr %slot1419, align 8
  %cv8723 = zext i32 %v8722 to i64
  %cond8724 = icmp ne i64 %cv8723, 0
  br i1 %cond8724, label %bb_rcunique2278, label %bb_failure
bb_rcunique2278:
  br label %bb_rcgunique2267
bb_rcgunique2267:
  %v8725 = load i64, ptr %slot40, align 8
  %p8726 = inttoptr i64 %v8725 to ptr
  %ld8727 = load i64, ptr %p8726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8727, ptr %slot1420, align 8
  %v8728 = load i64, ptr %slot44, align 8
  store i64 %v8728, ptr %slot1421, align 8
  %v8729 = load i64, ptr %slot1421, align 8
  %p8730 = inttoptr i64 %v8729 to ptr
  %ld8731 = load i64, ptr %p8730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8731, ptr %slot1422, align 8
  %v8732 = load i64, ptr %slot1422, align 8
  %v8733 = load i64, ptr %slot25, align 8
  %p8734 = inttoptr i64 %v8733 to ptr
  store i64 %v8732, ptr %p8734, align 8, !alias.scope !3, !noalias !4
  %v8735 = load i64, ptr %slot25, align 8
  store i64 %v8735, ptr %slot1423, align 8
  %v8736 = load i64, ptr %slot63, align 8
  %v8737 = load i64, ptr %slot1420, align 8
  %v8738 = load i64, ptr %slot1423, align 8
  %call8739 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v8736, i64 %v8737, i64 %v8738) nomerge, !dbg !180
  store i32 %call8739, ptr %slot1424, align 8
  %v8740 = load i32, ptr %slot1424, align 8
  %cv8741 = zext i32 %v8740 to i64
  %cond8742 = icmp ne i64 %cv8741, 0
  br i1 %cond8742, label %bb_success2284, label %bb_failed2284
bb_failed2284:
  %v8743 = load i64, ptr %slot1, align 8
  %p8744 = inttoptr i64 %v8743 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8744) nomerge, !dbg !180
  unreachable
bb_success2284:
  %v8745 = load i64, ptr %slot44, align 8
  %p8746 = inttoptr i64 %v8745 to ptr
  store i64 0, ptr %p8746, align 8, !alias.scope !3, !noalias !4
  %v8747 = load i64, ptr %slot17, align 8
  %p8748 = inttoptr i64 %v8747 to ptr
  %ld8749 = load i32, ptr %p8748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8749, ptr %slot1425, align 8
  %v8750 = load i32, ptr %slot1425, align 8
  %cv8751 = zext i32 %v8750 to i64
  %cond8752 = icmp ne i64 %cv8751, 0
  br i1 %cond8752, label %bb_rcslotdrop2287, label %bb_rcslotdone2287
bb_rcslotdrop2287:
  %v8753 = load i64, ptr %slot17, align 8
  %p8754 = inttoptr i64 %v8753 to ptr
  store i32 0, ptr %p8754, align 4, !alias.scope !3, !noalias !4
  %v8755 = load i64, ptr %slot22, align 8
  store i64 %v8755, ptr %slot1426, align 8
  %v8756 = load i64, ptr %slot18, align 8
  %p8757 = inttoptr i64 %v8756 to ptr
  %ld8758 = load i32, ptr %p8757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8758, ptr %slot1427, align 8
  %v8759 = load i32, ptr %slot1427, align 8
  %op8760 = and i32 %v8759, 28
  store i32 %op8760, ptr %slot1428, align 8
  %v8761 = load i32, ptr %slot1428, align 8
  %cv8762 = zext i32 %v8761 to i64
  %cond8763 = icmp ne i64 %cv8762, 0
  br i1 %cond8763, label %bb_rcslotrole2287, label %bb_rcslotowner2287
bb_rcslotrole2287:
  %v8764 = load i64, ptr %slot63, align 8
  store i64 %v8764, ptr %slot1429, align 8
  %v8765 = load i64, ptr %slot1426, align 8
  %p8766 = inttoptr i64 %v8765 to ptr
  %ld8767 = load i64, ptr %p8766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8767, ptr %slot1430, align 8
  %v8768 = load i64, ptr %slot1430, align 8
  %cmp8769 = icmp ne i64 %v8768, 0
  %cv8770 = zext i1 %cmp8769 to i32
  store i32 %cv8770, ptr %slot1431, align 8
  %v8771 = load i32, ptr %slot1431, align 8
  %cv8772 = zext i32 %v8771 to i64
  %cond8773 = icmp ne i64 %cv8772, 0
  br i1 %cond8773, label %bb_rcgnn2303, label %bb_rcgdone2303
bb_rcgnn2303:
  %v8774 = load i64, ptr %slot1430, align 8
  %op8775 = sub i64 %v8774, 16
  store i64 %op8775, ptr %slot1432, align 8
  %v8776 = load i64, ptr %slot1430, align 8
  %p8777 = inttoptr i64 %v8776 to ptr
  %rgep8778 = getelementptr i8, ptr %p8777, i64 -16
  %ld8779 = load i64, ptr %rgep8778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8779, ptr %slot1433, align 8
  %v8780 = load i64, ptr %slot1433, align 8
  %op8781 = and i64 %v8780, 4611686018427387906
  store i64 %op8781, ptr %slot1434, align 8
  %v8782 = load i64, ptr %slot1434, align 8
  %cmp8783 = icmp ne i64 %v8782, 0
  %cv8784 = zext i1 %cmp8783 to i32
  store i32 %cv8784, ptr %slot1435, align 8
  %v8785 = load i32, ptr %slot1435, align 8
  %cv8786 = zext i32 %v8785 to i64
  %cond8787 = icmp ne i64 %cv8786, 0
  br i1 %cond8787, label %bb_rcgclear2303, label %bb_rcgcounted2303
bb_rcgcounted2303:
  %v8788 = load i64, ptr %slot1430, align 8
  %op8789 = sub i64 %v8788, 24
  store i64 %op8789, ptr %slot1436, align 8
  %v8790 = load i64, ptr %slot1430, align 8
  %p8791 = inttoptr i64 %v8790 to ptr
  %rgep8792 = getelementptr i8, ptr %p8791, i64 -24
  %ld8793 = load i64, ptr %rgep8792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8793, ptr %slot1437, align 8
  %v8794 = load i64, ptr %slot1437, align 8
  %op8795 = sub i64 %v8794, 1
  store i64 %op8795, ptr %slot1438, align 8
  %v8796 = load i64, ptr %slot1438, align 8
  %cmp8797 = icmp eq i64 %v8796, 0
  %cv8798 = zext i1 %cmp8797 to i32
  store i32 %cv8798, ptr %slot1439, align 8
  %v8799 = load i32, ptr %slot1439, align 8
  %cv8800 = zext i32 %v8799 to i64
  %cond8801 = icmp ne i64 %cv8800, 0
  br i1 %cond8801, label %bb_rcglast2303, label %bb_rcgdec2303
bb_rcglast2303:
  %v8802 = load i64, ptr %slot1430, align 8
  %op8803 = sub i64 %v8802, 32
  store i64 %op8803, ptr %slot1440, align 8
  %v8804 = load i64, ptr %slot1430, align 8
  %p8805 = inttoptr i64 %v8804 to ptr
  %rgep8806 = getelementptr i8, ptr %p8805, i64 -32
  %ld8807 = load i64, ptr %rgep8806, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8807, ptr %slot1441, align 8
  %v8808 = load i64, ptr %slot1441, align 8
  %cmp8809 = icmp ne i64 %v8808, 0
  %cv8810 = zext i1 %cmp8809 to i32
  store i32 %cv8810, ptr %slot1442, align 8
  %v8811 = load i32, ptr %slot1442, align 8
  %cv8812 = zext i32 %v8811 to i64
  %cond8813 = icmp ne i64 %cv8812, 0
  br i1 %cond8813, label %bb_rcgdec2303, label %bb_rcgslow2303
bb_rcgslow2303:
  %v8814 = load i64, ptr %slot1429, align 8
  %v8815 = load i64, ptr %slot1426, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8814, i64 %v8815) nomerge, !dbg !180
  br label %bb_rcgdone2303
bb_rcgdec2303:
  %v8816 = load i64, ptr %slot1438, align 8
  %v8817 = load i64, ptr %slot1430, align 8
  %p8818 = inttoptr i64 %v8817 to ptr
  %rgep8819 = getelementptr i8, ptr %p8818, i64 -24
  store i64 %v8816, ptr %rgep8819, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2303
bb_rcgclear2303:
  %v8820 = load i64, ptr %slot1426, align 8
  %p8821 = inttoptr i64 %v8820 to ptr
  store i64 0, ptr %p8821, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2303
bb_rcgdone2303:
  br label %bb_rcslotdone2287
bb_rcslotowner2287:
  %v8822 = load i64, ptr %slot63, align 8
  store i64 %v8822, ptr %slot1443, align 8
  %v8823 = load i64, ptr %slot1426, align 8
  %p8824 = inttoptr i64 %v8823 to ptr
  %ld8825 = load i64, ptr %p8824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8825, ptr %slot1444, align 8
  %v8826 = load i64, ptr %slot1444, align 8
  %cmp8827 = icmp ne i64 %v8826, 0
  %cv8828 = zext i1 %cmp8827 to i32
  store i32 %cv8828, ptr %slot1445, align 8
  %v8829 = load i32, ptr %slot1445, align 8
  %cv8830 = zext i32 %v8829 to i64
  %cond8831 = icmp ne i64 %cv8830, 0
  br i1 %cond8831, label %bb_rcgnn2318, label %bb_rcgdone2318
bb_rcgnn2318:
  %v8832 = load i64, ptr %slot1444, align 8
  %op8833 = sub i64 %v8832, 16
  store i64 %op8833, ptr %slot1446, align 8
  %v8834 = load i64, ptr %slot1444, align 8
  %p8835 = inttoptr i64 %v8834 to ptr
  %rgep8836 = getelementptr i8, ptr %p8835, i64 -16
  %ld8837 = load i64, ptr %rgep8836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8837, ptr %slot1447, align 8
  %v8838 = load i64, ptr %slot1447, align 8
  %op8839 = and i64 %v8838, 4611686018427387906
  store i64 %op8839, ptr %slot1448, align 8
  %v8840 = load i64, ptr %slot1448, align 8
  %cmp8841 = icmp ne i64 %v8840, 0
  %cv8842 = zext i1 %cmp8841 to i32
  store i32 %cv8842, ptr %slot1449, align 8
  %v8843 = load i32, ptr %slot1449, align 8
  %cv8844 = zext i32 %v8843 to i64
  %cond8845 = icmp ne i64 %cv8844, 0
  br i1 %cond8845, label %bb_rcgclear2318, label %bb_rcgcounted2318
bb_rcgcounted2318:
  %v8846 = load i64, ptr %slot1444, align 8
  %op8847 = sub i64 %v8846, 32
  store i64 %op8847, ptr %slot1450, align 8
  %v8848 = load i64, ptr %slot1444, align 8
  %p8849 = inttoptr i64 %v8848 to ptr
  %rgep8850 = getelementptr i8, ptr %p8849, i64 -32
  %ld8851 = load i64, ptr %rgep8850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8851, ptr %slot1451, align 8
  %v8852 = load i64, ptr %slot1451, align 8
  %op8853 = sub i64 %v8852, 1
  store i64 %op8853, ptr %slot1452, align 8
  %v8854 = load i64, ptr %slot1452, align 8
  %cmp8855 = icmp eq i64 %v8854, 0
  %cv8856 = zext i1 %cmp8855 to i32
  store i32 %cv8856, ptr %slot1453, align 8
  %v8857 = load i32, ptr %slot1453, align 8
  %cv8858 = zext i32 %v8857 to i64
  %cond8859 = icmp ne i64 %cv8858, 0
  br i1 %cond8859, label %bb_rcglast2318, label %bb_rcgdec2318
bb_rcglast2318:
  %v8860 = load i64, ptr %slot1444, align 8
  %op8861 = sub i64 %v8860, 24
  store i64 %op8861, ptr %slot1454, align 8
  %v8862 = load i64, ptr %slot1444, align 8
  %p8863 = inttoptr i64 %v8862 to ptr
  %rgep8864 = getelementptr i8, ptr %p8863, i64 -24
  %ld8865 = load i64, ptr %rgep8864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8865, ptr %slot1455, align 8
  %v8866 = load i64, ptr %slot1455, align 8
  %cmp8867 = icmp ne i64 %v8866, 0
  %cv8868 = zext i1 %cmp8867 to i32
  store i32 %cv8868, ptr %slot1456, align 8
  %v8869 = load i32, ptr %slot1456, align 8
  %cv8870 = zext i32 %v8869 to i64
  %cond8871 = icmp ne i64 %cv8870, 0
  br i1 %cond8871, label %bb_rcgdec2318, label %bb_rcgslow2318
bb_rcgslow2318:
  %v8872 = load i64, ptr %slot1443, align 8
  %v8873 = load i64, ptr %slot1426, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8872, i64 %v8873) nomerge, !dbg !180
  br label %bb_rcgdone2318
bb_rcgdec2318:
  %v8874 = load i64, ptr %slot1452, align 8
  %v8875 = load i64, ptr %slot1444, align 8
  %p8876 = inttoptr i64 %v8875 to ptr
  %rgep8877 = getelementptr i8, ptr %p8876, i64 -32
  store i64 %v8874, ptr %rgep8877, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2318
bb_rcgclear2318:
  %v8878 = load i64, ptr %slot1426, align 8
  %p8879 = inttoptr i64 %v8878 to ptr
  store i64 0, ptr %p8879, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2318
bb_rcgdone2318:
  br label %bb_rcslotdone2287
bb_rcslotdone2287:
  %p8880 = inttoptr i64 ptrtoint (ptr @myl_lit_fadbbcee37090aefcabf2bf0f6a9366f5f34ef8c1ccde596b7696a8936daffcc to i64) to ptr
  %ld8881 = load i64, ptr %p8880, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8881, ptr %slot1457, align 8
  %v8882 = load i64, ptr %slot1457, align 8
  %v8883 = load i64, ptr %slot44, align 8
  %p8884 = inttoptr i64 %v8883 to ptr
  store i64 %v8882, ptr %p8884, align 8, !alias.scope !3, !noalias !4
  %v8885 = load i64, ptr %slot44, align 8
  %p8886 = inttoptr i64 %v8885 to ptr
  %ld8887 = load i64, ptr %p8886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8887, ptr %slot1458, align 8
  %v8888 = load i64, ptr %slot1458, align 8
  %v8889 = load i64, ptr %slot23, align 8
  %p8890 = inttoptr i64 %v8889 to ptr
  store i64 %v8888, ptr %p8890, align 8, !alias.scope !3, !noalias !4
  %v8891 = load i64, ptr %slot23, align 8
  store i64 %v8891, ptr %slot1459, align 8
  %v8892 = load i64, ptr %slot24, align 8
  store i64 %v8892, ptr %slot1460, align 8
  %v8893 = load i64, ptr %slot1459, align 8
  %v8894 = load i64, ptr %slot1460, align 8
  %p8895 = inttoptr i64 %v8893 to ptr
  %p8896 = inttoptr i64 %v8894 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8896, ptr %p8895, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8897 = load i64, ptr %slot20, align 8
  %p8898 = inttoptr i64 %v8897 to ptr
  store i32 2, ptr %p8898, align 4, !alias.scope !3, !noalias !4
  %v8899 = load i64, ptr %slot19, align 8
  %p8900 = inttoptr i64 %v8899 to ptr
  store i32 1, ptr %p8900, align 4, !alias.scope !3, !noalias !4
  %v8901 = load i64, ptr %slot22, align 8
  store i64 %v8901, ptr %slot1461, align 8
  %v8902 = load i64, ptr %slot24, align 8
  store i64 %v8902, ptr %slot1462, align 8
  %v8903 = load i64, ptr %slot1462, align 8
  %v8904 = load i64, ptr %slot1461, align 8
  %p8905 = inttoptr i64 %v8903 to ptr
  %p8906 = inttoptr i64 %v8904 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8906, ptr %p8905, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8907 = load i64, ptr %slot18, align 8
  %p8908 = inttoptr i64 %v8907 to ptr
  store i32 2, ptr %p8908, align 4, !alias.scope !3, !noalias !4
  %v8909 = load i64, ptr %slot20, align 8
  %p8910 = inttoptr i64 %v8909 to ptr
  %ld8911 = load i32, ptr %p8910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8911, ptr %slot1463, align 8
  %v8912 = load i32, ptr %slot1463, align 8
  %v8913 = load i64, ptr %slot18, align 8
  %p8914 = inttoptr i64 %v8913 to ptr
  store i32 %v8912, ptr %p8914, align 4, !alias.scope !3, !noalias !4
  %v8915 = load i64, ptr %slot19, align 8
  %p8916 = inttoptr i64 %v8915 to ptr
  store i32 0, ptr %p8916, align 4, !alias.scope !3, !noalias !4
  %v8917 = load i64, ptr %slot17, align 8
  %p8918 = inttoptr i64 %v8917 to ptr
  store i32 1, ptr %p8918, align 4, !alias.scope !3, !noalias !4
  %v8919 = load i64, ptr %slot1461, align 8
  %p8920 = inttoptr i64 %v8919 to ptr
  %ld8921 = load i64, ptr %p8920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8921, ptr %slot1464, align 8
  %v8922 = load i64, ptr %slot1464, align 8
  %v8923 = load i64, ptr %slot44, align 8
  %p8924 = inttoptr i64 %v8923 to ptr
  store i64 %v8922, ptr %p8924, align 8, !alias.scope !3, !noalias !4
  %v8925 = load i64, ptr %slot40, align 8
  store i64 %v8925, ptr %slot1465, align 8
  %v8926 = load i64, ptr %slot10, align 8
  %p8927 = inttoptr i64 %v8926 to ptr
  %ld8928 = load i32, ptr %p8927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8928, ptr %slot1466, align 8
  %v8929 = load i32, ptr %slot1466, align 8
  %cmp8930 = icmp eq i32 %v8929, 16
  %cv8931 = zext i1 %cmp8930 to i32
  store i32 %cv8931, ptr %slot1467, align 8
  %v8932 = load i64, ptr %slot9, align 8
  %p8933 = inttoptr i64 %v8932 to ptr
  %ld8934 = load i32, ptr %p8933, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8934, ptr %slot1468, align 8
  %v8935 = load i32, ptr %slot1468, align 8
  %v8936 = load i32, ptr %slot1467, align 8
  %op8937 = and i32 %v8935, %v8936
  store i32 %op8937, ptr %slot1469, align 8
  %v8938 = load i32, ptr %slot1469, align 8
  %cv8939 = zext i32 %v8938 to i64
  %cond8940 = icmp ne i64 %cv8939, 0
  br i1 %cond8940, label %bb_rcownlocal2344, label %bb_rcownedlocal2344
bb_rcownlocal2344:
  %v8941 = load i64, ptr %slot40, align 8
  store i64 %v8941, ptr %slot1470, align 8
  %v8942 = load i64, ptr %slot24, align 8
  store i64 %v8942, ptr %slot1471, align 8
  %v8943 = load i64, ptr %slot64, align 8
  store i64 %v8943, ptr %slot1472, align 8
  %v8944 = load i64, ptr %slot1470, align 8
  %p8945 = inttoptr i64 %v8944 to ptr
  %ld8946 = load i64, ptr %p8945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8946, ptr %slot1473, align 8
  %v8947 = load i64, ptr %slot1473, align 8
  %cmp8948 = icmp ne i64 %v8947, 0
  %cv8949 = zext i1 %cmp8948 to i32
  store i32 %cv8949, ptr %slot1474, align 8
  %v8950 = load i32, ptr %slot1474, align 8
  %cv8951 = zext i32 %v8950 to i64
  %cond8952 = icmp ne i64 %cv8951, 0
  br i1 %cond8952, label %bb_rcgnn2351, label %bb_rcgplain2351
bb_rcgnn2351:
  %v8953 = load i64, ptr %slot1473, align 8
  %op8954 = sub i64 %v8953, 16
  store i64 %op8954, ptr %slot1475, align 8
  %v8955 = load i64, ptr %slot1473, align 8
  %p8956 = inttoptr i64 %v8955 to ptr
  %rgep8957 = getelementptr i8, ptr %p8956, i64 -16
  %ld8958 = load i64, ptr %rgep8957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8958, ptr %slot1476, align 8
  %v8959 = load i64, ptr %slot1476, align 8
  %op8960 = and i64 %v8959, 4611686018427387906
  store i64 %op8960, ptr %slot1477, align 8
  %v8961 = load i64, ptr %slot1477, align 8
  %cmp8962 = icmp ne i64 %v8961, 0
  %cv8963 = zext i1 %cmp8962 to i32
  store i32 %cv8963, ptr %slot1478, align 8
  %v8964 = load i32, ptr %slot1478, align 8
  %cv8965 = zext i32 %v8964 to i64
  %cond8966 = icmp ne i64 %cv8965, 0
  br i1 %cond8966, label %bb_rcgspecial2351, label %bb_rcginc2351
bb_rcginc2351:
  %v8967 = load i64, ptr %slot1473, align 8
  %op8968 = sub i64 %v8967, 32
  store i64 %op8968, ptr %slot1479, align 8
  %v8969 = load i64, ptr %slot1473, align 8
  %p8970 = inttoptr i64 %v8969 to ptr
  %rgep8971 = getelementptr i8, ptr %p8970, i64 -32
  %ld8972 = load i64, ptr %rgep8971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8972, ptr %slot1480, align 8
  %v8973 = load i64, ptr %slot1480, align 8
  %op8974 = add i64 %v8973, 1
  store i64 %op8974, ptr %slot1481, align 8
  %v8975 = load i64, ptr %slot1481, align 8
  %cmp8976 = icmp eq i64 %v8975, 0
  %cv8977 = zext i1 %cmp8976 to i32
  store i32 %cv8977, ptr %slot1482, align 8
  %v8978 = load i32, ptr %slot1482, align 8
  %cv8979 = zext i32 %v8978 to i64
  %cond8980 = icmp ne i64 %cv8979, 0
  br i1 %cond8980, label %bb_rcglimit2351, label %bb_rcgcapacity2351
bb_rcglimit2351:
  %v8981 = load i64, ptr %slot1, align 8
  %p8982 = inttoptr i64 %v8981 to ptr
  %call8983 = call i32 @myl_qbe_rc_status(ptr %p8982, i32 2) nomerge, !dbg !182
  store i32 %call8983, ptr %slot1483, align 8
  br label %bb_failure
bb_rcgcapacity2351:
  %v8984 = load i64, ptr %slot1481, align 8
  %v8985 = load i64, ptr %slot1473, align 8
  %p8986 = inttoptr i64 %v8985 to ptr
  %rgep8987 = getelementptr i8, ptr %p8986, i64 -32
  store i64 %v8984, ptr %rgep8987, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2351
bb_rcgspecial2351:
  %v8988 = load i64, ptr %slot1476, align 8
  %op8989 = and i64 %v8988, 4611686018427387904
  store i64 %op8989, ptr %slot1484, align 8
  %v8990 = load i64, ptr %slot1484, align 8
  %cmp8991 = icmp ne i64 %v8990, 0
  %cv8992 = zext i1 %cmp8991 to i32
  store i32 %cv8992, ptr %slot1485, align 8
  %v8993 = load i32, ptr %slot1485, align 8
  %cv8994 = zext i32 %v8993 to i64
  %cond8995 = icmp ne i64 %cv8994, 0
  br i1 %cond8995, label %bb_rcgslow2351, label %bb_rcgplain2351
bb_rcgslow2351:
  %v8996 = load i64, ptr %slot63, align 8
  %v8997 = load i64, ptr %slot1471, align 8
  %v8998 = load i64, ptr %slot1470, align 8
  %v8999 = load i64, ptr %slot1472, align 8
  %cv9000 = trunc i64 %v8999 to i32
  %call9001 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v8996, i64 %v8997, i64 %v8998, i32 %cv9000) nomerge, !dbg !182
  store i32 %call9001, ptr %slot1486, align 8
  %v9002 = load i32, ptr %slot1486, align 8
  %cv9003 = zext i32 %v9002 to i64
  %cond9004 = icmp ne i64 %cv9003, 0
  br i1 %cond9004, label %bb_rcsuccess2365, label %bb_rcfailure2365
bb_rcfailure2365:
  %v9005 = load i64, ptr %slot63, align 8
  %p9006 = inttoptr i64 %v9005 to ptr
  %call9007 = call i32 @myl_rc_take_failure(ptr %p9006) nomerge, !dbg !182
  store i32 %call9007, ptr %slot1487, align 8
  %v9008 = load i64, ptr %slot1, align 8
  %p9009 = inttoptr i64 %v9008 to ptr
  %v9010 = load i32, ptr %slot1487, align 8
  %call9011 = call i32 @myl_qbe_rc_status(ptr %p9009, i32 %v9010) nomerge, !dbg !182
  store i32 %call9011, ptr %slot1488, align 8
  br label %bb_failure
bb_rcsuccess2365:
  br label %bb_rcgdone2351
bb_rcgplain2351:
  %v9012 = load i64, ptr %slot1473, align 8
  %v9013 = load i64, ptr %slot1471, align 8
  %p9014 = inttoptr i64 %v9013 to ptr
  store i64 %v9012, ptr %p9014, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2351
bb_rcgdone2351:
  %v9015 = load i64, ptr %slot20, align 8
  %p9016 = inttoptr i64 %v9015 to ptr
  store i32 2, ptr %p9016, align 4, !alias.scope !3, !noalias !4
  %v9017 = load i64, ptr %slot19, align 8
  %p9018 = inttoptr i64 %v9017 to ptr
  store i32 1, ptr %p9018, align 4, !alias.scope !3, !noalias !4
  %v9019 = load i64, ptr %slot9, align 8
  %p9020 = inttoptr i64 %v9019 to ptr
  %ld9021 = load i32, ptr %p9020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9021, ptr %slot1489, align 8
  %v9022 = load i32, ptr %slot1489, align 8
  %cv9023 = zext i32 %v9022 to i64
  %cond9024 = icmp ne i64 %cv9023, 0
  br i1 %cond9024, label %bb_rcslotdrop2372, label %bb_rcslotdone2372
bb_rcslotdrop2372:
  %v9025 = load i64, ptr %slot9, align 8
  %p9026 = inttoptr i64 %v9025 to ptr
  store i32 0, ptr %p9026, align 4, !alias.scope !3, !noalias !4
  %v9027 = load i64, ptr %slot40, align 8
  store i64 %v9027, ptr %slot1490, align 8
  %v9028 = load i64, ptr %slot10, align 8
  %p9029 = inttoptr i64 %v9028 to ptr
  %ld9030 = load i32, ptr %p9029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9030, ptr %slot1491, align 8
  %v9031 = load i32, ptr %slot1491, align 8
  %op9032 = and i32 %v9031, 28
  store i32 %op9032, ptr %slot1492, align 8
  %v9033 = load i32, ptr %slot1492, align 8
  %cv9034 = zext i32 %v9033 to i64
  %cond9035 = icmp ne i64 %cv9034, 0
  br i1 %cond9035, label %bb_rcslotrole2372, label %bb_rcslotowner2372
bb_rcslotrole2372:
  %v9036 = load i64, ptr %slot63, align 8
  store i64 %v9036, ptr %slot1493, align 8
  %v9037 = load i64, ptr %slot1490, align 8
  %p9038 = inttoptr i64 %v9037 to ptr
  %ld9039 = load i64, ptr %p9038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9039, ptr %slot1494, align 8
  %v9040 = load i64, ptr %slot1494, align 8
  %cmp9041 = icmp ne i64 %v9040, 0
  %cv9042 = zext i1 %cmp9041 to i32
  store i32 %cv9042, ptr %slot1495, align 8
  %v9043 = load i32, ptr %slot1495, align 8
  %cv9044 = zext i32 %v9043 to i64
  %cond9045 = icmp ne i64 %cv9044, 0
  br i1 %cond9045, label %bb_rcgnn2388, label %bb_rcgdone2388
bb_rcgnn2388:
  %v9046 = load i64, ptr %slot1494, align 8
  %op9047 = sub i64 %v9046, 16
  store i64 %op9047, ptr %slot1496, align 8
  %v9048 = load i64, ptr %slot1494, align 8
  %p9049 = inttoptr i64 %v9048 to ptr
  %rgep9050 = getelementptr i8, ptr %p9049, i64 -16
  %ld9051 = load i64, ptr %rgep9050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9051, ptr %slot1497, align 8
  %v9052 = load i64, ptr %slot1497, align 8
  %op9053 = and i64 %v9052, 4611686018427387906
  store i64 %op9053, ptr %slot1498, align 8
  %v9054 = load i64, ptr %slot1498, align 8
  %cmp9055 = icmp ne i64 %v9054, 0
  %cv9056 = zext i1 %cmp9055 to i32
  store i32 %cv9056, ptr %slot1499, align 8
  %v9057 = load i32, ptr %slot1499, align 8
  %cv9058 = zext i32 %v9057 to i64
  %cond9059 = icmp ne i64 %cv9058, 0
  br i1 %cond9059, label %bb_rcgclear2388, label %bb_rcgcounted2388
bb_rcgcounted2388:
  %v9060 = load i64, ptr %slot1494, align 8
  %op9061 = sub i64 %v9060, 24
  store i64 %op9061, ptr %slot1500, align 8
  %v9062 = load i64, ptr %slot1494, align 8
  %p9063 = inttoptr i64 %v9062 to ptr
  %rgep9064 = getelementptr i8, ptr %p9063, i64 -24
  %ld9065 = load i64, ptr %rgep9064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9065, ptr %slot1501, align 8
  %v9066 = load i64, ptr %slot1501, align 8
  %op9067 = sub i64 %v9066, 1
  store i64 %op9067, ptr %slot1502, align 8
  %v9068 = load i64, ptr %slot1502, align 8
  %cmp9069 = icmp eq i64 %v9068, 0
  %cv9070 = zext i1 %cmp9069 to i32
  store i32 %cv9070, ptr %slot1503, align 8
  %v9071 = load i32, ptr %slot1503, align 8
  %cv9072 = zext i32 %v9071 to i64
  %cond9073 = icmp ne i64 %cv9072, 0
  br i1 %cond9073, label %bb_rcglast2388, label %bb_rcgdec2388
bb_rcglast2388:
  %v9074 = load i64, ptr %slot1494, align 8
  %op9075 = sub i64 %v9074, 32
  store i64 %op9075, ptr %slot1504, align 8
  %v9076 = load i64, ptr %slot1494, align 8
  %p9077 = inttoptr i64 %v9076 to ptr
  %rgep9078 = getelementptr i8, ptr %p9077, i64 -32
  %ld9079 = load i64, ptr %rgep9078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9079, ptr %slot1505, align 8
  %v9080 = load i64, ptr %slot1505, align 8
  %cmp9081 = icmp ne i64 %v9080, 0
  %cv9082 = zext i1 %cmp9081 to i32
  store i32 %cv9082, ptr %slot1506, align 8
  %v9083 = load i32, ptr %slot1506, align 8
  %cv9084 = zext i32 %v9083 to i64
  %cond9085 = icmp ne i64 %cv9084, 0
  br i1 %cond9085, label %bb_rcgdec2388, label %bb_rcgslow2388
bb_rcgslow2388:
  %v9086 = load i64, ptr %slot1493, align 8
  %v9087 = load i64, ptr %slot1490, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9086, i64 %v9087) nomerge, !dbg !182
  br label %bb_rcgdone2388
bb_rcgdec2388:
  %v9088 = load i64, ptr %slot1502, align 8
  %v9089 = load i64, ptr %slot1494, align 8
  %p9090 = inttoptr i64 %v9089 to ptr
  %rgep9091 = getelementptr i8, ptr %p9090, i64 -24
  store i64 %v9088, ptr %rgep9091, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2388
bb_rcgclear2388:
  %v9092 = load i64, ptr %slot1490, align 8
  %p9093 = inttoptr i64 %v9092 to ptr
  store i64 0, ptr %p9093, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2388
bb_rcgdone2388:
  br label %bb_rcslotdone2372
bb_rcslotowner2372:
  %v9094 = load i64, ptr %slot63, align 8
  store i64 %v9094, ptr %slot1507, align 8
  %v9095 = load i64, ptr %slot1490, align 8
  %p9096 = inttoptr i64 %v9095 to ptr
  %ld9097 = load i64, ptr %p9096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9097, ptr %slot1508, align 8
  %v9098 = load i64, ptr %slot1508, align 8
  %cmp9099 = icmp ne i64 %v9098, 0
  %cv9100 = zext i1 %cmp9099 to i32
  store i32 %cv9100, ptr %slot1509, align 8
  %v9101 = load i32, ptr %slot1509, align 8
  %cv9102 = zext i32 %v9101 to i64
  %cond9103 = icmp ne i64 %cv9102, 0
  br i1 %cond9103, label %bb_rcgnn2403, label %bb_rcgdone2403
bb_rcgnn2403:
  %v9104 = load i64, ptr %slot1508, align 8
  %op9105 = sub i64 %v9104, 16
  store i64 %op9105, ptr %slot1510, align 8
  %v9106 = load i64, ptr %slot1508, align 8
  %p9107 = inttoptr i64 %v9106 to ptr
  %rgep9108 = getelementptr i8, ptr %p9107, i64 -16
  %ld9109 = load i64, ptr %rgep9108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9109, ptr %slot1511, align 8
  %v9110 = load i64, ptr %slot1511, align 8
  %op9111 = and i64 %v9110, 4611686018427387906
  store i64 %op9111, ptr %slot1512, align 8
  %v9112 = load i64, ptr %slot1512, align 8
  %cmp9113 = icmp ne i64 %v9112, 0
  %cv9114 = zext i1 %cmp9113 to i32
  store i32 %cv9114, ptr %slot1513, align 8
  %v9115 = load i32, ptr %slot1513, align 8
  %cv9116 = zext i32 %v9115 to i64
  %cond9117 = icmp ne i64 %cv9116, 0
  br i1 %cond9117, label %bb_rcgclear2403, label %bb_rcgcounted2403
bb_rcgcounted2403:
  %v9118 = load i64, ptr %slot1508, align 8
  %op9119 = sub i64 %v9118, 32
  store i64 %op9119, ptr %slot1514, align 8
  %v9120 = load i64, ptr %slot1508, align 8
  %p9121 = inttoptr i64 %v9120 to ptr
  %rgep9122 = getelementptr i8, ptr %p9121, i64 -32
  %ld9123 = load i64, ptr %rgep9122, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9123, ptr %slot1515, align 8
  %v9124 = load i64, ptr %slot1515, align 8
  %op9125 = sub i64 %v9124, 1
  store i64 %op9125, ptr %slot1516, align 8
  %v9126 = load i64, ptr %slot1516, align 8
  %cmp9127 = icmp eq i64 %v9126, 0
  %cv9128 = zext i1 %cmp9127 to i32
  store i32 %cv9128, ptr %slot1517, align 8
  %v9129 = load i32, ptr %slot1517, align 8
  %cv9130 = zext i32 %v9129 to i64
  %cond9131 = icmp ne i64 %cv9130, 0
  br i1 %cond9131, label %bb_rcglast2403, label %bb_rcgdec2403
bb_rcglast2403:
  %v9132 = load i64, ptr %slot1508, align 8
  %op9133 = sub i64 %v9132, 24
  store i64 %op9133, ptr %slot1518, align 8
  %v9134 = load i64, ptr %slot1508, align 8
  %p9135 = inttoptr i64 %v9134 to ptr
  %rgep9136 = getelementptr i8, ptr %p9135, i64 -24
  %ld9137 = load i64, ptr %rgep9136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9137, ptr %slot1519, align 8
  %v9138 = load i64, ptr %slot1519, align 8
  %cmp9139 = icmp ne i64 %v9138, 0
  %cv9140 = zext i1 %cmp9139 to i32
  store i32 %cv9140, ptr %slot1520, align 8
  %v9141 = load i32, ptr %slot1520, align 8
  %cv9142 = zext i32 %v9141 to i64
  %cond9143 = icmp ne i64 %cv9142, 0
  br i1 %cond9143, label %bb_rcgdec2403, label %bb_rcgslow2403
bb_rcgslow2403:
  %v9144 = load i64, ptr %slot1507, align 8
  %v9145 = load i64, ptr %slot1490, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9144, i64 %v9145) nomerge, !dbg !182
  br label %bb_rcgdone2403
bb_rcgdec2403:
  %v9146 = load i64, ptr %slot1516, align 8
  %v9147 = load i64, ptr %slot1508, align 8
  %p9148 = inttoptr i64 %v9147 to ptr
  %rgep9149 = getelementptr i8, ptr %p9148, i64 -32
  store i64 %v9146, ptr %rgep9149, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2403
bb_rcgclear2403:
  %v9150 = load i64, ptr %slot1490, align 8
  %p9151 = inttoptr i64 %v9150 to ptr
  store i64 0, ptr %p9151, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2403
bb_rcgdone2403:
  br label %bb_rcslotdone2372
bb_rcslotdone2372:
  %v9152 = load i64, ptr %slot24, align 8
  store i64 %v9152, ptr %slot1521, align 8
  %v9153 = load i64, ptr %slot1521, align 8
  %v9154 = load i64, ptr %slot1470, align 8
  %p9155 = inttoptr i64 %v9153 to ptr
  %p9156 = inttoptr i64 %v9154 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9156, ptr %p9155, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9157 = load i64, ptr %slot10, align 8
  %p9158 = inttoptr i64 %v9157 to ptr
  store i32 2, ptr %p9158, align 4, !alias.scope !3, !noalias !4
  %v9159 = load i64, ptr %slot9, align 8
  %p9160 = inttoptr i64 %v9159 to ptr
  store i32 1, ptr %p9160, align 4, !alias.scope !3, !noalias !4
  %v9161 = load i64, ptr %slot19, align 8
  %p9162 = inttoptr i64 %v9161 to ptr
  store i32 0, ptr %p9162, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2344
bb_rcownedlocal2344:
  %v9163 = load i64, ptr %slot10, align 8
  %p9164 = inttoptr i64 %v9163 to ptr
  store i32 2, ptr %p9164, align 4, !alias.scope !3, !noalias !4
  %v9165 = load i64, ptr %slot1465, align 8
  %p9166 = inttoptr i64 %v9165 to ptr
  %ld9167 = load i64, ptr %p9166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9167, ptr %slot1522, align 8
  %v9168 = load i64, ptr %slot1522, align 8
  %cmp9169 = icmp ne i64 %v9168, 0
  %cv9170 = zext i1 %cmp9169 to i32
  store i32 %cv9170, ptr %slot1523, align 8
  %v9171 = load i32, ptr %slot1523, align 8
  %cv9172 = zext i32 %v9171 to i64
  %cond9173 = icmp ne i64 %cv9172, 0
  br i1 %cond9173, label %bb_rcguniquenn2412, label %bb_rcgunique2412
bb_rcguniquenn2412:
  %v9174 = load i64, ptr %slot1522, align 8
  %op9175 = sub i64 %v9174, 16
  store i64 %op9175, ptr %slot1524, align 8
  %v9176 = load i64, ptr %slot1522, align 8
  %p9177 = inttoptr i64 %v9176 to ptr
  %rgep9178 = getelementptr i8, ptr %p9177, i64 -16
  %ld9179 = load i64, ptr %rgep9178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9179, ptr %slot1525, align 8
  %v9180 = load i64, ptr %slot1525, align 8
  %op9181 = and i64 %v9180, 6917529027641081858
  store i64 %op9181, ptr %slot1526, align 8
  %v9182 = load i64, ptr %slot1526, align 8
  %cmp9183 = icmp ne i64 %v9182, 0
  %cv9184 = zext i1 %cmp9183 to i32
  store i32 %cv9184, ptr %slot1527, align 8
  %v9185 = load i32, ptr %slot1527, align 8
  %cv9186 = zext i32 %v9185 to i64
  %cond9187 = icmp ne i64 %cv9186, 0
  br i1 %cond9187, label %bb_rcguniqueslow2412, label %bb_rcguniquecount2412
bb_rcguniquecount2412:
  %v9188 = load i64, ptr %slot1522, align 8
  %op9189 = sub i64 %v9188, 32
  store i64 %op9189, ptr %slot1528, align 8
  %v9190 = load i64, ptr %slot1522, align 8
  %p9191 = inttoptr i64 %v9190 to ptr
  %rgep9192 = getelementptr i8, ptr %p9191, i64 -32
  %ld9193 = load i64, ptr %rgep9192, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9193, ptr %slot1529, align 8
  %v9194 = load i64, ptr %slot1529, align 8
  %cmp9195 = icmp ult i64 %v9194, 2
  %cv9196 = zext i1 %cmp9195 to i32
  store i32 %cv9196, ptr %slot1530, align 8
  %v9197 = load i32, ptr %slot1530, align 8
  %cv9198 = zext i32 %v9197 to i64
  %cond9199 = icmp ne i64 %cv9198, 0
  br i1 %cond9199, label %bb_rcgunique2412, label %bb_rcguniqueslow2412
bb_rcguniqueslow2412:
  %v9200 = load i64, ptr %slot1, align 8
  %p9201 = inttoptr i64 %v9200 to ptr
  %p9202 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v9203 = load i64, ptr %slot1465, align 8
  %p9204 = inttoptr i64 %v9203 to ptr
  %v9205 = load i64, ptr %slot9, align 8
  %p9206 = inttoptr i64 %v9205 to ptr
  %call9207 = call i32 @myl_qbe_rc_unique_local(ptr %p9201, ptr %p9202, ptr %p9204, ptr %p9206) nomerge, !dbg !182
  store i32 %call9207, ptr %slot1531, align 8
  %v9208 = load i32, ptr %slot1531, align 8
  %cv9209 = zext i32 %v9208 to i64
  %cond9210 = icmp ne i64 %cv9209, 0
  br i1 %cond9210, label %bb_rcunique2423, label %bb_failure
bb_rcunique2423:
  br label %bb_rcgunique2412
bb_rcgunique2412:
  %v9211 = load i64, ptr %slot40, align 8
  %p9212 = inttoptr i64 %v9211 to ptr
  %ld9213 = load i64, ptr %p9212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9213, ptr %slot1532, align 8
  %v9214 = load i64, ptr %slot44, align 8
  store i64 %v9214, ptr %slot1533, align 8
  %v9215 = load i64, ptr %slot1533, align 8
  %p9216 = inttoptr i64 %v9215 to ptr
  %ld9217 = load i64, ptr %p9216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9217, ptr %slot1534, align 8
  %v9218 = load i64, ptr %slot1534, align 8
  %v9219 = load i64, ptr %slot25, align 8
  %p9220 = inttoptr i64 %v9219 to ptr
  store i64 %v9218, ptr %p9220, align 8, !alias.scope !3, !noalias !4
  %v9221 = load i64, ptr %slot25, align 8
  store i64 %v9221, ptr %slot1535, align 8
  %v9222 = load i64, ptr %slot63, align 8
  %v9223 = load i64, ptr %slot1532, align 8
  %v9224 = load i64, ptr %slot1535, align 8
  %call9225 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v9222, i64 %v9223, i64 %v9224) nomerge, !dbg !182
  store i32 %call9225, ptr %slot1536, align 8
  %v9226 = load i32, ptr %slot1536, align 8
  %cv9227 = zext i32 %v9226 to i64
  %cond9228 = icmp ne i64 %cv9227, 0
  br i1 %cond9228, label %bb_success2429, label %bb_failed2429
bb_failed2429:
  %v9229 = load i64, ptr %slot1, align 8
  %p9230 = inttoptr i64 %v9229 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9230) nomerge, !dbg !182
  unreachable
bb_success2429:
  %v9231 = load i64, ptr %slot44, align 8
  %p9232 = inttoptr i64 %v9231 to ptr
  store i64 0, ptr %p9232, align 8, !alias.scope !3, !noalias !4
  %v9233 = load i64, ptr %slot17, align 8
  %p9234 = inttoptr i64 %v9233 to ptr
  %ld9235 = load i32, ptr %p9234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9235, ptr %slot1537, align 8
  %v9236 = load i32, ptr %slot1537, align 8
  %cv9237 = zext i32 %v9236 to i64
  %cond9238 = icmp ne i64 %cv9237, 0
  br i1 %cond9238, label %bb_rcslotdrop2432, label %bb_rcslotdone2432
bb_rcslotdrop2432:
  %v9239 = load i64, ptr %slot17, align 8
  %p9240 = inttoptr i64 %v9239 to ptr
  store i32 0, ptr %p9240, align 4, !alias.scope !3, !noalias !4
  %v9241 = load i64, ptr %slot22, align 8
  store i64 %v9241, ptr %slot1538, align 8
  %v9242 = load i64, ptr %slot18, align 8
  %p9243 = inttoptr i64 %v9242 to ptr
  %ld9244 = load i32, ptr %p9243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9244, ptr %slot1539, align 8
  %v9245 = load i32, ptr %slot1539, align 8
  %op9246 = and i32 %v9245, 28
  store i32 %op9246, ptr %slot1540, align 8
  %v9247 = load i32, ptr %slot1540, align 8
  %cv9248 = zext i32 %v9247 to i64
  %cond9249 = icmp ne i64 %cv9248, 0
  br i1 %cond9249, label %bb_rcslotrole2432, label %bb_rcslotowner2432
bb_rcslotrole2432:
  %v9250 = load i64, ptr %slot63, align 8
  store i64 %v9250, ptr %slot1541, align 8
  %v9251 = load i64, ptr %slot1538, align 8
  %p9252 = inttoptr i64 %v9251 to ptr
  %ld9253 = load i64, ptr %p9252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9253, ptr %slot1542, align 8
  %v9254 = load i64, ptr %slot1542, align 8
  %cmp9255 = icmp ne i64 %v9254, 0
  %cv9256 = zext i1 %cmp9255 to i32
  store i32 %cv9256, ptr %slot1543, align 8
  %v9257 = load i32, ptr %slot1543, align 8
  %cv9258 = zext i32 %v9257 to i64
  %cond9259 = icmp ne i64 %cv9258, 0
  br i1 %cond9259, label %bb_rcgnn2448, label %bb_rcgdone2448
bb_rcgnn2448:
  %v9260 = load i64, ptr %slot1542, align 8
  %op9261 = sub i64 %v9260, 16
  store i64 %op9261, ptr %slot1544, align 8
  %v9262 = load i64, ptr %slot1542, align 8
  %p9263 = inttoptr i64 %v9262 to ptr
  %rgep9264 = getelementptr i8, ptr %p9263, i64 -16
  %ld9265 = load i64, ptr %rgep9264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9265, ptr %slot1545, align 8
  %v9266 = load i64, ptr %slot1545, align 8
  %op9267 = and i64 %v9266, 4611686018427387906
  store i64 %op9267, ptr %slot1546, align 8
  %v9268 = load i64, ptr %slot1546, align 8
  %cmp9269 = icmp ne i64 %v9268, 0
  %cv9270 = zext i1 %cmp9269 to i32
  store i32 %cv9270, ptr %slot1547, align 8
  %v9271 = load i32, ptr %slot1547, align 8
  %cv9272 = zext i32 %v9271 to i64
  %cond9273 = icmp ne i64 %cv9272, 0
  br i1 %cond9273, label %bb_rcgclear2448, label %bb_rcgcounted2448
bb_rcgcounted2448:
  %v9274 = load i64, ptr %slot1542, align 8
  %op9275 = sub i64 %v9274, 24
  store i64 %op9275, ptr %slot1548, align 8
  %v9276 = load i64, ptr %slot1542, align 8
  %p9277 = inttoptr i64 %v9276 to ptr
  %rgep9278 = getelementptr i8, ptr %p9277, i64 -24
  %ld9279 = load i64, ptr %rgep9278, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9279, ptr %slot1549, align 8
  %v9280 = load i64, ptr %slot1549, align 8
  %op9281 = sub i64 %v9280, 1
  store i64 %op9281, ptr %slot1550, align 8
  %v9282 = load i64, ptr %slot1550, align 8
  %cmp9283 = icmp eq i64 %v9282, 0
  %cv9284 = zext i1 %cmp9283 to i32
  store i32 %cv9284, ptr %slot1551, align 8
  %v9285 = load i32, ptr %slot1551, align 8
  %cv9286 = zext i32 %v9285 to i64
  %cond9287 = icmp ne i64 %cv9286, 0
  br i1 %cond9287, label %bb_rcglast2448, label %bb_rcgdec2448
bb_rcglast2448:
  %v9288 = load i64, ptr %slot1542, align 8
  %op9289 = sub i64 %v9288, 32
  store i64 %op9289, ptr %slot1552, align 8
  %v9290 = load i64, ptr %slot1542, align 8
  %p9291 = inttoptr i64 %v9290 to ptr
  %rgep9292 = getelementptr i8, ptr %p9291, i64 -32
  %ld9293 = load i64, ptr %rgep9292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9293, ptr %slot1553, align 8
  %v9294 = load i64, ptr %slot1553, align 8
  %cmp9295 = icmp ne i64 %v9294, 0
  %cv9296 = zext i1 %cmp9295 to i32
  store i32 %cv9296, ptr %slot1554, align 8
  %v9297 = load i32, ptr %slot1554, align 8
  %cv9298 = zext i32 %v9297 to i64
  %cond9299 = icmp ne i64 %cv9298, 0
  br i1 %cond9299, label %bb_rcgdec2448, label %bb_rcgslow2448
bb_rcgslow2448:
  %v9300 = load i64, ptr %slot1541, align 8
  %v9301 = load i64, ptr %slot1538, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9300, i64 %v9301) nomerge, !dbg !182
  br label %bb_rcgdone2448
bb_rcgdec2448:
  %v9302 = load i64, ptr %slot1550, align 8
  %v9303 = load i64, ptr %slot1542, align 8
  %p9304 = inttoptr i64 %v9303 to ptr
  %rgep9305 = getelementptr i8, ptr %p9304, i64 -24
  store i64 %v9302, ptr %rgep9305, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2448
bb_rcgclear2448:
  %v9306 = load i64, ptr %slot1538, align 8
  %p9307 = inttoptr i64 %v9306 to ptr
  store i64 0, ptr %p9307, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2448
bb_rcgdone2448:
  br label %bb_rcslotdone2432
bb_rcslotowner2432:
  %v9308 = load i64, ptr %slot63, align 8
  store i64 %v9308, ptr %slot1555, align 8
  %v9309 = load i64, ptr %slot1538, align 8
  %p9310 = inttoptr i64 %v9309 to ptr
  %ld9311 = load i64, ptr %p9310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9311, ptr %slot1556, align 8
  %v9312 = load i64, ptr %slot1556, align 8
  %cmp9313 = icmp ne i64 %v9312, 0
  %cv9314 = zext i1 %cmp9313 to i32
  store i32 %cv9314, ptr %slot1557, align 8
  %v9315 = load i32, ptr %slot1557, align 8
  %cv9316 = zext i32 %v9315 to i64
  %cond9317 = icmp ne i64 %cv9316, 0
  br i1 %cond9317, label %bb_rcgnn2463, label %bb_rcgdone2463
bb_rcgnn2463:
  %v9318 = load i64, ptr %slot1556, align 8
  %op9319 = sub i64 %v9318, 16
  store i64 %op9319, ptr %slot1558, align 8
  %v9320 = load i64, ptr %slot1556, align 8
  %p9321 = inttoptr i64 %v9320 to ptr
  %rgep9322 = getelementptr i8, ptr %p9321, i64 -16
  %ld9323 = load i64, ptr %rgep9322, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9323, ptr %slot1559, align 8
  %v9324 = load i64, ptr %slot1559, align 8
  %op9325 = and i64 %v9324, 4611686018427387906
  store i64 %op9325, ptr %slot1560, align 8
  %v9326 = load i64, ptr %slot1560, align 8
  %cmp9327 = icmp ne i64 %v9326, 0
  %cv9328 = zext i1 %cmp9327 to i32
  store i32 %cv9328, ptr %slot1561, align 8
  %v9329 = load i32, ptr %slot1561, align 8
  %cv9330 = zext i32 %v9329 to i64
  %cond9331 = icmp ne i64 %cv9330, 0
  br i1 %cond9331, label %bb_rcgclear2463, label %bb_rcgcounted2463
bb_rcgcounted2463:
  %v9332 = load i64, ptr %slot1556, align 8
  %op9333 = sub i64 %v9332, 32
  store i64 %op9333, ptr %slot1562, align 8
  %v9334 = load i64, ptr %slot1556, align 8
  %p9335 = inttoptr i64 %v9334 to ptr
  %rgep9336 = getelementptr i8, ptr %p9335, i64 -32
  %ld9337 = load i64, ptr %rgep9336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9337, ptr %slot1563, align 8
  %v9338 = load i64, ptr %slot1563, align 8
  %op9339 = sub i64 %v9338, 1
  store i64 %op9339, ptr %slot1564, align 8
  %v9340 = load i64, ptr %slot1564, align 8
  %cmp9341 = icmp eq i64 %v9340, 0
  %cv9342 = zext i1 %cmp9341 to i32
  store i32 %cv9342, ptr %slot1565, align 8
  %v9343 = load i32, ptr %slot1565, align 8
  %cv9344 = zext i32 %v9343 to i64
  %cond9345 = icmp ne i64 %cv9344, 0
  br i1 %cond9345, label %bb_rcglast2463, label %bb_rcgdec2463
bb_rcglast2463:
  %v9346 = load i64, ptr %slot1556, align 8
  %op9347 = sub i64 %v9346, 24
  store i64 %op9347, ptr %slot1566, align 8
  %v9348 = load i64, ptr %slot1556, align 8
  %p9349 = inttoptr i64 %v9348 to ptr
  %rgep9350 = getelementptr i8, ptr %p9349, i64 -24
  %ld9351 = load i64, ptr %rgep9350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9351, ptr %slot1567, align 8
  %v9352 = load i64, ptr %slot1567, align 8
  %cmp9353 = icmp ne i64 %v9352, 0
  %cv9354 = zext i1 %cmp9353 to i32
  store i32 %cv9354, ptr %slot1568, align 8
  %v9355 = load i32, ptr %slot1568, align 8
  %cv9356 = zext i32 %v9355 to i64
  %cond9357 = icmp ne i64 %cv9356, 0
  br i1 %cond9357, label %bb_rcgdec2463, label %bb_rcgslow2463
bb_rcgslow2463:
  %v9358 = load i64, ptr %slot1555, align 8
  %v9359 = load i64, ptr %slot1538, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9358, i64 %v9359) nomerge, !dbg !182
  br label %bb_rcgdone2463
bb_rcgdec2463:
  %v9360 = load i64, ptr %slot1564, align 8
  %v9361 = load i64, ptr %slot1556, align 8
  %p9362 = inttoptr i64 %v9361 to ptr
  %rgep9363 = getelementptr i8, ptr %p9362, i64 -32
  store i64 %v9360, ptr %rgep9363, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2463
bb_rcgclear2463:
  %v9364 = load i64, ptr %slot1538, align 8
  %p9365 = inttoptr i64 %v9364 to ptr
  store i64 0, ptr %p9365, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2463
bb_rcgdone2463:
  br label %bb_rcslotdone2432
bb_rcslotdone2432:
  %v9366 = load i64, ptr %slot27, align 8
  %p9367 = inttoptr i64 %v9366 to ptr
  %ld9368 = load i64, ptr %p9367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9368, ptr %slot1569, align 8
  %v9369 = load i64, ptr %slot1569, align 8
  %v9370 = load i64, ptr %slot44, align 8
  %p9371 = inttoptr i64 %v9370 to ptr
  store i64 %v9369, ptr %p9371, align 8, !alias.scope !3, !noalias !4
  %v9372 = load i64, ptr %slot44, align 8
  %p9373 = inttoptr i64 %v9372 to ptr
  %ld9374 = load i64, ptr %p9373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9374, ptr %slot1570, align 8
  %v9375 = load i64, ptr %slot63, align 8
  %p9376 = inttoptr i64 %v9375 to ptr
  %v9377 = load i64, ptr %slot1570, align 8
  %p9378 = inttoptr i64 %v9377 to ptr
  %call9379 = call ptr @myl_native_text_scalar(ptr %p9376, ptr %p9378, i32 0) nomerge, !dbg !184
  %calladdr9380 = ptrtoint ptr %call9379 to i64
  store i64 %calladdr9380, ptr %slot1571, align 8
  %v9381 = load i64, ptr %slot1571, align 8
  %cond9382 = icmp ne i64 %v9381, 0
  br i1 %cond9382, label %bb_success2470, label %bb_failed2470
bb_failed2470:
  %v9383 = load i64, ptr %slot1, align 8
  %p9384 = inttoptr i64 %v9383 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9384) nomerge, !dbg !184
  unreachable
bb_success2470:
  %v9385 = load i64, ptr %slot1571, align 8
  %v9386 = load i64, ptr %slot44, align 8
  %p9387 = inttoptr i64 %v9386 to ptr
  store i64 %v9385, ptr %p9387, align 8, !alias.scope !3, !noalias !4
  %v9388 = load i64, ptr %slot44, align 8
  %p9389 = inttoptr i64 %v9388 to ptr
  %ld9390 = load i64, ptr %p9389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9390, ptr %slot1572, align 8
  %v9391 = load i64, ptr %slot1572, align 8
  %v9392 = load i64, ptr %slot23, align 8
  %p9393 = inttoptr i64 %v9392 to ptr
  store i64 %v9391, ptr %p9393, align 8, !alias.scope !3, !noalias !4
  %v9394 = load i64, ptr %slot23, align 8
  store i64 %v9394, ptr %slot1573, align 8
  %v9395 = load i64, ptr %slot24, align 8
  store i64 %v9395, ptr %slot1574, align 8
  %v9396 = load i64, ptr %slot1573, align 8
  %v9397 = load i64, ptr %slot1574, align 8
  %p9398 = inttoptr i64 %v9396 to ptr
  %p9399 = inttoptr i64 %v9397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9399, ptr %p9398, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9400 = load i64, ptr %slot20, align 8
  %p9401 = inttoptr i64 %v9400 to ptr
  store i32 2, ptr %p9401, align 4, !alias.scope !3, !noalias !4
  %v9402 = load i64, ptr %slot19, align 8
  %p9403 = inttoptr i64 %v9402 to ptr
  store i32 1, ptr %p9403, align 4, !alias.scope !3, !noalias !4
  %v9404 = load i64, ptr %slot22, align 8
  store i64 %v9404, ptr %slot1575, align 8
  %v9405 = load i64, ptr %slot24, align 8
  store i64 %v9405, ptr %slot1576, align 8
  %v9406 = load i64, ptr %slot1576, align 8
  %v9407 = load i64, ptr %slot1575, align 8
  %p9408 = inttoptr i64 %v9406 to ptr
  %p9409 = inttoptr i64 %v9407 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9409, ptr %p9408, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9410 = load i64, ptr %slot18, align 8
  %p9411 = inttoptr i64 %v9410 to ptr
  store i32 2, ptr %p9411, align 4, !alias.scope !3, !noalias !4
  %v9412 = load i64, ptr %slot20, align 8
  %p9413 = inttoptr i64 %v9412 to ptr
  %ld9414 = load i32, ptr %p9413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9414, ptr %slot1577, align 8
  %v9415 = load i32, ptr %slot1577, align 8
  %v9416 = load i64, ptr %slot18, align 8
  %p9417 = inttoptr i64 %v9416 to ptr
  store i32 %v9415, ptr %p9417, align 4, !alias.scope !3, !noalias !4
  %v9418 = load i64, ptr %slot19, align 8
  %p9419 = inttoptr i64 %v9418 to ptr
  store i32 0, ptr %p9419, align 4, !alias.scope !3, !noalias !4
  %v9420 = load i64, ptr %slot17, align 8
  %p9421 = inttoptr i64 %v9420 to ptr
  store i32 1, ptr %p9421, align 4, !alias.scope !3, !noalias !4
  %v9422 = load i64, ptr %slot1575, align 8
  %p9423 = inttoptr i64 %v9422 to ptr
  %ld9424 = load i64, ptr %p9423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9424, ptr %slot1578, align 8
  %v9425 = load i64, ptr %slot1578, align 8
  %v9426 = load i64, ptr %slot44, align 8
  %p9427 = inttoptr i64 %v9426 to ptr
  store i64 %v9425, ptr %p9427, align 8, !alias.scope !3, !noalias !4
  %v9428 = load i64, ptr %slot40, align 8
  store i64 %v9428, ptr %slot1579, align 8
  %v9429 = load i64, ptr %slot10, align 8
  %p9430 = inttoptr i64 %v9429 to ptr
  %ld9431 = load i32, ptr %p9430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9431, ptr %slot1580, align 8
  %v9432 = load i32, ptr %slot1580, align 8
  %cmp9433 = icmp eq i32 %v9432, 16
  %cv9434 = zext i1 %cmp9433 to i32
  store i32 %cv9434, ptr %slot1581, align 8
  %v9435 = load i64, ptr %slot9, align 8
  %p9436 = inttoptr i64 %v9435 to ptr
  %ld9437 = load i32, ptr %p9436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9437, ptr %slot1582, align 8
  %v9438 = load i32, ptr %slot1582, align 8
  %v9439 = load i32, ptr %slot1581, align 8
  %op9440 = and i32 %v9438, %v9439
  store i32 %op9440, ptr %slot1583, align 8
  %v9441 = load i32, ptr %slot1583, align 8
  %cv9442 = zext i32 %v9441 to i64
  %cond9443 = icmp ne i64 %cv9442, 0
  br i1 %cond9443, label %bb_rcownlocal2491, label %bb_rcownedlocal2491
bb_rcownlocal2491:
  %v9444 = load i64, ptr %slot40, align 8
  store i64 %v9444, ptr %slot1584, align 8
  %v9445 = load i64, ptr %slot24, align 8
  store i64 %v9445, ptr %slot1585, align 8
  %v9446 = load i64, ptr %slot64, align 8
  store i64 %v9446, ptr %slot1586, align 8
  %v9447 = load i64, ptr %slot1584, align 8
  %p9448 = inttoptr i64 %v9447 to ptr
  %ld9449 = load i64, ptr %p9448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9449, ptr %slot1587, align 8
  %v9450 = load i64, ptr %slot1587, align 8
  %cmp9451 = icmp ne i64 %v9450, 0
  %cv9452 = zext i1 %cmp9451 to i32
  store i32 %cv9452, ptr %slot1588, align 8
  %v9453 = load i32, ptr %slot1588, align 8
  %cv9454 = zext i32 %v9453 to i64
  %cond9455 = icmp ne i64 %cv9454, 0
  br i1 %cond9455, label %bb_rcgnn2498, label %bb_rcgplain2498
bb_rcgnn2498:
  %v9456 = load i64, ptr %slot1587, align 8
  %op9457 = sub i64 %v9456, 16
  store i64 %op9457, ptr %slot1589, align 8
  %v9458 = load i64, ptr %slot1587, align 8
  %p9459 = inttoptr i64 %v9458 to ptr
  %rgep9460 = getelementptr i8, ptr %p9459, i64 -16
  %ld9461 = load i64, ptr %rgep9460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9461, ptr %slot1590, align 8
  %v9462 = load i64, ptr %slot1590, align 8
  %op9463 = and i64 %v9462, 4611686018427387906
  store i64 %op9463, ptr %slot1591, align 8
  %v9464 = load i64, ptr %slot1591, align 8
  %cmp9465 = icmp ne i64 %v9464, 0
  %cv9466 = zext i1 %cmp9465 to i32
  store i32 %cv9466, ptr %slot1592, align 8
  %v9467 = load i32, ptr %slot1592, align 8
  %cv9468 = zext i32 %v9467 to i64
  %cond9469 = icmp ne i64 %cv9468, 0
  br i1 %cond9469, label %bb_rcgspecial2498, label %bb_rcginc2498
bb_rcginc2498:
  %v9470 = load i64, ptr %slot1587, align 8
  %op9471 = sub i64 %v9470, 32
  store i64 %op9471, ptr %slot1593, align 8
  %v9472 = load i64, ptr %slot1587, align 8
  %p9473 = inttoptr i64 %v9472 to ptr
  %rgep9474 = getelementptr i8, ptr %p9473, i64 -32
  %ld9475 = load i64, ptr %rgep9474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9475, ptr %slot1594, align 8
  %v9476 = load i64, ptr %slot1594, align 8
  %op9477 = add i64 %v9476, 1
  store i64 %op9477, ptr %slot1595, align 8
  %v9478 = load i64, ptr %slot1595, align 8
  %cmp9479 = icmp eq i64 %v9478, 0
  %cv9480 = zext i1 %cmp9479 to i32
  store i32 %cv9480, ptr %slot1596, align 8
  %v9481 = load i32, ptr %slot1596, align 8
  %cv9482 = zext i32 %v9481 to i64
  %cond9483 = icmp ne i64 %cv9482, 0
  br i1 %cond9483, label %bb_rcglimit2498, label %bb_rcgcapacity2498
bb_rcglimit2498:
  %v9484 = load i64, ptr %slot1, align 8
  %p9485 = inttoptr i64 %v9484 to ptr
  %call9486 = call i32 @myl_qbe_rc_status(ptr %p9485, i32 2) nomerge, !dbg !186
  store i32 %call9486, ptr %slot1597, align 8
  br label %bb_failure
bb_rcgcapacity2498:
  %v9487 = load i64, ptr %slot1595, align 8
  %v9488 = load i64, ptr %slot1587, align 8
  %p9489 = inttoptr i64 %v9488 to ptr
  %rgep9490 = getelementptr i8, ptr %p9489, i64 -32
  store i64 %v9487, ptr %rgep9490, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2498
bb_rcgspecial2498:
  %v9491 = load i64, ptr %slot1590, align 8
  %op9492 = and i64 %v9491, 4611686018427387904
  store i64 %op9492, ptr %slot1598, align 8
  %v9493 = load i64, ptr %slot1598, align 8
  %cmp9494 = icmp ne i64 %v9493, 0
  %cv9495 = zext i1 %cmp9494 to i32
  store i32 %cv9495, ptr %slot1599, align 8
  %v9496 = load i32, ptr %slot1599, align 8
  %cv9497 = zext i32 %v9496 to i64
  %cond9498 = icmp ne i64 %cv9497, 0
  br i1 %cond9498, label %bb_rcgslow2498, label %bb_rcgplain2498
bb_rcgslow2498:
  %v9499 = load i64, ptr %slot63, align 8
  %v9500 = load i64, ptr %slot1585, align 8
  %v9501 = load i64, ptr %slot1584, align 8
  %v9502 = load i64, ptr %slot1586, align 8
  %cv9503 = trunc i64 %v9502 to i32
  %call9504 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v9499, i64 %v9500, i64 %v9501, i32 %cv9503) nomerge, !dbg !186
  store i32 %call9504, ptr %slot1600, align 8
  %v9505 = load i32, ptr %slot1600, align 8
  %cv9506 = zext i32 %v9505 to i64
  %cond9507 = icmp ne i64 %cv9506, 0
  br i1 %cond9507, label %bb_rcsuccess2512, label %bb_rcfailure2512
bb_rcfailure2512:
  %v9508 = load i64, ptr %slot63, align 8
  %p9509 = inttoptr i64 %v9508 to ptr
  %call9510 = call i32 @myl_rc_take_failure(ptr %p9509) nomerge, !dbg !186
  store i32 %call9510, ptr %slot1601, align 8
  %v9511 = load i64, ptr %slot1, align 8
  %p9512 = inttoptr i64 %v9511 to ptr
  %v9513 = load i32, ptr %slot1601, align 8
  %call9514 = call i32 @myl_qbe_rc_status(ptr %p9512, i32 %v9513) nomerge, !dbg !186
  store i32 %call9514, ptr %slot1602, align 8
  br label %bb_failure
bb_rcsuccess2512:
  br label %bb_rcgdone2498
bb_rcgplain2498:
  %v9515 = load i64, ptr %slot1587, align 8
  %v9516 = load i64, ptr %slot1585, align 8
  %p9517 = inttoptr i64 %v9516 to ptr
  store i64 %v9515, ptr %p9517, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2498
bb_rcgdone2498:
  %v9518 = load i64, ptr %slot20, align 8
  %p9519 = inttoptr i64 %v9518 to ptr
  store i32 2, ptr %p9519, align 4, !alias.scope !3, !noalias !4
  %v9520 = load i64, ptr %slot19, align 8
  %p9521 = inttoptr i64 %v9520 to ptr
  store i32 1, ptr %p9521, align 4, !alias.scope !3, !noalias !4
  %v9522 = load i64, ptr %slot9, align 8
  %p9523 = inttoptr i64 %v9522 to ptr
  %ld9524 = load i32, ptr %p9523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9524, ptr %slot1603, align 8
  %v9525 = load i32, ptr %slot1603, align 8
  %cv9526 = zext i32 %v9525 to i64
  %cond9527 = icmp ne i64 %cv9526, 0
  br i1 %cond9527, label %bb_rcslotdrop2519, label %bb_rcslotdone2519
bb_rcslotdrop2519:
  %v9528 = load i64, ptr %slot9, align 8
  %p9529 = inttoptr i64 %v9528 to ptr
  store i32 0, ptr %p9529, align 4, !alias.scope !3, !noalias !4
  %v9530 = load i64, ptr %slot40, align 8
  store i64 %v9530, ptr %slot1604, align 8
  %v9531 = load i64, ptr %slot10, align 8
  %p9532 = inttoptr i64 %v9531 to ptr
  %ld9533 = load i32, ptr %p9532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9533, ptr %slot1605, align 8
  %v9534 = load i32, ptr %slot1605, align 8
  %op9535 = and i32 %v9534, 28
  store i32 %op9535, ptr %slot1606, align 8
  %v9536 = load i32, ptr %slot1606, align 8
  %cv9537 = zext i32 %v9536 to i64
  %cond9538 = icmp ne i64 %cv9537, 0
  br i1 %cond9538, label %bb_rcslotrole2519, label %bb_rcslotowner2519
bb_rcslotrole2519:
  %v9539 = load i64, ptr %slot63, align 8
  store i64 %v9539, ptr %slot1607, align 8
  %v9540 = load i64, ptr %slot1604, align 8
  %p9541 = inttoptr i64 %v9540 to ptr
  %ld9542 = load i64, ptr %p9541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9542, ptr %slot1608, align 8
  %v9543 = load i64, ptr %slot1608, align 8
  %cmp9544 = icmp ne i64 %v9543, 0
  %cv9545 = zext i1 %cmp9544 to i32
  store i32 %cv9545, ptr %slot1609, align 8
  %v9546 = load i32, ptr %slot1609, align 8
  %cv9547 = zext i32 %v9546 to i64
  %cond9548 = icmp ne i64 %cv9547, 0
  br i1 %cond9548, label %bb_rcgnn2535, label %bb_rcgdone2535
bb_rcgnn2535:
  %v9549 = load i64, ptr %slot1608, align 8
  %op9550 = sub i64 %v9549, 16
  store i64 %op9550, ptr %slot1610, align 8
  %v9551 = load i64, ptr %slot1608, align 8
  %p9552 = inttoptr i64 %v9551 to ptr
  %rgep9553 = getelementptr i8, ptr %p9552, i64 -16
  %ld9554 = load i64, ptr %rgep9553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9554, ptr %slot1611, align 8
  %v9555 = load i64, ptr %slot1611, align 8
  %op9556 = and i64 %v9555, 4611686018427387906
  store i64 %op9556, ptr %slot1612, align 8
  %v9557 = load i64, ptr %slot1612, align 8
  %cmp9558 = icmp ne i64 %v9557, 0
  %cv9559 = zext i1 %cmp9558 to i32
  store i32 %cv9559, ptr %slot1613, align 8
  %v9560 = load i32, ptr %slot1613, align 8
  %cv9561 = zext i32 %v9560 to i64
  %cond9562 = icmp ne i64 %cv9561, 0
  br i1 %cond9562, label %bb_rcgclear2535, label %bb_rcgcounted2535
bb_rcgcounted2535:
  %v9563 = load i64, ptr %slot1608, align 8
  %op9564 = sub i64 %v9563, 24
  store i64 %op9564, ptr %slot1614, align 8
  %v9565 = load i64, ptr %slot1608, align 8
  %p9566 = inttoptr i64 %v9565 to ptr
  %rgep9567 = getelementptr i8, ptr %p9566, i64 -24
  %ld9568 = load i64, ptr %rgep9567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9568, ptr %slot1615, align 8
  %v9569 = load i64, ptr %slot1615, align 8
  %op9570 = sub i64 %v9569, 1
  store i64 %op9570, ptr %slot1616, align 8
  %v9571 = load i64, ptr %slot1616, align 8
  %cmp9572 = icmp eq i64 %v9571, 0
  %cv9573 = zext i1 %cmp9572 to i32
  store i32 %cv9573, ptr %slot1617, align 8
  %v9574 = load i32, ptr %slot1617, align 8
  %cv9575 = zext i32 %v9574 to i64
  %cond9576 = icmp ne i64 %cv9575, 0
  br i1 %cond9576, label %bb_rcglast2535, label %bb_rcgdec2535
bb_rcglast2535:
  %v9577 = load i64, ptr %slot1608, align 8
  %op9578 = sub i64 %v9577, 32
  store i64 %op9578, ptr %slot1618, align 8
  %v9579 = load i64, ptr %slot1608, align 8
  %p9580 = inttoptr i64 %v9579 to ptr
  %rgep9581 = getelementptr i8, ptr %p9580, i64 -32
  %ld9582 = load i64, ptr %rgep9581, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9582, ptr %slot1619, align 8
  %v9583 = load i64, ptr %slot1619, align 8
  %cmp9584 = icmp ne i64 %v9583, 0
  %cv9585 = zext i1 %cmp9584 to i32
  store i32 %cv9585, ptr %slot1620, align 8
  %v9586 = load i32, ptr %slot1620, align 8
  %cv9587 = zext i32 %v9586 to i64
  %cond9588 = icmp ne i64 %cv9587, 0
  br i1 %cond9588, label %bb_rcgdec2535, label %bb_rcgslow2535
bb_rcgslow2535:
  %v9589 = load i64, ptr %slot1607, align 8
  %v9590 = load i64, ptr %slot1604, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9589, i64 %v9590) nomerge, !dbg !186
  br label %bb_rcgdone2535
bb_rcgdec2535:
  %v9591 = load i64, ptr %slot1616, align 8
  %v9592 = load i64, ptr %slot1608, align 8
  %p9593 = inttoptr i64 %v9592 to ptr
  %rgep9594 = getelementptr i8, ptr %p9593, i64 -24
  store i64 %v9591, ptr %rgep9594, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2535
bb_rcgclear2535:
  %v9595 = load i64, ptr %slot1604, align 8
  %p9596 = inttoptr i64 %v9595 to ptr
  store i64 0, ptr %p9596, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2535
bb_rcgdone2535:
  br label %bb_rcslotdone2519
bb_rcslotowner2519:
  %v9597 = load i64, ptr %slot63, align 8
  store i64 %v9597, ptr %slot1621, align 8
  %v9598 = load i64, ptr %slot1604, align 8
  %p9599 = inttoptr i64 %v9598 to ptr
  %ld9600 = load i64, ptr %p9599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9600, ptr %slot1622, align 8
  %v9601 = load i64, ptr %slot1622, align 8
  %cmp9602 = icmp ne i64 %v9601, 0
  %cv9603 = zext i1 %cmp9602 to i32
  store i32 %cv9603, ptr %slot1623, align 8
  %v9604 = load i32, ptr %slot1623, align 8
  %cv9605 = zext i32 %v9604 to i64
  %cond9606 = icmp ne i64 %cv9605, 0
  br i1 %cond9606, label %bb_rcgnn2550, label %bb_rcgdone2550
bb_rcgnn2550:
  %v9607 = load i64, ptr %slot1622, align 8
  %op9608 = sub i64 %v9607, 16
  store i64 %op9608, ptr %slot1624, align 8
  %v9609 = load i64, ptr %slot1622, align 8
  %p9610 = inttoptr i64 %v9609 to ptr
  %rgep9611 = getelementptr i8, ptr %p9610, i64 -16
  %ld9612 = load i64, ptr %rgep9611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9612, ptr %slot1625, align 8
  %v9613 = load i64, ptr %slot1625, align 8
  %op9614 = and i64 %v9613, 4611686018427387906
  store i64 %op9614, ptr %slot1626, align 8
  %v9615 = load i64, ptr %slot1626, align 8
  %cmp9616 = icmp ne i64 %v9615, 0
  %cv9617 = zext i1 %cmp9616 to i32
  store i32 %cv9617, ptr %slot1627, align 8
  %v9618 = load i32, ptr %slot1627, align 8
  %cv9619 = zext i32 %v9618 to i64
  %cond9620 = icmp ne i64 %cv9619, 0
  br i1 %cond9620, label %bb_rcgclear2550, label %bb_rcgcounted2550
bb_rcgcounted2550:
  %v9621 = load i64, ptr %slot1622, align 8
  %op9622 = sub i64 %v9621, 32
  store i64 %op9622, ptr %slot1628, align 8
  %v9623 = load i64, ptr %slot1622, align 8
  %p9624 = inttoptr i64 %v9623 to ptr
  %rgep9625 = getelementptr i8, ptr %p9624, i64 -32
  %ld9626 = load i64, ptr %rgep9625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9626, ptr %slot1629, align 8
  %v9627 = load i64, ptr %slot1629, align 8
  %op9628 = sub i64 %v9627, 1
  store i64 %op9628, ptr %slot1630, align 8
  %v9629 = load i64, ptr %slot1630, align 8
  %cmp9630 = icmp eq i64 %v9629, 0
  %cv9631 = zext i1 %cmp9630 to i32
  store i32 %cv9631, ptr %slot1631, align 8
  %v9632 = load i32, ptr %slot1631, align 8
  %cv9633 = zext i32 %v9632 to i64
  %cond9634 = icmp ne i64 %cv9633, 0
  br i1 %cond9634, label %bb_rcglast2550, label %bb_rcgdec2550
bb_rcglast2550:
  %v9635 = load i64, ptr %slot1622, align 8
  %op9636 = sub i64 %v9635, 24
  store i64 %op9636, ptr %slot1632, align 8
  %v9637 = load i64, ptr %slot1622, align 8
  %p9638 = inttoptr i64 %v9637 to ptr
  %rgep9639 = getelementptr i8, ptr %p9638, i64 -24
  %ld9640 = load i64, ptr %rgep9639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9640, ptr %slot1633, align 8
  %v9641 = load i64, ptr %slot1633, align 8
  %cmp9642 = icmp ne i64 %v9641, 0
  %cv9643 = zext i1 %cmp9642 to i32
  store i32 %cv9643, ptr %slot1634, align 8
  %v9644 = load i32, ptr %slot1634, align 8
  %cv9645 = zext i32 %v9644 to i64
  %cond9646 = icmp ne i64 %cv9645, 0
  br i1 %cond9646, label %bb_rcgdec2550, label %bb_rcgslow2550
bb_rcgslow2550:
  %v9647 = load i64, ptr %slot1621, align 8
  %v9648 = load i64, ptr %slot1604, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9647, i64 %v9648) nomerge, !dbg !186
  br label %bb_rcgdone2550
bb_rcgdec2550:
  %v9649 = load i64, ptr %slot1630, align 8
  %v9650 = load i64, ptr %slot1622, align 8
  %p9651 = inttoptr i64 %v9650 to ptr
  %rgep9652 = getelementptr i8, ptr %p9651, i64 -32
  store i64 %v9649, ptr %rgep9652, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2550
bb_rcgclear2550:
  %v9653 = load i64, ptr %slot1604, align 8
  %p9654 = inttoptr i64 %v9653 to ptr
  store i64 0, ptr %p9654, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2550
bb_rcgdone2550:
  br label %bb_rcslotdone2519
bb_rcslotdone2519:
  %v9655 = load i64, ptr %slot24, align 8
  store i64 %v9655, ptr %slot1635, align 8
  %v9656 = load i64, ptr %slot1635, align 8
  %v9657 = load i64, ptr %slot1584, align 8
  %p9658 = inttoptr i64 %v9656 to ptr
  %p9659 = inttoptr i64 %v9657 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9659, ptr %p9658, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9660 = load i64, ptr %slot10, align 8
  %p9661 = inttoptr i64 %v9660 to ptr
  store i32 2, ptr %p9661, align 4, !alias.scope !3, !noalias !4
  %v9662 = load i64, ptr %slot9, align 8
  %p9663 = inttoptr i64 %v9662 to ptr
  store i32 1, ptr %p9663, align 4, !alias.scope !3, !noalias !4
  %v9664 = load i64, ptr %slot19, align 8
  %p9665 = inttoptr i64 %v9664 to ptr
  store i32 0, ptr %p9665, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2491
bb_rcownedlocal2491:
  %v9666 = load i64, ptr %slot10, align 8
  %p9667 = inttoptr i64 %v9666 to ptr
  store i32 2, ptr %p9667, align 4, !alias.scope !3, !noalias !4
  %v9668 = load i64, ptr %slot1579, align 8
  %p9669 = inttoptr i64 %v9668 to ptr
  %ld9670 = load i64, ptr %p9669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9670, ptr %slot1636, align 8
  %v9671 = load i64, ptr %slot1636, align 8
  %cmp9672 = icmp ne i64 %v9671, 0
  %cv9673 = zext i1 %cmp9672 to i32
  store i32 %cv9673, ptr %slot1637, align 8
  %v9674 = load i32, ptr %slot1637, align 8
  %cv9675 = zext i32 %v9674 to i64
  %cond9676 = icmp ne i64 %cv9675, 0
  br i1 %cond9676, label %bb_rcguniquenn2559, label %bb_rcgunique2559
bb_rcguniquenn2559:
  %v9677 = load i64, ptr %slot1636, align 8
  %op9678 = sub i64 %v9677, 16
  store i64 %op9678, ptr %slot1638, align 8
  %v9679 = load i64, ptr %slot1636, align 8
  %p9680 = inttoptr i64 %v9679 to ptr
  %rgep9681 = getelementptr i8, ptr %p9680, i64 -16
  %ld9682 = load i64, ptr %rgep9681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9682, ptr %slot1639, align 8
  %v9683 = load i64, ptr %slot1639, align 8
  %op9684 = and i64 %v9683, 6917529027641081858
  store i64 %op9684, ptr %slot1640, align 8
  %v9685 = load i64, ptr %slot1640, align 8
  %cmp9686 = icmp ne i64 %v9685, 0
  %cv9687 = zext i1 %cmp9686 to i32
  store i32 %cv9687, ptr %slot1641, align 8
  %v9688 = load i32, ptr %slot1641, align 8
  %cv9689 = zext i32 %v9688 to i64
  %cond9690 = icmp ne i64 %cv9689, 0
  br i1 %cond9690, label %bb_rcguniqueslow2559, label %bb_rcguniquecount2559
bb_rcguniquecount2559:
  %v9691 = load i64, ptr %slot1636, align 8
  %op9692 = sub i64 %v9691, 32
  store i64 %op9692, ptr %slot1642, align 8
  %v9693 = load i64, ptr %slot1636, align 8
  %p9694 = inttoptr i64 %v9693 to ptr
  %rgep9695 = getelementptr i8, ptr %p9694, i64 -32
  %ld9696 = load i64, ptr %rgep9695, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9696, ptr %slot1643, align 8
  %v9697 = load i64, ptr %slot1643, align 8
  %cmp9698 = icmp ult i64 %v9697, 2
  %cv9699 = zext i1 %cmp9698 to i32
  store i32 %cv9699, ptr %slot1644, align 8
  %v9700 = load i32, ptr %slot1644, align 8
  %cv9701 = zext i32 %v9700 to i64
  %cond9702 = icmp ne i64 %cv9701, 0
  br i1 %cond9702, label %bb_rcgunique2559, label %bb_rcguniqueslow2559
bb_rcguniqueslow2559:
  %v9703 = load i64, ptr %slot1, align 8
  %p9704 = inttoptr i64 %v9703 to ptr
  %p9705 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v9706 = load i64, ptr %slot1579, align 8
  %p9707 = inttoptr i64 %v9706 to ptr
  %v9708 = load i64, ptr %slot9, align 8
  %p9709 = inttoptr i64 %v9708 to ptr
  %call9710 = call i32 @myl_qbe_rc_unique_local(ptr %p9704, ptr %p9705, ptr %p9707, ptr %p9709) nomerge, !dbg !186
  store i32 %call9710, ptr %slot1645, align 8
  %v9711 = load i32, ptr %slot1645, align 8
  %cv9712 = zext i32 %v9711 to i64
  %cond9713 = icmp ne i64 %cv9712, 0
  br i1 %cond9713, label %bb_rcunique2570, label %bb_failure
bb_rcunique2570:
  br label %bb_rcgunique2559
bb_rcgunique2559:
  %v9714 = load i64, ptr %slot40, align 8
  %p9715 = inttoptr i64 %v9714 to ptr
  %ld9716 = load i64, ptr %p9715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9716, ptr %slot1646, align 8
  %v9717 = load i64, ptr %slot44, align 8
  store i64 %v9717, ptr %slot1647, align 8
  %v9718 = load i64, ptr %slot1647, align 8
  %p9719 = inttoptr i64 %v9718 to ptr
  %ld9720 = load i64, ptr %p9719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9720, ptr %slot1648, align 8
  %v9721 = load i64, ptr %slot1648, align 8
  %v9722 = load i64, ptr %slot25, align 8
  %p9723 = inttoptr i64 %v9722 to ptr
  store i64 %v9721, ptr %p9723, align 8, !alias.scope !3, !noalias !4
  %v9724 = load i64, ptr %slot25, align 8
  store i64 %v9724, ptr %slot1649, align 8
  %v9725 = load i64, ptr %slot63, align 8
  %v9726 = load i64, ptr %slot1646, align 8
  %v9727 = load i64, ptr %slot1649, align 8
  %call9728 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v9725, i64 %v9726, i64 %v9727) nomerge, !dbg !186
  store i32 %call9728, ptr %slot1650, align 8
  %v9729 = load i32, ptr %slot1650, align 8
  %cv9730 = zext i32 %v9729 to i64
  %cond9731 = icmp ne i64 %cv9730, 0
  br i1 %cond9731, label %bb_success2576, label %bb_failed2576
bb_failed2576:
  %v9732 = load i64, ptr %slot1, align 8
  %p9733 = inttoptr i64 %v9732 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9733) nomerge, !dbg !186
  unreachable
bb_success2576:
  %v9734 = load i64, ptr %slot44, align 8
  %p9735 = inttoptr i64 %v9734 to ptr
  store i64 0, ptr %p9735, align 8, !alias.scope !3, !noalias !4
  %v9736 = load i64, ptr %slot17, align 8
  %p9737 = inttoptr i64 %v9736 to ptr
  %ld9738 = load i32, ptr %p9737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9738, ptr %slot1651, align 8
  %v9739 = load i32, ptr %slot1651, align 8
  %cv9740 = zext i32 %v9739 to i64
  %cond9741 = icmp ne i64 %cv9740, 0
  br i1 %cond9741, label %bb_rcslotdrop2579, label %bb_rcslotdone2579
bb_rcslotdrop2579:
  %v9742 = load i64, ptr %slot17, align 8
  %p9743 = inttoptr i64 %v9742 to ptr
  store i32 0, ptr %p9743, align 4, !alias.scope !3, !noalias !4
  %v9744 = load i64, ptr %slot22, align 8
  store i64 %v9744, ptr %slot1652, align 8
  %v9745 = load i64, ptr %slot18, align 8
  %p9746 = inttoptr i64 %v9745 to ptr
  %ld9747 = load i32, ptr %p9746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9747, ptr %slot1653, align 8
  %v9748 = load i32, ptr %slot1653, align 8
  %op9749 = and i32 %v9748, 28
  store i32 %op9749, ptr %slot1654, align 8
  %v9750 = load i32, ptr %slot1654, align 8
  %cv9751 = zext i32 %v9750 to i64
  %cond9752 = icmp ne i64 %cv9751, 0
  br i1 %cond9752, label %bb_rcslotrole2579, label %bb_rcslotowner2579
bb_rcslotrole2579:
  %v9753 = load i64, ptr %slot63, align 8
  store i64 %v9753, ptr %slot1655, align 8
  %v9754 = load i64, ptr %slot1652, align 8
  %p9755 = inttoptr i64 %v9754 to ptr
  %ld9756 = load i64, ptr %p9755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9756, ptr %slot1656, align 8
  %v9757 = load i64, ptr %slot1656, align 8
  %cmp9758 = icmp ne i64 %v9757, 0
  %cv9759 = zext i1 %cmp9758 to i32
  store i32 %cv9759, ptr %slot1657, align 8
  %v9760 = load i32, ptr %slot1657, align 8
  %cv9761 = zext i32 %v9760 to i64
  %cond9762 = icmp ne i64 %cv9761, 0
  br i1 %cond9762, label %bb_rcgnn2595, label %bb_rcgdone2595
bb_rcgnn2595:
  %v9763 = load i64, ptr %slot1656, align 8
  %op9764 = sub i64 %v9763, 16
  store i64 %op9764, ptr %slot1658, align 8
  %v9765 = load i64, ptr %slot1656, align 8
  %p9766 = inttoptr i64 %v9765 to ptr
  %rgep9767 = getelementptr i8, ptr %p9766, i64 -16
  %ld9768 = load i64, ptr %rgep9767, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9768, ptr %slot1659, align 8
  %v9769 = load i64, ptr %slot1659, align 8
  %op9770 = and i64 %v9769, 4611686018427387906
  store i64 %op9770, ptr %slot1660, align 8
  %v9771 = load i64, ptr %slot1660, align 8
  %cmp9772 = icmp ne i64 %v9771, 0
  %cv9773 = zext i1 %cmp9772 to i32
  store i32 %cv9773, ptr %slot1661, align 8
  %v9774 = load i32, ptr %slot1661, align 8
  %cv9775 = zext i32 %v9774 to i64
  %cond9776 = icmp ne i64 %cv9775, 0
  br i1 %cond9776, label %bb_rcgclear2595, label %bb_rcgcounted2595
bb_rcgcounted2595:
  %v9777 = load i64, ptr %slot1656, align 8
  %op9778 = sub i64 %v9777, 24
  store i64 %op9778, ptr %slot1662, align 8
  %v9779 = load i64, ptr %slot1656, align 8
  %p9780 = inttoptr i64 %v9779 to ptr
  %rgep9781 = getelementptr i8, ptr %p9780, i64 -24
  %ld9782 = load i64, ptr %rgep9781, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9782, ptr %slot1663, align 8
  %v9783 = load i64, ptr %slot1663, align 8
  %op9784 = sub i64 %v9783, 1
  store i64 %op9784, ptr %slot1664, align 8
  %v9785 = load i64, ptr %slot1664, align 8
  %cmp9786 = icmp eq i64 %v9785, 0
  %cv9787 = zext i1 %cmp9786 to i32
  store i32 %cv9787, ptr %slot1665, align 8
  %v9788 = load i32, ptr %slot1665, align 8
  %cv9789 = zext i32 %v9788 to i64
  %cond9790 = icmp ne i64 %cv9789, 0
  br i1 %cond9790, label %bb_rcglast2595, label %bb_rcgdec2595
bb_rcglast2595:
  %v9791 = load i64, ptr %slot1656, align 8
  %op9792 = sub i64 %v9791, 32
  store i64 %op9792, ptr %slot1666, align 8
  %v9793 = load i64, ptr %slot1656, align 8
  %p9794 = inttoptr i64 %v9793 to ptr
  %rgep9795 = getelementptr i8, ptr %p9794, i64 -32
  %ld9796 = load i64, ptr %rgep9795, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9796, ptr %slot1667, align 8
  %v9797 = load i64, ptr %slot1667, align 8
  %cmp9798 = icmp ne i64 %v9797, 0
  %cv9799 = zext i1 %cmp9798 to i32
  store i32 %cv9799, ptr %slot1668, align 8
  %v9800 = load i32, ptr %slot1668, align 8
  %cv9801 = zext i32 %v9800 to i64
  %cond9802 = icmp ne i64 %cv9801, 0
  br i1 %cond9802, label %bb_rcgdec2595, label %bb_rcgslow2595
bb_rcgslow2595:
  %v9803 = load i64, ptr %slot1655, align 8
  %v9804 = load i64, ptr %slot1652, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9803, i64 %v9804) nomerge, !dbg !186
  br label %bb_rcgdone2595
bb_rcgdec2595:
  %v9805 = load i64, ptr %slot1664, align 8
  %v9806 = load i64, ptr %slot1656, align 8
  %p9807 = inttoptr i64 %v9806 to ptr
  %rgep9808 = getelementptr i8, ptr %p9807, i64 -24
  store i64 %v9805, ptr %rgep9808, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2595
bb_rcgclear2595:
  %v9809 = load i64, ptr %slot1652, align 8
  %p9810 = inttoptr i64 %v9809 to ptr
  store i64 0, ptr %p9810, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2595
bb_rcgdone2595:
  br label %bb_rcslotdone2579
bb_rcslotowner2579:
  %v9811 = load i64, ptr %slot63, align 8
  store i64 %v9811, ptr %slot1669, align 8
  %v9812 = load i64, ptr %slot1652, align 8
  %p9813 = inttoptr i64 %v9812 to ptr
  %ld9814 = load i64, ptr %p9813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9814, ptr %slot1670, align 8
  %v9815 = load i64, ptr %slot1670, align 8
  %cmp9816 = icmp ne i64 %v9815, 0
  %cv9817 = zext i1 %cmp9816 to i32
  store i32 %cv9817, ptr %slot1671, align 8
  %v9818 = load i32, ptr %slot1671, align 8
  %cv9819 = zext i32 %v9818 to i64
  %cond9820 = icmp ne i64 %cv9819, 0
  br i1 %cond9820, label %bb_rcgnn2610, label %bb_rcgdone2610
bb_rcgnn2610:
  %v9821 = load i64, ptr %slot1670, align 8
  %op9822 = sub i64 %v9821, 16
  store i64 %op9822, ptr %slot1672, align 8
  %v9823 = load i64, ptr %slot1670, align 8
  %p9824 = inttoptr i64 %v9823 to ptr
  %rgep9825 = getelementptr i8, ptr %p9824, i64 -16
  %ld9826 = load i64, ptr %rgep9825, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9826, ptr %slot1673, align 8
  %v9827 = load i64, ptr %slot1673, align 8
  %op9828 = and i64 %v9827, 4611686018427387906
  store i64 %op9828, ptr %slot1674, align 8
  %v9829 = load i64, ptr %slot1674, align 8
  %cmp9830 = icmp ne i64 %v9829, 0
  %cv9831 = zext i1 %cmp9830 to i32
  store i32 %cv9831, ptr %slot1675, align 8
  %v9832 = load i32, ptr %slot1675, align 8
  %cv9833 = zext i32 %v9832 to i64
  %cond9834 = icmp ne i64 %cv9833, 0
  br i1 %cond9834, label %bb_rcgclear2610, label %bb_rcgcounted2610
bb_rcgcounted2610:
  %v9835 = load i64, ptr %slot1670, align 8
  %op9836 = sub i64 %v9835, 32
  store i64 %op9836, ptr %slot1676, align 8
  %v9837 = load i64, ptr %slot1670, align 8
  %p9838 = inttoptr i64 %v9837 to ptr
  %rgep9839 = getelementptr i8, ptr %p9838, i64 -32
  %ld9840 = load i64, ptr %rgep9839, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9840, ptr %slot1677, align 8
  %v9841 = load i64, ptr %slot1677, align 8
  %op9842 = sub i64 %v9841, 1
  store i64 %op9842, ptr %slot1678, align 8
  %v9843 = load i64, ptr %slot1678, align 8
  %cmp9844 = icmp eq i64 %v9843, 0
  %cv9845 = zext i1 %cmp9844 to i32
  store i32 %cv9845, ptr %slot1679, align 8
  %v9846 = load i32, ptr %slot1679, align 8
  %cv9847 = zext i32 %v9846 to i64
  %cond9848 = icmp ne i64 %cv9847, 0
  br i1 %cond9848, label %bb_rcglast2610, label %bb_rcgdec2610
bb_rcglast2610:
  %v9849 = load i64, ptr %slot1670, align 8
  %op9850 = sub i64 %v9849, 24
  store i64 %op9850, ptr %slot1680, align 8
  %v9851 = load i64, ptr %slot1670, align 8
  %p9852 = inttoptr i64 %v9851 to ptr
  %rgep9853 = getelementptr i8, ptr %p9852, i64 -24
  %ld9854 = load i64, ptr %rgep9853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9854, ptr %slot1681, align 8
  %v9855 = load i64, ptr %slot1681, align 8
  %cmp9856 = icmp ne i64 %v9855, 0
  %cv9857 = zext i1 %cmp9856 to i32
  store i32 %cv9857, ptr %slot1682, align 8
  %v9858 = load i32, ptr %slot1682, align 8
  %cv9859 = zext i32 %v9858 to i64
  %cond9860 = icmp ne i64 %cv9859, 0
  br i1 %cond9860, label %bb_rcgdec2610, label %bb_rcgslow2610
bb_rcgslow2610:
  %v9861 = load i64, ptr %slot1669, align 8
  %v9862 = load i64, ptr %slot1652, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9861, i64 %v9862) nomerge, !dbg !186
  br label %bb_rcgdone2610
bb_rcgdec2610:
  %v9863 = load i64, ptr %slot1678, align 8
  %v9864 = load i64, ptr %slot1670, align 8
  %p9865 = inttoptr i64 %v9864 to ptr
  %rgep9866 = getelementptr i8, ptr %p9865, i64 -32
  store i64 %v9863, ptr %rgep9866, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2610
bb_rcgclear2610:
  %v9867 = load i64, ptr %slot1652, align 8
  %p9868 = inttoptr i64 %v9867 to ptr
  store i64 0, ptr %p9868, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2610
bb_rcgdone2610:
  br label %bb_rcslotdone2579
bb_rcslotdone2579:
  %p9869 = inttoptr i64 ptrtoint (ptr @myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 to i64) to ptr
  %ld9870 = load i64, ptr %p9869, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9870, ptr %slot1683, align 8
  %v9871 = load i64, ptr %slot1683, align 8
  %v9872 = load i64, ptr %slot44, align 8
  %p9873 = inttoptr i64 %v9872 to ptr
  store i64 %v9871, ptr %p9873, align 8, !alias.scope !3, !noalias !4
  %v9874 = load i64, ptr %slot44, align 8
  %p9875 = inttoptr i64 %v9874 to ptr
  %ld9876 = load i64, ptr %p9875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9876, ptr %slot1684, align 8
  %v9877 = load i64, ptr %slot1684, align 8
  %v9878 = load i64, ptr %slot23, align 8
  %p9879 = inttoptr i64 %v9878 to ptr
  store i64 %v9877, ptr %p9879, align 8, !alias.scope !3, !noalias !4
  %v9880 = load i64, ptr %slot23, align 8
  store i64 %v9880, ptr %slot1685, align 8
  %v9881 = load i64, ptr %slot24, align 8
  store i64 %v9881, ptr %slot1686, align 8
  %v9882 = load i64, ptr %slot1685, align 8
  %v9883 = load i64, ptr %slot1686, align 8
  %p9884 = inttoptr i64 %v9882 to ptr
  %p9885 = inttoptr i64 %v9883 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9885, ptr %p9884, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9886 = load i64, ptr %slot20, align 8
  %p9887 = inttoptr i64 %v9886 to ptr
  store i32 2, ptr %p9887, align 4, !alias.scope !3, !noalias !4
  %v9888 = load i64, ptr %slot19, align 8
  %p9889 = inttoptr i64 %v9888 to ptr
  store i32 1, ptr %p9889, align 4, !alias.scope !3, !noalias !4
  %v9890 = load i64, ptr %slot22, align 8
  store i64 %v9890, ptr %slot1687, align 8
  %v9891 = load i64, ptr %slot24, align 8
  store i64 %v9891, ptr %slot1688, align 8
  %v9892 = load i64, ptr %slot1688, align 8
  %v9893 = load i64, ptr %slot1687, align 8
  %p9894 = inttoptr i64 %v9892 to ptr
  %p9895 = inttoptr i64 %v9893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9895, ptr %p9894, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9896 = load i64, ptr %slot18, align 8
  %p9897 = inttoptr i64 %v9896 to ptr
  store i32 2, ptr %p9897, align 4, !alias.scope !3, !noalias !4
  %v9898 = load i64, ptr %slot20, align 8
  %p9899 = inttoptr i64 %v9898 to ptr
  %ld9900 = load i32, ptr %p9899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9900, ptr %slot1689, align 8
  %v9901 = load i32, ptr %slot1689, align 8
  %v9902 = load i64, ptr %slot18, align 8
  %p9903 = inttoptr i64 %v9902 to ptr
  store i32 %v9901, ptr %p9903, align 4, !alias.scope !3, !noalias !4
  %v9904 = load i64, ptr %slot19, align 8
  %p9905 = inttoptr i64 %v9904 to ptr
  store i32 0, ptr %p9905, align 4, !alias.scope !3, !noalias !4
  %v9906 = load i64, ptr %slot17, align 8
  %p9907 = inttoptr i64 %v9906 to ptr
  store i32 1, ptr %p9907, align 4, !alias.scope !3, !noalias !4
  %v9908 = load i64, ptr %slot1687, align 8
  %p9909 = inttoptr i64 %v9908 to ptr
  %ld9910 = load i64, ptr %p9909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9910, ptr %slot1690, align 8
  %v9911 = load i64, ptr %slot1690, align 8
  %v9912 = load i64, ptr %slot44, align 8
  %p9913 = inttoptr i64 %v9912 to ptr
  store i64 %v9911, ptr %p9913, align 8, !alias.scope !3, !noalias !4
  %v9914 = load i64, ptr %slot40, align 8
  store i64 %v9914, ptr %slot1691, align 8
  %v9915 = load i64, ptr %slot10, align 8
  %p9916 = inttoptr i64 %v9915 to ptr
  %ld9917 = load i32, ptr %p9916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9917, ptr %slot1692, align 8
  %v9918 = load i32, ptr %slot1692, align 8
  %cmp9919 = icmp eq i32 %v9918, 16
  %cv9920 = zext i1 %cmp9919 to i32
  store i32 %cv9920, ptr %slot1693, align 8
  %v9921 = load i64, ptr %slot9, align 8
  %p9922 = inttoptr i64 %v9921 to ptr
  %ld9923 = load i32, ptr %p9922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9923, ptr %slot1694, align 8
  %v9924 = load i32, ptr %slot1694, align 8
  %v9925 = load i32, ptr %slot1693, align 8
  %op9926 = and i32 %v9924, %v9925
  store i32 %op9926, ptr %slot1695, align 8
  %v9927 = load i32, ptr %slot1695, align 8
  %cv9928 = zext i32 %v9927 to i64
  %cond9929 = icmp ne i64 %cv9928, 0
  br i1 %cond9929, label %bb_rcownlocal2636, label %bb_rcownedlocal2636
bb_rcownlocal2636:
  %v9930 = load i64, ptr %slot40, align 8
  store i64 %v9930, ptr %slot1696, align 8
  %v9931 = load i64, ptr %slot24, align 8
  store i64 %v9931, ptr %slot1697, align 8
  %v9932 = load i64, ptr %slot64, align 8
  store i64 %v9932, ptr %slot1698, align 8
  %v9933 = load i64, ptr %slot1696, align 8
  %p9934 = inttoptr i64 %v9933 to ptr
  %ld9935 = load i64, ptr %p9934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9935, ptr %slot1699, align 8
  %v9936 = load i64, ptr %slot1699, align 8
  %cmp9937 = icmp ne i64 %v9936, 0
  %cv9938 = zext i1 %cmp9937 to i32
  store i32 %cv9938, ptr %slot1700, align 8
  %v9939 = load i32, ptr %slot1700, align 8
  %cv9940 = zext i32 %v9939 to i64
  %cond9941 = icmp ne i64 %cv9940, 0
  br i1 %cond9941, label %bb_rcgnn2643, label %bb_rcgplain2643
bb_rcgnn2643:
  %v9942 = load i64, ptr %slot1699, align 8
  %op9943 = sub i64 %v9942, 16
  store i64 %op9943, ptr %slot1701, align 8
  %v9944 = load i64, ptr %slot1699, align 8
  %p9945 = inttoptr i64 %v9944 to ptr
  %rgep9946 = getelementptr i8, ptr %p9945, i64 -16
  %ld9947 = load i64, ptr %rgep9946, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9947, ptr %slot1702, align 8
  %v9948 = load i64, ptr %slot1702, align 8
  %op9949 = and i64 %v9948, 4611686018427387906
  store i64 %op9949, ptr %slot1703, align 8
  %v9950 = load i64, ptr %slot1703, align 8
  %cmp9951 = icmp ne i64 %v9950, 0
  %cv9952 = zext i1 %cmp9951 to i32
  store i32 %cv9952, ptr %slot1704, align 8
  %v9953 = load i32, ptr %slot1704, align 8
  %cv9954 = zext i32 %v9953 to i64
  %cond9955 = icmp ne i64 %cv9954, 0
  br i1 %cond9955, label %bb_rcgspecial2643, label %bb_rcginc2643
bb_rcginc2643:
  %v9956 = load i64, ptr %slot1699, align 8
  %op9957 = sub i64 %v9956, 32
  store i64 %op9957, ptr %slot1705, align 8
  %v9958 = load i64, ptr %slot1699, align 8
  %p9959 = inttoptr i64 %v9958 to ptr
  %rgep9960 = getelementptr i8, ptr %p9959, i64 -32
  %ld9961 = load i64, ptr %rgep9960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9961, ptr %slot1706, align 8
  %v9962 = load i64, ptr %slot1706, align 8
  %op9963 = add i64 %v9962, 1
  store i64 %op9963, ptr %slot1707, align 8
  %v9964 = load i64, ptr %slot1707, align 8
  %cmp9965 = icmp eq i64 %v9964, 0
  %cv9966 = zext i1 %cmp9965 to i32
  store i32 %cv9966, ptr %slot1708, align 8
  %v9967 = load i32, ptr %slot1708, align 8
  %cv9968 = zext i32 %v9967 to i64
  %cond9969 = icmp ne i64 %cv9968, 0
  br i1 %cond9969, label %bb_rcglimit2643, label %bb_rcgcapacity2643
bb_rcglimit2643:
  %v9970 = load i64, ptr %slot1, align 8
  %p9971 = inttoptr i64 %v9970 to ptr
  %call9972 = call i32 @myl_qbe_rc_status(ptr %p9971, i32 2) nomerge, !dbg !188
  store i32 %call9972, ptr %slot1709, align 8
  br label %bb_failure
bb_rcgcapacity2643:
  %v9973 = load i64, ptr %slot1707, align 8
  %v9974 = load i64, ptr %slot1699, align 8
  %p9975 = inttoptr i64 %v9974 to ptr
  %rgep9976 = getelementptr i8, ptr %p9975, i64 -32
  store i64 %v9973, ptr %rgep9976, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2643
bb_rcgspecial2643:
  %v9977 = load i64, ptr %slot1702, align 8
  %op9978 = and i64 %v9977, 4611686018427387904
  store i64 %op9978, ptr %slot1710, align 8
  %v9979 = load i64, ptr %slot1710, align 8
  %cmp9980 = icmp ne i64 %v9979, 0
  %cv9981 = zext i1 %cmp9980 to i32
  store i32 %cv9981, ptr %slot1711, align 8
  %v9982 = load i32, ptr %slot1711, align 8
  %cv9983 = zext i32 %v9982 to i64
  %cond9984 = icmp ne i64 %cv9983, 0
  br i1 %cond9984, label %bb_rcgslow2643, label %bb_rcgplain2643
bb_rcgslow2643:
  %v9985 = load i64, ptr %slot63, align 8
  %v9986 = load i64, ptr %slot1697, align 8
  %v9987 = load i64, ptr %slot1696, align 8
  %v9988 = load i64, ptr %slot1698, align 8
  %cv9989 = trunc i64 %v9988 to i32
  %call9990 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v9985, i64 %v9986, i64 %v9987, i32 %cv9989) nomerge, !dbg !188
  store i32 %call9990, ptr %slot1712, align 8
  %v9991 = load i32, ptr %slot1712, align 8
  %cv9992 = zext i32 %v9991 to i64
  %cond9993 = icmp ne i64 %cv9992, 0
  br i1 %cond9993, label %bb_rcsuccess2657, label %bb_rcfailure2657
bb_rcfailure2657:
  %v9994 = load i64, ptr %slot63, align 8
  %p9995 = inttoptr i64 %v9994 to ptr
  %call9996 = call i32 @myl_rc_take_failure(ptr %p9995) nomerge, !dbg !188
  store i32 %call9996, ptr %slot1713, align 8
  %v9997 = load i64, ptr %slot1, align 8
  %p9998 = inttoptr i64 %v9997 to ptr
  %v9999 = load i32, ptr %slot1713, align 8
  %call10000 = call i32 @myl_qbe_rc_status(ptr %p9998, i32 %v9999) nomerge, !dbg !188
  store i32 %call10000, ptr %slot1714, align 8
  br label %bb_failure
bb_rcsuccess2657:
  br label %bb_rcgdone2643
bb_rcgplain2643:
  %v10001 = load i64, ptr %slot1699, align 8
  %v10002 = load i64, ptr %slot1697, align 8
  %p10003 = inttoptr i64 %v10002 to ptr
  store i64 %v10001, ptr %p10003, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2643
bb_rcgdone2643:
  %v10004 = load i64, ptr %slot20, align 8
  %p10005 = inttoptr i64 %v10004 to ptr
  store i32 2, ptr %p10005, align 4, !alias.scope !3, !noalias !4
  %v10006 = load i64, ptr %slot19, align 8
  %p10007 = inttoptr i64 %v10006 to ptr
  store i32 1, ptr %p10007, align 4, !alias.scope !3, !noalias !4
  %v10008 = load i64, ptr %slot9, align 8
  %p10009 = inttoptr i64 %v10008 to ptr
  %ld10010 = load i32, ptr %p10009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10010, ptr %slot1715, align 8
  %v10011 = load i32, ptr %slot1715, align 8
  %cv10012 = zext i32 %v10011 to i64
  %cond10013 = icmp ne i64 %cv10012, 0
  br i1 %cond10013, label %bb_rcslotdrop2664, label %bb_rcslotdone2664
bb_rcslotdrop2664:
  %v10014 = load i64, ptr %slot9, align 8
  %p10015 = inttoptr i64 %v10014 to ptr
  store i32 0, ptr %p10015, align 4, !alias.scope !3, !noalias !4
  %v10016 = load i64, ptr %slot40, align 8
  store i64 %v10016, ptr %slot1716, align 8
  %v10017 = load i64, ptr %slot10, align 8
  %p10018 = inttoptr i64 %v10017 to ptr
  %ld10019 = load i32, ptr %p10018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10019, ptr %slot1717, align 8
  %v10020 = load i32, ptr %slot1717, align 8
  %op10021 = and i32 %v10020, 28
  store i32 %op10021, ptr %slot1718, align 8
  %v10022 = load i32, ptr %slot1718, align 8
  %cv10023 = zext i32 %v10022 to i64
  %cond10024 = icmp ne i64 %cv10023, 0
  br i1 %cond10024, label %bb_rcslotrole2664, label %bb_rcslotowner2664
bb_rcslotrole2664:
  %v10025 = load i64, ptr %slot63, align 8
  store i64 %v10025, ptr %slot1719, align 8
  %v10026 = load i64, ptr %slot1716, align 8
  %p10027 = inttoptr i64 %v10026 to ptr
  %ld10028 = load i64, ptr %p10027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10028, ptr %slot1720, align 8
  %v10029 = load i64, ptr %slot1720, align 8
  %cmp10030 = icmp ne i64 %v10029, 0
  %cv10031 = zext i1 %cmp10030 to i32
  store i32 %cv10031, ptr %slot1721, align 8
  %v10032 = load i32, ptr %slot1721, align 8
  %cv10033 = zext i32 %v10032 to i64
  %cond10034 = icmp ne i64 %cv10033, 0
  br i1 %cond10034, label %bb_rcgnn2680, label %bb_rcgdone2680
bb_rcgnn2680:
  %v10035 = load i64, ptr %slot1720, align 8
  %op10036 = sub i64 %v10035, 16
  store i64 %op10036, ptr %slot1722, align 8
  %v10037 = load i64, ptr %slot1720, align 8
  %p10038 = inttoptr i64 %v10037 to ptr
  %rgep10039 = getelementptr i8, ptr %p10038, i64 -16
  %ld10040 = load i64, ptr %rgep10039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10040, ptr %slot1723, align 8
  %v10041 = load i64, ptr %slot1723, align 8
  %op10042 = and i64 %v10041, 4611686018427387906
  store i64 %op10042, ptr %slot1724, align 8
  %v10043 = load i64, ptr %slot1724, align 8
  %cmp10044 = icmp ne i64 %v10043, 0
  %cv10045 = zext i1 %cmp10044 to i32
  store i32 %cv10045, ptr %slot1725, align 8
  %v10046 = load i32, ptr %slot1725, align 8
  %cv10047 = zext i32 %v10046 to i64
  %cond10048 = icmp ne i64 %cv10047, 0
  br i1 %cond10048, label %bb_rcgclear2680, label %bb_rcgcounted2680
bb_rcgcounted2680:
  %v10049 = load i64, ptr %slot1720, align 8
  %op10050 = sub i64 %v10049, 24
  store i64 %op10050, ptr %slot1726, align 8
  %v10051 = load i64, ptr %slot1720, align 8
  %p10052 = inttoptr i64 %v10051 to ptr
  %rgep10053 = getelementptr i8, ptr %p10052, i64 -24
  %ld10054 = load i64, ptr %rgep10053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10054, ptr %slot1727, align 8
  %v10055 = load i64, ptr %slot1727, align 8
  %op10056 = sub i64 %v10055, 1
  store i64 %op10056, ptr %slot1728, align 8
  %v10057 = load i64, ptr %slot1728, align 8
  %cmp10058 = icmp eq i64 %v10057, 0
  %cv10059 = zext i1 %cmp10058 to i32
  store i32 %cv10059, ptr %slot1729, align 8
  %v10060 = load i32, ptr %slot1729, align 8
  %cv10061 = zext i32 %v10060 to i64
  %cond10062 = icmp ne i64 %cv10061, 0
  br i1 %cond10062, label %bb_rcglast2680, label %bb_rcgdec2680
bb_rcglast2680:
  %v10063 = load i64, ptr %slot1720, align 8
  %op10064 = sub i64 %v10063, 32
  store i64 %op10064, ptr %slot1730, align 8
  %v10065 = load i64, ptr %slot1720, align 8
  %p10066 = inttoptr i64 %v10065 to ptr
  %rgep10067 = getelementptr i8, ptr %p10066, i64 -32
  %ld10068 = load i64, ptr %rgep10067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10068, ptr %slot1731, align 8
  %v10069 = load i64, ptr %slot1731, align 8
  %cmp10070 = icmp ne i64 %v10069, 0
  %cv10071 = zext i1 %cmp10070 to i32
  store i32 %cv10071, ptr %slot1732, align 8
  %v10072 = load i32, ptr %slot1732, align 8
  %cv10073 = zext i32 %v10072 to i64
  %cond10074 = icmp ne i64 %cv10073, 0
  br i1 %cond10074, label %bb_rcgdec2680, label %bb_rcgslow2680
bb_rcgslow2680:
  %v10075 = load i64, ptr %slot1719, align 8
  %v10076 = load i64, ptr %slot1716, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v10075, i64 %v10076) nomerge, !dbg !188
  br label %bb_rcgdone2680
bb_rcgdec2680:
  %v10077 = load i64, ptr %slot1728, align 8
  %v10078 = load i64, ptr %slot1720, align 8
  %p10079 = inttoptr i64 %v10078 to ptr
  %rgep10080 = getelementptr i8, ptr %p10079, i64 -24
  store i64 %v10077, ptr %rgep10080, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2680
bb_rcgclear2680:
  %v10081 = load i64, ptr %slot1716, align 8
  %p10082 = inttoptr i64 %v10081 to ptr
  store i64 0, ptr %p10082, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2680
bb_rcgdone2680:
  br label %bb_rcslotdone2664
bb_rcslotowner2664:
  %v10083 = load i64, ptr %slot63, align 8
  store i64 %v10083, ptr %slot1733, align 8
  %v10084 = load i64, ptr %slot1716, align 8
  %p10085 = inttoptr i64 %v10084 to ptr
  %ld10086 = load i64, ptr %p10085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10086, ptr %slot1734, align 8
  %v10087 = load i64, ptr %slot1734, align 8
  %cmp10088 = icmp ne i64 %v10087, 0
  %cv10089 = zext i1 %cmp10088 to i32
  store i32 %cv10089, ptr %slot1735, align 8
  %v10090 = load i32, ptr %slot1735, align 8
  %cv10091 = zext i32 %v10090 to i64
  %cond10092 = icmp ne i64 %cv10091, 0
  br i1 %cond10092, label %bb_rcgnn2695, label %bb_rcgdone2695
bb_rcgnn2695:
  %v10093 = load i64, ptr %slot1734, align 8
  %op10094 = sub i64 %v10093, 16
  store i64 %op10094, ptr %slot1736, align 8
  %v10095 = load i64, ptr %slot1734, align 8
  %p10096 = inttoptr i64 %v10095 to ptr
  %rgep10097 = getelementptr i8, ptr %p10096, i64 -16
  %ld10098 = load i64, ptr %rgep10097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10098, ptr %slot1737, align 8
  %v10099 = load i64, ptr %slot1737, align 8
  %op10100 = and i64 %v10099, 4611686018427387906
  store i64 %op10100, ptr %slot1738, align 8
  %v10101 = load i64, ptr %slot1738, align 8
  %cmp10102 = icmp ne i64 %v10101, 0
  %cv10103 = zext i1 %cmp10102 to i32
  store i32 %cv10103, ptr %slot1739, align 8
  %v10104 = load i32, ptr %slot1739, align 8
  %cv10105 = zext i32 %v10104 to i64
  %cond10106 = icmp ne i64 %cv10105, 0
  br i1 %cond10106, label %bb_rcgclear2695, label %bb_rcgcounted2695
bb_rcgcounted2695:
  %v10107 = load i64, ptr %slot1734, align 8
  %op10108 = sub i64 %v10107, 32
  store i64 %op10108, ptr %slot1740, align 8
  %v10109 = load i64, ptr %slot1734, align 8
  %p10110 = inttoptr i64 %v10109 to ptr
  %rgep10111 = getelementptr i8, ptr %p10110, i64 -32
  %ld10112 = load i64, ptr %rgep10111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10112, ptr %slot1741, align 8
  %v10113 = load i64, ptr %slot1741, align 8
  %op10114 = sub i64 %v10113, 1
  store i64 %op10114, ptr %slot1742, align 8
  %v10115 = load i64, ptr %slot1742, align 8
  %cmp10116 = icmp eq i64 %v10115, 0
  %cv10117 = zext i1 %cmp10116 to i32
  store i32 %cv10117, ptr %slot1743, align 8
  %v10118 = load i32, ptr %slot1743, align 8
  %cv10119 = zext i32 %v10118 to i64
  %cond10120 = icmp ne i64 %cv10119, 0
  br i1 %cond10120, label %bb_rcglast2695, label %bb_rcgdec2695
bb_rcglast2695:
  %v10121 = load i64, ptr %slot1734, align 8
  %op10122 = sub i64 %v10121, 24
  store i64 %op10122, ptr %slot1744, align 8
  %v10123 = load i64, ptr %slot1734, align 8
  %p10124 = inttoptr i64 %v10123 to ptr
  %rgep10125 = getelementptr i8, ptr %p10124, i64 -24
  %ld10126 = load i64, ptr %rgep10125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10126, ptr %slot1745, align 8
  %v10127 = load i64, ptr %slot1745, align 8
  %cmp10128 = icmp ne i64 %v10127, 0
  %cv10129 = zext i1 %cmp10128 to i32
  store i32 %cv10129, ptr %slot1746, align 8
  %v10130 = load i32, ptr %slot1746, align 8
  %cv10131 = zext i32 %v10130 to i64
  %cond10132 = icmp ne i64 %cv10131, 0
  br i1 %cond10132, label %bb_rcgdec2695, label %bb_rcgslow2695
bb_rcgslow2695:
  %v10133 = load i64, ptr %slot1733, align 8
  %v10134 = load i64, ptr %slot1716, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v10133, i64 %v10134) nomerge, !dbg !188
  br label %bb_rcgdone2695
bb_rcgdec2695:
  %v10135 = load i64, ptr %slot1742, align 8
  %v10136 = load i64, ptr %slot1734, align 8
  %p10137 = inttoptr i64 %v10136 to ptr
  %rgep10138 = getelementptr i8, ptr %p10137, i64 -32
  store i64 %v10135, ptr %rgep10138, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2695
bb_rcgclear2695:
  %v10139 = load i64, ptr %slot1716, align 8
  %p10140 = inttoptr i64 %v10139 to ptr
  store i64 0, ptr %p10140, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2695
bb_rcgdone2695:
  br label %bb_rcslotdone2664
bb_rcslotdone2664:
  %v10141 = load i64, ptr %slot24, align 8
  store i64 %v10141, ptr %slot1747, align 8
  %v10142 = load i64, ptr %slot1747, align 8
  %v10143 = load i64, ptr %slot1696, align 8
  %p10144 = inttoptr i64 %v10142 to ptr
  %p10145 = inttoptr i64 %v10143 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10145, ptr %p10144, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10146 = load i64, ptr %slot10, align 8
  %p10147 = inttoptr i64 %v10146 to ptr
  store i32 2, ptr %p10147, align 4, !alias.scope !3, !noalias !4
  %v10148 = load i64, ptr %slot9, align 8
  %p10149 = inttoptr i64 %v10148 to ptr
  store i32 1, ptr %p10149, align 4, !alias.scope !3, !noalias !4
  %v10150 = load i64, ptr %slot19, align 8
  %p10151 = inttoptr i64 %v10150 to ptr
  store i32 0, ptr %p10151, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2636
bb_rcownedlocal2636:
  %v10152 = load i64, ptr %slot10, align 8
  %p10153 = inttoptr i64 %v10152 to ptr
  store i32 2, ptr %p10153, align 4, !alias.scope !3, !noalias !4
  %v10154 = load i64, ptr %slot1691, align 8
  %p10155 = inttoptr i64 %v10154 to ptr
  %ld10156 = load i64, ptr %p10155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10156, ptr %slot1748, align 8
  %v10157 = load i64, ptr %slot1748, align 8
  %cmp10158 = icmp ne i64 %v10157, 0
  %cv10159 = zext i1 %cmp10158 to i32
  store i32 %cv10159, ptr %slot1749, align 8
  %v10160 = load i32, ptr %slot1749, align 8
  %cv10161 = zext i32 %v10160 to i64
  %cond10162 = icmp ne i64 %cv10161, 0
  br i1 %cond10162, label %bb_rcguniquenn2704, label %bb_rcgunique2704
bb_rcguniquenn2704:
  %v10163 = load i64, ptr %slot1748, align 8
  %op10164 = sub i64 %v10163, 16
  store i64 %op10164, ptr %slot1750, align 8
  %v10165 = load i64, ptr %slot1748, align 8
  %p10166 = inttoptr i64 %v10165 to ptr
  %rgep10167 = getelementptr i8, ptr %p10166, i64 -16
  %ld10168 = load i64, ptr %rgep10167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10168, ptr %slot1751, align 8
  %v10169 = load i64, ptr %slot1751, align 8
  %op10170 = and i64 %v10169, 6917529027641081858
  store i64 %op10170, ptr %slot1752, align 8
  %v10171 = load i64, ptr %slot1752, align 8
  %cmp10172 = icmp ne i64 %v10171, 0
  %cv10173 = zext i1 %cmp10172 to i32
  store i32 %cv10173, ptr %slot1753, align 8
  %v10174 = load i32, ptr %slot1753, align 8
  %cv10175 = zext i32 %v10174 to i64
  %cond10176 = icmp ne i64 %cv10175, 0
  br i1 %cond10176, label %bb_rcguniqueslow2704, label %bb_rcguniquecount2704
bb_rcguniquecount2704:
  %v10177 = load i64, ptr %slot1748, align 8
  %op10178 = sub i64 %v10177, 32
  store i64 %op10178, ptr %slot1754, align 8
  %v10179 = load i64, ptr %slot1748, align 8
  %p10180 = inttoptr i64 %v10179 to ptr
  %rgep10181 = getelementptr i8, ptr %p10180, i64 -32
  %ld10182 = load i64, ptr %rgep10181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10182, ptr %slot1755, align 8
  %v10183 = load i64, ptr %slot1755, align 8
  %cmp10184 = icmp ult i64 %v10183, 2
  %cv10185 = zext i1 %cmp10184 to i32
  store i32 %cv10185, ptr %slot1756, align 8
  %v10186 = load i32, ptr %slot1756, align 8
  %cv10187 = zext i32 %v10186 to i64
  %cond10188 = icmp ne i64 %cv10187, 0
  br i1 %cond10188, label %bb_rcgunique2704, label %bb_rcguniqueslow2704
bb_rcguniqueslow2704:
  %v10189 = load i64, ptr %slot1, align 8
  %p10190 = inttoptr i64 %v10189 to ptr
  %p10191 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v10192 = load i64, ptr %slot1691, align 8
  %p10193 = inttoptr i64 %v10192 to ptr
  %v10194 = load i64, ptr %slot9, align 8
  %p10195 = inttoptr i64 %v10194 to ptr
  %call10196 = call i32 @myl_qbe_rc_unique_local(ptr %p10190, ptr %p10191, ptr %p10193, ptr %p10195) nomerge, !dbg !188
  store i32 %call10196, ptr %slot1757, align 8
  %v10197 = load i32, ptr %slot1757, align 8
  %cv10198 = zext i32 %v10197 to i64
  %cond10199 = icmp ne i64 %cv10198, 0
  br i1 %cond10199, label %bb_rcunique2715, label %bb_failure
bb_rcunique2715:
  br label %bb_rcgunique2704
bb_rcgunique2704:
  %v10200 = load i64, ptr %slot40, align 8
  %p10201 = inttoptr i64 %v10200 to ptr
  %ld10202 = load i64, ptr %p10201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10202, ptr %slot1758, align 8
  %v10203 = load i64, ptr %slot44, align 8
  store i64 %v10203, ptr %slot1759, align 8
  %v10204 = load i64, ptr %slot1759, align 8
  %p10205 = inttoptr i64 %v10204 to ptr
  %ld10206 = load i64, ptr %p10205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10206, ptr %slot1760, align 8
  %v10207 = load i64, ptr %slot1760, align 8
  %v10208 = load i64, ptr %slot25, align 8
  %p10209 = inttoptr i64 %v10208 to ptr
  store i64 %v10207, ptr %p10209, align 8, !alias.scope !3, !noalias !4
  %v10210 = load i64, ptr %slot25, align 8
  store i64 %v10210, ptr %slot1761, align 8
  %v10211 = load i64, ptr %slot63, align 8
  %v10212 = load i64, ptr %slot1758, align 8
  %v10213 = load i64, ptr %slot1761, align 8
  %call10214 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v10211, i64 %v10212, i64 %v10213) nomerge, !dbg !188
  store i32 %call10214, ptr %slot1762, align 8
  %v10215 = load i32, ptr %slot1762, align 8
  %cv10216 = zext i32 %v10215 to i64
  %cond10217 = icmp ne i64 %cv10216, 0
  br i1 %cond10217, label %bb_success2721, label %bb_failed2721
bb_failed2721:
  %v10218 = load i64, ptr %slot1, align 8
  %p10219 = inttoptr i64 %v10218 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10219) nomerge, !dbg !188
  unreachable
bb_success2721:
  %v10220 = load i64, ptr %slot44, align 8
  %p10221 = inttoptr i64 %v10220 to ptr
  store i64 0, ptr %p10221, align 8, !alias.scope !3, !noalias !4
  %v10222 = load i64, ptr %slot17, align 8
  %p10223 = inttoptr i64 %v10222 to ptr
  %ld10224 = load i32, ptr %p10223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10224, ptr %slot1763, align 8
  %v10225 = load i32, ptr %slot1763, align 8
  %cv10226 = zext i32 %v10225 to i64
  %cond10227 = icmp ne i64 %cv10226, 0
  br i1 %cond10227, label %bb_rcslotdrop2724, label %bb_rcslotdone2724
bb_rcslotdrop2724:
  %v10228 = load i64, ptr %slot17, align 8
  %p10229 = inttoptr i64 %v10228 to ptr
  store i32 0, ptr %p10229, align 4, !alias.scope !3, !noalias !4
  %v10230 = load i64, ptr %slot22, align 8
  store i64 %v10230, ptr %slot1764, align 8
  %v10231 = load i64, ptr %slot18, align 8
  %p10232 = inttoptr i64 %v10231 to ptr
  %ld10233 = load i32, ptr %p10232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10233, ptr %slot1765, align 8
  %v10234 = load i32, ptr %slot1765, align 8
  %op10235 = and i32 %v10234, 28
  store i32 %op10235, ptr %slot1766, align 8
  %v10236 = load i32, ptr %slot1766, align 8
  %cv10237 = zext i32 %v10236 to i64
  %cond10238 = icmp ne i64 %cv10237, 0
  br i1 %cond10238, label %bb_rcslotrole2724, label %bb_rcslotowner2724
bb_rcslotrole2724:
  %v10239 = load i64, ptr %slot63, align 8
  store i64 %v10239, ptr %slot1767, align 8
  %v10240 = load i64, ptr %slot1764, align 8
  %p10241 = inttoptr i64 %v10240 to ptr
  %ld10242 = load i64, ptr %p10241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10242, ptr %slot1768, align 8
  %v10243 = load i64, ptr %slot1768, align 8
  %cmp10244 = icmp ne i64 %v10243, 0
  %cv10245 = zext i1 %cmp10244 to i32
  store i32 %cv10245, ptr %slot1769, align 8
  %v10246 = load i32, ptr %slot1769, align 8
  %cv10247 = zext i32 %v10246 to i64
  %cond10248 = icmp ne i64 %cv10247, 0
  br i1 %cond10248, label %bb_rcgnn2740, label %bb_rcgdone2740
bb_rcgnn2740:
  %v10249 = load i64, ptr %slot1768, align 8
  %op10250 = sub i64 %v10249, 16
  store i64 %op10250, ptr %slot1770, align 8
  %v10251 = load i64, ptr %slot1768, align 8
  %p10252 = inttoptr i64 %v10251 to ptr
  %rgep10253 = getelementptr i8, ptr %p10252, i64 -16
  %ld10254 = load i64, ptr %rgep10253, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10254, ptr %slot1771, align 8
  %v10255 = load i64, ptr %slot1771, align 8
  %op10256 = and i64 %v10255, 4611686018427387906
  store i64 %op10256, ptr %slot1772, align 8
  %v10257 = load i64, ptr %slot1772, align 8
  %cmp10258 = icmp ne i64 %v10257, 0
  %cv10259 = zext i1 %cmp10258 to i32
  store i32 %cv10259, ptr %slot1773, align 8
  %v10260 = load i32, ptr %slot1773, align 8
  %cv10261 = zext i32 %v10260 to i64
  %cond10262 = icmp ne i64 %cv10261, 0
  br i1 %cond10262, label %bb_rcgclear2740, label %bb_rcgcounted2740
bb_rcgcounted2740:
  %v10263 = load i64, ptr %slot1768, align 8
  %op10264 = sub i64 %v10263, 24
  store i64 %op10264, ptr %slot1774, align 8
  %v10265 = load i64, ptr %slot1768, align 8
  %p10266 = inttoptr i64 %v10265 to ptr
  %rgep10267 = getelementptr i8, ptr %p10266, i64 -24
  %ld10268 = load i64, ptr %rgep10267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10268, ptr %slot1775, align 8
  %v10269 = load i64, ptr %slot1775, align 8
  %op10270 = sub i64 %v10269, 1
  store i64 %op10270, ptr %slot1776, align 8
  %v10271 = load i64, ptr %slot1776, align 8
  %cmp10272 = icmp eq i64 %v10271, 0
  %cv10273 = zext i1 %cmp10272 to i32
  store i32 %cv10273, ptr %slot1777, align 8
  %v10274 = load i32, ptr %slot1777, align 8
  %cv10275 = zext i32 %v10274 to i64
  %cond10276 = icmp ne i64 %cv10275, 0
  br i1 %cond10276, label %bb_rcglast2740, label %bb_rcgdec2740
bb_rcglast2740:
  %v10277 = load i64, ptr %slot1768, align 8
  %op10278 = sub i64 %v10277, 32
  store i64 %op10278, ptr %slot1778, align 8
  %v10279 = load i64, ptr %slot1768, align 8
  %p10280 = inttoptr i64 %v10279 to ptr
  %rgep10281 = getelementptr i8, ptr %p10280, i64 -32
  %ld10282 = load i64, ptr %rgep10281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10282, ptr %slot1779, align 8
  %v10283 = load i64, ptr %slot1779, align 8
  %cmp10284 = icmp ne i64 %v10283, 0
  %cv10285 = zext i1 %cmp10284 to i32
  store i32 %cv10285, ptr %slot1780, align 8
  %v10286 = load i32, ptr %slot1780, align 8
  %cv10287 = zext i32 %v10286 to i64
  %cond10288 = icmp ne i64 %cv10287, 0
  br i1 %cond10288, label %bb_rcgdec2740, label %bb_rcgslow2740
bb_rcgslow2740:
  %v10289 = load i64, ptr %slot1767, align 8
  %v10290 = load i64, ptr %slot1764, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v10289, i64 %v10290) nomerge, !dbg !188
  br label %bb_rcgdone2740
bb_rcgdec2740:
  %v10291 = load i64, ptr %slot1776, align 8
  %v10292 = load i64, ptr %slot1768, align 8
  %p10293 = inttoptr i64 %v10292 to ptr
  %rgep10294 = getelementptr i8, ptr %p10293, i64 -24
  store i64 %v10291, ptr %rgep10294, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2740
bb_rcgclear2740:
  %v10295 = load i64, ptr %slot1764, align 8
  %p10296 = inttoptr i64 %v10295 to ptr
  store i64 0, ptr %p10296, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2740
bb_rcgdone2740:
  br label %bb_rcslotdone2724
bb_rcslotowner2724:
  %v10297 = load i64, ptr %slot63, align 8
  store i64 %v10297, ptr %slot1781, align 8
  %v10298 = load i64, ptr %slot1764, align 8
  %p10299 = inttoptr i64 %v10298 to ptr
  %ld10300 = load i64, ptr %p10299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10300, ptr %slot1782, align 8
  %v10301 = load i64, ptr %slot1782, align 8
  %cmp10302 = icmp ne i64 %v10301, 0
  %cv10303 = zext i1 %cmp10302 to i32
  store i32 %cv10303, ptr %slot1783, align 8
  %v10304 = load i32, ptr %slot1783, align 8
  %cv10305 = zext i32 %v10304 to i64
  %cond10306 = icmp ne i64 %cv10305, 0
  br i1 %cond10306, label %bb_rcgnn2755, label %bb_rcgdone2755
bb_rcgnn2755:
  %v10307 = load i64, ptr %slot1782, align 8
  %op10308 = sub i64 %v10307, 16
  store i64 %op10308, ptr %slot1784, align 8
  %v10309 = load i64, ptr %slot1782, align 8
  %p10310 = inttoptr i64 %v10309 to ptr
  %rgep10311 = getelementptr i8, ptr %p10310, i64 -16
  %ld10312 = load i64, ptr %rgep10311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10312, ptr %slot1785, align 8
  %v10313 = load i64, ptr %slot1785, align 8
  %op10314 = and i64 %v10313, 4611686018427387906
  store i64 %op10314, ptr %slot1786, align 8
  %v10315 = load i64, ptr %slot1786, align 8
  %cmp10316 = icmp ne i64 %v10315, 0
  %cv10317 = zext i1 %cmp10316 to i32
  store i32 %cv10317, ptr %slot1787, align 8
  %v10318 = load i32, ptr %slot1787, align 8
  %cv10319 = zext i32 %v10318 to i64
  %cond10320 = icmp ne i64 %cv10319, 0
  br i1 %cond10320, label %bb_rcgclear2755, label %bb_rcgcounted2755
bb_rcgcounted2755:
  %v10321 = load i64, ptr %slot1782, align 8
  %op10322 = sub i64 %v10321, 32
  store i64 %op10322, ptr %slot1788, align 8
  %v10323 = load i64, ptr %slot1782, align 8
  %p10324 = inttoptr i64 %v10323 to ptr
  %rgep10325 = getelementptr i8, ptr %p10324, i64 -32
  %ld10326 = load i64, ptr %rgep10325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10326, ptr %slot1789, align 8
  %v10327 = load i64, ptr %slot1789, align 8
  %op10328 = sub i64 %v10327, 1
  store i64 %op10328, ptr %slot1790, align 8
  %v10329 = load i64, ptr %slot1790, align 8
  %cmp10330 = icmp eq i64 %v10329, 0
  %cv10331 = zext i1 %cmp10330 to i32
  store i32 %cv10331, ptr %slot1791, align 8
  %v10332 = load i32, ptr %slot1791, align 8
  %cv10333 = zext i32 %v10332 to i64
  %cond10334 = icmp ne i64 %cv10333, 0
  br i1 %cond10334, label %bb_rcglast2755, label %bb_rcgdec2755
bb_rcglast2755:
  %v10335 = load i64, ptr %slot1782, align 8
  %op10336 = sub i64 %v10335, 24
  store i64 %op10336, ptr %slot1792, align 8
  %v10337 = load i64, ptr %slot1782, align 8
  %p10338 = inttoptr i64 %v10337 to ptr
  %rgep10339 = getelementptr i8, ptr %p10338, i64 -24
  %ld10340 = load i64, ptr %rgep10339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10340, ptr %slot1793, align 8
  %v10341 = load i64, ptr %slot1793, align 8
  %cmp10342 = icmp ne i64 %v10341, 0
  %cv10343 = zext i1 %cmp10342 to i32
  store i32 %cv10343, ptr %slot1794, align 8
  %v10344 = load i32, ptr %slot1794, align 8
  %cv10345 = zext i32 %v10344 to i64
  %cond10346 = icmp ne i64 %cv10345, 0
  br i1 %cond10346, label %bb_rcgdec2755, label %bb_rcgslow2755
bb_rcgslow2755:
  %v10347 = load i64, ptr %slot1781, align 8
  %v10348 = load i64, ptr %slot1764, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v10347, i64 %v10348) nomerge, !dbg !188
  br label %bb_rcgdone2755
bb_rcgdec2755:
  %v10349 = load i64, ptr %slot1790, align 8
  %v10350 = load i64, ptr %slot1782, align 8
  %p10351 = inttoptr i64 %v10350 to ptr
  %rgep10352 = getelementptr i8, ptr %p10351, i64 -32
  store i64 %v10349, ptr %rgep10352, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2755
bb_rcgclear2755:
  %v10353 = load i64, ptr %slot1764, align 8
  %p10354 = inttoptr i64 %v10353 to ptr
  store i64 0, ptr %p10354, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2755
bb_rcgdone2755:
  br label %bb_rcslotdone2724
bb_rcslotdone2724:
  %v10355 = load i64, ptr %slot40, align 8
  %p10356 = inttoptr i64 %v10355 to ptr
  %ld10357 = load i64, ptr %p10356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10357, ptr %slot1795, align 8
  %v10358 = load i64, ptr %slot1795, align 8
  %v10359 = load i64, ptr %slot44, align 8
  %p10360 = inttoptr i64 %v10359 to ptr
  store i64 %v10358, ptr %p10360, align 8, !alias.scope !3, !noalias !4
  %v10361 = load i64, ptr %slot41, align 8
  %p10362 = inttoptr i64 %v10361 to ptr
  %ld10363 = load i64, ptr %p10362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10363, ptr %slot1796, align 8
  %v10364 = load i64, ptr %slot44, align 8
  %p10365 = inttoptr i64 %v10364 to ptr
  %ld10366 = load i64, ptr %p10365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10366, ptr %slot1797, align 8
  %v10367 = load i64, ptr %slot63, align 8
  %p10368 = inttoptr i64 %v10367 to ptr
  %v10369 = load i64, ptr %slot1796, align 8
  %p10370 = inttoptr i64 %v10369 to ptr
  %v10371 = load i64, ptr %slot1797, align 8
  %p10372 = inttoptr i64 %v10371 to ptr
  %call10373 = call ptr @myl_native_text_join(ptr %p10368, ptr %p10370, ptr %p10372) nomerge, !dbg !190
  %calladdr10374 = ptrtoint ptr %call10373 to i64
  store i64 %calladdr10374, ptr %slot1798, align 8
  %v10375 = load i64, ptr %slot1798, align 8
  %cond10376 = icmp ne i64 %v10375, 0
  br i1 %cond10376, label %bb_success2763, label %bb_failed2763
bb_failed2763:
  %v10377 = load i64, ptr %slot1, align 8
  %p10378 = inttoptr i64 %v10377 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10378) nomerge, !dbg !190
  unreachable
bb_success2763:
  %v10379 = load i64, ptr %slot1798, align 8
  %v10380 = load i64, ptr %slot44, align 8
  %p10381 = inttoptr i64 %v10380 to ptr
  store i64 %v10379, ptr %p10381, align 8, !alias.scope !3, !noalias !4
  %v10382 = load i64, ptr %slot44, align 8
  %p10383 = inttoptr i64 %v10382 to ptr
  %ld10384 = load i64, ptr %p10383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10384, ptr %slot1799, align 8
  %v10385 = load i64, ptr %slot1799, align 8
  %v10386 = load i64, ptr %slot23, align 8
  %p10387 = inttoptr i64 %v10386 to ptr
  store i64 %v10385, ptr %p10387, align 8, !alias.scope !3, !noalias !4
  %v10388 = load i64, ptr %slot23, align 8
  store i64 %v10388, ptr %slot1800, align 8
  %v10389 = load i64, ptr %slot24, align 8
  store i64 %v10389, ptr %slot1801, align 8
  %v10390 = load i64, ptr %slot1800, align 8
  %v10391 = load i64, ptr %slot1801, align 8
  %p10392 = inttoptr i64 %v10390 to ptr
  %p10393 = inttoptr i64 %v10391 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10393, ptr %p10392, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10394 = load i64, ptr %slot20, align 8
  %p10395 = inttoptr i64 %v10394 to ptr
  store i32 2, ptr %p10395, align 4, !alias.scope !3, !noalias !4
  %v10396 = load i64, ptr %slot19, align 8
  %p10397 = inttoptr i64 %v10396 to ptr
  store i32 1, ptr %p10397, align 4, !alias.scope !3, !noalias !4
  %v10398 = load i64, ptr %slot17, align 8
  %p10399 = inttoptr i64 %v10398 to ptr
  %ld10400 = load i32, ptr %p10399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10400, ptr %slot1802, align 8
  %v10401 = load i32, ptr %slot1802, align 8
  %cv10402 = zext i32 %v10401 to i64
  %cond10403 = icmp ne i64 %cv10402, 0
  br i1 %cond10403, label %bb_rcslotdrop2771, label %bb_rcslotdone2771
bb_rcslotdrop2771:
  %v10404 = load i64, ptr %slot17, align 8
  %p10405 = inttoptr i64 %v10404 to ptr
  store i32 0, ptr %p10405, align 4, !alias.scope !3, !noalias !4
  %v10406 = load i64, ptr %slot22, align 8
  store i64 %v10406, ptr %slot1803, align 8
  %v10407 = load i64, ptr %slot18, align 8
  %p10408 = inttoptr i64 %v10407 to ptr
  %ld10409 = load i32, ptr %p10408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10409, ptr %slot1804, align 8
  %v10410 = load i32, ptr %slot1804, align 8
  %op10411 = and i32 %v10410, 28
  store i32 %op10411, ptr %slot1805, align 8
  %v10412 = load i32, ptr %slot1805, align 8
  %cv10413 = zext i32 %v10412 to i64
  %cond10414 = icmp ne i64 %cv10413, 0
  br i1 %cond10414, label %bb_rcslotrole2771, label %bb_rcslotowner2771
bb_rcslotrole2771:
  %v10415 = load i64, ptr %slot63, align 8
  store i64 %v10415, ptr %slot1806, align 8
  %v10416 = load i64, ptr %slot1803, align 8
  %p10417 = inttoptr i64 %v10416 to ptr
  %ld10418 = load i64, ptr %p10417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10418, ptr %slot1807, align 8
  %v10419 = load i64, ptr %slot1807, align 8
  %cmp10420 = icmp ne i64 %v10419, 0
  %cv10421 = zext i1 %cmp10420 to i32
  store i32 %cv10421, ptr %slot1808, align 8
  %v10422 = load i32, ptr %slot1808, align 8
  %cv10423 = zext i32 %v10422 to i64
  %cond10424 = icmp ne i64 %cv10423, 0
  br i1 %cond10424, label %bb_rcgnn2787, label %bb_rcgdone2787
bb_rcgnn2787:
  %v10425 = load i64, ptr %slot1807, align 8
  %op10426 = sub i64 %v10425, 16
  store i64 %op10426, ptr %slot1809, align 8
  %v10427 = load i64, ptr %slot1807, align 8
  %p10428 = inttoptr i64 %v10427 to ptr
  %rgep10429 = getelementptr i8, ptr %p10428, i64 -16
  %ld10430 = load i64, ptr %rgep10429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10430, ptr %slot1810, align 8
  %v10431 = load i64, ptr %slot1810, align 8
  %op10432 = and i64 %v10431, 4611686018427387906
  store i64 %op10432, ptr %slot1811, align 8
  %v10433 = load i64, ptr %slot1811, align 8
  %cmp10434 = icmp ne i64 %v10433, 0
  %cv10435 = zext i1 %cmp10434 to i32
  store i32 %cv10435, ptr %slot1812, align 8
  %v10436 = load i32, ptr %slot1812, align 8
  %cv10437 = zext i32 %v10436 to i64
  %cond10438 = icmp ne i64 %cv10437, 0
  br i1 %cond10438, label %bb_rcgclear2787, label %bb_rcgcounted2787
bb_rcgcounted2787:
  %v10439 = load i64, ptr %slot1807, align 8
  %op10440 = sub i64 %v10439, 24
  store i64 %op10440, ptr %slot1813, align 8
  %v10441 = load i64, ptr %slot1807, align 8
  %p10442 = inttoptr i64 %v10441 to ptr
  %rgep10443 = getelementptr i8, ptr %p10442, i64 -24
  %ld10444 = load i64, ptr %rgep10443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10444, ptr %slot1814, align 8
  %v10445 = load i64, ptr %slot1814, align 8
  %op10446 = sub i64 %v10445, 1
  store i64 %op10446, ptr %slot1815, align 8
  %v10447 = load i64, ptr %slot1815, align 8
  %cmp10448 = icmp eq i64 %v10447, 0
  %cv10449 = zext i1 %cmp10448 to i32
  store i32 %cv10449, ptr %slot1816, align 8
  %v10450 = load i32, ptr %slot1816, align 8
  %cv10451 = zext i32 %v10450 to i64
  %cond10452 = icmp ne i64 %cv10451, 0
  br i1 %cond10452, label %bb_rcglast2787, label %bb_rcgdec2787
bb_rcglast2787:
  %v10453 = load i64, ptr %slot1807, align 8
  %op10454 = sub i64 %v10453, 32
  store i64 %op10454, ptr %slot1817, align 8
  %v10455 = load i64, ptr %slot1807, align 8
  %p10456 = inttoptr i64 %v10455 to ptr
  %rgep10457 = getelementptr i8, ptr %p10456, i64 -32
  %ld10458 = load i64, ptr %rgep10457, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10458, ptr %slot1818, align 8
  %v10459 = load i64, ptr %slot1818, align 8
  %cmp10460 = icmp ne i64 %v10459, 0
  %cv10461 = zext i1 %cmp10460 to i32
  store i32 %cv10461, ptr %slot1819, align 8
  %v10462 = load i32, ptr %slot1819, align 8
  %cv10463 = zext i32 %v10462 to i64
  %cond10464 = icmp ne i64 %cv10463, 0
  br i1 %cond10464, label %bb_rcgdec2787, label %bb_rcgslow2787
bb_rcgslow2787:
  %v10465 = load i64, ptr %slot1806, align 8
  %v10466 = load i64, ptr %slot1803, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v10465, i64 %v10466) nomerge, !dbg !190
  br label %bb_rcgdone2787
bb_rcgdec2787:
  %v10467 = load i64, ptr %slot1815, align 8
  %v10468 = load i64, ptr %slot1807, align 8
  %p10469 = inttoptr i64 %v10468 to ptr
  %rgep10470 = getelementptr i8, ptr %p10469, i64 -24
  store i64 %v10467, ptr %rgep10470, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2787
bb_rcgclear2787:
  %v10471 = load i64, ptr %slot1803, align 8
  %p10472 = inttoptr i64 %v10471 to ptr
  store i64 0, ptr %p10472, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2787
bb_rcgdone2787:
  br label %bb_rcslotdone2771
bb_rcslotowner2771:
  %v10473 = load i64, ptr %slot63, align 8
  store i64 %v10473, ptr %slot1820, align 8
  %v10474 = load i64, ptr %slot1803, align 8
  %p10475 = inttoptr i64 %v10474 to ptr
  %ld10476 = load i64, ptr %p10475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10476, ptr %slot1821, align 8
  %v10477 = load i64, ptr %slot1821, align 8
  %cmp10478 = icmp ne i64 %v10477, 0
  %cv10479 = zext i1 %cmp10478 to i32
  store i32 %cv10479, ptr %slot1822, align 8
  %v10480 = load i32, ptr %slot1822, align 8
  %cv10481 = zext i32 %v10480 to i64
  %cond10482 = icmp ne i64 %cv10481, 0
  br i1 %cond10482, label %bb_rcgnn2802, label %bb_rcgdone2802
bb_rcgnn2802:
  %v10483 = load i64, ptr %slot1821, align 8
  %op10484 = sub i64 %v10483, 16
  store i64 %op10484, ptr %slot1823, align 8
  %v10485 = load i64, ptr %slot1821, align 8
  %p10486 = inttoptr i64 %v10485 to ptr
  %rgep10487 = getelementptr i8, ptr %p10486, i64 -16
  %ld10488 = load i64, ptr %rgep10487, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10488, ptr %slot1824, align 8
  %v10489 = load i64, ptr %slot1824, align 8
  %op10490 = and i64 %v10489, 4611686018427387906
  store i64 %op10490, ptr %slot1825, align 8
  %v10491 = load i64, ptr %slot1825, align 8
  %cmp10492 = icmp ne i64 %v10491, 0
  %cv10493 = zext i1 %cmp10492 to i32
  store i32 %cv10493, ptr %slot1826, align 8
  %v10494 = load i32, ptr %slot1826, align 8
  %cv10495 = zext i32 %v10494 to i64
  %cond10496 = icmp ne i64 %cv10495, 0
  br i1 %cond10496, label %bb_rcgclear2802, label %bb_rcgcounted2802
bb_rcgcounted2802:
  %v10497 = load i64, ptr %slot1821, align 8
  %op10498 = sub i64 %v10497, 32
  store i64 %op10498, ptr %slot1827, align 8
  %v10499 = load i64, ptr %slot1821, align 8
  %p10500 = inttoptr i64 %v10499 to ptr
  %rgep10501 = getelementptr i8, ptr %p10500, i64 -32
  %ld10502 = load i64, ptr %rgep10501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10502, ptr %slot1828, align 8
  %v10503 = load i64, ptr %slot1828, align 8
  %op10504 = sub i64 %v10503, 1
  store i64 %op10504, ptr %slot1829, align 8
  %v10505 = load i64, ptr %slot1829, align 8
  %cmp10506 = icmp eq i64 %v10505, 0
  %cv10507 = zext i1 %cmp10506 to i32
  store i32 %cv10507, ptr %slot1830, align 8
  %v10508 = load i32, ptr %slot1830, align 8
  %cv10509 = zext i32 %v10508 to i64
  %cond10510 = icmp ne i64 %cv10509, 0
  br i1 %cond10510, label %bb_rcglast2802, label %bb_rcgdec2802
bb_rcglast2802:
  %v10511 = load i64, ptr %slot1821, align 8
  %op10512 = sub i64 %v10511, 24
  store i64 %op10512, ptr %slot1831, align 8
  %v10513 = load i64, ptr %slot1821, align 8
  %p10514 = inttoptr i64 %v10513 to ptr
  %rgep10515 = getelementptr i8, ptr %p10514, i64 -24
  %ld10516 = load i64, ptr %rgep10515, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10516, ptr %slot1832, align 8
  %v10517 = load i64, ptr %slot1832, align 8
  %cmp10518 = icmp ne i64 %v10517, 0
  %cv10519 = zext i1 %cmp10518 to i32
  store i32 %cv10519, ptr %slot1833, align 8
  %v10520 = load i32, ptr %slot1833, align 8
  %cv10521 = zext i32 %v10520 to i64
  %cond10522 = icmp ne i64 %cv10521, 0
  br i1 %cond10522, label %bb_rcgdec2802, label %bb_rcgslow2802
bb_rcgslow2802:
  %v10523 = load i64, ptr %slot1820, align 8
  %v10524 = load i64, ptr %slot1803, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v10523, i64 %v10524) nomerge, !dbg !190
  br label %bb_rcgdone2802
bb_rcgdec2802:
  %v10525 = load i64, ptr %slot1829, align 8
  %v10526 = load i64, ptr %slot1821, align 8
  %p10527 = inttoptr i64 %v10526 to ptr
  %rgep10528 = getelementptr i8, ptr %p10527, i64 -32
  store i64 %v10525, ptr %rgep10528, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2802
bb_rcgclear2802:
  %v10529 = load i64, ptr %slot1803, align 8
  %p10530 = inttoptr i64 %v10529 to ptr
  store i64 0, ptr %p10530, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2802
bb_rcgdone2802:
  br label %bb_rcslotdone2771
bb_rcslotdone2771:
  %v10531 = load i64, ptr %slot22, align 8
  store i64 %v10531, ptr %slot1834, align 8
  %v10532 = load i64, ptr %slot24, align 8
  store i64 %v10532, ptr %slot1835, align 8
  %v10533 = load i64, ptr %slot1835, align 8
  %v10534 = load i64, ptr %slot1834, align 8
  %p10535 = inttoptr i64 %v10533 to ptr
  %p10536 = inttoptr i64 %v10534 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10536, ptr %p10535, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10537 = load i64, ptr %slot18, align 8
  %p10538 = inttoptr i64 %v10537 to ptr
  store i32 2, ptr %p10538, align 4, !alias.scope !3, !noalias !4
  %v10539 = load i64, ptr %slot20, align 8
  %p10540 = inttoptr i64 %v10539 to ptr
  %ld10541 = load i32, ptr %p10540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10541, ptr %slot1836, align 8
  %v10542 = load i32, ptr %slot1836, align 8
  %v10543 = load i64, ptr %slot18, align 8
  %p10544 = inttoptr i64 %v10543 to ptr
  store i32 %v10542, ptr %p10544, align 4, !alias.scope !3, !noalias !4
  %v10545 = load i64, ptr %slot19, align 8
  %p10546 = inttoptr i64 %v10545 to ptr
  store i32 0, ptr %p10546, align 4, !alias.scope !3, !noalias !4
  %v10547 = load i64, ptr %slot17, align 8
  %p10548 = inttoptr i64 %v10547 to ptr
  store i32 1, ptr %p10548, align 4, !alias.scope !3, !noalias !4
  %v10549 = load i64, ptr %slot1834, align 8
  %p10550 = inttoptr i64 %v10549 to ptr
  %ld10551 = load i64, ptr %p10550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10551, ptr %slot1837, align 8
  %v10552 = load i64, ptr %slot1837, align 8
  %v10553 = load i64, ptr %slot44, align 8
  %p10554 = inttoptr i64 %v10553 to ptr
  store i64 %v10552, ptr %p10554, align 8, !alias.scope !3, !noalias !4
  %v10555 = load i64, ptr %slot44, align 8
  %p10556 = inttoptr i64 %v10555 to ptr
  %ld10557 = load i64, ptr %p10556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10557, ptr %slot1838, align 8
  %v10558 = load i64, ptr %slot1838, align 8
  %v10559 = load i64, ptr %slot23, align 8
  %p10560 = inttoptr i64 %v10559 to ptr
  store i64 %v10558, ptr %p10560, align 8, !alias.scope !3, !noalias !4
  %v10561 = load i64, ptr %slot23, align 8
  store i64 %v10561, ptr %slot1839, align 8
  %v10562 = load i64, ptr %slot17, align 8
  %p10563 = inttoptr i64 %v10562 to ptr
  %ld10564 = load i32, ptr %p10563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10564, ptr %slot1840, align 8
  %v10565 = load i64, ptr %slot18, align 8
  %p10566 = inttoptr i64 %v10565 to ptr
  %ld10567 = load i32, ptr %p10566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10567, ptr %slot1841, align 8
  %v10568 = load i32, ptr %slot1841, align 8
  %op10569 = and i32 %v10568, 24
  store i32 %op10569, ptr %slot1841, align 8
  %v10570 = load i32, ptr %slot1841, align 8
  %cmp10571 = icmp eq i32 %v10570, 0
  %cv10572 = zext i1 %cmp10571 to i32
  store i32 %cv10572, ptr %slot1842, align 8
  %v10573 = load i32, ptr %slot1840, align 8
  %v10574 = load i32, ptr %slot1842, align 8
  %op10575 = and i32 %v10573, %v10574
  store i32 %op10575, ptr %slot1843, align 8
  %v10576 = load i32, ptr %slot1843, align 8
  %cv10577 = zext i32 %v10576 to i64
  %cond10578 = icmp ne i64 %cv10577, 0
  br i1 %cond10578, label %bb_rcprivateown2823, label %bb_rcprivateloan2823
bb_rcprivateown2823:
  %v10579 = load i64, ptr %slot24, align 8
  store i64 %v10579, ptr %slot1844, align 8
  %v10580 = load i64, ptr %slot64, align 8
  store i64 %v10580, ptr %slot1845, align 8
  %v10581 = load i64, ptr %slot1839, align 8
  %v10582 = load i64, ptr %slot1844, align 8
  %op10583 = sub i64 %v10581, %v10582
  store i64 %op10583, ptr %slot1846, align 8
  %v10584 = load i64, ptr %slot1844, align 8
  %v10585 = load i64, ptr %slot1839, align 8
  %op10586 = sub i64 %v10584, %v10585
  store i64 %op10586, ptr %slot1847, align 8
  %v10587 = load i64, ptr %slot1846, align 8
  %cmp10588 = icmp ult i64 %v10587, 8
  %cv10589 = zext i1 %cmp10588 to i32
  store i32 %cv10589, ptr %slot1848, align 8
  %v10590 = load i64, ptr %slot1847, align 8
  %cmp10591 = icmp ult i64 %v10590, 8
  %cv10592 = zext i1 %cmp10591 to i32
  store i32 %cv10592, ptr %slot1849, align 8
  %v10593 = load i32, ptr %slot1848, align 8
  %v10594 = load i32, ptr %slot1849, align 8
  %op10595 = or i32 %v10593, %v10594
  store i32 %op10595, ptr %slot1850, align 8
  %v10596 = load i32, ptr %slot1850, align 8
  %cv10597 = zext i32 %v10596 to i64
  %cond10598 = icmp ne i64 %cv10597, 0
  br i1 %cond10598, label %bb_rcmoveslow2826, label %bb_rcmovecheck2826
bb_rcmovecheck2826:
  %v10599 = load i64, ptr %slot1839, align 8
  %p10601 = inttoptr i64 %v10599 to ptr
  %gep10602 = getelementptr i8, ptr %p10601, i64 0
  %op10600 = ptrtoint ptr %gep10602 to i64
  store i64 %op10600, ptr %slot1851, align 8
  %v10603 = load i64, ptr %slot1851, align 8
  %p10604 = inttoptr i64 %v10603 to ptr
  %ld10605 = load i64, ptr %p10604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10605, ptr %slot1852, align 8
  %v10606 = load i64, ptr %slot1852, align 8
  %cmp10607 = icmp ne i64 %v10606, 0
  %cv10608 = zext i1 %cmp10607 to i32
  store i32 %cv10608, ptr %slot1853, align 8
  %v10609 = load i32, ptr %slot1853, align 8
  %cv10610 = zext i32 %v10609 to i64
  %cond10611 = icmp ne i64 %cv10610, 0
  br i1 %cond10611, label %bb_rcmoveheader2834, label %bb_rcmovenext2834
bb_rcmoveheader2834:
  %v10612 = load i64, ptr %slot1852, align 8
  %op10613 = sub i64 %v10612, 16
  store i64 %op10613, ptr %slot1854, align 8
  %v10614 = load i64, ptr %slot1852, align 8
  %p10615 = inttoptr i64 %v10614 to ptr
  %rgep10616 = getelementptr i8, ptr %p10615, i64 -16
  %ld10617 = load i64, ptr %rgep10616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10617, ptr %slot1855, align 8
  %v10618 = load i64, ptr %slot1855, align 8
  %op10619 = and i64 %v10618, 5764607523034234881
  store i64 %op10619, ptr %slot1856, align 8
  %v10620 = load i64, ptr %slot1856, align 8
  %cmp10621 = icmp ne i64 %v10620, 0
  %cv10622 = zext i1 %cmp10621 to i32
  store i32 %cv10622, ptr %slot1857, align 8
  %v10623 = load i32, ptr %slot1857, align 8
  %cv10624 = zext i32 %v10623 to i64
  %cond10625 = icmp ne i64 %cv10624, 0
  br i1 %cond10625, label %bb_rcmoveslow2826, label %bb_rcmovenext2834
bb_rcmovenext2834:
  %v10626 = load i64, ptr %slot1839, align 8
  %v10627 = load i64, ptr %slot1844, align 8
  %p10628 = inttoptr i64 %v10626 to ptr
  %p10629 = inttoptr i64 %v10627 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10629, ptr %p10628, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10630 = load i64, ptr %slot1839, align 8
  %p10631 = inttoptr i64 %v10630 to ptr
  store i64 0, ptr %p10631, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2826
bb_rcmoveslow2826:
  %v10632 = load i64, ptr %slot63, align 8
  %v10633 = load i64, ptr %slot1844, align 8
  %v10634 = load i64, ptr %slot1839, align 8
  %v10635 = load i64, ptr %slot1845, align 8
  %cv10636 = trunc i64 %v10635 to i32
  %call10637 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v10632, i64 %v10633, i64 %v10634, i32 %cv10636) nomerge, !dbg !192
  store i32 %call10637, ptr %slot1858, align 8
  %v10638 = load i32, ptr %slot1858, align 8
  %cv10639 = zext i32 %v10638 to i64
  %cond10640 = icmp ne i64 %cv10639, 0
  br i1 %cond10640, label %bb_rcsuccess2841, label %bb_rcfailure2841
bb_rcfailure2841:
  %v10641 = load i64, ptr %slot63, align 8
  %p10642 = inttoptr i64 %v10641 to ptr
  %call10643 = call i32 @myl_rc_take_failure(ptr %p10642) nomerge, !dbg !192
  store i32 %call10643, ptr %slot1859, align 8
  %v10644 = load i64, ptr %slot1, align 8
  %p10645 = inttoptr i64 %v10644 to ptr
  %v10646 = load i32, ptr %slot1859, align 8
  %call10647 = call i32 @myl_qbe_rc_status(ptr %p10645, i32 %v10646) nomerge, !dbg !192
  store i32 %call10647, ptr %slot1860, align 8
  br label %bb_failure
bb_rcsuccess2841:
  br label %bb_rcmoved2826
bb_rcmoved2826:
  %v10648 = load i64, ptr %slot17, align 8
  %p10649 = inttoptr i64 %v10648 to ptr
  store i32 0, ptr %p10649, align 4, !alias.scope !3, !noalias !4
  %v10650 = load i64, ptr %slot20, align 8
  %p10651 = inttoptr i64 %v10650 to ptr
  store i32 2, ptr %p10651, align 4, !alias.scope !3, !noalias !4
  %v10652 = load i64, ptr %slot19, align 8
  %p10653 = inttoptr i64 %v10652 to ptr
  store i32 1, ptr %p10653, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2823
bb_rcprivateloan2823:
  %v10654 = load i64, ptr %slot17, align 8
  %p10655 = inttoptr i64 %v10654 to ptr
  %ld10656 = load i32, ptr %p10655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10656, ptr %slot1861, align 8
  %v10657 = load i64, ptr %slot18, align 8
  %p10658 = inttoptr i64 %v10657 to ptr
  %ld10659 = load i32, ptr %p10658, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10659, ptr %slot1862, align 8
  %v10660 = load i32, ptr %slot1862, align 8
  %cmp10661 = icmp eq i32 %v10660, 16
  %cv10662 = zext i1 %cmp10661 to i32
  store i32 %cv10662, ptr %slot1863, align 8
  %v10663 = load i32, ptr %slot1863, align 8
  %v10664 = load i32, ptr %slot1861, align 8
  %op10665 = and i32 %v10663, %v10664
  store i32 %op10665, ptr %slot1863, align 8
  %v10666 = load i32, ptr %slot1863, align 8
  %cv10667 = zext i32 %v10666 to i64
  %cond10668 = icmp ne i64 %cv10667, 0
  br i1 %cond10668, label %bb_rcprivatemove2823, label %bb_rcprivatenew2823
bb_rcprivatemove2823:
  %v10669 = load i64, ptr %slot24, align 8
  store i64 %v10669, ptr %slot1864, align 8
  %v10670 = load i64, ptr %slot1839, align 8
  %v10671 = load i64, ptr %slot1864, align 8
  %p10672 = inttoptr i64 %v10670 to ptr
  %p10673 = inttoptr i64 %v10671 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10673, ptr %p10672, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10674 = load i64, ptr %slot1839, align 8
  %p10675 = inttoptr i64 %v10674 to ptr
  store i64 0, ptr %p10675, align 8, !alias.scope !3, !noalias !4
  %v10676 = load i64, ptr %slot20, align 8
  %p10677 = inttoptr i64 %v10676 to ptr
  store i32 2, ptr %p10677, align 4, !alias.scope !3, !noalias !4
  %v10678 = load i64, ptr %slot20, align 8
  %p10679 = inttoptr i64 %v10678 to ptr
  store i32 16, ptr %p10679, align 4, !alias.scope !3, !noalias !4
  %v10680 = load i64, ptr %slot19, align 8
  %p10681 = inttoptr i64 %v10680 to ptr
  store i32 1, ptr %p10681, align 4, !alias.scope !3, !noalias !4
  %v10682 = load i64, ptr %slot17, align 8
  %p10683 = inttoptr i64 %v10682 to ptr
  store i32 0, ptr %p10683, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2823
bb_rcprivatenew2823:
  %v10684 = load i64, ptr %slot24, align 8
  store i64 %v10684, ptr %slot1865, align 8
  %v10685 = load i64, ptr %slot1839, align 8
  %p10686 = inttoptr i64 %v10685 to ptr
  %ld10687 = load i64, ptr %p10686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10687, ptr %slot1866, align 8
  %v10688 = load i64, ptr %slot1866, align 8
  %cmp10689 = icmp ne i64 %v10688, 0
  %cv10690 = zext i1 %cmp10689 to i32
  store i32 %cv10690, ptr %slot1867, align 8
  %v10691 = load i32, ptr %slot1867, align 8
  %cv10692 = zext i32 %v10691 to i64
  %cond10693 = icmp ne i64 %cv10692, 0
  br i1 %cond10693, label %bb_rcgnn2859, label %bb_rcgstore2859
bb_rcgnn2859:
  %v10694 = load i64, ptr %slot1866, align 8
  %op10695 = sub i64 %v10694, 16
  store i64 %op10695, ptr %slot1868, align 8
  %v10696 = load i64, ptr %slot1866, align 8
  %p10697 = inttoptr i64 %v10696 to ptr
  %rgep10698 = getelementptr i8, ptr %p10697, i64 -16
  %ld10699 = load i64, ptr %rgep10698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10699, ptr %slot1869, align 8
  %v10700 = load i64, ptr %slot1869, align 8
  %op10701 = and i64 %v10700, 4611686018427387906
  store i64 %op10701, ptr %slot1870, align 8
  %v10702 = load i64, ptr %slot1870, align 8
  %cmp10703 = icmp ne i64 %v10702, 0
  %cv10704 = zext i1 %cmp10703 to i32
  store i32 %cv10704, ptr %slot1871, align 8
  %v10705 = load i32, ptr %slot1871, align 8
  %cv10706 = zext i32 %v10705 to i64
  %cond10707 = icmp ne i64 %cv10706, 0
  br i1 %cond10707, label %bb_rcgstore2859, label %bb_rcginc2859
bb_rcginc2859:
  %v10708 = load i64, ptr %slot1866, align 8
  %op10709 = sub i64 %v10708, 24
  store i64 %op10709, ptr %slot1872, align 8
  %v10710 = load i64, ptr %slot1866, align 8
  %p10711 = inttoptr i64 %v10710 to ptr
  %rgep10712 = getelementptr i8, ptr %p10711, i64 -24
  %ld10713 = load i64, ptr %rgep10712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10713, ptr %slot1873, align 8
  %v10714 = load i64, ptr %slot1873, align 8
  %op10715 = add i64 %v10714, 1
  store i64 %op10715, ptr %slot1874, align 8
  %v10716 = load i64, ptr %slot1874, align 8
  %cmp10717 = icmp eq i64 %v10716, 0
  %cv10718 = zext i1 %cmp10717 to i32
  store i32 %cv10718, ptr %slot1875, align 8
  %v10719 = load i32, ptr %slot1875, align 8
  %cv10720 = zext i32 %v10719 to i64
  %cond10721 = icmp ne i64 %cv10720, 0
  br i1 %cond10721, label %bb_rcglimit2859, label %bb_rcgcapacity2859
bb_rcglimit2859:
  %v10722 = load i64, ptr %slot1, align 8
  %p10723 = inttoptr i64 %v10722 to ptr
  %call10724 = call i32 @myl_qbe_rc_status(ptr %p10723, i32 2) nomerge, !dbg !192
  store i32 %call10724, ptr %slot1876, align 8
  br label %bb_failure
bb_rcgcapacity2859:
  %v10725 = load i64, ptr %slot1874, align 8
  %v10726 = load i64, ptr %slot1866, align 8
  %p10727 = inttoptr i64 %v10726 to ptr
  %rgep10728 = getelementptr i8, ptr %p10727, i64 -24
  store i64 %v10725, ptr %rgep10728, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2859
bb_rcgstore2859:
  %v10729 = load i64, ptr %slot1866, align 8
  %v10730 = load i64, ptr %slot1865, align 8
  %p10731 = inttoptr i64 %v10730 to ptr
  store i64 %v10729, ptr %p10731, align 8, !alias.scope !3, !noalias !4
  %v10732 = load i64, ptr %slot20, align 8
  %p10733 = inttoptr i64 %v10732 to ptr
  store i32 2, ptr %p10733, align 4, !alias.scope !3, !noalias !4
  %v10734 = load i64, ptr %slot20, align 8
  %p10735 = inttoptr i64 %v10734 to ptr
  store i32 16, ptr %p10735, align 4, !alias.scope !3, !noalias !4
  %v10736 = load i64, ptr %slot19, align 8
  %p10737 = inttoptr i64 %v10736 to ptr
  store i32 1, ptr %p10737, align 4, !alias.scope !3, !noalias !4
  %v10738 = load i64, ptr %slot17, align 8
  %p10739 = inttoptr i64 %v10738 to ptr
  %ld10740 = load i32, ptr %p10739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10740, ptr %slot1877, align 8
  %v10741 = load i32, ptr %slot1877, align 8
  %cv10742 = zext i32 %v10741 to i64
  %cond10743 = icmp ne i64 %cv10742, 0
  br i1 %cond10743, label %bb_rcslotdrop2875, label %bb_rcslotdone2875
bb_rcslotdrop2875:
  %v10744 = load i64, ptr %slot17, align 8
  %p10745 = inttoptr i64 %v10744 to ptr
  store i32 0, ptr %p10745, align 4, !alias.scope !3, !noalias !4
  %v10746 = load i64, ptr %slot22, align 8
  store i64 %v10746, ptr %slot1878, align 8
  %v10747 = load i64, ptr %slot18, align 8
  %p10748 = inttoptr i64 %v10747 to ptr
  %ld10749 = load i32, ptr %p10748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10749, ptr %slot1879, align 8
  %v10750 = load i32, ptr %slot1879, align 8
  %op10751 = and i32 %v10750, 28
  store i32 %op10751, ptr %slot1880, align 8
  %v10752 = load i32, ptr %slot1880, align 8
  %cv10753 = zext i32 %v10752 to i64
  %cond10754 = icmp ne i64 %cv10753, 0
  br i1 %cond10754, label %bb_rcslotrole2875, label %bb_rcslotowner2875
bb_rcslotrole2875:
  %v10755 = load i64, ptr %slot63, align 8
  store i64 %v10755, ptr %slot1881, align 8
  %v10756 = load i64, ptr %slot1878, align 8
  %p10757 = inttoptr i64 %v10756 to ptr
  %ld10758 = load i64, ptr %p10757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10758, ptr %slot1882, align 8
  %v10759 = load i64, ptr %slot1882, align 8
  %cmp10760 = icmp ne i64 %v10759, 0
  %cv10761 = zext i1 %cmp10760 to i32
  store i32 %cv10761, ptr %slot1883, align 8
  %v10762 = load i32, ptr %slot1883, align 8
  %cv10763 = zext i32 %v10762 to i64
  %cond10764 = icmp ne i64 %cv10763, 0
  br i1 %cond10764, label %bb_rcgnn2891, label %bb_rcgdone2891
bb_rcgnn2891:
  %v10765 = load i64, ptr %slot1882, align 8
  %op10766 = sub i64 %v10765, 16
  store i64 %op10766, ptr %slot1884, align 8
  %v10767 = load i64, ptr %slot1882, align 8
  %p10768 = inttoptr i64 %v10767 to ptr
  %rgep10769 = getelementptr i8, ptr %p10768, i64 -16
  %ld10770 = load i64, ptr %rgep10769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10770, ptr %slot1885, align 8
  %v10771 = load i64, ptr %slot1885, align 8
  %op10772 = and i64 %v10771, 4611686018427387906
  store i64 %op10772, ptr %slot1886, align 8
  %v10773 = load i64, ptr %slot1886, align 8
  %cmp10774 = icmp ne i64 %v10773, 0
  %cv10775 = zext i1 %cmp10774 to i32
  store i32 %cv10775, ptr %slot1887, align 8
  %v10776 = load i32, ptr %slot1887, align 8
  %cv10777 = zext i32 %v10776 to i64
  %cond10778 = icmp ne i64 %cv10777, 0
  br i1 %cond10778, label %bb_rcgclear2891, label %bb_rcgcounted2891
bb_rcgcounted2891:
  %v10779 = load i64, ptr %slot1882, align 8
  %op10780 = sub i64 %v10779, 24
  store i64 %op10780, ptr %slot1888, align 8
  %v10781 = load i64, ptr %slot1882, align 8
  %p10782 = inttoptr i64 %v10781 to ptr
  %rgep10783 = getelementptr i8, ptr %p10782, i64 -24
  %ld10784 = load i64, ptr %rgep10783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10784, ptr %slot1889, align 8
  %v10785 = load i64, ptr %slot1889, align 8
  %op10786 = sub i64 %v10785, 1
  store i64 %op10786, ptr %slot1890, align 8
  %v10787 = load i64, ptr %slot1890, align 8
  %cmp10788 = icmp eq i64 %v10787, 0
  %cv10789 = zext i1 %cmp10788 to i32
  store i32 %cv10789, ptr %slot1891, align 8
  %v10790 = load i32, ptr %slot1891, align 8
  %cv10791 = zext i32 %v10790 to i64
  %cond10792 = icmp ne i64 %cv10791, 0
  br i1 %cond10792, label %bb_rcglast2891, label %bb_rcgdec2891
bb_rcglast2891:
  %v10793 = load i64, ptr %slot1882, align 8
  %op10794 = sub i64 %v10793, 32
  store i64 %op10794, ptr %slot1892, align 8
  %v10795 = load i64, ptr %slot1882, align 8
  %p10796 = inttoptr i64 %v10795 to ptr
  %rgep10797 = getelementptr i8, ptr %p10796, i64 -32
  %ld10798 = load i64, ptr %rgep10797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10798, ptr %slot1893, align 8
  %v10799 = load i64, ptr %slot1893, align 8
  %cmp10800 = icmp ne i64 %v10799, 0
  %cv10801 = zext i1 %cmp10800 to i32
  store i32 %cv10801, ptr %slot1894, align 8
  %v10802 = load i32, ptr %slot1894, align 8
  %cv10803 = zext i32 %v10802 to i64
  %cond10804 = icmp ne i64 %cv10803, 0
  br i1 %cond10804, label %bb_rcgdec2891, label %bb_rcgslow2891
bb_rcgslow2891:
  %v10805 = load i64, ptr %slot1881, align 8
  %v10806 = load i64, ptr %slot1878, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v10805, i64 %v10806) nomerge, !dbg !192
  br label %bb_rcgdone2891
bb_rcgdec2891:
  %v10807 = load i64, ptr %slot1890, align 8
  %v10808 = load i64, ptr %slot1882, align 8
  %p10809 = inttoptr i64 %v10808 to ptr
  %rgep10810 = getelementptr i8, ptr %p10809, i64 -24
  store i64 %v10807, ptr %rgep10810, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2891
bb_rcgclear2891:
  %v10811 = load i64, ptr %slot1878, align 8
  %p10812 = inttoptr i64 %v10811 to ptr
  store i64 0, ptr %p10812, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2891
bb_rcgdone2891:
  br label %bb_rcslotdone2875
bb_rcslotowner2875:
  %v10813 = load i64, ptr %slot63, align 8
  store i64 %v10813, ptr %slot1895, align 8
  %v10814 = load i64, ptr %slot1878, align 8
  %p10815 = inttoptr i64 %v10814 to ptr
  %ld10816 = load i64, ptr %p10815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10816, ptr %slot1896, align 8
  %v10817 = load i64, ptr %slot1896, align 8
  %cmp10818 = icmp ne i64 %v10817, 0
  %cv10819 = zext i1 %cmp10818 to i32
  store i32 %cv10819, ptr %slot1897, align 8
  %v10820 = load i32, ptr %slot1897, align 8
  %cv10821 = zext i32 %v10820 to i64
  %cond10822 = icmp ne i64 %cv10821, 0
  br i1 %cond10822, label %bb_rcgnn2906, label %bb_rcgdone2906
bb_rcgnn2906:
  %v10823 = load i64, ptr %slot1896, align 8
  %op10824 = sub i64 %v10823, 16
  store i64 %op10824, ptr %slot1898, align 8
  %v10825 = load i64, ptr %slot1896, align 8
  %p10826 = inttoptr i64 %v10825 to ptr
  %rgep10827 = getelementptr i8, ptr %p10826, i64 -16
  %ld10828 = load i64, ptr %rgep10827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10828, ptr %slot1899, align 8
  %v10829 = load i64, ptr %slot1899, align 8
  %op10830 = and i64 %v10829, 4611686018427387906
  store i64 %op10830, ptr %slot1900, align 8
  %v10831 = load i64, ptr %slot1900, align 8
  %cmp10832 = icmp ne i64 %v10831, 0
  %cv10833 = zext i1 %cmp10832 to i32
  store i32 %cv10833, ptr %slot1901, align 8
  %v10834 = load i32, ptr %slot1901, align 8
  %cv10835 = zext i32 %v10834 to i64
  %cond10836 = icmp ne i64 %cv10835, 0
  br i1 %cond10836, label %bb_rcgclear2906, label %bb_rcgcounted2906
bb_rcgcounted2906:
  %v10837 = load i64, ptr %slot1896, align 8
  %op10838 = sub i64 %v10837, 32
  store i64 %op10838, ptr %slot1902, align 8
  %v10839 = load i64, ptr %slot1896, align 8
  %p10840 = inttoptr i64 %v10839 to ptr
  %rgep10841 = getelementptr i8, ptr %p10840, i64 -32
  %ld10842 = load i64, ptr %rgep10841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10842, ptr %slot1903, align 8
  %v10843 = load i64, ptr %slot1903, align 8
  %op10844 = sub i64 %v10843, 1
  store i64 %op10844, ptr %slot1904, align 8
  %v10845 = load i64, ptr %slot1904, align 8
  %cmp10846 = icmp eq i64 %v10845, 0
  %cv10847 = zext i1 %cmp10846 to i32
  store i32 %cv10847, ptr %slot1905, align 8
  %v10848 = load i32, ptr %slot1905, align 8
  %cv10849 = zext i32 %v10848 to i64
  %cond10850 = icmp ne i64 %cv10849, 0
  br i1 %cond10850, label %bb_rcglast2906, label %bb_rcgdec2906
bb_rcglast2906:
  %v10851 = load i64, ptr %slot1896, align 8
  %op10852 = sub i64 %v10851, 24
  store i64 %op10852, ptr %slot1906, align 8
  %v10853 = load i64, ptr %slot1896, align 8
  %p10854 = inttoptr i64 %v10853 to ptr
  %rgep10855 = getelementptr i8, ptr %p10854, i64 -24
  %ld10856 = load i64, ptr %rgep10855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10856, ptr %slot1907, align 8
  %v10857 = load i64, ptr %slot1907, align 8
  %cmp10858 = icmp ne i64 %v10857, 0
  %cv10859 = zext i1 %cmp10858 to i32
  store i32 %cv10859, ptr %slot1908, align 8
  %v10860 = load i32, ptr %slot1908, align 8
  %cv10861 = zext i32 %v10860 to i64
  %cond10862 = icmp ne i64 %cv10861, 0
  br i1 %cond10862, label %bb_rcgdec2906, label %bb_rcgslow2906
bb_rcgslow2906:
  %v10863 = load i64, ptr %slot1895, align 8
  %v10864 = load i64, ptr %slot1878, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v10863, i64 %v10864) nomerge, !dbg !192
  br label %bb_rcgdone2906
bb_rcgdec2906:
  %v10865 = load i64, ptr %slot1904, align 8
  %v10866 = load i64, ptr %slot1896, align 8
  %p10867 = inttoptr i64 %v10866 to ptr
  %rgep10868 = getelementptr i8, ptr %p10867, i64 -32
  store i64 %v10865, ptr %rgep10868, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2906
bb_rcgclear2906:
  %v10869 = load i64, ptr %slot1878, align 8
  %p10870 = inttoptr i64 %v10869 to ptr
  store i64 0, ptr %p10870, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2906
bb_rcgdone2906:
  br label %bb_rcslotdone2875
bb_rcslotdone2875:
  br label %bb_rcprivateprepared2823
bb_rcprivateprepared2823:
  %v10871 = load i64, ptr %slot13, align 8
  %p10872 = inttoptr i64 %v10871 to ptr
  %ld10873 = load i32, ptr %p10872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10873, ptr %slot1909, align 8
  %v10874 = load i32, ptr %slot1909, align 8
  %cv10875 = zext i32 %v10874 to i64
  %cond10876 = icmp ne i64 %cv10875, 0
  br i1 %cond10876, label %bb_rcslotdrop2913, label %bb_rcslotdone2913
bb_rcslotdrop2913:
  %v10877 = load i64, ptr %slot13, align 8
  %p10878 = inttoptr i64 %v10877 to ptr
  store i32 0, ptr %p10878, align 4, !alias.scope !3, !noalias !4
  %v10879 = load i64, ptr %slot42, align 8
  store i64 %v10879, ptr %slot1910, align 8
  %v10880 = load i64, ptr %slot14, align 8
  %p10881 = inttoptr i64 %v10880 to ptr
  %ld10882 = load i32, ptr %p10881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10882, ptr %slot1911, align 8
  %v10883 = load i32, ptr %slot1911, align 8
  %op10884 = and i32 %v10883, 28
  store i32 %op10884, ptr %slot1912, align 8
  %v10885 = load i32, ptr %slot1912, align 8
  %cv10886 = zext i32 %v10885 to i64
  %cond10887 = icmp ne i64 %cv10886, 0
  br i1 %cond10887, label %bb_rcslotrole2913, label %bb_rcslotowner2913
bb_rcslotrole2913:
  %v10888 = load i64, ptr %slot63, align 8
  store i64 %v10888, ptr %slot1913, align 8
  %v10889 = load i64, ptr %slot1910, align 8
  %p10890 = inttoptr i64 %v10889 to ptr
  %ld10891 = load i64, ptr %p10890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10891, ptr %slot1914, align 8
  %v10892 = load i64, ptr %slot1914, align 8
  %cmp10893 = icmp ne i64 %v10892, 0
  %cv10894 = zext i1 %cmp10893 to i32
  store i32 %cv10894, ptr %slot1915, align 8
  %v10895 = load i32, ptr %slot1915, align 8
  %cv10896 = zext i32 %v10895 to i64
  %cond10897 = icmp ne i64 %cv10896, 0
  br i1 %cond10897, label %bb_rcgnn2929, label %bb_rcgdone2929
bb_rcgnn2929:
  %v10898 = load i64, ptr %slot1914, align 8
  %op10899 = sub i64 %v10898, 16
  store i64 %op10899, ptr %slot1916, align 8
  %v10900 = load i64, ptr %slot1914, align 8
  %p10901 = inttoptr i64 %v10900 to ptr
  %rgep10902 = getelementptr i8, ptr %p10901, i64 -16
  %ld10903 = load i64, ptr %rgep10902, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10903, ptr %slot1917, align 8
  %v10904 = load i64, ptr %slot1917, align 8
  %op10905 = and i64 %v10904, 4611686018427387906
  store i64 %op10905, ptr %slot1918, align 8
  %v10906 = load i64, ptr %slot1918, align 8
  %cmp10907 = icmp ne i64 %v10906, 0
  %cv10908 = zext i1 %cmp10907 to i32
  store i32 %cv10908, ptr %slot1919, align 8
  %v10909 = load i32, ptr %slot1919, align 8
  %cv10910 = zext i32 %v10909 to i64
  %cond10911 = icmp ne i64 %cv10910, 0
  br i1 %cond10911, label %bb_rcgclear2929, label %bb_rcgcounted2929
bb_rcgcounted2929:
  %v10912 = load i64, ptr %slot1914, align 8
  %op10913 = sub i64 %v10912, 24
  store i64 %op10913, ptr %slot1920, align 8
  %v10914 = load i64, ptr %slot1914, align 8
  %p10915 = inttoptr i64 %v10914 to ptr
  %rgep10916 = getelementptr i8, ptr %p10915, i64 -24
  %ld10917 = load i64, ptr %rgep10916, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10917, ptr %slot1921, align 8
  %v10918 = load i64, ptr %slot1921, align 8
  %op10919 = sub i64 %v10918, 1
  store i64 %op10919, ptr %slot1922, align 8
  %v10920 = load i64, ptr %slot1922, align 8
  %cmp10921 = icmp eq i64 %v10920, 0
  %cv10922 = zext i1 %cmp10921 to i32
  store i32 %cv10922, ptr %slot1923, align 8
  %v10923 = load i32, ptr %slot1923, align 8
  %cv10924 = zext i32 %v10923 to i64
  %cond10925 = icmp ne i64 %cv10924, 0
  br i1 %cond10925, label %bb_rcglast2929, label %bb_rcgdec2929
bb_rcglast2929:
  %v10926 = load i64, ptr %slot1914, align 8
  %op10927 = sub i64 %v10926, 32
  store i64 %op10927, ptr %slot1924, align 8
  %v10928 = load i64, ptr %slot1914, align 8
  %p10929 = inttoptr i64 %v10928 to ptr
  %rgep10930 = getelementptr i8, ptr %p10929, i64 -32
  %ld10931 = load i64, ptr %rgep10930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10931, ptr %slot1925, align 8
  %v10932 = load i64, ptr %slot1925, align 8
  %cmp10933 = icmp ne i64 %v10932, 0
  %cv10934 = zext i1 %cmp10933 to i32
  store i32 %cv10934, ptr %slot1926, align 8
  %v10935 = load i32, ptr %slot1926, align 8
  %cv10936 = zext i32 %v10935 to i64
  %cond10937 = icmp ne i64 %cv10936, 0
  br i1 %cond10937, label %bb_rcgdec2929, label %bb_rcgslow2929
bb_rcgslow2929:
  %v10938 = load i64, ptr %slot1913, align 8
  %v10939 = load i64, ptr %slot1910, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v10938, i64 %v10939) nomerge, !dbg !192
  br label %bb_rcgdone2929
bb_rcgdec2929:
  %v10940 = load i64, ptr %slot1922, align 8
  %v10941 = load i64, ptr %slot1914, align 8
  %p10942 = inttoptr i64 %v10941 to ptr
  %rgep10943 = getelementptr i8, ptr %p10942, i64 -24
  store i64 %v10940, ptr %rgep10943, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2929
bb_rcgclear2929:
  %v10944 = load i64, ptr %slot1910, align 8
  %p10945 = inttoptr i64 %v10944 to ptr
  store i64 0, ptr %p10945, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2929
bb_rcgdone2929:
  br label %bb_rcslotdone2913
bb_rcslotowner2913:
  %v10946 = load i64, ptr %slot63, align 8
  store i64 %v10946, ptr %slot1927, align 8
  %v10947 = load i64, ptr %slot1910, align 8
  %p10948 = inttoptr i64 %v10947 to ptr
  %ld10949 = load i64, ptr %p10948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10949, ptr %slot1928, align 8
  %v10950 = load i64, ptr %slot1928, align 8
  %cmp10951 = icmp ne i64 %v10950, 0
  %cv10952 = zext i1 %cmp10951 to i32
  store i32 %cv10952, ptr %slot1929, align 8
  %v10953 = load i32, ptr %slot1929, align 8
  %cv10954 = zext i32 %v10953 to i64
  %cond10955 = icmp ne i64 %cv10954, 0
  br i1 %cond10955, label %bb_rcgnn2944, label %bb_rcgdone2944
bb_rcgnn2944:
  %v10956 = load i64, ptr %slot1928, align 8
  %op10957 = sub i64 %v10956, 16
  store i64 %op10957, ptr %slot1930, align 8
  %v10958 = load i64, ptr %slot1928, align 8
  %p10959 = inttoptr i64 %v10958 to ptr
  %rgep10960 = getelementptr i8, ptr %p10959, i64 -16
  %ld10961 = load i64, ptr %rgep10960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10961, ptr %slot1931, align 8
  %v10962 = load i64, ptr %slot1931, align 8
  %op10963 = and i64 %v10962, 4611686018427387906
  store i64 %op10963, ptr %slot1932, align 8
  %v10964 = load i64, ptr %slot1932, align 8
  %cmp10965 = icmp ne i64 %v10964, 0
  %cv10966 = zext i1 %cmp10965 to i32
  store i32 %cv10966, ptr %slot1933, align 8
  %v10967 = load i32, ptr %slot1933, align 8
  %cv10968 = zext i32 %v10967 to i64
  %cond10969 = icmp ne i64 %cv10968, 0
  br i1 %cond10969, label %bb_rcgclear2944, label %bb_rcgcounted2944
bb_rcgcounted2944:
  %v10970 = load i64, ptr %slot1928, align 8
  %op10971 = sub i64 %v10970, 32
  store i64 %op10971, ptr %slot1934, align 8
  %v10972 = load i64, ptr %slot1928, align 8
  %p10973 = inttoptr i64 %v10972 to ptr
  %rgep10974 = getelementptr i8, ptr %p10973, i64 -32
  %ld10975 = load i64, ptr %rgep10974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10975, ptr %slot1935, align 8
  %v10976 = load i64, ptr %slot1935, align 8
  %op10977 = sub i64 %v10976, 1
  store i64 %op10977, ptr %slot1936, align 8
  %v10978 = load i64, ptr %slot1936, align 8
  %cmp10979 = icmp eq i64 %v10978, 0
  %cv10980 = zext i1 %cmp10979 to i32
  store i32 %cv10980, ptr %slot1937, align 8
  %v10981 = load i32, ptr %slot1937, align 8
  %cv10982 = zext i32 %v10981 to i64
  %cond10983 = icmp ne i64 %cv10982, 0
  br i1 %cond10983, label %bb_rcglast2944, label %bb_rcgdec2944
bb_rcglast2944:
  %v10984 = load i64, ptr %slot1928, align 8
  %op10985 = sub i64 %v10984, 24
  store i64 %op10985, ptr %slot1938, align 8
  %v10986 = load i64, ptr %slot1928, align 8
  %p10987 = inttoptr i64 %v10986 to ptr
  %rgep10988 = getelementptr i8, ptr %p10987, i64 -24
  %ld10989 = load i64, ptr %rgep10988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10989, ptr %slot1939, align 8
  %v10990 = load i64, ptr %slot1939, align 8
  %cmp10991 = icmp ne i64 %v10990, 0
  %cv10992 = zext i1 %cmp10991 to i32
  store i32 %cv10992, ptr %slot1940, align 8
  %v10993 = load i32, ptr %slot1940, align 8
  %cv10994 = zext i32 %v10993 to i64
  %cond10995 = icmp ne i64 %cv10994, 0
  br i1 %cond10995, label %bb_rcgdec2944, label %bb_rcgslow2944
bb_rcgslow2944:
  %v10996 = load i64, ptr %slot1927, align 8
  %v10997 = load i64, ptr %slot1910, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v10996, i64 %v10997) nomerge, !dbg !192
  br label %bb_rcgdone2944
bb_rcgdec2944:
  %v10998 = load i64, ptr %slot1936, align 8
  %v10999 = load i64, ptr %slot1928, align 8
  %p11000 = inttoptr i64 %v10999 to ptr
  %rgep11001 = getelementptr i8, ptr %p11000, i64 -32
  store i64 %v10998, ptr %rgep11001, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2944
bb_rcgclear2944:
  %v11002 = load i64, ptr %slot1910, align 8
  %p11003 = inttoptr i64 %v11002 to ptr
  store i64 0, ptr %p11003, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2944
bb_rcgdone2944:
  br label %bb_rcslotdone2913
bb_rcslotdone2913:
  %v11004 = load i64, ptr %slot42, align 8
  store i64 %v11004, ptr %slot1941, align 8
  %v11005 = load i64, ptr %slot24, align 8
  store i64 %v11005, ptr %slot1942, align 8
  %v11006 = load i64, ptr %slot1942, align 8
  %v11007 = load i64, ptr %slot1941, align 8
  %p11008 = inttoptr i64 %v11006 to ptr
  %p11009 = inttoptr i64 %v11007 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11009, ptr %p11008, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11010 = load i64, ptr %slot19, align 8
  %p11011 = inttoptr i64 %v11010 to ptr
  store i32 0, ptr %p11011, align 4, !alias.scope !3, !noalias !4
  %v11012 = load i64, ptr %slot14, align 8
  %p11013 = inttoptr i64 %v11012 to ptr
  store i32 2, ptr %p11013, align 4, !alias.scope !3, !noalias !4
  %v11014 = load i64, ptr %slot20, align 8
  %p11015 = inttoptr i64 %v11014 to ptr
  %ld11016 = load i32, ptr %p11015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11016, ptr %slot1943, align 8
  %v11017 = load i32, ptr %slot1943, align 8
  %v11018 = load i64, ptr %slot14, align 8
  %p11019 = inttoptr i64 %v11018 to ptr
  store i32 %v11017, ptr %p11019, align 4, !alias.scope !3, !noalias !4
  %v11020 = load i64, ptr %slot13, align 8
  %p11021 = inttoptr i64 %v11020 to ptr
  store i32 1, ptr %p11021, align 4, !alias.scope !3, !noalias !4
  %v11022 = load i64, ptr %slot9, align 8
  %p11023 = inttoptr i64 %v11022 to ptr
  %ld11024 = load i32, ptr %p11023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11024, ptr %slot1944, align 8
  %v11025 = load i32, ptr %slot1944, align 8
  %cv11026 = zext i32 %v11025 to i64
  %cond11027 = icmp ne i64 %cv11026, 0
  br i1 %cond11027, label %bb_rcslotdrop2957, label %bb_rcslotdone2957
bb_rcslotdrop2957:
  %v11028 = load i64, ptr %slot9, align 8
  %p11029 = inttoptr i64 %v11028 to ptr
  store i32 0, ptr %p11029, align 4, !alias.scope !3, !noalias !4
  %v11030 = load i64, ptr %slot40, align 8
  store i64 %v11030, ptr %slot1945, align 8
  %v11031 = load i64, ptr %slot10, align 8
  %p11032 = inttoptr i64 %v11031 to ptr
  %ld11033 = load i32, ptr %p11032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11033, ptr %slot1946, align 8
  %v11034 = load i32, ptr %slot1946, align 8
  %op11035 = and i32 %v11034, 28
  store i32 %op11035, ptr %slot1947, align 8
  %v11036 = load i32, ptr %slot1947, align 8
  %cv11037 = zext i32 %v11036 to i64
  %cond11038 = icmp ne i64 %cv11037, 0
  br i1 %cond11038, label %bb_rcslotrole2957, label %bb_rcslotowner2957
bb_rcslotrole2957:
  %v11039 = load i64, ptr %slot63, align 8
  store i64 %v11039, ptr %slot1948, align 8
  %v11040 = load i64, ptr %slot1945, align 8
  %p11041 = inttoptr i64 %v11040 to ptr
  %ld11042 = load i64, ptr %p11041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11042, ptr %slot1949, align 8
  %v11043 = load i64, ptr %slot1949, align 8
  %cmp11044 = icmp ne i64 %v11043, 0
  %cv11045 = zext i1 %cmp11044 to i32
  store i32 %cv11045, ptr %slot1950, align 8
  %v11046 = load i32, ptr %slot1950, align 8
  %cv11047 = zext i32 %v11046 to i64
  %cond11048 = icmp ne i64 %cv11047, 0
  br i1 %cond11048, label %bb_rcgnn2973, label %bb_rcgdone2973
bb_rcgnn2973:
  %v11049 = load i64, ptr %slot1949, align 8
  %op11050 = sub i64 %v11049, 16
  store i64 %op11050, ptr %slot1951, align 8
  %v11051 = load i64, ptr %slot1949, align 8
  %p11052 = inttoptr i64 %v11051 to ptr
  %rgep11053 = getelementptr i8, ptr %p11052, i64 -16
  %ld11054 = load i64, ptr %rgep11053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11054, ptr %slot1952, align 8
  %v11055 = load i64, ptr %slot1952, align 8
  %op11056 = and i64 %v11055, 4611686018427387906
  store i64 %op11056, ptr %slot1953, align 8
  %v11057 = load i64, ptr %slot1953, align 8
  %cmp11058 = icmp ne i64 %v11057, 0
  %cv11059 = zext i1 %cmp11058 to i32
  store i32 %cv11059, ptr %slot1954, align 8
  %v11060 = load i32, ptr %slot1954, align 8
  %cv11061 = zext i32 %v11060 to i64
  %cond11062 = icmp ne i64 %cv11061, 0
  br i1 %cond11062, label %bb_rcgclear2973, label %bb_rcgcounted2973
bb_rcgcounted2973:
  %v11063 = load i64, ptr %slot1949, align 8
  %op11064 = sub i64 %v11063, 24
  store i64 %op11064, ptr %slot1955, align 8
  %v11065 = load i64, ptr %slot1949, align 8
  %p11066 = inttoptr i64 %v11065 to ptr
  %rgep11067 = getelementptr i8, ptr %p11066, i64 -24
  %ld11068 = load i64, ptr %rgep11067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11068, ptr %slot1956, align 8
  %v11069 = load i64, ptr %slot1956, align 8
  %op11070 = sub i64 %v11069, 1
  store i64 %op11070, ptr %slot1957, align 8
  %v11071 = load i64, ptr %slot1957, align 8
  %cmp11072 = icmp eq i64 %v11071, 0
  %cv11073 = zext i1 %cmp11072 to i32
  store i32 %cv11073, ptr %slot1958, align 8
  %v11074 = load i32, ptr %slot1958, align 8
  %cv11075 = zext i32 %v11074 to i64
  %cond11076 = icmp ne i64 %cv11075, 0
  br i1 %cond11076, label %bb_rcglast2973, label %bb_rcgdec2973
bb_rcglast2973:
  %v11077 = load i64, ptr %slot1949, align 8
  %op11078 = sub i64 %v11077, 32
  store i64 %op11078, ptr %slot1959, align 8
  %v11079 = load i64, ptr %slot1949, align 8
  %p11080 = inttoptr i64 %v11079 to ptr
  %rgep11081 = getelementptr i8, ptr %p11080, i64 -32
  %ld11082 = load i64, ptr %rgep11081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11082, ptr %slot1960, align 8
  %v11083 = load i64, ptr %slot1960, align 8
  %cmp11084 = icmp ne i64 %v11083, 0
  %cv11085 = zext i1 %cmp11084 to i32
  store i32 %cv11085, ptr %slot1961, align 8
  %v11086 = load i32, ptr %slot1961, align 8
  %cv11087 = zext i32 %v11086 to i64
  %cond11088 = icmp ne i64 %cv11087, 0
  br i1 %cond11088, label %bb_rcgdec2973, label %bb_rcgslow2973
bb_rcgslow2973:
  %v11089 = load i64, ptr %slot1948, align 8
  %v11090 = load i64, ptr %slot1945, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v11089, i64 %v11090) nomerge, !dbg !192
  br label %bb_rcgdone2973
bb_rcgdec2973:
  %v11091 = load i64, ptr %slot1957, align 8
  %v11092 = load i64, ptr %slot1949, align 8
  %p11093 = inttoptr i64 %v11092 to ptr
  %rgep11094 = getelementptr i8, ptr %p11093, i64 -24
  store i64 %v11091, ptr %rgep11094, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2973
bb_rcgclear2973:
  %v11095 = load i64, ptr %slot1945, align 8
  %p11096 = inttoptr i64 %v11095 to ptr
  store i64 0, ptr %p11096, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2973
bb_rcgdone2973:
  br label %bb_rcslotdone2957
bb_rcslotowner2957:
  %v11097 = load i64, ptr %slot63, align 8
  store i64 %v11097, ptr %slot1962, align 8
  %v11098 = load i64, ptr %slot1945, align 8
  %p11099 = inttoptr i64 %v11098 to ptr
  %ld11100 = load i64, ptr %p11099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11100, ptr %slot1963, align 8
  %v11101 = load i64, ptr %slot1963, align 8
  %cmp11102 = icmp ne i64 %v11101, 0
  %cv11103 = zext i1 %cmp11102 to i32
  store i32 %cv11103, ptr %slot1964, align 8
  %v11104 = load i32, ptr %slot1964, align 8
  %cv11105 = zext i32 %v11104 to i64
  %cond11106 = icmp ne i64 %cv11105, 0
  br i1 %cond11106, label %bb_rcgnn2988, label %bb_rcgdone2988
bb_rcgnn2988:
  %v11107 = load i64, ptr %slot1963, align 8
  %op11108 = sub i64 %v11107, 16
  store i64 %op11108, ptr %slot1965, align 8
  %v11109 = load i64, ptr %slot1963, align 8
  %p11110 = inttoptr i64 %v11109 to ptr
  %rgep11111 = getelementptr i8, ptr %p11110, i64 -16
  %ld11112 = load i64, ptr %rgep11111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11112, ptr %slot1966, align 8
  %v11113 = load i64, ptr %slot1966, align 8
  %op11114 = and i64 %v11113, 4611686018427387906
  store i64 %op11114, ptr %slot1967, align 8
  %v11115 = load i64, ptr %slot1967, align 8
  %cmp11116 = icmp ne i64 %v11115, 0
  %cv11117 = zext i1 %cmp11116 to i32
  store i32 %cv11117, ptr %slot1968, align 8
  %v11118 = load i32, ptr %slot1968, align 8
  %cv11119 = zext i32 %v11118 to i64
  %cond11120 = icmp ne i64 %cv11119, 0
  br i1 %cond11120, label %bb_rcgclear2988, label %bb_rcgcounted2988
bb_rcgcounted2988:
  %v11121 = load i64, ptr %slot1963, align 8
  %op11122 = sub i64 %v11121, 32
  store i64 %op11122, ptr %slot1969, align 8
  %v11123 = load i64, ptr %slot1963, align 8
  %p11124 = inttoptr i64 %v11123 to ptr
  %rgep11125 = getelementptr i8, ptr %p11124, i64 -32
  %ld11126 = load i64, ptr %rgep11125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11126, ptr %slot1970, align 8
  %v11127 = load i64, ptr %slot1970, align 8
  %op11128 = sub i64 %v11127, 1
  store i64 %op11128, ptr %slot1971, align 8
  %v11129 = load i64, ptr %slot1971, align 8
  %cmp11130 = icmp eq i64 %v11129, 0
  %cv11131 = zext i1 %cmp11130 to i32
  store i32 %cv11131, ptr %slot1972, align 8
  %v11132 = load i32, ptr %slot1972, align 8
  %cv11133 = zext i32 %v11132 to i64
  %cond11134 = icmp ne i64 %cv11133, 0
  br i1 %cond11134, label %bb_rcglast2988, label %bb_rcgdec2988
bb_rcglast2988:
  %v11135 = load i64, ptr %slot1963, align 8
  %op11136 = sub i64 %v11135, 24
  store i64 %op11136, ptr %slot1973, align 8
  %v11137 = load i64, ptr %slot1963, align 8
  %p11138 = inttoptr i64 %v11137 to ptr
  %rgep11139 = getelementptr i8, ptr %p11138, i64 -24
  %ld11140 = load i64, ptr %rgep11139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11140, ptr %slot1974, align 8
  %v11141 = load i64, ptr %slot1974, align 8
  %cmp11142 = icmp ne i64 %v11141, 0
  %cv11143 = zext i1 %cmp11142 to i32
  store i32 %cv11143, ptr %slot1975, align 8
  %v11144 = load i32, ptr %slot1975, align 8
  %cv11145 = zext i32 %v11144 to i64
  %cond11146 = icmp ne i64 %cv11145, 0
  br i1 %cond11146, label %bb_rcgdec2988, label %bb_rcgslow2988
bb_rcgslow2988:
  %v11147 = load i64, ptr %slot1962, align 8
  %v11148 = load i64, ptr %slot1945, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v11147, i64 %v11148) nomerge, !dbg !192
  br label %bb_rcgdone2988
bb_rcgdec2988:
  %v11149 = load i64, ptr %slot1971, align 8
  %v11150 = load i64, ptr %slot1963, align 8
  %p11151 = inttoptr i64 %v11150 to ptr
  %rgep11152 = getelementptr i8, ptr %p11151, i64 -32
  store i64 %v11149, ptr %rgep11152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2988
bb_rcgclear2988:
  %v11153 = load i64, ptr %slot1945, align 8
  %p11154 = inttoptr i64 %v11153 to ptr
  store i64 0, ptr %p11154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2988
bb_rcgdone2988:
  br label %bb_rcslotdone2957
bb_rcslotdone2957:
  %v11155 = load i64, ptr %slot11, align 8
  %p11156 = inttoptr i64 %v11155 to ptr
  %ld11157 = load i32, ptr %p11156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11157, ptr %slot1976, align 8
  %v11158 = load i32, ptr %slot1976, align 8
  %cv11159 = zext i32 %v11158 to i64
  %cond11160 = icmp ne i64 %cv11159, 0
  br i1 %cond11160, label %bb_rcslotdrop2994, label %bb_rcslotdone2994
bb_rcslotdrop2994:
  %v11161 = load i64, ptr %slot11, align 8
  %p11162 = inttoptr i64 %v11161 to ptr
  store i32 0, ptr %p11162, align 4, !alias.scope !3, !noalias !4
  %v11163 = load i64, ptr %slot41, align 8
  store i64 %v11163, ptr %slot1977, align 8
  %v11164 = load i64, ptr %slot12, align 8
  %p11165 = inttoptr i64 %v11164 to ptr
  %ld11166 = load i32, ptr %p11165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11166, ptr %slot1978, align 8
  %v11167 = load i32, ptr %slot1978, align 8
  %op11168 = and i32 %v11167, 28
  store i32 %op11168, ptr %slot1979, align 8
  %v11169 = load i32, ptr %slot1979, align 8
  %cv11170 = zext i32 %v11169 to i64
  %cond11171 = icmp ne i64 %cv11170, 0
  br i1 %cond11171, label %bb_rcslotrole2994, label %bb_rcslotowner2994
bb_rcslotrole2994:
  %v11172 = load i64, ptr %slot63, align 8
  store i64 %v11172, ptr %slot1980, align 8
  %v11173 = load i64, ptr %slot1977, align 8
  %p11174 = inttoptr i64 %v11173 to ptr
  %ld11175 = load i64, ptr %p11174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11175, ptr %slot1981, align 8
  %v11176 = load i64, ptr %slot1981, align 8
  %cmp11177 = icmp ne i64 %v11176, 0
  %cv11178 = zext i1 %cmp11177 to i32
  store i32 %cv11178, ptr %slot1982, align 8
  %v11179 = load i32, ptr %slot1982, align 8
  %cv11180 = zext i32 %v11179 to i64
  %cond11181 = icmp ne i64 %cv11180, 0
  br i1 %cond11181, label %bb_rcgnn3010, label %bb_rcgdone3010
bb_rcgnn3010:
  %v11182 = load i64, ptr %slot1981, align 8
  %op11183 = sub i64 %v11182, 16
  store i64 %op11183, ptr %slot1983, align 8
  %v11184 = load i64, ptr %slot1981, align 8
  %p11185 = inttoptr i64 %v11184 to ptr
  %rgep11186 = getelementptr i8, ptr %p11185, i64 -16
  %ld11187 = load i64, ptr %rgep11186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11187, ptr %slot1984, align 8
  %v11188 = load i64, ptr %slot1984, align 8
  %op11189 = and i64 %v11188, 4611686018427387906
  store i64 %op11189, ptr %slot1985, align 8
  %v11190 = load i64, ptr %slot1985, align 8
  %cmp11191 = icmp ne i64 %v11190, 0
  %cv11192 = zext i1 %cmp11191 to i32
  store i32 %cv11192, ptr %slot1986, align 8
  %v11193 = load i32, ptr %slot1986, align 8
  %cv11194 = zext i32 %v11193 to i64
  %cond11195 = icmp ne i64 %cv11194, 0
  br i1 %cond11195, label %bb_rcgclear3010, label %bb_rcgcounted3010
bb_rcgcounted3010:
  %v11196 = load i64, ptr %slot1981, align 8
  %op11197 = sub i64 %v11196, 24
  store i64 %op11197, ptr %slot1987, align 8
  %v11198 = load i64, ptr %slot1981, align 8
  %p11199 = inttoptr i64 %v11198 to ptr
  %rgep11200 = getelementptr i8, ptr %p11199, i64 -24
  %ld11201 = load i64, ptr %rgep11200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11201, ptr %slot1988, align 8
  %v11202 = load i64, ptr %slot1988, align 8
  %op11203 = sub i64 %v11202, 1
  store i64 %op11203, ptr %slot1989, align 8
  %v11204 = load i64, ptr %slot1989, align 8
  %cmp11205 = icmp eq i64 %v11204, 0
  %cv11206 = zext i1 %cmp11205 to i32
  store i32 %cv11206, ptr %slot1990, align 8
  %v11207 = load i32, ptr %slot1990, align 8
  %cv11208 = zext i32 %v11207 to i64
  %cond11209 = icmp ne i64 %cv11208, 0
  br i1 %cond11209, label %bb_rcglast3010, label %bb_rcgdec3010
bb_rcglast3010:
  %v11210 = load i64, ptr %slot1981, align 8
  %op11211 = sub i64 %v11210, 32
  store i64 %op11211, ptr %slot1991, align 8
  %v11212 = load i64, ptr %slot1981, align 8
  %p11213 = inttoptr i64 %v11212 to ptr
  %rgep11214 = getelementptr i8, ptr %p11213, i64 -32
  %ld11215 = load i64, ptr %rgep11214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11215, ptr %slot1992, align 8
  %v11216 = load i64, ptr %slot1992, align 8
  %cmp11217 = icmp ne i64 %v11216, 0
  %cv11218 = zext i1 %cmp11217 to i32
  store i32 %cv11218, ptr %slot1993, align 8
  %v11219 = load i32, ptr %slot1993, align 8
  %cv11220 = zext i32 %v11219 to i64
  %cond11221 = icmp ne i64 %cv11220, 0
  br i1 %cond11221, label %bb_rcgdec3010, label %bb_rcgslow3010
bb_rcgslow3010:
  %v11222 = load i64, ptr %slot1980, align 8
  %v11223 = load i64, ptr %slot1977, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v11222, i64 %v11223) nomerge, !dbg !192
  br label %bb_rcgdone3010
bb_rcgdec3010:
  %v11224 = load i64, ptr %slot1989, align 8
  %v11225 = load i64, ptr %slot1981, align 8
  %p11226 = inttoptr i64 %v11225 to ptr
  %rgep11227 = getelementptr i8, ptr %p11226, i64 -24
  store i64 %v11224, ptr %rgep11227, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3010
bb_rcgclear3010:
  %v11228 = load i64, ptr %slot1977, align 8
  %p11229 = inttoptr i64 %v11228 to ptr
  store i64 0, ptr %p11229, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3010
bb_rcgdone3010:
  br label %bb_rcslotdone2994
bb_rcslotowner2994:
  %v11230 = load i64, ptr %slot63, align 8
  store i64 %v11230, ptr %slot1994, align 8
  %v11231 = load i64, ptr %slot1977, align 8
  %p11232 = inttoptr i64 %v11231 to ptr
  %ld11233 = load i64, ptr %p11232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11233, ptr %slot1995, align 8
  %v11234 = load i64, ptr %slot1995, align 8
  %cmp11235 = icmp ne i64 %v11234, 0
  %cv11236 = zext i1 %cmp11235 to i32
  store i32 %cv11236, ptr %slot1996, align 8
  %v11237 = load i32, ptr %slot1996, align 8
  %cv11238 = zext i32 %v11237 to i64
  %cond11239 = icmp ne i64 %cv11238, 0
  br i1 %cond11239, label %bb_rcgnn3025, label %bb_rcgdone3025
bb_rcgnn3025:
  %v11240 = load i64, ptr %slot1995, align 8
  %op11241 = sub i64 %v11240, 16
  store i64 %op11241, ptr %slot1997, align 8
  %v11242 = load i64, ptr %slot1995, align 8
  %p11243 = inttoptr i64 %v11242 to ptr
  %rgep11244 = getelementptr i8, ptr %p11243, i64 -16
  %ld11245 = load i64, ptr %rgep11244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11245, ptr %slot1998, align 8
  %v11246 = load i64, ptr %slot1998, align 8
  %op11247 = and i64 %v11246, 4611686018427387906
  store i64 %op11247, ptr %slot1999, align 8
  %v11248 = load i64, ptr %slot1999, align 8
  %cmp11249 = icmp ne i64 %v11248, 0
  %cv11250 = zext i1 %cmp11249 to i32
  store i32 %cv11250, ptr %slot2000, align 8
  %v11251 = load i32, ptr %slot2000, align 8
  %cv11252 = zext i32 %v11251 to i64
  %cond11253 = icmp ne i64 %cv11252, 0
  br i1 %cond11253, label %bb_rcgclear3025, label %bb_rcgcounted3025
bb_rcgcounted3025:
  %v11254 = load i64, ptr %slot1995, align 8
  %op11255 = sub i64 %v11254, 32
  store i64 %op11255, ptr %slot2001, align 8
  %v11256 = load i64, ptr %slot1995, align 8
  %p11257 = inttoptr i64 %v11256 to ptr
  %rgep11258 = getelementptr i8, ptr %p11257, i64 -32
  %ld11259 = load i64, ptr %rgep11258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11259, ptr %slot2002, align 8
  %v11260 = load i64, ptr %slot2002, align 8
  %op11261 = sub i64 %v11260, 1
  store i64 %op11261, ptr %slot2003, align 8
  %v11262 = load i64, ptr %slot2003, align 8
  %cmp11263 = icmp eq i64 %v11262, 0
  %cv11264 = zext i1 %cmp11263 to i32
  store i32 %cv11264, ptr %slot2004, align 8
  %v11265 = load i32, ptr %slot2004, align 8
  %cv11266 = zext i32 %v11265 to i64
  %cond11267 = icmp ne i64 %cv11266, 0
  br i1 %cond11267, label %bb_rcglast3025, label %bb_rcgdec3025
bb_rcglast3025:
  %v11268 = load i64, ptr %slot1995, align 8
  %op11269 = sub i64 %v11268, 24
  store i64 %op11269, ptr %slot2005, align 8
  %v11270 = load i64, ptr %slot1995, align 8
  %p11271 = inttoptr i64 %v11270 to ptr
  %rgep11272 = getelementptr i8, ptr %p11271, i64 -24
  %ld11273 = load i64, ptr %rgep11272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11273, ptr %slot2006, align 8
  %v11274 = load i64, ptr %slot2006, align 8
  %cmp11275 = icmp ne i64 %v11274, 0
  %cv11276 = zext i1 %cmp11275 to i32
  store i32 %cv11276, ptr %slot2007, align 8
  %v11277 = load i32, ptr %slot2007, align 8
  %cv11278 = zext i32 %v11277 to i64
  %cond11279 = icmp ne i64 %cv11278, 0
  br i1 %cond11279, label %bb_rcgdec3025, label %bb_rcgslow3025
bb_rcgslow3025:
  %v11280 = load i64, ptr %slot1994, align 8
  %v11281 = load i64, ptr %slot1977, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v11280, i64 %v11281) nomerge, !dbg !192
  br label %bb_rcgdone3025
bb_rcgdec3025:
  %v11282 = load i64, ptr %slot2003, align 8
  %v11283 = load i64, ptr %slot1995, align 8
  %p11284 = inttoptr i64 %v11283 to ptr
  %rgep11285 = getelementptr i8, ptr %p11284, i64 -32
  store i64 %v11282, ptr %rgep11285, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3025
bb_rcgclear3025:
  %v11286 = load i64, ptr %slot1977, align 8
  %p11287 = inttoptr i64 %v11286 to ptr
  store i64 0, ptr %p11287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3025
bb_rcgdone3025:
  br label %bb_rcslotdone2994
bb_rcslotdone2994:
  %v11288 = load i64, ptr %slot42, align 8
  %p11289 = inttoptr i64 %v11288 to ptr
  %ld11290 = load i64, ptr %p11289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11290, ptr %slot2008, align 8
  %v11291 = load i64, ptr %slot42, align 8
  %p11292 = inttoptr i64 %v11291 to ptr
  %ld11293 = load i64, ptr %p11292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11293, ptr %slot2009, align 8
  %v11294 = load i64, ptr %slot63, align 8
  %p11295 = inttoptr i64 %v11294 to ptr
  %v11296 = load i64, ptr %slot2009, align 8
  %p11297 = inttoptr i64 %v11296 to ptr
  %call11298 = call ptr @myl_native_bytes_encode(ptr %p11295, ptr %p11297) nomerge, !dbg !194
  %calladdr11299 = ptrtoint ptr %call11298 to i64
  store i64 %calladdr11299, ptr %slot2010, align 8
  %v11300 = load i64, ptr %slot2010, align 8
  %cond11301 = icmp ne i64 %v11300, 0
  br i1 %cond11301, label %bb_success3033, label %bb_failed3033
bb_failed3033:
  %v11302 = load i64, ptr %slot1, align 8
  %p11303 = inttoptr i64 %v11302 to ptr
  call void @myl_qbe_fail_allocation(ptr %p11303) nomerge, !dbg !194
  unreachable
bb_success3033:
  %v11304 = load i64, ptr %slot2010, align 8
  %v11305 = load i64, ptr %slot44, align 8
  %p11306 = inttoptr i64 %v11305 to ptr
  store i64 %v11304, ptr %p11306, align 8, !alias.scope !3, !noalias !4
  %v11307 = load i64, ptr %slot44, align 8
  %p11308 = inttoptr i64 %v11307 to ptr
  %ld11309 = load i64, ptr %p11308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11309, ptr %slot2011, align 8
  %v11310 = load i64, ptr %slot2011, align 8
  %v11311 = load i64, ptr %slot23, align 8
  %p11312 = inttoptr i64 %v11311 to ptr
  store i64 %v11310, ptr %p11312, align 8, !alias.scope !3, !noalias !4
  %v11313 = load i64, ptr %slot23, align 8
  store i64 %v11313, ptr %slot2012, align 8
  %v11314 = load i64, ptr %slot24, align 8
  store i64 %v11314, ptr %slot2013, align 8
  %v11315 = load i64, ptr %slot2012, align 8
  %v11316 = load i64, ptr %slot2013, align 8
  %p11317 = inttoptr i64 %v11315 to ptr
  %p11318 = inttoptr i64 %v11316 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11318, ptr %p11317, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11319 = load i64, ptr %slot20, align 8
  %p11320 = inttoptr i64 %v11319 to ptr
  store i32 2, ptr %p11320, align 4, !alias.scope !3, !noalias !4
  %v11321 = load i64, ptr %slot19, align 8
  %p11322 = inttoptr i64 %v11321 to ptr
  store i32 1, ptr %p11322, align 4, !alias.scope !3, !noalias !4
  %v11323 = load i64, ptr %slot22, align 8
  store i64 %v11323, ptr %slot2014, align 8
  %v11324 = load i64, ptr %slot24, align 8
  store i64 %v11324, ptr %slot2015, align 8
  %v11325 = load i64, ptr %slot2015, align 8
  %v11326 = load i64, ptr %slot2014, align 8
  %p11327 = inttoptr i64 %v11325 to ptr
  %p11328 = inttoptr i64 %v11326 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11328, ptr %p11327, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11329 = load i64, ptr %slot18, align 8
  %p11330 = inttoptr i64 %v11329 to ptr
  store i32 2, ptr %p11330, align 4, !alias.scope !3, !noalias !4
  %v11331 = load i64, ptr %slot20, align 8
  %p11332 = inttoptr i64 %v11331 to ptr
  %ld11333 = load i32, ptr %p11332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11333, ptr %slot2016, align 8
  %v11334 = load i32, ptr %slot2016, align 8
  %v11335 = load i64, ptr %slot18, align 8
  %p11336 = inttoptr i64 %v11335 to ptr
  store i32 %v11334, ptr %p11336, align 4, !alias.scope !3, !noalias !4
  %v11337 = load i64, ptr %slot19, align 8
  %p11338 = inttoptr i64 %v11337 to ptr
  store i32 0, ptr %p11338, align 4, !alias.scope !3, !noalias !4
  %v11339 = load i64, ptr %slot17, align 8
  %p11340 = inttoptr i64 %v11339 to ptr
  store i32 1, ptr %p11340, align 4, !alias.scope !3, !noalias !4
  %v11341 = load i64, ptr %slot2014, align 8
  %p11342 = inttoptr i64 %v11341 to ptr
  %ld11343 = load i64, ptr %p11342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11343, ptr %slot2017, align 8
  %v11344 = load i64, ptr %slot2017, align 8
  %v11345 = load i64, ptr %slot44, align 8
  %p11346 = inttoptr i64 %v11345 to ptr
  store i64 %v11344, ptr %p11346, align 8, !alias.scope !3, !noalias !4
  %v11347 = load i64, ptr %slot28, align 8
  %p11348 = inttoptr i64 %v11347 to ptr
  %ld11349 = load i64, ptr %p11348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11349, ptr %slot2018, align 8
  %v11350 = load i64, ptr %slot2018, align 8
  %v11351 = load i64, ptr %slot45, align 8
  %p11352 = inttoptr i64 %v11351 to ptr
  store i64 %v11350, ptr %p11352, align 8, !alias.scope !3, !noalias !4
  %v11353 = load i64, ptr %slot44, align 8
  %p11354 = inttoptr i64 %v11353 to ptr
  %ld11355 = load i64, ptr %p11354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11355, ptr %slot2019, align 8
  %v11356 = load i64, ptr %slot45, align 8
  %p11357 = inttoptr i64 %v11356 to ptr
  %ld11358 = load i64, ptr %p11357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11358, ptr %slot2020, align 8
  %v11359 = load i64, ptr %slot1, align 8
  %v11360 = load i64, ptr %slot2019, align 8
  %v11361 = load i64, ptr %slot2020, align 8
  %call11362 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v11359, i64 %v11360, i64 %v11361) nomerge, !dbg !196
  store { i64, i64 } %call11362, ptr %callresult2022, align 8
  %addr11363 = ptrtoint ptr %callresult2022 to i64
  store i64 %addr11363, ptr %slot2021, align 8
  %v11364 = load i64, ptr %slot2021, align 8
  %v11365 = load i64, ptr %slot44, align 8
  %p11366 = inttoptr i64 %v11365 to ptr
  store i64 %v11364, ptr %p11366, align 8, !alias.scope !3, !noalias !4
  %v11367 = load i64, ptr %slot44, align 8
  %p11368 = inttoptr i64 %v11367 to ptr
  %ld11369 = load i64, ptr %p11368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11369, ptr %slot2023, align 8
  %v11370 = load i64, ptr %slot24, align 8
  store i64 %v11370, ptr %slot2024, align 8
  %v11371 = load i64, ptr %slot63, align 8
  %v11372 = load i64, ptr %slot2024, align 8
  %v11373 = load i64, ptr %slot2023, align 8
  %call11374 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v11371, i64 %v11372, i64 %v11373) nomerge, !dbg !196
  store i32 %call11374, ptr %slot2025, align 8
  %v11375 = load i32, ptr %slot2025, align 8
  %cv11376 = zext i32 %v11375 to i64
  %cond11377 = icmp ne i64 %cv11376, 0
  br i1 %cond11377, label %bb_rcsuccess3055, label %bb_rcfailure3055
bb_rcfailure3055:
  %v11378 = load i64, ptr %slot63, align 8
  %p11379 = inttoptr i64 %v11378 to ptr
  %call11380 = call i32 @myl_rc_take_failure(ptr %p11379) nomerge, !dbg !196
  store i32 %call11380, ptr %slot2026, align 8
  %v11381 = load i64, ptr %slot1, align 8
  %p11382 = inttoptr i64 %v11381 to ptr
  %v11383 = load i32, ptr %slot2026, align 8
  %call11384 = call i32 @myl_qbe_rc_status(ptr %p11382, i32 %v11383) nomerge, !dbg !196
  store i32 %call11384, ptr %slot2027, align 8
  br label %bb_failure
bb_rcsuccess3055:
  %v11385 = load i64, ptr %slot20, align 8
  %p11386 = inttoptr i64 %v11385 to ptr
  store i32 2, ptr %p11386, align 4, !alias.scope !3, !noalias !4
  %v11387 = load i64, ptr %slot20, align 8
  %p11388 = inttoptr i64 %v11387 to ptr
  store i32 16, ptr %p11388, align 4, !alias.scope !3, !noalias !4
  %v11389 = load i64, ptr %slot19, align 8
  %p11390 = inttoptr i64 %v11389 to ptr
  store i32 1, ptr %p11390, align 4, !alias.scope !3, !noalias !4
  %v11391 = load i64, ptr %slot17, align 8
  %p11392 = inttoptr i64 %v11391 to ptr
  %ld11393 = load i32, ptr %p11392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11393, ptr %slot2028, align 8
  %v11394 = load i32, ptr %slot2028, align 8
  %cv11395 = zext i32 %v11394 to i64
  %cond11396 = icmp ne i64 %cv11395, 0
  br i1 %cond11396, label %bb_rcslotdrop3063, label %bb_rcslotdone3063
bb_rcslotdrop3063:
  %v11397 = load i64, ptr %slot17, align 8
  %p11398 = inttoptr i64 %v11397 to ptr
  store i32 0, ptr %p11398, align 4, !alias.scope !3, !noalias !4
  %v11399 = load i64, ptr %slot22, align 8
  store i64 %v11399, ptr %slot2029, align 8
  %v11400 = load i64, ptr %slot18, align 8
  %p11401 = inttoptr i64 %v11400 to ptr
  %ld11402 = load i32, ptr %p11401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11402, ptr %slot2030, align 8
  %v11403 = load i32, ptr %slot2030, align 8
  %op11404 = and i32 %v11403, 28
  store i32 %op11404, ptr %slot2031, align 8
  %v11405 = load i32, ptr %slot2031, align 8
  %cv11406 = zext i32 %v11405 to i64
  %cond11407 = icmp ne i64 %cv11406, 0
  br i1 %cond11407, label %bb_rcslotrole3063, label %bb_rcslotowner3063
bb_rcslotrole3063:
  %v11408 = load i64, ptr %slot63, align 8
  store i64 %v11408, ptr %slot2032, align 8
  %v11409 = load i64, ptr %slot2029, align 8
  %p11410 = inttoptr i64 %v11409 to ptr
  %ld11411 = load i64, ptr %p11410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11411, ptr %slot2033, align 8
  %v11412 = load i64, ptr %slot2033, align 8
  %cmp11413 = icmp ne i64 %v11412, 0
  %cv11414 = zext i1 %cmp11413 to i32
  store i32 %cv11414, ptr %slot2034, align 8
  %v11415 = load i32, ptr %slot2034, align 8
  %cv11416 = zext i32 %v11415 to i64
  %cond11417 = icmp ne i64 %cv11416, 0
  br i1 %cond11417, label %bb_rcgnn3079, label %bb_rcgdone3079
bb_rcgnn3079:
  %v11418 = load i64, ptr %slot2033, align 8
  %op11419 = sub i64 %v11418, 16
  store i64 %op11419, ptr %slot2035, align 8
  %v11420 = load i64, ptr %slot2033, align 8
  %p11421 = inttoptr i64 %v11420 to ptr
  %rgep11422 = getelementptr i8, ptr %p11421, i64 -16
  %ld11423 = load i64, ptr %rgep11422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11423, ptr %slot2036, align 8
  %v11424 = load i64, ptr %slot2036, align 8
  %op11425 = and i64 %v11424, 4611686018427387906
  store i64 %op11425, ptr %slot2037, align 8
  %v11426 = load i64, ptr %slot2037, align 8
  %cmp11427 = icmp ne i64 %v11426, 0
  %cv11428 = zext i1 %cmp11427 to i32
  store i32 %cv11428, ptr %slot2038, align 8
  %v11429 = load i32, ptr %slot2038, align 8
  %cv11430 = zext i32 %v11429 to i64
  %cond11431 = icmp ne i64 %cv11430, 0
  br i1 %cond11431, label %bb_rcgclear3079, label %bb_rcgcounted3079
bb_rcgcounted3079:
  %v11432 = load i64, ptr %slot2033, align 8
  %op11433 = sub i64 %v11432, 24
  store i64 %op11433, ptr %slot2039, align 8
  %v11434 = load i64, ptr %slot2033, align 8
  %p11435 = inttoptr i64 %v11434 to ptr
  %rgep11436 = getelementptr i8, ptr %p11435, i64 -24
  %ld11437 = load i64, ptr %rgep11436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11437, ptr %slot2040, align 8
  %v11438 = load i64, ptr %slot2040, align 8
  %op11439 = sub i64 %v11438, 1
  store i64 %op11439, ptr %slot2041, align 8
  %v11440 = load i64, ptr %slot2041, align 8
  %cmp11441 = icmp eq i64 %v11440, 0
  %cv11442 = zext i1 %cmp11441 to i32
  store i32 %cv11442, ptr %slot2042, align 8
  %v11443 = load i32, ptr %slot2042, align 8
  %cv11444 = zext i32 %v11443 to i64
  %cond11445 = icmp ne i64 %cv11444, 0
  br i1 %cond11445, label %bb_rcglast3079, label %bb_rcgdec3079
bb_rcglast3079:
  %v11446 = load i64, ptr %slot2033, align 8
  %op11447 = sub i64 %v11446, 32
  store i64 %op11447, ptr %slot2043, align 8
  %v11448 = load i64, ptr %slot2033, align 8
  %p11449 = inttoptr i64 %v11448 to ptr
  %rgep11450 = getelementptr i8, ptr %p11449, i64 -32
  %ld11451 = load i64, ptr %rgep11450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11451, ptr %slot2044, align 8
  %v11452 = load i64, ptr %slot2044, align 8
  %cmp11453 = icmp ne i64 %v11452, 0
  %cv11454 = zext i1 %cmp11453 to i32
  store i32 %cv11454, ptr %slot2045, align 8
  %v11455 = load i32, ptr %slot2045, align 8
  %cv11456 = zext i32 %v11455 to i64
  %cond11457 = icmp ne i64 %cv11456, 0
  br i1 %cond11457, label %bb_rcgdec3079, label %bb_rcgslow3079
bb_rcgslow3079:
  %v11458 = load i64, ptr %slot2032, align 8
  %v11459 = load i64, ptr %slot2029, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11458, i64 %v11459) nomerge, !dbg !196
  br label %bb_rcgdone3079
bb_rcgdec3079:
  %v11460 = load i64, ptr %slot2041, align 8
  %v11461 = load i64, ptr %slot2033, align 8
  %p11462 = inttoptr i64 %v11461 to ptr
  %rgep11463 = getelementptr i8, ptr %p11462, i64 -24
  store i64 %v11460, ptr %rgep11463, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3079
bb_rcgclear3079:
  %v11464 = load i64, ptr %slot2029, align 8
  %p11465 = inttoptr i64 %v11464 to ptr
  store i64 0, ptr %p11465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3079
bb_rcgdone3079:
  br label %bb_rcslotdone3063
bb_rcslotowner3063:
  %v11466 = load i64, ptr %slot63, align 8
  store i64 %v11466, ptr %slot2046, align 8
  %v11467 = load i64, ptr %slot2029, align 8
  %p11468 = inttoptr i64 %v11467 to ptr
  %ld11469 = load i64, ptr %p11468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11469, ptr %slot2047, align 8
  %v11470 = load i64, ptr %slot2047, align 8
  %cmp11471 = icmp ne i64 %v11470, 0
  %cv11472 = zext i1 %cmp11471 to i32
  store i32 %cv11472, ptr %slot2048, align 8
  %v11473 = load i32, ptr %slot2048, align 8
  %cv11474 = zext i32 %v11473 to i64
  %cond11475 = icmp ne i64 %cv11474, 0
  br i1 %cond11475, label %bb_rcgnn3094, label %bb_rcgdone3094
bb_rcgnn3094:
  %v11476 = load i64, ptr %slot2047, align 8
  %op11477 = sub i64 %v11476, 16
  store i64 %op11477, ptr %slot2049, align 8
  %v11478 = load i64, ptr %slot2047, align 8
  %p11479 = inttoptr i64 %v11478 to ptr
  %rgep11480 = getelementptr i8, ptr %p11479, i64 -16
  %ld11481 = load i64, ptr %rgep11480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11481, ptr %slot2050, align 8
  %v11482 = load i64, ptr %slot2050, align 8
  %op11483 = and i64 %v11482, 4611686018427387906
  store i64 %op11483, ptr %slot2051, align 8
  %v11484 = load i64, ptr %slot2051, align 8
  %cmp11485 = icmp ne i64 %v11484, 0
  %cv11486 = zext i1 %cmp11485 to i32
  store i32 %cv11486, ptr %slot2052, align 8
  %v11487 = load i32, ptr %slot2052, align 8
  %cv11488 = zext i32 %v11487 to i64
  %cond11489 = icmp ne i64 %cv11488, 0
  br i1 %cond11489, label %bb_rcgclear3094, label %bb_rcgcounted3094
bb_rcgcounted3094:
  %v11490 = load i64, ptr %slot2047, align 8
  %op11491 = sub i64 %v11490, 32
  store i64 %op11491, ptr %slot2053, align 8
  %v11492 = load i64, ptr %slot2047, align 8
  %p11493 = inttoptr i64 %v11492 to ptr
  %rgep11494 = getelementptr i8, ptr %p11493, i64 -32
  %ld11495 = load i64, ptr %rgep11494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11495, ptr %slot2054, align 8
  %v11496 = load i64, ptr %slot2054, align 8
  %op11497 = sub i64 %v11496, 1
  store i64 %op11497, ptr %slot2055, align 8
  %v11498 = load i64, ptr %slot2055, align 8
  %cmp11499 = icmp eq i64 %v11498, 0
  %cv11500 = zext i1 %cmp11499 to i32
  store i32 %cv11500, ptr %slot2056, align 8
  %v11501 = load i32, ptr %slot2056, align 8
  %cv11502 = zext i32 %v11501 to i64
  %cond11503 = icmp ne i64 %cv11502, 0
  br i1 %cond11503, label %bb_rcglast3094, label %bb_rcgdec3094
bb_rcglast3094:
  %v11504 = load i64, ptr %slot2047, align 8
  %op11505 = sub i64 %v11504, 24
  store i64 %op11505, ptr %slot2057, align 8
  %v11506 = load i64, ptr %slot2047, align 8
  %p11507 = inttoptr i64 %v11506 to ptr
  %rgep11508 = getelementptr i8, ptr %p11507, i64 -24
  %ld11509 = load i64, ptr %rgep11508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11509, ptr %slot2058, align 8
  %v11510 = load i64, ptr %slot2058, align 8
  %cmp11511 = icmp ne i64 %v11510, 0
  %cv11512 = zext i1 %cmp11511 to i32
  store i32 %cv11512, ptr %slot2059, align 8
  %v11513 = load i32, ptr %slot2059, align 8
  %cv11514 = zext i32 %v11513 to i64
  %cond11515 = icmp ne i64 %cv11514, 0
  br i1 %cond11515, label %bb_rcgdec3094, label %bb_rcgslow3094
bb_rcgslow3094:
  %v11516 = load i64, ptr %slot2046, align 8
  %v11517 = load i64, ptr %slot2029, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11516, i64 %v11517) nomerge, !dbg !196
  br label %bb_rcgdone3094
bb_rcgdec3094:
  %v11518 = load i64, ptr %slot2055, align 8
  %v11519 = load i64, ptr %slot2047, align 8
  %p11520 = inttoptr i64 %v11519 to ptr
  %rgep11521 = getelementptr i8, ptr %p11520, i64 -32
  store i64 %v11518, ptr %rgep11521, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3094
bb_rcgclear3094:
  %v11522 = load i64, ptr %slot2029, align 8
  %p11523 = inttoptr i64 %v11522 to ptr
  store i64 0, ptr %p11523, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3094
bb_rcgdone3094:
  br label %bb_rcslotdone3063
bb_rcslotdone3063:
  %v11524 = load i64, ptr %slot22, align 8
  store i64 %v11524, ptr %slot2060, align 8
  %v11525 = load i64, ptr %slot24, align 8
  store i64 %v11525, ptr %slot2061, align 8
  %v11526 = load i64, ptr %slot2061, align 8
  %v11527 = load i64, ptr %slot2060, align 8
  %p11528 = inttoptr i64 %v11526 to ptr
  %p11529 = inttoptr i64 %v11527 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11529, ptr %p11528, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11530 = load i64, ptr %slot18, align 8
  %p11531 = inttoptr i64 %v11530 to ptr
  store i32 2, ptr %p11531, align 4, !alias.scope !3, !noalias !4
  %v11532 = load i64, ptr %slot20, align 8
  %p11533 = inttoptr i64 %v11532 to ptr
  %ld11534 = load i32, ptr %p11533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11534, ptr %slot2062, align 8
  %v11535 = load i32, ptr %slot2062, align 8
  %v11536 = load i64, ptr %slot18, align 8
  %p11537 = inttoptr i64 %v11536 to ptr
  store i32 %v11535, ptr %p11537, align 4, !alias.scope !3, !noalias !4
  %v11538 = load i64, ptr %slot19, align 8
  %p11539 = inttoptr i64 %v11538 to ptr
  store i32 0, ptr %p11539, align 4, !alias.scope !3, !noalias !4
  %v11540 = load i64, ptr %slot17, align 8
  %p11541 = inttoptr i64 %v11540 to ptr
  store i32 1, ptr %p11541, align 4, !alias.scope !3, !noalias !4
  %v11542 = load i64, ptr %slot2060, align 8
  %v11543 = load i64, ptr %slot44, align 8
  %p11544 = inttoptr i64 %v11543 to ptr
  store i64 %v11542, ptr %p11544, align 8, !alias.scope !3, !noalias !4
  %v11545 = load i64, ptr %slot54, align 8
  store i64 %v11545, ptr %slot2063, align 8
  %v11546 = load i64, ptr %slot2063, align 8
  %p11547 = inttoptr i64 %v11546 to ptr
  store i64 0, ptr %p11547, align 8, !alias.scope !3, !noalias !4
  %v11548 = load i64, ptr %slot2063, align 8
  %p11550 = inttoptr i64 %v11548 to ptr
  %gep11551 = getelementptr i8, ptr %p11550, i64 8
  %op11549 = ptrtoint ptr %gep11551 to i64
  store i64 %op11549, ptr %slot2064, align 8
  %v11552 = load i64, ptr %slot2064, align 8
  %p11553 = inttoptr i64 %v11552 to ptr
  store i64 0, ptr %p11553, align 8, !alias.scope !3, !noalias !4
  %v11554 = load i64, ptr %slot2063, align 8
  %p11556 = inttoptr i64 %v11554 to ptr
  %gep11557 = getelementptr i8, ptr %p11556, i64 16
  %op11555 = ptrtoint ptr %gep11557 to i64
  store i64 %op11555, ptr %slot2065, align 8
  %v11558 = load i64, ptr %slot2065, align 8
  %p11559 = inttoptr i64 %v11558 to ptr
  store i64 0, ptr %p11559, align 8, !alias.scope !3, !noalias !4
  %v11560 = load i64, ptr %slot2063, align 8
  %p11561 = inttoptr i64 %v11560 to ptr
  store i32 1, ptr %p11561, align 4, !alias.scope !3, !noalias !4
  %v11562 = load i64, ptr %slot21, align 8
  %p11563 = inttoptr i64 %v11562 to ptr
  store i32 1, ptr %p11563, align 4, !alias.scope !3, !noalias !4
  %v11564 = load i64, ptr %slot44, align 8
  %p11565 = inttoptr i64 %v11564 to ptr
  %ld11566 = load i64, ptr %p11565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11566, ptr %slot2066, align 8
  %v11567 = load i64, ptr %slot2063, align 8
  %p11569 = inttoptr i64 %v11567 to ptr
  %gep11570 = getelementptr i8, ptr %p11569, i64 8
  %op11568 = ptrtoint ptr %gep11570 to i64
  store i64 %op11568, ptr %slot2067, align 8
  %v11571 = load i64, ptr %slot64, align 8
  store i64 %v11571, ptr %slot2068, align 8
  %v11572 = load i64, ptr %slot44, align 8
  %p11573 = inttoptr i64 %v11572 to ptr
  %ld11574 = load i64, ptr %p11573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11574, ptr %slot2069, align 8
  %v11575 = load i64, ptr %slot17, align 8
  %p11576 = inttoptr i64 %v11575 to ptr
  %ld11577 = load i32, ptr %p11576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11577, ptr %slot2070, align 8
  %v11578 = load i64, ptr %slot18, align 8
  %p11579 = inttoptr i64 %v11578 to ptr
  %ld11580 = load i32, ptr %p11579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11580, ptr %slot2071, align 8
  %v11581 = load i32, ptr %slot2071, align 8
  %op11582 = and i32 %v11581, 24
  store i32 %op11582, ptr %slot2071, align 8
  %v11583 = load i32, ptr %slot2071, align 8
  %cmp11584 = icmp eq i32 %v11583, 0
  %cv11585 = zext i1 %cmp11584 to i32
  store i32 %cv11585, ptr %slot2072, align 8
  %v11586 = load i32, ptr %slot2070, align 8
  %v11587 = load i32, ptr %slot2072, align 8
  %op11588 = and i32 %v11586, %v11587
  store i32 %op11588, ptr %slot2073, align 8
  %v11589 = load i32, ptr %slot2073, align 8
  %cv11590 = zext i32 %v11589 to i64
  %cond11591 = icmp ne i64 %cv11590, 0
  br i1 %cond11591, label %bb_rctake3115, label %bb_rccopy3115
bb_rctake3115:
  %v11592 = load i64, ptr %slot24, align 8
  store i64 %v11592, ptr %slot2074, align 8
  %v11593 = load i64, ptr %slot64, align 8
  store i64 %v11593, ptr %slot2075, align 8
  %v11594 = load i64, ptr %slot2069, align 8
  %v11595 = load i64, ptr %slot2074, align 8
  %op11596 = sub i64 %v11594, %v11595
  store i64 %op11596, ptr %slot2076, align 8
  %v11597 = load i64, ptr %slot2074, align 8
  %v11598 = load i64, ptr %slot2069, align 8
  %op11599 = sub i64 %v11597, %v11598
  store i64 %op11599, ptr %slot2077, align 8
  %v11600 = load i64, ptr %slot2076, align 8
  %cmp11601 = icmp ult i64 %v11600, 16
  %cv11602 = zext i1 %cmp11601 to i32
  store i32 %cv11602, ptr %slot2078, align 8
  %v11603 = load i64, ptr %slot2077, align 8
  %cmp11604 = icmp ult i64 %v11603, 16
  %cv11605 = zext i1 %cmp11604 to i32
  store i32 %cv11605, ptr %slot2079, align 8
  %v11606 = load i32, ptr %slot2078, align 8
  %v11607 = load i32, ptr %slot2079, align 8
  %op11608 = or i32 %v11606, %v11607
  store i32 %op11608, ptr %slot2080, align 8
  %v11609 = load i32, ptr %slot2080, align 8
  %cv11610 = zext i32 %v11609 to i64
  %cond11611 = icmp ne i64 %cv11610, 0
  br i1 %cond11611, label %bb_rcmoveslow3124, label %bb_rcmovecheck3124
bb_rcmovecheck3124:
  %v11612 = load i64, ptr %slot2069, align 8
  %op11613 = add i64 %v11612, 0
  store i64 %op11613, ptr %slot2081, align 8
  %v11614 = load i64, ptr %slot2081, align 8
  %p11615 = inttoptr i64 %v11614 to ptr
  %ld11616 = load i64, ptr %p11615, align 8
  store i64 %ld11616, ptr %slot2082, align 8
  %v11617 = load i64, ptr %slot2082, align 8
  %cmp11618 = icmp ne i64 %v11617, 0
  %cv11619 = zext i1 %cmp11618 to i32
  store i32 %cv11619, ptr %slot2083, align 8
  %v11620 = load i32, ptr %slot2083, align 8
  %cv11621 = zext i32 %v11620 to i64
  %cond11622 = icmp ne i64 %cv11621, 0
  br i1 %cond11622, label %bb_rcmoveheader3132, label %bb_rcmovenext3132
bb_rcmoveheader3132:
  %v11623 = load i64, ptr %slot2082, align 8
  %op11624 = sub i64 %v11623, 16
  store i64 %op11624, ptr %slot2084, align 8
  %v11625 = load i64, ptr %slot2082, align 8
  %p11626 = inttoptr i64 %v11625 to ptr
  %rgep11627 = getelementptr i8, ptr %p11626, i64 -16
  %ld11628 = load i64, ptr %rgep11627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11628, ptr %slot2085, align 8
  %v11629 = load i64, ptr %slot2085, align 8
  %op11630 = and i64 %v11629, 5764607523034234881
  store i64 %op11630, ptr %slot2086, align 8
  %v11631 = load i64, ptr %slot2086, align 8
  %cmp11632 = icmp ne i64 %v11631, 0
  %cv11633 = zext i1 %cmp11632 to i32
  store i32 %cv11633, ptr %slot2087, align 8
  %v11634 = load i32, ptr %slot2087, align 8
  %cv11635 = zext i32 %v11634 to i64
  %cond11636 = icmp ne i64 %cv11635, 0
  br i1 %cond11636, label %bb_rcmoveslow3124, label %bb_rcmovenext3132
bb_rcmovenext3132:
  %v11637 = load i64, ptr %slot2069, align 8
  %v11638 = load i64, ptr %slot2074, align 8
  %p11639 = inttoptr i64 %v11637 to ptr
  %p11640 = inttoptr i64 %v11638 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11640, ptr %p11639, i64 16, i1 false)
  %v11641 = load i64, ptr %slot2069, align 8
  %p11642 = inttoptr i64 %v11641 to ptr
  store i64 0, ptr %p11642, align 8
  %v11643 = load i64, ptr %slot2069, align 8
  %op11644 = add i64 %v11643, 8
  store i64 %op11644, ptr %slot2088, align 8
  %v11645 = load i64, ptr %slot2088, align 8
  %p11646 = inttoptr i64 %v11645 to ptr
  store i64 0, ptr %p11646, align 8
  br label %bb_rcmoved3124
bb_rcmoveslow3124:
  %v11647 = load i64, ptr %slot63, align 8
  %v11648 = load i64, ptr %slot2074, align 8
  %v11649 = load i64, ptr %slot2069, align 8
  %v11650 = load i64, ptr %slot2075, align 8
  %cv11651 = trunc i64 %v11650 to i32
  %call11652 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v11647, i64 %v11648, i64 %v11649, i32 %cv11651) nomerge, !dbg !198
  store i32 %call11652, ptr %slot2089, align 8
  %v11653 = load i32, ptr %slot2089, align 8
  %cv11654 = zext i32 %v11653 to i64
  %cond11655 = icmp ne i64 %cv11654, 0
  br i1 %cond11655, label %bb_rcsuccess3140, label %bb_rcfailure3140
bb_rcfailure3140:
  %v11656 = load i64, ptr %slot63, align 8
  %p11657 = inttoptr i64 %v11656 to ptr
  %call11658 = call i32 @myl_rc_take_failure(ptr %p11657) nomerge, !dbg !198
  store i32 %call11658, ptr %slot2090, align 8
  %v11659 = load i64, ptr %slot1, align 8
  %p11660 = inttoptr i64 %v11659 to ptr
  %v11661 = load i32, ptr %slot2090, align 8
  %call11662 = call i32 @myl_qbe_rc_status(ptr %p11660, i32 %v11661) nomerge, !dbg !198
  store i32 %call11662, ptr %slot2091, align 8
  br label %bb_failure
bb_rcsuccess3140:
  br label %bb_rcmoved3124
bb_rcmoved3124:
  %v11663 = load i64, ptr %slot17, align 8
  %p11664 = inttoptr i64 %v11663 to ptr
  store i32 0, ptr %p11664, align 4, !alias.scope !3, !noalias !4
  %v11665 = load i64, ptr %slot20, align 8
  %p11666 = inttoptr i64 %v11665 to ptr
  store i32 2, ptr %p11666, align 4, !alias.scope !3, !noalias !4
  %v11667 = load i64, ptr %slot19, align 8
  %p11668 = inttoptr i64 %v11667 to ptr
  store i32 1, ptr %p11668, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared3115
bb_rccopy3115:
  %v11669 = load i64, ptr %slot24, align 8
  store i64 %v11669, ptr %slot2092, align 8
  %v11670 = load i64, ptr %slot64, align 8
  store i64 %v11670, ptr %slot2093, align 8
  %v11671 = load i64, ptr %slot63, align 8
  %v11672 = load i64, ptr %slot2092, align 8
  %v11673 = load i64, ptr %slot2069, align 8
  %v11674 = load i64, ptr %slot2093, align 8
  %cv11675 = trunc i64 %v11674 to i32
  %call11676 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v11671, i64 %v11672, i64 %v11673, i32 %cv11675) nomerge, !dbg !198
  store i32 %call11676, ptr %slot2094, align 8
  %v11677 = load i32, ptr %slot2094, align 8
  %cv11678 = zext i32 %v11677 to i64
  %cond11679 = icmp ne i64 %cv11678, 0
  br i1 %cond11679, label %bb_rcsuccess3149, label %bb_rcfailure3149
bb_rcfailure3149:
  %v11680 = load i64, ptr %slot63, align 8
  %p11681 = inttoptr i64 %v11680 to ptr
  %call11682 = call i32 @myl_rc_take_failure(ptr %p11681) nomerge, !dbg !198
  store i32 %call11682, ptr %slot2095, align 8
  %v11683 = load i64, ptr %slot1, align 8
  %p11684 = inttoptr i64 %v11683 to ptr
  %v11685 = load i32, ptr %slot2095, align 8
  %call11686 = call i32 @myl_qbe_rc_status(ptr %p11684, i32 %v11685) nomerge, !dbg !198
  store i32 %call11686, ptr %slot2096, align 8
  br label %bb_failure
bb_rcsuccess3149:
  %v11687 = load i64, ptr %slot20, align 8
  %p11688 = inttoptr i64 %v11687 to ptr
  store i32 2, ptr %p11688, align 4, !alias.scope !3, !noalias !4
  %v11689 = load i64, ptr %slot19, align 8
  %p11690 = inttoptr i64 %v11689 to ptr
  store i32 1, ptr %p11690, align 4, !alias.scope !3, !noalias !4
  %v11691 = load i64, ptr %slot17, align 8
  %p11692 = inttoptr i64 %v11691 to ptr
  %ld11693 = load i32, ptr %p11692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11693, ptr %slot2097, align 8
  %v11694 = load i32, ptr %slot2097, align 8
  %cv11695 = zext i32 %v11694 to i64
  %cond11696 = icmp ne i64 %cv11695, 0
  br i1 %cond11696, label %bb_rcslotdrop3156, label %bb_rcslotdone3156
bb_rcslotdrop3156:
  %v11697 = load i64, ptr %slot17, align 8
  %p11698 = inttoptr i64 %v11697 to ptr
  store i32 0, ptr %p11698, align 4, !alias.scope !3, !noalias !4
  %v11699 = load i64, ptr %slot22, align 8
  store i64 %v11699, ptr %slot2098, align 8
  %v11700 = load i64, ptr %slot18, align 8
  %p11701 = inttoptr i64 %v11700 to ptr
  %ld11702 = load i32, ptr %p11701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11702, ptr %slot2099, align 8
  %v11703 = load i32, ptr %slot2099, align 8
  %op11704 = and i32 %v11703, 28
  store i32 %op11704, ptr %slot2100, align 8
  %v11705 = load i32, ptr %slot2100, align 8
  %cv11706 = zext i32 %v11705 to i64
  %cond11707 = icmp ne i64 %cv11706, 0
  br i1 %cond11707, label %bb_rcslotrole3156, label %bb_rcslotowner3156
bb_rcslotrole3156:
  %v11708 = load i64, ptr %slot63, align 8
  store i64 %v11708, ptr %slot2101, align 8
  %v11709 = load i64, ptr %slot2101, align 8
  %v11710 = load i64, ptr %slot2098, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v11709, i64 %v11710) nomerge, !dbg !198
  br label %bb_rcslotdone3156
bb_rcslotowner3156:
  %v11711 = load i64, ptr %slot63, align 8
  store i64 %v11711, ptr %slot2102, align 8
  %v11712 = load i64, ptr %slot2102, align 8
  %v11713 = load i64, ptr %slot2098, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v11712, i64 %v11713) nomerge, !dbg !198
  br label %bb_rcslotdone3156
bb_rcslotdone3156:
  br label %bb_rcprepared3115
bb_rcprepared3115:
  %v11714 = load i64, ptr %slot24, align 8
  store i64 %v11714, ptr %slot2103, align 8
  %v11715 = load i64, ptr %slot2103, align 8
  %v11716 = load i64, ptr %slot2067, align 8
  %p11717 = inttoptr i64 %v11715 to ptr
  %p11718 = inttoptr i64 %v11716 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11718, ptr %p11717, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11719 = load i64, ptr %slot19, align 8
  %p11720 = inttoptr i64 %v11719 to ptr
  store i32 0, ptr %p11720, align 4, !alias.scope !3, !noalias !4
  %v11721 = load i64, ptr %slot2063, align 8
  %v11722 = load i64, ptr %slot44, align 8
  %p11723 = inttoptr i64 %v11722 to ptr
  store i64 %v11721, ptr %p11723, align 8, !alias.scope !3, !noalias !4
  %p11724 = inttoptr i64 ptrtoint (ptr @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p11724, i64 131) "call-inline-cost"="0", !dbg !198
  %v11725 = load i64, ptr %slot44, align 8
  %p11726 = inttoptr i64 %v11725 to ptr
  %ld11727 = load i64, ptr %p11726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11727, ptr %slot2104, align 8
  %v11728 = load i64, ptr %slot22, align 8
  store i64 %v11728, ptr %slot2105, align 8
  %v11729 = load i64, ptr %slot2104, align 8
  %v11730 = load i64, ptr %slot2105, align 8
  %p11731 = inttoptr i64 %v11729 to ptr
  %p11732 = inttoptr i64 %v11730 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11732, ptr %p11731, i64 24, i1 false)
  %v11733 = load i64, ptr %slot18, align 8
  %p11734 = inttoptr i64 %v11733 to ptr
  store i32 2, ptr %p11734, align 4, !alias.scope !3, !noalias !4
  %v11735 = load i64, ptr %slot17, align 8
  %p11736 = inttoptr i64 %v11735 to ptr
  store i32 1, ptr %p11736, align 4, !alias.scope !3, !noalias !4
  %v11737 = load i64, ptr %slot2105, align 8
  %v11738 = load i64, ptr %slot44, align 8
  %p11739 = inttoptr i64 %v11738 to ptr
  store i64 %v11737, ptr %p11739, align 8, !alias.scope !3, !noalias !4
  %v11740 = load i64, ptr %slot44, align 8
  %p11741 = inttoptr i64 %v11740 to ptr
  %ld11742 = load i64, ptr %p11741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11742, ptr %slot2106, align 8
  %v11743 = load i64, ptr %slot44, align 8
  %p11744 = inttoptr i64 %v11743 to ptr
  %ld11745 = load i64, ptr %p11744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11745, ptr %slot2107, align 8
  %v11746 = load i64, ptr %slot24, align 8
  store i64 %v11746, ptr %slot2108, align 8
  %v11747 = load i64, ptr %slot64, align 8
  store i64 %v11747, ptr %slot2109, align 8
  %v11748 = load i64, ptr %slot63, align 8
  %v11749 = load i64, ptr %slot2108, align 8
  %v11750 = load i64, ptr %slot2107, align 8
  %v11751 = load i64, ptr %slot2109, align 8
  %cv11752 = trunc i64 %v11751 to i32
  %call11753 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v11748, i64 %v11749, i64 %v11750, i32 %cv11752) nomerge, !dbg !200
  store i32 %call11753, ptr %slot2110, align 8
  %v11754 = load i32, ptr %slot2110, align 8
  %cv11755 = zext i32 %v11754 to i64
  %cond11756 = icmp ne i64 %cv11755, 0
  br i1 %cond11756, label %bb_rcsuccess3174, label %bb_rcfailure3174
bb_rcfailure3174:
  %v11757 = load i64, ptr %slot63, align 8
  %p11758 = inttoptr i64 %v11757 to ptr
  %call11759 = call i32 @myl_rc_take_failure(ptr %p11758) nomerge, !dbg !200
  store i32 %call11759, ptr %slot2111, align 8
  %v11760 = load i64, ptr %slot1, align 8
  %p11761 = inttoptr i64 %v11760 to ptr
  %v11762 = load i32, ptr %slot2111, align 8
  %call11763 = call i32 @myl_qbe_rc_status(ptr %p11761, i32 %v11762) nomerge, !dbg !200
  store i32 %call11763, ptr %slot2112, align 8
  br label %bb_failure
bb_rcsuccess3174:
  %v11764 = load i64, ptr %slot17, align 8
  %p11765 = inttoptr i64 %v11764 to ptr
  store i32 0, ptr %p11765, align 4, !alias.scope !3, !noalias !4
  %v11766 = load i64, ptr %slot20, align 8
  %p11767 = inttoptr i64 %v11766 to ptr
  store i32 2, ptr %p11767, align 4, !alias.scope !3, !noalias !4
  %v11768 = load i64, ptr %slot19, align 8
  %p11769 = inttoptr i64 %v11768 to ptr
  store i32 1, ptr %p11769, align 4, !alias.scope !3, !noalias !4
  %v11770 = load i64, ptr %slot24, align 8
  store i64 %v11770, ptr %slot2113, align 8
  %v11771 = load i64, ptr %slot19, align 8
  %p11772 = inttoptr i64 %v11771 to ptr
  store i32 0, ptr %p11772, align 4, !alias.scope !3, !noalias !4
  %v11773 = load i64, ptr %slot17, align 8
  %p11774 = inttoptr i64 %v11773 to ptr
  %ld11775 = load i32, ptr %p11774, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11775, ptr %slot2114, align 8
  %v11776 = load i32, ptr %slot2114, align 8
  %cv11777 = zext i32 %v11776 to i64
  %cond11778 = icmp ne i64 %cv11777, 0
  br i1 %cond11778, label %bb_rcslotdrop3184, label %bb_rcslotdone3184
bb_rcslotdrop3184:
  %v11779 = load i64, ptr %slot17, align 8
  %p11780 = inttoptr i64 %v11779 to ptr
  store i32 0, ptr %p11780, align 4, !alias.scope !3, !noalias !4
  %v11781 = load i64, ptr %slot22, align 8
  store i64 %v11781, ptr %slot2115, align 8
  %v11782 = load i64, ptr %slot18, align 8
  %p11783 = inttoptr i64 %v11782 to ptr
  %ld11784 = load i32, ptr %p11783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11784, ptr %slot2116, align 8
  %v11785 = load i32, ptr %slot2116, align 8
  %op11786 = and i32 %v11785, 28
  store i32 %op11786, ptr %slot2117, align 8
  %v11787 = load i32, ptr %slot2117, align 8
  %cv11788 = zext i32 %v11787 to i64
  %cond11789 = icmp ne i64 %cv11788, 0
  br i1 %cond11789, label %bb_rcslotrole3184, label %bb_rcslotowner3184
bb_rcslotrole3184:
  %v11790 = load i64, ptr %slot63, align 8
  store i64 %v11790, ptr %slot2118, align 8
  %v11791 = load i64, ptr %slot2118, align 8
  %v11792 = load i64, ptr %slot2115, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v11791, i64 %v11792) nomerge, !dbg !200
  br label %bb_rcslotdone3184
bb_rcslotowner3184:
  %v11793 = load i64, ptr %slot63, align 8
  store i64 %v11793, ptr %slot2119, align 8
  %v11794 = load i64, ptr %slot2119, align 8
  %v11795 = load i64, ptr %slot2115, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v11794, i64 %v11795) nomerge, !dbg !200
  br label %bb_rcslotdone3184
bb_rcslotdone3184:
  %v11796 = load i64, ptr %slot15, align 8
  %p11797 = inttoptr i64 %v11796 to ptr
  %ld11798 = load i32, ptr %p11797, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11798, ptr %slot2120, align 8
  %v11799 = load i32, ptr %slot2120, align 8
  %cv11800 = zext i32 %v11799 to i64
  %cond11801 = icmp ne i64 %cv11800, 0
  br i1 %cond11801, label %bb_rcslotdrop3211, label %bb_rcslotdone3211
bb_rcslotdrop3211:
  %v11802 = load i64, ptr %slot15, align 8
  %p11803 = inttoptr i64 %v11802 to ptr
  store i32 0, ptr %p11803, align 4, !alias.scope !3, !noalias !4
  %v11804 = load i64, ptr %slot43, align 8
  store i64 %v11804, ptr %slot2121, align 8
  %v11805 = load i64, ptr %slot16, align 8
  %p11806 = inttoptr i64 %v11805 to ptr
  %ld11807 = load i32, ptr %p11806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11807, ptr %slot2122, align 8
  %v11808 = load i32, ptr %slot2122, align 8
  %op11809 = and i32 %v11808, 28
  store i32 %op11809, ptr %slot2123, align 8
  %v11810 = load i32, ptr %slot2123, align 8
  %cv11811 = zext i32 %v11810 to i64
  %cond11812 = icmp ne i64 %cv11811, 0
  br i1 %cond11812, label %bb_rcslotrole3211, label %bb_rcslotowner3211
bb_rcslotrole3211:
  %v11813 = load i64, ptr %slot63, align 8
  store i64 %v11813, ptr %slot2124, align 8
  %v11814 = load i64, ptr %slot2124, align 8
  %v11815 = load i64, ptr %slot2121, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v11814, i64 %v11815) nomerge, !dbg !200
  br label %bb_rcslotdone3211
bb_rcslotowner3211:
  %v11816 = load i64, ptr %slot63, align 8
  store i64 %v11816, ptr %slot2125, align 8
  %v11817 = load i64, ptr %slot2125, align 8
  %v11818 = load i64, ptr %slot2121, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v11817, i64 %v11818) nomerge, !dbg !200
  br label %bb_rcslotdone3211
bb_rcslotdone3211:
  %v11819 = load i64, ptr %slot13, align 8
  %p11820 = inttoptr i64 %v11819 to ptr
  %ld11821 = load i32, ptr %p11820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11821, ptr %slot2126, align 8
  %v11822 = load i32, ptr %slot2126, align 8
  %cv11823 = zext i32 %v11822 to i64
  %cond11824 = icmp ne i64 %cv11823, 0
  br i1 %cond11824, label %bb_rcslotdrop3220, label %bb_rcslotdone3220
bb_rcslotdrop3220:
  %v11825 = load i64, ptr %slot13, align 8
  %p11826 = inttoptr i64 %v11825 to ptr
  store i32 0, ptr %p11826, align 4, !alias.scope !3, !noalias !4
  %v11827 = load i64, ptr %slot42, align 8
  store i64 %v11827, ptr %slot2127, align 8
  %v11828 = load i64, ptr %slot14, align 8
  %p11829 = inttoptr i64 %v11828 to ptr
  %ld11830 = load i32, ptr %p11829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11830, ptr %slot2128, align 8
  %v11831 = load i32, ptr %slot2128, align 8
  %op11832 = and i32 %v11831, 28
  store i32 %op11832, ptr %slot2129, align 8
  %v11833 = load i32, ptr %slot2129, align 8
  %cv11834 = zext i32 %v11833 to i64
  %cond11835 = icmp ne i64 %cv11834, 0
  br i1 %cond11835, label %bb_rcslotrole3220, label %bb_rcslotowner3220
bb_rcslotrole3220:
  %v11836 = load i64, ptr %slot63, align 8
  store i64 %v11836, ptr %slot2130, align 8
  %v11837 = load i64, ptr %slot2127, align 8
  %p11838 = inttoptr i64 %v11837 to ptr
  %ld11839 = load i64, ptr %p11838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11839, ptr %slot2131, align 8
  %v11840 = load i64, ptr %slot2131, align 8
  %cmp11841 = icmp ne i64 %v11840, 0
  %cv11842 = zext i1 %cmp11841 to i32
  store i32 %cv11842, ptr %slot2132, align 8
  %v11843 = load i32, ptr %slot2132, align 8
  %cv11844 = zext i32 %v11843 to i64
  %cond11845 = icmp ne i64 %cv11844, 0
  br i1 %cond11845, label %bb_rcgnn3236, label %bb_rcgdone3236
bb_rcgnn3236:
  %v11846 = load i64, ptr %slot2131, align 8
  %op11847 = sub i64 %v11846, 16
  store i64 %op11847, ptr %slot2133, align 8
  %v11848 = load i64, ptr %slot2131, align 8
  %p11849 = inttoptr i64 %v11848 to ptr
  %rgep11850 = getelementptr i8, ptr %p11849, i64 -16
  %ld11851 = load i64, ptr %rgep11850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11851, ptr %slot2134, align 8
  %v11852 = load i64, ptr %slot2134, align 8
  %op11853 = and i64 %v11852, 4611686018427387906
  store i64 %op11853, ptr %slot2135, align 8
  %v11854 = load i64, ptr %slot2135, align 8
  %cmp11855 = icmp ne i64 %v11854, 0
  %cv11856 = zext i1 %cmp11855 to i32
  store i32 %cv11856, ptr %slot2136, align 8
  %v11857 = load i32, ptr %slot2136, align 8
  %cv11858 = zext i32 %v11857 to i64
  %cond11859 = icmp ne i64 %cv11858, 0
  br i1 %cond11859, label %bb_rcgclear3236, label %bb_rcgcounted3236
bb_rcgcounted3236:
  %v11860 = load i64, ptr %slot2131, align 8
  %op11861 = sub i64 %v11860, 24
  store i64 %op11861, ptr %slot2137, align 8
  %v11862 = load i64, ptr %slot2131, align 8
  %p11863 = inttoptr i64 %v11862 to ptr
  %rgep11864 = getelementptr i8, ptr %p11863, i64 -24
  %ld11865 = load i64, ptr %rgep11864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11865, ptr %slot2138, align 8
  %v11866 = load i64, ptr %slot2138, align 8
  %op11867 = sub i64 %v11866, 1
  store i64 %op11867, ptr %slot2139, align 8
  %v11868 = load i64, ptr %slot2139, align 8
  %cmp11869 = icmp eq i64 %v11868, 0
  %cv11870 = zext i1 %cmp11869 to i32
  store i32 %cv11870, ptr %slot2140, align 8
  %v11871 = load i32, ptr %slot2140, align 8
  %cv11872 = zext i32 %v11871 to i64
  %cond11873 = icmp ne i64 %cv11872, 0
  br i1 %cond11873, label %bb_rcglast3236, label %bb_rcgdec3236
bb_rcglast3236:
  %v11874 = load i64, ptr %slot2131, align 8
  %op11875 = sub i64 %v11874, 32
  store i64 %op11875, ptr %slot2141, align 8
  %v11876 = load i64, ptr %slot2131, align 8
  %p11877 = inttoptr i64 %v11876 to ptr
  %rgep11878 = getelementptr i8, ptr %p11877, i64 -32
  %ld11879 = load i64, ptr %rgep11878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11879, ptr %slot2142, align 8
  %v11880 = load i64, ptr %slot2142, align 8
  %cmp11881 = icmp ne i64 %v11880, 0
  %cv11882 = zext i1 %cmp11881 to i32
  store i32 %cv11882, ptr %slot2143, align 8
  %v11883 = load i32, ptr %slot2143, align 8
  %cv11884 = zext i32 %v11883 to i64
  %cond11885 = icmp ne i64 %cv11884, 0
  br i1 %cond11885, label %bb_rcgdec3236, label %bb_rcgslow3236
bb_rcgslow3236:
  %v11886 = load i64, ptr %slot2130, align 8
  %v11887 = load i64, ptr %slot2127, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v11886, i64 %v11887) nomerge, !dbg !200
  br label %bb_rcgdone3236
bb_rcgdec3236:
  %v11888 = load i64, ptr %slot2139, align 8
  %v11889 = load i64, ptr %slot2131, align 8
  %p11890 = inttoptr i64 %v11889 to ptr
  %rgep11891 = getelementptr i8, ptr %p11890, i64 -24
  store i64 %v11888, ptr %rgep11891, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3236
bb_rcgclear3236:
  %v11892 = load i64, ptr %slot2127, align 8
  %p11893 = inttoptr i64 %v11892 to ptr
  store i64 0, ptr %p11893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3236
bb_rcgdone3236:
  br label %bb_rcslotdone3220
bb_rcslotowner3220:
  %v11894 = load i64, ptr %slot63, align 8
  store i64 %v11894, ptr %slot2144, align 8
  %v11895 = load i64, ptr %slot2127, align 8
  %p11896 = inttoptr i64 %v11895 to ptr
  %ld11897 = load i64, ptr %p11896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11897, ptr %slot2145, align 8
  %v11898 = load i64, ptr %slot2145, align 8
  %cmp11899 = icmp ne i64 %v11898, 0
  %cv11900 = zext i1 %cmp11899 to i32
  store i32 %cv11900, ptr %slot2146, align 8
  %v11901 = load i32, ptr %slot2146, align 8
  %cv11902 = zext i32 %v11901 to i64
  %cond11903 = icmp ne i64 %cv11902, 0
  br i1 %cond11903, label %bb_rcgnn3251, label %bb_rcgdone3251
bb_rcgnn3251:
  %v11904 = load i64, ptr %slot2145, align 8
  %op11905 = sub i64 %v11904, 16
  store i64 %op11905, ptr %slot2147, align 8
  %v11906 = load i64, ptr %slot2145, align 8
  %p11907 = inttoptr i64 %v11906 to ptr
  %rgep11908 = getelementptr i8, ptr %p11907, i64 -16
  %ld11909 = load i64, ptr %rgep11908, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11909, ptr %slot2148, align 8
  %v11910 = load i64, ptr %slot2148, align 8
  %op11911 = and i64 %v11910, 4611686018427387906
  store i64 %op11911, ptr %slot2149, align 8
  %v11912 = load i64, ptr %slot2149, align 8
  %cmp11913 = icmp ne i64 %v11912, 0
  %cv11914 = zext i1 %cmp11913 to i32
  store i32 %cv11914, ptr %slot2150, align 8
  %v11915 = load i32, ptr %slot2150, align 8
  %cv11916 = zext i32 %v11915 to i64
  %cond11917 = icmp ne i64 %cv11916, 0
  br i1 %cond11917, label %bb_rcgclear3251, label %bb_rcgcounted3251
bb_rcgcounted3251:
  %v11918 = load i64, ptr %slot2145, align 8
  %op11919 = sub i64 %v11918, 32
  store i64 %op11919, ptr %slot2151, align 8
  %v11920 = load i64, ptr %slot2145, align 8
  %p11921 = inttoptr i64 %v11920 to ptr
  %rgep11922 = getelementptr i8, ptr %p11921, i64 -32
  %ld11923 = load i64, ptr %rgep11922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11923, ptr %slot2152, align 8
  %v11924 = load i64, ptr %slot2152, align 8
  %op11925 = sub i64 %v11924, 1
  store i64 %op11925, ptr %slot2153, align 8
  %v11926 = load i64, ptr %slot2153, align 8
  %cmp11927 = icmp eq i64 %v11926, 0
  %cv11928 = zext i1 %cmp11927 to i32
  store i32 %cv11928, ptr %slot2154, align 8
  %v11929 = load i32, ptr %slot2154, align 8
  %cv11930 = zext i32 %v11929 to i64
  %cond11931 = icmp ne i64 %cv11930, 0
  br i1 %cond11931, label %bb_rcglast3251, label %bb_rcgdec3251
bb_rcglast3251:
  %v11932 = load i64, ptr %slot2145, align 8
  %op11933 = sub i64 %v11932, 24
  store i64 %op11933, ptr %slot2155, align 8
  %v11934 = load i64, ptr %slot2145, align 8
  %p11935 = inttoptr i64 %v11934 to ptr
  %rgep11936 = getelementptr i8, ptr %p11935, i64 -24
  %ld11937 = load i64, ptr %rgep11936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11937, ptr %slot2156, align 8
  %v11938 = load i64, ptr %slot2156, align 8
  %cmp11939 = icmp ne i64 %v11938, 0
  %cv11940 = zext i1 %cmp11939 to i32
  store i32 %cv11940, ptr %slot2157, align 8
  %v11941 = load i32, ptr %slot2157, align 8
  %cv11942 = zext i32 %v11941 to i64
  %cond11943 = icmp ne i64 %cv11942, 0
  br i1 %cond11943, label %bb_rcgdec3251, label %bb_rcgslow3251
bb_rcgslow3251:
  %v11944 = load i64, ptr %slot2144, align 8
  %v11945 = load i64, ptr %slot2127, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v11944, i64 %v11945) nomerge, !dbg !200
  br label %bb_rcgdone3251
bb_rcgdec3251:
  %v11946 = load i64, ptr %slot2153, align 8
  %v11947 = load i64, ptr %slot2145, align 8
  %p11948 = inttoptr i64 %v11947 to ptr
  %rgep11949 = getelementptr i8, ptr %p11948, i64 -32
  store i64 %v11946, ptr %rgep11949, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3251
bb_rcgclear3251:
  %v11950 = load i64, ptr %slot2127, align 8
  %p11951 = inttoptr i64 %v11950 to ptr
  store i64 0, ptr %p11951, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3251
bb_rcgdone3251:
  br label %bb_rcslotdone3220
bb_rcslotdone3220:
  %v11952 = load i64, ptr %slot11, align 8
  %p11953 = inttoptr i64 %v11952 to ptr
  %ld11954 = load i32, ptr %p11953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11954, ptr %slot2158, align 8
  %v11955 = load i32, ptr %slot2158, align 8
  %cv11956 = zext i32 %v11955 to i64
  %cond11957 = icmp ne i64 %cv11956, 0
  br i1 %cond11957, label %bb_rcslotdrop3257, label %bb_rcslotdone3257
bb_rcslotdrop3257:
  %v11958 = load i64, ptr %slot11, align 8
  %p11959 = inttoptr i64 %v11958 to ptr
  store i32 0, ptr %p11959, align 4, !alias.scope !3, !noalias !4
  %v11960 = load i64, ptr %slot41, align 8
  store i64 %v11960, ptr %slot2159, align 8
  %v11961 = load i64, ptr %slot12, align 8
  %p11962 = inttoptr i64 %v11961 to ptr
  %ld11963 = load i32, ptr %p11962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11963, ptr %slot2160, align 8
  %v11964 = load i32, ptr %slot2160, align 8
  %op11965 = and i32 %v11964, 28
  store i32 %op11965, ptr %slot2161, align 8
  %v11966 = load i32, ptr %slot2161, align 8
  %cv11967 = zext i32 %v11966 to i64
  %cond11968 = icmp ne i64 %cv11967, 0
  br i1 %cond11968, label %bb_rcslotrole3257, label %bb_rcslotowner3257
bb_rcslotrole3257:
  %v11969 = load i64, ptr %slot63, align 8
  store i64 %v11969, ptr %slot2162, align 8
  %v11970 = load i64, ptr %slot2159, align 8
  %p11971 = inttoptr i64 %v11970 to ptr
  %ld11972 = load i64, ptr %p11971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11972, ptr %slot2163, align 8
  %v11973 = load i64, ptr %slot2163, align 8
  %cmp11974 = icmp ne i64 %v11973, 0
  %cv11975 = zext i1 %cmp11974 to i32
  store i32 %cv11975, ptr %slot2164, align 8
  %v11976 = load i32, ptr %slot2164, align 8
  %cv11977 = zext i32 %v11976 to i64
  %cond11978 = icmp ne i64 %cv11977, 0
  br i1 %cond11978, label %bb_rcgnn3273, label %bb_rcgdone3273
bb_rcgnn3273:
  %v11979 = load i64, ptr %slot2163, align 8
  %op11980 = sub i64 %v11979, 16
  store i64 %op11980, ptr %slot2165, align 8
  %v11981 = load i64, ptr %slot2163, align 8
  %p11982 = inttoptr i64 %v11981 to ptr
  %rgep11983 = getelementptr i8, ptr %p11982, i64 -16
  %ld11984 = load i64, ptr %rgep11983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11984, ptr %slot2166, align 8
  %v11985 = load i64, ptr %slot2166, align 8
  %op11986 = and i64 %v11985, 4611686018427387906
  store i64 %op11986, ptr %slot2167, align 8
  %v11987 = load i64, ptr %slot2167, align 8
  %cmp11988 = icmp ne i64 %v11987, 0
  %cv11989 = zext i1 %cmp11988 to i32
  store i32 %cv11989, ptr %slot2168, align 8
  %v11990 = load i32, ptr %slot2168, align 8
  %cv11991 = zext i32 %v11990 to i64
  %cond11992 = icmp ne i64 %cv11991, 0
  br i1 %cond11992, label %bb_rcgclear3273, label %bb_rcgcounted3273
bb_rcgcounted3273:
  %v11993 = load i64, ptr %slot2163, align 8
  %op11994 = sub i64 %v11993, 24
  store i64 %op11994, ptr %slot2169, align 8
  %v11995 = load i64, ptr %slot2163, align 8
  %p11996 = inttoptr i64 %v11995 to ptr
  %rgep11997 = getelementptr i8, ptr %p11996, i64 -24
  %ld11998 = load i64, ptr %rgep11997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11998, ptr %slot2170, align 8
  %v11999 = load i64, ptr %slot2170, align 8
  %op12000 = sub i64 %v11999, 1
  store i64 %op12000, ptr %slot2171, align 8
  %v12001 = load i64, ptr %slot2171, align 8
  %cmp12002 = icmp eq i64 %v12001, 0
  %cv12003 = zext i1 %cmp12002 to i32
  store i32 %cv12003, ptr %slot2172, align 8
  %v12004 = load i32, ptr %slot2172, align 8
  %cv12005 = zext i32 %v12004 to i64
  %cond12006 = icmp ne i64 %cv12005, 0
  br i1 %cond12006, label %bb_rcglast3273, label %bb_rcgdec3273
bb_rcglast3273:
  %v12007 = load i64, ptr %slot2163, align 8
  %op12008 = sub i64 %v12007, 32
  store i64 %op12008, ptr %slot2173, align 8
  %v12009 = load i64, ptr %slot2163, align 8
  %p12010 = inttoptr i64 %v12009 to ptr
  %rgep12011 = getelementptr i8, ptr %p12010, i64 -32
  %ld12012 = load i64, ptr %rgep12011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12012, ptr %slot2174, align 8
  %v12013 = load i64, ptr %slot2174, align 8
  %cmp12014 = icmp ne i64 %v12013, 0
  %cv12015 = zext i1 %cmp12014 to i32
  store i32 %cv12015, ptr %slot2175, align 8
  %v12016 = load i32, ptr %slot2175, align 8
  %cv12017 = zext i32 %v12016 to i64
  %cond12018 = icmp ne i64 %cv12017, 0
  br i1 %cond12018, label %bb_rcgdec3273, label %bb_rcgslow3273
bb_rcgslow3273:
  %v12019 = load i64, ptr %slot2162, align 8
  %v12020 = load i64, ptr %slot2159, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v12019, i64 %v12020) nomerge, !dbg !200
  br label %bb_rcgdone3273
bb_rcgdec3273:
  %v12021 = load i64, ptr %slot2171, align 8
  %v12022 = load i64, ptr %slot2163, align 8
  %p12023 = inttoptr i64 %v12022 to ptr
  %rgep12024 = getelementptr i8, ptr %p12023, i64 -24
  store i64 %v12021, ptr %rgep12024, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3273
bb_rcgclear3273:
  %v12025 = load i64, ptr %slot2159, align 8
  %p12026 = inttoptr i64 %v12025 to ptr
  store i64 0, ptr %p12026, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3273
bb_rcgdone3273:
  br label %bb_rcslotdone3257
bb_rcslotowner3257:
  %v12027 = load i64, ptr %slot63, align 8
  store i64 %v12027, ptr %slot2176, align 8
  %v12028 = load i64, ptr %slot2159, align 8
  %p12029 = inttoptr i64 %v12028 to ptr
  %ld12030 = load i64, ptr %p12029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12030, ptr %slot2177, align 8
  %v12031 = load i64, ptr %slot2177, align 8
  %cmp12032 = icmp ne i64 %v12031, 0
  %cv12033 = zext i1 %cmp12032 to i32
  store i32 %cv12033, ptr %slot2178, align 8
  %v12034 = load i32, ptr %slot2178, align 8
  %cv12035 = zext i32 %v12034 to i64
  %cond12036 = icmp ne i64 %cv12035, 0
  br i1 %cond12036, label %bb_rcgnn3288, label %bb_rcgdone3288
bb_rcgnn3288:
  %v12037 = load i64, ptr %slot2177, align 8
  %op12038 = sub i64 %v12037, 16
  store i64 %op12038, ptr %slot2179, align 8
  %v12039 = load i64, ptr %slot2177, align 8
  %p12040 = inttoptr i64 %v12039 to ptr
  %rgep12041 = getelementptr i8, ptr %p12040, i64 -16
  %ld12042 = load i64, ptr %rgep12041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12042, ptr %slot2180, align 8
  %v12043 = load i64, ptr %slot2180, align 8
  %op12044 = and i64 %v12043, 4611686018427387906
  store i64 %op12044, ptr %slot2181, align 8
  %v12045 = load i64, ptr %slot2181, align 8
  %cmp12046 = icmp ne i64 %v12045, 0
  %cv12047 = zext i1 %cmp12046 to i32
  store i32 %cv12047, ptr %slot2182, align 8
  %v12048 = load i32, ptr %slot2182, align 8
  %cv12049 = zext i32 %v12048 to i64
  %cond12050 = icmp ne i64 %cv12049, 0
  br i1 %cond12050, label %bb_rcgclear3288, label %bb_rcgcounted3288
bb_rcgcounted3288:
  %v12051 = load i64, ptr %slot2177, align 8
  %op12052 = sub i64 %v12051, 32
  store i64 %op12052, ptr %slot2183, align 8
  %v12053 = load i64, ptr %slot2177, align 8
  %p12054 = inttoptr i64 %v12053 to ptr
  %rgep12055 = getelementptr i8, ptr %p12054, i64 -32
  %ld12056 = load i64, ptr %rgep12055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12056, ptr %slot2184, align 8
  %v12057 = load i64, ptr %slot2184, align 8
  %op12058 = sub i64 %v12057, 1
  store i64 %op12058, ptr %slot2185, align 8
  %v12059 = load i64, ptr %slot2185, align 8
  %cmp12060 = icmp eq i64 %v12059, 0
  %cv12061 = zext i1 %cmp12060 to i32
  store i32 %cv12061, ptr %slot2186, align 8
  %v12062 = load i32, ptr %slot2186, align 8
  %cv12063 = zext i32 %v12062 to i64
  %cond12064 = icmp ne i64 %cv12063, 0
  br i1 %cond12064, label %bb_rcglast3288, label %bb_rcgdec3288
bb_rcglast3288:
  %v12065 = load i64, ptr %slot2177, align 8
  %op12066 = sub i64 %v12065, 24
  store i64 %op12066, ptr %slot2187, align 8
  %v12067 = load i64, ptr %slot2177, align 8
  %p12068 = inttoptr i64 %v12067 to ptr
  %rgep12069 = getelementptr i8, ptr %p12068, i64 -24
  %ld12070 = load i64, ptr %rgep12069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12070, ptr %slot2188, align 8
  %v12071 = load i64, ptr %slot2188, align 8
  %cmp12072 = icmp ne i64 %v12071, 0
  %cv12073 = zext i1 %cmp12072 to i32
  store i32 %cv12073, ptr %slot2189, align 8
  %v12074 = load i32, ptr %slot2189, align 8
  %cv12075 = zext i32 %v12074 to i64
  %cond12076 = icmp ne i64 %cv12075, 0
  br i1 %cond12076, label %bb_rcgdec3288, label %bb_rcgslow3288
bb_rcgslow3288:
  %v12077 = load i64, ptr %slot2176, align 8
  %v12078 = load i64, ptr %slot2159, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v12077, i64 %v12078) nomerge, !dbg !200
  br label %bb_rcgdone3288
bb_rcgdec3288:
  %v12079 = load i64, ptr %slot2185, align 8
  %v12080 = load i64, ptr %slot2177, align 8
  %p12081 = inttoptr i64 %v12080 to ptr
  %rgep12082 = getelementptr i8, ptr %p12081, i64 -32
  store i64 %v12079, ptr %rgep12082, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3288
bb_rcgclear3288:
  %v12083 = load i64, ptr %slot2159, align 8
  %p12084 = inttoptr i64 %v12083 to ptr
  store i64 0, ptr %p12084, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3288
bb_rcgdone3288:
  br label %bb_rcslotdone3257
bb_rcslotdone3257:
  %v12085 = load i64, ptr %slot9, align 8
  %p12086 = inttoptr i64 %v12085 to ptr
  %ld12087 = load i32, ptr %p12086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12087, ptr %slot2190, align 8
  %v12088 = load i32, ptr %slot2190, align 8
  %cv12089 = zext i32 %v12088 to i64
  %cond12090 = icmp ne i64 %cv12089, 0
  br i1 %cond12090, label %bb_rcslotdrop3294, label %bb_rcslotdone3294
bb_rcslotdrop3294:
  %v12091 = load i64, ptr %slot9, align 8
  %p12092 = inttoptr i64 %v12091 to ptr
  store i32 0, ptr %p12092, align 4, !alias.scope !3, !noalias !4
  %v12093 = load i64, ptr %slot40, align 8
  store i64 %v12093, ptr %slot2191, align 8
  %v12094 = load i64, ptr %slot10, align 8
  %p12095 = inttoptr i64 %v12094 to ptr
  %ld12096 = load i32, ptr %p12095, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12096, ptr %slot2192, align 8
  %v12097 = load i32, ptr %slot2192, align 8
  %op12098 = and i32 %v12097, 28
  store i32 %op12098, ptr %slot2193, align 8
  %v12099 = load i32, ptr %slot2193, align 8
  %cv12100 = zext i32 %v12099 to i64
  %cond12101 = icmp ne i64 %cv12100, 0
  br i1 %cond12101, label %bb_rcslotrole3294, label %bb_rcslotowner3294
bb_rcslotrole3294:
  %v12102 = load i64, ptr %slot63, align 8
  store i64 %v12102, ptr %slot2194, align 8
  %v12103 = load i64, ptr %slot2191, align 8
  %p12104 = inttoptr i64 %v12103 to ptr
  %ld12105 = load i64, ptr %p12104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12105, ptr %slot2195, align 8
  %v12106 = load i64, ptr %slot2195, align 8
  %cmp12107 = icmp ne i64 %v12106, 0
  %cv12108 = zext i1 %cmp12107 to i32
  store i32 %cv12108, ptr %slot2196, align 8
  %v12109 = load i32, ptr %slot2196, align 8
  %cv12110 = zext i32 %v12109 to i64
  %cond12111 = icmp ne i64 %cv12110, 0
  br i1 %cond12111, label %bb_rcgnn3310, label %bb_rcgdone3310
bb_rcgnn3310:
  %v12112 = load i64, ptr %slot2195, align 8
  %op12113 = sub i64 %v12112, 16
  store i64 %op12113, ptr %slot2197, align 8
  %v12114 = load i64, ptr %slot2195, align 8
  %p12115 = inttoptr i64 %v12114 to ptr
  %rgep12116 = getelementptr i8, ptr %p12115, i64 -16
  %ld12117 = load i64, ptr %rgep12116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12117, ptr %slot2198, align 8
  %v12118 = load i64, ptr %slot2198, align 8
  %op12119 = and i64 %v12118, 4611686018427387906
  store i64 %op12119, ptr %slot2199, align 8
  %v12120 = load i64, ptr %slot2199, align 8
  %cmp12121 = icmp ne i64 %v12120, 0
  %cv12122 = zext i1 %cmp12121 to i32
  store i32 %cv12122, ptr %slot2200, align 8
  %v12123 = load i32, ptr %slot2200, align 8
  %cv12124 = zext i32 %v12123 to i64
  %cond12125 = icmp ne i64 %cv12124, 0
  br i1 %cond12125, label %bb_rcgclear3310, label %bb_rcgcounted3310
bb_rcgcounted3310:
  %v12126 = load i64, ptr %slot2195, align 8
  %op12127 = sub i64 %v12126, 24
  store i64 %op12127, ptr %slot2201, align 8
  %v12128 = load i64, ptr %slot2195, align 8
  %p12129 = inttoptr i64 %v12128 to ptr
  %rgep12130 = getelementptr i8, ptr %p12129, i64 -24
  %ld12131 = load i64, ptr %rgep12130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12131, ptr %slot2202, align 8
  %v12132 = load i64, ptr %slot2202, align 8
  %op12133 = sub i64 %v12132, 1
  store i64 %op12133, ptr %slot2203, align 8
  %v12134 = load i64, ptr %slot2203, align 8
  %cmp12135 = icmp eq i64 %v12134, 0
  %cv12136 = zext i1 %cmp12135 to i32
  store i32 %cv12136, ptr %slot2204, align 8
  %v12137 = load i32, ptr %slot2204, align 8
  %cv12138 = zext i32 %v12137 to i64
  %cond12139 = icmp ne i64 %cv12138, 0
  br i1 %cond12139, label %bb_rcglast3310, label %bb_rcgdec3310
bb_rcglast3310:
  %v12140 = load i64, ptr %slot2195, align 8
  %op12141 = sub i64 %v12140, 32
  store i64 %op12141, ptr %slot2205, align 8
  %v12142 = load i64, ptr %slot2195, align 8
  %p12143 = inttoptr i64 %v12142 to ptr
  %rgep12144 = getelementptr i8, ptr %p12143, i64 -32
  %ld12145 = load i64, ptr %rgep12144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12145, ptr %slot2206, align 8
  %v12146 = load i64, ptr %slot2206, align 8
  %cmp12147 = icmp ne i64 %v12146, 0
  %cv12148 = zext i1 %cmp12147 to i32
  store i32 %cv12148, ptr %slot2207, align 8
  %v12149 = load i32, ptr %slot2207, align 8
  %cv12150 = zext i32 %v12149 to i64
  %cond12151 = icmp ne i64 %cv12150, 0
  br i1 %cond12151, label %bb_rcgdec3310, label %bb_rcgslow3310
bb_rcgslow3310:
  %v12152 = load i64, ptr %slot2194, align 8
  %v12153 = load i64, ptr %slot2191, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v12152, i64 %v12153) nomerge, !dbg !200
  br label %bb_rcgdone3310
bb_rcgdec3310:
  %v12154 = load i64, ptr %slot2203, align 8
  %v12155 = load i64, ptr %slot2195, align 8
  %p12156 = inttoptr i64 %v12155 to ptr
  %rgep12157 = getelementptr i8, ptr %p12156, i64 -24
  store i64 %v12154, ptr %rgep12157, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3310
bb_rcgclear3310:
  %v12158 = load i64, ptr %slot2191, align 8
  %p12159 = inttoptr i64 %v12158 to ptr
  store i64 0, ptr %p12159, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3310
bb_rcgdone3310:
  br label %bb_rcslotdone3294
bb_rcslotowner3294:
  %v12160 = load i64, ptr %slot63, align 8
  store i64 %v12160, ptr %slot2208, align 8
  %v12161 = load i64, ptr %slot2191, align 8
  %p12162 = inttoptr i64 %v12161 to ptr
  %ld12163 = load i64, ptr %p12162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12163, ptr %slot2209, align 8
  %v12164 = load i64, ptr %slot2209, align 8
  %cmp12165 = icmp ne i64 %v12164, 0
  %cv12166 = zext i1 %cmp12165 to i32
  store i32 %cv12166, ptr %slot2210, align 8
  %v12167 = load i32, ptr %slot2210, align 8
  %cv12168 = zext i32 %v12167 to i64
  %cond12169 = icmp ne i64 %cv12168, 0
  br i1 %cond12169, label %bb_rcgnn3325, label %bb_rcgdone3325
bb_rcgnn3325:
  %v12170 = load i64, ptr %slot2209, align 8
  %op12171 = sub i64 %v12170, 16
  store i64 %op12171, ptr %slot2211, align 8
  %v12172 = load i64, ptr %slot2209, align 8
  %p12173 = inttoptr i64 %v12172 to ptr
  %rgep12174 = getelementptr i8, ptr %p12173, i64 -16
  %ld12175 = load i64, ptr %rgep12174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12175, ptr %slot2212, align 8
  %v12176 = load i64, ptr %slot2212, align 8
  %op12177 = and i64 %v12176, 4611686018427387906
  store i64 %op12177, ptr %slot2213, align 8
  %v12178 = load i64, ptr %slot2213, align 8
  %cmp12179 = icmp ne i64 %v12178, 0
  %cv12180 = zext i1 %cmp12179 to i32
  store i32 %cv12180, ptr %slot2214, align 8
  %v12181 = load i32, ptr %slot2214, align 8
  %cv12182 = zext i32 %v12181 to i64
  %cond12183 = icmp ne i64 %cv12182, 0
  br i1 %cond12183, label %bb_rcgclear3325, label %bb_rcgcounted3325
bb_rcgcounted3325:
  %v12184 = load i64, ptr %slot2209, align 8
  %op12185 = sub i64 %v12184, 32
  store i64 %op12185, ptr %slot2215, align 8
  %v12186 = load i64, ptr %slot2209, align 8
  %p12187 = inttoptr i64 %v12186 to ptr
  %rgep12188 = getelementptr i8, ptr %p12187, i64 -32
  %ld12189 = load i64, ptr %rgep12188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12189, ptr %slot2216, align 8
  %v12190 = load i64, ptr %slot2216, align 8
  %op12191 = sub i64 %v12190, 1
  store i64 %op12191, ptr %slot2217, align 8
  %v12192 = load i64, ptr %slot2217, align 8
  %cmp12193 = icmp eq i64 %v12192, 0
  %cv12194 = zext i1 %cmp12193 to i32
  store i32 %cv12194, ptr %slot2218, align 8
  %v12195 = load i32, ptr %slot2218, align 8
  %cv12196 = zext i32 %v12195 to i64
  %cond12197 = icmp ne i64 %cv12196, 0
  br i1 %cond12197, label %bb_rcglast3325, label %bb_rcgdec3325
bb_rcglast3325:
  %v12198 = load i64, ptr %slot2209, align 8
  %op12199 = sub i64 %v12198, 24
  store i64 %op12199, ptr %slot2219, align 8
  %v12200 = load i64, ptr %slot2209, align 8
  %p12201 = inttoptr i64 %v12200 to ptr
  %rgep12202 = getelementptr i8, ptr %p12201, i64 -24
  %ld12203 = load i64, ptr %rgep12202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12203, ptr %slot2220, align 8
  %v12204 = load i64, ptr %slot2220, align 8
  %cmp12205 = icmp ne i64 %v12204, 0
  %cv12206 = zext i1 %cmp12205 to i32
  store i32 %cv12206, ptr %slot2221, align 8
  %v12207 = load i32, ptr %slot2221, align 8
  %cv12208 = zext i32 %v12207 to i64
  %cond12209 = icmp ne i64 %cv12208, 0
  br i1 %cond12209, label %bb_rcgdec3325, label %bb_rcgslow3325
bb_rcgslow3325:
  %v12210 = load i64, ptr %slot2208, align 8
  %v12211 = load i64, ptr %slot2191, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v12210, i64 %v12211) nomerge, !dbg !200
  br label %bb_rcgdone3325
bb_rcgdec3325:
  %v12212 = load i64, ptr %slot2217, align 8
  %v12213 = load i64, ptr %slot2209, align 8
  %p12214 = inttoptr i64 %v12213 to ptr
  %rgep12215 = getelementptr i8, ptr %p12214, i64 -32
  store i64 %v12212, ptr %rgep12215, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3325
bb_rcgclear3325:
  %v12216 = load i64, ptr %slot2191, align 8
  %p12217 = inttoptr i64 %v12216 to ptr
  store i64 0, ptr %p12217, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3325
bb_rcgdone3325:
  br label %bb_rcslotdone3294
bb_rcslotdone3294:
  %v12218 = load i64, ptr %slot7, align 8
  %p12219 = inttoptr i64 %v12218 to ptr
  %ld12220 = load i32, ptr %p12219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12220, ptr %slot2222, align 8
  %v12221 = load i32, ptr %slot2222, align 8
  %cv12222 = zext i32 %v12221 to i64
  %cond12223 = icmp ne i64 %cv12222, 0
  br i1 %cond12223, label %bb_rcslotdrop3349, label %bb_rcslotdone3349
bb_rcslotdrop3349:
  %v12224 = load i64, ptr %slot7, align 8
  %p12225 = inttoptr i64 %v12224 to ptr
  store i32 0, ptr %p12225, align 4, !alias.scope !3, !noalias !4
  %v12226 = load i64, ptr %slot38, align 8
  store i64 %v12226, ptr %slot2223, align 8
  %v12227 = load i64, ptr %slot8, align 8
  %p12228 = inttoptr i64 %v12227 to ptr
  %ld12229 = load i32, ptr %p12228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12229, ptr %slot2224, align 8
  %v12230 = load i32, ptr %slot2224, align 8
  %op12231 = and i32 %v12230, 28
  store i32 %op12231, ptr %slot2225, align 8
  %v12232 = load i32, ptr %slot2225, align 8
  %cv12233 = zext i32 %v12232 to i64
  %cond12234 = icmp ne i64 %cv12233, 0
  br i1 %cond12234, label %bb_rcslotrole3349, label %bb_rcslotowner3349
bb_rcslotrole3349:
  %v12235 = load i64, ptr %slot63, align 8
  store i64 %v12235, ptr %slot2226, align 8
  %v12236 = load i64, ptr %slot2226, align 8
  %v12237 = load i64, ptr %slot2223, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12236, i64 %v12237) nomerge, !dbg !200
  br label %bb_rcslotdone3349
bb_rcslotowner3349:
  %v12238 = load i64, ptr %slot63, align 8
  store i64 %v12238, ptr %slot2227, align 8
  %v12239 = load i64, ptr %slot2227, align 8
  %v12240 = load i64, ptr %slot2223, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12239, i64 %v12240) nomerge, !dbg !200
  br label %bb_rcslotdone3349
bb_rcslotdone3349:
  %v12241 = load i64, ptr %slot2113, align 8
  %p12242 = inttoptr i64 %v12241 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p12242, i64 24, i1 false)
  ret void
bb_i133:
  %v12243 = load i64, ptr %slot26, align 8
  %p12244 = inttoptr i64 %v12243 to ptr
  %ld12245 = load i64, ptr %p12244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12245, ptr %slot2228, align 8
  %v12246 = load i64, ptr %slot2228, align 8
  %v12247 = load i64, ptr %slot55, align 8
  %p12248 = inttoptr i64 %v12246 to ptr
  %p12249 = inttoptr i64 %v12247 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12249, ptr %p12248, i64 304, i1 false), !alias.scope !10000000
  %v12250 = load i64, ptr %slot55, align 8
  %v12251 = load i64, ptr %slot44, align 8
  %p12252 = inttoptr i64 %v12251 to ptr
  store i64 %v12250, ptr %p12252, align 8, !alias.scope !3, !noalias !4
  %v12253 = load i64, ptr %slot44, align 8
  %p12254 = inttoptr i64 %v12253 to ptr
  %ld12255 = load i64, ptr %p12254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12255, ptr %slot2229, align 8
  %v12256 = load i64, ptr %slot2229, align 8
  %op12257 = add i64 %v12256, 32
  store i64 %op12257, ptr %slot2230, align 8
  %v12258 = load i64, ptr %slot2230, align 8
  %v12259 = load i64, ptr %slot44, align 8
  %p12260 = inttoptr i64 %v12259 to ptr
  store i64 %v12258, ptr %p12260, align 8, !alias.scope !3, !noalias !4
  %v12261 = load i64, ptr %slot15, align 8
  %p12262 = inttoptr i64 %v12261 to ptr
  %ld12263 = load i32, ptr %p12262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12263, ptr %slot2231, align 8
  %v12264 = load i32, ptr %slot2231, align 8
  %cv12265 = zext i32 %v12264 to i64
  %cond12266 = icmp ne i64 %cv12265, 0
  br i1 %cond12266, label %bb_rcslotdrop3444, label %bb_rcslotdone3444
bb_rcslotdrop3444:
  %v12267 = load i64, ptr %slot15, align 8
  %p12268 = inttoptr i64 %v12267 to ptr
  store i32 0, ptr %p12268, align 4, !alias.scope !3, !noalias !4
  %v12269 = load i64, ptr %slot43, align 8
  store i64 %v12269, ptr %slot2232, align 8
  %v12270 = load i64, ptr %slot16, align 8
  %p12271 = inttoptr i64 %v12270 to ptr
  %ld12272 = load i32, ptr %p12271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12272, ptr %slot2233, align 8
  %v12273 = load i32, ptr %slot2233, align 8
  %op12274 = and i32 %v12273, 28
  store i32 %op12274, ptr %slot2234, align 8
  %v12275 = load i32, ptr %slot2234, align 8
  %cv12276 = zext i32 %v12275 to i64
  %cond12277 = icmp ne i64 %cv12276, 0
  br i1 %cond12277, label %bb_rcslotrole3444, label %bb_rcslotowner3444
bb_rcslotrole3444:
  %v12278 = load i64, ptr %slot63, align 8
  store i64 %v12278, ptr %slot2235, align 8
  %v12279 = load i64, ptr %slot2235, align 8
  %v12280 = load i64, ptr %slot2232, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12279, i64 %v12280) nomerge, !dbg !202
  br label %bb_rcslotdone3444
bb_rcslotowner3444:
  %v12281 = load i64, ptr %slot63, align 8
  store i64 %v12281, ptr %slot2236, align 8
  %v12282 = load i64, ptr %slot2236, align 8
  %v12283 = load i64, ptr %slot2232, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12282, i64 %v12283) nomerge, !dbg !202
  br label %bb_rcslotdone3444
bb_rcslotdone3444:
  %v12284 = load i64, ptr %slot26, align 8
  %p12285 = inttoptr i64 %v12284 to ptr
  %ld12286 = load i64, ptr %p12285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12286, ptr %slot2237, align 8
  %v12287 = load i64, ptr %slot2237, align 8
  %op12288 = add i64 %v12287, 32
  store i64 %op12288, ptr %slot2238, align 8
  %v12289 = load i64, ptr %slot43, align 8
  store i64 %v12289, ptr %slot2239, align 8
  %v12290 = load i64, ptr %slot2238, align 8
  %v12291 = load i64, ptr %slot2239, align 8
  %p12292 = inttoptr i64 %v12290 to ptr
  %p12293 = inttoptr i64 %v12291 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12293, ptr %p12292, i64 208, i1 false), !alias.scope !10000000
  %v12294 = load i64, ptr %slot2238, align 8
  %p12295 = inttoptr i64 %v12294 to ptr
  call void @llvm.memset.p0.i64(ptr %p12295, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !202
  %v12296 = load i64, ptr %slot15, align 8
  %p12297 = inttoptr i64 %v12296 to ptr
  store i32 1, ptr %p12297, align 4, !alias.scope !3, !noalias !4
  %v12298 = load i64, ptr %slot43, align 8
  %v12299 = load i64, ptr %slot44, align 8
  %p12300 = inttoptr i64 %v12299 to ptr
  store i64 %v12298, ptr %p12300, align 8, !alias.scope !3, !noalias !4
  %v12301 = load i64, ptr %slot27, align 8
  %p12302 = inttoptr i64 %v12301 to ptr
  %ld12303 = load i64, ptr %p12302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12303, ptr %slot2240, align 8
  %v12304 = load i64, ptr %slot2240, align 8
  %v12305 = load i64, ptr %slot45, align 8
  %p12306 = inttoptr i64 %v12305 to ptr
  store i64 %v12304, ptr %p12306, align 8, !alias.scope !3, !noalias !4
  %v12307 = load i64, ptr %slot43, align 8
  %v12308 = load i64, ptr %slot56, align 8
  %p12309 = inttoptr i64 %v12307 to ptr
  %p12310 = inttoptr i64 %v12308 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12310, ptr %p12309, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v12311 = load i64, ptr %slot56, align 8
  %v12312 = load i64, ptr %slot46, align 8
  %p12313 = inttoptr i64 %v12312 to ptr
  store i64 %v12311, ptr %p12313, align 8, !alias.scope !3, !noalias !4
  %v12314 = load i64, ptr %slot39, align 8
  %v12315 = load i64, ptr %slot47, align 8
  %p12316 = inttoptr i64 %v12315 to ptr
  store i64 %v12314, ptr %p12316, align 8, !alias.scope !3, !noalias !4
  %v12317 = load i64, ptr %slot47, align 8
  %p12318 = inttoptr i64 %v12317 to ptr
  %ld12319 = load i64, ptr %p12318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12319, ptr %slot2241, align 8
  %v12320 = load i64, ptr %slot2241, align 8
  %op12321 = add i64 %v12320, 0
  store i64 %op12321, ptr %slot2242, align 8
  %v12322 = load i64, ptr %slot2242, align 8
  %p12323 = inttoptr i64 %v12322 to ptr
  %ld12324 = load i64, ptr %p12323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12324, ptr %slot2243, align 8
  %v12325 = load i64, ptr %slot2243, align 8
  %v12326 = load i64, ptr %slot47, align 8
  %p12327 = inttoptr i64 %v12326 to ptr
  store i64 %v12325, ptr %p12327, align 8, !alias.scope !3, !noalias !4
  %v12328 = load i64, ptr %slot46, align 8
  %p12329 = inttoptr i64 %v12328 to ptr
  %ld12330 = load i64, ptr %p12329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12330, ptr %slot2244, align 8
  %v12331 = load i64, ptr %slot47, align 8
  %p12332 = inttoptr i64 %v12331 to ptr
  %ld12333 = load i64, ptr %p12332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12333, ptr %slot2245, align 8
  %v12334 = load i64, ptr %slot1, align 8
  %v12335 = load i64, ptr %slot2244, align 8
  %v12336 = load i64, ptr %slot2245, align 8
  %call12337 = call { i64, i64 } @myl_f_e57cc4bfa29a47edaf8fafe0f664bfacf1316c7705c32574aa82bd91cd9e2559(i64 %v12334, i64 %v12335, i64 %v12336) nomerge, !dbg !204
  store { i64, i64 } %call12337, ptr %callresult2247, align 8
  %addr12338 = ptrtoint ptr %callresult2247 to i64
  store i64 %addr12338, ptr %slot2246, align 8
  %v12339 = load i64, ptr %slot2246, align 8
  %v12340 = load i64, ptr %slot46, align 8
  %p12341 = inttoptr i64 %v12340 to ptr
  store i64 %v12339, ptr %p12341, align 8, !alias.scope !3, !noalias !4
  %v12342 = load i64, ptr %slot44, align 8
  %p12343 = inttoptr i64 %v12342 to ptr
  %ld12344 = load i64, ptr %p12343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12344, ptr %slot2248, align 8
  %v12345 = load i64, ptr %slot45, align 8
  %p12346 = inttoptr i64 %v12345 to ptr
  %ld12347 = load i64, ptr %p12346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12347, ptr %slot2249, align 8
  %v12348 = load i64, ptr %slot46, align 8
  %p12349 = inttoptr i64 %v12348 to ptr
  %ld12350 = load i64, ptr %p12349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12350, ptr %slot2250, align 8
  %v12351 = load i64, ptr %slot1, align 8
  %v12352 = load i64, ptr %slot2248, align 8
  %v12353 = load i64, ptr %slot2249, align 8
  %v12354 = load i64, ptr %slot2250, align 8
  %call12355 = call i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64 %v12351, i64 %v12352, i64 %v12353, i64 %v12354) nomerge, !dbg !206
  store i64 %call12355, ptr %slot2251, align 8
  %v12356 = load i64, ptr %slot2251, align 8
  %v12357 = load i64, ptr %slot44, align 8
  %p12358 = inttoptr i64 %v12357 to ptr
  store i64 %v12356, ptr %p12358, align 8, !alias.scope !3, !noalias !4
  %v12359 = load i64, ptr %slot17, align 8
  %p12360 = inttoptr i64 %v12359 to ptr
  %ld12361 = load i32, ptr %p12360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12361, ptr %slot2252, align 8
  %v12362 = load i32, ptr %slot2252, align 8
  %cv12363 = zext i32 %v12362 to i64
  %cond12364 = icmp ne i64 %cv12363, 0
  br i1 %cond12364, label %bb_rcslotdrop3477, label %bb_rcslotdone3477
bb_rcslotdrop3477:
  %v12365 = load i64, ptr %slot17, align 8
  %p12366 = inttoptr i64 %v12365 to ptr
  store i32 0, ptr %p12366, align 4, !alias.scope !3, !noalias !4
  %v12367 = load i64, ptr %slot22, align 8
  store i64 %v12367, ptr %slot2253, align 8
  %v12368 = load i64, ptr %slot18, align 8
  %p12369 = inttoptr i64 %v12368 to ptr
  %ld12370 = load i32, ptr %p12369, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12370, ptr %slot2254, align 8
  %v12371 = load i32, ptr %slot2254, align 8
  %op12372 = and i32 %v12371, 28
  store i32 %op12372, ptr %slot2255, align 8
  %v12373 = load i32, ptr %slot2255, align 8
  %cv12374 = zext i32 %v12373 to i64
  %cond12375 = icmp ne i64 %cv12374, 0
  br i1 %cond12375, label %bb_rcslotrole3477, label %bb_rcslotowner3477
bb_rcslotrole3477:
  %v12376 = load i64, ptr %slot63, align 8
  store i64 %v12376, ptr %slot2256, align 8
  %v12377 = load i64, ptr %slot2256, align 8
  %v12378 = load i64, ptr %slot2253, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12377, i64 %v12378) nomerge, !dbg !206
  br label %bb_rcslotdone3477
bb_rcslotowner3477:
  %v12379 = load i64, ptr %slot63, align 8
  store i64 %v12379, ptr %slot2257, align 8
  %v12380 = load i64, ptr %slot2257, align 8
  %v12381 = load i64, ptr %slot2253, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12380, i64 %v12381) nomerge, !dbg !206
  br label %bb_rcslotdone3477
bb_rcslotdone3477:
  %v12382 = load i64, ptr %slot26, align 8
  %p12383 = inttoptr i64 %v12382 to ptr
  %ld12384 = load i64, ptr %p12383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12384, ptr %slot2258, align 8
  %v12385 = load i64, ptr %slot2258, align 8
  %op12386 = add i64 %v12385, 32
  store i64 %op12386, ptr %slot2259, align 8
  %v12387 = load i64, ptr %slot43, align 8
  store i64 %v12387, ptr %slot2260, align 8
  %v12388 = load i64, ptr %slot2260, align 8
  %v12389 = load i64, ptr %slot2259, align 8
  %p12390 = inttoptr i64 %v12388 to ptr
  %p12391 = inttoptr i64 %v12389 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12391, ptr %p12390, i64 208, i1 false), !alias.scope !10000000
  %v12392 = load i64, ptr %slot2260, align 8
  %p12393 = inttoptr i64 %v12392 to ptr
  call void @llvm.memset.p0.i64(ptr %p12393, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v12394 = load i64, ptr %slot15, align 8
  %p12395 = inttoptr i64 %v12394 to ptr
  store i32 0, ptr %p12395, align 4, !alias.scope !3, !noalias !4
  %v12396 = load i64, ptr %slot44, align 8
  %p12397 = inttoptr i64 %v12396 to ptr
  store i64 0, ptr %p12397, align 8, !alias.scope !3, !noalias !4
  %v12398 = load i64, ptr %slot44, align 8
  %p12399 = inttoptr i64 %v12398 to ptr
  store i64 0, ptr %p12399, align 8, !alias.scope !3, !noalias !4
  %v12400 = load i64, ptr %slot57, align 8
  store i64 %v12400, ptr %slot2261, align 8
  %v12401 = load i64, ptr %slot2261, align 8
  %p12402 = inttoptr i64 %v12401 to ptr
  store i64 0, ptr %p12402, align 8, !alias.scope !3, !noalias !4
  %v12403 = load i64, ptr %slot2261, align 8
  %p12405 = inttoptr i64 %v12403 to ptr
  %gep12406 = getelementptr i8, ptr %p12405, i64 8
  %op12404 = ptrtoint ptr %gep12406 to i64
  store i64 %op12404, ptr %slot2262, align 8
  %v12407 = load i64, ptr %slot2262, align 8
  %p12408 = inttoptr i64 %v12407 to ptr
  store i64 0, ptr %p12408, align 8, !alias.scope !3, !noalias !4
  %v12409 = load i64, ptr %slot2261, align 8
  %p12411 = inttoptr i64 %v12409 to ptr
  %gep12412 = getelementptr i8, ptr %p12411, i64 16
  %op12410 = ptrtoint ptr %gep12412 to i64
  store i64 %op12410, ptr %slot2263, align 8
  %v12413 = load i64, ptr %slot2263, align 8
  %p12414 = inttoptr i64 %v12413 to ptr
  store i64 0, ptr %p12414, align 8, !alias.scope !3, !noalias !4
  %v12415 = load i64, ptr %slot2261, align 8
  %p12416 = inttoptr i64 %v12415 to ptr
  store i32 0, ptr %p12416, align 4, !alias.scope !3, !noalias !4
  %v12417 = load i64, ptr %slot21, align 8
  %p12418 = inttoptr i64 %v12417 to ptr
  store i32 1, ptr %p12418, align 4, !alias.scope !3, !noalias !4
  %v12419 = load i64, ptr %slot44, align 8
  store i64 %v12419, ptr %slot2264, align 8
  %v12420 = load i64, ptr %slot2261, align 8
  %p12422 = inttoptr i64 %v12420 to ptr
  %gep12423 = getelementptr i8, ptr %p12422, i64 8
  %op12421 = ptrtoint ptr %gep12423 to i64
  store i64 %op12421, ptr %slot2265, align 8
  %v12424 = load i64, ptr %slot64, align 8
  store i64 %v12424, ptr %slot2266, align 8
  store i64 0, ptr %slot2267, align 8
  %v12425 = load i64, ptr %slot2261, align 8
  %v12426 = load i64, ptr %slot44, align 8
  %p12427 = inttoptr i64 %v12426 to ptr
  store i64 %v12425, ptr %p12427, align 8, !alias.scope !3, !noalias !4
  %v12428 = load i64, ptr %slot44, align 8
  %p12429 = inttoptr i64 %v12428 to ptr
  %ld12430 = load i64, ptr %p12429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12430, ptr %slot2268, align 8
  %v12431 = load i64, ptr %slot22, align 8
  store i64 %v12431, ptr %slot2269, align 8
  %v12432 = load i64, ptr %slot2268, align 8
  %v12433 = load i64, ptr %slot2269, align 8
  %p12434 = inttoptr i64 %v12432 to ptr
  %p12435 = inttoptr i64 %v12433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12435, ptr %p12434, i64 24, i1 false)
  %v12436 = load i64, ptr %slot18, align 8
  %p12437 = inttoptr i64 %v12436 to ptr
  store i32 2, ptr %p12437, align 4, !alias.scope !3, !noalias !4
  %v12438 = load i64, ptr %slot17, align 8
  %p12439 = inttoptr i64 %v12438 to ptr
  store i32 1, ptr %p12439, align 4, !alias.scope !3, !noalias !4
  %v12440 = load i64, ptr %slot2269, align 8
  %v12441 = load i64, ptr %slot44, align 8
  %p12442 = inttoptr i64 %v12441 to ptr
  store i64 %v12440, ptr %p12442, align 8, !alias.scope !3, !noalias !4
  %v12443 = load i64, ptr %slot44, align 8
  %p12444 = inttoptr i64 %v12443 to ptr
  %ld12445 = load i64, ptr %p12444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12445, ptr %slot2270, align 8
  %v12446 = load i64, ptr %slot44, align 8
  %p12447 = inttoptr i64 %v12446 to ptr
  %ld12448 = load i64, ptr %p12447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12448, ptr %slot2271, align 8
  %v12449 = load i64, ptr %slot24, align 8
  store i64 %v12449, ptr %slot2272, align 8
  %v12450 = load i64, ptr %slot64, align 8
  store i64 %v12450, ptr %slot2273, align 8
  %v12451 = load i64, ptr %slot63, align 8
  %v12452 = load i64, ptr %slot2272, align 8
  %v12453 = load i64, ptr %slot2271, align 8
  %v12454 = load i64, ptr %slot2273, align 8
  %cv12455 = trunc i64 %v12454 to i32
  %call12456 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v12451, i64 %v12452, i64 %v12453, i32 %cv12455) nomerge, !dbg !210
  store i32 %call12456, ptr %slot2274, align 8
  %v12457 = load i32, ptr %slot2274, align 8
  %cv12458 = zext i32 %v12457 to i64
  %cond12459 = icmp ne i64 %cv12458, 0
  br i1 %cond12459, label %bb_rcsuccess3506, label %bb_rcfailure3506
bb_rcfailure3506:
  %v12460 = load i64, ptr %slot63, align 8
  %p12461 = inttoptr i64 %v12460 to ptr
  %call12462 = call i32 @myl_rc_take_failure(ptr %p12461) nomerge, !dbg !210
  store i32 %call12462, ptr %slot2275, align 8
  %v12463 = load i64, ptr %slot1, align 8
  %p12464 = inttoptr i64 %v12463 to ptr
  %v12465 = load i32, ptr %slot2275, align 8
  %call12466 = call i32 @myl_qbe_rc_status(ptr %p12464, i32 %v12465) nomerge, !dbg !210
  store i32 %call12466, ptr %slot2276, align 8
  br label %bb_failure
bb_rcsuccess3506:
  %v12467 = load i64, ptr %slot17, align 8
  %p12468 = inttoptr i64 %v12467 to ptr
  store i32 0, ptr %p12468, align 4, !alias.scope !3, !noalias !4
  %v12469 = load i64, ptr %slot20, align 8
  %p12470 = inttoptr i64 %v12469 to ptr
  store i32 2, ptr %p12470, align 4, !alias.scope !3, !noalias !4
  %v12471 = load i64, ptr %slot19, align 8
  %p12472 = inttoptr i64 %v12471 to ptr
  store i32 1, ptr %p12472, align 4, !alias.scope !3, !noalias !4
  %v12473 = load i64, ptr %slot24, align 8
  store i64 %v12473, ptr %slot2277, align 8
  %v12474 = load i64, ptr %slot19, align 8
  %p12475 = inttoptr i64 %v12474 to ptr
  store i32 0, ptr %p12475, align 4, !alias.scope !3, !noalias !4
  %v12476 = load i64, ptr %slot17, align 8
  %p12477 = inttoptr i64 %v12476 to ptr
  %ld12478 = load i32, ptr %p12477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12478, ptr %slot2278, align 8
  %v12479 = load i32, ptr %slot2278, align 8
  %cv12480 = zext i32 %v12479 to i64
  %cond12481 = icmp ne i64 %cv12480, 0
  br i1 %cond12481, label %bb_rcslotdrop3516, label %bb_rcslotdone3516
bb_rcslotdrop3516:
  %v12482 = load i64, ptr %slot17, align 8
  %p12483 = inttoptr i64 %v12482 to ptr
  store i32 0, ptr %p12483, align 4, !alias.scope !3, !noalias !4
  %v12484 = load i64, ptr %slot22, align 8
  store i64 %v12484, ptr %slot2279, align 8
  %v12485 = load i64, ptr %slot18, align 8
  %p12486 = inttoptr i64 %v12485 to ptr
  %ld12487 = load i32, ptr %p12486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12487, ptr %slot2280, align 8
  %v12488 = load i32, ptr %slot2280, align 8
  %op12489 = and i32 %v12488, 28
  store i32 %op12489, ptr %slot2281, align 8
  %v12490 = load i32, ptr %slot2281, align 8
  %cv12491 = zext i32 %v12490 to i64
  %cond12492 = icmp ne i64 %cv12491, 0
  br i1 %cond12492, label %bb_rcslotrole3516, label %bb_rcslotowner3516
bb_rcslotrole3516:
  %v12493 = load i64, ptr %slot63, align 8
  store i64 %v12493, ptr %slot2282, align 8
  %v12494 = load i64, ptr %slot2282, align 8
  %v12495 = load i64, ptr %slot2279, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v12494, i64 %v12495) nomerge, !dbg !210
  br label %bb_rcslotdone3516
bb_rcslotowner3516:
  %v12496 = load i64, ptr %slot63, align 8
  store i64 %v12496, ptr %slot2283, align 8
  %v12497 = load i64, ptr %slot2283, align 8
  %v12498 = load i64, ptr %slot2279, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v12497, i64 %v12498) nomerge, !dbg !210
  br label %bb_rcslotdone3516
bb_rcslotdone3516:
  %v12499 = load i64, ptr %slot15, align 8
  %p12500 = inttoptr i64 %v12499 to ptr
  %ld12501 = load i32, ptr %p12500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12501, ptr %slot2284, align 8
  %v12502 = load i32, ptr %slot2284, align 8
  %cv12503 = zext i32 %v12502 to i64
  %cond12504 = icmp ne i64 %cv12503, 0
  br i1 %cond12504, label %bb_rcslotdrop3543, label %bb_rcslotdone3543
bb_rcslotdrop3543:
  %v12505 = load i64, ptr %slot15, align 8
  %p12506 = inttoptr i64 %v12505 to ptr
  store i32 0, ptr %p12506, align 4, !alias.scope !3, !noalias !4
  %v12507 = load i64, ptr %slot43, align 8
  store i64 %v12507, ptr %slot2285, align 8
  %v12508 = load i64, ptr %slot16, align 8
  %p12509 = inttoptr i64 %v12508 to ptr
  %ld12510 = load i32, ptr %p12509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12510, ptr %slot2286, align 8
  %v12511 = load i32, ptr %slot2286, align 8
  %op12512 = and i32 %v12511, 28
  store i32 %op12512, ptr %slot2287, align 8
  %v12513 = load i32, ptr %slot2287, align 8
  %cv12514 = zext i32 %v12513 to i64
  %cond12515 = icmp ne i64 %cv12514, 0
  br i1 %cond12515, label %bb_rcslotrole3543, label %bb_rcslotowner3543
bb_rcslotrole3543:
  %v12516 = load i64, ptr %slot63, align 8
  store i64 %v12516, ptr %slot2288, align 8
  %v12517 = load i64, ptr %slot2288, align 8
  %v12518 = load i64, ptr %slot2285, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12517, i64 %v12518) nomerge, !dbg !210
  br label %bb_rcslotdone3543
bb_rcslotowner3543:
  %v12519 = load i64, ptr %slot63, align 8
  store i64 %v12519, ptr %slot2289, align 8
  %v12520 = load i64, ptr %slot2289, align 8
  %v12521 = load i64, ptr %slot2285, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12520, i64 %v12521) nomerge, !dbg !210
  br label %bb_rcslotdone3543
bb_rcslotdone3543:
  %v12522 = load i64, ptr %slot13, align 8
  %p12523 = inttoptr i64 %v12522 to ptr
  %ld12524 = load i32, ptr %p12523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12524, ptr %slot2290, align 8
  %v12525 = load i32, ptr %slot2290, align 8
  %cv12526 = zext i32 %v12525 to i64
  %cond12527 = icmp ne i64 %cv12526, 0
  br i1 %cond12527, label %bb_rcslotdrop3552, label %bb_rcslotdone3552
bb_rcslotdrop3552:
  %v12528 = load i64, ptr %slot13, align 8
  %p12529 = inttoptr i64 %v12528 to ptr
  store i32 0, ptr %p12529, align 4, !alias.scope !3, !noalias !4
  %v12530 = load i64, ptr %slot42, align 8
  store i64 %v12530, ptr %slot2291, align 8
  %v12531 = load i64, ptr %slot14, align 8
  %p12532 = inttoptr i64 %v12531 to ptr
  %ld12533 = load i32, ptr %p12532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12533, ptr %slot2292, align 8
  %v12534 = load i32, ptr %slot2292, align 8
  %op12535 = and i32 %v12534, 28
  store i32 %op12535, ptr %slot2293, align 8
  %v12536 = load i32, ptr %slot2293, align 8
  %cv12537 = zext i32 %v12536 to i64
  %cond12538 = icmp ne i64 %cv12537, 0
  br i1 %cond12538, label %bb_rcslotrole3552, label %bb_rcslotowner3552
bb_rcslotrole3552:
  %v12539 = load i64, ptr %slot63, align 8
  store i64 %v12539, ptr %slot2294, align 8
  %v12540 = load i64, ptr %slot2291, align 8
  %p12541 = inttoptr i64 %v12540 to ptr
  %ld12542 = load i64, ptr %p12541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12542, ptr %slot2295, align 8
  %v12543 = load i64, ptr %slot2295, align 8
  %cmp12544 = icmp ne i64 %v12543, 0
  %cv12545 = zext i1 %cmp12544 to i32
  store i32 %cv12545, ptr %slot2296, align 8
  %v12546 = load i32, ptr %slot2296, align 8
  %cv12547 = zext i32 %v12546 to i64
  %cond12548 = icmp ne i64 %cv12547, 0
  br i1 %cond12548, label %bb_rcgnn3568, label %bb_rcgdone3568
bb_rcgnn3568:
  %v12549 = load i64, ptr %slot2295, align 8
  %op12550 = sub i64 %v12549, 16
  store i64 %op12550, ptr %slot2297, align 8
  %v12551 = load i64, ptr %slot2295, align 8
  %p12552 = inttoptr i64 %v12551 to ptr
  %rgep12553 = getelementptr i8, ptr %p12552, i64 -16
  %ld12554 = load i64, ptr %rgep12553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12554, ptr %slot2298, align 8
  %v12555 = load i64, ptr %slot2298, align 8
  %op12556 = and i64 %v12555, 4611686018427387906
  store i64 %op12556, ptr %slot2299, align 8
  %v12557 = load i64, ptr %slot2299, align 8
  %cmp12558 = icmp ne i64 %v12557, 0
  %cv12559 = zext i1 %cmp12558 to i32
  store i32 %cv12559, ptr %slot2300, align 8
  %v12560 = load i32, ptr %slot2300, align 8
  %cv12561 = zext i32 %v12560 to i64
  %cond12562 = icmp ne i64 %cv12561, 0
  br i1 %cond12562, label %bb_rcgclear3568, label %bb_rcgcounted3568
bb_rcgcounted3568:
  %v12563 = load i64, ptr %slot2295, align 8
  %op12564 = sub i64 %v12563, 24
  store i64 %op12564, ptr %slot2301, align 8
  %v12565 = load i64, ptr %slot2295, align 8
  %p12566 = inttoptr i64 %v12565 to ptr
  %rgep12567 = getelementptr i8, ptr %p12566, i64 -24
  %ld12568 = load i64, ptr %rgep12567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12568, ptr %slot2302, align 8
  %v12569 = load i64, ptr %slot2302, align 8
  %op12570 = sub i64 %v12569, 1
  store i64 %op12570, ptr %slot2303, align 8
  %v12571 = load i64, ptr %slot2303, align 8
  %cmp12572 = icmp eq i64 %v12571, 0
  %cv12573 = zext i1 %cmp12572 to i32
  store i32 %cv12573, ptr %slot2304, align 8
  %v12574 = load i32, ptr %slot2304, align 8
  %cv12575 = zext i32 %v12574 to i64
  %cond12576 = icmp ne i64 %cv12575, 0
  br i1 %cond12576, label %bb_rcglast3568, label %bb_rcgdec3568
bb_rcglast3568:
  %v12577 = load i64, ptr %slot2295, align 8
  %op12578 = sub i64 %v12577, 32
  store i64 %op12578, ptr %slot2305, align 8
  %v12579 = load i64, ptr %slot2295, align 8
  %p12580 = inttoptr i64 %v12579 to ptr
  %rgep12581 = getelementptr i8, ptr %p12580, i64 -32
  %ld12582 = load i64, ptr %rgep12581, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12582, ptr %slot2306, align 8
  %v12583 = load i64, ptr %slot2306, align 8
  %cmp12584 = icmp ne i64 %v12583, 0
  %cv12585 = zext i1 %cmp12584 to i32
  store i32 %cv12585, ptr %slot2307, align 8
  %v12586 = load i32, ptr %slot2307, align 8
  %cv12587 = zext i32 %v12586 to i64
  %cond12588 = icmp ne i64 %cv12587, 0
  br i1 %cond12588, label %bb_rcgdec3568, label %bb_rcgslow3568
bb_rcgslow3568:
  %v12589 = load i64, ptr %slot2294, align 8
  %v12590 = load i64, ptr %slot2291, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v12589, i64 %v12590) nomerge, !dbg !210
  br label %bb_rcgdone3568
bb_rcgdec3568:
  %v12591 = load i64, ptr %slot2303, align 8
  %v12592 = load i64, ptr %slot2295, align 8
  %p12593 = inttoptr i64 %v12592 to ptr
  %rgep12594 = getelementptr i8, ptr %p12593, i64 -24
  store i64 %v12591, ptr %rgep12594, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3568
bb_rcgclear3568:
  %v12595 = load i64, ptr %slot2291, align 8
  %p12596 = inttoptr i64 %v12595 to ptr
  store i64 0, ptr %p12596, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3568
bb_rcgdone3568:
  br label %bb_rcslotdone3552
bb_rcslotowner3552:
  %v12597 = load i64, ptr %slot63, align 8
  store i64 %v12597, ptr %slot2308, align 8
  %v12598 = load i64, ptr %slot2291, align 8
  %p12599 = inttoptr i64 %v12598 to ptr
  %ld12600 = load i64, ptr %p12599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12600, ptr %slot2309, align 8
  %v12601 = load i64, ptr %slot2309, align 8
  %cmp12602 = icmp ne i64 %v12601, 0
  %cv12603 = zext i1 %cmp12602 to i32
  store i32 %cv12603, ptr %slot2310, align 8
  %v12604 = load i32, ptr %slot2310, align 8
  %cv12605 = zext i32 %v12604 to i64
  %cond12606 = icmp ne i64 %cv12605, 0
  br i1 %cond12606, label %bb_rcgnn3583, label %bb_rcgdone3583
bb_rcgnn3583:
  %v12607 = load i64, ptr %slot2309, align 8
  %op12608 = sub i64 %v12607, 16
  store i64 %op12608, ptr %slot2311, align 8
  %v12609 = load i64, ptr %slot2309, align 8
  %p12610 = inttoptr i64 %v12609 to ptr
  %rgep12611 = getelementptr i8, ptr %p12610, i64 -16
  %ld12612 = load i64, ptr %rgep12611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12612, ptr %slot2312, align 8
  %v12613 = load i64, ptr %slot2312, align 8
  %op12614 = and i64 %v12613, 4611686018427387906
  store i64 %op12614, ptr %slot2313, align 8
  %v12615 = load i64, ptr %slot2313, align 8
  %cmp12616 = icmp ne i64 %v12615, 0
  %cv12617 = zext i1 %cmp12616 to i32
  store i32 %cv12617, ptr %slot2314, align 8
  %v12618 = load i32, ptr %slot2314, align 8
  %cv12619 = zext i32 %v12618 to i64
  %cond12620 = icmp ne i64 %cv12619, 0
  br i1 %cond12620, label %bb_rcgclear3583, label %bb_rcgcounted3583
bb_rcgcounted3583:
  %v12621 = load i64, ptr %slot2309, align 8
  %op12622 = sub i64 %v12621, 32
  store i64 %op12622, ptr %slot2315, align 8
  %v12623 = load i64, ptr %slot2309, align 8
  %p12624 = inttoptr i64 %v12623 to ptr
  %rgep12625 = getelementptr i8, ptr %p12624, i64 -32
  %ld12626 = load i64, ptr %rgep12625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12626, ptr %slot2316, align 8
  %v12627 = load i64, ptr %slot2316, align 8
  %op12628 = sub i64 %v12627, 1
  store i64 %op12628, ptr %slot2317, align 8
  %v12629 = load i64, ptr %slot2317, align 8
  %cmp12630 = icmp eq i64 %v12629, 0
  %cv12631 = zext i1 %cmp12630 to i32
  store i32 %cv12631, ptr %slot2318, align 8
  %v12632 = load i32, ptr %slot2318, align 8
  %cv12633 = zext i32 %v12632 to i64
  %cond12634 = icmp ne i64 %cv12633, 0
  br i1 %cond12634, label %bb_rcglast3583, label %bb_rcgdec3583
bb_rcglast3583:
  %v12635 = load i64, ptr %slot2309, align 8
  %op12636 = sub i64 %v12635, 24
  store i64 %op12636, ptr %slot2319, align 8
  %v12637 = load i64, ptr %slot2309, align 8
  %p12638 = inttoptr i64 %v12637 to ptr
  %rgep12639 = getelementptr i8, ptr %p12638, i64 -24
  %ld12640 = load i64, ptr %rgep12639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12640, ptr %slot2320, align 8
  %v12641 = load i64, ptr %slot2320, align 8
  %cmp12642 = icmp ne i64 %v12641, 0
  %cv12643 = zext i1 %cmp12642 to i32
  store i32 %cv12643, ptr %slot2321, align 8
  %v12644 = load i32, ptr %slot2321, align 8
  %cv12645 = zext i32 %v12644 to i64
  %cond12646 = icmp ne i64 %cv12645, 0
  br i1 %cond12646, label %bb_rcgdec3583, label %bb_rcgslow3583
bb_rcgslow3583:
  %v12647 = load i64, ptr %slot2308, align 8
  %v12648 = load i64, ptr %slot2291, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v12647, i64 %v12648) nomerge, !dbg !210
  br label %bb_rcgdone3583
bb_rcgdec3583:
  %v12649 = load i64, ptr %slot2317, align 8
  %v12650 = load i64, ptr %slot2309, align 8
  %p12651 = inttoptr i64 %v12650 to ptr
  %rgep12652 = getelementptr i8, ptr %p12651, i64 -32
  store i64 %v12649, ptr %rgep12652, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3583
bb_rcgclear3583:
  %v12653 = load i64, ptr %slot2291, align 8
  %p12654 = inttoptr i64 %v12653 to ptr
  store i64 0, ptr %p12654, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3583
bb_rcgdone3583:
  br label %bb_rcslotdone3552
bb_rcslotdone3552:
  %v12655 = load i64, ptr %slot11, align 8
  %p12656 = inttoptr i64 %v12655 to ptr
  %ld12657 = load i32, ptr %p12656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12657, ptr %slot2322, align 8
  %v12658 = load i32, ptr %slot2322, align 8
  %cv12659 = zext i32 %v12658 to i64
  %cond12660 = icmp ne i64 %cv12659, 0
  br i1 %cond12660, label %bb_rcslotdrop3589, label %bb_rcslotdone3589
bb_rcslotdrop3589:
  %v12661 = load i64, ptr %slot11, align 8
  %p12662 = inttoptr i64 %v12661 to ptr
  store i32 0, ptr %p12662, align 4, !alias.scope !3, !noalias !4
  %v12663 = load i64, ptr %slot41, align 8
  store i64 %v12663, ptr %slot2323, align 8
  %v12664 = load i64, ptr %slot12, align 8
  %p12665 = inttoptr i64 %v12664 to ptr
  %ld12666 = load i32, ptr %p12665, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12666, ptr %slot2324, align 8
  %v12667 = load i32, ptr %slot2324, align 8
  %op12668 = and i32 %v12667, 28
  store i32 %op12668, ptr %slot2325, align 8
  %v12669 = load i32, ptr %slot2325, align 8
  %cv12670 = zext i32 %v12669 to i64
  %cond12671 = icmp ne i64 %cv12670, 0
  br i1 %cond12671, label %bb_rcslotrole3589, label %bb_rcslotowner3589
bb_rcslotrole3589:
  %v12672 = load i64, ptr %slot63, align 8
  store i64 %v12672, ptr %slot2326, align 8
  %v12673 = load i64, ptr %slot2323, align 8
  %p12674 = inttoptr i64 %v12673 to ptr
  %ld12675 = load i64, ptr %p12674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12675, ptr %slot2327, align 8
  %v12676 = load i64, ptr %slot2327, align 8
  %cmp12677 = icmp ne i64 %v12676, 0
  %cv12678 = zext i1 %cmp12677 to i32
  store i32 %cv12678, ptr %slot2328, align 8
  %v12679 = load i32, ptr %slot2328, align 8
  %cv12680 = zext i32 %v12679 to i64
  %cond12681 = icmp ne i64 %cv12680, 0
  br i1 %cond12681, label %bb_rcgnn3605, label %bb_rcgdone3605
bb_rcgnn3605:
  %v12682 = load i64, ptr %slot2327, align 8
  %op12683 = sub i64 %v12682, 16
  store i64 %op12683, ptr %slot2329, align 8
  %v12684 = load i64, ptr %slot2327, align 8
  %p12685 = inttoptr i64 %v12684 to ptr
  %rgep12686 = getelementptr i8, ptr %p12685, i64 -16
  %ld12687 = load i64, ptr %rgep12686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12687, ptr %slot2330, align 8
  %v12688 = load i64, ptr %slot2330, align 8
  %op12689 = and i64 %v12688, 4611686018427387906
  store i64 %op12689, ptr %slot2331, align 8
  %v12690 = load i64, ptr %slot2331, align 8
  %cmp12691 = icmp ne i64 %v12690, 0
  %cv12692 = zext i1 %cmp12691 to i32
  store i32 %cv12692, ptr %slot2332, align 8
  %v12693 = load i32, ptr %slot2332, align 8
  %cv12694 = zext i32 %v12693 to i64
  %cond12695 = icmp ne i64 %cv12694, 0
  br i1 %cond12695, label %bb_rcgclear3605, label %bb_rcgcounted3605
bb_rcgcounted3605:
  %v12696 = load i64, ptr %slot2327, align 8
  %op12697 = sub i64 %v12696, 24
  store i64 %op12697, ptr %slot2333, align 8
  %v12698 = load i64, ptr %slot2327, align 8
  %p12699 = inttoptr i64 %v12698 to ptr
  %rgep12700 = getelementptr i8, ptr %p12699, i64 -24
  %ld12701 = load i64, ptr %rgep12700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12701, ptr %slot2334, align 8
  %v12702 = load i64, ptr %slot2334, align 8
  %op12703 = sub i64 %v12702, 1
  store i64 %op12703, ptr %slot2335, align 8
  %v12704 = load i64, ptr %slot2335, align 8
  %cmp12705 = icmp eq i64 %v12704, 0
  %cv12706 = zext i1 %cmp12705 to i32
  store i32 %cv12706, ptr %slot2336, align 8
  %v12707 = load i32, ptr %slot2336, align 8
  %cv12708 = zext i32 %v12707 to i64
  %cond12709 = icmp ne i64 %cv12708, 0
  br i1 %cond12709, label %bb_rcglast3605, label %bb_rcgdec3605
bb_rcglast3605:
  %v12710 = load i64, ptr %slot2327, align 8
  %op12711 = sub i64 %v12710, 32
  store i64 %op12711, ptr %slot2337, align 8
  %v12712 = load i64, ptr %slot2327, align 8
  %p12713 = inttoptr i64 %v12712 to ptr
  %rgep12714 = getelementptr i8, ptr %p12713, i64 -32
  %ld12715 = load i64, ptr %rgep12714, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12715, ptr %slot2338, align 8
  %v12716 = load i64, ptr %slot2338, align 8
  %cmp12717 = icmp ne i64 %v12716, 0
  %cv12718 = zext i1 %cmp12717 to i32
  store i32 %cv12718, ptr %slot2339, align 8
  %v12719 = load i32, ptr %slot2339, align 8
  %cv12720 = zext i32 %v12719 to i64
  %cond12721 = icmp ne i64 %cv12720, 0
  br i1 %cond12721, label %bb_rcgdec3605, label %bb_rcgslow3605
bb_rcgslow3605:
  %v12722 = load i64, ptr %slot2326, align 8
  %v12723 = load i64, ptr %slot2323, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v12722, i64 %v12723) nomerge, !dbg !210
  br label %bb_rcgdone3605
bb_rcgdec3605:
  %v12724 = load i64, ptr %slot2335, align 8
  %v12725 = load i64, ptr %slot2327, align 8
  %p12726 = inttoptr i64 %v12725 to ptr
  %rgep12727 = getelementptr i8, ptr %p12726, i64 -24
  store i64 %v12724, ptr %rgep12727, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3605
bb_rcgclear3605:
  %v12728 = load i64, ptr %slot2323, align 8
  %p12729 = inttoptr i64 %v12728 to ptr
  store i64 0, ptr %p12729, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3605
bb_rcgdone3605:
  br label %bb_rcslotdone3589
bb_rcslotowner3589:
  %v12730 = load i64, ptr %slot63, align 8
  store i64 %v12730, ptr %slot2340, align 8
  %v12731 = load i64, ptr %slot2323, align 8
  %p12732 = inttoptr i64 %v12731 to ptr
  %ld12733 = load i64, ptr %p12732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12733, ptr %slot2341, align 8
  %v12734 = load i64, ptr %slot2341, align 8
  %cmp12735 = icmp ne i64 %v12734, 0
  %cv12736 = zext i1 %cmp12735 to i32
  store i32 %cv12736, ptr %slot2342, align 8
  %v12737 = load i32, ptr %slot2342, align 8
  %cv12738 = zext i32 %v12737 to i64
  %cond12739 = icmp ne i64 %cv12738, 0
  br i1 %cond12739, label %bb_rcgnn3620, label %bb_rcgdone3620
bb_rcgnn3620:
  %v12740 = load i64, ptr %slot2341, align 8
  %op12741 = sub i64 %v12740, 16
  store i64 %op12741, ptr %slot2343, align 8
  %v12742 = load i64, ptr %slot2341, align 8
  %p12743 = inttoptr i64 %v12742 to ptr
  %rgep12744 = getelementptr i8, ptr %p12743, i64 -16
  %ld12745 = load i64, ptr %rgep12744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12745, ptr %slot2344, align 8
  %v12746 = load i64, ptr %slot2344, align 8
  %op12747 = and i64 %v12746, 4611686018427387906
  store i64 %op12747, ptr %slot2345, align 8
  %v12748 = load i64, ptr %slot2345, align 8
  %cmp12749 = icmp ne i64 %v12748, 0
  %cv12750 = zext i1 %cmp12749 to i32
  store i32 %cv12750, ptr %slot2346, align 8
  %v12751 = load i32, ptr %slot2346, align 8
  %cv12752 = zext i32 %v12751 to i64
  %cond12753 = icmp ne i64 %cv12752, 0
  br i1 %cond12753, label %bb_rcgclear3620, label %bb_rcgcounted3620
bb_rcgcounted3620:
  %v12754 = load i64, ptr %slot2341, align 8
  %op12755 = sub i64 %v12754, 32
  store i64 %op12755, ptr %slot2347, align 8
  %v12756 = load i64, ptr %slot2341, align 8
  %p12757 = inttoptr i64 %v12756 to ptr
  %rgep12758 = getelementptr i8, ptr %p12757, i64 -32
  %ld12759 = load i64, ptr %rgep12758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12759, ptr %slot2348, align 8
  %v12760 = load i64, ptr %slot2348, align 8
  %op12761 = sub i64 %v12760, 1
  store i64 %op12761, ptr %slot2349, align 8
  %v12762 = load i64, ptr %slot2349, align 8
  %cmp12763 = icmp eq i64 %v12762, 0
  %cv12764 = zext i1 %cmp12763 to i32
  store i32 %cv12764, ptr %slot2350, align 8
  %v12765 = load i32, ptr %slot2350, align 8
  %cv12766 = zext i32 %v12765 to i64
  %cond12767 = icmp ne i64 %cv12766, 0
  br i1 %cond12767, label %bb_rcglast3620, label %bb_rcgdec3620
bb_rcglast3620:
  %v12768 = load i64, ptr %slot2341, align 8
  %op12769 = sub i64 %v12768, 24
  store i64 %op12769, ptr %slot2351, align 8
  %v12770 = load i64, ptr %slot2341, align 8
  %p12771 = inttoptr i64 %v12770 to ptr
  %rgep12772 = getelementptr i8, ptr %p12771, i64 -24
  %ld12773 = load i64, ptr %rgep12772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12773, ptr %slot2352, align 8
  %v12774 = load i64, ptr %slot2352, align 8
  %cmp12775 = icmp ne i64 %v12774, 0
  %cv12776 = zext i1 %cmp12775 to i32
  store i32 %cv12776, ptr %slot2353, align 8
  %v12777 = load i32, ptr %slot2353, align 8
  %cv12778 = zext i32 %v12777 to i64
  %cond12779 = icmp ne i64 %cv12778, 0
  br i1 %cond12779, label %bb_rcgdec3620, label %bb_rcgslow3620
bb_rcgslow3620:
  %v12780 = load i64, ptr %slot2340, align 8
  %v12781 = load i64, ptr %slot2323, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v12780, i64 %v12781) nomerge, !dbg !210
  br label %bb_rcgdone3620
bb_rcgdec3620:
  %v12782 = load i64, ptr %slot2349, align 8
  %v12783 = load i64, ptr %slot2341, align 8
  %p12784 = inttoptr i64 %v12783 to ptr
  %rgep12785 = getelementptr i8, ptr %p12784, i64 -32
  store i64 %v12782, ptr %rgep12785, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3620
bb_rcgclear3620:
  %v12786 = load i64, ptr %slot2323, align 8
  %p12787 = inttoptr i64 %v12786 to ptr
  store i64 0, ptr %p12787, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3620
bb_rcgdone3620:
  br label %bb_rcslotdone3589
bb_rcslotdone3589:
  %v12788 = load i64, ptr %slot9, align 8
  %p12789 = inttoptr i64 %v12788 to ptr
  %ld12790 = load i32, ptr %p12789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12790, ptr %slot2354, align 8
  %v12791 = load i32, ptr %slot2354, align 8
  %cv12792 = zext i32 %v12791 to i64
  %cond12793 = icmp ne i64 %cv12792, 0
  br i1 %cond12793, label %bb_rcslotdrop3626, label %bb_rcslotdone3626
bb_rcslotdrop3626:
  %v12794 = load i64, ptr %slot9, align 8
  %p12795 = inttoptr i64 %v12794 to ptr
  store i32 0, ptr %p12795, align 4, !alias.scope !3, !noalias !4
  %v12796 = load i64, ptr %slot40, align 8
  store i64 %v12796, ptr %slot2355, align 8
  %v12797 = load i64, ptr %slot10, align 8
  %p12798 = inttoptr i64 %v12797 to ptr
  %ld12799 = load i32, ptr %p12798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12799, ptr %slot2356, align 8
  %v12800 = load i32, ptr %slot2356, align 8
  %op12801 = and i32 %v12800, 28
  store i32 %op12801, ptr %slot2357, align 8
  %v12802 = load i32, ptr %slot2357, align 8
  %cv12803 = zext i32 %v12802 to i64
  %cond12804 = icmp ne i64 %cv12803, 0
  br i1 %cond12804, label %bb_rcslotrole3626, label %bb_rcslotowner3626
bb_rcslotrole3626:
  %v12805 = load i64, ptr %slot63, align 8
  store i64 %v12805, ptr %slot2358, align 8
  %v12806 = load i64, ptr %slot2355, align 8
  %p12807 = inttoptr i64 %v12806 to ptr
  %ld12808 = load i64, ptr %p12807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12808, ptr %slot2359, align 8
  %v12809 = load i64, ptr %slot2359, align 8
  %cmp12810 = icmp ne i64 %v12809, 0
  %cv12811 = zext i1 %cmp12810 to i32
  store i32 %cv12811, ptr %slot2360, align 8
  %v12812 = load i32, ptr %slot2360, align 8
  %cv12813 = zext i32 %v12812 to i64
  %cond12814 = icmp ne i64 %cv12813, 0
  br i1 %cond12814, label %bb_rcgnn3642, label %bb_rcgdone3642
bb_rcgnn3642:
  %v12815 = load i64, ptr %slot2359, align 8
  %op12816 = sub i64 %v12815, 16
  store i64 %op12816, ptr %slot2361, align 8
  %v12817 = load i64, ptr %slot2359, align 8
  %p12818 = inttoptr i64 %v12817 to ptr
  %rgep12819 = getelementptr i8, ptr %p12818, i64 -16
  %ld12820 = load i64, ptr %rgep12819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12820, ptr %slot2362, align 8
  %v12821 = load i64, ptr %slot2362, align 8
  %op12822 = and i64 %v12821, 4611686018427387906
  store i64 %op12822, ptr %slot2363, align 8
  %v12823 = load i64, ptr %slot2363, align 8
  %cmp12824 = icmp ne i64 %v12823, 0
  %cv12825 = zext i1 %cmp12824 to i32
  store i32 %cv12825, ptr %slot2364, align 8
  %v12826 = load i32, ptr %slot2364, align 8
  %cv12827 = zext i32 %v12826 to i64
  %cond12828 = icmp ne i64 %cv12827, 0
  br i1 %cond12828, label %bb_rcgclear3642, label %bb_rcgcounted3642
bb_rcgcounted3642:
  %v12829 = load i64, ptr %slot2359, align 8
  %op12830 = sub i64 %v12829, 24
  store i64 %op12830, ptr %slot2365, align 8
  %v12831 = load i64, ptr %slot2359, align 8
  %p12832 = inttoptr i64 %v12831 to ptr
  %rgep12833 = getelementptr i8, ptr %p12832, i64 -24
  %ld12834 = load i64, ptr %rgep12833, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12834, ptr %slot2366, align 8
  %v12835 = load i64, ptr %slot2366, align 8
  %op12836 = sub i64 %v12835, 1
  store i64 %op12836, ptr %slot2367, align 8
  %v12837 = load i64, ptr %slot2367, align 8
  %cmp12838 = icmp eq i64 %v12837, 0
  %cv12839 = zext i1 %cmp12838 to i32
  store i32 %cv12839, ptr %slot2368, align 8
  %v12840 = load i32, ptr %slot2368, align 8
  %cv12841 = zext i32 %v12840 to i64
  %cond12842 = icmp ne i64 %cv12841, 0
  br i1 %cond12842, label %bb_rcglast3642, label %bb_rcgdec3642
bb_rcglast3642:
  %v12843 = load i64, ptr %slot2359, align 8
  %op12844 = sub i64 %v12843, 32
  store i64 %op12844, ptr %slot2369, align 8
  %v12845 = load i64, ptr %slot2359, align 8
  %p12846 = inttoptr i64 %v12845 to ptr
  %rgep12847 = getelementptr i8, ptr %p12846, i64 -32
  %ld12848 = load i64, ptr %rgep12847, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12848, ptr %slot2370, align 8
  %v12849 = load i64, ptr %slot2370, align 8
  %cmp12850 = icmp ne i64 %v12849, 0
  %cv12851 = zext i1 %cmp12850 to i32
  store i32 %cv12851, ptr %slot2371, align 8
  %v12852 = load i32, ptr %slot2371, align 8
  %cv12853 = zext i32 %v12852 to i64
  %cond12854 = icmp ne i64 %cv12853, 0
  br i1 %cond12854, label %bb_rcgdec3642, label %bb_rcgslow3642
bb_rcgslow3642:
  %v12855 = load i64, ptr %slot2358, align 8
  %v12856 = load i64, ptr %slot2355, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v12855, i64 %v12856) nomerge, !dbg !210
  br label %bb_rcgdone3642
bb_rcgdec3642:
  %v12857 = load i64, ptr %slot2367, align 8
  %v12858 = load i64, ptr %slot2359, align 8
  %p12859 = inttoptr i64 %v12858 to ptr
  %rgep12860 = getelementptr i8, ptr %p12859, i64 -24
  store i64 %v12857, ptr %rgep12860, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3642
bb_rcgclear3642:
  %v12861 = load i64, ptr %slot2355, align 8
  %p12862 = inttoptr i64 %v12861 to ptr
  store i64 0, ptr %p12862, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3642
bb_rcgdone3642:
  br label %bb_rcslotdone3626
bb_rcslotowner3626:
  %v12863 = load i64, ptr %slot63, align 8
  store i64 %v12863, ptr %slot2372, align 8
  %v12864 = load i64, ptr %slot2355, align 8
  %p12865 = inttoptr i64 %v12864 to ptr
  %ld12866 = load i64, ptr %p12865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12866, ptr %slot2373, align 8
  %v12867 = load i64, ptr %slot2373, align 8
  %cmp12868 = icmp ne i64 %v12867, 0
  %cv12869 = zext i1 %cmp12868 to i32
  store i32 %cv12869, ptr %slot2374, align 8
  %v12870 = load i32, ptr %slot2374, align 8
  %cv12871 = zext i32 %v12870 to i64
  %cond12872 = icmp ne i64 %cv12871, 0
  br i1 %cond12872, label %bb_rcgnn3657, label %bb_rcgdone3657
bb_rcgnn3657:
  %v12873 = load i64, ptr %slot2373, align 8
  %op12874 = sub i64 %v12873, 16
  store i64 %op12874, ptr %slot2375, align 8
  %v12875 = load i64, ptr %slot2373, align 8
  %p12876 = inttoptr i64 %v12875 to ptr
  %rgep12877 = getelementptr i8, ptr %p12876, i64 -16
  %ld12878 = load i64, ptr %rgep12877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12878, ptr %slot2376, align 8
  %v12879 = load i64, ptr %slot2376, align 8
  %op12880 = and i64 %v12879, 4611686018427387906
  store i64 %op12880, ptr %slot2377, align 8
  %v12881 = load i64, ptr %slot2377, align 8
  %cmp12882 = icmp ne i64 %v12881, 0
  %cv12883 = zext i1 %cmp12882 to i32
  store i32 %cv12883, ptr %slot2378, align 8
  %v12884 = load i32, ptr %slot2378, align 8
  %cv12885 = zext i32 %v12884 to i64
  %cond12886 = icmp ne i64 %cv12885, 0
  br i1 %cond12886, label %bb_rcgclear3657, label %bb_rcgcounted3657
bb_rcgcounted3657:
  %v12887 = load i64, ptr %slot2373, align 8
  %op12888 = sub i64 %v12887, 32
  store i64 %op12888, ptr %slot2379, align 8
  %v12889 = load i64, ptr %slot2373, align 8
  %p12890 = inttoptr i64 %v12889 to ptr
  %rgep12891 = getelementptr i8, ptr %p12890, i64 -32
  %ld12892 = load i64, ptr %rgep12891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12892, ptr %slot2380, align 8
  %v12893 = load i64, ptr %slot2380, align 8
  %op12894 = sub i64 %v12893, 1
  store i64 %op12894, ptr %slot2381, align 8
  %v12895 = load i64, ptr %slot2381, align 8
  %cmp12896 = icmp eq i64 %v12895, 0
  %cv12897 = zext i1 %cmp12896 to i32
  store i32 %cv12897, ptr %slot2382, align 8
  %v12898 = load i32, ptr %slot2382, align 8
  %cv12899 = zext i32 %v12898 to i64
  %cond12900 = icmp ne i64 %cv12899, 0
  br i1 %cond12900, label %bb_rcglast3657, label %bb_rcgdec3657
bb_rcglast3657:
  %v12901 = load i64, ptr %slot2373, align 8
  %op12902 = sub i64 %v12901, 24
  store i64 %op12902, ptr %slot2383, align 8
  %v12903 = load i64, ptr %slot2373, align 8
  %p12904 = inttoptr i64 %v12903 to ptr
  %rgep12905 = getelementptr i8, ptr %p12904, i64 -24
  %ld12906 = load i64, ptr %rgep12905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12906, ptr %slot2384, align 8
  %v12907 = load i64, ptr %slot2384, align 8
  %cmp12908 = icmp ne i64 %v12907, 0
  %cv12909 = zext i1 %cmp12908 to i32
  store i32 %cv12909, ptr %slot2385, align 8
  %v12910 = load i32, ptr %slot2385, align 8
  %cv12911 = zext i32 %v12910 to i64
  %cond12912 = icmp ne i64 %cv12911, 0
  br i1 %cond12912, label %bb_rcgdec3657, label %bb_rcgslow3657
bb_rcgslow3657:
  %v12913 = load i64, ptr %slot2372, align 8
  %v12914 = load i64, ptr %slot2355, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v12913, i64 %v12914) nomerge, !dbg !210
  br label %bb_rcgdone3657
bb_rcgdec3657:
  %v12915 = load i64, ptr %slot2381, align 8
  %v12916 = load i64, ptr %slot2373, align 8
  %p12917 = inttoptr i64 %v12916 to ptr
  %rgep12918 = getelementptr i8, ptr %p12917, i64 -32
  store i64 %v12915, ptr %rgep12918, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3657
bb_rcgclear3657:
  %v12919 = load i64, ptr %slot2355, align 8
  %p12920 = inttoptr i64 %v12919 to ptr
  store i64 0, ptr %p12920, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3657
bb_rcgdone3657:
  br label %bb_rcslotdone3626
bb_rcslotdone3626:
  %v12921 = load i64, ptr %slot7, align 8
  %p12922 = inttoptr i64 %v12921 to ptr
  %ld12923 = load i32, ptr %p12922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12923, ptr %slot2386, align 8
  %v12924 = load i32, ptr %slot2386, align 8
  %cv12925 = zext i32 %v12924 to i64
  %cond12926 = icmp ne i64 %cv12925, 0
  br i1 %cond12926, label %bb_rcslotdrop3681, label %bb_rcslotdone3681
bb_rcslotdrop3681:
  %v12927 = load i64, ptr %slot7, align 8
  %p12928 = inttoptr i64 %v12927 to ptr
  store i32 0, ptr %p12928, align 4, !alias.scope !3, !noalias !4
  %v12929 = load i64, ptr %slot38, align 8
  store i64 %v12929, ptr %slot2387, align 8
  %v12930 = load i64, ptr %slot8, align 8
  %p12931 = inttoptr i64 %v12930 to ptr
  %ld12932 = load i32, ptr %p12931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12932, ptr %slot2388, align 8
  %v12933 = load i32, ptr %slot2388, align 8
  %op12934 = and i32 %v12933, 28
  store i32 %op12934, ptr %slot2389, align 8
  %v12935 = load i32, ptr %slot2389, align 8
  %cv12936 = zext i32 %v12935 to i64
  %cond12937 = icmp ne i64 %cv12936, 0
  br i1 %cond12937, label %bb_rcslotrole3681, label %bb_rcslotowner3681
bb_rcslotrole3681:
  %v12938 = load i64, ptr %slot63, align 8
  store i64 %v12938, ptr %slot2390, align 8
  %v12939 = load i64, ptr %slot2390, align 8
  %v12940 = load i64, ptr %slot2387, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12939, i64 %v12940) nomerge, !dbg !210
  br label %bb_rcslotdone3681
bb_rcslotowner3681:
  %v12941 = load i64, ptr %slot63, align 8
  store i64 %v12941, ptr %slot2391, align 8
  %v12942 = load i64, ptr %slot2391, align 8
  %v12943 = load i64, ptr %slot2387, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12942, i64 %v12943) nomerge, !dbg !210
  br label %bb_rcslotdone3681
bb_rcslotdone3681:
  %v12944 = load i64, ptr %slot2277, align 8
  %p12945 = inttoptr i64 %v12944 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p12945, i64 24, i1 false)
  ret void
bb_i161:
  br label %bb_i169
bb_i162:
  br label %bb_i169
bb_i163:
  br label %bb_i169
bb_i164:
  br label %bb_i169
bb_i165:
  br label %bb_i169
bb_i166:
  br label %bb_i169
bb_i167:
  br label %bb_i169
bb_i168:
  br label %bb_i169
bb_i169:
  br label %bb_i173
bb_i170:
  br label %bb_i173
bb_i171:
  br label %bb_i173
bb_i172:
  br label %bb_i173
bb_i173:
  %p12946 = inttoptr i64 ptrtoint (ptr @myl_lit_2e1774f1e730447dab0b1459b81c248e69750ce5e381e122d6f307ecd76a2f89 to i64) to ptr
  %ld12947 = load i64, ptr %p12946, align 8, !alias.scope !4, !noalias !3
  store i64 %ld12947, ptr %slot2392, align 8
  %v12948 = load i64, ptr %slot2392, align 8
  %v12949 = load i64, ptr %slot44, align 8
  %p12950 = inttoptr i64 %v12949 to ptr
  store i64 %v12948, ptr %p12950, align 8, !alias.scope !3, !noalias !4
  %v12951 = load i64, ptr %slot44, align 8
  %p12952 = inttoptr i64 %v12951 to ptr
  %ld12953 = load i64, ptr %p12952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12953, ptr %slot2393, align 8
  %v12954 = load i64, ptr %slot2393, align 8
  %v12955 = load i64, ptr %slot23, align 8
  %p12956 = inttoptr i64 %v12955 to ptr
  store i64 %v12954, ptr %p12956, align 8, !alias.scope !3, !noalias !4
  %v12957 = load i64, ptr %slot23, align 8
  store i64 %v12957, ptr %slot2394, align 8
  %v12958 = load i64, ptr %slot24, align 8
  store i64 %v12958, ptr %slot2395, align 8
  %v12959 = load i64, ptr %slot2394, align 8
  %v12960 = load i64, ptr %slot2395, align 8
  %p12961 = inttoptr i64 %v12959 to ptr
  %p12962 = inttoptr i64 %v12960 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12962, ptr %p12961, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12963 = load i64, ptr %slot20, align 8
  %p12964 = inttoptr i64 %v12963 to ptr
  store i32 2, ptr %p12964, align 4, !alias.scope !3, !noalias !4
  %v12965 = load i64, ptr %slot19, align 8
  %p12966 = inttoptr i64 %v12965 to ptr
  store i32 1, ptr %p12966, align 4, !alias.scope !3, !noalias !4
  %v12967 = load i64, ptr %slot22, align 8
  store i64 %v12967, ptr %slot2396, align 8
  %v12968 = load i64, ptr %slot24, align 8
  store i64 %v12968, ptr %slot2397, align 8
  %v12969 = load i64, ptr %slot2397, align 8
  %v12970 = load i64, ptr %slot2396, align 8
  %p12971 = inttoptr i64 %v12969 to ptr
  %p12972 = inttoptr i64 %v12970 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12972, ptr %p12971, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12973 = load i64, ptr %slot18, align 8
  %p12974 = inttoptr i64 %v12973 to ptr
  store i32 2, ptr %p12974, align 4, !alias.scope !3, !noalias !4
  %v12975 = load i64, ptr %slot20, align 8
  %p12976 = inttoptr i64 %v12975 to ptr
  %ld12977 = load i32, ptr %p12976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12977, ptr %slot2398, align 8
  %v12978 = load i32, ptr %slot2398, align 8
  %v12979 = load i64, ptr %slot18, align 8
  %p12980 = inttoptr i64 %v12979 to ptr
  store i32 %v12978, ptr %p12980, align 4, !alias.scope !3, !noalias !4
  %v12981 = load i64, ptr %slot19, align 8
  %p12982 = inttoptr i64 %v12981 to ptr
  store i32 0, ptr %p12982, align 4, !alias.scope !3, !noalias !4
  %v12983 = load i64, ptr %slot17, align 8
  %p12984 = inttoptr i64 %v12983 to ptr
  store i32 1, ptr %p12984, align 4, !alias.scope !3, !noalias !4
  %v12985 = load i64, ptr %slot2396, align 8
  %p12986 = inttoptr i64 %v12985 to ptr
  %ld12987 = load i64, ptr %p12986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12987, ptr %slot2399, align 8
  %v12988 = load i64, ptr %slot2399, align 8
  %v12989 = load i64, ptr %slot44, align 8
  %p12990 = inttoptr i64 %v12989 to ptr
  store i64 %v12988, ptr %p12990, align 8, !alias.scope !3, !noalias !4
  %v12991 = load i64, ptr %slot28, align 8
  %p12992 = inttoptr i64 %v12991 to ptr
  %ld12993 = load i64, ptr %p12992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12993, ptr %slot2400, align 8
  %v12994 = load i64, ptr %slot2400, align 8
  %v12995 = load i64, ptr %slot45, align 8
  %p12996 = inttoptr i64 %v12995 to ptr
  store i64 %v12994, ptr %p12996, align 8, !alias.scope !3, !noalias !4
  %v12997 = load i64, ptr %slot44, align 8
  %p12998 = inttoptr i64 %v12997 to ptr
  %ld12999 = load i64, ptr %p12998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12999, ptr %slot2401, align 8
  %v13000 = load i64, ptr %slot45, align 8
  %p13001 = inttoptr i64 %v13000 to ptr
  %ld13002 = load i64, ptr %p13001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13002, ptr %slot2402, align 8
  %v13003 = load i64, ptr %slot1, align 8
  %v13004 = load i64, ptr %slot2401, align 8
  %v13005 = load i64, ptr %slot2402, align 8
  %call13006 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v13003, i64 %v13004, i64 %v13005) nomerge, !dbg !212
  store { i64, i64 } %call13006, ptr %callresult2404, align 8
  %addr13007 = ptrtoint ptr %callresult2404 to i64
  store i64 %addr13007, ptr %slot2403, align 8
  %v13008 = load i64, ptr %slot2403, align 8
  %v13009 = load i64, ptr %slot44, align 8
  %p13010 = inttoptr i64 %v13009 to ptr
  store i64 %v13008, ptr %p13010, align 8, !alias.scope !3, !noalias !4
  %v13011 = load i64, ptr %slot44, align 8
  %p13012 = inttoptr i64 %v13011 to ptr
  %ld13013 = load i64, ptr %p13012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13013, ptr %slot2405, align 8
  %v13014 = load i64, ptr %slot24, align 8
  store i64 %v13014, ptr %slot2406, align 8
  %v13015 = load i64, ptr %slot63, align 8
  %v13016 = load i64, ptr %slot2406, align 8
  %v13017 = load i64, ptr %slot2405, align 8
  %call13018 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v13015, i64 %v13016, i64 %v13017) nomerge, !dbg !212
  store i32 %call13018, ptr %slot2407, align 8
  %v13019 = load i32, ptr %slot2407, align 8
  %cv13020 = zext i32 %v13019 to i64
  %cond13021 = icmp ne i64 %cv13020, 0
  br i1 %cond13021, label %bb_rcsuccess3794, label %bb_rcfailure3794
bb_rcfailure3794:
  %v13022 = load i64, ptr %slot63, align 8
  %p13023 = inttoptr i64 %v13022 to ptr
  %call13024 = call i32 @myl_rc_take_failure(ptr %p13023) nomerge, !dbg !212
  store i32 %call13024, ptr %slot2408, align 8
  %v13025 = load i64, ptr %slot1, align 8
  %p13026 = inttoptr i64 %v13025 to ptr
  %v13027 = load i32, ptr %slot2408, align 8
  %call13028 = call i32 @myl_qbe_rc_status(ptr %p13026, i32 %v13027) nomerge, !dbg !212
  store i32 %call13028, ptr %slot2409, align 8
  br label %bb_failure
bb_rcsuccess3794:
  %v13029 = load i64, ptr %slot20, align 8
  %p13030 = inttoptr i64 %v13029 to ptr
  store i32 2, ptr %p13030, align 4, !alias.scope !3, !noalias !4
  %v13031 = load i64, ptr %slot20, align 8
  %p13032 = inttoptr i64 %v13031 to ptr
  store i32 16, ptr %p13032, align 4, !alias.scope !3, !noalias !4
  %v13033 = load i64, ptr %slot19, align 8
  %p13034 = inttoptr i64 %v13033 to ptr
  store i32 1, ptr %p13034, align 4, !alias.scope !3, !noalias !4
  %v13035 = load i64, ptr %slot17, align 8
  %p13036 = inttoptr i64 %v13035 to ptr
  %ld13037 = load i32, ptr %p13036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13037, ptr %slot2410, align 8
  %v13038 = load i32, ptr %slot2410, align 8
  %cv13039 = zext i32 %v13038 to i64
  %cond13040 = icmp ne i64 %cv13039, 0
  br i1 %cond13040, label %bb_rcslotdrop3802, label %bb_rcslotdone3802
bb_rcslotdrop3802:
  %v13041 = load i64, ptr %slot17, align 8
  %p13042 = inttoptr i64 %v13041 to ptr
  store i32 0, ptr %p13042, align 4, !alias.scope !3, !noalias !4
  %v13043 = load i64, ptr %slot22, align 8
  store i64 %v13043, ptr %slot2411, align 8
  %v13044 = load i64, ptr %slot18, align 8
  %p13045 = inttoptr i64 %v13044 to ptr
  %ld13046 = load i32, ptr %p13045, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13046, ptr %slot2412, align 8
  %v13047 = load i32, ptr %slot2412, align 8
  %op13048 = and i32 %v13047, 28
  store i32 %op13048, ptr %slot2413, align 8
  %v13049 = load i32, ptr %slot2413, align 8
  %cv13050 = zext i32 %v13049 to i64
  %cond13051 = icmp ne i64 %cv13050, 0
  br i1 %cond13051, label %bb_rcslotrole3802, label %bb_rcslotowner3802
bb_rcslotrole3802:
  %v13052 = load i64, ptr %slot63, align 8
  store i64 %v13052, ptr %slot2414, align 8
  %v13053 = load i64, ptr %slot2411, align 8
  %p13054 = inttoptr i64 %v13053 to ptr
  %ld13055 = load i64, ptr %p13054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13055, ptr %slot2415, align 8
  %v13056 = load i64, ptr %slot2415, align 8
  %cmp13057 = icmp ne i64 %v13056, 0
  %cv13058 = zext i1 %cmp13057 to i32
  store i32 %cv13058, ptr %slot2416, align 8
  %v13059 = load i32, ptr %slot2416, align 8
  %cv13060 = zext i32 %v13059 to i64
  %cond13061 = icmp ne i64 %cv13060, 0
  br i1 %cond13061, label %bb_rcgnn3818, label %bb_rcgdone3818
bb_rcgnn3818:
  %v13062 = load i64, ptr %slot2415, align 8
  %op13063 = sub i64 %v13062, 16
  store i64 %op13063, ptr %slot2417, align 8
  %v13064 = load i64, ptr %slot2415, align 8
  %p13065 = inttoptr i64 %v13064 to ptr
  %rgep13066 = getelementptr i8, ptr %p13065, i64 -16
  %ld13067 = load i64, ptr %rgep13066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13067, ptr %slot2418, align 8
  %v13068 = load i64, ptr %slot2418, align 8
  %op13069 = and i64 %v13068, 4611686018427387906
  store i64 %op13069, ptr %slot2419, align 8
  %v13070 = load i64, ptr %slot2419, align 8
  %cmp13071 = icmp ne i64 %v13070, 0
  %cv13072 = zext i1 %cmp13071 to i32
  store i32 %cv13072, ptr %slot2420, align 8
  %v13073 = load i32, ptr %slot2420, align 8
  %cv13074 = zext i32 %v13073 to i64
  %cond13075 = icmp ne i64 %cv13074, 0
  br i1 %cond13075, label %bb_rcgclear3818, label %bb_rcgcounted3818
bb_rcgcounted3818:
  %v13076 = load i64, ptr %slot2415, align 8
  %op13077 = sub i64 %v13076, 24
  store i64 %op13077, ptr %slot2421, align 8
  %v13078 = load i64, ptr %slot2415, align 8
  %p13079 = inttoptr i64 %v13078 to ptr
  %rgep13080 = getelementptr i8, ptr %p13079, i64 -24
  %ld13081 = load i64, ptr %rgep13080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13081, ptr %slot2422, align 8
  %v13082 = load i64, ptr %slot2422, align 8
  %op13083 = sub i64 %v13082, 1
  store i64 %op13083, ptr %slot2423, align 8
  %v13084 = load i64, ptr %slot2423, align 8
  %cmp13085 = icmp eq i64 %v13084, 0
  %cv13086 = zext i1 %cmp13085 to i32
  store i32 %cv13086, ptr %slot2424, align 8
  %v13087 = load i32, ptr %slot2424, align 8
  %cv13088 = zext i32 %v13087 to i64
  %cond13089 = icmp ne i64 %cv13088, 0
  br i1 %cond13089, label %bb_rcglast3818, label %bb_rcgdec3818
bb_rcglast3818:
  %v13090 = load i64, ptr %slot2415, align 8
  %op13091 = sub i64 %v13090, 32
  store i64 %op13091, ptr %slot2425, align 8
  %v13092 = load i64, ptr %slot2415, align 8
  %p13093 = inttoptr i64 %v13092 to ptr
  %rgep13094 = getelementptr i8, ptr %p13093, i64 -32
  %ld13095 = load i64, ptr %rgep13094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13095, ptr %slot2426, align 8
  %v13096 = load i64, ptr %slot2426, align 8
  %cmp13097 = icmp ne i64 %v13096, 0
  %cv13098 = zext i1 %cmp13097 to i32
  store i32 %cv13098, ptr %slot2427, align 8
  %v13099 = load i32, ptr %slot2427, align 8
  %cv13100 = zext i32 %v13099 to i64
  %cond13101 = icmp ne i64 %cv13100, 0
  br i1 %cond13101, label %bb_rcgdec3818, label %bb_rcgslow3818
bb_rcgslow3818:
  %v13102 = load i64, ptr %slot2414, align 8
  %v13103 = load i64, ptr %slot2411, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v13102, i64 %v13103) nomerge, !dbg !212
  br label %bb_rcgdone3818
bb_rcgdec3818:
  %v13104 = load i64, ptr %slot2423, align 8
  %v13105 = load i64, ptr %slot2415, align 8
  %p13106 = inttoptr i64 %v13105 to ptr
  %rgep13107 = getelementptr i8, ptr %p13106, i64 -24
  store i64 %v13104, ptr %rgep13107, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3818
bb_rcgclear3818:
  %v13108 = load i64, ptr %slot2411, align 8
  %p13109 = inttoptr i64 %v13108 to ptr
  store i64 0, ptr %p13109, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3818
bb_rcgdone3818:
  br label %bb_rcslotdone3802
bb_rcslotowner3802:
  %v13110 = load i64, ptr %slot63, align 8
  store i64 %v13110, ptr %slot2428, align 8
  %v13111 = load i64, ptr %slot2411, align 8
  %p13112 = inttoptr i64 %v13111 to ptr
  %ld13113 = load i64, ptr %p13112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13113, ptr %slot2429, align 8
  %v13114 = load i64, ptr %slot2429, align 8
  %cmp13115 = icmp ne i64 %v13114, 0
  %cv13116 = zext i1 %cmp13115 to i32
  store i32 %cv13116, ptr %slot2430, align 8
  %v13117 = load i32, ptr %slot2430, align 8
  %cv13118 = zext i32 %v13117 to i64
  %cond13119 = icmp ne i64 %cv13118, 0
  br i1 %cond13119, label %bb_rcgnn3833, label %bb_rcgdone3833
bb_rcgnn3833:
  %v13120 = load i64, ptr %slot2429, align 8
  %op13121 = sub i64 %v13120, 16
  store i64 %op13121, ptr %slot2431, align 8
  %v13122 = load i64, ptr %slot2429, align 8
  %p13123 = inttoptr i64 %v13122 to ptr
  %rgep13124 = getelementptr i8, ptr %p13123, i64 -16
  %ld13125 = load i64, ptr %rgep13124, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13125, ptr %slot2432, align 8
  %v13126 = load i64, ptr %slot2432, align 8
  %op13127 = and i64 %v13126, 4611686018427387906
  store i64 %op13127, ptr %slot2433, align 8
  %v13128 = load i64, ptr %slot2433, align 8
  %cmp13129 = icmp ne i64 %v13128, 0
  %cv13130 = zext i1 %cmp13129 to i32
  store i32 %cv13130, ptr %slot2434, align 8
  %v13131 = load i32, ptr %slot2434, align 8
  %cv13132 = zext i32 %v13131 to i64
  %cond13133 = icmp ne i64 %cv13132, 0
  br i1 %cond13133, label %bb_rcgclear3833, label %bb_rcgcounted3833
bb_rcgcounted3833:
  %v13134 = load i64, ptr %slot2429, align 8
  %op13135 = sub i64 %v13134, 32
  store i64 %op13135, ptr %slot2435, align 8
  %v13136 = load i64, ptr %slot2429, align 8
  %p13137 = inttoptr i64 %v13136 to ptr
  %rgep13138 = getelementptr i8, ptr %p13137, i64 -32
  %ld13139 = load i64, ptr %rgep13138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13139, ptr %slot2436, align 8
  %v13140 = load i64, ptr %slot2436, align 8
  %op13141 = sub i64 %v13140, 1
  store i64 %op13141, ptr %slot2437, align 8
  %v13142 = load i64, ptr %slot2437, align 8
  %cmp13143 = icmp eq i64 %v13142, 0
  %cv13144 = zext i1 %cmp13143 to i32
  store i32 %cv13144, ptr %slot2438, align 8
  %v13145 = load i32, ptr %slot2438, align 8
  %cv13146 = zext i32 %v13145 to i64
  %cond13147 = icmp ne i64 %cv13146, 0
  br i1 %cond13147, label %bb_rcglast3833, label %bb_rcgdec3833
bb_rcglast3833:
  %v13148 = load i64, ptr %slot2429, align 8
  %op13149 = sub i64 %v13148, 24
  store i64 %op13149, ptr %slot2439, align 8
  %v13150 = load i64, ptr %slot2429, align 8
  %p13151 = inttoptr i64 %v13150 to ptr
  %rgep13152 = getelementptr i8, ptr %p13151, i64 -24
  %ld13153 = load i64, ptr %rgep13152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13153, ptr %slot2440, align 8
  %v13154 = load i64, ptr %slot2440, align 8
  %cmp13155 = icmp ne i64 %v13154, 0
  %cv13156 = zext i1 %cmp13155 to i32
  store i32 %cv13156, ptr %slot2441, align 8
  %v13157 = load i32, ptr %slot2441, align 8
  %cv13158 = zext i32 %v13157 to i64
  %cond13159 = icmp ne i64 %cv13158, 0
  br i1 %cond13159, label %bb_rcgdec3833, label %bb_rcgslow3833
bb_rcgslow3833:
  %v13160 = load i64, ptr %slot2428, align 8
  %v13161 = load i64, ptr %slot2411, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v13160, i64 %v13161) nomerge, !dbg !212
  br label %bb_rcgdone3833
bb_rcgdec3833:
  %v13162 = load i64, ptr %slot2437, align 8
  %v13163 = load i64, ptr %slot2429, align 8
  %p13164 = inttoptr i64 %v13163 to ptr
  %rgep13165 = getelementptr i8, ptr %p13164, i64 -32
  store i64 %v13162, ptr %rgep13165, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3833
bb_rcgclear3833:
  %v13166 = load i64, ptr %slot2411, align 8
  %p13167 = inttoptr i64 %v13166 to ptr
  store i64 0, ptr %p13167, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3833
bb_rcgdone3833:
  br label %bb_rcslotdone3802
bb_rcslotdone3802:
  %v13168 = load i64, ptr %slot22, align 8
  store i64 %v13168, ptr %slot2442, align 8
  %v13169 = load i64, ptr %slot24, align 8
  store i64 %v13169, ptr %slot2443, align 8
  %v13170 = load i64, ptr %slot2443, align 8
  %v13171 = load i64, ptr %slot2442, align 8
  %p13172 = inttoptr i64 %v13170 to ptr
  %p13173 = inttoptr i64 %v13171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13173, ptr %p13172, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v13174 = load i64, ptr %slot18, align 8
  %p13175 = inttoptr i64 %v13174 to ptr
  store i32 2, ptr %p13175, align 4, !alias.scope !3, !noalias !4
  %v13176 = load i64, ptr %slot20, align 8
  %p13177 = inttoptr i64 %v13176 to ptr
  %ld13178 = load i32, ptr %p13177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13178, ptr %slot2444, align 8
  %v13179 = load i32, ptr %slot2444, align 8
  %v13180 = load i64, ptr %slot18, align 8
  %p13181 = inttoptr i64 %v13180 to ptr
  store i32 %v13179, ptr %p13181, align 4, !alias.scope !3, !noalias !4
  %v13182 = load i64, ptr %slot19, align 8
  %p13183 = inttoptr i64 %v13182 to ptr
  store i32 0, ptr %p13183, align 4, !alias.scope !3, !noalias !4
  %v13184 = load i64, ptr %slot17, align 8
  %p13185 = inttoptr i64 %v13184 to ptr
  store i32 1, ptr %p13185, align 4, !alias.scope !3, !noalias !4
  %v13186 = load i64, ptr %slot2442, align 8
  %v13187 = load i64, ptr %slot44, align 8
  %p13188 = inttoptr i64 %v13187 to ptr
  store i64 %v13186, ptr %p13188, align 8, !alias.scope !3, !noalias !4
  %v13189 = load i64, ptr %slot58, align 8
  store i64 %v13189, ptr %slot2445, align 8
  %v13190 = load i64, ptr %slot2445, align 8
  %p13191 = inttoptr i64 %v13190 to ptr
  store i64 0, ptr %p13191, align 8, !alias.scope !3, !noalias !4
  %v13192 = load i64, ptr %slot2445, align 8
  %p13194 = inttoptr i64 %v13192 to ptr
  %gep13195 = getelementptr i8, ptr %p13194, i64 8
  %op13193 = ptrtoint ptr %gep13195 to i64
  store i64 %op13193, ptr %slot2446, align 8
  %v13196 = load i64, ptr %slot2446, align 8
  %p13197 = inttoptr i64 %v13196 to ptr
  store i64 0, ptr %p13197, align 8, !alias.scope !3, !noalias !4
  %v13198 = load i64, ptr %slot2445, align 8
  %p13200 = inttoptr i64 %v13198 to ptr
  %gep13201 = getelementptr i8, ptr %p13200, i64 16
  %op13199 = ptrtoint ptr %gep13201 to i64
  store i64 %op13199, ptr %slot2447, align 8
  %v13202 = load i64, ptr %slot2447, align 8
  %p13203 = inttoptr i64 %v13202 to ptr
  store i64 0, ptr %p13203, align 8, !alias.scope !3, !noalias !4
  %v13204 = load i64, ptr %slot2445, align 8
  %p13205 = inttoptr i64 %v13204 to ptr
  store i32 1, ptr %p13205, align 4, !alias.scope !3, !noalias !4
  %v13206 = load i64, ptr %slot21, align 8
  %p13207 = inttoptr i64 %v13206 to ptr
  store i32 1, ptr %p13207, align 4, !alias.scope !3, !noalias !4
  %v13208 = load i64, ptr %slot44, align 8
  %p13209 = inttoptr i64 %v13208 to ptr
  %ld13210 = load i64, ptr %p13209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13210, ptr %slot2448, align 8
  %v13211 = load i64, ptr %slot2445, align 8
  %p13213 = inttoptr i64 %v13211 to ptr
  %gep13214 = getelementptr i8, ptr %p13213, i64 8
  %op13212 = ptrtoint ptr %gep13214 to i64
  store i64 %op13212, ptr %slot2449, align 8
  %v13215 = load i64, ptr %slot64, align 8
  store i64 %v13215, ptr %slot2450, align 8
  %v13216 = load i64, ptr %slot44, align 8
  %p13217 = inttoptr i64 %v13216 to ptr
  %ld13218 = load i64, ptr %p13217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13218, ptr %slot2451, align 8
  %v13219 = load i64, ptr %slot17, align 8
  %p13220 = inttoptr i64 %v13219 to ptr
  %ld13221 = load i32, ptr %p13220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13221, ptr %slot2452, align 8
  %v13222 = load i64, ptr %slot18, align 8
  %p13223 = inttoptr i64 %v13222 to ptr
  %ld13224 = load i32, ptr %p13223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13224, ptr %slot2453, align 8
  %v13225 = load i32, ptr %slot2453, align 8
  %op13226 = and i32 %v13225, 24
  store i32 %op13226, ptr %slot2453, align 8
  %v13227 = load i32, ptr %slot2453, align 8
  %cmp13228 = icmp eq i32 %v13227, 0
  %cv13229 = zext i1 %cmp13228 to i32
  store i32 %cv13229, ptr %slot2454, align 8
  %v13230 = load i32, ptr %slot2452, align 8
  %v13231 = load i32, ptr %slot2454, align 8
  %op13232 = and i32 %v13230, %v13231
  store i32 %op13232, ptr %slot2455, align 8
  %v13233 = load i32, ptr %slot2455, align 8
  %cv13234 = zext i32 %v13233 to i64
  %cond13235 = icmp ne i64 %cv13234, 0
  br i1 %cond13235, label %bb_rctake3854, label %bb_rccopy3854
bb_rctake3854:
  %v13236 = load i64, ptr %slot24, align 8
  store i64 %v13236, ptr %slot2456, align 8
  %v13237 = load i64, ptr %slot64, align 8
  store i64 %v13237, ptr %slot2457, align 8
  %v13238 = load i64, ptr %slot2451, align 8
  %v13239 = load i64, ptr %slot2456, align 8
  %op13240 = sub i64 %v13238, %v13239
  store i64 %op13240, ptr %slot2458, align 8
  %v13241 = load i64, ptr %slot2456, align 8
  %v13242 = load i64, ptr %slot2451, align 8
  %op13243 = sub i64 %v13241, %v13242
  store i64 %op13243, ptr %slot2459, align 8
  %v13244 = load i64, ptr %slot2458, align 8
  %cmp13245 = icmp ult i64 %v13244, 16
  %cv13246 = zext i1 %cmp13245 to i32
  store i32 %cv13246, ptr %slot2460, align 8
  %v13247 = load i64, ptr %slot2459, align 8
  %cmp13248 = icmp ult i64 %v13247, 16
  %cv13249 = zext i1 %cmp13248 to i32
  store i32 %cv13249, ptr %slot2461, align 8
  %v13250 = load i32, ptr %slot2460, align 8
  %v13251 = load i32, ptr %slot2461, align 8
  %op13252 = or i32 %v13250, %v13251
  store i32 %op13252, ptr %slot2462, align 8
  %v13253 = load i32, ptr %slot2462, align 8
  %cv13254 = zext i32 %v13253 to i64
  %cond13255 = icmp ne i64 %cv13254, 0
  br i1 %cond13255, label %bb_rcmoveslow3863, label %bb_rcmovecheck3863
bb_rcmovecheck3863:
  %v13256 = load i64, ptr %slot2451, align 8
  %op13257 = add i64 %v13256, 0
  store i64 %op13257, ptr %slot2463, align 8
  %v13258 = load i64, ptr %slot2463, align 8
  %p13259 = inttoptr i64 %v13258 to ptr
  %ld13260 = load i64, ptr %p13259, align 8
  store i64 %ld13260, ptr %slot2464, align 8
  %v13261 = load i64, ptr %slot2464, align 8
  %cmp13262 = icmp ne i64 %v13261, 0
  %cv13263 = zext i1 %cmp13262 to i32
  store i32 %cv13263, ptr %slot2465, align 8
  %v13264 = load i32, ptr %slot2465, align 8
  %cv13265 = zext i32 %v13264 to i64
  %cond13266 = icmp ne i64 %cv13265, 0
  br i1 %cond13266, label %bb_rcmoveheader3871, label %bb_rcmovenext3871
bb_rcmoveheader3871:
  %v13267 = load i64, ptr %slot2464, align 8
  %op13268 = sub i64 %v13267, 16
  store i64 %op13268, ptr %slot2466, align 8
  %v13269 = load i64, ptr %slot2464, align 8
  %p13270 = inttoptr i64 %v13269 to ptr
  %rgep13271 = getelementptr i8, ptr %p13270, i64 -16
  %ld13272 = load i64, ptr %rgep13271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13272, ptr %slot2467, align 8
  %v13273 = load i64, ptr %slot2467, align 8
  %op13274 = and i64 %v13273, 5764607523034234881
  store i64 %op13274, ptr %slot2468, align 8
  %v13275 = load i64, ptr %slot2468, align 8
  %cmp13276 = icmp ne i64 %v13275, 0
  %cv13277 = zext i1 %cmp13276 to i32
  store i32 %cv13277, ptr %slot2469, align 8
  %v13278 = load i32, ptr %slot2469, align 8
  %cv13279 = zext i32 %v13278 to i64
  %cond13280 = icmp ne i64 %cv13279, 0
  br i1 %cond13280, label %bb_rcmoveslow3863, label %bb_rcmovenext3871
bb_rcmovenext3871:
  %v13281 = load i64, ptr %slot2451, align 8
  %v13282 = load i64, ptr %slot2456, align 8
  %p13283 = inttoptr i64 %v13281 to ptr
  %p13284 = inttoptr i64 %v13282 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13284, ptr %p13283, i64 16, i1 false)
  %v13285 = load i64, ptr %slot2451, align 8
  %p13286 = inttoptr i64 %v13285 to ptr
  store i64 0, ptr %p13286, align 8
  %v13287 = load i64, ptr %slot2451, align 8
  %op13288 = add i64 %v13287, 8
  store i64 %op13288, ptr %slot2470, align 8
  %v13289 = load i64, ptr %slot2470, align 8
  %p13290 = inttoptr i64 %v13289 to ptr
  store i64 0, ptr %p13290, align 8
  br label %bb_rcmoved3863
bb_rcmoveslow3863:
  %v13291 = load i64, ptr %slot63, align 8
  %v13292 = load i64, ptr %slot2456, align 8
  %v13293 = load i64, ptr %slot2451, align 8
  %v13294 = load i64, ptr %slot2457, align 8
  %cv13295 = trunc i64 %v13294 to i32
  %call13296 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v13291, i64 %v13292, i64 %v13293, i32 %cv13295) nomerge, !dbg !214
  store i32 %call13296, ptr %slot2471, align 8
  %v13297 = load i32, ptr %slot2471, align 8
  %cv13298 = zext i32 %v13297 to i64
  %cond13299 = icmp ne i64 %cv13298, 0
  br i1 %cond13299, label %bb_rcsuccess3879, label %bb_rcfailure3879
bb_rcfailure3879:
  %v13300 = load i64, ptr %slot63, align 8
  %p13301 = inttoptr i64 %v13300 to ptr
  %call13302 = call i32 @myl_rc_take_failure(ptr %p13301) nomerge, !dbg !214
  store i32 %call13302, ptr %slot2472, align 8
  %v13303 = load i64, ptr %slot1, align 8
  %p13304 = inttoptr i64 %v13303 to ptr
  %v13305 = load i32, ptr %slot2472, align 8
  %call13306 = call i32 @myl_qbe_rc_status(ptr %p13304, i32 %v13305) nomerge, !dbg !214
  store i32 %call13306, ptr %slot2473, align 8
  br label %bb_failure
bb_rcsuccess3879:
  br label %bb_rcmoved3863
bb_rcmoved3863:
  %v13307 = load i64, ptr %slot17, align 8
  %p13308 = inttoptr i64 %v13307 to ptr
  store i32 0, ptr %p13308, align 4, !alias.scope !3, !noalias !4
  %v13309 = load i64, ptr %slot20, align 8
  %p13310 = inttoptr i64 %v13309 to ptr
  store i32 2, ptr %p13310, align 4, !alias.scope !3, !noalias !4
  %v13311 = load i64, ptr %slot19, align 8
  %p13312 = inttoptr i64 %v13311 to ptr
  store i32 1, ptr %p13312, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared3854
bb_rccopy3854:
  %v13313 = load i64, ptr %slot24, align 8
  store i64 %v13313, ptr %slot2474, align 8
  %v13314 = load i64, ptr %slot64, align 8
  store i64 %v13314, ptr %slot2475, align 8
  %v13315 = load i64, ptr %slot63, align 8
  %v13316 = load i64, ptr %slot2474, align 8
  %v13317 = load i64, ptr %slot2451, align 8
  %v13318 = load i64, ptr %slot2475, align 8
  %cv13319 = trunc i64 %v13318 to i32
  %call13320 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v13315, i64 %v13316, i64 %v13317, i32 %cv13319) nomerge, !dbg !214
  store i32 %call13320, ptr %slot2476, align 8
  %v13321 = load i32, ptr %slot2476, align 8
  %cv13322 = zext i32 %v13321 to i64
  %cond13323 = icmp ne i64 %cv13322, 0
  br i1 %cond13323, label %bb_rcsuccess3888, label %bb_rcfailure3888
bb_rcfailure3888:
  %v13324 = load i64, ptr %slot63, align 8
  %p13325 = inttoptr i64 %v13324 to ptr
  %call13326 = call i32 @myl_rc_take_failure(ptr %p13325) nomerge, !dbg !214
  store i32 %call13326, ptr %slot2477, align 8
  %v13327 = load i64, ptr %slot1, align 8
  %p13328 = inttoptr i64 %v13327 to ptr
  %v13329 = load i32, ptr %slot2477, align 8
  %call13330 = call i32 @myl_qbe_rc_status(ptr %p13328, i32 %v13329) nomerge, !dbg !214
  store i32 %call13330, ptr %slot2478, align 8
  br label %bb_failure
bb_rcsuccess3888:
  %v13331 = load i64, ptr %slot20, align 8
  %p13332 = inttoptr i64 %v13331 to ptr
  store i32 2, ptr %p13332, align 4, !alias.scope !3, !noalias !4
  %v13333 = load i64, ptr %slot19, align 8
  %p13334 = inttoptr i64 %v13333 to ptr
  store i32 1, ptr %p13334, align 4, !alias.scope !3, !noalias !4
  %v13335 = load i64, ptr %slot17, align 8
  %p13336 = inttoptr i64 %v13335 to ptr
  %ld13337 = load i32, ptr %p13336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13337, ptr %slot2479, align 8
  %v13338 = load i32, ptr %slot2479, align 8
  %cv13339 = zext i32 %v13338 to i64
  %cond13340 = icmp ne i64 %cv13339, 0
  br i1 %cond13340, label %bb_rcslotdrop3895, label %bb_rcslotdone3895
bb_rcslotdrop3895:
  %v13341 = load i64, ptr %slot17, align 8
  %p13342 = inttoptr i64 %v13341 to ptr
  store i32 0, ptr %p13342, align 4, !alias.scope !3, !noalias !4
  %v13343 = load i64, ptr %slot22, align 8
  store i64 %v13343, ptr %slot2480, align 8
  %v13344 = load i64, ptr %slot18, align 8
  %p13345 = inttoptr i64 %v13344 to ptr
  %ld13346 = load i32, ptr %p13345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13346, ptr %slot2481, align 8
  %v13347 = load i32, ptr %slot2481, align 8
  %op13348 = and i32 %v13347, 28
  store i32 %op13348, ptr %slot2482, align 8
  %v13349 = load i32, ptr %slot2482, align 8
  %cv13350 = zext i32 %v13349 to i64
  %cond13351 = icmp ne i64 %cv13350, 0
  br i1 %cond13351, label %bb_rcslotrole3895, label %bb_rcslotowner3895
bb_rcslotrole3895:
  %v13352 = load i64, ptr %slot63, align 8
  store i64 %v13352, ptr %slot2483, align 8
  %v13353 = load i64, ptr %slot2483, align 8
  %v13354 = load i64, ptr %slot2480, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v13353, i64 %v13354) nomerge, !dbg !214
  br label %bb_rcslotdone3895
bb_rcslotowner3895:
  %v13355 = load i64, ptr %slot63, align 8
  store i64 %v13355, ptr %slot2484, align 8
  %v13356 = load i64, ptr %slot2484, align 8
  %v13357 = load i64, ptr %slot2480, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v13356, i64 %v13357) nomerge, !dbg !214
  br label %bb_rcslotdone3895
bb_rcslotdone3895:
  br label %bb_rcprepared3854
bb_rcprepared3854:
  %v13358 = load i64, ptr %slot24, align 8
  store i64 %v13358, ptr %slot2485, align 8
  %v13359 = load i64, ptr %slot2485, align 8
  %v13360 = load i64, ptr %slot2449, align 8
  %p13361 = inttoptr i64 %v13359 to ptr
  %p13362 = inttoptr i64 %v13360 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13362, ptr %p13361, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v13363 = load i64, ptr %slot19, align 8
  %p13364 = inttoptr i64 %v13363 to ptr
  store i32 0, ptr %p13364, align 4, !alias.scope !3, !noalias !4
  %v13365 = load i64, ptr %slot2445, align 8
  %v13366 = load i64, ptr %slot44, align 8
  %p13367 = inttoptr i64 %v13366 to ptr
  store i64 %v13365, ptr %p13367, align 8, !alias.scope !3, !noalias !4
  %p13368 = inttoptr i64 ptrtoint (ptr @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p13368, i64 176) "call-inline-cost"="0", !dbg !214
  %v13369 = load i64, ptr %slot44, align 8
  %p13370 = inttoptr i64 %v13369 to ptr
  %ld13371 = load i64, ptr %p13370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13371, ptr %slot2486, align 8
  %v13372 = load i64, ptr %slot22, align 8
  store i64 %v13372, ptr %slot2487, align 8
  %v13373 = load i64, ptr %slot2486, align 8
  %v13374 = load i64, ptr %slot2487, align 8
  %p13375 = inttoptr i64 %v13373 to ptr
  %p13376 = inttoptr i64 %v13374 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13376, ptr %p13375, i64 24, i1 false)
  %v13377 = load i64, ptr %slot18, align 8
  %p13378 = inttoptr i64 %v13377 to ptr
  store i32 2, ptr %p13378, align 4, !alias.scope !3, !noalias !4
  %v13379 = load i64, ptr %slot17, align 8
  %p13380 = inttoptr i64 %v13379 to ptr
  store i32 1, ptr %p13380, align 4, !alias.scope !3, !noalias !4
  %v13381 = load i64, ptr %slot2487, align 8
  %v13382 = load i64, ptr %slot44, align 8
  %p13383 = inttoptr i64 %v13382 to ptr
  store i64 %v13381, ptr %p13383, align 8, !alias.scope !3, !noalias !4
  %v13384 = load i64, ptr %slot44, align 8
  %p13385 = inttoptr i64 %v13384 to ptr
  %ld13386 = load i64, ptr %p13385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13386, ptr %slot2488, align 8
  %v13387 = load i64, ptr %slot44, align 8
  %p13388 = inttoptr i64 %v13387 to ptr
  %ld13389 = load i64, ptr %p13388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13389, ptr %slot2489, align 8
  %v13390 = load i64, ptr %slot24, align 8
  store i64 %v13390, ptr %slot2490, align 8
  %v13391 = load i64, ptr %slot64, align 8
  store i64 %v13391, ptr %slot2491, align 8
  %v13392 = load i64, ptr %slot63, align 8
  %v13393 = load i64, ptr %slot2490, align 8
  %v13394 = load i64, ptr %slot2489, align 8
  %v13395 = load i64, ptr %slot2491, align 8
  %cv13396 = trunc i64 %v13395 to i32
  %call13397 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v13392, i64 %v13393, i64 %v13394, i32 %cv13396) nomerge, !dbg !216
  store i32 %call13397, ptr %slot2492, align 8
  %v13398 = load i32, ptr %slot2492, align 8
  %cv13399 = zext i32 %v13398 to i64
  %cond13400 = icmp ne i64 %cv13399, 0
  br i1 %cond13400, label %bb_rcsuccess3913, label %bb_rcfailure3913
bb_rcfailure3913:
  %v13401 = load i64, ptr %slot63, align 8
  %p13402 = inttoptr i64 %v13401 to ptr
  %call13403 = call i32 @myl_rc_take_failure(ptr %p13402) nomerge, !dbg !216
  store i32 %call13403, ptr %slot2493, align 8
  %v13404 = load i64, ptr %slot1, align 8
  %p13405 = inttoptr i64 %v13404 to ptr
  %v13406 = load i32, ptr %slot2493, align 8
  %call13407 = call i32 @myl_qbe_rc_status(ptr %p13405, i32 %v13406) nomerge, !dbg !216
  store i32 %call13407, ptr %slot2494, align 8
  br label %bb_failure
bb_rcsuccess3913:
  %v13408 = load i64, ptr %slot17, align 8
  %p13409 = inttoptr i64 %v13408 to ptr
  store i32 0, ptr %p13409, align 4, !alias.scope !3, !noalias !4
  %v13410 = load i64, ptr %slot20, align 8
  %p13411 = inttoptr i64 %v13410 to ptr
  store i32 2, ptr %p13411, align 4, !alias.scope !3, !noalias !4
  %v13412 = load i64, ptr %slot19, align 8
  %p13413 = inttoptr i64 %v13412 to ptr
  store i32 1, ptr %p13413, align 4, !alias.scope !3, !noalias !4
  %v13414 = load i64, ptr %slot24, align 8
  store i64 %v13414, ptr %slot2495, align 8
  %v13415 = load i64, ptr %slot19, align 8
  %p13416 = inttoptr i64 %v13415 to ptr
  store i32 0, ptr %p13416, align 4, !alias.scope !3, !noalias !4
  %v13417 = load i64, ptr %slot17, align 8
  %p13418 = inttoptr i64 %v13417 to ptr
  %ld13419 = load i32, ptr %p13418, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13419, ptr %slot2496, align 8
  %v13420 = load i32, ptr %slot2496, align 8
  %cv13421 = zext i32 %v13420 to i64
  %cond13422 = icmp ne i64 %cv13421, 0
  br i1 %cond13422, label %bb_rcslotdrop3923, label %bb_rcslotdone3923
bb_rcslotdrop3923:
  %v13423 = load i64, ptr %slot17, align 8
  %p13424 = inttoptr i64 %v13423 to ptr
  store i32 0, ptr %p13424, align 4, !alias.scope !3, !noalias !4
  %v13425 = load i64, ptr %slot22, align 8
  store i64 %v13425, ptr %slot2497, align 8
  %v13426 = load i64, ptr %slot18, align 8
  %p13427 = inttoptr i64 %v13426 to ptr
  %ld13428 = load i32, ptr %p13427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13428, ptr %slot2498, align 8
  %v13429 = load i32, ptr %slot2498, align 8
  %op13430 = and i32 %v13429, 28
  store i32 %op13430, ptr %slot2499, align 8
  %v13431 = load i32, ptr %slot2499, align 8
  %cv13432 = zext i32 %v13431 to i64
  %cond13433 = icmp ne i64 %cv13432, 0
  br i1 %cond13433, label %bb_rcslotrole3923, label %bb_rcslotowner3923
bb_rcslotrole3923:
  %v13434 = load i64, ptr %slot63, align 8
  store i64 %v13434, ptr %slot2500, align 8
  %v13435 = load i64, ptr %slot2500, align 8
  %v13436 = load i64, ptr %slot2497, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v13435, i64 %v13436) nomerge, !dbg !216
  br label %bb_rcslotdone3923
bb_rcslotowner3923:
  %v13437 = load i64, ptr %slot63, align 8
  store i64 %v13437, ptr %slot2501, align 8
  %v13438 = load i64, ptr %slot2501, align 8
  %v13439 = load i64, ptr %slot2497, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v13438, i64 %v13439) nomerge, !dbg !216
  br label %bb_rcslotdone3923
bb_rcslotdone3923:
  %v13440 = load i64, ptr %slot15, align 8
  %p13441 = inttoptr i64 %v13440 to ptr
  %ld13442 = load i32, ptr %p13441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13442, ptr %slot2502, align 8
  %v13443 = load i32, ptr %slot2502, align 8
  %cv13444 = zext i32 %v13443 to i64
  %cond13445 = icmp ne i64 %cv13444, 0
  br i1 %cond13445, label %bb_rcslotdrop3950, label %bb_rcslotdone3950
bb_rcslotdrop3950:
  %v13446 = load i64, ptr %slot15, align 8
  %p13447 = inttoptr i64 %v13446 to ptr
  store i32 0, ptr %p13447, align 4, !alias.scope !3, !noalias !4
  %v13448 = load i64, ptr %slot43, align 8
  store i64 %v13448, ptr %slot2503, align 8
  %v13449 = load i64, ptr %slot16, align 8
  %p13450 = inttoptr i64 %v13449 to ptr
  %ld13451 = load i32, ptr %p13450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13451, ptr %slot2504, align 8
  %v13452 = load i32, ptr %slot2504, align 8
  %op13453 = and i32 %v13452, 28
  store i32 %op13453, ptr %slot2505, align 8
  %v13454 = load i32, ptr %slot2505, align 8
  %cv13455 = zext i32 %v13454 to i64
  %cond13456 = icmp ne i64 %cv13455, 0
  br i1 %cond13456, label %bb_rcslotrole3950, label %bb_rcslotowner3950
bb_rcslotrole3950:
  %v13457 = load i64, ptr %slot63, align 8
  store i64 %v13457, ptr %slot2506, align 8
  %v13458 = load i64, ptr %slot2506, align 8
  %v13459 = load i64, ptr %slot2503, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13458, i64 %v13459) nomerge, !dbg !216
  br label %bb_rcslotdone3950
bb_rcslotowner3950:
  %v13460 = load i64, ptr %slot63, align 8
  store i64 %v13460, ptr %slot2507, align 8
  %v13461 = load i64, ptr %slot2507, align 8
  %v13462 = load i64, ptr %slot2503, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13461, i64 %v13462) nomerge, !dbg !216
  br label %bb_rcslotdone3950
bb_rcslotdone3950:
  %v13463 = load i64, ptr %slot13, align 8
  %p13464 = inttoptr i64 %v13463 to ptr
  %ld13465 = load i32, ptr %p13464, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13465, ptr %slot2508, align 8
  %v13466 = load i32, ptr %slot2508, align 8
  %cv13467 = zext i32 %v13466 to i64
  %cond13468 = icmp ne i64 %cv13467, 0
  br i1 %cond13468, label %bb_rcslotdrop3959, label %bb_rcslotdone3959
bb_rcslotdrop3959:
  %v13469 = load i64, ptr %slot13, align 8
  %p13470 = inttoptr i64 %v13469 to ptr
  store i32 0, ptr %p13470, align 4, !alias.scope !3, !noalias !4
  %v13471 = load i64, ptr %slot42, align 8
  store i64 %v13471, ptr %slot2509, align 8
  %v13472 = load i64, ptr %slot14, align 8
  %p13473 = inttoptr i64 %v13472 to ptr
  %ld13474 = load i32, ptr %p13473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13474, ptr %slot2510, align 8
  %v13475 = load i32, ptr %slot2510, align 8
  %op13476 = and i32 %v13475, 28
  store i32 %op13476, ptr %slot2511, align 8
  %v13477 = load i32, ptr %slot2511, align 8
  %cv13478 = zext i32 %v13477 to i64
  %cond13479 = icmp ne i64 %cv13478, 0
  br i1 %cond13479, label %bb_rcslotrole3959, label %bb_rcslotowner3959
bb_rcslotrole3959:
  %v13480 = load i64, ptr %slot63, align 8
  store i64 %v13480, ptr %slot2512, align 8
  %v13481 = load i64, ptr %slot2509, align 8
  %p13482 = inttoptr i64 %v13481 to ptr
  %ld13483 = load i64, ptr %p13482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13483, ptr %slot2513, align 8
  %v13484 = load i64, ptr %slot2513, align 8
  %cmp13485 = icmp ne i64 %v13484, 0
  %cv13486 = zext i1 %cmp13485 to i32
  store i32 %cv13486, ptr %slot2514, align 8
  %v13487 = load i32, ptr %slot2514, align 8
  %cv13488 = zext i32 %v13487 to i64
  %cond13489 = icmp ne i64 %cv13488, 0
  br i1 %cond13489, label %bb_rcgnn3975, label %bb_rcgdone3975
bb_rcgnn3975:
  %v13490 = load i64, ptr %slot2513, align 8
  %op13491 = sub i64 %v13490, 16
  store i64 %op13491, ptr %slot2515, align 8
  %v13492 = load i64, ptr %slot2513, align 8
  %p13493 = inttoptr i64 %v13492 to ptr
  %rgep13494 = getelementptr i8, ptr %p13493, i64 -16
  %ld13495 = load i64, ptr %rgep13494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13495, ptr %slot2516, align 8
  %v13496 = load i64, ptr %slot2516, align 8
  %op13497 = and i64 %v13496, 4611686018427387906
  store i64 %op13497, ptr %slot2517, align 8
  %v13498 = load i64, ptr %slot2517, align 8
  %cmp13499 = icmp ne i64 %v13498, 0
  %cv13500 = zext i1 %cmp13499 to i32
  store i32 %cv13500, ptr %slot2518, align 8
  %v13501 = load i32, ptr %slot2518, align 8
  %cv13502 = zext i32 %v13501 to i64
  %cond13503 = icmp ne i64 %cv13502, 0
  br i1 %cond13503, label %bb_rcgclear3975, label %bb_rcgcounted3975
bb_rcgcounted3975:
  %v13504 = load i64, ptr %slot2513, align 8
  %op13505 = sub i64 %v13504, 24
  store i64 %op13505, ptr %slot2519, align 8
  %v13506 = load i64, ptr %slot2513, align 8
  %p13507 = inttoptr i64 %v13506 to ptr
  %rgep13508 = getelementptr i8, ptr %p13507, i64 -24
  %ld13509 = load i64, ptr %rgep13508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13509, ptr %slot2520, align 8
  %v13510 = load i64, ptr %slot2520, align 8
  %op13511 = sub i64 %v13510, 1
  store i64 %op13511, ptr %slot2521, align 8
  %v13512 = load i64, ptr %slot2521, align 8
  %cmp13513 = icmp eq i64 %v13512, 0
  %cv13514 = zext i1 %cmp13513 to i32
  store i32 %cv13514, ptr %slot2522, align 8
  %v13515 = load i32, ptr %slot2522, align 8
  %cv13516 = zext i32 %v13515 to i64
  %cond13517 = icmp ne i64 %cv13516, 0
  br i1 %cond13517, label %bb_rcglast3975, label %bb_rcgdec3975
bb_rcglast3975:
  %v13518 = load i64, ptr %slot2513, align 8
  %op13519 = sub i64 %v13518, 32
  store i64 %op13519, ptr %slot2523, align 8
  %v13520 = load i64, ptr %slot2513, align 8
  %p13521 = inttoptr i64 %v13520 to ptr
  %rgep13522 = getelementptr i8, ptr %p13521, i64 -32
  %ld13523 = load i64, ptr %rgep13522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13523, ptr %slot2524, align 8
  %v13524 = load i64, ptr %slot2524, align 8
  %cmp13525 = icmp ne i64 %v13524, 0
  %cv13526 = zext i1 %cmp13525 to i32
  store i32 %cv13526, ptr %slot2525, align 8
  %v13527 = load i32, ptr %slot2525, align 8
  %cv13528 = zext i32 %v13527 to i64
  %cond13529 = icmp ne i64 %cv13528, 0
  br i1 %cond13529, label %bb_rcgdec3975, label %bb_rcgslow3975
bb_rcgslow3975:
  %v13530 = load i64, ptr %slot2512, align 8
  %v13531 = load i64, ptr %slot2509, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v13530, i64 %v13531) nomerge, !dbg !216
  br label %bb_rcgdone3975
bb_rcgdec3975:
  %v13532 = load i64, ptr %slot2521, align 8
  %v13533 = load i64, ptr %slot2513, align 8
  %p13534 = inttoptr i64 %v13533 to ptr
  %rgep13535 = getelementptr i8, ptr %p13534, i64 -24
  store i64 %v13532, ptr %rgep13535, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3975
bb_rcgclear3975:
  %v13536 = load i64, ptr %slot2509, align 8
  %p13537 = inttoptr i64 %v13536 to ptr
  store i64 0, ptr %p13537, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3975
bb_rcgdone3975:
  br label %bb_rcslotdone3959
bb_rcslotowner3959:
  %v13538 = load i64, ptr %slot63, align 8
  store i64 %v13538, ptr %slot2526, align 8
  %v13539 = load i64, ptr %slot2509, align 8
  %p13540 = inttoptr i64 %v13539 to ptr
  %ld13541 = load i64, ptr %p13540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13541, ptr %slot2527, align 8
  %v13542 = load i64, ptr %slot2527, align 8
  %cmp13543 = icmp ne i64 %v13542, 0
  %cv13544 = zext i1 %cmp13543 to i32
  store i32 %cv13544, ptr %slot2528, align 8
  %v13545 = load i32, ptr %slot2528, align 8
  %cv13546 = zext i32 %v13545 to i64
  %cond13547 = icmp ne i64 %cv13546, 0
  br i1 %cond13547, label %bb_rcgnn3990, label %bb_rcgdone3990
bb_rcgnn3990:
  %v13548 = load i64, ptr %slot2527, align 8
  %op13549 = sub i64 %v13548, 16
  store i64 %op13549, ptr %slot2529, align 8
  %v13550 = load i64, ptr %slot2527, align 8
  %p13551 = inttoptr i64 %v13550 to ptr
  %rgep13552 = getelementptr i8, ptr %p13551, i64 -16
  %ld13553 = load i64, ptr %rgep13552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13553, ptr %slot2530, align 8
  %v13554 = load i64, ptr %slot2530, align 8
  %op13555 = and i64 %v13554, 4611686018427387906
  store i64 %op13555, ptr %slot2531, align 8
  %v13556 = load i64, ptr %slot2531, align 8
  %cmp13557 = icmp ne i64 %v13556, 0
  %cv13558 = zext i1 %cmp13557 to i32
  store i32 %cv13558, ptr %slot2532, align 8
  %v13559 = load i32, ptr %slot2532, align 8
  %cv13560 = zext i32 %v13559 to i64
  %cond13561 = icmp ne i64 %cv13560, 0
  br i1 %cond13561, label %bb_rcgclear3990, label %bb_rcgcounted3990
bb_rcgcounted3990:
  %v13562 = load i64, ptr %slot2527, align 8
  %op13563 = sub i64 %v13562, 32
  store i64 %op13563, ptr %slot2533, align 8
  %v13564 = load i64, ptr %slot2527, align 8
  %p13565 = inttoptr i64 %v13564 to ptr
  %rgep13566 = getelementptr i8, ptr %p13565, i64 -32
  %ld13567 = load i64, ptr %rgep13566, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13567, ptr %slot2534, align 8
  %v13568 = load i64, ptr %slot2534, align 8
  %op13569 = sub i64 %v13568, 1
  store i64 %op13569, ptr %slot2535, align 8
  %v13570 = load i64, ptr %slot2535, align 8
  %cmp13571 = icmp eq i64 %v13570, 0
  %cv13572 = zext i1 %cmp13571 to i32
  store i32 %cv13572, ptr %slot2536, align 8
  %v13573 = load i32, ptr %slot2536, align 8
  %cv13574 = zext i32 %v13573 to i64
  %cond13575 = icmp ne i64 %cv13574, 0
  br i1 %cond13575, label %bb_rcglast3990, label %bb_rcgdec3990
bb_rcglast3990:
  %v13576 = load i64, ptr %slot2527, align 8
  %op13577 = sub i64 %v13576, 24
  store i64 %op13577, ptr %slot2537, align 8
  %v13578 = load i64, ptr %slot2527, align 8
  %p13579 = inttoptr i64 %v13578 to ptr
  %rgep13580 = getelementptr i8, ptr %p13579, i64 -24
  %ld13581 = load i64, ptr %rgep13580, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13581, ptr %slot2538, align 8
  %v13582 = load i64, ptr %slot2538, align 8
  %cmp13583 = icmp ne i64 %v13582, 0
  %cv13584 = zext i1 %cmp13583 to i32
  store i32 %cv13584, ptr %slot2539, align 8
  %v13585 = load i32, ptr %slot2539, align 8
  %cv13586 = zext i32 %v13585 to i64
  %cond13587 = icmp ne i64 %cv13586, 0
  br i1 %cond13587, label %bb_rcgdec3990, label %bb_rcgslow3990
bb_rcgslow3990:
  %v13588 = load i64, ptr %slot2526, align 8
  %v13589 = load i64, ptr %slot2509, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v13588, i64 %v13589) nomerge, !dbg !216
  br label %bb_rcgdone3990
bb_rcgdec3990:
  %v13590 = load i64, ptr %slot2535, align 8
  %v13591 = load i64, ptr %slot2527, align 8
  %p13592 = inttoptr i64 %v13591 to ptr
  %rgep13593 = getelementptr i8, ptr %p13592, i64 -32
  store i64 %v13590, ptr %rgep13593, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3990
bb_rcgclear3990:
  %v13594 = load i64, ptr %slot2509, align 8
  %p13595 = inttoptr i64 %v13594 to ptr
  store i64 0, ptr %p13595, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3990
bb_rcgdone3990:
  br label %bb_rcslotdone3959
bb_rcslotdone3959:
  %v13596 = load i64, ptr %slot11, align 8
  %p13597 = inttoptr i64 %v13596 to ptr
  %ld13598 = load i32, ptr %p13597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13598, ptr %slot2540, align 8
  %v13599 = load i32, ptr %slot2540, align 8
  %cv13600 = zext i32 %v13599 to i64
  %cond13601 = icmp ne i64 %cv13600, 0
  br i1 %cond13601, label %bb_rcslotdrop3996, label %bb_rcslotdone3996
bb_rcslotdrop3996:
  %v13602 = load i64, ptr %slot11, align 8
  %p13603 = inttoptr i64 %v13602 to ptr
  store i32 0, ptr %p13603, align 4, !alias.scope !3, !noalias !4
  %v13604 = load i64, ptr %slot41, align 8
  store i64 %v13604, ptr %slot2541, align 8
  %v13605 = load i64, ptr %slot12, align 8
  %p13606 = inttoptr i64 %v13605 to ptr
  %ld13607 = load i32, ptr %p13606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13607, ptr %slot2542, align 8
  %v13608 = load i32, ptr %slot2542, align 8
  %op13609 = and i32 %v13608, 28
  store i32 %op13609, ptr %slot2543, align 8
  %v13610 = load i32, ptr %slot2543, align 8
  %cv13611 = zext i32 %v13610 to i64
  %cond13612 = icmp ne i64 %cv13611, 0
  br i1 %cond13612, label %bb_rcslotrole3996, label %bb_rcslotowner3996
bb_rcslotrole3996:
  %v13613 = load i64, ptr %slot63, align 8
  store i64 %v13613, ptr %slot2544, align 8
  %v13614 = load i64, ptr %slot2541, align 8
  %p13615 = inttoptr i64 %v13614 to ptr
  %ld13616 = load i64, ptr %p13615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13616, ptr %slot2545, align 8
  %v13617 = load i64, ptr %slot2545, align 8
  %cmp13618 = icmp ne i64 %v13617, 0
  %cv13619 = zext i1 %cmp13618 to i32
  store i32 %cv13619, ptr %slot2546, align 8
  %v13620 = load i32, ptr %slot2546, align 8
  %cv13621 = zext i32 %v13620 to i64
  %cond13622 = icmp ne i64 %cv13621, 0
  br i1 %cond13622, label %bb_rcgnn4012, label %bb_rcgdone4012
bb_rcgnn4012:
  %v13623 = load i64, ptr %slot2545, align 8
  %op13624 = sub i64 %v13623, 16
  store i64 %op13624, ptr %slot2547, align 8
  %v13625 = load i64, ptr %slot2545, align 8
  %p13626 = inttoptr i64 %v13625 to ptr
  %rgep13627 = getelementptr i8, ptr %p13626, i64 -16
  %ld13628 = load i64, ptr %rgep13627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13628, ptr %slot2548, align 8
  %v13629 = load i64, ptr %slot2548, align 8
  %op13630 = and i64 %v13629, 4611686018427387906
  store i64 %op13630, ptr %slot2549, align 8
  %v13631 = load i64, ptr %slot2549, align 8
  %cmp13632 = icmp ne i64 %v13631, 0
  %cv13633 = zext i1 %cmp13632 to i32
  store i32 %cv13633, ptr %slot2550, align 8
  %v13634 = load i32, ptr %slot2550, align 8
  %cv13635 = zext i32 %v13634 to i64
  %cond13636 = icmp ne i64 %cv13635, 0
  br i1 %cond13636, label %bb_rcgclear4012, label %bb_rcgcounted4012
bb_rcgcounted4012:
  %v13637 = load i64, ptr %slot2545, align 8
  %op13638 = sub i64 %v13637, 24
  store i64 %op13638, ptr %slot2551, align 8
  %v13639 = load i64, ptr %slot2545, align 8
  %p13640 = inttoptr i64 %v13639 to ptr
  %rgep13641 = getelementptr i8, ptr %p13640, i64 -24
  %ld13642 = load i64, ptr %rgep13641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13642, ptr %slot2552, align 8
  %v13643 = load i64, ptr %slot2552, align 8
  %op13644 = sub i64 %v13643, 1
  store i64 %op13644, ptr %slot2553, align 8
  %v13645 = load i64, ptr %slot2553, align 8
  %cmp13646 = icmp eq i64 %v13645, 0
  %cv13647 = zext i1 %cmp13646 to i32
  store i32 %cv13647, ptr %slot2554, align 8
  %v13648 = load i32, ptr %slot2554, align 8
  %cv13649 = zext i32 %v13648 to i64
  %cond13650 = icmp ne i64 %cv13649, 0
  br i1 %cond13650, label %bb_rcglast4012, label %bb_rcgdec4012
bb_rcglast4012:
  %v13651 = load i64, ptr %slot2545, align 8
  %op13652 = sub i64 %v13651, 32
  store i64 %op13652, ptr %slot2555, align 8
  %v13653 = load i64, ptr %slot2545, align 8
  %p13654 = inttoptr i64 %v13653 to ptr
  %rgep13655 = getelementptr i8, ptr %p13654, i64 -32
  %ld13656 = load i64, ptr %rgep13655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13656, ptr %slot2556, align 8
  %v13657 = load i64, ptr %slot2556, align 8
  %cmp13658 = icmp ne i64 %v13657, 0
  %cv13659 = zext i1 %cmp13658 to i32
  store i32 %cv13659, ptr %slot2557, align 8
  %v13660 = load i32, ptr %slot2557, align 8
  %cv13661 = zext i32 %v13660 to i64
  %cond13662 = icmp ne i64 %cv13661, 0
  br i1 %cond13662, label %bb_rcgdec4012, label %bb_rcgslow4012
bb_rcgslow4012:
  %v13663 = load i64, ptr %slot2544, align 8
  %v13664 = load i64, ptr %slot2541, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v13663, i64 %v13664) nomerge, !dbg !216
  br label %bb_rcgdone4012
bb_rcgdec4012:
  %v13665 = load i64, ptr %slot2553, align 8
  %v13666 = load i64, ptr %slot2545, align 8
  %p13667 = inttoptr i64 %v13666 to ptr
  %rgep13668 = getelementptr i8, ptr %p13667, i64 -24
  store i64 %v13665, ptr %rgep13668, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear4012
bb_rcgclear4012:
  %v13669 = load i64, ptr %slot2541, align 8
  %p13670 = inttoptr i64 %v13669 to ptr
  store i64 0, ptr %p13670, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone4012
bb_rcgdone4012:
  br label %bb_rcslotdone3996
bb_rcslotowner3996:
  %v13671 = load i64, ptr %slot63, align 8
  store i64 %v13671, ptr %slot2558, align 8
  %v13672 = load i64, ptr %slot2541, align 8
  %p13673 = inttoptr i64 %v13672 to ptr
  %ld13674 = load i64, ptr %p13673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13674, ptr %slot2559, align 8
  %v13675 = load i64, ptr %slot2559, align 8
  %cmp13676 = icmp ne i64 %v13675, 0
  %cv13677 = zext i1 %cmp13676 to i32
  store i32 %cv13677, ptr %slot2560, align 8
  %v13678 = load i32, ptr %slot2560, align 8
  %cv13679 = zext i32 %v13678 to i64
  %cond13680 = icmp ne i64 %cv13679, 0
  br i1 %cond13680, label %bb_rcgnn4027, label %bb_rcgdone4027
bb_rcgnn4027:
  %v13681 = load i64, ptr %slot2559, align 8
  %op13682 = sub i64 %v13681, 16
  store i64 %op13682, ptr %slot2561, align 8
  %v13683 = load i64, ptr %slot2559, align 8
  %p13684 = inttoptr i64 %v13683 to ptr
  %rgep13685 = getelementptr i8, ptr %p13684, i64 -16
  %ld13686 = load i64, ptr %rgep13685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13686, ptr %slot2562, align 8
  %v13687 = load i64, ptr %slot2562, align 8
  %op13688 = and i64 %v13687, 4611686018427387906
  store i64 %op13688, ptr %slot2563, align 8
  %v13689 = load i64, ptr %slot2563, align 8
  %cmp13690 = icmp ne i64 %v13689, 0
  %cv13691 = zext i1 %cmp13690 to i32
  store i32 %cv13691, ptr %slot2564, align 8
  %v13692 = load i32, ptr %slot2564, align 8
  %cv13693 = zext i32 %v13692 to i64
  %cond13694 = icmp ne i64 %cv13693, 0
  br i1 %cond13694, label %bb_rcgclear4027, label %bb_rcgcounted4027
bb_rcgcounted4027:
  %v13695 = load i64, ptr %slot2559, align 8
  %op13696 = sub i64 %v13695, 32
  store i64 %op13696, ptr %slot2565, align 8
  %v13697 = load i64, ptr %slot2559, align 8
  %p13698 = inttoptr i64 %v13697 to ptr
  %rgep13699 = getelementptr i8, ptr %p13698, i64 -32
  %ld13700 = load i64, ptr %rgep13699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13700, ptr %slot2566, align 8
  %v13701 = load i64, ptr %slot2566, align 8
  %op13702 = sub i64 %v13701, 1
  store i64 %op13702, ptr %slot2567, align 8
  %v13703 = load i64, ptr %slot2567, align 8
  %cmp13704 = icmp eq i64 %v13703, 0
  %cv13705 = zext i1 %cmp13704 to i32
  store i32 %cv13705, ptr %slot2568, align 8
  %v13706 = load i32, ptr %slot2568, align 8
  %cv13707 = zext i32 %v13706 to i64
  %cond13708 = icmp ne i64 %cv13707, 0
  br i1 %cond13708, label %bb_rcglast4027, label %bb_rcgdec4027
bb_rcglast4027:
  %v13709 = load i64, ptr %slot2559, align 8
  %op13710 = sub i64 %v13709, 24
  store i64 %op13710, ptr %slot2569, align 8
  %v13711 = load i64, ptr %slot2559, align 8
  %p13712 = inttoptr i64 %v13711 to ptr
  %rgep13713 = getelementptr i8, ptr %p13712, i64 -24
  %ld13714 = load i64, ptr %rgep13713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13714, ptr %slot2570, align 8
  %v13715 = load i64, ptr %slot2570, align 8
  %cmp13716 = icmp ne i64 %v13715, 0
  %cv13717 = zext i1 %cmp13716 to i32
  store i32 %cv13717, ptr %slot2571, align 8
  %v13718 = load i32, ptr %slot2571, align 8
  %cv13719 = zext i32 %v13718 to i64
  %cond13720 = icmp ne i64 %cv13719, 0
  br i1 %cond13720, label %bb_rcgdec4027, label %bb_rcgslow4027
bb_rcgslow4027:
  %v13721 = load i64, ptr %slot2558, align 8
  %v13722 = load i64, ptr %slot2541, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v13721, i64 %v13722) nomerge, !dbg !216
  br label %bb_rcgdone4027
bb_rcgdec4027:
  %v13723 = load i64, ptr %slot2567, align 8
  %v13724 = load i64, ptr %slot2559, align 8
  %p13725 = inttoptr i64 %v13724 to ptr
  %rgep13726 = getelementptr i8, ptr %p13725, i64 -32
  store i64 %v13723, ptr %rgep13726, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear4027
bb_rcgclear4027:
  %v13727 = load i64, ptr %slot2541, align 8
  %p13728 = inttoptr i64 %v13727 to ptr
  store i64 0, ptr %p13728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone4027
bb_rcgdone4027:
  br label %bb_rcslotdone3996
bb_rcslotdone3996:
  %v13729 = load i64, ptr %slot9, align 8
  %p13730 = inttoptr i64 %v13729 to ptr
  %ld13731 = load i32, ptr %p13730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13731, ptr %slot2572, align 8
  %v13732 = load i32, ptr %slot2572, align 8
  %cv13733 = zext i32 %v13732 to i64
  %cond13734 = icmp ne i64 %cv13733, 0
  br i1 %cond13734, label %bb_rcslotdrop4033, label %bb_rcslotdone4033
bb_rcslotdrop4033:
  %v13735 = load i64, ptr %slot9, align 8
  %p13736 = inttoptr i64 %v13735 to ptr
  store i32 0, ptr %p13736, align 4, !alias.scope !3, !noalias !4
  %v13737 = load i64, ptr %slot40, align 8
  store i64 %v13737, ptr %slot2573, align 8
  %v13738 = load i64, ptr %slot10, align 8
  %p13739 = inttoptr i64 %v13738 to ptr
  %ld13740 = load i32, ptr %p13739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13740, ptr %slot2574, align 8
  %v13741 = load i32, ptr %slot2574, align 8
  %op13742 = and i32 %v13741, 28
  store i32 %op13742, ptr %slot2575, align 8
  %v13743 = load i32, ptr %slot2575, align 8
  %cv13744 = zext i32 %v13743 to i64
  %cond13745 = icmp ne i64 %cv13744, 0
  br i1 %cond13745, label %bb_rcslotrole4033, label %bb_rcslotowner4033
bb_rcslotrole4033:
  %v13746 = load i64, ptr %slot63, align 8
  store i64 %v13746, ptr %slot2576, align 8
  %v13747 = load i64, ptr %slot2573, align 8
  %p13748 = inttoptr i64 %v13747 to ptr
  %ld13749 = load i64, ptr %p13748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13749, ptr %slot2577, align 8
  %v13750 = load i64, ptr %slot2577, align 8
  %cmp13751 = icmp ne i64 %v13750, 0
  %cv13752 = zext i1 %cmp13751 to i32
  store i32 %cv13752, ptr %slot2578, align 8
  %v13753 = load i32, ptr %slot2578, align 8
  %cv13754 = zext i32 %v13753 to i64
  %cond13755 = icmp ne i64 %cv13754, 0
  br i1 %cond13755, label %bb_rcgnn4049, label %bb_rcgdone4049
bb_rcgnn4049:
  %v13756 = load i64, ptr %slot2577, align 8
  %op13757 = sub i64 %v13756, 16
  store i64 %op13757, ptr %slot2579, align 8
  %v13758 = load i64, ptr %slot2577, align 8
  %p13759 = inttoptr i64 %v13758 to ptr
  %rgep13760 = getelementptr i8, ptr %p13759, i64 -16
  %ld13761 = load i64, ptr %rgep13760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13761, ptr %slot2580, align 8
  %v13762 = load i64, ptr %slot2580, align 8
  %op13763 = and i64 %v13762, 4611686018427387906
  store i64 %op13763, ptr %slot2581, align 8
  %v13764 = load i64, ptr %slot2581, align 8
  %cmp13765 = icmp ne i64 %v13764, 0
  %cv13766 = zext i1 %cmp13765 to i32
  store i32 %cv13766, ptr %slot2582, align 8
  %v13767 = load i32, ptr %slot2582, align 8
  %cv13768 = zext i32 %v13767 to i64
  %cond13769 = icmp ne i64 %cv13768, 0
  br i1 %cond13769, label %bb_rcgclear4049, label %bb_rcgcounted4049
bb_rcgcounted4049:
  %v13770 = load i64, ptr %slot2577, align 8
  %op13771 = sub i64 %v13770, 24
  store i64 %op13771, ptr %slot2583, align 8
  %v13772 = load i64, ptr %slot2577, align 8
  %p13773 = inttoptr i64 %v13772 to ptr
  %rgep13774 = getelementptr i8, ptr %p13773, i64 -24
  %ld13775 = load i64, ptr %rgep13774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13775, ptr %slot2584, align 8
  %v13776 = load i64, ptr %slot2584, align 8
  %op13777 = sub i64 %v13776, 1
  store i64 %op13777, ptr %slot2585, align 8
  %v13778 = load i64, ptr %slot2585, align 8
  %cmp13779 = icmp eq i64 %v13778, 0
  %cv13780 = zext i1 %cmp13779 to i32
  store i32 %cv13780, ptr %slot2586, align 8
  %v13781 = load i32, ptr %slot2586, align 8
  %cv13782 = zext i32 %v13781 to i64
  %cond13783 = icmp ne i64 %cv13782, 0
  br i1 %cond13783, label %bb_rcglast4049, label %bb_rcgdec4049
bb_rcglast4049:
  %v13784 = load i64, ptr %slot2577, align 8
  %op13785 = sub i64 %v13784, 32
  store i64 %op13785, ptr %slot2587, align 8
  %v13786 = load i64, ptr %slot2577, align 8
  %p13787 = inttoptr i64 %v13786 to ptr
  %rgep13788 = getelementptr i8, ptr %p13787, i64 -32
  %ld13789 = load i64, ptr %rgep13788, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13789, ptr %slot2588, align 8
  %v13790 = load i64, ptr %slot2588, align 8
  %cmp13791 = icmp ne i64 %v13790, 0
  %cv13792 = zext i1 %cmp13791 to i32
  store i32 %cv13792, ptr %slot2589, align 8
  %v13793 = load i32, ptr %slot2589, align 8
  %cv13794 = zext i32 %v13793 to i64
  %cond13795 = icmp ne i64 %cv13794, 0
  br i1 %cond13795, label %bb_rcgdec4049, label %bb_rcgslow4049
bb_rcgslow4049:
  %v13796 = load i64, ptr %slot2576, align 8
  %v13797 = load i64, ptr %slot2573, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v13796, i64 %v13797) nomerge, !dbg !216
  br label %bb_rcgdone4049
bb_rcgdec4049:
  %v13798 = load i64, ptr %slot2585, align 8
  %v13799 = load i64, ptr %slot2577, align 8
  %p13800 = inttoptr i64 %v13799 to ptr
  %rgep13801 = getelementptr i8, ptr %p13800, i64 -24
  store i64 %v13798, ptr %rgep13801, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear4049
bb_rcgclear4049:
  %v13802 = load i64, ptr %slot2573, align 8
  %p13803 = inttoptr i64 %v13802 to ptr
  store i64 0, ptr %p13803, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone4049
bb_rcgdone4049:
  br label %bb_rcslotdone4033
bb_rcslotowner4033:
  %v13804 = load i64, ptr %slot63, align 8
  store i64 %v13804, ptr %slot2590, align 8
  %v13805 = load i64, ptr %slot2573, align 8
  %p13806 = inttoptr i64 %v13805 to ptr
  %ld13807 = load i64, ptr %p13806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13807, ptr %slot2591, align 8
  %v13808 = load i64, ptr %slot2591, align 8
  %cmp13809 = icmp ne i64 %v13808, 0
  %cv13810 = zext i1 %cmp13809 to i32
  store i32 %cv13810, ptr %slot2592, align 8
  %v13811 = load i32, ptr %slot2592, align 8
  %cv13812 = zext i32 %v13811 to i64
  %cond13813 = icmp ne i64 %cv13812, 0
  br i1 %cond13813, label %bb_rcgnn4064, label %bb_rcgdone4064
bb_rcgnn4064:
  %v13814 = load i64, ptr %slot2591, align 8
  %op13815 = sub i64 %v13814, 16
  store i64 %op13815, ptr %slot2593, align 8
  %v13816 = load i64, ptr %slot2591, align 8
  %p13817 = inttoptr i64 %v13816 to ptr
  %rgep13818 = getelementptr i8, ptr %p13817, i64 -16
  %ld13819 = load i64, ptr %rgep13818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13819, ptr %slot2594, align 8
  %v13820 = load i64, ptr %slot2594, align 8
  %op13821 = and i64 %v13820, 4611686018427387906
  store i64 %op13821, ptr %slot2595, align 8
  %v13822 = load i64, ptr %slot2595, align 8
  %cmp13823 = icmp ne i64 %v13822, 0
  %cv13824 = zext i1 %cmp13823 to i32
  store i32 %cv13824, ptr %slot2596, align 8
  %v13825 = load i32, ptr %slot2596, align 8
  %cv13826 = zext i32 %v13825 to i64
  %cond13827 = icmp ne i64 %cv13826, 0
  br i1 %cond13827, label %bb_rcgclear4064, label %bb_rcgcounted4064
bb_rcgcounted4064:
  %v13828 = load i64, ptr %slot2591, align 8
  %op13829 = sub i64 %v13828, 32
  store i64 %op13829, ptr %slot2597, align 8
  %v13830 = load i64, ptr %slot2591, align 8
  %p13831 = inttoptr i64 %v13830 to ptr
  %rgep13832 = getelementptr i8, ptr %p13831, i64 -32
  %ld13833 = load i64, ptr %rgep13832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13833, ptr %slot2598, align 8
  %v13834 = load i64, ptr %slot2598, align 8
  %op13835 = sub i64 %v13834, 1
  store i64 %op13835, ptr %slot2599, align 8
  %v13836 = load i64, ptr %slot2599, align 8
  %cmp13837 = icmp eq i64 %v13836, 0
  %cv13838 = zext i1 %cmp13837 to i32
  store i32 %cv13838, ptr %slot2600, align 8
  %v13839 = load i32, ptr %slot2600, align 8
  %cv13840 = zext i32 %v13839 to i64
  %cond13841 = icmp ne i64 %cv13840, 0
  br i1 %cond13841, label %bb_rcglast4064, label %bb_rcgdec4064
bb_rcglast4064:
  %v13842 = load i64, ptr %slot2591, align 8
  %op13843 = sub i64 %v13842, 24
  store i64 %op13843, ptr %slot2601, align 8
  %v13844 = load i64, ptr %slot2591, align 8
  %p13845 = inttoptr i64 %v13844 to ptr
  %rgep13846 = getelementptr i8, ptr %p13845, i64 -24
  %ld13847 = load i64, ptr %rgep13846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13847, ptr %slot2602, align 8
  %v13848 = load i64, ptr %slot2602, align 8
  %cmp13849 = icmp ne i64 %v13848, 0
  %cv13850 = zext i1 %cmp13849 to i32
  store i32 %cv13850, ptr %slot2603, align 8
  %v13851 = load i32, ptr %slot2603, align 8
  %cv13852 = zext i32 %v13851 to i64
  %cond13853 = icmp ne i64 %cv13852, 0
  br i1 %cond13853, label %bb_rcgdec4064, label %bb_rcgslow4064
bb_rcgslow4064:
  %v13854 = load i64, ptr %slot2590, align 8
  %v13855 = load i64, ptr %slot2573, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v13854, i64 %v13855) nomerge, !dbg !216
  br label %bb_rcgdone4064
bb_rcgdec4064:
  %v13856 = load i64, ptr %slot2599, align 8
  %v13857 = load i64, ptr %slot2591, align 8
  %p13858 = inttoptr i64 %v13857 to ptr
  %rgep13859 = getelementptr i8, ptr %p13858, i64 -32
  store i64 %v13856, ptr %rgep13859, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear4064
bb_rcgclear4064:
  %v13860 = load i64, ptr %slot2573, align 8
  %p13861 = inttoptr i64 %v13860 to ptr
  store i64 0, ptr %p13861, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone4064
bb_rcgdone4064:
  br label %bb_rcslotdone4033
bb_rcslotdone4033:
  %v13862 = load i64, ptr %slot7, align 8
  %p13863 = inttoptr i64 %v13862 to ptr
  %ld13864 = load i32, ptr %p13863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13864, ptr %slot2604, align 8
  %v13865 = load i32, ptr %slot2604, align 8
  %cv13866 = zext i32 %v13865 to i64
  %cond13867 = icmp ne i64 %cv13866, 0
  br i1 %cond13867, label %bb_rcslotdrop4088, label %bb_rcslotdone4088
bb_rcslotdrop4088:
  %v13868 = load i64, ptr %slot7, align 8
  %p13869 = inttoptr i64 %v13868 to ptr
  store i32 0, ptr %p13869, align 4, !alias.scope !3, !noalias !4
  %v13870 = load i64, ptr %slot38, align 8
  store i64 %v13870, ptr %slot2605, align 8
  %v13871 = load i64, ptr %slot8, align 8
  %p13872 = inttoptr i64 %v13871 to ptr
  %ld13873 = load i32, ptr %p13872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13873, ptr %slot2606, align 8
  %v13874 = load i32, ptr %slot2606, align 8
  %op13875 = and i32 %v13874, 28
  store i32 %op13875, ptr %slot2607, align 8
  %v13876 = load i32, ptr %slot2607, align 8
  %cv13877 = zext i32 %v13876 to i64
  %cond13878 = icmp ne i64 %cv13877, 0
  br i1 %cond13878, label %bb_rcslotrole4088, label %bb_rcslotowner4088
bb_rcslotrole4088:
  %v13879 = load i64, ptr %slot63, align 8
  store i64 %v13879, ptr %slot2608, align 8
  %v13880 = load i64, ptr %slot2608, align 8
  %v13881 = load i64, ptr %slot2605, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13880, i64 %v13881) nomerge, !dbg !216
  br label %bb_rcslotdone4088
bb_rcslotowner4088:
  %v13882 = load i64, ptr %slot63, align 8
  store i64 %v13882, ptr %slot2609, align 8
  %v13883 = load i64, ptr %slot2609, align 8
  %v13884 = load i64, ptr %slot2605, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13883, i64 %v13884) nomerge, !dbg !216
  br label %bb_rcslotdone4088
bb_rcslotdone4088:
  %v13885 = load i64, ptr %slot2495, align 8
  %p13886 = inttoptr i64 %v13885 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13886, i64 24, i1 false)
  ret void
bb_failure:
  %v13887 = load i64, ptr %slot6, align 8
  %p13888 = inttoptr i64 %v13887 to ptr
  call void @llvm.memset.p0.i64(ptr %p13888, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !216
  %v13889 = load i64, ptr %slot6, align 8
  %p13890 = inttoptr i64 %v13889 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13890, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v13891 = load i64, ptr %slot6, align 8
  %p13892 = inttoptr i64 %v13891 to ptr
  call void @llvm.memset.p0.i64(ptr %p13892, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !216
  %v13893 = load i64, ptr %slot6, align 8
  %p13894 = inttoptr i64 %v13893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13894, i64 24, i1 false)
  ret void
}

@myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d_meta = external global i8, align 8
@myl_lit_2e1774f1e730447dab0b1459b81c248e69750ce5e381e122d6f307ecd76a2f89 = external global i8, align 8
@myl_lit_30bdecd870d597c62d1c30c02882c43b1f27244eec6e99c1398f7fc84cf4ce25 = external global i8, align 8
@myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a = external global i8, align 8
@myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 = external global i8, align 8
@myl_lit_fadbbcee37090aefcabf2bf0f6a9366f5f34ef8c1ccde596b7696a8936daffcc = external global i8, align 8
@myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b = external global i8, align 8
@myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_3ea6e9e7e7e3f3c99e8bd3ee87e61bb9473edc3368079bda3cc736a65b3decbc(ptr sret([24 x i8]) align 8, i64, i64, i64, i64, i64, i64, i64)
declare i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64, i64, i64, i64)
declare void @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd(ptr sret([24 x i8]) align 8, i64, i64, i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare { i64, i64 } @myl_f_e57cc4bfa29a47edaf8fafe0f664bfacf1316c7705c32574aa82bd91cd9e2559(i64, i64, i64)
declare void @myl_f_e8c749c10445dc457f5775bb824164c0e2bada77ed66473babb0974281a32427(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare ptr @myl_native_bytes_encode(ptr, ptr)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_native_text_join(ptr, ptr, ptr)
declare ptr @myl_native_text_scalar(ptr, ptr, i32)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64, i64)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64, i64)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)
declare void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64, i64)
declare void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d", linkageName: "myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8447737441882454303, i64 0, !"myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!128 = !DILocation(line: 22, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!130 = !DILocation(line: 25, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!136 = !DILocation(line: 38, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!138 = !DILocation(line: 40, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!140 = !DILocation(line: 43, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!142 = !DILocation(line: 44, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!144 = !DILocation(line: 52, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!146 = !DILocation(line: 54, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!148 = !DILocation(line: 55, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!150 = !DILocation(line: 57, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!152 = !DILocation(line: 62, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!154 = !DILocation(line: 63, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!156 = !DILocation(line: 65, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!158 = !DILocation(line: 68, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!160 = !DILocation(line: 74, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!162 = !DILocation(line: 86, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647263)
!164 = !DILocation(line: 91, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!166 = !DILocation(line: 96, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!168 = !DILocation(line: 97, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!170 = !DILocation(line: 104, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!172 = !DILocation(line: 106, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!174 = !DILocation(line: 107, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647407)
!176 = !DILocation(line: 109, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!178 = !DILocation(line: 113, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!180 = !DILocation(line: 114, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!182 = !DILocation(line: 117, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647495)
!184 = !DILocation(line: 120, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647503)
!186 = !DILocation(line: 121, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!188 = !DILocation(line: 124, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647551)
!190 = !DILocation(line: 127, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!192 = !DILocation(line: 128, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647567)
!194 = !DILocation(line: 129, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647583)
!196 = !DILocation(line: 131, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647591)
!198 = !DILocation(line: 132, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!200 = !DILocation(line: 133, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647615)
!202 = !DILocation(line: 135, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647679)
!204 = !DILocation(line: 143, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647687)
!206 = !DILocation(line: 144, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647783)
!208 = !DILocation(line: 156, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647823)
!210 = !DILocation(line: 161, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647943)
!212 = !DILocation(line: 176, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647951)
!214 = !DILocation(line: 177, column: 0, scope: !215)
!217 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647959)
!216 = !DILocation(line: 178, column: 0, scope: !217)
