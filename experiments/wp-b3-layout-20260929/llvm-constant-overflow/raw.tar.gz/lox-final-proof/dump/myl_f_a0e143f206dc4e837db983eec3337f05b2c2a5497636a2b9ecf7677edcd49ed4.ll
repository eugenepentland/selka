target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v221 = load i64, ptr %slot1, align 8
  %op222 = add i64 %v221, 32
  store i64 %op222, ptr %slot4, align 8
  %mem223 = alloca i8, i64 16, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot5, align 8
  %mem225 = alloca i8, i64 8, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot6, align 8
  %mem227 = alloca i8, i64 8, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot7, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot8, align 8
  %mem231 = alloca i8, i64 8, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot9, align 8
  %mem233 = alloca i8, i64 8, align 8
  %ptr234 = ptrtoint ptr %mem233 to i64
  store i64 %ptr234, ptr %slot10, align 8
  %mem235 = alloca i8, i64 16, align 8
  %ptr236 = ptrtoint ptr %mem235 to i64
  store i64 %ptr236, ptr %slot11, align 8
  %mem237 = alloca i8, i64 8, align 8
  %ptr238 = ptrtoint ptr %mem237 to i64
  store i64 %ptr238, ptr %slot12, align 8
  %mem239 = alloca i8, i64 16, align 8
  %ptr240 = ptrtoint ptr %mem239 to i64
  store i64 %ptr240, ptr %slot13, align 8
  %mem241 = alloca i8, i64 8, align 8
  %ptr242 = ptrtoint ptr %mem241 to i64
  store i64 %ptr242, ptr %slot14, align 8
  %mem243 = alloca i8, i64 8, align 8
  %ptr244 = ptrtoint ptr %mem243 to i64
  store i64 %ptr244, ptr %slot15, align 8
  %mem245 = alloca i8, i64 8, align 8
  %ptr246 = ptrtoint ptr %mem245 to i64
  store i64 %ptr246, ptr %slot16, align 8
  %mem247 = alloca i8, i64 8, align 8
  %ptr248 = ptrtoint ptr %mem247 to i64
  store i64 %ptr248, ptr %slot17, align 8
  %mem249 = alloca i8, i64 8, align 8
  %ptr250 = ptrtoint ptr %mem249 to i64
  store i64 %ptr250, ptr %slot18, align 8
  %mem251 = alloca i8, i64 16, align 8
  %ptr252 = ptrtoint ptr %mem251 to i64
  store i64 %ptr252, ptr %slot19, align 8
  %mem253 = alloca i8, i64 16, align 8
  %ptr254 = ptrtoint ptr %mem253 to i64
  store i64 %ptr254, ptr %slot20, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot21, align 8
  %mem257 = alloca i8, i64 16, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot22, align 8
  %v259 = load i64, ptr %slot2, align 8
  %v260 = load i64, ptr %slot14, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 %v259, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot3, align 8
  %v263 = load i64, ptr %slot15, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot1, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %call267 = call ptr @myl_qbe_heap(ptr %p266) nomerge, !dbg !110
  %calladdr268 = ptrtoint ptr %call267 to i64
  store i64 %calladdr268, ptr %slot23, align 8
  %v269 = load i64, ptr %slot1, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %call271 = call i64 @myl_qbe_region_mark(ptr %p270) nomerge, !dbg !110
  store i64 %call271, ptr %slot24, align 8
  %v272 = load i64, ptr %slot6, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i32 0, ptr %p273, align 4, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot7, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i32 0, ptr %p275, align 4, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot8, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i32 0, ptr %p277, align 4, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot9, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i32 0, ptr %p279, align 4, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot10, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 0, ptr %p281, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v282 = load i64, ptr %slot15, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot25, align 8
  %v285 = load i64, ptr %slot25, align 8
  %v286 = load i64, ptr %slot16, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot16, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot26, align 8
  %v291 = load i64, ptr %slot26, align 8
  %op292 = add i64 %v291, 0
  store i64 %op292, ptr %slot27, align 8
  %v293 = load i64, ptr %slot27, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8
  store i64 %ld295, ptr %slot28, align 8
  %v296 = load i64, ptr %slot28, align 8
  %v297 = load i64, ptr %slot16, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot17, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 0, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot17, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %ld303 = load i64, ptr %p302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld303, ptr %slot29, align 8
  %v304 = load i64, ptr %slot16, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot30, align 8
  %v307 = load i64, ptr %slot30, align 8
  %v308 = load i64, ptr %slot29, align 8
  %cmp309 = icmp sgt i64 %v307, %v308
  %cv310 = zext i1 %cmp309 to i64
  store i64 %cv310, ptr %slot31, align 8
  %v311 = load i64, ptr %slot31, align 8
  %v312 = load i64, ptr %slot16, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i64 %v311, ptr %p313, align 8, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot16, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot32, align 8
  %v317 = load i64, ptr %slot32, align 8
  %cond318 = icmp ne i64 %v317, 0
  br i1 %cond318, label %bb_next8, label %bb_i14
bb_next8:
  %v319 = load i64, ptr %slot14, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %ld321 = load i64, ptr %p320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld321, ptr %slot33, align 8
  %v322 = load i64, ptr %slot33, align 8
  %v323 = load i64, ptr %slot16, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i64 %v322, ptr %p324, align 8, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot16, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i64, ptr %p326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld327, ptr %slot34, align 8
  %v328 = load i64, ptr %slot34, align 8
  %op329 = add i64 %v328, 0
  store i64 %op329, ptr %slot35, align 8
  %v330 = load i64, ptr %slot35, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8
  store i64 %ld332, ptr %slot36, align 8
  %v333 = load i64, ptr %slot36, align 8
  %v334 = load i64, ptr %slot16, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 %v333, ptr %p335, align 8, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot17, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 9223372036854775807, ptr %p337, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v338 = load i64, ptr %slot15, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot37, align 8
  %v341 = load i64, ptr %slot37, align 8
  %v342 = load i64, ptr %slot18, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot18, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i64, ptr %p345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot38, align 8
  %v347 = load i64, ptr %slot38, align 8
  %op348 = add i64 %v347, 0
  store i64 %op348, ptr %slot39, align 8
  %v349 = load i64, ptr %slot39, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i64, ptr %p350, align 8, !alias.scope !4, !noalias !3
  store i64 %ld351, ptr %slot40, align 8
  %v352 = load i64, ptr %slot40, align 8
  %v353 = load i64, ptr %slot18, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 %v352, ptr %p354, align 8, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot18, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot41, align 8
  %v358 = load i64, ptr %slot17, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot42, align 8
  %v361 = load i64, ptr %slot42, align 8
  %v362 = load i64, ptr %slot41, align 8
  %ovpair364 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v361, i64 %v362)
  %op363 = extractvalue { i64, i1 } %ovpair364, 0
  %ov365 = extractvalue { i64, i1 } %ovpair364, 1
  store i64 %op363, ptr %slot43, align 8
  %v366 = load i64, ptr %slot42, align 8
  %v367 = load i64, ptr %slot41, align 8
  %op368 = xor i64 %v366, %v367
  store i64 %op368, ptr %slot44, align 8
  %v369 = load i64, ptr %slot42, align 8
  %v370 = load i64, ptr %slot43, align 8
  %op371 = xor i64 %v369, %v370
  store i64 %op371, ptr %slot45, align 8
  %v372 = load i64, ptr %slot44, align 8
  %v373 = load i64, ptr %slot45, align 8
  %op374 = and i64 %v372, %v373
  store i64 %op374, ptr %slot46, align 8
  %cv375 = zext i1 %ov365 to i64
  store i64 %cv375, ptr %slot47, align 8
  %v376 = load i64, ptr %slot47, align 8
  %cond377 = icmp ne i64 %v376, 0
  br i1 %cond377, label %bb_overflow18, label %bb_checked18
bb_overflow18:
  %v378 = load i64, ptr %slot1, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %v380 = load i64, ptr %slot42, align 8
  %v381 = load i64, ptr %slot41, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p379, i64 1, i64 %v380, i64 %v381, i64 64) nomerge, !dbg !112
  unreachable
bb_checked18:
  %v382 = load i64, ptr %slot43, align 8
  %v383 = load i64, ptr %slot17, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i64 %v382, ptr %p384, align 8, !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot17, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i64, ptr %p386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld387, ptr %slot48, align 8
  %v388 = load i64, ptr %slot16, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot49, align 8
  %v391 = load i64, ptr %slot49, align 8
  %v392 = load i64, ptr %slot48, align 8
  %cmp393 = icmp sgt i64 %v391, %v392
  %cv394 = zext i1 %cmp393 to i64
  store i64 %cv394, ptr %slot50, align 8
  %v395 = load i64, ptr %slot50, align 8
  %v396 = load i64, ptr %slot16, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i14:
  %v398 = load i64, ptr %slot16, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 0, ptr %p399, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v400 = load i64, ptr %slot16, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i64, ptr %p401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld402, ptr %slot51, align 8
  %v403 = load i64, ptr %slot51, align 8
  %cond404 = icmp ne i64 %v403, 0
  br i1 %cond404, label %bb_next27, label %bb_i19
bb_next27:
  %p405 = inttoptr i64 ptrtoint (ptr @myl_lit_96b96a195291d03f92cca564c4274dd7d042db7850382b1d70eb29994402efe8 to i64) to ptr
  %ld406 = load i64, ptr %p405, align 8, !alias.scope !4, !noalias !3
  store i64 %ld406, ptr %slot52, align 8
  %v407 = load i64, ptr %slot52, align 8
  %v408 = load i64, ptr %slot16, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 %v407, ptr %p409, align 8, !alias.scope !3, !noalias !4
  %v410 = load i64, ptr %slot16, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i64, ptr %p411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld412, ptr %slot53, align 8
  %v413 = load i64, ptr %slot53, align 8
  %v414 = load i64, ptr %slot12, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i64 %v413, ptr %p415, align 8, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot12, align 8
  store i64 %v416, ptr %slot54, align 8
  %v417 = load i64, ptr %slot13, align 8
  store i64 %v417, ptr %slot55, align 8
  %v418 = load i64, ptr %slot54, align 8
  %v419 = load i64, ptr %slot55, align 8
  %p420 = inttoptr i64 %v418 to ptr
  %p421 = inttoptr i64 %v419 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p421, ptr %p420, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot9, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i32 2, ptr %p423, align 4, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot8, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i32 1, ptr %p425, align 4, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot11, align 8
  store i64 %v426, ptr %slot56, align 8
  %v427 = load i64, ptr %slot13, align 8
  store i64 %v427, ptr %slot57, align 8
  %v428 = load i64, ptr %slot57, align 8
  %v429 = load i64, ptr %slot56, align 8
  %p430 = inttoptr i64 %v428 to ptr
  %p431 = inttoptr i64 %v429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p431, ptr %p430, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot7, align 8
  %p433 = inttoptr i64 %v432 to ptr
  store i32 2, ptr %p433, align 4, !alias.scope !3, !noalias !4
  %v434 = load i64, ptr %slot9, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i32, ptr %p435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld436, ptr %slot58, align 8
  %v437 = load i32, ptr %slot58, align 8
  %v438 = load i64, ptr %slot7, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i32 %v437, ptr %p439, align 4, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot8, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i32 0, ptr %p441, align 4, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot6, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i32 1, ptr %p443, align 4, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot56, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot59, align 8
  %v447 = load i64, ptr %slot59, align 8
  %v448 = load i64, ptr %slot16, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 %v447, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot19, align 8
  store i64 %v450, ptr %slot60, align 8
  %v451 = load i64, ptr %slot60, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i64 0, ptr %p452, align 8, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot60, align 8
  %p455 = inttoptr i64 %v453 to ptr
  %gep456 = getelementptr i8, ptr %p455, i64 8
  %op454 = ptrtoint ptr %gep456 to i64
  store i64 %op454, ptr %slot61, align 8
  %v457 = load i64, ptr %slot61, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 0, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot60, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i32 1, ptr %p460, align 4, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot10, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i32 1, ptr %p462, align 4, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot16, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %ld465 = load i64, ptr %p464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld465, ptr %slot62, align 8
  %v466 = load i64, ptr %slot62, align 8
  %v467 = load i64, ptr %slot12, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i64 %v466, ptr %p468, align 8, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot12, align 8
  store i64 %v469, ptr %slot63, align 8
  %v470 = load i64, ptr %slot60, align 8
  %p472 = inttoptr i64 %v470 to ptr
  %gep473 = getelementptr i8, ptr %p472, i64 8
  %op471 = ptrtoint ptr %gep473 to i64
  store i64 %op471, ptr %slot64, align 8
  %v474 = load i64, ptr %slot24, align 8
  store i64 %v474, ptr %slot65, align 8
  %v475 = load i64, ptr %slot16, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %ld477 = load i64, ptr %p476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld477, ptr %slot66, align 8
  %v478 = load i64, ptr %slot66, align 8
  %v479 = load i64, ptr %slot12, align 8
  %p480 = inttoptr i64 %v479 to ptr
  store i64 %v478, ptr %p480, align 8, !alias.scope !3, !noalias !4
  %v481 = load i64, ptr %slot12, align 8
  store i64 %v481, ptr %slot67, align 8
  %v482 = load i64, ptr %slot13, align 8
  store i64 %v482, ptr %slot68, align 8
  %v483 = load i64, ptr %slot24, align 8
  store i64 %v483, ptr %slot69, align 8
  %v484 = load i64, ptr %slot67, align 8
  %p486 = inttoptr i64 %v484 to ptr
  %gep487 = getelementptr i8, ptr %p486, i64 0
  %op485 = ptrtoint ptr %gep487 to i64
  store i64 %op485, ptr %slot70, align 8
  %v488 = load i64, ptr %slot70, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %ld490 = load i64, ptr %p489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld490, ptr %slot71, align 8
  %v491 = load i64, ptr %slot71, align 8
  %cmp492 = icmp ne i64 %v491, 0
  %cv493 = zext i1 %cmp492 to i32
  store i32 %cv493, ptr %slot72, align 8
  %v494 = load i32, ptr %slot72, align 8
  %cv495 = zext i32 %v494 to i64
  %cond496 = icmp ne i64 %cv495, 0
  br i1 %cond496, label %bb_rcmoveheader58, label %bb_rcmovenext58
bb_rcmoveheader58:
  %v497 = load i64, ptr %slot71, align 8
  %op498 = sub i64 %v497, 16
  store i64 %op498, ptr %slot73, align 8
  %v499 = load i64, ptr %slot71, align 8
  %p500 = inttoptr i64 %v499 to ptr
  %rgep501 = getelementptr i8, ptr %p500, i64 -16
  %ld502 = load i64, ptr %rgep501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld502, ptr %slot74, align 8
  %v503 = load i64, ptr %slot74, align 8
  %op504 = and i64 %v503, 5764607523034234881
  store i64 %op504, ptr %slot75, align 8
  %v505 = load i64, ptr %slot75, align 8
  %cmp506 = icmp ne i64 %v505, 0
  %cv507 = zext i1 %cmp506 to i32
  store i32 %cv507, ptr %slot76, align 8
  %v508 = load i32, ptr %slot76, align 8
  %cv509 = zext i32 %v508 to i64
  %cond510 = icmp ne i64 %cv509, 0
  br i1 %cond510, label %bb_rcmoveslow55, label %bb_rcmovenext58
bb_rcmovenext58:
  %v511 = load i64, ptr %slot67, align 8
  %v512 = load i64, ptr %slot68, align 8
  %p513 = inttoptr i64 %v511 to ptr
  %p514 = inttoptr i64 %v512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p514, ptr %p513, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot67, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i64 0, ptr %p516, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved55
bb_rcmoveslow55:
  %v517 = load i64, ptr %slot23, align 8
  %v518 = load i64, ptr %slot68, align 8
  %v519 = load i64, ptr %slot67, align 8
  %v520 = load i64, ptr %slot69, align 8
  %cv521 = trunc i64 %v520 to i32
  %call522 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v517, i64 %v518, i64 %v519, i32 %cv521) nomerge, !dbg !114
  store i32 %call522, ptr %slot77, align 8
  %v523 = load i32, ptr %slot77, align 8
  %cv524 = zext i32 %v523 to i64
  %cond525 = icmp ne i64 %cv524, 0
  br i1 %cond525, label %bb_rcsuccess65, label %bb_rcfailure65
bb_rcfailure65:
  %v526 = load i64, ptr %slot23, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %call528 = call i32 @myl_rc_take_failure(ptr %p527) nomerge, !dbg !114
  store i32 %call528, ptr %slot78, align 8
  %v529 = load i64, ptr %slot1, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %v531 = load i32, ptr %slot78, align 8
  %call532 = call i32 @myl_qbe_rc_status(ptr %p530, i32 %v531) nomerge, !dbg !114
  store i32 %call532, ptr %slot79, align 8
  br label %bb_failure
bb_rcsuccess65:
  br label %bb_rcmoved55
bb_rcmoved55:
  %v533 = load i64, ptr %slot6, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i32 0, ptr %p534, align 4, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot9, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i32 2, ptr %p536, align 4, !alias.scope !3, !noalias !4
  %v537 = load i64, ptr %slot8, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i32 1, ptr %p538, align 4, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot13, align 8
  store i64 %v539, ptr %slot80, align 8
  %v540 = load i64, ptr %slot80, align 8
  %v541 = load i64, ptr %slot64, align 8
  %p542 = inttoptr i64 %v540 to ptr
  %p543 = inttoptr i64 %v541 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p543, ptr %p542, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot8, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i32 0, ptr %p545, align 4, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot60, align 8
  %v547 = load i64, ptr %slot16, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i64 %v546, ptr %p548, align 8, !alias.scope !3, !noalias !4
  %p549 = inttoptr i64 ptrtoint (ptr @myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p549, i64 17) "call-inline-cost"="0", !dbg !114
  %v550 = load i64, ptr %slot16, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot81, align 8
  %v553 = load i64, ptr %slot11, align 8
  store i64 %v553, ptr %slot82, align 8
  %v554 = load i64, ptr %slot81, align 8
  %v555 = load i64, ptr %slot82, align 8
  %p556 = inttoptr i64 %v554 to ptr
  %p557 = inttoptr i64 %v555 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p557, ptr %p556, i64 16, i1 false)
  %v558 = load i64, ptr %slot7, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 2, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot6, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i32 1, ptr %p561, align 4, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot82, align 8
  %v563 = load i64, ptr %slot16, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i64 %v562, ptr %p564, align 8, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot16, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i64, ptr %p566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld567, ptr %slot83, align 8
  %v568 = load i64, ptr %slot16, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot84, align 8
  %v571 = load i64, ptr %slot13, align 8
  store i64 %v571, ptr %slot85, align 8
  %v572 = load i64, ptr %slot24, align 8
  store i64 %v572, ptr %slot86, align 8
  %v573 = load i64, ptr %slot23, align 8
  %v574 = load i64, ptr %slot85, align 8
  %v575 = load i64, ptr %slot84, align 8
  %v576 = load i64, ptr %slot86, align 8
  %cv577 = trunc i64 %v576 to i32
  %call578 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v573, i64 %v574, i64 %v575, i32 %cv577) nomerge, !dbg !116
  store i32 %call578, ptr %slot87, align 8
  %v579 = load i32, ptr %slot87, align 8
  %cv580 = zext i32 %v579 to i64
  %cond581 = icmp ne i64 %cv580, 0
  br i1 %cond581, label %bb_rcsuccess82, label %bb_rcfailure82
bb_rcfailure82:
  %v582 = load i64, ptr %slot23, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %call584 = call i32 @myl_rc_take_failure(ptr %p583) nomerge, !dbg !116
  store i32 %call584, ptr %slot88, align 8
  %v585 = load i64, ptr %slot1, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %v587 = load i32, ptr %slot88, align 8
  %call588 = call i32 @myl_qbe_rc_status(ptr %p586, i32 %v587) nomerge, !dbg !116
  store i32 %call588, ptr %slot89, align 8
  br label %bb_failure
bb_rcsuccess82:
  %v589 = load i64, ptr %slot6, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i32 0, ptr %p590, align 4, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot9, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 2, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot8, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 1, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot13, align 8
  store i64 %v595, ptr %slot90, align 8
  %v596 = load i64, ptr %slot8, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 0, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot6, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i32, ptr %p599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld600, ptr %slot91, align 8
  %v601 = load i32, ptr %slot91, align 8
  %cv602 = zext i32 %v601 to i64
  %cond603 = icmp ne i64 %cv602, 0
  br i1 %cond603, label %bb_rcslotdrop92, label %bb_rcslotdone92
bb_rcslotdrop92:
  %v604 = load i64, ptr %slot6, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot11, align 8
  store i64 %v606, ptr %slot92, align 8
  %v607 = load i64, ptr %slot7, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i32, ptr %p608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld609, ptr %slot93, align 8
  %v610 = load i32, ptr %slot93, align 8
  %op611 = and i32 %v610, 28
  store i32 %op611, ptr %slot94, align 8
  %v612 = load i32, ptr %slot94, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcslotrole92, label %bb_rcslotowner92
bb_rcslotrole92:
  %v615 = load i64, ptr %slot23, align 8
  store i64 %v615, ptr %slot95, align 8
  %v616 = load i64, ptr %slot95, align 8
  %v617 = load i64, ptr %slot92, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v616, i64 %v617) nomerge, !dbg !116
  br label %bb_rcslotdone92
bb_rcslotowner92:
  %v618 = load i64, ptr %slot23, align 8
  store i64 %v618, ptr %slot96, align 8
  %v619 = load i64, ptr %slot96, align 8
  %v620 = load i64, ptr %slot92, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v619, i64 %v620) nomerge, !dbg !116
  br label %bb_rcslotdone92
bb_rcslotdone92:
  %v621 = load i64, ptr %slot90, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ret623 = load { i64, i64 }, ptr %p622, align 8
  ret { i64, i64 } %ret623
bb_i19:
  %v624 = load i64, ptr %slot15, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %ld626 = load i64, ptr %p625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld626, ptr %slot97, align 8
  %v627 = load i64, ptr %slot97, align 8
  %v628 = load i64, ptr %slot16, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot16, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot98, align 8
  %v633 = load i64, ptr %slot98, align 8
  %op634 = add i64 %v633, 0
  store i64 %op634, ptr %slot99, align 8
  %v635 = load i64, ptr %slot99, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8
  store i64 %ld637, ptr %slot100, align 8
  %v638 = load i64, ptr %slot100, align 8
  %v639 = load i64, ptr %slot16, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 %v638, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot17, align 8
  %p642 = inttoptr i64 %v641 to ptr
  store i64 0, ptr %p642, align 8, !alias.scope !3, !noalias !4
  %v643 = load i64, ptr %slot17, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %ld645 = load i64, ptr %p644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld645, ptr %slot101, align 8
  %v646 = load i64, ptr %slot16, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %ld648 = load i64, ptr %p647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld648, ptr %slot102, align 8
  %v649 = load i64, ptr %slot102, align 8
  %v650 = load i64, ptr %slot101, align 8
  %cmp651 = icmp slt i64 %v649, %v650
  %cv652 = zext i1 %cmp651 to i64
  store i64 %cv652, ptr %slot103, align 8
  %v653 = load i64, ptr %slot103, align 8
  %v654 = load i64, ptr %slot16, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 %v653, ptr %p655, align 8, !alias.scope !3, !noalias !4
  %v656 = load i64, ptr %slot16, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %ld658 = load i64, ptr %p657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld658, ptr %slot104, align 8
  %v659 = load i64, ptr %slot104, align 8
  %cond660 = icmp ne i64 %v659, 0
  br i1 %cond660, label %bb_next107, label %bb_i37
bb_next107:
  %v661 = load i64, ptr %slot14, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i64, ptr %p662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld663, ptr %slot105, align 8
  %v664 = load i64, ptr %slot105, align 8
  %v665 = load i64, ptr %slot16, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i64 %v664, ptr %p666, align 8, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot16, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot106, align 8
  %v670 = load i64, ptr %slot106, align 8
  %op671 = add i64 %v670, 0
  store i64 %op671, ptr %slot107, align 8
  %v672 = load i64, ptr %slot107, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8
  store i64 %ld674, ptr %slot108, align 8
  %v675 = load i64, ptr %slot108, align 8
  %v676 = load i64, ptr %slot16, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i64 %v675, ptr %p677, align 8, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot17, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i64 0, ptr %p679, align 8, !alias.scope !3, !noalias !4
  %v680 = load i64, ptr %slot18, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 9223372036854775807, ptr %p681, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i29:
  %v682 = load i64, ptr %slot18, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot109, align 8
  %v685 = load i64, ptr %slot17, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %ld687 = load i64, ptr %p686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld687, ptr %slot110, align 8
  %v688 = load i64, ptr %slot110, align 8
  %v689 = load i64, ptr %slot109, align 8
  %ovpair691 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v688, i64 %v689)
  %op690 = extractvalue { i64, i1 } %ovpair691, 0
  %ov692 = extractvalue { i64, i1 } %ovpair691, 1
  store i64 %op690, ptr %slot111, align 8
  %v693 = load i64, ptr %slot110, align 8
  %v694 = load i64, ptr %slot109, align 8
  %op695 = xor i64 %v693, %v694
  store i64 %op695, ptr %slot112, align 8
  %v696 = load i64, ptr %slot110, align 8
  %v697 = load i64, ptr %slot111, align 8
  %op698 = xor i64 %v696, %v697
  store i64 %op698, ptr %slot113, align 8
  %v699 = load i64, ptr %slot112, align 8
  %v700 = load i64, ptr %slot113, align 8
  %op701 = and i64 %v699, %v700
  store i64 %op701, ptr %slot114, align 8
  %cv702 = zext i1 %ov692 to i64
  store i64 %cv702, ptr %slot115, align 8
  %v703 = load i64, ptr %slot115, align 8
  %cond704 = icmp ne i64 %v703, 0
  br i1 %cond704, label %bb_overflow113, label %bb_checked113
bb_overflow113:
  %v705 = load i64, ptr %slot1, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %v707 = load i64, ptr %slot110, align 8
  %v708 = load i64, ptr %slot109, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p706, i64 1, i64 %v707, i64 %v708, i64 64) nomerge, !dbg !118
  unreachable
bb_checked113:
  %v709 = load i64, ptr %slot111, align 8
  %v710 = load i64, ptr %slot17, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot18, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 1, ptr %p713, align 8, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot18, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i64, ptr %p715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld716, ptr %slot116, align 8
  %v717 = load i64, ptr %slot17, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot117, align 8
  %v720 = load i64, ptr %slot117, align 8
  %v721 = load i64, ptr %slot116, align 8
  %ovpair723 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v720, i64 %v721)
  %op722 = extractvalue { i64, i1 } %ovpair723, 0
  %ov724 = extractvalue { i64, i1 } %ovpair723, 1
  store i64 %op722, ptr %slot118, align 8
  %cv725 = zext i1 %ov724 to i64
  store i64 %cv725, ptr %slot119, align 8
  %v726 = load i64, ptr %slot119, align 8
  %cond727 = icmp ne i64 %v726, 0
  br i1 %cond727, label %bb_overflow120, label %bb_checked120
bb_overflow120:
  %v728 = load i64, ptr %slot1, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %v730 = load i64, ptr %slot117, align 8
  %v731 = load i64, ptr %slot116, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p729, i64 1, i64 %v730, i64 %v731, i64 64) nomerge, !dbg !120
  unreachable
bb_checked120:
  %v732 = load i64, ptr %slot118, align 8
  %v733 = load i64, ptr %slot17, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot15, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot120, align 8
  %v738 = load i64, ptr %slot120, align 8
  %v739 = load i64, ptr %slot18, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i64 %v738, ptr %p740, align 8, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot18, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld743, ptr %slot121, align 8
  %v744 = load i64, ptr %slot121, align 8
  %op745 = add i64 %v744, 0
  store i64 %op745, ptr %slot122, align 8
  %v746 = load i64, ptr %slot122, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i64, ptr %p747, align 8, !alias.scope !4, !noalias !3
  store i64 %ld748, ptr %slot123, align 8
  %v749 = load i64, ptr %slot123, align 8
  %v750 = load i64, ptr %slot18, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 %v749, ptr %p751, align 8, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot18, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i64, ptr %p753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld754, ptr %slot124, align 8
  %v755 = load i64, ptr %slot17, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %ld757 = load i64, ptr %p756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld757, ptr %slot125, align 8
  %v758 = load i64, ptr %slot125, align 8
  %v759 = load i64, ptr %slot124, align 8
  %ovpair761 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v758, i64 %v759)
  %op760 = extractvalue { i64, i1 } %ovpair761, 0
  %ov762 = extractvalue { i64, i1 } %ovpair761, 1
  store i64 %op760, ptr %slot126, align 8
  %v763 = load i64, ptr %slot125, align 8
  %v764 = load i64, ptr %slot124, align 8
  %op765 = xor i64 %v763, %v764
  store i64 %op765, ptr %slot127, align 8
  %v766 = load i64, ptr %slot125, align 8
  %v767 = load i64, ptr %slot126, align 8
  %op768 = xor i64 %v766, %v767
  store i64 %op768, ptr %slot128, align 8
  %v769 = load i64, ptr %slot127, align 8
  %v770 = load i64, ptr %slot128, align 8
  %op771 = and i64 %v769, %v770
  store i64 %op771, ptr %slot129, align 8
  %cv772 = zext i1 %ov762 to i64
  store i64 %cv772, ptr %slot130, align 8
  %v773 = load i64, ptr %slot130, align 8
  %cond774 = icmp ne i64 %v773, 0
  br i1 %cond774, label %bb_overflow128, label %bb_checked128
bb_overflow128:
  %v775 = load i64, ptr %slot1, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %v777 = load i64, ptr %slot125, align 8
  %v778 = load i64, ptr %slot124, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p776, i64 1, i64 %v777, i64 %v778, i64 64) nomerge, !dbg !122
  unreachable
bb_checked128:
  %v779 = load i64, ptr %slot126, align 8
  %v780 = load i64, ptr %slot17, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i64 %v779, ptr %p781, align 8, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot17, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %ld784 = load i64, ptr %p783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld784, ptr %slot131, align 8
  %v785 = load i64, ptr %slot16, align 8
  %p786 = inttoptr i64 %v785 to ptr
  %ld787 = load i64, ptr %p786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld787, ptr %slot132, align 8
  %v788 = load i64, ptr %slot132, align 8
  %v789 = load i64, ptr %slot131, align 8
  %cmp790 = icmp slt i64 %v788, %v789
  %cv791 = zext i1 %cmp790 to i64
  store i64 %cv791, ptr %slot133, align 8
  %v792 = load i64, ptr %slot133, align 8
  %v793 = load i64, ptr %slot16, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 %v792, ptr %p794, align 8, !alias.scope !3, !noalias !4
  br label %bb_i38
bb_i37:
  %v795 = load i64, ptr %slot16, align 8
  %p796 = inttoptr i64 %v795 to ptr
  store i64 0, ptr %p796, align 8, !alias.scope !3, !noalias !4
  br label %bb_i38
bb_i38:
  %v797 = load i64, ptr %slot16, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %ld799 = load i64, ptr %p798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld799, ptr %slot134, align 8
  %v800 = load i64, ptr %slot134, align 8
  %cond801 = icmp ne i64 %v800, 0
  br i1 %cond801, label %bb_next137, label %bb_i42
bb_next137:
  %p802 = inttoptr i64 ptrtoint (ptr @myl_lit_96b96a195291d03f92cca564c4274dd7d042db7850382b1d70eb29994402efe8 to i64) to ptr
  %ld803 = load i64, ptr %p802, align 8, !alias.scope !4, !noalias !3
  store i64 %ld803, ptr %slot135, align 8
  %v804 = load i64, ptr %slot135, align 8
  %v805 = load i64, ptr %slot16, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i64 %v804, ptr %p806, align 8, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot16, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %ld809 = load i64, ptr %p808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld809, ptr %slot136, align 8
  %v810 = load i64, ptr %slot136, align 8
  %v811 = load i64, ptr %slot12, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i64 %v810, ptr %p812, align 8, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot12, align 8
  store i64 %v813, ptr %slot137, align 8
  %v814 = load i64, ptr %slot13, align 8
  store i64 %v814, ptr %slot138, align 8
  %v815 = load i64, ptr %slot137, align 8
  %v816 = load i64, ptr %slot138, align 8
  %p817 = inttoptr i64 %v815 to ptr
  %p818 = inttoptr i64 %v816 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p818, ptr %p817, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot9, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i32 2, ptr %p820, align 4, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot8, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i32 1, ptr %p822, align 4, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot11, align 8
  store i64 %v823, ptr %slot139, align 8
  %v824 = load i64, ptr %slot13, align 8
  store i64 %v824, ptr %slot140, align 8
  %v825 = load i64, ptr %slot140, align 8
  %v826 = load i64, ptr %slot139, align 8
  %p827 = inttoptr i64 %v825 to ptr
  %p828 = inttoptr i64 %v826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p828, ptr %p827, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot7, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 2, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot9, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %ld833 = load i32, ptr %p832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld833, ptr %slot141, align 8
  %v834 = load i32, ptr %slot141, align 8
  %v835 = load i64, ptr %slot7, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i32 %v834, ptr %p836, align 4, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot8, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot6, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 1, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot139, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i64, ptr %p842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld843, ptr %slot142, align 8
  %v844 = load i64, ptr %slot142, align 8
  %v845 = load i64, ptr %slot16, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 %v844, ptr %p846, align 8, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot20, align 8
  store i64 %v847, ptr %slot143, align 8
  %v848 = load i64, ptr %slot143, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i64 0, ptr %p849, align 8, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot143, align 8
  %p852 = inttoptr i64 %v850 to ptr
  %gep853 = getelementptr i8, ptr %p852, i64 8
  %op851 = ptrtoint ptr %gep853 to i64
  store i64 %op851, ptr %slot144, align 8
  %v854 = load i64, ptr %slot144, align 8
  %p855 = inttoptr i64 %v854 to ptr
  store i64 0, ptr %p855, align 8, !alias.scope !3, !noalias !4
  %v856 = load i64, ptr %slot143, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 1, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot10, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i32 1, ptr %p859, align 4, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot16, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i64, ptr %p861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld862, ptr %slot145, align 8
  %v863 = load i64, ptr %slot145, align 8
  %v864 = load i64, ptr %slot12, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i64 %v863, ptr %p865, align 8, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot12, align 8
  store i64 %v866, ptr %slot146, align 8
  %v867 = load i64, ptr %slot143, align 8
  %p869 = inttoptr i64 %v867 to ptr
  %gep870 = getelementptr i8, ptr %p869, i64 8
  %op868 = ptrtoint ptr %gep870 to i64
  store i64 %op868, ptr %slot147, align 8
  %v871 = load i64, ptr %slot24, align 8
  store i64 %v871, ptr %slot148, align 8
  %v872 = load i64, ptr %slot16, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %ld874 = load i64, ptr %p873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld874, ptr %slot149, align 8
  %v875 = load i64, ptr %slot149, align 8
  %v876 = load i64, ptr %slot12, align 8
  %p877 = inttoptr i64 %v876 to ptr
  store i64 %v875, ptr %p877, align 8, !alias.scope !3, !noalias !4
  %v878 = load i64, ptr %slot12, align 8
  store i64 %v878, ptr %slot150, align 8
  %v879 = load i64, ptr %slot13, align 8
  store i64 %v879, ptr %slot151, align 8
  %v880 = load i64, ptr %slot24, align 8
  store i64 %v880, ptr %slot152, align 8
  %v881 = load i64, ptr %slot150, align 8
  %p883 = inttoptr i64 %v881 to ptr
  %gep884 = getelementptr i8, ptr %p883, i64 0
  %op882 = ptrtoint ptr %gep884 to i64
  store i64 %op882, ptr %slot153, align 8
  %v885 = load i64, ptr %slot153, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i64, ptr %p886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld887, ptr %slot154, align 8
  %v888 = load i64, ptr %slot154, align 8
  %cmp889 = icmp ne i64 %v888, 0
  %cv890 = zext i1 %cmp889 to i32
  store i32 %cv890, ptr %slot155, align 8
  %v891 = load i32, ptr %slot155, align 8
  %cv892 = zext i32 %v891 to i64
  %cond893 = icmp ne i64 %cv892, 0
  br i1 %cond893, label %bb_rcmoveheader168, label %bb_rcmovenext168
bb_rcmoveheader168:
  %v894 = load i64, ptr %slot154, align 8
  %op895 = sub i64 %v894, 16
  store i64 %op895, ptr %slot156, align 8
  %v896 = load i64, ptr %slot154, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %rgep898 = getelementptr i8, ptr %p897, i64 -16
  %ld899 = load i64, ptr %rgep898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld899, ptr %slot157, align 8
  %v900 = load i64, ptr %slot157, align 8
  %op901 = and i64 %v900, 5764607523034234881
  store i64 %op901, ptr %slot158, align 8
  %v902 = load i64, ptr %slot158, align 8
  %cmp903 = icmp ne i64 %v902, 0
  %cv904 = zext i1 %cmp903 to i32
  store i32 %cv904, ptr %slot159, align 8
  %v905 = load i32, ptr %slot159, align 8
  %cv906 = zext i32 %v905 to i64
  %cond907 = icmp ne i64 %cv906, 0
  br i1 %cond907, label %bb_rcmoveslow165, label %bb_rcmovenext168
bb_rcmovenext168:
  %v908 = load i64, ptr %slot150, align 8
  %v909 = load i64, ptr %slot151, align 8
  %p910 = inttoptr i64 %v908 to ptr
  %p911 = inttoptr i64 %v909 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p911, ptr %p910, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot150, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i64 0, ptr %p913, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved165
bb_rcmoveslow165:
  %v914 = load i64, ptr %slot23, align 8
  %v915 = load i64, ptr %slot151, align 8
  %v916 = load i64, ptr %slot150, align 8
  %v917 = load i64, ptr %slot152, align 8
  %cv918 = trunc i64 %v917 to i32
  %call919 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v914, i64 %v915, i64 %v916, i32 %cv918) nomerge, !dbg !124
  store i32 %call919, ptr %slot160, align 8
  %v920 = load i32, ptr %slot160, align 8
  %cv921 = zext i32 %v920 to i64
  %cond922 = icmp ne i64 %cv921, 0
  br i1 %cond922, label %bb_rcsuccess175, label %bb_rcfailure175
bb_rcfailure175:
  %v923 = load i64, ptr %slot23, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %call925 = call i32 @myl_rc_take_failure(ptr %p924) nomerge, !dbg !124
  store i32 %call925, ptr %slot161, align 8
  %v926 = load i64, ptr %slot1, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %v928 = load i32, ptr %slot161, align 8
  %call929 = call i32 @myl_qbe_rc_status(ptr %p927, i32 %v928) nomerge, !dbg !124
  store i32 %call929, ptr %slot162, align 8
  br label %bb_failure
bb_rcsuccess175:
  br label %bb_rcmoved165
bb_rcmoved165:
  %v930 = load i64, ptr %slot6, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot9, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 2, ptr %p933, align 4, !alias.scope !3, !noalias !4
  %v934 = load i64, ptr %slot8, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i32 1, ptr %p935, align 4, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot13, align 8
  store i64 %v936, ptr %slot163, align 8
  %v937 = load i64, ptr %slot163, align 8
  %v938 = load i64, ptr %slot147, align 8
  %p939 = inttoptr i64 %v937 to ptr
  %p940 = inttoptr i64 %v938 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p940, ptr %p939, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v941 = load i64, ptr %slot8, align 8
  %p942 = inttoptr i64 %v941 to ptr
  store i32 0, ptr %p942, align 4, !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot143, align 8
  %v944 = load i64, ptr %slot16, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i64 %v943, ptr %p945, align 8, !alias.scope !3, !noalias !4
  %p946 = inttoptr i64 ptrtoint (ptr @myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p946, i64 40) "call-inline-cost"="0", !dbg !124
  %v947 = load i64, ptr %slot16, align 8
  %p948 = inttoptr i64 %v947 to ptr
  %ld949 = load i64, ptr %p948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld949, ptr %slot164, align 8
  %v950 = load i64, ptr %slot11, align 8
  store i64 %v950, ptr %slot165, align 8
  %v951 = load i64, ptr %slot164, align 8
  %v952 = load i64, ptr %slot165, align 8
  %p953 = inttoptr i64 %v951 to ptr
  %p954 = inttoptr i64 %v952 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p954, ptr %p953, i64 16, i1 false)
  %v955 = load i64, ptr %slot7, align 8
  %p956 = inttoptr i64 %v955 to ptr
  store i32 2, ptr %p956, align 4, !alias.scope !3, !noalias !4
  %v957 = load i64, ptr %slot6, align 8
  %p958 = inttoptr i64 %v957 to ptr
  store i32 1, ptr %p958, align 4, !alias.scope !3, !noalias !4
  %v959 = load i64, ptr %slot165, align 8
  %v960 = load i64, ptr %slot16, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i64 %v959, ptr %p961, align 8, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot16, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i64, ptr %p963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld964, ptr %slot166, align 8
  %v965 = load i64, ptr %slot16, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %ld967 = load i64, ptr %p966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld967, ptr %slot167, align 8
  %v968 = load i64, ptr %slot13, align 8
  store i64 %v968, ptr %slot168, align 8
  %v969 = load i64, ptr %slot24, align 8
  store i64 %v969, ptr %slot169, align 8
  %v970 = load i64, ptr %slot23, align 8
  %v971 = load i64, ptr %slot168, align 8
  %v972 = load i64, ptr %slot167, align 8
  %v973 = load i64, ptr %slot169, align 8
  %cv974 = trunc i64 %v973 to i32
  %call975 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v970, i64 %v971, i64 %v972, i32 %cv974) nomerge, !dbg !126
  store i32 %call975, ptr %slot170, align 8
  %v976 = load i32, ptr %slot170, align 8
  %cv977 = zext i32 %v976 to i64
  %cond978 = icmp ne i64 %cv977, 0
  br i1 %cond978, label %bb_rcsuccess192, label %bb_rcfailure192
bb_rcfailure192:
  %v979 = load i64, ptr %slot23, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %call981 = call i32 @myl_rc_take_failure(ptr %p980) nomerge, !dbg !126
  store i32 %call981, ptr %slot171, align 8
  %v982 = load i64, ptr %slot1, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %v984 = load i32, ptr %slot171, align 8
  %call985 = call i32 @myl_qbe_rc_status(ptr %p983, i32 %v984) nomerge, !dbg !126
  store i32 %call985, ptr %slot172, align 8
  br label %bb_failure
bb_rcsuccess192:
  %v986 = load i64, ptr %slot6, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i32 0, ptr %p987, align 4, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot9, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i32 2, ptr %p989, align 4, !alias.scope !3, !noalias !4
  %v990 = load i64, ptr %slot8, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i32 1, ptr %p991, align 4, !alias.scope !3, !noalias !4
  %v992 = load i64, ptr %slot13, align 8
  store i64 %v992, ptr %slot173, align 8
  %v993 = load i64, ptr %slot8, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i32 0, ptr %p994, align 4, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot6, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i32, ptr %p996, align 4, !alias.scope !3, !noalias !4
  store i32 %ld997, ptr %slot174, align 8
  %v998 = load i32, ptr %slot174, align 8
  %cv999 = zext i32 %v998 to i64
  %cond1000 = icmp ne i64 %cv999, 0
  br i1 %cond1000, label %bb_rcslotdrop202, label %bb_rcslotdone202
bb_rcslotdrop202:
  %v1001 = load i64, ptr %slot6, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i32 0, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  %v1003 = load i64, ptr %slot11, align 8
  store i64 %v1003, ptr %slot175, align 8
  %v1004 = load i64, ptr %slot7, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  %ld1006 = load i32, ptr %p1005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1006, ptr %slot176, align 8
  %v1007 = load i32, ptr %slot176, align 8
  %op1008 = and i32 %v1007, 28
  store i32 %op1008, ptr %slot177, align 8
  %v1009 = load i32, ptr %slot177, align 8
  %cv1010 = zext i32 %v1009 to i64
  %cond1011 = icmp ne i64 %cv1010, 0
  br i1 %cond1011, label %bb_rcslotrole202, label %bb_rcslotowner202
bb_rcslotrole202:
  %v1012 = load i64, ptr %slot23, align 8
  store i64 %v1012, ptr %slot178, align 8
  %v1013 = load i64, ptr %slot178, align 8
  %v1014 = load i64, ptr %slot175, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v1013, i64 %v1014) nomerge, !dbg !126
  br label %bb_rcslotdone202
bb_rcslotowner202:
  %v1015 = load i64, ptr %slot23, align 8
  store i64 %v1015, ptr %slot179, align 8
  %v1016 = load i64, ptr %slot179, align 8
  %v1017 = load i64, ptr %slot175, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v1016, i64 %v1017) nomerge, !dbg !126
  br label %bb_rcslotdone202
bb_rcslotdone202:
  %v1018 = load i64, ptr %slot173, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %ret1020 = load { i64, i64 }, ptr %p1019, align 8
  ret { i64, i64 } %ret1020
bb_i42:
  %v1021 = load i64, ptr %slot14, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i64, ptr %p1022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1023, ptr %slot180, align 8
  %v1024 = load i64, ptr %slot180, align 8
  %v1025 = load i64, ptr %slot16, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i64 %v1024, ptr %p1026, align 8, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot16, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  %ld1029 = load i64, ptr %p1028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1029, ptr %slot181, align 8
  %v1030 = load i64, ptr %slot181, align 8
  %op1031 = add i64 %v1030, 0
  store i64 %op1031, ptr %slot182, align 8
  %v1032 = load i64, ptr %slot182, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %ld1034 = load i64, ptr %p1033, align 8
  store i64 %ld1034, ptr %slot183, align 8
  %v1035 = load i64, ptr %slot183, align 8
  %v1036 = load i64, ptr %slot16, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i64 %v1035, ptr %p1037, align 8, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot15, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %ld1040 = load i64, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1040, ptr %slot184, align 8
  %v1041 = load i64, ptr %slot184, align 8
  %v1042 = load i64, ptr %slot17, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i64 %v1041, ptr %p1043, align 8, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot17, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  %ld1046 = load i64, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1046, ptr %slot185, align 8
  %v1047 = load i64, ptr %slot185, align 8
  %op1048 = add i64 %v1047, 0
  store i64 %op1048, ptr %slot186, align 8
  %v1049 = load i64, ptr %slot186, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %ld1051 = load i64, ptr %p1050, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1051, ptr %slot187, align 8
  %v1052 = load i64, ptr %slot187, align 8
  %v1053 = load i64, ptr %slot17, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 %v1052, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot17, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i64, ptr %p1056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1057, ptr %slot188, align 8
  %v1058 = load i64, ptr %slot16, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i64, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1060, ptr %slot189, align 8
  %v1061 = load i64, ptr %slot189, align 8
  %v1062 = load i64, ptr %slot188, align 8
  %ovpair1064 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1061, i64 %v1062)
  %op1063 = extractvalue { i64, i1 } %ovpair1064, 0
  %ov1065 = extractvalue { i64, i1 } %ovpair1064, 1
  store i64 %op1063, ptr %slot190, align 8
  %v1066 = load i64, ptr %slot189, align 8
  %v1067 = load i64, ptr %slot190, align 8
  %op1068 = xor i64 %v1066, %v1067
  store i64 %op1068, ptr %slot191, align 8
  %v1069 = load i64, ptr %slot188, align 8
  %v1070 = load i64, ptr %slot190, align 8
  %op1071 = xor i64 %v1069, %v1070
  store i64 %op1071, ptr %slot192, align 8
  %v1072 = load i64, ptr %slot191, align 8
  %v1073 = load i64, ptr %slot192, align 8
  %op1074 = and i64 %v1072, %v1073
  store i64 %op1074, ptr %slot193, align 8
  %cv1075 = zext i1 %ov1065 to i64
  store i64 %cv1075, ptr %slot194, align 8
  %v1076 = load i64, ptr %slot194, align 8
  %cond1077 = icmp ne i64 %v1076, 0
  br i1 %cond1077, label %bb_overflow219, label %bb_checked219
bb_overflow219:
  %v1078 = load i64, ptr %slot1, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %v1080 = load i64, ptr %slot189, align 8
  %v1081 = load i64, ptr %slot188, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1079, i64 0, i64 %v1080, i64 %v1081, i64 64) nomerge, !dbg !128
  unreachable
bb_checked219:
  %v1082 = load i64, ptr %slot190, align 8
  %v1083 = load i64, ptr %slot16, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i64 %v1082, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot21, align 8
  store i64 %v1085, ptr %slot195, align 8
  %v1086 = load i64, ptr %slot24, align 8
  store i64 %v1086, ptr %slot196, align 8
  %v1087 = load i64, ptr %slot16, align 8
  store i64 %v1087, ptr %slot197, align 8
  %v1088 = load i64, ptr %slot195, align 8
  %p1090 = inttoptr i64 %v1088 to ptr
  %gep1091 = getelementptr i8, ptr %p1090, i64 0
  %op1089 = ptrtoint ptr %gep1091 to i64
  store i64 %op1089, ptr %slot198, align 8
  %v1092 = load i64, ptr %slot197, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i64, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1094, ptr %slot199, align 8
  %v1095 = load i64, ptr %slot199, align 8
  %v1096 = load i64, ptr %slot198, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  store i64 %v1095, ptr %p1097, align 8, !alias.scope !3, !noalias !4
  %v1098 = load i64, ptr %slot195, align 8
  %v1099 = load i64, ptr %slot16, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  store i64 %v1098, ptr %p1100, align 8, !alias.scope !3, !noalias !4
  %v1101 = load i64, ptr %slot22, align 8
  store i64 %v1101, ptr %slot200, align 8
  %v1102 = load i64, ptr %slot200, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  store i64 0, ptr %p1103, align 8, !alias.scope !3, !noalias !4
  %v1104 = load i64, ptr %slot200, align 8
  %p1106 = inttoptr i64 %v1104 to ptr
  %gep1107 = getelementptr i8, ptr %p1106, i64 8
  %op1105 = ptrtoint ptr %gep1107 to i64
  store i64 %op1105, ptr %slot201, align 8
  %v1108 = load i64, ptr %slot201, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i64 0, ptr %p1109, align 8, !alias.scope !3, !noalias !4
  %v1110 = load i64, ptr %slot200, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 0, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot10, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i32 1, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot16, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  %ld1116 = load i64, ptr %p1115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1116, ptr %slot202, align 8
  %v1117 = load i64, ptr %slot200, align 8
  %p1119 = inttoptr i64 %v1117 to ptr
  %gep1120 = getelementptr i8, ptr %p1119, i64 8
  %op1118 = ptrtoint ptr %gep1120 to i64
  store i64 %op1118, ptr %slot203, align 8
  %v1121 = load i64, ptr %slot24, align 8
  store i64 %v1121, ptr %slot204, align 8
  %v1122 = load i64, ptr %slot202, align 8
  %v1123 = load i64, ptr %slot203, align 8
  %p1124 = inttoptr i64 %v1122 to ptr
  %p1125 = inttoptr i64 %v1123 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1125, ptr %p1124, i64 8, i1 false)
  %v1126 = load i64, ptr %slot200, align 8
  %v1127 = load i64, ptr %slot16, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i64 %v1126, ptr %p1128, align 8, !alias.scope !3, !noalias !4
  %v1129 = load i64, ptr %slot16, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %ld1131 = load i64, ptr %p1130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1131, ptr %slot205, align 8
  %v1132 = load i64, ptr %slot11, align 8
  store i64 %v1132, ptr %slot206, align 8
  %v1133 = load i64, ptr %slot205, align 8
  %v1134 = load i64, ptr %slot206, align 8
  %p1135 = inttoptr i64 %v1133 to ptr
  %p1136 = inttoptr i64 %v1134 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1136, ptr %p1135, i64 16, i1 false)
  %v1137 = load i64, ptr %slot7, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i32 2, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot6, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  store i32 1, ptr %p1140, align 4, !alias.scope !3, !noalias !4
  %v1141 = load i64, ptr %slot206, align 8
  %v1142 = load i64, ptr %slot16, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i64 %v1141, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  %v1144 = load i64, ptr %slot16, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %ld1146 = load i64, ptr %p1145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1146, ptr %slot207, align 8
  %v1147 = load i64, ptr %slot16, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  %ld1149 = load i64, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1149, ptr %slot208, align 8
  %v1150 = load i64, ptr %slot13, align 8
  store i64 %v1150, ptr %slot209, align 8
  %v1151 = load i64, ptr %slot24, align 8
  store i64 %v1151, ptr %slot210, align 8
  %v1152 = load i64, ptr %slot23, align 8
  %v1153 = load i64, ptr %slot209, align 8
  %v1154 = load i64, ptr %slot208, align 8
  %v1155 = load i64, ptr %slot210, align 8
  %cv1156 = trunc i64 %v1155 to i32
  %call1157 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v1152, i64 %v1153, i64 %v1154, i32 %cv1156) nomerge, !dbg !130
  store i32 %call1157, ptr %slot211, align 8
  %v1158 = load i32, ptr %slot211, align 8
  %cv1159 = zext i32 %v1158 to i64
  %cond1160 = icmp ne i64 %cv1159, 0
  br i1 %cond1160, label %bb_rcsuccess245, label %bb_rcfailure245
bb_rcfailure245:
  %v1161 = load i64, ptr %slot23, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %call1163 = call i32 @myl_rc_take_failure(ptr %p1162) nomerge, !dbg !130
  store i32 %call1163, ptr %slot212, align 8
  %v1164 = load i64, ptr %slot1, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %v1166 = load i32, ptr %slot212, align 8
  %call1167 = call i32 @myl_qbe_rc_status(ptr %p1165, i32 %v1166) nomerge, !dbg !130
  store i32 %call1167, ptr %slot213, align 8
  br label %bb_failure
bb_rcsuccess245:
  %v1168 = load i64, ptr %slot6, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i32 0, ptr %p1169, align 4, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot9, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  store i32 2, ptr %p1171, align 4, !alias.scope !3, !noalias !4
  %v1172 = load i64, ptr %slot8, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i32 1, ptr %p1173, align 4, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot13, align 8
  store i64 %v1174, ptr %slot214, align 8
  %v1175 = load i64, ptr %slot8, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i32 0, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot6, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i32, ptr %p1178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1179, ptr %slot215, align 8
  %v1180 = load i32, ptr %slot215, align 8
  %cv1181 = zext i32 %v1180 to i64
  %cond1182 = icmp ne i64 %cv1181, 0
  br i1 %cond1182, label %bb_rcslotdrop255, label %bb_rcslotdone255
bb_rcslotdrop255:
  %v1183 = load i64, ptr %slot6, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  store i32 0, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot11, align 8
  store i64 %v1185, ptr %slot216, align 8
  %v1186 = load i64, ptr %slot7, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i32, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1188, ptr %slot217, align 8
  %v1189 = load i32, ptr %slot217, align 8
  %op1190 = and i32 %v1189, 28
  store i32 %op1190, ptr %slot218, align 8
  %v1191 = load i32, ptr %slot218, align 8
  %cv1192 = zext i32 %v1191 to i64
  %cond1193 = icmp ne i64 %cv1192, 0
  br i1 %cond1193, label %bb_rcslotrole255, label %bb_rcslotowner255
bb_rcslotrole255:
  %v1194 = load i64, ptr %slot23, align 8
  store i64 %v1194, ptr %slot219, align 8
  %v1195 = load i64, ptr %slot219, align 8
  %v1196 = load i64, ptr %slot216, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v1195, i64 %v1196) nomerge, !dbg !130
  br label %bb_rcslotdone255
bb_rcslotowner255:
  %v1197 = load i64, ptr %slot23, align 8
  store i64 %v1197, ptr %slot220, align 8
  %v1198 = load i64, ptr %slot220, align 8
  %v1199 = load i64, ptr %slot216, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v1198, i64 %v1199) nomerge, !dbg !130
  br label %bb_rcslotdone255
bb_rcslotdone255:
  %v1200 = load i64, ptr %slot214, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %ret1202 = load { i64, i64 }, ptr %p1201, align 8
  ret { i64, i64 } %ret1202
bb_failure:
  %v1203 = load i64, ptr %slot5, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  call void @llvm.memset.p0.i64(ptr %p1204, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v1205 = load i64, ptr %slot5, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %ret1207 = load { i64, i64 }, ptr %p1206, align 8
  ret { i64, i64 } %ret1207
bb_entry_failure:
  %v1208 = load i64, ptr %slot5, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  call void @llvm.memset.p0.i64(ptr %p1209, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v1210 = load i64, ptr %slot5, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ret1212 = load { i64, i64 }, ptr %p1211, align 8
  ret { i64, i64 } %ret1212
}

@myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4_meta = external global i8, align 8
@myl_lit_96b96a195291d03f92cca564c4274dd7d042db7850382b1d70eb29994402efe8 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64, i64)
declare i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4", linkageName: "myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10043256374356166515, i64 0, !"myl_f_a0e143f206dc4e837db983eec3337f05b2c2a5497636a2b9ecf7677edcd49ed4"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!112 = !DILocation(line: 12, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!114 = !DILocation(line: 18, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!116 = !DILocation(line: 19, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!118 = !DILocation(line: 30, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!120 = !DILocation(line: 32, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!122 = !DILocation(line: 35, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!124 = !DILocation(line: 41, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!126 = !DILocation(line: 42, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!128 = !DILocation(line: 47, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!130 = !DILocation(line: 50, column: 0, scope: !131)
