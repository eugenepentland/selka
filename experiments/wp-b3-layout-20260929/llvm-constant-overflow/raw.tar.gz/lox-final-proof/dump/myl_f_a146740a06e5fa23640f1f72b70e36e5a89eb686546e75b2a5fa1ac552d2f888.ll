target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %callresult48 = alloca [16 x i8], align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v406 = load i64, ptr %slot1, align 8
  %op407 = add i64 %v406, 32
  store i64 %op407, ptr %slot6, align 8
  %mem408 = alloca i8, i64 8, align 8
  %ptr409 = ptrtoint ptr %mem408 to i64
  store i64 %ptr409, ptr %slot7, align 8
  %mem410 = alloca i8, i64 8, align 8
  %ptr411 = ptrtoint ptr %mem410 to i64
  store i64 %ptr411, ptr %slot8, align 8
  %mem412 = alloca i8, i64 8, align 8
  %ptr413 = ptrtoint ptr %mem412 to i64
  store i64 %ptr413, ptr %slot9, align 8
  %mem414 = alloca i8, i64 8, align 8
  %ptr415 = ptrtoint ptr %mem414 to i64
  store i64 %ptr415, ptr %slot10, align 8
  %mem416 = alloca i8, i64 8, align 8
  %ptr417 = ptrtoint ptr %mem416 to i64
  store i64 %ptr417, ptr %slot11, align 8
  %mem418 = alloca i8, i64 8, align 8
  %ptr419 = ptrtoint ptr %mem418 to i64
  store i64 %ptr419, ptr %slot12, align 8
  %mem420 = alloca i8, i64 8, align 8
  %ptr421 = ptrtoint ptr %mem420 to i64
  store i64 %ptr421, ptr %slot13, align 8
  %mem422 = alloca i8, i64 8, align 8
  %ptr423 = ptrtoint ptr %mem422 to i64
  store i64 %ptr423, ptr %slot14, align 8
  %mem424 = alloca i8, i64 8, align 8
  %ptr425 = ptrtoint ptr %mem424 to i64
  store i64 %ptr425, ptr %slot15, align 8
  %mem426 = alloca i8, i64 208, align 8
  %ptr427 = ptrtoint ptr %mem426 to i64
  store i64 %ptr427, ptr %slot16, align 8
  %mem428 = alloca i8, i64 208, align 8
  %ptr429 = ptrtoint ptr %mem428 to i64
  store i64 %ptr429, ptr %slot17, align 8
  %mem430 = alloca i8, i64 32, align 8
  %ptr431 = ptrtoint ptr %mem430 to i64
  store i64 %ptr431, ptr %slot18, align 8
  %v432 = load i64, ptr %slot18, align 8
  %p434 = inttoptr i64 %v432 to ptr
  %gep435 = getelementptr i8, ptr %p434, i64 24
  %op433 = ptrtoint ptr %gep435 to i64
  store i64 %op433, ptr %slot19, align 8
  %v436 = load i64, ptr %slot19, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i64 0, ptr %p437, align 8, !alias.scope !3, !noalias !4
  %mem438 = alloca i8, i64 8, align 8
  %ptr439 = ptrtoint ptr %mem438 to i64
  store i64 %ptr439, ptr %slot20, align 8
  %mem440 = alloca i8, i64 8, align 8
  %ptr441 = ptrtoint ptr %mem440 to i64
  store i64 %ptr441, ptr %slot21, align 8
  %mem442 = alloca i8, i64 8, align 8
  %ptr443 = ptrtoint ptr %mem442 to i64
  store i64 %ptr443, ptr %slot22, align 8
  %mem444 = alloca i8, i64 8, align 8
  %ptr445 = ptrtoint ptr %mem444 to i64
  store i64 %ptr445, ptr %slot23, align 8
  %mem446 = alloca i8, i64 8, align 8
  %ptr447 = ptrtoint ptr %mem446 to i64
  store i64 %ptr447, ptr %slot24, align 8
  %mem448 = alloca i8, i64 16, align 8
  %ptr449 = ptrtoint ptr %mem448 to i64
  store i64 %ptr449, ptr %slot25, align 8
  %mem450 = alloca i8, i64 8, align 8
  %ptr451 = ptrtoint ptr %mem450 to i64
  store i64 %ptr451, ptr %slot26, align 8
  %mem452 = alloca i8, i64 16, align 8
  %ptr453 = ptrtoint ptr %mem452 to i64
  store i64 %ptr453, ptr %slot27, align 8
  %mem454 = alloca i8, i64 8, align 8
  %ptr455 = ptrtoint ptr %mem454 to i64
  store i64 %ptr455, ptr %slot28, align 8
  %mem456 = alloca i8, i64 8, align 8
  %ptr457 = ptrtoint ptr %mem456 to i64
  store i64 %ptr457, ptr %slot29, align 8
  %mem458 = alloca i8, i64 56, align 8
  %ptr459 = ptrtoint ptr %mem458 to i64
  store i64 %ptr459, ptr %slot30, align 8
  %mem460 = alloca i8, i64 8, align 8
  %ptr461 = ptrtoint ptr %mem460 to i64
  store i64 %ptr461, ptr %slot31, align 8
  %mem462 = alloca i8, i64 8, align 8
  %ptr463 = ptrtoint ptr %mem462 to i64
  store i64 %ptr463, ptr %slot32, align 8
  %mem464 = alloca i8, i64 8, align 8
  %ptr465 = ptrtoint ptr %mem464 to i64
  store i64 %ptr465, ptr %slot33, align 8
  %mem466 = alloca i8, i64 16, align 8
  %ptr467 = ptrtoint ptr %mem466 to i64
  store i64 %ptr467, ptr %slot34, align 8
  %mem468 = alloca i8, i64 56, align 8
  %ptr469 = ptrtoint ptr %mem468 to i64
  store i64 %ptr469, ptr %slot35, align 8
  %mem470 = alloca i8, i64 56, align 8
  %ptr471 = ptrtoint ptr %mem470 to i64
  store i64 %ptr471, ptr %slot36, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem472 = alloca i8, i64 8, align 8
  %ptr473 = ptrtoint ptr %mem472 to i64
  store i64 %ptr473, ptr %slot37, align 8
  %v474 = load i64, ptr %slot1, align 8
  %op475 = add i64 %v474, 64
  store i64 %op475, ptr %slot38, align 8
  %v476 = load i64, ptr %slot38, align 8
  %p477 = inttoptr i64 %v476 to ptr
  %ld478 = load i64, ptr %p477, align 8, !alias.scope !4, !noalias !3
  store i64 %ld478, ptr %slot39, align 8
  %stack479 = call ptr @llvm.stacksave()
  %stackaddr480 = ptrtoint ptr %stack479 to i64
  %v481 = load i64, ptr %slot39, align 8
  %cmp482 = icmp ult i64 %stackaddr480, %v481
  %cv483 = zext i1 %cmp482 to i64
  store i64 %cv483, ptr %slot40, align 8
  %v484 = load i64, ptr %slot40, align 8
  %cond485 = icmp ne i64 %v484, 0
  br i1 %cond485, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v486 = load i64, ptr %slot1, align 8
  %p487 = inttoptr i64 %v486 to ptr
  call void @myl_qbe_fail_frame(ptr %p487) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v488 = load i64, ptr %slot26, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i64 0, ptr %p489, align 8, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot29, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 0, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot2, align 8
  %v493 = load i64, ptr %slot21, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i64 %v492, ptr %p494, align 8, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot3, align 8
  %v496 = load i64, ptr %slot22, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 %v495, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot4, align 8
  %v499 = load i64, ptr %slot23, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i64 %v498, ptr %p500, align 8, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot5, align 8
  %v502 = load i64, ptr %slot24, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot1, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %call506 = call ptr @myl_qbe_heap(ptr %p505) nomerge, !dbg !112
  %calladdr507 = ptrtoint ptr %call506 to i64
  store i64 %calladdr507, ptr %slot41, align 8
  %v508 = load i64, ptr %slot1, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %call510 = call i64 @myl_qbe_region_mark(ptr %p509) nomerge, !dbg !112
  store i64 %call510, ptr %slot42, align 8
  %v511 = load i64, ptr %slot7, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i32 0, ptr %p512, align 4, !alias.scope !3, !noalias !4
  %v513 = load i64, ptr %slot8, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i32 0, ptr %p514, align 4, !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot9, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i32 0, ptr %p516, align 4, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot10, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i32 0, ptr %p518, align 4, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot11, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i32 0, ptr %p520, align 4, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 0, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot13, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot14, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 0, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot15, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 0, ptr %p528, align 4, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot8, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i32 2, ptr %p530, align 4, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot10, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i32 2, ptr %p532, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v533 = load i64, ptr %slot21, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i64, ptr %p534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot43, align 8
  %v536 = load i64, ptr %slot43, align 8
  %v537 = load i64, ptr %slot32, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i64 %v536, ptr %p538, align 8, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot22, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %ld541 = load i64, ptr %p540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld541, ptr %slot44, align 8
  %v542 = load i64, ptr %slot44, align 8
  %v543 = load i64, ptr %slot33, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i64 %v542, ptr %p544, align 8, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot32, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot45, align 8
  %v548 = load i64, ptr %slot33, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i64, ptr %p549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld550, ptr %slot46, align 8
  %v551 = load i64, ptr %slot1, align 8
  %v552 = load i64, ptr %slot45, align 8
  %v553 = load i64, ptr %slot46, align 8
  %call554 = call { i64, i64 } @myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0(i64 %v551, i64 %v552, i64 %v553) nomerge, !dbg !114
  store { i64, i64 } %call554, ptr %callresult48, align 8
  %addr555 = ptrtoint ptr %callresult48 to i64
  store i64 %addr555, ptr %slot47, align 8
  %v556 = load i64, ptr %slot47, align 8
  %v557 = load i64, ptr %slot32, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i64 %v556, ptr %p558, align 8, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot32, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %ld561 = load i64, ptr %p560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld561, ptr %slot49, align 8
  %v562 = load i64, ptr %slot17, align 8
  store i64 %v562, ptr %slot50, align 8
  %v563 = load i64, ptr %slot49, align 8
  %v564 = load i64, ptr %slot50, align 8
  %p565 = inttoptr i64 %v563 to ptr
  %p566 = inttoptr i64 %v564 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p566, ptr %p565, i64 16, i1 false)
  %v567 = load i64, ptr %slot14, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 2, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot13, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 1, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot11, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i32, ptr %p572, align 4, !alias.scope !3, !noalias !4
  store i32 %ld573, ptr %slot51, align 8
  %v574 = load i32, ptr %slot51, align 8
  %cv575 = zext i32 %v574 to i64
  %cond576 = icmp ne i64 %cv575, 0
  br i1 %cond576, label %bb_rcslotdrop23, label %bb_rcslotdone23
bb_rcslotdrop23:
  %v577 = load i64, ptr %slot11, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i32 0, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot16, align 8
  store i64 %v579, ptr %slot52, align 8
  %v580 = load i64, ptr %slot12, align 8
  %p581 = inttoptr i64 %v580 to ptr
  %ld582 = load i32, ptr %p581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld582, ptr %slot53, align 8
  %v583 = load i32, ptr %slot53, align 8
  %op584 = and i32 %v583, 28
  store i32 %op584, ptr %slot54, align 8
  %v585 = load i32, ptr %slot54, align 8
  %cv586 = zext i32 %v585 to i64
  %cond587 = icmp ne i64 %cv586, 0
  br i1 %cond587, label %bb_rcslotrole23, label %bb_rcslotowner23
bb_rcslotrole23:
  %v588 = load i64, ptr %slot41, align 8
  store i64 %v588, ptr %slot55, align 8
  %v589 = load i64, ptr %slot55, align 8
  %v590 = load i64, ptr %slot52, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v589, i64 %v590) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotowner23:
  %v591 = load i64, ptr %slot41, align 8
  store i64 %v591, ptr %slot56, align 8
  %v592 = load i64, ptr %slot56, align 8
  %v593 = load i64, ptr %slot52, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v592, i64 %v593) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotdone23:
  %v594 = load i64, ptr %slot16, align 8
  store i64 %v594, ptr %slot57, align 8
  %v595 = load i64, ptr %slot17, align 8
  store i64 %v595, ptr %slot58, align 8
  %v596 = load i64, ptr %slot58, align 8
  %v597 = load i64, ptr %slot57, align 8
  %p598 = inttoptr i64 %v596 to ptr
  %p599 = inttoptr i64 %v597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p599, ptr %p598, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot12, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i32 2, ptr %p601, align 4, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot14, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i32, ptr %p603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld604, ptr %slot59, align 8
  %v605 = load i32, ptr %slot59, align 8
  %v606 = load i64, ptr %slot12, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i32 %v605, ptr %p607, align 4, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot13, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 0, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot11, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i32 1, ptr %p611, align 4, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot57, align 8
  %v613 = load i64, ptr %slot32, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i64 %v612, ptr %p614, align 8, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot32, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %ld617 = load i64, ptr %p616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld617, ptr %slot60, align 8
  %v618 = load i64, ptr %slot17, align 8
  store i64 %v618, ptr %slot61, align 8
  %v619 = load i64, ptr %slot42, align 8
  store i64 %v619, ptr %slot62, align 8
  %v620 = load i64, ptr %slot60, align 8
  %op621 = add i64 %v620, 8
  store i64 %op621, ptr %slot63, align 8
  %v622 = load i64, ptr %slot63, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i64, ptr %p623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld624, ptr %slot64, align 8
  %v625 = load i64, ptr %slot64, align 8
  %cmp626 = icmp ne i64 %v625, 0
  %cv627 = zext i1 %cmp626 to i32
  store i32 %cv627, ptr %slot65, align 8
  %v628 = load i32, ptr %slot65, align 8
  %cv629 = zext i32 %v628 to i64
  %cond630 = icmp ne i64 %cv629, 0
  br i1 %cond630, label %bb_rcmoveheader44, label %bb_rcmovenext44
bb_rcmoveheader44:
  %v631 = load i64, ptr %slot64, align 8
  %op632 = sub i64 %v631, 16
  store i64 %op632, ptr %slot66, align 8
  %v633 = load i64, ptr %slot64, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %rgep635 = getelementptr i8, ptr %p634, i64 -16
  %ld636 = load i64, ptr %rgep635, align 8, !alias.scope !9, !noalias !10
  store i64 %ld636, ptr %slot67, align 8
  %v637 = load i64, ptr %slot67, align 8
  %op638 = and i64 %v637, 5764607523034234881
  store i64 %op638, ptr %slot68, align 8
  %v639 = load i64, ptr %slot68, align 8
  %cmp640 = icmp ne i64 %v639, 0
  %cv641 = zext i1 %cmp640 to i32
  store i32 %cv641, ptr %slot69, align 8
  %v642 = load i32, ptr %slot69, align 8
  %cv643 = zext i32 %v642 to i64
  %cond644 = icmp ne i64 %cv643, 0
  br i1 %cond644, label %bb_rcmoveslow41, label %bb_rcmovenext44
bb_rcmovenext44:
  %v645 = load i64, ptr %slot60, align 8
  %v646 = load i64, ptr %slot61, align 8
  %p647 = inttoptr i64 %v645 to ptr
  %p648 = inttoptr i64 %v646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p648, ptr %p647, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot60, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 0, ptr %p650, align 8, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot60, align 8
  %op652 = add i64 %v651, 8
  store i64 %op652, ptr %slot70, align 8
  %v653 = load i64, ptr %slot70, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i64 0, ptr %p654, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved41
bb_rcmoveslow41:
  %v655 = load i64, ptr %slot41, align 8
  %v656 = load i64, ptr %slot61, align 8
  %v657 = load i64, ptr %slot60, align 8
  %v658 = load i64, ptr %slot62, align 8
  %cv659 = trunc i64 %v658 to i32
  %call660 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v655, i64 %v656, i64 %v657, i32 %cv659) nomerge, !dbg !116
  store i32 %call660, ptr %slot71, align 8
  %v661 = load i32, ptr %slot71, align 8
  %cv662 = zext i32 %v661 to i64
  %cond663 = icmp ne i64 %cv662, 0
  br i1 %cond663, label %bb_rcsuccess52, label %bb_rcfailure52
bb_rcfailure52:
  %v664 = load i64, ptr %slot41, align 8
  %p665 = inttoptr i64 %v664 to ptr
  %call666 = call i32 @myl_rc_take_failure(ptr %p665) nomerge, !dbg !116
  store i32 %call666, ptr %slot72, align 8
  %v667 = load i64, ptr %slot1, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %v669 = load i32, ptr %slot72, align 8
  %call670 = call i32 @myl_qbe_rc_status(ptr %p668, i32 %v669) nomerge, !dbg !116
  store i32 %call670, ptr %slot73, align 8
  br label %bb_failure
bb_rcsuccess52:
  br label %bb_rcmoved41
bb_rcmoved41:
  %v671 = load i64, ptr %slot11, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 0, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot14, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i32 2, ptr %p674, align 4, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot13, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i32 1, ptr %p676, align 4, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot7, align 8
  %p678 = inttoptr i64 %v677 to ptr
  %ld679 = load i32, ptr %p678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld679, ptr %slot74, align 8
  %v680 = load i32, ptr %slot74, align 8
  %cv681 = zext i32 %v680 to i64
  %cond682 = icmp ne i64 %cv681, 0
  br i1 %cond682, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v683 = load i64, ptr %slot7, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 0, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot25, align 8
  store i64 %v685, ptr %slot75, align 8
  %v686 = load i64, ptr %slot8, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i32, ptr %p687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld688, ptr %slot76, align 8
  %v689 = load i32, ptr %slot76, align 8
  %op690 = and i32 %v689, 28
  store i32 %op690, ptr %slot77, align 8
  %v691 = load i32, ptr %slot77, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v694 = load i64, ptr %slot41, align 8
  store i64 %v694, ptr %slot78, align 8
  %v695 = load i64, ptr %slot78, align 8
  %v696 = load i64, ptr %slot75, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v695, i64 %v696) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v697 = load i64, ptr %slot75, align 8
  %p699 = inttoptr i64 %v697 to ptr
  %gep700 = getelementptr i8, ptr %p699, i64 8
  %op698 = ptrtoint ptr %gep700 to i64
  store i64 %op698, ptr %slot79, align 8
  %v701 = load i64, ptr %slot41, align 8
  store i64 %v701, ptr %slot80, align 8
  %v702 = load i64, ptr %slot79, align 8
  %p703 = inttoptr i64 %v702 to ptr
  %ld704 = load i64, ptr %p703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld704, ptr %slot81, align 8
  %v705 = load i64, ptr %slot81, align 8
  %cmp706 = icmp ne i64 %v705, 0
  %cv707 = zext i1 %cmp706 to i32
  store i32 %cv707, ptr %slot82, align 8
  %v708 = load i32, ptr %slot82, align 8
  %cv709 = zext i32 %v708 to i64
  %cond710 = icmp ne i64 %cv709, 0
  br i1 %cond710, label %bb_rcgnn79, label %bb_rcgdone79
bb_rcgnn79:
  %v711 = load i64, ptr %slot81, align 8
  %op712 = sub i64 %v711, 16
  store i64 %op712, ptr %slot83, align 8
  %v713 = load i64, ptr %slot81, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %rgep715 = getelementptr i8, ptr %p714, i64 -16
  %ld716 = load i64, ptr %rgep715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld716, ptr %slot84, align 8
  %v717 = load i64, ptr %slot84, align 8
  %op718 = and i64 %v717, 4611686018427387906
  store i64 %op718, ptr %slot85, align 8
  %v719 = load i64, ptr %slot85, align 8
  %cmp720 = icmp ne i64 %v719, 0
  %cv721 = zext i1 %cmp720 to i32
  store i32 %cv721, ptr %slot86, align 8
  %v722 = load i32, ptr %slot86, align 8
  %cv723 = zext i32 %v722 to i64
  %cond724 = icmp ne i64 %cv723, 0
  br i1 %cond724, label %bb_rcgclear79, label %bb_rcgcounted79
bb_rcgcounted79:
  %v725 = load i64, ptr %slot81, align 8
  %op726 = sub i64 %v725, 32
  store i64 %op726, ptr %slot87, align 8
  %v727 = load i64, ptr %slot81, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %rgep729 = getelementptr i8, ptr %p728, i64 -32
  %ld730 = load i64, ptr %rgep729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld730, ptr %slot88, align 8
  %v731 = load i64, ptr %slot88, align 8
  %op732 = sub i64 %v731, 1
  store i64 %op732, ptr %slot89, align 8
  %v733 = load i64, ptr %slot89, align 8
  %cmp734 = icmp eq i64 %v733, 0
  %cv735 = zext i1 %cmp734 to i32
  store i32 %cv735, ptr %slot90, align 8
  %v736 = load i32, ptr %slot90, align 8
  %cv737 = zext i32 %v736 to i64
  %cond738 = icmp ne i64 %cv737, 0
  br i1 %cond738, label %bb_rcglast79, label %bb_rcgdec79
bb_rcglast79:
  %v739 = load i64, ptr %slot81, align 8
  %op740 = sub i64 %v739, 24
  store i64 %op740, ptr %slot91, align 8
  %v741 = load i64, ptr %slot81, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %rgep743 = getelementptr i8, ptr %p742, i64 -24
  %ld744 = load i64, ptr %rgep743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld744, ptr %slot92, align 8
  %v745 = load i64, ptr %slot92, align 8
  %cmp746 = icmp ne i64 %v745, 0
  %cv747 = zext i1 %cmp746 to i32
  store i32 %cv747, ptr %slot93, align 8
  %v748 = load i32, ptr %slot93, align 8
  %cv749 = zext i32 %v748 to i64
  %cond750 = icmp ne i64 %cv749, 0
  br i1 %cond750, label %bb_rcgdec79, label %bb_rcgslow79
bb_rcgslow79:
  %v751 = load i64, ptr %slot80, align 8
  %v752 = load i64, ptr %slot79, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v751, i64 %v752) nomerge, !dbg !116
  br label %bb_rcgdone79
bb_rcgdec79:
  %v753 = load i64, ptr %slot89, align 8
  %v754 = load i64, ptr %slot81, align 8
  %p755 = inttoptr i64 %v754 to ptr
  %rgep756 = getelementptr i8, ptr %p755, i64 -32
  store i64 %v753, ptr %rgep756, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear79
bb_rcgclear79:
  %v757 = load i64, ptr %slot79, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i64 0, ptr %p758, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone79
bb_rcgdone79:
  %v759 = load i64, ptr %slot75, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i64 0, ptr %p760, align 8, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot75, align 8
  %p763 = inttoptr i64 %v761 to ptr
  %gep764 = getelementptr i8, ptr %p763, i64 8
  %op762 = ptrtoint ptr %gep764 to i64
  store i64 %op762, ptr %slot94, align 8
  %v765 = load i64, ptr %slot94, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i64 0, ptr %p766, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone61
bb_rcslotdone61:
  %v767 = load i64, ptr %slot25, align 8
  store i64 %v767, ptr %slot95, align 8
  %v768 = load i64, ptr %slot17, align 8
  store i64 %v768, ptr %slot96, align 8
  %v769 = load i64, ptr %slot96, align 8
  %v770 = load i64, ptr %slot95, align 8
  %p771 = inttoptr i64 %v769 to ptr
  %p772 = inttoptr i64 %v770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p772, ptr %p771, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot13, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 0, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot8, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 2, ptr %p776, align 4, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot14, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot97, align 8
  %v780 = load i32, ptr %slot97, align 8
  %v781 = load i64, ptr %slot8, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i32 %v780, ptr %p782, align 4, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot7, align 8
  %p784 = inttoptr i64 %v783 to ptr
  store i32 1, ptr %p784, align 4, !alias.scope !3, !noalias !4
  %v785 = load i64, ptr %slot24, align 8
  %p786 = inttoptr i64 %v785 to ptr
  %ld787 = load i64, ptr %p786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld787, ptr %slot98, align 8
  %v788 = load i64, ptr %slot98, align 8
  %v789 = load i64, ptr %slot32, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i64 %v788, ptr %p790, align 8, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot32, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %ld793 = load i64, ptr %p792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld793, ptr %slot99, align 8
  %v794 = load i64, ptr %slot99, align 8
  %v795 = load i64, ptr %slot27, align 8
  %p796 = inttoptr i64 %v794 to ptr
  %p797 = inttoptr i64 %v795 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p797, ptr %p796, i64 16, i1 false), !alias.scope !10000000
  %v798 = load i64, ptr %slot25, align 8
  %v799 = load i64, ptr %slot32, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i64 %v798, ptr %p800, align 8, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot32, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %ld803 = load i64, ptr %p802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld803, ptr %slot100, align 8
  %v804 = load i64, ptr %slot100, align 8
  %op805 = add i64 %v804, 8
  store i64 %op805, ptr %slot101, align 8
  %v806 = load i64, ptr %slot101, align 8
  %p807 = inttoptr i64 %v806 to ptr
  %ld808 = load i64, ptr %p807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld808, ptr %slot102, align 8
  %v809 = load i64, ptr %slot102, align 8
  %v810 = load i64, ptr %slot32, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 %v809, ptr %p811, align 8, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot11, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i32, ptr %p813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld814, ptr %slot103, align 8
  %v815 = load i32, ptr %slot103, align 8
  %cv816 = zext i32 %v815 to i64
  %cond817 = icmp ne i64 %cv816, 0
  br i1 %cond817, label %bb_rcslotdrop98, label %bb_rcslotdone98
bb_rcslotdrop98:
  %v818 = load i64, ptr %slot11, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i32 0, ptr %p819, align 4, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot16, align 8
  store i64 %v820, ptr %slot104, align 8
  %v821 = load i64, ptr %slot12, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i32, ptr %p822, align 4, !alias.scope !3, !noalias !4
  store i32 %ld823, ptr %slot105, align 8
  %v824 = load i32, ptr %slot105, align 8
  %op825 = and i32 %v824, 28
  store i32 %op825, ptr %slot106, align 8
  %v826 = load i32, ptr %slot106, align 8
  %cv827 = zext i32 %v826 to i64
  %cond828 = icmp ne i64 %cv827, 0
  br i1 %cond828, label %bb_rcslotrole98, label %bb_rcslotowner98
bb_rcslotrole98:
  %v829 = load i64, ptr %slot41, align 8
  store i64 %v829, ptr %slot107, align 8
  %v830 = load i64, ptr %slot107, align 8
  %v831 = load i64, ptr %slot104, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v830, i64 %v831) nomerge, !dbg !118
  br label %bb_rcslotdone98
bb_rcslotowner98:
  %v832 = load i64, ptr %slot41, align 8
  store i64 %v832, ptr %slot108, align 8
  %v833 = load i64, ptr %slot108, align 8
  %v834 = load i64, ptr %slot104, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v833, i64 %v834) nomerge, !dbg !118
  br label %bb_rcslotdone98
bb_rcslotdone98:
  %v835 = load i64, ptr %slot32, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i64, ptr %p836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld837, ptr %slot109, align 8
  %v838 = load i64, ptr %slot25, align 8
  store i64 %v838, ptr %slot110, align 8
  %v839 = load i64, ptr %slot11, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i32, ptr %p840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld841, ptr %slot111, align 8
  %v842 = load i32, ptr %slot111, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcslotdrop110, label %bb_rcslotdone110
bb_rcslotdrop110:
  %v845 = load i64, ptr %slot11, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot16, align 8
  store i64 %v847, ptr %slot112, align 8
  %v848 = load i64, ptr %slot12, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %ld850 = load i32, ptr %p849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld850, ptr %slot113, align 8
  %v851 = load i32, ptr %slot113, align 8
  %op852 = and i32 %v851, 28
  store i32 %op852, ptr %slot114, align 8
  %v853 = load i32, ptr %slot114, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotrole110, label %bb_rcslotowner110
bb_rcslotrole110:
  %v856 = load i64, ptr %slot41, align 8
  store i64 %v856, ptr %slot115, align 8
  %v857 = load i64, ptr %slot112, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i64, ptr %p858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld859, ptr %slot116, align 8
  %v860 = load i64, ptr %slot116, align 8
  %cmp861 = icmp ne i64 %v860, 0
  %cv862 = zext i1 %cmp861 to i32
  store i32 %cv862, ptr %slot117, align 8
  %v863 = load i32, ptr %slot117, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcgnn126, label %bb_rcgdone126
bb_rcgnn126:
  %v866 = load i64, ptr %slot116, align 8
  %op867 = sub i64 %v866, 16
  store i64 %op867, ptr %slot118, align 8
  %v868 = load i64, ptr %slot116, align 8
  %p869 = inttoptr i64 %v868 to ptr
  %rgep870 = getelementptr i8, ptr %p869, i64 -16
  %ld871 = load i64, ptr %rgep870, align 8, !alias.scope !9, !noalias !10
  store i64 %ld871, ptr %slot119, align 8
  %v872 = load i64, ptr %slot119, align 8
  %op873 = and i64 %v872, 4611686018427387906
  store i64 %op873, ptr %slot120, align 8
  %v874 = load i64, ptr %slot120, align 8
  %cmp875 = icmp ne i64 %v874, 0
  %cv876 = zext i1 %cmp875 to i32
  store i32 %cv876, ptr %slot121, align 8
  %v877 = load i32, ptr %slot121, align 8
  %cv878 = zext i32 %v877 to i64
  %cond879 = icmp ne i64 %cv878, 0
  br i1 %cond879, label %bb_rcgclear126, label %bb_rcgcounted126
bb_rcgcounted126:
  %v880 = load i64, ptr %slot116, align 8
  %op881 = sub i64 %v880, 24
  store i64 %op881, ptr %slot122, align 8
  %v882 = load i64, ptr %slot116, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %rgep884 = getelementptr i8, ptr %p883, i64 -24
  %ld885 = load i64, ptr %rgep884, align 8, !alias.scope !9, !noalias !10
  store i64 %ld885, ptr %slot123, align 8
  %v886 = load i64, ptr %slot123, align 8
  %op887 = sub i64 %v886, 1
  store i64 %op887, ptr %slot124, align 8
  %v888 = load i64, ptr %slot124, align 8
  %cmp889 = icmp eq i64 %v888, 0
  %cv890 = zext i1 %cmp889 to i32
  store i32 %cv890, ptr %slot125, align 8
  %v891 = load i32, ptr %slot125, align 8
  %cv892 = zext i32 %v891 to i64
  %cond893 = icmp ne i64 %cv892, 0
  br i1 %cond893, label %bb_rcglast126, label %bb_rcgdec126
bb_rcglast126:
  %v894 = load i64, ptr %slot116, align 8
  %op895 = sub i64 %v894, 32
  store i64 %op895, ptr %slot126, align 8
  %v896 = load i64, ptr %slot116, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %rgep898 = getelementptr i8, ptr %p897, i64 -32
  %ld899 = load i64, ptr %rgep898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld899, ptr %slot127, align 8
  %v900 = load i64, ptr %slot127, align 8
  %cmp901 = icmp ne i64 %v900, 0
  %cv902 = zext i1 %cmp901 to i32
  store i32 %cv902, ptr %slot128, align 8
  %v903 = load i32, ptr %slot128, align 8
  %cv904 = zext i32 %v903 to i64
  %cond905 = icmp ne i64 %cv904, 0
  br i1 %cond905, label %bb_rcgdec126, label %bb_rcgslow126
bb_rcgslow126:
  %v906 = load i64, ptr %slot115, align 8
  %v907 = load i64, ptr %slot112, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v906, i64 %v907) nomerge, !dbg !120
  br label %bb_rcgdone126
bb_rcgdec126:
  %v908 = load i64, ptr %slot124, align 8
  %v909 = load i64, ptr %slot116, align 8
  %p910 = inttoptr i64 %v909 to ptr
  %rgep911 = getelementptr i8, ptr %p910, i64 -24
  store i64 %v908, ptr %rgep911, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear126
bb_rcgclear126:
  %v912 = load i64, ptr %slot112, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i64 0, ptr %p913, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone126
bb_rcgdone126:
  br label %bb_rcslotdone110
bb_rcslotowner110:
  %v914 = load i64, ptr %slot41, align 8
  store i64 %v914, ptr %slot129, align 8
  %v915 = load i64, ptr %slot112, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i64, ptr %p916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld917, ptr %slot130, align 8
  %v918 = load i64, ptr %slot130, align 8
  %cmp919 = icmp ne i64 %v918, 0
  %cv920 = zext i1 %cmp919 to i32
  store i32 %cv920, ptr %slot131, align 8
  %v921 = load i32, ptr %slot131, align 8
  %cv922 = zext i32 %v921 to i64
  %cond923 = icmp ne i64 %cv922, 0
  br i1 %cond923, label %bb_rcgnn141, label %bb_rcgdone141
bb_rcgnn141:
  %v924 = load i64, ptr %slot130, align 8
  %op925 = sub i64 %v924, 16
  store i64 %op925, ptr %slot132, align 8
  %v926 = load i64, ptr %slot130, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %rgep928 = getelementptr i8, ptr %p927, i64 -16
  %ld929 = load i64, ptr %rgep928, align 8, !alias.scope !9, !noalias !10
  store i64 %ld929, ptr %slot133, align 8
  %v930 = load i64, ptr %slot133, align 8
  %op931 = and i64 %v930, 4611686018427387906
  store i64 %op931, ptr %slot134, align 8
  %v932 = load i64, ptr %slot134, align 8
  %cmp933 = icmp ne i64 %v932, 0
  %cv934 = zext i1 %cmp933 to i32
  store i32 %cv934, ptr %slot135, align 8
  %v935 = load i32, ptr %slot135, align 8
  %cv936 = zext i32 %v935 to i64
  %cond937 = icmp ne i64 %cv936, 0
  br i1 %cond937, label %bb_rcgclear141, label %bb_rcgcounted141
bb_rcgcounted141:
  %v938 = load i64, ptr %slot130, align 8
  %op939 = sub i64 %v938, 32
  store i64 %op939, ptr %slot136, align 8
  %v940 = load i64, ptr %slot130, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %rgep942 = getelementptr i8, ptr %p941, i64 -32
  %ld943 = load i64, ptr %rgep942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld943, ptr %slot137, align 8
  %v944 = load i64, ptr %slot137, align 8
  %op945 = sub i64 %v944, 1
  store i64 %op945, ptr %slot138, align 8
  %v946 = load i64, ptr %slot138, align 8
  %cmp947 = icmp eq i64 %v946, 0
  %cv948 = zext i1 %cmp947 to i32
  store i32 %cv948, ptr %slot139, align 8
  %v949 = load i32, ptr %slot139, align 8
  %cv950 = zext i32 %v949 to i64
  %cond951 = icmp ne i64 %cv950, 0
  br i1 %cond951, label %bb_rcglast141, label %bb_rcgdec141
bb_rcglast141:
  %v952 = load i64, ptr %slot130, align 8
  %op953 = sub i64 %v952, 24
  store i64 %op953, ptr %slot140, align 8
  %v954 = load i64, ptr %slot130, align 8
  %p955 = inttoptr i64 %v954 to ptr
  %rgep956 = getelementptr i8, ptr %p955, i64 -24
  %ld957 = load i64, ptr %rgep956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld957, ptr %slot141, align 8
  %v958 = load i64, ptr %slot141, align 8
  %cmp959 = icmp ne i64 %v958, 0
  %cv960 = zext i1 %cmp959 to i32
  store i32 %cv960, ptr %slot142, align 8
  %v961 = load i32, ptr %slot142, align 8
  %cv962 = zext i32 %v961 to i64
  %cond963 = icmp ne i64 %cv962, 0
  br i1 %cond963, label %bb_rcgdec141, label %bb_rcgslow141
bb_rcgslow141:
  %v964 = load i64, ptr %slot129, align 8
  %v965 = load i64, ptr %slot112, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v964, i64 %v965) nomerge, !dbg !120
  br label %bb_rcgdone141
bb_rcgdec141:
  %v966 = load i64, ptr %slot138, align 8
  %v967 = load i64, ptr %slot130, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %rgep969 = getelementptr i8, ptr %p968, i64 -32
  store i64 %v966, ptr %rgep969, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear141
bb_rcgclear141:
  %v970 = load i64, ptr %slot112, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i64 0, ptr %p971, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone141
bb_rcgdone141:
  br label %bb_rcslotdone110
bb_rcslotdone110:
  %v972 = load i64, ptr %slot110, align 8
  %p974 = inttoptr i64 %v972 to ptr
  %gep975 = getelementptr i8, ptr %p974, i64 8
  %op973 = ptrtoint ptr %gep975 to i64
  store i64 %op973, ptr %slot143, align 8
  store i64 0, ptr %slot144, align 8
  %v976 = load i64, ptr %slot143, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %ld978 = load i64, ptr %p977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld978, ptr %slot145, align 8
  %v979 = load i64, ptr %slot145, align 8
  %cmp980 = icmp ne i64 %v979, 0
  %cv981 = zext i1 %cmp980 to i32
  store i32 %cv981, ptr %slot146, align 8
  %v982 = load i32, ptr %slot146, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcguniquenn147, label %bb_rcgunique147
bb_rcguniquenn147:
  %v985 = load i64, ptr %slot145, align 8
  %op986 = sub i64 %v985, 16
  store i64 %op986, ptr %slot147, align 8
  %v987 = load i64, ptr %slot145, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %rgep989 = getelementptr i8, ptr %p988, i64 -16
  %ld990 = load i64, ptr %rgep989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld990, ptr %slot148, align 8
  %v991 = load i64, ptr %slot148, align 8
  %op992 = and i64 %v991, 6917529027641081858
  store i64 %op992, ptr %slot149, align 8
  %v993 = load i64, ptr %slot149, align 8
  %cmp994 = icmp ne i64 %v993, 0
  %cv995 = zext i1 %cmp994 to i32
  store i32 %cv995, ptr %slot150, align 8
  %v996 = load i32, ptr %slot150, align 8
  %cv997 = zext i32 %v996 to i64
  %cond998 = icmp ne i64 %cv997, 0
  br i1 %cond998, label %bb_rcguniqueslow147, label %bb_rcguniquecount147
bb_rcguniquecount147:
  %v999 = load i64, ptr %slot145, align 8
  %op1000 = sub i64 %v999, 32
  store i64 %op1000, ptr %slot151, align 8
  %v1001 = load i64, ptr %slot145, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %rgep1003 = getelementptr i8, ptr %p1002, i64 -32
  %ld1004 = load i64, ptr %rgep1003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1004, ptr %slot152, align 8
  %v1005 = load i64, ptr %slot152, align 8
  %cmp1006 = icmp ult i64 %v1005, 2
  %cv1007 = zext i1 %cmp1006 to i32
  store i32 %cv1007, ptr %slot153, align 8
  %v1008 = load i32, ptr %slot153, align 8
  %cv1009 = zext i32 %v1008 to i64
  %cond1010 = icmp ne i64 %cv1009, 0
  br i1 %cond1010, label %bb_rcgunique147, label %bb_rcguniqueslow147
bb_rcguniqueslow147:
  %v1011 = load i64, ptr %slot1, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %p1013 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v1014 = load i64, ptr %slot143, align 8
  %p1015 = inttoptr i64 %v1014 to ptr
  %v1016 = load i64, ptr %slot144, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %call1018 = call i32 @myl_qbe_rc_unique_field(ptr %p1012, ptr %p1013, ptr %p1015, ptr %p1017) nomerge, !dbg !120
  store i32 %call1018, ptr %slot154, align 8
  %v1019 = load i32, ptr %slot154, align 8
  %cv1020 = zext i32 %v1019 to i64
  %cond1021 = icmp ne i64 %cv1020, 0
  br i1 %cond1021, label %bb_rcunique157, label %bb_failure
bb_rcunique157:
  br label %bb_rcgunique147
bb_rcgunique147:
  %v1022 = load i64, ptr %slot143, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %ld1024 = load i64, ptr %p1023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1024, ptr %slot155, align 8
  %v1025 = load i64, ptr %slot155, align 8
  %v1026 = load i64, ptr %slot32, align 8
  %p1027 = inttoptr i64 %v1026 to ptr
  store i64 %v1025, ptr %p1027, align 8, !alias.scope !3, !noalias !4
  %v1028 = load i64, ptr %slot32, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  %ld1030 = load i64, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1030, ptr %slot156, align 8
  %v1031 = load i64, ptr %slot156, align 8
  %v1032 = load i64, ptr %slot26, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i64 %v1031, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  %v1034 = load i64, ptr %slot23, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i64, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1036, ptr %slot157, align 8
  %v1037 = load i64, ptr %slot157, align 8
  %v1038 = load i64, ptr %slot32, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i64 %v1037, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot32, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot158, align 8
  %v1043 = load i64, ptr %slot158, align 8
  %v1044 = load i64, ptr %slot28, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i64 %v1043, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot28, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i64, ptr %p1047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1048, ptr %slot159, align 8
  %v1049 = load i64, ptr %slot159, align 8
  %v1050 = load i64, ptr %slot32, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i64 %v1049, ptr %p1051, align 8, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot33, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i64 0, ptr %p1053, align 8, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot33, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %ld1056 = load i64, ptr %p1055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1056, ptr %slot160, align 8
  %v1057 = load i64, ptr %slot32, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  %ld1059 = load i64, ptr %p1058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1059, ptr %slot161, align 8
  %v1060 = load i64, ptr %slot161, align 8
  %v1061 = load i64, ptr %slot160, align 8
  %cmp1062 = icmp slt i64 %v1060, %v1061
  %cv1063 = zext i1 %cmp1062 to i64
  store i64 %cv1063, ptr %slot162, align 8
  %v1064 = load i64, ptr %slot162, align 8
  %v1065 = load i64, ptr %slot32, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  store i64 %v1064, ptr %p1066, align 8, !alias.scope !3, !noalias !4
  %v1067 = load i64, ptr %slot32, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %ld1069 = load i64, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1069, ptr %slot163, align 8
  %v1070 = load i64, ptr %slot163, align 8
  %cond1071 = icmp ne i64 %v1070, 0
  br i1 %cond1071, label %bb_next167, label %bb_i20
bb_next167:
  %v1072 = load i64, ptr %slot26, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i64, ptr %p1073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1074, ptr %slot164, align 8
  %v1075 = load i64, ptr %slot164, align 8
  %op1076 = add i64 %v1075, 0
  store i64 %op1076, ptr %slot165, align 8
  %v1077 = load i64, ptr %slot165, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  %ld1079 = load i64, ptr %p1078, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1079, ptr %slot166, align 8
  %v1080 = load i64, ptr %slot166, align 8
  %v1081 = load i64, ptr %slot32, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i64 %v1080, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot32, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i64, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1085, ptr %slot167, align 8
  %v1086 = load i64, ptr %slot167, align 8
  %cmp1087 = icmp ugt i64 %v1086, 9223372036854775807
  %cv1088 = zext i1 %cmp1087 to i64
  store i64 %cv1088, ptr %slot168, align 8
  %v1089 = load i64, ptr %slot168, align 8
  %cond1090 = icmp ne i64 %v1089, 0
  br i1 %cond1090, label %bb_cast_overflow172, label %bb_cast_ok172
bb_cast_overflow172:
  %v1091 = load i64, ptr %slot1, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %v1093 = load i64, ptr %slot167, align 8
  call void @myl_qbe_fail_cast(ptr %p1092, i64 %v1093, i64 320) nomerge, !dbg !122
  unreachable
bb_cast_ok172:
  %v1094 = load i64, ptr %slot167, align 8
  %v1095 = load i64, ptr %slot32, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i64 %v1094, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  %v1097 = load i64, ptr %slot28, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  %ld1099 = load i64, ptr %p1098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1099, ptr %slot169, align 8
  %v1100 = load i64, ptr %slot169, align 8
  %v1101 = load i64, ptr %slot33, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  store i64 %v1100, ptr %p1102, align 8, !alias.scope !3, !noalias !4
  %v1103 = load i64, ptr %slot33, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %ld1105 = load i64, ptr %p1104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1105, ptr %slot170, align 8
  %v1106 = load i64, ptr %slot32, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  %ld1108 = load i64, ptr %p1107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1108, ptr %slot171, align 8
  %v1109 = load i64, ptr %slot171, align 8
  %v1110 = load i64, ptr %slot170, align 8
  %ovpair1112 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1109, i64 %v1110)
  %op1111 = extractvalue { i64, i1 } %ovpair1112, 0
  %ov1113 = extractvalue { i64, i1 } %ovpair1112, 1
  store i64 %op1111, ptr %slot172, align 8
  %v1114 = load i64, ptr %slot171, align 8
  %v1115 = load i64, ptr %slot172, align 8
  %op1116 = xor i64 %v1114, %v1115
  store i64 %op1116, ptr %slot173, align 8
  %v1117 = load i64, ptr %slot170, align 8
  %v1118 = load i64, ptr %slot172, align 8
  %op1119 = xor i64 %v1117, %v1118
  store i64 %op1119, ptr %slot174, align 8
  %v1120 = load i64, ptr %slot173, align 8
  %v1121 = load i64, ptr %slot174, align 8
  %op1122 = and i64 %v1120, %v1121
  store i64 %op1122, ptr %slot175, align 8
  %cv1123 = zext i1 %ov1113 to i64
  store i64 %cv1123, ptr %slot176, align 8
  %v1124 = load i64, ptr %slot176, align 8
  %cond1125 = icmp ne i64 %v1124, 0
  br i1 %cond1125, label %bb_overflow176, label %bb_checked176
bb_overflow176:
  %v1126 = load i64, ptr %slot1, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  %v1128 = load i64, ptr %slot171, align 8
  %v1129 = load i64, ptr %slot170, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1127, i64 0, i64 %v1128, i64 %v1129, i64 64) nomerge, !dbg !124
  unreachable
bb_checked176:
  %v1130 = load i64, ptr %slot172, align 8
  %v1131 = load i64, ptr %slot32, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  store i64 %v1130, ptr %p1132, align 8, !alias.scope !3, !noalias !4
  %v1133 = load i64, ptr %slot32, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %ld1135 = load i64, ptr %p1134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1135, ptr %slot177, align 8
  %v1136 = load i64, ptr %slot177, align 8
  %v1137 = load i64, ptr %slot28, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i64 %v1136, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i20:
  %v1139 = load i64, ptr %slot28, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  %ld1141 = load i64, ptr %p1140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1141, ptr %slot178, align 8
  %v1142 = load i64, ptr %slot178, align 8
  %v1143 = load i64, ptr %slot32, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 %v1142, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot27, align 8
  %v1146 = load i64, ptr %slot34, align 8
  %p1147 = inttoptr i64 %v1145 to ptr
  %p1148 = inttoptr i64 %v1146 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1148, ptr %p1147, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1149 = load i64, ptr %slot34, align 8
  %v1150 = load i64, ptr %slot33, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i64 %v1149, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot26, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i64, ptr %p1153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1154, ptr %slot179, align 8
  %v1155 = load i64, ptr %slot33, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %ld1157 = load i64, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1157, ptr %slot180, align 8
  %v1158 = load i64, ptr %slot32, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i64, ptr %p1159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1160, ptr %slot181, align 8
  %v1161 = load i64, ptr %slot179, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %ld1163 = load i64, ptr %p1162, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1163, ptr %slot182, align 8
  %v1164 = load i64, ptr %slot181, align 8
  %v1165 = load i64, ptr %slot182, align 8
  %cmp1166 = icmp ult i64 %v1164, %v1165
  %cv1167 = zext i1 %cmp1166 to i64
  store i64 %cv1167, ptr %slot183, align 8
  %v1168 = load i64, ptr %slot183, align 8
  %cond1169 = icmp ne i64 %v1168, 0
  br i1 %cond1169, label %bb_success189, label %bb_failed189
bb_failed189:
  %v1170 = load i64, ptr %slot1, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  %v1172 = load i64, ptr %slot181, align 8
  %v1173 = load i64, ptr %slot182, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1171, i64 %v1172, i64 %v1173) nomerge, !dbg !126
  unreachable
bb_success189:
  %v1174 = load i64, ptr %slot179, align 8
  %op1175 = add i64 %v1174, 32
  store i64 %op1175, ptr %slot184, align 8
  %v1176 = load i64, ptr %slot184, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  %ld1178 = load i64, ptr %p1177, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1178, ptr %slot185, align 8
  %v1179 = load i64, ptr %slot181, align 8
  %op1180 = mul i64 %v1179, 16
  store i64 %op1180, ptr %slot186, align 8
  %v1181 = load i64, ptr %slot185, align 8
  %v1182 = load i64, ptr %slot186, align 8
  %op1183 = add i64 %v1181, %v1182
  store i64 %op1183, ptr %slot187, align 8
  %v1184 = load i64, ptr %slot33, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  %ld1186 = load i64, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1186, ptr %slot188, align 8
  %v1187 = load i64, ptr %slot188, align 8
  %v1188 = load i64, ptr %slot187, align 8
  %p1189 = inttoptr i64 %v1187 to ptr
  %p1190 = inttoptr i64 %v1188 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1190, ptr %p1189, i64 16, i1 false), !alias.scope !10000001
  %v1191 = load i64, ptr %slot32, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i64 0, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot25, align 8
  %v1194 = load i64, ptr %slot32, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i64 %v1193, ptr %p1195, align 8, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot32, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i64, ptr %p1197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1198, ptr %slot189, align 8
  %v1199 = load i64, ptr %slot11, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %ld1201 = load i32, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1201, ptr %slot190, align 8
  %v1202 = load i64, ptr %slot12, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %ld1204 = load i32, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1204, ptr %slot191, align 8
  %v1205 = load i32, ptr %slot191, align 8
  %op1206 = and i32 %v1205, 24
  store i32 %op1206, ptr %slot191, align 8
  %v1207 = load i32, ptr %slot191, align 8
  %cmp1208 = icmp eq i32 %v1207, 0
  %cv1209 = zext i1 %cmp1208 to i32
  store i32 %cv1209, ptr %slot192, align 8
  %v1210 = load i32, ptr %slot190, align 8
  %v1211 = load i32, ptr %slot192, align 8
  %op1212 = and i32 %v1210, %v1211
  store i32 %op1212, ptr %slot193, align 8
  %v1213 = load i64, ptr %slot42, align 8
  store i64 %v1213, ptr %slot194, align 8
  %v1214 = load i32, ptr %slot193, align 8
  %op1215 = mul i32 %v1214, 4
  store i32 %op1215, ptr %slot195, align 8
  %v1216 = load i32, ptr %slot195, align 8
  %op1217 = or i32 %v1216, 0
  store i32 %op1217, ptr %slot196, align 8
  %v1218 = load i64, ptr %slot17, align 8
  store i64 %v1218, ptr %slot197, align 8
  %v1219 = load i64, ptr %slot41, align 8
  %v1220 = load i64, ptr %slot197, align 8
  %v1221 = load i64, ptr %slot189, align 8
  %v1222 = load i64, ptr %slot194, align 8
  %cv1223 = trunc i64 %v1222 to i32
  %v1224 = load i32, ptr %slot196, align 8
  %call1225 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_publish(i64 %v1219, i64 %v1220, i64 %v1221, i32 %cv1223, i32 %v1224) nomerge, !dbg !128
  store i32 %call1225, ptr %slot198, align 8
  %v1226 = load i32, ptr %slot198, align 8
  %cv1227 = zext i32 %v1226 to i64
  %cond1228 = icmp ne i64 %cv1227, 0
  br i1 %cond1228, label %bb_rcsuccess209, label %bb_rcfailure209
bb_rcfailure209:
  %v1229 = load i64, ptr %slot41, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  %call1231 = call i32 @myl_rc_take_failure(ptr %p1230) nomerge, !dbg !128
  store i32 %call1231, ptr %slot199, align 8
  %v1232 = load i64, ptr %slot1, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  %v1234 = load i32, ptr %slot199, align 8
  %call1235 = call i32 @myl_qbe_rc_status(ptr %p1233, i32 %v1234) nomerge, !dbg !128
  store i32 %call1235, ptr %slot200, align 8
  br label %bb_failure
bb_rcsuccess209:
  %v1236 = load i32, ptr %slot193, align 8
  %cv1237 = zext i32 %v1236 to i64
  %cond1238 = icmp ne i64 %cv1237, 0
  br i1 %cond1238, label %bb_rchtaken212, label %bb_rchcopied212
bb_rchcopied212:
  %v1239 = load i64, ptr %slot11, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %ld1241 = load i32, ptr %p1240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1241, ptr %slot201, align 8
  %v1242 = load i32, ptr %slot201, align 8
  %cv1243 = zext i32 %v1242 to i64
  %cond1244 = icmp ne i64 %cv1243, 0
  br i1 %cond1244, label %bb_rcslotdrop215, label %bb_rcslotdone215
bb_rcslotdrop215:
  %v1245 = load i64, ptr %slot11, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i32 0, ptr %p1246, align 4, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot16, align 8
  store i64 %v1247, ptr %slot202, align 8
  %v1248 = load i64, ptr %slot12, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  %ld1250 = load i32, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1250, ptr %slot203, align 8
  %v1251 = load i32, ptr %slot203, align 8
  %op1252 = and i32 %v1251, 28
  store i32 %op1252, ptr %slot204, align 8
  %v1253 = load i32, ptr %slot204, align 8
  %cv1254 = zext i32 %v1253 to i64
  %cond1255 = icmp ne i64 %cv1254, 0
  br i1 %cond1255, label %bb_rcslotrole215, label %bb_rcslotowner215
bb_rcslotrole215:
  %v1256 = load i64, ptr %slot41, align 8
  store i64 %v1256, ptr %slot205, align 8
  %v1257 = load i64, ptr %slot205, align 8
  %v1258 = load i64, ptr %slot202, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1257, i64 %v1258) nomerge, !dbg !128
  br label %bb_rcslotdone215
bb_rcslotowner215:
  %v1259 = load i64, ptr %slot41, align 8
  store i64 %v1259, ptr %slot206, align 8
  %v1260 = load i64, ptr %slot206, align 8
  %v1261 = load i64, ptr %slot202, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1260, i64 %v1261) nomerge, !dbg !128
  br label %bb_rcslotdone215
bb_rcslotdone215:
  br label %bb_rchprepared212
bb_rchtaken212:
  %v1262 = load i64, ptr %slot11, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  store i32 0, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared212
bb_rchprepared212:
  %v1264 = load i64, ptr %slot14, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i32 2, ptr %p1265, align 4, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot13, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  store i32 1, ptr %p1267, align 4, !alias.scope !3, !noalias !4
  %v1268 = load i64, ptr %slot16, align 8
  store i64 %v1268, ptr %slot207, align 8
  %v1269 = load i64, ptr %slot17, align 8
  store i64 %v1269, ptr %slot208, align 8
  %v1270 = load i64, ptr %slot208, align 8
  %v1271 = load i64, ptr %slot207, align 8
  %p1272 = inttoptr i64 %v1270 to ptr
  %p1273 = inttoptr i64 %v1271 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1273, ptr %p1272, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1274 = load i64, ptr %slot12, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i32 2, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot14, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %ld1278 = load i32, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1278, ptr %slot209, align 8
  %v1279 = load i32, ptr %slot209, align 8
  %v1280 = load i64, ptr %slot12, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i32 %v1279, ptr %p1281, align 4, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot13, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  store i32 0, ptr %p1283, align 4, !alias.scope !3, !noalias !4
  %v1284 = load i64, ptr %slot11, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i32 1, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot207, align 8
  %v1287 = load i64, ptr %slot32, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i64 %v1286, ptr %p1288, align 8, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot35, align 8
  store i64 %v1289, ptr %slot210, align 8
  %v1290 = load i64, ptr %slot210, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i64 0, ptr %p1291, align 8, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot210, align 8
  %p1294 = inttoptr i64 %v1292 to ptr
  %gep1295 = getelementptr i8, ptr %p1294, i64 8
  %op1293 = ptrtoint ptr %gep1295 to i64
  store i64 %op1293, ptr %slot211, align 8
  %v1296 = load i64, ptr %slot211, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i64 0, ptr %p1297, align 8, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot210, align 8
  %p1300 = inttoptr i64 %v1298 to ptr
  %gep1301 = getelementptr i8, ptr %p1300, i64 16
  %op1299 = ptrtoint ptr %gep1301 to i64
  store i64 %op1299, ptr %slot212, align 8
  %v1302 = load i64, ptr %slot212, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i64 0, ptr %p1303, align 8, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot210, align 8
  %p1306 = inttoptr i64 %v1304 to ptr
  %gep1307 = getelementptr i8, ptr %p1306, i64 24
  %op1305 = ptrtoint ptr %gep1307 to i64
  store i64 %op1305, ptr %slot213, align 8
  %v1308 = load i64, ptr %slot213, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  store i64 0, ptr %p1309, align 8, !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot210, align 8
  %p1312 = inttoptr i64 %v1310 to ptr
  %gep1313 = getelementptr i8, ptr %p1312, i64 32
  %op1311 = ptrtoint ptr %gep1313 to i64
  store i64 %op1311, ptr %slot214, align 8
  %v1314 = load i64, ptr %slot214, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  store i64 0, ptr %p1315, align 8, !alias.scope !3, !noalias !4
  %v1316 = load i64, ptr %slot210, align 8
  %p1318 = inttoptr i64 %v1316 to ptr
  %gep1319 = getelementptr i8, ptr %p1318, i64 40
  %op1317 = ptrtoint ptr %gep1319 to i64
  store i64 %op1317, ptr %slot215, align 8
  %v1320 = load i64, ptr %slot215, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i64 0, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot210, align 8
  %p1324 = inttoptr i64 %v1322 to ptr
  %gep1325 = getelementptr i8, ptr %p1324, i64 48
  %op1323 = ptrtoint ptr %gep1325 to i64
  store i64 %op1323, ptr %slot216, align 8
  %v1326 = load i64, ptr %slot216, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i64 0, ptr %p1327, align 8, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot210, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 9, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot15, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 1, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot32, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %ld1334 = load i64, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1334, ptr %slot217, align 8
  %v1335 = load i64, ptr %slot210, align 8
  %p1337 = inttoptr i64 %v1335 to ptr
  %gep1338 = getelementptr i8, ptr %p1337, i64 8
  %op1336 = ptrtoint ptr %gep1338 to i64
  store i64 %op1336, ptr %slot218, align 8
  %v1339 = load i64, ptr %slot42, align 8
  store i64 %v1339, ptr %slot219, align 8
  %v1340 = load i64, ptr %slot32, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  %ld1342 = load i64, ptr %p1341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1342, ptr %slot220, align 8
  %v1343 = load i64, ptr %slot17, align 8
  store i64 %v1343, ptr %slot221, align 8
  %v1344 = load i64, ptr %slot42, align 8
  store i64 %v1344, ptr %slot222, align 8
  %v1345 = load i64, ptr %slot220, align 8
  %op1346 = add i64 %v1345, 8
  store i64 %op1346, ptr %slot223, align 8
  %v1347 = load i64, ptr %slot223, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %ld1349 = load i64, ptr %p1348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1349, ptr %slot224, align 8
  %v1350 = load i64, ptr %slot224, align 8
  %cmp1351 = icmp ne i64 %v1350, 0
  %cv1352 = zext i1 %cmp1351 to i32
  store i32 %cv1352, ptr %slot225, align 8
  %v1353 = load i32, ptr %slot225, align 8
  %cv1354 = zext i32 %v1353 to i64
  %cond1355 = icmp ne i64 %cv1354, 0
  br i1 %cond1355, label %bb_rcmoveheader251, label %bb_rcmovenext251
bb_rcmoveheader251:
  %v1356 = load i64, ptr %slot224, align 8
  %op1357 = sub i64 %v1356, 16
  store i64 %op1357, ptr %slot226, align 8
  %v1358 = load i64, ptr %slot224, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %rgep1360 = getelementptr i8, ptr %p1359, i64 -16
  %ld1361 = load i64, ptr %rgep1360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1361, ptr %slot227, align 8
  %v1362 = load i64, ptr %slot227, align 8
  %op1363 = and i64 %v1362, 5764607523034234881
  store i64 %op1363, ptr %slot228, align 8
  %v1364 = load i64, ptr %slot228, align 8
  %cmp1365 = icmp ne i64 %v1364, 0
  %cv1366 = zext i1 %cmp1365 to i32
  store i32 %cv1366, ptr %slot229, align 8
  %v1367 = load i32, ptr %slot229, align 8
  %cv1368 = zext i32 %v1367 to i64
  %cond1369 = icmp ne i64 %cv1368, 0
  br i1 %cond1369, label %bb_rcmoveslow248, label %bb_rcmovenext251
bb_rcmovenext251:
  %v1370 = load i64, ptr %slot220, align 8
  %v1371 = load i64, ptr %slot221, align 8
  %p1372 = inttoptr i64 %v1370 to ptr
  %p1373 = inttoptr i64 %v1371 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1373, ptr %p1372, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1374 = load i64, ptr %slot220, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i64 0, ptr %p1375, align 8, !alias.scope !3, !noalias !4
  %v1376 = load i64, ptr %slot220, align 8
  %op1377 = add i64 %v1376, 8
  store i64 %op1377, ptr %slot230, align 8
  %v1378 = load i64, ptr %slot230, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 0, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved248
bb_rcmoveslow248:
  %v1380 = load i64, ptr %slot41, align 8
  %v1381 = load i64, ptr %slot221, align 8
  %v1382 = load i64, ptr %slot220, align 8
  %v1383 = load i64, ptr %slot222, align 8
  %cv1384 = trunc i64 %v1383 to i32
  %call1385 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1380, i64 %v1381, i64 %v1382, i32 %cv1384) nomerge, !dbg !130
  store i32 %call1385, ptr %slot231, align 8
  %v1386 = load i32, ptr %slot231, align 8
  %cv1387 = zext i32 %v1386 to i64
  %cond1388 = icmp ne i64 %cv1387, 0
  br i1 %cond1388, label %bb_rcsuccess259, label %bb_rcfailure259
bb_rcfailure259:
  %v1389 = load i64, ptr %slot41, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %call1391 = call i32 @myl_rc_take_failure(ptr %p1390) nomerge, !dbg !130
  store i32 %call1391, ptr %slot232, align 8
  %v1392 = load i64, ptr %slot1, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  %v1394 = load i32, ptr %slot232, align 8
  %call1395 = call i32 @myl_qbe_rc_status(ptr %p1393, i32 %v1394) nomerge, !dbg !130
  store i32 %call1395, ptr %slot233, align 8
  br label %bb_failure
bb_rcsuccess259:
  br label %bb_rcmoved248
bb_rcmoved248:
  %v1396 = load i64, ptr %slot11, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i32 0, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  %v1398 = load i64, ptr %slot14, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 2, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot13, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 1, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot17, align 8
  store i64 %v1402, ptr %slot234, align 8
  %v1403 = load i64, ptr %slot234, align 8
  %v1404 = load i64, ptr %slot218, align 8
  %p1405 = inttoptr i64 %v1403 to ptr
  %p1406 = inttoptr i64 %v1404 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1406, ptr %p1405, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot13, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i32 0, ptr %p1408, align 4, !alias.scope !3, !noalias !4
  %v1409 = load i64, ptr %slot210, align 8
  %v1410 = load i64, ptr %slot32, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  store i64 %v1409, ptr %p1411, align 8, !alias.scope !3, !noalias !4
  %v1412 = load i64, ptr %slot32, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  %ld1414 = load i64, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1414, ptr %slot235, align 8
  %v1415 = load i64, ptr %slot16, align 8
  store i64 %v1415, ptr %slot236, align 8
  %v1416 = load i64, ptr %slot235, align 8
  %v1417 = load i64, ptr %slot236, align 8
  %p1418 = inttoptr i64 %v1416 to ptr
  %p1419 = inttoptr i64 %v1417 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1419, ptr %p1418, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1420 = load i64, ptr %slot12, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  store i32 2, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  %v1422 = load i64, ptr %slot11, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 1, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot236, align 8
  %v1425 = load i64, ptr %slot32, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i64 %v1424, ptr %p1426, align 8, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot32, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %ld1429 = load i64, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1429, ptr %slot237, align 8
  %v1430 = load i64, ptr %slot11, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i32, ptr %p1431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1432, ptr %slot238, align 8
  %v1433 = load i64, ptr %slot12, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  %ld1435 = load i32, ptr %p1434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1435, ptr %slot239, align 8
  %v1436 = load i32, ptr %slot239, align 8
  %op1437 = and i32 %v1436, 24
  store i32 %op1437, ptr %slot239, align 8
  %v1438 = load i32, ptr %slot239, align 8
  %cmp1439 = icmp eq i32 %v1438, 0
  %cv1440 = zext i1 %cmp1439 to i32
  store i32 %cv1440, ptr %slot240, align 8
  %v1441 = load i32, ptr %slot238, align 8
  %v1442 = load i32, ptr %slot240, align 8
  %op1443 = and i32 %v1441, %v1442
  store i32 %op1443, ptr %slot241, align 8
  %v1444 = load i32, ptr %slot241, align 8
  %cv1445 = zext i32 %v1444 to i64
  %cond1446 = icmp ne i64 %cv1445, 0
  br i1 %cond1446, label %bb_rcprivateown278, label %bb_rcprivateloan278
bb_rcprivateown278:
  %v1447 = load i64, ptr %slot17, align 8
  store i64 %v1447, ptr %slot242, align 8
  %v1448 = load i64, ptr %slot42, align 8
  store i64 %v1448, ptr %slot243, align 8
  %v1449 = load i64, ptr %slot41, align 8
  %v1450 = load i64, ptr %slot242, align 8
  %v1451 = load i64, ptr %slot237, align 8
  %v1452 = load i64, ptr %slot243, align 8
  %cv1453 = trunc i64 %v1452 to i32
  %call1454 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v1449, i64 %v1450, i64 %v1451, i32 %cv1453) nomerge, !dbg !132
  store i32 %call1454, ptr %slot244, align 8
  %v1455 = load i32, ptr %slot244, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcsuccess282, label %bb_rcfailure282
bb_rcfailure282:
  %v1458 = load i64, ptr %slot41, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %call1460 = call i32 @myl_rc_take_failure(ptr %p1459) nomerge, !dbg !132
  store i32 %call1460, ptr %slot245, align 8
  %v1461 = load i64, ptr %slot1, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %v1463 = load i32, ptr %slot245, align 8
  %call1464 = call i32 @myl_qbe_rc_status(ptr %p1462, i32 %v1463) nomerge, !dbg !132
  store i32 %call1464, ptr %slot246, align 8
  br label %bb_failure
bb_rcsuccess282:
  %v1465 = load i64, ptr %slot11, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i32 0, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot14, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i32 2, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot13, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  store i32 1, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared278
bb_rcprivateloan278:
  %v1471 = load i64, ptr %slot11, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  %ld1473 = load i32, ptr %p1472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1473, ptr %slot247, align 8
  %v1474 = load i64, ptr %slot12, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  %ld1476 = load i32, ptr %p1475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1476, ptr %slot248, align 8
  %v1477 = load i32, ptr %slot248, align 8
  %cmp1478 = icmp eq i32 %v1477, 16
  %cv1479 = zext i1 %cmp1478 to i32
  store i32 %cv1479, ptr %slot249, align 8
  %v1480 = load i32, ptr %slot249, align 8
  %v1481 = load i32, ptr %slot247, align 8
  %op1482 = and i32 %v1480, %v1481
  store i32 %op1482, ptr %slot249, align 8
  %v1483 = load i32, ptr %slot249, align 8
  %cv1484 = zext i32 %v1483 to i64
  %cond1485 = icmp ne i64 %cv1484, 0
  br i1 %cond1485, label %bb_rcprivatemove278, label %bb_rcprivatenew278
bb_rcprivatemove278:
  %v1486 = load i64, ptr %slot17, align 8
  store i64 %v1486, ptr %slot250, align 8
  %v1487 = load i64, ptr %slot237, align 8
  %v1488 = load i64, ptr %slot250, align 8
  %p1489 = inttoptr i64 %v1487 to ptr
  %p1490 = inttoptr i64 %v1488 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1490, ptr %p1489, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot237, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  call void @llvm.memset.p0.i64(ptr %p1492, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v1493 = load i64, ptr %slot14, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i32 2, ptr %p1494, align 4, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot14, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  store i32 16, ptr %p1496, align 4, !alias.scope !3, !noalias !4
  %v1497 = load i64, ptr %slot13, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i32 1, ptr %p1498, align 4, !alias.scope !3, !noalias !4
  %v1499 = load i64, ptr %slot11, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  store i32 0, ptr %p1500, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared278
bb_rcprivatenew278:
  %v1501 = load i64, ptr %slot17, align 8
  store i64 %v1501, ptr %slot251, align 8
  %v1502 = load i64, ptr %slot41, align 8
  %v1503 = load i64, ptr %slot251, align 8
  %v1504 = load i64, ptr %slot237, align 8
  %call1505 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v1502, i64 %v1503, i64 %v1504) nomerge, !dbg !132
  store i32 %call1505, ptr %slot252, align 8
  %v1506 = load i32, ptr %slot252, align 8
  %cv1507 = zext i32 %v1506 to i64
  %cond1508 = icmp ne i64 %cv1507, 0
  br i1 %cond1508, label %bb_rcsuccess300, label %bb_rcfailure300
bb_rcfailure300:
  %v1509 = load i64, ptr %slot41, align 8
  %p1510 = inttoptr i64 %v1509 to ptr
  %call1511 = call i32 @myl_rc_take_failure(ptr %p1510) nomerge, !dbg !132
  store i32 %call1511, ptr %slot253, align 8
  %v1512 = load i64, ptr %slot1, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %v1514 = load i32, ptr %slot253, align 8
  %call1515 = call i32 @myl_qbe_rc_status(ptr %p1513, i32 %v1514) nomerge, !dbg !132
  store i32 %call1515, ptr %slot254, align 8
  br label %bb_failure
bb_rcsuccess300:
  %v1516 = load i64, ptr %slot14, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  store i32 2, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  %v1518 = load i64, ptr %slot14, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  store i32 16, ptr %p1519, align 4, !alias.scope !3, !noalias !4
  %v1520 = load i64, ptr %slot13, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  store i32 1, ptr %p1521, align 4, !alias.scope !3, !noalias !4
  %v1522 = load i64, ptr %slot11, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  %ld1524 = load i32, ptr %p1523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1524, ptr %slot255, align 8
  %v1525 = load i32, ptr %slot255, align 8
  %cv1526 = zext i32 %v1525 to i64
  %cond1527 = icmp ne i64 %cv1526, 0
  br i1 %cond1527, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1528 = load i64, ptr %slot11, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  store i32 0, ptr %p1529, align 4, !alias.scope !3, !noalias !4
  %v1530 = load i64, ptr %slot16, align 8
  store i64 %v1530, ptr %slot256, align 8
  %v1531 = load i64, ptr %slot12, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %ld1533 = load i32, ptr %p1532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1533, ptr %slot257, align 8
  %v1534 = load i32, ptr %slot257, align 8
  %op1535 = and i32 %v1534, 28
  store i32 %op1535, ptr %slot258, align 8
  %v1536 = load i32, ptr %slot258, align 8
  %cv1537 = zext i32 %v1536 to i64
  %cond1538 = icmp ne i64 %cv1537, 0
  br i1 %cond1538, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1539 = load i64, ptr %slot41, align 8
  store i64 %v1539, ptr %slot259, align 8
  %v1540 = load i64, ptr %slot259, align 8
  %v1541 = load i64, ptr %slot256, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1540, i64 %v1541) nomerge, !dbg !132
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1542 = load i64, ptr %slot41, align 8
  store i64 %v1542, ptr %slot260, align 8
  %v1543 = load i64, ptr %slot260, align 8
  %v1544 = load i64, ptr %slot256, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1543, i64 %v1544) nomerge, !dbg !132
  br label %bb_rcslotdone308
bb_rcslotdone308:
  br label %bb_rcprivateprepared278
bb_rcprivateprepared278:
  %v1545 = load i64, ptr %slot9, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %ld1547 = load i32, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1547, ptr %slot261, align 8
  %v1548 = load i32, ptr %slot261, align 8
  %cv1549 = zext i32 %v1548 to i64
  %cond1550 = icmp ne i64 %cv1549, 0
  br i1 %cond1550, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v1551 = load i64, ptr %slot9, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  store i32 0, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  %v1553 = load i64, ptr %slot30, align 8
  store i64 %v1553, ptr %slot262, align 8
  %v1554 = load i64, ptr %slot10, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i32, ptr %p1555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1556, ptr %slot263, align 8
  %v1557 = load i32, ptr %slot263, align 8
  %op1558 = and i32 %v1557, 28
  store i32 %op1558, ptr %slot264, align 8
  %v1559 = load i32, ptr %slot264, align 8
  %cv1560 = zext i32 %v1559 to i64
  %cond1561 = icmp ne i64 %cv1560, 0
  br i1 %cond1561, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v1562 = load i64, ptr %slot41, align 8
  store i64 %v1562, ptr %slot265, align 8
  %v1563 = load i64, ptr %slot265, align 8
  %v1564 = load i64, ptr %slot262, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1563, i64 %v1564) nomerge, !dbg !132
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v1565 = load i64, ptr %slot41, align 8
  store i64 %v1565, ptr %slot266, align 8
  %v1566 = load i64, ptr %slot266, align 8
  %v1567 = load i64, ptr %slot262, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1566, i64 %v1567) nomerge, !dbg !132
  br label %bb_rcslotdone318
bb_rcslotdone318:
  %v1568 = load i64, ptr %slot30, align 8
  store i64 %v1568, ptr %slot267, align 8
  %v1569 = load i64, ptr %slot17, align 8
  store i64 %v1569, ptr %slot268, align 8
  %v1570 = load i64, ptr %slot268, align 8
  %v1571 = load i64, ptr %slot267, align 8
  %p1572 = inttoptr i64 %v1570 to ptr
  %p1573 = inttoptr i64 %v1571 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1573, ptr %p1572, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot13, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 0, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot10, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i32 2, ptr %p1577, align 4, !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot14, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %ld1580 = load i32, ptr %p1579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1580, ptr %slot269, align 8
  %v1581 = load i32, ptr %slot269, align 8
  %v1582 = load i64, ptr %slot10, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i32 %v1581, ptr %p1583, align 4, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot9, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  store i32 1, ptr %p1585, align 4, !alias.scope !3, !noalias !4
  %v1586 = load i64, ptr %slot21, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i64, ptr %p1587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1588, ptr %slot270, align 8
  %v1589 = load i64, ptr %slot270, align 8
  %v1590 = load i64, ptr %slot32, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i64 %v1589, ptr %p1591, align 8, !alias.scope !3, !noalias !4
  %v1592 = load i64, ptr %slot32, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %ld1594 = load i64, ptr %p1593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1594, ptr %slot271, align 8
  %v1595 = load i64, ptr %slot271, align 8
  %op1596 = add i64 %v1595, 0
  store i64 %op1596, ptr %slot272, align 8
  %v1597 = load i64, ptr %slot272, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %ld1599 = load i64, ptr %p1598, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1599, ptr %slot273, align 8
  %v1600 = load i64, ptr %slot273, align 8
  %v1601 = load i64, ptr %slot32, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i64 %v1600, ptr %p1602, align 8, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot11, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i32, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1605, ptr %slot274, align 8
  %v1606 = load i32, ptr %slot274, align 8
  %cv1607 = zext i32 %v1606 to i64
  %cond1608 = icmp ne i64 %cv1607, 0
  br i1 %cond1608, label %bb_rcslotdrop338, label %bb_rcslotdone338
bb_rcslotdrop338:
  %v1609 = load i64, ptr %slot11, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  store i32 0, ptr %p1610, align 4, !alias.scope !3, !noalias !4
  %v1611 = load i64, ptr %slot16, align 8
  store i64 %v1611, ptr %slot275, align 8
  %v1612 = load i64, ptr %slot12, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  %ld1614 = load i32, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1614, ptr %slot276, align 8
  %v1615 = load i32, ptr %slot276, align 8
  %op1616 = and i32 %v1615, 28
  store i32 %op1616, ptr %slot277, align 8
  %v1617 = load i32, ptr %slot277, align 8
  %cv1618 = zext i32 %v1617 to i64
  %cond1619 = icmp ne i64 %cv1618, 0
  br i1 %cond1619, label %bb_rcslotrole338, label %bb_rcslotowner338
bb_rcslotrole338:
  %v1620 = load i64, ptr %slot41, align 8
  store i64 %v1620, ptr %slot278, align 8
  %v1621 = load i64, ptr %slot278, align 8
  %v1622 = load i64, ptr %slot275, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1621, i64 %v1622) nomerge, !dbg !134
  br label %bb_rcslotdone338
bb_rcslotowner338:
  %v1623 = load i64, ptr %slot41, align 8
  store i64 %v1623, ptr %slot279, align 8
  %v1624 = load i64, ptr %slot279, align 8
  %v1625 = load i64, ptr %slot275, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1624, i64 %v1625) nomerge, !dbg !134
  br label %bb_rcslotdone338
bb_rcslotdone338:
  %v1626 = load i64, ptr %slot32, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot280, align 8
  %v1629 = load i64, ptr %slot21, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i64, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1631, ptr %slot281, align 8
  %v1632 = load i64, ptr %slot11, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot282, align 8
  %v1635 = load i32, ptr %slot282, align 8
  %cv1636 = zext i32 %v1635 to i64
  %cond1637 = icmp ne i64 %cv1636, 0
  br i1 %cond1637, label %bb_rcslotdrop350, label %bb_rcslotdone350
bb_rcslotdrop350:
  %v1638 = load i64, ptr %slot11, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 0, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot16, align 8
  store i64 %v1640, ptr %slot283, align 8
  %v1641 = load i64, ptr %slot12, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i32, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1643, ptr %slot284, align 8
  %v1644 = load i32, ptr %slot284, align 8
  %op1645 = and i32 %v1644, 28
  store i32 %op1645, ptr %slot285, align 8
  %v1646 = load i32, ptr %slot285, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcslotrole350, label %bb_rcslotowner350
bb_rcslotrole350:
  %v1649 = load i64, ptr %slot41, align 8
  store i64 %v1649, ptr %slot286, align 8
  %v1650 = load i64, ptr %slot283, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  %ld1652 = load i64, ptr %p1651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1652, ptr %slot287, align 8
  %v1653 = load i64, ptr %slot287, align 8
  %cmp1654 = icmp ne i64 %v1653, 0
  %cv1655 = zext i1 %cmp1654 to i32
  store i32 %cv1655, ptr %slot288, align 8
  %v1656 = load i32, ptr %slot288, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcgnn366, label %bb_rcgdone366
bb_rcgnn366:
  %v1659 = load i64, ptr %slot287, align 8
  %op1660 = sub i64 %v1659, 16
  store i64 %op1660, ptr %slot289, align 8
  %v1661 = load i64, ptr %slot287, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %rgep1663 = getelementptr i8, ptr %p1662, i64 -16
  %ld1664 = load i64, ptr %rgep1663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1664, ptr %slot290, align 8
  %v1665 = load i64, ptr %slot290, align 8
  %op1666 = and i64 %v1665, 4611686018427387906
  store i64 %op1666, ptr %slot291, align 8
  %v1667 = load i64, ptr %slot291, align 8
  %cmp1668 = icmp ne i64 %v1667, 0
  %cv1669 = zext i1 %cmp1668 to i32
  store i32 %cv1669, ptr %slot292, align 8
  %v1670 = load i32, ptr %slot292, align 8
  %cv1671 = zext i32 %v1670 to i64
  %cond1672 = icmp ne i64 %cv1671, 0
  br i1 %cond1672, label %bb_rcgclear366, label %bb_rcgcounted366
bb_rcgcounted366:
  %v1673 = load i64, ptr %slot287, align 8
  %op1674 = sub i64 %v1673, 24
  store i64 %op1674, ptr %slot293, align 8
  %v1675 = load i64, ptr %slot287, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %rgep1677 = getelementptr i8, ptr %p1676, i64 -24
  %ld1678 = load i64, ptr %rgep1677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1678, ptr %slot294, align 8
  %v1679 = load i64, ptr %slot294, align 8
  %op1680 = sub i64 %v1679, 1
  store i64 %op1680, ptr %slot295, align 8
  %v1681 = load i64, ptr %slot295, align 8
  %cmp1682 = icmp eq i64 %v1681, 0
  %cv1683 = zext i1 %cmp1682 to i32
  store i32 %cv1683, ptr %slot296, align 8
  %v1684 = load i32, ptr %slot296, align 8
  %cv1685 = zext i32 %v1684 to i64
  %cond1686 = icmp ne i64 %cv1685, 0
  br i1 %cond1686, label %bb_rcglast366, label %bb_rcgdec366
bb_rcglast366:
  %v1687 = load i64, ptr %slot287, align 8
  %op1688 = sub i64 %v1687, 32
  store i64 %op1688, ptr %slot297, align 8
  %v1689 = load i64, ptr %slot287, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %rgep1691 = getelementptr i8, ptr %p1690, i64 -32
  %ld1692 = load i64, ptr %rgep1691, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1692, ptr %slot298, align 8
  %v1693 = load i64, ptr %slot298, align 8
  %cmp1694 = icmp ne i64 %v1693, 0
  %cv1695 = zext i1 %cmp1694 to i32
  store i32 %cv1695, ptr %slot299, align 8
  %v1696 = load i32, ptr %slot299, align 8
  %cv1697 = zext i32 %v1696 to i64
  %cond1698 = icmp ne i64 %cv1697, 0
  br i1 %cond1698, label %bb_rcgdec366, label %bb_rcgslow366
bb_rcgslow366:
  %v1699 = load i64, ptr %slot286, align 8
  %v1700 = load i64, ptr %slot283, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v1699, i64 %v1700) nomerge, !dbg !136
  br label %bb_rcgdone366
bb_rcgdec366:
  %v1701 = load i64, ptr %slot295, align 8
  %v1702 = load i64, ptr %slot287, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %rgep1704 = getelementptr i8, ptr %p1703, i64 -24
  store i64 %v1701, ptr %rgep1704, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear366
bb_rcgclear366:
  %v1705 = load i64, ptr %slot283, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i64 0, ptr %p1706, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone366
bb_rcgdone366:
  br label %bb_rcslotdone350
bb_rcslotowner350:
  %v1707 = load i64, ptr %slot41, align 8
  store i64 %v1707, ptr %slot300, align 8
  %v1708 = load i64, ptr %slot283, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %ld1710 = load i64, ptr %p1709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1710, ptr %slot301, align 8
  %v1711 = load i64, ptr %slot301, align 8
  %cmp1712 = icmp ne i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot302, align 8
  %v1714 = load i32, ptr %slot302, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcgnn381, label %bb_rcgdone381
bb_rcgnn381:
  %v1717 = load i64, ptr %slot301, align 8
  %op1718 = sub i64 %v1717, 16
  store i64 %op1718, ptr %slot303, align 8
  %v1719 = load i64, ptr %slot301, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %rgep1721 = getelementptr i8, ptr %p1720, i64 -16
  %ld1722 = load i64, ptr %rgep1721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1722, ptr %slot304, align 8
  %v1723 = load i64, ptr %slot304, align 8
  %op1724 = and i64 %v1723, 4611686018427387906
  store i64 %op1724, ptr %slot305, align 8
  %v1725 = load i64, ptr %slot305, align 8
  %cmp1726 = icmp ne i64 %v1725, 0
  %cv1727 = zext i1 %cmp1726 to i32
  store i32 %cv1727, ptr %slot306, align 8
  %v1728 = load i32, ptr %slot306, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcgclear381, label %bb_rcgcounted381
bb_rcgcounted381:
  %v1731 = load i64, ptr %slot301, align 8
  %op1732 = sub i64 %v1731, 32
  store i64 %op1732, ptr %slot307, align 8
  %v1733 = load i64, ptr %slot301, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %rgep1735 = getelementptr i8, ptr %p1734, i64 -32
  %ld1736 = load i64, ptr %rgep1735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1736, ptr %slot308, align 8
  %v1737 = load i64, ptr %slot308, align 8
  %op1738 = sub i64 %v1737, 1
  store i64 %op1738, ptr %slot309, align 8
  %v1739 = load i64, ptr %slot309, align 8
  %cmp1740 = icmp eq i64 %v1739, 0
  %cv1741 = zext i1 %cmp1740 to i32
  store i32 %cv1741, ptr %slot310, align 8
  %v1742 = load i32, ptr %slot310, align 8
  %cv1743 = zext i32 %v1742 to i64
  %cond1744 = icmp ne i64 %cv1743, 0
  br i1 %cond1744, label %bb_rcglast381, label %bb_rcgdec381
bb_rcglast381:
  %v1745 = load i64, ptr %slot301, align 8
  %op1746 = sub i64 %v1745, 24
  store i64 %op1746, ptr %slot311, align 8
  %v1747 = load i64, ptr %slot301, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  %rgep1749 = getelementptr i8, ptr %p1748, i64 -24
  %ld1750 = load i64, ptr %rgep1749, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1750, ptr %slot312, align 8
  %v1751 = load i64, ptr %slot312, align 8
  %cmp1752 = icmp ne i64 %v1751, 0
  %cv1753 = zext i1 %cmp1752 to i32
  store i32 %cv1753, ptr %slot313, align 8
  %v1754 = load i32, ptr %slot313, align 8
  %cv1755 = zext i32 %v1754 to i64
  %cond1756 = icmp ne i64 %cv1755, 0
  br i1 %cond1756, label %bb_rcgdec381, label %bb_rcgslow381
bb_rcgslow381:
  %v1757 = load i64, ptr %slot300, align 8
  %v1758 = load i64, ptr %slot283, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v1757, i64 %v1758) nomerge, !dbg !136
  br label %bb_rcgdone381
bb_rcgdec381:
  %v1759 = load i64, ptr %slot309, align 8
  %v1760 = load i64, ptr %slot301, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %rgep1762 = getelementptr i8, ptr %p1761, i64 -32
  store i64 %v1759, ptr %rgep1762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear381
bb_rcgclear381:
  %v1763 = load i64, ptr %slot283, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  store i64 0, ptr %p1764, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone381
bb_rcgdone381:
  br label %bb_rcslotdone350
bb_rcslotdone350:
  %v1765 = load i64, ptr %slot281, align 8
  %op1766 = add i64 %v1765, 0
  store i64 %op1766, ptr %slot314, align 8
  store i64 0, ptr %slot315, align 8
  %v1767 = load i64, ptr %slot314, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %ld1769 = load i64, ptr %p1768, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1769, ptr %slot316, align 8
  %v1770 = load i64, ptr %slot316, align 8
  %cmp1771 = icmp ne i64 %v1770, 0
  %cv1772 = zext i1 %cmp1771 to i32
  store i32 %cv1772, ptr %slot317, align 8
  %v1773 = load i32, ptr %slot317, align 8
  %cv1774 = zext i32 %v1773 to i64
  %cond1775 = icmp ne i64 %cv1774, 0
  br i1 %cond1775, label %bb_rcguniquenn387, label %bb_rcgunique387
bb_rcguniquenn387:
  %v1776 = load i64, ptr %slot316, align 8
  %op1777 = sub i64 %v1776, 16
  store i64 %op1777, ptr %slot318, align 8
  %v1778 = load i64, ptr %slot316, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %rgep1780 = getelementptr i8, ptr %p1779, i64 -16
  %ld1781 = load i64, ptr %rgep1780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1781, ptr %slot319, align 8
  %v1782 = load i64, ptr %slot319, align 8
  %op1783 = and i64 %v1782, 6917529027641081858
  store i64 %op1783, ptr %slot320, align 8
  %v1784 = load i64, ptr %slot320, align 8
  %cmp1785 = icmp ne i64 %v1784, 0
  %cv1786 = zext i1 %cmp1785 to i32
  store i32 %cv1786, ptr %slot321, align 8
  %v1787 = load i32, ptr %slot321, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rcguniqueslow387, label %bb_rcguniquecount387
bb_rcguniquecount387:
  %v1790 = load i64, ptr %slot316, align 8
  %op1791 = sub i64 %v1790, 32
  store i64 %op1791, ptr %slot322, align 8
  %v1792 = load i64, ptr %slot316, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %rgep1794 = getelementptr i8, ptr %p1793, i64 -32
  %ld1795 = load i64, ptr %rgep1794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1795, ptr %slot323, align 8
  %v1796 = load i64, ptr %slot323, align 8
  %cmp1797 = icmp ult i64 %v1796, 2
  %cv1798 = zext i1 %cmp1797 to i32
  store i32 %cv1798, ptr %slot324, align 8
  %v1799 = load i32, ptr %slot324, align 8
  %cv1800 = zext i32 %v1799 to i64
  %cond1801 = icmp ne i64 %cv1800, 0
  br i1 %cond1801, label %bb_rcgunique387, label %bb_rcguniqueslow387
bb_rcguniqueslow387:
  %v1802 = load i64, ptr %slot1, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  %p1804 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v1805 = load i64, ptr %slot314, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  %v1807 = load i64, ptr %slot315, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %call1809 = call i32 @myl_qbe_rc_unique_field(ptr %p1803, ptr %p1804, ptr %p1806, ptr %p1808) nomerge, !dbg !136
  store i32 %call1809, ptr %slot325, align 8
  %v1810 = load i32, ptr %slot325, align 8
  %cv1811 = zext i32 %v1810 to i64
  %cond1812 = icmp ne i64 %cv1811, 0
  br i1 %cond1812, label %bb_rcunique397, label %bb_failure
bb_rcunique397:
  br label %bb_rcgunique387
bb_rcgunique387:
  %v1813 = load i64, ptr %slot314, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %ld1815 = load i64, ptr %p1814, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1815, ptr %slot326, align 8
  %v1816 = load i64, ptr %slot326, align 8
  %v1817 = load i64, ptr %slot32, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i64 %v1816, ptr %p1818, align 8, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot32, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  %ld1821 = load i64, ptr %p1820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1821, ptr %slot327, align 8
  %v1822 = load i64, ptr %slot11, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i32, ptr %p1823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1824, ptr %slot328, align 8
  %v1825 = load i32, ptr %slot328, align 8
  %cv1826 = zext i32 %v1825 to i64
  %cond1827 = icmp ne i64 %cv1826, 0
  br i1 %cond1827, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v1828 = load i64, ptr %slot11, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i32 0, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot16, align 8
  store i64 %v1830, ptr %slot329, align 8
  %v1831 = load i64, ptr %slot12, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  %ld1833 = load i32, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1833, ptr %slot330, align 8
  %v1834 = load i32, ptr %slot330, align 8
  %op1835 = and i32 %v1834, 28
  store i32 %op1835, ptr %slot331, align 8
  %v1836 = load i32, ptr %slot331, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v1839 = load i64, ptr %slot41, align 8
  store i64 %v1839, ptr %slot332, align 8
  %v1840 = load i64, ptr %slot329, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %ld1842 = load i64, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1842, ptr %slot333, align 8
  %v1843 = load i64, ptr %slot333, align 8
  %cmp1844 = icmp ne i64 %v1843, 0
  %cv1845 = zext i1 %cmp1844 to i32
  store i32 %cv1845, ptr %slot334, align 8
  %v1846 = load i32, ptr %slot334, align 8
  %cv1847 = zext i32 %v1846 to i64
  %cond1848 = icmp ne i64 %cv1847, 0
  br i1 %cond1848, label %bb_rcgnn418, label %bb_rcgdone418
bb_rcgnn418:
  %v1849 = load i64, ptr %slot333, align 8
  %op1850 = sub i64 %v1849, 16
  store i64 %op1850, ptr %slot335, align 8
  %v1851 = load i64, ptr %slot333, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  %rgep1853 = getelementptr i8, ptr %p1852, i64 -16
  %ld1854 = load i64, ptr %rgep1853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1854, ptr %slot336, align 8
  %v1855 = load i64, ptr %slot336, align 8
  %op1856 = and i64 %v1855, 4611686018427387906
  store i64 %op1856, ptr %slot337, align 8
  %v1857 = load i64, ptr %slot337, align 8
  %cmp1858 = icmp ne i64 %v1857, 0
  %cv1859 = zext i1 %cmp1858 to i32
  store i32 %cv1859, ptr %slot338, align 8
  %v1860 = load i32, ptr %slot338, align 8
  %cv1861 = zext i32 %v1860 to i64
  %cond1862 = icmp ne i64 %cv1861, 0
  br i1 %cond1862, label %bb_rcgclear418, label %bb_rcgcounted418
bb_rcgcounted418:
  %v1863 = load i64, ptr %slot333, align 8
  %op1864 = sub i64 %v1863, 24
  store i64 %op1864, ptr %slot339, align 8
  %v1865 = load i64, ptr %slot333, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %rgep1867 = getelementptr i8, ptr %p1866, i64 -24
  %ld1868 = load i64, ptr %rgep1867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1868, ptr %slot340, align 8
  %v1869 = load i64, ptr %slot340, align 8
  %op1870 = sub i64 %v1869, 1
  store i64 %op1870, ptr %slot341, align 8
  %v1871 = load i64, ptr %slot341, align 8
  %cmp1872 = icmp eq i64 %v1871, 0
  %cv1873 = zext i1 %cmp1872 to i32
  store i32 %cv1873, ptr %slot342, align 8
  %v1874 = load i32, ptr %slot342, align 8
  %cv1875 = zext i32 %v1874 to i64
  %cond1876 = icmp ne i64 %cv1875, 0
  br i1 %cond1876, label %bb_rcglast418, label %bb_rcgdec418
bb_rcglast418:
  %v1877 = load i64, ptr %slot333, align 8
  %op1878 = sub i64 %v1877, 32
  store i64 %op1878, ptr %slot343, align 8
  %v1879 = load i64, ptr %slot333, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  %rgep1881 = getelementptr i8, ptr %p1880, i64 -32
  %ld1882 = load i64, ptr %rgep1881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1882, ptr %slot344, align 8
  %v1883 = load i64, ptr %slot344, align 8
  %cmp1884 = icmp ne i64 %v1883, 0
  %cv1885 = zext i1 %cmp1884 to i32
  store i32 %cv1885, ptr %slot345, align 8
  %v1886 = load i32, ptr %slot345, align 8
  %cv1887 = zext i32 %v1886 to i64
  %cond1888 = icmp ne i64 %cv1887, 0
  br i1 %cond1888, label %bb_rcgdec418, label %bb_rcgslow418
bb_rcgslow418:
  %v1889 = load i64, ptr %slot332, align 8
  %v1890 = load i64, ptr %slot329, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v1889, i64 %v1890) nomerge, !dbg !136
  br label %bb_rcgdone418
bb_rcgdec418:
  %v1891 = load i64, ptr %slot341, align 8
  %v1892 = load i64, ptr %slot333, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  %rgep1894 = getelementptr i8, ptr %p1893, i64 -24
  store i64 %v1891, ptr %rgep1894, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear418
bb_rcgclear418:
  %v1895 = load i64, ptr %slot329, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i64 0, ptr %p1896, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone418
bb_rcgdone418:
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v1897 = load i64, ptr %slot41, align 8
  store i64 %v1897, ptr %slot346, align 8
  %v1898 = load i64, ptr %slot329, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %ld1900 = load i64, ptr %p1899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1900, ptr %slot347, align 8
  %v1901 = load i64, ptr %slot347, align 8
  %cmp1902 = icmp ne i64 %v1901, 0
  %cv1903 = zext i1 %cmp1902 to i32
  store i32 %cv1903, ptr %slot348, align 8
  %v1904 = load i32, ptr %slot348, align 8
  %cv1905 = zext i32 %v1904 to i64
  %cond1906 = icmp ne i64 %cv1905, 0
  br i1 %cond1906, label %bb_rcgnn433, label %bb_rcgdone433
bb_rcgnn433:
  %v1907 = load i64, ptr %slot347, align 8
  %op1908 = sub i64 %v1907, 16
  store i64 %op1908, ptr %slot349, align 8
  %v1909 = load i64, ptr %slot347, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  %rgep1911 = getelementptr i8, ptr %p1910, i64 -16
  %ld1912 = load i64, ptr %rgep1911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1912, ptr %slot350, align 8
  %v1913 = load i64, ptr %slot350, align 8
  %op1914 = and i64 %v1913, 4611686018427387906
  store i64 %op1914, ptr %slot351, align 8
  %v1915 = load i64, ptr %slot351, align 8
  %cmp1916 = icmp ne i64 %v1915, 0
  %cv1917 = zext i1 %cmp1916 to i32
  store i32 %cv1917, ptr %slot352, align 8
  %v1918 = load i32, ptr %slot352, align 8
  %cv1919 = zext i32 %v1918 to i64
  %cond1920 = icmp ne i64 %cv1919, 0
  br i1 %cond1920, label %bb_rcgclear433, label %bb_rcgcounted433
bb_rcgcounted433:
  %v1921 = load i64, ptr %slot347, align 8
  %op1922 = sub i64 %v1921, 32
  store i64 %op1922, ptr %slot353, align 8
  %v1923 = load i64, ptr %slot347, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  %rgep1925 = getelementptr i8, ptr %p1924, i64 -32
  %ld1926 = load i64, ptr %rgep1925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1926, ptr %slot354, align 8
  %v1927 = load i64, ptr %slot354, align 8
  %op1928 = sub i64 %v1927, 1
  store i64 %op1928, ptr %slot355, align 8
  %v1929 = load i64, ptr %slot355, align 8
  %cmp1930 = icmp eq i64 %v1929, 0
  %cv1931 = zext i1 %cmp1930 to i32
  store i32 %cv1931, ptr %slot356, align 8
  %v1932 = load i32, ptr %slot356, align 8
  %cv1933 = zext i32 %v1932 to i64
  %cond1934 = icmp ne i64 %cv1933, 0
  br i1 %cond1934, label %bb_rcglast433, label %bb_rcgdec433
bb_rcglast433:
  %v1935 = load i64, ptr %slot347, align 8
  %op1936 = sub i64 %v1935, 24
  store i64 %op1936, ptr %slot357, align 8
  %v1937 = load i64, ptr %slot347, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %rgep1939 = getelementptr i8, ptr %p1938, i64 -24
  %ld1940 = load i64, ptr %rgep1939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1940, ptr %slot358, align 8
  %v1941 = load i64, ptr %slot358, align 8
  %cmp1942 = icmp ne i64 %v1941, 0
  %cv1943 = zext i1 %cmp1942 to i32
  store i32 %cv1943, ptr %slot359, align 8
  %v1944 = load i32, ptr %slot359, align 8
  %cv1945 = zext i32 %v1944 to i64
  %cond1946 = icmp ne i64 %cv1945, 0
  br i1 %cond1946, label %bb_rcgdec433, label %bb_rcgslow433
bb_rcgslow433:
  %v1947 = load i64, ptr %slot346, align 8
  %v1948 = load i64, ptr %slot329, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v1947, i64 %v1948) nomerge, !dbg !136
  br label %bb_rcgdone433
bb_rcgdec433:
  %v1949 = load i64, ptr %slot355, align 8
  %v1950 = load i64, ptr %slot347, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %rgep1952 = getelementptr i8, ptr %p1951, i64 -32
  store i64 %v1949, ptr %rgep1952, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear433
bb_rcgclear433:
  %v1953 = load i64, ptr %slot329, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 0, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone433
bb_rcgdone433:
  br label %bb_rcslotdone402
bb_rcslotdone402:
  %v1955 = load i64, ptr %slot327, align 8
  %v1956 = load i64, ptr %slot29, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  store i64 %v1955, ptr %p1957, align 8, !alias.scope !3, !noalias !4
  %v1958 = load i64, ptr %slot22, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %ld1960 = load i64, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1960, ptr %slot360, align 8
  %v1961 = load i64, ptr %slot360, align 8
  %v1962 = load i64, ptr %slot32, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  store i64 %v1961, ptr %p1963, align 8, !alias.scope !3, !noalias !4
  %v1964 = load i64, ptr %slot32, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1966, ptr %slot361, align 8
  %v1967 = load i64, ptr %slot361, align 8
  %v1968 = load i64, ptr %slot31, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  store i64 %v1967, ptr %p1969, align 8, !alias.scope !3, !noalias !4
  %v1970 = load i64, ptr %slot31, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  %ld1972 = load i64, ptr %p1971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1972, ptr %slot362, align 8
  %v1973 = load i64, ptr %slot362, align 8
  %v1974 = load i64, ptr %slot32, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i64 %v1973, ptr %p1975, align 8, !alias.scope !3, !noalias !4
  %v1976 = load i64, ptr %slot33, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  store i64 0, ptr %p1977, align 8, !alias.scope !3, !noalias !4
  %v1978 = load i64, ptr %slot33, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  %ld1980 = load i64, ptr %p1979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1980, ptr %slot363, align 8
  %v1981 = load i64, ptr %slot32, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %ld1983 = load i64, ptr %p1982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1983, ptr %slot364, align 8
  %v1984 = load i64, ptr %slot364, align 8
  %v1985 = load i64, ptr %slot363, align 8
  %cmp1986 = icmp slt i64 %v1984, %v1985
  %cv1987 = zext i1 %cmp1986 to i64
  store i64 %cv1987, ptr %slot365, align 8
  %v1988 = load i64, ptr %slot365, align 8
  %v1989 = load i64, ptr %slot32, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i64 %v1988, ptr %p1990, align 8, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot32, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i64, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1993, ptr %slot366, align 8
  %v1994 = load i64, ptr %slot366, align 8
  %cond1995 = icmp ne i64 %v1994, 0
  br i1 %cond1995, label %bb_next481, label %bb_i42
bb_next481:
  %v1996 = load i64, ptr %slot29, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot367, align 8
  %v1999 = load i64, ptr %slot367, align 8
  %op2000 = add i64 %v1999, 0
  store i64 %op2000, ptr %slot368, align 8
  %v2001 = load i64, ptr %slot368, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %ld2003 = load i64, ptr %p2002, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2003, ptr %slot369, align 8
  %v2004 = load i64, ptr %slot369, align 8
  %v2005 = load i64, ptr %slot32, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i64 %v2004, ptr %p2006, align 8, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot32, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %ld2009 = load i64, ptr %p2008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2009, ptr %slot370, align 8
  %v2010 = load i64, ptr %slot370, align 8
  %cmp2011 = icmp ugt i64 %v2010, 9223372036854775807
  %cv2012 = zext i1 %cmp2011 to i64
  store i64 %cv2012, ptr %slot371, align 8
  %v2013 = load i64, ptr %slot371, align 8
  %cond2014 = icmp ne i64 %v2013, 0
  br i1 %cond2014, label %bb_cast_overflow486, label %bb_cast_ok486
bb_cast_overflow486:
  %v2015 = load i64, ptr %slot1, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  %v2017 = load i64, ptr %slot370, align 8
  call void @myl_qbe_fail_cast(ptr %p2016, i64 %v2017, i64 320) nomerge, !dbg !138
  unreachable
bb_cast_ok486:
  %v2018 = load i64, ptr %slot370, align 8
  %v2019 = load i64, ptr %slot32, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i64 %v2018, ptr %p2020, align 8, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot31, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i64, ptr %p2022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2023, ptr %slot372, align 8
  %v2024 = load i64, ptr %slot372, align 8
  %v2025 = load i64, ptr %slot33, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  store i64 %v2024, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  %v2027 = load i64, ptr %slot33, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %ld2029 = load i64, ptr %p2028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2029, ptr %slot373, align 8
  %v2030 = load i64, ptr %slot32, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i64, ptr %p2031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2032, ptr %slot374, align 8
  %v2033 = load i64, ptr %slot374, align 8
  %v2034 = load i64, ptr %slot373, align 8
  %ovpair2036 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2033, i64 %v2034)
  %op2035 = extractvalue { i64, i1 } %ovpair2036, 0
  %ov2037 = extractvalue { i64, i1 } %ovpair2036, 1
  store i64 %op2035, ptr %slot375, align 8
  %v2038 = load i64, ptr %slot374, align 8
  %v2039 = load i64, ptr %slot375, align 8
  %op2040 = xor i64 %v2038, %v2039
  store i64 %op2040, ptr %slot376, align 8
  %v2041 = load i64, ptr %slot373, align 8
  %v2042 = load i64, ptr %slot375, align 8
  %op2043 = xor i64 %v2041, %v2042
  store i64 %op2043, ptr %slot377, align 8
  %v2044 = load i64, ptr %slot376, align 8
  %v2045 = load i64, ptr %slot377, align 8
  %op2046 = and i64 %v2044, %v2045
  store i64 %op2046, ptr %slot378, align 8
  %cv2047 = zext i1 %ov2037 to i64
  store i64 %cv2047, ptr %slot379, align 8
  %v2048 = load i64, ptr %slot379, align 8
  %cond2049 = icmp ne i64 %v2048, 0
  br i1 %cond2049, label %bb_overflow490, label %bb_checked490
bb_overflow490:
  %v2050 = load i64, ptr %slot1, align 8
  %p2051 = inttoptr i64 %v2050 to ptr
  %v2052 = load i64, ptr %slot374, align 8
  %v2053 = load i64, ptr %slot373, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2051, i64 0, i64 %v2052, i64 %v2053, i64 64) nomerge, !dbg !140
  unreachable
bb_checked490:
  %v2054 = load i64, ptr %slot375, align 8
  %v2055 = load i64, ptr %slot32, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 %v2054, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot32, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i64, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2059, ptr %slot380, align 8
  %v2060 = load i64, ptr %slot380, align 8
  %v2061 = load i64, ptr %slot31, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i64 %v2060, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  %v2063 = load i64, ptr %slot31, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %ld2065 = load i64, ptr %p2064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2065, ptr %slot381, align 8
  %v2066 = load i64, ptr %slot381, align 8
  %v2067 = load i64, ptr %slot32, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  store i64 %v2066, ptr %p2068, align 8, !alias.scope !3, !noalias !4
  %v2069 = load i64, ptr %slot30, align 8
  %v2070 = load i64, ptr %slot36, align 8
  %p2071 = inttoptr i64 %v2069 to ptr
  %p2072 = inttoptr i64 %v2070 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2072, ptr %p2071, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2073 = load i64, ptr %slot36, align 8
  %v2074 = load i64, ptr %slot33, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i64 %v2073, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot29, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %ld2078 = load i64, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2078, ptr %slot382, align 8
  %v2079 = load i64, ptr %slot33, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %ld2081 = load i64, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2081, ptr %slot383, align 8
  %v2082 = load i64, ptr %slot32, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  %ld2084 = load i64, ptr %p2083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2084, ptr %slot384, align 8
  %v2085 = load i64, ptr %slot382, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i64, ptr %p2086, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2087, ptr %slot385, align 8
  %v2088 = load i64, ptr %slot384, align 8
  %v2089 = load i64, ptr %slot385, align 8
  %cmp2090 = icmp ult i64 %v2088, %v2089
  %cv2091 = zext i1 %cmp2090 to i64
  store i64 %cv2091, ptr %slot386, align 8
  %v2092 = load i64, ptr %slot386, align 8
  %cond2093 = icmp ne i64 %v2092, 0
  br i1 %cond2093, label %bb_success503, label %bb_failed503
bb_failed503:
  %v2094 = load i64, ptr %slot1, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %v2096 = load i64, ptr %slot384, align 8
  %v2097 = load i64, ptr %slot385, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2095, i64 %v2096, i64 %v2097) nomerge, !dbg !142
  unreachable
bb_success503:
  %v2098 = load i64, ptr %slot33, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i64, ptr %p2099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2100, ptr %slot387, align 8
  %v2101 = load i64, ptr %slot41, align 8
  %v2102 = load i64, ptr %slot382, align 8
  %v2103 = load i64, ptr %slot384, align 8
  %v2104 = load i64, ptr %slot387, align 8
  %call2105 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v2101, i64 %v2102, i64 %v2103, i64 %v2104) nomerge, !dbg !142
  store i32 %call2105, ptr %slot388, align 8
  %v2106 = load i32, ptr %slot388, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_success506, label %bb_failed506
bb_failed506:
  %v2109 = load i64, ptr %slot1, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2110) nomerge, !dbg !142
  unreachable
bb_success506:
  %v2111 = load i64, ptr %slot32, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i64 0, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot32, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  store i64 0, ptr %p2114, align 8, !alias.scope !3, !noalias !4
  %v2115 = load i64, ptr %slot32, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %ld2117 = load i64, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2117, ptr %slot389, align 8
  %v2118 = load i64, ptr %slot18, align 8
  %p2120 = inttoptr i64 %v2118 to ptr
  %gep2121 = getelementptr i8, ptr %p2120, i64 24
  %op2119 = ptrtoint ptr %gep2121 to i64
  store i64 %op2119, ptr %slot390, align 8
  %v2122 = load i64, ptr %slot390, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i32, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2124, ptr %slot391, align 8
  %v2125 = load i32, ptr %slot391, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcscopesopen519, label %bb_rcscopesclosed519
bb_rcscopesopen519:
  %v2128 = load i64, ptr %slot20, align 8
  %p2130 = inttoptr i64 %v2128 to ptr
  %gep2131 = getelementptr i8, ptr %p2130, i64 0
  %op2129 = ptrtoint ptr %gep2131 to i64
  store i64 %op2129, ptr %slot392, align 8
  %v2132 = load i64, ptr %slot18, align 8
  %v2133 = load i64, ptr %slot392, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  store i64 %v2132, ptr %p2134, align 8, !alias.scope !3, !noalias !4
  %v2135 = load i64, ptr %slot1, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  %v2137 = load i64, ptr %slot20, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2136, ptr %p2138, i64 1) nomerge, !dbg !144
  br label %bb_rcscopesclosed519
bb_rcscopesclosed519:
  %v2139 = load i64, ptr %slot11, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  %ld2141 = load i32, ptr %p2140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2141, ptr %slot393, align 8
  %v2142 = load i32, ptr %slot393, align 8
  %cv2143 = zext i32 %v2142 to i64
  %cond2144 = icmp ne i64 %cv2143, 0
  br i1 %cond2144, label %bb_rcslotdrop523, label %bb_rcslotdone523
bb_rcslotdrop523:
  %v2145 = load i64, ptr %slot11, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  store i32 0, ptr %p2146, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone523
bb_rcslotdone523:
  %v2147 = load i64, ptr %slot9, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i32, ptr %p2148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2149, ptr %slot394, align 8
  %v2150 = load i32, ptr %slot394, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rcslotdrop526, label %bb_rcslotdone526
bb_rcslotdrop526:
  %v2153 = load i64, ptr %slot9, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  store i32 0, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  %v2155 = load i64, ptr %slot30, align 8
  store i64 %v2155, ptr %slot395, align 8
  %v2156 = load i64, ptr %slot10, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %ld2158 = load i32, ptr %p2157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2158, ptr %slot396, align 8
  %v2159 = load i32, ptr %slot396, align 8
  %op2160 = and i32 %v2159, 28
  store i32 %op2160, ptr %slot397, align 8
  %v2161 = load i32, ptr %slot397, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcslotrole526, label %bb_rcslotowner526
bb_rcslotrole526:
  %v2164 = load i64, ptr %slot41, align 8
  store i64 %v2164, ptr %slot398, align 8
  %v2165 = load i64, ptr %slot398, align 8
  %v2166 = load i64, ptr %slot395, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2165, i64 %v2166) nomerge, !dbg !144
  br label %bb_rcslotdone526
bb_rcslotowner526:
  %v2167 = load i64, ptr %slot41, align 8
  store i64 %v2167, ptr %slot399, align 8
  %v2168 = load i64, ptr %slot399, align 8
  %v2169 = load i64, ptr %slot395, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2168, i64 %v2169) nomerge, !dbg !144
  br label %bb_rcslotdone526
bb_rcslotdone526:
  %v2170 = load i64, ptr %slot7, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %ld2172 = load i32, ptr %p2171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2172, ptr %slot400, align 8
  %v2173 = load i32, ptr %slot400, align 8
  %cv2174 = zext i32 %v2173 to i64
  %cond2175 = icmp ne i64 %cv2174, 0
  br i1 %cond2175, label %bb_rcslotdrop572, label %bb_rcslotdone572
bb_rcslotdrop572:
  %v2176 = load i64, ptr %slot7, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  store i32 0, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  %v2178 = load i64, ptr %slot25, align 8
  store i64 %v2178, ptr %slot401, align 8
  %v2179 = load i64, ptr %slot8, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %ld2181 = load i32, ptr %p2180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2181, ptr %slot402, align 8
  %v2182 = load i32, ptr %slot402, align 8
  %op2183 = and i32 %v2182, 28
  store i32 %op2183, ptr %slot403, align 8
  %v2184 = load i32, ptr %slot403, align 8
  %cv2185 = zext i32 %v2184 to i64
  %cond2186 = icmp ne i64 %cv2185, 0
  br i1 %cond2186, label %bb_rcslotrole572, label %bb_rcslotowner572
bb_rcslotrole572:
  %v2187 = load i64, ptr %slot41, align 8
  store i64 %v2187, ptr %slot404, align 8
  %v2188 = load i64, ptr %slot404, align 8
  %v2189 = load i64, ptr %slot401, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2188, i64 %v2189) nomerge, !dbg !144
  br label %bb_rcslotdone572
bb_rcslotowner572:
  %v2190 = load i64, ptr %slot41, align 8
  store i64 %v2190, ptr %slot405, align 8
  %v2191 = load i64, ptr %slot405, align 8
  %v2192 = load i64, ptr %slot401, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2191, i64 %v2192) nomerge, !dbg !144
  br label %bb_rcslotdone572
bb_rcslotdone572:
  %v2193 = load i64, ptr %slot389, align 8
  ret i64 %v2193
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0(i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64, i64)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64, i64, i64, i32)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 16v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!10000001 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888", linkageName: "myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14340150561881314835, i64 0, !"myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!124 = !DILocation(line: 19, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!136 = !DILocation(line: 31, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!140 = !DILocation(line: 41, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!142 = !DILocation(line: 46, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!144 = !DILocation(line: 49, column: 0, scope: !145)
