target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %callresult69 = alloca [24 x i8], align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %callresult189 = alloca [16 x i8], align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %callresult199 = alloca [32 x i8], align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %callresult300 = alloca [24 x i8], align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %callresult406 = alloca [24 x i8], align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %callresult449 = alloca [24 x i8], align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %callresult478 = alloca [16 x i8], align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %callresult808 = alloca [16 x i8], align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %callresult959 = alloca [16 x i8], align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1081 = load i64, ptr %slot1, align 8
  %op1082 = add i64 %v1081, 32
  store i64 %op1082, ptr %slot4, align 8
  %mem1083 = alloca i8, i64 24, align 8
  %ptr1084 = ptrtoint ptr %mem1083 to i64
  store i64 %ptr1084, ptr %slot5, align 8
  %mem1085 = alloca i8, i64 8, align 8
  %ptr1086 = ptrtoint ptr %mem1085 to i64
  store i64 %ptr1086, ptr %slot6, align 8
  %mem1087 = alloca i8, i64 8, align 8
  %ptr1088 = ptrtoint ptr %mem1087 to i64
  store i64 %ptr1088, ptr %slot7, align 8
  %mem1089 = alloca i8, i64 8, align 8
  %ptr1090 = ptrtoint ptr %mem1089 to i64
  store i64 %ptr1090, ptr %slot8, align 8
  %mem1091 = alloca i8, i64 8, align 8
  %ptr1092 = ptrtoint ptr %mem1091 to i64
  store i64 %ptr1092, ptr %slot9, align 8
  %mem1093 = alloca i8, i64 8, align 8
  %ptr1094 = ptrtoint ptr %mem1093 to i64
  store i64 %ptr1094, ptr %slot10, align 8
  %mem1095 = alloca i8, i64 8, align 8
  %ptr1096 = ptrtoint ptr %mem1095 to i64
  store i64 %ptr1096, ptr %slot11, align 8
  %mem1097 = alloca i8, i64 8, align 8
  %ptr1098 = ptrtoint ptr %mem1097 to i64
  store i64 %ptr1098, ptr %slot12, align 8
  %mem1099 = alloca i8, i64 8, align 8
  %ptr1100 = ptrtoint ptr %mem1099 to i64
  store i64 %ptr1100, ptr %slot13, align 8
  %mem1101 = alloca i8, i64 8, align 8
  %ptr1102 = ptrtoint ptr %mem1101 to i64
  store i64 %ptr1102, ptr %slot14, align 8
  %mem1103 = alloca i8, i64 8, align 8
  %ptr1104 = ptrtoint ptr %mem1103 to i64
  store i64 %ptr1104, ptr %slot15, align 8
  %mem1105 = alloca i8, i64 8, align 8
  %ptr1106 = ptrtoint ptr %mem1105 to i64
  store i64 %ptr1106, ptr %slot16, align 8
  %mem1107 = alloca i8, i64 8, align 8
  %ptr1108 = ptrtoint ptr %mem1107 to i64
  store i64 %ptr1108, ptr %slot17, align 8
  %mem1109 = alloca i8, i64 8, align 8
  %ptr1110 = ptrtoint ptr %mem1109 to i64
  store i64 %ptr1110, ptr %slot18, align 8
  %mem1111 = alloca i8, i64 8, align 8
  %ptr1112 = ptrtoint ptr %mem1111 to i64
  store i64 %ptr1112, ptr %slot19, align 8
  %mem1113 = alloca i8, i64 8, align 8
  %ptr1114 = ptrtoint ptr %mem1113 to i64
  store i64 %ptr1114, ptr %slot20, align 8
  %mem1115 = alloca i8, i64 304, align 8
  %ptr1116 = ptrtoint ptr %mem1115 to i64
  store i64 %ptr1116, ptr %slot21, align 8
  %mem1117 = alloca i8, i64 304, align 8
  %ptr1118 = ptrtoint ptr %mem1117 to i64
  store i64 %ptr1118, ptr %slot22, align 8
  %mem1119 = alloca i8, i64 8, align 8
  %ptr1120 = ptrtoint ptr %mem1119 to i64
  store i64 %ptr1120, ptr %slot23, align 8
  %mem1121 = alloca i8, i64 8, align 8
  %ptr1122 = ptrtoint ptr %mem1121 to i64
  store i64 %ptr1122, ptr %slot24, align 8
  %mem1123 = alloca i8, i64 304, align 8
  %ptr1124 = ptrtoint ptr %mem1123 to i64
  store i64 %ptr1124, ptr %slot25, align 8
  %mem1125 = alloca i8, i64 8, align 8
  %ptr1126 = ptrtoint ptr %mem1125 to i64
  store i64 %ptr1126, ptr %slot26, align 8
  %mem1127 = alloca i8, i64 8, align 8
  %ptr1128 = ptrtoint ptr %mem1127 to i64
  store i64 %ptr1128, ptr %slot27, align 8
  %mem1129 = alloca i8, i64 24, align 8
  %ptr1130 = ptrtoint ptr %mem1129 to i64
  store i64 %ptr1130, ptr %slot28, align 8
  %mem1131 = alloca i8, i64 8, align 8
  %ptr1132 = ptrtoint ptr %mem1131 to i64
  store i64 %ptr1132, ptr %slot29, align 8
  %mem1133 = alloca i8, i64 16, align 8
  %ptr1134 = ptrtoint ptr %mem1133 to i64
  store i64 %ptr1134, ptr %slot30, align 8
  %mem1135 = alloca i8, i64 208, align 8
  %ptr1136 = ptrtoint ptr %mem1135 to i64
  store i64 %ptr1136, ptr %slot31, align 8
  %mem1137 = alloca i8, i64 16, align 8
  %ptr1138 = ptrtoint ptr %mem1137 to i64
  store i64 %ptr1138, ptr %slot32, align 8
  %mem1139 = alloca i8, i64 208, align 8
  %ptr1140 = ptrtoint ptr %mem1139 to i64
  store i64 %ptr1140, ptr %slot33, align 8
  %mem1141 = alloca i8, i64 8, align 8
  %ptr1142 = ptrtoint ptr %mem1141 to i64
  store i64 %ptr1142, ptr %slot34, align 8
  %mem1143 = alloca i8, i64 208, align 8
  %ptr1144 = ptrtoint ptr %mem1143 to i64
  store i64 %ptr1144, ptr %slot35, align 8
  %mem1145 = alloca i8, i64 8, align 8
  %ptr1146 = ptrtoint ptr %mem1145 to i64
  store i64 %ptr1146, ptr %slot36, align 8
  %mem1147 = alloca i8, i64 8, align 8
  %ptr1148 = ptrtoint ptr %mem1147 to i64
  store i64 %ptr1148, ptr %slot37, align 8
  %mem1149 = alloca i8, i64 8, align 8
  %ptr1150 = ptrtoint ptr %mem1149 to i64
  store i64 %ptr1150, ptr %slot38, align 8
  %mem1151 = alloca i8, i64 24, align 8
  %ptr1152 = ptrtoint ptr %mem1151 to i64
  store i64 %ptr1152, ptr %slot39, align 8
  %mem1153 = alloca i8, i64 304, align 8
  %ptr1154 = ptrtoint ptr %mem1153 to i64
  store i64 %ptr1154, ptr %slot40, align 8
  %mem1155 = alloca i8, i64 24, align 8
  %ptr1156 = ptrtoint ptr %mem1155 to i64
  store i64 %ptr1156, ptr %slot41, align 8
  %mem1157 = alloca i8, i64 304, align 8
  %ptr1158 = ptrtoint ptr %mem1157 to i64
  store i64 %ptr1158, ptr %slot42, align 8
  %mem1159 = alloca i8, i64 208, align 8
  %ptr1160 = ptrtoint ptr %mem1159 to i64
  store i64 %ptr1160, ptr %slot43, align 8
  %mem1161 = alloca i8, i64 304, align 8
  %ptr1162 = ptrtoint ptr %mem1161 to i64
  store i64 %ptr1162, ptr %slot44, align 8
  %mem1163 = alloca i8, i64 208, align 8
  %ptr1164 = ptrtoint ptr %mem1163 to i64
  store i64 %ptr1164, ptr %slot45, align 8
  %mem1165 = alloca i8, i64 24, align 8
  %ptr1166 = ptrtoint ptr %mem1165 to i64
  store i64 %ptr1166, ptr %slot46, align 8
  %mem1167 = alloca i8, i64 24, align 8
  %ptr1168 = ptrtoint ptr %mem1167 to i64
  store i64 %ptr1168, ptr %slot47, align 8
  %mem1169 = alloca i8, i64 24, align 8
  %ptr1170 = ptrtoint ptr %mem1169 to i64
  store i64 %ptr1170, ptr %slot48, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1171 = alloca i8, i64 8, align 8
  %ptr1172 = ptrtoint ptr %mem1171 to i64
  store i64 %ptr1172, ptr %slot49, align 8
  %v1173 = load i64, ptr %slot1, align 8
  %op1174 = add i64 %v1173, 64
  store i64 %op1174, ptr %slot50, align 8
  %v1175 = load i64, ptr %slot50, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %ld1177 = load i64, ptr %p1176, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1177, ptr %slot51, align 8
  %stack1178 = call ptr @llvm.stacksave()
  %stackaddr1179 = ptrtoint ptr %stack1178 to i64
  %v1180 = load i64, ptr %slot51, align 8
  %cmp1181 = icmp ult i64 %stackaddr1179, %v1180
  %cv1182 = zext i1 %cmp1181 to i64
  store i64 %cv1182, ptr %slot52, align 8
  %v1183 = load i64, ptr %slot52, align 8
  %cond1184 = icmp ne i64 %v1183, 0
  br i1 %cond1184, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1185 = load i64, ptr %slot1, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  call void @myl_qbe_fail_frame(ptr %p1186) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1187 = load i64, ptr %slot2, align 8
  %v1188 = load i64, ptr %slot26, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i64 %v1187, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  %v1190 = load i64, ptr %slot3, align 8
  %v1191 = load i64, ptr %slot27, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i64 %v1190, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot1, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  %call1195 = call ptr @myl_qbe_heap(ptr %p1194) nomerge, !dbg !112
  %calladdr1196 = ptrtoint ptr %call1195 to i64
  store i64 %calladdr1196, ptr %slot53, align 8
  %v1197 = load i64, ptr %slot1, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %call1199 = call i64 @myl_qbe_region_mark(ptr %p1198) nomerge, !dbg !112
  store i64 %call1199, ptr %slot54, align 8
  %v1200 = load i64, ptr %slot6, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i32 0, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot7, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 0, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot8, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i32 0, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot9, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  store i32 0, ptr %p1207, align 4, !alias.scope !3, !noalias !4
  %v1208 = load i64, ptr %slot10, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  store i32 0, ptr %p1209, align 4, !alias.scope !3, !noalias !4
  %v1210 = load i64, ptr %slot11, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i32 0, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot12, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  store i32 0, ptr %p1213, align 4, !alias.scope !3, !noalias !4
  %v1214 = load i64, ptr %slot13, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  store i32 0, ptr %p1215, align 4, !alias.scope !3, !noalias !4
  %v1216 = load i64, ptr %slot14, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i32 0, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot15, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i32 0, ptr %p1219, align 4, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot16, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i32 0, ptr %p1221, align 4, !alias.scope !3, !noalias !4
  %v1222 = load i64, ptr %slot17, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  store i32 0, ptr %p1223, align 4, !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot18, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 0, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot19, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  store i32 0, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot20, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  store i32 0, ptr %p1229, align 4, !alias.scope !3, !noalias !4
  %v1230 = load i64, ptr %slot7, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i32 2, ptr %p1231, align 4, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot9, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i32 2, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot11, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 2, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot13, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i32 2, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1238 = load i64, ptr %slot26, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ld1240 = load i64, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1240, ptr %slot55, align 8
  %v1241 = load i64, ptr %slot55, align 8
  %v1242 = load i64, ptr %slot36, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 %v1241, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot27, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i64, ptr %p1245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1246, ptr %slot56, align 8
  %v1247 = load i64, ptr %slot56, align 8
  %v1248 = load i64, ptr %slot37, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i64 %v1247, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot37, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i64, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1252, ptr %slot57, align 8
  %v1253 = load i64, ptr %slot57, align 8
  %op1254 = add i64 %v1253, 0
  store i64 %op1254, ptr %slot58, align 8
  %v1255 = load i64, ptr %slot58, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i64, ptr %p1256, align 8
  store i64 %ld1257, ptr %slot59, align 8
  %v1258 = load i64, ptr %slot59, align 8
  %v1259 = load i64, ptr %slot37, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  store i64 %v1258, ptr %p1260, align 8, !alias.scope !3, !noalias !4
  %v1261 = load i64, ptr %slot16, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %ld1263 = load i32, ptr %p1262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1263, ptr %slot60, align 8
  %v1264 = load i32, ptr %slot60, align 8
  %cv1265 = zext i32 %v1264 to i64
  %cond1266 = icmp ne i64 %cv1265, 0
  br i1 %cond1266, label %bb_rcslotdrop26, label %bb_rcslotdone26
bb_rcslotdrop26:
  %v1267 = load i64, ptr %slot16, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  store i32 0, ptr %p1268, align 4, !alias.scope !3, !noalias !4
  %v1269 = load i64, ptr %slot22, align 8
  store i64 %v1269, ptr %slot61, align 8
  %v1270 = load i64, ptr %slot17, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i32, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1272, ptr %slot62, align 8
  %v1273 = load i32, ptr %slot62, align 8
  %op1274 = and i32 %v1273, 28
  store i32 %op1274, ptr %slot63, align 8
  %v1275 = load i32, ptr %slot63, align 8
  %cv1276 = zext i32 %v1275 to i64
  %cond1277 = icmp ne i64 %cv1276, 0
  br i1 %cond1277, label %bb_rcslotrole26, label %bb_rcslotowner26
bb_rcslotrole26:
  %v1278 = load i64, ptr %slot53, align 8
  store i64 %v1278, ptr %slot64, align 8
  %v1279 = load i64, ptr %slot64, align 8
  %v1280 = load i64, ptr %slot61, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v1279, i64 %v1280) nomerge, !dbg !114
  br label %bb_rcslotdone26
bb_rcslotowner26:
  %v1281 = load i64, ptr %slot53, align 8
  store i64 %v1281, ptr %slot65, align 8
  %v1282 = load i64, ptr %slot65, align 8
  %v1283 = load i64, ptr %slot61, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v1282, i64 %v1283) nomerge, !dbg !114
  br label %bb_rcslotdone26
bb_rcslotdone26:
  %v1284 = load i64, ptr %slot36, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i64, ptr %p1285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1286, ptr %slot66, align 8
  %v1287 = load i64, ptr %slot37, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %ld1289 = load i64, ptr %p1288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1289, ptr %slot67, align 8
  %v1290 = load i64, ptr %slot1, align 8
  %v1291 = load i64, ptr %slot66, align 8
  %v1292 = load i64, ptr %slot67, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult69, i64 %v1290, i64 %v1291, i64 %v1292) nomerge, !dbg !116
  %addr1293 = ptrtoint ptr %callresult69 to i64
  store i64 %addr1293, ptr %slot68, align 8
  %v1294 = load i64, ptr %slot68, align 8
  %v1295 = load i64, ptr %slot36, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i64 %v1294, ptr %p1296, align 8, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot36, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i64, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1299, ptr %slot70, align 8
  %v1300 = load i64, ptr %slot25, align 8
  store i64 %v1300, ptr %slot71, align 8
  %v1301 = load i64, ptr %slot70, align 8
  %v1302 = load i64, ptr %slot71, align 8
  %p1303 = inttoptr i64 %v1301 to ptr
  %p1304 = inttoptr i64 %v1302 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1304, ptr %p1303, i64 24, i1 false)
  %v1305 = load i64, ptr %slot19, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i32 2, ptr %p1306, align 4, !alias.scope !3, !noalias !4
  %v1307 = load i64, ptr %slot18, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 1, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot14, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot72, align 8
  %v1312 = load i32, ptr %slot72, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rcslotdrop42, label %bb_rcslotdone42
bb_rcslotdrop42:
  %v1315 = load i64, ptr %slot14, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 0, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot21, align 8
  store i64 %v1317, ptr %slot73, align 8
  %v1318 = load i64, ptr %slot15, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %ld1320 = load i32, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1320, ptr %slot74, align 8
  %v1321 = load i32, ptr %slot74, align 8
  %op1322 = and i32 %v1321, 28
  store i32 %op1322, ptr %slot75, align 8
  %v1323 = load i32, ptr %slot75, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcslotrole42, label %bb_rcslotowner42
bb_rcslotrole42:
  %v1326 = load i64, ptr %slot53, align 8
  store i64 %v1326, ptr %slot76, align 8
  %v1327 = load i64, ptr %slot76, align 8
  %v1328 = load i64, ptr %slot73, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1327, i64 %v1328) nomerge, !dbg !116
  br label %bb_rcslotdone42
bb_rcslotowner42:
  %v1329 = load i64, ptr %slot53, align 8
  store i64 %v1329, ptr %slot77, align 8
  %v1330 = load i64, ptr %slot77, align 8
  %v1331 = load i64, ptr %slot73, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1330, i64 %v1331) nomerge, !dbg !116
  br label %bb_rcslotdone42
bb_rcslotdone42:
  %v1332 = load i64, ptr %slot21, align 8
  store i64 %v1332, ptr %slot78, align 8
  %v1333 = load i64, ptr %slot25, align 8
  store i64 %v1333, ptr %slot79, align 8
  %v1334 = load i64, ptr %slot79, align 8
  %v1335 = load i64, ptr %slot78, align 8
  %p1336 = inttoptr i64 %v1334 to ptr
  %p1337 = inttoptr i64 %v1335 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1337, ptr %p1336, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot15, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 2, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot19, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  %ld1342 = load i32, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1342, ptr %slot80, align 8
  %v1343 = load i32, ptr %slot80, align 8
  %v1344 = load i64, ptr %slot15, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i32 %v1343, ptr %p1345, align 4, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot18, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  store i32 0, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  %v1348 = load i64, ptr %slot14, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  store i32 1, ptr %p1349, align 4, !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot78, align 8
  %v1351 = load i64, ptr %slot36, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i64 %v1350, ptr %p1352, align 8, !alias.scope !3, !noalias !4
  %v1353 = load i64, ptr %slot36, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i64, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1355, ptr %slot81, align 8
  %v1356 = load i64, ptr %slot81, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  %ld1358 = load i32, ptr %p1357, align 4
  %ext1359 = zext i32 %ld1358 to i64
  store i64 %ext1359, ptr %slot82, align 8
  %v1360 = load i64, ptr %slot82, align 8
  %cmp1361 = icmp eq i64 %v1360, 0
  %cv1362 = zext i1 %cmp1361 to i64
  store i64 %cv1362, ptr %slot83, align 8
  %v1363 = load i64, ptr %slot83, align 8
  %cond1364 = icmp ne i64 %v1363, 0
  br i1 %cond1364, label %bb_rctryok58, label %bb_rctryerror58
bb_rctryerror58:
  %p1365 = inttoptr i64 ptrtoint (ptr @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1365, i64 12884901892) "call-inline-cost"="0", !dbg !118
  %v1366 = load i64, ptr %slot81, align 8
  %op1367 = add i64 %v1366, 8
  store i64 %op1367, ptr %slot84, align 8
  %v1368 = load i64, ptr %slot39, align 8
  store i64 %v1368, ptr %slot85, align 8
  %v1369 = load i64, ptr %slot85, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  store i64 0, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot85, align 8
  %p1373 = inttoptr i64 %v1371 to ptr
  %gep1374 = getelementptr i8, ptr %p1373, i64 8
  %op1372 = ptrtoint ptr %gep1374 to i64
  store i64 %op1372, ptr %slot86, align 8
  %v1375 = load i64, ptr %slot86, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i64 0, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot85, align 8
  %p1379 = inttoptr i64 %v1377 to ptr
  %gep1380 = getelementptr i8, ptr %p1379, i64 16
  %op1378 = ptrtoint ptr %gep1380 to i64
  store i64 %op1378, ptr %slot87, align 8
  %v1381 = load i64, ptr %slot87, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  store i64 0, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  %v1383 = load i64, ptr %slot85, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i32 1, ptr %p1384, align 4, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot85, align 8
  %p1387 = inttoptr i64 %v1385 to ptr
  %gep1388 = getelementptr i8, ptr %p1387, i64 8
  %op1386 = ptrtoint ptr %gep1388 to i64
  store i64 %op1386, ptr %slot88, align 8
  %v1389 = load i64, ptr %slot20, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  store i32 1, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  %v1391 = load i64, ptr %slot54, align 8
  store i64 %v1391, ptr %slot89, align 8
  %v1392 = load i64, ptr %slot53, align 8
  %v1393 = load i64, ptr %slot88, align 8
  %v1394 = load i64, ptr %slot84, align 8
  %v1395 = load i64, ptr %slot89, align 8
  %cv1396 = trunc i64 %v1395 to i32
  %call1397 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v1392, i64 %v1393, i64 %v1394, i32 %cv1396) nomerge, !dbg !118
  store i32 %call1397, ptr %slot90, align 8
  %v1398 = load i32, ptr %slot90, align 8
  %cv1399 = zext i32 %v1398 to i64
  %cond1400 = icmp ne i64 %cv1399, 0
  br i1 %cond1400, label %bb_rcsuccess69, label %bb_rcfailure69
bb_rcfailure69:
  %v1401 = load i64, ptr %slot53, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %call1403 = call i32 @myl_rc_take_failure(ptr %p1402) nomerge, !dbg !118
  store i32 %call1403, ptr %slot91, align 8
  %v1404 = load i64, ptr %slot1, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %v1406 = load i32, ptr %slot91, align 8
  %call1407 = call i32 @myl_qbe_rc_status(ptr %p1405, i32 %v1406) nomerge, !dbg !118
  store i32 %call1407, ptr %slot92, align 8
  br label %bb_failure
bb_rcsuccess69:
  %v1408 = load i64, ptr %slot85, align 8
  %v1409 = load i64, ptr %slot36, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i64 %v1408, ptr %p1410, align 8, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot36, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i64, ptr %p1412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1413, ptr %slot93, align 8
  %v1414 = load i64, ptr %slot25, align 8
  store i64 %v1414, ptr %slot94, align 8
  %v1415 = load i64, ptr %slot93, align 8
  %v1416 = load i64, ptr %slot94, align 8
  %p1417 = inttoptr i64 %v1415 to ptr
  %p1418 = inttoptr i64 %v1416 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1418, ptr %p1417, i64 24, i1 false)
  %v1419 = load i64, ptr %slot19, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i32 2, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot18, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  store i32 1, ptr %p1422, align 4, !alias.scope !3, !noalias !4
  %v1423 = load i64, ptr %slot14, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  %ld1425 = load i32, ptr %p1424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1425, ptr %slot95, align 8
  %v1426 = load i32, ptr %slot95, align 8
  %cv1427 = zext i32 %v1426 to i64
  %cond1428 = icmp ne i64 %cv1427, 0
  br i1 %cond1428, label %bb_rcslotdrop78, label %bb_rcslotdone78
bb_rcslotdrop78:
  %v1429 = load i64, ptr %slot14, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  store i32 0, ptr %p1430, align 4, !alias.scope !3, !noalias !4
  %v1431 = load i64, ptr %slot21, align 8
  store i64 %v1431, ptr %slot96, align 8
  %v1432 = load i64, ptr %slot15, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ld1434 = load i32, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1434, ptr %slot97, align 8
  %v1435 = load i32, ptr %slot97, align 8
  %op1436 = and i32 %v1435, 28
  store i32 %op1436, ptr %slot98, align 8
  %v1437 = load i32, ptr %slot98, align 8
  %cv1438 = zext i32 %v1437 to i64
  %cond1439 = icmp ne i64 %cv1438, 0
  br i1 %cond1439, label %bb_rcslotrole78, label %bb_rcslotowner78
bb_rcslotrole78:
  %v1440 = load i64, ptr %slot53, align 8
  store i64 %v1440, ptr %slot99, align 8
  %v1441 = load i64, ptr %slot99, align 8
  %v1442 = load i64, ptr %slot96, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1441, i64 %v1442) nomerge, !dbg !118
  br label %bb_rcslotdone78
bb_rcslotowner78:
  %v1443 = load i64, ptr %slot53, align 8
  store i64 %v1443, ptr %slot100, align 8
  %v1444 = load i64, ptr %slot100, align 8
  %v1445 = load i64, ptr %slot96, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1444, i64 %v1445) nomerge, !dbg !118
  br label %bb_rcslotdone78
bb_rcslotdone78:
  %v1446 = load i64, ptr %slot21, align 8
  store i64 %v1446, ptr %slot101, align 8
  %v1447 = load i64, ptr %slot25, align 8
  store i64 %v1447, ptr %slot102, align 8
  %v1448 = load i64, ptr %slot102, align 8
  %v1449 = load i64, ptr %slot101, align 8
  %p1450 = inttoptr i64 %v1448 to ptr
  %p1451 = inttoptr i64 %v1449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1451, ptr %p1450, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot15, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 2, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot19, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i32, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1456, ptr %slot103, align 8
  %v1457 = load i32, ptr %slot103, align 8
  %v1458 = load i64, ptr %slot15, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 %v1457, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot18, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  store i32 0, ptr %p1461, align 4, !alias.scope !3, !noalias !4
  %v1462 = load i64, ptr %slot14, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i32 1, ptr %p1463, align 4, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot101, align 8
  %v1465 = load i64, ptr %slot36, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i64 %v1464, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_rctryok58:
  %v1467 = load i64, ptr %slot39, align 8
  store i64 %v1467, ptr %slot104, align 8
  %v1468 = load i64, ptr %slot20, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  store i32 1, ptr %p1469, align 4, !alias.scope !3, !noalias !4
  %v1470 = load i64, ptr %slot81, align 8
  %op1471 = add i64 %v1470, 8
  store i64 %op1471, ptr %slot105, align 8
  %v1472 = load i64, ptr %slot54, align 8
  store i64 %v1472, ptr %slot106, align 8
  store i64 0, ptr %slot107, align 8
  store i64 0, ptr %slot108, align 8
  %v1473 = load i64, ptr %slot108, align 8
  %v1474 = load i64, ptr %slot36, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i64 %v1473, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot14, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %ld1478 = load i32, ptr %p1477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1478, ptr %slot109, align 8
  %v1479 = load i32, ptr %slot109, align 8
  %cv1480 = zext i32 %v1479 to i64
  %cond1481 = icmp ne i64 %cv1480, 0
  br i1 %cond1481, label %bb_rcslotdrop102, label %bb_rcslotdone102
bb_rcslotdrop102:
  %v1482 = load i64, ptr %slot14, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i32 0, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  %v1484 = load i64, ptr %slot21, align 8
  store i64 %v1484, ptr %slot110, align 8
  %v1485 = load i64, ptr %slot15, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  %ld1487 = load i32, ptr %p1486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1487, ptr %slot111, align 8
  %v1488 = load i32, ptr %slot111, align 8
  %op1489 = and i32 %v1488, 28
  store i32 %op1489, ptr %slot112, align 8
  %v1490 = load i32, ptr %slot112, align 8
  %cv1491 = zext i32 %v1490 to i64
  %cond1492 = icmp ne i64 %cv1491, 0
  br i1 %cond1492, label %bb_rcslotrole102, label %bb_rcslotowner102
bb_rcslotrole102:
  %v1493 = load i64, ptr %slot53, align 8
  store i64 %v1493, ptr %slot113, align 8
  %v1494 = load i64, ptr %slot113, align 8
  %v1495 = load i64, ptr %slot110, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1494, i64 %v1495) nomerge, !dbg !118
  br label %bb_rcslotdone102
bb_rcslotowner102:
  %v1496 = load i64, ptr %slot53, align 8
  store i64 %v1496, ptr %slot114, align 8
  %v1497 = load i64, ptr %slot114, align 8
  %v1498 = load i64, ptr %slot110, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1497, i64 %v1498) nomerge, !dbg !118
  br label %bb_rcslotdone102
bb_rcslotdone102:
  br label %bb_i7
bb_i6:
  %v1499 = load i64, ptr %slot36, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %ld1501 = load i64, ptr %p1500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1501, ptr %slot115, align 8
  %v1502 = load i64, ptr %slot36, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %ld1504 = load i64, ptr %p1503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1504, ptr %slot116, align 8
  %v1505 = load i64, ptr %slot14, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i32, ptr %p1506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1507, ptr %slot117, align 8
  %v1508 = load i64, ptr %slot15, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i32, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1510, ptr %slot118, align 8
  %v1511 = load i32, ptr %slot118, align 8
  %op1512 = and i32 %v1511, 24
  store i32 %op1512, ptr %slot118, align 8
  %v1513 = load i32, ptr %slot118, align 8
  %cmp1514 = icmp eq i32 %v1513, 0
  %cv1515 = zext i1 %cmp1514 to i32
  store i32 %cv1515, ptr %slot119, align 8
  %v1516 = load i32, ptr %slot117, align 8
  %v1517 = load i32, ptr %slot119, align 8
  %op1518 = and i32 %v1516, %v1517
  store i32 %op1518, ptr %slot120, align 8
  %v1519 = load i32, ptr %slot120, align 8
  %cv1520 = zext i32 %v1519 to i64
  %cond1521 = icmp ne i64 %cv1520, 0
  br i1 %cond1521, label %bb_rctake111, label %bb_rccopy111
bb_rctake111:
  %v1522 = load i64, ptr %slot25, align 8
  store i64 %v1522, ptr %slot121, align 8
  %v1523 = load i64, ptr %slot54, align 8
  store i64 %v1523, ptr %slot122, align 8
  %v1524 = load i64, ptr %slot53, align 8
  %v1525 = load i64, ptr %slot121, align 8
  %v1526 = load i64, ptr %slot116, align 8
  %v1527 = load i64, ptr %slot122, align 8
  %cv1528 = trunc i64 %v1527 to i32
  %call1529 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v1524, i64 %v1525, i64 %v1526, i32 %cv1528) nomerge, !dbg !120
  store i32 %call1529, ptr %slot123, align 8
  %v1530 = load i32, ptr %slot123, align 8
  %cv1531 = zext i32 %v1530 to i64
  %cond1532 = icmp ne i64 %cv1531, 0
  br i1 %cond1532, label %bb_rcsuccess121, label %bb_rcfailure121
bb_rcfailure121:
  %v1533 = load i64, ptr %slot53, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  %call1535 = call i32 @myl_rc_take_failure(ptr %p1534) nomerge, !dbg !120
  store i32 %call1535, ptr %slot124, align 8
  %v1536 = load i64, ptr %slot1, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %v1538 = load i32, ptr %slot124, align 8
  %call1539 = call i32 @myl_qbe_rc_status(ptr %p1537, i32 %v1538) nomerge, !dbg !120
  store i32 %call1539, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess121:
  %v1540 = load i64, ptr %slot14, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i32 0, ptr %p1541, align 4, !alias.scope !3, !noalias !4
  %v1542 = load i64, ptr %slot19, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  store i32 2, ptr %p1543, align 4, !alias.scope !3, !noalias !4
  %v1544 = load i64, ptr %slot18, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i32 1, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared111
bb_rccopy111:
  %v1546 = load i64, ptr %slot25, align 8
  store i64 %v1546, ptr %slot126, align 8
  %v1547 = load i64, ptr %slot54, align 8
  store i64 %v1547, ptr %slot127, align 8
  %v1548 = load i64, ptr %slot53, align 8
  %v1549 = load i64, ptr %slot126, align 8
  %v1550 = load i64, ptr %slot116, align 8
  %v1551 = load i64, ptr %slot127, align 8
  %cv1552 = trunc i64 %v1551 to i32
  %call1553 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v1548, i64 %v1549, i64 %v1550, i32 %cv1552) nomerge, !dbg !120
  store i32 %call1553, ptr %slot128, align 8
  %v1554 = load i32, ptr %slot128, align 8
  %cv1555 = zext i32 %v1554 to i64
  %cond1556 = icmp ne i64 %cv1555, 0
  br i1 %cond1556, label %bb_rcsuccess130, label %bb_rcfailure130
bb_rcfailure130:
  %v1557 = load i64, ptr %slot53, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %call1559 = call i32 @myl_rc_take_failure(ptr %p1558) nomerge, !dbg !120
  store i32 %call1559, ptr %slot129, align 8
  %v1560 = load i64, ptr %slot1, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %v1562 = load i32, ptr %slot129, align 8
  %call1563 = call i32 @myl_qbe_rc_status(ptr %p1561, i32 %v1562) nomerge, !dbg !120
  store i32 %call1563, ptr %slot130, align 8
  br label %bb_failure
bb_rcsuccess130:
  %v1564 = load i64, ptr %slot19, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i32 2, ptr %p1565, align 4, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot18, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i32 1, ptr %p1567, align 4, !alias.scope !3, !noalias !4
  %v1568 = load i64, ptr %slot14, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  %ld1570 = load i32, ptr %p1569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1570, ptr %slot131, align 8
  %v1571 = load i32, ptr %slot131, align 8
  %cv1572 = zext i32 %v1571 to i64
  %cond1573 = icmp ne i64 %cv1572, 0
  br i1 %cond1573, label %bb_rcslotdrop137, label %bb_rcslotdone137
bb_rcslotdrop137:
  %v1574 = load i64, ptr %slot14, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 0, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot21, align 8
  store i64 %v1576, ptr %slot132, align 8
  %v1577 = load i64, ptr %slot15, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %ld1579 = load i32, ptr %p1578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1579, ptr %slot133, align 8
  %v1580 = load i32, ptr %slot133, align 8
  %op1581 = and i32 %v1580, 28
  store i32 %op1581, ptr %slot134, align 8
  %v1582 = load i32, ptr %slot134, align 8
  %cv1583 = zext i32 %v1582 to i64
  %cond1584 = icmp ne i64 %cv1583, 0
  br i1 %cond1584, label %bb_rcslotrole137, label %bb_rcslotowner137
bb_rcslotrole137:
  %v1585 = load i64, ptr %slot53, align 8
  store i64 %v1585, ptr %slot135, align 8
  %v1586 = load i64, ptr %slot135, align 8
  %v1587 = load i64, ptr %slot132, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1586, i64 %v1587) nomerge, !dbg !120
  br label %bb_rcslotdone137
bb_rcslotowner137:
  %v1588 = load i64, ptr %slot53, align 8
  store i64 %v1588, ptr %slot136, align 8
  %v1589 = load i64, ptr %slot136, align 8
  %v1590 = load i64, ptr %slot132, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1589, i64 %v1590) nomerge, !dbg !120
  br label %bb_rcslotdone137
bb_rcslotdone137:
  br label %bb_rcprepared111
bb_rcprepared111:
  %v1591 = load i64, ptr %slot25, align 8
  store i64 %v1591, ptr %slot137, align 8
  %v1592 = load i64, ptr %slot18, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i32 0, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  %v1594 = load i64, ptr %slot14, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  %ld1596 = load i32, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1596, ptr %slot138, align 8
  %v1597 = load i32, ptr %slot138, align 8
  %cv1598 = zext i32 %v1597 to i64
  %cond1599 = icmp ne i64 %cv1598, 0
  br i1 %cond1599, label %bb_rcslotdrop148, label %bb_rcslotdone148
bb_rcslotdrop148:
  %v1600 = load i64, ptr %slot14, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i32 0, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot21, align 8
  store i64 %v1602, ptr %slot139, align 8
  %v1603 = load i64, ptr %slot15, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i32, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1605, ptr %slot140, align 8
  %v1606 = load i32, ptr %slot140, align 8
  %op1607 = and i32 %v1606, 28
  store i32 %op1607, ptr %slot141, align 8
  %v1608 = load i32, ptr %slot141, align 8
  %cv1609 = zext i32 %v1608 to i64
  %cond1610 = icmp ne i64 %cv1609, 0
  br i1 %cond1610, label %bb_rcslotrole148, label %bb_rcslotowner148
bb_rcslotrole148:
  %v1611 = load i64, ptr %slot53, align 8
  store i64 %v1611, ptr %slot142, align 8
  %v1612 = load i64, ptr %slot142, align 8
  %v1613 = load i64, ptr %slot139, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1612, i64 %v1613) nomerge, !dbg !120
  br label %bb_rcslotdone148
bb_rcslotowner148:
  %v1614 = load i64, ptr %slot53, align 8
  store i64 %v1614, ptr %slot143, align 8
  %v1615 = load i64, ptr %slot143, align 8
  %v1616 = load i64, ptr %slot139, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1615, i64 %v1616) nomerge, !dbg !120
  br label %bb_rcslotdone148
bb_rcslotdone148:
  %v1617 = load i64, ptr %slot12, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i32, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1619, ptr %slot144, align 8
  %v1620 = load i32, ptr %slot144, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcslotdrop175, label %bb_rcslotdone175
bb_rcslotdrop175:
  %v1623 = load i64, ptr %slot12, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  store i32 0, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  %v1625 = load i64, ptr %slot35, align 8
  store i64 %v1625, ptr %slot145, align 8
  %v1626 = load i64, ptr %slot13, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i32, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1628, ptr %slot146, align 8
  %v1629 = load i32, ptr %slot146, align 8
  %op1630 = and i32 %v1629, 28
  store i32 %op1630, ptr %slot147, align 8
  %v1631 = load i32, ptr %slot147, align 8
  %cv1632 = zext i32 %v1631 to i64
  %cond1633 = icmp ne i64 %cv1632, 0
  br i1 %cond1633, label %bb_rcslotrole175, label %bb_rcslotowner175
bb_rcslotrole175:
  %v1634 = load i64, ptr %slot53, align 8
  store i64 %v1634, ptr %slot148, align 8
  %v1635 = load i64, ptr %slot148, align 8
  %v1636 = load i64, ptr %slot145, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1635, i64 %v1636) nomerge, !dbg !120
  br label %bb_rcslotdone175
bb_rcslotowner175:
  %v1637 = load i64, ptr %slot53, align 8
  store i64 %v1637, ptr %slot149, align 8
  %v1638 = load i64, ptr %slot149, align 8
  %v1639 = load i64, ptr %slot145, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1638, i64 %v1639) nomerge, !dbg !120
  br label %bb_rcslotdone175
bb_rcslotdone175:
  %v1640 = load i64, ptr %slot10, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  %ld1642 = load i32, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1642, ptr %slot150, align 8
  %v1643 = load i32, ptr %slot150, align 8
  %cv1644 = zext i32 %v1643 to i64
  %cond1645 = icmp ne i64 %cv1644, 0
  br i1 %cond1645, label %bb_rcslotdrop202, label %bb_rcslotdone202
bb_rcslotdrop202:
  %v1646 = load i64, ptr %slot10, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i32 0, ptr %p1647, align 4, !alias.scope !3, !noalias !4
  %v1648 = load i64, ptr %slot33, align 8
  store i64 %v1648, ptr %slot151, align 8
  %v1649 = load i64, ptr %slot11, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  %ld1651 = load i32, ptr %p1650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1651, ptr %slot152, align 8
  %v1652 = load i32, ptr %slot152, align 8
  %op1653 = and i32 %v1652, 28
  store i32 %op1653, ptr %slot153, align 8
  %v1654 = load i32, ptr %slot153, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcslotrole202, label %bb_rcslotowner202
bb_rcslotrole202:
  %v1657 = load i64, ptr %slot53, align 8
  store i64 %v1657, ptr %slot154, align 8
  %v1658 = load i64, ptr %slot154, align 8
  %v1659 = load i64, ptr %slot151, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1658, i64 %v1659) nomerge, !dbg !120
  br label %bb_rcslotdone202
bb_rcslotowner202:
  %v1660 = load i64, ptr %slot53, align 8
  store i64 %v1660, ptr %slot155, align 8
  %v1661 = load i64, ptr %slot155, align 8
  %v1662 = load i64, ptr %slot151, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1661, i64 %v1662) nomerge, !dbg !120
  br label %bb_rcslotdone202
bb_rcslotdone202:
  %v1663 = load i64, ptr %slot8, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %ld1665 = load i32, ptr %p1664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1665, ptr %slot156, align 8
  %v1666 = load i32, ptr %slot156, align 8
  %cv1667 = zext i32 %v1666 to i64
  %cond1668 = icmp ne i64 %cv1667, 0
  br i1 %cond1668, label %bb_rcslotdrop229, label %bb_rcslotdone229
bb_rcslotdrop229:
  %v1669 = load i64, ptr %slot8, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i32 0, ptr %p1670, align 4, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot31, align 8
  store i64 %v1671, ptr %slot157, align 8
  %v1672 = load i64, ptr %slot9, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %ld1674 = load i32, ptr %p1673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1674, ptr %slot158, align 8
  %v1675 = load i32, ptr %slot158, align 8
  %op1676 = and i32 %v1675, 28
  store i32 %op1676, ptr %slot159, align 8
  %v1677 = load i32, ptr %slot159, align 8
  %cv1678 = zext i32 %v1677 to i64
  %cond1679 = icmp ne i64 %cv1678, 0
  br i1 %cond1679, label %bb_rcslotrole229, label %bb_rcslotowner229
bb_rcslotrole229:
  %v1680 = load i64, ptr %slot53, align 8
  store i64 %v1680, ptr %slot160, align 8
  %v1681 = load i64, ptr %slot160, align 8
  %v1682 = load i64, ptr %slot157, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1681, i64 %v1682) nomerge, !dbg !120
  br label %bb_rcslotdone229
bb_rcslotowner229:
  %v1683 = load i64, ptr %slot53, align 8
  store i64 %v1683, ptr %slot161, align 8
  %v1684 = load i64, ptr %slot161, align 8
  %v1685 = load i64, ptr %slot157, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1684, i64 %v1685) nomerge, !dbg !120
  br label %bb_rcslotdone229
bb_rcslotdone229:
  %v1686 = load i64, ptr %slot6, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %ld1688 = load i32, ptr %p1687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1688, ptr %slot162, align 8
  %v1689 = load i32, ptr %slot162, align 8
  %cv1690 = zext i32 %v1689 to i64
  %cond1691 = icmp ne i64 %cv1690, 0
  br i1 %cond1691, label %bb_rcslotdrop238, label %bb_rcslotdone238
bb_rcslotdrop238:
  %v1692 = load i64, ptr %slot6, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  store i32 0, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  %v1694 = load i64, ptr %slot28, align 8
  store i64 %v1694, ptr %slot163, align 8
  %v1695 = load i64, ptr %slot7, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %ld1697 = load i32, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1697, ptr %slot164, align 8
  %v1698 = load i32, ptr %slot164, align 8
  %op1699 = and i32 %v1698, 28
  store i32 %op1699, ptr %slot165, align 8
  %v1700 = load i32, ptr %slot165, align 8
  %cv1701 = zext i32 %v1700 to i64
  %cond1702 = icmp ne i64 %cv1701, 0
  br i1 %cond1702, label %bb_rcslotrole238, label %bb_rcslotowner238
bb_rcslotrole238:
  %v1703 = load i64, ptr %slot53, align 8
  store i64 %v1703, ptr %slot166, align 8
  %v1704 = load i64, ptr %slot166, align 8
  %v1705 = load i64, ptr %slot163, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1704, i64 %v1705) nomerge, !dbg !120
  br label %bb_rcslotdone238
bb_rcslotowner238:
  %v1706 = load i64, ptr %slot53, align 8
  store i64 %v1706, ptr %slot167, align 8
  %v1707 = load i64, ptr %slot167, align 8
  %v1708 = load i64, ptr %slot163, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v1707, i64 %v1708) nomerge, !dbg !120
  br label %bb_rcslotdone238
bb_rcslotdone238:
  %v1709 = load i64, ptr %slot137, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1710, i64 24, i1 false)
  ret void
bb_i7:
  %v1711 = load i64, ptr %slot26, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i64, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1713, ptr %slot168, align 8
  %v1714 = load i64, ptr %slot168, align 8
  %v1715 = load i64, ptr %slot36, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i64 %v1714, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot36, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i64, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1719, ptr %slot169, align 8
  %v1720 = load i64, ptr %slot169, align 8
  %op1721 = add i64 %v1720, 32
  store i64 %op1721, ptr %slot170, align 8
  %v1722 = load i64, ptr %slot170, align 8
  %v1723 = load i64, ptr %slot36, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i64 %v1722, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot14, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %ld1727 = load i32, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1727, ptr %slot171, align 8
  %v1728 = load i32, ptr %slot171, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v1731 = load i64, ptr %slot14, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 0, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot21, align 8
  store i64 %v1733, ptr %slot172, align 8
  %v1734 = load i64, ptr %slot15, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %ld1736 = load i32, ptr %p1735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1736, ptr %slot173, align 8
  %v1737 = load i32, ptr %slot173, align 8
  %op1738 = and i32 %v1737, 28
  store i32 %op1738, ptr %slot174, align 8
  %v1739 = load i32, ptr %slot174, align 8
  %cv1740 = zext i32 %v1739 to i64
  %cond1741 = icmp ne i64 %cv1740, 0
  br i1 %cond1741, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v1742 = load i64, ptr %slot53, align 8
  store i64 %v1742, ptr %slot175, align 8
  %v1743 = load i64, ptr %slot175, align 8
  %v1744 = load i64, ptr %slot172, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1743, i64 %v1744) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v1745 = load i64, ptr %slot53, align 8
  store i64 %v1745, ptr %slot176, align 8
  %v1746 = load i64, ptr %slot176, align 8
  %v1747 = load i64, ptr %slot172, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1746, i64 %v1747) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v1748 = load i64, ptr %slot26, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  %ld1750 = load i64, ptr %p1749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1750, ptr %slot177, align 8
  %v1751 = load i64, ptr %slot177, align 8
  %v1752 = load i64, ptr %slot37, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i64 %v1751, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot37, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %ld1756 = load i64, ptr %p1755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1756, ptr %slot178, align 8
  %v1757 = load i64, ptr %slot178, align 8
  %op1758 = add i64 %v1757, 32
  store i64 %op1758, ptr %slot179, align 8
  %v1759 = load i64, ptr %slot179, align 8
  %v1760 = load i64, ptr %slot37, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  store i64 %v1759, ptr %p1761, align 8, !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot16, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %ld1764 = load i32, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1764, ptr %slot180, align 8
  %v1765 = load i32, ptr %slot180, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcslotdrop280, label %bb_rcslotdone280
bb_rcslotdrop280:
  %v1768 = load i64, ptr %slot16, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  store i32 0, ptr %p1769, align 4, !alias.scope !3, !noalias !4
  %v1770 = load i64, ptr %slot22, align 8
  store i64 %v1770, ptr %slot181, align 8
  %v1771 = load i64, ptr %slot17, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  %ld1773 = load i32, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1773, ptr %slot182, align 8
  %v1774 = load i32, ptr %slot182, align 8
  %op1775 = and i32 %v1774, 28
  store i32 %op1775, ptr %slot183, align 8
  %v1776 = load i32, ptr %slot183, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rcslotrole280, label %bb_rcslotowner280
bb_rcslotrole280:
  %v1779 = load i64, ptr %slot53, align 8
  store i64 %v1779, ptr %slot184, align 8
  %v1780 = load i64, ptr %slot184, align 8
  %v1781 = load i64, ptr %slot181, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1780, i64 %v1781) nomerge, !dbg !124
  br label %bb_rcslotdone280
bb_rcslotowner280:
  %v1782 = load i64, ptr %slot53, align 8
  store i64 %v1782, ptr %slot185, align 8
  %v1783 = load i64, ptr %slot185, align 8
  %v1784 = load i64, ptr %slot181, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1783, i64 %v1784) nomerge, !dbg !124
  br label %bb_rcslotdone280
bb_rcslotdone280:
  %v1785 = load i64, ptr %slot38, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i64 0, ptr %p1786, align 8, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot37, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i64, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1789, ptr %slot186, align 8
  %v1790 = load i64, ptr %slot38, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %ld1792 = load i64, ptr %p1791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1792, ptr %slot187, align 8
  %v1793 = load i64, ptr %slot1, align 8
  %v1794 = load i64, ptr %slot186, align 8
  %v1795 = load i64, ptr %slot187, align 8
  %call1796 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1793, i64 %v1794, i64 %v1795) nomerge, !dbg !126
  store { i64, i64 } %call1796, ptr %callresult189, align 8
  %addr1797 = ptrtoint ptr %callresult189 to i64
  store i64 %addr1797, ptr %slot188, align 8
  %v1798 = load i64, ptr %slot188, align 8
  %v1799 = load i64, ptr %slot37, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i64 %v1798, ptr %p1800, align 8, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot16, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  %ld1803 = load i32, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1803, ptr %slot190, align 8
  %v1804 = load i32, ptr %slot190, align 8
  %cv1805 = zext i32 %v1804 to i64
  %cond1806 = icmp ne i64 %cv1805, 0
  br i1 %cond1806, label %bb_rcslotdrop292, label %bb_rcslotdone292
bb_rcslotdrop292:
  %v1807 = load i64, ptr %slot16, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 0, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot22, align 8
  store i64 %v1809, ptr %slot191, align 8
  %v1810 = load i64, ptr %slot17, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  %ld1812 = load i32, ptr %p1811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1812, ptr %slot192, align 8
  %v1813 = load i32, ptr %slot192, align 8
  %op1814 = and i32 %v1813, 28
  store i32 %op1814, ptr %slot193, align 8
  %v1815 = load i32, ptr %slot193, align 8
  %cv1816 = zext i32 %v1815 to i64
  %cond1817 = icmp ne i64 %cv1816, 0
  br i1 %cond1817, label %bb_rcslotrole292, label %bb_rcslotowner292
bb_rcslotrole292:
  %v1818 = load i64, ptr %slot53, align 8
  store i64 %v1818, ptr %slot194, align 8
  %v1819 = load i64, ptr %slot194, align 8
  %v1820 = load i64, ptr %slot191, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1819, i64 %v1820) nomerge, !dbg !126
  br label %bb_rcslotdone292
bb_rcslotowner292:
  %v1821 = load i64, ptr %slot53, align 8
  store i64 %v1821, ptr %slot195, align 8
  %v1822 = load i64, ptr %slot195, align 8
  %v1823 = load i64, ptr %slot191, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1822, i64 %v1823) nomerge, !dbg !126
  br label %bb_rcslotdone292
bb_rcslotdone292:
  %v1824 = load i64, ptr %slot36, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  %ld1826 = load i64, ptr %p1825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1826, ptr %slot196, align 8
  %v1827 = load i64, ptr %slot37, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i64, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1829, ptr %slot197, align 8
  %v1830 = load i64, ptr %slot1, align 8
  %v1831 = load i64, ptr %slot196, align 8
  %v1832 = load i64, ptr %slot197, align 8
  call void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8 %callresult199, i64 %v1830, i64 %v1831, i64 %v1832) nomerge, !dbg !128
  %addr1833 = ptrtoint ptr %callresult199 to i64
  store i64 %addr1833, ptr %slot198, align 8
  %v1834 = load i64, ptr %slot198, align 8
  %v1835 = load i64, ptr %slot36, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i64 %v1834, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot36, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  %ld1839 = load i64, ptr %p1838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1839, ptr %slot200, align 8
  %v1840 = load i64, ptr %slot25, align 8
  store i64 %v1840, ptr %slot201, align 8
  %v1841 = load i64, ptr %slot200, align 8
  %v1842 = load i64, ptr %slot201, align 8
  %p1843 = inttoptr i64 %v1841 to ptr
  %p1844 = inttoptr i64 %v1842 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1844, ptr %p1843, i64 32, i1 false)
  %v1845 = load i64, ptr %slot19, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 2, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot18, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i32 1, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  %v1849 = load i64, ptr %slot14, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i32, ptr %p1850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1851, ptr %slot202, align 8
  %v1852 = load i32, ptr %slot202, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1855 = load i64, ptr %slot14, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 0, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot21, align 8
  store i64 %v1857, ptr %slot203, align 8
  %v1858 = load i64, ptr %slot15, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %ld1860 = load i32, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1860, ptr %slot204, align 8
  %v1861 = load i32, ptr %slot204, align 8
  %op1862 = and i32 %v1861, 28
  store i32 %op1862, ptr %slot205, align 8
  %v1863 = load i32, ptr %slot205, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1866 = load i64, ptr %slot53, align 8
  store i64 %v1866, ptr %slot206, align 8
  %v1867 = load i64, ptr %slot206, align 8
  %v1868 = load i64, ptr %slot203, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1867, i64 %v1868) nomerge, !dbg !128
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1869 = load i64, ptr %slot53, align 8
  store i64 %v1869, ptr %slot207, align 8
  %v1870 = load i64, ptr %slot207, align 8
  %v1871 = load i64, ptr %slot203, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1870, i64 %v1871) nomerge, !dbg !128
  br label %bb_rcslotdone308
bb_rcslotdone308:
  %v1872 = load i64, ptr %slot21, align 8
  store i64 %v1872, ptr %slot208, align 8
  %v1873 = load i64, ptr %slot25, align 8
  store i64 %v1873, ptr %slot209, align 8
  %v1874 = load i64, ptr %slot209, align 8
  %v1875 = load i64, ptr %slot208, align 8
  %p1876 = inttoptr i64 %v1874 to ptr
  %p1877 = inttoptr i64 %v1875 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1877, ptr %p1876, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot15, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 2, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot19, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %ld1882 = load i32, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1882, ptr %slot210, align 8
  %v1883 = load i32, ptr %slot210, align 8
  %v1884 = load i64, ptr %slot15, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 %v1883, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot18, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 0, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot14, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 1, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot208, align 8
  %v1891 = load i64, ptr %slot36, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i64 %v1890, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot36, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  %ld1895 = load i64, ptr %p1894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1895, ptr %slot211, align 8
  %v1896 = load i64, ptr %slot211, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i32, ptr %p1897, align 4
  %ext1899 = zext i32 %ld1898 to i64
  store i64 %ext1899, ptr %slot212, align 8
  %v1900 = load i64, ptr %slot212, align 8
  %cmp1901 = icmp eq i64 %v1900, 0
  %cv1902 = zext i1 %cmp1901 to i64
  store i64 %cv1902, ptr %slot213, align 8
  %v1903 = load i64, ptr %slot213, align 8
  %cond1904 = icmp ne i64 %v1903, 0
  br i1 %cond1904, label %bb_rcarm325, label %bb_rcarmnext325
bb_rcarm325:
  %v1905 = load i64, ptr %slot14, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  %ld1907 = load i32, ptr %p1906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1907, ptr %slot214, align 8
  %v1908 = load i32, ptr %slot214, align 8
  %cv1909 = zext i32 %v1908 to i64
  %cond1910 = icmp ne i64 %cv1909, 0
  br i1 %cond1910, label %bb_rcslotdrop328, label %bb_rcslotdone328
bb_rcslotdrop328:
  %v1911 = load i64, ptr %slot14, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  store i32 0, ptr %p1912, align 4, !alias.scope !3, !noalias !4
  %v1913 = load i64, ptr %slot21, align 8
  store i64 %v1913, ptr %slot215, align 8
  %v1914 = load i64, ptr %slot15, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %ld1916 = load i32, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1916, ptr %slot216, align 8
  %v1917 = load i32, ptr %slot216, align 8
  %op1918 = and i32 %v1917, 28
  store i32 %op1918, ptr %slot217, align 8
  %v1919 = load i32, ptr %slot217, align 8
  %cv1920 = zext i32 %v1919 to i64
  %cond1921 = icmp ne i64 %cv1920, 0
  br i1 %cond1921, label %bb_rcslotrole328, label %bb_rcslotowner328
bb_rcslotrole328:
  %v1922 = load i64, ptr %slot53, align 8
  store i64 %v1922, ptr %slot218, align 8
  %v1923 = load i64, ptr %slot218, align 8
  %v1924 = load i64, ptr %slot215, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1923, i64 %v1924) nomerge, !dbg !130
  br label %bb_rcslotdone328
bb_rcslotowner328:
  %v1925 = load i64, ptr %slot53, align 8
  store i64 %v1925, ptr %slot219, align 8
  %v1926 = load i64, ptr %slot219, align 8
  %v1927 = load i64, ptr %slot215, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1926, i64 %v1927) nomerge, !dbg !130
  br label %bb_rcslotdone328
bb_rcslotdone328:
  br label %bb_i130
bb_rcarmnext325:
  %v1928 = load i64, ptr %slot212, align 8
  %cmp1929 = icmp eq i64 %v1928, 1
  %cv1930 = zext i1 %cmp1929 to i64
  store i64 %cv1930, ptr %slot220, align 8
  %v1931 = load i64, ptr %slot220, align 8
  %cond1932 = icmp ne i64 %v1931, 0
  br i1 %cond1932, label %bb_rcarm335, label %bb_rcarmnext335
bb_rcarm335:
  %v1933 = load i64, ptr %slot25, align 8
  store i64 %v1933, ptr %slot221, align 8
  %v1934 = load i64, ptr %slot211, align 8
  %op1935 = add i64 %v1934, 8
  store i64 %op1935, ptr %slot222, align 8
  %v1936 = load i64, ptr %slot54, align 8
  store i64 %v1936, ptr %slot223, align 8
  %v1937 = load i64, ptr %slot53, align 8
  %v1938 = load i64, ptr %slot221, align 8
  %v1939 = load i64, ptr %slot222, align 8
  %v1940 = load i64, ptr %slot223, align 8
  %cv1941 = trunc i64 %v1940 to i32
  %call1942 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v1937, i64 %v1938, i64 %v1939, i32 %cv1941) nomerge, !dbg !130
  store i32 %call1942, ptr %slot224, align 8
  %v1943 = load i32, ptr %slot224, align 8
  %cv1944 = zext i32 %v1943 to i64
  %cond1945 = icmp ne i64 %cv1944, 0
  br i1 %cond1945, label %bb_rcsuccess340, label %bb_rcfailure340
bb_rcfailure340:
  %v1946 = load i64, ptr %slot53, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  %call1948 = call i32 @myl_rc_take_failure(ptr %p1947) nomerge, !dbg !130
  store i32 %call1948, ptr %slot225, align 8
  %v1949 = load i64, ptr %slot1, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %v1951 = load i32, ptr %slot225, align 8
  %call1952 = call i32 @myl_qbe_rc_status(ptr %p1950, i32 %v1951) nomerge, !dbg !130
  store i32 %call1952, ptr %slot226, align 8
  br label %bb_failure
bb_rcsuccess340:
  %v1953 = load i64, ptr %slot19, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i32 2, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot18, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i32 1, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot6, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %ld1959 = load i32, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1959, ptr %slot227, align 8
  %v1960 = load i32, ptr %slot227, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcslotdrop347, label %bb_rcslotdone347
bb_rcslotdrop347:
  %v1963 = load i64, ptr %slot6, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  store i32 0, ptr %p1964, align 4, !alias.scope !3, !noalias !4
  %v1965 = load i64, ptr %slot28, align 8
  store i64 %v1965, ptr %slot228, align 8
  %v1966 = load i64, ptr %slot7, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %ld1968 = load i32, ptr %p1967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1968, ptr %slot229, align 8
  %v1969 = load i32, ptr %slot229, align 8
  %op1970 = and i32 %v1969, 28
  store i32 %op1970, ptr %slot230, align 8
  %v1971 = load i32, ptr %slot230, align 8
  %cv1972 = zext i32 %v1971 to i64
  %cond1973 = icmp ne i64 %cv1972, 0
  br i1 %cond1973, label %bb_rcslotrole347, label %bb_rcslotowner347
bb_rcslotrole347:
  %v1974 = load i64, ptr %slot53, align 8
  store i64 %v1974, ptr %slot231, align 8
  %v1975 = load i64, ptr %slot231, align 8
  %v1976 = load i64, ptr %slot228, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1975, i64 %v1976) nomerge, !dbg !130
  br label %bb_rcslotdone347
bb_rcslotowner347:
  %v1977 = load i64, ptr %slot53, align 8
  store i64 %v1977, ptr %slot232, align 8
  %v1978 = load i64, ptr %slot232, align 8
  %v1979 = load i64, ptr %slot228, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v1978, i64 %v1979) nomerge, !dbg !130
  br label %bb_rcslotdone347
bb_rcslotdone347:
  %v1980 = load i64, ptr %slot221, align 8
  %v1981 = load i64, ptr %slot28, align 8
  %p1982 = inttoptr i64 %v1980 to ptr
  %p1983 = inttoptr i64 %v1981 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1983, ptr %p1982, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot18, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  store i32 0, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  %v1986 = load i64, ptr %slot28, align 8
  store i64 %v1986, ptr %slot233, align 8
  %v1987 = load i64, ptr %slot7, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 2, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot6, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i32 1, ptr %p1990, align 4, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot14, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i32, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1993, ptr %slot234, align 8
  %v1994 = load i32, ptr %slot234, align 8
  %cv1995 = zext i32 %v1994 to i64
  %cond1996 = icmp ne i64 %cv1995, 0
  br i1 %cond1996, label %bb_rcslotdrop360, label %bb_rcslotdone360
bb_rcslotdrop360:
  %v1997 = load i64, ptr %slot14, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i32 0, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  %v1999 = load i64, ptr %slot21, align 8
  store i64 %v1999, ptr %slot235, align 8
  %v2000 = load i64, ptr %slot15, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  %ld2002 = load i32, ptr %p2001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2002, ptr %slot236, align 8
  %v2003 = load i32, ptr %slot236, align 8
  %op2004 = and i32 %v2003, 28
  store i32 %op2004, ptr %slot237, align 8
  %v2005 = load i32, ptr %slot237, align 8
  %cv2006 = zext i32 %v2005 to i64
  %cond2007 = icmp ne i64 %cv2006, 0
  br i1 %cond2007, label %bb_rcslotrole360, label %bb_rcslotowner360
bb_rcslotrole360:
  %v2008 = load i64, ptr %slot53, align 8
  store i64 %v2008, ptr %slot238, align 8
  %v2009 = load i64, ptr %slot238, align 8
  %v2010 = load i64, ptr %slot235, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2009, i64 %v2010) nomerge, !dbg !130
  br label %bb_rcslotdone360
bb_rcslotowner360:
  %v2011 = load i64, ptr %slot53, align 8
  store i64 %v2011, ptr %slot239, align 8
  %v2012 = load i64, ptr %slot239, align 8
  %v2013 = load i64, ptr %slot235, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2012, i64 %v2013) nomerge, !dbg !130
  br label %bb_rcslotdone360
bb_rcslotdone360:
  br label %bb_i16
bb_rcarmnext335:
  br label %bb_failure
bb_i16:
  %v2014 = load i64, ptr %slot26, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %ld2016 = load i64, ptr %p2015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2016, ptr %slot240, align 8
  %v2017 = load i64, ptr %slot240, align 8
  %v2018 = load i64, ptr %slot36, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i64 %v2017, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot36, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  %ld2022 = load i64, ptr %p2021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2022, ptr %slot241, align 8
  %v2023 = load i64, ptr %slot241, align 8
  %op2024 = add i64 %v2023, 32
  store i64 %op2024, ptr %slot242, align 8
  %v2025 = load i64, ptr %slot242, align 8
  %v2026 = load i64, ptr %slot36, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  store i64 %v2025, ptr %p2027, align 8, !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot14, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %ld2030 = load i32, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2030, ptr %slot243, align 8
  %v2031 = load i32, ptr %slot243, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcslotdrop372, label %bb_rcslotdone372
bb_rcslotdrop372:
  %v2034 = load i64, ptr %slot14, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  store i32 0, ptr %p2035, align 4, !alias.scope !3, !noalias !4
  %v2036 = load i64, ptr %slot21, align 8
  store i64 %v2036, ptr %slot244, align 8
  %v2037 = load i64, ptr %slot15, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %ld2039 = load i32, ptr %p2038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2039, ptr %slot245, align 8
  %v2040 = load i32, ptr %slot245, align 8
  %op2041 = and i32 %v2040, 28
  store i32 %op2041, ptr %slot246, align 8
  %v2042 = load i32, ptr %slot246, align 8
  %cv2043 = zext i32 %v2042 to i64
  %cond2044 = icmp ne i64 %cv2043, 0
  br i1 %cond2044, label %bb_rcslotrole372, label %bb_rcslotowner372
bb_rcslotrole372:
  %v2045 = load i64, ptr %slot53, align 8
  store i64 %v2045, ptr %slot247, align 8
  %v2046 = load i64, ptr %slot247, align 8
  %v2047 = load i64, ptr %slot244, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2046, i64 %v2047) nomerge, !dbg !132
  br label %bb_rcslotdone372
bb_rcslotowner372:
  %v2048 = load i64, ptr %slot53, align 8
  store i64 %v2048, ptr %slot248, align 8
  %v2049 = load i64, ptr %slot248, align 8
  %v2050 = load i64, ptr %slot244, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2049, i64 %v2050) nomerge, !dbg !132
  br label %bb_rcslotdone372
bb_rcslotdone372:
  %v2051 = load i64, ptr %slot27, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i64, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2053, ptr %slot249, align 8
  %v2054 = load i64, ptr %slot249, align 8
  %v2055 = load i64, ptr %slot37, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 %v2054, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot37, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i64, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2059, ptr %slot250, align 8
  %v2060 = load i64, ptr %slot250, align 8
  %op2061 = add i64 %v2060, 48
  store i64 %op2061, ptr %slot251, align 8
  %v2062 = load i64, ptr %slot251, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8
  store i64 %ld2064, ptr %slot252, align 8
  %v2065 = load i64, ptr %slot252, align 8
  %v2066 = load i64, ptr %slot37, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i64 %v2065, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot16, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %ld2070 = load i32, ptr %p2069, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2070, ptr %slot253, align 8
  %v2071 = load i32, ptr %slot253, align 8
  %cv2072 = zext i32 %v2071 to i64
  %cond2073 = icmp ne i64 %cv2072, 0
  br i1 %cond2073, label %bb_rcslotdrop385, label %bb_rcslotdone385
bb_rcslotdrop385:
  %v2074 = load i64, ptr %slot16, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i32 0, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot22, align 8
  store i64 %v2076, ptr %slot254, align 8
  %v2077 = load i64, ptr %slot17, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i32, ptr %p2078, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2079, ptr %slot255, align 8
  %v2080 = load i32, ptr %slot255, align 8
  %op2081 = and i32 %v2080, 28
  store i32 %op2081, ptr %slot256, align 8
  %v2082 = load i32, ptr %slot256, align 8
  %cv2083 = zext i32 %v2082 to i64
  %cond2084 = icmp ne i64 %cv2083, 0
  br i1 %cond2084, label %bb_rcslotrole385, label %bb_rcslotowner385
bb_rcslotrole385:
  %v2085 = load i64, ptr %slot53, align 8
  store i64 %v2085, ptr %slot257, align 8
  %v2086 = load i64, ptr %slot257, align 8
  %v2087 = load i64, ptr %slot254, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v2086, i64 %v2087) nomerge, !dbg !134
  br label %bb_rcslotdone385
bb_rcslotowner385:
  %v2088 = load i64, ptr %slot53, align 8
  store i64 %v2088, ptr %slot258, align 8
  %v2089 = load i64, ptr %slot258, align 8
  %v2090 = load i64, ptr %slot254, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v2089, i64 %v2090) nomerge, !dbg !134
  br label %bb_rcslotdone385
bb_rcslotdone385:
  %v2091 = load i64, ptr %slot36, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i64, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2093, ptr %slot259, align 8
  %v2094 = load i64, ptr %slot37, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %ld2096 = load i64, ptr %p2095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2096, ptr %slot260, align 8
  %v2097 = load i64, ptr %slot1, align 8
  %v2098 = load i64, ptr %slot259, align 8
  %v2099 = load i64, ptr %slot260, align 8
  %call2100 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v2097, i64 %v2098, i64 %v2099) nomerge, !dbg !136
  store i64 %call2100, ptr %slot261, align 8
  %v2101 = load i64, ptr %slot261, align 8
  %v2102 = load i64, ptr %slot36, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i64 %v2101, ptr %p2103, align 8, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot14, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i32, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2106, ptr %slot262, align 8
  %v2107 = load i32, ptr %slot262, align 8
  %cv2108 = zext i32 %v2107 to i64
  %cond2109 = icmp ne i64 %cv2108, 0
  br i1 %cond2109, label %bb_rcslotdrop397, label %bb_rcslotdone397
bb_rcslotdrop397:
  %v2110 = load i64, ptr %slot14, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  store i32 0, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  %v2112 = load i64, ptr %slot21, align 8
  store i64 %v2112, ptr %slot263, align 8
  %v2113 = load i64, ptr %slot15, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %ld2115 = load i32, ptr %p2114, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2115, ptr %slot264, align 8
  %v2116 = load i32, ptr %slot264, align 8
  %op2117 = and i32 %v2116, 28
  store i32 %op2117, ptr %slot265, align 8
  %v2118 = load i32, ptr %slot265, align 8
  %cv2119 = zext i32 %v2118 to i64
  %cond2120 = icmp ne i64 %cv2119, 0
  br i1 %cond2120, label %bb_rcslotrole397, label %bb_rcslotowner397
bb_rcslotrole397:
  %v2121 = load i64, ptr %slot53, align 8
  store i64 %v2121, ptr %slot266, align 8
  %v2122 = load i64, ptr %slot266, align 8
  %v2123 = load i64, ptr %slot263, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2122, i64 %v2123) nomerge, !dbg !136
  br label %bb_rcslotdone397
bb_rcslotowner397:
  %v2124 = load i64, ptr %slot53, align 8
  store i64 %v2124, ptr %slot267, align 8
  %v2125 = load i64, ptr %slot267, align 8
  %v2126 = load i64, ptr %slot263, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2125, i64 %v2126) nomerge, !dbg !136
  br label %bb_rcslotdone397
bb_rcslotdone397:
  %v2127 = load i64, ptr %slot36, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %ld2129 = load i64, ptr %p2128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2129, ptr %slot268, align 8
  %v2130 = load i64, ptr %slot268, align 8
  %v2131 = load i64, ptr %slot29, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  store i64 %v2130, ptr %p2132, align 8, !alias.scope !3, !noalias !4
  %v2133 = load i64, ptr %slot28, align 8
  %v2134 = load i64, ptr %slot36, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i64 %v2133, ptr %p2135, align 8, !alias.scope !3, !noalias !4
  %v2136 = load i64, ptr %slot36, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %ld2138 = load i64, ptr %p2137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2138, ptr %slot269, align 8
  %v2139 = load i64, ptr %slot269, align 8
  %op2140 = add i64 %v2139, 8
  store i64 %op2140, ptr %slot270, align 8
  %v2141 = load i64, ptr %slot270, align 8
  %v2142 = load i64, ptr %slot36, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i64 %v2141, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot36, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %ld2146 = load i64, ptr %p2145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2146, ptr %slot271, align 8
  %v2147 = load i64, ptr %slot25, align 8
  store i64 %v2147, ptr %slot272, align 8
  %v2148 = load i64, ptr %slot53, align 8
  %v2149 = load i64, ptr %slot272, align 8
  %v2150 = load i64, ptr %slot271, align 8
  %call2151 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v2148, i64 %v2149, i64 %v2150) nomerge, !dbg !138
  store i32 %call2151, ptr %slot273, align 8
  %v2152 = load i32, ptr %slot273, align 8
  %cv2153 = zext i32 %v2152 to i64
  %cond2154 = icmp ne i64 %cv2153, 0
  br i1 %cond2154, label %bb_rcsuccess410, label %bb_rcfailure410
bb_rcfailure410:
  %v2155 = load i64, ptr %slot53, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  %call2157 = call i32 @myl_rc_take_failure(ptr %p2156) nomerge, !dbg !138
  store i32 %call2157, ptr %slot274, align 8
  %v2158 = load i64, ptr %slot1, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %v2160 = load i32, ptr %slot274, align 8
  %call2161 = call i32 @myl_qbe_rc_status(ptr %p2159, i32 %v2160) nomerge, !dbg !138
  store i32 %call2161, ptr %slot275, align 8
  br label %bb_failure
bb_rcsuccess410:
  %v2162 = load i64, ptr %slot19, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i32 2, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  %v2164 = load i64, ptr %slot19, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 16, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot18, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i32 1, ptr %p2167, align 4, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot14, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i32, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2170, ptr %slot276, align 8
  %v2171 = load i32, ptr %slot276, align 8
  %cv2172 = zext i32 %v2171 to i64
  %cond2173 = icmp ne i64 %cv2172, 0
  br i1 %cond2173, label %bb_rcslotdrop418, label %bb_rcslotdone418
bb_rcslotdrop418:
  %v2174 = load i64, ptr %slot14, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 0, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot21, align 8
  store i64 %v2176, ptr %slot277, align 8
  %v2177 = load i64, ptr %slot15, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  %ld2179 = load i32, ptr %p2178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2179, ptr %slot278, align 8
  %v2180 = load i32, ptr %slot278, align 8
  %op2181 = and i32 %v2180, 28
  store i32 %op2181, ptr %slot279, align 8
  %v2182 = load i32, ptr %slot279, align 8
  %cv2183 = zext i32 %v2182 to i64
  %cond2184 = icmp ne i64 %cv2183, 0
  br i1 %cond2184, label %bb_rcslotrole418, label %bb_rcslotowner418
bb_rcslotrole418:
  %v2185 = load i64, ptr %slot53, align 8
  store i64 %v2185, ptr %slot280, align 8
  %v2186 = load i64, ptr %slot280, align 8
  %v2187 = load i64, ptr %slot277, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2186, i64 %v2187) nomerge, !dbg !138
  br label %bb_rcslotdone418
bb_rcslotowner418:
  %v2188 = load i64, ptr %slot53, align 8
  store i64 %v2188, ptr %slot281, align 8
  %v2189 = load i64, ptr %slot281, align 8
  %v2190 = load i64, ptr %slot277, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2189, i64 %v2190) nomerge, !dbg !138
  br label %bb_rcslotdone418
bb_rcslotdone418:
  %v2191 = load i64, ptr %slot21, align 8
  store i64 %v2191, ptr %slot282, align 8
  %v2192 = load i64, ptr %slot25, align 8
  store i64 %v2192, ptr %slot283, align 8
  %v2193 = load i64, ptr %slot283, align 8
  %v2194 = load i64, ptr %slot282, align 8
  %p2195 = inttoptr i64 %v2193 to ptr
  %p2196 = inttoptr i64 %v2194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2196, ptr %p2195, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot15, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i32 2, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  %v2199 = load i64, ptr %slot19, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i32, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2201, ptr %slot284, align 8
  %v2202 = load i32, ptr %slot284, align 8
  %v2203 = load i64, ptr %slot15, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  store i32 %v2202, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  %v2205 = load i64, ptr %slot18, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i32 0, ptr %p2206, align 4, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot14, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  store i32 1, ptr %p2208, align 4, !alias.scope !3, !noalias !4
  %v2209 = load i64, ptr %slot282, align 8
  %v2210 = load i64, ptr %slot36, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  store i64 %v2209, ptr %p2211, align 8, !alias.scope !3, !noalias !4
  %v2212 = load i64, ptr %slot27, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %ld2214 = load i64, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2214, ptr %slot285, align 8
  %v2215 = load i64, ptr %slot285, align 8
  %v2216 = load i64, ptr %slot37, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i64 %v2215, ptr %p2217, align 8, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot37, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %ld2220 = load i64, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2220, ptr %slot286, align 8
  %v2221 = load i64, ptr %slot286, align 8
  %op2222 = add i64 %v2221, 48
  store i64 %op2222, ptr %slot287, align 8
  %v2223 = load i64, ptr %slot287, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %ld2225 = load i64, ptr %p2224, align 8
  store i64 %ld2225, ptr %slot288, align 8
  %v2226 = load i64, ptr %slot288, align 8
  %v2227 = load i64, ptr %slot37, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  store i64 %v2226, ptr %p2228, align 8, !alias.scope !3, !noalias !4
  %v2229 = load i64, ptr %slot16, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i32, ptr %p2230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2231, ptr %slot289, align 8
  %v2232 = load i32, ptr %slot289, align 8
  %cv2233 = zext i32 %v2232 to i64
  %cond2234 = icmp ne i64 %cv2233, 0
  br i1 %cond2234, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v2235 = load i64, ptr %slot16, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  store i32 0, ptr %p2236, align 4, !alias.scope !3, !noalias !4
  %v2237 = load i64, ptr %slot22, align 8
  store i64 %v2237, ptr %slot290, align 8
  %v2238 = load i64, ptr %slot17, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %ld2240 = load i32, ptr %p2239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2240, ptr %slot291, align 8
  %v2241 = load i32, ptr %slot291, align 8
  %op2242 = and i32 %v2241, 28
  store i32 %op2242, ptr %slot292, align 8
  %v2243 = load i32, ptr %slot292, align 8
  %cv2244 = zext i32 %v2243 to i64
  %cond2245 = icmp ne i64 %cv2244, 0
  br i1 %cond2245, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v2246 = load i64, ptr %slot53, align 8
  store i64 %v2246, ptr %slot293, align 8
  %v2247 = load i64, ptr %slot293, align 8
  %v2248 = load i64, ptr %slot290, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v2247, i64 %v2248) nomerge, !dbg !140
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v2249 = load i64, ptr %slot53, align 8
  store i64 %v2249, ptr %slot294, align 8
  %v2250 = load i64, ptr %slot294, align 8
  %v2251 = load i64, ptr %slot290, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v2250, i64 %v2251) nomerge, !dbg !140
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v2252 = load i64, ptr %slot29, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %ld2254 = load i64, ptr %p2253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2254, ptr %slot295, align 8
  %v2255 = load i64, ptr %slot295, align 8
  %v2256 = load i64, ptr %slot38, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i64 %v2255, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot36, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i64, ptr %p2259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2260, ptr %slot296, align 8
  %v2261 = load i64, ptr %slot37, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %ld2263 = load i64, ptr %p2262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2263, ptr %slot297, align 8
  %v2264 = load i64, ptr %slot38, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %ld2266 = load i64, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2266, ptr %slot298, align 8
  %v2267 = load i64, ptr %slot1, align 8
  %v2268 = load i64, ptr %slot296, align 8
  %v2269 = load i64, ptr %slot297, align 8
  %v2270 = load i64, ptr %slot298, align 8
  call void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %callresult300, i64 %v2267, i64 %v2268, i64 %v2269, i64 %v2270) nomerge, !dbg !142
  %addr2271 = ptrtoint ptr %callresult300 to i64
  store i64 %addr2271, ptr %slot299, align 8
  %v2272 = load i64, ptr %slot299, align 8
  %v2273 = load i64, ptr %slot36, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  store i64 %v2272, ptr %p2274, align 8, !alias.scope !3, !noalias !4
  %v2275 = load i64, ptr %slot14, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %ld2277 = load i32, ptr %p2276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2277, ptr %slot301, align 8
  %v2278 = load i32, ptr %slot301, align 8
  %cv2279 = zext i32 %v2278 to i64
  %cond2280 = icmp ne i64 %cv2279, 0
  br i1 %cond2280, label %bb_rcslotdrop453, label %bb_rcslotdone453
bb_rcslotdrop453:
  %v2281 = load i64, ptr %slot14, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i32 0, ptr %p2282, align 4, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot21, align 8
  store i64 %v2283, ptr %slot302, align 8
  %v2284 = load i64, ptr %slot15, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  %ld2286 = load i32, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2286, ptr %slot303, align 8
  %v2287 = load i32, ptr %slot303, align 8
  %op2288 = and i32 %v2287, 28
  store i32 %op2288, ptr %slot304, align 8
  %v2289 = load i32, ptr %slot304, align 8
  %cv2290 = zext i32 %v2289 to i64
  %cond2291 = icmp ne i64 %cv2290, 0
  br i1 %cond2291, label %bb_rcslotrole453, label %bb_rcslotowner453
bb_rcslotrole453:
  %v2292 = load i64, ptr %slot53, align 8
  store i64 %v2292, ptr %slot305, align 8
  %v2293 = load i64, ptr %slot305, align 8
  %v2294 = load i64, ptr %slot302, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2293, i64 %v2294) nomerge, !dbg !142
  br label %bb_rcslotdone453
bb_rcslotowner453:
  %v2295 = load i64, ptr %slot53, align 8
  store i64 %v2295, ptr %slot306, align 8
  %v2296 = load i64, ptr %slot306, align 8
  %v2297 = load i64, ptr %slot302, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2296, i64 %v2297) nomerge, !dbg !142
  br label %bb_rcslotdone453
bb_rcslotdone453:
  %v2298 = load i64, ptr %slot36, align 8
  %p2299 = inttoptr i64 %v2298 to ptr
  %ld2300 = load i64, ptr %p2299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2300, ptr %slot307, align 8
  %v2301 = load i64, ptr %slot307, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %ld2303 = load i32, ptr %p2302, align 4
  %ext2304 = zext i32 %ld2303 to i64
  store i64 %ext2304, ptr %slot308, align 8
  %v2305 = load i64, ptr %slot308, align 8
  %cmp2306 = icmp eq i64 %v2305, 0
  %cv2307 = zext i1 %cmp2306 to i64
  store i64 %cv2307, ptr %slot309, align 8
  %v2308 = load i64, ptr %slot309, align 8
  %cond2309 = icmp ne i64 %v2308, 0
  br i1 %cond2309, label %bb_rcarm462, label %bb_rcarmnext462
bb_rcarm462:
  br label %bb_i53
bb_rcarmnext462:
  %v2310 = load i64, ptr %slot308, align 8
  %cmp2311 = icmp eq i64 %v2310, 1
  %cv2312 = zext i1 %cmp2311 to i64
  store i64 %cv2312, ptr %slot310, align 8
  %v2313 = load i64, ptr %slot310, align 8
  %cond2314 = icmp ne i64 %v2313, 0
  br i1 %cond2314, label %bb_rcarm463, label %bb_rcarmnext463
bb_rcarm463:
  %v2315 = load i64, ptr %slot25, align 8
  store i64 %v2315, ptr %slot311, align 8
  %v2316 = load i64, ptr %slot307, align 8
  %op2317 = add i64 %v2316, 8
  store i64 %op2317, ptr %slot312, align 8
  %v2318 = load i64, ptr %slot54, align 8
  store i64 %v2318, ptr %slot313, align 8
  %v2319 = load i64, ptr %slot312, align 8
  %v2320 = load i64, ptr %slot311, align 8
  %p2321 = inttoptr i64 %v2319 to ptr
  %p2322 = inttoptr i64 %v2320 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2322, ptr %p2321, i64 16, i1 false)
  %v2323 = load i64, ptr %slot19, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  store i32 0, ptr %p2324, align 4, !alias.scope !3, !noalias !4
  %v2325 = load i64, ptr %slot18, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  store i32 1, ptr %p2326, align 4, !alias.scope !3, !noalias !4
  %v2327 = load i64, ptr %slot311, align 8
  %v2328 = load i64, ptr %slot30, align 8
  %p2329 = inttoptr i64 %v2327 to ptr
  %p2330 = inttoptr i64 %v2328 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2330, ptr %p2329, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2331 = load i64, ptr %slot18, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 0, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_rcarmnext463:
  br label %bb_failure
bb_i29:
  %v2333 = load i64, ptr %slot26, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i64, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2335, ptr %slot314, align 8
  %v2336 = load i64, ptr %slot314, align 8
  %v2337 = load i64, ptr %slot40, align 8
  %p2338 = inttoptr i64 %v2336 to ptr
  %p2339 = inttoptr i64 %v2337 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2339, ptr %p2338, i64 304, i1 false), !alias.scope !10000000
  %v2340 = load i64, ptr %slot40, align 8
  %v2341 = load i64, ptr %slot36, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i64 %v2340, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot36, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i64, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2345, ptr %slot315, align 8
  %v2346 = load i64, ptr %slot315, align 8
  %op2347 = add i64 %v2346, 32
  store i64 %op2347, ptr %slot316, align 8
  %v2348 = load i64, ptr %slot316, align 8
  %v2349 = load i64, ptr %slot36, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot8, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i32, ptr %p2352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2353, ptr %slot317, align 8
  %v2354 = load i32, ptr %slot317, align 8
  %cv2355 = zext i32 %v2354 to i64
  %cond2356 = icmp ne i64 %cv2355, 0
  br i1 %cond2356, label %bb_rcslotdrop475, label %bb_rcslotdone475
bb_rcslotdrop475:
  %v2357 = load i64, ptr %slot8, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i32 0, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot31, align 8
  store i64 %v2359, ptr %slot318, align 8
  %v2360 = load i64, ptr %slot9, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i32, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2362, ptr %slot319, align 8
  %v2363 = load i32, ptr %slot319, align 8
  %op2364 = and i32 %v2363, 28
  store i32 %op2364, ptr %slot320, align 8
  %v2365 = load i32, ptr %slot320, align 8
  %cv2366 = zext i32 %v2365 to i64
  %cond2367 = icmp ne i64 %cv2366, 0
  br i1 %cond2367, label %bb_rcslotrole475, label %bb_rcslotowner475
bb_rcslotrole475:
  %v2368 = load i64, ptr %slot53, align 8
  store i64 %v2368, ptr %slot321, align 8
  %v2369 = load i64, ptr %slot321, align 8
  %v2370 = load i64, ptr %slot318, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2369, i64 %v2370) nomerge, !dbg !144
  br label %bb_rcslotdone475
bb_rcslotowner475:
  %v2371 = load i64, ptr %slot53, align 8
  store i64 %v2371, ptr %slot322, align 8
  %v2372 = load i64, ptr %slot322, align 8
  %v2373 = load i64, ptr %slot318, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2372, i64 %v2373) nomerge, !dbg !144
  br label %bb_rcslotdone475
bb_rcslotdone475:
  %v2374 = load i64, ptr %slot26, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %ld2376 = load i64, ptr %p2375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2376, ptr %slot323, align 8
  %v2377 = load i64, ptr %slot323, align 8
  %op2378 = add i64 %v2377, 32
  store i64 %op2378, ptr %slot324, align 8
  %v2379 = load i64, ptr %slot31, align 8
  store i64 %v2379, ptr %slot325, align 8
  %v2380 = load i64, ptr %slot324, align 8
  %v2381 = load i64, ptr %slot325, align 8
  %p2382 = inttoptr i64 %v2380 to ptr
  %p2383 = inttoptr i64 %v2381 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2383, ptr %p2382, i64 208, i1 false), !alias.scope !10000000
  %v2384 = load i64, ptr %slot324, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  call void @llvm.memset.p0.i64(ptr %p2385, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !144
  %v2386 = load i64, ptr %slot8, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i32 1, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot31, align 8
  %v2389 = load i64, ptr %slot36, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  store i64 %v2388, ptr %p2390, align 8, !alias.scope !3, !noalias !4
  %v2391 = load i64, ptr %slot30, align 8
  %v2392 = load i64, ptr %slot37, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i64 %v2391, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot36, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2396, ptr %slot326, align 8
  %v2397 = load i64, ptr %slot37, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  %ld2399 = load i64, ptr %p2398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2399, ptr %slot327, align 8
  %v2400 = load i64, ptr %slot1, align 8
  %v2401 = load i64, ptr %slot326, align 8
  %v2402 = load i64, ptr %slot327, align 8
  %call2403 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v2400, i64 %v2401, i64 %v2402) nomerge, !dbg !146
  store i64 %call2403, ptr %slot328, align 8
  %v2404 = load i64, ptr %slot328, align 8
  %v2405 = load i64, ptr %slot36, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i64 %v2404, ptr %p2406, align 8, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot14, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  %ld2409 = load i32, ptr %p2408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2409, ptr %slot329, align 8
  %v2410 = load i32, ptr %slot329, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcslotdrop491, label %bb_rcslotdone491
bb_rcslotdrop491:
  %v2413 = load i64, ptr %slot14, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 0, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot21, align 8
  store i64 %v2415, ptr %slot330, align 8
  %v2416 = load i64, ptr %slot15, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %ld2418 = load i32, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2418, ptr %slot331, align 8
  %v2419 = load i32, ptr %slot331, align 8
  %op2420 = and i32 %v2419, 28
  store i32 %op2420, ptr %slot332, align 8
  %v2421 = load i32, ptr %slot332, align 8
  %cv2422 = zext i32 %v2421 to i64
  %cond2423 = icmp ne i64 %cv2422, 0
  br i1 %cond2423, label %bb_rcslotrole491, label %bb_rcslotowner491
bb_rcslotrole491:
  %v2424 = load i64, ptr %slot53, align 8
  store i64 %v2424, ptr %slot333, align 8
  %v2425 = load i64, ptr %slot333, align 8
  %v2426 = load i64, ptr %slot330, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2425, i64 %v2426) nomerge, !dbg !146
  br label %bb_rcslotdone491
bb_rcslotowner491:
  %v2427 = load i64, ptr %slot53, align 8
  store i64 %v2427, ptr %slot334, align 8
  %v2428 = load i64, ptr %slot334, align 8
  %v2429 = load i64, ptr %slot330, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2428, i64 %v2429) nomerge, !dbg !146
  br label %bb_rcslotdone491
bb_rcslotdone491:
  %v2430 = load i64, ptr %slot26, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i64, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2432, ptr %slot335, align 8
  %v2433 = load i64, ptr %slot335, align 8
  %op2434 = add i64 %v2433, 32
  store i64 %op2434, ptr %slot336, align 8
  %v2435 = load i64, ptr %slot31, align 8
  store i64 %v2435, ptr %slot337, align 8
  %v2436 = load i64, ptr %slot337, align 8
  %v2437 = load i64, ptr %slot336, align 8
  %p2438 = inttoptr i64 %v2436 to ptr
  %p2439 = inttoptr i64 %v2437 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2439, ptr %p2438, i64 208, i1 false), !alias.scope !10000000
  %v2440 = load i64, ptr %slot337, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  call void @llvm.memset.p0.i64(ptr %p2441, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !148
  %v2442 = load i64, ptr %slot8, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 0, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot36, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  store i64 0, ptr %p2445, align 8, !alias.scope !3, !noalias !4
  %v2446 = load i64, ptr %slot36, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i64 0, ptr %p2447, align 8, !alias.scope !3, !noalias !4
  %v2448 = load i64, ptr %slot41, align 8
  store i64 %v2448, ptr %slot338, align 8
  %v2449 = load i64, ptr %slot338, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i64 0, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot338, align 8
  %p2453 = inttoptr i64 %v2451 to ptr
  %gep2454 = getelementptr i8, ptr %p2453, i64 8
  %op2452 = ptrtoint ptr %gep2454 to i64
  store i64 %op2452, ptr %slot339, align 8
  %v2455 = load i64, ptr %slot339, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  store i64 0, ptr %p2456, align 8, !alias.scope !3, !noalias !4
  %v2457 = load i64, ptr %slot338, align 8
  %p2459 = inttoptr i64 %v2457 to ptr
  %gep2460 = getelementptr i8, ptr %p2459, i64 16
  %op2458 = ptrtoint ptr %gep2460 to i64
  store i64 %op2458, ptr %slot340, align 8
  %v2461 = load i64, ptr %slot340, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  store i64 0, ptr %p2462, align 8, !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot338, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 0, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  %v2465 = load i64, ptr %slot20, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i32 1, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot36, align 8
  store i64 %v2467, ptr %slot341, align 8
  %v2468 = load i64, ptr %slot338, align 8
  %p2470 = inttoptr i64 %v2468 to ptr
  %gep2471 = getelementptr i8, ptr %p2470, i64 8
  %op2469 = ptrtoint ptr %gep2471 to i64
  store i64 %op2469, ptr %slot342, align 8
  %v2472 = load i64, ptr %slot54, align 8
  store i64 %v2472, ptr %slot343, align 8
  store i64 0, ptr %slot344, align 8
  %v2473 = load i64, ptr %slot338, align 8
  %v2474 = load i64, ptr %slot36, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  store i64 %v2473, ptr %p2475, align 8, !alias.scope !3, !noalias !4
  %v2476 = load i64, ptr %slot36, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %ld2478 = load i64, ptr %p2477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2478, ptr %slot345, align 8
  %v2479 = load i64, ptr %slot21, align 8
  store i64 %v2479, ptr %slot346, align 8
  %v2480 = load i64, ptr %slot345, align 8
  %v2481 = load i64, ptr %slot346, align 8
  %p2482 = inttoptr i64 %v2480 to ptr
  %p2483 = inttoptr i64 %v2481 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2483, ptr %p2482, i64 24, i1 false)
  %v2484 = load i64, ptr %slot15, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i32 2, ptr %p2485, align 4, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot14, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i32 1, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot346, align 8
  %v2489 = load i64, ptr %slot36, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  store i64 %v2488, ptr %p2490, align 8, !alias.scope !3, !noalias !4
  %v2491 = load i64, ptr %slot36, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %ld2493 = load i64, ptr %p2492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2493, ptr %slot347, align 8
  %v2494 = load i64, ptr %slot36, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %ld2496 = load i64, ptr %p2495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2496, ptr %slot348, align 8
  %v2497 = load i64, ptr %slot25, align 8
  store i64 %v2497, ptr %slot349, align 8
  %v2498 = load i64, ptr %slot54, align 8
  store i64 %v2498, ptr %slot350, align 8
  %v2499 = load i64, ptr %slot53, align 8
  %v2500 = load i64, ptr %slot349, align 8
  %v2501 = load i64, ptr %slot348, align 8
  %v2502 = load i64, ptr %slot350, align 8
  %cv2503 = trunc i64 %v2502 to i32
  %call2504 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2499, i64 %v2500, i64 %v2501, i32 %cv2503) nomerge, !dbg !150
  store i32 %call2504, ptr %slot351, align 8
  %v2505 = load i32, ptr %slot351, align 8
  %cv2506 = zext i32 %v2505 to i64
  %cond2507 = icmp ne i64 %cv2506, 0
  br i1 %cond2507, label %bb_rcsuccess520, label %bb_rcfailure520
bb_rcfailure520:
  %v2508 = load i64, ptr %slot53, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  %call2510 = call i32 @myl_rc_take_failure(ptr %p2509) nomerge, !dbg !150
  store i32 %call2510, ptr %slot352, align 8
  %v2511 = load i64, ptr %slot1, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %v2513 = load i32, ptr %slot352, align 8
  %call2514 = call i32 @myl_qbe_rc_status(ptr %p2512, i32 %v2513) nomerge, !dbg !150
  store i32 %call2514, ptr %slot353, align 8
  br label %bb_failure
bb_rcsuccess520:
  %v2515 = load i64, ptr %slot14, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  store i32 0, ptr %p2516, align 4, !alias.scope !3, !noalias !4
  %v2517 = load i64, ptr %slot19, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 2, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot18, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 1, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot25, align 8
  store i64 %v2521, ptr %slot354, align 8
  %v2522 = load i64, ptr %slot18, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i32 0, ptr %p2523, align 4, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot14, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %ld2526 = load i32, ptr %p2525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2526, ptr %slot355, align 8
  %v2527 = load i32, ptr %slot355, align 8
  %cv2528 = zext i32 %v2527 to i64
  %cond2529 = icmp ne i64 %cv2528, 0
  br i1 %cond2529, label %bb_rcslotdrop530, label %bb_rcslotdone530
bb_rcslotdrop530:
  %v2530 = load i64, ptr %slot14, align 8
  %p2531 = inttoptr i64 %v2530 to ptr
  store i32 0, ptr %p2531, align 4, !alias.scope !3, !noalias !4
  %v2532 = load i64, ptr %slot21, align 8
  store i64 %v2532, ptr %slot356, align 8
  %v2533 = load i64, ptr %slot15, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i32, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2535, ptr %slot357, align 8
  %v2536 = load i32, ptr %slot357, align 8
  %op2537 = and i32 %v2536, 28
  store i32 %op2537, ptr %slot358, align 8
  %v2538 = load i32, ptr %slot358, align 8
  %cv2539 = zext i32 %v2538 to i64
  %cond2540 = icmp ne i64 %cv2539, 0
  br i1 %cond2540, label %bb_rcslotrole530, label %bb_rcslotowner530
bb_rcslotrole530:
  %v2541 = load i64, ptr %slot53, align 8
  store i64 %v2541, ptr %slot359, align 8
  %v2542 = load i64, ptr %slot359, align 8
  %v2543 = load i64, ptr %slot356, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2542, i64 %v2543) nomerge, !dbg !150
  br label %bb_rcslotdone530
bb_rcslotowner530:
  %v2544 = load i64, ptr %slot53, align 8
  store i64 %v2544, ptr %slot360, align 8
  %v2545 = load i64, ptr %slot360, align 8
  %v2546 = load i64, ptr %slot356, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2545, i64 %v2546) nomerge, !dbg !150
  br label %bb_rcslotdone530
bb_rcslotdone530:
  %v2547 = load i64, ptr %slot12, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  %ld2549 = load i32, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2549, ptr %slot361, align 8
  %v2550 = load i32, ptr %slot361, align 8
  %cv2551 = zext i32 %v2550 to i64
  %cond2552 = icmp ne i64 %cv2551, 0
  br i1 %cond2552, label %bb_rcslotdrop557, label %bb_rcslotdone557
bb_rcslotdrop557:
  %v2553 = load i64, ptr %slot12, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  store i32 0, ptr %p2554, align 4, !alias.scope !3, !noalias !4
  %v2555 = load i64, ptr %slot35, align 8
  store i64 %v2555, ptr %slot362, align 8
  %v2556 = load i64, ptr %slot13, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i32, ptr %p2557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2558, ptr %slot363, align 8
  %v2559 = load i32, ptr %slot363, align 8
  %op2560 = and i32 %v2559, 28
  store i32 %op2560, ptr %slot364, align 8
  %v2561 = load i32, ptr %slot364, align 8
  %cv2562 = zext i32 %v2561 to i64
  %cond2563 = icmp ne i64 %cv2562, 0
  br i1 %cond2563, label %bb_rcslotrole557, label %bb_rcslotowner557
bb_rcslotrole557:
  %v2564 = load i64, ptr %slot53, align 8
  store i64 %v2564, ptr %slot365, align 8
  %v2565 = load i64, ptr %slot365, align 8
  %v2566 = load i64, ptr %slot362, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2565, i64 %v2566) nomerge, !dbg !150
  br label %bb_rcslotdone557
bb_rcslotowner557:
  %v2567 = load i64, ptr %slot53, align 8
  store i64 %v2567, ptr %slot366, align 8
  %v2568 = load i64, ptr %slot366, align 8
  %v2569 = load i64, ptr %slot362, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2568, i64 %v2569) nomerge, !dbg !150
  br label %bb_rcslotdone557
bb_rcslotdone557:
  %v2570 = load i64, ptr %slot10, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  %ld2572 = load i32, ptr %p2571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2572, ptr %slot367, align 8
  %v2573 = load i32, ptr %slot367, align 8
  %cv2574 = zext i32 %v2573 to i64
  %cond2575 = icmp ne i64 %cv2574, 0
  br i1 %cond2575, label %bb_rcslotdrop584, label %bb_rcslotdone584
bb_rcslotdrop584:
  %v2576 = load i64, ptr %slot10, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  store i32 0, ptr %p2577, align 4, !alias.scope !3, !noalias !4
  %v2578 = load i64, ptr %slot33, align 8
  store i64 %v2578, ptr %slot368, align 8
  %v2579 = load i64, ptr %slot11, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  %ld2581 = load i32, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2581, ptr %slot369, align 8
  %v2582 = load i32, ptr %slot369, align 8
  %op2583 = and i32 %v2582, 28
  store i32 %op2583, ptr %slot370, align 8
  %v2584 = load i32, ptr %slot370, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcslotrole584, label %bb_rcslotowner584
bb_rcslotrole584:
  %v2587 = load i64, ptr %slot53, align 8
  store i64 %v2587, ptr %slot371, align 8
  %v2588 = load i64, ptr %slot371, align 8
  %v2589 = load i64, ptr %slot368, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2588, i64 %v2589) nomerge, !dbg !150
  br label %bb_rcslotdone584
bb_rcslotowner584:
  %v2590 = load i64, ptr %slot53, align 8
  store i64 %v2590, ptr %slot372, align 8
  %v2591 = load i64, ptr %slot372, align 8
  %v2592 = load i64, ptr %slot368, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2591, i64 %v2592) nomerge, !dbg !150
  br label %bb_rcslotdone584
bb_rcslotdone584:
  %v2593 = load i64, ptr %slot8, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %ld2595 = load i32, ptr %p2594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2595, ptr %slot373, align 8
  %v2596 = load i32, ptr %slot373, align 8
  %cv2597 = zext i32 %v2596 to i64
  %cond2598 = icmp ne i64 %cv2597, 0
  br i1 %cond2598, label %bb_rcslotdrop611, label %bb_rcslotdone611
bb_rcslotdrop611:
  %v2599 = load i64, ptr %slot8, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  store i32 0, ptr %p2600, align 4, !alias.scope !3, !noalias !4
  %v2601 = load i64, ptr %slot31, align 8
  store i64 %v2601, ptr %slot374, align 8
  %v2602 = load i64, ptr %slot9, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  %ld2604 = load i32, ptr %p2603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2604, ptr %slot375, align 8
  %v2605 = load i32, ptr %slot375, align 8
  %op2606 = and i32 %v2605, 28
  store i32 %op2606, ptr %slot376, align 8
  %v2607 = load i32, ptr %slot376, align 8
  %cv2608 = zext i32 %v2607 to i64
  %cond2609 = icmp ne i64 %cv2608, 0
  br i1 %cond2609, label %bb_rcslotrole611, label %bb_rcslotowner611
bb_rcslotrole611:
  %v2610 = load i64, ptr %slot53, align 8
  store i64 %v2610, ptr %slot377, align 8
  %v2611 = load i64, ptr %slot377, align 8
  %v2612 = load i64, ptr %slot374, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2611, i64 %v2612) nomerge, !dbg !150
  br label %bb_rcslotdone611
bb_rcslotowner611:
  %v2613 = load i64, ptr %slot53, align 8
  store i64 %v2613, ptr %slot378, align 8
  %v2614 = load i64, ptr %slot378, align 8
  %v2615 = load i64, ptr %slot374, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2614, i64 %v2615) nomerge, !dbg !150
  br label %bb_rcslotdone611
bb_rcslotdone611:
  %v2616 = load i64, ptr %slot6, align 8
  %p2617 = inttoptr i64 %v2616 to ptr
  %ld2618 = load i32, ptr %p2617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2618, ptr %slot379, align 8
  %v2619 = load i32, ptr %slot379, align 8
  %cv2620 = zext i32 %v2619 to i64
  %cond2621 = icmp ne i64 %cv2620, 0
  br i1 %cond2621, label %bb_rcslotdrop620, label %bb_rcslotdone620
bb_rcslotdrop620:
  %v2622 = load i64, ptr %slot6, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  store i32 0, ptr %p2623, align 4, !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot28, align 8
  store i64 %v2624, ptr %slot380, align 8
  %v2625 = load i64, ptr %slot7, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  %ld2627 = load i32, ptr %p2626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2627, ptr %slot381, align 8
  %v2628 = load i32, ptr %slot381, align 8
  %op2629 = and i32 %v2628, 28
  store i32 %op2629, ptr %slot382, align 8
  %v2630 = load i32, ptr %slot382, align 8
  %cv2631 = zext i32 %v2630 to i64
  %cond2632 = icmp ne i64 %cv2631, 0
  br i1 %cond2632, label %bb_rcslotrole620, label %bb_rcslotowner620
bb_rcslotrole620:
  %v2633 = load i64, ptr %slot53, align 8
  store i64 %v2633, ptr %slot383, align 8
  %v2634 = load i64, ptr %slot383, align 8
  %v2635 = load i64, ptr %slot380, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2634, i64 %v2635) nomerge, !dbg !150
  br label %bb_rcslotdone620
bb_rcslotowner620:
  %v2636 = load i64, ptr %slot53, align 8
  store i64 %v2636, ptr %slot384, align 8
  %v2637 = load i64, ptr %slot384, align 8
  %v2638 = load i64, ptr %slot380, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2637, i64 %v2638) nomerge, !dbg !150
  br label %bb_rcslotdone620
bb_rcslotdone620:
  %v2639 = load i64, ptr %slot354, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2640, i64 24, i1 false)
  ret void
bb_i53:
  br label %bb_i54
bb_i54:
  %v2641 = load i64, ptr %slot26, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %ld2643 = load i64, ptr %p2642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2643, ptr %slot385, align 8
  %v2644 = load i64, ptr %slot385, align 8
  %v2645 = load i64, ptr %slot36, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i64 %v2644, ptr %p2646, align 8, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot36, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %ld2649 = load i64, ptr %p2648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2649, ptr %slot386, align 8
  %v2650 = load i64, ptr %slot386, align 8
  %op2651 = add i64 %v2650, 32
  store i64 %op2651, ptr %slot387, align 8
  %v2652 = load i64, ptr %slot387, align 8
  %v2653 = load i64, ptr %slot36, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  store i64 %v2652, ptr %p2654, align 8, !alias.scope !3, !noalias !4
  %v2655 = load i64, ptr %slot14, align 8
  %p2656 = inttoptr i64 %v2655 to ptr
  %ld2657 = load i32, ptr %p2656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2657, ptr %slot388, align 8
  %v2658 = load i32, ptr %slot388, align 8
  %cv2659 = zext i32 %v2658 to i64
  %cond2660 = icmp ne i64 %cv2659, 0
  br i1 %cond2660, label %bb_rcslotdrop650, label %bb_rcslotdone650
bb_rcslotdrop650:
  %v2661 = load i64, ptr %slot14, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  store i32 0, ptr %p2662, align 4, !alias.scope !3, !noalias !4
  %v2663 = load i64, ptr %slot21, align 8
  store i64 %v2663, ptr %slot389, align 8
  %v2664 = load i64, ptr %slot15, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  %ld2666 = load i32, ptr %p2665, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2666, ptr %slot390, align 8
  %v2667 = load i32, ptr %slot390, align 8
  %op2668 = and i32 %v2667, 28
  store i32 %op2668, ptr %slot391, align 8
  %v2669 = load i32, ptr %slot391, align 8
  %cv2670 = zext i32 %v2669 to i64
  %cond2671 = icmp ne i64 %cv2670, 0
  br i1 %cond2671, label %bb_rcslotrole650, label %bb_rcslotowner650
bb_rcslotrole650:
  %v2672 = load i64, ptr %slot53, align 8
  store i64 %v2672, ptr %slot392, align 8
  %v2673 = load i64, ptr %slot392, align 8
  %v2674 = load i64, ptr %slot389, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2673, i64 %v2674) nomerge, !dbg !152
  br label %bb_rcslotdone650
bb_rcslotowner650:
  %v2675 = load i64, ptr %slot53, align 8
  store i64 %v2675, ptr %slot393, align 8
  %v2676 = load i64, ptr %slot393, align 8
  %v2677 = load i64, ptr %slot389, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2676, i64 %v2677) nomerge, !dbg !152
  br label %bb_rcslotdone650
bb_rcslotdone650:
  %v2678 = load i64, ptr %slot28, align 8
  %v2679 = load i64, ptr %slot37, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  store i64 %v2678, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  %v2681 = load i64, ptr %slot37, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  %ld2683 = load i64, ptr %p2682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2683, ptr %slot394, align 8
  %v2684 = load i64, ptr %slot394, align 8
  %op2685 = add i64 %v2684, 0
  store i64 %op2685, ptr %slot395, align 8
  %v2686 = load i64, ptr %slot395, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  %ld2688 = load i64, ptr %p2687, align 8
  store i64 %ld2688, ptr %slot396, align 8
  %v2689 = load i64, ptr %slot396, align 8
  %v2690 = load i64, ptr %slot37, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i64 %v2689, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot16, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  %ld2694 = load i32, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2694, ptr %slot397, align 8
  %v2695 = load i32, ptr %slot397, align 8
  %cv2696 = zext i32 %v2695 to i64
  %cond2697 = icmp ne i64 %cv2696, 0
  br i1 %cond2697, label %bb_rcslotdrop662, label %bb_rcslotdone662
bb_rcslotdrop662:
  %v2698 = load i64, ptr %slot16, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 0, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  %v2700 = load i64, ptr %slot22, align 8
  store i64 %v2700, ptr %slot398, align 8
  %v2701 = load i64, ptr %slot17, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  %ld2703 = load i32, ptr %p2702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2703, ptr %slot399, align 8
  %v2704 = load i32, ptr %slot399, align 8
  %op2705 = and i32 %v2704, 28
  store i32 %op2705, ptr %slot400, align 8
  %v2706 = load i32, ptr %slot400, align 8
  %cv2707 = zext i32 %v2706 to i64
  %cond2708 = icmp ne i64 %cv2707, 0
  br i1 %cond2708, label %bb_rcslotrole662, label %bb_rcslotowner662
bb_rcslotrole662:
  %v2709 = load i64, ptr %slot53, align 8
  store i64 %v2709, ptr %slot401, align 8
  %v2710 = load i64, ptr %slot401, align 8
  %v2711 = load i64, ptr %slot398, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2710, i64 %v2711) nomerge, !dbg !154
  br label %bb_rcslotdone662
bb_rcslotowner662:
  %v2712 = load i64, ptr %slot53, align 8
  store i64 %v2712, ptr %slot402, align 8
  %v2713 = load i64, ptr %slot402, align 8
  %v2714 = load i64, ptr %slot398, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2713, i64 %v2714) nomerge, !dbg !154
  br label %bb_rcslotdone662
bb_rcslotdone662:
  %v2715 = load i64, ptr %slot36, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %ld2717 = load i64, ptr %p2716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2717, ptr %slot403, align 8
  %v2718 = load i64, ptr %slot37, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  %ld2720 = load i64, ptr %p2719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2720, ptr %slot404, align 8
  %v2721 = load i64, ptr %slot1, align 8
  %v2722 = load i64, ptr %slot403, align 8
  %v2723 = load i64, ptr %slot404, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult406, i64 %v2721, i64 %v2722, i64 %v2723) nomerge, !dbg !156
  %addr2724 = ptrtoint ptr %callresult406 to i64
  store i64 %addr2724, ptr %slot405, align 8
  %v2725 = load i64, ptr %slot405, align 8
  %v2726 = load i64, ptr %slot36, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i64 %v2725, ptr %p2727, align 8, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot36, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2730, ptr %slot407, align 8
  %v2731 = load i64, ptr %slot25, align 8
  store i64 %v2731, ptr %slot408, align 8
  %v2732 = load i64, ptr %slot407, align 8
  %v2733 = load i64, ptr %slot408, align 8
  %p2734 = inttoptr i64 %v2732 to ptr
  %p2735 = inttoptr i64 %v2733 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2735, ptr %p2734, i64 24, i1 false)
  %v2736 = load i64, ptr %slot19, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  store i32 2, ptr %p2737, align 4, !alias.scope !3, !noalias !4
  %v2738 = load i64, ptr %slot18, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  store i32 1, ptr %p2739, align 4, !alias.scope !3, !noalias !4
  %v2740 = load i64, ptr %slot14, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  %ld2742 = load i32, ptr %p2741, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2742, ptr %slot409, align 8
  %v2743 = load i32, ptr %slot409, align 8
  %cv2744 = zext i32 %v2743 to i64
  %cond2745 = icmp ne i64 %cv2744, 0
  br i1 %cond2745, label %bb_rcslotdrop678, label %bb_rcslotdone678
bb_rcslotdrop678:
  %v2746 = load i64, ptr %slot14, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  store i32 0, ptr %p2747, align 4, !alias.scope !3, !noalias !4
  %v2748 = load i64, ptr %slot21, align 8
  store i64 %v2748, ptr %slot410, align 8
  %v2749 = load i64, ptr %slot15, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %ld2751 = load i32, ptr %p2750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2751, ptr %slot411, align 8
  %v2752 = load i32, ptr %slot411, align 8
  %op2753 = and i32 %v2752, 28
  store i32 %op2753, ptr %slot412, align 8
  %v2754 = load i32, ptr %slot412, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcslotrole678, label %bb_rcslotowner678
bb_rcslotrole678:
  %v2757 = load i64, ptr %slot53, align 8
  store i64 %v2757, ptr %slot413, align 8
  %v2758 = load i64, ptr %slot413, align 8
  %v2759 = load i64, ptr %slot410, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2758, i64 %v2759) nomerge, !dbg !156
  br label %bb_rcslotdone678
bb_rcslotowner678:
  %v2760 = load i64, ptr %slot53, align 8
  store i64 %v2760, ptr %slot414, align 8
  %v2761 = load i64, ptr %slot414, align 8
  %v2762 = load i64, ptr %slot410, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2761, i64 %v2762) nomerge, !dbg !156
  br label %bb_rcslotdone678
bb_rcslotdone678:
  %v2763 = load i64, ptr %slot21, align 8
  store i64 %v2763, ptr %slot415, align 8
  %v2764 = load i64, ptr %slot25, align 8
  store i64 %v2764, ptr %slot416, align 8
  %v2765 = load i64, ptr %slot416, align 8
  %v2766 = load i64, ptr %slot415, align 8
  %p2767 = inttoptr i64 %v2765 to ptr
  %p2768 = inttoptr i64 %v2766 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2768, ptr %p2767, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2769 = load i64, ptr %slot15, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  store i32 2, ptr %p2770, align 4, !alias.scope !3, !noalias !4
  %v2771 = load i64, ptr %slot19, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  %ld2773 = load i32, ptr %p2772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2773, ptr %slot417, align 8
  %v2774 = load i32, ptr %slot417, align 8
  %v2775 = load i64, ptr %slot15, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i32 %v2774, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot18, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  store i32 0, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot14, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  store i32 1, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  %v2781 = load i64, ptr %slot415, align 8
  %v2782 = load i64, ptr %slot36, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i64 %v2781, ptr %p2783, align 8, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot36, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  %ld2786 = load i64, ptr %p2785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2786, ptr %slot418, align 8
  %v2787 = load i64, ptr %slot418, align 8
  %op2788 = add i64 %v2787, 8
  store i64 %op2788, ptr %slot419, align 8
  %v2789 = load i64, ptr %slot419, align 8
  %v2790 = load i64, ptr %slot36, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  store i64 %v2789, ptr %p2791, align 8, !alias.scope !3, !noalias !4
  %v2792 = load i64, ptr %slot36, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  %ld2794 = load i64, ptr %p2793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2794, ptr %slot420, align 8
  %v2795 = load i64, ptr %slot25, align 8
  store i64 %v2795, ptr %slot421, align 8
  %v2796 = load i64, ptr %slot53, align 8
  %v2797 = load i64, ptr %slot421, align 8
  %v2798 = load i64, ptr %slot420, align 8
  %call2799 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v2796, i64 %v2797, i64 %v2798) nomerge, !dbg !158
  store i32 %call2799, ptr %slot422, align 8
  %v2800 = load i32, ptr %slot422, align 8
  %cv2801 = zext i32 %v2800 to i64
  %cond2802 = icmp ne i64 %cv2801, 0
  br i1 %cond2802, label %bb_rcsuccess698, label %bb_rcfailure698
bb_rcfailure698:
  %v2803 = load i64, ptr %slot53, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  %call2805 = call i32 @myl_rc_take_failure(ptr %p2804) nomerge, !dbg !158
  store i32 %call2805, ptr %slot423, align 8
  %v2806 = load i64, ptr %slot1, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %v2808 = load i32, ptr %slot423, align 8
  %call2809 = call i32 @myl_qbe_rc_status(ptr %p2807, i32 %v2808) nomerge, !dbg !158
  store i32 %call2809, ptr %slot424, align 8
  br label %bb_failure
bb_rcsuccess698:
  %v2810 = load i64, ptr %slot19, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 2, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot19, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i32 16, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  %v2814 = load i64, ptr %slot18, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  store i32 1, ptr %p2815, align 4, !alias.scope !3, !noalias !4
  %v2816 = load i64, ptr %slot14, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  %ld2818 = load i32, ptr %p2817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2818, ptr %slot425, align 8
  %v2819 = load i32, ptr %slot425, align 8
  %cv2820 = zext i32 %v2819 to i64
  %cond2821 = icmp ne i64 %cv2820, 0
  br i1 %cond2821, label %bb_rcslotdrop706, label %bb_rcslotdone706
bb_rcslotdrop706:
  %v2822 = load i64, ptr %slot14, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  store i32 0, ptr %p2823, align 4, !alias.scope !3, !noalias !4
  %v2824 = load i64, ptr %slot21, align 8
  store i64 %v2824, ptr %slot426, align 8
  %v2825 = load i64, ptr %slot15, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  %ld2827 = load i32, ptr %p2826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2827, ptr %slot427, align 8
  %v2828 = load i32, ptr %slot427, align 8
  %op2829 = and i32 %v2828, 28
  store i32 %op2829, ptr %slot428, align 8
  %v2830 = load i32, ptr %slot428, align 8
  %cv2831 = zext i32 %v2830 to i64
  %cond2832 = icmp ne i64 %cv2831, 0
  br i1 %cond2832, label %bb_rcslotrole706, label %bb_rcslotowner706
bb_rcslotrole706:
  %v2833 = load i64, ptr %slot53, align 8
  store i64 %v2833, ptr %slot429, align 8
  %v2834 = load i64, ptr %slot429, align 8
  %v2835 = load i64, ptr %slot426, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2834, i64 %v2835) nomerge, !dbg !158
  br label %bb_rcslotdone706
bb_rcslotowner706:
  %v2836 = load i64, ptr %slot53, align 8
  store i64 %v2836, ptr %slot430, align 8
  %v2837 = load i64, ptr %slot430, align 8
  %v2838 = load i64, ptr %slot426, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2837, i64 %v2838) nomerge, !dbg !158
  br label %bb_rcslotdone706
bb_rcslotdone706:
  %v2839 = load i64, ptr %slot21, align 8
  store i64 %v2839, ptr %slot431, align 8
  %v2840 = load i64, ptr %slot25, align 8
  store i64 %v2840, ptr %slot432, align 8
  %v2841 = load i64, ptr %slot432, align 8
  %v2842 = load i64, ptr %slot431, align 8
  %p2843 = inttoptr i64 %v2841 to ptr
  %p2844 = inttoptr i64 %v2842 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2844, ptr %p2843, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2845 = load i64, ptr %slot15, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  store i32 2, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  %v2847 = load i64, ptr %slot19, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i32, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2849, ptr %slot433, align 8
  %v2850 = load i32, ptr %slot433, align 8
  %v2851 = load i64, ptr %slot15, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i32 %v2850, ptr %p2852, align 4, !alias.scope !3, !noalias !4
  %v2853 = load i64, ptr %slot18, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 0, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot14, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i32 1, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot431, align 8
  %v2858 = load i64, ptr %slot36, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i64 %v2857, ptr %p2859, align 8, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot27, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %ld2862 = load i64, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2862, ptr %slot434, align 8
  %v2863 = load i64, ptr %slot434, align 8
  %v2864 = load i64, ptr %slot37, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i64 %v2863, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot37, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  %ld2868 = load i64, ptr %p2867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2868, ptr %slot435, align 8
  %v2869 = load i64, ptr %slot435, align 8
  %op2870 = add i64 %v2869, 48
  store i64 %op2870, ptr %slot436, align 8
  %v2871 = load i64, ptr %slot436, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  %ld2873 = load i64, ptr %p2872, align 8
  store i64 %ld2873, ptr %slot437, align 8
  %v2874 = load i64, ptr %slot437, align 8
  %v2875 = load i64, ptr %slot37, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  store i64 %v2874, ptr %p2876, align 8, !alias.scope !3, !noalias !4
  %v2877 = load i64, ptr %slot16, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i32, ptr %p2878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2879, ptr %slot438, align 8
  %v2880 = load i32, ptr %slot438, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcslotdrop727, label %bb_rcslotdone727
bb_rcslotdrop727:
  %v2883 = load i64, ptr %slot16, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i32 0, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot22, align 8
  store i64 %v2885, ptr %slot439, align 8
  %v2886 = load i64, ptr %slot17, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %ld2888 = load i32, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2888, ptr %slot440, align 8
  %v2889 = load i32, ptr %slot440, align 8
  %op2890 = and i32 %v2889, 28
  store i32 %op2890, ptr %slot441, align 8
  %v2891 = load i32, ptr %slot441, align 8
  %cv2892 = zext i32 %v2891 to i64
  %cond2893 = icmp ne i64 %cv2892, 0
  br i1 %cond2893, label %bb_rcslotrole727, label %bb_rcslotowner727
bb_rcslotrole727:
  %v2894 = load i64, ptr %slot53, align 8
  store i64 %v2894, ptr %slot442, align 8
  %v2895 = load i64, ptr %slot442, align 8
  %v2896 = load i64, ptr %slot439, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v2895, i64 %v2896) nomerge, !dbg !160
  br label %bb_rcslotdone727
bb_rcslotowner727:
  %v2897 = load i64, ptr %slot53, align 8
  store i64 %v2897, ptr %slot443, align 8
  %v2898 = load i64, ptr %slot443, align 8
  %v2899 = load i64, ptr %slot439, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v2898, i64 %v2899) nomerge, !dbg !160
  br label %bb_rcslotdone727
bb_rcslotdone727:
  %v2900 = load i64, ptr %slot29, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  %ld2902 = load i64, ptr %p2901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2902, ptr %slot444, align 8
  %v2903 = load i64, ptr %slot444, align 8
  %v2904 = load i64, ptr %slot38, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  store i64 %v2903, ptr %p2905, align 8, !alias.scope !3, !noalias !4
  %v2906 = load i64, ptr %slot36, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %ld2908 = load i64, ptr %p2907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2908, ptr %slot445, align 8
  %v2909 = load i64, ptr %slot37, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  %ld2911 = load i64, ptr %p2910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2911, ptr %slot446, align 8
  %v2912 = load i64, ptr %slot38, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  %ld2914 = load i64, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2914, ptr %slot447, align 8
  %v2915 = load i64, ptr %slot1, align 8
  %v2916 = load i64, ptr %slot445, align 8
  %v2917 = load i64, ptr %slot446, align 8
  %v2918 = load i64, ptr %slot447, align 8
  call void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %callresult449, i64 %v2915, i64 %v2916, i64 %v2917, i64 %v2918) nomerge, !dbg !162
  %addr2919 = ptrtoint ptr %callresult449 to i64
  store i64 %addr2919, ptr %slot448, align 8
  %v2920 = load i64, ptr %slot448, align 8
  %v2921 = load i64, ptr %slot36, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  store i64 %v2920, ptr %p2922, align 8, !alias.scope !3, !noalias !4
  %v2923 = load i64, ptr %slot14, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %ld2925 = load i32, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2925, ptr %slot450, align 8
  %v2926 = load i32, ptr %slot450, align 8
  %cv2927 = zext i32 %v2926 to i64
  %cond2928 = icmp ne i64 %cv2927, 0
  br i1 %cond2928, label %bb_rcslotdrop741, label %bb_rcslotdone741
bb_rcslotdrop741:
  %v2929 = load i64, ptr %slot14, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  store i32 0, ptr %p2930, align 4, !alias.scope !3, !noalias !4
  %v2931 = load i64, ptr %slot21, align 8
  store i64 %v2931, ptr %slot451, align 8
  %v2932 = load i64, ptr %slot15, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %ld2934 = load i32, ptr %p2933, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2934, ptr %slot452, align 8
  %v2935 = load i32, ptr %slot452, align 8
  %op2936 = and i32 %v2935, 28
  store i32 %op2936, ptr %slot453, align 8
  %v2937 = load i32, ptr %slot453, align 8
  %cv2938 = zext i32 %v2937 to i64
  %cond2939 = icmp ne i64 %cv2938, 0
  br i1 %cond2939, label %bb_rcslotrole741, label %bb_rcslotowner741
bb_rcslotrole741:
  %v2940 = load i64, ptr %slot53, align 8
  store i64 %v2940, ptr %slot454, align 8
  %v2941 = load i64, ptr %slot454, align 8
  %v2942 = load i64, ptr %slot451, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2941, i64 %v2942) nomerge, !dbg !162
  br label %bb_rcslotdone741
bb_rcslotowner741:
  %v2943 = load i64, ptr %slot53, align 8
  store i64 %v2943, ptr %slot455, align 8
  %v2944 = load i64, ptr %slot455, align 8
  %v2945 = load i64, ptr %slot451, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2944, i64 %v2945) nomerge, !dbg !162
  br label %bb_rcslotdone741
bb_rcslotdone741:
  %v2946 = load i64, ptr %slot36, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %ld2948 = load i64, ptr %p2947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2948, ptr %slot456, align 8
  %v2949 = load i64, ptr %slot456, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %ld2951 = load i32, ptr %p2950, align 4
  %ext2952 = zext i32 %ld2951 to i64
  store i64 %ext2952, ptr %slot457, align 8
  %v2953 = load i64, ptr %slot457, align 8
  %cmp2954 = icmp eq i64 %v2953, 0
  %cv2955 = zext i1 %cmp2954 to i64
  store i64 %cv2955, ptr %slot458, align 8
  %v2956 = load i64, ptr %slot458, align 8
  %cond2957 = icmp ne i64 %v2956, 0
  br i1 %cond2957, label %bb_rcarm750, label %bb_rcarmnext750
bb_rcarm750:
  br label %bb_i115
bb_rcarmnext750:
  %v2958 = load i64, ptr %slot457, align 8
  %cmp2959 = icmp eq i64 %v2958, 1
  %cv2960 = zext i1 %cmp2959 to i64
  store i64 %cv2960, ptr %slot459, align 8
  %v2961 = load i64, ptr %slot459, align 8
  %cond2962 = icmp ne i64 %v2961, 0
  br i1 %cond2962, label %bb_rcarm751, label %bb_rcarmnext751
bb_rcarm751:
  %v2963 = load i64, ptr %slot25, align 8
  store i64 %v2963, ptr %slot460, align 8
  %v2964 = load i64, ptr %slot456, align 8
  %op2965 = add i64 %v2964, 8
  store i64 %op2965, ptr %slot461, align 8
  %v2966 = load i64, ptr %slot54, align 8
  store i64 %v2966, ptr %slot462, align 8
  %v2967 = load i64, ptr %slot461, align 8
  %v2968 = load i64, ptr %slot460, align 8
  %p2969 = inttoptr i64 %v2967 to ptr
  %p2970 = inttoptr i64 %v2968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2970, ptr %p2969, i64 16, i1 false)
  %v2971 = load i64, ptr %slot19, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  store i32 0, ptr %p2972, align 4, !alias.scope !3, !noalias !4
  %v2973 = load i64, ptr %slot18, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  store i32 1, ptr %p2974, align 4, !alias.scope !3, !noalias !4
  %v2975 = load i64, ptr %slot460, align 8
  %v2976 = load i64, ptr %slot32, align 8
  %p2977 = inttoptr i64 %v2975 to ptr
  %p2978 = inttoptr i64 %v2976 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2978, ptr %p2977, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2979 = load i64, ptr %slot18, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i32 0, ptr %p2980, align 4, !alias.scope !3, !noalias !4
  br label %bb_i65
bb_rcarmnext751:
  br label %bb_failure
bb_i65:
  %v2981 = load i64, ptr %slot26, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %ld2983 = load i64, ptr %p2982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2983, ptr %slot463, align 8
  %v2984 = load i64, ptr %slot463, align 8
  %v2985 = load i64, ptr %slot42, align 8
  %p2986 = inttoptr i64 %v2984 to ptr
  %p2987 = inttoptr i64 %v2985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2987, ptr %p2986, i64 304, i1 false), !alias.scope !10000000
  %v2988 = load i64, ptr %slot42, align 8
  %v2989 = load i64, ptr %slot36, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  store i64 %v2988, ptr %p2990, align 8, !alias.scope !3, !noalias !4
  %v2991 = load i64, ptr %slot36, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  %ld2993 = load i64, ptr %p2992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2993, ptr %slot464, align 8
  %v2994 = load i64, ptr %slot464, align 8
  %op2995 = add i64 %v2994, 32
  store i64 %op2995, ptr %slot465, align 8
  %v2996 = load i64, ptr %slot465, align 8
  %v2997 = load i64, ptr %slot36, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  store i64 %v2996, ptr %p2998, align 8, !alias.scope !3, !noalias !4
  %v2999 = load i64, ptr %slot10, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  %ld3001 = load i32, ptr %p3000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3001, ptr %slot466, align 8
  %v3002 = load i32, ptr %slot466, align 8
  %cv3003 = zext i32 %v3002 to i64
  %cond3004 = icmp ne i64 %cv3003, 0
  br i1 %cond3004, label %bb_rcslotdrop763, label %bb_rcslotdone763
bb_rcslotdrop763:
  %v3005 = load i64, ptr %slot10, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  store i32 0, ptr %p3006, align 4, !alias.scope !3, !noalias !4
  %v3007 = load i64, ptr %slot33, align 8
  store i64 %v3007, ptr %slot467, align 8
  %v3008 = load i64, ptr %slot11, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  %ld3010 = load i32, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3010, ptr %slot468, align 8
  %v3011 = load i32, ptr %slot468, align 8
  %op3012 = and i32 %v3011, 28
  store i32 %op3012, ptr %slot469, align 8
  %v3013 = load i32, ptr %slot469, align 8
  %cv3014 = zext i32 %v3013 to i64
  %cond3015 = icmp ne i64 %cv3014, 0
  br i1 %cond3015, label %bb_rcslotrole763, label %bb_rcslotowner763
bb_rcslotrole763:
  %v3016 = load i64, ptr %slot53, align 8
  store i64 %v3016, ptr %slot470, align 8
  %v3017 = load i64, ptr %slot470, align 8
  %v3018 = load i64, ptr %slot467, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3017, i64 %v3018) nomerge, !dbg !164
  br label %bb_rcslotdone763
bb_rcslotowner763:
  %v3019 = load i64, ptr %slot53, align 8
  store i64 %v3019, ptr %slot471, align 8
  %v3020 = load i64, ptr %slot471, align 8
  %v3021 = load i64, ptr %slot467, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3020, i64 %v3021) nomerge, !dbg !164
  br label %bb_rcslotdone763
bb_rcslotdone763:
  %v3022 = load i64, ptr %slot26, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %ld3024 = load i64, ptr %p3023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3024, ptr %slot472, align 8
  %v3025 = load i64, ptr %slot472, align 8
  %op3026 = add i64 %v3025, 32
  store i64 %op3026, ptr %slot473, align 8
  %v3027 = load i64, ptr %slot33, align 8
  store i64 %v3027, ptr %slot474, align 8
  %v3028 = load i64, ptr %slot473, align 8
  %v3029 = load i64, ptr %slot474, align 8
  %p3030 = inttoptr i64 %v3028 to ptr
  %p3031 = inttoptr i64 %v3029 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3031, ptr %p3030, i64 208, i1 false), !alias.scope !10000000
  %v3032 = load i64, ptr %slot473, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  call void @llvm.memset.p0.i64(ptr %p3033, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !164
  %v3034 = load i64, ptr %slot10, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  store i32 1, ptr %p3035, align 4, !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot33, align 8
  %v3037 = load i64, ptr %slot36, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  store i64 %v3036, ptr %p3038, align 8, !alias.scope !3, !noalias !4
  %v3039 = load i64, ptr %slot33, align 8
  %v3040 = load i64, ptr %slot43, align 8
  %p3041 = inttoptr i64 %v3039 to ptr
  %p3042 = inttoptr i64 %v3040 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3042, ptr %p3041, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v3043 = load i64, ptr %slot43, align 8
  %v3044 = load i64, ptr %slot37, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  store i64 %v3043, ptr %p3045, align 8, !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot38, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i64 0, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot37, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i64, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3050, ptr %slot475, align 8
  %v3051 = load i64, ptr %slot38, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %ld3053 = load i64, ptr %p3052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3053, ptr %slot476, align 8
  %v3054 = load i64, ptr %slot1, align 8
  %v3055 = load i64, ptr %slot475, align 8
  %v3056 = load i64, ptr %slot476, align 8
  %call3057 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v3054, i64 %v3055, i64 %v3056) nomerge, !dbg !166
  store { i64, i64 } %call3057, ptr %callresult478, align 8
  %addr3058 = ptrtoint ptr %callresult478 to i64
  store i64 %addr3058, ptr %slot477, align 8
  %v3059 = load i64, ptr %slot477, align 8
  %v3060 = load i64, ptr %slot37, align 8
  %p3061 = inttoptr i64 %v3060 to ptr
  store i64 %v3059, ptr %p3061, align 8, !alias.scope !3, !noalias !4
  %v3062 = load i64, ptr %slot16, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %ld3064 = load i32, ptr %p3063, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3064, ptr %slot479, align 8
  %v3065 = load i32, ptr %slot479, align 8
  %cv3066 = zext i32 %v3065 to i64
  %cond3067 = icmp ne i64 %cv3066, 0
  br i1 %cond3067, label %bb_rcslotdrop779, label %bb_rcslotdone779
bb_rcslotdrop779:
  %v3068 = load i64, ptr %slot16, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i32 0, ptr %p3069, align 4, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot22, align 8
  store i64 %v3070, ptr %slot480, align 8
  %v3071 = load i64, ptr %slot17, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  %ld3073 = load i32, ptr %p3072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3073, ptr %slot481, align 8
  %v3074 = load i32, ptr %slot481, align 8
  %op3075 = and i32 %v3074, 28
  store i32 %op3075, ptr %slot482, align 8
  %v3076 = load i32, ptr %slot482, align 8
  %cv3077 = zext i32 %v3076 to i64
  %cond3078 = icmp ne i64 %cv3077, 0
  br i1 %cond3078, label %bb_rcslotrole779, label %bb_rcslotowner779
bb_rcslotrole779:
  %v3079 = load i64, ptr %slot53, align 8
  store i64 %v3079, ptr %slot483, align 8
  %v3080 = load i64, ptr %slot483, align 8
  %v3081 = load i64, ptr %slot480, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3080, i64 %v3081) nomerge, !dbg !166
  br label %bb_rcslotdone779
bb_rcslotowner779:
  %v3082 = load i64, ptr %slot53, align 8
  store i64 %v3082, ptr %slot484, align 8
  %v3083 = load i64, ptr %slot484, align 8
  %v3084 = load i64, ptr %slot480, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3083, i64 %v3084) nomerge, !dbg !166
  br label %bb_rcslotdone779
bb_rcslotdone779:
  %v3085 = load i64, ptr %slot32, align 8
  %v3086 = load i64, ptr %slot38, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i64 %v3085, ptr %p3087, align 8, !alias.scope !3, !noalias !4
  %v3088 = load i64, ptr %slot38, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  %ld3090 = load i64, ptr %p3089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3090, ptr %slot485, align 8
  %v3091 = load i64, ptr %slot1, align 8
  %v3092 = load i64, ptr %slot485, align 8
  %call3093 = call i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64 %v3091, i64 %v3092) nomerge, !dbg !168
  store i64 %call3093, ptr %slot486, align 8
  %v3094 = load i64, ptr %slot486, align 8
  %v3095 = load i64, ptr %slot38, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  store i64 %v3094, ptr %p3096, align 8, !alias.scope !3, !noalias !4
  %v3097 = load i64, ptr %slot36, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  %ld3099 = load i64, ptr %p3098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3099, ptr %slot487, align 8
  %v3100 = load i64, ptr %slot37, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  %ld3102 = load i64, ptr %p3101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3102, ptr %slot488, align 8
  %v3103 = load i64, ptr %slot38, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  %ld3105 = load i64, ptr %p3104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3105, ptr %slot489, align 8
  %v3106 = load i64, ptr %slot1, align 8
  %v3107 = load i64, ptr %slot487, align 8
  %v3108 = load i64, ptr %slot488, align 8
  %v3109 = load i64, ptr %slot489, align 8
  %call3110 = call i64 @myl_f_ed0279e2fa3cbd41257c59aa86e577373533d86b28d37b01468f504f3e141d51(i64 %v3106, i64 %v3107, i64 %v3108, i64 %v3109) nomerge, !dbg !170
  store i64 %call3110, ptr %slot490, align 8
  %v3111 = load i64, ptr %slot490, align 8
  %v3112 = load i64, ptr %slot36, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  store i64 %v3111, ptr %p3113, align 8, !alias.scope !3, !noalias !4
  %v3114 = load i64, ptr %slot14, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %ld3116 = load i32, ptr %p3115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3116, ptr %slot491, align 8
  %v3117 = load i32, ptr %slot491, align 8
  %cv3118 = zext i32 %v3117 to i64
  %cond3119 = icmp ne i64 %cv3118, 0
  br i1 %cond3119, label %bb_rcslotdrop794, label %bb_rcslotdone794
bb_rcslotdrop794:
  %v3120 = load i64, ptr %slot14, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i32 0, ptr %p3121, align 4, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot21, align 8
  store i64 %v3122, ptr %slot492, align 8
  %v3123 = load i64, ptr %slot15, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  %ld3125 = load i32, ptr %p3124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3125, ptr %slot493, align 8
  %v3126 = load i32, ptr %slot493, align 8
  %op3127 = and i32 %v3126, 28
  store i32 %op3127, ptr %slot494, align 8
  %v3128 = load i32, ptr %slot494, align 8
  %cv3129 = zext i32 %v3128 to i64
  %cond3130 = icmp ne i64 %cv3129, 0
  br i1 %cond3130, label %bb_rcslotrole794, label %bb_rcslotowner794
bb_rcslotrole794:
  %v3131 = load i64, ptr %slot53, align 8
  store i64 %v3131, ptr %slot495, align 8
  %v3132 = load i64, ptr %slot495, align 8
  %v3133 = load i64, ptr %slot492, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3132, i64 %v3133) nomerge, !dbg !170
  br label %bb_rcslotdone794
bb_rcslotowner794:
  %v3134 = load i64, ptr %slot53, align 8
  store i64 %v3134, ptr %slot496, align 8
  %v3135 = load i64, ptr %slot496, align 8
  %v3136 = load i64, ptr %slot492, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3135, i64 %v3136) nomerge, !dbg !170
  br label %bb_rcslotdone794
bb_rcslotdone794:
  %v3137 = load i64, ptr %slot36, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  %ld3139 = load i64, ptr %p3138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3139, ptr %slot497, align 8
  %v3140 = load i64, ptr %slot497, align 8
  %v3141 = load i64, ptr %slot34, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  store i64 %v3140, ptr %p3142, align 8, !alias.scope !3, !noalias !4
  %v3143 = load i64, ptr %slot26, align 8
  %p3144 = inttoptr i64 %v3143 to ptr
  %ld3145 = load i64, ptr %p3144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3145, ptr %slot498, align 8
  %v3146 = load i64, ptr %slot498, align 8
  %op3147 = add i64 %v3146, 32
  store i64 %op3147, ptr %slot499, align 8
  %v3148 = load i64, ptr %slot33, align 8
  store i64 %v3148, ptr %slot500, align 8
  %v3149 = load i64, ptr %slot500, align 8
  %v3150 = load i64, ptr %slot499, align 8
  %p3151 = inttoptr i64 %v3149 to ptr
  %p3152 = inttoptr i64 %v3150 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3152, ptr %p3151, i64 208, i1 false), !alias.scope !10000000
  %v3153 = load i64, ptr %slot500, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  call void @llvm.memset.p0.i64(ptr %p3154, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v3155 = load i64, ptr %slot10, align 8
  %p3156 = inttoptr i64 %v3155 to ptr
  store i32 0, ptr %p3156, align 4, !alias.scope !3, !noalias !4
  %v3157 = load i64, ptr %slot36, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i64 0, ptr %p3158, align 8, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot26, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %ld3161 = load i64, ptr %p3160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3161, ptr %slot501, align 8
  %v3162 = load i64, ptr %slot501, align 8
  %v3163 = load i64, ptr %slot44, align 8
  %p3164 = inttoptr i64 %v3162 to ptr
  %p3165 = inttoptr i64 %v3163 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3165, ptr %p3164, i64 304, i1 false), !alias.scope !10000000
  %v3166 = load i64, ptr %slot44, align 8
  %v3167 = load i64, ptr %slot36, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  store i64 %v3166, ptr %p3168, align 8, !alias.scope !3, !noalias !4
  %v3169 = load i64, ptr %slot36, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %ld3171 = load i64, ptr %p3170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3171, ptr %slot502, align 8
  %v3172 = load i64, ptr %slot502, align 8
  %op3173 = add i64 %v3172, 32
  store i64 %op3173, ptr %slot503, align 8
  %v3174 = load i64, ptr %slot503, align 8
  %v3175 = load i64, ptr %slot36, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i64 %v3174, ptr %p3176, align 8, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot12, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i32, ptr %p3178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3179, ptr %slot504, align 8
  %v3180 = load i32, ptr %slot504, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcslotdrop811, label %bb_rcslotdone811
bb_rcslotdrop811:
  %v3183 = load i64, ptr %slot12, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  store i32 0, ptr %p3184, align 4, !alias.scope !3, !noalias !4
  %v3185 = load i64, ptr %slot35, align 8
  store i64 %v3185, ptr %slot505, align 8
  %v3186 = load i64, ptr %slot13, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  %ld3188 = load i32, ptr %p3187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3188, ptr %slot506, align 8
  %v3189 = load i32, ptr %slot506, align 8
  %op3190 = and i32 %v3189, 28
  store i32 %op3190, ptr %slot507, align 8
  %v3191 = load i32, ptr %slot507, align 8
  %cv3192 = zext i32 %v3191 to i64
  %cond3193 = icmp ne i64 %cv3192, 0
  br i1 %cond3193, label %bb_rcslotrole811, label %bb_rcslotowner811
bb_rcslotrole811:
  %v3194 = load i64, ptr %slot53, align 8
  store i64 %v3194, ptr %slot508, align 8
  %v3195 = load i64, ptr %slot508, align 8
  %v3196 = load i64, ptr %slot505, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3195, i64 %v3196) nomerge, !dbg !174
  br label %bb_rcslotdone811
bb_rcslotowner811:
  %v3197 = load i64, ptr %slot53, align 8
  store i64 %v3197, ptr %slot509, align 8
  %v3198 = load i64, ptr %slot509, align 8
  %v3199 = load i64, ptr %slot505, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3198, i64 %v3199) nomerge, !dbg !174
  br label %bb_rcslotdone811
bb_rcslotdone811:
  %v3200 = load i64, ptr %slot26, align 8
  %p3201 = inttoptr i64 %v3200 to ptr
  %ld3202 = load i64, ptr %p3201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3202, ptr %slot510, align 8
  %v3203 = load i64, ptr %slot510, align 8
  %op3204 = add i64 %v3203, 32
  store i64 %op3204, ptr %slot511, align 8
  %v3205 = load i64, ptr %slot35, align 8
  store i64 %v3205, ptr %slot512, align 8
  %v3206 = load i64, ptr %slot511, align 8
  %v3207 = load i64, ptr %slot512, align 8
  %p3208 = inttoptr i64 %v3206 to ptr
  %p3209 = inttoptr i64 %v3207 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3209, ptr %p3208, i64 208, i1 false), !alias.scope !10000000
  %v3210 = load i64, ptr %slot511, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  call void @llvm.memset.p0.i64(ptr %p3211, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !174
  %v3212 = load i64, ptr %slot12, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 1, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  %v3214 = load i64, ptr %slot35, align 8
  %v3215 = load i64, ptr %slot36, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  store i64 %v3214, ptr %p3216, align 8, !alias.scope !3, !noalias !4
  %v3217 = load i64, ptr %slot34, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  %ld3219 = load i64, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3219, ptr %slot513, align 8
  %v3220 = load i64, ptr %slot513, align 8
  %v3221 = load i64, ptr %slot37, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 %v3220, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot45, align 8
  store i64 %v3223, ptr %slot514, align 8
  %v3224 = load i64, ptr %slot514, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  store i64 0, ptr %p3225, align 8, !alias.scope !3, !noalias !4
  %v3226 = load i64, ptr %slot514, align 8
  %p3228 = inttoptr i64 %v3226 to ptr
  %gep3229 = getelementptr i8, ptr %p3228, i64 8
  %op3227 = ptrtoint ptr %gep3229 to i64
  store i64 %op3227, ptr %slot515, align 8
  %v3230 = load i64, ptr %slot515, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  store i64 0, ptr %p3231, align 8, !alias.scope !3, !noalias !4
  %v3232 = load i64, ptr %slot514, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i32 3, ptr %p3233, align 4, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot20, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  store i32 1, ptr %p3235, align 4, !alias.scope !3, !noalias !4
  %v3236 = load i64, ptr %slot37, align 8
  store i64 %v3236, ptr %slot516, align 8
  %v3237 = load i64, ptr %slot514, align 8
  %p3239 = inttoptr i64 %v3237 to ptr
  %gep3240 = getelementptr i8, ptr %p3239, i64 8
  %op3238 = ptrtoint ptr %gep3240 to i64
  store i64 %op3238, ptr %slot517, align 8
  %v3241 = load i64, ptr %slot54, align 8
  store i64 %v3241, ptr %slot518, align 8
  %v3242 = load i64, ptr %slot516, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %ld3244 = load i64, ptr %p3243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3244, ptr %slot519, align 8
  %v3245 = load i64, ptr %slot519, align 8
  %v3246 = load i64, ptr %slot517, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  store i64 %v3245, ptr %p3247, align 8, !alias.scope !3, !noalias !4
  %v3248 = load i64, ptr %slot514, align 8
  %v3249 = load i64, ptr %slot37, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  store i64 %v3248, ptr %p3250, align 8, !alias.scope !3, !noalias !4
  %v3251 = load i64, ptr %slot36, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %ld3253 = load i64, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3253, ptr %slot520, align 8
  %v3254 = load i64, ptr %slot37, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %ld3256 = load i64, ptr %p3255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3256, ptr %slot521, align 8
  %v3257 = load i64, ptr %slot1, align 8
  %v3258 = load i64, ptr %slot520, align 8
  %v3259 = load i64, ptr %slot521, align 8
  %call3260 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v3257, i64 %v3258, i64 %v3259) nomerge, !dbg !176
  store i64 %call3260, ptr %slot522, align 8
  %v3261 = load i64, ptr %slot522, align 8
  %v3262 = load i64, ptr %slot36, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  store i64 %v3261, ptr %p3263, align 8, !alias.scope !3, !noalias !4
  %v3264 = load i64, ptr %slot14, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  %ld3266 = load i32, ptr %p3265, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3266, ptr %slot523, align 8
  %v3267 = load i32, ptr %slot523, align 8
  %cv3268 = zext i32 %v3267 to i64
  %cond3269 = icmp ne i64 %cv3268, 0
  br i1 %cond3269, label %bb_rcslotdrop836, label %bb_rcslotdone836
bb_rcslotdrop836:
  %v3270 = load i64, ptr %slot14, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  store i32 0, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  %v3272 = load i64, ptr %slot21, align 8
  store i64 %v3272, ptr %slot524, align 8
  %v3273 = load i64, ptr %slot15, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  %ld3275 = load i32, ptr %p3274, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3275, ptr %slot525, align 8
  %v3276 = load i32, ptr %slot525, align 8
  %op3277 = and i32 %v3276, 28
  store i32 %op3277, ptr %slot526, align 8
  %v3278 = load i32, ptr %slot526, align 8
  %cv3279 = zext i32 %v3278 to i64
  %cond3280 = icmp ne i64 %cv3279, 0
  br i1 %cond3280, label %bb_rcslotrole836, label %bb_rcslotowner836
bb_rcslotrole836:
  %v3281 = load i64, ptr %slot53, align 8
  store i64 %v3281, ptr %slot527, align 8
  %v3282 = load i64, ptr %slot527, align 8
  %v3283 = load i64, ptr %slot524, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3282, i64 %v3283) nomerge, !dbg !176
  br label %bb_rcslotdone836
bb_rcslotowner836:
  %v3284 = load i64, ptr %slot53, align 8
  store i64 %v3284, ptr %slot528, align 8
  %v3285 = load i64, ptr %slot528, align 8
  %v3286 = load i64, ptr %slot524, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3285, i64 %v3286) nomerge, !dbg !176
  br label %bb_rcslotdone836
bb_rcslotdone836:
  %v3287 = load i64, ptr %slot26, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  %ld3289 = load i64, ptr %p3288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3289, ptr %slot529, align 8
  %v3290 = load i64, ptr %slot529, align 8
  %op3291 = add i64 %v3290, 32
  store i64 %op3291, ptr %slot530, align 8
  %v3292 = load i64, ptr %slot35, align 8
  store i64 %v3292, ptr %slot531, align 8
  %v3293 = load i64, ptr %slot531, align 8
  %v3294 = load i64, ptr %slot530, align 8
  %p3295 = inttoptr i64 %v3293 to ptr
  %p3296 = inttoptr i64 %v3294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3296, ptr %p3295, i64 208, i1 false), !alias.scope !10000000
  %v3297 = load i64, ptr %slot531, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  call void @llvm.memset.p0.i64(ptr %p3298, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !178
  %v3299 = load i64, ptr %slot12, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  store i32 0, ptr %p3300, align 4, !alias.scope !3, !noalias !4
  %v3301 = load i64, ptr %slot36, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  store i64 0, ptr %p3302, align 8, !alias.scope !3, !noalias !4
  %v3303 = load i64, ptr %slot36, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 0, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot46, align 8
  store i64 %v3305, ptr %slot532, align 8
  %v3306 = load i64, ptr %slot532, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i64 0, ptr %p3307, align 8, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot532, align 8
  %p3310 = inttoptr i64 %v3308 to ptr
  %gep3311 = getelementptr i8, ptr %p3310, i64 8
  %op3309 = ptrtoint ptr %gep3311 to i64
  store i64 %op3309, ptr %slot533, align 8
  %v3312 = load i64, ptr %slot533, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  store i64 0, ptr %p3313, align 8, !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot532, align 8
  %p3316 = inttoptr i64 %v3314 to ptr
  %gep3317 = getelementptr i8, ptr %p3316, i64 16
  %op3315 = ptrtoint ptr %gep3317 to i64
  store i64 %op3315, ptr %slot534, align 8
  %v3318 = load i64, ptr %slot534, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i64 0, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot532, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  store i32 0, ptr %p3321, align 4, !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot20, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i32 1, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot36, align 8
  store i64 %v3324, ptr %slot535, align 8
  %v3325 = load i64, ptr %slot532, align 8
  %p3327 = inttoptr i64 %v3325 to ptr
  %gep3328 = getelementptr i8, ptr %p3327, i64 8
  %op3326 = ptrtoint ptr %gep3328 to i64
  store i64 %op3326, ptr %slot536, align 8
  %v3329 = load i64, ptr %slot54, align 8
  store i64 %v3329, ptr %slot537, align 8
  store i64 0, ptr %slot538, align 8
  %v3330 = load i64, ptr %slot532, align 8
  %v3331 = load i64, ptr %slot36, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i64 %v3330, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot36, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i64, ptr %p3334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3335, ptr %slot539, align 8
  %v3336 = load i64, ptr %slot21, align 8
  store i64 %v3336, ptr %slot540, align 8
  %v3337 = load i64, ptr %slot539, align 8
  %v3338 = load i64, ptr %slot540, align 8
  %p3339 = inttoptr i64 %v3337 to ptr
  %p3340 = inttoptr i64 %v3338 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3340, ptr %p3339, i64 24, i1 false)
  %v3341 = load i64, ptr %slot15, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  store i32 2, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  %v3343 = load i64, ptr %slot14, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  store i32 1, ptr %p3344, align 4, !alias.scope !3, !noalias !4
  %v3345 = load i64, ptr %slot540, align 8
  %v3346 = load i64, ptr %slot36, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  store i64 %v3345, ptr %p3347, align 8, !alias.scope !3, !noalias !4
  %v3348 = load i64, ptr %slot36, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  %ld3350 = load i64, ptr %p3349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3350, ptr %slot541, align 8
  %v3351 = load i64, ptr %slot36, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %ld3353 = load i64, ptr %p3352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3353, ptr %slot542, align 8
  %v3354 = load i64, ptr %slot25, align 8
  store i64 %v3354, ptr %slot543, align 8
  %v3355 = load i64, ptr %slot54, align 8
  store i64 %v3355, ptr %slot544, align 8
  %v3356 = load i64, ptr %slot53, align 8
  %v3357 = load i64, ptr %slot543, align 8
  %v3358 = load i64, ptr %slot542, align 8
  %v3359 = load i64, ptr %slot544, align 8
  %cv3360 = trunc i64 %v3359 to i32
  %call3361 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3356, i64 %v3357, i64 %v3358, i32 %cv3360) nomerge, !dbg !180
  store i32 %call3361, ptr %slot545, align 8
  %v3362 = load i32, ptr %slot545, align 8
  %cv3363 = zext i32 %v3362 to i64
  %cond3364 = icmp ne i64 %cv3363, 0
  br i1 %cond3364, label %bb_rcsuccess865, label %bb_rcfailure865
bb_rcfailure865:
  %v3365 = load i64, ptr %slot53, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  %call3367 = call i32 @myl_rc_take_failure(ptr %p3366) nomerge, !dbg !180
  store i32 %call3367, ptr %slot546, align 8
  %v3368 = load i64, ptr %slot1, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  %v3370 = load i32, ptr %slot546, align 8
  %call3371 = call i32 @myl_qbe_rc_status(ptr %p3369, i32 %v3370) nomerge, !dbg !180
  store i32 %call3371, ptr %slot547, align 8
  br label %bb_failure
bb_rcsuccess865:
  %v3372 = load i64, ptr %slot14, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  store i32 0, ptr %p3373, align 4, !alias.scope !3, !noalias !4
  %v3374 = load i64, ptr %slot19, align 8
  %p3375 = inttoptr i64 %v3374 to ptr
  store i32 2, ptr %p3375, align 4, !alias.scope !3, !noalias !4
  %v3376 = load i64, ptr %slot18, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  store i32 1, ptr %p3377, align 4, !alias.scope !3, !noalias !4
  %v3378 = load i64, ptr %slot25, align 8
  store i64 %v3378, ptr %slot548, align 8
  %v3379 = load i64, ptr %slot18, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i32 0, ptr %p3380, align 4, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot14, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i32, ptr %p3382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3383, ptr %slot549, align 8
  %v3384 = load i32, ptr %slot549, align 8
  %cv3385 = zext i32 %v3384 to i64
  %cond3386 = icmp ne i64 %cv3385, 0
  br i1 %cond3386, label %bb_rcslotdrop875, label %bb_rcslotdone875
bb_rcslotdrop875:
  %v3387 = load i64, ptr %slot14, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  store i32 0, ptr %p3388, align 4, !alias.scope !3, !noalias !4
  %v3389 = load i64, ptr %slot21, align 8
  store i64 %v3389, ptr %slot550, align 8
  %v3390 = load i64, ptr %slot15, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %ld3392 = load i32, ptr %p3391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3392, ptr %slot551, align 8
  %v3393 = load i32, ptr %slot551, align 8
  %op3394 = and i32 %v3393, 28
  store i32 %op3394, ptr %slot552, align 8
  %v3395 = load i32, ptr %slot552, align 8
  %cv3396 = zext i32 %v3395 to i64
  %cond3397 = icmp ne i64 %cv3396, 0
  br i1 %cond3397, label %bb_rcslotrole875, label %bb_rcslotowner875
bb_rcslotrole875:
  %v3398 = load i64, ptr %slot53, align 8
  store i64 %v3398, ptr %slot553, align 8
  %v3399 = load i64, ptr %slot553, align 8
  %v3400 = load i64, ptr %slot550, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3399, i64 %v3400) nomerge, !dbg !180
  br label %bb_rcslotdone875
bb_rcslotowner875:
  %v3401 = load i64, ptr %slot53, align 8
  store i64 %v3401, ptr %slot554, align 8
  %v3402 = load i64, ptr %slot554, align 8
  %v3403 = load i64, ptr %slot550, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3402, i64 %v3403) nomerge, !dbg !180
  br label %bb_rcslotdone875
bb_rcslotdone875:
  %v3404 = load i64, ptr %slot12, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  %ld3406 = load i32, ptr %p3405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3406, ptr %slot555, align 8
  %v3407 = load i32, ptr %slot555, align 8
  %cv3408 = zext i32 %v3407 to i64
  %cond3409 = icmp ne i64 %cv3408, 0
  br i1 %cond3409, label %bb_rcslotdrop902, label %bb_rcslotdone902
bb_rcslotdrop902:
  %v3410 = load i64, ptr %slot12, align 8
  %p3411 = inttoptr i64 %v3410 to ptr
  store i32 0, ptr %p3411, align 4, !alias.scope !3, !noalias !4
  %v3412 = load i64, ptr %slot35, align 8
  store i64 %v3412, ptr %slot556, align 8
  %v3413 = load i64, ptr %slot13, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  %ld3415 = load i32, ptr %p3414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3415, ptr %slot557, align 8
  %v3416 = load i32, ptr %slot557, align 8
  %op3417 = and i32 %v3416, 28
  store i32 %op3417, ptr %slot558, align 8
  %v3418 = load i32, ptr %slot558, align 8
  %cv3419 = zext i32 %v3418 to i64
  %cond3420 = icmp ne i64 %cv3419, 0
  br i1 %cond3420, label %bb_rcslotrole902, label %bb_rcslotowner902
bb_rcslotrole902:
  %v3421 = load i64, ptr %slot53, align 8
  store i64 %v3421, ptr %slot559, align 8
  %v3422 = load i64, ptr %slot559, align 8
  %v3423 = load i64, ptr %slot556, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3422, i64 %v3423) nomerge, !dbg !180
  br label %bb_rcslotdone902
bb_rcslotowner902:
  %v3424 = load i64, ptr %slot53, align 8
  store i64 %v3424, ptr %slot560, align 8
  %v3425 = load i64, ptr %slot560, align 8
  %v3426 = load i64, ptr %slot556, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3425, i64 %v3426) nomerge, !dbg !180
  br label %bb_rcslotdone902
bb_rcslotdone902:
  %v3427 = load i64, ptr %slot10, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %ld3429 = load i32, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3429, ptr %slot561, align 8
  %v3430 = load i32, ptr %slot561, align 8
  %cv3431 = zext i32 %v3430 to i64
  %cond3432 = icmp ne i64 %cv3431, 0
  br i1 %cond3432, label %bb_rcslotdrop929, label %bb_rcslotdone929
bb_rcslotdrop929:
  %v3433 = load i64, ptr %slot10, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  store i32 0, ptr %p3434, align 4, !alias.scope !3, !noalias !4
  %v3435 = load i64, ptr %slot33, align 8
  store i64 %v3435, ptr %slot562, align 8
  %v3436 = load i64, ptr %slot11, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %ld3438 = load i32, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3438, ptr %slot563, align 8
  %v3439 = load i32, ptr %slot563, align 8
  %op3440 = and i32 %v3439, 28
  store i32 %op3440, ptr %slot564, align 8
  %v3441 = load i32, ptr %slot564, align 8
  %cv3442 = zext i32 %v3441 to i64
  %cond3443 = icmp ne i64 %cv3442, 0
  br i1 %cond3443, label %bb_rcslotrole929, label %bb_rcslotowner929
bb_rcslotrole929:
  %v3444 = load i64, ptr %slot53, align 8
  store i64 %v3444, ptr %slot565, align 8
  %v3445 = load i64, ptr %slot565, align 8
  %v3446 = load i64, ptr %slot562, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3445, i64 %v3446) nomerge, !dbg !180
  br label %bb_rcslotdone929
bb_rcslotowner929:
  %v3447 = load i64, ptr %slot53, align 8
  store i64 %v3447, ptr %slot566, align 8
  %v3448 = load i64, ptr %slot566, align 8
  %v3449 = load i64, ptr %slot562, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3448, i64 %v3449) nomerge, !dbg !180
  br label %bb_rcslotdone929
bb_rcslotdone929:
  %v3450 = load i64, ptr %slot8, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i32, ptr %p3451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3452, ptr %slot567, align 8
  %v3453 = load i32, ptr %slot567, align 8
  %cv3454 = zext i32 %v3453 to i64
  %cond3455 = icmp ne i64 %cv3454, 0
  br i1 %cond3455, label %bb_rcslotdrop956, label %bb_rcslotdone956
bb_rcslotdrop956:
  %v3456 = load i64, ptr %slot8, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  store i32 0, ptr %p3457, align 4, !alias.scope !3, !noalias !4
  %v3458 = load i64, ptr %slot31, align 8
  store i64 %v3458, ptr %slot568, align 8
  %v3459 = load i64, ptr %slot9, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  %ld3461 = load i32, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3461, ptr %slot569, align 8
  %v3462 = load i32, ptr %slot569, align 8
  %op3463 = and i32 %v3462, 28
  store i32 %op3463, ptr %slot570, align 8
  %v3464 = load i32, ptr %slot570, align 8
  %cv3465 = zext i32 %v3464 to i64
  %cond3466 = icmp ne i64 %cv3465, 0
  br i1 %cond3466, label %bb_rcslotrole956, label %bb_rcslotowner956
bb_rcslotrole956:
  %v3467 = load i64, ptr %slot53, align 8
  store i64 %v3467, ptr %slot571, align 8
  %v3468 = load i64, ptr %slot571, align 8
  %v3469 = load i64, ptr %slot568, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3468, i64 %v3469) nomerge, !dbg !180
  br label %bb_rcslotdone956
bb_rcslotowner956:
  %v3470 = load i64, ptr %slot53, align 8
  store i64 %v3470, ptr %slot572, align 8
  %v3471 = load i64, ptr %slot572, align 8
  %v3472 = load i64, ptr %slot568, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3471, i64 %v3472) nomerge, !dbg !180
  br label %bb_rcslotdone956
bb_rcslotdone956:
  %v3473 = load i64, ptr %slot6, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %ld3475 = load i32, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3475, ptr %slot573, align 8
  %v3476 = load i32, ptr %slot573, align 8
  %cv3477 = zext i32 %v3476 to i64
  %cond3478 = icmp ne i64 %cv3477, 0
  br i1 %cond3478, label %bb_rcslotdrop965, label %bb_rcslotdone965
bb_rcslotdrop965:
  %v3479 = load i64, ptr %slot6, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i32 0, ptr %p3480, align 4, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot28, align 8
  store i64 %v3481, ptr %slot574, align 8
  %v3482 = load i64, ptr %slot7, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i32, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3484, ptr %slot575, align 8
  %v3485 = load i32, ptr %slot575, align 8
  %op3486 = and i32 %v3485, 28
  store i32 %op3486, ptr %slot576, align 8
  %v3487 = load i32, ptr %slot576, align 8
  %cv3488 = zext i32 %v3487 to i64
  %cond3489 = icmp ne i64 %cv3488, 0
  br i1 %cond3489, label %bb_rcslotrole965, label %bb_rcslotowner965
bb_rcslotrole965:
  %v3490 = load i64, ptr %slot53, align 8
  store i64 %v3490, ptr %slot577, align 8
  %v3491 = load i64, ptr %slot577, align 8
  %v3492 = load i64, ptr %slot574, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3491, i64 %v3492) nomerge, !dbg !180
  br label %bb_rcslotdone965
bb_rcslotowner965:
  %v3493 = load i64, ptr %slot53, align 8
  store i64 %v3493, ptr %slot578, align 8
  %v3494 = load i64, ptr %slot578, align 8
  %v3495 = load i64, ptr %slot574, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3494, i64 %v3495) nomerge, !dbg !180
  br label %bb_rcslotdone965
bb_rcslotdone965:
  %v3496 = load i64, ptr %slot548, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3497, i64 24, i1 false)
  ret void
bb_i115:
  %p3498 = inttoptr i64 ptrtoint (ptr @myl_lit_ccec7865dc7b502581d71aee3367b2a04dffea764d540fdcda9a17841514ad4f to i64) to ptr
  %ld3499 = load i64, ptr %p3498, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3499, ptr %slot579, align 8
  %v3500 = load i64, ptr %slot579, align 8
  %v3501 = load i64, ptr %slot36, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  store i64 %v3500, ptr %p3502, align 8, !alias.scope !3, !noalias !4
  %v3503 = load i64, ptr %slot36, align 8
  %p3504 = inttoptr i64 %v3503 to ptr
  %ld3505 = load i64, ptr %p3504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3505, ptr %slot580, align 8
  %v3506 = load i64, ptr %slot580, align 8
  %v3507 = load i64, ptr %slot23, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  store i64 %v3506, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  %v3509 = load i64, ptr %slot23, align 8
  store i64 %v3509, ptr %slot581, align 8
  %v3510 = load i64, ptr %slot25, align 8
  store i64 %v3510, ptr %slot582, align 8
  %v3511 = load i64, ptr %slot581, align 8
  %v3512 = load i64, ptr %slot582, align 8
  %p3513 = inttoptr i64 %v3511 to ptr
  %p3514 = inttoptr i64 %v3512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3514, ptr %p3513, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3515 = load i64, ptr %slot19, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  store i32 2, ptr %p3516, align 4, !alias.scope !3, !noalias !4
  %v3517 = load i64, ptr %slot18, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  store i32 1, ptr %p3518, align 4, !alias.scope !3, !noalias !4
  %v3519 = load i64, ptr %slot21, align 8
  store i64 %v3519, ptr %slot583, align 8
  %v3520 = load i64, ptr %slot25, align 8
  store i64 %v3520, ptr %slot584, align 8
  %v3521 = load i64, ptr %slot584, align 8
  %v3522 = load i64, ptr %slot583, align 8
  %p3523 = inttoptr i64 %v3521 to ptr
  %p3524 = inttoptr i64 %v3522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3524, ptr %p3523, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3525 = load i64, ptr %slot15, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i32 2, ptr %p3526, align 4, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot19, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i32, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3529, ptr %slot585, align 8
  %v3530 = load i32, ptr %slot585, align 8
  %v3531 = load i64, ptr %slot15, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  store i32 %v3530, ptr %p3532, align 4, !alias.scope !3, !noalias !4
  %v3533 = load i64, ptr %slot18, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  store i32 0, ptr %p3534, align 4, !alias.scope !3, !noalias !4
  %v3535 = load i64, ptr %slot14, align 8
  %p3536 = inttoptr i64 %v3535 to ptr
  store i32 1, ptr %p3536, align 4, !alias.scope !3, !noalias !4
  %v3537 = load i64, ptr %slot583, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %ld3539 = load i64, ptr %p3538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3539, ptr %slot586, align 8
  %v3540 = load i64, ptr %slot586, align 8
  %v3541 = load i64, ptr %slot36, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  store i64 %v3540, ptr %p3542, align 8, !alias.scope !3, !noalias !4
  %v3543 = load i64, ptr %slot26, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %ld3545 = load i64, ptr %p3544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3545, ptr %slot587, align 8
  %v3546 = load i64, ptr %slot587, align 8
  %v3547 = load i64, ptr %slot37, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  store i64 %v3546, ptr %p3548, align 8, !alias.scope !3, !noalias !4
  %v3549 = load i64, ptr %slot37, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %ld3551 = load i64, ptr %p3550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3551, ptr %slot588, align 8
  %v3552 = load i64, ptr %slot588, align 8
  %op3553 = add i64 %v3552, 32
  store i64 %op3553, ptr %slot589, align 8
  %v3554 = load i64, ptr %slot589, align 8
  %v3555 = load i64, ptr %slot37, align 8
  %p3556 = inttoptr i64 %v3555 to ptr
  store i64 %v3554, ptr %p3556, align 8, !alias.scope !3, !noalias !4
  %v3557 = load i64, ptr %slot16, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %ld3559 = load i32, ptr %p3558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3559, ptr %slot590, align 8
  %v3560 = load i32, ptr %slot590, align 8
  %cv3561 = zext i32 %v3560 to i64
  %cond3562 = icmp ne i64 %cv3561, 0
  br i1 %cond3562, label %bb_rcslotdrop1011, label %bb_rcslotdone1011
bb_rcslotdrop1011:
  %v3563 = load i64, ptr %slot16, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  store i32 0, ptr %p3564, align 4, !alias.scope !3, !noalias !4
  %v3565 = load i64, ptr %slot22, align 8
  store i64 %v3565, ptr %slot591, align 8
  %v3566 = load i64, ptr %slot17, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %ld3568 = load i32, ptr %p3567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3568, ptr %slot592, align 8
  %v3569 = load i32, ptr %slot592, align 8
  %op3570 = and i32 %v3569, 28
  store i32 %op3570, ptr %slot593, align 8
  %v3571 = load i32, ptr %slot593, align 8
  %cv3572 = zext i32 %v3571 to i64
  %cond3573 = icmp ne i64 %cv3572, 0
  br i1 %cond3573, label %bb_rcslotrole1011, label %bb_rcslotowner1011
bb_rcslotrole1011:
  %v3574 = load i64, ptr %slot53, align 8
  store i64 %v3574, ptr %slot594, align 8
  %v3575 = load i64, ptr %slot594, align 8
  %v3576 = load i64, ptr %slot591, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3575, i64 %v3576) nomerge, !dbg !182
  br label %bb_rcslotdone1011
bb_rcslotowner1011:
  %v3577 = load i64, ptr %slot53, align 8
  store i64 %v3577, ptr %slot595, align 8
  %v3578 = load i64, ptr %slot595, align 8
  %v3579 = load i64, ptr %slot591, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3578, i64 %v3579) nomerge, !dbg !182
  br label %bb_rcslotdone1011
bb_rcslotdone1011:
  %v3580 = load i64, ptr %slot27, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  %ld3582 = load i64, ptr %p3581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3582, ptr %slot596, align 8
  %v3583 = load i64, ptr %slot596, align 8
  %v3584 = load i64, ptr %slot38, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i64 %v3583, ptr %p3585, align 8, !alias.scope !3, !noalias !4
  %v3586 = load i64, ptr %slot38, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i64, ptr %p3587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3588, ptr %slot597, align 8
  %v3589 = load i64, ptr %slot597, align 8
  %op3590 = add i64 %v3589, 48
  store i64 %op3590, ptr %slot598, align 8
  %v3591 = load i64, ptr %slot598, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  %ld3593 = load i64, ptr %p3592, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3593, ptr %slot599, align 8
  %v3594 = load i64, ptr %slot599, align 8
  %v3595 = load i64, ptr %slot38, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  store i64 %v3594, ptr %p3596, align 8, !alias.scope !3, !noalias !4
  %v3597 = load i64, ptr %slot37, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  %ld3599 = load i64, ptr %p3598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3599, ptr %slot600, align 8
  %v3600 = load i64, ptr %slot38, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %ld3602 = load i64, ptr %p3601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3602, ptr %slot601, align 8
  %v3603 = load i64, ptr %slot1, align 8
  %v3604 = load i64, ptr %slot600, align 8
  %v3605 = load i64, ptr %slot601, align 8
  %call3606 = call i64 @myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b_rc_borrow(i64 %v3603, i64 %v3604, i64 %v3605) nomerge, !dbg !184
  store i64 %call3606, ptr %slot602, align 8
  %v3607 = load i64, ptr %slot602, align 8
  %v3608 = load i64, ptr %slot37, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  store i64 %v3607, ptr %p3609, align 8, !alias.scope !3, !noalias !4
  %v3610 = load i64, ptr %slot37, align 8
  %p3611 = inttoptr i64 %v3610 to ptr
  %ld3612 = load i64, ptr %p3611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3612, ptr %slot603, align 8
  %v3613 = load i64, ptr %slot603, align 8
  %v3614 = load i64, ptr %slot24, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i64 %v3613, ptr %p3615, align 8, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot24, align 8
  store i64 %v3616, ptr %slot604, align 8
  %v3617 = load i64, ptr %slot25, align 8
  store i64 %v3617, ptr %slot605, align 8
  %v3618 = load i64, ptr %slot604, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %ld3620 = load i64, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3620, ptr %slot606, align 8
  %v3621 = load i64, ptr %slot606, align 8
  %cmp3622 = icmp ne i64 %v3621, 0
  %cv3623 = zext i1 %cmp3622 to i32
  store i32 %cv3623, ptr %slot607, align 8
  %v3624 = load i32, ptr %slot607, align 8
  %cv3625 = zext i32 %v3624 to i64
  %cond3626 = icmp ne i64 %cv3625, 0
  br i1 %cond3626, label %bb_rcgnn1038, label %bb_rcgstore1038
bb_rcgnn1038:
  %v3627 = load i64, ptr %slot606, align 8
  %op3628 = sub i64 %v3627, 16
  store i64 %op3628, ptr %slot608, align 8
  %v3629 = load i64, ptr %slot606, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %rgep3631 = getelementptr i8, ptr %p3630, i64 -16
  %ld3632 = load i64, ptr %rgep3631, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3632, ptr %slot609, align 8
  %v3633 = load i64, ptr %slot609, align 8
  %op3634 = and i64 %v3633, 4611686018427387906
  store i64 %op3634, ptr %slot610, align 8
  %v3635 = load i64, ptr %slot610, align 8
  %cmp3636 = icmp ne i64 %v3635, 0
  %cv3637 = zext i1 %cmp3636 to i32
  store i32 %cv3637, ptr %slot611, align 8
  %v3638 = load i32, ptr %slot611, align 8
  %cv3639 = zext i32 %v3638 to i64
  %cond3640 = icmp ne i64 %cv3639, 0
  br i1 %cond3640, label %bb_rcgstore1038, label %bb_rcginc1038
bb_rcginc1038:
  %v3641 = load i64, ptr %slot606, align 8
  %op3642 = sub i64 %v3641, 24
  store i64 %op3642, ptr %slot612, align 8
  %v3643 = load i64, ptr %slot606, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %rgep3645 = getelementptr i8, ptr %p3644, i64 -24
  %ld3646 = load i64, ptr %rgep3645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3646, ptr %slot613, align 8
  %v3647 = load i64, ptr %slot613, align 8
  %op3648 = add i64 %v3647, 1
  store i64 %op3648, ptr %slot614, align 8
  %v3649 = load i64, ptr %slot614, align 8
  %cmp3650 = icmp eq i64 %v3649, 0
  %cv3651 = zext i1 %cmp3650 to i32
  store i32 %cv3651, ptr %slot615, align 8
  %v3652 = load i32, ptr %slot615, align 8
  %cv3653 = zext i32 %v3652 to i64
  %cond3654 = icmp ne i64 %cv3653, 0
  br i1 %cond3654, label %bb_rcglimit1038, label %bb_rcgcapacity1038
bb_rcglimit1038:
  %v3655 = load i64, ptr %slot1, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  %call3657 = call i32 @myl_qbe_rc_status(ptr %p3656, i32 2) nomerge, !dbg !184
  store i32 %call3657, ptr %slot616, align 8
  br label %bb_failure
bb_rcgcapacity1038:
  %v3658 = load i64, ptr %slot614, align 8
  %v3659 = load i64, ptr %slot606, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %rgep3661 = getelementptr i8, ptr %p3660, i64 -24
  store i64 %v3658, ptr %rgep3661, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1038
bb_rcgstore1038:
  %v3662 = load i64, ptr %slot606, align 8
  %v3663 = load i64, ptr %slot605, align 8
  %p3664 = inttoptr i64 %v3663 to ptr
  store i64 %v3662, ptr %p3664, align 8, !alias.scope !3, !noalias !4
  %v3665 = load i64, ptr %slot19, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  store i32 2, ptr %p3666, align 4, !alias.scope !3, !noalias !4
  %v3667 = load i64, ptr %slot19, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  store i32 16, ptr %p3668, align 4, !alias.scope !3, !noalias !4
  %v3669 = load i64, ptr %slot18, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  store i32 1, ptr %p3670, align 4, !alias.scope !3, !noalias !4
  %v3671 = load i64, ptr %slot16, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  %ld3673 = load i32, ptr %p3672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3673, ptr %slot617, align 8
  %v3674 = load i32, ptr %slot617, align 8
  %cv3675 = zext i32 %v3674 to i64
  %cond3676 = icmp ne i64 %cv3675, 0
  br i1 %cond3676, label %bb_rcslotdrop1054, label %bb_rcslotdone1054
bb_rcslotdrop1054:
  %v3677 = load i64, ptr %slot16, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  store i32 0, ptr %p3678, align 4, !alias.scope !3, !noalias !4
  %v3679 = load i64, ptr %slot22, align 8
  store i64 %v3679, ptr %slot618, align 8
  %v3680 = load i64, ptr %slot17, align 8
  %p3681 = inttoptr i64 %v3680 to ptr
  %ld3682 = load i32, ptr %p3681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3682, ptr %slot619, align 8
  %v3683 = load i32, ptr %slot619, align 8
  %op3684 = and i32 %v3683, 28
  store i32 %op3684, ptr %slot620, align 8
  %v3685 = load i32, ptr %slot620, align 8
  %cv3686 = zext i32 %v3685 to i64
  %cond3687 = icmp ne i64 %cv3686, 0
  br i1 %cond3687, label %bb_rcslotrole1054, label %bb_rcslotowner1054
bb_rcslotrole1054:
  %v3688 = load i64, ptr %slot53, align 8
  store i64 %v3688, ptr %slot621, align 8
  %v3689 = load i64, ptr %slot621, align 8
  %v3690 = load i64, ptr %slot618, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3689, i64 %v3690) nomerge, !dbg !184
  br label %bb_rcslotdone1054
bb_rcslotowner1054:
  %v3691 = load i64, ptr %slot53, align 8
  store i64 %v3691, ptr %slot622, align 8
  %v3692 = load i64, ptr %slot622, align 8
  %v3693 = load i64, ptr %slot618, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3692, i64 %v3693) nomerge, !dbg !184
  br label %bb_rcslotdone1054
bb_rcslotdone1054:
  %v3694 = load i64, ptr %slot22, align 8
  store i64 %v3694, ptr %slot623, align 8
  %v3695 = load i64, ptr %slot25, align 8
  store i64 %v3695, ptr %slot624, align 8
  %v3696 = load i64, ptr %slot624, align 8
  %v3697 = load i64, ptr %slot623, align 8
  %p3698 = inttoptr i64 %v3696 to ptr
  %p3699 = inttoptr i64 %v3697 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3699, ptr %p3698, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3700 = load i64, ptr %slot17, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  store i32 2, ptr %p3701, align 4, !alias.scope !3, !noalias !4
  %v3702 = load i64, ptr %slot19, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  %ld3704 = load i32, ptr %p3703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3704, ptr %slot625, align 8
  %v3705 = load i32, ptr %slot625, align 8
  %v3706 = load i64, ptr %slot17, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  store i32 %v3705, ptr %p3707, align 4, !alias.scope !3, !noalias !4
  %v3708 = load i64, ptr %slot18, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i32 0, ptr %p3709, align 4, !alias.scope !3, !noalias !4
  %v3710 = load i64, ptr %slot16, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  store i32 1, ptr %p3711, align 4, !alias.scope !3, !noalias !4
  %v3712 = load i64, ptr %slot623, align 8
  %p3713 = inttoptr i64 %v3712 to ptr
  %ld3714 = load i64, ptr %p3713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3714, ptr %slot626, align 8
  %v3715 = load i64, ptr %slot626, align 8
  %v3716 = load i64, ptr %slot37, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i64 %v3715, ptr %p3717, align 8, !alias.scope !3, !noalias !4
  %v3718 = load i64, ptr %slot36, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %ld3720 = load i64, ptr %p3719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3720, ptr %slot627, align 8
  %v3721 = load i64, ptr %slot37, align 8
  %p3722 = inttoptr i64 %v3721 to ptr
  %ld3723 = load i64, ptr %p3722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3723, ptr %slot628, align 8
  %v3724 = load i64, ptr %slot36, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  %ld3726 = load i64, ptr %p3725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3726, ptr %slot629, align 8
  %v3727 = load i64, ptr %slot37, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  %ld3729 = load i64, ptr %p3728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3729, ptr %slot630, align 8
  %v3730 = load i64, ptr %slot53, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %v3732 = load i64, ptr %slot629, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  %v3734 = load i64, ptr %slot630, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %call3736 = call ptr @myl_native_bytes_concat(ptr %p3731, ptr %p3733, ptr %p3735) nomerge, !dbg !186
  %calladdr3737 = ptrtoint ptr %call3736 to i64
  store i64 %calladdr3737, ptr %slot631, align 8
  %v3738 = load i64, ptr %slot631, align 8
  %cond3739 = icmp ne i64 %v3738, 0
  br i1 %cond3739, label %bb_success1076, label %bb_failed1076
bb_failed1076:
  %v3740 = load i64, ptr %slot1, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3741) nomerge, !dbg !186
  unreachable
bb_success1076:
  %v3742 = load i64, ptr %slot631, align 8
  %v3743 = load i64, ptr %slot36, align 8
  %p3744 = inttoptr i64 %v3743 to ptr
  store i64 %v3742, ptr %p3744, align 8, !alias.scope !3, !noalias !4
  %v3745 = load i64, ptr %slot36, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %ld3747 = load i64, ptr %p3746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3747, ptr %slot632, align 8
  %v3748 = load i64, ptr %slot632, align 8
  %v3749 = load i64, ptr %slot23, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  store i64 %v3748, ptr %p3750, align 8, !alias.scope !3, !noalias !4
  %v3751 = load i64, ptr %slot23, align 8
  store i64 %v3751, ptr %slot633, align 8
  %v3752 = load i64, ptr %slot25, align 8
  store i64 %v3752, ptr %slot634, align 8
  %v3753 = load i64, ptr %slot633, align 8
  %v3754 = load i64, ptr %slot634, align 8
  %p3755 = inttoptr i64 %v3753 to ptr
  %p3756 = inttoptr i64 %v3754 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3756, ptr %p3755, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3757 = load i64, ptr %slot19, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  store i32 2, ptr %p3758, align 4, !alias.scope !3, !noalias !4
  %v3759 = load i64, ptr %slot18, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  store i32 1, ptr %p3760, align 4, !alias.scope !3, !noalias !4
  %v3761 = load i64, ptr %slot14, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %ld3763 = load i32, ptr %p3762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3763, ptr %slot635, align 8
  %v3764 = load i32, ptr %slot635, align 8
  %cv3765 = zext i32 %v3764 to i64
  %cond3766 = icmp ne i64 %cv3765, 0
  br i1 %cond3766, label %bb_rcslotdrop1084, label %bb_rcslotdone1084
bb_rcslotdrop1084:
  %v3767 = load i64, ptr %slot14, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  store i32 0, ptr %p3768, align 4, !alias.scope !3, !noalias !4
  %v3769 = load i64, ptr %slot21, align 8
  store i64 %v3769, ptr %slot636, align 8
  %v3770 = load i64, ptr %slot15, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  %ld3772 = load i32, ptr %p3771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3772, ptr %slot637, align 8
  %v3773 = load i32, ptr %slot637, align 8
  %op3774 = and i32 %v3773, 28
  store i32 %op3774, ptr %slot638, align 8
  %v3775 = load i32, ptr %slot638, align 8
  %cv3776 = zext i32 %v3775 to i64
  %cond3777 = icmp ne i64 %cv3776, 0
  br i1 %cond3777, label %bb_rcslotrole1084, label %bb_rcslotowner1084
bb_rcslotrole1084:
  %v3778 = load i64, ptr %slot53, align 8
  store i64 %v3778, ptr %slot639, align 8
  %v3779 = load i64, ptr %slot636, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3781, ptr %slot640, align 8
  %v3782 = load i64, ptr %slot640, align 8
  %cmp3783 = icmp ne i64 %v3782, 0
  %cv3784 = zext i1 %cmp3783 to i32
  store i32 %cv3784, ptr %slot641, align 8
  %v3785 = load i32, ptr %slot641, align 8
  %cv3786 = zext i32 %v3785 to i64
  %cond3787 = icmp ne i64 %cv3786, 0
  br i1 %cond3787, label %bb_rcgnn1100, label %bb_rcgdone1100
bb_rcgnn1100:
  %v3788 = load i64, ptr %slot640, align 8
  %op3789 = sub i64 %v3788, 16
  store i64 %op3789, ptr %slot642, align 8
  %v3790 = load i64, ptr %slot640, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %rgep3792 = getelementptr i8, ptr %p3791, i64 -16
  %ld3793 = load i64, ptr %rgep3792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3793, ptr %slot643, align 8
  %v3794 = load i64, ptr %slot643, align 8
  %op3795 = and i64 %v3794, 4611686018427387906
  store i64 %op3795, ptr %slot644, align 8
  %v3796 = load i64, ptr %slot644, align 8
  %cmp3797 = icmp ne i64 %v3796, 0
  %cv3798 = zext i1 %cmp3797 to i32
  store i32 %cv3798, ptr %slot645, align 8
  %v3799 = load i32, ptr %slot645, align 8
  %cv3800 = zext i32 %v3799 to i64
  %cond3801 = icmp ne i64 %cv3800, 0
  br i1 %cond3801, label %bb_rcgclear1100, label %bb_rcgcounted1100
bb_rcgcounted1100:
  %v3802 = load i64, ptr %slot640, align 8
  %op3803 = sub i64 %v3802, 24
  store i64 %op3803, ptr %slot646, align 8
  %v3804 = load i64, ptr %slot640, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %rgep3806 = getelementptr i8, ptr %p3805, i64 -24
  %ld3807 = load i64, ptr %rgep3806, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3807, ptr %slot647, align 8
  %v3808 = load i64, ptr %slot647, align 8
  %op3809 = sub i64 %v3808, 1
  store i64 %op3809, ptr %slot648, align 8
  %v3810 = load i64, ptr %slot648, align 8
  %cmp3811 = icmp eq i64 %v3810, 0
  %cv3812 = zext i1 %cmp3811 to i32
  store i32 %cv3812, ptr %slot649, align 8
  %v3813 = load i32, ptr %slot649, align 8
  %cv3814 = zext i32 %v3813 to i64
  %cond3815 = icmp ne i64 %cv3814, 0
  br i1 %cond3815, label %bb_rcglast1100, label %bb_rcgdec1100
bb_rcglast1100:
  %v3816 = load i64, ptr %slot640, align 8
  %op3817 = sub i64 %v3816, 32
  store i64 %op3817, ptr %slot650, align 8
  %v3818 = load i64, ptr %slot640, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  %rgep3820 = getelementptr i8, ptr %p3819, i64 -32
  %ld3821 = load i64, ptr %rgep3820, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3821, ptr %slot651, align 8
  %v3822 = load i64, ptr %slot651, align 8
  %cmp3823 = icmp ne i64 %v3822, 0
  %cv3824 = zext i1 %cmp3823 to i32
  store i32 %cv3824, ptr %slot652, align 8
  %v3825 = load i32, ptr %slot652, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcgdec1100, label %bb_rcgslow1100
bb_rcgslow1100:
  %v3828 = load i64, ptr %slot639, align 8
  %v3829 = load i64, ptr %slot636, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3828, i64 %v3829) nomerge, !dbg !186
  br label %bb_rcgdone1100
bb_rcgdec1100:
  %v3830 = load i64, ptr %slot648, align 8
  %v3831 = load i64, ptr %slot640, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %rgep3833 = getelementptr i8, ptr %p3832, i64 -24
  store i64 %v3830, ptr %rgep3833, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1100
bb_rcgclear1100:
  %v3834 = load i64, ptr %slot636, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  store i64 0, ptr %p3835, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1100
bb_rcgdone1100:
  br label %bb_rcslotdone1084
bb_rcslotowner1084:
  %v3836 = load i64, ptr %slot53, align 8
  store i64 %v3836, ptr %slot653, align 8
  %v3837 = load i64, ptr %slot636, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i64, ptr %p3838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3839, ptr %slot654, align 8
  %v3840 = load i64, ptr %slot654, align 8
  %cmp3841 = icmp ne i64 %v3840, 0
  %cv3842 = zext i1 %cmp3841 to i32
  store i32 %cv3842, ptr %slot655, align 8
  %v3843 = load i32, ptr %slot655, align 8
  %cv3844 = zext i32 %v3843 to i64
  %cond3845 = icmp ne i64 %cv3844, 0
  br i1 %cond3845, label %bb_rcgnn1115, label %bb_rcgdone1115
bb_rcgnn1115:
  %v3846 = load i64, ptr %slot654, align 8
  %op3847 = sub i64 %v3846, 16
  store i64 %op3847, ptr %slot656, align 8
  %v3848 = load i64, ptr %slot654, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %rgep3850 = getelementptr i8, ptr %p3849, i64 -16
  %ld3851 = load i64, ptr %rgep3850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3851, ptr %slot657, align 8
  %v3852 = load i64, ptr %slot657, align 8
  %op3853 = and i64 %v3852, 4611686018427387906
  store i64 %op3853, ptr %slot658, align 8
  %v3854 = load i64, ptr %slot658, align 8
  %cmp3855 = icmp ne i64 %v3854, 0
  %cv3856 = zext i1 %cmp3855 to i32
  store i32 %cv3856, ptr %slot659, align 8
  %v3857 = load i32, ptr %slot659, align 8
  %cv3858 = zext i32 %v3857 to i64
  %cond3859 = icmp ne i64 %cv3858, 0
  br i1 %cond3859, label %bb_rcgclear1115, label %bb_rcgcounted1115
bb_rcgcounted1115:
  %v3860 = load i64, ptr %slot654, align 8
  %op3861 = sub i64 %v3860, 32
  store i64 %op3861, ptr %slot660, align 8
  %v3862 = load i64, ptr %slot654, align 8
  %p3863 = inttoptr i64 %v3862 to ptr
  %rgep3864 = getelementptr i8, ptr %p3863, i64 -32
  %ld3865 = load i64, ptr %rgep3864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3865, ptr %slot661, align 8
  %v3866 = load i64, ptr %slot661, align 8
  %op3867 = sub i64 %v3866, 1
  store i64 %op3867, ptr %slot662, align 8
  %v3868 = load i64, ptr %slot662, align 8
  %cmp3869 = icmp eq i64 %v3868, 0
  %cv3870 = zext i1 %cmp3869 to i32
  store i32 %cv3870, ptr %slot663, align 8
  %v3871 = load i32, ptr %slot663, align 8
  %cv3872 = zext i32 %v3871 to i64
  %cond3873 = icmp ne i64 %cv3872, 0
  br i1 %cond3873, label %bb_rcglast1115, label %bb_rcgdec1115
bb_rcglast1115:
  %v3874 = load i64, ptr %slot654, align 8
  %op3875 = sub i64 %v3874, 24
  store i64 %op3875, ptr %slot664, align 8
  %v3876 = load i64, ptr %slot654, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  %rgep3878 = getelementptr i8, ptr %p3877, i64 -24
  %ld3879 = load i64, ptr %rgep3878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3879, ptr %slot665, align 8
  %v3880 = load i64, ptr %slot665, align 8
  %cmp3881 = icmp ne i64 %v3880, 0
  %cv3882 = zext i1 %cmp3881 to i32
  store i32 %cv3882, ptr %slot666, align 8
  %v3883 = load i32, ptr %slot666, align 8
  %cv3884 = zext i32 %v3883 to i64
  %cond3885 = icmp ne i64 %cv3884, 0
  br i1 %cond3885, label %bb_rcgdec1115, label %bb_rcgslow1115
bb_rcgslow1115:
  %v3886 = load i64, ptr %slot653, align 8
  %v3887 = load i64, ptr %slot636, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3886, i64 %v3887) nomerge, !dbg !186
  br label %bb_rcgdone1115
bb_rcgdec1115:
  %v3888 = load i64, ptr %slot662, align 8
  %v3889 = load i64, ptr %slot654, align 8
  %p3890 = inttoptr i64 %v3889 to ptr
  %rgep3891 = getelementptr i8, ptr %p3890, i64 -32
  store i64 %v3888, ptr %rgep3891, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1115
bb_rcgclear1115:
  %v3892 = load i64, ptr %slot636, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  store i64 0, ptr %p3893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1115
bb_rcgdone1115:
  br label %bb_rcslotdone1084
bb_rcslotdone1084:
  %v3894 = load i64, ptr %slot16, align 8
  %p3895 = inttoptr i64 %v3894 to ptr
  %ld3896 = load i32, ptr %p3895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3896, ptr %slot667, align 8
  %v3897 = load i32, ptr %slot667, align 8
  %cv3898 = zext i32 %v3897 to i64
  %cond3899 = icmp ne i64 %cv3898, 0
  br i1 %cond3899, label %bb_rcslotdrop1121, label %bb_rcslotdone1121
bb_rcslotdrop1121:
  %v3900 = load i64, ptr %slot16, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  store i32 0, ptr %p3901, align 4, !alias.scope !3, !noalias !4
  %v3902 = load i64, ptr %slot22, align 8
  store i64 %v3902, ptr %slot668, align 8
  %v3903 = load i64, ptr %slot17, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  %ld3905 = load i32, ptr %p3904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3905, ptr %slot669, align 8
  %v3906 = load i32, ptr %slot669, align 8
  %op3907 = and i32 %v3906, 28
  store i32 %op3907, ptr %slot670, align 8
  %v3908 = load i32, ptr %slot670, align 8
  %cv3909 = zext i32 %v3908 to i64
  %cond3910 = icmp ne i64 %cv3909, 0
  br i1 %cond3910, label %bb_rcslotrole1121, label %bb_rcslotowner1121
bb_rcslotrole1121:
  %v3911 = load i64, ptr %slot53, align 8
  store i64 %v3911, ptr %slot671, align 8
  %v3912 = load i64, ptr %slot668, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i64, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3914, ptr %slot672, align 8
  %v3915 = load i64, ptr %slot672, align 8
  %cmp3916 = icmp ne i64 %v3915, 0
  %cv3917 = zext i1 %cmp3916 to i32
  store i32 %cv3917, ptr %slot673, align 8
  %v3918 = load i32, ptr %slot673, align 8
  %cv3919 = zext i32 %v3918 to i64
  %cond3920 = icmp ne i64 %cv3919, 0
  br i1 %cond3920, label %bb_rcgnn1137, label %bb_rcgdone1137
bb_rcgnn1137:
  %v3921 = load i64, ptr %slot672, align 8
  %op3922 = sub i64 %v3921, 16
  store i64 %op3922, ptr %slot674, align 8
  %v3923 = load i64, ptr %slot672, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %rgep3925 = getelementptr i8, ptr %p3924, i64 -16
  %ld3926 = load i64, ptr %rgep3925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3926, ptr %slot675, align 8
  %v3927 = load i64, ptr %slot675, align 8
  %op3928 = and i64 %v3927, 4611686018427387906
  store i64 %op3928, ptr %slot676, align 8
  %v3929 = load i64, ptr %slot676, align 8
  %cmp3930 = icmp ne i64 %v3929, 0
  %cv3931 = zext i1 %cmp3930 to i32
  store i32 %cv3931, ptr %slot677, align 8
  %v3932 = load i32, ptr %slot677, align 8
  %cv3933 = zext i32 %v3932 to i64
  %cond3934 = icmp ne i64 %cv3933, 0
  br i1 %cond3934, label %bb_rcgclear1137, label %bb_rcgcounted1137
bb_rcgcounted1137:
  %v3935 = load i64, ptr %slot672, align 8
  %op3936 = sub i64 %v3935, 24
  store i64 %op3936, ptr %slot678, align 8
  %v3937 = load i64, ptr %slot672, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %rgep3939 = getelementptr i8, ptr %p3938, i64 -24
  %ld3940 = load i64, ptr %rgep3939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3940, ptr %slot679, align 8
  %v3941 = load i64, ptr %slot679, align 8
  %op3942 = sub i64 %v3941, 1
  store i64 %op3942, ptr %slot680, align 8
  %v3943 = load i64, ptr %slot680, align 8
  %cmp3944 = icmp eq i64 %v3943, 0
  %cv3945 = zext i1 %cmp3944 to i32
  store i32 %cv3945, ptr %slot681, align 8
  %v3946 = load i32, ptr %slot681, align 8
  %cv3947 = zext i32 %v3946 to i64
  %cond3948 = icmp ne i64 %cv3947, 0
  br i1 %cond3948, label %bb_rcglast1137, label %bb_rcgdec1137
bb_rcglast1137:
  %v3949 = load i64, ptr %slot672, align 8
  %op3950 = sub i64 %v3949, 32
  store i64 %op3950, ptr %slot682, align 8
  %v3951 = load i64, ptr %slot672, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  %rgep3953 = getelementptr i8, ptr %p3952, i64 -32
  %ld3954 = load i64, ptr %rgep3953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3954, ptr %slot683, align 8
  %v3955 = load i64, ptr %slot683, align 8
  %cmp3956 = icmp ne i64 %v3955, 0
  %cv3957 = zext i1 %cmp3956 to i32
  store i32 %cv3957, ptr %slot684, align 8
  %v3958 = load i32, ptr %slot684, align 8
  %cv3959 = zext i32 %v3958 to i64
  %cond3960 = icmp ne i64 %cv3959, 0
  br i1 %cond3960, label %bb_rcgdec1137, label %bb_rcgslow1137
bb_rcgslow1137:
  %v3961 = load i64, ptr %slot671, align 8
  %v3962 = load i64, ptr %slot668, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3961, i64 %v3962) nomerge, !dbg !186
  br label %bb_rcgdone1137
bb_rcgdec1137:
  %v3963 = load i64, ptr %slot680, align 8
  %v3964 = load i64, ptr %slot672, align 8
  %p3965 = inttoptr i64 %v3964 to ptr
  %rgep3966 = getelementptr i8, ptr %p3965, i64 -24
  store i64 %v3963, ptr %rgep3966, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1137
bb_rcgclear1137:
  %v3967 = load i64, ptr %slot668, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  store i64 0, ptr %p3968, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1137
bb_rcgdone1137:
  br label %bb_rcslotdone1121
bb_rcslotowner1121:
  %v3969 = load i64, ptr %slot53, align 8
  store i64 %v3969, ptr %slot685, align 8
  %v3970 = load i64, ptr %slot668, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i64, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3972, ptr %slot686, align 8
  %v3973 = load i64, ptr %slot686, align 8
  %cmp3974 = icmp ne i64 %v3973, 0
  %cv3975 = zext i1 %cmp3974 to i32
  store i32 %cv3975, ptr %slot687, align 8
  %v3976 = load i32, ptr %slot687, align 8
  %cv3977 = zext i32 %v3976 to i64
  %cond3978 = icmp ne i64 %cv3977, 0
  br i1 %cond3978, label %bb_rcgnn1152, label %bb_rcgdone1152
bb_rcgnn1152:
  %v3979 = load i64, ptr %slot686, align 8
  %op3980 = sub i64 %v3979, 16
  store i64 %op3980, ptr %slot688, align 8
  %v3981 = load i64, ptr %slot686, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  %rgep3983 = getelementptr i8, ptr %p3982, i64 -16
  %ld3984 = load i64, ptr %rgep3983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3984, ptr %slot689, align 8
  %v3985 = load i64, ptr %slot689, align 8
  %op3986 = and i64 %v3985, 4611686018427387906
  store i64 %op3986, ptr %slot690, align 8
  %v3987 = load i64, ptr %slot690, align 8
  %cmp3988 = icmp ne i64 %v3987, 0
  %cv3989 = zext i1 %cmp3988 to i32
  store i32 %cv3989, ptr %slot691, align 8
  %v3990 = load i32, ptr %slot691, align 8
  %cv3991 = zext i32 %v3990 to i64
  %cond3992 = icmp ne i64 %cv3991, 0
  br i1 %cond3992, label %bb_rcgclear1152, label %bb_rcgcounted1152
bb_rcgcounted1152:
  %v3993 = load i64, ptr %slot686, align 8
  %op3994 = sub i64 %v3993, 32
  store i64 %op3994, ptr %slot692, align 8
  %v3995 = load i64, ptr %slot686, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  %rgep3997 = getelementptr i8, ptr %p3996, i64 -32
  %ld3998 = load i64, ptr %rgep3997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3998, ptr %slot693, align 8
  %v3999 = load i64, ptr %slot693, align 8
  %op4000 = sub i64 %v3999, 1
  store i64 %op4000, ptr %slot694, align 8
  %v4001 = load i64, ptr %slot694, align 8
  %cmp4002 = icmp eq i64 %v4001, 0
  %cv4003 = zext i1 %cmp4002 to i32
  store i32 %cv4003, ptr %slot695, align 8
  %v4004 = load i32, ptr %slot695, align 8
  %cv4005 = zext i32 %v4004 to i64
  %cond4006 = icmp ne i64 %cv4005, 0
  br i1 %cond4006, label %bb_rcglast1152, label %bb_rcgdec1152
bb_rcglast1152:
  %v4007 = load i64, ptr %slot686, align 8
  %op4008 = sub i64 %v4007, 24
  store i64 %op4008, ptr %slot696, align 8
  %v4009 = load i64, ptr %slot686, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %rgep4011 = getelementptr i8, ptr %p4010, i64 -24
  %ld4012 = load i64, ptr %rgep4011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4012, ptr %slot697, align 8
  %v4013 = load i64, ptr %slot697, align 8
  %cmp4014 = icmp ne i64 %v4013, 0
  %cv4015 = zext i1 %cmp4014 to i32
  store i32 %cv4015, ptr %slot698, align 8
  %v4016 = load i32, ptr %slot698, align 8
  %cv4017 = zext i32 %v4016 to i64
  %cond4018 = icmp ne i64 %cv4017, 0
  br i1 %cond4018, label %bb_rcgdec1152, label %bb_rcgslow1152
bb_rcgslow1152:
  %v4019 = load i64, ptr %slot685, align 8
  %v4020 = load i64, ptr %slot668, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4019, i64 %v4020) nomerge, !dbg !186
  br label %bb_rcgdone1152
bb_rcgdec1152:
  %v4021 = load i64, ptr %slot694, align 8
  %v4022 = load i64, ptr %slot686, align 8
  %p4023 = inttoptr i64 %v4022 to ptr
  %rgep4024 = getelementptr i8, ptr %p4023, i64 -32
  store i64 %v4021, ptr %rgep4024, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1152
bb_rcgclear1152:
  %v4025 = load i64, ptr %slot668, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  store i64 0, ptr %p4026, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1152
bb_rcgdone1152:
  br label %bb_rcslotdone1121
bb_rcslotdone1121:
  %v4027 = load i64, ptr %slot21, align 8
  store i64 %v4027, ptr %slot699, align 8
  %v4028 = load i64, ptr %slot25, align 8
  store i64 %v4028, ptr %slot700, align 8
  %v4029 = load i64, ptr %slot700, align 8
  %v4030 = load i64, ptr %slot699, align 8
  %p4031 = inttoptr i64 %v4029 to ptr
  %p4032 = inttoptr i64 %v4030 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4032, ptr %p4031, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4033 = load i64, ptr %slot15, align 8
  %p4034 = inttoptr i64 %v4033 to ptr
  store i32 2, ptr %p4034, align 4, !alias.scope !3, !noalias !4
  %v4035 = load i64, ptr %slot19, align 8
  %p4036 = inttoptr i64 %v4035 to ptr
  %ld4037 = load i32, ptr %p4036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4037, ptr %slot701, align 8
  %v4038 = load i32, ptr %slot701, align 8
  %v4039 = load i64, ptr %slot15, align 8
  %p4040 = inttoptr i64 %v4039 to ptr
  store i32 %v4038, ptr %p4040, align 4, !alias.scope !3, !noalias !4
  %v4041 = load i64, ptr %slot18, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  store i32 0, ptr %p4042, align 4, !alias.scope !3, !noalias !4
  %v4043 = load i64, ptr %slot14, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  store i32 1, ptr %p4044, align 4, !alias.scope !3, !noalias !4
  %v4045 = load i64, ptr %slot699, align 8
  %p4046 = inttoptr i64 %v4045 to ptr
  %ld4047 = load i64, ptr %p4046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4047, ptr %slot702, align 8
  %v4048 = load i64, ptr %slot702, align 8
  %v4049 = load i64, ptr %slot36, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  store i64 %v4048, ptr %p4050, align 8, !alias.scope !3, !noalias !4
  %p4051 = inttoptr i64 ptrtoint (ptr @myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 to i64) to ptr
  %ld4052 = load i64, ptr %p4051, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4052, ptr %slot703, align 8
  %v4053 = load i64, ptr %slot703, align 8
  %v4054 = load i64, ptr %slot37, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  store i64 %v4053, ptr %p4055, align 8, !alias.scope !3, !noalias !4
  %v4056 = load i64, ptr %slot37, align 8
  %p4057 = inttoptr i64 %v4056 to ptr
  %ld4058 = load i64, ptr %p4057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4058, ptr %slot704, align 8
  %v4059 = load i64, ptr %slot704, align 8
  %v4060 = load i64, ptr %slot24, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  store i64 %v4059, ptr %p4061, align 8, !alias.scope !3, !noalias !4
  %v4062 = load i64, ptr %slot24, align 8
  store i64 %v4062, ptr %slot705, align 8
  %v4063 = load i64, ptr %slot25, align 8
  store i64 %v4063, ptr %slot706, align 8
  %v4064 = load i64, ptr %slot705, align 8
  %v4065 = load i64, ptr %slot706, align 8
  %p4066 = inttoptr i64 %v4064 to ptr
  %p4067 = inttoptr i64 %v4065 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4067, ptr %p4066, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4068 = load i64, ptr %slot19, align 8
  %p4069 = inttoptr i64 %v4068 to ptr
  store i32 2, ptr %p4069, align 4, !alias.scope !3, !noalias !4
  %v4070 = load i64, ptr %slot18, align 8
  %p4071 = inttoptr i64 %v4070 to ptr
  store i32 1, ptr %p4071, align 4, !alias.scope !3, !noalias !4
  %v4072 = load i64, ptr %slot22, align 8
  store i64 %v4072, ptr %slot707, align 8
  %v4073 = load i64, ptr %slot25, align 8
  store i64 %v4073, ptr %slot708, align 8
  %v4074 = load i64, ptr %slot708, align 8
  %v4075 = load i64, ptr %slot707, align 8
  %p4076 = inttoptr i64 %v4074 to ptr
  %p4077 = inttoptr i64 %v4075 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4077, ptr %p4076, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot17, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  store i32 2, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  %v4080 = load i64, ptr %slot19, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  %ld4082 = load i32, ptr %p4081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4082, ptr %slot709, align 8
  %v4083 = load i32, ptr %slot709, align 8
  %v4084 = load i64, ptr %slot17, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  store i32 %v4083, ptr %p4085, align 4, !alias.scope !3, !noalias !4
  %v4086 = load i64, ptr %slot18, align 8
  %p4087 = inttoptr i64 %v4086 to ptr
  store i32 0, ptr %p4087, align 4, !alias.scope !3, !noalias !4
  %v4088 = load i64, ptr %slot16, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  store i32 1, ptr %p4089, align 4, !alias.scope !3, !noalias !4
  %v4090 = load i64, ptr %slot707, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %ld4092 = load i64, ptr %p4091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4092, ptr %slot710, align 8
  %v4093 = load i64, ptr %slot710, align 8
  %v4094 = load i64, ptr %slot37, align 8
  %p4095 = inttoptr i64 %v4094 to ptr
  store i64 %v4093, ptr %p4095, align 8, !alias.scope !3, !noalias !4
  %v4096 = load i64, ptr %slot36, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  %ld4098 = load i64, ptr %p4097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4098, ptr %slot711, align 8
  %v4099 = load i64, ptr %slot37, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  %ld4101 = load i64, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4101, ptr %slot712, align 8
  %v4102 = load i64, ptr %slot36, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %ld4104 = load i64, ptr %p4103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4104, ptr %slot713, align 8
  %v4105 = load i64, ptr %slot37, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %ld4107 = load i64, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4107, ptr %slot714, align 8
  %v4108 = load i64, ptr %slot53, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  %v4110 = load i64, ptr %slot713, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  %v4112 = load i64, ptr %slot714, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %call4114 = call ptr @myl_native_bytes_concat(ptr %p4109, ptr %p4111, ptr %p4113) nomerge, !dbg !188
  %calladdr4115 = ptrtoint ptr %call4114 to i64
  store i64 %calladdr4115, ptr %slot715, align 8
  %v4116 = load i64, ptr %slot715, align 8
  %cond4117 = icmp ne i64 %v4116, 0
  br i1 %cond4117, label %bb_success1187, label %bb_failed1187
bb_failed1187:
  %v4118 = load i64, ptr %slot1, align 8
  %p4119 = inttoptr i64 %v4118 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4119) nomerge, !dbg !188
  unreachable
bb_success1187:
  %v4120 = load i64, ptr %slot715, align 8
  %v4121 = load i64, ptr %slot36, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  store i64 %v4120, ptr %p4122, align 8, !alias.scope !3, !noalias !4
  %v4123 = load i64, ptr %slot36, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  %ld4125 = load i64, ptr %p4124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4125, ptr %slot716, align 8
  %v4126 = load i64, ptr %slot716, align 8
  %v4127 = load i64, ptr %slot23, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  store i64 %v4126, ptr %p4128, align 8, !alias.scope !3, !noalias !4
  %v4129 = load i64, ptr %slot23, align 8
  store i64 %v4129, ptr %slot717, align 8
  %v4130 = load i64, ptr %slot25, align 8
  store i64 %v4130, ptr %slot718, align 8
  %v4131 = load i64, ptr %slot717, align 8
  %v4132 = load i64, ptr %slot718, align 8
  %p4133 = inttoptr i64 %v4131 to ptr
  %p4134 = inttoptr i64 %v4132 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4134, ptr %p4133, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4135 = load i64, ptr %slot19, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  store i32 2, ptr %p4136, align 4, !alias.scope !3, !noalias !4
  %v4137 = load i64, ptr %slot18, align 8
  %p4138 = inttoptr i64 %v4137 to ptr
  store i32 1, ptr %p4138, align 4, !alias.scope !3, !noalias !4
  %v4139 = load i64, ptr %slot14, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  %ld4141 = load i32, ptr %p4140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4141, ptr %slot719, align 8
  %v4142 = load i32, ptr %slot719, align 8
  %cv4143 = zext i32 %v4142 to i64
  %cond4144 = icmp ne i64 %cv4143, 0
  br i1 %cond4144, label %bb_rcslotdrop1195, label %bb_rcslotdone1195
bb_rcslotdrop1195:
  %v4145 = load i64, ptr %slot14, align 8
  %p4146 = inttoptr i64 %v4145 to ptr
  store i32 0, ptr %p4146, align 4, !alias.scope !3, !noalias !4
  %v4147 = load i64, ptr %slot21, align 8
  store i64 %v4147, ptr %slot720, align 8
  %v4148 = load i64, ptr %slot15, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  %ld4150 = load i32, ptr %p4149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4150, ptr %slot721, align 8
  %v4151 = load i32, ptr %slot721, align 8
  %op4152 = and i32 %v4151, 28
  store i32 %op4152, ptr %slot722, align 8
  %v4153 = load i32, ptr %slot722, align 8
  %cv4154 = zext i32 %v4153 to i64
  %cond4155 = icmp ne i64 %cv4154, 0
  br i1 %cond4155, label %bb_rcslotrole1195, label %bb_rcslotowner1195
bb_rcslotrole1195:
  %v4156 = load i64, ptr %slot53, align 8
  store i64 %v4156, ptr %slot723, align 8
  %v4157 = load i64, ptr %slot720, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %ld4159 = load i64, ptr %p4158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4159, ptr %slot724, align 8
  %v4160 = load i64, ptr %slot724, align 8
  %cmp4161 = icmp ne i64 %v4160, 0
  %cv4162 = zext i1 %cmp4161 to i32
  store i32 %cv4162, ptr %slot725, align 8
  %v4163 = load i32, ptr %slot725, align 8
  %cv4164 = zext i32 %v4163 to i64
  %cond4165 = icmp ne i64 %cv4164, 0
  br i1 %cond4165, label %bb_rcgnn1211, label %bb_rcgdone1211
bb_rcgnn1211:
  %v4166 = load i64, ptr %slot724, align 8
  %op4167 = sub i64 %v4166, 16
  store i64 %op4167, ptr %slot726, align 8
  %v4168 = load i64, ptr %slot724, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  %rgep4170 = getelementptr i8, ptr %p4169, i64 -16
  %ld4171 = load i64, ptr %rgep4170, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4171, ptr %slot727, align 8
  %v4172 = load i64, ptr %slot727, align 8
  %op4173 = and i64 %v4172, 4611686018427387906
  store i64 %op4173, ptr %slot728, align 8
  %v4174 = load i64, ptr %slot728, align 8
  %cmp4175 = icmp ne i64 %v4174, 0
  %cv4176 = zext i1 %cmp4175 to i32
  store i32 %cv4176, ptr %slot729, align 8
  %v4177 = load i32, ptr %slot729, align 8
  %cv4178 = zext i32 %v4177 to i64
  %cond4179 = icmp ne i64 %cv4178, 0
  br i1 %cond4179, label %bb_rcgclear1211, label %bb_rcgcounted1211
bb_rcgcounted1211:
  %v4180 = load i64, ptr %slot724, align 8
  %op4181 = sub i64 %v4180, 24
  store i64 %op4181, ptr %slot730, align 8
  %v4182 = load i64, ptr %slot724, align 8
  %p4183 = inttoptr i64 %v4182 to ptr
  %rgep4184 = getelementptr i8, ptr %p4183, i64 -24
  %ld4185 = load i64, ptr %rgep4184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4185, ptr %slot731, align 8
  %v4186 = load i64, ptr %slot731, align 8
  %op4187 = sub i64 %v4186, 1
  store i64 %op4187, ptr %slot732, align 8
  %v4188 = load i64, ptr %slot732, align 8
  %cmp4189 = icmp eq i64 %v4188, 0
  %cv4190 = zext i1 %cmp4189 to i32
  store i32 %cv4190, ptr %slot733, align 8
  %v4191 = load i32, ptr %slot733, align 8
  %cv4192 = zext i32 %v4191 to i64
  %cond4193 = icmp ne i64 %cv4192, 0
  br i1 %cond4193, label %bb_rcglast1211, label %bb_rcgdec1211
bb_rcglast1211:
  %v4194 = load i64, ptr %slot724, align 8
  %op4195 = sub i64 %v4194, 32
  store i64 %op4195, ptr %slot734, align 8
  %v4196 = load i64, ptr %slot724, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  %rgep4198 = getelementptr i8, ptr %p4197, i64 -32
  %ld4199 = load i64, ptr %rgep4198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4199, ptr %slot735, align 8
  %v4200 = load i64, ptr %slot735, align 8
  %cmp4201 = icmp ne i64 %v4200, 0
  %cv4202 = zext i1 %cmp4201 to i32
  store i32 %cv4202, ptr %slot736, align 8
  %v4203 = load i32, ptr %slot736, align 8
  %cv4204 = zext i32 %v4203 to i64
  %cond4205 = icmp ne i64 %cv4204, 0
  br i1 %cond4205, label %bb_rcgdec1211, label %bb_rcgslow1211
bb_rcgslow1211:
  %v4206 = load i64, ptr %slot723, align 8
  %v4207 = load i64, ptr %slot720, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4206, i64 %v4207) nomerge, !dbg !188
  br label %bb_rcgdone1211
bb_rcgdec1211:
  %v4208 = load i64, ptr %slot732, align 8
  %v4209 = load i64, ptr %slot724, align 8
  %p4210 = inttoptr i64 %v4209 to ptr
  %rgep4211 = getelementptr i8, ptr %p4210, i64 -24
  store i64 %v4208, ptr %rgep4211, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1211
bb_rcgclear1211:
  %v4212 = load i64, ptr %slot720, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  store i64 0, ptr %p4213, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1211
bb_rcgdone1211:
  br label %bb_rcslotdone1195
bb_rcslotowner1195:
  %v4214 = load i64, ptr %slot53, align 8
  store i64 %v4214, ptr %slot737, align 8
  %v4215 = load i64, ptr %slot720, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i64, ptr %p4216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4217, ptr %slot738, align 8
  %v4218 = load i64, ptr %slot738, align 8
  %cmp4219 = icmp ne i64 %v4218, 0
  %cv4220 = zext i1 %cmp4219 to i32
  store i32 %cv4220, ptr %slot739, align 8
  %v4221 = load i32, ptr %slot739, align 8
  %cv4222 = zext i32 %v4221 to i64
  %cond4223 = icmp ne i64 %cv4222, 0
  br i1 %cond4223, label %bb_rcgnn1226, label %bb_rcgdone1226
bb_rcgnn1226:
  %v4224 = load i64, ptr %slot738, align 8
  %op4225 = sub i64 %v4224, 16
  store i64 %op4225, ptr %slot740, align 8
  %v4226 = load i64, ptr %slot738, align 8
  %p4227 = inttoptr i64 %v4226 to ptr
  %rgep4228 = getelementptr i8, ptr %p4227, i64 -16
  %ld4229 = load i64, ptr %rgep4228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4229, ptr %slot741, align 8
  %v4230 = load i64, ptr %slot741, align 8
  %op4231 = and i64 %v4230, 4611686018427387906
  store i64 %op4231, ptr %slot742, align 8
  %v4232 = load i64, ptr %slot742, align 8
  %cmp4233 = icmp ne i64 %v4232, 0
  %cv4234 = zext i1 %cmp4233 to i32
  store i32 %cv4234, ptr %slot743, align 8
  %v4235 = load i32, ptr %slot743, align 8
  %cv4236 = zext i32 %v4235 to i64
  %cond4237 = icmp ne i64 %cv4236, 0
  br i1 %cond4237, label %bb_rcgclear1226, label %bb_rcgcounted1226
bb_rcgcounted1226:
  %v4238 = load i64, ptr %slot738, align 8
  %op4239 = sub i64 %v4238, 32
  store i64 %op4239, ptr %slot744, align 8
  %v4240 = load i64, ptr %slot738, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  %rgep4242 = getelementptr i8, ptr %p4241, i64 -32
  %ld4243 = load i64, ptr %rgep4242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4243, ptr %slot745, align 8
  %v4244 = load i64, ptr %slot745, align 8
  %op4245 = sub i64 %v4244, 1
  store i64 %op4245, ptr %slot746, align 8
  %v4246 = load i64, ptr %slot746, align 8
  %cmp4247 = icmp eq i64 %v4246, 0
  %cv4248 = zext i1 %cmp4247 to i32
  store i32 %cv4248, ptr %slot747, align 8
  %v4249 = load i32, ptr %slot747, align 8
  %cv4250 = zext i32 %v4249 to i64
  %cond4251 = icmp ne i64 %cv4250, 0
  br i1 %cond4251, label %bb_rcglast1226, label %bb_rcgdec1226
bb_rcglast1226:
  %v4252 = load i64, ptr %slot738, align 8
  %op4253 = sub i64 %v4252, 24
  store i64 %op4253, ptr %slot748, align 8
  %v4254 = load i64, ptr %slot738, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  %rgep4256 = getelementptr i8, ptr %p4255, i64 -24
  %ld4257 = load i64, ptr %rgep4256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4257, ptr %slot749, align 8
  %v4258 = load i64, ptr %slot749, align 8
  %cmp4259 = icmp ne i64 %v4258, 0
  %cv4260 = zext i1 %cmp4259 to i32
  store i32 %cv4260, ptr %slot750, align 8
  %v4261 = load i32, ptr %slot750, align 8
  %cv4262 = zext i32 %v4261 to i64
  %cond4263 = icmp ne i64 %cv4262, 0
  br i1 %cond4263, label %bb_rcgdec1226, label %bb_rcgslow1226
bb_rcgslow1226:
  %v4264 = load i64, ptr %slot737, align 8
  %v4265 = load i64, ptr %slot720, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4264, i64 %v4265) nomerge, !dbg !188
  br label %bb_rcgdone1226
bb_rcgdec1226:
  %v4266 = load i64, ptr %slot746, align 8
  %v4267 = load i64, ptr %slot738, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  %rgep4269 = getelementptr i8, ptr %p4268, i64 -32
  store i64 %v4266, ptr %rgep4269, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1226
bb_rcgclear1226:
  %v4270 = load i64, ptr %slot720, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  store i64 0, ptr %p4271, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1226
bb_rcgdone1226:
  br label %bb_rcslotdone1195
bb_rcslotdone1195:
  %v4272 = load i64, ptr %slot16, align 8
  %p4273 = inttoptr i64 %v4272 to ptr
  %ld4274 = load i32, ptr %p4273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4274, ptr %slot751, align 8
  %v4275 = load i32, ptr %slot751, align 8
  %cv4276 = zext i32 %v4275 to i64
  %cond4277 = icmp ne i64 %cv4276, 0
  br i1 %cond4277, label %bb_rcslotdrop1232, label %bb_rcslotdone1232
bb_rcslotdrop1232:
  %v4278 = load i64, ptr %slot16, align 8
  %p4279 = inttoptr i64 %v4278 to ptr
  store i32 0, ptr %p4279, align 4, !alias.scope !3, !noalias !4
  %v4280 = load i64, ptr %slot22, align 8
  store i64 %v4280, ptr %slot752, align 8
  %v4281 = load i64, ptr %slot17, align 8
  %p4282 = inttoptr i64 %v4281 to ptr
  %ld4283 = load i32, ptr %p4282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4283, ptr %slot753, align 8
  %v4284 = load i32, ptr %slot753, align 8
  %op4285 = and i32 %v4284, 28
  store i32 %op4285, ptr %slot754, align 8
  %v4286 = load i32, ptr %slot754, align 8
  %cv4287 = zext i32 %v4286 to i64
  %cond4288 = icmp ne i64 %cv4287, 0
  br i1 %cond4288, label %bb_rcslotrole1232, label %bb_rcslotowner1232
bb_rcslotrole1232:
  %v4289 = load i64, ptr %slot53, align 8
  store i64 %v4289, ptr %slot755, align 8
  %v4290 = load i64, ptr %slot752, align 8
  %p4291 = inttoptr i64 %v4290 to ptr
  %ld4292 = load i64, ptr %p4291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4292, ptr %slot756, align 8
  %v4293 = load i64, ptr %slot756, align 8
  %cmp4294 = icmp ne i64 %v4293, 0
  %cv4295 = zext i1 %cmp4294 to i32
  store i32 %cv4295, ptr %slot757, align 8
  %v4296 = load i32, ptr %slot757, align 8
  %cv4297 = zext i32 %v4296 to i64
  %cond4298 = icmp ne i64 %cv4297, 0
  br i1 %cond4298, label %bb_rcgnn1248, label %bb_rcgdone1248
bb_rcgnn1248:
  %v4299 = load i64, ptr %slot756, align 8
  %op4300 = sub i64 %v4299, 16
  store i64 %op4300, ptr %slot758, align 8
  %v4301 = load i64, ptr %slot756, align 8
  %p4302 = inttoptr i64 %v4301 to ptr
  %rgep4303 = getelementptr i8, ptr %p4302, i64 -16
  %ld4304 = load i64, ptr %rgep4303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4304, ptr %slot759, align 8
  %v4305 = load i64, ptr %slot759, align 8
  %op4306 = and i64 %v4305, 4611686018427387906
  store i64 %op4306, ptr %slot760, align 8
  %v4307 = load i64, ptr %slot760, align 8
  %cmp4308 = icmp ne i64 %v4307, 0
  %cv4309 = zext i1 %cmp4308 to i32
  store i32 %cv4309, ptr %slot761, align 8
  %v4310 = load i32, ptr %slot761, align 8
  %cv4311 = zext i32 %v4310 to i64
  %cond4312 = icmp ne i64 %cv4311, 0
  br i1 %cond4312, label %bb_rcgclear1248, label %bb_rcgcounted1248
bb_rcgcounted1248:
  %v4313 = load i64, ptr %slot756, align 8
  %op4314 = sub i64 %v4313, 24
  store i64 %op4314, ptr %slot762, align 8
  %v4315 = load i64, ptr %slot756, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  %rgep4317 = getelementptr i8, ptr %p4316, i64 -24
  %ld4318 = load i64, ptr %rgep4317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4318, ptr %slot763, align 8
  %v4319 = load i64, ptr %slot763, align 8
  %op4320 = sub i64 %v4319, 1
  store i64 %op4320, ptr %slot764, align 8
  %v4321 = load i64, ptr %slot764, align 8
  %cmp4322 = icmp eq i64 %v4321, 0
  %cv4323 = zext i1 %cmp4322 to i32
  store i32 %cv4323, ptr %slot765, align 8
  %v4324 = load i32, ptr %slot765, align 8
  %cv4325 = zext i32 %v4324 to i64
  %cond4326 = icmp ne i64 %cv4325, 0
  br i1 %cond4326, label %bb_rcglast1248, label %bb_rcgdec1248
bb_rcglast1248:
  %v4327 = load i64, ptr %slot756, align 8
  %op4328 = sub i64 %v4327, 32
  store i64 %op4328, ptr %slot766, align 8
  %v4329 = load i64, ptr %slot756, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  %rgep4331 = getelementptr i8, ptr %p4330, i64 -32
  %ld4332 = load i64, ptr %rgep4331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4332, ptr %slot767, align 8
  %v4333 = load i64, ptr %slot767, align 8
  %cmp4334 = icmp ne i64 %v4333, 0
  %cv4335 = zext i1 %cmp4334 to i32
  store i32 %cv4335, ptr %slot768, align 8
  %v4336 = load i32, ptr %slot768, align 8
  %cv4337 = zext i32 %v4336 to i64
  %cond4338 = icmp ne i64 %cv4337, 0
  br i1 %cond4338, label %bb_rcgdec1248, label %bb_rcgslow1248
bb_rcgslow1248:
  %v4339 = load i64, ptr %slot755, align 8
  %v4340 = load i64, ptr %slot752, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4339, i64 %v4340) nomerge, !dbg !188
  br label %bb_rcgdone1248
bb_rcgdec1248:
  %v4341 = load i64, ptr %slot764, align 8
  %v4342 = load i64, ptr %slot756, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %rgep4344 = getelementptr i8, ptr %p4343, i64 -24
  store i64 %v4341, ptr %rgep4344, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1248
bb_rcgclear1248:
  %v4345 = load i64, ptr %slot752, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  store i64 0, ptr %p4346, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1248
bb_rcgdone1248:
  br label %bb_rcslotdone1232
bb_rcslotowner1232:
  %v4347 = load i64, ptr %slot53, align 8
  store i64 %v4347, ptr %slot769, align 8
  %v4348 = load i64, ptr %slot752, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  %ld4350 = load i64, ptr %p4349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4350, ptr %slot770, align 8
  %v4351 = load i64, ptr %slot770, align 8
  %cmp4352 = icmp ne i64 %v4351, 0
  %cv4353 = zext i1 %cmp4352 to i32
  store i32 %cv4353, ptr %slot771, align 8
  %v4354 = load i32, ptr %slot771, align 8
  %cv4355 = zext i32 %v4354 to i64
  %cond4356 = icmp ne i64 %cv4355, 0
  br i1 %cond4356, label %bb_rcgnn1263, label %bb_rcgdone1263
bb_rcgnn1263:
  %v4357 = load i64, ptr %slot770, align 8
  %op4358 = sub i64 %v4357, 16
  store i64 %op4358, ptr %slot772, align 8
  %v4359 = load i64, ptr %slot770, align 8
  %p4360 = inttoptr i64 %v4359 to ptr
  %rgep4361 = getelementptr i8, ptr %p4360, i64 -16
  %ld4362 = load i64, ptr %rgep4361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4362, ptr %slot773, align 8
  %v4363 = load i64, ptr %slot773, align 8
  %op4364 = and i64 %v4363, 4611686018427387906
  store i64 %op4364, ptr %slot774, align 8
  %v4365 = load i64, ptr %slot774, align 8
  %cmp4366 = icmp ne i64 %v4365, 0
  %cv4367 = zext i1 %cmp4366 to i32
  store i32 %cv4367, ptr %slot775, align 8
  %v4368 = load i32, ptr %slot775, align 8
  %cv4369 = zext i32 %v4368 to i64
  %cond4370 = icmp ne i64 %cv4369, 0
  br i1 %cond4370, label %bb_rcgclear1263, label %bb_rcgcounted1263
bb_rcgcounted1263:
  %v4371 = load i64, ptr %slot770, align 8
  %op4372 = sub i64 %v4371, 32
  store i64 %op4372, ptr %slot776, align 8
  %v4373 = load i64, ptr %slot770, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  %rgep4375 = getelementptr i8, ptr %p4374, i64 -32
  %ld4376 = load i64, ptr %rgep4375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4376, ptr %slot777, align 8
  %v4377 = load i64, ptr %slot777, align 8
  %op4378 = sub i64 %v4377, 1
  store i64 %op4378, ptr %slot778, align 8
  %v4379 = load i64, ptr %slot778, align 8
  %cmp4380 = icmp eq i64 %v4379, 0
  %cv4381 = zext i1 %cmp4380 to i32
  store i32 %cv4381, ptr %slot779, align 8
  %v4382 = load i32, ptr %slot779, align 8
  %cv4383 = zext i32 %v4382 to i64
  %cond4384 = icmp ne i64 %cv4383, 0
  br i1 %cond4384, label %bb_rcglast1263, label %bb_rcgdec1263
bb_rcglast1263:
  %v4385 = load i64, ptr %slot770, align 8
  %op4386 = sub i64 %v4385, 24
  store i64 %op4386, ptr %slot780, align 8
  %v4387 = load i64, ptr %slot770, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  %rgep4389 = getelementptr i8, ptr %p4388, i64 -24
  %ld4390 = load i64, ptr %rgep4389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4390, ptr %slot781, align 8
  %v4391 = load i64, ptr %slot781, align 8
  %cmp4392 = icmp ne i64 %v4391, 0
  %cv4393 = zext i1 %cmp4392 to i32
  store i32 %cv4393, ptr %slot782, align 8
  %v4394 = load i32, ptr %slot782, align 8
  %cv4395 = zext i32 %v4394 to i64
  %cond4396 = icmp ne i64 %cv4395, 0
  br i1 %cond4396, label %bb_rcgdec1263, label %bb_rcgslow1263
bb_rcgslow1263:
  %v4397 = load i64, ptr %slot769, align 8
  %v4398 = load i64, ptr %slot752, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4397, i64 %v4398) nomerge, !dbg !188
  br label %bb_rcgdone1263
bb_rcgdec1263:
  %v4399 = load i64, ptr %slot778, align 8
  %v4400 = load i64, ptr %slot770, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %rgep4402 = getelementptr i8, ptr %p4401, i64 -32
  store i64 %v4399, ptr %rgep4402, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1263
bb_rcgclear1263:
  %v4403 = load i64, ptr %slot752, align 8
  %p4404 = inttoptr i64 %v4403 to ptr
  store i64 0, ptr %p4404, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1263
bb_rcgdone1263:
  br label %bb_rcslotdone1232
bb_rcslotdone1232:
  %v4405 = load i64, ptr %slot21, align 8
  store i64 %v4405, ptr %slot783, align 8
  %v4406 = load i64, ptr %slot25, align 8
  store i64 %v4406, ptr %slot784, align 8
  %v4407 = load i64, ptr %slot784, align 8
  %v4408 = load i64, ptr %slot783, align 8
  %p4409 = inttoptr i64 %v4407 to ptr
  %p4410 = inttoptr i64 %v4408 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4410, ptr %p4409, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4411 = load i64, ptr %slot15, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  store i32 2, ptr %p4412, align 4, !alias.scope !3, !noalias !4
  %v4413 = load i64, ptr %slot19, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  %ld4415 = load i32, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4415, ptr %slot785, align 8
  %v4416 = load i32, ptr %slot785, align 8
  %v4417 = load i64, ptr %slot15, align 8
  %p4418 = inttoptr i64 %v4417 to ptr
  store i32 %v4416, ptr %p4418, align 4, !alias.scope !3, !noalias !4
  %v4419 = load i64, ptr %slot18, align 8
  %p4420 = inttoptr i64 %v4419 to ptr
  store i32 0, ptr %p4420, align 4, !alias.scope !3, !noalias !4
  %v4421 = load i64, ptr %slot14, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  store i32 1, ptr %p4422, align 4, !alias.scope !3, !noalias !4
  %v4423 = load i64, ptr %slot783, align 8
  %p4424 = inttoptr i64 %v4423 to ptr
  %ld4425 = load i64, ptr %p4424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4425, ptr %slot786, align 8
  %v4426 = load i64, ptr %slot786, align 8
  %v4427 = load i64, ptr %slot36, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  store i64 %v4426, ptr %p4428, align 8, !alias.scope !3, !noalias !4
  %v4429 = load i64, ptr %slot27, align 8
  %p4430 = inttoptr i64 %v4429 to ptr
  %ld4431 = load i64, ptr %p4430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4431, ptr %slot787, align 8
  %v4432 = load i64, ptr %slot787, align 8
  %v4433 = load i64, ptr %slot37, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  store i64 %v4432, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  %v4435 = load i64, ptr %slot37, align 8
  %p4436 = inttoptr i64 %v4435 to ptr
  %ld4437 = load i64, ptr %p4436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4437, ptr %slot788, align 8
  %v4438 = load i64, ptr %slot788, align 8
  %op4439 = add i64 %v4438, 8
  store i64 %op4439, ptr %slot789, align 8
  %v4440 = load i64, ptr %slot789, align 8
  %v4441 = load i64, ptr %slot37, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i64 %v4440, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot16, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i32, ptr %p4444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4445, ptr %slot790, align 8
  %v4446 = load i32, ptr %slot790, align 8
  %cv4447 = zext i32 %v4446 to i64
  %cond4448 = icmp ne i64 %cv4447, 0
  br i1 %cond4448, label %bb_rcslotdrop1281, label %bb_rcslotdone1281
bb_rcslotdrop1281:
  %v4449 = load i64, ptr %slot16, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  store i32 0, ptr %p4450, align 4, !alias.scope !3, !noalias !4
  %v4451 = load i64, ptr %slot22, align 8
  store i64 %v4451, ptr %slot791, align 8
  %v4452 = load i64, ptr %slot17, align 8
  %p4453 = inttoptr i64 %v4452 to ptr
  %ld4454 = load i32, ptr %p4453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4454, ptr %slot792, align 8
  %v4455 = load i32, ptr %slot792, align 8
  %op4456 = and i32 %v4455, 28
  store i32 %op4456, ptr %slot793, align 8
  %v4457 = load i32, ptr %slot793, align 8
  %cv4458 = zext i32 %v4457 to i64
  %cond4459 = icmp ne i64 %cv4458, 0
  br i1 %cond4459, label %bb_rcslotrole1281, label %bb_rcslotowner1281
bb_rcslotrole1281:
  %v4460 = load i64, ptr %slot53, align 8
  store i64 %v4460, ptr %slot794, align 8
  %v4461 = load i64, ptr %slot794, align 8
  %v4462 = load i64, ptr %slot791, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v4461, i64 %v4462) nomerge, !dbg !190
  br label %bb_rcslotdone1281
bb_rcslotowner1281:
  %v4463 = load i64, ptr %slot53, align 8
  store i64 %v4463, ptr %slot795, align 8
  %v4464 = load i64, ptr %slot795, align 8
  %v4465 = load i64, ptr %slot791, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v4464, i64 %v4465) nomerge, !dbg !190
  br label %bb_rcslotdone1281
bb_rcslotdone1281:
  %v4466 = load i64, ptr %slot37, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  %ld4468 = load i64, ptr %p4467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4468, ptr %slot796, align 8
  %v4469 = load i64, ptr %slot796, align 8
  %op4470 = add i64 %v4469, 24
  store i64 %op4470, ptr %slot797, align 8
  %v4471 = load i64, ptr %slot797, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %ld4473 = load i64, ptr %p4472, align 8
  store i64 %ld4473, ptr %slot798, align 8
  %v4474 = load i64, ptr %slot798, align 8
  %v4475 = load i64, ptr %slot37, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  store i64 %v4474, ptr %p4476, align 8, !alias.scope !3, !noalias !4
  %v4477 = load i64, ptr %slot16, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  %ld4479 = load i32, ptr %p4478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4479, ptr %slot799, align 8
  %v4480 = load i32, ptr %slot799, align 8
  %cv4481 = zext i32 %v4480 to i64
  %cond4482 = icmp ne i64 %cv4481, 0
  br i1 %cond4482, label %bb_rcslotdrop1293, label %bb_rcslotdone1293
bb_rcslotdrop1293:
  %v4483 = load i64, ptr %slot16, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  store i32 0, ptr %p4484, align 4, !alias.scope !3, !noalias !4
  %v4485 = load i64, ptr %slot22, align 8
  store i64 %v4485, ptr %slot800, align 8
  %v4486 = load i64, ptr %slot17, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %ld4488 = load i32, ptr %p4487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4488, ptr %slot801, align 8
  %v4489 = load i32, ptr %slot801, align 8
  %op4490 = and i32 %v4489, 28
  store i32 %op4490, ptr %slot802, align 8
  %v4491 = load i32, ptr %slot802, align 8
  %cv4492 = zext i32 %v4491 to i64
  %cond4493 = icmp ne i64 %cv4492, 0
  br i1 %cond4493, label %bb_rcslotrole1293, label %bb_rcslotowner1293
bb_rcslotrole1293:
  %v4494 = load i64, ptr %slot53, align 8
  store i64 %v4494, ptr %slot803, align 8
  %v4495 = load i64, ptr %slot803, align 8
  %v4496 = load i64, ptr %slot800, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4495, i64 %v4496) nomerge, !dbg !192
  br label %bb_rcslotdone1293
bb_rcslotowner1293:
  %v4497 = load i64, ptr %slot53, align 8
  store i64 %v4497, ptr %slot804, align 8
  %v4498 = load i64, ptr %slot804, align 8
  %v4499 = load i64, ptr %slot800, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4498, i64 %v4499) nomerge, !dbg !192
  br label %bb_rcslotdone1293
bb_rcslotdone1293:
  %v4500 = load i64, ptr %slot36, align 8
  %p4501 = inttoptr i64 %v4500 to ptr
  %ld4502 = load i64, ptr %p4501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4502, ptr %slot805, align 8
  %v4503 = load i64, ptr %slot37, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  %ld4505 = load i64, ptr %p4504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4505, ptr %slot806, align 8
  %v4506 = load i64, ptr %slot1, align 8
  %v4507 = load i64, ptr %slot805, align 8
  %v4508 = load i64, ptr %slot806, align 8
  %call4509 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v4506, i64 %v4507, i64 %v4508) nomerge, !dbg !194
  store { i64, i64 } %call4509, ptr %callresult808, align 8
  %addr4510 = ptrtoint ptr %callresult808 to i64
  store i64 %addr4510, ptr %slot807, align 8
  %v4511 = load i64, ptr %slot807, align 8
  %v4512 = load i64, ptr %slot36, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  store i64 %v4511, ptr %p4513, align 8, !alias.scope !3, !noalias !4
  %v4514 = load i64, ptr %slot36, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  %ld4516 = load i64, ptr %p4515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4516, ptr %slot809, align 8
  %v4517 = load i64, ptr %slot25, align 8
  store i64 %v4517, ptr %slot810, align 8
  %v4518 = load i64, ptr %slot53, align 8
  %v4519 = load i64, ptr %slot810, align 8
  %v4520 = load i64, ptr %slot809, align 8
  %call4521 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v4518, i64 %v4519, i64 %v4520) nomerge, !dbg !194
  store i32 %call4521, ptr %slot811, align 8
  %v4522 = load i32, ptr %slot811, align 8
  %cv4523 = zext i32 %v4522 to i64
  %cond4524 = icmp ne i64 %cv4523, 0
  br i1 %cond4524, label %bb_rcsuccess1306, label %bb_rcfailure1306
bb_rcfailure1306:
  %v4525 = load i64, ptr %slot53, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %call4527 = call i32 @myl_rc_take_failure(ptr %p4526) nomerge, !dbg !194
  store i32 %call4527, ptr %slot812, align 8
  %v4528 = load i64, ptr %slot1, align 8
  %p4529 = inttoptr i64 %v4528 to ptr
  %v4530 = load i32, ptr %slot812, align 8
  %call4531 = call i32 @myl_qbe_rc_status(ptr %p4529, i32 %v4530) nomerge, !dbg !194
  store i32 %call4531, ptr %slot813, align 8
  br label %bb_failure
bb_rcsuccess1306:
  %v4532 = load i64, ptr %slot19, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  store i32 2, ptr %p4533, align 4, !alias.scope !3, !noalias !4
  %v4534 = load i64, ptr %slot19, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  store i32 16, ptr %p4535, align 4, !alias.scope !3, !noalias !4
  %v4536 = load i64, ptr %slot18, align 8
  %p4537 = inttoptr i64 %v4536 to ptr
  store i32 1, ptr %p4537, align 4, !alias.scope !3, !noalias !4
  %v4538 = load i64, ptr %slot14, align 8
  %p4539 = inttoptr i64 %v4538 to ptr
  %ld4540 = load i32, ptr %p4539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4540, ptr %slot814, align 8
  %v4541 = load i32, ptr %slot814, align 8
  %cv4542 = zext i32 %v4541 to i64
  %cond4543 = icmp ne i64 %cv4542, 0
  br i1 %cond4543, label %bb_rcslotdrop1314, label %bb_rcslotdone1314
bb_rcslotdrop1314:
  %v4544 = load i64, ptr %slot14, align 8
  %p4545 = inttoptr i64 %v4544 to ptr
  store i32 0, ptr %p4545, align 4, !alias.scope !3, !noalias !4
  %v4546 = load i64, ptr %slot21, align 8
  store i64 %v4546, ptr %slot815, align 8
  %v4547 = load i64, ptr %slot15, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  %ld4549 = load i32, ptr %p4548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4549, ptr %slot816, align 8
  %v4550 = load i32, ptr %slot816, align 8
  %op4551 = and i32 %v4550, 28
  store i32 %op4551, ptr %slot817, align 8
  %v4552 = load i32, ptr %slot817, align 8
  %cv4553 = zext i32 %v4552 to i64
  %cond4554 = icmp ne i64 %cv4553, 0
  br i1 %cond4554, label %bb_rcslotrole1314, label %bb_rcslotowner1314
bb_rcslotrole1314:
  %v4555 = load i64, ptr %slot53, align 8
  store i64 %v4555, ptr %slot818, align 8
  %v4556 = load i64, ptr %slot815, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  %ld4558 = load i64, ptr %p4557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4558, ptr %slot819, align 8
  %v4559 = load i64, ptr %slot819, align 8
  %cmp4560 = icmp ne i64 %v4559, 0
  %cv4561 = zext i1 %cmp4560 to i32
  store i32 %cv4561, ptr %slot820, align 8
  %v4562 = load i32, ptr %slot820, align 8
  %cv4563 = zext i32 %v4562 to i64
  %cond4564 = icmp ne i64 %cv4563, 0
  br i1 %cond4564, label %bb_rcgnn1330, label %bb_rcgdone1330
bb_rcgnn1330:
  %v4565 = load i64, ptr %slot819, align 8
  %op4566 = sub i64 %v4565, 16
  store i64 %op4566, ptr %slot821, align 8
  %v4567 = load i64, ptr %slot819, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %rgep4569 = getelementptr i8, ptr %p4568, i64 -16
  %ld4570 = load i64, ptr %rgep4569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4570, ptr %slot822, align 8
  %v4571 = load i64, ptr %slot822, align 8
  %op4572 = and i64 %v4571, 4611686018427387906
  store i64 %op4572, ptr %slot823, align 8
  %v4573 = load i64, ptr %slot823, align 8
  %cmp4574 = icmp ne i64 %v4573, 0
  %cv4575 = zext i1 %cmp4574 to i32
  store i32 %cv4575, ptr %slot824, align 8
  %v4576 = load i32, ptr %slot824, align 8
  %cv4577 = zext i32 %v4576 to i64
  %cond4578 = icmp ne i64 %cv4577, 0
  br i1 %cond4578, label %bb_rcgclear1330, label %bb_rcgcounted1330
bb_rcgcounted1330:
  %v4579 = load i64, ptr %slot819, align 8
  %op4580 = sub i64 %v4579, 24
  store i64 %op4580, ptr %slot825, align 8
  %v4581 = load i64, ptr %slot819, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  %rgep4583 = getelementptr i8, ptr %p4582, i64 -24
  %ld4584 = load i64, ptr %rgep4583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4584, ptr %slot826, align 8
  %v4585 = load i64, ptr %slot826, align 8
  %op4586 = sub i64 %v4585, 1
  store i64 %op4586, ptr %slot827, align 8
  %v4587 = load i64, ptr %slot827, align 8
  %cmp4588 = icmp eq i64 %v4587, 0
  %cv4589 = zext i1 %cmp4588 to i32
  store i32 %cv4589, ptr %slot828, align 8
  %v4590 = load i32, ptr %slot828, align 8
  %cv4591 = zext i32 %v4590 to i64
  %cond4592 = icmp ne i64 %cv4591, 0
  br i1 %cond4592, label %bb_rcglast1330, label %bb_rcgdec1330
bb_rcglast1330:
  %v4593 = load i64, ptr %slot819, align 8
  %op4594 = sub i64 %v4593, 32
  store i64 %op4594, ptr %slot829, align 8
  %v4595 = load i64, ptr %slot819, align 8
  %p4596 = inttoptr i64 %v4595 to ptr
  %rgep4597 = getelementptr i8, ptr %p4596, i64 -32
  %ld4598 = load i64, ptr %rgep4597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4598, ptr %slot830, align 8
  %v4599 = load i64, ptr %slot830, align 8
  %cmp4600 = icmp ne i64 %v4599, 0
  %cv4601 = zext i1 %cmp4600 to i32
  store i32 %cv4601, ptr %slot831, align 8
  %v4602 = load i32, ptr %slot831, align 8
  %cv4603 = zext i32 %v4602 to i64
  %cond4604 = icmp ne i64 %cv4603, 0
  br i1 %cond4604, label %bb_rcgdec1330, label %bb_rcgslow1330
bb_rcgslow1330:
  %v4605 = load i64, ptr %slot818, align 8
  %v4606 = load i64, ptr %slot815, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4605, i64 %v4606) nomerge, !dbg !194
  br label %bb_rcgdone1330
bb_rcgdec1330:
  %v4607 = load i64, ptr %slot827, align 8
  %v4608 = load i64, ptr %slot819, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  %rgep4610 = getelementptr i8, ptr %p4609, i64 -24
  store i64 %v4607, ptr %rgep4610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1330
bb_rcgclear1330:
  %v4611 = load i64, ptr %slot815, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  store i64 0, ptr %p4612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1330
bb_rcgdone1330:
  br label %bb_rcslotdone1314
bb_rcslotowner1314:
  %v4613 = load i64, ptr %slot53, align 8
  store i64 %v4613, ptr %slot832, align 8
  %v4614 = load i64, ptr %slot815, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  %ld4616 = load i64, ptr %p4615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4616, ptr %slot833, align 8
  %v4617 = load i64, ptr %slot833, align 8
  %cmp4618 = icmp ne i64 %v4617, 0
  %cv4619 = zext i1 %cmp4618 to i32
  store i32 %cv4619, ptr %slot834, align 8
  %v4620 = load i32, ptr %slot834, align 8
  %cv4621 = zext i32 %v4620 to i64
  %cond4622 = icmp ne i64 %cv4621, 0
  br i1 %cond4622, label %bb_rcgnn1345, label %bb_rcgdone1345
bb_rcgnn1345:
  %v4623 = load i64, ptr %slot833, align 8
  %op4624 = sub i64 %v4623, 16
  store i64 %op4624, ptr %slot835, align 8
  %v4625 = load i64, ptr %slot833, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %rgep4627 = getelementptr i8, ptr %p4626, i64 -16
  %ld4628 = load i64, ptr %rgep4627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4628, ptr %slot836, align 8
  %v4629 = load i64, ptr %slot836, align 8
  %op4630 = and i64 %v4629, 4611686018427387906
  store i64 %op4630, ptr %slot837, align 8
  %v4631 = load i64, ptr %slot837, align 8
  %cmp4632 = icmp ne i64 %v4631, 0
  %cv4633 = zext i1 %cmp4632 to i32
  store i32 %cv4633, ptr %slot838, align 8
  %v4634 = load i32, ptr %slot838, align 8
  %cv4635 = zext i32 %v4634 to i64
  %cond4636 = icmp ne i64 %cv4635, 0
  br i1 %cond4636, label %bb_rcgclear1345, label %bb_rcgcounted1345
bb_rcgcounted1345:
  %v4637 = load i64, ptr %slot833, align 8
  %op4638 = sub i64 %v4637, 32
  store i64 %op4638, ptr %slot839, align 8
  %v4639 = load i64, ptr %slot833, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %rgep4641 = getelementptr i8, ptr %p4640, i64 -32
  %ld4642 = load i64, ptr %rgep4641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4642, ptr %slot840, align 8
  %v4643 = load i64, ptr %slot840, align 8
  %op4644 = sub i64 %v4643, 1
  store i64 %op4644, ptr %slot841, align 8
  %v4645 = load i64, ptr %slot841, align 8
  %cmp4646 = icmp eq i64 %v4645, 0
  %cv4647 = zext i1 %cmp4646 to i32
  store i32 %cv4647, ptr %slot842, align 8
  %v4648 = load i32, ptr %slot842, align 8
  %cv4649 = zext i32 %v4648 to i64
  %cond4650 = icmp ne i64 %cv4649, 0
  br i1 %cond4650, label %bb_rcglast1345, label %bb_rcgdec1345
bb_rcglast1345:
  %v4651 = load i64, ptr %slot833, align 8
  %op4652 = sub i64 %v4651, 24
  store i64 %op4652, ptr %slot843, align 8
  %v4653 = load i64, ptr %slot833, align 8
  %p4654 = inttoptr i64 %v4653 to ptr
  %rgep4655 = getelementptr i8, ptr %p4654, i64 -24
  %ld4656 = load i64, ptr %rgep4655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4656, ptr %slot844, align 8
  %v4657 = load i64, ptr %slot844, align 8
  %cmp4658 = icmp ne i64 %v4657, 0
  %cv4659 = zext i1 %cmp4658 to i32
  store i32 %cv4659, ptr %slot845, align 8
  %v4660 = load i32, ptr %slot845, align 8
  %cv4661 = zext i32 %v4660 to i64
  %cond4662 = icmp ne i64 %cv4661, 0
  br i1 %cond4662, label %bb_rcgdec1345, label %bb_rcgslow1345
bb_rcgslow1345:
  %v4663 = load i64, ptr %slot832, align 8
  %v4664 = load i64, ptr %slot815, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4663, i64 %v4664) nomerge, !dbg !194
  br label %bb_rcgdone1345
bb_rcgdec1345:
  %v4665 = load i64, ptr %slot841, align 8
  %v4666 = load i64, ptr %slot833, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  %rgep4668 = getelementptr i8, ptr %p4667, i64 -32
  store i64 %v4665, ptr %rgep4668, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1345
bb_rcgclear1345:
  %v4669 = load i64, ptr %slot815, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  store i64 0, ptr %p4670, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1345
bb_rcgdone1345:
  br label %bb_rcslotdone1314
bb_rcslotdone1314:
  %v4671 = load i64, ptr %slot21, align 8
  store i64 %v4671, ptr %slot846, align 8
  %v4672 = load i64, ptr %slot25, align 8
  store i64 %v4672, ptr %slot847, align 8
  %v4673 = load i64, ptr %slot847, align 8
  %v4674 = load i64, ptr %slot846, align 8
  %p4675 = inttoptr i64 %v4673 to ptr
  %p4676 = inttoptr i64 %v4674 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4676, ptr %p4675, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4677 = load i64, ptr %slot15, align 8
  %p4678 = inttoptr i64 %v4677 to ptr
  store i32 2, ptr %p4678, align 4, !alias.scope !3, !noalias !4
  %v4679 = load i64, ptr %slot19, align 8
  %p4680 = inttoptr i64 %v4679 to ptr
  %ld4681 = load i32, ptr %p4680, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4681, ptr %slot848, align 8
  %v4682 = load i32, ptr %slot848, align 8
  %v4683 = load i64, ptr %slot15, align 8
  %p4684 = inttoptr i64 %v4683 to ptr
  store i32 %v4682, ptr %p4684, align 4, !alias.scope !3, !noalias !4
  %v4685 = load i64, ptr %slot18, align 8
  %p4686 = inttoptr i64 %v4685 to ptr
  store i32 0, ptr %p4686, align 4, !alias.scope !3, !noalias !4
  %v4687 = load i64, ptr %slot14, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  store i32 1, ptr %p4688, align 4, !alias.scope !3, !noalias !4
  %v4689 = load i64, ptr %slot846, align 8
  %v4690 = load i64, ptr %slot36, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  store i64 %v4689, ptr %p4691, align 8, !alias.scope !3, !noalias !4
  %v4692 = load i64, ptr %slot47, align 8
  store i64 %v4692, ptr %slot849, align 8
  %v4693 = load i64, ptr %slot849, align 8
  %p4694 = inttoptr i64 %v4693 to ptr
  store i64 0, ptr %p4694, align 8, !alias.scope !3, !noalias !4
  %v4695 = load i64, ptr %slot849, align 8
  %p4697 = inttoptr i64 %v4695 to ptr
  %gep4698 = getelementptr i8, ptr %p4697, i64 8
  %op4696 = ptrtoint ptr %gep4698 to i64
  store i64 %op4696, ptr %slot850, align 8
  %v4699 = load i64, ptr %slot850, align 8
  %p4700 = inttoptr i64 %v4699 to ptr
  store i64 0, ptr %p4700, align 8, !alias.scope !3, !noalias !4
  %v4701 = load i64, ptr %slot849, align 8
  %p4703 = inttoptr i64 %v4701 to ptr
  %gep4704 = getelementptr i8, ptr %p4703, i64 16
  %op4702 = ptrtoint ptr %gep4704 to i64
  store i64 %op4702, ptr %slot851, align 8
  %v4705 = load i64, ptr %slot851, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  store i64 0, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  %v4707 = load i64, ptr %slot849, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  store i32 1, ptr %p4708, align 4, !alias.scope !3, !noalias !4
  %v4709 = load i64, ptr %slot20, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  store i32 1, ptr %p4710, align 4, !alias.scope !3, !noalias !4
  %v4711 = load i64, ptr %slot36, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %ld4713 = load i64, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4713, ptr %slot852, align 8
  %v4714 = load i64, ptr %slot849, align 8
  %p4716 = inttoptr i64 %v4714 to ptr
  %gep4717 = getelementptr i8, ptr %p4716, i64 8
  %op4715 = ptrtoint ptr %gep4717 to i64
  store i64 %op4715, ptr %slot853, align 8
  %v4718 = load i64, ptr %slot54, align 8
  store i64 %v4718, ptr %slot854, align 8
  %v4719 = load i64, ptr %slot36, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i64, ptr %p4720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4721, ptr %slot855, align 8
  %v4722 = load i64, ptr %slot14, align 8
  %p4723 = inttoptr i64 %v4722 to ptr
  %ld4724 = load i32, ptr %p4723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4724, ptr %slot856, align 8
  %v4725 = load i64, ptr %slot15, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %ld4727 = load i32, ptr %p4726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4727, ptr %slot857, align 8
  %v4728 = load i32, ptr %slot857, align 8
  %op4729 = and i32 %v4728, 24
  store i32 %op4729, ptr %slot857, align 8
  %v4730 = load i32, ptr %slot857, align 8
  %cmp4731 = icmp eq i32 %v4730, 0
  %cv4732 = zext i1 %cmp4731 to i32
  store i32 %cv4732, ptr %slot858, align 8
  %v4733 = load i32, ptr %slot856, align 8
  %v4734 = load i32, ptr %slot858, align 8
  %op4735 = and i32 %v4733, %v4734
  store i32 %op4735, ptr %slot859, align 8
  %v4736 = load i32, ptr %slot859, align 8
  %cv4737 = zext i32 %v4736 to i64
  %cond4738 = icmp ne i64 %cv4737, 0
  br i1 %cond4738, label %bb_rctake1366, label %bb_rccopy1366
bb_rctake1366:
  %v4739 = load i64, ptr %slot25, align 8
  store i64 %v4739, ptr %slot860, align 8
  %v4740 = load i64, ptr %slot54, align 8
  store i64 %v4740, ptr %slot861, align 8
  %v4741 = load i64, ptr %slot855, align 8
  %v4742 = load i64, ptr %slot860, align 8
  %op4743 = sub i64 %v4741, %v4742
  store i64 %op4743, ptr %slot862, align 8
  %v4744 = load i64, ptr %slot860, align 8
  %v4745 = load i64, ptr %slot855, align 8
  %op4746 = sub i64 %v4744, %v4745
  store i64 %op4746, ptr %slot863, align 8
  %v4747 = load i64, ptr %slot862, align 8
  %cmp4748 = icmp ult i64 %v4747, 16
  %cv4749 = zext i1 %cmp4748 to i32
  store i32 %cv4749, ptr %slot864, align 8
  %v4750 = load i64, ptr %slot863, align 8
  %cmp4751 = icmp ult i64 %v4750, 16
  %cv4752 = zext i1 %cmp4751 to i32
  store i32 %cv4752, ptr %slot865, align 8
  %v4753 = load i32, ptr %slot864, align 8
  %v4754 = load i32, ptr %slot865, align 8
  %op4755 = or i32 %v4753, %v4754
  store i32 %op4755, ptr %slot866, align 8
  %v4756 = load i32, ptr %slot866, align 8
  %cv4757 = zext i32 %v4756 to i64
  %cond4758 = icmp ne i64 %cv4757, 0
  br i1 %cond4758, label %bb_rcmoveslow1375, label %bb_rcmovecheck1375
bb_rcmovecheck1375:
  %v4759 = load i64, ptr %slot855, align 8
  %op4760 = add i64 %v4759, 0
  store i64 %op4760, ptr %slot867, align 8
  %v4761 = load i64, ptr %slot867, align 8
  %p4762 = inttoptr i64 %v4761 to ptr
  %ld4763 = load i64, ptr %p4762, align 8
  store i64 %ld4763, ptr %slot868, align 8
  %v4764 = load i64, ptr %slot868, align 8
  %cmp4765 = icmp ne i64 %v4764, 0
  %cv4766 = zext i1 %cmp4765 to i32
  store i32 %cv4766, ptr %slot869, align 8
  %v4767 = load i32, ptr %slot869, align 8
  %cv4768 = zext i32 %v4767 to i64
  %cond4769 = icmp ne i64 %cv4768, 0
  br i1 %cond4769, label %bb_rcmoveheader1383, label %bb_rcmovenext1383
bb_rcmoveheader1383:
  %v4770 = load i64, ptr %slot868, align 8
  %op4771 = sub i64 %v4770, 16
  store i64 %op4771, ptr %slot870, align 8
  %v4772 = load i64, ptr %slot868, align 8
  %p4773 = inttoptr i64 %v4772 to ptr
  %rgep4774 = getelementptr i8, ptr %p4773, i64 -16
  %ld4775 = load i64, ptr %rgep4774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4775, ptr %slot871, align 8
  %v4776 = load i64, ptr %slot871, align 8
  %op4777 = and i64 %v4776, 5764607523034234881
  store i64 %op4777, ptr %slot872, align 8
  %v4778 = load i64, ptr %slot872, align 8
  %cmp4779 = icmp ne i64 %v4778, 0
  %cv4780 = zext i1 %cmp4779 to i32
  store i32 %cv4780, ptr %slot873, align 8
  %v4781 = load i32, ptr %slot873, align 8
  %cv4782 = zext i32 %v4781 to i64
  %cond4783 = icmp ne i64 %cv4782, 0
  br i1 %cond4783, label %bb_rcmoveslow1375, label %bb_rcmovenext1383
bb_rcmovenext1383:
  %v4784 = load i64, ptr %slot855, align 8
  %v4785 = load i64, ptr %slot860, align 8
  %p4786 = inttoptr i64 %v4784 to ptr
  %p4787 = inttoptr i64 %v4785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4787, ptr %p4786, i64 16, i1 false)
  %v4788 = load i64, ptr %slot855, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  store i64 0, ptr %p4789, align 8
  %v4790 = load i64, ptr %slot855, align 8
  %op4791 = add i64 %v4790, 8
  store i64 %op4791, ptr %slot874, align 8
  %v4792 = load i64, ptr %slot874, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i64 0, ptr %p4793, align 8
  br label %bb_rcmoved1375
bb_rcmoveslow1375:
  %v4794 = load i64, ptr %slot53, align 8
  %v4795 = load i64, ptr %slot860, align 8
  %v4796 = load i64, ptr %slot855, align 8
  %v4797 = load i64, ptr %slot861, align 8
  %cv4798 = trunc i64 %v4797 to i32
  %call4799 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v4794, i64 %v4795, i64 %v4796, i32 %cv4798) nomerge, !dbg !196
  store i32 %call4799, ptr %slot875, align 8
  %v4800 = load i32, ptr %slot875, align 8
  %cv4801 = zext i32 %v4800 to i64
  %cond4802 = icmp ne i64 %cv4801, 0
  br i1 %cond4802, label %bb_rcsuccess1391, label %bb_rcfailure1391
bb_rcfailure1391:
  %v4803 = load i64, ptr %slot53, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %call4805 = call i32 @myl_rc_take_failure(ptr %p4804) nomerge, !dbg !196
  store i32 %call4805, ptr %slot876, align 8
  %v4806 = load i64, ptr %slot1, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  %v4808 = load i32, ptr %slot876, align 8
  %call4809 = call i32 @myl_qbe_rc_status(ptr %p4807, i32 %v4808) nomerge, !dbg !196
  store i32 %call4809, ptr %slot877, align 8
  br label %bb_failure
bb_rcsuccess1391:
  br label %bb_rcmoved1375
bb_rcmoved1375:
  %v4810 = load i64, ptr %slot14, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  store i32 0, ptr %p4811, align 4, !alias.scope !3, !noalias !4
  %v4812 = load i64, ptr %slot19, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  store i32 2, ptr %p4813, align 4, !alias.scope !3, !noalias !4
  %v4814 = load i64, ptr %slot18, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  store i32 1, ptr %p4815, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1366
bb_rccopy1366:
  %v4816 = load i64, ptr %slot25, align 8
  store i64 %v4816, ptr %slot878, align 8
  %v4817 = load i64, ptr %slot54, align 8
  store i64 %v4817, ptr %slot879, align 8
  %v4818 = load i64, ptr %slot53, align 8
  %v4819 = load i64, ptr %slot878, align 8
  %v4820 = load i64, ptr %slot855, align 8
  %v4821 = load i64, ptr %slot879, align 8
  %cv4822 = trunc i64 %v4821 to i32
  %call4823 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v4818, i64 %v4819, i64 %v4820, i32 %cv4822) nomerge, !dbg !196
  store i32 %call4823, ptr %slot880, align 8
  %v4824 = load i32, ptr %slot880, align 8
  %cv4825 = zext i32 %v4824 to i64
  %cond4826 = icmp ne i64 %cv4825, 0
  br i1 %cond4826, label %bb_rcsuccess1400, label %bb_rcfailure1400
bb_rcfailure1400:
  %v4827 = load i64, ptr %slot53, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  %call4829 = call i32 @myl_rc_take_failure(ptr %p4828) nomerge, !dbg !196
  store i32 %call4829, ptr %slot881, align 8
  %v4830 = load i64, ptr %slot1, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  %v4832 = load i32, ptr %slot881, align 8
  %call4833 = call i32 @myl_qbe_rc_status(ptr %p4831, i32 %v4832) nomerge, !dbg !196
  store i32 %call4833, ptr %slot882, align 8
  br label %bb_failure
bb_rcsuccess1400:
  %v4834 = load i64, ptr %slot19, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  store i32 2, ptr %p4835, align 4, !alias.scope !3, !noalias !4
  %v4836 = load i64, ptr %slot18, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  store i32 1, ptr %p4837, align 4, !alias.scope !3, !noalias !4
  %v4838 = load i64, ptr %slot14, align 8
  %p4839 = inttoptr i64 %v4838 to ptr
  %ld4840 = load i32, ptr %p4839, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4840, ptr %slot883, align 8
  %v4841 = load i32, ptr %slot883, align 8
  %cv4842 = zext i32 %v4841 to i64
  %cond4843 = icmp ne i64 %cv4842, 0
  br i1 %cond4843, label %bb_rcslotdrop1407, label %bb_rcslotdone1407
bb_rcslotdrop1407:
  %v4844 = load i64, ptr %slot14, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  store i32 0, ptr %p4845, align 4, !alias.scope !3, !noalias !4
  %v4846 = load i64, ptr %slot21, align 8
  store i64 %v4846, ptr %slot884, align 8
  %v4847 = load i64, ptr %slot15, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  %ld4849 = load i32, ptr %p4848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4849, ptr %slot885, align 8
  %v4850 = load i32, ptr %slot885, align 8
  %op4851 = and i32 %v4850, 28
  store i32 %op4851, ptr %slot886, align 8
  %v4852 = load i32, ptr %slot886, align 8
  %cv4853 = zext i32 %v4852 to i64
  %cond4854 = icmp ne i64 %cv4853, 0
  br i1 %cond4854, label %bb_rcslotrole1407, label %bb_rcslotowner1407
bb_rcslotrole1407:
  %v4855 = load i64, ptr %slot53, align 8
  store i64 %v4855, ptr %slot887, align 8
  %v4856 = load i64, ptr %slot887, align 8
  %v4857 = load i64, ptr %slot884, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v4856, i64 %v4857) nomerge, !dbg !196
  br label %bb_rcslotdone1407
bb_rcslotowner1407:
  %v4858 = load i64, ptr %slot53, align 8
  store i64 %v4858, ptr %slot888, align 8
  %v4859 = load i64, ptr %slot888, align 8
  %v4860 = load i64, ptr %slot884, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v4859, i64 %v4860) nomerge, !dbg !196
  br label %bb_rcslotdone1407
bb_rcslotdone1407:
  br label %bb_rcprepared1366
bb_rcprepared1366:
  %v4861 = load i64, ptr %slot25, align 8
  store i64 %v4861, ptr %slot889, align 8
  %v4862 = load i64, ptr %slot889, align 8
  %v4863 = load i64, ptr %slot853, align 8
  %p4864 = inttoptr i64 %v4862 to ptr
  %p4865 = inttoptr i64 %v4863 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4865, ptr %p4864, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4866 = load i64, ptr %slot18, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  store i32 0, ptr %p4867, align 4, !alias.scope !3, !noalias !4
  %v4868 = load i64, ptr %slot849, align 8
  %v4869 = load i64, ptr %slot36, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  store i64 %v4868, ptr %p4870, align 8, !alias.scope !3, !noalias !4
  %p4871 = inttoptr i64 ptrtoint (ptr @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p4871, i64 128) "call-inline-cost"="0", !dbg !196
  %v4872 = load i64, ptr %slot36, align 8
  %p4873 = inttoptr i64 %v4872 to ptr
  %ld4874 = load i64, ptr %p4873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4874, ptr %slot890, align 8
  %v4875 = load i64, ptr %slot21, align 8
  store i64 %v4875, ptr %slot891, align 8
  %v4876 = load i64, ptr %slot890, align 8
  %v4877 = load i64, ptr %slot891, align 8
  %p4878 = inttoptr i64 %v4876 to ptr
  %p4879 = inttoptr i64 %v4877 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4879, ptr %p4878, i64 24, i1 false)
  %v4880 = load i64, ptr %slot15, align 8
  %p4881 = inttoptr i64 %v4880 to ptr
  store i32 2, ptr %p4881, align 4, !alias.scope !3, !noalias !4
  %v4882 = load i64, ptr %slot14, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  store i32 1, ptr %p4883, align 4, !alias.scope !3, !noalias !4
  %v4884 = load i64, ptr %slot891, align 8
  %v4885 = load i64, ptr %slot36, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  store i64 %v4884, ptr %p4886, align 8, !alias.scope !3, !noalias !4
  %v4887 = load i64, ptr %slot36, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %ld4889 = load i64, ptr %p4888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4889, ptr %slot892, align 8
  %v4890 = load i64, ptr %slot36, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  %ld4892 = load i64, ptr %p4891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4892, ptr %slot893, align 8
  %v4893 = load i64, ptr %slot25, align 8
  store i64 %v4893, ptr %slot894, align 8
  %v4894 = load i64, ptr %slot54, align 8
  store i64 %v4894, ptr %slot895, align 8
  %v4895 = load i64, ptr %slot53, align 8
  %v4896 = load i64, ptr %slot894, align 8
  %v4897 = load i64, ptr %slot893, align 8
  %v4898 = load i64, ptr %slot895, align 8
  %cv4899 = trunc i64 %v4898 to i32
  %call4900 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4895, i64 %v4896, i64 %v4897, i32 %cv4899) nomerge, !dbg !198
  store i32 %call4900, ptr %slot896, align 8
  %v4901 = load i32, ptr %slot896, align 8
  %cv4902 = zext i32 %v4901 to i64
  %cond4903 = icmp ne i64 %cv4902, 0
  br i1 %cond4903, label %bb_rcsuccess1425, label %bb_rcfailure1425
bb_rcfailure1425:
  %v4904 = load i64, ptr %slot53, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  %call4906 = call i32 @myl_rc_take_failure(ptr %p4905) nomerge, !dbg !198
  store i32 %call4906, ptr %slot897, align 8
  %v4907 = load i64, ptr %slot1, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  %v4909 = load i32, ptr %slot897, align 8
  %call4910 = call i32 @myl_qbe_rc_status(ptr %p4908, i32 %v4909) nomerge, !dbg !198
  store i32 %call4910, ptr %slot898, align 8
  br label %bb_failure
bb_rcsuccess1425:
  %v4911 = load i64, ptr %slot14, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  store i32 0, ptr %p4912, align 4, !alias.scope !3, !noalias !4
  %v4913 = load i64, ptr %slot19, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  store i32 2, ptr %p4914, align 4, !alias.scope !3, !noalias !4
  %v4915 = load i64, ptr %slot18, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  store i32 1, ptr %p4916, align 4, !alias.scope !3, !noalias !4
  %v4917 = load i64, ptr %slot25, align 8
  store i64 %v4917, ptr %slot899, align 8
  %v4918 = load i64, ptr %slot18, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  store i32 0, ptr %p4919, align 4, !alias.scope !3, !noalias !4
  %v4920 = load i64, ptr %slot14, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  %ld4922 = load i32, ptr %p4921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4922, ptr %slot900, align 8
  %v4923 = load i32, ptr %slot900, align 8
  %cv4924 = zext i32 %v4923 to i64
  %cond4925 = icmp ne i64 %cv4924, 0
  br i1 %cond4925, label %bb_rcslotdrop1435, label %bb_rcslotdone1435
bb_rcslotdrop1435:
  %v4926 = load i64, ptr %slot14, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  store i32 0, ptr %p4927, align 4, !alias.scope !3, !noalias !4
  %v4928 = load i64, ptr %slot21, align 8
  store i64 %v4928, ptr %slot901, align 8
  %v4929 = load i64, ptr %slot15, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  %ld4931 = load i32, ptr %p4930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4931, ptr %slot902, align 8
  %v4932 = load i32, ptr %slot902, align 8
  %op4933 = and i32 %v4932, 28
  store i32 %op4933, ptr %slot903, align 8
  %v4934 = load i32, ptr %slot903, align 8
  %cv4935 = zext i32 %v4934 to i64
  %cond4936 = icmp ne i64 %cv4935, 0
  br i1 %cond4936, label %bb_rcslotrole1435, label %bb_rcslotowner1435
bb_rcslotrole1435:
  %v4937 = load i64, ptr %slot53, align 8
  store i64 %v4937, ptr %slot904, align 8
  %v4938 = load i64, ptr %slot904, align 8
  %v4939 = load i64, ptr %slot901, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4938, i64 %v4939) nomerge, !dbg !198
  br label %bb_rcslotdone1435
bb_rcslotowner1435:
  %v4940 = load i64, ptr %slot53, align 8
  store i64 %v4940, ptr %slot905, align 8
  %v4941 = load i64, ptr %slot905, align 8
  %v4942 = load i64, ptr %slot901, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4941, i64 %v4942) nomerge, !dbg !198
  br label %bb_rcslotdone1435
bb_rcslotdone1435:
  %v4943 = load i64, ptr %slot12, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  %ld4945 = load i32, ptr %p4944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4945, ptr %slot906, align 8
  %v4946 = load i32, ptr %slot906, align 8
  %cv4947 = zext i32 %v4946 to i64
  %cond4948 = icmp ne i64 %cv4947, 0
  br i1 %cond4948, label %bb_rcslotdrop1462, label %bb_rcslotdone1462
bb_rcslotdrop1462:
  %v4949 = load i64, ptr %slot12, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  store i32 0, ptr %p4950, align 4, !alias.scope !3, !noalias !4
  %v4951 = load i64, ptr %slot35, align 8
  store i64 %v4951, ptr %slot907, align 8
  %v4952 = load i64, ptr %slot13, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i32, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4954, ptr %slot908, align 8
  %v4955 = load i32, ptr %slot908, align 8
  %op4956 = and i32 %v4955, 28
  store i32 %op4956, ptr %slot909, align 8
  %v4957 = load i32, ptr %slot909, align 8
  %cv4958 = zext i32 %v4957 to i64
  %cond4959 = icmp ne i64 %cv4958, 0
  br i1 %cond4959, label %bb_rcslotrole1462, label %bb_rcslotowner1462
bb_rcslotrole1462:
  %v4960 = load i64, ptr %slot53, align 8
  store i64 %v4960, ptr %slot910, align 8
  %v4961 = load i64, ptr %slot910, align 8
  %v4962 = load i64, ptr %slot907, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4961, i64 %v4962) nomerge, !dbg !198
  br label %bb_rcslotdone1462
bb_rcslotowner1462:
  %v4963 = load i64, ptr %slot53, align 8
  store i64 %v4963, ptr %slot911, align 8
  %v4964 = load i64, ptr %slot911, align 8
  %v4965 = load i64, ptr %slot907, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4964, i64 %v4965) nomerge, !dbg !198
  br label %bb_rcslotdone1462
bb_rcslotdone1462:
  %v4966 = load i64, ptr %slot10, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  %ld4968 = load i32, ptr %p4967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4968, ptr %slot912, align 8
  %v4969 = load i32, ptr %slot912, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rcslotdrop1489, label %bb_rcslotdone1489
bb_rcslotdrop1489:
  %v4972 = load i64, ptr %slot10, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  store i32 0, ptr %p4973, align 4, !alias.scope !3, !noalias !4
  %v4974 = load i64, ptr %slot33, align 8
  store i64 %v4974, ptr %slot913, align 8
  %v4975 = load i64, ptr %slot11, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %ld4977 = load i32, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4977, ptr %slot914, align 8
  %v4978 = load i32, ptr %slot914, align 8
  %op4979 = and i32 %v4978, 28
  store i32 %op4979, ptr %slot915, align 8
  %v4980 = load i32, ptr %slot915, align 8
  %cv4981 = zext i32 %v4980 to i64
  %cond4982 = icmp ne i64 %cv4981, 0
  br i1 %cond4982, label %bb_rcslotrole1489, label %bb_rcslotowner1489
bb_rcslotrole1489:
  %v4983 = load i64, ptr %slot53, align 8
  store i64 %v4983, ptr %slot916, align 8
  %v4984 = load i64, ptr %slot916, align 8
  %v4985 = load i64, ptr %slot913, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4984, i64 %v4985) nomerge, !dbg !198
  br label %bb_rcslotdone1489
bb_rcslotowner1489:
  %v4986 = load i64, ptr %slot53, align 8
  store i64 %v4986, ptr %slot917, align 8
  %v4987 = load i64, ptr %slot917, align 8
  %v4988 = load i64, ptr %slot913, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4987, i64 %v4988) nomerge, !dbg !198
  br label %bb_rcslotdone1489
bb_rcslotdone1489:
  %v4989 = load i64, ptr %slot8, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %ld4991 = load i32, ptr %p4990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4991, ptr %slot918, align 8
  %v4992 = load i32, ptr %slot918, align 8
  %cv4993 = zext i32 %v4992 to i64
  %cond4994 = icmp ne i64 %cv4993, 0
  br i1 %cond4994, label %bb_rcslotdrop1516, label %bb_rcslotdone1516
bb_rcslotdrop1516:
  %v4995 = load i64, ptr %slot8, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  store i32 0, ptr %p4996, align 4, !alias.scope !3, !noalias !4
  %v4997 = load i64, ptr %slot31, align 8
  store i64 %v4997, ptr %slot919, align 8
  %v4998 = load i64, ptr %slot9, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  %ld5000 = load i32, ptr %p4999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5000, ptr %slot920, align 8
  %v5001 = load i32, ptr %slot920, align 8
  %op5002 = and i32 %v5001, 28
  store i32 %op5002, ptr %slot921, align 8
  %v5003 = load i32, ptr %slot921, align 8
  %cv5004 = zext i32 %v5003 to i64
  %cond5005 = icmp ne i64 %cv5004, 0
  br i1 %cond5005, label %bb_rcslotrole1516, label %bb_rcslotowner1516
bb_rcslotrole1516:
  %v5006 = load i64, ptr %slot53, align 8
  store i64 %v5006, ptr %slot922, align 8
  %v5007 = load i64, ptr %slot922, align 8
  %v5008 = load i64, ptr %slot919, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5007, i64 %v5008) nomerge, !dbg !198
  br label %bb_rcslotdone1516
bb_rcslotowner1516:
  %v5009 = load i64, ptr %slot53, align 8
  store i64 %v5009, ptr %slot923, align 8
  %v5010 = load i64, ptr %slot923, align 8
  %v5011 = load i64, ptr %slot919, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5010, i64 %v5011) nomerge, !dbg !198
  br label %bb_rcslotdone1516
bb_rcslotdone1516:
  %v5012 = load i64, ptr %slot6, align 8
  %p5013 = inttoptr i64 %v5012 to ptr
  %ld5014 = load i32, ptr %p5013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5014, ptr %slot924, align 8
  %v5015 = load i32, ptr %slot924, align 8
  %cv5016 = zext i32 %v5015 to i64
  %cond5017 = icmp ne i64 %cv5016, 0
  br i1 %cond5017, label %bb_rcslotdrop1525, label %bb_rcslotdone1525
bb_rcslotdrop1525:
  %v5018 = load i64, ptr %slot6, align 8
  %p5019 = inttoptr i64 %v5018 to ptr
  store i32 0, ptr %p5019, align 4, !alias.scope !3, !noalias !4
  %v5020 = load i64, ptr %slot28, align 8
  store i64 %v5020, ptr %slot925, align 8
  %v5021 = load i64, ptr %slot7, align 8
  %p5022 = inttoptr i64 %v5021 to ptr
  %ld5023 = load i32, ptr %p5022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5023, ptr %slot926, align 8
  %v5024 = load i32, ptr %slot926, align 8
  %op5025 = and i32 %v5024, 28
  store i32 %op5025, ptr %slot927, align 8
  %v5026 = load i32, ptr %slot927, align 8
  %cv5027 = zext i32 %v5026 to i64
  %cond5028 = icmp ne i64 %cv5027, 0
  br i1 %cond5028, label %bb_rcslotrole1525, label %bb_rcslotowner1525
bb_rcslotrole1525:
  %v5029 = load i64, ptr %slot53, align 8
  store i64 %v5029, ptr %slot928, align 8
  %v5030 = load i64, ptr %slot928, align 8
  %v5031 = load i64, ptr %slot925, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5030, i64 %v5031) nomerge, !dbg !198
  br label %bb_rcslotdone1525
bb_rcslotowner1525:
  %v5032 = load i64, ptr %slot53, align 8
  store i64 %v5032, ptr %slot929, align 8
  %v5033 = load i64, ptr %slot929, align 8
  %v5034 = load i64, ptr %slot925, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v5033, i64 %v5034) nomerge, !dbg !198
  br label %bb_rcslotdone1525
bb_rcslotdone1525:
  %v5035 = load i64, ptr %slot899, align 8
  %p5036 = inttoptr i64 %v5035 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5036, i64 24, i1 false)
  ret void
bb_i130:
  %p5037 = inttoptr i64 ptrtoint (ptr @myl_lit_9ca860660ece73adde8e9de88ebf49903ccf758f133fa9c13722550c82522529 to i64) to ptr
  %ld5038 = load i64, ptr %p5037, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5038, ptr %slot930, align 8
  %v5039 = load i64, ptr %slot930, align 8
  %v5040 = load i64, ptr %slot36, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  store i64 %v5039, ptr %p5041, align 8, !alias.scope !3, !noalias !4
  %v5042 = load i64, ptr %slot36, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %ld5044 = load i64, ptr %p5043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5044, ptr %slot931, align 8
  %v5045 = load i64, ptr %slot931, align 8
  %v5046 = load i64, ptr %slot23, align 8
  %p5047 = inttoptr i64 %v5046 to ptr
  store i64 %v5045, ptr %p5047, align 8, !alias.scope !3, !noalias !4
  %v5048 = load i64, ptr %slot23, align 8
  store i64 %v5048, ptr %slot932, align 8
  %v5049 = load i64, ptr %slot25, align 8
  store i64 %v5049, ptr %slot933, align 8
  %v5050 = load i64, ptr %slot932, align 8
  %v5051 = load i64, ptr %slot933, align 8
  %p5052 = inttoptr i64 %v5050 to ptr
  %p5053 = inttoptr i64 %v5051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5053, ptr %p5052, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5054 = load i64, ptr %slot19, align 8
  %p5055 = inttoptr i64 %v5054 to ptr
  store i32 2, ptr %p5055, align 4, !alias.scope !3, !noalias !4
  %v5056 = load i64, ptr %slot18, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  store i32 1, ptr %p5057, align 4, !alias.scope !3, !noalias !4
  %v5058 = load i64, ptr %slot21, align 8
  store i64 %v5058, ptr %slot934, align 8
  %v5059 = load i64, ptr %slot25, align 8
  store i64 %v5059, ptr %slot935, align 8
  %v5060 = load i64, ptr %slot935, align 8
  %v5061 = load i64, ptr %slot934, align 8
  %p5062 = inttoptr i64 %v5060 to ptr
  %p5063 = inttoptr i64 %v5061 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5063, ptr %p5062, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5064 = load i64, ptr %slot15, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  store i32 2, ptr %p5065, align 4, !alias.scope !3, !noalias !4
  %v5066 = load i64, ptr %slot19, align 8
  %p5067 = inttoptr i64 %v5066 to ptr
  %ld5068 = load i32, ptr %p5067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5068, ptr %slot936, align 8
  %v5069 = load i32, ptr %slot936, align 8
  %v5070 = load i64, ptr %slot15, align 8
  %p5071 = inttoptr i64 %v5070 to ptr
  store i32 %v5069, ptr %p5071, align 4, !alias.scope !3, !noalias !4
  %v5072 = load i64, ptr %slot18, align 8
  %p5073 = inttoptr i64 %v5072 to ptr
  store i32 0, ptr %p5073, align 4, !alias.scope !3, !noalias !4
  %v5074 = load i64, ptr %slot14, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  store i32 1, ptr %p5075, align 4, !alias.scope !3, !noalias !4
  %v5076 = load i64, ptr %slot934, align 8
  %p5077 = inttoptr i64 %v5076 to ptr
  %ld5078 = load i64, ptr %p5077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5078, ptr %slot937, align 8
  %v5079 = load i64, ptr %slot937, align 8
  %v5080 = load i64, ptr %slot36, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  store i64 %v5079, ptr %p5081, align 8, !alias.scope !3, !noalias !4
  %v5082 = load i64, ptr %slot27, align 8
  %p5083 = inttoptr i64 %v5082 to ptr
  %ld5084 = load i64, ptr %p5083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5084, ptr %slot938, align 8
  %v5085 = load i64, ptr %slot938, align 8
  %v5086 = load i64, ptr %slot37, align 8
  %p5087 = inttoptr i64 %v5086 to ptr
  store i64 %v5085, ptr %p5087, align 8, !alias.scope !3, !noalias !4
  %v5088 = load i64, ptr %slot37, align 8
  %p5089 = inttoptr i64 %v5088 to ptr
  %ld5090 = load i64, ptr %p5089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5090, ptr %slot939, align 8
  %v5091 = load i64, ptr %slot939, align 8
  %op5092 = add i64 %v5091, 8
  store i64 %op5092, ptr %slot940, align 8
  %v5093 = load i64, ptr %slot940, align 8
  %v5094 = load i64, ptr %slot37, align 8
  %p5095 = inttoptr i64 %v5094 to ptr
  store i64 %v5093, ptr %p5095, align 8, !alias.scope !3, !noalias !4
  %v5096 = load i64, ptr %slot16, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %ld5098 = load i32, ptr %p5097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5098, ptr %slot941, align 8
  %v5099 = load i32, ptr %slot941, align 8
  %cv5100 = zext i32 %v5099 to i64
  %cond5101 = icmp ne i64 %cv5100, 0
  br i1 %cond5101, label %bb_rcslotdrop1571, label %bb_rcslotdone1571
bb_rcslotdrop1571:
  %v5102 = load i64, ptr %slot16, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  store i32 0, ptr %p5103, align 4, !alias.scope !3, !noalias !4
  %v5104 = load i64, ptr %slot22, align 8
  store i64 %v5104, ptr %slot942, align 8
  %v5105 = load i64, ptr %slot17, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %ld5107 = load i32, ptr %p5106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5107, ptr %slot943, align 8
  %v5108 = load i32, ptr %slot943, align 8
  %op5109 = and i32 %v5108, 28
  store i32 %op5109, ptr %slot944, align 8
  %v5110 = load i32, ptr %slot944, align 8
  %cv5111 = zext i32 %v5110 to i64
  %cond5112 = icmp ne i64 %cv5111, 0
  br i1 %cond5112, label %bb_rcslotrole1571, label %bb_rcslotowner1571
bb_rcslotrole1571:
  %v5113 = load i64, ptr %slot53, align 8
  store i64 %v5113, ptr %slot945, align 8
  %v5114 = load i64, ptr %slot945, align 8
  %v5115 = load i64, ptr %slot942, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v5114, i64 %v5115) nomerge, !dbg !200
  br label %bb_rcslotdone1571
bb_rcslotowner1571:
  %v5116 = load i64, ptr %slot53, align 8
  store i64 %v5116, ptr %slot946, align 8
  %v5117 = load i64, ptr %slot946, align 8
  %v5118 = load i64, ptr %slot942, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v5117, i64 %v5118) nomerge, !dbg !200
  br label %bb_rcslotdone1571
bb_rcslotdone1571:
  %v5119 = load i64, ptr %slot37, align 8
  %p5120 = inttoptr i64 %v5119 to ptr
  %ld5121 = load i64, ptr %p5120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5121, ptr %slot947, align 8
  %v5122 = load i64, ptr %slot947, align 8
  %op5123 = add i64 %v5122, 24
  store i64 %op5123, ptr %slot948, align 8
  %v5124 = load i64, ptr %slot948, align 8
  %p5125 = inttoptr i64 %v5124 to ptr
  %ld5126 = load i64, ptr %p5125, align 8
  store i64 %ld5126, ptr %slot949, align 8
  %v5127 = load i64, ptr %slot949, align 8
  %v5128 = load i64, ptr %slot37, align 8
  %p5129 = inttoptr i64 %v5128 to ptr
  store i64 %v5127, ptr %p5129, align 8, !alias.scope !3, !noalias !4
  %v5130 = load i64, ptr %slot16, align 8
  %p5131 = inttoptr i64 %v5130 to ptr
  %ld5132 = load i32, ptr %p5131, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5132, ptr %slot950, align 8
  %v5133 = load i32, ptr %slot950, align 8
  %cv5134 = zext i32 %v5133 to i64
  %cond5135 = icmp ne i64 %cv5134, 0
  br i1 %cond5135, label %bb_rcslotdrop1583, label %bb_rcslotdone1583
bb_rcslotdrop1583:
  %v5136 = load i64, ptr %slot16, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  store i32 0, ptr %p5137, align 4, !alias.scope !3, !noalias !4
  %v5138 = load i64, ptr %slot22, align 8
  store i64 %v5138, ptr %slot951, align 8
  %v5139 = load i64, ptr %slot17, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  %ld5141 = load i32, ptr %p5140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5141, ptr %slot952, align 8
  %v5142 = load i32, ptr %slot952, align 8
  %op5143 = and i32 %v5142, 28
  store i32 %op5143, ptr %slot953, align 8
  %v5144 = load i32, ptr %slot953, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcslotrole1583, label %bb_rcslotowner1583
bb_rcslotrole1583:
  %v5147 = load i64, ptr %slot53, align 8
  store i64 %v5147, ptr %slot954, align 8
  %v5148 = load i64, ptr %slot954, align 8
  %v5149 = load i64, ptr %slot951, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5148, i64 %v5149) nomerge, !dbg !202
  br label %bb_rcslotdone1583
bb_rcslotowner1583:
  %v5150 = load i64, ptr %slot53, align 8
  store i64 %v5150, ptr %slot955, align 8
  %v5151 = load i64, ptr %slot955, align 8
  %v5152 = load i64, ptr %slot951, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5151, i64 %v5152) nomerge, !dbg !202
  br label %bb_rcslotdone1583
bb_rcslotdone1583:
  %v5153 = load i64, ptr %slot36, align 8
  %p5154 = inttoptr i64 %v5153 to ptr
  %ld5155 = load i64, ptr %p5154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5155, ptr %slot956, align 8
  %v5156 = load i64, ptr %slot37, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %ld5158 = load i64, ptr %p5157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5158, ptr %slot957, align 8
  %v5159 = load i64, ptr %slot1, align 8
  %v5160 = load i64, ptr %slot956, align 8
  %v5161 = load i64, ptr %slot957, align 8
  %call5162 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v5159, i64 %v5160, i64 %v5161) nomerge, !dbg !204
  store { i64, i64 } %call5162, ptr %callresult959, align 8
  %addr5163 = ptrtoint ptr %callresult959 to i64
  store i64 %addr5163, ptr %slot958, align 8
  %v5164 = load i64, ptr %slot958, align 8
  %v5165 = load i64, ptr %slot36, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  store i64 %v5164, ptr %p5166, align 8, !alias.scope !3, !noalias !4
  %v5167 = load i64, ptr %slot36, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  %ld5169 = load i64, ptr %p5168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5169, ptr %slot960, align 8
  %v5170 = load i64, ptr %slot25, align 8
  store i64 %v5170, ptr %slot961, align 8
  %v5171 = load i64, ptr %slot53, align 8
  %v5172 = load i64, ptr %slot961, align 8
  %v5173 = load i64, ptr %slot960, align 8
  %call5174 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v5171, i64 %v5172, i64 %v5173) nomerge, !dbg !204
  store i32 %call5174, ptr %slot962, align 8
  %v5175 = load i32, ptr %slot962, align 8
  %cv5176 = zext i32 %v5175 to i64
  %cond5177 = icmp ne i64 %cv5176, 0
  br i1 %cond5177, label %bb_rcsuccess1596, label %bb_rcfailure1596
bb_rcfailure1596:
  %v5178 = load i64, ptr %slot53, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  %call5180 = call i32 @myl_rc_take_failure(ptr %p5179) nomerge, !dbg !204
  store i32 %call5180, ptr %slot963, align 8
  %v5181 = load i64, ptr %slot1, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  %v5183 = load i32, ptr %slot963, align 8
  %call5184 = call i32 @myl_qbe_rc_status(ptr %p5182, i32 %v5183) nomerge, !dbg !204
  store i32 %call5184, ptr %slot964, align 8
  br label %bb_failure
bb_rcsuccess1596:
  %v5185 = load i64, ptr %slot19, align 8
  %p5186 = inttoptr i64 %v5185 to ptr
  store i32 2, ptr %p5186, align 4, !alias.scope !3, !noalias !4
  %v5187 = load i64, ptr %slot19, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  store i32 16, ptr %p5188, align 4, !alias.scope !3, !noalias !4
  %v5189 = load i64, ptr %slot18, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  store i32 1, ptr %p5190, align 4, !alias.scope !3, !noalias !4
  %v5191 = load i64, ptr %slot14, align 8
  %p5192 = inttoptr i64 %v5191 to ptr
  %ld5193 = load i32, ptr %p5192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5193, ptr %slot965, align 8
  %v5194 = load i32, ptr %slot965, align 8
  %cv5195 = zext i32 %v5194 to i64
  %cond5196 = icmp ne i64 %cv5195, 0
  br i1 %cond5196, label %bb_rcslotdrop1604, label %bb_rcslotdone1604
bb_rcslotdrop1604:
  %v5197 = load i64, ptr %slot14, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  store i32 0, ptr %p5198, align 4, !alias.scope !3, !noalias !4
  %v5199 = load i64, ptr %slot21, align 8
  store i64 %v5199, ptr %slot966, align 8
  %v5200 = load i64, ptr %slot15, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  %ld5202 = load i32, ptr %p5201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5202, ptr %slot967, align 8
  %v5203 = load i32, ptr %slot967, align 8
  %op5204 = and i32 %v5203, 28
  store i32 %op5204, ptr %slot968, align 8
  %v5205 = load i32, ptr %slot968, align 8
  %cv5206 = zext i32 %v5205 to i64
  %cond5207 = icmp ne i64 %cv5206, 0
  br i1 %cond5207, label %bb_rcslotrole1604, label %bb_rcslotowner1604
bb_rcslotrole1604:
  %v5208 = load i64, ptr %slot53, align 8
  store i64 %v5208, ptr %slot969, align 8
  %v5209 = load i64, ptr %slot966, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  %ld5211 = load i64, ptr %p5210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5211, ptr %slot970, align 8
  %v5212 = load i64, ptr %slot970, align 8
  %cmp5213 = icmp ne i64 %v5212, 0
  %cv5214 = zext i1 %cmp5213 to i32
  store i32 %cv5214, ptr %slot971, align 8
  %v5215 = load i32, ptr %slot971, align 8
  %cv5216 = zext i32 %v5215 to i64
  %cond5217 = icmp ne i64 %cv5216, 0
  br i1 %cond5217, label %bb_rcgnn1620, label %bb_rcgdone1620
bb_rcgnn1620:
  %v5218 = load i64, ptr %slot970, align 8
  %op5219 = sub i64 %v5218, 16
  store i64 %op5219, ptr %slot972, align 8
  %v5220 = load i64, ptr %slot970, align 8
  %p5221 = inttoptr i64 %v5220 to ptr
  %rgep5222 = getelementptr i8, ptr %p5221, i64 -16
  %ld5223 = load i64, ptr %rgep5222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5223, ptr %slot973, align 8
  %v5224 = load i64, ptr %slot973, align 8
  %op5225 = and i64 %v5224, 4611686018427387906
  store i64 %op5225, ptr %slot974, align 8
  %v5226 = load i64, ptr %slot974, align 8
  %cmp5227 = icmp ne i64 %v5226, 0
  %cv5228 = zext i1 %cmp5227 to i32
  store i32 %cv5228, ptr %slot975, align 8
  %v5229 = load i32, ptr %slot975, align 8
  %cv5230 = zext i32 %v5229 to i64
  %cond5231 = icmp ne i64 %cv5230, 0
  br i1 %cond5231, label %bb_rcgclear1620, label %bb_rcgcounted1620
bb_rcgcounted1620:
  %v5232 = load i64, ptr %slot970, align 8
  %op5233 = sub i64 %v5232, 24
  store i64 %op5233, ptr %slot976, align 8
  %v5234 = load i64, ptr %slot970, align 8
  %p5235 = inttoptr i64 %v5234 to ptr
  %rgep5236 = getelementptr i8, ptr %p5235, i64 -24
  %ld5237 = load i64, ptr %rgep5236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5237, ptr %slot977, align 8
  %v5238 = load i64, ptr %slot977, align 8
  %op5239 = sub i64 %v5238, 1
  store i64 %op5239, ptr %slot978, align 8
  %v5240 = load i64, ptr %slot978, align 8
  %cmp5241 = icmp eq i64 %v5240, 0
  %cv5242 = zext i1 %cmp5241 to i32
  store i32 %cv5242, ptr %slot979, align 8
  %v5243 = load i32, ptr %slot979, align 8
  %cv5244 = zext i32 %v5243 to i64
  %cond5245 = icmp ne i64 %cv5244, 0
  br i1 %cond5245, label %bb_rcglast1620, label %bb_rcgdec1620
bb_rcglast1620:
  %v5246 = load i64, ptr %slot970, align 8
  %op5247 = sub i64 %v5246, 32
  store i64 %op5247, ptr %slot980, align 8
  %v5248 = load i64, ptr %slot970, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  %rgep5250 = getelementptr i8, ptr %p5249, i64 -32
  %ld5251 = load i64, ptr %rgep5250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5251, ptr %slot981, align 8
  %v5252 = load i64, ptr %slot981, align 8
  %cmp5253 = icmp ne i64 %v5252, 0
  %cv5254 = zext i1 %cmp5253 to i32
  store i32 %cv5254, ptr %slot982, align 8
  %v5255 = load i32, ptr %slot982, align 8
  %cv5256 = zext i32 %v5255 to i64
  %cond5257 = icmp ne i64 %cv5256, 0
  br i1 %cond5257, label %bb_rcgdec1620, label %bb_rcgslow1620
bb_rcgslow1620:
  %v5258 = load i64, ptr %slot969, align 8
  %v5259 = load i64, ptr %slot966, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5258, i64 %v5259) nomerge, !dbg !204
  br label %bb_rcgdone1620
bb_rcgdec1620:
  %v5260 = load i64, ptr %slot978, align 8
  %v5261 = load i64, ptr %slot970, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %rgep5263 = getelementptr i8, ptr %p5262, i64 -24
  store i64 %v5260, ptr %rgep5263, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1620
bb_rcgclear1620:
  %v5264 = load i64, ptr %slot966, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  store i64 0, ptr %p5265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1620
bb_rcgdone1620:
  br label %bb_rcslotdone1604
bb_rcslotowner1604:
  %v5266 = load i64, ptr %slot53, align 8
  store i64 %v5266, ptr %slot983, align 8
  %v5267 = load i64, ptr %slot966, align 8
  %p5268 = inttoptr i64 %v5267 to ptr
  %ld5269 = load i64, ptr %p5268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5269, ptr %slot984, align 8
  %v5270 = load i64, ptr %slot984, align 8
  %cmp5271 = icmp ne i64 %v5270, 0
  %cv5272 = zext i1 %cmp5271 to i32
  store i32 %cv5272, ptr %slot985, align 8
  %v5273 = load i32, ptr %slot985, align 8
  %cv5274 = zext i32 %v5273 to i64
  %cond5275 = icmp ne i64 %cv5274, 0
  br i1 %cond5275, label %bb_rcgnn1635, label %bb_rcgdone1635
bb_rcgnn1635:
  %v5276 = load i64, ptr %slot984, align 8
  %op5277 = sub i64 %v5276, 16
  store i64 %op5277, ptr %slot986, align 8
  %v5278 = load i64, ptr %slot984, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %rgep5280 = getelementptr i8, ptr %p5279, i64 -16
  %ld5281 = load i64, ptr %rgep5280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5281, ptr %slot987, align 8
  %v5282 = load i64, ptr %slot987, align 8
  %op5283 = and i64 %v5282, 4611686018427387906
  store i64 %op5283, ptr %slot988, align 8
  %v5284 = load i64, ptr %slot988, align 8
  %cmp5285 = icmp ne i64 %v5284, 0
  %cv5286 = zext i1 %cmp5285 to i32
  store i32 %cv5286, ptr %slot989, align 8
  %v5287 = load i32, ptr %slot989, align 8
  %cv5288 = zext i32 %v5287 to i64
  %cond5289 = icmp ne i64 %cv5288, 0
  br i1 %cond5289, label %bb_rcgclear1635, label %bb_rcgcounted1635
bb_rcgcounted1635:
  %v5290 = load i64, ptr %slot984, align 8
  %op5291 = sub i64 %v5290, 32
  store i64 %op5291, ptr %slot990, align 8
  %v5292 = load i64, ptr %slot984, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %rgep5294 = getelementptr i8, ptr %p5293, i64 -32
  %ld5295 = load i64, ptr %rgep5294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5295, ptr %slot991, align 8
  %v5296 = load i64, ptr %slot991, align 8
  %op5297 = sub i64 %v5296, 1
  store i64 %op5297, ptr %slot992, align 8
  %v5298 = load i64, ptr %slot992, align 8
  %cmp5299 = icmp eq i64 %v5298, 0
  %cv5300 = zext i1 %cmp5299 to i32
  store i32 %cv5300, ptr %slot993, align 8
  %v5301 = load i32, ptr %slot993, align 8
  %cv5302 = zext i32 %v5301 to i64
  %cond5303 = icmp ne i64 %cv5302, 0
  br i1 %cond5303, label %bb_rcglast1635, label %bb_rcgdec1635
bb_rcglast1635:
  %v5304 = load i64, ptr %slot984, align 8
  %op5305 = sub i64 %v5304, 24
  store i64 %op5305, ptr %slot994, align 8
  %v5306 = load i64, ptr %slot984, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  %rgep5308 = getelementptr i8, ptr %p5307, i64 -24
  %ld5309 = load i64, ptr %rgep5308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5309, ptr %slot995, align 8
  %v5310 = load i64, ptr %slot995, align 8
  %cmp5311 = icmp ne i64 %v5310, 0
  %cv5312 = zext i1 %cmp5311 to i32
  store i32 %cv5312, ptr %slot996, align 8
  %v5313 = load i32, ptr %slot996, align 8
  %cv5314 = zext i32 %v5313 to i64
  %cond5315 = icmp ne i64 %cv5314, 0
  br i1 %cond5315, label %bb_rcgdec1635, label %bb_rcgslow1635
bb_rcgslow1635:
  %v5316 = load i64, ptr %slot983, align 8
  %v5317 = load i64, ptr %slot966, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5316, i64 %v5317) nomerge, !dbg !204
  br label %bb_rcgdone1635
bb_rcgdec1635:
  %v5318 = load i64, ptr %slot992, align 8
  %v5319 = load i64, ptr %slot984, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %rgep5321 = getelementptr i8, ptr %p5320, i64 -32
  store i64 %v5318, ptr %rgep5321, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1635
bb_rcgclear1635:
  %v5322 = load i64, ptr %slot966, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  store i64 0, ptr %p5323, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1635
bb_rcgdone1635:
  br label %bb_rcslotdone1604
bb_rcslotdone1604:
  %v5324 = load i64, ptr %slot21, align 8
  store i64 %v5324, ptr %slot997, align 8
  %v5325 = load i64, ptr %slot25, align 8
  store i64 %v5325, ptr %slot998, align 8
  %v5326 = load i64, ptr %slot998, align 8
  %v5327 = load i64, ptr %slot997, align 8
  %p5328 = inttoptr i64 %v5326 to ptr
  %p5329 = inttoptr i64 %v5327 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5329, ptr %p5328, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5330 = load i64, ptr %slot15, align 8
  %p5331 = inttoptr i64 %v5330 to ptr
  store i32 2, ptr %p5331, align 4, !alias.scope !3, !noalias !4
  %v5332 = load i64, ptr %slot19, align 8
  %p5333 = inttoptr i64 %v5332 to ptr
  %ld5334 = load i32, ptr %p5333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5334, ptr %slot999, align 8
  %v5335 = load i32, ptr %slot999, align 8
  %v5336 = load i64, ptr %slot15, align 8
  %p5337 = inttoptr i64 %v5336 to ptr
  store i32 %v5335, ptr %p5337, align 4, !alias.scope !3, !noalias !4
  %v5338 = load i64, ptr %slot18, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  store i32 0, ptr %p5339, align 4, !alias.scope !3, !noalias !4
  %v5340 = load i64, ptr %slot14, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  store i32 1, ptr %p5341, align 4, !alias.scope !3, !noalias !4
  %v5342 = load i64, ptr %slot997, align 8
  %v5343 = load i64, ptr %slot36, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  store i64 %v5342, ptr %p5344, align 8, !alias.scope !3, !noalias !4
  %v5345 = load i64, ptr %slot48, align 8
  store i64 %v5345, ptr %slot1000, align 8
  %v5346 = load i64, ptr %slot1000, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  store i64 0, ptr %p5347, align 8, !alias.scope !3, !noalias !4
  %v5348 = load i64, ptr %slot1000, align 8
  %p5350 = inttoptr i64 %v5348 to ptr
  %gep5351 = getelementptr i8, ptr %p5350, i64 8
  %op5349 = ptrtoint ptr %gep5351 to i64
  store i64 %op5349, ptr %slot1001, align 8
  %v5352 = load i64, ptr %slot1001, align 8
  %p5353 = inttoptr i64 %v5352 to ptr
  store i64 0, ptr %p5353, align 8, !alias.scope !3, !noalias !4
  %v5354 = load i64, ptr %slot1000, align 8
  %p5356 = inttoptr i64 %v5354 to ptr
  %gep5357 = getelementptr i8, ptr %p5356, i64 16
  %op5355 = ptrtoint ptr %gep5357 to i64
  store i64 %op5355, ptr %slot1002, align 8
  %v5358 = load i64, ptr %slot1002, align 8
  %p5359 = inttoptr i64 %v5358 to ptr
  store i64 0, ptr %p5359, align 8, !alias.scope !3, !noalias !4
  %v5360 = load i64, ptr %slot1000, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  store i32 1, ptr %p5361, align 4, !alias.scope !3, !noalias !4
  %v5362 = load i64, ptr %slot20, align 8
  %p5363 = inttoptr i64 %v5362 to ptr
  store i32 1, ptr %p5363, align 4, !alias.scope !3, !noalias !4
  %v5364 = load i64, ptr %slot36, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %ld5366 = load i64, ptr %p5365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5366, ptr %slot1003, align 8
  %v5367 = load i64, ptr %slot1000, align 8
  %p5369 = inttoptr i64 %v5367 to ptr
  %gep5370 = getelementptr i8, ptr %p5369, i64 8
  %op5368 = ptrtoint ptr %gep5370 to i64
  store i64 %op5368, ptr %slot1004, align 8
  %v5371 = load i64, ptr %slot54, align 8
  store i64 %v5371, ptr %slot1005, align 8
  %v5372 = load i64, ptr %slot36, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  %ld5374 = load i64, ptr %p5373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5374, ptr %slot1006, align 8
  %v5375 = load i64, ptr %slot14, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  %ld5377 = load i32, ptr %p5376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5377, ptr %slot1007, align 8
  %v5378 = load i64, ptr %slot15, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  %ld5380 = load i32, ptr %p5379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5380, ptr %slot1008, align 8
  %v5381 = load i32, ptr %slot1008, align 8
  %op5382 = and i32 %v5381, 24
  store i32 %op5382, ptr %slot1008, align 8
  %v5383 = load i32, ptr %slot1008, align 8
  %cmp5384 = icmp eq i32 %v5383, 0
  %cv5385 = zext i1 %cmp5384 to i32
  store i32 %cv5385, ptr %slot1009, align 8
  %v5386 = load i32, ptr %slot1007, align 8
  %v5387 = load i32, ptr %slot1009, align 8
  %op5388 = and i32 %v5386, %v5387
  store i32 %op5388, ptr %slot1010, align 8
  %v5389 = load i32, ptr %slot1010, align 8
  %cv5390 = zext i32 %v5389 to i64
  %cond5391 = icmp ne i64 %cv5390, 0
  br i1 %cond5391, label %bb_rctake1656, label %bb_rccopy1656
bb_rctake1656:
  %v5392 = load i64, ptr %slot25, align 8
  store i64 %v5392, ptr %slot1011, align 8
  %v5393 = load i64, ptr %slot54, align 8
  store i64 %v5393, ptr %slot1012, align 8
  %v5394 = load i64, ptr %slot1006, align 8
  %v5395 = load i64, ptr %slot1011, align 8
  %op5396 = sub i64 %v5394, %v5395
  store i64 %op5396, ptr %slot1013, align 8
  %v5397 = load i64, ptr %slot1011, align 8
  %v5398 = load i64, ptr %slot1006, align 8
  %op5399 = sub i64 %v5397, %v5398
  store i64 %op5399, ptr %slot1014, align 8
  %v5400 = load i64, ptr %slot1013, align 8
  %cmp5401 = icmp ult i64 %v5400, 16
  %cv5402 = zext i1 %cmp5401 to i32
  store i32 %cv5402, ptr %slot1015, align 8
  %v5403 = load i64, ptr %slot1014, align 8
  %cmp5404 = icmp ult i64 %v5403, 16
  %cv5405 = zext i1 %cmp5404 to i32
  store i32 %cv5405, ptr %slot1016, align 8
  %v5406 = load i32, ptr %slot1015, align 8
  %v5407 = load i32, ptr %slot1016, align 8
  %op5408 = or i32 %v5406, %v5407
  store i32 %op5408, ptr %slot1017, align 8
  %v5409 = load i32, ptr %slot1017, align 8
  %cv5410 = zext i32 %v5409 to i64
  %cond5411 = icmp ne i64 %cv5410, 0
  br i1 %cond5411, label %bb_rcmoveslow1665, label %bb_rcmovecheck1665
bb_rcmovecheck1665:
  %v5412 = load i64, ptr %slot1006, align 8
  %op5413 = add i64 %v5412, 0
  store i64 %op5413, ptr %slot1018, align 8
  %v5414 = load i64, ptr %slot1018, align 8
  %p5415 = inttoptr i64 %v5414 to ptr
  %ld5416 = load i64, ptr %p5415, align 8
  store i64 %ld5416, ptr %slot1019, align 8
  %v5417 = load i64, ptr %slot1019, align 8
  %cmp5418 = icmp ne i64 %v5417, 0
  %cv5419 = zext i1 %cmp5418 to i32
  store i32 %cv5419, ptr %slot1020, align 8
  %v5420 = load i32, ptr %slot1020, align 8
  %cv5421 = zext i32 %v5420 to i64
  %cond5422 = icmp ne i64 %cv5421, 0
  br i1 %cond5422, label %bb_rcmoveheader1673, label %bb_rcmovenext1673
bb_rcmoveheader1673:
  %v5423 = load i64, ptr %slot1019, align 8
  %op5424 = sub i64 %v5423, 16
  store i64 %op5424, ptr %slot1021, align 8
  %v5425 = load i64, ptr %slot1019, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  %rgep5427 = getelementptr i8, ptr %p5426, i64 -16
  %ld5428 = load i64, ptr %rgep5427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5428, ptr %slot1022, align 8
  %v5429 = load i64, ptr %slot1022, align 8
  %op5430 = and i64 %v5429, 5764607523034234881
  store i64 %op5430, ptr %slot1023, align 8
  %v5431 = load i64, ptr %slot1023, align 8
  %cmp5432 = icmp ne i64 %v5431, 0
  %cv5433 = zext i1 %cmp5432 to i32
  store i32 %cv5433, ptr %slot1024, align 8
  %v5434 = load i32, ptr %slot1024, align 8
  %cv5435 = zext i32 %v5434 to i64
  %cond5436 = icmp ne i64 %cv5435, 0
  br i1 %cond5436, label %bb_rcmoveslow1665, label %bb_rcmovenext1673
bb_rcmovenext1673:
  %v5437 = load i64, ptr %slot1006, align 8
  %v5438 = load i64, ptr %slot1011, align 8
  %p5439 = inttoptr i64 %v5437 to ptr
  %p5440 = inttoptr i64 %v5438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5440, ptr %p5439, i64 16, i1 false)
  %v5441 = load i64, ptr %slot1006, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  store i64 0, ptr %p5442, align 8
  %v5443 = load i64, ptr %slot1006, align 8
  %op5444 = add i64 %v5443, 8
  store i64 %op5444, ptr %slot1025, align 8
  %v5445 = load i64, ptr %slot1025, align 8
  %p5446 = inttoptr i64 %v5445 to ptr
  store i64 0, ptr %p5446, align 8
  br label %bb_rcmoved1665
bb_rcmoveslow1665:
  %v5447 = load i64, ptr %slot53, align 8
  %v5448 = load i64, ptr %slot1011, align 8
  %v5449 = load i64, ptr %slot1006, align 8
  %v5450 = load i64, ptr %slot1012, align 8
  %cv5451 = trunc i64 %v5450 to i32
  %call5452 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v5447, i64 %v5448, i64 %v5449, i32 %cv5451) nomerge, !dbg !206
  store i32 %call5452, ptr %slot1026, align 8
  %v5453 = load i32, ptr %slot1026, align 8
  %cv5454 = zext i32 %v5453 to i64
  %cond5455 = icmp ne i64 %cv5454, 0
  br i1 %cond5455, label %bb_rcsuccess1681, label %bb_rcfailure1681
bb_rcfailure1681:
  %v5456 = load i64, ptr %slot53, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  %call5458 = call i32 @myl_rc_take_failure(ptr %p5457) nomerge, !dbg !206
  store i32 %call5458, ptr %slot1027, align 8
  %v5459 = load i64, ptr %slot1, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  %v5461 = load i32, ptr %slot1027, align 8
  %call5462 = call i32 @myl_qbe_rc_status(ptr %p5460, i32 %v5461) nomerge, !dbg !206
  store i32 %call5462, ptr %slot1028, align 8
  br label %bb_failure
bb_rcsuccess1681:
  br label %bb_rcmoved1665
bb_rcmoved1665:
  %v5463 = load i64, ptr %slot14, align 8
  %p5464 = inttoptr i64 %v5463 to ptr
  store i32 0, ptr %p5464, align 4, !alias.scope !3, !noalias !4
  %v5465 = load i64, ptr %slot19, align 8
  %p5466 = inttoptr i64 %v5465 to ptr
  store i32 2, ptr %p5466, align 4, !alias.scope !3, !noalias !4
  %v5467 = load i64, ptr %slot18, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  store i32 1, ptr %p5468, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1656
bb_rccopy1656:
  %v5469 = load i64, ptr %slot25, align 8
  store i64 %v5469, ptr %slot1029, align 8
  %v5470 = load i64, ptr %slot54, align 8
  store i64 %v5470, ptr %slot1030, align 8
  %v5471 = load i64, ptr %slot53, align 8
  %v5472 = load i64, ptr %slot1029, align 8
  %v5473 = load i64, ptr %slot1006, align 8
  %v5474 = load i64, ptr %slot1030, align 8
  %cv5475 = trunc i64 %v5474 to i32
  %call5476 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v5471, i64 %v5472, i64 %v5473, i32 %cv5475) nomerge, !dbg !206
  store i32 %call5476, ptr %slot1031, align 8
  %v5477 = load i32, ptr %slot1031, align 8
  %cv5478 = zext i32 %v5477 to i64
  %cond5479 = icmp ne i64 %cv5478, 0
  br i1 %cond5479, label %bb_rcsuccess1690, label %bb_rcfailure1690
bb_rcfailure1690:
  %v5480 = load i64, ptr %slot53, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  %call5482 = call i32 @myl_rc_take_failure(ptr %p5481) nomerge, !dbg !206
  store i32 %call5482, ptr %slot1032, align 8
  %v5483 = load i64, ptr %slot1, align 8
  %p5484 = inttoptr i64 %v5483 to ptr
  %v5485 = load i32, ptr %slot1032, align 8
  %call5486 = call i32 @myl_qbe_rc_status(ptr %p5484, i32 %v5485) nomerge, !dbg !206
  store i32 %call5486, ptr %slot1033, align 8
  br label %bb_failure
bb_rcsuccess1690:
  %v5487 = load i64, ptr %slot19, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  store i32 2, ptr %p5488, align 4, !alias.scope !3, !noalias !4
  %v5489 = load i64, ptr %slot18, align 8
  %p5490 = inttoptr i64 %v5489 to ptr
  store i32 1, ptr %p5490, align 4, !alias.scope !3, !noalias !4
  %v5491 = load i64, ptr %slot14, align 8
  %p5492 = inttoptr i64 %v5491 to ptr
  %ld5493 = load i32, ptr %p5492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5493, ptr %slot1034, align 8
  %v5494 = load i32, ptr %slot1034, align 8
  %cv5495 = zext i32 %v5494 to i64
  %cond5496 = icmp ne i64 %cv5495, 0
  br i1 %cond5496, label %bb_rcslotdrop1697, label %bb_rcslotdone1697
bb_rcslotdrop1697:
  %v5497 = load i64, ptr %slot14, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  store i32 0, ptr %p5498, align 4, !alias.scope !3, !noalias !4
  %v5499 = load i64, ptr %slot21, align 8
  store i64 %v5499, ptr %slot1035, align 8
  %v5500 = load i64, ptr %slot15, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  %ld5502 = load i32, ptr %p5501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5502, ptr %slot1036, align 8
  %v5503 = load i32, ptr %slot1036, align 8
  %op5504 = and i32 %v5503, 28
  store i32 %op5504, ptr %slot1037, align 8
  %v5505 = load i32, ptr %slot1037, align 8
  %cv5506 = zext i32 %v5505 to i64
  %cond5507 = icmp ne i64 %cv5506, 0
  br i1 %cond5507, label %bb_rcslotrole1697, label %bb_rcslotowner1697
bb_rcslotrole1697:
  %v5508 = load i64, ptr %slot53, align 8
  store i64 %v5508, ptr %slot1038, align 8
  %v5509 = load i64, ptr %slot1038, align 8
  %v5510 = load i64, ptr %slot1035, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v5509, i64 %v5510) nomerge, !dbg !206
  br label %bb_rcslotdone1697
bb_rcslotowner1697:
  %v5511 = load i64, ptr %slot53, align 8
  store i64 %v5511, ptr %slot1039, align 8
  %v5512 = load i64, ptr %slot1039, align 8
  %v5513 = load i64, ptr %slot1035, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v5512, i64 %v5513) nomerge, !dbg !206
  br label %bb_rcslotdone1697
bb_rcslotdone1697:
  br label %bb_rcprepared1656
bb_rcprepared1656:
  %v5514 = load i64, ptr %slot25, align 8
  store i64 %v5514, ptr %slot1040, align 8
  %v5515 = load i64, ptr %slot1040, align 8
  %v5516 = load i64, ptr %slot1004, align 8
  %p5517 = inttoptr i64 %v5515 to ptr
  %p5518 = inttoptr i64 %v5516 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5518, ptr %p5517, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5519 = load i64, ptr %slot18, align 8
  %p5520 = inttoptr i64 %v5519 to ptr
  store i32 0, ptr %p5520, align 4, !alias.scope !3, !noalias !4
  %v5521 = load i64, ptr %slot1000, align 8
  %v5522 = load i64, ptr %slot36, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  store i64 %v5521, ptr %p5523, align 8, !alias.scope !3, !noalias !4
  %p5524 = inttoptr i64 ptrtoint (ptr @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p5524, i64 135) "call-inline-cost"="0", !dbg !206
  %v5525 = load i64, ptr %slot36, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  %ld5527 = load i64, ptr %p5526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5527, ptr %slot1041, align 8
  %v5528 = load i64, ptr %slot21, align 8
  store i64 %v5528, ptr %slot1042, align 8
  %v5529 = load i64, ptr %slot1041, align 8
  %v5530 = load i64, ptr %slot1042, align 8
  %p5531 = inttoptr i64 %v5529 to ptr
  %p5532 = inttoptr i64 %v5530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5532, ptr %p5531, i64 24, i1 false)
  %v5533 = load i64, ptr %slot15, align 8
  %p5534 = inttoptr i64 %v5533 to ptr
  store i32 2, ptr %p5534, align 4, !alias.scope !3, !noalias !4
  %v5535 = load i64, ptr %slot14, align 8
  %p5536 = inttoptr i64 %v5535 to ptr
  store i32 1, ptr %p5536, align 4, !alias.scope !3, !noalias !4
  %v5537 = load i64, ptr %slot1042, align 8
  %v5538 = load i64, ptr %slot36, align 8
  %p5539 = inttoptr i64 %v5538 to ptr
  store i64 %v5537, ptr %p5539, align 8, !alias.scope !3, !noalias !4
  %v5540 = load i64, ptr %slot36, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  %ld5542 = load i64, ptr %p5541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5542, ptr %slot1043, align 8
  %v5543 = load i64, ptr %slot36, align 8
  %p5544 = inttoptr i64 %v5543 to ptr
  %ld5545 = load i64, ptr %p5544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5545, ptr %slot1044, align 8
  %v5546 = load i64, ptr %slot25, align 8
  store i64 %v5546, ptr %slot1045, align 8
  %v5547 = load i64, ptr %slot54, align 8
  store i64 %v5547, ptr %slot1046, align 8
  %v5548 = load i64, ptr %slot53, align 8
  %v5549 = load i64, ptr %slot1045, align 8
  %v5550 = load i64, ptr %slot1044, align 8
  %v5551 = load i64, ptr %slot1046, align 8
  %cv5552 = trunc i64 %v5551 to i32
  %call5553 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v5548, i64 %v5549, i64 %v5550, i32 %cv5552) nomerge, !dbg !208
  store i32 %call5553, ptr %slot1047, align 8
  %v5554 = load i32, ptr %slot1047, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcsuccess1715, label %bb_rcfailure1715
bb_rcfailure1715:
  %v5557 = load i64, ptr %slot53, align 8
  %p5558 = inttoptr i64 %v5557 to ptr
  %call5559 = call i32 @myl_rc_take_failure(ptr %p5558) nomerge, !dbg !208
  store i32 %call5559, ptr %slot1048, align 8
  %v5560 = load i64, ptr %slot1, align 8
  %p5561 = inttoptr i64 %v5560 to ptr
  %v5562 = load i32, ptr %slot1048, align 8
  %call5563 = call i32 @myl_qbe_rc_status(ptr %p5561, i32 %v5562) nomerge, !dbg !208
  store i32 %call5563, ptr %slot1049, align 8
  br label %bb_failure
bb_rcsuccess1715:
  %v5564 = load i64, ptr %slot14, align 8
  %p5565 = inttoptr i64 %v5564 to ptr
  store i32 0, ptr %p5565, align 4, !alias.scope !3, !noalias !4
  %v5566 = load i64, ptr %slot19, align 8
  %p5567 = inttoptr i64 %v5566 to ptr
  store i32 2, ptr %p5567, align 4, !alias.scope !3, !noalias !4
  %v5568 = load i64, ptr %slot18, align 8
  %p5569 = inttoptr i64 %v5568 to ptr
  store i32 1, ptr %p5569, align 4, !alias.scope !3, !noalias !4
  %v5570 = load i64, ptr %slot25, align 8
  store i64 %v5570, ptr %slot1050, align 8
  %v5571 = load i64, ptr %slot18, align 8
  %p5572 = inttoptr i64 %v5571 to ptr
  store i32 0, ptr %p5572, align 4, !alias.scope !3, !noalias !4
  %v5573 = load i64, ptr %slot14, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %ld5575 = load i32, ptr %p5574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5575, ptr %slot1051, align 8
  %v5576 = load i32, ptr %slot1051, align 8
  %cv5577 = zext i32 %v5576 to i64
  %cond5578 = icmp ne i64 %cv5577, 0
  br i1 %cond5578, label %bb_rcslotdrop1725, label %bb_rcslotdone1725
bb_rcslotdrop1725:
  %v5579 = load i64, ptr %slot14, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i32 0, ptr %p5580, align 4, !alias.scope !3, !noalias !4
  %v5581 = load i64, ptr %slot21, align 8
  store i64 %v5581, ptr %slot1052, align 8
  %v5582 = load i64, ptr %slot15, align 8
  %p5583 = inttoptr i64 %v5582 to ptr
  %ld5584 = load i32, ptr %p5583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5584, ptr %slot1053, align 8
  %v5585 = load i32, ptr %slot1053, align 8
  %op5586 = and i32 %v5585, 28
  store i32 %op5586, ptr %slot1054, align 8
  %v5587 = load i32, ptr %slot1054, align 8
  %cv5588 = zext i32 %v5587 to i64
  %cond5589 = icmp ne i64 %cv5588, 0
  br i1 %cond5589, label %bb_rcslotrole1725, label %bb_rcslotowner1725
bb_rcslotrole1725:
  %v5590 = load i64, ptr %slot53, align 8
  store i64 %v5590, ptr %slot1055, align 8
  %v5591 = load i64, ptr %slot1055, align 8
  %v5592 = load i64, ptr %slot1052, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5591, i64 %v5592) nomerge, !dbg !208
  br label %bb_rcslotdone1725
bb_rcslotowner1725:
  %v5593 = load i64, ptr %slot53, align 8
  store i64 %v5593, ptr %slot1056, align 8
  %v5594 = load i64, ptr %slot1056, align 8
  %v5595 = load i64, ptr %slot1052, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5594, i64 %v5595) nomerge, !dbg !208
  br label %bb_rcslotdone1725
bb_rcslotdone1725:
  %v5596 = load i64, ptr %slot12, align 8
  %p5597 = inttoptr i64 %v5596 to ptr
  %ld5598 = load i32, ptr %p5597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5598, ptr %slot1057, align 8
  %v5599 = load i32, ptr %slot1057, align 8
  %cv5600 = zext i32 %v5599 to i64
  %cond5601 = icmp ne i64 %cv5600, 0
  br i1 %cond5601, label %bb_rcslotdrop1752, label %bb_rcslotdone1752
bb_rcslotdrop1752:
  %v5602 = load i64, ptr %slot12, align 8
  %p5603 = inttoptr i64 %v5602 to ptr
  store i32 0, ptr %p5603, align 4, !alias.scope !3, !noalias !4
  %v5604 = load i64, ptr %slot35, align 8
  store i64 %v5604, ptr %slot1058, align 8
  %v5605 = load i64, ptr %slot13, align 8
  %p5606 = inttoptr i64 %v5605 to ptr
  %ld5607 = load i32, ptr %p5606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5607, ptr %slot1059, align 8
  %v5608 = load i32, ptr %slot1059, align 8
  %op5609 = and i32 %v5608, 28
  store i32 %op5609, ptr %slot1060, align 8
  %v5610 = load i32, ptr %slot1060, align 8
  %cv5611 = zext i32 %v5610 to i64
  %cond5612 = icmp ne i64 %cv5611, 0
  br i1 %cond5612, label %bb_rcslotrole1752, label %bb_rcslotowner1752
bb_rcslotrole1752:
  %v5613 = load i64, ptr %slot53, align 8
  store i64 %v5613, ptr %slot1061, align 8
  %v5614 = load i64, ptr %slot1061, align 8
  %v5615 = load i64, ptr %slot1058, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5614, i64 %v5615) nomerge, !dbg !208
  br label %bb_rcslotdone1752
bb_rcslotowner1752:
  %v5616 = load i64, ptr %slot53, align 8
  store i64 %v5616, ptr %slot1062, align 8
  %v5617 = load i64, ptr %slot1062, align 8
  %v5618 = load i64, ptr %slot1058, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5617, i64 %v5618) nomerge, !dbg !208
  br label %bb_rcslotdone1752
bb_rcslotdone1752:
  %v5619 = load i64, ptr %slot10, align 8
  %p5620 = inttoptr i64 %v5619 to ptr
  %ld5621 = load i32, ptr %p5620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5621, ptr %slot1063, align 8
  %v5622 = load i32, ptr %slot1063, align 8
  %cv5623 = zext i32 %v5622 to i64
  %cond5624 = icmp ne i64 %cv5623, 0
  br i1 %cond5624, label %bb_rcslotdrop1779, label %bb_rcslotdone1779
bb_rcslotdrop1779:
  %v5625 = load i64, ptr %slot10, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  store i32 0, ptr %p5626, align 4, !alias.scope !3, !noalias !4
  %v5627 = load i64, ptr %slot33, align 8
  store i64 %v5627, ptr %slot1064, align 8
  %v5628 = load i64, ptr %slot11, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %ld5630 = load i32, ptr %p5629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5630, ptr %slot1065, align 8
  %v5631 = load i32, ptr %slot1065, align 8
  %op5632 = and i32 %v5631, 28
  store i32 %op5632, ptr %slot1066, align 8
  %v5633 = load i32, ptr %slot1066, align 8
  %cv5634 = zext i32 %v5633 to i64
  %cond5635 = icmp ne i64 %cv5634, 0
  br i1 %cond5635, label %bb_rcslotrole1779, label %bb_rcslotowner1779
bb_rcslotrole1779:
  %v5636 = load i64, ptr %slot53, align 8
  store i64 %v5636, ptr %slot1067, align 8
  %v5637 = load i64, ptr %slot1067, align 8
  %v5638 = load i64, ptr %slot1064, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5637, i64 %v5638) nomerge, !dbg !208
  br label %bb_rcslotdone1779
bb_rcslotowner1779:
  %v5639 = load i64, ptr %slot53, align 8
  store i64 %v5639, ptr %slot1068, align 8
  %v5640 = load i64, ptr %slot1068, align 8
  %v5641 = load i64, ptr %slot1064, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5640, i64 %v5641) nomerge, !dbg !208
  br label %bb_rcslotdone1779
bb_rcslotdone1779:
  %v5642 = load i64, ptr %slot8, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  %ld5644 = load i32, ptr %p5643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5644, ptr %slot1069, align 8
  %v5645 = load i32, ptr %slot1069, align 8
  %cv5646 = zext i32 %v5645 to i64
  %cond5647 = icmp ne i64 %cv5646, 0
  br i1 %cond5647, label %bb_rcslotdrop1806, label %bb_rcslotdone1806
bb_rcslotdrop1806:
  %v5648 = load i64, ptr %slot8, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  store i32 0, ptr %p5649, align 4, !alias.scope !3, !noalias !4
  %v5650 = load i64, ptr %slot31, align 8
  store i64 %v5650, ptr %slot1070, align 8
  %v5651 = load i64, ptr %slot9, align 8
  %p5652 = inttoptr i64 %v5651 to ptr
  %ld5653 = load i32, ptr %p5652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5653, ptr %slot1071, align 8
  %v5654 = load i32, ptr %slot1071, align 8
  %op5655 = and i32 %v5654, 28
  store i32 %op5655, ptr %slot1072, align 8
  %v5656 = load i32, ptr %slot1072, align 8
  %cv5657 = zext i32 %v5656 to i64
  %cond5658 = icmp ne i64 %cv5657, 0
  br i1 %cond5658, label %bb_rcslotrole1806, label %bb_rcslotowner1806
bb_rcslotrole1806:
  %v5659 = load i64, ptr %slot53, align 8
  store i64 %v5659, ptr %slot1073, align 8
  %v5660 = load i64, ptr %slot1073, align 8
  %v5661 = load i64, ptr %slot1070, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5660, i64 %v5661) nomerge, !dbg !208
  br label %bb_rcslotdone1806
bb_rcslotowner1806:
  %v5662 = load i64, ptr %slot53, align 8
  store i64 %v5662, ptr %slot1074, align 8
  %v5663 = load i64, ptr %slot1074, align 8
  %v5664 = load i64, ptr %slot1070, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5663, i64 %v5664) nomerge, !dbg !208
  br label %bb_rcslotdone1806
bb_rcslotdone1806:
  %v5665 = load i64, ptr %slot6, align 8
  %p5666 = inttoptr i64 %v5665 to ptr
  %ld5667 = load i32, ptr %p5666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5667, ptr %slot1075, align 8
  %v5668 = load i32, ptr %slot1075, align 8
  %cv5669 = zext i32 %v5668 to i64
  %cond5670 = icmp ne i64 %cv5669, 0
  br i1 %cond5670, label %bb_rcslotdrop1815, label %bb_rcslotdone1815
bb_rcslotdrop1815:
  %v5671 = load i64, ptr %slot6, align 8
  %p5672 = inttoptr i64 %v5671 to ptr
  store i32 0, ptr %p5672, align 4, !alias.scope !3, !noalias !4
  %v5673 = load i64, ptr %slot28, align 8
  store i64 %v5673, ptr %slot1076, align 8
  %v5674 = load i64, ptr %slot7, align 8
  %p5675 = inttoptr i64 %v5674 to ptr
  %ld5676 = load i32, ptr %p5675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5676, ptr %slot1077, align 8
  %v5677 = load i32, ptr %slot1077, align 8
  %op5678 = and i32 %v5677, 28
  store i32 %op5678, ptr %slot1078, align 8
  %v5679 = load i32, ptr %slot1078, align 8
  %cv5680 = zext i32 %v5679 to i64
  %cond5681 = icmp ne i64 %cv5680, 0
  br i1 %cond5681, label %bb_rcslotrole1815, label %bb_rcslotowner1815
bb_rcslotrole1815:
  %v5682 = load i64, ptr %slot53, align 8
  store i64 %v5682, ptr %slot1079, align 8
  %v5683 = load i64, ptr %slot1079, align 8
  %v5684 = load i64, ptr %slot1076, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5683, i64 %v5684) nomerge, !dbg !208
  br label %bb_rcslotdone1815
bb_rcslotowner1815:
  %v5685 = load i64, ptr %slot53, align 8
  store i64 %v5685, ptr %slot1080, align 8
  %v5686 = load i64, ptr %slot1080, align 8
  %v5687 = load i64, ptr %slot1076, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v5686, i64 %v5687) nomerge, !dbg !208
  br label %bb_rcslotdone1815
bb_rcslotdone1815:
  %v5688 = load i64, ptr %slot1050, align 8
  %p5689 = inttoptr i64 %v5688 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5689, i64 24, i1 false)
  ret void
bb_failure:
  %v5690 = load i64, ptr %slot5, align 8
  %p5691 = inttoptr i64 %v5690 to ptr
  call void @llvm.memset.p0.i64(ptr %p5691, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v5692 = load i64, ptr %slot5, align 8
  %p5693 = inttoptr i64 %v5692 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5693, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v5694 = load i64, ptr %slot5, align 8
  %p5695 = inttoptr i64 %v5694 to ptr
  call void @llvm.memset.p0.i64(ptr %p5695, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v5696 = load i64, ptr %slot5, align 8
  %p5697 = inttoptr i64 %v5696 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5697, i64 24, i1 false)
  ret void
}

@myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342_meta = external global i8, align 8
@myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 = external global i8, align 8
@myl_lit_9ca860660ece73adde8e9de88ebf49903ccf758f133fa9c13722550c82522529 = external global i8, align 8
@myl_lit_ccec7865dc7b502581d71aee3367b2a04dffea764d540fdcda9a17841514ad4f = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64, i64, i64)
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8, i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b_rc_borrow(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64, i64)
declare i64 @myl_f_ed0279e2fa3cbd41257c59aa86e577373533d86b28d37b01468f504f3e141d51(i64, i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64, i64)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64, i64)
declare void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342", linkageName: "myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13351273231618621711, i64 0, !"myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!124 = !DILocation(line: 12, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!128 = !DILocation(line: 15, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!130 = !DILocation(line: 16, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!132 = !DILocation(line: 18, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!134 = !DILocation(line: 20, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!136 = !DILocation(line: 21, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!138 = !DILocation(line: 24, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!140 = !DILocation(line: 26, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!142 = !DILocation(line: 28, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!144 = !DILocation(line: 31, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!146 = !DILocation(line: 36, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!148 = !DILocation(line: 48, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!150 = !DILocation(line: 53, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!152 = !DILocation(line: 56, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!154 = !DILocation(line: 58, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!156 = !DILocation(line: 59, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!158 = !DILocation(line: 60, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!160 = !DILocation(line: 62, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!162 = !DILocation(line: 64, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!164 = !DILocation(line: 67, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!166 = !DILocation(line: 73, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!168 = !DILocation(line: 75, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!170 = !DILocation(line: 76, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!172 = !DILocation(line: 88, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!174 = !DILocation(line: 92, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!176 = !DILocation(line: 98, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!178 = !DILocation(line: 110, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647455)
!180 = !DILocation(line: 115, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647479)
!182 = !DILocation(line: 118, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647503)
!184 = !DILocation(line: 121, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647511)
!186 = !DILocation(line: 122, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!188 = !DILocation(line: 124, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647543)
!190 = !DILocation(line: 126, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647551)
!192 = !DILocation(line: 127, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!194 = !DILocation(line: 128, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647567)
!196 = !DILocation(line: 129, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647575)
!198 = !DILocation(line: 130, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!200 = !DILocation(line: 133, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647607)
!202 = !DILocation(line: 134, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647615)
!204 = !DILocation(line: 135, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647623)
!206 = !DILocation(line: 136, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647631)
!208 = !DILocation(line: 137, column: 0, scope: !209)
