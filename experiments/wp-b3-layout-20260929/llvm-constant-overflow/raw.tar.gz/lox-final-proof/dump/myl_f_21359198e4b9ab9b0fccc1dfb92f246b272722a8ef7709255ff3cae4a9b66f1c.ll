target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v123 = load i64, ptr %slot1, align 8
  %op124 = add i64 %v123, 32
  store i64 %op124, ptr %slot4, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot5, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot6, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot7, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot8, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot9, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot10, align 8
  %mem137 = alloca i8, i64 208, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot11, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot12, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot13, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot14, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot15, align 8
  %mem147 = alloca i8, i64 8, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot16, align 8
  %mem149 = alloca i8, i64 8, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot17, align 8
  %mem151 = alloca i8, i64 8, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot19, align 8
  %v155 = load i64, ptr %slot1, align 8
  %op156 = add i64 %v155, 64
  store i64 %op156, ptr %slot20, align 8
  %v157 = load i64, ptr %slot20, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !4, !noalias !3
  store i64 %ld159, ptr %slot21, align 8
  %stack160 = call ptr @llvm.stacksave()
  %stackaddr161 = ptrtoint ptr %stack160 to i64
  %v162 = load i64, ptr %slot21, align 8
  %cmp163 = icmp ult i64 %stackaddr161, %v162
  %cv164 = zext i1 %cmp163 to i64
  store i64 %cv164, ptr %slot22, align 8
  %v165 = load i64, ptr %slot22, align 8
  %cond166 = icmp ne i64 %v165, 0
  br i1 %cond166, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v167 = load i64, ptr %slot1, align 8
  %p168 = inttoptr i64 %v167 to ptr
  call void @myl_qbe_fail_frame(ptr %p168) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v169 = load i64, ptr %slot2, align 8
  %v170 = load i64, ptr %slot12, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i64 %v169, ptr %p171, align 8, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot3, align 8
  %v173 = load i64, ptr %slot13, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot1, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %call177 = call ptr @myl_qbe_heap(ptr %p176) nomerge, !dbg !112
  %calladdr178 = ptrtoint ptr %call177 to i64
  store i64 %calladdr178, ptr %slot23, align 8
  %v179 = load i64, ptr %slot5, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i32 0, ptr %p180, align 4, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot6, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i32 0, ptr %p182, align 4, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot7, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i32 0, ptr %p184, align 4, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot8, align 8
  %p186 = inttoptr i64 %v185 to ptr
  store i32 0, ptr %p186, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v187 = load i64, ptr %slot13, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot24, align 8
  %v190 = load i64, ptr %slot24, align 8
  %v191 = load i64, ptr %slot16, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot16, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot25, align 8
  %v196 = load i64, ptr %slot1, align 8
  %v197 = load i64, ptr %slot25, align 8
  %call198 = call i64 @myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1(i64 %v196, i64 %v197) nomerge, !dbg !114
  store i64 %call198, ptr %slot26, align 8
  %v199 = load i64, ptr %slot26, align 8
  %v200 = load i64, ptr %slot16, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot16, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot27, align 8
  %v205 = load i64, ptr %slot27, align 8
  %v206 = load i64, ptr %slot14, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot12, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot28, align 8
  %v211 = load i64, ptr %slot28, align 8
  %v212 = load i64, ptr %slot16, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot13, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot29, align 8
  %v217 = load i64, ptr %slot29, align 8
  %v218 = load i64, ptr %slot17, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot14, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot30, align 8
  %v223 = load i64, ptr %slot30, align 8
  %v224 = load i64, ptr %slot18, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot16, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot31, align 8
  %v229 = load i64, ptr %slot17, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld231, ptr %slot32, align 8
  %v232 = load i64, ptr %slot18, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot33, align 8
  %v235 = load i64, ptr %slot1, align 8
  %v236 = load i64, ptr %slot31, align 8
  %v237 = load i64, ptr %slot32, align 8
  %v238 = load i64, ptr %slot33, align 8
  %call239 = call i64 @myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb(i64 %v235, i64 %v236, i64 %v237, i64 %v238) nomerge, !dbg !116
  store i64 %call239, ptr %slot34, align 8
  %v240 = load i64, ptr %slot34, align 8
  %v241 = load i64, ptr %slot16, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i32, ptr %p244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld245, ptr %slot35, align 8
  %v246 = load i32, ptr %slot35, align 8
  %cv247 = zext i32 %v246 to i64
  %cond248 = icmp ne i64 %cv247, 0
  br i1 %cond248, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v249 = load i64, ptr %slot5, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i32 0, ptr %p250, align 4, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot9, align 8
  store i64 %v251, ptr %slot36, align 8
  %v252 = load i64, ptr %slot6, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i32, ptr %p253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld254, ptr %slot37, align 8
  %v255 = load i32, ptr %slot37, align 8
  %op256 = and i32 %v255, 28
  store i32 %op256, ptr %slot38, align 8
  %v257 = load i32, ptr %slot38, align 8
  %cv258 = zext i32 %v257 to i64
  %cond259 = icmp ne i64 %cv258, 0
  br i1 %cond259, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v260 = load i64, ptr %slot23, align 8
  store i64 %v260, ptr %slot39, align 8
  %v261 = load i64, ptr %slot36, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot40, align 8
  %v264 = load i64, ptr %slot40, align 8
  %cmp265 = icmp ne i64 %v264, 0
  %cv266 = zext i1 %cmp265 to i32
  store i32 %cv266, ptr %slot41, align 8
  %v267 = load i32, ptr %slot41, align 8
  %cv268 = zext i32 %v267 to i64
  %cond269 = icmp ne i64 %cv268, 0
  br i1 %cond269, label %bb_rcgnn84, label %bb_rcgdone84
bb_rcgnn84:
  %v270 = load i64, ptr %slot40, align 8
  %op271 = sub i64 %v270, 16
  store i64 %op271, ptr %slot42, align 8
  %v272 = load i64, ptr %slot40, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %rgep274 = getelementptr i8, ptr %p273, i64 -16
  %ld275 = load i64, ptr %rgep274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld275, ptr %slot43, align 8
  %v276 = load i64, ptr %slot43, align 8
  %op277 = and i64 %v276, 4611686018427387906
  store i64 %op277, ptr %slot44, align 8
  %v278 = load i64, ptr %slot44, align 8
  %cmp279 = icmp ne i64 %v278, 0
  %cv280 = zext i1 %cmp279 to i32
  store i32 %cv280, ptr %slot45, align 8
  %v281 = load i32, ptr %slot45, align 8
  %cv282 = zext i32 %v281 to i64
  %cond283 = icmp ne i64 %cv282, 0
  br i1 %cond283, label %bb_rcgclear84, label %bb_rcgcounted84
bb_rcgcounted84:
  %v284 = load i64, ptr %slot40, align 8
  %op285 = sub i64 %v284, 24
  store i64 %op285, ptr %slot46, align 8
  %v286 = load i64, ptr %slot40, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %rgep288 = getelementptr i8, ptr %p287, i64 -24
  %ld289 = load i64, ptr %rgep288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld289, ptr %slot47, align 8
  %v290 = load i64, ptr %slot47, align 8
  %op291 = sub i64 %v290, 1
  store i64 %op291, ptr %slot48, align 8
  %v292 = load i64, ptr %slot48, align 8
  %cmp293 = icmp eq i64 %v292, 0
  %cv294 = zext i1 %cmp293 to i32
  store i32 %cv294, ptr %slot49, align 8
  %v295 = load i32, ptr %slot49, align 8
  %cv296 = zext i32 %v295 to i64
  %cond297 = icmp ne i64 %cv296, 0
  br i1 %cond297, label %bb_rcglast84, label %bb_rcgdec84
bb_rcglast84:
  %v298 = load i64, ptr %slot40, align 8
  %op299 = sub i64 %v298, 32
  store i64 %op299, ptr %slot50, align 8
  %v300 = load i64, ptr %slot40, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %rgep302 = getelementptr i8, ptr %p301, i64 -32
  %ld303 = load i64, ptr %rgep302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld303, ptr %slot51, align 8
  %v304 = load i64, ptr %slot51, align 8
  %cmp305 = icmp ne i64 %v304, 0
  %cv306 = zext i1 %cmp305 to i32
  store i32 %cv306, ptr %slot52, align 8
  %v307 = load i32, ptr %slot52, align 8
  %cv308 = zext i32 %v307 to i64
  %cond309 = icmp ne i64 %cv308, 0
  br i1 %cond309, label %bb_rcgdec84, label %bb_rcgslow84
bb_rcgslow84:
  %v310 = load i64, ptr %slot39, align 8
  %v311 = load i64, ptr %slot36, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v310, i64 %v311) nomerge, !dbg !116
  br label %bb_rcgdone84
bb_rcgdec84:
  %v312 = load i64, ptr %slot48, align 8
  %v313 = load i64, ptr %slot40, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %rgep315 = getelementptr i8, ptr %p314, i64 -24
  store i64 %v312, ptr %rgep315, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear84
bb_rcgclear84:
  %v316 = load i64, ptr %slot36, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 0, ptr %p317, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone84
bb_rcgdone84:
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v318 = load i64, ptr %slot23, align 8
  store i64 %v318, ptr %slot53, align 8
  %v319 = load i64, ptr %slot36, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %ld321 = load i64, ptr %p320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld321, ptr %slot54, align 8
  %v322 = load i64, ptr %slot54, align 8
  %cmp323 = icmp ne i64 %v322, 0
  %cv324 = zext i1 %cmp323 to i32
  store i32 %cv324, ptr %slot55, align 8
  %v325 = load i32, ptr %slot55, align 8
  %cv326 = zext i32 %v325 to i64
  %cond327 = icmp ne i64 %cv326, 0
  br i1 %cond327, label %bb_rcgnn99, label %bb_rcgdone99
bb_rcgnn99:
  %v328 = load i64, ptr %slot54, align 8
  %op329 = sub i64 %v328, 16
  store i64 %op329, ptr %slot56, align 8
  %v330 = load i64, ptr %slot54, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %rgep332 = getelementptr i8, ptr %p331, i64 -16
  %ld333 = load i64, ptr %rgep332, align 8, !alias.scope !9, !noalias !10
  store i64 %ld333, ptr %slot57, align 8
  %v334 = load i64, ptr %slot57, align 8
  %op335 = and i64 %v334, 4611686018427387906
  store i64 %op335, ptr %slot58, align 8
  %v336 = load i64, ptr %slot58, align 8
  %cmp337 = icmp ne i64 %v336, 0
  %cv338 = zext i1 %cmp337 to i32
  store i32 %cv338, ptr %slot59, align 8
  %v339 = load i32, ptr %slot59, align 8
  %cv340 = zext i32 %v339 to i64
  %cond341 = icmp ne i64 %cv340, 0
  br i1 %cond341, label %bb_rcgclear99, label %bb_rcgcounted99
bb_rcgcounted99:
  %v342 = load i64, ptr %slot54, align 8
  %op343 = sub i64 %v342, 32
  store i64 %op343, ptr %slot60, align 8
  %v344 = load i64, ptr %slot54, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %rgep346 = getelementptr i8, ptr %p345, i64 -32
  %ld347 = load i64, ptr %rgep346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld347, ptr %slot61, align 8
  %v348 = load i64, ptr %slot61, align 8
  %op349 = sub i64 %v348, 1
  store i64 %op349, ptr %slot62, align 8
  %v350 = load i64, ptr %slot62, align 8
  %cmp351 = icmp eq i64 %v350, 0
  %cv352 = zext i1 %cmp351 to i32
  store i32 %cv352, ptr %slot63, align 8
  %v353 = load i32, ptr %slot63, align 8
  %cv354 = zext i32 %v353 to i64
  %cond355 = icmp ne i64 %cv354, 0
  br i1 %cond355, label %bb_rcglast99, label %bb_rcgdec99
bb_rcglast99:
  %v356 = load i64, ptr %slot54, align 8
  %op357 = sub i64 %v356, 24
  store i64 %op357, ptr %slot64, align 8
  %v358 = load i64, ptr %slot54, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %rgep360 = getelementptr i8, ptr %p359, i64 -24
  %ld361 = load i64, ptr %rgep360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld361, ptr %slot65, align 8
  %v362 = load i64, ptr %slot65, align 8
  %cmp363 = icmp ne i64 %v362, 0
  %cv364 = zext i1 %cmp363 to i32
  store i32 %cv364, ptr %slot66, align 8
  %v365 = load i32, ptr %slot66, align 8
  %cv366 = zext i32 %v365 to i64
  %cond367 = icmp ne i64 %cv366, 0
  br i1 %cond367, label %bb_rcgdec99, label %bb_rcgslow99
bb_rcgslow99:
  %v368 = load i64, ptr %slot53, align 8
  %v369 = load i64, ptr %slot36, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v368, i64 %v369) nomerge, !dbg !116
  br label %bb_rcgdone99
bb_rcgdec99:
  %v370 = load i64, ptr %slot62, align 8
  %v371 = load i64, ptr %slot54, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %rgep373 = getelementptr i8, ptr %p372, i64 -32
  store i64 %v370, ptr %rgep373, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear99
bb_rcgclear99:
  %v374 = load i64, ptr %slot36, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 0, ptr %p375, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone99
bb_rcgdone99:
  br label %bb_rcslotdone68
bb_rcslotdone68:
  %v376 = load i64, ptr %slot16, align 8
  %p377 = inttoptr i64 %v376 to ptr
  %ld378 = load i64, ptr %p377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld378, ptr %slot67, align 8
  %v379 = load i64, ptr %slot67, align 8
  %v380 = load i64, ptr %slot15, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 %v379, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot15, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot68, align 8
  %v385 = load i64, ptr %slot68, align 8
  %v386 = load i64, ptr %slot16, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot17, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 18446744073709551615, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot17, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot69, align 8
  %v393 = load i64, ptr %slot16, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %ld395 = load i64, ptr %p394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld395, ptr %slot70, align 8
  %v396 = load i64, ptr %slot70, align 8
  %v397 = load i64, ptr %slot69, align 8
  %cmp398 = icmp ne i64 %v396, %v397
  %cv399 = zext i1 %cmp398 to i64
  store i64 %cv399, ptr %slot71, align 8
  %v400 = load i64, ptr %slot71, align 8
  %v401 = load i64, ptr %slot16, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 %v400, ptr %p402, align 8, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot16, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot72, align 8
  %v406 = load i64, ptr %slot72, align 8
  %cond407 = icmp ne i64 %v406, 0
  br i1 %cond407, label %bb_next109, label %bb_i14
bb_next109:
  %v408 = load i64, ptr %slot15, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot73, align 8
  %v411 = load i64, ptr %slot73, align 8
  %v412 = load i64, ptr %slot16, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot16, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot74, align 8
  %v417 = load i64, ptr %slot74, align 8
  ret i64 %v417
bb_i14:
  %v418 = load i64, ptr %slot12, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld420, ptr %slot75, align 8
  %v421 = load i64, ptr %slot75, align 8
  %v422 = load i64, ptr %slot16, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot13, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot76, align 8
  %v427 = load i64, ptr %slot23, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %v429 = load i64, ptr %slot76, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %call431 = call ptr @myl_native_bytes_copy(ptr %p428, ptr %p430) nomerge, !dbg !118
  %calladdr432 = ptrtoint ptr %call431 to i64
  store i64 %calladdr432, ptr %slot77, align 8
  %v433 = load i64, ptr %slot77, align 8
  %cond434 = icmp ne i64 %v433, 0
  br i1 %cond434, label %bb_success163, label %bb_failed163
bb_failed163:
  %v435 = load i64, ptr %slot1, align 8
  %p436 = inttoptr i64 %v435 to ptr
  call void @myl_qbe_fail_allocation(ptr %p436) nomerge, !dbg !118
  unreachable
bb_success163:
  %v437 = load i64, ptr %slot77, align 8
  %v438 = load i64, ptr %slot17, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 %v437, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot17, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i64, ptr %p441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld442, ptr %slot78, align 8
  %v443 = load i64, ptr %slot78, align 8
  %v444 = load i64, ptr %slot10, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 %v443, ptr %p445, align 8, !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot10, align 8
  store i64 %v446, ptr %slot79, align 8
  %v447 = load i64, ptr %slot11, align 8
  store i64 %v447, ptr %slot80, align 8
  %v448 = load i64, ptr %slot79, align 8
  %v449 = load i64, ptr %slot80, align 8
  %p450 = inttoptr i64 %v448 to ptr
  %p451 = inttoptr i64 %v449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p451, ptr %p450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot8, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i32 2, ptr %p453, align 4, !alias.scope !3, !noalias !4
  %v454 = load i64, ptr %slot7, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i32 1, ptr %p455, align 4, !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot9, align 8
  store i64 %v456, ptr %slot81, align 8
  %v457 = load i64, ptr %slot11, align 8
  store i64 %v457, ptr %slot82, align 8
  %v458 = load i64, ptr %slot82, align 8
  %v459 = load i64, ptr %slot81, align 8
  %p460 = inttoptr i64 %v458 to ptr
  %p461 = inttoptr i64 %v459 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p461, ptr %p460, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot6, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i32 2, ptr %p463, align 4, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot8, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i32, ptr %p465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld466, ptr %slot83, align 8
  %v467 = load i32, ptr %slot83, align 8
  %v468 = load i64, ptr %slot6, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 %v467, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot7, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 0, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot5, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 1, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot81, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot84, align 8
  %v477 = load i64, ptr %slot84, align 8
  %v478 = load i64, ptr %slot17, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i64 %v477, ptr %p479, align 8, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot14, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld482, ptr %slot85, align 8
  %v483 = load i64, ptr %slot85, align 8
  %v484 = load i64, ptr %slot18, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 %v483, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot16, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i64, ptr %p487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld488, ptr %slot86, align 8
  %v489 = load i64, ptr %slot17, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld491, ptr %slot87, align 8
  %v492 = load i64, ptr %slot18, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot88, align 8
  %v495 = load i64, ptr %slot1, align 8
  %v496 = load i64, ptr %slot86, align 8
  %v497 = load i64, ptr %slot87, align 8
  %v498 = load i64, ptr %slot88, align 8
  %call499 = call i64 @myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016(i64 %v495, i64 %v496, i64 %v497, i64 %v498) nomerge, !dbg !120
  store i64 %call499, ptr %slot89, align 8
  %v500 = load i64, ptr %slot89, align 8
  %v501 = load i64, ptr %slot16, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i64 %v500, ptr %p502, align 8, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot5, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %ld505 = load i32, ptr %p504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld505, ptr %slot90, align 8
  %v506 = load i32, ptr %slot90, align 8
  %cv507 = zext i32 %v506 to i64
  %cond508 = icmp ne i64 %cv507, 0
  br i1 %cond508, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v509 = load i64, ptr %slot5, align 8
  %p510 = inttoptr i64 %v509 to ptr
  store i32 0, ptr %p510, align 4, !alias.scope !3, !noalias !4
  %v511 = load i64, ptr %slot9, align 8
  store i64 %v511, ptr %slot91, align 8
  %v512 = load i64, ptr %slot6, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %ld514 = load i32, ptr %p513, align 4, !alias.scope !3, !noalias !4
  store i32 %ld514, ptr %slot92, align 8
  %v515 = load i32, ptr %slot92, align 8
  %op516 = and i32 %v515, 28
  store i32 %op516, ptr %slot93, align 8
  %v517 = load i32, ptr %slot93, align 8
  %cv518 = zext i32 %v517 to i64
  %cond519 = icmp ne i64 %cv518, 0
  br i1 %cond519, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v520 = load i64, ptr %slot23, align 8
  store i64 %v520, ptr %slot94, align 8
  %v521 = load i64, ptr %slot91, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i64, ptr %p522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld523, ptr %slot95, align 8
  %v524 = load i64, ptr %slot95, align 8
  %cmp525 = icmp ne i64 %v524, 0
  %cv526 = zext i1 %cmp525 to i32
  store i32 %cv526, ptr %slot96, align 8
  %v527 = load i32, ptr %slot96, align 8
  %cv528 = zext i32 %v527 to i64
  %cond529 = icmp ne i64 %cv528, 0
  br i1 %cond529, label %bb_rcgnn210, label %bb_rcgdone210
bb_rcgnn210:
  %v530 = load i64, ptr %slot95, align 8
  %op531 = sub i64 %v530, 16
  store i64 %op531, ptr %slot97, align 8
  %v532 = load i64, ptr %slot95, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %rgep534 = getelementptr i8, ptr %p533, i64 -16
  %ld535 = load i64, ptr %rgep534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld535, ptr %slot98, align 8
  %v536 = load i64, ptr %slot98, align 8
  %op537 = and i64 %v536, 4611686018427387906
  store i64 %op537, ptr %slot99, align 8
  %v538 = load i64, ptr %slot99, align 8
  %cmp539 = icmp ne i64 %v538, 0
  %cv540 = zext i1 %cmp539 to i32
  store i32 %cv540, ptr %slot100, align 8
  %v541 = load i32, ptr %slot100, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcgclear210, label %bb_rcgcounted210
bb_rcgcounted210:
  %v544 = load i64, ptr %slot95, align 8
  %op545 = sub i64 %v544, 24
  store i64 %op545, ptr %slot101, align 8
  %v546 = load i64, ptr %slot95, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %rgep548 = getelementptr i8, ptr %p547, i64 -24
  %ld549 = load i64, ptr %rgep548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld549, ptr %slot102, align 8
  %v550 = load i64, ptr %slot102, align 8
  %op551 = sub i64 %v550, 1
  store i64 %op551, ptr %slot103, align 8
  %v552 = load i64, ptr %slot103, align 8
  %cmp553 = icmp eq i64 %v552, 0
  %cv554 = zext i1 %cmp553 to i32
  store i32 %cv554, ptr %slot104, align 8
  %v555 = load i32, ptr %slot104, align 8
  %cv556 = zext i32 %v555 to i64
  %cond557 = icmp ne i64 %cv556, 0
  br i1 %cond557, label %bb_rcglast210, label %bb_rcgdec210
bb_rcglast210:
  %v558 = load i64, ptr %slot95, align 8
  %op559 = sub i64 %v558, 32
  store i64 %op559, ptr %slot105, align 8
  %v560 = load i64, ptr %slot95, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %rgep562 = getelementptr i8, ptr %p561, i64 -32
  %ld563 = load i64, ptr %rgep562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld563, ptr %slot106, align 8
  %v564 = load i64, ptr %slot106, align 8
  %cmp565 = icmp ne i64 %v564, 0
  %cv566 = zext i1 %cmp565 to i32
  store i32 %cv566, ptr %slot107, align 8
  %v567 = load i32, ptr %slot107, align 8
  %cv568 = zext i32 %v567 to i64
  %cond569 = icmp ne i64 %cv568, 0
  br i1 %cond569, label %bb_rcgdec210, label %bb_rcgslow210
bb_rcgslow210:
  %v570 = load i64, ptr %slot94, align 8
  %v571 = load i64, ptr %slot91, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v570, i64 %v571) nomerge, !dbg !120
  br label %bb_rcgdone210
bb_rcgdec210:
  %v572 = load i64, ptr %slot103, align 8
  %v573 = load i64, ptr %slot95, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %rgep575 = getelementptr i8, ptr %p574, i64 -24
  store i64 %v572, ptr %rgep575, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear210
bb_rcgclear210:
  %v576 = load i64, ptr %slot91, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i64 0, ptr %p577, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone210
bb_rcgdone210:
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v578 = load i64, ptr %slot23, align 8
  store i64 %v578, ptr %slot108, align 8
  %v579 = load i64, ptr %slot91, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i64, ptr %p580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld581, ptr %slot109, align 8
  %v582 = load i64, ptr %slot109, align 8
  %cmp583 = icmp ne i64 %v582, 0
  %cv584 = zext i1 %cmp583 to i32
  store i32 %cv584, ptr %slot110, align 8
  %v585 = load i32, ptr %slot110, align 8
  %cv586 = zext i32 %v585 to i64
  %cond587 = icmp ne i64 %cv586, 0
  br i1 %cond587, label %bb_rcgnn225, label %bb_rcgdone225
bb_rcgnn225:
  %v588 = load i64, ptr %slot109, align 8
  %op589 = sub i64 %v588, 16
  store i64 %op589, ptr %slot111, align 8
  %v590 = load i64, ptr %slot109, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %rgep592 = getelementptr i8, ptr %p591, i64 -16
  %ld593 = load i64, ptr %rgep592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld593, ptr %slot112, align 8
  %v594 = load i64, ptr %slot112, align 8
  %op595 = and i64 %v594, 4611686018427387906
  store i64 %op595, ptr %slot113, align 8
  %v596 = load i64, ptr %slot113, align 8
  %cmp597 = icmp ne i64 %v596, 0
  %cv598 = zext i1 %cmp597 to i32
  store i32 %cv598, ptr %slot114, align 8
  %v599 = load i32, ptr %slot114, align 8
  %cv600 = zext i32 %v599 to i64
  %cond601 = icmp ne i64 %cv600, 0
  br i1 %cond601, label %bb_rcgclear225, label %bb_rcgcounted225
bb_rcgcounted225:
  %v602 = load i64, ptr %slot109, align 8
  %op603 = sub i64 %v602, 32
  store i64 %op603, ptr %slot115, align 8
  %v604 = load i64, ptr %slot109, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %rgep606 = getelementptr i8, ptr %p605, i64 -32
  %ld607 = load i64, ptr %rgep606, align 8, !alias.scope !9, !noalias !10
  store i64 %ld607, ptr %slot116, align 8
  %v608 = load i64, ptr %slot116, align 8
  %op609 = sub i64 %v608, 1
  store i64 %op609, ptr %slot117, align 8
  %v610 = load i64, ptr %slot117, align 8
  %cmp611 = icmp eq i64 %v610, 0
  %cv612 = zext i1 %cmp611 to i32
  store i32 %cv612, ptr %slot118, align 8
  %v613 = load i32, ptr %slot118, align 8
  %cv614 = zext i32 %v613 to i64
  %cond615 = icmp ne i64 %cv614, 0
  br i1 %cond615, label %bb_rcglast225, label %bb_rcgdec225
bb_rcglast225:
  %v616 = load i64, ptr %slot109, align 8
  %op617 = sub i64 %v616, 24
  store i64 %op617, ptr %slot119, align 8
  %v618 = load i64, ptr %slot109, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %rgep620 = getelementptr i8, ptr %p619, i64 -24
  %ld621 = load i64, ptr %rgep620, align 8, !alias.scope !9, !noalias !10
  store i64 %ld621, ptr %slot120, align 8
  %v622 = load i64, ptr %slot120, align 8
  %cmp623 = icmp ne i64 %v622, 0
  %cv624 = zext i1 %cmp623 to i32
  store i32 %cv624, ptr %slot121, align 8
  %v625 = load i32, ptr %slot121, align 8
  %cv626 = zext i32 %v625 to i64
  %cond627 = icmp ne i64 %cv626, 0
  br i1 %cond627, label %bb_rcgdec225, label %bb_rcgslow225
bb_rcgslow225:
  %v628 = load i64, ptr %slot108, align 8
  %v629 = load i64, ptr %slot91, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v628, i64 %v629) nomerge, !dbg !120
  br label %bb_rcgdone225
bb_rcgdec225:
  %v630 = load i64, ptr %slot117, align 8
  %v631 = load i64, ptr %slot109, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %rgep633 = getelementptr i8, ptr %p632, i64 -32
  store i64 %v630, ptr %rgep633, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear225
bb_rcgclear225:
  %v634 = load i64, ptr %slot91, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i64 0, ptr %p635, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone225
bb_rcgdone225:
  br label %bb_rcslotdone194
bb_rcslotdone194:
  %v636 = load i64, ptr %slot16, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot122, align 8
  %v639 = load i64, ptr %slot122, align 8
  ret i64 %v639
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb(i64, i64, i64, i64)
declare i64 @myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016(i64, i64, i64, i64)
declare i64 @myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1(i64, i64)
declare ptr @myl_native_bytes_copy(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c", linkageName: "myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1389213097633688550, i64 0, !"myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!118 = !DILocation(line: 16, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!120 = !DILocation(line: 18, column: 0, scope: !121)
