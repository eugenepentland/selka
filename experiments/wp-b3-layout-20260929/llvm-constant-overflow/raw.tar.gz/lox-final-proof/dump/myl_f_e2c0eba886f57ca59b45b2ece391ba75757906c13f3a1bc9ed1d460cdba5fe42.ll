target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %callresult47 = alloca [40 x i8], align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %callresult95 = alloca [40 x i8], align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %callresult115 = alloca [1 x i8], align 1
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v153 = load i64, ptr %slot1, align 8
  %op154 = add i64 %v153, 32
  store i64 %op154, ptr %slot5, align 8
  %mem155 = alloca i8, i64 48, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot6, align 8
  %mem157 = alloca i8, i64 8, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot7, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot8, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot9, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot10, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot11, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot12, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot13, align 8
  %mem171 = alloca i8, i64 312, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot14, align 8
  %mem173 = alloca i8, i64 312, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot15, align 8
  %mem175 = alloca i8, i64 312, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot16, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot17, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot18, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot19, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot20, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot21, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot22, align 8
  %mem189 = alloca i8, i64 48, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot23, align 8
  %mem191 = alloca i8, i64 312, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot24, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot25, align 8
  %v195 = load i64, ptr %slot1, align 8
  %op196 = add i64 %v195, 64
  store i64 %op196, ptr %slot26, align 8
  %v197 = load i64, ptr %slot26, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !4, !noalias !3
  store i64 %ld199, ptr %slot27, align 8
  %stack200 = call ptr @llvm.stacksave()
  %stackaddr201 = ptrtoint ptr %stack200 to i64
  %v202 = load i64, ptr %slot27, align 8
  %cmp203 = icmp ult i64 %stackaddr201, %v202
  %cv204 = zext i1 %cmp203 to i64
  store i64 %cv204, ptr %slot28, align 8
  %v205 = load i64, ptr %slot28, align 8
  %cond206 = icmp ne i64 %v205, 0
  br i1 %cond206, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v207 = load i64, ptr %slot1, align 8
  %p208 = inttoptr i64 %v207 to ptr
  call void @myl_qbe_fail_frame(ptr %p208) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %mem209 = alloca i8, i64 48, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot29, align 8
  %v211 = load i64, ptr %slot2, align 8
  %v212 = load i64, ptr %slot17, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot3, align 8
  %v215 = load i64, ptr %slot18, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot4, align 8
  %v218 = load i64, ptr %slot19, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot1, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %call222 = call ptr @myl_qbe_heap(ptr %p221) nomerge, !dbg !112
  %calladdr223 = ptrtoint ptr %call222 to i64
  store i64 %calladdr223, ptr %slot30, align 8
  %v224 = load i64, ptr %slot1, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %call226 = call i64 @myl_qbe_region_mark(ptr %p225) nomerge, !dbg !112
  store i64 %call226, ptr %slot31, align 8
  %v227 = load i64, ptr %slot7, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i32 0, ptr %p228, align 4, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot8, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i32 0, ptr %p230, align 4, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot9, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i32 0, ptr %p232, align 4, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot10, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i32 0, ptr %p234, align 4, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot11, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i32 0, ptr %p236, align 4, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot12, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i32 0, ptr %p238, align 4, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot13, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i32 0, ptr %p240, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v241 = load i64, ptr %slot17, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot32, align 8
  %v244 = load i64, ptr %slot32, align 8
  %v245 = load i64, ptr %slot20, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i64 %v244, ptr %p246, align 8, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot18, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot33, align 8
  %v250 = load i64, ptr %slot33, align 8
  %v251 = load i64, ptr %slot21, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot20, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot34, align 8
  %v256 = load i64, ptr %slot21, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot35, align 8
  %v259 = load i64, ptr %slot1, align 8
  %v260 = load i64, ptr %slot34, align 8
  %v261 = load i64, ptr %slot35, align 8
  %call262 = call i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %v259, i64 %v260, i64 %v261) nomerge, !dbg !114
  store i64 %call262, ptr %slot36, align 8
  %v263 = load i64, ptr %slot36, align 8
  %v264 = load i64, ptr %slot20, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i64 %v263, ptr %p265, align 8, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot7, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %ld268 = load i32, ptr %p267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld268, ptr %slot37, align 8
  %v269 = load i32, ptr %slot37, align 8
  %cv270 = zext i32 %v269 to i64
  %cond271 = icmp ne i64 %cv270, 0
  br i1 %cond271, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v272 = load i64, ptr %slot7, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i32 0, ptr %p273, align 4, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot14, align 8
  store i64 %v274, ptr %slot38, align 8
  %v275 = load i64, ptr %slot8, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i32, ptr %p276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld277, ptr %slot39, align 8
  %v278 = load i32, ptr %slot39, align 8
  %op279 = and i32 %v278, 28
  store i32 %op279, ptr %slot40, align 8
  %v280 = load i32, ptr %slot40, align 8
  %cv281 = zext i32 %v280 to i64
  %cond282 = icmp ne i64 %cv281, 0
  br i1 %cond282, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v283 = load i64, ptr %slot30, align 8
  store i64 %v283, ptr %slot41, align 8
  %v284 = load i64, ptr %slot41, align 8
  %v285 = load i64, ptr %slot38, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v284, i64 %v285) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v286 = load i64, ptr %slot30, align 8
  store i64 %v286, ptr %slot42, align 8
  %v287 = load i64, ptr %slot42, align 8
  %v288 = load i64, ptr %slot38, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v287, i64 %v288) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v289 = load i64, ptr %slot20, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot43, align 8
  %v292 = load i64, ptr %slot43, align 8
  %cond293 = icmp ne i64 %v292, 0
  br i1 %cond293, label %bb_next24, label %bb_i8
bb_next24:
  %v294 = load i64, ptr %slot17, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %ld296 = load i64, ptr %p295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld296, ptr %slot44, align 8
  %v297 = load i64, ptr %slot44, align 8
  %v298 = load i64, ptr %slot20, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 %v297, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot20, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot45, align 8
  %v303 = load i64, ptr %slot1, align 8
  %v304 = load i64, ptr %slot45, align 8
  call void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8 %callresult47, i64 %v303, i64 %v304) nomerge, !dbg !116
  %addr305 = ptrtoint ptr %callresult47 to i64
  store i64 %addr305, ptr %slot46, align 8
  %v306 = load i64, ptr %slot46, align 8
  %v307 = load i64, ptr %slot20, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i64 %v306, ptr %p308, align 8, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot20, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot48, align 8
  %v312 = load i64, ptr %slot16, align 8
  store i64 %v312, ptr %slot49, align 8
  %v313 = load i64, ptr %slot48, align 8
  %v314 = load i64, ptr %slot49, align 8
  %p315 = inttoptr i64 %v313 to ptr
  %p316 = inttoptr i64 %v314 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p316, ptr %p315, i64 40, i1 false)
  %v317 = load i64, ptr %slot12, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 2, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot11, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 1, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot7, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i32, ptr %p322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld323, ptr %slot50, align 8
  %v324 = load i32, ptr %slot50, align 8
  %cv325 = zext i32 %v324 to i64
  %cond326 = icmp ne i64 %cv325, 0
  br i1 %cond326, label %bb_rcslotdrop33, label %bb_rcslotdone33
bb_rcslotdrop33:
  %v327 = load i64, ptr %slot7, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 0, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot14, align 8
  store i64 %v329, ptr %slot51, align 8
  %v330 = load i64, ptr %slot8, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i32, ptr %p331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld332, ptr %slot52, align 8
  %v333 = load i32, ptr %slot52, align 8
  %op334 = and i32 %v333, 28
  store i32 %op334, ptr %slot53, align 8
  %v335 = load i32, ptr %slot53, align 8
  %cv336 = zext i32 %v335 to i64
  %cond337 = icmp ne i64 %cv336, 0
  br i1 %cond337, label %bb_rcslotrole33, label %bb_rcslotowner33
bb_rcslotrole33:
  %v338 = load i64, ptr %slot30, align 8
  store i64 %v338, ptr %slot54, align 8
  %v339 = load i64, ptr %slot54, align 8
  %v340 = load i64, ptr %slot51, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v339, i64 %v340) nomerge, !dbg !116
  br label %bb_rcslotdone33
bb_rcslotowner33:
  %v341 = load i64, ptr %slot30, align 8
  store i64 %v341, ptr %slot55, align 8
  %v342 = load i64, ptr %slot55, align 8
  %v343 = load i64, ptr %slot51, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v342, i64 %v343) nomerge, !dbg !116
  br label %bb_rcslotdone33
bb_rcslotdone33:
  %v344 = load i64, ptr %slot14, align 8
  store i64 %v344, ptr %slot56, align 8
  %v345 = load i64, ptr %slot16, align 8
  store i64 %v345, ptr %slot57, align 8
  %v346 = load i64, ptr %slot57, align 8
  %v347 = load i64, ptr %slot56, align 8
  %p348 = inttoptr i64 %v346 to ptr
  %p349 = inttoptr i64 %v347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p349, ptr %p348, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot8, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 2, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot12, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %ld354 = load i32, ptr %p353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld354, ptr %slot58, align 8
  %v355 = load i32, ptr %slot58, align 8
  %v356 = load i64, ptr %slot8, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i32 %v355, ptr %p357, align 4, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot11, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i32 0, ptr %p359, align 4, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot7, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i32 1, ptr %p361, align 4, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot56, align 8
  %v363 = load i64, ptr %slot20, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot23, align 8
  store i64 %v365, ptr %slot59, align 8
  %v366 = load i64, ptr %slot59, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 0, ptr %p367, align 8, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot59, align 8
  %p370 = inttoptr i64 %v368 to ptr
  %gep371 = getelementptr i8, ptr %p370, i64 8
  %op369 = ptrtoint ptr %gep371 to i64
  store i64 %op369, ptr %slot60, align 8
  %v372 = load i64, ptr %slot60, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 0, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot59, align 8
  %p376 = inttoptr i64 %v374 to ptr
  %gep377 = getelementptr i8, ptr %p376, i64 16
  %op375 = ptrtoint ptr %gep377 to i64
  store i64 %op375, ptr %slot61, align 8
  %v378 = load i64, ptr %slot61, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 0, ptr %p379, align 8, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot59, align 8
  %p382 = inttoptr i64 %v380 to ptr
  %gep383 = getelementptr i8, ptr %p382, i64 24
  %op381 = ptrtoint ptr %gep383 to i64
  store i64 %op381, ptr %slot62, align 8
  %v384 = load i64, ptr %slot62, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 0, ptr %p385, align 8, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot59, align 8
  %p388 = inttoptr i64 %v386 to ptr
  %gep389 = getelementptr i8, ptr %p388, i64 32
  %op387 = ptrtoint ptr %gep389 to i64
  store i64 %op387, ptr %slot63, align 8
  %v390 = load i64, ptr %slot63, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 0, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot59, align 8
  %p394 = inttoptr i64 %v392 to ptr
  %gep395 = getelementptr i8, ptr %p394, i64 40
  %op393 = ptrtoint ptr %gep395 to i64
  store i64 %op393, ptr %slot64, align 8
  %v396 = load i64, ptr %slot64, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 0, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot59, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i32 0, ptr %p399, align 4, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot13, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i32 1, ptr %p401, align 4, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot20, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot65, align 8
  %v405 = load i64, ptr %slot59, align 8
  %p407 = inttoptr i64 %v405 to ptr
  %gep408 = getelementptr i8, ptr %p407, i64 8
  %op406 = ptrtoint ptr %gep408 to i64
  store i64 %op406, ptr %slot66, align 8
  %v409 = load i64, ptr %slot31, align 8
  store i64 %v409, ptr %slot67, align 8
  %v410 = load i64, ptr %slot20, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i64, ptr %p411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld412, ptr %slot68, align 8
  %v413 = load i64, ptr %slot16, align 8
  store i64 %v413, ptr %slot69, align 8
  %v414 = load i64, ptr %slot31, align 8
  store i64 %v414, ptr %slot70, align 8
  %v415 = load i64, ptr %slot30, align 8
  %v416 = load i64, ptr %slot69, align 8
  %v417 = load i64, ptr %slot68, align 8
  %v418 = load i64, ptr %slot70, align 8
  %cv419 = trunc i64 %v418 to i32
  %call420 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v415, i64 %v416, i64 %v417, i32 %cv419) nomerge, !dbg !118
  store i32 %call420, ptr %slot71, align 8
  %v421 = load i32, ptr %slot71, align 8
  %cv422 = zext i32 %v421 to i64
  %cond423 = icmp ne i64 %cv422, 0
  br i1 %cond423, label %bb_rcsuccess63, label %bb_rcfailure63
bb_rcfailure63:
  %v424 = load i64, ptr %slot30, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %call426 = call i32 @myl_rc_take_failure(ptr %p425) nomerge, !dbg !118
  store i32 %call426, ptr %slot72, align 8
  %v427 = load i64, ptr %slot1, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %v429 = load i32, ptr %slot72, align 8
  %call430 = call i32 @myl_qbe_rc_status(ptr %p428, i32 %v429) nomerge, !dbg !118
  store i32 %call430, ptr %slot73, align 8
  br label %bb_failure
bb_rcsuccess63:
  %v431 = load i64, ptr %slot7, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i32 0, ptr %p432, align 4, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot12, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i32 2, ptr %p434, align 4, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot11, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i32 1, ptr %p436, align 4, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot16, align 8
  store i64 %v437, ptr %slot74, align 8
  %v438 = load i64, ptr %slot74, align 8
  %v439 = load i64, ptr %slot66, align 8
  %p440 = inttoptr i64 %v438 to ptr
  %p441 = inttoptr i64 %v439 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p441, ptr %p440, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot11, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i32 0, ptr %p443, align 4, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot59, align 8
  %v445 = load i64, ptr %slot20, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 %v444, ptr %p446, align 8, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot20, align 8
  %p448 = inttoptr i64 %v447 to ptr
  %ld449 = load i64, ptr %p448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld449, ptr %slot75, align 8
  %v450 = load i64, ptr %slot14, align 8
  store i64 %v450, ptr %slot76, align 8
  %v451 = load i64, ptr %slot75, align 8
  %v452 = load i64, ptr %slot76, align 8
  %p453 = inttoptr i64 %v451 to ptr
  %p454 = inttoptr i64 %v452 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p454, ptr %p453, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot8, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i32 2, ptr %p456, align 4, !alias.scope !3, !noalias !4
  %v457 = load i64, ptr %slot7, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i32 1, ptr %p458, align 4, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot76, align 8
  %v460 = load i64, ptr %slot20, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 %v459, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot20, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot77, align 8
  %v465 = load i64, ptr %slot20, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %ld467 = load i64, ptr %p466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld467, ptr %slot78, align 8
  %v468 = load i64, ptr %slot16, align 8
  store i64 %v468, ptr %slot79, align 8
  %v469 = load i64, ptr %slot31, align 8
  store i64 %v469, ptr %slot80, align 8
  %v470 = load i64, ptr %slot30, align 8
  %v471 = load i64, ptr %slot79, align 8
  %v472 = load i64, ptr %slot78, align 8
  %v473 = load i64, ptr %slot80, align 8
  %cv474 = trunc i64 %v473 to i32
  %call475 = call i32 @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_take(i64 %v470, i64 %v471, i64 %v472, i32 %cv474) nomerge, !dbg !120
  store i32 %call475, ptr %slot81, align 8
  %v476 = load i32, ptr %slot81, align 8
  %cv477 = zext i32 %v476 to i64
  %cond478 = icmp ne i64 %cv477, 0
  br i1 %cond478, label %bb_rcsuccess80, label %bb_rcfailure80
bb_rcfailure80:
  %v479 = load i64, ptr %slot30, align 8
  %p480 = inttoptr i64 %v479 to ptr
  %call481 = call i32 @myl_rc_take_failure(ptr %p480) nomerge, !dbg !120
  store i32 %call481, ptr %slot82, align 8
  %v482 = load i64, ptr %slot1, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %v484 = load i32, ptr %slot82, align 8
  %call485 = call i32 @myl_qbe_rc_status(ptr %p483, i32 %v484) nomerge, !dbg !120
  store i32 %call485, ptr %slot83, align 8
  br label %bb_failure
bb_rcsuccess80:
  %v486 = load i64, ptr %slot7, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 0, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot12, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i32 2, ptr %p489, align 4, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot11, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i32 1, ptr %p491, align 4, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot16, align 8
  store i64 %v492, ptr %slot84, align 8
  %v493 = load i64, ptr %slot11, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i32 0, ptr %p494, align 4, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot7, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i32, ptr %p496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld497, ptr %slot85, align 8
  %v498 = load i32, ptr %slot85, align 8
  %cv499 = zext i32 %v498 to i64
  %cond500 = icmp ne i64 %cv499, 0
  br i1 %cond500, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v501 = load i64, ptr %slot7, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i32 0, ptr %p502, align 4, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot14, align 8
  store i64 %v503, ptr %slot86, align 8
  %v504 = load i64, ptr %slot8, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i32, ptr %p505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld506, ptr %slot87, align 8
  %v507 = load i32, ptr %slot87, align 8
  %op508 = and i32 %v507, 28
  store i32 %op508, ptr %slot88, align 8
  %v509 = load i32, ptr %slot88, align 8
  %cv510 = zext i32 %v509 to i64
  %cond511 = icmp ne i64 %cv510, 0
  br i1 %cond511, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v512 = load i64, ptr %slot30, align 8
  store i64 %v512, ptr %slot89, align 8
  %v513 = load i64, ptr %slot89, align 8
  %v514 = load i64, ptr %slot86, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v513, i64 %v514) nomerge, !dbg !120
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v515 = load i64, ptr %slot30, align 8
  store i64 %v515, ptr %slot90, align 8
  %v516 = load i64, ptr %slot90, align 8
  %v517 = load i64, ptr %slot86, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v516, i64 %v517) nomerge, !dbg !120
  br label %bb_rcslotdone90
bb_rcslotdone90:
  %v518 = load i64, ptr %slot84, align 8
  %p519 = inttoptr i64 %v518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p519, i64 48, i1 false)
  ret void
bb_i8:
  %v520 = load i64, ptr %slot17, align 8
  %p521 = inttoptr i64 %v520 to ptr
  %ld522 = load i64, ptr %p521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld522, ptr %slot91, align 8
  %v523 = load i64, ptr %slot91, align 8
  %v524 = load i64, ptr %slot20, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot17, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot92, align 8
  %v529 = load i64, ptr %slot92, align 8
  %v530 = load i64, ptr %slot24, align 8
  %p531 = inttoptr i64 %v529 to ptr
  %p532 = inttoptr i64 %v530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p532, ptr %p531, i64 312, i1 false), !alias.scope !10000000
  %v533 = load i64, ptr %slot24, align 8
  %v534 = load i64, ptr %slot21, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot21, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot93, align 8
  %v539 = load i64, ptr %slot1, align 8
  %v540 = load i64, ptr %slot93, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult95, i64 %v539, i64 %v540) nomerge, !dbg !122
  %addr541 = ptrtoint ptr %callresult95 to i64
  store i64 %addr541, ptr %slot94, align 8
  %v542 = load i64, ptr %slot94, align 8
  %v543 = load i64, ptr %slot21, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i64 %v542, ptr %p544, align 8, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot21, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot96, align 8
  %v548 = load i64, ptr %slot16, align 8
  store i64 %v548, ptr %slot97, align 8
  %v549 = load i64, ptr %slot30, align 8
  %v550 = load i64, ptr %slot97, align 8
  %v551 = load i64, ptr %slot96, align 8
  %call552 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v549, i64 %v550, i64 %v551) nomerge, !dbg !122
  store i32 %call552, ptr %slot98, align 8
  %v553 = load i32, ptr %slot98, align 8
  %cv554 = zext i32 %v553 to i64
  %cond555 = icmp ne i64 %cv554, 0
  br i1 %cond555, label %bb_rcsuccess150, label %bb_rcfailure150
bb_rcfailure150:
  %v556 = load i64, ptr %slot30, align 8
  %p557 = inttoptr i64 %v556 to ptr
  %call558 = call i32 @myl_rc_take_failure(ptr %p557) nomerge, !dbg !122
  store i32 %call558, ptr %slot99, align 8
  %v559 = load i64, ptr %slot1, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %v561 = load i32, ptr %slot99, align 8
  %call562 = call i32 @myl_qbe_rc_status(ptr %p560, i32 %v561) nomerge, !dbg !122
  store i32 %call562, ptr %slot100, align 8
  br label %bb_failure
bb_rcsuccess150:
  %v563 = load i64, ptr %slot12, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 2, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot12, align 8
  %p566 = inttoptr i64 %v565 to ptr
  store i32 16, ptr %p566, align 4, !alias.scope !3, !noalias !4
  %v567 = load i64, ptr %slot11, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 1, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot9, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i32, ptr %p570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld571, ptr %slot101, align 8
  %v572 = load i32, ptr %slot101, align 8
  %cv573 = zext i32 %v572 to i64
  %cond574 = icmp ne i64 %cv573, 0
  br i1 %cond574, label %bb_rcslotdrop158, label %bb_rcslotdone158
bb_rcslotdrop158:
  %v575 = load i64, ptr %slot9, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 0, ptr %p576, align 4, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot15, align 8
  store i64 %v577, ptr %slot102, align 8
  %v578 = load i64, ptr %slot10, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i32, ptr %p579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld580, ptr %slot103, align 8
  %v581 = load i32, ptr %slot103, align 8
  %op582 = and i32 %v581, 28
  store i32 %op582, ptr %slot104, align 8
  %v583 = load i32, ptr %slot104, align 8
  %cv584 = zext i32 %v583 to i64
  %cond585 = icmp ne i64 %cv584, 0
  br i1 %cond585, label %bb_rcslotrole158, label %bb_rcslotowner158
bb_rcslotrole158:
  %v586 = load i64, ptr %slot30, align 8
  store i64 %v586, ptr %slot105, align 8
  %v587 = load i64, ptr %slot105, align 8
  %v588 = load i64, ptr %slot102, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v587, i64 %v588) nomerge, !dbg !122
  br label %bb_rcslotdone158
bb_rcslotowner158:
  %v589 = load i64, ptr %slot30, align 8
  store i64 %v589, ptr %slot106, align 8
  %v590 = load i64, ptr %slot106, align 8
  %v591 = load i64, ptr %slot102, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v590, i64 %v591) nomerge, !dbg !122
  br label %bb_rcslotdone158
bb_rcslotdone158:
  %v592 = load i64, ptr %slot15, align 8
  store i64 %v592, ptr %slot107, align 8
  %v593 = load i64, ptr %slot16, align 8
  store i64 %v593, ptr %slot108, align 8
  %v594 = load i64, ptr %slot108, align 8
  %v595 = load i64, ptr %slot107, align 8
  %p596 = inttoptr i64 %v594 to ptr
  %p597 = inttoptr i64 %v595 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p597, ptr %p596, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot10, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i32 2, ptr %p599, align 4, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot12, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i32, ptr %p601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld602, ptr %slot109, align 8
  %v603 = load i32, ptr %slot109, align 8
  %v604 = load i64, ptr %slot10, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 %v603, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot11, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i32 0, ptr %p607, align 4, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot9, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 1, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot107, align 8
  %v611 = load i64, ptr %slot21, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i64 %v610, ptr %p612, align 8, !alias.scope !3, !noalias !4
  %v613 = load i64, ptr %slot19, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %ld615 = load i64, ptr %p614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld615, ptr %slot110, align 8
  %v616 = load i64, ptr %slot110, align 8
  %v617 = load i64, ptr %slot22, align 8
  %p618 = inttoptr i64 %v617 to ptr
  store i64 %v616, ptr %p618, align 8, !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot20, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld621, ptr %slot111, align 8
  %v622 = load i64, ptr %slot21, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i64, ptr %p623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld624, ptr %slot112, align 8
  %v625 = load i64, ptr %slot22, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i64, ptr %p626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld627, ptr %slot113, align 8
  %v628 = load i64, ptr %slot1, align 8
  %v629 = load i64, ptr %slot111, align 8
  %v630 = load i64, ptr %slot112, align 8
  %v631 = load i64, ptr %slot113, align 8
  %call632 = call i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64 %v628, i64 %v629, i64 %v630, i64 %v631) nomerge, !dbg !124
  store i8 %call632, ptr %callresult115, align 1
  %addr633 = ptrtoint ptr %callresult115 to i64
  store i64 %addr633, ptr %slot114, align 8
  %v634 = load i64, ptr %slot114, align 8
  %v635 = load i64, ptr %slot20, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i64 %v634, ptr %p636, align 8, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot7, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i32, ptr %p638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld639, ptr %slot116, align 8
  %v640 = load i32, ptr %slot116, align 8
  %cv641 = zext i32 %v640 to i64
  %cond642 = icmp ne i64 %cv641, 0
  br i1 %cond642, label %bb_rcslotdrop180, label %bb_rcslotdone180
bb_rcslotdrop180:
  %v643 = load i64, ptr %slot7, align 8
  %p644 = inttoptr i64 %v643 to ptr
  store i32 0, ptr %p644, align 4, !alias.scope !3, !noalias !4
  %v645 = load i64, ptr %slot14, align 8
  store i64 %v645, ptr %slot117, align 8
  %v646 = load i64, ptr %slot8, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %ld648 = load i32, ptr %p647, align 4, !alias.scope !3, !noalias !4
  store i32 %ld648, ptr %slot118, align 8
  %v649 = load i32, ptr %slot118, align 8
  %op650 = and i32 %v649, 28
  store i32 %op650, ptr %slot119, align 8
  %v651 = load i32, ptr %slot119, align 8
  %cv652 = zext i32 %v651 to i64
  %cond653 = icmp ne i64 %cv652, 0
  br i1 %cond653, label %bb_rcslotrole180, label %bb_rcslotowner180
bb_rcslotrole180:
  %v654 = load i64, ptr %slot30, align 8
  store i64 %v654, ptr %slot120, align 8
  %v655 = load i64, ptr %slot120, align 8
  %v656 = load i64, ptr %slot117, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v655, i64 %v656) nomerge, !dbg !124
  br label %bb_rcslotdone180
bb_rcslotowner180:
  %v657 = load i64, ptr %slot30, align 8
  store i64 %v657, ptr %slot121, align 8
  %v658 = load i64, ptr %slot121, align 8
  %v659 = load i64, ptr %slot117, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v658, i64 %v659) nomerge, !dbg !124
  br label %bb_rcslotdone180
bb_rcslotdone180:
  %v660 = load i64, ptr %slot9, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %ld662 = load i32, ptr %p661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld662, ptr %slot122, align 8
  %v663 = load i32, ptr %slot122, align 8
  %cv664 = zext i32 %v663 to i64
  %cond665 = icmp ne i64 %cv664, 0
  br i1 %cond665, label %bb_rcslotdrop189, label %bb_rcslotdone189
bb_rcslotdrop189:
  %v666 = load i64, ptr %slot9, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i32 0, ptr %p667, align 4, !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot15, align 8
  store i64 %v668, ptr %slot123, align 8
  %v669 = load i64, ptr %slot10, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %ld671 = load i32, ptr %p670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld671, ptr %slot124, align 8
  %v672 = load i32, ptr %slot124, align 8
  %op673 = and i32 %v672, 28
  store i32 %op673, ptr %slot125, align 8
  %v674 = load i32, ptr %slot125, align 8
  %cv675 = zext i32 %v674 to i64
  %cond676 = icmp ne i64 %cv675, 0
  br i1 %cond676, label %bb_rcslotrole189, label %bb_rcslotowner189
bb_rcslotrole189:
  %v677 = load i64, ptr %slot30, align 8
  store i64 %v677, ptr %slot126, align 8
  %v678 = load i64, ptr %slot126, align 8
  %v679 = load i64, ptr %slot123, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v678, i64 %v679) nomerge, !dbg !124
  br label %bb_rcslotdone189
bb_rcslotowner189:
  %v680 = load i64, ptr %slot30, align 8
  store i64 %v680, ptr %slot127, align 8
  %v681 = load i64, ptr %slot127, align 8
  %v682 = load i64, ptr %slot123, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v681, i64 %v682) nomerge, !dbg !124
  br label %bb_rcslotdone189
bb_rcslotdone189:
  %v683 = load i64, ptr %slot29, align 8
  store i64 %v683, ptr %slot128, align 8
  %v684 = load i64, ptr %slot128, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i64 0, ptr %p685, align 8, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot128, align 8
  %p688 = inttoptr i64 %v686 to ptr
  %gep689 = getelementptr i8, ptr %p688, i64 8
  %op687 = ptrtoint ptr %gep689 to i64
  store i64 %op687, ptr %slot129, align 8
  %v690 = load i64, ptr %slot129, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i64 0, ptr %p691, align 8, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot128, align 8
  %p694 = inttoptr i64 %v692 to ptr
  %gep695 = getelementptr i8, ptr %p694, i64 16
  %op693 = ptrtoint ptr %gep695 to i64
  store i64 %op693, ptr %slot130, align 8
  %v696 = load i64, ptr %slot130, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 0, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot128, align 8
  %p700 = inttoptr i64 %v698 to ptr
  %gep701 = getelementptr i8, ptr %p700, i64 24
  %op699 = ptrtoint ptr %gep701 to i64
  store i64 %op699, ptr %slot131, align 8
  %v702 = load i64, ptr %slot131, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i64 0, ptr %p703, align 8, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot128, align 8
  %p706 = inttoptr i64 %v704 to ptr
  %gep707 = getelementptr i8, ptr %p706, i64 32
  %op705 = ptrtoint ptr %gep707 to i64
  store i64 %op705, ptr %slot132, align 8
  %v708 = load i64, ptr %slot132, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i64 0, ptr %p709, align 8, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot128, align 8
  %p712 = inttoptr i64 %v710 to ptr
  %gep713 = getelementptr i8, ptr %p712, i64 40
  %op711 = ptrtoint ptr %gep713 to i64
  store i64 %op711, ptr %slot133, align 8
  %v714 = load i64, ptr %slot133, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i64 0, ptr %p715, align 8, !alias.scope !3, !noalias !4
  %v716 = load i64, ptr %slot128, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i32 1, ptr %p717, align 4, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot13, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i32 1, ptr %p719, align 4, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot20, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i64, ptr %p721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld722, ptr %slot134, align 8
  %v723 = load i64, ptr %slot128, align 8
  %p725 = inttoptr i64 %v723 to ptr
  %gep726 = getelementptr i8, ptr %p725, i64 8
  %op724 = ptrtoint ptr %gep726 to i64
  store i64 %op724, ptr %slot135, align 8
  %v727 = load i64, ptr %slot31, align 8
  store i64 %v727, ptr %slot136, align 8
  %v728 = load i64, ptr %slot128, align 8
  %v729 = load i64, ptr %slot20, align 8
  %p730 = inttoptr i64 %v729 to ptr
  store i64 %v728, ptr %p730, align 8, !alias.scope !3, !noalias !4
  %p731 = inttoptr i64 ptrtoint (ptr @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p731, i64 13) "call-inline-cost"="0", !dbg !126
  %v732 = load i64, ptr %slot20, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot137, align 8
  %v735 = load i64, ptr %slot14, align 8
  store i64 %v735, ptr %slot138, align 8
  %v736 = load i64, ptr %slot137, align 8
  %v737 = load i64, ptr %slot138, align 8
  %p738 = inttoptr i64 %v736 to ptr
  %p739 = inttoptr i64 %v737 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p739, ptr %p738, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot8, align 8
  %p741 = inttoptr i64 %v740 to ptr
  store i32 2, ptr %p741, align 4, !alias.scope !3, !noalias !4
  %v742 = load i64, ptr %slot7, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i32 1, ptr %p743, align 4, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot138, align 8
  %v745 = load i64, ptr %slot20, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i64 %v744, ptr %p746, align 8, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot20, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i64, ptr %p748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld749, ptr %slot139, align 8
  %v750 = load i64, ptr %slot20, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i64, ptr %p751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld752, ptr %slot140, align 8
  %v753 = load i64, ptr %slot16, align 8
  store i64 %v753, ptr %slot141, align 8
  %v754 = load i64, ptr %slot31, align 8
  store i64 %v754, ptr %slot142, align 8
  %v755 = load i64, ptr %slot30, align 8
  %v756 = load i64, ptr %slot141, align 8
  %v757 = load i64, ptr %slot140, align 8
  %v758 = load i64, ptr %slot142, align 8
  %cv759 = trunc i64 %v758 to i32
  %call760 = call i32 @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_take(i64 %v755, i64 %v756, i64 %v757, i32 %cv759) nomerge, !dbg !128
  store i32 %call760, ptr %slot143, align 8
  %v761 = load i32, ptr %slot143, align 8
  %cv762 = zext i32 %v761 to i64
  %cond763 = icmp ne i64 %cv762, 0
  br i1 %cond763, label %bb_rcsuccess253, label %bb_rcfailure253
bb_rcfailure253:
  %v764 = load i64, ptr %slot30, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %call766 = call i32 @myl_rc_take_failure(ptr %p765) nomerge, !dbg !128
  store i32 %call766, ptr %slot144, align 8
  %v767 = load i64, ptr %slot1, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %v769 = load i32, ptr %slot144, align 8
  %call770 = call i32 @myl_qbe_rc_status(ptr %p768, i32 %v769) nomerge, !dbg !128
  store i32 %call770, ptr %slot145, align 8
  br label %bb_failure
bb_rcsuccess253:
  %v771 = load i64, ptr %slot7, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i32 0, ptr %p772, align 4, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot12, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 2, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot11, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 1, ptr %p776, align 4, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot16, align 8
  store i64 %v777, ptr %slot146, align 8
  %v778 = load i64, ptr %slot11, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 0, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot7, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %ld782 = load i32, ptr %p781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld782, ptr %slot147, align 8
  %v783 = load i32, ptr %slot147, align 8
  %cv784 = zext i32 %v783 to i64
  %cond785 = icmp ne i64 %cv784, 0
  br i1 %cond785, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v786 = load i64, ptr %slot7, align 8
  %p787 = inttoptr i64 %v786 to ptr
  store i32 0, ptr %p787, align 4, !alias.scope !3, !noalias !4
  %v788 = load i64, ptr %slot14, align 8
  store i64 %v788, ptr %slot148, align 8
  %v789 = load i64, ptr %slot8, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %ld791 = load i32, ptr %p790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld791, ptr %slot149, align 8
  %v792 = load i32, ptr %slot149, align 8
  %op793 = and i32 %v792, 28
  store i32 %op793, ptr %slot150, align 8
  %v794 = load i32, ptr %slot150, align 8
  %cv795 = zext i32 %v794 to i64
  %cond796 = icmp ne i64 %cv795, 0
  br i1 %cond796, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v797 = load i64, ptr %slot30, align 8
  store i64 %v797, ptr %slot151, align 8
  %v798 = load i64, ptr %slot151, align 8
  %v799 = load i64, ptr %slot148, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v798, i64 %v799) nomerge, !dbg !128
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v800 = load i64, ptr %slot30, align 8
  store i64 %v800, ptr %slot152, align 8
  %v801 = load i64, ptr %slot152, align 8
  %v802 = load i64, ptr %slot148, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v801, i64 %v802) nomerge, !dbg !128
  br label %bb_rcslotdone263
bb_rcslotdone263:
  %v803 = load i64, ptr %slot146, align 8
  %p804 = inttoptr i64 %v803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p804, i64 48, i1 false)
  ret void
bb_failure:
  %v805 = load i64, ptr %slot6, align 8
  %p806 = inttoptr i64 %v805 to ptr
  call void @llvm.memset.p0.i64(ptr %p806, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v807 = load i64, ptr %slot6, align 8
  %p808 = inttoptr i64 %v807 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p808, i64 48, i1 false)
  ret void
bb_entry_failure:
  %v809 = load i64, ptr %slot6, align 8
  %p810 = inttoptr i64 %v809 to ptr
  call void @llvm.memset.p0.i64(ptr %p810, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v811 = load i64, ptr %slot6, align 8
  %p812 = inttoptr i64 %v811 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p812, i64 48, i1 false)
  ret void
}

@myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64, i64, i64, i64)
declare i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64, i64, i64)
declare void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare i32 @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42", linkageName: "myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 457482984292683143, i64 0, !"myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!122 = !DILocation(line: 11, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!124 = !DILocation(line: 13, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!128 = !DILocation(line: 15, column: 0, scope: !129)
