target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_97bbcd9db50097e4e50d294b15751b0838cf2924ba5c16b52b23aa9e3a225f04(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %callresult1049 = alloca [40 x i8], align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i32, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i32, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %callresult1189 = alloca [40 x i8], align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i32, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i32, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v1251 = load i64, ptr %slot1, align 8
  %op1252 = add i64 %v1251, 32
  store i64 %op1252, ptr %slot3, align 8
  %mem1253 = alloca i8, i64 40, align 8
  %ptr1254 = ptrtoint ptr %mem1253 to i64
  store i64 %ptr1254, ptr %slot4, align 8
  %mem1255 = alloca i8, i64 8, align 8
  %ptr1256 = ptrtoint ptr %mem1255 to i64
  store i64 %ptr1256, ptr %slot5, align 8
  %mem1257 = alloca i8, i64 8, align 8
  %ptr1258 = ptrtoint ptr %mem1257 to i64
  store i64 %ptr1258, ptr %slot6, align 8
  %mem1259 = alloca i8, i64 8, align 8
  %ptr1260 = ptrtoint ptr %mem1259 to i64
  store i64 %ptr1260, ptr %slot7, align 8
  %mem1261 = alloca i8, i64 8, align 8
  %ptr1262 = ptrtoint ptr %mem1261 to i64
  store i64 %ptr1262, ptr %slot8, align 8
  %mem1263 = alloca i8, i64 8, align 8
  %ptr1264 = ptrtoint ptr %mem1263 to i64
  store i64 %ptr1264, ptr %slot9, align 8
  %mem1265 = alloca i8, i64 8, align 8
  %ptr1266 = ptrtoint ptr %mem1265 to i64
  store i64 %ptr1266, ptr %slot10, align 8
  %mem1267 = alloca i8, i64 8, align 8
  %ptr1268 = ptrtoint ptr %mem1267 to i64
  store i64 %ptr1268, ptr %slot11, align 8
  %mem1269 = alloca i8, i64 8, align 8
  %ptr1270 = ptrtoint ptr %mem1269 to i64
  store i64 %ptr1270, ptr %slot12, align 8
  %mem1271 = alloca i8, i64 8, align 8
  %ptr1272 = ptrtoint ptr %mem1271 to i64
  store i64 %ptr1272, ptr %slot13, align 8
  %mem1273 = alloca i8, i64 8, align 8
  %ptr1274 = ptrtoint ptr %mem1273 to i64
  store i64 %ptr1274, ptr %slot14, align 8
  %mem1275 = alloca i8, i64 8, align 8
  %ptr1276 = ptrtoint ptr %mem1275 to i64
  store i64 %ptr1276, ptr %slot15, align 8
  %mem1277 = alloca i8, i64 8, align 8
  %ptr1278 = ptrtoint ptr %mem1277 to i64
  store i64 %ptr1278, ptr %slot16, align 8
  %mem1279 = alloca i8, i64 8, align 8
  %ptr1280 = ptrtoint ptr %mem1279 to i64
  store i64 %ptr1280, ptr %slot17, align 8
  %mem1281 = alloca i8, i64 8, align 8
  %ptr1282 = ptrtoint ptr %mem1281 to i64
  store i64 %ptr1282, ptr %slot18, align 8
  %mem1283 = alloca i8, i64 8, align 8
  %ptr1284 = ptrtoint ptr %mem1283 to i64
  store i64 %ptr1284, ptr %slot19, align 8
  %mem1285 = alloca i8, i64 8, align 8
  %ptr1286 = ptrtoint ptr %mem1285 to i64
  store i64 %ptr1286, ptr %slot20, align 8
  %mem1287 = alloca i8, i64 8, align 8
  %ptr1288 = ptrtoint ptr %mem1287 to i64
  store i64 %ptr1288, ptr %slot21, align 8
  %mem1289 = alloca i8, i64 8, align 8
  %ptr1290 = ptrtoint ptr %mem1289 to i64
  store i64 %ptr1290, ptr %slot22, align 8
  %mem1291 = alloca i8, i64 40, align 8
  %ptr1292 = ptrtoint ptr %mem1291 to i64
  store i64 %ptr1292, ptr %slot23, align 8
  %mem1293 = alloca i8, i64 32, align 8
  %ptr1294 = ptrtoint ptr %mem1293 to i64
  store i64 %ptr1294, ptr %slot24, align 8
  %mem1295 = alloca i8, i64 8, align 8
  %ptr1296 = ptrtoint ptr %mem1295 to i64
  store i64 %ptr1296, ptr %slot25, align 8
  %mem1297 = alloca i8, i64 8, align 8
  %ptr1298 = ptrtoint ptr %mem1297 to i64
  store i64 %ptr1298, ptr %slot26, align 8
  %mem1299 = alloca i8, i64 40, align 8
  %ptr1300 = ptrtoint ptr %mem1299 to i64
  store i64 %ptr1300, ptr %slot27, align 8
  %mem1301 = alloca i8, i64 8, align 8
  %ptr1302 = ptrtoint ptr %mem1301 to i64
  store i64 %ptr1302, ptr %slot28, align 8
  %mem1303 = alloca i8, i64 8, align 8
  %ptr1304 = ptrtoint ptr %mem1303 to i64
  store i64 %ptr1304, ptr %slot29, align 8
  %mem1305 = alloca i8, i64 8, align 8
  %ptr1306 = ptrtoint ptr %mem1305 to i64
  store i64 %ptr1306, ptr %slot30, align 8
  %mem1307 = alloca i8, i64 8, align 8
  %ptr1308 = ptrtoint ptr %mem1307 to i64
  store i64 %ptr1308, ptr %slot31, align 8
  %mem1309 = alloca i8, i64 32, align 8
  %ptr1310 = ptrtoint ptr %mem1309 to i64
  store i64 %ptr1310, ptr %slot32, align 8
  %mem1311 = alloca i8, i64 32, align 8
  %ptr1312 = ptrtoint ptr %mem1311 to i64
  store i64 %ptr1312, ptr %slot33, align 8
  %mem1313 = alloca i8, i64 32, align 8
  %ptr1314 = ptrtoint ptr %mem1313 to i64
  store i64 %ptr1314, ptr %slot34, align 8
  %mem1315 = alloca i8, i64 32, align 8
  %ptr1316 = ptrtoint ptr %mem1315 to i64
  store i64 %ptr1316, ptr %slot35, align 8
  %mem1317 = alloca i8, i64 32, align 8
  %ptr1318 = ptrtoint ptr %mem1317 to i64
  store i64 %ptr1318, ptr %slot36, align 8
  %mem1319 = alloca i8, i64 32, align 8
  %ptr1320 = ptrtoint ptr %mem1319 to i64
  store i64 %ptr1320, ptr %slot37, align 8
  %mem1321 = alloca i8, i64 8, align 8
  %ptr1322 = ptrtoint ptr %mem1321 to i64
  store i64 %ptr1322, ptr %slot38, align 8
  %mem1323 = alloca i8, i64 8, align 8
  %ptr1324 = ptrtoint ptr %mem1323 to i64
  store i64 %ptr1324, ptr %slot39, align 8
  %mem1325 = alloca i8, i64 32, align 8
  %ptr1326 = ptrtoint ptr %mem1325 to i64
  store i64 %ptr1326, ptr %slot40, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1327 = alloca i8, i64 8, align 8
  %ptr1328 = ptrtoint ptr %mem1327 to i64
  store i64 %ptr1328, ptr %slot41, align 8
  %v1329 = load i64, ptr %slot1, align 8
  %op1330 = add i64 %v1329, 64
  store i64 %op1330, ptr %slot42, align 8
  %v1331 = load i64, ptr %slot42, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %ld1333 = load i64, ptr %p1332, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1333, ptr %slot43, align 8
  %stack1334 = call ptr @llvm.stacksave()
  %stackaddr1335 = ptrtoint ptr %stack1334 to i64
  %v1336 = load i64, ptr %slot43, align 8
  %cmp1337 = icmp ult i64 %stackaddr1335, %v1336
  %cv1338 = zext i1 %cmp1337 to i64
  store i64 %cv1338, ptr %slot44, align 8
  %v1339 = load i64, ptr %slot44, align 8
  %cond1340 = icmp ne i64 %v1339, 0
  br i1 %cond1340, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1341 = load i64, ptr %slot1, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  call void @myl_qbe_fail_frame(ptr %p1342) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1343 = load i64, ptr %slot2, align 8
  %v1344 = load i64, ptr %slot28, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i64 %v1343, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot1, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %call1348 = call ptr @myl_qbe_heap(ptr %p1347) nomerge, !dbg !112
  %calladdr1349 = ptrtoint ptr %call1348 to i64
  store i64 %calladdr1349, ptr %slot45, align 8
  %v1350 = load i64, ptr %slot1, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %call1352 = call i64 @myl_qbe_region_mark(ptr %p1351) nomerge, !dbg !112
  store i64 %call1352, ptr %slot46, align 8
  %v1353 = load i64, ptr %slot5, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  store i32 0, ptr %p1354, align 4, !alias.scope !3, !noalias !4
  %v1355 = load i64, ptr %slot6, align 8
  %p1356 = inttoptr i64 %v1355 to ptr
  store i32 0, ptr %p1356, align 4, !alias.scope !3, !noalias !4
  %v1357 = load i64, ptr %slot7, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i32 0, ptr %p1358, align 4, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot8, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  store i32 0, ptr %p1360, align 4, !alias.scope !3, !noalias !4
  %v1361 = load i64, ptr %slot9, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  store i32 0, ptr %p1362, align 4, !alias.scope !3, !noalias !4
  %v1363 = load i64, ptr %slot10, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  store i32 0, ptr %p1364, align 4, !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot11, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 0, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot12, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i32 0, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  %v1369 = load i64, ptr %slot13, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  store i32 0, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot14, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 0, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot15, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 0, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot16, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 0, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot17, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i32 0, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  %v1379 = load i64, ptr %slot18, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i32 0, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot19, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  store i32 0, ptr %p1382, align 4, !alias.scope !3, !noalias !4
  %v1383 = load i64, ptr %slot20, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i32 0, ptr %p1384, align 4, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot21, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 0, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot22, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  store i32 0, ptr %p1388, align 4, !alias.scope !3, !noalias !4
  %v1389 = load i64, ptr %slot6, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  store i32 2, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  %v1391 = load i64, ptr %slot8, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  store i32 2, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  %v1393 = load i64, ptr %slot10, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i32 2, ptr %p1394, align 4, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot12, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i32 2, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot14, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 2, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot16, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  store i32 2, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1401 = load i64, ptr %slot28, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %ld1403 = load i64, ptr %p1402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1403, ptr %slot47, align 8
  %v1404 = load i64, ptr %slot47, align 8
  %v1405 = load i64, ptr %slot38, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i64 %v1404, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot38, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  %ld1409 = load i64, ptr %p1408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1409, ptr %slot48, align 8
  %v1410 = load i64, ptr %slot17, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  %ld1412 = load i32, ptr %p1411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1412, ptr %slot49, align 8
  %v1413 = load i64, ptr %slot18, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  %ld1415 = load i32, ptr %p1414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1415, ptr %slot50, align 8
  %v1416 = load i32, ptr %slot50, align 8
  %op1417 = and i32 %v1416, 24
  store i32 %op1417, ptr %slot50, align 8
  %v1418 = load i32, ptr %slot50, align 8
  %cmp1419 = icmp eq i32 %v1418, 0
  %cv1420 = zext i1 %cmp1419 to i32
  store i32 %cv1420, ptr %slot51, align 8
  %v1421 = load i32, ptr %slot49, align 8
  %v1422 = load i32, ptr %slot51, align 8
  %op1423 = and i32 %v1421, %v1422
  store i32 %op1423, ptr %slot52, align 8
  %v1424 = load i32, ptr %slot52, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rctake19, label %bb_rccopy19
bb_rctake19:
  %v1427 = load i64, ptr %slot27, align 8
  store i64 %v1427, ptr %slot53, align 8
  %v1428 = load i64, ptr %slot46, align 8
  store i64 %v1428, ptr %slot54, align 8
  %v1429 = load i64, ptr %slot48, align 8
  %v1430 = load i64, ptr %slot53, align 8
  %op1431 = sub i64 %v1429, %v1430
  store i64 %op1431, ptr %slot55, align 8
  %v1432 = load i64, ptr %slot53, align 8
  %v1433 = load i64, ptr %slot48, align 8
  %op1434 = sub i64 %v1432, %v1433
  store i64 %op1434, ptr %slot56, align 8
  %v1435 = load i64, ptr %slot55, align 8
  %cmp1436 = icmp ult i64 %v1435, 32
  %cv1437 = zext i1 %cmp1436 to i32
  store i32 %cv1437, ptr %slot57, align 8
  %v1438 = load i64, ptr %slot56, align 8
  %cmp1439 = icmp ult i64 %v1438, 32
  %cv1440 = zext i1 %cmp1439 to i32
  store i32 %cv1440, ptr %slot58, align 8
  %v1441 = load i32, ptr %slot57, align 8
  %v1442 = load i32, ptr %slot58, align 8
  %op1443 = or i32 %v1441, %v1442
  store i32 %op1443, ptr %slot59, align 8
  %v1444 = load i32, ptr %slot59, align 8
  %cv1445 = zext i32 %v1444 to i64
  %cond1446 = icmp ne i64 %cv1445, 0
  br i1 %cond1446, label %bb_rcmoveslow28, label %bb_rcmovecheck28
bb_rcmovecheck28:
  %v1447 = load i64, ptr %slot48, align 8
  %op1448 = add i64 %v1447, 0
  store i64 %op1448, ptr %slot60, align 8
  %v1449 = load i64, ptr %slot60, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i64, ptr %p1450, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1451, ptr %slot61, align 8
  %v1452 = load i64, ptr %slot61, align 8
  %cmp1453 = icmp ne i64 %v1452, 0
  %cv1454 = zext i1 %cmp1453 to i32
  store i32 %cv1454, ptr %slot62, align 8
  %v1455 = load i32, ptr %slot62, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcmoveheader36, label %bb_rcmovenext36
bb_rcmoveheader36:
  %v1458 = load i64, ptr %slot61, align 8
  %op1459 = sub i64 %v1458, 16
  store i64 %op1459, ptr %slot63, align 8
  %v1460 = load i64, ptr %slot61, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  %rgep1462 = getelementptr i8, ptr %p1461, i64 -16
  %ld1463 = load i64, ptr %rgep1462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1463, ptr %slot64, align 8
  %v1464 = load i64, ptr %slot64, align 8
  %op1465 = and i64 %v1464, 5764607523034234881
  store i64 %op1465, ptr %slot65, align 8
  %v1466 = load i64, ptr %slot65, align 8
  %cmp1467 = icmp ne i64 %v1466, 0
  %cv1468 = zext i1 %cmp1467 to i32
  store i32 %cv1468, ptr %slot66, align 8
  %v1469 = load i32, ptr %slot66, align 8
  %cv1470 = zext i32 %v1469 to i64
  %cond1471 = icmp ne i64 %cv1470, 0
  br i1 %cond1471, label %bb_rcmoveslow28, label %bb_rcmovenext36
bb_rcmovenext36:
  %v1472 = load i64, ptr %slot48, align 8
  %v1473 = load i64, ptr %slot53, align 8
  %p1474 = inttoptr i64 %v1472 to ptr
  %p1475 = inttoptr i64 %v1473 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1475, ptr %p1474, i64 32, i1 false), !alias.scope !10000000
  %v1476 = load i64, ptr %slot48, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  store i64 0, ptr %p1477, align 8, !alias.scope !4, !noalias !3
  %v1478 = load i64, ptr %slot48, align 8
  %op1479 = add i64 %v1478, 8
  store i64 %op1479, ptr %slot67, align 8
  %v1480 = load i64, ptr %slot67, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i64 0, ptr %p1481, align 8, !alias.scope !4, !noalias !3
  %v1482 = load i64, ptr %slot48, align 8
  %op1483 = add i64 %v1482, 16
  store i64 %op1483, ptr %slot68, align 8
  %v1484 = load i64, ptr %slot68, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  store i64 0, ptr %p1485, align 8, !alias.scope !4, !noalias !3
  %v1486 = load i64, ptr %slot48, align 8
  %op1487 = add i64 %v1486, 24
  store i64 %op1487, ptr %slot69, align 8
  %v1488 = load i64, ptr %slot69, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i64 0, ptr %p1489, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved28
bb_rcmoveslow28:
  %v1490 = load i64, ptr %slot45, align 8
  %v1491 = load i64, ptr %slot53, align 8
  %v1492 = load i64, ptr %slot48, align 8
  %v1493 = load i64, ptr %slot54, align 8
  %cv1494 = trunc i64 %v1493 to i32
  %call1495 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1490, i64 %v1491, i64 %v1492, i32 %cv1494) nomerge, !dbg !114
  store i32 %call1495, ptr %slot70, align 8
  %v1496 = load i32, ptr %slot70, align 8
  %cv1497 = zext i32 %v1496 to i64
  %cond1498 = icmp ne i64 %cv1497, 0
  br i1 %cond1498, label %bb_rcsuccess46, label %bb_rcfailure46
bb_rcfailure46:
  %v1499 = load i64, ptr %slot45, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %call1501 = call i32 @myl_rc_take_failure(ptr %p1500) nomerge, !dbg !114
  store i32 %call1501, ptr %slot71, align 8
  %v1502 = load i64, ptr %slot1, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %v1504 = load i32, ptr %slot71, align 8
  %call1505 = call i32 @myl_qbe_rc_status(ptr %p1503, i32 %v1504) nomerge, !dbg !114
  store i32 %call1505, ptr %slot72, align 8
  br label %bb_failure
bb_rcsuccess46:
  br label %bb_rcmoved28
bb_rcmoved28:
  %v1506 = load i64, ptr %slot17, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  store i32 0, ptr %p1507, align 4, !alias.scope !3, !noalias !4
  %v1508 = load i64, ptr %slot22, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i32 2, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot21, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  store i32 1, ptr %p1511, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared19
bb_rccopy19:
  %v1512 = load i64, ptr %slot27, align 8
  store i64 %v1512, ptr %slot73, align 8
  %v1513 = load i64, ptr %slot46, align 8
  store i64 %v1513, ptr %slot74, align 8
  %v1514 = load i64, ptr %slot45, align 8
  %v1515 = load i64, ptr %slot73, align 8
  %v1516 = load i64, ptr %slot48, align 8
  %v1517 = load i64, ptr %slot74, align 8
  %cv1518 = trunc i64 %v1517 to i32
  %call1519 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1514, i64 %v1515, i64 %v1516, i32 %cv1518) nomerge, !dbg !114
  store i32 %call1519, ptr %slot75, align 8
  %v1520 = load i32, ptr %slot75, align 8
  %cv1521 = zext i32 %v1520 to i64
  %cond1522 = icmp ne i64 %cv1521, 0
  br i1 %cond1522, label %bb_rcsuccess55, label %bb_rcfailure55
bb_rcfailure55:
  %v1523 = load i64, ptr %slot45, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  %call1525 = call i32 @myl_rc_take_failure(ptr %p1524) nomerge, !dbg !114
  store i32 %call1525, ptr %slot76, align 8
  %v1526 = load i64, ptr %slot1, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %v1528 = load i32, ptr %slot76, align 8
  %call1529 = call i32 @myl_qbe_rc_status(ptr %p1527, i32 %v1528) nomerge, !dbg !114
  store i32 %call1529, ptr %slot77, align 8
  br label %bb_failure
bb_rcsuccess55:
  %v1530 = load i64, ptr %slot22, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  store i32 2, ptr %p1531, align 4, !alias.scope !3, !noalias !4
  %v1532 = load i64, ptr %slot21, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i32 1, ptr %p1533, align 4, !alias.scope !3, !noalias !4
  %v1534 = load i64, ptr %slot17, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  %ld1536 = load i32, ptr %p1535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1536, ptr %slot78, align 8
  %v1537 = load i32, ptr %slot78, align 8
  %cv1538 = zext i32 %v1537 to i64
  %cond1539 = icmp ne i64 %cv1538, 0
  br i1 %cond1539, label %bb_rcslotdrop62, label %bb_rcslotdone62
bb_rcslotdrop62:
  %v1540 = load i64, ptr %slot17, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i32 0, ptr %p1541, align 4, !alias.scope !3, !noalias !4
  %v1542 = load i64, ptr %slot23, align 8
  store i64 %v1542, ptr %slot79, align 8
  %v1543 = load i64, ptr %slot18, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %ld1545 = load i32, ptr %p1544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1545, ptr %slot80, align 8
  %v1546 = load i32, ptr %slot80, align 8
  %op1547 = and i32 %v1546, 28
  store i32 %op1547, ptr %slot81, align 8
  %v1548 = load i32, ptr %slot81, align 8
  %cv1549 = zext i32 %v1548 to i64
  %cond1550 = icmp ne i64 %cv1549, 0
  br i1 %cond1550, label %bb_rcslotrole62, label %bb_rcslotowner62
bb_rcslotrole62:
  %v1551 = load i64, ptr %slot45, align 8
  store i64 %v1551, ptr %slot82, align 8
  %v1552 = load i64, ptr %slot82, align 8
  %v1553 = load i64, ptr %slot79, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1552, i64 %v1553) nomerge, !dbg !114
  br label %bb_rcslotdone62
bb_rcslotowner62:
  %v1554 = load i64, ptr %slot79, align 8
  %p1556 = inttoptr i64 %v1554 to ptr
  %gep1557 = getelementptr i8, ptr %p1556, i64 0
  %op1555 = ptrtoint ptr %gep1557 to i64
  store i64 %op1555, ptr %slot83, align 8
  %v1558 = load i64, ptr %slot45, align 8
  store i64 %v1558, ptr %slot84, align 8
  %v1559 = load i64, ptr %slot83, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot85, align 8
  %v1562 = load i64, ptr %slot85, align 8
  %cmp1563 = icmp ne i64 %v1562, 0
  %cv1564 = zext i1 %cmp1563 to i32
  store i32 %cv1564, ptr %slot86, align 8
  %v1565 = load i32, ptr %slot86, align 8
  %cv1566 = zext i32 %v1565 to i64
  %cond1567 = icmp ne i64 %cv1566, 0
  br i1 %cond1567, label %bb_rcgnn80, label %bb_rcgdone80
bb_rcgnn80:
  %v1568 = load i64, ptr %slot85, align 8
  %op1569 = sub i64 %v1568, 16
  store i64 %op1569, ptr %slot87, align 8
  %v1570 = load i64, ptr %slot85, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  %rgep1572 = getelementptr i8, ptr %p1571, i64 -16
  %ld1573 = load i64, ptr %rgep1572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1573, ptr %slot88, align 8
  %v1574 = load i64, ptr %slot88, align 8
  %op1575 = and i64 %v1574, 4611686018427387906
  store i64 %op1575, ptr %slot89, align 8
  %v1576 = load i64, ptr %slot89, align 8
  %cmp1577 = icmp ne i64 %v1576, 0
  %cv1578 = zext i1 %cmp1577 to i32
  store i32 %cv1578, ptr %slot90, align 8
  %v1579 = load i32, ptr %slot90, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcgclear80, label %bb_rcgcounted80
bb_rcgcounted80:
  %v1582 = load i64, ptr %slot85, align 8
  %op1583 = sub i64 %v1582, 32
  store i64 %op1583, ptr %slot91, align 8
  %v1584 = load i64, ptr %slot85, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %rgep1586 = getelementptr i8, ptr %p1585, i64 -32
  %ld1587 = load i64, ptr %rgep1586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1587, ptr %slot92, align 8
  %v1588 = load i64, ptr %slot92, align 8
  %op1589 = sub i64 %v1588, 1
  store i64 %op1589, ptr %slot93, align 8
  %v1590 = load i64, ptr %slot93, align 8
  %cmp1591 = icmp eq i64 %v1590, 0
  %cv1592 = zext i1 %cmp1591 to i32
  store i32 %cv1592, ptr %slot94, align 8
  %v1593 = load i32, ptr %slot94, align 8
  %cv1594 = zext i32 %v1593 to i64
  %cond1595 = icmp ne i64 %cv1594, 0
  br i1 %cond1595, label %bb_rcglast80, label %bb_rcgdec80
bb_rcglast80:
  %v1596 = load i64, ptr %slot85, align 8
  %op1597 = sub i64 %v1596, 24
  store i64 %op1597, ptr %slot95, align 8
  %v1598 = load i64, ptr %slot85, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  %rgep1600 = getelementptr i8, ptr %p1599, i64 -24
  %ld1601 = load i64, ptr %rgep1600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1601, ptr %slot96, align 8
  %v1602 = load i64, ptr %slot96, align 8
  %cmp1603 = icmp ne i64 %v1602, 0
  %cv1604 = zext i1 %cmp1603 to i32
  store i32 %cv1604, ptr %slot97, align 8
  %v1605 = load i32, ptr %slot97, align 8
  %cv1606 = zext i32 %v1605 to i64
  %cond1607 = icmp ne i64 %cv1606, 0
  br i1 %cond1607, label %bb_rcgdec80, label %bb_rcgslow80
bb_rcgslow80:
  %v1608 = load i64, ptr %slot84, align 8
  %v1609 = load i64, ptr %slot83, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1608, i64 %v1609) nomerge, !dbg !114
  br label %bb_rcgdone80
bb_rcgdec80:
  %v1610 = load i64, ptr %slot93, align 8
  %v1611 = load i64, ptr %slot85, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %rgep1613 = getelementptr i8, ptr %p1612, i64 -32
  store i64 %v1610, ptr %rgep1613, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear80
bb_rcgclear80:
  %v1614 = load i64, ptr %slot83, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i64 0, ptr %p1615, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone80
bb_rcgdone80:
  %v1616 = load i64, ptr %slot79, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i64 0, ptr %p1617, align 8, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot79, align 8
  %p1620 = inttoptr i64 %v1618 to ptr
  %gep1621 = getelementptr i8, ptr %p1620, i64 8
  %op1619 = ptrtoint ptr %gep1621 to i64
  store i64 %op1619, ptr %slot98, align 8
  %v1622 = load i64, ptr %slot98, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 0, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot79, align 8
  %p1626 = inttoptr i64 %v1624 to ptr
  %gep1627 = getelementptr i8, ptr %p1626, i64 16
  %op1625 = ptrtoint ptr %gep1627 to i64
  store i64 %op1625, ptr %slot99, align 8
  %v1628 = load i64, ptr %slot99, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i64 0, ptr %p1629, align 8, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot79, align 8
  %p1632 = inttoptr i64 %v1630 to ptr
  %gep1633 = getelementptr i8, ptr %p1632, i64 24
  %op1631 = ptrtoint ptr %gep1633 to i64
  store i64 %op1631, ptr %slot100, align 8
  %v1634 = load i64, ptr %slot100, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i64 0, ptr %p1635, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone62
bb_rcslotdone62:
  br label %bb_rcprepared19
bb_rcprepared19:
  %v1636 = load i64, ptr %slot5, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i32, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1638, ptr %slot101, align 8
  %v1639 = load i32, ptr %slot101, align 8
  %cv1640 = zext i32 %v1639 to i64
  %cond1641 = icmp ne i64 %cv1640, 0
  br i1 %cond1641, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v1642 = load i64, ptr %slot5, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 0, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot32, align 8
  store i64 %v1644, ptr %slot102, align 8
  %v1645 = load i64, ptr %slot6, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %ld1647 = load i32, ptr %p1646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1647, ptr %slot103, align 8
  %v1648 = load i32, ptr %slot103, align 8
  %op1649 = and i32 %v1648, 28
  store i32 %op1649, ptr %slot104, align 8
  %v1650 = load i32, ptr %slot104, align 8
  %cv1651 = zext i32 %v1650 to i64
  %cond1652 = icmp ne i64 %cv1651, 0
  br i1 %cond1652, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v1653 = load i64, ptr %slot45, align 8
  store i64 %v1653, ptr %slot105, align 8
  %v1654 = load i64, ptr %slot105, align 8
  %v1655 = load i64, ptr %slot102, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1654, i64 %v1655) nomerge, !dbg !114
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v1656 = load i64, ptr %slot102, align 8
  %p1658 = inttoptr i64 %v1656 to ptr
  %gep1659 = getelementptr i8, ptr %p1658, i64 0
  %op1657 = ptrtoint ptr %gep1659 to i64
  store i64 %op1657, ptr %slot106, align 8
  %v1660 = load i64, ptr %slot45, align 8
  store i64 %v1660, ptr %slot107, align 8
  %v1661 = load i64, ptr %slot106, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %ld1663 = load i64, ptr %p1662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1663, ptr %slot108, align 8
  %v1664 = load i64, ptr %slot108, align 8
  %cmp1665 = icmp ne i64 %v1664, 0
  %cv1666 = zext i1 %cmp1665 to i32
  store i32 %cv1666, ptr %slot109, align 8
  %v1667 = load i32, ptr %slot109, align 8
  %cv1668 = zext i32 %v1667 to i64
  %cond1669 = icmp ne i64 %cv1668, 0
  br i1 %cond1669, label %bb_rcgnn108, label %bb_rcgdone108
bb_rcgnn108:
  %v1670 = load i64, ptr %slot108, align 8
  %op1671 = sub i64 %v1670, 16
  store i64 %op1671, ptr %slot110, align 8
  %v1672 = load i64, ptr %slot108, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %rgep1674 = getelementptr i8, ptr %p1673, i64 -16
  %ld1675 = load i64, ptr %rgep1674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1675, ptr %slot111, align 8
  %v1676 = load i64, ptr %slot111, align 8
  %op1677 = and i64 %v1676, 4611686018427387906
  store i64 %op1677, ptr %slot112, align 8
  %v1678 = load i64, ptr %slot112, align 8
  %cmp1679 = icmp ne i64 %v1678, 0
  %cv1680 = zext i1 %cmp1679 to i32
  store i32 %cv1680, ptr %slot113, align 8
  %v1681 = load i32, ptr %slot113, align 8
  %cv1682 = zext i32 %v1681 to i64
  %cond1683 = icmp ne i64 %cv1682, 0
  br i1 %cond1683, label %bb_rcgclear108, label %bb_rcgcounted108
bb_rcgcounted108:
  %v1684 = load i64, ptr %slot108, align 8
  %op1685 = sub i64 %v1684, 32
  store i64 %op1685, ptr %slot114, align 8
  %v1686 = load i64, ptr %slot108, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %rgep1688 = getelementptr i8, ptr %p1687, i64 -32
  %ld1689 = load i64, ptr %rgep1688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1689, ptr %slot115, align 8
  %v1690 = load i64, ptr %slot115, align 8
  %op1691 = sub i64 %v1690, 1
  store i64 %op1691, ptr %slot116, align 8
  %v1692 = load i64, ptr %slot116, align 8
  %cmp1693 = icmp eq i64 %v1692, 0
  %cv1694 = zext i1 %cmp1693 to i32
  store i32 %cv1694, ptr %slot117, align 8
  %v1695 = load i32, ptr %slot117, align 8
  %cv1696 = zext i32 %v1695 to i64
  %cond1697 = icmp ne i64 %cv1696, 0
  br i1 %cond1697, label %bb_rcglast108, label %bb_rcgdec108
bb_rcglast108:
  %v1698 = load i64, ptr %slot108, align 8
  %op1699 = sub i64 %v1698, 24
  store i64 %op1699, ptr %slot118, align 8
  %v1700 = load i64, ptr %slot108, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  %rgep1702 = getelementptr i8, ptr %p1701, i64 -24
  %ld1703 = load i64, ptr %rgep1702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1703, ptr %slot119, align 8
  %v1704 = load i64, ptr %slot119, align 8
  %cmp1705 = icmp ne i64 %v1704, 0
  %cv1706 = zext i1 %cmp1705 to i32
  store i32 %cv1706, ptr %slot120, align 8
  %v1707 = load i32, ptr %slot120, align 8
  %cv1708 = zext i32 %v1707 to i64
  %cond1709 = icmp ne i64 %cv1708, 0
  br i1 %cond1709, label %bb_rcgdec108, label %bb_rcgslow108
bb_rcgslow108:
  %v1710 = load i64, ptr %slot107, align 8
  %v1711 = load i64, ptr %slot106, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1710, i64 %v1711) nomerge, !dbg !114
  br label %bb_rcgdone108
bb_rcgdec108:
  %v1712 = load i64, ptr %slot116, align 8
  %v1713 = load i64, ptr %slot108, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  %rgep1715 = getelementptr i8, ptr %p1714, i64 -32
  store i64 %v1712, ptr %rgep1715, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear108
bb_rcgclear108:
  %v1716 = load i64, ptr %slot106, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  store i64 0, ptr %p1717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone108
bb_rcgdone108:
  %v1718 = load i64, ptr %slot102, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  store i64 0, ptr %p1719, align 8, !alias.scope !3, !noalias !4
  %v1720 = load i64, ptr %slot102, align 8
  %p1722 = inttoptr i64 %v1720 to ptr
  %gep1723 = getelementptr i8, ptr %p1722, i64 8
  %op1721 = ptrtoint ptr %gep1723 to i64
  store i64 %op1721, ptr %slot121, align 8
  %v1724 = load i64, ptr %slot121, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i64 0, ptr %p1725, align 8, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot102, align 8
  %p1728 = inttoptr i64 %v1726 to ptr
  %gep1729 = getelementptr i8, ptr %p1728, i64 16
  %op1727 = ptrtoint ptr %gep1729 to i64
  store i64 %op1727, ptr %slot122, align 8
  %v1730 = load i64, ptr %slot122, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  store i64 0, ptr %p1731, align 8, !alias.scope !3, !noalias !4
  %v1732 = load i64, ptr %slot102, align 8
  %p1734 = inttoptr i64 %v1732 to ptr
  %gep1735 = getelementptr i8, ptr %p1734, i64 24
  %op1733 = ptrtoint ptr %gep1735 to i64
  store i64 %op1733, ptr %slot123, align 8
  %v1736 = load i64, ptr %slot123, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  store i64 0, ptr %p1737, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone90
bb_rcslotdone90:
  %v1738 = load i64, ptr %slot32, align 8
  store i64 %v1738, ptr %slot124, align 8
  %v1739 = load i64, ptr %slot27, align 8
  store i64 %v1739, ptr %slot125, align 8
  %v1740 = load i64, ptr %slot125, align 8
  %v1741 = load i64, ptr %slot124, align 8
  %p1742 = inttoptr i64 %v1740 to ptr
  %p1743 = inttoptr i64 %v1741 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1743, ptr %p1742, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1744 = load i64, ptr %slot21, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  store i32 0, ptr %p1745, align 4, !alias.scope !3, !noalias !4
  %v1746 = load i64, ptr %slot6, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  store i32 2, ptr %p1747, align 4, !alias.scope !3, !noalias !4
  %v1748 = load i64, ptr %slot22, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  %ld1750 = load i32, ptr %p1749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1750, ptr %slot126, align 8
  %v1751 = load i32, ptr %slot126, align 8
  %v1752 = load i64, ptr %slot6, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i32 %v1751, ptr %p1753, align 4, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot5, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 1, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot32, align 8
  %v1757 = load i64, ptr %slot38, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  store i64 %v1756, ptr %p1758, align 8, !alias.scope !3, !noalias !4
  %v1759 = load i64, ptr %slot38, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %ld1761 = load i64, ptr %p1760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1761, ptr %slot127, align 8
  %v1762 = load i64, ptr %slot17, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %ld1764 = load i32, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1764, ptr %slot128, align 8
  %v1765 = load i64, ptr %slot18, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %ld1767 = load i32, ptr %p1766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1767, ptr %slot129, align 8
  %v1768 = load i32, ptr %slot129, align 8
  %op1769 = and i32 %v1768, 24
  store i32 %op1769, ptr %slot129, align 8
  %v1770 = load i32, ptr %slot129, align 8
  %cmp1771 = icmp eq i32 %v1770, 0
  %cv1772 = zext i1 %cmp1771 to i32
  store i32 %cv1772, ptr %slot130, align 8
  %v1773 = load i32, ptr %slot128, align 8
  %v1774 = load i32, ptr %slot130, align 8
  %op1775 = and i32 %v1773, %v1774
  store i32 %op1775, ptr %slot131, align 8
  %v1776 = load i32, ptr %slot131, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rctake123, label %bb_rccopy123
bb_rctake123:
  %v1779 = load i64, ptr %slot27, align 8
  store i64 %v1779, ptr %slot132, align 8
  %v1780 = load i64, ptr %slot46, align 8
  store i64 %v1780, ptr %slot133, align 8
  %v1781 = load i64, ptr %slot127, align 8
  %v1782 = load i64, ptr %slot132, align 8
  %op1783 = sub i64 %v1781, %v1782
  store i64 %op1783, ptr %slot134, align 8
  %v1784 = load i64, ptr %slot132, align 8
  %v1785 = load i64, ptr %slot127, align 8
  %op1786 = sub i64 %v1784, %v1785
  store i64 %op1786, ptr %slot135, align 8
  %v1787 = load i64, ptr %slot134, align 8
  %cmp1788 = icmp ult i64 %v1787, 32
  %cv1789 = zext i1 %cmp1788 to i32
  store i32 %cv1789, ptr %slot136, align 8
  %v1790 = load i64, ptr %slot135, align 8
  %cmp1791 = icmp ult i64 %v1790, 32
  %cv1792 = zext i1 %cmp1791 to i32
  store i32 %cv1792, ptr %slot137, align 8
  %v1793 = load i32, ptr %slot136, align 8
  %v1794 = load i32, ptr %slot137, align 8
  %op1795 = or i32 %v1793, %v1794
  store i32 %op1795, ptr %slot138, align 8
  %v1796 = load i32, ptr %slot138, align 8
  %cv1797 = zext i32 %v1796 to i64
  %cond1798 = icmp ne i64 %cv1797, 0
  br i1 %cond1798, label %bb_rcmoveslow132, label %bb_rcmovecheck132
bb_rcmovecheck132:
  %v1799 = load i64, ptr %slot127, align 8
  %op1800 = add i64 %v1799, 0
  store i64 %op1800, ptr %slot139, align 8
  %v1801 = load i64, ptr %slot139, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  %ld1803 = load i64, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1803, ptr %slot140, align 8
  %v1804 = load i64, ptr %slot140, align 8
  %cmp1805 = icmp ne i64 %v1804, 0
  %cv1806 = zext i1 %cmp1805 to i32
  store i32 %cv1806, ptr %slot141, align 8
  %v1807 = load i32, ptr %slot141, align 8
  %cv1808 = zext i32 %v1807 to i64
  %cond1809 = icmp ne i64 %cv1808, 0
  br i1 %cond1809, label %bb_rcmoveheader140, label %bb_rcmovenext140
bb_rcmoveheader140:
  %v1810 = load i64, ptr %slot140, align 8
  %op1811 = sub i64 %v1810, 16
  store i64 %op1811, ptr %slot142, align 8
  %v1812 = load i64, ptr %slot140, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %rgep1814 = getelementptr i8, ptr %p1813, i64 -16
  %ld1815 = load i64, ptr %rgep1814, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1815, ptr %slot143, align 8
  %v1816 = load i64, ptr %slot143, align 8
  %op1817 = and i64 %v1816, 5764607523034234881
  store i64 %op1817, ptr %slot144, align 8
  %v1818 = load i64, ptr %slot144, align 8
  %cmp1819 = icmp ne i64 %v1818, 0
  %cv1820 = zext i1 %cmp1819 to i32
  store i32 %cv1820, ptr %slot145, align 8
  %v1821 = load i32, ptr %slot145, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcmoveslow132, label %bb_rcmovenext140
bb_rcmovenext140:
  %v1824 = load i64, ptr %slot127, align 8
  %v1825 = load i64, ptr %slot132, align 8
  %p1826 = inttoptr i64 %v1824 to ptr
  %p1827 = inttoptr i64 %v1825 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1827, ptr %p1826, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1828 = load i64, ptr %slot127, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i64 0, ptr %p1829, align 8, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot127, align 8
  %op1831 = add i64 %v1830, 8
  store i64 %op1831, ptr %slot146, align 8
  %v1832 = load i64, ptr %slot146, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  store i64 0, ptr %p1833, align 8, !alias.scope !3, !noalias !4
  %v1834 = load i64, ptr %slot127, align 8
  %op1835 = add i64 %v1834, 16
  store i64 %op1835, ptr %slot147, align 8
  %v1836 = load i64, ptr %slot147, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i64 0, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  %v1838 = load i64, ptr %slot127, align 8
  %op1839 = add i64 %v1838, 24
  store i64 %op1839, ptr %slot148, align 8
  %v1840 = load i64, ptr %slot148, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i64 0, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved132
bb_rcmoveslow132:
  %v1842 = load i64, ptr %slot45, align 8
  %v1843 = load i64, ptr %slot132, align 8
  %v1844 = load i64, ptr %slot127, align 8
  %v1845 = load i64, ptr %slot133, align 8
  %cv1846 = trunc i64 %v1845 to i32
  %call1847 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1842, i64 %v1843, i64 %v1844, i32 %cv1846) nomerge, !dbg !116
  store i32 %call1847, ptr %slot149, align 8
  %v1848 = load i32, ptr %slot149, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcsuccess150, label %bb_rcfailure150
bb_rcfailure150:
  %v1851 = load i64, ptr %slot45, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  %call1853 = call i32 @myl_rc_take_failure(ptr %p1852) nomerge, !dbg !116
  store i32 %call1853, ptr %slot150, align 8
  %v1854 = load i64, ptr %slot1, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %v1856 = load i32, ptr %slot150, align 8
  %call1857 = call i32 @myl_qbe_rc_status(ptr %p1855, i32 %v1856) nomerge, !dbg !116
  store i32 %call1857, ptr %slot151, align 8
  br label %bb_failure
bb_rcsuccess150:
  br label %bb_rcmoved132
bb_rcmoved132:
  %v1858 = load i64, ptr %slot17, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  store i32 0, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  %v1860 = load i64, ptr %slot22, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  store i32 2, ptr %p1861, align 4, !alias.scope !3, !noalias !4
  %v1862 = load i64, ptr %slot21, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i32 1, ptr %p1863, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared123
bb_rccopy123:
  %v1864 = load i64, ptr %slot27, align 8
  store i64 %v1864, ptr %slot152, align 8
  %v1865 = load i64, ptr %slot46, align 8
  store i64 %v1865, ptr %slot153, align 8
  %v1866 = load i64, ptr %slot45, align 8
  %v1867 = load i64, ptr %slot152, align 8
  %v1868 = load i64, ptr %slot127, align 8
  %v1869 = load i64, ptr %slot153, align 8
  %cv1870 = trunc i64 %v1869 to i32
  %call1871 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1866, i64 %v1867, i64 %v1868, i32 %cv1870) nomerge, !dbg !116
  store i32 %call1871, ptr %slot154, align 8
  %v1872 = load i32, ptr %slot154, align 8
  %cv1873 = zext i32 %v1872 to i64
  %cond1874 = icmp ne i64 %cv1873, 0
  br i1 %cond1874, label %bb_rcsuccess159, label %bb_rcfailure159
bb_rcfailure159:
  %v1875 = load i64, ptr %slot45, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %call1877 = call i32 @myl_rc_take_failure(ptr %p1876) nomerge, !dbg !116
  store i32 %call1877, ptr %slot155, align 8
  %v1878 = load i64, ptr %slot1, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %v1880 = load i32, ptr %slot155, align 8
  %call1881 = call i32 @myl_qbe_rc_status(ptr %p1879, i32 %v1880) nomerge, !dbg !116
  store i32 %call1881, ptr %slot156, align 8
  br label %bb_failure
bb_rcsuccess159:
  %v1882 = load i64, ptr %slot22, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  store i32 2, ptr %p1883, align 4, !alias.scope !3, !noalias !4
  %v1884 = load i64, ptr %slot21, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 1, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot17, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  %ld1888 = load i32, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1888, ptr %slot157, align 8
  %v1889 = load i32, ptr %slot157, align 8
  %cv1890 = zext i32 %v1889 to i64
  %cond1891 = icmp ne i64 %cv1890, 0
  br i1 %cond1891, label %bb_rcslotdrop166, label %bb_rcslotdone166
bb_rcslotdrop166:
  %v1892 = load i64, ptr %slot17, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  store i32 0, ptr %p1893, align 4, !alias.scope !3, !noalias !4
  %v1894 = load i64, ptr %slot23, align 8
  store i64 %v1894, ptr %slot158, align 8
  %v1895 = load i64, ptr %slot18, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  %ld1897 = load i32, ptr %p1896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1897, ptr %slot159, align 8
  %v1898 = load i32, ptr %slot159, align 8
  %op1899 = and i32 %v1898, 28
  store i32 %op1899, ptr %slot160, align 8
  %v1900 = load i32, ptr %slot160, align 8
  %cv1901 = zext i32 %v1900 to i64
  %cond1902 = icmp ne i64 %cv1901, 0
  br i1 %cond1902, label %bb_rcslotrole166, label %bb_rcslotowner166
bb_rcslotrole166:
  %v1903 = load i64, ptr %slot45, align 8
  store i64 %v1903, ptr %slot161, align 8
  %v1904 = load i64, ptr %slot161, align 8
  %v1905 = load i64, ptr %slot158, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1904, i64 %v1905) nomerge, !dbg !116
  br label %bb_rcslotdone166
bb_rcslotowner166:
  %v1906 = load i64, ptr %slot158, align 8
  %p1908 = inttoptr i64 %v1906 to ptr
  %gep1909 = getelementptr i8, ptr %p1908, i64 0
  %op1907 = ptrtoint ptr %gep1909 to i64
  store i64 %op1907, ptr %slot162, align 8
  %v1910 = load i64, ptr %slot45, align 8
  store i64 %v1910, ptr %slot163, align 8
  %v1911 = load i64, ptr %slot162, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %ld1913 = load i64, ptr %p1912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1913, ptr %slot164, align 8
  %v1914 = load i64, ptr %slot164, align 8
  %cmp1915 = icmp ne i64 %v1914, 0
  %cv1916 = zext i1 %cmp1915 to i32
  store i32 %cv1916, ptr %slot165, align 8
  %v1917 = load i32, ptr %slot165, align 8
  %cv1918 = zext i32 %v1917 to i64
  %cond1919 = icmp ne i64 %cv1918, 0
  br i1 %cond1919, label %bb_rcgnn184, label %bb_rcgdone184
bb_rcgnn184:
  %v1920 = load i64, ptr %slot164, align 8
  %op1921 = sub i64 %v1920, 16
  store i64 %op1921, ptr %slot166, align 8
  %v1922 = load i64, ptr %slot164, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %rgep1924 = getelementptr i8, ptr %p1923, i64 -16
  %ld1925 = load i64, ptr %rgep1924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1925, ptr %slot167, align 8
  %v1926 = load i64, ptr %slot167, align 8
  %op1927 = and i64 %v1926, 4611686018427387906
  store i64 %op1927, ptr %slot168, align 8
  %v1928 = load i64, ptr %slot168, align 8
  %cmp1929 = icmp ne i64 %v1928, 0
  %cv1930 = zext i1 %cmp1929 to i32
  store i32 %cv1930, ptr %slot169, align 8
  %v1931 = load i32, ptr %slot169, align 8
  %cv1932 = zext i32 %v1931 to i64
  %cond1933 = icmp ne i64 %cv1932, 0
  br i1 %cond1933, label %bb_rcgclear184, label %bb_rcgcounted184
bb_rcgcounted184:
  %v1934 = load i64, ptr %slot164, align 8
  %op1935 = sub i64 %v1934, 32
  store i64 %op1935, ptr %slot170, align 8
  %v1936 = load i64, ptr %slot164, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  %rgep1938 = getelementptr i8, ptr %p1937, i64 -32
  %ld1939 = load i64, ptr %rgep1938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1939, ptr %slot171, align 8
  %v1940 = load i64, ptr %slot171, align 8
  %op1941 = sub i64 %v1940, 1
  store i64 %op1941, ptr %slot172, align 8
  %v1942 = load i64, ptr %slot172, align 8
  %cmp1943 = icmp eq i64 %v1942, 0
  %cv1944 = zext i1 %cmp1943 to i32
  store i32 %cv1944, ptr %slot173, align 8
  %v1945 = load i32, ptr %slot173, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcglast184, label %bb_rcgdec184
bb_rcglast184:
  %v1948 = load i64, ptr %slot164, align 8
  %op1949 = sub i64 %v1948, 24
  store i64 %op1949, ptr %slot174, align 8
  %v1950 = load i64, ptr %slot164, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %rgep1952 = getelementptr i8, ptr %p1951, i64 -24
  %ld1953 = load i64, ptr %rgep1952, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1953, ptr %slot175, align 8
  %v1954 = load i64, ptr %slot175, align 8
  %cmp1955 = icmp ne i64 %v1954, 0
  %cv1956 = zext i1 %cmp1955 to i32
  store i32 %cv1956, ptr %slot176, align 8
  %v1957 = load i32, ptr %slot176, align 8
  %cv1958 = zext i32 %v1957 to i64
  %cond1959 = icmp ne i64 %cv1958, 0
  br i1 %cond1959, label %bb_rcgdec184, label %bb_rcgslow184
bb_rcgslow184:
  %v1960 = load i64, ptr %slot163, align 8
  %v1961 = load i64, ptr %slot162, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1960, i64 %v1961) nomerge, !dbg !116
  br label %bb_rcgdone184
bb_rcgdec184:
  %v1962 = load i64, ptr %slot172, align 8
  %v1963 = load i64, ptr %slot164, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %rgep1965 = getelementptr i8, ptr %p1964, i64 -32
  store i64 %v1962, ptr %rgep1965, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear184
bb_rcgclear184:
  %v1966 = load i64, ptr %slot162, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  store i64 0, ptr %p1967, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone184
bb_rcgdone184:
  %v1968 = load i64, ptr %slot158, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  store i64 0, ptr %p1969, align 8, !alias.scope !3, !noalias !4
  %v1970 = load i64, ptr %slot158, align 8
  %p1972 = inttoptr i64 %v1970 to ptr
  %gep1973 = getelementptr i8, ptr %p1972, i64 8
  %op1971 = ptrtoint ptr %gep1973 to i64
  store i64 %op1971, ptr %slot177, align 8
  %v1974 = load i64, ptr %slot177, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i64 0, ptr %p1975, align 8, !alias.scope !3, !noalias !4
  %v1976 = load i64, ptr %slot158, align 8
  %p1978 = inttoptr i64 %v1976 to ptr
  %gep1979 = getelementptr i8, ptr %p1978, i64 16
  %op1977 = ptrtoint ptr %gep1979 to i64
  store i64 %op1977, ptr %slot178, align 8
  %v1980 = load i64, ptr %slot178, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i64 0, ptr %p1981, align 8, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot158, align 8
  %p1984 = inttoptr i64 %v1982 to ptr
  %gep1985 = getelementptr i8, ptr %p1984, i64 24
  %op1983 = ptrtoint ptr %gep1985 to i64
  store i64 %op1983, ptr %slot179, align 8
  %v1986 = load i64, ptr %slot179, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  store i64 0, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone166
bb_rcslotdone166:
  br label %bb_rcprepared123
bb_rcprepared123:
  %v1988 = load i64, ptr %slot7, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %ld1990 = load i32, ptr %p1989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1990, ptr %slot180, align 8
  %v1991 = load i32, ptr %slot180, align 8
  %cv1992 = zext i32 %v1991 to i64
  %cond1993 = icmp ne i64 %cv1992, 0
  br i1 %cond1993, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v1994 = load i64, ptr %slot7, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i32 0, ptr %p1995, align 4, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot33, align 8
  store i64 %v1996, ptr %slot181, align 8
  %v1997 = load i64, ptr %slot8, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %ld1999 = load i32, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1999, ptr %slot182, align 8
  %v2000 = load i32, ptr %slot182, align 8
  %op2001 = and i32 %v2000, 28
  store i32 %op2001, ptr %slot183, align 8
  %v2002 = load i32, ptr %slot183, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v2005 = load i64, ptr %slot45, align 8
  store i64 %v2005, ptr %slot184, align 8
  %v2006 = load i64, ptr %slot184, align 8
  %v2007 = load i64, ptr %slot181, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2006, i64 %v2007) nomerge, !dbg !116
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v2008 = load i64, ptr %slot181, align 8
  %p2010 = inttoptr i64 %v2008 to ptr
  %gep2011 = getelementptr i8, ptr %p2010, i64 0
  %op2009 = ptrtoint ptr %gep2011 to i64
  store i64 %op2009, ptr %slot185, align 8
  %v2012 = load i64, ptr %slot45, align 8
  store i64 %v2012, ptr %slot186, align 8
  %v2013 = load i64, ptr %slot185, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %ld2015 = load i64, ptr %p2014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2015, ptr %slot187, align 8
  %v2016 = load i64, ptr %slot187, align 8
  %cmp2017 = icmp ne i64 %v2016, 0
  %cv2018 = zext i1 %cmp2017 to i32
  store i32 %cv2018, ptr %slot188, align 8
  %v2019 = load i32, ptr %slot188, align 8
  %cv2020 = zext i32 %v2019 to i64
  %cond2021 = icmp ne i64 %cv2020, 0
  br i1 %cond2021, label %bb_rcgnn212, label %bb_rcgdone212
bb_rcgnn212:
  %v2022 = load i64, ptr %slot187, align 8
  %op2023 = sub i64 %v2022, 16
  store i64 %op2023, ptr %slot189, align 8
  %v2024 = load i64, ptr %slot187, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %rgep2026 = getelementptr i8, ptr %p2025, i64 -16
  %ld2027 = load i64, ptr %rgep2026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2027, ptr %slot190, align 8
  %v2028 = load i64, ptr %slot190, align 8
  %op2029 = and i64 %v2028, 4611686018427387906
  store i64 %op2029, ptr %slot191, align 8
  %v2030 = load i64, ptr %slot191, align 8
  %cmp2031 = icmp ne i64 %v2030, 0
  %cv2032 = zext i1 %cmp2031 to i32
  store i32 %cv2032, ptr %slot192, align 8
  %v2033 = load i32, ptr %slot192, align 8
  %cv2034 = zext i32 %v2033 to i64
  %cond2035 = icmp ne i64 %cv2034, 0
  br i1 %cond2035, label %bb_rcgclear212, label %bb_rcgcounted212
bb_rcgcounted212:
  %v2036 = load i64, ptr %slot187, align 8
  %op2037 = sub i64 %v2036, 32
  store i64 %op2037, ptr %slot193, align 8
  %v2038 = load i64, ptr %slot187, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  %rgep2040 = getelementptr i8, ptr %p2039, i64 -32
  %ld2041 = load i64, ptr %rgep2040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2041, ptr %slot194, align 8
  %v2042 = load i64, ptr %slot194, align 8
  %op2043 = sub i64 %v2042, 1
  store i64 %op2043, ptr %slot195, align 8
  %v2044 = load i64, ptr %slot195, align 8
  %cmp2045 = icmp eq i64 %v2044, 0
  %cv2046 = zext i1 %cmp2045 to i32
  store i32 %cv2046, ptr %slot196, align 8
  %v2047 = load i32, ptr %slot196, align 8
  %cv2048 = zext i32 %v2047 to i64
  %cond2049 = icmp ne i64 %cv2048, 0
  br i1 %cond2049, label %bb_rcglast212, label %bb_rcgdec212
bb_rcglast212:
  %v2050 = load i64, ptr %slot187, align 8
  %op2051 = sub i64 %v2050, 24
  store i64 %op2051, ptr %slot197, align 8
  %v2052 = load i64, ptr %slot187, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %rgep2054 = getelementptr i8, ptr %p2053, i64 -24
  %ld2055 = load i64, ptr %rgep2054, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2055, ptr %slot198, align 8
  %v2056 = load i64, ptr %slot198, align 8
  %cmp2057 = icmp ne i64 %v2056, 0
  %cv2058 = zext i1 %cmp2057 to i32
  store i32 %cv2058, ptr %slot199, align 8
  %v2059 = load i32, ptr %slot199, align 8
  %cv2060 = zext i32 %v2059 to i64
  %cond2061 = icmp ne i64 %cv2060, 0
  br i1 %cond2061, label %bb_rcgdec212, label %bb_rcgslow212
bb_rcgslow212:
  %v2062 = load i64, ptr %slot186, align 8
  %v2063 = load i64, ptr %slot185, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2062, i64 %v2063) nomerge, !dbg !116
  br label %bb_rcgdone212
bb_rcgdec212:
  %v2064 = load i64, ptr %slot195, align 8
  %v2065 = load i64, ptr %slot187, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  %rgep2067 = getelementptr i8, ptr %p2066, i64 -32
  store i64 %v2064, ptr %rgep2067, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear212
bb_rcgclear212:
  %v2068 = load i64, ptr %slot185, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  store i64 0, ptr %p2069, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone212
bb_rcgdone212:
  %v2070 = load i64, ptr %slot181, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i64 0, ptr %p2071, align 8, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot181, align 8
  %p2074 = inttoptr i64 %v2072 to ptr
  %gep2075 = getelementptr i8, ptr %p2074, i64 8
  %op2073 = ptrtoint ptr %gep2075 to i64
  store i64 %op2073, ptr %slot200, align 8
  %v2076 = load i64, ptr %slot200, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i64 0, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot181, align 8
  %p2080 = inttoptr i64 %v2078 to ptr
  %gep2081 = getelementptr i8, ptr %p2080, i64 16
  %op2079 = ptrtoint ptr %gep2081 to i64
  store i64 %op2079, ptr %slot201, align 8
  %v2082 = load i64, ptr %slot201, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i64 0, ptr %p2083, align 8, !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot181, align 8
  %p2086 = inttoptr i64 %v2084 to ptr
  %gep2087 = getelementptr i8, ptr %p2086, i64 24
  %op2085 = ptrtoint ptr %gep2087 to i64
  store i64 %op2085, ptr %slot202, align 8
  %v2088 = load i64, ptr %slot202, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  store i64 0, ptr %p2089, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone194
bb_rcslotdone194:
  %v2090 = load i64, ptr %slot33, align 8
  store i64 %v2090, ptr %slot203, align 8
  %v2091 = load i64, ptr %slot27, align 8
  store i64 %v2091, ptr %slot204, align 8
  %v2092 = load i64, ptr %slot204, align 8
  %v2093 = load i64, ptr %slot203, align 8
  %p2094 = inttoptr i64 %v2092 to ptr
  %p2095 = inttoptr i64 %v2093 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2095, ptr %p2094, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot21, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 0, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot8, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  store i32 2, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  %v2100 = load i64, ptr %slot22, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %ld2102 = load i32, ptr %p2101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2102, ptr %slot205, align 8
  %v2103 = load i32, ptr %slot205, align 8
  %v2104 = load i64, ptr %slot8, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 %v2103, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot7, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 1, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot33, align 8
  %v2109 = load i64, ptr %slot38, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i64 %v2108, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot38, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot206, align 8
  %v2114 = load i64, ptr %slot206, align 8
  %op2115 = add i64 %v2114, 16
  store i64 %op2115, ptr %slot207, align 8
  %v2116 = load i64, ptr %slot207, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2118, ptr %slot208, align 8
  %v2119 = load i64, ptr %slot208, align 8
  %v2120 = load i64, ptr %slot38, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i64 %v2119, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot17, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i32, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2124, ptr %slot209, align 8
  %v2125 = load i32, ptr %slot209, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcslotdrop231, label %bb_rcslotdone231
bb_rcslotdrop231:
  %v2128 = load i64, ptr %slot17, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i32 0, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot23, align 8
  store i64 %v2130, ptr %slot210, align 8
  %v2131 = load i64, ptr %slot18, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i32, ptr %p2132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2133, ptr %slot211, align 8
  %v2134 = load i32, ptr %slot211, align 8
  %op2135 = and i32 %v2134, 28
  store i32 %op2135, ptr %slot212, align 8
  %v2136 = load i32, ptr %slot212, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcslotrole231, label %bb_rcslotowner231
bb_rcslotrole231:
  %v2139 = load i64, ptr %slot45, align 8
  store i64 %v2139, ptr %slot213, align 8
  %v2140 = load i64, ptr %slot213, align 8
  %v2141 = load i64, ptr %slot210, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2140, i64 %v2141) nomerge, !dbg !118
  br label %bb_rcslotdone231
bb_rcslotowner231:
  %v2142 = load i64, ptr %slot45, align 8
  store i64 %v2142, ptr %slot214, align 8
  %v2143 = load i64, ptr %slot214, align 8
  %v2144 = load i64, ptr %slot210, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2143, i64 %v2144) nomerge, !dbg !118
  br label %bb_rcslotdone231
bb_rcslotdone231:
  %v2145 = load i64, ptr %slot33, align 8
  %v2146 = load i64, ptr %slot39, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  store i64 %v2145, ptr %p2147, align 8, !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot39, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  %ld2150 = load i64, ptr %p2149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2150, ptr %slot215, align 8
  %v2151 = load i64, ptr %slot215, align 8
  %op2152 = add i64 %v2151, 0
  store i64 %op2152, ptr %slot216, align 8
  %v2153 = load i64, ptr %slot216, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i64, ptr %p2154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2155, ptr %slot217, align 8
  %v2156 = load i64, ptr %slot217, align 8
  %v2157 = load i64, ptr %slot39, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 %v2156, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot39, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %ld2161 = load i64, ptr %p2160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2161, ptr %slot218, align 8
  %v2162 = load i64, ptr %slot218, align 8
  %v2163 = load i64, ptr %slot26, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  store i64 %v2162, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  %v2165 = load i64, ptr %slot26, align 8
  store i64 %v2165, ptr %slot219, align 8
  %v2166 = load i64, ptr %slot27, align 8
  store i64 %v2166, ptr %slot220, align 8
  %v2167 = load i64, ptr %slot219, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %ld2169 = load i64, ptr %p2168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2169, ptr %slot221, align 8
  %v2170 = load i64, ptr %slot221, align 8
  %cmp2171 = icmp ne i64 %v2170, 0
  %cv2172 = zext i1 %cmp2171 to i32
  store i32 %cv2172, ptr %slot222, align 8
  %v2173 = load i32, ptr %slot222, align 8
  %cv2174 = zext i32 %v2173 to i64
  %cond2175 = icmp ne i64 %cv2174, 0
  br i1 %cond2175, label %bb_rcgnn245, label %bb_rcgstore245
bb_rcgnn245:
  %v2176 = load i64, ptr %slot221, align 8
  %op2177 = sub i64 %v2176, 16
  store i64 %op2177, ptr %slot223, align 8
  %v2178 = load i64, ptr %slot221, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %rgep2180 = getelementptr i8, ptr %p2179, i64 -16
  %ld2181 = load i64, ptr %rgep2180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2181, ptr %slot224, align 8
  %v2182 = load i64, ptr %slot224, align 8
  %op2183 = and i64 %v2182, 4611686018427387906
  store i64 %op2183, ptr %slot225, align 8
  %v2184 = load i64, ptr %slot225, align 8
  %cmp2185 = icmp ne i64 %v2184, 0
  %cv2186 = zext i1 %cmp2185 to i32
  store i32 %cv2186, ptr %slot226, align 8
  %v2187 = load i32, ptr %slot226, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcgstore245, label %bb_rcginc245
bb_rcginc245:
  %v2190 = load i64, ptr %slot221, align 8
  %op2191 = sub i64 %v2190, 24
  store i64 %op2191, ptr %slot227, align 8
  %v2192 = load i64, ptr %slot221, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %rgep2194 = getelementptr i8, ptr %p2193, i64 -24
  %ld2195 = load i64, ptr %rgep2194, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2195, ptr %slot228, align 8
  %v2196 = load i64, ptr %slot228, align 8
  %op2197 = add i64 %v2196, 1
  store i64 %op2197, ptr %slot229, align 8
  %v2198 = load i64, ptr %slot229, align 8
  %cmp2199 = icmp eq i64 %v2198, 0
  %cv2200 = zext i1 %cmp2199 to i32
  store i32 %cv2200, ptr %slot230, align 8
  %v2201 = load i32, ptr %slot230, align 8
  %cv2202 = zext i32 %v2201 to i64
  %cond2203 = icmp ne i64 %cv2202, 0
  br i1 %cond2203, label %bb_rcglimit245, label %bb_rcgcapacity245
bb_rcglimit245:
  %v2204 = load i64, ptr %slot1, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %call2206 = call i32 @myl_qbe_rc_status(ptr %p2205, i32 2) nomerge, !dbg !120
  store i32 %call2206, ptr %slot231, align 8
  br label %bb_failure
bb_rcgcapacity245:
  %v2207 = load i64, ptr %slot229, align 8
  %v2208 = load i64, ptr %slot221, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %rgep2210 = getelementptr i8, ptr %p2209, i64 -24
  store i64 %v2207, ptr %rgep2210, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore245
bb_rcgstore245:
  %v2211 = load i64, ptr %slot221, align 8
  %v2212 = load i64, ptr %slot220, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  store i64 %v2211, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  %v2214 = load i64, ptr %slot22, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  store i32 2, ptr %p2215, align 4, !alias.scope !3, !noalias !4
  %v2216 = load i64, ptr %slot22, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i32 16, ptr %p2217, align 4, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot21, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  store i32 1, ptr %p2219, align 4, !alias.scope !3, !noalias !4
  %v2220 = load i64, ptr %slot19, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %ld2222 = load i32, ptr %p2221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2222, ptr %slot232, align 8
  %v2223 = load i32, ptr %slot232, align 8
  %cv2224 = zext i32 %v2223 to i64
  %cond2225 = icmp ne i64 %cv2224, 0
  br i1 %cond2225, label %bb_rcslotdrop261, label %bb_rcslotdone261
bb_rcslotdrop261:
  %v2226 = load i64, ptr %slot19, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  store i32 0, ptr %p2227, align 4, !alias.scope !3, !noalias !4
  %v2228 = load i64, ptr %slot24, align 8
  store i64 %v2228, ptr %slot233, align 8
  %v2229 = load i64, ptr %slot20, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i32, ptr %p2230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2231, ptr %slot234, align 8
  %v2232 = load i32, ptr %slot234, align 8
  %op2233 = and i32 %v2232, 28
  store i32 %op2233, ptr %slot235, align 8
  %v2234 = load i32, ptr %slot235, align 8
  %cv2235 = zext i32 %v2234 to i64
  %cond2236 = icmp ne i64 %cv2235, 0
  br i1 %cond2236, label %bb_rcslotrole261, label %bb_rcslotowner261
bb_rcslotrole261:
  %v2237 = load i64, ptr %slot45, align 8
  store i64 %v2237, ptr %slot236, align 8
  %v2238 = load i64, ptr %slot236, align 8
  %v2239 = load i64, ptr %slot233, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2238, i64 %v2239) nomerge, !dbg !120
  br label %bb_rcslotdone261
bb_rcslotowner261:
  %v2240 = load i64, ptr %slot45, align 8
  store i64 %v2240, ptr %slot237, align 8
  %v2241 = load i64, ptr %slot237, align 8
  %v2242 = load i64, ptr %slot233, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2241, i64 %v2242) nomerge, !dbg !120
  br label %bb_rcslotdone261
bb_rcslotdone261:
  %v2243 = load i64, ptr %slot24, align 8
  store i64 %v2243, ptr %slot238, align 8
  %v2244 = load i64, ptr %slot27, align 8
  store i64 %v2244, ptr %slot239, align 8
  %v2245 = load i64, ptr %slot239, align 8
  %v2246 = load i64, ptr %slot238, align 8
  %p2247 = inttoptr i64 %v2245 to ptr
  %p2248 = inttoptr i64 %v2246 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2248, ptr %p2247, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2249 = load i64, ptr %slot20, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  store i32 2, ptr %p2250, align 4, !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot22, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %ld2253 = load i32, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2253, ptr %slot240, align 8
  %v2254 = load i32, ptr %slot240, align 8
  %v2255 = load i64, ptr %slot20, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i32 %v2254, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot21, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  store i32 0, ptr %p2258, align 4, !alias.scope !3, !noalias !4
  %v2259 = load i64, ptr %slot19, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i32 1, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot238, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %ld2263 = load i64, ptr %p2262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2263, ptr %slot241, align 8
  %v2264 = load i64, ptr %slot241, align 8
  %v2265 = load i64, ptr %slot39, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i64 %v2264, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot39, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2269, ptr %slot242, align 8
  %v2270 = load i64, ptr %slot242, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %ld2272 = load i64, ptr %p2271, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2272, ptr %slot243, align 8
  %v2273 = load i64, ptr %slot243, align 8
  %v2274 = load i64, ptr %slot39, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 %v2273, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot19, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i32, ptr %p2277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2278, ptr %slot244, align 8
  %v2279 = load i32, ptr %slot244, align 8
  %cv2280 = zext i32 %v2279 to i64
  %cond2281 = icmp ne i64 %cv2280, 0
  br i1 %cond2281, label %bb_rcslotdrop281, label %bb_rcslotdone281
bb_rcslotdrop281:
  %v2282 = load i64, ptr %slot19, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i32 0, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  %v2284 = load i64, ptr %slot24, align 8
  store i64 %v2284, ptr %slot245, align 8
  %v2285 = load i64, ptr %slot20, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i32, ptr %p2286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2287, ptr %slot246, align 8
  %v2288 = load i32, ptr %slot246, align 8
  %op2289 = and i32 %v2288, 28
  store i32 %op2289, ptr %slot247, align 8
  %v2290 = load i32, ptr %slot247, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcslotrole281, label %bb_rcslotowner281
bb_rcslotrole281:
  %v2293 = load i64, ptr %slot45, align 8
  store i64 %v2293, ptr %slot248, align 8
  %v2294 = load i64, ptr %slot245, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %ld2296 = load i64, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2296, ptr %slot249, align 8
  %v2297 = load i64, ptr %slot249, align 8
  %cmp2298 = icmp ne i64 %v2297, 0
  %cv2299 = zext i1 %cmp2298 to i32
  store i32 %cv2299, ptr %slot250, align 8
  %v2300 = load i32, ptr %slot250, align 8
  %cv2301 = zext i32 %v2300 to i64
  %cond2302 = icmp ne i64 %cv2301, 0
  br i1 %cond2302, label %bb_rcgnn297, label %bb_rcgdone297
bb_rcgnn297:
  %v2303 = load i64, ptr %slot249, align 8
  %op2304 = sub i64 %v2303, 16
  store i64 %op2304, ptr %slot251, align 8
  %v2305 = load i64, ptr %slot249, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %rgep2307 = getelementptr i8, ptr %p2306, i64 -16
  %ld2308 = load i64, ptr %rgep2307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2308, ptr %slot252, align 8
  %v2309 = load i64, ptr %slot252, align 8
  %op2310 = and i64 %v2309, 4611686018427387906
  store i64 %op2310, ptr %slot253, align 8
  %v2311 = load i64, ptr %slot253, align 8
  %cmp2312 = icmp ne i64 %v2311, 0
  %cv2313 = zext i1 %cmp2312 to i32
  store i32 %cv2313, ptr %slot254, align 8
  %v2314 = load i32, ptr %slot254, align 8
  %cv2315 = zext i32 %v2314 to i64
  %cond2316 = icmp ne i64 %cv2315, 0
  br i1 %cond2316, label %bb_rcgclear297, label %bb_rcgcounted297
bb_rcgcounted297:
  %v2317 = load i64, ptr %slot249, align 8
  %op2318 = sub i64 %v2317, 24
  store i64 %op2318, ptr %slot255, align 8
  %v2319 = load i64, ptr %slot249, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  %rgep2321 = getelementptr i8, ptr %p2320, i64 -24
  %ld2322 = load i64, ptr %rgep2321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2322, ptr %slot256, align 8
  %v2323 = load i64, ptr %slot256, align 8
  %op2324 = sub i64 %v2323, 1
  store i64 %op2324, ptr %slot257, align 8
  %v2325 = load i64, ptr %slot257, align 8
  %cmp2326 = icmp eq i64 %v2325, 0
  %cv2327 = zext i1 %cmp2326 to i32
  store i32 %cv2327, ptr %slot258, align 8
  %v2328 = load i32, ptr %slot258, align 8
  %cv2329 = zext i32 %v2328 to i64
  %cond2330 = icmp ne i64 %cv2329, 0
  br i1 %cond2330, label %bb_rcglast297, label %bb_rcgdec297
bb_rcglast297:
  %v2331 = load i64, ptr %slot249, align 8
  %op2332 = sub i64 %v2331, 32
  store i64 %op2332, ptr %slot259, align 8
  %v2333 = load i64, ptr %slot249, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %rgep2335 = getelementptr i8, ptr %p2334, i64 -32
  %ld2336 = load i64, ptr %rgep2335, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2336, ptr %slot260, align 8
  %v2337 = load i64, ptr %slot260, align 8
  %cmp2338 = icmp ne i64 %v2337, 0
  %cv2339 = zext i1 %cmp2338 to i32
  store i32 %cv2339, ptr %slot261, align 8
  %v2340 = load i32, ptr %slot261, align 8
  %cv2341 = zext i32 %v2340 to i64
  %cond2342 = icmp ne i64 %cv2341, 0
  br i1 %cond2342, label %bb_rcgdec297, label %bb_rcgslow297
bb_rcgslow297:
  %v2343 = load i64, ptr %slot248, align 8
  %v2344 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2343, i64 %v2344) nomerge, !dbg !122
  br label %bb_rcgdone297
bb_rcgdec297:
  %v2345 = load i64, ptr %slot257, align 8
  %v2346 = load i64, ptr %slot249, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %rgep2348 = getelementptr i8, ptr %p2347, i64 -24
  store i64 %v2345, ptr %rgep2348, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear297
bb_rcgclear297:
  %v2349 = load i64, ptr %slot245, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 0, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone297
bb_rcgdone297:
  br label %bb_rcslotdone281
bb_rcslotowner281:
  %v2351 = load i64, ptr %slot45, align 8
  store i64 %v2351, ptr %slot262, align 8
  %v2352 = load i64, ptr %slot245, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %ld2354 = load i64, ptr %p2353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2354, ptr %slot263, align 8
  %v2355 = load i64, ptr %slot263, align 8
  %cmp2356 = icmp ne i64 %v2355, 0
  %cv2357 = zext i1 %cmp2356 to i32
  store i32 %cv2357, ptr %slot264, align 8
  %v2358 = load i32, ptr %slot264, align 8
  %cv2359 = zext i32 %v2358 to i64
  %cond2360 = icmp ne i64 %cv2359, 0
  br i1 %cond2360, label %bb_rcgnn312, label %bb_rcgdone312
bb_rcgnn312:
  %v2361 = load i64, ptr %slot263, align 8
  %op2362 = sub i64 %v2361, 16
  store i64 %op2362, ptr %slot265, align 8
  %v2363 = load i64, ptr %slot263, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %rgep2365 = getelementptr i8, ptr %p2364, i64 -16
  %ld2366 = load i64, ptr %rgep2365, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2366, ptr %slot266, align 8
  %v2367 = load i64, ptr %slot266, align 8
  %op2368 = and i64 %v2367, 4611686018427387906
  store i64 %op2368, ptr %slot267, align 8
  %v2369 = load i64, ptr %slot267, align 8
  %cmp2370 = icmp ne i64 %v2369, 0
  %cv2371 = zext i1 %cmp2370 to i32
  store i32 %cv2371, ptr %slot268, align 8
  %v2372 = load i32, ptr %slot268, align 8
  %cv2373 = zext i32 %v2372 to i64
  %cond2374 = icmp ne i64 %cv2373, 0
  br i1 %cond2374, label %bb_rcgclear312, label %bb_rcgcounted312
bb_rcgcounted312:
  %v2375 = load i64, ptr %slot263, align 8
  %op2376 = sub i64 %v2375, 32
  store i64 %op2376, ptr %slot269, align 8
  %v2377 = load i64, ptr %slot263, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  %rgep2379 = getelementptr i8, ptr %p2378, i64 -32
  %ld2380 = load i64, ptr %rgep2379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2380, ptr %slot270, align 8
  %v2381 = load i64, ptr %slot270, align 8
  %op2382 = sub i64 %v2381, 1
  store i64 %op2382, ptr %slot271, align 8
  %v2383 = load i64, ptr %slot271, align 8
  %cmp2384 = icmp eq i64 %v2383, 0
  %cv2385 = zext i1 %cmp2384 to i32
  store i32 %cv2385, ptr %slot272, align 8
  %v2386 = load i32, ptr %slot272, align 8
  %cv2387 = zext i32 %v2386 to i64
  %cond2388 = icmp ne i64 %cv2387, 0
  br i1 %cond2388, label %bb_rcglast312, label %bb_rcgdec312
bb_rcglast312:
  %v2389 = load i64, ptr %slot263, align 8
  %op2390 = sub i64 %v2389, 24
  store i64 %op2390, ptr %slot273, align 8
  %v2391 = load i64, ptr %slot263, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  %rgep2393 = getelementptr i8, ptr %p2392, i64 -24
  %ld2394 = load i64, ptr %rgep2393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2394, ptr %slot274, align 8
  %v2395 = load i64, ptr %slot274, align 8
  %cmp2396 = icmp ne i64 %v2395, 0
  %cv2397 = zext i1 %cmp2396 to i32
  store i32 %cv2397, ptr %slot275, align 8
  %v2398 = load i32, ptr %slot275, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcgdec312, label %bb_rcgslow312
bb_rcgslow312:
  %v2401 = load i64, ptr %slot262, align 8
  %v2402 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2401, i64 %v2402) nomerge, !dbg !122
  br label %bb_rcgdone312
bb_rcgdec312:
  %v2403 = load i64, ptr %slot271, align 8
  %v2404 = load i64, ptr %slot263, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %rgep2406 = getelementptr i8, ptr %p2405, i64 -32
  store i64 %v2403, ptr %rgep2406, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear312
bb_rcgclear312:
  %v2407 = load i64, ptr %slot245, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  store i64 0, ptr %p2408, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone312
bb_rcgdone312:
  br label %bb_rcslotdone281
bb_rcslotdone281:
  %v2409 = load i64, ptr %slot39, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  %ld2411 = load i64, ptr %p2410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2411, ptr %slot276, align 8
  %v2412 = load i64, ptr %slot38, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %ld2414 = load i64, ptr %p2413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2414, ptr %slot277, align 8
  %v2415 = load i64, ptr %slot277, align 8
  %v2416 = load i64, ptr %slot276, align 8
  %cmp2417 = icmp sge i64 %v2415, %v2416
  %cv2418 = zext i1 %cmp2417 to i64
  store i64 %cv2418, ptr %slot278, align 8
  %v2419 = load i64, ptr %slot278, align 8
  %v2420 = load i64, ptr %slot38, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  store i64 %v2419, ptr %p2421, align 8, !alias.scope !3, !noalias !4
  br label %bb_i11
bb_i11:
  %v2422 = load i64, ptr %slot38, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %ld2424 = load i64, ptr %p2423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2424, ptr %slot279, align 8
  %v2425 = load i64, ptr %slot279, align 8
  %cond2426 = icmp ne i64 %v2425, 0
  br i1 %cond2426, label %bb_next320, label %bb_i14
bb_next320:
  %v2427 = load i64, ptr %slot38, align 8
  %p2428 = inttoptr i64 %v2427 to ptr
  store i64 0, ptr %p2428, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i14:
  %v2429 = load i64, ptr %slot32, align 8
  %v2430 = load i64, ptr %slot38, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  store i64 %v2429, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  %v2432 = load i64, ptr %slot38, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  %ld2434 = load i64, ptr %p2433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2434, ptr %slot280, align 8
  %v2435 = load i64, ptr %slot280, align 8
  %op2436 = add i64 %v2435, 0
  store i64 %op2436, ptr %slot281, align 8
  %v2437 = load i64, ptr %slot281, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i64, ptr %p2438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2439, ptr %slot282, align 8
  %v2440 = load i64, ptr %slot282, align 8
  %v2441 = load i64, ptr %slot38, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i64 %v2440, ptr %p2442, align 8, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot38, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %ld2445 = load i64, ptr %p2444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2445, ptr %slot283, align 8
  %v2446 = load i64, ptr %slot283, align 8
  %v2447 = load i64, ptr %slot25, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  store i64 %v2446, ptr %p2448, align 8, !alias.scope !3, !noalias !4
  %v2449 = load i64, ptr %slot25, align 8
  store i64 %v2449, ptr %slot284, align 8
  %v2450 = load i64, ptr %slot27, align 8
  store i64 %v2450, ptr %slot285, align 8
  %v2451 = load i64, ptr %slot284, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  %ld2453 = load i64, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2453, ptr %slot286, align 8
  %v2454 = load i64, ptr %slot286, align 8
  %cmp2455 = icmp ne i64 %v2454, 0
  %cv2456 = zext i1 %cmp2455 to i32
  store i32 %cv2456, ptr %slot287, align 8
  %v2457 = load i32, ptr %slot287, align 8
  %cv2458 = zext i32 %v2457 to i64
  %cond2459 = icmp ne i64 %cv2458, 0
  br i1 %cond2459, label %bb_rcgnn327, label %bb_rcgstore327
bb_rcgnn327:
  %v2460 = load i64, ptr %slot286, align 8
  %op2461 = sub i64 %v2460, 16
  store i64 %op2461, ptr %slot288, align 8
  %v2462 = load i64, ptr %slot286, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %rgep2464 = getelementptr i8, ptr %p2463, i64 -16
  %ld2465 = load i64, ptr %rgep2464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2465, ptr %slot289, align 8
  %v2466 = load i64, ptr %slot289, align 8
  %op2467 = and i64 %v2466, 4611686018427387906
  store i64 %op2467, ptr %slot290, align 8
  %v2468 = load i64, ptr %slot290, align 8
  %cmp2469 = icmp ne i64 %v2468, 0
  %cv2470 = zext i1 %cmp2469 to i32
  store i32 %cv2470, ptr %slot291, align 8
  %v2471 = load i32, ptr %slot291, align 8
  %cv2472 = zext i32 %v2471 to i64
  %cond2473 = icmp ne i64 %cv2472, 0
  br i1 %cond2473, label %bb_rcgstore327, label %bb_rcginc327
bb_rcginc327:
  %v2474 = load i64, ptr %slot286, align 8
  %op2475 = sub i64 %v2474, 24
  store i64 %op2475, ptr %slot292, align 8
  %v2476 = load i64, ptr %slot286, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %rgep2478 = getelementptr i8, ptr %p2477, i64 -24
  %ld2479 = load i64, ptr %rgep2478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2479, ptr %slot293, align 8
  %v2480 = load i64, ptr %slot293, align 8
  %op2481 = add i64 %v2480, 1
  store i64 %op2481, ptr %slot294, align 8
  %v2482 = load i64, ptr %slot294, align 8
  %cmp2483 = icmp eq i64 %v2482, 0
  %cv2484 = zext i1 %cmp2483 to i32
  store i32 %cv2484, ptr %slot295, align 8
  %v2485 = load i32, ptr %slot295, align 8
  %cv2486 = zext i32 %v2485 to i64
  %cond2487 = icmp ne i64 %cv2486, 0
  br i1 %cond2487, label %bb_rcglimit327, label %bb_rcgcapacity327
bb_rcglimit327:
  %v2488 = load i64, ptr %slot1, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  %call2490 = call i32 @myl_qbe_rc_status(ptr %p2489, i32 2) nomerge, !dbg !124
  store i32 %call2490, ptr %slot296, align 8
  br label %bb_failure
bb_rcgcapacity327:
  %v2491 = load i64, ptr %slot294, align 8
  %v2492 = load i64, ptr %slot286, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %rgep2494 = getelementptr i8, ptr %p2493, i64 -24
  store i64 %v2491, ptr %rgep2494, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore327
bb_rcgstore327:
  %v2495 = load i64, ptr %slot286, align 8
  %v2496 = load i64, ptr %slot285, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i64 %v2495, ptr %p2497, align 8, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot22, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  store i32 2, ptr %p2499, align 4, !alias.scope !3, !noalias !4
  %v2500 = load i64, ptr %slot22, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  store i32 16, ptr %p2501, align 4, !alias.scope !3, !noalias !4
  %v2502 = load i64, ptr %slot21, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  store i32 1, ptr %p2503, align 4, !alias.scope !3, !noalias !4
  %v2504 = load i64, ptr %slot17, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  %ld2506 = load i32, ptr %p2505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2506, ptr %slot297, align 8
  %v2507 = load i32, ptr %slot297, align 8
  %cv2508 = zext i32 %v2507 to i64
  %cond2509 = icmp ne i64 %cv2508, 0
  br i1 %cond2509, label %bb_rcslotdrop343, label %bb_rcslotdone343
bb_rcslotdrop343:
  %v2510 = load i64, ptr %slot17, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  store i32 0, ptr %p2511, align 4, !alias.scope !3, !noalias !4
  %v2512 = load i64, ptr %slot23, align 8
  store i64 %v2512, ptr %slot298, align 8
  %v2513 = load i64, ptr %slot18, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %ld2515 = load i32, ptr %p2514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2515, ptr %slot299, align 8
  %v2516 = load i32, ptr %slot299, align 8
  %op2517 = and i32 %v2516, 28
  store i32 %op2517, ptr %slot300, align 8
  %v2518 = load i32, ptr %slot300, align 8
  %cv2519 = zext i32 %v2518 to i64
  %cond2520 = icmp ne i64 %cv2519, 0
  br i1 %cond2520, label %bb_rcslotrole343, label %bb_rcslotowner343
bb_rcslotrole343:
  %v2521 = load i64, ptr %slot45, align 8
  store i64 %v2521, ptr %slot301, align 8
  %v2522 = load i64, ptr %slot301, align 8
  %v2523 = load i64, ptr %slot298, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2522, i64 %v2523) nomerge, !dbg !124
  br label %bb_rcslotdone343
bb_rcslotowner343:
  %v2524 = load i64, ptr %slot45, align 8
  store i64 %v2524, ptr %slot302, align 8
  %v2525 = load i64, ptr %slot302, align 8
  %v2526 = load i64, ptr %slot298, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2525, i64 %v2526) nomerge, !dbg !124
  br label %bb_rcslotdone343
bb_rcslotdone343:
  %v2527 = load i64, ptr %slot23, align 8
  store i64 %v2527, ptr %slot303, align 8
  %v2528 = load i64, ptr %slot27, align 8
  store i64 %v2528, ptr %slot304, align 8
  %v2529 = load i64, ptr %slot304, align 8
  %v2530 = load i64, ptr %slot303, align 8
  %p2531 = inttoptr i64 %v2529 to ptr
  %p2532 = inttoptr i64 %v2530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2532, ptr %p2531, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2533 = load i64, ptr %slot18, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  store i32 2, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  %v2535 = load i64, ptr %slot22, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  %ld2537 = load i32, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2537, ptr %slot305, align 8
  %v2538 = load i32, ptr %slot305, align 8
  %v2539 = load i64, ptr %slot18, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i32 %v2538, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  %v2541 = load i64, ptr %slot21, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  store i32 0, ptr %p2542, align 4, !alias.scope !3, !noalias !4
  %v2543 = load i64, ptr %slot17, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i32 1, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot303, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i64, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2547, ptr %slot306, align 8
  %v2548 = load i64, ptr %slot306, align 8
  %v2549 = load i64, ptr %slot38, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i64 %v2548, ptr %p2550, align 8, !alias.scope !3, !noalias !4
  %v2551 = load i64, ptr %slot32, align 8
  %v2552 = load i64, ptr %slot39, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  store i64 %v2551, ptr %p2553, align 8, !alias.scope !3, !noalias !4
  %v2554 = load i64, ptr %slot39, align 8
  %p2555 = inttoptr i64 %v2554 to ptr
  %ld2556 = load i64, ptr %p2555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2556, ptr %slot307, align 8
  %v2557 = load i64, ptr %slot307, align 8
  %op2558 = add i64 %v2557, 16
  store i64 %op2558, ptr %slot308, align 8
  %v2559 = load i64, ptr %slot308, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %ld2561 = load i64, ptr %p2560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2561, ptr %slot309, align 8
  %v2562 = load i64, ptr %slot309, align 8
  %v2563 = load i64, ptr %slot39, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  store i64 %v2562, ptr %p2564, align 8, !alias.scope !3, !noalias !4
  %v2565 = load i64, ptr %slot19, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  %ld2567 = load i32, ptr %p2566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2567, ptr %slot310, align 8
  %v2568 = load i32, ptr %slot310, align 8
  %cv2569 = zext i32 %v2568 to i64
  %cond2570 = icmp ne i64 %cv2569, 0
  br i1 %cond2570, label %bb_rcslotdrop364, label %bb_rcslotdone364
bb_rcslotdrop364:
  %v2571 = load i64, ptr %slot19, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i32 0, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot24, align 8
  store i64 %v2573, ptr %slot311, align 8
  %v2574 = load i64, ptr %slot20, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  %ld2576 = load i32, ptr %p2575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2576, ptr %slot312, align 8
  %v2577 = load i32, ptr %slot312, align 8
  %op2578 = and i32 %v2577, 28
  store i32 %op2578, ptr %slot313, align 8
  %v2579 = load i32, ptr %slot313, align 8
  %cv2580 = zext i32 %v2579 to i64
  %cond2581 = icmp ne i64 %cv2580, 0
  br i1 %cond2581, label %bb_rcslotrole364, label %bb_rcslotowner364
bb_rcslotrole364:
  %v2582 = load i64, ptr %slot45, align 8
  store i64 %v2582, ptr %slot314, align 8
  %v2583 = load i64, ptr %slot314, align 8
  %v2584 = load i64, ptr %slot311, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2583, i64 %v2584) nomerge, !dbg !126
  br label %bb_rcslotdone364
bb_rcslotowner364:
  %v2585 = load i64, ptr %slot45, align 8
  store i64 %v2585, ptr %slot315, align 8
  %v2586 = load i64, ptr %slot315, align 8
  %v2587 = load i64, ptr %slot311, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2586, i64 %v2587) nomerge, !dbg !126
  br label %bb_rcslotdone364
bb_rcslotdone364:
  %v2588 = load i64, ptr %slot38, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %ld2590 = load i64, ptr %p2589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2590, ptr %slot316, align 8
  %v2591 = load i64, ptr %slot39, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  %ld2593 = load i64, ptr %p2592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2593, ptr %slot317, align 8
  %v2594 = load i64, ptr %slot316, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %ld2596 = load i64, ptr %p2595, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2596, ptr %slot318, align 8
  %v2597 = load i64, ptr %slot317, align 8
  %op2598 = ashr i64 %v2597, 63
  store i64 %op2598, ptr %slot319, align 8
  %v2599 = load i64, ptr %slot319, align 8
  %v2600 = load i64, ptr %slot318, align 8
  %op2601 = and i64 %v2599, %v2600
  store i64 %op2601, ptr %slot320, align 8
  %v2602 = load i64, ptr %slot317, align 8
  %v2603 = load i64, ptr %slot320, align 8
  %op2604 = add i64 %v2602, %v2603
  store i64 %op2604, ptr %slot321, align 8
  %v2605 = load i64, ptr %slot321, align 8
  %v2606 = load i64, ptr %slot318, align 8
  %cmp2607 = icmp ult i64 %v2605, %v2606
  %cv2608 = zext i1 %cmp2607 to i64
  store i64 %cv2608, ptr %slot322, align 8
  %v2609 = load i64, ptr %slot322, align 8
  %cond2610 = icmp ne i64 %v2609, 0
  br i1 %cond2610, label %bb_success379, label %bb_failed379
bb_failed379:
  %v2611 = load i64, ptr %slot1, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %v2613 = load i64, ptr %slot317, align 8
  %v2614 = load i64, ptr %slot318, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p2612, i64 %v2613, i64 %v2614) nomerge, !dbg !128
  unreachable
bb_success379:
  %v2615 = load i64, ptr %slot316, align 8
  %op2616 = add i64 %v2615, 32
  store i64 %op2616, ptr %slot323, align 8
  %v2617 = load i64, ptr %slot323, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2619, ptr %slot324, align 8
  %v2620 = load i64, ptr %slot324, align 8
  %v2621 = load i64, ptr %slot321, align 8
  %op2622 = add i64 %v2620, %v2621
  store i64 %op2622, ptr %slot325, align 8
  %v2623 = load i64, ptr %slot324, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  %v2625 = load i64, ptr %slot321, align 8
  %egep2626 = getelementptr i8, ptr %p2624, i64 %v2625
  %ld2627 = load i8, ptr %egep2626, align 1, !alias.scope !12, !noalias !13
  %ext2628 = zext i8 %ld2627 to i64
  store i64 %ext2628, ptr %slot326, align 8
  %v2629 = load i64, ptr %slot326, align 8
  %v2630 = load i64, ptr %slot38, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i64 %v2629, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  %v2632 = load i64, ptr %slot17, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  %ld2634 = load i32, ptr %p2633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2634, ptr %slot327, align 8
  %v2635 = load i32, ptr %slot327, align 8
  %cv2636 = zext i32 %v2635 to i64
  %cond2637 = icmp ne i64 %cv2636, 0
  br i1 %cond2637, label %bb_rcslotdrop387, label %bb_rcslotdone387
bb_rcslotdrop387:
  %v2638 = load i64, ptr %slot17, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  store i32 0, ptr %p2639, align 4, !alias.scope !3, !noalias !4
  %v2640 = load i64, ptr %slot23, align 8
  store i64 %v2640, ptr %slot328, align 8
  %v2641 = load i64, ptr %slot18, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %ld2643 = load i32, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2643, ptr %slot329, align 8
  %v2644 = load i32, ptr %slot329, align 8
  %op2645 = and i32 %v2644, 28
  store i32 %op2645, ptr %slot330, align 8
  %v2646 = load i32, ptr %slot330, align 8
  %cv2647 = zext i32 %v2646 to i64
  %cond2648 = icmp ne i64 %cv2647, 0
  br i1 %cond2648, label %bb_rcslotrole387, label %bb_rcslotowner387
bb_rcslotrole387:
  %v2649 = load i64, ptr %slot45, align 8
  store i64 %v2649, ptr %slot331, align 8
  %v2650 = load i64, ptr %slot328, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i64, ptr %p2651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2652, ptr %slot332, align 8
  %v2653 = load i64, ptr %slot332, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot333, align 8
  %v2656 = load i32, ptr %slot333, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcgnn403, label %bb_rcgdone403
bb_rcgnn403:
  %v2659 = load i64, ptr %slot332, align 8
  %op2660 = sub i64 %v2659, 16
  store i64 %op2660, ptr %slot334, align 8
  %v2661 = load i64, ptr %slot332, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -16
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot335, align 8
  %v2665 = load i64, ptr %slot335, align 8
  %op2666 = and i64 %v2665, 4611686018427387906
  store i64 %op2666, ptr %slot336, align 8
  %v2667 = load i64, ptr %slot336, align 8
  %cmp2668 = icmp ne i64 %v2667, 0
  %cv2669 = zext i1 %cmp2668 to i32
  store i32 %cv2669, ptr %slot337, align 8
  %v2670 = load i32, ptr %slot337, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcgclear403, label %bb_rcgcounted403
bb_rcgcounted403:
  %v2673 = load i64, ptr %slot332, align 8
  %op2674 = sub i64 %v2673, 24
  store i64 %op2674, ptr %slot338, align 8
  %v2675 = load i64, ptr %slot332, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -24
  %ld2678 = load i64, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2678, ptr %slot339, align 8
  %v2679 = load i64, ptr %slot339, align 8
  %op2680 = sub i64 %v2679, 1
  store i64 %op2680, ptr %slot340, align 8
  %v2681 = load i64, ptr %slot340, align 8
  %cmp2682 = icmp eq i64 %v2681, 0
  %cv2683 = zext i1 %cmp2682 to i32
  store i32 %cv2683, ptr %slot341, align 8
  %v2684 = load i32, ptr %slot341, align 8
  %cv2685 = zext i32 %v2684 to i64
  %cond2686 = icmp ne i64 %cv2685, 0
  br i1 %cond2686, label %bb_rcglast403, label %bb_rcgdec403
bb_rcglast403:
  %v2687 = load i64, ptr %slot332, align 8
  %op2688 = sub i64 %v2687, 32
  store i64 %op2688, ptr %slot342, align 8
  %v2689 = load i64, ptr %slot332, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  %rgep2691 = getelementptr i8, ptr %p2690, i64 -32
  %ld2692 = load i64, ptr %rgep2691, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2692, ptr %slot343, align 8
  %v2693 = load i64, ptr %slot343, align 8
  %cmp2694 = icmp ne i64 %v2693, 0
  %cv2695 = zext i1 %cmp2694 to i32
  store i32 %cv2695, ptr %slot344, align 8
  %v2696 = load i32, ptr %slot344, align 8
  %cv2697 = zext i32 %v2696 to i64
  %cond2698 = icmp ne i64 %cv2697, 0
  br i1 %cond2698, label %bb_rcgdec403, label %bb_rcgslow403
bb_rcgslow403:
  %v2699 = load i64, ptr %slot331, align 8
  %v2700 = load i64, ptr %slot328, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2699, i64 %v2700) nomerge, !dbg !128
  br label %bb_rcgdone403
bb_rcgdec403:
  %v2701 = load i64, ptr %slot340, align 8
  %v2702 = load i64, ptr %slot332, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  %rgep2704 = getelementptr i8, ptr %p2703, i64 -24
  store i64 %v2701, ptr %rgep2704, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear403
bb_rcgclear403:
  %v2705 = load i64, ptr %slot328, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  store i64 0, ptr %p2706, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone403
bb_rcgdone403:
  br label %bb_rcslotdone387
bb_rcslotowner387:
  %v2707 = load i64, ptr %slot45, align 8
  store i64 %v2707, ptr %slot345, align 8
  %v2708 = load i64, ptr %slot328, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i64, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2710, ptr %slot346, align 8
  %v2711 = load i64, ptr %slot346, align 8
  %cmp2712 = icmp ne i64 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot347, align 8
  %v2714 = load i32, ptr %slot347, align 8
  %cv2715 = zext i32 %v2714 to i64
  %cond2716 = icmp ne i64 %cv2715, 0
  br i1 %cond2716, label %bb_rcgnn418, label %bb_rcgdone418
bb_rcgnn418:
  %v2717 = load i64, ptr %slot346, align 8
  %op2718 = sub i64 %v2717, 16
  store i64 %op2718, ptr %slot348, align 8
  %v2719 = load i64, ptr %slot346, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %rgep2721 = getelementptr i8, ptr %p2720, i64 -16
  %ld2722 = load i64, ptr %rgep2721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2722, ptr %slot349, align 8
  %v2723 = load i64, ptr %slot349, align 8
  %op2724 = and i64 %v2723, 4611686018427387906
  store i64 %op2724, ptr %slot350, align 8
  %v2725 = load i64, ptr %slot350, align 8
  %cmp2726 = icmp ne i64 %v2725, 0
  %cv2727 = zext i1 %cmp2726 to i32
  store i32 %cv2727, ptr %slot351, align 8
  %v2728 = load i32, ptr %slot351, align 8
  %cv2729 = zext i32 %v2728 to i64
  %cond2730 = icmp ne i64 %cv2729, 0
  br i1 %cond2730, label %bb_rcgclear418, label %bb_rcgcounted418
bb_rcgcounted418:
  %v2731 = load i64, ptr %slot346, align 8
  %op2732 = sub i64 %v2731, 32
  store i64 %op2732, ptr %slot352, align 8
  %v2733 = load i64, ptr %slot346, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %rgep2735 = getelementptr i8, ptr %p2734, i64 -32
  %ld2736 = load i64, ptr %rgep2735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2736, ptr %slot353, align 8
  %v2737 = load i64, ptr %slot353, align 8
  %op2738 = sub i64 %v2737, 1
  store i64 %op2738, ptr %slot354, align 8
  %v2739 = load i64, ptr %slot354, align 8
  %cmp2740 = icmp eq i64 %v2739, 0
  %cv2741 = zext i1 %cmp2740 to i32
  store i32 %cv2741, ptr %slot355, align 8
  %v2742 = load i32, ptr %slot355, align 8
  %cv2743 = zext i32 %v2742 to i64
  %cond2744 = icmp ne i64 %cv2743, 0
  br i1 %cond2744, label %bb_rcglast418, label %bb_rcgdec418
bb_rcglast418:
  %v2745 = load i64, ptr %slot346, align 8
  %op2746 = sub i64 %v2745, 24
  store i64 %op2746, ptr %slot356, align 8
  %v2747 = load i64, ptr %slot346, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  %rgep2749 = getelementptr i8, ptr %p2748, i64 -24
  %ld2750 = load i64, ptr %rgep2749, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2750, ptr %slot357, align 8
  %v2751 = load i64, ptr %slot357, align 8
  %cmp2752 = icmp ne i64 %v2751, 0
  %cv2753 = zext i1 %cmp2752 to i32
  store i32 %cv2753, ptr %slot358, align 8
  %v2754 = load i32, ptr %slot358, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcgdec418, label %bb_rcgslow418
bb_rcgslow418:
  %v2757 = load i64, ptr %slot345, align 8
  %v2758 = load i64, ptr %slot328, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2757, i64 %v2758) nomerge, !dbg !128
  br label %bb_rcgdone418
bb_rcgdec418:
  %v2759 = load i64, ptr %slot354, align 8
  %v2760 = load i64, ptr %slot346, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %rgep2762 = getelementptr i8, ptr %p2761, i64 -32
  store i64 %v2759, ptr %rgep2762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear418
bb_rcgclear418:
  %v2763 = load i64, ptr %slot328, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  store i64 0, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone418
bb_rcgdone418:
  br label %bb_rcslotdone387
bb_rcslotdone387:
  %v2765 = load i64, ptr %slot38, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i64, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2767, ptr %slot359, align 8
  %v2768 = load i64, ptr %slot359, align 8
  %v2769 = load i64, ptr %slot38, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  store i64 %v2768, ptr %p2770, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v2771 = load i64, ptr %slot39, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 34, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot39, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %ld2775 = load i64, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2775, ptr %slot360, align 8
  %v2776 = load i64, ptr %slot38, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  %ld2778 = load i64, ptr %p2777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2778, ptr %slot361, align 8
  %v2779 = load i64, ptr %slot361, align 8
  %v2780 = load i64, ptr %slot360, align 8
  %cmp2781 = icmp ne i64 %v2779, %v2780
  %cv2782 = zext i1 %cmp2781 to i64
  store i64 %cv2782, ptr %slot362, align 8
  %v2783 = load i64, ptr %slot362, align 8
  %v2784 = load i64, ptr %slot38, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  store i64 %v2783, ptr %p2785, align 8, !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot38, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  %ld2788 = load i64, ptr %p2787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2788, ptr %slot363, align 8
  %v2789 = load i64, ptr %slot363, align 8
  %cond2790 = icmp ne i64 %v2789, 0
  br i1 %cond2790, label %bb_next427, label %bb_i35
bb_next427:
  %v2791 = load i64, ptr %slot28, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i64, ptr %p2792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2793, ptr %slot364, align 8
  %v2794 = load i64, ptr %slot364, align 8
  %v2795 = load i64, ptr %slot38, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  store i64 %v2794, ptr %p2796, align 8, !alias.scope !3, !noalias !4
  %v2797 = load i64, ptr %slot38, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i64, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2799, ptr %slot365, align 8
  %v2800 = load i64, ptr %slot17, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i32, ptr %p2801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2802, ptr %slot366, align 8
  %v2803 = load i64, ptr %slot18, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  %ld2805 = load i32, ptr %p2804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2805, ptr %slot367, align 8
  %v2806 = load i32, ptr %slot367, align 8
  %op2807 = and i32 %v2806, 24
  store i32 %op2807, ptr %slot367, align 8
  %v2808 = load i32, ptr %slot367, align 8
  %cmp2809 = icmp eq i32 %v2808, 0
  %cv2810 = zext i1 %cmp2809 to i32
  store i32 %cv2810, ptr %slot368, align 8
  %v2811 = load i32, ptr %slot366, align 8
  %v2812 = load i32, ptr %slot368, align 8
  %op2813 = and i32 %v2811, %v2812
  store i32 %op2813, ptr %slot369, align 8
  %v2814 = load i32, ptr %slot369, align 8
  %cv2815 = zext i32 %v2814 to i64
  %cond2816 = icmp ne i64 %cv2815, 0
  br i1 %cond2816, label %bb_rctake429, label %bb_rccopy429
bb_rctake429:
  %v2817 = load i64, ptr %slot27, align 8
  store i64 %v2817, ptr %slot370, align 8
  %v2818 = load i64, ptr %slot46, align 8
  store i64 %v2818, ptr %slot371, align 8
  %v2819 = load i64, ptr %slot365, align 8
  %v2820 = load i64, ptr %slot370, align 8
  %op2821 = sub i64 %v2819, %v2820
  store i64 %op2821, ptr %slot372, align 8
  %v2822 = load i64, ptr %slot370, align 8
  %v2823 = load i64, ptr %slot365, align 8
  %op2824 = sub i64 %v2822, %v2823
  store i64 %op2824, ptr %slot373, align 8
  %v2825 = load i64, ptr %slot372, align 8
  %cmp2826 = icmp ult i64 %v2825, 32
  %cv2827 = zext i1 %cmp2826 to i32
  store i32 %cv2827, ptr %slot374, align 8
  %v2828 = load i64, ptr %slot373, align 8
  %cmp2829 = icmp ult i64 %v2828, 32
  %cv2830 = zext i1 %cmp2829 to i32
  store i32 %cv2830, ptr %slot375, align 8
  %v2831 = load i32, ptr %slot374, align 8
  %v2832 = load i32, ptr %slot375, align 8
  %op2833 = or i32 %v2831, %v2832
  store i32 %op2833, ptr %slot376, align 8
  %v2834 = load i32, ptr %slot376, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcmoveslow438, label %bb_rcmovecheck438
bb_rcmovecheck438:
  %v2837 = load i64, ptr %slot365, align 8
  %op2838 = add i64 %v2837, 0
  store i64 %op2838, ptr %slot377, align 8
  %v2839 = load i64, ptr %slot377, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  %ld2841 = load i64, ptr %p2840, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2841, ptr %slot378, align 8
  %v2842 = load i64, ptr %slot378, align 8
  %cmp2843 = icmp ne i64 %v2842, 0
  %cv2844 = zext i1 %cmp2843 to i32
  store i32 %cv2844, ptr %slot379, align 8
  %v2845 = load i32, ptr %slot379, align 8
  %cv2846 = zext i32 %v2845 to i64
  %cond2847 = icmp ne i64 %cv2846, 0
  br i1 %cond2847, label %bb_rcmoveheader446, label %bb_rcmovenext446
bb_rcmoveheader446:
  %v2848 = load i64, ptr %slot378, align 8
  %op2849 = sub i64 %v2848, 16
  store i64 %op2849, ptr %slot380, align 8
  %v2850 = load i64, ptr %slot378, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %rgep2852 = getelementptr i8, ptr %p2851, i64 -16
  %ld2853 = load i64, ptr %rgep2852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2853, ptr %slot381, align 8
  %v2854 = load i64, ptr %slot381, align 8
  %op2855 = and i64 %v2854, 5764607523034234881
  store i64 %op2855, ptr %slot382, align 8
  %v2856 = load i64, ptr %slot382, align 8
  %cmp2857 = icmp ne i64 %v2856, 0
  %cv2858 = zext i1 %cmp2857 to i32
  store i32 %cv2858, ptr %slot383, align 8
  %v2859 = load i32, ptr %slot383, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcmoveslow438, label %bb_rcmovenext446
bb_rcmovenext446:
  %v2862 = load i64, ptr %slot365, align 8
  %v2863 = load i64, ptr %slot370, align 8
  %p2864 = inttoptr i64 %v2862 to ptr
  %p2865 = inttoptr i64 %v2863 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2865, ptr %p2864, i64 32, i1 false), !alias.scope !10000000
  %v2866 = load i64, ptr %slot365, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i64 0, ptr %p2867, align 8, !alias.scope !4, !noalias !3
  %v2868 = load i64, ptr %slot365, align 8
  %op2869 = add i64 %v2868, 8
  store i64 %op2869, ptr %slot384, align 8
  %v2870 = load i64, ptr %slot384, align 8
  %p2871 = inttoptr i64 %v2870 to ptr
  store i64 0, ptr %p2871, align 8, !alias.scope !4, !noalias !3
  %v2872 = load i64, ptr %slot365, align 8
  %op2873 = add i64 %v2872, 16
  store i64 %op2873, ptr %slot385, align 8
  %v2874 = load i64, ptr %slot385, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  store i64 0, ptr %p2875, align 8, !alias.scope !4, !noalias !3
  %v2876 = load i64, ptr %slot365, align 8
  %op2877 = add i64 %v2876, 24
  store i64 %op2877, ptr %slot386, align 8
  %v2878 = load i64, ptr %slot386, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  store i64 0, ptr %p2879, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved438
bb_rcmoveslow438:
  %v2880 = load i64, ptr %slot45, align 8
  %v2881 = load i64, ptr %slot370, align 8
  %v2882 = load i64, ptr %slot365, align 8
  %v2883 = load i64, ptr %slot371, align 8
  %cv2884 = trunc i64 %v2883 to i32
  %call2885 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2880, i64 %v2881, i64 %v2882, i32 %cv2884) nomerge, !dbg !130
  store i32 %call2885, ptr %slot387, align 8
  %v2886 = load i32, ptr %slot387, align 8
  %cv2887 = zext i32 %v2886 to i64
  %cond2888 = icmp ne i64 %cv2887, 0
  br i1 %cond2888, label %bb_rcsuccess456, label %bb_rcfailure456
bb_rcfailure456:
  %v2889 = load i64, ptr %slot45, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %call2891 = call i32 @myl_rc_take_failure(ptr %p2890) nomerge, !dbg !130
  store i32 %call2891, ptr %slot388, align 8
  %v2892 = load i64, ptr %slot1, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  %v2894 = load i32, ptr %slot388, align 8
  %call2895 = call i32 @myl_qbe_rc_status(ptr %p2893, i32 %v2894) nomerge, !dbg !130
  store i32 %call2895, ptr %slot389, align 8
  br label %bb_failure
bb_rcsuccess456:
  br label %bb_rcmoved438
bb_rcmoved438:
  %v2896 = load i64, ptr %slot17, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  store i32 0, ptr %p2897, align 4, !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot22, align 8
  %p2899 = inttoptr i64 %v2898 to ptr
  store i32 2, ptr %p2899, align 4, !alias.scope !3, !noalias !4
  %v2900 = load i64, ptr %slot21, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  store i32 1, ptr %p2901, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared429
bb_rccopy429:
  %v2902 = load i64, ptr %slot27, align 8
  store i64 %v2902, ptr %slot390, align 8
  %v2903 = load i64, ptr %slot46, align 8
  store i64 %v2903, ptr %slot391, align 8
  %v2904 = load i64, ptr %slot45, align 8
  %v2905 = load i64, ptr %slot390, align 8
  %v2906 = load i64, ptr %slot365, align 8
  %v2907 = load i64, ptr %slot391, align 8
  %cv2908 = trunc i64 %v2907 to i32
  %call2909 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v2904, i64 %v2905, i64 %v2906, i32 %cv2908) nomerge, !dbg !130
  store i32 %call2909, ptr %slot392, align 8
  %v2910 = load i32, ptr %slot392, align 8
  %cv2911 = zext i32 %v2910 to i64
  %cond2912 = icmp ne i64 %cv2911, 0
  br i1 %cond2912, label %bb_rcsuccess465, label %bb_rcfailure465
bb_rcfailure465:
  %v2913 = load i64, ptr %slot45, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  %call2915 = call i32 @myl_rc_take_failure(ptr %p2914) nomerge, !dbg !130
  store i32 %call2915, ptr %slot393, align 8
  %v2916 = load i64, ptr %slot1, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %v2918 = load i32, ptr %slot393, align 8
  %call2919 = call i32 @myl_qbe_rc_status(ptr %p2917, i32 %v2918) nomerge, !dbg !130
  store i32 %call2919, ptr %slot394, align 8
  br label %bb_failure
bb_rcsuccess465:
  %v2920 = load i64, ptr %slot22, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  store i32 2, ptr %p2921, align 4, !alias.scope !3, !noalias !4
  %v2922 = load i64, ptr %slot21, align 8
  %p2923 = inttoptr i64 %v2922 to ptr
  store i32 1, ptr %p2923, align 4, !alias.scope !3, !noalias !4
  %v2924 = load i64, ptr %slot17, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  %ld2926 = load i32, ptr %p2925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2926, ptr %slot395, align 8
  %v2927 = load i32, ptr %slot395, align 8
  %cv2928 = zext i32 %v2927 to i64
  %cond2929 = icmp ne i64 %cv2928, 0
  br i1 %cond2929, label %bb_rcslotdrop472, label %bb_rcslotdone472
bb_rcslotdrop472:
  %v2930 = load i64, ptr %slot17, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  store i32 0, ptr %p2931, align 4, !alias.scope !3, !noalias !4
  %v2932 = load i64, ptr %slot23, align 8
  store i64 %v2932, ptr %slot396, align 8
  %v2933 = load i64, ptr %slot18, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %ld2935 = load i32, ptr %p2934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2935, ptr %slot397, align 8
  %v2936 = load i32, ptr %slot397, align 8
  %op2937 = and i32 %v2936, 28
  store i32 %op2937, ptr %slot398, align 8
  %v2938 = load i32, ptr %slot398, align 8
  %cv2939 = zext i32 %v2938 to i64
  %cond2940 = icmp ne i64 %cv2939, 0
  br i1 %cond2940, label %bb_rcslotrole472, label %bb_rcslotowner472
bb_rcslotrole472:
  %v2941 = load i64, ptr %slot45, align 8
  store i64 %v2941, ptr %slot399, align 8
  %v2942 = load i64, ptr %slot399, align 8
  %v2943 = load i64, ptr %slot396, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2942, i64 %v2943) nomerge, !dbg !130
  br label %bb_rcslotdone472
bb_rcslotowner472:
  %v2944 = load i64, ptr %slot396, align 8
  %p2946 = inttoptr i64 %v2944 to ptr
  %gep2947 = getelementptr i8, ptr %p2946, i64 0
  %op2945 = ptrtoint ptr %gep2947 to i64
  store i64 %op2945, ptr %slot400, align 8
  %v2948 = load i64, ptr %slot45, align 8
  store i64 %v2948, ptr %slot401, align 8
  %v2949 = load i64, ptr %slot400, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %ld2951 = load i64, ptr %p2950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2951, ptr %slot402, align 8
  %v2952 = load i64, ptr %slot402, align 8
  %cmp2953 = icmp ne i64 %v2952, 0
  %cv2954 = zext i1 %cmp2953 to i32
  store i32 %cv2954, ptr %slot403, align 8
  %v2955 = load i32, ptr %slot403, align 8
  %cv2956 = zext i32 %v2955 to i64
  %cond2957 = icmp ne i64 %cv2956, 0
  br i1 %cond2957, label %bb_rcgnn490, label %bb_rcgdone490
bb_rcgnn490:
  %v2958 = load i64, ptr %slot402, align 8
  %op2959 = sub i64 %v2958, 16
  store i64 %op2959, ptr %slot404, align 8
  %v2960 = load i64, ptr %slot402, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  %rgep2962 = getelementptr i8, ptr %p2961, i64 -16
  %ld2963 = load i64, ptr %rgep2962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2963, ptr %slot405, align 8
  %v2964 = load i64, ptr %slot405, align 8
  %op2965 = and i64 %v2964, 4611686018427387906
  store i64 %op2965, ptr %slot406, align 8
  %v2966 = load i64, ptr %slot406, align 8
  %cmp2967 = icmp ne i64 %v2966, 0
  %cv2968 = zext i1 %cmp2967 to i32
  store i32 %cv2968, ptr %slot407, align 8
  %v2969 = load i32, ptr %slot407, align 8
  %cv2970 = zext i32 %v2969 to i64
  %cond2971 = icmp ne i64 %cv2970, 0
  br i1 %cond2971, label %bb_rcgclear490, label %bb_rcgcounted490
bb_rcgcounted490:
  %v2972 = load i64, ptr %slot402, align 8
  %op2973 = sub i64 %v2972, 32
  store i64 %op2973, ptr %slot408, align 8
  %v2974 = load i64, ptr %slot402, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  %rgep2976 = getelementptr i8, ptr %p2975, i64 -32
  %ld2977 = load i64, ptr %rgep2976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2977, ptr %slot409, align 8
  %v2978 = load i64, ptr %slot409, align 8
  %op2979 = sub i64 %v2978, 1
  store i64 %op2979, ptr %slot410, align 8
  %v2980 = load i64, ptr %slot410, align 8
  %cmp2981 = icmp eq i64 %v2980, 0
  %cv2982 = zext i1 %cmp2981 to i32
  store i32 %cv2982, ptr %slot411, align 8
  %v2983 = load i32, ptr %slot411, align 8
  %cv2984 = zext i32 %v2983 to i64
  %cond2985 = icmp ne i64 %cv2984, 0
  br i1 %cond2985, label %bb_rcglast490, label %bb_rcgdec490
bb_rcglast490:
  %v2986 = load i64, ptr %slot402, align 8
  %op2987 = sub i64 %v2986, 24
  store i64 %op2987, ptr %slot412, align 8
  %v2988 = load i64, ptr %slot402, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %rgep2990 = getelementptr i8, ptr %p2989, i64 -24
  %ld2991 = load i64, ptr %rgep2990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2991, ptr %slot413, align 8
  %v2992 = load i64, ptr %slot413, align 8
  %cmp2993 = icmp ne i64 %v2992, 0
  %cv2994 = zext i1 %cmp2993 to i32
  store i32 %cv2994, ptr %slot414, align 8
  %v2995 = load i32, ptr %slot414, align 8
  %cv2996 = zext i32 %v2995 to i64
  %cond2997 = icmp ne i64 %cv2996, 0
  br i1 %cond2997, label %bb_rcgdec490, label %bb_rcgslow490
bb_rcgslow490:
  %v2998 = load i64, ptr %slot401, align 8
  %v2999 = load i64, ptr %slot400, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2998, i64 %v2999) nomerge, !dbg !130
  br label %bb_rcgdone490
bb_rcgdec490:
  %v3000 = load i64, ptr %slot410, align 8
  %v3001 = load i64, ptr %slot402, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %rgep3003 = getelementptr i8, ptr %p3002, i64 -32
  store i64 %v3000, ptr %rgep3003, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear490
bb_rcgclear490:
  %v3004 = load i64, ptr %slot400, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i64 0, ptr %p3005, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone490
bb_rcgdone490:
  %v3006 = load i64, ptr %slot396, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i64 0, ptr %p3007, align 8, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot396, align 8
  %p3010 = inttoptr i64 %v3008 to ptr
  %gep3011 = getelementptr i8, ptr %p3010, i64 8
  %op3009 = ptrtoint ptr %gep3011 to i64
  store i64 %op3009, ptr %slot415, align 8
  %v3012 = load i64, ptr %slot415, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i64 0, ptr %p3013, align 8, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot396, align 8
  %p3016 = inttoptr i64 %v3014 to ptr
  %gep3017 = getelementptr i8, ptr %p3016, i64 16
  %op3015 = ptrtoint ptr %gep3017 to i64
  store i64 %op3015, ptr %slot416, align 8
  %v3018 = load i64, ptr %slot416, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  store i64 0, ptr %p3019, align 8, !alias.scope !3, !noalias !4
  %v3020 = load i64, ptr %slot396, align 8
  %p3022 = inttoptr i64 %v3020 to ptr
  %gep3023 = getelementptr i8, ptr %p3022, i64 24
  %op3021 = ptrtoint ptr %gep3023 to i64
  store i64 %op3021, ptr %slot417, align 8
  %v3024 = load i64, ptr %slot417, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  store i64 0, ptr %p3025, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone472
bb_rcslotdone472:
  br label %bb_rcprepared429
bb_rcprepared429:
  %v3026 = load i64, ptr %slot9, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %ld3028 = load i32, ptr %p3027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3028, ptr %slot418, align 8
  %v3029 = load i32, ptr %slot418, align 8
  %cv3030 = zext i32 %v3029 to i64
  %cond3031 = icmp ne i64 %cv3030, 0
  br i1 %cond3031, label %bb_rcslotdrop500, label %bb_rcslotdone500
bb_rcslotdrop500:
  %v3032 = load i64, ptr %slot9, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  store i32 0, ptr %p3033, align 4, !alias.scope !3, !noalias !4
  %v3034 = load i64, ptr %slot34, align 8
  store i64 %v3034, ptr %slot419, align 8
  %v3035 = load i64, ptr %slot10, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  %ld3037 = load i32, ptr %p3036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3037, ptr %slot420, align 8
  %v3038 = load i32, ptr %slot420, align 8
  %op3039 = and i32 %v3038, 28
  store i32 %op3039, ptr %slot421, align 8
  %v3040 = load i32, ptr %slot421, align 8
  %cv3041 = zext i32 %v3040 to i64
  %cond3042 = icmp ne i64 %cv3041, 0
  br i1 %cond3042, label %bb_rcslotrole500, label %bb_rcslotowner500
bb_rcslotrole500:
  %v3043 = load i64, ptr %slot45, align 8
  store i64 %v3043, ptr %slot422, align 8
  %v3044 = load i64, ptr %slot422, align 8
  %v3045 = load i64, ptr %slot419, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3044, i64 %v3045) nomerge, !dbg !130
  br label %bb_rcslotdone500
bb_rcslotowner500:
  %v3046 = load i64, ptr %slot419, align 8
  %p3048 = inttoptr i64 %v3046 to ptr
  %gep3049 = getelementptr i8, ptr %p3048, i64 0
  %op3047 = ptrtoint ptr %gep3049 to i64
  store i64 %op3047, ptr %slot423, align 8
  %v3050 = load i64, ptr %slot45, align 8
  store i64 %v3050, ptr %slot424, align 8
  %v3051 = load i64, ptr %slot423, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %ld3053 = load i64, ptr %p3052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3053, ptr %slot425, align 8
  %v3054 = load i64, ptr %slot425, align 8
  %cmp3055 = icmp ne i64 %v3054, 0
  %cv3056 = zext i1 %cmp3055 to i32
  store i32 %cv3056, ptr %slot426, align 8
  %v3057 = load i32, ptr %slot426, align 8
  %cv3058 = zext i32 %v3057 to i64
  %cond3059 = icmp ne i64 %cv3058, 0
  br i1 %cond3059, label %bb_rcgnn518, label %bb_rcgdone518
bb_rcgnn518:
  %v3060 = load i64, ptr %slot425, align 8
  %op3061 = sub i64 %v3060, 16
  store i64 %op3061, ptr %slot427, align 8
  %v3062 = load i64, ptr %slot425, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %rgep3064 = getelementptr i8, ptr %p3063, i64 -16
  %ld3065 = load i64, ptr %rgep3064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3065, ptr %slot428, align 8
  %v3066 = load i64, ptr %slot428, align 8
  %op3067 = and i64 %v3066, 4611686018427387906
  store i64 %op3067, ptr %slot429, align 8
  %v3068 = load i64, ptr %slot429, align 8
  %cmp3069 = icmp ne i64 %v3068, 0
  %cv3070 = zext i1 %cmp3069 to i32
  store i32 %cv3070, ptr %slot430, align 8
  %v3071 = load i32, ptr %slot430, align 8
  %cv3072 = zext i32 %v3071 to i64
  %cond3073 = icmp ne i64 %cv3072, 0
  br i1 %cond3073, label %bb_rcgclear518, label %bb_rcgcounted518
bb_rcgcounted518:
  %v3074 = load i64, ptr %slot425, align 8
  %op3075 = sub i64 %v3074, 32
  store i64 %op3075, ptr %slot431, align 8
  %v3076 = load i64, ptr %slot425, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %rgep3078 = getelementptr i8, ptr %p3077, i64 -32
  %ld3079 = load i64, ptr %rgep3078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3079, ptr %slot432, align 8
  %v3080 = load i64, ptr %slot432, align 8
  %op3081 = sub i64 %v3080, 1
  store i64 %op3081, ptr %slot433, align 8
  %v3082 = load i64, ptr %slot433, align 8
  %cmp3083 = icmp eq i64 %v3082, 0
  %cv3084 = zext i1 %cmp3083 to i32
  store i32 %cv3084, ptr %slot434, align 8
  %v3085 = load i32, ptr %slot434, align 8
  %cv3086 = zext i32 %v3085 to i64
  %cond3087 = icmp ne i64 %cv3086, 0
  br i1 %cond3087, label %bb_rcglast518, label %bb_rcgdec518
bb_rcglast518:
  %v3088 = load i64, ptr %slot425, align 8
  %op3089 = sub i64 %v3088, 24
  store i64 %op3089, ptr %slot435, align 8
  %v3090 = load i64, ptr %slot425, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %rgep3092 = getelementptr i8, ptr %p3091, i64 -24
  %ld3093 = load i64, ptr %rgep3092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3093, ptr %slot436, align 8
  %v3094 = load i64, ptr %slot436, align 8
  %cmp3095 = icmp ne i64 %v3094, 0
  %cv3096 = zext i1 %cmp3095 to i32
  store i32 %cv3096, ptr %slot437, align 8
  %v3097 = load i32, ptr %slot437, align 8
  %cv3098 = zext i32 %v3097 to i64
  %cond3099 = icmp ne i64 %cv3098, 0
  br i1 %cond3099, label %bb_rcgdec518, label %bb_rcgslow518
bb_rcgslow518:
  %v3100 = load i64, ptr %slot424, align 8
  %v3101 = load i64, ptr %slot423, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3100, i64 %v3101) nomerge, !dbg !130
  br label %bb_rcgdone518
bb_rcgdec518:
  %v3102 = load i64, ptr %slot433, align 8
  %v3103 = load i64, ptr %slot425, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  %rgep3105 = getelementptr i8, ptr %p3104, i64 -32
  store i64 %v3102, ptr %rgep3105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear518
bb_rcgclear518:
  %v3106 = load i64, ptr %slot423, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  store i64 0, ptr %p3107, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone518
bb_rcgdone518:
  %v3108 = load i64, ptr %slot419, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i64 0, ptr %p3109, align 8, !alias.scope !3, !noalias !4
  %v3110 = load i64, ptr %slot419, align 8
  %p3112 = inttoptr i64 %v3110 to ptr
  %gep3113 = getelementptr i8, ptr %p3112, i64 8
  %op3111 = ptrtoint ptr %gep3113 to i64
  store i64 %op3111, ptr %slot438, align 8
  %v3114 = load i64, ptr %slot438, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  store i64 0, ptr %p3115, align 8, !alias.scope !3, !noalias !4
  %v3116 = load i64, ptr %slot419, align 8
  %p3118 = inttoptr i64 %v3116 to ptr
  %gep3119 = getelementptr i8, ptr %p3118, i64 16
  %op3117 = ptrtoint ptr %gep3119 to i64
  store i64 %op3117, ptr %slot439, align 8
  %v3120 = load i64, ptr %slot439, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 0, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot419, align 8
  %p3124 = inttoptr i64 %v3122 to ptr
  %gep3125 = getelementptr i8, ptr %p3124, i64 24
  %op3123 = ptrtoint ptr %gep3125 to i64
  store i64 %op3123, ptr %slot440, align 8
  %v3126 = load i64, ptr %slot440, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  store i64 0, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone500
bb_rcslotdone500:
  %v3128 = load i64, ptr %slot34, align 8
  store i64 %v3128, ptr %slot441, align 8
  %v3129 = load i64, ptr %slot27, align 8
  store i64 %v3129, ptr %slot442, align 8
  %v3130 = load i64, ptr %slot442, align 8
  %v3131 = load i64, ptr %slot441, align 8
  %p3132 = inttoptr i64 %v3130 to ptr
  %p3133 = inttoptr i64 %v3131 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3133, ptr %p3132, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot21, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 0, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot10, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  store i32 2, ptr %p3137, align 4, !alias.scope !3, !noalias !4
  %v3138 = load i64, ptr %slot22, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  %ld3140 = load i32, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3140, ptr %slot443, align 8
  %v3141 = load i32, ptr %slot443, align 8
  %v3142 = load i64, ptr %slot10, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  store i32 %v3141, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  %v3144 = load i64, ptr %slot9, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  store i32 1, ptr %p3145, align 4, !alias.scope !3, !noalias !4
  %v3146 = load i64, ptr %slot34, align 8
  %v3147 = load i64, ptr %slot38, align 8
  %p3148 = inttoptr i64 %v3147 to ptr
  store i64 %v3146, ptr %p3148, align 8, !alias.scope !3, !noalias !4
  %v3149 = load i64, ptr %slot38, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  %ld3151 = load i64, ptr %p3150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3151, ptr %slot444, align 8
  %v3152 = load i64, ptr %slot444, align 8
  %op3153 = add i64 %v3152, 16
  store i64 %op3153, ptr %slot445, align 8
  %v3154 = load i64, ptr %slot445, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i64, ptr %p3155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3156, ptr %slot446, align 8
  %v3157 = load i64, ptr %slot446, align 8
  %v3158 = load i64, ptr %slot38, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  store i64 %v3157, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  %v3160 = load i64, ptr %slot17, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  %ld3162 = load i32, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3162, ptr %slot447, align 8
  %v3163 = load i32, ptr %slot447, align 8
  %cv3164 = zext i32 %v3163 to i64
  %cond3165 = icmp ne i64 %cv3164, 0
  br i1 %cond3165, label %bb_rcslotdrop537, label %bb_rcslotdone537
bb_rcslotdrop537:
  %v3166 = load i64, ptr %slot17, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  store i32 0, ptr %p3167, align 4, !alias.scope !3, !noalias !4
  %v3168 = load i64, ptr %slot23, align 8
  store i64 %v3168, ptr %slot448, align 8
  %v3169 = load i64, ptr %slot18, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %ld3171 = load i32, ptr %p3170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3171, ptr %slot449, align 8
  %v3172 = load i32, ptr %slot449, align 8
  %op3173 = and i32 %v3172, 28
  store i32 %op3173, ptr %slot450, align 8
  %v3174 = load i32, ptr %slot450, align 8
  %cv3175 = zext i32 %v3174 to i64
  %cond3176 = icmp ne i64 %cv3175, 0
  br i1 %cond3176, label %bb_rcslotrole537, label %bb_rcslotowner537
bb_rcslotrole537:
  %v3177 = load i64, ptr %slot45, align 8
  store i64 %v3177, ptr %slot451, align 8
  %v3178 = load i64, ptr %slot451, align 8
  %v3179 = load i64, ptr %slot448, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3178, i64 %v3179) nomerge, !dbg !132
  br label %bb_rcslotdone537
bb_rcslotowner537:
  %v3180 = load i64, ptr %slot45, align 8
  store i64 %v3180, ptr %slot452, align 8
  %v3181 = load i64, ptr %slot452, align 8
  %v3182 = load i64, ptr %slot448, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3181, i64 %v3182) nomerge, !dbg !132
  br label %bb_rcslotdone537
bb_rcslotdone537:
  %v3183 = load i64, ptr %slot34, align 8
  %v3184 = load i64, ptr %slot39, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i64 %v3183, ptr %p3185, align 8, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot39, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  %ld3188 = load i64, ptr %p3187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3188, ptr %slot453, align 8
  %v3189 = load i64, ptr %slot453, align 8
  %op3190 = add i64 %v3189, 0
  store i64 %op3190, ptr %slot454, align 8
  %v3191 = load i64, ptr %slot454, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  %ld3193 = load i64, ptr %p3192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3193, ptr %slot455, align 8
  %v3194 = load i64, ptr %slot455, align 8
  %v3195 = load i64, ptr %slot39, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i64 %v3194, ptr %p3196, align 8, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot39, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %ld3199 = load i64, ptr %p3198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3199, ptr %slot456, align 8
  %v3200 = load i64, ptr %slot456, align 8
  %v3201 = load i64, ptr %slot26, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  store i64 %v3200, ptr %p3202, align 8, !alias.scope !3, !noalias !4
  %v3203 = load i64, ptr %slot26, align 8
  store i64 %v3203, ptr %slot457, align 8
  %v3204 = load i64, ptr %slot27, align 8
  store i64 %v3204, ptr %slot458, align 8
  %v3205 = load i64, ptr %slot457, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i64, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3207, ptr %slot459, align 8
  %v3208 = load i64, ptr %slot459, align 8
  %cmp3209 = icmp ne i64 %v3208, 0
  %cv3210 = zext i1 %cmp3209 to i32
  store i32 %cv3210, ptr %slot460, align 8
  %v3211 = load i32, ptr %slot460, align 8
  %cv3212 = zext i32 %v3211 to i64
  %cond3213 = icmp ne i64 %cv3212, 0
  br i1 %cond3213, label %bb_rcgnn551, label %bb_rcgstore551
bb_rcgnn551:
  %v3214 = load i64, ptr %slot459, align 8
  %op3215 = sub i64 %v3214, 16
  store i64 %op3215, ptr %slot461, align 8
  %v3216 = load i64, ptr %slot459, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  %rgep3218 = getelementptr i8, ptr %p3217, i64 -16
  %ld3219 = load i64, ptr %rgep3218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3219, ptr %slot462, align 8
  %v3220 = load i64, ptr %slot462, align 8
  %op3221 = and i64 %v3220, 4611686018427387906
  store i64 %op3221, ptr %slot463, align 8
  %v3222 = load i64, ptr %slot463, align 8
  %cmp3223 = icmp ne i64 %v3222, 0
  %cv3224 = zext i1 %cmp3223 to i32
  store i32 %cv3224, ptr %slot464, align 8
  %v3225 = load i32, ptr %slot464, align 8
  %cv3226 = zext i32 %v3225 to i64
  %cond3227 = icmp ne i64 %cv3226, 0
  br i1 %cond3227, label %bb_rcgstore551, label %bb_rcginc551
bb_rcginc551:
  %v3228 = load i64, ptr %slot459, align 8
  %op3229 = sub i64 %v3228, 24
  store i64 %op3229, ptr %slot465, align 8
  %v3230 = load i64, ptr %slot459, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  %rgep3232 = getelementptr i8, ptr %p3231, i64 -24
  %ld3233 = load i64, ptr %rgep3232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3233, ptr %slot466, align 8
  %v3234 = load i64, ptr %slot466, align 8
  %op3235 = add i64 %v3234, 1
  store i64 %op3235, ptr %slot467, align 8
  %v3236 = load i64, ptr %slot467, align 8
  %cmp3237 = icmp eq i64 %v3236, 0
  %cv3238 = zext i1 %cmp3237 to i32
  store i32 %cv3238, ptr %slot468, align 8
  %v3239 = load i32, ptr %slot468, align 8
  %cv3240 = zext i32 %v3239 to i64
  %cond3241 = icmp ne i64 %cv3240, 0
  br i1 %cond3241, label %bb_rcglimit551, label %bb_rcgcapacity551
bb_rcglimit551:
  %v3242 = load i64, ptr %slot1, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %call3244 = call i32 @myl_qbe_rc_status(ptr %p3243, i32 2) nomerge, !dbg !134
  store i32 %call3244, ptr %slot469, align 8
  br label %bb_failure
bb_rcgcapacity551:
  %v3245 = load i64, ptr %slot467, align 8
  %v3246 = load i64, ptr %slot459, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  %rgep3248 = getelementptr i8, ptr %p3247, i64 -24
  store i64 %v3245, ptr %rgep3248, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore551
bb_rcgstore551:
  %v3249 = load i64, ptr %slot459, align 8
  %v3250 = load i64, ptr %slot458, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  store i64 %v3249, ptr %p3251, align 8, !alias.scope !3, !noalias !4
  %v3252 = load i64, ptr %slot22, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  store i32 2, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  %v3254 = load i64, ptr %slot22, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  store i32 16, ptr %p3255, align 4, !alias.scope !3, !noalias !4
  %v3256 = load i64, ptr %slot21, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i32 1, ptr %p3257, align 4, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot19, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  %ld3260 = load i32, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3260, ptr %slot470, align 8
  %v3261 = load i32, ptr %slot470, align 8
  %cv3262 = zext i32 %v3261 to i64
  %cond3263 = icmp ne i64 %cv3262, 0
  br i1 %cond3263, label %bb_rcslotdrop567, label %bb_rcslotdone567
bb_rcslotdrop567:
  %v3264 = load i64, ptr %slot19, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  store i32 0, ptr %p3265, align 4, !alias.scope !3, !noalias !4
  %v3266 = load i64, ptr %slot24, align 8
  store i64 %v3266, ptr %slot471, align 8
  %v3267 = load i64, ptr %slot20, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  %ld3269 = load i32, ptr %p3268, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3269, ptr %slot472, align 8
  %v3270 = load i32, ptr %slot472, align 8
  %op3271 = and i32 %v3270, 28
  store i32 %op3271, ptr %slot473, align 8
  %v3272 = load i32, ptr %slot473, align 8
  %cv3273 = zext i32 %v3272 to i64
  %cond3274 = icmp ne i64 %cv3273, 0
  br i1 %cond3274, label %bb_rcslotrole567, label %bb_rcslotowner567
bb_rcslotrole567:
  %v3275 = load i64, ptr %slot45, align 8
  store i64 %v3275, ptr %slot474, align 8
  %v3276 = load i64, ptr %slot474, align 8
  %v3277 = load i64, ptr %slot471, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3276, i64 %v3277) nomerge, !dbg !134
  br label %bb_rcslotdone567
bb_rcslotowner567:
  %v3278 = load i64, ptr %slot45, align 8
  store i64 %v3278, ptr %slot475, align 8
  %v3279 = load i64, ptr %slot475, align 8
  %v3280 = load i64, ptr %slot471, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3279, i64 %v3280) nomerge, !dbg !134
  br label %bb_rcslotdone567
bb_rcslotdone567:
  %v3281 = load i64, ptr %slot24, align 8
  store i64 %v3281, ptr %slot476, align 8
  %v3282 = load i64, ptr %slot27, align 8
  store i64 %v3282, ptr %slot477, align 8
  %v3283 = load i64, ptr %slot477, align 8
  %v3284 = load i64, ptr %slot476, align 8
  %p3285 = inttoptr i64 %v3283 to ptr
  %p3286 = inttoptr i64 %v3284 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3286, ptr %p3285, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3287 = load i64, ptr %slot20, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  store i32 2, ptr %p3288, align 4, !alias.scope !3, !noalias !4
  %v3289 = load i64, ptr %slot22, align 8
  %p3290 = inttoptr i64 %v3289 to ptr
  %ld3291 = load i32, ptr %p3290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3291, ptr %slot478, align 8
  %v3292 = load i32, ptr %slot478, align 8
  %v3293 = load i64, ptr %slot20, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i32 %v3292, ptr %p3294, align 4, !alias.scope !3, !noalias !4
  %v3295 = load i64, ptr %slot21, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  store i32 0, ptr %p3296, align 4, !alias.scope !3, !noalias !4
  %v3297 = load i64, ptr %slot19, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  store i32 1, ptr %p3298, align 4, !alias.scope !3, !noalias !4
  %v3299 = load i64, ptr %slot476, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i64, ptr %p3300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3301, ptr %slot479, align 8
  %v3302 = load i64, ptr %slot479, align 8
  %v3303 = load i64, ptr %slot39, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 %v3302, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot39, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i64, ptr %p3306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3307, ptr %slot480, align 8
  %v3308 = load i64, ptr %slot480, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  %ld3310 = load i64, ptr %p3309, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3310, ptr %slot481, align 8
  %v3311 = load i64, ptr %slot481, align 8
  %v3312 = load i64, ptr %slot39, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  store i64 %v3311, ptr %p3313, align 8, !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot19, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i32, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3316, ptr %slot482, align 8
  %v3317 = load i32, ptr %slot482, align 8
  %cv3318 = zext i32 %v3317 to i64
  %cond3319 = icmp ne i64 %cv3318, 0
  br i1 %cond3319, label %bb_rcslotdrop587, label %bb_rcslotdone587
bb_rcslotdrop587:
  %v3320 = load i64, ptr %slot19, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  store i32 0, ptr %p3321, align 4, !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot24, align 8
  store i64 %v3322, ptr %slot483, align 8
  %v3323 = load i64, ptr %slot20, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  %ld3325 = load i32, ptr %p3324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3325, ptr %slot484, align 8
  %v3326 = load i32, ptr %slot484, align 8
  %op3327 = and i32 %v3326, 28
  store i32 %op3327, ptr %slot485, align 8
  %v3328 = load i32, ptr %slot485, align 8
  %cv3329 = zext i32 %v3328 to i64
  %cond3330 = icmp ne i64 %cv3329, 0
  br i1 %cond3330, label %bb_rcslotrole587, label %bb_rcslotowner587
bb_rcslotrole587:
  %v3331 = load i64, ptr %slot45, align 8
  store i64 %v3331, ptr %slot486, align 8
  %v3332 = load i64, ptr %slot483, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot487, align 8
  %v3335 = load i64, ptr %slot487, align 8
  %cmp3336 = icmp ne i64 %v3335, 0
  %cv3337 = zext i1 %cmp3336 to i32
  store i32 %cv3337, ptr %slot488, align 8
  %v3338 = load i32, ptr %slot488, align 8
  %cv3339 = zext i32 %v3338 to i64
  %cond3340 = icmp ne i64 %cv3339, 0
  br i1 %cond3340, label %bb_rcgnn603, label %bb_rcgdone603
bb_rcgnn603:
  %v3341 = load i64, ptr %slot487, align 8
  %op3342 = sub i64 %v3341, 16
  store i64 %op3342, ptr %slot489, align 8
  %v3343 = load i64, ptr %slot487, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  %rgep3345 = getelementptr i8, ptr %p3344, i64 -16
  %ld3346 = load i64, ptr %rgep3345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3346, ptr %slot490, align 8
  %v3347 = load i64, ptr %slot490, align 8
  %op3348 = and i64 %v3347, 4611686018427387906
  store i64 %op3348, ptr %slot491, align 8
  %v3349 = load i64, ptr %slot491, align 8
  %cmp3350 = icmp ne i64 %v3349, 0
  %cv3351 = zext i1 %cmp3350 to i32
  store i32 %cv3351, ptr %slot492, align 8
  %v3352 = load i32, ptr %slot492, align 8
  %cv3353 = zext i32 %v3352 to i64
  %cond3354 = icmp ne i64 %cv3353, 0
  br i1 %cond3354, label %bb_rcgclear603, label %bb_rcgcounted603
bb_rcgcounted603:
  %v3355 = load i64, ptr %slot487, align 8
  %op3356 = sub i64 %v3355, 24
  store i64 %op3356, ptr %slot493, align 8
  %v3357 = load i64, ptr %slot487, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  %rgep3359 = getelementptr i8, ptr %p3358, i64 -24
  %ld3360 = load i64, ptr %rgep3359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3360, ptr %slot494, align 8
  %v3361 = load i64, ptr %slot494, align 8
  %op3362 = sub i64 %v3361, 1
  store i64 %op3362, ptr %slot495, align 8
  %v3363 = load i64, ptr %slot495, align 8
  %cmp3364 = icmp eq i64 %v3363, 0
  %cv3365 = zext i1 %cmp3364 to i32
  store i32 %cv3365, ptr %slot496, align 8
  %v3366 = load i32, ptr %slot496, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcglast603, label %bb_rcgdec603
bb_rcglast603:
  %v3369 = load i64, ptr %slot487, align 8
  %op3370 = sub i64 %v3369, 32
  store i64 %op3370, ptr %slot497, align 8
  %v3371 = load i64, ptr %slot487, align 8
  %p3372 = inttoptr i64 %v3371 to ptr
  %rgep3373 = getelementptr i8, ptr %p3372, i64 -32
  %ld3374 = load i64, ptr %rgep3373, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3374, ptr %slot498, align 8
  %v3375 = load i64, ptr %slot498, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot499, align 8
  %v3378 = load i32, ptr %slot499, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcgdec603, label %bb_rcgslow603
bb_rcgslow603:
  %v3381 = load i64, ptr %slot486, align 8
  %v3382 = load i64, ptr %slot483, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3381, i64 %v3382) nomerge, !dbg !136
  br label %bb_rcgdone603
bb_rcgdec603:
  %v3383 = load i64, ptr %slot495, align 8
  %v3384 = load i64, ptr %slot487, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  %rgep3386 = getelementptr i8, ptr %p3385, i64 -24
  store i64 %v3383, ptr %rgep3386, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear603
bb_rcgclear603:
  %v3387 = load i64, ptr %slot483, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  store i64 0, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone603
bb_rcgdone603:
  br label %bb_rcslotdone587
bb_rcslotowner587:
  %v3389 = load i64, ptr %slot45, align 8
  store i64 %v3389, ptr %slot500, align 8
  %v3390 = load i64, ptr %slot483, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %ld3392 = load i64, ptr %p3391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3392, ptr %slot501, align 8
  %v3393 = load i64, ptr %slot501, align 8
  %cmp3394 = icmp ne i64 %v3393, 0
  %cv3395 = zext i1 %cmp3394 to i32
  store i32 %cv3395, ptr %slot502, align 8
  %v3396 = load i32, ptr %slot502, align 8
  %cv3397 = zext i32 %v3396 to i64
  %cond3398 = icmp ne i64 %cv3397, 0
  br i1 %cond3398, label %bb_rcgnn618, label %bb_rcgdone618
bb_rcgnn618:
  %v3399 = load i64, ptr %slot501, align 8
  %op3400 = sub i64 %v3399, 16
  store i64 %op3400, ptr %slot503, align 8
  %v3401 = load i64, ptr %slot501, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  %rgep3403 = getelementptr i8, ptr %p3402, i64 -16
  %ld3404 = load i64, ptr %rgep3403, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3404, ptr %slot504, align 8
  %v3405 = load i64, ptr %slot504, align 8
  %op3406 = and i64 %v3405, 4611686018427387906
  store i64 %op3406, ptr %slot505, align 8
  %v3407 = load i64, ptr %slot505, align 8
  %cmp3408 = icmp ne i64 %v3407, 0
  %cv3409 = zext i1 %cmp3408 to i32
  store i32 %cv3409, ptr %slot506, align 8
  %v3410 = load i32, ptr %slot506, align 8
  %cv3411 = zext i32 %v3410 to i64
  %cond3412 = icmp ne i64 %cv3411, 0
  br i1 %cond3412, label %bb_rcgclear618, label %bb_rcgcounted618
bb_rcgcounted618:
  %v3413 = load i64, ptr %slot501, align 8
  %op3414 = sub i64 %v3413, 32
  store i64 %op3414, ptr %slot507, align 8
  %v3415 = load i64, ptr %slot501, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %rgep3417 = getelementptr i8, ptr %p3416, i64 -32
  %ld3418 = load i64, ptr %rgep3417, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3418, ptr %slot508, align 8
  %v3419 = load i64, ptr %slot508, align 8
  %op3420 = sub i64 %v3419, 1
  store i64 %op3420, ptr %slot509, align 8
  %v3421 = load i64, ptr %slot509, align 8
  %cmp3422 = icmp eq i64 %v3421, 0
  %cv3423 = zext i1 %cmp3422 to i32
  store i32 %cv3423, ptr %slot510, align 8
  %v3424 = load i32, ptr %slot510, align 8
  %cv3425 = zext i32 %v3424 to i64
  %cond3426 = icmp ne i64 %cv3425, 0
  br i1 %cond3426, label %bb_rcglast618, label %bb_rcgdec618
bb_rcglast618:
  %v3427 = load i64, ptr %slot501, align 8
  %op3428 = sub i64 %v3427, 24
  store i64 %op3428, ptr %slot511, align 8
  %v3429 = load i64, ptr %slot501, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  %rgep3431 = getelementptr i8, ptr %p3430, i64 -24
  %ld3432 = load i64, ptr %rgep3431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3432, ptr %slot512, align 8
  %v3433 = load i64, ptr %slot512, align 8
  %cmp3434 = icmp ne i64 %v3433, 0
  %cv3435 = zext i1 %cmp3434 to i32
  store i32 %cv3435, ptr %slot513, align 8
  %v3436 = load i32, ptr %slot513, align 8
  %cv3437 = zext i32 %v3436 to i64
  %cond3438 = icmp ne i64 %cv3437, 0
  br i1 %cond3438, label %bb_rcgdec618, label %bb_rcgslow618
bb_rcgslow618:
  %v3439 = load i64, ptr %slot500, align 8
  %v3440 = load i64, ptr %slot483, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3439, i64 %v3440) nomerge, !dbg !136
  br label %bb_rcgdone618
bb_rcgdec618:
  %v3441 = load i64, ptr %slot509, align 8
  %v3442 = load i64, ptr %slot501, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  %rgep3444 = getelementptr i8, ptr %p3443, i64 -32
  store i64 %v3441, ptr %rgep3444, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear618
bb_rcgclear618:
  %v3445 = load i64, ptr %slot483, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  store i64 0, ptr %p3446, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone618
bb_rcgdone618:
  br label %bb_rcslotdone587
bb_rcslotdone587:
  %v3447 = load i64, ptr %slot39, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  %ld3449 = load i64, ptr %p3448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3449, ptr %slot514, align 8
  %v3450 = load i64, ptr %slot38, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i64, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3452, ptr %slot515, align 8
  %v3453 = load i64, ptr %slot515, align 8
  %v3454 = load i64, ptr %slot514, align 8
  %cmp3455 = icmp sge i64 %v3453, %v3454
  %cv3456 = zext i1 %cmp3455 to i64
  store i64 %cv3456, ptr %slot516, align 8
  %v3457 = load i64, ptr %slot516, align 8
  %v3458 = load i64, ptr %slot38, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  store i64 %v3457, ptr %p3459, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i33:
  %v3460 = load i64, ptr %slot38, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  %ld3462 = load i64, ptr %p3461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3462, ptr %slot517, align 8
  %v3463 = load i64, ptr %slot517, align 8
  %op3464 = xor i64 %v3463, 1
  store i64 %op3464, ptr %slot518, align 8
  %v3465 = load i64, ptr %slot518, align 8
  %v3466 = load i64, ptr %slot38, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  store i64 %v3465, ptr %p3467, align 8, !alias.scope !3, !noalias !4
  br label %bb_i36
bb_i35:
  %v3468 = load i64, ptr %slot38, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  store i64 0, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  br label %bb_i36
bb_i36:
  %v3470 = load i64, ptr %slot38, align 8
  %p3471 = inttoptr i64 %v3470 to ptr
  %ld3472 = load i64, ptr %p3471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3472, ptr %slot519, align 8
  %v3473 = load i64, ptr %slot519, align 8
  %cond3474 = icmp ne i64 %v3473, 0
  br i1 %cond3474, label %bb_next628, label %bb_i92
bb_next628:
  %v3475 = load i64, ptr %slot28, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %ld3477 = load i64, ptr %p3476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3477, ptr %slot520, align 8
  %v3478 = load i64, ptr %slot520, align 8
  %v3479 = load i64, ptr %slot38, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i64 %v3478, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot38, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i64, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3483, ptr %slot521, align 8
  %v3484 = load i64, ptr %slot17, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %ld3486 = load i32, ptr %p3485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3486, ptr %slot522, align 8
  %v3487 = load i64, ptr %slot18, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  %ld3489 = load i32, ptr %p3488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3489, ptr %slot523, align 8
  %v3490 = load i32, ptr %slot523, align 8
  %op3491 = and i32 %v3490, 24
  store i32 %op3491, ptr %slot523, align 8
  %v3492 = load i32, ptr %slot523, align 8
  %cmp3493 = icmp eq i32 %v3492, 0
  %cv3494 = zext i1 %cmp3493 to i32
  store i32 %cv3494, ptr %slot524, align 8
  %v3495 = load i32, ptr %slot522, align 8
  %v3496 = load i32, ptr %slot524, align 8
  %op3497 = and i32 %v3495, %v3496
  store i32 %op3497, ptr %slot525, align 8
  %v3498 = load i32, ptr %slot525, align 8
  %cv3499 = zext i32 %v3498 to i64
  %cond3500 = icmp ne i64 %cv3499, 0
  br i1 %cond3500, label %bb_rctake630, label %bb_rccopy630
bb_rctake630:
  %v3501 = load i64, ptr %slot27, align 8
  store i64 %v3501, ptr %slot526, align 8
  %v3502 = load i64, ptr %slot46, align 8
  store i64 %v3502, ptr %slot527, align 8
  %v3503 = load i64, ptr %slot521, align 8
  %v3504 = load i64, ptr %slot526, align 8
  %op3505 = sub i64 %v3503, %v3504
  store i64 %op3505, ptr %slot528, align 8
  %v3506 = load i64, ptr %slot526, align 8
  %v3507 = load i64, ptr %slot521, align 8
  %op3508 = sub i64 %v3506, %v3507
  store i64 %op3508, ptr %slot529, align 8
  %v3509 = load i64, ptr %slot528, align 8
  %cmp3510 = icmp ult i64 %v3509, 32
  %cv3511 = zext i1 %cmp3510 to i32
  store i32 %cv3511, ptr %slot530, align 8
  %v3512 = load i64, ptr %slot529, align 8
  %cmp3513 = icmp ult i64 %v3512, 32
  %cv3514 = zext i1 %cmp3513 to i32
  store i32 %cv3514, ptr %slot531, align 8
  %v3515 = load i32, ptr %slot530, align 8
  %v3516 = load i32, ptr %slot531, align 8
  %op3517 = or i32 %v3515, %v3516
  store i32 %op3517, ptr %slot532, align 8
  %v3518 = load i32, ptr %slot532, align 8
  %cv3519 = zext i32 %v3518 to i64
  %cond3520 = icmp ne i64 %cv3519, 0
  br i1 %cond3520, label %bb_rcmoveslow639, label %bb_rcmovecheck639
bb_rcmovecheck639:
  %v3521 = load i64, ptr %slot521, align 8
  %op3522 = add i64 %v3521, 0
  store i64 %op3522, ptr %slot533, align 8
  %v3523 = load i64, ptr %slot533, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %ld3525 = load i64, ptr %p3524, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3525, ptr %slot534, align 8
  %v3526 = load i64, ptr %slot534, align 8
  %cmp3527 = icmp ne i64 %v3526, 0
  %cv3528 = zext i1 %cmp3527 to i32
  store i32 %cv3528, ptr %slot535, align 8
  %v3529 = load i32, ptr %slot535, align 8
  %cv3530 = zext i32 %v3529 to i64
  %cond3531 = icmp ne i64 %cv3530, 0
  br i1 %cond3531, label %bb_rcmoveheader647, label %bb_rcmovenext647
bb_rcmoveheader647:
  %v3532 = load i64, ptr %slot534, align 8
  %op3533 = sub i64 %v3532, 16
  store i64 %op3533, ptr %slot536, align 8
  %v3534 = load i64, ptr %slot534, align 8
  %p3535 = inttoptr i64 %v3534 to ptr
  %rgep3536 = getelementptr i8, ptr %p3535, i64 -16
  %ld3537 = load i64, ptr %rgep3536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3537, ptr %slot537, align 8
  %v3538 = load i64, ptr %slot537, align 8
  %op3539 = and i64 %v3538, 5764607523034234881
  store i64 %op3539, ptr %slot538, align 8
  %v3540 = load i64, ptr %slot538, align 8
  %cmp3541 = icmp ne i64 %v3540, 0
  %cv3542 = zext i1 %cmp3541 to i32
  store i32 %cv3542, ptr %slot539, align 8
  %v3543 = load i32, ptr %slot539, align 8
  %cv3544 = zext i32 %v3543 to i64
  %cond3545 = icmp ne i64 %cv3544, 0
  br i1 %cond3545, label %bb_rcmoveslow639, label %bb_rcmovenext647
bb_rcmovenext647:
  %v3546 = load i64, ptr %slot521, align 8
  %v3547 = load i64, ptr %slot526, align 8
  %p3548 = inttoptr i64 %v3546 to ptr
  %p3549 = inttoptr i64 %v3547 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3549, ptr %p3548, i64 32, i1 false), !alias.scope !10000000
  %v3550 = load i64, ptr %slot521, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  store i64 0, ptr %p3551, align 8, !alias.scope !4, !noalias !3
  %v3552 = load i64, ptr %slot521, align 8
  %op3553 = add i64 %v3552, 8
  store i64 %op3553, ptr %slot540, align 8
  %v3554 = load i64, ptr %slot540, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  store i64 0, ptr %p3555, align 8, !alias.scope !4, !noalias !3
  %v3556 = load i64, ptr %slot521, align 8
  %op3557 = add i64 %v3556, 16
  store i64 %op3557, ptr %slot541, align 8
  %v3558 = load i64, ptr %slot541, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  store i64 0, ptr %p3559, align 8, !alias.scope !4, !noalias !3
  %v3560 = load i64, ptr %slot521, align 8
  %op3561 = add i64 %v3560, 24
  store i64 %op3561, ptr %slot542, align 8
  %v3562 = load i64, ptr %slot542, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  store i64 0, ptr %p3563, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved639
bb_rcmoveslow639:
  %v3564 = load i64, ptr %slot45, align 8
  %v3565 = load i64, ptr %slot526, align 8
  %v3566 = load i64, ptr %slot521, align 8
  %v3567 = load i64, ptr %slot527, align 8
  %cv3568 = trunc i64 %v3567 to i32
  %call3569 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3564, i64 %v3565, i64 %v3566, i32 %cv3568) nomerge, !dbg !138
  store i32 %call3569, ptr %slot543, align 8
  %v3570 = load i32, ptr %slot543, align 8
  %cv3571 = zext i32 %v3570 to i64
  %cond3572 = icmp ne i64 %cv3571, 0
  br i1 %cond3572, label %bb_rcsuccess657, label %bb_rcfailure657
bb_rcfailure657:
  %v3573 = load i64, ptr %slot45, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %call3575 = call i32 @myl_rc_take_failure(ptr %p3574) nomerge, !dbg !138
  store i32 %call3575, ptr %slot544, align 8
  %v3576 = load i64, ptr %slot1, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %v3578 = load i32, ptr %slot544, align 8
  %call3579 = call i32 @myl_qbe_rc_status(ptr %p3577, i32 %v3578) nomerge, !dbg !138
  store i32 %call3579, ptr %slot545, align 8
  br label %bb_failure
bb_rcsuccess657:
  br label %bb_rcmoved639
bb_rcmoved639:
  %v3580 = load i64, ptr %slot17, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  store i32 0, ptr %p3581, align 4, !alias.scope !3, !noalias !4
  %v3582 = load i64, ptr %slot22, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  store i32 2, ptr %p3583, align 4, !alias.scope !3, !noalias !4
  %v3584 = load i64, ptr %slot21, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i32 1, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared630
bb_rccopy630:
  %v3586 = load i64, ptr %slot27, align 8
  store i64 %v3586, ptr %slot546, align 8
  %v3587 = load i64, ptr %slot46, align 8
  store i64 %v3587, ptr %slot547, align 8
  %v3588 = load i64, ptr %slot45, align 8
  %v3589 = load i64, ptr %slot546, align 8
  %v3590 = load i64, ptr %slot521, align 8
  %v3591 = load i64, ptr %slot547, align 8
  %cv3592 = trunc i64 %v3591 to i32
  %call3593 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3588, i64 %v3589, i64 %v3590, i32 %cv3592) nomerge, !dbg !138
  store i32 %call3593, ptr %slot548, align 8
  %v3594 = load i32, ptr %slot548, align 8
  %cv3595 = zext i32 %v3594 to i64
  %cond3596 = icmp ne i64 %cv3595, 0
  br i1 %cond3596, label %bb_rcsuccess666, label %bb_rcfailure666
bb_rcfailure666:
  %v3597 = load i64, ptr %slot45, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  %call3599 = call i32 @myl_rc_take_failure(ptr %p3598) nomerge, !dbg !138
  store i32 %call3599, ptr %slot549, align 8
  %v3600 = load i64, ptr %slot1, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %v3602 = load i32, ptr %slot549, align 8
  %call3603 = call i32 @myl_qbe_rc_status(ptr %p3601, i32 %v3602) nomerge, !dbg !138
  store i32 %call3603, ptr %slot550, align 8
  br label %bb_failure
bb_rcsuccess666:
  %v3604 = load i64, ptr %slot22, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  store i32 2, ptr %p3605, align 4, !alias.scope !3, !noalias !4
  %v3606 = load i64, ptr %slot21, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  store i32 1, ptr %p3607, align 4, !alias.scope !3, !noalias !4
  %v3608 = load i64, ptr %slot17, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i32, ptr %p3609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3610, ptr %slot551, align 8
  %v3611 = load i32, ptr %slot551, align 8
  %cv3612 = zext i32 %v3611 to i64
  %cond3613 = icmp ne i64 %cv3612, 0
  br i1 %cond3613, label %bb_rcslotdrop673, label %bb_rcslotdone673
bb_rcslotdrop673:
  %v3614 = load i64, ptr %slot17, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i32 0, ptr %p3615, align 4, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot23, align 8
  store i64 %v3616, ptr %slot552, align 8
  %v3617 = load i64, ptr %slot18, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  %ld3619 = load i32, ptr %p3618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3619, ptr %slot553, align 8
  %v3620 = load i32, ptr %slot553, align 8
  %op3621 = and i32 %v3620, 28
  store i32 %op3621, ptr %slot554, align 8
  %v3622 = load i32, ptr %slot554, align 8
  %cv3623 = zext i32 %v3622 to i64
  %cond3624 = icmp ne i64 %cv3623, 0
  br i1 %cond3624, label %bb_rcslotrole673, label %bb_rcslotowner673
bb_rcslotrole673:
  %v3625 = load i64, ptr %slot45, align 8
  store i64 %v3625, ptr %slot555, align 8
  %v3626 = load i64, ptr %slot555, align 8
  %v3627 = load i64, ptr %slot552, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3626, i64 %v3627) nomerge, !dbg !138
  br label %bb_rcslotdone673
bb_rcslotowner673:
  %v3628 = load i64, ptr %slot552, align 8
  %p3630 = inttoptr i64 %v3628 to ptr
  %gep3631 = getelementptr i8, ptr %p3630, i64 0
  %op3629 = ptrtoint ptr %gep3631 to i64
  store i64 %op3629, ptr %slot556, align 8
  %v3632 = load i64, ptr %slot45, align 8
  store i64 %v3632, ptr %slot557, align 8
  %v3633 = load i64, ptr %slot556, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  %ld3635 = load i64, ptr %p3634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3635, ptr %slot558, align 8
  %v3636 = load i64, ptr %slot558, align 8
  %cmp3637 = icmp ne i64 %v3636, 0
  %cv3638 = zext i1 %cmp3637 to i32
  store i32 %cv3638, ptr %slot559, align 8
  %v3639 = load i32, ptr %slot559, align 8
  %cv3640 = zext i32 %v3639 to i64
  %cond3641 = icmp ne i64 %cv3640, 0
  br i1 %cond3641, label %bb_rcgnn691, label %bb_rcgdone691
bb_rcgnn691:
  %v3642 = load i64, ptr %slot558, align 8
  %op3643 = sub i64 %v3642, 16
  store i64 %op3643, ptr %slot560, align 8
  %v3644 = load i64, ptr %slot558, align 8
  %p3645 = inttoptr i64 %v3644 to ptr
  %rgep3646 = getelementptr i8, ptr %p3645, i64 -16
  %ld3647 = load i64, ptr %rgep3646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3647, ptr %slot561, align 8
  %v3648 = load i64, ptr %slot561, align 8
  %op3649 = and i64 %v3648, 4611686018427387906
  store i64 %op3649, ptr %slot562, align 8
  %v3650 = load i64, ptr %slot562, align 8
  %cmp3651 = icmp ne i64 %v3650, 0
  %cv3652 = zext i1 %cmp3651 to i32
  store i32 %cv3652, ptr %slot563, align 8
  %v3653 = load i32, ptr %slot563, align 8
  %cv3654 = zext i32 %v3653 to i64
  %cond3655 = icmp ne i64 %cv3654, 0
  br i1 %cond3655, label %bb_rcgclear691, label %bb_rcgcounted691
bb_rcgcounted691:
  %v3656 = load i64, ptr %slot558, align 8
  %op3657 = sub i64 %v3656, 32
  store i64 %op3657, ptr %slot564, align 8
  %v3658 = load i64, ptr %slot558, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  %rgep3660 = getelementptr i8, ptr %p3659, i64 -32
  %ld3661 = load i64, ptr %rgep3660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3661, ptr %slot565, align 8
  %v3662 = load i64, ptr %slot565, align 8
  %op3663 = sub i64 %v3662, 1
  store i64 %op3663, ptr %slot566, align 8
  %v3664 = load i64, ptr %slot566, align 8
  %cmp3665 = icmp eq i64 %v3664, 0
  %cv3666 = zext i1 %cmp3665 to i32
  store i32 %cv3666, ptr %slot567, align 8
  %v3667 = load i32, ptr %slot567, align 8
  %cv3668 = zext i32 %v3667 to i64
  %cond3669 = icmp ne i64 %cv3668, 0
  br i1 %cond3669, label %bb_rcglast691, label %bb_rcgdec691
bb_rcglast691:
  %v3670 = load i64, ptr %slot558, align 8
  %op3671 = sub i64 %v3670, 24
  store i64 %op3671, ptr %slot568, align 8
  %v3672 = load i64, ptr %slot558, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %rgep3674 = getelementptr i8, ptr %p3673, i64 -24
  %ld3675 = load i64, ptr %rgep3674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3675, ptr %slot569, align 8
  %v3676 = load i64, ptr %slot569, align 8
  %cmp3677 = icmp ne i64 %v3676, 0
  %cv3678 = zext i1 %cmp3677 to i32
  store i32 %cv3678, ptr %slot570, align 8
  %v3679 = load i32, ptr %slot570, align 8
  %cv3680 = zext i32 %v3679 to i64
  %cond3681 = icmp ne i64 %cv3680, 0
  br i1 %cond3681, label %bb_rcgdec691, label %bb_rcgslow691
bb_rcgslow691:
  %v3682 = load i64, ptr %slot557, align 8
  %v3683 = load i64, ptr %slot556, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3682, i64 %v3683) nomerge, !dbg !138
  br label %bb_rcgdone691
bb_rcgdec691:
  %v3684 = load i64, ptr %slot566, align 8
  %v3685 = load i64, ptr %slot558, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  %rgep3687 = getelementptr i8, ptr %p3686, i64 -32
  store i64 %v3684, ptr %rgep3687, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear691
bb_rcgclear691:
  %v3688 = load i64, ptr %slot556, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  store i64 0, ptr %p3689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone691
bb_rcgdone691:
  %v3690 = load i64, ptr %slot552, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  store i64 0, ptr %p3691, align 8, !alias.scope !3, !noalias !4
  %v3692 = load i64, ptr %slot552, align 8
  %p3694 = inttoptr i64 %v3692 to ptr
  %gep3695 = getelementptr i8, ptr %p3694, i64 8
  %op3693 = ptrtoint ptr %gep3695 to i64
  store i64 %op3693, ptr %slot571, align 8
  %v3696 = load i64, ptr %slot571, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  store i64 0, ptr %p3697, align 8, !alias.scope !3, !noalias !4
  %v3698 = load i64, ptr %slot552, align 8
  %p3700 = inttoptr i64 %v3698 to ptr
  %gep3701 = getelementptr i8, ptr %p3700, i64 16
  %op3699 = ptrtoint ptr %gep3701 to i64
  store i64 %op3699, ptr %slot572, align 8
  %v3702 = load i64, ptr %slot572, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  store i64 0, ptr %p3703, align 8, !alias.scope !3, !noalias !4
  %v3704 = load i64, ptr %slot552, align 8
  %p3706 = inttoptr i64 %v3704 to ptr
  %gep3707 = getelementptr i8, ptr %p3706, i64 24
  %op3705 = ptrtoint ptr %gep3707 to i64
  store i64 %op3705, ptr %slot573, align 8
  %v3708 = load i64, ptr %slot573, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i64 0, ptr %p3709, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone673
bb_rcslotdone673:
  br label %bb_rcprepared630
bb_rcprepared630:
  %v3710 = load i64, ptr %slot11, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %ld3712 = load i32, ptr %p3711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3712, ptr %slot574, align 8
  %v3713 = load i32, ptr %slot574, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcslotdrop701, label %bb_rcslotdone701
bb_rcslotdrop701:
  %v3716 = load i64, ptr %slot11, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i32 0, ptr %p3717, align 4, !alias.scope !3, !noalias !4
  %v3718 = load i64, ptr %slot35, align 8
  store i64 %v3718, ptr %slot575, align 8
  %v3719 = load i64, ptr %slot12, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i32, ptr %p3720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3721, ptr %slot576, align 8
  %v3722 = load i32, ptr %slot576, align 8
  %op3723 = and i32 %v3722, 28
  store i32 %op3723, ptr %slot577, align 8
  %v3724 = load i32, ptr %slot577, align 8
  %cv3725 = zext i32 %v3724 to i64
  %cond3726 = icmp ne i64 %cv3725, 0
  br i1 %cond3726, label %bb_rcslotrole701, label %bb_rcslotowner701
bb_rcslotrole701:
  %v3727 = load i64, ptr %slot45, align 8
  store i64 %v3727, ptr %slot578, align 8
  %v3728 = load i64, ptr %slot578, align 8
  %v3729 = load i64, ptr %slot575, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3728, i64 %v3729) nomerge, !dbg !138
  br label %bb_rcslotdone701
bb_rcslotowner701:
  %v3730 = load i64, ptr %slot575, align 8
  %p3732 = inttoptr i64 %v3730 to ptr
  %gep3733 = getelementptr i8, ptr %p3732, i64 0
  %op3731 = ptrtoint ptr %gep3733 to i64
  store i64 %op3731, ptr %slot579, align 8
  %v3734 = load i64, ptr %slot45, align 8
  store i64 %v3734, ptr %slot580, align 8
  %v3735 = load i64, ptr %slot579, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %ld3737 = load i64, ptr %p3736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3737, ptr %slot581, align 8
  %v3738 = load i64, ptr %slot581, align 8
  %cmp3739 = icmp ne i64 %v3738, 0
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot582, align 8
  %v3741 = load i32, ptr %slot582, align 8
  %cv3742 = zext i32 %v3741 to i64
  %cond3743 = icmp ne i64 %cv3742, 0
  br i1 %cond3743, label %bb_rcgnn719, label %bb_rcgdone719
bb_rcgnn719:
  %v3744 = load i64, ptr %slot581, align 8
  %op3745 = sub i64 %v3744, 16
  store i64 %op3745, ptr %slot583, align 8
  %v3746 = load i64, ptr %slot581, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %rgep3748 = getelementptr i8, ptr %p3747, i64 -16
  %ld3749 = load i64, ptr %rgep3748, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3749, ptr %slot584, align 8
  %v3750 = load i64, ptr %slot584, align 8
  %op3751 = and i64 %v3750, 4611686018427387906
  store i64 %op3751, ptr %slot585, align 8
  %v3752 = load i64, ptr %slot585, align 8
  %cmp3753 = icmp ne i64 %v3752, 0
  %cv3754 = zext i1 %cmp3753 to i32
  store i32 %cv3754, ptr %slot586, align 8
  %v3755 = load i32, ptr %slot586, align 8
  %cv3756 = zext i32 %v3755 to i64
  %cond3757 = icmp ne i64 %cv3756, 0
  br i1 %cond3757, label %bb_rcgclear719, label %bb_rcgcounted719
bb_rcgcounted719:
  %v3758 = load i64, ptr %slot581, align 8
  %op3759 = sub i64 %v3758, 32
  store i64 %op3759, ptr %slot587, align 8
  %v3760 = load i64, ptr %slot581, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  %rgep3762 = getelementptr i8, ptr %p3761, i64 -32
  %ld3763 = load i64, ptr %rgep3762, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3763, ptr %slot588, align 8
  %v3764 = load i64, ptr %slot588, align 8
  %op3765 = sub i64 %v3764, 1
  store i64 %op3765, ptr %slot589, align 8
  %v3766 = load i64, ptr %slot589, align 8
  %cmp3767 = icmp eq i64 %v3766, 0
  %cv3768 = zext i1 %cmp3767 to i32
  store i32 %cv3768, ptr %slot590, align 8
  %v3769 = load i32, ptr %slot590, align 8
  %cv3770 = zext i32 %v3769 to i64
  %cond3771 = icmp ne i64 %cv3770, 0
  br i1 %cond3771, label %bb_rcglast719, label %bb_rcgdec719
bb_rcglast719:
  %v3772 = load i64, ptr %slot581, align 8
  %op3773 = sub i64 %v3772, 24
  store i64 %op3773, ptr %slot591, align 8
  %v3774 = load i64, ptr %slot581, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  %rgep3776 = getelementptr i8, ptr %p3775, i64 -24
  %ld3777 = load i64, ptr %rgep3776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3777, ptr %slot592, align 8
  %v3778 = load i64, ptr %slot592, align 8
  %cmp3779 = icmp ne i64 %v3778, 0
  %cv3780 = zext i1 %cmp3779 to i32
  store i32 %cv3780, ptr %slot593, align 8
  %v3781 = load i32, ptr %slot593, align 8
  %cv3782 = zext i32 %v3781 to i64
  %cond3783 = icmp ne i64 %cv3782, 0
  br i1 %cond3783, label %bb_rcgdec719, label %bb_rcgslow719
bb_rcgslow719:
  %v3784 = load i64, ptr %slot580, align 8
  %v3785 = load i64, ptr %slot579, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3784, i64 %v3785) nomerge, !dbg !138
  br label %bb_rcgdone719
bb_rcgdec719:
  %v3786 = load i64, ptr %slot589, align 8
  %v3787 = load i64, ptr %slot581, align 8
  %p3788 = inttoptr i64 %v3787 to ptr
  %rgep3789 = getelementptr i8, ptr %p3788, i64 -32
  store i64 %v3786, ptr %rgep3789, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear719
bb_rcgclear719:
  %v3790 = load i64, ptr %slot579, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  store i64 0, ptr %p3791, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone719
bb_rcgdone719:
  %v3792 = load i64, ptr %slot575, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  store i64 0, ptr %p3793, align 8, !alias.scope !3, !noalias !4
  %v3794 = load i64, ptr %slot575, align 8
  %p3796 = inttoptr i64 %v3794 to ptr
  %gep3797 = getelementptr i8, ptr %p3796, i64 8
  %op3795 = ptrtoint ptr %gep3797 to i64
  store i64 %op3795, ptr %slot594, align 8
  %v3798 = load i64, ptr %slot594, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  store i64 0, ptr %p3799, align 8, !alias.scope !3, !noalias !4
  %v3800 = load i64, ptr %slot575, align 8
  %p3802 = inttoptr i64 %v3800 to ptr
  %gep3803 = getelementptr i8, ptr %p3802, i64 16
  %op3801 = ptrtoint ptr %gep3803 to i64
  store i64 %op3801, ptr %slot595, align 8
  %v3804 = load i64, ptr %slot595, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i64 0, ptr %p3805, align 8, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot575, align 8
  %p3808 = inttoptr i64 %v3806 to ptr
  %gep3809 = getelementptr i8, ptr %p3808, i64 24
  %op3807 = ptrtoint ptr %gep3809 to i64
  store i64 %op3807, ptr %slot596, align 8
  %v3810 = load i64, ptr %slot596, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i64 0, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone701
bb_rcslotdone701:
  %v3812 = load i64, ptr %slot35, align 8
  store i64 %v3812, ptr %slot597, align 8
  %v3813 = load i64, ptr %slot27, align 8
  store i64 %v3813, ptr %slot598, align 8
  %v3814 = load i64, ptr %slot598, align 8
  %v3815 = load i64, ptr %slot597, align 8
  %p3816 = inttoptr i64 %v3814 to ptr
  %p3817 = inttoptr i64 %v3815 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3817, ptr %p3816, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot21, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  store i32 0, ptr %p3819, align 4, !alias.scope !3, !noalias !4
  %v3820 = load i64, ptr %slot12, align 8
  %p3821 = inttoptr i64 %v3820 to ptr
  store i32 2, ptr %p3821, align 4, !alias.scope !3, !noalias !4
  %v3822 = load i64, ptr %slot22, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i32, ptr %p3823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3824, ptr %slot599, align 8
  %v3825 = load i32, ptr %slot599, align 8
  %v3826 = load i64, ptr %slot12, align 8
  %p3827 = inttoptr i64 %v3826 to ptr
  store i32 %v3825, ptr %p3827, align 4, !alias.scope !3, !noalias !4
  %v3828 = load i64, ptr %slot11, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i32 1, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot35, align 8
  %v3831 = load i64, ptr %slot38, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  store i64 %v3830, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  %v3833 = load i64, ptr %slot38, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %ld3835 = load i64, ptr %p3834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3835, ptr %slot600, align 8
  %v3836 = load i64, ptr %slot17, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  %ld3838 = load i32, ptr %p3837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3838, ptr %slot601, align 8
  %v3839 = load i64, ptr %slot18, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %ld3841 = load i32, ptr %p3840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3841, ptr %slot602, align 8
  %v3842 = load i32, ptr %slot602, align 8
  %op3843 = and i32 %v3842, 24
  store i32 %op3843, ptr %slot602, align 8
  %v3844 = load i32, ptr %slot602, align 8
  %cmp3845 = icmp eq i32 %v3844, 0
  %cv3846 = zext i1 %cmp3845 to i32
  store i32 %cv3846, ptr %slot603, align 8
  %v3847 = load i32, ptr %slot601, align 8
  %v3848 = load i32, ptr %slot603, align 8
  %op3849 = and i32 %v3847, %v3848
  store i32 %op3849, ptr %slot604, align 8
  %v3850 = load i32, ptr %slot604, align 8
  %cv3851 = zext i32 %v3850 to i64
  %cond3852 = icmp ne i64 %cv3851, 0
  br i1 %cond3852, label %bb_rctake734, label %bb_rccopy734
bb_rctake734:
  %v3853 = load i64, ptr %slot27, align 8
  store i64 %v3853, ptr %slot605, align 8
  %v3854 = load i64, ptr %slot46, align 8
  store i64 %v3854, ptr %slot606, align 8
  %v3855 = load i64, ptr %slot600, align 8
  %v3856 = load i64, ptr %slot605, align 8
  %op3857 = sub i64 %v3855, %v3856
  store i64 %op3857, ptr %slot607, align 8
  %v3858 = load i64, ptr %slot605, align 8
  %v3859 = load i64, ptr %slot600, align 8
  %op3860 = sub i64 %v3858, %v3859
  store i64 %op3860, ptr %slot608, align 8
  %v3861 = load i64, ptr %slot607, align 8
  %cmp3862 = icmp ult i64 %v3861, 32
  %cv3863 = zext i1 %cmp3862 to i32
  store i32 %cv3863, ptr %slot609, align 8
  %v3864 = load i64, ptr %slot608, align 8
  %cmp3865 = icmp ult i64 %v3864, 32
  %cv3866 = zext i1 %cmp3865 to i32
  store i32 %cv3866, ptr %slot610, align 8
  %v3867 = load i32, ptr %slot609, align 8
  %v3868 = load i32, ptr %slot610, align 8
  %op3869 = or i32 %v3867, %v3868
  store i32 %op3869, ptr %slot611, align 8
  %v3870 = load i32, ptr %slot611, align 8
  %cv3871 = zext i32 %v3870 to i64
  %cond3872 = icmp ne i64 %cv3871, 0
  br i1 %cond3872, label %bb_rcmoveslow743, label %bb_rcmovecheck743
bb_rcmovecheck743:
  %v3873 = load i64, ptr %slot600, align 8
  %op3874 = add i64 %v3873, 0
  store i64 %op3874, ptr %slot612, align 8
  %v3875 = load i64, ptr %slot612, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  %ld3877 = load i64, ptr %p3876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3877, ptr %slot613, align 8
  %v3878 = load i64, ptr %slot613, align 8
  %cmp3879 = icmp ne i64 %v3878, 0
  %cv3880 = zext i1 %cmp3879 to i32
  store i32 %cv3880, ptr %slot614, align 8
  %v3881 = load i32, ptr %slot614, align 8
  %cv3882 = zext i32 %v3881 to i64
  %cond3883 = icmp ne i64 %cv3882, 0
  br i1 %cond3883, label %bb_rcmoveheader751, label %bb_rcmovenext751
bb_rcmoveheader751:
  %v3884 = load i64, ptr %slot613, align 8
  %op3885 = sub i64 %v3884, 16
  store i64 %op3885, ptr %slot615, align 8
  %v3886 = load i64, ptr %slot613, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %rgep3888 = getelementptr i8, ptr %p3887, i64 -16
  %ld3889 = load i64, ptr %rgep3888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3889, ptr %slot616, align 8
  %v3890 = load i64, ptr %slot616, align 8
  %op3891 = and i64 %v3890, 5764607523034234881
  store i64 %op3891, ptr %slot617, align 8
  %v3892 = load i64, ptr %slot617, align 8
  %cmp3893 = icmp ne i64 %v3892, 0
  %cv3894 = zext i1 %cmp3893 to i32
  store i32 %cv3894, ptr %slot618, align 8
  %v3895 = load i32, ptr %slot618, align 8
  %cv3896 = zext i32 %v3895 to i64
  %cond3897 = icmp ne i64 %cv3896, 0
  br i1 %cond3897, label %bb_rcmoveslow743, label %bb_rcmovenext751
bb_rcmovenext751:
  %v3898 = load i64, ptr %slot600, align 8
  %v3899 = load i64, ptr %slot605, align 8
  %p3900 = inttoptr i64 %v3898 to ptr
  %p3901 = inttoptr i64 %v3899 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3901, ptr %p3900, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3902 = load i64, ptr %slot600, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  store i64 0, ptr %p3903, align 8, !alias.scope !3, !noalias !4
  %v3904 = load i64, ptr %slot600, align 8
  %op3905 = add i64 %v3904, 8
  store i64 %op3905, ptr %slot619, align 8
  %v3906 = load i64, ptr %slot619, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  store i64 0, ptr %p3907, align 8, !alias.scope !3, !noalias !4
  %v3908 = load i64, ptr %slot600, align 8
  %op3909 = add i64 %v3908, 16
  store i64 %op3909, ptr %slot620, align 8
  %v3910 = load i64, ptr %slot620, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i64 0, ptr %p3911, align 8, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot600, align 8
  %op3913 = add i64 %v3912, 24
  store i64 %op3913, ptr %slot621, align 8
  %v3914 = load i64, ptr %slot621, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  store i64 0, ptr %p3915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved743
bb_rcmoveslow743:
  %v3916 = load i64, ptr %slot45, align 8
  %v3917 = load i64, ptr %slot605, align 8
  %v3918 = load i64, ptr %slot600, align 8
  %v3919 = load i64, ptr %slot606, align 8
  %cv3920 = trunc i64 %v3919 to i32
  %call3921 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3916, i64 %v3917, i64 %v3918, i32 %cv3920) nomerge, !dbg !140
  store i32 %call3921, ptr %slot622, align 8
  %v3922 = load i32, ptr %slot622, align 8
  %cv3923 = zext i32 %v3922 to i64
  %cond3924 = icmp ne i64 %cv3923, 0
  br i1 %cond3924, label %bb_rcsuccess761, label %bb_rcfailure761
bb_rcfailure761:
  %v3925 = load i64, ptr %slot45, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %call3927 = call i32 @myl_rc_take_failure(ptr %p3926) nomerge, !dbg !140
  store i32 %call3927, ptr %slot623, align 8
  %v3928 = load i64, ptr %slot1, align 8
  %p3929 = inttoptr i64 %v3928 to ptr
  %v3930 = load i32, ptr %slot623, align 8
  %call3931 = call i32 @myl_qbe_rc_status(ptr %p3929, i32 %v3930) nomerge, !dbg !140
  store i32 %call3931, ptr %slot624, align 8
  br label %bb_failure
bb_rcsuccess761:
  br label %bb_rcmoved743
bb_rcmoved743:
  %v3932 = load i64, ptr %slot17, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  store i32 0, ptr %p3933, align 4, !alias.scope !3, !noalias !4
  %v3934 = load i64, ptr %slot22, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  store i32 2, ptr %p3935, align 4, !alias.scope !3, !noalias !4
  %v3936 = load i64, ptr %slot21, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  store i32 1, ptr %p3937, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared734
bb_rccopy734:
  %v3938 = load i64, ptr %slot27, align 8
  store i64 %v3938, ptr %slot625, align 8
  %v3939 = load i64, ptr %slot46, align 8
  store i64 %v3939, ptr %slot626, align 8
  %v3940 = load i64, ptr %slot45, align 8
  %v3941 = load i64, ptr %slot625, align 8
  %v3942 = load i64, ptr %slot600, align 8
  %v3943 = load i64, ptr %slot626, align 8
  %cv3944 = trunc i64 %v3943 to i32
  %call3945 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3940, i64 %v3941, i64 %v3942, i32 %cv3944) nomerge, !dbg !140
  store i32 %call3945, ptr %slot627, align 8
  %v3946 = load i32, ptr %slot627, align 8
  %cv3947 = zext i32 %v3946 to i64
  %cond3948 = icmp ne i64 %cv3947, 0
  br i1 %cond3948, label %bb_rcsuccess770, label %bb_rcfailure770
bb_rcfailure770:
  %v3949 = load i64, ptr %slot45, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  %call3951 = call i32 @myl_rc_take_failure(ptr %p3950) nomerge, !dbg !140
  store i32 %call3951, ptr %slot628, align 8
  %v3952 = load i64, ptr %slot1, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %v3954 = load i32, ptr %slot628, align 8
  %call3955 = call i32 @myl_qbe_rc_status(ptr %p3953, i32 %v3954) nomerge, !dbg !140
  store i32 %call3955, ptr %slot629, align 8
  br label %bb_failure
bb_rcsuccess770:
  %v3956 = load i64, ptr %slot22, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  store i32 2, ptr %p3957, align 4, !alias.scope !3, !noalias !4
  %v3958 = load i64, ptr %slot21, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  store i32 1, ptr %p3959, align 4, !alias.scope !3, !noalias !4
  %v3960 = load i64, ptr %slot17, align 8
  %p3961 = inttoptr i64 %v3960 to ptr
  %ld3962 = load i32, ptr %p3961, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3962, ptr %slot630, align 8
  %v3963 = load i32, ptr %slot630, align 8
  %cv3964 = zext i32 %v3963 to i64
  %cond3965 = icmp ne i64 %cv3964, 0
  br i1 %cond3965, label %bb_rcslotdrop777, label %bb_rcslotdone777
bb_rcslotdrop777:
  %v3966 = load i64, ptr %slot17, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i32 0, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  %v3968 = load i64, ptr %slot23, align 8
  store i64 %v3968, ptr %slot631, align 8
  %v3969 = load i64, ptr %slot18, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  %ld3971 = load i32, ptr %p3970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3971, ptr %slot632, align 8
  %v3972 = load i32, ptr %slot632, align 8
  %op3973 = and i32 %v3972, 28
  store i32 %op3973, ptr %slot633, align 8
  %v3974 = load i32, ptr %slot633, align 8
  %cv3975 = zext i32 %v3974 to i64
  %cond3976 = icmp ne i64 %cv3975, 0
  br i1 %cond3976, label %bb_rcslotrole777, label %bb_rcslotowner777
bb_rcslotrole777:
  %v3977 = load i64, ptr %slot45, align 8
  store i64 %v3977, ptr %slot634, align 8
  %v3978 = load i64, ptr %slot634, align 8
  %v3979 = load i64, ptr %slot631, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3978, i64 %v3979) nomerge, !dbg !140
  br label %bb_rcslotdone777
bb_rcslotowner777:
  %v3980 = load i64, ptr %slot631, align 8
  %p3982 = inttoptr i64 %v3980 to ptr
  %gep3983 = getelementptr i8, ptr %p3982, i64 0
  %op3981 = ptrtoint ptr %gep3983 to i64
  store i64 %op3981, ptr %slot635, align 8
  %v3984 = load i64, ptr %slot45, align 8
  store i64 %v3984, ptr %slot636, align 8
  %v3985 = load i64, ptr %slot635, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  %ld3987 = load i64, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3987, ptr %slot637, align 8
  %v3988 = load i64, ptr %slot637, align 8
  %cmp3989 = icmp ne i64 %v3988, 0
  %cv3990 = zext i1 %cmp3989 to i32
  store i32 %cv3990, ptr %slot638, align 8
  %v3991 = load i32, ptr %slot638, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcgnn795, label %bb_rcgdone795
bb_rcgnn795:
  %v3994 = load i64, ptr %slot637, align 8
  %op3995 = sub i64 %v3994, 16
  store i64 %op3995, ptr %slot639, align 8
  %v3996 = load i64, ptr %slot637, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %rgep3998 = getelementptr i8, ptr %p3997, i64 -16
  %ld3999 = load i64, ptr %rgep3998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3999, ptr %slot640, align 8
  %v4000 = load i64, ptr %slot640, align 8
  %op4001 = and i64 %v4000, 4611686018427387906
  store i64 %op4001, ptr %slot641, align 8
  %v4002 = load i64, ptr %slot641, align 8
  %cmp4003 = icmp ne i64 %v4002, 0
  %cv4004 = zext i1 %cmp4003 to i32
  store i32 %cv4004, ptr %slot642, align 8
  %v4005 = load i32, ptr %slot642, align 8
  %cv4006 = zext i32 %v4005 to i64
  %cond4007 = icmp ne i64 %cv4006, 0
  br i1 %cond4007, label %bb_rcgclear795, label %bb_rcgcounted795
bb_rcgcounted795:
  %v4008 = load i64, ptr %slot637, align 8
  %op4009 = sub i64 %v4008, 32
  store i64 %op4009, ptr %slot643, align 8
  %v4010 = load i64, ptr %slot637, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  %rgep4012 = getelementptr i8, ptr %p4011, i64 -32
  %ld4013 = load i64, ptr %rgep4012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4013, ptr %slot644, align 8
  %v4014 = load i64, ptr %slot644, align 8
  %op4015 = sub i64 %v4014, 1
  store i64 %op4015, ptr %slot645, align 8
  %v4016 = load i64, ptr %slot645, align 8
  %cmp4017 = icmp eq i64 %v4016, 0
  %cv4018 = zext i1 %cmp4017 to i32
  store i32 %cv4018, ptr %slot646, align 8
  %v4019 = load i32, ptr %slot646, align 8
  %cv4020 = zext i32 %v4019 to i64
  %cond4021 = icmp ne i64 %cv4020, 0
  br i1 %cond4021, label %bb_rcglast795, label %bb_rcgdec795
bb_rcglast795:
  %v4022 = load i64, ptr %slot637, align 8
  %op4023 = sub i64 %v4022, 24
  store i64 %op4023, ptr %slot647, align 8
  %v4024 = load i64, ptr %slot637, align 8
  %p4025 = inttoptr i64 %v4024 to ptr
  %rgep4026 = getelementptr i8, ptr %p4025, i64 -24
  %ld4027 = load i64, ptr %rgep4026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4027, ptr %slot648, align 8
  %v4028 = load i64, ptr %slot648, align 8
  %cmp4029 = icmp ne i64 %v4028, 0
  %cv4030 = zext i1 %cmp4029 to i32
  store i32 %cv4030, ptr %slot649, align 8
  %v4031 = load i32, ptr %slot649, align 8
  %cv4032 = zext i32 %v4031 to i64
  %cond4033 = icmp ne i64 %cv4032, 0
  br i1 %cond4033, label %bb_rcgdec795, label %bb_rcgslow795
bb_rcgslow795:
  %v4034 = load i64, ptr %slot636, align 8
  %v4035 = load i64, ptr %slot635, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4034, i64 %v4035) nomerge, !dbg !140
  br label %bb_rcgdone795
bb_rcgdec795:
  %v4036 = load i64, ptr %slot645, align 8
  %v4037 = load i64, ptr %slot637, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %rgep4039 = getelementptr i8, ptr %p4038, i64 -32
  store i64 %v4036, ptr %rgep4039, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear795
bb_rcgclear795:
  %v4040 = load i64, ptr %slot635, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  store i64 0, ptr %p4041, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone795
bb_rcgdone795:
  %v4042 = load i64, ptr %slot631, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  store i64 0, ptr %p4043, align 8, !alias.scope !3, !noalias !4
  %v4044 = load i64, ptr %slot631, align 8
  %p4046 = inttoptr i64 %v4044 to ptr
  %gep4047 = getelementptr i8, ptr %p4046, i64 8
  %op4045 = ptrtoint ptr %gep4047 to i64
  store i64 %op4045, ptr %slot650, align 8
  %v4048 = load i64, ptr %slot650, align 8
  %p4049 = inttoptr i64 %v4048 to ptr
  store i64 0, ptr %p4049, align 8, !alias.scope !3, !noalias !4
  %v4050 = load i64, ptr %slot631, align 8
  %p4052 = inttoptr i64 %v4050 to ptr
  %gep4053 = getelementptr i8, ptr %p4052, i64 16
  %op4051 = ptrtoint ptr %gep4053 to i64
  store i64 %op4051, ptr %slot651, align 8
  %v4054 = load i64, ptr %slot651, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  store i64 0, ptr %p4055, align 8, !alias.scope !3, !noalias !4
  %v4056 = load i64, ptr %slot631, align 8
  %p4058 = inttoptr i64 %v4056 to ptr
  %gep4059 = getelementptr i8, ptr %p4058, i64 24
  %op4057 = ptrtoint ptr %gep4059 to i64
  store i64 %op4057, ptr %slot652, align 8
  %v4060 = load i64, ptr %slot652, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  store i64 0, ptr %p4061, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone777
bb_rcslotdone777:
  br label %bb_rcprepared734
bb_rcprepared734:
  %v4062 = load i64, ptr %slot13, align 8
  %p4063 = inttoptr i64 %v4062 to ptr
  %ld4064 = load i32, ptr %p4063, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4064, ptr %slot653, align 8
  %v4065 = load i32, ptr %slot653, align 8
  %cv4066 = zext i32 %v4065 to i64
  %cond4067 = icmp ne i64 %cv4066, 0
  br i1 %cond4067, label %bb_rcslotdrop805, label %bb_rcslotdone805
bb_rcslotdrop805:
  %v4068 = load i64, ptr %slot13, align 8
  %p4069 = inttoptr i64 %v4068 to ptr
  store i32 0, ptr %p4069, align 4, !alias.scope !3, !noalias !4
  %v4070 = load i64, ptr %slot36, align 8
  store i64 %v4070, ptr %slot654, align 8
  %v4071 = load i64, ptr %slot14, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %ld4073 = load i32, ptr %p4072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4073, ptr %slot655, align 8
  %v4074 = load i32, ptr %slot655, align 8
  %op4075 = and i32 %v4074, 28
  store i32 %op4075, ptr %slot656, align 8
  %v4076 = load i32, ptr %slot656, align 8
  %cv4077 = zext i32 %v4076 to i64
  %cond4078 = icmp ne i64 %cv4077, 0
  br i1 %cond4078, label %bb_rcslotrole805, label %bb_rcslotowner805
bb_rcslotrole805:
  %v4079 = load i64, ptr %slot45, align 8
  store i64 %v4079, ptr %slot657, align 8
  %v4080 = load i64, ptr %slot657, align 8
  %v4081 = load i64, ptr %slot654, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4080, i64 %v4081) nomerge, !dbg !140
  br label %bb_rcslotdone805
bb_rcslotowner805:
  %v4082 = load i64, ptr %slot654, align 8
  %p4084 = inttoptr i64 %v4082 to ptr
  %gep4085 = getelementptr i8, ptr %p4084, i64 0
  %op4083 = ptrtoint ptr %gep4085 to i64
  store i64 %op4083, ptr %slot658, align 8
  %v4086 = load i64, ptr %slot45, align 8
  store i64 %v4086, ptr %slot659, align 8
  %v4087 = load i64, ptr %slot658, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  %ld4089 = load i64, ptr %p4088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4089, ptr %slot660, align 8
  %v4090 = load i64, ptr %slot660, align 8
  %cmp4091 = icmp ne i64 %v4090, 0
  %cv4092 = zext i1 %cmp4091 to i32
  store i32 %cv4092, ptr %slot661, align 8
  %v4093 = load i32, ptr %slot661, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcgnn823, label %bb_rcgdone823
bb_rcgnn823:
  %v4096 = load i64, ptr %slot660, align 8
  %op4097 = sub i64 %v4096, 16
  store i64 %op4097, ptr %slot662, align 8
  %v4098 = load i64, ptr %slot660, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %rgep4100 = getelementptr i8, ptr %p4099, i64 -16
  %ld4101 = load i64, ptr %rgep4100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4101, ptr %slot663, align 8
  %v4102 = load i64, ptr %slot663, align 8
  %op4103 = and i64 %v4102, 4611686018427387906
  store i64 %op4103, ptr %slot664, align 8
  %v4104 = load i64, ptr %slot664, align 8
  %cmp4105 = icmp ne i64 %v4104, 0
  %cv4106 = zext i1 %cmp4105 to i32
  store i32 %cv4106, ptr %slot665, align 8
  %v4107 = load i32, ptr %slot665, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcgclear823, label %bb_rcgcounted823
bb_rcgcounted823:
  %v4110 = load i64, ptr %slot660, align 8
  %op4111 = sub i64 %v4110, 32
  store i64 %op4111, ptr %slot666, align 8
  %v4112 = load i64, ptr %slot660, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %rgep4114 = getelementptr i8, ptr %p4113, i64 -32
  %ld4115 = load i64, ptr %rgep4114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4115, ptr %slot667, align 8
  %v4116 = load i64, ptr %slot667, align 8
  %op4117 = sub i64 %v4116, 1
  store i64 %op4117, ptr %slot668, align 8
  %v4118 = load i64, ptr %slot668, align 8
  %cmp4119 = icmp eq i64 %v4118, 0
  %cv4120 = zext i1 %cmp4119 to i32
  store i32 %cv4120, ptr %slot669, align 8
  %v4121 = load i32, ptr %slot669, align 8
  %cv4122 = zext i32 %v4121 to i64
  %cond4123 = icmp ne i64 %cv4122, 0
  br i1 %cond4123, label %bb_rcglast823, label %bb_rcgdec823
bb_rcglast823:
  %v4124 = load i64, ptr %slot660, align 8
  %op4125 = sub i64 %v4124, 24
  store i64 %op4125, ptr %slot670, align 8
  %v4126 = load i64, ptr %slot660, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  %rgep4128 = getelementptr i8, ptr %p4127, i64 -24
  %ld4129 = load i64, ptr %rgep4128, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4129, ptr %slot671, align 8
  %v4130 = load i64, ptr %slot671, align 8
  %cmp4131 = icmp ne i64 %v4130, 0
  %cv4132 = zext i1 %cmp4131 to i32
  store i32 %cv4132, ptr %slot672, align 8
  %v4133 = load i32, ptr %slot672, align 8
  %cv4134 = zext i32 %v4133 to i64
  %cond4135 = icmp ne i64 %cv4134, 0
  br i1 %cond4135, label %bb_rcgdec823, label %bb_rcgslow823
bb_rcgslow823:
  %v4136 = load i64, ptr %slot659, align 8
  %v4137 = load i64, ptr %slot658, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4136, i64 %v4137) nomerge, !dbg !140
  br label %bb_rcgdone823
bb_rcgdec823:
  %v4138 = load i64, ptr %slot668, align 8
  %v4139 = load i64, ptr %slot660, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  %rgep4141 = getelementptr i8, ptr %p4140, i64 -32
  store i64 %v4138, ptr %rgep4141, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear823
bb_rcgclear823:
  %v4142 = load i64, ptr %slot658, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  store i64 0, ptr %p4143, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone823
bb_rcgdone823:
  %v4144 = load i64, ptr %slot654, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i64 0, ptr %p4145, align 8, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot654, align 8
  %p4148 = inttoptr i64 %v4146 to ptr
  %gep4149 = getelementptr i8, ptr %p4148, i64 8
  %op4147 = ptrtoint ptr %gep4149 to i64
  store i64 %op4147, ptr %slot673, align 8
  %v4150 = load i64, ptr %slot673, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  store i64 0, ptr %p4151, align 8, !alias.scope !3, !noalias !4
  %v4152 = load i64, ptr %slot654, align 8
  %p4154 = inttoptr i64 %v4152 to ptr
  %gep4155 = getelementptr i8, ptr %p4154, i64 16
  %op4153 = ptrtoint ptr %gep4155 to i64
  store i64 %op4153, ptr %slot674, align 8
  %v4156 = load i64, ptr %slot674, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  store i64 0, ptr %p4157, align 8, !alias.scope !3, !noalias !4
  %v4158 = load i64, ptr %slot654, align 8
  %p4160 = inttoptr i64 %v4158 to ptr
  %gep4161 = getelementptr i8, ptr %p4160, i64 24
  %op4159 = ptrtoint ptr %gep4161 to i64
  store i64 %op4159, ptr %slot675, align 8
  %v4162 = load i64, ptr %slot675, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  store i64 0, ptr %p4163, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone805
bb_rcslotdone805:
  %v4164 = load i64, ptr %slot36, align 8
  store i64 %v4164, ptr %slot676, align 8
  %v4165 = load i64, ptr %slot27, align 8
  store i64 %v4165, ptr %slot677, align 8
  %v4166 = load i64, ptr %slot677, align 8
  %v4167 = load i64, ptr %slot676, align 8
  %p4168 = inttoptr i64 %v4166 to ptr
  %p4169 = inttoptr i64 %v4167 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4169, ptr %p4168, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4170 = load i64, ptr %slot21, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  store i32 0, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  %v4172 = load i64, ptr %slot14, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  store i32 2, ptr %p4173, align 4, !alias.scope !3, !noalias !4
  %v4174 = load i64, ptr %slot22, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %ld4176 = load i32, ptr %p4175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4176, ptr %slot678, align 8
  %v4177 = load i32, ptr %slot678, align 8
  %v4178 = load i64, ptr %slot14, align 8
  %p4179 = inttoptr i64 %v4178 to ptr
  store i32 %v4177, ptr %p4179, align 4, !alias.scope !3, !noalias !4
  %v4180 = load i64, ptr %slot13, align 8
  %p4181 = inttoptr i64 %v4180 to ptr
  store i32 1, ptr %p4181, align 4, !alias.scope !3, !noalias !4
  %v4182 = load i64, ptr %slot36, align 8
  %v4183 = load i64, ptr %slot38, align 8
  %p4184 = inttoptr i64 %v4183 to ptr
  store i64 %v4182, ptr %p4184, align 8, !alias.scope !3, !noalias !4
  %v4185 = load i64, ptr %slot38, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  %ld4187 = load i64, ptr %p4186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4187, ptr %slot679, align 8
  %v4188 = load i64, ptr %slot679, align 8
  %op4189 = add i64 %v4188, 16
  store i64 %op4189, ptr %slot680, align 8
  %v4190 = load i64, ptr %slot680, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %ld4192 = load i64, ptr %p4191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4192, ptr %slot681, align 8
  %v4193 = load i64, ptr %slot681, align 8
  %v4194 = load i64, ptr %slot38, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  store i64 %v4193, ptr %p4195, align 8, !alias.scope !3, !noalias !4
  %v4196 = load i64, ptr %slot17, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  %ld4198 = load i32, ptr %p4197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4198, ptr %slot682, align 8
  %v4199 = load i32, ptr %slot682, align 8
  %cv4200 = zext i32 %v4199 to i64
  %cond4201 = icmp ne i64 %cv4200, 0
  br i1 %cond4201, label %bb_rcslotdrop842, label %bb_rcslotdone842
bb_rcslotdrop842:
  %v4202 = load i64, ptr %slot17, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  store i32 0, ptr %p4203, align 4, !alias.scope !3, !noalias !4
  %v4204 = load i64, ptr %slot23, align 8
  store i64 %v4204, ptr %slot683, align 8
  %v4205 = load i64, ptr %slot18, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %ld4207 = load i32, ptr %p4206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4207, ptr %slot684, align 8
  %v4208 = load i32, ptr %slot684, align 8
  %op4209 = and i32 %v4208, 28
  store i32 %op4209, ptr %slot685, align 8
  %v4210 = load i32, ptr %slot685, align 8
  %cv4211 = zext i32 %v4210 to i64
  %cond4212 = icmp ne i64 %cv4211, 0
  br i1 %cond4212, label %bb_rcslotrole842, label %bb_rcslotowner842
bb_rcslotrole842:
  %v4213 = load i64, ptr %slot45, align 8
  store i64 %v4213, ptr %slot686, align 8
  %v4214 = load i64, ptr %slot686, align 8
  %v4215 = load i64, ptr %slot683, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4214, i64 %v4215) nomerge, !dbg !142
  br label %bb_rcslotdone842
bb_rcslotowner842:
  %v4216 = load i64, ptr %slot45, align 8
  store i64 %v4216, ptr %slot687, align 8
  %v4217 = load i64, ptr %slot687, align 8
  %v4218 = load i64, ptr %slot683, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4217, i64 %v4218) nomerge, !dbg !142
  br label %bb_rcslotdone842
bb_rcslotdone842:
  %v4219 = load i64, ptr %slot36, align 8
  %v4220 = load i64, ptr %slot39, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  store i64 %v4219, ptr %p4221, align 8, !alias.scope !3, !noalias !4
  %v4222 = load i64, ptr %slot39, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  %ld4224 = load i64, ptr %p4223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4224, ptr %slot688, align 8
  %v4225 = load i64, ptr %slot688, align 8
  %op4226 = add i64 %v4225, 0
  store i64 %op4226, ptr %slot689, align 8
  %v4227 = load i64, ptr %slot689, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  %ld4229 = load i64, ptr %p4228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4229, ptr %slot690, align 8
  %v4230 = load i64, ptr %slot690, align 8
  %v4231 = load i64, ptr %slot39, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  store i64 %v4230, ptr %p4232, align 8, !alias.scope !3, !noalias !4
  %v4233 = load i64, ptr %slot39, align 8
  %p4234 = inttoptr i64 %v4233 to ptr
  %ld4235 = load i64, ptr %p4234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4235, ptr %slot691, align 8
  %v4236 = load i64, ptr %slot691, align 8
  %v4237 = load i64, ptr %slot26, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  store i64 %v4236, ptr %p4238, align 8, !alias.scope !3, !noalias !4
  %v4239 = load i64, ptr %slot26, align 8
  store i64 %v4239, ptr %slot692, align 8
  %v4240 = load i64, ptr %slot27, align 8
  store i64 %v4240, ptr %slot693, align 8
  %v4241 = load i64, ptr %slot692, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %ld4243 = load i64, ptr %p4242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4243, ptr %slot694, align 8
  %v4244 = load i64, ptr %slot694, align 8
  %cmp4245 = icmp ne i64 %v4244, 0
  %cv4246 = zext i1 %cmp4245 to i32
  store i32 %cv4246, ptr %slot695, align 8
  %v4247 = load i32, ptr %slot695, align 8
  %cv4248 = zext i32 %v4247 to i64
  %cond4249 = icmp ne i64 %cv4248, 0
  br i1 %cond4249, label %bb_rcgnn856, label %bb_rcgstore856
bb_rcgnn856:
  %v4250 = load i64, ptr %slot694, align 8
  %op4251 = sub i64 %v4250, 16
  store i64 %op4251, ptr %slot696, align 8
  %v4252 = load i64, ptr %slot694, align 8
  %p4253 = inttoptr i64 %v4252 to ptr
  %rgep4254 = getelementptr i8, ptr %p4253, i64 -16
  %ld4255 = load i64, ptr %rgep4254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4255, ptr %slot697, align 8
  %v4256 = load i64, ptr %slot697, align 8
  %op4257 = and i64 %v4256, 4611686018427387906
  store i64 %op4257, ptr %slot698, align 8
  %v4258 = load i64, ptr %slot698, align 8
  %cmp4259 = icmp ne i64 %v4258, 0
  %cv4260 = zext i1 %cmp4259 to i32
  store i32 %cv4260, ptr %slot699, align 8
  %v4261 = load i32, ptr %slot699, align 8
  %cv4262 = zext i32 %v4261 to i64
  %cond4263 = icmp ne i64 %cv4262, 0
  br i1 %cond4263, label %bb_rcgstore856, label %bb_rcginc856
bb_rcginc856:
  %v4264 = load i64, ptr %slot694, align 8
  %op4265 = sub i64 %v4264, 24
  store i64 %op4265, ptr %slot700, align 8
  %v4266 = load i64, ptr %slot694, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  %rgep4268 = getelementptr i8, ptr %p4267, i64 -24
  %ld4269 = load i64, ptr %rgep4268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4269, ptr %slot701, align 8
  %v4270 = load i64, ptr %slot701, align 8
  %op4271 = add i64 %v4270, 1
  store i64 %op4271, ptr %slot702, align 8
  %v4272 = load i64, ptr %slot702, align 8
  %cmp4273 = icmp eq i64 %v4272, 0
  %cv4274 = zext i1 %cmp4273 to i32
  store i32 %cv4274, ptr %slot703, align 8
  %v4275 = load i32, ptr %slot703, align 8
  %cv4276 = zext i32 %v4275 to i64
  %cond4277 = icmp ne i64 %cv4276, 0
  br i1 %cond4277, label %bb_rcglimit856, label %bb_rcgcapacity856
bb_rcglimit856:
  %v4278 = load i64, ptr %slot1, align 8
  %p4279 = inttoptr i64 %v4278 to ptr
  %call4280 = call i32 @myl_qbe_rc_status(ptr %p4279, i32 2) nomerge, !dbg !144
  store i32 %call4280, ptr %slot704, align 8
  br label %bb_failure
bb_rcgcapacity856:
  %v4281 = load i64, ptr %slot702, align 8
  %v4282 = load i64, ptr %slot694, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %rgep4284 = getelementptr i8, ptr %p4283, i64 -24
  store i64 %v4281, ptr %rgep4284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore856
bb_rcgstore856:
  %v4285 = load i64, ptr %slot694, align 8
  %v4286 = load i64, ptr %slot693, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i64 %v4285, ptr %p4287, align 8, !alias.scope !3, !noalias !4
  %v4288 = load i64, ptr %slot22, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  store i32 2, ptr %p4289, align 4, !alias.scope !3, !noalias !4
  %v4290 = load i64, ptr %slot22, align 8
  %p4291 = inttoptr i64 %v4290 to ptr
  store i32 16, ptr %p4291, align 4, !alias.scope !3, !noalias !4
  %v4292 = load i64, ptr %slot21, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  store i32 1, ptr %p4293, align 4, !alias.scope !3, !noalias !4
  %v4294 = load i64, ptr %slot19, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  %ld4296 = load i32, ptr %p4295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4296, ptr %slot705, align 8
  %v4297 = load i32, ptr %slot705, align 8
  %cv4298 = zext i32 %v4297 to i64
  %cond4299 = icmp ne i64 %cv4298, 0
  br i1 %cond4299, label %bb_rcslotdrop872, label %bb_rcslotdone872
bb_rcslotdrop872:
  %v4300 = load i64, ptr %slot19, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  store i32 0, ptr %p4301, align 4, !alias.scope !3, !noalias !4
  %v4302 = load i64, ptr %slot24, align 8
  store i64 %v4302, ptr %slot706, align 8
  %v4303 = load i64, ptr %slot20, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  %ld4305 = load i32, ptr %p4304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4305, ptr %slot707, align 8
  %v4306 = load i32, ptr %slot707, align 8
  %op4307 = and i32 %v4306, 28
  store i32 %op4307, ptr %slot708, align 8
  %v4308 = load i32, ptr %slot708, align 8
  %cv4309 = zext i32 %v4308 to i64
  %cond4310 = icmp ne i64 %cv4309, 0
  br i1 %cond4310, label %bb_rcslotrole872, label %bb_rcslotowner872
bb_rcslotrole872:
  %v4311 = load i64, ptr %slot45, align 8
  store i64 %v4311, ptr %slot709, align 8
  %v4312 = load i64, ptr %slot709, align 8
  %v4313 = load i64, ptr %slot706, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4312, i64 %v4313) nomerge, !dbg !144
  br label %bb_rcslotdone872
bb_rcslotowner872:
  %v4314 = load i64, ptr %slot45, align 8
  store i64 %v4314, ptr %slot710, align 8
  %v4315 = load i64, ptr %slot710, align 8
  %v4316 = load i64, ptr %slot706, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4315, i64 %v4316) nomerge, !dbg !144
  br label %bb_rcslotdone872
bb_rcslotdone872:
  %v4317 = load i64, ptr %slot24, align 8
  store i64 %v4317, ptr %slot711, align 8
  %v4318 = load i64, ptr %slot27, align 8
  store i64 %v4318, ptr %slot712, align 8
  %v4319 = load i64, ptr %slot712, align 8
  %v4320 = load i64, ptr %slot711, align 8
  %p4321 = inttoptr i64 %v4319 to ptr
  %p4322 = inttoptr i64 %v4320 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4322, ptr %p4321, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4323 = load i64, ptr %slot20, align 8
  %p4324 = inttoptr i64 %v4323 to ptr
  store i32 2, ptr %p4324, align 4, !alias.scope !3, !noalias !4
  %v4325 = load i64, ptr %slot22, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  %ld4327 = load i32, ptr %p4326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4327, ptr %slot713, align 8
  %v4328 = load i32, ptr %slot713, align 8
  %v4329 = load i64, ptr %slot20, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  store i32 %v4328, ptr %p4330, align 4, !alias.scope !3, !noalias !4
  %v4331 = load i64, ptr %slot21, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  store i32 0, ptr %p4332, align 4, !alias.scope !3, !noalias !4
  %v4333 = load i64, ptr %slot19, align 8
  %p4334 = inttoptr i64 %v4333 to ptr
  store i32 1, ptr %p4334, align 4, !alias.scope !3, !noalias !4
  %v4335 = load i64, ptr %slot711, align 8
  %p4336 = inttoptr i64 %v4335 to ptr
  %ld4337 = load i64, ptr %p4336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4337, ptr %slot714, align 8
  %v4338 = load i64, ptr %slot714, align 8
  %v4339 = load i64, ptr %slot39, align 8
  %p4340 = inttoptr i64 %v4339 to ptr
  store i64 %v4338, ptr %p4340, align 8, !alias.scope !3, !noalias !4
  %v4341 = load i64, ptr %slot39, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  %ld4343 = load i64, ptr %p4342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4343, ptr %slot715, align 8
  %v4344 = load i64, ptr %slot715, align 8
  %p4345 = inttoptr i64 %v4344 to ptr
  %ld4346 = load i64, ptr %p4345, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4346, ptr %slot716, align 8
  %v4347 = load i64, ptr %slot716, align 8
  %v4348 = load i64, ptr %slot39, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  store i64 %v4347, ptr %p4349, align 8, !alias.scope !3, !noalias !4
  %v4350 = load i64, ptr %slot19, align 8
  %p4351 = inttoptr i64 %v4350 to ptr
  %ld4352 = load i32, ptr %p4351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4352, ptr %slot717, align 8
  %v4353 = load i32, ptr %slot717, align 8
  %cv4354 = zext i32 %v4353 to i64
  %cond4355 = icmp ne i64 %cv4354, 0
  br i1 %cond4355, label %bb_rcslotdrop892, label %bb_rcslotdone892
bb_rcslotdrop892:
  %v4356 = load i64, ptr %slot19, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  store i32 0, ptr %p4357, align 4, !alias.scope !3, !noalias !4
  %v4358 = load i64, ptr %slot24, align 8
  store i64 %v4358, ptr %slot718, align 8
  %v4359 = load i64, ptr %slot20, align 8
  %p4360 = inttoptr i64 %v4359 to ptr
  %ld4361 = load i32, ptr %p4360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4361, ptr %slot719, align 8
  %v4362 = load i32, ptr %slot719, align 8
  %op4363 = and i32 %v4362, 28
  store i32 %op4363, ptr %slot720, align 8
  %v4364 = load i32, ptr %slot720, align 8
  %cv4365 = zext i32 %v4364 to i64
  %cond4366 = icmp ne i64 %cv4365, 0
  br i1 %cond4366, label %bb_rcslotrole892, label %bb_rcslotowner892
bb_rcslotrole892:
  %v4367 = load i64, ptr %slot45, align 8
  store i64 %v4367, ptr %slot721, align 8
  %v4368 = load i64, ptr %slot718, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  %ld4370 = load i64, ptr %p4369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4370, ptr %slot722, align 8
  %v4371 = load i64, ptr %slot722, align 8
  %cmp4372 = icmp ne i64 %v4371, 0
  %cv4373 = zext i1 %cmp4372 to i32
  store i32 %cv4373, ptr %slot723, align 8
  %v4374 = load i32, ptr %slot723, align 8
  %cv4375 = zext i32 %v4374 to i64
  %cond4376 = icmp ne i64 %cv4375, 0
  br i1 %cond4376, label %bb_rcgnn908, label %bb_rcgdone908
bb_rcgnn908:
  %v4377 = load i64, ptr %slot722, align 8
  %op4378 = sub i64 %v4377, 16
  store i64 %op4378, ptr %slot724, align 8
  %v4379 = load i64, ptr %slot722, align 8
  %p4380 = inttoptr i64 %v4379 to ptr
  %rgep4381 = getelementptr i8, ptr %p4380, i64 -16
  %ld4382 = load i64, ptr %rgep4381, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4382, ptr %slot725, align 8
  %v4383 = load i64, ptr %slot725, align 8
  %op4384 = and i64 %v4383, 4611686018427387906
  store i64 %op4384, ptr %slot726, align 8
  %v4385 = load i64, ptr %slot726, align 8
  %cmp4386 = icmp ne i64 %v4385, 0
  %cv4387 = zext i1 %cmp4386 to i32
  store i32 %cv4387, ptr %slot727, align 8
  %v4388 = load i32, ptr %slot727, align 8
  %cv4389 = zext i32 %v4388 to i64
  %cond4390 = icmp ne i64 %cv4389, 0
  br i1 %cond4390, label %bb_rcgclear908, label %bb_rcgcounted908
bb_rcgcounted908:
  %v4391 = load i64, ptr %slot722, align 8
  %op4392 = sub i64 %v4391, 24
  store i64 %op4392, ptr %slot728, align 8
  %v4393 = load i64, ptr %slot722, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  %rgep4395 = getelementptr i8, ptr %p4394, i64 -24
  %ld4396 = load i64, ptr %rgep4395, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4396, ptr %slot729, align 8
  %v4397 = load i64, ptr %slot729, align 8
  %op4398 = sub i64 %v4397, 1
  store i64 %op4398, ptr %slot730, align 8
  %v4399 = load i64, ptr %slot730, align 8
  %cmp4400 = icmp eq i64 %v4399, 0
  %cv4401 = zext i1 %cmp4400 to i32
  store i32 %cv4401, ptr %slot731, align 8
  %v4402 = load i32, ptr %slot731, align 8
  %cv4403 = zext i32 %v4402 to i64
  %cond4404 = icmp ne i64 %cv4403, 0
  br i1 %cond4404, label %bb_rcglast908, label %bb_rcgdec908
bb_rcglast908:
  %v4405 = load i64, ptr %slot722, align 8
  %op4406 = sub i64 %v4405, 32
  store i64 %op4406, ptr %slot732, align 8
  %v4407 = load i64, ptr %slot722, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  %rgep4409 = getelementptr i8, ptr %p4408, i64 -32
  %ld4410 = load i64, ptr %rgep4409, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4410, ptr %slot733, align 8
  %v4411 = load i64, ptr %slot733, align 8
  %cmp4412 = icmp ne i64 %v4411, 0
  %cv4413 = zext i1 %cmp4412 to i32
  store i32 %cv4413, ptr %slot734, align 8
  %v4414 = load i32, ptr %slot734, align 8
  %cv4415 = zext i32 %v4414 to i64
  %cond4416 = icmp ne i64 %cv4415, 0
  br i1 %cond4416, label %bb_rcgdec908, label %bb_rcgslow908
bb_rcgslow908:
  %v4417 = load i64, ptr %slot721, align 8
  %v4418 = load i64, ptr %slot718, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4417, i64 %v4418) nomerge, !dbg !146
  br label %bb_rcgdone908
bb_rcgdec908:
  %v4419 = load i64, ptr %slot730, align 8
  %v4420 = load i64, ptr %slot722, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %rgep4422 = getelementptr i8, ptr %p4421, i64 -24
  store i64 %v4419, ptr %rgep4422, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear908
bb_rcgclear908:
  %v4423 = load i64, ptr %slot718, align 8
  %p4424 = inttoptr i64 %v4423 to ptr
  store i64 0, ptr %p4424, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone908
bb_rcgdone908:
  br label %bb_rcslotdone892
bb_rcslotowner892:
  %v4425 = load i64, ptr %slot45, align 8
  store i64 %v4425, ptr %slot735, align 8
  %v4426 = load i64, ptr %slot718, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %ld4428 = load i64, ptr %p4427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4428, ptr %slot736, align 8
  %v4429 = load i64, ptr %slot736, align 8
  %cmp4430 = icmp ne i64 %v4429, 0
  %cv4431 = zext i1 %cmp4430 to i32
  store i32 %cv4431, ptr %slot737, align 8
  %v4432 = load i32, ptr %slot737, align 8
  %cv4433 = zext i32 %v4432 to i64
  %cond4434 = icmp ne i64 %cv4433, 0
  br i1 %cond4434, label %bb_rcgnn923, label %bb_rcgdone923
bb_rcgnn923:
  %v4435 = load i64, ptr %slot736, align 8
  %op4436 = sub i64 %v4435, 16
  store i64 %op4436, ptr %slot738, align 8
  %v4437 = load i64, ptr %slot736, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  %rgep4439 = getelementptr i8, ptr %p4438, i64 -16
  %ld4440 = load i64, ptr %rgep4439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4440, ptr %slot739, align 8
  %v4441 = load i64, ptr %slot739, align 8
  %op4442 = and i64 %v4441, 4611686018427387906
  store i64 %op4442, ptr %slot740, align 8
  %v4443 = load i64, ptr %slot740, align 8
  %cmp4444 = icmp ne i64 %v4443, 0
  %cv4445 = zext i1 %cmp4444 to i32
  store i32 %cv4445, ptr %slot741, align 8
  %v4446 = load i32, ptr %slot741, align 8
  %cv4447 = zext i32 %v4446 to i64
  %cond4448 = icmp ne i64 %cv4447, 0
  br i1 %cond4448, label %bb_rcgclear923, label %bb_rcgcounted923
bb_rcgcounted923:
  %v4449 = load i64, ptr %slot736, align 8
  %op4450 = sub i64 %v4449, 32
  store i64 %op4450, ptr %slot742, align 8
  %v4451 = load i64, ptr %slot736, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  %rgep4453 = getelementptr i8, ptr %p4452, i64 -32
  %ld4454 = load i64, ptr %rgep4453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4454, ptr %slot743, align 8
  %v4455 = load i64, ptr %slot743, align 8
  %op4456 = sub i64 %v4455, 1
  store i64 %op4456, ptr %slot744, align 8
  %v4457 = load i64, ptr %slot744, align 8
  %cmp4458 = icmp eq i64 %v4457, 0
  %cv4459 = zext i1 %cmp4458 to i32
  store i32 %cv4459, ptr %slot745, align 8
  %v4460 = load i32, ptr %slot745, align 8
  %cv4461 = zext i32 %v4460 to i64
  %cond4462 = icmp ne i64 %cv4461, 0
  br i1 %cond4462, label %bb_rcglast923, label %bb_rcgdec923
bb_rcglast923:
  %v4463 = load i64, ptr %slot736, align 8
  %op4464 = sub i64 %v4463, 24
  store i64 %op4464, ptr %slot746, align 8
  %v4465 = load i64, ptr %slot736, align 8
  %p4466 = inttoptr i64 %v4465 to ptr
  %rgep4467 = getelementptr i8, ptr %p4466, i64 -24
  %ld4468 = load i64, ptr %rgep4467, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4468, ptr %slot747, align 8
  %v4469 = load i64, ptr %slot747, align 8
  %cmp4470 = icmp ne i64 %v4469, 0
  %cv4471 = zext i1 %cmp4470 to i32
  store i32 %cv4471, ptr %slot748, align 8
  %v4472 = load i32, ptr %slot748, align 8
  %cv4473 = zext i32 %v4472 to i64
  %cond4474 = icmp ne i64 %cv4473, 0
  br i1 %cond4474, label %bb_rcgdec923, label %bb_rcgslow923
bb_rcgslow923:
  %v4475 = load i64, ptr %slot735, align 8
  %v4476 = load i64, ptr %slot718, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4475, i64 %v4476) nomerge, !dbg !146
  br label %bb_rcgdone923
bb_rcgdec923:
  %v4477 = load i64, ptr %slot744, align 8
  %v4478 = load i64, ptr %slot736, align 8
  %p4479 = inttoptr i64 %v4478 to ptr
  %rgep4480 = getelementptr i8, ptr %p4479, i64 -32
  store i64 %v4477, ptr %rgep4480, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear923
bb_rcgclear923:
  %v4481 = load i64, ptr %slot718, align 8
  %p4482 = inttoptr i64 %v4481 to ptr
  store i64 0, ptr %p4482, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone923
bb_rcgdone923:
  br label %bb_rcslotdone892
bb_rcslotdone892:
  %v4483 = load i64, ptr %slot39, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  %ld4485 = load i64, ptr %p4484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4485, ptr %slot749, align 8
  %v4486 = load i64, ptr %slot38, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %ld4488 = load i64, ptr %p4487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4488, ptr %slot750, align 8
  %v4489 = load i64, ptr %slot750, align 8
  %v4490 = load i64, ptr %slot749, align 8
  %cmp4491 = icmp sge i64 %v4489, %v4490
  %cv4492 = zext i1 %cmp4491 to i64
  store i64 %cv4492, ptr %slot751, align 8
  %v4493 = load i64, ptr %slot751, align 8
  %v4494 = load i64, ptr %slot38, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  store i64 %v4493, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  br label %bb_i48
bb_i48:
  %v4496 = load i64, ptr %slot38, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  %ld4498 = load i64, ptr %p4497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4498, ptr %slot752, align 8
  %v4499 = load i64, ptr %slot752, align 8
  %cond4500 = icmp ne i64 %v4499, 0
  br i1 %cond4500, label %bb_next931, label %bb_i51
bb_next931:
  %v4501 = load i64, ptr %slot38, align 8
  %p4502 = inttoptr i64 %v4501 to ptr
  store i64 0, ptr %p4502, align 8, !alias.scope !3, !noalias !4
  br label %bb_i58
bb_i51:
  %v4503 = load i64, ptr %slot35, align 8
  %v4504 = load i64, ptr %slot38, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  store i64 %v4503, ptr %p4505, align 8, !alias.scope !3, !noalias !4
  %v4506 = load i64, ptr %slot38, align 8
  %p4507 = inttoptr i64 %v4506 to ptr
  %ld4508 = load i64, ptr %p4507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4508, ptr %slot753, align 8
  %v4509 = load i64, ptr %slot753, align 8
  %op4510 = add i64 %v4509, 0
  store i64 %op4510, ptr %slot754, align 8
  %v4511 = load i64, ptr %slot754, align 8
  %p4512 = inttoptr i64 %v4511 to ptr
  %ld4513 = load i64, ptr %p4512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4513, ptr %slot755, align 8
  %v4514 = load i64, ptr %slot755, align 8
  %v4515 = load i64, ptr %slot38, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  store i64 %v4514, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  %v4517 = load i64, ptr %slot38, align 8
  %p4518 = inttoptr i64 %v4517 to ptr
  %ld4519 = load i64, ptr %p4518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4519, ptr %slot756, align 8
  %v4520 = load i64, ptr %slot756, align 8
  %v4521 = load i64, ptr %slot25, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  store i64 %v4520, ptr %p4522, align 8, !alias.scope !3, !noalias !4
  %v4523 = load i64, ptr %slot25, align 8
  store i64 %v4523, ptr %slot757, align 8
  %v4524 = load i64, ptr %slot27, align 8
  store i64 %v4524, ptr %slot758, align 8
  %v4525 = load i64, ptr %slot757, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %ld4527 = load i64, ptr %p4526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4527, ptr %slot759, align 8
  %v4528 = load i64, ptr %slot759, align 8
  %cmp4529 = icmp ne i64 %v4528, 0
  %cv4530 = zext i1 %cmp4529 to i32
  store i32 %cv4530, ptr %slot760, align 8
  %v4531 = load i32, ptr %slot760, align 8
  %cv4532 = zext i32 %v4531 to i64
  %cond4533 = icmp ne i64 %cv4532, 0
  br i1 %cond4533, label %bb_rcgnn938, label %bb_rcgstore938
bb_rcgnn938:
  %v4534 = load i64, ptr %slot759, align 8
  %op4535 = sub i64 %v4534, 16
  store i64 %op4535, ptr %slot761, align 8
  %v4536 = load i64, ptr %slot759, align 8
  %p4537 = inttoptr i64 %v4536 to ptr
  %rgep4538 = getelementptr i8, ptr %p4537, i64 -16
  %ld4539 = load i64, ptr %rgep4538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4539, ptr %slot762, align 8
  %v4540 = load i64, ptr %slot762, align 8
  %op4541 = and i64 %v4540, 4611686018427387906
  store i64 %op4541, ptr %slot763, align 8
  %v4542 = load i64, ptr %slot763, align 8
  %cmp4543 = icmp ne i64 %v4542, 0
  %cv4544 = zext i1 %cmp4543 to i32
  store i32 %cv4544, ptr %slot764, align 8
  %v4545 = load i32, ptr %slot764, align 8
  %cv4546 = zext i32 %v4545 to i64
  %cond4547 = icmp ne i64 %cv4546, 0
  br i1 %cond4547, label %bb_rcgstore938, label %bb_rcginc938
bb_rcginc938:
  %v4548 = load i64, ptr %slot759, align 8
  %op4549 = sub i64 %v4548, 24
  store i64 %op4549, ptr %slot765, align 8
  %v4550 = load i64, ptr %slot759, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  %rgep4552 = getelementptr i8, ptr %p4551, i64 -24
  %ld4553 = load i64, ptr %rgep4552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4553, ptr %slot766, align 8
  %v4554 = load i64, ptr %slot766, align 8
  %op4555 = add i64 %v4554, 1
  store i64 %op4555, ptr %slot767, align 8
  %v4556 = load i64, ptr %slot767, align 8
  %cmp4557 = icmp eq i64 %v4556, 0
  %cv4558 = zext i1 %cmp4557 to i32
  store i32 %cv4558, ptr %slot768, align 8
  %v4559 = load i32, ptr %slot768, align 8
  %cv4560 = zext i32 %v4559 to i64
  %cond4561 = icmp ne i64 %cv4560, 0
  br i1 %cond4561, label %bb_rcglimit938, label %bb_rcgcapacity938
bb_rcglimit938:
  %v4562 = load i64, ptr %slot1, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  %call4564 = call i32 @myl_qbe_rc_status(ptr %p4563, i32 2) nomerge, !dbg !148
  store i32 %call4564, ptr %slot769, align 8
  br label %bb_failure
bb_rcgcapacity938:
  %v4565 = load i64, ptr %slot767, align 8
  %v4566 = load i64, ptr %slot759, align 8
  %p4567 = inttoptr i64 %v4566 to ptr
  %rgep4568 = getelementptr i8, ptr %p4567, i64 -24
  store i64 %v4565, ptr %rgep4568, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore938
bb_rcgstore938:
  %v4569 = load i64, ptr %slot759, align 8
  %v4570 = load i64, ptr %slot758, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  store i64 %v4569, ptr %p4571, align 8, !alias.scope !3, !noalias !4
  %v4572 = load i64, ptr %slot22, align 8
  %p4573 = inttoptr i64 %v4572 to ptr
  store i32 2, ptr %p4573, align 4, !alias.scope !3, !noalias !4
  %v4574 = load i64, ptr %slot22, align 8
  %p4575 = inttoptr i64 %v4574 to ptr
  store i32 16, ptr %p4575, align 4, !alias.scope !3, !noalias !4
  %v4576 = load i64, ptr %slot21, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  store i32 1, ptr %p4577, align 4, !alias.scope !3, !noalias !4
  %v4578 = load i64, ptr %slot17, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  %ld4580 = load i32, ptr %p4579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4580, ptr %slot770, align 8
  %v4581 = load i32, ptr %slot770, align 8
  %cv4582 = zext i32 %v4581 to i64
  %cond4583 = icmp ne i64 %cv4582, 0
  br i1 %cond4583, label %bb_rcslotdrop954, label %bb_rcslotdone954
bb_rcslotdrop954:
  %v4584 = load i64, ptr %slot17, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  store i32 0, ptr %p4585, align 4, !alias.scope !3, !noalias !4
  %v4586 = load i64, ptr %slot23, align 8
  store i64 %v4586, ptr %slot771, align 8
  %v4587 = load i64, ptr %slot18, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  %ld4589 = load i32, ptr %p4588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4589, ptr %slot772, align 8
  %v4590 = load i32, ptr %slot772, align 8
  %op4591 = and i32 %v4590, 28
  store i32 %op4591, ptr %slot773, align 8
  %v4592 = load i32, ptr %slot773, align 8
  %cv4593 = zext i32 %v4592 to i64
  %cond4594 = icmp ne i64 %cv4593, 0
  br i1 %cond4594, label %bb_rcslotrole954, label %bb_rcslotowner954
bb_rcslotrole954:
  %v4595 = load i64, ptr %slot45, align 8
  store i64 %v4595, ptr %slot774, align 8
  %v4596 = load i64, ptr %slot774, align 8
  %v4597 = load i64, ptr %slot771, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4596, i64 %v4597) nomerge, !dbg !148
  br label %bb_rcslotdone954
bb_rcslotowner954:
  %v4598 = load i64, ptr %slot45, align 8
  store i64 %v4598, ptr %slot775, align 8
  %v4599 = load i64, ptr %slot775, align 8
  %v4600 = load i64, ptr %slot771, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4599, i64 %v4600) nomerge, !dbg !148
  br label %bb_rcslotdone954
bb_rcslotdone954:
  %v4601 = load i64, ptr %slot23, align 8
  store i64 %v4601, ptr %slot776, align 8
  %v4602 = load i64, ptr %slot27, align 8
  store i64 %v4602, ptr %slot777, align 8
  %v4603 = load i64, ptr %slot777, align 8
  %v4604 = load i64, ptr %slot776, align 8
  %p4605 = inttoptr i64 %v4603 to ptr
  %p4606 = inttoptr i64 %v4604 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4606, ptr %p4605, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4607 = load i64, ptr %slot18, align 8
  %p4608 = inttoptr i64 %v4607 to ptr
  store i32 2, ptr %p4608, align 4, !alias.scope !3, !noalias !4
  %v4609 = load i64, ptr %slot22, align 8
  %p4610 = inttoptr i64 %v4609 to ptr
  %ld4611 = load i32, ptr %p4610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4611, ptr %slot778, align 8
  %v4612 = load i32, ptr %slot778, align 8
  %v4613 = load i64, ptr %slot18, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  store i32 %v4612, ptr %p4614, align 4, !alias.scope !3, !noalias !4
  %v4615 = load i64, ptr %slot21, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  store i32 0, ptr %p4616, align 4, !alias.scope !3, !noalias !4
  %v4617 = load i64, ptr %slot17, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  store i32 1, ptr %p4618, align 4, !alias.scope !3, !noalias !4
  %v4619 = load i64, ptr %slot776, align 8
  %p4620 = inttoptr i64 %v4619 to ptr
  %ld4621 = load i64, ptr %p4620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4621, ptr %slot779, align 8
  %v4622 = load i64, ptr %slot779, align 8
  %v4623 = load i64, ptr %slot38, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  store i64 %v4622, ptr %p4624, align 8, !alias.scope !3, !noalias !4
  %v4625 = load i64, ptr %slot35, align 8
  %v4626 = load i64, ptr %slot39, align 8
  %p4627 = inttoptr i64 %v4626 to ptr
  store i64 %v4625, ptr %p4627, align 8, !alias.scope !3, !noalias !4
  %v4628 = load i64, ptr %slot39, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  %ld4630 = load i64, ptr %p4629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4630, ptr %slot780, align 8
  %v4631 = load i64, ptr %slot780, align 8
  %op4632 = add i64 %v4631, 16
  store i64 %op4632, ptr %slot781, align 8
  %v4633 = load i64, ptr %slot781, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  %ld4635 = load i64, ptr %p4634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4635, ptr %slot782, align 8
  %v4636 = load i64, ptr %slot782, align 8
  %v4637 = load i64, ptr %slot39, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  store i64 %v4636, ptr %p4638, align 8, !alias.scope !3, !noalias !4
  %v4639 = load i64, ptr %slot19, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %ld4641 = load i32, ptr %p4640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4641, ptr %slot783, align 8
  %v4642 = load i32, ptr %slot783, align 8
  %cv4643 = zext i32 %v4642 to i64
  %cond4644 = icmp ne i64 %cv4643, 0
  br i1 %cond4644, label %bb_rcslotdrop975, label %bb_rcslotdone975
bb_rcslotdrop975:
  %v4645 = load i64, ptr %slot19, align 8
  %p4646 = inttoptr i64 %v4645 to ptr
  store i32 0, ptr %p4646, align 4, !alias.scope !3, !noalias !4
  %v4647 = load i64, ptr %slot24, align 8
  store i64 %v4647, ptr %slot784, align 8
  %v4648 = load i64, ptr %slot20, align 8
  %p4649 = inttoptr i64 %v4648 to ptr
  %ld4650 = load i32, ptr %p4649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4650, ptr %slot785, align 8
  %v4651 = load i32, ptr %slot785, align 8
  %op4652 = and i32 %v4651, 28
  store i32 %op4652, ptr %slot786, align 8
  %v4653 = load i32, ptr %slot786, align 8
  %cv4654 = zext i32 %v4653 to i64
  %cond4655 = icmp ne i64 %cv4654, 0
  br i1 %cond4655, label %bb_rcslotrole975, label %bb_rcslotowner975
bb_rcslotrole975:
  %v4656 = load i64, ptr %slot45, align 8
  store i64 %v4656, ptr %slot787, align 8
  %v4657 = load i64, ptr %slot787, align 8
  %v4658 = load i64, ptr %slot784, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4657, i64 %v4658) nomerge, !dbg !150
  br label %bb_rcslotdone975
bb_rcslotowner975:
  %v4659 = load i64, ptr %slot45, align 8
  store i64 %v4659, ptr %slot788, align 8
  %v4660 = load i64, ptr %slot788, align 8
  %v4661 = load i64, ptr %slot784, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4660, i64 %v4661) nomerge, !dbg !150
  br label %bb_rcslotdone975
bb_rcslotdone975:
  %v4662 = load i64, ptr %slot38, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  %ld4664 = load i64, ptr %p4663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4664, ptr %slot789, align 8
  %v4665 = load i64, ptr %slot39, align 8
  %p4666 = inttoptr i64 %v4665 to ptr
  %ld4667 = load i64, ptr %p4666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4667, ptr %slot790, align 8
  %v4668 = load i64, ptr %slot789, align 8
  %p4669 = inttoptr i64 %v4668 to ptr
  %ld4670 = load i64, ptr %p4669, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4670, ptr %slot791, align 8
  %v4671 = load i64, ptr %slot790, align 8
  %op4672 = ashr i64 %v4671, 63
  store i64 %op4672, ptr %slot792, align 8
  %v4673 = load i64, ptr %slot792, align 8
  %v4674 = load i64, ptr %slot791, align 8
  %op4675 = and i64 %v4673, %v4674
  store i64 %op4675, ptr %slot793, align 8
  %v4676 = load i64, ptr %slot790, align 8
  %v4677 = load i64, ptr %slot793, align 8
  %op4678 = add i64 %v4676, %v4677
  store i64 %op4678, ptr %slot794, align 8
  %v4679 = load i64, ptr %slot794, align 8
  %v4680 = load i64, ptr %slot791, align 8
  %cmp4681 = icmp ult i64 %v4679, %v4680
  %cv4682 = zext i1 %cmp4681 to i64
  store i64 %cv4682, ptr %slot795, align 8
  %v4683 = load i64, ptr %slot795, align 8
  %cond4684 = icmp ne i64 %v4683, 0
  br i1 %cond4684, label %bb_success990, label %bb_failed990
bb_failed990:
  %v4685 = load i64, ptr %slot1, align 8
  %p4686 = inttoptr i64 %v4685 to ptr
  %v4687 = load i64, ptr %slot790, align 8
  %v4688 = load i64, ptr %slot791, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p4686, i64 %v4687, i64 %v4688) nomerge, !dbg !152
  unreachable
bb_success990:
  %v4689 = load i64, ptr %slot789, align 8
  %op4690 = add i64 %v4689, 32
  store i64 %op4690, ptr %slot796, align 8
  %v4691 = load i64, ptr %slot796, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %ld4693 = load i64, ptr %p4692, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4693, ptr %slot797, align 8
  %v4694 = load i64, ptr %slot797, align 8
  %v4695 = load i64, ptr %slot794, align 8
  %op4696 = add i64 %v4694, %v4695
  store i64 %op4696, ptr %slot798, align 8
  %v4697 = load i64, ptr %slot797, align 8
  %p4698 = inttoptr i64 %v4697 to ptr
  %v4699 = load i64, ptr %slot794, align 8
  %egep4700 = getelementptr i8, ptr %p4698, i64 %v4699
  %ld4701 = load i8, ptr %egep4700, align 1, !alias.scope !12, !noalias !13
  %ext4702 = zext i8 %ld4701 to i64
  store i64 %ext4702, ptr %slot799, align 8
  %v4703 = load i64, ptr %slot799, align 8
  %v4704 = load i64, ptr %slot38, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  store i64 %v4703, ptr %p4705, align 8, !alias.scope !3, !noalias !4
  %v4706 = load i64, ptr %slot17, align 8
  %p4707 = inttoptr i64 %v4706 to ptr
  %ld4708 = load i32, ptr %p4707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4708, ptr %slot800, align 8
  %v4709 = load i32, ptr %slot800, align 8
  %cv4710 = zext i32 %v4709 to i64
  %cond4711 = icmp ne i64 %cv4710, 0
  br i1 %cond4711, label %bb_rcslotdrop998, label %bb_rcslotdone998
bb_rcslotdrop998:
  %v4712 = load i64, ptr %slot17, align 8
  %p4713 = inttoptr i64 %v4712 to ptr
  store i32 0, ptr %p4713, align 4, !alias.scope !3, !noalias !4
  %v4714 = load i64, ptr %slot23, align 8
  store i64 %v4714, ptr %slot801, align 8
  %v4715 = load i64, ptr %slot18, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  %ld4717 = load i32, ptr %p4716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4717, ptr %slot802, align 8
  %v4718 = load i32, ptr %slot802, align 8
  %op4719 = and i32 %v4718, 28
  store i32 %op4719, ptr %slot803, align 8
  %v4720 = load i32, ptr %slot803, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcslotrole998, label %bb_rcslotowner998
bb_rcslotrole998:
  %v4723 = load i64, ptr %slot45, align 8
  store i64 %v4723, ptr %slot804, align 8
  %v4724 = load i64, ptr %slot801, align 8
  %p4725 = inttoptr i64 %v4724 to ptr
  %ld4726 = load i64, ptr %p4725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4726, ptr %slot805, align 8
  %v4727 = load i64, ptr %slot805, align 8
  %cmp4728 = icmp ne i64 %v4727, 0
  %cv4729 = zext i1 %cmp4728 to i32
  store i32 %cv4729, ptr %slot806, align 8
  %v4730 = load i32, ptr %slot806, align 8
  %cv4731 = zext i32 %v4730 to i64
  %cond4732 = icmp ne i64 %cv4731, 0
  br i1 %cond4732, label %bb_rcgnn1014, label %bb_rcgdone1014
bb_rcgnn1014:
  %v4733 = load i64, ptr %slot805, align 8
  %op4734 = sub i64 %v4733, 16
  store i64 %op4734, ptr %slot807, align 8
  %v4735 = load i64, ptr %slot805, align 8
  %p4736 = inttoptr i64 %v4735 to ptr
  %rgep4737 = getelementptr i8, ptr %p4736, i64 -16
  %ld4738 = load i64, ptr %rgep4737, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4738, ptr %slot808, align 8
  %v4739 = load i64, ptr %slot808, align 8
  %op4740 = and i64 %v4739, 4611686018427387906
  store i64 %op4740, ptr %slot809, align 8
  %v4741 = load i64, ptr %slot809, align 8
  %cmp4742 = icmp ne i64 %v4741, 0
  %cv4743 = zext i1 %cmp4742 to i32
  store i32 %cv4743, ptr %slot810, align 8
  %v4744 = load i32, ptr %slot810, align 8
  %cv4745 = zext i32 %v4744 to i64
  %cond4746 = icmp ne i64 %cv4745, 0
  br i1 %cond4746, label %bb_rcgclear1014, label %bb_rcgcounted1014
bb_rcgcounted1014:
  %v4747 = load i64, ptr %slot805, align 8
  %op4748 = sub i64 %v4747, 24
  store i64 %op4748, ptr %slot811, align 8
  %v4749 = load i64, ptr %slot805, align 8
  %p4750 = inttoptr i64 %v4749 to ptr
  %rgep4751 = getelementptr i8, ptr %p4750, i64 -24
  %ld4752 = load i64, ptr %rgep4751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4752, ptr %slot812, align 8
  %v4753 = load i64, ptr %slot812, align 8
  %op4754 = sub i64 %v4753, 1
  store i64 %op4754, ptr %slot813, align 8
  %v4755 = load i64, ptr %slot813, align 8
  %cmp4756 = icmp eq i64 %v4755, 0
  %cv4757 = zext i1 %cmp4756 to i32
  store i32 %cv4757, ptr %slot814, align 8
  %v4758 = load i32, ptr %slot814, align 8
  %cv4759 = zext i32 %v4758 to i64
  %cond4760 = icmp ne i64 %cv4759, 0
  br i1 %cond4760, label %bb_rcglast1014, label %bb_rcgdec1014
bb_rcglast1014:
  %v4761 = load i64, ptr %slot805, align 8
  %op4762 = sub i64 %v4761, 32
  store i64 %op4762, ptr %slot815, align 8
  %v4763 = load i64, ptr %slot805, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  %rgep4765 = getelementptr i8, ptr %p4764, i64 -32
  %ld4766 = load i64, ptr %rgep4765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4766, ptr %slot816, align 8
  %v4767 = load i64, ptr %slot816, align 8
  %cmp4768 = icmp ne i64 %v4767, 0
  %cv4769 = zext i1 %cmp4768 to i32
  store i32 %cv4769, ptr %slot817, align 8
  %v4770 = load i32, ptr %slot817, align 8
  %cv4771 = zext i32 %v4770 to i64
  %cond4772 = icmp ne i64 %cv4771, 0
  br i1 %cond4772, label %bb_rcgdec1014, label %bb_rcgslow1014
bb_rcgslow1014:
  %v4773 = load i64, ptr %slot804, align 8
  %v4774 = load i64, ptr %slot801, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4773, i64 %v4774) nomerge, !dbg !152
  br label %bb_rcgdone1014
bb_rcgdec1014:
  %v4775 = load i64, ptr %slot813, align 8
  %v4776 = load i64, ptr %slot805, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %rgep4778 = getelementptr i8, ptr %p4777, i64 -24
  store i64 %v4775, ptr %rgep4778, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1014
bb_rcgclear1014:
  %v4779 = load i64, ptr %slot801, align 8
  %p4780 = inttoptr i64 %v4779 to ptr
  store i64 0, ptr %p4780, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1014
bb_rcgdone1014:
  br label %bb_rcslotdone998
bb_rcslotowner998:
  %v4781 = load i64, ptr %slot45, align 8
  store i64 %v4781, ptr %slot818, align 8
  %v4782 = load i64, ptr %slot801, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  %ld4784 = load i64, ptr %p4783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4784, ptr %slot819, align 8
  %v4785 = load i64, ptr %slot819, align 8
  %cmp4786 = icmp ne i64 %v4785, 0
  %cv4787 = zext i1 %cmp4786 to i32
  store i32 %cv4787, ptr %slot820, align 8
  %v4788 = load i32, ptr %slot820, align 8
  %cv4789 = zext i32 %v4788 to i64
  %cond4790 = icmp ne i64 %cv4789, 0
  br i1 %cond4790, label %bb_rcgnn1029, label %bb_rcgdone1029
bb_rcgnn1029:
  %v4791 = load i64, ptr %slot819, align 8
  %op4792 = sub i64 %v4791, 16
  store i64 %op4792, ptr %slot821, align 8
  %v4793 = load i64, ptr %slot819, align 8
  %p4794 = inttoptr i64 %v4793 to ptr
  %rgep4795 = getelementptr i8, ptr %p4794, i64 -16
  %ld4796 = load i64, ptr %rgep4795, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4796, ptr %slot822, align 8
  %v4797 = load i64, ptr %slot822, align 8
  %op4798 = and i64 %v4797, 4611686018427387906
  store i64 %op4798, ptr %slot823, align 8
  %v4799 = load i64, ptr %slot823, align 8
  %cmp4800 = icmp ne i64 %v4799, 0
  %cv4801 = zext i1 %cmp4800 to i32
  store i32 %cv4801, ptr %slot824, align 8
  %v4802 = load i32, ptr %slot824, align 8
  %cv4803 = zext i32 %v4802 to i64
  %cond4804 = icmp ne i64 %cv4803, 0
  br i1 %cond4804, label %bb_rcgclear1029, label %bb_rcgcounted1029
bb_rcgcounted1029:
  %v4805 = load i64, ptr %slot819, align 8
  %op4806 = sub i64 %v4805, 32
  store i64 %op4806, ptr %slot825, align 8
  %v4807 = load i64, ptr %slot819, align 8
  %p4808 = inttoptr i64 %v4807 to ptr
  %rgep4809 = getelementptr i8, ptr %p4808, i64 -32
  %ld4810 = load i64, ptr %rgep4809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4810, ptr %slot826, align 8
  %v4811 = load i64, ptr %slot826, align 8
  %op4812 = sub i64 %v4811, 1
  store i64 %op4812, ptr %slot827, align 8
  %v4813 = load i64, ptr %slot827, align 8
  %cmp4814 = icmp eq i64 %v4813, 0
  %cv4815 = zext i1 %cmp4814 to i32
  store i32 %cv4815, ptr %slot828, align 8
  %v4816 = load i32, ptr %slot828, align 8
  %cv4817 = zext i32 %v4816 to i64
  %cond4818 = icmp ne i64 %cv4817, 0
  br i1 %cond4818, label %bb_rcglast1029, label %bb_rcgdec1029
bb_rcglast1029:
  %v4819 = load i64, ptr %slot819, align 8
  %op4820 = sub i64 %v4819, 24
  store i64 %op4820, ptr %slot829, align 8
  %v4821 = load i64, ptr %slot819, align 8
  %p4822 = inttoptr i64 %v4821 to ptr
  %rgep4823 = getelementptr i8, ptr %p4822, i64 -24
  %ld4824 = load i64, ptr %rgep4823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4824, ptr %slot830, align 8
  %v4825 = load i64, ptr %slot830, align 8
  %cmp4826 = icmp ne i64 %v4825, 0
  %cv4827 = zext i1 %cmp4826 to i32
  store i32 %cv4827, ptr %slot831, align 8
  %v4828 = load i32, ptr %slot831, align 8
  %cv4829 = zext i32 %v4828 to i64
  %cond4830 = icmp ne i64 %cv4829, 0
  br i1 %cond4830, label %bb_rcgdec1029, label %bb_rcgslow1029
bb_rcgslow1029:
  %v4831 = load i64, ptr %slot818, align 8
  %v4832 = load i64, ptr %slot801, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4831, i64 %v4832) nomerge, !dbg !152
  br label %bb_rcgdone1029
bb_rcgdec1029:
  %v4833 = load i64, ptr %slot827, align 8
  %v4834 = load i64, ptr %slot819, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  %rgep4836 = getelementptr i8, ptr %p4835, i64 -32
  store i64 %v4833, ptr %rgep4836, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1029
bb_rcgclear1029:
  %v4837 = load i64, ptr %slot801, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  store i64 0, ptr %p4838, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1029
bb_rcgdone1029:
  br label %bb_rcslotdone998
bb_rcslotdone998:
  %v4839 = load i64, ptr %slot38, align 8
  %p4840 = inttoptr i64 %v4839 to ptr
  %ld4841 = load i64, ptr %p4840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4841, ptr %slot832, align 8
  %v4842 = load i64, ptr %slot832, align 8
  %v4843 = load i64, ptr %slot38, align 8
  %p4844 = inttoptr i64 %v4843 to ptr
  store i64 %v4842, ptr %p4844, align 8, !alias.scope !3, !noalias !4
  br label %bb_i58
bb_i58:
  %v4845 = load i64, ptr %slot39, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  store i64 10, ptr %p4846, align 8, !alias.scope !3, !noalias !4
  %v4847 = load i64, ptr %slot39, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  %ld4849 = load i64, ptr %p4848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4849, ptr %slot833, align 8
  %v4850 = load i64, ptr %slot38, align 8
  %p4851 = inttoptr i64 %v4850 to ptr
  %ld4852 = load i64, ptr %p4851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4852, ptr %slot834, align 8
  %v4853 = load i64, ptr %slot834, align 8
  %v4854 = load i64, ptr %slot833, align 8
  %cmp4855 = icmp eq i64 %v4853, %v4854
  %cv4856 = zext i1 %cmp4855 to i64
  store i64 %cv4856, ptr %slot835, align 8
  %v4857 = load i64, ptr %slot835, align 8
  %v4858 = load i64, ptr %slot38, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  store i64 %v4857, ptr %p4859, align 8, !alias.scope !3, !noalias !4
  %v4860 = load i64, ptr %slot38, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %ld4862 = load i64, ptr %p4861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4862, ptr %slot836, align 8
  %v4863 = load i64, ptr %slot836, align 8
  %cond4864 = icmp ne i64 %v4863, 0
  br i1 %cond4864, label %bb_next1038, label %bb_i76
bb_next1038:
  %v4865 = load i64, ptr %slot28, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %ld4867 = load i64, ptr %p4866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4867, ptr %slot837, align 8
  %v4868 = load i64, ptr %slot837, align 8
  %v4869 = load i64, ptr %slot38, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  store i64 %v4868, ptr %p4870, align 8, !alias.scope !3, !noalias !4
  %v4871 = load i64, ptr %slot38, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  %ld4873 = load i64, ptr %p4872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4873, ptr %slot838, align 8
  %v4874 = load i64, ptr %slot838, align 8
  %op4875 = add i64 %v4874, 24
  store i64 %op4875, ptr %slot839, align 8
  %v4876 = load i64, ptr %slot839, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i64, ptr %p4877, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4878, ptr %slot840, align 8
  %v4879 = load i64, ptr %slot840, align 8
  %v4880 = load i64, ptr %slot38, align 8
  %p4881 = inttoptr i64 %v4880 to ptr
  store i64 %v4879, ptr %p4881, align 8, !alias.scope !3, !noalias !4
  %v4882 = load i64, ptr %slot17, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  %ld4884 = load i32, ptr %p4883, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4884, ptr %slot841, align 8
  %v4885 = load i32, ptr %slot841, align 8
  %cv4886 = zext i32 %v4885 to i64
  %cond4887 = icmp ne i64 %cv4886, 0
  br i1 %cond4887, label %bb_rcslotdrop1044, label %bb_rcslotdone1044
bb_rcslotdrop1044:
  %v4888 = load i64, ptr %slot17, align 8
  %p4889 = inttoptr i64 %v4888 to ptr
  store i32 0, ptr %p4889, align 4, !alias.scope !3, !noalias !4
  %v4890 = load i64, ptr %slot23, align 8
  store i64 %v4890, ptr %slot842, align 8
  %v4891 = load i64, ptr %slot18, align 8
  %p4892 = inttoptr i64 %v4891 to ptr
  %ld4893 = load i32, ptr %p4892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4893, ptr %slot843, align 8
  %v4894 = load i32, ptr %slot843, align 8
  %op4895 = and i32 %v4894, 28
  store i32 %op4895, ptr %slot844, align 8
  %v4896 = load i32, ptr %slot844, align 8
  %cv4897 = zext i32 %v4896 to i64
  %cond4898 = icmp ne i64 %cv4897, 0
  br i1 %cond4898, label %bb_rcslotrole1044, label %bb_rcslotowner1044
bb_rcslotrole1044:
  %v4899 = load i64, ptr %slot45, align 8
  store i64 %v4899, ptr %slot845, align 8
  %v4900 = load i64, ptr %slot845, align 8
  %v4901 = load i64, ptr %slot842, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4900, i64 %v4901) nomerge, !dbg !154
  br label %bb_rcslotdone1044
bb_rcslotowner1044:
  %v4902 = load i64, ptr %slot45, align 8
  store i64 %v4902, ptr %slot846, align 8
  %v4903 = load i64, ptr %slot846, align 8
  %v4904 = load i64, ptr %slot842, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4903, i64 %v4904) nomerge, !dbg !154
  br label %bb_rcslotdone1044
bb_rcslotdone1044:
  %v4905 = load i64, ptr %slot39, align 8
  %p4906 = inttoptr i64 %v4905 to ptr
  store i64 1, ptr %p4906, align 8, !alias.scope !3, !noalias !4
  %v4907 = load i64, ptr %slot39, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  %ld4909 = load i64, ptr %p4908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4909, ptr %slot847, align 8
  %v4910 = load i64, ptr %slot38, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %ld4912 = load i64, ptr %p4911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4912, ptr %slot848, align 8
  %v4913 = load i64, ptr %slot848, align 8
  %v4914 = load i64, ptr %slot847, align 8
  %ovpair4916 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4913, i64 %v4914)
  %op4915 = extractvalue { i64, i1 } %ovpair4916, 0
  %ov4917 = extractvalue { i64, i1 } %ovpair4916, 1
  store i64 %op4915, ptr %slot849, align 8
  %cv4918 = zext i1 %ov4917 to i64
  store i64 %cv4918, ptr %slot850, align 8
  %v4919 = load i64, ptr %slot850, align 8
  %cond4920 = icmp ne i64 %v4919, 0
  br i1 %cond4920, label %bb_overflow1053, label %bb_checked1053
bb_overflow1053:
  %v4921 = load i64, ptr %slot1, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %v4923 = load i64, ptr %slot848, align 8
  %v4924 = load i64, ptr %slot847, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4922, i64 0, i64 %v4923, i64 %v4924, i64 64) nomerge, !dbg !156
  unreachable
bb_checked1053:
  %v4925 = load i64, ptr %slot849, align 8
  %v4926 = load i64, ptr %slot38, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  store i64 %v4925, ptr %p4927, align 8, !alias.scope !3, !noalias !4
  %v4928 = load i64, ptr %slot38, align 8
  %p4929 = inttoptr i64 %v4928 to ptr
  %ld4930 = load i64, ptr %p4929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4930, ptr %slot851, align 8
  %v4931 = load i64, ptr %slot851, align 8
  %v4932 = load i64, ptr %slot29, align 8
  %p4933 = inttoptr i64 %v4932 to ptr
  store i64 %v4931, ptr %p4933, align 8, !alias.scope !3, !noalias !4
  %v4934 = load i64, ptr %slot28, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %ld4936 = load i64, ptr %p4935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4936, ptr %slot852, align 8
  %v4937 = load i64, ptr %slot852, align 8
  %v4938 = load i64, ptr %slot38, align 8
  %p4939 = inttoptr i64 %v4938 to ptr
  store i64 %v4937, ptr %p4939, align 8, !alias.scope !3, !noalias !4
  %v4940 = load i64, ptr %slot28, align 8
  %p4941 = inttoptr i64 %v4940 to ptr
  %ld4942 = load i64, ptr %p4941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4942, ptr %slot853, align 8
  %v4943 = load i64, ptr %slot853, align 8
  %v4944 = load i64, ptr %slot38, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  store i64 %v4943, ptr %p4945, align 8, !alias.scope !3, !noalias !4
  %v4946 = load i64, ptr %slot28, align 8
  %p4947 = inttoptr i64 %v4946 to ptr
  %ld4948 = load i64, ptr %p4947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4948, ptr %slot854, align 8
  %v4949 = load i64, ptr %slot854, align 8
  %v4950 = load i64, ptr %slot38, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i64 %v4949, ptr %p4951, align 8, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot29, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i64, ptr %p4953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4954, ptr %slot855, align 8
  %v4955 = load i64, ptr %slot855, align 8
  %v4956 = load i64, ptr %slot39, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  store i64 %v4955, ptr %p4957, align 8, !alias.scope !3, !noalias !4
  %v4958 = load i64, ptr %slot28, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  %ld4960 = load i64, ptr %p4959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4960, ptr %slot856, align 8
  %v4961 = load i64, ptr %slot856, align 8
  %v4962 = load i64, ptr %slot38, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  store i64 %v4961, ptr %p4963, align 8, !alias.scope !3, !noalias !4
  %v4964 = load i64, ptr %slot29, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %ld4966 = load i64, ptr %p4965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4966, ptr %slot857, align 8
  %v4967 = load i64, ptr %slot28, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i64, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4969, ptr %slot858, align 8
  %v4970 = load i64, ptr %slot858, align 8
  %op4971 = add i64 %v4970, 24
  store i64 %op4971, ptr %slot859, align 8
  %v4972 = load i64, ptr %slot857, align 8
  %v4973 = load i64, ptr %slot859, align 8
  %p4974 = inttoptr i64 %v4973 to ptr
  store i64 %v4972, ptr %p4974, align 8, !alias.scope !4, !noalias !3
  %v4975 = load i64, ptr %slot38, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  store i64 0, ptr %p4976, align 8, !alias.scope !3, !noalias !4
  br label %bb_i76
bb_i76:
  %v4977 = load i64, ptr %slot28, align 8
  %p4978 = inttoptr i64 %v4977 to ptr
  %ld4979 = load i64, ptr %p4978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4979, ptr %slot860, align 8
  %v4980 = load i64, ptr %slot860, align 8
  %v4981 = load i64, ptr %slot38, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  store i64 %v4980, ptr %p4982, align 8, !alias.scope !3, !noalias !4
  %v4983 = load i64, ptr %slot38, align 8
  %p4984 = inttoptr i64 %v4983 to ptr
  %ld4985 = load i64, ptr %p4984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4985, ptr %slot861, align 8
  %v4986 = load i64, ptr %slot861, align 8
  %op4987 = add i64 %v4986, 16
  store i64 %op4987, ptr %slot862, align 8
  %v4988 = load i64, ptr %slot862, align 8
  %p4989 = inttoptr i64 %v4988 to ptr
  %ld4990 = load i64, ptr %p4989, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4990, ptr %slot863, align 8
  %v4991 = load i64, ptr %slot863, align 8
  %v4992 = load i64, ptr %slot38, align 8
  %p4993 = inttoptr i64 %v4992 to ptr
  store i64 %v4991, ptr %p4993, align 8, !alias.scope !3, !noalias !4
  %v4994 = load i64, ptr %slot17, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %ld4996 = load i32, ptr %p4995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4996, ptr %slot864, align 8
  %v4997 = load i32, ptr %slot864, align 8
  %cv4998 = zext i32 %v4997 to i64
  %cond4999 = icmp ne i64 %cv4998, 0
  br i1 %cond4999, label %bb_rcslotdrop1070, label %bb_rcslotdone1070
bb_rcslotdrop1070:
  %v5000 = load i64, ptr %slot17, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  store i32 0, ptr %p5001, align 4, !alias.scope !3, !noalias !4
  %v5002 = load i64, ptr %slot23, align 8
  store i64 %v5002, ptr %slot865, align 8
  %v5003 = load i64, ptr %slot18, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %ld5005 = load i32, ptr %p5004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5005, ptr %slot866, align 8
  %v5006 = load i32, ptr %slot866, align 8
  %op5007 = and i32 %v5006, 28
  store i32 %op5007, ptr %slot867, align 8
  %v5008 = load i32, ptr %slot867, align 8
  %cv5009 = zext i32 %v5008 to i64
  %cond5010 = icmp ne i64 %cv5009, 0
  br i1 %cond5010, label %bb_rcslotrole1070, label %bb_rcslotowner1070
bb_rcslotrole1070:
  %v5011 = load i64, ptr %slot45, align 8
  store i64 %v5011, ptr %slot868, align 8
  %v5012 = load i64, ptr %slot868, align 8
  %v5013 = load i64, ptr %slot865, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5012, i64 %v5013) nomerge, !dbg !158
  br label %bb_rcslotdone1070
bb_rcslotowner1070:
  %v5014 = load i64, ptr %slot45, align 8
  store i64 %v5014, ptr %slot869, align 8
  %v5015 = load i64, ptr %slot869, align 8
  %v5016 = load i64, ptr %slot865, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5015, i64 %v5016) nomerge, !dbg !158
  br label %bb_rcslotdone1070
bb_rcslotdone1070:
  %v5017 = load i64, ptr %slot39, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  store i64 1, ptr %p5018, align 8, !alias.scope !3, !noalias !4
  %v5019 = load i64, ptr %slot39, align 8
  %p5020 = inttoptr i64 %v5019 to ptr
  %ld5021 = load i64, ptr %p5020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5021, ptr %slot870, align 8
  %v5022 = load i64, ptr %slot38, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i64, ptr %p5023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5024, ptr %slot871, align 8
  %v5025 = load i64, ptr %slot871, align 8
  %v5026 = load i64, ptr %slot870, align 8
  %ovpair5028 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5025, i64 %v5026)
  %op5027 = extractvalue { i64, i1 } %ovpair5028, 0
  %ov5029 = extractvalue { i64, i1 } %ovpair5028, 1
  store i64 %op5027, ptr %slot872, align 8
  %cv5030 = zext i1 %ov5029 to i64
  store i64 %cv5030, ptr %slot873, align 8
  %v5031 = load i64, ptr %slot873, align 8
  %cond5032 = icmp ne i64 %v5031, 0
  br i1 %cond5032, label %bb_overflow1079, label %bb_checked1079
bb_overflow1079:
  %v5033 = load i64, ptr %slot1, align 8
  %p5034 = inttoptr i64 %v5033 to ptr
  %v5035 = load i64, ptr %slot871, align 8
  %v5036 = load i64, ptr %slot870, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5034, i64 0, i64 %v5035, i64 %v5036, i64 64) nomerge, !dbg !160
  unreachable
bb_checked1079:
  %v5037 = load i64, ptr %slot872, align 8
  %v5038 = load i64, ptr %slot38, align 8
  %p5039 = inttoptr i64 %v5038 to ptr
  store i64 %v5037, ptr %p5039, align 8, !alias.scope !3, !noalias !4
  %v5040 = load i64, ptr %slot38, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  %ld5042 = load i64, ptr %p5041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5042, ptr %slot874, align 8
  %v5043 = load i64, ptr %slot874, align 8
  %v5044 = load i64, ptr %slot30, align 8
  %p5045 = inttoptr i64 %v5044 to ptr
  store i64 %v5043, ptr %p5045, align 8, !alias.scope !3, !noalias !4
  %v5046 = load i64, ptr %slot28, align 8
  %p5047 = inttoptr i64 %v5046 to ptr
  %ld5048 = load i64, ptr %p5047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5048, ptr %slot875, align 8
  %v5049 = load i64, ptr %slot875, align 8
  %v5050 = load i64, ptr %slot38, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  store i64 %v5049, ptr %p5051, align 8, !alias.scope !3, !noalias !4
  %v5052 = load i64, ptr %slot28, align 8
  %p5053 = inttoptr i64 %v5052 to ptr
  %ld5054 = load i64, ptr %p5053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5054, ptr %slot876, align 8
  %v5055 = load i64, ptr %slot876, align 8
  %v5056 = load i64, ptr %slot38, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  store i64 %v5055, ptr %p5057, align 8, !alias.scope !3, !noalias !4
  %v5058 = load i64, ptr %slot28, align 8
  %p5059 = inttoptr i64 %v5058 to ptr
  %ld5060 = load i64, ptr %p5059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5060, ptr %slot877, align 8
  %v5061 = load i64, ptr %slot877, align 8
  %v5062 = load i64, ptr %slot38, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  store i64 %v5061, ptr %p5063, align 8, !alias.scope !3, !noalias !4
  %v5064 = load i64, ptr %slot30, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  %ld5066 = load i64, ptr %p5065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5066, ptr %slot878, align 8
  %v5067 = load i64, ptr %slot878, align 8
  %v5068 = load i64, ptr %slot39, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  store i64 %v5067, ptr %p5069, align 8, !alias.scope !3, !noalias !4
  %v5070 = load i64, ptr %slot28, align 8
  %p5071 = inttoptr i64 %v5070 to ptr
  %ld5072 = load i64, ptr %p5071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5072, ptr %slot879, align 8
  %v5073 = load i64, ptr %slot879, align 8
  %v5074 = load i64, ptr %slot38, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  store i64 %v5073, ptr %p5075, align 8, !alias.scope !3, !noalias !4
  %v5076 = load i64, ptr %slot30, align 8
  %p5077 = inttoptr i64 %v5076 to ptr
  %ld5078 = load i64, ptr %p5077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5078, ptr %slot880, align 8
  %v5079 = load i64, ptr %slot28, align 8
  %p5080 = inttoptr i64 %v5079 to ptr
  %ld5081 = load i64, ptr %p5080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5081, ptr %slot881, align 8
  %v5082 = load i64, ptr %slot881, align 8
  %op5083 = add i64 %v5082, 16
  store i64 %op5083, ptr %slot882, align 8
  %v5084 = load i64, ptr %slot880, align 8
  %v5085 = load i64, ptr %slot882, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  store i64 %v5084, ptr %p5086, align 8, !alias.scope !4, !noalias !3
  %v5087 = load i64, ptr %slot38, align 8
  %p5088 = inttoptr i64 %v5087 to ptr
  store i64 0, ptr %p5088, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i92:
  %v5089 = load i64, ptr %slot28, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  %ld5091 = load i64, ptr %p5090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5091, ptr %slot883, align 8
  %v5092 = load i64, ptr %slot883, align 8
  %v5093 = load i64, ptr %slot38, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  store i64 %v5092, ptr %p5094, align 8, !alias.scope !3, !noalias !4
  %v5095 = load i64, ptr %slot38, align 8
  %p5096 = inttoptr i64 %v5095 to ptr
  %ld5097 = load i64, ptr %p5096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5097, ptr %slot884, align 8
  %v5098 = load i64, ptr %slot17, align 8
  %p5099 = inttoptr i64 %v5098 to ptr
  %ld5100 = load i32, ptr %p5099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5100, ptr %slot885, align 8
  %v5101 = load i64, ptr %slot18, align 8
  %p5102 = inttoptr i64 %v5101 to ptr
  %ld5103 = load i32, ptr %p5102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5103, ptr %slot886, align 8
  %v5104 = load i32, ptr %slot886, align 8
  %op5105 = and i32 %v5104, 24
  store i32 %op5105, ptr %slot886, align 8
  %v5106 = load i32, ptr %slot886, align 8
  %cmp5107 = icmp eq i32 %v5106, 0
  %cv5108 = zext i1 %cmp5107 to i32
  store i32 %cv5108, ptr %slot887, align 8
  %v5109 = load i32, ptr %slot885, align 8
  %v5110 = load i32, ptr %slot887, align 8
  %op5111 = and i32 %v5109, %v5110
  store i32 %op5111, ptr %slot888, align 8
  %v5112 = load i32, ptr %slot888, align 8
  %cv5113 = zext i32 %v5112 to i64
  %cond5114 = icmp ne i64 %cv5113, 0
  br i1 %cond5114, label %bb_rctake1092, label %bb_rccopy1092
bb_rctake1092:
  %v5115 = load i64, ptr %slot27, align 8
  store i64 %v5115, ptr %slot889, align 8
  %v5116 = load i64, ptr %slot46, align 8
  store i64 %v5116, ptr %slot890, align 8
  %v5117 = load i64, ptr %slot884, align 8
  %v5118 = load i64, ptr %slot889, align 8
  %op5119 = sub i64 %v5117, %v5118
  store i64 %op5119, ptr %slot891, align 8
  %v5120 = load i64, ptr %slot889, align 8
  %v5121 = load i64, ptr %slot884, align 8
  %op5122 = sub i64 %v5120, %v5121
  store i64 %op5122, ptr %slot892, align 8
  %v5123 = load i64, ptr %slot891, align 8
  %cmp5124 = icmp ult i64 %v5123, 32
  %cv5125 = zext i1 %cmp5124 to i32
  store i32 %cv5125, ptr %slot893, align 8
  %v5126 = load i64, ptr %slot892, align 8
  %cmp5127 = icmp ult i64 %v5126, 32
  %cv5128 = zext i1 %cmp5127 to i32
  store i32 %cv5128, ptr %slot894, align 8
  %v5129 = load i32, ptr %slot893, align 8
  %v5130 = load i32, ptr %slot894, align 8
  %op5131 = or i32 %v5129, %v5130
  store i32 %op5131, ptr %slot895, align 8
  %v5132 = load i32, ptr %slot895, align 8
  %cv5133 = zext i32 %v5132 to i64
  %cond5134 = icmp ne i64 %cv5133, 0
  br i1 %cond5134, label %bb_rcmoveslow1101, label %bb_rcmovecheck1101
bb_rcmovecheck1101:
  %v5135 = load i64, ptr %slot884, align 8
  %op5136 = add i64 %v5135, 0
  store i64 %op5136, ptr %slot896, align 8
  %v5137 = load i64, ptr %slot896, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  %ld5139 = load i64, ptr %p5138, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5139, ptr %slot897, align 8
  %v5140 = load i64, ptr %slot897, align 8
  %cmp5141 = icmp ne i64 %v5140, 0
  %cv5142 = zext i1 %cmp5141 to i32
  store i32 %cv5142, ptr %slot898, align 8
  %v5143 = load i32, ptr %slot898, align 8
  %cv5144 = zext i32 %v5143 to i64
  %cond5145 = icmp ne i64 %cv5144, 0
  br i1 %cond5145, label %bb_rcmoveheader1109, label %bb_rcmovenext1109
bb_rcmoveheader1109:
  %v5146 = load i64, ptr %slot897, align 8
  %op5147 = sub i64 %v5146, 16
  store i64 %op5147, ptr %slot899, align 8
  %v5148 = load i64, ptr %slot897, align 8
  %p5149 = inttoptr i64 %v5148 to ptr
  %rgep5150 = getelementptr i8, ptr %p5149, i64 -16
  %ld5151 = load i64, ptr %rgep5150, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5151, ptr %slot900, align 8
  %v5152 = load i64, ptr %slot900, align 8
  %op5153 = and i64 %v5152, 5764607523034234881
  store i64 %op5153, ptr %slot901, align 8
  %v5154 = load i64, ptr %slot901, align 8
  %cmp5155 = icmp ne i64 %v5154, 0
  %cv5156 = zext i1 %cmp5155 to i32
  store i32 %cv5156, ptr %slot902, align 8
  %v5157 = load i32, ptr %slot902, align 8
  %cv5158 = zext i32 %v5157 to i64
  %cond5159 = icmp ne i64 %cv5158, 0
  br i1 %cond5159, label %bb_rcmoveslow1101, label %bb_rcmovenext1109
bb_rcmovenext1109:
  %v5160 = load i64, ptr %slot884, align 8
  %v5161 = load i64, ptr %slot889, align 8
  %p5162 = inttoptr i64 %v5160 to ptr
  %p5163 = inttoptr i64 %v5161 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5163, ptr %p5162, i64 32, i1 false), !alias.scope !10000000
  %v5164 = load i64, ptr %slot884, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  store i64 0, ptr %p5165, align 8, !alias.scope !4, !noalias !3
  %v5166 = load i64, ptr %slot884, align 8
  %op5167 = add i64 %v5166, 8
  store i64 %op5167, ptr %slot903, align 8
  %v5168 = load i64, ptr %slot903, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  store i64 0, ptr %p5169, align 8, !alias.scope !4, !noalias !3
  %v5170 = load i64, ptr %slot884, align 8
  %op5171 = add i64 %v5170, 16
  store i64 %op5171, ptr %slot904, align 8
  %v5172 = load i64, ptr %slot904, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  store i64 0, ptr %p5173, align 8, !alias.scope !4, !noalias !3
  %v5174 = load i64, ptr %slot884, align 8
  %op5175 = add i64 %v5174, 24
  store i64 %op5175, ptr %slot905, align 8
  %v5176 = load i64, ptr %slot905, align 8
  %p5177 = inttoptr i64 %v5176 to ptr
  store i64 0, ptr %p5177, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1101
bb_rcmoveslow1101:
  %v5178 = load i64, ptr %slot45, align 8
  %v5179 = load i64, ptr %slot889, align 8
  %v5180 = load i64, ptr %slot884, align 8
  %v5181 = load i64, ptr %slot890, align 8
  %cv5182 = trunc i64 %v5181 to i32
  %call5183 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v5178, i64 %v5179, i64 %v5180, i32 %cv5182) nomerge, !dbg !162
  store i32 %call5183, ptr %slot906, align 8
  %v5184 = load i32, ptr %slot906, align 8
  %cv5185 = zext i32 %v5184 to i64
  %cond5186 = icmp ne i64 %cv5185, 0
  br i1 %cond5186, label %bb_rcsuccess1119, label %bb_rcfailure1119
bb_rcfailure1119:
  %v5187 = load i64, ptr %slot45, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  %call5189 = call i32 @myl_rc_take_failure(ptr %p5188) nomerge, !dbg !162
  store i32 %call5189, ptr %slot907, align 8
  %v5190 = load i64, ptr %slot1, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  %v5192 = load i32, ptr %slot907, align 8
  %call5193 = call i32 @myl_qbe_rc_status(ptr %p5191, i32 %v5192) nomerge, !dbg !162
  store i32 %call5193, ptr %slot908, align 8
  br label %bb_failure
bb_rcsuccess1119:
  br label %bb_rcmoved1101
bb_rcmoved1101:
  %v5194 = load i64, ptr %slot17, align 8
  %p5195 = inttoptr i64 %v5194 to ptr
  store i32 0, ptr %p5195, align 4, !alias.scope !3, !noalias !4
  %v5196 = load i64, ptr %slot22, align 8
  %p5197 = inttoptr i64 %v5196 to ptr
  store i32 2, ptr %p5197, align 4, !alias.scope !3, !noalias !4
  %v5198 = load i64, ptr %slot21, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  store i32 1, ptr %p5199, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1092
bb_rccopy1092:
  %v5200 = load i64, ptr %slot27, align 8
  store i64 %v5200, ptr %slot909, align 8
  %v5201 = load i64, ptr %slot46, align 8
  store i64 %v5201, ptr %slot910, align 8
  %v5202 = load i64, ptr %slot45, align 8
  %v5203 = load i64, ptr %slot909, align 8
  %v5204 = load i64, ptr %slot884, align 8
  %v5205 = load i64, ptr %slot910, align 8
  %cv5206 = trunc i64 %v5205 to i32
  %call5207 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v5202, i64 %v5203, i64 %v5204, i32 %cv5206) nomerge, !dbg !162
  store i32 %call5207, ptr %slot911, align 8
  %v5208 = load i32, ptr %slot911, align 8
  %cv5209 = zext i32 %v5208 to i64
  %cond5210 = icmp ne i64 %cv5209, 0
  br i1 %cond5210, label %bb_rcsuccess1128, label %bb_rcfailure1128
bb_rcfailure1128:
  %v5211 = load i64, ptr %slot45, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %call5213 = call i32 @myl_rc_take_failure(ptr %p5212) nomerge, !dbg !162
  store i32 %call5213, ptr %slot912, align 8
  %v5214 = load i64, ptr %slot1, align 8
  %p5215 = inttoptr i64 %v5214 to ptr
  %v5216 = load i32, ptr %slot912, align 8
  %call5217 = call i32 @myl_qbe_rc_status(ptr %p5215, i32 %v5216) nomerge, !dbg !162
  store i32 %call5217, ptr %slot913, align 8
  br label %bb_failure
bb_rcsuccess1128:
  %v5218 = load i64, ptr %slot22, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  store i32 2, ptr %p5219, align 4, !alias.scope !3, !noalias !4
  %v5220 = load i64, ptr %slot21, align 8
  %p5221 = inttoptr i64 %v5220 to ptr
  store i32 1, ptr %p5221, align 4, !alias.scope !3, !noalias !4
  %v5222 = load i64, ptr %slot17, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  %ld5224 = load i32, ptr %p5223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5224, ptr %slot914, align 8
  %v5225 = load i32, ptr %slot914, align 8
  %cv5226 = zext i32 %v5225 to i64
  %cond5227 = icmp ne i64 %cv5226, 0
  br i1 %cond5227, label %bb_rcslotdrop1135, label %bb_rcslotdone1135
bb_rcslotdrop1135:
  %v5228 = load i64, ptr %slot17, align 8
  %p5229 = inttoptr i64 %v5228 to ptr
  store i32 0, ptr %p5229, align 4, !alias.scope !3, !noalias !4
  %v5230 = load i64, ptr %slot23, align 8
  store i64 %v5230, ptr %slot915, align 8
  %v5231 = load i64, ptr %slot18, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  %ld5233 = load i32, ptr %p5232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5233, ptr %slot916, align 8
  %v5234 = load i32, ptr %slot916, align 8
  %op5235 = and i32 %v5234, 28
  store i32 %op5235, ptr %slot917, align 8
  %v5236 = load i32, ptr %slot917, align 8
  %cv5237 = zext i32 %v5236 to i64
  %cond5238 = icmp ne i64 %cv5237, 0
  br i1 %cond5238, label %bb_rcslotrole1135, label %bb_rcslotowner1135
bb_rcslotrole1135:
  %v5239 = load i64, ptr %slot45, align 8
  store i64 %v5239, ptr %slot918, align 8
  %v5240 = load i64, ptr %slot918, align 8
  %v5241 = load i64, ptr %slot915, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5240, i64 %v5241) nomerge, !dbg !162
  br label %bb_rcslotdone1135
bb_rcslotowner1135:
  %v5242 = load i64, ptr %slot915, align 8
  %p5244 = inttoptr i64 %v5242 to ptr
  %gep5245 = getelementptr i8, ptr %p5244, i64 0
  %op5243 = ptrtoint ptr %gep5245 to i64
  store i64 %op5243, ptr %slot919, align 8
  %v5246 = load i64, ptr %slot45, align 8
  store i64 %v5246, ptr %slot920, align 8
  %v5247 = load i64, ptr %slot919, align 8
  %p5248 = inttoptr i64 %v5247 to ptr
  %ld5249 = load i64, ptr %p5248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5249, ptr %slot921, align 8
  %v5250 = load i64, ptr %slot921, align 8
  %cmp5251 = icmp ne i64 %v5250, 0
  %cv5252 = zext i1 %cmp5251 to i32
  store i32 %cv5252, ptr %slot922, align 8
  %v5253 = load i32, ptr %slot922, align 8
  %cv5254 = zext i32 %v5253 to i64
  %cond5255 = icmp ne i64 %cv5254, 0
  br i1 %cond5255, label %bb_rcgnn1153, label %bb_rcgdone1153
bb_rcgnn1153:
  %v5256 = load i64, ptr %slot921, align 8
  %op5257 = sub i64 %v5256, 16
  store i64 %op5257, ptr %slot923, align 8
  %v5258 = load i64, ptr %slot921, align 8
  %p5259 = inttoptr i64 %v5258 to ptr
  %rgep5260 = getelementptr i8, ptr %p5259, i64 -16
  %ld5261 = load i64, ptr %rgep5260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5261, ptr %slot924, align 8
  %v5262 = load i64, ptr %slot924, align 8
  %op5263 = and i64 %v5262, 4611686018427387906
  store i64 %op5263, ptr %slot925, align 8
  %v5264 = load i64, ptr %slot925, align 8
  %cmp5265 = icmp ne i64 %v5264, 0
  %cv5266 = zext i1 %cmp5265 to i32
  store i32 %cv5266, ptr %slot926, align 8
  %v5267 = load i32, ptr %slot926, align 8
  %cv5268 = zext i32 %v5267 to i64
  %cond5269 = icmp ne i64 %cv5268, 0
  br i1 %cond5269, label %bb_rcgclear1153, label %bb_rcgcounted1153
bb_rcgcounted1153:
  %v5270 = load i64, ptr %slot921, align 8
  %op5271 = sub i64 %v5270, 32
  store i64 %op5271, ptr %slot927, align 8
  %v5272 = load i64, ptr %slot921, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %rgep5274 = getelementptr i8, ptr %p5273, i64 -32
  %ld5275 = load i64, ptr %rgep5274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5275, ptr %slot928, align 8
  %v5276 = load i64, ptr %slot928, align 8
  %op5277 = sub i64 %v5276, 1
  store i64 %op5277, ptr %slot929, align 8
  %v5278 = load i64, ptr %slot929, align 8
  %cmp5279 = icmp eq i64 %v5278, 0
  %cv5280 = zext i1 %cmp5279 to i32
  store i32 %cv5280, ptr %slot930, align 8
  %v5281 = load i32, ptr %slot930, align 8
  %cv5282 = zext i32 %v5281 to i64
  %cond5283 = icmp ne i64 %cv5282, 0
  br i1 %cond5283, label %bb_rcglast1153, label %bb_rcgdec1153
bb_rcglast1153:
  %v5284 = load i64, ptr %slot921, align 8
  %op5285 = sub i64 %v5284, 24
  store i64 %op5285, ptr %slot931, align 8
  %v5286 = load i64, ptr %slot921, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  %rgep5288 = getelementptr i8, ptr %p5287, i64 -24
  %ld5289 = load i64, ptr %rgep5288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5289, ptr %slot932, align 8
  %v5290 = load i64, ptr %slot932, align 8
  %cmp5291 = icmp ne i64 %v5290, 0
  %cv5292 = zext i1 %cmp5291 to i32
  store i32 %cv5292, ptr %slot933, align 8
  %v5293 = load i32, ptr %slot933, align 8
  %cv5294 = zext i32 %v5293 to i64
  %cond5295 = icmp ne i64 %cv5294, 0
  br i1 %cond5295, label %bb_rcgdec1153, label %bb_rcgslow1153
bb_rcgslow1153:
  %v5296 = load i64, ptr %slot920, align 8
  %v5297 = load i64, ptr %slot919, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5296, i64 %v5297) nomerge, !dbg !162
  br label %bb_rcgdone1153
bb_rcgdec1153:
  %v5298 = load i64, ptr %slot929, align 8
  %v5299 = load i64, ptr %slot921, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  %rgep5301 = getelementptr i8, ptr %p5300, i64 -32
  store i64 %v5298, ptr %rgep5301, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1153
bb_rcgclear1153:
  %v5302 = load i64, ptr %slot919, align 8
  %p5303 = inttoptr i64 %v5302 to ptr
  store i64 0, ptr %p5303, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1153
bb_rcgdone1153:
  %v5304 = load i64, ptr %slot915, align 8
  %p5305 = inttoptr i64 %v5304 to ptr
  store i64 0, ptr %p5305, align 8, !alias.scope !3, !noalias !4
  %v5306 = load i64, ptr %slot915, align 8
  %p5308 = inttoptr i64 %v5306 to ptr
  %gep5309 = getelementptr i8, ptr %p5308, i64 8
  %op5307 = ptrtoint ptr %gep5309 to i64
  store i64 %op5307, ptr %slot934, align 8
  %v5310 = load i64, ptr %slot934, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  store i64 0, ptr %p5311, align 8, !alias.scope !3, !noalias !4
  %v5312 = load i64, ptr %slot915, align 8
  %p5314 = inttoptr i64 %v5312 to ptr
  %gep5315 = getelementptr i8, ptr %p5314, i64 16
  %op5313 = ptrtoint ptr %gep5315 to i64
  store i64 %op5313, ptr %slot935, align 8
  %v5316 = load i64, ptr %slot935, align 8
  %p5317 = inttoptr i64 %v5316 to ptr
  store i64 0, ptr %p5317, align 8, !alias.scope !3, !noalias !4
  %v5318 = load i64, ptr %slot915, align 8
  %p5320 = inttoptr i64 %v5318 to ptr
  %gep5321 = getelementptr i8, ptr %p5320, i64 24
  %op5319 = ptrtoint ptr %gep5321 to i64
  store i64 %op5319, ptr %slot936, align 8
  %v5322 = load i64, ptr %slot936, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  store i64 0, ptr %p5323, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1135
bb_rcslotdone1135:
  br label %bb_rcprepared1092
bb_rcprepared1092:
  %v5324 = load i64, ptr %slot15, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  %ld5326 = load i32, ptr %p5325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5326, ptr %slot937, align 8
  %v5327 = load i32, ptr %slot937, align 8
  %cv5328 = zext i32 %v5327 to i64
  %cond5329 = icmp ne i64 %cv5328, 0
  br i1 %cond5329, label %bb_rcslotdrop1163, label %bb_rcslotdone1163
bb_rcslotdrop1163:
  %v5330 = load i64, ptr %slot15, align 8
  %p5331 = inttoptr i64 %v5330 to ptr
  store i32 0, ptr %p5331, align 4, !alias.scope !3, !noalias !4
  %v5332 = load i64, ptr %slot37, align 8
  store i64 %v5332, ptr %slot938, align 8
  %v5333 = load i64, ptr %slot16, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  %ld5335 = load i32, ptr %p5334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5335, ptr %slot939, align 8
  %v5336 = load i32, ptr %slot939, align 8
  %op5337 = and i32 %v5336, 28
  store i32 %op5337, ptr %slot940, align 8
  %v5338 = load i32, ptr %slot940, align 8
  %cv5339 = zext i32 %v5338 to i64
  %cond5340 = icmp ne i64 %cv5339, 0
  br i1 %cond5340, label %bb_rcslotrole1163, label %bb_rcslotowner1163
bb_rcslotrole1163:
  %v5341 = load i64, ptr %slot45, align 8
  store i64 %v5341, ptr %slot941, align 8
  %v5342 = load i64, ptr %slot941, align 8
  %v5343 = load i64, ptr %slot938, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5342, i64 %v5343) nomerge, !dbg !162
  br label %bb_rcslotdone1163
bb_rcslotowner1163:
  %v5344 = load i64, ptr %slot938, align 8
  %p5346 = inttoptr i64 %v5344 to ptr
  %gep5347 = getelementptr i8, ptr %p5346, i64 0
  %op5345 = ptrtoint ptr %gep5347 to i64
  store i64 %op5345, ptr %slot942, align 8
  %v5348 = load i64, ptr %slot45, align 8
  store i64 %v5348, ptr %slot943, align 8
  %v5349 = load i64, ptr %slot942, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  %ld5351 = load i64, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5351, ptr %slot944, align 8
  %v5352 = load i64, ptr %slot944, align 8
  %cmp5353 = icmp ne i64 %v5352, 0
  %cv5354 = zext i1 %cmp5353 to i32
  store i32 %cv5354, ptr %slot945, align 8
  %v5355 = load i32, ptr %slot945, align 8
  %cv5356 = zext i32 %v5355 to i64
  %cond5357 = icmp ne i64 %cv5356, 0
  br i1 %cond5357, label %bb_rcgnn1181, label %bb_rcgdone1181
bb_rcgnn1181:
  %v5358 = load i64, ptr %slot944, align 8
  %op5359 = sub i64 %v5358, 16
  store i64 %op5359, ptr %slot946, align 8
  %v5360 = load i64, ptr %slot944, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %rgep5362 = getelementptr i8, ptr %p5361, i64 -16
  %ld5363 = load i64, ptr %rgep5362, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5363, ptr %slot947, align 8
  %v5364 = load i64, ptr %slot947, align 8
  %op5365 = and i64 %v5364, 4611686018427387906
  store i64 %op5365, ptr %slot948, align 8
  %v5366 = load i64, ptr %slot948, align 8
  %cmp5367 = icmp ne i64 %v5366, 0
  %cv5368 = zext i1 %cmp5367 to i32
  store i32 %cv5368, ptr %slot949, align 8
  %v5369 = load i32, ptr %slot949, align 8
  %cv5370 = zext i32 %v5369 to i64
  %cond5371 = icmp ne i64 %cv5370, 0
  br i1 %cond5371, label %bb_rcgclear1181, label %bb_rcgcounted1181
bb_rcgcounted1181:
  %v5372 = load i64, ptr %slot944, align 8
  %op5373 = sub i64 %v5372, 32
  store i64 %op5373, ptr %slot950, align 8
  %v5374 = load i64, ptr %slot944, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  %rgep5376 = getelementptr i8, ptr %p5375, i64 -32
  %ld5377 = load i64, ptr %rgep5376, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5377, ptr %slot951, align 8
  %v5378 = load i64, ptr %slot951, align 8
  %op5379 = sub i64 %v5378, 1
  store i64 %op5379, ptr %slot952, align 8
  %v5380 = load i64, ptr %slot952, align 8
  %cmp5381 = icmp eq i64 %v5380, 0
  %cv5382 = zext i1 %cmp5381 to i32
  store i32 %cv5382, ptr %slot953, align 8
  %v5383 = load i32, ptr %slot953, align 8
  %cv5384 = zext i32 %v5383 to i64
  %cond5385 = icmp ne i64 %cv5384, 0
  br i1 %cond5385, label %bb_rcglast1181, label %bb_rcgdec1181
bb_rcglast1181:
  %v5386 = load i64, ptr %slot944, align 8
  %op5387 = sub i64 %v5386, 24
  store i64 %op5387, ptr %slot954, align 8
  %v5388 = load i64, ptr %slot944, align 8
  %p5389 = inttoptr i64 %v5388 to ptr
  %rgep5390 = getelementptr i8, ptr %p5389, i64 -24
  %ld5391 = load i64, ptr %rgep5390, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5391, ptr %slot955, align 8
  %v5392 = load i64, ptr %slot955, align 8
  %cmp5393 = icmp ne i64 %v5392, 0
  %cv5394 = zext i1 %cmp5393 to i32
  store i32 %cv5394, ptr %slot956, align 8
  %v5395 = load i32, ptr %slot956, align 8
  %cv5396 = zext i32 %v5395 to i64
  %cond5397 = icmp ne i64 %cv5396, 0
  br i1 %cond5397, label %bb_rcgdec1181, label %bb_rcgslow1181
bb_rcgslow1181:
  %v5398 = load i64, ptr %slot943, align 8
  %v5399 = load i64, ptr %slot942, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5398, i64 %v5399) nomerge, !dbg !162
  br label %bb_rcgdone1181
bb_rcgdec1181:
  %v5400 = load i64, ptr %slot952, align 8
  %v5401 = load i64, ptr %slot944, align 8
  %p5402 = inttoptr i64 %v5401 to ptr
  %rgep5403 = getelementptr i8, ptr %p5402, i64 -32
  store i64 %v5400, ptr %rgep5403, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1181
bb_rcgclear1181:
  %v5404 = load i64, ptr %slot942, align 8
  %p5405 = inttoptr i64 %v5404 to ptr
  store i64 0, ptr %p5405, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1181
bb_rcgdone1181:
  %v5406 = load i64, ptr %slot938, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  store i64 0, ptr %p5407, align 8, !alias.scope !3, !noalias !4
  %v5408 = load i64, ptr %slot938, align 8
  %p5410 = inttoptr i64 %v5408 to ptr
  %gep5411 = getelementptr i8, ptr %p5410, i64 8
  %op5409 = ptrtoint ptr %gep5411 to i64
  store i64 %op5409, ptr %slot957, align 8
  %v5412 = load i64, ptr %slot957, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  store i64 0, ptr %p5413, align 8, !alias.scope !3, !noalias !4
  %v5414 = load i64, ptr %slot938, align 8
  %p5416 = inttoptr i64 %v5414 to ptr
  %gep5417 = getelementptr i8, ptr %p5416, i64 16
  %op5415 = ptrtoint ptr %gep5417 to i64
  store i64 %op5415, ptr %slot958, align 8
  %v5418 = load i64, ptr %slot958, align 8
  %p5419 = inttoptr i64 %v5418 to ptr
  store i64 0, ptr %p5419, align 8, !alias.scope !3, !noalias !4
  %v5420 = load i64, ptr %slot938, align 8
  %p5422 = inttoptr i64 %v5420 to ptr
  %gep5423 = getelementptr i8, ptr %p5422, i64 24
  %op5421 = ptrtoint ptr %gep5423 to i64
  store i64 %op5421, ptr %slot959, align 8
  %v5424 = load i64, ptr %slot959, align 8
  %p5425 = inttoptr i64 %v5424 to ptr
  store i64 0, ptr %p5425, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1163
bb_rcslotdone1163:
  %v5426 = load i64, ptr %slot37, align 8
  store i64 %v5426, ptr %slot960, align 8
  %v5427 = load i64, ptr %slot27, align 8
  store i64 %v5427, ptr %slot961, align 8
  %v5428 = load i64, ptr %slot961, align 8
  %v5429 = load i64, ptr %slot960, align 8
  %p5430 = inttoptr i64 %v5428 to ptr
  %p5431 = inttoptr i64 %v5429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5431, ptr %p5430, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5432 = load i64, ptr %slot21, align 8
  %p5433 = inttoptr i64 %v5432 to ptr
  store i32 0, ptr %p5433, align 4, !alias.scope !3, !noalias !4
  %v5434 = load i64, ptr %slot16, align 8
  %p5435 = inttoptr i64 %v5434 to ptr
  store i32 2, ptr %p5435, align 4, !alias.scope !3, !noalias !4
  %v5436 = load i64, ptr %slot22, align 8
  %p5437 = inttoptr i64 %v5436 to ptr
  %ld5438 = load i32, ptr %p5437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5438, ptr %slot962, align 8
  %v5439 = load i32, ptr %slot962, align 8
  %v5440 = load i64, ptr %slot16, align 8
  %p5441 = inttoptr i64 %v5440 to ptr
  store i32 %v5439, ptr %p5441, align 4, !alias.scope !3, !noalias !4
  %v5442 = load i64, ptr %slot15, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  store i32 1, ptr %p5443, align 4, !alias.scope !3, !noalias !4
  %v5444 = load i64, ptr %slot37, align 8
  %v5445 = load i64, ptr %slot38, align 8
  %p5446 = inttoptr i64 %v5445 to ptr
  store i64 %v5444, ptr %p5446, align 8, !alias.scope !3, !noalias !4
  %v5447 = load i64, ptr %slot38, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  %ld5449 = load i64, ptr %p5448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5449, ptr %slot963, align 8
  %v5450 = load i64, ptr %slot963, align 8
  %op5451 = add i64 %v5450, 16
  store i64 %op5451, ptr %slot964, align 8
  %v5452 = load i64, ptr %slot964, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  %ld5454 = load i64, ptr %p5453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5454, ptr %slot965, align 8
  %v5455 = load i64, ptr %slot965, align 8
  %v5456 = load i64, ptr %slot38, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  store i64 %v5455, ptr %p5457, align 8, !alias.scope !3, !noalias !4
  %v5458 = load i64, ptr %slot17, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i32, ptr %p5459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5460, ptr %slot966, align 8
  %v5461 = load i32, ptr %slot966, align 8
  %cv5462 = zext i32 %v5461 to i64
  %cond5463 = icmp ne i64 %cv5462, 0
  br i1 %cond5463, label %bb_rcslotdrop1200, label %bb_rcslotdone1200
bb_rcslotdrop1200:
  %v5464 = load i64, ptr %slot17, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i32 0, ptr %p5465, align 4, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot23, align 8
  store i64 %v5466, ptr %slot967, align 8
  %v5467 = load i64, ptr %slot18, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  %ld5469 = load i32, ptr %p5468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5469, ptr %slot968, align 8
  %v5470 = load i32, ptr %slot968, align 8
  %op5471 = and i32 %v5470, 28
  store i32 %op5471, ptr %slot969, align 8
  %v5472 = load i32, ptr %slot969, align 8
  %cv5473 = zext i32 %v5472 to i64
  %cond5474 = icmp ne i64 %cv5473, 0
  br i1 %cond5474, label %bb_rcslotrole1200, label %bb_rcslotowner1200
bb_rcslotrole1200:
  %v5475 = load i64, ptr %slot45, align 8
  store i64 %v5475, ptr %slot970, align 8
  %v5476 = load i64, ptr %slot970, align 8
  %v5477 = load i64, ptr %slot967, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5476, i64 %v5477) nomerge, !dbg !164
  br label %bb_rcslotdone1200
bb_rcslotowner1200:
  %v5478 = load i64, ptr %slot45, align 8
  store i64 %v5478, ptr %slot971, align 8
  %v5479 = load i64, ptr %slot971, align 8
  %v5480 = load i64, ptr %slot967, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5479, i64 %v5480) nomerge, !dbg !164
  br label %bb_rcslotdone1200
bb_rcslotdone1200:
  %v5481 = load i64, ptr %slot37, align 8
  %v5482 = load i64, ptr %slot39, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  store i64 %v5481, ptr %p5483, align 8, !alias.scope !3, !noalias !4
  %v5484 = load i64, ptr %slot39, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %ld5486 = load i64, ptr %p5485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5486, ptr %slot972, align 8
  %v5487 = load i64, ptr %slot972, align 8
  %op5488 = add i64 %v5487, 0
  store i64 %op5488, ptr %slot973, align 8
  %v5489 = load i64, ptr %slot973, align 8
  %p5490 = inttoptr i64 %v5489 to ptr
  %ld5491 = load i64, ptr %p5490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5491, ptr %slot974, align 8
  %v5492 = load i64, ptr %slot974, align 8
  %v5493 = load i64, ptr %slot39, align 8
  %p5494 = inttoptr i64 %v5493 to ptr
  store i64 %v5492, ptr %p5494, align 8, !alias.scope !3, !noalias !4
  %v5495 = load i64, ptr %slot39, align 8
  %p5496 = inttoptr i64 %v5495 to ptr
  %ld5497 = load i64, ptr %p5496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5497, ptr %slot975, align 8
  %v5498 = load i64, ptr %slot975, align 8
  %v5499 = load i64, ptr %slot26, align 8
  %p5500 = inttoptr i64 %v5499 to ptr
  store i64 %v5498, ptr %p5500, align 8, !alias.scope !3, !noalias !4
  %v5501 = load i64, ptr %slot26, align 8
  store i64 %v5501, ptr %slot976, align 8
  %v5502 = load i64, ptr %slot27, align 8
  store i64 %v5502, ptr %slot977, align 8
  %v5503 = load i64, ptr %slot976, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  %ld5505 = load i64, ptr %p5504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5505, ptr %slot978, align 8
  %v5506 = load i64, ptr %slot978, align 8
  %cmp5507 = icmp ne i64 %v5506, 0
  %cv5508 = zext i1 %cmp5507 to i32
  store i32 %cv5508, ptr %slot979, align 8
  %v5509 = load i32, ptr %slot979, align 8
  %cv5510 = zext i32 %v5509 to i64
  %cond5511 = icmp ne i64 %cv5510, 0
  br i1 %cond5511, label %bb_rcgnn1214, label %bb_rcgstore1214
bb_rcgnn1214:
  %v5512 = load i64, ptr %slot978, align 8
  %op5513 = sub i64 %v5512, 16
  store i64 %op5513, ptr %slot980, align 8
  %v5514 = load i64, ptr %slot978, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  %rgep5516 = getelementptr i8, ptr %p5515, i64 -16
  %ld5517 = load i64, ptr %rgep5516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5517, ptr %slot981, align 8
  %v5518 = load i64, ptr %slot981, align 8
  %op5519 = and i64 %v5518, 4611686018427387906
  store i64 %op5519, ptr %slot982, align 8
  %v5520 = load i64, ptr %slot982, align 8
  %cmp5521 = icmp ne i64 %v5520, 0
  %cv5522 = zext i1 %cmp5521 to i32
  store i32 %cv5522, ptr %slot983, align 8
  %v5523 = load i32, ptr %slot983, align 8
  %cv5524 = zext i32 %v5523 to i64
  %cond5525 = icmp ne i64 %cv5524, 0
  br i1 %cond5525, label %bb_rcgstore1214, label %bb_rcginc1214
bb_rcginc1214:
  %v5526 = load i64, ptr %slot978, align 8
  %op5527 = sub i64 %v5526, 24
  store i64 %op5527, ptr %slot984, align 8
  %v5528 = load i64, ptr %slot978, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %rgep5530 = getelementptr i8, ptr %p5529, i64 -24
  %ld5531 = load i64, ptr %rgep5530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5531, ptr %slot985, align 8
  %v5532 = load i64, ptr %slot985, align 8
  %op5533 = add i64 %v5532, 1
  store i64 %op5533, ptr %slot986, align 8
  %v5534 = load i64, ptr %slot986, align 8
  %cmp5535 = icmp eq i64 %v5534, 0
  %cv5536 = zext i1 %cmp5535 to i32
  store i32 %cv5536, ptr %slot987, align 8
  %v5537 = load i32, ptr %slot987, align 8
  %cv5538 = zext i32 %v5537 to i64
  %cond5539 = icmp ne i64 %cv5538, 0
  br i1 %cond5539, label %bb_rcglimit1214, label %bb_rcgcapacity1214
bb_rcglimit1214:
  %v5540 = load i64, ptr %slot1, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  %call5542 = call i32 @myl_qbe_rc_status(ptr %p5541, i32 2) nomerge, !dbg !166
  store i32 %call5542, ptr %slot988, align 8
  br label %bb_failure
bb_rcgcapacity1214:
  %v5543 = load i64, ptr %slot986, align 8
  %v5544 = load i64, ptr %slot978, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  %rgep5546 = getelementptr i8, ptr %p5545, i64 -24
  store i64 %v5543, ptr %rgep5546, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1214
bb_rcgstore1214:
  %v5547 = load i64, ptr %slot978, align 8
  %v5548 = load i64, ptr %slot977, align 8
  %p5549 = inttoptr i64 %v5548 to ptr
  store i64 %v5547, ptr %p5549, align 8, !alias.scope !3, !noalias !4
  %v5550 = load i64, ptr %slot22, align 8
  %p5551 = inttoptr i64 %v5550 to ptr
  store i32 2, ptr %p5551, align 4, !alias.scope !3, !noalias !4
  %v5552 = load i64, ptr %slot22, align 8
  %p5553 = inttoptr i64 %v5552 to ptr
  store i32 16, ptr %p5553, align 4, !alias.scope !3, !noalias !4
  %v5554 = load i64, ptr %slot21, align 8
  %p5555 = inttoptr i64 %v5554 to ptr
  store i32 1, ptr %p5555, align 4, !alias.scope !3, !noalias !4
  %v5556 = load i64, ptr %slot19, align 8
  %p5557 = inttoptr i64 %v5556 to ptr
  %ld5558 = load i32, ptr %p5557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5558, ptr %slot989, align 8
  %v5559 = load i32, ptr %slot989, align 8
  %cv5560 = zext i32 %v5559 to i64
  %cond5561 = icmp ne i64 %cv5560, 0
  br i1 %cond5561, label %bb_rcslotdrop1230, label %bb_rcslotdone1230
bb_rcslotdrop1230:
  %v5562 = load i64, ptr %slot19, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  store i32 0, ptr %p5563, align 4, !alias.scope !3, !noalias !4
  %v5564 = load i64, ptr %slot24, align 8
  store i64 %v5564, ptr %slot990, align 8
  %v5565 = load i64, ptr %slot20, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %ld5567 = load i32, ptr %p5566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5567, ptr %slot991, align 8
  %v5568 = load i32, ptr %slot991, align 8
  %op5569 = and i32 %v5568, 28
  store i32 %op5569, ptr %slot992, align 8
  %v5570 = load i32, ptr %slot992, align 8
  %cv5571 = zext i32 %v5570 to i64
  %cond5572 = icmp ne i64 %cv5571, 0
  br i1 %cond5572, label %bb_rcslotrole1230, label %bb_rcslotowner1230
bb_rcslotrole1230:
  %v5573 = load i64, ptr %slot45, align 8
  store i64 %v5573, ptr %slot993, align 8
  %v5574 = load i64, ptr %slot993, align 8
  %v5575 = load i64, ptr %slot990, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5574, i64 %v5575) nomerge, !dbg !166
  br label %bb_rcslotdone1230
bb_rcslotowner1230:
  %v5576 = load i64, ptr %slot45, align 8
  store i64 %v5576, ptr %slot994, align 8
  %v5577 = load i64, ptr %slot994, align 8
  %v5578 = load i64, ptr %slot990, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5577, i64 %v5578) nomerge, !dbg !166
  br label %bb_rcslotdone1230
bb_rcslotdone1230:
  %v5579 = load i64, ptr %slot24, align 8
  store i64 %v5579, ptr %slot995, align 8
  %v5580 = load i64, ptr %slot27, align 8
  store i64 %v5580, ptr %slot996, align 8
  %v5581 = load i64, ptr %slot996, align 8
  %v5582 = load i64, ptr %slot995, align 8
  %p5583 = inttoptr i64 %v5581 to ptr
  %p5584 = inttoptr i64 %v5582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5584, ptr %p5583, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5585 = load i64, ptr %slot20, align 8
  %p5586 = inttoptr i64 %v5585 to ptr
  store i32 2, ptr %p5586, align 4, !alias.scope !3, !noalias !4
  %v5587 = load i64, ptr %slot22, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %ld5589 = load i32, ptr %p5588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5589, ptr %slot997, align 8
  %v5590 = load i32, ptr %slot997, align 8
  %v5591 = load i64, ptr %slot20, align 8
  %p5592 = inttoptr i64 %v5591 to ptr
  store i32 %v5590, ptr %p5592, align 4, !alias.scope !3, !noalias !4
  %v5593 = load i64, ptr %slot21, align 8
  %p5594 = inttoptr i64 %v5593 to ptr
  store i32 0, ptr %p5594, align 4, !alias.scope !3, !noalias !4
  %v5595 = load i64, ptr %slot19, align 8
  %p5596 = inttoptr i64 %v5595 to ptr
  store i32 1, ptr %p5596, align 4, !alias.scope !3, !noalias !4
  %v5597 = load i64, ptr %slot995, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  %ld5599 = load i64, ptr %p5598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5599, ptr %slot998, align 8
  %v5600 = load i64, ptr %slot998, align 8
  %v5601 = load i64, ptr %slot39, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  store i64 %v5600, ptr %p5602, align 8, !alias.scope !3, !noalias !4
  %v5603 = load i64, ptr %slot39, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %ld5605 = load i64, ptr %p5604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5605, ptr %slot999, align 8
  %v5606 = load i64, ptr %slot999, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  %ld5608 = load i64, ptr %p5607, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5608, ptr %slot1000, align 8
  %v5609 = load i64, ptr %slot1000, align 8
  %v5610 = load i64, ptr %slot39, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  store i64 %v5609, ptr %p5611, align 8, !alias.scope !3, !noalias !4
  %v5612 = load i64, ptr %slot19, align 8
  %p5613 = inttoptr i64 %v5612 to ptr
  %ld5614 = load i32, ptr %p5613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5614, ptr %slot1001, align 8
  %v5615 = load i32, ptr %slot1001, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcslotdrop1250, label %bb_rcslotdone1250
bb_rcslotdrop1250:
  %v5618 = load i64, ptr %slot19, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  store i32 0, ptr %p5619, align 4, !alias.scope !3, !noalias !4
  %v5620 = load i64, ptr %slot24, align 8
  store i64 %v5620, ptr %slot1002, align 8
  %v5621 = load i64, ptr %slot20, align 8
  %p5622 = inttoptr i64 %v5621 to ptr
  %ld5623 = load i32, ptr %p5622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5623, ptr %slot1003, align 8
  %v5624 = load i32, ptr %slot1003, align 8
  %op5625 = and i32 %v5624, 28
  store i32 %op5625, ptr %slot1004, align 8
  %v5626 = load i32, ptr %slot1004, align 8
  %cv5627 = zext i32 %v5626 to i64
  %cond5628 = icmp ne i64 %cv5627, 0
  br i1 %cond5628, label %bb_rcslotrole1250, label %bb_rcslotowner1250
bb_rcslotrole1250:
  %v5629 = load i64, ptr %slot45, align 8
  store i64 %v5629, ptr %slot1005, align 8
  %v5630 = load i64, ptr %slot1002, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  %ld5632 = load i64, ptr %p5631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5632, ptr %slot1006, align 8
  %v5633 = load i64, ptr %slot1006, align 8
  %cmp5634 = icmp ne i64 %v5633, 0
  %cv5635 = zext i1 %cmp5634 to i32
  store i32 %cv5635, ptr %slot1007, align 8
  %v5636 = load i32, ptr %slot1007, align 8
  %cv5637 = zext i32 %v5636 to i64
  %cond5638 = icmp ne i64 %cv5637, 0
  br i1 %cond5638, label %bb_rcgnn1266, label %bb_rcgdone1266
bb_rcgnn1266:
  %v5639 = load i64, ptr %slot1006, align 8
  %op5640 = sub i64 %v5639, 16
  store i64 %op5640, ptr %slot1008, align 8
  %v5641 = load i64, ptr %slot1006, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  %rgep5643 = getelementptr i8, ptr %p5642, i64 -16
  %ld5644 = load i64, ptr %rgep5643, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5644, ptr %slot1009, align 8
  %v5645 = load i64, ptr %slot1009, align 8
  %op5646 = and i64 %v5645, 4611686018427387906
  store i64 %op5646, ptr %slot1010, align 8
  %v5647 = load i64, ptr %slot1010, align 8
  %cmp5648 = icmp ne i64 %v5647, 0
  %cv5649 = zext i1 %cmp5648 to i32
  store i32 %cv5649, ptr %slot1011, align 8
  %v5650 = load i32, ptr %slot1011, align 8
  %cv5651 = zext i32 %v5650 to i64
  %cond5652 = icmp ne i64 %cv5651, 0
  br i1 %cond5652, label %bb_rcgclear1266, label %bb_rcgcounted1266
bb_rcgcounted1266:
  %v5653 = load i64, ptr %slot1006, align 8
  %op5654 = sub i64 %v5653, 24
  store i64 %op5654, ptr %slot1012, align 8
  %v5655 = load i64, ptr %slot1006, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  %rgep5657 = getelementptr i8, ptr %p5656, i64 -24
  %ld5658 = load i64, ptr %rgep5657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5658, ptr %slot1013, align 8
  %v5659 = load i64, ptr %slot1013, align 8
  %op5660 = sub i64 %v5659, 1
  store i64 %op5660, ptr %slot1014, align 8
  %v5661 = load i64, ptr %slot1014, align 8
  %cmp5662 = icmp eq i64 %v5661, 0
  %cv5663 = zext i1 %cmp5662 to i32
  store i32 %cv5663, ptr %slot1015, align 8
  %v5664 = load i32, ptr %slot1015, align 8
  %cv5665 = zext i32 %v5664 to i64
  %cond5666 = icmp ne i64 %cv5665, 0
  br i1 %cond5666, label %bb_rcglast1266, label %bb_rcgdec1266
bb_rcglast1266:
  %v5667 = load i64, ptr %slot1006, align 8
  %op5668 = sub i64 %v5667, 32
  store i64 %op5668, ptr %slot1016, align 8
  %v5669 = load i64, ptr %slot1006, align 8
  %p5670 = inttoptr i64 %v5669 to ptr
  %rgep5671 = getelementptr i8, ptr %p5670, i64 -32
  %ld5672 = load i64, ptr %rgep5671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5672, ptr %slot1017, align 8
  %v5673 = load i64, ptr %slot1017, align 8
  %cmp5674 = icmp ne i64 %v5673, 0
  %cv5675 = zext i1 %cmp5674 to i32
  store i32 %cv5675, ptr %slot1018, align 8
  %v5676 = load i32, ptr %slot1018, align 8
  %cv5677 = zext i32 %v5676 to i64
  %cond5678 = icmp ne i64 %cv5677, 0
  br i1 %cond5678, label %bb_rcgdec1266, label %bb_rcgslow1266
bb_rcgslow1266:
  %v5679 = load i64, ptr %slot1005, align 8
  %v5680 = load i64, ptr %slot1002, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5679, i64 %v5680) nomerge, !dbg !168
  br label %bb_rcgdone1266
bb_rcgdec1266:
  %v5681 = load i64, ptr %slot1014, align 8
  %v5682 = load i64, ptr %slot1006, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  %rgep5684 = getelementptr i8, ptr %p5683, i64 -24
  store i64 %v5681, ptr %rgep5684, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1266
bb_rcgclear1266:
  %v5685 = load i64, ptr %slot1002, align 8
  %p5686 = inttoptr i64 %v5685 to ptr
  store i64 0, ptr %p5686, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1266
bb_rcgdone1266:
  br label %bb_rcslotdone1250
bb_rcslotowner1250:
  %v5687 = load i64, ptr %slot45, align 8
  store i64 %v5687, ptr %slot1019, align 8
  %v5688 = load i64, ptr %slot1002, align 8
  %p5689 = inttoptr i64 %v5688 to ptr
  %ld5690 = load i64, ptr %p5689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5690, ptr %slot1020, align 8
  %v5691 = load i64, ptr %slot1020, align 8
  %cmp5692 = icmp ne i64 %v5691, 0
  %cv5693 = zext i1 %cmp5692 to i32
  store i32 %cv5693, ptr %slot1021, align 8
  %v5694 = load i32, ptr %slot1021, align 8
  %cv5695 = zext i32 %v5694 to i64
  %cond5696 = icmp ne i64 %cv5695, 0
  br i1 %cond5696, label %bb_rcgnn1281, label %bb_rcgdone1281
bb_rcgnn1281:
  %v5697 = load i64, ptr %slot1020, align 8
  %op5698 = sub i64 %v5697, 16
  store i64 %op5698, ptr %slot1022, align 8
  %v5699 = load i64, ptr %slot1020, align 8
  %p5700 = inttoptr i64 %v5699 to ptr
  %rgep5701 = getelementptr i8, ptr %p5700, i64 -16
  %ld5702 = load i64, ptr %rgep5701, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5702, ptr %slot1023, align 8
  %v5703 = load i64, ptr %slot1023, align 8
  %op5704 = and i64 %v5703, 4611686018427387906
  store i64 %op5704, ptr %slot1024, align 8
  %v5705 = load i64, ptr %slot1024, align 8
  %cmp5706 = icmp ne i64 %v5705, 0
  %cv5707 = zext i1 %cmp5706 to i32
  store i32 %cv5707, ptr %slot1025, align 8
  %v5708 = load i32, ptr %slot1025, align 8
  %cv5709 = zext i32 %v5708 to i64
  %cond5710 = icmp ne i64 %cv5709, 0
  br i1 %cond5710, label %bb_rcgclear1281, label %bb_rcgcounted1281
bb_rcgcounted1281:
  %v5711 = load i64, ptr %slot1020, align 8
  %op5712 = sub i64 %v5711, 32
  store i64 %op5712, ptr %slot1026, align 8
  %v5713 = load i64, ptr %slot1020, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  %rgep5715 = getelementptr i8, ptr %p5714, i64 -32
  %ld5716 = load i64, ptr %rgep5715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5716, ptr %slot1027, align 8
  %v5717 = load i64, ptr %slot1027, align 8
  %op5718 = sub i64 %v5717, 1
  store i64 %op5718, ptr %slot1028, align 8
  %v5719 = load i64, ptr %slot1028, align 8
  %cmp5720 = icmp eq i64 %v5719, 0
  %cv5721 = zext i1 %cmp5720 to i32
  store i32 %cv5721, ptr %slot1029, align 8
  %v5722 = load i32, ptr %slot1029, align 8
  %cv5723 = zext i32 %v5722 to i64
  %cond5724 = icmp ne i64 %cv5723, 0
  br i1 %cond5724, label %bb_rcglast1281, label %bb_rcgdec1281
bb_rcglast1281:
  %v5725 = load i64, ptr %slot1020, align 8
  %op5726 = sub i64 %v5725, 24
  store i64 %op5726, ptr %slot1030, align 8
  %v5727 = load i64, ptr %slot1020, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  %rgep5729 = getelementptr i8, ptr %p5728, i64 -24
  %ld5730 = load i64, ptr %rgep5729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5730, ptr %slot1031, align 8
  %v5731 = load i64, ptr %slot1031, align 8
  %cmp5732 = icmp ne i64 %v5731, 0
  %cv5733 = zext i1 %cmp5732 to i32
  store i32 %cv5733, ptr %slot1032, align 8
  %v5734 = load i32, ptr %slot1032, align 8
  %cv5735 = zext i32 %v5734 to i64
  %cond5736 = icmp ne i64 %cv5735, 0
  br i1 %cond5736, label %bb_rcgdec1281, label %bb_rcgslow1281
bb_rcgslow1281:
  %v5737 = load i64, ptr %slot1019, align 8
  %v5738 = load i64, ptr %slot1002, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5737, i64 %v5738) nomerge, !dbg !168
  br label %bb_rcgdone1281
bb_rcgdec1281:
  %v5739 = load i64, ptr %slot1028, align 8
  %v5740 = load i64, ptr %slot1020, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  %rgep5742 = getelementptr i8, ptr %p5741, i64 -32
  store i64 %v5739, ptr %rgep5742, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1281
bb_rcgclear1281:
  %v5743 = load i64, ptr %slot1002, align 8
  %p5744 = inttoptr i64 %v5743 to ptr
  store i64 0, ptr %p5744, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1281
bb_rcgdone1281:
  br label %bb_rcslotdone1250
bb_rcslotdone1250:
  %v5745 = load i64, ptr %slot39, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %ld5747 = load i64, ptr %p5746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5747, ptr %slot1033, align 8
  %v5748 = load i64, ptr %slot38, align 8
  %p5749 = inttoptr i64 %v5748 to ptr
  %ld5750 = load i64, ptr %p5749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5750, ptr %slot1034, align 8
  %v5751 = load i64, ptr %slot1034, align 8
  %v5752 = load i64, ptr %slot1033, align 8
  %cmp5753 = icmp sge i64 %v5751, %v5752
  %cv5754 = zext i1 %cmp5753 to i64
  store i64 %cv5754, ptr %slot1035, align 8
  %v5755 = load i64, ptr %slot1035, align 8
  %v5756 = load i64, ptr %slot38, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  store i64 %v5755, ptr %p5757, align 8, !alias.scope !3, !noalias !4
  br label %bb_i101
bb_i101:
  %v5758 = load i64, ptr %slot38, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  %ld5760 = load i64, ptr %p5759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5760, ptr %slot1036, align 8
  %v5761 = load i64, ptr %slot1036, align 8
  %cond5762 = icmp ne i64 %v5761, 0
  br i1 %cond5762, label %bb_next1289, label %bb_i106
bb_next1289:
  %v5763 = load i64, ptr %slot28, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  %ld5765 = load i64, ptr %p5764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5765, ptr %slot1037, align 8
  %v5766 = load i64, ptr %slot1037, align 8
  %v5767 = load i64, ptr %slot38, align 8
  %p5768 = inttoptr i64 %v5767 to ptr
  store i64 %v5766, ptr %p5768, align 8, !alias.scope !3, !noalias !4
  %p5769 = inttoptr i64 ptrtoint (ptr @myl_lit_bae599b006792dd02a4a9c7cf18fd28335c95841bfb7b94284aeba4f8b10c547 to i64) to ptr
  %ld5770 = load i64, ptr %p5769, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5770, ptr %slot1038, align 8
  %v5771 = load i64, ptr %slot1038, align 8
  %v5772 = load i64, ptr %slot39, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  store i64 %v5771, ptr %p5773, align 8, !alias.scope !3, !noalias !4
  %v5774 = load i64, ptr %slot39, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  %ld5776 = load i64, ptr %p5775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5776, ptr %slot1039, align 8
  %v5777 = load i64, ptr %slot1039, align 8
  %v5778 = load i64, ptr %slot26, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  store i64 %v5777, ptr %p5779, align 8, !alias.scope !3, !noalias !4
  %v5780 = load i64, ptr %slot26, align 8
  store i64 %v5780, ptr %slot1040, align 8
  %v5781 = load i64, ptr %slot27, align 8
  store i64 %v5781, ptr %slot1041, align 8
  %v5782 = load i64, ptr %slot1040, align 8
  %v5783 = load i64, ptr %slot1041, align 8
  %p5784 = inttoptr i64 %v5782 to ptr
  %p5785 = inttoptr i64 %v5783 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5785, ptr %p5784, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5786 = load i64, ptr %slot22, align 8
  %p5787 = inttoptr i64 %v5786 to ptr
  store i32 2, ptr %p5787, align 4, !alias.scope !3, !noalias !4
  %v5788 = load i64, ptr %slot21, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  store i32 1, ptr %p5789, align 4, !alias.scope !3, !noalias !4
  %v5790 = load i64, ptr %slot24, align 8
  store i64 %v5790, ptr %slot1042, align 8
  %v5791 = load i64, ptr %slot27, align 8
  store i64 %v5791, ptr %slot1043, align 8
  %v5792 = load i64, ptr %slot1043, align 8
  %v5793 = load i64, ptr %slot1042, align 8
  %p5794 = inttoptr i64 %v5792 to ptr
  %p5795 = inttoptr i64 %v5793 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5795, ptr %p5794, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5796 = load i64, ptr %slot20, align 8
  %p5797 = inttoptr i64 %v5796 to ptr
  store i32 2, ptr %p5797, align 4, !alias.scope !3, !noalias !4
  %v5798 = load i64, ptr %slot22, align 8
  %p5799 = inttoptr i64 %v5798 to ptr
  %ld5800 = load i32, ptr %p5799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5800, ptr %slot1044, align 8
  %v5801 = load i32, ptr %slot1044, align 8
  %v5802 = load i64, ptr %slot20, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  store i32 %v5801, ptr %p5803, align 4, !alias.scope !3, !noalias !4
  %v5804 = load i64, ptr %slot21, align 8
  %p5805 = inttoptr i64 %v5804 to ptr
  store i32 0, ptr %p5805, align 4, !alias.scope !3, !noalias !4
  %v5806 = load i64, ptr %slot19, align 8
  %p5807 = inttoptr i64 %v5806 to ptr
  store i32 1, ptr %p5807, align 4, !alias.scope !3, !noalias !4
  %v5808 = load i64, ptr %slot1042, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  %ld5810 = load i64, ptr %p5809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5810, ptr %slot1045, align 8
  %v5811 = load i64, ptr %slot1045, align 8
  %v5812 = load i64, ptr %slot39, align 8
  %p5813 = inttoptr i64 %v5812 to ptr
  store i64 %v5811, ptr %p5813, align 8, !alias.scope !3, !noalias !4
  %v5814 = load i64, ptr %slot38, align 8
  %p5815 = inttoptr i64 %v5814 to ptr
  %ld5816 = load i64, ptr %p5815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5816, ptr %slot1046, align 8
  %v5817 = load i64, ptr %slot39, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  %ld5819 = load i64, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5819, ptr %slot1047, align 8
  %v5820 = load i64, ptr %slot1, align 8
  %v5821 = load i64, ptr %slot1046, align 8
  %v5822 = load i64, ptr %slot1047, align 8
  call void @myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow(ptr sret([40 x i8]) align 8 %callresult1049, i64 %v5820, i64 %v5821, i64 %v5822) nomerge, !dbg !170
  %addr5823 = ptrtoint ptr %callresult1049 to i64
  store i64 %addr5823, ptr %slot1048, align 8
  %v5824 = load i64, ptr %slot1048, align 8
  %v5825 = load i64, ptr %slot38, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  store i64 %v5824, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  %v5827 = load i64, ptr %slot38, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  %ld5829 = load i64, ptr %p5828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5829, ptr %slot1050, align 8
  %v5830 = load i64, ptr %slot27, align 8
  store i64 %v5830, ptr %slot1051, align 8
  %v5831 = load i64, ptr %slot45, align 8
  %v5832 = load i64, ptr %slot1051, align 8
  %v5833 = load i64, ptr %slot1050, align 8
  %call5834 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v5831, i64 %v5832, i64 %v5833) nomerge, !dbg !170
  store i32 %call5834, ptr %slot1052, align 8
  %v5835 = load i32, ptr %slot1052, align 8
  %cv5836 = zext i32 %v5835 to i64
  %cond5837 = icmp ne i64 %cv5836, 0
  br i1 %cond5837, label %bb_rcsuccess1312, label %bb_rcfailure1312
bb_rcfailure1312:
  %v5838 = load i64, ptr %slot45, align 8
  %p5839 = inttoptr i64 %v5838 to ptr
  %call5840 = call i32 @myl_rc_take_failure(ptr %p5839) nomerge, !dbg !170
  store i32 %call5840, ptr %slot1053, align 8
  %v5841 = load i64, ptr %slot1, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  %v5843 = load i32, ptr %slot1053, align 8
  %call5844 = call i32 @myl_qbe_rc_status(ptr %p5842, i32 %v5843) nomerge, !dbg !170
  store i32 %call5844, ptr %slot1054, align 8
  br label %bb_failure
bb_rcsuccess1312:
  %v5845 = load i64, ptr %slot22, align 8
  %p5846 = inttoptr i64 %v5845 to ptr
  store i32 2, ptr %p5846, align 4, !alias.scope !3, !noalias !4
  %v5847 = load i64, ptr %slot22, align 8
  %p5848 = inttoptr i64 %v5847 to ptr
  store i32 16, ptr %p5848, align 4, !alias.scope !3, !noalias !4
  %v5849 = load i64, ptr %slot21, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  store i32 1, ptr %p5850, align 4, !alias.scope !3, !noalias !4
  %v5851 = load i64, ptr %slot17, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  %ld5853 = load i32, ptr %p5852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5853, ptr %slot1055, align 8
  %v5854 = load i32, ptr %slot1055, align 8
  %cv5855 = zext i32 %v5854 to i64
  %cond5856 = icmp ne i64 %cv5855, 0
  br i1 %cond5856, label %bb_rcslotdrop1320, label %bb_rcslotdone1320
bb_rcslotdrop1320:
  %v5857 = load i64, ptr %slot17, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  store i32 0, ptr %p5858, align 4, !alias.scope !3, !noalias !4
  %v5859 = load i64, ptr %slot23, align 8
  store i64 %v5859, ptr %slot1056, align 8
  %v5860 = load i64, ptr %slot18, align 8
  %p5861 = inttoptr i64 %v5860 to ptr
  %ld5862 = load i32, ptr %p5861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5862, ptr %slot1057, align 8
  %v5863 = load i32, ptr %slot1057, align 8
  %op5864 = and i32 %v5863, 28
  store i32 %op5864, ptr %slot1058, align 8
  %v5865 = load i32, ptr %slot1058, align 8
  %cv5866 = zext i32 %v5865 to i64
  %cond5867 = icmp ne i64 %cv5866, 0
  br i1 %cond5867, label %bb_rcslotrole1320, label %bb_rcslotowner1320
bb_rcslotrole1320:
  %v5868 = load i64, ptr %slot45, align 8
  store i64 %v5868, ptr %slot1059, align 8
  %v5869 = load i64, ptr %slot1059, align 8
  %v5870 = load i64, ptr %slot1056, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5869, i64 %v5870) nomerge, !dbg !170
  br label %bb_rcslotdone1320
bb_rcslotowner1320:
  %v5871 = load i64, ptr %slot45, align 8
  store i64 %v5871, ptr %slot1060, align 8
  %v5872 = load i64, ptr %slot1060, align 8
  %v5873 = load i64, ptr %slot1056, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5872, i64 %v5873) nomerge, !dbg !170
  br label %bb_rcslotdone1320
bb_rcslotdone1320:
  %v5874 = load i64, ptr %slot19, align 8
  %p5875 = inttoptr i64 %v5874 to ptr
  %ld5876 = load i32, ptr %p5875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5876, ptr %slot1061, align 8
  %v5877 = load i32, ptr %slot1061, align 8
  %cv5878 = zext i32 %v5877 to i64
  %cond5879 = icmp ne i64 %cv5878, 0
  br i1 %cond5879, label %bb_rcslotdrop1329, label %bb_rcslotdone1329
bb_rcslotdrop1329:
  %v5880 = load i64, ptr %slot19, align 8
  %p5881 = inttoptr i64 %v5880 to ptr
  store i32 0, ptr %p5881, align 4, !alias.scope !3, !noalias !4
  %v5882 = load i64, ptr %slot24, align 8
  store i64 %v5882, ptr %slot1062, align 8
  %v5883 = load i64, ptr %slot20, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %ld5885 = load i32, ptr %p5884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5885, ptr %slot1063, align 8
  %v5886 = load i32, ptr %slot1063, align 8
  %op5887 = and i32 %v5886, 28
  store i32 %op5887, ptr %slot1064, align 8
  %v5888 = load i32, ptr %slot1064, align 8
  %cv5889 = zext i32 %v5888 to i64
  %cond5890 = icmp ne i64 %cv5889, 0
  br i1 %cond5890, label %bb_rcslotrole1329, label %bb_rcslotowner1329
bb_rcslotrole1329:
  %v5891 = load i64, ptr %slot45, align 8
  store i64 %v5891, ptr %slot1065, align 8
  %v5892 = load i64, ptr %slot1062, align 8
  %p5893 = inttoptr i64 %v5892 to ptr
  %ld5894 = load i64, ptr %p5893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5894, ptr %slot1066, align 8
  %v5895 = load i64, ptr %slot1066, align 8
  %cmp5896 = icmp ne i64 %v5895, 0
  %cv5897 = zext i1 %cmp5896 to i32
  store i32 %cv5897, ptr %slot1067, align 8
  %v5898 = load i32, ptr %slot1067, align 8
  %cv5899 = zext i32 %v5898 to i64
  %cond5900 = icmp ne i64 %cv5899, 0
  br i1 %cond5900, label %bb_rcgnn1345, label %bb_rcgdone1345
bb_rcgnn1345:
  %v5901 = load i64, ptr %slot1066, align 8
  %op5902 = sub i64 %v5901, 16
  store i64 %op5902, ptr %slot1068, align 8
  %v5903 = load i64, ptr %slot1066, align 8
  %p5904 = inttoptr i64 %v5903 to ptr
  %rgep5905 = getelementptr i8, ptr %p5904, i64 -16
  %ld5906 = load i64, ptr %rgep5905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5906, ptr %slot1069, align 8
  %v5907 = load i64, ptr %slot1069, align 8
  %op5908 = and i64 %v5907, 4611686018427387906
  store i64 %op5908, ptr %slot1070, align 8
  %v5909 = load i64, ptr %slot1070, align 8
  %cmp5910 = icmp ne i64 %v5909, 0
  %cv5911 = zext i1 %cmp5910 to i32
  store i32 %cv5911, ptr %slot1071, align 8
  %v5912 = load i32, ptr %slot1071, align 8
  %cv5913 = zext i32 %v5912 to i64
  %cond5914 = icmp ne i64 %cv5913, 0
  br i1 %cond5914, label %bb_rcgclear1345, label %bb_rcgcounted1345
bb_rcgcounted1345:
  %v5915 = load i64, ptr %slot1066, align 8
  %op5916 = sub i64 %v5915, 24
  store i64 %op5916, ptr %slot1072, align 8
  %v5917 = load i64, ptr %slot1066, align 8
  %p5918 = inttoptr i64 %v5917 to ptr
  %rgep5919 = getelementptr i8, ptr %p5918, i64 -24
  %ld5920 = load i64, ptr %rgep5919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5920, ptr %slot1073, align 8
  %v5921 = load i64, ptr %slot1073, align 8
  %op5922 = sub i64 %v5921, 1
  store i64 %op5922, ptr %slot1074, align 8
  %v5923 = load i64, ptr %slot1074, align 8
  %cmp5924 = icmp eq i64 %v5923, 0
  %cv5925 = zext i1 %cmp5924 to i32
  store i32 %cv5925, ptr %slot1075, align 8
  %v5926 = load i32, ptr %slot1075, align 8
  %cv5927 = zext i32 %v5926 to i64
  %cond5928 = icmp ne i64 %cv5927, 0
  br i1 %cond5928, label %bb_rcglast1345, label %bb_rcgdec1345
bb_rcglast1345:
  %v5929 = load i64, ptr %slot1066, align 8
  %op5930 = sub i64 %v5929, 32
  store i64 %op5930, ptr %slot1076, align 8
  %v5931 = load i64, ptr %slot1066, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  %rgep5933 = getelementptr i8, ptr %p5932, i64 -32
  %ld5934 = load i64, ptr %rgep5933, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5934, ptr %slot1077, align 8
  %v5935 = load i64, ptr %slot1077, align 8
  %cmp5936 = icmp ne i64 %v5935, 0
  %cv5937 = zext i1 %cmp5936 to i32
  store i32 %cv5937, ptr %slot1078, align 8
  %v5938 = load i32, ptr %slot1078, align 8
  %cv5939 = zext i32 %v5938 to i64
  %cond5940 = icmp ne i64 %cv5939, 0
  br i1 %cond5940, label %bb_rcgdec1345, label %bb_rcgslow1345
bb_rcgslow1345:
  %v5941 = load i64, ptr %slot1065, align 8
  %v5942 = load i64, ptr %slot1062, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5941, i64 %v5942) nomerge, !dbg !170
  br label %bb_rcgdone1345
bb_rcgdec1345:
  %v5943 = load i64, ptr %slot1074, align 8
  %v5944 = load i64, ptr %slot1066, align 8
  %p5945 = inttoptr i64 %v5944 to ptr
  %rgep5946 = getelementptr i8, ptr %p5945, i64 -24
  store i64 %v5943, ptr %rgep5946, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1345
bb_rcgclear1345:
  %v5947 = load i64, ptr %slot1062, align 8
  %p5948 = inttoptr i64 %v5947 to ptr
  store i64 0, ptr %p5948, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1345
bb_rcgdone1345:
  br label %bb_rcslotdone1329
bb_rcslotowner1329:
  %v5949 = load i64, ptr %slot45, align 8
  store i64 %v5949, ptr %slot1079, align 8
  %v5950 = load i64, ptr %slot1062, align 8
  %p5951 = inttoptr i64 %v5950 to ptr
  %ld5952 = load i64, ptr %p5951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5952, ptr %slot1080, align 8
  %v5953 = load i64, ptr %slot1080, align 8
  %cmp5954 = icmp ne i64 %v5953, 0
  %cv5955 = zext i1 %cmp5954 to i32
  store i32 %cv5955, ptr %slot1081, align 8
  %v5956 = load i32, ptr %slot1081, align 8
  %cv5957 = zext i32 %v5956 to i64
  %cond5958 = icmp ne i64 %cv5957, 0
  br i1 %cond5958, label %bb_rcgnn1360, label %bb_rcgdone1360
bb_rcgnn1360:
  %v5959 = load i64, ptr %slot1080, align 8
  %op5960 = sub i64 %v5959, 16
  store i64 %op5960, ptr %slot1082, align 8
  %v5961 = load i64, ptr %slot1080, align 8
  %p5962 = inttoptr i64 %v5961 to ptr
  %rgep5963 = getelementptr i8, ptr %p5962, i64 -16
  %ld5964 = load i64, ptr %rgep5963, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5964, ptr %slot1083, align 8
  %v5965 = load i64, ptr %slot1083, align 8
  %op5966 = and i64 %v5965, 4611686018427387906
  store i64 %op5966, ptr %slot1084, align 8
  %v5967 = load i64, ptr %slot1084, align 8
  %cmp5968 = icmp ne i64 %v5967, 0
  %cv5969 = zext i1 %cmp5968 to i32
  store i32 %cv5969, ptr %slot1085, align 8
  %v5970 = load i32, ptr %slot1085, align 8
  %cv5971 = zext i32 %v5970 to i64
  %cond5972 = icmp ne i64 %cv5971, 0
  br i1 %cond5972, label %bb_rcgclear1360, label %bb_rcgcounted1360
bb_rcgcounted1360:
  %v5973 = load i64, ptr %slot1080, align 8
  %op5974 = sub i64 %v5973, 32
  store i64 %op5974, ptr %slot1086, align 8
  %v5975 = load i64, ptr %slot1080, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  %rgep5977 = getelementptr i8, ptr %p5976, i64 -32
  %ld5978 = load i64, ptr %rgep5977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5978, ptr %slot1087, align 8
  %v5979 = load i64, ptr %slot1087, align 8
  %op5980 = sub i64 %v5979, 1
  store i64 %op5980, ptr %slot1088, align 8
  %v5981 = load i64, ptr %slot1088, align 8
  %cmp5982 = icmp eq i64 %v5981, 0
  %cv5983 = zext i1 %cmp5982 to i32
  store i32 %cv5983, ptr %slot1089, align 8
  %v5984 = load i32, ptr %slot1089, align 8
  %cv5985 = zext i32 %v5984 to i64
  %cond5986 = icmp ne i64 %cv5985, 0
  br i1 %cond5986, label %bb_rcglast1360, label %bb_rcgdec1360
bb_rcglast1360:
  %v5987 = load i64, ptr %slot1080, align 8
  %op5988 = sub i64 %v5987, 24
  store i64 %op5988, ptr %slot1090, align 8
  %v5989 = load i64, ptr %slot1080, align 8
  %p5990 = inttoptr i64 %v5989 to ptr
  %rgep5991 = getelementptr i8, ptr %p5990, i64 -24
  %ld5992 = load i64, ptr %rgep5991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5992, ptr %slot1091, align 8
  %v5993 = load i64, ptr %slot1091, align 8
  %cmp5994 = icmp ne i64 %v5993, 0
  %cv5995 = zext i1 %cmp5994 to i32
  store i32 %cv5995, ptr %slot1092, align 8
  %v5996 = load i32, ptr %slot1092, align 8
  %cv5997 = zext i32 %v5996 to i64
  %cond5998 = icmp ne i64 %cv5997, 0
  br i1 %cond5998, label %bb_rcgdec1360, label %bb_rcgslow1360
bb_rcgslow1360:
  %v5999 = load i64, ptr %slot1079, align 8
  %v6000 = load i64, ptr %slot1062, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5999, i64 %v6000) nomerge, !dbg !170
  br label %bb_rcgdone1360
bb_rcgdec1360:
  %v6001 = load i64, ptr %slot1088, align 8
  %v6002 = load i64, ptr %slot1080, align 8
  %p6003 = inttoptr i64 %v6002 to ptr
  %rgep6004 = getelementptr i8, ptr %p6003, i64 -32
  store i64 %v6001, ptr %rgep6004, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1360
bb_rcgclear1360:
  %v6005 = load i64, ptr %slot1062, align 8
  %p6006 = inttoptr i64 %v6005 to ptr
  store i64 0, ptr %p6006, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1360
bb_rcgdone1360:
  br label %bb_rcslotdone1329
bb_rcslotdone1329:
  %v6007 = load i64, ptr %slot23, align 8
  store i64 %v6007, ptr %slot1093, align 8
  %v6008 = load i64, ptr %slot27, align 8
  store i64 %v6008, ptr %slot1094, align 8
  %v6009 = load i64, ptr %slot1094, align 8
  %v6010 = load i64, ptr %slot1093, align 8
  %p6011 = inttoptr i64 %v6009 to ptr
  %p6012 = inttoptr i64 %v6010 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6012, ptr %p6011, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v6013 = load i64, ptr %slot18, align 8
  %p6014 = inttoptr i64 %v6013 to ptr
  store i32 2, ptr %p6014, align 4, !alias.scope !3, !noalias !4
  %v6015 = load i64, ptr %slot22, align 8
  %p6016 = inttoptr i64 %v6015 to ptr
  %ld6017 = load i32, ptr %p6016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6017, ptr %slot1095, align 8
  %v6018 = load i32, ptr %slot1095, align 8
  %v6019 = load i64, ptr %slot18, align 8
  %p6020 = inttoptr i64 %v6019 to ptr
  store i32 %v6018, ptr %p6020, align 4, !alias.scope !3, !noalias !4
  %v6021 = load i64, ptr %slot21, align 8
  %p6022 = inttoptr i64 %v6021 to ptr
  store i32 0, ptr %p6022, align 4, !alias.scope !3, !noalias !4
  %v6023 = load i64, ptr %slot17, align 8
  %p6024 = inttoptr i64 %v6023 to ptr
  store i32 1, ptr %p6024, align 4, !alias.scope !3, !noalias !4
  %v6025 = load i64, ptr %slot1093, align 8
  %v6026 = load i64, ptr %slot38, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  store i64 %v6025, ptr %p6027, align 8, !alias.scope !3, !noalias !4
  %v6028 = load i64, ptr %slot38, align 8
  %p6029 = inttoptr i64 %v6028 to ptr
  %ld6030 = load i64, ptr %p6029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6030, ptr %slot1096, align 8
  %v6031 = load i64, ptr %slot38, align 8
  %p6032 = inttoptr i64 %v6031 to ptr
  %ld6033 = load i64, ptr %p6032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6033, ptr %slot1097, align 8
  %v6034 = load i64, ptr %slot17, align 8
  %p6035 = inttoptr i64 %v6034 to ptr
  %ld6036 = load i32, ptr %p6035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6036, ptr %slot1098, align 8
  %v6037 = load i64, ptr %slot18, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  %ld6039 = load i32, ptr %p6038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6039, ptr %slot1099, align 8
  %v6040 = load i32, ptr %slot1099, align 8
  %op6041 = and i32 %v6040, 24
  store i32 %op6041, ptr %slot1099, align 8
  %v6042 = load i32, ptr %slot1099, align 8
  %cmp6043 = icmp eq i32 %v6042, 0
  %cv6044 = zext i1 %cmp6043 to i32
  store i32 %cv6044, ptr %slot1100, align 8
  %v6045 = load i32, ptr %slot1098, align 8
  %v6046 = load i32, ptr %slot1100, align 8
  %op6047 = and i32 %v6045, %v6046
  store i32 %op6047, ptr %slot1101, align 8
  %v6048 = load i32, ptr %slot1101, align 8
  %cv6049 = zext i32 %v6048 to i64
  %cond6050 = icmp ne i64 %cv6049, 0
  br i1 %cond6050, label %bb_rctake1374, label %bb_rccopy1374
bb_rctake1374:
  %v6051 = load i64, ptr %slot27, align 8
  store i64 %v6051, ptr %slot1102, align 8
  %v6052 = load i64, ptr %slot46, align 8
  store i64 %v6052, ptr %slot1103, align 8
  %v6053 = load i64, ptr %slot45, align 8
  %v6054 = load i64, ptr %slot1102, align 8
  %v6055 = load i64, ptr %slot1097, align 8
  %v6056 = load i64, ptr %slot1103, align 8
  %cv6057 = trunc i64 %v6056 to i32
  %call6058 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v6053, i64 %v6054, i64 %v6055, i32 %cv6057) nomerge, !dbg !172
  store i32 %call6058, ptr %slot1104, align 8
  %v6059 = load i32, ptr %slot1104, align 8
  %cv6060 = zext i32 %v6059 to i64
  %cond6061 = icmp ne i64 %cv6060, 0
  br i1 %cond6061, label %bb_rcsuccess1384, label %bb_rcfailure1384
bb_rcfailure1384:
  %v6062 = load i64, ptr %slot45, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  %call6064 = call i32 @myl_rc_take_failure(ptr %p6063) nomerge, !dbg !172
  store i32 %call6064, ptr %slot1105, align 8
  %v6065 = load i64, ptr %slot1, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  %v6067 = load i32, ptr %slot1105, align 8
  %call6068 = call i32 @myl_qbe_rc_status(ptr %p6066, i32 %v6067) nomerge, !dbg !172
  store i32 %call6068, ptr %slot1106, align 8
  br label %bb_failure
bb_rcsuccess1384:
  %v6069 = load i64, ptr %slot17, align 8
  %p6070 = inttoptr i64 %v6069 to ptr
  store i32 0, ptr %p6070, align 4, !alias.scope !3, !noalias !4
  %v6071 = load i64, ptr %slot22, align 8
  %p6072 = inttoptr i64 %v6071 to ptr
  store i32 2, ptr %p6072, align 4, !alias.scope !3, !noalias !4
  %v6073 = load i64, ptr %slot21, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  store i32 1, ptr %p6074, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1374
bb_rccopy1374:
  %v6075 = load i64, ptr %slot27, align 8
  store i64 %v6075, ptr %slot1107, align 8
  %v6076 = load i64, ptr %slot46, align 8
  store i64 %v6076, ptr %slot1108, align 8
  %v6077 = load i64, ptr %slot45, align 8
  %v6078 = load i64, ptr %slot1107, align 8
  %v6079 = load i64, ptr %slot1097, align 8
  %v6080 = load i64, ptr %slot1108, align 8
  %cv6081 = trunc i64 %v6080 to i32
  %call6082 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v6077, i64 %v6078, i64 %v6079, i32 %cv6081) nomerge, !dbg !172
  store i32 %call6082, ptr %slot1109, align 8
  %v6083 = load i32, ptr %slot1109, align 8
  %cv6084 = zext i32 %v6083 to i64
  %cond6085 = icmp ne i64 %cv6084, 0
  br i1 %cond6085, label %bb_rcsuccess1393, label %bb_rcfailure1393
bb_rcfailure1393:
  %v6086 = load i64, ptr %slot45, align 8
  %p6087 = inttoptr i64 %v6086 to ptr
  %call6088 = call i32 @myl_rc_take_failure(ptr %p6087) nomerge, !dbg !172
  store i32 %call6088, ptr %slot1110, align 8
  %v6089 = load i64, ptr %slot1, align 8
  %p6090 = inttoptr i64 %v6089 to ptr
  %v6091 = load i32, ptr %slot1110, align 8
  %call6092 = call i32 @myl_qbe_rc_status(ptr %p6090, i32 %v6091) nomerge, !dbg !172
  store i32 %call6092, ptr %slot1111, align 8
  br label %bb_failure
bb_rcsuccess1393:
  %v6093 = load i64, ptr %slot22, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  store i32 2, ptr %p6094, align 4, !alias.scope !3, !noalias !4
  %v6095 = load i64, ptr %slot21, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  store i32 1, ptr %p6096, align 4, !alias.scope !3, !noalias !4
  %v6097 = load i64, ptr %slot17, align 8
  %p6098 = inttoptr i64 %v6097 to ptr
  %ld6099 = load i32, ptr %p6098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6099, ptr %slot1112, align 8
  %v6100 = load i32, ptr %slot1112, align 8
  %cv6101 = zext i32 %v6100 to i64
  %cond6102 = icmp ne i64 %cv6101, 0
  br i1 %cond6102, label %bb_rcslotdrop1400, label %bb_rcslotdone1400
bb_rcslotdrop1400:
  %v6103 = load i64, ptr %slot17, align 8
  %p6104 = inttoptr i64 %v6103 to ptr
  store i32 0, ptr %p6104, align 4, !alias.scope !3, !noalias !4
  %v6105 = load i64, ptr %slot23, align 8
  store i64 %v6105, ptr %slot1113, align 8
  %v6106 = load i64, ptr %slot18, align 8
  %p6107 = inttoptr i64 %v6106 to ptr
  %ld6108 = load i32, ptr %p6107, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6108, ptr %slot1114, align 8
  %v6109 = load i32, ptr %slot1114, align 8
  %op6110 = and i32 %v6109, 28
  store i32 %op6110, ptr %slot1115, align 8
  %v6111 = load i32, ptr %slot1115, align 8
  %cv6112 = zext i32 %v6111 to i64
  %cond6113 = icmp ne i64 %cv6112, 0
  br i1 %cond6113, label %bb_rcslotrole1400, label %bb_rcslotowner1400
bb_rcslotrole1400:
  %v6114 = load i64, ptr %slot45, align 8
  store i64 %v6114, ptr %slot1116, align 8
  %v6115 = load i64, ptr %slot1116, align 8
  %v6116 = load i64, ptr %slot1113, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6115, i64 %v6116) nomerge, !dbg !172
  br label %bb_rcslotdone1400
bb_rcslotowner1400:
  %v6117 = load i64, ptr %slot45, align 8
  store i64 %v6117, ptr %slot1117, align 8
  %v6118 = load i64, ptr %slot1117, align 8
  %v6119 = load i64, ptr %slot1113, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6118, i64 %v6119) nomerge, !dbg !172
  br label %bb_rcslotdone1400
bb_rcslotdone1400:
  br label %bb_rcprepared1374
bb_rcprepared1374:
  %v6120 = load i64, ptr %slot27, align 8
  store i64 %v6120, ptr %slot1118, align 8
  %v6121 = load i64, ptr %slot21, align 8
  %p6122 = inttoptr i64 %v6121 to ptr
  store i32 0, ptr %p6122, align 4, !alias.scope !3, !noalias !4
  %v6123 = load i64, ptr %slot17, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  %ld6125 = load i32, ptr %p6124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6125, ptr %slot1119, align 8
  %v6126 = load i32, ptr %slot1119, align 8
  %cv6127 = zext i32 %v6126 to i64
  %cond6128 = icmp ne i64 %cv6127, 0
  br i1 %cond6128, label %bb_rcslotdrop1411, label %bb_rcslotdone1411
bb_rcslotdrop1411:
  %v6129 = load i64, ptr %slot17, align 8
  %p6130 = inttoptr i64 %v6129 to ptr
  store i32 0, ptr %p6130, align 4, !alias.scope !3, !noalias !4
  %v6131 = load i64, ptr %slot23, align 8
  store i64 %v6131, ptr %slot1120, align 8
  %v6132 = load i64, ptr %slot18, align 8
  %p6133 = inttoptr i64 %v6132 to ptr
  %ld6134 = load i32, ptr %p6133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6134, ptr %slot1121, align 8
  %v6135 = load i32, ptr %slot1121, align 8
  %op6136 = and i32 %v6135, 28
  store i32 %op6136, ptr %slot1122, align 8
  %v6137 = load i32, ptr %slot1122, align 8
  %cv6138 = zext i32 %v6137 to i64
  %cond6139 = icmp ne i64 %cv6138, 0
  br i1 %cond6139, label %bb_rcslotrole1411, label %bb_rcslotowner1411
bb_rcslotrole1411:
  %v6140 = load i64, ptr %slot45, align 8
  store i64 %v6140, ptr %slot1123, align 8
  %v6141 = load i64, ptr %slot1123, align 8
  %v6142 = load i64, ptr %slot1120, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6141, i64 %v6142) nomerge, !dbg !172
  br label %bb_rcslotdone1411
bb_rcslotowner1411:
  %v6143 = load i64, ptr %slot45, align 8
  store i64 %v6143, ptr %slot1124, align 8
  %v6144 = load i64, ptr %slot1124, align 8
  %v6145 = load i64, ptr %slot1120, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6144, i64 %v6145) nomerge, !dbg !172
  br label %bb_rcslotdone1411
bb_rcslotdone1411:
  %v6146 = load i64, ptr %slot15, align 8
  %p6147 = inttoptr i64 %v6146 to ptr
  %ld6148 = load i32, ptr %p6147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6148, ptr %slot1125, align 8
  %v6149 = load i32, ptr %slot1125, align 8
  %cv6150 = zext i32 %v6149 to i64
  %cond6151 = icmp ne i64 %cv6150, 0
  br i1 %cond6151, label %bb_rcslotdrop1420, label %bb_rcslotdone1420
bb_rcslotdrop1420:
  %v6152 = load i64, ptr %slot15, align 8
  %p6153 = inttoptr i64 %v6152 to ptr
  store i32 0, ptr %p6153, align 4, !alias.scope !3, !noalias !4
  %v6154 = load i64, ptr %slot37, align 8
  store i64 %v6154, ptr %slot1126, align 8
  %v6155 = load i64, ptr %slot16, align 8
  %p6156 = inttoptr i64 %v6155 to ptr
  %ld6157 = load i32, ptr %p6156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6157, ptr %slot1127, align 8
  %v6158 = load i32, ptr %slot1127, align 8
  %op6159 = and i32 %v6158, 28
  store i32 %op6159, ptr %slot1128, align 8
  %v6160 = load i32, ptr %slot1128, align 8
  %cv6161 = zext i32 %v6160 to i64
  %cond6162 = icmp ne i64 %cv6161, 0
  br i1 %cond6162, label %bb_rcslotrole1420, label %bb_rcslotowner1420
bb_rcslotrole1420:
  %v6163 = load i64, ptr %slot45, align 8
  store i64 %v6163, ptr %slot1129, align 8
  %v6164 = load i64, ptr %slot1129, align 8
  %v6165 = load i64, ptr %slot1126, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6164, i64 %v6165) nomerge, !dbg !172
  br label %bb_rcslotdone1420
bb_rcslotowner1420:
  %v6166 = load i64, ptr %slot45, align 8
  store i64 %v6166, ptr %slot1130, align 8
  %v6167 = load i64, ptr %slot1130, align 8
  %v6168 = load i64, ptr %slot1126, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6167, i64 %v6168) nomerge, !dbg !172
  br label %bb_rcslotdone1420
bb_rcslotdone1420:
  %v6169 = load i64, ptr %slot13, align 8
  %p6170 = inttoptr i64 %v6169 to ptr
  %ld6171 = load i32, ptr %p6170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6171, ptr %slot1131, align 8
  %v6172 = load i32, ptr %slot1131, align 8
  %cv6173 = zext i32 %v6172 to i64
  %cond6174 = icmp ne i64 %cv6173, 0
  br i1 %cond6174, label %bb_rcslotdrop1429, label %bb_rcslotdone1429
bb_rcslotdrop1429:
  %v6175 = load i64, ptr %slot13, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  store i32 0, ptr %p6176, align 4, !alias.scope !3, !noalias !4
  %v6177 = load i64, ptr %slot36, align 8
  store i64 %v6177, ptr %slot1132, align 8
  %v6178 = load i64, ptr %slot14, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i32, ptr %p6179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6180, ptr %slot1133, align 8
  %v6181 = load i32, ptr %slot1133, align 8
  %op6182 = and i32 %v6181, 28
  store i32 %op6182, ptr %slot1134, align 8
  %v6183 = load i32, ptr %slot1134, align 8
  %cv6184 = zext i32 %v6183 to i64
  %cond6185 = icmp ne i64 %cv6184, 0
  br i1 %cond6185, label %bb_rcslotrole1429, label %bb_rcslotowner1429
bb_rcslotrole1429:
  %v6186 = load i64, ptr %slot45, align 8
  store i64 %v6186, ptr %slot1135, align 8
  %v6187 = load i64, ptr %slot1135, align 8
  %v6188 = load i64, ptr %slot1132, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6187, i64 %v6188) nomerge, !dbg !172
  br label %bb_rcslotdone1429
bb_rcslotowner1429:
  %v6189 = load i64, ptr %slot45, align 8
  store i64 %v6189, ptr %slot1136, align 8
  %v6190 = load i64, ptr %slot1136, align 8
  %v6191 = load i64, ptr %slot1132, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6190, i64 %v6191) nomerge, !dbg !172
  br label %bb_rcslotdone1429
bb_rcslotdone1429:
  %v6192 = load i64, ptr %slot11, align 8
  %p6193 = inttoptr i64 %v6192 to ptr
  %ld6194 = load i32, ptr %p6193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6194, ptr %slot1137, align 8
  %v6195 = load i32, ptr %slot1137, align 8
  %cv6196 = zext i32 %v6195 to i64
  %cond6197 = icmp ne i64 %cv6196, 0
  br i1 %cond6197, label %bb_rcslotdrop1438, label %bb_rcslotdone1438
bb_rcslotdrop1438:
  %v6198 = load i64, ptr %slot11, align 8
  %p6199 = inttoptr i64 %v6198 to ptr
  store i32 0, ptr %p6199, align 4, !alias.scope !3, !noalias !4
  %v6200 = load i64, ptr %slot35, align 8
  store i64 %v6200, ptr %slot1138, align 8
  %v6201 = load i64, ptr %slot12, align 8
  %p6202 = inttoptr i64 %v6201 to ptr
  %ld6203 = load i32, ptr %p6202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6203, ptr %slot1139, align 8
  %v6204 = load i32, ptr %slot1139, align 8
  %op6205 = and i32 %v6204, 28
  store i32 %op6205, ptr %slot1140, align 8
  %v6206 = load i32, ptr %slot1140, align 8
  %cv6207 = zext i32 %v6206 to i64
  %cond6208 = icmp ne i64 %cv6207, 0
  br i1 %cond6208, label %bb_rcslotrole1438, label %bb_rcslotowner1438
bb_rcslotrole1438:
  %v6209 = load i64, ptr %slot45, align 8
  store i64 %v6209, ptr %slot1141, align 8
  %v6210 = load i64, ptr %slot1141, align 8
  %v6211 = load i64, ptr %slot1138, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6210, i64 %v6211) nomerge, !dbg !172
  br label %bb_rcslotdone1438
bb_rcslotowner1438:
  %v6212 = load i64, ptr %slot45, align 8
  store i64 %v6212, ptr %slot1142, align 8
  %v6213 = load i64, ptr %slot1142, align 8
  %v6214 = load i64, ptr %slot1138, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6213, i64 %v6214) nomerge, !dbg !172
  br label %bb_rcslotdone1438
bb_rcslotdone1438:
  %v6215 = load i64, ptr %slot9, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  %ld6217 = load i32, ptr %p6216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6217, ptr %slot1143, align 8
  %v6218 = load i32, ptr %slot1143, align 8
  %cv6219 = zext i32 %v6218 to i64
  %cond6220 = icmp ne i64 %cv6219, 0
  br i1 %cond6220, label %bb_rcslotdrop1447, label %bb_rcslotdone1447
bb_rcslotdrop1447:
  %v6221 = load i64, ptr %slot9, align 8
  %p6222 = inttoptr i64 %v6221 to ptr
  store i32 0, ptr %p6222, align 4, !alias.scope !3, !noalias !4
  %v6223 = load i64, ptr %slot34, align 8
  store i64 %v6223, ptr %slot1144, align 8
  %v6224 = load i64, ptr %slot10, align 8
  %p6225 = inttoptr i64 %v6224 to ptr
  %ld6226 = load i32, ptr %p6225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6226, ptr %slot1145, align 8
  %v6227 = load i32, ptr %slot1145, align 8
  %op6228 = and i32 %v6227, 28
  store i32 %op6228, ptr %slot1146, align 8
  %v6229 = load i32, ptr %slot1146, align 8
  %cv6230 = zext i32 %v6229 to i64
  %cond6231 = icmp ne i64 %cv6230, 0
  br i1 %cond6231, label %bb_rcslotrole1447, label %bb_rcslotowner1447
bb_rcslotrole1447:
  %v6232 = load i64, ptr %slot45, align 8
  store i64 %v6232, ptr %slot1147, align 8
  %v6233 = load i64, ptr %slot1147, align 8
  %v6234 = load i64, ptr %slot1144, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6233, i64 %v6234) nomerge, !dbg !172
  br label %bb_rcslotdone1447
bb_rcslotowner1447:
  %v6235 = load i64, ptr %slot45, align 8
  store i64 %v6235, ptr %slot1148, align 8
  %v6236 = load i64, ptr %slot1148, align 8
  %v6237 = load i64, ptr %slot1144, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6236, i64 %v6237) nomerge, !dbg !172
  br label %bb_rcslotdone1447
bb_rcslotdone1447:
  %v6238 = load i64, ptr %slot7, align 8
  %p6239 = inttoptr i64 %v6238 to ptr
  %ld6240 = load i32, ptr %p6239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6240, ptr %slot1149, align 8
  %v6241 = load i32, ptr %slot1149, align 8
  %cv6242 = zext i32 %v6241 to i64
  %cond6243 = icmp ne i64 %cv6242, 0
  br i1 %cond6243, label %bb_rcslotdrop1456, label %bb_rcslotdone1456
bb_rcslotdrop1456:
  %v6244 = load i64, ptr %slot7, align 8
  %p6245 = inttoptr i64 %v6244 to ptr
  store i32 0, ptr %p6245, align 4, !alias.scope !3, !noalias !4
  %v6246 = load i64, ptr %slot33, align 8
  store i64 %v6246, ptr %slot1150, align 8
  %v6247 = load i64, ptr %slot8, align 8
  %p6248 = inttoptr i64 %v6247 to ptr
  %ld6249 = load i32, ptr %p6248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6249, ptr %slot1151, align 8
  %v6250 = load i32, ptr %slot1151, align 8
  %op6251 = and i32 %v6250, 28
  store i32 %op6251, ptr %slot1152, align 8
  %v6252 = load i32, ptr %slot1152, align 8
  %cv6253 = zext i32 %v6252 to i64
  %cond6254 = icmp ne i64 %cv6253, 0
  br i1 %cond6254, label %bb_rcslotrole1456, label %bb_rcslotowner1456
bb_rcslotrole1456:
  %v6255 = load i64, ptr %slot45, align 8
  store i64 %v6255, ptr %slot1153, align 8
  %v6256 = load i64, ptr %slot1153, align 8
  %v6257 = load i64, ptr %slot1150, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6256, i64 %v6257) nomerge, !dbg !172
  br label %bb_rcslotdone1456
bb_rcslotowner1456:
  %v6258 = load i64, ptr %slot45, align 8
  store i64 %v6258, ptr %slot1154, align 8
  %v6259 = load i64, ptr %slot1154, align 8
  %v6260 = load i64, ptr %slot1150, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6259, i64 %v6260) nomerge, !dbg !172
  br label %bb_rcslotdone1456
bb_rcslotdone1456:
  %v6261 = load i64, ptr %slot5, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  %ld6263 = load i32, ptr %p6262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6263, ptr %slot1155, align 8
  %v6264 = load i32, ptr %slot1155, align 8
  %cv6265 = zext i32 %v6264 to i64
  %cond6266 = icmp ne i64 %cv6265, 0
  br i1 %cond6266, label %bb_rcslotdrop1465, label %bb_rcslotdone1465
bb_rcslotdrop1465:
  %v6267 = load i64, ptr %slot5, align 8
  %p6268 = inttoptr i64 %v6267 to ptr
  store i32 0, ptr %p6268, align 4, !alias.scope !3, !noalias !4
  %v6269 = load i64, ptr %slot32, align 8
  store i64 %v6269, ptr %slot1156, align 8
  %v6270 = load i64, ptr %slot6, align 8
  %p6271 = inttoptr i64 %v6270 to ptr
  %ld6272 = load i32, ptr %p6271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6272, ptr %slot1157, align 8
  %v6273 = load i32, ptr %slot1157, align 8
  %op6274 = and i32 %v6273, 28
  store i32 %op6274, ptr %slot1158, align 8
  %v6275 = load i32, ptr %slot1158, align 8
  %cv6276 = zext i32 %v6275 to i64
  %cond6277 = icmp ne i64 %cv6276, 0
  br i1 %cond6277, label %bb_rcslotrole1465, label %bb_rcslotowner1465
bb_rcslotrole1465:
  %v6278 = load i64, ptr %slot45, align 8
  store i64 %v6278, ptr %slot1159, align 8
  %v6279 = load i64, ptr %slot1159, align 8
  %v6280 = load i64, ptr %slot1156, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6279, i64 %v6280) nomerge, !dbg !172
  br label %bb_rcslotdone1465
bb_rcslotowner1465:
  %v6281 = load i64, ptr %slot45, align 8
  store i64 %v6281, ptr %slot1160, align 8
  %v6282 = load i64, ptr %slot1160, align 8
  %v6283 = load i64, ptr %slot1156, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6282, i64 %v6283) nomerge, !dbg !172
  br label %bb_rcslotdone1465
bb_rcslotdone1465:
  %v6284 = load i64, ptr %slot1118, align 8
  %p6285 = inttoptr i64 %v6284 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6285, i64 40, i1 false)
  ret void
bb_i106:
  %v6286 = load i64, ptr %slot28, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  %ld6288 = load i64, ptr %p6287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6288, ptr %slot1161, align 8
  %v6289 = load i64, ptr %slot1161, align 8
  %v6290 = load i64, ptr %slot38, align 8
  %p6291 = inttoptr i64 %v6290 to ptr
  store i64 %v6289, ptr %p6291, align 8, !alias.scope !3, !noalias !4
  %v6292 = load i64, ptr %slot38, align 8
  %p6293 = inttoptr i64 %v6292 to ptr
  %ld6294 = load i64, ptr %p6293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6294, ptr %slot1162, align 8
  %v6295 = load i64, ptr %slot1162, align 8
  %op6296 = add i64 %v6295, 16
  store i64 %op6296, ptr %slot1163, align 8
  %v6297 = load i64, ptr %slot1163, align 8
  %p6298 = inttoptr i64 %v6297 to ptr
  %ld6299 = load i64, ptr %p6298, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6299, ptr %slot1164, align 8
  %v6300 = load i64, ptr %slot1164, align 8
  %v6301 = load i64, ptr %slot38, align 8
  %p6302 = inttoptr i64 %v6301 to ptr
  store i64 %v6300, ptr %p6302, align 8, !alias.scope !3, !noalias !4
  %v6303 = load i64, ptr %slot17, align 8
  %p6304 = inttoptr i64 %v6303 to ptr
  %ld6305 = load i32, ptr %p6304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6305, ptr %slot1165, align 8
  %v6306 = load i32, ptr %slot1165, align 8
  %cv6307 = zext i32 %v6306 to i64
  %cond6308 = icmp ne i64 %cv6307, 0
  br i1 %cond6308, label %bb_rcslotdrop1514, label %bb_rcslotdone1514
bb_rcslotdrop1514:
  %v6309 = load i64, ptr %slot17, align 8
  %p6310 = inttoptr i64 %v6309 to ptr
  store i32 0, ptr %p6310, align 4, !alias.scope !3, !noalias !4
  %v6311 = load i64, ptr %slot23, align 8
  store i64 %v6311, ptr %slot1166, align 8
  %v6312 = load i64, ptr %slot18, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  %ld6314 = load i32, ptr %p6313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6314, ptr %slot1167, align 8
  %v6315 = load i32, ptr %slot1167, align 8
  %op6316 = and i32 %v6315, 28
  store i32 %op6316, ptr %slot1168, align 8
  %v6317 = load i32, ptr %slot1168, align 8
  %cv6318 = zext i32 %v6317 to i64
  %cond6319 = icmp ne i64 %cv6318, 0
  br i1 %cond6319, label %bb_rcslotrole1514, label %bb_rcslotowner1514
bb_rcslotrole1514:
  %v6320 = load i64, ptr %slot45, align 8
  store i64 %v6320, ptr %slot1169, align 8
  %v6321 = load i64, ptr %slot1169, align 8
  %v6322 = load i64, ptr %slot1166, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6321, i64 %v6322) nomerge, !dbg !174
  br label %bb_rcslotdone1514
bb_rcslotowner1514:
  %v6323 = load i64, ptr %slot45, align 8
  store i64 %v6323, ptr %slot1170, align 8
  %v6324 = load i64, ptr %slot1170, align 8
  %v6325 = load i64, ptr %slot1166, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6324, i64 %v6325) nomerge, !dbg !174
  br label %bb_rcslotdone1514
bb_rcslotdone1514:
  %v6326 = load i64, ptr %slot39, align 8
  %p6327 = inttoptr i64 %v6326 to ptr
  store i64 1, ptr %p6327, align 8, !alias.scope !3, !noalias !4
  %v6328 = load i64, ptr %slot39, align 8
  %p6329 = inttoptr i64 %v6328 to ptr
  %ld6330 = load i64, ptr %p6329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6330, ptr %slot1171, align 8
  %v6331 = load i64, ptr %slot38, align 8
  %p6332 = inttoptr i64 %v6331 to ptr
  %ld6333 = load i64, ptr %p6332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6333, ptr %slot1172, align 8
  %v6334 = load i64, ptr %slot1172, align 8
  %v6335 = load i64, ptr %slot1171, align 8
  %ovpair6337 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6334, i64 %v6335)
  %op6336 = extractvalue { i64, i1 } %ovpair6337, 0
  %ov6338 = extractvalue { i64, i1 } %ovpair6337, 1
  store i64 %op6336, ptr %slot1173, align 8
  %cv6339 = zext i1 %ov6338 to i64
  store i64 %cv6339, ptr %slot1174, align 8
  %v6340 = load i64, ptr %slot1174, align 8
  %cond6341 = icmp ne i64 %v6340, 0
  br i1 %cond6341, label %bb_overflow1523, label %bb_checked1523
bb_overflow1523:
  %v6342 = load i64, ptr %slot1, align 8
  %p6343 = inttoptr i64 %v6342 to ptr
  %v6344 = load i64, ptr %slot1172, align 8
  %v6345 = load i64, ptr %slot1171, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p6343, i64 0, i64 %v6344, i64 %v6345, i64 64) nomerge, !dbg !176
  unreachable
bb_checked1523:
  %v6346 = load i64, ptr %slot1173, align 8
  %v6347 = load i64, ptr %slot38, align 8
  %p6348 = inttoptr i64 %v6347 to ptr
  store i64 %v6346, ptr %p6348, align 8, !alias.scope !3, !noalias !4
  %v6349 = load i64, ptr %slot38, align 8
  %p6350 = inttoptr i64 %v6349 to ptr
  %ld6351 = load i64, ptr %p6350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6351, ptr %slot1175, align 8
  %v6352 = load i64, ptr %slot1175, align 8
  %v6353 = load i64, ptr %slot31, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  store i64 %v6352, ptr %p6354, align 8, !alias.scope !3, !noalias !4
  %v6355 = load i64, ptr %slot28, align 8
  %p6356 = inttoptr i64 %v6355 to ptr
  %ld6357 = load i64, ptr %p6356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6357, ptr %slot1176, align 8
  %v6358 = load i64, ptr %slot1176, align 8
  %v6359 = load i64, ptr %slot38, align 8
  %p6360 = inttoptr i64 %v6359 to ptr
  store i64 %v6358, ptr %p6360, align 8, !alias.scope !3, !noalias !4
  %v6361 = load i64, ptr %slot28, align 8
  %p6362 = inttoptr i64 %v6361 to ptr
  %ld6363 = load i64, ptr %p6362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6363, ptr %slot1177, align 8
  %v6364 = load i64, ptr %slot1177, align 8
  %v6365 = load i64, ptr %slot38, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  store i64 %v6364, ptr %p6366, align 8, !alias.scope !3, !noalias !4
  %v6367 = load i64, ptr %slot28, align 8
  %p6368 = inttoptr i64 %v6367 to ptr
  %ld6369 = load i64, ptr %p6368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6369, ptr %slot1178, align 8
  %v6370 = load i64, ptr %slot1178, align 8
  %v6371 = load i64, ptr %slot38, align 8
  %p6372 = inttoptr i64 %v6371 to ptr
  store i64 %v6370, ptr %p6372, align 8, !alias.scope !3, !noalias !4
  %v6373 = load i64, ptr %slot31, align 8
  %p6374 = inttoptr i64 %v6373 to ptr
  %ld6375 = load i64, ptr %p6374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6375, ptr %slot1179, align 8
  %v6376 = load i64, ptr %slot1179, align 8
  %v6377 = load i64, ptr %slot39, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  store i64 %v6376, ptr %p6378, align 8, !alias.scope !3, !noalias !4
  %v6379 = load i64, ptr %slot28, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  %ld6381 = load i64, ptr %p6380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6381, ptr %slot1180, align 8
  %v6382 = load i64, ptr %slot1180, align 8
  %v6383 = load i64, ptr %slot38, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  store i64 %v6382, ptr %p6384, align 8, !alias.scope !3, !noalias !4
  %v6385 = load i64, ptr %slot31, align 8
  %p6386 = inttoptr i64 %v6385 to ptr
  %ld6387 = load i64, ptr %p6386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6387, ptr %slot1181, align 8
  %v6388 = load i64, ptr %slot28, align 8
  %p6389 = inttoptr i64 %v6388 to ptr
  %ld6390 = load i64, ptr %p6389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6390, ptr %slot1182, align 8
  %v6391 = load i64, ptr %slot1182, align 8
  %op6392 = add i64 %v6391, 16
  store i64 %op6392, ptr %slot1183, align 8
  %v6393 = load i64, ptr %slot1181, align 8
  %v6394 = load i64, ptr %slot1183, align 8
  %p6395 = inttoptr i64 %v6394 to ptr
  store i64 %v6393, ptr %p6395, align 8, !alias.scope !4, !noalias !3
  %v6396 = load i64, ptr %slot38, align 8
  %p6397 = inttoptr i64 %v6396 to ptr
  store i64 0, ptr %p6397, align 8, !alias.scope !3, !noalias !4
  %v6398 = load i64, ptr %slot28, align 8
  %p6399 = inttoptr i64 %v6398 to ptr
  %ld6400 = load i64, ptr %p6399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6400, ptr %slot1184, align 8
  %v6401 = load i64, ptr %slot1184, align 8
  %v6402 = load i64, ptr %slot38, align 8
  %p6403 = inttoptr i64 %v6402 to ptr
  store i64 %v6401, ptr %p6403, align 8, !alias.scope !3, !noalias !4
  %v6404 = load i64, ptr %slot40, align 8
  store i64 %v6404, ptr %slot1185, align 8
  %v6405 = load i64, ptr %slot1185, align 8
  %p6406 = inttoptr i64 %v6405 to ptr
  store i32 0, ptr %p6406, align 4, !alias.scope !3, !noalias !4
  %v6407 = load i64, ptr %slot1185, align 8
  %p6408 = inttoptr i64 %v6407 to ptr
  store i32 20, ptr %p6408, align 4, !alias.scope !3, !noalias !4
  %v6409 = load i64, ptr %slot1185, align 8
  %v6410 = load i64, ptr %slot39, align 8
  %p6411 = inttoptr i64 %v6410 to ptr
  store i64 %v6409, ptr %p6411, align 8, !alias.scope !3, !noalias !4
  %v6412 = load i64, ptr %slot38, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  %ld6414 = load i64, ptr %p6413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6414, ptr %slot1186, align 8
  %v6415 = load i64, ptr %slot39, align 8
  %p6416 = inttoptr i64 %v6415 to ptr
  %ld6417 = load i64, ptr %p6416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6417, ptr %slot1187, align 8
  %v6418 = load i64, ptr %slot1, align 8
  %v6419 = load i64, ptr %slot1186, align 8
  %v6420 = load i64, ptr %slot1187, align 8
  call void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8 %callresult1189, i64 %v6418, i64 %v6419, i64 %v6420) nomerge, !dbg !178
  %addr6421 = ptrtoint ptr %callresult1189 to i64
  store i64 %addr6421, ptr %slot1188, align 8
  %v6422 = load i64, ptr %slot1188, align 8
  %v6423 = load i64, ptr %slot38, align 8
  %p6424 = inttoptr i64 %v6423 to ptr
  store i64 %v6422, ptr %p6424, align 8, !alias.scope !3, !noalias !4
  %v6425 = load i64, ptr %slot38, align 8
  %p6426 = inttoptr i64 %v6425 to ptr
  %ld6427 = load i64, ptr %p6426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6427, ptr %slot1190, align 8
  %v6428 = load i64, ptr %slot27, align 8
  store i64 %v6428, ptr %slot1191, align 8
  %v6429 = load i64, ptr %slot1190, align 8
  %v6430 = load i64, ptr %slot1191, align 8
  %p6431 = inttoptr i64 %v6429 to ptr
  %p6432 = inttoptr i64 %v6430 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6432, ptr %p6431, i64 40, i1 false)
  %v6433 = load i64, ptr %slot22, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  store i32 2, ptr %p6434, align 4, !alias.scope !3, !noalias !4
  %v6435 = load i64, ptr %slot21, align 8
  %p6436 = inttoptr i64 %v6435 to ptr
  store i32 1, ptr %p6436, align 4, !alias.scope !3, !noalias !4
  %v6437 = load i64, ptr %slot17, align 8
  %p6438 = inttoptr i64 %v6437 to ptr
  %ld6439 = load i32, ptr %p6438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6439, ptr %slot1192, align 8
  %v6440 = load i32, ptr %slot1192, align 8
  %cv6441 = zext i32 %v6440 to i64
  %cond6442 = icmp ne i64 %cv6441, 0
  br i1 %cond6442, label %bb_rcslotdrop1545, label %bb_rcslotdone1545
bb_rcslotdrop1545:
  %v6443 = load i64, ptr %slot17, align 8
  %p6444 = inttoptr i64 %v6443 to ptr
  store i32 0, ptr %p6444, align 4, !alias.scope !3, !noalias !4
  %v6445 = load i64, ptr %slot23, align 8
  store i64 %v6445, ptr %slot1193, align 8
  %v6446 = load i64, ptr %slot18, align 8
  %p6447 = inttoptr i64 %v6446 to ptr
  %ld6448 = load i32, ptr %p6447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6448, ptr %slot1194, align 8
  %v6449 = load i32, ptr %slot1194, align 8
  %op6450 = and i32 %v6449, 28
  store i32 %op6450, ptr %slot1195, align 8
  %v6451 = load i32, ptr %slot1195, align 8
  %cv6452 = zext i32 %v6451 to i64
  %cond6453 = icmp ne i64 %cv6452, 0
  br i1 %cond6453, label %bb_rcslotrole1545, label %bb_rcslotowner1545
bb_rcslotrole1545:
  %v6454 = load i64, ptr %slot45, align 8
  store i64 %v6454, ptr %slot1196, align 8
  %v6455 = load i64, ptr %slot1196, align 8
  %v6456 = load i64, ptr %slot1193, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6455, i64 %v6456) nomerge, !dbg !178
  br label %bb_rcslotdone1545
bb_rcslotowner1545:
  %v6457 = load i64, ptr %slot45, align 8
  store i64 %v6457, ptr %slot1197, align 8
  %v6458 = load i64, ptr %slot1197, align 8
  %v6459 = load i64, ptr %slot1193, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6458, i64 %v6459) nomerge, !dbg !178
  br label %bb_rcslotdone1545
bb_rcslotdone1545:
  %v6460 = load i64, ptr %slot23, align 8
  store i64 %v6460, ptr %slot1198, align 8
  %v6461 = load i64, ptr %slot27, align 8
  store i64 %v6461, ptr %slot1199, align 8
  %v6462 = load i64, ptr %slot1199, align 8
  %v6463 = load i64, ptr %slot1198, align 8
  %p6464 = inttoptr i64 %v6462 to ptr
  %p6465 = inttoptr i64 %v6463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6465, ptr %p6464, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v6466 = load i64, ptr %slot18, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  store i32 2, ptr %p6467, align 4, !alias.scope !3, !noalias !4
  %v6468 = load i64, ptr %slot22, align 8
  %p6469 = inttoptr i64 %v6468 to ptr
  %ld6470 = load i32, ptr %p6469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6470, ptr %slot1200, align 8
  %v6471 = load i32, ptr %slot1200, align 8
  %v6472 = load i64, ptr %slot18, align 8
  %p6473 = inttoptr i64 %v6472 to ptr
  store i32 %v6471, ptr %p6473, align 4, !alias.scope !3, !noalias !4
  %v6474 = load i64, ptr %slot21, align 8
  %p6475 = inttoptr i64 %v6474 to ptr
  store i32 0, ptr %p6475, align 4, !alias.scope !3, !noalias !4
  %v6476 = load i64, ptr %slot17, align 8
  %p6477 = inttoptr i64 %v6476 to ptr
  store i32 1, ptr %p6477, align 4, !alias.scope !3, !noalias !4
  %v6478 = load i64, ptr %slot1198, align 8
  %v6479 = load i64, ptr %slot38, align 8
  %p6480 = inttoptr i64 %v6479 to ptr
  store i64 %v6478, ptr %p6480, align 8, !alias.scope !3, !noalias !4
  %v6481 = load i64, ptr %slot38, align 8
  %p6482 = inttoptr i64 %v6481 to ptr
  %ld6483 = load i64, ptr %p6482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6483, ptr %slot1201, align 8
  %v6484 = load i64, ptr %slot38, align 8
  %p6485 = inttoptr i64 %v6484 to ptr
  %ld6486 = load i64, ptr %p6485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6486, ptr %slot1202, align 8
  %v6487 = load i64, ptr %slot27, align 8
  store i64 %v6487, ptr %slot1203, align 8
  %v6488 = load i64, ptr %slot46, align 8
  store i64 %v6488, ptr %slot1204, align 8
  %v6489 = load i64, ptr %slot45, align 8
  %v6490 = load i64, ptr %slot1203, align 8
  %v6491 = load i64, ptr %slot1202, align 8
  %v6492 = load i64, ptr %slot1204, align 8
  %cv6493 = trunc i64 %v6492 to i32
  %call6494 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v6489, i64 %v6490, i64 %v6491, i32 %cv6493) nomerge, !dbg !180
  store i32 %call6494, ptr %slot1205, align 8
  %v6495 = load i32, ptr %slot1205, align 8
  %cv6496 = zext i32 %v6495 to i64
  %cond6497 = icmp ne i64 %cv6496, 0
  br i1 %cond6497, label %bb_rcsuccess1565, label %bb_rcfailure1565
bb_rcfailure1565:
  %v6498 = load i64, ptr %slot45, align 8
  %p6499 = inttoptr i64 %v6498 to ptr
  %call6500 = call i32 @myl_rc_take_failure(ptr %p6499) nomerge, !dbg !180
  store i32 %call6500, ptr %slot1206, align 8
  %v6501 = load i64, ptr %slot1, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  %v6503 = load i32, ptr %slot1206, align 8
  %call6504 = call i32 @myl_qbe_rc_status(ptr %p6502, i32 %v6503) nomerge, !dbg !180
  store i32 %call6504, ptr %slot1207, align 8
  br label %bb_failure
bb_rcsuccess1565:
  %v6505 = load i64, ptr %slot17, align 8
  %p6506 = inttoptr i64 %v6505 to ptr
  store i32 0, ptr %p6506, align 4, !alias.scope !3, !noalias !4
  %v6507 = load i64, ptr %slot22, align 8
  %p6508 = inttoptr i64 %v6507 to ptr
  store i32 2, ptr %p6508, align 4, !alias.scope !3, !noalias !4
  %v6509 = load i64, ptr %slot21, align 8
  %p6510 = inttoptr i64 %v6509 to ptr
  store i32 1, ptr %p6510, align 4, !alias.scope !3, !noalias !4
  %v6511 = load i64, ptr %slot27, align 8
  store i64 %v6511, ptr %slot1208, align 8
  %v6512 = load i64, ptr %slot21, align 8
  %p6513 = inttoptr i64 %v6512 to ptr
  store i32 0, ptr %p6513, align 4, !alias.scope !3, !noalias !4
  %v6514 = load i64, ptr %slot17, align 8
  %p6515 = inttoptr i64 %v6514 to ptr
  %ld6516 = load i32, ptr %p6515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6516, ptr %slot1209, align 8
  %v6517 = load i32, ptr %slot1209, align 8
  %cv6518 = zext i32 %v6517 to i64
  %cond6519 = icmp ne i64 %cv6518, 0
  br i1 %cond6519, label %bb_rcslotdrop1575, label %bb_rcslotdone1575
bb_rcslotdrop1575:
  %v6520 = load i64, ptr %slot17, align 8
  %p6521 = inttoptr i64 %v6520 to ptr
  store i32 0, ptr %p6521, align 4, !alias.scope !3, !noalias !4
  %v6522 = load i64, ptr %slot23, align 8
  store i64 %v6522, ptr %slot1210, align 8
  %v6523 = load i64, ptr %slot18, align 8
  %p6524 = inttoptr i64 %v6523 to ptr
  %ld6525 = load i32, ptr %p6524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6525, ptr %slot1211, align 8
  %v6526 = load i32, ptr %slot1211, align 8
  %op6527 = and i32 %v6526, 28
  store i32 %op6527, ptr %slot1212, align 8
  %v6528 = load i32, ptr %slot1212, align 8
  %cv6529 = zext i32 %v6528 to i64
  %cond6530 = icmp ne i64 %cv6529, 0
  br i1 %cond6530, label %bb_rcslotrole1575, label %bb_rcslotowner1575
bb_rcslotrole1575:
  %v6531 = load i64, ptr %slot45, align 8
  store i64 %v6531, ptr %slot1213, align 8
  %v6532 = load i64, ptr %slot1213, align 8
  %v6533 = load i64, ptr %slot1210, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6532, i64 %v6533) nomerge, !dbg !180
  br label %bb_rcslotdone1575
bb_rcslotowner1575:
  %v6534 = load i64, ptr %slot45, align 8
  store i64 %v6534, ptr %slot1214, align 8
  %v6535 = load i64, ptr %slot1214, align 8
  %v6536 = load i64, ptr %slot1210, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6535, i64 %v6536) nomerge, !dbg !180
  br label %bb_rcslotdone1575
bb_rcslotdone1575:
  %v6537 = load i64, ptr %slot15, align 8
  %p6538 = inttoptr i64 %v6537 to ptr
  %ld6539 = load i32, ptr %p6538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6539, ptr %slot1215, align 8
  %v6540 = load i32, ptr %slot1215, align 8
  %cv6541 = zext i32 %v6540 to i64
  %cond6542 = icmp ne i64 %cv6541, 0
  br i1 %cond6542, label %bb_rcslotdrop1584, label %bb_rcslotdone1584
bb_rcslotdrop1584:
  %v6543 = load i64, ptr %slot15, align 8
  %p6544 = inttoptr i64 %v6543 to ptr
  store i32 0, ptr %p6544, align 4, !alias.scope !3, !noalias !4
  %v6545 = load i64, ptr %slot37, align 8
  store i64 %v6545, ptr %slot1216, align 8
  %v6546 = load i64, ptr %slot16, align 8
  %p6547 = inttoptr i64 %v6546 to ptr
  %ld6548 = load i32, ptr %p6547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6548, ptr %slot1217, align 8
  %v6549 = load i32, ptr %slot1217, align 8
  %op6550 = and i32 %v6549, 28
  store i32 %op6550, ptr %slot1218, align 8
  %v6551 = load i32, ptr %slot1218, align 8
  %cv6552 = zext i32 %v6551 to i64
  %cond6553 = icmp ne i64 %cv6552, 0
  br i1 %cond6553, label %bb_rcslotrole1584, label %bb_rcslotowner1584
bb_rcslotrole1584:
  %v6554 = load i64, ptr %slot45, align 8
  store i64 %v6554, ptr %slot1219, align 8
  %v6555 = load i64, ptr %slot1219, align 8
  %v6556 = load i64, ptr %slot1216, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6555, i64 %v6556) nomerge, !dbg !180
  br label %bb_rcslotdone1584
bb_rcslotowner1584:
  %v6557 = load i64, ptr %slot45, align 8
  store i64 %v6557, ptr %slot1220, align 8
  %v6558 = load i64, ptr %slot1220, align 8
  %v6559 = load i64, ptr %slot1216, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6558, i64 %v6559) nomerge, !dbg !180
  br label %bb_rcslotdone1584
bb_rcslotdone1584:
  %v6560 = load i64, ptr %slot13, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  %ld6562 = load i32, ptr %p6561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6562, ptr %slot1221, align 8
  %v6563 = load i32, ptr %slot1221, align 8
  %cv6564 = zext i32 %v6563 to i64
  %cond6565 = icmp ne i64 %cv6564, 0
  br i1 %cond6565, label %bb_rcslotdrop1593, label %bb_rcslotdone1593
bb_rcslotdrop1593:
  %v6566 = load i64, ptr %slot13, align 8
  %p6567 = inttoptr i64 %v6566 to ptr
  store i32 0, ptr %p6567, align 4, !alias.scope !3, !noalias !4
  %v6568 = load i64, ptr %slot36, align 8
  store i64 %v6568, ptr %slot1222, align 8
  %v6569 = load i64, ptr %slot14, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  %ld6571 = load i32, ptr %p6570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6571, ptr %slot1223, align 8
  %v6572 = load i32, ptr %slot1223, align 8
  %op6573 = and i32 %v6572, 28
  store i32 %op6573, ptr %slot1224, align 8
  %v6574 = load i32, ptr %slot1224, align 8
  %cv6575 = zext i32 %v6574 to i64
  %cond6576 = icmp ne i64 %cv6575, 0
  br i1 %cond6576, label %bb_rcslotrole1593, label %bb_rcslotowner1593
bb_rcslotrole1593:
  %v6577 = load i64, ptr %slot45, align 8
  store i64 %v6577, ptr %slot1225, align 8
  %v6578 = load i64, ptr %slot1225, align 8
  %v6579 = load i64, ptr %slot1222, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6578, i64 %v6579) nomerge, !dbg !180
  br label %bb_rcslotdone1593
bb_rcslotowner1593:
  %v6580 = load i64, ptr %slot45, align 8
  store i64 %v6580, ptr %slot1226, align 8
  %v6581 = load i64, ptr %slot1226, align 8
  %v6582 = load i64, ptr %slot1222, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6581, i64 %v6582) nomerge, !dbg !180
  br label %bb_rcslotdone1593
bb_rcslotdone1593:
  %v6583 = load i64, ptr %slot11, align 8
  %p6584 = inttoptr i64 %v6583 to ptr
  %ld6585 = load i32, ptr %p6584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6585, ptr %slot1227, align 8
  %v6586 = load i32, ptr %slot1227, align 8
  %cv6587 = zext i32 %v6586 to i64
  %cond6588 = icmp ne i64 %cv6587, 0
  br i1 %cond6588, label %bb_rcslotdrop1602, label %bb_rcslotdone1602
bb_rcslotdrop1602:
  %v6589 = load i64, ptr %slot11, align 8
  %p6590 = inttoptr i64 %v6589 to ptr
  store i32 0, ptr %p6590, align 4, !alias.scope !3, !noalias !4
  %v6591 = load i64, ptr %slot35, align 8
  store i64 %v6591, ptr %slot1228, align 8
  %v6592 = load i64, ptr %slot12, align 8
  %p6593 = inttoptr i64 %v6592 to ptr
  %ld6594 = load i32, ptr %p6593, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6594, ptr %slot1229, align 8
  %v6595 = load i32, ptr %slot1229, align 8
  %op6596 = and i32 %v6595, 28
  store i32 %op6596, ptr %slot1230, align 8
  %v6597 = load i32, ptr %slot1230, align 8
  %cv6598 = zext i32 %v6597 to i64
  %cond6599 = icmp ne i64 %cv6598, 0
  br i1 %cond6599, label %bb_rcslotrole1602, label %bb_rcslotowner1602
bb_rcslotrole1602:
  %v6600 = load i64, ptr %slot45, align 8
  store i64 %v6600, ptr %slot1231, align 8
  %v6601 = load i64, ptr %slot1231, align 8
  %v6602 = load i64, ptr %slot1228, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6601, i64 %v6602) nomerge, !dbg !180
  br label %bb_rcslotdone1602
bb_rcslotowner1602:
  %v6603 = load i64, ptr %slot45, align 8
  store i64 %v6603, ptr %slot1232, align 8
  %v6604 = load i64, ptr %slot1232, align 8
  %v6605 = load i64, ptr %slot1228, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6604, i64 %v6605) nomerge, !dbg !180
  br label %bb_rcslotdone1602
bb_rcslotdone1602:
  %v6606 = load i64, ptr %slot9, align 8
  %p6607 = inttoptr i64 %v6606 to ptr
  %ld6608 = load i32, ptr %p6607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6608, ptr %slot1233, align 8
  %v6609 = load i32, ptr %slot1233, align 8
  %cv6610 = zext i32 %v6609 to i64
  %cond6611 = icmp ne i64 %cv6610, 0
  br i1 %cond6611, label %bb_rcslotdrop1611, label %bb_rcslotdone1611
bb_rcslotdrop1611:
  %v6612 = load i64, ptr %slot9, align 8
  %p6613 = inttoptr i64 %v6612 to ptr
  store i32 0, ptr %p6613, align 4, !alias.scope !3, !noalias !4
  %v6614 = load i64, ptr %slot34, align 8
  store i64 %v6614, ptr %slot1234, align 8
  %v6615 = load i64, ptr %slot10, align 8
  %p6616 = inttoptr i64 %v6615 to ptr
  %ld6617 = load i32, ptr %p6616, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6617, ptr %slot1235, align 8
  %v6618 = load i32, ptr %slot1235, align 8
  %op6619 = and i32 %v6618, 28
  store i32 %op6619, ptr %slot1236, align 8
  %v6620 = load i32, ptr %slot1236, align 8
  %cv6621 = zext i32 %v6620 to i64
  %cond6622 = icmp ne i64 %cv6621, 0
  br i1 %cond6622, label %bb_rcslotrole1611, label %bb_rcslotowner1611
bb_rcslotrole1611:
  %v6623 = load i64, ptr %slot45, align 8
  store i64 %v6623, ptr %slot1237, align 8
  %v6624 = load i64, ptr %slot1237, align 8
  %v6625 = load i64, ptr %slot1234, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6624, i64 %v6625) nomerge, !dbg !180
  br label %bb_rcslotdone1611
bb_rcslotowner1611:
  %v6626 = load i64, ptr %slot45, align 8
  store i64 %v6626, ptr %slot1238, align 8
  %v6627 = load i64, ptr %slot1238, align 8
  %v6628 = load i64, ptr %slot1234, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6627, i64 %v6628) nomerge, !dbg !180
  br label %bb_rcslotdone1611
bb_rcslotdone1611:
  %v6629 = load i64, ptr %slot7, align 8
  %p6630 = inttoptr i64 %v6629 to ptr
  %ld6631 = load i32, ptr %p6630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6631, ptr %slot1239, align 8
  %v6632 = load i32, ptr %slot1239, align 8
  %cv6633 = zext i32 %v6632 to i64
  %cond6634 = icmp ne i64 %cv6633, 0
  br i1 %cond6634, label %bb_rcslotdrop1620, label %bb_rcslotdone1620
bb_rcslotdrop1620:
  %v6635 = load i64, ptr %slot7, align 8
  %p6636 = inttoptr i64 %v6635 to ptr
  store i32 0, ptr %p6636, align 4, !alias.scope !3, !noalias !4
  %v6637 = load i64, ptr %slot33, align 8
  store i64 %v6637, ptr %slot1240, align 8
  %v6638 = load i64, ptr %slot8, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  %ld6640 = load i32, ptr %p6639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6640, ptr %slot1241, align 8
  %v6641 = load i32, ptr %slot1241, align 8
  %op6642 = and i32 %v6641, 28
  store i32 %op6642, ptr %slot1242, align 8
  %v6643 = load i32, ptr %slot1242, align 8
  %cv6644 = zext i32 %v6643 to i64
  %cond6645 = icmp ne i64 %cv6644, 0
  br i1 %cond6645, label %bb_rcslotrole1620, label %bb_rcslotowner1620
bb_rcslotrole1620:
  %v6646 = load i64, ptr %slot45, align 8
  store i64 %v6646, ptr %slot1243, align 8
  %v6647 = load i64, ptr %slot1243, align 8
  %v6648 = load i64, ptr %slot1240, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6647, i64 %v6648) nomerge, !dbg !180
  br label %bb_rcslotdone1620
bb_rcslotowner1620:
  %v6649 = load i64, ptr %slot45, align 8
  store i64 %v6649, ptr %slot1244, align 8
  %v6650 = load i64, ptr %slot1244, align 8
  %v6651 = load i64, ptr %slot1240, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6650, i64 %v6651) nomerge, !dbg !180
  br label %bb_rcslotdone1620
bb_rcslotdone1620:
  %v6652 = load i64, ptr %slot5, align 8
  %p6653 = inttoptr i64 %v6652 to ptr
  %ld6654 = load i32, ptr %p6653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6654, ptr %slot1245, align 8
  %v6655 = load i32, ptr %slot1245, align 8
  %cv6656 = zext i32 %v6655 to i64
  %cond6657 = icmp ne i64 %cv6656, 0
  br i1 %cond6657, label %bb_rcslotdrop1629, label %bb_rcslotdone1629
bb_rcslotdrop1629:
  %v6658 = load i64, ptr %slot5, align 8
  %p6659 = inttoptr i64 %v6658 to ptr
  store i32 0, ptr %p6659, align 4, !alias.scope !3, !noalias !4
  %v6660 = load i64, ptr %slot32, align 8
  store i64 %v6660, ptr %slot1246, align 8
  %v6661 = load i64, ptr %slot6, align 8
  %p6662 = inttoptr i64 %v6661 to ptr
  %ld6663 = load i32, ptr %p6662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6663, ptr %slot1247, align 8
  %v6664 = load i32, ptr %slot1247, align 8
  %op6665 = and i32 %v6664, 28
  store i32 %op6665, ptr %slot1248, align 8
  %v6666 = load i32, ptr %slot1248, align 8
  %cv6667 = zext i32 %v6666 to i64
  %cond6668 = icmp ne i64 %cv6667, 0
  br i1 %cond6668, label %bb_rcslotrole1629, label %bb_rcslotowner1629
bb_rcslotrole1629:
  %v6669 = load i64, ptr %slot45, align 8
  store i64 %v6669, ptr %slot1249, align 8
  %v6670 = load i64, ptr %slot1249, align 8
  %v6671 = load i64, ptr %slot1246, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6670, i64 %v6671) nomerge, !dbg !180
  br label %bb_rcslotdone1629
bb_rcslotowner1629:
  %v6672 = load i64, ptr %slot45, align 8
  store i64 %v6672, ptr %slot1250, align 8
  %v6673 = load i64, ptr %slot1250, align 8
  %v6674 = load i64, ptr %slot1246, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6673, i64 %v6674) nomerge, !dbg !180
  br label %bb_rcslotdone1629
bb_rcslotdone1629:
  %v6675 = load i64, ptr %slot1208, align 8
  %p6676 = inttoptr i64 %v6675 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6676, i64 40, i1 false)
  ret void
bb_failure:
  %v6677 = load i64, ptr %slot4, align 8
  %p6678 = inttoptr i64 %v6677 to ptr
  call void @llvm.memset.p0.i64(ptr %p6678, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !180
  %v6679 = load i64, ptr %slot4, align 8
  %p6680 = inttoptr i64 %v6679 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6680, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v6681 = load i64, ptr %slot4, align 8
  %p6682 = inttoptr i64 %v6681 to ptr
  call void @llvm.memset.p0.i64(ptr %p6682, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !180
  %v6683 = load i64, ptr %slot4, align 8
  %p6684 = inttoptr i64 %v6683 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6684, i64 40, i1 false)
  ret void
}

@myl_lit_bae599b006792dd02a4a9c7cf18fd28335c95841bfb7b94284aeba4f8b10c547 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64, i64)
declare void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_97bbcd9db50097e4e50d294b15751b0838cf2924ba5c16b52b23aa9e3a225f04", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_97bbcd9db50097e4e50d294b15751b0838cf2924ba5c16b52b23aa9e3a225f04", linkageName: "myl_f_97bbcd9db50097e4e50d294b15751b0838cf2924ba5c16b52b23aa9e3a225f04", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2912032144413492901, i64 0, !"myl_f_97bbcd9db50097e4e50d294b15751b0838cf2924ba5c16b52b23aa9e3a225f04"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!136 = !DILocation(line: 31, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!140 = !DILocation(line: 41, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!142 = !DILocation(line: 43, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!144 = !DILocation(line: 45, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!146 = !DILocation(line: 46, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!148 = !DILocation(line: 53, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!150 = !DILocation(line: 55, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!152 = !DILocation(line: 56, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!154 = !DILocation(line: 63, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!156 = !DILocation(line: 65, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!158 = !DILocation(line: 78, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!160 = !DILocation(line: 80, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!162 = !DILocation(line: 94, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!164 = !DILocation(line: 96, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!166 = !DILocation(line: 98, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!168 = !DILocation(line: 99, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!170 = !DILocation(line: 105, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!172 = !DILocation(line: 106, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647399)
!174 = !DILocation(line: 108, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!176 = !DILocation(line: 110, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!178 = !DILocation(line: 124, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647535)
!180 = !DILocation(line: 125, column: 0, scope: !181)
