target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v56 = load i64, ptr %slot1, align 8
  %op57 = add i64 %v56, 32
  store i64 %op57, ptr %slot3, align 8
  %mem58 = alloca i8, i64 40, align 8
  %ptr59 = ptrtoint ptr %mem58 to i64
  store i64 %ptr59, ptr %slot4, align 8
  %mem60 = alloca i8, i64 8, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot5, align 8
  %mem62 = alloca i8, i64 8, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot6, align 8
  %mem64 = alloca i8, i64 8, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot7, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot8, align 8
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot9, align 8
  %v70 = load i64, ptr %slot6, align 8
  %p71 = inttoptr i64 %v70 to ptr
  store i64 0, ptr %p71, align 8, !alias.scope !3, !noalias !4
  %v72 = load i64, ptr %slot2, align 8
  %v73 = load i64, ptr %slot5, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v75 = load i64, ptr %slot5, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !3, !noalias !4
  store i64 %ld77, ptr %slot10, align 8
  %v78 = load i64, ptr %slot10, align 8
  %v79 = load i64, ptr %slot8, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot8, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot11, align 8
  %v84 = load i64, ptr %slot11, align 8
  %op85 = add i64 %v84, 256
  store i64 %op85, ptr %slot12, align 8
  %v86 = load i64, ptr %slot12, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %ld88 = load i64, ptr %p87, align 8, !alias.scope !4, !noalias !3
  store i64 %ld88, ptr %slot13, align 8
  %v89 = load i64, ptr %slot13, align 8
  %v90 = load i64, ptr %slot8, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 %v89, ptr %p91, align 8, !alias.scope !3, !noalias !4
  %v92 = load i64, ptr %slot8, align 8
  %p93 = inttoptr i64 %v92 to ptr
  %ld94 = load i64, ptr %p93, align 8, !alias.scope !3, !noalias !4
  store i64 %ld94, ptr %slot14, align 8
  %v95 = load i64, ptr %slot6, align 8
  store i64 %v95, ptr %slot15, align 8
  %v96 = load i64, ptr %slot14, align 8
  %v97 = load i64, ptr %slot15, align 8
  %p98 = inttoptr i64 %v97 to ptr
  store i64 %v96, ptr %p98, align 8, !alias.scope !3, !noalias !4
  %v99 = load i64, ptr %slot5, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %ld101 = load i64, ptr %p100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld101, ptr %slot16, align 8
  %v102 = load i64, ptr %slot16, align 8
  %v103 = load i64, ptr %slot8, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !3, !noalias !4
  %v105 = load i64, ptr %slot8, align 8
  %p106 = inttoptr i64 %v105 to ptr
  %ld107 = load i64, ptr %p106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld107, ptr %slot17, align 8
  %v108 = load i64, ptr %slot17, align 8
  %op109 = add i64 %v108, 264
  store i64 %op109, ptr %slot18, align 8
  %v110 = load i64, ptr %slot18, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !4, !noalias !3
  store i64 %ld112, ptr %slot19, align 8
  %v113 = load i64, ptr %slot19, align 8
  %v114 = load i64, ptr %slot8, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot9, align 8
  %p117 = inttoptr i64 %v116 to ptr
  store i64 1, ptr %p117, align 8, !alias.scope !3, !noalias !4
  %v118 = load i64, ptr %slot9, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot20, align 8
  %v121 = load i64, ptr %slot8, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot21, align 8
  %v124 = load i64, ptr %slot21, align 8
  %v125 = load i64, ptr %slot20, align 8
  %ovpair127 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v124, i64 %v125)
  %op126 = extractvalue { i64, i1 } %ovpair127, 0
  %ov128 = extractvalue { i64, i1 } %ovpair127, 1
  store i64 %op126, ptr %slot22, align 8
  %cv129 = zext i1 %ov128 to i64
  store i64 %cv129, ptr %slot23, align 8
  %v130 = load i64, ptr %slot23, align 8
  %cond131 = icmp ne i64 %v130, 0
  br i1 %cond131, label %bb_overflow14, label %bb_checked14
bb_overflow14:
  %v132 = load i64, ptr %slot1, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %v134 = load i64, ptr %slot21, align 8
  %v135 = load i64, ptr %slot20, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p133, i64 1, i64 %v134, i64 %v135, i64 64) nomerge, !dbg !110
  unreachable
bb_checked14:
  %v136 = load i64, ptr %slot22, align 8
  %v137 = load i64, ptr %slot8, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot8, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot24, align 8
  %v142 = load i64, ptr %slot7, align 8
  store i64 %v142, ptr %slot25, align 8
  %v143 = load i64, ptr %slot24, align 8
  %v144 = load i64, ptr %slot25, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot7, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot26, align 8
  %v149 = load i64, ptr %slot26, align 8
  %v150 = load i64, ptr %slot8, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot9, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 0, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot9, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot27, align 8
  %v157 = load i64, ptr %slot8, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot28, align 8
  %v160 = load i64, ptr %slot28, align 8
  %v161 = load i64, ptr %slot27, align 8
  %cmp162 = icmp slt i64 %v160, %v161
  %cv163 = zext i1 %cmp162 to i64
  store i64 %cv163, ptr %slot29, align 8
  %v164 = load i64, ptr %slot29, align 8
  %v165 = load i64, ptr %slot8, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 %v164, ptr %p166, align 8, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot8, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot30, align 8
  %v170 = load i64, ptr %slot30, align 8
  %cond171 = icmp ne i64 %v170, 0
  br i1 %cond171, label %bb_next23, label %bb_i17
bb_next23:
  %v172 = load i64, ptr %slot6, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld174, ptr %slot31, align 8
  %v175 = load i64, ptr %slot31, align 8
  %op176 = add i64 %v175, 0
  store i64 %op176, ptr %slot32, align 8
  %v177 = load i64, ptr %slot32, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !6, !noalias !7
  store i64 %ld179, ptr %slot33, align 8
  %v180 = load i64, ptr %slot33, align 8
  %v181 = load i64, ptr %slot8, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot8, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot34, align 8
  %v186 = load i64, ptr %slot34, align 8
  %cmp187 = icmp ugt i64 %v186, 9223372036854775807
  %cv188 = zext i1 %cmp187 to i64
  store i64 %cv188, ptr %slot35, align 8
  %v189 = load i64, ptr %slot35, align 8
  %cond190 = icmp ne i64 %v189, 0
  br i1 %cond190, label %bb_cast_overflow28, label %bb_cast_ok28
bb_cast_overflow28:
  %v191 = load i64, ptr %slot1, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %v193 = load i64, ptr %slot34, align 8
  call void @myl_qbe_fail_cast(ptr %p192, i64 %v193, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok28:
  %v194 = load i64, ptr %slot34, align 8
  %v195 = load i64, ptr %slot8, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot7, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot36, align 8
  %v200 = load i64, ptr %slot36, align 8
  %v201 = load i64, ptr %slot9, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot9, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot37, align 8
  %v206 = load i64, ptr %slot8, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot38, align 8
  %v209 = load i64, ptr %slot38, align 8
  %v210 = load i64, ptr %slot37, align 8
  %ovpair212 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v209, i64 %v210)
  %op211 = extractvalue { i64, i1 } %ovpair212, 0
  %ov213 = extractvalue { i64, i1 } %ovpair212, 1
  store i64 %op211, ptr %slot39, align 8
  %v214 = load i64, ptr %slot38, align 8
  %v215 = load i64, ptr %slot39, align 8
  %op216 = xor i64 %v214, %v215
  store i64 %op216, ptr %slot40, align 8
  %v217 = load i64, ptr %slot37, align 8
  %v218 = load i64, ptr %slot39, align 8
  %op219 = xor i64 %v217, %v218
  store i64 %op219, ptr %slot41, align 8
  %v220 = load i64, ptr %slot40, align 8
  %v221 = load i64, ptr %slot41, align 8
  %op222 = and i64 %v220, %v221
  store i64 %op222, ptr %slot42, align 8
  %cv223 = zext i1 %ov213 to i64
  store i64 %cv223, ptr %slot43, align 8
  %v224 = load i64, ptr %slot43, align 8
  %cond225 = icmp ne i64 %v224, 0
  br i1 %cond225, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v226 = load i64, ptr %slot1, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %v228 = load i64, ptr %slot38, align 8
  %v229 = load i64, ptr %slot37, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p227, i64 0, i64 %v228, i64 %v229, i64 64) nomerge, !dbg !114
  unreachable
bb_checked32:
  %v230 = load i64, ptr %slot39, align 8
  %v231 = load i64, ptr %slot8, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 %v230, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot8, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot44, align 8
  %v236 = load i64, ptr %slot7, align 8
  store i64 %v236, ptr %slot45, align 8
  %v237 = load i64, ptr %slot44, align 8
  %v238 = load i64, ptr %slot45, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 %v237, ptr %p239, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_i17:
  %v240 = load i64, ptr %slot7, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot46, align 8
  %v243 = load i64, ptr %slot46, align 8
  %v244 = load i64, ptr %slot8, align 8
  %p245 = inttoptr i64 %v244 to ptr
  store i64 %v243, ptr %p245, align 8, !alias.scope !3, !noalias !4
  %v246 = load i64, ptr %slot6, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot47, align 8
  %v249 = load i64, ptr %slot8, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot48, align 8
  %v252 = load i64, ptr %slot47, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !6, !noalias !7
  store i64 %ld254, ptr %slot49, align 8
  %v255 = load i64, ptr %slot48, align 8
  %v256 = load i64, ptr %slot49, align 8
  %cmp257 = icmp ult i64 %v255, %v256
  %cv258 = zext i1 %cmp257 to i64
  store i64 %cv258, ptr %slot50, align 8
  %v259 = load i64, ptr %slot50, align 8
  %cond260 = icmp ne i64 %v259, 0
  br i1 %cond260, label %bb_success45, label %bb_failed45
bb_failed45:
  %v261 = load i64, ptr %slot1, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %v263 = load i64, ptr %slot48, align 8
  %v264 = load i64, ptr %slot49, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p262, i64 %v263, i64 %v264) nomerge, !dbg !116
  unreachable
bb_success45:
  %v265 = load i64, ptr %slot47, align 8
  %op266 = add i64 %v265, 32
  store i64 %op266, ptr %slot51, align 8
  %v267 = load i64, ptr %slot51, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !6, !noalias !7
  store i64 %ld269, ptr %slot52, align 8
  %v270 = load i64, ptr %slot48, align 8
  %op271 = mul i64 %v270, 40
  store i64 %op271, ptr %slot53, align 8
  %v272 = load i64, ptr %slot52, align 8
  %v273 = load i64, ptr %slot53, align 8
  %op274 = add i64 %v272, %v273
  store i64 %op274, ptr %slot54, align 8
  %v275 = load i64, ptr %slot54, align 8
  %v276 = load i64, ptr %slot8, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 %v275, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot8, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot55, align 8
  %v281 = load i64, ptr %slot55, align 8
  %p282 = inttoptr i64 %v281 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p282, i64 40, i1 false)
  ret void
bb_failure:
  %v283 = load i64, ptr %slot4, align 8
  %p284 = inttoptr i64 %v283 to ptr
  call void @llvm.memset.p0.i64(ptr %p284, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v285 = load i64, ptr %slot4, align 8
  %p286 = inttoptr i64 %v285 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p286, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v287 = load i64, ptr %slot4, align 8
  %p288 = inttoptr i64 %v287 to ptr
  call void @llvm.memset.p0.i64(ptr %p288, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v289 = load i64, ptr %slot4, align 8
  %p290 = inttoptr i64 %v289 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p290, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow", linkageName: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11912398982025620975, i64 0, !"myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!110 = !DILocation(line: 7, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!112 = !DILocation(line: 14, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!116 = !DILocation(line: 19, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!118 = !DILocation(line: 20, column: 0, scope: !119)
