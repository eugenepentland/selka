target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v756 = load i64, ptr %slot1, align 8
  %op757 = add i64 %v756, 32
  store i64 %op757, ptr %slot2, align 8
  %mem758 = alloca i8, i64 24, align 8
  %ptr759 = ptrtoint ptr %mem758 to i64
  store i64 %ptr759, ptr %slot3, align 8
  %mem760 = alloca i8, i64 8, align 8
  %ptr761 = ptrtoint ptr %mem760 to i64
  store i64 %ptr761, ptr %slot4, align 8
  %mem762 = alloca i8, i64 8, align 8
  %ptr763 = ptrtoint ptr %mem762 to i64
  store i64 %ptr763, ptr %slot5, align 8
  %mem764 = alloca i8, i64 8, align 8
  %ptr765 = ptrtoint ptr %mem764 to i64
  store i64 %ptr765, ptr %slot6, align 8
  %mem766 = alloca i8, i64 8, align 8
  %ptr767 = ptrtoint ptr %mem766 to i64
  store i64 %ptr767, ptr %slot7, align 8
  %mem768 = alloca i8, i64 8, align 8
  %ptr769 = ptrtoint ptr %mem768 to i64
  store i64 %ptr769, ptr %slot8, align 8
  %mem770 = alloca i8, i64 8, align 8
  %ptr771 = ptrtoint ptr %mem770 to i64
  store i64 %ptr771, ptr %slot9, align 8
  %mem772 = alloca i8, i64 8, align 8
  %ptr773 = ptrtoint ptr %mem772 to i64
  store i64 %ptr773, ptr %slot10, align 8
  %mem774 = alloca i8, i64 8, align 8
  %ptr775 = ptrtoint ptr %mem774 to i64
  store i64 %ptr775, ptr %slot11, align 8
  %mem776 = alloca i8, i64 8, align 8
  %ptr777 = ptrtoint ptr %mem776 to i64
  store i64 %ptr777, ptr %slot12, align 8
  %mem778 = alloca i8, i64 8, align 8
  %ptr779 = ptrtoint ptr %mem778 to i64
  store i64 %ptr779, ptr %slot13, align 8
  %mem780 = alloca i8, i64 8, align 8
  %ptr781 = ptrtoint ptr %mem780 to i64
  store i64 %ptr781, ptr %slot14, align 8
  %mem782 = alloca i8, i64 8, align 8
  %ptr783 = ptrtoint ptr %mem782 to i64
  store i64 %ptr783, ptr %slot15, align 8
  %mem784 = alloca i8, i64 8, align 8
  %ptr785 = ptrtoint ptr %mem784 to i64
  store i64 %ptr785, ptr %slot16, align 8
  %mem786 = alloca i8, i64 8, align 8
  %ptr787 = ptrtoint ptr %mem786 to i64
  store i64 %ptr787, ptr %slot17, align 8
  %mem788 = alloca i8, i64 8, align 8
  %ptr789 = ptrtoint ptr %mem788 to i64
  store i64 %ptr789, ptr %slot18, align 8
  %mem790 = alloca i8, i64 24, align 8
  %ptr791 = ptrtoint ptr %mem790 to i64
  store i64 %ptr791, ptr %slot19, align 8
  %mem792 = alloca i8, i64 8, align 8
  %ptr793 = ptrtoint ptr %mem792 to i64
  store i64 %ptr793, ptr %slot20, align 8
  %mem794 = alloca i8, i64 8, align 8
  %ptr795 = ptrtoint ptr %mem794 to i64
  store i64 %ptr795, ptr %slot21, align 8
  %mem796 = alloca i8, i64 8, align 8
  %ptr797 = ptrtoint ptr %mem796 to i64
  store i64 %ptr797, ptr %slot22, align 8
  %mem798 = alloca i8, i64 8, align 8
  %ptr799 = ptrtoint ptr %mem798 to i64
  store i64 %ptr799, ptr %slot23, align 8
  %mem800 = alloca i8, i64 8, align 8
  %ptr801 = ptrtoint ptr %mem800 to i64
  store i64 %ptr801, ptr %slot24, align 8
  %mem802 = alloca i8, i64 24, align 8
  %ptr803 = ptrtoint ptr %mem802 to i64
  store i64 %ptr803, ptr %slot25, align 8
  %mem804 = alloca i8, i64 8, align 8
  %ptr805 = ptrtoint ptr %mem804 to i64
  store i64 %ptr805, ptr %slot26, align 8
  %mem806 = alloca i8, i64 8, align 8
  %ptr807 = ptrtoint ptr %mem806 to i64
  store i64 %ptr807, ptr %slot27, align 8
  %mem808 = alloca i8, i64 8, align 8
  %ptr809 = ptrtoint ptr %mem808 to i64
  store i64 %ptr809, ptr %slot28, align 8
  %mem810 = alloca i8, i64 8, align 8
  %ptr811 = ptrtoint ptr %mem810 to i64
  store i64 %ptr811, ptr %slot29, align 8
  %mem812 = alloca i8, i64 8, align 8
  %ptr813 = ptrtoint ptr %mem812 to i64
  store i64 %ptr813, ptr %slot30, align 8
  %mem814 = alloca i8, i64 8, align 8
  %ptr815 = ptrtoint ptr %mem814 to i64
  store i64 %ptr815, ptr %slot31, align 8
  %mem816 = alloca i8, i64 24, align 8
  %ptr817 = ptrtoint ptr %mem816 to i64
  store i64 %ptr817, ptr %slot32, align 8
  %v818 = load i64, ptr %slot26, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i64 0, ptr %p819, align 8, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot27, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 0, ptr %p821, align 8, !alias.scope !3, !noalias !4
  %v822 = load i64, ptr %slot28, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 0, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot1, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %call826 = call ptr @myl_qbe_heap(ptr %p825) nomerge, !dbg !110
  %calladdr827 = ptrtoint ptr %call826 to i64
  store i64 %calladdr827, ptr %slot33, align 8
  %v828 = load i64, ptr %slot1, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %call830 = call i64 @myl_qbe_region_mark(ptr %p829) nomerge, !dbg !110
  store i64 %call830, ptr %slot34, align 8
  %v831 = load i64, ptr %slot4, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i32 0, ptr %p832, align 4, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot5, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i32 0, ptr %p834, align 4, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot6, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i32 0, ptr %p836, align 4, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot7, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot8, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 0, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot9, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i32 0, ptr %p842, align 4, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot10, align 8
  %p844 = inttoptr i64 %v843 to ptr
  store i32 0, ptr %p844, align 4, !alias.scope !3, !noalias !4
  %v845 = load i64, ptr %slot11, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot12, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i32 0, ptr %p848, align 4, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot13, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i32 0, ptr %p850, align 4, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot14, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i32 0, ptr %p852, align 4, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot15, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i32 0, ptr %p854, align 4, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot16, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i32 0, ptr %p856, align 4, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot17, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i32 0, ptr %p858, align 4, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot18, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i32 0, ptr %p860, align 4, !alias.scope !3, !noalias !4
  %v861 = load i64, ptr %slot5, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i32 2, ptr %p862, align 4, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot7, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i32 2, ptr %p864, align 4, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot9, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i32 2, ptr %p866, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v867 = load i64, ptr %slot29, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i64 0, ptr %p868, align 8, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot29, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i64, ptr %p870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld871, ptr %slot35, align 8
  %v872 = load i64, ptr %slot35, align 8
  %cmp873 = icmp sge i64 %v872, 0
  %cv874 = zext i1 %cmp873 to i64
  store i64 %cv874, ptr %slot36, align 8
  %v875 = load i64, ptr %slot36, align 8
  %cond876 = icmp ne i64 %v875, 0
  br i1 %cond876, label %bb_success5, label %bb_failed5
bb_failed5:
  %v877 = load i64, ptr %slot1, align 8
  %p878 = inttoptr i64 %v877 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p878) nomerge, !dbg !112
  unreachable
bb_success5:
  %v879 = load i64, ptr %slot33, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %p881 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v882 = load i64, ptr %slot35, align 8
  %call883 = call ptr @myl_native_list_new(ptr %p880, ptr %p881, i64 %v882) nomerge, !dbg !112
  %calladdr884 = ptrtoint ptr %call883 to i64
  store i64 %calladdr884, ptr %slot37, align 8
  %v885 = load i64, ptr %slot37, align 8
  %cond886 = icmp ne i64 %v885, 0
  br i1 %cond886, label %bb_success7, label %bb_failed7
bb_failed7:
  %v887 = load i64, ptr %slot1, align 8
  %p888 = inttoptr i64 %v887 to ptr
  call void @myl_qbe_fail_allocation(ptr %p888) nomerge, !dbg !112
  unreachable
bb_success7:
  %v889 = load i64, ptr %slot37, align 8
  %v890 = load i64, ptr %slot29, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i64 %v889, ptr %p891, align 8, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot29, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %ld894 = load i64, ptr %p893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld894, ptr %slot38, align 8
  %v895 = load i64, ptr %slot38, align 8
  %v896 = load i64, ptr %slot22, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i64 %v895, ptr %p897, align 8, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot22, align 8
  store i64 %v898, ptr %slot39, align 8
  %v899 = load i64, ptr %slot25, align 8
  store i64 %v899, ptr %slot40, align 8
  %v900 = load i64, ptr %slot39, align 8
  %v901 = load i64, ptr %slot40, align 8
  %p902 = inttoptr i64 %v900 to ptr
  %p903 = inttoptr i64 %v901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p903, ptr %p902, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot17, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 2, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot16, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 1, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot19, align 8
  store i64 %v908, ptr %slot41, align 8
  %v909 = load i64, ptr %slot25, align 8
  store i64 %v909, ptr %slot42, align 8
  %v910 = load i64, ptr %slot42, align 8
  %v911 = load i64, ptr %slot41, align 8
  %p912 = inttoptr i64 %v910 to ptr
  %p913 = inttoptr i64 %v911 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p913, ptr %p912, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot11, align 8
  %p915 = inttoptr i64 %v914 to ptr
  store i32 2, ptr %p915, align 4, !alias.scope !3, !noalias !4
  %v916 = load i64, ptr %slot17, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %ld918 = load i32, ptr %p917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld918, ptr %slot43, align 8
  %v919 = load i32, ptr %slot43, align 8
  %v920 = load i64, ptr %slot11, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 %v919, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot16, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i32 0, ptr %p923, align 4, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot10, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i32 1, ptr %p925, align 4, !alias.scope !3, !noalias !4
  %v926 = load i64, ptr %slot41, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i64, ptr %p927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld928, ptr %slot44, align 8
  %v929 = load i64, ptr %slot44, align 8
  %v930 = load i64, ptr %slot29, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i64 %v929, ptr %p931, align 8, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot29, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %ld934 = load i64, ptr %p933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld934, ptr %slot45, align 8
  %v935 = load i64, ptr %slot45, align 8
  %v936 = load i64, ptr %slot22, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i64 %v935, ptr %p937, align 8, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot22, align 8
  store i64 %v938, ptr %slot46, align 8
  %v939 = load i64, ptr %slot10, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %ld941 = load i32, ptr %p940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld941, ptr %slot47, align 8
  %v942 = load i64, ptr %slot11, align 8
  %p943 = inttoptr i64 %v942 to ptr
  %ld944 = load i32, ptr %p943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld944, ptr %slot48, align 8
  %v945 = load i32, ptr %slot48, align 8
  %op946 = and i32 %v945, 24
  store i32 %op946, ptr %slot48, align 8
  %v947 = load i32, ptr %slot48, align 8
  %cmp948 = icmp eq i32 %v947, 0
  %cv949 = zext i1 %cmp948 to i32
  store i32 %cv949, ptr %slot49, align 8
  %v950 = load i32, ptr %slot47, align 8
  %v951 = load i32, ptr %slot49, align 8
  %op952 = and i32 %v950, %v951
  store i32 %op952, ptr %slot50, align 8
  %v953 = load i32, ptr %slot50, align 8
  %cv954 = zext i32 %v953 to i64
  %cond955 = icmp ne i64 %cv954, 0
  br i1 %cond955, label %bb_rcprivateown30, label %bb_rcprivateloan30
bb_rcprivateown30:
  %v956 = load i64, ptr %slot25, align 8
  store i64 %v956, ptr %slot51, align 8
  %v957 = load i64, ptr %slot34, align 8
  store i64 %v957, ptr %slot52, align 8
  %v958 = load i64, ptr %slot46, align 8
  %v959 = load i64, ptr %slot51, align 8
  %op960 = sub i64 %v958, %v959
  store i64 %op960, ptr %slot53, align 8
  %v961 = load i64, ptr %slot51, align 8
  %v962 = load i64, ptr %slot46, align 8
  %op963 = sub i64 %v961, %v962
  store i64 %op963, ptr %slot54, align 8
  %v964 = load i64, ptr %slot53, align 8
  %cmp965 = icmp ult i64 %v964, 8
  %cv966 = zext i1 %cmp965 to i32
  store i32 %cv966, ptr %slot55, align 8
  %v967 = load i64, ptr %slot54, align 8
  %cmp968 = icmp ult i64 %v967, 8
  %cv969 = zext i1 %cmp968 to i32
  store i32 %cv969, ptr %slot56, align 8
  %v970 = load i32, ptr %slot55, align 8
  %v971 = load i32, ptr %slot56, align 8
  %op972 = or i32 %v970, %v971
  store i32 %op972, ptr %slot57, align 8
  %v973 = load i32, ptr %slot57, align 8
  %cv974 = zext i32 %v973 to i64
  %cond975 = icmp ne i64 %cv974, 0
  br i1 %cond975, label %bb_rcmoveslow33, label %bb_rcmovecheck33
bb_rcmovecheck33:
  %v976 = load i64, ptr %slot46, align 8
  %p978 = inttoptr i64 %v976 to ptr
  %gep979 = getelementptr i8, ptr %p978, i64 0
  %op977 = ptrtoint ptr %gep979 to i64
  store i64 %op977, ptr %slot58, align 8
  %v980 = load i64, ptr %slot58, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i64, ptr %p981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld982, ptr %slot59, align 8
  %v983 = load i64, ptr %slot59, align 8
  %cmp984 = icmp ne i64 %v983, 0
  %cv985 = zext i1 %cmp984 to i32
  store i32 %cv985, ptr %slot60, align 8
  %v986 = load i32, ptr %slot60, align 8
  %cv987 = zext i32 %v986 to i64
  %cond988 = icmp ne i64 %cv987, 0
  br i1 %cond988, label %bb_rcmoveheader41, label %bb_rcmovenext41
bb_rcmoveheader41:
  %v989 = load i64, ptr %slot59, align 8
  %op990 = sub i64 %v989, 16
  store i64 %op990, ptr %slot61, align 8
  %v991 = load i64, ptr %slot59, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %rgep993 = getelementptr i8, ptr %p992, i64 -16
  %ld994 = load i64, ptr %rgep993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld994, ptr %slot62, align 8
  %v995 = load i64, ptr %slot62, align 8
  %op996 = and i64 %v995, 5764607523034234881
  store i64 %op996, ptr %slot63, align 8
  %v997 = load i64, ptr %slot63, align 8
  %cmp998 = icmp ne i64 %v997, 0
  %cv999 = zext i1 %cmp998 to i32
  store i32 %cv999, ptr %slot64, align 8
  %v1000 = load i32, ptr %slot64, align 8
  %cv1001 = zext i32 %v1000 to i64
  %cond1002 = icmp ne i64 %cv1001, 0
  br i1 %cond1002, label %bb_rcmoveslow33, label %bb_rcmovenext41
bb_rcmovenext41:
  %v1003 = load i64, ptr %slot46, align 8
  %v1004 = load i64, ptr %slot51, align 8
  %p1005 = inttoptr i64 %v1003 to ptr
  %p1006 = inttoptr i64 %v1004 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1006, ptr %p1005, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot46, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  store i64 0, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved33
bb_rcmoveslow33:
  %v1009 = load i64, ptr %slot33, align 8
  %v1010 = load i64, ptr %slot51, align 8
  %v1011 = load i64, ptr %slot46, align 8
  %v1012 = load i64, ptr %slot52, align 8
  %cv1013 = trunc i64 %v1012 to i32
  %call1014 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1009, i64 %v1010, i64 %v1011, i32 %cv1013) nomerge, !dbg !114
  store i32 %call1014, ptr %slot65, align 8
  %v1015 = load i32, ptr %slot65, align 8
  %cv1016 = zext i32 %v1015 to i64
  %cond1017 = icmp ne i64 %cv1016, 0
  br i1 %cond1017, label %bb_rcsuccess48, label %bb_rcfailure48
bb_rcfailure48:
  %v1018 = load i64, ptr %slot33, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %call1020 = call i32 @myl_rc_take_failure(ptr %p1019) nomerge, !dbg !114
  store i32 %call1020, ptr %slot66, align 8
  %v1021 = load i64, ptr %slot1, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %v1023 = load i32, ptr %slot66, align 8
  %call1024 = call i32 @myl_qbe_rc_status(ptr %p1022, i32 %v1023) nomerge, !dbg !114
  store i32 %call1024, ptr %slot67, align 8
  br label %bb_failure
bb_rcsuccess48:
  br label %bb_rcmoved33
bb_rcmoved33:
  %v1025 = load i64, ptr %slot10, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i32 0, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot17, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i32 2, ptr %p1028, align 4, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot16, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i32 1, ptr %p1030, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared30
bb_rcprivateloan30:
  %v1031 = load i64, ptr %slot10, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  %ld1033 = load i32, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1033, ptr %slot68, align 8
  %v1034 = load i64, ptr %slot11, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i32, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1036, ptr %slot69, align 8
  %v1037 = load i32, ptr %slot69, align 8
  %cmp1038 = icmp eq i32 %v1037, 16
  %cv1039 = zext i1 %cmp1038 to i32
  store i32 %cv1039, ptr %slot70, align 8
  %v1040 = load i32, ptr %slot70, align 8
  %v1041 = load i32, ptr %slot68, align 8
  %op1042 = and i32 %v1040, %v1041
  store i32 %op1042, ptr %slot70, align 8
  %v1043 = load i32, ptr %slot70, align 8
  %cv1044 = zext i32 %v1043 to i64
  %cond1045 = icmp ne i64 %cv1044, 0
  br i1 %cond1045, label %bb_rcprivatemove30, label %bb_rcprivatenew30
bb_rcprivatemove30:
  %v1046 = load i64, ptr %slot25, align 8
  store i64 %v1046, ptr %slot71, align 8
  %v1047 = load i64, ptr %slot46, align 8
  %v1048 = load i64, ptr %slot71, align 8
  %p1049 = inttoptr i64 %v1047 to ptr
  %p1050 = inttoptr i64 %v1048 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1050, ptr %p1049, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot46, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  store i64 0, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  %v1053 = load i64, ptr %slot17, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 2, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot17, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  store i32 16, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot16, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 1, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot10, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  store i32 0, ptr %p1060, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared30
bb_rcprivatenew30:
  %v1061 = load i64, ptr %slot25, align 8
  store i64 %v1061, ptr %slot72, align 8
  %v1062 = load i64, ptr %slot46, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  %ld1064 = load i64, ptr %p1063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1064, ptr %slot73, align 8
  %v1065 = load i64, ptr %slot73, align 8
  %cmp1066 = icmp ne i64 %v1065, 0
  %cv1067 = zext i1 %cmp1066 to i32
  store i32 %cv1067, ptr %slot74, align 8
  %v1068 = load i32, ptr %slot74, align 8
  %cv1069 = zext i32 %v1068 to i64
  %cond1070 = icmp ne i64 %cv1069, 0
  br i1 %cond1070, label %bb_rcgnn66, label %bb_rcgstore66
bb_rcgnn66:
  %v1071 = load i64, ptr %slot73, align 8
  %op1072 = sub i64 %v1071, 16
  store i64 %op1072, ptr %slot75, align 8
  %v1073 = load i64, ptr %slot73, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %rgep1075 = getelementptr i8, ptr %p1074, i64 -16
  %ld1076 = load i64, ptr %rgep1075, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1076, ptr %slot76, align 8
  %v1077 = load i64, ptr %slot76, align 8
  %op1078 = and i64 %v1077, 4611686018427387906
  store i64 %op1078, ptr %slot77, align 8
  %v1079 = load i64, ptr %slot77, align 8
  %cmp1080 = icmp ne i64 %v1079, 0
  %cv1081 = zext i1 %cmp1080 to i32
  store i32 %cv1081, ptr %slot78, align 8
  %v1082 = load i32, ptr %slot78, align 8
  %cv1083 = zext i32 %v1082 to i64
  %cond1084 = icmp ne i64 %cv1083, 0
  br i1 %cond1084, label %bb_rcgstore66, label %bb_rcginc66
bb_rcginc66:
  %v1085 = load i64, ptr %slot73, align 8
  %op1086 = sub i64 %v1085, 24
  store i64 %op1086, ptr %slot79, align 8
  %v1087 = load i64, ptr %slot73, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %rgep1089 = getelementptr i8, ptr %p1088, i64 -24
  %ld1090 = load i64, ptr %rgep1089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1090, ptr %slot80, align 8
  %v1091 = load i64, ptr %slot80, align 8
  %op1092 = add i64 %v1091, 1
  store i64 %op1092, ptr %slot81, align 8
  %v1093 = load i64, ptr %slot81, align 8
  %cmp1094 = icmp eq i64 %v1093, 0
  %cv1095 = zext i1 %cmp1094 to i32
  store i32 %cv1095, ptr %slot82, align 8
  %v1096 = load i32, ptr %slot82, align 8
  %cv1097 = zext i32 %v1096 to i64
  %cond1098 = icmp ne i64 %cv1097, 0
  br i1 %cond1098, label %bb_rcglimit66, label %bb_rcgcapacity66
bb_rcglimit66:
  %v1099 = load i64, ptr %slot1, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %call1101 = call i32 @myl_qbe_rc_status(ptr %p1100, i32 2) nomerge, !dbg !114
  store i32 %call1101, ptr %slot83, align 8
  br label %bb_failure
bb_rcgcapacity66:
  %v1102 = load i64, ptr %slot81, align 8
  %v1103 = load i64, ptr %slot73, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %rgep1105 = getelementptr i8, ptr %p1104, i64 -24
  store i64 %v1102, ptr %rgep1105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore66
bb_rcgstore66:
  %v1106 = load i64, ptr %slot73, align 8
  %v1107 = load i64, ptr %slot72, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  store i64 %v1106, ptr %p1108, align 8, !alias.scope !3, !noalias !4
  %v1109 = load i64, ptr %slot17, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  store i32 2, ptr %p1110, align 4, !alias.scope !3, !noalias !4
  %v1111 = load i64, ptr %slot17, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i32 16, ptr %p1112, align 4, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot16, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i32 1, ptr %p1114, align 4, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot10, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %ld1117 = load i32, ptr %p1116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1117, ptr %slot84, align 8
  %v1118 = load i32, ptr %slot84, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1121 = load i64, ptr %slot10, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  store i32 0, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  %v1123 = load i64, ptr %slot19, align 8
  store i64 %v1123, ptr %slot85, align 8
  %v1124 = load i64, ptr %slot11, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %ld1126 = load i32, ptr %p1125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1126, ptr %slot86, align 8
  %v1127 = load i32, ptr %slot86, align 8
  %op1128 = and i32 %v1127, 28
  store i32 %op1128, ptr %slot87, align 8
  %v1129 = load i32, ptr %slot87, align 8
  %cv1130 = zext i32 %v1129 to i64
  %cond1131 = icmp ne i64 %cv1130, 0
  br i1 %cond1131, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1132 = load i64, ptr %slot33, align 8
  store i64 %v1132, ptr %slot88, align 8
  %v1133 = load i64, ptr %slot85, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %ld1135 = load i64, ptr %p1134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1135, ptr %slot89, align 8
  %v1136 = load i64, ptr %slot89, align 8
  %cmp1137 = icmp ne i64 %v1136, 0
  %cv1138 = zext i1 %cmp1137 to i32
  store i32 %cv1138, ptr %slot90, align 8
  %v1139 = load i32, ptr %slot90, align 8
  %cv1140 = zext i32 %v1139 to i64
  %cond1141 = icmp ne i64 %cv1140, 0
  br i1 %cond1141, label %bb_rcgnn98, label %bb_rcgdone98
bb_rcgnn98:
  %v1142 = load i64, ptr %slot89, align 8
  %op1143 = sub i64 %v1142, 16
  store i64 %op1143, ptr %slot91, align 8
  %v1144 = load i64, ptr %slot89, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %rgep1146 = getelementptr i8, ptr %p1145, i64 -16
  %ld1147 = load i64, ptr %rgep1146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1147, ptr %slot92, align 8
  %v1148 = load i64, ptr %slot92, align 8
  %op1149 = and i64 %v1148, 4611686018427387906
  store i64 %op1149, ptr %slot93, align 8
  %v1150 = load i64, ptr %slot93, align 8
  %cmp1151 = icmp ne i64 %v1150, 0
  %cv1152 = zext i1 %cmp1151 to i32
  store i32 %cv1152, ptr %slot94, align 8
  %v1153 = load i32, ptr %slot94, align 8
  %cv1154 = zext i32 %v1153 to i64
  %cond1155 = icmp ne i64 %cv1154, 0
  br i1 %cond1155, label %bb_rcgclear98, label %bb_rcgcounted98
bb_rcgcounted98:
  %v1156 = load i64, ptr %slot89, align 8
  %op1157 = sub i64 %v1156, 24
  store i64 %op1157, ptr %slot95, align 8
  %v1158 = load i64, ptr %slot89, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %rgep1160 = getelementptr i8, ptr %p1159, i64 -24
  %ld1161 = load i64, ptr %rgep1160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1161, ptr %slot96, align 8
  %v1162 = load i64, ptr %slot96, align 8
  %op1163 = sub i64 %v1162, 1
  store i64 %op1163, ptr %slot97, align 8
  %v1164 = load i64, ptr %slot97, align 8
  %cmp1165 = icmp eq i64 %v1164, 0
  %cv1166 = zext i1 %cmp1165 to i32
  store i32 %cv1166, ptr %slot98, align 8
  %v1167 = load i32, ptr %slot98, align 8
  %cv1168 = zext i32 %v1167 to i64
  %cond1169 = icmp ne i64 %cv1168, 0
  br i1 %cond1169, label %bb_rcglast98, label %bb_rcgdec98
bb_rcglast98:
  %v1170 = load i64, ptr %slot89, align 8
  %op1171 = sub i64 %v1170, 32
  store i64 %op1171, ptr %slot99, align 8
  %v1172 = load i64, ptr %slot89, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  %rgep1174 = getelementptr i8, ptr %p1173, i64 -32
  %ld1175 = load i64, ptr %rgep1174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1175, ptr %slot100, align 8
  %v1176 = load i64, ptr %slot100, align 8
  %cmp1177 = icmp ne i64 %v1176, 0
  %cv1178 = zext i1 %cmp1177 to i32
  store i32 %cv1178, ptr %slot101, align 8
  %v1179 = load i32, ptr %slot101, align 8
  %cv1180 = zext i32 %v1179 to i64
  %cond1181 = icmp ne i64 %cv1180, 0
  br i1 %cond1181, label %bb_rcgdec98, label %bb_rcgslow98
bb_rcgslow98:
  %v1182 = load i64, ptr %slot88, align 8
  %v1183 = load i64, ptr %slot85, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1182, i64 %v1183) nomerge, !dbg !114
  br label %bb_rcgdone98
bb_rcgdec98:
  %v1184 = load i64, ptr %slot97, align 8
  %v1185 = load i64, ptr %slot89, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %rgep1187 = getelementptr i8, ptr %p1186, i64 -24
  store i64 %v1184, ptr %rgep1187, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear98
bb_rcgclear98:
  %v1188 = load i64, ptr %slot85, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i64 0, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone98
bb_rcgdone98:
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1190 = load i64, ptr %slot33, align 8
  store i64 %v1190, ptr %slot102, align 8
  %v1191 = load i64, ptr %slot85, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i64, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1193, ptr %slot103, align 8
  %v1194 = load i64, ptr %slot103, align 8
  %cmp1195 = icmp ne i64 %v1194, 0
  %cv1196 = zext i1 %cmp1195 to i32
  store i32 %cv1196, ptr %slot104, align 8
  %v1197 = load i32, ptr %slot104, align 8
  %cv1198 = zext i32 %v1197 to i64
  %cond1199 = icmp ne i64 %cv1198, 0
  br i1 %cond1199, label %bb_rcgnn113, label %bb_rcgdone113
bb_rcgnn113:
  %v1200 = load i64, ptr %slot103, align 8
  %op1201 = sub i64 %v1200, 16
  store i64 %op1201, ptr %slot105, align 8
  %v1202 = load i64, ptr %slot103, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %rgep1204 = getelementptr i8, ptr %p1203, i64 -16
  %ld1205 = load i64, ptr %rgep1204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1205, ptr %slot106, align 8
  %v1206 = load i64, ptr %slot106, align 8
  %op1207 = and i64 %v1206, 4611686018427387906
  store i64 %op1207, ptr %slot107, align 8
  %v1208 = load i64, ptr %slot107, align 8
  %cmp1209 = icmp ne i64 %v1208, 0
  %cv1210 = zext i1 %cmp1209 to i32
  store i32 %cv1210, ptr %slot108, align 8
  %v1211 = load i32, ptr %slot108, align 8
  %cv1212 = zext i32 %v1211 to i64
  %cond1213 = icmp ne i64 %cv1212, 0
  br i1 %cond1213, label %bb_rcgclear113, label %bb_rcgcounted113
bb_rcgcounted113:
  %v1214 = load i64, ptr %slot103, align 8
  %op1215 = sub i64 %v1214, 32
  store i64 %op1215, ptr %slot109, align 8
  %v1216 = load i64, ptr %slot103, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %rgep1218 = getelementptr i8, ptr %p1217, i64 -32
  %ld1219 = load i64, ptr %rgep1218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1219, ptr %slot110, align 8
  %v1220 = load i64, ptr %slot110, align 8
  %op1221 = sub i64 %v1220, 1
  store i64 %op1221, ptr %slot111, align 8
  %v1222 = load i64, ptr %slot111, align 8
  %cmp1223 = icmp eq i64 %v1222, 0
  %cv1224 = zext i1 %cmp1223 to i32
  store i32 %cv1224, ptr %slot112, align 8
  %v1225 = load i32, ptr %slot112, align 8
  %cv1226 = zext i32 %v1225 to i64
  %cond1227 = icmp ne i64 %cv1226, 0
  br i1 %cond1227, label %bb_rcglast113, label %bb_rcgdec113
bb_rcglast113:
  %v1228 = load i64, ptr %slot103, align 8
  %op1229 = sub i64 %v1228, 24
  store i64 %op1229, ptr %slot113, align 8
  %v1230 = load i64, ptr %slot103, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %rgep1232 = getelementptr i8, ptr %p1231, i64 -24
  %ld1233 = load i64, ptr %rgep1232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1233, ptr %slot114, align 8
  %v1234 = load i64, ptr %slot114, align 8
  %cmp1235 = icmp ne i64 %v1234, 0
  %cv1236 = zext i1 %cmp1235 to i32
  store i32 %cv1236, ptr %slot115, align 8
  %v1237 = load i32, ptr %slot115, align 8
  %cv1238 = zext i32 %v1237 to i64
  %cond1239 = icmp ne i64 %cv1238, 0
  br i1 %cond1239, label %bb_rcgdec113, label %bb_rcgslow113
bb_rcgslow113:
  %v1240 = load i64, ptr %slot102, align 8
  %v1241 = load i64, ptr %slot85, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1240, i64 %v1241) nomerge, !dbg !114
  br label %bb_rcgdone113
bb_rcgdec113:
  %v1242 = load i64, ptr %slot111, align 8
  %v1243 = load i64, ptr %slot103, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %rgep1245 = getelementptr i8, ptr %p1244, i64 -32
  store i64 %v1242, ptr %rgep1245, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear113
bb_rcgclear113:
  %v1246 = load i64, ptr %slot85, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i64 0, ptr %p1247, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone113
bb_rcgdone113:
  br label %bb_rcslotdone82
bb_rcslotdone82:
  br label %bb_rcprivateprepared30
bb_rcprivateprepared30:
  %v1248 = load i64, ptr %slot4, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  %ld1250 = load i32, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1250, ptr %slot116, align 8
  %v1251 = load i32, ptr %slot116, align 8
  %cv1252 = zext i32 %v1251 to i64
  %cond1253 = icmp ne i64 %cv1252, 0
  br i1 %cond1253, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v1254 = load i64, ptr %slot4, align 8
  %p1255 = inttoptr i64 %v1254 to ptr
  store i32 0, ptr %p1255, align 4, !alias.scope !3, !noalias !4
  %v1256 = load i64, ptr %slot26, align 8
  store i64 %v1256, ptr %slot117, align 8
  %v1257 = load i64, ptr %slot5, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i32, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1259, ptr %slot118, align 8
  %v1260 = load i32, ptr %slot118, align 8
  %op1261 = and i32 %v1260, 28
  store i32 %op1261, ptr %slot119, align 8
  %v1262 = load i32, ptr %slot119, align 8
  %cv1263 = zext i32 %v1262 to i64
  %cond1264 = icmp ne i64 %cv1263, 0
  br i1 %cond1264, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v1265 = load i64, ptr %slot33, align 8
  store i64 %v1265, ptr %slot120, align 8
  %v1266 = load i64, ptr %slot117, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i64, ptr %p1267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1268, ptr %slot121, align 8
  %v1269 = load i64, ptr %slot121, align 8
  %cmp1270 = icmp ne i64 %v1269, 0
  %cv1271 = zext i1 %cmp1270 to i32
  store i32 %cv1271, ptr %slot122, align 8
  %v1272 = load i32, ptr %slot122, align 8
  %cv1273 = zext i32 %v1272 to i64
  %cond1274 = icmp ne i64 %cv1273, 0
  br i1 %cond1274, label %bb_rcgnn136, label %bb_rcgdone136
bb_rcgnn136:
  %v1275 = load i64, ptr %slot121, align 8
  %op1276 = sub i64 %v1275, 16
  store i64 %op1276, ptr %slot123, align 8
  %v1277 = load i64, ptr %slot121, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  %rgep1279 = getelementptr i8, ptr %p1278, i64 -16
  %ld1280 = load i64, ptr %rgep1279, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1280, ptr %slot124, align 8
  %v1281 = load i64, ptr %slot124, align 8
  %op1282 = and i64 %v1281, 4611686018427387906
  store i64 %op1282, ptr %slot125, align 8
  %v1283 = load i64, ptr %slot125, align 8
  %cmp1284 = icmp ne i64 %v1283, 0
  %cv1285 = zext i1 %cmp1284 to i32
  store i32 %cv1285, ptr %slot126, align 8
  %v1286 = load i32, ptr %slot126, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcgclear136, label %bb_rcgcounted136
bb_rcgcounted136:
  %v1289 = load i64, ptr %slot121, align 8
  %op1290 = sub i64 %v1289, 24
  store i64 %op1290, ptr %slot127, align 8
  %v1291 = load i64, ptr %slot121, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %rgep1293 = getelementptr i8, ptr %p1292, i64 -24
  %ld1294 = load i64, ptr %rgep1293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1294, ptr %slot128, align 8
  %v1295 = load i64, ptr %slot128, align 8
  %op1296 = sub i64 %v1295, 1
  store i64 %op1296, ptr %slot129, align 8
  %v1297 = load i64, ptr %slot129, align 8
  %cmp1298 = icmp eq i64 %v1297, 0
  %cv1299 = zext i1 %cmp1298 to i32
  store i32 %cv1299, ptr %slot130, align 8
  %v1300 = load i32, ptr %slot130, align 8
  %cv1301 = zext i32 %v1300 to i64
  %cond1302 = icmp ne i64 %cv1301, 0
  br i1 %cond1302, label %bb_rcglast136, label %bb_rcgdec136
bb_rcglast136:
  %v1303 = load i64, ptr %slot121, align 8
  %op1304 = sub i64 %v1303, 32
  store i64 %op1304, ptr %slot131, align 8
  %v1305 = load i64, ptr %slot121, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %rgep1307 = getelementptr i8, ptr %p1306, i64 -32
  %ld1308 = load i64, ptr %rgep1307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1308, ptr %slot132, align 8
  %v1309 = load i64, ptr %slot132, align 8
  %cmp1310 = icmp ne i64 %v1309, 0
  %cv1311 = zext i1 %cmp1310 to i32
  store i32 %cv1311, ptr %slot133, align 8
  %v1312 = load i32, ptr %slot133, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rcgdec136, label %bb_rcgslow136
bb_rcgslow136:
  %v1315 = load i64, ptr %slot120, align 8
  %v1316 = load i64, ptr %slot117, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1315, i64 %v1316) nomerge, !dbg !114
  br label %bb_rcgdone136
bb_rcgdec136:
  %v1317 = load i64, ptr %slot129, align 8
  %v1318 = load i64, ptr %slot121, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %rgep1320 = getelementptr i8, ptr %p1319, i64 -24
  store i64 %v1317, ptr %rgep1320, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear136
bb_rcgclear136:
  %v1321 = load i64, ptr %slot117, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i64 0, ptr %p1322, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone136
bb_rcgdone136:
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v1323 = load i64, ptr %slot33, align 8
  store i64 %v1323, ptr %slot134, align 8
  %v1324 = load i64, ptr %slot117, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i64, ptr %p1325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1326, ptr %slot135, align 8
  %v1327 = load i64, ptr %slot135, align 8
  %cmp1328 = icmp ne i64 %v1327, 0
  %cv1329 = zext i1 %cmp1328 to i32
  store i32 %cv1329, ptr %slot136, align 8
  %v1330 = load i32, ptr %slot136, align 8
  %cv1331 = zext i32 %v1330 to i64
  %cond1332 = icmp ne i64 %cv1331, 0
  br i1 %cond1332, label %bb_rcgnn151, label %bb_rcgdone151
bb_rcgnn151:
  %v1333 = load i64, ptr %slot135, align 8
  %op1334 = sub i64 %v1333, 16
  store i64 %op1334, ptr %slot137, align 8
  %v1335 = load i64, ptr %slot135, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  %rgep1337 = getelementptr i8, ptr %p1336, i64 -16
  %ld1338 = load i64, ptr %rgep1337, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1338, ptr %slot138, align 8
  %v1339 = load i64, ptr %slot138, align 8
  %op1340 = and i64 %v1339, 4611686018427387906
  store i64 %op1340, ptr %slot139, align 8
  %v1341 = load i64, ptr %slot139, align 8
  %cmp1342 = icmp ne i64 %v1341, 0
  %cv1343 = zext i1 %cmp1342 to i32
  store i32 %cv1343, ptr %slot140, align 8
  %v1344 = load i32, ptr %slot140, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcgclear151, label %bb_rcgcounted151
bb_rcgcounted151:
  %v1347 = load i64, ptr %slot135, align 8
  %op1348 = sub i64 %v1347, 32
  store i64 %op1348, ptr %slot141, align 8
  %v1349 = load i64, ptr %slot135, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  %rgep1351 = getelementptr i8, ptr %p1350, i64 -32
  %ld1352 = load i64, ptr %rgep1351, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1352, ptr %slot142, align 8
  %v1353 = load i64, ptr %slot142, align 8
  %op1354 = sub i64 %v1353, 1
  store i64 %op1354, ptr %slot143, align 8
  %v1355 = load i64, ptr %slot143, align 8
  %cmp1356 = icmp eq i64 %v1355, 0
  %cv1357 = zext i1 %cmp1356 to i32
  store i32 %cv1357, ptr %slot144, align 8
  %v1358 = load i32, ptr %slot144, align 8
  %cv1359 = zext i32 %v1358 to i64
  %cond1360 = icmp ne i64 %cv1359, 0
  br i1 %cond1360, label %bb_rcglast151, label %bb_rcgdec151
bb_rcglast151:
  %v1361 = load i64, ptr %slot135, align 8
  %op1362 = sub i64 %v1361, 24
  store i64 %op1362, ptr %slot145, align 8
  %v1363 = load i64, ptr %slot135, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %rgep1365 = getelementptr i8, ptr %p1364, i64 -24
  %ld1366 = load i64, ptr %rgep1365, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1366, ptr %slot146, align 8
  %v1367 = load i64, ptr %slot146, align 8
  %cmp1368 = icmp ne i64 %v1367, 0
  %cv1369 = zext i1 %cmp1368 to i32
  store i32 %cv1369, ptr %slot147, align 8
  %v1370 = load i32, ptr %slot147, align 8
  %cv1371 = zext i32 %v1370 to i64
  %cond1372 = icmp ne i64 %cv1371, 0
  br i1 %cond1372, label %bb_rcgdec151, label %bb_rcgslow151
bb_rcgslow151:
  %v1373 = load i64, ptr %slot134, align 8
  %v1374 = load i64, ptr %slot117, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1373, i64 %v1374) nomerge, !dbg !114
  br label %bb_rcgdone151
bb_rcgdec151:
  %v1375 = load i64, ptr %slot143, align 8
  %v1376 = load i64, ptr %slot135, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  %rgep1378 = getelementptr i8, ptr %p1377, i64 -32
  store i64 %v1375, ptr %rgep1378, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear151
bb_rcgclear151:
  %v1379 = load i64, ptr %slot117, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i64 0, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone151
bb_rcgdone151:
  br label %bb_rcslotdone120
bb_rcslotdone120:
  %v1381 = load i64, ptr %slot26, align 8
  store i64 %v1381, ptr %slot148, align 8
  %v1382 = load i64, ptr %slot25, align 8
  store i64 %v1382, ptr %slot149, align 8
  %v1383 = load i64, ptr %slot149, align 8
  %v1384 = load i64, ptr %slot148, align 8
  %p1385 = inttoptr i64 %v1383 to ptr
  %p1386 = inttoptr i64 %v1384 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1386, ptr %p1385, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot16, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  store i32 0, ptr %p1388, align 4, !alias.scope !3, !noalias !4
  %v1389 = load i64, ptr %slot5, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  store i32 2, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  %v1391 = load i64, ptr %slot17, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i32, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1393, ptr %slot150, align 8
  %v1394 = load i32, ptr %slot150, align 8
  %v1395 = load i64, ptr %slot5, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i32 %v1394, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot4, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 1, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot26, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i64, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1401, ptr %slot151, align 8
  %v1402 = load i64, ptr %slot151, align 8
  %v1403 = load i64, ptr %slot29, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 %v1402, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  %v1405 = load i64, ptr %slot30, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i64 0, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot30, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  %ld1409 = load i64, ptr %p1408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1409, ptr %slot152, align 8
  %v1410 = load i64, ptr %slot152, align 8
  %cmp1411 = icmp sge i64 %v1410, 0
  %cv1412 = zext i1 %cmp1411 to i64
  store i64 %cv1412, ptr %slot153, align 8
  %v1413 = load i64, ptr %slot153, align 8
  %cond1414 = icmp ne i64 %v1413, 0
  br i1 %cond1414, label %bb_success165, label %bb_failed165
bb_failed165:
  %v1415 = load i64, ptr %slot1, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1416) nomerge, !dbg !116
  unreachable
bb_success165:
  %v1417 = load i64, ptr %slot33, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %p1419 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v1420 = load i64, ptr %slot152, align 8
  %call1421 = call ptr @myl_native_list_new(ptr %p1418, ptr %p1419, i64 %v1420) nomerge, !dbg !116
  %calladdr1422 = ptrtoint ptr %call1421 to i64
  store i64 %calladdr1422, ptr %slot154, align 8
  %v1423 = load i64, ptr %slot154, align 8
  %cond1424 = icmp ne i64 %v1423, 0
  br i1 %cond1424, label %bb_success167, label %bb_failed167
bb_failed167:
  %v1425 = load i64, ptr %slot1, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1426) nomerge, !dbg !116
  unreachable
bb_success167:
  %v1427 = load i64, ptr %slot154, align 8
  %v1428 = load i64, ptr %slot30, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i64 %v1427, ptr %p1429, align 8, !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot30, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i64, ptr %p1431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1432, ptr %slot155, align 8
  %v1433 = load i64, ptr %slot155, align 8
  %v1434 = load i64, ptr %slot23, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  store i64 %v1433, ptr %p1435, align 8, !alias.scope !3, !noalias !4
  %v1436 = load i64, ptr %slot23, align 8
  store i64 %v1436, ptr %slot156, align 8
  %v1437 = load i64, ptr %slot25, align 8
  store i64 %v1437, ptr %slot157, align 8
  %v1438 = load i64, ptr %slot156, align 8
  %v1439 = load i64, ptr %slot157, align 8
  %p1440 = inttoptr i64 %v1438 to ptr
  %p1441 = inttoptr i64 %v1439 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1441, ptr %p1440, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot17, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i32 2, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot16, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 1, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot20, align 8
  store i64 %v1446, ptr %slot158, align 8
  %v1447 = load i64, ptr %slot25, align 8
  store i64 %v1447, ptr %slot159, align 8
  %v1448 = load i64, ptr %slot159, align 8
  %v1449 = load i64, ptr %slot158, align 8
  %p1450 = inttoptr i64 %v1448 to ptr
  %p1451 = inttoptr i64 %v1449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1451, ptr %p1450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot13, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 2, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot17, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i32, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1456, ptr %slot160, align 8
  %v1457 = load i32, ptr %slot160, align 8
  %v1458 = load i64, ptr %slot13, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 %v1457, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot16, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  store i32 0, ptr %p1461, align 4, !alias.scope !3, !noalias !4
  %v1462 = load i64, ptr %slot12, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i32 1, ptr %p1463, align 4, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot158, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i64, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1466, ptr %slot161, align 8
  %v1467 = load i64, ptr %slot161, align 8
  %v1468 = load i64, ptr %slot30, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  store i64 %v1467, ptr %p1469, align 8, !alias.scope !3, !noalias !4
  %v1470 = load i64, ptr %slot30, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %ld1472 = load i64, ptr %p1471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1472, ptr %slot162, align 8
  %v1473 = load i64, ptr %slot162, align 8
  %v1474 = load i64, ptr %slot23, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i64 %v1473, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot23, align 8
  store i64 %v1476, ptr %slot163, align 8
  %v1477 = load i64, ptr %slot12, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i32, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1479, ptr %slot164, align 8
  %v1480 = load i64, ptr %slot13, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  %ld1482 = load i32, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1482, ptr %slot165, align 8
  %v1483 = load i32, ptr %slot165, align 8
  %op1484 = and i32 %v1483, 24
  store i32 %op1484, ptr %slot165, align 8
  %v1485 = load i32, ptr %slot165, align 8
  %cmp1486 = icmp eq i32 %v1485, 0
  %cv1487 = zext i1 %cmp1486 to i32
  store i32 %cv1487, ptr %slot166, align 8
  %v1488 = load i32, ptr %slot164, align 8
  %v1489 = load i32, ptr %slot166, align 8
  %op1490 = and i32 %v1488, %v1489
  store i32 %op1490, ptr %slot167, align 8
  %v1491 = load i32, ptr %slot167, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcprivateown190, label %bb_rcprivateloan190
bb_rcprivateown190:
  %v1494 = load i64, ptr %slot25, align 8
  store i64 %v1494, ptr %slot168, align 8
  %v1495 = load i64, ptr %slot34, align 8
  store i64 %v1495, ptr %slot169, align 8
  %v1496 = load i64, ptr %slot163, align 8
  %v1497 = load i64, ptr %slot168, align 8
  %op1498 = sub i64 %v1496, %v1497
  store i64 %op1498, ptr %slot170, align 8
  %v1499 = load i64, ptr %slot168, align 8
  %v1500 = load i64, ptr %slot163, align 8
  %op1501 = sub i64 %v1499, %v1500
  store i64 %op1501, ptr %slot171, align 8
  %v1502 = load i64, ptr %slot170, align 8
  %cmp1503 = icmp ult i64 %v1502, 8
  %cv1504 = zext i1 %cmp1503 to i32
  store i32 %cv1504, ptr %slot172, align 8
  %v1505 = load i64, ptr %slot171, align 8
  %cmp1506 = icmp ult i64 %v1505, 8
  %cv1507 = zext i1 %cmp1506 to i32
  store i32 %cv1507, ptr %slot173, align 8
  %v1508 = load i32, ptr %slot172, align 8
  %v1509 = load i32, ptr %slot173, align 8
  %op1510 = or i32 %v1508, %v1509
  store i32 %op1510, ptr %slot174, align 8
  %v1511 = load i32, ptr %slot174, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcmoveslow193, label %bb_rcmovecheck193
bb_rcmovecheck193:
  %v1514 = load i64, ptr %slot163, align 8
  %p1516 = inttoptr i64 %v1514 to ptr
  %gep1517 = getelementptr i8, ptr %p1516, i64 0
  %op1515 = ptrtoint ptr %gep1517 to i64
  store i64 %op1515, ptr %slot175, align 8
  %v1518 = load i64, ptr %slot175, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %ld1520 = load i64, ptr %p1519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1520, ptr %slot176, align 8
  %v1521 = load i64, ptr %slot176, align 8
  %cmp1522 = icmp ne i64 %v1521, 0
  %cv1523 = zext i1 %cmp1522 to i32
  store i32 %cv1523, ptr %slot177, align 8
  %v1524 = load i32, ptr %slot177, align 8
  %cv1525 = zext i32 %v1524 to i64
  %cond1526 = icmp ne i64 %cv1525, 0
  br i1 %cond1526, label %bb_rcmoveheader201, label %bb_rcmovenext201
bb_rcmoveheader201:
  %v1527 = load i64, ptr %slot176, align 8
  %op1528 = sub i64 %v1527, 16
  store i64 %op1528, ptr %slot178, align 8
  %v1529 = load i64, ptr %slot176, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %rgep1531 = getelementptr i8, ptr %p1530, i64 -16
  %ld1532 = load i64, ptr %rgep1531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1532, ptr %slot179, align 8
  %v1533 = load i64, ptr %slot179, align 8
  %op1534 = and i64 %v1533, 5764607523034234881
  store i64 %op1534, ptr %slot180, align 8
  %v1535 = load i64, ptr %slot180, align 8
  %cmp1536 = icmp ne i64 %v1535, 0
  %cv1537 = zext i1 %cmp1536 to i32
  store i32 %cv1537, ptr %slot181, align 8
  %v1538 = load i32, ptr %slot181, align 8
  %cv1539 = zext i32 %v1538 to i64
  %cond1540 = icmp ne i64 %cv1539, 0
  br i1 %cond1540, label %bb_rcmoveslow193, label %bb_rcmovenext201
bb_rcmovenext201:
  %v1541 = load i64, ptr %slot163, align 8
  %v1542 = load i64, ptr %slot168, align 8
  %p1543 = inttoptr i64 %v1541 to ptr
  %p1544 = inttoptr i64 %v1542 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1544, ptr %p1543, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot163, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i64 0, ptr %p1546, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved193
bb_rcmoveslow193:
  %v1547 = load i64, ptr %slot33, align 8
  %v1548 = load i64, ptr %slot168, align 8
  %v1549 = load i64, ptr %slot163, align 8
  %v1550 = load i64, ptr %slot169, align 8
  %cv1551 = trunc i64 %v1550 to i32
  %call1552 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1547, i64 %v1548, i64 %v1549, i32 %cv1551) nomerge, !dbg !118
  store i32 %call1552, ptr %slot182, align 8
  %v1553 = load i32, ptr %slot182, align 8
  %cv1554 = zext i32 %v1553 to i64
  %cond1555 = icmp ne i64 %cv1554, 0
  br i1 %cond1555, label %bb_rcsuccess208, label %bb_rcfailure208
bb_rcfailure208:
  %v1556 = load i64, ptr %slot33, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  %call1558 = call i32 @myl_rc_take_failure(ptr %p1557) nomerge, !dbg !118
  store i32 %call1558, ptr %slot183, align 8
  %v1559 = load i64, ptr %slot1, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %v1561 = load i32, ptr %slot183, align 8
  %call1562 = call i32 @myl_qbe_rc_status(ptr %p1560, i32 %v1561) nomerge, !dbg !118
  store i32 %call1562, ptr %slot184, align 8
  br label %bb_failure
bb_rcsuccess208:
  br label %bb_rcmoved193
bb_rcmoved193:
  %v1563 = load i64, ptr %slot12, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i32 0, ptr %p1564, align 4, !alias.scope !3, !noalias !4
  %v1565 = load i64, ptr %slot17, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  store i32 2, ptr %p1566, align 4, !alias.scope !3, !noalias !4
  %v1567 = load i64, ptr %slot16, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i32 1, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared190
bb_rcprivateloan190:
  %v1569 = load i64, ptr %slot12, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %ld1571 = load i32, ptr %p1570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1571, ptr %slot185, align 8
  %v1572 = load i64, ptr %slot13, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %ld1574 = load i32, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1574, ptr %slot186, align 8
  %v1575 = load i32, ptr %slot186, align 8
  %cmp1576 = icmp eq i32 %v1575, 16
  %cv1577 = zext i1 %cmp1576 to i32
  store i32 %cv1577, ptr %slot187, align 8
  %v1578 = load i32, ptr %slot187, align 8
  %v1579 = load i32, ptr %slot185, align 8
  %op1580 = and i32 %v1578, %v1579
  store i32 %op1580, ptr %slot187, align 8
  %v1581 = load i32, ptr %slot187, align 8
  %cv1582 = zext i32 %v1581 to i64
  %cond1583 = icmp ne i64 %cv1582, 0
  br i1 %cond1583, label %bb_rcprivatemove190, label %bb_rcprivatenew190
bb_rcprivatemove190:
  %v1584 = load i64, ptr %slot25, align 8
  store i64 %v1584, ptr %slot188, align 8
  %v1585 = load i64, ptr %slot163, align 8
  %v1586 = load i64, ptr %slot188, align 8
  %p1587 = inttoptr i64 %v1585 to ptr
  %p1588 = inttoptr i64 %v1586 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1588, ptr %p1587, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1589 = load i64, ptr %slot163, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i64 0, ptr %p1590, align 8, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot17, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 2, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot17, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i32 16, ptr %p1594, align 4, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot16, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  store i32 1, ptr %p1596, align 4, !alias.scope !3, !noalias !4
  %v1597 = load i64, ptr %slot12, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i32 0, ptr %p1598, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared190
bb_rcprivatenew190:
  %v1599 = load i64, ptr %slot25, align 8
  store i64 %v1599, ptr %slot189, align 8
  %v1600 = load i64, ptr %slot163, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %ld1602 = load i64, ptr %p1601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1602, ptr %slot190, align 8
  %v1603 = load i64, ptr %slot190, align 8
  %cmp1604 = icmp ne i64 %v1603, 0
  %cv1605 = zext i1 %cmp1604 to i32
  store i32 %cv1605, ptr %slot191, align 8
  %v1606 = load i32, ptr %slot191, align 8
  %cv1607 = zext i32 %v1606 to i64
  %cond1608 = icmp ne i64 %cv1607, 0
  br i1 %cond1608, label %bb_rcgnn226, label %bb_rcgstore226
bb_rcgnn226:
  %v1609 = load i64, ptr %slot190, align 8
  %op1610 = sub i64 %v1609, 16
  store i64 %op1610, ptr %slot192, align 8
  %v1611 = load i64, ptr %slot190, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %rgep1613 = getelementptr i8, ptr %p1612, i64 -16
  %ld1614 = load i64, ptr %rgep1613, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1614, ptr %slot193, align 8
  %v1615 = load i64, ptr %slot193, align 8
  %op1616 = and i64 %v1615, 4611686018427387906
  store i64 %op1616, ptr %slot194, align 8
  %v1617 = load i64, ptr %slot194, align 8
  %cmp1618 = icmp ne i64 %v1617, 0
  %cv1619 = zext i1 %cmp1618 to i32
  store i32 %cv1619, ptr %slot195, align 8
  %v1620 = load i32, ptr %slot195, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcgstore226, label %bb_rcginc226
bb_rcginc226:
  %v1623 = load i64, ptr %slot190, align 8
  %op1624 = sub i64 %v1623, 24
  store i64 %op1624, ptr %slot196, align 8
  %v1625 = load i64, ptr %slot190, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %rgep1627 = getelementptr i8, ptr %p1626, i64 -24
  %ld1628 = load i64, ptr %rgep1627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1628, ptr %slot197, align 8
  %v1629 = load i64, ptr %slot197, align 8
  %op1630 = add i64 %v1629, 1
  store i64 %op1630, ptr %slot198, align 8
  %v1631 = load i64, ptr %slot198, align 8
  %cmp1632 = icmp eq i64 %v1631, 0
  %cv1633 = zext i1 %cmp1632 to i32
  store i32 %cv1633, ptr %slot199, align 8
  %v1634 = load i32, ptr %slot199, align 8
  %cv1635 = zext i32 %v1634 to i64
  %cond1636 = icmp ne i64 %cv1635, 0
  br i1 %cond1636, label %bb_rcglimit226, label %bb_rcgcapacity226
bb_rcglimit226:
  %v1637 = load i64, ptr %slot1, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %call1639 = call i32 @myl_qbe_rc_status(ptr %p1638, i32 2) nomerge, !dbg !118
  store i32 %call1639, ptr %slot200, align 8
  br label %bb_failure
bb_rcgcapacity226:
  %v1640 = load i64, ptr %slot198, align 8
  %v1641 = load i64, ptr %slot190, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %rgep1643 = getelementptr i8, ptr %p1642, i64 -24
  store i64 %v1640, ptr %rgep1643, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore226
bb_rcgstore226:
  %v1644 = load i64, ptr %slot190, align 8
  %v1645 = load i64, ptr %slot189, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i64 %v1644, ptr %p1646, align 8, !alias.scope !3, !noalias !4
  %v1647 = load i64, ptr %slot17, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  store i32 2, ptr %p1648, align 4, !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot17, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  store i32 16, ptr %p1650, align 4, !alias.scope !3, !noalias !4
  %v1651 = load i64, ptr %slot16, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i32 1, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot12, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %ld1655 = load i32, ptr %p1654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1655, ptr %slot201, align 8
  %v1656 = load i32, ptr %slot201, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcslotdrop242, label %bb_rcslotdone242
bb_rcslotdrop242:
  %v1659 = load i64, ptr %slot12, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i32 0, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot20, align 8
  store i64 %v1661, ptr %slot202, align 8
  %v1662 = load i64, ptr %slot13, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %ld1664 = load i32, ptr %p1663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1664, ptr %slot203, align 8
  %v1665 = load i32, ptr %slot203, align 8
  %op1666 = and i32 %v1665, 28
  store i32 %op1666, ptr %slot204, align 8
  %v1667 = load i32, ptr %slot204, align 8
  %cv1668 = zext i32 %v1667 to i64
  %cond1669 = icmp ne i64 %cv1668, 0
  br i1 %cond1669, label %bb_rcslotrole242, label %bb_rcslotowner242
bb_rcslotrole242:
  %v1670 = load i64, ptr %slot33, align 8
  store i64 %v1670, ptr %slot205, align 8
  %v1671 = load i64, ptr %slot202, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i64, ptr %p1672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1673, ptr %slot206, align 8
  %v1674 = load i64, ptr %slot206, align 8
  %cmp1675 = icmp ne i64 %v1674, 0
  %cv1676 = zext i1 %cmp1675 to i32
  store i32 %cv1676, ptr %slot207, align 8
  %v1677 = load i32, ptr %slot207, align 8
  %cv1678 = zext i32 %v1677 to i64
  %cond1679 = icmp ne i64 %cv1678, 0
  br i1 %cond1679, label %bb_rcgnn258, label %bb_rcgdone258
bb_rcgnn258:
  %v1680 = load i64, ptr %slot206, align 8
  %op1681 = sub i64 %v1680, 16
  store i64 %op1681, ptr %slot208, align 8
  %v1682 = load i64, ptr %slot206, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %rgep1684 = getelementptr i8, ptr %p1683, i64 -16
  %ld1685 = load i64, ptr %rgep1684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1685, ptr %slot209, align 8
  %v1686 = load i64, ptr %slot209, align 8
  %op1687 = and i64 %v1686, 4611686018427387906
  store i64 %op1687, ptr %slot210, align 8
  %v1688 = load i64, ptr %slot210, align 8
  %cmp1689 = icmp ne i64 %v1688, 0
  %cv1690 = zext i1 %cmp1689 to i32
  store i32 %cv1690, ptr %slot211, align 8
  %v1691 = load i32, ptr %slot211, align 8
  %cv1692 = zext i32 %v1691 to i64
  %cond1693 = icmp ne i64 %cv1692, 0
  br i1 %cond1693, label %bb_rcgclear258, label %bb_rcgcounted258
bb_rcgcounted258:
  %v1694 = load i64, ptr %slot206, align 8
  %op1695 = sub i64 %v1694, 24
  store i64 %op1695, ptr %slot212, align 8
  %v1696 = load i64, ptr %slot206, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %rgep1698 = getelementptr i8, ptr %p1697, i64 -24
  %ld1699 = load i64, ptr %rgep1698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1699, ptr %slot213, align 8
  %v1700 = load i64, ptr %slot213, align 8
  %op1701 = sub i64 %v1700, 1
  store i64 %op1701, ptr %slot214, align 8
  %v1702 = load i64, ptr %slot214, align 8
  %cmp1703 = icmp eq i64 %v1702, 0
  %cv1704 = zext i1 %cmp1703 to i32
  store i32 %cv1704, ptr %slot215, align 8
  %v1705 = load i32, ptr %slot215, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rcglast258, label %bb_rcgdec258
bb_rcglast258:
  %v1708 = load i64, ptr %slot206, align 8
  %op1709 = sub i64 %v1708, 32
  store i64 %op1709, ptr %slot216, align 8
  %v1710 = load i64, ptr %slot206, align 8
  %p1711 = inttoptr i64 %v1710 to ptr
  %rgep1712 = getelementptr i8, ptr %p1711, i64 -32
  %ld1713 = load i64, ptr %rgep1712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1713, ptr %slot217, align 8
  %v1714 = load i64, ptr %slot217, align 8
  %cmp1715 = icmp ne i64 %v1714, 0
  %cv1716 = zext i1 %cmp1715 to i32
  store i32 %cv1716, ptr %slot218, align 8
  %v1717 = load i32, ptr %slot218, align 8
  %cv1718 = zext i32 %v1717 to i64
  %cond1719 = icmp ne i64 %cv1718, 0
  br i1 %cond1719, label %bb_rcgdec258, label %bb_rcgslow258
bb_rcgslow258:
  %v1720 = load i64, ptr %slot205, align 8
  %v1721 = load i64, ptr %slot202, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1720, i64 %v1721) nomerge, !dbg !118
  br label %bb_rcgdone258
bb_rcgdec258:
  %v1722 = load i64, ptr %slot214, align 8
  %v1723 = load i64, ptr %slot206, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %rgep1725 = getelementptr i8, ptr %p1724, i64 -24
  store i64 %v1722, ptr %rgep1725, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear258
bb_rcgclear258:
  %v1726 = load i64, ptr %slot202, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i64 0, ptr %p1727, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone258
bb_rcgdone258:
  br label %bb_rcslotdone242
bb_rcslotowner242:
  %v1728 = load i64, ptr %slot33, align 8
  store i64 %v1728, ptr %slot219, align 8
  %v1729 = load i64, ptr %slot202, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i64, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1731, ptr %slot220, align 8
  %v1732 = load i64, ptr %slot220, align 8
  %cmp1733 = icmp ne i64 %v1732, 0
  %cv1734 = zext i1 %cmp1733 to i32
  store i32 %cv1734, ptr %slot221, align 8
  %v1735 = load i32, ptr %slot221, align 8
  %cv1736 = zext i32 %v1735 to i64
  %cond1737 = icmp ne i64 %cv1736, 0
  br i1 %cond1737, label %bb_rcgnn273, label %bb_rcgdone273
bb_rcgnn273:
  %v1738 = load i64, ptr %slot220, align 8
  %op1739 = sub i64 %v1738, 16
  store i64 %op1739, ptr %slot222, align 8
  %v1740 = load i64, ptr %slot220, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  %rgep1742 = getelementptr i8, ptr %p1741, i64 -16
  %ld1743 = load i64, ptr %rgep1742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1743, ptr %slot223, align 8
  %v1744 = load i64, ptr %slot223, align 8
  %op1745 = and i64 %v1744, 4611686018427387906
  store i64 %op1745, ptr %slot224, align 8
  %v1746 = load i64, ptr %slot224, align 8
  %cmp1747 = icmp ne i64 %v1746, 0
  %cv1748 = zext i1 %cmp1747 to i32
  store i32 %cv1748, ptr %slot225, align 8
  %v1749 = load i32, ptr %slot225, align 8
  %cv1750 = zext i32 %v1749 to i64
  %cond1751 = icmp ne i64 %cv1750, 0
  br i1 %cond1751, label %bb_rcgclear273, label %bb_rcgcounted273
bb_rcgcounted273:
  %v1752 = load i64, ptr %slot220, align 8
  %op1753 = sub i64 %v1752, 32
  store i64 %op1753, ptr %slot226, align 8
  %v1754 = load i64, ptr %slot220, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %rgep1756 = getelementptr i8, ptr %p1755, i64 -32
  %ld1757 = load i64, ptr %rgep1756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1757, ptr %slot227, align 8
  %v1758 = load i64, ptr %slot227, align 8
  %op1759 = sub i64 %v1758, 1
  store i64 %op1759, ptr %slot228, align 8
  %v1760 = load i64, ptr %slot228, align 8
  %cmp1761 = icmp eq i64 %v1760, 0
  %cv1762 = zext i1 %cmp1761 to i32
  store i32 %cv1762, ptr %slot229, align 8
  %v1763 = load i32, ptr %slot229, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcglast273, label %bb_rcgdec273
bb_rcglast273:
  %v1766 = load i64, ptr %slot220, align 8
  %op1767 = sub i64 %v1766, 24
  store i64 %op1767, ptr %slot230, align 8
  %v1768 = load i64, ptr %slot220, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %rgep1770 = getelementptr i8, ptr %p1769, i64 -24
  %ld1771 = load i64, ptr %rgep1770, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1771, ptr %slot231, align 8
  %v1772 = load i64, ptr %slot231, align 8
  %cmp1773 = icmp ne i64 %v1772, 0
  %cv1774 = zext i1 %cmp1773 to i32
  store i32 %cv1774, ptr %slot232, align 8
  %v1775 = load i32, ptr %slot232, align 8
  %cv1776 = zext i32 %v1775 to i64
  %cond1777 = icmp ne i64 %cv1776, 0
  br i1 %cond1777, label %bb_rcgdec273, label %bb_rcgslow273
bb_rcgslow273:
  %v1778 = load i64, ptr %slot219, align 8
  %v1779 = load i64, ptr %slot202, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1778, i64 %v1779) nomerge, !dbg !118
  br label %bb_rcgdone273
bb_rcgdec273:
  %v1780 = load i64, ptr %slot228, align 8
  %v1781 = load i64, ptr %slot220, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %rgep1783 = getelementptr i8, ptr %p1782, i64 -32
  store i64 %v1780, ptr %rgep1783, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear273
bb_rcgclear273:
  %v1784 = load i64, ptr %slot202, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  store i64 0, ptr %p1785, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone273
bb_rcgdone273:
  br label %bb_rcslotdone242
bb_rcslotdone242:
  br label %bb_rcprivateprepared190
bb_rcprivateprepared190:
  %v1786 = load i64, ptr %slot6, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  %ld1788 = load i32, ptr %p1787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1788, ptr %slot233, align 8
  %v1789 = load i32, ptr %slot233, align 8
  %cv1790 = zext i32 %v1789 to i64
  %cond1791 = icmp ne i64 %cv1790, 0
  br i1 %cond1791, label %bb_rcslotdrop280, label %bb_rcslotdone280
bb_rcslotdrop280:
  %v1792 = load i64, ptr %slot6, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  store i32 0, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  %v1794 = load i64, ptr %slot27, align 8
  store i64 %v1794, ptr %slot234, align 8
  %v1795 = load i64, ptr %slot7, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  %ld1797 = load i32, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1797, ptr %slot235, align 8
  %v1798 = load i32, ptr %slot235, align 8
  %op1799 = and i32 %v1798, 28
  store i32 %op1799, ptr %slot236, align 8
  %v1800 = load i32, ptr %slot236, align 8
  %cv1801 = zext i32 %v1800 to i64
  %cond1802 = icmp ne i64 %cv1801, 0
  br i1 %cond1802, label %bb_rcslotrole280, label %bb_rcslotowner280
bb_rcslotrole280:
  %v1803 = load i64, ptr %slot33, align 8
  store i64 %v1803, ptr %slot237, align 8
  %v1804 = load i64, ptr %slot234, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  %ld1806 = load i64, ptr %p1805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1806, ptr %slot238, align 8
  %v1807 = load i64, ptr %slot238, align 8
  %cmp1808 = icmp ne i64 %v1807, 0
  %cv1809 = zext i1 %cmp1808 to i32
  store i32 %cv1809, ptr %slot239, align 8
  %v1810 = load i32, ptr %slot239, align 8
  %cv1811 = zext i32 %v1810 to i64
  %cond1812 = icmp ne i64 %cv1811, 0
  br i1 %cond1812, label %bb_rcgnn296, label %bb_rcgdone296
bb_rcgnn296:
  %v1813 = load i64, ptr %slot238, align 8
  %op1814 = sub i64 %v1813, 16
  store i64 %op1814, ptr %slot240, align 8
  %v1815 = load i64, ptr %slot238, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  %rgep1817 = getelementptr i8, ptr %p1816, i64 -16
  %ld1818 = load i64, ptr %rgep1817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1818, ptr %slot241, align 8
  %v1819 = load i64, ptr %slot241, align 8
  %op1820 = and i64 %v1819, 4611686018427387906
  store i64 %op1820, ptr %slot242, align 8
  %v1821 = load i64, ptr %slot242, align 8
  %cmp1822 = icmp ne i64 %v1821, 0
  %cv1823 = zext i1 %cmp1822 to i32
  store i32 %cv1823, ptr %slot243, align 8
  %v1824 = load i32, ptr %slot243, align 8
  %cv1825 = zext i32 %v1824 to i64
  %cond1826 = icmp ne i64 %cv1825, 0
  br i1 %cond1826, label %bb_rcgclear296, label %bb_rcgcounted296
bb_rcgcounted296:
  %v1827 = load i64, ptr %slot238, align 8
  %op1828 = sub i64 %v1827, 24
  store i64 %op1828, ptr %slot244, align 8
  %v1829 = load i64, ptr %slot238, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  %rgep1831 = getelementptr i8, ptr %p1830, i64 -24
  %ld1832 = load i64, ptr %rgep1831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1832, ptr %slot245, align 8
  %v1833 = load i64, ptr %slot245, align 8
  %op1834 = sub i64 %v1833, 1
  store i64 %op1834, ptr %slot246, align 8
  %v1835 = load i64, ptr %slot246, align 8
  %cmp1836 = icmp eq i64 %v1835, 0
  %cv1837 = zext i1 %cmp1836 to i32
  store i32 %cv1837, ptr %slot247, align 8
  %v1838 = load i32, ptr %slot247, align 8
  %cv1839 = zext i32 %v1838 to i64
  %cond1840 = icmp ne i64 %cv1839, 0
  br i1 %cond1840, label %bb_rcglast296, label %bb_rcgdec296
bb_rcglast296:
  %v1841 = load i64, ptr %slot238, align 8
  %op1842 = sub i64 %v1841, 32
  store i64 %op1842, ptr %slot248, align 8
  %v1843 = load i64, ptr %slot238, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %rgep1845 = getelementptr i8, ptr %p1844, i64 -32
  %ld1846 = load i64, ptr %rgep1845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1846, ptr %slot249, align 8
  %v1847 = load i64, ptr %slot249, align 8
  %cmp1848 = icmp ne i64 %v1847, 0
  %cv1849 = zext i1 %cmp1848 to i32
  store i32 %cv1849, ptr %slot250, align 8
  %v1850 = load i32, ptr %slot250, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcgdec296, label %bb_rcgslow296
bb_rcgslow296:
  %v1853 = load i64, ptr %slot237, align 8
  %v1854 = load i64, ptr %slot234, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1853, i64 %v1854) nomerge, !dbg !118
  br label %bb_rcgdone296
bb_rcgdec296:
  %v1855 = load i64, ptr %slot246, align 8
  %v1856 = load i64, ptr %slot238, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %rgep1858 = getelementptr i8, ptr %p1857, i64 -24
  store i64 %v1855, ptr %rgep1858, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear296
bb_rcgclear296:
  %v1859 = load i64, ptr %slot234, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  store i64 0, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone296
bb_rcgdone296:
  br label %bb_rcslotdone280
bb_rcslotowner280:
  %v1861 = load i64, ptr %slot33, align 8
  store i64 %v1861, ptr %slot251, align 8
  %v1862 = load i64, ptr %slot234, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  %ld1864 = load i64, ptr %p1863, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1864, ptr %slot252, align 8
  %v1865 = load i64, ptr %slot252, align 8
  %cmp1866 = icmp ne i64 %v1865, 0
  %cv1867 = zext i1 %cmp1866 to i32
  store i32 %cv1867, ptr %slot253, align 8
  %v1868 = load i32, ptr %slot253, align 8
  %cv1869 = zext i32 %v1868 to i64
  %cond1870 = icmp ne i64 %cv1869, 0
  br i1 %cond1870, label %bb_rcgnn311, label %bb_rcgdone311
bb_rcgnn311:
  %v1871 = load i64, ptr %slot252, align 8
  %op1872 = sub i64 %v1871, 16
  store i64 %op1872, ptr %slot254, align 8
  %v1873 = load i64, ptr %slot252, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  %rgep1875 = getelementptr i8, ptr %p1874, i64 -16
  %ld1876 = load i64, ptr %rgep1875, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1876, ptr %slot255, align 8
  %v1877 = load i64, ptr %slot255, align 8
  %op1878 = and i64 %v1877, 4611686018427387906
  store i64 %op1878, ptr %slot256, align 8
  %v1879 = load i64, ptr %slot256, align 8
  %cmp1880 = icmp ne i64 %v1879, 0
  %cv1881 = zext i1 %cmp1880 to i32
  store i32 %cv1881, ptr %slot257, align 8
  %v1882 = load i32, ptr %slot257, align 8
  %cv1883 = zext i32 %v1882 to i64
  %cond1884 = icmp ne i64 %cv1883, 0
  br i1 %cond1884, label %bb_rcgclear311, label %bb_rcgcounted311
bb_rcgcounted311:
  %v1885 = load i64, ptr %slot252, align 8
  %op1886 = sub i64 %v1885, 32
  store i64 %op1886, ptr %slot258, align 8
  %v1887 = load i64, ptr %slot252, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %rgep1889 = getelementptr i8, ptr %p1888, i64 -32
  %ld1890 = load i64, ptr %rgep1889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1890, ptr %slot259, align 8
  %v1891 = load i64, ptr %slot259, align 8
  %op1892 = sub i64 %v1891, 1
  store i64 %op1892, ptr %slot260, align 8
  %v1893 = load i64, ptr %slot260, align 8
  %cmp1894 = icmp eq i64 %v1893, 0
  %cv1895 = zext i1 %cmp1894 to i32
  store i32 %cv1895, ptr %slot261, align 8
  %v1896 = load i32, ptr %slot261, align 8
  %cv1897 = zext i32 %v1896 to i64
  %cond1898 = icmp ne i64 %cv1897, 0
  br i1 %cond1898, label %bb_rcglast311, label %bb_rcgdec311
bb_rcglast311:
  %v1899 = load i64, ptr %slot252, align 8
  %op1900 = sub i64 %v1899, 24
  store i64 %op1900, ptr %slot262, align 8
  %v1901 = load i64, ptr %slot252, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  %rgep1903 = getelementptr i8, ptr %p1902, i64 -24
  %ld1904 = load i64, ptr %rgep1903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1904, ptr %slot263, align 8
  %v1905 = load i64, ptr %slot263, align 8
  %cmp1906 = icmp ne i64 %v1905, 0
  %cv1907 = zext i1 %cmp1906 to i32
  store i32 %cv1907, ptr %slot264, align 8
  %v1908 = load i32, ptr %slot264, align 8
  %cv1909 = zext i32 %v1908 to i64
  %cond1910 = icmp ne i64 %cv1909, 0
  br i1 %cond1910, label %bb_rcgdec311, label %bb_rcgslow311
bb_rcgslow311:
  %v1911 = load i64, ptr %slot251, align 8
  %v1912 = load i64, ptr %slot234, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1911, i64 %v1912) nomerge, !dbg !118
  br label %bb_rcgdone311
bb_rcgdec311:
  %v1913 = load i64, ptr %slot260, align 8
  %v1914 = load i64, ptr %slot252, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %rgep1916 = getelementptr i8, ptr %p1915, i64 -32
  store i64 %v1913, ptr %rgep1916, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear311
bb_rcgclear311:
  %v1917 = load i64, ptr %slot234, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i64 0, ptr %p1918, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone311
bb_rcgdone311:
  br label %bb_rcslotdone280
bb_rcslotdone280:
  %v1919 = load i64, ptr %slot27, align 8
  store i64 %v1919, ptr %slot265, align 8
  %v1920 = load i64, ptr %slot25, align 8
  store i64 %v1920, ptr %slot266, align 8
  %v1921 = load i64, ptr %slot266, align 8
  %v1922 = load i64, ptr %slot265, align 8
  %p1923 = inttoptr i64 %v1921 to ptr
  %p1924 = inttoptr i64 %v1922 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1924, ptr %p1923, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot16, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i32 0, ptr %p1926, align 4, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot7, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  store i32 2, ptr %p1928, align 4, !alias.scope !3, !noalias !4
  %v1929 = load i64, ptr %slot17, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  %ld1931 = load i32, ptr %p1930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1931, ptr %slot267, align 8
  %v1932 = load i32, ptr %slot267, align 8
  %v1933 = load i64, ptr %slot7, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i32 %v1932, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  %v1935 = load i64, ptr %slot6, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i32 1, ptr %p1936, align 4, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot27, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i64, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1939, ptr %slot268, align 8
  %v1940 = load i64, ptr %slot268, align 8
  %v1941 = load i64, ptr %slot30, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 %v1940, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  %v1943 = load i64, ptr %slot31, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i64 0, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  %v1945 = load i64, ptr %slot31, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %ld1947 = load i64, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1947, ptr %slot269, align 8
  %v1948 = load i64, ptr %slot269, align 8
  %cmp1949 = icmp sge i64 %v1948, 0
  %cv1950 = zext i1 %cmp1949 to i64
  store i64 %cv1950, ptr %slot270, align 8
  %v1951 = load i64, ptr %slot270, align 8
  %cond1952 = icmp ne i64 %v1951, 0
  br i1 %cond1952, label %bb_success325, label %bb_failed325
bb_failed325:
  %v1953 = load i64, ptr %slot1, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1954) nomerge, !dbg !120
  unreachable
bb_success325:
  %v1955 = load i64, ptr %slot33, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %p1957 = inttoptr i64 ptrtoint (ptr @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 to i64) to ptr
  %v1958 = load i64, ptr %slot269, align 8
  %call1959 = call ptr @myl_native_list_new(ptr %p1956, ptr %p1957, i64 %v1958) nomerge, !dbg !120
  %calladdr1960 = ptrtoint ptr %call1959 to i64
  store i64 %calladdr1960, ptr %slot271, align 8
  %v1961 = load i64, ptr %slot271, align 8
  %cond1962 = icmp ne i64 %v1961, 0
  br i1 %cond1962, label %bb_success327, label %bb_failed327
bb_failed327:
  %v1963 = load i64, ptr %slot1, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1964) nomerge, !dbg !120
  unreachable
bb_success327:
  %v1965 = load i64, ptr %slot271, align 8
  %v1966 = load i64, ptr %slot31, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  store i64 %v1965, ptr %p1967, align 8, !alias.scope !3, !noalias !4
  %v1968 = load i64, ptr %slot31, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  %ld1970 = load i64, ptr %p1969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1970, ptr %slot272, align 8
  %v1971 = load i64, ptr %slot272, align 8
  %v1972 = load i64, ptr %slot24, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i64 %v1971, ptr %p1973, align 8, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot24, align 8
  store i64 %v1974, ptr %slot273, align 8
  %v1975 = load i64, ptr %slot25, align 8
  store i64 %v1975, ptr %slot274, align 8
  %v1976 = load i64, ptr %slot273, align 8
  %v1977 = load i64, ptr %slot274, align 8
  %p1978 = inttoptr i64 %v1976 to ptr
  %p1979 = inttoptr i64 %v1977 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1979, ptr %p1978, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1980 = load i64, ptr %slot17, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i32 2, ptr %p1981, align 4, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot16, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 1, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot21, align 8
  store i64 %v1984, ptr %slot275, align 8
  %v1985 = load i64, ptr %slot25, align 8
  store i64 %v1985, ptr %slot276, align 8
  %v1986 = load i64, ptr %slot276, align 8
  %v1987 = load i64, ptr %slot275, align 8
  %p1988 = inttoptr i64 %v1986 to ptr
  %p1989 = inttoptr i64 %v1987 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1989, ptr %p1988, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1990 = load i64, ptr %slot15, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  store i32 2, ptr %p1991, align 4, !alias.scope !3, !noalias !4
  %v1992 = load i64, ptr %slot17, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %ld1994 = load i32, ptr %p1993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1994, ptr %slot277, align 8
  %v1995 = load i32, ptr %slot277, align 8
  %v1996 = load i64, ptr %slot15, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i32 %v1995, ptr %p1997, align 4, !alias.scope !3, !noalias !4
  %v1998 = load i64, ptr %slot16, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i32 0, ptr %p1999, align 4, !alias.scope !3, !noalias !4
  %v2000 = load i64, ptr %slot14, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i32 1, ptr %p2001, align 4, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot275, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i64, ptr %p2003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2004, ptr %slot278, align 8
  %v2005 = load i64, ptr %slot278, align 8
  %v2006 = load i64, ptr %slot31, align 8
  %p2007 = inttoptr i64 %v2006 to ptr
  store i64 %v2005, ptr %p2007, align 8, !alias.scope !3, !noalias !4
  %v2008 = load i64, ptr %slot31, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i64, ptr %p2009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2010, ptr %slot279, align 8
  %v2011 = load i64, ptr %slot279, align 8
  %v2012 = load i64, ptr %slot24, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  store i64 %v2011, ptr %p2013, align 8, !alias.scope !3, !noalias !4
  %v2014 = load i64, ptr %slot24, align 8
  store i64 %v2014, ptr %slot280, align 8
  %v2015 = load i64, ptr %slot14, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  %ld2017 = load i32, ptr %p2016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2017, ptr %slot281, align 8
  %v2018 = load i64, ptr %slot15, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %ld2020 = load i32, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2020, ptr %slot282, align 8
  %v2021 = load i32, ptr %slot282, align 8
  %op2022 = and i32 %v2021, 24
  store i32 %op2022, ptr %slot282, align 8
  %v2023 = load i32, ptr %slot282, align 8
  %cmp2024 = icmp eq i32 %v2023, 0
  %cv2025 = zext i1 %cmp2024 to i32
  store i32 %cv2025, ptr %slot283, align 8
  %v2026 = load i32, ptr %slot281, align 8
  %v2027 = load i32, ptr %slot283, align 8
  %op2028 = and i32 %v2026, %v2027
  store i32 %op2028, ptr %slot284, align 8
  %v2029 = load i32, ptr %slot284, align 8
  %cv2030 = zext i32 %v2029 to i64
  %cond2031 = icmp ne i64 %cv2030, 0
  br i1 %cond2031, label %bb_rcprivateown350, label %bb_rcprivateloan350
bb_rcprivateown350:
  %v2032 = load i64, ptr %slot25, align 8
  store i64 %v2032, ptr %slot285, align 8
  %v2033 = load i64, ptr %slot34, align 8
  store i64 %v2033, ptr %slot286, align 8
  %v2034 = load i64, ptr %slot280, align 8
  %v2035 = load i64, ptr %slot285, align 8
  %op2036 = sub i64 %v2034, %v2035
  store i64 %op2036, ptr %slot287, align 8
  %v2037 = load i64, ptr %slot285, align 8
  %v2038 = load i64, ptr %slot280, align 8
  %op2039 = sub i64 %v2037, %v2038
  store i64 %op2039, ptr %slot288, align 8
  %v2040 = load i64, ptr %slot287, align 8
  %cmp2041 = icmp ult i64 %v2040, 8
  %cv2042 = zext i1 %cmp2041 to i32
  store i32 %cv2042, ptr %slot289, align 8
  %v2043 = load i64, ptr %slot288, align 8
  %cmp2044 = icmp ult i64 %v2043, 8
  %cv2045 = zext i1 %cmp2044 to i32
  store i32 %cv2045, ptr %slot290, align 8
  %v2046 = load i32, ptr %slot289, align 8
  %v2047 = load i32, ptr %slot290, align 8
  %op2048 = or i32 %v2046, %v2047
  store i32 %op2048, ptr %slot291, align 8
  %v2049 = load i32, ptr %slot291, align 8
  %cv2050 = zext i32 %v2049 to i64
  %cond2051 = icmp ne i64 %cv2050, 0
  br i1 %cond2051, label %bb_rcmoveslow353, label %bb_rcmovecheck353
bb_rcmovecheck353:
  %v2052 = load i64, ptr %slot280, align 8
  %p2054 = inttoptr i64 %v2052 to ptr
  %gep2055 = getelementptr i8, ptr %p2054, i64 0
  %op2053 = ptrtoint ptr %gep2055 to i64
  store i64 %op2053, ptr %slot292, align 8
  %v2056 = load i64, ptr %slot292, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  %ld2058 = load i64, ptr %p2057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2058, ptr %slot293, align 8
  %v2059 = load i64, ptr %slot293, align 8
  %cmp2060 = icmp ne i64 %v2059, 0
  %cv2061 = zext i1 %cmp2060 to i32
  store i32 %cv2061, ptr %slot294, align 8
  %v2062 = load i32, ptr %slot294, align 8
  %cv2063 = zext i32 %v2062 to i64
  %cond2064 = icmp ne i64 %cv2063, 0
  br i1 %cond2064, label %bb_rcmoveheader361, label %bb_rcmovenext361
bb_rcmoveheader361:
  %v2065 = load i64, ptr %slot293, align 8
  %op2066 = sub i64 %v2065, 16
  store i64 %op2066, ptr %slot295, align 8
  %v2067 = load i64, ptr %slot293, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %rgep2069 = getelementptr i8, ptr %p2068, i64 -16
  %ld2070 = load i64, ptr %rgep2069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2070, ptr %slot296, align 8
  %v2071 = load i64, ptr %slot296, align 8
  %op2072 = and i64 %v2071, 5764607523034234881
  store i64 %op2072, ptr %slot297, align 8
  %v2073 = load i64, ptr %slot297, align 8
  %cmp2074 = icmp ne i64 %v2073, 0
  %cv2075 = zext i1 %cmp2074 to i32
  store i32 %cv2075, ptr %slot298, align 8
  %v2076 = load i32, ptr %slot298, align 8
  %cv2077 = zext i32 %v2076 to i64
  %cond2078 = icmp ne i64 %cv2077, 0
  br i1 %cond2078, label %bb_rcmoveslow353, label %bb_rcmovenext361
bb_rcmovenext361:
  %v2079 = load i64, ptr %slot280, align 8
  %v2080 = load i64, ptr %slot285, align 8
  %p2081 = inttoptr i64 %v2079 to ptr
  %p2082 = inttoptr i64 %v2080 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2082, ptr %p2081, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot280, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i64 0, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved353
bb_rcmoveslow353:
  %v2085 = load i64, ptr %slot33, align 8
  %v2086 = load i64, ptr %slot285, align 8
  %v2087 = load i64, ptr %slot280, align 8
  %v2088 = load i64, ptr %slot286, align 8
  %cv2089 = trunc i64 %v2088 to i32
  %call2090 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v2085, i64 %v2086, i64 %v2087, i32 %cv2089) nomerge, !dbg !122
  store i32 %call2090, ptr %slot299, align 8
  %v2091 = load i32, ptr %slot299, align 8
  %cv2092 = zext i32 %v2091 to i64
  %cond2093 = icmp ne i64 %cv2092, 0
  br i1 %cond2093, label %bb_rcsuccess368, label %bb_rcfailure368
bb_rcfailure368:
  %v2094 = load i64, ptr %slot33, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %call2096 = call i32 @myl_rc_take_failure(ptr %p2095) nomerge, !dbg !122
  store i32 %call2096, ptr %slot300, align 8
  %v2097 = load i64, ptr %slot1, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %v2099 = load i32, ptr %slot300, align 8
  %call2100 = call i32 @myl_qbe_rc_status(ptr %p2098, i32 %v2099) nomerge, !dbg !122
  store i32 %call2100, ptr %slot301, align 8
  br label %bb_failure
bb_rcsuccess368:
  br label %bb_rcmoved353
bb_rcmoved353:
  %v2101 = load i64, ptr %slot14, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 0, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot17, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i32 2, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot16, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 1, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared350
bb_rcprivateloan350:
  %v2107 = load i64, ptr %slot14, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i32, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2109, ptr %slot302, align 8
  %v2110 = load i64, ptr %slot15, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i32, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2112, ptr %slot303, align 8
  %v2113 = load i32, ptr %slot303, align 8
  %cmp2114 = icmp eq i32 %v2113, 16
  %cv2115 = zext i1 %cmp2114 to i32
  store i32 %cv2115, ptr %slot304, align 8
  %v2116 = load i32, ptr %slot304, align 8
  %v2117 = load i32, ptr %slot302, align 8
  %op2118 = and i32 %v2116, %v2117
  store i32 %op2118, ptr %slot304, align 8
  %v2119 = load i32, ptr %slot304, align 8
  %cv2120 = zext i32 %v2119 to i64
  %cond2121 = icmp ne i64 %cv2120, 0
  br i1 %cond2121, label %bb_rcprivatemove350, label %bb_rcprivatenew350
bb_rcprivatemove350:
  %v2122 = load i64, ptr %slot25, align 8
  store i64 %v2122, ptr %slot305, align 8
  %v2123 = load i64, ptr %slot280, align 8
  %v2124 = load i64, ptr %slot305, align 8
  %p2125 = inttoptr i64 %v2123 to ptr
  %p2126 = inttoptr i64 %v2124 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2126, ptr %p2125, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2127 = load i64, ptr %slot280, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  store i64 0, ptr %p2128, align 8, !alias.scope !3, !noalias !4
  %v2129 = load i64, ptr %slot17, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i32 2, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot17, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  store i32 16, ptr %p2132, align 4, !alias.scope !3, !noalias !4
  %v2133 = load i64, ptr %slot16, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  store i32 1, ptr %p2134, align 4, !alias.scope !3, !noalias !4
  %v2135 = load i64, ptr %slot14, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i32 0, ptr %p2136, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared350
bb_rcprivatenew350:
  %v2137 = load i64, ptr %slot25, align 8
  store i64 %v2137, ptr %slot306, align 8
  %v2138 = load i64, ptr %slot280, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i64, ptr %p2139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2140, ptr %slot307, align 8
  %v2141 = load i64, ptr %slot307, align 8
  %cmp2142 = icmp ne i64 %v2141, 0
  %cv2143 = zext i1 %cmp2142 to i32
  store i32 %cv2143, ptr %slot308, align 8
  %v2144 = load i32, ptr %slot308, align 8
  %cv2145 = zext i32 %v2144 to i64
  %cond2146 = icmp ne i64 %cv2145, 0
  br i1 %cond2146, label %bb_rcgnn386, label %bb_rcgstore386
bb_rcgnn386:
  %v2147 = load i64, ptr %slot307, align 8
  %op2148 = sub i64 %v2147, 16
  store i64 %op2148, ptr %slot309, align 8
  %v2149 = load i64, ptr %slot307, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  %rgep2151 = getelementptr i8, ptr %p2150, i64 -16
  %ld2152 = load i64, ptr %rgep2151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2152, ptr %slot310, align 8
  %v2153 = load i64, ptr %slot310, align 8
  %op2154 = and i64 %v2153, 4611686018427387906
  store i64 %op2154, ptr %slot311, align 8
  %v2155 = load i64, ptr %slot311, align 8
  %cmp2156 = icmp ne i64 %v2155, 0
  %cv2157 = zext i1 %cmp2156 to i32
  store i32 %cv2157, ptr %slot312, align 8
  %v2158 = load i32, ptr %slot312, align 8
  %cv2159 = zext i32 %v2158 to i64
  %cond2160 = icmp ne i64 %cv2159, 0
  br i1 %cond2160, label %bb_rcgstore386, label %bb_rcginc386
bb_rcginc386:
  %v2161 = load i64, ptr %slot307, align 8
  %op2162 = sub i64 %v2161, 24
  store i64 %op2162, ptr %slot313, align 8
  %v2163 = load i64, ptr %slot307, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %rgep2165 = getelementptr i8, ptr %p2164, i64 -24
  %ld2166 = load i64, ptr %rgep2165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2166, ptr %slot314, align 8
  %v2167 = load i64, ptr %slot314, align 8
  %op2168 = add i64 %v2167, 1
  store i64 %op2168, ptr %slot315, align 8
  %v2169 = load i64, ptr %slot315, align 8
  %cmp2170 = icmp eq i64 %v2169, 0
  %cv2171 = zext i1 %cmp2170 to i32
  store i32 %cv2171, ptr %slot316, align 8
  %v2172 = load i32, ptr %slot316, align 8
  %cv2173 = zext i32 %v2172 to i64
  %cond2174 = icmp ne i64 %cv2173, 0
  br i1 %cond2174, label %bb_rcglimit386, label %bb_rcgcapacity386
bb_rcglimit386:
  %v2175 = load i64, ptr %slot1, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  %call2177 = call i32 @myl_qbe_rc_status(ptr %p2176, i32 2) nomerge, !dbg !122
  store i32 %call2177, ptr %slot317, align 8
  br label %bb_failure
bb_rcgcapacity386:
  %v2178 = load i64, ptr %slot315, align 8
  %v2179 = load i64, ptr %slot307, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %rgep2181 = getelementptr i8, ptr %p2180, i64 -24
  store i64 %v2178, ptr %rgep2181, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore386
bb_rcgstore386:
  %v2182 = load i64, ptr %slot307, align 8
  %v2183 = load i64, ptr %slot306, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i64 %v2182, ptr %p2184, align 8, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot17, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 2, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot17, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i32 16, ptr %p2188, align 4, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot16, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i32 1, ptr %p2190, align 4, !alias.scope !3, !noalias !4
  %v2191 = load i64, ptr %slot14, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i32, ptr %p2192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2193, ptr %slot318, align 8
  %v2194 = load i32, ptr %slot318, align 8
  %cv2195 = zext i32 %v2194 to i64
  %cond2196 = icmp ne i64 %cv2195, 0
  br i1 %cond2196, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v2197 = load i64, ptr %slot14, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i32 0, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  %v2199 = load i64, ptr %slot21, align 8
  store i64 %v2199, ptr %slot319, align 8
  %v2200 = load i64, ptr %slot15, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %ld2202 = load i32, ptr %p2201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2202, ptr %slot320, align 8
  %v2203 = load i32, ptr %slot320, align 8
  %op2204 = and i32 %v2203, 28
  store i32 %op2204, ptr %slot321, align 8
  %v2205 = load i32, ptr %slot321, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v2208 = load i64, ptr %slot33, align 8
  store i64 %v2208, ptr %slot322, align 8
  %v2209 = load i64, ptr %slot319, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  %ld2211 = load i64, ptr %p2210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2211, ptr %slot323, align 8
  %v2212 = load i64, ptr %slot323, align 8
  %cmp2213 = icmp ne i64 %v2212, 0
  %cv2214 = zext i1 %cmp2213 to i32
  store i32 %cv2214, ptr %slot324, align 8
  %v2215 = load i32, ptr %slot324, align 8
  %cv2216 = zext i32 %v2215 to i64
  %cond2217 = icmp ne i64 %cv2216, 0
  br i1 %cond2217, label %bb_rcgnn418, label %bb_rcgdone418
bb_rcgnn418:
  %v2218 = load i64, ptr %slot323, align 8
  %op2219 = sub i64 %v2218, 16
  store i64 %op2219, ptr %slot325, align 8
  %v2220 = load i64, ptr %slot323, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %rgep2222 = getelementptr i8, ptr %p2221, i64 -16
  %ld2223 = load i64, ptr %rgep2222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2223, ptr %slot326, align 8
  %v2224 = load i64, ptr %slot326, align 8
  %op2225 = and i64 %v2224, 4611686018427387906
  store i64 %op2225, ptr %slot327, align 8
  %v2226 = load i64, ptr %slot327, align 8
  %cmp2227 = icmp ne i64 %v2226, 0
  %cv2228 = zext i1 %cmp2227 to i32
  store i32 %cv2228, ptr %slot328, align 8
  %v2229 = load i32, ptr %slot328, align 8
  %cv2230 = zext i32 %v2229 to i64
  %cond2231 = icmp ne i64 %cv2230, 0
  br i1 %cond2231, label %bb_rcgclear418, label %bb_rcgcounted418
bb_rcgcounted418:
  %v2232 = load i64, ptr %slot323, align 8
  %op2233 = sub i64 %v2232, 24
  store i64 %op2233, ptr %slot329, align 8
  %v2234 = load i64, ptr %slot323, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  %rgep2236 = getelementptr i8, ptr %p2235, i64 -24
  %ld2237 = load i64, ptr %rgep2236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2237, ptr %slot330, align 8
  %v2238 = load i64, ptr %slot330, align 8
  %op2239 = sub i64 %v2238, 1
  store i64 %op2239, ptr %slot331, align 8
  %v2240 = load i64, ptr %slot331, align 8
  %cmp2241 = icmp eq i64 %v2240, 0
  %cv2242 = zext i1 %cmp2241 to i32
  store i32 %cv2242, ptr %slot332, align 8
  %v2243 = load i32, ptr %slot332, align 8
  %cv2244 = zext i32 %v2243 to i64
  %cond2245 = icmp ne i64 %cv2244, 0
  br i1 %cond2245, label %bb_rcglast418, label %bb_rcgdec418
bb_rcglast418:
  %v2246 = load i64, ptr %slot323, align 8
  %op2247 = sub i64 %v2246, 32
  store i64 %op2247, ptr %slot333, align 8
  %v2248 = load i64, ptr %slot323, align 8
  %p2249 = inttoptr i64 %v2248 to ptr
  %rgep2250 = getelementptr i8, ptr %p2249, i64 -32
  %ld2251 = load i64, ptr %rgep2250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2251, ptr %slot334, align 8
  %v2252 = load i64, ptr %slot334, align 8
  %cmp2253 = icmp ne i64 %v2252, 0
  %cv2254 = zext i1 %cmp2253 to i32
  store i32 %cv2254, ptr %slot335, align 8
  %v2255 = load i32, ptr %slot335, align 8
  %cv2256 = zext i32 %v2255 to i64
  %cond2257 = icmp ne i64 %cv2256, 0
  br i1 %cond2257, label %bb_rcgdec418, label %bb_rcgslow418
bb_rcgslow418:
  %v2258 = load i64, ptr %slot322, align 8
  %v2259 = load i64, ptr %slot319, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v2258, i64 %v2259) nomerge, !dbg !122
  br label %bb_rcgdone418
bb_rcgdec418:
  %v2260 = load i64, ptr %slot331, align 8
  %v2261 = load i64, ptr %slot323, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %rgep2263 = getelementptr i8, ptr %p2262, i64 -24
  store i64 %v2260, ptr %rgep2263, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear418
bb_rcgclear418:
  %v2264 = load i64, ptr %slot319, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i64 0, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone418
bb_rcgdone418:
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v2266 = load i64, ptr %slot33, align 8
  store i64 %v2266, ptr %slot336, align 8
  %v2267 = load i64, ptr %slot319, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2269, ptr %slot337, align 8
  %v2270 = load i64, ptr %slot337, align 8
  %cmp2271 = icmp ne i64 %v2270, 0
  %cv2272 = zext i1 %cmp2271 to i32
  store i32 %cv2272, ptr %slot338, align 8
  %v2273 = load i32, ptr %slot338, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcgnn433, label %bb_rcgdone433
bb_rcgnn433:
  %v2276 = load i64, ptr %slot337, align 8
  %op2277 = sub i64 %v2276, 16
  store i64 %op2277, ptr %slot339, align 8
  %v2278 = load i64, ptr %slot337, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %rgep2280 = getelementptr i8, ptr %p2279, i64 -16
  %ld2281 = load i64, ptr %rgep2280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2281, ptr %slot340, align 8
  %v2282 = load i64, ptr %slot340, align 8
  %op2283 = and i64 %v2282, 4611686018427387906
  store i64 %op2283, ptr %slot341, align 8
  %v2284 = load i64, ptr %slot341, align 8
  %cmp2285 = icmp ne i64 %v2284, 0
  %cv2286 = zext i1 %cmp2285 to i32
  store i32 %cv2286, ptr %slot342, align 8
  %v2287 = load i32, ptr %slot342, align 8
  %cv2288 = zext i32 %v2287 to i64
  %cond2289 = icmp ne i64 %cv2288, 0
  br i1 %cond2289, label %bb_rcgclear433, label %bb_rcgcounted433
bb_rcgcounted433:
  %v2290 = load i64, ptr %slot337, align 8
  %op2291 = sub i64 %v2290, 32
  store i64 %op2291, ptr %slot343, align 8
  %v2292 = load i64, ptr %slot337, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %rgep2294 = getelementptr i8, ptr %p2293, i64 -32
  %ld2295 = load i64, ptr %rgep2294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2295, ptr %slot344, align 8
  %v2296 = load i64, ptr %slot344, align 8
  %op2297 = sub i64 %v2296, 1
  store i64 %op2297, ptr %slot345, align 8
  %v2298 = load i64, ptr %slot345, align 8
  %cmp2299 = icmp eq i64 %v2298, 0
  %cv2300 = zext i1 %cmp2299 to i32
  store i32 %cv2300, ptr %slot346, align 8
  %v2301 = load i32, ptr %slot346, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcglast433, label %bb_rcgdec433
bb_rcglast433:
  %v2304 = load i64, ptr %slot337, align 8
  %op2305 = sub i64 %v2304, 24
  store i64 %op2305, ptr %slot347, align 8
  %v2306 = load i64, ptr %slot337, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  %rgep2308 = getelementptr i8, ptr %p2307, i64 -24
  %ld2309 = load i64, ptr %rgep2308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2309, ptr %slot348, align 8
  %v2310 = load i64, ptr %slot348, align 8
  %cmp2311 = icmp ne i64 %v2310, 0
  %cv2312 = zext i1 %cmp2311 to i32
  store i32 %cv2312, ptr %slot349, align 8
  %v2313 = load i32, ptr %slot349, align 8
  %cv2314 = zext i32 %v2313 to i64
  %cond2315 = icmp ne i64 %cv2314, 0
  br i1 %cond2315, label %bb_rcgdec433, label %bb_rcgslow433
bb_rcgslow433:
  %v2316 = load i64, ptr %slot336, align 8
  %v2317 = load i64, ptr %slot319, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v2316, i64 %v2317) nomerge, !dbg !122
  br label %bb_rcgdone433
bb_rcgdec433:
  %v2318 = load i64, ptr %slot345, align 8
  %v2319 = load i64, ptr %slot337, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  %rgep2321 = getelementptr i8, ptr %p2320, i64 -32
  store i64 %v2318, ptr %rgep2321, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear433
bb_rcgclear433:
  %v2322 = load i64, ptr %slot319, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  store i64 0, ptr %p2323, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone433
bb_rcgdone433:
  br label %bb_rcslotdone402
bb_rcslotdone402:
  br label %bb_rcprivateprepared350
bb_rcprivateprepared350:
  %v2324 = load i64, ptr %slot8, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i32, ptr %p2325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2326, ptr %slot350, align 8
  %v2327 = load i32, ptr %slot350, align 8
  %cv2328 = zext i32 %v2327 to i64
  %cond2329 = icmp ne i64 %cv2328, 0
  br i1 %cond2329, label %bb_rcslotdrop440, label %bb_rcslotdone440
bb_rcslotdrop440:
  %v2330 = load i64, ptr %slot8, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  store i32 0, ptr %p2331, align 4, !alias.scope !3, !noalias !4
  %v2332 = load i64, ptr %slot28, align 8
  store i64 %v2332, ptr %slot351, align 8
  %v2333 = load i64, ptr %slot9, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i32, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2335, ptr %slot352, align 8
  %v2336 = load i32, ptr %slot352, align 8
  %op2337 = and i32 %v2336, 28
  store i32 %op2337, ptr %slot353, align 8
  %v2338 = load i32, ptr %slot353, align 8
  %cv2339 = zext i32 %v2338 to i64
  %cond2340 = icmp ne i64 %cv2339, 0
  br i1 %cond2340, label %bb_rcslotrole440, label %bb_rcslotowner440
bb_rcslotrole440:
  %v2341 = load i64, ptr %slot33, align 8
  store i64 %v2341, ptr %slot354, align 8
  %v2342 = load i64, ptr %slot351, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i64, ptr %p2343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2344, ptr %slot355, align 8
  %v2345 = load i64, ptr %slot355, align 8
  %cmp2346 = icmp ne i64 %v2345, 0
  %cv2347 = zext i1 %cmp2346 to i32
  store i32 %cv2347, ptr %slot356, align 8
  %v2348 = load i32, ptr %slot356, align 8
  %cv2349 = zext i32 %v2348 to i64
  %cond2350 = icmp ne i64 %cv2349, 0
  br i1 %cond2350, label %bb_rcgnn456, label %bb_rcgdone456
bb_rcgnn456:
  %v2351 = load i64, ptr %slot355, align 8
  %op2352 = sub i64 %v2351, 16
  store i64 %op2352, ptr %slot357, align 8
  %v2353 = load i64, ptr %slot355, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %rgep2355 = getelementptr i8, ptr %p2354, i64 -16
  %ld2356 = load i64, ptr %rgep2355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2356, ptr %slot358, align 8
  %v2357 = load i64, ptr %slot358, align 8
  %op2358 = and i64 %v2357, 4611686018427387906
  store i64 %op2358, ptr %slot359, align 8
  %v2359 = load i64, ptr %slot359, align 8
  %cmp2360 = icmp ne i64 %v2359, 0
  %cv2361 = zext i1 %cmp2360 to i32
  store i32 %cv2361, ptr %slot360, align 8
  %v2362 = load i32, ptr %slot360, align 8
  %cv2363 = zext i32 %v2362 to i64
  %cond2364 = icmp ne i64 %cv2363, 0
  br i1 %cond2364, label %bb_rcgclear456, label %bb_rcgcounted456
bb_rcgcounted456:
  %v2365 = load i64, ptr %slot355, align 8
  %op2366 = sub i64 %v2365, 24
  store i64 %op2366, ptr %slot361, align 8
  %v2367 = load i64, ptr %slot355, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %rgep2369 = getelementptr i8, ptr %p2368, i64 -24
  %ld2370 = load i64, ptr %rgep2369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2370, ptr %slot362, align 8
  %v2371 = load i64, ptr %slot362, align 8
  %op2372 = sub i64 %v2371, 1
  store i64 %op2372, ptr %slot363, align 8
  %v2373 = load i64, ptr %slot363, align 8
  %cmp2374 = icmp eq i64 %v2373, 0
  %cv2375 = zext i1 %cmp2374 to i32
  store i32 %cv2375, ptr %slot364, align 8
  %v2376 = load i32, ptr %slot364, align 8
  %cv2377 = zext i32 %v2376 to i64
  %cond2378 = icmp ne i64 %cv2377, 0
  br i1 %cond2378, label %bb_rcglast456, label %bb_rcgdec456
bb_rcglast456:
  %v2379 = load i64, ptr %slot355, align 8
  %op2380 = sub i64 %v2379, 32
  store i64 %op2380, ptr %slot365, align 8
  %v2381 = load i64, ptr %slot355, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %rgep2383 = getelementptr i8, ptr %p2382, i64 -32
  %ld2384 = load i64, ptr %rgep2383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2384, ptr %slot366, align 8
  %v2385 = load i64, ptr %slot366, align 8
  %cmp2386 = icmp ne i64 %v2385, 0
  %cv2387 = zext i1 %cmp2386 to i32
  store i32 %cv2387, ptr %slot367, align 8
  %v2388 = load i32, ptr %slot367, align 8
  %cv2389 = zext i32 %v2388 to i64
  %cond2390 = icmp ne i64 %cv2389, 0
  br i1 %cond2390, label %bb_rcgdec456, label %bb_rcgslow456
bb_rcgslow456:
  %v2391 = load i64, ptr %slot354, align 8
  %v2392 = load i64, ptr %slot351, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v2391, i64 %v2392) nomerge, !dbg !122
  br label %bb_rcgdone456
bb_rcgdec456:
  %v2393 = load i64, ptr %slot363, align 8
  %v2394 = load i64, ptr %slot355, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %rgep2396 = getelementptr i8, ptr %p2395, i64 -24
  store i64 %v2393, ptr %rgep2396, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear456
bb_rcgclear456:
  %v2397 = load i64, ptr %slot351, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i64 0, ptr %p2398, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone456
bb_rcgdone456:
  br label %bb_rcslotdone440
bb_rcslotowner440:
  %v2399 = load i64, ptr %slot33, align 8
  store i64 %v2399, ptr %slot368, align 8
  %v2400 = load i64, ptr %slot351, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot369, align 8
  %v2403 = load i64, ptr %slot369, align 8
  %cmp2404 = icmp ne i64 %v2403, 0
  %cv2405 = zext i1 %cmp2404 to i32
  store i32 %cv2405, ptr %slot370, align 8
  %v2406 = load i32, ptr %slot370, align 8
  %cv2407 = zext i32 %v2406 to i64
  %cond2408 = icmp ne i64 %cv2407, 0
  br i1 %cond2408, label %bb_rcgnn471, label %bb_rcgdone471
bb_rcgnn471:
  %v2409 = load i64, ptr %slot369, align 8
  %op2410 = sub i64 %v2409, 16
  store i64 %op2410, ptr %slot371, align 8
  %v2411 = load i64, ptr %slot369, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %rgep2413 = getelementptr i8, ptr %p2412, i64 -16
  %ld2414 = load i64, ptr %rgep2413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2414, ptr %slot372, align 8
  %v2415 = load i64, ptr %slot372, align 8
  %op2416 = and i64 %v2415, 4611686018427387906
  store i64 %op2416, ptr %slot373, align 8
  %v2417 = load i64, ptr %slot373, align 8
  %cmp2418 = icmp ne i64 %v2417, 0
  %cv2419 = zext i1 %cmp2418 to i32
  store i32 %cv2419, ptr %slot374, align 8
  %v2420 = load i32, ptr %slot374, align 8
  %cv2421 = zext i32 %v2420 to i64
  %cond2422 = icmp ne i64 %cv2421, 0
  br i1 %cond2422, label %bb_rcgclear471, label %bb_rcgcounted471
bb_rcgcounted471:
  %v2423 = load i64, ptr %slot369, align 8
  %op2424 = sub i64 %v2423, 32
  store i64 %op2424, ptr %slot375, align 8
  %v2425 = load i64, ptr %slot369, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %rgep2427 = getelementptr i8, ptr %p2426, i64 -32
  %ld2428 = load i64, ptr %rgep2427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2428, ptr %slot376, align 8
  %v2429 = load i64, ptr %slot376, align 8
  %op2430 = sub i64 %v2429, 1
  store i64 %op2430, ptr %slot377, align 8
  %v2431 = load i64, ptr %slot377, align 8
  %cmp2432 = icmp eq i64 %v2431, 0
  %cv2433 = zext i1 %cmp2432 to i32
  store i32 %cv2433, ptr %slot378, align 8
  %v2434 = load i32, ptr %slot378, align 8
  %cv2435 = zext i32 %v2434 to i64
  %cond2436 = icmp ne i64 %cv2435, 0
  br i1 %cond2436, label %bb_rcglast471, label %bb_rcgdec471
bb_rcglast471:
  %v2437 = load i64, ptr %slot369, align 8
  %op2438 = sub i64 %v2437, 24
  store i64 %op2438, ptr %slot379, align 8
  %v2439 = load i64, ptr %slot369, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %rgep2441 = getelementptr i8, ptr %p2440, i64 -24
  %ld2442 = load i64, ptr %rgep2441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2442, ptr %slot380, align 8
  %v2443 = load i64, ptr %slot380, align 8
  %cmp2444 = icmp ne i64 %v2443, 0
  %cv2445 = zext i1 %cmp2444 to i32
  store i32 %cv2445, ptr %slot381, align 8
  %v2446 = load i32, ptr %slot381, align 8
  %cv2447 = zext i32 %v2446 to i64
  %cond2448 = icmp ne i64 %cv2447, 0
  br i1 %cond2448, label %bb_rcgdec471, label %bb_rcgslow471
bb_rcgslow471:
  %v2449 = load i64, ptr %slot368, align 8
  %v2450 = load i64, ptr %slot351, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v2449, i64 %v2450) nomerge, !dbg !122
  br label %bb_rcgdone471
bb_rcgdec471:
  %v2451 = load i64, ptr %slot377, align 8
  %v2452 = load i64, ptr %slot369, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %rgep2454 = getelementptr i8, ptr %p2453, i64 -32
  store i64 %v2451, ptr %rgep2454, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear471
bb_rcgclear471:
  %v2455 = load i64, ptr %slot351, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  store i64 0, ptr %p2456, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone471
bb_rcgdone471:
  br label %bb_rcslotdone440
bb_rcslotdone440:
  %v2457 = load i64, ptr %slot28, align 8
  store i64 %v2457, ptr %slot382, align 8
  %v2458 = load i64, ptr %slot25, align 8
  store i64 %v2458, ptr %slot383, align 8
  %v2459 = load i64, ptr %slot383, align 8
  %v2460 = load i64, ptr %slot382, align 8
  %p2461 = inttoptr i64 %v2459 to ptr
  %p2462 = inttoptr i64 %v2460 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2462, ptr %p2461, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot16, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 0, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  %v2465 = load i64, ptr %slot9, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i32 2, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot17, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  %ld2469 = load i32, ptr %p2468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2469, ptr %slot384, align 8
  %v2470 = load i32, ptr %slot384, align 8
  %v2471 = load i64, ptr %slot9, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  store i32 %v2470, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  %v2473 = load i64, ptr %slot8, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  store i32 1, ptr %p2474, align 4, !alias.scope !3, !noalias !4
  %v2475 = load i64, ptr %slot28, align 8
  %p2476 = inttoptr i64 %v2475 to ptr
  %ld2477 = load i64, ptr %p2476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2477, ptr %slot385, align 8
  %v2478 = load i64, ptr %slot385, align 8
  %v2479 = load i64, ptr %slot31, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  store i64 %v2478, ptr %p2480, align 8, !alias.scope !3, !noalias !4
  %v2481 = load i64, ptr %slot32, align 8
  store i64 %v2481, ptr %slot386, align 8
  %v2482 = load i64, ptr %slot386, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i64 0, ptr %p2483, align 8, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot386, align 8
  %p2486 = inttoptr i64 %v2484 to ptr
  %gep2487 = getelementptr i8, ptr %p2486, i64 8
  %op2485 = ptrtoint ptr %gep2487 to i64
  store i64 %op2485, ptr %slot387, align 8
  %v2488 = load i64, ptr %slot387, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i64 0, ptr %p2489, align 8, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot386, align 8
  %p2492 = inttoptr i64 %v2490 to ptr
  %gep2493 = getelementptr i8, ptr %p2492, i64 16
  %op2491 = ptrtoint ptr %gep2493 to i64
  store i64 %op2491, ptr %slot388, align 8
  %v2494 = load i64, ptr %slot388, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i64 0, ptr %p2495, align 8, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot18, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 1, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot34, align 8
  store i64 %v2498, ptr %slot389, align 8
  %v2499 = load i64, ptr %slot29, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i64, ptr %p2500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2501, ptr %slot390, align 8
  %v2502 = load i64, ptr %slot390, align 8
  %v2503 = load i64, ptr %slot22, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i64 %v2502, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  %v2505 = load i64, ptr %slot22, align 8
  store i64 %v2505, ptr %slot391, align 8
  %v2506 = load i64, ptr %slot386, align 8
  %p2508 = inttoptr i64 %v2506 to ptr
  %gep2509 = getelementptr i8, ptr %p2508, i64 0
  %op2507 = ptrtoint ptr %gep2509 to i64
  store i64 %op2507, ptr %slot392, align 8
  %v2510 = load i64, ptr %slot29, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %ld2512 = load i64, ptr %p2511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2512, ptr %slot393, align 8
  %v2513 = load i64, ptr %slot393, align 8
  %v2514 = load i64, ptr %slot22, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  store i64 %v2513, ptr %p2515, align 8, !alias.scope !3, !noalias !4
  %v2516 = load i64, ptr %slot22, align 8
  store i64 %v2516, ptr %slot394, align 8
  %v2517 = load i64, ptr %slot10, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  %ld2519 = load i32, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2519, ptr %slot395, align 8
  %v2520 = load i64, ptr %slot11, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  %ld2522 = load i32, ptr %p2521, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2522, ptr %slot396, align 8
  %v2523 = load i32, ptr %slot396, align 8
  %op2524 = and i32 %v2523, 24
  store i32 %op2524, ptr %slot396, align 8
  %v2525 = load i32, ptr %slot396, align 8
  %cmp2526 = icmp eq i32 %v2525, 0
  %cv2527 = zext i1 %cmp2526 to i32
  store i32 %cv2527, ptr %slot397, align 8
  %v2528 = load i32, ptr %slot395, align 8
  %v2529 = load i32, ptr %slot397, align 8
  %op2530 = and i32 %v2528, %v2529
  store i32 %op2530, ptr %slot398, align 8
  %v2531 = load i32, ptr %slot398, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rctake494, label %bb_rccopy494
bb_rctake494:
  %v2534 = load i64, ptr %slot25, align 8
  store i64 %v2534, ptr %slot399, align 8
  %v2535 = load i64, ptr %slot34, align 8
  store i64 %v2535, ptr %slot400, align 8
  %v2536 = load i64, ptr %slot394, align 8
  %v2537 = load i64, ptr %slot399, align 8
  %op2538 = sub i64 %v2536, %v2537
  store i64 %op2538, ptr %slot401, align 8
  %v2539 = load i64, ptr %slot399, align 8
  %v2540 = load i64, ptr %slot394, align 8
  %op2541 = sub i64 %v2539, %v2540
  store i64 %op2541, ptr %slot402, align 8
  %v2542 = load i64, ptr %slot401, align 8
  %cmp2543 = icmp ult i64 %v2542, 8
  %cv2544 = zext i1 %cmp2543 to i32
  store i32 %cv2544, ptr %slot403, align 8
  %v2545 = load i64, ptr %slot402, align 8
  %cmp2546 = icmp ult i64 %v2545, 8
  %cv2547 = zext i1 %cmp2546 to i32
  store i32 %cv2547, ptr %slot404, align 8
  %v2548 = load i32, ptr %slot403, align 8
  %v2549 = load i32, ptr %slot404, align 8
  %op2550 = or i32 %v2548, %v2549
  store i32 %op2550, ptr %slot405, align 8
  %v2551 = load i32, ptr %slot405, align 8
  %cv2552 = zext i32 %v2551 to i64
  %cond2553 = icmp ne i64 %cv2552, 0
  br i1 %cond2553, label %bb_rcmoveslow503, label %bb_rcmovecheck503
bb_rcmovecheck503:
  %v2554 = load i64, ptr %slot394, align 8
  %p2556 = inttoptr i64 %v2554 to ptr
  %gep2557 = getelementptr i8, ptr %p2556, i64 0
  %op2555 = ptrtoint ptr %gep2557 to i64
  store i64 %op2555, ptr %slot406, align 8
  %v2558 = load i64, ptr %slot406, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  %ld2560 = load i64, ptr %p2559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2560, ptr %slot407, align 8
  %v2561 = load i64, ptr %slot407, align 8
  %cmp2562 = icmp ne i64 %v2561, 0
  %cv2563 = zext i1 %cmp2562 to i32
  store i32 %cv2563, ptr %slot408, align 8
  %v2564 = load i32, ptr %slot408, align 8
  %cv2565 = zext i32 %v2564 to i64
  %cond2566 = icmp ne i64 %cv2565, 0
  br i1 %cond2566, label %bb_rcmoveheader511, label %bb_rcmovenext511
bb_rcmoveheader511:
  %v2567 = load i64, ptr %slot407, align 8
  %op2568 = sub i64 %v2567, 16
  store i64 %op2568, ptr %slot409, align 8
  %v2569 = load i64, ptr %slot407, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  %rgep2571 = getelementptr i8, ptr %p2570, i64 -16
  %ld2572 = load i64, ptr %rgep2571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2572, ptr %slot410, align 8
  %v2573 = load i64, ptr %slot410, align 8
  %op2574 = and i64 %v2573, 5764607523034234881
  store i64 %op2574, ptr %slot411, align 8
  %v2575 = load i64, ptr %slot411, align 8
  %cmp2576 = icmp ne i64 %v2575, 0
  %cv2577 = zext i1 %cmp2576 to i32
  store i32 %cv2577, ptr %slot412, align 8
  %v2578 = load i32, ptr %slot412, align 8
  %cv2579 = zext i32 %v2578 to i64
  %cond2580 = icmp ne i64 %cv2579, 0
  br i1 %cond2580, label %bb_rcmoveslow503, label %bb_rcmovenext511
bb_rcmovenext511:
  %v2581 = load i64, ptr %slot394, align 8
  %v2582 = load i64, ptr %slot399, align 8
  %p2583 = inttoptr i64 %v2581 to ptr
  %p2584 = inttoptr i64 %v2582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2584, ptr %p2583, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2585 = load i64, ptr %slot394, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i64 0, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved503
bb_rcmoveslow503:
  %v2587 = load i64, ptr %slot33, align 8
  %v2588 = load i64, ptr %slot399, align 8
  %v2589 = load i64, ptr %slot394, align 8
  %v2590 = load i64, ptr %slot400, align 8
  %cv2591 = trunc i64 %v2590 to i32
  %call2592 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2587, i64 %v2588, i64 %v2589, i32 %cv2591) nomerge, !dbg !124
  store i32 %call2592, ptr %slot413, align 8
  %v2593 = load i32, ptr %slot413, align 8
  %cv2594 = zext i32 %v2593 to i64
  %cond2595 = icmp ne i64 %cv2594, 0
  br i1 %cond2595, label %bb_rcsuccess518, label %bb_rcfailure518
bb_rcfailure518:
  %v2596 = load i64, ptr %slot33, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  %call2598 = call i32 @myl_rc_take_failure(ptr %p2597) nomerge, !dbg !124
  store i32 %call2598, ptr %slot414, align 8
  %v2599 = load i64, ptr %slot1, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  %v2601 = load i32, ptr %slot414, align 8
  %call2602 = call i32 @myl_qbe_rc_status(ptr %p2600, i32 %v2601) nomerge, !dbg !124
  store i32 %call2602, ptr %slot415, align 8
  br label %bb_failure
bb_rcsuccess518:
  br label %bb_rcmoved503
bb_rcmoved503:
  %v2603 = load i64, ptr %slot10, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  store i32 0, ptr %p2604, align 4, !alias.scope !3, !noalias !4
  %v2605 = load i64, ptr %slot17, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  store i32 2, ptr %p2606, align 4, !alias.scope !3, !noalias !4
  %v2607 = load i64, ptr %slot16, align 8
  %p2608 = inttoptr i64 %v2607 to ptr
  store i32 1, ptr %p2608, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared494
bb_rccopy494:
  %v2609 = load i64, ptr %slot25, align 8
  store i64 %v2609, ptr %slot416, align 8
  %v2610 = load i64, ptr %slot34, align 8
  store i64 %v2610, ptr %slot417, align 8
  %v2611 = load i64, ptr %slot394, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i64, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2613, ptr %slot418, align 8
  %v2614 = load i64, ptr %slot418, align 8
  %cmp2615 = icmp ne i64 %v2614, 0
  %cv2616 = zext i1 %cmp2615 to i32
  store i32 %cv2616, ptr %slot419, align 8
  %v2617 = load i32, ptr %slot419, align 8
  %cv2618 = zext i32 %v2617 to i64
  %cond2619 = icmp ne i64 %cv2618, 0
  br i1 %cond2619, label %bb_rcgnn527, label %bb_rcgplain527
bb_rcgnn527:
  %v2620 = load i64, ptr %slot418, align 8
  %op2621 = sub i64 %v2620, 16
  store i64 %op2621, ptr %slot420, align 8
  %v2622 = load i64, ptr %slot418, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %rgep2624 = getelementptr i8, ptr %p2623, i64 -16
  %ld2625 = load i64, ptr %rgep2624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2625, ptr %slot421, align 8
  %v2626 = load i64, ptr %slot421, align 8
  %op2627 = and i64 %v2626, 4611686018427387906
  store i64 %op2627, ptr %slot422, align 8
  %v2628 = load i64, ptr %slot422, align 8
  %cmp2629 = icmp ne i64 %v2628, 0
  %cv2630 = zext i1 %cmp2629 to i32
  store i32 %cv2630, ptr %slot423, align 8
  %v2631 = load i32, ptr %slot423, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcgspecial527, label %bb_rcginc527
bb_rcginc527:
  %v2634 = load i64, ptr %slot418, align 8
  %op2635 = sub i64 %v2634, 32
  store i64 %op2635, ptr %slot424, align 8
  %v2636 = load i64, ptr %slot418, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %rgep2638 = getelementptr i8, ptr %p2637, i64 -32
  %ld2639 = load i64, ptr %rgep2638, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2639, ptr %slot425, align 8
  %v2640 = load i64, ptr %slot425, align 8
  %op2641 = add i64 %v2640, 1
  store i64 %op2641, ptr %slot426, align 8
  %v2642 = load i64, ptr %slot426, align 8
  %cmp2643 = icmp eq i64 %v2642, 0
  %cv2644 = zext i1 %cmp2643 to i32
  store i32 %cv2644, ptr %slot427, align 8
  %v2645 = load i32, ptr %slot427, align 8
  %cv2646 = zext i32 %v2645 to i64
  %cond2647 = icmp ne i64 %cv2646, 0
  br i1 %cond2647, label %bb_rcglimit527, label %bb_rcgcapacity527
bb_rcglimit527:
  %v2648 = load i64, ptr %slot1, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %call2650 = call i32 @myl_qbe_rc_status(ptr %p2649, i32 2) nomerge, !dbg !124
  store i32 %call2650, ptr %slot428, align 8
  br label %bb_failure
bb_rcgcapacity527:
  %v2651 = load i64, ptr %slot426, align 8
  %v2652 = load i64, ptr %slot418, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %rgep2654 = getelementptr i8, ptr %p2653, i64 -32
  store i64 %v2651, ptr %rgep2654, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain527
bb_rcgspecial527:
  %v2655 = load i64, ptr %slot421, align 8
  %op2656 = and i64 %v2655, 4611686018427387904
  store i64 %op2656, ptr %slot429, align 8
  %v2657 = load i64, ptr %slot429, align 8
  %cmp2658 = icmp ne i64 %v2657, 0
  %cv2659 = zext i1 %cmp2658 to i32
  store i32 %cv2659, ptr %slot430, align 8
  %v2660 = load i32, ptr %slot430, align 8
  %cv2661 = zext i32 %v2660 to i64
  %cond2662 = icmp ne i64 %cv2661, 0
  br i1 %cond2662, label %bb_rcgslow527, label %bb_rcgplain527
bb_rcgslow527:
  %v2663 = load i64, ptr %slot33, align 8
  %v2664 = load i64, ptr %slot416, align 8
  %v2665 = load i64, ptr %slot394, align 8
  %v2666 = load i64, ptr %slot417, align 8
  %cv2667 = trunc i64 %v2666 to i32
  %call2668 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v2663, i64 %v2664, i64 %v2665, i32 %cv2667) nomerge, !dbg !124
  store i32 %call2668, ptr %slot431, align 8
  %v2669 = load i32, ptr %slot431, align 8
  %cv2670 = zext i32 %v2669 to i64
  %cond2671 = icmp ne i64 %cv2670, 0
  br i1 %cond2671, label %bb_rcsuccess541, label %bb_rcfailure541
bb_rcfailure541:
  %v2672 = load i64, ptr %slot33, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  %call2674 = call i32 @myl_rc_take_failure(ptr %p2673) nomerge, !dbg !124
  store i32 %call2674, ptr %slot432, align 8
  %v2675 = load i64, ptr %slot1, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %v2677 = load i32, ptr %slot432, align 8
  %call2678 = call i32 @myl_qbe_rc_status(ptr %p2676, i32 %v2677) nomerge, !dbg !124
  store i32 %call2678, ptr %slot433, align 8
  br label %bb_failure
bb_rcsuccess541:
  br label %bb_rcgdone527
bb_rcgplain527:
  %v2679 = load i64, ptr %slot418, align 8
  %v2680 = load i64, ptr %slot416, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i64 %v2679, ptr %p2681, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone527
bb_rcgdone527:
  %v2682 = load i64, ptr %slot17, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i32 2, ptr %p2683, align 4, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot16, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i32 1, ptr %p2685, align 4, !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot10, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  %ld2688 = load i32, ptr %p2687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2688, ptr %slot434, align 8
  %v2689 = load i32, ptr %slot434, align 8
  %cv2690 = zext i32 %v2689 to i64
  %cond2691 = icmp ne i64 %cv2690, 0
  br i1 %cond2691, label %bb_rcslotdrop548, label %bb_rcslotdone548
bb_rcslotdrop548:
  %v2692 = load i64, ptr %slot10, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i32 0, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot19, align 8
  store i64 %v2694, ptr %slot435, align 8
  %v2695 = load i64, ptr %slot11, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %ld2697 = load i32, ptr %p2696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2697, ptr %slot436, align 8
  %v2698 = load i32, ptr %slot436, align 8
  %op2699 = and i32 %v2698, 28
  store i32 %op2699, ptr %slot437, align 8
  %v2700 = load i32, ptr %slot437, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcslotrole548, label %bb_rcslotowner548
bb_rcslotrole548:
  %v2703 = load i64, ptr %slot33, align 8
  store i64 %v2703, ptr %slot438, align 8
  %v2704 = load i64, ptr %slot435, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  %ld2706 = load i64, ptr %p2705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2706, ptr %slot439, align 8
  %v2707 = load i64, ptr %slot439, align 8
  %cmp2708 = icmp ne i64 %v2707, 0
  %cv2709 = zext i1 %cmp2708 to i32
  store i32 %cv2709, ptr %slot440, align 8
  %v2710 = load i32, ptr %slot440, align 8
  %cv2711 = zext i32 %v2710 to i64
  %cond2712 = icmp ne i64 %cv2711, 0
  br i1 %cond2712, label %bb_rcgnn564, label %bb_rcgdone564
bb_rcgnn564:
  %v2713 = load i64, ptr %slot439, align 8
  %op2714 = sub i64 %v2713, 16
  store i64 %op2714, ptr %slot441, align 8
  %v2715 = load i64, ptr %slot439, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %rgep2717 = getelementptr i8, ptr %p2716, i64 -16
  %ld2718 = load i64, ptr %rgep2717, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2718, ptr %slot442, align 8
  %v2719 = load i64, ptr %slot442, align 8
  %op2720 = and i64 %v2719, 4611686018427387906
  store i64 %op2720, ptr %slot443, align 8
  %v2721 = load i64, ptr %slot443, align 8
  %cmp2722 = icmp ne i64 %v2721, 0
  %cv2723 = zext i1 %cmp2722 to i32
  store i32 %cv2723, ptr %slot444, align 8
  %v2724 = load i32, ptr %slot444, align 8
  %cv2725 = zext i32 %v2724 to i64
  %cond2726 = icmp ne i64 %cv2725, 0
  br i1 %cond2726, label %bb_rcgclear564, label %bb_rcgcounted564
bb_rcgcounted564:
  %v2727 = load i64, ptr %slot439, align 8
  %op2728 = sub i64 %v2727, 24
  store i64 %op2728, ptr %slot445, align 8
  %v2729 = load i64, ptr %slot439, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %rgep2731 = getelementptr i8, ptr %p2730, i64 -24
  %ld2732 = load i64, ptr %rgep2731, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2732, ptr %slot446, align 8
  %v2733 = load i64, ptr %slot446, align 8
  %op2734 = sub i64 %v2733, 1
  store i64 %op2734, ptr %slot447, align 8
  %v2735 = load i64, ptr %slot447, align 8
  %cmp2736 = icmp eq i64 %v2735, 0
  %cv2737 = zext i1 %cmp2736 to i32
  store i32 %cv2737, ptr %slot448, align 8
  %v2738 = load i32, ptr %slot448, align 8
  %cv2739 = zext i32 %v2738 to i64
  %cond2740 = icmp ne i64 %cv2739, 0
  br i1 %cond2740, label %bb_rcglast564, label %bb_rcgdec564
bb_rcglast564:
  %v2741 = load i64, ptr %slot439, align 8
  %op2742 = sub i64 %v2741, 32
  store i64 %op2742, ptr %slot449, align 8
  %v2743 = load i64, ptr %slot439, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %rgep2745 = getelementptr i8, ptr %p2744, i64 -32
  %ld2746 = load i64, ptr %rgep2745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2746, ptr %slot450, align 8
  %v2747 = load i64, ptr %slot450, align 8
  %cmp2748 = icmp ne i64 %v2747, 0
  %cv2749 = zext i1 %cmp2748 to i32
  store i32 %cv2749, ptr %slot451, align 8
  %v2750 = load i32, ptr %slot451, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcgdec564, label %bb_rcgslow564
bb_rcgslow564:
  %v2753 = load i64, ptr %slot438, align 8
  %v2754 = load i64, ptr %slot435, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2753, i64 %v2754) nomerge, !dbg !124
  br label %bb_rcgdone564
bb_rcgdec564:
  %v2755 = load i64, ptr %slot447, align 8
  %v2756 = load i64, ptr %slot439, align 8
  %p2757 = inttoptr i64 %v2756 to ptr
  %rgep2758 = getelementptr i8, ptr %p2757, i64 -24
  store i64 %v2755, ptr %rgep2758, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear564
bb_rcgclear564:
  %v2759 = load i64, ptr %slot435, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  store i64 0, ptr %p2760, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone564
bb_rcgdone564:
  br label %bb_rcslotdone548
bb_rcslotowner548:
  %v2761 = load i64, ptr %slot33, align 8
  store i64 %v2761, ptr %slot452, align 8
  %v2762 = load i64, ptr %slot435, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  %ld2764 = load i64, ptr %p2763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2764, ptr %slot453, align 8
  %v2765 = load i64, ptr %slot453, align 8
  %cmp2766 = icmp ne i64 %v2765, 0
  %cv2767 = zext i1 %cmp2766 to i32
  store i32 %cv2767, ptr %slot454, align 8
  %v2768 = load i32, ptr %slot454, align 8
  %cv2769 = zext i32 %v2768 to i64
  %cond2770 = icmp ne i64 %cv2769, 0
  br i1 %cond2770, label %bb_rcgnn579, label %bb_rcgdone579
bb_rcgnn579:
  %v2771 = load i64, ptr %slot453, align 8
  %op2772 = sub i64 %v2771, 16
  store i64 %op2772, ptr %slot455, align 8
  %v2773 = load i64, ptr %slot453, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %rgep2775 = getelementptr i8, ptr %p2774, i64 -16
  %ld2776 = load i64, ptr %rgep2775, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2776, ptr %slot456, align 8
  %v2777 = load i64, ptr %slot456, align 8
  %op2778 = and i64 %v2777, 4611686018427387906
  store i64 %op2778, ptr %slot457, align 8
  %v2779 = load i64, ptr %slot457, align 8
  %cmp2780 = icmp ne i64 %v2779, 0
  %cv2781 = zext i1 %cmp2780 to i32
  store i32 %cv2781, ptr %slot458, align 8
  %v2782 = load i32, ptr %slot458, align 8
  %cv2783 = zext i32 %v2782 to i64
  %cond2784 = icmp ne i64 %cv2783, 0
  br i1 %cond2784, label %bb_rcgclear579, label %bb_rcgcounted579
bb_rcgcounted579:
  %v2785 = load i64, ptr %slot453, align 8
  %op2786 = sub i64 %v2785, 32
  store i64 %op2786, ptr %slot459, align 8
  %v2787 = load i64, ptr %slot453, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  %rgep2789 = getelementptr i8, ptr %p2788, i64 -32
  %ld2790 = load i64, ptr %rgep2789, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2790, ptr %slot460, align 8
  %v2791 = load i64, ptr %slot460, align 8
  %op2792 = sub i64 %v2791, 1
  store i64 %op2792, ptr %slot461, align 8
  %v2793 = load i64, ptr %slot461, align 8
  %cmp2794 = icmp eq i64 %v2793, 0
  %cv2795 = zext i1 %cmp2794 to i32
  store i32 %cv2795, ptr %slot462, align 8
  %v2796 = load i32, ptr %slot462, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcglast579, label %bb_rcgdec579
bb_rcglast579:
  %v2799 = load i64, ptr %slot453, align 8
  %op2800 = sub i64 %v2799, 24
  store i64 %op2800, ptr %slot463, align 8
  %v2801 = load i64, ptr %slot453, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  %rgep2803 = getelementptr i8, ptr %p2802, i64 -24
  %ld2804 = load i64, ptr %rgep2803, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2804, ptr %slot464, align 8
  %v2805 = load i64, ptr %slot464, align 8
  %cmp2806 = icmp ne i64 %v2805, 0
  %cv2807 = zext i1 %cmp2806 to i32
  store i32 %cv2807, ptr %slot465, align 8
  %v2808 = load i32, ptr %slot465, align 8
  %cv2809 = zext i32 %v2808 to i64
  %cond2810 = icmp ne i64 %cv2809, 0
  br i1 %cond2810, label %bb_rcgdec579, label %bb_rcgslow579
bb_rcgslow579:
  %v2811 = load i64, ptr %slot452, align 8
  %v2812 = load i64, ptr %slot435, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2811, i64 %v2812) nomerge, !dbg !124
  br label %bb_rcgdone579
bb_rcgdec579:
  %v2813 = load i64, ptr %slot461, align 8
  %v2814 = load i64, ptr %slot453, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %rgep2816 = getelementptr i8, ptr %p2815, i64 -32
  store i64 %v2813, ptr %rgep2816, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear579
bb_rcgclear579:
  %v2817 = load i64, ptr %slot435, align 8
  %p2818 = inttoptr i64 %v2817 to ptr
  store i64 0, ptr %p2818, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone579
bb_rcgdone579:
  br label %bb_rcslotdone548
bb_rcslotdone548:
  br label %bb_rcprepared494
bb_rcprepared494:
  %v2819 = load i64, ptr %slot25, align 8
  store i64 %v2819, ptr %slot466, align 8
  %v2820 = load i64, ptr %slot466, align 8
  %v2821 = load i64, ptr %slot392, align 8
  %p2822 = inttoptr i64 %v2820 to ptr
  %p2823 = inttoptr i64 %v2821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2823, ptr %p2822, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2824 = load i64, ptr %slot16, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i32 0, ptr %p2825, align 4, !alias.scope !3, !noalias !4
  %v2826 = load i64, ptr %slot30, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  %ld2828 = load i64, ptr %p2827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2828, ptr %slot467, align 8
  %v2829 = load i64, ptr %slot467, align 8
  %v2830 = load i64, ptr %slot23, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i64 %v2829, ptr %p2831, align 8, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot23, align 8
  store i64 %v2832, ptr %slot468, align 8
  %v2833 = load i64, ptr %slot386, align 8
  %p2835 = inttoptr i64 %v2833 to ptr
  %gep2836 = getelementptr i8, ptr %p2835, i64 8
  %op2834 = ptrtoint ptr %gep2836 to i64
  store i64 %op2834, ptr %slot469, align 8
  %v2837 = load i64, ptr %slot30, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %ld2839 = load i64, ptr %p2838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2839, ptr %slot470, align 8
  %v2840 = load i64, ptr %slot470, align 8
  %v2841 = load i64, ptr %slot23, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  store i64 %v2840, ptr %p2842, align 8, !alias.scope !3, !noalias !4
  %v2843 = load i64, ptr %slot23, align 8
  store i64 %v2843, ptr %slot471, align 8
  %v2844 = load i64, ptr %slot12, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %ld2846 = load i32, ptr %p2845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2846, ptr %slot472, align 8
  %v2847 = load i64, ptr %slot13, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i32, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2849, ptr %slot473, align 8
  %v2850 = load i32, ptr %slot473, align 8
  %op2851 = and i32 %v2850, 24
  store i32 %op2851, ptr %slot473, align 8
  %v2852 = load i32, ptr %slot473, align 8
  %cmp2853 = icmp eq i32 %v2852, 0
  %cv2854 = zext i1 %cmp2853 to i32
  store i32 %cv2854, ptr %slot474, align 8
  %v2855 = load i32, ptr %slot472, align 8
  %v2856 = load i32, ptr %slot474, align 8
  %op2857 = and i32 %v2855, %v2856
  store i32 %op2857, ptr %slot475, align 8
  %v2858 = load i32, ptr %slot475, align 8
  %cv2859 = zext i32 %v2858 to i64
  %cond2860 = icmp ne i64 %cv2859, 0
  br i1 %cond2860, label %bb_rctake590, label %bb_rccopy590
bb_rctake590:
  %v2861 = load i64, ptr %slot25, align 8
  store i64 %v2861, ptr %slot476, align 8
  %v2862 = load i64, ptr %slot34, align 8
  store i64 %v2862, ptr %slot477, align 8
  %v2863 = load i64, ptr %slot471, align 8
  %v2864 = load i64, ptr %slot476, align 8
  %op2865 = sub i64 %v2863, %v2864
  store i64 %op2865, ptr %slot478, align 8
  %v2866 = load i64, ptr %slot476, align 8
  %v2867 = load i64, ptr %slot471, align 8
  %op2868 = sub i64 %v2866, %v2867
  store i64 %op2868, ptr %slot479, align 8
  %v2869 = load i64, ptr %slot478, align 8
  %cmp2870 = icmp ult i64 %v2869, 8
  %cv2871 = zext i1 %cmp2870 to i32
  store i32 %cv2871, ptr %slot480, align 8
  %v2872 = load i64, ptr %slot479, align 8
  %cmp2873 = icmp ult i64 %v2872, 8
  %cv2874 = zext i1 %cmp2873 to i32
  store i32 %cv2874, ptr %slot481, align 8
  %v2875 = load i32, ptr %slot480, align 8
  %v2876 = load i32, ptr %slot481, align 8
  %op2877 = or i32 %v2875, %v2876
  store i32 %op2877, ptr %slot482, align 8
  %v2878 = load i32, ptr %slot482, align 8
  %cv2879 = zext i32 %v2878 to i64
  %cond2880 = icmp ne i64 %cv2879, 0
  br i1 %cond2880, label %bb_rcmoveslow599, label %bb_rcmovecheck599
bb_rcmovecheck599:
  %v2881 = load i64, ptr %slot471, align 8
  %p2883 = inttoptr i64 %v2881 to ptr
  %gep2884 = getelementptr i8, ptr %p2883, i64 0
  %op2882 = ptrtoint ptr %gep2884 to i64
  store i64 %op2882, ptr %slot483, align 8
  %v2885 = load i64, ptr %slot483, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %ld2887 = load i64, ptr %p2886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2887, ptr %slot484, align 8
  %v2888 = load i64, ptr %slot484, align 8
  %cmp2889 = icmp ne i64 %v2888, 0
  %cv2890 = zext i1 %cmp2889 to i32
  store i32 %cv2890, ptr %slot485, align 8
  %v2891 = load i32, ptr %slot485, align 8
  %cv2892 = zext i32 %v2891 to i64
  %cond2893 = icmp ne i64 %cv2892, 0
  br i1 %cond2893, label %bb_rcmoveheader607, label %bb_rcmovenext607
bb_rcmoveheader607:
  %v2894 = load i64, ptr %slot484, align 8
  %op2895 = sub i64 %v2894, 16
  store i64 %op2895, ptr %slot486, align 8
  %v2896 = load i64, ptr %slot484, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %rgep2898 = getelementptr i8, ptr %p2897, i64 -16
  %ld2899 = load i64, ptr %rgep2898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2899, ptr %slot487, align 8
  %v2900 = load i64, ptr %slot487, align 8
  %op2901 = and i64 %v2900, 5764607523034234881
  store i64 %op2901, ptr %slot488, align 8
  %v2902 = load i64, ptr %slot488, align 8
  %cmp2903 = icmp ne i64 %v2902, 0
  %cv2904 = zext i1 %cmp2903 to i32
  store i32 %cv2904, ptr %slot489, align 8
  %v2905 = load i32, ptr %slot489, align 8
  %cv2906 = zext i32 %v2905 to i64
  %cond2907 = icmp ne i64 %cv2906, 0
  br i1 %cond2907, label %bb_rcmoveslow599, label %bb_rcmovenext607
bb_rcmovenext607:
  %v2908 = load i64, ptr %slot471, align 8
  %v2909 = load i64, ptr %slot476, align 8
  %p2910 = inttoptr i64 %v2908 to ptr
  %p2911 = inttoptr i64 %v2909 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2911, ptr %p2910, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2912 = load i64, ptr %slot471, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i64 0, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved599
bb_rcmoveslow599:
  %v2914 = load i64, ptr %slot33, align 8
  %v2915 = load i64, ptr %slot476, align 8
  %v2916 = load i64, ptr %slot471, align 8
  %v2917 = load i64, ptr %slot477, align 8
  %cv2918 = trunc i64 %v2917 to i32
  %call2919 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2914, i64 %v2915, i64 %v2916, i32 %cv2918) nomerge, !dbg !124
  store i32 %call2919, ptr %slot490, align 8
  %v2920 = load i32, ptr %slot490, align 8
  %cv2921 = zext i32 %v2920 to i64
  %cond2922 = icmp ne i64 %cv2921, 0
  br i1 %cond2922, label %bb_rcsuccess614, label %bb_rcfailure614
bb_rcfailure614:
  %v2923 = load i64, ptr %slot33, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %call2925 = call i32 @myl_rc_take_failure(ptr %p2924) nomerge, !dbg !124
  store i32 %call2925, ptr %slot491, align 8
  %v2926 = load i64, ptr %slot1, align 8
  %p2927 = inttoptr i64 %v2926 to ptr
  %v2928 = load i32, ptr %slot491, align 8
  %call2929 = call i32 @myl_qbe_rc_status(ptr %p2927, i32 %v2928) nomerge, !dbg !124
  store i32 %call2929, ptr %slot492, align 8
  br label %bb_failure
bb_rcsuccess614:
  br label %bb_rcmoved599
bb_rcmoved599:
  %v2930 = load i64, ptr %slot12, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  store i32 0, ptr %p2931, align 4, !alias.scope !3, !noalias !4
  %v2932 = load i64, ptr %slot17, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  store i32 2, ptr %p2933, align 4, !alias.scope !3, !noalias !4
  %v2934 = load i64, ptr %slot16, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  store i32 1, ptr %p2935, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared590
bb_rccopy590:
  %v2936 = load i64, ptr %slot25, align 8
  store i64 %v2936, ptr %slot493, align 8
  %v2937 = load i64, ptr %slot34, align 8
  store i64 %v2937, ptr %slot494, align 8
  %v2938 = load i64, ptr %slot471, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %ld2940 = load i64, ptr %p2939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2940, ptr %slot495, align 8
  %v2941 = load i64, ptr %slot495, align 8
  %cmp2942 = icmp ne i64 %v2941, 0
  %cv2943 = zext i1 %cmp2942 to i32
  store i32 %cv2943, ptr %slot496, align 8
  %v2944 = load i32, ptr %slot496, align 8
  %cv2945 = zext i32 %v2944 to i64
  %cond2946 = icmp ne i64 %cv2945, 0
  br i1 %cond2946, label %bb_rcgnn623, label %bb_rcgplain623
bb_rcgnn623:
  %v2947 = load i64, ptr %slot495, align 8
  %op2948 = sub i64 %v2947, 16
  store i64 %op2948, ptr %slot497, align 8
  %v2949 = load i64, ptr %slot495, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %rgep2951 = getelementptr i8, ptr %p2950, i64 -16
  %ld2952 = load i64, ptr %rgep2951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2952, ptr %slot498, align 8
  %v2953 = load i64, ptr %slot498, align 8
  %op2954 = and i64 %v2953, 4611686018427387906
  store i64 %op2954, ptr %slot499, align 8
  %v2955 = load i64, ptr %slot499, align 8
  %cmp2956 = icmp ne i64 %v2955, 0
  %cv2957 = zext i1 %cmp2956 to i32
  store i32 %cv2957, ptr %slot500, align 8
  %v2958 = load i32, ptr %slot500, align 8
  %cv2959 = zext i32 %v2958 to i64
  %cond2960 = icmp ne i64 %cv2959, 0
  br i1 %cond2960, label %bb_rcgspecial623, label %bb_rcginc623
bb_rcginc623:
  %v2961 = load i64, ptr %slot495, align 8
  %op2962 = sub i64 %v2961, 32
  store i64 %op2962, ptr %slot501, align 8
  %v2963 = load i64, ptr %slot495, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %rgep2965 = getelementptr i8, ptr %p2964, i64 -32
  %ld2966 = load i64, ptr %rgep2965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2966, ptr %slot502, align 8
  %v2967 = load i64, ptr %slot502, align 8
  %op2968 = add i64 %v2967, 1
  store i64 %op2968, ptr %slot503, align 8
  %v2969 = load i64, ptr %slot503, align 8
  %cmp2970 = icmp eq i64 %v2969, 0
  %cv2971 = zext i1 %cmp2970 to i32
  store i32 %cv2971, ptr %slot504, align 8
  %v2972 = load i32, ptr %slot504, align 8
  %cv2973 = zext i32 %v2972 to i64
  %cond2974 = icmp ne i64 %cv2973, 0
  br i1 %cond2974, label %bb_rcglimit623, label %bb_rcgcapacity623
bb_rcglimit623:
  %v2975 = load i64, ptr %slot1, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  %call2977 = call i32 @myl_qbe_rc_status(ptr %p2976, i32 2) nomerge, !dbg !124
  store i32 %call2977, ptr %slot505, align 8
  br label %bb_failure
bb_rcgcapacity623:
  %v2978 = load i64, ptr %slot503, align 8
  %v2979 = load i64, ptr %slot495, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  %rgep2981 = getelementptr i8, ptr %p2980, i64 -32
  store i64 %v2978, ptr %rgep2981, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain623
bb_rcgspecial623:
  %v2982 = load i64, ptr %slot498, align 8
  %op2983 = and i64 %v2982, 4611686018427387904
  store i64 %op2983, ptr %slot506, align 8
  %v2984 = load i64, ptr %slot506, align 8
  %cmp2985 = icmp ne i64 %v2984, 0
  %cv2986 = zext i1 %cmp2985 to i32
  store i32 %cv2986, ptr %slot507, align 8
  %v2987 = load i32, ptr %slot507, align 8
  %cv2988 = zext i32 %v2987 to i64
  %cond2989 = icmp ne i64 %cv2988, 0
  br i1 %cond2989, label %bb_rcgslow623, label %bb_rcgplain623
bb_rcgslow623:
  %v2990 = load i64, ptr %slot33, align 8
  %v2991 = load i64, ptr %slot493, align 8
  %v2992 = load i64, ptr %slot471, align 8
  %v2993 = load i64, ptr %slot494, align 8
  %cv2994 = trunc i64 %v2993 to i32
  %call2995 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v2990, i64 %v2991, i64 %v2992, i32 %cv2994) nomerge, !dbg !124
  store i32 %call2995, ptr %slot508, align 8
  %v2996 = load i32, ptr %slot508, align 8
  %cv2997 = zext i32 %v2996 to i64
  %cond2998 = icmp ne i64 %cv2997, 0
  br i1 %cond2998, label %bb_rcsuccess637, label %bb_rcfailure637
bb_rcfailure637:
  %v2999 = load i64, ptr %slot33, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  %call3001 = call i32 @myl_rc_take_failure(ptr %p3000) nomerge, !dbg !124
  store i32 %call3001, ptr %slot509, align 8
  %v3002 = load i64, ptr %slot1, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  %v3004 = load i32, ptr %slot509, align 8
  %call3005 = call i32 @myl_qbe_rc_status(ptr %p3003, i32 %v3004) nomerge, !dbg !124
  store i32 %call3005, ptr %slot510, align 8
  br label %bb_failure
bb_rcsuccess637:
  br label %bb_rcgdone623
bb_rcgplain623:
  %v3006 = load i64, ptr %slot495, align 8
  %v3007 = load i64, ptr %slot493, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  store i64 %v3006, ptr %p3008, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone623
bb_rcgdone623:
  %v3009 = load i64, ptr %slot17, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  store i32 2, ptr %p3010, align 4, !alias.scope !3, !noalias !4
  %v3011 = load i64, ptr %slot16, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  store i32 1, ptr %p3012, align 4, !alias.scope !3, !noalias !4
  %v3013 = load i64, ptr %slot12, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i32, ptr %p3014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3015, ptr %slot511, align 8
  %v3016 = load i32, ptr %slot511, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcslotdrop644, label %bb_rcslotdone644
bb_rcslotdrop644:
  %v3019 = load i64, ptr %slot12, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  store i32 0, ptr %p3020, align 4, !alias.scope !3, !noalias !4
  %v3021 = load i64, ptr %slot20, align 8
  store i64 %v3021, ptr %slot512, align 8
  %v3022 = load i64, ptr %slot13, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %ld3024 = load i32, ptr %p3023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3024, ptr %slot513, align 8
  %v3025 = load i32, ptr %slot513, align 8
  %op3026 = and i32 %v3025, 28
  store i32 %op3026, ptr %slot514, align 8
  %v3027 = load i32, ptr %slot514, align 8
  %cv3028 = zext i32 %v3027 to i64
  %cond3029 = icmp ne i64 %cv3028, 0
  br i1 %cond3029, label %bb_rcslotrole644, label %bb_rcslotowner644
bb_rcslotrole644:
  %v3030 = load i64, ptr %slot33, align 8
  store i64 %v3030, ptr %slot515, align 8
  %v3031 = load i64, ptr %slot512, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  %ld3033 = load i64, ptr %p3032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3033, ptr %slot516, align 8
  %v3034 = load i64, ptr %slot516, align 8
  %cmp3035 = icmp ne i64 %v3034, 0
  %cv3036 = zext i1 %cmp3035 to i32
  store i32 %cv3036, ptr %slot517, align 8
  %v3037 = load i32, ptr %slot517, align 8
  %cv3038 = zext i32 %v3037 to i64
  %cond3039 = icmp ne i64 %cv3038, 0
  br i1 %cond3039, label %bb_rcgnn660, label %bb_rcgdone660
bb_rcgnn660:
  %v3040 = load i64, ptr %slot516, align 8
  %op3041 = sub i64 %v3040, 16
  store i64 %op3041, ptr %slot518, align 8
  %v3042 = load i64, ptr %slot516, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  %rgep3044 = getelementptr i8, ptr %p3043, i64 -16
  %ld3045 = load i64, ptr %rgep3044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3045, ptr %slot519, align 8
  %v3046 = load i64, ptr %slot519, align 8
  %op3047 = and i64 %v3046, 4611686018427387906
  store i64 %op3047, ptr %slot520, align 8
  %v3048 = load i64, ptr %slot520, align 8
  %cmp3049 = icmp ne i64 %v3048, 0
  %cv3050 = zext i1 %cmp3049 to i32
  store i32 %cv3050, ptr %slot521, align 8
  %v3051 = load i32, ptr %slot521, align 8
  %cv3052 = zext i32 %v3051 to i64
  %cond3053 = icmp ne i64 %cv3052, 0
  br i1 %cond3053, label %bb_rcgclear660, label %bb_rcgcounted660
bb_rcgcounted660:
  %v3054 = load i64, ptr %slot516, align 8
  %op3055 = sub i64 %v3054, 24
  store i64 %op3055, ptr %slot522, align 8
  %v3056 = load i64, ptr %slot516, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  %rgep3058 = getelementptr i8, ptr %p3057, i64 -24
  %ld3059 = load i64, ptr %rgep3058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3059, ptr %slot523, align 8
  %v3060 = load i64, ptr %slot523, align 8
  %op3061 = sub i64 %v3060, 1
  store i64 %op3061, ptr %slot524, align 8
  %v3062 = load i64, ptr %slot524, align 8
  %cmp3063 = icmp eq i64 %v3062, 0
  %cv3064 = zext i1 %cmp3063 to i32
  store i32 %cv3064, ptr %slot525, align 8
  %v3065 = load i32, ptr %slot525, align 8
  %cv3066 = zext i32 %v3065 to i64
  %cond3067 = icmp ne i64 %cv3066, 0
  br i1 %cond3067, label %bb_rcglast660, label %bb_rcgdec660
bb_rcglast660:
  %v3068 = load i64, ptr %slot516, align 8
  %op3069 = sub i64 %v3068, 32
  store i64 %op3069, ptr %slot526, align 8
  %v3070 = load i64, ptr %slot516, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %rgep3072 = getelementptr i8, ptr %p3071, i64 -32
  %ld3073 = load i64, ptr %rgep3072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3073, ptr %slot527, align 8
  %v3074 = load i64, ptr %slot527, align 8
  %cmp3075 = icmp ne i64 %v3074, 0
  %cv3076 = zext i1 %cmp3075 to i32
  store i32 %cv3076, ptr %slot528, align 8
  %v3077 = load i32, ptr %slot528, align 8
  %cv3078 = zext i32 %v3077 to i64
  %cond3079 = icmp ne i64 %cv3078, 0
  br i1 %cond3079, label %bb_rcgdec660, label %bb_rcgslow660
bb_rcgslow660:
  %v3080 = load i64, ptr %slot515, align 8
  %v3081 = load i64, ptr %slot512, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3080, i64 %v3081) nomerge, !dbg !124
  br label %bb_rcgdone660
bb_rcgdec660:
  %v3082 = load i64, ptr %slot524, align 8
  %v3083 = load i64, ptr %slot516, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %rgep3085 = getelementptr i8, ptr %p3084, i64 -24
  store i64 %v3082, ptr %rgep3085, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear660
bb_rcgclear660:
  %v3086 = load i64, ptr %slot512, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i64 0, ptr %p3087, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone660
bb_rcgdone660:
  br label %bb_rcslotdone644
bb_rcslotowner644:
  %v3088 = load i64, ptr %slot33, align 8
  store i64 %v3088, ptr %slot529, align 8
  %v3089 = load i64, ptr %slot512, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i64, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3091, ptr %slot530, align 8
  %v3092 = load i64, ptr %slot530, align 8
  %cmp3093 = icmp ne i64 %v3092, 0
  %cv3094 = zext i1 %cmp3093 to i32
  store i32 %cv3094, ptr %slot531, align 8
  %v3095 = load i32, ptr %slot531, align 8
  %cv3096 = zext i32 %v3095 to i64
  %cond3097 = icmp ne i64 %cv3096, 0
  br i1 %cond3097, label %bb_rcgnn675, label %bb_rcgdone675
bb_rcgnn675:
  %v3098 = load i64, ptr %slot530, align 8
  %op3099 = sub i64 %v3098, 16
  store i64 %op3099, ptr %slot532, align 8
  %v3100 = load i64, ptr %slot530, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  %rgep3102 = getelementptr i8, ptr %p3101, i64 -16
  %ld3103 = load i64, ptr %rgep3102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3103, ptr %slot533, align 8
  %v3104 = load i64, ptr %slot533, align 8
  %op3105 = and i64 %v3104, 4611686018427387906
  store i64 %op3105, ptr %slot534, align 8
  %v3106 = load i64, ptr %slot534, align 8
  %cmp3107 = icmp ne i64 %v3106, 0
  %cv3108 = zext i1 %cmp3107 to i32
  store i32 %cv3108, ptr %slot535, align 8
  %v3109 = load i32, ptr %slot535, align 8
  %cv3110 = zext i32 %v3109 to i64
  %cond3111 = icmp ne i64 %cv3110, 0
  br i1 %cond3111, label %bb_rcgclear675, label %bb_rcgcounted675
bb_rcgcounted675:
  %v3112 = load i64, ptr %slot530, align 8
  %op3113 = sub i64 %v3112, 32
  store i64 %op3113, ptr %slot536, align 8
  %v3114 = load i64, ptr %slot530, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %rgep3116 = getelementptr i8, ptr %p3115, i64 -32
  %ld3117 = load i64, ptr %rgep3116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3117, ptr %slot537, align 8
  %v3118 = load i64, ptr %slot537, align 8
  %op3119 = sub i64 %v3118, 1
  store i64 %op3119, ptr %slot538, align 8
  %v3120 = load i64, ptr %slot538, align 8
  %cmp3121 = icmp eq i64 %v3120, 0
  %cv3122 = zext i1 %cmp3121 to i32
  store i32 %cv3122, ptr %slot539, align 8
  %v3123 = load i32, ptr %slot539, align 8
  %cv3124 = zext i32 %v3123 to i64
  %cond3125 = icmp ne i64 %cv3124, 0
  br i1 %cond3125, label %bb_rcglast675, label %bb_rcgdec675
bb_rcglast675:
  %v3126 = load i64, ptr %slot530, align 8
  %op3127 = sub i64 %v3126, 24
  store i64 %op3127, ptr %slot540, align 8
  %v3128 = load i64, ptr %slot530, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %rgep3130 = getelementptr i8, ptr %p3129, i64 -24
  %ld3131 = load i64, ptr %rgep3130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3131, ptr %slot541, align 8
  %v3132 = load i64, ptr %slot541, align 8
  %cmp3133 = icmp ne i64 %v3132, 0
  %cv3134 = zext i1 %cmp3133 to i32
  store i32 %cv3134, ptr %slot542, align 8
  %v3135 = load i32, ptr %slot542, align 8
  %cv3136 = zext i32 %v3135 to i64
  %cond3137 = icmp ne i64 %cv3136, 0
  br i1 %cond3137, label %bb_rcgdec675, label %bb_rcgslow675
bb_rcgslow675:
  %v3138 = load i64, ptr %slot529, align 8
  %v3139 = load i64, ptr %slot512, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3138, i64 %v3139) nomerge, !dbg !124
  br label %bb_rcgdone675
bb_rcgdec675:
  %v3140 = load i64, ptr %slot538, align 8
  %v3141 = load i64, ptr %slot530, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  %rgep3143 = getelementptr i8, ptr %p3142, i64 -32
  store i64 %v3140, ptr %rgep3143, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear675
bb_rcgclear675:
  %v3144 = load i64, ptr %slot512, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  store i64 0, ptr %p3145, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone675
bb_rcgdone675:
  br label %bb_rcslotdone644
bb_rcslotdone644:
  br label %bb_rcprepared590
bb_rcprepared590:
  %v3146 = load i64, ptr %slot25, align 8
  store i64 %v3146, ptr %slot543, align 8
  %v3147 = load i64, ptr %slot543, align 8
  %v3148 = load i64, ptr %slot469, align 8
  %p3149 = inttoptr i64 %v3147 to ptr
  %p3150 = inttoptr i64 %v3148 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3150, ptr %p3149, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot16, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i32 0, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot31, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %ld3155 = load i64, ptr %p3154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3155, ptr %slot544, align 8
  %v3156 = load i64, ptr %slot544, align 8
  %v3157 = load i64, ptr %slot24, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i64 %v3156, ptr %p3158, align 8, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot24, align 8
  store i64 %v3159, ptr %slot545, align 8
  %v3160 = load i64, ptr %slot386, align 8
  %p3162 = inttoptr i64 %v3160 to ptr
  %gep3163 = getelementptr i8, ptr %p3162, i64 16
  %op3161 = ptrtoint ptr %gep3163 to i64
  store i64 %op3161, ptr %slot546, align 8
  %v3164 = load i64, ptr %slot31, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i64, ptr %p3165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3166, ptr %slot547, align 8
  %v3167 = load i64, ptr %slot547, align 8
  %v3168 = load i64, ptr %slot24, align 8
  %p3169 = inttoptr i64 %v3168 to ptr
  store i64 %v3167, ptr %p3169, align 8, !alias.scope !3, !noalias !4
  %v3170 = load i64, ptr %slot24, align 8
  store i64 %v3170, ptr %slot548, align 8
  %v3171 = load i64, ptr %slot14, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  %ld3173 = load i32, ptr %p3172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3173, ptr %slot549, align 8
  %v3174 = load i64, ptr %slot15, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i32, ptr %p3175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3176, ptr %slot550, align 8
  %v3177 = load i32, ptr %slot550, align 8
  %op3178 = and i32 %v3177, 24
  store i32 %op3178, ptr %slot550, align 8
  %v3179 = load i32, ptr %slot550, align 8
  %cmp3180 = icmp eq i32 %v3179, 0
  %cv3181 = zext i1 %cmp3180 to i32
  store i32 %cv3181, ptr %slot551, align 8
  %v3182 = load i32, ptr %slot549, align 8
  %v3183 = load i32, ptr %slot551, align 8
  %op3184 = and i32 %v3182, %v3183
  store i32 %op3184, ptr %slot552, align 8
  %v3185 = load i32, ptr %slot552, align 8
  %cv3186 = zext i32 %v3185 to i64
  %cond3187 = icmp ne i64 %cv3186, 0
  br i1 %cond3187, label %bb_rctake686, label %bb_rccopy686
bb_rctake686:
  %v3188 = load i64, ptr %slot25, align 8
  store i64 %v3188, ptr %slot553, align 8
  %v3189 = load i64, ptr %slot34, align 8
  store i64 %v3189, ptr %slot554, align 8
  %v3190 = load i64, ptr %slot548, align 8
  %v3191 = load i64, ptr %slot553, align 8
  %op3192 = sub i64 %v3190, %v3191
  store i64 %op3192, ptr %slot555, align 8
  %v3193 = load i64, ptr %slot553, align 8
  %v3194 = load i64, ptr %slot548, align 8
  %op3195 = sub i64 %v3193, %v3194
  store i64 %op3195, ptr %slot556, align 8
  %v3196 = load i64, ptr %slot555, align 8
  %cmp3197 = icmp ult i64 %v3196, 8
  %cv3198 = zext i1 %cmp3197 to i32
  store i32 %cv3198, ptr %slot557, align 8
  %v3199 = load i64, ptr %slot556, align 8
  %cmp3200 = icmp ult i64 %v3199, 8
  %cv3201 = zext i1 %cmp3200 to i32
  store i32 %cv3201, ptr %slot558, align 8
  %v3202 = load i32, ptr %slot557, align 8
  %v3203 = load i32, ptr %slot558, align 8
  %op3204 = or i32 %v3202, %v3203
  store i32 %op3204, ptr %slot559, align 8
  %v3205 = load i32, ptr %slot559, align 8
  %cv3206 = zext i32 %v3205 to i64
  %cond3207 = icmp ne i64 %cv3206, 0
  br i1 %cond3207, label %bb_rcmoveslow695, label %bb_rcmovecheck695
bb_rcmovecheck695:
  %v3208 = load i64, ptr %slot548, align 8
  %p3210 = inttoptr i64 %v3208 to ptr
  %gep3211 = getelementptr i8, ptr %p3210, i64 0
  %op3209 = ptrtoint ptr %gep3211 to i64
  store i64 %op3209, ptr %slot560, align 8
  %v3212 = load i64, ptr %slot560, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot561, align 8
  %v3215 = load i64, ptr %slot561, align 8
  %cmp3216 = icmp ne i64 %v3215, 0
  %cv3217 = zext i1 %cmp3216 to i32
  store i32 %cv3217, ptr %slot562, align 8
  %v3218 = load i32, ptr %slot562, align 8
  %cv3219 = zext i32 %v3218 to i64
  %cond3220 = icmp ne i64 %cv3219, 0
  br i1 %cond3220, label %bb_rcmoveheader703, label %bb_rcmovenext703
bb_rcmoveheader703:
  %v3221 = load i64, ptr %slot561, align 8
  %op3222 = sub i64 %v3221, 16
  store i64 %op3222, ptr %slot563, align 8
  %v3223 = load i64, ptr %slot561, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %rgep3225 = getelementptr i8, ptr %p3224, i64 -16
  %ld3226 = load i64, ptr %rgep3225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3226, ptr %slot564, align 8
  %v3227 = load i64, ptr %slot564, align 8
  %op3228 = and i64 %v3227, 5764607523034234881
  store i64 %op3228, ptr %slot565, align 8
  %v3229 = load i64, ptr %slot565, align 8
  %cmp3230 = icmp ne i64 %v3229, 0
  %cv3231 = zext i1 %cmp3230 to i32
  store i32 %cv3231, ptr %slot566, align 8
  %v3232 = load i32, ptr %slot566, align 8
  %cv3233 = zext i32 %v3232 to i64
  %cond3234 = icmp ne i64 %cv3233, 0
  br i1 %cond3234, label %bb_rcmoveslow695, label %bb_rcmovenext703
bb_rcmovenext703:
  %v3235 = load i64, ptr %slot548, align 8
  %v3236 = load i64, ptr %slot553, align 8
  %p3237 = inttoptr i64 %v3235 to ptr
  %p3238 = inttoptr i64 %v3236 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3238, ptr %p3237, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3239 = load i64, ptr %slot548, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  store i64 0, ptr %p3240, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved695
bb_rcmoveslow695:
  %v3241 = load i64, ptr %slot33, align 8
  %v3242 = load i64, ptr %slot553, align 8
  %v3243 = load i64, ptr %slot548, align 8
  %v3244 = load i64, ptr %slot554, align 8
  %cv3245 = trunc i64 %v3244 to i32
  %call3246 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v3241, i64 %v3242, i64 %v3243, i32 %cv3245) nomerge, !dbg !124
  store i32 %call3246, ptr %slot567, align 8
  %v3247 = load i32, ptr %slot567, align 8
  %cv3248 = zext i32 %v3247 to i64
  %cond3249 = icmp ne i64 %cv3248, 0
  br i1 %cond3249, label %bb_rcsuccess710, label %bb_rcfailure710
bb_rcfailure710:
  %v3250 = load i64, ptr %slot33, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %call3252 = call i32 @myl_rc_take_failure(ptr %p3251) nomerge, !dbg !124
  store i32 %call3252, ptr %slot568, align 8
  %v3253 = load i64, ptr %slot1, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %v3255 = load i32, ptr %slot568, align 8
  %call3256 = call i32 @myl_qbe_rc_status(ptr %p3254, i32 %v3255) nomerge, !dbg !124
  store i32 %call3256, ptr %slot569, align 8
  br label %bb_failure
bb_rcsuccess710:
  br label %bb_rcmoved695
bb_rcmoved695:
  %v3257 = load i64, ptr %slot14, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  store i32 0, ptr %p3258, align 4, !alias.scope !3, !noalias !4
  %v3259 = load i64, ptr %slot17, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  store i32 2, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  %v3261 = load i64, ptr %slot16, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  store i32 1, ptr %p3262, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared686
bb_rccopy686:
  %v3263 = load i64, ptr %slot25, align 8
  store i64 %v3263, ptr %slot570, align 8
  %v3264 = load i64, ptr %slot34, align 8
  store i64 %v3264, ptr %slot571, align 8
  %v3265 = load i64, ptr %slot548, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  %ld3267 = load i64, ptr %p3266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3267, ptr %slot572, align 8
  %v3268 = load i64, ptr %slot572, align 8
  %cmp3269 = icmp ne i64 %v3268, 0
  %cv3270 = zext i1 %cmp3269 to i32
  store i32 %cv3270, ptr %slot573, align 8
  %v3271 = load i32, ptr %slot573, align 8
  %cv3272 = zext i32 %v3271 to i64
  %cond3273 = icmp ne i64 %cv3272, 0
  br i1 %cond3273, label %bb_rcgnn719, label %bb_rcgplain719
bb_rcgnn719:
  %v3274 = load i64, ptr %slot572, align 8
  %op3275 = sub i64 %v3274, 16
  store i64 %op3275, ptr %slot574, align 8
  %v3276 = load i64, ptr %slot572, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  %rgep3278 = getelementptr i8, ptr %p3277, i64 -16
  %ld3279 = load i64, ptr %rgep3278, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3279, ptr %slot575, align 8
  %v3280 = load i64, ptr %slot575, align 8
  %op3281 = and i64 %v3280, 4611686018427387906
  store i64 %op3281, ptr %slot576, align 8
  %v3282 = load i64, ptr %slot576, align 8
  %cmp3283 = icmp ne i64 %v3282, 0
  %cv3284 = zext i1 %cmp3283 to i32
  store i32 %cv3284, ptr %slot577, align 8
  %v3285 = load i32, ptr %slot577, align 8
  %cv3286 = zext i32 %v3285 to i64
  %cond3287 = icmp ne i64 %cv3286, 0
  br i1 %cond3287, label %bb_rcgspecial719, label %bb_rcginc719
bb_rcginc719:
  %v3288 = load i64, ptr %slot572, align 8
  %op3289 = sub i64 %v3288, 32
  store i64 %op3289, ptr %slot578, align 8
  %v3290 = load i64, ptr %slot572, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %rgep3292 = getelementptr i8, ptr %p3291, i64 -32
  %ld3293 = load i64, ptr %rgep3292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3293, ptr %slot579, align 8
  %v3294 = load i64, ptr %slot579, align 8
  %op3295 = add i64 %v3294, 1
  store i64 %op3295, ptr %slot580, align 8
  %v3296 = load i64, ptr %slot580, align 8
  %cmp3297 = icmp eq i64 %v3296, 0
  %cv3298 = zext i1 %cmp3297 to i32
  store i32 %cv3298, ptr %slot581, align 8
  %v3299 = load i32, ptr %slot581, align 8
  %cv3300 = zext i32 %v3299 to i64
  %cond3301 = icmp ne i64 %cv3300, 0
  br i1 %cond3301, label %bb_rcglimit719, label %bb_rcgcapacity719
bb_rcglimit719:
  %v3302 = load i64, ptr %slot1, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %call3304 = call i32 @myl_qbe_rc_status(ptr %p3303, i32 2) nomerge, !dbg !124
  store i32 %call3304, ptr %slot582, align 8
  br label %bb_failure
bb_rcgcapacity719:
  %v3305 = load i64, ptr %slot580, align 8
  %v3306 = load i64, ptr %slot572, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  %rgep3308 = getelementptr i8, ptr %p3307, i64 -32
  store i64 %v3305, ptr %rgep3308, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain719
bb_rcgspecial719:
  %v3309 = load i64, ptr %slot575, align 8
  %op3310 = and i64 %v3309, 4611686018427387904
  store i64 %op3310, ptr %slot583, align 8
  %v3311 = load i64, ptr %slot583, align 8
  %cmp3312 = icmp ne i64 %v3311, 0
  %cv3313 = zext i1 %cmp3312 to i32
  store i32 %cv3313, ptr %slot584, align 8
  %v3314 = load i32, ptr %slot584, align 8
  %cv3315 = zext i32 %v3314 to i64
  %cond3316 = icmp ne i64 %cv3315, 0
  br i1 %cond3316, label %bb_rcgslow719, label %bb_rcgplain719
bb_rcgslow719:
  %v3317 = load i64, ptr %slot33, align 8
  %v3318 = load i64, ptr %slot570, align 8
  %v3319 = load i64, ptr %slot548, align 8
  %v3320 = load i64, ptr %slot571, align 8
  %cv3321 = trunc i64 %v3320 to i32
  %call3322 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64 %v3317, i64 %v3318, i64 %v3319, i32 %cv3321) nomerge, !dbg !124
  store i32 %call3322, ptr %slot585, align 8
  %v3323 = load i32, ptr %slot585, align 8
  %cv3324 = zext i32 %v3323 to i64
  %cond3325 = icmp ne i64 %cv3324, 0
  br i1 %cond3325, label %bb_rcsuccess733, label %bb_rcfailure733
bb_rcfailure733:
  %v3326 = load i64, ptr %slot33, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %call3328 = call i32 @myl_rc_take_failure(ptr %p3327) nomerge, !dbg !124
  store i32 %call3328, ptr %slot586, align 8
  %v3329 = load i64, ptr %slot1, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %v3331 = load i32, ptr %slot586, align 8
  %call3332 = call i32 @myl_qbe_rc_status(ptr %p3330, i32 %v3331) nomerge, !dbg !124
  store i32 %call3332, ptr %slot587, align 8
  br label %bb_failure
bb_rcsuccess733:
  br label %bb_rcgdone719
bb_rcgplain719:
  %v3333 = load i64, ptr %slot572, align 8
  %v3334 = load i64, ptr %slot570, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  store i64 %v3333, ptr %p3335, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone719
bb_rcgdone719:
  %v3336 = load i64, ptr %slot17, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  store i32 2, ptr %p3337, align 4, !alias.scope !3, !noalias !4
  %v3338 = load i64, ptr %slot16, align 8
  %p3339 = inttoptr i64 %v3338 to ptr
  store i32 1, ptr %p3339, align 4, !alias.scope !3, !noalias !4
  %v3340 = load i64, ptr %slot14, align 8
  %p3341 = inttoptr i64 %v3340 to ptr
  %ld3342 = load i32, ptr %p3341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3342, ptr %slot588, align 8
  %v3343 = load i32, ptr %slot588, align 8
  %cv3344 = zext i32 %v3343 to i64
  %cond3345 = icmp ne i64 %cv3344, 0
  br i1 %cond3345, label %bb_rcslotdrop740, label %bb_rcslotdone740
bb_rcslotdrop740:
  %v3346 = load i64, ptr %slot14, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  store i32 0, ptr %p3347, align 4, !alias.scope !3, !noalias !4
  %v3348 = load i64, ptr %slot21, align 8
  store i64 %v3348, ptr %slot589, align 8
  %v3349 = load i64, ptr %slot15, align 8
  %p3350 = inttoptr i64 %v3349 to ptr
  %ld3351 = load i32, ptr %p3350, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3351, ptr %slot590, align 8
  %v3352 = load i32, ptr %slot590, align 8
  %op3353 = and i32 %v3352, 28
  store i32 %op3353, ptr %slot591, align 8
  %v3354 = load i32, ptr %slot591, align 8
  %cv3355 = zext i32 %v3354 to i64
  %cond3356 = icmp ne i64 %cv3355, 0
  br i1 %cond3356, label %bb_rcslotrole740, label %bb_rcslotowner740
bb_rcslotrole740:
  %v3357 = load i64, ptr %slot33, align 8
  store i64 %v3357, ptr %slot592, align 8
  %v3358 = load i64, ptr %slot589, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3360, ptr %slot593, align 8
  %v3361 = load i64, ptr %slot593, align 8
  %cmp3362 = icmp ne i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot594, align 8
  %v3364 = load i32, ptr %slot594, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcgnn756, label %bb_rcgdone756
bb_rcgnn756:
  %v3367 = load i64, ptr %slot593, align 8
  %op3368 = sub i64 %v3367, 16
  store i64 %op3368, ptr %slot595, align 8
  %v3369 = load i64, ptr %slot593, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %rgep3371 = getelementptr i8, ptr %p3370, i64 -16
  %ld3372 = load i64, ptr %rgep3371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3372, ptr %slot596, align 8
  %v3373 = load i64, ptr %slot596, align 8
  %op3374 = and i64 %v3373, 4611686018427387906
  store i64 %op3374, ptr %slot597, align 8
  %v3375 = load i64, ptr %slot597, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot598, align 8
  %v3378 = load i32, ptr %slot598, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcgclear756, label %bb_rcgcounted756
bb_rcgcounted756:
  %v3381 = load i64, ptr %slot593, align 8
  %op3382 = sub i64 %v3381, 24
  store i64 %op3382, ptr %slot599, align 8
  %v3383 = load i64, ptr %slot593, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %rgep3385 = getelementptr i8, ptr %p3384, i64 -24
  %ld3386 = load i64, ptr %rgep3385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3386, ptr %slot600, align 8
  %v3387 = load i64, ptr %slot600, align 8
  %op3388 = sub i64 %v3387, 1
  store i64 %op3388, ptr %slot601, align 8
  %v3389 = load i64, ptr %slot601, align 8
  %cmp3390 = icmp eq i64 %v3389, 0
  %cv3391 = zext i1 %cmp3390 to i32
  store i32 %cv3391, ptr %slot602, align 8
  %v3392 = load i32, ptr %slot602, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcglast756, label %bb_rcgdec756
bb_rcglast756:
  %v3395 = load i64, ptr %slot593, align 8
  %op3396 = sub i64 %v3395, 32
  store i64 %op3396, ptr %slot603, align 8
  %v3397 = load i64, ptr %slot593, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  %rgep3399 = getelementptr i8, ptr %p3398, i64 -32
  %ld3400 = load i64, ptr %rgep3399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3400, ptr %slot604, align 8
  %v3401 = load i64, ptr %slot604, align 8
  %cmp3402 = icmp ne i64 %v3401, 0
  %cv3403 = zext i1 %cmp3402 to i32
  store i32 %cv3403, ptr %slot605, align 8
  %v3404 = load i32, ptr %slot605, align 8
  %cv3405 = zext i32 %v3404 to i64
  %cond3406 = icmp ne i64 %cv3405, 0
  br i1 %cond3406, label %bb_rcgdec756, label %bb_rcgslow756
bb_rcgslow756:
  %v3407 = load i64, ptr %slot592, align 8
  %v3408 = load i64, ptr %slot589, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3407, i64 %v3408) nomerge, !dbg !124
  br label %bb_rcgdone756
bb_rcgdec756:
  %v3409 = load i64, ptr %slot601, align 8
  %v3410 = load i64, ptr %slot593, align 8
  %p3411 = inttoptr i64 %v3410 to ptr
  %rgep3412 = getelementptr i8, ptr %p3411, i64 -24
  store i64 %v3409, ptr %rgep3412, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear756
bb_rcgclear756:
  %v3413 = load i64, ptr %slot589, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i64 0, ptr %p3414, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone756
bb_rcgdone756:
  br label %bb_rcslotdone740
bb_rcslotowner740:
  %v3415 = load i64, ptr %slot33, align 8
  store i64 %v3415, ptr %slot606, align 8
  %v3416 = load i64, ptr %slot589, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  %ld3418 = load i64, ptr %p3417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3418, ptr %slot607, align 8
  %v3419 = load i64, ptr %slot607, align 8
  %cmp3420 = icmp ne i64 %v3419, 0
  %cv3421 = zext i1 %cmp3420 to i32
  store i32 %cv3421, ptr %slot608, align 8
  %v3422 = load i32, ptr %slot608, align 8
  %cv3423 = zext i32 %v3422 to i64
  %cond3424 = icmp ne i64 %cv3423, 0
  br i1 %cond3424, label %bb_rcgnn771, label %bb_rcgdone771
bb_rcgnn771:
  %v3425 = load i64, ptr %slot607, align 8
  %op3426 = sub i64 %v3425, 16
  store i64 %op3426, ptr %slot609, align 8
  %v3427 = load i64, ptr %slot607, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %rgep3429 = getelementptr i8, ptr %p3428, i64 -16
  %ld3430 = load i64, ptr %rgep3429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3430, ptr %slot610, align 8
  %v3431 = load i64, ptr %slot610, align 8
  %op3432 = and i64 %v3431, 4611686018427387906
  store i64 %op3432, ptr %slot611, align 8
  %v3433 = load i64, ptr %slot611, align 8
  %cmp3434 = icmp ne i64 %v3433, 0
  %cv3435 = zext i1 %cmp3434 to i32
  store i32 %cv3435, ptr %slot612, align 8
  %v3436 = load i32, ptr %slot612, align 8
  %cv3437 = zext i32 %v3436 to i64
  %cond3438 = icmp ne i64 %cv3437, 0
  br i1 %cond3438, label %bb_rcgclear771, label %bb_rcgcounted771
bb_rcgcounted771:
  %v3439 = load i64, ptr %slot607, align 8
  %op3440 = sub i64 %v3439, 32
  store i64 %op3440, ptr %slot613, align 8
  %v3441 = load i64, ptr %slot607, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  %rgep3443 = getelementptr i8, ptr %p3442, i64 -32
  %ld3444 = load i64, ptr %rgep3443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3444, ptr %slot614, align 8
  %v3445 = load i64, ptr %slot614, align 8
  %op3446 = sub i64 %v3445, 1
  store i64 %op3446, ptr %slot615, align 8
  %v3447 = load i64, ptr %slot615, align 8
  %cmp3448 = icmp eq i64 %v3447, 0
  %cv3449 = zext i1 %cmp3448 to i32
  store i32 %cv3449, ptr %slot616, align 8
  %v3450 = load i32, ptr %slot616, align 8
  %cv3451 = zext i32 %v3450 to i64
  %cond3452 = icmp ne i64 %cv3451, 0
  br i1 %cond3452, label %bb_rcglast771, label %bb_rcgdec771
bb_rcglast771:
  %v3453 = load i64, ptr %slot607, align 8
  %op3454 = sub i64 %v3453, 24
  store i64 %op3454, ptr %slot617, align 8
  %v3455 = load i64, ptr %slot607, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %rgep3457 = getelementptr i8, ptr %p3456, i64 -24
  %ld3458 = load i64, ptr %rgep3457, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3458, ptr %slot618, align 8
  %v3459 = load i64, ptr %slot618, align 8
  %cmp3460 = icmp ne i64 %v3459, 0
  %cv3461 = zext i1 %cmp3460 to i32
  store i32 %cv3461, ptr %slot619, align 8
  %v3462 = load i32, ptr %slot619, align 8
  %cv3463 = zext i32 %v3462 to i64
  %cond3464 = icmp ne i64 %cv3463, 0
  br i1 %cond3464, label %bb_rcgdec771, label %bb_rcgslow771
bb_rcgslow771:
  %v3465 = load i64, ptr %slot606, align 8
  %v3466 = load i64, ptr %slot589, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3465, i64 %v3466) nomerge, !dbg !124
  br label %bb_rcgdone771
bb_rcgdec771:
  %v3467 = load i64, ptr %slot615, align 8
  %v3468 = load i64, ptr %slot607, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %rgep3470 = getelementptr i8, ptr %p3469, i64 -32
  store i64 %v3467, ptr %rgep3470, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear771
bb_rcgclear771:
  %v3471 = load i64, ptr %slot589, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i64 0, ptr %p3472, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone771
bb_rcgdone771:
  br label %bb_rcslotdone740
bb_rcslotdone740:
  br label %bb_rcprepared686
bb_rcprepared686:
  %v3473 = load i64, ptr %slot25, align 8
  store i64 %v3473, ptr %slot620, align 8
  %v3474 = load i64, ptr %slot620, align 8
  %v3475 = load i64, ptr %slot546, align 8
  %p3476 = inttoptr i64 %v3474 to ptr
  %p3477 = inttoptr i64 %v3475 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3477, ptr %p3476, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3478 = load i64, ptr %slot16, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i32 0, ptr %p3479, align 4, !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot386, align 8
  %v3481 = load i64, ptr %slot29, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i64 %v3480, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  %v3483 = load i64, ptr %slot29, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  %ld3485 = load i64, ptr %p3484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3485, ptr %slot621, align 8
  %v3486 = load i64, ptr %slot19, align 8
  store i64 %v3486, ptr %slot622, align 8
  %v3487 = load i64, ptr %slot621, align 8
  %v3488 = load i64, ptr %slot622, align 8
  %p3489 = inttoptr i64 %v3487 to ptr
  %p3490 = inttoptr i64 %v3488 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3490, ptr %p3489, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3491 = load i64, ptr %slot11, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  store i32 2, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  %v3493 = load i64, ptr %slot10, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  store i32 1, ptr %p3494, align 4, !alias.scope !3, !noalias !4
  %v3495 = load i64, ptr %slot622, align 8
  %v3496 = load i64, ptr %slot29, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  store i64 %v3495, ptr %p3497, align 8, !alias.scope !3, !noalias !4
  %v3498 = load i64, ptr %slot29, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  %ld3500 = load i64, ptr %p3499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3500, ptr %slot623, align 8
  %v3501 = load i64, ptr %slot29, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  %ld3503 = load i64, ptr %p3502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3503, ptr %slot624, align 8
  %v3504 = load i64, ptr %slot25, align 8
  store i64 %v3504, ptr %slot625, align 8
  %v3505 = load i64, ptr %slot34, align 8
  store i64 %v3505, ptr %slot626, align 8
  %v3506 = load i64, ptr %slot624, align 8
  %op3507 = add i64 %v3506, 0
  store i64 %op3507, ptr %slot627, align 8
  %v3508 = load i64, ptr %slot627, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %ld3510 = load i64, ptr %p3509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3510, ptr %slot628, align 8
  %v3511 = load i64, ptr %slot628, align 8
  %cmp3512 = icmp ne i64 %v3511, 0
  %cv3513 = zext i1 %cmp3512 to i32
  store i32 %cv3513, ptr %slot629, align 8
  %v3514 = load i32, ptr %slot629, align 8
  %cv3515 = zext i32 %v3514 to i64
  %cond3516 = icmp ne i64 %cv3515, 0
  br i1 %cond3516, label %bb_rcmoveheader788, label %bb_rcmovenext788
bb_rcmoveheader788:
  %v3517 = load i64, ptr %slot628, align 8
  %op3518 = sub i64 %v3517, 16
  store i64 %op3518, ptr %slot630, align 8
  %v3519 = load i64, ptr %slot628, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  %rgep3521 = getelementptr i8, ptr %p3520, i64 -16
  %ld3522 = load i64, ptr %rgep3521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3522, ptr %slot631, align 8
  %v3523 = load i64, ptr %slot631, align 8
  %op3524 = and i64 %v3523, 5764607523034234881
  store i64 %op3524, ptr %slot632, align 8
  %v3525 = load i64, ptr %slot632, align 8
  %cmp3526 = icmp ne i64 %v3525, 0
  %cv3527 = zext i1 %cmp3526 to i32
  store i32 %cv3527, ptr %slot633, align 8
  %v3528 = load i32, ptr %slot633, align 8
  %cv3529 = zext i32 %v3528 to i64
  %cond3530 = icmp ne i64 %cv3529, 0
  br i1 %cond3530, label %bb_rcmoveslow785, label %bb_rcmovenext788
bb_rcmovenext788:
  %v3531 = load i64, ptr %slot624, align 8
  %op3532 = add i64 %v3531, 8
  store i64 %op3532, ptr %slot634, align 8
  %v3533 = load i64, ptr %slot634, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %ld3535 = load i64, ptr %p3534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3535, ptr %slot635, align 8
  %v3536 = load i64, ptr %slot635, align 8
  %cmp3537 = icmp ne i64 %v3536, 0
  %cv3538 = zext i1 %cmp3537 to i32
  store i32 %cv3538, ptr %slot636, align 8
  %v3539 = load i32, ptr %slot636, align 8
  %cv3540 = zext i32 %v3539 to i64
  %cond3541 = icmp ne i64 %cv3540, 0
  br i1 %cond3541, label %bb_rcmoveheader796, label %bb_rcmovenext796
bb_rcmoveheader796:
  %v3542 = load i64, ptr %slot635, align 8
  %op3543 = sub i64 %v3542, 16
  store i64 %op3543, ptr %slot637, align 8
  %v3544 = load i64, ptr %slot635, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %rgep3546 = getelementptr i8, ptr %p3545, i64 -16
  %ld3547 = load i64, ptr %rgep3546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3547, ptr %slot638, align 8
  %v3548 = load i64, ptr %slot638, align 8
  %op3549 = and i64 %v3548, 5764607523034234881
  store i64 %op3549, ptr %slot639, align 8
  %v3550 = load i64, ptr %slot639, align 8
  %cmp3551 = icmp ne i64 %v3550, 0
  %cv3552 = zext i1 %cmp3551 to i32
  store i32 %cv3552, ptr %slot640, align 8
  %v3553 = load i32, ptr %slot640, align 8
  %cv3554 = zext i32 %v3553 to i64
  %cond3555 = icmp ne i64 %cv3554, 0
  br i1 %cond3555, label %bb_rcmoveslow785, label %bb_rcmovenext796
bb_rcmovenext796:
  %v3556 = load i64, ptr %slot624, align 8
  %op3557 = add i64 %v3556, 16
  store i64 %op3557, ptr %slot641, align 8
  %v3558 = load i64, ptr %slot641, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  %ld3560 = load i64, ptr %p3559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3560, ptr %slot642, align 8
  %v3561 = load i64, ptr %slot642, align 8
  %cmp3562 = icmp ne i64 %v3561, 0
  %cv3563 = zext i1 %cmp3562 to i32
  store i32 %cv3563, ptr %slot643, align 8
  %v3564 = load i32, ptr %slot643, align 8
  %cv3565 = zext i32 %v3564 to i64
  %cond3566 = icmp ne i64 %cv3565, 0
  br i1 %cond3566, label %bb_rcmoveheader804, label %bb_rcmovenext804
bb_rcmoveheader804:
  %v3567 = load i64, ptr %slot642, align 8
  %op3568 = sub i64 %v3567, 16
  store i64 %op3568, ptr %slot644, align 8
  %v3569 = load i64, ptr %slot642, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  %rgep3571 = getelementptr i8, ptr %p3570, i64 -16
  %ld3572 = load i64, ptr %rgep3571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3572, ptr %slot645, align 8
  %v3573 = load i64, ptr %slot645, align 8
  %op3574 = and i64 %v3573, 5764607523034234881
  store i64 %op3574, ptr %slot646, align 8
  %v3575 = load i64, ptr %slot646, align 8
  %cmp3576 = icmp ne i64 %v3575, 0
  %cv3577 = zext i1 %cmp3576 to i32
  store i32 %cv3577, ptr %slot647, align 8
  %v3578 = load i32, ptr %slot647, align 8
  %cv3579 = zext i32 %v3578 to i64
  %cond3580 = icmp ne i64 %cv3579, 0
  br i1 %cond3580, label %bb_rcmoveslow785, label %bb_rcmovenext804
bb_rcmovenext804:
  %v3581 = load i64, ptr %slot624, align 8
  %v3582 = load i64, ptr %slot625, align 8
  %p3583 = inttoptr i64 %v3581 to ptr
  %p3584 = inttoptr i64 %v3582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3584, ptr %p3583, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot624, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  store i64 0, ptr %p3586, align 8, !alias.scope !3, !noalias !4
  %v3587 = load i64, ptr %slot624, align 8
  %op3588 = add i64 %v3587, 8
  store i64 %op3588, ptr %slot648, align 8
  %v3589 = load i64, ptr %slot648, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i64 0, ptr %p3590, align 8, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot624, align 8
  %op3592 = add i64 %v3591, 16
  store i64 %op3592, ptr %slot649, align 8
  %v3593 = load i64, ptr %slot649, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  store i64 0, ptr %p3594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved785
bb_rcmoveslow785:
  %v3595 = load i64, ptr %slot33, align 8
  %v3596 = load i64, ptr %slot625, align 8
  %v3597 = load i64, ptr %slot624, align 8
  %v3598 = load i64, ptr %slot626, align 8
  %cv3599 = trunc i64 %v3598 to i32
  %call3600 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v3595, i64 %v3596, i64 %v3597, i32 %cv3599) nomerge, !dbg !126
  store i32 %call3600, ptr %slot650, align 8
  %v3601 = load i32, ptr %slot650, align 8
  %cv3602 = zext i32 %v3601 to i64
  %cond3603 = icmp ne i64 %cv3602, 0
  br i1 %cond3603, label %bb_rcsuccess813, label %bb_rcfailure813
bb_rcfailure813:
  %v3604 = load i64, ptr %slot33, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  %call3606 = call i32 @myl_rc_take_failure(ptr %p3605) nomerge, !dbg !126
  store i32 %call3606, ptr %slot651, align 8
  %v3607 = load i64, ptr %slot1, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  %v3609 = load i32, ptr %slot651, align 8
  %call3610 = call i32 @myl_qbe_rc_status(ptr %p3608, i32 %v3609) nomerge, !dbg !126
  store i32 %call3610, ptr %slot652, align 8
  br label %bb_failure
bb_rcsuccess813:
  br label %bb_rcmoved785
bb_rcmoved785:
  %v3611 = load i64, ptr %slot10, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  store i32 0, ptr %p3612, align 4, !alias.scope !3, !noalias !4
  %v3613 = load i64, ptr %slot17, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i32 2, ptr %p3614, align 4, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot16, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  store i32 1, ptr %p3616, align 4, !alias.scope !3, !noalias !4
  %v3617 = load i64, ptr %slot25, align 8
  store i64 %v3617, ptr %slot653, align 8
  %v3618 = load i64, ptr %slot16, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i32 0, ptr %p3619, align 4, !alias.scope !3, !noalias !4
  %v3620 = load i64, ptr %slot10, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot654, align 8
  %v3623 = load i32, ptr %slot654, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcslotdrop823, label %bb_rcslotdone823
bb_rcslotdrop823:
  %v3626 = load i64, ptr %slot10, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i32 0, ptr %p3627, align 4, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot19, align 8
  store i64 %v3628, ptr %slot655, align 8
  %v3629 = load i64, ptr %slot11, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %ld3631 = load i32, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3631, ptr %slot656, align 8
  %v3632 = load i32, ptr %slot656, align 8
  %op3633 = and i32 %v3632, 28
  store i32 %op3633, ptr %slot657, align 8
  %v3634 = load i32, ptr %slot657, align 8
  %cv3635 = zext i32 %v3634 to i64
  %cond3636 = icmp ne i64 %cv3635, 0
  br i1 %cond3636, label %bb_rcslotrole823, label %bb_rcslotowner823
bb_rcslotrole823:
  %v3637 = load i64, ptr %slot33, align 8
  store i64 %v3637, ptr %slot658, align 8
  %v3638 = load i64, ptr %slot658, align 8
  %v3639 = load i64, ptr %slot655, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3638, i64 %v3639) nomerge, !dbg !126
  br label %bb_rcslotdone823
bb_rcslotowner823:
  %v3640 = load i64, ptr %slot33, align 8
  store i64 %v3640, ptr %slot659, align 8
  %v3641 = load i64, ptr %slot659, align 8
  %v3642 = load i64, ptr %slot655, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v3641, i64 %v3642) nomerge, !dbg !126
  br label %bb_rcslotdone823
bb_rcslotdone823:
  %v3643 = load i64, ptr %slot8, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %ld3645 = load i32, ptr %p3644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3645, ptr %slot660, align 8
  %v3646 = load i32, ptr %slot660, align 8
  %cv3647 = zext i32 %v3646 to i64
  %cond3648 = icmp ne i64 %cv3647, 0
  br i1 %cond3648, label %bb_rcslotdrop832, label %bb_rcslotdone832
bb_rcslotdrop832:
  %v3649 = load i64, ptr %slot8, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  store i32 0, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  %v3651 = load i64, ptr %slot28, align 8
  store i64 %v3651, ptr %slot661, align 8
  %v3652 = load i64, ptr %slot9, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %ld3654 = load i32, ptr %p3653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3654, ptr %slot662, align 8
  %v3655 = load i32, ptr %slot662, align 8
  %op3656 = and i32 %v3655, 28
  store i32 %op3656, ptr %slot663, align 8
  %v3657 = load i32, ptr %slot663, align 8
  %cv3658 = zext i32 %v3657 to i64
  %cond3659 = icmp ne i64 %cv3658, 0
  br i1 %cond3659, label %bb_rcslotrole832, label %bb_rcslotowner832
bb_rcslotrole832:
  %v3660 = load i64, ptr %slot33, align 8
  store i64 %v3660, ptr %slot664, align 8
  %v3661 = load i64, ptr %slot661, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %ld3663 = load i64, ptr %p3662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3663, ptr %slot665, align 8
  %v3664 = load i64, ptr %slot665, align 8
  %cmp3665 = icmp ne i64 %v3664, 0
  %cv3666 = zext i1 %cmp3665 to i32
  store i32 %cv3666, ptr %slot666, align 8
  %v3667 = load i32, ptr %slot666, align 8
  %cv3668 = zext i32 %v3667 to i64
  %cond3669 = icmp ne i64 %cv3668, 0
  br i1 %cond3669, label %bb_rcgnn848, label %bb_rcgdone848
bb_rcgnn848:
  %v3670 = load i64, ptr %slot665, align 8
  %op3671 = sub i64 %v3670, 16
  store i64 %op3671, ptr %slot667, align 8
  %v3672 = load i64, ptr %slot665, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %rgep3674 = getelementptr i8, ptr %p3673, i64 -16
  %ld3675 = load i64, ptr %rgep3674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3675, ptr %slot668, align 8
  %v3676 = load i64, ptr %slot668, align 8
  %op3677 = and i64 %v3676, 4611686018427387906
  store i64 %op3677, ptr %slot669, align 8
  %v3678 = load i64, ptr %slot669, align 8
  %cmp3679 = icmp ne i64 %v3678, 0
  %cv3680 = zext i1 %cmp3679 to i32
  store i32 %cv3680, ptr %slot670, align 8
  %v3681 = load i32, ptr %slot670, align 8
  %cv3682 = zext i32 %v3681 to i64
  %cond3683 = icmp ne i64 %cv3682, 0
  br i1 %cond3683, label %bb_rcgclear848, label %bb_rcgcounted848
bb_rcgcounted848:
  %v3684 = load i64, ptr %slot665, align 8
  %op3685 = sub i64 %v3684, 24
  store i64 %op3685, ptr %slot671, align 8
  %v3686 = load i64, ptr %slot665, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  %rgep3688 = getelementptr i8, ptr %p3687, i64 -24
  %ld3689 = load i64, ptr %rgep3688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3689, ptr %slot672, align 8
  %v3690 = load i64, ptr %slot672, align 8
  %op3691 = sub i64 %v3690, 1
  store i64 %op3691, ptr %slot673, align 8
  %v3692 = load i64, ptr %slot673, align 8
  %cmp3693 = icmp eq i64 %v3692, 0
  %cv3694 = zext i1 %cmp3693 to i32
  store i32 %cv3694, ptr %slot674, align 8
  %v3695 = load i32, ptr %slot674, align 8
  %cv3696 = zext i32 %v3695 to i64
  %cond3697 = icmp ne i64 %cv3696, 0
  br i1 %cond3697, label %bb_rcglast848, label %bb_rcgdec848
bb_rcglast848:
  %v3698 = load i64, ptr %slot665, align 8
  %op3699 = sub i64 %v3698, 32
  store i64 %op3699, ptr %slot675, align 8
  %v3700 = load i64, ptr %slot665, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %rgep3702 = getelementptr i8, ptr %p3701, i64 -32
  %ld3703 = load i64, ptr %rgep3702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3703, ptr %slot676, align 8
  %v3704 = load i64, ptr %slot676, align 8
  %cmp3705 = icmp ne i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot677, align 8
  %v3707 = load i32, ptr %slot677, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcgdec848, label %bb_rcgslow848
bb_rcgslow848:
  %v3710 = load i64, ptr %slot664, align 8
  %v3711 = load i64, ptr %slot661, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3710, i64 %v3711) nomerge, !dbg !126
  br label %bb_rcgdone848
bb_rcgdec848:
  %v3712 = load i64, ptr %slot673, align 8
  %v3713 = load i64, ptr %slot665, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %rgep3715 = getelementptr i8, ptr %p3714, i64 -24
  store i64 %v3712, ptr %rgep3715, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear848
bb_rcgclear848:
  %v3716 = load i64, ptr %slot661, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i64 0, ptr %p3717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone848
bb_rcgdone848:
  br label %bb_rcslotdone832
bb_rcslotowner832:
  %v3718 = load i64, ptr %slot33, align 8
  store i64 %v3718, ptr %slot678, align 8
  %v3719 = load i64, ptr %slot661, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i64, ptr %p3720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3721, ptr %slot679, align 8
  %v3722 = load i64, ptr %slot679, align 8
  %cmp3723 = icmp ne i64 %v3722, 0
  %cv3724 = zext i1 %cmp3723 to i32
  store i32 %cv3724, ptr %slot680, align 8
  %v3725 = load i32, ptr %slot680, align 8
  %cv3726 = zext i32 %v3725 to i64
  %cond3727 = icmp ne i64 %cv3726, 0
  br i1 %cond3727, label %bb_rcgnn863, label %bb_rcgdone863
bb_rcgnn863:
  %v3728 = load i64, ptr %slot679, align 8
  %op3729 = sub i64 %v3728, 16
  store i64 %op3729, ptr %slot681, align 8
  %v3730 = load i64, ptr %slot679, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %rgep3732 = getelementptr i8, ptr %p3731, i64 -16
  %ld3733 = load i64, ptr %rgep3732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3733, ptr %slot682, align 8
  %v3734 = load i64, ptr %slot682, align 8
  %op3735 = and i64 %v3734, 4611686018427387906
  store i64 %op3735, ptr %slot683, align 8
  %v3736 = load i64, ptr %slot683, align 8
  %cmp3737 = icmp ne i64 %v3736, 0
  %cv3738 = zext i1 %cmp3737 to i32
  store i32 %cv3738, ptr %slot684, align 8
  %v3739 = load i32, ptr %slot684, align 8
  %cv3740 = zext i32 %v3739 to i64
  %cond3741 = icmp ne i64 %cv3740, 0
  br i1 %cond3741, label %bb_rcgclear863, label %bb_rcgcounted863
bb_rcgcounted863:
  %v3742 = load i64, ptr %slot679, align 8
  %op3743 = sub i64 %v3742, 32
  store i64 %op3743, ptr %slot685, align 8
  %v3744 = load i64, ptr %slot679, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  %rgep3746 = getelementptr i8, ptr %p3745, i64 -32
  %ld3747 = load i64, ptr %rgep3746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3747, ptr %slot686, align 8
  %v3748 = load i64, ptr %slot686, align 8
  %op3749 = sub i64 %v3748, 1
  store i64 %op3749, ptr %slot687, align 8
  %v3750 = load i64, ptr %slot687, align 8
  %cmp3751 = icmp eq i64 %v3750, 0
  %cv3752 = zext i1 %cmp3751 to i32
  store i32 %cv3752, ptr %slot688, align 8
  %v3753 = load i32, ptr %slot688, align 8
  %cv3754 = zext i32 %v3753 to i64
  %cond3755 = icmp ne i64 %cv3754, 0
  br i1 %cond3755, label %bb_rcglast863, label %bb_rcgdec863
bb_rcglast863:
  %v3756 = load i64, ptr %slot679, align 8
  %op3757 = sub i64 %v3756, 24
  store i64 %op3757, ptr %slot689, align 8
  %v3758 = load i64, ptr %slot679, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  %rgep3760 = getelementptr i8, ptr %p3759, i64 -24
  %ld3761 = load i64, ptr %rgep3760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3761, ptr %slot690, align 8
  %v3762 = load i64, ptr %slot690, align 8
  %cmp3763 = icmp ne i64 %v3762, 0
  %cv3764 = zext i1 %cmp3763 to i32
  store i32 %cv3764, ptr %slot691, align 8
  %v3765 = load i32, ptr %slot691, align 8
  %cv3766 = zext i32 %v3765 to i64
  %cond3767 = icmp ne i64 %cv3766, 0
  br i1 %cond3767, label %bb_rcgdec863, label %bb_rcgslow863
bb_rcgslow863:
  %v3768 = load i64, ptr %slot678, align 8
  %v3769 = load i64, ptr %slot661, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3768, i64 %v3769) nomerge, !dbg !126
  br label %bb_rcgdone863
bb_rcgdec863:
  %v3770 = load i64, ptr %slot687, align 8
  %v3771 = load i64, ptr %slot679, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  %rgep3773 = getelementptr i8, ptr %p3772, i64 -32
  store i64 %v3770, ptr %rgep3773, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear863
bb_rcgclear863:
  %v3774 = load i64, ptr %slot661, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i64 0, ptr %p3775, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone863
bb_rcgdone863:
  br label %bb_rcslotdone832
bb_rcslotdone832:
  %v3776 = load i64, ptr %slot6, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ld3778 = load i32, ptr %p3777, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3778, ptr %slot692, align 8
  %v3779 = load i32, ptr %slot692, align 8
  %cv3780 = zext i32 %v3779 to i64
  %cond3781 = icmp ne i64 %cv3780, 0
  br i1 %cond3781, label %bb_rcslotdrop869, label %bb_rcslotdone869
bb_rcslotdrop869:
  %v3782 = load i64, ptr %slot6, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  store i32 0, ptr %p3783, align 4, !alias.scope !3, !noalias !4
  %v3784 = load i64, ptr %slot27, align 8
  store i64 %v3784, ptr %slot693, align 8
  %v3785 = load i64, ptr %slot7, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i32, ptr %p3786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3787, ptr %slot694, align 8
  %v3788 = load i32, ptr %slot694, align 8
  %op3789 = and i32 %v3788, 28
  store i32 %op3789, ptr %slot695, align 8
  %v3790 = load i32, ptr %slot695, align 8
  %cv3791 = zext i32 %v3790 to i64
  %cond3792 = icmp ne i64 %cv3791, 0
  br i1 %cond3792, label %bb_rcslotrole869, label %bb_rcslotowner869
bb_rcslotrole869:
  %v3793 = load i64, ptr %slot33, align 8
  store i64 %v3793, ptr %slot696, align 8
  %v3794 = load i64, ptr %slot693, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  %ld3796 = load i64, ptr %p3795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3796, ptr %slot697, align 8
  %v3797 = load i64, ptr %slot697, align 8
  %cmp3798 = icmp ne i64 %v3797, 0
  %cv3799 = zext i1 %cmp3798 to i32
  store i32 %cv3799, ptr %slot698, align 8
  %v3800 = load i32, ptr %slot698, align 8
  %cv3801 = zext i32 %v3800 to i64
  %cond3802 = icmp ne i64 %cv3801, 0
  br i1 %cond3802, label %bb_rcgnn885, label %bb_rcgdone885
bb_rcgnn885:
  %v3803 = load i64, ptr %slot697, align 8
  %op3804 = sub i64 %v3803, 16
  store i64 %op3804, ptr %slot699, align 8
  %v3805 = load i64, ptr %slot697, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %rgep3807 = getelementptr i8, ptr %p3806, i64 -16
  %ld3808 = load i64, ptr %rgep3807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3808, ptr %slot700, align 8
  %v3809 = load i64, ptr %slot700, align 8
  %op3810 = and i64 %v3809, 4611686018427387906
  store i64 %op3810, ptr %slot701, align 8
  %v3811 = load i64, ptr %slot701, align 8
  %cmp3812 = icmp ne i64 %v3811, 0
  %cv3813 = zext i1 %cmp3812 to i32
  store i32 %cv3813, ptr %slot702, align 8
  %v3814 = load i32, ptr %slot702, align 8
  %cv3815 = zext i32 %v3814 to i64
  %cond3816 = icmp ne i64 %cv3815, 0
  br i1 %cond3816, label %bb_rcgclear885, label %bb_rcgcounted885
bb_rcgcounted885:
  %v3817 = load i64, ptr %slot697, align 8
  %op3818 = sub i64 %v3817, 24
  store i64 %op3818, ptr %slot703, align 8
  %v3819 = load i64, ptr %slot697, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %rgep3821 = getelementptr i8, ptr %p3820, i64 -24
  %ld3822 = load i64, ptr %rgep3821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3822, ptr %slot704, align 8
  %v3823 = load i64, ptr %slot704, align 8
  %op3824 = sub i64 %v3823, 1
  store i64 %op3824, ptr %slot705, align 8
  %v3825 = load i64, ptr %slot705, align 8
  %cmp3826 = icmp eq i64 %v3825, 0
  %cv3827 = zext i1 %cmp3826 to i32
  store i32 %cv3827, ptr %slot706, align 8
  %v3828 = load i32, ptr %slot706, align 8
  %cv3829 = zext i32 %v3828 to i64
  %cond3830 = icmp ne i64 %cv3829, 0
  br i1 %cond3830, label %bb_rcglast885, label %bb_rcgdec885
bb_rcglast885:
  %v3831 = load i64, ptr %slot697, align 8
  %op3832 = sub i64 %v3831, 32
  store i64 %op3832, ptr %slot707, align 8
  %v3833 = load i64, ptr %slot697, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %rgep3835 = getelementptr i8, ptr %p3834, i64 -32
  %ld3836 = load i64, ptr %rgep3835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3836, ptr %slot708, align 8
  %v3837 = load i64, ptr %slot708, align 8
  %cmp3838 = icmp ne i64 %v3837, 0
  %cv3839 = zext i1 %cmp3838 to i32
  store i32 %cv3839, ptr %slot709, align 8
  %v3840 = load i32, ptr %slot709, align 8
  %cv3841 = zext i32 %v3840 to i64
  %cond3842 = icmp ne i64 %cv3841, 0
  br i1 %cond3842, label %bb_rcgdec885, label %bb_rcgslow885
bb_rcgslow885:
  %v3843 = load i64, ptr %slot696, align 8
  %v3844 = load i64, ptr %slot693, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3843, i64 %v3844) nomerge, !dbg !126
  br label %bb_rcgdone885
bb_rcgdec885:
  %v3845 = load i64, ptr %slot705, align 8
  %v3846 = load i64, ptr %slot697, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  %rgep3848 = getelementptr i8, ptr %p3847, i64 -24
  store i64 %v3845, ptr %rgep3848, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear885
bb_rcgclear885:
  %v3849 = load i64, ptr %slot693, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  store i64 0, ptr %p3850, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone885
bb_rcgdone885:
  br label %bb_rcslotdone869
bb_rcslotowner869:
  %v3851 = load i64, ptr %slot33, align 8
  store i64 %v3851, ptr %slot710, align 8
  %v3852 = load i64, ptr %slot693, align 8
  %p3853 = inttoptr i64 %v3852 to ptr
  %ld3854 = load i64, ptr %p3853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3854, ptr %slot711, align 8
  %v3855 = load i64, ptr %slot711, align 8
  %cmp3856 = icmp ne i64 %v3855, 0
  %cv3857 = zext i1 %cmp3856 to i32
  store i32 %cv3857, ptr %slot712, align 8
  %v3858 = load i32, ptr %slot712, align 8
  %cv3859 = zext i32 %v3858 to i64
  %cond3860 = icmp ne i64 %cv3859, 0
  br i1 %cond3860, label %bb_rcgnn900, label %bb_rcgdone900
bb_rcgnn900:
  %v3861 = load i64, ptr %slot711, align 8
  %op3862 = sub i64 %v3861, 16
  store i64 %op3862, ptr %slot713, align 8
  %v3863 = load i64, ptr %slot711, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %rgep3865 = getelementptr i8, ptr %p3864, i64 -16
  %ld3866 = load i64, ptr %rgep3865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3866, ptr %slot714, align 8
  %v3867 = load i64, ptr %slot714, align 8
  %op3868 = and i64 %v3867, 4611686018427387906
  store i64 %op3868, ptr %slot715, align 8
  %v3869 = load i64, ptr %slot715, align 8
  %cmp3870 = icmp ne i64 %v3869, 0
  %cv3871 = zext i1 %cmp3870 to i32
  store i32 %cv3871, ptr %slot716, align 8
  %v3872 = load i32, ptr %slot716, align 8
  %cv3873 = zext i32 %v3872 to i64
  %cond3874 = icmp ne i64 %cv3873, 0
  br i1 %cond3874, label %bb_rcgclear900, label %bb_rcgcounted900
bb_rcgcounted900:
  %v3875 = load i64, ptr %slot711, align 8
  %op3876 = sub i64 %v3875, 32
  store i64 %op3876, ptr %slot717, align 8
  %v3877 = load i64, ptr %slot711, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  %rgep3879 = getelementptr i8, ptr %p3878, i64 -32
  %ld3880 = load i64, ptr %rgep3879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3880, ptr %slot718, align 8
  %v3881 = load i64, ptr %slot718, align 8
  %op3882 = sub i64 %v3881, 1
  store i64 %op3882, ptr %slot719, align 8
  %v3883 = load i64, ptr %slot719, align 8
  %cmp3884 = icmp eq i64 %v3883, 0
  %cv3885 = zext i1 %cmp3884 to i32
  store i32 %cv3885, ptr %slot720, align 8
  %v3886 = load i32, ptr %slot720, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcglast900, label %bb_rcgdec900
bb_rcglast900:
  %v3889 = load i64, ptr %slot711, align 8
  %op3890 = sub i64 %v3889, 24
  store i64 %op3890, ptr %slot721, align 8
  %v3891 = load i64, ptr %slot711, align 8
  %p3892 = inttoptr i64 %v3891 to ptr
  %rgep3893 = getelementptr i8, ptr %p3892, i64 -24
  %ld3894 = load i64, ptr %rgep3893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3894, ptr %slot722, align 8
  %v3895 = load i64, ptr %slot722, align 8
  %cmp3896 = icmp ne i64 %v3895, 0
  %cv3897 = zext i1 %cmp3896 to i32
  store i32 %cv3897, ptr %slot723, align 8
  %v3898 = load i32, ptr %slot723, align 8
  %cv3899 = zext i32 %v3898 to i64
  %cond3900 = icmp ne i64 %cv3899, 0
  br i1 %cond3900, label %bb_rcgdec900, label %bb_rcgslow900
bb_rcgslow900:
  %v3901 = load i64, ptr %slot710, align 8
  %v3902 = load i64, ptr %slot693, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3901, i64 %v3902) nomerge, !dbg !126
  br label %bb_rcgdone900
bb_rcgdec900:
  %v3903 = load i64, ptr %slot719, align 8
  %v3904 = load i64, ptr %slot711, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  %rgep3906 = getelementptr i8, ptr %p3905, i64 -32
  store i64 %v3903, ptr %rgep3906, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear900
bb_rcgclear900:
  %v3907 = load i64, ptr %slot693, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  store i64 0, ptr %p3908, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone900
bb_rcgdone900:
  br label %bb_rcslotdone869
bb_rcslotdone869:
  %v3909 = load i64, ptr %slot4, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %ld3911 = load i32, ptr %p3910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3911, ptr %slot724, align 8
  %v3912 = load i32, ptr %slot724, align 8
  %cv3913 = zext i32 %v3912 to i64
  %cond3914 = icmp ne i64 %cv3913, 0
  br i1 %cond3914, label %bb_rcslotdrop906, label %bb_rcslotdone906
bb_rcslotdrop906:
  %v3915 = load i64, ptr %slot4, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  store i32 0, ptr %p3916, align 4, !alias.scope !3, !noalias !4
  %v3917 = load i64, ptr %slot26, align 8
  store i64 %v3917, ptr %slot725, align 8
  %v3918 = load i64, ptr %slot5, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  %ld3920 = load i32, ptr %p3919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3920, ptr %slot726, align 8
  %v3921 = load i32, ptr %slot726, align 8
  %op3922 = and i32 %v3921, 28
  store i32 %op3922, ptr %slot727, align 8
  %v3923 = load i32, ptr %slot727, align 8
  %cv3924 = zext i32 %v3923 to i64
  %cond3925 = icmp ne i64 %cv3924, 0
  br i1 %cond3925, label %bb_rcslotrole906, label %bb_rcslotowner906
bb_rcslotrole906:
  %v3926 = load i64, ptr %slot33, align 8
  store i64 %v3926, ptr %slot728, align 8
  %v3927 = load i64, ptr %slot725, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  %ld3929 = load i64, ptr %p3928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3929, ptr %slot729, align 8
  %v3930 = load i64, ptr %slot729, align 8
  %cmp3931 = icmp ne i64 %v3930, 0
  %cv3932 = zext i1 %cmp3931 to i32
  store i32 %cv3932, ptr %slot730, align 8
  %v3933 = load i32, ptr %slot730, align 8
  %cv3934 = zext i32 %v3933 to i64
  %cond3935 = icmp ne i64 %cv3934, 0
  br i1 %cond3935, label %bb_rcgnn922, label %bb_rcgdone922
bb_rcgnn922:
  %v3936 = load i64, ptr %slot729, align 8
  %op3937 = sub i64 %v3936, 16
  store i64 %op3937, ptr %slot731, align 8
  %v3938 = load i64, ptr %slot729, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %rgep3940 = getelementptr i8, ptr %p3939, i64 -16
  %ld3941 = load i64, ptr %rgep3940, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3941, ptr %slot732, align 8
  %v3942 = load i64, ptr %slot732, align 8
  %op3943 = and i64 %v3942, 4611686018427387906
  store i64 %op3943, ptr %slot733, align 8
  %v3944 = load i64, ptr %slot733, align 8
  %cmp3945 = icmp ne i64 %v3944, 0
  %cv3946 = zext i1 %cmp3945 to i32
  store i32 %cv3946, ptr %slot734, align 8
  %v3947 = load i32, ptr %slot734, align 8
  %cv3948 = zext i32 %v3947 to i64
  %cond3949 = icmp ne i64 %cv3948, 0
  br i1 %cond3949, label %bb_rcgclear922, label %bb_rcgcounted922
bb_rcgcounted922:
  %v3950 = load i64, ptr %slot729, align 8
  %op3951 = sub i64 %v3950, 24
  store i64 %op3951, ptr %slot735, align 8
  %v3952 = load i64, ptr %slot729, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %rgep3954 = getelementptr i8, ptr %p3953, i64 -24
  %ld3955 = load i64, ptr %rgep3954, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3955, ptr %slot736, align 8
  %v3956 = load i64, ptr %slot736, align 8
  %op3957 = sub i64 %v3956, 1
  store i64 %op3957, ptr %slot737, align 8
  %v3958 = load i64, ptr %slot737, align 8
  %cmp3959 = icmp eq i64 %v3958, 0
  %cv3960 = zext i1 %cmp3959 to i32
  store i32 %cv3960, ptr %slot738, align 8
  %v3961 = load i32, ptr %slot738, align 8
  %cv3962 = zext i32 %v3961 to i64
  %cond3963 = icmp ne i64 %cv3962, 0
  br i1 %cond3963, label %bb_rcglast922, label %bb_rcgdec922
bb_rcglast922:
  %v3964 = load i64, ptr %slot729, align 8
  %op3965 = sub i64 %v3964, 32
  store i64 %op3965, ptr %slot739, align 8
  %v3966 = load i64, ptr %slot729, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %rgep3968 = getelementptr i8, ptr %p3967, i64 -32
  %ld3969 = load i64, ptr %rgep3968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3969, ptr %slot740, align 8
  %v3970 = load i64, ptr %slot740, align 8
  %cmp3971 = icmp ne i64 %v3970, 0
  %cv3972 = zext i1 %cmp3971 to i32
  store i32 %cv3972, ptr %slot741, align 8
  %v3973 = load i32, ptr %slot741, align 8
  %cv3974 = zext i32 %v3973 to i64
  %cond3975 = icmp ne i64 %cv3974, 0
  br i1 %cond3975, label %bb_rcgdec922, label %bb_rcgslow922
bb_rcgslow922:
  %v3976 = load i64, ptr %slot728, align 8
  %v3977 = load i64, ptr %slot725, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3976, i64 %v3977) nomerge, !dbg !126
  br label %bb_rcgdone922
bb_rcgdec922:
  %v3978 = load i64, ptr %slot737, align 8
  %v3979 = load i64, ptr %slot729, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  %rgep3981 = getelementptr i8, ptr %p3980, i64 -24
  store i64 %v3978, ptr %rgep3981, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear922
bb_rcgclear922:
  %v3982 = load i64, ptr %slot725, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  store i64 0, ptr %p3983, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone922
bb_rcgdone922:
  br label %bb_rcslotdone906
bb_rcslotowner906:
  %v3984 = load i64, ptr %slot33, align 8
  store i64 %v3984, ptr %slot742, align 8
  %v3985 = load i64, ptr %slot725, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  %ld3987 = load i64, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3987, ptr %slot743, align 8
  %v3988 = load i64, ptr %slot743, align 8
  %cmp3989 = icmp ne i64 %v3988, 0
  %cv3990 = zext i1 %cmp3989 to i32
  store i32 %cv3990, ptr %slot744, align 8
  %v3991 = load i32, ptr %slot744, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcgnn937, label %bb_rcgdone937
bb_rcgnn937:
  %v3994 = load i64, ptr %slot743, align 8
  %op3995 = sub i64 %v3994, 16
  store i64 %op3995, ptr %slot745, align 8
  %v3996 = load i64, ptr %slot743, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %rgep3998 = getelementptr i8, ptr %p3997, i64 -16
  %ld3999 = load i64, ptr %rgep3998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3999, ptr %slot746, align 8
  %v4000 = load i64, ptr %slot746, align 8
  %op4001 = and i64 %v4000, 4611686018427387906
  store i64 %op4001, ptr %slot747, align 8
  %v4002 = load i64, ptr %slot747, align 8
  %cmp4003 = icmp ne i64 %v4002, 0
  %cv4004 = zext i1 %cmp4003 to i32
  store i32 %cv4004, ptr %slot748, align 8
  %v4005 = load i32, ptr %slot748, align 8
  %cv4006 = zext i32 %v4005 to i64
  %cond4007 = icmp ne i64 %cv4006, 0
  br i1 %cond4007, label %bb_rcgclear937, label %bb_rcgcounted937
bb_rcgcounted937:
  %v4008 = load i64, ptr %slot743, align 8
  %op4009 = sub i64 %v4008, 32
  store i64 %op4009, ptr %slot749, align 8
  %v4010 = load i64, ptr %slot743, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  %rgep4012 = getelementptr i8, ptr %p4011, i64 -32
  %ld4013 = load i64, ptr %rgep4012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4013, ptr %slot750, align 8
  %v4014 = load i64, ptr %slot750, align 8
  %op4015 = sub i64 %v4014, 1
  store i64 %op4015, ptr %slot751, align 8
  %v4016 = load i64, ptr %slot751, align 8
  %cmp4017 = icmp eq i64 %v4016, 0
  %cv4018 = zext i1 %cmp4017 to i32
  store i32 %cv4018, ptr %slot752, align 8
  %v4019 = load i32, ptr %slot752, align 8
  %cv4020 = zext i32 %v4019 to i64
  %cond4021 = icmp ne i64 %cv4020, 0
  br i1 %cond4021, label %bb_rcglast937, label %bb_rcgdec937
bb_rcglast937:
  %v4022 = load i64, ptr %slot743, align 8
  %op4023 = sub i64 %v4022, 24
  store i64 %op4023, ptr %slot753, align 8
  %v4024 = load i64, ptr %slot743, align 8
  %p4025 = inttoptr i64 %v4024 to ptr
  %rgep4026 = getelementptr i8, ptr %p4025, i64 -24
  %ld4027 = load i64, ptr %rgep4026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4027, ptr %slot754, align 8
  %v4028 = load i64, ptr %slot754, align 8
  %cmp4029 = icmp ne i64 %v4028, 0
  %cv4030 = zext i1 %cmp4029 to i32
  store i32 %cv4030, ptr %slot755, align 8
  %v4031 = load i32, ptr %slot755, align 8
  %cv4032 = zext i32 %v4031 to i64
  %cond4033 = icmp ne i64 %cv4032, 0
  br i1 %cond4033, label %bb_rcgdec937, label %bb_rcgslow937
bb_rcgslow937:
  %v4034 = load i64, ptr %slot742, align 8
  %v4035 = load i64, ptr %slot725, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4034, i64 %v4035) nomerge, !dbg !126
  br label %bb_rcgdone937
bb_rcgdec937:
  %v4036 = load i64, ptr %slot751, align 8
  %v4037 = load i64, ptr %slot743, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %rgep4039 = getelementptr i8, ptr %p4038, i64 -32
  store i64 %v4036, ptr %rgep4039, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear937
bb_rcgclear937:
  %v4040 = load i64, ptr %slot725, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  store i64 0, ptr %p4041, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone937
bb_rcgdone937:
  br label %bb_rcslotdone906
bb_rcslotdone906:
  %v4042 = load i64, ptr %slot653, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4043, i64 24, i1 false)
  ret void
bb_failure:
  %v4044 = load i64, ptr %slot3, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  call void @llvm.memset.p0.i64(ptr %p4045, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v4046 = load i64, ptr %slot3, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4047, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v4048 = load i64, ptr %slot3, align 8
  %p4049 = inttoptr i64 %v4048 to ptr
  call void @llvm.memset.p0.i64(ptr %p4049, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v4050 = load i64, ptr %slot3, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4051, i64 24, i1 false)
  ret void
}

@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8
@myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2", linkageName: "myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17943600572479123718, i64 0, !"myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
