target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v163 = load i64, ptr %slot1, align 8
  %op164 = add i64 %v163, 32
  store i64 %op164, ptr %slot4, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot5, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot6, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot7, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot8, align 8
  %mem173 = alloca i8, i64 40, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot9, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot10, align 8
  %mem177 = alloca i8, i64 40, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot11, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot12, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot13, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot14, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot15, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot16, align 8
  %v189 = load i64, ptr %slot2, align 8
  %v190 = load i64, ptr %slot12, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 %v189, ptr %p191, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot3, align 8
  %v193 = load i64, ptr %slot13, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot1, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %call197 = call ptr @myl_qbe_heap(ptr %p196) nomerge, !dbg !110
  %calladdr198 = ptrtoint ptr %call197 to i64
  store i64 %calladdr198, ptr %slot17, align 8
  %v199 = load i64, ptr %slot1, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %call201 = call i64 @myl_qbe_region_mark(ptr %p200) nomerge, !dbg !110
  store i64 %call201, ptr %slot18, align 8
  %v202 = load i64, ptr %slot5, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i32 0, ptr %p203, align 4, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot6, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i32 0, ptr %p205, align 4, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot7, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i32 0, ptr %p207, align 4, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot8, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i32 0, ptr %p209, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v210 = load i64, ptr %slot13, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot19, align 8
  %v213 = load i64, ptr %slot19, align 8
  %v214 = load i64, ptr %slot14, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i64 %v213, ptr %p215, align 8, !alias.scope !3, !noalias !4
  %v216 = load i64, ptr %slot14, align 8
  %p217 = inttoptr i64 %v216 to ptr
  %ld218 = load i64, ptr %p217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld218, ptr %slot20, align 8
  %v219 = load i64, ptr %slot20, align 8
  %op220 = add i64 %v219, 8
  store i64 %op220, ptr %slot21, align 8
  %v221 = load i64, ptr %slot21, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !4, !noalias !3
  store i64 %ld223, ptr %slot22, align 8
  %v224 = load i64, ptr %slot22, align 8
  %v225 = load i64, ptr %slot14, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot5, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i32, ptr %p228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld229, ptr %slot23, align 8
  %v230 = load i32, ptr %slot23, align 8
  %cv231 = zext i32 %v230 to i64
  %cond232 = icmp ne i64 %cv231, 0
  br i1 %cond232, label %bb_rcslotdrop8, label %bb_rcslotdone8
bb_rcslotdrop8:
  %v233 = load i64, ptr %slot5, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i32 0, ptr %p234, align 4, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot9, align 8
  store i64 %v235, ptr %slot24, align 8
  %v236 = load i64, ptr %slot6, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i32, ptr %p237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld238, ptr %slot25, align 8
  %v239 = load i32, ptr %slot25, align 8
  %op240 = and i32 %v239, 28
  store i32 %op240, ptr %slot26, align 8
  %v241 = load i32, ptr %slot26, align 8
  %cv242 = zext i32 %v241 to i64
  %cond243 = icmp ne i64 %cv242, 0
  br i1 %cond243, label %bb_rcslotrole8, label %bb_rcslotowner8
bb_rcslotrole8:
  %v244 = load i64, ptr %slot17, align 8
  store i64 %v244, ptr %slot27, align 8
  %v245 = load i64, ptr %slot27, align 8
  %v246 = load i64, ptr %slot24, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v245, i64 %v246) nomerge, !dbg !112
  br label %bb_rcslotdone8
bb_rcslotowner8:
  %v247 = load i64, ptr %slot17, align 8
  store i64 %v247, ptr %slot28, align 8
  %v248 = load i64, ptr %slot28, align 8
  %v249 = load i64, ptr %slot24, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v248, i64 %v249) nomerge, !dbg !112
  br label %bb_rcslotdone8
bb_rcslotdone8:
  %v250 = load i64, ptr %slot13, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot29, align 8
  %v253 = load i64, ptr %slot29, align 8
  %v254 = load i64, ptr %slot15, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot15, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot30, align 8
  %v259 = load i64, ptr %slot30, align 8
  %op260 = add i64 %v259, 8
  store i64 %op260, ptr %slot31, align 8
  %v261 = load i64, ptr %slot31, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !4, !noalias !3
  store i64 %ld263, ptr %slot32, align 8
  %v264 = load i64, ptr %slot32, align 8
  %v265 = load i64, ptr %slot15, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot13, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld269, ptr %slot33, align 8
  %v270 = load i64, ptr %slot33, align 8
  %v271 = load i64, ptr %slot16, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i64 %v270, ptr %p272, align 8, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot16, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot34, align 8
  %v276 = load i64, ptr %slot34, align 8
  %op277 = add i64 %v276, 16
  store i64 %op277, ptr %slot35, align 8
  %v278 = load i64, ptr %slot35, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !4, !noalias !3
  store i64 %ld280, ptr %slot36, align 8
  %v281 = load i64, ptr %slot36, align 8
  %v282 = load i64, ptr %slot16, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot16, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot37, align 8
  %v287 = load i64, ptr %slot15, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot38, align 8
  %v290 = load i64, ptr %slot38, align 8
  %v291 = load i64, ptr %slot37, align 8
  %ovpair293 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v290, i64 %v291)
  %op292 = extractvalue { i64, i1 } %ovpair293, 0
  %ov294 = extractvalue { i64, i1 } %ovpair293, 1
  store i64 %op292, ptr %slot39, align 8
  %v295 = load i64, ptr %slot38, align 8
  %v296 = load i64, ptr %slot39, align 8
  %op297 = xor i64 %v295, %v296
  store i64 %op297, ptr %slot40, align 8
  %v298 = load i64, ptr %slot37, align 8
  %v299 = load i64, ptr %slot39, align 8
  %op300 = xor i64 %v298, %v299
  store i64 %op300, ptr %slot41, align 8
  %v301 = load i64, ptr %slot40, align 8
  %v302 = load i64, ptr %slot41, align 8
  %op303 = and i64 %v301, %v302
  store i64 %op303, ptr %slot42, align 8
  %cv304 = zext i1 %ov294 to i64
  store i64 %cv304, ptr %slot43, align 8
  %v305 = load i64, ptr %slot43, align 8
  %cond306 = icmp ne i64 %v305, 0
  br i1 %cond306, label %bb_overflow43, label %bb_checked43
bb_overflow43:
  %v307 = load i64, ptr %slot1, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %v309 = load i64, ptr %slot38, align 8
  %v310 = load i64, ptr %slot37, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p308, i64 0, i64 %v309, i64 %v310, i64 64) nomerge, !dbg !114
  unreachable
bb_checked43:
  %v311 = load i64, ptr %slot39, align 8
  %v312 = load i64, ptr %slot15, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i64 %v311, ptr %p313, align 8, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot12, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot44, align 8
  %v317 = load i64, ptr %slot14, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot45, align 8
  %v320 = load i64, ptr %slot15, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot46, align 8
  %v323 = load i64, ptr %slot17, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %v325 = load i64, ptr %slot44, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %v327 = load i64, ptr %slot45, align 8
  %v328 = load i64, ptr %slot46, align 8
  %call329 = call ptr @myl_native_bytes_view(ptr %p324, ptr %p326, i64 %v327, i64 %v328) nomerge, !dbg !116
  %calladdr330 = ptrtoint ptr %call329 to i64
  store i64 %calladdr330, ptr %slot47, align 8
  %v331 = load i64, ptr %slot47, align 8
  %cond332 = icmp ne i64 %v331, 0
  br i1 %cond332, label %bb_success52, label %bb_failed52
bb_failed52:
  %v333 = load i64, ptr %slot1, align 8
  %p334 = inttoptr i64 %v333 to ptr
  call void @myl_qbe_fail_allocation(ptr %p334) nomerge, !dbg !116
  unreachable
bb_success52:
  %v335 = load i64, ptr %slot47, align 8
  %v336 = load i64, ptr %slot14, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 %v335, ptr %p337, align 8, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot14, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot48, align 8
  %v341 = load i64, ptr %slot48, align 8
  %v342 = load i64, ptr %slot10, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot10, align 8
  store i64 %v344, ptr %slot49, align 8
  %v345 = load i64, ptr %slot11, align 8
  store i64 %v345, ptr %slot50, align 8
  %v346 = load i64, ptr %slot49, align 8
  %v347 = load i64, ptr %slot50, align 8
  %p348 = inttoptr i64 %v346 to ptr
  %p349 = inttoptr i64 %v347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p349, ptr %p348, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot8, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 2, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot7, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot9, align 8
  store i64 %v354, ptr %slot51, align 8
  %v355 = load i64, ptr %slot11, align 8
  store i64 %v355, ptr %slot52, align 8
  %v356 = load i64, ptr %slot52, align 8
  %v357 = load i64, ptr %slot51, align 8
  %p358 = inttoptr i64 %v356 to ptr
  %p359 = inttoptr i64 %v357 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p359, ptr %p358, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot6, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i32 2, ptr %p361, align 4, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot8, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i32, ptr %p363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld364, ptr %slot53, align 8
  %v365 = load i32, ptr %slot53, align 8
  %v366 = load i64, ptr %slot6, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i32 %v365, ptr %p367, align 4, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot7, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 0, ptr %p369, align 4, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i32 1, ptr %p371, align 4, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot51, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot54, align 8
  %v375 = load i64, ptr %slot54, align 8
  %v376 = load i64, ptr %slot14, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 %v375, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot14, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot55, align 8
  %v381 = load i64, ptr %slot14, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot56, align 8
  %v384 = load i64, ptr %slot56, align 8
  %v385 = load i64, ptr %slot10, align 8
  %p386 = inttoptr i64 %v385 to ptr
  store i64 %v384, ptr %p386, align 8, !alias.scope !3, !noalias !4
  %v387 = load i64, ptr %slot10, align 8
  store i64 %v387, ptr %slot57, align 8
  %v388 = load i64, ptr %slot5, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i32, ptr %p389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld390, ptr %slot58, align 8
  %v391 = load i64, ptr %slot6, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i32, ptr %p392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld393, ptr %slot59, align 8
  %v394 = load i32, ptr %slot59, align 8
  %op395 = and i32 %v394, 24
  store i32 %op395, ptr %slot59, align 8
  %v396 = load i32, ptr %slot59, align 8
  %cmp397 = icmp eq i32 %v396, 0
  %cv398 = zext i1 %cmp397 to i32
  store i32 %cv398, ptr %slot60, align 8
  %v399 = load i32, ptr %slot58, align 8
  %v400 = load i32, ptr %slot60, align 8
  %op401 = and i32 %v399, %v400
  store i32 %op401, ptr %slot61, align 8
  %v402 = load i32, ptr %slot61, align 8
  %cv403 = zext i32 %v402 to i64
  %cond404 = icmp ne i64 %cv403, 0
  br i1 %cond404, label %bb_rctake70, label %bb_rccopy70
bb_rctake70:
  %v405 = load i64, ptr %slot11, align 8
  store i64 %v405, ptr %slot62, align 8
  %v406 = load i64, ptr %slot18, align 8
  store i64 %v406, ptr %slot63, align 8
  %v407 = load i64, ptr %slot57, align 8
  %v408 = load i64, ptr %slot62, align 8
  %op409 = sub i64 %v407, %v408
  store i64 %op409, ptr %slot64, align 8
  %v410 = load i64, ptr %slot62, align 8
  %v411 = load i64, ptr %slot57, align 8
  %op412 = sub i64 %v410, %v411
  store i64 %op412, ptr %slot65, align 8
  %v413 = load i64, ptr %slot64, align 8
  %cmp414 = icmp ult i64 %v413, 8
  %cv415 = zext i1 %cmp414 to i32
  store i32 %cv415, ptr %slot66, align 8
  %v416 = load i64, ptr %slot65, align 8
  %cmp417 = icmp ult i64 %v416, 8
  %cv418 = zext i1 %cmp417 to i32
  store i32 %cv418, ptr %slot67, align 8
  %v419 = load i32, ptr %slot66, align 8
  %v420 = load i32, ptr %slot67, align 8
  %op421 = or i32 %v419, %v420
  store i32 %op421, ptr %slot68, align 8
  %v422 = load i32, ptr %slot68, align 8
  %cv423 = zext i32 %v422 to i64
  %cond424 = icmp ne i64 %cv423, 0
  br i1 %cond424, label %bb_rcmoveslow79, label %bb_rcmovecheck79
bb_rcmovecheck79:
  %v425 = load i64, ptr %slot57, align 8
  %p427 = inttoptr i64 %v425 to ptr
  %gep428 = getelementptr i8, ptr %p427, i64 0
  %op426 = ptrtoint ptr %gep428 to i64
  store i64 %op426, ptr %slot69, align 8
  %v429 = load i64, ptr %slot69, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot70, align 8
  %v432 = load i64, ptr %slot70, align 8
  %cmp433 = icmp ne i64 %v432, 0
  %cv434 = zext i1 %cmp433 to i32
  store i32 %cv434, ptr %slot71, align 8
  %v435 = load i32, ptr %slot71, align 8
  %cv436 = zext i32 %v435 to i64
  %cond437 = icmp ne i64 %cv436, 0
  br i1 %cond437, label %bb_rcmoveheader87, label %bb_rcmovenext87
bb_rcmoveheader87:
  %v438 = load i64, ptr %slot70, align 8
  %op439 = sub i64 %v438, 16
  store i64 %op439, ptr %slot72, align 8
  %v440 = load i64, ptr %slot70, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %rgep442 = getelementptr i8, ptr %p441, i64 -16
  %ld443 = load i64, ptr %rgep442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld443, ptr %slot73, align 8
  %v444 = load i64, ptr %slot73, align 8
  %op445 = and i64 %v444, 5764607523034234881
  store i64 %op445, ptr %slot74, align 8
  %v446 = load i64, ptr %slot74, align 8
  %cmp447 = icmp ne i64 %v446, 0
  %cv448 = zext i1 %cmp447 to i32
  store i32 %cv448, ptr %slot75, align 8
  %v449 = load i32, ptr %slot75, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcmoveslow79, label %bb_rcmovenext87
bb_rcmovenext87:
  %v452 = load i64, ptr %slot57, align 8
  %v453 = load i64, ptr %slot62, align 8
  %p454 = inttoptr i64 %v452 to ptr
  %p455 = inttoptr i64 %v453 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p455, ptr %p454, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot57, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 0, ptr %p457, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved79
bb_rcmoveslow79:
  %v458 = load i64, ptr %slot17, align 8
  %v459 = load i64, ptr %slot62, align 8
  %v460 = load i64, ptr %slot57, align 8
  %v461 = load i64, ptr %slot63, align 8
  %cv462 = trunc i64 %v461 to i32
  %call463 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v458, i64 %v459, i64 %v460, i32 %cv462) nomerge, !dbg !118
  store i32 %call463, ptr %slot76, align 8
  %v464 = load i32, ptr %slot76, align 8
  %cv465 = zext i32 %v464 to i64
  %cond466 = icmp ne i64 %cv465, 0
  br i1 %cond466, label %bb_rcsuccess94, label %bb_rcfailure94
bb_rcfailure94:
  %v467 = load i64, ptr %slot17, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %call469 = call i32 @myl_rc_take_failure(ptr %p468) nomerge, !dbg !118
  store i32 %call469, ptr %slot77, align 8
  %v470 = load i64, ptr %slot1, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %v472 = load i32, ptr %slot77, align 8
  %call473 = call i32 @myl_qbe_rc_status(ptr %p471, i32 %v472) nomerge, !dbg !118
  store i32 %call473, ptr %slot78, align 8
  br label %bb_failure
bb_rcsuccess94:
  br label %bb_rcmoved79
bb_rcmoved79:
  %v474 = load i64, ptr %slot5, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 0, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot8, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 2, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot7, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 1, ptr %p479, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared70
bb_rccopy70:
  %v480 = load i64, ptr %slot11, align 8
  store i64 %v480, ptr %slot79, align 8
  %v481 = load i64, ptr %slot18, align 8
  store i64 %v481, ptr %slot80, align 8
  %v482 = load i64, ptr %slot57, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %ld484 = load i64, ptr %p483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld484, ptr %slot81, align 8
  %v485 = load i64, ptr %slot81, align 8
  %cmp486 = icmp ne i64 %v485, 0
  %cv487 = zext i1 %cmp486 to i32
  store i32 %cv487, ptr %slot82, align 8
  %v488 = load i32, ptr %slot82, align 8
  %cv489 = zext i32 %v488 to i64
  %cond490 = icmp ne i64 %cv489, 0
  br i1 %cond490, label %bb_rcgnn103, label %bb_rcgplain103
bb_rcgnn103:
  %v491 = load i64, ptr %slot81, align 8
  %op492 = sub i64 %v491, 16
  store i64 %op492, ptr %slot83, align 8
  %v493 = load i64, ptr %slot81, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %rgep495 = getelementptr i8, ptr %p494, i64 -16
  %ld496 = load i64, ptr %rgep495, align 8, !alias.scope !9, !noalias !10
  store i64 %ld496, ptr %slot84, align 8
  %v497 = load i64, ptr %slot84, align 8
  %op498 = and i64 %v497, 4611686018427387906
  store i64 %op498, ptr %slot85, align 8
  %v499 = load i64, ptr %slot85, align 8
  %cmp500 = icmp ne i64 %v499, 0
  %cv501 = zext i1 %cmp500 to i32
  store i32 %cv501, ptr %slot86, align 8
  %v502 = load i32, ptr %slot86, align 8
  %cv503 = zext i32 %v502 to i64
  %cond504 = icmp ne i64 %cv503, 0
  br i1 %cond504, label %bb_rcgspecial103, label %bb_rcginc103
bb_rcginc103:
  %v505 = load i64, ptr %slot81, align 8
  %op506 = sub i64 %v505, 32
  store i64 %op506, ptr %slot87, align 8
  %v507 = load i64, ptr %slot81, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %rgep509 = getelementptr i8, ptr %p508, i64 -32
  %ld510 = load i64, ptr %rgep509, align 8, !alias.scope !9, !noalias !10
  store i64 %ld510, ptr %slot88, align 8
  %v511 = load i64, ptr %slot88, align 8
  %op512 = add i64 %v511, 1
  store i64 %op512, ptr %slot89, align 8
  %v513 = load i64, ptr %slot89, align 8
  %cmp514 = icmp eq i64 %v513, 0
  %cv515 = zext i1 %cmp514 to i32
  store i32 %cv515, ptr %slot90, align 8
  %v516 = load i32, ptr %slot90, align 8
  %cv517 = zext i32 %v516 to i64
  %cond518 = icmp ne i64 %cv517, 0
  br i1 %cond518, label %bb_rcglimit103, label %bb_rcgcapacity103
bb_rcglimit103:
  %v519 = load i64, ptr %slot1, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %call521 = call i32 @myl_qbe_rc_status(ptr %p520, i32 2) nomerge, !dbg !118
  store i32 %call521, ptr %slot91, align 8
  br label %bb_failure
bb_rcgcapacity103:
  %v522 = load i64, ptr %slot89, align 8
  %v523 = load i64, ptr %slot81, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %rgep525 = getelementptr i8, ptr %p524, i64 -32
  store i64 %v522, ptr %rgep525, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain103
bb_rcgspecial103:
  %v526 = load i64, ptr %slot84, align 8
  %op527 = and i64 %v526, 4611686018427387904
  store i64 %op527, ptr %slot92, align 8
  %v528 = load i64, ptr %slot92, align 8
  %cmp529 = icmp ne i64 %v528, 0
  %cv530 = zext i1 %cmp529 to i32
  store i32 %cv530, ptr %slot93, align 8
  %v531 = load i32, ptr %slot93, align 8
  %cv532 = zext i32 %v531 to i64
  %cond533 = icmp ne i64 %cv532, 0
  br i1 %cond533, label %bb_rcgslow103, label %bb_rcgplain103
bb_rcgslow103:
  %v534 = load i64, ptr %slot17, align 8
  %v535 = load i64, ptr %slot79, align 8
  %v536 = load i64, ptr %slot57, align 8
  %v537 = load i64, ptr %slot80, align 8
  %cv538 = trunc i64 %v537 to i32
  %call539 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v534, i64 %v535, i64 %v536, i32 %cv538) nomerge, !dbg !118
  store i32 %call539, ptr %slot94, align 8
  %v540 = load i32, ptr %slot94, align 8
  %cv541 = zext i32 %v540 to i64
  %cond542 = icmp ne i64 %cv541, 0
  br i1 %cond542, label %bb_rcsuccess117, label %bb_rcfailure117
bb_rcfailure117:
  %v543 = load i64, ptr %slot17, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %call545 = call i32 @myl_rc_take_failure(ptr %p544) nomerge, !dbg !118
  store i32 %call545, ptr %slot95, align 8
  %v546 = load i64, ptr %slot1, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %v548 = load i32, ptr %slot95, align 8
  %call549 = call i32 @myl_qbe_rc_status(ptr %p547, i32 %v548) nomerge, !dbg !118
  store i32 %call549, ptr %slot96, align 8
  br label %bb_failure
bb_rcsuccess117:
  br label %bb_rcgdone103
bb_rcgplain103:
  %v550 = load i64, ptr %slot81, align 8
  %v551 = load i64, ptr %slot79, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 %v550, ptr %p552, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone103
bb_rcgdone103:
  %v553 = load i64, ptr %slot8, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i32 2, ptr %p554, align 4, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot7, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i32 1, ptr %p556, align 4, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot5, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i32, ptr %p558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld559, ptr %slot97, align 8
  %v560 = load i32, ptr %slot97, align 8
  %cv561 = zext i32 %v560 to i64
  %cond562 = icmp ne i64 %cv561, 0
  br i1 %cond562, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v563 = load i64, ptr %slot5, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot9, align 8
  store i64 %v565, ptr %slot98, align 8
  %v566 = load i64, ptr %slot6, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i32, ptr %p567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld568, ptr %slot99, align 8
  %v569 = load i32, ptr %slot99, align 8
  %op570 = and i32 %v569, 28
  store i32 %op570, ptr %slot100, align 8
  %v571 = load i32, ptr %slot100, align 8
  %cv572 = zext i32 %v571 to i64
  %cond573 = icmp ne i64 %cv572, 0
  br i1 %cond573, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v574 = load i64, ptr %slot17, align 8
  store i64 %v574, ptr %slot101, align 8
  %v575 = load i64, ptr %slot98, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot102, align 8
  %v578 = load i64, ptr %slot102, align 8
  %cmp579 = icmp ne i64 %v578, 0
  %cv580 = zext i1 %cmp579 to i32
  store i32 %cv580, ptr %slot103, align 8
  %v581 = load i32, ptr %slot103, align 8
  %cv582 = zext i32 %v581 to i64
  %cond583 = icmp ne i64 %cv582, 0
  br i1 %cond583, label %bb_rcgnn140, label %bb_rcgdone140
bb_rcgnn140:
  %v584 = load i64, ptr %slot102, align 8
  %op585 = sub i64 %v584, 16
  store i64 %op585, ptr %slot104, align 8
  %v586 = load i64, ptr %slot102, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %rgep588 = getelementptr i8, ptr %p587, i64 -16
  %ld589 = load i64, ptr %rgep588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld589, ptr %slot105, align 8
  %v590 = load i64, ptr %slot105, align 8
  %op591 = and i64 %v590, 4611686018427387906
  store i64 %op591, ptr %slot106, align 8
  %v592 = load i64, ptr %slot106, align 8
  %cmp593 = icmp ne i64 %v592, 0
  %cv594 = zext i1 %cmp593 to i32
  store i32 %cv594, ptr %slot107, align 8
  %v595 = load i32, ptr %slot107, align 8
  %cv596 = zext i32 %v595 to i64
  %cond597 = icmp ne i64 %cv596, 0
  br i1 %cond597, label %bb_rcgclear140, label %bb_rcgcounted140
bb_rcgcounted140:
  %v598 = load i64, ptr %slot102, align 8
  %op599 = sub i64 %v598, 24
  store i64 %op599, ptr %slot108, align 8
  %v600 = load i64, ptr %slot102, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %rgep602 = getelementptr i8, ptr %p601, i64 -24
  %ld603 = load i64, ptr %rgep602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld603, ptr %slot109, align 8
  %v604 = load i64, ptr %slot109, align 8
  %op605 = sub i64 %v604, 1
  store i64 %op605, ptr %slot110, align 8
  %v606 = load i64, ptr %slot110, align 8
  %cmp607 = icmp eq i64 %v606, 0
  %cv608 = zext i1 %cmp607 to i32
  store i32 %cv608, ptr %slot111, align 8
  %v609 = load i32, ptr %slot111, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcglast140, label %bb_rcgdec140
bb_rcglast140:
  %v612 = load i64, ptr %slot102, align 8
  %op613 = sub i64 %v612, 32
  store i64 %op613, ptr %slot112, align 8
  %v614 = load i64, ptr %slot102, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %rgep616 = getelementptr i8, ptr %p615, i64 -32
  %ld617 = load i64, ptr %rgep616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld617, ptr %slot113, align 8
  %v618 = load i64, ptr %slot113, align 8
  %cmp619 = icmp ne i64 %v618, 0
  %cv620 = zext i1 %cmp619 to i32
  store i32 %cv620, ptr %slot114, align 8
  %v621 = load i32, ptr %slot114, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcgdec140, label %bb_rcgslow140
bb_rcgslow140:
  %v624 = load i64, ptr %slot101, align 8
  %v625 = load i64, ptr %slot98, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v624, i64 %v625) nomerge, !dbg !118
  br label %bb_rcgdone140
bb_rcgdec140:
  %v626 = load i64, ptr %slot110, align 8
  %v627 = load i64, ptr %slot102, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %rgep629 = getelementptr i8, ptr %p628, i64 -24
  store i64 %v626, ptr %rgep629, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear140
bb_rcgclear140:
  %v630 = load i64, ptr %slot98, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i64 0, ptr %p631, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone140
bb_rcgdone140:
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v632 = load i64, ptr %slot17, align 8
  store i64 %v632, ptr %slot115, align 8
  %v633 = load i64, ptr %slot98, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ld635 = load i64, ptr %p634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld635, ptr %slot116, align 8
  %v636 = load i64, ptr %slot116, align 8
  %cmp637 = icmp ne i64 %v636, 0
  %cv638 = zext i1 %cmp637 to i32
  store i32 %cv638, ptr %slot117, align 8
  %v639 = load i32, ptr %slot117, align 8
  %cv640 = zext i32 %v639 to i64
  %cond641 = icmp ne i64 %cv640, 0
  br i1 %cond641, label %bb_rcgnn155, label %bb_rcgdone155
bb_rcgnn155:
  %v642 = load i64, ptr %slot116, align 8
  %op643 = sub i64 %v642, 16
  store i64 %op643, ptr %slot118, align 8
  %v644 = load i64, ptr %slot116, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %rgep646 = getelementptr i8, ptr %p645, i64 -16
  %ld647 = load i64, ptr %rgep646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld647, ptr %slot119, align 8
  %v648 = load i64, ptr %slot119, align 8
  %op649 = and i64 %v648, 4611686018427387906
  store i64 %op649, ptr %slot120, align 8
  %v650 = load i64, ptr %slot120, align 8
  %cmp651 = icmp ne i64 %v650, 0
  %cv652 = zext i1 %cmp651 to i32
  store i32 %cv652, ptr %slot121, align 8
  %v653 = load i32, ptr %slot121, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcgclear155, label %bb_rcgcounted155
bb_rcgcounted155:
  %v656 = load i64, ptr %slot116, align 8
  %op657 = sub i64 %v656, 32
  store i64 %op657, ptr %slot122, align 8
  %v658 = load i64, ptr %slot116, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %rgep660 = getelementptr i8, ptr %p659, i64 -32
  %ld661 = load i64, ptr %rgep660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld661, ptr %slot123, align 8
  %v662 = load i64, ptr %slot123, align 8
  %op663 = sub i64 %v662, 1
  store i64 %op663, ptr %slot124, align 8
  %v664 = load i64, ptr %slot124, align 8
  %cmp665 = icmp eq i64 %v664, 0
  %cv666 = zext i1 %cmp665 to i32
  store i32 %cv666, ptr %slot125, align 8
  %v667 = load i32, ptr %slot125, align 8
  %cv668 = zext i32 %v667 to i64
  %cond669 = icmp ne i64 %cv668, 0
  br i1 %cond669, label %bb_rcglast155, label %bb_rcgdec155
bb_rcglast155:
  %v670 = load i64, ptr %slot116, align 8
  %op671 = sub i64 %v670, 24
  store i64 %op671, ptr %slot126, align 8
  %v672 = load i64, ptr %slot116, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %rgep674 = getelementptr i8, ptr %p673, i64 -24
  %ld675 = load i64, ptr %rgep674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld675, ptr %slot127, align 8
  %v676 = load i64, ptr %slot127, align 8
  %cmp677 = icmp ne i64 %v676, 0
  %cv678 = zext i1 %cmp677 to i32
  store i32 %cv678, ptr %slot128, align 8
  %v679 = load i32, ptr %slot128, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcgdec155, label %bb_rcgslow155
bb_rcgslow155:
  %v682 = load i64, ptr %slot115, align 8
  %v683 = load i64, ptr %slot98, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v682, i64 %v683) nomerge, !dbg !118
  br label %bb_rcgdone155
bb_rcgdec155:
  %v684 = load i64, ptr %slot124, align 8
  %v685 = load i64, ptr %slot116, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %rgep687 = getelementptr i8, ptr %p686, i64 -32
  store i64 %v684, ptr %rgep687, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear155
bb_rcgclear155:
  %v688 = load i64, ptr %slot98, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 0, ptr %p689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone155
bb_rcgdone155:
  br label %bb_rcslotdone124
bb_rcslotdone124:
  br label %bb_rcprepared70
bb_rcprepared70:
  %v690 = load i64, ptr %slot11, align 8
  store i64 %v690, ptr %slot129, align 8
  %v691 = load i64, ptr %slot129, align 8
  %p692 = inttoptr i64 %v691 to ptr
  %ld693 = load i64, ptr %p692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld693, ptr %slot130, align 8
  %v694 = load i64, ptr %slot7, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i32 0, ptr %p695, align 4, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot5, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %ld698 = load i32, ptr %p697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld698, ptr %slot131, align 8
  %v699 = load i32, ptr %slot131, align 8
  %cv700 = zext i32 %v699 to i64
  %cond701 = icmp ne i64 %cv700, 0
  br i1 %cond701, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v702 = load i64, ptr %slot5, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i32 0, ptr %p703, align 4, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot9, align 8
  store i64 %v704, ptr %slot132, align 8
  %v705 = load i64, ptr %slot6, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i32, ptr %p706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld707, ptr %slot133, align 8
  %v708 = load i32, ptr %slot133, align 8
  %op709 = and i32 %v708, 28
  store i32 %op709, ptr %slot134, align 8
  %v710 = load i32, ptr %slot134, align 8
  %cv711 = zext i32 %v710 to i64
  %cond712 = icmp ne i64 %cv711, 0
  br i1 %cond712, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v713 = load i64, ptr %slot17, align 8
  store i64 %v713, ptr %slot135, align 8
  %v714 = load i64, ptr %slot132, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i64, ptr %p715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld716, ptr %slot136, align 8
  %v717 = load i64, ptr %slot136, align 8
  %cmp718 = icmp ne i64 %v717, 0
  %cv719 = zext i1 %cmp718 to i32
  store i32 %cv719, ptr %slot137, align 8
  %v720 = load i32, ptr %slot137, align 8
  %cv721 = zext i32 %v720 to i64
  %cond722 = icmp ne i64 %cv721, 0
  br i1 %cond722, label %bb_rcgnn180, label %bb_rcgdone180
bb_rcgnn180:
  %v723 = load i64, ptr %slot136, align 8
  %op724 = sub i64 %v723, 16
  store i64 %op724, ptr %slot138, align 8
  %v725 = load i64, ptr %slot136, align 8
  %p726 = inttoptr i64 %v725 to ptr
  %rgep727 = getelementptr i8, ptr %p726, i64 -16
  %ld728 = load i64, ptr %rgep727, align 8, !alias.scope !9, !noalias !10
  store i64 %ld728, ptr %slot139, align 8
  %v729 = load i64, ptr %slot139, align 8
  %op730 = and i64 %v729, 4611686018427387906
  store i64 %op730, ptr %slot140, align 8
  %v731 = load i64, ptr %slot140, align 8
  %cmp732 = icmp ne i64 %v731, 0
  %cv733 = zext i1 %cmp732 to i32
  store i32 %cv733, ptr %slot141, align 8
  %v734 = load i32, ptr %slot141, align 8
  %cv735 = zext i32 %v734 to i64
  %cond736 = icmp ne i64 %cv735, 0
  br i1 %cond736, label %bb_rcgclear180, label %bb_rcgcounted180
bb_rcgcounted180:
  %v737 = load i64, ptr %slot136, align 8
  %op738 = sub i64 %v737, 24
  store i64 %op738, ptr %slot142, align 8
  %v739 = load i64, ptr %slot136, align 8
  %p740 = inttoptr i64 %v739 to ptr
  %rgep741 = getelementptr i8, ptr %p740, i64 -24
  %ld742 = load i64, ptr %rgep741, align 8, !alias.scope !9, !noalias !10
  store i64 %ld742, ptr %slot143, align 8
  %v743 = load i64, ptr %slot143, align 8
  %op744 = sub i64 %v743, 1
  store i64 %op744, ptr %slot144, align 8
  %v745 = load i64, ptr %slot144, align 8
  %cmp746 = icmp eq i64 %v745, 0
  %cv747 = zext i1 %cmp746 to i32
  store i32 %cv747, ptr %slot145, align 8
  %v748 = load i32, ptr %slot145, align 8
  %cv749 = zext i32 %v748 to i64
  %cond750 = icmp ne i64 %cv749, 0
  br i1 %cond750, label %bb_rcglast180, label %bb_rcgdec180
bb_rcglast180:
  %v751 = load i64, ptr %slot136, align 8
  %op752 = sub i64 %v751, 32
  store i64 %op752, ptr %slot146, align 8
  %v753 = load i64, ptr %slot136, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %rgep755 = getelementptr i8, ptr %p754, i64 -32
  %ld756 = load i64, ptr %rgep755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld756, ptr %slot147, align 8
  %v757 = load i64, ptr %slot147, align 8
  %cmp758 = icmp ne i64 %v757, 0
  %cv759 = zext i1 %cmp758 to i32
  store i32 %cv759, ptr %slot148, align 8
  %v760 = load i32, ptr %slot148, align 8
  %cv761 = zext i32 %v760 to i64
  %cond762 = icmp ne i64 %cv761, 0
  br i1 %cond762, label %bb_rcgdec180, label %bb_rcgslow180
bb_rcgslow180:
  %v763 = load i64, ptr %slot135, align 8
  %v764 = load i64, ptr %slot132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v763, i64 %v764) nomerge, !dbg !118
  br label %bb_rcgdone180
bb_rcgdec180:
  %v765 = load i64, ptr %slot144, align 8
  %v766 = load i64, ptr %slot136, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %rgep768 = getelementptr i8, ptr %p767, i64 -24
  store i64 %v765, ptr %rgep768, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear180
bb_rcgclear180:
  %v769 = load i64, ptr %slot132, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i64 0, ptr %p770, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone180
bb_rcgdone180:
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v771 = load i64, ptr %slot17, align 8
  store i64 %v771, ptr %slot149, align 8
  %v772 = load i64, ptr %slot132, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %ld774 = load i64, ptr %p773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld774, ptr %slot150, align 8
  %v775 = load i64, ptr %slot150, align 8
  %cmp776 = icmp ne i64 %v775, 0
  %cv777 = zext i1 %cmp776 to i32
  store i32 %cv777, ptr %slot151, align 8
  %v778 = load i32, ptr %slot151, align 8
  %cv779 = zext i32 %v778 to i64
  %cond780 = icmp ne i64 %cv779, 0
  br i1 %cond780, label %bb_rcgnn195, label %bb_rcgdone195
bb_rcgnn195:
  %v781 = load i64, ptr %slot150, align 8
  %op782 = sub i64 %v781, 16
  store i64 %op782, ptr %slot152, align 8
  %v783 = load i64, ptr %slot150, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %rgep785 = getelementptr i8, ptr %p784, i64 -16
  %ld786 = load i64, ptr %rgep785, align 8, !alias.scope !9, !noalias !10
  store i64 %ld786, ptr %slot153, align 8
  %v787 = load i64, ptr %slot153, align 8
  %op788 = and i64 %v787, 4611686018427387906
  store i64 %op788, ptr %slot154, align 8
  %v789 = load i64, ptr %slot154, align 8
  %cmp790 = icmp ne i64 %v789, 0
  %cv791 = zext i1 %cmp790 to i32
  store i32 %cv791, ptr %slot155, align 8
  %v792 = load i32, ptr %slot155, align 8
  %cv793 = zext i32 %v792 to i64
  %cond794 = icmp ne i64 %cv793, 0
  br i1 %cond794, label %bb_rcgclear195, label %bb_rcgcounted195
bb_rcgcounted195:
  %v795 = load i64, ptr %slot150, align 8
  %op796 = sub i64 %v795, 32
  store i64 %op796, ptr %slot156, align 8
  %v797 = load i64, ptr %slot150, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %rgep799 = getelementptr i8, ptr %p798, i64 -32
  %ld800 = load i64, ptr %rgep799, align 8, !alias.scope !9, !noalias !10
  store i64 %ld800, ptr %slot157, align 8
  %v801 = load i64, ptr %slot157, align 8
  %op802 = sub i64 %v801, 1
  store i64 %op802, ptr %slot158, align 8
  %v803 = load i64, ptr %slot158, align 8
  %cmp804 = icmp eq i64 %v803, 0
  %cv805 = zext i1 %cmp804 to i32
  store i32 %cv805, ptr %slot159, align 8
  %v806 = load i32, ptr %slot159, align 8
  %cv807 = zext i32 %v806 to i64
  %cond808 = icmp ne i64 %cv807, 0
  br i1 %cond808, label %bb_rcglast195, label %bb_rcgdec195
bb_rcglast195:
  %v809 = load i64, ptr %slot150, align 8
  %op810 = sub i64 %v809, 24
  store i64 %op810, ptr %slot160, align 8
  %v811 = load i64, ptr %slot150, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %rgep813 = getelementptr i8, ptr %p812, i64 -24
  %ld814 = load i64, ptr %rgep813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld814, ptr %slot161, align 8
  %v815 = load i64, ptr %slot161, align 8
  %cmp816 = icmp ne i64 %v815, 0
  %cv817 = zext i1 %cmp816 to i32
  store i32 %cv817, ptr %slot162, align 8
  %v818 = load i32, ptr %slot162, align 8
  %cv819 = zext i32 %v818 to i64
  %cond820 = icmp ne i64 %cv819, 0
  br i1 %cond820, label %bb_rcgdec195, label %bb_rcgslow195
bb_rcgslow195:
  %v821 = load i64, ptr %slot149, align 8
  %v822 = load i64, ptr %slot132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v821, i64 %v822) nomerge, !dbg !118
  br label %bb_rcgdone195
bb_rcgdec195:
  %v823 = load i64, ptr %slot158, align 8
  %v824 = load i64, ptr %slot150, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %rgep826 = getelementptr i8, ptr %p825, i64 -32
  store i64 %v823, ptr %rgep826, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear195
bb_rcgclear195:
  %v827 = load i64, ptr %slot132, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i64 0, ptr %p828, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone195
bb_rcgdone195:
  br label %bb_rcslotdone164
bb_rcslotdone164:
  %v829 = load i64, ptr %slot130, align 8
  ret i64 %v829
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @myl_native_bytes_view(ptr, ptr, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d", linkageName: "myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3341519321707495747, i64 0, !"myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
