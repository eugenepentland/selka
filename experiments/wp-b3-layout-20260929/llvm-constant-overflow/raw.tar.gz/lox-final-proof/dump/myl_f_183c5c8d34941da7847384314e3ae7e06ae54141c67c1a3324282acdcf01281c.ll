target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_183c5c8d34941da7847384314e3ae7e06ae54141c67c1a3324282acdcf01281c(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v19 = load i64, ptr %slot1, align 8
  %op20 = add i64 %v19, 32
  store i64 %op20, ptr %slot3, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot4, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot5, align 8
  %v25 = load i64, ptr %slot2, align 8
  %v26 = load i64, ptr %slot4, align 8
  %p27 = inttoptr i64 %v26 to ptr
  store i64 %v25, ptr %p27, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v28 = load i64, ptr %slot4, align 8
  %p29 = inttoptr i64 %v28 to ptr
  %ld30 = load i64, ptr %p29, align 8, !alias.scope !3, !noalias !4
  store i64 %ld30, ptr %slot6, align 8
  %v31 = load i64, ptr %slot6, align 8
  %v32 = load i64, ptr %slot5, align 8
  %p33 = inttoptr i64 %v32 to ptr
  store i64 %v31, ptr %p33, align 8, !alias.scope !3, !noalias !4
  %v34 = load i64, ptr %slot5, align 8
  %p35 = inttoptr i64 %v34 to ptr
  %ld36 = load i64, ptr %p35, align 8, !alias.scope !3, !noalias !4
  store i64 %ld36, ptr %slot7, align 8
  %v37 = load i64, ptr %slot7, align 8
  %op38 = add i64 %v37, 16
  store i64 %op38, ptr %slot8, align 8
  %v39 = load i64, ptr %slot8, align 8
  %v40 = load i64, ptr %slot5, align 8
  %p41 = inttoptr i64 %v40 to ptr
  store i64 %v39, ptr %p41, align 8, !alias.scope !3, !noalias !4
  %v42 = load i64, ptr %slot5, align 8
  %p43 = inttoptr i64 %v42 to ptr
  %ld44 = load i64, ptr %p43, align 8, !alias.scope !3, !noalias !4
  store i64 %ld44, ptr %slot9, align 8
  %v45 = load i64, ptr %slot9, align 8
  %p46 = inttoptr i64 %v45 to ptr
  %ld47 = load i32, ptr %p46, align 4, !alias.scope !4, !noalias !3
  %ext48 = zext i32 %ld47 to i64
  store i64 %ext48, ptr %slot10, align 8
  %v49 = load i64, ptr %slot10, align 8
  %cmp50 = icmp eq i64 %v49, 0
  %cv51 = zext i1 %cmp50 to i64
  store i64 %cv51, ptr %slot11, align 8
  %v52 = load i64, ptr %slot11, align 8
  %cond53 = icmp ne i64 %v52, 0
  br i1 %cond53, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i3
bb_armnext5:
  %v54 = load i64, ptr %slot10, align 8
  %cmp55 = icmp eq i64 %v54, 1
  %cv56 = zext i1 %cmp55 to i64
  store i64 %cv56, ptr %slot12, align 8
  %v57 = load i64, ptr %slot12, align 8
  %cond58 = icmp ne i64 %v57, 0
  br i1 %cond58, label %bb_arm6, label %bb_armnext6
bb_arm6:
  br label %bb_i5
bb_armnext6:
  %v59 = load i64, ptr %slot10, align 8
  %cmp60 = icmp eq i64 %v59, 2
  %cv61 = zext i1 %cmp60 to i64
  store i64 %cv61, ptr %slot13, align 8
  %v62 = load i64, ptr %slot13, align 8
  %cond63 = icmp ne i64 %v62, 0
  br i1 %cond63, label %bb_arm7, label %bb_armnext7
bb_arm7:
  br label %bb_i7
bb_armnext7:
  %v64 = load i64, ptr %slot10, align 8
  %cmp65 = icmp eq i64 %v64, 3
  %cv66 = zext i1 %cmp65 to i64
  store i64 %cv66, ptr %slot14, align 8
  %v67 = load i64, ptr %slot14, align 8
  %cond68 = icmp ne i64 %v67, 0
  br i1 %cond68, label %bb_arm8, label %bb_armnext8
bb_arm8:
  br label %bb_i9
bb_armnext8:
  br label %bb_failure
bb_i3:
  %v69 = load i64, ptr %slot5, align 8
  %p70 = inttoptr i64 %v69 to ptr
  store i64 0, ptr %p70, align 8, !alias.scope !3, !noalias !4
  %v71 = load i64, ptr %slot5, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !3, !noalias !4
  store i64 %ld73, ptr %slot15, align 8
  %v74 = load i64, ptr %slot15, align 8
  ret i64 %v74
bb_i5:
  %v75 = load i64, ptr %slot5, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 1, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot5, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot16, align 8
  %v80 = load i64, ptr %slot16, align 8
  ret i64 %v80
bb_i7:
  %v81 = load i64, ptr %slot5, align 8
  %p82 = inttoptr i64 %v81 to ptr
  store i64 1, ptr %p82, align 8, !alias.scope !3, !noalias !4
  %v83 = load i64, ptr %slot5, align 8
  %p84 = inttoptr i64 %v83 to ptr
  %ld85 = load i64, ptr %p84, align 8, !alias.scope !3, !noalias !4
  store i64 %ld85, ptr %slot17, align 8
  %v86 = load i64, ptr %slot17, align 8
  ret i64 %v86
bb_i9:
  %v87 = load i64, ptr %slot5, align 8
  %p88 = inttoptr i64 %v87 to ptr
  store i64 1, ptr %p88, align 8, !alias.scope !3, !noalias !4
  %v89 = load i64, ptr %slot5, align 8
  %p90 = inttoptr i64 %v89 to ptr
  %ld91 = load i64, ptr %p90, align 8, !alias.scope !3, !noalias !4
  store i64 %ld91, ptr %slot18, align 8
  %v92 = load i64, ptr %slot18, align 8
  ret i64 %v92
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
