target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v538 = load i64, ptr %slot1, align 8
  %op539 = add i64 %v538, 32
  store i64 %op539, ptr %slot3, align 8
  %mem540 = alloca i8, i64 8, align 8
  %ptr541 = ptrtoint ptr %mem540 to i64
  store i64 %ptr541, ptr %slot4, align 8
  %mem542 = alloca i8, i64 8, align 8
  %ptr543 = ptrtoint ptr %mem542 to i64
  store i64 %ptr543, ptr %slot5, align 8
  %mem544 = alloca i8, i64 8, align 8
  %ptr545 = ptrtoint ptr %mem544 to i64
  store i64 %ptr545, ptr %slot6, align 8
  %mem546 = alloca i8, i64 8, align 8
  %ptr547 = ptrtoint ptr %mem546 to i64
  store i64 %ptr547, ptr %slot7, align 8
  %mem548 = alloca i8, i64 8, align 8
  %ptr549 = ptrtoint ptr %mem548 to i64
  store i64 %ptr549, ptr %slot8, align 8
  %mem550 = alloca i8, i64 8, align 8
  %ptr551 = ptrtoint ptr %mem550 to i64
  store i64 %ptr551, ptr %slot9, align 8
  %mem552 = alloca i8, i64 8, align 8
  %ptr553 = ptrtoint ptr %mem552 to i64
  store i64 %ptr553, ptr %slot10, align 8
  %mem554 = alloca i8, i64 104, align 8
  %ptr555 = ptrtoint ptr %mem554 to i64
  store i64 %ptr555, ptr %slot11, align 8
  %mem556 = alloca i8, i64 8, align 8
  %ptr557 = ptrtoint ptr %mem556 to i64
  store i64 %ptr557, ptr %slot12, align 8
  %mem558 = alloca i8, i64 104, align 8
  %ptr559 = ptrtoint ptr %mem558 to i64
  store i64 %ptr559, ptr %slot13, align 8
  %mem560 = alloca i8, i64 32, align 8
  %ptr561 = ptrtoint ptr %mem560 to i64
  store i64 %ptr561, ptr %slot14, align 8
  %v562 = load i64, ptr %slot14, align 8
  %p564 = inttoptr i64 %v562 to ptr
  %gep565 = getelementptr i8, ptr %p564, i64 24
  %op563 = ptrtoint ptr %gep565 to i64
  store i64 %op563, ptr %slot15, align 8
  %v566 = load i64, ptr %slot15, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 0, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %mem568 = alloca i8, i64 8, align 8
  %ptr569 = ptrtoint ptr %mem568 to i64
  store i64 %ptr569, ptr %slot16, align 8
  %mem570 = alloca i8, i64 8, align 8
  %ptr571 = ptrtoint ptr %mem570 to i64
  store i64 %ptr571, ptr %slot17, align 8
  %mem572 = alloca i8, i64 8, align 8
  %ptr573 = ptrtoint ptr %mem572 to i64
  store i64 %ptr573, ptr %slot18, align 8
  %mem574 = alloca i8, i64 8, align 8
  %ptr575 = ptrtoint ptr %mem574 to i64
  store i64 %ptr575, ptr %slot19, align 8
  %mem576 = alloca i8, i64 8, align 8
  %ptr577 = ptrtoint ptr %mem576 to i64
  store i64 %ptr577, ptr %slot20, align 8
  %mem578 = alloca i8, i64 8, align 8
  %ptr579 = ptrtoint ptr %mem578 to i64
  store i64 %ptr579, ptr %slot21, align 8
  %v580 = load i64, ptr %slot18, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 0, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot19, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i64 0, ptr %p583, align 8, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot2, align 8
  %v585 = load i64, ptr %slot17, align 8
  %p586 = inttoptr i64 %v585 to ptr
  store i64 %v584, ptr %p586, align 8, !alias.scope !3, !noalias !4
  %v587 = load i64, ptr %slot1, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %call589 = call ptr @myl_qbe_heap(ptr %p588) nomerge, !dbg !110
  %calladdr590 = ptrtoint ptr %call589 to i64
  store i64 %calladdr590, ptr %slot22, align 8
  %v591 = load i64, ptr %slot1, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %call593 = call i64 @myl_qbe_region_mark(ptr %p592) nomerge, !dbg !110
  store i64 %call593, ptr %slot23, align 8
  %v594 = load i64, ptr %slot4, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 0, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot5, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 0, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot6, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i32 0, ptr %p599, align 4, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot7, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i32 0, ptr %p601, align 4, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot8, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i32 0, ptr %p603, align 4, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot9, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot10, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i32 0, ptr %p607, align 4, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot5, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 2, ptr %p609, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v610 = load i64, ptr %slot17, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot24, align 8
  %v613 = load i64, ptr %slot24, align 8
  %v614 = load i64, ptr %slot20, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 %v613, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot20, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i64, ptr %p617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld618, ptr %slot25, align 8
  %v619 = load i64, ptr %slot25, align 8
  %op620 = add i64 %v619, 80
  store i64 %op620, ptr %slot26, align 8
  %v621 = load i64, ptr %slot26, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ld623 = load i64, ptr %p622, align 8, !alias.scope !4, !noalias !3
  store i64 %ld623, ptr %slot27, align 8
  %v624 = load i64, ptr %slot27, align 8
  %v625 = load i64, ptr %slot20, align 8
  %p626 = inttoptr i64 %v625 to ptr
  store i64 %v624, ptr %p626, align 8, !alias.scope !3, !noalias !4
  %v627 = load i64, ptr %slot20, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %ld629 = load i64, ptr %p628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld629, ptr %slot28, align 8
  %v630 = load i64, ptr %slot28, align 8
  %v631 = load i64, ptr %slot12, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i64 %v630, ptr %p632, align 8, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot12, align 8
  store i64 %v633, ptr %slot29, align 8
  %v634 = load i64, ptr %slot13, align 8
  store i64 %v634, ptr %slot30, align 8
  %v635 = load i64, ptr %slot29, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot31, align 8
  %v638 = load i64, ptr %slot31, align 8
  %cmp639 = icmp ne i64 %v638, 0
  %cv640 = zext i1 %cmp639 to i32
  store i32 %cv640, ptr %slot32, align 8
  %v641 = load i32, ptr %slot32, align 8
  %cv642 = zext i32 %v641 to i64
  %cond643 = icmp ne i64 %cv642, 0
  br i1 %cond643, label %bb_rcgnn12, label %bb_rcgstore12
bb_rcgnn12:
  %v644 = load i64, ptr %slot31, align 8
  %op645 = sub i64 %v644, 16
  store i64 %op645, ptr %slot33, align 8
  %v646 = load i64, ptr %slot31, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %rgep648 = getelementptr i8, ptr %p647, i64 -16
  %ld649 = load i64, ptr %rgep648, align 8, !alias.scope !9, !noalias !10
  store i64 %ld649, ptr %slot34, align 8
  %v650 = load i64, ptr %slot34, align 8
  %op651 = and i64 %v650, 4611686018427387906
  store i64 %op651, ptr %slot35, align 8
  %v652 = load i64, ptr %slot35, align 8
  %cmp653 = icmp ne i64 %v652, 0
  %cv654 = zext i1 %cmp653 to i32
  store i32 %cv654, ptr %slot36, align 8
  %v655 = load i32, ptr %slot36, align 8
  %cv656 = zext i32 %v655 to i64
  %cond657 = icmp ne i64 %cv656, 0
  br i1 %cond657, label %bb_rcgstore12, label %bb_rcginc12
bb_rcginc12:
  %v658 = load i64, ptr %slot31, align 8
  %op659 = sub i64 %v658, 24
  store i64 %op659, ptr %slot37, align 8
  %v660 = load i64, ptr %slot31, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %rgep662 = getelementptr i8, ptr %p661, i64 -24
  %ld663 = load i64, ptr %rgep662, align 8, !alias.scope !9, !noalias !10
  store i64 %ld663, ptr %slot38, align 8
  %v664 = load i64, ptr %slot38, align 8
  %op665 = add i64 %v664, 1
  store i64 %op665, ptr %slot39, align 8
  %v666 = load i64, ptr %slot39, align 8
  %cmp667 = icmp eq i64 %v666, 0
  %cv668 = zext i1 %cmp667 to i32
  store i32 %cv668, ptr %slot40, align 8
  %v669 = load i32, ptr %slot40, align 8
  %cv670 = zext i32 %v669 to i64
  %cond671 = icmp ne i64 %cv670, 0
  br i1 %cond671, label %bb_rcglimit12, label %bb_rcgcapacity12
bb_rcglimit12:
  %v672 = load i64, ptr %slot1, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %call674 = call i32 @myl_qbe_rc_status(ptr %p673, i32 2) nomerge, !dbg !112
  store i32 %call674, ptr %slot41, align 8
  br label %bb_failure
bb_rcgcapacity12:
  %v675 = load i64, ptr %slot39, align 8
  %v676 = load i64, ptr %slot31, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %rgep678 = getelementptr i8, ptr %p677, i64 -24
  store i64 %v675, ptr %rgep678, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore12
bb_rcgstore12:
  %v679 = load i64, ptr %slot31, align 8
  %v680 = load i64, ptr %slot30, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot9, align 8
  %p683 = inttoptr i64 %v682 to ptr
  store i32 2, ptr %p683, align 4, !alias.scope !3, !noalias !4
  %v684 = load i64, ptr %slot9, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i32 16, ptr %p685, align 4, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot8, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i32 1, ptr %p687, align 4, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot6, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i32, ptr %p689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld690, ptr %slot42, align 8
  %v691 = load i32, ptr %slot42, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcslotdrop28, label %bb_rcslotdone28
bb_rcslotdrop28:
  %v694 = load i64, ptr %slot6, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i32 0, ptr %p695, align 4, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot11, align 8
  store i64 %v696, ptr %slot43, align 8
  %v697 = load i64, ptr %slot7, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i32, ptr %p698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld699, ptr %slot44, align 8
  %v700 = load i32, ptr %slot44, align 8
  %op701 = and i32 %v700, 28
  store i32 %op701, ptr %slot45, align 8
  %v702 = load i32, ptr %slot45, align 8
  %cv703 = zext i32 %v702 to i64
  %cond704 = icmp ne i64 %cv703, 0
  br i1 %cond704, label %bb_rcslotrole28, label %bb_rcslotowner28
bb_rcslotrole28:
  %v705 = load i64, ptr %slot22, align 8
  store i64 %v705, ptr %slot46, align 8
  %v706 = load i64, ptr %slot46, align 8
  %v707 = load i64, ptr %slot43, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v706, i64 %v707) nomerge, !dbg !112
  br label %bb_rcslotdone28
bb_rcslotowner28:
  %v708 = load i64, ptr %slot22, align 8
  store i64 %v708, ptr %slot47, align 8
  %v709 = load i64, ptr %slot47, align 8
  %v710 = load i64, ptr %slot43, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v709, i64 %v710) nomerge, !dbg !112
  br label %bb_rcslotdone28
bb_rcslotdone28:
  %v711 = load i64, ptr %slot11, align 8
  store i64 %v711, ptr %slot48, align 8
  %v712 = load i64, ptr %slot13, align 8
  store i64 %v712, ptr %slot49, align 8
  %v713 = load i64, ptr %slot49, align 8
  %v714 = load i64, ptr %slot48, align 8
  %p715 = inttoptr i64 %v713 to ptr
  %p716 = inttoptr i64 %v714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p716, ptr %p715, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot7, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i32 2, ptr %p718, align 4, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot9, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %ld721 = load i32, ptr %p720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld721, ptr %slot50, align 8
  %v722 = load i32, ptr %slot50, align 8
  %v723 = load i64, ptr %slot7, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i32 %v722, ptr %p724, align 4, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot8, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 0, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot6, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 1, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot48, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i64, ptr %p730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld731, ptr %slot51, align 8
  %v732 = load i64, ptr %slot51, align 8
  %v733 = load i64, ptr %slot20, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot20, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot52, align 8
  %v738 = load i64, ptr %slot17, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot53, align 8
  %v741 = load i64, ptr %slot6, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i32, ptr %p742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld743, ptr %slot54, align 8
  %v744 = load i32, ptr %slot54, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcslotdrop49, label %bb_rcslotdone49
bb_rcslotdrop49:
  %v747 = load i64, ptr %slot6, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i32 0, ptr %p748, align 4, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot11, align 8
  store i64 %v749, ptr %slot55, align 8
  %v750 = load i64, ptr %slot7, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i32, ptr %p751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld752, ptr %slot56, align 8
  %v753 = load i32, ptr %slot56, align 8
  %op754 = and i32 %v753, 28
  store i32 %op754, ptr %slot57, align 8
  %v755 = load i32, ptr %slot57, align 8
  %cv756 = zext i32 %v755 to i64
  %cond757 = icmp ne i64 %cv756, 0
  br i1 %cond757, label %bb_rcslotrole49, label %bb_rcslotowner49
bb_rcslotrole49:
  %v758 = load i64, ptr %slot22, align 8
  store i64 %v758, ptr %slot58, align 8
  %v759 = load i64, ptr %slot55, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i64, ptr %p760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld761, ptr %slot59, align 8
  %v762 = load i64, ptr %slot59, align 8
  %cmp763 = icmp ne i64 %v762, 0
  %cv764 = zext i1 %cmp763 to i32
  store i32 %cv764, ptr %slot60, align 8
  %v765 = load i32, ptr %slot60, align 8
  %cv766 = zext i32 %v765 to i64
  %cond767 = icmp ne i64 %cv766, 0
  br i1 %cond767, label %bb_rcgnn65, label %bb_rcgdone65
bb_rcgnn65:
  %v768 = load i64, ptr %slot59, align 8
  %op769 = sub i64 %v768, 16
  store i64 %op769, ptr %slot61, align 8
  %v770 = load i64, ptr %slot59, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %rgep772 = getelementptr i8, ptr %p771, i64 -16
  %ld773 = load i64, ptr %rgep772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld773, ptr %slot62, align 8
  %v774 = load i64, ptr %slot62, align 8
  %op775 = and i64 %v774, 4611686018427387906
  store i64 %op775, ptr %slot63, align 8
  %v776 = load i64, ptr %slot63, align 8
  %cmp777 = icmp ne i64 %v776, 0
  %cv778 = zext i1 %cmp777 to i32
  store i32 %cv778, ptr %slot64, align 8
  %v779 = load i32, ptr %slot64, align 8
  %cv780 = zext i32 %v779 to i64
  %cond781 = icmp ne i64 %cv780, 0
  br i1 %cond781, label %bb_rcgclear65, label %bb_rcgcounted65
bb_rcgcounted65:
  %v782 = load i64, ptr %slot59, align 8
  %op783 = sub i64 %v782, 24
  store i64 %op783, ptr %slot65, align 8
  %v784 = load i64, ptr %slot59, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %rgep786 = getelementptr i8, ptr %p785, i64 -24
  %ld787 = load i64, ptr %rgep786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld787, ptr %slot66, align 8
  %v788 = load i64, ptr %slot66, align 8
  %op789 = sub i64 %v788, 1
  store i64 %op789, ptr %slot67, align 8
  %v790 = load i64, ptr %slot67, align 8
  %cmp791 = icmp eq i64 %v790, 0
  %cv792 = zext i1 %cmp791 to i32
  store i32 %cv792, ptr %slot68, align 8
  %v793 = load i32, ptr %slot68, align 8
  %cv794 = zext i32 %v793 to i64
  %cond795 = icmp ne i64 %cv794, 0
  br i1 %cond795, label %bb_rcglast65, label %bb_rcgdec65
bb_rcglast65:
  %v796 = load i64, ptr %slot59, align 8
  %op797 = sub i64 %v796, 32
  store i64 %op797, ptr %slot69, align 8
  %v798 = load i64, ptr %slot59, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %rgep800 = getelementptr i8, ptr %p799, i64 -32
  %ld801 = load i64, ptr %rgep800, align 8, !alias.scope !9, !noalias !10
  store i64 %ld801, ptr %slot70, align 8
  %v802 = load i64, ptr %slot70, align 8
  %cmp803 = icmp ne i64 %v802, 0
  %cv804 = zext i1 %cmp803 to i32
  store i32 %cv804, ptr %slot71, align 8
  %v805 = load i32, ptr %slot71, align 8
  %cv806 = zext i32 %v805 to i64
  %cond807 = icmp ne i64 %cv806, 0
  br i1 %cond807, label %bb_rcgdec65, label %bb_rcgslow65
bb_rcgslow65:
  %v808 = load i64, ptr %slot58, align 8
  %v809 = load i64, ptr %slot55, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v808, i64 %v809) nomerge, !dbg !114
  br label %bb_rcgdone65
bb_rcgdec65:
  %v810 = load i64, ptr %slot67, align 8
  %v811 = load i64, ptr %slot59, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %rgep813 = getelementptr i8, ptr %p812, i64 -24
  store i64 %v810, ptr %rgep813, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear65
bb_rcgclear65:
  %v814 = load i64, ptr %slot55, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 0, ptr %p815, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone65
bb_rcgdone65:
  br label %bb_rcslotdone49
bb_rcslotowner49:
  %v816 = load i64, ptr %slot22, align 8
  store i64 %v816, ptr %slot72, align 8
  %v817 = load i64, ptr %slot55, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot73, align 8
  %v820 = load i64, ptr %slot73, align 8
  %cmp821 = icmp ne i64 %v820, 0
  %cv822 = zext i1 %cmp821 to i32
  store i32 %cv822, ptr %slot74, align 8
  %v823 = load i32, ptr %slot74, align 8
  %cv824 = zext i32 %v823 to i64
  %cond825 = icmp ne i64 %cv824, 0
  br i1 %cond825, label %bb_rcgnn80, label %bb_rcgdone80
bb_rcgnn80:
  %v826 = load i64, ptr %slot73, align 8
  %op827 = sub i64 %v826, 16
  store i64 %op827, ptr %slot75, align 8
  %v828 = load i64, ptr %slot73, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %rgep830 = getelementptr i8, ptr %p829, i64 -16
  %ld831 = load i64, ptr %rgep830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld831, ptr %slot76, align 8
  %v832 = load i64, ptr %slot76, align 8
  %op833 = and i64 %v832, 4611686018427387906
  store i64 %op833, ptr %slot77, align 8
  %v834 = load i64, ptr %slot77, align 8
  %cmp835 = icmp ne i64 %v834, 0
  %cv836 = zext i1 %cmp835 to i32
  store i32 %cv836, ptr %slot78, align 8
  %v837 = load i32, ptr %slot78, align 8
  %cv838 = zext i32 %v837 to i64
  %cond839 = icmp ne i64 %cv838, 0
  br i1 %cond839, label %bb_rcgclear80, label %bb_rcgcounted80
bb_rcgcounted80:
  %v840 = load i64, ptr %slot73, align 8
  %op841 = sub i64 %v840, 32
  store i64 %op841, ptr %slot79, align 8
  %v842 = load i64, ptr %slot73, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %rgep844 = getelementptr i8, ptr %p843, i64 -32
  %ld845 = load i64, ptr %rgep844, align 8, !alias.scope !9, !noalias !10
  store i64 %ld845, ptr %slot80, align 8
  %v846 = load i64, ptr %slot80, align 8
  %op847 = sub i64 %v846, 1
  store i64 %op847, ptr %slot81, align 8
  %v848 = load i64, ptr %slot81, align 8
  %cmp849 = icmp eq i64 %v848, 0
  %cv850 = zext i1 %cmp849 to i32
  store i32 %cv850, ptr %slot82, align 8
  %v851 = load i32, ptr %slot82, align 8
  %cv852 = zext i32 %v851 to i64
  %cond853 = icmp ne i64 %cv852, 0
  br i1 %cond853, label %bb_rcglast80, label %bb_rcgdec80
bb_rcglast80:
  %v854 = load i64, ptr %slot73, align 8
  %op855 = sub i64 %v854, 24
  store i64 %op855, ptr %slot83, align 8
  %v856 = load i64, ptr %slot73, align 8
  %p857 = inttoptr i64 %v856 to ptr
  %rgep858 = getelementptr i8, ptr %p857, i64 -24
  %ld859 = load i64, ptr %rgep858, align 8, !alias.scope !9, !noalias !10
  store i64 %ld859, ptr %slot84, align 8
  %v860 = load i64, ptr %slot84, align 8
  %cmp861 = icmp ne i64 %v860, 0
  %cv862 = zext i1 %cmp861 to i32
  store i32 %cv862, ptr %slot85, align 8
  %v863 = load i32, ptr %slot85, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcgdec80, label %bb_rcgslow80
bb_rcgslow80:
  %v866 = load i64, ptr %slot72, align 8
  %v867 = load i64, ptr %slot55, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v866, i64 %v867) nomerge, !dbg !114
  br label %bb_rcgdone80
bb_rcgdec80:
  %v868 = load i64, ptr %slot81, align 8
  %v869 = load i64, ptr %slot73, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %rgep871 = getelementptr i8, ptr %p870, i64 -32
  store i64 %v868, ptr %rgep871, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear80
bb_rcgclear80:
  %v872 = load i64, ptr %slot55, align 8
  %p873 = inttoptr i64 %v872 to ptr
  store i64 0, ptr %p873, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone80
bb_rcgdone80:
  br label %bb_rcslotdone49
bb_rcslotdone49:
  %v874 = load i64, ptr %slot53, align 8
  %op875 = add i64 %v874, 80
  store i64 %op875, ptr %slot86, align 8
  store i64 0, ptr %slot87, align 8
  %v876 = load i64, ptr %slot86, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !4, !noalias !3
  store i64 %ld878, ptr %slot88, align 8
  %v879 = load i64, ptr %slot88, align 8
  %cmp880 = icmp ne i64 %v879, 0
  %cv881 = zext i1 %cmp880 to i32
  store i32 %cv881, ptr %slot89, align 8
  %v882 = load i32, ptr %slot89, align 8
  %cv883 = zext i32 %v882 to i64
  %cond884 = icmp ne i64 %cv883, 0
  br i1 %cond884, label %bb_rcguniquenn86, label %bb_rcgunique86
bb_rcguniquenn86:
  %v885 = load i64, ptr %slot88, align 8
  %op886 = sub i64 %v885, 16
  store i64 %op886, ptr %slot90, align 8
  %v887 = load i64, ptr %slot88, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %rgep889 = getelementptr i8, ptr %p888, i64 -16
  %ld890 = load i64, ptr %rgep889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld890, ptr %slot91, align 8
  %v891 = load i64, ptr %slot91, align 8
  %op892 = and i64 %v891, 6917529027641081858
  store i64 %op892, ptr %slot92, align 8
  %v893 = load i64, ptr %slot92, align 8
  %cmp894 = icmp ne i64 %v893, 0
  %cv895 = zext i1 %cmp894 to i32
  store i32 %cv895, ptr %slot93, align 8
  %v896 = load i32, ptr %slot93, align 8
  %cv897 = zext i32 %v896 to i64
  %cond898 = icmp ne i64 %cv897, 0
  br i1 %cond898, label %bb_rcguniqueslow86, label %bb_rcguniquecount86
bb_rcguniquecount86:
  %v899 = load i64, ptr %slot88, align 8
  %op900 = sub i64 %v899, 32
  store i64 %op900, ptr %slot94, align 8
  %v901 = load i64, ptr %slot88, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %rgep903 = getelementptr i8, ptr %p902, i64 -32
  %ld904 = load i64, ptr %rgep903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld904, ptr %slot95, align 8
  %v905 = load i64, ptr %slot95, align 8
  %cmp906 = icmp ult i64 %v905, 2
  %cv907 = zext i1 %cmp906 to i32
  store i32 %cv907, ptr %slot96, align 8
  %v908 = load i32, ptr %slot96, align 8
  %cv909 = zext i32 %v908 to i64
  %cond910 = icmp ne i64 %cv909, 0
  br i1 %cond910, label %bb_rcgunique86, label %bb_rcguniqueslow86
bb_rcguniqueslow86:
  %v911 = load i64, ptr %slot1, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %p913 = inttoptr i64 ptrtoint (ptr @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50 to i64) to ptr
  %v914 = load i64, ptr %slot86, align 8
  %p915 = inttoptr i64 %v914 to ptr
  %v916 = load i64, ptr %slot87, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %call918 = call i32 @myl_qbe_rc_unique_field(ptr %p912, ptr %p913, ptr %p915, ptr %p917) nomerge, !dbg !114
  store i32 %call918, ptr %slot97, align 8
  %v919 = load i32, ptr %slot97, align 8
  %cv920 = zext i32 %v919 to i64
  %cond921 = icmp ne i64 %cv920, 0
  br i1 %cond921, label %bb_rcunique96, label %bb_failure
bb_rcunique96:
  br label %bb_rcgunique86
bb_rcgunique86:
  %v922 = load i64, ptr %slot86, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i64, ptr %p923, align 8, !alias.scope !4, !noalias !3
  store i64 %ld924, ptr %slot98, align 8
  %v925 = load i64, ptr %slot98, align 8
  %v926 = load i64, ptr %slot20, align 8
  %p927 = inttoptr i64 %v926 to ptr
  store i64 %v925, ptr %p927, align 8, !alias.scope !3, !noalias !4
  %v928 = load i64, ptr %slot20, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %ld930 = load i64, ptr %p929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld930, ptr %slot99, align 8
  %v931 = load i64, ptr %slot6, align 8
  %p932 = inttoptr i64 %v931 to ptr
  %ld933 = load i32, ptr %p932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld933, ptr %slot100, align 8
  %v934 = load i32, ptr %slot100, align 8
  %cv935 = zext i32 %v934 to i64
  %cond936 = icmp ne i64 %cv935, 0
  br i1 %cond936, label %bb_rcslotdrop101, label %bb_rcslotdone101
bb_rcslotdrop101:
  %v937 = load i64, ptr %slot6, align 8
  %p938 = inttoptr i64 %v937 to ptr
  store i32 0, ptr %p938, align 4, !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot11, align 8
  store i64 %v939, ptr %slot101, align 8
  %v940 = load i64, ptr %slot7, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i32, ptr %p941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld942, ptr %slot102, align 8
  %v943 = load i32, ptr %slot102, align 8
  %op944 = and i32 %v943, 28
  store i32 %op944, ptr %slot103, align 8
  %v945 = load i32, ptr %slot103, align 8
  %cv946 = zext i32 %v945 to i64
  %cond947 = icmp ne i64 %cv946, 0
  br i1 %cond947, label %bb_rcslotrole101, label %bb_rcslotowner101
bb_rcslotrole101:
  %v948 = load i64, ptr %slot22, align 8
  store i64 %v948, ptr %slot104, align 8
  %v949 = load i64, ptr %slot101, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ld951 = load i64, ptr %p950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld951, ptr %slot105, align 8
  %v952 = load i64, ptr %slot105, align 8
  %cmp953 = icmp ne i64 %v952, 0
  %cv954 = zext i1 %cmp953 to i32
  store i32 %cv954, ptr %slot106, align 8
  %v955 = load i32, ptr %slot106, align 8
  %cv956 = zext i32 %v955 to i64
  %cond957 = icmp ne i64 %cv956, 0
  br i1 %cond957, label %bb_rcgnn117, label %bb_rcgdone117
bb_rcgnn117:
  %v958 = load i64, ptr %slot105, align 8
  %op959 = sub i64 %v958, 16
  store i64 %op959, ptr %slot107, align 8
  %v960 = load i64, ptr %slot105, align 8
  %p961 = inttoptr i64 %v960 to ptr
  %rgep962 = getelementptr i8, ptr %p961, i64 -16
  %ld963 = load i64, ptr %rgep962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld963, ptr %slot108, align 8
  %v964 = load i64, ptr %slot108, align 8
  %op965 = and i64 %v964, 4611686018427387906
  store i64 %op965, ptr %slot109, align 8
  %v966 = load i64, ptr %slot109, align 8
  %cmp967 = icmp ne i64 %v966, 0
  %cv968 = zext i1 %cmp967 to i32
  store i32 %cv968, ptr %slot110, align 8
  %v969 = load i32, ptr %slot110, align 8
  %cv970 = zext i32 %v969 to i64
  %cond971 = icmp ne i64 %cv970, 0
  br i1 %cond971, label %bb_rcgclear117, label %bb_rcgcounted117
bb_rcgcounted117:
  %v972 = load i64, ptr %slot105, align 8
  %op973 = sub i64 %v972, 24
  store i64 %op973, ptr %slot111, align 8
  %v974 = load i64, ptr %slot105, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %rgep976 = getelementptr i8, ptr %p975, i64 -24
  %ld977 = load i64, ptr %rgep976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld977, ptr %slot112, align 8
  %v978 = load i64, ptr %slot112, align 8
  %op979 = sub i64 %v978, 1
  store i64 %op979, ptr %slot113, align 8
  %v980 = load i64, ptr %slot113, align 8
  %cmp981 = icmp eq i64 %v980, 0
  %cv982 = zext i1 %cmp981 to i32
  store i32 %cv982, ptr %slot114, align 8
  %v983 = load i32, ptr %slot114, align 8
  %cv984 = zext i32 %v983 to i64
  %cond985 = icmp ne i64 %cv984, 0
  br i1 %cond985, label %bb_rcglast117, label %bb_rcgdec117
bb_rcglast117:
  %v986 = load i64, ptr %slot105, align 8
  %op987 = sub i64 %v986, 32
  store i64 %op987, ptr %slot115, align 8
  %v988 = load i64, ptr %slot105, align 8
  %p989 = inttoptr i64 %v988 to ptr
  %rgep990 = getelementptr i8, ptr %p989, i64 -32
  %ld991 = load i64, ptr %rgep990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld991, ptr %slot116, align 8
  %v992 = load i64, ptr %slot116, align 8
  %cmp993 = icmp ne i64 %v992, 0
  %cv994 = zext i1 %cmp993 to i32
  store i32 %cv994, ptr %slot117, align 8
  %v995 = load i32, ptr %slot117, align 8
  %cv996 = zext i32 %v995 to i64
  %cond997 = icmp ne i64 %cv996, 0
  br i1 %cond997, label %bb_rcgdec117, label %bb_rcgslow117
bb_rcgslow117:
  %v998 = load i64, ptr %slot104, align 8
  %v999 = load i64, ptr %slot101, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64 %v998, i64 %v999) nomerge, !dbg !114
  br label %bb_rcgdone117
bb_rcgdec117:
  %v1000 = load i64, ptr %slot113, align 8
  %v1001 = load i64, ptr %slot105, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %rgep1003 = getelementptr i8, ptr %p1002, i64 -24
  store i64 %v1000, ptr %rgep1003, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear117
bb_rcgclear117:
  %v1004 = load i64, ptr %slot101, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  store i64 0, ptr %p1005, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone117
bb_rcgdone117:
  br label %bb_rcslotdone101
bb_rcslotowner101:
  %v1006 = load i64, ptr %slot22, align 8
  store i64 %v1006, ptr %slot118, align 8
  %v1007 = load i64, ptr %slot101, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %ld1009 = load i64, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1009, ptr %slot119, align 8
  %v1010 = load i64, ptr %slot119, align 8
  %cmp1011 = icmp ne i64 %v1010, 0
  %cv1012 = zext i1 %cmp1011 to i32
  store i32 %cv1012, ptr %slot120, align 8
  %v1013 = load i32, ptr %slot120, align 8
  %cv1014 = zext i32 %v1013 to i64
  %cond1015 = icmp ne i64 %cv1014, 0
  br i1 %cond1015, label %bb_rcgnn132, label %bb_rcgdone132
bb_rcgnn132:
  %v1016 = load i64, ptr %slot119, align 8
  %op1017 = sub i64 %v1016, 16
  store i64 %op1017, ptr %slot121, align 8
  %v1018 = load i64, ptr %slot119, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %rgep1020 = getelementptr i8, ptr %p1019, i64 -16
  %ld1021 = load i64, ptr %rgep1020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1021, ptr %slot122, align 8
  %v1022 = load i64, ptr %slot122, align 8
  %op1023 = and i64 %v1022, 4611686018427387906
  store i64 %op1023, ptr %slot123, align 8
  %v1024 = load i64, ptr %slot123, align 8
  %cmp1025 = icmp ne i64 %v1024, 0
  %cv1026 = zext i1 %cmp1025 to i32
  store i32 %cv1026, ptr %slot124, align 8
  %v1027 = load i32, ptr %slot124, align 8
  %cv1028 = zext i32 %v1027 to i64
  %cond1029 = icmp ne i64 %cv1028, 0
  br i1 %cond1029, label %bb_rcgclear132, label %bb_rcgcounted132
bb_rcgcounted132:
  %v1030 = load i64, ptr %slot119, align 8
  %op1031 = sub i64 %v1030, 32
  store i64 %op1031, ptr %slot125, align 8
  %v1032 = load i64, ptr %slot119, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %rgep1034 = getelementptr i8, ptr %p1033, i64 -32
  %ld1035 = load i64, ptr %rgep1034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1035, ptr %slot126, align 8
  %v1036 = load i64, ptr %slot126, align 8
  %op1037 = sub i64 %v1036, 1
  store i64 %op1037, ptr %slot127, align 8
  %v1038 = load i64, ptr %slot127, align 8
  %cmp1039 = icmp eq i64 %v1038, 0
  %cv1040 = zext i1 %cmp1039 to i32
  store i32 %cv1040, ptr %slot128, align 8
  %v1041 = load i32, ptr %slot128, align 8
  %cv1042 = zext i32 %v1041 to i64
  %cond1043 = icmp ne i64 %cv1042, 0
  br i1 %cond1043, label %bb_rcglast132, label %bb_rcgdec132
bb_rcglast132:
  %v1044 = load i64, ptr %slot119, align 8
  %op1045 = sub i64 %v1044, 24
  store i64 %op1045, ptr %slot129, align 8
  %v1046 = load i64, ptr %slot119, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %rgep1048 = getelementptr i8, ptr %p1047, i64 -24
  %ld1049 = load i64, ptr %rgep1048, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1049, ptr %slot130, align 8
  %v1050 = load i64, ptr %slot130, align 8
  %cmp1051 = icmp ne i64 %v1050, 0
  %cv1052 = zext i1 %cmp1051 to i32
  store i32 %cv1052, ptr %slot131, align 8
  %v1053 = load i32, ptr %slot131, align 8
  %cv1054 = zext i32 %v1053 to i64
  %cond1055 = icmp ne i64 %cv1054, 0
  br i1 %cond1055, label %bb_rcgdec132, label %bb_rcgslow132
bb_rcgslow132:
  %v1056 = load i64, ptr %slot118, align 8
  %v1057 = load i64, ptr %slot101, align 8
  call void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64 %v1056, i64 %v1057) nomerge, !dbg !114
  br label %bb_rcgdone132
bb_rcgdec132:
  %v1058 = load i64, ptr %slot127, align 8
  %v1059 = load i64, ptr %slot119, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %rgep1061 = getelementptr i8, ptr %p1060, i64 -32
  store i64 %v1058, ptr %rgep1061, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear132
bb_rcgclear132:
  %v1062 = load i64, ptr %slot101, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i64 0, ptr %p1063, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone132
bb_rcgdone132:
  br label %bb_rcslotdone101
bb_rcslotdone101:
  %v1064 = load i64, ptr %slot14, align 8
  store i64 %v1064, ptr %slot132, align 8
  %v1065 = load i64, ptr %slot22, align 8
  %v1066 = load i64, ptr %slot132, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i64 %v1065, ptr %p1067, align 8, !alias.scope !3, !noalias !4
  %v1068 = load i64, ptr %slot22, align 8
  %p1070 = inttoptr i64 %v1068 to ptr
  %gep1071 = getelementptr i8, ptr %p1070, i64 5640
  %op1069 = ptrtoint ptr %gep1071 to i64
  store i64 %op1069, ptr %slot133, align 8
  %v1072 = load i64, ptr %slot133, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i64, ptr %p1073, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1074, ptr %slot134, align 8
  %v1075 = load i64, ptr %slot134, align 8
  %op1076 = add i64 %v1075, 248
  store i64 %op1076, ptr %slot135, align 8
  %v1077 = load i64, ptr %slot135, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  %ld1079 = load i64, ptr %p1078, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1079, ptr %slot136, align 8
  %v1080 = load i64, ptr %slot132, align 8
  %p1082 = inttoptr i64 %v1080 to ptr
  %gep1083 = getelementptr i8, ptr %p1082, i64 8
  %op1081 = ptrtoint ptr %gep1083 to i64
  store i64 %op1081, ptr %slot137, align 8
  %v1084 = load i64, ptr %slot136, align 8
  %v1085 = load i64, ptr %slot137, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i64 %v1084, ptr %p1086, align 8, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot132, align 8
  %p1089 = inttoptr i64 %v1087 to ptr
  %gep1090 = getelementptr i8, ptr %p1089, i64 16
  %op1088 = ptrtoint ptr %gep1090 to i64
  store i64 %op1088, ptr %slot138, align 8
  %v1091 = load i64, ptr %slot138, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  store i64 0, ptr %p1092, align 8, !alias.scope !3, !noalias !4
  %v1093 = load i64, ptr %slot22, align 8
  %p1095 = inttoptr i64 %v1093 to ptr
  %gep1096 = getelementptr i8, ptr %p1095, i64 112
  %op1094 = ptrtoint ptr %gep1096 to i64
  store i64 %op1094, ptr %slot139, align 8
  %v1097 = load i64, ptr %slot132, align 8
  %p1099 = inttoptr i64 %v1097 to ptr
  %gep1100 = getelementptr i8, ptr %p1099, i64 24
  %op1098 = ptrtoint ptr %gep1100 to i64
  store i64 %op1098, ptr %slot140, align 8
  %v1101 = load i64, ptr %slot132, align 8
  %p1103 = inttoptr i64 %v1101 to ptr
  %gep1104 = getelementptr i8, ptr %p1103, i64 28
  %op1102 = ptrtoint ptr %gep1104 to i64
  store i64 %op1102, ptr %slot141, align 8
  %v1105 = load i64, ptr %slot139, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  %ld1107 = load i32, ptr %p1106, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld1107, ptr %slot142, align 8
  %v1108 = load i64, ptr %slot140, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i32 1, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  %v1110 = load i32, ptr %slot142, align 8
  %v1111 = load i64, ptr %slot141, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i32 %v1110, ptr %p1112, align 4, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot132, align 8
  %v1114 = load i64, ptr %slot135, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i64 %v1113, ptr %p1115, align 8, !alias.scope !9999998, !noalias !9999999
  %v1116 = load i64, ptr %slot99, align 8
  %cmp1117 = icmp ne i64 %v1116, 0
  %cv1118 = zext i1 %cmp1117 to i32
  store i32 %cv1118, ptr %slot143, align 8
  %v1119 = load i32, ptr %slot143, align 8
  %cv1120 = zext i32 %v1119 to i64
  %cond1121 = icmp ne i64 %cv1120, 0
  br i1 %cond1121, label %bb_rcspinmark184, label %bb_rcspindone184
bb_rcspinmark184:
  %v1122 = load i64, ptr %slot99, align 8
  %op1123 = sub i64 %v1122, 16
  store i64 %op1123, ptr %slot144, align 8
  %v1124 = load i64, ptr %slot99, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %rgep1126 = getelementptr i8, ptr %p1125, i64 -16
  %ld1127 = load i64, ptr %rgep1126, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1127, ptr %slot145, align 8
  %v1128 = load i64, ptr %slot145, align 8
  %op1129 = and i64 %v1128, 2
  store i64 %op1129, ptr %slot146, align 8
  %v1130 = load i64, ptr %slot146, align 8
  %cmp1131 = icmp ne i64 %v1130, 0
  %cv1132 = zext i1 %cmp1131 to i32
  store i32 %cv1132, ptr %slot147, align 8
  %v1133 = load i32, ptr %slot147, align 8
  %cv1134 = zext i32 %v1133 to i64
  %cond1135 = icmp ne i64 %cv1134, 0
  br i1 %cond1135, label %bb_rcspindone184, label %bb_rcspintype184
bb_rcspintype184:
  %v1136 = load i64, ptr %slot145, align 8
  %op1137 = and i64 %v1136, 4611686018427387907
  store i64 %op1137, ptr %slot148, align 8
  %v1138 = load i64, ptr %slot148, align 8
  %cmp1139 = icmp eq i64 %v1138, 0
  %cv1140 = zext i1 %cmp1139 to i32
  store i32 %cv1140, ptr %slot149, align 8
  %v1141 = load i32, ptr %slot149, align 8
  %cv1142 = zext i32 %v1141 to i64
  %cond1143 = icmp ne i64 %cv1142, 0
  br i1 %cond1143, label %bb_rcs192, label %bb_rcspinslow184
bb_rcs192:
  %v1144 = load i64, ptr %slot99, align 8
  %op1145 = sub i64 %v1144, 8
  store i64 %op1145, ptr %slot150, align 8
  %v1146 = load i64, ptr %slot99, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %rgep1148 = getelementptr i8, ptr %p1147, i64 -8
  %ld1149 = load i64, ptr %rgep1148, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1149, ptr %slot151, align 8
  %p1150 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld1151 = load i64, ptr %p1150, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1151, ptr %slot152, align 8
  %v1152 = load i64, ptr %slot151, align 8
  %v1153 = load i64, ptr %slot152, align 8
  %cmp1154 = icmp eq i64 %v1152, %v1153
  %cv1155 = zext i1 %cmp1154 to i32
  store i32 %cv1155, ptr %slot153, align 8
  %v1156 = load i32, ptr %slot153, align 8
  %cv1157 = zext i32 %v1156 to i64
  %cond1158 = icmp ne i64 %cv1157, 0
  br i1 %cond1158, label %bb_rcs197, label %bb_rcspinslow184
bb_rcs197:
  %v1159 = load i64, ptr %slot22, align 8
  %p1161 = inttoptr i64 %v1159 to ptr
  %gep1162 = getelementptr i8, ptr %p1161, i64 5640
  %op1160 = ptrtoint ptr %gep1162 to i64
  store i64 %op1160, ptr %slot154, align 8
  %v1163 = load i64, ptr %slot154, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1165, ptr %slot155, align 8
  %v1166 = load i64, ptr %slot155, align 8
  %op1167 = add i64 %v1166, 256
  store i64 %op1167, ptr %slot156, align 8
  %v1168 = load i64, ptr %slot156, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1170, ptr %slot157, align 8
  %v1171 = load i64, ptr %slot157, align 8
  %cmp1172 = icmp ne i64 %v1171, 0
  %cv1173 = zext i1 %cmp1172 to i32
  store i32 %cv1173, ptr %slot158, align 8
  %v1174 = load i32, ptr %slot158, align 8
  %cv1175 = zext i32 %v1174 to i64
  %cond1176 = icmp ne i64 %cv1175, 0
  br i1 %cond1176, label %bb_rcs203, label %bb_rcspinslow184
bb_rcs203:
  %v1177 = load i64, ptr %slot22, align 8
  %p1179 = inttoptr i64 %v1177 to ptr
  %gep1180 = getelementptr i8, ptr %p1179, i64 24
  %op1178 = ptrtoint ptr %gep1180 to i64
  store i64 %op1178, ptr %slot159, align 8
  %v1181 = load i64, ptr %slot159, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %ld1183 = load i64, ptr %p1182, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1183, ptr %slot160, align 8
  %v1184 = load i64, ptr %slot160, align 8
  %op1185 = add i64 %v1184, 40
  store i64 %op1185, ptr %slot161, align 8
  %v1186 = load i64, ptr %slot161, align 8
  %v1187 = load i64, ptr %slot160, align 8
  %cmp1188 = icmp uge i64 %v1186, %v1187
  %cv1189 = zext i1 %cmp1188 to i32
  store i32 %cv1189, ptr %slot162, align 8
  %v1190 = load i32, ptr %slot162, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcs208, label %bb_rcspinslow184
bb_rcs208:
  %v1193 = load i64, ptr %slot22, align 8
  %p1195 = inttoptr i64 %v1193 to ptr
  %gep1196 = getelementptr i8, ptr %p1195, i64 88
  %op1194 = ptrtoint ptr %gep1196 to i64
  store i64 %op1194, ptr %slot163, align 8
  %v1197 = load i64, ptr %slot163, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %ld1199 = load i64, ptr %p1198, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1199, ptr %slot164, align 8
  %v1200 = load i64, ptr %slot164, align 8
  %cmp1201 = icmp eq i64 %v1200, 0
  %cv1202 = zext i1 %cmp1201 to i32
  store i32 %cv1202, ptr %slot165, align 8
  %v1203 = load i64, ptr %slot161, align 8
  %v1204 = load i64, ptr %slot164, align 8
  %cmp1205 = icmp ule i64 %v1203, %v1204
  %cv1206 = zext i1 %cmp1205 to i32
  store i32 %cv1206, ptr %slot166, align 8
  %v1207 = load i32, ptr %slot165, align 8
  %v1208 = load i32, ptr %slot166, align 8
  %op1209 = or i32 %v1207, %v1208
  store i32 %op1209, ptr %slot167, align 8
  %v1210 = load i32, ptr %slot167, align 8
  %cv1211 = zext i32 %v1210 to i64
  %cond1212 = icmp ne i64 %cv1211, 0
  br i1 %cond1212, label %bb_rcs214, label %bb_rcspinslow184
bb_rcs214:
  %v1213 = load i64, ptr %slot99, align 8
  %op1214 = sub i64 %v1213, 24
  store i64 %op1214, ptr %slot168, align 8
  %v1215 = load i64, ptr %slot99, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  %rgep1217 = getelementptr i8, ptr %p1216, i64 -24
  %ld1218 = load i64, ptr %rgep1217, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1218, ptr %slot169, align 8
  %v1219 = load i64, ptr %slot169, align 8
  %cmp1220 = icmp ne i64 %v1219, 18446744073709551615
  %cv1221 = zext i1 %cmp1220 to i32
  store i32 %cv1221, ptr %slot170, align 8
  %v1222 = load i32, ptr %slot170, align 8
  %cv1223 = zext i32 %v1222 to i64
  %cond1224 = icmp ne i64 %cv1223, 0
  br i1 %cond1224, label %bb_rcs218, label %bb_rcspinslow184
bb_rcs218:
  %v1225 = load i64, ptr %slot99, align 8
  %op1226 = add i64 %v1225, 32
  store i64 %op1226, ptr %slot171, align 8
  %v1227 = load i64, ptr %slot171, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %ld1229 = load i64, ptr %p1228, align 8
  store i64 %ld1229, ptr %slot172, align 8
  %v1230 = load i64, ptr %slot172, align 8
  %cmp1231 = icmp ne i64 %v1230, 0
  %cv1232 = zext i1 %cmp1231 to i32
  store i32 %cv1232, ptr %slot173, align 8
  %v1233 = load i32, ptr %slot173, align 8
  %cv1234 = zext i32 %v1233 to i64
  %cond1235 = icmp ne i64 %cv1234, 0
  br i1 %cond1235, label %bb_rcspinbacking184, label %bb_rcspincommit184
bb_rcspinbacking184:
  %v1236 = load i64, ptr %slot172, align 8
  %op1237 = sub i64 %v1236, 16
  store i64 %op1237, ptr %slot174, align 8
  %v1238 = load i64, ptr %slot172, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %rgep1240 = getelementptr i8, ptr %p1239, i64 -16
  %ld1241 = load i64, ptr %rgep1240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1241, ptr %slot175, align 8
  %v1242 = load i64, ptr %slot175, align 8
  %op1243 = and i64 %v1242, 4611686018427387907
  store i64 %op1243, ptr %slot176, align 8
  %v1244 = load i64, ptr %slot176, align 8
  %cmp1245 = icmp eq i64 %v1244, 0
  %cv1246 = zext i1 %cmp1245 to i32
  store i32 %cv1246, ptr %slot177, align 8
  %v1247 = load i32, ptr %slot177, align 8
  %cv1248 = zext i32 %v1247 to i64
  %cond1249 = icmp ne i64 %cv1248, 0
  br i1 %cond1249, label %bb_rcs226, label %bb_rcspinslow184
bb_rcs226:
  %v1250 = load i64, ptr %slot172, align 8
  %op1251 = sub i64 %v1250, 24
  store i64 %op1251, ptr %slot178, align 8
  %v1252 = load i64, ptr %slot172, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %rgep1254 = getelementptr i8, ptr %p1253, i64 -24
  %ld1255 = load i64, ptr %rgep1254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1255, ptr %slot179, align 8
  %v1256 = load i64, ptr %slot179, align 8
  %cmp1257 = icmp ne i64 %v1256, 18446744073709551615
  %cv1258 = zext i1 %cmp1257 to i32
  store i32 %cv1258, ptr %slot180, align 8
  %v1259 = load i32, ptr %slot180, align 8
  %cv1260 = zext i32 %v1259 to i64
  %cond1261 = icmp ne i64 %cv1260, 0
  br i1 %cond1261, label %bb_rcs230, label %bb_rcspinslow184
bb_rcs230:
  br label %bb_rcspincommit184
bb_rcspincommit184:
  %v1262 = load i64, ptr %slot157, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i64, ptr %p1263, align 8
  store i64 %ld1264, ptr %slot181, align 8
  %v1265 = load i64, ptr %slot155, align 8
  %op1266 = add i64 %v1265, 256
  store i64 %op1266, ptr %slot182, align 8
  %v1267 = load i64, ptr %slot181, align 8
  %v1268 = load i64, ptr %slot182, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i64 %v1267, ptr %p1269, align 8, !alias.scope !9999998, !noalias !9999999
  %v1270 = load i64, ptr %slot155, align 8
  %op1271 = add i64 %v1270, 264
  store i64 %op1271, ptr %slot183, align 8
  %v1272 = load i64, ptr %slot183, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i64, ptr %p1273, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1274, ptr %slot184, align 8
  %v1275 = load i64, ptr %slot184, align 8
  %op1276 = add i64 %v1275, 18446744073709551615
  store i64 %op1276, ptr %slot185, align 8
  %v1277 = load i64, ptr %slot185, align 8
  %v1278 = load i64, ptr %slot183, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i64 %v1277, ptr %p1279, align 8, !alias.scope !9999998, !noalias !9999999
  %v1280 = load i64, ptr %slot22, align 8
  %p1282 = inttoptr i64 %v1280 to ptr
  %gep1283 = getelementptr i8, ptr %p1282, i64 24
  %op1281 = ptrtoint ptr %gep1283 to i64
  store i64 %op1281, ptr %slot186, align 8
  %v1284 = load i64, ptr %slot186, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i64, ptr %p1285, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1286, ptr %slot187, align 8
  %v1287 = load i64, ptr %slot187, align 8
  %op1288 = add i64 %v1287, 40
  store i64 %op1288, ptr %slot188, align 8
  %v1289 = load i64, ptr %slot188, align 8
  %v1290 = load i64, ptr %slot186, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i64 %v1289, ptr %p1291, align 8, !alias.scope !9999998, !noalias !9999999
  %v1292 = load i64, ptr %slot155, align 8
  %op1293 = add i64 %v1292, 48
  store i64 %op1293, ptr %slot189, align 8
  %v1294 = load i64, ptr %slot189, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i64, ptr %p1295, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1296, ptr %slot190, align 8
  %v1297 = load i64, ptr %slot190, align 8
  %op1298 = add i64 %v1297, 40
  store i64 %op1298, ptr %slot191, align 8
  %v1299 = load i64, ptr %slot191, align 8
  %v1300 = load i64, ptr %slot189, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i64 %v1299, ptr %p1301, align 8, !alias.scope !9999998, !noalias !9999999
  %v1302 = load i64, ptr %slot99, align 8
  %op1303 = sub i64 %v1302, 24
  store i64 %op1303, ptr %slot192, align 8
  %v1304 = load i64, ptr %slot99, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  %rgep1306 = getelementptr i8, ptr %p1305, i64 -24
  %ld1307 = load i64, ptr %rgep1306, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1307, ptr %slot193, align 8
  %v1308 = load i64, ptr %slot193, align 8
  %op1309 = add i64 %v1308, 1
  store i64 %op1309, ptr %slot194, align 8
  %v1310 = load i64, ptr %slot194, align 8
  %v1311 = load i64, ptr %slot99, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %rgep1313 = getelementptr i8, ptr %p1312, i64 -24
  store i64 %v1310, ptr %rgep1313, align 8, !alias.scope !9, !noalias !10
  %v1314 = load i64, ptr %slot172, align 8
  %cmp1315 = icmp ne i64 %v1314, 0
  %cv1316 = zext i1 %cmp1315 to i32
  store i32 %cv1316, ptr %slot195, align 8
  %v1317 = load i32, ptr %slot195, align 8
  %cv1318 = zext i32 %v1317 to i64
  %cond1319 = icmp ne i64 %cv1318, 0
  br i1 %cond1319, label %bb_rcspinhold184, label %bb_rcspinjournal184
bb_rcspinhold184:
  %v1320 = load i64, ptr %slot172, align 8
  %op1321 = sub i64 %v1320, 24
  store i64 %op1321, ptr %slot196, align 8
  %v1322 = load i64, ptr %slot172, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %rgep1324 = getelementptr i8, ptr %p1323, i64 -24
  %ld1325 = load i64, ptr %rgep1324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1325, ptr %slot197, align 8
  %v1326 = load i64, ptr %slot197, align 8
  %op1327 = add i64 %v1326, 1
  store i64 %op1327, ptr %slot198, align 8
  %v1328 = load i64, ptr %slot198, align 8
  %v1329 = load i64, ptr %slot172, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %rgep1331 = getelementptr i8, ptr %p1330, i64 -24
  store i64 %v1328, ptr %rgep1331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal184
bb_rcspinjournal184:
  %v1332 = load i64, ptr %slot145, align 8
  %op1333 = and i64 %v1332, 1152921504606846976
  store i64 %op1333, ptr %slot199, align 8
  %v1334 = load i64, ptr %slot145, align 8
  %op1335 = or i64 %v1334, 1152921504606846976
  store i64 %op1335, ptr %slot200, align 8
  %v1336 = load i64, ptr %slot99, align 8
  %op1337 = sub i64 %v1336, 16
  store i64 %op1337, ptr %slot201, align 8
  %v1338 = load i64, ptr %slot200, align 8
  %v1339 = load i64, ptr %slot99, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %rgep1341 = getelementptr i8, ptr %p1340, i64 -16
  store i64 %v1338, ptr %rgep1341, align 8, !alias.scope !9, !noalias !10
  %v1342 = load i64, ptr %slot132, align 8
  %p1344 = inttoptr i64 %v1342 to ptr
  %gep1345 = getelementptr i8, ptr %p1344, i64 16
  %op1343 = ptrtoint ptr %gep1345 to i64
  store i64 %op1343, ptr %slot202, align 8
  %v1346 = load i64, ptr %slot202, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i64, ptr %p1347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1348, ptr %slot203, align 8
  %v1349 = load i64, ptr %slot157, align 8
  %op1350 = add i64 %v1349, 0
  store i64 %op1350, ptr %slot204, align 8
  %v1351 = load i64, ptr %slot203, align 8
  %v1352 = load i64, ptr %slot204, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i64 %v1351, ptr %p1353, align 8, !alias.scope !9999998, !noalias !9999999
  %v1354 = load i64, ptr %slot157, align 8
  %op1355 = add i64 %v1354, 8
  store i64 %op1355, ptr %slot205, align 8
  %v1356 = load i64, ptr %slot99, align 8
  %v1357 = load i64, ptr %slot205, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i64 %v1356, ptr %p1358, align 8, !alias.scope !9999998, !noalias !9999999
  %v1359 = load i64, ptr %slot157, align 8
  %op1360 = add i64 %v1359, 16
  store i64 %op1360, ptr %slot206, align 8
  %v1361 = load i64, ptr %slot199, align 8
  %v1362 = load i64, ptr %slot206, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i64 %v1361, ptr %p1363, align 8, !alias.scope !9999998, !noalias !9999999
  %v1364 = load i64, ptr %slot157, align 8
  %op1365 = add i64 %v1364, 24
  store i64 %op1365, ptr %slot207, align 8
  %v1366 = load i64, ptr %slot207, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  store i32 1, ptr %p1367, align 4, !alias.scope !9999998, !noalias !9999999
  %v1368 = load i64, ptr %slot157, align 8
  %op1369 = add i64 %v1368, 32
  store i64 %op1369, ptr %slot208, align 8
  %v1370 = load i64, ptr %slot172, align 8
  %v1371 = load i64, ptr %slot208, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 %v1370, ptr %p1372, align 8, !alias.scope !9999998, !noalias !9999999
  %v1373 = load i64, ptr %slot132, align 8
  %p1375 = inttoptr i64 %v1373 to ptr
  %gep1376 = getelementptr i8, ptr %p1375, i64 16
  %op1374 = ptrtoint ptr %gep1376 to i64
  store i64 %op1374, ptr %slot209, align 8
  %v1377 = load i64, ptr %slot157, align 8
  %v1378 = load i64, ptr %slot209, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 %v1377, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone184
bb_rcspinslow184:
  %v1380 = load i64, ptr %slot1, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  %v1382 = load i64, ptr %slot132, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %v1384 = load i64, ptr %slot99, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %call1386 = call i32 @myl_qbe_rc_scope_pin(ptr %p1381, ptr %p1383, ptr %p1385) nomerge, !dbg !114
  store i32 %call1386, ptr %slot210, align 8
  %v1387 = load i32, ptr %slot210, align 8
  %cv1388 = zext i32 %v1387 to i64
  %cond1389 = icmp ne i64 %cv1388, 0
  br i1 %cond1389, label %bb_rcunique261, label %bb_failure
bb_rcunique261:
  br label %bb_rcspindone184
bb_rcspindone184:
  %v1390 = load i64, ptr %slot99, align 8
  %v1391 = load i64, ptr %slot19, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  store i64 %v1390, ptr %p1392, align 8, !alias.scope !3, !noalias !4
  %v1393 = load i64, ptr %slot20, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i64 0, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot20, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  %ld1397 = load i64, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1397, ptr %slot211, align 8
  %v1398 = load i64, ptr %slot211, align 8
  %cmp1399 = icmp sge i64 %v1398, 0
  %cv1400 = zext i1 %cmp1399 to i64
  store i64 %cv1400, ptr %slot212, align 8
  %v1401 = load i64, ptr %slot212, align 8
  %cond1402 = icmp ne i64 %v1401, 0
  br i1 %cond1402, label %bb_success264, label %bb_failed264
bb_failed264:
  %v1403 = load i64, ptr %slot1, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1404) nomerge, !dbg !116
  unreachable
bb_success264:
  %v1405 = load i64, ptr %slot22, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %p1407 = inttoptr i64 ptrtoint (ptr @myl_t_f749cfa4957a50c796581a924ff7e06dd2421e2bd9503d1990c4d6b66531549d to i64) to ptr
  %v1408 = load i64, ptr %slot211, align 8
  %call1409 = call ptr @myl_native_list_new(ptr %p1406, ptr %p1407, i64 %v1408) nomerge, !dbg !116
  %calladdr1410 = ptrtoint ptr %call1409 to i64
  store i64 %calladdr1410, ptr %slot213, align 8
  %v1411 = load i64, ptr %slot213, align 8
  %cond1412 = icmp ne i64 %v1411, 0
  br i1 %cond1412, label %bb_success266, label %bb_failed266
bb_failed266:
  %v1413 = load i64, ptr %slot1, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1414) nomerge, !dbg !116
  unreachable
bb_success266:
  %v1415 = load i64, ptr %slot213, align 8
  %v1416 = load i64, ptr %slot20, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  store i64 %v1415, ptr %p1417, align 8, !alias.scope !3, !noalias !4
  %v1418 = load i64, ptr %slot20, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i64, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1420, ptr %slot214, align 8
  %v1421 = load i64, ptr %slot214, align 8
  %v1422 = load i64, ptr %slot12, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i64 %v1421, ptr %p1423, align 8, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot12, align 8
  store i64 %v1424, ptr %slot215, align 8
  %v1425 = load i64, ptr %slot13, align 8
  store i64 %v1425, ptr %slot216, align 8
  %v1426 = load i64, ptr %slot215, align 8
  %v1427 = load i64, ptr %slot216, align 8
  %p1428 = inttoptr i64 %v1426 to ptr
  %p1429 = inttoptr i64 %v1427 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1429, ptr %p1428, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot9, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  store i32 2, ptr %p1431, align 4, !alias.scope !3, !noalias !4
  %v1432 = load i64, ptr %slot8, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  store i32 1, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  %v1434 = load i64, ptr %slot11, align 8
  store i64 %v1434, ptr %slot217, align 8
  %v1435 = load i64, ptr %slot13, align 8
  store i64 %v1435, ptr %slot218, align 8
  %v1436 = load i64, ptr %slot218, align 8
  %v1437 = load i64, ptr %slot217, align 8
  %p1438 = inttoptr i64 %v1436 to ptr
  %p1439 = inttoptr i64 %v1437 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1439, ptr %p1438, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot7, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  store i32 2, ptr %p1441, align 4, !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot9, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i32, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1444, ptr %slot219, align 8
  %v1445 = load i32, ptr %slot219, align 8
  %v1446 = load i64, ptr %slot7, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i32 %v1445, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot8, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i32 0, ptr %p1449, align 4, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot6, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i32 1, ptr %p1451, align 4, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot217, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %ld1454 = load i64, ptr %p1453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1454, ptr %slot220, align 8
  %v1455 = load i64, ptr %slot220, align 8
  %v1456 = load i64, ptr %slot20, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  store i64 %v1455, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  %v1458 = load i64, ptr %slot20, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %ld1460 = load i64, ptr %p1459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1460, ptr %slot221, align 8
  %v1461 = load i64, ptr %slot221, align 8
  %v1462 = load i64, ptr %slot12, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i64 %v1461, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot12, align 8
  store i64 %v1464, ptr %slot222, align 8
  %v1465 = load i64, ptr %slot6, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  %ld1467 = load i32, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1467, ptr %slot223, align 8
  %v1468 = load i64, ptr %slot7, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %ld1470 = load i32, ptr %p1469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1470, ptr %slot224, align 8
  %v1471 = load i32, ptr %slot224, align 8
  %op1472 = and i32 %v1471, 24
  store i32 %op1472, ptr %slot224, align 8
  %v1473 = load i32, ptr %slot224, align 8
  %cmp1474 = icmp eq i32 %v1473, 0
  %cv1475 = zext i1 %cmp1474 to i32
  store i32 %cv1475, ptr %slot225, align 8
  %v1476 = load i32, ptr %slot223, align 8
  %v1477 = load i32, ptr %slot225, align 8
  %op1478 = and i32 %v1476, %v1477
  store i32 %op1478, ptr %slot226, align 8
  %v1479 = load i32, ptr %slot226, align 8
  %cv1480 = zext i32 %v1479 to i64
  %cond1481 = icmp ne i64 %cv1480, 0
  br i1 %cond1481, label %bb_rcprivateown289, label %bb_rcprivateloan289
bb_rcprivateown289:
  %v1482 = load i64, ptr %slot13, align 8
  store i64 %v1482, ptr %slot227, align 8
  %v1483 = load i64, ptr %slot23, align 8
  store i64 %v1483, ptr %slot228, align 8
  %v1484 = load i64, ptr %slot222, align 8
  %v1485 = load i64, ptr %slot227, align 8
  %op1486 = sub i64 %v1484, %v1485
  store i64 %op1486, ptr %slot229, align 8
  %v1487 = load i64, ptr %slot227, align 8
  %v1488 = load i64, ptr %slot222, align 8
  %op1489 = sub i64 %v1487, %v1488
  store i64 %op1489, ptr %slot230, align 8
  %v1490 = load i64, ptr %slot229, align 8
  %cmp1491 = icmp ult i64 %v1490, 8
  %cv1492 = zext i1 %cmp1491 to i32
  store i32 %cv1492, ptr %slot231, align 8
  %v1493 = load i64, ptr %slot230, align 8
  %cmp1494 = icmp ult i64 %v1493, 8
  %cv1495 = zext i1 %cmp1494 to i32
  store i32 %cv1495, ptr %slot232, align 8
  %v1496 = load i32, ptr %slot231, align 8
  %v1497 = load i32, ptr %slot232, align 8
  %op1498 = or i32 %v1496, %v1497
  store i32 %op1498, ptr %slot233, align 8
  %v1499 = load i32, ptr %slot233, align 8
  %cv1500 = zext i32 %v1499 to i64
  %cond1501 = icmp ne i64 %cv1500, 0
  br i1 %cond1501, label %bb_rcmoveslow292, label %bb_rcmovecheck292
bb_rcmovecheck292:
  %v1502 = load i64, ptr %slot222, align 8
  %p1504 = inttoptr i64 %v1502 to ptr
  %gep1505 = getelementptr i8, ptr %p1504, i64 0
  %op1503 = ptrtoint ptr %gep1505 to i64
  store i64 %op1503, ptr %slot234, align 8
  %v1506 = load i64, ptr %slot234, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  %ld1508 = load i64, ptr %p1507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1508, ptr %slot235, align 8
  %v1509 = load i64, ptr %slot235, align 8
  %cmp1510 = icmp ne i64 %v1509, 0
  %cv1511 = zext i1 %cmp1510 to i32
  store i32 %cv1511, ptr %slot236, align 8
  %v1512 = load i32, ptr %slot236, align 8
  %cv1513 = zext i32 %v1512 to i64
  %cond1514 = icmp ne i64 %cv1513, 0
  br i1 %cond1514, label %bb_rcmoveheader300, label %bb_rcmovenext300
bb_rcmoveheader300:
  %v1515 = load i64, ptr %slot235, align 8
  %op1516 = sub i64 %v1515, 16
  store i64 %op1516, ptr %slot237, align 8
  %v1517 = load i64, ptr %slot235, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  %rgep1519 = getelementptr i8, ptr %p1518, i64 -16
  %ld1520 = load i64, ptr %rgep1519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1520, ptr %slot238, align 8
  %v1521 = load i64, ptr %slot238, align 8
  %op1522 = and i64 %v1521, 5764607523034234881
  store i64 %op1522, ptr %slot239, align 8
  %v1523 = load i64, ptr %slot239, align 8
  %cmp1524 = icmp ne i64 %v1523, 0
  %cv1525 = zext i1 %cmp1524 to i32
  store i32 %cv1525, ptr %slot240, align 8
  %v1526 = load i32, ptr %slot240, align 8
  %cv1527 = zext i32 %v1526 to i64
  %cond1528 = icmp ne i64 %cv1527, 0
  br i1 %cond1528, label %bb_rcmoveslow292, label %bb_rcmovenext300
bb_rcmovenext300:
  %v1529 = load i64, ptr %slot222, align 8
  %v1530 = load i64, ptr %slot227, align 8
  %p1531 = inttoptr i64 %v1529 to ptr
  %p1532 = inttoptr i64 %v1530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1532, ptr %p1531, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1533 = load i64, ptr %slot222, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i64 0, ptr %p1534, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved292
bb_rcmoveslow292:
  %v1535 = load i64, ptr %slot22, align 8
  %v1536 = load i64, ptr %slot227, align 8
  %v1537 = load i64, ptr %slot222, align 8
  %v1538 = load i64, ptr %slot228, align 8
  %cv1539 = trunc i64 %v1538 to i32
  %call1540 = call i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_take(i64 %v1535, i64 %v1536, i64 %v1537, i32 %cv1539) nomerge, !dbg !118
  store i32 %call1540, ptr %slot241, align 8
  %v1541 = load i32, ptr %slot241, align 8
  %cv1542 = zext i32 %v1541 to i64
  %cond1543 = icmp ne i64 %cv1542, 0
  br i1 %cond1543, label %bb_rcsuccess307, label %bb_rcfailure307
bb_rcfailure307:
  %v1544 = load i64, ptr %slot22, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %call1546 = call i32 @myl_rc_take_failure(ptr %p1545) nomerge, !dbg !118
  store i32 %call1546, ptr %slot242, align 8
  %v1547 = load i64, ptr %slot1, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  %v1549 = load i32, ptr %slot242, align 8
  %call1550 = call i32 @myl_qbe_rc_status(ptr %p1548, i32 %v1549) nomerge, !dbg !118
  store i32 %call1550, ptr %slot243, align 8
  br label %bb_failure
bb_rcsuccess307:
  br label %bb_rcmoved292
bb_rcmoved292:
  %v1551 = load i64, ptr %slot6, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  store i32 0, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  %v1553 = load i64, ptr %slot9, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  store i32 2, ptr %p1554, align 4, !alias.scope !3, !noalias !4
  %v1555 = load i64, ptr %slot8, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i32 1, ptr %p1556, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared289
bb_rcprivateloan289:
  %v1557 = load i64, ptr %slot6, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %ld1559 = load i32, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1559, ptr %slot244, align 8
  %v1560 = load i64, ptr %slot7, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %ld1562 = load i32, ptr %p1561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1562, ptr %slot245, align 8
  %v1563 = load i32, ptr %slot245, align 8
  %cmp1564 = icmp eq i32 %v1563, 16
  %cv1565 = zext i1 %cmp1564 to i32
  store i32 %cv1565, ptr %slot246, align 8
  %v1566 = load i32, ptr %slot246, align 8
  %v1567 = load i32, ptr %slot244, align 8
  %op1568 = and i32 %v1566, %v1567
  store i32 %op1568, ptr %slot246, align 8
  %v1569 = load i32, ptr %slot246, align 8
  %cv1570 = zext i32 %v1569 to i64
  %cond1571 = icmp ne i64 %cv1570, 0
  br i1 %cond1571, label %bb_rcprivatemove289, label %bb_rcprivatenew289
bb_rcprivatemove289:
  %v1572 = load i64, ptr %slot13, align 8
  store i64 %v1572, ptr %slot247, align 8
  %v1573 = load i64, ptr %slot222, align 8
  %v1574 = load i64, ptr %slot247, align 8
  %p1575 = inttoptr i64 %v1573 to ptr
  %p1576 = inttoptr i64 %v1574 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1576, ptr %p1575, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1577 = load i64, ptr %slot222, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i64 0, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot9, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i32 2, ptr %p1580, align 4, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot9, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 16, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot8, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 1, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot6, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i32 0, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared289
bb_rcprivatenew289:
  %v1587 = load i64, ptr %slot13, align 8
  store i64 %v1587, ptr %slot248, align 8
  %v1588 = load i64, ptr %slot222, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  %ld1590 = load i64, ptr %p1589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1590, ptr %slot249, align 8
  %v1591 = load i64, ptr %slot249, align 8
  %cmp1592 = icmp ne i64 %v1591, 0
  %cv1593 = zext i1 %cmp1592 to i32
  store i32 %cv1593, ptr %slot250, align 8
  %v1594 = load i32, ptr %slot250, align 8
  %cv1595 = zext i32 %v1594 to i64
  %cond1596 = icmp ne i64 %cv1595, 0
  br i1 %cond1596, label %bb_rcgnn325, label %bb_rcgstore325
bb_rcgnn325:
  %v1597 = load i64, ptr %slot249, align 8
  %op1598 = sub i64 %v1597, 16
  store i64 %op1598, ptr %slot251, align 8
  %v1599 = load i64, ptr %slot249, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  %rgep1601 = getelementptr i8, ptr %p1600, i64 -16
  %ld1602 = load i64, ptr %rgep1601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1602, ptr %slot252, align 8
  %v1603 = load i64, ptr %slot252, align 8
  %op1604 = and i64 %v1603, 4611686018427387906
  store i64 %op1604, ptr %slot253, align 8
  %v1605 = load i64, ptr %slot253, align 8
  %cmp1606 = icmp ne i64 %v1605, 0
  %cv1607 = zext i1 %cmp1606 to i32
  store i32 %cv1607, ptr %slot254, align 8
  %v1608 = load i32, ptr %slot254, align 8
  %cv1609 = zext i32 %v1608 to i64
  %cond1610 = icmp ne i64 %cv1609, 0
  br i1 %cond1610, label %bb_rcgstore325, label %bb_rcginc325
bb_rcginc325:
  %v1611 = load i64, ptr %slot249, align 8
  %op1612 = sub i64 %v1611, 24
  store i64 %op1612, ptr %slot255, align 8
  %v1613 = load i64, ptr %slot249, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  %rgep1615 = getelementptr i8, ptr %p1614, i64 -24
  %ld1616 = load i64, ptr %rgep1615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1616, ptr %slot256, align 8
  %v1617 = load i64, ptr %slot256, align 8
  %op1618 = add i64 %v1617, 1
  store i64 %op1618, ptr %slot257, align 8
  %v1619 = load i64, ptr %slot257, align 8
  %cmp1620 = icmp eq i64 %v1619, 0
  %cv1621 = zext i1 %cmp1620 to i32
  store i32 %cv1621, ptr %slot258, align 8
  %v1622 = load i32, ptr %slot258, align 8
  %cv1623 = zext i32 %v1622 to i64
  %cond1624 = icmp ne i64 %cv1623, 0
  br i1 %cond1624, label %bb_rcglimit325, label %bb_rcgcapacity325
bb_rcglimit325:
  %v1625 = load i64, ptr %slot1, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %call1627 = call i32 @myl_qbe_rc_status(ptr %p1626, i32 2) nomerge, !dbg !118
  store i32 %call1627, ptr %slot259, align 8
  br label %bb_failure
bb_rcgcapacity325:
  %v1628 = load i64, ptr %slot257, align 8
  %v1629 = load i64, ptr %slot249, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %rgep1631 = getelementptr i8, ptr %p1630, i64 -24
  store i64 %v1628, ptr %rgep1631, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore325
bb_rcgstore325:
  %v1632 = load i64, ptr %slot249, align 8
  %v1633 = load i64, ptr %slot248, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 %v1632, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot9, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  store i32 2, ptr %p1636, align 4, !alias.scope !3, !noalias !4
  %v1637 = load i64, ptr %slot9, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  store i32 16, ptr %p1638, align 4, !alias.scope !3, !noalias !4
  %v1639 = load i64, ptr %slot8, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  store i32 1, ptr %p1640, align 4, !alias.scope !3, !noalias !4
  %v1641 = load i64, ptr %slot6, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i32, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1643, ptr %slot260, align 8
  %v1644 = load i32, ptr %slot260, align 8
  %cv1645 = zext i32 %v1644 to i64
  %cond1646 = icmp ne i64 %cv1645, 0
  br i1 %cond1646, label %bb_rcslotdrop341, label %bb_rcslotdone341
bb_rcslotdrop341:
  %v1647 = load i64, ptr %slot6, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  store i32 0, ptr %p1648, align 4, !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot11, align 8
  store i64 %v1649, ptr %slot261, align 8
  %v1650 = load i64, ptr %slot7, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  %ld1652 = load i32, ptr %p1651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1652, ptr %slot262, align 8
  %v1653 = load i32, ptr %slot262, align 8
  %op1654 = and i32 %v1653, 28
  store i32 %op1654, ptr %slot263, align 8
  %v1655 = load i32, ptr %slot263, align 8
  %cv1656 = zext i32 %v1655 to i64
  %cond1657 = icmp ne i64 %cv1656, 0
  br i1 %cond1657, label %bb_rcslotrole341, label %bb_rcslotowner341
bb_rcslotrole341:
  %v1658 = load i64, ptr %slot22, align 8
  store i64 %v1658, ptr %slot264, align 8
  %v1659 = load i64, ptr %slot261, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i64, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1661, ptr %slot265, align 8
  %v1662 = load i64, ptr %slot265, align 8
  %cmp1663 = icmp ne i64 %v1662, 0
  %cv1664 = zext i1 %cmp1663 to i32
  store i32 %cv1664, ptr %slot266, align 8
  %v1665 = load i32, ptr %slot266, align 8
  %cv1666 = zext i32 %v1665 to i64
  %cond1667 = icmp ne i64 %cv1666, 0
  br i1 %cond1667, label %bb_rcgnn357, label %bb_rcgdone357
bb_rcgnn357:
  %v1668 = load i64, ptr %slot265, align 8
  %op1669 = sub i64 %v1668, 16
  store i64 %op1669, ptr %slot267, align 8
  %v1670 = load i64, ptr %slot265, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  %rgep1672 = getelementptr i8, ptr %p1671, i64 -16
  %ld1673 = load i64, ptr %rgep1672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1673, ptr %slot268, align 8
  %v1674 = load i64, ptr %slot268, align 8
  %op1675 = and i64 %v1674, 4611686018427387906
  store i64 %op1675, ptr %slot269, align 8
  %v1676 = load i64, ptr %slot269, align 8
  %cmp1677 = icmp ne i64 %v1676, 0
  %cv1678 = zext i1 %cmp1677 to i32
  store i32 %cv1678, ptr %slot270, align 8
  %v1679 = load i32, ptr %slot270, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcgclear357, label %bb_rcgcounted357
bb_rcgcounted357:
  %v1682 = load i64, ptr %slot265, align 8
  %op1683 = sub i64 %v1682, 24
  store i64 %op1683, ptr %slot271, align 8
  %v1684 = load i64, ptr %slot265, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %rgep1686 = getelementptr i8, ptr %p1685, i64 -24
  %ld1687 = load i64, ptr %rgep1686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1687, ptr %slot272, align 8
  %v1688 = load i64, ptr %slot272, align 8
  %op1689 = sub i64 %v1688, 1
  store i64 %op1689, ptr %slot273, align 8
  %v1690 = load i64, ptr %slot273, align 8
  %cmp1691 = icmp eq i64 %v1690, 0
  %cv1692 = zext i1 %cmp1691 to i32
  store i32 %cv1692, ptr %slot274, align 8
  %v1693 = load i32, ptr %slot274, align 8
  %cv1694 = zext i32 %v1693 to i64
  %cond1695 = icmp ne i64 %cv1694, 0
  br i1 %cond1695, label %bb_rcglast357, label %bb_rcgdec357
bb_rcglast357:
  %v1696 = load i64, ptr %slot265, align 8
  %op1697 = sub i64 %v1696, 32
  store i64 %op1697, ptr %slot275, align 8
  %v1698 = load i64, ptr %slot265, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %rgep1700 = getelementptr i8, ptr %p1699, i64 -32
  %ld1701 = load i64, ptr %rgep1700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1701, ptr %slot276, align 8
  %v1702 = load i64, ptr %slot276, align 8
  %cmp1703 = icmp ne i64 %v1702, 0
  %cv1704 = zext i1 %cmp1703 to i32
  store i32 %cv1704, ptr %slot277, align 8
  %v1705 = load i32, ptr %slot277, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rcgdec357, label %bb_rcgslow357
bb_rcgslow357:
  %v1708 = load i64, ptr %slot264, align 8
  %v1709 = load i64, ptr %slot261, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v1708, i64 %v1709) nomerge, !dbg !118
  br label %bb_rcgdone357
bb_rcgdec357:
  %v1710 = load i64, ptr %slot273, align 8
  %v1711 = load i64, ptr %slot265, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %rgep1713 = getelementptr i8, ptr %p1712, i64 -24
  store i64 %v1710, ptr %rgep1713, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear357
bb_rcgclear357:
  %v1714 = load i64, ptr %slot261, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  store i64 0, ptr %p1715, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone357
bb_rcgdone357:
  br label %bb_rcslotdone341
bb_rcslotowner341:
  %v1716 = load i64, ptr %slot22, align 8
  store i64 %v1716, ptr %slot278, align 8
  %v1717 = load i64, ptr %slot261, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i64, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1719, ptr %slot279, align 8
  %v1720 = load i64, ptr %slot279, align 8
  %cmp1721 = icmp ne i64 %v1720, 0
  %cv1722 = zext i1 %cmp1721 to i32
  store i32 %cv1722, ptr %slot280, align 8
  %v1723 = load i32, ptr %slot280, align 8
  %cv1724 = zext i32 %v1723 to i64
  %cond1725 = icmp ne i64 %cv1724, 0
  br i1 %cond1725, label %bb_rcgnn372, label %bb_rcgdone372
bb_rcgnn372:
  %v1726 = load i64, ptr %slot279, align 8
  %op1727 = sub i64 %v1726, 16
  store i64 %op1727, ptr %slot281, align 8
  %v1728 = load i64, ptr %slot279, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  %rgep1730 = getelementptr i8, ptr %p1729, i64 -16
  %ld1731 = load i64, ptr %rgep1730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1731, ptr %slot282, align 8
  %v1732 = load i64, ptr %slot282, align 8
  %op1733 = and i64 %v1732, 4611686018427387906
  store i64 %op1733, ptr %slot283, align 8
  %v1734 = load i64, ptr %slot283, align 8
  %cmp1735 = icmp ne i64 %v1734, 0
  %cv1736 = zext i1 %cmp1735 to i32
  store i32 %cv1736, ptr %slot284, align 8
  %v1737 = load i32, ptr %slot284, align 8
  %cv1738 = zext i32 %v1737 to i64
  %cond1739 = icmp ne i64 %cv1738, 0
  br i1 %cond1739, label %bb_rcgclear372, label %bb_rcgcounted372
bb_rcgcounted372:
  %v1740 = load i64, ptr %slot279, align 8
  %op1741 = sub i64 %v1740, 32
  store i64 %op1741, ptr %slot285, align 8
  %v1742 = load i64, ptr %slot279, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %rgep1744 = getelementptr i8, ptr %p1743, i64 -32
  %ld1745 = load i64, ptr %rgep1744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1745, ptr %slot286, align 8
  %v1746 = load i64, ptr %slot286, align 8
  %op1747 = sub i64 %v1746, 1
  store i64 %op1747, ptr %slot287, align 8
  %v1748 = load i64, ptr %slot287, align 8
  %cmp1749 = icmp eq i64 %v1748, 0
  %cv1750 = zext i1 %cmp1749 to i32
  store i32 %cv1750, ptr %slot288, align 8
  %v1751 = load i32, ptr %slot288, align 8
  %cv1752 = zext i32 %v1751 to i64
  %cond1753 = icmp ne i64 %cv1752, 0
  br i1 %cond1753, label %bb_rcglast372, label %bb_rcgdec372
bb_rcglast372:
  %v1754 = load i64, ptr %slot279, align 8
  %op1755 = sub i64 %v1754, 24
  store i64 %op1755, ptr %slot289, align 8
  %v1756 = load i64, ptr %slot279, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %rgep1758 = getelementptr i8, ptr %p1757, i64 -24
  %ld1759 = load i64, ptr %rgep1758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1759, ptr %slot290, align 8
  %v1760 = load i64, ptr %slot290, align 8
  %cmp1761 = icmp ne i64 %v1760, 0
  %cv1762 = zext i1 %cmp1761 to i32
  store i32 %cv1762, ptr %slot291, align 8
  %v1763 = load i32, ptr %slot291, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcgdec372, label %bb_rcgslow372
bb_rcgslow372:
  %v1766 = load i64, ptr %slot278, align 8
  %v1767 = load i64, ptr %slot261, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v1766, i64 %v1767) nomerge, !dbg !118
  br label %bb_rcgdone372
bb_rcgdec372:
  %v1768 = load i64, ptr %slot287, align 8
  %v1769 = load i64, ptr %slot279, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %rgep1771 = getelementptr i8, ptr %p1770, i64 -32
  store i64 %v1768, ptr %rgep1771, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear372
bb_rcgclear372:
  %v1772 = load i64, ptr %slot261, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i64 0, ptr %p1773, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone372
bb_rcgdone372:
  br label %bb_rcslotdone341
bb_rcslotdone341:
  br label %bb_rcprivateprepared289
bb_rcprivateprepared289:
  %v1774 = load i64, ptr %slot4, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i32, ptr %p1775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1776, ptr %slot292, align 8
  %v1777 = load i32, ptr %slot292, align 8
  %cv1778 = zext i32 %v1777 to i64
  %cond1779 = icmp ne i64 %cv1778, 0
  br i1 %cond1779, label %bb_rcslotdrop379, label %bb_rcslotdone379
bb_rcslotdrop379:
  %v1780 = load i64, ptr %slot4, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  store i32 0, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  %v1782 = load i64, ptr %slot18, align 8
  store i64 %v1782, ptr %slot293, align 8
  %v1783 = load i64, ptr %slot5, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %ld1785 = load i32, ptr %p1784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1785, ptr %slot294, align 8
  %v1786 = load i32, ptr %slot294, align 8
  %op1787 = and i32 %v1786, 28
  store i32 %op1787, ptr %slot295, align 8
  %v1788 = load i32, ptr %slot295, align 8
  %cv1789 = zext i32 %v1788 to i64
  %cond1790 = icmp ne i64 %cv1789, 0
  br i1 %cond1790, label %bb_rcslotrole379, label %bb_rcslotowner379
bb_rcslotrole379:
  %v1791 = load i64, ptr %slot22, align 8
  store i64 %v1791, ptr %slot296, align 8
  %v1792 = load i64, ptr %slot293, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %ld1794 = load i64, ptr %p1793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1794, ptr %slot297, align 8
  %v1795 = load i64, ptr %slot297, align 8
  %cmp1796 = icmp ne i64 %v1795, 0
  %cv1797 = zext i1 %cmp1796 to i32
  store i32 %cv1797, ptr %slot298, align 8
  %v1798 = load i32, ptr %slot298, align 8
  %cv1799 = zext i32 %v1798 to i64
  %cond1800 = icmp ne i64 %cv1799, 0
  br i1 %cond1800, label %bb_rcgnn395, label %bb_rcgdone395
bb_rcgnn395:
  %v1801 = load i64, ptr %slot297, align 8
  %op1802 = sub i64 %v1801, 16
  store i64 %op1802, ptr %slot299, align 8
  %v1803 = load i64, ptr %slot297, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %rgep1805 = getelementptr i8, ptr %p1804, i64 -16
  %ld1806 = load i64, ptr %rgep1805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1806, ptr %slot300, align 8
  %v1807 = load i64, ptr %slot300, align 8
  %op1808 = and i64 %v1807, 4611686018427387906
  store i64 %op1808, ptr %slot301, align 8
  %v1809 = load i64, ptr %slot301, align 8
  %cmp1810 = icmp ne i64 %v1809, 0
  %cv1811 = zext i1 %cmp1810 to i32
  store i32 %cv1811, ptr %slot302, align 8
  %v1812 = load i32, ptr %slot302, align 8
  %cv1813 = zext i32 %v1812 to i64
  %cond1814 = icmp ne i64 %cv1813, 0
  br i1 %cond1814, label %bb_rcgclear395, label %bb_rcgcounted395
bb_rcgcounted395:
  %v1815 = load i64, ptr %slot297, align 8
  %op1816 = sub i64 %v1815, 24
  store i64 %op1816, ptr %slot303, align 8
  %v1817 = load i64, ptr %slot297, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  %rgep1819 = getelementptr i8, ptr %p1818, i64 -24
  %ld1820 = load i64, ptr %rgep1819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1820, ptr %slot304, align 8
  %v1821 = load i64, ptr %slot304, align 8
  %op1822 = sub i64 %v1821, 1
  store i64 %op1822, ptr %slot305, align 8
  %v1823 = load i64, ptr %slot305, align 8
  %cmp1824 = icmp eq i64 %v1823, 0
  %cv1825 = zext i1 %cmp1824 to i32
  store i32 %cv1825, ptr %slot306, align 8
  %v1826 = load i32, ptr %slot306, align 8
  %cv1827 = zext i32 %v1826 to i64
  %cond1828 = icmp ne i64 %cv1827, 0
  br i1 %cond1828, label %bb_rcglast395, label %bb_rcgdec395
bb_rcglast395:
  %v1829 = load i64, ptr %slot297, align 8
  %op1830 = sub i64 %v1829, 32
  store i64 %op1830, ptr %slot307, align 8
  %v1831 = load i64, ptr %slot297, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  %rgep1833 = getelementptr i8, ptr %p1832, i64 -32
  %ld1834 = load i64, ptr %rgep1833, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1834, ptr %slot308, align 8
  %v1835 = load i64, ptr %slot308, align 8
  %cmp1836 = icmp ne i64 %v1835, 0
  %cv1837 = zext i1 %cmp1836 to i32
  store i32 %cv1837, ptr %slot309, align 8
  %v1838 = load i32, ptr %slot309, align 8
  %cv1839 = zext i32 %v1838 to i64
  %cond1840 = icmp ne i64 %cv1839, 0
  br i1 %cond1840, label %bb_rcgdec395, label %bb_rcgslow395
bb_rcgslow395:
  %v1841 = load i64, ptr %slot296, align 8
  %v1842 = load i64, ptr %slot293, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v1841, i64 %v1842) nomerge, !dbg !118
  br label %bb_rcgdone395
bb_rcgdec395:
  %v1843 = load i64, ptr %slot305, align 8
  %v1844 = load i64, ptr %slot297, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %rgep1846 = getelementptr i8, ptr %p1845, i64 -24
  store i64 %v1843, ptr %rgep1846, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear395
bb_rcgclear395:
  %v1847 = load i64, ptr %slot293, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i64 0, ptr %p1848, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone395
bb_rcgdone395:
  br label %bb_rcslotdone379
bb_rcslotowner379:
  %v1849 = load i64, ptr %slot22, align 8
  store i64 %v1849, ptr %slot310, align 8
  %v1850 = load i64, ptr %slot293, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %ld1852 = load i64, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1852, ptr %slot311, align 8
  %v1853 = load i64, ptr %slot311, align 8
  %cmp1854 = icmp ne i64 %v1853, 0
  %cv1855 = zext i1 %cmp1854 to i32
  store i32 %cv1855, ptr %slot312, align 8
  %v1856 = load i32, ptr %slot312, align 8
  %cv1857 = zext i32 %v1856 to i64
  %cond1858 = icmp ne i64 %cv1857, 0
  br i1 %cond1858, label %bb_rcgnn410, label %bb_rcgdone410
bb_rcgnn410:
  %v1859 = load i64, ptr %slot311, align 8
  %op1860 = sub i64 %v1859, 16
  store i64 %op1860, ptr %slot313, align 8
  %v1861 = load i64, ptr %slot311, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %rgep1863 = getelementptr i8, ptr %p1862, i64 -16
  %ld1864 = load i64, ptr %rgep1863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1864, ptr %slot314, align 8
  %v1865 = load i64, ptr %slot314, align 8
  %op1866 = and i64 %v1865, 4611686018427387906
  store i64 %op1866, ptr %slot315, align 8
  %v1867 = load i64, ptr %slot315, align 8
  %cmp1868 = icmp ne i64 %v1867, 0
  %cv1869 = zext i1 %cmp1868 to i32
  store i32 %cv1869, ptr %slot316, align 8
  %v1870 = load i32, ptr %slot316, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcgclear410, label %bb_rcgcounted410
bb_rcgcounted410:
  %v1873 = load i64, ptr %slot311, align 8
  %op1874 = sub i64 %v1873, 32
  store i64 %op1874, ptr %slot317, align 8
  %v1875 = load i64, ptr %slot311, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %rgep1877 = getelementptr i8, ptr %p1876, i64 -32
  %ld1878 = load i64, ptr %rgep1877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1878, ptr %slot318, align 8
  %v1879 = load i64, ptr %slot318, align 8
  %op1880 = sub i64 %v1879, 1
  store i64 %op1880, ptr %slot319, align 8
  %v1881 = load i64, ptr %slot319, align 8
  %cmp1882 = icmp eq i64 %v1881, 0
  %cv1883 = zext i1 %cmp1882 to i32
  store i32 %cv1883, ptr %slot320, align 8
  %v1884 = load i32, ptr %slot320, align 8
  %cv1885 = zext i32 %v1884 to i64
  %cond1886 = icmp ne i64 %cv1885, 0
  br i1 %cond1886, label %bb_rcglast410, label %bb_rcgdec410
bb_rcglast410:
  %v1887 = load i64, ptr %slot311, align 8
  %op1888 = sub i64 %v1887, 24
  store i64 %op1888, ptr %slot321, align 8
  %v1889 = load i64, ptr %slot311, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  %rgep1891 = getelementptr i8, ptr %p1890, i64 -24
  %ld1892 = load i64, ptr %rgep1891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1892, ptr %slot322, align 8
  %v1893 = load i64, ptr %slot322, align 8
  %cmp1894 = icmp ne i64 %v1893, 0
  %cv1895 = zext i1 %cmp1894 to i32
  store i32 %cv1895, ptr %slot323, align 8
  %v1896 = load i32, ptr %slot323, align 8
  %cv1897 = zext i32 %v1896 to i64
  %cond1898 = icmp ne i64 %cv1897, 0
  br i1 %cond1898, label %bb_rcgdec410, label %bb_rcgslow410
bb_rcgslow410:
  %v1899 = load i64, ptr %slot310, align 8
  %v1900 = load i64, ptr %slot293, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v1899, i64 %v1900) nomerge, !dbg !118
  br label %bb_rcgdone410
bb_rcgdec410:
  %v1901 = load i64, ptr %slot319, align 8
  %v1902 = load i64, ptr %slot311, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %rgep1904 = getelementptr i8, ptr %p1903, i64 -32
  store i64 %v1901, ptr %rgep1904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear410
bb_rcgclear410:
  %v1905 = load i64, ptr %slot293, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i64 0, ptr %p1906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone410
bb_rcgdone410:
  br label %bb_rcslotdone379
bb_rcslotdone379:
  %v1907 = load i64, ptr %slot18, align 8
  store i64 %v1907, ptr %slot324, align 8
  %v1908 = load i64, ptr %slot13, align 8
  store i64 %v1908, ptr %slot325, align 8
  %v1909 = load i64, ptr %slot325, align 8
  %v1910 = load i64, ptr %slot324, align 8
  %p1911 = inttoptr i64 %v1909 to ptr
  %p1912 = inttoptr i64 %v1910 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1912, ptr %p1911, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1913 = load i64, ptr %slot8, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i32 0, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot5, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  store i32 2, ptr %p1916, align 4, !alias.scope !3, !noalias !4
  %v1917 = load i64, ptr %slot9, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i32, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1919, ptr %slot326, align 8
  %v1920 = load i32, ptr %slot326, align 8
  %v1921 = load i64, ptr %slot5, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i32 %v1920, ptr %p1922, align 4, !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot4, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i32 1, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot18, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i64, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1927, ptr %slot327, align 8
  %v1928 = load i64, ptr %slot327, align 8
  %v1929 = load i64, ptr %slot20, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i64 %v1928, ptr %p1930, align 8, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot21, align 8
  store i64 %v1931, ptr %slot328, align 8
  %v1932 = load i64, ptr %slot328, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i64 0, ptr %p1933, align 8, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot10, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i32 1, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot23, align 8
  store i64 %v1936, ptr %slot329, align 8
  %v1937 = load i64, ptr %slot20, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i64, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1939, ptr %slot330, align 8
  %v1940 = load i64, ptr %slot330, align 8
  %v1941 = load i64, ptr %slot12, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 %v1940, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  %v1943 = load i64, ptr %slot12, align 8
  store i64 %v1943, ptr %slot331, align 8
  %v1944 = load i64, ptr %slot328, align 8
  %p1946 = inttoptr i64 %v1944 to ptr
  %gep1947 = getelementptr i8, ptr %p1946, i64 0
  %op1945 = ptrtoint ptr %gep1947 to i64
  store i64 %op1945, ptr %slot332, align 8
  %v1948 = load i64, ptr %slot20, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  %ld1950 = load i64, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1950, ptr %slot333, align 8
  %v1951 = load i64, ptr %slot333, align 8
  %v1952 = load i64, ptr %slot12, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  store i64 %v1951, ptr %p1953, align 8, !alias.scope !3, !noalias !4
  %v1954 = load i64, ptr %slot12, align 8
  store i64 %v1954, ptr %slot334, align 8
  %v1955 = load i64, ptr %slot6, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i32, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1957, ptr %slot335, align 8
  %v1958 = load i64, ptr %slot7, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %ld1960 = load i32, ptr %p1959, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1960, ptr %slot336, align 8
  %v1961 = load i32, ptr %slot336, align 8
  %op1962 = and i32 %v1961, 24
  store i32 %op1962, ptr %slot336, align 8
  %v1963 = load i32, ptr %slot336, align 8
  %cmp1964 = icmp eq i32 %v1963, 0
  %cv1965 = zext i1 %cmp1964 to i32
  store i32 %cv1965, ptr %slot337, align 8
  %v1966 = load i32, ptr %slot335, align 8
  %v1967 = load i32, ptr %slot337, align 8
  %op1968 = and i32 %v1966, %v1967
  store i32 %op1968, ptr %slot338, align 8
  %v1969 = load i32, ptr %slot338, align 8
  %cv1970 = zext i32 %v1969 to i64
  %cond1971 = icmp ne i64 %cv1970, 0
  br i1 %cond1971, label %bb_rctake431, label %bb_rccopy431
bb_rctake431:
  %v1972 = load i64, ptr %slot13, align 8
  store i64 %v1972, ptr %slot339, align 8
  %v1973 = load i64, ptr %slot23, align 8
  store i64 %v1973, ptr %slot340, align 8
  %v1974 = load i64, ptr %slot334, align 8
  %v1975 = load i64, ptr %slot339, align 8
  %op1976 = sub i64 %v1974, %v1975
  store i64 %op1976, ptr %slot341, align 8
  %v1977 = load i64, ptr %slot339, align 8
  %v1978 = load i64, ptr %slot334, align 8
  %op1979 = sub i64 %v1977, %v1978
  store i64 %op1979, ptr %slot342, align 8
  %v1980 = load i64, ptr %slot341, align 8
  %cmp1981 = icmp ult i64 %v1980, 8
  %cv1982 = zext i1 %cmp1981 to i32
  store i32 %cv1982, ptr %slot343, align 8
  %v1983 = load i64, ptr %slot342, align 8
  %cmp1984 = icmp ult i64 %v1983, 8
  %cv1985 = zext i1 %cmp1984 to i32
  store i32 %cv1985, ptr %slot344, align 8
  %v1986 = load i32, ptr %slot343, align 8
  %v1987 = load i32, ptr %slot344, align 8
  %op1988 = or i32 %v1986, %v1987
  store i32 %op1988, ptr %slot345, align 8
  %v1989 = load i32, ptr %slot345, align 8
  %cv1990 = zext i32 %v1989 to i64
  %cond1991 = icmp ne i64 %cv1990, 0
  br i1 %cond1991, label %bb_rcmoveslow440, label %bb_rcmovecheck440
bb_rcmovecheck440:
  %v1992 = load i64, ptr %slot334, align 8
  %p1994 = inttoptr i64 %v1992 to ptr
  %gep1995 = getelementptr i8, ptr %p1994, i64 0
  %op1993 = ptrtoint ptr %gep1995 to i64
  store i64 %op1993, ptr %slot346, align 8
  %v1996 = load i64, ptr %slot346, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot347, align 8
  %v1999 = load i64, ptr %slot347, align 8
  %cmp2000 = icmp ne i64 %v1999, 0
  %cv2001 = zext i1 %cmp2000 to i32
  store i32 %cv2001, ptr %slot348, align 8
  %v2002 = load i32, ptr %slot348, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcmoveheader448, label %bb_rcmovenext448
bb_rcmoveheader448:
  %v2005 = load i64, ptr %slot347, align 8
  %op2006 = sub i64 %v2005, 16
  store i64 %op2006, ptr %slot349, align 8
  %v2007 = load i64, ptr %slot347, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %rgep2009 = getelementptr i8, ptr %p2008, i64 -16
  %ld2010 = load i64, ptr %rgep2009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2010, ptr %slot350, align 8
  %v2011 = load i64, ptr %slot350, align 8
  %op2012 = and i64 %v2011, 5764607523034234881
  store i64 %op2012, ptr %slot351, align 8
  %v2013 = load i64, ptr %slot351, align 8
  %cmp2014 = icmp ne i64 %v2013, 0
  %cv2015 = zext i1 %cmp2014 to i32
  store i32 %cv2015, ptr %slot352, align 8
  %v2016 = load i32, ptr %slot352, align 8
  %cv2017 = zext i32 %v2016 to i64
  %cond2018 = icmp ne i64 %cv2017, 0
  br i1 %cond2018, label %bb_rcmoveslow440, label %bb_rcmovenext448
bb_rcmovenext448:
  %v2019 = load i64, ptr %slot334, align 8
  %v2020 = load i64, ptr %slot339, align 8
  %p2021 = inttoptr i64 %v2019 to ptr
  %p2022 = inttoptr i64 %v2020 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2022, ptr %p2021, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2023 = load i64, ptr %slot334, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 0, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved440
bb_rcmoveslow440:
  %v2025 = load i64, ptr %slot22, align 8
  %v2026 = load i64, ptr %slot339, align 8
  %v2027 = load i64, ptr %slot334, align 8
  %v2028 = load i64, ptr %slot340, align 8
  %cv2029 = trunc i64 %v2028 to i32
  %call2030 = call i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_take(i64 %v2025, i64 %v2026, i64 %v2027, i32 %cv2029) nomerge, !dbg !120
  store i32 %call2030, ptr %slot353, align 8
  %v2031 = load i32, ptr %slot353, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcsuccess455, label %bb_rcfailure455
bb_rcfailure455:
  %v2034 = load i64, ptr %slot22, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %call2036 = call i32 @myl_rc_take_failure(ptr %p2035) nomerge, !dbg !120
  store i32 %call2036, ptr %slot354, align 8
  %v2037 = load i64, ptr %slot1, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %v2039 = load i32, ptr %slot354, align 8
  %call2040 = call i32 @myl_qbe_rc_status(ptr %p2038, i32 %v2039) nomerge, !dbg !120
  store i32 %call2040, ptr %slot355, align 8
  br label %bb_failure
bb_rcsuccess455:
  br label %bb_rcmoved440
bb_rcmoved440:
  %v2041 = load i64, ptr %slot6, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i32 0, ptr %p2042, align 4, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot9, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  store i32 2, ptr %p2044, align 4, !alias.scope !3, !noalias !4
  %v2045 = load i64, ptr %slot8, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i32 1, ptr %p2046, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared431
bb_rccopy431:
  %v2047 = load i64, ptr %slot13, align 8
  store i64 %v2047, ptr %slot356, align 8
  %v2048 = load i64, ptr %slot23, align 8
  store i64 %v2048, ptr %slot357, align 8
  %v2049 = load i64, ptr %slot334, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  %ld2051 = load i64, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2051, ptr %slot358, align 8
  %v2052 = load i64, ptr %slot358, align 8
  %cmp2053 = icmp ne i64 %v2052, 0
  %cv2054 = zext i1 %cmp2053 to i32
  store i32 %cv2054, ptr %slot359, align 8
  %v2055 = load i32, ptr %slot359, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcgnn464, label %bb_rcgplain464
bb_rcgnn464:
  %v2058 = load i64, ptr %slot358, align 8
  %op2059 = sub i64 %v2058, 16
  store i64 %op2059, ptr %slot360, align 8
  %v2060 = load i64, ptr %slot358, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %rgep2062 = getelementptr i8, ptr %p2061, i64 -16
  %ld2063 = load i64, ptr %rgep2062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2063, ptr %slot361, align 8
  %v2064 = load i64, ptr %slot361, align 8
  %op2065 = and i64 %v2064, 4611686018427387906
  store i64 %op2065, ptr %slot362, align 8
  %v2066 = load i64, ptr %slot362, align 8
  %cmp2067 = icmp ne i64 %v2066, 0
  %cv2068 = zext i1 %cmp2067 to i32
  store i32 %cv2068, ptr %slot363, align 8
  %v2069 = load i32, ptr %slot363, align 8
  %cv2070 = zext i32 %v2069 to i64
  %cond2071 = icmp ne i64 %cv2070, 0
  br i1 %cond2071, label %bb_rcgspecial464, label %bb_rcginc464
bb_rcginc464:
  %v2072 = load i64, ptr %slot358, align 8
  %op2073 = sub i64 %v2072, 32
  store i64 %op2073, ptr %slot364, align 8
  %v2074 = load i64, ptr %slot358, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %rgep2076 = getelementptr i8, ptr %p2075, i64 -32
  %ld2077 = load i64, ptr %rgep2076, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2077, ptr %slot365, align 8
  %v2078 = load i64, ptr %slot365, align 8
  %op2079 = add i64 %v2078, 1
  store i64 %op2079, ptr %slot366, align 8
  %v2080 = load i64, ptr %slot366, align 8
  %cmp2081 = icmp eq i64 %v2080, 0
  %cv2082 = zext i1 %cmp2081 to i32
  store i32 %cv2082, ptr %slot367, align 8
  %v2083 = load i32, ptr %slot367, align 8
  %cv2084 = zext i32 %v2083 to i64
  %cond2085 = icmp ne i64 %cv2084, 0
  br i1 %cond2085, label %bb_rcglimit464, label %bb_rcgcapacity464
bb_rcglimit464:
  %v2086 = load i64, ptr %slot1, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %call2088 = call i32 @myl_qbe_rc_status(ptr %p2087, i32 2) nomerge, !dbg !120
  store i32 %call2088, ptr %slot368, align 8
  br label %bb_failure
bb_rcgcapacity464:
  %v2089 = load i64, ptr %slot366, align 8
  %v2090 = load i64, ptr %slot358, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  %rgep2092 = getelementptr i8, ptr %p2091, i64 -32
  store i64 %v2089, ptr %rgep2092, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain464
bb_rcgspecial464:
  %v2093 = load i64, ptr %slot361, align 8
  %op2094 = and i64 %v2093, 4611686018427387904
  store i64 %op2094, ptr %slot369, align 8
  %v2095 = load i64, ptr %slot369, align 8
  %cmp2096 = icmp ne i64 %v2095, 0
  %cv2097 = zext i1 %cmp2096 to i32
  store i32 %cv2097, ptr %slot370, align 8
  %v2098 = load i32, ptr %slot370, align 8
  %cv2099 = zext i32 %v2098 to i64
  %cond2100 = icmp ne i64 %cv2099, 0
  br i1 %cond2100, label %bb_rcgslow464, label %bb_rcgplain464
bb_rcgslow464:
  %v2101 = load i64, ptr %slot22, align 8
  %v2102 = load i64, ptr %slot356, align 8
  %v2103 = load i64, ptr %slot334, align 8
  %v2104 = load i64, ptr %slot357, align 8
  %cv2105 = trunc i64 %v2104 to i32
  %call2106 = call i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_retain(i64 %v2101, i64 %v2102, i64 %v2103, i32 %cv2105) nomerge, !dbg !120
  store i32 %call2106, ptr %slot371, align 8
  %v2107 = load i32, ptr %slot371, align 8
  %cv2108 = zext i32 %v2107 to i64
  %cond2109 = icmp ne i64 %cv2108, 0
  br i1 %cond2109, label %bb_rcsuccess478, label %bb_rcfailure478
bb_rcfailure478:
  %v2110 = load i64, ptr %slot22, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %call2112 = call i32 @myl_rc_take_failure(ptr %p2111) nomerge, !dbg !120
  store i32 %call2112, ptr %slot372, align 8
  %v2113 = load i64, ptr %slot1, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %v2115 = load i32, ptr %slot372, align 8
  %call2116 = call i32 @myl_qbe_rc_status(ptr %p2114, i32 %v2115) nomerge, !dbg !120
  store i32 %call2116, ptr %slot373, align 8
  br label %bb_failure
bb_rcsuccess478:
  br label %bb_rcgdone464
bb_rcgplain464:
  %v2117 = load i64, ptr %slot358, align 8
  %v2118 = load i64, ptr %slot356, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i64 %v2117, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone464
bb_rcgdone464:
  %v2120 = load i64, ptr %slot9, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i32 2, ptr %p2121, align 4, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot8, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  store i32 1, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  %v2124 = load i64, ptr %slot6, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %ld2126 = load i32, ptr %p2125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2126, ptr %slot374, align 8
  %v2127 = load i32, ptr %slot374, align 8
  %cv2128 = zext i32 %v2127 to i64
  %cond2129 = icmp ne i64 %cv2128, 0
  br i1 %cond2129, label %bb_rcslotdrop485, label %bb_rcslotdone485
bb_rcslotdrop485:
  %v2130 = load i64, ptr %slot6, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i32 0, ptr %p2131, align 4, !alias.scope !3, !noalias !4
  %v2132 = load i64, ptr %slot11, align 8
  store i64 %v2132, ptr %slot375, align 8
  %v2133 = load i64, ptr %slot7, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  %ld2135 = load i32, ptr %p2134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2135, ptr %slot376, align 8
  %v2136 = load i32, ptr %slot376, align 8
  %op2137 = and i32 %v2136, 28
  store i32 %op2137, ptr %slot377, align 8
  %v2138 = load i32, ptr %slot377, align 8
  %cv2139 = zext i32 %v2138 to i64
  %cond2140 = icmp ne i64 %cv2139, 0
  br i1 %cond2140, label %bb_rcslotrole485, label %bb_rcslotowner485
bb_rcslotrole485:
  %v2141 = load i64, ptr %slot22, align 8
  store i64 %v2141, ptr %slot378, align 8
  %v2142 = load i64, ptr %slot375, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  %ld2144 = load i64, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2144, ptr %slot379, align 8
  %v2145 = load i64, ptr %slot379, align 8
  %cmp2146 = icmp ne i64 %v2145, 0
  %cv2147 = zext i1 %cmp2146 to i32
  store i32 %cv2147, ptr %slot380, align 8
  %v2148 = load i32, ptr %slot380, align 8
  %cv2149 = zext i32 %v2148 to i64
  %cond2150 = icmp ne i64 %cv2149, 0
  br i1 %cond2150, label %bb_rcgnn501, label %bb_rcgdone501
bb_rcgnn501:
  %v2151 = load i64, ptr %slot379, align 8
  %op2152 = sub i64 %v2151, 16
  store i64 %op2152, ptr %slot381, align 8
  %v2153 = load i64, ptr %slot379, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %rgep2155 = getelementptr i8, ptr %p2154, i64 -16
  %ld2156 = load i64, ptr %rgep2155, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2156, ptr %slot382, align 8
  %v2157 = load i64, ptr %slot382, align 8
  %op2158 = and i64 %v2157, 4611686018427387906
  store i64 %op2158, ptr %slot383, align 8
  %v2159 = load i64, ptr %slot383, align 8
  %cmp2160 = icmp ne i64 %v2159, 0
  %cv2161 = zext i1 %cmp2160 to i32
  store i32 %cv2161, ptr %slot384, align 8
  %v2162 = load i32, ptr %slot384, align 8
  %cv2163 = zext i32 %v2162 to i64
  %cond2164 = icmp ne i64 %cv2163, 0
  br i1 %cond2164, label %bb_rcgclear501, label %bb_rcgcounted501
bb_rcgcounted501:
  %v2165 = load i64, ptr %slot379, align 8
  %op2166 = sub i64 %v2165, 24
  store i64 %op2166, ptr %slot385, align 8
  %v2167 = load i64, ptr %slot379, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %rgep2169 = getelementptr i8, ptr %p2168, i64 -24
  %ld2170 = load i64, ptr %rgep2169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2170, ptr %slot386, align 8
  %v2171 = load i64, ptr %slot386, align 8
  %op2172 = sub i64 %v2171, 1
  store i64 %op2172, ptr %slot387, align 8
  %v2173 = load i64, ptr %slot387, align 8
  %cmp2174 = icmp eq i64 %v2173, 0
  %cv2175 = zext i1 %cmp2174 to i32
  store i32 %cv2175, ptr %slot388, align 8
  %v2176 = load i32, ptr %slot388, align 8
  %cv2177 = zext i32 %v2176 to i64
  %cond2178 = icmp ne i64 %cv2177, 0
  br i1 %cond2178, label %bb_rcglast501, label %bb_rcgdec501
bb_rcglast501:
  %v2179 = load i64, ptr %slot379, align 8
  %op2180 = sub i64 %v2179, 32
  store i64 %op2180, ptr %slot389, align 8
  %v2181 = load i64, ptr %slot379, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %rgep2183 = getelementptr i8, ptr %p2182, i64 -32
  %ld2184 = load i64, ptr %rgep2183, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2184, ptr %slot390, align 8
  %v2185 = load i64, ptr %slot390, align 8
  %cmp2186 = icmp ne i64 %v2185, 0
  %cv2187 = zext i1 %cmp2186 to i32
  store i32 %cv2187, ptr %slot391, align 8
  %v2188 = load i32, ptr %slot391, align 8
  %cv2189 = zext i32 %v2188 to i64
  %cond2190 = icmp ne i64 %cv2189, 0
  br i1 %cond2190, label %bb_rcgdec501, label %bb_rcgslow501
bb_rcgslow501:
  %v2191 = load i64, ptr %slot378, align 8
  %v2192 = load i64, ptr %slot375, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v2191, i64 %v2192) nomerge, !dbg !120
  br label %bb_rcgdone501
bb_rcgdec501:
  %v2193 = load i64, ptr %slot387, align 8
  %v2194 = load i64, ptr %slot379, align 8
  %p2195 = inttoptr i64 %v2194 to ptr
  %rgep2196 = getelementptr i8, ptr %p2195, i64 -24
  store i64 %v2193, ptr %rgep2196, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear501
bb_rcgclear501:
  %v2197 = load i64, ptr %slot375, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i64 0, ptr %p2198, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone501
bb_rcgdone501:
  br label %bb_rcslotdone485
bb_rcslotowner485:
  %v2199 = load i64, ptr %slot22, align 8
  store i64 %v2199, ptr %slot392, align 8
  %v2200 = load i64, ptr %slot375, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %ld2202 = load i64, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2202, ptr %slot393, align 8
  %v2203 = load i64, ptr %slot393, align 8
  %cmp2204 = icmp ne i64 %v2203, 0
  %cv2205 = zext i1 %cmp2204 to i32
  store i32 %cv2205, ptr %slot394, align 8
  %v2206 = load i32, ptr %slot394, align 8
  %cv2207 = zext i32 %v2206 to i64
  %cond2208 = icmp ne i64 %cv2207, 0
  br i1 %cond2208, label %bb_rcgnn516, label %bb_rcgdone516
bb_rcgnn516:
  %v2209 = load i64, ptr %slot393, align 8
  %op2210 = sub i64 %v2209, 16
  store i64 %op2210, ptr %slot395, align 8
  %v2211 = load i64, ptr %slot393, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  %rgep2213 = getelementptr i8, ptr %p2212, i64 -16
  %ld2214 = load i64, ptr %rgep2213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2214, ptr %slot396, align 8
  %v2215 = load i64, ptr %slot396, align 8
  %op2216 = and i64 %v2215, 4611686018427387906
  store i64 %op2216, ptr %slot397, align 8
  %v2217 = load i64, ptr %slot397, align 8
  %cmp2218 = icmp ne i64 %v2217, 0
  %cv2219 = zext i1 %cmp2218 to i32
  store i32 %cv2219, ptr %slot398, align 8
  %v2220 = load i32, ptr %slot398, align 8
  %cv2221 = zext i32 %v2220 to i64
  %cond2222 = icmp ne i64 %cv2221, 0
  br i1 %cond2222, label %bb_rcgclear516, label %bb_rcgcounted516
bb_rcgcounted516:
  %v2223 = load i64, ptr %slot393, align 8
  %op2224 = sub i64 %v2223, 32
  store i64 %op2224, ptr %slot399, align 8
  %v2225 = load i64, ptr %slot393, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  %rgep2227 = getelementptr i8, ptr %p2226, i64 -32
  %ld2228 = load i64, ptr %rgep2227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2228, ptr %slot400, align 8
  %v2229 = load i64, ptr %slot400, align 8
  %op2230 = sub i64 %v2229, 1
  store i64 %op2230, ptr %slot401, align 8
  %v2231 = load i64, ptr %slot401, align 8
  %cmp2232 = icmp eq i64 %v2231, 0
  %cv2233 = zext i1 %cmp2232 to i32
  store i32 %cv2233, ptr %slot402, align 8
  %v2234 = load i32, ptr %slot402, align 8
  %cv2235 = zext i32 %v2234 to i64
  %cond2236 = icmp ne i64 %cv2235, 0
  br i1 %cond2236, label %bb_rcglast516, label %bb_rcgdec516
bb_rcglast516:
  %v2237 = load i64, ptr %slot393, align 8
  %op2238 = sub i64 %v2237, 24
  store i64 %op2238, ptr %slot403, align 8
  %v2239 = load i64, ptr %slot393, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  %rgep2241 = getelementptr i8, ptr %p2240, i64 -24
  %ld2242 = load i64, ptr %rgep2241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2242, ptr %slot404, align 8
  %v2243 = load i64, ptr %slot404, align 8
  %cmp2244 = icmp ne i64 %v2243, 0
  %cv2245 = zext i1 %cmp2244 to i32
  store i32 %cv2245, ptr %slot405, align 8
  %v2246 = load i32, ptr %slot405, align 8
  %cv2247 = zext i32 %v2246 to i64
  %cond2248 = icmp ne i64 %cv2247, 0
  br i1 %cond2248, label %bb_rcgdec516, label %bb_rcgslow516
bb_rcgslow516:
  %v2249 = load i64, ptr %slot392, align 8
  %v2250 = load i64, ptr %slot375, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2249, i64 %v2250) nomerge, !dbg !120
  br label %bb_rcgdone516
bb_rcgdec516:
  %v2251 = load i64, ptr %slot401, align 8
  %v2252 = load i64, ptr %slot393, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %rgep2254 = getelementptr i8, ptr %p2253, i64 -32
  store i64 %v2251, ptr %rgep2254, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear516
bb_rcgclear516:
  %v2255 = load i64, ptr %slot375, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i64 0, ptr %p2256, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone516
bb_rcgdone516:
  br label %bb_rcslotdone485
bb_rcslotdone485:
  br label %bb_rcprepared431
bb_rcprepared431:
  %v2257 = load i64, ptr %slot13, align 8
  store i64 %v2257, ptr %slot406, align 8
  %v2258 = load i64, ptr %slot406, align 8
  %v2259 = load i64, ptr %slot332, align 8
  %p2260 = inttoptr i64 %v2258 to ptr
  %p2261 = inttoptr i64 %v2259 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2261, ptr %p2260, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot8, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i32 0, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot328, align 8
  %v2265 = load i64, ptr %slot20, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i64 %v2264, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot20, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2269, ptr %slot407, align 8
  %v2270 = load i64, ptr %slot11, align 8
  store i64 %v2270, ptr %slot408, align 8
  %v2271 = load i64, ptr %slot407, align 8
  %v2272 = load i64, ptr %slot408, align 8
  %p2273 = inttoptr i64 %v2271 to ptr
  %p2274 = inttoptr i64 %v2272 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2274, ptr %p2273, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2275 = load i64, ptr %slot7, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i32 2, ptr %p2276, align 4, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot6, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i32 1, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot408, align 8
  %v2280 = load i64, ptr %slot20, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i64 %v2279, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot19, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  %ld2284 = load i64, ptr %p2283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2284, ptr %slot409, align 8
  %v2285 = load i64, ptr %slot20, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i64, ptr %p2286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2287, ptr %slot410, align 8
  %v2288 = load i64, ptr %slot22, align 8
  %v2289 = load i64, ptr %slot409, align 8
  %v2290 = load i64, ptr %slot410, align 8
  %call2291 = call i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_list_append(i64 %v2288, i64 %v2289, i64 %v2290) nomerge, !dbg !122
  store i32 %call2291, ptr %slot411, align 8
  %v2292 = load i32, ptr %slot411, align 8
  %cv2293 = zext i32 %v2292 to i64
  %cond2294 = icmp ne i64 %cv2293, 0
  br i1 %cond2294, label %bb_success529, label %bb_failed529
bb_failed529:
  %v2295 = load i64, ptr %slot1, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2296) nomerge, !dbg !122
  unreachable
bb_success529:
  %v2297 = load i64, ptr %slot20, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 0, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  %v2299 = load i64, ptr %slot6, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i32, ptr %p2300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2301, ptr %slot412, align 8
  %v2302 = load i32, ptr %slot412, align 8
  %cv2303 = zext i32 %v2302 to i64
  %cond2304 = icmp ne i64 %cv2303, 0
  br i1 %cond2304, label %bb_rcslotdrop532, label %bb_rcslotdone532
bb_rcslotdrop532:
  %v2305 = load i64, ptr %slot6, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  store i32 0, ptr %p2306, align 4, !alias.scope !3, !noalias !4
  %v2307 = load i64, ptr %slot11, align 8
  store i64 %v2307, ptr %slot413, align 8
  %v2308 = load i64, ptr %slot7, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i32, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2310, ptr %slot414, align 8
  %v2311 = load i32, ptr %slot414, align 8
  %op2312 = and i32 %v2311, 28
  store i32 %op2312, ptr %slot415, align 8
  %v2313 = load i32, ptr %slot415, align 8
  %cv2314 = zext i32 %v2313 to i64
  %cond2315 = icmp ne i64 %cv2314, 0
  br i1 %cond2315, label %bb_rcslotrole532, label %bb_rcslotowner532
bb_rcslotrole532:
  %v2316 = load i64, ptr %slot22, align 8
  store i64 %v2316, ptr %slot416, align 8
  %v2317 = load i64, ptr %slot416, align 8
  %v2318 = load i64, ptr %slot413, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v2317, i64 %v2318) nomerge, !dbg !122
  br label %bb_rcslotdone532
bb_rcslotowner532:
  %v2319 = load i64, ptr %slot22, align 8
  store i64 %v2319, ptr %slot417, align 8
  %v2320 = load i64, ptr %slot417, align 8
  %v2321 = load i64, ptr %slot413, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64 %v2320, i64 %v2321) nomerge, !dbg !122
  br label %bb_rcslotdone532
bb_rcslotdone532:
  %v2322 = load i64, ptr %slot14, align 8
  store i64 %v2322, ptr %slot418, align 8
  %v2323 = load i64, ptr %slot418, align 8
  %p2325 = inttoptr i64 %v2323 to ptr
  %gep2326 = getelementptr i8, ptr %p2325, i64 24
  %op2324 = ptrtoint ptr %gep2326 to i64
  store i64 %op2324, ptr %slot419, align 8
  %v2327 = load i64, ptr %slot419, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i32, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2329, ptr %slot420, align 8
  %v2330 = load i32, ptr %slot420, align 8
  %cv2331 = zext i32 %v2330 to i64
  %cond2332 = icmp ne i64 %cv2331, 0
  br i1 %cond2332, label %bb_rcsendactive540, label %bb_rcsenddone540
bb_rcsendactive540:
  %v2333 = load i64, ptr %slot22, align 8
  %p2335 = inttoptr i64 %v2333 to ptr
  %gep2336 = getelementptr i8, ptr %p2335, i64 5640
  %op2334 = ptrtoint ptr %gep2336 to i64
  store i64 %op2334, ptr %slot421, align 8
  %v2337 = load i64, ptr %slot421, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  %ld2339 = load i64, ptr %p2338, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2339, ptr %slot422, align 8
  %v2340 = load i64, ptr %slot422, align 8
  %op2341 = add i64 %v2340, 248
  store i64 %op2341, ptr %slot423, align 8
  %v2342 = load i64, ptr %slot423, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i64, ptr %p2343, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2344, ptr %slot424, align 8
  %v2345 = load i64, ptr %slot424, align 8
  %v2346 = load i64, ptr %slot418, align 8
  %cmp2347 = icmp eq i64 %v2345, %v2346
  %cv2348 = zext i1 %cmp2347 to i32
  store i32 %cv2348, ptr %slot425, align 8
  %v2349 = load i32, ptr %slot425, align 8
  %cv2350 = zext i32 %v2349 to i64
  %cond2351 = icmp ne i64 %cv2350, 0
  br i1 %cond2351, label %bb_rcs548, label %bb_rcsendslow540
bb_rcs548:
  %v2352 = load i64, ptr %slot422, align 8
  %op2353 = add i64 %v2352, 200
  store i64 %op2353, ptr %slot426, align 8
  %v2354 = load i64, ptr %slot426, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %ld2356 = load i64, ptr %p2355, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2356, ptr %slot427, align 8
  %v2357 = load i64, ptr %slot427, align 8
  %cmp2358 = icmp eq i64 %v2357, 0
  %cv2359 = zext i1 %cmp2358 to i32
  store i32 %cv2359, ptr %slot428, align 8
  %v2360 = load i32, ptr %slot428, align 8
  %cv2361 = zext i32 %v2360 to i64
  %cond2362 = icmp ne i64 %cv2361, 0
  br i1 %cond2362, label %bb_rcs552, label %bb_rcsendslow540
bb_rcs552:
  %v2363 = load i64, ptr %slot418, align 8
  %p2365 = inttoptr i64 %v2363 to ptr
  %gep2366 = getelementptr i8, ptr %p2365, i64 16
  %op2364 = ptrtoint ptr %gep2366 to i64
  store i64 %op2364, ptr %slot429, align 8
  %v2367 = load i64, ptr %slot429, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %ld2369 = load i64, ptr %p2368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2369, ptr %slot430, align 8
  %v2370 = load i64, ptr %slot430, align 8
  %cmp2371 = icmp ne i64 %v2370, 0
  %cv2372 = zext i1 %cmp2371 to i32
  store i32 %cv2372, ptr %slot431, align 8
  %v2373 = load i32, ptr %slot431, align 8
  %cv2374 = zext i32 %v2373 to i64
  %cond2375 = icmp ne i64 %cv2374, 0
  br i1 %cond2375, label %bb_rcsendnode540, label %bb_rcsendunlink540
bb_rcsendnode540:
  %v2376 = load i64, ptr %slot430, align 8
  %op2377 = add i64 %v2376, 0
  store i64 %op2377, ptr %slot432, align 8
  %v2378 = load i64, ptr %slot432, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %ld2380 = load i64, ptr %p2379, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2380, ptr %slot433, align 8
  %v2381 = load i64, ptr %slot433, align 8
  %cmp2382 = icmp eq i64 %v2381, 0
  %cv2383 = zext i1 %cmp2382 to i32
  store i32 %cv2383, ptr %slot434, align 8
  %v2384 = load i32, ptr %slot434, align 8
  %cv2385 = zext i32 %v2384 to i64
  %cond2386 = icmp ne i64 %cv2385, 0
  br i1 %cond2386, label %bb_rcs559, label %bb_rcsendslow540
bb_rcs559:
  %v2387 = load i64, ptr %slot422, align 8
  %op2388 = add i64 %v2387, 264
  store i64 %op2388, ptr %slot435, align 8
  %v2389 = load i64, ptr %slot435, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  %ld2391 = load i64, ptr %p2390, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2391, ptr %slot436, align 8
  %v2392 = load i64, ptr %slot436, align 8
  %cmp2393 = icmp ult i64 %v2392, 32
  %cv2394 = zext i1 %cmp2393 to i32
  store i32 %cv2394, ptr %slot437, align 8
  %v2395 = load i32, ptr %slot437, align 8
  %cv2396 = zext i32 %v2395 to i64
  %cond2397 = icmp ne i64 %cv2396, 0
  br i1 %cond2397, label %bb_rcs563, label %bb_rcsendslow540
bb_rcs563:
  %v2398 = load i64, ptr %slot430, align 8
  %op2399 = add i64 %v2398, 8
  store i64 %op2399, ptr %slot438, align 8
  %v2400 = load i64, ptr %slot438, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2402, ptr %slot439, align 8
  %v2403 = load i64, ptr %slot439, align 8
  %cmp2404 = icmp ne i64 %v2403, 0
  %cv2405 = zext i1 %cmp2404 to i32
  store i32 %cv2405, ptr %slot440, align 8
  %v2406 = load i32, ptr %slot440, align 8
  %cv2407 = zext i32 %v2406 to i64
  %cond2408 = icmp ne i64 %cv2407, 0
  br i1 %cond2408, label %bb_rcs567, label %bb_rcsendslow540
bb_rcs567:
  %v2409 = load i64, ptr %slot439, align 8
  %op2410 = sub i64 %v2409, 16
  store i64 %op2410, ptr %slot441, align 8
  %v2411 = load i64, ptr %slot439, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %rgep2413 = getelementptr i8, ptr %p2412, i64 -16
  %ld2414 = load i64, ptr %rgep2413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2414, ptr %slot442, align 8
  %v2415 = load i64, ptr %slot442, align 8
  %op2416 = and i64 %v2415, 4611686018427387907
  store i64 %op2416, ptr %slot443, align 8
  %v2417 = load i64, ptr %slot443, align 8
  %cmp2418 = icmp eq i64 %v2417, 0
  %cv2419 = zext i1 %cmp2418 to i32
  store i32 %cv2419, ptr %slot444, align 8
  %v2420 = load i32, ptr %slot444, align 8
  %cv2421 = zext i32 %v2420 to i64
  %cond2422 = icmp ne i64 %cv2421, 0
  br i1 %cond2422, label %bb_rcs572, label %bb_rcsendslow540
bb_rcs572:
  %v2423 = load i64, ptr %slot439, align 8
  %op2424 = sub i64 %v2423, 24
  store i64 %op2424, ptr %slot445, align 8
  %v2425 = load i64, ptr %slot439, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %rgep2427 = getelementptr i8, ptr %p2426, i64 -24
  %ld2428 = load i64, ptr %rgep2427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2428, ptr %slot446, align 8
  %v2429 = load i64, ptr %slot446, align 8
  %cmp2430 = icmp ne i64 %v2429, 0
  %cv2431 = zext i1 %cmp2430 to i32
  store i32 %cv2431, ptr %slot447, align 8
  %v2432 = load i32, ptr %slot447, align 8
  %cv2433 = zext i32 %v2432 to i64
  %cond2434 = icmp ne i64 %cv2433, 0
  br i1 %cond2434, label %bb_rcs576, label %bb_rcsendslow540
bb_rcs576:
  %v2435 = load i64, ptr %slot439, align 8
  %op2436 = sub i64 %v2435, 32
  store i64 %op2436, ptr %slot448, align 8
  %v2437 = load i64, ptr %slot439, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %rgep2439 = getelementptr i8, ptr %p2438, i64 -32
  %ld2440 = load i64, ptr %rgep2439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2440, ptr %slot449, align 8
  %v2441 = load i64, ptr %slot446, align 8
  %cmp2442 = icmp ugt i64 %v2441, 1
  %cv2443 = zext i1 %cmp2442 to i32
  store i32 %cv2443, ptr %slot450, align 8
  %v2444 = load i64, ptr %slot449, align 8
  %cmp2445 = icmp ne i64 %v2444, 0
  %cv2446 = zext i1 %cmp2445 to i32
  store i32 %cv2446, ptr %slot451, align 8
  %v2447 = load i32, ptr %slot450, align 8
  %v2448 = load i32, ptr %slot451, align 8
  %op2449 = or i32 %v2447, %v2448
  store i32 %op2449, ptr %slot452, align 8
  %v2450 = load i32, ptr %slot452, align 8
  %cv2451 = zext i32 %v2450 to i64
  %cond2452 = icmp ne i64 %cv2451, 0
  br i1 %cond2452, label %bb_rcs582, label %bb_rcsendslow540
bb_rcs582:
  %v2453 = load i64, ptr %slot430, align 8
  %op2454 = add i64 %v2453, 32
  store i64 %op2454, ptr %slot453, align 8
  %v2455 = load i64, ptr %slot453, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i64, ptr %p2456, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2457, ptr %slot454, align 8
  %v2458 = load i64, ptr %slot454, align 8
  %cmp2459 = icmp ne i64 %v2458, 0
  %cv2460 = zext i1 %cmp2459 to i32
  store i32 %cv2460, ptr %slot455, align 8
  %v2461 = load i32, ptr %slot455, align 8
  %cv2462 = zext i32 %v2461 to i64
  %cond2463 = icmp ne i64 %cv2462, 0
  br i1 %cond2463, label %bb_rcsendbacking540, label %bb_rcsendcommit540
bb_rcsendbacking540:
  %v2464 = load i64, ptr %slot454, align 8
  %op2465 = sub i64 %v2464, 16
  store i64 %op2465, ptr %slot456, align 8
  %v2466 = load i64, ptr %slot454, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %rgep2468 = getelementptr i8, ptr %p2467, i64 -16
  %ld2469 = load i64, ptr %rgep2468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2469, ptr %slot457, align 8
  %v2470 = load i64, ptr %slot457, align 8
  %op2471 = and i64 %v2470, 4611686018427387907
  store i64 %op2471, ptr %slot458, align 8
  %v2472 = load i64, ptr %slot458, align 8
  %cmp2473 = icmp eq i64 %v2472, 0
  %cv2474 = zext i1 %cmp2473 to i32
  store i32 %cv2474, ptr %slot459, align 8
  %v2475 = load i32, ptr %slot459, align 8
  %cv2476 = zext i32 %v2475 to i64
  %cond2477 = icmp ne i64 %cv2476, 0
  br i1 %cond2477, label %bb_rcs590, label %bb_rcsendslow540
bb_rcs590:
  %v2478 = load i64, ptr %slot454, align 8
  %op2479 = sub i64 %v2478, 24
  store i64 %op2479, ptr %slot460, align 8
  %v2480 = load i64, ptr %slot454, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %rgep2482 = getelementptr i8, ptr %p2481, i64 -24
  %ld2483 = load i64, ptr %rgep2482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2483, ptr %slot461, align 8
  %v2484 = load i64, ptr %slot461, align 8
  %cmp2485 = icmp ne i64 %v2484, 0
  %cv2486 = zext i1 %cmp2485 to i32
  store i32 %cv2486, ptr %slot462, align 8
  %v2487 = load i32, ptr %slot462, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcs594, label %bb_rcsendslow540
bb_rcs594:
  %v2490 = load i64, ptr %slot454, align 8
  %op2491 = sub i64 %v2490, 32
  store i64 %op2491, ptr %slot463, align 8
  %v2492 = load i64, ptr %slot454, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %rgep2494 = getelementptr i8, ptr %p2493, i64 -32
  %ld2495 = load i64, ptr %rgep2494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2495, ptr %slot464, align 8
  %v2496 = load i64, ptr %slot461, align 8
  %cmp2497 = icmp ugt i64 %v2496, 1
  %cv2498 = zext i1 %cmp2497 to i32
  store i32 %cv2498, ptr %slot465, align 8
  %v2499 = load i64, ptr %slot464, align 8
  %cmp2500 = icmp ne i64 %v2499, 0
  %cv2501 = zext i1 %cmp2500 to i32
  store i32 %cv2501, ptr %slot466, align 8
  %v2502 = load i32, ptr %slot465, align 8
  %v2503 = load i32, ptr %slot466, align 8
  %op2504 = or i32 %v2502, %v2503
  store i32 %op2504, ptr %slot467, align 8
  %v2505 = load i32, ptr %slot467, align 8
  %cv2506 = zext i32 %v2505 to i64
  %cond2507 = icmp ne i64 %cv2506, 0
  br i1 %cond2507, label %bb_rcs600, label %bb_rcsendslow540
bb_rcs600:
  br label %bb_rcsendcommit540
bb_rcsendcommit540:
  %v2508 = load i64, ptr %slot430, align 8
  %op2509 = add i64 %v2508, 24
  store i64 %op2509, ptr %slot468, align 8
  %v2510 = load i64, ptr %slot468, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %ld2512 = load i32, ptr %p2511, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld2512, ptr %slot469, align 8
  %v2513 = load i32, ptr %slot469, align 8
  %cv2514 = zext i32 %v2513 to i64
  %cond2515 = icmp ne i64 %cv2514, 0
  br i1 %cond2515, label %bb_rcsendrestore540, label %bb_rcsendreturned540
bb_rcsendrestore540:
  %v2516 = load i64, ptr %slot430, align 8
  %op2517 = add i64 %v2516, 16
  store i64 %op2517, ptr %slot470, align 8
  %v2518 = load i64, ptr %slot470, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  %ld2520 = load i64, ptr %p2519, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2520, ptr %slot471, align 8
  %v2521 = load i64, ptr %slot442, align 8
  %op2522 = and i64 %v2521, 17293822569102704639
  store i64 %op2522, ptr %slot472, align 8
  %v2523 = load i64, ptr %slot472, align 8
  %v2524 = load i64, ptr %slot471, align 8
  %op2525 = or i64 %v2523, %v2524
  store i64 %op2525, ptr %slot473, align 8
  %v2526 = load i64, ptr %slot439, align 8
  %op2527 = sub i64 %v2526, 16
  store i64 %op2527, ptr %slot474, align 8
  %v2528 = load i64, ptr %slot473, align 8
  %v2529 = load i64, ptr %slot439, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %rgep2531 = getelementptr i8, ptr %p2530, i64 -16
  store i64 %v2528, ptr %rgep2531, align 8, !alias.scope !9, !noalias !10
  %v2532 = load i64, ptr %slot418, align 8
  %p2534 = inttoptr i64 %v2532 to ptr
  %gep2535 = getelementptr i8, ptr %p2534, i64 16
  %op2533 = ptrtoint ptr %gep2535 to i64
  store i64 %op2533, ptr %slot475, align 8
  br label %bb_rcsendreturned540
bb_rcsendreturned540:
  %v2536 = load i64, ptr %slot475, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  store i64 0, ptr %p2537, align 8, !alias.scope !3, !noalias !4
  %v2538 = load i64, ptr %slot422, align 8
  %op2539 = add i64 %v2538, 256
  store i64 %op2539, ptr %slot476, align 8
  %v2540 = load i64, ptr %slot476, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i64, ptr %p2541, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2542, ptr %slot477, align 8
  %v2543 = load i64, ptr %slot430, align 8
  %op2544 = add i64 %v2543, 0
  store i64 %op2544, ptr %slot478, align 8
  %v2545 = load i64, ptr %slot477, align 8
  %v2546 = load i64, ptr %slot478, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  store i64 %v2545, ptr %p2547, align 8, !alias.scope !9999998, !noalias !9999999
  %v2548 = load i64, ptr %slot422, align 8
  %op2549 = add i64 %v2548, 256
  store i64 %op2549, ptr %slot479, align 8
  %v2550 = load i64, ptr %slot430, align 8
  %v2551 = load i64, ptr %slot479, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  store i64 %v2550, ptr %p2552, align 8, !alias.scope !9999998, !noalias !9999999
  %v2553 = load i64, ptr %slot422, align 8
  %op2554 = add i64 %v2553, 264
  store i64 %op2554, ptr %slot480, align 8
  %v2555 = load i64, ptr %slot480, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %ld2557 = load i64, ptr %p2556, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2557, ptr %slot481, align 8
  %v2558 = load i64, ptr %slot481, align 8
  %op2559 = add i64 %v2558, 1
  store i64 %op2559, ptr %slot482, align 8
  %v2560 = load i64, ptr %slot482, align 8
  %v2561 = load i64, ptr %slot480, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  store i64 %v2560, ptr %p2562, align 8, !alias.scope !9999998, !noalias !9999999
  %v2563 = load i64, ptr %slot22, align 8
  %p2565 = inttoptr i64 %v2563 to ptr
  %gep2566 = getelementptr i8, ptr %p2565, i64 24
  %op2564 = ptrtoint ptr %gep2566 to i64
  store i64 %op2564, ptr %slot483, align 8
  %v2567 = load i64, ptr %slot483, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  %ld2569 = load i64, ptr %p2568, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2569, ptr %slot484, align 8
  %v2570 = load i64, ptr %slot484, align 8
  %op2571 = add i64 %v2570, 18446744073709551576
  store i64 %op2571, ptr %slot485, align 8
  %v2572 = load i64, ptr %slot485, align 8
  %v2573 = load i64, ptr %slot483, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  store i64 %v2572, ptr %p2574, align 8, !alias.scope !9999998, !noalias !9999999
  %v2575 = load i64, ptr %slot422, align 8
  %op2576 = add i64 %v2575, 48
  store i64 %op2576, ptr %slot486, align 8
  %v2577 = load i64, ptr %slot486, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i64, ptr %p2578, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2579, ptr %slot487, align 8
  %v2580 = load i64, ptr %slot487, align 8
  %op2581 = add i64 %v2580, 18446744073709551576
  store i64 %op2581, ptr %slot488, align 8
  %v2582 = load i64, ptr %slot488, align 8
  %v2583 = load i64, ptr %slot486, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  store i64 %v2582, ptr %p2584, align 8, !alias.scope !9999998, !noalias !9999999
  %v2585 = load i64, ptr %slot454, align 8
  %cmp2586 = icmp ne i64 %v2585, 0
  %cv2587 = zext i1 %cmp2586 to i32
  store i32 %cv2587, ptr %slot489, align 8
  %v2588 = load i32, ptr %slot489, align 8
  %cv2589 = zext i32 %v2588 to i64
  %cond2590 = icmp ne i64 %cv2589, 0
  br i1 %cond2590, label %bb_rcsenddropbacking540, label %bb_rcsenddroppayload540
bb_rcsenddropbacking540:
  %v2591 = load i64, ptr %slot454, align 8
  %op2592 = sub i64 %v2591, 24
  store i64 %op2592, ptr %slot490, align 8
  %v2593 = load i64, ptr %slot454, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %rgep2595 = getelementptr i8, ptr %p2594, i64 -24
  %ld2596 = load i64, ptr %rgep2595, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2596, ptr %slot491, align 8
  %v2597 = load i64, ptr %slot491, align 8
  %op2598 = add i64 %v2597, 18446744073709551615
  store i64 %op2598, ptr %slot492, align 8
  %v2599 = load i64, ptr %slot492, align 8
  %v2600 = load i64, ptr %slot454, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %rgep2602 = getelementptr i8, ptr %p2601, i64 -24
  store i64 %v2599, ptr %rgep2602, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload540
bb_rcsenddroppayload540:
  %v2603 = load i64, ptr %slot439, align 8
  %op2604 = sub i64 %v2603, 24
  store i64 %op2604, ptr %slot493, align 8
  %v2605 = load i64, ptr %slot439, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  %rgep2607 = getelementptr i8, ptr %p2606, i64 -24
  %ld2608 = load i64, ptr %rgep2607, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2608, ptr %slot494, align 8
  %v2609 = load i64, ptr %slot494, align 8
  %op2610 = add i64 %v2609, 18446744073709551615
  store i64 %op2610, ptr %slot495, align 8
  %v2611 = load i64, ptr %slot495, align 8
  %v2612 = load i64, ptr %slot439, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  %rgep2614 = getelementptr i8, ptr %p2613, i64 -24
  store i64 %v2611, ptr %rgep2614, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink540
bb_rcsendunlink540:
  %v2615 = load i64, ptr %slot418, align 8
  %p2617 = inttoptr i64 %v2615 to ptr
  %gep2618 = getelementptr i8, ptr %p2617, i64 8
  %op2616 = ptrtoint ptr %gep2618 to i64
  store i64 %op2616, ptr %slot496, align 8
  %v2619 = load i64, ptr %slot496, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  %ld2621 = load i64, ptr %p2620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2621, ptr %slot497, align 8
  %v2622 = load i64, ptr %slot422, align 8
  %op2623 = add i64 %v2622, 248
  store i64 %op2623, ptr %slot498, align 8
  %v2624 = load i64, ptr %slot497, align 8
  %v2625 = load i64, ptr %slot498, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 %v2624, ptr %p2626, align 8, !alias.scope !9999998, !noalias !9999999
  %v2627 = load i64, ptr %slot418, align 8
  %p2629 = inttoptr i64 %v2627 to ptr
  %gep2630 = getelementptr i8, ptr %p2629, i64 24
  %op2628 = ptrtoint ptr %gep2630 to i64
  store i64 %op2628, ptr %slot499, align 8
  %v2631 = load i64, ptr %slot418, align 8
  %p2633 = inttoptr i64 %v2631 to ptr
  %gep2634 = getelementptr i8, ptr %p2633, i64 8
  %op2632 = ptrtoint ptr %gep2634 to i64
  store i64 %op2632, ptr %slot500, align 8
  %v2635 = load i64, ptr %slot499, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i32 0, ptr %p2636, align 4, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot500, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i64 0, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone540
bb_rcsendslow540:
  %v2639 = load i64, ptr %slot1, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  %v2641 = load i64, ptr %slot418, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p2640, ptr %p2642) nomerge, !dbg !122
  br label %bb_rcsenddone540
bb_rcsenddone540:
  %v2643 = load i64, ptr %slot20, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i64 0, ptr %p2644, align 8, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot20, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  %ld2647 = load i64, ptr %p2646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2647, ptr %slot501, align 8
  %v2648 = load i64, ptr %slot14, align 8
  %p2650 = inttoptr i64 %v2648 to ptr
  %gep2651 = getelementptr i8, ptr %p2650, i64 24
  %op2649 = ptrtoint ptr %gep2651 to i64
  store i64 %op2649, ptr %slot502, align 8
  %v2652 = load i64, ptr %slot502, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %ld2654 = load i32, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2654, ptr %slot503, align 8
  %v2655 = load i32, ptr %slot503, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcscopesopen637, label %bb_rcscopesclosed637
bb_rcscopesopen637:
  %v2658 = load i64, ptr %slot16, align 8
  %p2660 = inttoptr i64 %v2658 to ptr
  %gep2661 = getelementptr i8, ptr %p2660, i64 0
  %op2659 = ptrtoint ptr %gep2661 to i64
  store i64 %op2659, ptr %slot504, align 8
  %v2662 = load i64, ptr %slot14, align 8
  %v2663 = load i64, ptr %slot504, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i64 %v2662, ptr %p2664, align 8, !alias.scope !3, !noalias !4
  %v2665 = load i64, ptr %slot1, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %v2667 = load i64, ptr %slot16, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2666, ptr %p2668, i64 1) nomerge, !dbg !124
  br label %bb_rcscopesclosed637
bb_rcscopesclosed637:
  %v2669 = load i64, ptr %slot6, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %ld2671 = load i32, ptr %p2670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2671, ptr %slot505, align 8
  %v2672 = load i32, ptr %slot505, align 8
  %cv2673 = zext i32 %v2672 to i64
  %cond2674 = icmp ne i64 %cv2673, 0
  br i1 %cond2674, label %bb_rcslotdrop641, label %bb_rcslotdone641
bb_rcslotdrop641:
  %v2675 = load i64, ptr %slot6, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i32 0, ptr %p2676, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone641
bb_rcslotdone641:
  %v2677 = load i64, ptr %slot4, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  %ld2679 = load i32, ptr %p2678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2679, ptr %slot506, align 8
  %v2680 = load i32, ptr %slot506, align 8
  %cv2681 = zext i32 %v2680 to i64
  %cond2682 = icmp ne i64 %cv2681, 0
  br i1 %cond2682, label %bb_rcslotdrop681, label %bb_rcslotdone681
bb_rcslotdrop681:
  %v2683 = load i64, ptr %slot4, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i32 0, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot18, align 8
  store i64 %v2685, ptr %slot507, align 8
  %v2686 = load i64, ptr %slot5, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  %ld2688 = load i32, ptr %p2687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2688, ptr %slot508, align 8
  %v2689 = load i32, ptr %slot508, align 8
  %op2690 = and i32 %v2689, 28
  store i32 %op2690, ptr %slot509, align 8
  %v2691 = load i32, ptr %slot509, align 8
  %cv2692 = zext i32 %v2691 to i64
  %cond2693 = icmp ne i64 %cv2692, 0
  br i1 %cond2693, label %bb_rcslotrole681, label %bb_rcslotowner681
bb_rcslotrole681:
  %v2694 = load i64, ptr %slot22, align 8
  store i64 %v2694, ptr %slot510, align 8
  %v2695 = load i64, ptr %slot507, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %ld2697 = load i64, ptr %p2696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2697, ptr %slot511, align 8
  %v2698 = load i64, ptr %slot511, align 8
  %cmp2699 = icmp ne i64 %v2698, 0
  %cv2700 = zext i1 %cmp2699 to i32
  store i32 %cv2700, ptr %slot512, align 8
  %v2701 = load i32, ptr %slot512, align 8
  %cv2702 = zext i32 %v2701 to i64
  %cond2703 = icmp ne i64 %cv2702, 0
  br i1 %cond2703, label %bb_rcgnn697, label %bb_rcgdone697
bb_rcgnn697:
  %v2704 = load i64, ptr %slot511, align 8
  %op2705 = sub i64 %v2704, 16
  store i64 %op2705, ptr %slot513, align 8
  %v2706 = load i64, ptr %slot511, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %rgep2708 = getelementptr i8, ptr %p2707, i64 -16
  %ld2709 = load i64, ptr %rgep2708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2709, ptr %slot514, align 8
  %v2710 = load i64, ptr %slot514, align 8
  %op2711 = and i64 %v2710, 4611686018427387906
  store i64 %op2711, ptr %slot515, align 8
  %v2712 = load i64, ptr %slot515, align 8
  %cmp2713 = icmp ne i64 %v2712, 0
  %cv2714 = zext i1 %cmp2713 to i32
  store i32 %cv2714, ptr %slot516, align 8
  %v2715 = load i32, ptr %slot516, align 8
  %cv2716 = zext i32 %v2715 to i64
  %cond2717 = icmp ne i64 %cv2716, 0
  br i1 %cond2717, label %bb_rcgclear697, label %bb_rcgcounted697
bb_rcgcounted697:
  %v2718 = load i64, ptr %slot511, align 8
  %op2719 = sub i64 %v2718, 24
  store i64 %op2719, ptr %slot517, align 8
  %v2720 = load i64, ptr %slot511, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  %rgep2722 = getelementptr i8, ptr %p2721, i64 -24
  %ld2723 = load i64, ptr %rgep2722, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2723, ptr %slot518, align 8
  %v2724 = load i64, ptr %slot518, align 8
  %op2725 = sub i64 %v2724, 1
  store i64 %op2725, ptr %slot519, align 8
  %v2726 = load i64, ptr %slot519, align 8
  %cmp2727 = icmp eq i64 %v2726, 0
  %cv2728 = zext i1 %cmp2727 to i32
  store i32 %cv2728, ptr %slot520, align 8
  %v2729 = load i32, ptr %slot520, align 8
  %cv2730 = zext i32 %v2729 to i64
  %cond2731 = icmp ne i64 %cv2730, 0
  br i1 %cond2731, label %bb_rcglast697, label %bb_rcgdec697
bb_rcglast697:
  %v2732 = load i64, ptr %slot511, align 8
  %op2733 = sub i64 %v2732, 32
  store i64 %op2733, ptr %slot521, align 8
  %v2734 = load i64, ptr %slot511, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  %rgep2736 = getelementptr i8, ptr %p2735, i64 -32
  %ld2737 = load i64, ptr %rgep2736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2737, ptr %slot522, align 8
  %v2738 = load i64, ptr %slot522, align 8
  %cmp2739 = icmp ne i64 %v2738, 0
  %cv2740 = zext i1 %cmp2739 to i32
  store i32 %cv2740, ptr %slot523, align 8
  %v2741 = load i32, ptr %slot523, align 8
  %cv2742 = zext i32 %v2741 to i64
  %cond2743 = icmp ne i64 %cv2742, 0
  br i1 %cond2743, label %bb_rcgdec697, label %bb_rcgslow697
bb_rcgslow697:
  %v2744 = load i64, ptr %slot510, align 8
  %v2745 = load i64, ptr %slot507, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v2744, i64 %v2745) nomerge, !dbg !124
  br label %bb_rcgdone697
bb_rcgdec697:
  %v2746 = load i64, ptr %slot519, align 8
  %v2747 = load i64, ptr %slot511, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  %rgep2749 = getelementptr i8, ptr %p2748, i64 -24
  store i64 %v2746, ptr %rgep2749, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear697
bb_rcgclear697:
  %v2750 = load i64, ptr %slot507, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i64 0, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone697
bb_rcgdone697:
  br label %bb_rcslotdone681
bb_rcslotowner681:
  %v2752 = load i64, ptr %slot22, align 8
  store i64 %v2752, ptr %slot524, align 8
  %v2753 = load i64, ptr %slot507, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %ld2755 = load i64, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2755, ptr %slot525, align 8
  %v2756 = load i64, ptr %slot525, align 8
  %cmp2757 = icmp ne i64 %v2756, 0
  %cv2758 = zext i1 %cmp2757 to i32
  store i32 %cv2758, ptr %slot526, align 8
  %v2759 = load i32, ptr %slot526, align 8
  %cv2760 = zext i32 %v2759 to i64
  %cond2761 = icmp ne i64 %cv2760, 0
  br i1 %cond2761, label %bb_rcgnn712, label %bb_rcgdone712
bb_rcgnn712:
  %v2762 = load i64, ptr %slot525, align 8
  %op2763 = sub i64 %v2762, 16
  store i64 %op2763, ptr %slot527, align 8
  %v2764 = load i64, ptr %slot525, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  %rgep2766 = getelementptr i8, ptr %p2765, i64 -16
  %ld2767 = load i64, ptr %rgep2766, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2767, ptr %slot528, align 8
  %v2768 = load i64, ptr %slot528, align 8
  %op2769 = and i64 %v2768, 4611686018427387906
  store i64 %op2769, ptr %slot529, align 8
  %v2770 = load i64, ptr %slot529, align 8
  %cmp2771 = icmp ne i64 %v2770, 0
  %cv2772 = zext i1 %cmp2771 to i32
  store i32 %cv2772, ptr %slot530, align 8
  %v2773 = load i32, ptr %slot530, align 8
  %cv2774 = zext i32 %v2773 to i64
  %cond2775 = icmp ne i64 %cv2774, 0
  br i1 %cond2775, label %bb_rcgclear712, label %bb_rcgcounted712
bb_rcgcounted712:
  %v2776 = load i64, ptr %slot525, align 8
  %op2777 = sub i64 %v2776, 32
  store i64 %op2777, ptr %slot531, align 8
  %v2778 = load i64, ptr %slot525, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %rgep2780 = getelementptr i8, ptr %p2779, i64 -32
  %ld2781 = load i64, ptr %rgep2780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2781, ptr %slot532, align 8
  %v2782 = load i64, ptr %slot532, align 8
  %op2783 = sub i64 %v2782, 1
  store i64 %op2783, ptr %slot533, align 8
  %v2784 = load i64, ptr %slot533, align 8
  %cmp2785 = icmp eq i64 %v2784, 0
  %cv2786 = zext i1 %cmp2785 to i32
  store i32 %cv2786, ptr %slot534, align 8
  %v2787 = load i32, ptr %slot534, align 8
  %cv2788 = zext i32 %v2787 to i64
  %cond2789 = icmp ne i64 %cv2788, 0
  br i1 %cond2789, label %bb_rcglast712, label %bb_rcgdec712
bb_rcglast712:
  %v2790 = load i64, ptr %slot525, align 8
  %op2791 = sub i64 %v2790, 24
  store i64 %op2791, ptr %slot535, align 8
  %v2792 = load i64, ptr %slot525, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  %rgep2794 = getelementptr i8, ptr %p2793, i64 -24
  %ld2795 = load i64, ptr %rgep2794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2795, ptr %slot536, align 8
  %v2796 = load i64, ptr %slot536, align 8
  %cmp2797 = icmp ne i64 %v2796, 0
  %cv2798 = zext i1 %cmp2797 to i32
  store i32 %cv2798, ptr %slot537, align 8
  %v2799 = load i32, ptr %slot537, align 8
  %cv2800 = zext i32 %v2799 to i64
  %cond2801 = icmp ne i64 %cv2800, 0
  br i1 %cond2801, label %bb_rcgdec712, label %bb_rcgslow712
bb_rcgslow712:
  %v2802 = load i64, ptr %slot524, align 8
  %v2803 = load i64, ptr %slot507, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2802, i64 %v2803) nomerge, !dbg !124
  br label %bb_rcgdone712
bb_rcgdec712:
  %v2804 = load i64, ptr %slot533, align 8
  %v2805 = load i64, ptr %slot525, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %rgep2807 = getelementptr i8, ptr %p2806, i64 -32
  store i64 %v2804, ptr %rgep2807, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear712
bb_rcgclear712:
  %v2808 = load i64, ptr %slot507, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i64 0, ptr %p2809, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone712
bb_rcgdone712:
  br label %bb_rcslotdone681
bb_rcslotdone681:
  %v2810 = load i64, ptr %slot501, align 8
  ret i64 %v2810
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50 = external global i8, align 8
@myl_t_f749cfa4957a50c796581a924ff7e06dd2421e2bd9503d1990c4d6b66531549d = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_drop(i64, i64)
declare void @myl_t_4f20e76e27e395fee56a693879e303c849eda963e9a3b99991d08b034e016e50_rcg_unloan(i64, i64)
declare void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64, i64)
declare i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64, i64)
declare void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64, i64)
declare i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_list_append(i64, i64, i64)
declare void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577", linkageName: "myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16244860720683020818, i64 0, !"myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!124 = !DILocation(line: 13, column: 0, scope: !125)
