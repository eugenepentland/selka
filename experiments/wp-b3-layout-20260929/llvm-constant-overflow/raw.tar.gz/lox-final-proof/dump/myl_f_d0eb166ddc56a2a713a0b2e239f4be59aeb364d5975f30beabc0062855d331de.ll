target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_d0eb166ddc56a2a713a0b2e239f4be59aeb364d5975f30beabc0062855d331de(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v40 = load i64, ptr %slot1, align 8
  %op41 = add i64 %v40, 32
  store i64 %op41, ptr %slot4, align 8
  %mem42 = alloca i8, i64 8, align 8
  %ptr43 = ptrtoint ptr %mem42 to i64
  store i64 %ptr43, ptr %slot5, align 8
  %mem44 = alloca i8, i64 8, align 8
  %ptr45 = ptrtoint ptr %mem44 to i64
  store i64 %ptr45, ptr %slot6, align 8
  %mem46 = alloca i8, i64 8, align 8
  %ptr47 = ptrtoint ptr %mem46 to i64
  store i64 %ptr47, ptr %slot7, align 8
  %mem48 = alloca i8, i64 8, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot8, align 8
  %v50 = load i64, ptr %slot2, align 8
  %v51 = load i64, ptr %slot5, align 8
  %p52 = inttoptr i64 %v51 to ptr
  store i64 %v50, ptr %p52, align 8, !alias.scope !3, !noalias !4
  %v53 = load i64, ptr %slot3, align 8
  %v54 = load i64, ptr %slot6, align 8
  %p55 = inttoptr i64 %v54 to ptr
  store i64 %v53, ptr %p55, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v56 = load i64, ptr %slot5, align 8
  %p57 = inttoptr i64 %v56 to ptr
  %ld58 = load i64, ptr %p57, align 8, !alias.scope !3, !noalias !4
  store i64 %ld58, ptr %slot9, align 8
  %v59 = load i64, ptr %slot9, align 8
  %v60 = load i64, ptr %slot7, align 8
  %p61 = inttoptr i64 %v60 to ptr
  store i64 %v59, ptr %p61, align 8, !alias.scope !3, !noalias !4
  %v62 = load i64, ptr %slot7, align 8
  %p63 = inttoptr i64 %v62 to ptr
  %ld64 = load i64, ptr %p63, align 8, !alias.scope !3, !noalias !4
  store i64 %ld64, ptr %slot10, align 8
  %v65 = load i64, ptr %slot10, align 8
  %op66 = add i64 %v65, 0
  store i64 %op66, ptr %slot11, align 8
  %v67 = load i64, ptr %slot11, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !4, !noalias !3
  store i64 %ld69, ptr %slot12, align 8
  %v70 = load i64, ptr %slot12, align 8
  %v71 = load i64, ptr %slot7, align 8
  %p72 = inttoptr i64 %v71 to ptr
  store i64 %v70, ptr %p72, align 8, !alias.scope !3, !noalias !4
  %v73 = load i64, ptr %slot6, align 8
  %p74 = inttoptr i64 %v73 to ptr
  %ld75 = load i64, ptr %p74, align 8, !alias.scope !3, !noalias !4
  store i64 %ld75, ptr %slot13, align 8
  %v76 = load i64, ptr %slot13, align 8
  %v77 = load i64, ptr %slot8, align 8
  %p78 = inttoptr i64 %v77 to ptr
  store i64 %v76, ptr %p78, align 8, !alias.scope !3, !noalias !4
  %v79 = load i64, ptr %slot8, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ld81 = load i64, ptr %p80, align 8, !alias.scope !3, !noalias !4
  store i64 %ld81, ptr %slot14, align 8
  %v82 = load i64, ptr %slot14, align 8
  %op83 = add i64 %v82, 0
  store i64 %op83, ptr %slot15, align 8
  %v84 = load i64, ptr %slot15, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ld86 = load i64, ptr %p85, align 8, !alias.scope !4, !noalias !3
  store i64 %ld86, ptr %slot16, align 8
  %v87 = load i64, ptr %slot16, align 8
  %v88 = load i64, ptr %slot8, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  %v90 = load i64, ptr %slot8, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot17, align 8
  %v93 = load i64, ptr %slot7, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot18, align 8
  %v96 = load i64, ptr %slot18, align 8
  %v97 = load i64, ptr %slot17, align 8
  %cmp98 = icmp slt i64 %v96, %v97
  %cv99 = zext i1 %cmp98 to i64
  store i64 %cv99, ptr %slot19, align 8
  %v100 = load i64, ptr %slot19, align 8
  %v101 = load i64, ptr %slot7, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 %v100, ptr %p102, align 8, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot7, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld105, ptr %slot20, align 8
  %v106 = load i64, ptr %slot20, align 8
  %cond107 = icmp ne i64 %v106, 0
  br i1 %cond107, label %bb_next12, label %bb_i10
bb_next12:
  %v108 = load i64, ptr %slot7, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 0, ptr %p109, align 8, !alias.scope !3, !noalias !4
  %v110 = load i64, ptr %slot8, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 1, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot8, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot21, align 8
  %v115 = load i64, ptr %slot7, align 8
  %p116 = inttoptr i64 %v115 to ptr
  %ld117 = load i64, ptr %p116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld117, ptr %slot22, align 8
  %v118 = load i64, ptr %slot22, align 8
  %v119 = load i64, ptr %slot21, align 8
  %ovpair121 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v118, i64 %v119)
  %op120 = extractvalue { i64, i1 } %ovpair121, 0
  %ov122 = extractvalue { i64, i1 } %ovpair121, 1
  store i64 %op120, ptr %slot23, align 8
  %cv123 = zext i1 %ov122 to i64
  store i64 %cv123, ptr %slot24, align 8
  %v124 = load i64, ptr %slot24, align 8
  %cond125 = icmp ne i64 %v124, 0
  br i1 %cond125, label %bb_overflow14, label %bb_checked14
bb_overflow14:
  %v126 = load i64, ptr %slot1, align 8
  %p127 = inttoptr i64 %v126 to ptr
  %v128 = load i64, ptr %slot22, align 8
  %v129 = load i64, ptr %slot21, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p127, i64 1, i64 %v128, i64 %v129, i64 64) nomerge, !dbg !110
  unreachable
bb_checked14:
  %v130 = load i64, ptr %slot23, align 8
  %v131 = load i64, ptr %slot7, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot7, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot25, align 8
  %v136 = load i64, ptr %slot25, align 8
  ret i64 %v136
bb_i10:
  %v137 = load i64, ptr %slot5, align 8
  %p138 = inttoptr i64 %v137 to ptr
  %ld139 = load i64, ptr %p138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld139, ptr %slot26, align 8
  %v140 = load i64, ptr %slot26, align 8
  %v141 = load i64, ptr %slot7, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 %v140, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot7, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot27, align 8
  %v146 = load i64, ptr %slot27, align 8
  %op147 = add i64 %v146, 0
  store i64 %op147, ptr %slot28, align 8
  %v148 = load i64, ptr %slot28, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ld150 = load i64, ptr %p149, align 8, !alias.scope !4, !noalias !3
  store i64 %ld150, ptr %slot29, align 8
  %v151 = load i64, ptr %slot29, align 8
  %v152 = load i64, ptr %slot7, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot6, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot30, align 8
  %v157 = load i64, ptr %slot30, align 8
  %v158 = load i64, ptr %slot8, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot8, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot31, align 8
  %v163 = load i64, ptr %slot31, align 8
  %op164 = add i64 %v163, 0
  store i64 %op164, ptr %slot32, align 8
  %v165 = load i64, ptr %slot32, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !4, !noalias !3
  store i64 %ld167, ptr %slot33, align 8
  %v168 = load i64, ptr %slot33, align 8
  %v169 = load i64, ptr %slot8, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot8, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot34, align 8
  %v174 = load i64, ptr %slot7, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot35, align 8
  %v177 = load i64, ptr %slot35, align 8
  %v178 = load i64, ptr %slot34, align 8
  %cmp179 = icmp sgt i64 %v177, %v178
  %cv180 = zext i1 %cmp179 to i64
  store i64 %cv180, ptr %slot36, align 8
  %v181 = load i64, ptr %slot36, align 8
  %v182 = load i64, ptr %slot7, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot7, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot37, align 8
  %v187 = load i64, ptr %slot37, align 8
  %cond188 = icmp ne i64 %v187, 0
  br i1 %cond188, label %bb_next29, label %bb_i18
bb_next29:
  %v189 = load i64, ptr %slot7, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 1, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot7, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot38, align 8
  %v194 = load i64, ptr %slot38, align 8
  ret i64 %v194
bb_i18:
  %v195 = load i64, ptr %slot7, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 0, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot7, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot39, align 8
  %v200 = load i64, ptr %slot39, align 8
  ret i64 %v200
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_d0eb166ddc56a2a713a0b2e239f4be59aeb364d5975f30beabc0062855d331de", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_d0eb166ddc56a2a713a0b2e239f4be59aeb364d5975f30beabc0062855d331de", linkageName: "myl_f_d0eb166ddc56a2a713a0b2e239f4be59aeb364d5975f30beabc0062855d331de", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8023108329247372920, i64 0, !"myl_f_d0eb166ddc56a2a713a0b2e239f4be59aeb364d5975f30beabc0062855d331de"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!110 = !DILocation(line: 9, column: 0, scope: !111)
