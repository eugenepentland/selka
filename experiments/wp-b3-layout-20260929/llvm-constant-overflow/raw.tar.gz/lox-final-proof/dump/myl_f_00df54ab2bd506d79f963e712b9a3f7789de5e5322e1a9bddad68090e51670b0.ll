target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v83 = load i64, ptr %slot1, align 8
  %op84 = add i64 %v83, 32
  store i64 %op84, ptr %slot4, align 8
  %mem85 = alloca i8, i64 24, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot5, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot6, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot7, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot8, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot9, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot10, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot11, align 8
  %mem99 = alloca i8, i64 304, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot12, align 8
  %mem101 = alloca i8, i64 304, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot13, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot14, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot15, align 8
  %mem107 = alloca i8, i64 208, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot16, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot17, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot18, align 8
  %mem113 = alloca i8, i64 304, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot19, align 8
  %mem115 = alloca i8, i64 24, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot20, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot21, align 8
  %v119 = load i64, ptr %slot1, align 8
  %op120 = add i64 %v119, 64
  store i64 %op120, ptr %slot22, align 8
  %v121 = load i64, ptr %slot22, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !4, !noalias !3
  store i64 %ld123, ptr %slot23, align 8
  %stack124 = call ptr @llvm.stacksave()
  %stackaddr125 = ptrtoint ptr %stack124 to i64
  %v126 = load i64, ptr %slot23, align 8
  %cmp127 = icmp ult i64 %stackaddr125, %v126
  %cv128 = zext i1 %cmp127 to i64
  store i64 %cv128, ptr %slot24, align 8
  %v129 = load i64, ptr %slot24, align 8
  %cond130 = icmp ne i64 %v129, 0
  br i1 %cond130, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v131 = load i64, ptr %slot1, align 8
  %p132 = inttoptr i64 %v131 to ptr
  call void @myl_qbe_fail_frame(ptr %p132) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v133 = load i64, ptr %slot2, align 8
  %v134 = load i64, ptr %slot14, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i64 %v133, ptr %p135, align 8, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot3, align 8
  %v137 = load i64, ptr %slot15, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot1, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %call141 = call ptr @myl_qbe_heap(ptr %p140) nomerge, !dbg !112
  %calladdr142 = ptrtoint ptr %call141 to i64
  store i64 %calladdr142, ptr %slot25, align 8
  %v143 = load i64, ptr %slot1, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %call145 = call i64 @myl_qbe_region_mark(ptr %p144) nomerge, !dbg !112
  store i64 %call145, ptr %slot26, align 8
  %v146 = load i64, ptr %slot6, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i32 0, ptr %p147, align 4, !alias.scope !3, !noalias !4
  %v148 = load i64, ptr %slot7, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i32 0, ptr %p149, align 4, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot8, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i32 0, ptr %p151, align 4, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot9, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i32 0, ptr %p153, align 4, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot10, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i32 0, ptr %p155, align 4, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot11, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i32 0, ptr %p157, align 4, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot7, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i32 2, ptr %p159, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v160 = load i64, ptr %slot14, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot27, align 8
  %v163 = load i64, ptr %slot27, align 8
  %v164 = load i64, ptr %slot19, align 8
  %p165 = inttoptr i64 %v163 to ptr
  %p166 = inttoptr i64 %v164 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p166, ptr %p165, i64 304, i1 false), !alias.scope !10000000
  %v167 = load i64, ptr %slot19, align 8
  %v168 = load i64, ptr %slot17, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 %v167, ptr %p169, align 8, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot17, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld172, ptr %slot28, align 8
  %v173 = load i64, ptr %slot28, align 8
  %op174 = add i64 %v173, 32
  store i64 %op174, ptr %slot29, align 8
  %v175 = load i64, ptr %slot29, align 8
  %v176 = load i64, ptr %slot17, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot6, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i32, ptr %p179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld180, ptr %slot30, align 8
  %v181 = load i32, ptr %slot30, align 8
  %cv182 = zext i32 %v181 to i64
  %cond183 = icmp ne i64 %cv182, 0
  br i1 %cond183, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v184 = load i64, ptr %slot6, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i32 0, ptr %p185, align 4, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot16, align 8
  store i64 %v186, ptr %slot31, align 8
  %v187 = load i64, ptr %slot7, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i32, ptr %p188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld189, ptr %slot32, align 8
  %v190 = load i32, ptr %slot32, align 8
  %op191 = and i32 %v190, 28
  store i32 %op191, ptr %slot33, align 8
  %v192 = load i32, ptr %slot33, align 8
  %cv193 = zext i32 %v192 to i64
  %cond194 = icmp ne i64 %cv193, 0
  br i1 %cond194, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v195 = load i64, ptr %slot25, align 8
  store i64 %v195, ptr %slot34, align 8
  %v196 = load i64, ptr %slot34, align 8
  %v197 = load i64, ptr %slot31, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v196, i64 %v197) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v198 = load i64, ptr %slot25, align 8
  store i64 %v198, ptr %slot35, align 8
  %v199 = load i64, ptr %slot35, align 8
  %v200 = load i64, ptr %slot31, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v199, i64 %v200) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v201 = load i64, ptr %slot14, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld203, ptr %slot36, align 8
  %v204 = load i64, ptr %slot36, align 8
  %op205 = add i64 %v204, 32
  store i64 %op205, ptr %slot37, align 8
  %v206 = load i64, ptr %slot16, align 8
  store i64 %v206, ptr %slot38, align 8
  %v207 = load i64, ptr %slot37, align 8
  %v208 = load i64, ptr %slot38, align 8
  %p209 = inttoptr i64 %v207 to ptr
  %p210 = inttoptr i64 %v208 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p210, ptr %p209, i64 208, i1 false), !alias.scope !10000000
  %v211 = load i64, ptr %slot37, align 8
  %p212 = inttoptr i64 %v211 to ptr
  call void @llvm.memset.p0.i64(ptr %p212, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !114
  %v213 = load i64, ptr %slot6, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i32 1, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot16, align 8
  %v216 = load i64, ptr %slot17, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot15, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot39, align 8
  %v221 = load i64, ptr %slot39, align 8
  %v222 = load i64, ptr %slot18, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot18, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot40, align 8
  %v227 = load i64, ptr %slot40, align 8
  %op228 = add i64 %v227, 0
  store i64 %op228, ptr %slot41, align 8
  %v229 = load i64, ptr %slot41, align 8
  %v230 = load i64, ptr %slot18, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot17, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot42, align 8
  %v235 = load i64, ptr %slot18, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld237, ptr %slot43, align 8
  %v238 = load i64, ptr %slot1, align 8
  %v239 = load i64, ptr %slot42, align 8
  %v240 = load i64, ptr %slot43, align 8
  %call241 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v238, i64 %v239, i64 %v240) nomerge, !dbg !116
  store i64 %call241, ptr %slot44, align 8
  %v242 = load i64, ptr %slot44, align 8
  %v243 = load i64, ptr %slot17, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 %v242, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot8, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i32, ptr %p246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld247, ptr %slot45, align 8
  %v248 = load i32, ptr %slot45, align 8
  %cv249 = zext i32 %v248 to i64
  %cond250 = icmp ne i64 %cv249, 0
  br i1 %cond250, label %bb_rcslotdrop45, label %bb_rcslotdone45
bb_rcslotdrop45:
  %v251 = load i64, ptr %slot8, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 0, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot12, align 8
  store i64 %v253, ptr %slot46, align 8
  %v254 = load i64, ptr %slot9, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i32, ptr %p255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld256, ptr %slot47, align 8
  %v257 = load i32, ptr %slot47, align 8
  %op258 = and i32 %v257, 28
  store i32 %op258, ptr %slot48, align 8
  %v259 = load i32, ptr %slot48, align 8
  %cv260 = zext i32 %v259 to i64
  %cond261 = icmp ne i64 %cv260, 0
  br i1 %cond261, label %bb_rcslotrole45, label %bb_rcslotowner45
bb_rcslotrole45:
  %v262 = load i64, ptr %slot25, align 8
  store i64 %v262, ptr %slot49, align 8
  %v263 = load i64, ptr %slot49, align 8
  %v264 = load i64, ptr %slot46, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v263, i64 %v264) nomerge, !dbg !116
  br label %bb_rcslotdone45
bb_rcslotowner45:
  %v265 = load i64, ptr %slot25, align 8
  store i64 %v265, ptr %slot50, align 8
  %v266 = load i64, ptr %slot50, align 8
  %v267 = load i64, ptr %slot46, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v266, i64 %v267) nomerge, !dbg !116
  br label %bb_rcslotdone45
bb_rcslotdone45:
  %v268 = load i64, ptr %slot14, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot51, align 8
  %v271 = load i64, ptr %slot51, align 8
  %op272 = add i64 %v271, 32
  store i64 %op272, ptr %slot52, align 8
  %v273 = load i64, ptr %slot16, align 8
  store i64 %v273, ptr %slot53, align 8
  %v274 = load i64, ptr %slot53, align 8
  %v275 = load i64, ptr %slot52, align 8
  %p276 = inttoptr i64 %v274 to ptr
  %p277 = inttoptr i64 %v275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p277, ptr %p276, i64 208, i1 false), !alias.scope !10000000
  %v278 = load i64, ptr %slot53, align 8
  %p279 = inttoptr i64 %v278 to ptr
  call void @llvm.memset.p0.i64(ptr %p279, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v280 = load i64, ptr %slot6, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 0, ptr %p281, align 4, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot17, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 0, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot17, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i64 0, ptr %p285, align 8, !alias.scope !3, !noalias !4
  %v286 = load i64, ptr %slot20, align 8
  store i64 %v286, ptr %slot54, align 8
  %v287 = load i64, ptr %slot54, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i64 0, ptr %p288, align 8, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot54, align 8
  %p291 = inttoptr i64 %v289 to ptr
  %gep292 = getelementptr i8, ptr %p291, i64 8
  %op290 = ptrtoint ptr %gep292 to i64
  store i64 %op290, ptr %slot55, align 8
  %v293 = load i64, ptr %slot55, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 0, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot54, align 8
  %p297 = inttoptr i64 %v295 to ptr
  %gep298 = getelementptr i8, ptr %p297, i64 16
  %op296 = ptrtoint ptr %gep298 to i64
  store i64 %op296, ptr %slot56, align 8
  %v299 = load i64, ptr %slot56, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 0, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot54, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i32 0, ptr %p302, align 4, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot11, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i32 1, ptr %p304, align 4, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot17, align 8
  store i64 %v305, ptr %slot57, align 8
  %v306 = load i64, ptr %slot54, align 8
  %p308 = inttoptr i64 %v306 to ptr
  %gep309 = getelementptr i8, ptr %p308, i64 8
  %op307 = ptrtoint ptr %gep309 to i64
  store i64 %op307, ptr %slot58, align 8
  %v310 = load i64, ptr %slot26, align 8
  store i64 %v310, ptr %slot59, align 8
  store i64 0, ptr %slot60, align 8
  %v311 = load i64, ptr %slot54, align 8
  %v312 = load i64, ptr %slot17, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i64 %v311, ptr %p313, align 8, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot17, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot61, align 8
  %v317 = load i64, ptr %slot12, align 8
  store i64 %v317, ptr %slot62, align 8
  %v318 = load i64, ptr %slot61, align 8
  %v319 = load i64, ptr %slot62, align 8
  %p320 = inttoptr i64 %v318 to ptr
  %p321 = inttoptr i64 %v319 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p321, ptr %p320, i64 24, i1 false)
  %v322 = load i64, ptr %slot9, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i32 2, ptr %p323, align 4, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot8, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i32 1, ptr %p325, align 4, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot62, align 8
  %v327 = load i64, ptr %slot17, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot17, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot63, align 8
  %v332 = load i64, ptr %slot17, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i64, ptr %p333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld334, ptr %slot64, align 8
  %v335 = load i64, ptr %slot13, align 8
  store i64 %v335, ptr %slot65, align 8
  %v336 = load i64, ptr %slot26, align 8
  store i64 %v336, ptr %slot66, align 8
  %v337 = load i64, ptr %slot25, align 8
  %v338 = load i64, ptr %slot65, align 8
  %v339 = load i64, ptr %slot64, align 8
  %v340 = load i64, ptr %slot66, align 8
  %cv341 = trunc i64 %v340 to i32
  %call342 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v337, i64 %v338, i64 %v339, i32 %cv341) nomerge, !dbg !120
  store i32 %call342, ptr %slot67, align 8
  %v343 = load i32, ptr %slot67, align 8
  %cv344 = zext i32 %v343 to i64
  %cond345 = icmp ne i64 %cv344, 0
  br i1 %cond345, label %bb_rcsuccess74, label %bb_rcfailure74
bb_rcfailure74:
  %v346 = load i64, ptr %slot25, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %call348 = call i32 @myl_rc_take_failure(ptr %p347) nomerge, !dbg !120
  store i32 %call348, ptr %slot68, align 8
  %v349 = load i64, ptr %slot1, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %v351 = load i32, ptr %slot68, align 8
  %call352 = call i32 @myl_qbe_rc_status(ptr %p350, i32 %v351) nomerge, !dbg !120
  store i32 %call352, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess74:
  %v353 = load i64, ptr %slot8, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i32 0, ptr %p354, align 4, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot10, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i32 1, ptr %p356, align 4, !alias.scope !3, !noalias !4
  %v357 = load i64, ptr %slot13, align 8
  store i64 %v357, ptr %slot70, align 8
  %v358 = load i64, ptr %slot10, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i32 0, ptr %p359, align 4, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot8, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i32, ptr %p361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld362, ptr %slot71, align 8
  %v363 = load i32, ptr %slot71, align 8
  %cv364 = zext i32 %v363 to i64
  %cond365 = icmp ne i64 %cv364, 0
  br i1 %cond365, label %bb_rcslotdrop84, label %bb_rcslotdone84
bb_rcslotdrop84:
  %v366 = load i64, ptr %slot8, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i32 0, ptr %p367, align 4, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot12, align 8
  store i64 %v368, ptr %slot72, align 8
  %v369 = load i64, ptr %slot9, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i32, ptr %p370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld371, ptr %slot73, align 8
  %v372 = load i32, ptr %slot73, align 8
  %op373 = and i32 %v372, 28
  store i32 %op373, ptr %slot74, align 8
  %v374 = load i32, ptr %slot74, align 8
  %cv375 = zext i32 %v374 to i64
  %cond376 = icmp ne i64 %cv375, 0
  br i1 %cond376, label %bb_rcslotrole84, label %bb_rcslotowner84
bb_rcslotrole84:
  %v377 = load i64, ptr %slot25, align 8
  store i64 %v377, ptr %slot75, align 8
  %v378 = load i64, ptr %slot75, align 8
  %v379 = load i64, ptr %slot72, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v378, i64 %v379) nomerge, !dbg !120
  br label %bb_rcslotdone84
bb_rcslotowner84:
  %v380 = load i64, ptr %slot25, align 8
  store i64 %v380, ptr %slot76, align 8
  %v381 = load i64, ptr %slot76, align 8
  %v382 = load i64, ptr %slot72, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v381, i64 %v382) nomerge, !dbg !120
  br label %bb_rcslotdone84
bb_rcslotdone84:
  %v383 = load i64, ptr %slot6, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i32, ptr %p384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld385, ptr %slot77, align 8
  %v386 = load i32, ptr %slot77, align 8
  %cv387 = zext i32 %v386 to i64
  %cond388 = icmp ne i64 %cv387, 0
  br i1 %cond388, label %bb_rcslotdrop111, label %bb_rcslotdone111
bb_rcslotdrop111:
  %v389 = load i64, ptr %slot6, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i32 0, ptr %p390, align 4, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot16, align 8
  store i64 %v391, ptr %slot78, align 8
  %v392 = load i64, ptr %slot7, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i32, ptr %p393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld394, ptr %slot79, align 8
  %v395 = load i32, ptr %slot79, align 8
  %op396 = and i32 %v395, 28
  store i32 %op396, ptr %slot80, align 8
  %v397 = load i32, ptr %slot80, align 8
  %cv398 = zext i32 %v397 to i64
  %cond399 = icmp ne i64 %cv398, 0
  br i1 %cond399, label %bb_rcslotrole111, label %bb_rcslotowner111
bb_rcslotrole111:
  %v400 = load i64, ptr %slot25, align 8
  store i64 %v400, ptr %slot81, align 8
  %v401 = load i64, ptr %slot81, align 8
  %v402 = load i64, ptr %slot78, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v401, i64 %v402) nomerge, !dbg !120
  br label %bb_rcslotdone111
bb_rcslotowner111:
  %v403 = load i64, ptr %slot25, align 8
  store i64 %v403, ptr %slot82, align 8
  %v404 = load i64, ptr %slot82, align 8
  %v405 = load i64, ptr %slot78, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v404, i64 %v405) nomerge, !dbg !120
  br label %bb_rcslotdone111
bb_rcslotdone111:
  %v406 = load i64, ptr %slot70, align 8
  %p407 = inttoptr i64 %v406 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p407, i64 24, i1 false)
  ret void
bb_failure:
  %v408 = load i64, ptr %slot5, align 8
  %p409 = inttoptr i64 %v408 to ptr
  call void @llvm.memset.p0.i64(ptr %p409, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v410 = load i64, ptr %slot5, align 8
  %p411 = inttoptr i64 %v410 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p411, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v412 = load i64, ptr %slot5, align 8
  %p413 = inttoptr i64 %v412 to ptr
  call void @llvm.memset.p0.i64(ptr %p413, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v414 = load i64, ptr %slot5, align 8
  %p415 = inttoptr i64 %v414 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p415, i64 24, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0", linkageName: "myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11332108188994593798, i64 0, !"myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!118 = !DILocation(line: 20, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!120 = !DILocation(line: 25, column: 0, scope: !121)
