target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v80 = load i64, ptr %slot1, align 8
  %op81 = add i64 %v80, 32
  store i64 %op81, ptr %slot3, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot4, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot5, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot6, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot7, align 8
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot8, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot9, align 8
  %mem94 = alloca i8, i64 392, align 8
  %ptr95 = ptrtoint ptr %mem94 to i64
  store i64 %ptr95, ptr %slot10, align 8
  %mem96 = alloca i8, i64 8, align 8
  %ptr97 = ptrtoint ptr %mem96 to i64
  store i64 %ptr97, ptr %slot11, align 8
  %mem98 = alloca i8, i64 8, align 8
  %ptr99 = ptrtoint ptr %mem98 to i64
  store i64 %ptr99, ptr %slot12, align 8
  %mem100 = alloca i8, i64 8, align 8
  %ptr101 = ptrtoint ptr %mem100 to i64
  store i64 %ptr101, ptr %slot13, align 8
  %mem102 = alloca i8, i64 8, align 8
  %ptr103 = ptrtoint ptr %mem102 to i64
  store i64 %ptr103, ptr %slot14, align 8
  %mem104 = alloca i8, i64 392, align 8
  %ptr105 = ptrtoint ptr %mem104 to i64
  store i64 %ptr105, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem106 = alloca i8, i64 8, align 8
  %ptr107 = ptrtoint ptr %mem106 to i64
  store i64 %ptr107, ptr %slot16, align 8
  %v108 = load i64, ptr %slot1, align 8
  %op109 = add i64 %v108, 64
  store i64 %op109, ptr %slot17, align 8
  %v110 = load i64, ptr %slot17, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !4, !noalias !3
  store i64 %ld112, ptr %slot18, align 8
  %stack113 = call ptr @llvm.stacksave()
  %stackaddr114 = ptrtoint ptr %stack113 to i64
  %v115 = load i64, ptr %slot18, align 8
  %cmp116 = icmp ult i64 %stackaddr114, %v115
  %cv117 = zext i1 %cmp116 to i64
  store i64 %cv117, ptr %slot19, align 8
  %v118 = load i64, ptr %slot19, align 8
  %cond119 = icmp ne i64 %v118, 0
  br i1 %cond119, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v120 = load i64, ptr %slot1, align 8
  %p121 = inttoptr i64 %v120 to ptr
  call void @myl_qbe_fail_frame(ptr %p121) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v122 = load i64, ptr %slot2, align 8
  %v123 = load i64, ptr %slot11, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i64 %v122, ptr %p124, align 8, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot1, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %call127 = call ptr @myl_qbe_heap(ptr %p126) nomerge, !dbg !112
  %calladdr128 = ptrtoint ptr %call127 to i64
  store i64 %calladdr128, ptr %slot20, align 8
  %v129 = load i64, ptr %slot4, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i32 0, ptr %p130, align 4, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot5, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i32 0, ptr %p132, align 4, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i32 0, ptr %p134, align 4, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot7, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i32 0, ptr %p136, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v137 = load i64, ptr %slot11, align 8
  %p138 = inttoptr i64 %v137 to ptr
  %ld139 = load i64, ptr %p138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld139, ptr %slot21, align 8
  %v140 = load i64, ptr %slot21, align 8
  %v141 = load i64, ptr %slot13, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 %v140, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %p143 = inttoptr i64 ptrtoint (ptr @myl_lit_3ad41f5b757367ccf6306958a53d26e1cc53e8597f73caeedb438aeafefbc700 to i64) to ptr
  %ld144 = load i64, ptr %p143, align 8, !alias.scope !4, !noalias !3
  store i64 %ld144, ptr %slot22, align 8
  %v145 = load i64, ptr %slot22, align 8
  %v146 = load i64, ptr %slot14, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i64 %v145, ptr %p147, align 8, !alias.scope !3, !noalias !4
  %v148 = load i64, ptr %slot14, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ld150 = load i64, ptr %p149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld150, ptr %slot23, align 8
  %v151 = load i64, ptr %slot23, align 8
  %v152 = load i64, ptr %slot9, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot9, align 8
  store i64 %v154, ptr %slot24, align 8
  %v155 = load i64, ptr %slot10, align 8
  store i64 %v155, ptr %slot25, align 8
  %v156 = load i64, ptr %slot24, align 8
  %v157 = load i64, ptr %slot25, align 8
  %p158 = inttoptr i64 %v156 to ptr
  %p159 = inttoptr i64 %v157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p159, ptr %p158, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot7, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i32 2, ptr %p161, align 4, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot6, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i32 1, ptr %p163, align 4, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot8, align 8
  store i64 %v164, ptr %slot26, align 8
  %v165 = load i64, ptr %slot10, align 8
  store i64 %v165, ptr %slot27, align 8
  %v166 = load i64, ptr %slot27, align 8
  %v167 = load i64, ptr %slot26, align 8
  %p168 = inttoptr i64 %v166 to ptr
  %p169 = inttoptr i64 %v167 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p169, ptr %p168, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot5, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 2, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i32, ptr %p173, align 4, !alias.scope !3, !noalias !4
  store i32 %ld174, ptr %slot28, align 8
  %v175 = load i32, ptr %slot28, align 8
  %v176 = load i64, ptr %slot5, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 %v175, ptr %p177, align 4, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot6, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i32 0, ptr %p179, align 4, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot4, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i32 1, ptr %p181, align 4, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot26, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot29, align 8
  %v185 = load i64, ptr %slot29, align 8
  %v186 = load i64, ptr %slot14, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot13, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot30, align 8
  %v191 = load i64, ptr %slot14, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot31, align 8
  %v194 = load i64, ptr %slot1, align 8
  %v195 = load i64, ptr %slot30, align 8
  %v196 = load i64, ptr %slot31, align 8
  %call197 = call i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64 %v194, i64 %v195, i64 %v196) nomerge, !dbg !114
  store i64 %call197, ptr %slot32, align 8
  %v198 = load i64, ptr %slot32, align 8
  %v199 = load i64, ptr %slot13, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot4, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i32, ptr %p202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld203, ptr %slot33, align 8
  %v204 = load i32, ptr %slot33, align 8
  %cv205 = zext i32 %v204 to i64
  %cond206 = icmp ne i64 %cv205, 0
  br i1 %cond206, label %bb_rcslotdrop39, label %bb_rcslotdone39
bb_rcslotdrop39:
  %v207 = load i64, ptr %slot4, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i32 0, ptr %p208, align 4, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot8, align 8
  store i64 %v209, ptr %slot34, align 8
  %v210 = load i64, ptr %slot5, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i32, ptr %p211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld212, ptr %slot35, align 8
  %v213 = load i32, ptr %slot35, align 8
  %op214 = and i32 %v213, 28
  store i32 %op214, ptr %slot36, align 8
  %v215 = load i32, ptr %slot36, align 8
  %cv216 = zext i32 %v215 to i64
  %cond217 = icmp ne i64 %cv216, 0
  br i1 %cond217, label %bb_rcslotrole39, label %bb_rcslotowner39
bb_rcslotrole39:
  %v218 = load i64, ptr %slot20, align 8
  store i64 %v218, ptr %slot37, align 8
  %v219 = load i64, ptr %slot34, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot38, align 8
  %v222 = load i64, ptr %slot38, align 8
  %cmp223 = icmp ne i64 %v222, 0
  %cv224 = zext i1 %cmp223 to i32
  store i32 %cv224, ptr %slot39, align 8
  %v225 = load i32, ptr %slot39, align 8
  %cv226 = zext i32 %v225 to i64
  %cond227 = icmp ne i64 %cv226, 0
  br i1 %cond227, label %bb_rcgnn55, label %bb_rcgdone55
bb_rcgnn55:
  %v228 = load i64, ptr %slot38, align 8
  %op229 = sub i64 %v228, 16
  store i64 %op229, ptr %slot40, align 8
  %v230 = load i64, ptr %slot38, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %rgep232 = getelementptr i8, ptr %p231, i64 -16
  %ld233 = load i64, ptr %rgep232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld233, ptr %slot41, align 8
  %v234 = load i64, ptr %slot41, align 8
  %op235 = and i64 %v234, 4611686018427387906
  store i64 %op235, ptr %slot42, align 8
  %v236 = load i64, ptr %slot42, align 8
  %cmp237 = icmp ne i64 %v236, 0
  %cv238 = zext i1 %cmp237 to i32
  store i32 %cv238, ptr %slot43, align 8
  %v239 = load i32, ptr %slot43, align 8
  %cv240 = zext i32 %v239 to i64
  %cond241 = icmp ne i64 %cv240, 0
  br i1 %cond241, label %bb_rcgclear55, label %bb_rcgcounted55
bb_rcgcounted55:
  %v242 = load i64, ptr %slot38, align 8
  %op243 = sub i64 %v242, 24
  store i64 %op243, ptr %slot44, align 8
  %v244 = load i64, ptr %slot38, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %rgep246 = getelementptr i8, ptr %p245, i64 -24
  %ld247 = load i64, ptr %rgep246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld247, ptr %slot45, align 8
  %v248 = load i64, ptr %slot45, align 8
  %op249 = sub i64 %v248, 1
  store i64 %op249, ptr %slot46, align 8
  %v250 = load i64, ptr %slot46, align 8
  %cmp251 = icmp eq i64 %v250, 0
  %cv252 = zext i1 %cmp251 to i32
  store i32 %cv252, ptr %slot47, align 8
  %v253 = load i32, ptr %slot47, align 8
  %cv254 = zext i32 %v253 to i64
  %cond255 = icmp ne i64 %cv254, 0
  br i1 %cond255, label %bb_rcglast55, label %bb_rcgdec55
bb_rcglast55:
  %v256 = load i64, ptr %slot38, align 8
  %op257 = sub i64 %v256, 32
  store i64 %op257, ptr %slot48, align 8
  %v258 = load i64, ptr %slot38, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %rgep260 = getelementptr i8, ptr %p259, i64 -32
  %ld261 = load i64, ptr %rgep260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld261, ptr %slot49, align 8
  %v262 = load i64, ptr %slot49, align 8
  %cmp263 = icmp ne i64 %v262, 0
  %cv264 = zext i1 %cmp263 to i32
  store i32 %cv264, ptr %slot50, align 8
  %v265 = load i32, ptr %slot50, align 8
  %cv266 = zext i32 %v265 to i64
  %cond267 = icmp ne i64 %cv266, 0
  br i1 %cond267, label %bb_rcgdec55, label %bb_rcgslow55
bb_rcgslow55:
  %v268 = load i64, ptr %slot37, align 8
  %v269 = load i64, ptr %slot34, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v268, i64 %v269) nomerge, !dbg !114
  br label %bb_rcgdone55
bb_rcgdec55:
  %v270 = load i64, ptr %slot46, align 8
  %v271 = load i64, ptr %slot38, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %rgep273 = getelementptr i8, ptr %p272, i64 -24
  store i64 %v270, ptr %rgep273, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear55
bb_rcgclear55:
  %v274 = load i64, ptr %slot34, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 0, ptr %p275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone55
bb_rcgdone55:
  br label %bb_rcslotdone39
bb_rcslotowner39:
  %v276 = load i64, ptr %slot20, align 8
  store i64 %v276, ptr %slot51, align 8
  %v277 = load i64, ptr %slot34, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot52, align 8
  %v280 = load i64, ptr %slot52, align 8
  %cmp281 = icmp ne i64 %v280, 0
  %cv282 = zext i1 %cmp281 to i32
  store i32 %cv282, ptr %slot53, align 8
  %v283 = load i32, ptr %slot53, align 8
  %cv284 = zext i32 %v283 to i64
  %cond285 = icmp ne i64 %cv284, 0
  br i1 %cond285, label %bb_rcgnn70, label %bb_rcgdone70
bb_rcgnn70:
  %v286 = load i64, ptr %slot52, align 8
  %op287 = sub i64 %v286, 16
  store i64 %op287, ptr %slot54, align 8
  %v288 = load i64, ptr %slot52, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %rgep290 = getelementptr i8, ptr %p289, i64 -16
  %ld291 = load i64, ptr %rgep290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld291, ptr %slot55, align 8
  %v292 = load i64, ptr %slot55, align 8
  %op293 = and i64 %v292, 4611686018427387906
  store i64 %op293, ptr %slot56, align 8
  %v294 = load i64, ptr %slot56, align 8
  %cmp295 = icmp ne i64 %v294, 0
  %cv296 = zext i1 %cmp295 to i32
  store i32 %cv296, ptr %slot57, align 8
  %v297 = load i32, ptr %slot57, align 8
  %cv298 = zext i32 %v297 to i64
  %cond299 = icmp ne i64 %cv298, 0
  br i1 %cond299, label %bb_rcgclear70, label %bb_rcgcounted70
bb_rcgcounted70:
  %v300 = load i64, ptr %slot52, align 8
  %op301 = sub i64 %v300, 32
  store i64 %op301, ptr %slot58, align 8
  %v302 = load i64, ptr %slot52, align 8
  %p303 = inttoptr i64 %v302 to ptr
  %rgep304 = getelementptr i8, ptr %p303, i64 -32
  %ld305 = load i64, ptr %rgep304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld305, ptr %slot59, align 8
  %v306 = load i64, ptr %slot59, align 8
  %op307 = sub i64 %v306, 1
  store i64 %op307, ptr %slot60, align 8
  %v308 = load i64, ptr %slot60, align 8
  %cmp309 = icmp eq i64 %v308, 0
  %cv310 = zext i1 %cmp309 to i32
  store i32 %cv310, ptr %slot61, align 8
  %v311 = load i32, ptr %slot61, align 8
  %cv312 = zext i32 %v311 to i64
  %cond313 = icmp ne i64 %cv312, 0
  br i1 %cond313, label %bb_rcglast70, label %bb_rcgdec70
bb_rcglast70:
  %v314 = load i64, ptr %slot52, align 8
  %op315 = sub i64 %v314, 24
  store i64 %op315, ptr %slot62, align 8
  %v316 = load i64, ptr %slot52, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %rgep318 = getelementptr i8, ptr %p317, i64 -24
  %ld319 = load i64, ptr %rgep318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld319, ptr %slot63, align 8
  %v320 = load i64, ptr %slot63, align 8
  %cmp321 = icmp ne i64 %v320, 0
  %cv322 = zext i1 %cmp321 to i32
  store i32 %cv322, ptr %slot64, align 8
  %v323 = load i32, ptr %slot64, align 8
  %cv324 = zext i32 %v323 to i64
  %cond325 = icmp ne i64 %cv324, 0
  br i1 %cond325, label %bb_rcgdec70, label %bb_rcgslow70
bb_rcgslow70:
  %v326 = load i64, ptr %slot51, align 8
  %v327 = load i64, ptr %slot34, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v326, i64 %v327) nomerge, !dbg !114
  br label %bb_rcgdone70
bb_rcgdec70:
  %v328 = load i64, ptr %slot60, align 8
  %v329 = load i64, ptr %slot52, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %rgep331 = getelementptr i8, ptr %p330, i64 -32
  store i64 %v328, ptr %rgep331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear70
bb_rcgclear70:
  %v332 = load i64, ptr %slot34, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 0, ptr %p333, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone70
bb_rcgdone70:
  br label %bb_rcslotdone39
bb_rcslotdone39:
  %v334 = load i64, ptr %slot13, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot65, align 8
  %v337 = load i64, ptr %slot65, align 8
  %v338 = load i64, ptr %slot12, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i64 %v337, ptr %p339, align 8, !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot11, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld342, ptr %slot66, align 8
  %v343 = load i64, ptr %slot66, align 8
  %v344 = load i64, ptr %slot13, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i64 %v343, ptr %p345, align 8, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot13, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld348, ptr %slot67, align 8
  %v349 = load i64, ptr %slot1, align 8
  %v350 = load i64, ptr %slot67, align 8
  %call351 = call i64 @myl_f_fda9a293642c453fac79f8b6d7f75b135405e246ae3c1aab4c49816401b1323d(i64 %v349, i64 %v350) nomerge, !dbg !116
  store i64 %call351, ptr %slot68, align 8
  %v352 = load i64, ptr %slot68, align 8
  %v353 = load i64, ptr %slot13, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 %v352, ptr %p354, align 8, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot11, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot69, align 8
  %v358 = load i64, ptr %slot69, align 8
  %v359 = load i64, ptr %slot13, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot15, align 8
  store i64 %v361, ptr %slot70, align 8
  %v362 = load i64, ptr %slot70, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i32 0, ptr %p363, align 4, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot70, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i32 0, ptr %p365, align 4, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot70, align 8
  %v367 = load i64, ptr %slot14, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i64 %v366, ptr %p368, align 8, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot13, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot71, align 8
  %v372 = load i64, ptr %slot14, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot72, align 8
  %v375 = load i64, ptr %slot1, align 8
  %v376 = load i64, ptr %slot71, align 8
  %v377 = load i64, ptr %slot72, align 8
  %call378 = call i64 @myl_f_bb6814a1264fadd2b0a3de12ef2b6f56e36ce4ae661e2bcddce13df25b413f46(i64 %v375, i64 %v376, i64 %v377) nomerge, !dbg !118
  store i64 %call378, ptr %slot73, align 8
  %v379 = load i64, ptr %slot73, align 8
  %v380 = load i64, ptr %slot13, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 %v379, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot11, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot74, align 8
  %v385 = load i64, ptr %slot74, align 8
  %v386 = load i64, ptr %slot13, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot12, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot75, align 8
  %v391 = load i64, ptr %slot75, align 8
  %v392 = load i64, ptr %slot14, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 %v391, ptr %p393, align 8, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot13, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot76, align 8
  %v397 = load i64, ptr %slot14, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot77, align 8
  %v400 = load i64, ptr %slot1, align 8
  %v401 = load i64, ptr %slot76, align 8
  %v402 = load i64, ptr %slot77, align 8
  %call403 = call i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64 %v400, i64 %v401, i64 %v402) nomerge, !dbg !120
  store i64 %call403, ptr %slot78, align 8
  %v404 = load i64, ptr %slot78, align 8
  %v405 = load i64, ptr %slot13, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot13, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 0, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot13, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i64, ptr %p410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot79, align 8
  %v412 = load i64, ptr %slot79, align 8
  ret i64 %v412
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_3ad41f5b757367ccf6306958a53d26e1cc53e8597f73caeedb438aeafefbc700 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64, i64, i64)
declare i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64, i64, i64)
declare i64 @myl_f_bb6814a1264fadd2b0a3de12ef2b6f56e36ce4ae661e2bcddce13df25b413f46(i64, i64, i64)
declare i64 @myl_f_fda9a293642c453fac79f8b6d7f75b135405e246ae3c1aab4c49816401b1323d(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b", linkageName: "myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3524428484386786496, i64 0, !"myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
