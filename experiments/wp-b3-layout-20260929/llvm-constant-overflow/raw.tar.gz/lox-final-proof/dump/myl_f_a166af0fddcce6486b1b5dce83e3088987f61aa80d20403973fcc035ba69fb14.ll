target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a166af0fddcce6486b1b5dce83e3088987f61aa80d20403973fcc035ba69fb14(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %callresult57 = alloca [24 x i8], align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v306 = load i64, ptr %slot1, align 8
  %op307 = add i64 %v306, 32
  store i64 %op307, ptr %slot5, align 8
  %mem308 = alloca i8, i64 8, align 8
  %ptr309 = ptrtoint ptr %mem308 to i64
  store i64 %ptr309, ptr %slot6, align 8
  %mem310 = alloca i8, i64 8, align 8
  %ptr311 = ptrtoint ptr %mem310 to i64
  store i64 %ptr311, ptr %slot7, align 8
  %mem312 = alloca i8, i64 8, align 8
  %ptr313 = ptrtoint ptr %mem312 to i64
  store i64 %ptr313, ptr %slot8, align 8
  %mem314 = alloca i8, i64 8, align 8
  %ptr315 = ptrtoint ptr %mem314 to i64
  store i64 %ptr315, ptr %slot9, align 8
  %mem316 = alloca i8, i64 8, align 8
  %ptr317 = ptrtoint ptr %mem316 to i64
  store i64 %ptr317, ptr %slot10, align 8
  %mem318 = alloca i8, i64 8, align 8
  %ptr319 = ptrtoint ptr %mem318 to i64
  store i64 %ptr319, ptr %slot11, align 8
  %mem320 = alloca i8, i64 208, align 8
  %ptr321 = ptrtoint ptr %mem320 to i64
  store i64 %ptr321, ptr %slot12, align 8
  %mem322 = alloca i8, i64 208, align 8
  %ptr323 = ptrtoint ptr %mem322 to i64
  store i64 %ptr323, ptr %slot13, align 8
  %mem324 = alloca i8, i64 8, align 8
  %ptr325 = ptrtoint ptr %mem324 to i64
  store i64 %ptr325, ptr %slot14, align 8
  %mem326 = alloca i8, i64 8, align 8
  %ptr327 = ptrtoint ptr %mem326 to i64
  store i64 %ptr327, ptr %slot15, align 8
  %mem328 = alloca i8, i64 208, align 8
  %ptr329 = ptrtoint ptr %mem328 to i64
  store i64 %ptr329, ptr %slot16, align 8
  %mem330 = alloca i8, i64 8, align 8
  %ptr331 = ptrtoint ptr %mem330 to i64
  store i64 %ptr331, ptr %slot17, align 8
  %mem332 = alloca i8, i64 8, align 8
  %ptr333 = ptrtoint ptr %mem332 to i64
  store i64 %ptr333, ptr %slot18, align 8
  %mem334 = alloca i8, i64 8, align 8
  %ptr335 = ptrtoint ptr %mem334 to i64
  store i64 %ptr335, ptr %slot19, align 8
  %mem336 = alloca i8, i64 8, align 8
  %ptr337 = ptrtoint ptr %mem336 to i64
  store i64 %ptr337, ptr %slot20, align 8
  %mem338 = alloca i8, i64 16, align 8
  %ptr339 = ptrtoint ptr %mem338 to i64
  store i64 %ptr339, ptr %slot21, align 8
  %mem340 = alloca i8, i64 8, align 8
  %ptr341 = ptrtoint ptr %mem340 to i64
  store i64 %ptr341, ptr %slot22, align 8
  %mem342 = alloca i8, i64 8, align 8
  %ptr343 = ptrtoint ptr %mem342 to i64
  store i64 %ptr343, ptr %slot23, align 8
  %mem344 = alloca i8, i64 8, align 8
  %ptr345 = ptrtoint ptr %mem344 to i64
  store i64 %ptr345, ptr %slot24, align 8
  %mem346 = alloca i8, i64 8, align 8
  %ptr347 = ptrtoint ptr %mem346 to i64
  store i64 %ptr347, ptr %slot25, align 8
  %mem348 = alloca i8, i64 8, align 8
  %ptr349 = ptrtoint ptr %mem348 to i64
  store i64 %ptr349, ptr %slot26, align 8
  %mem350 = alloca i8, i64 208, align 8
  %ptr351 = ptrtoint ptr %mem350 to i64
  store i64 %ptr351, ptr %slot27, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem352 = alloca i8, i64 8, align 8
  %ptr353 = ptrtoint ptr %mem352 to i64
  store i64 %ptr353, ptr %slot28, align 8
  %v354 = load i64, ptr %slot1, align 8
  %op355 = add i64 %v354, 64
  store i64 %op355, ptr %slot29, align 8
  %v356 = load i64, ptr %slot29, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !4, !noalias !3
  store i64 %ld358, ptr %slot30, align 8
  %stack359 = call ptr @llvm.stacksave()
  %stackaddr360 = ptrtoint ptr %stack359 to i64
  %v361 = load i64, ptr %slot30, align 8
  %cmp362 = icmp ult i64 %stackaddr360, %v361
  %cv363 = zext i1 %cmp362 to i64
  store i64 %cv363, ptr %slot31, align 8
  %v364 = load i64, ptr %slot31, align 8
  %cond365 = icmp ne i64 %v364, 0
  br i1 %cond365, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v366 = load i64, ptr %slot1, align 8
  %p367 = inttoptr i64 %v366 to ptr
  call void @myl_qbe_fail_frame(ptr %p367) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v368 = load i64, ptr %slot2, align 8
  %v369 = load i64, ptr %slot17, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot3, align 8
  %v372 = load i64, ptr %slot18, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 %v371, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot4, align 8
  %v375 = load i64, ptr %slot19, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot1, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %call379 = call ptr @myl_qbe_heap(ptr %p378) nomerge, !dbg !112
  %calladdr380 = ptrtoint ptr %call379 to i64
  store i64 %calladdr380, ptr %slot32, align 8
  %v381 = load i64, ptr %slot1, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %call383 = call i64 @myl_qbe_region_mark(ptr %p382) nomerge, !dbg !112
  store i64 %call383, ptr %slot33, align 8
  %v384 = load i64, ptr %slot6, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i32 0, ptr %p385, align 4, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot7, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 0, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot8, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i32 0, ptr %p389, align 4, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot9, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i32 0, ptr %p391, align 4, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot10, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i32 0, ptr %p393, align 4, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot11, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i32 0, ptr %p395, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v396 = load i64, ptr %slot19, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot34, align 8
  %v399 = load i64, ptr %slot34, align 8
  %v400 = load i64, ptr %slot22, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot22, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot35, align 8
  %v405 = load i64, ptr %slot1, align 8
  %v406 = load i64, ptr %slot35, align 8
  %call407 = call i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64 %v405, i64 %v406) nomerge, !dbg !114
  store i64 %call407, ptr %slot36, align 8
  %v408 = load i64, ptr %slot36, align 8
  %v409 = load i64, ptr %slot22, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i64 %v408, ptr %p410, align 8, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot22, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot37, align 8
  %v414 = load i64, ptr %slot37, align 8
  %v415 = load i64, ptr %slot20, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot17, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot38, align 8
  %v420 = load i64, ptr %slot38, align 8
  %v421 = load i64, ptr %slot22, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot22, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot39, align 8
  %v426 = load i64, ptr %slot39, align 8
  %op427 = add i64 %v426, 48
  store i64 %op427, ptr %slot40, align 8
  %v428 = load i64, ptr %slot40, align 8
  %v429 = load i64, ptr %slot22, align 8
  %p430 = inttoptr i64 %v429 to ptr
  store i64 %v428, ptr %p430, align 8, !alias.scope !3, !noalias !4
  %v431 = load i64, ptr %slot20, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i64, ptr %p432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld433, ptr %slot41, align 8
  %v434 = load i64, ptr %slot41, align 8
  %v435 = load i64, ptr %slot23, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i64 %v434, ptr %p436, align 8, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot17, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld439, ptr %slot42, align 8
  %v440 = load i64, ptr %slot42, align 8
  %v441 = load i64, ptr %slot24, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 %v440, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot20, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot43, align 8
  %v446 = load i64, ptr %slot43, align 8
  %v447 = load i64, ptr %slot25, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 %v446, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot24, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot44, align 8
  %v452 = load i64, ptr %slot25, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot45, align 8
  %v455 = load i64, ptr %slot1, align 8
  %v456 = load i64, ptr %slot44, align 8
  %v457 = load i64, ptr %slot45, align 8
  %call458 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v455, i64 %v456, i64 %v457) nomerge, !dbg !116
  store i64 %call458, ptr %slot46, align 8
  %v459 = load i64, ptr %slot46, align 8
  %v460 = load i64, ptr %slot24, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 %v459, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot6, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i32, ptr %p463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld464, ptr %slot47, align 8
  %v465 = load i32, ptr %slot47, align 8
  %cv466 = zext i32 %v465 to i64
  %cond467 = icmp ne i64 %cv466, 0
  br i1 %cond467, label %bb_rcslotdrop43, label %bb_rcslotdone43
bb_rcslotdrop43:
  %v468 = load i64, ptr %slot6, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 0, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot12, align 8
  store i64 %v470, ptr %slot48, align 8
  %v471 = load i64, ptr %slot7, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i32, ptr %p472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld473, ptr %slot49, align 8
  %v474 = load i32, ptr %slot49, align 8
  %op475 = and i32 %v474, 28
  store i32 %op475, ptr %slot50, align 8
  %v476 = load i32, ptr %slot50, align 8
  %cv477 = zext i32 %v476 to i64
  %cond478 = icmp ne i64 %cv477, 0
  br i1 %cond478, label %bb_rcslotrole43, label %bb_rcslotowner43
bb_rcslotrole43:
  %v479 = load i64, ptr %slot32, align 8
  store i64 %v479, ptr %slot51, align 8
  %v480 = load i64, ptr %slot51, align 8
  %v481 = load i64, ptr %slot48, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v480, i64 %v481) nomerge, !dbg !116
  br label %bb_rcslotdone43
bb_rcslotowner43:
  %v482 = load i64, ptr %slot32, align 8
  store i64 %v482, ptr %slot52, align 8
  %v483 = load i64, ptr %slot52, align 8
  %v484 = load i64, ptr %slot48, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v483, i64 %v484) nomerge, !dbg !116
  br label %bb_rcslotdone43
bb_rcslotdone43:
  %v485 = load i64, ptr %slot22, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i64, ptr %p486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot53, align 8
  %v488 = load i64, ptr %slot23, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %ld490 = load i64, ptr %p489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld490, ptr %slot54, align 8
  %v491 = load i64, ptr %slot24, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %ld493 = load i64, ptr %p492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld493, ptr %slot55, align 8
  %v494 = load i64, ptr %slot1, align 8
  %v495 = load i64, ptr %slot53, align 8
  %v496 = load i64, ptr %slot54, align 8
  %v497 = load i64, ptr %slot55, align 8
  call void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %callresult57, i64 %v494, i64 %v495, i64 %v496, i64 %v497) nomerge, !dbg !118
  %addr498 = ptrtoint ptr %callresult57 to i64
  store i64 %addr498, ptr %slot56, align 8
  %v499 = load i64, ptr %slot56, align 8
  %v500 = load i64, ptr %slot22, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i64 %v499, ptr %p501, align 8, !alias.scope !3, !noalias !4
  %v502 = load i64, ptr %slot22, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i64, ptr %p503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld504, ptr %slot58, align 8
  %v505 = load i64, ptr %slot58, align 8
  %p506 = inttoptr i64 %v505 to ptr
  %ld507 = load i32, ptr %p506, align 4
  %ext508 = zext i32 %ld507 to i64
  store i64 %ext508, ptr %slot59, align 8
  %v509 = load i64, ptr %slot59, align 8
  %cmp510 = icmp eq i64 %v509, 0
  %cv511 = zext i1 %cmp510 to i64
  store i64 %cv511, ptr %slot60, align 8
  %v512 = load i64, ptr %slot60, align 8
  %cond513 = icmp ne i64 %v512, 0
  br i1 %cond513, label %bb_rcarm65, label %bb_rcarmnext65
bb_rcarm65:
  br label %bb_i17
bb_rcarmnext65:
  %v514 = load i64, ptr %slot59, align 8
  %cmp515 = icmp eq i64 %v514, 1
  %cv516 = zext i1 %cmp515 to i64
  store i64 %cv516, ptr %slot61, align 8
  %v517 = load i64, ptr %slot61, align 8
  %cond518 = icmp ne i64 %v517, 0
  br i1 %cond518, label %bb_rcarm66, label %bb_rcarmnext66
bb_rcarm66:
  %v519 = load i64, ptr %slot16, align 8
  store i64 %v519, ptr %slot62, align 8
  %v520 = load i64, ptr %slot58, align 8
  %op521 = add i64 %v520, 8
  store i64 %op521, ptr %slot63, align 8
  %v522 = load i64, ptr %slot33, align 8
  store i64 %v522, ptr %slot64, align 8
  %v523 = load i64, ptr %slot63, align 8
  %v524 = load i64, ptr %slot62, align 8
  %p525 = inttoptr i64 %v523 to ptr
  %p526 = inttoptr i64 %v524 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p526, ptr %p525, i64 16, i1 false)
  %v527 = load i64, ptr %slot11, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 0, ptr %p528, align 4, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot10, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i32 1, ptr %p530, align 4, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot62, align 8
  %v532 = load i64, ptr %slot21, align 8
  %p533 = inttoptr i64 %v531 to ptr
  %p534 = inttoptr i64 %v532 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p534, ptr %p533, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot10, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i32 0, ptr %p536, align 4, !alias.scope !3, !noalias !4
  br label %bb_i11
bb_rcarmnext66:
  br label %bb_failure
bb_i11:
  %v537 = load i64, ptr %slot17, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i64, ptr %p538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld539, ptr %slot65, align 8
  %v540 = load i64, ptr %slot65, align 8
  %v541 = load i64, ptr %slot22, align 8
  %p542 = inttoptr i64 %v541 to ptr
  store i64 %v540, ptr %p542, align 8, !alias.scope !3, !noalias !4
  %v543 = load i64, ptr %slot21, align 8
  %v544 = load i64, ptr %slot23, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 %v543, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot22, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot66, align 8
  %v549 = load i64, ptr %slot23, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %ld551 = load i64, ptr %p550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld551, ptr %slot67, align 8
  %v552 = load i64, ptr %slot1, align 8
  %v553 = load i64, ptr %slot66, align 8
  %v554 = load i64, ptr %slot67, align 8
  %call555 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v552, i64 %v553, i64 %v554) nomerge, !dbg !120
  store i64 %call555, ptr %slot68, align 8
  %v556 = load i64, ptr %slot68, align 8
  %v557 = load i64, ptr %slot22, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i64 %v556, ptr %p558, align 8, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot22, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i64 1, ptr %p560, align 8, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot22, align 8
  %p562 = inttoptr i64 %v561 to ptr
  %ld563 = load i64, ptr %p562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld563, ptr %slot69, align 8
  %v564 = load i64, ptr %slot69, align 8
  ret i64 %v564
bb_i17:
  %v565 = load i64, ptr %slot17, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i64, ptr %p566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld567, ptr %slot70, align 8
  %v568 = load i64, ptr %slot70, align 8
  %v569 = load i64, ptr %slot22, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 %v568, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot18, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot71, align 8
  %v574 = load i64, ptr %slot71, align 8
  %v575 = load i64, ptr %slot23, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %p577 = inttoptr i64 ptrtoint (ptr @myl_lit_8d47278f5246a959c9cf373236b198659ae1c259b6afd12cadab3d657868cf2b to i64) to ptr
  %ld578 = load i64, ptr %p577, align 8, !alias.scope !4, !noalias !3
  store i64 %ld578, ptr %slot72, align 8
  %v579 = load i64, ptr %slot72, align 8
  %v580 = load i64, ptr %slot24, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 %v579, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot24, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld584, ptr %slot73, align 8
  %v585 = load i64, ptr %slot73, align 8
  %v586 = load i64, ptr %slot14, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i64 %v585, ptr %p587, align 8, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot14, align 8
  store i64 %v588, ptr %slot74, align 8
  %v589 = load i64, ptr %slot16, align 8
  store i64 %v589, ptr %slot75, align 8
  %v590 = load i64, ptr %slot74, align 8
  %v591 = load i64, ptr %slot75, align 8
  %p592 = inttoptr i64 %v590 to ptr
  %p593 = inttoptr i64 %v591 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p593, ptr %p592, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot11, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 2, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot10, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 1, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot12, align 8
  store i64 %v598, ptr %slot76, align 8
  %v599 = load i64, ptr %slot16, align 8
  store i64 %v599, ptr %slot77, align 8
  %v600 = load i64, ptr %slot77, align 8
  %v601 = load i64, ptr %slot76, align 8
  %p602 = inttoptr i64 %v600 to ptr
  %p603 = inttoptr i64 %v601 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p603, ptr %p602, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot7, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 2, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot11, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %ld608 = load i32, ptr %p607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld608, ptr %slot78, align 8
  %v609 = load i32, ptr %slot78, align 8
  %v610 = load i64, ptr %slot7, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i32 %v609, ptr %p611, align 4, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot10, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i32 0, ptr %p613, align 4, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot6, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i32 1, ptr %p615, align 4, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot76, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i64, ptr %p617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld618, ptr %slot79, align 8
  %v619 = load i64, ptr %slot79, align 8
  %v620 = load i64, ptr %slot24, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i64 %v619, ptr %p621, align 8, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot17, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i64, ptr %p623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld624, ptr %slot80, align 8
  %v625 = load i64, ptr %slot80, align 8
  %v626 = load i64, ptr %slot27, align 8
  %p627 = inttoptr i64 %v625 to ptr
  %p628 = inttoptr i64 %v626 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p628, ptr %p627, i64 208, i1 false), !alias.scope !10000000
  %v629 = load i64, ptr %slot27, align 8
  %v630 = load i64, ptr %slot25, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i64 %v629, ptr %p631, align 8, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot20, align 8
  %p633 = inttoptr i64 %v632 to ptr
  %ld634 = load i64, ptr %p633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld634, ptr %slot81, align 8
  %v635 = load i64, ptr %slot81, align 8
  %v636 = load i64, ptr %slot26, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i64 %v635, ptr %p637, align 8, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot25, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i64, ptr %p639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld640, ptr %slot82, align 8
  %v641 = load i64, ptr %slot26, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot83, align 8
  %v644 = load i64, ptr %slot1, align 8
  %v645 = load i64, ptr %slot82, align 8
  %v646 = load i64, ptr %slot83, align 8
  %call647 = call i64 @myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow(i64 %v644, i64 %v645, i64 %v646) nomerge, !dbg !122
  store i64 %call647, ptr %slot84, align 8
  %v648 = load i64, ptr %slot84, align 8
  %v649 = load i64, ptr %slot25, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 %v648, ptr %p650, align 8, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot25, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot85, align 8
  %v654 = load i64, ptr %slot85, align 8
  %v655 = load i64, ptr %slot15, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i64 %v654, ptr %p656, align 8, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot15, align 8
  store i64 %v657, ptr %slot86, align 8
  %v658 = load i64, ptr %slot16, align 8
  store i64 %v658, ptr %slot87, align 8
  %v659 = load i64, ptr %slot86, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %ld661 = load i64, ptr %p660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld661, ptr %slot88, align 8
  %v662 = load i64, ptr %slot88, align 8
  %cmp663 = icmp ne i64 %v662, 0
  %cv664 = zext i1 %cmp663 to i32
  store i32 %cv664, ptr %slot89, align 8
  %v665 = load i32, ptr %slot89, align 8
  %cv666 = zext i32 %v665 to i64
  %cond667 = icmp ne i64 %cv666, 0
  br i1 %cond667, label %bb_rcgnn144, label %bb_rcgstore144
bb_rcgnn144:
  %v668 = load i64, ptr %slot88, align 8
  %op669 = sub i64 %v668, 16
  store i64 %op669, ptr %slot90, align 8
  %v670 = load i64, ptr %slot88, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %rgep672 = getelementptr i8, ptr %p671, i64 -16
  %ld673 = load i64, ptr %rgep672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld673, ptr %slot91, align 8
  %v674 = load i64, ptr %slot91, align 8
  %op675 = and i64 %v674, 4611686018427387906
  store i64 %op675, ptr %slot92, align 8
  %v676 = load i64, ptr %slot92, align 8
  %cmp677 = icmp ne i64 %v676, 0
  %cv678 = zext i1 %cmp677 to i32
  store i32 %cv678, ptr %slot93, align 8
  %v679 = load i32, ptr %slot93, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcgstore144, label %bb_rcginc144
bb_rcginc144:
  %v682 = load i64, ptr %slot88, align 8
  %op683 = sub i64 %v682, 24
  store i64 %op683, ptr %slot94, align 8
  %v684 = load i64, ptr %slot88, align 8
  %p685 = inttoptr i64 %v684 to ptr
  %rgep686 = getelementptr i8, ptr %p685, i64 -24
  %ld687 = load i64, ptr %rgep686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld687, ptr %slot95, align 8
  %v688 = load i64, ptr %slot95, align 8
  %op689 = add i64 %v688, 1
  store i64 %op689, ptr %slot96, align 8
  %v690 = load i64, ptr %slot96, align 8
  %cmp691 = icmp eq i64 %v690, 0
  %cv692 = zext i1 %cmp691 to i32
  store i32 %cv692, ptr %slot97, align 8
  %v693 = load i32, ptr %slot97, align 8
  %cv694 = zext i32 %v693 to i64
  %cond695 = icmp ne i64 %cv694, 0
  br i1 %cond695, label %bb_rcglimit144, label %bb_rcgcapacity144
bb_rcglimit144:
  %v696 = load i64, ptr %slot1, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %call698 = call i32 @myl_qbe_rc_status(ptr %p697, i32 2) nomerge, !dbg !122
  store i32 %call698, ptr %slot98, align 8
  br label %bb_failure
bb_rcgcapacity144:
  %v699 = load i64, ptr %slot96, align 8
  %v700 = load i64, ptr %slot88, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %rgep702 = getelementptr i8, ptr %p701, i64 -24
  store i64 %v699, ptr %rgep702, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore144
bb_rcgstore144:
  %v703 = load i64, ptr %slot88, align 8
  %v704 = load i64, ptr %slot87, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot11, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i32 2, ptr %p707, align 4, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot11, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i32 16, ptr %p709, align 4, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot10, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i32 1, ptr %p711, align 4, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot8, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %ld714 = load i32, ptr %p713, align 4, !alias.scope !3, !noalias !4
  store i32 %ld714, ptr %slot99, align 8
  %v715 = load i32, ptr %slot99, align 8
  %cv716 = zext i32 %v715 to i64
  %cond717 = icmp ne i64 %cv716, 0
  br i1 %cond717, label %bb_rcslotdrop160, label %bb_rcslotdone160
bb_rcslotdrop160:
  %v718 = load i64, ptr %slot8, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i32 0, ptr %p719, align 4, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot13, align 8
  store i64 %v720, ptr %slot100, align 8
  %v721 = load i64, ptr %slot9, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i32, ptr %p722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld723, ptr %slot101, align 8
  %v724 = load i32, ptr %slot101, align 8
  %op725 = and i32 %v724, 28
  store i32 %op725, ptr %slot102, align 8
  %v726 = load i32, ptr %slot102, align 8
  %cv727 = zext i32 %v726 to i64
  %cond728 = icmp ne i64 %cv727, 0
  br i1 %cond728, label %bb_rcslotrole160, label %bb_rcslotowner160
bb_rcslotrole160:
  %v729 = load i64, ptr %slot32, align 8
  store i64 %v729, ptr %slot103, align 8
  %v730 = load i64, ptr %slot103, align 8
  %v731 = load i64, ptr %slot100, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v730, i64 %v731) nomerge, !dbg !122
  br label %bb_rcslotdone160
bb_rcslotowner160:
  %v732 = load i64, ptr %slot32, align 8
  store i64 %v732, ptr %slot104, align 8
  %v733 = load i64, ptr %slot104, align 8
  %v734 = load i64, ptr %slot100, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v733, i64 %v734) nomerge, !dbg !122
  br label %bb_rcslotdone160
bb_rcslotdone160:
  %v735 = load i64, ptr %slot13, align 8
  store i64 %v735, ptr %slot105, align 8
  %v736 = load i64, ptr %slot16, align 8
  store i64 %v736, ptr %slot106, align 8
  %v737 = load i64, ptr %slot106, align 8
  %v738 = load i64, ptr %slot105, align 8
  %p739 = inttoptr i64 %v737 to ptr
  %p740 = inttoptr i64 %v738 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p740, ptr %p739, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot9, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i32 2, ptr %p742, align 4, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot11, align 8
  %p744 = inttoptr i64 %v743 to ptr
  %ld745 = load i32, ptr %p744, align 4, !alias.scope !3, !noalias !4
  store i32 %ld745, ptr %slot107, align 8
  %v746 = load i32, ptr %slot107, align 8
  %v747 = load i64, ptr %slot9, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i32 %v746, ptr %p748, align 4, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot10, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i32 0, ptr %p750, align 4, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot8, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i32 1, ptr %p752, align 4, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot105, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ld755 = load i64, ptr %p754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld755, ptr %slot108, align 8
  %v756 = load i64, ptr %slot108, align 8
  %v757 = load i64, ptr %slot25, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i64 %v756, ptr %p758, align 8, !alias.scope !3, !noalias !4
  %v759 = load i64, ptr %slot24, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i64, ptr %p760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld761, ptr %slot109, align 8
  %v762 = load i64, ptr %slot25, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %ld764 = load i64, ptr %p763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld764, ptr %slot110, align 8
  %v765 = load i64, ptr %slot24, align 8
  %p766 = inttoptr i64 %v765 to ptr
  %ld767 = load i64, ptr %p766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld767, ptr %slot111, align 8
  %v768 = load i64, ptr %slot25, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i64, ptr %p769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld770, ptr %slot112, align 8
  %v771 = load i64, ptr %slot32, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %v773 = load i64, ptr %slot111, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %v775 = load i64, ptr %slot112, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %call777 = call ptr @myl_native_bytes_concat(ptr %p772, ptr %p774, ptr %p776) nomerge, !dbg !124
  %calladdr778 = ptrtoint ptr %call777 to i64
  store i64 %calladdr778, ptr %slot113, align 8
  %v779 = load i64, ptr %slot113, align 8
  %cond780 = icmp ne i64 %v779, 0
  br i1 %cond780, label %bb_success182, label %bb_failed182
bb_failed182:
  %v781 = load i64, ptr %slot1, align 8
  %p782 = inttoptr i64 %v781 to ptr
  call void @myl_qbe_fail_allocation(ptr %p782) nomerge, !dbg !124
  unreachable
bb_success182:
  %v783 = load i64, ptr %slot113, align 8
  %v784 = load i64, ptr %slot24, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i64 %v783, ptr %p785, align 8, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot24, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i64, ptr %p787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld788, ptr %slot114, align 8
  %v789 = load i64, ptr %slot114, align 8
  %v790 = load i64, ptr %slot14, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i64 %v789, ptr %p791, align 8, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot14, align 8
  store i64 %v792, ptr %slot115, align 8
  %v793 = load i64, ptr %slot16, align 8
  store i64 %v793, ptr %slot116, align 8
  %v794 = load i64, ptr %slot115, align 8
  %v795 = load i64, ptr %slot116, align 8
  %p796 = inttoptr i64 %v794 to ptr
  %p797 = inttoptr i64 %v795 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p797, ptr %p796, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot11, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 2, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot10, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 1, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot6, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i32, ptr %p803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld804, ptr %slot117, align 8
  %v805 = load i32, ptr %slot117, align 8
  %cv806 = zext i32 %v805 to i64
  %cond807 = icmp ne i64 %cv806, 0
  br i1 %cond807, label %bb_rcslotdrop190, label %bb_rcslotdone190
bb_rcslotdrop190:
  %v808 = load i64, ptr %slot6, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 0, ptr %p809, align 4, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot12, align 8
  store i64 %v810, ptr %slot118, align 8
  %v811 = load i64, ptr %slot7, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i32, ptr %p812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld813, ptr %slot119, align 8
  %v814 = load i32, ptr %slot119, align 8
  %op815 = and i32 %v814, 28
  store i32 %op815, ptr %slot120, align 8
  %v816 = load i32, ptr %slot120, align 8
  %cv817 = zext i32 %v816 to i64
  %cond818 = icmp ne i64 %cv817, 0
  br i1 %cond818, label %bb_rcslotrole190, label %bb_rcslotowner190
bb_rcslotrole190:
  %v819 = load i64, ptr %slot32, align 8
  store i64 %v819, ptr %slot121, align 8
  %v820 = load i64, ptr %slot118, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %ld822 = load i64, ptr %p821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld822, ptr %slot122, align 8
  %v823 = load i64, ptr %slot122, align 8
  %cmp824 = icmp ne i64 %v823, 0
  %cv825 = zext i1 %cmp824 to i32
  store i32 %cv825, ptr %slot123, align 8
  %v826 = load i32, ptr %slot123, align 8
  %cv827 = zext i32 %v826 to i64
  %cond828 = icmp ne i64 %cv827, 0
  br i1 %cond828, label %bb_rcgnn206, label %bb_rcgdone206
bb_rcgnn206:
  %v829 = load i64, ptr %slot122, align 8
  %op830 = sub i64 %v829, 16
  store i64 %op830, ptr %slot124, align 8
  %v831 = load i64, ptr %slot122, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %rgep833 = getelementptr i8, ptr %p832, i64 -16
  %ld834 = load i64, ptr %rgep833, align 8, !alias.scope !9, !noalias !10
  store i64 %ld834, ptr %slot125, align 8
  %v835 = load i64, ptr %slot125, align 8
  %op836 = and i64 %v835, 4611686018427387906
  store i64 %op836, ptr %slot126, align 8
  %v837 = load i64, ptr %slot126, align 8
  %cmp838 = icmp ne i64 %v837, 0
  %cv839 = zext i1 %cmp838 to i32
  store i32 %cv839, ptr %slot127, align 8
  %v840 = load i32, ptr %slot127, align 8
  %cv841 = zext i32 %v840 to i64
  %cond842 = icmp ne i64 %cv841, 0
  br i1 %cond842, label %bb_rcgclear206, label %bb_rcgcounted206
bb_rcgcounted206:
  %v843 = load i64, ptr %slot122, align 8
  %op844 = sub i64 %v843, 24
  store i64 %op844, ptr %slot128, align 8
  %v845 = load i64, ptr %slot122, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %rgep847 = getelementptr i8, ptr %p846, i64 -24
  %ld848 = load i64, ptr %rgep847, align 8, !alias.scope !9, !noalias !10
  store i64 %ld848, ptr %slot129, align 8
  %v849 = load i64, ptr %slot129, align 8
  %op850 = sub i64 %v849, 1
  store i64 %op850, ptr %slot130, align 8
  %v851 = load i64, ptr %slot130, align 8
  %cmp852 = icmp eq i64 %v851, 0
  %cv853 = zext i1 %cmp852 to i32
  store i32 %cv853, ptr %slot131, align 8
  %v854 = load i32, ptr %slot131, align 8
  %cv855 = zext i32 %v854 to i64
  %cond856 = icmp ne i64 %cv855, 0
  br i1 %cond856, label %bb_rcglast206, label %bb_rcgdec206
bb_rcglast206:
  %v857 = load i64, ptr %slot122, align 8
  %op858 = sub i64 %v857, 32
  store i64 %op858, ptr %slot132, align 8
  %v859 = load i64, ptr %slot122, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %rgep861 = getelementptr i8, ptr %p860, i64 -32
  %ld862 = load i64, ptr %rgep861, align 8, !alias.scope !9, !noalias !10
  store i64 %ld862, ptr %slot133, align 8
  %v863 = load i64, ptr %slot133, align 8
  %cmp864 = icmp ne i64 %v863, 0
  %cv865 = zext i1 %cmp864 to i32
  store i32 %cv865, ptr %slot134, align 8
  %v866 = load i32, ptr %slot134, align 8
  %cv867 = zext i32 %v866 to i64
  %cond868 = icmp ne i64 %cv867, 0
  br i1 %cond868, label %bb_rcgdec206, label %bb_rcgslow206
bb_rcgslow206:
  %v869 = load i64, ptr %slot121, align 8
  %v870 = load i64, ptr %slot118, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v869, i64 %v870) nomerge, !dbg !124
  br label %bb_rcgdone206
bb_rcgdec206:
  %v871 = load i64, ptr %slot130, align 8
  %v872 = load i64, ptr %slot122, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %rgep874 = getelementptr i8, ptr %p873, i64 -24
  store i64 %v871, ptr %rgep874, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear206
bb_rcgclear206:
  %v875 = load i64, ptr %slot118, align 8
  %p876 = inttoptr i64 %v875 to ptr
  store i64 0, ptr %p876, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone206
bb_rcgdone206:
  br label %bb_rcslotdone190
bb_rcslotowner190:
  %v877 = load i64, ptr %slot32, align 8
  store i64 %v877, ptr %slot135, align 8
  %v878 = load i64, ptr %slot118, align 8
  %p879 = inttoptr i64 %v878 to ptr
  %ld880 = load i64, ptr %p879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld880, ptr %slot136, align 8
  %v881 = load i64, ptr %slot136, align 8
  %cmp882 = icmp ne i64 %v881, 0
  %cv883 = zext i1 %cmp882 to i32
  store i32 %cv883, ptr %slot137, align 8
  %v884 = load i32, ptr %slot137, align 8
  %cv885 = zext i32 %v884 to i64
  %cond886 = icmp ne i64 %cv885, 0
  br i1 %cond886, label %bb_rcgnn221, label %bb_rcgdone221
bb_rcgnn221:
  %v887 = load i64, ptr %slot136, align 8
  %op888 = sub i64 %v887, 16
  store i64 %op888, ptr %slot138, align 8
  %v889 = load i64, ptr %slot136, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %rgep891 = getelementptr i8, ptr %p890, i64 -16
  %ld892 = load i64, ptr %rgep891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld892, ptr %slot139, align 8
  %v893 = load i64, ptr %slot139, align 8
  %op894 = and i64 %v893, 4611686018427387906
  store i64 %op894, ptr %slot140, align 8
  %v895 = load i64, ptr %slot140, align 8
  %cmp896 = icmp ne i64 %v895, 0
  %cv897 = zext i1 %cmp896 to i32
  store i32 %cv897, ptr %slot141, align 8
  %v898 = load i32, ptr %slot141, align 8
  %cv899 = zext i32 %v898 to i64
  %cond900 = icmp ne i64 %cv899, 0
  br i1 %cond900, label %bb_rcgclear221, label %bb_rcgcounted221
bb_rcgcounted221:
  %v901 = load i64, ptr %slot136, align 8
  %op902 = sub i64 %v901, 32
  store i64 %op902, ptr %slot142, align 8
  %v903 = load i64, ptr %slot136, align 8
  %p904 = inttoptr i64 %v903 to ptr
  %rgep905 = getelementptr i8, ptr %p904, i64 -32
  %ld906 = load i64, ptr %rgep905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld906, ptr %slot143, align 8
  %v907 = load i64, ptr %slot143, align 8
  %op908 = sub i64 %v907, 1
  store i64 %op908, ptr %slot144, align 8
  %v909 = load i64, ptr %slot144, align 8
  %cmp910 = icmp eq i64 %v909, 0
  %cv911 = zext i1 %cmp910 to i32
  store i32 %cv911, ptr %slot145, align 8
  %v912 = load i32, ptr %slot145, align 8
  %cv913 = zext i32 %v912 to i64
  %cond914 = icmp ne i64 %cv913, 0
  br i1 %cond914, label %bb_rcglast221, label %bb_rcgdec221
bb_rcglast221:
  %v915 = load i64, ptr %slot136, align 8
  %op916 = sub i64 %v915, 24
  store i64 %op916, ptr %slot146, align 8
  %v917 = load i64, ptr %slot136, align 8
  %p918 = inttoptr i64 %v917 to ptr
  %rgep919 = getelementptr i8, ptr %p918, i64 -24
  %ld920 = load i64, ptr %rgep919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld920, ptr %slot147, align 8
  %v921 = load i64, ptr %slot147, align 8
  %cmp922 = icmp ne i64 %v921, 0
  %cv923 = zext i1 %cmp922 to i32
  store i32 %cv923, ptr %slot148, align 8
  %v924 = load i32, ptr %slot148, align 8
  %cv925 = zext i32 %v924 to i64
  %cond926 = icmp ne i64 %cv925, 0
  br i1 %cond926, label %bb_rcgdec221, label %bb_rcgslow221
bb_rcgslow221:
  %v927 = load i64, ptr %slot135, align 8
  %v928 = load i64, ptr %slot118, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v927, i64 %v928) nomerge, !dbg !124
  br label %bb_rcgdone221
bb_rcgdec221:
  %v929 = load i64, ptr %slot144, align 8
  %v930 = load i64, ptr %slot136, align 8
  %p931 = inttoptr i64 %v930 to ptr
  %rgep932 = getelementptr i8, ptr %p931, i64 -32
  store i64 %v929, ptr %rgep932, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear221
bb_rcgclear221:
  %v933 = load i64, ptr %slot118, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 0, ptr %p934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone221
bb_rcgdone221:
  br label %bb_rcslotdone190
bb_rcslotdone190:
  %v935 = load i64, ptr %slot8, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i32, ptr %p936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld937, ptr %slot149, align 8
  %v938 = load i32, ptr %slot149, align 8
  %cv939 = zext i32 %v938 to i64
  %cond940 = icmp ne i64 %cv939, 0
  br i1 %cond940, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v941 = load i64, ptr %slot8, align 8
  %p942 = inttoptr i64 %v941 to ptr
  store i32 0, ptr %p942, align 4, !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot13, align 8
  store i64 %v943, ptr %slot150, align 8
  %v944 = load i64, ptr %slot9, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %ld946 = load i32, ptr %p945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld946, ptr %slot151, align 8
  %v947 = load i32, ptr %slot151, align 8
  %op948 = and i32 %v947, 28
  store i32 %op948, ptr %slot152, align 8
  %v949 = load i32, ptr %slot152, align 8
  %cv950 = zext i32 %v949 to i64
  %cond951 = icmp ne i64 %cv950, 0
  br i1 %cond951, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v952 = load i64, ptr %slot32, align 8
  store i64 %v952, ptr %slot153, align 8
  %v953 = load i64, ptr %slot150, align 8
  %p954 = inttoptr i64 %v953 to ptr
  %ld955 = load i64, ptr %p954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld955, ptr %slot154, align 8
  %v956 = load i64, ptr %slot154, align 8
  %cmp957 = icmp ne i64 %v956, 0
  %cv958 = zext i1 %cmp957 to i32
  store i32 %cv958, ptr %slot155, align 8
  %v959 = load i32, ptr %slot155, align 8
  %cv960 = zext i32 %v959 to i64
  %cond961 = icmp ne i64 %cv960, 0
  br i1 %cond961, label %bb_rcgnn243, label %bb_rcgdone243
bb_rcgnn243:
  %v962 = load i64, ptr %slot154, align 8
  %op963 = sub i64 %v962, 16
  store i64 %op963, ptr %slot156, align 8
  %v964 = load i64, ptr %slot154, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %rgep966 = getelementptr i8, ptr %p965, i64 -16
  %ld967 = load i64, ptr %rgep966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld967, ptr %slot157, align 8
  %v968 = load i64, ptr %slot157, align 8
  %op969 = and i64 %v968, 4611686018427387906
  store i64 %op969, ptr %slot158, align 8
  %v970 = load i64, ptr %slot158, align 8
  %cmp971 = icmp ne i64 %v970, 0
  %cv972 = zext i1 %cmp971 to i32
  store i32 %cv972, ptr %slot159, align 8
  %v973 = load i32, ptr %slot159, align 8
  %cv974 = zext i32 %v973 to i64
  %cond975 = icmp ne i64 %cv974, 0
  br i1 %cond975, label %bb_rcgclear243, label %bb_rcgcounted243
bb_rcgcounted243:
  %v976 = load i64, ptr %slot154, align 8
  %op977 = sub i64 %v976, 24
  store i64 %op977, ptr %slot160, align 8
  %v978 = load i64, ptr %slot154, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %rgep980 = getelementptr i8, ptr %p979, i64 -24
  %ld981 = load i64, ptr %rgep980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld981, ptr %slot161, align 8
  %v982 = load i64, ptr %slot161, align 8
  %op983 = sub i64 %v982, 1
  store i64 %op983, ptr %slot162, align 8
  %v984 = load i64, ptr %slot162, align 8
  %cmp985 = icmp eq i64 %v984, 0
  %cv986 = zext i1 %cmp985 to i32
  store i32 %cv986, ptr %slot163, align 8
  %v987 = load i32, ptr %slot163, align 8
  %cv988 = zext i32 %v987 to i64
  %cond989 = icmp ne i64 %cv988, 0
  br i1 %cond989, label %bb_rcglast243, label %bb_rcgdec243
bb_rcglast243:
  %v990 = load i64, ptr %slot154, align 8
  %op991 = sub i64 %v990, 32
  store i64 %op991, ptr %slot164, align 8
  %v992 = load i64, ptr %slot154, align 8
  %p993 = inttoptr i64 %v992 to ptr
  %rgep994 = getelementptr i8, ptr %p993, i64 -32
  %ld995 = load i64, ptr %rgep994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld995, ptr %slot165, align 8
  %v996 = load i64, ptr %slot165, align 8
  %cmp997 = icmp ne i64 %v996, 0
  %cv998 = zext i1 %cmp997 to i32
  store i32 %cv998, ptr %slot166, align 8
  %v999 = load i32, ptr %slot166, align 8
  %cv1000 = zext i32 %v999 to i64
  %cond1001 = icmp ne i64 %cv1000, 0
  br i1 %cond1001, label %bb_rcgdec243, label %bb_rcgslow243
bb_rcgslow243:
  %v1002 = load i64, ptr %slot153, align 8
  %v1003 = load i64, ptr %slot150, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1002, i64 %v1003) nomerge, !dbg !124
  br label %bb_rcgdone243
bb_rcgdec243:
  %v1004 = load i64, ptr %slot162, align 8
  %v1005 = load i64, ptr %slot154, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  %rgep1007 = getelementptr i8, ptr %p1006, i64 -24
  store i64 %v1004, ptr %rgep1007, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear243
bb_rcgclear243:
  %v1008 = load i64, ptr %slot150, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i64 0, ptr %p1009, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone243
bb_rcgdone243:
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v1010 = load i64, ptr %slot32, align 8
  store i64 %v1010, ptr %slot167, align 8
  %v1011 = load i64, ptr %slot150, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %ld1013 = load i64, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1013, ptr %slot168, align 8
  %v1014 = load i64, ptr %slot168, align 8
  %cmp1015 = icmp ne i64 %v1014, 0
  %cv1016 = zext i1 %cmp1015 to i32
  store i32 %cv1016, ptr %slot169, align 8
  %v1017 = load i32, ptr %slot169, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcgnn258, label %bb_rcgdone258
bb_rcgnn258:
  %v1020 = load i64, ptr %slot168, align 8
  %op1021 = sub i64 %v1020, 16
  store i64 %op1021, ptr %slot170, align 8
  %v1022 = load i64, ptr %slot168, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %rgep1024 = getelementptr i8, ptr %p1023, i64 -16
  %ld1025 = load i64, ptr %rgep1024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1025, ptr %slot171, align 8
  %v1026 = load i64, ptr %slot171, align 8
  %op1027 = and i64 %v1026, 4611686018427387906
  store i64 %op1027, ptr %slot172, align 8
  %v1028 = load i64, ptr %slot172, align 8
  %cmp1029 = icmp ne i64 %v1028, 0
  %cv1030 = zext i1 %cmp1029 to i32
  store i32 %cv1030, ptr %slot173, align 8
  %v1031 = load i32, ptr %slot173, align 8
  %cv1032 = zext i32 %v1031 to i64
  %cond1033 = icmp ne i64 %cv1032, 0
  br i1 %cond1033, label %bb_rcgclear258, label %bb_rcgcounted258
bb_rcgcounted258:
  %v1034 = load i64, ptr %slot168, align 8
  %op1035 = sub i64 %v1034, 32
  store i64 %op1035, ptr %slot174, align 8
  %v1036 = load i64, ptr %slot168, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %rgep1038 = getelementptr i8, ptr %p1037, i64 -32
  %ld1039 = load i64, ptr %rgep1038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1039, ptr %slot175, align 8
  %v1040 = load i64, ptr %slot175, align 8
  %op1041 = sub i64 %v1040, 1
  store i64 %op1041, ptr %slot176, align 8
  %v1042 = load i64, ptr %slot176, align 8
  %cmp1043 = icmp eq i64 %v1042, 0
  %cv1044 = zext i1 %cmp1043 to i32
  store i32 %cv1044, ptr %slot177, align 8
  %v1045 = load i32, ptr %slot177, align 8
  %cv1046 = zext i32 %v1045 to i64
  %cond1047 = icmp ne i64 %cv1046, 0
  br i1 %cond1047, label %bb_rcglast258, label %bb_rcgdec258
bb_rcglast258:
  %v1048 = load i64, ptr %slot168, align 8
  %op1049 = sub i64 %v1048, 24
  store i64 %op1049, ptr %slot178, align 8
  %v1050 = load i64, ptr %slot168, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %rgep1052 = getelementptr i8, ptr %p1051, i64 -24
  %ld1053 = load i64, ptr %rgep1052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1053, ptr %slot179, align 8
  %v1054 = load i64, ptr %slot179, align 8
  %cmp1055 = icmp ne i64 %v1054, 0
  %cv1056 = zext i1 %cmp1055 to i32
  store i32 %cv1056, ptr %slot180, align 8
  %v1057 = load i32, ptr %slot180, align 8
  %cv1058 = zext i32 %v1057 to i64
  %cond1059 = icmp ne i64 %cv1058, 0
  br i1 %cond1059, label %bb_rcgdec258, label %bb_rcgslow258
bb_rcgslow258:
  %v1060 = load i64, ptr %slot167, align 8
  %v1061 = load i64, ptr %slot150, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1060, i64 %v1061) nomerge, !dbg !124
  br label %bb_rcgdone258
bb_rcgdec258:
  %v1062 = load i64, ptr %slot176, align 8
  %v1063 = load i64, ptr %slot168, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %rgep1065 = getelementptr i8, ptr %p1064, i64 -32
  store i64 %v1062, ptr %rgep1065, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear258
bb_rcgclear258:
  %v1066 = load i64, ptr %slot150, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i64 0, ptr %p1067, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone258
bb_rcgdone258:
  br label %bb_rcslotdone227
bb_rcslotdone227:
  %v1068 = load i64, ptr %slot12, align 8
  store i64 %v1068, ptr %slot181, align 8
  %v1069 = load i64, ptr %slot16, align 8
  store i64 %v1069, ptr %slot182, align 8
  %v1070 = load i64, ptr %slot182, align 8
  %v1071 = load i64, ptr %slot181, align 8
  %p1072 = inttoptr i64 %v1070 to ptr
  %p1073 = inttoptr i64 %v1071 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1073, ptr %p1072, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1074 = load i64, ptr %slot7, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  store i32 2, ptr %p1075, align 4, !alias.scope !3, !noalias !4
  %v1076 = load i64, ptr %slot11, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %ld1078 = load i32, ptr %p1077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1078, ptr %slot183, align 8
  %v1079 = load i32, ptr %slot183, align 8
  %v1080 = load i64, ptr %slot7, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  store i32 %v1079, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  %v1082 = load i64, ptr %slot10, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i32 0, ptr %p1083, align 4, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot6, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  store i32 1, ptr %p1085, align 4, !alias.scope !3, !noalias !4
  %v1086 = load i64, ptr %slot181, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  %ld1088 = load i64, ptr %p1087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1088, ptr %slot184, align 8
  %v1089 = load i64, ptr %slot184, align 8
  %v1090 = load i64, ptr %slot24, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  store i64 %v1089, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  %p1092 = inttoptr i64 ptrtoint (ptr @myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 to i64) to ptr
  %ld1093 = load i64, ptr %p1092, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1093, ptr %slot185, align 8
  %v1094 = load i64, ptr %slot185, align 8
  %v1095 = load i64, ptr %slot25, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i64 %v1094, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  %v1097 = load i64, ptr %slot25, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  %ld1099 = load i64, ptr %p1098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1099, ptr %slot186, align 8
  %v1100 = load i64, ptr %slot186, align 8
  %v1101 = load i64, ptr %slot15, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  store i64 %v1100, ptr %p1102, align 8, !alias.scope !3, !noalias !4
  %v1103 = load i64, ptr %slot15, align 8
  store i64 %v1103, ptr %slot187, align 8
  %v1104 = load i64, ptr %slot16, align 8
  store i64 %v1104, ptr %slot188, align 8
  %v1105 = load i64, ptr %slot187, align 8
  %v1106 = load i64, ptr %slot188, align 8
  %p1107 = inttoptr i64 %v1105 to ptr
  %p1108 = inttoptr i64 %v1106 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1108, ptr %p1107, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1109 = load i64, ptr %slot11, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  store i32 2, ptr %p1110, align 4, !alias.scope !3, !noalias !4
  %v1111 = load i64, ptr %slot10, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i32 1, ptr %p1112, align 4, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot13, align 8
  store i64 %v1113, ptr %slot189, align 8
  %v1114 = load i64, ptr %slot16, align 8
  store i64 %v1114, ptr %slot190, align 8
  %v1115 = load i64, ptr %slot190, align 8
  %v1116 = load i64, ptr %slot189, align 8
  %p1117 = inttoptr i64 %v1115 to ptr
  %p1118 = inttoptr i64 %v1116 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1118, ptr %p1117, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot9, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  store i32 2, ptr %p1120, align 4, !alias.scope !3, !noalias !4
  %v1121 = load i64, ptr %slot11, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  %ld1123 = load i32, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1123, ptr %slot191, align 8
  %v1124 = load i32, ptr %slot191, align 8
  %v1125 = load i64, ptr %slot9, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i32 %v1124, ptr %p1126, align 4, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot10, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i32 0, ptr %p1128, align 4, !alias.scope !3, !noalias !4
  %v1129 = load i64, ptr %slot8, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  store i32 1, ptr %p1130, align 4, !alias.scope !3, !noalias !4
  %v1131 = load i64, ptr %slot189, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %ld1133 = load i64, ptr %p1132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1133, ptr %slot192, align 8
  %v1134 = load i64, ptr %slot192, align 8
  %v1135 = load i64, ptr %slot25, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  store i64 %v1134, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  %v1137 = load i64, ptr %slot24, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %ld1139 = load i64, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1139, ptr %slot193, align 8
  %v1140 = load i64, ptr %slot25, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i64, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1142, ptr %slot194, align 8
  %v1143 = load i64, ptr %slot24, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i64, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1145, ptr %slot195, align 8
  %v1146 = load i64, ptr %slot25, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1148, ptr %slot196, align 8
  %v1149 = load i64, ptr %slot32, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %v1151 = load i64, ptr %slot195, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %v1153 = load i64, ptr %slot196, align 8
  %p1154 = inttoptr i64 %v1153 to ptr
  %call1155 = call ptr @myl_native_bytes_concat(ptr %p1150, ptr %p1152, ptr %p1154) nomerge, !dbg !126
  %calladdr1156 = ptrtoint ptr %call1155 to i64
  store i64 %calladdr1156, ptr %slot197, align 8
  %v1157 = load i64, ptr %slot197, align 8
  %cond1158 = icmp ne i64 %v1157, 0
  br i1 %cond1158, label %bb_success293, label %bb_failed293
bb_failed293:
  %v1159 = load i64, ptr %slot1, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1160) nomerge, !dbg !126
  unreachable
bb_success293:
  %v1161 = load i64, ptr %slot197, align 8
  %v1162 = load i64, ptr %slot24, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i64 %v1161, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot24, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %ld1166 = load i64, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1166, ptr %slot198, align 8
  %v1167 = load i64, ptr %slot198, align 8
  %v1168 = load i64, ptr %slot14, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i64 %v1167, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot14, align 8
  store i64 %v1170, ptr %slot199, align 8
  %v1171 = load i64, ptr %slot16, align 8
  store i64 %v1171, ptr %slot200, align 8
  %v1172 = load i64, ptr %slot199, align 8
  %v1173 = load i64, ptr %slot200, align 8
  %p1174 = inttoptr i64 %v1172 to ptr
  %p1175 = inttoptr i64 %v1173 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1175, ptr %p1174, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot11, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 2, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot10, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 1, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot6, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  %ld1182 = load i32, ptr %p1181, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1182, ptr %slot201, align 8
  %v1183 = load i32, ptr %slot201, align 8
  %cv1184 = zext i32 %v1183 to i64
  %cond1185 = icmp ne i64 %cv1184, 0
  br i1 %cond1185, label %bb_rcslotdrop301, label %bb_rcslotdone301
bb_rcslotdrop301:
  %v1186 = load i64, ptr %slot6, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i32 0, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot12, align 8
  store i64 %v1188, ptr %slot202, align 8
  %v1189 = load i64, ptr %slot7, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i32, ptr %p1190, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1191, ptr %slot203, align 8
  %v1192 = load i32, ptr %slot203, align 8
  %op1193 = and i32 %v1192, 28
  store i32 %op1193, ptr %slot204, align 8
  %v1194 = load i32, ptr %slot204, align 8
  %cv1195 = zext i32 %v1194 to i64
  %cond1196 = icmp ne i64 %cv1195, 0
  br i1 %cond1196, label %bb_rcslotrole301, label %bb_rcslotowner301
bb_rcslotrole301:
  %v1197 = load i64, ptr %slot32, align 8
  store i64 %v1197, ptr %slot205, align 8
  %v1198 = load i64, ptr %slot202, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %ld1200 = load i64, ptr %p1199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1200, ptr %slot206, align 8
  %v1201 = load i64, ptr %slot206, align 8
  %cmp1202 = icmp ne i64 %v1201, 0
  %cv1203 = zext i1 %cmp1202 to i32
  store i32 %cv1203, ptr %slot207, align 8
  %v1204 = load i32, ptr %slot207, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcgnn317, label %bb_rcgdone317
bb_rcgnn317:
  %v1207 = load i64, ptr %slot206, align 8
  %op1208 = sub i64 %v1207, 16
  store i64 %op1208, ptr %slot208, align 8
  %v1209 = load i64, ptr %slot206, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  %rgep1211 = getelementptr i8, ptr %p1210, i64 -16
  %ld1212 = load i64, ptr %rgep1211, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1212, ptr %slot209, align 8
  %v1213 = load i64, ptr %slot209, align 8
  %op1214 = and i64 %v1213, 4611686018427387906
  store i64 %op1214, ptr %slot210, align 8
  %v1215 = load i64, ptr %slot210, align 8
  %cmp1216 = icmp ne i64 %v1215, 0
  %cv1217 = zext i1 %cmp1216 to i32
  store i32 %cv1217, ptr %slot211, align 8
  %v1218 = load i32, ptr %slot211, align 8
  %cv1219 = zext i32 %v1218 to i64
  %cond1220 = icmp ne i64 %cv1219, 0
  br i1 %cond1220, label %bb_rcgclear317, label %bb_rcgcounted317
bb_rcgcounted317:
  %v1221 = load i64, ptr %slot206, align 8
  %op1222 = sub i64 %v1221, 24
  store i64 %op1222, ptr %slot212, align 8
  %v1223 = load i64, ptr %slot206, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  %rgep1225 = getelementptr i8, ptr %p1224, i64 -24
  %ld1226 = load i64, ptr %rgep1225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1226, ptr %slot213, align 8
  %v1227 = load i64, ptr %slot213, align 8
  %op1228 = sub i64 %v1227, 1
  store i64 %op1228, ptr %slot214, align 8
  %v1229 = load i64, ptr %slot214, align 8
  %cmp1230 = icmp eq i64 %v1229, 0
  %cv1231 = zext i1 %cmp1230 to i32
  store i32 %cv1231, ptr %slot215, align 8
  %v1232 = load i32, ptr %slot215, align 8
  %cv1233 = zext i32 %v1232 to i64
  %cond1234 = icmp ne i64 %cv1233, 0
  br i1 %cond1234, label %bb_rcglast317, label %bb_rcgdec317
bb_rcglast317:
  %v1235 = load i64, ptr %slot206, align 8
  %op1236 = sub i64 %v1235, 32
  store i64 %op1236, ptr %slot216, align 8
  %v1237 = load i64, ptr %slot206, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  %rgep1239 = getelementptr i8, ptr %p1238, i64 -32
  %ld1240 = load i64, ptr %rgep1239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1240, ptr %slot217, align 8
  %v1241 = load i64, ptr %slot217, align 8
  %cmp1242 = icmp ne i64 %v1241, 0
  %cv1243 = zext i1 %cmp1242 to i32
  store i32 %cv1243, ptr %slot218, align 8
  %v1244 = load i32, ptr %slot218, align 8
  %cv1245 = zext i32 %v1244 to i64
  %cond1246 = icmp ne i64 %cv1245, 0
  br i1 %cond1246, label %bb_rcgdec317, label %bb_rcgslow317
bb_rcgslow317:
  %v1247 = load i64, ptr %slot205, align 8
  %v1248 = load i64, ptr %slot202, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1247, i64 %v1248) nomerge, !dbg !126
  br label %bb_rcgdone317
bb_rcgdec317:
  %v1249 = load i64, ptr %slot214, align 8
  %v1250 = load i64, ptr %slot206, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %rgep1252 = getelementptr i8, ptr %p1251, i64 -24
  store i64 %v1249, ptr %rgep1252, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear317
bb_rcgclear317:
  %v1253 = load i64, ptr %slot202, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i64 0, ptr %p1254, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone317
bb_rcgdone317:
  br label %bb_rcslotdone301
bb_rcslotowner301:
  %v1255 = load i64, ptr %slot32, align 8
  store i64 %v1255, ptr %slot219, align 8
  %v1256 = load i64, ptr %slot202, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %ld1258 = load i64, ptr %p1257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1258, ptr %slot220, align 8
  %v1259 = load i64, ptr %slot220, align 8
  %cmp1260 = icmp ne i64 %v1259, 0
  %cv1261 = zext i1 %cmp1260 to i32
  store i32 %cv1261, ptr %slot221, align 8
  %v1262 = load i32, ptr %slot221, align 8
  %cv1263 = zext i32 %v1262 to i64
  %cond1264 = icmp ne i64 %cv1263, 0
  br i1 %cond1264, label %bb_rcgnn332, label %bb_rcgdone332
bb_rcgnn332:
  %v1265 = load i64, ptr %slot220, align 8
  %op1266 = sub i64 %v1265, 16
  store i64 %op1266, ptr %slot222, align 8
  %v1267 = load i64, ptr %slot220, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  %rgep1269 = getelementptr i8, ptr %p1268, i64 -16
  %ld1270 = load i64, ptr %rgep1269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1270, ptr %slot223, align 8
  %v1271 = load i64, ptr %slot223, align 8
  %op1272 = and i64 %v1271, 4611686018427387906
  store i64 %op1272, ptr %slot224, align 8
  %v1273 = load i64, ptr %slot224, align 8
  %cmp1274 = icmp ne i64 %v1273, 0
  %cv1275 = zext i1 %cmp1274 to i32
  store i32 %cv1275, ptr %slot225, align 8
  %v1276 = load i32, ptr %slot225, align 8
  %cv1277 = zext i32 %v1276 to i64
  %cond1278 = icmp ne i64 %cv1277, 0
  br i1 %cond1278, label %bb_rcgclear332, label %bb_rcgcounted332
bb_rcgcounted332:
  %v1279 = load i64, ptr %slot220, align 8
  %op1280 = sub i64 %v1279, 32
  store i64 %op1280, ptr %slot226, align 8
  %v1281 = load i64, ptr %slot220, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %rgep1283 = getelementptr i8, ptr %p1282, i64 -32
  %ld1284 = load i64, ptr %rgep1283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1284, ptr %slot227, align 8
  %v1285 = load i64, ptr %slot227, align 8
  %op1286 = sub i64 %v1285, 1
  store i64 %op1286, ptr %slot228, align 8
  %v1287 = load i64, ptr %slot228, align 8
  %cmp1288 = icmp eq i64 %v1287, 0
  %cv1289 = zext i1 %cmp1288 to i32
  store i32 %cv1289, ptr %slot229, align 8
  %v1290 = load i32, ptr %slot229, align 8
  %cv1291 = zext i32 %v1290 to i64
  %cond1292 = icmp ne i64 %cv1291, 0
  br i1 %cond1292, label %bb_rcglast332, label %bb_rcgdec332
bb_rcglast332:
  %v1293 = load i64, ptr %slot220, align 8
  %op1294 = sub i64 %v1293, 24
  store i64 %op1294, ptr %slot230, align 8
  %v1295 = load i64, ptr %slot220, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  %rgep1297 = getelementptr i8, ptr %p1296, i64 -24
  %ld1298 = load i64, ptr %rgep1297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1298, ptr %slot231, align 8
  %v1299 = load i64, ptr %slot231, align 8
  %cmp1300 = icmp ne i64 %v1299, 0
  %cv1301 = zext i1 %cmp1300 to i32
  store i32 %cv1301, ptr %slot232, align 8
  %v1302 = load i32, ptr %slot232, align 8
  %cv1303 = zext i32 %v1302 to i64
  %cond1304 = icmp ne i64 %cv1303, 0
  br i1 %cond1304, label %bb_rcgdec332, label %bb_rcgslow332
bb_rcgslow332:
  %v1305 = load i64, ptr %slot219, align 8
  %v1306 = load i64, ptr %slot202, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1305, i64 %v1306) nomerge, !dbg !126
  br label %bb_rcgdone332
bb_rcgdec332:
  %v1307 = load i64, ptr %slot228, align 8
  %v1308 = load i64, ptr %slot220, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  %rgep1310 = getelementptr i8, ptr %p1309, i64 -32
  store i64 %v1307, ptr %rgep1310, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear332
bb_rcgclear332:
  %v1311 = load i64, ptr %slot202, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  store i64 0, ptr %p1312, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone332
bb_rcgdone332:
  br label %bb_rcslotdone301
bb_rcslotdone301:
  %v1313 = load i64, ptr %slot8, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %ld1315 = load i32, ptr %p1314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1315, ptr %slot233, align 8
  %v1316 = load i32, ptr %slot233, align 8
  %cv1317 = zext i32 %v1316 to i64
  %cond1318 = icmp ne i64 %cv1317, 0
  br i1 %cond1318, label %bb_rcslotdrop338, label %bb_rcslotdone338
bb_rcslotdrop338:
  %v1319 = load i64, ptr %slot8, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  store i32 0, ptr %p1320, align 4, !alias.scope !3, !noalias !4
  %v1321 = load i64, ptr %slot13, align 8
  store i64 %v1321, ptr %slot234, align 8
  %v1322 = load i64, ptr %slot9, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i32, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1324, ptr %slot235, align 8
  %v1325 = load i32, ptr %slot235, align 8
  %op1326 = and i32 %v1325, 28
  store i32 %op1326, ptr %slot236, align 8
  %v1327 = load i32, ptr %slot236, align 8
  %cv1328 = zext i32 %v1327 to i64
  %cond1329 = icmp ne i64 %cv1328, 0
  br i1 %cond1329, label %bb_rcslotrole338, label %bb_rcslotowner338
bb_rcslotrole338:
  %v1330 = load i64, ptr %slot32, align 8
  store i64 %v1330, ptr %slot237, align 8
  %v1331 = load i64, ptr %slot234, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %ld1333 = load i64, ptr %p1332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1333, ptr %slot238, align 8
  %v1334 = load i64, ptr %slot238, align 8
  %cmp1335 = icmp ne i64 %v1334, 0
  %cv1336 = zext i1 %cmp1335 to i32
  store i32 %cv1336, ptr %slot239, align 8
  %v1337 = load i32, ptr %slot239, align 8
  %cv1338 = zext i32 %v1337 to i64
  %cond1339 = icmp ne i64 %cv1338, 0
  br i1 %cond1339, label %bb_rcgnn354, label %bb_rcgdone354
bb_rcgnn354:
  %v1340 = load i64, ptr %slot238, align 8
  %op1341 = sub i64 %v1340, 16
  store i64 %op1341, ptr %slot240, align 8
  %v1342 = load i64, ptr %slot238, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %rgep1344 = getelementptr i8, ptr %p1343, i64 -16
  %ld1345 = load i64, ptr %rgep1344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1345, ptr %slot241, align 8
  %v1346 = load i64, ptr %slot241, align 8
  %op1347 = and i64 %v1346, 4611686018427387906
  store i64 %op1347, ptr %slot242, align 8
  %v1348 = load i64, ptr %slot242, align 8
  %cmp1349 = icmp ne i64 %v1348, 0
  %cv1350 = zext i1 %cmp1349 to i32
  store i32 %cv1350, ptr %slot243, align 8
  %v1351 = load i32, ptr %slot243, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcgclear354, label %bb_rcgcounted354
bb_rcgcounted354:
  %v1354 = load i64, ptr %slot238, align 8
  %op1355 = sub i64 %v1354, 24
  store i64 %op1355, ptr %slot244, align 8
  %v1356 = load i64, ptr %slot238, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  %rgep1358 = getelementptr i8, ptr %p1357, i64 -24
  %ld1359 = load i64, ptr %rgep1358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1359, ptr %slot245, align 8
  %v1360 = load i64, ptr %slot245, align 8
  %op1361 = sub i64 %v1360, 1
  store i64 %op1361, ptr %slot246, align 8
  %v1362 = load i64, ptr %slot246, align 8
  %cmp1363 = icmp eq i64 %v1362, 0
  %cv1364 = zext i1 %cmp1363 to i32
  store i32 %cv1364, ptr %slot247, align 8
  %v1365 = load i32, ptr %slot247, align 8
  %cv1366 = zext i32 %v1365 to i64
  %cond1367 = icmp ne i64 %cv1366, 0
  br i1 %cond1367, label %bb_rcglast354, label %bb_rcgdec354
bb_rcglast354:
  %v1368 = load i64, ptr %slot238, align 8
  %op1369 = sub i64 %v1368, 32
  store i64 %op1369, ptr %slot248, align 8
  %v1370 = load i64, ptr %slot238, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %rgep1372 = getelementptr i8, ptr %p1371, i64 -32
  %ld1373 = load i64, ptr %rgep1372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1373, ptr %slot249, align 8
  %v1374 = load i64, ptr %slot249, align 8
  %cmp1375 = icmp ne i64 %v1374, 0
  %cv1376 = zext i1 %cmp1375 to i32
  store i32 %cv1376, ptr %slot250, align 8
  %v1377 = load i32, ptr %slot250, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rcgdec354, label %bb_rcgslow354
bb_rcgslow354:
  %v1380 = load i64, ptr %slot237, align 8
  %v1381 = load i64, ptr %slot234, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1380, i64 %v1381) nomerge, !dbg !126
  br label %bb_rcgdone354
bb_rcgdec354:
  %v1382 = load i64, ptr %slot246, align 8
  %v1383 = load i64, ptr %slot238, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %rgep1385 = getelementptr i8, ptr %p1384, i64 -24
  store i64 %v1382, ptr %rgep1385, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear354
bb_rcgclear354:
  %v1386 = load i64, ptr %slot234, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i64 0, ptr %p1387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone354
bb_rcgdone354:
  br label %bb_rcslotdone338
bb_rcslotowner338:
  %v1388 = load i64, ptr %slot32, align 8
  store i64 %v1388, ptr %slot251, align 8
  %v1389 = load i64, ptr %slot234, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %ld1391 = load i64, ptr %p1390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1391, ptr %slot252, align 8
  %v1392 = load i64, ptr %slot252, align 8
  %cmp1393 = icmp ne i64 %v1392, 0
  %cv1394 = zext i1 %cmp1393 to i32
  store i32 %cv1394, ptr %slot253, align 8
  %v1395 = load i32, ptr %slot253, align 8
  %cv1396 = zext i32 %v1395 to i64
  %cond1397 = icmp ne i64 %cv1396, 0
  br i1 %cond1397, label %bb_rcgnn369, label %bb_rcgdone369
bb_rcgnn369:
  %v1398 = load i64, ptr %slot252, align 8
  %op1399 = sub i64 %v1398, 16
  store i64 %op1399, ptr %slot254, align 8
  %v1400 = load i64, ptr %slot252, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %rgep1402 = getelementptr i8, ptr %p1401, i64 -16
  %ld1403 = load i64, ptr %rgep1402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1403, ptr %slot255, align 8
  %v1404 = load i64, ptr %slot255, align 8
  %op1405 = and i64 %v1404, 4611686018427387906
  store i64 %op1405, ptr %slot256, align 8
  %v1406 = load i64, ptr %slot256, align 8
  %cmp1407 = icmp ne i64 %v1406, 0
  %cv1408 = zext i1 %cmp1407 to i32
  store i32 %cv1408, ptr %slot257, align 8
  %v1409 = load i32, ptr %slot257, align 8
  %cv1410 = zext i32 %v1409 to i64
  %cond1411 = icmp ne i64 %cv1410, 0
  br i1 %cond1411, label %bb_rcgclear369, label %bb_rcgcounted369
bb_rcgcounted369:
  %v1412 = load i64, ptr %slot252, align 8
  %op1413 = sub i64 %v1412, 32
  store i64 %op1413, ptr %slot258, align 8
  %v1414 = load i64, ptr %slot252, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  %rgep1416 = getelementptr i8, ptr %p1415, i64 -32
  %ld1417 = load i64, ptr %rgep1416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1417, ptr %slot259, align 8
  %v1418 = load i64, ptr %slot259, align 8
  %op1419 = sub i64 %v1418, 1
  store i64 %op1419, ptr %slot260, align 8
  %v1420 = load i64, ptr %slot260, align 8
  %cmp1421 = icmp eq i64 %v1420, 0
  %cv1422 = zext i1 %cmp1421 to i32
  store i32 %cv1422, ptr %slot261, align 8
  %v1423 = load i32, ptr %slot261, align 8
  %cv1424 = zext i32 %v1423 to i64
  %cond1425 = icmp ne i64 %cv1424, 0
  br i1 %cond1425, label %bb_rcglast369, label %bb_rcgdec369
bb_rcglast369:
  %v1426 = load i64, ptr %slot252, align 8
  %op1427 = sub i64 %v1426, 24
  store i64 %op1427, ptr %slot262, align 8
  %v1428 = load i64, ptr %slot252, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %rgep1430 = getelementptr i8, ptr %p1429, i64 -24
  %ld1431 = load i64, ptr %rgep1430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1431, ptr %slot263, align 8
  %v1432 = load i64, ptr %slot263, align 8
  %cmp1433 = icmp ne i64 %v1432, 0
  %cv1434 = zext i1 %cmp1433 to i32
  store i32 %cv1434, ptr %slot264, align 8
  %v1435 = load i32, ptr %slot264, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcgdec369, label %bb_rcgslow369
bb_rcgslow369:
  %v1438 = load i64, ptr %slot251, align 8
  %v1439 = load i64, ptr %slot234, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1438, i64 %v1439) nomerge, !dbg !126
  br label %bb_rcgdone369
bb_rcgdec369:
  %v1440 = load i64, ptr %slot260, align 8
  %v1441 = load i64, ptr %slot252, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  %rgep1443 = getelementptr i8, ptr %p1442, i64 -32
  store i64 %v1440, ptr %rgep1443, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear369
bb_rcgclear369:
  %v1444 = load i64, ptr %slot234, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i64 0, ptr %p1445, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone369
bb_rcgdone369:
  br label %bb_rcslotdone338
bb_rcslotdone338:
  %v1446 = load i64, ptr %slot12, align 8
  store i64 %v1446, ptr %slot265, align 8
  %v1447 = load i64, ptr %slot16, align 8
  store i64 %v1447, ptr %slot266, align 8
  %v1448 = load i64, ptr %slot266, align 8
  %v1449 = load i64, ptr %slot265, align 8
  %p1450 = inttoptr i64 %v1448 to ptr
  %p1451 = inttoptr i64 %v1449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1451, ptr %p1450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot7, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 2, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot11, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i32, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1456, ptr %slot267, align 8
  %v1457 = load i32, ptr %slot267, align 8
  %v1458 = load i64, ptr %slot7, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 %v1457, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot10, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  store i32 0, ptr %p1461, align 4, !alias.scope !3, !noalias !4
  %v1462 = load i64, ptr %slot6, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i32 1, ptr %p1463, align 4, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot265, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i64, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1466, ptr %slot268, align 8
  %v1467 = load i64, ptr %slot268, align 8
  %v1468 = load i64, ptr %slot24, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  store i64 %v1467, ptr %p1469, align 8, !alias.scope !3, !noalias !4
  %v1470 = load i64, ptr %slot22, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %ld1472 = load i64, ptr %p1471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1472, ptr %slot269, align 8
  %v1473 = load i64, ptr %slot23, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %ld1475 = load i64, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1475, ptr %slot270, align 8
  %v1476 = load i64, ptr %slot24, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %ld1478 = load i64, ptr %p1477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1478, ptr %slot271, align 8
  %v1479 = load i64, ptr %slot1, align 8
  %v1480 = load i64, ptr %slot269, align 8
  %v1481 = load i64, ptr %slot270, align 8
  %v1482 = load i64, ptr %slot271, align 8
  %call1483 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v1479, i64 %v1480, i64 %v1481, i64 %v1482) nomerge, !dbg !128
  store i64 %call1483, ptr %slot272, align 8
  %v1484 = load i64, ptr %slot272, align 8
  %v1485 = load i64, ptr %slot22, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i64 %v1484, ptr %p1486, align 8, !alias.scope !3, !noalias !4
  %v1487 = load i64, ptr %slot6, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %ld1489 = load i32, ptr %p1488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1489, ptr %slot273, align 8
  %v1490 = load i32, ptr %slot273, align 8
  %cv1491 = zext i32 %v1490 to i64
  %cond1492 = icmp ne i64 %cv1491, 0
  br i1 %cond1492, label %bb_rcslotdrop406, label %bb_rcslotdone406
bb_rcslotdrop406:
  %v1493 = load i64, ptr %slot6, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i32 0, ptr %p1494, align 4, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot12, align 8
  store i64 %v1495, ptr %slot274, align 8
  %v1496 = load i64, ptr %slot7, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %ld1498 = load i32, ptr %p1497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1498, ptr %slot275, align 8
  %v1499 = load i32, ptr %slot275, align 8
  %op1500 = and i32 %v1499, 28
  store i32 %op1500, ptr %slot276, align 8
  %v1501 = load i32, ptr %slot276, align 8
  %cv1502 = zext i32 %v1501 to i64
  %cond1503 = icmp ne i64 %cv1502, 0
  br i1 %cond1503, label %bb_rcslotrole406, label %bb_rcslotowner406
bb_rcslotrole406:
  %v1504 = load i64, ptr %slot32, align 8
  store i64 %v1504, ptr %slot277, align 8
  %v1505 = load i64, ptr %slot274, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot278, align 8
  %v1508 = load i64, ptr %slot278, align 8
  %cmp1509 = icmp ne i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot279, align 8
  %v1511 = load i32, ptr %slot279, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcgnn422, label %bb_rcgdone422
bb_rcgnn422:
  %v1514 = load i64, ptr %slot278, align 8
  %op1515 = sub i64 %v1514, 16
  store i64 %op1515, ptr %slot280, align 8
  %v1516 = load i64, ptr %slot278, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %rgep1518 = getelementptr i8, ptr %p1517, i64 -16
  %ld1519 = load i64, ptr %rgep1518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1519, ptr %slot281, align 8
  %v1520 = load i64, ptr %slot281, align 8
  %op1521 = and i64 %v1520, 4611686018427387906
  store i64 %op1521, ptr %slot282, align 8
  %v1522 = load i64, ptr %slot282, align 8
  %cmp1523 = icmp ne i64 %v1522, 0
  %cv1524 = zext i1 %cmp1523 to i32
  store i32 %cv1524, ptr %slot283, align 8
  %v1525 = load i32, ptr %slot283, align 8
  %cv1526 = zext i32 %v1525 to i64
  %cond1527 = icmp ne i64 %cv1526, 0
  br i1 %cond1527, label %bb_rcgclear422, label %bb_rcgcounted422
bb_rcgcounted422:
  %v1528 = load i64, ptr %slot278, align 8
  %op1529 = sub i64 %v1528, 24
  store i64 %op1529, ptr %slot284, align 8
  %v1530 = load i64, ptr %slot278, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  %rgep1532 = getelementptr i8, ptr %p1531, i64 -24
  %ld1533 = load i64, ptr %rgep1532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1533, ptr %slot285, align 8
  %v1534 = load i64, ptr %slot285, align 8
  %op1535 = sub i64 %v1534, 1
  store i64 %op1535, ptr %slot286, align 8
  %v1536 = load i64, ptr %slot286, align 8
  %cmp1537 = icmp eq i64 %v1536, 0
  %cv1538 = zext i1 %cmp1537 to i32
  store i32 %cv1538, ptr %slot287, align 8
  %v1539 = load i32, ptr %slot287, align 8
  %cv1540 = zext i32 %v1539 to i64
  %cond1541 = icmp ne i64 %cv1540, 0
  br i1 %cond1541, label %bb_rcglast422, label %bb_rcgdec422
bb_rcglast422:
  %v1542 = load i64, ptr %slot278, align 8
  %op1543 = sub i64 %v1542, 32
  store i64 %op1543, ptr %slot288, align 8
  %v1544 = load i64, ptr %slot278, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %rgep1546 = getelementptr i8, ptr %p1545, i64 -32
  %ld1547 = load i64, ptr %rgep1546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1547, ptr %slot289, align 8
  %v1548 = load i64, ptr %slot289, align 8
  %cmp1549 = icmp ne i64 %v1548, 0
  %cv1550 = zext i1 %cmp1549 to i32
  store i32 %cv1550, ptr %slot290, align 8
  %v1551 = load i32, ptr %slot290, align 8
  %cv1552 = zext i32 %v1551 to i64
  %cond1553 = icmp ne i64 %cv1552, 0
  br i1 %cond1553, label %bb_rcgdec422, label %bb_rcgslow422
bb_rcgslow422:
  %v1554 = load i64, ptr %slot277, align 8
  %v1555 = load i64, ptr %slot274, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1554, i64 %v1555) nomerge, !dbg !128
  br label %bb_rcgdone422
bb_rcgdec422:
  %v1556 = load i64, ptr %slot286, align 8
  %v1557 = load i64, ptr %slot278, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %rgep1559 = getelementptr i8, ptr %p1558, i64 -24
  store i64 %v1556, ptr %rgep1559, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear422
bb_rcgclear422:
  %v1560 = load i64, ptr %slot274, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  store i64 0, ptr %p1561, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone422
bb_rcgdone422:
  br label %bb_rcslotdone406
bb_rcslotowner406:
  %v1562 = load i64, ptr %slot32, align 8
  store i64 %v1562, ptr %slot291, align 8
  %v1563 = load i64, ptr %slot274, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i64, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1565, ptr %slot292, align 8
  %v1566 = load i64, ptr %slot292, align 8
  %cmp1567 = icmp ne i64 %v1566, 0
  %cv1568 = zext i1 %cmp1567 to i32
  store i32 %cv1568, ptr %slot293, align 8
  %v1569 = load i32, ptr %slot293, align 8
  %cv1570 = zext i32 %v1569 to i64
  %cond1571 = icmp ne i64 %cv1570, 0
  br i1 %cond1571, label %bb_rcgnn437, label %bb_rcgdone437
bb_rcgnn437:
  %v1572 = load i64, ptr %slot292, align 8
  %op1573 = sub i64 %v1572, 16
  store i64 %op1573, ptr %slot294, align 8
  %v1574 = load i64, ptr %slot292, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %rgep1576 = getelementptr i8, ptr %p1575, i64 -16
  %ld1577 = load i64, ptr %rgep1576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1577, ptr %slot295, align 8
  %v1578 = load i64, ptr %slot295, align 8
  %op1579 = and i64 %v1578, 4611686018427387906
  store i64 %op1579, ptr %slot296, align 8
  %v1580 = load i64, ptr %slot296, align 8
  %cmp1581 = icmp ne i64 %v1580, 0
  %cv1582 = zext i1 %cmp1581 to i32
  store i32 %cv1582, ptr %slot297, align 8
  %v1583 = load i32, ptr %slot297, align 8
  %cv1584 = zext i32 %v1583 to i64
  %cond1585 = icmp ne i64 %cv1584, 0
  br i1 %cond1585, label %bb_rcgclear437, label %bb_rcgcounted437
bb_rcgcounted437:
  %v1586 = load i64, ptr %slot292, align 8
  %op1587 = sub i64 %v1586, 32
  store i64 %op1587, ptr %slot298, align 8
  %v1588 = load i64, ptr %slot292, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  %rgep1590 = getelementptr i8, ptr %p1589, i64 -32
  %ld1591 = load i64, ptr %rgep1590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1591, ptr %slot299, align 8
  %v1592 = load i64, ptr %slot299, align 8
  %op1593 = sub i64 %v1592, 1
  store i64 %op1593, ptr %slot300, align 8
  %v1594 = load i64, ptr %slot300, align 8
  %cmp1595 = icmp eq i64 %v1594, 0
  %cv1596 = zext i1 %cmp1595 to i32
  store i32 %cv1596, ptr %slot301, align 8
  %v1597 = load i32, ptr %slot301, align 8
  %cv1598 = zext i32 %v1597 to i64
  %cond1599 = icmp ne i64 %cv1598, 0
  br i1 %cond1599, label %bb_rcglast437, label %bb_rcgdec437
bb_rcglast437:
  %v1600 = load i64, ptr %slot292, align 8
  %op1601 = sub i64 %v1600, 24
  store i64 %op1601, ptr %slot302, align 8
  %v1602 = load i64, ptr %slot292, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  %rgep1604 = getelementptr i8, ptr %p1603, i64 -24
  %ld1605 = load i64, ptr %rgep1604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1605, ptr %slot303, align 8
  %v1606 = load i64, ptr %slot303, align 8
  %cmp1607 = icmp ne i64 %v1606, 0
  %cv1608 = zext i1 %cmp1607 to i32
  store i32 %cv1608, ptr %slot304, align 8
  %v1609 = load i32, ptr %slot304, align 8
  %cv1610 = zext i32 %v1609 to i64
  %cond1611 = icmp ne i64 %cv1610, 0
  br i1 %cond1611, label %bb_rcgdec437, label %bb_rcgslow437
bb_rcgslow437:
  %v1612 = load i64, ptr %slot291, align 8
  %v1613 = load i64, ptr %slot274, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1612, i64 %v1613) nomerge, !dbg !128
  br label %bb_rcgdone437
bb_rcgdec437:
  %v1614 = load i64, ptr %slot300, align 8
  %v1615 = load i64, ptr %slot292, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %rgep1617 = getelementptr i8, ptr %p1616, i64 -32
  store i64 %v1614, ptr %rgep1617, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear437
bb_rcgclear437:
  %v1618 = load i64, ptr %slot274, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i64 0, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone437
bb_rcgdone437:
  br label %bb_rcslotdone406
bb_rcslotdone406:
  %v1620 = load i64, ptr %slot22, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %ld1622 = load i64, ptr %p1621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1622, ptr %slot305, align 8
  %v1623 = load i64, ptr %slot305, align 8
  ret i64 %v1623
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_8d47278f5246a959c9cf373236b198659ae1c259b6afd12cadab3d657868cf2b = external global i8, align 8
@myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare i64 @myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow(i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a166af0fddcce6486b1b5dce83e3088987f61aa80d20403973fcc035ba69fb14", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a166af0fddcce6486b1b5dce83e3088987f61aa80d20403973fcc035ba69fb14", linkageName: "myl_f_a166af0fddcce6486b1b5dce83e3088987f61aa80d20403973fcc035ba69fb14", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6375538794965686144, i64 0, !"myl_f_a166af0fddcce6486b1b5dce83e3088987f61aa80d20403973fcc035ba69fb14"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!116 = !DILocation(line: 9, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!122 = !DILocation(line: 23, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!124 = !DILocation(line: 24, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!126 = !DILocation(line: 26, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!128 = !DILocation(line: 27, column: 0, scope: !129)
