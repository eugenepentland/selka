target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v253 = load i64, ptr %slot1, align 8
  %op254 = add i64 %v253, 32
  store i64 %op254, ptr %slot3, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot4, align 8
  %mem257 = alloca i8, i64 8, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot5, align 8
  %mem259 = alloca i8, i64 8, align 8
  %ptr260 = ptrtoint ptr %mem259 to i64
  store i64 %ptr260, ptr %slot6, align 8
  %mem261 = alloca i8, i64 8, align 8
  %ptr262 = ptrtoint ptr %mem261 to i64
  store i64 %ptr262, ptr %slot7, align 8
  %mem263 = alloca i8, i64 8, align 8
  %ptr264 = ptrtoint ptr %mem263 to i64
  store i64 %ptr264, ptr %slot8, align 8
  %mem265 = alloca i8, i64 8, align 8
  %ptr266 = ptrtoint ptr %mem265 to i64
  store i64 %ptr266, ptr %slot9, align 8
  %mem267 = alloca i8, i64 8, align 8
  %ptr268 = ptrtoint ptr %mem267 to i64
  store i64 %ptr268, ptr %slot10, align 8
  %mem269 = alloca i8, i64 8, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot11, align 8
  %mem271 = alloca i8, i64 8, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot12, align 8
  %mem273 = alloca i8, i64 8, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot13, align 8
  %mem275 = alloca i8, i64 8, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot14, align 8
  %mem277 = alloca i8, i64 8, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot15, align 8
  %mem279 = alloca i8, i64 8, align 8
  %ptr280 = ptrtoint ptr %mem279 to i64
  store i64 %ptr280, ptr %slot16, align 8
  %mem281 = alloca i8, i64 392, align 8
  %ptr282 = ptrtoint ptr %mem281 to i64
  store i64 %ptr282, ptr %slot17, align 8
  %mem283 = alloca i8, i64 8, align 8
  %ptr284 = ptrtoint ptr %mem283 to i64
  store i64 %ptr284, ptr %slot18, align 8
  %mem285 = alloca i8, i64 8, align 8
  %ptr286 = ptrtoint ptr %mem285 to i64
  store i64 %ptr286, ptr %slot19, align 8
  %mem287 = alloca i8, i64 392, align 8
  %ptr288 = ptrtoint ptr %mem287 to i64
  store i64 %ptr288, ptr %slot20, align 8
  %mem289 = alloca i8, i64 8, align 8
  %ptr290 = ptrtoint ptr %mem289 to i64
  store i64 %ptr290, ptr %slot21, align 8
  %mem291 = alloca i8, i64 8, align 8
  %ptr292 = ptrtoint ptr %mem291 to i64
  store i64 %ptr292, ptr %slot22, align 8
  %mem293 = alloca i8, i64 8, align 8
  %ptr294 = ptrtoint ptr %mem293 to i64
  store i64 %ptr294, ptr %slot23, align 8
  %mem295 = alloca i8, i64 8, align 8
  %ptr296 = ptrtoint ptr %mem295 to i64
  store i64 %ptr296, ptr %slot24, align 8
  %mem297 = alloca i8, i64 392, align 8
  %ptr298 = ptrtoint ptr %mem297 to i64
  store i64 %ptr298, ptr %slot25, align 8
  %mem299 = alloca i8, i64 40, align 8
  %ptr300 = ptrtoint ptr %mem299 to i64
  store i64 %ptr300, ptr %slot26, align 8
  %mem301 = alloca i8, i64 392, align 8
  %ptr302 = ptrtoint ptr %mem301 to i64
  store i64 %ptr302, ptr %slot27, align 8
  %mem303 = alloca i8, i64 392, align 8
  %ptr304 = ptrtoint ptr %mem303 to i64
  store i64 %ptr304, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem305 = alloca i8, i64 8, align 8
  %ptr306 = ptrtoint ptr %mem305 to i64
  store i64 %ptr306, ptr %slot29, align 8
  %v307 = load i64, ptr %slot1, align 8
  %op308 = add i64 %v307, 64
  store i64 %op308, ptr %slot30, align 8
  %v309 = load i64, ptr %slot30, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !4, !noalias !3
  store i64 %ld311, ptr %slot31, align 8
  %stack312 = call ptr @llvm.stacksave()
  %stackaddr313 = ptrtoint ptr %stack312 to i64
  %v314 = load i64, ptr %slot31, align 8
  %cmp315 = icmp ult i64 %stackaddr313, %v314
  %cv316 = zext i1 %cmp315 to i64
  store i64 %cv316, ptr %slot32, align 8
  %v317 = load i64, ptr %slot32, align 8
  %cond318 = icmp ne i64 %v317, 0
  br i1 %cond318, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v319 = load i64, ptr %slot1, align 8
  %p320 = inttoptr i64 %v319 to ptr
  call void @myl_qbe_fail_frame(ptr %p320) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v321 = load i64, ptr %slot2, align 8
  %v322 = load i64, ptr %slot18, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i64 %v321, ptr %p323, align 8, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot1, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %call326 = call ptr @myl_qbe_heap(ptr %p325) nomerge, !dbg !112
  %calladdr327 = ptrtoint ptr %call326 to i64
  store i64 %calladdr327, ptr %slot33, align 8
  %v328 = load i64, ptr %slot1, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %call330 = call i64 @myl_qbe_region_mark(ptr %p329) nomerge, !dbg !112
  store i64 %call330, ptr %slot34, align 8
  %v331 = load i64, ptr %slot4, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 0, ptr %p332, align 4, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot5, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i32 0, ptr %p334, align 4, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot6, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 0, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot7, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 0, ptr %p338, align 4, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot8, align 8
  %p340 = inttoptr i64 %v339 to ptr
  store i32 0, ptr %p340, align 4, !alias.scope !3, !noalias !4
  %v341 = load i64, ptr %slot9, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i32 0, ptr %p342, align 4, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot10, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i32 0, ptr %p344, align 4, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot11, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i32 0, ptr %p346, align 4, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot12, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i32 0, ptr %p348, align 4, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot5, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i32 2, ptr %p350, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v351 = load i64, ptr %slot22, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 0, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot22, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot35, align 8
  %v356 = load i64, ptr %slot35, align 8
  %v357 = load i64, ptr %slot19, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 %v356, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot18, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %ld361 = load i64, ptr %p360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld361, ptr %slot36, align 8
  %v362 = load i64, ptr %slot36, align 8
  %v363 = load i64, ptr %slot22, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot25, align 8
  store i64 %v365, ptr %slot37, align 8
  %v366 = load i64, ptr %slot37, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i32 0, ptr %p367, align 4, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot37, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 1, ptr %p369, align 4, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot37, align 8
  %v371 = load i64, ptr %slot23, align 8
  %p372 = inttoptr i64 %v371 to ptr
  store i64 %v370, ptr %p372, align 8, !alias.scope !3, !noalias !4
  %v373 = load i64, ptr %slot23, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i64, ptr %p374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld375, ptr %slot38, align 8
  %v376 = load i64, ptr %slot38, align 8
  %v377 = load i64, ptr %slot21, align 8
  %p378 = inttoptr i64 %v376 to ptr
  %p379 = inttoptr i64 %v377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p379, ptr %p378, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot22, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot39, align 8
  store i32 0, ptr %slot40, align 8
  %v383 = load i64, ptr %slot6, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i32, ptr %p384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld385, ptr %slot41, align 8
  %v386 = load i32, ptr %slot41, align 8
  %op387 = and i32 %v386, 24
  store i32 %op387, ptr %slot41, align 8
  %v388 = load i32, ptr %slot41, align 8
  %cmp389 = icmp eq i32 %v388, 0
  %cv390 = zext i1 %cmp389 to i32
  store i32 %cv390, ptr %slot42, align 8
  %v391 = load i32, ptr %slot40, align 8
  %v392 = load i32, ptr %slot42, align 8
  %op393 = and i32 %v391, %v392
  store i32 %op393, ptr %slot43, align 8
  %v394 = load i32, ptr %slot43, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rctake14, label %bb_rccopy14
bb_rctake14:
  %v397 = load i64, ptr %slot17, align 8
  store i64 %v397, ptr %slot44, align 8
  %v398 = load i64, ptr %slot34, align 8
  store i64 %v398, ptr %slot45, align 8
  %v399 = load i64, ptr %slot33, align 8
  %v400 = load i64, ptr %slot44, align 8
  %v401 = load i64, ptr %slot39, align 8
  %v402 = load i64, ptr %slot45, align 8
  %cv403 = trunc i64 %v402 to i32
  %call404 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v399, i64 %v400, i64 %v401, i32 %cv403) nomerge, !dbg !114
  store i32 %call404, ptr %slot46, align 8
  %v405 = load i32, ptr %slot46, align 8
  %cv406 = zext i32 %v405 to i64
  %cond407 = icmp ne i64 %cv406, 0
  br i1 %cond407, label %bb_rcsuccess24, label %bb_rcfailure24
bb_rcfailure24:
  %v408 = load i64, ptr %slot33, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %call410 = call i32 @myl_rc_take_failure(ptr %p409) nomerge, !dbg !114
  store i32 %call410, ptr %slot47, align 8
  %v411 = load i64, ptr %slot1, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %v413 = load i32, ptr %slot47, align 8
  %call414 = call i32 @myl_qbe_rc_status(ptr %p412, i32 %v413) nomerge, !dbg !114
  store i32 %call414, ptr %slot48, align 8
  br label %bb_failure
bb_rcsuccess24:
  %v415 = load i64, ptr %slot12, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i32 2, ptr %p416, align 4, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot11, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i32 1, ptr %p418, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rccopy14:
  %v419 = load i64, ptr %slot17, align 8
  store i64 %v419, ptr %slot49, align 8
  %v420 = load i64, ptr %slot34, align 8
  store i64 %v420, ptr %slot50, align 8
  %v421 = load i64, ptr %slot33, align 8
  %v422 = load i64, ptr %slot49, align 8
  %v423 = load i64, ptr %slot39, align 8
  %v424 = load i64, ptr %slot50, align 8
  %cv425 = trunc i64 %v424 to i32
  %call426 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v421, i64 %v422, i64 %v423, i32 %cv425) nomerge, !dbg !114
  store i32 %call426, ptr %slot51, align 8
  %v427 = load i32, ptr %slot51, align 8
  %cv428 = zext i32 %v427 to i64
  %cond429 = icmp ne i64 %cv428, 0
  br i1 %cond429, label %bb_rcsuccess33, label %bb_rcfailure33
bb_rcfailure33:
  %v430 = load i64, ptr %slot33, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %call432 = call i32 @myl_rc_take_failure(ptr %p431) nomerge, !dbg !114
  store i32 %call432, ptr %slot52, align 8
  %v433 = load i64, ptr %slot1, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %v435 = load i32, ptr %slot52, align 8
  %call436 = call i32 @myl_qbe_rc_status(ptr %p434, i32 %v435) nomerge, !dbg !114
  store i32 %call436, ptr %slot53, align 8
  br label %bb_failure
bb_rcsuccess33:
  %v437 = load i64, ptr %slot12, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 2, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot11, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 1, ptr %p440, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rcprepared14:
  %v441 = load i64, ptr %slot4, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i32, ptr %p442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld443, ptr %slot54, align 8
  %v444 = load i32, ptr %slot54, align 8
  %cv445 = zext i32 %v444 to i64
  %cond446 = icmp ne i64 %cv445, 0
  br i1 %cond446, label %bb_rcslotdrop50, label %bb_rcslotdone50
bb_rcslotdrop50:
  %v447 = load i64, ptr %slot4, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 0, ptr %p448, align 4, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot20, align 8
  store i64 %v449, ptr %slot55, align 8
  %v450 = load i64, ptr %slot5, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i32, ptr %p451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld452, ptr %slot56, align 8
  %v453 = load i32, ptr %slot56, align 8
  %op454 = and i32 %v453, 28
  store i32 %op454, ptr %slot57, align 8
  %v455 = load i32, ptr %slot57, align 8
  %cv456 = zext i32 %v455 to i64
  %cond457 = icmp ne i64 %cv456, 0
  br i1 %cond457, label %bb_rcslotrole50, label %bb_rcslotowner50
bb_rcslotrole50:
  %v458 = load i64, ptr %slot33, align 8
  store i64 %v458, ptr %slot58, align 8
  %v459 = load i64, ptr %slot58, align 8
  %v460 = load i64, ptr %slot55, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v459, i64 %v460) nomerge, !dbg !114
  br label %bb_rcslotdone50
bb_rcslotowner50:
  %v461 = load i64, ptr %slot33, align 8
  store i64 %v461, ptr %slot59, align 8
  %v462 = load i64, ptr %slot59, align 8
  %v463 = load i64, ptr %slot55, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v462, i64 %v463) nomerge, !dbg !114
  br label %bb_rcslotdone50
bb_rcslotdone50:
  %v464 = load i64, ptr %slot20, align 8
  store i64 %v464, ptr %slot60, align 8
  %v465 = load i64, ptr %slot17, align 8
  store i64 %v465, ptr %slot61, align 8
  %v466 = load i64, ptr %slot61, align 8
  %v467 = load i64, ptr %slot60, align 8
  %p468 = inttoptr i64 %v466 to ptr
  %p469 = inttoptr i64 %v467 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p469, ptr %p468, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot11, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 0, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot5, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 2, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot12, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i32, ptr %p475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld476, ptr %slot62, align 8
  %v477 = load i32, ptr %slot62, align 8
  %v478 = load i64, ptr %slot5, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 %v477, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot4, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 1, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot20, align 8
  %v483 = load i64, ptr %slot22, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i64 %v482, ptr %p484, align 8, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot22, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i64, ptr %p486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot63, align 8
  %v488 = load i64, ptr %slot63, align 8
  %op489 = add i64 %v488, 288
  store i64 %op489, ptr %slot64, align 8
  %v490 = load i64, ptr %slot64, align 8
  %v491 = load i64, ptr %slot22, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i64 %v490, ptr %p492, align 8, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot22, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i64, ptr %p494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld495, ptr %slot65, align 8
  %v496 = load i64, ptr %slot65, align 8
  %op497 = add i64 %v496, 0
  store i64 %op497, ptr %slot66, align 8
  %v498 = load i64, ptr %slot66, align 8
  %v499 = load i64, ptr %slot22, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i64 %v498, ptr %p500, align 8, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot22, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %ld503 = load i64, ptr %p502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld503, ptr %slot67, align 8
  %v504 = load i64, ptr %slot26, align 8
  store i64 %v504, ptr %slot68, align 8
  %v505 = load i64, ptr %slot67, align 8
  %v506 = load i64, ptr %slot68, align 8
  %p507 = inttoptr i64 %v505 to ptr
  %p508 = inttoptr i64 %v506 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p508, ptr %p507, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot68, align 8
  %v510 = load i64, ptr %slot22, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i64 %v509, ptr %p511, align 8, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot21, align 8
  %v513 = load i64, ptr %slot23, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i64 %v512, ptr %p514, align 8, !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot23, align 8
  %p516 = inttoptr i64 %v515 to ptr
  %ld517 = load i64, ptr %p516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld517, ptr %slot69, align 8
  %v518 = load i64, ptr %slot22, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %ld520 = load i64, ptr %p519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld520, ptr %slot70, align 8
  %v521 = load i64, ptr %slot70, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i32, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %ext524 = zext i32 %ld523 to i64
  store i64 %ext524, ptr %slot71, align 8
  %v525 = load i64, ptr %slot69, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i32, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %ext528 = zext i32 %ld527 to i64
  store i64 %ext528, ptr %slot72, align 8
  %v529 = load i64, ptr %slot71, align 8
  %v530 = load i64, ptr %slot72, align 8
  %cmp531 = icmp eq i64 %v529, %v530
  %cv532 = zext i1 %cmp531 to i64
  store i64 %cv532, ptr %slot73, align 8
  %v533 = load i64, ptr %slot73, align 8
  %v534 = load i64, ptr %slot22, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  br label %bb_i12
bb_i12:
  %v536 = load i64, ptr %slot22, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot74, align 8
  %v539 = load i64, ptr %slot74, align 8
  %op540 = xor i64 %v539, 1
  store i64 %op540, ptr %slot75, align 8
  %v541 = load i64, ptr %slot75, align 8
  %v542 = load i64, ptr %slot22, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot22, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot76, align 8
  %v547 = load i64, ptr %slot76, align 8
  %cond548 = icmp ne i64 %v547, 0
  br i1 %cond548, label %bb_next96, label %bb_i49
bb_next96:
  %v549 = load i64, ptr %slot18, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %ld551 = load i64, ptr %p550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld551, ptr %slot77, align 8
  %v552 = load i64, ptr %slot77, align 8
  %v553 = load i64, ptr %slot22, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i64 %v552, ptr %p554, align 8, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot22, align 8
  %p556 = inttoptr i64 %v555 to ptr
  %ld557 = load i64, ptr %p556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld557, ptr %slot78, align 8
  %v558 = load i64, ptr %slot1, align 8
  %v559 = load i64, ptr %slot78, align 8
  %call560 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v558, i64 %v559) nomerge, !dbg !116
  store i64 %call560, ptr %slot79, align 8
  %v561 = load i64, ptr %slot79, align 8
  %v562 = load i64, ptr %slot22, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot19, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot80, align 8
  %v567 = load i64, ptr %slot80, align 8
  %v568 = load i64, ptr %slot22, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i64 %v567, ptr %p569, align 8, !alias.scope !3, !noalias !4
  %v570 = load i64, ptr %slot23, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i64 255, ptr %p571, align 8, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot23, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot81, align 8
  %v575 = load i64, ptr %slot22, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot82, align 8
  %v578 = load i64, ptr %slot82, align 8
  %v579 = load i64, ptr %slot81, align 8
  %cmp580 = icmp eq i64 %v578, %v579
  %cv581 = zext i1 %cmp580 to i64
  store i64 %cv581, ptr %slot83, align 8
  %v582 = load i64, ptr %slot83, align 8
  %v583 = load i64, ptr %slot22, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot22, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot84, align 8
  %v588 = load i64, ptr %slot84, align 8
  %cond589 = icmp ne i64 %v588, 0
  br i1 %cond589, label %bb_next113, label %bb_i25
bb_next113:
  %v590 = load i64, ptr %slot18, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %ld592 = load i64, ptr %p591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld592, ptr %slot85, align 8
  %v593 = load i64, ptr %slot85, align 8
  %v594 = load i64, ptr %slot22, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i64 %v593, ptr %p595, align 8, !alias.scope !3, !noalias !4
  %p596 = inttoptr i64 ptrtoint (ptr @myl_lit_a2fef6855234220d4efe69d6d206ee3c11f5b0c2ac2ff07411d432d186d8f508 to i64) to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !4, !noalias !3
  store i64 %ld597, ptr %slot86, align 8
  %v598 = load i64, ptr %slot86, align 8
  %v599 = load i64, ptr %slot23, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i64 %v598, ptr %p600, align 8, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot23, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %ld603 = load i64, ptr %p602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld603, ptr %slot87, align 8
  %v604 = load i64, ptr %slot87, align 8
  %v605 = load i64, ptr %slot15, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i64 %v604, ptr %p606, align 8, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot15, align 8
  store i64 %v607, ptr %slot88, align 8
  %v608 = load i64, ptr %slot17, align 8
  store i64 %v608, ptr %slot89, align 8
  %v609 = load i64, ptr %slot88, align 8
  %v610 = load i64, ptr %slot89, align 8
  %p611 = inttoptr i64 %v609 to ptr
  %p612 = inttoptr i64 %v610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p612, ptr %p611, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v613 = load i64, ptr %slot12, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i32 2, ptr %p614, align 4, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot11, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i32 1, ptr %p616, align 4, !alias.scope !3, !noalias !4
  %v617 = load i64, ptr %slot13, align 8
  store i64 %v617, ptr %slot90, align 8
  %v618 = load i64, ptr %slot17, align 8
  store i64 %v618, ptr %slot91, align 8
  %v619 = load i64, ptr %slot91, align 8
  %v620 = load i64, ptr %slot90, align 8
  %p621 = inttoptr i64 %v619 to ptr
  %p622 = inttoptr i64 %v620 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p622, ptr %p621, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v623 = load i64, ptr %slot8, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i32 2, ptr %p624, align 4, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot12, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i32, ptr %p626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld627, ptr %slot92, align 8
  %v628 = load i32, ptr %slot92, align 8
  %v629 = load i64, ptr %slot8, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i32 %v628, ptr %p630, align 4, !alias.scope !3, !noalias !4
  %v631 = load i64, ptr %slot11, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i32 0, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot7, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i32 1, ptr %p634, align 4, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot90, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot93, align 8
  %v638 = load i64, ptr %slot93, align 8
  %v639 = load i64, ptr %slot23, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 %v638, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot22, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot94, align 8
  %v644 = load i64, ptr %slot23, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %ld646 = load i64, ptr %p645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld646, ptr %slot95, align 8
  %v647 = load i64, ptr %slot1, align 8
  %v648 = load i64, ptr %slot94, align 8
  %v649 = load i64, ptr %slot95, align 8
  %call650 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v647, i64 %v648, i64 %v649) nomerge, !dbg !118
  store i64 %call650, ptr %slot96, align 8
  %v651 = load i64, ptr %slot96, align 8
  %v652 = load i64, ptr %slot22, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot7, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i32, ptr %p655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld656, ptr %slot97, align 8
  %v657 = load i32, ptr %slot97, align 8
  %cv658 = zext i32 %v657 to i64
  %cond659 = icmp ne i64 %cv658, 0
  br i1 %cond659, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v660 = load i64, ptr %slot7, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i32 0, ptr %p661, align 4, !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot13, align 8
  store i64 %v662, ptr %slot98, align 8
  %v663 = load i64, ptr %slot8, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i32, ptr %p664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld665, ptr %slot99, align 8
  %v666 = load i32, ptr %slot99, align 8
  %op667 = and i32 %v666, 28
  store i32 %op667, ptr %slot100, align 8
  %v668 = load i32, ptr %slot100, align 8
  %cv669 = zext i32 %v668 to i64
  %cond670 = icmp ne i64 %cv669, 0
  br i1 %cond670, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v671 = load i64, ptr %slot33, align 8
  store i64 %v671, ptr %slot101, align 8
  %v672 = load i64, ptr %slot98, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld674, ptr %slot102, align 8
  %v675 = load i64, ptr %slot102, align 8
  %cmp676 = icmp ne i64 %v675, 0
  %cv677 = zext i1 %cmp676 to i32
  store i32 %cv677, ptr %slot103, align 8
  %v678 = load i32, ptr %slot103, align 8
  %cv679 = zext i32 %v678 to i64
  %cond680 = icmp ne i64 %cv679, 0
  br i1 %cond680, label %bb_rcgnn160, label %bb_rcgdone160
bb_rcgnn160:
  %v681 = load i64, ptr %slot102, align 8
  %op682 = sub i64 %v681, 16
  store i64 %op682, ptr %slot104, align 8
  %v683 = load i64, ptr %slot102, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %rgep685 = getelementptr i8, ptr %p684, i64 -16
  %ld686 = load i64, ptr %rgep685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld686, ptr %slot105, align 8
  %v687 = load i64, ptr %slot105, align 8
  %op688 = and i64 %v687, 4611686018427387906
  store i64 %op688, ptr %slot106, align 8
  %v689 = load i64, ptr %slot106, align 8
  %cmp690 = icmp ne i64 %v689, 0
  %cv691 = zext i1 %cmp690 to i32
  store i32 %cv691, ptr %slot107, align 8
  %v692 = load i32, ptr %slot107, align 8
  %cv693 = zext i32 %v692 to i64
  %cond694 = icmp ne i64 %cv693, 0
  br i1 %cond694, label %bb_rcgclear160, label %bb_rcgcounted160
bb_rcgcounted160:
  %v695 = load i64, ptr %slot102, align 8
  %op696 = sub i64 %v695, 24
  store i64 %op696, ptr %slot108, align 8
  %v697 = load i64, ptr %slot102, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %rgep699 = getelementptr i8, ptr %p698, i64 -24
  %ld700 = load i64, ptr %rgep699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld700, ptr %slot109, align 8
  %v701 = load i64, ptr %slot109, align 8
  %op702 = sub i64 %v701, 1
  store i64 %op702, ptr %slot110, align 8
  %v703 = load i64, ptr %slot110, align 8
  %cmp704 = icmp eq i64 %v703, 0
  %cv705 = zext i1 %cmp704 to i32
  store i32 %cv705, ptr %slot111, align 8
  %v706 = load i32, ptr %slot111, align 8
  %cv707 = zext i32 %v706 to i64
  %cond708 = icmp ne i64 %cv707, 0
  br i1 %cond708, label %bb_rcglast160, label %bb_rcgdec160
bb_rcglast160:
  %v709 = load i64, ptr %slot102, align 8
  %op710 = sub i64 %v709, 32
  store i64 %op710, ptr %slot112, align 8
  %v711 = load i64, ptr %slot102, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %rgep713 = getelementptr i8, ptr %p712, i64 -32
  %ld714 = load i64, ptr %rgep713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld714, ptr %slot113, align 8
  %v715 = load i64, ptr %slot113, align 8
  %cmp716 = icmp ne i64 %v715, 0
  %cv717 = zext i1 %cmp716 to i32
  store i32 %cv717, ptr %slot114, align 8
  %v718 = load i32, ptr %slot114, align 8
  %cv719 = zext i32 %v718 to i64
  %cond720 = icmp ne i64 %cv719, 0
  br i1 %cond720, label %bb_rcgdec160, label %bb_rcgslow160
bb_rcgslow160:
  %v721 = load i64, ptr %slot101, align 8
  %v722 = load i64, ptr %slot98, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v721, i64 %v722) nomerge, !dbg !118
  br label %bb_rcgdone160
bb_rcgdec160:
  %v723 = load i64, ptr %slot110, align 8
  %v724 = load i64, ptr %slot102, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %rgep726 = getelementptr i8, ptr %p725, i64 -24
  store i64 %v723, ptr %rgep726, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear160
bb_rcgclear160:
  %v727 = load i64, ptr %slot98, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 0, ptr %p728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone160
bb_rcgdone160:
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v729 = load i64, ptr %slot33, align 8
  store i64 %v729, ptr %slot115, align 8
  %v730 = load i64, ptr %slot98, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot116, align 8
  %v733 = load i64, ptr %slot116, align 8
  %cmp734 = icmp ne i64 %v733, 0
  %cv735 = zext i1 %cmp734 to i32
  store i32 %cv735, ptr %slot117, align 8
  %v736 = load i32, ptr %slot117, align 8
  %cv737 = zext i32 %v736 to i64
  %cond738 = icmp ne i64 %cv737, 0
  br i1 %cond738, label %bb_rcgnn175, label %bb_rcgdone175
bb_rcgnn175:
  %v739 = load i64, ptr %slot116, align 8
  %op740 = sub i64 %v739, 16
  store i64 %op740, ptr %slot118, align 8
  %v741 = load i64, ptr %slot116, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %rgep743 = getelementptr i8, ptr %p742, i64 -16
  %ld744 = load i64, ptr %rgep743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld744, ptr %slot119, align 8
  %v745 = load i64, ptr %slot119, align 8
  %op746 = and i64 %v745, 4611686018427387906
  store i64 %op746, ptr %slot120, align 8
  %v747 = load i64, ptr %slot120, align 8
  %cmp748 = icmp ne i64 %v747, 0
  %cv749 = zext i1 %cmp748 to i32
  store i32 %cv749, ptr %slot121, align 8
  %v750 = load i32, ptr %slot121, align 8
  %cv751 = zext i32 %v750 to i64
  %cond752 = icmp ne i64 %cv751, 0
  br i1 %cond752, label %bb_rcgclear175, label %bb_rcgcounted175
bb_rcgcounted175:
  %v753 = load i64, ptr %slot116, align 8
  %op754 = sub i64 %v753, 32
  store i64 %op754, ptr %slot122, align 8
  %v755 = load i64, ptr %slot116, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %rgep757 = getelementptr i8, ptr %p756, i64 -32
  %ld758 = load i64, ptr %rgep757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld758, ptr %slot123, align 8
  %v759 = load i64, ptr %slot123, align 8
  %op760 = sub i64 %v759, 1
  store i64 %op760, ptr %slot124, align 8
  %v761 = load i64, ptr %slot124, align 8
  %cmp762 = icmp eq i64 %v761, 0
  %cv763 = zext i1 %cmp762 to i32
  store i32 %cv763, ptr %slot125, align 8
  %v764 = load i32, ptr %slot125, align 8
  %cv765 = zext i32 %v764 to i64
  %cond766 = icmp ne i64 %cv765, 0
  br i1 %cond766, label %bb_rcglast175, label %bb_rcgdec175
bb_rcglast175:
  %v767 = load i64, ptr %slot116, align 8
  %op768 = sub i64 %v767, 24
  store i64 %op768, ptr %slot126, align 8
  %v769 = load i64, ptr %slot116, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %rgep771 = getelementptr i8, ptr %p770, i64 -24
  %ld772 = load i64, ptr %rgep771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld772, ptr %slot127, align 8
  %v773 = load i64, ptr %slot127, align 8
  %cmp774 = icmp ne i64 %v773, 0
  %cv775 = zext i1 %cmp774 to i32
  store i32 %cv775, ptr %slot128, align 8
  %v776 = load i32, ptr %slot128, align 8
  %cv777 = zext i32 %v776 to i64
  %cond778 = icmp ne i64 %cv777, 0
  br i1 %cond778, label %bb_rcgdec175, label %bb_rcgslow175
bb_rcgslow175:
  %v779 = load i64, ptr %slot115, align 8
  %v780 = load i64, ptr %slot98, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v779, i64 %v780) nomerge, !dbg !118
  br label %bb_rcgdone175
bb_rcgdec175:
  %v781 = load i64, ptr %slot124, align 8
  %v782 = load i64, ptr %slot116, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %rgep784 = getelementptr i8, ptr %p783, i64 -32
  store i64 %v781, ptr %rgep784, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear175
bb_rcgclear175:
  %v785 = load i64, ptr %slot98, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i64 0, ptr %p786, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone175
bb_rcgdone175:
  br label %bb_rcslotdone144
bb_rcslotdone144:
  br label %bb_i25
bb_i25:
  %v787 = load i64, ptr %slot19, align 8
  %p788 = inttoptr i64 %v787 to ptr
  %ld789 = load i64, ptr %p788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld789, ptr %slot129, align 8
  %v790 = load i64, ptr %slot129, align 8
  %v791 = load i64, ptr %slot22, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 %v790, ptr %p792, align 8, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot23, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 1, ptr %p794, align 8, !alias.scope !3, !noalias !4
  %v795 = load i64, ptr %slot23, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld797, ptr %slot130, align 8
  %v798 = load i64, ptr %slot22, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld800, ptr %slot131, align 8
  %v801 = load i64, ptr %slot131, align 8
  %v802 = load i64, ptr %slot130, align 8
  %ovpair804 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v801, i64 %v802)
  %op803 = extractvalue { i64, i1 } %ovpair804, 0
  %ov805 = extractvalue { i64, i1 } %ovpair804, 1
  store i64 %op803, ptr %slot132, align 8
  %cv806 = zext i1 %ov805 to i64
  store i64 %cv806, ptr %slot133, align 8
  %v807 = load i64, ptr %slot133, align 8
  %cond808 = icmp ne i64 %v807, 0
  br i1 %cond808, label %bb_overflow182, label %bb_checked182
bb_overflow182:
  %v809 = load i64, ptr %slot1, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %v811 = load i64, ptr %slot131, align 8
  %v812 = load i64, ptr %slot130, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p810, i64 0, i64 %v811, i64 %v812, i64 64) nomerge, !dbg !120
  unreachable
bb_checked182:
  %v813 = load i64, ptr %slot132, align 8
  %v814 = load i64, ptr %slot22, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 %v813, ptr %p815, align 8, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot22, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i64, ptr %p817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld818, ptr %slot134, align 8
  %v819 = load i64, ptr %slot134, align 8
  %v820 = load i64, ptr %slot19, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 %v819, ptr %p821, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i29:
  %v822 = load i64, ptr %slot18, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot135, align 8
  %v825 = load i64, ptr %slot135, align 8
  %v826 = load i64, ptr %slot22, align 8
  %p827 = inttoptr i64 %v826 to ptr
  store i64 %v825, ptr %p827, align 8, !alias.scope !3, !noalias !4
  %v828 = load i64, ptr %slot27, align 8
  store i64 %v828, ptr %slot136, align 8
  %v829 = load i64, ptr %slot136, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 0, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot136, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i32 4, ptr %p832, align 4, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot136, align 8
  %v834 = load i64, ptr %slot23, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 %v833, ptr %p835, align 8, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot22, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot137, align 8
  %v839 = load i64, ptr %slot23, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot138, align 8
  %v842 = load i64, ptr %slot1, align 8
  %v843 = load i64, ptr %slot137, align 8
  %v844 = load i64, ptr %slot138, align 8
  %call845 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v842, i64 %v843, i64 %v844) nomerge, !dbg !122
  store i64 %call845, ptr %slot139, align 8
  %v846 = load i64, ptr %slot139, align 8
  %v847 = load i64, ptr %slot22, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i64 %v846, ptr %p848, align 8, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot22, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot140, align 8
  %v852 = load i64, ptr %slot140, align 8
  %cond853 = icmp ne i64 %v852, 0
  br i1 %cond853, label %bb_next200, label %bb_i49
bb_next200:
  %v854 = load i64, ptr %slot18, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld856, ptr %slot141, align 8
  %v857 = load i64, ptr %slot141, align 8
  %v858 = load i64, ptr %slot22, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i64 %v857, ptr %p859, align 8, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot22, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i64, ptr %p861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld862, ptr %slot142, align 8
  %v863 = load i64, ptr %slot1, align 8
  %v864 = load i64, ptr %slot142, align 8
  %call865 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v863, i64 %v864) nomerge, !dbg !124
  store i64 %call865, ptr %slot143, align 8
  %v866 = load i64, ptr %slot143, align 8
  %v867 = load i64, ptr %slot22, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i64 %v866, ptr %p868, align 8, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot19, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i64, ptr %p870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld871, ptr %slot144, align 8
  %v872 = load i64, ptr %slot144, align 8
  %v873 = load i64, ptr %slot22, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i64 %v872, ptr %p874, align 8, !alias.scope !3, !noalias !4
  %v875 = load i64, ptr %slot23, align 8
  %p876 = inttoptr i64 %v875 to ptr
  store i64 255, ptr %p876, align 8, !alias.scope !3, !noalias !4
  %v877 = load i64, ptr %slot23, align 8
  %p878 = inttoptr i64 %v877 to ptr
  %ld879 = load i64, ptr %p878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld879, ptr %slot145, align 8
  %v880 = load i64, ptr %slot22, align 8
  %p881 = inttoptr i64 %v880 to ptr
  %ld882 = load i64, ptr %p881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld882, ptr %slot146, align 8
  %v883 = load i64, ptr %slot146, align 8
  %v884 = load i64, ptr %slot145, align 8
  %cmp885 = icmp eq i64 %v883, %v884
  %cv886 = zext i1 %cmp885 to i64
  store i64 %cv886, ptr %slot147, align 8
  %v887 = load i64, ptr %slot147, align 8
  %v888 = load i64, ptr %slot22, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i64 %v887, ptr %p889, align 8, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot22, align 8
  %p891 = inttoptr i64 %v890 to ptr
  %ld892 = load i64, ptr %p891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld892, ptr %slot148, align 8
  %v893 = load i64, ptr %slot148, align 8
  %cond894 = icmp ne i64 %v893, 0
  br i1 %cond894, label %bb_next217, label %bb_i44
bb_next217:
  %v895 = load i64, ptr %slot18, align 8
  %p896 = inttoptr i64 %v895 to ptr
  %ld897 = load i64, ptr %p896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld897, ptr %slot149, align 8
  %v898 = load i64, ptr %slot149, align 8
  %v899 = load i64, ptr %slot22, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 %v898, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %p901 = inttoptr i64 ptrtoint (ptr @myl_lit_a2fef6855234220d4efe69d6d206ee3c11f5b0c2ac2ff07411d432d186d8f508 to i64) to ptr
  %ld902 = load i64, ptr %p901, align 8, !alias.scope !4, !noalias !3
  store i64 %ld902, ptr %slot150, align 8
  %v903 = load i64, ptr %slot150, align 8
  %v904 = load i64, ptr %slot23, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i64 %v903, ptr %p905, align 8, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot23, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i64, ptr %p907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld908, ptr %slot151, align 8
  %v909 = load i64, ptr %slot151, align 8
  %v910 = load i64, ptr %slot15, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i64 %v909, ptr %p911, align 8, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot15, align 8
  store i64 %v912, ptr %slot152, align 8
  %v913 = load i64, ptr %slot17, align 8
  store i64 %v913, ptr %slot153, align 8
  %v914 = load i64, ptr %slot152, align 8
  %v915 = load i64, ptr %slot153, align 8
  %p916 = inttoptr i64 %v914 to ptr
  %p917 = inttoptr i64 %v915 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p917, ptr %p916, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v918 = load i64, ptr %slot12, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 2, ptr %p919, align 4, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot11, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 1, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot13, align 8
  store i64 %v922, ptr %slot154, align 8
  %v923 = load i64, ptr %slot17, align 8
  store i64 %v923, ptr %slot155, align 8
  %v924 = load i64, ptr %slot155, align 8
  %v925 = load i64, ptr %slot154, align 8
  %p926 = inttoptr i64 %v924 to ptr
  %p927 = inttoptr i64 %v925 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p927, ptr %p926, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v928 = load i64, ptr %slot8, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i32 2, ptr %p929, align 4, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot12, align 8
  %p931 = inttoptr i64 %v930 to ptr
  %ld932 = load i32, ptr %p931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld932, ptr %slot156, align 8
  %v933 = load i32, ptr %slot156, align 8
  %v934 = load i64, ptr %slot8, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i32 %v933, ptr %p935, align 4, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot11, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i32 0, ptr %p937, align 4, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot7, align 8
  %p939 = inttoptr i64 %v938 to ptr
  store i32 1, ptr %p939, align 4, !alias.scope !3, !noalias !4
  %v940 = load i64, ptr %slot154, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i64, ptr %p941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld942, ptr %slot157, align 8
  %v943 = load i64, ptr %slot157, align 8
  %v944 = load i64, ptr %slot23, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i64 %v943, ptr %p945, align 8, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot22, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %ld948 = load i64, ptr %p947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld948, ptr %slot158, align 8
  %v949 = load i64, ptr %slot23, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ld951 = load i64, ptr %p950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld951, ptr %slot159, align 8
  %v952 = load i64, ptr %slot1, align 8
  %v953 = load i64, ptr %slot158, align 8
  %v954 = load i64, ptr %slot159, align 8
  %call955 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v952, i64 %v953, i64 %v954) nomerge, !dbg !126
  store i64 %call955, ptr %slot160, align 8
  %v956 = load i64, ptr %slot160, align 8
  %v957 = load i64, ptr %slot22, align 8
  %p958 = inttoptr i64 %v957 to ptr
  store i64 %v956, ptr %p958, align 8, !alias.scope !3, !noalias !4
  %v959 = load i64, ptr %slot7, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %ld961 = load i32, ptr %p960, align 4, !alias.scope !3, !noalias !4
  store i32 %ld961, ptr %slot161, align 8
  %v962 = load i32, ptr %slot161, align 8
  %cv963 = zext i32 %v962 to i64
  %cond964 = icmp ne i64 %cv963, 0
  br i1 %cond964, label %bb_rcslotdrop248, label %bb_rcslotdone248
bb_rcslotdrop248:
  %v965 = load i64, ptr %slot7, align 8
  %p966 = inttoptr i64 %v965 to ptr
  store i32 0, ptr %p966, align 4, !alias.scope !3, !noalias !4
  %v967 = load i64, ptr %slot13, align 8
  store i64 %v967, ptr %slot162, align 8
  %v968 = load i64, ptr %slot8, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %ld970 = load i32, ptr %p969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld970, ptr %slot163, align 8
  %v971 = load i32, ptr %slot163, align 8
  %op972 = and i32 %v971, 28
  store i32 %op972, ptr %slot164, align 8
  %v973 = load i32, ptr %slot164, align 8
  %cv974 = zext i32 %v973 to i64
  %cond975 = icmp ne i64 %cv974, 0
  br i1 %cond975, label %bb_rcslotrole248, label %bb_rcslotowner248
bb_rcslotrole248:
  %v976 = load i64, ptr %slot33, align 8
  store i64 %v976, ptr %slot165, align 8
  %v977 = load i64, ptr %slot162, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %ld979 = load i64, ptr %p978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld979, ptr %slot166, align 8
  %v980 = load i64, ptr %slot166, align 8
  %cmp981 = icmp ne i64 %v980, 0
  %cv982 = zext i1 %cmp981 to i32
  store i32 %cv982, ptr %slot167, align 8
  %v983 = load i32, ptr %slot167, align 8
  %cv984 = zext i32 %v983 to i64
  %cond985 = icmp ne i64 %cv984, 0
  br i1 %cond985, label %bb_rcgnn264, label %bb_rcgdone264
bb_rcgnn264:
  %v986 = load i64, ptr %slot166, align 8
  %op987 = sub i64 %v986, 16
  store i64 %op987, ptr %slot168, align 8
  %v988 = load i64, ptr %slot166, align 8
  %p989 = inttoptr i64 %v988 to ptr
  %rgep990 = getelementptr i8, ptr %p989, i64 -16
  %ld991 = load i64, ptr %rgep990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld991, ptr %slot169, align 8
  %v992 = load i64, ptr %slot169, align 8
  %op993 = and i64 %v992, 4611686018427387906
  store i64 %op993, ptr %slot170, align 8
  %v994 = load i64, ptr %slot170, align 8
  %cmp995 = icmp ne i64 %v994, 0
  %cv996 = zext i1 %cmp995 to i32
  store i32 %cv996, ptr %slot171, align 8
  %v997 = load i32, ptr %slot171, align 8
  %cv998 = zext i32 %v997 to i64
  %cond999 = icmp ne i64 %cv998, 0
  br i1 %cond999, label %bb_rcgclear264, label %bb_rcgcounted264
bb_rcgcounted264:
  %v1000 = load i64, ptr %slot166, align 8
  %op1001 = sub i64 %v1000, 24
  store i64 %op1001, ptr %slot172, align 8
  %v1002 = load i64, ptr %slot166, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  %rgep1004 = getelementptr i8, ptr %p1003, i64 -24
  %ld1005 = load i64, ptr %rgep1004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1005, ptr %slot173, align 8
  %v1006 = load i64, ptr %slot173, align 8
  %op1007 = sub i64 %v1006, 1
  store i64 %op1007, ptr %slot174, align 8
  %v1008 = load i64, ptr %slot174, align 8
  %cmp1009 = icmp eq i64 %v1008, 0
  %cv1010 = zext i1 %cmp1009 to i32
  store i32 %cv1010, ptr %slot175, align 8
  %v1011 = load i32, ptr %slot175, align 8
  %cv1012 = zext i32 %v1011 to i64
  %cond1013 = icmp ne i64 %cv1012, 0
  br i1 %cond1013, label %bb_rcglast264, label %bb_rcgdec264
bb_rcglast264:
  %v1014 = load i64, ptr %slot166, align 8
  %op1015 = sub i64 %v1014, 32
  store i64 %op1015, ptr %slot176, align 8
  %v1016 = load i64, ptr %slot166, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %rgep1018 = getelementptr i8, ptr %p1017, i64 -32
  %ld1019 = load i64, ptr %rgep1018, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1019, ptr %slot177, align 8
  %v1020 = load i64, ptr %slot177, align 8
  %cmp1021 = icmp ne i64 %v1020, 0
  %cv1022 = zext i1 %cmp1021 to i32
  store i32 %cv1022, ptr %slot178, align 8
  %v1023 = load i32, ptr %slot178, align 8
  %cv1024 = zext i32 %v1023 to i64
  %cond1025 = icmp ne i64 %cv1024, 0
  br i1 %cond1025, label %bb_rcgdec264, label %bb_rcgslow264
bb_rcgslow264:
  %v1026 = load i64, ptr %slot165, align 8
  %v1027 = load i64, ptr %slot162, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1026, i64 %v1027) nomerge, !dbg !126
  br label %bb_rcgdone264
bb_rcgdec264:
  %v1028 = load i64, ptr %slot174, align 8
  %v1029 = load i64, ptr %slot166, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  %rgep1031 = getelementptr i8, ptr %p1030, i64 -24
  store i64 %v1028, ptr %rgep1031, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear264
bb_rcgclear264:
  %v1032 = load i64, ptr %slot162, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i64 0, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone264
bb_rcgdone264:
  br label %bb_rcslotdone248
bb_rcslotowner248:
  %v1034 = load i64, ptr %slot33, align 8
  store i64 %v1034, ptr %slot179, align 8
  %v1035 = load i64, ptr %slot162, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i64, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1037, ptr %slot180, align 8
  %v1038 = load i64, ptr %slot180, align 8
  %cmp1039 = icmp ne i64 %v1038, 0
  %cv1040 = zext i1 %cmp1039 to i32
  store i32 %cv1040, ptr %slot181, align 8
  %v1041 = load i32, ptr %slot181, align 8
  %cv1042 = zext i32 %v1041 to i64
  %cond1043 = icmp ne i64 %cv1042, 0
  br i1 %cond1043, label %bb_rcgnn279, label %bb_rcgdone279
bb_rcgnn279:
  %v1044 = load i64, ptr %slot180, align 8
  %op1045 = sub i64 %v1044, 16
  store i64 %op1045, ptr %slot182, align 8
  %v1046 = load i64, ptr %slot180, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %rgep1048 = getelementptr i8, ptr %p1047, i64 -16
  %ld1049 = load i64, ptr %rgep1048, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1049, ptr %slot183, align 8
  %v1050 = load i64, ptr %slot183, align 8
  %op1051 = and i64 %v1050, 4611686018427387906
  store i64 %op1051, ptr %slot184, align 8
  %v1052 = load i64, ptr %slot184, align 8
  %cmp1053 = icmp ne i64 %v1052, 0
  %cv1054 = zext i1 %cmp1053 to i32
  store i32 %cv1054, ptr %slot185, align 8
  %v1055 = load i32, ptr %slot185, align 8
  %cv1056 = zext i32 %v1055 to i64
  %cond1057 = icmp ne i64 %cv1056, 0
  br i1 %cond1057, label %bb_rcgclear279, label %bb_rcgcounted279
bb_rcgcounted279:
  %v1058 = load i64, ptr %slot180, align 8
  %op1059 = sub i64 %v1058, 32
  store i64 %op1059, ptr %slot186, align 8
  %v1060 = load i64, ptr %slot180, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %rgep1062 = getelementptr i8, ptr %p1061, i64 -32
  %ld1063 = load i64, ptr %rgep1062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1063, ptr %slot187, align 8
  %v1064 = load i64, ptr %slot187, align 8
  %op1065 = sub i64 %v1064, 1
  store i64 %op1065, ptr %slot188, align 8
  %v1066 = load i64, ptr %slot188, align 8
  %cmp1067 = icmp eq i64 %v1066, 0
  %cv1068 = zext i1 %cmp1067 to i32
  store i32 %cv1068, ptr %slot189, align 8
  %v1069 = load i32, ptr %slot189, align 8
  %cv1070 = zext i32 %v1069 to i64
  %cond1071 = icmp ne i64 %cv1070, 0
  br i1 %cond1071, label %bb_rcglast279, label %bb_rcgdec279
bb_rcglast279:
  %v1072 = load i64, ptr %slot180, align 8
  %op1073 = sub i64 %v1072, 24
  store i64 %op1073, ptr %slot190, align 8
  %v1074 = load i64, ptr %slot180, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  %rgep1076 = getelementptr i8, ptr %p1075, i64 -24
  %ld1077 = load i64, ptr %rgep1076, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1077, ptr %slot191, align 8
  %v1078 = load i64, ptr %slot191, align 8
  %cmp1079 = icmp ne i64 %v1078, 0
  %cv1080 = zext i1 %cmp1079 to i32
  store i32 %cv1080, ptr %slot192, align 8
  %v1081 = load i32, ptr %slot192, align 8
  %cv1082 = zext i32 %v1081 to i64
  %cond1083 = icmp ne i64 %cv1082, 0
  br i1 %cond1083, label %bb_rcgdec279, label %bb_rcgslow279
bb_rcgslow279:
  %v1084 = load i64, ptr %slot179, align 8
  %v1085 = load i64, ptr %slot162, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1084, i64 %v1085) nomerge, !dbg !126
  br label %bb_rcgdone279
bb_rcgdec279:
  %v1086 = load i64, ptr %slot188, align 8
  %v1087 = load i64, ptr %slot180, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %rgep1089 = getelementptr i8, ptr %p1088, i64 -32
  store i64 %v1086, ptr %rgep1089, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear279
bb_rcgclear279:
  %v1090 = load i64, ptr %slot162, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  store i64 0, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone279
bb_rcgdone279:
  br label %bb_rcslotdone248
bb_rcslotdone248:
  br label %bb_i44
bb_i44:
  %v1092 = load i64, ptr %slot19, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i64, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1094, ptr %slot193, align 8
  %v1095 = load i64, ptr %slot193, align 8
  %v1096 = load i64, ptr %slot22, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  store i64 %v1095, ptr %p1097, align 8, !alias.scope !3, !noalias !4
  %v1098 = load i64, ptr %slot23, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i64 1, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  %v1100 = load i64, ptr %slot23, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i64, ptr %p1101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1102, ptr %slot194, align 8
  %v1103 = load i64, ptr %slot22, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %ld1105 = load i64, ptr %p1104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1105, ptr %slot195, align 8
  %v1106 = load i64, ptr %slot195, align 8
  %v1107 = load i64, ptr %slot194, align 8
  %ovpair1109 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1106, i64 %v1107)
  %op1108 = extractvalue { i64, i1 } %ovpair1109, 0
  %ov1110 = extractvalue { i64, i1 } %ovpair1109, 1
  store i64 %op1108, ptr %slot196, align 8
  %cv1111 = zext i1 %ov1110 to i64
  store i64 %cv1111, ptr %slot197, align 8
  %v1112 = load i64, ptr %slot197, align 8
  %cond1113 = icmp ne i64 %v1112, 0
  br i1 %cond1113, label %bb_overflow286, label %bb_checked286
bb_overflow286:
  %v1114 = load i64, ptr %slot1, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  %v1116 = load i64, ptr %slot195, align 8
  %v1117 = load i64, ptr %slot194, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1115, i64 0, i64 %v1116, i64 %v1117, i64 64) nomerge, !dbg !128
  unreachable
bb_checked286:
  %v1118 = load i64, ptr %slot196, align 8
  %v1119 = load i64, ptr %slot22, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  store i64 %v1118, ptr %p1120, align 8, !alias.scope !3, !noalias !4
  %v1121 = load i64, ptr %slot22, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  %ld1123 = load i64, ptr %p1122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1123, ptr %slot198, align 8
  %v1124 = load i64, ptr %slot198, align 8
  %v1125 = load i64, ptr %slot19, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i64 %v1124, ptr %p1126, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i49:
  %v1127 = load i64, ptr %slot18, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  %ld1129 = load i64, ptr %p1128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1129, ptr %slot199, align 8
  %v1130 = load i64, ptr %slot199, align 8
  %v1131 = load i64, ptr %slot22, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  store i64 %v1130, ptr %p1132, align 8, !alias.scope !3, !noalias !4
  %v1133 = load i64, ptr %slot28, align 8
  store i64 %v1133, ptr %slot200, align 8
  %v1134 = load i64, ptr %slot200, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i32 0, ptr %p1135, align 4, !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot200, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  store i32 1, ptr %p1137, align 4, !alias.scope !3, !noalias !4
  %v1138 = load i64, ptr %slot200, align 8
  %v1139 = load i64, ptr %slot23, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  store i64 %v1138, ptr %p1140, align 8, !alias.scope !3, !noalias !4
  %p1141 = inttoptr i64 ptrtoint (ptr @myl_lit_35d41e0b6aa3a58cd0db1d8c7a982e8b15477d856cb7b6bc9404d8afd095ed9e to i64) to ptr
  %ld1142 = load i64, ptr %p1141, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1142, ptr %slot201, align 8
  %v1143 = load i64, ptr %slot201, align 8
  %v1144 = load i64, ptr %slot24, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i64 %v1143, ptr %p1145, align 8, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot24, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1148, ptr %slot202, align 8
  %v1149 = load i64, ptr %slot202, align 8
  %v1150 = load i64, ptr %slot16, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i64 %v1149, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot16, align 8
  store i64 %v1152, ptr %slot203, align 8
  %v1153 = load i64, ptr %slot17, align 8
  store i64 %v1153, ptr %slot204, align 8
  %v1154 = load i64, ptr %slot203, align 8
  %v1155 = load i64, ptr %slot204, align 8
  %p1156 = inttoptr i64 %v1154 to ptr
  %p1157 = inttoptr i64 %v1155 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1157, ptr %p1156, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot12, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  store i32 2, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  %v1160 = load i64, ptr %slot11, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i32 1, ptr %p1161, align 4, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot14, align 8
  store i64 %v1162, ptr %slot205, align 8
  %v1163 = load i64, ptr %slot17, align 8
  store i64 %v1163, ptr %slot206, align 8
  %v1164 = load i64, ptr %slot206, align 8
  %v1165 = load i64, ptr %slot205, align 8
  %p1166 = inttoptr i64 %v1164 to ptr
  %p1167 = inttoptr i64 %v1165 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1167, ptr %p1166, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1168 = load i64, ptr %slot10, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i32 2, ptr %p1169, align 4, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot12, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  %ld1172 = load i32, ptr %p1171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1172, ptr %slot207, align 8
  %v1173 = load i32, ptr %slot207, align 8
  %v1174 = load i64, ptr %slot10, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i32 %v1173, ptr %p1175, align 4, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot11, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 0, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot9, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 1, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot205, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  %ld1182 = load i64, ptr %p1181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1182, ptr %slot208, align 8
  %v1183 = load i64, ptr %slot208, align 8
  %v1184 = load i64, ptr %slot24, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i64 %v1183, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot22, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i64, ptr %p1187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1188, ptr %slot209, align 8
  %v1189 = load i64, ptr %slot23, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i64, ptr %p1190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1191, ptr %slot210, align 8
  %v1192 = load i64, ptr %slot24, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i64, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1194, ptr %slot211, align 8
  %v1195 = load i64, ptr %slot1, align 8
  %v1196 = load i64, ptr %slot209, align 8
  %v1197 = load i64, ptr %slot210, align 8
  %v1198 = load i64, ptr %slot211, align 8
  %call1199 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v1195, i64 %v1196, i64 %v1197, i64 %v1198) nomerge, !dbg !130
  store i64 %call1199, ptr %slot212, align 8
  %v1200 = load i64, ptr %slot212, align 8
  %v1201 = load i64, ptr %slot22, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i64 %v1200, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot9, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  %ld1205 = load i32, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1205, ptr %slot213, align 8
  %v1206 = load i32, ptr %slot213, align 8
  %cv1207 = zext i32 %v1206 to i64
  %cond1208 = icmp ne i64 %cv1207, 0
  br i1 %cond1208, label %bb_rcslotdrop322, label %bb_rcslotdone322
bb_rcslotdrop322:
  %v1209 = load i64, ptr %slot9, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i32 0, ptr %p1210, align 4, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot14, align 8
  store i64 %v1211, ptr %slot214, align 8
  %v1212 = load i64, ptr %slot10, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %ld1214 = load i32, ptr %p1213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1214, ptr %slot215, align 8
  %v1215 = load i32, ptr %slot215, align 8
  %op1216 = and i32 %v1215, 28
  store i32 %op1216, ptr %slot216, align 8
  %v1217 = load i32, ptr %slot216, align 8
  %cv1218 = zext i32 %v1217 to i64
  %cond1219 = icmp ne i64 %cv1218, 0
  br i1 %cond1219, label %bb_rcslotrole322, label %bb_rcslotowner322
bb_rcslotrole322:
  %v1220 = load i64, ptr %slot33, align 8
  store i64 %v1220, ptr %slot217, align 8
  %v1221 = load i64, ptr %slot214, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  %ld1223 = load i64, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1223, ptr %slot218, align 8
  %v1224 = load i64, ptr %slot218, align 8
  %cmp1225 = icmp ne i64 %v1224, 0
  %cv1226 = zext i1 %cmp1225 to i32
  store i32 %cv1226, ptr %slot219, align 8
  %v1227 = load i32, ptr %slot219, align 8
  %cv1228 = zext i32 %v1227 to i64
  %cond1229 = icmp ne i64 %cv1228, 0
  br i1 %cond1229, label %bb_rcgnn338, label %bb_rcgdone338
bb_rcgnn338:
  %v1230 = load i64, ptr %slot218, align 8
  %op1231 = sub i64 %v1230, 16
  store i64 %op1231, ptr %slot220, align 8
  %v1232 = load i64, ptr %slot218, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  %rgep1234 = getelementptr i8, ptr %p1233, i64 -16
  %ld1235 = load i64, ptr %rgep1234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1235, ptr %slot221, align 8
  %v1236 = load i64, ptr %slot221, align 8
  %op1237 = and i64 %v1236, 4611686018427387906
  store i64 %op1237, ptr %slot222, align 8
  %v1238 = load i64, ptr %slot222, align 8
  %cmp1239 = icmp ne i64 %v1238, 0
  %cv1240 = zext i1 %cmp1239 to i32
  store i32 %cv1240, ptr %slot223, align 8
  %v1241 = load i32, ptr %slot223, align 8
  %cv1242 = zext i32 %v1241 to i64
  %cond1243 = icmp ne i64 %cv1242, 0
  br i1 %cond1243, label %bb_rcgclear338, label %bb_rcgcounted338
bb_rcgcounted338:
  %v1244 = load i64, ptr %slot218, align 8
  %op1245 = sub i64 %v1244, 24
  store i64 %op1245, ptr %slot224, align 8
  %v1246 = load i64, ptr %slot218, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  %rgep1248 = getelementptr i8, ptr %p1247, i64 -24
  %ld1249 = load i64, ptr %rgep1248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1249, ptr %slot225, align 8
  %v1250 = load i64, ptr %slot225, align 8
  %op1251 = sub i64 %v1250, 1
  store i64 %op1251, ptr %slot226, align 8
  %v1252 = load i64, ptr %slot226, align 8
  %cmp1253 = icmp eq i64 %v1252, 0
  %cv1254 = zext i1 %cmp1253 to i32
  store i32 %cv1254, ptr %slot227, align 8
  %v1255 = load i32, ptr %slot227, align 8
  %cv1256 = zext i32 %v1255 to i64
  %cond1257 = icmp ne i64 %cv1256, 0
  br i1 %cond1257, label %bb_rcglast338, label %bb_rcgdec338
bb_rcglast338:
  %v1258 = load i64, ptr %slot218, align 8
  %op1259 = sub i64 %v1258, 32
  store i64 %op1259, ptr %slot228, align 8
  %v1260 = load i64, ptr %slot218, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %rgep1262 = getelementptr i8, ptr %p1261, i64 -32
  %ld1263 = load i64, ptr %rgep1262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1263, ptr %slot229, align 8
  %v1264 = load i64, ptr %slot229, align 8
  %cmp1265 = icmp ne i64 %v1264, 0
  %cv1266 = zext i1 %cmp1265 to i32
  store i32 %cv1266, ptr %slot230, align 8
  %v1267 = load i32, ptr %slot230, align 8
  %cv1268 = zext i32 %v1267 to i64
  %cond1269 = icmp ne i64 %cv1268, 0
  br i1 %cond1269, label %bb_rcgdec338, label %bb_rcgslow338
bb_rcgslow338:
  %v1270 = load i64, ptr %slot217, align 8
  %v1271 = load i64, ptr %slot214, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1270, i64 %v1271) nomerge, !dbg !130
  br label %bb_rcgdone338
bb_rcgdec338:
  %v1272 = load i64, ptr %slot226, align 8
  %v1273 = load i64, ptr %slot218, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  %rgep1275 = getelementptr i8, ptr %p1274, i64 -24
  store i64 %v1272, ptr %rgep1275, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear338
bb_rcgclear338:
  %v1276 = load i64, ptr %slot214, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i64 0, ptr %p1277, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone338
bb_rcgdone338:
  br label %bb_rcslotdone322
bb_rcslotowner322:
  %v1278 = load i64, ptr %slot33, align 8
  store i64 %v1278, ptr %slot231, align 8
  %v1279 = load i64, ptr %slot214, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %ld1281 = load i64, ptr %p1280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1281, ptr %slot232, align 8
  %v1282 = load i64, ptr %slot232, align 8
  %cmp1283 = icmp ne i64 %v1282, 0
  %cv1284 = zext i1 %cmp1283 to i32
  store i32 %cv1284, ptr %slot233, align 8
  %v1285 = load i32, ptr %slot233, align 8
  %cv1286 = zext i32 %v1285 to i64
  %cond1287 = icmp ne i64 %cv1286, 0
  br i1 %cond1287, label %bb_rcgnn353, label %bb_rcgdone353
bb_rcgnn353:
  %v1288 = load i64, ptr %slot232, align 8
  %op1289 = sub i64 %v1288, 16
  store i64 %op1289, ptr %slot234, align 8
  %v1290 = load i64, ptr %slot232, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  %rgep1292 = getelementptr i8, ptr %p1291, i64 -16
  %ld1293 = load i64, ptr %rgep1292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1293, ptr %slot235, align 8
  %v1294 = load i64, ptr %slot235, align 8
  %op1295 = and i64 %v1294, 4611686018427387906
  store i64 %op1295, ptr %slot236, align 8
  %v1296 = load i64, ptr %slot236, align 8
  %cmp1297 = icmp ne i64 %v1296, 0
  %cv1298 = zext i1 %cmp1297 to i32
  store i32 %cv1298, ptr %slot237, align 8
  %v1299 = load i32, ptr %slot237, align 8
  %cv1300 = zext i32 %v1299 to i64
  %cond1301 = icmp ne i64 %cv1300, 0
  br i1 %cond1301, label %bb_rcgclear353, label %bb_rcgcounted353
bb_rcgcounted353:
  %v1302 = load i64, ptr %slot232, align 8
  %op1303 = sub i64 %v1302, 32
  store i64 %op1303, ptr %slot238, align 8
  %v1304 = load i64, ptr %slot232, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  %rgep1306 = getelementptr i8, ptr %p1305, i64 -32
  %ld1307 = load i64, ptr %rgep1306, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1307, ptr %slot239, align 8
  %v1308 = load i64, ptr %slot239, align 8
  %op1309 = sub i64 %v1308, 1
  store i64 %op1309, ptr %slot240, align 8
  %v1310 = load i64, ptr %slot240, align 8
  %cmp1311 = icmp eq i64 %v1310, 0
  %cv1312 = zext i1 %cmp1311 to i32
  store i32 %cv1312, ptr %slot241, align 8
  %v1313 = load i32, ptr %slot241, align 8
  %cv1314 = zext i32 %v1313 to i64
  %cond1315 = icmp ne i64 %cv1314, 0
  br i1 %cond1315, label %bb_rcglast353, label %bb_rcgdec353
bb_rcglast353:
  %v1316 = load i64, ptr %slot232, align 8
  %op1317 = sub i64 %v1316, 24
  store i64 %op1317, ptr %slot242, align 8
  %v1318 = load i64, ptr %slot232, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %rgep1320 = getelementptr i8, ptr %p1319, i64 -24
  %ld1321 = load i64, ptr %rgep1320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1321, ptr %slot243, align 8
  %v1322 = load i64, ptr %slot243, align 8
  %cmp1323 = icmp ne i64 %v1322, 0
  %cv1324 = zext i1 %cmp1323 to i32
  store i32 %cv1324, ptr %slot244, align 8
  %v1325 = load i32, ptr %slot244, align 8
  %cv1326 = zext i32 %v1325 to i64
  %cond1327 = icmp ne i64 %cv1326, 0
  br i1 %cond1327, label %bb_rcgdec353, label %bb_rcgslow353
bb_rcgslow353:
  %v1328 = load i64, ptr %slot231, align 8
  %v1329 = load i64, ptr %slot214, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1328, i64 %v1329) nomerge, !dbg !130
  br label %bb_rcgdone353
bb_rcgdec353:
  %v1330 = load i64, ptr %slot240, align 8
  %v1331 = load i64, ptr %slot232, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %rgep1333 = getelementptr i8, ptr %p1332, i64 -32
  store i64 %v1330, ptr %rgep1333, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear353
bb_rcgclear353:
  %v1334 = load i64, ptr %slot214, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i64 0, ptr %p1335, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone353
bb_rcgdone353:
  br label %bb_rcslotdone322
bb_rcslotdone322:
  %v1336 = load i64, ptr %slot19, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %ld1338 = load i64, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1338, ptr %slot245, align 8
  %v1339 = load i64, ptr %slot245, align 8
  %v1340 = load i64, ptr %slot22, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i64 %v1339, ptr %p1341, align 8, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot22, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i64, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1344, ptr %slot246, align 8
  %v1345 = load i64, ptr %slot4, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i32, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1347, ptr %slot247, align 8
  %v1348 = load i32, ptr %slot247, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcslotdrop364, label %bb_rcslotdone364
bb_rcslotdrop364:
  %v1351 = load i64, ptr %slot4, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i32 0, ptr %p1352, align 4, !alias.scope !3, !noalias !4
  %v1353 = load i64, ptr %slot20, align 8
  store i64 %v1353, ptr %slot248, align 8
  %v1354 = load i64, ptr %slot5, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  %ld1356 = load i32, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1356, ptr %slot249, align 8
  %v1357 = load i32, ptr %slot249, align 8
  %op1358 = and i32 %v1357, 28
  store i32 %op1358, ptr %slot250, align 8
  %v1359 = load i32, ptr %slot250, align 8
  %cv1360 = zext i32 %v1359 to i64
  %cond1361 = icmp ne i64 %cv1360, 0
  br i1 %cond1361, label %bb_rcslotrole364, label %bb_rcslotowner364
bb_rcslotrole364:
  %v1362 = load i64, ptr %slot33, align 8
  store i64 %v1362, ptr %slot251, align 8
  %v1363 = load i64, ptr %slot251, align 8
  %v1364 = load i64, ptr %slot248, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1363, i64 %v1364) nomerge, !dbg !132
  br label %bb_rcslotdone364
bb_rcslotowner364:
  %v1365 = load i64, ptr %slot33, align 8
  store i64 %v1365, ptr %slot252, align 8
  %v1366 = load i64, ptr %slot252, align 8
  %v1367 = load i64, ptr %slot248, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1366, i64 %v1367) nomerge, !dbg !132
  br label %bb_rcslotdone364
bb_rcslotdone364:
  %v1368 = load i64, ptr %slot246, align 8
  ret i64 %v1368
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_35d41e0b6aa3a58cd0db1d8c7a982e8b15477d856cb7b6bc9404d8afd095ed9e = external global i8, align 8
@myl_lit_a2fef6855234220d4efe69d6d206ee3c11f5b0c2ac2ff07411d432d186d8f508 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64, i64, i64)
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64, i64, i64, i32)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281", linkageName: "myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7074070750980245065, i64 0, !"myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!116 = !DILocation(line: 16, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!118 = !DILocation(line: 24, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!120 = !DILocation(line: 28, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!122 = !DILocation(line: 32, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!124 = !DILocation(line: 35, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!126 = !DILocation(line: 43, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!128 = !DILocation(line: 47, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!130 = !DILocation(line: 53, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!132 = !DILocation(line: 56, column: 0, scope: !133)
