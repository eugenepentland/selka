target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v43 = load i64, ptr %slot1, align 8
  %op44 = add i64 %v43, 32
  store i64 %op44, ptr %slot5, align 8
  %mem45 = alloca i8, i64 8, align 8
  %ptr46 = ptrtoint ptr %mem45 to i64
  store i64 %ptr46, ptr %slot6, align 8
  %mem47 = alloca i8, i64 8, align 8
  %ptr48 = ptrtoint ptr %mem47 to i64
  store i64 %ptr48, ptr %slot7, align 8
  %mem49 = alloca i8, i64 8, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot8, align 8
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot9, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot10, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot11, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot12, align 8
  %v59 = load i64, ptr %slot1, align 8
  %op60 = add i64 %v59, 64
  store i64 %op60, ptr %slot13, align 8
  %v61 = load i64, ptr %slot13, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !4, !noalias !3
  store i64 %ld63, ptr %slot14, align 8
  %stack64 = call ptr @llvm.stacksave()
  %stackaddr65 = ptrtoint ptr %stack64 to i64
  %v66 = load i64, ptr %slot14, align 8
  %cmp67 = icmp ult i64 %stackaddr65, %v66
  %cv68 = zext i1 %cmp67 to i64
  store i64 %cv68, ptr %slot15, align 8
  %v69 = load i64, ptr %slot15, align 8
  %cond70 = icmp ne i64 %v69, 0
  br i1 %cond70, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v71 = load i64, ptr %slot1, align 8
  %p72 = inttoptr i64 %v71 to ptr
  call void @myl_qbe_fail_frame(ptr %p72) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v73 = load i64, ptr %slot2, align 8
  %v74 = load i64, ptr %slot6, align 8
  %p75 = inttoptr i64 %v74 to ptr
  store i64 %v73, ptr %p75, align 8, !alias.scope !3, !noalias !4
  %v76 = load i64, ptr %slot3, align 8
  %v77 = load i64, ptr %slot7, align 8
  %p78 = inttoptr i64 %v77 to ptr
  store i64 %v76, ptr %p78, align 8, !alias.scope !3, !noalias !4
  %v79 = load i64, ptr %slot4, align 8
  %v80 = load i64, ptr %slot8, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i64 %v79, ptr %p81, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v82 = load i64, ptr %slot6, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot16, align 8
  %v85 = load i64, ptr %slot16, align 8
  %v86 = load i64, ptr %slot10, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot10, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot17, align 8
  %v91 = load i64, ptr %slot17, align 8
  %op92 = add i64 %v91, 128
  store i64 %op92, ptr %slot18, align 8
  %v93 = load i64, ptr %slot18, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !4, !noalias !3
  store i64 %ld95, ptr %slot19, align 8
  %v96 = load i64, ptr %slot19, align 8
  %v97 = load i64, ptr %slot10, align 8
  %p98 = inttoptr i64 %v97 to ptr
  store i64 %v96, ptr %p98, align 8, !alias.scope !3, !noalias !4
  %v99 = load i64, ptr %slot7, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %ld101 = load i64, ptr %p100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld101, ptr %slot20, align 8
  %v102 = load i64, ptr %slot20, align 8
  %v103 = load i64, ptr %slot11, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !3, !noalias !4
  %v105 = load i64, ptr %slot11, align 8
  %p106 = inttoptr i64 %v105 to ptr
  %ld107 = load i64, ptr %p106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld107, ptr %slot21, align 8
  %v108 = load i64, ptr %slot10, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot22, align 8
  %v111 = load i64, ptr %slot22, align 8
  %v112 = load i64, ptr %slot21, align 8
  %ovpair114 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v111, i64 %v112)
  %op113 = extractvalue { i64, i1 } %ovpair114, 0
  %ov115 = extractvalue { i64, i1 } %ovpair114, 1
  store i64 %op113, ptr %slot23, align 8
  %v116 = load i64, ptr %slot22, align 8
  %v117 = load i64, ptr %slot21, align 8
  %op118 = xor i64 %v116, %v117
  store i64 %op118, ptr %slot24, align 8
  %v119 = load i64, ptr %slot22, align 8
  %v120 = load i64, ptr %slot23, align 8
  %op121 = xor i64 %v119, %v120
  store i64 %op121, ptr %slot25, align 8
  %v122 = load i64, ptr %slot24, align 8
  %v123 = load i64, ptr %slot25, align 8
  %op124 = and i64 %v122, %v123
  store i64 %op124, ptr %slot26, align 8
  %cv125 = zext i1 %ov115 to i64
  store i64 %cv125, ptr %slot27, align 8
  %v126 = load i64, ptr %slot27, align 8
  %cond127 = icmp ne i64 %v126, 0
  br i1 %cond127, label %bb_overflow25, label %bb_checked25
bb_overflow25:
  %v128 = load i64, ptr %slot1, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %v130 = load i64, ptr %slot22, align 8
  %v131 = load i64, ptr %slot21, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p129, i64 1, i64 %v130, i64 %v131, i64 64) nomerge, !dbg !112
  unreachable
bb_checked25:
  %v132 = load i64, ptr %slot23, align 8
  %v133 = load i64, ptr %slot10, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot10, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot28, align 8
  %v138 = load i64, ptr %slot28, align 8
  %v139 = load i64, ptr %slot9, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i64 %v138, ptr %p140, align 8, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot6, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld143, ptr %slot29, align 8
  %v144 = load i64, ptr %slot29, align 8
  %v145 = load i64, ptr %slot10, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot6, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot30, align 8
  %v150 = load i64, ptr %slot30, align 8
  %v151 = load i64, ptr %slot10, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot6, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %ld155 = load i64, ptr %p154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld155, ptr %slot31, align 8
  %v156 = load i64, ptr %slot31, align 8
  %v157 = load i64, ptr %slot10, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 %v156, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot9, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld161, ptr %slot32, align 8
  %v162 = load i64, ptr %slot32, align 8
  %v163 = load i64, ptr %slot11, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot6, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot33, align 8
  %v168 = load i64, ptr %slot33, align 8
  %v169 = load i64, ptr %slot10, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot9, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot34, align 8
  %v174 = load i64, ptr %slot6, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot35, align 8
  %v177 = load i64, ptr %slot35, align 8
  %op178 = add i64 %v177, 128
  store i64 %op178, ptr %slot36, align 8
  %v179 = load i64, ptr %slot34, align 8
  %v180 = load i64, ptr %slot36, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i64 %v179, ptr %p181, align 8, !alias.scope !4, !noalias !3
  %v182 = load i64, ptr %slot10, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 0, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot6, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot37, align 8
  %v187 = load i64, ptr %slot37, align 8
  %v188 = load i64, ptr %slot10, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot8, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot38, align 8
  %v193 = load i64, ptr %slot38, align 8
  %v194 = load i64, ptr %slot11, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot10, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot39, align 8
  %v199 = load i64, ptr %slot11, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot40, align 8
  %v202 = load i64, ptr %slot1, align 8
  %v203 = load i64, ptr %slot39, align 8
  %v204 = load i64, ptr %slot40, align 8
  %call205 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v202, i64 %v203, i64 %v204) nomerge, !dbg !114
  store i64 %call205, ptr %slot41, align 8
  %v206 = load i64, ptr %slot41, align 8
  %v207 = load i64, ptr %slot10, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i64 %v206, ptr %p208, align 8, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot10, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 0, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot10, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot42, align 8
  %v214 = load i64, ptr %slot42, align 8
  ret i64 %v214
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8", linkageName: "myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5084228588742097163, i64 0, !"myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!114 = !DILocation(line: 18, column: 0, scope: !115)
