target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %callresult24 = alloca [16 x i8], align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v46 = load i64, ptr %slot1, align 8
  %op47 = add i64 %v46, 32
  store i64 %op47, ptr %slot3, align 8
  %mem48 = alloca i8, i64 16, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot4, align 8
  %mem50 = alloca i8, i64 8, align 8
  %ptr51 = ptrtoint ptr %mem50 to i64
  store i64 %ptr51, ptr %slot5, align 8
  %mem52 = alloca i8, i64 8, align 8
  %ptr53 = ptrtoint ptr %mem52 to i64
  store i64 %ptr53, ptr %slot6, align 8
  %mem54 = alloca i8, i64 8, align 8
  %ptr55 = ptrtoint ptr %mem54 to i64
  store i64 %ptr55, ptr %slot7, align 8
  %mem56 = alloca i8, i64 8, align 8
  %ptr57 = ptrtoint ptr %mem56 to i64
  store i64 %ptr57, ptr %slot8, align 8
  %mem58 = alloca i8, i64 16, align 8
  %ptr59 = ptrtoint ptr %mem58 to i64
  store i64 %ptr59, ptr %slot9, align 8
  %mem60 = alloca i8, i64 16, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot10, align 8
  %mem62 = alloca i8, i64 8, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot11, align 8
  %mem64 = alloca i8, i64 8, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot12, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot13, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot1, align 8
  %op71 = add i64 %v70, 64
  store i64 %op71, ptr %slot15, align 8
  %v72 = load i64, ptr %slot15, align 8
  %p73 = inttoptr i64 %v72 to ptr
  %ld74 = load i64, ptr %p73, align 8, !alias.scope !4, !noalias !3
  store i64 %ld74, ptr %slot16, align 8
  %stack75 = call ptr @llvm.stacksave()
  %stackaddr76 = ptrtoint ptr %stack75 to i64
  %v77 = load i64, ptr %slot16, align 8
  %cmp78 = icmp ult i64 %stackaddr76, %v77
  %cv79 = zext i1 %cmp78 to i64
  store i64 %cv79, ptr %slot17, align 8
  %v80 = load i64, ptr %slot17, align 8
  %cond81 = icmp ne i64 %v80, 0
  br i1 %cond81, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v82 = load i64, ptr %slot1, align 8
  %p83 = inttoptr i64 %v82 to ptr
  call void @myl_qbe_fail_frame(ptr %p83) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v84 = load i64, ptr %slot2, align 8
  %v85 = load i64, ptr %slot11, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  %v87 = load i64, ptr %slot1, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %call89 = call ptr @myl_qbe_heap(ptr %p88) nomerge, !dbg !112
  %calladdr90 = ptrtoint ptr %call89 to i64
  store i64 %calladdr90, ptr %slot18, align 8
  %v91 = load i64, ptr %slot1, align 8
  %p92 = inttoptr i64 %v91 to ptr
  %call93 = call i64 @myl_qbe_region_mark(ptr %p92) nomerge, !dbg !112
  store i64 %call93, ptr %slot19, align 8
  %v94 = load i64, ptr %slot5, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i32 0, ptr %p95, align 4, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot6, align 8
  %p97 = inttoptr i64 %v96 to ptr
  store i32 0, ptr %p97, align 4, !alias.scope !3, !noalias !4
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i32 0, ptr %p99, align 4, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot8, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i32 0, ptr %p101, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v102 = load i64, ptr %slot11, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld104, ptr %slot20, align 8
  %v105 = load i64, ptr %slot20, align 8
  %v106 = load i64, ptr %slot12, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 %v105, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot13, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 1000000000, ptr %p109, align 8, !alias.scope !3, !noalias !4
  %v110 = load i64, ptr %slot12, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot21, align 8
  %v113 = load i64, ptr %slot13, align 8
  %p114 = inttoptr i64 %v113 to ptr
  %ld115 = load i64, ptr %p114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld115, ptr %slot22, align 8
  %v116 = load i64, ptr %slot1, align 8
  %v117 = load i64, ptr %slot21, align 8
  %v118 = load i64, ptr %slot22, align 8
  %call119 = call { i64, i64 } @myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee(i64 %v116, i64 %v117, i64 %v118) nomerge, !dbg !114
  store { i64, i64 } %call119, ptr %callresult24, align 8
  %addr120 = ptrtoint ptr %callresult24 to i64
  store i64 %addr120, ptr %slot23, align 8
  %v121 = load i64, ptr %slot23, align 8
  %v122 = load i64, ptr %slot12, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i64 %v121, ptr %p123, align 8, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot12, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld126, ptr %slot25, align 8
  %v127 = load i64, ptr %slot10, align 8
  store i64 %v127, ptr %slot26, align 8
  %v128 = load i64, ptr %slot25, align 8
  %v129 = load i64, ptr %slot26, align 8
  %p130 = inttoptr i64 %v128 to ptr
  %p131 = inttoptr i64 %v129 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p131, ptr %p130, i64 16, i1 false)
  %v132 = load i64, ptr %slot8, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i32 2, ptr %p133, align 4, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot7, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i32 1, ptr %p135, align 4, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot9, align 8
  store i64 %v136, ptr %slot27, align 8
  %v137 = load i64, ptr %slot10, align 8
  store i64 %v137, ptr %slot28, align 8
  %v138 = load i64, ptr %slot28, align 8
  %v139 = load i64, ptr %slot27, align 8
  %p140 = inttoptr i64 %v138 to ptr
  %p141 = inttoptr i64 %v139 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p141, ptr %p140, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v142 = load i64, ptr %slot6, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i32 2, ptr %p143, align 4, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot8, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i32, ptr %p145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld146, ptr %slot29, align 8
  %v147 = load i32, ptr %slot29, align 8
  %v148 = load i64, ptr %slot6, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i32 %v147, ptr %p149, align 4, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot7, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i32 0, ptr %p151, align 4, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot5, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i32 1, ptr %p153, align 4, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot27, align 8
  %v155 = load i64, ptr %slot12, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot12, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot30, align 8
  %v160 = load i64, ptr %slot30, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i32, ptr %p161, align 4, !alias.scope !3, !noalias !4
  %ext163 = zext i32 %ld162 to i64
  store i64 %ext163, ptr %slot31, align 8
  %v164 = load i64, ptr %slot31, align 8
  %cmp165 = icmp eq i64 %v164, 1
  %cv166 = zext i1 %cmp165 to i64
  store i64 %cv166, ptr %slot32, align 8
  %v167 = load i64, ptr %slot32, align 8
  %cond168 = icmp ne i64 %v167, 0
  br i1 %cond168, label %bb_errtrace25, label %bb_errtraced25
bb_errtrace25:
  %p169 = inttoptr i64 ptrtoint (ptr @myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p169, i64 8589934595) "call-inline-cost"="0", !dbg !116
  br label %bb_errtraced25
bb_errtraced25:
  %v170 = load i64, ptr %slot12, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld172, ptr %slot33, align 8
  %v173 = load i64, ptr %slot10, align 8
  store i64 %v173, ptr %slot34, align 8
  %v174 = load i64, ptr %slot19, align 8
  store i64 %v174, ptr %slot35, align 8
  %v175 = load i64, ptr %slot18, align 8
  %v176 = load i64, ptr %slot34, align 8
  %v177 = load i64, ptr %slot33, align 8
  %v178 = load i64, ptr %slot35, align 8
  %cv179 = trunc i64 %v178 to i32
  %call180 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v175, i64 %v176, i64 %v177, i32 %cv179) nomerge, !dbg !116
  store i32 %call180, ptr %slot36, align 8
  %v181 = load i32, ptr %slot36, align 8
  %cv182 = zext i32 %v181 to i64
  %cond183 = icmp ne i64 %cv182, 0
  br i1 %cond183, label %bb_rcsuccess30, label %bb_rcfailure30
bb_rcfailure30:
  %v184 = load i64, ptr %slot18, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %call186 = call i32 @myl_rc_take_failure(ptr %p185) nomerge, !dbg !116
  store i32 %call186, ptr %slot37, align 8
  %v187 = load i64, ptr %slot1, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %v189 = load i32, ptr %slot37, align 8
  %call190 = call i32 @myl_qbe_rc_status(ptr %p188, i32 %v189) nomerge, !dbg !116
  store i32 %call190, ptr %slot38, align 8
  br label %bb_failure
bb_rcsuccess30:
  %v191 = load i64, ptr %slot5, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i32 0, ptr %p192, align 4, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot8, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i32 2, ptr %p194, align 4, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot7, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i32 1, ptr %p196, align 4, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot10, align 8
  store i64 %v197, ptr %slot39, align 8
  %v198 = load i64, ptr %slot7, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i32 0, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot5, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i32, ptr %p201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld202, ptr %slot40, align 8
  %v203 = load i32, ptr %slot40, align 8
  %cv204 = zext i32 %v203 to i64
  %cond205 = icmp ne i64 %cv204, 0
  br i1 %cond205, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v206 = load i64, ptr %slot5, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i32 0, ptr %p207, align 4, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot9, align 8
  store i64 %v208, ptr %slot41, align 8
  %v209 = load i64, ptr %slot6, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i32, ptr %p210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld211, ptr %slot42, align 8
  %v212 = load i32, ptr %slot42, align 8
  %op213 = and i32 %v212, 28
  store i32 %op213, ptr %slot43, align 8
  %v214 = load i32, ptr %slot43, align 8
  %cv215 = zext i32 %v214 to i64
  %cond216 = icmp ne i64 %cv215, 0
  br i1 %cond216, label %bb_rcslotrole40, label %bb_rcslotowner40
bb_rcslotrole40:
  %v217 = load i64, ptr %slot18, align 8
  store i64 %v217, ptr %slot44, align 8
  %v218 = load i64, ptr %slot44, align 8
  %v219 = load i64, ptr %slot41, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v218, i64 %v219) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotowner40:
  %v220 = load i64, ptr %slot18, align 8
  store i64 %v220, ptr %slot45, align 8
  %v221 = load i64, ptr %slot45, align 8
  %v222 = load i64, ptr %slot41, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v221, i64 %v222) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v223 = load i64, ptr %slot39, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ret225 = load { i64, i64 }, ptr %p224, align 8
  ret { i64, i64 } %ret225
bb_failure:
  %v226 = load i64, ptr %slot4, align 8
  %p227 = inttoptr i64 %v226 to ptr
  call void @llvm.memset.p0.i64(ptr %p227, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v228 = load i64, ptr %slot4, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ret230 = load { i64, i64 }, ptr %p229, align 8
  ret { i64, i64 } %ret230
bb_entry_failure:
  %v231 = load i64, ptr %slot4, align 8
  %p232 = inttoptr i64 %v231 to ptr
  call void @llvm.memset.p0.i64(ptr %p232, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v233 = load i64, ptr %slot4, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ret235 = load { i64, i64 }, ptr %p234, align 8
  ret { i64, i64 } %ret235
}

@myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee(i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64, i64)
declare i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa", linkageName: "myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11608829077211318234, i64 0, !"myl_f_4777d77b441b87ca35e0abc3f6d3f8fda4da2b8517d1855d6bae7c7144cfdcfa"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
