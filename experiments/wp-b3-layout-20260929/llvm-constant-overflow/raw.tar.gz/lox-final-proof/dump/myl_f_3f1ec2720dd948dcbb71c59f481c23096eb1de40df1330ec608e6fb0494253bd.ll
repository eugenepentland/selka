target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %callresult24 = alloca [88 x i8], align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v74 = load i64, ptr %slot1, align 8
  %op75 = add i64 %v74, 32
  store i64 %op75, ptr %slot4, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot5, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot6, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot7, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot8, align 8
  %mem84 = alloca i8, i64 392, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot9, align 8
  %mem86 = alloca i8, i64 392, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot10, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot11, align 8
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot12, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot13, align 8
  %mem94 = alloca i8, i64 8, align 8
  %ptr95 = ptrtoint ptr %mem94 to i64
  store i64 %ptr95, ptr %slot14, align 8
  %mem96 = alloca i8, i64 8, align 8
  %ptr97 = ptrtoint ptr %mem96 to i64
  store i64 %ptr97, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem98 = alloca i8, i64 8, align 8
  %ptr99 = ptrtoint ptr %mem98 to i64
  store i64 %ptr99, ptr %slot16, align 8
  %v100 = load i64, ptr %slot1, align 8
  %op101 = add i64 %v100, 64
  store i64 %op101, ptr %slot17, align 8
  %v102 = load i64, ptr %slot17, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !4, !noalias !3
  store i64 %ld104, ptr %slot18, align 8
  %stack105 = call ptr @llvm.stacksave()
  %stackaddr106 = ptrtoint ptr %stack105 to i64
  %v107 = load i64, ptr %slot18, align 8
  %cmp108 = icmp ult i64 %stackaddr106, %v107
  %cv109 = zext i1 %cmp108 to i64
  store i64 %cv109, ptr %slot19, align 8
  %v110 = load i64, ptr %slot19, align 8
  %cond111 = icmp ne i64 %v110, 0
  br i1 %cond111, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v112 = load i64, ptr %slot1, align 8
  %p113 = inttoptr i64 %v112 to ptr
  call void @myl_qbe_fail_frame(ptr %p113) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v114 = load i64, ptr %slot2, align 8
  %v115 = load i64, ptr %slot11, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot3, align 8
  %v118 = load i64, ptr %slot12, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot1, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %call122 = call ptr @myl_qbe_heap(ptr %p121) nomerge, !dbg !112
  %calladdr123 = ptrtoint ptr %call122 to i64
  store i64 %calladdr123, ptr %slot20, align 8
  %v124 = load i64, ptr %slot5, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i32 0, ptr %p125, align 4, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot6, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i32 0, ptr %p127, align 4, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot7, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i32 0, ptr %p129, align 4, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot8, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i32 0, ptr %p131, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v132 = load i64, ptr %slot11, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i64, ptr %p133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld134, ptr %slot21, align 8
  %v135 = load i64, ptr %slot21, align 8
  %v136 = load i64, ptr %slot13, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot13, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot22, align 8
  %v141 = load i64, ptr %slot1, align 8
  %v142 = load i64, ptr %slot22, align 8
  call void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %callresult24, i64 %v141, i64 %v142) nomerge, !dbg !114
  %addr143 = ptrtoint ptr %callresult24 to i64
  store i64 %addr143, ptr %slot23, align 8
  %v144 = load i64, ptr %slot23, align 8
  %v145 = load i64, ptr %slot13, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot13, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot25, align 8
  %v150 = load i64, ptr %slot10, align 8
  store i64 %v150, ptr %slot26, align 8
  %v151 = load i64, ptr %slot25, align 8
  %v152 = load i64, ptr %slot26, align 8
  %p153 = inttoptr i64 %v151 to ptr
  %p154 = inttoptr i64 %v152 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p154, ptr %p153, i64 88, i1 false)
  %v155 = load i64, ptr %slot8, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i32 2, ptr %p156, align 4, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot7, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i32 1, ptr %p158, align 4, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot5, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i32, ptr %p160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld161, ptr %slot27, align 8
  %v162 = load i32, ptr %slot27, align 8
  %cv163 = zext i32 %v162 to i64
  %cond164 = icmp ne i64 %cv163, 0
  br i1 %cond164, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v165 = load i64, ptr %slot5, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i32 0, ptr %p166, align 4, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot9, align 8
  store i64 %v167, ptr %slot28, align 8
  %v168 = load i64, ptr %slot6, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i32, ptr %p169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld170, ptr %slot29, align 8
  %v171 = load i32, ptr %slot29, align 8
  %op172 = and i32 %v171, 28
  store i32 %op172, ptr %slot30, align 8
  %v173 = load i32, ptr %slot30, align 8
  %cv174 = zext i32 %v173 to i64
  %cond175 = icmp ne i64 %cv174, 0
  br i1 %cond175, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v176 = load i64, ptr %slot20, align 8
  store i64 %v176, ptr %slot31, align 8
  %v177 = load i64, ptr %slot31, align 8
  %v178 = load i64, ptr %slot28, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v177, i64 %v178) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v179 = load i64, ptr %slot20, align 8
  store i64 %v179, ptr %slot32, align 8
  %v180 = load i64, ptr %slot32, align 8
  %v181 = load i64, ptr %slot28, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v180, i64 %v181) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v182 = load i64, ptr %slot9, align 8
  store i64 %v182, ptr %slot33, align 8
  %v183 = load i64, ptr %slot10, align 8
  store i64 %v183, ptr %slot34, align 8
  %v184 = load i64, ptr %slot34, align 8
  %v185 = load i64, ptr %slot33, align 8
  %p186 = inttoptr i64 %v184 to ptr
  %p187 = inttoptr i64 %v185 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p187, ptr %p186, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot6, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i32 2, ptr %p189, align 4, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot8, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i32, ptr %p191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld192, ptr %slot35, align 8
  %v193 = load i32, ptr %slot35, align 8
  %v194 = load i64, ptr %slot6, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i32 %v193, ptr %p195, align 4, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot7, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i32 0, ptr %p197, align 4, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot5, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i32 1, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot33, align 8
  %v201 = load i64, ptr %slot13, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot13, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot36, align 8
  %v206 = load i64, ptr %slot36, align 8
  %op207 = add i64 %v206, 80
  store i64 %op207, ptr %slot37, align 8
  %v208 = load i64, ptr %slot37, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot38, align 8
  %v211 = load i64, ptr %slot38, align 8
  %v212 = load i64, ptr %slot13, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot5, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i32, ptr %p215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld216, ptr %slot39, align 8
  %v217 = load i32, ptr %slot39, align 8
  %cv218 = zext i32 %v217 to i64
  %cond219 = icmp ne i64 %cv218, 0
  br i1 %cond219, label %bb_rcslotdrop37, label %bb_rcslotdone37
bb_rcslotdrop37:
  %v220 = load i64, ptr %slot5, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i32 0, ptr %p221, align 4, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot9, align 8
  store i64 %v222, ptr %slot40, align 8
  %v223 = load i64, ptr %slot6, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i32, ptr %p224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld225, ptr %slot41, align 8
  %v226 = load i32, ptr %slot41, align 8
  %op227 = and i32 %v226, 28
  store i32 %op227, ptr %slot42, align 8
  %v228 = load i32, ptr %slot42, align 8
  %cv229 = zext i32 %v228 to i64
  %cond230 = icmp ne i64 %cv229, 0
  br i1 %cond230, label %bb_rcslotrole37, label %bb_rcslotowner37
bb_rcslotrole37:
  %v231 = load i64, ptr %slot20, align 8
  store i64 %v231, ptr %slot43, align 8
  %v232 = load i64, ptr %slot43, align 8
  %v233 = load i64, ptr %slot40, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v232, i64 %v233) nomerge, !dbg !116
  br label %bb_rcslotdone37
bb_rcslotowner37:
  %v234 = load i64, ptr %slot20, align 8
  store i64 %v234, ptr %slot44, align 8
  %v235 = load i64, ptr %slot44, align 8
  %v236 = load i64, ptr %slot40, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v235, i64 %v236) nomerge, !dbg !116
  br label %bb_rcslotdone37
bb_rcslotdone37:
  %v237 = load i64, ptr %slot14, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 0, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot14, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot45, align 8
  %v242 = load i64, ptr %slot13, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot46, align 8
  %v245 = load i64, ptr %slot46, align 8
  %v246 = load i64, ptr %slot45, align 8
  %cmp247 = icmp sgt i64 %v245, %v246
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot47, align 8
  %v249 = load i64, ptr %slot47, align 8
  %v250 = load i64, ptr %slot13, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i64 %v249, ptr %p251, align 8, !alias.scope !3, !noalias !4
  %v252 = load i64, ptr %slot13, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot48, align 8
  %v255 = load i64, ptr %slot48, align 8
  %cond256 = icmp ne i64 %v255, 0
  br i1 %cond256, label %bb_next48, label %bb_i11
bb_next48:
  %v257 = load i64, ptr %slot11, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot49, align 8
  %v260 = load i64, ptr %slot49, align 8
  %v261 = load i64, ptr %slot13, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i64 %v260, ptr %p262, align 8, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot13, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot50, align 8
  %v266 = load i64, ptr %slot1, align 8
  %v267 = load i64, ptr %slot50, align 8
  %call268 = call i64 @myl_f_fda9a293642c453fac79f8b6d7f75b135405e246ae3c1aab4c49816401b1323d(i64 %v266, i64 %v267) nomerge, !dbg !118
  store i64 %call268, ptr %slot51, align 8
  %v269 = load i64, ptr %slot51, align 8
  %v270 = load i64, ptr %slot13, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i64 %v269, ptr %p271, align 8, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot5, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i32, ptr %p273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld274, ptr %slot52, align 8
  %v275 = load i32, ptr %slot52, align 8
  %cv276 = zext i32 %v275 to i64
  %cond277 = icmp ne i64 %cv276, 0
  br i1 %cond277, label %bb_rcslotdrop53, label %bb_rcslotdone53
bb_rcslotdrop53:
  %v278 = load i64, ptr %slot5, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i32 0, ptr %p279, align 4, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot9, align 8
  store i64 %v280, ptr %slot53, align 8
  %v281 = load i64, ptr %slot6, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i32, ptr %p282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld283, ptr %slot54, align 8
  %v284 = load i32, ptr %slot54, align 8
  %op285 = and i32 %v284, 28
  store i32 %op285, ptr %slot55, align 8
  %v286 = load i32, ptr %slot55, align 8
  %cv287 = zext i32 %v286 to i64
  %cond288 = icmp ne i64 %cv287, 0
  br i1 %cond288, label %bb_rcslotrole53, label %bb_rcslotowner53
bb_rcslotrole53:
  %v289 = load i64, ptr %slot20, align 8
  store i64 %v289, ptr %slot56, align 8
  %v290 = load i64, ptr %slot56, align 8
  %v291 = load i64, ptr %slot53, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v290, i64 %v291) nomerge, !dbg !118
  br label %bb_rcslotdone53
bb_rcslotowner53:
  %v292 = load i64, ptr %slot20, align 8
  store i64 %v292, ptr %slot57, align 8
  %v293 = load i64, ptr %slot57, align 8
  %v294 = load i64, ptr %slot53, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v293, i64 %v294) nomerge, !dbg !118
  br label %bb_rcslotdone53
bb_rcslotdone53:
  %v295 = load i64, ptr %slot13, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 0, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot13, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot58, align 8
  %v300 = load i64, ptr %slot5, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i32, ptr %p301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld302, ptr %slot59, align 8
  %v303 = load i32, ptr %slot59, align 8
  %cv304 = zext i32 %v303 to i64
  %cond305 = icmp ne i64 %cv304, 0
  br i1 %cond305, label %bb_rcslotdrop63, label %bb_rcslotdone63
bb_rcslotdrop63:
  %v306 = load i64, ptr %slot5, align 8
  %p307 = inttoptr i64 %v306 to ptr
  store i32 0, ptr %p307, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone63
bb_rcslotdone63:
  %v308 = load i64, ptr %slot58, align 8
  ret i64 %v308
bb_i11:
  %v309 = load i64, ptr %slot11, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot60, align 8
  %v312 = load i64, ptr %slot60, align 8
  %v313 = load i64, ptr %slot13, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot14, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 8, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot12, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot61, align 8
  %v320 = load i64, ptr %slot61, align 8
  %v321 = load i64, ptr %slot15, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot13, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot62, align 8
  %v326 = load i64, ptr %slot14, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot63, align 8
  %v329 = load i64, ptr %slot15, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot64, align 8
  %v332 = load i64, ptr %slot1, align 8
  %v333 = load i64, ptr %slot62, align 8
  %v334 = load i64, ptr %slot63, align 8
  %v335 = load i64, ptr %slot64, align 8
  %call336 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v332, i64 %v333, i64 %v334, i64 %v335) nomerge, !dbg !120
  store i64 %call336, ptr %slot65, align 8
  %v337 = load i64, ptr %slot65, align 8
  %v338 = load i64, ptr %slot13, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i64 %v337, ptr %p339, align 8, !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot5, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i32, ptr %p341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld342, ptr %slot66, align 8
  %v343 = load i32, ptr %slot66, align 8
  %cv344 = zext i32 %v343 to i64
  %cond345 = icmp ne i64 %cv344, 0
  br i1 %cond345, label %bb_rcslotdrop81, label %bb_rcslotdone81
bb_rcslotdrop81:
  %v346 = load i64, ptr %slot5, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i32 0, ptr %p347, align 4, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot9, align 8
  store i64 %v348, ptr %slot67, align 8
  %v349 = load i64, ptr %slot6, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i32, ptr %p350, align 4, !alias.scope !3, !noalias !4
  store i32 %ld351, ptr %slot68, align 8
  %v352 = load i32, ptr %slot68, align 8
  %op353 = and i32 %v352, 28
  store i32 %op353, ptr %slot69, align 8
  %v354 = load i32, ptr %slot69, align 8
  %cv355 = zext i32 %v354 to i64
  %cond356 = icmp ne i64 %cv355, 0
  br i1 %cond356, label %bb_rcslotrole81, label %bb_rcslotowner81
bb_rcslotrole81:
  %v357 = load i64, ptr %slot20, align 8
  store i64 %v357, ptr %slot70, align 8
  %v358 = load i64, ptr %slot70, align 8
  %v359 = load i64, ptr %slot67, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v358, i64 %v359) nomerge, !dbg !120
  br label %bb_rcslotdone81
bb_rcslotowner81:
  %v360 = load i64, ptr %slot20, align 8
  store i64 %v360, ptr %slot71, align 8
  %v361 = load i64, ptr %slot71, align 8
  %v362 = load i64, ptr %slot67, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v361, i64 %v362) nomerge, !dbg !120
  br label %bb_rcslotdone81
bb_rcslotdone81:
  %v363 = load i64, ptr %slot13, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 0, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot13, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld367, ptr %slot72, align 8
  %v368 = load i64, ptr %slot5, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i32, ptr %p369, align 4, !alias.scope !3, !noalias !4
  store i32 %ld370, ptr %slot73, align 8
  %v371 = load i32, ptr %slot73, align 8
  %cv372 = zext i32 %v371 to i64
  %cond373 = icmp ne i64 %cv372, 0
  br i1 %cond373, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v374 = load i64, ptr %slot5, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i32 0, ptr %p375, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v376 = load i64, ptr %slot72, align 8
  ret i64 %v376
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8, i64, i64)
declare i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64, i64, i64, i64)
declare i64 @myl_f_fda9a293642c453fac79f8b6d7f75b135405e246ae3c1aab4c49816401b1323d(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd", linkageName: "myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8592503301045702440, i64 0, !"myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!120 = !DILocation(line: 15, column: 0, scope: !121)
