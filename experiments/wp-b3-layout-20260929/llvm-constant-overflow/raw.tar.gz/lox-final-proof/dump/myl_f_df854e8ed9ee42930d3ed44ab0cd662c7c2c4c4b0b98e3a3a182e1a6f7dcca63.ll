target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_df854e8ed9ee42930d3ed44ab0cd662c7c2c4c4b0b98e3a3a182e1a6f7dcca63(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v64 = load i64, ptr %slot1, align 8
  %op65 = add i64 %v64, 32
  store i64 %op65, ptr %slot5, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot6, align 8
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot7, align 8
  %mem70 = alloca i8, i64 8, align 8
  %ptr71 = ptrtoint ptr %mem70 to i64
  store i64 %ptr71, ptr %slot8, align 8
  %mem72 = alloca i8, i64 8, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot9, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot10, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot11, align 8
  %mem78 = alloca i8, i64 16, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot12, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot13, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot14, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot15, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot16, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot17, align 8
  %mem90 = alloca i8, i64 208, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot19, align 8
  %v94 = load i64, ptr %slot1, align 8
  %op95 = add i64 %v94, 64
  store i64 %op95, ptr %slot20, align 8
  %v96 = load i64, ptr %slot20, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !4, !noalias !3
  store i64 %ld98, ptr %slot21, align 8
  %stack99 = call ptr @llvm.stacksave()
  %stackaddr100 = ptrtoint ptr %stack99 to i64
  %v101 = load i64, ptr %slot21, align 8
  %cmp102 = icmp ult i64 %stackaddr100, %v101
  %cv103 = zext i1 %cmp102 to i64
  store i64 %cv103, ptr %slot22, align 8
  %v104 = load i64, ptr %slot22, align 8
  %cond105 = icmp ne i64 %v104, 0
  br i1 %cond105, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v106 = load i64, ptr %slot1, align 8
  %p107 = inttoptr i64 %v106 to ptr
  call void @myl_qbe_fail_frame(ptr %p107) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v108 = load i64, ptr %slot2, align 8
  %v109 = load i64, ptr %slot8, align 8
  %p110 = inttoptr i64 %v109 to ptr
  store i64 %v108, ptr %p110, align 8, !alias.scope !3, !noalias !4
  %v111 = load i64, ptr %slot3, align 8
  %v112 = load i64, ptr %slot9, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot4, align 8
  %v115 = load i64, ptr %slot10, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot1, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %call119 = call ptr @myl_qbe_heap(ptr %p118) nomerge, !dbg !112
  %calladdr120 = ptrtoint ptr %call119 to i64
  store i64 %calladdr120, ptr %slot23, align 8
  %v121 = load i64, ptr %slot6, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i32 0, ptr %p122, align 4, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot7, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i32 0, ptr %p124, align 4, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot7, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i32 2, ptr %p126, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v127 = load i64, ptr %slot8, align 8
  %p128 = inttoptr i64 %v127 to ptr
  %ld129 = load i64, ptr %p128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot24, align 8
  %v130 = load i64, ptr %slot24, align 8
  %v131 = load i64, ptr %slot14, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot9, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot25, align 8
  %v136 = load i64, ptr %slot25, align 8
  %v137 = load i64, ptr %slot15, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot14, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot26, align 8
  %v142 = load i64, ptr %slot15, align 8
  %p143 = inttoptr i64 %v142 to ptr
  %ld144 = load i64, ptr %p143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld144, ptr %slot27, align 8
  %v145 = load i64, ptr %slot1, align 8
  %v146 = load i64, ptr %slot26, align 8
  %v147 = load i64, ptr %slot27, align 8
  %call148 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v145, i64 %v146, i64 %v147) nomerge, !dbg !114
  store i64 %call148, ptr %slot28, align 8
  %v149 = load i64, ptr %slot28, align 8
  %v150 = load i64, ptr %slot14, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot14, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot29, align 8
  %v155 = load i64, ptr %slot29, align 8
  %v156 = load i64, ptr %slot11, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot8, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot30, align 8
  %v161 = load i64, ptr %slot30, align 8
  %v162 = load i64, ptr %slot18, align 8
  %p163 = inttoptr i64 %v161 to ptr
  %p164 = inttoptr i64 %v162 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p164, ptr %p163, i64 208, i1 false), !alias.scope !10000000
  %v165 = load i64, ptr %slot18, align 8
  %v166 = load i64, ptr %slot14, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot14, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot31, align 8
  %v171 = load i64, ptr %slot31, align 8
  %op172 = add i64 %v171, 48
  store i64 %op172, ptr %slot32, align 8
  %v173 = load i64, ptr %slot32, align 8
  %v174 = load i64, ptr %slot14, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 %v173, ptr %p175, align 8, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot6, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %ld178 = load i32, ptr %p177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld178, ptr %slot33, align 8
  %v179 = load i32, ptr %slot33, align 8
  %cv180 = zext i32 %v179 to i64
  %cond181 = icmp ne i64 %cv180, 0
  br i1 %cond181, label %bb_rcslotdrop31, label %bb_rcslotdone31
bb_rcslotdrop31:
  %v182 = load i64, ptr %slot6, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i32 0, ptr %p183, align 4, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot12, align 8
  store i64 %v184, ptr %slot34, align 8
  %v185 = load i64, ptr %slot7, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i32, ptr %p186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld187, ptr %slot35, align 8
  %v188 = load i32, ptr %slot35, align 8
  %op189 = and i32 %v188, 28
  store i32 %op189, ptr %slot36, align 8
  %v190 = load i32, ptr %slot36, align 8
  %cv191 = zext i32 %v190 to i64
  %cond192 = icmp ne i64 %cv191, 0
  br i1 %cond192, label %bb_rcslotrole31, label %bb_rcslotowner31
bb_rcslotrole31:
  %v193 = load i64, ptr %slot23, align 8
  store i64 %v193, ptr %slot37, align 8
  %v194 = load i64, ptr %slot37, align 8
  %v195 = load i64, ptr %slot34, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v194, i64 %v195) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotowner31:
  %v196 = load i64, ptr %slot23, align 8
  store i64 %v196, ptr %slot38, align 8
  %v197 = load i64, ptr %slot38, align 8
  %v198 = load i64, ptr %slot34, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v197, i64 %v198) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotdone31:
  %v199 = load i64, ptr %slot8, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot39, align 8
  %v202 = load i64, ptr %slot39, align 8
  %op203 = add i64 %v202, 48
  store i64 %op203, ptr %slot40, align 8
  %v204 = load i64, ptr %slot12, align 8
  store i64 %v204, ptr %slot41, align 8
  %v205 = load i64, ptr %slot40, align 8
  %v206 = load i64, ptr %slot41, align 8
  %p207 = inttoptr i64 %v205 to ptr
  %p208 = inttoptr i64 %v206 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p208, ptr %p207, i64 16, i1 false), !alias.scope !10000000
  %v209 = load i64, ptr %slot40, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 0, ptr %p210, align 8, !alias.scope !4, !noalias !3
  %v211 = load i64, ptr %slot40, align 8
  %op212 = add i64 %v211, 8
  store i64 %op212, ptr %slot42, align 8
  %v213 = load i64, ptr %slot42, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 0, ptr %p214, align 8, !alias.scope !4, !noalias !3
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 1, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot12, align 8
  %v218 = load i64, ptr %slot14, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot9, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot43, align 8
  %v223 = load i64, ptr %slot43, align 8
  %v224 = load i64, ptr %slot15, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot11, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot44, align 8
  %v229 = load i64, ptr %slot44, align 8
  %v230 = load i64, ptr %slot16, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot10, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot45, align 8
  %v235 = load i64, ptr %slot45, align 8
  %v236 = load i64, ptr %slot17, align 8
  %p237 = inttoptr i64 %v236 to ptr
  store i64 %v235, ptr %p237, align 8, !alias.scope !3, !noalias !4
  %v238 = load i64, ptr %slot14, align 8
  %p239 = inttoptr i64 %v238 to ptr
  %ld240 = load i64, ptr %p239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld240, ptr %slot46, align 8
  %v241 = load i64, ptr %slot15, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot47, align 8
  %v244 = load i64, ptr %slot16, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot48, align 8
  %v247 = load i64, ptr %slot17, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot49, align 8
  %v250 = load i64, ptr %slot1, align 8
  %v251 = load i64, ptr %slot46, align 8
  %v252 = load i64, ptr %slot47, align 8
  %v253 = load i64, ptr %slot48, align 8
  %v254 = load i64, ptr %slot49, align 8
  %call255 = call i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64 %v250, i64 %v251, i64 %v252, i64 %v253, i64 %v254) nomerge, !dbg !118
  store i64 %call255, ptr %slot50, align 8
  %v256 = load i64, ptr %slot50, align 8
  %v257 = load i64, ptr %slot14, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i64 %v256, ptr %p258, align 8, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot14, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot51, align 8
  %v262 = load i64, ptr %slot51, align 8
  %v263 = load i64, ptr %slot13, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot8, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot52, align 8
  %v268 = load i64, ptr %slot52, align 8
  %op269 = add i64 %v268, 48
  store i64 %op269, ptr %slot53, align 8
  %v270 = load i64, ptr %slot12, align 8
  store i64 %v270, ptr %slot54, align 8
  %v271 = load i64, ptr %slot54, align 8
  %v272 = load i64, ptr %slot53, align 8
  %p273 = inttoptr i64 %v271 to ptr
  %p274 = inttoptr i64 %v272 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p274, ptr %p273, i64 16, i1 false), !alias.scope !10000000
  %v275 = load i64, ptr %slot54, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i64 0, ptr %p276, align 8, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot54, align 8
  %p279 = inttoptr i64 %v277 to ptr
  %gep280 = getelementptr i8, ptr %p279, i64 8
  %op278 = ptrtoint ptr %gep280 to i64
  store i64 %op278, ptr %slot55, align 8
  %v281 = load i64, ptr %slot55, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 0, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot6, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i32 0, ptr %p284, align 4, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot14, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 0, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot13, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot56, align 8
  %v290 = load i64, ptr %slot56, align 8
  %v291 = load i64, ptr %slot14, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot14, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot57, align 8
  %v296 = load i64, ptr %slot6, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i32, ptr %p297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld298, ptr %slot58, align 8
  %v299 = load i32, ptr %slot58, align 8
  %cv300 = zext i32 %v299 to i64
  %cond301 = icmp ne i64 %cv300, 0
  br i1 %cond301, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v302 = load i64, ptr %slot6, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i32 0, ptr %p303, align 4, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot12, align 8
  store i64 %v304, ptr %slot59, align 8
  %v305 = load i64, ptr %slot7, align 8
  %p306 = inttoptr i64 %v305 to ptr
  %ld307 = load i32, ptr %p306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld307, ptr %slot60, align 8
  %v308 = load i32, ptr %slot60, align 8
  %op309 = and i32 %v308, 28
  store i32 %op309, ptr %slot61, align 8
  %v310 = load i32, ptr %slot61, align 8
  %cv311 = zext i32 %v310 to i64
  %cond312 = icmp ne i64 %cv311, 0
  br i1 %cond312, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v313 = load i64, ptr %slot23, align 8
  store i64 %v313, ptr %slot62, align 8
  %v314 = load i64, ptr %slot62, align 8
  %v315 = load i64, ptr %slot59, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v314, i64 %v315) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v316 = load i64, ptr %slot23, align 8
  store i64 %v316, ptr %slot63, align 8
  %v317 = load i64, ptr %slot63, align 8
  %v318 = load i64, ptr %slot59, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v317, i64 %v318) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v319 = load i64, ptr %slot57, align 8
  ret i64 %v319
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64, i64, i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_df854e8ed9ee42930d3ed44ab0cd662c7c2c4c4b0b98e3a3a182e1a6f7dcca63", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_df854e8ed9ee42930d3ed44ab0cd662c7c2c4c4b0b98e3a3a182e1a6f7dcca63", linkageName: "myl_f_df854e8ed9ee42930d3ed44ab0cd662c7c2c4c4b0b98e3a3a182e1a6f7dcca63", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9516887611419818660, i64 0, !"myl_f_df854e8ed9ee42930d3ed44ab0cd662c7c2c4c4b0b98e3a3a182e1a6f7dcca63"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!120 = !DILocation(line: 29, column: 0, scope: !121)
