target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v113 = load i64, ptr %slot1, align 8
  %op114 = add i64 %v113, 32
  store i64 %op114, ptr %slot4, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot5, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot6, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot7, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot8, align 8
  %mem123 = alloca i8, i64 312, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot9, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot10, align 8
  %mem127 = alloca i8, i64 312, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot11, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot12, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot13, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot14, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot15, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot16, align 8
  %mem139 = alloca i8, i64 312, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot17, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot18, align 8
  %v143 = load i64, ptr %slot1, align 8
  %op144 = add i64 %v143, 64
  store i64 %op144, ptr %slot19, align 8
  %v145 = load i64, ptr %slot19, align 8
  %p146 = inttoptr i64 %v145 to ptr
  %ld147 = load i64, ptr %p146, align 8, !alias.scope !4, !noalias !3
  store i64 %ld147, ptr %slot20, align 8
  %stack148 = call ptr @llvm.stacksave()
  %stackaddr149 = ptrtoint ptr %stack148 to i64
  %v150 = load i64, ptr %slot20, align 8
  %cmp151 = icmp ult i64 %stackaddr149, %v150
  %cv152 = zext i1 %cmp151 to i64
  store i64 %cv152, ptr %slot21, align 8
  %v153 = load i64, ptr %slot21, align 8
  %cond154 = icmp ne i64 %v153, 0
  br i1 %cond154, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v155 = load i64, ptr %slot1, align 8
  %p156 = inttoptr i64 %v155 to ptr
  call void @myl_qbe_fail_frame(ptr %p156) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v157 = load i64, ptr %slot2, align 8
  %v158 = load i64, ptr %slot12, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot3, align 8
  %v161 = load i64, ptr %slot13, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot1, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %call165 = call ptr @myl_qbe_heap(ptr %p164) nomerge, !dbg !112
  %calladdr166 = ptrtoint ptr %call165 to i64
  store i64 %calladdr166, ptr %slot22, align 8
  %v167 = load i64, ptr %slot5, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i32 0, ptr %p168, align 4, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot6, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i32 0, ptr %p170, align 4, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot7, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i32 0, ptr %p172, align 4, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot8, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i32 0, ptr %p174, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v175 = load i64, ptr %slot12, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld177, ptr %slot23, align 8
  %v178 = load i64, ptr %slot23, align 8
  %v179 = load i64, ptr %slot14, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 %v178, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot12, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i64, ptr %p182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld183, ptr %slot24, align 8
  %v184 = load i64, ptr %slot24, align 8
  %v185 = load i64, ptr %slot17, align 8
  %p186 = inttoptr i64 %v184 to ptr
  %p187 = inttoptr i64 %v185 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p187, ptr %p186, i64 312, i1 false), !alias.scope !10000000
  %v188 = load i64, ptr %slot17, align 8
  %v189 = load i64, ptr %slot15, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot15, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot25, align 8
  %v194 = load i64, ptr %slot25, align 8
  %op195 = add i64 %v194, 248
  store i64 %op195, ptr %slot26, align 8
  %v196 = load i64, ptr %slot26, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot27, align 8
  %v199 = load i64, ptr %slot27, align 8
  %v200 = load i64, ptr %slot15, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot5, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i32, ptr %p203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld204, ptr %slot28, align 8
  %v205 = load i32, ptr %slot28, align 8
  %cv206 = zext i32 %v205 to i64
  %cond207 = icmp ne i64 %cv206, 0
  br i1 %cond207, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v208 = load i64, ptr %slot5, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i32 0, ptr %p209, align 4, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot9, align 8
  store i64 %v210, ptr %slot29, align 8
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i32, ptr %p212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld213, ptr %slot30, align 8
  %v214 = load i32, ptr %slot30, align 8
  %op215 = and i32 %v214, 28
  store i32 %op215, ptr %slot31, align 8
  %v216 = load i32, ptr %slot31, align 8
  %cv217 = zext i32 %v216 to i64
  %cond218 = icmp ne i64 %cv217, 0
  br i1 %cond218, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v219 = load i64, ptr %slot22, align 8
  store i64 %v219, ptr %slot32, align 8
  %v220 = load i64, ptr %slot32, align 8
  %v221 = load i64, ptr %slot29, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v220, i64 %v221) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v222 = load i64, ptr %slot22, align 8
  store i64 %v222, ptr %slot33, align 8
  %v223 = load i64, ptr %slot33, align 8
  %v224 = load i64, ptr %slot29, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v223, i64 %v224) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v225 = load i64, ptr %slot13, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot34, align 8
  %v228 = load i64, ptr %slot34, align 8
  %v229 = load i64, ptr %slot16, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot15, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot35, align 8
  %v234 = load i64, ptr %slot16, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot36, align 8
  %v237 = load i64, ptr %slot1, align 8
  %v238 = load i64, ptr %slot35, align 8
  %v239 = load i64, ptr %slot36, align 8
  %call240 = call i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %v237, i64 %v238, i64 %v239) nomerge, !dbg !116
  store i64 %call240, ptr %slot37, align 8
  %v241 = load i64, ptr %slot37, align 8
  %v242 = load i64, ptr %slot15, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i64 %v241, ptr %p243, align 8, !alias.scope !3, !noalias !4
  %v244 = load i64, ptr %slot15, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot38, align 8
  %v247 = load i64, ptr %slot38, align 8
  %v248 = load i64, ptr %slot10, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 %v247, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot10, align 8
  store i64 %v250, ptr %slot39, align 8
  %v251 = load i64, ptr %slot11, align 8
  store i64 %v251, ptr %slot40, align 8
  %v252 = load i64, ptr %slot39, align 8
  %v253 = load i64, ptr %slot40, align 8
  %p254 = inttoptr i64 %v252 to ptr
  %p255 = inttoptr i64 %v253 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p255, ptr %p254, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot8, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i32 2, ptr %p257, align 4, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot7, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i32 1, ptr %p259, align 4, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot5, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i32, ptr %p261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld262, ptr %slot41, align 8
  %v263 = load i32, ptr %slot41, align 8
  %cv264 = zext i32 %v263 to i64
  %cond265 = icmp ne i64 %cv264, 0
  br i1 %cond265, label %bb_rcslotdrop34, label %bb_rcslotdone34
bb_rcslotdrop34:
  %v266 = load i64, ptr %slot5, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i32 0, ptr %p267, align 4, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot9, align 8
  store i64 %v268, ptr %slot42, align 8
  %v269 = load i64, ptr %slot6, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i32, ptr %p270, align 4, !alias.scope !3, !noalias !4
  store i32 %ld271, ptr %slot43, align 8
  %v272 = load i32, ptr %slot43, align 8
  %op273 = and i32 %v272, 28
  store i32 %op273, ptr %slot44, align 8
  %v274 = load i32, ptr %slot44, align 8
  %cv275 = zext i32 %v274 to i64
  %cond276 = icmp ne i64 %cv275, 0
  br i1 %cond276, label %bb_rcslotrole34, label %bb_rcslotowner34
bb_rcslotrole34:
  %v277 = load i64, ptr %slot22, align 8
  store i64 %v277, ptr %slot45, align 8
  %v278 = load i64, ptr %slot42, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot46, align 8
  %v281 = load i64, ptr %slot46, align 8
  %cmp282 = icmp ne i64 %v281, 0
  %cv283 = zext i1 %cmp282 to i32
  store i32 %cv283, ptr %slot47, align 8
  %v284 = load i32, ptr %slot47, align 8
  %cv285 = zext i32 %v284 to i64
  %cond286 = icmp ne i64 %cv285, 0
  br i1 %cond286, label %bb_rcgnn50, label %bb_rcgdone50
bb_rcgnn50:
  %v287 = load i64, ptr %slot46, align 8
  %op288 = sub i64 %v287, 16
  store i64 %op288, ptr %slot48, align 8
  %v289 = load i64, ptr %slot46, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %rgep291 = getelementptr i8, ptr %p290, i64 -16
  %ld292 = load i64, ptr %rgep291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld292, ptr %slot49, align 8
  %v293 = load i64, ptr %slot49, align 8
  %op294 = and i64 %v293, 4611686018427387906
  store i64 %op294, ptr %slot50, align 8
  %v295 = load i64, ptr %slot50, align 8
  %cmp296 = icmp ne i64 %v295, 0
  %cv297 = zext i1 %cmp296 to i32
  store i32 %cv297, ptr %slot51, align 8
  %v298 = load i32, ptr %slot51, align 8
  %cv299 = zext i32 %v298 to i64
  %cond300 = icmp ne i64 %cv299, 0
  br i1 %cond300, label %bb_rcgclear50, label %bb_rcgcounted50
bb_rcgcounted50:
  %v301 = load i64, ptr %slot46, align 8
  %op302 = sub i64 %v301, 24
  store i64 %op302, ptr %slot52, align 8
  %v303 = load i64, ptr %slot46, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %rgep305 = getelementptr i8, ptr %p304, i64 -24
  %ld306 = load i64, ptr %rgep305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld306, ptr %slot53, align 8
  %v307 = load i64, ptr %slot53, align 8
  %op308 = sub i64 %v307, 1
  store i64 %op308, ptr %slot54, align 8
  %v309 = load i64, ptr %slot54, align 8
  %cmp310 = icmp eq i64 %v309, 0
  %cv311 = zext i1 %cmp310 to i32
  store i32 %cv311, ptr %slot55, align 8
  %v312 = load i32, ptr %slot55, align 8
  %cv313 = zext i32 %v312 to i64
  %cond314 = icmp ne i64 %cv313, 0
  br i1 %cond314, label %bb_rcglast50, label %bb_rcgdec50
bb_rcglast50:
  %v315 = load i64, ptr %slot46, align 8
  %op316 = sub i64 %v315, 32
  store i64 %op316, ptr %slot56, align 8
  %v317 = load i64, ptr %slot46, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %rgep319 = getelementptr i8, ptr %p318, i64 -32
  %ld320 = load i64, ptr %rgep319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld320, ptr %slot57, align 8
  %v321 = load i64, ptr %slot57, align 8
  %cmp322 = icmp ne i64 %v321, 0
  %cv323 = zext i1 %cmp322 to i32
  store i32 %cv323, ptr %slot58, align 8
  %v324 = load i32, ptr %slot58, align 8
  %cv325 = zext i32 %v324 to i64
  %cond326 = icmp ne i64 %cv325, 0
  br i1 %cond326, label %bb_rcgdec50, label %bb_rcgslow50
bb_rcgslow50:
  %v327 = load i64, ptr %slot45, align 8
  %v328 = load i64, ptr %slot42, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v327, i64 %v328) nomerge, !dbg !116
  br label %bb_rcgdone50
bb_rcgdec50:
  %v329 = load i64, ptr %slot54, align 8
  %v330 = load i64, ptr %slot46, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %rgep332 = getelementptr i8, ptr %p331, i64 -24
  store i64 %v329, ptr %rgep332, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear50
bb_rcgclear50:
  %v333 = load i64, ptr %slot42, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 0, ptr %p334, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone50
bb_rcgdone50:
  br label %bb_rcslotdone34
bb_rcslotowner34:
  %v335 = load i64, ptr %slot22, align 8
  store i64 %v335, ptr %slot59, align 8
  %v336 = load i64, ptr %slot42, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot60, align 8
  %v339 = load i64, ptr %slot60, align 8
  %cmp340 = icmp ne i64 %v339, 0
  %cv341 = zext i1 %cmp340 to i32
  store i32 %cv341, ptr %slot61, align 8
  %v342 = load i32, ptr %slot61, align 8
  %cv343 = zext i32 %v342 to i64
  %cond344 = icmp ne i64 %cv343, 0
  br i1 %cond344, label %bb_rcgnn65, label %bb_rcgdone65
bb_rcgnn65:
  %v345 = load i64, ptr %slot60, align 8
  %op346 = sub i64 %v345, 16
  store i64 %op346, ptr %slot62, align 8
  %v347 = load i64, ptr %slot60, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %rgep349 = getelementptr i8, ptr %p348, i64 -16
  %ld350 = load i64, ptr %rgep349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld350, ptr %slot63, align 8
  %v351 = load i64, ptr %slot63, align 8
  %op352 = and i64 %v351, 4611686018427387906
  store i64 %op352, ptr %slot64, align 8
  %v353 = load i64, ptr %slot64, align 8
  %cmp354 = icmp ne i64 %v353, 0
  %cv355 = zext i1 %cmp354 to i32
  store i32 %cv355, ptr %slot65, align 8
  %v356 = load i32, ptr %slot65, align 8
  %cv357 = zext i32 %v356 to i64
  %cond358 = icmp ne i64 %cv357, 0
  br i1 %cond358, label %bb_rcgclear65, label %bb_rcgcounted65
bb_rcgcounted65:
  %v359 = load i64, ptr %slot60, align 8
  %op360 = sub i64 %v359, 32
  store i64 %op360, ptr %slot66, align 8
  %v361 = load i64, ptr %slot60, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %rgep363 = getelementptr i8, ptr %p362, i64 -32
  %ld364 = load i64, ptr %rgep363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld364, ptr %slot67, align 8
  %v365 = load i64, ptr %slot67, align 8
  %op366 = sub i64 %v365, 1
  store i64 %op366, ptr %slot68, align 8
  %v367 = load i64, ptr %slot68, align 8
  %cmp368 = icmp eq i64 %v367, 0
  %cv369 = zext i1 %cmp368 to i32
  store i32 %cv369, ptr %slot69, align 8
  %v370 = load i32, ptr %slot69, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcglast65, label %bb_rcgdec65
bb_rcglast65:
  %v373 = load i64, ptr %slot60, align 8
  %op374 = sub i64 %v373, 24
  store i64 %op374, ptr %slot70, align 8
  %v375 = load i64, ptr %slot60, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %rgep377 = getelementptr i8, ptr %p376, i64 -24
  %ld378 = load i64, ptr %rgep377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld378, ptr %slot71, align 8
  %v379 = load i64, ptr %slot71, align 8
  %cmp380 = icmp ne i64 %v379, 0
  %cv381 = zext i1 %cmp380 to i32
  store i32 %cv381, ptr %slot72, align 8
  %v382 = load i32, ptr %slot72, align 8
  %cv383 = zext i32 %v382 to i64
  %cond384 = icmp ne i64 %cv383, 0
  br i1 %cond384, label %bb_rcgdec65, label %bb_rcgslow65
bb_rcgslow65:
  %v385 = load i64, ptr %slot59, align 8
  %v386 = load i64, ptr %slot42, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v385, i64 %v386) nomerge, !dbg !116
  br label %bb_rcgdone65
bb_rcgdec65:
  %v387 = load i64, ptr %slot68, align 8
  %v388 = load i64, ptr %slot60, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %rgep390 = getelementptr i8, ptr %p389, i64 -32
  store i64 %v387, ptr %rgep390, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear65
bb_rcgclear65:
  %v391 = load i64, ptr %slot42, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 0, ptr %p392, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone65
bb_rcgdone65:
  br label %bb_rcslotdone34
bb_rcslotdone34:
  %v393 = load i64, ptr %slot9, align 8
  store i64 %v393, ptr %slot73, align 8
  %v394 = load i64, ptr %slot11, align 8
  store i64 %v394, ptr %slot74, align 8
  %v395 = load i64, ptr %slot74, align 8
  %v396 = load i64, ptr %slot73, align 8
  %p397 = inttoptr i64 %v395 to ptr
  %p398 = inttoptr i64 %v396 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p398, ptr %p397, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot6, align 8
  %p400 = inttoptr i64 %v399 to ptr
  store i32 2, ptr %p400, align 4, !alias.scope !3, !noalias !4
  %v401 = load i64, ptr %slot8, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i32, ptr %p402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld403, ptr %slot75, align 8
  %v404 = load i32, ptr %slot75, align 8
  %v405 = load i64, ptr %slot6, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i32 %v404, ptr %p406, align 4, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot7, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i32 0, ptr %p408, align 4, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot5, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i32 1, ptr %p410, align 4, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot73, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot76, align 8
  %v414 = load i64, ptr %slot76, align 8
  %v415 = load i64, ptr %slot15, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot14, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot77, align 8
  %v420 = load i64, ptr %slot15, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot78, align 8
  %v423 = load i64, ptr %slot1, align 8
  %v424 = load i64, ptr %slot77, align 8
  %v425 = load i64, ptr %slot78, align 8
  %call426 = call i64 @myl_f_be55845d0d1b5c3c8f232826f6eebbc3f154bbc843ca36782c227966ffc2f923(i64 %v423, i64 %v424, i64 %v425) nomerge, !dbg !118
  store i64 %call426, ptr %slot79, align 8
  %v427 = load i64, ptr %slot79, align 8
  %v428 = load i64, ptr %slot14, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot5, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i32, ptr %p431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld432, ptr %slot80, align 8
  %v433 = load i32, ptr %slot80, align 8
  %cv434 = zext i32 %v433 to i64
  %cond435 = icmp ne i64 %cv434, 0
  br i1 %cond435, label %bb_rcslotdrop101, label %bb_rcslotdone101
bb_rcslotdrop101:
  %v436 = load i64, ptr %slot5, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i32 0, ptr %p437, align 4, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot9, align 8
  store i64 %v438, ptr %slot81, align 8
  %v439 = load i64, ptr %slot6, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i32, ptr %p440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld441, ptr %slot82, align 8
  %v442 = load i32, ptr %slot82, align 8
  %op443 = and i32 %v442, 28
  store i32 %op443, ptr %slot83, align 8
  %v444 = load i32, ptr %slot83, align 8
  %cv445 = zext i32 %v444 to i64
  %cond446 = icmp ne i64 %cv445, 0
  br i1 %cond446, label %bb_rcslotrole101, label %bb_rcslotowner101
bb_rcslotrole101:
  %v447 = load i64, ptr %slot22, align 8
  store i64 %v447, ptr %slot84, align 8
  %v448 = load i64, ptr %slot81, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %ld450 = load i64, ptr %p449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld450, ptr %slot85, align 8
  %v451 = load i64, ptr %slot85, align 8
  %cmp452 = icmp ne i64 %v451, 0
  %cv453 = zext i1 %cmp452 to i32
  store i32 %cv453, ptr %slot86, align 8
  %v454 = load i32, ptr %slot86, align 8
  %cv455 = zext i32 %v454 to i64
  %cond456 = icmp ne i64 %cv455, 0
  br i1 %cond456, label %bb_rcgnn117, label %bb_rcgdone117
bb_rcgnn117:
  %v457 = load i64, ptr %slot85, align 8
  %op458 = sub i64 %v457, 16
  store i64 %op458, ptr %slot87, align 8
  %v459 = load i64, ptr %slot85, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %rgep461 = getelementptr i8, ptr %p460, i64 -16
  %ld462 = load i64, ptr %rgep461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld462, ptr %slot88, align 8
  %v463 = load i64, ptr %slot88, align 8
  %op464 = and i64 %v463, 4611686018427387906
  store i64 %op464, ptr %slot89, align 8
  %v465 = load i64, ptr %slot89, align 8
  %cmp466 = icmp ne i64 %v465, 0
  %cv467 = zext i1 %cmp466 to i32
  store i32 %cv467, ptr %slot90, align 8
  %v468 = load i32, ptr %slot90, align 8
  %cv469 = zext i32 %v468 to i64
  %cond470 = icmp ne i64 %cv469, 0
  br i1 %cond470, label %bb_rcgclear117, label %bb_rcgcounted117
bb_rcgcounted117:
  %v471 = load i64, ptr %slot85, align 8
  %op472 = sub i64 %v471, 24
  store i64 %op472, ptr %slot91, align 8
  %v473 = load i64, ptr %slot85, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %rgep475 = getelementptr i8, ptr %p474, i64 -24
  %ld476 = load i64, ptr %rgep475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld476, ptr %slot92, align 8
  %v477 = load i64, ptr %slot92, align 8
  %op478 = sub i64 %v477, 1
  store i64 %op478, ptr %slot93, align 8
  %v479 = load i64, ptr %slot93, align 8
  %cmp480 = icmp eq i64 %v479, 0
  %cv481 = zext i1 %cmp480 to i32
  store i32 %cv481, ptr %slot94, align 8
  %v482 = load i32, ptr %slot94, align 8
  %cv483 = zext i32 %v482 to i64
  %cond484 = icmp ne i64 %cv483, 0
  br i1 %cond484, label %bb_rcglast117, label %bb_rcgdec117
bb_rcglast117:
  %v485 = load i64, ptr %slot85, align 8
  %op486 = sub i64 %v485, 32
  store i64 %op486, ptr %slot95, align 8
  %v487 = load i64, ptr %slot85, align 8
  %p488 = inttoptr i64 %v487 to ptr
  %rgep489 = getelementptr i8, ptr %p488, i64 -32
  %ld490 = load i64, ptr %rgep489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld490, ptr %slot96, align 8
  %v491 = load i64, ptr %slot96, align 8
  %cmp492 = icmp ne i64 %v491, 0
  %cv493 = zext i1 %cmp492 to i32
  store i32 %cv493, ptr %slot97, align 8
  %v494 = load i32, ptr %slot97, align 8
  %cv495 = zext i32 %v494 to i64
  %cond496 = icmp ne i64 %cv495, 0
  br i1 %cond496, label %bb_rcgdec117, label %bb_rcgslow117
bb_rcgslow117:
  %v497 = load i64, ptr %slot84, align 8
  %v498 = load i64, ptr %slot81, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v497, i64 %v498) nomerge, !dbg !118
  br label %bb_rcgdone117
bb_rcgdec117:
  %v499 = load i64, ptr %slot93, align 8
  %v500 = load i64, ptr %slot85, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %rgep502 = getelementptr i8, ptr %p501, i64 -24
  store i64 %v499, ptr %rgep502, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear117
bb_rcgclear117:
  %v503 = load i64, ptr %slot81, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i64 0, ptr %p504, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone117
bb_rcgdone117:
  br label %bb_rcslotdone101
bb_rcslotowner101:
  %v505 = load i64, ptr %slot22, align 8
  store i64 %v505, ptr %slot98, align 8
  %v506 = load i64, ptr %slot81, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %ld508 = load i64, ptr %p507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld508, ptr %slot99, align 8
  %v509 = load i64, ptr %slot99, align 8
  %cmp510 = icmp ne i64 %v509, 0
  %cv511 = zext i1 %cmp510 to i32
  store i32 %cv511, ptr %slot100, align 8
  %v512 = load i32, ptr %slot100, align 8
  %cv513 = zext i32 %v512 to i64
  %cond514 = icmp ne i64 %cv513, 0
  br i1 %cond514, label %bb_rcgnn132, label %bb_rcgdone132
bb_rcgnn132:
  %v515 = load i64, ptr %slot99, align 8
  %op516 = sub i64 %v515, 16
  store i64 %op516, ptr %slot101, align 8
  %v517 = load i64, ptr %slot99, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %rgep519 = getelementptr i8, ptr %p518, i64 -16
  %ld520 = load i64, ptr %rgep519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld520, ptr %slot102, align 8
  %v521 = load i64, ptr %slot102, align 8
  %op522 = and i64 %v521, 4611686018427387906
  store i64 %op522, ptr %slot103, align 8
  %v523 = load i64, ptr %slot103, align 8
  %cmp524 = icmp ne i64 %v523, 0
  %cv525 = zext i1 %cmp524 to i32
  store i32 %cv525, ptr %slot104, align 8
  %v526 = load i32, ptr %slot104, align 8
  %cv527 = zext i32 %v526 to i64
  %cond528 = icmp ne i64 %cv527, 0
  br i1 %cond528, label %bb_rcgclear132, label %bb_rcgcounted132
bb_rcgcounted132:
  %v529 = load i64, ptr %slot99, align 8
  %op530 = sub i64 %v529, 32
  store i64 %op530, ptr %slot105, align 8
  %v531 = load i64, ptr %slot99, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %rgep533 = getelementptr i8, ptr %p532, i64 -32
  %ld534 = load i64, ptr %rgep533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld534, ptr %slot106, align 8
  %v535 = load i64, ptr %slot106, align 8
  %op536 = sub i64 %v535, 1
  store i64 %op536, ptr %slot107, align 8
  %v537 = load i64, ptr %slot107, align 8
  %cmp538 = icmp eq i64 %v537, 0
  %cv539 = zext i1 %cmp538 to i32
  store i32 %cv539, ptr %slot108, align 8
  %v540 = load i32, ptr %slot108, align 8
  %cv541 = zext i32 %v540 to i64
  %cond542 = icmp ne i64 %cv541, 0
  br i1 %cond542, label %bb_rcglast132, label %bb_rcgdec132
bb_rcglast132:
  %v543 = load i64, ptr %slot99, align 8
  %op544 = sub i64 %v543, 24
  store i64 %op544, ptr %slot109, align 8
  %v545 = load i64, ptr %slot99, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %rgep547 = getelementptr i8, ptr %p546, i64 -24
  %ld548 = load i64, ptr %rgep547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld548, ptr %slot110, align 8
  %v549 = load i64, ptr %slot110, align 8
  %cmp550 = icmp ne i64 %v549, 0
  %cv551 = zext i1 %cmp550 to i32
  store i32 %cv551, ptr %slot111, align 8
  %v552 = load i32, ptr %slot111, align 8
  %cv553 = zext i32 %v552 to i64
  %cond554 = icmp ne i64 %cv553, 0
  br i1 %cond554, label %bb_rcgdec132, label %bb_rcgslow132
bb_rcgslow132:
  %v555 = load i64, ptr %slot98, align 8
  %v556 = load i64, ptr %slot81, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v555, i64 %v556) nomerge, !dbg !118
  br label %bb_rcgdone132
bb_rcgdec132:
  %v557 = load i64, ptr %slot107, align 8
  %v558 = load i64, ptr %slot99, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %rgep560 = getelementptr i8, ptr %p559, i64 -32
  store i64 %v557, ptr %rgep560, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear132
bb_rcgclear132:
  %v561 = load i64, ptr %slot81, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 0, ptr %p562, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone132
bb_rcgdone132:
  br label %bb_rcslotdone101
bb_rcslotdone101:
  %v563 = load i64, ptr %slot14, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot112, align 8
  %v566 = load i64, ptr %slot112, align 8
  ret i64 %v566
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64, i64, i64)
declare i64 @myl_f_be55845d0d1b5c3c8f232826f6eebbc3f154bbc843ca36782c227966ffc2f923(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4", linkageName: "myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7642310001278082280, i64 0, !"myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
