target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f(ptr sret([88 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v679 = load i64, ptr %slot1, align 8
  %op680 = add i64 %v679, 32
  store i64 %op680, ptr %slot3, align 8
  %mem681 = alloca i8, i64 88, align 8
  %ptr682 = ptrtoint ptr %mem681 to i64
  store i64 %ptr682, ptr %slot4, align 8
  %mem683 = alloca i8, i64 8, align 8
  %ptr684 = ptrtoint ptr %mem683 to i64
  store i64 %ptr684, ptr %slot5, align 8
  %mem685 = alloca i8, i64 8, align 8
  %ptr686 = ptrtoint ptr %mem685 to i64
  store i64 %ptr686, ptr %slot6, align 8
  %mem687 = alloca i8, i64 8, align 8
  %ptr688 = ptrtoint ptr %mem687 to i64
  store i64 %ptr688, ptr %slot7, align 8
  %mem689 = alloca i8, i64 8, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot8, align 8
  %mem691 = alloca i8, i64 8, align 8
  %ptr692 = ptrtoint ptr %mem691 to i64
  store i64 %ptr692, ptr %slot9, align 8
  %mem693 = alloca i8, i64 8, align 8
  %ptr694 = ptrtoint ptr %mem693 to i64
  store i64 %ptr694, ptr %slot10, align 8
  %mem695 = alloca i8, i64 392, align 8
  %ptr696 = ptrtoint ptr %mem695 to i64
  store i64 %ptr696, ptr %slot11, align 8
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot12, align 8
  %mem699 = alloca i8, i64 392, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot13, align 8
  %mem701 = alloca i8, i64 32, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot14, align 8
  %v703 = load i64, ptr %slot14, align 8
  %p705 = inttoptr i64 %v703 to ptr
  %gep706 = getelementptr i8, ptr %p705, i64 24
  %op704 = ptrtoint ptr %gep706 to i64
  store i64 %op704, ptr %slot15, align 8
  %v707 = load i64, ptr %slot15, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i64 0, ptr %p708, align 8, !alias.scope !3, !noalias !4
  %mem709 = alloca i8, i64 32, align 8
  %ptr710 = ptrtoint ptr %mem709 to i64
  store i64 %ptr710, ptr %slot16, align 8
  %v711 = load i64, ptr %slot16, align 8
  %p713 = inttoptr i64 %v711 to ptr
  %gep714 = getelementptr i8, ptr %p713, i64 24
  %op712 = ptrtoint ptr %gep714 to i64
  store i64 %op712, ptr %slot17, align 8
  %v715 = load i64, ptr %slot17, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 0, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %mem717 = alloca i8, i64 16, align 8
  %ptr718 = ptrtoint ptr %mem717 to i64
  store i64 %ptr718, ptr %slot18, align 8
  %mem719 = alloca i8, i64 8, align 8
  %ptr720 = ptrtoint ptr %mem719 to i64
  store i64 %ptr720, ptr %slot19, align 8
  %mem721 = alloca i8, i64 8, align 8
  %ptr722 = ptrtoint ptr %mem721 to i64
  store i64 %ptr722, ptr %slot20, align 8
  %mem723 = alloca i8, i64 88, align 8
  %ptr724 = ptrtoint ptr %mem723 to i64
  store i64 %ptr724, ptr %slot21, align 8
  %mem725 = alloca i8, i64 8, align 8
  %ptr726 = ptrtoint ptr %mem725 to i64
  store i64 %ptr726, ptr %slot22, align 8
  %mem727 = alloca i8, i64 8, align 8
  %ptr728 = ptrtoint ptr %mem727 to i64
  store i64 %ptr728, ptr %slot23, align 8
  %mem729 = alloca i8, i64 88, align 8
  %ptr730 = ptrtoint ptr %mem729 to i64
  store i64 %ptr730, ptr %slot24, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem731 = alloca i8, i64 8, align 8
  %ptr732 = ptrtoint ptr %mem731 to i64
  store i64 %ptr732, ptr %slot25, align 8
  %v733 = load i64, ptr %slot1, align 8
  %op734 = add i64 %v733, 64
  store i64 %op734, ptr %slot26, align 8
  %v735 = load i64, ptr %slot26, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !4, !noalias !3
  store i64 %ld737, ptr %slot27, align 8
  %stack738 = call ptr @llvm.stacksave()
  %stackaddr739 = ptrtoint ptr %stack738 to i64
  %v740 = load i64, ptr %slot27, align 8
  %cmp741 = icmp ult i64 %stackaddr739, %v740
  %cv742 = zext i1 %cmp741 to i64
  store i64 %cv742, ptr %slot28, align 8
  %v743 = load i64, ptr %slot28, align 8
  %cond744 = icmp ne i64 %v743, 0
  br i1 %cond744, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v745 = load i64, ptr %slot1, align 8
  %p746 = inttoptr i64 %v745 to ptr
  call void @myl_qbe_fail_frame(ptr %p746) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %mem747 = alloca i8, i64 88, align 8
  %ptr748 = ptrtoint ptr %mem747 to i64
  store i64 %ptr748, ptr %slot29, align 8
  %mem749 = alloca i8, i64 8, align 8
  %ptr750 = ptrtoint ptr %mem749 to i64
  store i64 %ptr750, ptr %slot30, align 8
  %v751 = load i64, ptr %slot20, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i64 0, ptr %p752, align 8, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot22, align 8
  %p754 = inttoptr i64 %v753 to ptr
  store i64 0, ptr %p754, align 8, !alias.scope !3, !noalias !4
  %v755 = load i64, ptr %slot2, align 8
  %v756 = load i64, ptr %slot19, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i64 %v755, ptr %p757, align 8, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot1, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %call760 = call ptr @myl_qbe_heap(ptr %p759) nomerge, !dbg !112
  %calladdr761 = ptrtoint ptr %call760 to i64
  store i64 %calladdr761, ptr %slot31, align 8
  %v762 = load i64, ptr %slot1, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %call764 = call i64 @myl_qbe_region_mark(ptr %p763) nomerge, !dbg !112
  store i64 %call764, ptr %slot32, align 8
  %v765 = load i64, ptr %slot5, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i32 0, ptr %p766, align 4, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot6, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i32 0, ptr %p768, align 4, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot7, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i32 0, ptr %p770, align 4, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot8, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i32 0, ptr %p772, align 4, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot9, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 0, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot10, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 0, ptr %p776, align 4, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot6, align 8
  %p778 = inttoptr i64 %v777 to ptr
  store i32 2, ptr %p778, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v779 = load i64, ptr %slot19, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %ld781 = load i64, ptr %p780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld781, ptr %slot33, align 8
  %v782 = load i64, ptr %slot33, align 8
  %v783 = load i64, ptr %slot23, align 8
  %p784 = inttoptr i64 %v783 to ptr
  store i64 %v782, ptr %p784, align 8, !alias.scope !3, !noalias !4
  %v785 = load i64, ptr %slot23, align 8
  %p786 = inttoptr i64 %v785 to ptr
  %ld787 = load i64, ptr %p786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld787, ptr %slot34, align 8
  %v788 = load i64, ptr %slot1, align 8
  %v789 = load i64, ptr %slot34, align 8
  %call790 = call i64 @myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae(i64 %v788, i64 %v789) nomerge, !dbg !114
  store i64 %call790, ptr %slot35, align 8
  %v791 = load i64, ptr %slot35, align 8
  %v792 = load i64, ptr %slot23, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 %v791, ptr %p793, align 8, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot7, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i32, ptr %p795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld796, ptr %slot36, align 8
  %v797 = load i32, ptr %slot36, align 8
  %cv798 = zext i32 %v797 to i64
  %cond799 = icmp ne i64 %cv798, 0
  br i1 %cond799, label %bb_rcslotdrop18, label %bb_rcslotdone18
bb_rcslotdrop18:
  %v800 = load i64, ptr %slot7, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 0, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot11, align 8
  store i64 %v802, ptr %slot37, align 8
  %v803 = load i64, ptr %slot8, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i32, ptr %p804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld805, ptr %slot38, align 8
  %v806 = load i32, ptr %slot38, align 8
  %op807 = and i32 %v806, 28
  store i32 %op807, ptr %slot39, align 8
  %v808 = load i32, ptr %slot39, align 8
  %cv809 = zext i32 %v808 to i64
  %cond810 = icmp ne i64 %cv809, 0
  br i1 %cond810, label %bb_rcslotrole18, label %bb_rcslotowner18
bb_rcslotrole18:
  %v811 = load i64, ptr %slot31, align 8
  store i64 %v811, ptr %slot40, align 8
  %v812 = load i64, ptr %slot40, align 8
  %v813 = load i64, ptr %slot37, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v812, i64 %v813) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotowner18:
  %v814 = load i64, ptr %slot31, align 8
  store i64 %v814, ptr %slot41, align 8
  %v815 = load i64, ptr %slot41, align 8
  %v816 = load i64, ptr %slot37, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v815, i64 %v816) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotdone18:
  %v817 = load i64, ptr %slot19, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot42, align 8
  %v820 = load i64, ptr %slot42, align 8
  %v821 = load i64, ptr %slot23, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i64 %v820, ptr %p822, align 8, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot23, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot43, align 8
  %v826 = load i64, ptr %slot43, align 8
  %op827 = add i64 %v826, 376
  store i64 %op827, ptr %slot44, align 8
  %v828 = load i64, ptr %slot44, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i64, ptr %p829, align 8, !alias.scope !4, !noalias !3
  store i64 %ld830, ptr %slot45, align 8
  %v831 = load i64, ptr %slot45, align 8
  %v832 = load i64, ptr %slot23, align 8
  %p833 = inttoptr i64 %v832 to ptr
  store i64 %v831, ptr %p833, align 8, !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot23, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %ld836 = load i64, ptr %p835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld836, ptr %slot46, align 8
  %v837 = load i64, ptr %slot46, align 8
  %v838 = load i64, ptr %slot12, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i64 %v837, ptr %p839, align 8, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot12, align 8
  store i64 %v840, ptr %slot47, align 8
  %v841 = load i64, ptr %slot13, align 8
  store i64 %v841, ptr %slot48, align 8
  %v842 = load i64, ptr %slot47, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i64, ptr %p843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld844, ptr %slot49, align 8
  %v845 = load i64, ptr %slot49, align 8
  %cmp846 = icmp ne i64 %v845, 0
  %cv847 = zext i1 %cmp846 to i32
  store i32 %cv847, ptr %slot50, align 8
  %v848 = load i32, ptr %slot50, align 8
  %cv849 = zext i32 %v848 to i64
  %cond850 = icmp ne i64 %cv849, 0
  br i1 %cond850, label %bb_rcgnn33, label %bb_rcgstore33
bb_rcgnn33:
  %v851 = load i64, ptr %slot49, align 8
  %op852 = sub i64 %v851, 16
  store i64 %op852, ptr %slot51, align 8
  %v853 = load i64, ptr %slot49, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %rgep855 = getelementptr i8, ptr %p854, i64 -16
  %ld856 = load i64, ptr %rgep855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld856, ptr %slot52, align 8
  %v857 = load i64, ptr %slot52, align 8
  %op858 = and i64 %v857, 4611686018427387906
  store i64 %op858, ptr %slot53, align 8
  %v859 = load i64, ptr %slot53, align 8
  %cmp860 = icmp ne i64 %v859, 0
  %cv861 = zext i1 %cmp860 to i32
  store i32 %cv861, ptr %slot54, align 8
  %v862 = load i32, ptr %slot54, align 8
  %cv863 = zext i32 %v862 to i64
  %cond864 = icmp ne i64 %cv863, 0
  br i1 %cond864, label %bb_rcgstore33, label %bb_rcginc33
bb_rcginc33:
  %v865 = load i64, ptr %slot49, align 8
  %op866 = sub i64 %v865, 24
  store i64 %op866, ptr %slot55, align 8
  %v867 = load i64, ptr %slot49, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %rgep869 = getelementptr i8, ptr %p868, i64 -24
  %ld870 = load i64, ptr %rgep869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld870, ptr %slot56, align 8
  %v871 = load i64, ptr %slot56, align 8
  %op872 = add i64 %v871, 1
  store i64 %op872, ptr %slot57, align 8
  %v873 = load i64, ptr %slot57, align 8
  %cmp874 = icmp eq i64 %v873, 0
  %cv875 = zext i1 %cmp874 to i32
  store i32 %cv875, ptr %slot58, align 8
  %v876 = load i32, ptr %slot58, align 8
  %cv877 = zext i32 %v876 to i64
  %cond878 = icmp ne i64 %cv877, 0
  br i1 %cond878, label %bb_rcglimit33, label %bb_rcgcapacity33
bb_rcglimit33:
  %v879 = load i64, ptr %slot1, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %call881 = call i32 @myl_qbe_rc_status(ptr %p880, i32 2) nomerge, !dbg !116
  store i32 %call881, ptr %slot59, align 8
  br label %bb_failure
bb_rcgcapacity33:
  %v882 = load i64, ptr %slot57, align 8
  %v883 = load i64, ptr %slot49, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %rgep885 = getelementptr i8, ptr %p884, i64 -24
  store i64 %v882, ptr %rgep885, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore33
bb_rcgstore33:
  %v886 = load i64, ptr %slot49, align 8
  %v887 = load i64, ptr %slot48, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i64 %v886, ptr %p888, align 8, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot10, align 8
  %p890 = inttoptr i64 %v889 to ptr
  store i32 2, ptr %p890, align 4, !alias.scope !3, !noalias !4
  %v891 = load i64, ptr %slot10, align 8
  %p892 = inttoptr i64 %v891 to ptr
  store i32 16, ptr %p892, align 4, !alias.scope !3, !noalias !4
  %v893 = load i64, ptr %slot9, align 8
  %p894 = inttoptr i64 %v893 to ptr
  store i32 1, ptr %p894, align 4, !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot7, align 8
  %p896 = inttoptr i64 %v895 to ptr
  %ld897 = load i32, ptr %p896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld897, ptr %slot60, align 8
  %v898 = load i32, ptr %slot60, align 8
  %cv899 = zext i32 %v898 to i64
  %cond900 = icmp ne i64 %cv899, 0
  br i1 %cond900, label %bb_rcslotdrop49, label %bb_rcslotdone49
bb_rcslotdrop49:
  %v901 = load i64, ptr %slot7, align 8
  %p902 = inttoptr i64 %v901 to ptr
  store i32 0, ptr %p902, align 4, !alias.scope !3, !noalias !4
  %v903 = load i64, ptr %slot11, align 8
  store i64 %v903, ptr %slot61, align 8
  %v904 = load i64, ptr %slot8, align 8
  %p905 = inttoptr i64 %v904 to ptr
  %ld906 = load i32, ptr %p905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld906, ptr %slot62, align 8
  %v907 = load i32, ptr %slot62, align 8
  %op908 = and i32 %v907, 28
  store i32 %op908, ptr %slot63, align 8
  %v909 = load i32, ptr %slot63, align 8
  %cv910 = zext i32 %v909 to i64
  %cond911 = icmp ne i64 %cv910, 0
  br i1 %cond911, label %bb_rcslotrole49, label %bb_rcslotowner49
bb_rcslotrole49:
  %v912 = load i64, ptr %slot31, align 8
  store i64 %v912, ptr %slot64, align 8
  %v913 = load i64, ptr %slot64, align 8
  %v914 = load i64, ptr %slot61, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v913, i64 %v914) nomerge, !dbg !116
  br label %bb_rcslotdone49
bb_rcslotowner49:
  %v915 = load i64, ptr %slot31, align 8
  store i64 %v915, ptr %slot65, align 8
  %v916 = load i64, ptr %slot65, align 8
  %v917 = load i64, ptr %slot61, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v916, i64 %v917) nomerge, !dbg !116
  br label %bb_rcslotdone49
bb_rcslotdone49:
  %v918 = load i64, ptr %slot11, align 8
  store i64 %v918, ptr %slot66, align 8
  %v919 = load i64, ptr %slot13, align 8
  store i64 %v919, ptr %slot67, align 8
  %v920 = load i64, ptr %slot67, align 8
  %v921 = load i64, ptr %slot66, align 8
  %p922 = inttoptr i64 %v920 to ptr
  %p923 = inttoptr i64 %v921 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p923, ptr %p922, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot8, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i32 2, ptr %p925, align 4, !alias.scope !3, !noalias !4
  %v926 = load i64, ptr %slot10, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot68, align 8
  %v929 = load i32, ptr %slot68, align 8
  %v930 = load i64, ptr %slot8, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 %v929, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot9, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 0, ptr %p933, align 4, !alias.scope !3, !noalias !4
  %v934 = load i64, ptr %slot7, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i32 1, ptr %p935, align 4, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot66, align 8
  %p937 = inttoptr i64 %v936 to ptr
  %ld938 = load i64, ptr %p937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld938, ptr %slot69, align 8
  %v939 = load i64, ptr %slot69, align 8
  %v940 = load i64, ptr %slot23, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i64 %v939, ptr %p941, align 8, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot23, align 8
  %p943 = inttoptr i64 %v942 to ptr
  %ld944 = load i64, ptr %p943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld944, ptr %slot70, align 8
  %v945 = load i64, ptr %slot19, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i64, ptr %p946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld947, ptr %slot71, align 8
  %v948 = load i64, ptr %slot7, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i32, ptr %p949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld950, ptr %slot72, align 8
  %v951 = load i32, ptr %slot72, align 8
  %cv952 = zext i32 %v951 to i64
  %cond953 = icmp ne i64 %cv952, 0
  br i1 %cond953, label %bb_rcslotdrop70, label %bb_rcslotdone70
bb_rcslotdrop70:
  %v954 = load i64, ptr %slot7, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i32 0, ptr %p955, align 4, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot11, align 8
  store i64 %v956, ptr %slot73, align 8
  %v957 = load i64, ptr %slot8, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ld959 = load i32, ptr %p958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld959, ptr %slot74, align 8
  %v960 = load i32, ptr %slot74, align 8
  %op961 = and i32 %v960, 28
  store i32 %op961, ptr %slot75, align 8
  %v962 = load i32, ptr %slot75, align 8
  %cv963 = zext i32 %v962 to i64
  %cond964 = icmp ne i64 %cv963, 0
  br i1 %cond964, label %bb_rcslotrole70, label %bb_rcslotowner70
bb_rcslotrole70:
  %v965 = load i64, ptr %slot31, align 8
  store i64 %v965, ptr %slot76, align 8
  %v966 = load i64, ptr %slot73, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %ld968 = load i64, ptr %p967, align 8, !alias.scope !3, !noalias !4
  store i64 %ld968, ptr %slot77, align 8
  %v969 = load i64, ptr %slot77, align 8
  %cmp970 = icmp ne i64 %v969, 0
  %cv971 = zext i1 %cmp970 to i32
  store i32 %cv971, ptr %slot78, align 8
  %v972 = load i32, ptr %slot78, align 8
  %cv973 = zext i32 %v972 to i64
  %cond974 = icmp ne i64 %cv973, 0
  br i1 %cond974, label %bb_rcgnn86, label %bb_rcgdone86
bb_rcgnn86:
  %v975 = load i64, ptr %slot77, align 8
  %op976 = sub i64 %v975, 16
  store i64 %op976, ptr %slot79, align 8
  %v977 = load i64, ptr %slot77, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %rgep979 = getelementptr i8, ptr %p978, i64 -16
  %ld980 = load i64, ptr %rgep979, align 8, !alias.scope !9, !noalias !10
  store i64 %ld980, ptr %slot80, align 8
  %v981 = load i64, ptr %slot80, align 8
  %op982 = and i64 %v981, 4611686018427387906
  store i64 %op982, ptr %slot81, align 8
  %v983 = load i64, ptr %slot81, align 8
  %cmp984 = icmp ne i64 %v983, 0
  %cv985 = zext i1 %cmp984 to i32
  store i32 %cv985, ptr %slot82, align 8
  %v986 = load i32, ptr %slot82, align 8
  %cv987 = zext i32 %v986 to i64
  %cond988 = icmp ne i64 %cv987, 0
  br i1 %cond988, label %bb_rcgclear86, label %bb_rcgcounted86
bb_rcgcounted86:
  %v989 = load i64, ptr %slot77, align 8
  %op990 = sub i64 %v989, 24
  store i64 %op990, ptr %slot83, align 8
  %v991 = load i64, ptr %slot77, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %rgep993 = getelementptr i8, ptr %p992, i64 -24
  %ld994 = load i64, ptr %rgep993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld994, ptr %slot84, align 8
  %v995 = load i64, ptr %slot84, align 8
  %op996 = sub i64 %v995, 1
  store i64 %op996, ptr %slot85, align 8
  %v997 = load i64, ptr %slot85, align 8
  %cmp998 = icmp eq i64 %v997, 0
  %cv999 = zext i1 %cmp998 to i32
  store i32 %cv999, ptr %slot86, align 8
  %v1000 = load i32, ptr %slot86, align 8
  %cv1001 = zext i32 %v1000 to i64
  %cond1002 = icmp ne i64 %cv1001, 0
  br i1 %cond1002, label %bb_rcglast86, label %bb_rcgdec86
bb_rcglast86:
  %v1003 = load i64, ptr %slot77, align 8
  %op1004 = sub i64 %v1003, 32
  store i64 %op1004, ptr %slot87, align 8
  %v1005 = load i64, ptr %slot77, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  %rgep1007 = getelementptr i8, ptr %p1006, i64 -32
  %ld1008 = load i64, ptr %rgep1007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1008, ptr %slot88, align 8
  %v1009 = load i64, ptr %slot88, align 8
  %cmp1010 = icmp ne i64 %v1009, 0
  %cv1011 = zext i1 %cmp1010 to i32
  store i32 %cv1011, ptr %slot89, align 8
  %v1012 = load i32, ptr %slot89, align 8
  %cv1013 = zext i32 %v1012 to i64
  %cond1014 = icmp ne i64 %cv1013, 0
  br i1 %cond1014, label %bb_rcgdec86, label %bb_rcgslow86
bb_rcgslow86:
  %v1015 = load i64, ptr %slot76, align 8
  %v1016 = load i64, ptr %slot73, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v1015, i64 %v1016) nomerge, !dbg !118
  br label %bb_rcgdone86
bb_rcgdec86:
  %v1017 = load i64, ptr %slot85, align 8
  %v1018 = load i64, ptr %slot77, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %rgep1020 = getelementptr i8, ptr %p1019, i64 -24
  store i64 %v1017, ptr %rgep1020, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear86
bb_rcgclear86:
  %v1021 = load i64, ptr %slot73, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i64 0, ptr %p1022, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone86
bb_rcgdone86:
  br label %bb_rcslotdone70
bb_rcslotowner70:
  %v1023 = load i64, ptr %slot31, align 8
  store i64 %v1023, ptr %slot90, align 8
  %v1024 = load i64, ptr %slot73, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %ld1026 = load i64, ptr %p1025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1026, ptr %slot91, align 8
  %v1027 = load i64, ptr %slot91, align 8
  %cmp1028 = icmp ne i64 %v1027, 0
  %cv1029 = zext i1 %cmp1028 to i32
  store i32 %cv1029, ptr %slot92, align 8
  %v1030 = load i32, ptr %slot92, align 8
  %cv1031 = zext i32 %v1030 to i64
  %cond1032 = icmp ne i64 %cv1031, 0
  br i1 %cond1032, label %bb_rcgnn101, label %bb_rcgdone101
bb_rcgnn101:
  %v1033 = load i64, ptr %slot91, align 8
  %op1034 = sub i64 %v1033, 16
  store i64 %op1034, ptr %slot93, align 8
  %v1035 = load i64, ptr %slot91, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %rgep1037 = getelementptr i8, ptr %p1036, i64 -16
  %ld1038 = load i64, ptr %rgep1037, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1038, ptr %slot94, align 8
  %v1039 = load i64, ptr %slot94, align 8
  %op1040 = and i64 %v1039, 4611686018427387906
  store i64 %op1040, ptr %slot95, align 8
  %v1041 = load i64, ptr %slot95, align 8
  %cmp1042 = icmp ne i64 %v1041, 0
  %cv1043 = zext i1 %cmp1042 to i32
  store i32 %cv1043, ptr %slot96, align 8
  %v1044 = load i32, ptr %slot96, align 8
  %cv1045 = zext i32 %v1044 to i64
  %cond1046 = icmp ne i64 %cv1045, 0
  br i1 %cond1046, label %bb_rcgclear101, label %bb_rcgcounted101
bb_rcgcounted101:
  %v1047 = load i64, ptr %slot91, align 8
  %op1048 = sub i64 %v1047, 32
  store i64 %op1048, ptr %slot97, align 8
  %v1049 = load i64, ptr %slot91, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %rgep1051 = getelementptr i8, ptr %p1050, i64 -32
  %ld1052 = load i64, ptr %rgep1051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1052, ptr %slot98, align 8
  %v1053 = load i64, ptr %slot98, align 8
  %op1054 = sub i64 %v1053, 1
  store i64 %op1054, ptr %slot99, align 8
  %v1055 = load i64, ptr %slot99, align 8
  %cmp1056 = icmp eq i64 %v1055, 0
  %cv1057 = zext i1 %cmp1056 to i32
  store i32 %cv1057, ptr %slot100, align 8
  %v1058 = load i32, ptr %slot100, align 8
  %cv1059 = zext i32 %v1058 to i64
  %cond1060 = icmp ne i64 %cv1059, 0
  br i1 %cond1060, label %bb_rcglast101, label %bb_rcgdec101
bb_rcglast101:
  %v1061 = load i64, ptr %slot91, align 8
  %op1062 = sub i64 %v1061, 24
  store i64 %op1062, ptr %slot101, align 8
  %v1063 = load i64, ptr %slot91, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %rgep1065 = getelementptr i8, ptr %p1064, i64 -24
  %ld1066 = load i64, ptr %rgep1065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1066, ptr %slot102, align 8
  %v1067 = load i64, ptr %slot102, align 8
  %cmp1068 = icmp ne i64 %v1067, 0
  %cv1069 = zext i1 %cmp1068 to i32
  store i32 %cv1069, ptr %slot103, align 8
  %v1070 = load i32, ptr %slot103, align 8
  %cv1071 = zext i32 %v1070 to i64
  %cond1072 = icmp ne i64 %cv1071, 0
  br i1 %cond1072, label %bb_rcgdec101, label %bb_rcgslow101
bb_rcgslow101:
  %v1073 = load i64, ptr %slot90, align 8
  %v1074 = load i64, ptr %slot73, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v1073, i64 %v1074) nomerge, !dbg !118
  br label %bb_rcgdone101
bb_rcgdec101:
  %v1075 = load i64, ptr %slot99, align 8
  %v1076 = load i64, ptr %slot91, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %rgep1078 = getelementptr i8, ptr %p1077, i64 -32
  store i64 %v1075, ptr %rgep1078, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear101
bb_rcgclear101:
  %v1079 = load i64, ptr %slot73, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i64 0, ptr %p1080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone101
bb_rcgdone101:
  br label %bb_rcslotdone70
bb_rcslotdone70:
  %v1081 = load i64, ptr %slot71, align 8
  %op1082 = add i64 %v1081, 376
  store i64 %op1082, ptr %slot104, align 8
  store i64 0, ptr %slot105, align 8
  %v1083 = load i64, ptr %slot104, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i64, ptr %p1084, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1085, ptr %slot106, align 8
  %v1086 = load i64, ptr %slot106, align 8
  %cmp1087 = icmp ne i64 %v1086, 0
  %cv1088 = zext i1 %cmp1087 to i32
  store i32 %cv1088, ptr %slot107, align 8
  %v1089 = load i32, ptr %slot107, align 8
  %cv1090 = zext i32 %v1089 to i64
  %cond1091 = icmp ne i64 %cv1090, 0
  br i1 %cond1091, label %bb_rcguniquenn107, label %bb_rcgunique107
bb_rcguniquenn107:
  %v1092 = load i64, ptr %slot106, align 8
  %op1093 = sub i64 %v1092, 16
  store i64 %op1093, ptr %slot108, align 8
  %v1094 = load i64, ptr %slot106, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %rgep1096 = getelementptr i8, ptr %p1095, i64 -16
  %ld1097 = load i64, ptr %rgep1096, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1097, ptr %slot109, align 8
  %v1098 = load i64, ptr %slot109, align 8
  %op1099 = and i64 %v1098, 6917529027641081858
  store i64 %op1099, ptr %slot110, align 8
  %v1100 = load i64, ptr %slot110, align 8
  %cmp1101 = icmp ne i64 %v1100, 0
  %cv1102 = zext i1 %cmp1101 to i32
  store i32 %cv1102, ptr %slot111, align 8
  %v1103 = load i32, ptr %slot111, align 8
  %cv1104 = zext i32 %v1103 to i64
  %cond1105 = icmp ne i64 %cv1104, 0
  br i1 %cond1105, label %bb_rcguniqueslow107, label %bb_rcguniquecount107
bb_rcguniquecount107:
  %v1106 = load i64, ptr %slot106, align 8
  %op1107 = sub i64 %v1106, 32
  store i64 %op1107, ptr %slot112, align 8
  %v1108 = load i64, ptr %slot106, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %rgep1110 = getelementptr i8, ptr %p1109, i64 -32
  %ld1111 = load i64, ptr %rgep1110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1111, ptr %slot113, align 8
  %v1112 = load i64, ptr %slot113, align 8
  %cmp1113 = icmp ult i64 %v1112, 2
  %cv1114 = zext i1 %cmp1113 to i32
  store i32 %cv1114, ptr %slot114, align 8
  %v1115 = load i32, ptr %slot114, align 8
  %cv1116 = zext i32 %v1115 to i64
  %cond1117 = icmp ne i64 %cv1116, 0
  br i1 %cond1117, label %bb_rcgunique107, label %bb_rcguniqueslow107
bb_rcguniqueslow107:
  %v1118 = load i64, ptr %slot1, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  %p1120 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v1121 = load i64, ptr %slot104, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  %v1123 = load i64, ptr %slot105, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %call1125 = call i32 @myl_qbe_rc_unique_field(ptr %p1119, ptr %p1120, ptr %p1122, ptr %p1124) nomerge, !dbg !118
  store i32 %call1125, ptr %slot115, align 8
  %v1126 = load i32, ptr %slot115, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcunique117, label %bb_failure
bb_rcunique117:
  br label %bb_rcgunique107
bb_rcgunique107:
  %v1129 = load i64, ptr %slot104, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %ld1131 = load i64, ptr %p1130, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1131, ptr %slot116, align 8
  %v1132 = load i64, ptr %slot116, align 8
  %v1133 = load i64, ptr %slot23, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  store i64 %v1132, ptr %p1134, align 8, !alias.scope !3, !noalias !4
  %v1135 = load i64, ptr %slot23, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %ld1137 = load i64, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1137, ptr %slot117, align 8
  %v1138 = load i64, ptr %slot7, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  %ld1140 = load i32, ptr %p1139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1140, ptr %slot118, align 8
  %v1141 = load i32, ptr %slot118, align 8
  %cv1142 = zext i32 %v1141 to i64
  %cond1143 = icmp ne i64 %cv1142, 0
  br i1 %cond1143, label %bb_rcslotdrop122, label %bb_rcslotdone122
bb_rcslotdrop122:
  %v1144 = load i64, ptr %slot7, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i32 0, ptr %p1145, align 4, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot11, align 8
  store i64 %v1146, ptr %slot119, align 8
  %v1147 = load i64, ptr %slot8, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  %ld1149 = load i32, ptr %p1148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1149, ptr %slot120, align 8
  %v1150 = load i32, ptr %slot120, align 8
  %op1151 = and i32 %v1150, 28
  store i32 %op1151, ptr %slot121, align 8
  %v1152 = load i32, ptr %slot121, align 8
  %cv1153 = zext i32 %v1152 to i64
  %cond1154 = icmp ne i64 %cv1153, 0
  br i1 %cond1154, label %bb_rcslotrole122, label %bb_rcslotowner122
bb_rcslotrole122:
  %v1155 = load i64, ptr %slot31, align 8
  store i64 %v1155, ptr %slot122, align 8
  %v1156 = load i64, ptr %slot119, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %ld1158 = load i64, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1158, ptr %slot123, align 8
  %v1159 = load i64, ptr %slot123, align 8
  %cmp1160 = icmp ne i64 %v1159, 0
  %cv1161 = zext i1 %cmp1160 to i32
  store i32 %cv1161, ptr %slot124, align 8
  %v1162 = load i32, ptr %slot124, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcgnn138, label %bb_rcgdone138
bb_rcgnn138:
  %v1165 = load i64, ptr %slot123, align 8
  %op1166 = sub i64 %v1165, 16
  store i64 %op1166, ptr %slot125, align 8
  %v1167 = load i64, ptr %slot123, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  %rgep1169 = getelementptr i8, ptr %p1168, i64 -16
  %ld1170 = load i64, ptr %rgep1169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1170, ptr %slot126, align 8
  %v1171 = load i64, ptr %slot126, align 8
  %op1172 = and i64 %v1171, 4611686018427387906
  store i64 %op1172, ptr %slot127, align 8
  %v1173 = load i64, ptr %slot127, align 8
  %cmp1174 = icmp ne i64 %v1173, 0
  %cv1175 = zext i1 %cmp1174 to i32
  store i32 %cv1175, ptr %slot128, align 8
  %v1176 = load i32, ptr %slot128, align 8
  %cv1177 = zext i32 %v1176 to i64
  %cond1178 = icmp ne i64 %cv1177, 0
  br i1 %cond1178, label %bb_rcgclear138, label %bb_rcgcounted138
bb_rcgcounted138:
  %v1179 = load i64, ptr %slot123, align 8
  %op1180 = sub i64 %v1179, 24
  store i64 %op1180, ptr %slot129, align 8
  %v1181 = load i64, ptr %slot123, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %rgep1183 = getelementptr i8, ptr %p1182, i64 -24
  %ld1184 = load i64, ptr %rgep1183, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1184, ptr %slot130, align 8
  %v1185 = load i64, ptr %slot130, align 8
  %op1186 = sub i64 %v1185, 1
  store i64 %op1186, ptr %slot131, align 8
  %v1187 = load i64, ptr %slot131, align 8
  %cmp1188 = icmp eq i64 %v1187, 0
  %cv1189 = zext i1 %cmp1188 to i32
  store i32 %cv1189, ptr %slot132, align 8
  %v1190 = load i32, ptr %slot132, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcglast138, label %bb_rcgdec138
bb_rcglast138:
  %v1193 = load i64, ptr %slot123, align 8
  %op1194 = sub i64 %v1193, 32
  store i64 %op1194, ptr %slot133, align 8
  %v1195 = load i64, ptr %slot123, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %rgep1197 = getelementptr i8, ptr %p1196, i64 -32
  %ld1198 = load i64, ptr %rgep1197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1198, ptr %slot134, align 8
  %v1199 = load i64, ptr %slot134, align 8
  %cmp1200 = icmp ne i64 %v1199, 0
  %cv1201 = zext i1 %cmp1200 to i32
  store i32 %cv1201, ptr %slot135, align 8
  %v1202 = load i32, ptr %slot135, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcgdec138, label %bb_rcgslow138
bb_rcgslow138:
  %v1205 = load i64, ptr %slot122, align 8
  %v1206 = load i64, ptr %slot119, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v1205, i64 %v1206) nomerge, !dbg !118
  br label %bb_rcgdone138
bb_rcgdec138:
  %v1207 = load i64, ptr %slot131, align 8
  %v1208 = load i64, ptr %slot123, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %rgep1210 = getelementptr i8, ptr %p1209, i64 -24
  store i64 %v1207, ptr %rgep1210, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear138
bb_rcgclear138:
  %v1211 = load i64, ptr %slot119, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i64 0, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone138
bb_rcgdone138:
  br label %bb_rcslotdone122
bb_rcslotowner122:
  %v1213 = load i64, ptr %slot31, align 8
  store i64 %v1213, ptr %slot136, align 8
  %v1214 = load i64, ptr %slot119, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %ld1216 = load i64, ptr %p1215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1216, ptr %slot137, align 8
  %v1217 = load i64, ptr %slot137, align 8
  %cmp1218 = icmp ne i64 %v1217, 0
  %cv1219 = zext i1 %cmp1218 to i32
  store i32 %cv1219, ptr %slot138, align 8
  %v1220 = load i32, ptr %slot138, align 8
  %cv1221 = zext i32 %v1220 to i64
  %cond1222 = icmp ne i64 %cv1221, 0
  br i1 %cond1222, label %bb_rcgnn153, label %bb_rcgdone153
bb_rcgnn153:
  %v1223 = load i64, ptr %slot137, align 8
  %op1224 = sub i64 %v1223, 16
  store i64 %op1224, ptr %slot139, align 8
  %v1225 = load i64, ptr %slot137, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %rgep1227 = getelementptr i8, ptr %p1226, i64 -16
  %ld1228 = load i64, ptr %rgep1227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1228, ptr %slot140, align 8
  %v1229 = load i64, ptr %slot140, align 8
  %op1230 = and i64 %v1229, 4611686018427387906
  store i64 %op1230, ptr %slot141, align 8
  %v1231 = load i64, ptr %slot141, align 8
  %cmp1232 = icmp ne i64 %v1231, 0
  %cv1233 = zext i1 %cmp1232 to i32
  store i32 %cv1233, ptr %slot142, align 8
  %v1234 = load i32, ptr %slot142, align 8
  %cv1235 = zext i32 %v1234 to i64
  %cond1236 = icmp ne i64 %cv1235, 0
  br i1 %cond1236, label %bb_rcgclear153, label %bb_rcgcounted153
bb_rcgcounted153:
  %v1237 = load i64, ptr %slot137, align 8
  %op1238 = sub i64 %v1237, 32
  store i64 %op1238, ptr %slot143, align 8
  %v1239 = load i64, ptr %slot137, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %rgep1241 = getelementptr i8, ptr %p1240, i64 -32
  %ld1242 = load i64, ptr %rgep1241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1242, ptr %slot144, align 8
  %v1243 = load i64, ptr %slot144, align 8
  %op1244 = sub i64 %v1243, 1
  store i64 %op1244, ptr %slot145, align 8
  %v1245 = load i64, ptr %slot145, align 8
  %cmp1246 = icmp eq i64 %v1245, 0
  %cv1247 = zext i1 %cmp1246 to i32
  store i32 %cv1247, ptr %slot146, align 8
  %v1248 = load i32, ptr %slot146, align 8
  %cv1249 = zext i32 %v1248 to i64
  %cond1250 = icmp ne i64 %cv1249, 0
  br i1 %cond1250, label %bb_rcglast153, label %bb_rcgdec153
bb_rcglast153:
  %v1251 = load i64, ptr %slot137, align 8
  %op1252 = sub i64 %v1251, 24
  store i64 %op1252, ptr %slot147, align 8
  %v1253 = load i64, ptr %slot137, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  %rgep1255 = getelementptr i8, ptr %p1254, i64 -24
  %ld1256 = load i64, ptr %rgep1255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1256, ptr %slot148, align 8
  %v1257 = load i64, ptr %slot148, align 8
  %cmp1258 = icmp ne i64 %v1257, 0
  %cv1259 = zext i1 %cmp1258 to i32
  store i32 %cv1259, ptr %slot149, align 8
  %v1260 = load i32, ptr %slot149, align 8
  %cv1261 = zext i32 %v1260 to i64
  %cond1262 = icmp ne i64 %cv1261, 0
  br i1 %cond1262, label %bb_rcgdec153, label %bb_rcgslow153
bb_rcgslow153:
  %v1263 = load i64, ptr %slot136, align 8
  %v1264 = load i64, ptr %slot119, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v1263, i64 %v1264) nomerge, !dbg !118
  br label %bb_rcgdone153
bb_rcgdec153:
  %v1265 = load i64, ptr %slot145, align 8
  %v1266 = load i64, ptr %slot137, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %rgep1268 = getelementptr i8, ptr %p1267, i64 -32
  store i64 %v1265, ptr %rgep1268, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear153
bb_rcgclear153:
  %v1269 = load i64, ptr %slot119, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  store i64 0, ptr %p1270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone153
bb_rcgdone153:
  br label %bb_rcslotdone122
bb_rcslotdone122:
  %v1271 = load i64, ptr %slot14, align 8
  store i64 %v1271, ptr %slot150, align 8
  %v1272 = load i64, ptr %slot31, align 8
  %v1273 = load i64, ptr %slot150, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  store i64 %v1272, ptr %p1274, align 8, !alias.scope !3, !noalias !4
  %v1275 = load i64, ptr %slot31, align 8
  %p1277 = inttoptr i64 %v1275 to ptr
  %gep1278 = getelementptr i8, ptr %p1277, i64 5640
  %op1276 = ptrtoint ptr %gep1278 to i64
  store i64 %op1276, ptr %slot151, align 8
  %v1279 = load i64, ptr %slot151, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %ld1281 = load i64, ptr %p1280, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1281, ptr %slot152, align 8
  %v1282 = load i64, ptr %slot152, align 8
  %op1283 = add i64 %v1282, 248
  store i64 %op1283, ptr %slot153, align 8
  %v1284 = load i64, ptr %slot153, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i64, ptr %p1285, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1286, ptr %slot154, align 8
  %v1287 = load i64, ptr %slot150, align 8
  %p1289 = inttoptr i64 %v1287 to ptr
  %gep1290 = getelementptr i8, ptr %p1289, i64 8
  %op1288 = ptrtoint ptr %gep1290 to i64
  store i64 %op1288, ptr %slot155, align 8
  %v1291 = load i64, ptr %slot154, align 8
  %v1292 = load i64, ptr %slot155, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i64 %v1291, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot150, align 8
  %p1296 = inttoptr i64 %v1294 to ptr
  %gep1297 = getelementptr i8, ptr %p1296, i64 16
  %op1295 = ptrtoint ptr %gep1297 to i64
  store i64 %op1295, ptr %slot156, align 8
  %v1298 = load i64, ptr %slot156, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  store i64 0, ptr %p1299, align 8, !alias.scope !3, !noalias !4
  %v1300 = load i64, ptr %slot31, align 8
  %p1302 = inttoptr i64 %v1300 to ptr
  %gep1303 = getelementptr i8, ptr %p1302, i64 112
  %op1301 = ptrtoint ptr %gep1303 to i64
  store i64 %op1301, ptr %slot157, align 8
  %v1304 = load i64, ptr %slot150, align 8
  %p1306 = inttoptr i64 %v1304 to ptr
  %gep1307 = getelementptr i8, ptr %p1306, i64 24
  %op1305 = ptrtoint ptr %gep1307 to i64
  store i64 %op1305, ptr %slot158, align 8
  %v1308 = load i64, ptr %slot150, align 8
  %p1310 = inttoptr i64 %v1308 to ptr
  %gep1311 = getelementptr i8, ptr %p1310, i64 28
  %op1309 = ptrtoint ptr %gep1311 to i64
  store i64 %op1309, ptr %slot159, align 8
  %v1312 = load i64, ptr %slot157, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  %ld1314 = load i32, ptr %p1313, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld1314, ptr %slot160, align 8
  %v1315 = load i64, ptr %slot158, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 1, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i32, ptr %slot160, align 8
  %v1318 = load i64, ptr %slot159, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 %v1317, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot150, align 8
  %v1321 = load i64, ptr %slot153, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i64 %v1320, ptr %p1322, align 8, !alias.scope !9999998, !noalias !9999999
  %v1323 = load i64, ptr %slot117, align 8
  %cmp1324 = icmp ne i64 %v1323, 0
  %cv1325 = zext i1 %cmp1324 to i32
  store i32 %cv1325, ptr %slot161, align 8
  %v1326 = load i32, ptr %slot161, align 8
  %cv1327 = zext i32 %v1326 to i64
  %cond1328 = icmp ne i64 %cv1327, 0
  br i1 %cond1328, label %bb_rcspinmark205, label %bb_rcspindone205
bb_rcspinmark205:
  %v1329 = load i64, ptr %slot117, align 8
  %op1330 = sub i64 %v1329, 16
  store i64 %op1330, ptr %slot162, align 8
  %v1331 = load i64, ptr %slot117, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %rgep1333 = getelementptr i8, ptr %p1332, i64 -16
  %ld1334 = load i64, ptr %rgep1333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1334, ptr %slot163, align 8
  %v1335 = load i64, ptr %slot163, align 8
  %op1336 = and i64 %v1335, 2
  store i64 %op1336, ptr %slot164, align 8
  %v1337 = load i64, ptr %slot164, align 8
  %cmp1338 = icmp ne i64 %v1337, 0
  %cv1339 = zext i1 %cmp1338 to i32
  store i32 %cv1339, ptr %slot165, align 8
  %v1340 = load i32, ptr %slot165, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcspindone205, label %bb_rcspintype205
bb_rcspintype205:
  %v1343 = load i64, ptr %slot163, align 8
  %op1344 = and i64 %v1343, 4611686018427387907
  store i64 %op1344, ptr %slot166, align 8
  %v1345 = load i64, ptr %slot166, align 8
  %cmp1346 = icmp eq i64 %v1345, 0
  %cv1347 = zext i1 %cmp1346 to i32
  store i32 %cv1347, ptr %slot167, align 8
  %v1348 = load i32, ptr %slot167, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcs213, label %bb_rcspinslow205
bb_rcs213:
  %v1351 = load i64, ptr %slot117, align 8
  %op1352 = sub i64 %v1351, 8
  store i64 %op1352, ptr %slot168, align 8
  %v1353 = load i64, ptr %slot117, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %rgep1355 = getelementptr i8, ptr %p1354, i64 -8
  %ld1356 = load i64, ptr %rgep1355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1356, ptr %slot169, align 8
  %p1357 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld1358 = load i64, ptr %p1357, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1358, ptr %slot170, align 8
  %v1359 = load i64, ptr %slot169, align 8
  %v1360 = load i64, ptr %slot170, align 8
  %cmp1361 = icmp eq i64 %v1359, %v1360
  %cv1362 = zext i1 %cmp1361 to i32
  store i32 %cv1362, ptr %slot171, align 8
  %v1363 = load i32, ptr %slot171, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcs218, label %bb_rcspinslow205
bb_rcs218:
  %v1366 = load i64, ptr %slot31, align 8
  %p1368 = inttoptr i64 %v1366 to ptr
  %gep1369 = getelementptr i8, ptr %p1368, i64 5640
  %op1367 = ptrtoint ptr %gep1369 to i64
  store i64 %op1367, ptr %slot172, align 8
  %v1370 = load i64, ptr %slot172, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %ld1372 = load i64, ptr %p1371, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1372, ptr %slot173, align 8
  %v1373 = load i64, ptr %slot173, align 8
  %op1374 = add i64 %v1373, 256
  store i64 %op1374, ptr %slot174, align 8
  %v1375 = load i64, ptr %slot174, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1377, ptr %slot175, align 8
  %v1378 = load i64, ptr %slot175, align 8
  %cmp1379 = icmp ne i64 %v1378, 0
  %cv1380 = zext i1 %cmp1379 to i32
  store i32 %cv1380, ptr %slot176, align 8
  %v1381 = load i32, ptr %slot176, align 8
  %cv1382 = zext i32 %v1381 to i64
  %cond1383 = icmp ne i64 %cv1382, 0
  br i1 %cond1383, label %bb_rcs224, label %bb_rcspinslow205
bb_rcs224:
  %v1384 = load i64, ptr %slot31, align 8
  %p1386 = inttoptr i64 %v1384 to ptr
  %gep1387 = getelementptr i8, ptr %p1386, i64 24
  %op1385 = ptrtoint ptr %gep1387 to i64
  store i64 %op1385, ptr %slot177, align 8
  %v1388 = load i64, ptr %slot177, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i64, ptr %p1389, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1390, ptr %slot178, align 8
  %v1391 = load i64, ptr %slot178, align 8
  %op1392 = add i64 %v1391, 40
  store i64 %op1392, ptr %slot179, align 8
  %v1393 = load i64, ptr %slot179, align 8
  %v1394 = load i64, ptr %slot178, align 8
  %cmp1395 = icmp uge i64 %v1393, %v1394
  %cv1396 = zext i1 %cmp1395 to i32
  store i32 %cv1396, ptr %slot180, align 8
  %v1397 = load i32, ptr %slot180, align 8
  %cv1398 = zext i32 %v1397 to i64
  %cond1399 = icmp ne i64 %cv1398, 0
  br i1 %cond1399, label %bb_rcs229, label %bb_rcspinslow205
bb_rcs229:
  %v1400 = load i64, ptr %slot31, align 8
  %p1402 = inttoptr i64 %v1400 to ptr
  %gep1403 = getelementptr i8, ptr %p1402, i64 88
  %op1401 = ptrtoint ptr %gep1403 to i64
  store i64 %op1401, ptr %slot181, align 8
  %v1404 = load i64, ptr %slot181, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i64, ptr %p1405, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1406, ptr %slot182, align 8
  %v1407 = load i64, ptr %slot182, align 8
  %cmp1408 = icmp eq i64 %v1407, 0
  %cv1409 = zext i1 %cmp1408 to i32
  store i32 %cv1409, ptr %slot183, align 8
  %v1410 = load i64, ptr %slot179, align 8
  %v1411 = load i64, ptr %slot182, align 8
  %cmp1412 = icmp ule i64 %v1410, %v1411
  %cv1413 = zext i1 %cmp1412 to i32
  store i32 %cv1413, ptr %slot184, align 8
  %v1414 = load i32, ptr %slot183, align 8
  %v1415 = load i32, ptr %slot184, align 8
  %op1416 = or i32 %v1414, %v1415
  store i32 %op1416, ptr %slot185, align 8
  %v1417 = load i32, ptr %slot185, align 8
  %cv1418 = zext i32 %v1417 to i64
  %cond1419 = icmp ne i64 %cv1418, 0
  br i1 %cond1419, label %bb_rcs235, label %bb_rcspinslow205
bb_rcs235:
  %v1420 = load i64, ptr %slot117, align 8
  %op1421 = sub i64 %v1420, 24
  store i64 %op1421, ptr %slot186, align 8
  %v1422 = load i64, ptr %slot117, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  %rgep1424 = getelementptr i8, ptr %p1423, i64 -24
  %ld1425 = load i64, ptr %rgep1424, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1425, ptr %slot187, align 8
  %v1426 = load i64, ptr %slot187, align 8
  %cmp1427 = icmp ne i64 %v1426, 18446744073709551615
  %cv1428 = zext i1 %cmp1427 to i32
  store i32 %cv1428, ptr %slot188, align 8
  %v1429 = load i32, ptr %slot188, align 8
  %cv1430 = zext i32 %v1429 to i64
  %cond1431 = icmp ne i64 %cv1430, 0
  br i1 %cond1431, label %bb_rcs239, label %bb_rcspinslow205
bb_rcs239:
  %v1432 = load i64, ptr %slot117, align 8
  %op1433 = add i64 %v1432, 32
  store i64 %op1433, ptr %slot189, align 8
  %v1434 = load i64, ptr %slot189, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i64, ptr %p1435, align 8
  store i64 %ld1436, ptr %slot190, align 8
  %v1437 = load i64, ptr %slot190, align 8
  %cmp1438 = icmp ne i64 %v1437, 0
  %cv1439 = zext i1 %cmp1438 to i32
  store i32 %cv1439, ptr %slot191, align 8
  %v1440 = load i32, ptr %slot191, align 8
  %cv1441 = zext i32 %v1440 to i64
  %cond1442 = icmp ne i64 %cv1441, 0
  br i1 %cond1442, label %bb_rcspinbacking205, label %bb_rcspincommit205
bb_rcspinbacking205:
  %v1443 = load i64, ptr %slot190, align 8
  %op1444 = sub i64 %v1443, 16
  store i64 %op1444, ptr %slot192, align 8
  %v1445 = load i64, ptr %slot190, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  %rgep1447 = getelementptr i8, ptr %p1446, i64 -16
  %ld1448 = load i64, ptr %rgep1447, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1448, ptr %slot193, align 8
  %v1449 = load i64, ptr %slot193, align 8
  %op1450 = and i64 %v1449, 4611686018427387907
  store i64 %op1450, ptr %slot194, align 8
  %v1451 = load i64, ptr %slot194, align 8
  %cmp1452 = icmp eq i64 %v1451, 0
  %cv1453 = zext i1 %cmp1452 to i32
  store i32 %cv1453, ptr %slot195, align 8
  %v1454 = load i32, ptr %slot195, align 8
  %cv1455 = zext i32 %v1454 to i64
  %cond1456 = icmp ne i64 %cv1455, 0
  br i1 %cond1456, label %bb_rcs247, label %bb_rcspinslow205
bb_rcs247:
  %v1457 = load i64, ptr %slot190, align 8
  %op1458 = sub i64 %v1457, 24
  store i64 %op1458, ptr %slot196, align 8
  %v1459 = load i64, ptr %slot190, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %rgep1461 = getelementptr i8, ptr %p1460, i64 -24
  %ld1462 = load i64, ptr %rgep1461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1462, ptr %slot197, align 8
  %v1463 = load i64, ptr %slot197, align 8
  %cmp1464 = icmp ne i64 %v1463, 18446744073709551615
  %cv1465 = zext i1 %cmp1464 to i32
  store i32 %cv1465, ptr %slot198, align 8
  %v1466 = load i32, ptr %slot198, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcs251, label %bb_rcspinslow205
bb_rcs251:
  br label %bb_rcspincommit205
bb_rcspincommit205:
  %v1469 = load i64, ptr %slot175, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8
  store i64 %ld1471, ptr %slot199, align 8
  %v1472 = load i64, ptr %slot173, align 8
  %op1473 = add i64 %v1472, 256
  store i64 %op1473, ptr %slot200, align 8
  %v1474 = load i64, ptr %slot199, align 8
  %v1475 = load i64, ptr %slot200, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  store i64 %v1474, ptr %p1476, align 8, !alias.scope !9999998, !noalias !9999999
  %v1477 = load i64, ptr %slot173, align 8
  %op1478 = add i64 %v1477, 264
  store i64 %op1478, ptr %slot201, align 8
  %v1479 = load i64, ptr %slot201, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  %ld1481 = load i64, ptr %p1480, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1481, ptr %slot202, align 8
  %v1482 = load i64, ptr %slot202, align 8
  %op1483 = add i64 %v1482, 18446744073709551615
  store i64 %op1483, ptr %slot203, align 8
  %v1484 = load i64, ptr %slot203, align 8
  %v1485 = load i64, ptr %slot201, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i64 %v1484, ptr %p1486, align 8, !alias.scope !9999998, !noalias !9999999
  %v1487 = load i64, ptr %slot31, align 8
  %p1489 = inttoptr i64 %v1487 to ptr
  %gep1490 = getelementptr i8, ptr %p1489, i64 24
  %op1488 = ptrtoint ptr %gep1490 to i64
  store i64 %op1488, ptr %slot204, align 8
  %v1491 = load i64, ptr %slot204, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i64, ptr %p1492, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1493, ptr %slot205, align 8
  %v1494 = load i64, ptr %slot205, align 8
  %op1495 = add i64 %v1494, 40
  store i64 %op1495, ptr %slot206, align 8
  %v1496 = load i64, ptr %slot206, align 8
  %v1497 = load i64, ptr %slot204, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i64 %v1496, ptr %p1498, align 8, !alias.scope !9999998, !noalias !9999999
  %v1499 = load i64, ptr %slot173, align 8
  %op1500 = add i64 %v1499, 48
  store i64 %op1500, ptr %slot207, align 8
  %v1501 = load i64, ptr %slot207, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  %ld1503 = load i64, ptr %p1502, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1503, ptr %slot208, align 8
  %v1504 = load i64, ptr %slot208, align 8
  %op1505 = add i64 %v1504, 40
  store i64 %op1505, ptr %slot209, align 8
  %v1506 = load i64, ptr %slot209, align 8
  %v1507 = load i64, ptr %slot207, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  store i64 %v1506, ptr %p1508, align 8, !alias.scope !9999998, !noalias !9999999
  %v1509 = load i64, ptr %slot117, align 8
  %op1510 = sub i64 %v1509, 24
  store i64 %op1510, ptr %slot210, align 8
  %v1511 = load i64, ptr %slot117, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %rgep1513 = getelementptr i8, ptr %p1512, i64 -24
  %ld1514 = load i64, ptr %rgep1513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1514, ptr %slot211, align 8
  %v1515 = load i64, ptr %slot211, align 8
  %op1516 = add i64 %v1515, 1
  store i64 %op1516, ptr %slot212, align 8
  %v1517 = load i64, ptr %slot212, align 8
  %v1518 = load i64, ptr %slot117, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %rgep1520 = getelementptr i8, ptr %p1519, i64 -24
  store i64 %v1517, ptr %rgep1520, align 8, !alias.scope !9, !noalias !10
  %v1521 = load i64, ptr %slot190, align 8
  %cmp1522 = icmp ne i64 %v1521, 0
  %cv1523 = zext i1 %cmp1522 to i32
  store i32 %cv1523, ptr %slot213, align 8
  %v1524 = load i32, ptr %slot213, align 8
  %cv1525 = zext i32 %v1524 to i64
  %cond1526 = icmp ne i64 %cv1525, 0
  br i1 %cond1526, label %bb_rcspinhold205, label %bb_rcspinjournal205
bb_rcspinhold205:
  %v1527 = load i64, ptr %slot190, align 8
  %op1528 = sub i64 %v1527, 24
  store i64 %op1528, ptr %slot214, align 8
  %v1529 = load i64, ptr %slot190, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %rgep1531 = getelementptr i8, ptr %p1530, i64 -24
  %ld1532 = load i64, ptr %rgep1531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1532, ptr %slot215, align 8
  %v1533 = load i64, ptr %slot215, align 8
  %op1534 = add i64 %v1533, 1
  store i64 %op1534, ptr %slot216, align 8
  %v1535 = load i64, ptr %slot216, align 8
  %v1536 = load i64, ptr %slot190, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %rgep1538 = getelementptr i8, ptr %p1537, i64 -24
  store i64 %v1535, ptr %rgep1538, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal205
bb_rcspinjournal205:
  %v1539 = load i64, ptr %slot163, align 8
  %op1540 = and i64 %v1539, 1152921504606846976
  store i64 %op1540, ptr %slot217, align 8
  %v1541 = load i64, ptr %slot163, align 8
  %op1542 = or i64 %v1541, 1152921504606846976
  store i64 %op1542, ptr %slot218, align 8
  %v1543 = load i64, ptr %slot117, align 8
  %op1544 = sub i64 %v1543, 16
  store i64 %op1544, ptr %slot219, align 8
  %v1545 = load i64, ptr %slot218, align 8
  %v1546 = load i64, ptr %slot117, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %rgep1548 = getelementptr i8, ptr %p1547, i64 -16
  store i64 %v1545, ptr %rgep1548, align 8, !alias.scope !9, !noalias !10
  %v1549 = load i64, ptr %slot150, align 8
  %p1551 = inttoptr i64 %v1549 to ptr
  %gep1552 = getelementptr i8, ptr %p1551, i64 16
  %op1550 = ptrtoint ptr %gep1552 to i64
  store i64 %op1550, ptr %slot220, align 8
  %v1553 = load i64, ptr %slot220, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  %ld1555 = load i64, ptr %p1554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1555, ptr %slot221, align 8
  %v1556 = load i64, ptr %slot175, align 8
  %op1557 = add i64 %v1556, 0
  store i64 %op1557, ptr %slot222, align 8
  %v1558 = load i64, ptr %slot221, align 8
  %v1559 = load i64, ptr %slot222, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i64 %v1558, ptr %p1560, align 8, !alias.scope !9999998, !noalias !9999999
  %v1561 = load i64, ptr %slot175, align 8
  %op1562 = add i64 %v1561, 8
  store i64 %op1562, ptr %slot223, align 8
  %v1563 = load i64, ptr %slot117, align 8
  %v1564 = load i64, ptr %slot223, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 %v1563, ptr %p1565, align 8, !alias.scope !9999998, !noalias !9999999
  %v1566 = load i64, ptr %slot175, align 8
  %op1567 = add i64 %v1566, 16
  store i64 %op1567, ptr %slot224, align 8
  %v1568 = load i64, ptr %slot217, align 8
  %v1569 = load i64, ptr %slot224, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i64 %v1568, ptr %p1570, align 8, !alias.scope !9999998, !noalias !9999999
  %v1571 = load i64, ptr %slot175, align 8
  %op1572 = add i64 %v1571, 24
  store i64 %op1572, ptr %slot225, align 8
  %v1573 = load i64, ptr %slot225, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i32 1, ptr %p1574, align 4, !alias.scope !9999998, !noalias !9999999
  %v1575 = load i64, ptr %slot175, align 8
  %op1576 = add i64 %v1575, 32
  store i64 %op1576, ptr %slot226, align 8
  %v1577 = load i64, ptr %slot190, align 8
  %v1578 = load i64, ptr %slot226, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i64 %v1577, ptr %p1579, align 8, !alias.scope !9999998, !noalias !9999999
  %v1580 = load i64, ptr %slot150, align 8
  %p1582 = inttoptr i64 %v1580 to ptr
  %gep1583 = getelementptr i8, ptr %p1582, i64 16
  %op1581 = ptrtoint ptr %gep1583 to i64
  store i64 %op1581, ptr %slot227, align 8
  %v1584 = load i64, ptr %slot175, align 8
  %v1585 = load i64, ptr %slot227, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i64 %v1584, ptr %p1586, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone205
bb_rcspinslow205:
  %v1587 = load i64, ptr %slot1, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %v1589 = load i64, ptr %slot150, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %v1591 = load i64, ptr %slot117, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %call1593 = call i32 @myl_qbe_rc_scope_pin(ptr %p1588, ptr %p1590, ptr %p1592) nomerge, !dbg !118
  store i32 %call1593, ptr %slot228, align 8
  %v1594 = load i32, ptr %slot228, align 8
  %cv1595 = zext i32 %v1594 to i64
  %cond1596 = icmp ne i64 %cv1595, 0
  br i1 %cond1596, label %bb_rcunique282, label %bb_failure
bb_rcunique282:
  br label %bb_rcspindone205
bb_rcspindone205:
  %v1597 = load i64, ptr %slot117, align 8
  %v1598 = load i64, ptr %slot20, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i64 %v1597, ptr %p1599, align 8, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot20, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %ld1602 = load i64, ptr %p1601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1602, ptr %slot229, align 8
  %v1603 = load i64, ptr %slot29, align 8
  store i64 %v1603, ptr %slot230, align 8
  %v1604 = load i64, ptr %slot229, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  %ld1606 = load i64, ptr %p1605, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1606, ptr %slot231, align 8
  %v1607 = load i64, ptr %slot31, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  %v1609 = load i64, ptr %slot229, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  %v1611 = load i64, ptr %slot29, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %call1613 = call i32 @myl_rc_list_pop(ptr %p1608, ptr %p1610, ptr %p1612) nomerge, !dbg !120
  store i32 %call1613, ptr %slot232, align 8
  %v1614 = load i32, ptr %slot232, align 8
  %cmp1615 = icmp sge i32 %v1614, 0
  %cv1616 = zext i1 %cmp1615 to i32
  store i32 %cv1616, ptr %slot233, align 8
  %v1617 = load i32, ptr %slot233, align 8
  %cv1618 = zext i32 %v1617 to i64
  %cond1619 = icmp ne i64 %cv1618, 0
  br i1 %cond1619, label %bb_success288, label %bb_failed288
bb_failed288:
  %v1620 = load i64, ptr %slot1, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1621) nomerge, !dbg !120
  unreachable
bb_success288:
  %v1622 = load i32, ptr %slot232, align 8
  %cv1623 = zext i32 %v1622 to i64
  %cond1624 = icmp ne i64 %cv1623, 0
  br i1 %cond1624, label %bb_success289, label %bb_failed289
bb_failed289:
  %v1625 = load i64, ptr %slot1, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %v1627 = load i64, ptr %slot231, align 8
  call void @myl_qbe_fail_pop_bounds(ptr %p1626, i64 %v1627) nomerge, !dbg !120
  unreachable
bb_success289:
  %v1628 = load i64, ptr %slot230, align 8
  %v1629 = load i64, ptr %slot23, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  store i64 %v1628, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  %v1631 = load i64, ptr %slot23, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  %ld1633 = load i64, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1633, ptr %slot234, align 8
  %v1634 = load i64, ptr %slot13, align 8
  store i64 %v1634, ptr %slot235, align 8
  %v1635 = load i64, ptr %slot234, align 8
  %v1636 = load i64, ptr %slot235, align 8
  %p1637 = inttoptr i64 %v1635 to ptr
  %p1638 = inttoptr i64 %v1636 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1638, ptr %p1637, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1639 = load i64, ptr %slot10, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  store i32 2, ptr %p1640, align 4, !alias.scope !3, !noalias !4
  %v1641 = load i64, ptr %slot9, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  store i32 1, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  %v1643 = load i64, ptr %slot11, align 8
  store i64 %v1643, ptr %slot236, align 8
  %v1644 = load i64, ptr %slot13, align 8
  store i64 %v1644, ptr %slot237, align 8
  %v1645 = load i64, ptr %slot237, align 8
  %v1646 = load i64, ptr %slot236, align 8
  %p1647 = inttoptr i64 %v1645 to ptr
  %p1648 = inttoptr i64 %v1646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1648, ptr %p1647, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot8, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  store i32 2, ptr %p1650, align 4, !alias.scope !3, !noalias !4
  %v1651 = load i64, ptr %slot10, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %ld1653 = load i32, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1653, ptr %slot238, align 8
  %v1654 = load i32, ptr %slot238, align 8
  %v1655 = load i64, ptr %slot8, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  store i32 %v1654, ptr %p1656, align 4, !alias.scope !3, !noalias !4
  %v1657 = load i64, ptr %slot9, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i32 0, ptr %p1658, align 4, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot7, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i32 1, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot236, align 8
  %v1662 = load i64, ptr %slot23, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i64 %v1661, ptr %p1663, align 8, !alias.scope !3, !noalias !4
  %v1664 = load i64, ptr %slot14, align 8
  store i64 %v1664, ptr %slot239, align 8
  %v1665 = load i64, ptr %slot239, align 8
  %p1667 = inttoptr i64 %v1665 to ptr
  %gep1668 = getelementptr i8, ptr %p1667, i64 24
  %op1666 = ptrtoint ptr %gep1668 to i64
  store i64 %op1666, ptr %slot240, align 8
  %v1669 = load i64, ptr %slot240, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  %ld1671 = load i32, ptr %p1670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1671, ptr %slot241, align 8
  %v1672 = load i32, ptr %slot241, align 8
  %cv1673 = zext i32 %v1672 to i64
  %cond1674 = icmp ne i64 %cv1673, 0
  br i1 %cond1674, label %bb_rcsendactive303, label %bb_rcsenddone303
bb_rcsendactive303:
  %v1675 = load i64, ptr %slot31, align 8
  %p1677 = inttoptr i64 %v1675 to ptr
  %gep1678 = getelementptr i8, ptr %p1677, i64 5640
  %op1676 = ptrtoint ptr %gep1678 to i64
  store i64 %op1676, ptr %slot242, align 8
  %v1679 = load i64, ptr %slot242, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i64, ptr %p1680, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1681, ptr %slot243, align 8
  %v1682 = load i64, ptr %slot243, align 8
  %op1683 = add i64 %v1682, 248
  store i64 %op1683, ptr %slot244, align 8
  %v1684 = load i64, ptr %slot244, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %ld1686 = load i64, ptr %p1685, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1686, ptr %slot245, align 8
  %v1687 = load i64, ptr %slot245, align 8
  %v1688 = load i64, ptr %slot239, align 8
  %cmp1689 = icmp eq i64 %v1687, %v1688
  %cv1690 = zext i1 %cmp1689 to i32
  store i32 %cv1690, ptr %slot246, align 8
  %v1691 = load i32, ptr %slot246, align 8
  %cv1692 = zext i32 %v1691 to i64
  %cond1693 = icmp ne i64 %cv1692, 0
  br i1 %cond1693, label %bb_rcs311, label %bb_rcsendslow303
bb_rcs311:
  %v1694 = load i64, ptr %slot243, align 8
  %op1695 = add i64 %v1694, 200
  store i64 %op1695, ptr %slot247, align 8
  %v1696 = load i64, ptr %slot247, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %ld1698 = load i64, ptr %p1697, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1698, ptr %slot248, align 8
  %v1699 = load i64, ptr %slot248, align 8
  %cmp1700 = icmp eq i64 %v1699, 0
  %cv1701 = zext i1 %cmp1700 to i32
  store i32 %cv1701, ptr %slot249, align 8
  %v1702 = load i32, ptr %slot249, align 8
  %cv1703 = zext i32 %v1702 to i64
  %cond1704 = icmp ne i64 %cv1703, 0
  br i1 %cond1704, label %bb_rcs315, label %bb_rcsendslow303
bb_rcs315:
  %v1705 = load i64, ptr %slot239, align 8
  %p1707 = inttoptr i64 %v1705 to ptr
  %gep1708 = getelementptr i8, ptr %p1707, i64 16
  %op1706 = ptrtoint ptr %gep1708 to i64
  store i64 %op1706, ptr %slot250, align 8
  %v1709 = load i64, ptr %slot250, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i64, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1711, ptr %slot251, align 8
  %v1712 = load i64, ptr %slot251, align 8
  %cmp1713 = icmp ne i64 %v1712, 0
  %cv1714 = zext i1 %cmp1713 to i32
  store i32 %cv1714, ptr %slot252, align 8
  %v1715 = load i32, ptr %slot252, align 8
  %cv1716 = zext i32 %v1715 to i64
  %cond1717 = icmp ne i64 %cv1716, 0
  br i1 %cond1717, label %bb_rcsendnode303, label %bb_rcsendunlink303
bb_rcsendnode303:
  %v1718 = load i64, ptr %slot251, align 8
  %op1719 = add i64 %v1718, 0
  store i64 %op1719, ptr %slot253, align 8
  %v1720 = load i64, ptr %slot253, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  %ld1722 = load i64, ptr %p1721, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1722, ptr %slot254, align 8
  %v1723 = load i64, ptr %slot254, align 8
  %cmp1724 = icmp eq i64 %v1723, 0
  %cv1725 = zext i1 %cmp1724 to i32
  store i32 %cv1725, ptr %slot255, align 8
  %v1726 = load i32, ptr %slot255, align 8
  %cv1727 = zext i32 %v1726 to i64
  %cond1728 = icmp ne i64 %cv1727, 0
  br i1 %cond1728, label %bb_rcs322, label %bb_rcsendslow303
bb_rcs322:
  %v1729 = load i64, ptr %slot243, align 8
  %op1730 = add i64 %v1729, 264
  store i64 %op1730, ptr %slot256, align 8
  %v1731 = load i64, ptr %slot256, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i64, ptr %p1732, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1733, ptr %slot257, align 8
  %v1734 = load i64, ptr %slot257, align 8
  %cmp1735 = icmp ult i64 %v1734, 32
  %cv1736 = zext i1 %cmp1735 to i32
  store i32 %cv1736, ptr %slot258, align 8
  %v1737 = load i32, ptr %slot258, align 8
  %cv1738 = zext i32 %v1737 to i64
  %cond1739 = icmp ne i64 %cv1738, 0
  br i1 %cond1739, label %bb_rcs326, label %bb_rcsendslow303
bb_rcs326:
  %v1740 = load i64, ptr %slot251, align 8
  %op1741 = add i64 %v1740, 8
  store i64 %op1741, ptr %slot259, align 8
  %v1742 = load i64, ptr %slot259, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i64, ptr %p1743, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1744, ptr %slot260, align 8
  %v1745 = load i64, ptr %slot260, align 8
  %cmp1746 = icmp ne i64 %v1745, 0
  %cv1747 = zext i1 %cmp1746 to i32
  store i32 %cv1747, ptr %slot261, align 8
  %v1748 = load i32, ptr %slot261, align 8
  %cv1749 = zext i32 %v1748 to i64
  %cond1750 = icmp ne i64 %cv1749, 0
  br i1 %cond1750, label %bb_rcs330, label %bb_rcsendslow303
bb_rcs330:
  %v1751 = load i64, ptr %slot260, align 8
  %op1752 = sub i64 %v1751, 16
  store i64 %op1752, ptr %slot262, align 8
  %v1753 = load i64, ptr %slot260, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  %rgep1755 = getelementptr i8, ptr %p1754, i64 -16
  %ld1756 = load i64, ptr %rgep1755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1756, ptr %slot263, align 8
  %v1757 = load i64, ptr %slot263, align 8
  %op1758 = and i64 %v1757, 4611686018427387907
  store i64 %op1758, ptr %slot264, align 8
  %v1759 = load i64, ptr %slot264, align 8
  %cmp1760 = icmp eq i64 %v1759, 0
  %cv1761 = zext i1 %cmp1760 to i32
  store i32 %cv1761, ptr %slot265, align 8
  %v1762 = load i32, ptr %slot265, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcs335, label %bb_rcsendslow303
bb_rcs335:
  %v1765 = load i64, ptr %slot260, align 8
  %op1766 = sub i64 %v1765, 24
  store i64 %op1766, ptr %slot266, align 8
  %v1767 = load i64, ptr %slot260, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %rgep1769 = getelementptr i8, ptr %p1768, i64 -24
  %ld1770 = load i64, ptr %rgep1769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1770, ptr %slot267, align 8
  %v1771 = load i64, ptr %slot267, align 8
  %cmp1772 = icmp ne i64 %v1771, 0
  %cv1773 = zext i1 %cmp1772 to i32
  store i32 %cv1773, ptr %slot268, align 8
  %v1774 = load i32, ptr %slot268, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcs339, label %bb_rcsendslow303
bb_rcs339:
  %v1777 = load i64, ptr %slot260, align 8
  %op1778 = sub i64 %v1777, 32
  store i64 %op1778, ptr %slot269, align 8
  %v1779 = load i64, ptr %slot260, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %rgep1781 = getelementptr i8, ptr %p1780, i64 -32
  %ld1782 = load i64, ptr %rgep1781, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1782, ptr %slot270, align 8
  %v1783 = load i64, ptr %slot267, align 8
  %cmp1784 = icmp ugt i64 %v1783, 1
  %cv1785 = zext i1 %cmp1784 to i32
  store i32 %cv1785, ptr %slot271, align 8
  %v1786 = load i64, ptr %slot270, align 8
  %cmp1787 = icmp ne i64 %v1786, 0
  %cv1788 = zext i1 %cmp1787 to i32
  store i32 %cv1788, ptr %slot272, align 8
  %v1789 = load i32, ptr %slot271, align 8
  %v1790 = load i32, ptr %slot272, align 8
  %op1791 = or i32 %v1789, %v1790
  store i32 %op1791, ptr %slot273, align 8
  %v1792 = load i32, ptr %slot273, align 8
  %cv1793 = zext i32 %v1792 to i64
  %cond1794 = icmp ne i64 %cv1793, 0
  br i1 %cond1794, label %bb_rcs345, label %bb_rcsendslow303
bb_rcs345:
  %v1795 = load i64, ptr %slot251, align 8
  %op1796 = add i64 %v1795, 32
  store i64 %op1796, ptr %slot274, align 8
  %v1797 = load i64, ptr %slot274, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %ld1799 = load i64, ptr %p1798, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1799, ptr %slot275, align 8
  %v1800 = load i64, ptr %slot275, align 8
  %cmp1801 = icmp ne i64 %v1800, 0
  %cv1802 = zext i1 %cmp1801 to i32
  store i32 %cv1802, ptr %slot276, align 8
  %v1803 = load i32, ptr %slot276, align 8
  %cv1804 = zext i32 %v1803 to i64
  %cond1805 = icmp ne i64 %cv1804, 0
  br i1 %cond1805, label %bb_rcsendbacking303, label %bb_rcsendcommit303
bb_rcsendbacking303:
  %v1806 = load i64, ptr %slot275, align 8
  %op1807 = sub i64 %v1806, 16
  store i64 %op1807, ptr %slot277, align 8
  %v1808 = load i64, ptr %slot275, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %rgep1810 = getelementptr i8, ptr %p1809, i64 -16
  %ld1811 = load i64, ptr %rgep1810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1811, ptr %slot278, align 8
  %v1812 = load i64, ptr %slot278, align 8
  %op1813 = and i64 %v1812, 4611686018427387907
  store i64 %op1813, ptr %slot279, align 8
  %v1814 = load i64, ptr %slot279, align 8
  %cmp1815 = icmp eq i64 %v1814, 0
  %cv1816 = zext i1 %cmp1815 to i32
  store i32 %cv1816, ptr %slot280, align 8
  %v1817 = load i32, ptr %slot280, align 8
  %cv1818 = zext i32 %v1817 to i64
  %cond1819 = icmp ne i64 %cv1818, 0
  br i1 %cond1819, label %bb_rcs353, label %bb_rcsendslow303
bb_rcs353:
  %v1820 = load i64, ptr %slot275, align 8
  %op1821 = sub i64 %v1820, 24
  store i64 %op1821, ptr %slot281, align 8
  %v1822 = load i64, ptr %slot275, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %rgep1824 = getelementptr i8, ptr %p1823, i64 -24
  %ld1825 = load i64, ptr %rgep1824, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1825, ptr %slot282, align 8
  %v1826 = load i64, ptr %slot282, align 8
  %cmp1827 = icmp ne i64 %v1826, 0
  %cv1828 = zext i1 %cmp1827 to i32
  store i32 %cv1828, ptr %slot283, align 8
  %v1829 = load i32, ptr %slot283, align 8
  %cv1830 = zext i32 %v1829 to i64
  %cond1831 = icmp ne i64 %cv1830, 0
  br i1 %cond1831, label %bb_rcs357, label %bb_rcsendslow303
bb_rcs357:
  %v1832 = load i64, ptr %slot275, align 8
  %op1833 = sub i64 %v1832, 32
  store i64 %op1833, ptr %slot284, align 8
  %v1834 = load i64, ptr %slot275, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %rgep1836 = getelementptr i8, ptr %p1835, i64 -32
  %ld1837 = load i64, ptr %rgep1836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1837, ptr %slot285, align 8
  %v1838 = load i64, ptr %slot282, align 8
  %cmp1839 = icmp ugt i64 %v1838, 1
  %cv1840 = zext i1 %cmp1839 to i32
  store i32 %cv1840, ptr %slot286, align 8
  %v1841 = load i64, ptr %slot285, align 8
  %cmp1842 = icmp ne i64 %v1841, 0
  %cv1843 = zext i1 %cmp1842 to i32
  store i32 %cv1843, ptr %slot287, align 8
  %v1844 = load i32, ptr %slot286, align 8
  %v1845 = load i32, ptr %slot287, align 8
  %op1846 = or i32 %v1844, %v1845
  store i32 %op1846, ptr %slot288, align 8
  %v1847 = load i32, ptr %slot288, align 8
  %cv1848 = zext i32 %v1847 to i64
  %cond1849 = icmp ne i64 %cv1848, 0
  br i1 %cond1849, label %bb_rcs363, label %bb_rcsendslow303
bb_rcs363:
  br label %bb_rcsendcommit303
bb_rcsendcommit303:
  %v1850 = load i64, ptr %slot251, align 8
  %op1851 = add i64 %v1850, 24
  store i64 %op1851, ptr %slot289, align 8
  %v1852 = load i64, ptr %slot289, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i32, ptr %p1853, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld1854, ptr %slot290, align 8
  %v1855 = load i32, ptr %slot290, align 8
  %cv1856 = zext i32 %v1855 to i64
  %cond1857 = icmp ne i64 %cv1856, 0
  br i1 %cond1857, label %bb_rcsendrestore303, label %bb_rcsendreturned303
bb_rcsendrestore303:
  %v1858 = load i64, ptr %slot251, align 8
  %op1859 = add i64 %v1858, 16
  store i64 %op1859, ptr %slot291, align 8
  %v1860 = load i64, ptr %slot291, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %ld1862 = load i64, ptr %p1861, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1862, ptr %slot292, align 8
  %v1863 = load i64, ptr %slot263, align 8
  %op1864 = and i64 %v1863, 17293822569102704639
  store i64 %op1864, ptr %slot293, align 8
  %v1865 = load i64, ptr %slot293, align 8
  %v1866 = load i64, ptr %slot292, align 8
  %op1867 = or i64 %v1865, %v1866
  store i64 %op1867, ptr %slot294, align 8
  %v1868 = load i64, ptr %slot260, align 8
  %op1869 = sub i64 %v1868, 16
  store i64 %op1869, ptr %slot295, align 8
  %v1870 = load i64, ptr %slot294, align 8
  %v1871 = load i64, ptr %slot260, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  %rgep1873 = getelementptr i8, ptr %p1872, i64 -16
  store i64 %v1870, ptr %rgep1873, align 8, !alias.scope !9, !noalias !10
  %v1874 = load i64, ptr %slot239, align 8
  %p1876 = inttoptr i64 %v1874 to ptr
  %gep1877 = getelementptr i8, ptr %p1876, i64 16
  %op1875 = ptrtoint ptr %gep1877 to i64
  store i64 %op1875, ptr %slot296, align 8
  br label %bb_rcsendreturned303
bb_rcsendreturned303:
  %v1878 = load i64, ptr %slot296, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i64 0, ptr %p1879, align 8, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot243, align 8
  %op1881 = add i64 %v1880, 256
  store i64 %op1881, ptr %slot297, align 8
  %v1882 = load i64, ptr %slot297, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %ld1884 = load i64, ptr %p1883, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1884, ptr %slot298, align 8
  %v1885 = load i64, ptr %slot251, align 8
  %op1886 = add i64 %v1885, 0
  store i64 %op1886, ptr %slot299, align 8
  %v1887 = load i64, ptr %slot298, align 8
  %v1888 = load i64, ptr %slot299, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i64 %v1887, ptr %p1889, align 8, !alias.scope !9999998, !noalias !9999999
  %v1890 = load i64, ptr %slot243, align 8
  %op1891 = add i64 %v1890, 256
  store i64 %op1891, ptr %slot300, align 8
  %v1892 = load i64, ptr %slot251, align 8
  %v1893 = load i64, ptr %slot300, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  store i64 %v1892, ptr %p1894, align 8, !alias.scope !9999998, !noalias !9999999
  %v1895 = load i64, ptr %slot243, align 8
  %op1896 = add i64 %v1895, 264
  store i64 %op1896, ptr %slot301, align 8
  %v1897 = load i64, ptr %slot301, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  %ld1899 = load i64, ptr %p1898, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1899, ptr %slot302, align 8
  %v1900 = load i64, ptr %slot302, align 8
  %op1901 = add i64 %v1900, 1
  store i64 %op1901, ptr %slot303, align 8
  %v1902 = load i64, ptr %slot303, align 8
  %v1903 = load i64, ptr %slot301, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i64 %v1902, ptr %p1904, align 8, !alias.scope !9999998, !noalias !9999999
  %v1905 = load i64, ptr %slot31, align 8
  %p1907 = inttoptr i64 %v1905 to ptr
  %gep1908 = getelementptr i8, ptr %p1907, i64 24
  %op1906 = ptrtoint ptr %gep1908 to i64
  store i64 %op1906, ptr %slot304, align 8
  %v1909 = load i64, ptr %slot304, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  %ld1911 = load i64, ptr %p1910, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1911, ptr %slot305, align 8
  %v1912 = load i64, ptr %slot305, align 8
  %op1913 = add i64 %v1912, 18446744073709551576
  store i64 %op1913, ptr %slot306, align 8
  %v1914 = load i64, ptr %slot306, align 8
  %v1915 = load i64, ptr %slot304, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  store i64 %v1914, ptr %p1916, align 8, !alias.scope !9999998, !noalias !9999999
  %v1917 = load i64, ptr %slot243, align 8
  %op1918 = add i64 %v1917, 48
  store i64 %op1918, ptr %slot307, align 8
  %v1919 = load i64, ptr %slot307, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1921, ptr %slot308, align 8
  %v1922 = load i64, ptr %slot308, align 8
  %op1923 = add i64 %v1922, 18446744073709551576
  store i64 %op1923, ptr %slot309, align 8
  %v1924 = load i64, ptr %slot309, align 8
  %v1925 = load i64, ptr %slot307, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i64 %v1924, ptr %p1926, align 8, !alias.scope !9999998, !noalias !9999999
  %v1927 = load i64, ptr %slot275, align 8
  %cmp1928 = icmp ne i64 %v1927, 0
  %cv1929 = zext i1 %cmp1928 to i32
  store i32 %cv1929, ptr %slot310, align 8
  %v1930 = load i32, ptr %slot310, align 8
  %cv1931 = zext i32 %v1930 to i64
  %cond1932 = icmp ne i64 %cv1931, 0
  br i1 %cond1932, label %bb_rcsenddropbacking303, label %bb_rcsenddroppayload303
bb_rcsenddropbacking303:
  %v1933 = load i64, ptr %slot275, align 8
  %op1934 = sub i64 %v1933, 24
  store i64 %op1934, ptr %slot311, align 8
  %v1935 = load i64, ptr %slot275, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %rgep1937 = getelementptr i8, ptr %p1936, i64 -24
  %ld1938 = load i64, ptr %rgep1937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1938, ptr %slot312, align 8
  %v1939 = load i64, ptr %slot312, align 8
  %op1940 = add i64 %v1939, 18446744073709551615
  store i64 %op1940, ptr %slot313, align 8
  %v1941 = load i64, ptr %slot313, align 8
  %v1942 = load i64, ptr %slot275, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %rgep1944 = getelementptr i8, ptr %p1943, i64 -24
  store i64 %v1941, ptr %rgep1944, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload303
bb_rcsenddroppayload303:
  %v1945 = load i64, ptr %slot260, align 8
  %op1946 = sub i64 %v1945, 24
  store i64 %op1946, ptr %slot314, align 8
  %v1947 = load i64, ptr %slot260, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %rgep1949 = getelementptr i8, ptr %p1948, i64 -24
  %ld1950 = load i64, ptr %rgep1949, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1950, ptr %slot315, align 8
  %v1951 = load i64, ptr %slot315, align 8
  %op1952 = add i64 %v1951, 18446744073709551615
  store i64 %op1952, ptr %slot316, align 8
  %v1953 = load i64, ptr %slot316, align 8
  %v1954 = load i64, ptr %slot260, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  %rgep1956 = getelementptr i8, ptr %p1955, i64 -24
  store i64 %v1953, ptr %rgep1956, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink303
bb_rcsendunlink303:
  %v1957 = load i64, ptr %slot239, align 8
  %p1959 = inttoptr i64 %v1957 to ptr
  %gep1960 = getelementptr i8, ptr %p1959, i64 8
  %op1958 = ptrtoint ptr %gep1960 to i64
  store i64 %op1958, ptr %slot317, align 8
  %v1961 = load i64, ptr %slot317, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  %ld1963 = load i64, ptr %p1962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1963, ptr %slot318, align 8
  %v1964 = load i64, ptr %slot243, align 8
  %op1965 = add i64 %v1964, 248
  store i64 %op1965, ptr %slot319, align 8
  %v1966 = load i64, ptr %slot318, align 8
  %v1967 = load i64, ptr %slot319, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  store i64 %v1966, ptr %p1968, align 8, !alias.scope !9999998, !noalias !9999999
  %v1969 = load i64, ptr %slot239, align 8
  %p1971 = inttoptr i64 %v1969 to ptr
  %gep1972 = getelementptr i8, ptr %p1971, i64 24
  %op1970 = ptrtoint ptr %gep1972 to i64
  store i64 %op1970, ptr %slot320, align 8
  %v1973 = load i64, ptr %slot239, align 8
  %p1975 = inttoptr i64 %v1973 to ptr
  %gep1976 = getelementptr i8, ptr %p1975, i64 8
  %op1974 = ptrtoint ptr %gep1976 to i64
  store i64 %op1974, ptr %slot321, align 8
  %v1977 = load i64, ptr %slot320, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  store i32 0, ptr %p1978, align 4, !alias.scope !3, !noalias !4
  %v1979 = load i64, ptr %slot321, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  store i64 0, ptr %p1980, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone303
bb_rcsendslow303:
  %v1981 = load i64, ptr %slot1, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %v1983 = load i64, ptr %slot239, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p1982, ptr %p1984) nomerge, !dbg !120
  br label %bb_rcsenddone303
bb_rcsenddone303:
  %v1985 = load i64, ptr %slot23, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %ld1987 = load i64, ptr %p1986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1987, ptr %slot322, align 8
  %v1988 = load i64, ptr %slot7, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %ld1990 = load i32, ptr %p1989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1990, ptr %slot323, align 8
  %v1991 = load i64, ptr %slot8, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i32, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1993, ptr %slot324, align 8
  %v1994 = load i32, ptr %slot324, align 8
  %op1995 = and i32 %v1994, 24
  store i32 %op1995, ptr %slot324, align 8
  %v1996 = load i32, ptr %slot324, align 8
  %cmp1997 = icmp eq i32 %v1996, 0
  %cv1998 = zext i1 %cmp1997 to i32
  store i32 %cv1998, ptr %slot325, align 8
  %v1999 = load i32, ptr %slot323, align 8
  %v2000 = load i32, ptr %slot325, align 8
  %op2001 = and i32 %v1999, %v2000
  store i32 %op2001, ptr %slot326, align 8
  %v2002 = load i32, ptr %slot326, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rctake398, label %bb_rccopy398
bb_rctake398:
  %v2005 = load i64, ptr %slot13, align 8
  store i64 %v2005, ptr %slot327, align 8
  %v2006 = load i64, ptr %slot32, align 8
  store i64 %v2006, ptr %slot328, align 8
  %v2007 = load i64, ptr %slot31, align 8
  %v2008 = load i64, ptr %slot327, align 8
  %v2009 = load i64, ptr %slot322, align 8
  %v2010 = load i64, ptr %slot328, align 8
  %cv2011 = trunc i64 %v2010 to i32
  %call2012 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2007, i64 %v2008, i64 %v2009, i32 %cv2011) nomerge, !dbg !122
  store i32 %call2012, ptr %slot329, align 8
  %v2013 = load i32, ptr %slot329, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcsuccess408, label %bb_rcfailure408
bb_rcfailure408:
  %v2016 = load i64, ptr %slot31, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %call2018 = call i32 @myl_rc_take_failure(ptr %p2017) nomerge, !dbg !122
  store i32 %call2018, ptr %slot330, align 8
  %v2019 = load i64, ptr %slot1, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %v2021 = load i32, ptr %slot330, align 8
  %call2022 = call i32 @myl_qbe_rc_status(ptr %p2020, i32 %v2021) nomerge, !dbg !122
  store i32 %call2022, ptr %slot331, align 8
  br label %bb_failure
bb_rcsuccess408:
  %v2023 = load i64, ptr %slot7, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 0, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot10, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  store i32 2, ptr %p2026, align 4, !alias.scope !3, !noalias !4
  %v2027 = load i64, ptr %slot9, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  store i32 1, ptr %p2028, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared398
bb_rccopy398:
  %v2029 = load i64, ptr %slot13, align 8
  store i64 %v2029, ptr %slot332, align 8
  %v2030 = load i64, ptr %slot32, align 8
  store i64 %v2030, ptr %slot333, align 8
  %v2031 = load i64, ptr %slot31, align 8
  %v2032 = load i64, ptr %slot332, align 8
  %v2033 = load i64, ptr %slot322, align 8
  %v2034 = load i64, ptr %slot333, align 8
  %cv2035 = trunc i64 %v2034 to i32
  %call2036 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v2031, i64 %v2032, i64 %v2033, i32 %cv2035) nomerge, !dbg !122
  store i32 %call2036, ptr %slot334, align 8
  %v2037 = load i32, ptr %slot334, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcsuccess417, label %bb_rcfailure417
bb_rcfailure417:
  %v2040 = load i64, ptr %slot31, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %call2042 = call i32 @myl_rc_take_failure(ptr %p2041) nomerge, !dbg !122
  store i32 %call2042, ptr %slot335, align 8
  %v2043 = load i64, ptr %slot1, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %v2045 = load i32, ptr %slot335, align 8
  %call2046 = call i32 @myl_qbe_rc_status(ptr %p2044, i32 %v2045) nomerge, !dbg !122
  store i32 %call2046, ptr %slot336, align 8
  br label %bb_failure
bb_rcsuccess417:
  %v2047 = load i64, ptr %slot10, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  store i32 2, ptr %p2048, align 4, !alias.scope !3, !noalias !4
  %v2049 = load i64, ptr %slot9, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i32 1, ptr %p2050, align 4, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot7, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i32, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2053, ptr %slot337, align 8
  %v2054 = load i32, ptr %slot337, align 8
  %cv2055 = zext i32 %v2054 to i64
  %cond2056 = icmp ne i64 %cv2055, 0
  br i1 %cond2056, label %bb_rcslotdrop424, label %bb_rcslotdone424
bb_rcslotdrop424:
  %v2057 = load i64, ptr %slot7, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i32 0, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot11, align 8
  store i64 %v2059, ptr %slot338, align 8
  %v2060 = load i64, ptr %slot8, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %ld2062 = load i32, ptr %p2061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2062, ptr %slot339, align 8
  %v2063 = load i32, ptr %slot339, align 8
  %op2064 = and i32 %v2063, 28
  store i32 %op2064, ptr %slot340, align 8
  %v2065 = load i32, ptr %slot340, align 8
  %cv2066 = zext i32 %v2065 to i64
  %cond2067 = icmp ne i64 %cv2066, 0
  br i1 %cond2067, label %bb_rcslotrole424, label %bb_rcslotowner424
bb_rcslotrole424:
  %v2068 = load i64, ptr %slot31, align 8
  store i64 %v2068, ptr %slot341, align 8
  %v2069 = load i64, ptr %slot341, align 8
  %v2070 = load i64, ptr %slot338, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2069, i64 %v2070) nomerge, !dbg !122
  br label %bb_rcslotdone424
bb_rcslotowner424:
  %v2071 = load i64, ptr %slot31, align 8
  store i64 %v2071, ptr %slot342, align 8
  %v2072 = load i64, ptr %slot342, align 8
  %v2073 = load i64, ptr %slot338, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2072, i64 %v2073) nomerge, !dbg !122
  br label %bb_rcslotdone424
bb_rcslotdone424:
  br label %bb_rcprepared398
bb_rcprepared398:
  %v2074 = load i64, ptr %slot5, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i32, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2076, ptr %slot343, align 8
  %v2077 = load i32, ptr %slot343, align 8
  %cv2078 = zext i32 %v2077 to i64
  %cond2079 = icmp ne i64 %cv2078, 0
  br i1 %cond2079, label %bb_rcslotdrop434, label %bb_rcslotdone434
bb_rcslotdrop434:
  %v2080 = load i64, ptr %slot5, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  store i32 0, ptr %p2081, align 4, !alias.scope !3, !noalias !4
  %v2082 = load i64, ptr %slot21, align 8
  store i64 %v2082, ptr %slot344, align 8
  %v2083 = load i64, ptr %slot6, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i32, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2085, ptr %slot345, align 8
  %v2086 = load i32, ptr %slot345, align 8
  %op2087 = and i32 %v2086, 28
  store i32 %op2087, ptr %slot346, align 8
  %v2088 = load i32, ptr %slot346, align 8
  %cv2089 = zext i32 %v2088 to i64
  %cond2090 = icmp ne i64 %cv2089, 0
  br i1 %cond2090, label %bb_rcslotrole434, label %bb_rcslotowner434
bb_rcslotrole434:
  %v2091 = load i64, ptr %slot31, align 8
  store i64 %v2091, ptr %slot347, align 8
  %v2092 = load i64, ptr %slot347, align 8
  %v2093 = load i64, ptr %slot344, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2092, i64 %v2093) nomerge, !dbg !122
  br label %bb_rcslotdone434
bb_rcslotowner434:
  %v2094 = load i64, ptr %slot31, align 8
  store i64 %v2094, ptr %slot348, align 8
  %v2095 = load i64, ptr %slot348, align 8
  %v2096 = load i64, ptr %slot344, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2095, i64 %v2096) nomerge, !dbg !122
  br label %bb_rcslotdone434
bb_rcslotdone434:
  %v2097 = load i64, ptr %slot21, align 8
  store i64 %v2097, ptr %slot349, align 8
  %v2098 = load i64, ptr %slot13, align 8
  store i64 %v2098, ptr %slot350, align 8
  %v2099 = load i64, ptr %slot350, align 8
  %v2100 = load i64, ptr %slot349, align 8
  %p2101 = inttoptr i64 %v2099 to ptr
  %p2102 = inttoptr i64 %v2100 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2102, ptr %p2101, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot9, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i32 0, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot6, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 2, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot10, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i32, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2109, ptr %slot351, align 8
  %v2110 = load i32, ptr %slot351, align 8
  %v2111 = load i64, ptr %slot6, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i32 %v2110, ptr %p2112, align 4, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot5, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  store i32 1, ptr %p2114, align 4, !alias.scope !3, !noalias !4
  %v2115 = load i64, ptr %slot19, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %ld2117 = load i64, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2117, ptr %slot352, align 8
  %v2118 = load i64, ptr %slot352, align 8
  %v2119 = load i64, ptr %slot23, align 8
  %p2120 = inttoptr i64 %v2119 to ptr
  store i64 %v2118, ptr %p2120, align 8, !alias.scope !3, !noalias !4
  %v2121 = load i64, ptr %slot23, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  %ld2123 = load i64, ptr %p2122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2123, ptr %slot353, align 8
  %v2124 = load i64, ptr %slot353, align 8
  %op2125 = add i64 %v2124, 0
  store i64 %op2125, ptr %slot354, align 8
  %v2126 = load i64, ptr %slot354, align 8
  %v2127 = load i64, ptr %slot23, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  store i64 %v2126, ptr %p2128, align 8, !alias.scope !3, !noalias !4
  %v2129 = load i64, ptr %slot7, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %ld2131 = load i32, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2131, ptr %slot355, align 8
  %v2132 = load i32, ptr %slot355, align 8
  %cv2133 = zext i32 %v2132 to i64
  %cond2134 = icmp ne i64 %cv2133, 0
  br i1 %cond2134, label %bb_rcslotdrop490, label %bb_rcslotdone490
bb_rcslotdrop490:
  %v2135 = load i64, ptr %slot7, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i32 0, ptr %p2136, align 4, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot11, align 8
  store i64 %v2137, ptr %slot356, align 8
  %v2138 = load i64, ptr %slot8, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i32, ptr %p2139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2140, ptr %slot357, align 8
  %v2141 = load i32, ptr %slot357, align 8
  %op2142 = and i32 %v2141, 28
  store i32 %op2142, ptr %slot358, align 8
  %v2143 = load i32, ptr %slot358, align 8
  %cv2144 = zext i32 %v2143 to i64
  %cond2145 = icmp ne i64 %cv2144, 0
  br i1 %cond2145, label %bb_rcslotrole490, label %bb_rcslotowner490
bb_rcslotrole490:
  %v2146 = load i64, ptr %slot31, align 8
  store i64 %v2146, ptr %slot359, align 8
  %v2147 = load i64, ptr %slot359, align 8
  %v2148 = load i64, ptr %slot356, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2147, i64 %v2148) nomerge, !dbg !124
  br label %bb_rcslotdone490
bb_rcslotowner490:
  %v2149 = load i64, ptr %slot31, align 8
  store i64 %v2149, ptr %slot360, align 8
  %v2150 = load i64, ptr %slot360, align 8
  %v2151 = load i64, ptr %slot356, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2150, i64 %v2151) nomerge, !dbg !124
  br label %bb_rcslotdone490
bb_rcslotdone490:
  %v2152 = load i64, ptr %slot23, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %ld2154 = load i64, ptr %p2153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2154, ptr %slot361, align 8
  %v2155 = load i64, ptr %slot361, align 8
  %op2156 = add i64 %v2155, 160
  store i64 %op2156, ptr %slot362, align 8
  %v2157 = load i64, ptr %slot362, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  %ld2159 = load i64, ptr %p2158, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2159, ptr %slot363, align 8
  %v2160 = load i64, ptr %slot363, align 8
  %v2161 = load i64, ptr %slot23, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  store i64 %v2160, ptr %p2162, align 8, !alias.scope !3, !noalias !4
  %v2163 = load i64, ptr %slot23, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %ld2165 = load i64, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2165, ptr %slot364, align 8
  %v2166 = load i64, ptr %slot364, align 8
  %v2167 = load i64, ptr %slot12, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  store i64 %v2166, ptr %p2168, align 8, !alias.scope !3, !noalias !4
  %v2169 = load i64, ptr %slot12, align 8
  store i64 %v2169, ptr %slot365, align 8
  %v2170 = load i64, ptr %slot13, align 8
  store i64 %v2170, ptr %slot366, align 8
  %v2171 = load i64, ptr %slot365, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i64, ptr %p2172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2173, ptr %slot367, align 8
  %v2174 = load i64, ptr %slot367, align 8
  %cmp2175 = icmp ne i64 %v2174, 0
  %cv2176 = zext i1 %cmp2175 to i32
  store i32 %cv2176, ptr %slot368, align 8
  %v2177 = load i32, ptr %slot368, align 8
  %cv2178 = zext i32 %v2177 to i64
  %cond2179 = icmp ne i64 %cv2178, 0
  br i1 %cond2179, label %bb_rcgnn504, label %bb_rcgstore504
bb_rcgnn504:
  %v2180 = load i64, ptr %slot367, align 8
  %op2181 = sub i64 %v2180, 16
  store i64 %op2181, ptr %slot369, align 8
  %v2182 = load i64, ptr %slot367, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %rgep2184 = getelementptr i8, ptr %p2183, i64 -16
  %ld2185 = load i64, ptr %rgep2184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2185, ptr %slot370, align 8
  %v2186 = load i64, ptr %slot370, align 8
  %op2187 = and i64 %v2186, 4611686018427387906
  store i64 %op2187, ptr %slot371, align 8
  %v2188 = load i64, ptr %slot371, align 8
  %cmp2189 = icmp ne i64 %v2188, 0
  %cv2190 = zext i1 %cmp2189 to i32
  store i32 %cv2190, ptr %slot372, align 8
  %v2191 = load i32, ptr %slot372, align 8
  %cv2192 = zext i32 %v2191 to i64
  %cond2193 = icmp ne i64 %cv2192, 0
  br i1 %cond2193, label %bb_rcgstore504, label %bb_rcginc504
bb_rcginc504:
  %v2194 = load i64, ptr %slot367, align 8
  %op2195 = sub i64 %v2194, 24
  store i64 %op2195, ptr %slot373, align 8
  %v2196 = load i64, ptr %slot367, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %rgep2198 = getelementptr i8, ptr %p2197, i64 -24
  %ld2199 = load i64, ptr %rgep2198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2199, ptr %slot374, align 8
  %v2200 = load i64, ptr %slot374, align 8
  %op2201 = add i64 %v2200, 1
  store i64 %op2201, ptr %slot375, align 8
  %v2202 = load i64, ptr %slot375, align 8
  %cmp2203 = icmp eq i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot376, align 8
  %v2205 = load i32, ptr %slot376, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcglimit504, label %bb_rcgcapacity504
bb_rcglimit504:
  %v2208 = load i64, ptr %slot1, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %call2210 = call i32 @myl_qbe_rc_status(ptr %p2209, i32 2) nomerge, !dbg !126
  store i32 %call2210, ptr %slot377, align 8
  br label %bb_failure
bb_rcgcapacity504:
  %v2211 = load i64, ptr %slot375, align 8
  %v2212 = load i64, ptr %slot367, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %rgep2214 = getelementptr i8, ptr %p2213, i64 -24
  store i64 %v2211, ptr %rgep2214, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore504
bb_rcgstore504:
  %v2215 = load i64, ptr %slot367, align 8
  %v2216 = load i64, ptr %slot366, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i64 %v2215, ptr %p2217, align 8, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot10, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  store i32 2, ptr %p2219, align 4, !alias.scope !3, !noalias !4
  %v2220 = load i64, ptr %slot10, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i32 16, ptr %p2221, align 4, !alias.scope !3, !noalias !4
  %v2222 = load i64, ptr %slot9, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i32 1, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot7, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i32, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2226, ptr %slot378, align 8
  %v2227 = load i32, ptr %slot378, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcslotdrop520, label %bb_rcslotdone520
bb_rcslotdrop520:
  %v2230 = load i64, ptr %slot7, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  store i32 0, ptr %p2231, align 4, !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot11, align 8
  store i64 %v2232, ptr %slot379, align 8
  %v2233 = load i64, ptr %slot8, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i32, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2235, ptr %slot380, align 8
  %v2236 = load i32, ptr %slot380, align 8
  %op2237 = and i32 %v2236, 28
  store i32 %op2237, ptr %slot381, align 8
  %v2238 = load i32, ptr %slot381, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotrole520, label %bb_rcslotowner520
bb_rcslotrole520:
  %v2241 = load i64, ptr %slot31, align 8
  store i64 %v2241, ptr %slot382, align 8
  %v2242 = load i64, ptr %slot382, align 8
  %v2243 = load i64, ptr %slot379, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2242, i64 %v2243) nomerge, !dbg !126
  br label %bb_rcslotdone520
bb_rcslotowner520:
  %v2244 = load i64, ptr %slot31, align 8
  store i64 %v2244, ptr %slot383, align 8
  %v2245 = load i64, ptr %slot383, align 8
  %v2246 = load i64, ptr %slot379, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2245, i64 %v2246) nomerge, !dbg !126
  br label %bb_rcslotdone520
bb_rcslotdone520:
  %v2247 = load i64, ptr %slot11, align 8
  store i64 %v2247, ptr %slot384, align 8
  %v2248 = load i64, ptr %slot13, align 8
  store i64 %v2248, ptr %slot385, align 8
  %v2249 = load i64, ptr %slot385, align 8
  %v2250 = load i64, ptr %slot384, align 8
  %p2251 = inttoptr i64 %v2249 to ptr
  %p2252 = inttoptr i64 %v2250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2252, ptr %p2251, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot8, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i32 2, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot10, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %ld2257 = load i32, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2257, ptr %slot386, align 8
  %v2258 = load i32, ptr %slot386, align 8
  %v2259 = load i64, ptr %slot8, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i32 %v2258, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot9, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  store i32 0, ptr %p2262, align 4, !alias.scope !3, !noalias !4
  %v2263 = load i64, ptr %slot7, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i32 1, ptr %p2264, align 4, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot384, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot387, align 8
  %v2268 = load i64, ptr %slot387, align 8
  %v2269 = load i64, ptr %slot23, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i64 %v2268, ptr %p2270, align 8, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot23, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  %ld2273 = load i64, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2273, ptr %slot388, align 8
  %v2274 = load i64, ptr %slot19, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  %ld2276 = load i64, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2276, ptr %slot389, align 8
  %v2277 = load i64, ptr %slot7, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i32, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2279, ptr %slot390, align 8
  %v2280 = load i32, ptr %slot390, align 8
  %cv2281 = zext i32 %v2280 to i64
  %cond2282 = icmp ne i64 %cv2281, 0
  br i1 %cond2282, label %bb_rcslotdrop541, label %bb_rcslotdone541
bb_rcslotdrop541:
  %v2283 = load i64, ptr %slot7, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i32 0, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot11, align 8
  store i64 %v2285, ptr %slot391, align 8
  %v2286 = load i64, ptr %slot8, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i32, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2288, ptr %slot392, align 8
  %v2289 = load i32, ptr %slot392, align 8
  %op2290 = and i32 %v2289, 28
  store i32 %op2290, ptr %slot393, align 8
  %v2291 = load i32, ptr %slot393, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcslotrole541, label %bb_rcslotowner541
bb_rcslotrole541:
  %v2294 = load i64, ptr %slot31, align 8
  store i64 %v2294, ptr %slot394, align 8
  %v2295 = load i64, ptr %slot391, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  %ld2297 = load i64, ptr %p2296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2297, ptr %slot395, align 8
  %v2298 = load i64, ptr %slot395, align 8
  %cmp2299 = icmp ne i64 %v2298, 0
  %cv2300 = zext i1 %cmp2299 to i32
  store i32 %cv2300, ptr %slot396, align 8
  %v2301 = load i32, ptr %slot396, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcgnn557, label %bb_rcgdone557
bb_rcgnn557:
  %v2304 = load i64, ptr %slot395, align 8
  %op2305 = sub i64 %v2304, 16
  store i64 %op2305, ptr %slot397, align 8
  %v2306 = load i64, ptr %slot395, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  %rgep2308 = getelementptr i8, ptr %p2307, i64 -16
  %ld2309 = load i64, ptr %rgep2308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2309, ptr %slot398, align 8
  %v2310 = load i64, ptr %slot398, align 8
  %op2311 = and i64 %v2310, 4611686018427387906
  store i64 %op2311, ptr %slot399, align 8
  %v2312 = load i64, ptr %slot399, align 8
  %cmp2313 = icmp ne i64 %v2312, 0
  %cv2314 = zext i1 %cmp2313 to i32
  store i32 %cv2314, ptr %slot400, align 8
  %v2315 = load i32, ptr %slot400, align 8
  %cv2316 = zext i32 %v2315 to i64
  %cond2317 = icmp ne i64 %cv2316, 0
  br i1 %cond2317, label %bb_rcgclear557, label %bb_rcgcounted557
bb_rcgcounted557:
  %v2318 = load i64, ptr %slot395, align 8
  %op2319 = sub i64 %v2318, 24
  store i64 %op2319, ptr %slot401, align 8
  %v2320 = load i64, ptr %slot395, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  %rgep2322 = getelementptr i8, ptr %p2321, i64 -24
  %ld2323 = load i64, ptr %rgep2322, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2323, ptr %slot402, align 8
  %v2324 = load i64, ptr %slot402, align 8
  %op2325 = sub i64 %v2324, 1
  store i64 %op2325, ptr %slot403, align 8
  %v2326 = load i64, ptr %slot403, align 8
  %cmp2327 = icmp eq i64 %v2326, 0
  %cv2328 = zext i1 %cmp2327 to i32
  store i32 %cv2328, ptr %slot404, align 8
  %v2329 = load i32, ptr %slot404, align 8
  %cv2330 = zext i32 %v2329 to i64
  %cond2331 = icmp ne i64 %cv2330, 0
  br i1 %cond2331, label %bb_rcglast557, label %bb_rcgdec557
bb_rcglast557:
  %v2332 = load i64, ptr %slot395, align 8
  %op2333 = sub i64 %v2332, 32
  store i64 %op2333, ptr %slot405, align 8
  %v2334 = load i64, ptr %slot395, align 8
  %p2335 = inttoptr i64 %v2334 to ptr
  %rgep2336 = getelementptr i8, ptr %p2335, i64 -32
  %ld2337 = load i64, ptr %rgep2336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2337, ptr %slot406, align 8
  %v2338 = load i64, ptr %slot406, align 8
  %cmp2339 = icmp ne i64 %v2338, 0
  %cv2340 = zext i1 %cmp2339 to i32
  store i32 %cv2340, ptr %slot407, align 8
  %v2341 = load i32, ptr %slot407, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcgdec557, label %bb_rcgslow557
bb_rcgslow557:
  %v2344 = load i64, ptr %slot394, align 8
  %v2345 = load i64, ptr %slot391, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2344, i64 %v2345) nomerge, !dbg !128
  br label %bb_rcgdone557
bb_rcgdec557:
  %v2346 = load i64, ptr %slot403, align 8
  %v2347 = load i64, ptr %slot395, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  %rgep2349 = getelementptr i8, ptr %p2348, i64 -24
  store i64 %v2346, ptr %rgep2349, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear557
bb_rcgclear557:
  %v2350 = load i64, ptr %slot391, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  store i64 0, ptr %p2351, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone557
bb_rcgdone557:
  br label %bb_rcslotdone541
bb_rcslotowner541:
  %v2352 = load i64, ptr %slot31, align 8
  store i64 %v2352, ptr %slot408, align 8
  %v2353 = load i64, ptr %slot391, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %ld2355 = load i64, ptr %p2354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2355, ptr %slot409, align 8
  %v2356 = load i64, ptr %slot409, align 8
  %cmp2357 = icmp ne i64 %v2356, 0
  %cv2358 = zext i1 %cmp2357 to i32
  store i32 %cv2358, ptr %slot410, align 8
  %v2359 = load i32, ptr %slot410, align 8
  %cv2360 = zext i32 %v2359 to i64
  %cond2361 = icmp ne i64 %cv2360, 0
  br i1 %cond2361, label %bb_rcgnn572, label %bb_rcgdone572
bb_rcgnn572:
  %v2362 = load i64, ptr %slot409, align 8
  %op2363 = sub i64 %v2362, 16
  store i64 %op2363, ptr %slot411, align 8
  %v2364 = load i64, ptr %slot409, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %rgep2366 = getelementptr i8, ptr %p2365, i64 -16
  %ld2367 = load i64, ptr %rgep2366, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2367, ptr %slot412, align 8
  %v2368 = load i64, ptr %slot412, align 8
  %op2369 = and i64 %v2368, 4611686018427387906
  store i64 %op2369, ptr %slot413, align 8
  %v2370 = load i64, ptr %slot413, align 8
  %cmp2371 = icmp ne i64 %v2370, 0
  %cv2372 = zext i1 %cmp2371 to i32
  store i32 %cv2372, ptr %slot414, align 8
  %v2373 = load i32, ptr %slot414, align 8
  %cv2374 = zext i32 %v2373 to i64
  %cond2375 = icmp ne i64 %cv2374, 0
  br i1 %cond2375, label %bb_rcgclear572, label %bb_rcgcounted572
bb_rcgcounted572:
  %v2376 = load i64, ptr %slot409, align 8
  %op2377 = sub i64 %v2376, 32
  store i64 %op2377, ptr %slot415, align 8
  %v2378 = load i64, ptr %slot409, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %rgep2380 = getelementptr i8, ptr %p2379, i64 -32
  %ld2381 = load i64, ptr %rgep2380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2381, ptr %slot416, align 8
  %v2382 = load i64, ptr %slot416, align 8
  %op2383 = sub i64 %v2382, 1
  store i64 %op2383, ptr %slot417, align 8
  %v2384 = load i64, ptr %slot417, align 8
  %cmp2385 = icmp eq i64 %v2384, 0
  %cv2386 = zext i1 %cmp2385 to i32
  store i32 %cv2386, ptr %slot418, align 8
  %v2387 = load i32, ptr %slot418, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcglast572, label %bb_rcgdec572
bb_rcglast572:
  %v2390 = load i64, ptr %slot409, align 8
  %op2391 = sub i64 %v2390, 24
  store i64 %op2391, ptr %slot419, align 8
  %v2392 = load i64, ptr %slot409, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  %rgep2394 = getelementptr i8, ptr %p2393, i64 -24
  %ld2395 = load i64, ptr %rgep2394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2395, ptr %slot420, align 8
  %v2396 = load i64, ptr %slot420, align 8
  %cmp2397 = icmp ne i64 %v2396, 0
  %cv2398 = zext i1 %cmp2397 to i32
  store i32 %cv2398, ptr %slot421, align 8
  %v2399 = load i32, ptr %slot421, align 8
  %cv2400 = zext i32 %v2399 to i64
  %cond2401 = icmp ne i64 %cv2400, 0
  br i1 %cond2401, label %bb_rcgdec572, label %bb_rcgslow572
bb_rcgslow572:
  %v2402 = load i64, ptr %slot408, align 8
  %v2403 = load i64, ptr %slot391, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2402, i64 %v2403) nomerge, !dbg !128
  br label %bb_rcgdone572
bb_rcgdec572:
  %v2404 = load i64, ptr %slot417, align 8
  %v2405 = load i64, ptr %slot409, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  %rgep2407 = getelementptr i8, ptr %p2406, i64 -32
  store i64 %v2404, ptr %rgep2407, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear572
bb_rcgclear572:
  %v2408 = load i64, ptr %slot391, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i64 0, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone572
bb_rcgdone572:
  br label %bb_rcslotdone541
bb_rcslotdone541:
  %v2410 = load i64, ptr %slot389, align 8
  %op2411 = add i64 %v2410, 0
  store i64 %op2411, ptr %slot422, align 8
  %v2412 = load i64, ptr %slot422, align 8
  %op2413 = add i64 %v2412, 160
  store i64 %op2413, ptr %slot423, align 8
  store i64 0, ptr %slot424, align 8
  %v2414 = load i64, ptr %slot423, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  %ld2416 = load i64, ptr %p2415, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2416, ptr %slot425, align 8
  %v2417 = load i64, ptr %slot425, align 8
  %cmp2418 = icmp ne i64 %v2417, 0
  %cv2419 = zext i1 %cmp2418 to i32
  store i32 %cv2419, ptr %slot426, align 8
  %v2420 = load i32, ptr %slot426, align 8
  %cv2421 = zext i32 %v2420 to i64
  %cond2422 = icmp ne i64 %cv2421, 0
  br i1 %cond2422, label %bb_rcguniquenn579, label %bb_rcgunique579
bb_rcguniquenn579:
  %v2423 = load i64, ptr %slot425, align 8
  %op2424 = sub i64 %v2423, 16
  store i64 %op2424, ptr %slot427, align 8
  %v2425 = load i64, ptr %slot425, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %rgep2427 = getelementptr i8, ptr %p2426, i64 -16
  %ld2428 = load i64, ptr %rgep2427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2428, ptr %slot428, align 8
  %v2429 = load i64, ptr %slot428, align 8
  %op2430 = and i64 %v2429, 6917529027641081858
  store i64 %op2430, ptr %slot429, align 8
  %v2431 = load i64, ptr %slot429, align 8
  %cmp2432 = icmp ne i64 %v2431, 0
  %cv2433 = zext i1 %cmp2432 to i32
  store i32 %cv2433, ptr %slot430, align 8
  %v2434 = load i32, ptr %slot430, align 8
  %cv2435 = zext i32 %v2434 to i64
  %cond2436 = icmp ne i64 %cv2435, 0
  br i1 %cond2436, label %bb_rcguniqueslow579, label %bb_rcguniquecount579
bb_rcguniquecount579:
  %v2437 = load i64, ptr %slot425, align 8
  %op2438 = sub i64 %v2437, 32
  store i64 %op2438, ptr %slot431, align 8
  %v2439 = load i64, ptr %slot425, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %rgep2441 = getelementptr i8, ptr %p2440, i64 -32
  %ld2442 = load i64, ptr %rgep2441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2442, ptr %slot432, align 8
  %v2443 = load i64, ptr %slot432, align 8
  %cmp2444 = icmp ult i64 %v2443, 2
  %cv2445 = zext i1 %cmp2444 to i32
  store i32 %cv2445, ptr %slot433, align 8
  %v2446 = load i32, ptr %slot433, align 8
  %cv2447 = zext i32 %v2446 to i64
  %cond2448 = icmp ne i64 %cv2447, 0
  br i1 %cond2448, label %bb_rcgunique579, label %bb_rcguniqueslow579
bb_rcguniqueslow579:
  %v2449 = load i64, ptr %slot1, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  %p2451 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v2452 = load i64, ptr %slot423, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %v2454 = load i64, ptr %slot424, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %call2456 = call i32 @myl_qbe_rc_unique_field(ptr %p2450, ptr %p2451, ptr %p2453, ptr %p2455) nomerge, !dbg !128
  store i32 %call2456, ptr %slot434, align 8
  %v2457 = load i32, ptr %slot434, align 8
  %cv2458 = zext i32 %v2457 to i64
  %cond2459 = icmp ne i64 %cv2458, 0
  br i1 %cond2459, label %bb_rcunique589, label %bb_failure
bb_rcunique589:
  br label %bb_rcgunique579
bb_rcgunique579:
  %v2460 = load i64, ptr %slot423, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %ld2462 = load i64, ptr %p2461, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2462, ptr %slot435, align 8
  %v2463 = load i64, ptr %slot435, align 8
  %v2464 = load i64, ptr %slot23, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  store i64 %v2463, ptr %p2465, align 8, !alias.scope !3, !noalias !4
  %v2466 = load i64, ptr %slot23, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %ld2468 = load i64, ptr %p2467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2468, ptr %slot436, align 8
  %v2469 = load i64, ptr %slot7, align 8
  %p2470 = inttoptr i64 %v2469 to ptr
  %ld2471 = load i32, ptr %p2470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2471, ptr %slot437, align 8
  %v2472 = load i32, ptr %slot437, align 8
  %cv2473 = zext i32 %v2472 to i64
  %cond2474 = icmp ne i64 %cv2473, 0
  br i1 %cond2474, label %bb_rcslotdrop594, label %bb_rcslotdone594
bb_rcslotdrop594:
  %v2475 = load i64, ptr %slot7, align 8
  %p2476 = inttoptr i64 %v2475 to ptr
  store i32 0, ptr %p2476, align 4, !alias.scope !3, !noalias !4
  %v2477 = load i64, ptr %slot11, align 8
  store i64 %v2477, ptr %slot438, align 8
  %v2478 = load i64, ptr %slot8, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %ld2480 = load i32, ptr %p2479, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2480, ptr %slot439, align 8
  %v2481 = load i32, ptr %slot439, align 8
  %op2482 = and i32 %v2481, 28
  store i32 %op2482, ptr %slot440, align 8
  %v2483 = load i32, ptr %slot440, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcslotrole594, label %bb_rcslotowner594
bb_rcslotrole594:
  %v2486 = load i64, ptr %slot31, align 8
  store i64 %v2486, ptr %slot441, align 8
  %v2487 = load i64, ptr %slot438, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %ld2489 = load i64, ptr %p2488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2489, ptr %slot442, align 8
  %v2490 = load i64, ptr %slot442, align 8
  %cmp2491 = icmp ne i64 %v2490, 0
  %cv2492 = zext i1 %cmp2491 to i32
  store i32 %cv2492, ptr %slot443, align 8
  %v2493 = load i32, ptr %slot443, align 8
  %cv2494 = zext i32 %v2493 to i64
  %cond2495 = icmp ne i64 %cv2494, 0
  br i1 %cond2495, label %bb_rcgnn610, label %bb_rcgdone610
bb_rcgnn610:
  %v2496 = load i64, ptr %slot442, align 8
  %op2497 = sub i64 %v2496, 16
  store i64 %op2497, ptr %slot444, align 8
  %v2498 = load i64, ptr %slot442, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  %rgep2500 = getelementptr i8, ptr %p2499, i64 -16
  %ld2501 = load i64, ptr %rgep2500, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2501, ptr %slot445, align 8
  %v2502 = load i64, ptr %slot445, align 8
  %op2503 = and i64 %v2502, 4611686018427387906
  store i64 %op2503, ptr %slot446, align 8
  %v2504 = load i64, ptr %slot446, align 8
  %cmp2505 = icmp ne i64 %v2504, 0
  %cv2506 = zext i1 %cmp2505 to i32
  store i32 %cv2506, ptr %slot447, align 8
  %v2507 = load i32, ptr %slot447, align 8
  %cv2508 = zext i32 %v2507 to i64
  %cond2509 = icmp ne i64 %cv2508, 0
  br i1 %cond2509, label %bb_rcgclear610, label %bb_rcgcounted610
bb_rcgcounted610:
  %v2510 = load i64, ptr %slot442, align 8
  %op2511 = sub i64 %v2510, 24
  store i64 %op2511, ptr %slot448, align 8
  %v2512 = load i64, ptr %slot442, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  %rgep2514 = getelementptr i8, ptr %p2513, i64 -24
  %ld2515 = load i64, ptr %rgep2514, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2515, ptr %slot449, align 8
  %v2516 = load i64, ptr %slot449, align 8
  %op2517 = sub i64 %v2516, 1
  store i64 %op2517, ptr %slot450, align 8
  %v2518 = load i64, ptr %slot450, align 8
  %cmp2519 = icmp eq i64 %v2518, 0
  %cv2520 = zext i1 %cmp2519 to i32
  store i32 %cv2520, ptr %slot451, align 8
  %v2521 = load i32, ptr %slot451, align 8
  %cv2522 = zext i32 %v2521 to i64
  %cond2523 = icmp ne i64 %cv2522, 0
  br i1 %cond2523, label %bb_rcglast610, label %bb_rcgdec610
bb_rcglast610:
  %v2524 = load i64, ptr %slot442, align 8
  %op2525 = sub i64 %v2524, 32
  store i64 %op2525, ptr %slot452, align 8
  %v2526 = load i64, ptr %slot442, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %rgep2528 = getelementptr i8, ptr %p2527, i64 -32
  %ld2529 = load i64, ptr %rgep2528, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2529, ptr %slot453, align 8
  %v2530 = load i64, ptr %slot453, align 8
  %cmp2531 = icmp ne i64 %v2530, 0
  %cv2532 = zext i1 %cmp2531 to i32
  store i32 %cv2532, ptr %slot454, align 8
  %v2533 = load i32, ptr %slot454, align 8
  %cv2534 = zext i32 %v2533 to i64
  %cond2535 = icmp ne i64 %cv2534, 0
  br i1 %cond2535, label %bb_rcgdec610, label %bb_rcgslow610
bb_rcgslow610:
  %v2536 = load i64, ptr %slot441, align 8
  %v2537 = load i64, ptr %slot438, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2536, i64 %v2537) nomerge, !dbg !128
  br label %bb_rcgdone610
bb_rcgdec610:
  %v2538 = load i64, ptr %slot450, align 8
  %v2539 = load i64, ptr %slot442, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %rgep2541 = getelementptr i8, ptr %p2540, i64 -24
  store i64 %v2538, ptr %rgep2541, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear610
bb_rcgclear610:
  %v2542 = load i64, ptr %slot438, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  store i64 0, ptr %p2543, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone610
bb_rcgdone610:
  br label %bb_rcslotdone594
bb_rcslotowner594:
  %v2544 = load i64, ptr %slot31, align 8
  store i64 %v2544, ptr %slot455, align 8
  %v2545 = load i64, ptr %slot438, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i64, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2547, ptr %slot456, align 8
  %v2548 = load i64, ptr %slot456, align 8
  %cmp2549 = icmp ne i64 %v2548, 0
  %cv2550 = zext i1 %cmp2549 to i32
  store i32 %cv2550, ptr %slot457, align 8
  %v2551 = load i32, ptr %slot457, align 8
  %cv2552 = zext i32 %v2551 to i64
  %cond2553 = icmp ne i64 %cv2552, 0
  br i1 %cond2553, label %bb_rcgnn625, label %bb_rcgdone625
bb_rcgnn625:
  %v2554 = load i64, ptr %slot456, align 8
  %op2555 = sub i64 %v2554, 16
  store i64 %op2555, ptr %slot458, align 8
  %v2556 = load i64, ptr %slot456, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %rgep2558 = getelementptr i8, ptr %p2557, i64 -16
  %ld2559 = load i64, ptr %rgep2558, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2559, ptr %slot459, align 8
  %v2560 = load i64, ptr %slot459, align 8
  %op2561 = and i64 %v2560, 4611686018427387906
  store i64 %op2561, ptr %slot460, align 8
  %v2562 = load i64, ptr %slot460, align 8
  %cmp2563 = icmp ne i64 %v2562, 0
  %cv2564 = zext i1 %cmp2563 to i32
  store i32 %cv2564, ptr %slot461, align 8
  %v2565 = load i32, ptr %slot461, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcgclear625, label %bb_rcgcounted625
bb_rcgcounted625:
  %v2568 = load i64, ptr %slot456, align 8
  %op2569 = sub i64 %v2568, 32
  store i64 %op2569, ptr %slot462, align 8
  %v2570 = load i64, ptr %slot456, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  %rgep2572 = getelementptr i8, ptr %p2571, i64 -32
  %ld2573 = load i64, ptr %rgep2572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2573, ptr %slot463, align 8
  %v2574 = load i64, ptr %slot463, align 8
  %op2575 = sub i64 %v2574, 1
  store i64 %op2575, ptr %slot464, align 8
  %v2576 = load i64, ptr %slot464, align 8
  %cmp2577 = icmp eq i64 %v2576, 0
  %cv2578 = zext i1 %cmp2577 to i32
  store i32 %cv2578, ptr %slot465, align 8
  %v2579 = load i32, ptr %slot465, align 8
  %cv2580 = zext i32 %v2579 to i64
  %cond2581 = icmp ne i64 %cv2580, 0
  br i1 %cond2581, label %bb_rcglast625, label %bb_rcgdec625
bb_rcglast625:
  %v2582 = load i64, ptr %slot456, align 8
  %op2583 = sub i64 %v2582, 24
  store i64 %op2583, ptr %slot466, align 8
  %v2584 = load i64, ptr %slot456, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  %rgep2586 = getelementptr i8, ptr %p2585, i64 -24
  %ld2587 = load i64, ptr %rgep2586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2587, ptr %slot467, align 8
  %v2588 = load i64, ptr %slot467, align 8
  %cmp2589 = icmp ne i64 %v2588, 0
  %cv2590 = zext i1 %cmp2589 to i32
  store i32 %cv2590, ptr %slot468, align 8
  %v2591 = load i32, ptr %slot468, align 8
  %cv2592 = zext i32 %v2591 to i64
  %cond2593 = icmp ne i64 %cv2592, 0
  br i1 %cond2593, label %bb_rcgdec625, label %bb_rcgslow625
bb_rcgslow625:
  %v2594 = load i64, ptr %slot455, align 8
  %v2595 = load i64, ptr %slot438, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2594, i64 %v2595) nomerge, !dbg !128
  br label %bb_rcgdone625
bb_rcgdec625:
  %v2596 = load i64, ptr %slot464, align 8
  %v2597 = load i64, ptr %slot456, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  %rgep2599 = getelementptr i8, ptr %p2598, i64 -32
  store i64 %v2596, ptr %rgep2599, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear625
bb_rcgclear625:
  %v2600 = load i64, ptr %slot438, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  store i64 0, ptr %p2601, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone625
bb_rcgdone625:
  br label %bb_rcslotdone594
bb_rcslotdone594:
  %v2602 = load i64, ptr %slot16, align 8
  store i64 %v2602, ptr %slot469, align 8
  %v2603 = load i64, ptr %slot31, align 8
  %v2604 = load i64, ptr %slot469, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i64 %v2603, ptr %p2605, align 8, !alias.scope !3, !noalias !4
  %v2606 = load i64, ptr %slot31, align 8
  %p2608 = inttoptr i64 %v2606 to ptr
  %gep2609 = getelementptr i8, ptr %p2608, i64 5640
  %op2607 = ptrtoint ptr %gep2609 to i64
  store i64 %op2607, ptr %slot470, align 8
  %v2610 = load i64, ptr %slot470, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  %ld2612 = load i64, ptr %p2611, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2612, ptr %slot471, align 8
  %v2613 = load i64, ptr %slot471, align 8
  %op2614 = add i64 %v2613, 248
  store i64 %op2614, ptr %slot472, align 8
  %v2615 = load i64, ptr %slot472, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  %ld2617 = load i64, ptr %p2616, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2617, ptr %slot473, align 8
  %v2618 = load i64, ptr %slot469, align 8
  %p2620 = inttoptr i64 %v2618 to ptr
  %gep2621 = getelementptr i8, ptr %p2620, i64 8
  %op2619 = ptrtoint ptr %gep2621 to i64
  store i64 %op2619, ptr %slot474, align 8
  %v2622 = load i64, ptr %slot473, align 8
  %v2623 = load i64, ptr %slot474, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  store i64 %v2622, ptr %p2624, align 8, !alias.scope !3, !noalias !4
  %v2625 = load i64, ptr %slot469, align 8
  %p2627 = inttoptr i64 %v2625 to ptr
  %gep2628 = getelementptr i8, ptr %p2627, i64 16
  %op2626 = ptrtoint ptr %gep2628 to i64
  store i64 %op2626, ptr %slot475, align 8
  %v2629 = load i64, ptr %slot475, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i64 0, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot31, align 8
  %p2633 = inttoptr i64 %v2631 to ptr
  %gep2634 = getelementptr i8, ptr %p2633, i64 112
  %op2632 = ptrtoint ptr %gep2634 to i64
  store i64 %op2632, ptr %slot476, align 8
  %v2635 = load i64, ptr %slot469, align 8
  %p2637 = inttoptr i64 %v2635 to ptr
  %gep2638 = getelementptr i8, ptr %p2637, i64 24
  %op2636 = ptrtoint ptr %gep2638 to i64
  store i64 %op2636, ptr %slot477, align 8
  %v2639 = load i64, ptr %slot469, align 8
  %p2641 = inttoptr i64 %v2639 to ptr
  %gep2642 = getelementptr i8, ptr %p2641, i64 28
  %op2640 = ptrtoint ptr %gep2642 to i64
  store i64 %op2640, ptr %slot478, align 8
  %v2643 = load i64, ptr %slot476, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  %ld2645 = load i32, ptr %p2644, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld2645, ptr %slot479, align 8
  %v2646 = load i64, ptr %slot477, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i32 1, ptr %p2647, align 4, !alias.scope !3, !noalias !4
  %v2648 = load i32, ptr %slot479, align 8
  %v2649 = load i64, ptr %slot478, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  store i32 %v2648, ptr %p2650, align 4, !alias.scope !3, !noalias !4
  %v2651 = load i64, ptr %slot469, align 8
  %v2652 = load i64, ptr %slot472, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i64 %v2651, ptr %p2653, align 8, !alias.scope !9999998, !noalias !9999999
  %v2654 = load i64, ptr %slot436, align 8
  %cmp2655 = icmp ne i64 %v2654, 0
  %cv2656 = zext i1 %cmp2655 to i32
  store i32 %cv2656, ptr %slot480, align 8
  %v2657 = load i32, ptr %slot480, align 8
  %cv2658 = zext i32 %v2657 to i64
  %cond2659 = icmp ne i64 %cv2658, 0
  br i1 %cond2659, label %bb_rcspinmark677, label %bb_rcspindone677
bb_rcspinmark677:
  %v2660 = load i64, ptr %slot436, align 8
  %op2661 = sub i64 %v2660, 16
  store i64 %op2661, ptr %slot481, align 8
  %v2662 = load i64, ptr %slot436, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  %rgep2664 = getelementptr i8, ptr %p2663, i64 -16
  %ld2665 = load i64, ptr %rgep2664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2665, ptr %slot482, align 8
  %v2666 = load i64, ptr %slot482, align 8
  %op2667 = and i64 %v2666, 2
  store i64 %op2667, ptr %slot483, align 8
  %v2668 = load i64, ptr %slot483, align 8
  %cmp2669 = icmp ne i64 %v2668, 0
  %cv2670 = zext i1 %cmp2669 to i32
  store i32 %cv2670, ptr %slot484, align 8
  %v2671 = load i32, ptr %slot484, align 8
  %cv2672 = zext i32 %v2671 to i64
  %cond2673 = icmp ne i64 %cv2672, 0
  br i1 %cond2673, label %bb_rcspindone677, label %bb_rcspintype677
bb_rcspintype677:
  %v2674 = load i64, ptr %slot482, align 8
  %op2675 = and i64 %v2674, 4611686018427387907
  store i64 %op2675, ptr %slot485, align 8
  %v2676 = load i64, ptr %slot485, align 8
  %cmp2677 = icmp eq i64 %v2676, 0
  %cv2678 = zext i1 %cmp2677 to i32
  store i32 %cv2678, ptr %slot486, align 8
  %v2679 = load i32, ptr %slot486, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcs685, label %bb_rcspinslow677
bb_rcs685:
  %v2682 = load i64, ptr %slot436, align 8
  %op2683 = sub i64 %v2682, 8
  store i64 %op2683, ptr %slot487, align 8
  %v2684 = load i64, ptr %slot436, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  %rgep2686 = getelementptr i8, ptr %p2685, i64 -8
  %ld2687 = load i64, ptr %rgep2686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2687, ptr %slot488, align 8
  %p2688 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld2689 = load i64, ptr %p2688, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2689, ptr %slot489, align 8
  %v2690 = load i64, ptr %slot488, align 8
  %v2691 = load i64, ptr %slot489, align 8
  %cmp2692 = icmp eq i64 %v2690, %v2691
  %cv2693 = zext i1 %cmp2692 to i32
  store i32 %cv2693, ptr %slot490, align 8
  %v2694 = load i32, ptr %slot490, align 8
  %cv2695 = zext i32 %v2694 to i64
  %cond2696 = icmp ne i64 %cv2695, 0
  br i1 %cond2696, label %bb_rcs690, label %bb_rcspinslow677
bb_rcs690:
  %v2697 = load i64, ptr %slot31, align 8
  %p2699 = inttoptr i64 %v2697 to ptr
  %gep2700 = getelementptr i8, ptr %p2699, i64 5640
  %op2698 = ptrtoint ptr %gep2700 to i64
  store i64 %op2698, ptr %slot491, align 8
  %v2701 = load i64, ptr %slot491, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  %ld2703 = load i64, ptr %p2702, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2703, ptr %slot492, align 8
  %v2704 = load i64, ptr %slot492, align 8
  %op2705 = add i64 %v2704, 256
  store i64 %op2705, ptr %slot493, align 8
  %v2706 = load i64, ptr %slot493, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %ld2708 = load i64, ptr %p2707, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2708, ptr %slot494, align 8
  %v2709 = load i64, ptr %slot494, align 8
  %cmp2710 = icmp ne i64 %v2709, 0
  %cv2711 = zext i1 %cmp2710 to i32
  store i32 %cv2711, ptr %slot495, align 8
  %v2712 = load i32, ptr %slot495, align 8
  %cv2713 = zext i32 %v2712 to i64
  %cond2714 = icmp ne i64 %cv2713, 0
  br i1 %cond2714, label %bb_rcs696, label %bb_rcspinslow677
bb_rcs696:
  %v2715 = load i64, ptr %slot31, align 8
  %p2717 = inttoptr i64 %v2715 to ptr
  %gep2718 = getelementptr i8, ptr %p2717, i64 24
  %op2716 = ptrtoint ptr %gep2718 to i64
  store i64 %op2716, ptr %slot496, align 8
  %v2719 = load i64, ptr %slot496, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %ld2721 = load i64, ptr %p2720, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2721, ptr %slot497, align 8
  %v2722 = load i64, ptr %slot497, align 8
  %op2723 = add i64 %v2722, 40
  store i64 %op2723, ptr %slot498, align 8
  %v2724 = load i64, ptr %slot498, align 8
  %v2725 = load i64, ptr %slot497, align 8
  %cmp2726 = icmp uge i64 %v2724, %v2725
  %cv2727 = zext i1 %cmp2726 to i32
  store i32 %cv2727, ptr %slot499, align 8
  %v2728 = load i32, ptr %slot499, align 8
  %cv2729 = zext i32 %v2728 to i64
  %cond2730 = icmp ne i64 %cv2729, 0
  br i1 %cond2730, label %bb_rcs701, label %bb_rcspinslow677
bb_rcs701:
  %v2731 = load i64, ptr %slot31, align 8
  %p2733 = inttoptr i64 %v2731 to ptr
  %gep2734 = getelementptr i8, ptr %p2733, i64 88
  %op2732 = ptrtoint ptr %gep2734 to i64
  store i64 %op2732, ptr %slot500, align 8
  %v2735 = load i64, ptr %slot500, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  %ld2737 = load i64, ptr %p2736, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2737, ptr %slot501, align 8
  %v2738 = load i64, ptr %slot501, align 8
  %cmp2739 = icmp eq i64 %v2738, 0
  %cv2740 = zext i1 %cmp2739 to i32
  store i32 %cv2740, ptr %slot502, align 8
  %v2741 = load i64, ptr %slot498, align 8
  %v2742 = load i64, ptr %slot501, align 8
  %cmp2743 = icmp ule i64 %v2741, %v2742
  %cv2744 = zext i1 %cmp2743 to i32
  store i32 %cv2744, ptr %slot503, align 8
  %v2745 = load i32, ptr %slot502, align 8
  %v2746 = load i32, ptr %slot503, align 8
  %op2747 = or i32 %v2745, %v2746
  store i32 %op2747, ptr %slot504, align 8
  %v2748 = load i32, ptr %slot504, align 8
  %cv2749 = zext i32 %v2748 to i64
  %cond2750 = icmp ne i64 %cv2749, 0
  br i1 %cond2750, label %bb_rcs707, label %bb_rcspinslow677
bb_rcs707:
  %v2751 = load i64, ptr %slot436, align 8
  %op2752 = sub i64 %v2751, 24
  store i64 %op2752, ptr %slot505, align 8
  %v2753 = load i64, ptr %slot436, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %rgep2755 = getelementptr i8, ptr %p2754, i64 -24
  %ld2756 = load i64, ptr %rgep2755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2756, ptr %slot506, align 8
  %v2757 = load i64, ptr %slot506, align 8
  %cmp2758 = icmp ne i64 %v2757, 18446744073709551615
  %cv2759 = zext i1 %cmp2758 to i32
  store i32 %cv2759, ptr %slot507, align 8
  %v2760 = load i32, ptr %slot507, align 8
  %cv2761 = zext i32 %v2760 to i64
  %cond2762 = icmp ne i64 %cv2761, 0
  br i1 %cond2762, label %bb_rcs711, label %bb_rcspinslow677
bb_rcs711:
  %v2763 = load i64, ptr %slot436, align 8
  %op2764 = add i64 %v2763, 32
  store i64 %op2764, ptr %slot508, align 8
  %v2765 = load i64, ptr %slot508, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i64, ptr %p2766, align 8
  store i64 %ld2767, ptr %slot509, align 8
  %v2768 = load i64, ptr %slot509, align 8
  %cmp2769 = icmp ne i64 %v2768, 0
  %cv2770 = zext i1 %cmp2769 to i32
  store i32 %cv2770, ptr %slot510, align 8
  %v2771 = load i32, ptr %slot510, align 8
  %cv2772 = zext i32 %v2771 to i64
  %cond2773 = icmp ne i64 %cv2772, 0
  br i1 %cond2773, label %bb_rcspinbacking677, label %bb_rcspincommit677
bb_rcspinbacking677:
  %v2774 = load i64, ptr %slot509, align 8
  %op2775 = sub i64 %v2774, 16
  store i64 %op2775, ptr %slot511, align 8
  %v2776 = load i64, ptr %slot509, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  %rgep2778 = getelementptr i8, ptr %p2777, i64 -16
  %ld2779 = load i64, ptr %rgep2778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2779, ptr %slot512, align 8
  %v2780 = load i64, ptr %slot512, align 8
  %op2781 = and i64 %v2780, 4611686018427387907
  store i64 %op2781, ptr %slot513, align 8
  %v2782 = load i64, ptr %slot513, align 8
  %cmp2783 = icmp eq i64 %v2782, 0
  %cv2784 = zext i1 %cmp2783 to i32
  store i32 %cv2784, ptr %slot514, align 8
  %v2785 = load i32, ptr %slot514, align 8
  %cv2786 = zext i32 %v2785 to i64
  %cond2787 = icmp ne i64 %cv2786, 0
  br i1 %cond2787, label %bb_rcs719, label %bb_rcspinslow677
bb_rcs719:
  %v2788 = load i64, ptr %slot509, align 8
  %op2789 = sub i64 %v2788, 24
  store i64 %op2789, ptr %slot515, align 8
  %v2790 = load i64, ptr %slot509, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  %rgep2792 = getelementptr i8, ptr %p2791, i64 -24
  %ld2793 = load i64, ptr %rgep2792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2793, ptr %slot516, align 8
  %v2794 = load i64, ptr %slot516, align 8
  %cmp2795 = icmp ne i64 %v2794, 18446744073709551615
  %cv2796 = zext i1 %cmp2795 to i32
  store i32 %cv2796, ptr %slot517, align 8
  %v2797 = load i32, ptr %slot517, align 8
  %cv2798 = zext i32 %v2797 to i64
  %cond2799 = icmp ne i64 %cv2798, 0
  br i1 %cond2799, label %bb_rcs723, label %bb_rcspinslow677
bb_rcs723:
  br label %bb_rcspincommit677
bb_rcspincommit677:
  %v2800 = load i64, ptr %slot494, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8
  store i64 %ld2802, ptr %slot518, align 8
  %v2803 = load i64, ptr %slot492, align 8
  %op2804 = add i64 %v2803, 256
  store i64 %op2804, ptr %slot519, align 8
  %v2805 = load i64, ptr %slot518, align 8
  %v2806 = load i64, ptr %slot519, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i64 %v2805, ptr %p2807, align 8, !alias.scope !9999998, !noalias !9999999
  %v2808 = load i64, ptr %slot492, align 8
  %op2809 = add i64 %v2808, 264
  store i64 %op2809, ptr %slot520, align 8
  %v2810 = load i64, ptr %slot520, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  %ld2812 = load i64, ptr %p2811, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2812, ptr %slot521, align 8
  %v2813 = load i64, ptr %slot521, align 8
  %op2814 = add i64 %v2813, 18446744073709551615
  store i64 %op2814, ptr %slot522, align 8
  %v2815 = load i64, ptr %slot522, align 8
  %v2816 = load i64, ptr %slot520, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i64 %v2815, ptr %p2817, align 8, !alias.scope !9999998, !noalias !9999999
  %v2818 = load i64, ptr %slot31, align 8
  %p2820 = inttoptr i64 %v2818 to ptr
  %gep2821 = getelementptr i8, ptr %p2820, i64 24
  %op2819 = ptrtoint ptr %gep2821 to i64
  store i64 %op2819, ptr %slot523, align 8
  %v2822 = load i64, ptr %slot523, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %ld2824 = load i64, ptr %p2823, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2824, ptr %slot524, align 8
  %v2825 = load i64, ptr %slot524, align 8
  %op2826 = add i64 %v2825, 40
  store i64 %op2826, ptr %slot525, align 8
  %v2827 = load i64, ptr %slot525, align 8
  %v2828 = load i64, ptr %slot523, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  store i64 %v2827, ptr %p2829, align 8, !alias.scope !9999998, !noalias !9999999
  %v2830 = load i64, ptr %slot492, align 8
  %op2831 = add i64 %v2830, 48
  store i64 %op2831, ptr %slot526, align 8
  %v2832 = load i64, ptr %slot526, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i64, ptr %p2833, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2834, ptr %slot527, align 8
  %v2835 = load i64, ptr %slot527, align 8
  %op2836 = add i64 %v2835, 40
  store i64 %op2836, ptr %slot528, align 8
  %v2837 = load i64, ptr %slot528, align 8
  %v2838 = load i64, ptr %slot526, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i64 %v2837, ptr %p2839, align 8, !alias.scope !9999998, !noalias !9999999
  %v2840 = load i64, ptr %slot436, align 8
  %op2841 = sub i64 %v2840, 24
  store i64 %op2841, ptr %slot529, align 8
  %v2842 = load i64, ptr %slot436, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %rgep2844 = getelementptr i8, ptr %p2843, i64 -24
  %ld2845 = load i64, ptr %rgep2844, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2845, ptr %slot530, align 8
  %v2846 = load i64, ptr %slot530, align 8
  %op2847 = add i64 %v2846, 1
  store i64 %op2847, ptr %slot531, align 8
  %v2848 = load i64, ptr %slot531, align 8
  %v2849 = load i64, ptr %slot436, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %rgep2851 = getelementptr i8, ptr %p2850, i64 -24
  store i64 %v2848, ptr %rgep2851, align 8, !alias.scope !9, !noalias !10
  %v2852 = load i64, ptr %slot509, align 8
  %cmp2853 = icmp ne i64 %v2852, 0
  %cv2854 = zext i1 %cmp2853 to i32
  store i32 %cv2854, ptr %slot532, align 8
  %v2855 = load i32, ptr %slot532, align 8
  %cv2856 = zext i32 %v2855 to i64
  %cond2857 = icmp ne i64 %cv2856, 0
  br i1 %cond2857, label %bb_rcspinhold677, label %bb_rcspinjournal677
bb_rcspinhold677:
  %v2858 = load i64, ptr %slot509, align 8
  %op2859 = sub i64 %v2858, 24
  store i64 %op2859, ptr %slot533, align 8
  %v2860 = load i64, ptr %slot509, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %rgep2862 = getelementptr i8, ptr %p2861, i64 -24
  %ld2863 = load i64, ptr %rgep2862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2863, ptr %slot534, align 8
  %v2864 = load i64, ptr %slot534, align 8
  %op2865 = add i64 %v2864, 1
  store i64 %op2865, ptr %slot535, align 8
  %v2866 = load i64, ptr %slot535, align 8
  %v2867 = load i64, ptr %slot509, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %rgep2869 = getelementptr i8, ptr %p2868, i64 -24
  store i64 %v2866, ptr %rgep2869, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal677
bb_rcspinjournal677:
  %v2870 = load i64, ptr %slot482, align 8
  %op2871 = and i64 %v2870, 1152921504606846976
  store i64 %op2871, ptr %slot536, align 8
  %v2872 = load i64, ptr %slot482, align 8
  %op2873 = or i64 %v2872, 1152921504606846976
  store i64 %op2873, ptr %slot537, align 8
  %v2874 = load i64, ptr %slot436, align 8
  %op2875 = sub i64 %v2874, 16
  store i64 %op2875, ptr %slot538, align 8
  %v2876 = load i64, ptr %slot537, align 8
  %v2877 = load i64, ptr %slot436, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %rgep2879 = getelementptr i8, ptr %p2878, i64 -16
  store i64 %v2876, ptr %rgep2879, align 8, !alias.scope !9, !noalias !10
  %v2880 = load i64, ptr %slot469, align 8
  %p2882 = inttoptr i64 %v2880 to ptr
  %gep2883 = getelementptr i8, ptr %p2882, i64 16
  %op2881 = ptrtoint ptr %gep2883 to i64
  store i64 %op2881, ptr %slot539, align 8
  %v2884 = load i64, ptr %slot539, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  %ld2886 = load i64, ptr %p2885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2886, ptr %slot540, align 8
  %v2887 = load i64, ptr %slot494, align 8
  %op2888 = add i64 %v2887, 0
  store i64 %op2888, ptr %slot541, align 8
  %v2889 = load i64, ptr %slot540, align 8
  %v2890 = load i64, ptr %slot541, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  store i64 %v2889, ptr %p2891, align 8, !alias.scope !9999998, !noalias !9999999
  %v2892 = load i64, ptr %slot494, align 8
  %op2893 = add i64 %v2892, 8
  store i64 %op2893, ptr %slot542, align 8
  %v2894 = load i64, ptr %slot436, align 8
  %v2895 = load i64, ptr %slot542, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  store i64 %v2894, ptr %p2896, align 8, !alias.scope !9999998, !noalias !9999999
  %v2897 = load i64, ptr %slot494, align 8
  %op2898 = add i64 %v2897, 16
  store i64 %op2898, ptr %slot543, align 8
  %v2899 = load i64, ptr %slot536, align 8
  %v2900 = load i64, ptr %slot543, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  store i64 %v2899, ptr %p2901, align 8, !alias.scope !9999998, !noalias !9999999
  %v2902 = load i64, ptr %slot494, align 8
  %op2903 = add i64 %v2902, 24
  store i64 %op2903, ptr %slot544, align 8
  %v2904 = load i64, ptr %slot544, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  store i32 1, ptr %p2905, align 4, !alias.scope !9999998, !noalias !9999999
  %v2906 = load i64, ptr %slot494, align 8
  %op2907 = add i64 %v2906, 32
  store i64 %op2907, ptr %slot545, align 8
  %v2908 = load i64, ptr %slot509, align 8
  %v2909 = load i64, ptr %slot545, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  store i64 %v2908, ptr %p2910, align 8, !alias.scope !9999998, !noalias !9999999
  %v2911 = load i64, ptr %slot469, align 8
  %p2913 = inttoptr i64 %v2911 to ptr
  %gep2914 = getelementptr i8, ptr %p2913, i64 16
  %op2912 = ptrtoint ptr %gep2914 to i64
  store i64 %op2912, ptr %slot546, align 8
  %v2915 = load i64, ptr %slot494, align 8
  %v2916 = load i64, ptr %slot546, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  store i64 %v2915, ptr %p2917, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone677
bb_rcspinslow677:
  %v2918 = load i64, ptr %slot1, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  %v2920 = load i64, ptr %slot469, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  %v2922 = load i64, ptr %slot436, align 8
  %p2923 = inttoptr i64 %v2922 to ptr
  %call2924 = call i32 @myl_qbe_rc_scope_pin(ptr %p2919, ptr %p2921, ptr %p2923) nomerge, !dbg !128
  store i32 %call2924, ptr %slot547, align 8
  %v2925 = load i32, ptr %slot547, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcunique754, label %bb_failure
bb_rcunique754:
  br label %bb_rcspindone677
bb_rcspindone677:
  %v2928 = load i64, ptr %slot436, align 8
  %v2929 = load i64, ptr %slot22, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  store i64 %v2928, ptr %p2930, align 8, !alias.scope !3, !noalias !4
  %v2931 = load i64, ptr %slot22, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  %ld2933 = load i64, ptr %p2932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2933, ptr %slot548, align 8
  %v2934 = load i64, ptr %slot30, align 8
  store i64 %v2934, ptr %slot549, align 8
  %v2935 = load i64, ptr %slot548, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  %ld2937 = load i64, ptr %p2936, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2937, ptr %slot550, align 8
  %v2938 = load i64, ptr %slot31, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %v2940 = load i64, ptr %slot548, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %v2942 = load i64, ptr %slot30, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %call2944 = call i32 @myl_rc_list_pop(ptr %p2939, ptr %p2941, ptr %p2943) nomerge, !dbg !130
  store i32 %call2944, ptr %slot551, align 8
  %v2945 = load i32, ptr %slot551, align 8
  %cmp2946 = icmp sge i32 %v2945, 0
  %cv2947 = zext i1 %cmp2946 to i32
  store i32 %cv2947, ptr %slot552, align 8
  %v2948 = load i32, ptr %slot552, align 8
  %cv2949 = zext i32 %v2948 to i64
  %cond2950 = icmp ne i64 %cv2949, 0
  br i1 %cond2950, label %bb_success760, label %bb_failed760
bb_failed760:
  %v2951 = load i64, ptr %slot1, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2952) nomerge, !dbg !130
  unreachable
bb_success760:
  %v2953 = load i32, ptr %slot551, align 8
  %cv2954 = zext i32 %v2953 to i64
  %cond2955 = icmp ne i64 %cv2954, 0
  br i1 %cond2955, label %bb_success761, label %bb_failed761
bb_failed761:
  %v2956 = load i64, ptr %slot1, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  %v2958 = load i64, ptr %slot550, align 8
  call void @myl_qbe_fail_pop_bounds(ptr %p2957, i64 %v2958) nomerge, !dbg !130
  unreachable
bb_success761:
  %v2959 = load i64, ptr %slot549, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  %ld2961 = load i64, ptr %p2960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2961, ptr %slot553, align 8
  %v2962 = load i64, ptr %slot553, align 8
  %v2963 = load i64, ptr %slot23, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  store i64 %v2962, ptr %p2964, align 8, !alias.scope !3, !noalias !4
  %v2965 = load i64, ptr %slot16, align 8
  store i64 %v2965, ptr %slot554, align 8
  %v2966 = load i64, ptr %slot554, align 8
  %p2968 = inttoptr i64 %v2966 to ptr
  %gep2969 = getelementptr i8, ptr %p2968, i64 24
  %op2967 = ptrtoint ptr %gep2969 to i64
  store i64 %op2967, ptr %slot555, align 8
  %v2970 = load i64, ptr %slot555, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  %ld2972 = load i32, ptr %p2971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2972, ptr %slot556, align 8
  %v2973 = load i32, ptr %slot556, align 8
  %cv2974 = zext i32 %v2973 to i64
  %cond2975 = icmp ne i64 %cv2974, 0
  br i1 %cond2975, label %bb_rcsendactive764, label %bb_rcsenddone764
bb_rcsendactive764:
  %v2976 = load i64, ptr %slot31, align 8
  %p2978 = inttoptr i64 %v2976 to ptr
  %gep2979 = getelementptr i8, ptr %p2978, i64 5640
  %op2977 = ptrtoint ptr %gep2979 to i64
  store i64 %op2977, ptr %slot557, align 8
  %v2980 = load i64, ptr %slot557, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  %ld2982 = load i64, ptr %p2981, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2982, ptr %slot558, align 8
  %v2983 = load i64, ptr %slot558, align 8
  %op2984 = add i64 %v2983, 248
  store i64 %op2984, ptr %slot559, align 8
  %v2985 = load i64, ptr %slot559, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %ld2987 = load i64, ptr %p2986, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2987, ptr %slot560, align 8
  %v2988 = load i64, ptr %slot560, align 8
  %v2989 = load i64, ptr %slot554, align 8
  %cmp2990 = icmp eq i64 %v2988, %v2989
  %cv2991 = zext i1 %cmp2990 to i32
  store i32 %cv2991, ptr %slot561, align 8
  %v2992 = load i32, ptr %slot561, align 8
  %cv2993 = zext i32 %v2992 to i64
  %cond2994 = icmp ne i64 %cv2993, 0
  br i1 %cond2994, label %bb_rcs772, label %bb_rcsendslow764
bb_rcs772:
  %v2995 = load i64, ptr %slot558, align 8
  %op2996 = add i64 %v2995, 200
  store i64 %op2996, ptr %slot562, align 8
  %v2997 = load i64, ptr %slot562, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %ld2999 = load i64, ptr %p2998, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2999, ptr %slot563, align 8
  %v3000 = load i64, ptr %slot563, align 8
  %cmp3001 = icmp eq i64 %v3000, 0
  %cv3002 = zext i1 %cmp3001 to i32
  store i32 %cv3002, ptr %slot564, align 8
  %v3003 = load i32, ptr %slot564, align 8
  %cv3004 = zext i32 %v3003 to i64
  %cond3005 = icmp ne i64 %cv3004, 0
  br i1 %cond3005, label %bb_rcs776, label %bb_rcsendslow764
bb_rcs776:
  %v3006 = load i64, ptr %slot554, align 8
  %p3008 = inttoptr i64 %v3006 to ptr
  %gep3009 = getelementptr i8, ptr %p3008, i64 16
  %op3007 = ptrtoint ptr %gep3009 to i64
  store i64 %op3007, ptr %slot565, align 8
  %v3010 = load i64, ptr %slot565, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %ld3012 = load i64, ptr %p3011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3012, ptr %slot566, align 8
  %v3013 = load i64, ptr %slot566, align 8
  %cmp3014 = icmp ne i64 %v3013, 0
  %cv3015 = zext i1 %cmp3014 to i32
  store i32 %cv3015, ptr %slot567, align 8
  %v3016 = load i32, ptr %slot567, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcsendnode764, label %bb_rcsendunlink764
bb_rcsendnode764:
  %v3019 = load i64, ptr %slot566, align 8
  %op3020 = add i64 %v3019, 0
  store i64 %op3020, ptr %slot568, align 8
  %v3021 = load i64, ptr %slot568, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %ld3023 = load i64, ptr %p3022, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3023, ptr %slot569, align 8
  %v3024 = load i64, ptr %slot569, align 8
  %cmp3025 = icmp eq i64 %v3024, 0
  %cv3026 = zext i1 %cmp3025 to i32
  store i32 %cv3026, ptr %slot570, align 8
  %v3027 = load i32, ptr %slot570, align 8
  %cv3028 = zext i32 %v3027 to i64
  %cond3029 = icmp ne i64 %cv3028, 0
  br i1 %cond3029, label %bb_rcs783, label %bb_rcsendslow764
bb_rcs783:
  %v3030 = load i64, ptr %slot558, align 8
  %op3031 = add i64 %v3030, 264
  store i64 %op3031, ptr %slot571, align 8
  %v3032 = load i64, ptr %slot571, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  %ld3034 = load i64, ptr %p3033, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3034, ptr %slot572, align 8
  %v3035 = load i64, ptr %slot572, align 8
  %cmp3036 = icmp ult i64 %v3035, 32
  %cv3037 = zext i1 %cmp3036 to i32
  store i32 %cv3037, ptr %slot573, align 8
  %v3038 = load i32, ptr %slot573, align 8
  %cv3039 = zext i32 %v3038 to i64
  %cond3040 = icmp ne i64 %cv3039, 0
  br i1 %cond3040, label %bb_rcs787, label %bb_rcsendslow764
bb_rcs787:
  %v3041 = load i64, ptr %slot566, align 8
  %op3042 = add i64 %v3041, 8
  store i64 %op3042, ptr %slot574, align 8
  %v3043 = load i64, ptr %slot574, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %ld3045 = load i64, ptr %p3044, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3045, ptr %slot575, align 8
  %v3046 = load i64, ptr %slot575, align 8
  %cmp3047 = icmp ne i64 %v3046, 0
  %cv3048 = zext i1 %cmp3047 to i32
  store i32 %cv3048, ptr %slot576, align 8
  %v3049 = load i32, ptr %slot576, align 8
  %cv3050 = zext i32 %v3049 to i64
  %cond3051 = icmp ne i64 %cv3050, 0
  br i1 %cond3051, label %bb_rcs791, label %bb_rcsendslow764
bb_rcs791:
  %v3052 = load i64, ptr %slot575, align 8
  %op3053 = sub i64 %v3052, 16
  store i64 %op3053, ptr %slot577, align 8
  %v3054 = load i64, ptr %slot575, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  %rgep3056 = getelementptr i8, ptr %p3055, i64 -16
  %ld3057 = load i64, ptr %rgep3056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3057, ptr %slot578, align 8
  %v3058 = load i64, ptr %slot578, align 8
  %op3059 = and i64 %v3058, 4611686018427387907
  store i64 %op3059, ptr %slot579, align 8
  %v3060 = load i64, ptr %slot579, align 8
  %cmp3061 = icmp eq i64 %v3060, 0
  %cv3062 = zext i1 %cmp3061 to i32
  store i32 %cv3062, ptr %slot580, align 8
  %v3063 = load i32, ptr %slot580, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcs796, label %bb_rcsendslow764
bb_rcs796:
  %v3066 = load i64, ptr %slot575, align 8
  %op3067 = sub i64 %v3066, 24
  store i64 %op3067, ptr %slot581, align 8
  %v3068 = load i64, ptr %slot575, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -24
  %ld3071 = load i64, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3071, ptr %slot582, align 8
  %v3072 = load i64, ptr %slot582, align 8
  %cmp3073 = icmp ne i64 %v3072, 0
  %cv3074 = zext i1 %cmp3073 to i32
  store i32 %cv3074, ptr %slot583, align 8
  %v3075 = load i32, ptr %slot583, align 8
  %cv3076 = zext i32 %v3075 to i64
  %cond3077 = icmp ne i64 %cv3076, 0
  br i1 %cond3077, label %bb_rcs800, label %bb_rcsendslow764
bb_rcs800:
  %v3078 = load i64, ptr %slot575, align 8
  %op3079 = sub i64 %v3078, 32
  store i64 %op3079, ptr %slot584, align 8
  %v3080 = load i64, ptr %slot575, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %rgep3082 = getelementptr i8, ptr %p3081, i64 -32
  %ld3083 = load i64, ptr %rgep3082, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3083, ptr %slot585, align 8
  %v3084 = load i64, ptr %slot582, align 8
  %cmp3085 = icmp ugt i64 %v3084, 1
  %cv3086 = zext i1 %cmp3085 to i32
  store i32 %cv3086, ptr %slot586, align 8
  %v3087 = load i64, ptr %slot585, align 8
  %cmp3088 = icmp ne i64 %v3087, 0
  %cv3089 = zext i1 %cmp3088 to i32
  store i32 %cv3089, ptr %slot587, align 8
  %v3090 = load i32, ptr %slot586, align 8
  %v3091 = load i32, ptr %slot587, align 8
  %op3092 = or i32 %v3090, %v3091
  store i32 %op3092, ptr %slot588, align 8
  %v3093 = load i32, ptr %slot588, align 8
  %cv3094 = zext i32 %v3093 to i64
  %cond3095 = icmp ne i64 %cv3094, 0
  br i1 %cond3095, label %bb_rcs806, label %bb_rcsendslow764
bb_rcs806:
  %v3096 = load i64, ptr %slot566, align 8
  %op3097 = add i64 %v3096, 32
  store i64 %op3097, ptr %slot589, align 8
  %v3098 = load i64, ptr %slot589, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  %ld3100 = load i64, ptr %p3099, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3100, ptr %slot590, align 8
  %v3101 = load i64, ptr %slot590, align 8
  %cmp3102 = icmp ne i64 %v3101, 0
  %cv3103 = zext i1 %cmp3102 to i32
  store i32 %cv3103, ptr %slot591, align 8
  %v3104 = load i32, ptr %slot591, align 8
  %cv3105 = zext i32 %v3104 to i64
  %cond3106 = icmp ne i64 %cv3105, 0
  br i1 %cond3106, label %bb_rcsendbacking764, label %bb_rcsendcommit764
bb_rcsendbacking764:
  %v3107 = load i64, ptr %slot590, align 8
  %op3108 = sub i64 %v3107, 16
  store i64 %op3108, ptr %slot592, align 8
  %v3109 = load i64, ptr %slot590, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %rgep3111 = getelementptr i8, ptr %p3110, i64 -16
  %ld3112 = load i64, ptr %rgep3111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3112, ptr %slot593, align 8
  %v3113 = load i64, ptr %slot593, align 8
  %op3114 = and i64 %v3113, 4611686018427387907
  store i64 %op3114, ptr %slot594, align 8
  %v3115 = load i64, ptr %slot594, align 8
  %cmp3116 = icmp eq i64 %v3115, 0
  %cv3117 = zext i1 %cmp3116 to i32
  store i32 %cv3117, ptr %slot595, align 8
  %v3118 = load i32, ptr %slot595, align 8
  %cv3119 = zext i32 %v3118 to i64
  %cond3120 = icmp ne i64 %cv3119, 0
  br i1 %cond3120, label %bb_rcs814, label %bb_rcsendslow764
bb_rcs814:
  %v3121 = load i64, ptr %slot590, align 8
  %op3122 = sub i64 %v3121, 24
  store i64 %op3122, ptr %slot596, align 8
  %v3123 = load i64, ptr %slot590, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  %rgep3125 = getelementptr i8, ptr %p3124, i64 -24
  %ld3126 = load i64, ptr %rgep3125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3126, ptr %slot597, align 8
  %v3127 = load i64, ptr %slot597, align 8
  %cmp3128 = icmp ne i64 %v3127, 0
  %cv3129 = zext i1 %cmp3128 to i32
  store i32 %cv3129, ptr %slot598, align 8
  %v3130 = load i32, ptr %slot598, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcs818, label %bb_rcsendslow764
bb_rcs818:
  %v3133 = load i64, ptr %slot590, align 8
  %op3134 = sub i64 %v3133, 32
  store i64 %op3134, ptr %slot599, align 8
  %v3135 = load i64, ptr %slot590, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %rgep3137 = getelementptr i8, ptr %p3136, i64 -32
  %ld3138 = load i64, ptr %rgep3137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3138, ptr %slot600, align 8
  %v3139 = load i64, ptr %slot597, align 8
  %cmp3140 = icmp ugt i64 %v3139, 1
  %cv3141 = zext i1 %cmp3140 to i32
  store i32 %cv3141, ptr %slot601, align 8
  %v3142 = load i64, ptr %slot600, align 8
  %cmp3143 = icmp ne i64 %v3142, 0
  %cv3144 = zext i1 %cmp3143 to i32
  store i32 %cv3144, ptr %slot602, align 8
  %v3145 = load i32, ptr %slot601, align 8
  %v3146 = load i32, ptr %slot602, align 8
  %op3147 = or i32 %v3145, %v3146
  store i32 %op3147, ptr %slot603, align 8
  %v3148 = load i32, ptr %slot603, align 8
  %cv3149 = zext i32 %v3148 to i64
  %cond3150 = icmp ne i64 %cv3149, 0
  br i1 %cond3150, label %bb_rcs824, label %bb_rcsendslow764
bb_rcs824:
  br label %bb_rcsendcommit764
bb_rcsendcommit764:
  %v3151 = load i64, ptr %slot566, align 8
  %op3152 = add i64 %v3151, 24
  store i64 %op3152, ptr %slot604, align 8
  %v3153 = load i64, ptr %slot604, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %ld3155 = load i32, ptr %p3154, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld3155, ptr %slot605, align 8
  %v3156 = load i32, ptr %slot605, align 8
  %cv3157 = zext i32 %v3156 to i64
  %cond3158 = icmp ne i64 %cv3157, 0
  br i1 %cond3158, label %bb_rcsendrestore764, label %bb_rcsendreturned764
bb_rcsendrestore764:
  %v3159 = load i64, ptr %slot566, align 8
  %op3160 = add i64 %v3159, 16
  store i64 %op3160, ptr %slot606, align 8
  %v3161 = load i64, ptr %slot606, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  %ld3163 = load i64, ptr %p3162, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3163, ptr %slot607, align 8
  %v3164 = load i64, ptr %slot578, align 8
  %op3165 = and i64 %v3164, 17293822569102704639
  store i64 %op3165, ptr %slot608, align 8
  %v3166 = load i64, ptr %slot608, align 8
  %v3167 = load i64, ptr %slot607, align 8
  %op3168 = or i64 %v3166, %v3167
  store i64 %op3168, ptr %slot609, align 8
  %v3169 = load i64, ptr %slot575, align 8
  %op3170 = sub i64 %v3169, 16
  store i64 %op3170, ptr %slot610, align 8
  %v3171 = load i64, ptr %slot609, align 8
  %v3172 = load i64, ptr %slot575, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %rgep3174 = getelementptr i8, ptr %p3173, i64 -16
  store i64 %v3171, ptr %rgep3174, align 8, !alias.scope !9, !noalias !10
  %v3175 = load i64, ptr %slot554, align 8
  %p3177 = inttoptr i64 %v3175 to ptr
  %gep3178 = getelementptr i8, ptr %p3177, i64 16
  %op3176 = ptrtoint ptr %gep3178 to i64
  store i64 %op3176, ptr %slot611, align 8
  br label %bb_rcsendreturned764
bb_rcsendreturned764:
  %v3179 = load i64, ptr %slot611, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  store i64 0, ptr %p3180, align 8, !alias.scope !3, !noalias !4
  %v3181 = load i64, ptr %slot558, align 8
  %op3182 = add i64 %v3181, 256
  store i64 %op3182, ptr %slot612, align 8
  %v3183 = load i64, ptr %slot612, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %ld3185 = load i64, ptr %p3184, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3185, ptr %slot613, align 8
  %v3186 = load i64, ptr %slot566, align 8
  %op3187 = add i64 %v3186, 0
  store i64 %op3187, ptr %slot614, align 8
  %v3188 = load i64, ptr %slot613, align 8
  %v3189 = load i64, ptr %slot614, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 %v3188, ptr %p3190, align 8, !alias.scope !9999998, !noalias !9999999
  %v3191 = load i64, ptr %slot558, align 8
  %op3192 = add i64 %v3191, 256
  store i64 %op3192, ptr %slot615, align 8
  %v3193 = load i64, ptr %slot566, align 8
  %v3194 = load i64, ptr %slot615, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  store i64 %v3193, ptr %p3195, align 8, !alias.scope !9999998, !noalias !9999999
  %v3196 = load i64, ptr %slot558, align 8
  %op3197 = add i64 %v3196, 264
  store i64 %op3197, ptr %slot616, align 8
  %v3198 = load i64, ptr %slot616, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  %ld3200 = load i64, ptr %p3199, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3200, ptr %slot617, align 8
  %v3201 = load i64, ptr %slot617, align 8
  %op3202 = add i64 %v3201, 1
  store i64 %op3202, ptr %slot618, align 8
  %v3203 = load i64, ptr %slot618, align 8
  %v3204 = load i64, ptr %slot616, align 8
  %p3205 = inttoptr i64 %v3204 to ptr
  store i64 %v3203, ptr %p3205, align 8, !alias.scope !9999998, !noalias !9999999
  %v3206 = load i64, ptr %slot31, align 8
  %p3208 = inttoptr i64 %v3206 to ptr
  %gep3209 = getelementptr i8, ptr %p3208, i64 24
  %op3207 = ptrtoint ptr %gep3209 to i64
  store i64 %op3207, ptr %slot619, align 8
  %v3210 = load i64, ptr %slot619, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  %ld3212 = load i64, ptr %p3211, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3212, ptr %slot620, align 8
  %v3213 = load i64, ptr %slot620, align 8
  %op3214 = add i64 %v3213, 18446744073709551576
  store i64 %op3214, ptr %slot621, align 8
  %v3215 = load i64, ptr %slot621, align 8
  %v3216 = load i64, ptr %slot619, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i64 %v3215, ptr %p3217, align 8, !alias.scope !9999998, !noalias !9999999
  %v3218 = load i64, ptr %slot558, align 8
  %op3219 = add i64 %v3218, 48
  store i64 %op3219, ptr %slot622, align 8
  %v3220 = load i64, ptr %slot622, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %ld3222 = load i64, ptr %p3221, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3222, ptr %slot623, align 8
  %v3223 = load i64, ptr %slot623, align 8
  %op3224 = add i64 %v3223, 18446744073709551576
  store i64 %op3224, ptr %slot624, align 8
  %v3225 = load i64, ptr %slot624, align 8
  %v3226 = load i64, ptr %slot622, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  store i64 %v3225, ptr %p3227, align 8, !alias.scope !9999998, !noalias !9999999
  %v3228 = load i64, ptr %slot590, align 8
  %cmp3229 = icmp ne i64 %v3228, 0
  %cv3230 = zext i1 %cmp3229 to i32
  store i32 %cv3230, ptr %slot625, align 8
  %v3231 = load i32, ptr %slot625, align 8
  %cv3232 = zext i32 %v3231 to i64
  %cond3233 = icmp ne i64 %cv3232, 0
  br i1 %cond3233, label %bb_rcsenddropbacking764, label %bb_rcsenddroppayload764
bb_rcsenddropbacking764:
  %v3234 = load i64, ptr %slot590, align 8
  %op3235 = sub i64 %v3234, 24
  store i64 %op3235, ptr %slot626, align 8
  %v3236 = load i64, ptr %slot590, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %rgep3238 = getelementptr i8, ptr %p3237, i64 -24
  %ld3239 = load i64, ptr %rgep3238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3239, ptr %slot627, align 8
  %v3240 = load i64, ptr %slot627, align 8
  %op3241 = add i64 %v3240, 18446744073709551615
  store i64 %op3241, ptr %slot628, align 8
  %v3242 = load i64, ptr %slot628, align 8
  %v3243 = load i64, ptr %slot590, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %rgep3245 = getelementptr i8, ptr %p3244, i64 -24
  store i64 %v3242, ptr %rgep3245, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload764
bb_rcsenddroppayload764:
  %v3246 = load i64, ptr %slot575, align 8
  %op3247 = sub i64 %v3246, 24
  store i64 %op3247, ptr %slot629, align 8
  %v3248 = load i64, ptr %slot575, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %rgep3250 = getelementptr i8, ptr %p3249, i64 -24
  %ld3251 = load i64, ptr %rgep3250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3251, ptr %slot630, align 8
  %v3252 = load i64, ptr %slot630, align 8
  %op3253 = add i64 %v3252, 18446744073709551615
  store i64 %op3253, ptr %slot631, align 8
  %v3254 = load i64, ptr %slot631, align 8
  %v3255 = load i64, ptr %slot575, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %rgep3257 = getelementptr i8, ptr %p3256, i64 -24
  store i64 %v3254, ptr %rgep3257, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink764
bb_rcsendunlink764:
  %v3258 = load i64, ptr %slot554, align 8
  %p3260 = inttoptr i64 %v3258 to ptr
  %gep3261 = getelementptr i8, ptr %p3260, i64 8
  %op3259 = ptrtoint ptr %gep3261 to i64
  store i64 %op3259, ptr %slot632, align 8
  %v3262 = load i64, ptr %slot632, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %ld3264 = load i64, ptr %p3263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3264, ptr %slot633, align 8
  %v3265 = load i64, ptr %slot558, align 8
  %op3266 = add i64 %v3265, 248
  store i64 %op3266, ptr %slot634, align 8
  %v3267 = load i64, ptr %slot633, align 8
  %v3268 = load i64, ptr %slot634, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i64 %v3267, ptr %p3269, align 8, !alias.scope !9999998, !noalias !9999999
  %v3270 = load i64, ptr %slot554, align 8
  %p3272 = inttoptr i64 %v3270 to ptr
  %gep3273 = getelementptr i8, ptr %p3272, i64 24
  %op3271 = ptrtoint ptr %gep3273 to i64
  store i64 %op3271, ptr %slot635, align 8
  %v3274 = load i64, ptr %slot554, align 8
  %p3276 = inttoptr i64 %v3274 to ptr
  %gep3277 = getelementptr i8, ptr %p3276, i64 8
  %op3275 = ptrtoint ptr %gep3277 to i64
  store i64 %op3275, ptr %slot636, align 8
  %v3278 = load i64, ptr %slot635, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i32 0, ptr %p3279, align 4, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot636, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i64 0, ptr %p3281, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone764
bb_rcsendslow764:
  %v3282 = load i64, ptr %slot1, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %v3284 = load i64, ptr %slot554, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p3283, ptr %p3285) nomerge, !dbg !130
  br label %bb_rcsenddone764
bb_rcsenddone764:
  %v3286 = load i64, ptr %slot21, align 8
  %v3287 = load i64, ptr %slot24, align 8
  %p3288 = inttoptr i64 %v3286 to ptr
  %p3289 = inttoptr i64 %v3287 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3289, ptr %p3288, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot24, align 8
  %v3291 = load i64, ptr %slot23, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i64 %v3290, ptr %p3292, align 8, !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot23, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %ld3295 = load i64, ptr %p3294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3295, ptr %slot637, align 8
  %v3296 = load i64, ptr %slot23, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %ld3298 = load i64, ptr %p3297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3298, ptr %slot638, align 8
  %v3299 = load i64, ptr %slot7, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i32, ptr %p3300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3301, ptr %slot639, align 8
  %v3302 = load i64, ptr %slot8, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %ld3304 = load i32, ptr %p3303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3304, ptr %slot640, align 8
  %v3305 = load i32, ptr %slot640, align 8
  %op3306 = and i32 %v3305, 24
  store i32 %op3306, ptr %slot640, align 8
  %v3307 = load i32, ptr %slot640, align 8
  %cmp3308 = icmp eq i32 %v3307, 0
  %cv3309 = zext i1 %cmp3308 to i32
  store i32 %cv3309, ptr %slot641, align 8
  %v3310 = load i32, ptr %slot639, align 8
  %v3311 = load i32, ptr %slot641, align 8
  %op3312 = and i32 %v3310, %v3311
  store i32 %op3312, ptr %slot642, align 8
  %v3313 = load i32, ptr %slot642, align 8
  %cv3314 = zext i32 %v3313 to i64
  %cond3315 = icmp ne i64 %cv3314, 0
  br i1 %cond3315, label %bb_rctake860, label %bb_rccopy860
bb_rctake860:
  %v3316 = load i64, ptr %slot13, align 8
  store i64 %v3316, ptr %slot643, align 8
  %v3317 = load i64, ptr %slot32, align 8
  store i64 %v3317, ptr %slot644, align 8
  %v3318 = load i64, ptr %slot31, align 8
  %v3319 = load i64, ptr %slot643, align 8
  %v3320 = load i64, ptr %slot638, align 8
  %v3321 = load i64, ptr %slot644, align 8
  %cv3322 = trunc i64 %v3321 to i32
  %call3323 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3318, i64 %v3319, i64 %v3320, i32 %cv3322) nomerge, !dbg !132
  store i32 %call3323, ptr %slot645, align 8
  %v3324 = load i32, ptr %slot645, align 8
  %cv3325 = zext i32 %v3324 to i64
  %cond3326 = icmp ne i64 %cv3325, 0
  br i1 %cond3326, label %bb_rcsuccess870, label %bb_rcfailure870
bb_rcfailure870:
  %v3327 = load i64, ptr %slot31, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  %call3329 = call i32 @myl_rc_take_failure(ptr %p3328) nomerge, !dbg !132
  store i32 %call3329, ptr %slot646, align 8
  %v3330 = load i64, ptr %slot1, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %v3332 = load i32, ptr %slot646, align 8
  %call3333 = call i32 @myl_qbe_rc_status(ptr %p3331, i32 %v3332) nomerge, !dbg !132
  store i32 %call3333, ptr %slot647, align 8
  br label %bb_failure
bb_rcsuccess870:
  %v3334 = load i64, ptr %slot7, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  store i32 0, ptr %p3335, align 4, !alias.scope !3, !noalias !4
  %v3336 = load i64, ptr %slot10, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  store i32 2, ptr %p3337, align 4, !alias.scope !3, !noalias !4
  %v3338 = load i64, ptr %slot9, align 8
  %p3339 = inttoptr i64 %v3338 to ptr
  store i32 1, ptr %p3339, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared860
bb_rccopy860:
  %v3340 = load i64, ptr %slot13, align 8
  store i64 %v3340, ptr %slot648, align 8
  %v3341 = load i64, ptr %slot32, align 8
  store i64 %v3341, ptr %slot649, align 8
  %v3342 = load i64, ptr %slot31, align 8
  %v3343 = load i64, ptr %slot648, align 8
  %v3344 = load i64, ptr %slot638, align 8
  %v3345 = load i64, ptr %slot649, align 8
  %cv3346 = trunc i64 %v3345 to i32
  %call3347 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v3342, i64 %v3343, i64 %v3344, i32 %cv3346) nomerge, !dbg !132
  store i32 %call3347, ptr %slot650, align 8
  %v3348 = load i32, ptr %slot650, align 8
  %cv3349 = zext i32 %v3348 to i64
  %cond3350 = icmp ne i64 %cv3349, 0
  br i1 %cond3350, label %bb_rcsuccess879, label %bb_rcfailure879
bb_rcfailure879:
  %v3351 = load i64, ptr %slot31, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %call3353 = call i32 @myl_rc_take_failure(ptr %p3352) nomerge, !dbg !132
  store i32 %call3353, ptr %slot651, align 8
  %v3354 = load i64, ptr %slot1, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  %v3356 = load i32, ptr %slot651, align 8
  %call3357 = call i32 @myl_qbe_rc_status(ptr %p3355, i32 %v3356) nomerge, !dbg !132
  store i32 %call3357, ptr %slot652, align 8
  br label %bb_failure
bb_rcsuccess879:
  %v3358 = load i64, ptr %slot10, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  store i32 2, ptr %p3359, align 4, !alias.scope !3, !noalias !4
  %v3360 = load i64, ptr %slot9, align 8
  %p3361 = inttoptr i64 %v3360 to ptr
  store i32 1, ptr %p3361, align 4, !alias.scope !3, !noalias !4
  %v3362 = load i64, ptr %slot7, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %ld3364 = load i32, ptr %p3363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3364, ptr %slot653, align 8
  %v3365 = load i32, ptr %slot653, align 8
  %cv3366 = zext i32 %v3365 to i64
  %cond3367 = icmp ne i64 %cv3366, 0
  br i1 %cond3367, label %bb_rcslotdrop886, label %bb_rcslotdone886
bb_rcslotdrop886:
  %v3368 = load i64, ptr %slot7, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  store i32 0, ptr %p3369, align 4, !alias.scope !3, !noalias !4
  %v3370 = load i64, ptr %slot11, align 8
  store i64 %v3370, ptr %slot654, align 8
  %v3371 = load i64, ptr %slot8, align 8
  %p3372 = inttoptr i64 %v3371 to ptr
  %ld3373 = load i32, ptr %p3372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3373, ptr %slot655, align 8
  %v3374 = load i32, ptr %slot655, align 8
  %op3375 = and i32 %v3374, 28
  store i32 %op3375, ptr %slot656, align 8
  %v3376 = load i32, ptr %slot656, align 8
  %cv3377 = zext i32 %v3376 to i64
  %cond3378 = icmp ne i64 %cv3377, 0
  br i1 %cond3378, label %bb_rcslotrole886, label %bb_rcslotowner886
bb_rcslotrole886:
  %v3379 = load i64, ptr %slot31, align 8
  store i64 %v3379, ptr %slot657, align 8
  %v3380 = load i64, ptr %slot657, align 8
  %v3381 = load i64, ptr %slot654, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3380, i64 %v3381) nomerge, !dbg !132
  br label %bb_rcslotdone886
bb_rcslotowner886:
  %v3382 = load i64, ptr %slot31, align 8
  store i64 %v3382, ptr %slot658, align 8
  %v3383 = load i64, ptr %slot658, align 8
  %v3384 = load i64, ptr %slot654, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3383, i64 %v3384) nomerge, !dbg !132
  br label %bb_rcslotdone886
bb_rcslotdone886:
  br label %bb_rcprepared860
bb_rcprepared860:
  %v3385 = load i64, ptr %slot13, align 8
  store i64 %v3385, ptr %slot659, align 8
  %v3386 = load i64, ptr %slot9, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  store i32 0, ptr %p3387, align 4, !alias.scope !3, !noalias !4
  %v3388 = load i64, ptr %slot14, align 8
  %p3390 = inttoptr i64 %v3388 to ptr
  %gep3391 = getelementptr i8, ptr %p3390, i64 24
  %op3389 = ptrtoint ptr %gep3391 to i64
  store i64 %op3389, ptr %slot660, align 8
  %v3392 = load i64, ptr %slot660, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %ld3394 = load i32, ptr %p3393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3394, ptr %slot661, align 8
  %v3395 = load i64, ptr %slot16, align 8
  %p3397 = inttoptr i64 %v3395 to ptr
  %gep3398 = getelementptr i8, ptr %p3397, i64 24
  %op3396 = ptrtoint ptr %gep3398 to i64
  store i64 %op3396, ptr %slot662, align 8
  %v3399 = load i64, ptr %slot662, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %ld3401 = load i32, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3401, ptr %slot663, align 8
  %v3402 = load i32, ptr %slot661, align 8
  %v3403 = load i32, ptr %slot663, align 8
  %op3404 = or i32 %v3402, %v3403
  store i32 %op3404, ptr %slot664, align 8
  %v3405 = load i32, ptr %slot664, align 8
  %cv3406 = zext i32 %v3405 to i64
  %cond3407 = icmp ne i64 %cv3406, 0
  br i1 %cond3407, label %bb_rcscopesopen900, label %bb_rcscopesclosed900
bb_rcscopesopen900:
  %v3408 = load i64, ptr %slot18, align 8
  %p3410 = inttoptr i64 %v3408 to ptr
  %gep3411 = getelementptr i8, ptr %p3410, i64 0
  %op3409 = ptrtoint ptr %gep3411 to i64
  store i64 %op3409, ptr %slot665, align 8
  %v3412 = load i64, ptr %slot14, align 8
  %v3413 = load i64, ptr %slot665, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i64 %v3412, ptr %p3414, align 8, !alias.scope !3, !noalias !4
  %v3415 = load i64, ptr %slot18, align 8
  %p3417 = inttoptr i64 %v3415 to ptr
  %gep3418 = getelementptr i8, ptr %p3417, i64 8
  %op3416 = ptrtoint ptr %gep3418 to i64
  store i64 %op3416, ptr %slot666, align 8
  %v3419 = load i64, ptr %slot16, align 8
  %v3420 = load i64, ptr %slot666, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  store i64 %v3419, ptr %p3421, align 8, !alias.scope !3, !noalias !4
  %v3422 = load i64, ptr %slot1, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  %v3424 = load i64, ptr %slot18, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p3423, ptr %p3425, i64 2) nomerge, !dbg !132
  br label %bb_rcscopesclosed900
bb_rcscopesclosed900:
  %v3426 = load i64, ptr %slot7, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %ld3428 = load i32, ptr %p3427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3428, ptr %slot667, align 8
  %v3429 = load i32, ptr %slot667, align 8
  %cv3430 = zext i32 %v3429 to i64
  %cond3431 = icmp ne i64 %cv3430, 0
  br i1 %cond3431, label %bb_rcslotdrop905, label %bb_rcslotdone905
bb_rcslotdrop905:
  %v3432 = load i64, ptr %slot7, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  store i32 0, ptr %p3433, align 4, !alias.scope !3, !noalias !4
  %v3434 = load i64, ptr %slot11, align 8
  store i64 %v3434, ptr %slot668, align 8
  %v3435 = load i64, ptr %slot8, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %ld3437 = load i32, ptr %p3436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3437, ptr %slot669, align 8
  %v3438 = load i32, ptr %slot669, align 8
  %op3439 = and i32 %v3438, 28
  store i32 %op3439, ptr %slot670, align 8
  %v3440 = load i32, ptr %slot670, align 8
  %cv3441 = zext i32 %v3440 to i64
  %cond3442 = icmp ne i64 %cv3441, 0
  br i1 %cond3442, label %bb_rcslotrole905, label %bb_rcslotowner905
bb_rcslotrole905:
  %v3443 = load i64, ptr %slot31, align 8
  store i64 %v3443, ptr %slot671, align 8
  %v3444 = load i64, ptr %slot671, align 8
  %v3445 = load i64, ptr %slot668, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3444, i64 %v3445) nomerge, !dbg !132
  br label %bb_rcslotdone905
bb_rcslotowner905:
  %v3446 = load i64, ptr %slot31, align 8
  store i64 %v3446, ptr %slot672, align 8
  %v3447 = load i64, ptr %slot672, align 8
  %v3448 = load i64, ptr %slot668, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3447, i64 %v3448) nomerge, !dbg !132
  br label %bb_rcslotdone905
bb_rcslotdone905:
  %v3449 = load i64, ptr %slot5, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %ld3451 = load i32, ptr %p3450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3451, ptr %slot673, align 8
  %v3452 = load i32, ptr %slot673, align 8
  %cv3453 = zext i32 %v3452 to i64
  %cond3454 = icmp ne i64 %cv3453, 0
  br i1 %cond3454, label %bb_rcslotdrop951, label %bb_rcslotdone951
bb_rcslotdrop951:
  %v3455 = load i64, ptr %slot5, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i32 0, ptr %p3456, align 4, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot21, align 8
  store i64 %v3457, ptr %slot674, align 8
  %v3458 = load i64, ptr %slot6, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %ld3460 = load i32, ptr %p3459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3460, ptr %slot675, align 8
  %v3461 = load i32, ptr %slot675, align 8
  %op3462 = and i32 %v3461, 28
  store i32 %op3462, ptr %slot676, align 8
  %v3463 = load i32, ptr %slot676, align 8
  %cv3464 = zext i32 %v3463 to i64
  %cond3465 = icmp ne i64 %cv3464, 0
  br i1 %cond3465, label %bb_rcslotrole951, label %bb_rcslotowner951
bb_rcslotrole951:
  %v3466 = load i64, ptr %slot31, align 8
  store i64 %v3466, ptr %slot677, align 8
  %v3467 = load i64, ptr %slot677, align 8
  %v3468 = load i64, ptr %slot674, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3467, i64 %v3468) nomerge, !dbg !132
  br label %bb_rcslotdone951
bb_rcslotowner951:
  %v3469 = load i64, ptr %slot31, align 8
  store i64 %v3469, ptr %slot678, align 8
  %v3470 = load i64, ptr %slot678, align 8
  %v3471 = load i64, ptr %slot674, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3470, i64 %v3471) nomerge, !dbg !132
  br label %bb_rcslotdone951
bb_rcslotdone951:
  %v3472 = load i64, ptr %slot659, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3473, i64 88, i1 false)
  ret void
bb_failure:
  %v3474 = load i64, ptr %slot4, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  call void @llvm.memset.p0.i64(ptr %p3475, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v3476 = load i64, ptr %slot4, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3477, i64 88, i1 false)
  ret void
bb_entry_failure:
  %v3478 = load i64, ptr %slot4, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  call void @llvm.memset.p0.i64(ptr %p3479, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v3480 = load i64, ptr %slot4, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3481, i64 88, i1 false)
  ret void
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_pop_bounds(ptr, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_pop(ptr, ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f", linkageName: "myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3061188912194514936, i64 0, !"myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!122 = !DILocation(line: 8, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!124 = !DILocation(line: 10, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!126 = !DILocation(line: 11, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!128 = !DILocation(line: 12, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!130 = !DILocation(line: 13, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!132 = !DILocation(line: 17, column: 0, scope: !133)
