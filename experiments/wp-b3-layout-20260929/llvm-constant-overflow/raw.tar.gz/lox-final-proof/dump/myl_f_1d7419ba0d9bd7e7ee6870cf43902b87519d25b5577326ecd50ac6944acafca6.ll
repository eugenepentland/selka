target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1d7419ba0d9bd7e7ee6870cf43902b87519d25b5577326ecd50ac6944acafca6(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %callresult50 = alloca [24 x i8], align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v655 = load i64, ptr %slot1, align 8
  %op656 = add i64 %v655, 32
  store i64 %op656, ptr %slot5, align 8
  %mem657 = alloca i8, i64 8, align 8
  %ptr658 = ptrtoint ptr %mem657 to i64
  store i64 %ptr658, ptr %slot6, align 8
  %mem659 = alloca i8, i64 8, align 8
  %ptr660 = ptrtoint ptr %mem659 to i64
  store i64 %ptr660, ptr %slot7, align 8
  %mem661 = alloca i8, i64 8, align 8
  %ptr662 = ptrtoint ptr %mem661 to i64
  store i64 %ptr662, ptr %slot8, align 8
  %mem663 = alloca i8, i64 8, align 8
  %ptr664 = ptrtoint ptr %mem663 to i64
  store i64 %ptr664, ptr %slot9, align 8
  %mem665 = alloca i8, i64 8, align 8
  %ptr666 = ptrtoint ptr %mem665 to i64
  store i64 %ptr666, ptr %slot10, align 8
  %mem667 = alloca i8, i64 8, align 8
  %ptr668 = ptrtoint ptr %mem667 to i64
  store i64 %ptr668, ptr %slot11, align 8
  %mem669 = alloca i8, i64 8, align 8
  %ptr670 = ptrtoint ptr %mem669 to i64
  store i64 %ptr670, ptr %slot12, align 8
  %mem671 = alloca i8, i64 8, align 8
  %ptr672 = ptrtoint ptr %mem671 to i64
  store i64 %ptr672, ptr %slot13, align 8
  %mem673 = alloca i8, i64 8, align 8
  %ptr674 = ptrtoint ptr %mem673 to i64
  store i64 %ptr674, ptr %slot14, align 8
  %mem675 = alloca i8, i64 8, align 8
  %ptr676 = ptrtoint ptr %mem675 to i64
  store i64 %ptr676, ptr %slot15, align 8
  %mem677 = alloca i8, i64 8, align 8
  %ptr678 = ptrtoint ptr %mem677 to i64
  store i64 %ptr678, ptr %slot16, align 8
  %mem679 = alloca i8, i64 8, align 8
  %ptr680 = ptrtoint ptr %mem679 to i64
  store i64 %ptr680, ptr %slot17, align 8
  %mem681 = alloca i8, i64 8, align 8
  %ptr682 = ptrtoint ptr %mem681 to i64
  store i64 %ptr682, ptr %slot18, align 8
  %mem683 = alloca i8, i64 208, align 8
  %ptr684 = ptrtoint ptr %mem683 to i64
  store i64 %ptr684, ptr %slot19, align 8
  %mem685 = alloca i8, i64 56, align 8
  %ptr686 = ptrtoint ptr %mem685 to i64
  store i64 %ptr686, ptr %slot20, align 8
  %mem687 = alloca i8, i64 208, align 8
  %ptr688 = ptrtoint ptr %mem687 to i64
  store i64 %ptr688, ptr %slot21, align 8
  %mem689 = alloca i8, i64 32, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot22, align 8
  %v691 = load i64, ptr %slot22, align 8
  %p693 = inttoptr i64 %v691 to ptr
  %gep694 = getelementptr i8, ptr %p693, i64 24
  %op692 = ptrtoint ptr %gep694 to i64
  store i64 %op692, ptr %slot23, align 8
  %v695 = load i64, ptr %slot23, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 0, ptr %p696, align 8, !alias.scope !3, !noalias !4
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot24, align 8
  %mem699 = alloca i8, i64 8, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot25, align 8
  %mem701 = alloca i8, i64 8, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot26, align 8
  %mem703 = alloca i8, i64 8, align 8
  %ptr704 = ptrtoint ptr %mem703 to i64
  store i64 %ptr704, ptr %slot27, align 8
  %mem705 = alloca i8, i64 24, align 8
  %ptr706 = ptrtoint ptr %mem705 to i64
  store i64 %ptr706, ptr %slot28, align 8
  %mem707 = alloca i8, i64 24, align 8
  %ptr708 = ptrtoint ptr %mem707 to i64
  store i64 %ptr708, ptr %slot29, align 8
  %mem709 = alloca i8, i64 16, align 8
  %ptr710 = ptrtoint ptr %mem709 to i64
  store i64 %ptr710, ptr %slot30, align 8
  %mem711 = alloca i8, i64 8, align 8
  %ptr712 = ptrtoint ptr %mem711 to i64
  store i64 %ptr712, ptr %slot31, align 8
  %mem713 = alloca i8, i64 56, align 8
  %ptr714 = ptrtoint ptr %mem713 to i64
  store i64 %ptr714, ptr %slot32, align 8
  %mem715 = alloca i8, i64 8, align 8
  %ptr716 = ptrtoint ptr %mem715 to i64
  store i64 %ptr716, ptr %slot33, align 8
  %mem717 = alloca i8, i64 8, align 8
  %ptr718 = ptrtoint ptr %mem717 to i64
  store i64 %ptr718, ptr %slot34, align 8
  %mem719 = alloca i8, i64 8, align 8
  %ptr720 = ptrtoint ptr %mem719 to i64
  store i64 %ptr720, ptr %slot35, align 8
  %mem721 = alloca i8, i64 24, align 8
  %ptr722 = ptrtoint ptr %mem721 to i64
  store i64 %ptr722, ptr %slot36, align 8
  %mem723 = alloca i8, i64 56, align 8
  %ptr724 = ptrtoint ptr %mem723 to i64
  store i64 %ptr724, ptr %slot37, align 8
  %mem725 = alloca i8, i64 56, align 8
  %ptr726 = ptrtoint ptr %mem725 to i64
  store i64 %ptr726, ptr %slot38, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem727 = alloca i8, i64 8, align 8
  %ptr728 = ptrtoint ptr %mem727 to i64
  store i64 %ptr728, ptr %slot39, align 8
  %v729 = load i64, ptr %slot1, align 8
  %op730 = add i64 %v729, 64
  store i64 %op730, ptr %slot40, align 8
  %v731 = load i64, ptr %slot40, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i64, ptr %p732, align 8, !alias.scope !4, !noalias !3
  store i64 %ld733, ptr %slot41, align 8
  %stack734 = call ptr @llvm.stacksave()
  %stackaddr735 = ptrtoint ptr %stack734 to i64
  %v736 = load i64, ptr %slot41, align 8
  %cmp737 = icmp ult i64 %stackaddr735, %v736
  %cv738 = zext i1 %cmp737 to i64
  store i64 %cv738, ptr %slot42, align 8
  %v739 = load i64, ptr %slot42, align 8
  %cond740 = icmp ne i64 %v739, 0
  br i1 %cond740, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v741 = load i64, ptr %slot1, align 8
  %p742 = inttoptr i64 %v741 to ptr
  call void @myl_qbe_fail_frame(ptr %p742) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v743 = load i64, ptr %slot31, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i64 0, ptr %p744, align 8, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot2, align 8
  %v746 = load i64, ptr %slot25, align 8
  %p747 = inttoptr i64 %v746 to ptr
  store i64 %v745, ptr %p747, align 8, !alias.scope !3, !noalias !4
  %v748 = load i64, ptr %slot3, align 8
  %v749 = load i64, ptr %slot26, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 %v748, ptr %p750, align 8, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot4, align 8
  %v752 = load i64, ptr %slot27, align 8
  %p753 = inttoptr i64 %v752 to ptr
  store i64 %v751, ptr %p753, align 8, !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot1, align 8
  %p755 = inttoptr i64 %v754 to ptr
  %call756 = call ptr @myl_qbe_heap(ptr %p755) nomerge, !dbg !112
  %calladdr757 = ptrtoint ptr %call756 to i64
  store i64 %calladdr757, ptr %slot43, align 8
  %v758 = load i64, ptr %slot1, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %call760 = call i64 @myl_qbe_region_mark(ptr %p759) nomerge, !dbg !112
  store i64 %call760, ptr %slot44, align 8
  %v761 = load i64, ptr %slot6, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i32 0, ptr %p762, align 4, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot7, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i32 0, ptr %p764, align 4, !alias.scope !3, !noalias !4
  %v765 = load i64, ptr %slot8, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i32 0, ptr %p766, align 4, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot9, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i32 0, ptr %p768, align 4, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot10, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i32 0, ptr %p770, align 4, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot11, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i32 0, ptr %p772, align 4, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot12, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 0, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot13, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 0, ptr %p776, align 4, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot14, align 8
  %p778 = inttoptr i64 %v777 to ptr
  store i32 0, ptr %p778, align 4, !alias.scope !3, !noalias !4
  %v779 = load i64, ptr %slot15, align 8
  %p780 = inttoptr i64 %v779 to ptr
  store i32 0, ptr %p780, align 4, !alias.scope !3, !noalias !4
  %v781 = load i64, ptr %slot16, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i32 0, ptr %p782, align 4, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot17, align 8
  %p784 = inttoptr i64 %v783 to ptr
  store i32 0, ptr %p784, align 4, !alias.scope !3, !noalias !4
  %v785 = load i64, ptr %slot18, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i32 0, ptr %p786, align 4, !alias.scope !3, !noalias !4
  %v787 = load i64, ptr %slot7, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i32 2, ptr %p788, align 4, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot9, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i32 2, ptr %p790, align 4, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot11, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i32 2, ptr %p792, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v793 = load i64, ptr %slot25, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i64, ptr %p794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld795, ptr %slot45, align 8
  %v796 = load i64, ptr %slot45, align 8
  %v797 = load i64, ptr %slot34, align 8
  %p798 = inttoptr i64 %v797 to ptr
  store i64 %v796, ptr %p798, align 8, !alias.scope !3, !noalias !4
  %v799 = load i64, ptr %slot26, align 8
  %p800 = inttoptr i64 %v799 to ptr
  %ld801 = load i64, ptr %p800, align 8, !alias.scope !3, !noalias !4
  store i64 %ld801, ptr %slot46, align 8
  %v802 = load i64, ptr %slot46, align 8
  %v803 = load i64, ptr %slot35, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 %v802, ptr %p804, align 8, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot34, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot47, align 8
  %v808 = load i64, ptr %slot35, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot48, align 8
  %v811 = load i64, ptr %slot1, align 8
  %v812 = load i64, ptr %slot47, align 8
  %v813 = load i64, ptr %slot48, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult50, i64 %v811, i64 %v812, i64 %v813) nomerge, !dbg !114
  %addr814 = ptrtoint ptr %callresult50 to i64
  store i64 %addr814, ptr %slot49, align 8
  %v815 = load i64, ptr %slot49, align 8
  %v816 = load i64, ptr %slot34, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot34, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot51, align 8
  %v821 = load i64, ptr %slot21, align 8
  store i64 %v821, ptr %slot52, align 8
  %v822 = load i64, ptr %slot51, align 8
  %v823 = load i64, ptr %slot52, align 8
  %p824 = inttoptr i64 %v822 to ptr
  %p825 = inttoptr i64 %v823 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p825, ptr %p824, i64 24, i1 false)
  %v826 = load i64, ptr %slot17, align 8
  %p827 = inttoptr i64 %v826 to ptr
  store i32 2, ptr %p827, align 4, !alias.scope !3, !noalias !4
  %v828 = load i64, ptr %slot16, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i32 1, ptr %p829, align 4, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot12, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i32, ptr %p831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld832, ptr %slot53, align 8
  %v833 = load i32, ptr %slot53, align 8
  %cv834 = zext i32 %v833 to i64
  %cond835 = icmp ne i64 %cv834, 0
  br i1 %cond835, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v836 = load i64, ptr %slot12, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i32 0, ptr %p837, align 4, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot19, align 8
  store i64 %v838, ptr %slot54, align 8
  %v839 = load i64, ptr %slot13, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i32, ptr %p840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld841, ptr %slot55, align 8
  %v842 = load i32, ptr %slot55, align 8
  %op843 = and i32 %v842, 28
  store i32 %op843, ptr %slot56, align 8
  %v844 = load i32, ptr %slot56, align 8
  %cv845 = zext i32 %v844 to i64
  %cond846 = icmp ne i64 %cv845, 0
  br i1 %cond846, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v847 = load i64, ptr %slot43, align 8
  store i64 %v847, ptr %slot57, align 8
  %v848 = load i64, ptr %slot57, align 8
  %v849 = load i64, ptr %slot54, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v848, i64 %v849) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v850 = load i64, ptr %slot43, align 8
  store i64 %v850, ptr %slot58, align 8
  %v851 = load i64, ptr %slot58, align 8
  %v852 = load i64, ptr %slot54, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v851, i64 %v852) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v853 = load i64, ptr %slot19, align 8
  store i64 %v853, ptr %slot59, align 8
  %v854 = load i64, ptr %slot21, align 8
  store i64 %v854, ptr %slot60, align 8
  %v855 = load i64, ptr %slot60, align 8
  %v856 = load i64, ptr %slot59, align 8
  %p857 = inttoptr i64 %v855 to ptr
  %p858 = inttoptr i64 %v856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p858, ptr %p857, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot13, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i32 2, ptr %p860, align 4, !alias.scope !3, !noalias !4
  %v861 = load i64, ptr %slot17, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i32, ptr %p862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld863, ptr %slot61, align 8
  %v864 = load i32, ptr %slot61, align 8
  %v865 = load i64, ptr %slot13, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i32 %v864, ptr %p866, align 4, !alias.scope !3, !noalias !4
  %v867 = load i64, ptr %slot16, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i32 0, ptr %p868, align 4, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot12, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i32 1, ptr %p870, align 4, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot59, align 8
  %v872 = load i64, ptr %slot34, align 8
  %p873 = inttoptr i64 %v872 to ptr
  store i64 %v871, ptr %p873, align 8, !alias.scope !3, !noalias !4
  %v874 = load i64, ptr %slot34, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %ld876 = load i64, ptr %p875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld876, ptr %slot62, align 8
  %v877 = load i64, ptr %slot21, align 8
  store i64 %v877, ptr %slot63, align 8
  %v878 = load i64, ptr %slot44, align 8
  store i64 %v878, ptr %slot64, align 8
  %v879 = load i64, ptr %slot62, align 8
  %op880 = add i64 %v879, 8
  store i64 %op880, ptr %slot65, align 8
  %v881 = load i64, ptr %slot65, align 8
  %p882 = inttoptr i64 %v881 to ptr
  %ld883 = load i64, ptr %p882, align 8, !alias.scope !3, !noalias !4
  store i64 %ld883, ptr %slot66, align 8
  %v884 = load i64, ptr %slot66, align 8
  %cmp885 = icmp ne i64 %v884, 0
  %cv886 = zext i1 %cmp885 to i32
  store i32 %cv886, ptr %slot67, align 8
  %v887 = load i32, ptr %slot67, align 8
  %cv888 = zext i32 %v887 to i64
  %cond889 = icmp ne i64 %cv888, 0
  br i1 %cond889, label %bb_rcmoveheader46, label %bb_rcmovenext46
bb_rcmoveheader46:
  %v890 = load i64, ptr %slot66, align 8
  %op891 = sub i64 %v890, 16
  store i64 %op891, ptr %slot68, align 8
  %v892 = load i64, ptr %slot66, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %rgep894 = getelementptr i8, ptr %p893, i64 -16
  %ld895 = load i64, ptr %rgep894, align 8, !alias.scope !9, !noalias !10
  store i64 %ld895, ptr %slot69, align 8
  %v896 = load i64, ptr %slot69, align 8
  %op897 = and i64 %v896, 5764607523034234881
  store i64 %op897, ptr %slot70, align 8
  %v898 = load i64, ptr %slot70, align 8
  %cmp899 = icmp ne i64 %v898, 0
  %cv900 = zext i1 %cmp899 to i32
  store i32 %cv900, ptr %slot71, align 8
  %v901 = load i32, ptr %slot71, align 8
  %cv902 = zext i32 %v901 to i64
  %cond903 = icmp ne i64 %cv902, 0
  br i1 %cond903, label %bb_rcmoveslow43, label %bb_rcmovenext46
bb_rcmovenext46:
  %v904 = load i64, ptr %slot62, align 8
  %v905 = load i64, ptr %slot63, align 8
  %p906 = inttoptr i64 %v904 to ptr
  %p907 = inttoptr i64 %v905 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p907, ptr %p906, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot62, align 8
  %p909 = inttoptr i64 %v908 to ptr
  store i64 0, ptr %p909, align 8, !alias.scope !3, !noalias !4
  %v910 = load i64, ptr %slot62, align 8
  %op911 = add i64 %v910, 8
  store i64 %op911, ptr %slot72, align 8
  %v912 = load i64, ptr %slot72, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i64 0, ptr %p913, align 8, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot62, align 8
  %op915 = add i64 %v914, 16
  store i64 %op915, ptr %slot73, align 8
  %v916 = load i64, ptr %slot73, align 8
  %p917 = inttoptr i64 %v916 to ptr
  store i64 0, ptr %p917, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved43
bb_rcmoveslow43:
  %v918 = load i64, ptr %slot43, align 8
  %v919 = load i64, ptr %slot63, align 8
  %v920 = load i64, ptr %slot62, align 8
  %v921 = load i64, ptr %slot64, align 8
  %cv922 = trunc i64 %v921 to i32
  %call923 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v918, i64 %v919, i64 %v920, i32 %cv922) nomerge, !dbg !116
  store i32 %call923, ptr %slot74, align 8
  %v924 = load i32, ptr %slot74, align 8
  %cv925 = zext i32 %v924 to i64
  %cond926 = icmp ne i64 %cv925, 0
  br i1 %cond926, label %bb_rcsuccess55, label %bb_rcfailure55
bb_rcfailure55:
  %v927 = load i64, ptr %slot43, align 8
  %p928 = inttoptr i64 %v927 to ptr
  %call929 = call i32 @myl_rc_take_failure(ptr %p928) nomerge, !dbg !116
  store i32 %call929, ptr %slot75, align 8
  %v930 = load i64, ptr %slot1, align 8
  %p931 = inttoptr i64 %v930 to ptr
  %v932 = load i32, ptr %slot75, align 8
  %call933 = call i32 @myl_qbe_rc_status(ptr %p931, i32 %v932) nomerge, !dbg !116
  store i32 %call933, ptr %slot76, align 8
  br label %bb_failure
bb_rcsuccess55:
  br label %bb_rcmoved43
bb_rcmoved43:
  %v934 = load i64, ptr %slot12, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i32 0, ptr %p935, align 4, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot17, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i32 2, ptr %p937, align 4, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot16, align 8
  %p939 = inttoptr i64 %v938 to ptr
  store i32 1, ptr %p939, align 4, !alias.scope !3, !noalias !4
  %v940 = load i64, ptr %slot6, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i32, ptr %p941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld942, ptr %slot77, align 8
  %v943 = load i32, ptr %slot77, align 8
  %cv944 = zext i32 %v943 to i64
  %cond945 = icmp ne i64 %cv944, 0
  br i1 %cond945, label %bb_rcslotdrop64, label %bb_rcslotdone64
bb_rcslotdrop64:
  %v946 = load i64, ptr %slot6, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 0, ptr %p947, align 4, !alias.scope !3, !noalias !4
  %v948 = load i64, ptr %slot28, align 8
  store i64 %v948, ptr %slot78, align 8
  %v949 = load i64, ptr %slot7, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ld951 = load i32, ptr %p950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld951, ptr %slot79, align 8
  %v952 = load i32, ptr %slot79, align 8
  %op953 = and i32 %v952, 28
  store i32 %op953, ptr %slot80, align 8
  %v954 = load i32, ptr %slot80, align 8
  %cv955 = zext i32 %v954 to i64
  %cond956 = icmp ne i64 %cv955, 0
  br i1 %cond956, label %bb_rcslotrole64, label %bb_rcslotowner64
bb_rcslotrole64:
  %v957 = load i64, ptr %slot43, align 8
  store i64 %v957, ptr %slot81, align 8
  %v958 = load i64, ptr %slot81, align 8
  %v959 = load i64, ptr %slot78, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v958, i64 %v959) nomerge, !dbg !116
  br label %bb_rcslotdone64
bb_rcslotowner64:
  %v960 = load i64, ptr %slot78, align 8
  %p962 = inttoptr i64 %v960 to ptr
  %gep963 = getelementptr i8, ptr %p962, i64 8
  %op961 = ptrtoint ptr %gep963 to i64
  store i64 %op961, ptr %slot82, align 8
  %v964 = load i64, ptr %slot43, align 8
  store i64 %v964, ptr %slot83, align 8
  %v965 = load i64, ptr %slot82, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %ld967 = load i64, ptr %p966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld967, ptr %slot84, align 8
  %v968 = load i64, ptr %slot84, align 8
  %cmp969 = icmp ne i64 %v968, 0
  %cv970 = zext i1 %cmp969 to i32
  store i32 %cv970, ptr %slot85, align 8
  %v971 = load i32, ptr %slot85, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcgnn82, label %bb_rcgdone82
bb_rcgnn82:
  %v974 = load i64, ptr %slot84, align 8
  %op975 = sub i64 %v974, 16
  store i64 %op975, ptr %slot86, align 8
  %v976 = load i64, ptr %slot84, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %rgep978 = getelementptr i8, ptr %p977, i64 -16
  %ld979 = load i64, ptr %rgep978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld979, ptr %slot87, align 8
  %v980 = load i64, ptr %slot87, align 8
  %op981 = and i64 %v980, 4611686018427387906
  store i64 %op981, ptr %slot88, align 8
  %v982 = load i64, ptr %slot88, align 8
  %cmp983 = icmp ne i64 %v982, 0
  %cv984 = zext i1 %cmp983 to i32
  store i32 %cv984, ptr %slot89, align 8
  %v985 = load i32, ptr %slot89, align 8
  %cv986 = zext i32 %v985 to i64
  %cond987 = icmp ne i64 %cv986, 0
  br i1 %cond987, label %bb_rcgclear82, label %bb_rcgcounted82
bb_rcgcounted82:
  %v988 = load i64, ptr %slot84, align 8
  %op989 = sub i64 %v988, 32
  store i64 %op989, ptr %slot90, align 8
  %v990 = load i64, ptr %slot84, align 8
  %p991 = inttoptr i64 %v990 to ptr
  %rgep992 = getelementptr i8, ptr %p991, i64 -32
  %ld993 = load i64, ptr %rgep992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld993, ptr %slot91, align 8
  %v994 = load i64, ptr %slot91, align 8
  %op995 = sub i64 %v994, 1
  store i64 %op995, ptr %slot92, align 8
  %v996 = load i64, ptr %slot92, align 8
  %cmp997 = icmp eq i64 %v996, 0
  %cv998 = zext i1 %cmp997 to i32
  store i32 %cv998, ptr %slot93, align 8
  %v999 = load i32, ptr %slot93, align 8
  %cv1000 = zext i32 %v999 to i64
  %cond1001 = icmp ne i64 %cv1000, 0
  br i1 %cond1001, label %bb_rcglast82, label %bb_rcgdec82
bb_rcglast82:
  %v1002 = load i64, ptr %slot84, align 8
  %op1003 = sub i64 %v1002, 24
  store i64 %op1003, ptr %slot94, align 8
  %v1004 = load i64, ptr %slot84, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  %rgep1006 = getelementptr i8, ptr %p1005, i64 -24
  %ld1007 = load i64, ptr %rgep1006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1007, ptr %slot95, align 8
  %v1008 = load i64, ptr %slot95, align 8
  %cmp1009 = icmp ne i64 %v1008, 0
  %cv1010 = zext i1 %cmp1009 to i32
  store i32 %cv1010, ptr %slot96, align 8
  %v1011 = load i32, ptr %slot96, align 8
  %cv1012 = zext i32 %v1011 to i64
  %cond1013 = icmp ne i64 %cv1012, 0
  br i1 %cond1013, label %bb_rcgdec82, label %bb_rcgslow82
bb_rcgslow82:
  %v1014 = load i64, ptr %slot83, align 8
  %v1015 = load i64, ptr %slot82, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1014, i64 %v1015) nomerge, !dbg !116
  br label %bb_rcgdone82
bb_rcgdec82:
  %v1016 = load i64, ptr %slot92, align 8
  %v1017 = load i64, ptr %slot84, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %rgep1019 = getelementptr i8, ptr %p1018, i64 -32
  store i64 %v1016, ptr %rgep1019, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear82
bb_rcgclear82:
  %v1020 = load i64, ptr %slot82, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  store i64 0, ptr %p1021, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone82
bb_rcgdone82:
  %v1022 = load i64, ptr %slot78, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  store i64 0, ptr %p1023, align 8, !alias.scope !3, !noalias !4
  %v1024 = load i64, ptr %slot78, align 8
  %p1026 = inttoptr i64 %v1024 to ptr
  %gep1027 = getelementptr i8, ptr %p1026, i64 8
  %op1025 = ptrtoint ptr %gep1027 to i64
  store i64 %op1025, ptr %slot97, align 8
  %v1028 = load i64, ptr %slot97, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i64 0, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot78, align 8
  %p1032 = inttoptr i64 %v1030 to ptr
  %gep1033 = getelementptr i8, ptr %p1032, i64 16
  %op1031 = ptrtoint ptr %gep1033 to i64
  store i64 %op1031, ptr %slot98, align 8
  %v1034 = load i64, ptr %slot98, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  store i64 0, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone64
bb_rcslotdone64:
  %v1036 = load i64, ptr %slot28, align 8
  store i64 %v1036, ptr %slot99, align 8
  %v1037 = load i64, ptr %slot21, align 8
  store i64 %v1037, ptr %slot100, align 8
  %v1038 = load i64, ptr %slot100, align 8
  %v1039 = load i64, ptr %slot99, align 8
  %p1040 = inttoptr i64 %v1038 to ptr
  %p1041 = inttoptr i64 %v1039 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1041, ptr %p1040, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1042 = load i64, ptr %slot16, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 0, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot7, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 2, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot17, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i32, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1048, ptr %slot101, align 8
  %v1049 = load i32, ptr %slot101, align 8
  %v1050 = load i64, ptr %slot7, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i32 %v1049, ptr %p1051, align 4, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot6, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 1, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot27, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %ld1056 = load i64, ptr %p1055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1056, ptr %slot102, align 8
  %v1057 = load i64, ptr %slot102, align 8
  %v1058 = load i64, ptr %slot34, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i64 %v1057, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot34, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %ld1062 = load i64, ptr %p1061, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1062, ptr %slot103, align 8
  %v1063 = load i64, ptr %slot103, align 8
  %v1064 = load i64, ptr %slot30, align 8
  %p1065 = inttoptr i64 %v1063 to ptr
  %p1066 = inttoptr i64 %v1064 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1066, ptr %p1065, i64 16, i1 false), !alias.scope !10000000
  %v1067 = load i64, ptr %slot28, align 8
  %v1068 = load i64, ptr %slot34, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i64 %v1067, ptr %p1069, align 8, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot34, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %ld1072 = load i64, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1072, ptr %slot104, align 8
  %v1073 = load i64, ptr %slot12, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %ld1075 = load i32, ptr %p1074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1075, ptr %slot105, align 8
  %v1076 = load i64, ptr %slot13, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %ld1078 = load i32, ptr %p1077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1078, ptr %slot106, align 8
  %v1079 = load i32, ptr %slot106, align 8
  %op1080 = and i32 %v1079, 24
  store i32 %op1080, ptr %slot106, align 8
  %v1081 = load i32, ptr %slot106, align 8
  %cmp1082 = icmp eq i32 %v1081, 0
  %cv1083 = zext i1 %cmp1082 to i32
  store i32 %cv1083, ptr %slot107, align 8
  %v1084 = load i32, ptr %slot105, align 8
  %v1085 = load i32, ptr %slot107, align 8
  %op1086 = and i32 %v1084, %v1085
  store i32 %op1086, ptr %slot108, align 8
  %v1087 = load i32, ptr %slot108, align 8
  %cv1088 = zext i32 %v1087 to i64
  %cond1089 = icmp ne i64 %cv1088, 0
  br i1 %cond1089, label %bb_rcprivateown104, label %bb_rcprivateloan104
bb_rcprivateown104:
  %v1090 = load i64, ptr %slot21, align 8
  store i64 %v1090, ptr %slot109, align 8
  %v1091 = load i64, ptr %slot44, align 8
  store i64 %v1091, ptr %slot110, align 8
  %v1092 = load i64, ptr %slot104, align 8
  %v1093 = load i64, ptr %slot109, align 8
  %op1094 = sub i64 %v1092, %v1093
  store i64 %op1094, ptr %slot111, align 8
  %v1095 = load i64, ptr %slot109, align 8
  %v1096 = load i64, ptr %slot104, align 8
  %op1097 = sub i64 %v1095, %v1096
  store i64 %op1097, ptr %slot112, align 8
  %v1098 = load i64, ptr %slot111, align 8
  %cmp1099 = icmp ult i64 %v1098, 24
  %cv1100 = zext i1 %cmp1099 to i32
  store i32 %cv1100, ptr %slot113, align 8
  %v1101 = load i64, ptr %slot112, align 8
  %cmp1102 = icmp ult i64 %v1101, 24
  %cv1103 = zext i1 %cmp1102 to i32
  store i32 %cv1103, ptr %slot114, align 8
  %v1104 = load i32, ptr %slot113, align 8
  %v1105 = load i32, ptr %slot114, align 8
  %op1106 = or i32 %v1104, %v1105
  store i32 %op1106, ptr %slot115, align 8
  %v1107 = load i32, ptr %slot115, align 8
  %cv1108 = zext i32 %v1107 to i64
  %cond1109 = icmp ne i64 %cv1108, 0
  br i1 %cond1109, label %bb_rcmoveslow107, label %bb_rcmovecheck107
bb_rcmovecheck107:
  %v1110 = load i64, ptr %slot104, align 8
  %op1111 = add i64 %v1110, 8
  store i64 %op1111, ptr %slot116, align 8
  %v1112 = load i64, ptr %slot116, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %ld1114 = load i64, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1114, ptr %slot117, align 8
  %v1115 = load i64, ptr %slot117, align 8
  %cmp1116 = icmp ne i64 %v1115, 0
  %cv1117 = zext i1 %cmp1116 to i32
  store i32 %cv1117, ptr %slot118, align 8
  %v1118 = load i32, ptr %slot118, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcmoveheader115, label %bb_rcmovenext115
bb_rcmoveheader115:
  %v1121 = load i64, ptr %slot117, align 8
  %op1122 = sub i64 %v1121, 16
  store i64 %op1122, ptr %slot119, align 8
  %v1123 = load i64, ptr %slot117, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %rgep1125 = getelementptr i8, ptr %p1124, i64 -16
  %ld1126 = load i64, ptr %rgep1125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1126, ptr %slot120, align 8
  %v1127 = load i64, ptr %slot120, align 8
  %op1128 = and i64 %v1127, 5764607523034234881
  store i64 %op1128, ptr %slot121, align 8
  %v1129 = load i64, ptr %slot121, align 8
  %cmp1130 = icmp ne i64 %v1129, 0
  %cv1131 = zext i1 %cmp1130 to i32
  store i32 %cv1131, ptr %slot122, align 8
  %v1132 = load i32, ptr %slot122, align 8
  %cv1133 = zext i32 %v1132 to i64
  %cond1134 = icmp ne i64 %cv1133, 0
  br i1 %cond1134, label %bb_rcmoveslow107, label %bb_rcmovenext115
bb_rcmovenext115:
  %v1135 = load i64, ptr %slot104, align 8
  %v1136 = load i64, ptr %slot109, align 8
  %p1137 = inttoptr i64 %v1135 to ptr
  %p1138 = inttoptr i64 %v1136 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1138, ptr %p1137, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot104, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  store i64 0, ptr %p1140, align 8, !alias.scope !3, !noalias !4
  %v1141 = load i64, ptr %slot104, align 8
  %op1142 = add i64 %v1141, 8
  store i64 %op1142, ptr %slot123, align 8
  %v1143 = load i64, ptr %slot123, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 0, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot104, align 8
  %op1146 = add i64 %v1145, 16
  store i64 %op1146, ptr %slot124, align 8
  %v1147 = load i64, ptr %slot124, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 0, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved107
bb_rcmoveslow107:
  %v1149 = load i64, ptr %slot43, align 8
  %v1150 = load i64, ptr %slot109, align 8
  %v1151 = load i64, ptr %slot104, align 8
  %v1152 = load i64, ptr %slot110, align 8
  %cv1153 = trunc i64 %v1152 to i32
  %call1154 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1149, i64 %v1150, i64 %v1151, i32 %cv1153) nomerge, !dbg !118
  store i32 %call1154, ptr %slot125, align 8
  %v1155 = load i32, ptr %slot125, align 8
  %cv1156 = zext i32 %v1155 to i64
  %cond1157 = icmp ne i64 %cv1156, 0
  br i1 %cond1157, label %bb_rcsuccess124, label %bb_rcfailure124
bb_rcfailure124:
  %v1158 = load i64, ptr %slot43, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %call1160 = call i32 @myl_rc_take_failure(ptr %p1159) nomerge, !dbg !118
  store i32 %call1160, ptr %slot126, align 8
  %v1161 = load i64, ptr %slot1, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %v1163 = load i32, ptr %slot126, align 8
  %call1164 = call i32 @myl_qbe_rc_status(ptr %p1162, i32 %v1163) nomerge, !dbg !118
  store i32 %call1164, ptr %slot127, align 8
  br label %bb_failure
bb_rcsuccess124:
  br label %bb_rcmoved107
bb_rcmoved107:
  %v1165 = load i64, ptr %slot12, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i32 0, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot17, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i32 2, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot16, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 1, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared104
bb_rcprivateloan104:
  %v1171 = load i64, ptr %slot21, align 8
  store i64 %v1171, ptr %slot128, align 8
  %v1172 = load i64, ptr %slot43, align 8
  %v1173 = load i64, ptr %slot128, align 8
  %v1174 = load i64, ptr %slot104, align 8
  %call1175 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v1172, i64 %v1173, i64 %v1174) nomerge, !dbg !118
  store i32 %call1175, ptr %slot129, align 8
  %v1176 = load i32, ptr %slot129, align 8
  %cv1177 = zext i32 %v1176 to i64
  %cond1178 = icmp ne i64 %cv1177, 0
  br i1 %cond1178, label %bb_rcsuccess132, label %bb_rcfailure132
bb_rcfailure132:
  %v1179 = load i64, ptr %slot43, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %call1181 = call i32 @myl_rc_take_failure(ptr %p1180) nomerge, !dbg !118
  store i32 %call1181, ptr %slot130, align 8
  %v1182 = load i64, ptr %slot1, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  %v1184 = load i32, ptr %slot130, align 8
  %call1185 = call i32 @myl_qbe_rc_status(ptr %p1183, i32 %v1184) nomerge, !dbg !118
  store i32 %call1185, ptr %slot131, align 8
  br label %bb_failure
bb_rcsuccess132:
  %v1186 = load i64, ptr %slot17, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i32 2, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot17, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i32 16, ptr %p1189, align 4, !alias.scope !3, !noalias !4
  %v1190 = load i64, ptr %slot16, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  store i32 1, ptr %p1191, align 4, !alias.scope !3, !noalias !4
  %v1192 = load i64, ptr %slot12, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i32, ptr %p1193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1194, ptr %slot132, align 8
  %v1195 = load i32, ptr %slot132, align 8
  %cv1196 = zext i32 %v1195 to i64
  %cond1197 = icmp ne i64 %cv1196, 0
  br i1 %cond1197, label %bb_rcslotdrop140, label %bb_rcslotdone140
bb_rcslotdrop140:
  %v1198 = load i64, ptr %slot12, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  store i32 0, ptr %p1199, align 4, !alias.scope !3, !noalias !4
  %v1200 = load i64, ptr %slot19, align 8
  store i64 %v1200, ptr %slot133, align 8
  %v1201 = load i64, ptr %slot13, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i32, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1203, ptr %slot134, align 8
  %v1204 = load i32, ptr %slot134, align 8
  %op1205 = and i32 %v1204, 28
  store i32 %op1205, ptr %slot135, align 8
  %v1206 = load i32, ptr %slot135, align 8
  %cv1207 = zext i32 %v1206 to i64
  %cond1208 = icmp ne i64 %cv1207, 0
  br i1 %cond1208, label %bb_rcslotrole140, label %bb_rcslotowner140
bb_rcslotrole140:
  %v1209 = load i64, ptr %slot43, align 8
  store i64 %v1209, ptr %slot136, align 8
  %v1210 = load i64, ptr %slot136, align 8
  %v1211 = load i64, ptr %slot133, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1210, i64 %v1211) nomerge, !dbg !118
  br label %bb_rcslotdone140
bb_rcslotowner140:
  %v1212 = load i64, ptr %slot133, align 8
  %p1214 = inttoptr i64 %v1212 to ptr
  %gep1215 = getelementptr i8, ptr %p1214, i64 8
  %op1213 = ptrtoint ptr %gep1215 to i64
  store i64 %op1213, ptr %slot137, align 8
  %v1216 = load i64, ptr %slot43, align 8
  store i64 %v1216, ptr %slot138, align 8
  %v1217 = load i64, ptr %slot137, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ld1219 = load i64, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1219, ptr %slot139, align 8
  %v1220 = load i64, ptr %slot139, align 8
  %cmp1221 = icmp ne i64 %v1220, 0
  %cv1222 = zext i1 %cmp1221 to i32
  store i32 %cv1222, ptr %slot140, align 8
  %v1223 = load i32, ptr %slot140, align 8
  %cv1224 = zext i32 %v1223 to i64
  %cond1225 = icmp ne i64 %cv1224, 0
  br i1 %cond1225, label %bb_rcgnn158, label %bb_rcgdone158
bb_rcgnn158:
  %v1226 = load i64, ptr %slot139, align 8
  %op1227 = sub i64 %v1226, 16
  store i64 %op1227, ptr %slot141, align 8
  %v1228 = load i64, ptr %slot139, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %rgep1230 = getelementptr i8, ptr %p1229, i64 -16
  %ld1231 = load i64, ptr %rgep1230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1231, ptr %slot142, align 8
  %v1232 = load i64, ptr %slot142, align 8
  %op1233 = and i64 %v1232, 4611686018427387906
  store i64 %op1233, ptr %slot143, align 8
  %v1234 = load i64, ptr %slot143, align 8
  %cmp1235 = icmp ne i64 %v1234, 0
  %cv1236 = zext i1 %cmp1235 to i32
  store i32 %cv1236, ptr %slot144, align 8
  %v1237 = load i32, ptr %slot144, align 8
  %cv1238 = zext i32 %v1237 to i64
  %cond1239 = icmp ne i64 %cv1238, 0
  br i1 %cond1239, label %bb_rcgclear158, label %bb_rcgcounted158
bb_rcgcounted158:
  %v1240 = load i64, ptr %slot139, align 8
  %op1241 = sub i64 %v1240, 32
  store i64 %op1241, ptr %slot145, align 8
  %v1242 = load i64, ptr %slot139, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %rgep1244 = getelementptr i8, ptr %p1243, i64 -32
  %ld1245 = load i64, ptr %rgep1244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1245, ptr %slot146, align 8
  %v1246 = load i64, ptr %slot146, align 8
  %op1247 = sub i64 %v1246, 1
  store i64 %op1247, ptr %slot147, align 8
  %v1248 = load i64, ptr %slot147, align 8
  %cmp1249 = icmp eq i64 %v1248, 0
  %cv1250 = zext i1 %cmp1249 to i32
  store i32 %cv1250, ptr %slot148, align 8
  %v1251 = load i32, ptr %slot148, align 8
  %cv1252 = zext i32 %v1251 to i64
  %cond1253 = icmp ne i64 %cv1252, 0
  br i1 %cond1253, label %bb_rcglast158, label %bb_rcgdec158
bb_rcglast158:
  %v1254 = load i64, ptr %slot139, align 8
  %op1255 = sub i64 %v1254, 24
  store i64 %op1255, ptr %slot149, align 8
  %v1256 = load i64, ptr %slot139, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %rgep1258 = getelementptr i8, ptr %p1257, i64 -24
  %ld1259 = load i64, ptr %rgep1258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1259, ptr %slot150, align 8
  %v1260 = load i64, ptr %slot150, align 8
  %cmp1261 = icmp ne i64 %v1260, 0
  %cv1262 = zext i1 %cmp1261 to i32
  store i32 %cv1262, ptr %slot151, align 8
  %v1263 = load i32, ptr %slot151, align 8
  %cv1264 = zext i32 %v1263 to i64
  %cond1265 = icmp ne i64 %cv1264, 0
  br i1 %cond1265, label %bb_rcgdec158, label %bb_rcgslow158
bb_rcgslow158:
  %v1266 = load i64, ptr %slot138, align 8
  %v1267 = load i64, ptr %slot137, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1266, i64 %v1267) nomerge, !dbg !118
  br label %bb_rcgdone158
bb_rcgdec158:
  %v1268 = load i64, ptr %slot147, align 8
  %v1269 = load i64, ptr %slot139, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  %rgep1271 = getelementptr i8, ptr %p1270, i64 -32
  store i64 %v1268, ptr %rgep1271, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear158
bb_rcgclear158:
  %v1272 = load i64, ptr %slot137, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  store i64 0, ptr %p1273, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone158
bb_rcgdone158:
  %v1274 = load i64, ptr %slot133, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i64 0, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot133, align 8
  %p1278 = inttoptr i64 %v1276 to ptr
  %gep1279 = getelementptr i8, ptr %p1278, i64 8
  %op1277 = ptrtoint ptr %gep1279 to i64
  store i64 %op1277, ptr %slot152, align 8
  %v1280 = load i64, ptr %slot152, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i64 0, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot133, align 8
  %p1284 = inttoptr i64 %v1282 to ptr
  %gep1285 = getelementptr i8, ptr %p1284, i64 16
  %op1283 = ptrtoint ptr %gep1285 to i64
  store i64 %op1283, ptr %slot153, align 8
  %v1286 = load i64, ptr %slot153, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 0, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone140
bb_rcslotdone140:
  br label %bb_rcprivateprepared104
bb_rcprivateprepared104:
  %v1288 = load i64, ptr %slot8, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i32, ptr %p1289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1290, ptr %slot154, align 8
  %v1291 = load i32, ptr %slot154, align 8
  %cv1292 = zext i32 %v1291 to i64
  %cond1293 = icmp ne i64 %cv1292, 0
  br i1 %cond1293, label %bb_rcslotdrop167, label %bb_rcslotdone167
bb_rcslotdrop167:
  %v1294 = load i64, ptr %slot8, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  store i32 0, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  %v1296 = load i64, ptr %slot29, align 8
  store i64 %v1296, ptr %slot155, align 8
  %v1297 = load i64, ptr %slot9, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i32, ptr %p1298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1299, ptr %slot156, align 8
  %v1300 = load i32, ptr %slot156, align 8
  %op1301 = and i32 %v1300, 28
  store i32 %op1301, ptr %slot157, align 8
  %v1302 = load i32, ptr %slot157, align 8
  %cv1303 = zext i32 %v1302 to i64
  %cond1304 = icmp ne i64 %cv1303, 0
  br i1 %cond1304, label %bb_rcslotrole167, label %bb_rcslotowner167
bb_rcslotrole167:
  %v1305 = load i64, ptr %slot43, align 8
  store i64 %v1305, ptr %slot158, align 8
  %v1306 = load i64, ptr %slot158, align 8
  %v1307 = load i64, ptr %slot155, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1306, i64 %v1307) nomerge, !dbg !118
  br label %bb_rcslotdone167
bb_rcslotowner167:
  %v1308 = load i64, ptr %slot155, align 8
  %p1310 = inttoptr i64 %v1308 to ptr
  %gep1311 = getelementptr i8, ptr %p1310, i64 8
  %op1309 = ptrtoint ptr %gep1311 to i64
  store i64 %op1309, ptr %slot159, align 8
  %v1312 = load i64, ptr %slot43, align 8
  store i64 %v1312, ptr %slot160, align 8
  %v1313 = load i64, ptr %slot159, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %ld1315 = load i64, ptr %p1314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1315, ptr %slot161, align 8
  %v1316 = load i64, ptr %slot161, align 8
  %cmp1317 = icmp ne i64 %v1316, 0
  %cv1318 = zext i1 %cmp1317 to i32
  store i32 %cv1318, ptr %slot162, align 8
  %v1319 = load i32, ptr %slot162, align 8
  %cv1320 = zext i32 %v1319 to i64
  %cond1321 = icmp ne i64 %cv1320, 0
  br i1 %cond1321, label %bb_rcgnn185, label %bb_rcgdone185
bb_rcgnn185:
  %v1322 = load i64, ptr %slot161, align 8
  %op1323 = sub i64 %v1322, 16
  store i64 %op1323, ptr %slot163, align 8
  %v1324 = load i64, ptr %slot161, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %rgep1326 = getelementptr i8, ptr %p1325, i64 -16
  %ld1327 = load i64, ptr %rgep1326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1327, ptr %slot164, align 8
  %v1328 = load i64, ptr %slot164, align 8
  %op1329 = and i64 %v1328, 4611686018427387906
  store i64 %op1329, ptr %slot165, align 8
  %v1330 = load i64, ptr %slot165, align 8
  %cmp1331 = icmp ne i64 %v1330, 0
  %cv1332 = zext i1 %cmp1331 to i32
  store i32 %cv1332, ptr %slot166, align 8
  %v1333 = load i32, ptr %slot166, align 8
  %cv1334 = zext i32 %v1333 to i64
  %cond1335 = icmp ne i64 %cv1334, 0
  br i1 %cond1335, label %bb_rcgclear185, label %bb_rcgcounted185
bb_rcgcounted185:
  %v1336 = load i64, ptr %slot161, align 8
  %op1337 = sub i64 %v1336, 32
  store i64 %op1337, ptr %slot167, align 8
  %v1338 = load i64, ptr %slot161, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %rgep1340 = getelementptr i8, ptr %p1339, i64 -32
  %ld1341 = load i64, ptr %rgep1340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1341, ptr %slot168, align 8
  %v1342 = load i64, ptr %slot168, align 8
  %op1343 = sub i64 %v1342, 1
  store i64 %op1343, ptr %slot169, align 8
  %v1344 = load i64, ptr %slot169, align 8
  %cmp1345 = icmp eq i64 %v1344, 0
  %cv1346 = zext i1 %cmp1345 to i32
  store i32 %cv1346, ptr %slot170, align 8
  %v1347 = load i32, ptr %slot170, align 8
  %cv1348 = zext i32 %v1347 to i64
  %cond1349 = icmp ne i64 %cv1348, 0
  br i1 %cond1349, label %bb_rcglast185, label %bb_rcgdec185
bb_rcglast185:
  %v1350 = load i64, ptr %slot161, align 8
  %op1351 = sub i64 %v1350, 24
  store i64 %op1351, ptr %slot171, align 8
  %v1352 = load i64, ptr %slot161, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  %rgep1354 = getelementptr i8, ptr %p1353, i64 -24
  %ld1355 = load i64, ptr %rgep1354, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1355, ptr %slot172, align 8
  %v1356 = load i64, ptr %slot172, align 8
  %cmp1357 = icmp ne i64 %v1356, 0
  %cv1358 = zext i1 %cmp1357 to i32
  store i32 %cv1358, ptr %slot173, align 8
  %v1359 = load i32, ptr %slot173, align 8
  %cv1360 = zext i32 %v1359 to i64
  %cond1361 = icmp ne i64 %cv1360, 0
  br i1 %cond1361, label %bb_rcgdec185, label %bb_rcgslow185
bb_rcgslow185:
  %v1362 = load i64, ptr %slot160, align 8
  %v1363 = load i64, ptr %slot159, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1362, i64 %v1363) nomerge, !dbg !118
  br label %bb_rcgdone185
bb_rcgdec185:
  %v1364 = load i64, ptr %slot169, align 8
  %v1365 = load i64, ptr %slot161, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  %rgep1367 = getelementptr i8, ptr %p1366, i64 -32
  store i64 %v1364, ptr %rgep1367, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear185
bb_rcgclear185:
  %v1368 = load i64, ptr %slot159, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  store i64 0, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone185
bb_rcgdone185:
  %v1370 = load i64, ptr %slot155, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  store i64 0, ptr %p1371, align 8, !alias.scope !3, !noalias !4
  %v1372 = load i64, ptr %slot155, align 8
  %p1374 = inttoptr i64 %v1372 to ptr
  %gep1375 = getelementptr i8, ptr %p1374, i64 8
  %op1373 = ptrtoint ptr %gep1375 to i64
  store i64 %op1373, ptr %slot174, align 8
  %v1376 = load i64, ptr %slot174, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  store i64 0, ptr %p1377, align 8, !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot155, align 8
  %p1380 = inttoptr i64 %v1378 to ptr
  %gep1381 = getelementptr i8, ptr %p1380, i64 16
  %op1379 = ptrtoint ptr %gep1381 to i64
  store i64 %op1379, ptr %slot175, align 8
  %v1382 = load i64, ptr %slot175, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i64 0, ptr %p1383, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone167
bb_rcslotdone167:
  %v1384 = load i64, ptr %slot29, align 8
  store i64 %v1384, ptr %slot176, align 8
  %v1385 = load i64, ptr %slot21, align 8
  store i64 %v1385, ptr %slot177, align 8
  %v1386 = load i64, ptr %slot177, align 8
  %v1387 = load i64, ptr %slot176, align 8
  %p1388 = inttoptr i64 %v1386 to ptr
  %p1389 = inttoptr i64 %v1387 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1389, ptr %p1388, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot16, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i32 0, ptr %p1391, align 4, !alias.scope !3, !noalias !4
  %v1392 = load i64, ptr %slot9, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 2, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot17, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %ld1396 = load i32, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1396, ptr %slot178, align 8
  %v1397 = load i32, ptr %slot178, align 8
  %v1398 = load i64, ptr %slot9, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 %v1397, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot8, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 1, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot28, align 8
  %v1403 = load i64, ptr %slot34, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 %v1402, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  %v1405 = load i64, ptr %slot34, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot179, align 8
  %v1408 = load i64, ptr %slot12, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i32, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1410, ptr %slot180, align 8
  %v1411 = load i64, ptr %slot13, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i32, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1413, ptr %slot181, align 8
  %v1414 = load i32, ptr %slot181, align 8
  %op1415 = and i32 %v1414, 24
  store i32 %op1415, ptr %slot181, align 8
  %v1416 = load i32, ptr %slot181, align 8
  %cmp1417 = icmp eq i32 %v1416, 0
  %cv1418 = zext i1 %cmp1417 to i32
  store i32 %cv1418, ptr %slot182, align 8
  %v1419 = load i32, ptr %slot180, align 8
  %v1420 = load i32, ptr %slot182, align 8
  %op1421 = and i32 %v1419, %v1420
  store i32 %op1421, ptr %slot183, align 8
  %v1422 = load i32, ptr %slot183, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcprivateown205, label %bb_rcprivateloan205
bb_rcprivateown205:
  %v1425 = load i64, ptr %slot21, align 8
  store i64 %v1425, ptr %slot184, align 8
  %v1426 = load i64, ptr %slot44, align 8
  store i64 %v1426, ptr %slot185, align 8
  %v1427 = load i64, ptr %slot179, align 8
  %v1428 = load i64, ptr %slot184, align 8
  %op1429 = sub i64 %v1427, %v1428
  store i64 %op1429, ptr %slot186, align 8
  %v1430 = load i64, ptr %slot184, align 8
  %v1431 = load i64, ptr %slot179, align 8
  %op1432 = sub i64 %v1430, %v1431
  store i64 %op1432, ptr %slot187, align 8
  %v1433 = load i64, ptr %slot186, align 8
  %cmp1434 = icmp ult i64 %v1433, 24
  %cv1435 = zext i1 %cmp1434 to i32
  store i32 %cv1435, ptr %slot188, align 8
  %v1436 = load i64, ptr %slot187, align 8
  %cmp1437 = icmp ult i64 %v1436, 24
  %cv1438 = zext i1 %cmp1437 to i32
  store i32 %cv1438, ptr %slot189, align 8
  %v1439 = load i32, ptr %slot188, align 8
  %v1440 = load i32, ptr %slot189, align 8
  %op1441 = or i32 %v1439, %v1440
  store i32 %op1441, ptr %slot190, align 8
  %v1442 = load i32, ptr %slot190, align 8
  %cv1443 = zext i32 %v1442 to i64
  %cond1444 = icmp ne i64 %cv1443, 0
  br i1 %cond1444, label %bb_rcmoveslow208, label %bb_rcmovecheck208
bb_rcmovecheck208:
  %v1445 = load i64, ptr %slot179, align 8
  %op1446 = add i64 %v1445, 8
  store i64 %op1446, ptr %slot191, align 8
  %v1447 = load i64, ptr %slot191, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i64, ptr %p1448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1449, ptr %slot192, align 8
  %v1450 = load i64, ptr %slot192, align 8
  %cmp1451 = icmp ne i64 %v1450, 0
  %cv1452 = zext i1 %cmp1451 to i32
  store i32 %cv1452, ptr %slot193, align 8
  %v1453 = load i32, ptr %slot193, align 8
  %cv1454 = zext i32 %v1453 to i64
  %cond1455 = icmp ne i64 %cv1454, 0
  br i1 %cond1455, label %bb_rcmoveheader216, label %bb_rcmovenext216
bb_rcmoveheader216:
  %v1456 = load i64, ptr %slot192, align 8
  %op1457 = sub i64 %v1456, 16
  store i64 %op1457, ptr %slot194, align 8
  %v1458 = load i64, ptr %slot192, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %rgep1460 = getelementptr i8, ptr %p1459, i64 -16
  %ld1461 = load i64, ptr %rgep1460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1461, ptr %slot195, align 8
  %v1462 = load i64, ptr %slot195, align 8
  %op1463 = and i64 %v1462, 5764607523034234881
  store i64 %op1463, ptr %slot196, align 8
  %v1464 = load i64, ptr %slot196, align 8
  %cmp1465 = icmp ne i64 %v1464, 0
  %cv1466 = zext i1 %cmp1465 to i32
  store i32 %cv1466, ptr %slot197, align 8
  %v1467 = load i32, ptr %slot197, align 8
  %cv1468 = zext i32 %v1467 to i64
  %cond1469 = icmp ne i64 %cv1468, 0
  br i1 %cond1469, label %bb_rcmoveslow208, label %bb_rcmovenext216
bb_rcmovenext216:
  %v1470 = load i64, ptr %slot179, align 8
  %v1471 = load i64, ptr %slot184, align 8
  %p1472 = inttoptr i64 %v1470 to ptr
  %p1473 = inttoptr i64 %v1471 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1473, ptr %p1472, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1474 = load i64, ptr %slot179, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i64 0, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot179, align 8
  %op1477 = add i64 %v1476, 8
  store i64 %op1477, ptr %slot198, align 8
  %v1478 = load i64, ptr %slot198, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  store i64 0, ptr %p1479, align 8, !alias.scope !3, !noalias !4
  %v1480 = load i64, ptr %slot179, align 8
  %op1481 = add i64 %v1480, 16
  store i64 %op1481, ptr %slot199, align 8
  %v1482 = load i64, ptr %slot199, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i64 0, ptr %p1483, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved208
bb_rcmoveslow208:
  %v1484 = load i64, ptr %slot43, align 8
  %v1485 = load i64, ptr %slot184, align 8
  %v1486 = load i64, ptr %slot179, align 8
  %v1487 = load i64, ptr %slot185, align 8
  %cv1488 = trunc i64 %v1487 to i32
  %call1489 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1484, i64 %v1485, i64 %v1486, i32 %cv1488) nomerge, !dbg !120
  store i32 %call1489, ptr %slot200, align 8
  %v1490 = load i32, ptr %slot200, align 8
  %cv1491 = zext i32 %v1490 to i64
  %cond1492 = icmp ne i64 %cv1491, 0
  br i1 %cond1492, label %bb_rcsuccess225, label %bb_rcfailure225
bb_rcfailure225:
  %v1493 = load i64, ptr %slot43, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  %call1495 = call i32 @myl_rc_take_failure(ptr %p1494) nomerge, !dbg !120
  store i32 %call1495, ptr %slot201, align 8
  %v1496 = load i64, ptr %slot1, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %v1498 = load i32, ptr %slot201, align 8
  %call1499 = call i32 @myl_qbe_rc_status(ptr %p1497, i32 %v1498) nomerge, !dbg !120
  store i32 %call1499, ptr %slot202, align 8
  br label %bb_failure
bb_rcsuccess225:
  br label %bb_rcmoved208
bb_rcmoved208:
  %v1500 = load i64, ptr %slot12, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i32 0, ptr %p1501, align 4, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot17, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i32 2, ptr %p1503, align 4, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot16, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  store i32 1, ptr %p1505, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared205
bb_rcprivateloan205:
  %v1506 = load i64, ptr %slot21, align 8
  store i64 %v1506, ptr %slot203, align 8
  %v1507 = load i64, ptr %slot43, align 8
  %v1508 = load i64, ptr %slot203, align 8
  %v1509 = load i64, ptr %slot179, align 8
  %call1510 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v1507, i64 %v1508, i64 %v1509) nomerge, !dbg !120
  store i32 %call1510, ptr %slot204, align 8
  %v1511 = load i32, ptr %slot204, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcsuccess233, label %bb_rcfailure233
bb_rcfailure233:
  %v1514 = load i64, ptr %slot43, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %call1516 = call i32 @myl_rc_take_failure(ptr %p1515) nomerge, !dbg !120
  store i32 %call1516, ptr %slot205, align 8
  %v1517 = load i64, ptr %slot1, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  %v1519 = load i32, ptr %slot205, align 8
  %call1520 = call i32 @myl_qbe_rc_status(ptr %p1518, i32 %v1519) nomerge, !dbg !120
  store i32 %call1520, ptr %slot206, align 8
  br label %bb_failure
bb_rcsuccess233:
  %v1521 = load i64, ptr %slot17, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i32 2, ptr %p1522, align 4, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot17, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 16, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot16, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i32 1, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot12, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %ld1529 = load i32, ptr %p1528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1529, ptr %slot207, align 8
  %v1530 = load i32, ptr %slot207, align 8
  %cv1531 = zext i32 %v1530 to i64
  %cond1532 = icmp ne i64 %cv1531, 0
  br i1 %cond1532, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  %v1533 = load i64, ptr %slot12, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i32 0, ptr %p1534, align 4, !alias.scope !3, !noalias !4
  %v1535 = load i64, ptr %slot19, align 8
  store i64 %v1535, ptr %slot208, align 8
  %v1536 = load i64, ptr %slot13, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %ld1538 = load i32, ptr %p1537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1538, ptr %slot209, align 8
  %v1539 = load i32, ptr %slot209, align 8
  %op1540 = and i32 %v1539, 28
  store i32 %op1540, ptr %slot210, align 8
  %v1541 = load i32, ptr %slot210, align 8
  %cv1542 = zext i32 %v1541 to i64
  %cond1543 = icmp ne i64 %cv1542, 0
  br i1 %cond1543, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v1544 = load i64, ptr %slot43, align 8
  store i64 %v1544, ptr %slot211, align 8
  %v1545 = load i64, ptr %slot211, align 8
  %v1546 = load i64, ptr %slot208, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1545, i64 %v1546) nomerge, !dbg !120
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v1547 = load i64, ptr %slot208, align 8
  %p1549 = inttoptr i64 %v1547 to ptr
  %gep1550 = getelementptr i8, ptr %p1549, i64 8
  %op1548 = ptrtoint ptr %gep1550 to i64
  store i64 %op1548, ptr %slot212, align 8
  %v1551 = load i64, ptr %slot43, align 8
  store i64 %v1551, ptr %slot213, align 8
  %v1552 = load i64, ptr %slot212, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  %ld1554 = load i64, ptr %p1553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1554, ptr %slot214, align 8
  %v1555 = load i64, ptr %slot214, align 8
  %cmp1556 = icmp ne i64 %v1555, 0
  %cv1557 = zext i1 %cmp1556 to i32
  store i32 %cv1557, ptr %slot215, align 8
  %v1558 = load i32, ptr %slot215, align 8
  %cv1559 = zext i32 %v1558 to i64
  %cond1560 = icmp ne i64 %cv1559, 0
  br i1 %cond1560, label %bb_rcgnn259, label %bb_rcgdone259
bb_rcgnn259:
  %v1561 = load i64, ptr %slot214, align 8
  %op1562 = sub i64 %v1561, 16
  store i64 %op1562, ptr %slot216, align 8
  %v1563 = load i64, ptr %slot214, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %rgep1565 = getelementptr i8, ptr %p1564, i64 -16
  %ld1566 = load i64, ptr %rgep1565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1566, ptr %slot217, align 8
  %v1567 = load i64, ptr %slot217, align 8
  %op1568 = and i64 %v1567, 4611686018427387906
  store i64 %op1568, ptr %slot218, align 8
  %v1569 = load i64, ptr %slot218, align 8
  %cmp1570 = icmp ne i64 %v1569, 0
  %cv1571 = zext i1 %cmp1570 to i32
  store i32 %cv1571, ptr %slot219, align 8
  %v1572 = load i32, ptr %slot219, align 8
  %cv1573 = zext i32 %v1572 to i64
  %cond1574 = icmp ne i64 %cv1573, 0
  br i1 %cond1574, label %bb_rcgclear259, label %bb_rcgcounted259
bb_rcgcounted259:
  %v1575 = load i64, ptr %slot214, align 8
  %op1576 = sub i64 %v1575, 32
  store i64 %op1576, ptr %slot220, align 8
  %v1577 = load i64, ptr %slot214, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %rgep1579 = getelementptr i8, ptr %p1578, i64 -32
  %ld1580 = load i64, ptr %rgep1579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1580, ptr %slot221, align 8
  %v1581 = load i64, ptr %slot221, align 8
  %op1582 = sub i64 %v1581, 1
  store i64 %op1582, ptr %slot222, align 8
  %v1583 = load i64, ptr %slot222, align 8
  %cmp1584 = icmp eq i64 %v1583, 0
  %cv1585 = zext i1 %cmp1584 to i32
  store i32 %cv1585, ptr %slot223, align 8
  %v1586 = load i32, ptr %slot223, align 8
  %cv1587 = zext i32 %v1586 to i64
  %cond1588 = icmp ne i64 %cv1587, 0
  br i1 %cond1588, label %bb_rcglast259, label %bb_rcgdec259
bb_rcglast259:
  %v1589 = load i64, ptr %slot214, align 8
  %op1590 = sub i64 %v1589, 24
  store i64 %op1590, ptr %slot224, align 8
  %v1591 = load i64, ptr %slot214, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %rgep1593 = getelementptr i8, ptr %p1592, i64 -24
  %ld1594 = load i64, ptr %rgep1593, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1594, ptr %slot225, align 8
  %v1595 = load i64, ptr %slot225, align 8
  %cmp1596 = icmp ne i64 %v1595, 0
  %cv1597 = zext i1 %cmp1596 to i32
  store i32 %cv1597, ptr %slot226, align 8
  %v1598 = load i32, ptr %slot226, align 8
  %cv1599 = zext i32 %v1598 to i64
  %cond1600 = icmp ne i64 %cv1599, 0
  br i1 %cond1600, label %bb_rcgdec259, label %bb_rcgslow259
bb_rcgslow259:
  %v1601 = load i64, ptr %slot213, align 8
  %v1602 = load i64, ptr %slot212, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1601, i64 %v1602) nomerge, !dbg !120
  br label %bb_rcgdone259
bb_rcgdec259:
  %v1603 = load i64, ptr %slot222, align 8
  %v1604 = load i64, ptr %slot214, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  %rgep1606 = getelementptr i8, ptr %p1605, i64 -32
  store i64 %v1603, ptr %rgep1606, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear259
bb_rcgclear259:
  %v1607 = load i64, ptr %slot212, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  store i64 0, ptr %p1608, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone259
bb_rcgdone259:
  %v1609 = load i64, ptr %slot208, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  store i64 0, ptr %p1610, align 8, !alias.scope !3, !noalias !4
  %v1611 = load i64, ptr %slot208, align 8
  %p1613 = inttoptr i64 %v1611 to ptr
  %gep1614 = getelementptr i8, ptr %p1613, i64 8
  %op1612 = ptrtoint ptr %gep1614 to i64
  store i64 %op1612, ptr %slot227, align 8
  %v1615 = load i64, ptr %slot227, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  store i64 0, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  %v1617 = load i64, ptr %slot208, align 8
  %p1619 = inttoptr i64 %v1617 to ptr
  %gep1620 = getelementptr i8, ptr %p1619, i64 16
  %op1618 = ptrtoint ptr %gep1620 to i64
  store i64 %op1618, ptr %slot228, align 8
  %v1621 = load i64, ptr %slot228, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i64 0, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone241
bb_rcslotdone241:
  br label %bb_rcprivateprepared205
bb_rcprivateprepared205:
  %v1623 = load i64, ptr %slot8, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i32, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1625, ptr %slot229, align 8
  %v1626 = load i32, ptr %slot229, align 8
  %cv1627 = zext i32 %v1626 to i64
  %cond1628 = icmp ne i64 %cv1627, 0
  br i1 %cond1628, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v1629 = load i64, ptr %slot8, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  store i32 0, ptr %p1630, align 4, !alias.scope !3, !noalias !4
  %v1631 = load i64, ptr %slot29, align 8
  store i64 %v1631, ptr %slot230, align 8
  %v1632 = load i64, ptr %slot9, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot231, align 8
  %v1635 = load i32, ptr %slot231, align 8
  %op1636 = and i32 %v1635, 28
  store i32 %op1636, ptr %slot232, align 8
  %v1637 = load i32, ptr %slot232, align 8
  %cv1638 = zext i32 %v1637 to i64
  %cond1639 = icmp ne i64 %cv1638, 0
  br i1 %cond1639, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v1640 = load i64, ptr %slot43, align 8
  store i64 %v1640, ptr %slot233, align 8
  %v1641 = load i64, ptr %slot233, align 8
  %v1642 = load i64, ptr %slot230, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1641, i64 %v1642) nomerge, !dbg !120
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v1643 = load i64, ptr %slot230, align 8
  %p1645 = inttoptr i64 %v1643 to ptr
  %gep1646 = getelementptr i8, ptr %p1645, i64 8
  %op1644 = ptrtoint ptr %gep1646 to i64
  store i64 %op1644, ptr %slot234, align 8
  %v1647 = load i64, ptr %slot43, align 8
  store i64 %v1647, ptr %slot235, align 8
  %v1648 = load i64, ptr %slot234, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot236, align 8
  %v1651 = load i64, ptr %slot236, align 8
  %cmp1652 = icmp ne i64 %v1651, 0
  %cv1653 = zext i1 %cmp1652 to i32
  store i32 %cv1653, ptr %slot237, align 8
  %v1654 = load i32, ptr %slot237, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcgnn286, label %bb_rcgdone286
bb_rcgnn286:
  %v1657 = load i64, ptr %slot236, align 8
  %op1658 = sub i64 %v1657, 16
  store i64 %op1658, ptr %slot238, align 8
  %v1659 = load i64, ptr %slot236, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %rgep1661 = getelementptr i8, ptr %p1660, i64 -16
  %ld1662 = load i64, ptr %rgep1661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1662, ptr %slot239, align 8
  %v1663 = load i64, ptr %slot239, align 8
  %op1664 = and i64 %v1663, 4611686018427387906
  store i64 %op1664, ptr %slot240, align 8
  %v1665 = load i64, ptr %slot240, align 8
  %cmp1666 = icmp ne i64 %v1665, 0
  %cv1667 = zext i1 %cmp1666 to i32
  store i32 %cv1667, ptr %slot241, align 8
  %v1668 = load i32, ptr %slot241, align 8
  %cv1669 = zext i32 %v1668 to i64
  %cond1670 = icmp ne i64 %cv1669, 0
  br i1 %cond1670, label %bb_rcgclear286, label %bb_rcgcounted286
bb_rcgcounted286:
  %v1671 = load i64, ptr %slot236, align 8
  %op1672 = sub i64 %v1671, 32
  store i64 %op1672, ptr %slot242, align 8
  %v1673 = load i64, ptr %slot236, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  %rgep1675 = getelementptr i8, ptr %p1674, i64 -32
  %ld1676 = load i64, ptr %rgep1675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1676, ptr %slot243, align 8
  %v1677 = load i64, ptr %slot243, align 8
  %op1678 = sub i64 %v1677, 1
  store i64 %op1678, ptr %slot244, align 8
  %v1679 = load i64, ptr %slot244, align 8
  %cmp1680 = icmp eq i64 %v1679, 0
  %cv1681 = zext i1 %cmp1680 to i32
  store i32 %cv1681, ptr %slot245, align 8
  %v1682 = load i32, ptr %slot245, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcglast286, label %bb_rcgdec286
bb_rcglast286:
  %v1685 = load i64, ptr %slot236, align 8
  %op1686 = sub i64 %v1685, 24
  store i64 %op1686, ptr %slot246, align 8
  %v1687 = load i64, ptr %slot236, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  %rgep1689 = getelementptr i8, ptr %p1688, i64 -24
  %ld1690 = load i64, ptr %rgep1689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1690, ptr %slot247, align 8
  %v1691 = load i64, ptr %slot247, align 8
  %cmp1692 = icmp ne i64 %v1691, 0
  %cv1693 = zext i1 %cmp1692 to i32
  store i32 %cv1693, ptr %slot248, align 8
  %v1694 = load i32, ptr %slot248, align 8
  %cv1695 = zext i32 %v1694 to i64
  %cond1696 = icmp ne i64 %cv1695, 0
  br i1 %cond1696, label %bb_rcgdec286, label %bb_rcgslow286
bb_rcgslow286:
  %v1697 = load i64, ptr %slot235, align 8
  %v1698 = load i64, ptr %slot234, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1697, i64 %v1698) nomerge, !dbg !120
  br label %bb_rcgdone286
bb_rcgdec286:
  %v1699 = load i64, ptr %slot244, align 8
  %v1700 = load i64, ptr %slot236, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  %rgep1702 = getelementptr i8, ptr %p1701, i64 -32
  store i64 %v1699, ptr %rgep1702, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear286
bb_rcgclear286:
  %v1703 = load i64, ptr %slot234, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i64 0, ptr %p1704, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone286
bb_rcgdone286:
  %v1705 = load i64, ptr %slot230, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i64 0, ptr %p1706, align 8, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot230, align 8
  %p1709 = inttoptr i64 %v1707 to ptr
  %gep1710 = getelementptr i8, ptr %p1709, i64 8
  %op1708 = ptrtoint ptr %gep1710 to i64
  store i64 %op1708, ptr %slot249, align 8
  %v1711 = load i64, ptr %slot249, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i64 0, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot230, align 8
  %p1715 = inttoptr i64 %v1713 to ptr
  %gep1716 = getelementptr i8, ptr %p1715, i64 16
  %op1714 = ptrtoint ptr %gep1716 to i64
  store i64 %op1714, ptr %slot250, align 8
  %v1717 = load i64, ptr %slot250, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i64 0, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v1719 = load i64, ptr %slot29, align 8
  store i64 %v1719, ptr %slot251, align 8
  %v1720 = load i64, ptr %slot21, align 8
  store i64 %v1720, ptr %slot252, align 8
  %v1721 = load i64, ptr %slot252, align 8
  %v1722 = load i64, ptr %slot251, align 8
  %p1723 = inttoptr i64 %v1721 to ptr
  %p1724 = inttoptr i64 %v1722 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1724, ptr %p1723, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot16, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i32 0, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot9, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 2, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot17, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i32, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1731, ptr %slot253, align 8
  %v1732 = load i32, ptr %slot253, align 8
  %v1733 = load i64, ptr %slot9, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 %v1732, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot8, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i32 1, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  %v1737 = load i64, ptr %slot29, align 8
  %v1738 = load i64, ptr %slot34, align 8
  %p1739 = inttoptr i64 %v1738 to ptr
  store i64 %v1737, ptr %p1739, align 8, !alias.scope !3, !noalias !4
  %v1740 = load i64, ptr %slot30, align 8
  %v1741 = load i64, ptr %slot35, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i64 %v1740, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot35, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot254, align 8
  %v1746 = load i64, ptr %slot14, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i32, ptr %p1747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1748, ptr %slot255, align 8
  %v1749 = load i64, ptr %slot15, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i32, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1751, ptr %slot256, align 8
  %v1752 = load i32, ptr %slot256, align 8
  %op1753 = and i32 %v1752, 24
  store i32 %op1753, ptr %slot256, align 8
  %v1754 = load i32, ptr %slot256, align 8
  %cmp1755 = icmp eq i32 %v1754, 0
  %cv1756 = zext i1 %cmp1755 to i32
  store i32 %cv1756, ptr %slot257, align 8
  %v1757 = load i32, ptr %slot255, align 8
  %v1758 = load i32, ptr %slot257, align 8
  %op1759 = and i32 %v1757, %v1758
  store i32 %op1759, ptr %slot258, align 8
  %v1760 = load i64, ptr %slot44, align 8
  store i64 %v1760, ptr %slot259, align 8
  %v1761 = load i32, ptr %slot258, align 8
  %op1762 = mul i32 %v1761, 4
  store i32 %op1762, ptr %slot260, align 8
  %v1763 = load i32, ptr %slot260, align 8
  %op1764 = or i32 %v1763, 0
  store i32 %op1764, ptr %slot261, align 8
  %v1765 = load i64, ptr %slot21, align 8
  store i64 %v1765, ptr %slot262, align 8
  %v1766 = load i64, ptr %slot43, align 8
  %v1767 = load i64, ptr %slot262, align 8
  %v1768 = load i64, ptr %slot254, align 8
  %v1769 = load i64, ptr %slot259, align 8
  %cv1770 = trunc i64 %v1769 to i32
  %v1771 = load i32, ptr %slot261, align 8
  %call1772 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64 %v1766, i64 %v1767, i64 %v1768, i32 %cv1770, i32 %v1771) nomerge, !dbg !122
  store i32 %call1772, ptr %slot263, align 8
  %v1773 = load i32, ptr %slot263, align 8
  %cv1774 = zext i32 %v1773 to i64
  %cond1775 = icmp ne i64 %cv1774, 0
  br i1 %cond1775, label %bb_rcsuccess313, label %bb_rcfailure313
bb_rcfailure313:
  %v1776 = load i64, ptr %slot43, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %call1778 = call i32 @myl_rc_take_failure(ptr %p1777) nomerge, !dbg !122
  store i32 %call1778, ptr %slot264, align 8
  %v1779 = load i64, ptr %slot1, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %v1781 = load i32, ptr %slot264, align 8
  %call1782 = call i32 @myl_qbe_rc_status(ptr %p1780, i32 %v1781) nomerge, !dbg !122
  store i32 %call1782, ptr %slot265, align 8
  br label %bb_failure
bb_rcsuccess313:
  %v1783 = load i32, ptr %slot258, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rchtaken316, label %bb_rchcopied316
bb_rchcopied316:
  %v1786 = load i64, ptr %slot14, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  %ld1788 = load i32, ptr %p1787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1788, ptr %slot266, align 8
  %v1789 = load i32, ptr %slot266, align 8
  %cv1790 = zext i32 %v1789 to i64
  %cond1791 = icmp ne i64 %cv1790, 0
  br i1 %cond1791, label %bb_rcslotdrop319, label %bb_rcslotdone319
bb_rcslotdrop319:
  %v1792 = load i64, ptr %slot14, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  store i32 0, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  %v1794 = load i64, ptr %slot20, align 8
  store i64 %v1794, ptr %slot267, align 8
  %v1795 = load i64, ptr %slot15, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  %ld1797 = load i32, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1797, ptr %slot268, align 8
  %v1798 = load i32, ptr %slot268, align 8
  %op1799 = and i32 %v1798, 28
  store i32 %op1799, ptr %slot269, align 8
  %v1800 = load i32, ptr %slot269, align 8
  %cv1801 = zext i32 %v1800 to i64
  %cond1802 = icmp ne i64 %cv1801, 0
  br i1 %cond1802, label %bb_rcslotrole319, label %bb_rcslotowner319
bb_rcslotrole319:
  %v1803 = load i64, ptr %slot43, align 8
  store i64 %v1803, ptr %slot270, align 8
  %v1804 = load i64, ptr %slot270, align 8
  %v1805 = load i64, ptr %slot267, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1804, i64 %v1805) nomerge, !dbg !122
  br label %bb_rcslotdone319
bb_rcslotowner319:
  %v1806 = load i64, ptr %slot43, align 8
  store i64 %v1806, ptr %slot271, align 8
  %v1807 = load i64, ptr %slot271, align 8
  %v1808 = load i64, ptr %slot267, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v1807, i64 %v1808) nomerge, !dbg !122
  br label %bb_rcslotdone319
bb_rcslotdone319:
  br label %bb_rchprepared316
bb_rchtaken316:
  %v1809 = load i64, ptr %slot14, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 0, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared316
bb_rchprepared316:
  %v1811 = load i64, ptr %slot17, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i32 2, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot16, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 1, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot20, align 8
  store i64 %v1815, ptr %slot272, align 8
  %v1816 = load i64, ptr %slot21, align 8
  store i64 %v1816, ptr %slot273, align 8
  %v1817 = load i64, ptr %slot273, align 8
  %v1818 = load i64, ptr %slot272, align 8
  %p1819 = inttoptr i64 %v1817 to ptr
  %p1820 = inttoptr i64 %v1818 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1820, ptr %p1819, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot15, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i32 2, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot17, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %ld1825 = load i32, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1825, ptr %slot274, align 8
  %v1826 = load i32, ptr %slot274, align 8
  %v1827 = load i64, ptr %slot15, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i32 %v1826, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  %v1829 = load i64, ptr %slot16, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i32 0, ptr %p1830, align 4, !alias.scope !3, !noalias !4
  %v1831 = load i64, ptr %slot14, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 1, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot272, align 8
  %v1834 = load i64, ptr %slot35, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  store i64 %v1833, ptr %p1835, align 8, !alias.scope !3, !noalias !4
  %v1836 = load i64, ptr %slot34, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot275, align 8
  %v1839 = load i64, ptr %slot12, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  %ld1841 = load i32, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1841, ptr %slot276, align 8
  %v1842 = load i64, ptr %slot13, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  %ld1844 = load i32, ptr %p1843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1844, ptr %slot277, align 8
  %v1845 = load i32, ptr %slot277, align 8
  %op1846 = and i32 %v1845, 24
  store i32 %op1846, ptr %slot277, align 8
  %v1847 = load i32, ptr %slot277, align 8
  %cmp1848 = icmp eq i32 %v1847, 0
  %cv1849 = zext i1 %cmp1848 to i32
  store i32 %cv1849, ptr %slot278, align 8
  %v1850 = load i32, ptr %slot276, align 8
  %v1851 = load i32, ptr %slot278, align 8
  %op1852 = and i32 %v1850, %v1851
  store i32 %op1852, ptr %slot279, align 8
  %v1853 = load i32, ptr %slot279, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rctake338, label %bb_rccopy338
bb_rctake338:
  %v1856 = load i64, ptr %slot21, align 8
  store i64 %v1856, ptr %slot280, align 8
  %v1857 = load i64, ptr %slot44, align 8
  store i64 %v1857, ptr %slot281, align 8
  %v1858 = load i64, ptr %slot275, align 8
  %v1859 = load i64, ptr %slot280, align 8
  %op1860 = sub i64 %v1858, %v1859
  store i64 %op1860, ptr %slot282, align 8
  %v1861 = load i64, ptr %slot280, align 8
  %v1862 = load i64, ptr %slot275, align 8
  %op1863 = sub i64 %v1861, %v1862
  store i64 %op1863, ptr %slot283, align 8
  %v1864 = load i64, ptr %slot282, align 8
  %cmp1865 = icmp ult i64 %v1864, 24
  %cv1866 = zext i1 %cmp1865 to i32
  store i32 %cv1866, ptr %slot284, align 8
  %v1867 = load i64, ptr %slot283, align 8
  %cmp1868 = icmp ult i64 %v1867, 24
  %cv1869 = zext i1 %cmp1868 to i32
  store i32 %cv1869, ptr %slot285, align 8
  %v1870 = load i32, ptr %slot284, align 8
  %v1871 = load i32, ptr %slot285, align 8
  %op1872 = or i32 %v1870, %v1871
  store i32 %op1872, ptr %slot286, align 8
  %v1873 = load i32, ptr %slot286, align 8
  %cv1874 = zext i32 %v1873 to i64
  %cond1875 = icmp ne i64 %cv1874, 0
  br i1 %cond1875, label %bb_rcmoveslow347, label %bb_rcmovecheck347
bb_rcmovecheck347:
  %v1876 = load i64, ptr %slot275, align 8
  %op1877 = add i64 %v1876, 8
  store i64 %op1877, ptr %slot287, align 8
  %v1878 = load i64, ptr %slot287, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i64, ptr %p1879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1880, ptr %slot288, align 8
  %v1881 = load i64, ptr %slot288, align 8
  %cmp1882 = icmp ne i64 %v1881, 0
  %cv1883 = zext i1 %cmp1882 to i32
  store i32 %cv1883, ptr %slot289, align 8
  %v1884 = load i32, ptr %slot289, align 8
  %cv1885 = zext i32 %v1884 to i64
  %cond1886 = icmp ne i64 %cv1885, 0
  br i1 %cond1886, label %bb_rcmoveheader355, label %bb_rcmovenext355
bb_rcmoveheader355:
  %v1887 = load i64, ptr %slot288, align 8
  %op1888 = sub i64 %v1887, 16
  store i64 %op1888, ptr %slot290, align 8
  %v1889 = load i64, ptr %slot288, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  %rgep1891 = getelementptr i8, ptr %p1890, i64 -16
  %ld1892 = load i64, ptr %rgep1891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1892, ptr %slot291, align 8
  %v1893 = load i64, ptr %slot291, align 8
  %op1894 = and i64 %v1893, 5764607523034234881
  store i64 %op1894, ptr %slot292, align 8
  %v1895 = load i64, ptr %slot292, align 8
  %cmp1896 = icmp ne i64 %v1895, 0
  %cv1897 = zext i1 %cmp1896 to i32
  store i32 %cv1897, ptr %slot293, align 8
  %v1898 = load i32, ptr %slot293, align 8
  %cv1899 = zext i32 %v1898 to i64
  %cond1900 = icmp ne i64 %cv1899, 0
  br i1 %cond1900, label %bb_rcmoveslow347, label %bb_rcmovenext355
bb_rcmovenext355:
  %v1901 = load i64, ptr %slot275, align 8
  %v1902 = load i64, ptr %slot280, align 8
  %p1903 = inttoptr i64 %v1901 to ptr
  %p1904 = inttoptr i64 %v1902 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1904, ptr %p1903, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot275, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i64 0, ptr %p1906, align 8, !alias.scope !3, !noalias !4
  %v1907 = load i64, ptr %slot275, align 8
  %op1908 = add i64 %v1907, 8
  store i64 %op1908, ptr %slot294, align 8
  %v1909 = load i64, ptr %slot294, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i64 0, ptr %p1910, align 8, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot275, align 8
  %op1912 = add i64 %v1911, 16
  store i64 %op1912, ptr %slot295, align 8
  %v1913 = load i64, ptr %slot295, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i64 0, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved347
bb_rcmoveslow347:
  %v1915 = load i64, ptr %slot43, align 8
  %v1916 = load i64, ptr %slot280, align 8
  %v1917 = load i64, ptr %slot275, align 8
  %v1918 = load i64, ptr %slot281, align 8
  %cv1919 = trunc i64 %v1918 to i32
  %call1920 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1915, i64 %v1916, i64 %v1917, i32 %cv1919) nomerge, !dbg !124
  store i32 %call1920, ptr %slot296, align 8
  %v1921 = load i32, ptr %slot296, align 8
  %cv1922 = zext i32 %v1921 to i64
  %cond1923 = icmp ne i64 %cv1922, 0
  br i1 %cond1923, label %bb_rcsuccess364, label %bb_rcfailure364
bb_rcfailure364:
  %v1924 = load i64, ptr %slot43, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %call1926 = call i32 @myl_rc_take_failure(ptr %p1925) nomerge, !dbg !124
  store i32 %call1926, ptr %slot297, align 8
  %v1927 = load i64, ptr %slot1, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %v1929 = load i32, ptr %slot297, align 8
  %call1930 = call i32 @myl_qbe_rc_status(ptr %p1928, i32 %v1929) nomerge, !dbg !124
  store i32 %call1930, ptr %slot298, align 8
  br label %bb_failure
bb_rcsuccess364:
  br label %bb_rcmoved347
bb_rcmoved347:
  %v1931 = load i64, ptr %slot12, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i32 0, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot17, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i32 2, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  %v1935 = load i64, ptr %slot16, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i32 1, ptr %p1936, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared338
bb_rccopy338:
  %v1937 = load i64, ptr %slot21, align 8
  store i64 %v1937, ptr %slot299, align 8
  %v1938 = load i64, ptr %slot44, align 8
  store i64 %v1938, ptr %slot300, align 8
  %v1939 = load i64, ptr %slot43, align 8
  %v1940 = load i64, ptr %slot299, align 8
  %v1941 = load i64, ptr %slot275, align 8
  %v1942 = load i64, ptr %slot300, align 8
  %cv1943 = trunc i64 %v1942 to i32
  %call1944 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v1939, i64 %v1940, i64 %v1941, i32 %cv1943) nomerge, !dbg !124
  store i32 %call1944, ptr %slot301, align 8
  %v1945 = load i32, ptr %slot301, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcsuccess373, label %bb_rcfailure373
bb_rcfailure373:
  %v1948 = load i64, ptr %slot43, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  %call1950 = call i32 @myl_rc_take_failure(ptr %p1949) nomerge, !dbg !124
  store i32 %call1950, ptr %slot302, align 8
  %v1951 = load i64, ptr %slot1, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %v1953 = load i32, ptr %slot302, align 8
  %call1954 = call i32 @myl_qbe_rc_status(ptr %p1952, i32 %v1953) nomerge, !dbg !124
  store i32 %call1954, ptr %slot303, align 8
  br label %bb_failure
bb_rcsuccess373:
  %v1955 = load i64, ptr %slot17, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i32 2, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot16, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i32 1, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot12, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i32, ptr %p1960, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1961, ptr %slot304, align 8
  %v1962 = load i32, ptr %slot304, align 8
  %cv1963 = zext i32 %v1962 to i64
  %cond1964 = icmp ne i64 %cv1963, 0
  br i1 %cond1964, label %bb_rcslotdrop380, label %bb_rcslotdone380
bb_rcslotdrop380:
  %v1965 = load i64, ptr %slot12, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i32 0, ptr %p1966, align 4, !alias.scope !3, !noalias !4
  %v1967 = load i64, ptr %slot19, align 8
  store i64 %v1967, ptr %slot305, align 8
  %v1968 = load i64, ptr %slot13, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  %ld1970 = load i32, ptr %p1969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1970, ptr %slot306, align 8
  %v1971 = load i32, ptr %slot306, align 8
  %op1972 = and i32 %v1971, 28
  store i32 %op1972, ptr %slot307, align 8
  %v1973 = load i32, ptr %slot307, align 8
  %cv1974 = zext i32 %v1973 to i64
  %cond1975 = icmp ne i64 %cv1974, 0
  br i1 %cond1975, label %bb_rcslotrole380, label %bb_rcslotowner380
bb_rcslotrole380:
  %v1976 = load i64, ptr %slot43, align 8
  store i64 %v1976, ptr %slot308, align 8
  %v1977 = load i64, ptr %slot308, align 8
  %v1978 = load i64, ptr %slot305, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1977, i64 %v1978) nomerge, !dbg !124
  br label %bb_rcslotdone380
bb_rcslotowner380:
  %v1979 = load i64, ptr %slot43, align 8
  store i64 %v1979, ptr %slot309, align 8
  %v1980 = load i64, ptr %slot309, align 8
  %v1981 = load i64, ptr %slot305, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v1980, i64 %v1981) nomerge, !dbg !124
  br label %bb_rcslotdone380
bb_rcslotdone380:
  br label %bb_rcprepared338
bb_rcprepared338:
  %v1982 = load i64, ptr %slot21, align 8
  store i64 %v1982, ptr %slot310, align 8
  %v1983 = load i64, ptr %slot36, align 8
  store i64 %v1983, ptr %slot311, align 8
  %v1984 = load i64, ptr %slot310, align 8
  %v1985 = load i64, ptr %slot311, align 8
  %p1986 = inttoptr i64 %v1984 to ptr
  %p1987 = inttoptr i64 %v1985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1987, ptr %p1986, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1988 = load i64, ptr %slot16, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  store i32 0, ptr %p1989, align 4, !alias.scope !3, !noalias !4
  %v1990 = load i64, ptr %slot18, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  store i32 1, ptr %p1991, align 4, !alias.scope !3, !noalias !4
  %v1992 = load i64, ptr %slot44, align 8
  store i64 %v1992, ptr %slot312, align 8
  %v1993 = load i64, ptr %slot35, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %ld1995 = load i64, ptr %p1994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1995, ptr %slot313, align 8
  %v1996 = load i64, ptr %slot311, align 8
  %p1998 = inttoptr i64 %v1996 to ptr
  %gep1999 = getelementptr i8, ptr %p1998, i64 8
  %op1997 = ptrtoint ptr %gep1999 to i64
  store i64 %op1997, ptr %slot314, align 8
  %v2000 = load i64, ptr %slot21, align 8
  store i64 %v2000, ptr %slot315, align 8
  %v2001 = load i64, ptr %slot35, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %ld2003 = load i64, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2003, ptr %slot316, align 8
  %v2004 = load i64, ptr %slot21, align 8
  store i64 %v2004, ptr %slot317, align 8
  %v2005 = load i64, ptr %slot44, align 8
  store i64 %v2005, ptr %slot318, align 8
  %v2006 = load i64, ptr %slot316, align 8
  %op2007 = add i64 %v2006, 0
  store i64 %op2007, ptr %slot319, align 8
  %v2008 = load i64, ptr %slot319, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i64, ptr %p2009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2010, ptr %slot320, align 8
  %v2011 = load i64, ptr %slot320, align 8
  %cmp2012 = icmp ne i64 %v2011, 0
  %cv2013 = zext i1 %cmp2012 to i32
  store i32 %cv2013, ptr %slot321, align 8
  %v2014 = load i32, ptr %slot321, align 8
  %cv2015 = zext i32 %v2014 to i64
  %cond2016 = icmp ne i64 %cv2015, 0
  br i1 %cond2016, label %bb_rcmoveheader402, label %bb_rcmovenext402
bb_rcmoveheader402:
  %v2017 = load i64, ptr %slot320, align 8
  %op2018 = sub i64 %v2017, 16
  store i64 %op2018, ptr %slot322, align 8
  %v2019 = load i64, ptr %slot320, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %rgep2021 = getelementptr i8, ptr %p2020, i64 -16
  %ld2022 = load i64, ptr %rgep2021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2022, ptr %slot323, align 8
  %v2023 = load i64, ptr %slot323, align 8
  %op2024 = and i64 %v2023, 5764607523034234881
  store i64 %op2024, ptr %slot324, align 8
  %v2025 = load i64, ptr %slot324, align 8
  %cmp2026 = icmp ne i64 %v2025, 0
  %cv2027 = zext i1 %cmp2026 to i32
  store i32 %cv2027, ptr %slot325, align 8
  %v2028 = load i32, ptr %slot325, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcmoveslow399, label %bb_rcmovenext402
bb_rcmovenext402:
  %v2031 = load i64, ptr %slot316, align 8
  %v2032 = load i64, ptr %slot317, align 8
  %p2033 = inttoptr i64 %v2031 to ptr
  %p2034 = inttoptr i64 %v2032 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2034, ptr %p2033, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot316, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  store i64 0, ptr %p2036, align 8, !alias.scope !3, !noalias !4
  %v2037 = load i64, ptr %slot316, align 8
  %op2038 = add i64 %v2037, 8
  store i64 %op2038, ptr %slot326, align 8
  %v2039 = load i64, ptr %slot326, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i64 0, ptr %p2040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved399
bb_rcmoveslow399:
  %v2041 = load i64, ptr %slot43, align 8
  %v2042 = load i64, ptr %slot317, align 8
  %v2043 = load i64, ptr %slot316, align 8
  %v2044 = load i64, ptr %slot318, align 8
  %cv2045 = trunc i64 %v2044 to i32
  %call2046 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2041, i64 %v2042, i64 %v2043, i32 %cv2045) nomerge, !dbg !124
  store i32 %call2046, ptr %slot327, align 8
  %v2047 = load i32, ptr %slot327, align 8
  %cv2048 = zext i32 %v2047 to i64
  %cond2049 = icmp ne i64 %cv2048, 0
  br i1 %cond2049, label %bb_rcsuccess410, label %bb_rcfailure410
bb_rcfailure410:
  %v2050 = load i64, ptr %slot43, align 8
  %p2051 = inttoptr i64 %v2050 to ptr
  %call2052 = call i32 @myl_rc_take_failure(ptr %p2051) nomerge, !dbg !124
  store i32 %call2052, ptr %slot328, align 8
  %v2053 = load i64, ptr %slot1, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %v2055 = load i32, ptr %slot328, align 8
  %call2056 = call i32 @myl_qbe_rc_status(ptr %p2054, i32 %v2055) nomerge, !dbg !124
  store i32 %call2056, ptr %slot329, align 8
  br label %bb_failure
bb_rcsuccess410:
  br label %bb_rcmoved399
bb_rcmoved399:
  %v2057 = load i64, ptr %slot14, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i32 0, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot17, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  store i32 2, ptr %p2060, align 4, !alias.scope !3, !noalias !4
  %v2061 = load i64, ptr %slot16, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i32 1, ptr %p2062, align 4, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot21, align 8
  store i64 %v2063, ptr %slot330, align 8
  %v2064 = load i64, ptr %slot330, align 8
  %v2065 = load i64, ptr %slot315, align 8
  %p2066 = inttoptr i64 %v2064 to ptr
  %p2067 = inttoptr i64 %v2065 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2067, ptr %p2066, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot16, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  store i32 0, ptr %p2069, align 4, !alias.scope !3, !noalias !4
  %v2070 = load i64, ptr %slot17, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i32 2, ptr %p2071, align 4, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot16, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i32 1, ptr %p2073, align 4, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot43, align 8
  store i64 %v2074, ptr %slot331, align 8
  %v2075 = load i64, ptr %slot331, align 8
  %v2076 = load i64, ptr %slot314, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2075, i64 %v2076) nomerge, !dbg !124
  %v2077 = load i64, ptr %slot315, align 8
  %v2078 = load i64, ptr %slot314, align 8
  %p2079 = inttoptr i64 %v2077 to ptr
  %p2080 = inttoptr i64 %v2078 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2080, ptr %p2079, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot16, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 0, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot311, align 8
  %v2084 = load i64, ptr %slot34, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i64 %v2083, ptr %p2085, align 8, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot34, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %ld2088 = load i64, ptr %p2087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2088, ptr %slot332, align 8
  %v2089 = load i64, ptr %slot21, align 8
  store i64 %v2089, ptr %slot333, align 8
  %v2090 = load i64, ptr %slot332, align 8
  %v2091 = load i64, ptr %slot333, align 8
  %p2092 = inttoptr i64 %v2090 to ptr
  %p2093 = inttoptr i64 %v2091 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2093, ptr %p2092, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot17, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 2, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot16, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 1, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot12, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i32, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2100, ptr %slot334, align 8
  %v2101 = load i32, ptr %slot334, align 8
  %cv2102 = zext i32 %v2101 to i64
  %cond2103 = icmp ne i64 %cv2102, 0
  br i1 %cond2103, label %bb_rcslotdrop428, label %bb_rcslotdone428
bb_rcslotdrop428:
  %v2104 = load i64, ptr %slot12, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 0, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot19, align 8
  store i64 %v2106, ptr %slot335, align 8
  %v2107 = load i64, ptr %slot13, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i32, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2109, ptr %slot336, align 8
  %v2110 = load i32, ptr %slot336, align 8
  %op2111 = and i32 %v2110, 28
  store i32 %op2111, ptr %slot337, align 8
  %v2112 = load i32, ptr %slot337, align 8
  %cv2113 = zext i32 %v2112 to i64
  %cond2114 = icmp ne i64 %cv2113, 0
  br i1 %cond2114, label %bb_rcslotrole428, label %bb_rcslotowner428
bb_rcslotrole428:
  %v2115 = load i64, ptr %slot43, align 8
  store i64 %v2115, ptr %slot338, align 8
  %v2116 = load i64, ptr %slot338, align 8
  %v2117 = load i64, ptr %slot335, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2116, i64 %v2117) nomerge, !dbg !124
  br label %bb_rcslotdone428
bb_rcslotowner428:
  %v2118 = load i64, ptr %slot43, align 8
  store i64 %v2118, ptr %slot339, align 8
  %v2119 = load i64, ptr %slot339, align 8
  %v2120 = load i64, ptr %slot335, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2119, i64 %v2120) nomerge, !dbg !124
  br label %bb_rcslotdone428
bb_rcslotdone428:
  %v2121 = load i64, ptr %slot14, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  %ld2123 = load i32, ptr %p2122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2123, ptr %slot340, align 8
  %v2124 = load i32, ptr %slot340, align 8
  %cv2125 = zext i32 %v2124 to i64
  %cond2126 = icmp ne i64 %cv2125, 0
  br i1 %cond2126, label %bb_rcslotdrop437, label %bb_rcslotdone437
bb_rcslotdrop437:
  %v2127 = load i64, ptr %slot14, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  store i32 0, ptr %p2128, align 4, !alias.scope !3, !noalias !4
  %v2129 = load i64, ptr %slot20, align 8
  store i64 %v2129, ptr %slot341, align 8
  %v2130 = load i64, ptr %slot15, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  %ld2132 = load i32, ptr %p2131, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2132, ptr %slot342, align 8
  %v2133 = load i32, ptr %slot342, align 8
  %op2134 = and i32 %v2133, 28
  store i32 %op2134, ptr %slot343, align 8
  %v2135 = load i32, ptr %slot343, align 8
  %cv2136 = zext i32 %v2135 to i64
  %cond2137 = icmp ne i64 %cv2136, 0
  br i1 %cond2137, label %bb_rcslotrole437, label %bb_rcslotowner437
bb_rcslotrole437:
  %v2138 = load i64, ptr %slot43, align 8
  store i64 %v2138, ptr %slot344, align 8
  %v2139 = load i64, ptr %slot344, align 8
  %v2140 = load i64, ptr %slot341, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2139, i64 %v2140) nomerge, !dbg !124
  br label %bb_rcslotdone437
bb_rcslotowner437:
  %v2141 = load i64, ptr %slot43, align 8
  store i64 %v2141, ptr %slot345, align 8
  %v2142 = load i64, ptr %slot345, align 8
  %v2143 = load i64, ptr %slot341, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2142, i64 %v2143) nomerge, !dbg !124
  br label %bb_rcslotdone437
bb_rcslotdone437:
  %v2144 = load i64, ptr %slot19, align 8
  store i64 %v2144, ptr %slot346, align 8
  %v2145 = load i64, ptr %slot21, align 8
  store i64 %v2145, ptr %slot347, align 8
  %v2146 = load i64, ptr %slot347, align 8
  %v2147 = load i64, ptr %slot346, align 8
  %p2148 = inttoptr i64 %v2146 to ptr
  %p2149 = inttoptr i64 %v2147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2149, ptr %p2148, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot13, align 8
  %p2151 = inttoptr i64 %v2150 to ptr
  store i32 2, ptr %p2151, align 4, !alias.scope !3, !noalias !4
  %v2152 = load i64, ptr %slot17, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %ld2154 = load i32, ptr %p2153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2154, ptr %slot348, align 8
  %v2155 = load i32, ptr %slot348, align 8
  %v2156 = load i64, ptr %slot13, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  store i32 %v2155, ptr %p2157, align 4, !alias.scope !3, !noalias !4
  %v2158 = load i64, ptr %slot16, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  store i32 0, ptr %p2159, align 4, !alias.scope !3, !noalias !4
  %v2160 = load i64, ptr %slot12, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i32 1, ptr %p2161, align 4, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot346, align 8
  %v2163 = load i64, ptr %slot34, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  store i64 %v2162, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  %v2165 = load i64, ptr %slot34, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i64, ptr %p2166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2167, ptr %slot349, align 8
  %v2168 = load i64, ptr %slot12, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i32, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2170, ptr %slot350, align 8
  %v2171 = load i64, ptr %slot13, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i32, ptr %p2172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2173, ptr %slot351, align 8
  %v2174 = load i32, ptr %slot351, align 8
  %op2175 = and i32 %v2174, 24
  store i32 %op2175, ptr %slot351, align 8
  %v2176 = load i32, ptr %slot351, align 8
  %cmp2177 = icmp eq i32 %v2176, 0
  %cv2178 = zext i1 %cmp2177 to i32
  store i32 %cv2178, ptr %slot352, align 8
  %v2179 = load i32, ptr %slot350, align 8
  %v2180 = load i32, ptr %slot352, align 8
  %op2181 = and i32 %v2179, %v2180
  store i32 %op2181, ptr %slot353, align 8
  %v2182 = load i32, ptr %slot353, align 8
  %cv2183 = zext i32 %v2182 to i64
  %cond2184 = icmp ne i64 %cv2183, 0
  br i1 %cond2184, label %bb_rctake453, label %bb_rccopy453
bb_rctake453:
  %v2185 = load i64, ptr %slot21, align 8
  store i64 %v2185, ptr %slot354, align 8
  %v2186 = load i64, ptr %slot44, align 8
  store i64 %v2186, ptr %slot355, align 8
  %v2187 = load i64, ptr %slot349, align 8
  %v2188 = load i64, ptr %slot354, align 8
  %op2189 = sub i64 %v2187, %v2188
  store i64 %op2189, ptr %slot356, align 8
  %v2190 = load i64, ptr %slot354, align 8
  %v2191 = load i64, ptr %slot349, align 8
  %op2192 = sub i64 %v2190, %v2191
  store i64 %op2192, ptr %slot357, align 8
  %v2193 = load i64, ptr %slot356, align 8
  %cmp2194 = icmp ult i64 %v2193, 24
  %cv2195 = zext i1 %cmp2194 to i32
  store i32 %cv2195, ptr %slot358, align 8
  %v2196 = load i64, ptr %slot357, align 8
  %cmp2197 = icmp ult i64 %v2196, 24
  %cv2198 = zext i1 %cmp2197 to i32
  store i32 %cv2198, ptr %slot359, align 8
  %v2199 = load i32, ptr %slot358, align 8
  %v2200 = load i32, ptr %slot359, align 8
  %op2201 = or i32 %v2199, %v2200
  store i32 %op2201, ptr %slot360, align 8
  %v2202 = load i32, ptr %slot360, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rcmoveslow462, label %bb_rcmovecheck462
bb_rcmovecheck462:
  %v2205 = load i64, ptr %slot349, align 8
  %op2206 = add i64 %v2205, 8
  store i64 %op2206, ptr %slot361, align 8
  %v2207 = load i64, ptr %slot361, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %ld2209 = load i64, ptr %p2208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2209, ptr %slot362, align 8
  %v2210 = load i64, ptr %slot362, align 8
  %cmp2211 = icmp ne i64 %v2210, 0
  %cv2212 = zext i1 %cmp2211 to i32
  store i32 %cv2212, ptr %slot363, align 8
  %v2213 = load i32, ptr %slot363, align 8
  %cv2214 = zext i32 %v2213 to i64
  %cond2215 = icmp ne i64 %cv2214, 0
  br i1 %cond2215, label %bb_rcmoveheader470, label %bb_rcmovenext470
bb_rcmoveheader470:
  %v2216 = load i64, ptr %slot362, align 8
  %op2217 = sub i64 %v2216, 16
  store i64 %op2217, ptr %slot364, align 8
  %v2218 = load i64, ptr %slot362, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %rgep2220 = getelementptr i8, ptr %p2219, i64 -16
  %ld2221 = load i64, ptr %rgep2220, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2221, ptr %slot365, align 8
  %v2222 = load i64, ptr %slot365, align 8
  %op2223 = and i64 %v2222, 5764607523034234881
  store i64 %op2223, ptr %slot366, align 8
  %v2224 = load i64, ptr %slot366, align 8
  %cmp2225 = icmp ne i64 %v2224, 0
  %cv2226 = zext i1 %cmp2225 to i32
  store i32 %cv2226, ptr %slot367, align 8
  %v2227 = load i32, ptr %slot367, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcmoveslow462, label %bb_rcmovenext470
bb_rcmovenext470:
  %v2230 = load i64, ptr %slot349, align 8
  %v2231 = load i64, ptr %slot354, align 8
  %p2232 = inttoptr i64 %v2230 to ptr
  %p2233 = inttoptr i64 %v2231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2233, ptr %p2232, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2234 = load i64, ptr %slot349, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i64 0, ptr %p2235, align 8, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot349, align 8
  %op2237 = add i64 %v2236, 8
  store i64 %op2237, ptr %slot368, align 8
  %v2238 = load i64, ptr %slot368, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  store i64 0, ptr %p2239, align 8, !alias.scope !3, !noalias !4
  %v2240 = load i64, ptr %slot349, align 8
  %op2241 = add i64 %v2240, 16
  store i64 %op2241, ptr %slot369, align 8
  %v2242 = load i64, ptr %slot369, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i64 0, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved462
bb_rcmoveslow462:
  %v2244 = load i64, ptr %slot43, align 8
  %v2245 = load i64, ptr %slot354, align 8
  %v2246 = load i64, ptr %slot349, align 8
  %v2247 = load i64, ptr %slot355, align 8
  %cv2248 = trunc i64 %v2247 to i32
  %call2249 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2244, i64 %v2245, i64 %v2246, i32 %cv2248) nomerge, !dbg !126
  store i32 %call2249, ptr %slot370, align 8
  %v2250 = load i32, ptr %slot370, align 8
  %cv2251 = zext i32 %v2250 to i64
  %cond2252 = icmp ne i64 %cv2251, 0
  br i1 %cond2252, label %bb_rcsuccess479, label %bb_rcfailure479
bb_rcfailure479:
  %v2253 = load i64, ptr %slot43, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %call2255 = call i32 @myl_rc_take_failure(ptr %p2254) nomerge, !dbg !126
  store i32 %call2255, ptr %slot371, align 8
  %v2256 = load i64, ptr %slot1, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %v2258 = load i32, ptr %slot371, align 8
  %call2259 = call i32 @myl_qbe_rc_status(ptr %p2257, i32 %v2258) nomerge, !dbg !126
  store i32 %call2259, ptr %slot372, align 8
  br label %bb_failure
bb_rcsuccess479:
  br label %bb_rcmoved462
bb_rcmoved462:
  %v2260 = load i64, ptr %slot12, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  store i32 0, ptr %p2261, align 4, !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot17, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i32 2, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot16, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i32 1, ptr %p2265, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared453
bb_rccopy453:
  %v2266 = load i64, ptr %slot21, align 8
  store i64 %v2266, ptr %slot373, align 8
  %v2267 = load i64, ptr %slot44, align 8
  store i64 %v2267, ptr %slot374, align 8
  %v2268 = load i64, ptr %slot43, align 8
  %v2269 = load i64, ptr %slot373, align 8
  %v2270 = load i64, ptr %slot349, align 8
  %v2271 = load i64, ptr %slot374, align 8
  %cv2272 = trunc i64 %v2271 to i32
  %call2273 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v2268, i64 %v2269, i64 %v2270, i32 %cv2272) nomerge, !dbg !126
  store i32 %call2273, ptr %slot375, align 8
  %v2274 = load i32, ptr %slot375, align 8
  %cv2275 = zext i32 %v2274 to i64
  %cond2276 = icmp ne i64 %cv2275, 0
  br i1 %cond2276, label %bb_rcsuccess488, label %bb_rcfailure488
bb_rcfailure488:
  %v2277 = load i64, ptr %slot43, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %call2279 = call i32 @myl_rc_take_failure(ptr %p2278) nomerge, !dbg !126
  store i32 %call2279, ptr %slot376, align 8
  %v2280 = load i64, ptr %slot1, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %v2282 = load i32, ptr %slot376, align 8
  %call2283 = call i32 @myl_qbe_rc_status(ptr %p2281, i32 %v2282) nomerge, !dbg !126
  store i32 %call2283, ptr %slot377, align 8
  br label %bb_failure
bb_rcsuccess488:
  %v2284 = load i64, ptr %slot17, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 2, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot16, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  store i32 1, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  %v2288 = load i64, ptr %slot12, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  %ld2290 = load i32, ptr %p2289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2290, ptr %slot378, align 8
  %v2291 = load i32, ptr %slot378, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcslotdrop495, label %bb_rcslotdone495
bb_rcslotdrop495:
  %v2294 = load i64, ptr %slot12, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i32 0, ptr %p2295, align 4, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot19, align 8
  store i64 %v2296, ptr %slot379, align 8
  %v2297 = load i64, ptr %slot13, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %ld2299 = load i32, ptr %p2298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2299, ptr %slot380, align 8
  %v2300 = load i32, ptr %slot380, align 8
  %op2301 = and i32 %v2300, 28
  store i32 %op2301, ptr %slot381, align 8
  %v2302 = load i32, ptr %slot381, align 8
  %cv2303 = zext i32 %v2302 to i64
  %cond2304 = icmp ne i64 %cv2303, 0
  br i1 %cond2304, label %bb_rcslotrole495, label %bb_rcslotowner495
bb_rcslotrole495:
  %v2305 = load i64, ptr %slot43, align 8
  store i64 %v2305, ptr %slot382, align 8
  %v2306 = load i64, ptr %slot382, align 8
  %v2307 = load i64, ptr %slot379, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2306, i64 %v2307) nomerge, !dbg !126
  br label %bb_rcslotdone495
bb_rcslotowner495:
  %v2308 = load i64, ptr %slot379, align 8
  %p2310 = inttoptr i64 %v2308 to ptr
  %gep2311 = getelementptr i8, ptr %p2310, i64 8
  %op2309 = ptrtoint ptr %gep2311 to i64
  store i64 %op2309, ptr %slot383, align 8
  %v2312 = load i64, ptr %slot43, align 8
  store i64 %v2312, ptr %slot384, align 8
  %v2313 = load i64, ptr %slot383, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  %ld2315 = load i64, ptr %p2314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2315, ptr %slot385, align 8
  %v2316 = load i64, ptr %slot385, align 8
  %cmp2317 = icmp ne i64 %v2316, 0
  %cv2318 = zext i1 %cmp2317 to i32
  store i32 %cv2318, ptr %slot386, align 8
  %v2319 = load i32, ptr %slot386, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcgnn513, label %bb_rcgdone513
bb_rcgnn513:
  %v2322 = load i64, ptr %slot385, align 8
  %op2323 = sub i64 %v2322, 16
  store i64 %op2323, ptr %slot387, align 8
  %v2324 = load i64, ptr %slot385, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %rgep2326 = getelementptr i8, ptr %p2325, i64 -16
  %ld2327 = load i64, ptr %rgep2326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2327, ptr %slot388, align 8
  %v2328 = load i64, ptr %slot388, align 8
  %op2329 = and i64 %v2328, 4611686018427387906
  store i64 %op2329, ptr %slot389, align 8
  %v2330 = load i64, ptr %slot389, align 8
  %cmp2331 = icmp ne i64 %v2330, 0
  %cv2332 = zext i1 %cmp2331 to i32
  store i32 %cv2332, ptr %slot390, align 8
  %v2333 = load i32, ptr %slot390, align 8
  %cv2334 = zext i32 %v2333 to i64
  %cond2335 = icmp ne i64 %cv2334, 0
  br i1 %cond2335, label %bb_rcgclear513, label %bb_rcgcounted513
bb_rcgcounted513:
  %v2336 = load i64, ptr %slot385, align 8
  %op2337 = sub i64 %v2336, 32
  store i64 %op2337, ptr %slot391, align 8
  %v2338 = load i64, ptr %slot385, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %rgep2340 = getelementptr i8, ptr %p2339, i64 -32
  %ld2341 = load i64, ptr %rgep2340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2341, ptr %slot392, align 8
  %v2342 = load i64, ptr %slot392, align 8
  %op2343 = sub i64 %v2342, 1
  store i64 %op2343, ptr %slot393, align 8
  %v2344 = load i64, ptr %slot393, align 8
  %cmp2345 = icmp eq i64 %v2344, 0
  %cv2346 = zext i1 %cmp2345 to i32
  store i32 %cv2346, ptr %slot394, align 8
  %v2347 = load i32, ptr %slot394, align 8
  %cv2348 = zext i32 %v2347 to i64
  %cond2349 = icmp ne i64 %cv2348, 0
  br i1 %cond2349, label %bb_rcglast513, label %bb_rcgdec513
bb_rcglast513:
  %v2350 = load i64, ptr %slot385, align 8
  %op2351 = sub i64 %v2350, 24
  store i64 %op2351, ptr %slot395, align 8
  %v2352 = load i64, ptr %slot385, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %rgep2354 = getelementptr i8, ptr %p2353, i64 -24
  %ld2355 = load i64, ptr %rgep2354, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2355, ptr %slot396, align 8
  %v2356 = load i64, ptr %slot396, align 8
  %cmp2357 = icmp ne i64 %v2356, 0
  %cv2358 = zext i1 %cmp2357 to i32
  store i32 %cv2358, ptr %slot397, align 8
  %v2359 = load i32, ptr %slot397, align 8
  %cv2360 = zext i32 %v2359 to i64
  %cond2361 = icmp ne i64 %cv2360, 0
  br i1 %cond2361, label %bb_rcgdec513, label %bb_rcgslow513
bb_rcgslow513:
  %v2362 = load i64, ptr %slot384, align 8
  %v2363 = load i64, ptr %slot383, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2362, i64 %v2363) nomerge, !dbg !126
  br label %bb_rcgdone513
bb_rcgdec513:
  %v2364 = load i64, ptr %slot393, align 8
  %v2365 = load i64, ptr %slot385, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %rgep2367 = getelementptr i8, ptr %p2366, i64 -32
  store i64 %v2364, ptr %rgep2367, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear513
bb_rcgclear513:
  %v2368 = load i64, ptr %slot383, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  store i64 0, ptr %p2369, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone513
bb_rcgdone513:
  %v2370 = load i64, ptr %slot379, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 0, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot379, align 8
  %p2374 = inttoptr i64 %v2372 to ptr
  %gep2375 = getelementptr i8, ptr %p2374, i64 8
  %op2373 = ptrtoint ptr %gep2375 to i64
  store i64 %op2373, ptr %slot398, align 8
  %v2376 = load i64, ptr %slot398, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  store i64 0, ptr %p2377, align 8, !alias.scope !3, !noalias !4
  %v2378 = load i64, ptr %slot379, align 8
  %p2380 = inttoptr i64 %v2378 to ptr
  %gep2381 = getelementptr i8, ptr %p2380, i64 16
  %op2379 = ptrtoint ptr %gep2381 to i64
  store i64 %op2379, ptr %slot399, align 8
  %v2382 = load i64, ptr %slot399, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i64 0, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone495
bb_rcslotdone495:
  br label %bb_rcprepared453
bb_rcprepared453:
  %v2384 = load i64, ptr %slot6, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %ld2386 = load i32, ptr %p2385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2386, ptr %slot400, align 8
  %v2387 = load i32, ptr %slot400, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcslotdrop522, label %bb_rcslotdone522
bb_rcslotdrop522:
  %v2390 = load i64, ptr %slot6, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i32 0, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  %v2392 = load i64, ptr %slot28, align 8
  store i64 %v2392, ptr %slot401, align 8
  %v2393 = load i64, ptr %slot7, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i32, ptr %p2394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2395, ptr %slot402, align 8
  %v2396 = load i32, ptr %slot402, align 8
  %op2397 = and i32 %v2396, 28
  store i32 %op2397, ptr %slot403, align 8
  %v2398 = load i32, ptr %slot403, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcslotrole522, label %bb_rcslotowner522
bb_rcslotrole522:
  %v2401 = load i64, ptr %slot43, align 8
  store i64 %v2401, ptr %slot404, align 8
  %v2402 = load i64, ptr %slot404, align 8
  %v2403 = load i64, ptr %slot401, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2402, i64 %v2403) nomerge, !dbg !126
  br label %bb_rcslotdone522
bb_rcslotowner522:
  %v2404 = load i64, ptr %slot401, align 8
  %p2406 = inttoptr i64 %v2404 to ptr
  %gep2407 = getelementptr i8, ptr %p2406, i64 8
  %op2405 = ptrtoint ptr %gep2407 to i64
  store i64 %op2405, ptr %slot405, align 8
  %v2408 = load i64, ptr %slot43, align 8
  store i64 %v2408, ptr %slot406, align 8
  %v2409 = load i64, ptr %slot405, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  %ld2411 = load i64, ptr %p2410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2411, ptr %slot407, align 8
  %v2412 = load i64, ptr %slot407, align 8
  %cmp2413 = icmp ne i64 %v2412, 0
  %cv2414 = zext i1 %cmp2413 to i32
  store i32 %cv2414, ptr %slot408, align 8
  %v2415 = load i32, ptr %slot408, align 8
  %cv2416 = zext i32 %v2415 to i64
  %cond2417 = icmp ne i64 %cv2416, 0
  br i1 %cond2417, label %bb_rcgnn540, label %bb_rcgdone540
bb_rcgnn540:
  %v2418 = load i64, ptr %slot407, align 8
  %op2419 = sub i64 %v2418, 16
  store i64 %op2419, ptr %slot409, align 8
  %v2420 = load i64, ptr %slot407, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %rgep2422 = getelementptr i8, ptr %p2421, i64 -16
  %ld2423 = load i64, ptr %rgep2422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2423, ptr %slot410, align 8
  %v2424 = load i64, ptr %slot410, align 8
  %op2425 = and i64 %v2424, 4611686018427387906
  store i64 %op2425, ptr %slot411, align 8
  %v2426 = load i64, ptr %slot411, align 8
  %cmp2427 = icmp ne i64 %v2426, 0
  %cv2428 = zext i1 %cmp2427 to i32
  store i32 %cv2428, ptr %slot412, align 8
  %v2429 = load i32, ptr %slot412, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcgclear540, label %bb_rcgcounted540
bb_rcgcounted540:
  %v2432 = load i64, ptr %slot407, align 8
  %op2433 = sub i64 %v2432, 32
  store i64 %op2433, ptr %slot413, align 8
  %v2434 = load i64, ptr %slot407, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %rgep2436 = getelementptr i8, ptr %p2435, i64 -32
  %ld2437 = load i64, ptr %rgep2436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2437, ptr %slot414, align 8
  %v2438 = load i64, ptr %slot414, align 8
  %op2439 = sub i64 %v2438, 1
  store i64 %op2439, ptr %slot415, align 8
  %v2440 = load i64, ptr %slot415, align 8
  %cmp2441 = icmp eq i64 %v2440, 0
  %cv2442 = zext i1 %cmp2441 to i32
  store i32 %cv2442, ptr %slot416, align 8
  %v2443 = load i32, ptr %slot416, align 8
  %cv2444 = zext i32 %v2443 to i64
  %cond2445 = icmp ne i64 %cv2444, 0
  br i1 %cond2445, label %bb_rcglast540, label %bb_rcgdec540
bb_rcglast540:
  %v2446 = load i64, ptr %slot407, align 8
  %op2447 = sub i64 %v2446, 24
  store i64 %op2447, ptr %slot417, align 8
  %v2448 = load i64, ptr %slot407, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %rgep2450 = getelementptr i8, ptr %p2449, i64 -24
  %ld2451 = load i64, ptr %rgep2450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2451, ptr %slot418, align 8
  %v2452 = load i64, ptr %slot418, align 8
  %cmp2453 = icmp ne i64 %v2452, 0
  %cv2454 = zext i1 %cmp2453 to i32
  store i32 %cv2454, ptr %slot419, align 8
  %v2455 = load i32, ptr %slot419, align 8
  %cv2456 = zext i32 %v2455 to i64
  %cond2457 = icmp ne i64 %cv2456, 0
  br i1 %cond2457, label %bb_rcgdec540, label %bb_rcgslow540
bb_rcgslow540:
  %v2458 = load i64, ptr %slot406, align 8
  %v2459 = load i64, ptr %slot405, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2458, i64 %v2459) nomerge, !dbg !126
  br label %bb_rcgdone540
bb_rcgdec540:
  %v2460 = load i64, ptr %slot415, align 8
  %v2461 = load i64, ptr %slot407, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  %rgep2463 = getelementptr i8, ptr %p2462, i64 -32
  store i64 %v2460, ptr %rgep2463, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear540
bb_rcgclear540:
  %v2464 = load i64, ptr %slot405, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  store i64 0, ptr %p2465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone540
bb_rcgdone540:
  %v2466 = load i64, ptr %slot401, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  store i64 0, ptr %p2467, align 8, !alias.scope !3, !noalias !4
  %v2468 = load i64, ptr %slot401, align 8
  %p2470 = inttoptr i64 %v2468 to ptr
  %gep2471 = getelementptr i8, ptr %p2470, i64 8
  %op2469 = ptrtoint ptr %gep2471 to i64
  store i64 %op2469, ptr %slot420, align 8
  %v2472 = load i64, ptr %slot420, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  store i64 0, ptr %p2473, align 8, !alias.scope !3, !noalias !4
  %v2474 = load i64, ptr %slot401, align 8
  %p2476 = inttoptr i64 %v2474 to ptr
  %gep2477 = getelementptr i8, ptr %p2476, i64 16
  %op2475 = ptrtoint ptr %gep2477 to i64
  store i64 %op2475, ptr %slot421, align 8
  %v2478 = load i64, ptr %slot421, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  store i64 0, ptr %p2479, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone522
bb_rcslotdone522:
  %v2480 = load i64, ptr %slot28, align 8
  store i64 %v2480, ptr %slot422, align 8
  %v2481 = load i64, ptr %slot21, align 8
  store i64 %v2481, ptr %slot423, align 8
  %v2482 = load i64, ptr %slot423, align 8
  %v2483 = load i64, ptr %slot422, align 8
  %p2484 = inttoptr i64 %v2482 to ptr
  %p2485 = inttoptr i64 %v2483 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2485, ptr %p2484, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot16, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i32 0, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot7, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i32 2, ptr %p2489, align 4, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot17, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %ld2492 = load i32, ptr %p2491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2492, ptr %slot424, align 8
  %v2493 = load i32, ptr %slot424, align 8
  %v2494 = load i64, ptr %slot7, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i32 %v2493, ptr %p2495, align 4, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot6, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 1, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot34, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  store i64 0, ptr %p2499, align 8, !alias.scope !3, !noalias !4
  %v2500 = load i64, ptr %slot28, align 8
  %v2501 = load i64, ptr %slot34, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  store i64 %v2500, ptr %p2502, align 8, !alias.scope !3, !noalias !4
  %v2503 = load i64, ptr %slot34, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  %ld2505 = load i64, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2505, ptr %slot425, align 8
  %v2506 = load i64, ptr %slot12, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %ld2508 = load i32, ptr %p2507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2508, ptr %slot426, align 8
  %v2509 = load i64, ptr %slot13, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  %ld2511 = load i32, ptr %p2510, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2511, ptr %slot427, align 8
  %v2512 = load i32, ptr %slot427, align 8
  %op2513 = and i32 %v2512, 24
  store i32 %op2513, ptr %slot427, align 8
  %v2514 = load i32, ptr %slot427, align 8
  %cmp2515 = icmp eq i32 %v2514, 0
  %cv2516 = zext i1 %cmp2515 to i32
  store i32 %cv2516, ptr %slot428, align 8
  %v2517 = load i32, ptr %slot426, align 8
  %v2518 = load i32, ptr %slot428, align 8
  %op2519 = and i32 %v2517, %v2518
  store i32 %op2519, ptr %slot429, align 8
  %v2520 = load i64, ptr %slot44, align 8
  store i64 %v2520, ptr %slot430, align 8
  %v2521 = load i32, ptr %slot429, align 8
  %op2522 = mul i32 %v2521, 4
  store i32 %op2522, ptr %slot431, align 8
  %v2523 = load i32, ptr %slot431, align 8
  %op2524 = or i32 %v2523, 0
  store i32 %op2524, ptr %slot432, align 8
  %v2525 = load i64, ptr %slot21, align 8
  store i64 %v2525, ptr %slot433, align 8
  %v2526 = load i64, ptr %slot43, align 8
  %v2527 = load i64, ptr %slot433, align 8
  %v2528 = load i64, ptr %slot425, align 8
  %v2529 = load i64, ptr %slot430, align 8
  %cv2530 = trunc i64 %v2529 to i32
  %v2531 = load i32, ptr %slot432, align 8
  %call2532 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64 %v2526, i64 %v2527, i64 %v2528, i32 %cv2530, i32 %v2531) nomerge, !dbg !128
  store i32 %call2532, ptr %slot434, align 8
  %v2533 = load i32, ptr %slot434, align 8
  %cv2534 = zext i32 %v2533 to i64
  %cond2535 = icmp ne i64 %cv2534, 0
  br i1 %cond2535, label %bb_rcsuccess567, label %bb_rcfailure567
bb_rcfailure567:
  %v2536 = load i64, ptr %slot43, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %call2538 = call i32 @myl_rc_take_failure(ptr %p2537) nomerge, !dbg !128
  store i32 %call2538, ptr %slot435, align 8
  %v2539 = load i64, ptr %slot1, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %v2541 = load i32, ptr %slot435, align 8
  %call2542 = call i32 @myl_qbe_rc_status(ptr %p2540, i32 %v2541) nomerge, !dbg !128
  store i32 %call2542, ptr %slot436, align 8
  br label %bb_failure
bb_rcsuccess567:
  %v2543 = load i32, ptr %slot429, align 8
  %cv2544 = zext i32 %v2543 to i64
  %cond2545 = icmp ne i64 %cv2544, 0
  br i1 %cond2545, label %bb_rchtaken570, label %bb_rchcopied570
bb_rchcopied570:
  %v2546 = load i64, ptr %slot12, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  %ld2548 = load i32, ptr %p2547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2548, ptr %slot437, align 8
  %v2549 = load i32, ptr %slot437, align 8
  %cv2550 = zext i32 %v2549 to i64
  %cond2551 = icmp ne i64 %cv2550, 0
  br i1 %cond2551, label %bb_rcslotdrop573, label %bb_rcslotdone573
bb_rcslotdrop573:
  %v2552 = load i64, ptr %slot12, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  store i32 0, ptr %p2553, align 4, !alias.scope !3, !noalias !4
  %v2554 = load i64, ptr %slot19, align 8
  store i64 %v2554, ptr %slot438, align 8
  %v2555 = load i64, ptr %slot13, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %ld2557 = load i32, ptr %p2556, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2557, ptr %slot439, align 8
  %v2558 = load i32, ptr %slot439, align 8
  %op2559 = and i32 %v2558, 28
  store i32 %op2559, ptr %slot440, align 8
  %v2560 = load i32, ptr %slot440, align 8
  %cv2561 = zext i32 %v2560 to i64
  %cond2562 = icmp ne i64 %cv2561, 0
  br i1 %cond2562, label %bb_rcslotrole573, label %bb_rcslotowner573
bb_rcslotrole573:
  %v2563 = load i64, ptr %slot43, align 8
  store i64 %v2563, ptr %slot441, align 8
  %v2564 = load i64, ptr %slot441, align 8
  %v2565 = load i64, ptr %slot438, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2564, i64 %v2565) nomerge, !dbg !128
  br label %bb_rcslotdone573
bb_rcslotowner573:
  %v2566 = load i64, ptr %slot43, align 8
  store i64 %v2566, ptr %slot442, align 8
  %v2567 = load i64, ptr %slot442, align 8
  %v2568 = load i64, ptr %slot438, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2567, i64 %v2568) nomerge, !dbg !128
  br label %bb_rcslotdone573
bb_rcslotdone573:
  br label %bb_rchprepared570
bb_rchtaken570:
  %v2569 = load i64, ptr %slot12, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 0, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared570
bb_rchprepared570:
  %v2571 = load i64, ptr %slot17, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i32 2, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot16, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  store i32 1, ptr %p2574, align 4, !alias.scope !3, !noalias !4
  %v2575 = load i64, ptr %slot19, align 8
  store i64 %v2575, ptr %slot443, align 8
  %v2576 = load i64, ptr %slot21, align 8
  store i64 %v2576, ptr %slot444, align 8
  %v2577 = load i64, ptr %slot444, align 8
  %v2578 = load i64, ptr %slot443, align 8
  %p2579 = inttoptr i64 %v2577 to ptr
  %p2580 = inttoptr i64 %v2578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2580, ptr %p2579, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2581 = load i64, ptr %slot13, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i32 2, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot17, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i32, ptr %p2584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2585, ptr %slot445, align 8
  %v2586 = load i32, ptr %slot445, align 8
  %v2587 = load i64, ptr %slot13, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  store i32 %v2586, ptr %p2588, align 4, !alias.scope !3, !noalias !4
  %v2589 = load i64, ptr %slot16, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  store i32 0, ptr %p2590, align 4, !alias.scope !3, !noalias !4
  %v2591 = load i64, ptr %slot12, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  store i32 1, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  %v2593 = load i64, ptr %slot443, align 8
  %v2594 = load i64, ptr %slot34, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  store i64 %v2593, ptr %p2595, align 8, !alias.scope !3, !noalias !4
  %v2596 = load i64, ptr %slot37, align 8
  store i64 %v2596, ptr %slot446, align 8
  %v2597 = load i64, ptr %slot446, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i64 0, ptr %p2598, align 8, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot446, align 8
  %p2601 = inttoptr i64 %v2599 to ptr
  %gep2602 = getelementptr i8, ptr %p2601, i64 8
  %op2600 = ptrtoint ptr %gep2602 to i64
  store i64 %op2600, ptr %slot447, align 8
  %v2603 = load i64, ptr %slot447, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  store i64 0, ptr %p2604, align 8, !alias.scope !3, !noalias !4
  %v2605 = load i64, ptr %slot446, align 8
  %p2607 = inttoptr i64 %v2605 to ptr
  %gep2608 = getelementptr i8, ptr %p2607, i64 16
  %op2606 = ptrtoint ptr %gep2608 to i64
  store i64 %op2606, ptr %slot448, align 8
  %v2609 = load i64, ptr %slot448, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  store i64 0, ptr %p2610, align 8, !alias.scope !3, !noalias !4
  %v2611 = load i64, ptr %slot446, align 8
  %p2613 = inttoptr i64 %v2611 to ptr
  %gep2614 = getelementptr i8, ptr %p2613, i64 24
  %op2612 = ptrtoint ptr %gep2614 to i64
  store i64 %op2612, ptr %slot449, align 8
  %v2615 = load i64, ptr %slot449, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i64 0, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot446, align 8
  %p2619 = inttoptr i64 %v2617 to ptr
  %gep2620 = getelementptr i8, ptr %p2619, i64 32
  %op2618 = ptrtoint ptr %gep2620 to i64
  store i64 %op2618, ptr %slot450, align 8
  %v2621 = load i64, ptr %slot450, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  store i64 0, ptr %p2622, align 8, !alias.scope !3, !noalias !4
  %v2623 = load i64, ptr %slot446, align 8
  %p2625 = inttoptr i64 %v2623 to ptr
  %gep2626 = getelementptr i8, ptr %p2625, i64 40
  %op2624 = ptrtoint ptr %gep2626 to i64
  store i64 %op2624, ptr %slot451, align 8
  %v2627 = load i64, ptr %slot451, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  store i64 0, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot446, align 8
  %p2631 = inttoptr i64 %v2629 to ptr
  %gep2632 = getelementptr i8, ptr %p2631, i64 48
  %op2630 = ptrtoint ptr %gep2632 to i64
  store i64 %op2630, ptr %slot452, align 8
  %v2633 = load i64, ptr %slot452, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i64 0, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  %v2635 = load i64, ptr %slot446, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i32 6, ptr %p2636, align 4, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot18, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 1, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot34, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  %ld2641 = load i64, ptr %p2640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2641, ptr %slot453, align 8
  %v2642 = load i64, ptr %slot446, align 8
  %p2644 = inttoptr i64 %v2642 to ptr
  %gep2645 = getelementptr i8, ptr %p2644, i64 8
  %op2643 = ptrtoint ptr %gep2645 to i64
  store i64 %op2643, ptr %slot454, align 8
  %v2646 = load i64, ptr %slot44, align 8
  store i64 %v2646, ptr %slot455, align 8
  %v2647 = load i64, ptr %slot34, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %ld2649 = load i64, ptr %p2648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2649, ptr %slot456, align 8
  %v2650 = load i64, ptr %slot21, align 8
  store i64 %v2650, ptr %slot457, align 8
  %v2651 = load i64, ptr %slot44, align 8
  store i64 %v2651, ptr %slot458, align 8
  %v2652 = load i64, ptr %slot456, align 8
  %op2653 = add i64 %v2652, 8
  store i64 %op2653, ptr %slot459, align 8
  %v2654 = load i64, ptr %slot459, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %ld2656 = load i64, ptr %p2655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2656, ptr %slot460, align 8
  %v2657 = load i64, ptr %slot460, align 8
  %cmp2658 = icmp ne i64 %v2657, 0
  %cv2659 = zext i1 %cmp2658 to i32
  store i32 %cv2659, ptr %slot461, align 8
  %v2660 = load i32, ptr %slot461, align 8
  %cv2661 = zext i32 %v2660 to i64
  %cond2662 = icmp ne i64 %cv2661, 0
  br i1 %cond2662, label %bb_rcmoveheader609, label %bb_rcmovenext609
bb_rcmoveheader609:
  %v2663 = load i64, ptr %slot460, align 8
  %op2664 = sub i64 %v2663, 16
  store i64 %op2664, ptr %slot462, align 8
  %v2665 = load i64, ptr %slot460, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %rgep2667 = getelementptr i8, ptr %p2666, i64 -16
  %ld2668 = load i64, ptr %rgep2667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2668, ptr %slot463, align 8
  %v2669 = load i64, ptr %slot463, align 8
  %op2670 = and i64 %v2669, 5764607523034234881
  store i64 %op2670, ptr %slot464, align 8
  %v2671 = load i64, ptr %slot464, align 8
  %cmp2672 = icmp ne i64 %v2671, 0
  %cv2673 = zext i1 %cmp2672 to i32
  store i32 %cv2673, ptr %slot465, align 8
  %v2674 = load i32, ptr %slot465, align 8
  %cv2675 = zext i32 %v2674 to i64
  %cond2676 = icmp ne i64 %cv2675, 0
  br i1 %cond2676, label %bb_rcmoveslow606, label %bb_rcmovenext609
bb_rcmovenext609:
  %v2677 = load i64, ptr %slot456, align 8
  %v2678 = load i64, ptr %slot457, align 8
  %p2679 = inttoptr i64 %v2677 to ptr
  %p2680 = inttoptr i64 %v2678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2680, ptr %p2679, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2681 = load i64, ptr %slot456, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  store i64 0, ptr %p2682, align 8, !alias.scope !3, !noalias !4
  %v2683 = load i64, ptr %slot456, align 8
  %op2684 = add i64 %v2683, 8
  store i64 %op2684, ptr %slot466, align 8
  %v2685 = load i64, ptr %slot466, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  store i64 0, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  %v2687 = load i64, ptr %slot456, align 8
  %op2688 = add i64 %v2687, 16
  store i64 %op2688, ptr %slot467, align 8
  %v2689 = load i64, ptr %slot467, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 0, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved606
bb_rcmoveslow606:
  %v2691 = load i64, ptr %slot43, align 8
  %v2692 = load i64, ptr %slot457, align 8
  %v2693 = load i64, ptr %slot456, align 8
  %v2694 = load i64, ptr %slot458, align 8
  %cv2695 = trunc i64 %v2694 to i32
  %call2696 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2691, i64 %v2692, i64 %v2693, i32 %cv2695) nomerge, !dbg !130
  store i32 %call2696, ptr %slot468, align 8
  %v2697 = load i32, ptr %slot468, align 8
  %cv2698 = zext i32 %v2697 to i64
  %cond2699 = icmp ne i64 %cv2698, 0
  br i1 %cond2699, label %bb_rcsuccess618, label %bb_rcfailure618
bb_rcfailure618:
  %v2700 = load i64, ptr %slot43, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  %call2702 = call i32 @myl_rc_take_failure(ptr %p2701) nomerge, !dbg !130
  store i32 %call2702, ptr %slot469, align 8
  %v2703 = load i64, ptr %slot1, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  %v2705 = load i32, ptr %slot469, align 8
  %call2706 = call i32 @myl_qbe_rc_status(ptr %p2704, i32 %v2705) nomerge, !dbg !130
  store i32 %call2706, ptr %slot470, align 8
  br label %bb_failure
bb_rcsuccess618:
  br label %bb_rcmoved606
bb_rcmoved606:
  %v2707 = load i64, ptr %slot12, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  store i32 0, ptr %p2708, align 4, !alias.scope !3, !noalias !4
  %v2709 = load i64, ptr %slot17, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  store i32 2, ptr %p2710, align 4, !alias.scope !3, !noalias !4
  %v2711 = load i64, ptr %slot16, align 8
  %p2712 = inttoptr i64 %v2711 to ptr
  store i32 1, ptr %p2712, align 4, !alias.scope !3, !noalias !4
  %v2713 = load i64, ptr %slot21, align 8
  store i64 %v2713, ptr %slot471, align 8
  %v2714 = load i64, ptr %slot471, align 8
  %v2715 = load i64, ptr %slot454, align 8
  %p2716 = inttoptr i64 %v2714 to ptr
  %p2717 = inttoptr i64 %v2715 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2717, ptr %p2716, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot16, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  store i32 0, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  %v2720 = load i64, ptr %slot446, align 8
  %v2721 = load i64, ptr %slot34, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i64 %v2720, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot34, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %ld2725 = load i64, ptr %p2724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2725, ptr %slot472, align 8
  %v2726 = load i64, ptr %slot19, align 8
  store i64 %v2726, ptr %slot473, align 8
  %v2727 = load i64, ptr %slot472, align 8
  %v2728 = load i64, ptr %slot473, align 8
  %p2729 = inttoptr i64 %v2727 to ptr
  %p2730 = inttoptr i64 %v2728 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2730, ptr %p2729, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2731 = load i64, ptr %slot13, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  store i32 2, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  %v2733 = load i64, ptr %slot12, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i32 1, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot473, align 8
  %v2736 = load i64, ptr %slot34, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  store i64 %v2735, ptr %p2737, align 8, !alias.scope !3, !noalias !4
  %v2738 = load i64, ptr %slot34, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %ld2740 = load i64, ptr %p2739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2740, ptr %slot474, align 8
  %v2741 = load i64, ptr %slot12, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  %ld2743 = load i32, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2743, ptr %slot475, align 8
  %v2744 = load i64, ptr %slot13, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  %ld2746 = load i32, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2746, ptr %slot476, align 8
  %v2747 = load i32, ptr %slot476, align 8
  %op2748 = and i32 %v2747, 24
  store i32 %op2748, ptr %slot476, align 8
  %v2749 = load i32, ptr %slot476, align 8
  %cmp2750 = icmp eq i32 %v2749, 0
  %cv2751 = zext i1 %cmp2750 to i32
  store i32 %cv2751, ptr %slot477, align 8
  %v2752 = load i32, ptr %slot475, align 8
  %v2753 = load i32, ptr %slot477, align 8
  %op2754 = and i32 %v2752, %v2753
  store i32 %op2754, ptr %slot478, align 8
  %v2755 = load i32, ptr %slot478, align 8
  %cv2756 = zext i32 %v2755 to i64
  %cond2757 = icmp ne i64 %cv2756, 0
  br i1 %cond2757, label %bb_rcprivateown637, label %bb_rcprivateloan637
bb_rcprivateown637:
  %v2758 = load i64, ptr %slot21, align 8
  store i64 %v2758, ptr %slot479, align 8
  %v2759 = load i64, ptr %slot44, align 8
  store i64 %v2759, ptr %slot480, align 8
  %v2760 = load i64, ptr %slot43, align 8
  %v2761 = load i64, ptr %slot479, align 8
  %v2762 = load i64, ptr %slot474, align 8
  %v2763 = load i64, ptr %slot480, align 8
  %cv2764 = trunc i64 %v2763 to i32
  %call2765 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v2760, i64 %v2761, i64 %v2762, i32 %cv2764) nomerge, !dbg !132
  store i32 %call2765, ptr %slot481, align 8
  %v2766 = load i32, ptr %slot481, align 8
  %cv2767 = zext i32 %v2766 to i64
  %cond2768 = icmp ne i64 %cv2767, 0
  br i1 %cond2768, label %bb_rcsuccess641, label %bb_rcfailure641
bb_rcfailure641:
  %v2769 = load i64, ptr %slot43, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %call2771 = call i32 @myl_rc_take_failure(ptr %p2770) nomerge, !dbg !132
  store i32 %call2771, ptr %slot482, align 8
  %v2772 = load i64, ptr %slot1, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  %v2774 = load i32, ptr %slot482, align 8
  %call2775 = call i32 @myl_qbe_rc_status(ptr %p2773, i32 %v2774) nomerge, !dbg !132
  store i32 %call2775, ptr %slot483, align 8
  br label %bb_failure
bb_rcsuccess641:
  %v2776 = load i64, ptr %slot12, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  store i32 0, ptr %p2777, align 4, !alias.scope !3, !noalias !4
  %v2778 = load i64, ptr %slot17, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  store i32 2, ptr %p2779, align 4, !alias.scope !3, !noalias !4
  %v2780 = load i64, ptr %slot16, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  store i32 1, ptr %p2781, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared637
bb_rcprivateloan637:
  %v2782 = load i64, ptr %slot12, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %ld2784 = load i32, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2784, ptr %slot484, align 8
  %v2785 = load i64, ptr %slot13, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %ld2787 = load i32, ptr %p2786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2787, ptr %slot485, align 8
  %v2788 = load i32, ptr %slot485, align 8
  %cmp2789 = icmp eq i32 %v2788, 16
  %cv2790 = zext i1 %cmp2789 to i32
  store i32 %cv2790, ptr %slot486, align 8
  %v2791 = load i32, ptr %slot486, align 8
  %v2792 = load i32, ptr %slot484, align 8
  %op2793 = and i32 %v2791, %v2792
  store i32 %op2793, ptr %slot486, align 8
  %v2794 = load i32, ptr %slot486, align 8
  %cv2795 = zext i32 %v2794 to i64
  %cond2796 = icmp ne i64 %cv2795, 0
  br i1 %cond2796, label %bb_rcprivatemove637, label %bb_rcprivatenew637
bb_rcprivatemove637:
  %v2797 = load i64, ptr %slot21, align 8
  store i64 %v2797, ptr %slot487, align 8
  %v2798 = load i64, ptr %slot474, align 8
  %v2799 = load i64, ptr %slot487, align 8
  %p2800 = inttoptr i64 %v2798 to ptr
  %p2801 = inttoptr i64 %v2799 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2801, ptr %p2800, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2802 = load i64, ptr %slot474, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  call void @llvm.memset.p0.i64(ptr %p2803, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v2804 = load i64, ptr %slot17, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i32 2, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot17, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 16, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot16, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i32 1, ptr %p2809, align 4, !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot12, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 0, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared637
bb_rcprivatenew637:
  %v2812 = load i64, ptr %slot21, align 8
  store i64 %v2812, ptr %slot488, align 8
  %v2813 = load i64, ptr %slot43, align 8
  %v2814 = load i64, ptr %slot488, align 8
  %v2815 = load i64, ptr %slot474, align 8
  %call2816 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v2813, i64 %v2814, i64 %v2815) nomerge, !dbg !132
  store i32 %call2816, ptr %slot489, align 8
  %v2817 = load i32, ptr %slot489, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcsuccess659, label %bb_rcfailure659
bb_rcfailure659:
  %v2820 = load i64, ptr %slot43, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %call2822 = call i32 @myl_rc_take_failure(ptr %p2821) nomerge, !dbg !132
  store i32 %call2822, ptr %slot490, align 8
  %v2823 = load i64, ptr %slot1, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %v2825 = load i32, ptr %slot490, align 8
  %call2826 = call i32 @myl_qbe_rc_status(ptr %p2824, i32 %v2825) nomerge, !dbg !132
  store i32 %call2826, ptr %slot491, align 8
  br label %bb_failure
bb_rcsuccess659:
  %v2827 = load i64, ptr %slot17, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i32 2, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot17, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i32 16, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot16, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  store i32 1, ptr %p2832, align 4, !alias.scope !3, !noalias !4
  %v2833 = load i64, ptr %slot12, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  %ld2835 = load i32, ptr %p2834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2835, ptr %slot492, align 8
  %v2836 = load i32, ptr %slot492, align 8
  %cv2837 = zext i32 %v2836 to i64
  %cond2838 = icmp ne i64 %cv2837, 0
  br i1 %cond2838, label %bb_rcslotdrop667, label %bb_rcslotdone667
bb_rcslotdrop667:
  %v2839 = load i64, ptr %slot12, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 0, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot19, align 8
  store i64 %v2841, ptr %slot493, align 8
  %v2842 = load i64, ptr %slot13, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %ld2844 = load i32, ptr %p2843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2844, ptr %slot494, align 8
  %v2845 = load i32, ptr %slot494, align 8
  %op2846 = and i32 %v2845, 28
  store i32 %op2846, ptr %slot495, align 8
  %v2847 = load i32, ptr %slot495, align 8
  %cv2848 = zext i32 %v2847 to i64
  %cond2849 = icmp ne i64 %cv2848, 0
  br i1 %cond2849, label %bb_rcslotrole667, label %bb_rcslotowner667
bb_rcslotrole667:
  %v2850 = load i64, ptr %slot43, align 8
  store i64 %v2850, ptr %slot496, align 8
  %v2851 = load i64, ptr %slot496, align 8
  %v2852 = load i64, ptr %slot493, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2851, i64 %v2852) nomerge, !dbg !132
  br label %bb_rcslotdone667
bb_rcslotowner667:
  %v2853 = load i64, ptr %slot43, align 8
  store i64 %v2853, ptr %slot497, align 8
  %v2854 = load i64, ptr %slot497, align 8
  %v2855 = load i64, ptr %slot493, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2854, i64 %v2855) nomerge, !dbg !132
  br label %bb_rcslotdone667
bb_rcslotdone667:
  br label %bb_rcprivateprepared637
bb_rcprivateprepared637:
  %v2856 = load i64, ptr %slot10, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  %ld2858 = load i32, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2858, ptr %slot498, align 8
  %v2859 = load i32, ptr %slot498, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcslotdrop677, label %bb_rcslotdone677
bb_rcslotdrop677:
  %v2862 = load i64, ptr %slot10, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i32 0, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot32, align 8
  store i64 %v2864, ptr %slot499, align 8
  %v2865 = load i64, ptr %slot11, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %ld2867 = load i32, ptr %p2866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2867, ptr %slot500, align 8
  %v2868 = load i32, ptr %slot500, align 8
  %op2869 = and i32 %v2868, 28
  store i32 %op2869, ptr %slot501, align 8
  %v2870 = load i32, ptr %slot501, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcslotrole677, label %bb_rcslotowner677
bb_rcslotrole677:
  %v2873 = load i64, ptr %slot43, align 8
  store i64 %v2873, ptr %slot502, align 8
  %v2874 = load i64, ptr %slot502, align 8
  %v2875 = load i64, ptr %slot499, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2874, i64 %v2875) nomerge, !dbg !132
  br label %bb_rcslotdone677
bb_rcslotowner677:
  %v2876 = load i64, ptr %slot43, align 8
  store i64 %v2876, ptr %slot503, align 8
  %v2877 = load i64, ptr %slot503, align 8
  %v2878 = load i64, ptr %slot499, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2877, i64 %v2878) nomerge, !dbg !132
  br label %bb_rcslotdone677
bb_rcslotdone677:
  %v2879 = load i64, ptr %slot32, align 8
  store i64 %v2879, ptr %slot504, align 8
  %v2880 = load i64, ptr %slot21, align 8
  store i64 %v2880, ptr %slot505, align 8
  %v2881 = load i64, ptr %slot505, align 8
  %v2882 = load i64, ptr %slot504, align 8
  %p2883 = inttoptr i64 %v2881 to ptr
  %p2884 = inttoptr i64 %v2882 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2884, ptr %p2883, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot16, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  store i32 0, ptr %p2886, align 4, !alias.scope !3, !noalias !4
  %v2887 = load i64, ptr %slot11, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  store i32 2, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  %v2889 = load i64, ptr %slot17, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %ld2891 = load i32, ptr %p2890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2891, ptr %slot506, align 8
  %v2892 = load i32, ptr %slot506, align 8
  %v2893 = load i64, ptr %slot11, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  store i32 %v2892, ptr %p2894, align 4, !alias.scope !3, !noalias !4
  %v2895 = load i64, ptr %slot10, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  store i32 1, ptr %p2896, align 4, !alias.scope !3, !noalias !4
  %v2897 = load i64, ptr %slot25, align 8
  %p2898 = inttoptr i64 %v2897 to ptr
  %ld2899 = load i64, ptr %p2898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2899, ptr %slot507, align 8
  %v2900 = load i64, ptr %slot507, align 8
  %v2901 = load i64, ptr %slot34, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  store i64 %v2900, ptr %p2902, align 8, !alias.scope !3, !noalias !4
  %v2903 = load i64, ptr %slot34, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  %ld2905 = load i64, ptr %p2904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2905, ptr %slot508, align 8
  %v2906 = load i64, ptr %slot508, align 8
  %op2907 = add i64 %v2906, 0
  store i64 %op2907, ptr %slot509, align 8
  %v2908 = load i64, ptr %slot509, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  %ld2910 = load i64, ptr %p2909, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2910, ptr %slot510, align 8
  %v2911 = load i64, ptr %slot510, align 8
  %v2912 = load i64, ptr %slot34, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i64 %v2911, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot12, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %ld2916 = load i32, ptr %p2915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2916, ptr %slot511, align 8
  %v2917 = load i32, ptr %slot511, align 8
  %cv2918 = zext i32 %v2917 to i64
  %cond2919 = icmp ne i64 %cv2918, 0
  br i1 %cond2919, label %bb_rcslotdrop697, label %bb_rcslotdone697
bb_rcslotdrop697:
  %v2920 = load i64, ptr %slot12, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  store i32 0, ptr %p2921, align 4, !alias.scope !3, !noalias !4
  %v2922 = load i64, ptr %slot19, align 8
  store i64 %v2922, ptr %slot512, align 8
  %v2923 = load i64, ptr %slot13, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %ld2925 = load i32, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2925, ptr %slot513, align 8
  %v2926 = load i32, ptr %slot513, align 8
  %op2927 = and i32 %v2926, 28
  store i32 %op2927, ptr %slot514, align 8
  %v2928 = load i32, ptr %slot514, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcslotrole697, label %bb_rcslotowner697
bb_rcslotrole697:
  %v2931 = load i64, ptr %slot43, align 8
  store i64 %v2931, ptr %slot515, align 8
  %v2932 = load i64, ptr %slot515, align 8
  %v2933 = load i64, ptr %slot512, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2932, i64 %v2933) nomerge, !dbg !134
  br label %bb_rcslotdone697
bb_rcslotowner697:
  %v2934 = load i64, ptr %slot43, align 8
  store i64 %v2934, ptr %slot516, align 8
  %v2935 = load i64, ptr %slot516, align 8
  %v2936 = load i64, ptr %slot512, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2935, i64 %v2936) nomerge, !dbg !134
  br label %bb_rcslotdone697
bb_rcslotdone697:
  %v2937 = load i64, ptr %slot34, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %ld2939 = load i64, ptr %p2938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2939, ptr %slot517, align 8
  %v2940 = load i64, ptr %slot25, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %ld2942 = load i64, ptr %p2941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2942, ptr %slot518, align 8
  %v2943 = load i64, ptr %slot12, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %ld2945 = load i32, ptr %p2944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2945, ptr %slot519, align 8
  %v2946 = load i32, ptr %slot519, align 8
  %cv2947 = zext i32 %v2946 to i64
  %cond2948 = icmp ne i64 %cv2947, 0
  br i1 %cond2948, label %bb_rcslotdrop709, label %bb_rcslotdone709
bb_rcslotdrop709:
  %v2949 = load i64, ptr %slot12, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i32 0, ptr %p2950, align 4, !alias.scope !3, !noalias !4
  %v2951 = load i64, ptr %slot19, align 8
  store i64 %v2951, ptr %slot520, align 8
  %v2952 = load i64, ptr %slot13, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  %ld2954 = load i32, ptr %p2953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2954, ptr %slot521, align 8
  %v2955 = load i32, ptr %slot521, align 8
  %op2956 = and i32 %v2955, 28
  store i32 %op2956, ptr %slot522, align 8
  %v2957 = load i32, ptr %slot522, align 8
  %cv2958 = zext i32 %v2957 to i64
  %cond2959 = icmp ne i64 %cv2958, 0
  br i1 %cond2959, label %bb_rcslotrole709, label %bb_rcslotowner709
bb_rcslotrole709:
  %v2960 = load i64, ptr %slot43, align 8
  store i64 %v2960, ptr %slot523, align 8
  %v2961 = load i64, ptr %slot520, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  %ld2963 = load i64, ptr %p2962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2963, ptr %slot524, align 8
  %v2964 = load i64, ptr %slot524, align 8
  %cmp2965 = icmp ne i64 %v2964, 0
  %cv2966 = zext i1 %cmp2965 to i32
  store i32 %cv2966, ptr %slot525, align 8
  %v2967 = load i32, ptr %slot525, align 8
  %cv2968 = zext i32 %v2967 to i64
  %cond2969 = icmp ne i64 %cv2968, 0
  br i1 %cond2969, label %bb_rcgnn725, label %bb_rcgdone725
bb_rcgnn725:
  %v2970 = load i64, ptr %slot524, align 8
  %op2971 = sub i64 %v2970, 16
  store i64 %op2971, ptr %slot526, align 8
  %v2972 = load i64, ptr %slot524, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %rgep2974 = getelementptr i8, ptr %p2973, i64 -16
  %ld2975 = load i64, ptr %rgep2974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2975, ptr %slot527, align 8
  %v2976 = load i64, ptr %slot527, align 8
  %op2977 = and i64 %v2976, 4611686018427387906
  store i64 %op2977, ptr %slot528, align 8
  %v2978 = load i64, ptr %slot528, align 8
  %cmp2979 = icmp ne i64 %v2978, 0
  %cv2980 = zext i1 %cmp2979 to i32
  store i32 %cv2980, ptr %slot529, align 8
  %v2981 = load i32, ptr %slot529, align 8
  %cv2982 = zext i32 %v2981 to i64
  %cond2983 = icmp ne i64 %cv2982, 0
  br i1 %cond2983, label %bb_rcgclear725, label %bb_rcgcounted725
bb_rcgcounted725:
  %v2984 = load i64, ptr %slot524, align 8
  %op2985 = sub i64 %v2984, 24
  store i64 %op2985, ptr %slot530, align 8
  %v2986 = load i64, ptr %slot524, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %rgep2988 = getelementptr i8, ptr %p2987, i64 -24
  %ld2989 = load i64, ptr %rgep2988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2989, ptr %slot531, align 8
  %v2990 = load i64, ptr %slot531, align 8
  %op2991 = sub i64 %v2990, 1
  store i64 %op2991, ptr %slot532, align 8
  %v2992 = load i64, ptr %slot532, align 8
  %cmp2993 = icmp eq i64 %v2992, 0
  %cv2994 = zext i1 %cmp2993 to i32
  store i32 %cv2994, ptr %slot533, align 8
  %v2995 = load i32, ptr %slot533, align 8
  %cv2996 = zext i32 %v2995 to i64
  %cond2997 = icmp ne i64 %cv2996, 0
  br i1 %cond2997, label %bb_rcglast725, label %bb_rcgdec725
bb_rcglast725:
  %v2998 = load i64, ptr %slot524, align 8
  %op2999 = sub i64 %v2998, 32
  store i64 %op2999, ptr %slot534, align 8
  %v3000 = load i64, ptr %slot524, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %rgep3002 = getelementptr i8, ptr %p3001, i64 -32
  %ld3003 = load i64, ptr %rgep3002, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3003, ptr %slot535, align 8
  %v3004 = load i64, ptr %slot535, align 8
  %cmp3005 = icmp ne i64 %v3004, 0
  %cv3006 = zext i1 %cmp3005 to i32
  store i32 %cv3006, ptr %slot536, align 8
  %v3007 = load i32, ptr %slot536, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcgdec725, label %bb_rcgslow725
bb_rcgslow725:
  %v3010 = load i64, ptr %slot523, align 8
  %v3011 = load i64, ptr %slot520, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v3010, i64 %v3011) nomerge, !dbg !136
  br label %bb_rcgdone725
bb_rcgdec725:
  %v3012 = load i64, ptr %slot532, align 8
  %v3013 = load i64, ptr %slot524, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %rgep3015 = getelementptr i8, ptr %p3014, i64 -24
  store i64 %v3012, ptr %rgep3015, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear725
bb_rcgclear725:
  %v3016 = load i64, ptr %slot520, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  store i64 0, ptr %p3017, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone725
bb_rcgdone725:
  br label %bb_rcslotdone709
bb_rcslotowner709:
  %v3018 = load i64, ptr %slot43, align 8
  store i64 %v3018, ptr %slot537, align 8
  %v3019 = load i64, ptr %slot520, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i64, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3021, ptr %slot538, align 8
  %v3022 = load i64, ptr %slot538, align 8
  %cmp3023 = icmp ne i64 %v3022, 0
  %cv3024 = zext i1 %cmp3023 to i32
  store i32 %cv3024, ptr %slot539, align 8
  %v3025 = load i32, ptr %slot539, align 8
  %cv3026 = zext i32 %v3025 to i64
  %cond3027 = icmp ne i64 %cv3026, 0
  br i1 %cond3027, label %bb_rcgnn740, label %bb_rcgdone740
bb_rcgnn740:
  %v3028 = load i64, ptr %slot538, align 8
  %op3029 = sub i64 %v3028, 16
  store i64 %op3029, ptr %slot540, align 8
  %v3030 = load i64, ptr %slot538, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  %rgep3032 = getelementptr i8, ptr %p3031, i64 -16
  %ld3033 = load i64, ptr %rgep3032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3033, ptr %slot541, align 8
  %v3034 = load i64, ptr %slot541, align 8
  %op3035 = and i64 %v3034, 4611686018427387906
  store i64 %op3035, ptr %slot542, align 8
  %v3036 = load i64, ptr %slot542, align 8
  %cmp3037 = icmp ne i64 %v3036, 0
  %cv3038 = zext i1 %cmp3037 to i32
  store i32 %cv3038, ptr %slot543, align 8
  %v3039 = load i32, ptr %slot543, align 8
  %cv3040 = zext i32 %v3039 to i64
  %cond3041 = icmp ne i64 %cv3040, 0
  br i1 %cond3041, label %bb_rcgclear740, label %bb_rcgcounted740
bb_rcgcounted740:
  %v3042 = load i64, ptr %slot538, align 8
  %op3043 = sub i64 %v3042, 32
  store i64 %op3043, ptr %slot544, align 8
  %v3044 = load i64, ptr %slot538, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  %rgep3046 = getelementptr i8, ptr %p3045, i64 -32
  %ld3047 = load i64, ptr %rgep3046, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3047, ptr %slot545, align 8
  %v3048 = load i64, ptr %slot545, align 8
  %op3049 = sub i64 %v3048, 1
  store i64 %op3049, ptr %slot546, align 8
  %v3050 = load i64, ptr %slot546, align 8
  %cmp3051 = icmp eq i64 %v3050, 0
  %cv3052 = zext i1 %cmp3051 to i32
  store i32 %cv3052, ptr %slot547, align 8
  %v3053 = load i32, ptr %slot547, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcglast740, label %bb_rcgdec740
bb_rcglast740:
  %v3056 = load i64, ptr %slot538, align 8
  %op3057 = sub i64 %v3056, 24
  store i64 %op3057, ptr %slot548, align 8
  %v3058 = load i64, ptr %slot538, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %rgep3060 = getelementptr i8, ptr %p3059, i64 -24
  %ld3061 = load i64, ptr %rgep3060, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3061, ptr %slot549, align 8
  %v3062 = load i64, ptr %slot549, align 8
  %cmp3063 = icmp ne i64 %v3062, 0
  %cv3064 = zext i1 %cmp3063 to i32
  store i32 %cv3064, ptr %slot550, align 8
  %v3065 = load i32, ptr %slot550, align 8
  %cv3066 = zext i32 %v3065 to i64
  %cond3067 = icmp ne i64 %cv3066, 0
  br i1 %cond3067, label %bb_rcgdec740, label %bb_rcgslow740
bb_rcgslow740:
  %v3068 = load i64, ptr %slot537, align 8
  %v3069 = load i64, ptr %slot520, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v3068, i64 %v3069) nomerge, !dbg !136
  br label %bb_rcgdone740
bb_rcgdec740:
  %v3070 = load i64, ptr %slot546, align 8
  %v3071 = load i64, ptr %slot538, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  %rgep3073 = getelementptr i8, ptr %p3072, i64 -32
  store i64 %v3070, ptr %rgep3073, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear740
bb_rcgclear740:
  %v3074 = load i64, ptr %slot520, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i64 0, ptr %p3075, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone740
bb_rcgdone740:
  br label %bb_rcslotdone709
bb_rcslotdone709:
  %v3076 = load i64, ptr %slot518, align 8
  %op3077 = add i64 %v3076, 0
  store i64 %op3077, ptr %slot551, align 8
  store i64 0, ptr %slot552, align 8
  %v3078 = load i64, ptr %slot551, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %ld3080 = load i64, ptr %p3079, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3080, ptr %slot553, align 8
  %v3081 = load i64, ptr %slot553, align 8
  %cmp3082 = icmp ne i64 %v3081, 0
  %cv3083 = zext i1 %cmp3082 to i32
  store i32 %cv3083, ptr %slot554, align 8
  %v3084 = load i32, ptr %slot554, align 8
  %cv3085 = zext i32 %v3084 to i64
  %cond3086 = icmp ne i64 %cv3085, 0
  br i1 %cond3086, label %bb_rcguniquenn746, label %bb_rcgunique746
bb_rcguniquenn746:
  %v3087 = load i64, ptr %slot553, align 8
  %op3088 = sub i64 %v3087, 16
  store i64 %op3088, ptr %slot555, align 8
  %v3089 = load i64, ptr %slot553, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %rgep3091 = getelementptr i8, ptr %p3090, i64 -16
  %ld3092 = load i64, ptr %rgep3091, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3092, ptr %slot556, align 8
  %v3093 = load i64, ptr %slot556, align 8
  %op3094 = and i64 %v3093, 6917529027641081858
  store i64 %op3094, ptr %slot557, align 8
  %v3095 = load i64, ptr %slot557, align 8
  %cmp3096 = icmp ne i64 %v3095, 0
  %cv3097 = zext i1 %cmp3096 to i32
  store i32 %cv3097, ptr %slot558, align 8
  %v3098 = load i32, ptr %slot558, align 8
  %cv3099 = zext i32 %v3098 to i64
  %cond3100 = icmp ne i64 %cv3099, 0
  br i1 %cond3100, label %bb_rcguniqueslow746, label %bb_rcguniquecount746
bb_rcguniquecount746:
  %v3101 = load i64, ptr %slot553, align 8
  %op3102 = sub i64 %v3101, 32
  store i64 %op3102, ptr %slot559, align 8
  %v3103 = load i64, ptr %slot553, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  %rgep3105 = getelementptr i8, ptr %p3104, i64 -32
  %ld3106 = load i64, ptr %rgep3105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3106, ptr %slot560, align 8
  %v3107 = load i64, ptr %slot560, align 8
  %cmp3108 = icmp ult i64 %v3107, 2
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot561, align 8
  %v3110 = load i32, ptr %slot561, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcgunique746, label %bb_rcguniqueslow746
bb_rcguniqueslow746:
  %v3113 = load i64, ptr %slot1, align 8
  %p3114 = inttoptr i64 %v3113 to ptr
  %p3115 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v3116 = load i64, ptr %slot551, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  %v3118 = load i64, ptr %slot552, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  %call3120 = call i32 @myl_qbe_rc_unique_field(ptr %p3114, ptr %p3115, ptr %p3117, ptr %p3119) nomerge, !dbg !136
  store i32 %call3120, ptr %slot562, align 8
  %v3121 = load i32, ptr %slot562, align 8
  %cv3122 = zext i32 %v3121 to i64
  %cond3123 = icmp ne i64 %cv3122, 0
  br i1 %cond3123, label %bb_rcunique756, label %bb_failure
bb_rcunique756:
  br label %bb_rcgunique746
bb_rcgunique746:
  %v3124 = load i64, ptr %slot551, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %ld3126 = load i64, ptr %p3125, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3126, ptr %slot563, align 8
  %v3127 = load i64, ptr %slot563, align 8
  %v3128 = load i64, ptr %slot34, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  store i64 %v3127, ptr %p3129, align 8, !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot34, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %ld3132 = load i64, ptr %p3131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3132, ptr %slot564, align 8
  %v3133 = load i64, ptr %slot12, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  %ld3135 = load i32, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3135, ptr %slot565, align 8
  %v3136 = load i32, ptr %slot565, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcslotdrop761, label %bb_rcslotdone761
bb_rcslotdrop761:
  %v3139 = load i64, ptr %slot12, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  store i32 0, ptr %p3140, align 4, !alias.scope !3, !noalias !4
  %v3141 = load i64, ptr %slot19, align 8
  store i64 %v3141, ptr %slot566, align 8
  %v3142 = load i64, ptr %slot13, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot567, align 8
  %v3145 = load i32, ptr %slot567, align 8
  %op3146 = and i32 %v3145, 28
  store i32 %op3146, ptr %slot568, align 8
  %v3147 = load i32, ptr %slot568, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_rcslotrole761, label %bb_rcslotowner761
bb_rcslotrole761:
  %v3150 = load i64, ptr %slot43, align 8
  store i64 %v3150, ptr %slot569, align 8
  %v3151 = load i64, ptr %slot566, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i64, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3153, ptr %slot570, align 8
  %v3154 = load i64, ptr %slot570, align 8
  %cmp3155 = icmp ne i64 %v3154, 0
  %cv3156 = zext i1 %cmp3155 to i32
  store i32 %cv3156, ptr %slot571, align 8
  %v3157 = load i32, ptr %slot571, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcgnn777, label %bb_rcgdone777
bb_rcgnn777:
  %v3160 = load i64, ptr %slot570, align 8
  %op3161 = sub i64 %v3160, 16
  store i64 %op3161, ptr %slot572, align 8
  %v3162 = load i64, ptr %slot570, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  %rgep3164 = getelementptr i8, ptr %p3163, i64 -16
  %ld3165 = load i64, ptr %rgep3164, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3165, ptr %slot573, align 8
  %v3166 = load i64, ptr %slot573, align 8
  %op3167 = and i64 %v3166, 4611686018427387906
  store i64 %op3167, ptr %slot574, align 8
  %v3168 = load i64, ptr %slot574, align 8
  %cmp3169 = icmp ne i64 %v3168, 0
  %cv3170 = zext i1 %cmp3169 to i32
  store i32 %cv3170, ptr %slot575, align 8
  %v3171 = load i32, ptr %slot575, align 8
  %cv3172 = zext i32 %v3171 to i64
  %cond3173 = icmp ne i64 %cv3172, 0
  br i1 %cond3173, label %bb_rcgclear777, label %bb_rcgcounted777
bb_rcgcounted777:
  %v3174 = load i64, ptr %slot570, align 8
  %op3175 = sub i64 %v3174, 24
  store i64 %op3175, ptr %slot576, align 8
  %v3176 = load i64, ptr %slot570, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  %rgep3178 = getelementptr i8, ptr %p3177, i64 -24
  %ld3179 = load i64, ptr %rgep3178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3179, ptr %slot577, align 8
  %v3180 = load i64, ptr %slot577, align 8
  %op3181 = sub i64 %v3180, 1
  store i64 %op3181, ptr %slot578, align 8
  %v3182 = load i64, ptr %slot578, align 8
  %cmp3183 = icmp eq i64 %v3182, 0
  %cv3184 = zext i1 %cmp3183 to i32
  store i32 %cv3184, ptr %slot579, align 8
  %v3185 = load i32, ptr %slot579, align 8
  %cv3186 = zext i32 %v3185 to i64
  %cond3187 = icmp ne i64 %cv3186, 0
  br i1 %cond3187, label %bb_rcglast777, label %bb_rcgdec777
bb_rcglast777:
  %v3188 = load i64, ptr %slot570, align 8
  %op3189 = sub i64 %v3188, 32
  store i64 %op3189, ptr %slot580, align 8
  %v3190 = load i64, ptr %slot570, align 8
  %p3191 = inttoptr i64 %v3190 to ptr
  %rgep3192 = getelementptr i8, ptr %p3191, i64 -32
  %ld3193 = load i64, ptr %rgep3192, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3193, ptr %slot581, align 8
  %v3194 = load i64, ptr %slot581, align 8
  %cmp3195 = icmp ne i64 %v3194, 0
  %cv3196 = zext i1 %cmp3195 to i32
  store i32 %cv3196, ptr %slot582, align 8
  %v3197 = load i32, ptr %slot582, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcgdec777, label %bb_rcgslow777
bb_rcgslow777:
  %v3200 = load i64, ptr %slot569, align 8
  %v3201 = load i64, ptr %slot566, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v3200, i64 %v3201) nomerge, !dbg !136
  br label %bb_rcgdone777
bb_rcgdec777:
  %v3202 = load i64, ptr %slot578, align 8
  %v3203 = load i64, ptr %slot570, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  %rgep3205 = getelementptr i8, ptr %p3204, i64 -24
  store i64 %v3202, ptr %rgep3205, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear777
bb_rcgclear777:
  %v3206 = load i64, ptr %slot566, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i64 0, ptr %p3207, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone777
bb_rcgdone777:
  br label %bb_rcslotdone761
bb_rcslotowner761:
  %v3208 = load i64, ptr %slot43, align 8
  store i64 %v3208, ptr %slot583, align 8
  %v3209 = load i64, ptr %slot566, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  %ld3211 = load i64, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3211, ptr %slot584, align 8
  %v3212 = load i64, ptr %slot584, align 8
  %cmp3213 = icmp ne i64 %v3212, 0
  %cv3214 = zext i1 %cmp3213 to i32
  store i32 %cv3214, ptr %slot585, align 8
  %v3215 = load i32, ptr %slot585, align 8
  %cv3216 = zext i32 %v3215 to i64
  %cond3217 = icmp ne i64 %cv3216, 0
  br i1 %cond3217, label %bb_rcgnn792, label %bb_rcgdone792
bb_rcgnn792:
  %v3218 = load i64, ptr %slot584, align 8
  %op3219 = sub i64 %v3218, 16
  store i64 %op3219, ptr %slot586, align 8
  %v3220 = load i64, ptr %slot584, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %rgep3222 = getelementptr i8, ptr %p3221, i64 -16
  %ld3223 = load i64, ptr %rgep3222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3223, ptr %slot587, align 8
  %v3224 = load i64, ptr %slot587, align 8
  %op3225 = and i64 %v3224, 4611686018427387906
  store i64 %op3225, ptr %slot588, align 8
  %v3226 = load i64, ptr %slot588, align 8
  %cmp3227 = icmp ne i64 %v3226, 0
  %cv3228 = zext i1 %cmp3227 to i32
  store i32 %cv3228, ptr %slot589, align 8
  %v3229 = load i32, ptr %slot589, align 8
  %cv3230 = zext i32 %v3229 to i64
  %cond3231 = icmp ne i64 %cv3230, 0
  br i1 %cond3231, label %bb_rcgclear792, label %bb_rcgcounted792
bb_rcgcounted792:
  %v3232 = load i64, ptr %slot584, align 8
  %op3233 = sub i64 %v3232, 32
  store i64 %op3233, ptr %slot590, align 8
  %v3234 = load i64, ptr %slot584, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  %rgep3236 = getelementptr i8, ptr %p3235, i64 -32
  %ld3237 = load i64, ptr %rgep3236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3237, ptr %slot591, align 8
  %v3238 = load i64, ptr %slot591, align 8
  %op3239 = sub i64 %v3238, 1
  store i64 %op3239, ptr %slot592, align 8
  %v3240 = load i64, ptr %slot592, align 8
  %cmp3241 = icmp eq i64 %v3240, 0
  %cv3242 = zext i1 %cmp3241 to i32
  store i32 %cv3242, ptr %slot593, align 8
  %v3243 = load i32, ptr %slot593, align 8
  %cv3244 = zext i32 %v3243 to i64
  %cond3245 = icmp ne i64 %cv3244, 0
  br i1 %cond3245, label %bb_rcglast792, label %bb_rcgdec792
bb_rcglast792:
  %v3246 = load i64, ptr %slot584, align 8
  %op3247 = sub i64 %v3246, 24
  store i64 %op3247, ptr %slot594, align 8
  %v3248 = load i64, ptr %slot584, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %rgep3250 = getelementptr i8, ptr %p3249, i64 -24
  %ld3251 = load i64, ptr %rgep3250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3251, ptr %slot595, align 8
  %v3252 = load i64, ptr %slot595, align 8
  %cmp3253 = icmp ne i64 %v3252, 0
  %cv3254 = zext i1 %cmp3253 to i32
  store i32 %cv3254, ptr %slot596, align 8
  %v3255 = load i32, ptr %slot596, align 8
  %cv3256 = zext i32 %v3255 to i64
  %cond3257 = icmp ne i64 %cv3256, 0
  br i1 %cond3257, label %bb_rcgdec792, label %bb_rcgslow792
bb_rcgslow792:
  %v3258 = load i64, ptr %slot583, align 8
  %v3259 = load i64, ptr %slot566, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v3258, i64 %v3259) nomerge, !dbg !136
  br label %bb_rcgdone792
bb_rcgdec792:
  %v3260 = load i64, ptr %slot592, align 8
  %v3261 = load i64, ptr %slot584, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  %rgep3263 = getelementptr i8, ptr %p3262, i64 -32
  store i64 %v3260, ptr %rgep3263, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear792
bb_rcgclear792:
  %v3264 = load i64, ptr %slot566, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  store i64 0, ptr %p3265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone792
bb_rcgdone792:
  br label %bb_rcslotdone761
bb_rcslotdone761:
  %v3266 = load i64, ptr %slot564, align 8
  %v3267 = load i64, ptr %slot31, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  store i64 %v3266, ptr %p3268, align 8, !alias.scope !3, !noalias !4
  %v3269 = load i64, ptr %slot26, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %ld3271 = load i64, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3271, ptr %slot597, align 8
  %v3272 = load i64, ptr %slot597, align 8
  %v3273 = load i64, ptr %slot34, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  store i64 %v3272, ptr %p3274, align 8, !alias.scope !3, !noalias !4
  %v3275 = load i64, ptr %slot34, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  %ld3277 = load i64, ptr %p3276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3277, ptr %slot598, align 8
  %v3278 = load i64, ptr %slot598, align 8
  %v3279 = load i64, ptr %slot33, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  store i64 %v3278, ptr %p3280, align 8, !alias.scope !3, !noalias !4
  %v3281 = load i64, ptr %slot33, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  %ld3283 = load i64, ptr %p3282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3283, ptr %slot599, align 8
  %v3284 = load i64, ptr %slot599, align 8
  %v3285 = load i64, ptr %slot34, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  store i64 %v3284, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  %v3287 = load i64, ptr %slot35, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  store i64 0, ptr %p3288, align 8, !alias.scope !3, !noalias !4
  %v3289 = load i64, ptr %slot35, align 8
  %p3290 = inttoptr i64 %v3289 to ptr
  %ld3291 = load i64, ptr %p3290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3291, ptr %slot600, align 8
  %v3292 = load i64, ptr %slot34, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %ld3294 = load i64, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3294, ptr %slot601, align 8
  %v3295 = load i64, ptr %slot601, align 8
  %v3296 = load i64, ptr %slot600, align 8
  %cmp3297 = icmp slt i64 %v3295, %v3296
  %cv3298 = zext i1 %cmp3297 to i64
  store i64 %cv3298, ptr %slot602, align 8
  %v3299 = load i64, ptr %slot602, align 8
  %v3300 = load i64, ptr %slot34, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i64 %v3299, ptr %p3301, align 8, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot34, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %ld3304 = load i64, ptr %p3303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3304, ptr %slot603, align 8
  %v3305 = load i64, ptr %slot603, align 8
  %cond3306 = icmp ne i64 %v3305, 0
  br i1 %cond3306, label %bb_next840, label %bb_i35
bb_next840:
  %v3307 = load i64, ptr %slot31, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %ld3309 = load i64, ptr %p3308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3309, ptr %slot604, align 8
  %v3310 = load i64, ptr %slot604, align 8
  %op3311 = add i64 %v3310, 0
  store i64 %op3311, ptr %slot605, align 8
  %v3312 = load i64, ptr %slot605, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  %ld3314 = load i64, ptr %p3313, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3314, ptr %slot606, align 8
  %v3315 = load i64, ptr %slot606, align 8
  %v3316 = load i64, ptr %slot34, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  store i64 %v3315, ptr %p3317, align 8, !alias.scope !3, !noalias !4
  %v3318 = load i64, ptr %slot34, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  %ld3320 = load i64, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3320, ptr %slot607, align 8
  %v3321 = load i64, ptr %slot607, align 8
  %cmp3322 = icmp ugt i64 %v3321, 9223372036854775807
  %cv3323 = zext i1 %cmp3322 to i64
  store i64 %cv3323, ptr %slot608, align 8
  %v3324 = load i64, ptr %slot608, align 8
  %cond3325 = icmp ne i64 %v3324, 0
  br i1 %cond3325, label %bb_cast_overflow845, label %bb_cast_ok845
bb_cast_overflow845:
  %v3326 = load i64, ptr %slot1, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %v3328 = load i64, ptr %slot607, align 8
  call void @myl_qbe_fail_cast(ptr %p3327, i64 %v3328, i64 320) nomerge, !dbg !138
  unreachable
bb_cast_ok845:
  %v3329 = load i64, ptr %slot607, align 8
  %v3330 = load i64, ptr %slot34, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  store i64 %v3329, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  %v3332 = load i64, ptr %slot33, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot609, align 8
  %v3335 = load i64, ptr %slot609, align 8
  %v3336 = load i64, ptr %slot35, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  store i64 %v3335, ptr %p3337, align 8, !alias.scope !3, !noalias !4
  %v3338 = load i64, ptr %slot35, align 8
  %p3339 = inttoptr i64 %v3338 to ptr
  %ld3340 = load i64, ptr %p3339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3340, ptr %slot610, align 8
  %v3341 = load i64, ptr %slot34, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i64, ptr %p3342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3343, ptr %slot611, align 8
  %v3344 = load i64, ptr %slot611, align 8
  %v3345 = load i64, ptr %slot610, align 8
  %ovpair3347 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3344, i64 %v3345)
  %op3346 = extractvalue { i64, i1 } %ovpair3347, 0
  %ov3348 = extractvalue { i64, i1 } %ovpair3347, 1
  store i64 %op3346, ptr %slot612, align 8
  %v3349 = load i64, ptr %slot611, align 8
  %v3350 = load i64, ptr %slot612, align 8
  %op3351 = xor i64 %v3349, %v3350
  store i64 %op3351, ptr %slot613, align 8
  %v3352 = load i64, ptr %slot610, align 8
  %v3353 = load i64, ptr %slot612, align 8
  %op3354 = xor i64 %v3352, %v3353
  store i64 %op3354, ptr %slot614, align 8
  %v3355 = load i64, ptr %slot613, align 8
  %v3356 = load i64, ptr %slot614, align 8
  %op3357 = and i64 %v3355, %v3356
  store i64 %op3357, ptr %slot615, align 8
  %cv3358 = zext i1 %ov3348 to i64
  store i64 %cv3358, ptr %slot616, align 8
  %v3359 = load i64, ptr %slot616, align 8
  %cond3360 = icmp ne i64 %v3359, 0
  br i1 %cond3360, label %bb_overflow849, label %bb_checked849
bb_overflow849:
  %v3361 = load i64, ptr %slot1, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  %v3363 = load i64, ptr %slot611, align 8
  %v3364 = load i64, ptr %slot610, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3362, i64 0, i64 %v3363, i64 %v3364, i64 64) nomerge, !dbg !140
  unreachable
bb_checked849:
  %v3365 = load i64, ptr %slot612, align 8
  %v3366 = load i64, ptr %slot34, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  store i64 %v3365, ptr %p3367, align 8, !alias.scope !3, !noalias !4
  %v3368 = load i64, ptr %slot34, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  %ld3370 = load i64, ptr %p3369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3370, ptr %slot617, align 8
  %v3371 = load i64, ptr %slot617, align 8
  %v3372 = load i64, ptr %slot33, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  store i64 %v3371, ptr %p3373, align 8, !alias.scope !3, !noalias !4
  br label %bb_i35
bb_i35:
  %v3374 = load i64, ptr %slot33, align 8
  %p3375 = inttoptr i64 %v3374 to ptr
  %ld3376 = load i64, ptr %p3375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3376, ptr %slot618, align 8
  %v3377 = load i64, ptr %slot618, align 8
  %v3378 = load i64, ptr %slot34, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  store i64 %v3377, ptr %p3379, align 8, !alias.scope !3, !noalias !4
  %v3380 = load i64, ptr %slot32, align 8
  %v3381 = load i64, ptr %slot38, align 8
  %p3382 = inttoptr i64 %v3380 to ptr
  %p3383 = inttoptr i64 %v3381 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3383, ptr %p3382, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v3384 = load i64, ptr %slot38, align 8
  %v3385 = load i64, ptr %slot35, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i64 %v3384, ptr %p3386, align 8, !alias.scope !3, !noalias !4
  %v3387 = load i64, ptr %slot31, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i64, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3389, ptr %slot619, align 8
  %v3390 = load i64, ptr %slot35, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %ld3392 = load i64, ptr %p3391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3392, ptr %slot620, align 8
  %v3393 = load i64, ptr %slot34, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %ld3395 = load i64, ptr %p3394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3395, ptr %slot621, align 8
  %v3396 = load i64, ptr %slot619, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %ld3398 = load i64, ptr %p3397, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3398, ptr %slot622, align 8
  %v3399 = load i64, ptr %slot621, align 8
  %v3400 = load i64, ptr %slot622, align 8
  %cmp3401 = icmp ult i64 %v3399, %v3400
  %cv3402 = zext i1 %cmp3401 to i64
  store i64 %cv3402, ptr %slot623, align 8
  %v3403 = load i64, ptr %slot623, align 8
  %cond3404 = icmp ne i64 %v3403, 0
  br i1 %cond3404, label %bb_success862, label %bb_failed862
bb_failed862:
  %v3405 = load i64, ptr %slot1, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %v3407 = load i64, ptr %slot621, align 8
  %v3408 = load i64, ptr %slot622, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3406, i64 %v3407, i64 %v3408) nomerge, !dbg !142
  unreachable
bb_success862:
  %v3409 = load i64, ptr %slot35, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i64, ptr %p3410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3411, ptr %slot624, align 8
  %v3412 = load i64, ptr %slot43, align 8
  %v3413 = load i64, ptr %slot619, align 8
  %v3414 = load i64, ptr %slot621, align 8
  %v3415 = load i64, ptr %slot624, align 8
  %call3416 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v3412, i64 %v3413, i64 %v3414, i64 %v3415) nomerge, !dbg !142
  store i32 %call3416, ptr %slot625, align 8
  %v3417 = load i32, ptr %slot625, align 8
  %cv3418 = zext i32 %v3417 to i64
  %cond3419 = icmp ne i64 %cv3418, 0
  br i1 %cond3419, label %bb_success865, label %bb_failed865
bb_failed865:
  %v3420 = load i64, ptr %slot1, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3421) nomerge, !dbg !142
  unreachable
bb_success865:
  %v3422 = load i64, ptr %slot34, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  store i64 0, ptr %p3423, align 8, !alias.scope !3, !noalias !4
  %v3424 = load i64, ptr %slot14, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  %ld3426 = load i32, ptr %p3425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3426, ptr %slot626, align 8
  %v3427 = load i32, ptr %slot626, align 8
  %cv3428 = zext i32 %v3427 to i64
  %cond3429 = icmp ne i64 %cv3428, 0
  br i1 %cond3429, label %bb_rcslotdrop868, label %bb_rcslotdone868
bb_rcslotdrop868:
  %v3430 = load i64, ptr %slot14, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  store i32 0, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  %v3432 = load i64, ptr %slot20, align 8
  store i64 %v3432, ptr %slot627, align 8
  %v3433 = load i64, ptr %slot15, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  %ld3435 = load i32, ptr %p3434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3435, ptr %slot628, align 8
  %v3436 = load i32, ptr %slot628, align 8
  %op3437 = and i32 %v3436, 28
  store i32 %op3437, ptr %slot629, align 8
  %v3438 = load i32, ptr %slot629, align 8
  %cv3439 = zext i32 %v3438 to i64
  %cond3440 = icmp ne i64 %cv3439, 0
  br i1 %cond3440, label %bb_rcslotrole868, label %bb_rcslotowner868
bb_rcslotrole868:
  %v3441 = load i64, ptr %slot43, align 8
  store i64 %v3441, ptr %slot630, align 8
  %v3442 = load i64, ptr %slot630, align 8
  %v3443 = load i64, ptr %slot627, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3442, i64 %v3443) nomerge, !dbg !142
  br label %bb_rcslotdone868
bb_rcslotowner868:
  %v3444 = load i64, ptr %slot43, align 8
  store i64 %v3444, ptr %slot631, align 8
  %v3445 = load i64, ptr %slot631, align 8
  %v3446 = load i64, ptr %slot627, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3445, i64 %v3446) nomerge, !dbg !142
  br label %bb_rcslotdone868
bb_rcslotdone868:
  %v3447 = load i64, ptr %slot34, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  store i64 0, ptr %p3448, align 8, !alias.scope !3, !noalias !4
  %v3449 = load i64, ptr %slot34, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %ld3451 = load i64, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3451, ptr %slot632, align 8
  %v3452 = load i64, ptr %slot22, align 8
  %p3454 = inttoptr i64 %v3452 to ptr
  %gep3455 = getelementptr i8, ptr %p3454, i64 24
  %op3453 = ptrtoint ptr %gep3455 to i64
  store i64 %op3453, ptr %slot633, align 8
  %v3456 = load i64, ptr %slot633, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  %ld3458 = load i32, ptr %p3457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3458, ptr %slot634, align 8
  %v3459 = load i32, ptr %slot634, align 8
  %cv3460 = zext i32 %v3459 to i64
  %cond3461 = icmp ne i64 %cv3460, 0
  br i1 %cond3461, label %bb_rcscopesopen878, label %bb_rcscopesclosed878
bb_rcscopesopen878:
  %v3462 = load i64, ptr %slot24, align 8
  %p3464 = inttoptr i64 %v3462 to ptr
  %gep3465 = getelementptr i8, ptr %p3464, i64 0
  %op3463 = ptrtoint ptr %gep3465 to i64
  store i64 %op3463, ptr %slot635, align 8
  %v3466 = load i64, ptr %slot22, align 8
  %v3467 = load i64, ptr %slot635, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  store i64 %v3466, ptr %p3468, align 8, !alias.scope !3, !noalias !4
  %v3469 = load i64, ptr %slot1, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %v3471 = load i64, ptr %slot24, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p3470, ptr %p3472, i64 1) nomerge, !dbg !144
  br label %bb_rcscopesclosed878
bb_rcscopesclosed878:
  %v3473 = load i64, ptr %slot12, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %ld3475 = load i32, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3475, ptr %slot636, align 8
  %v3476 = load i32, ptr %slot636, align 8
  %cv3477 = zext i32 %v3476 to i64
  %cond3478 = icmp ne i64 %cv3477, 0
  br i1 %cond3478, label %bb_rcslotdrop882, label %bb_rcslotdone882
bb_rcslotdrop882:
  %v3479 = load i64, ptr %slot12, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i32 0, ptr %p3480, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone882
bb_rcslotdone882:
  %v3481 = load i64, ptr %slot10, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i32, ptr %p3482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3483, ptr %slot637, align 8
  %v3484 = load i32, ptr %slot637, align 8
  %cv3485 = zext i32 %v3484 to i64
  %cond3486 = icmp ne i64 %cv3485, 0
  br i1 %cond3486, label %bb_rcslotdrop885, label %bb_rcslotdone885
bb_rcslotdrop885:
  %v3487 = load i64, ptr %slot10, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  store i32 0, ptr %p3488, align 4, !alias.scope !3, !noalias !4
  %v3489 = load i64, ptr %slot32, align 8
  store i64 %v3489, ptr %slot638, align 8
  %v3490 = load i64, ptr %slot11, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  %ld3492 = load i32, ptr %p3491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3492, ptr %slot639, align 8
  %v3493 = load i32, ptr %slot639, align 8
  %op3494 = and i32 %v3493, 28
  store i32 %op3494, ptr %slot640, align 8
  %v3495 = load i32, ptr %slot640, align 8
  %cv3496 = zext i32 %v3495 to i64
  %cond3497 = icmp ne i64 %cv3496, 0
  br i1 %cond3497, label %bb_rcslotrole885, label %bb_rcslotowner885
bb_rcslotrole885:
  %v3498 = load i64, ptr %slot43, align 8
  store i64 %v3498, ptr %slot641, align 8
  %v3499 = load i64, ptr %slot641, align 8
  %v3500 = load i64, ptr %slot638, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3499, i64 %v3500) nomerge, !dbg !144
  br label %bb_rcslotdone885
bb_rcslotowner885:
  %v3501 = load i64, ptr %slot43, align 8
  store i64 %v3501, ptr %slot642, align 8
  %v3502 = load i64, ptr %slot642, align 8
  %v3503 = load i64, ptr %slot638, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3502, i64 %v3503) nomerge, !dbg !144
  br label %bb_rcslotdone885
bb_rcslotdone885:
  %v3504 = load i64, ptr %slot8, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i32, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3506, ptr %slot643, align 8
  %v3507 = load i32, ptr %slot643, align 8
  %cv3508 = zext i32 %v3507 to i64
  %cond3509 = icmp ne i64 %cv3508, 0
  br i1 %cond3509, label %bb_rcslotdrop931, label %bb_rcslotdone931
bb_rcslotdrop931:
  %v3510 = load i64, ptr %slot8, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i32 0, ptr %p3511, align 4, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot29, align 8
  store i64 %v3512, ptr %slot644, align 8
  %v3513 = load i64, ptr %slot9, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  %ld3515 = load i32, ptr %p3514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3515, ptr %slot645, align 8
  %v3516 = load i32, ptr %slot645, align 8
  %op3517 = and i32 %v3516, 28
  store i32 %op3517, ptr %slot646, align 8
  %v3518 = load i32, ptr %slot646, align 8
  %cv3519 = zext i32 %v3518 to i64
  %cond3520 = icmp ne i64 %cv3519, 0
  br i1 %cond3520, label %bb_rcslotrole931, label %bb_rcslotowner931
bb_rcslotrole931:
  %v3521 = load i64, ptr %slot43, align 8
  store i64 %v3521, ptr %slot647, align 8
  %v3522 = load i64, ptr %slot647, align 8
  %v3523 = load i64, ptr %slot644, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3522, i64 %v3523) nomerge, !dbg !144
  br label %bb_rcslotdone931
bb_rcslotowner931:
  %v3524 = load i64, ptr %slot43, align 8
  store i64 %v3524, ptr %slot648, align 8
  %v3525 = load i64, ptr %slot648, align 8
  %v3526 = load i64, ptr %slot644, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3525, i64 %v3526) nomerge, !dbg !144
  br label %bb_rcslotdone931
bb_rcslotdone931:
  %v3527 = load i64, ptr %slot6, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i32, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3529, ptr %slot649, align 8
  %v3530 = load i32, ptr %slot649, align 8
  %cv3531 = zext i32 %v3530 to i64
  %cond3532 = icmp ne i64 %cv3531, 0
  br i1 %cond3532, label %bb_rcslotdrop940, label %bb_rcslotdone940
bb_rcslotdrop940:
  %v3533 = load i64, ptr %slot6, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  store i32 0, ptr %p3534, align 4, !alias.scope !3, !noalias !4
  %v3535 = load i64, ptr %slot28, align 8
  store i64 %v3535, ptr %slot650, align 8
  %v3536 = load i64, ptr %slot7, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  %ld3538 = load i32, ptr %p3537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3538, ptr %slot651, align 8
  %v3539 = load i32, ptr %slot651, align 8
  %op3540 = and i32 %v3539, 28
  store i32 %op3540, ptr %slot652, align 8
  %v3541 = load i32, ptr %slot652, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcslotrole940, label %bb_rcslotowner940
bb_rcslotrole940:
  %v3544 = load i64, ptr %slot43, align 8
  store i64 %v3544, ptr %slot653, align 8
  %v3545 = load i64, ptr %slot653, align 8
  %v3546 = load i64, ptr %slot650, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3545, i64 %v3546) nomerge, !dbg !144
  br label %bb_rcslotdone940
bb_rcslotowner940:
  %v3547 = load i64, ptr %slot43, align 8
  store i64 %v3547, ptr %slot654, align 8
  %v3548 = load i64, ptr %slot654, align 8
  %v3549 = load i64, ptr %slot650, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3548, i64 %v3549) nomerge, !dbg !144
  br label %bb_rcslotdone940
bb_rcslotdone940:
  %v3550 = load i64, ptr %slot632, align 8
  ret i64 %v3550
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64, i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1d7419ba0d9bd7e7ee6870cf43902b87519d25b5577326ecd50ac6944acafca6", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1d7419ba0d9bd7e7ee6870cf43902b87519d25b5577326ecd50ac6944acafca6", linkageName: "myl_f_1d7419ba0d9bd7e7ee6870cf43902b87519d25b5577326ecd50ac6944acafca6", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16064082213584814145, i64 0, !"myl_f_1d7419ba0d9bd7e7ee6870cf43902b87519d25b5577326ecd50ac6944acafca6"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!132 = !DILocation(line: 21, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!134 = !DILocation(line: 23, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!136 = !DILocation(line: 24, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!138 = !DILocation(line: 32, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!140 = !DILocation(line: 34, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!142 = !DILocation(line: 39, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!144 = !DILocation(line: 42, column: 0, scope: !145)
