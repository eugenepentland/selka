target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v116 = load i64, ptr %slot1, align 8
  %op117 = add i64 %v116, 32
  store i64 %op117, ptr %slot3, align 8
  %mem118 = alloca i8, i64 8, align 8
  %ptr119 = ptrtoint ptr %mem118 to i64
  store i64 %ptr119, ptr %slot4, align 8
  %mem120 = alloca i8, i64 8, align 8
  %ptr121 = ptrtoint ptr %mem120 to i64
  store i64 %ptr121, ptr %slot5, align 8
  %mem122 = alloca i8, i64 8, align 8
  %ptr123 = ptrtoint ptr %mem122 to i64
  store i64 %ptr123, ptr %slot6, align 8
  %mem124 = alloca i8, i64 8, align 8
  %ptr125 = ptrtoint ptr %mem124 to i64
  store i64 %ptr125, ptr %slot7, align 8
  %mem126 = alloca i8, i64 40, align 8
  %ptr127 = ptrtoint ptr %mem126 to i64
  store i64 %ptr127, ptr %slot8, align 8
  %mem128 = alloca i8, i64 8, align 8
  %ptr129 = ptrtoint ptr %mem128 to i64
  store i64 %ptr129, ptr %slot9, align 8
  %mem130 = alloca i8, i64 40, align 8
  %ptr131 = ptrtoint ptr %mem130 to i64
  store i64 %ptr131, ptr %slot10, align 8
  %mem132 = alloca i8, i64 8, align 8
  %ptr133 = ptrtoint ptr %mem132 to i64
  store i64 %ptr133, ptr %slot11, align 8
  %mem134 = alloca i8, i64 40, align 8
  %ptr135 = ptrtoint ptr %mem134 to i64
  store i64 %ptr135, ptr %slot12, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem136 = alloca i8, i64 8, align 8
  %ptr137 = ptrtoint ptr %mem136 to i64
  store i64 %ptr137, ptr %slot13, align 8
  %v138 = load i64, ptr %slot1, align 8
  %op139 = add i64 %v138, 64
  store i64 %op139, ptr %slot14, align 8
  %v140 = load i64, ptr %slot14, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !4, !noalias !3
  store i64 %ld142, ptr %slot15, align 8
  %stack143 = call ptr @llvm.stacksave()
  %stackaddr144 = ptrtoint ptr %stack143 to i64
  %v145 = load i64, ptr %slot15, align 8
  %cmp146 = icmp ult i64 %stackaddr144, %v145
  %cv147 = zext i1 %cmp146 to i64
  store i64 %cv147, ptr %slot16, align 8
  %v148 = load i64, ptr %slot16, align 8
  %cond149 = icmp ne i64 %v148, 0
  br i1 %cond149, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v150 = load i64, ptr %slot1, align 8
  %p151 = inttoptr i64 %v150 to ptr
  call void @myl_qbe_fail_frame(ptr %p151) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v152 = load i64, ptr %slot2, align 8
  %v153 = load i64, ptr %slot4, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v155 = load i64, ptr %slot6, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 0, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot6, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot17, align 8
  %v160 = load i64, ptr %slot17, align 8
  %v161 = load i64, ptr %slot5, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot4, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot18, align 8
  %v166 = load i64, ptr %slot18, align 8
  %v167 = load i64, ptr %slot6, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot4, align 8
  %p170 = inttoptr i64 %v169 to ptr
  %ld171 = load i64, ptr %p170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld171, ptr %slot19, align 8
  %v172 = load i64, ptr %slot19, align 8
  %v173 = load i64, ptr %slot6, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot4, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld177, ptr %slot20, align 8
  %v178 = load i64, ptr %slot20, align 8
  %v179 = load i64, ptr %slot6, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 %v178, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot5, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i64, ptr %p182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld183, ptr %slot21, align 8
  %v184 = load i64, ptr %slot21, align 8
  %v185 = load i64, ptr %slot7, align 8
  %p186 = inttoptr i64 %v185 to ptr
  store i64 %v184, ptr %p186, align 8, !alias.scope !3, !noalias !4
  %v187 = load i64, ptr %slot4, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot22, align 8
  %v190 = load i64, ptr %slot22, align 8
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot5, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot23, align 8
  %v196 = load i64, ptr %slot4, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot24, align 8
  %v199 = load i64, ptr %slot24, align 8
  %op200 = add i64 %v199, 369
  store i64 %op200, ptr %slot25, align 8
  %v201 = load i64, ptr %slot23, align 8
  %cv202 = trunc i64 %v201 to i8
  %v203 = load i64, ptr %slot25, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i8 %cv202, ptr %p204, align 1, !alias.scope !4, !noalias !3
  %v205 = load i64, ptr %slot6, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 0, ptr %p206, align 8, !alias.scope !3, !noalias !4
  br label %bb_i12
bb_i12:
  %v207 = load i64, ptr %slot4, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot26, align 8
  %v210 = load i64, ptr %slot26, align 8
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i64 %v210, ptr %p212, align 8, !alias.scope !3, !noalias !4
  %v213 = load i64, ptr %slot6, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld215, ptr %slot27, align 8
  %v216 = load i64, ptr %slot27, align 8
  %op217 = add i64 %v216, 288
  store i64 %op217, ptr %slot28, align 8
  %v218 = load i64, ptr %slot28, align 8
  %v219 = load i64, ptr %slot6, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot6, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot29, align 8
  %v224 = load i64, ptr %slot29, align 8
  %op225 = add i64 %v224, 0
  store i64 %op225, ptr %slot30, align 8
  %v226 = load i64, ptr %slot30, align 8
  %v227 = load i64, ptr %slot6, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i64 %v226, ptr %p228, align 8, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot6, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld231, ptr %slot31, align 8
  %v232 = load i64, ptr %slot8, align 8
  store i64 %v232, ptr %slot32, align 8
  %v233 = load i64, ptr %slot31, align 8
  %v234 = load i64, ptr %slot32, align 8
  %p235 = inttoptr i64 %v233 to ptr
  %p236 = inttoptr i64 %v234 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p236, ptr %p235, i64 4, i1 false), !alias.scope !10000000
  %v237 = load i64, ptr %slot32, align 8
  %v238 = load i64, ptr %slot6, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 %v237, ptr %p239, align 8, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot9, align 8
  store i64 %v240, ptr %slot33, align 8
  %v241 = load i64, ptr %slot33, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i32 0, ptr %p242, align 4, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot33, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 39, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot33, align 8
  %v246 = load i64, ptr %slot7, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 %v245, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot7, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot34, align 8
  %v251 = load i64, ptr %slot6, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot35, align 8
  %v254 = load i64, ptr %slot35, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i32, ptr %p255, align 4, !alias.scope !3, !noalias !4
  %ext257 = zext i32 %ld256 to i64
  store i64 %ext257, ptr %slot36, align 8
  %v258 = load i64, ptr %slot34, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i32, ptr %p259, align 4, !alias.scope !3, !noalias !4
  %ext261 = zext i32 %ld260 to i64
  store i64 %ext261, ptr %slot37, align 8
  %v262 = load i64, ptr %slot36, align 8
  %v263 = load i64, ptr %slot37, align 8
  %cmp264 = icmp ne i64 %v262, %v263
  %cv265 = zext i1 %cmp264 to i64
  store i64 %cv265, ptr %slot38, align 8
  %v266 = load i64, ptr %slot38, align 8
  %v267 = load i64, ptr %slot6, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot6, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot39, align 8
  %v272 = load i64, ptr %slot39, align 8
  %cond273 = icmp ne i64 %v272, 0
  br i1 %cond273, label %bb_next50, label %bb_i82
bb_next50:
  %v274 = load i64, ptr %slot4, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot40, align 8
  %v277 = load i64, ptr %slot40, align 8
  %v278 = load i64, ptr %slot6, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot6, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot41, align 8
  %v283 = load i64, ptr %slot41, align 8
  %op284 = add i64 %v283, 328
  store i64 %op284, ptr %slot42, align 8
  %v285 = load i64, ptr %slot42, align 8
  %v286 = load i64, ptr %slot6, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot6, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot43, align 8
  %v291 = load i64, ptr %slot43, align 8
  %op292 = add i64 %v291, 0
  store i64 %op292, ptr %slot44, align 8
  %v293 = load i64, ptr %slot44, align 8
  %v294 = load i64, ptr %slot6, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot6, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot45, align 8
  %v299 = load i64, ptr %slot10, align 8
  store i64 %v299, ptr %slot46, align 8
  %v300 = load i64, ptr %slot45, align 8
  %v301 = load i64, ptr %slot46, align 8
  %p302 = inttoptr i64 %v300 to ptr
  %p303 = inttoptr i64 %v301 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p303, ptr %p302, i64 4, i1 false), !alias.scope !10000000
  %v304 = load i64, ptr %slot46, align 8
  %v305 = load i64, ptr %slot6, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i64 %v304, ptr %p306, align 8, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot11, align 8
  store i64 %v307, ptr %slot47, align 8
  %v308 = load i64, ptr %slot47, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i32 0, ptr %p309, align 4, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot47, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i32 8, ptr %p311, align 4, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot47, align 8
  %v313 = load i64, ptr %slot7, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot7, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot48, align 8
  %v318 = load i64, ptr %slot6, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld320, ptr %slot49, align 8
  %v321 = load i64, ptr %slot49, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i32, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %ext324 = zext i32 %ld323 to i64
  store i64 %ext324, ptr %slot50, align 8
  %v325 = load i64, ptr %slot48, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i32, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %ext328 = zext i32 %ld327 to i64
  store i64 %ext328, ptr %slot51, align 8
  %v329 = load i64, ptr %slot50, align 8
  %v330 = load i64, ptr %slot51, align 8
  %cmp331 = icmp eq i64 %v329, %v330
  %cv332 = zext i1 %cmp331 to i64
  store i64 %cv332, ptr %slot52, align 8
  %v333 = load i64, ptr %slot52, align 8
  %v334 = load i64, ptr %slot6, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 %v333, ptr %p335, align 8, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot6, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot53, align 8
  %v339 = load i64, ptr %slot53, align 8
  %cond340 = icmp ne i64 %v339, 0
  br i1 %cond340, label %bb_next82, label %bb_i26
bb_next82:
  %v341 = load i64, ptr %slot6, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 0, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot6, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %ld345 = load i64, ptr %p344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld345, ptr %slot54, align 8
  %v346 = load i64, ptr %slot54, align 8
  ret i64 %v346
bb_i26:
  %v347 = load i64, ptr %slot4, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %ld349 = load i64, ptr %p348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld349, ptr %slot55, align 8
  %v350 = load i64, ptr %slot55, align 8
  %v351 = load i64, ptr %slot6, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 %v350, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot6, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot56, align 8
  %v356 = load i64, ptr %slot56, align 8
  %op357 = add i64 %v356, 288
  store i64 %op357, ptr %slot57, align 8
  %v358 = load i64, ptr %slot57, align 8
  %v359 = load i64, ptr %slot6, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot6, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i64, ptr %p362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld363, ptr %slot58, align 8
  %v364 = load i64, ptr %slot58, align 8
  %op365 = add i64 %v364, 0
  store i64 %op365, ptr %slot59, align 8
  %v366 = load i64, ptr %slot59, align 8
  %v367 = load i64, ptr %slot6, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i64 %v366, ptr %p368, align 8, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot6, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot60, align 8
  %v372 = load i64, ptr %slot12, align 8
  store i64 %v372, ptr %slot61, align 8
  %v373 = load i64, ptr %slot60, align 8
  %v374 = load i64, ptr %slot61, align 8
  %p375 = inttoptr i64 %v373 to ptr
  %p376 = inttoptr i64 %v374 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p376, ptr %p375, i64 4, i1 false), !alias.scope !10000000
  %v377 = load i64, ptr %slot61, align 8
  %v378 = load i64, ptr %slot6, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 %v377, ptr %p379, align 8, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot6, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot62, align 8
  %v383 = load i64, ptr %slot62, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i32, ptr %p384, align 4, !alias.scope !3, !noalias !4
  %ext386 = zext i32 %ld385 to i64
  store i64 %ext386, ptr %slot63, align 8
  %v387 = load i64, ptr %slot63, align 8
  %cmp388 = icmp eq i64 %v387, 0
  %cv389 = zext i1 %cmp388 to i64
  store i64 %cv389, ptr %slot64, align 8
  %v390 = load i64, ptr %slot64, align 8
  %cond391 = icmp ne i64 %v390, 0
  br i1 %cond391, label %bb_rcarm131, label %bb_rcarmnext131
bb_rcarm131:
  br label %bb_i46
bb_rcarmnext131:
  %v392 = load i64, ptr %slot63, align 8
  %cmp393 = icmp eq i64 %v392, 1
  %cv394 = zext i1 %cmp393 to i64
  store i64 %cv394, ptr %slot65, align 8
  %v395 = load i64, ptr %slot65, align 8
  %cond396 = icmp ne i64 %v395, 0
  br i1 %cond396, label %bb_rcarm132, label %bb_rcarmnext132
bb_rcarm132:
  br label %bb_i47
bb_rcarmnext132:
  %v397 = load i64, ptr %slot63, align 8
  %cmp398 = icmp eq i64 %v397, 2
  %cv399 = zext i1 %cmp398 to i64
  store i64 %cv399, ptr %slot66, align 8
  %v400 = load i64, ptr %slot66, align 8
  %cond401 = icmp ne i64 %v400, 0
  br i1 %cond401, label %bb_rcarm133, label %bb_rcarmnext133
bb_rcarm133:
  br label %bb_i48
bb_rcarmnext133:
  %v402 = load i64, ptr %slot63, align 8
  %cmp403 = icmp eq i64 %v402, 3
  %cv404 = zext i1 %cmp403 to i64
  store i64 %cv404, ptr %slot67, align 8
  %v405 = load i64, ptr %slot67, align 8
  %cond406 = icmp ne i64 %v405, 0
  br i1 %cond406, label %bb_rcarm134, label %bb_rcarmnext134
bb_rcarm134:
  br label %bb_i49
bb_rcarmnext134:
  %v407 = load i64, ptr %slot63, align 8
  %cmp408 = icmp eq i64 %v407, 4
  %cv409 = zext i1 %cmp408 to i64
  store i64 %cv409, ptr %slot68, align 8
  %v410 = load i64, ptr %slot68, align 8
  %cond411 = icmp ne i64 %v410, 0
  br i1 %cond411, label %bb_rcarm135, label %bb_rcarmnext135
bb_rcarm135:
  br label %bb_i50
bb_rcarmnext135:
  %v412 = load i64, ptr %slot63, align 8
  %cmp413 = icmp eq i64 %v412, 5
  %cv414 = zext i1 %cmp413 to i64
  store i64 %cv414, ptr %slot69, align 8
  %v415 = load i64, ptr %slot69, align 8
  %cond416 = icmp ne i64 %v415, 0
  br i1 %cond416, label %bb_rcarm136, label %bb_rcarmnext136
bb_rcarm136:
  br label %bb_i51
bb_rcarmnext136:
  %v417 = load i64, ptr %slot63, align 8
  %cmp418 = icmp eq i64 %v417, 6
  %cv419 = zext i1 %cmp418 to i64
  store i64 %cv419, ptr %slot70, align 8
  %v420 = load i64, ptr %slot70, align 8
  %cond421 = icmp ne i64 %v420, 0
  br i1 %cond421, label %bb_rcarm137, label %bb_rcarmnext137
bb_rcarm137:
  br label %bb_i52
bb_rcarmnext137:
  %v422 = load i64, ptr %slot63, align 8
  %cmp423 = icmp eq i64 %v422, 7
  %cv424 = zext i1 %cmp423 to i64
  store i64 %cv424, ptr %slot71, align 8
  %v425 = load i64, ptr %slot71, align 8
  %cond426 = icmp ne i64 %v425, 0
  br i1 %cond426, label %bb_rcarm138, label %bb_rcarmnext138
bb_rcarm138:
  br label %bb_i53
bb_rcarmnext138:
  %v427 = load i64, ptr %slot63, align 8
  %cmp428 = icmp eq i64 %v427, 8
  %cv429 = zext i1 %cmp428 to i64
  store i64 %cv429, ptr %slot72, align 8
  %v430 = load i64, ptr %slot72, align 8
  %cond431 = icmp ne i64 %v430, 0
  br i1 %cond431, label %bb_rcarm139, label %bb_rcarmnext139
bb_rcarm139:
  br label %bb_i54
bb_rcarmnext139:
  %v432 = load i64, ptr %slot63, align 8
  %cmp433 = icmp eq i64 %v432, 9
  %cv434 = zext i1 %cmp433 to i64
  store i64 %cv434, ptr %slot73, align 8
  %v435 = load i64, ptr %slot73, align 8
  %cond436 = icmp ne i64 %v435, 0
  br i1 %cond436, label %bb_rcarm140, label %bb_rcarmnext140
bb_rcarm140:
  br label %bb_i55
bb_rcarmnext140:
  %v437 = load i64, ptr %slot63, align 8
  %cmp438 = icmp eq i64 %v437, 10
  %cv439 = zext i1 %cmp438 to i64
  store i64 %cv439, ptr %slot74, align 8
  %v440 = load i64, ptr %slot74, align 8
  %cond441 = icmp ne i64 %v440, 0
  br i1 %cond441, label %bb_rcarm141, label %bb_rcarmnext141
bb_rcarm141:
  br label %bb_i56
bb_rcarmnext141:
  %v442 = load i64, ptr %slot63, align 8
  %cmp443 = icmp eq i64 %v442, 11
  %cv444 = zext i1 %cmp443 to i64
  store i64 %cv444, ptr %slot75, align 8
  %v445 = load i64, ptr %slot75, align 8
  %cond446 = icmp ne i64 %v445, 0
  br i1 %cond446, label %bb_rcarm142, label %bb_rcarmnext142
bb_rcarm142:
  br label %bb_i57
bb_rcarmnext142:
  %v447 = load i64, ptr %slot63, align 8
  %cmp448 = icmp eq i64 %v447, 12
  %cv449 = zext i1 %cmp448 to i64
  store i64 %cv449, ptr %slot76, align 8
  %v450 = load i64, ptr %slot76, align 8
  %cond451 = icmp ne i64 %v450, 0
  br i1 %cond451, label %bb_rcarm143, label %bb_rcarmnext143
bb_rcarm143:
  br label %bb_i58
bb_rcarmnext143:
  %v452 = load i64, ptr %slot63, align 8
  %cmp453 = icmp eq i64 %v452, 13
  %cv454 = zext i1 %cmp453 to i64
  store i64 %cv454, ptr %slot77, align 8
  %v455 = load i64, ptr %slot77, align 8
  %cond456 = icmp ne i64 %v455, 0
  br i1 %cond456, label %bb_rcarm144, label %bb_rcarmnext144
bb_rcarm144:
  br label %bb_i59
bb_rcarmnext144:
  %v457 = load i64, ptr %slot63, align 8
  %cmp458 = icmp eq i64 %v457, 14
  %cv459 = zext i1 %cmp458 to i64
  store i64 %cv459, ptr %slot78, align 8
  %v460 = load i64, ptr %slot78, align 8
  %cond461 = icmp ne i64 %v460, 0
  br i1 %cond461, label %bb_rcarm145, label %bb_rcarmnext145
bb_rcarm145:
  br label %bb_i60
bb_rcarmnext145:
  %v462 = load i64, ptr %slot63, align 8
  %cmp463 = icmp eq i64 %v462, 15
  %cv464 = zext i1 %cmp463 to i64
  store i64 %cv464, ptr %slot79, align 8
  %v465 = load i64, ptr %slot79, align 8
  %cond466 = icmp ne i64 %v465, 0
  br i1 %cond466, label %bb_rcarm146, label %bb_rcarmnext146
bb_rcarm146:
  br label %bb_i61
bb_rcarmnext146:
  %v467 = load i64, ptr %slot63, align 8
  %cmp468 = icmp eq i64 %v467, 16
  %cv469 = zext i1 %cmp468 to i64
  store i64 %cv469, ptr %slot80, align 8
  %v470 = load i64, ptr %slot80, align 8
  %cond471 = icmp ne i64 %v470, 0
  br i1 %cond471, label %bb_rcarm147, label %bb_rcarmnext147
bb_rcarm147:
  br label %bb_i62
bb_rcarmnext147:
  %v472 = load i64, ptr %slot63, align 8
  %cmp473 = icmp eq i64 %v472, 17
  %cv474 = zext i1 %cmp473 to i64
  store i64 %cv474, ptr %slot81, align 8
  %v475 = load i64, ptr %slot81, align 8
  %cond476 = icmp ne i64 %v475, 0
  br i1 %cond476, label %bb_rcarm148, label %bb_rcarmnext148
bb_rcarm148:
  br label %bb_i63
bb_rcarmnext148:
  %v477 = load i64, ptr %slot63, align 8
  %cmp478 = icmp eq i64 %v477, 18
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot82, align 8
  %v480 = load i64, ptr %slot82, align 8
  %cond481 = icmp ne i64 %v480, 0
  br i1 %cond481, label %bb_rcarm149, label %bb_rcarmnext149
bb_rcarm149:
  br label %bb_i64
bb_rcarmnext149:
  %v482 = load i64, ptr %slot63, align 8
  %cmp483 = icmp eq i64 %v482, 19
  %cv484 = zext i1 %cmp483 to i64
  store i64 %cv484, ptr %slot83, align 8
  %v485 = load i64, ptr %slot83, align 8
  %cond486 = icmp ne i64 %v485, 0
  br i1 %cond486, label %bb_rcarm150, label %bb_rcarmnext150
bb_rcarm150:
  br label %bb_i65
bb_rcarmnext150:
  %v487 = load i64, ptr %slot63, align 8
  %cmp488 = icmp eq i64 %v487, 20
  %cv489 = zext i1 %cmp488 to i64
  store i64 %cv489, ptr %slot84, align 8
  %v490 = load i64, ptr %slot84, align 8
  %cond491 = icmp ne i64 %v490, 0
  br i1 %cond491, label %bb_rcarm151, label %bb_rcarmnext151
bb_rcarm151:
  br label %bb_i66
bb_rcarmnext151:
  %v492 = load i64, ptr %slot63, align 8
  %cmp493 = icmp eq i64 %v492, 21
  %cv494 = zext i1 %cmp493 to i64
  store i64 %cv494, ptr %slot85, align 8
  %v495 = load i64, ptr %slot85, align 8
  %cond496 = icmp ne i64 %v495, 0
  br i1 %cond496, label %bb_rcarm152, label %bb_rcarmnext152
bb_rcarm152:
  br label %bb_i67
bb_rcarmnext152:
  %v497 = load i64, ptr %slot63, align 8
  %cmp498 = icmp eq i64 %v497, 22
  %cv499 = zext i1 %cmp498 to i64
  store i64 %cv499, ptr %slot86, align 8
  %v500 = load i64, ptr %slot86, align 8
  %cond501 = icmp ne i64 %v500, 0
  br i1 %cond501, label %bb_rcarm153, label %bb_rcarmnext153
bb_rcarm153:
  br label %bb_i68
bb_rcarmnext153:
  %v502 = load i64, ptr %slot63, align 8
  %cmp503 = icmp eq i64 %v502, 23
  %cv504 = zext i1 %cmp503 to i64
  store i64 %cv504, ptr %slot87, align 8
  %v505 = load i64, ptr %slot87, align 8
  %cond506 = icmp ne i64 %v505, 0
  br i1 %cond506, label %bb_rcarm154, label %bb_rcarmnext154
bb_rcarm154:
  br label %bb_i30
bb_rcarmnext154:
  %v507 = load i64, ptr %slot63, align 8
  %cmp508 = icmp eq i64 %v507, 24
  %cv509 = zext i1 %cmp508 to i64
  store i64 %cv509, ptr %slot88, align 8
  %v510 = load i64, ptr %slot88, align 8
  %cond511 = icmp ne i64 %v510, 0
  br i1 %cond511, label %bb_rcarm155, label %bb_rcarmnext155
bb_rcarm155:
  br label %bb_i69
bb_rcarmnext155:
  %v512 = load i64, ptr %slot63, align 8
  %cmp513 = icmp eq i64 %v512, 25
  %cv514 = zext i1 %cmp513 to i64
  store i64 %cv514, ptr %slot89, align 8
  %v515 = load i64, ptr %slot89, align 8
  %cond516 = icmp ne i64 %v515, 0
  br i1 %cond516, label %bb_rcarm156, label %bb_rcarmnext156
bb_rcarm156:
  br label %bb_i70
bb_rcarmnext156:
  %v517 = load i64, ptr %slot63, align 8
  %cmp518 = icmp eq i64 %v517, 26
  %cv519 = zext i1 %cmp518 to i64
  store i64 %cv519, ptr %slot90, align 8
  %v520 = load i64, ptr %slot90, align 8
  %cond521 = icmp ne i64 %v520, 0
  br i1 %cond521, label %bb_rcarm157, label %bb_rcarmnext157
bb_rcarm157:
  br label %bb_i36
bb_rcarmnext157:
  %v522 = load i64, ptr %slot63, align 8
  %cmp523 = icmp eq i64 %v522, 27
  %cv524 = zext i1 %cmp523 to i64
  store i64 %cv524, ptr %slot91, align 8
  %v525 = load i64, ptr %slot91, align 8
  %cond526 = icmp ne i64 %v525, 0
  br i1 %cond526, label %bb_rcarm158, label %bb_rcarmnext158
bb_rcarm158:
  br label %bb_i32
bb_rcarmnext158:
  %v527 = load i64, ptr %slot63, align 8
  %cmp528 = icmp eq i64 %v527, 28
  %cv529 = zext i1 %cmp528 to i64
  store i64 %cv529, ptr %slot92, align 8
  %v530 = load i64, ptr %slot92, align 8
  %cond531 = icmp ne i64 %v530, 0
  br i1 %cond531, label %bb_rcarm159, label %bb_rcarmnext159
bb_rcarm159:
  br label %bb_i38
bb_rcarmnext159:
  %v532 = load i64, ptr %slot63, align 8
  %cmp533 = icmp eq i64 %v532, 29
  %cv534 = zext i1 %cmp533 to i64
  store i64 %cv534, ptr %slot93, align 8
  %v535 = load i64, ptr %slot93, align 8
  %cond536 = icmp ne i64 %v535, 0
  br i1 %cond536, label %bb_rcarm160, label %bb_rcarmnext160
bb_rcarm160:
  br label %bb_i71
bb_rcarmnext160:
  %v537 = load i64, ptr %slot63, align 8
  %cmp538 = icmp eq i64 %v537, 30
  %cv539 = zext i1 %cmp538 to i64
  store i64 %cv539, ptr %slot94, align 8
  %v540 = load i64, ptr %slot94, align 8
  %cond541 = icmp ne i64 %v540, 0
  br i1 %cond541, label %bb_rcarm161, label %bb_rcarmnext161
bb_rcarm161:
  br label %bb_i72
bb_rcarmnext161:
  %v542 = load i64, ptr %slot63, align 8
  %cmp543 = icmp eq i64 %v542, 31
  %cv544 = zext i1 %cmp543 to i64
  store i64 %cv544, ptr %slot95, align 8
  %v545 = load i64, ptr %slot95, align 8
  %cond546 = icmp ne i64 %v545, 0
  br i1 %cond546, label %bb_rcarm162, label %bb_rcarmnext162
bb_rcarm162:
  br label %bb_i42
bb_rcarmnext162:
  %v547 = load i64, ptr %slot63, align 8
  %cmp548 = icmp eq i64 %v547, 32
  %cv549 = zext i1 %cmp548 to i64
  store i64 %cv549, ptr %slot96, align 8
  %v550 = load i64, ptr %slot96, align 8
  %cond551 = icmp ne i64 %v550, 0
  br i1 %cond551, label %bb_rcarm163, label %bb_rcarmnext163
bb_rcarm163:
  br label %bb_i44
bb_rcarmnext163:
  %v552 = load i64, ptr %slot63, align 8
  %cmp553 = icmp eq i64 %v552, 33
  %cv554 = zext i1 %cmp553 to i64
  store i64 %cv554, ptr %slot97, align 8
  %v555 = load i64, ptr %slot97, align 8
  %cond556 = icmp ne i64 %v555, 0
  br i1 %cond556, label %bb_rcarm164, label %bb_rcarmnext164
bb_rcarm164:
  br label %bb_i73
bb_rcarmnext164:
  %v557 = load i64, ptr %slot63, align 8
  %cmp558 = icmp eq i64 %v557, 34
  %cv559 = zext i1 %cmp558 to i64
  store i64 %cv559, ptr %slot98, align 8
  %v560 = load i64, ptr %slot98, align 8
  %cond561 = icmp ne i64 %v560, 0
  br i1 %cond561, label %bb_rcarm165, label %bb_rcarmnext165
bb_rcarm165:
  br label %bb_i74
bb_rcarmnext165:
  %v562 = load i64, ptr %slot63, align 8
  %cmp563 = icmp eq i64 %v562, 35
  %cv564 = zext i1 %cmp563 to i64
  store i64 %cv564, ptr %slot99, align 8
  %v565 = load i64, ptr %slot99, align 8
  %cond566 = icmp ne i64 %v565, 0
  br i1 %cond566, label %bb_rcarm166, label %bb_rcarmnext166
bb_rcarm166:
  br label %bb_i75
bb_rcarmnext166:
  %v567 = load i64, ptr %slot63, align 8
  %cmp568 = icmp eq i64 %v567, 36
  %cv569 = zext i1 %cmp568 to i64
  store i64 %cv569, ptr %slot100, align 8
  %v570 = load i64, ptr %slot100, align 8
  %cond571 = icmp ne i64 %v570, 0
  br i1 %cond571, label %bb_rcarm167, label %bb_rcarmnext167
bb_rcarm167:
  br label %bb_i34
bb_rcarmnext167:
  %v572 = load i64, ptr %slot63, align 8
  %cmp573 = icmp eq i64 %v572, 37
  %cv574 = zext i1 %cmp573 to i64
  store i64 %cv574, ptr %slot101, align 8
  %v575 = load i64, ptr %slot101, align 8
  %cond576 = icmp ne i64 %v575, 0
  br i1 %cond576, label %bb_rcarm168, label %bb_rcarmnext168
bb_rcarm168:
  br label %bb_i40
bb_rcarmnext168:
  %v577 = load i64, ptr %slot63, align 8
  %cmp578 = icmp eq i64 %v577, 38
  %cv579 = zext i1 %cmp578 to i64
  store i64 %cv579, ptr %slot102, align 8
  %v580 = load i64, ptr %slot102, align 8
  %cond581 = icmp ne i64 %v580, 0
  br i1 %cond581, label %bb_rcarm169, label %bb_rcarmnext169
bb_rcarm169:
  br label %bb_i76
bb_rcarmnext169:
  %v582 = load i64, ptr %slot63, align 8
  %cmp583 = icmp eq i64 %v582, 39
  %cv584 = zext i1 %cmp583 to i64
  store i64 %cv584, ptr %slot103, align 8
  %v585 = load i64, ptr %slot103, align 8
  %cond586 = icmp ne i64 %v585, 0
  br i1 %cond586, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  br label %bb_i77
bb_rcarmnext170:
  br label %bb_failure
bb_i30:
  %v587 = load i64, ptr %slot6, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 0, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot6, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld591, ptr %slot104, align 8
  %v592 = load i64, ptr %slot104, align 8
  ret i64 %v592
bb_i32:
  %v593 = load i64, ptr %slot6, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 0, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot6, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot105, align 8
  %v598 = load i64, ptr %slot105, align 8
  ret i64 %v598
bb_i34:
  %v599 = load i64, ptr %slot6, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i64 0, ptr %p600, align 8, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot6, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %ld603 = load i64, ptr %p602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld603, ptr %slot106, align 8
  %v604 = load i64, ptr %slot106, align 8
  ret i64 %v604
bb_i36:
  %v605 = load i64, ptr %slot6, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i64 0, ptr %p606, align 8, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot6, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i64, ptr %p608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld609, ptr %slot107, align 8
  %v610 = load i64, ptr %slot107, align 8
  ret i64 %v610
bb_i38:
  %v611 = load i64, ptr %slot6, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i64 0, ptr %p612, align 8, !alias.scope !3, !noalias !4
  %v613 = load i64, ptr %slot6, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %ld615 = load i64, ptr %p614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld615, ptr %slot108, align 8
  %v616 = load i64, ptr %slot108, align 8
  ret i64 %v616
bb_i40:
  %v617 = load i64, ptr %slot6, align 8
  %p618 = inttoptr i64 %v617 to ptr
  store i64 0, ptr %p618, align 8, !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot6, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld621, ptr %slot109, align 8
  %v622 = load i64, ptr %slot109, align 8
  ret i64 %v622
bb_i42:
  %v623 = load i64, ptr %slot6, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i64 0, ptr %p624, align 8, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot6, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i64, ptr %p626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld627, ptr %slot110, align 8
  %v628 = load i64, ptr %slot110, align 8
  ret i64 %v628
bb_i44:
  %v629 = load i64, ptr %slot6, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i64 0, ptr %p630, align 8, !alias.scope !3, !noalias !4
  %v631 = load i64, ptr %slot6, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i64, ptr %p632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld633, ptr %slot111, align 8
  %v634 = load i64, ptr %slot111, align 8
  ret i64 %v634
bb_i46:
  br label %bb_i78
bb_i47:
  br label %bb_i78
bb_i48:
  br label %bb_i78
bb_i49:
  br label %bb_i78
bb_i50:
  br label %bb_i78
bb_i51:
  br label %bb_i78
bb_i52:
  br label %bb_i78
bb_i53:
  br label %bb_i78
bb_i54:
  br label %bb_i78
bb_i55:
  br label %bb_i78
bb_i56:
  br label %bb_i78
bb_i57:
  br label %bb_i78
bb_i58:
  br label %bb_i78
bb_i59:
  br label %bb_i78
bb_i60:
  br label %bb_i78
bb_i61:
  br label %bb_i78
bb_i62:
  br label %bb_i78
bb_i63:
  br label %bb_i78
bb_i64:
  br label %bb_i78
bb_i65:
  br label %bb_i78
bb_i66:
  br label %bb_i78
bb_i67:
  br label %bb_i78
bb_i68:
  br label %bb_i78
bb_i69:
  br label %bb_i78
bb_i70:
  br label %bb_i78
bb_i71:
  br label %bb_i78
bb_i72:
  br label %bb_i78
bb_i73:
  br label %bb_i78
bb_i74:
  br label %bb_i78
bb_i75:
  br label %bb_i78
bb_i76:
  br label %bb_i78
bb_i77:
  br label %bb_i78
bb_i78:
  %v635 = load i64, ptr %slot4, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot112, align 8
  %v638 = load i64, ptr %slot112, align 8
  %v639 = load i64, ptr %slot6, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 %v638, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot6, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot113, align 8
  %v644 = load i64, ptr %slot1, align 8
  %v645 = load i64, ptr %slot113, align 8
  %call646 = call i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64 %v644, i64 %v645) nomerge, !dbg !112
  store i64 %call646, ptr %slot114, align 8
  %v647 = load i64, ptr %slot114, align 8
  %v648 = load i64, ptr %slot6, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i64 %v647, ptr %p649, align 8, !alias.scope !3, !noalias !4
  br label %bb_i12
bb_i82:
  %v650 = load i64, ptr %slot6, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i64 0, ptr %p651, align 8, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot6, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %ld654 = load i64, ptr %p653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld654, ptr %slot115, align 8
  %v655 = load i64, ptr %slot115, align 8
  ret i64 %v655
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba", linkageName: "myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14786047891560489707, i64 0, !"myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!112 = !DILocation(line: 80, column: 0, scope: !113)
