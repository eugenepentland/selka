target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %callresult56 = alloca [32 x i8], align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %callresult178 = alloca [40 x i8], align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v469 = load i64, ptr %slot1, align 8
  %op470 = add i64 %v469, 32
  store i64 %op470, ptr %slot3, align 8
  %mem471 = alloca i8, i64 8, align 8
  %ptr472 = ptrtoint ptr %mem471 to i64
  store i64 %ptr472, ptr %slot4, align 8
  %mem473 = alloca i8, i64 8, align 8
  %ptr474 = ptrtoint ptr %mem473 to i64
  store i64 %ptr474, ptr %slot5, align 8
  %mem475 = alloca i8, i64 8, align 8
  %ptr476 = ptrtoint ptr %mem475 to i64
  store i64 %ptr476, ptr %slot6, align 8
  %mem477 = alloca i8, i64 8, align 8
  %ptr478 = ptrtoint ptr %mem477 to i64
  store i64 %ptr478, ptr %slot7, align 8
  %mem479 = alloca i8, i64 8, align 8
  %ptr480 = ptrtoint ptr %mem479 to i64
  store i64 %ptr480, ptr %slot8, align 8
  %mem481 = alloca i8, i64 8, align 8
  %ptr482 = ptrtoint ptr %mem481 to i64
  store i64 %ptr482, ptr %slot9, align 8
  %mem483 = alloca i8, i64 8, align 8
  %ptr484 = ptrtoint ptr %mem483 to i64
  store i64 %ptr484, ptr %slot10, align 8
  %mem485 = alloca i8, i64 8, align 8
  %ptr486 = ptrtoint ptr %mem485 to i64
  store i64 %ptr486, ptr %slot11, align 8
  %mem487 = alloca i8, i64 8, align 8
  %ptr488 = ptrtoint ptr %mem487 to i64
  store i64 %ptr488, ptr %slot12, align 8
  %mem489 = alloca i8, i64 8, align 8
  %ptr490 = ptrtoint ptr %mem489 to i64
  store i64 %ptr490, ptr %slot13, align 8
  %mem491 = alloca i8, i64 8, align 8
  %ptr492 = ptrtoint ptr %mem491 to i64
  store i64 %ptr492, ptr %slot14, align 8
  %mem493 = alloca i8, i64 8, align 8
  %ptr494 = ptrtoint ptr %mem493 to i64
  store i64 %ptr494, ptr %slot15, align 8
  %mem495 = alloca i8, i64 312, align 8
  %ptr496 = ptrtoint ptr %mem495 to i64
  store i64 %ptr496, ptr %slot16, align 8
  %mem497 = alloca i8, i64 8, align 8
  %ptr498 = ptrtoint ptr %mem497 to i64
  store i64 %ptr498, ptr %slot17, align 8
  %mem499 = alloca i8, i64 40, align 8
  %ptr500 = ptrtoint ptr %mem499 to i64
  store i64 %ptr500, ptr %slot18, align 8
  %mem501 = alloca i8, i64 8, align 8
  %ptr502 = ptrtoint ptr %mem501 to i64
  store i64 %ptr502, ptr %slot19, align 8
  %mem503 = alloca i8, i64 8, align 8
  %ptr504 = ptrtoint ptr %mem503 to i64
  store i64 %ptr504, ptr %slot20, align 8
  %mem505 = alloca i8, i64 312, align 8
  %ptr506 = ptrtoint ptr %mem505 to i64
  store i64 %ptr506, ptr %slot21, align 8
  %mem507 = alloca i8, i64 32, align 8
  %ptr508 = ptrtoint ptr %mem507 to i64
  store i64 %ptr508, ptr %slot22, align 8
  %v509 = load i64, ptr %slot22, align 8
  %p511 = inttoptr i64 %v509 to ptr
  %gep512 = getelementptr i8, ptr %p511, i64 24
  %op510 = ptrtoint ptr %gep512 to i64
  store i64 %op510, ptr %slot23, align 8
  %v513 = load i64, ptr %slot23, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i64 0, ptr %p514, align 8, !alias.scope !3, !noalias !4
  %mem515 = alloca i8, i64 8, align 8
  %ptr516 = ptrtoint ptr %mem515 to i64
  store i64 %ptr516, ptr %slot24, align 8
  %mem517 = alloca i8, i64 8, align 8
  %ptr518 = ptrtoint ptr %mem517 to i64
  store i64 %ptr518, ptr %slot25, align 8
  %mem519 = alloca i8, i64 32, align 8
  %ptr520 = ptrtoint ptr %mem519 to i64
  store i64 %ptr520, ptr %slot26, align 8
  %mem521 = alloca i8, i64 40, align 8
  %ptr522 = ptrtoint ptr %mem521 to i64
  store i64 %ptr522, ptr %slot27, align 8
  %mem523 = alloca i8, i64 8, align 8
  %ptr524 = ptrtoint ptr %mem523 to i64
  store i64 %ptr524, ptr %slot28, align 8
  %mem525 = alloca i8, i64 8, align 8
  %ptr526 = ptrtoint ptr %mem525 to i64
  store i64 %ptr526, ptr %slot29, align 8
  %mem527 = alloca i8, i64 8, align 8
  %ptr528 = ptrtoint ptr %mem527 to i64
  store i64 %ptr528, ptr %slot30, align 8
  %mem529 = alloca i8, i64 8, align 8
  %ptr530 = ptrtoint ptr %mem529 to i64
  store i64 %ptr530, ptr %slot31, align 8
  %mem531 = alloca i8, i64 8, align 8
  %ptr532 = ptrtoint ptr %mem531 to i64
  store i64 %ptr532, ptr %slot32, align 8
  %mem533 = alloca i8, i64 40, align 8
  %ptr534 = ptrtoint ptr %mem533 to i64
  store i64 %ptr534, ptr %slot33, align 8
  %mem535 = alloca i8, i64 8, align 8
  %ptr536 = ptrtoint ptr %mem535 to i64
  store i64 %ptr536, ptr %slot34, align 8
  %mem537 = alloca i8, i64 40, align 8
  %ptr538 = ptrtoint ptr %mem537 to i64
  store i64 %ptr538, ptr %slot35, align 8
  %mem539 = alloca i8, i64 40, align 8
  %ptr540 = ptrtoint ptr %mem539 to i64
  store i64 %ptr540, ptr %slot36, align 8
  %mem541 = alloca i8, i64 8, align 8
  %ptr542 = ptrtoint ptr %mem541 to i64
  store i64 %ptr542, ptr %slot37, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem543 = alloca i8, i64 8, align 8
  %ptr544 = ptrtoint ptr %mem543 to i64
  store i64 %ptr544, ptr %slot38, align 8
  %v545 = load i64, ptr %slot1, align 8
  %op546 = add i64 %v545, 64
  store i64 %op546, ptr %slot39, align 8
  %v547 = load i64, ptr %slot39, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !4, !noalias !3
  store i64 %ld549, ptr %slot40, align 8
  %stack550 = call ptr @llvm.stacksave()
  %stackaddr551 = ptrtoint ptr %stack550 to i64
  %v552 = load i64, ptr %slot40, align 8
  %cmp553 = icmp ult i64 %stackaddr551, %v552
  %cv554 = zext i1 %cmp553 to i64
  store i64 %cv554, ptr %slot41, align 8
  %v555 = load i64, ptr %slot41, align 8
  %cond556 = icmp ne i64 %v555, 0
  br i1 %cond556, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v557 = load i64, ptr %slot1, align 8
  %p558 = inttoptr i64 %v557 to ptr
  call void @myl_qbe_fail_frame(ptr %p558) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v559 = load i64, ptr %slot28, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i64 0, ptr %p560, align 8, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot2, align 8
  %v562 = load i64, ptr %slot25, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot1, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %call566 = call ptr @myl_qbe_heap(ptr %p565) nomerge, !dbg !112
  %calladdr567 = ptrtoint ptr %call566 to i64
  store i64 %calladdr567, ptr %slot42, align 8
  %v568 = load i64, ptr %slot1, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %call570 = call i64 @myl_qbe_region_mark(ptr %p569) nomerge, !dbg !112
  store i64 %call570, ptr %slot43, align 8
  %v571 = load i64, ptr %slot4, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 0, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot5, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 0, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot6, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 0, ptr %p576, align 4, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot7, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i32 0, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot8, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i32 0, ptr %p580, align 4, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot9, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i32 0, ptr %p582, align 4, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot10, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i32 0, ptr %p584, align 4, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot11, align 8
  %p586 = inttoptr i64 %v585 to ptr
  store i32 0, ptr %p586, align 4, !alias.scope !3, !noalias !4
  %v587 = load i64, ptr %slot12, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i32 0, ptr %p588, align 4, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot13, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i32 0, ptr %p590, align 4, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot14, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 0, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot15, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 0, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot5, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i32 2, ptr %p596, align 4, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot7, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 2, ptr %p598, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v599 = load i64, ptr %slot25, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ld601 = load i64, ptr %p600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot44, align 8
  %v602 = load i64, ptr %slot44, align 8
  %v603 = load i64, ptr %slot29, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i64 %v602, ptr %p604, align 8, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot29, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %ld607 = load i64, ptr %p606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld607, ptr %slot45, align 8
  %v608 = load i64, ptr %slot45, align 8
  %op609 = add i64 %v608, 248
  store i64 %op609, ptr %slot46, align 8
  %v610 = load i64, ptr %slot46, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !4, !noalias !3
  store i64 %ld612, ptr %slot47, align 8
  %v613 = load i64, ptr %slot47, align 8
  %v614 = load i64, ptr %slot29, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 %v613, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot8, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i32, ptr %p617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld618, ptr %slot48, align 8
  %v619 = load i32, ptr %slot48, align 8
  %cv620 = zext i32 %v619 to i64
  %cond621 = icmp ne i64 %cv620, 0
  br i1 %cond621, label %bb_rcslotdrop18, label %bb_rcslotdone18
bb_rcslotdrop18:
  %v622 = load i64, ptr %slot8, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i32 0, ptr %p623, align 4, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot16, align 8
  store i64 %v624, ptr %slot49, align 8
  %v625 = load i64, ptr %slot9, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i32, ptr %p626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld627, ptr %slot50, align 8
  %v628 = load i32, ptr %slot50, align 8
  %op629 = and i32 %v628, 28
  store i32 %op629, ptr %slot51, align 8
  %v630 = load i32, ptr %slot51, align 8
  %cv631 = zext i32 %v630 to i64
  %cond632 = icmp ne i64 %cv631, 0
  br i1 %cond632, label %bb_rcslotrole18, label %bb_rcslotowner18
bb_rcslotrole18:
  %v633 = load i64, ptr %slot42, align 8
  store i64 %v633, ptr %slot52, align 8
  %v634 = load i64, ptr %slot52, align 8
  %v635 = load i64, ptr %slot49, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v634, i64 %v635) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotowner18:
  %v636 = load i64, ptr %slot42, align 8
  store i64 %v636, ptr %slot53, align 8
  %v637 = load i64, ptr %slot53, align 8
  %v638 = load i64, ptr %slot49, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v637, i64 %v638) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotdone18:
  %v639 = load i64, ptr %slot29, align 8
  %p640 = inttoptr i64 %v639 to ptr
  %ld641 = load i64, ptr %p640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld641, ptr %slot54, align 8
  %v642 = load i64, ptr %slot1, align 8
  %v643 = load i64, ptr %slot54, align 8
  call void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow(ptr sret([32 x i8]) align 8 %callresult56, i64 %v642, i64 %v643) nomerge, !dbg !116
  %addr644 = ptrtoint ptr %callresult56 to i64
  store i64 %addr644, ptr %slot55, align 8
  %v645 = load i64, ptr %slot55, align 8
  %v646 = load i64, ptr %slot29, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i64 %v645, ptr %p647, align 8, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot29, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot57, align 8
  %v651 = load i64, ptr %slot21, align 8
  store i64 %v651, ptr %slot58, align 8
  %v652 = load i64, ptr %slot42, align 8
  %v653 = load i64, ptr %slot58, align 8
  %v654 = load i64, ptr %slot57, align 8
  %call655 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_loan(i64 %v652, i64 %v653, i64 %v654) nomerge, !dbg !116
  store i32 %call655, ptr %slot59, align 8
  %v656 = load i32, ptr %slot59, align 8
  %cv657 = zext i32 %v656 to i64
  %cond658 = icmp ne i64 %cv657, 0
  br i1 %cond658, label %bb_rcsuccess30, label %bb_rcfailure30
bb_rcfailure30:
  %v659 = load i64, ptr %slot42, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %call661 = call i32 @myl_rc_take_failure(ptr %p660) nomerge, !dbg !116
  store i32 %call661, ptr %slot60, align 8
  %v662 = load i64, ptr %slot1, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %v664 = load i32, ptr %slot60, align 8
  %call665 = call i32 @myl_qbe_rc_status(ptr %p663, i32 %v664) nomerge, !dbg !116
  store i32 %call665, ptr %slot61, align 8
  br label %bb_failure
bb_rcsuccess30:
  %v666 = load i64, ptr %slot15, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i32 2, ptr %p667, align 4, !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot15, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i32 16, ptr %p669, align 4, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot14, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i32 1, ptr %p671, align 4, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot8, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i32, ptr %p673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld674, ptr %slot62, align 8
  %v675 = load i32, ptr %slot62, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcslotdrop38, label %bb_rcslotdone38
bb_rcslotdrop38:
  %v678 = load i64, ptr %slot8, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i32 0, ptr %p679, align 4, !alias.scope !3, !noalias !4
  %v680 = load i64, ptr %slot16, align 8
  store i64 %v680, ptr %slot63, align 8
  %v681 = load i64, ptr %slot9, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i32, ptr %p682, align 4, !alias.scope !3, !noalias !4
  store i32 %ld683, ptr %slot64, align 8
  %v684 = load i32, ptr %slot64, align 8
  %op685 = and i32 %v684, 28
  store i32 %op685, ptr %slot65, align 8
  %v686 = load i32, ptr %slot65, align 8
  %cv687 = zext i32 %v686 to i64
  %cond688 = icmp ne i64 %cv687, 0
  br i1 %cond688, label %bb_rcslotrole38, label %bb_rcslotowner38
bb_rcslotrole38:
  %v689 = load i64, ptr %slot42, align 8
  store i64 %v689, ptr %slot66, align 8
  %v690 = load i64, ptr %slot63, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %ld692 = load i64, ptr %p691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld692, ptr %slot67, align 8
  %v693 = load i64, ptr %slot67, align 8
  %cmp694 = icmp ne i64 %v693, 0
  %cv695 = zext i1 %cmp694 to i32
  store i32 %cv695, ptr %slot68, align 8
  %v696 = load i32, ptr %slot68, align 8
  %cv697 = zext i32 %v696 to i64
  %cond698 = icmp ne i64 %cv697, 0
  br i1 %cond698, label %bb_rcgnn54, label %bb_rcgdone54
bb_rcgnn54:
  %v699 = load i64, ptr %slot67, align 8
  %op700 = sub i64 %v699, 16
  store i64 %op700, ptr %slot69, align 8
  %v701 = load i64, ptr %slot67, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %rgep703 = getelementptr i8, ptr %p702, i64 -16
  %ld704 = load i64, ptr %rgep703, align 8, !alias.scope !9, !noalias !10
  store i64 %ld704, ptr %slot70, align 8
  %v705 = load i64, ptr %slot70, align 8
  %op706 = and i64 %v705, 4611686018427387906
  store i64 %op706, ptr %slot71, align 8
  %v707 = load i64, ptr %slot71, align 8
  %cmp708 = icmp ne i64 %v707, 0
  %cv709 = zext i1 %cmp708 to i32
  store i32 %cv709, ptr %slot72, align 8
  %v710 = load i32, ptr %slot72, align 8
  %cv711 = zext i32 %v710 to i64
  %cond712 = icmp ne i64 %cv711, 0
  br i1 %cond712, label %bb_rcgclear54, label %bb_rcgcounted54
bb_rcgcounted54:
  %v713 = load i64, ptr %slot67, align 8
  %op714 = sub i64 %v713, 24
  store i64 %op714, ptr %slot73, align 8
  %v715 = load i64, ptr %slot67, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %rgep717 = getelementptr i8, ptr %p716, i64 -24
  %ld718 = load i64, ptr %rgep717, align 8, !alias.scope !9, !noalias !10
  store i64 %ld718, ptr %slot74, align 8
  %v719 = load i64, ptr %slot74, align 8
  %op720 = sub i64 %v719, 1
  store i64 %op720, ptr %slot75, align 8
  %v721 = load i64, ptr %slot75, align 8
  %cmp722 = icmp eq i64 %v721, 0
  %cv723 = zext i1 %cmp722 to i32
  store i32 %cv723, ptr %slot76, align 8
  %v724 = load i32, ptr %slot76, align 8
  %cv725 = zext i32 %v724 to i64
  %cond726 = icmp ne i64 %cv725, 0
  br i1 %cond726, label %bb_rcglast54, label %bb_rcgdec54
bb_rcglast54:
  %v727 = load i64, ptr %slot67, align 8
  %op728 = sub i64 %v727, 32
  store i64 %op728, ptr %slot77, align 8
  %v729 = load i64, ptr %slot67, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %rgep731 = getelementptr i8, ptr %p730, i64 -32
  %ld732 = load i64, ptr %rgep731, align 8, !alias.scope !9, !noalias !10
  store i64 %ld732, ptr %slot78, align 8
  %v733 = load i64, ptr %slot78, align 8
  %cmp734 = icmp ne i64 %v733, 0
  %cv735 = zext i1 %cmp734 to i32
  store i32 %cv735, ptr %slot79, align 8
  %v736 = load i32, ptr %slot79, align 8
  %cv737 = zext i32 %v736 to i64
  %cond738 = icmp ne i64 %cv737, 0
  br i1 %cond738, label %bb_rcgdec54, label %bb_rcgslow54
bb_rcgslow54:
  %v739 = load i64, ptr %slot66, align 8
  %v740 = load i64, ptr %slot63, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v739, i64 %v740) nomerge, !dbg !116
  br label %bb_rcgdone54
bb_rcgdec54:
  %v741 = load i64, ptr %slot75, align 8
  %v742 = load i64, ptr %slot67, align 8
  %p743 = inttoptr i64 %v742 to ptr
  %rgep744 = getelementptr i8, ptr %p743, i64 -24
  store i64 %v741, ptr %rgep744, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear54
bb_rcgclear54:
  %v745 = load i64, ptr %slot63, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i64 0, ptr %p746, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone54
bb_rcgdone54:
  br label %bb_rcslotdone38
bb_rcslotowner38:
  %v747 = load i64, ptr %slot42, align 8
  store i64 %v747, ptr %slot80, align 8
  %v748 = load i64, ptr %slot63, align 8
  %p749 = inttoptr i64 %v748 to ptr
  %ld750 = load i64, ptr %p749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld750, ptr %slot81, align 8
  %v751 = load i64, ptr %slot81, align 8
  %cmp752 = icmp ne i64 %v751, 0
  %cv753 = zext i1 %cmp752 to i32
  store i32 %cv753, ptr %slot82, align 8
  %v754 = load i32, ptr %slot82, align 8
  %cv755 = zext i32 %v754 to i64
  %cond756 = icmp ne i64 %cv755, 0
  br i1 %cond756, label %bb_rcgnn69, label %bb_rcgdone69
bb_rcgnn69:
  %v757 = load i64, ptr %slot81, align 8
  %op758 = sub i64 %v757, 16
  store i64 %op758, ptr %slot83, align 8
  %v759 = load i64, ptr %slot81, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %rgep761 = getelementptr i8, ptr %p760, i64 -16
  %ld762 = load i64, ptr %rgep761, align 8, !alias.scope !9, !noalias !10
  store i64 %ld762, ptr %slot84, align 8
  %v763 = load i64, ptr %slot84, align 8
  %op764 = and i64 %v763, 4611686018427387906
  store i64 %op764, ptr %slot85, align 8
  %v765 = load i64, ptr %slot85, align 8
  %cmp766 = icmp ne i64 %v765, 0
  %cv767 = zext i1 %cmp766 to i32
  store i32 %cv767, ptr %slot86, align 8
  %v768 = load i32, ptr %slot86, align 8
  %cv769 = zext i32 %v768 to i64
  %cond770 = icmp ne i64 %cv769, 0
  br i1 %cond770, label %bb_rcgclear69, label %bb_rcgcounted69
bb_rcgcounted69:
  %v771 = load i64, ptr %slot81, align 8
  %op772 = sub i64 %v771, 32
  store i64 %op772, ptr %slot87, align 8
  %v773 = load i64, ptr %slot81, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %rgep775 = getelementptr i8, ptr %p774, i64 -32
  %ld776 = load i64, ptr %rgep775, align 8, !alias.scope !9, !noalias !10
  store i64 %ld776, ptr %slot88, align 8
  %v777 = load i64, ptr %slot88, align 8
  %op778 = sub i64 %v777, 1
  store i64 %op778, ptr %slot89, align 8
  %v779 = load i64, ptr %slot89, align 8
  %cmp780 = icmp eq i64 %v779, 0
  %cv781 = zext i1 %cmp780 to i32
  store i32 %cv781, ptr %slot90, align 8
  %v782 = load i32, ptr %slot90, align 8
  %cv783 = zext i32 %v782 to i64
  %cond784 = icmp ne i64 %cv783, 0
  br i1 %cond784, label %bb_rcglast69, label %bb_rcgdec69
bb_rcglast69:
  %v785 = load i64, ptr %slot81, align 8
  %op786 = sub i64 %v785, 24
  store i64 %op786, ptr %slot91, align 8
  %v787 = load i64, ptr %slot81, align 8
  %p788 = inttoptr i64 %v787 to ptr
  %rgep789 = getelementptr i8, ptr %p788, i64 -24
  %ld790 = load i64, ptr %rgep789, align 8, !alias.scope !9, !noalias !10
  store i64 %ld790, ptr %slot92, align 8
  %v791 = load i64, ptr %slot92, align 8
  %cmp792 = icmp ne i64 %v791, 0
  %cv793 = zext i1 %cmp792 to i32
  store i32 %cv793, ptr %slot93, align 8
  %v794 = load i32, ptr %slot93, align 8
  %cv795 = zext i32 %v794 to i64
  %cond796 = icmp ne i64 %cv795, 0
  br i1 %cond796, label %bb_rcgdec69, label %bb_rcgslow69
bb_rcgslow69:
  %v797 = load i64, ptr %slot80, align 8
  %v798 = load i64, ptr %slot63, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v797, i64 %v798) nomerge, !dbg !116
  br label %bb_rcgdone69
bb_rcgdec69:
  %v799 = load i64, ptr %slot89, align 8
  %v800 = load i64, ptr %slot81, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %rgep802 = getelementptr i8, ptr %p801, i64 -32
  store i64 %v799, ptr %rgep802, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear69
bb_rcgclear69:
  %v803 = load i64, ptr %slot63, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 0, ptr %p804, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone69
bb_rcgdone69:
  br label %bb_rcslotdone38
bb_rcslotdone38:
  %v805 = load i64, ptr %slot16, align 8
  store i64 %v805, ptr %slot94, align 8
  %v806 = load i64, ptr %slot21, align 8
  store i64 %v806, ptr %slot95, align 8
  %v807 = load i64, ptr %slot95, align 8
  %v808 = load i64, ptr %slot94, align 8
  %p809 = inttoptr i64 %v807 to ptr
  %p810 = inttoptr i64 %v808 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p810, ptr %p809, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot9, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i32 2, ptr %p812, align 4, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot15, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i32, ptr %p814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld815, ptr %slot96, align 8
  %v816 = load i32, ptr %slot96, align 8
  %v817 = load i64, ptr %slot9, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i32 %v816, ptr %p818, align 4, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot14, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i32 0, ptr %p820, align 4, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot8, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i32 1, ptr %p822, align 4, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot94, align 8
  %v824 = load i64, ptr %slot29, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i64 %v823, ptr %p825, align 8, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot29, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld828, ptr %slot97, align 8
  %v829 = load i64, ptr %slot8, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i32, ptr %p830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld831, ptr %slot98, align 8
  %v832 = load i64, ptr %slot9, align 8
  %p833 = inttoptr i64 %v832 to ptr
  %ld834 = load i32, ptr %p833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld834, ptr %slot99, align 8
  %v835 = load i32, ptr %slot99, align 8
  %op836 = and i32 %v835, 24
  store i32 %op836, ptr %slot99, align 8
  %v837 = load i32, ptr %slot99, align 8
  %cmp838 = icmp eq i32 %v837, 0
  %cv839 = zext i1 %cmp838 to i32
  store i32 %cv839, ptr %slot100, align 8
  %v840 = load i32, ptr %slot98, align 8
  %v841 = load i32, ptr %slot100, align 8
  %op842 = and i32 %v840, %v841
  store i32 %op842, ptr %slot101, align 8
  %v843 = load i32, ptr %slot101, align 8
  %cv844 = zext i32 %v843 to i64
  %cond845 = icmp ne i64 %cv844, 0
  br i1 %cond845, label %bb_rctake82, label %bb_rccopy82
bb_rctake82:
  %v846 = load i64, ptr %slot21, align 8
  store i64 %v846, ptr %slot102, align 8
  %v847 = load i64, ptr %slot43, align 8
  store i64 %v847, ptr %slot103, align 8
  %v848 = load i64, ptr %slot97, align 8
  %v849 = load i64, ptr %slot102, align 8
  %op850 = sub i64 %v848, %v849
  store i64 %op850, ptr %slot104, align 8
  %v851 = load i64, ptr %slot102, align 8
  %v852 = load i64, ptr %slot97, align 8
  %op853 = sub i64 %v851, %v852
  store i64 %op853, ptr %slot105, align 8
  %v854 = load i64, ptr %slot104, align 8
  %cmp855 = icmp ult i64 %v854, 32
  %cv856 = zext i1 %cmp855 to i32
  store i32 %cv856, ptr %slot106, align 8
  %v857 = load i64, ptr %slot105, align 8
  %cmp858 = icmp ult i64 %v857, 32
  %cv859 = zext i1 %cmp858 to i32
  store i32 %cv859, ptr %slot107, align 8
  %v860 = load i32, ptr %slot106, align 8
  %v861 = load i32, ptr %slot107, align 8
  %op862 = or i32 %v860, %v861
  store i32 %op862, ptr %slot108, align 8
  %v863 = load i32, ptr %slot108, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcmoveslow91, label %bb_rcmovecheck91
bb_rcmovecheck91:
  %v866 = load i64, ptr %slot97, align 8
  %op867 = add i64 %v866, 0
  store i64 %op867, ptr %slot109, align 8
  %v868 = load i64, ptr %slot109, align 8
  %p869 = inttoptr i64 %v868 to ptr
  %ld870 = load i64, ptr %p869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld870, ptr %slot110, align 8
  %v871 = load i64, ptr %slot110, align 8
  %cmp872 = icmp ne i64 %v871, 0
  %cv873 = zext i1 %cmp872 to i32
  store i32 %cv873, ptr %slot111, align 8
  %v874 = load i32, ptr %slot111, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcmoveheader99, label %bb_rcmovenext99
bb_rcmoveheader99:
  %v877 = load i64, ptr %slot110, align 8
  %op878 = sub i64 %v877, 16
  store i64 %op878, ptr %slot112, align 8
  %v879 = load i64, ptr %slot110, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %rgep881 = getelementptr i8, ptr %p880, i64 -16
  %ld882 = load i64, ptr %rgep881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld882, ptr %slot113, align 8
  %v883 = load i64, ptr %slot113, align 8
  %op884 = and i64 %v883, 5764607523034234881
  store i64 %op884, ptr %slot114, align 8
  %v885 = load i64, ptr %slot114, align 8
  %cmp886 = icmp ne i64 %v885, 0
  %cv887 = zext i1 %cmp886 to i32
  store i32 %cv887, ptr %slot115, align 8
  %v888 = load i32, ptr %slot115, align 8
  %cv889 = zext i32 %v888 to i64
  %cond890 = icmp ne i64 %cv889, 0
  br i1 %cond890, label %bb_rcmoveslow91, label %bb_rcmovenext99
bb_rcmovenext99:
  %v891 = load i64, ptr %slot97, align 8
  %v892 = load i64, ptr %slot102, align 8
  %p893 = inttoptr i64 %v891 to ptr
  %p894 = inttoptr i64 %v892 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p894, ptr %p893, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot97, align 8
  %p896 = inttoptr i64 %v895 to ptr
  store i64 0, ptr %p896, align 8, !alias.scope !3, !noalias !4
  %v897 = load i64, ptr %slot97, align 8
  %op898 = add i64 %v897, 8
  store i64 %op898, ptr %slot116, align 8
  %v899 = load i64, ptr %slot116, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 0, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot97, align 8
  %op902 = add i64 %v901, 16
  store i64 %op902, ptr %slot117, align 8
  %v903 = load i64, ptr %slot117, align 8
  %p904 = inttoptr i64 %v903 to ptr
  store i64 0, ptr %p904, align 8, !alias.scope !3, !noalias !4
  %v905 = load i64, ptr %slot97, align 8
  %op906 = add i64 %v905, 24
  store i64 %op906, ptr %slot118, align 8
  %v907 = load i64, ptr %slot118, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i64 0, ptr %p908, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved91
bb_rcmoveslow91:
  %v909 = load i64, ptr %slot42, align 8
  %v910 = load i64, ptr %slot102, align 8
  %v911 = load i64, ptr %slot97, align 8
  %v912 = load i64, ptr %slot103, align 8
  %cv913 = trunc i64 %v912 to i32
  %call914 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v909, i64 %v910, i64 %v911, i32 %cv913) nomerge, !dbg !118
  store i32 %call914, ptr %slot119, align 8
  %v915 = load i32, ptr %slot119, align 8
  %cv916 = zext i32 %v915 to i64
  %cond917 = icmp ne i64 %cv916, 0
  br i1 %cond917, label %bb_rcsuccess109, label %bb_rcfailure109
bb_rcfailure109:
  %v918 = load i64, ptr %slot42, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %call920 = call i32 @myl_rc_take_failure(ptr %p919) nomerge, !dbg !118
  store i32 %call920, ptr %slot120, align 8
  %v921 = load i64, ptr %slot1, align 8
  %p922 = inttoptr i64 %v921 to ptr
  %v923 = load i32, ptr %slot120, align 8
  %call924 = call i32 @myl_qbe_rc_status(ptr %p922, i32 %v923) nomerge, !dbg !118
  store i32 %call924, ptr %slot121, align 8
  br label %bb_failure
bb_rcsuccess109:
  br label %bb_rcmoved91
bb_rcmoved91:
  %v925 = load i64, ptr %slot8, align 8
  %p926 = inttoptr i64 %v925 to ptr
  store i32 0, ptr %p926, align 4, !alias.scope !3, !noalias !4
  %v927 = load i64, ptr %slot15, align 8
  %p928 = inttoptr i64 %v927 to ptr
  store i32 2, ptr %p928, align 4, !alias.scope !3, !noalias !4
  %v929 = load i64, ptr %slot14, align 8
  %p930 = inttoptr i64 %v929 to ptr
  store i32 1, ptr %p930, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared82
bb_rccopy82:
  %v931 = load i64, ptr %slot21, align 8
  store i64 %v931, ptr %slot122, align 8
  %v932 = load i64, ptr %slot43, align 8
  store i64 %v932, ptr %slot123, align 8
  %v933 = load i64, ptr %slot42, align 8
  %v934 = load i64, ptr %slot122, align 8
  %v935 = load i64, ptr %slot97, align 8
  %v936 = load i64, ptr %slot123, align 8
  %cv937 = trunc i64 %v936 to i32
  %call938 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v933, i64 %v934, i64 %v935, i32 %cv937) nomerge, !dbg !118
  store i32 %call938, ptr %slot124, align 8
  %v939 = load i32, ptr %slot124, align 8
  %cv940 = zext i32 %v939 to i64
  %cond941 = icmp ne i64 %cv940, 0
  br i1 %cond941, label %bb_rcsuccess118, label %bb_rcfailure118
bb_rcfailure118:
  %v942 = load i64, ptr %slot42, align 8
  %p943 = inttoptr i64 %v942 to ptr
  %call944 = call i32 @myl_rc_take_failure(ptr %p943) nomerge, !dbg !118
  store i32 %call944, ptr %slot125, align 8
  %v945 = load i64, ptr %slot1, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %v947 = load i32, ptr %slot125, align 8
  %call948 = call i32 @myl_qbe_rc_status(ptr %p946, i32 %v947) nomerge, !dbg !118
  store i32 %call948, ptr %slot126, align 8
  br label %bb_failure
bb_rcsuccess118:
  %v949 = load i64, ptr %slot15, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i32 2, ptr %p950, align 4, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot14, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i32 1, ptr %p952, align 4, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot8, align 8
  %p954 = inttoptr i64 %v953 to ptr
  %ld955 = load i32, ptr %p954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld955, ptr %slot127, align 8
  %v956 = load i32, ptr %slot127, align 8
  %cv957 = zext i32 %v956 to i64
  %cond958 = icmp ne i64 %cv957, 0
  br i1 %cond958, label %bb_rcslotdrop125, label %bb_rcslotdone125
bb_rcslotdrop125:
  %v959 = load i64, ptr %slot8, align 8
  %p960 = inttoptr i64 %v959 to ptr
  store i32 0, ptr %p960, align 4, !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot16, align 8
  store i64 %v961, ptr %slot128, align 8
  %v962 = load i64, ptr %slot9, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i32, ptr %p963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld964, ptr %slot129, align 8
  %v965 = load i32, ptr %slot129, align 8
  %op966 = and i32 %v965, 28
  store i32 %op966, ptr %slot130, align 8
  %v967 = load i32, ptr %slot130, align 8
  %cv968 = zext i32 %v967 to i64
  %cond969 = icmp ne i64 %cv968, 0
  br i1 %cond969, label %bb_rcslotrole125, label %bb_rcslotowner125
bb_rcslotrole125:
  %v970 = load i64, ptr %slot42, align 8
  store i64 %v970, ptr %slot131, align 8
  %v971 = load i64, ptr %slot131, align 8
  %v972 = load i64, ptr %slot128, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v971, i64 %v972) nomerge, !dbg !118
  br label %bb_rcslotdone125
bb_rcslotowner125:
  %v973 = load i64, ptr %slot128, align 8
  %p975 = inttoptr i64 %v973 to ptr
  %gep976 = getelementptr i8, ptr %p975, i64 0
  %op974 = ptrtoint ptr %gep976 to i64
  store i64 %op974, ptr %slot132, align 8
  %v977 = load i64, ptr %slot42, align 8
  store i64 %v977, ptr %slot133, align 8
  %v978 = load i64, ptr %slot132, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %ld980 = load i64, ptr %p979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld980, ptr %slot134, align 8
  %v981 = load i64, ptr %slot134, align 8
  %cmp982 = icmp ne i64 %v981, 0
  %cv983 = zext i1 %cmp982 to i32
  store i32 %cv983, ptr %slot135, align 8
  %v984 = load i32, ptr %slot135, align 8
  %cv985 = zext i32 %v984 to i64
  %cond986 = icmp ne i64 %cv985, 0
  br i1 %cond986, label %bb_rcgnn143, label %bb_rcgdone143
bb_rcgnn143:
  %v987 = load i64, ptr %slot134, align 8
  %op988 = sub i64 %v987, 16
  store i64 %op988, ptr %slot136, align 8
  %v989 = load i64, ptr %slot134, align 8
  %p990 = inttoptr i64 %v989 to ptr
  %rgep991 = getelementptr i8, ptr %p990, i64 -16
  %ld992 = load i64, ptr %rgep991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld992, ptr %slot137, align 8
  %v993 = load i64, ptr %slot137, align 8
  %op994 = and i64 %v993, 4611686018427387906
  store i64 %op994, ptr %slot138, align 8
  %v995 = load i64, ptr %slot138, align 8
  %cmp996 = icmp ne i64 %v995, 0
  %cv997 = zext i1 %cmp996 to i32
  store i32 %cv997, ptr %slot139, align 8
  %v998 = load i32, ptr %slot139, align 8
  %cv999 = zext i32 %v998 to i64
  %cond1000 = icmp ne i64 %cv999, 0
  br i1 %cond1000, label %bb_rcgclear143, label %bb_rcgcounted143
bb_rcgcounted143:
  %v1001 = load i64, ptr %slot134, align 8
  %op1002 = sub i64 %v1001, 32
  store i64 %op1002, ptr %slot140, align 8
  %v1003 = load i64, ptr %slot134, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %rgep1005 = getelementptr i8, ptr %p1004, i64 -32
  %ld1006 = load i64, ptr %rgep1005, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1006, ptr %slot141, align 8
  %v1007 = load i64, ptr %slot141, align 8
  %op1008 = sub i64 %v1007, 1
  store i64 %op1008, ptr %slot142, align 8
  %v1009 = load i64, ptr %slot142, align 8
  %cmp1010 = icmp eq i64 %v1009, 0
  %cv1011 = zext i1 %cmp1010 to i32
  store i32 %cv1011, ptr %slot143, align 8
  %v1012 = load i32, ptr %slot143, align 8
  %cv1013 = zext i32 %v1012 to i64
  %cond1014 = icmp ne i64 %cv1013, 0
  br i1 %cond1014, label %bb_rcglast143, label %bb_rcgdec143
bb_rcglast143:
  %v1015 = load i64, ptr %slot134, align 8
  %op1016 = sub i64 %v1015, 24
  store i64 %op1016, ptr %slot144, align 8
  %v1017 = load i64, ptr %slot134, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %rgep1019 = getelementptr i8, ptr %p1018, i64 -24
  %ld1020 = load i64, ptr %rgep1019, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1020, ptr %slot145, align 8
  %v1021 = load i64, ptr %slot145, align 8
  %cmp1022 = icmp ne i64 %v1021, 0
  %cv1023 = zext i1 %cmp1022 to i32
  store i32 %cv1023, ptr %slot146, align 8
  %v1024 = load i32, ptr %slot146, align 8
  %cv1025 = zext i32 %v1024 to i64
  %cond1026 = icmp ne i64 %cv1025, 0
  br i1 %cond1026, label %bb_rcgdec143, label %bb_rcgslow143
bb_rcgslow143:
  %v1027 = load i64, ptr %slot133, align 8
  %v1028 = load i64, ptr %slot132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1027, i64 %v1028) nomerge, !dbg !118
  br label %bb_rcgdone143
bb_rcgdec143:
  %v1029 = load i64, ptr %slot142, align 8
  %v1030 = load i64, ptr %slot134, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  %rgep1032 = getelementptr i8, ptr %p1031, i64 -32
  store i64 %v1029, ptr %rgep1032, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear143
bb_rcgclear143:
  %v1033 = load i64, ptr %slot132, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  store i64 0, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone143
bb_rcgdone143:
  %v1035 = load i64, ptr %slot128, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  store i64 0, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  %v1037 = load i64, ptr %slot128, align 8
  %p1039 = inttoptr i64 %v1037 to ptr
  %gep1040 = getelementptr i8, ptr %p1039, i64 8
  %op1038 = ptrtoint ptr %gep1040 to i64
  store i64 %op1038, ptr %slot147, align 8
  %v1041 = load i64, ptr %slot147, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  store i64 0, ptr %p1042, align 8, !alias.scope !3, !noalias !4
  %v1043 = load i64, ptr %slot128, align 8
  %p1045 = inttoptr i64 %v1043 to ptr
  %gep1046 = getelementptr i8, ptr %p1045, i64 16
  %op1044 = ptrtoint ptr %gep1046 to i64
  store i64 %op1044, ptr %slot148, align 8
  %v1047 = load i64, ptr %slot148, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i64 0, ptr %p1048, align 8, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot128, align 8
  %p1051 = inttoptr i64 %v1049 to ptr
  %gep1052 = getelementptr i8, ptr %p1051, i64 24
  %op1050 = ptrtoint ptr %gep1052 to i64
  store i64 %op1050, ptr %slot149, align 8
  %v1053 = load i64, ptr %slot149, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 0, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone125
bb_rcslotdone125:
  br label %bb_rcprepared82
bb_rcprepared82:
  %v1055 = load i64, ptr %slot4, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i32, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1057, ptr %slot150, align 8
  %v1058 = load i32, ptr %slot150, align 8
  %cv1059 = zext i32 %v1058 to i64
  %cond1060 = icmp ne i64 %cv1059, 0
  br i1 %cond1060, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v1061 = load i64, ptr %slot4, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i32 0, ptr %p1062, align 4, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot26, align 8
  store i64 %v1063, ptr %slot151, align 8
  %v1064 = load i64, ptr %slot5, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i32, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1066, ptr %slot152, align 8
  %v1067 = load i32, ptr %slot152, align 8
  %op1068 = and i32 %v1067, 28
  store i32 %op1068, ptr %slot153, align 8
  %v1069 = load i32, ptr %slot153, align 8
  %cv1070 = zext i32 %v1069 to i64
  %cond1071 = icmp ne i64 %cv1070, 0
  br i1 %cond1071, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v1072 = load i64, ptr %slot42, align 8
  store i64 %v1072, ptr %slot154, align 8
  %v1073 = load i64, ptr %slot154, align 8
  %v1074 = load i64, ptr %slot151, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1073, i64 %v1074) nomerge, !dbg !118
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v1075 = load i64, ptr %slot151, align 8
  %p1077 = inttoptr i64 %v1075 to ptr
  %gep1078 = getelementptr i8, ptr %p1077, i64 0
  %op1076 = ptrtoint ptr %gep1078 to i64
  store i64 %op1076, ptr %slot155, align 8
  %v1079 = load i64, ptr %slot42, align 8
  store i64 %v1079, ptr %slot156, align 8
  %v1080 = load i64, ptr %slot155, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  %ld1082 = load i64, ptr %p1081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1082, ptr %slot157, align 8
  %v1083 = load i64, ptr %slot157, align 8
  %cmp1084 = icmp ne i64 %v1083, 0
  %cv1085 = zext i1 %cmp1084 to i32
  store i32 %cv1085, ptr %slot158, align 8
  %v1086 = load i32, ptr %slot158, align 8
  %cv1087 = zext i32 %v1086 to i64
  %cond1088 = icmp ne i64 %cv1087, 0
  br i1 %cond1088, label %bb_rcgnn171, label %bb_rcgdone171
bb_rcgnn171:
  %v1089 = load i64, ptr %slot157, align 8
  %op1090 = sub i64 %v1089, 16
  store i64 %op1090, ptr %slot159, align 8
  %v1091 = load i64, ptr %slot157, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %rgep1093 = getelementptr i8, ptr %p1092, i64 -16
  %ld1094 = load i64, ptr %rgep1093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1094, ptr %slot160, align 8
  %v1095 = load i64, ptr %slot160, align 8
  %op1096 = and i64 %v1095, 4611686018427387906
  store i64 %op1096, ptr %slot161, align 8
  %v1097 = load i64, ptr %slot161, align 8
  %cmp1098 = icmp ne i64 %v1097, 0
  %cv1099 = zext i1 %cmp1098 to i32
  store i32 %cv1099, ptr %slot162, align 8
  %v1100 = load i32, ptr %slot162, align 8
  %cv1101 = zext i32 %v1100 to i64
  %cond1102 = icmp ne i64 %cv1101, 0
  br i1 %cond1102, label %bb_rcgclear171, label %bb_rcgcounted171
bb_rcgcounted171:
  %v1103 = load i64, ptr %slot157, align 8
  %op1104 = sub i64 %v1103, 32
  store i64 %op1104, ptr %slot163, align 8
  %v1105 = load i64, ptr %slot157, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  %rgep1107 = getelementptr i8, ptr %p1106, i64 -32
  %ld1108 = load i64, ptr %rgep1107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1108, ptr %slot164, align 8
  %v1109 = load i64, ptr %slot164, align 8
  %op1110 = sub i64 %v1109, 1
  store i64 %op1110, ptr %slot165, align 8
  %v1111 = load i64, ptr %slot165, align 8
  %cmp1112 = icmp eq i64 %v1111, 0
  %cv1113 = zext i1 %cmp1112 to i32
  store i32 %cv1113, ptr %slot166, align 8
  %v1114 = load i32, ptr %slot166, align 8
  %cv1115 = zext i32 %v1114 to i64
  %cond1116 = icmp ne i64 %cv1115, 0
  br i1 %cond1116, label %bb_rcglast171, label %bb_rcgdec171
bb_rcglast171:
  %v1117 = load i64, ptr %slot157, align 8
  %op1118 = sub i64 %v1117, 24
  store i64 %op1118, ptr %slot167, align 8
  %v1119 = load i64, ptr %slot157, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %rgep1121 = getelementptr i8, ptr %p1120, i64 -24
  %ld1122 = load i64, ptr %rgep1121, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1122, ptr %slot168, align 8
  %v1123 = load i64, ptr %slot168, align 8
  %cmp1124 = icmp ne i64 %v1123, 0
  %cv1125 = zext i1 %cmp1124 to i32
  store i32 %cv1125, ptr %slot169, align 8
  %v1126 = load i32, ptr %slot169, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcgdec171, label %bb_rcgslow171
bb_rcgslow171:
  %v1129 = load i64, ptr %slot156, align 8
  %v1130 = load i64, ptr %slot155, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1129, i64 %v1130) nomerge, !dbg !118
  br label %bb_rcgdone171
bb_rcgdec171:
  %v1131 = load i64, ptr %slot165, align 8
  %v1132 = load i64, ptr %slot157, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  %rgep1134 = getelementptr i8, ptr %p1133, i64 -32
  store i64 %v1131, ptr %rgep1134, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear171
bb_rcgclear171:
  %v1135 = load i64, ptr %slot155, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  store i64 0, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone171
bb_rcgdone171:
  %v1137 = load i64, ptr %slot151, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i64 0, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot151, align 8
  %p1141 = inttoptr i64 %v1139 to ptr
  %gep1142 = getelementptr i8, ptr %p1141, i64 8
  %op1140 = ptrtoint ptr %gep1142 to i64
  store i64 %op1140, ptr %slot170, align 8
  %v1143 = load i64, ptr %slot170, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 0, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot151, align 8
  %p1147 = inttoptr i64 %v1145 to ptr
  %gep1148 = getelementptr i8, ptr %p1147, i64 16
  %op1146 = ptrtoint ptr %gep1148 to i64
  store i64 %op1146, ptr %slot171, align 8
  %v1149 = load i64, ptr %slot171, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  store i64 0, ptr %p1150, align 8, !alias.scope !3, !noalias !4
  %v1151 = load i64, ptr %slot151, align 8
  %p1153 = inttoptr i64 %v1151 to ptr
  %gep1154 = getelementptr i8, ptr %p1153, i64 24
  %op1152 = ptrtoint ptr %gep1154 to i64
  store i64 %op1152, ptr %slot172, align 8
  %v1155 = load i64, ptr %slot172, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  store i64 0, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone153
bb_rcslotdone153:
  %v1157 = load i64, ptr %slot26, align 8
  store i64 %v1157, ptr %slot173, align 8
  %v1158 = load i64, ptr %slot21, align 8
  store i64 %v1158, ptr %slot174, align 8
  %v1159 = load i64, ptr %slot174, align 8
  %v1160 = load i64, ptr %slot173, align 8
  %p1161 = inttoptr i64 %v1159 to ptr
  %p1162 = inttoptr i64 %v1160 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1162, ptr %p1161, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot14, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i32 0, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot5, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i32 2, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot15, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  %ld1169 = load i32, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1169, ptr %slot175, align 8
  %v1170 = load i32, ptr %slot175, align 8
  %v1171 = load i64, ptr %slot5, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  store i32 %v1170, ptr %p1172, align 4, !alias.scope !3, !noalias !4
  %v1173 = load i64, ptr %slot4, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i32 1, ptr %p1174, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_i4:
  %v1175 = load i64, ptr %slot26, align 8
  %v1176 = load i64, ptr %slot29, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i64 %v1175, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot29, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i64, ptr %p1179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1180, ptr %slot176, align 8
  %v1181 = load i64, ptr %slot1, align 8
  %v1182 = load i64, ptr %slot176, align 8
  call void @myl_f_e4b0bf9563972641903c91a76184ac78f1f83b05bb4beab9462ad6bdca4a1ea9(ptr sret([40 x i8]) align 8 %callresult178, i64 %v1181, i64 %v1182) nomerge, !dbg !120
  %addr1183 = ptrtoint ptr %callresult178 to i64
  store i64 %addr1183, ptr %slot177, align 8
  %v1184 = load i64, ptr %slot177, align 8
  %v1185 = load i64, ptr %slot29, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i64 %v1184, ptr %p1186, align 8, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot29, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i64, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1189, ptr %slot179, align 8
  %v1190 = load i64, ptr %slot21, align 8
  store i64 %v1190, ptr %slot180, align 8
  %v1191 = load i64, ptr %slot179, align 8
  %v1192 = load i64, ptr %slot180, align 8
  %p1193 = inttoptr i64 %v1191 to ptr
  %p1194 = inttoptr i64 %v1192 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1194, ptr %p1193, i64 40, i1 false)
  %v1195 = load i64, ptr %slot15, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i32 2, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot14, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i32 1, ptr %p1198, align 4, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot8, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %ld1201 = load i32, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1201, ptr %slot181, align 8
  %v1202 = load i32, ptr %slot181, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcslotdrop193, label %bb_rcslotdone193
bb_rcslotdrop193:
  %v1205 = load i64, ptr %slot8, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i32 0, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot16, align 8
  store i64 %v1207, ptr %slot182, align 8
  %v1208 = load i64, ptr %slot9, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %ld1210 = load i32, ptr %p1209, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1210, ptr %slot183, align 8
  %v1211 = load i32, ptr %slot183, align 8
  %op1212 = and i32 %v1211, 28
  store i32 %op1212, ptr %slot184, align 8
  %v1213 = load i32, ptr %slot184, align 8
  %cv1214 = zext i32 %v1213 to i64
  %cond1215 = icmp ne i64 %cv1214, 0
  br i1 %cond1215, label %bb_rcslotrole193, label %bb_rcslotowner193
bb_rcslotrole193:
  %v1216 = load i64, ptr %slot42, align 8
  store i64 %v1216, ptr %slot185, align 8
  %v1217 = load i64, ptr %slot185, align 8
  %v1218 = load i64, ptr %slot182, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1217, i64 %v1218) nomerge, !dbg !120
  br label %bb_rcslotdone193
bb_rcslotowner193:
  %v1219 = load i64, ptr %slot42, align 8
  store i64 %v1219, ptr %slot186, align 8
  %v1220 = load i64, ptr %slot186, align 8
  %v1221 = load i64, ptr %slot182, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1220, i64 %v1221) nomerge, !dbg !120
  br label %bb_rcslotdone193
bb_rcslotdone193:
  %v1222 = load i64, ptr %slot16, align 8
  store i64 %v1222, ptr %slot187, align 8
  %v1223 = load i64, ptr %slot21, align 8
  store i64 %v1223, ptr %slot188, align 8
  %v1224 = load i64, ptr %slot188, align 8
  %v1225 = load i64, ptr %slot187, align 8
  %p1226 = inttoptr i64 %v1224 to ptr
  %p1227 = inttoptr i64 %v1225 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1227, ptr %p1226, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot9, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  store i32 2, ptr %p1229, align 4, !alias.scope !3, !noalias !4
  %v1230 = load i64, ptr %slot15, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %ld1232 = load i32, ptr %p1231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1232, ptr %slot189, align 8
  %v1233 = load i32, ptr %slot189, align 8
  %v1234 = load i64, ptr %slot9, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 %v1233, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot14, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i32 0, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot8, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i32 1, ptr %p1239, align 4, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot187, align 8
  %v1241 = load i64, ptr %slot29, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  store i64 %v1240, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  %v1243 = load i64, ptr %slot29, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %ld1245 = load i64, ptr %p1244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1245, ptr %slot190, align 8
  %v1246 = load i64, ptr %slot21, align 8
  store i64 %v1246, ptr %slot191, align 8
  %v1247 = load i64, ptr %slot43, align 8
  store i64 %v1247, ptr %slot192, align 8
  %v1248 = load i64, ptr %slot42, align 8
  %v1249 = load i64, ptr %slot191, align 8
  %v1250 = load i64, ptr %slot190, align 8
  %v1251 = load i64, ptr %slot192, align 8
  %cv1252 = trunc i64 %v1251 to i32
  %call1253 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1248, i64 %v1249, i64 %v1250, i32 %cv1252) nomerge, !dbg !122
  store i32 %call1253, ptr %slot193, align 8
  %v1254 = load i32, ptr %slot193, align 8
  %cv1255 = zext i32 %v1254 to i64
  %cond1256 = icmp ne i64 %cv1255, 0
  br i1 %cond1256, label %bb_rcsuccess212, label %bb_rcfailure212
bb_rcfailure212:
  %v1257 = load i64, ptr %slot42, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %call1259 = call i32 @myl_rc_take_failure(ptr %p1258) nomerge, !dbg !122
  store i32 %call1259, ptr %slot194, align 8
  %v1260 = load i64, ptr %slot1, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %v1262 = load i32, ptr %slot194, align 8
  %call1263 = call i32 @myl_qbe_rc_status(ptr %p1261, i32 %v1262) nomerge, !dbg !122
  store i32 %call1263, ptr %slot195, align 8
  br label %bb_failure
bb_rcsuccess212:
  %v1264 = load i64, ptr %slot8, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i32 0, ptr %p1265, align 4, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot15, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  store i32 2, ptr %p1267, align 4, !alias.scope !3, !noalias !4
  %v1268 = load i64, ptr %slot14, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i32 1, ptr %p1269, align 4, !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot6, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i32, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1272, ptr %slot196, align 8
  %v1273 = load i32, ptr %slot196, align 8
  %cv1274 = zext i32 %v1273 to i64
  %cond1275 = icmp ne i64 %cv1274, 0
  br i1 %cond1275, label %bb_rcslotdrop221, label %bb_rcslotdone221
bb_rcslotdrop221:
  %v1276 = load i64, ptr %slot6, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i32 0, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot27, align 8
  store i64 %v1278, ptr %slot197, align 8
  %v1279 = load i64, ptr %slot7, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %ld1281 = load i32, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1281, ptr %slot198, align 8
  %v1282 = load i32, ptr %slot198, align 8
  %op1283 = and i32 %v1282, 28
  store i32 %op1283, ptr %slot199, align 8
  %v1284 = load i32, ptr %slot199, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rcslotrole221, label %bb_rcslotowner221
bb_rcslotrole221:
  %v1287 = load i64, ptr %slot42, align 8
  store i64 %v1287, ptr %slot200, align 8
  %v1288 = load i64, ptr %slot200, align 8
  %v1289 = load i64, ptr %slot197, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1288, i64 %v1289) nomerge, !dbg !122
  br label %bb_rcslotdone221
bb_rcslotowner221:
  %v1290 = load i64, ptr %slot42, align 8
  store i64 %v1290, ptr %slot201, align 8
  %v1291 = load i64, ptr %slot201, align 8
  %v1292 = load i64, ptr %slot197, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1291, i64 %v1292) nomerge, !dbg !122
  br label %bb_rcslotdone221
bb_rcslotdone221:
  %v1293 = load i64, ptr %slot27, align 8
  store i64 %v1293, ptr %slot202, align 8
  %v1294 = load i64, ptr %slot21, align 8
  store i64 %v1294, ptr %slot203, align 8
  %v1295 = load i64, ptr %slot203, align 8
  %v1296 = load i64, ptr %slot202, align 8
  %p1297 = inttoptr i64 %v1295 to ptr
  %p1298 = inttoptr i64 %v1296 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1298, ptr %p1297, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1299 = load i64, ptr %slot14, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  store i32 0, ptr %p1300, align 4, !alias.scope !3, !noalias !4
  %v1301 = load i64, ptr %slot7, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  store i32 2, ptr %p1302, align 4, !alias.scope !3, !noalias !4
  %v1303 = load i64, ptr %slot15, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i32, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1305, ptr %slot204, align 8
  %v1306 = load i32, ptr %slot204, align 8
  %v1307 = load i64, ptr %slot7, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 %v1306, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot6, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i32 1, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot27, align 8
  %v1312 = load i64, ptr %slot29, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i64 %v1311, ptr %p1313, align 8, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot29, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i64, ptr %p1315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1316, ptr %slot205, align 8
  %v1317 = load i64, ptr %slot205, align 8
  %op1318 = add i64 %v1317, 0
  store i64 %op1318, ptr %slot206, align 8
  %v1319 = load i64, ptr %slot206, align 8
  %v1320 = load i64, ptr %slot29, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i64 %v1319, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot29, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i64, ptr %p1323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1324, ptr %slot207, align 8
  %v1325 = load i64, ptr %slot33, align 8
  store i64 %v1325, ptr %slot208, align 8
  %v1326 = load i64, ptr %slot207, align 8
  %v1327 = load i64, ptr %slot208, align 8
  %p1328 = inttoptr i64 %v1326 to ptr
  %p1329 = inttoptr i64 %v1327 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1329, ptr %p1328, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot208, align 8
  %v1331 = load i64, ptr %slot29, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  store i64 %v1330, ptr %p1332, align 8, !alias.scope !3, !noalias !4
  %v1333 = load i64, ptr %slot8, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %ld1335 = load i32, ptr %p1334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1335, ptr %slot209, align 8
  %v1336 = load i32, ptr %slot209, align 8
  %cv1337 = zext i32 %v1336 to i64
  %cond1338 = icmp ne i64 %cv1337, 0
  br i1 %cond1338, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  %v1339 = load i64, ptr %slot8, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i32 0, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot16, align 8
  store i64 %v1341, ptr %slot210, align 8
  %v1342 = load i64, ptr %slot9, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i32, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1344, ptr %slot211, align 8
  %v1345 = load i32, ptr %slot211, align 8
  %op1346 = and i32 %v1345, 28
  store i32 %op1346, ptr %slot212, align 8
  %v1347 = load i32, ptr %slot212, align 8
  %cv1348 = zext i32 %v1347 to i64
  %cond1349 = icmp ne i64 %cv1348, 0
  br i1 %cond1349, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v1350 = load i64, ptr %slot42, align 8
  store i64 %v1350, ptr %slot213, align 8
  %v1351 = load i64, ptr %slot213, align 8
  %v1352 = load i64, ptr %slot210, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1351, i64 %v1352) nomerge, !dbg !124
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v1353 = load i64, ptr %slot42, align 8
  store i64 %v1353, ptr %slot214, align 8
  %v1354 = load i64, ptr %slot214, align 8
  %v1355 = load i64, ptr %slot210, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1354, i64 %v1355) nomerge, !dbg !124
  br label %bb_rcslotdone241
bb_rcslotdone241:
  %v1356 = load i64, ptr %slot34, align 8
  store i64 %v1356, ptr %slot215, align 8
  %v1357 = load i64, ptr %slot215, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i32 0, ptr %p1358, align 4, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot215, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  store i32 38, ptr %p1360, align 4, !alias.scope !3, !noalias !4
  %v1361 = load i64, ptr %slot215, align 8
  %v1362 = load i64, ptr %slot30, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i64 %v1361, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  %v1364 = load i64, ptr %slot30, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %ld1366 = load i64, ptr %p1365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1366, ptr %slot216, align 8
  %v1367 = load i64, ptr %slot29, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %ld1369 = load i64, ptr %p1368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1369, ptr %slot217, align 8
  %v1370 = load i64, ptr %slot217, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %ld1372 = load i32, ptr %p1371, align 4, !alias.scope !3, !noalias !4
  %ext1373 = zext i32 %ld1372 to i64
  store i64 %ext1373, ptr %slot218, align 8
  %v1374 = load i64, ptr %slot216, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  %ld1376 = load i32, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  %ext1377 = zext i32 %ld1376 to i64
  store i64 %ext1377, ptr %slot219, align 8
  %v1378 = load i64, ptr %slot218, align 8
  %v1379 = load i64, ptr %slot219, align 8
  %cmp1380 = icmp eq i64 %v1378, %v1379
  %cv1381 = zext i1 %cmp1380 to i64
  store i64 %cv1381, ptr %slot220, align 8
  %v1382 = load i64, ptr %slot220, align 8
  %v1383 = load i64, ptr %slot29, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i64 %v1382, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot29, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  %ld1387 = load i64, ptr %p1386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1387, ptr %slot221, align 8
  %v1388 = load i64, ptr %slot221, align 8
  %cond1389 = icmp ne i64 %v1388, 0
  br i1 %cond1389, label %bb_next255, label %bb_i21
bb_next255:
  %v1390 = load i64, ptr %slot25, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  %ld1392 = load i64, ptr %p1391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1392, ptr %slot222, align 8
  %v1393 = load i64, ptr %slot222, align 8
  %v1394 = load i64, ptr %slot29, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i64 %v1393, ptr %p1395, align 8, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot27, align 8
  %v1397 = load i64, ptr %slot30, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i64 %v1396, ptr %p1398, align 8, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot30, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i64, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1401, ptr %slot223, align 8
  %v1402 = load i64, ptr %slot223, align 8
  %op1403 = add i64 %v1402, 24
  store i64 %op1403, ptr %slot224, align 8
  %v1404 = load i64, ptr %slot224, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i64, ptr %p1405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1406, ptr %slot225, align 8
  %v1407 = load i64, ptr %slot225, align 8
  %v1408 = load i64, ptr %slot30, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i64 %v1407, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  %p1410 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld1411 = load i64, ptr %p1410, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1411, ptr %slot226, align 8
  %v1412 = load i64, ptr %slot226, align 8
  %v1413 = load i64, ptr %slot31, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  store i64 %v1412, ptr %p1414, align 8, !alias.scope !3, !noalias !4
  %v1415 = load i64, ptr %slot31, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %ld1417 = load i64, ptr %p1416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1417, ptr %slot227, align 8
  %v1418 = load i64, ptr %slot227, align 8
  %v1419 = load i64, ptr %slot19, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i64 %v1418, ptr %p1420, align 8, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot19, align 8
  store i64 %v1421, ptr %slot228, align 8
  %v1422 = load i64, ptr %slot21, align 8
  store i64 %v1422, ptr %slot229, align 8
  %v1423 = load i64, ptr %slot228, align 8
  %v1424 = load i64, ptr %slot229, align 8
  %p1425 = inttoptr i64 %v1423 to ptr
  %p1426 = inttoptr i64 %v1424 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1426, ptr %p1425, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot15, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i32 2, ptr %p1428, align 4, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot14, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  store i32 1, ptr %p1430, align 4, !alias.scope !3, !noalias !4
  %v1431 = load i64, ptr %slot17, align 8
  store i64 %v1431, ptr %slot230, align 8
  %v1432 = load i64, ptr %slot21, align 8
  store i64 %v1432, ptr %slot231, align 8
  %v1433 = load i64, ptr %slot231, align 8
  %v1434 = load i64, ptr %slot230, align 8
  %p1435 = inttoptr i64 %v1433 to ptr
  %p1436 = inttoptr i64 %v1434 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1436, ptr %p1435, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1437 = load i64, ptr %slot11, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  store i32 2, ptr %p1438, align 4, !alias.scope !3, !noalias !4
  %v1439 = load i64, ptr %slot15, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %ld1441 = load i32, ptr %p1440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1441, ptr %slot232, align 8
  %v1442 = load i32, ptr %slot232, align 8
  %v1443 = load i64, ptr %slot11, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  store i32 %v1442, ptr %p1444, align 4, !alias.scope !3, !noalias !4
  %v1445 = load i64, ptr %slot14, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  store i32 0, ptr %p1446, align 4, !alias.scope !3, !noalias !4
  %v1447 = load i64, ptr %slot10, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  store i32 1, ptr %p1448, align 4, !alias.scope !3, !noalias !4
  %v1449 = load i64, ptr %slot230, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i64, ptr %p1450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1451, ptr %slot233, align 8
  %v1452 = load i64, ptr %slot233, align 8
  %v1453 = load i64, ptr %slot31, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  store i64 %v1452, ptr %p1454, align 8, !alias.scope !3, !noalias !4
  %v1455 = load i64, ptr %slot27, align 8
  %v1456 = load i64, ptr %slot32, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  store i64 %v1455, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  %v1458 = load i64, ptr %slot32, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %ld1460 = load i64, ptr %p1459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1460, ptr %slot234, align 8
  %v1461 = load i64, ptr %slot234, align 8
  %op1462 = add i64 %v1461, 32
  store i64 %op1462, ptr %slot235, align 8
  %v1463 = load i64, ptr %slot235, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  %ld1465 = load i64, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1465, ptr %slot236, align 8
  %v1466 = load i64, ptr %slot236, align 8
  %v1467 = load i64, ptr %slot32, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i64 %v1466, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot32, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1471, ptr %slot237, align 8
  %v1472 = load i64, ptr %slot237, align 8
  %v1473 = load i64, ptr %slot20, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i64 %v1472, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot20, align 8
  store i64 %v1475, ptr %slot238, align 8
  %v1476 = load i64, ptr %slot21, align 8
  store i64 %v1476, ptr %slot239, align 8
  %v1477 = load i64, ptr %slot238, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i64, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1479, ptr %slot240, align 8
  %v1480 = load i64, ptr %slot240, align 8
  %cmp1481 = icmp ne i64 %v1480, 0
  %cv1482 = zext i1 %cmp1481 to i32
  store i32 %cv1482, ptr %slot241, align 8
  %v1483 = load i32, ptr %slot241, align 8
  %cv1484 = zext i32 %v1483 to i64
  %cond1485 = icmp ne i64 %cv1484, 0
  br i1 %cond1485, label %bb_rcgnn291, label %bb_rcgstore291
bb_rcgnn291:
  %v1486 = load i64, ptr %slot240, align 8
  %op1487 = sub i64 %v1486, 16
  store i64 %op1487, ptr %slot242, align 8
  %v1488 = load i64, ptr %slot240, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %rgep1490 = getelementptr i8, ptr %p1489, i64 -16
  %ld1491 = load i64, ptr %rgep1490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1491, ptr %slot243, align 8
  %v1492 = load i64, ptr %slot243, align 8
  %op1493 = and i64 %v1492, 4611686018427387906
  store i64 %op1493, ptr %slot244, align 8
  %v1494 = load i64, ptr %slot244, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot245, align 8
  %v1497 = load i32, ptr %slot245, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcgstore291, label %bb_rcginc291
bb_rcginc291:
  %v1500 = load i64, ptr %slot240, align 8
  %op1501 = sub i64 %v1500, 24
  store i64 %op1501, ptr %slot246, align 8
  %v1502 = load i64, ptr %slot240, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %rgep1504 = getelementptr i8, ptr %p1503, i64 -24
  %ld1505 = load i64, ptr %rgep1504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1505, ptr %slot247, align 8
  %v1506 = load i64, ptr %slot247, align 8
  %op1507 = add i64 %v1506, 1
  store i64 %op1507, ptr %slot248, align 8
  %v1508 = load i64, ptr %slot248, align 8
  %cmp1509 = icmp eq i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot249, align 8
  %v1511 = load i32, ptr %slot249, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcglimit291, label %bb_rcgcapacity291
bb_rcglimit291:
  %v1514 = load i64, ptr %slot1, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %call1516 = call i32 @myl_qbe_rc_status(ptr %p1515, i32 2) nomerge, !dbg !126
  store i32 %call1516, ptr %slot250, align 8
  br label %bb_failure
bb_rcgcapacity291:
  %v1517 = load i64, ptr %slot248, align 8
  %v1518 = load i64, ptr %slot240, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %rgep1520 = getelementptr i8, ptr %p1519, i64 -24
  store i64 %v1517, ptr %rgep1520, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore291
bb_rcgstore291:
  %v1521 = load i64, ptr %slot240, align 8
  %v1522 = load i64, ptr %slot239, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i64 %v1521, ptr %p1523, align 8, !alias.scope !3, !noalias !4
  %v1524 = load i64, ptr %slot15, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i32 2, ptr %p1525, align 4, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot15, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  store i32 16, ptr %p1527, align 4, !alias.scope !3, !noalias !4
  %v1528 = load i64, ptr %slot14, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  store i32 1, ptr %p1529, align 4, !alias.scope !3, !noalias !4
  %v1530 = load i64, ptr %slot12, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  %ld1532 = load i32, ptr %p1531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1532, ptr %slot251, align 8
  %v1533 = load i32, ptr %slot251, align 8
  %cv1534 = zext i32 %v1533 to i64
  %cond1535 = icmp ne i64 %cv1534, 0
  br i1 %cond1535, label %bb_rcslotdrop307, label %bb_rcslotdone307
bb_rcslotdrop307:
  %v1536 = load i64, ptr %slot12, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i32 0, ptr %p1537, align 4, !alias.scope !3, !noalias !4
  %v1538 = load i64, ptr %slot18, align 8
  store i64 %v1538, ptr %slot252, align 8
  %v1539 = load i64, ptr %slot13, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %ld1541 = load i32, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1541, ptr %slot253, align 8
  %v1542 = load i32, ptr %slot253, align 8
  %op1543 = and i32 %v1542, 28
  store i32 %op1543, ptr %slot254, align 8
  %v1544 = load i32, ptr %slot254, align 8
  %cv1545 = zext i32 %v1544 to i64
  %cond1546 = icmp ne i64 %cv1545, 0
  br i1 %cond1546, label %bb_rcslotrole307, label %bb_rcslotowner307
bb_rcslotrole307:
  %v1547 = load i64, ptr %slot42, align 8
  store i64 %v1547, ptr %slot255, align 8
  %v1548 = load i64, ptr %slot255, align 8
  %v1549 = load i64, ptr %slot252, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1548, i64 %v1549) nomerge, !dbg !126
  br label %bb_rcslotdone307
bb_rcslotowner307:
  %v1550 = load i64, ptr %slot42, align 8
  store i64 %v1550, ptr %slot256, align 8
  %v1551 = load i64, ptr %slot256, align 8
  %v1552 = load i64, ptr %slot252, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1551, i64 %v1552) nomerge, !dbg !126
  br label %bb_rcslotdone307
bb_rcslotdone307:
  %v1553 = load i64, ptr %slot18, align 8
  store i64 %v1553, ptr %slot257, align 8
  %v1554 = load i64, ptr %slot21, align 8
  store i64 %v1554, ptr %slot258, align 8
  %v1555 = load i64, ptr %slot258, align 8
  %v1556 = load i64, ptr %slot257, align 8
  %p1557 = inttoptr i64 %v1555 to ptr
  %p1558 = inttoptr i64 %v1556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1558, ptr %p1557, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot13, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 2, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot15, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %ld1563 = load i32, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1563, ptr %slot259, align 8
  %v1564 = load i32, ptr %slot259, align 8
  %v1565 = load i64, ptr %slot13, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  store i32 %v1564, ptr %p1566, align 4, !alias.scope !3, !noalias !4
  %v1567 = load i64, ptr %slot14, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i32 0, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot12, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i32 1, ptr %p1570, align 4, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot257, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  %ld1573 = load i64, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1573, ptr %slot260, align 8
  %v1574 = load i64, ptr %slot260, align 8
  %v1575 = load i64, ptr %slot32, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  store i64 %v1574, ptr %p1576, align 8, !alias.scope !3, !noalias !4
  %v1577 = load i64, ptr %slot29, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %ld1579 = load i64, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1579, ptr %slot261, align 8
  %v1580 = load i64, ptr %slot30, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  %ld1582 = load i64, ptr %p1581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1582, ptr %slot262, align 8
  %v1583 = load i64, ptr %slot31, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %ld1585 = load i64, ptr %p1584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1585, ptr %slot263, align 8
  %v1586 = load i64, ptr %slot32, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i64, ptr %p1587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1588, ptr %slot264, align 8
  %v1589 = load i64, ptr %slot1, align 8
  %v1590 = load i64, ptr %slot261, align 8
  %v1591 = load i64, ptr %slot262, align 8
  %v1592 = load i64, ptr %slot263, align 8
  %v1593 = load i64, ptr %slot264, align 8
  %call1594 = call i64 @myl_f_1a58e33e63dbac4b89202d66010d9cb688e1b15f0c09dc7f3c9b36ac8ba482e5(i64 %v1589, i64 %v1590, i64 %v1591, i64 %v1592, i64 %v1593) nomerge, !dbg !128
  store i64 %call1594, ptr %slot265, align 8
  %v1595 = load i64, ptr %slot265, align 8
  %v1596 = load i64, ptr %slot29, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  store i64 %v1595, ptr %p1597, align 8, !alias.scope !3, !noalias !4
  %v1598 = load i64, ptr %slot8, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  %ld1600 = load i32, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1600, ptr %slot266, align 8
  %v1601 = load i32, ptr %slot266, align 8
  %cv1602 = zext i32 %v1601 to i64
  %cond1603 = icmp ne i64 %cv1602, 0
  br i1 %cond1603, label %bb_rcslotdrop330, label %bb_rcslotdone330
bb_rcslotdrop330:
  %v1604 = load i64, ptr %slot8, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i32 0, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot16, align 8
  store i64 %v1606, ptr %slot267, align 8
  %v1607 = load i64, ptr %slot9, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  %ld1609 = load i32, ptr %p1608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1609, ptr %slot268, align 8
  %v1610 = load i32, ptr %slot268, align 8
  %op1611 = and i32 %v1610, 28
  store i32 %op1611, ptr %slot269, align 8
  %v1612 = load i32, ptr %slot269, align 8
  %cv1613 = zext i32 %v1612 to i64
  %cond1614 = icmp ne i64 %cv1613, 0
  br i1 %cond1614, label %bb_rcslotrole330, label %bb_rcslotowner330
bb_rcslotrole330:
  %v1615 = load i64, ptr %slot42, align 8
  store i64 %v1615, ptr %slot270, align 8
  %v1616 = load i64, ptr %slot270, align 8
  %v1617 = load i64, ptr %slot267, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1616, i64 %v1617) nomerge, !dbg !128
  br label %bb_rcslotdone330
bb_rcslotowner330:
  %v1618 = load i64, ptr %slot42, align 8
  store i64 %v1618, ptr %slot271, align 8
  %v1619 = load i64, ptr %slot271, align 8
  %v1620 = load i64, ptr %slot267, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1619, i64 %v1620) nomerge, !dbg !128
  br label %bb_rcslotdone330
bb_rcslotdone330:
  %v1621 = load i64, ptr %slot10, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %ld1623 = load i32, ptr %p1622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1623, ptr %slot272, align 8
  %v1624 = load i32, ptr %slot272, align 8
  %cv1625 = zext i32 %v1624 to i64
  %cond1626 = icmp ne i64 %cv1625, 0
  br i1 %cond1626, label %bb_rcslotdrop339, label %bb_rcslotdone339
bb_rcslotdrop339:
  %v1627 = load i64, ptr %slot10, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  store i32 0, ptr %p1628, align 4, !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot17, align 8
  store i64 %v1629, ptr %slot273, align 8
  %v1630 = load i64, ptr %slot11, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  %ld1632 = load i32, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1632, ptr %slot274, align 8
  %v1633 = load i32, ptr %slot274, align 8
  %op1634 = and i32 %v1633, 28
  store i32 %op1634, ptr %slot275, align 8
  %v1635 = load i32, ptr %slot275, align 8
  %cv1636 = zext i32 %v1635 to i64
  %cond1637 = icmp ne i64 %cv1636, 0
  br i1 %cond1637, label %bb_rcslotrole339, label %bb_rcslotowner339
bb_rcslotrole339:
  %v1638 = load i64, ptr %slot42, align 8
  store i64 %v1638, ptr %slot276, align 8
  %v1639 = load i64, ptr %slot273, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  %ld1641 = load i64, ptr %p1640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1641, ptr %slot277, align 8
  %v1642 = load i64, ptr %slot277, align 8
  %cmp1643 = icmp ne i64 %v1642, 0
  %cv1644 = zext i1 %cmp1643 to i32
  store i32 %cv1644, ptr %slot278, align 8
  %v1645 = load i32, ptr %slot278, align 8
  %cv1646 = zext i32 %v1645 to i64
  %cond1647 = icmp ne i64 %cv1646, 0
  br i1 %cond1647, label %bb_rcgnn355, label %bb_rcgdone355
bb_rcgnn355:
  %v1648 = load i64, ptr %slot277, align 8
  %op1649 = sub i64 %v1648, 16
  store i64 %op1649, ptr %slot279, align 8
  %v1650 = load i64, ptr %slot277, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  %rgep1652 = getelementptr i8, ptr %p1651, i64 -16
  %ld1653 = load i64, ptr %rgep1652, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1653, ptr %slot280, align 8
  %v1654 = load i64, ptr %slot280, align 8
  %op1655 = and i64 %v1654, 4611686018427387906
  store i64 %op1655, ptr %slot281, align 8
  %v1656 = load i64, ptr %slot281, align 8
  %cmp1657 = icmp ne i64 %v1656, 0
  %cv1658 = zext i1 %cmp1657 to i32
  store i32 %cv1658, ptr %slot282, align 8
  %v1659 = load i32, ptr %slot282, align 8
  %cv1660 = zext i32 %v1659 to i64
  %cond1661 = icmp ne i64 %cv1660, 0
  br i1 %cond1661, label %bb_rcgclear355, label %bb_rcgcounted355
bb_rcgcounted355:
  %v1662 = load i64, ptr %slot277, align 8
  %op1663 = sub i64 %v1662, 24
  store i64 %op1663, ptr %slot283, align 8
  %v1664 = load i64, ptr %slot277, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  %rgep1666 = getelementptr i8, ptr %p1665, i64 -24
  %ld1667 = load i64, ptr %rgep1666, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1667, ptr %slot284, align 8
  %v1668 = load i64, ptr %slot284, align 8
  %op1669 = sub i64 %v1668, 1
  store i64 %op1669, ptr %slot285, align 8
  %v1670 = load i64, ptr %slot285, align 8
  %cmp1671 = icmp eq i64 %v1670, 0
  %cv1672 = zext i1 %cmp1671 to i32
  store i32 %cv1672, ptr %slot286, align 8
  %v1673 = load i32, ptr %slot286, align 8
  %cv1674 = zext i32 %v1673 to i64
  %cond1675 = icmp ne i64 %cv1674, 0
  br i1 %cond1675, label %bb_rcglast355, label %bb_rcgdec355
bb_rcglast355:
  %v1676 = load i64, ptr %slot277, align 8
  %op1677 = sub i64 %v1676, 32
  store i64 %op1677, ptr %slot287, align 8
  %v1678 = load i64, ptr %slot277, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  %rgep1680 = getelementptr i8, ptr %p1679, i64 -32
  %ld1681 = load i64, ptr %rgep1680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1681, ptr %slot288, align 8
  %v1682 = load i64, ptr %slot288, align 8
  %cmp1683 = icmp ne i64 %v1682, 0
  %cv1684 = zext i1 %cmp1683 to i32
  store i32 %cv1684, ptr %slot289, align 8
  %v1685 = load i32, ptr %slot289, align 8
  %cv1686 = zext i32 %v1685 to i64
  %cond1687 = icmp ne i64 %cv1686, 0
  br i1 %cond1687, label %bb_rcgdec355, label %bb_rcgslow355
bb_rcgslow355:
  %v1688 = load i64, ptr %slot276, align 8
  %v1689 = load i64, ptr %slot273, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1688, i64 %v1689) nomerge, !dbg !128
  br label %bb_rcgdone355
bb_rcgdec355:
  %v1690 = load i64, ptr %slot285, align 8
  %v1691 = load i64, ptr %slot277, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %rgep1693 = getelementptr i8, ptr %p1692, i64 -24
  store i64 %v1690, ptr %rgep1693, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear355
bb_rcgclear355:
  %v1694 = load i64, ptr %slot273, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  store i64 0, ptr %p1695, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone355
bb_rcgdone355:
  br label %bb_rcslotdone339
bb_rcslotowner339:
  %v1696 = load i64, ptr %slot42, align 8
  store i64 %v1696, ptr %slot290, align 8
  %v1697 = load i64, ptr %slot273, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  %ld1699 = load i64, ptr %p1698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1699, ptr %slot291, align 8
  %v1700 = load i64, ptr %slot291, align 8
  %cmp1701 = icmp ne i64 %v1700, 0
  %cv1702 = zext i1 %cmp1701 to i32
  store i32 %cv1702, ptr %slot292, align 8
  %v1703 = load i32, ptr %slot292, align 8
  %cv1704 = zext i32 %v1703 to i64
  %cond1705 = icmp ne i64 %cv1704, 0
  br i1 %cond1705, label %bb_rcgnn370, label %bb_rcgdone370
bb_rcgnn370:
  %v1706 = load i64, ptr %slot291, align 8
  %op1707 = sub i64 %v1706, 16
  store i64 %op1707, ptr %slot293, align 8
  %v1708 = load i64, ptr %slot291, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %rgep1710 = getelementptr i8, ptr %p1709, i64 -16
  %ld1711 = load i64, ptr %rgep1710, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1711, ptr %slot294, align 8
  %v1712 = load i64, ptr %slot294, align 8
  %op1713 = and i64 %v1712, 4611686018427387906
  store i64 %op1713, ptr %slot295, align 8
  %v1714 = load i64, ptr %slot295, align 8
  %cmp1715 = icmp ne i64 %v1714, 0
  %cv1716 = zext i1 %cmp1715 to i32
  store i32 %cv1716, ptr %slot296, align 8
  %v1717 = load i32, ptr %slot296, align 8
  %cv1718 = zext i32 %v1717 to i64
  %cond1719 = icmp ne i64 %cv1718, 0
  br i1 %cond1719, label %bb_rcgclear370, label %bb_rcgcounted370
bb_rcgcounted370:
  %v1720 = load i64, ptr %slot291, align 8
  %op1721 = sub i64 %v1720, 32
  store i64 %op1721, ptr %slot297, align 8
  %v1722 = load i64, ptr %slot291, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  %rgep1724 = getelementptr i8, ptr %p1723, i64 -32
  %ld1725 = load i64, ptr %rgep1724, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1725, ptr %slot298, align 8
  %v1726 = load i64, ptr %slot298, align 8
  %op1727 = sub i64 %v1726, 1
  store i64 %op1727, ptr %slot299, align 8
  %v1728 = load i64, ptr %slot299, align 8
  %cmp1729 = icmp eq i64 %v1728, 0
  %cv1730 = zext i1 %cmp1729 to i32
  store i32 %cv1730, ptr %slot300, align 8
  %v1731 = load i32, ptr %slot300, align 8
  %cv1732 = zext i32 %v1731 to i64
  %cond1733 = icmp ne i64 %cv1732, 0
  br i1 %cond1733, label %bb_rcglast370, label %bb_rcgdec370
bb_rcglast370:
  %v1734 = load i64, ptr %slot291, align 8
  %op1735 = sub i64 %v1734, 24
  store i64 %op1735, ptr %slot301, align 8
  %v1736 = load i64, ptr %slot291, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %rgep1738 = getelementptr i8, ptr %p1737, i64 -24
  %ld1739 = load i64, ptr %rgep1738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1739, ptr %slot302, align 8
  %v1740 = load i64, ptr %slot302, align 8
  %cmp1741 = icmp ne i64 %v1740, 0
  %cv1742 = zext i1 %cmp1741 to i32
  store i32 %cv1742, ptr %slot303, align 8
  %v1743 = load i32, ptr %slot303, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcgdec370, label %bb_rcgslow370
bb_rcgslow370:
  %v1746 = load i64, ptr %slot290, align 8
  %v1747 = load i64, ptr %slot273, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1746, i64 %v1747) nomerge, !dbg !128
  br label %bb_rcgdone370
bb_rcgdec370:
  %v1748 = load i64, ptr %slot299, align 8
  %v1749 = load i64, ptr %slot291, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %rgep1751 = getelementptr i8, ptr %p1750, i64 -32
  store i64 %v1748, ptr %rgep1751, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear370
bb_rcgclear370:
  %v1752 = load i64, ptr %slot273, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i64 0, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone370
bb_rcgdone370:
  br label %bb_rcslotdone339
bb_rcslotdone339:
  %v1754 = load i64, ptr %slot12, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %ld1756 = load i32, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1756, ptr %slot304, align 8
  %v1757 = load i32, ptr %slot304, align 8
  %cv1758 = zext i32 %v1757 to i64
  %cond1759 = icmp ne i64 %cv1758, 0
  br i1 %cond1759, label %bb_rcslotdrop376, label %bb_rcslotdone376
bb_rcslotdrop376:
  %v1760 = load i64, ptr %slot12, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  store i32 0, ptr %p1761, align 4, !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot18, align 8
  store i64 %v1762, ptr %slot305, align 8
  %v1763 = load i64, ptr %slot13, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %ld1765 = load i32, ptr %p1764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1765, ptr %slot306, align 8
  %v1766 = load i32, ptr %slot306, align 8
  %op1767 = and i32 %v1766, 28
  store i32 %op1767, ptr %slot307, align 8
  %v1768 = load i32, ptr %slot307, align 8
  %cv1769 = zext i32 %v1768 to i64
  %cond1770 = icmp ne i64 %cv1769, 0
  br i1 %cond1770, label %bb_rcslotrole376, label %bb_rcslotowner376
bb_rcslotrole376:
  %v1771 = load i64, ptr %slot42, align 8
  store i64 %v1771, ptr %slot308, align 8
  %v1772 = load i64, ptr %slot305, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  %ld1774 = load i64, ptr %p1773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1774, ptr %slot309, align 8
  %v1775 = load i64, ptr %slot309, align 8
  %cmp1776 = icmp ne i64 %v1775, 0
  %cv1777 = zext i1 %cmp1776 to i32
  store i32 %cv1777, ptr %slot310, align 8
  %v1778 = load i32, ptr %slot310, align 8
  %cv1779 = zext i32 %v1778 to i64
  %cond1780 = icmp ne i64 %cv1779, 0
  br i1 %cond1780, label %bb_rcgnn392, label %bb_rcgdone392
bb_rcgnn392:
  %v1781 = load i64, ptr %slot309, align 8
  %op1782 = sub i64 %v1781, 16
  store i64 %op1782, ptr %slot311, align 8
  %v1783 = load i64, ptr %slot309, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %rgep1785 = getelementptr i8, ptr %p1784, i64 -16
  %ld1786 = load i64, ptr %rgep1785, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1786, ptr %slot312, align 8
  %v1787 = load i64, ptr %slot312, align 8
  %op1788 = and i64 %v1787, 4611686018427387906
  store i64 %op1788, ptr %slot313, align 8
  %v1789 = load i64, ptr %slot313, align 8
  %cmp1790 = icmp ne i64 %v1789, 0
  %cv1791 = zext i1 %cmp1790 to i32
  store i32 %cv1791, ptr %slot314, align 8
  %v1792 = load i32, ptr %slot314, align 8
  %cv1793 = zext i32 %v1792 to i64
  %cond1794 = icmp ne i64 %cv1793, 0
  br i1 %cond1794, label %bb_rcgclear392, label %bb_rcgcounted392
bb_rcgcounted392:
  %v1795 = load i64, ptr %slot309, align 8
  %op1796 = sub i64 %v1795, 24
  store i64 %op1796, ptr %slot315, align 8
  %v1797 = load i64, ptr %slot309, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %rgep1799 = getelementptr i8, ptr %p1798, i64 -24
  %ld1800 = load i64, ptr %rgep1799, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1800, ptr %slot316, align 8
  %v1801 = load i64, ptr %slot316, align 8
  %op1802 = sub i64 %v1801, 1
  store i64 %op1802, ptr %slot317, align 8
  %v1803 = load i64, ptr %slot317, align 8
  %cmp1804 = icmp eq i64 %v1803, 0
  %cv1805 = zext i1 %cmp1804 to i32
  store i32 %cv1805, ptr %slot318, align 8
  %v1806 = load i32, ptr %slot318, align 8
  %cv1807 = zext i32 %v1806 to i64
  %cond1808 = icmp ne i64 %cv1807, 0
  br i1 %cond1808, label %bb_rcglast392, label %bb_rcgdec392
bb_rcglast392:
  %v1809 = load i64, ptr %slot309, align 8
  %op1810 = sub i64 %v1809, 32
  store i64 %op1810, ptr %slot319, align 8
  %v1811 = load i64, ptr %slot309, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %rgep1813 = getelementptr i8, ptr %p1812, i64 -32
  %ld1814 = load i64, ptr %rgep1813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1814, ptr %slot320, align 8
  %v1815 = load i64, ptr %slot320, align 8
  %cmp1816 = icmp ne i64 %v1815, 0
  %cv1817 = zext i1 %cmp1816 to i32
  store i32 %cv1817, ptr %slot321, align 8
  %v1818 = load i32, ptr %slot321, align 8
  %cv1819 = zext i32 %v1818 to i64
  %cond1820 = icmp ne i64 %cv1819, 0
  br i1 %cond1820, label %bb_rcgdec392, label %bb_rcgslow392
bb_rcgslow392:
  %v1821 = load i64, ptr %slot308, align 8
  %v1822 = load i64, ptr %slot305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1821, i64 %v1822) nomerge, !dbg !128
  br label %bb_rcgdone392
bb_rcgdec392:
  %v1823 = load i64, ptr %slot317, align 8
  %v1824 = load i64, ptr %slot309, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  %rgep1826 = getelementptr i8, ptr %p1825, i64 -24
  store i64 %v1823, ptr %rgep1826, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear392
bb_rcgclear392:
  %v1827 = load i64, ptr %slot305, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i64 0, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone392
bb_rcgdone392:
  br label %bb_rcslotdone376
bb_rcslotowner376:
  %v1829 = load i64, ptr %slot42, align 8
  store i64 %v1829, ptr %slot322, align 8
  %v1830 = load i64, ptr %slot305, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %ld1832 = load i64, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1832, ptr %slot323, align 8
  %v1833 = load i64, ptr %slot323, align 8
  %cmp1834 = icmp ne i64 %v1833, 0
  %cv1835 = zext i1 %cmp1834 to i32
  store i32 %cv1835, ptr %slot324, align 8
  %v1836 = load i32, ptr %slot324, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcgnn407, label %bb_rcgdone407
bb_rcgnn407:
  %v1839 = load i64, ptr %slot323, align 8
  %op1840 = sub i64 %v1839, 16
  store i64 %op1840, ptr %slot325, align 8
  %v1841 = load i64, ptr %slot323, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %rgep1843 = getelementptr i8, ptr %p1842, i64 -16
  %ld1844 = load i64, ptr %rgep1843, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1844, ptr %slot326, align 8
  %v1845 = load i64, ptr %slot326, align 8
  %op1846 = and i64 %v1845, 4611686018427387906
  store i64 %op1846, ptr %slot327, align 8
  %v1847 = load i64, ptr %slot327, align 8
  %cmp1848 = icmp ne i64 %v1847, 0
  %cv1849 = zext i1 %cmp1848 to i32
  store i32 %cv1849, ptr %slot328, align 8
  %v1850 = load i32, ptr %slot328, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcgclear407, label %bb_rcgcounted407
bb_rcgcounted407:
  %v1853 = load i64, ptr %slot323, align 8
  %op1854 = sub i64 %v1853, 32
  store i64 %op1854, ptr %slot329, align 8
  %v1855 = load i64, ptr %slot323, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %rgep1857 = getelementptr i8, ptr %p1856, i64 -32
  %ld1858 = load i64, ptr %rgep1857, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1858, ptr %slot330, align 8
  %v1859 = load i64, ptr %slot330, align 8
  %op1860 = sub i64 %v1859, 1
  store i64 %op1860, ptr %slot331, align 8
  %v1861 = load i64, ptr %slot331, align 8
  %cmp1862 = icmp eq i64 %v1861, 0
  %cv1863 = zext i1 %cmp1862 to i32
  store i32 %cv1863, ptr %slot332, align 8
  %v1864 = load i32, ptr %slot332, align 8
  %cv1865 = zext i32 %v1864 to i64
  %cond1866 = icmp ne i64 %cv1865, 0
  br i1 %cond1866, label %bb_rcglast407, label %bb_rcgdec407
bb_rcglast407:
  %v1867 = load i64, ptr %slot323, align 8
  %op1868 = sub i64 %v1867, 24
  store i64 %op1868, ptr %slot333, align 8
  %v1869 = load i64, ptr %slot323, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %rgep1871 = getelementptr i8, ptr %p1870, i64 -24
  %ld1872 = load i64, ptr %rgep1871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1872, ptr %slot334, align 8
  %v1873 = load i64, ptr %slot334, align 8
  %cmp1874 = icmp ne i64 %v1873, 0
  %cv1875 = zext i1 %cmp1874 to i32
  store i32 %cv1875, ptr %slot335, align 8
  %v1876 = load i32, ptr %slot335, align 8
  %cv1877 = zext i32 %v1876 to i64
  %cond1878 = icmp ne i64 %cv1877, 0
  br i1 %cond1878, label %bb_rcgdec407, label %bb_rcgslow407
bb_rcgslow407:
  %v1879 = load i64, ptr %slot322, align 8
  %v1880 = load i64, ptr %slot305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1879, i64 %v1880) nomerge, !dbg !128
  br label %bb_rcgdone407
bb_rcgdec407:
  %v1881 = load i64, ptr %slot331, align 8
  %v1882 = load i64, ptr %slot323, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %rgep1884 = getelementptr i8, ptr %p1883, i64 -32
  store i64 %v1881, ptr %rgep1884, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear407
bb_rcgclear407:
  %v1885 = load i64, ptr %slot305, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i64 0, ptr %p1886, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone407
bb_rcgdone407:
  br label %bb_rcslotdone376
bb_rcslotdone376:
  br label %bb_i34
bb_i21:
  %v1887 = load i64, ptr %slot25, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %ld1889 = load i64, ptr %p1888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1889, ptr %slot336, align 8
  %v1890 = load i64, ptr %slot336, align 8
  %v1891 = load i64, ptr %slot29, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i64 %v1890, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot29, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  %ld1895 = load i64, ptr %p1894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1895, ptr %slot337, align 8
  %v1896 = load i64, ptr %slot337, align 8
  %op1897 = add i64 %v1896, 256
  store i64 %op1897, ptr %slot338, align 8
  %v1898 = load i64, ptr %slot338, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %ld1900 = load i64, ptr %p1899, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1900, ptr %slot339, align 8
  %v1901 = load i64, ptr %slot339, align 8
  %v1902 = load i64, ptr %slot29, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i64 %v1901, ptr %p1903, align 8, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot8, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %ld1906 = load i32, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1906, ptr %slot340, align 8
  %v1907 = load i32, ptr %slot340, align 8
  %cv1908 = zext i32 %v1907 to i64
  %cond1909 = icmp ne i64 %cv1908, 0
  br i1 %cond1909, label %bb_rcslotdrop417, label %bb_rcslotdone417
bb_rcslotdrop417:
  %v1910 = load i64, ptr %slot8, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 0, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot16, align 8
  store i64 %v1912, ptr %slot341, align 8
  %v1913 = load i64, ptr %slot9, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i32, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1915, ptr %slot342, align 8
  %v1916 = load i32, ptr %slot342, align 8
  %op1917 = and i32 %v1916, 28
  store i32 %op1917, ptr %slot343, align 8
  %v1918 = load i32, ptr %slot343, align 8
  %cv1919 = zext i32 %v1918 to i64
  %cond1920 = icmp ne i64 %cv1919, 0
  br i1 %cond1920, label %bb_rcslotrole417, label %bb_rcslotowner417
bb_rcslotrole417:
  %v1921 = load i64, ptr %slot42, align 8
  store i64 %v1921, ptr %slot344, align 8
  %v1922 = load i64, ptr %slot344, align 8
  %v1923 = load i64, ptr %slot341, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1922, i64 %v1923) nomerge, !dbg !130
  br label %bb_rcslotdone417
bb_rcslotowner417:
  %v1924 = load i64, ptr %slot42, align 8
  store i64 %v1924, ptr %slot345, align 8
  %v1925 = load i64, ptr %slot345, align 8
  %v1926 = load i64, ptr %slot341, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1925, i64 %v1926) nomerge, !dbg !130
  br label %bb_rcslotdone417
bb_rcslotdone417:
  %v1927 = load i64, ptr %slot29, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %ld1929 = load i64, ptr %p1928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1929, ptr %slot346, align 8
  %v1930 = load i64, ptr %slot25, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  %ld1932 = load i64, ptr %p1931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1932, ptr %slot347, align 8
  %v1933 = load i64, ptr %slot8, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i32, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1935, ptr %slot348, align 8
  %v1936 = load i32, ptr %slot348, align 8
  %cv1937 = zext i32 %v1936 to i64
  %cond1938 = icmp ne i64 %cv1937, 0
  br i1 %cond1938, label %bb_rcslotdrop429, label %bb_rcslotdone429
bb_rcslotdrop429:
  %v1939 = load i64, ptr %slot8, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  store i32 0, ptr %p1940, align 4, !alias.scope !3, !noalias !4
  %v1941 = load i64, ptr %slot16, align 8
  store i64 %v1941, ptr %slot349, align 8
  %v1942 = load i64, ptr %slot9, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i32, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1944, ptr %slot350, align 8
  %v1945 = load i32, ptr %slot350, align 8
  %op1946 = and i32 %v1945, 28
  store i32 %op1946, ptr %slot351, align 8
  %v1947 = load i32, ptr %slot351, align 8
  %cv1948 = zext i32 %v1947 to i64
  %cond1949 = icmp ne i64 %cv1948, 0
  br i1 %cond1949, label %bb_rcslotrole429, label %bb_rcslotowner429
bb_rcslotrole429:
  %v1950 = load i64, ptr %slot42, align 8
  store i64 %v1950, ptr %slot352, align 8
  %v1951 = load i64, ptr %slot349, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %ld1953 = load i64, ptr %p1952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1953, ptr %slot353, align 8
  %v1954 = load i64, ptr %slot353, align 8
  %cmp1955 = icmp ne i64 %v1954, 0
  %cv1956 = zext i1 %cmp1955 to i32
  store i32 %cv1956, ptr %slot354, align 8
  %v1957 = load i32, ptr %slot354, align 8
  %cv1958 = zext i32 %v1957 to i64
  %cond1959 = icmp ne i64 %cv1958, 0
  br i1 %cond1959, label %bb_rcgnn445, label %bb_rcgdone445
bb_rcgnn445:
  %v1960 = load i64, ptr %slot353, align 8
  %op1961 = sub i64 %v1960, 16
  store i64 %op1961, ptr %slot355, align 8
  %v1962 = load i64, ptr %slot353, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  %rgep1964 = getelementptr i8, ptr %p1963, i64 -16
  %ld1965 = load i64, ptr %rgep1964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1965, ptr %slot356, align 8
  %v1966 = load i64, ptr %slot356, align 8
  %op1967 = and i64 %v1966, 4611686018427387906
  store i64 %op1967, ptr %slot357, align 8
  %v1968 = load i64, ptr %slot357, align 8
  %cmp1969 = icmp ne i64 %v1968, 0
  %cv1970 = zext i1 %cmp1969 to i32
  store i32 %cv1970, ptr %slot358, align 8
  %v1971 = load i32, ptr %slot358, align 8
  %cv1972 = zext i32 %v1971 to i64
  %cond1973 = icmp ne i64 %cv1972, 0
  br i1 %cond1973, label %bb_rcgclear445, label %bb_rcgcounted445
bb_rcgcounted445:
  %v1974 = load i64, ptr %slot353, align 8
  %op1975 = sub i64 %v1974, 24
  store i64 %op1975, ptr %slot359, align 8
  %v1976 = load i64, ptr %slot353, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %rgep1978 = getelementptr i8, ptr %p1977, i64 -24
  %ld1979 = load i64, ptr %rgep1978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1979, ptr %slot360, align 8
  %v1980 = load i64, ptr %slot360, align 8
  %op1981 = sub i64 %v1980, 1
  store i64 %op1981, ptr %slot361, align 8
  %v1982 = load i64, ptr %slot361, align 8
  %cmp1983 = icmp eq i64 %v1982, 0
  %cv1984 = zext i1 %cmp1983 to i32
  store i32 %cv1984, ptr %slot362, align 8
  %v1985 = load i32, ptr %slot362, align 8
  %cv1986 = zext i32 %v1985 to i64
  %cond1987 = icmp ne i64 %cv1986, 0
  br i1 %cond1987, label %bb_rcglast445, label %bb_rcgdec445
bb_rcglast445:
  %v1988 = load i64, ptr %slot353, align 8
  %op1989 = sub i64 %v1988, 32
  store i64 %op1989, ptr %slot363, align 8
  %v1990 = load i64, ptr %slot353, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  %rgep1992 = getelementptr i8, ptr %p1991, i64 -32
  %ld1993 = load i64, ptr %rgep1992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1993, ptr %slot364, align 8
  %v1994 = load i64, ptr %slot364, align 8
  %cmp1995 = icmp ne i64 %v1994, 0
  %cv1996 = zext i1 %cmp1995 to i32
  store i32 %cv1996, ptr %slot365, align 8
  %v1997 = load i32, ptr %slot365, align 8
  %cv1998 = zext i32 %v1997 to i64
  %cond1999 = icmp ne i64 %cv1998, 0
  br i1 %cond1999, label %bb_rcgdec445, label %bb_rcgslow445
bb_rcgslow445:
  %v2000 = load i64, ptr %slot352, align 8
  %v2001 = load i64, ptr %slot349, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v2000, i64 %v2001) nomerge, !dbg !132
  br label %bb_rcgdone445
bb_rcgdec445:
  %v2002 = load i64, ptr %slot361, align 8
  %v2003 = load i64, ptr %slot353, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %rgep2005 = getelementptr i8, ptr %p2004, i64 -24
  store i64 %v2002, ptr %rgep2005, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear445
bb_rcgclear445:
  %v2006 = load i64, ptr %slot349, align 8
  %p2007 = inttoptr i64 %v2006 to ptr
  store i64 0, ptr %p2007, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone445
bb_rcgdone445:
  br label %bb_rcslotdone429
bb_rcslotowner429:
  %v2008 = load i64, ptr %slot42, align 8
  store i64 %v2008, ptr %slot366, align 8
  %v2009 = load i64, ptr %slot349, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %ld2011 = load i64, ptr %p2010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2011, ptr %slot367, align 8
  %v2012 = load i64, ptr %slot367, align 8
  %cmp2013 = icmp ne i64 %v2012, 0
  %cv2014 = zext i1 %cmp2013 to i32
  store i32 %cv2014, ptr %slot368, align 8
  %v2015 = load i32, ptr %slot368, align 8
  %cv2016 = zext i32 %v2015 to i64
  %cond2017 = icmp ne i64 %cv2016, 0
  br i1 %cond2017, label %bb_rcgnn460, label %bb_rcgdone460
bb_rcgnn460:
  %v2018 = load i64, ptr %slot367, align 8
  %op2019 = sub i64 %v2018, 16
  store i64 %op2019, ptr %slot369, align 8
  %v2020 = load i64, ptr %slot367, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  %rgep2022 = getelementptr i8, ptr %p2021, i64 -16
  %ld2023 = load i64, ptr %rgep2022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2023, ptr %slot370, align 8
  %v2024 = load i64, ptr %slot370, align 8
  %op2025 = and i64 %v2024, 4611686018427387906
  store i64 %op2025, ptr %slot371, align 8
  %v2026 = load i64, ptr %slot371, align 8
  %cmp2027 = icmp ne i64 %v2026, 0
  %cv2028 = zext i1 %cmp2027 to i32
  store i32 %cv2028, ptr %slot372, align 8
  %v2029 = load i32, ptr %slot372, align 8
  %cv2030 = zext i32 %v2029 to i64
  %cond2031 = icmp ne i64 %cv2030, 0
  br i1 %cond2031, label %bb_rcgclear460, label %bb_rcgcounted460
bb_rcgcounted460:
  %v2032 = load i64, ptr %slot367, align 8
  %op2033 = sub i64 %v2032, 32
  store i64 %op2033, ptr %slot373, align 8
  %v2034 = load i64, ptr %slot367, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %rgep2036 = getelementptr i8, ptr %p2035, i64 -32
  %ld2037 = load i64, ptr %rgep2036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2037, ptr %slot374, align 8
  %v2038 = load i64, ptr %slot374, align 8
  %op2039 = sub i64 %v2038, 1
  store i64 %op2039, ptr %slot375, align 8
  %v2040 = load i64, ptr %slot375, align 8
  %cmp2041 = icmp eq i64 %v2040, 0
  %cv2042 = zext i1 %cmp2041 to i32
  store i32 %cv2042, ptr %slot376, align 8
  %v2043 = load i32, ptr %slot376, align 8
  %cv2044 = zext i32 %v2043 to i64
  %cond2045 = icmp ne i64 %cv2044, 0
  br i1 %cond2045, label %bb_rcglast460, label %bb_rcgdec460
bb_rcglast460:
  %v2046 = load i64, ptr %slot367, align 8
  %op2047 = sub i64 %v2046, 24
  store i64 %op2047, ptr %slot377, align 8
  %v2048 = load i64, ptr %slot367, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  %rgep2050 = getelementptr i8, ptr %p2049, i64 -24
  %ld2051 = load i64, ptr %rgep2050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2051, ptr %slot378, align 8
  %v2052 = load i64, ptr %slot378, align 8
  %cmp2053 = icmp ne i64 %v2052, 0
  %cv2054 = zext i1 %cmp2053 to i32
  store i32 %cv2054, ptr %slot379, align 8
  %v2055 = load i32, ptr %slot379, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcgdec460, label %bb_rcgslow460
bb_rcgslow460:
  %v2058 = load i64, ptr %slot366, align 8
  %v2059 = load i64, ptr %slot349, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v2058, i64 %v2059) nomerge, !dbg !132
  br label %bb_rcgdone460
bb_rcgdec460:
  %v2060 = load i64, ptr %slot375, align 8
  %v2061 = load i64, ptr %slot367, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %rgep2063 = getelementptr i8, ptr %p2062, i64 -32
  store i64 %v2060, ptr %rgep2063, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear460
bb_rcgclear460:
  %v2064 = load i64, ptr %slot349, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  store i64 0, ptr %p2065, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone460
bb_rcgdone460:
  br label %bb_rcslotdone429
bb_rcslotdone429:
  %v2066 = load i64, ptr %slot347, align 8
  %op2067 = add i64 %v2066, 256
  store i64 %op2067, ptr %slot380, align 8
  store i64 0, ptr %slot381, align 8
  %v2068 = load i64, ptr %slot380, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %ld2070 = load i64, ptr %p2069, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2070, ptr %slot382, align 8
  %v2071 = load i64, ptr %slot382, align 8
  %cmp2072 = icmp ne i64 %v2071, 0
  %cv2073 = zext i1 %cmp2072 to i32
  store i32 %cv2073, ptr %slot383, align 8
  %v2074 = load i32, ptr %slot383, align 8
  %cv2075 = zext i32 %v2074 to i64
  %cond2076 = icmp ne i64 %cv2075, 0
  br i1 %cond2076, label %bb_rcguniquenn466, label %bb_rcgunique466
bb_rcguniquenn466:
  %v2077 = load i64, ptr %slot382, align 8
  %op2078 = sub i64 %v2077, 16
  store i64 %op2078, ptr %slot384, align 8
  %v2079 = load i64, ptr %slot382, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %rgep2081 = getelementptr i8, ptr %p2080, i64 -16
  %ld2082 = load i64, ptr %rgep2081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2082, ptr %slot385, align 8
  %v2083 = load i64, ptr %slot385, align 8
  %op2084 = and i64 %v2083, 6917529027641081858
  store i64 %op2084, ptr %slot386, align 8
  %v2085 = load i64, ptr %slot386, align 8
  %cmp2086 = icmp ne i64 %v2085, 0
  %cv2087 = zext i1 %cmp2086 to i32
  store i32 %cv2087, ptr %slot387, align 8
  %v2088 = load i32, ptr %slot387, align 8
  %cv2089 = zext i32 %v2088 to i64
  %cond2090 = icmp ne i64 %cv2089, 0
  br i1 %cond2090, label %bb_rcguniqueslow466, label %bb_rcguniquecount466
bb_rcguniquecount466:
  %v2091 = load i64, ptr %slot382, align 8
  %op2092 = sub i64 %v2091, 32
  store i64 %op2092, ptr %slot388, align 8
  %v2093 = load i64, ptr %slot382, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  %rgep2095 = getelementptr i8, ptr %p2094, i64 -32
  %ld2096 = load i64, ptr %rgep2095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2096, ptr %slot389, align 8
  %v2097 = load i64, ptr %slot389, align 8
  %cmp2098 = icmp ult i64 %v2097, 2
  %cv2099 = zext i1 %cmp2098 to i32
  store i32 %cv2099, ptr %slot390, align 8
  %v2100 = load i32, ptr %slot390, align 8
  %cv2101 = zext i32 %v2100 to i64
  %cond2102 = icmp ne i64 %cv2101, 0
  br i1 %cond2102, label %bb_rcgunique466, label %bb_rcguniqueslow466
bb_rcguniqueslow466:
  %v2103 = load i64, ptr %slot1, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %p2105 = inttoptr i64 ptrtoint (ptr @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e to i64) to ptr
  %v2106 = load i64, ptr %slot380, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  %v2108 = load i64, ptr %slot381, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %call2110 = call i32 @myl_qbe_rc_unique_field(ptr %p2104, ptr %p2105, ptr %p2107, ptr %p2109) nomerge, !dbg !132
  store i32 %call2110, ptr %slot391, align 8
  %v2111 = load i32, ptr %slot391, align 8
  %cv2112 = zext i32 %v2111 to i64
  %cond2113 = icmp ne i64 %cv2112, 0
  br i1 %cond2113, label %bb_rcunique476, label %bb_failure
bb_rcunique476:
  br label %bb_rcgunique466
bb_rcgunique466:
  %v2114 = load i64, ptr %slot380, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i64, ptr %p2115, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2116, ptr %slot392, align 8
  %v2117 = load i64, ptr %slot392, align 8
  %v2118 = load i64, ptr %slot29, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i64 %v2117, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  %v2120 = load i64, ptr %slot29, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i64, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2122, ptr %slot393, align 8
  %v2123 = load i64, ptr %slot8, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  %ld2125 = load i32, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2125, ptr %slot394, align 8
  %v2126 = load i32, ptr %slot394, align 8
  %cv2127 = zext i32 %v2126 to i64
  %cond2128 = icmp ne i64 %cv2127, 0
  br i1 %cond2128, label %bb_rcslotdrop481, label %bb_rcslotdone481
bb_rcslotdrop481:
  %v2129 = load i64, ptr %slot8, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i32 0, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot16, align 8
  store i64 %v2131, ptr %slot395, align 8
  %v2132 = load i64, ptr %slot9, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %ld2134 = load i32, ptr %p2133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2134, ptr %slot396, align 8
  %v2135 = load i32, ptr %slot396, align 8
  %op2136 = and i32 %v2135, 28
  store i32 %op2136, ptr %slot397, align 8
  %v2137 = load i32, ptr %slot397, align 8
  %cv2138 = zext i32 %v2137 to i64
  %cond2139 = icmp ne i64 %cv2138, 0
  br i1 %cond2139, label %bb_rcslotrole481, label %bb_rcslotowner481
bb_rcslotrole481:
  %v2140 = load i64, ptr %slot42, align 8
  store i64 %v2140, ptr %slot398, align 8
  %v2141 = load i64, ptr %slot395, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  %ld2143 = load i64, ptr %p2142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2143, ptr %slot399, align 8
  %v2144 = load i64, ptr %slot399, align 8
  %cmp2145 = icmp ne i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot400, align 8
  %v2147 = load i32, ptr %slot400, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcgnn497, label %bb_rcgdone497
bb_rcgnn497:
  %v2150 = load i64, ptr %slot399, align 8
  %op2151 = sub i64 %v2150, 16
  store i64 %op2151, ptr %slot401, align 8
  %v2152 = load i64, ptr %slot399, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %rgep2154 = getelementptr i8, ptr %p2153, i64 -16
  %ld2155 = load i64, ptr %rgep2154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2155, ptr %slot402, align 8
  %v2156 = load i64, ptr %slot402, align 8
  %op2157 = and i64 %v2156, 4611686018427387906
  store i64 %op2157, ptr %slot403, align 8
  %v2158 = load i64, ptr %slot403, align 8
  %cmp2159 = icmp ne i64 %v2158, 0
  %cv2160 = zext i1 %cmp2159 to i32
  store i32 %cv2160, ptr %slot404, align 8
  %v2161 = load i32, ptr %slot404, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcgclear497, label %bb_rcgcounted497
bb_rcgcounted497:
  %v2164 = load i64, ptr %slot399, align 8
  %op2165 = sub i64 %v2164, 24
  store i64 %op2165, ptr %slot405, align 8
  %v2166 = load i64, ptr %slot399, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %rgep2168 = getelementptr i8, ptr %p2167, i64 -24
  %ld2169 = load i64, ptr %rgep2168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2169, ptr %slot406, align 8
  %v2170 = load i64, ptr %slot406, align 8
  %op2171 = sub i64 %v2170, 1
  store i64 %op2171, ptr %slot407, align 8
  %v2172 = load i64, ptr %slot407, align 8
  %cmp2173 = icmp eq i64 %v2172, 0
  %cv2174 = zext i1 %cmp2173 to i32
  store i32 %cv2174, ptr %slot408, align 8
  %v2175 = load i32, ptr %slot408, align 8
  %cv2176 = zext i32 %v2175 to i64
  %cond2177 = icmp ne i64 %cv2176, 0
  br i1 %cond2177, label %bb_rcglast497, label %bb_rcgdec497
bb_rcglast497:
  %v2178 = load i64, ptr %slot399, align 8
  %op2179 = sub i64 %v2178, 32
  store i64 %op2179, ptr %slot409, align 8
  %v2180 = load i64, ptr %slot399, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %rgep2182 = getelementptr i8, ptr %p2181, i64 -32
  %ld2183 = load i64, ptr %rgep2182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2183, ptr %slot410, align 8
  %v2184 = load i64, ptr %slot410, align 8
  %cmp2185 = icmp ne i64 %v2184, 0
  %cv2186 = zext i1 %cmp2185 to i32
  store i32 %cv2186, ptr %slot411, align 8
  %v2187 = load i32, ptr %slot411, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcgdec497, label %bb_rcgslow497
bb_rcgslow497:
  %v2190 = load i64, ptr %slot398, align 8
  %v2191 = load i64, ptr %slot395, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v2190, i64 %v2191) nomerge, !dbg !132
  br label %bb_rcgdone497
bb_rcgdec497:
  %v2192 = load i64, ptr %slot407, align 8
  %v2193 = load i64, ptr %slot399, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %rgep2195 = getelementptr i8, ptr %p2194, i64 -24
  store i64 %v2192, ptr %rgep2195, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear497
bb_rcgclear497:
  %v2196 = load i64, ptr %slot395, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i64 0, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone497
bb_rcgdone497:
  br label %bb_rcslotdone481
bb_rcslotowner481:
  %v2198 = load i64, ptr %slot42, align 8
  store i64 %v2198, ptr %slot412, align 8
  %v2199 = load i64, ptr %slot395, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot413, align 8
  %v2202 = load i64, ptr %slot413, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot414, align 8
  %v2205 = load i32, ptr %slot414, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcgnn512, label %bb_rcgdone512
bb_rcgnn512:
  %v2208 = load i64, ptr %slot413, align 8
  %op2209 = sub i64 %v2208, 16
  store i64 %op2209, ptr %slot415, align 8
  %v2210 = load i64, ptr %slot413, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -16
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot416, align 8
  %v2214 = load i64, ptr %slot416, align 8
  %op2215 = and i64 %v2214, 4611686018427387906
  store i64 %op2215, ptr %slot417, align 8
  %v2216 = load i64, ptr %slot417, align 8
  %cmp2217 = icmp ne i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot418, align 8
  %v2219 = load i32, ptr %slot418, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcgclear512, label %bb_rcgcounted512
bb_rcgcounted512:
  %v2222 = load i64, ptr %slot413, align 8
  %op2223 = sub i64 %v2222, 32
  store i64 %op2223, ptr %slot419, align 8
  %v2224 = load i64, ptr %slot413, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %rgep2226 = getelementptr i8, ptr %p2225, i64 -32
  %ld2227 = load i64, ptr %rgep2226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2227, ptr %slot420, align 8
  %v2228 = load i64, ptr %slot420, align 8
  %op2229 = sub i64 %v2228, 1
  store i64 %op2229, ptr %slot421, align 8
  %v2230 = load i64, ptr %slot421, align 8
  %cmp2231 = icmp eq i64 %v2230, 0
  %cv2232 = zext i1 %cmp2231 to i32
  store i32 %cv2232, ptr %slot422, align 8
  %v2233 = load i32, ptr %slot422, align 8
  %cv2234 = zext i32 %v2233 to i64
  %cond2235 = icmp ne i64 %cv2234, 0
  br i1 %cond2235, label %bb_rcglast512, label %bb_rcgdec512
bb_rcglast512:
  %v2236 = load i64, ptr %slot413, align 8
  %op2237 = sub i64 %v2236, 24
  store i64 %op2237, ptr %slot423, align 8
  %v2238 = load i64, ptr %slot413, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %rgep2240 = getelementptr i8, ptr %p2239, i64 -24
  %ld2241 = load i64, ptr %rgep2240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2241, ptr %slot424, align 8
  %v2242 = load i64, ptr %slot424, align 8
  %cmp2243 = icmp ne i64 %v2242, 0
  %cv2244 = zext i1 %cmp2243 to i32
  store i32 %cv2244, ptr %slot425, align 8
  %v2245 = load i32, ptr %slot425, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcgdec512, label %bb_rcgslow512
bb_rcgslow512:
  %v2248 = load i64, ptr %slot412, align 8
  %v2249 = load i64, ptr %slot395, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v2248, i64 %v2249) nomerge, !dbg !132
  br label %bb_rcgdone512
bb_rcgdec512:
  %v2250 = load i64, ptr %slot421, align 8
  %v2251 = load i64, ptr %slot413, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %rgep2253 = getelementptr i8, ptr %p2252, i64 -32
  store i64 %v2250, ptr %rgep2253, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear512
bb_rcgclear512:
  %v2254 = load i64, ptr %slot395, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 0, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone512
bb_rcgdone512:
  br label %bb_rcslotdone481
bb_rcslotdone481:
  %v2256 = load i64, ptr %slot393, align 8
  %v2257 = load i64, ptr %slot28, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  store i64 %v2256, ptr %p2258, align 8, !alias.scope !3, !noalias !4
  %v2259 = load i64, ptr %slot27, align 8
  %v2260 = load i64, ptr %slot35, align 8
  %p2261 = inttoptr i64 %v2259 to ptr
  %p2262 = inttoptr i64 %v2260 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2262, ptr %p2261, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2263 = load i64, ptr %slot35, align 8
  %v2264 = load i64, ptr %slot29, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i64 %v2263, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot28, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %ld2268 = load i64, ptr %p2267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2268, ptr %slot426, align 8
  %v2269 = load i64, ptr %slot29, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  %ld2271 = load i64, ptr %p2270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2271, ptr %slot427, align 8
  %v2272 = load i64, ptr %slot42, align 8
  %v2273 = load i64, ptr %slot426, align 8
  %v2274 = load i64, ptr %slot427, align 8
  %call2275 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_list_append(i64 %v2272, i64 %v2273, i64 %v2274) nomerge, !dbg !134
  store i32 %call2275, ptr %slot428, align 8
  %v2276 = load i32, ptr %slot428, align 8
  %cv2277 = zext i32 %v2276 to i64
  %cond2278 = icmp ne i64 %cv2277, 0
  br i1 %cond2278, label %bb_success556, label %bb_failed556
bb_failed556:
  %v2279 = load i64, ptr %slot1, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2280) nomerge, !dbg !134
  unreachable
bb_success556:
  %v2281 = load i64, ptr %slot29, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i64 0, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot8, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  %ld2285 = load i32, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2285, ptr %slot429, align 8
  %v2286 = load i32, ptr %slot429, align 8
  %cv2287 = zext i32 %v2286 to i64
  %cond2288 = icmp ne i64 %cv2287, 0
  br i1 %cond2288, label %bb_rcslotdrop559, label %bb_rcslotdone559
bb_rcslotdrop559:
  %v2289 = load i64, ptr %slot8, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i32 0, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot16, align 8
  store i64 %v2291, ptr %slot430, align 8
  %v2292 = load i64, ptr %slot9, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %ld2294 = load i32, ptr %p2293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2294, ptr %slot431, align 8
  %v2295 = load i32, ptr %slot431, align 8
  %op2296 = and i32 %v2295, 28
  store i32 %op2296, ptr %slot432, align 8
  %v2297 = load i32, ptr %slot432, align 8
  %cv2298 = zext i32 %v2297 to i64
  %cond2299 = icmp ne i64 %cv2298, 0
  br i1 %cond2299, label %bb_rcslotrole559, label %bb_rcslotowner559
bb_rcslotrole559:
  %v2300 = load i64, ptr %slot42, align 8
  store i64 %v2300, ptr %slot433, align 8
  %v2301 = load i64, ptr %slot433, align 8
  %v2302 = load i64, ptr %slot430, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2301, i64 %v2302) nomerge, !dbg !134
  br label %bb_rcslotdone559
bb_rcslotowner559:
  %v2303 = load i64, ptr %slot42, align 8
  store i64 %v2303, ptr %slot434, align 8
  %v2304 = load i64, ptr %slot434, align 8
  %v2305 = load i64, ptr %slot430, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2304, i64 %v2305) nomerge, !dbg !134
  br label %bb_rcslotdone559
bb_rcslotdone559:
  %v2306 = load i64, ptr %slot27, align 8
  %v2307 = load i64, ptr %slot29, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i64 %v2306, ptr %p2308, align 8, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot29, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  %ld2311 = load i64, ptr %p2310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2311, ptr %slot435, align 8
  %v2312 = load i64, ptr %slot435, align 8
  %op2313 = add i64 %v2312, 0
  store i64 %op2313, ptr %slot436, align 8
  %v2314 = load i64, ptr %slot436, align 8
  %v2315 = load i64, ptr %slot29, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  store i64 %v2314, ptr %p2316, align 8, !alias.scope !3, !noalias !4
  %v2317 = load i64, ptr %slot29, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %ld2319 = load i64, ptr %p2318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2319, ptr %slot437, align 8
  %v2320 = load i64, ptr %slot36, align 8
  store i64 %v2320, ptr %slot438, align 8
  %v2321 = load i64, ptr %slot437, align 8
  %v2322 = load i64, ptr %slot438, align 8
  %p2323 = inttoptr i64 %v2321 to ptr
  %p2324 = inttoptr i64 %v2322 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2324, ptr %p2323, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2325 = load i64, ptr %slot438, align 8
  %v2326 = load i64, ptr %slot29, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  store i64 %v2325, ptr %p2327, align 8, !alias.scope !3, !noalias !4
  %v2328 = load i64, ptr %slot8, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  %ld2330 = load i32, ptr %p2329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2330, ptr %slot439, align 8
  %v2331 = load i32, ptr %slot439, align 8
  %cv2332 = zext i32 %v2331 to i64
  %cond2333 = icmp ne i64 %cv2332, 0
  br i1 %cond2333, label %bb_rcslotdrop572, label %bb_rcslotdone572
bb_rcslotdrop572:
  %v2334 = load i64, ptr %slot8, align 8
  %p2335 = inttoptr i64 %v2334 to ptr
  store i32 0, ptr %p2335, align 4, !alias.scope !3, !noalias !4
  %v2336 = load i64, ptr %slot16, align 8
  store i64 %v2336, ptr %slot440, align 8
  %v2337 = load i64, ptr %slot9, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  %ld2339 = load i32, ptr %p2338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2339, ptr %slot441, align 8
  %v2340 = load i32, ptr %slot441, align 8
  %op2341 = and i32 %v2340, 28
  store i32 %op2341, ptr %slot442, align 8
  %v2342 = load i32, ptr %slot442, align 8
  %cv2343 = zext i32 %v2342 to i64
  %cond2344 = icmp ne i64 %cv2343, 0
  br i1 %cond2344, label %bb_rcslotrole572, label %bb_rcslotowner572
bb_rcslotrole572:
  %v2345 = load i64, ptr %slot42, align 8
  store i64 %v2345, ptr %slot443, align 8
  %v2346 = load i64, ptr %slot443, align 8
  %v2347 = load i64, ptr %slot440, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2346, i64 %v2347) nomerge, !dbg !136
  br label %bb_rcslotdone572
bb_rcslotowner572:
  %v2348 = load i64, ptr %slot42, align 8
  store i64 %v2348, ptr %slot444, align 8
  %v2349 = load i64, ptr %slot444, align 8
  %v2350 = load i64, ptr %slot440, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2349, i64 %v2350) nomerge, !dbg !136
  br label %bb_rcslotdone572
bb_rcslotdone572:
  %v2351 = load i64, ptr %slot37, align 8
  store i64 %v2351, ptr %slot445, align 8
  %v2352 = load i64, ptr %slot445, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  store i32 0, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot445, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  store i32 39, ptr %p2355, align 4, !alias.scope !3, !noalias !4
  %v2356 = load i64, ptr %slot445, align 8
  %v2357 = load i64, ptr %slot30, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i64 %v2356, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot30, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %ld2361 = load i64, ptr %p2360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2361, ptr %slot446, align 8
  %v2362 = load i64, ptr %slot29, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %ld2364 = load i64, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2364, ptr %slot447, align 8
  %v2365 = load i64, ptr %slot447, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i32, ptr %p2366, align 4, !alias.scope !3, !noalias !4
  %ext2368 = zext i32 %ld2367 to i64
  store i64 %ext2368, ptr %slot448, align 8
  %v2369 = load i64, ptr %slot446, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  %ld2371 = load i32, ptr %p2370, align 4, !alias.scope !3, !noalias !4
  %ext2372 = zext i32 %ld2371 to i64
  store i64 %ext2372, ptr %slot449, align 8
  %v2373 = load i64, ptr %slot448, align 8
  %v2374 = load i64, ptr %slot449, align 8
  %cmp2375 = icmp eq i64 %v2373, %v2374
  %cv2376 = zext i1 %cmp2375 to i64
  store i64 %cv2376, ptr %slot450, align 8
  %v2377 = load i64, ptr %slot450, align 8
  %v2378 = load i64, ptr %slot29, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i64 %v2377, ptr %p2379, align 8, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot29, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i64, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2382, ptr %slot451, align 8
  %v2383 = load i64, ptr %slot451, align 8
  %cond2384 = icmp ne i64 %v2383, 0
  br i1 %cond2384, label %bb_next586, label %bb_i34
bb_next586:
  %v2385 = load i64, ptr %slot29, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  store i64 0, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  %v2387 = load i64, ptr %slot29, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %ld2389 = load i64, ptr %p2388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2389, ptr %slot452, align 8
  %v2390 = load i64, ptr %slot22, align 8
  %p2392 = inttoptr i64 %v2390 to ptr
  %gep2393 = getelementptr i8, ptr %p2392, i64 24
  %op2391 = ptrtoint ptr %gep2393 to i64
  store i64 %op2391, ptr %slot453, align 8
  %v2394 = load i64, ptr %slot453, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i32, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2396, ptr %slot454, align 8
  %v2397 = load i32, ptr %slot454, align 8
  %cv2398 = zext i32 %v2397 to i64
  %cond2399 = icmp ne i64 %cv2398, 0
  br i1 %cond2399, label %bb_rcscopesopen589, label %bb_rcscopesclosed589
bb_rcscopesopen589:
  %v2400 = load i64, ptr %slot24, align 8
  %p2402 = inttoptr i64 %v2400 to ptr
  %gep2403 = getelementptr i8, ptr %p2402, i64 0
  %op2401 = ptrtoint ptr %gep2403 to i64
  store i64 %op2401, ptr %slot455, align 8
  %v2404 = load i64, ptr %slot22, align 8
  %v2405 = load i64, ptr %slot455, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i64 %v2404, ptr %p2406, align 8, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot1, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  %v2409 = load i64, ptr %slot24, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2408, ptr %p2410, i64 1) nomerge, !dbg !138
  br label %bb_rcscopesclosed589
bb_rcscopesclosed589:
  %v2411 = load i64, ptr %slot8, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %ld2413 = load i32, ptr %p2412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2413, ptr %slot456, align 8
  %v2414 = load i32, ptr %slot456, align 8
  %cv2415 = zext i32 %v2414 to i64
  %cond2416 = icmp ne i64 %cv2415, 0
  br i1 %cond2416, label %bb_rcslotdrop593, label %bb_rcslotdone593
bb_rcslotdrop593:
  %v2417 = load i64, ptr %slot8, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  store i32 0, ptr %p2418, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone593
bb_rcslotdone593:
  %v2419 = load i64, ptr %slot6, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i32, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2421, ptr %slot457, align 8
  %v2422 = load i32, ptr %slot457, align 8
  %cv2423 = zext i32 %v2422 to i64
  %cond2424 = icmp ne i64 %cv2423, 0
  br i1 %cond2424, label %bb_rcslotdrop633, label %bb_rcslotdone633
bb_rcslotdrop633:
  %v2425 = load i64, ptr %slot6, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i32 0, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  %v2427 = load i64, ptr %slot27, align 8
  store i64 %v2427, ptr %slot458, align 8
  %v2428 = load i64, ptr %slot7, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %ld2430 = load i32, ptr %p2429, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2430, ptr %slot459, align 8
  %v2431 = load i32, ptr %slot459, align 8
  %op2432 = and i32 %v2431, 28
  store i32 %op2432, ptr %slot460, align 8
  %v2433 = load i32, ptr %slot460, align 8
  %cv2434 = zext i32 %v2433 to i64
  %cond2435 = icmp ne i64 %cv2434, 0
  br i1 %cond2435, label %bb_rcslotrole633, label %bb_rcslotowner633
bb_rcslotrole633:
  %v2436 = load i64, ptr %slot42, align 8
  store i64 %v2436, ptr %slot461, align 8
  %v2437 = load i64, ptr %slot461, align 8
  %v2438 = load i64, ptr %slot458, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2437, i64 %v2438) nomerge, !dbg !138
  br label %bb_rcslotdone633
bb_rcslotowner633:
  %v2439 = load i64, ptr %slot42, align 8
  store i64 %v2439, ptr %slot462, align 8
  %v2440 = load i64, ptr %slot462, align 8
  %v2441 = load i64, ptr %slot458, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2440, i64 %v2441) nomerge, !dbg !138
  br label %bb_rcslotdone633
bb_rcslotdone633:
  %v2442 = load i64, ptr %slot4, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %ld2444 = load i32, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2444, ptr %slot463, align 8
  %v2445 = load i32, ptr %slot463, align 8
  %cv2446 = zext i32 %v2445 to i64
  %cond2447 = icmp ne i64 %cv2446, 0
  br i1 %cond2447, label %bb_rcslotdrop642, label %bb_rcslotdone642
bb_rcslotdrop642:
  %v2448 = load i64, ptr %slot4, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  store i32 0, ptr %p2449, align 4, !alias.scope !3, !noalias !4
  %v2450 = load i64, ptr %slot26, align 8
  store i64 %v2450, ptr %slot464, align 8
  %v2451 = load i64, ptr %slot5, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  %ld2453 = load i32, ptr %p2452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2453, ptr %slot465, align 8
  %v2454 = load i32, ptr %slot465, align 8
  %op2455 = and i32 %v2454, 28
  store i32 %op2455, ptr %slot466, align 8
  %v2456 = load i32, ptr %slot466, align 8
  %cv2457 = zext i32 %v2456 to i64
  %cond2458 = icmp ne i64 %cv2457, 0
  br i1 %cond2458, label %bb_rcslotrole642, label %bb_rcslotowner642
bb_rcslotrole642:
  %v2459 = load i64, ptr %slot42, align 8
  store i64 %v2459, ptr %slot467, align 8
  %v2460 = load i64, ptr %slot467, align 8
  %v2461 = load i64, ptr %slot464, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2460, i64 %v2461) nomerge, !dbg !138
  br label %bb_rcslotdone642
bb_rcslotowner642:
  %v2462 = load i64, ptr %slot42, align 8
  store i64 %v2462, ptr %slot468, align 8
  %v2463 = load i64, ptr %slot468, align 8
  %v2464 = load i64, ptr %slot464, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2463, i64 %v2464) nomerge, !dbg !138
  br label %bb_rcslotdone642
bb_rcslotdone642:
  %v2465 = load i64, ptr %slot452, align 8
  ret i64 %v2465
bb_i34:
  br label %bb_i4
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8
@myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1a58e33e63dbac4b89202d66010d9cb688e1b15f0c09dc7f3c9b36ac8ba482e5(i64, i64, i64, i64, i64)
declare void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow(ptr sret([32 x i8]) align 8, i64, i64)
declare void @myl_f_e4b0bf9563972641903c91a76184ac78f1f83b05bb4beab9462ad6bdca4a1ea9(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_loan(i64, i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)
declare void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64, i64)
declare void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d", linkageName: "myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5409463488446941288, i64 0, !"myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!118 = !DILocation(line: 4, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!120 = !DILocation(line: 6, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!122 = !DILocation(line: 7, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!124 = !DILocation(line: 9, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!130 = !DILocation(line: 23, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!134 = !DILocation(line: 26, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!136 = !DILocation(line: 29, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!138 = !DILocation(line: 34, column: 0, scope: !139)
