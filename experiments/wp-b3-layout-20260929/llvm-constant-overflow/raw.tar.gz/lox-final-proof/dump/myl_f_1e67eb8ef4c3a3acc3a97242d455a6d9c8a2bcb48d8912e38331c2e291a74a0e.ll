target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v75 = load i64, ptr %slot1, align 8
  %op76 = add i64 %v75, 32
  store i64 %op76, ptr %slot4, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot5, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot6, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot7, align 8
  %mem83 = alloca i8, i64 16, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot8, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot9, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot10, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot11, align 8
  %mem91 = alloca i8, i64 16, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot12, align 8
  %v93 = load i64, ptr %slot7, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 0, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot2, align 8
  %v96 = load i64, ptr %slot5, align 8
  %p97 = inttoptr i64 %v96 to ptr
  store i64 %v95, ptr %p97, align 8, !alias.scope !3, !noalias !4
  %v98 = load i64, ptr %slot3, align 8
  %v99 = load i64, ptr %slot6, align 8
  %p100 = inttoptr i64 %v99 to ptr
  store i64 %v98, ptr %p100, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v101 = load i64, ptr %slot6, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld103, ptr %slot13, align 8
  %v104 = load i64, ptr %slot13, align 8
  %v105 = load i64, ptr %slot10, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 %v104, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot10, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot14, align 8
  %v110 = load i64, ptr %slot14, align 8
  %v111 = load i64, ptr %slot8, align 8
  %p112 = inttoptr i64 %v110 to ptr
  %p113 = inttoptr i64 %v111 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p113, ptr %p112, i64 16, i1 false), !alias.scope !10000000
  %v114 = load i64, ptr %slot5, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld116, ptr %slot15, align 8
  %v117 = load i64, ptr %slot15, align 8
  %v118 = load i64, ptr %slot10, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot10, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot16, align 8
  %v123 = load i64, ptr %slot16, align 8
  %op124 = add i64 %v123, 120
  store i64 %op124, ptr %slot17, align 8
  %v125 = load i64, ptr %slot17, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !4, !noalias !3
  store i64 %ld127, ptr %slot18, align 8
  %v128 = load i64, ptr %slot18, align 8
  %v129 = load i64, ptr %slot10, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot10, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld133, ptr %slot19, align 8
  %v134 = load i64, ptr %slot5, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot20, align 8
  %v137 = load i64, ptr %slot20, align 8
  %op138 = add i64 %v137, 120
  store i64 %op138, ptr %slot21, align 8
  store i64 0, ptr %slot22, align 8
  %v139 = load i64, ptr %slot21, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !4, !noalias !3
  store i64 %ld141, ptr %slot23, align 8
  %v142 = load i64, ptr %slot23, align 8
  %cmp143 = icmp ne i64 %v142, 0
  %cv144 = zext i1 %cmp143 to i32
  store i32 %cv144, ptr %slot24, align 8
  %v145 = load i32, ptr %slot24, align 8
  %cv146 = zext i32 %v145 to i64
  %cond147 = icmp ne i64 %cv146, 0
  br i1 %cond147, label %bb_rcguniquenn58, label %bb_rcgunique58
bb_rcguniquenn58:
  %v148 = load i64, ptr %slot23, align 8
  %op149 = sub i64 %v148, 16
  store i64 %op149, ptr %slot25, align 8
  %v150 = load i64, ptr %slot23, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %rgep152 = getelementptr i8, ptr %p151, i64 -16
  %ld153 = load i64, ptr %rgep152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld153, ptr %slot26, align 8
  %v154 = load i64, ptr %slot26, align 8
  %op155 = and i64 %v154, 6917529027641081858
  store i64 %op155, ptr %slot27, align 8
  %v156 = load i64, ptr %slot27, align 8
  %cmp157 = icmp ne i64 %v156, 0
  %cv158 = zext i1 %cmp157 to i32
  store i32 %cv158, ptr %slot28, align 8
  %v159 = load i32, ptr %slot28, align 8
  %cv160 = zext i32 %v159 to i64
  %cond161 = icmp ne i64 %cv160, 0
  br i1 %cond161, label %bb_rcguniqueslow58, label %bb_rcguniquecount58
bb_rcguniquecount58:
  %v162 = load i64, ptr %slot23, align 8
  %op163 = sub i64 %v162, 32
  store i64 %op163, ptr %slot29, align 8
  %v164 = load i64, ptr %slot23, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %rgep166 = getelementptr i8, ptr %p165, i64 -32
  %ld167 = load i64, ptr %rgep166, align 8, !alias.scope !9, !noalias !10
  store i64 %ld167, ptr %slot30, align 8
  %v168 = load i64, ptr %slot30, align 8
  %cmp169 = icmp ult i64 %v168, 2
  %cv170 = zext i1 %cmp169 to i32
  store i32 %cv170, ptr %slot31, align 8
  %v171 = load i32, ptr %slot31, align 8
  %cv172 = zext i32 %v171 to i64
  %cond173 = icmp ne i64 %cv172, 0
  br i1 %cond173, label %bb_rcgunique58, label %bb_rcguniqueslow58
bb_rcguniqueslow58:
  %v174 = load i64, ptr %slot1, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %p176 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v177 = load i64, ptr %slot21, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %v179 = load i64, ptr %slot22, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %call181 = call i32 @myl_qbe_rc_unique_field(ptr %p175, ptr %p176, ptr %p178, ptr %p180) nomerge, !dbg !110
  store i32 %call181, ptr %slot32, align 8
  %v182 = load i32, ptr %slot32, align 8
  %cv183 = zext i32 %v182 to i64
  %cond184 = icmp ne i64 %cv183, 0
  br i1 %cond184, label %bb_rcunique68, label %bb_failure
bb_rcunique68:
  br label %bb_rcgunique58
bb_rcgunique58:
  %v185 = load i64, ptr %slot21, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !4, !noalias !3
  store i64 %ld187, ptr %slot33, align 8
  %v188 = load i64, ptr %slot33, align 8
  %v189 = load i64, ptr %slot10, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot10, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot34, align 8
  %v194 = load i64, ptr %slot34, align 8
  %v195 = load i64, ptr %slot7, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot5, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot35, align 8
  %v200 = load i64, ptr %slot35, align 8
  %v201 = load i64, ptr %slot10, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot10, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot36, align 8
  %v206 = load i64, ptr %slot36, align 8
  %op207 = add i64 %v206, 128
  store i64 %op207, ptr %slot37, align 8
  %v208 = load i64, ptr %slot37, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !4, !noalias !3
  store i64 %ld210, ptr %slot38, align 8
  %v211 = load i64, ptr %slot38, align 8
  %v212 = load i64, ptr %slot10, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot11, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i64 1, ptr %p215, align 8, !alias.scope !3, !noalias !4
  %v216 = load i64, ptr %slot11, align 8
  %p217 = inttoptr i64 %v216 to ptr
  %ld218 = load i64, ptr %p217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld218, ptr %slot39, align 8
  %v219 = load i64, ptr %slot10, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot40, align 8
  %v222 = load i64, ptr %slot40, align 8
  %v223 = load i64, ptr %slot39, align 8
  %ovpair225 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v222, i64 %v223)
  %op224 = extractvalue { i64, i1 } %ovpair225, 0
  %ov226 = extractvalue { i64, i1 } %ovpair225, 1
  store i64 %op224, ptr %slot41, align 8
  %cv227 = zext i1 %ov226 to i64
  store i64 %cv227, ptr %slot42, align 8
  %v228 = load i64, ptr %slot42, align 8
  %cond229 = icmp ne i64 %v228, 0
  br i1 %cond229, label %bb_overflow86, label %bb_checked86
bb_overflow86:
  %v230 = load i64, ptr %slot1, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %v232 = load i64, ptr %slot40, align 8
  %v233 = load i64, ptr %slot39, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p231, i64 1, i64 %v232, i64 %v233, i64 64) nomerge, !dbg !112
  unreachable
bb_checked86:
  %v234 = load i64, ptr %slot41, align 8
  %v235 = load i64, ptr %slot10, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot10, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot43, align 8
  %v240 = load i64, ptr %slot43, align 8
  %v241 = load i64, ptr %slot9, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot9, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot44, align 8
  %v246 = load i64, ptr %slot44, align 8
  %v247 = load i64, ptr %slot10, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot11, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 0, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot11, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot45, align 8
  %v254 = load i64, ptr %slot10, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot46, align 8
  %v257 = load i64, ptr %slot46, align 8
  %v258 = load i64, ptr %slot45, align 8
  %cmp259 = icmp slt i64 %v257, %v258
  %cv260 = zext i1 %cmp259 to i64
  store i64 %cv260, ptr %slot47, align 8
  %v261 = load i64, ptr %slot47, align 8
  %v262 = load i64, ptr %slot10, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot10, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot48, align 8
  %v267 = load i64, ptr %slot48, align 8
  %cond268 = icmp ne i64 %v267, 0
  br i1 %cond268, label %bb_next94, label %bb_i19
bb_next94:
  %v269 = load i64, ptr %slot7, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot49, align 8
  %v272 = load i64, ptr %slot49, align 8
  %op273 = add i64 %v272, 0
  store i64 %op273, ptr %slot50, align 8
  %v274 = load i64, ptr %slot50, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !6, !noalias !7
  store i64 %ld276, ptr %slot51, align 8
  %v277 = load i64, ptr %slot51, align 8
  %v278 = load i64, ptr %slot10, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot10, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot52, align 8
  %v283 = load i64, ptr %slot52, align 8
  %cmp284 = icmp ugt i64 %v283, 9223372036854775807
  %cv285 = zext i1 %cmp284 to i64
  store i64 %cv285, ptr %slot53, align 8
  %v286 = load i64, ptr %slot53, align 8
  %cond287 = icmp ne i64 %v286, 0
  br i1 %cond287, label %bb_cast_overflow99, label %bb_cast_ok99
bb_cast_overflow99:
  %v288 = load i64, ptr %slot1, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %v290 = load i64, ptr %slot52, align 8
  call void @myl_qbe_fail_cast(ptr %p289, i64 %v290, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok99:
  %v291 = load i64, ptr %slot52, align 8
  %v292 = load i64, ptr %slot10, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot9, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %ld296 = load i64, ptr %p295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld296, ptr %slot54, align 8
  %v297 = load i64, ptr %slot54, align 8
  %v298 = load i64, ptr %slot11, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 %v297, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot11, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot55, align 8
  %v303 = load i64, ptr %slot10, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot56, align 8
  %v306 = load i64, ptr %slot56, align 8
  %v307 = load i64, ptr %slot55, align 8
  %ovpair309 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v306, i64 %v307)
  %op308 = extractvalue { i64, i1 } %ovpair309, 0
  %ov310 = extractvalue { i64, i1 } %ovpair309, 1
  store i64 %op308, ptr %slot57, align 8
  %v311 = load i64, ptr %slot56, align 8
  %v312 = load i64, ptr %slot57, align 8
  %op313 = xor i64 %v311, %v312
  store i64 %op313, ptr %slot58, align 8
  %v314 = load i64, ptr %slot55, align 8
  %v315 = load i64, ptr %slot57, align 8
  %op316 = xor i64 %v314, %v315
  store i64 %op316, ptr %slot59, align 8
  %v317 = load i64, ptr %slot58, align 8
  %v318 = load i64, ptr %slot59, align 8
  %op319 = and i64 %v317, %v318
  store i64 %op319, ptr %slot60, align 8
  %cv320 = zext i1 %ov310 to i64
  store i64 %cv320, ptr %slot61, align 8
  %v321 = load i64, ptr %slot61, align 8
  %cond322 = icmp ne i64 %v321, 0
  br i1 %cond322, label %bb_overflow103, label %bb_checked103
bb_overflow103:
  %v323 = load i64, ptr %slot1, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %v325 = load i64, ptr %slot56, align 8
  %v326 = load i64, ptr %slot55, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p324, i64 0, i64 %v325, i64 %v326, i64 64) nomerge, !dbg !116
  unreachable
bb_checked103:
  %v327 = load i64, ptr %slot57, align 8
  %v328 = load i64, ptr %slot10, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i64 %v327, ptr %p329, align 8, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot10, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld332, ptr %slot62, align 8
  %v333 = load i64, ptr %slot62, align 8
  %v334 = load i64, ptr %slot9, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 %v333, ptr %p335, align 8, !alias.scope !3, !noalias !4
  br label %bb_i19
bb_i19:
  %v336 = load i64, ptr %slot9, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot63, align 8
  %v339 = load i64, ptr %slot63, align 8
  %v340 = load i64, ptr %slot10, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i64 %v339, ptr %p341, align 8, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot8, align 8
  %v343 = load i64, ptr %slot12, align 8
  %p344 = inttoptr i64 %v342 to ptr
  %p345 = inttoptr i64 %v343 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p345, ptr %p344, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot12, align 8
  %v347 = load i64, ptr %slot11, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot7, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i64, ptr %p350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld351, ptr %slot64, align 8
  %v352 = load i64, ptr %slot11, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %ld354 = load i64, ptr %p353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld354, ptr %slot65, align 8
  %v355 = load i64, ptr %slot10, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot66, align 8
  %v358 = load i64, ptr %slot64, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !6, !noalias !7
  store i64 %ld360, ptr %slot67, align 8
  %v361 = load i64, ptr %slot66, align 8
  %v362 = load i64, ptr %slot67, align 8
  %cmp363 = icmp ult i64 %v361, %v362
  %cv364 = zext i1 %cmp363 to i64
  store i64 %cv364, ptr %slot68, align 8
  %v365 = load i64, ptr %slot68, align 8
  %cond366 = icmp ne i64 %v365, 0
  br i1 %cond366, label %bb_success116, label %bb_failed116
bb_failed116:
  %v367 = load i64, ptr %slot1, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %v369 = load i64, ptr %slot66, align 8
  %v370 = load i64, ptr %slot67, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p368, i64 %v369, i64 %v370) nomerge, !dbg !118
  unreachable
bb_success116:
  %v371 = load i64, ptr %slot64, align 8
  %op372 = add i64 %v371, 32
  store i64 %op372, ptr %slot69, align 8
  %v373 = load i64, ptr %slot69, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i64, ptr %p374, align 8, !alias.scope !6, !noalias !7
  store i64 %ld375, ptr %slot70, align 8
  %v376 = load i64, ptr %slot66, align 8
  %op377 = mul i64 %v376, 16
  store i64 %op377, ptr %slot71, align 8
  %v378 = load i64, ptr %slot70, align 8
  %v379 = load i64, ptr %slot71, align 8
  %op380 = add i64 %v378, %v379
  store i64 %op380, ptr %slot72, align 8
  %v381 = load i64, ptr %slot11, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot73, align 8
  %v384 = load i64, ptr %slot73, align 8
  %v385 = load i64, ptr %slot72, align 8
  %p386 = inttoptr i64 %v384 to ptr
  %p387 = inttoptr i64 %v385 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p387, ptr %p386, i64 16, i1 false), !alias.scope !10000001
  %v388 = load i64, ptr %slot10, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 0, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot10, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 0, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot10, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot74, align 8
  %v395 = load i64, ptr %slot74, align 8
  ret i64 %v395
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 16v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!10000001 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e", linkageName: "myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1671865086461582538, i64 0, !"myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!110 = !DILocation(line: 5, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!112 = !DILocation(line: 9, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!116 = !DILocation(line: 18, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!118 = !DILocation(line: 22, column: 0, scope: !119)
