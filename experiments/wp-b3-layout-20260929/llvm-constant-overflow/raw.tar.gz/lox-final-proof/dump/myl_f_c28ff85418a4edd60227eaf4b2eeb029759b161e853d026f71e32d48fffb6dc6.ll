target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c28ff85418a4edd60227eaf4b2eeb029759b161e853d026f71e32d48fffb6dc6(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v141 = load i64, ptr %slot1, align 8
  %op142 = add i64 %v141, 32
  store i64 %op142, ptr %slot3, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot4, align 8
  %mem145 = alloca i8, i64 16, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot5, align 8
  %mem147 = alloca i8, i64 16, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot6, align 8
  %mem149 = alloca i8, i64 8, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot7, align 8
  %mem151 = alloca i8, i64 16, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot8, align 8
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot9, align 8
  %mem155 = alloca i8, i64 8, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot10, align 8
  %mem157 = alloca i8, i64 8, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot11, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot12, align 8
  %v161 = load i64, ptr %slot7, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 0, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot9, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 0, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot2, align 8
  %v166 = load i64, ptr %slot4, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v168 = load i64, ptr %slot4, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot13, align 8
  %v171 = load i64, ptr %slot13, align 8
  %v172 = load i64, ptr %slot10, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i64 %v171, ptr %p173, align 8, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot10, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot14, align 8
  %v177 = load i64, ptr %slot14, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i32, ptr %p178, align 4, !alias.scope !4, !noalias !3
  %ext180 = zext i32 %ld179 to i64
  store i64 %ext180, ptr %slot15, align 8
  %v181 = load i64, ptr %slot15, align 8
  %cmp182 = icmp eq i64 %v181, 0
  %cv183 = zext i1 %cmp182 to i64
  store i64 %cv183, ptr %slot16, align 8
  %v184 = load i64, ptr %slot16, align 8
  %cond185 = icmp ne i64 %v184, 0
  br i1 %cond185, label %bb_rcarm9, label %bb_rcarmnext9
bb_rcarm9:
  br label %bb_i2
bb_rcarmnext9:
  %v186 = load i64, ptr %slot15, align 8
  %cmp187 = icmp eq i64 %v186, 1
  %cv188 = zext i1 %cmp187 to i64
  store i64 %cv188, ptr %slot17, align 8
  %v189 = load i64, ptr %slot17, align 8
  %cond190 = icmp ne i64 %v189, 0
  br i1 %cond190, label %bb_rcarm19, label %bb_rcarmnext19
bb_rcarm19:
  %v191 = load i64, ptr %slot14, align 8
  %op192 = add i64 %v191, 8
  store i64 %op192, ptr %slot18, align 8
  %v193 = load i64, ptr %slot18, align 8
  %v194 = load i64, ptr %slot5, align 8
  %p195 = inttoptr i64 %v193 to ptr
  %p196 = inttoptr i64 %v194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p196, ptr %p195, i64 16, i1 false), !alias.scope !10000000
  br label %bb_i4
bb_rcarmnext19:
  %v197 = load i64, ptr %slot15, align 8
  %cmp198 = icmp eq i64 %v197, 2
  %cv199 = zext i1 %cmp198 to i64
  store i64 %cv199, ptr %slot19, align 8
  %v200 = load i64, ptr %slot19, align 8
  %cond201 = icmp ne i64 %v200, 0
  br i1 %cond201, label %bb_rcarm40, label %bb_rcarmnext40
bb_rcarm40:
  br label %bb_i10
bb_rcarmnext40:
  %v202 = load i64, ptr %slot15, align 8
  %cmp203 = icmp eq i64 %v202, 3
  %cv204 = zext i1 %cmp203 to i64
  store i64 %cv204, ptr %slot20, align 8
  %v205 = load i64, ptr %slot20, align 8
  %cond206 = icmp ne i64 %v205, 0
  br i1 %cond206, label %bb_rcarm50, label %bb_rcarmnext50
bb_rcarm50:
  br label %bb_i12
bb_rcarmnext50:
  %v207 = load i64, ptr %slot15, align 8
  %cmp208 = icmp eq i64 %v207, 4
  %cv209 = zext i1 %cmp208 to i64
  store i64 %cv209, ptr %slot21, align 8
  %v210 = load i64, ptr %slot21, align 8
  %cond211 = icmp ne i64 %v210, 0
  br i1 %cond211, label %bb_rcarm60, label %bb_rcarmnext60
bb_rcarm60:
  %v212 = load i64, ptr %slot14, align 8
  %op213 = add i64 %v212, 8
  store i64 %op213, ptr %slot22, align 8
  %v214 = load i64, ptr %slot22, align 8
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v214 to ptr
  %p217 = inttoptr i64 %v215 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p217, ptr %p216, i64 16, i1 false), !alias.scope !10000000
  br label %bb_i14
bb_rcarmnext60:
  %v218 = load i64, ptr %slot15, align 8
  %cmp219 = icmp eq i64 %v218, 5
  %cv220 = zext i1 %cmp219 to i64
  store i64 %cv220, ptr %slot23, align 8
  %v221 = load i64, ptr %slot23, align 8
  %cond222 = icmp ne i64 %v221, 0
  br i1 %cond222, label %bb_rcarm81, label %bb_rcarmnext81
bb_rcarm81:
  br label %bb_i27
bb_rcarmnext81:
  %v223 = load i64, ptr %slot15, align 8
  %cmp224 = icmp eq i64 %v223, 6
  %cv225 = zext i1 %cmp224 to i64
  store i64 %cv225, ptr %slot24, align 8
  %v226 = load i64, ptr %slot24, align 8
  %cond227 = icmp ne i64 %v226, 0
  br i1 %cond227, label %bb_rcarm91, label %bb_rcarmnext91
bb_rcarm91:
  br label %bb_i29
bb_rcarmnext91:
  %v228 = load i64, ptr %slot15, align 8
  %cmp229 = icmp eq i64 %v228, 7
  %cv230 = zext i1 %cmp229 to i64
  store i64 %cv230, ptr %slot25, align 8
  %v231 = load i64, ptr %slot25, align 8
  %cond232 = icmp ne i64 %v231, 0
  br i1 %cond232, label %bb_rcarm101, label %bb_rcarmnext101
bb_rcarm101:
  br label %bb_i31
bb_rcarmnext101:
  %v233 = load i64, ptr %slot15, align 8
  %cmp234 = icmp eq i64 %v233, 8
  %cv235 = zext i1 %cmp234 to i64
  store i64 %cv235, ptr %slot26, align 8
  %v236 = load i64, ptr %slot26, align 8
  %cond237 = icmp ne i64 %v236, 0
  br i1 %cond237, label %bb_rcarm111, label %bb_rcarmnext111
bb_rcarm111:
  br label %bb_i33
bb_rcarmnext111:
  %v238 = load i64, ptr %slot15, align 8
  %cmp239 = icmp eq i64 %v238, 9
  %cv240 = zext i1 %cmp239 to i64
  store i64 %cv240, ptr %slot27, align 8
  %v241 = load i64, ptr %slot27, align 8
  %cond242 = icmp ne i64 %v241, 0
  br i1 %cond242, label %bb_rcarm121, label %bb_rcarmnext121
bb_rcarm121:
  %v243 = load i64, ptr %slot14, align 8
  %op244 = add i64 %v243, 8
  store i64 %op244, ptr %slot28, align 8
  %v245 = load i64, ptr %slot28, align 8
  %v246 = load i64, ptr %slot8, align 8
  %p247 = inttoptr i64 %v245 to ptr
  %p248 = inttoptr i64 %v246 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p248, ptr %p247, i64 16, i1 false), !alias.scope !10000000
  br label %bb_i35
bb_rcarmnext121:
  %v249 = load i64, ptr %slot15, align 8
  %cmp250 = icmp eq i64 %v249, 10
  %cv251 = zext i1 %cmp250 to i64
  store i64 %cv251, ptr %slot29, align 8
  %v252 = load i64, ptr %slot29, align 8
  %cond253 = icmp ne i64 %v252, 0
  br i1 %cond253, label %bb_rcarm142, label %bb_rcarmnext142
bb_rcarm142:
  br label %bb_i48
bb_rcarmnext142:
  br label %bb_failure
bb_i2:
  %v254 = load i64, ptr %slot10, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 0, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot10, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot30, align 8
  %v259 = load i64, ptr %slot30, align 8
  ret i64 %v259
bb_i4:
  %v260 = load i64, ptr %slot10, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 32, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot5, align 8
  %v263 = load i64, ptr %slot11, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot11, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot31, align 8
  %v268 = load i64, ptr %slot31, align 8
  %op269 = add i64 %v268, 0
  store i64 %op269, ptr %slot32, align 8
  %v270 = load i64, ptr %slot32, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot33, align 8
  %v273 = load i64, ptr %slot33, align 8
  %v274 = load i64, ptr %slot11, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 %v273, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot11, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot34, align 8
  %v279 = load i64, ptr %slot34, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !6, !noalias !7
  store i64 %ld281, ptr %slot35, align 8
  %v282 = load i64, ptr %slot35, align 8
  %v283 = load i64, ptr %slot11, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot11, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot36, align 8
  %v288 = load i64, ptr %slot10, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot37, align 8
  %v291 = load i64, ptr %slot37, align 8
  %v292 = load i64, ptr %slot36, align 8
  %ovpair294 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v291, i64 %v292)
  %op293 = extractvalue { i64, i1 } %ovpair294, 0
  %ov295 = extractvalue { i64, i1 } %ovpair294, 1
  store i64 %op293, ptr %slot38, align 8
  %v296 = load i64, ptr %slot37, align 8
  %v297 = load i64, ptr %slot38, align 8
  %op298 = xor i64 %v296, %v297
  store i64 %op298, ptr %slot39, align 8
  %v299 = load i64, ptr %slot36, align 8
  %v300 = load i64, ptr %slot38, align 8
  %op301 = xor i64 %v299, %v300
  store i64 %op301, ptr %slot40, align 8
  %v302 = load i64, ptr %slot39, align 8
  %v303 = load i64, ptr %slot40, align 8
  %op304 = and i64 %v302, %v303
  store i64 %op304, ptr %slot41, align 8
  %cv305 = zext i1 %ov295 to i64
  store i64 %cv305, ptr %slot42, align 8
  %v306 = load i64, ptr %slot42, align 8
  %cond307 = icmp ne i64 %v306, 0
  br i1 %cond307, label %bb_overflow319, label %bb_checked319
bb_overflow319:
  %v308 = load i64, ptr %slot1, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %v310 = load i64, ptr %slot37, align 8
  %v311 = load i64, ptr %slot36, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p309, i64 0, i64 %v310, i64 %v311, i64 64) nomerge, !dbg !110
  unreachable
bb_checked319:
  %v312 = load i64, ptr %slot38, align 8
  %v313 = load i64, ptr %slot10, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot10, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot43, align 8
  %v318 = load i64, ptr %slot43, align 8
  ret i64 %v318
bb_i10:
  %v319 = load i64, ptr %slot10, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 64, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot10, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot44, align 8
  %v324 = load i64, ptr %slot44, align 8
  ret i64 %v324
bb_i12:
  %v325 = load i64, ptr %slot10, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i64 32, ptr %p326, align 8, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot10, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %ld329 = load i64, ptr %p328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld329, ptr %slot45, align 8
  %v330 = load i64, ptr %slot45, align 8
  ret i64 %v330
bb_i14:
  %v331 = load i64, ptr %slot6, align 8
  %v332 = load i64, ptr %slot10, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot10, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 32, ptr %p335, align 8, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot11, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 8, ptr %p337, align 8, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot6, align 8
  %v339 = load i64, ptr %slot12, align 8
  %p340 = inttoptr i64 %v339 to ptr
  store i64 %v338, ptr %p340, align 8, !alias.scope !3, !noalias !4
  %v341 = load i64, ptr %slot12, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i64, ptr %p342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld343, ptr %slot46, align 8
  %v344 = load i64, ptr %slot46, align 8
  %op345 = add i64 %v344, 8
  store i64 %op345, ptr %slot47, align 8
  %v346 = load i64, ptr %slot47, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld348, ptr %slot48, align 8
  %v349 = load i64, ptr %slot48, align 8
  %v350 = load i64, ptr %slot12, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 %v349, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot12, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %ld354 = load i64, ptr %p353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld354, ptr %slot49, align 8
  %v355 = load i64, ptr %slot49, align 8
  %v356 = load i64, ptr %slot7, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot7, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot50, align 8
  %v361 = load i64, ptr %slot50, align 8
  %op362 = add i64 %v361, 0
  store i64 %op362, ptr %slot51, align 8
  %v363 = load i64, ptr %slot51, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !6, !noalias !7
  store i64 %ld365, ptr %slot52, align 8
  %v366 = load i64, ptr %slot52, align 8
  %v367 = load i64, ptr %slot12, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i64 %v366, ptr %p368, align 8, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot12, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot53, align 8
  %v372 = load i64, ptr %slot53, align 8
  %cmp373 = icmp ugt i64 %v372, 9223372036854775807
  %cv374 = zext i1 %cmp373 to i64
  store i64 %cv374, ptr %slot54, align 8
  %v375 = load i64, ptr %slot54, align 8
  %cond376 = icmp ne i64 %v375, 0
  br i1 %cond376, label %bb_cast_overflow684, label %bb_cast_ok684
bb_cast_overflow684:
  %v377 = load i64, ptr %slot1, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %v379 = load i64, ptr %slot53, align 8
  call void @myl_qbe_fail_cast(ptr %p378, i64 %v379, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok684:
  %v380 = load i64, ptr %slot53, align 8
  %v381 = load i64, ptr %slot12, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot55, align 8
  %v386 = load i64, ptr %slot11, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot56, align 8
  %v389 = load i64, ptr %slot56, align 8
  %v390 = load i64, ptr %slot55, align 8
  %ovpair392 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v389, i64 %v390)
  %op391 = extractvalue { i64, i1 } %ovpair392, 0
  %ov393 = extractvalue { i64, i1 } %ovpair392, 1
  store i64 %op391, ptr %slot57, align 8
  %v394 = load i64, ptr %slot56, align 8
  %op395 = and i64 %v394, 4294967295
  store i64 %op395, ptr %slot58, align 8
  %v396 = load i64, ptr %slot56, align 8
  %op397 = lshr i64 %v396, 32
  store i64 %op397, ptr %slot59, align 8
  %v398 = load i64, ptr %slot55, align 8
  %op399 = and i64 %v398, 4294967295
  store i64 %op399, ptr %slot60, align 8
  %v400 = load i64, ptr %slot55, align 8
  %op401 = lshr i64 %v400, 32
  store i64 %op401, ptr %slot61, align 8
  %v402 = load i64, ptr %slot58, align 8
  %v403 = load i64, ptr %slot60, align 8
  %op404 = mul i64 %v402, %v403
  store i64 %op404, ptr %slot62, align 8
  %v405 = load i64, ptr %slot62, align 8
  %op406 = lshr i64 %v405, 32
  store i64 %op406, ptr %slot63, align 8
  %v407 = load i64, ptr %slot59, align 8
  %v408 = load i64, ptr %slot60, align 8
  %op409 = mul i64 %v407, %v408
  store i64 %op409, ptr %slot64, align 8
  %v410 = load i64, ptr %slot64, align 8
  %v411 = load i64, ptr %slot63, align 8
  %op412 = add i64 %v410, %v411
  store i64 %op412, ptr %slot65, align 8
  %v413 = load i64, ptr %slot65, align 8
  %op414 = and i64 %v413, 4294967295
  store i64 %op414, ptr %slot66, align 8
  %v415 = load i64, ptr %slot65, align 8
  %op416 = lshr i64 %v415, 32
  store i64 %op416, ptr %slot67, align 8
  %v417 = load i64, ptr %slot58, align 8
  %v418 = load i64, ptr %slot61, align 8
  %op419 = mul i64 %v417, %v418
  store i64 %op419, ptr %slot68, align 8
  %v420 = load i64, ptr %slot68, align 8
  %v421 = load i64, ptr %slot66, align 8
  %op422 = add i64 %v420, %v421
  store i64 %op422, ptr %slot69, align 8
  %v423 = load i64, ptr %slot69, align 8
  %op424 = lshr i64 %v423, 32
  store i64 %op424, ptr %slot70, align 8
  %v425 = load i64, ptr %slot59, align 8
  %v426 = load i64, ptr %slot61, align 8
  %op427 = mul i64 %v425, %v426
  store i64 %op427, ptr %slot71, align 8
  %v428 = load i64, ptr %slot71, align 8
  %v429 = load i64, ptr %slot67, align 8
  %op430 = add i64 %v428, %v429
  store i64 %op430, ptr %slot72, align 8
  %v431 = load i64, ptr %slot72, align 8
  %v432 = load i64, ptr %slot70, align 8
  %op433 = add i64 %v431, %v432
  store i64 %op433, ptr %slot73, align 8
  %v434 = load i64, ptr %slot56, align 8
  %cmp435 = icmp slt i64 %v434, 0
  %cv436 = zext i1 %cmp435 to i64
  store i64 %cv436, ptr %slot74, align 8
  %v437 = load i64, ptr %slot55, align 8
  %cmp438 = icmp slt i64 %v437, 0
  %cv439 = zext i1 %cmp438 to i64
  store i64 %cv439, ptr %slot75, align 8
  %v440 = load i64, ptr %slot74, align 8
  %neg441 = sub i64 0, %v440
  store i64 %neg441, ptr %slot76, align 8
  %v442 = load i64, ptr %slot75, align 8
  %neg443 = sub i64 0, %v442
  store i64 %neg443, ptr %slot77, align 8
  %v444 = load i64, ptr %slot55, align 8
  %v445 = load i64, ptr %slot76, align 8
  %op446 = and i64 %v444, %v445
  store i64 %op446, ptr %slot78, align 8
  %v447 = load i64, ptr %slot56, align 8
  %v448 = load i64, ptr %slot77, align 8
  %op449 = and i64 %v447, %v448
  store i64 %op449, ptr %slot79, align 8
  %v450 = load i64, ptr %slot73, align 8
  %v451 = load i64, ptr %slot78, align 8
  %op452 = sub i64 %v450, %v451
  store i64 %op452, ptr %slot80, align 8
  %v453 = load i64, ptr %slot80, align 8
  %v454 = load i64, ptr %slot79, align 8
  %op455 = sub i64 %v453, %v454
  store i64 %op455, ptr %slot80, align 8
  %v456 = load i64, ptr %slot57, align 8
  %op457 = ashr i64 %v456, 63
  store i64 %op457, ptr %slot81, align 8
  %cv458 = zext i1 %ov393 to i64
  store i64 %cv458, ptr %slot82, align 8
  %v459 = load i64, ptr %slot82, align 8
  %cond460 = icmp ne i64 %v459, 0
  br i1 %cond460, label %bb_overflow687, label %bb_checked687
bb_overflow687:
  %v461 = load i64, ptr %slot1, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %v463 = load i64, ptr %slot56, align 8
  %v464 = load i64, ptr %slot55, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p462, i64 2, i64 %v463, i64 %v464, i64 64) nomerge, !dbg !114
  unreachable
bb_checked687:
  %v465 = load i64, ptr %slot57, align 8
  %v466 = load i64, ptr %slot11, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i64 %v465, ptr %p467, align 8, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot11, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld470, ptr %slot83, align 8
  %v471 = load i64, ptr %slot10, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot84, align 8
  %v474 = load i64, ptr %slot84, align 8
  %v475 = load i64, ptr %slot83, align 8
  %ovpair477 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v474, i64 %v475)
  %op476 = extractvalue { i64, i1 } %ovpair477, 0
  %ov478 = extractvalue { i64, i1 } %ovpair477, 1
  store i64 %op476, ptr %slot85, align 8
  %v479 = load i64, ptr %slot84, align 8
  %v480 = load i64, ptr %slot85, align 8
  %op481 = xor i64 %v479, %v480
  store i64 %op481, ptr %slot86, align 8
  %v482 = load i64, ptr %slot83, align 8
  %v483 = load i64, ptr %slot85, align 8
  %op484 = xor i64 %v482, %v483
  store i64 %op484, ptr %slot87, align 8
  %v485 = load i64, ptr %slot86, align 8
  %v486 = load i64, ptr %slot87, align 8
  %op487 = and i64 %v485, %v486
  store i64 %op487, ptr %slot88, align 8
  %cv488 = zext i1 %ov478 to i64
  store i64 %cv488, ptr %slot89, align 8
  %v489 = load i64, ptr %slot89, align 8
  %cond490 = icmp ne i64 %v489, 0
  br i1 %cond490, label %bb_overflow715, label %bb_checked715
bb_overflow715:
  %v491 = load i64, ptr %slot1, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %v493 = load i64, ptr %slot84, align 8
  %v494 = load i64, ptr %slot83, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p492, i64 0, i64 %v493, i64 %v494, i64 64) nomerge, !dbg !116
  unreachable
bb_checked715:
  %v495 = load i64, ptr %slot85, align 8
  %v496 = load i64, ptr %slot10, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 %v495, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot10, align 8
  %p499 = inttoptr i64 %v498 to ptr
  %ld500 = load i64, ptr %p499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld500, ptr %slot90, align 8
  %v501 = load i64, ptr %slot90, align 8
  ret i64 %v501
bb_i27:
  %v502 = load i64, ptr %slot10, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 32, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot10, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot91, align 8
  %v507 = load i64, ptr %slot91, align 8
  ret i64 %v507
bb_i29:
  %v508 = load i64, ptr %slot10, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 48, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot10, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot92, align 8
  %v513 = load i64, ptr %slot92, align 8
  ret i64 %v513
bb_i31:
  %v514 = load i64, ptr %slot10, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 48, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot10, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot93, align 8
  %v519 = load i64, ptr %slot93, align 8
  ret i64 %v519
bb_i33:
  %v520 = load i64, ptr %slot10, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 32, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot10, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld524, ptr %slot94, align 8
  %v525 = load i64, ptr %slot94, align 8
  ret i64 %v525
bb_i35:
  %v526 = load i64, ptr %slot8, align 8
  %v527 = load i64, ptr %slot10, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i64 %v526, ptr %p528, align 8, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot10, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i64 32, ptr %p530, align 8, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot11, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i64 16, ptr %p532, align 8, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot8, align 8
  %v534 = load i64, ptr %slot12, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot12, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot95, align 8
  %v539 = load i64, ptr %slot95, align 8
  %op540 = add i64 %v539, 8
  store i64 %op540, ptr %slot96, align 8
  %v541 = load i64, ptr %slot96, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot97, align 8
  %v544 = load i64, ptr %slot97, align 8
  %v545 = load i64, ptr %slot12, align 8
  %p546 = inttoptr i64 %v545 to ptr
  store i64 %v544, ptr %p546, align 8, !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot12, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld549, ptr %slot98, align 8
  %v550 = load i64, ptr %slot98, align 8
  %v551 = load i64, ptr %slot9, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 %v550, ptr %p552, align 8, !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot9, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot99, align 8
  %v556 = load i64, ptr %slot99, align 8
  %op557 = add i64 %v556, 0
  store i64 %op557, ptr %slot100, align 8
  %v558 = load i64, ptr %slot100, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %ld560 = load i64, ptr %p559, align 8, !alias.scope !6, !noalias !7
  store i64 %ld560, ptr %slot101, align 8
  %v561 = load i64, ptr %slot101, align 8
  %v562 = load i64, ptr %slot12, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot12, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot102, align 8
  %v567 = load i64, ptr %slot102, align 8
  %cmp568 = icmp ugt i64 %v567, 9223372036854775807
  %cv569 = zext i1 %cmp568 to i64
  store i64 %cv569, ptr %slot103, align 8
  %v570 = load i64, ptr %slot103, align 8
  %cond571 = icmp ne i64 %v570, 0
  br i1 %cond571, label %bb_cast_overflow1308, label %bb_cast_ok1308
bb_cast_overflow1308:
  %v572 = load i64, ptr %slot1, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %v574 = load i64, ptr %slot102, align 8
  call void @myl_qbe_fail_cast(ptr %p573, i64 %v574, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok1308:
  %v575 = load i64, ptr %slot102, align 8
  %v576 = load i64, ptr %slot12, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i64 %v575, ptr %p577, align 8, !alias.scope !3, !noalias !4
  %v578 = load i64, ptr %slot12, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i64, ptr %p579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld580, ptr %slot104, align 8
  %v581 = load i64, ptr %slot11, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %ld583 = load i64, ptr %p582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld583, ptr %slot105, align 8
  %v584 = load i64, ptr %slot105, align 8
  %v585 = load i64, ptr %slot104, align 8
  %ovpair587 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v584, i64 %v585)
  %op586 = extractvalue { i64, i1 } %ovpair587, 0
  %ov588 = extractvalue { i64, i1 } %ovpair587, 1
  store i64 %op586, ptr %slot106, align 8
  %v589 = load i64, ptr %slot105, align 8
  %op590 = and i64 %v589, 4294967295
  store i64 %op590, ptr %slot107, align 8
  %v591 = load i64, ptr %slot105, align 8
  %op592 = lshr i64 %v591, 32
  store i64 %op592, ptr %slot108, align 8
  %v593 = load i64, ptr %slot104, align 8
  %op594 = and i64 %v593, 4294967295
  store i64 %op594, ptr %slot109, align 8
  %v595 = load i64, ptr %slot104, align 8
  %op596 = lshr i64 %v595, 32
  store i64 %op596, ptr %slot110, align 8
  %v597 = load i64, ptr %slot107, align 8
  %v598 = load i64, ptr %slot109, align 8
  %op599 = mul i64 %v597, %v598
  store i64 %op599, ptr %slot111, align 8
  %v600 = load i64, ptr %slot111, align 8
  %op601 = lshr i64 %v600, 32
  store i64 %op601, ptr %slot112, align 8
  %v602 = load i64, ptr %slot108, align 8
  %v603 = load i64, ptr %slot109, align 8
  %op604 = mul i64 %v602, %v603
  store i64 %op604, ptr %slot113, align 8
  %v605 = load i64, ptr %slot113, align 8
  %v606 = load i64, ptr %slot112, align 8
  %op607 = add i64 %v605, %v606
  store i64 %op607, ptr %slot114, align 8
  %v608 = load i64, ptr %slot114, align 8
  %op609 = and i64 %v608, 4294967295
  store i64 %op609, ptr %slot115, align 8
  %v610 = load i64, ptr %slot114, align 8
  %op611 = lshr i64 %v610, 32
  store i64 %op611, ptr %slot116, align 8
  %v612 = load i64, ptr %slot107, align 8
  %v613 = load i64, ptr %slot110, align 8
  %op614 = mul i64 %v612, %v613
  store i64 %op614, ptr %slot117, align 8
  %v615 = load i64, ptr %slot117, align 8
  %v616 = load i64, ptr %slot115, align 8
  %op617 = add i64 %v615, %v616
  store i64 %op617, ptr %slot118, align 8
  %v618 = load i64, ptr %slot118, align 8
  %op619 = lshr i64 %v618, 32
  store i64 %op619, ptr %slot119, align 8
  %v620 = load i64, ptr %slot108, align 8
  %v621 = load i64, ptr %slot110, align 8
  %op622 = mul i64 %v620, %v621
  store i64 %op622, ptr %slot120, align 8
  %v623 = load i64, ptr %slot120, align 8
  %v624 = load i64, ptr %slot116, align 8
  %op625 = add i64 %v623, %v624
  store i64 %op625, ptr %slot121, align 8
  %v626 = load i64, ptr %slot121, align 8
  %v627 = load i64, ptr %slot119, align 8
  %op628 = add i64 %v626, %v627
  store i64 %op628, ptr %slot122, align 8
  %v629 = load i64, ptr %slot105, align 8
  %cmp630 = icmp slt i64 %v629, 0
  %cv631 = zext i1 %cmp630 to i64
  store i64 %cv631, ptr %slot123, align 8
  %v632 = load i64, ptr %slot104, align 8
  %cmp633 = icmp slt i64 %v632, 0
  %cv634 = zext i1 %cmp633 to i64
  store i64 %cv634, ptr %slot124, align 8
  %v635 = load i64, ptr %slot123, align 8
  %neg636 = sub i64 0, %v635
  store i64 %neg636, ptr %slot125, align 8
  %v637 = load i64, ptr %slot124, align 8
  %neg638 = sub i64 0, %v637
  store i64 %neg638, ptr %slot126, align 8
  %v639 = load i64, ptr %slot104, align 8
  %v640 = load i64, ptr %slot125, align 8
  %op641 = and i64 %v639, %v640
  store i64 %op641, ptr %slot127, align 8
  %v642 = load i64, ptr %slot105, align 8
  %v643 = load i64, ptr %slot126, align 8
  %op644 = and i64 %v642, %v643
  store i64 %op644, ptr %slot128, align 8
  %v645 = load i64, ptr %slot122, align 8
  %v646 = load i64, ptr %slot127, align 8
  %op647 = sub i64 %v645, %v646
  store i64 %op647, ptr %slot129, align 8
  %v648 = load i64, ptr %slot129, align 8
  %v649 = load i64, ptr %slot128, align 8
  %op650 = sub i64 %v648, %v649
  store i64 %op650, ptr %slot129, align 8
  %v651 = load i64, ptr %slot106, align 8
  %op652 = ashr i64 %v651, 63
  store i64 %op652, ptr %slot130, align 8
  %cv653 = zext i1 %ov588 to i64
  store i64 %cv653, ptr %slot131, align 8
  %v654 = load i64, ptr %slot131, align 8
  %cond655 = icmp ne i64 %v654, 0
  br i1 %cond655, label %bb_overflow1311, label %bb_checked1311
bb_overflow1311:
  %v656 = load i64, ptr %slot1, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %v658 = load i64, ptr %slot105, align 8
  %v659 = load i64, ptr %slot104, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p657, i64 2, i64 %v658, i64 %v659, i64 64) nomerge, !dbg !120
  unreachable
bb_checked1311:
  %v660 = load i64, ptr %slot106, align 8
  %v661 = load i64, ptr %slot11, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot11, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot132, align 8
  %v666 = load i64, ptr %slot10, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %ld668 = load i64, ptr %p667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld668, ptr %slot133, align 8
  %v669 = load i64, ptr %slot133, align 8
  %v670 = load i64, ptr %slot132, align 8
  %ovpair672 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v669, i64 %v670)
  %op671 = extractvalue { i64, i1 } %ovpair672, 0
  %ov673 = extractvalue { i64, i1 } %ovpair672, 1
  store i64 %op671, ptr %slot134, align 8
  %v674 = load i64, ptr %slot133, align 8
  %v675 = load i64, ptr %slot134, align 8
  %op676 = xor i64 %v674, %v675
  store i64 %op676, ptr %slot135, align 8
  %v677 = load i64, ptr %slot132, align 8
  %v678 = load i64, ptr %slot134, align 8
  %op679 = xor i64 %v677, %v678
  store i64 %op679, ptr %slot136, align 8
  %v680 = load i64, ptr %slot135, align 8
  %v681 = load i64, ptr %slot136, align 8
  %op682 = and i64 %v680, %v681
  store i64 %op682, ptr %slot137, align 8
  %cv683 = zext i1 %ov673 to i64
  store i64 %cv683, ptr %slot138, align 8
  %v684 = load i64, ptr %slot138, align 8
  %cond685 = icmp ne i64 %v684, 0
  br i1 %cond685, label %bb_overflow1339, label %bb_checked1339
bb_overflow1339:
  %v686 = load i64, ptr %slot1, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %v688 = load i64, ptr %slot133, align 8
  %v689 = load i64, ptr %slot132, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p687, i64 0, i64 %v688, i64 %v689, i64 64) nomerge, !dbg !122
  unreachable
bb_checked1339:
  %v690 = load i64, ptr %slot134, align 8
  %v691 = load i64, ptr %slot10, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot10, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %ld695 = load i64, ptr %p694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld695, ptr %slot139, align 8
  %v696 = load i64, ptr %slot139, align 8
  ret i64 %v696
bb_i48:
  %v697 = load i64, ptr %slot10, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i64 48, ptr %p698, align 8, !alias.scope !3, !noalias !4
  %v699 = load i64, ptr %slot10, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %ld701 = load i64, ptr %p700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld701, ptr %slot140, align 8
  %v702 = load i64, ptr %slot140, align 8
  ret i64 %v702
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c28ff85418a4edd60227eaf4b2eeb029759b161e853d026f71e32d48fffb6dc6", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c28ff85418a4edd60227eaf4b2eeb029759b161e853d026f71e32d48fffb6dc6", linkageName: "myl_f_c28ff85418a4edd60227eaf4b2eeb029759b161e853d026f71e32d48fffb6dc6", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7250605391314816360, i64 0, !"myl_f_c28ff85418a4edd60227eaf4b2eeb029759b161e853d026f71e32d48fffb6dc6"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!110 = !DILocation(line: 9, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!112 = !DILocation(line: 24, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!114 = !DILocation(line: 25, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!116 = !DILocation(line: 26, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!118 = !DILocation(line: 45, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!120 = !DILocation(line: 46, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!122 = !DILocation(line: 47, column: 0, scope: !123)
