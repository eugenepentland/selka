target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i32, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v51 = load i64, ptr %slot1, align 8
  %op52 = add i64 %v51, 32
  store i64 %op52, ptr %slot4, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot5, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot6, align 8
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot7, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot8, align 8
  %mem61 = alloca i8, i64 8, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot9, align 8
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot10, align 8
  %v65 = load i64, ptr %slot7, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 0, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot8, align 8
  %p68 = inttoptr i64 %v67 to ptr
  store i64 0, ptr %p68, align 8, !alias.scope !3, !noalias !4
  %v69 = load i64, ptr %slot2, align 8
  %v70 = load i64, ptr %slot5, align 8
  %p71 = inttoptr i64 %v70 to ptr
  store i64 %v69, ptr %p71, align 8, !alias.scope !3, !noalias !4
  %v72 = load i64, ptr %slot3, align 8
  %v73 = load i64, ptr %slot6, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot1, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %call77 = call ptr @myl_qbe_heap(ptr %p76) nomerge, !dbg !110
  %calladdr78 = ptrtoint ptr %call77 to i64
  store i64 %calladdr78, ptr %slot11, align 8
  br label %bb_i0
bb_i0:
  %v79 = load i64, ptr %slot5, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ld81 = load i64, ptr %p80, align 8, !alias.scope !3, !noalias !4
  store i64 %ld81, ptr %slot12, align 8
  %v82 = load i64, ptr %slot12, align 8
  %v83 = load i64, ptr %slot9, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 %v82, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot9, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot13, align 8
  %v88 = load i64, ptr %slot13, align 8
  %op89 = add i64 %v88, 16
  store i64 %op89, ptr %slot14, align 8
  %v90 = load i64, ptr %slot14, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !4, !noalias !3
  store i64 %ld92, ptr %slot15, align 8
  %v93 = load i64, ptr %slot15, align 8
  %v94 = load i64, ptr %slot9, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot9, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot16, align 8
  %v99 = load i64, ptr %slot5, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %ld101 = load i64, ptr %p100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld101, ptr %slot17, align 8
  %v102 = load i64, ptr %slot17, align 8
  %op103 = add i64 %v102, 16
  store i64 %op103, ptr %slot18, align 8
  store i64 0, ptr %slot19, align 8
  %v104 = load i64, ptr %slot18, align 8
  %p105 = inttoptr i64 %v104 to ptr
  %ld106 = load i64, ptr %p105, align 8, !alias.scope !4, !noalias !3
  store i64 %ld106, ptr %slot20, align 8
  %v107 = load i64, ptr %slot20, align 8
  %cmp108 = icmp ne i64 %v107, 0
  %cv109 = zext i1 %cmp108 to i32
  store i32 %cv109, ptr %slot21, align 8
  %v110 = load i32, ptr %slot21, align 8
  %cv111 = zext i32 %v110 to i64
  %cond112 = icmp ne i64 %cv111, 0
  br i1 %cond112, label %bb_rcguniquenn57, label %bb_rcgunique57
bb_rcguniquenn57:
  %v113 = load i64, ptr %slot20, align 8
  %op114 = sub i64 %v113, 16
  store i64 %op114, ptr %slot22, align 8
  %v115 = load i64, ptr %slot20, align 8
  %p116 = inttoptr i64 %v115 to ptr
  %rgep117 = getelementptr i8, ptr %p116, i64 -16
  %ld118 = load i64, ptr %rgep117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld118, ptr %slot23, align 8
  %v119 = load i64, ptr %slot23, align 8
  %op120 = and i64 %v119, 6917529027641081858
  store i64 %op120, ptr %slot24, align 8
  %v121 = load i64, ptr %slot24, align 8
  %cmp122 = icmp ne i64 %v121, 0
  %cv123 = zext i1 %cmp122 to i32
  store i32 %cv123, ptr %slot25, align 8
  %v124 = load i32, ptr %slot25, align 8
  %cv125 = zext i32 %v124 to i64
  %cond126 = icmp ne i64 %cv125, 0
  br i1 %cond126, label %bb_rcguniqueslow57, label %bb_rcguniquecount57
bb_rcguniquecount57:
  %v127 = load i64, ptr %slot20, align 8
  %op128 = sub i64 %v127, 32
  store i64 %op128, ptr %slot26, align 8
  %v129 = load i64, ptr %slot20, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %rgep131 = getelementptr i8, ptr %p130, i64 -32
  %ld132 = load i64, ptr %rgep131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld132, ptr %slot27, align 8
  %v133 = load i64, ptr %slot27, align 8
  %cmp134 = icmp ult i64 %v133, 2
  %cv135 = zext i1 %cmp134 to i32
  store i32 %cv135, ptr %slot28, align 8
  %v136 = load i32, ptr %slot28, align 8
  %cv137 = zext i32 %v136 to i64
  %cond138 = icmp ne i64 %cv137, 0
  br i1 %cond138, label %bb_rcgunique57, label %bb_rcguniqueslow57
bb_rcguniqueslow57:
  %v139 = load i64, ptr %slot1, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %p141 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v142 = load i64, ptr %slot18, align 8
  %p143 = inttoptr i64 %v142 to ptr
  %v144 = load i64, ptr %slot19, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %call146 = call i32 @myl_qbe_rc_unique_field(ptr %p140, ptr %p141, ptr %p143, ptr %p145) nomerge, !dbg !112
  store i32 %call146, ptr %slot29, align 8
  %v147 = load i32, ptr %slot29, align 8
  %cv148 = zext i32 %v147 to i64
  %cond149 = icmp ne i64 %cv148, 0
  br i1 %cond149, label %bb_rcunique67, label %bb_failure
bb_rcunique67:
  br label %bb_rcgunique57
bb_rcgunique57:
  %v150 = load i64, ptr %slot18, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !4, !noalias !3
  store i64 %ld152, ptr %slot30, align 8
  %v153 = load i64, ptr %slot30, align 8
  %v154 = load i64, ptr %slot9, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 %v153, ptr %p155, align 8, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot9, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot31, align 8
  %v159 = load i64, ptr %slot31, align 8
  %v160 = load i64, ptr %slot7, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot6, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot32, align 8
  %v165 = load i64, ptr %slot32, align 8
  %v166 = load i64, ptr %slot9, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot7, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot33, align 8
  %v171 = load i64, ptr %slot9, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot34, align 8
  %v174 = load i64, ptr %slot11, align 8
  %v175 = load i64, ptr %slot33, align 8
  %v176 = load i64, ptr %slot34, align 8
  %call177 = call i32 @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47_rcg_list_append(i64 %v174, i64 %v175, i64 %v176) nomerge, !dbg !114
  store i32 %call177, ptr %slot35, align 8
  %v178 = load i32, ptr %slot35, align 8
  %cv179 = zext i32 %v178 to i64
  %cond180 = icmp ne i64 %cv179, 0
  br i1 %cond180, label %bb_success74, label %bb_failed74
bb_failed74:
  %v181 = load i64, ptr %slot1, align 8
  %p182 = inttoptr i64 %v181 to ptr
  call void @myl_qbe_fail_allocation(ptr %p182) nomerge, !dbg !114
  unreachable
bb_success74:
  %v183 = load i64, ptr %slot9, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 0, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot5, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld187, ptr %slot36, align 8
  %v188 = load i64, ptr %slot36, align 8
  %v189 = load i64, ptr %slot9, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot9, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot37, align 8
  %v194 = load i64, ptr %slot37, align 8
  %op195 = add i64 %v194, 16
  store i64 %op195, ptr %slot38, align 8
  %v196 = load i64, ptr %slot38, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !4, !noalias !3
  store i64 %ld198, ptr %slot39, align 8
  %v199 = load i64, ptr %slot39, align 8
  %v200 = load i64, ptr %slot9, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot9, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot40, align 8
  %v205 = load i64, ptr %slot40, align 8
  %v206 = load i64, ptr %slot8, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot8, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot41, align 8
  %v211 = load i64, ptr %slot41, align 8
  %op212 = add i64 %v211, 0
  store i64 %op212, ptr %slot42, align 8
  %v213 = load i64, ptr %slot42, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !6, !noalias !7
  store i64 %ld215, ptr %slot43, align 8
  %v216 = load i64, ptr %slot43, align 8
  %v217 = load i64, ptr %slot9, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot9, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot44, align 8
  %v222 = load i64, ptr %slot44, align 8
  %cmp223 = icmp ugt i64 %v222, 9223372036854775807
  %cv224 = zext i1 %cmp223 to i64
  store i64 %cv224, ptr %slot45, align 8
  %v225 = load i64, ptr %slot45, align 8
  %cond226 = icmp ne i64 %v225, 0
  br i1 %cond226, label %bb_cast_overflow94, label %bb_cast_ok94
bb_cast_overflow94:
  %v227 = load i64, ptr %slot1, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %v229 = load i64, ptr %slot44, align 8
  call void @myl_qbe_fail_cast(ptr %p228, i64 %v229, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok94:
  %v230 = load i64, ptr %slot44, align 8
  %v231 = load i64, ptr %slot9, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 %v230, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot10, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i64 1, ptr %p234, align 8, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot10, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld237, ptr %slot46, align 8
  %v238 = load i64, ptr %slot9, align 8
  %p239 = inttoptr i64 %v238 to ptr
  %ld240 = load i64, ptr %p239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld240, ptr %slot47, align 8
  %v241 = load i64, ptr %slot47, align 8
  %v242 = load i64, ptr %slot46, align 8
  %ovpair244 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v241, i64 %v242)
  %op243 = extractvalue { i64, i1 } %ovpair244, 0
  %ov245 = extractvalue { i64, i1 } %ovpair244, 1
  store i64 %op243, ptr %slot48, align 8
  %cv246 = zext i1 %ov245 to i64
  store i64 %cv246, ptr %slot49, align 8
  %v247 = load i64, ptr %slot49, align 8
  %cond248 = icmp ne i64 %v247, 0
  br i1 %cond248, label %bb_overflow97, label %bb_checked97
bb_overflow97:
  %v249 = load i64, ptr %slot1, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %v251 = load i64, ptr %slot47, align 8
  %v252 = load i64, ptr %slot46, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p250, i64 1, i64 %v251, i64 %v252, i64 64) nomerge, !dbg !118
  unreachable
bb_checked97:
  %v253 = load i64, ptr %slot48, align 8
  %v254 = load i64, ptr %slot9, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot9, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot50, align 8
  %v259 = load i64, ptr %slot50, align 8
  ret i64 %v259
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i32 @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47_rcg_list_append(i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651", linkageName: "myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17406373326133340805, i64 0, !"myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
