target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v193 = load i64, ptr %slot1, align 8
  %op194 = add i64 %v193, 32
  store i64 %op194, ptr %slot5, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot6, align 8
  %mem197 = alloca i8, i64 8, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot7, align 8
  %mem199 = alloca i8, i64 8, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot8, align 8
  %mem201 = alloca i8, i64 8, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot9, align 8
  %mem203 = alloca i8, i64 8, align 8
  %ptr204 = ptrtoint ptr %mem203 to i64
  store i64 %ptr204, ptr %slot10, align 8
  %mem205 = alloca i8, i64 8, align 8
  %ptr206 = ptrtoint ptr %mem205 to i64
  store i64 %ptr206, ptr %slot11, align 8
  %mem207 = alloca i8, i64 56, align 8
  %ptr208 = ptrtoint ptr %mem207 to i64
  store i64 %ptr208, ptr %slot12, align 8
  %mem209 = alloca i8, i64 8, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot13, align 8
  %mem211 = alloca i8, i64 208, align 8
  %ptr212 = ptrtoint ptr %mem211 to i64
  store i64 %ptr212, ptr %slot14, align 8
  %mem213 = alloca i8, i64 8, align 8
  %ptr214 = ptrtoint ptr %mem213 to i64
  store i64 %ptr214, ptr %slot15, align 8
  %mem215 = alloca i8, i64 8, align 8
  %ptr216 = ptrtoint ptr %mem215 to i64
  store i64 %ptr216, ptr %slot16, align 8
  %mem217 = alloca i8, i64 8, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot17, align 8
  %mem219 = alloca i8, i64 8, align 8
  %ptr220 = ptrtoint ptr %mem219 to i64
  store i64 %ptr220, ptr %slot18, align 8
  %mem221 = alloca i8, i64 16, align 8
  %ptr222 = ptrtoint ptr %mem221 to i64
  store i64 %ptr222, ptr %slot19, align 8
  %mem223 = alloca i8, i64 8, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot20, align 8
  %mem225 = alloca i8, i64 8, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot21, align 8
  %mem227 = alloca i8, i64 8, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot22, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot23, align 8
  %mem231 = alloca i8, i64 208, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot24, align 8
  %mem233 = alloca i8, i64 208, align 8
  %ptr234 = ptrtoint ptr %mem233 to i64
  store i64 %ptr234, ptr %slot25, align 8
  %mem235 = alloca i8, i64 208, align 8
  %ptr236 = ptrtoint ptr %mem235 to i64
  store i64 %ptr236, ptr %slot26, align 8
  %mem237 = alloca i8, i64 16, align 8
  %ptr238 = ptrtoint ptr %mem237 to i64
  store i64 %ptr238, ptr %slot27, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem239 = alloca i8, i64 8, align 8
  %ptr240 = ptrtoint ptr %mem239 to i64
  store i64 %ptr240, ptr %slot28, align 8
  %v241 = load i64, ptr %slot1, align 8
  %op242 = add i64 %v241, 64
  store i64 %op242, ptr %slot29, align 8
  %v243 = load i64, ptr %slot29, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !4, !noalias !3
  store i64 %ld245, ptr %slot30, align 8
  %stack246 = call ptr @llvm.stacksave()
  %stackaddr247 = ptrtoint ptr %stack246 to i64
  %v248 = load i64, ptr %slot30, align 8
  %cmp249 = icmp ult i64 %stackaddr247, %v248
  %cv250 = zext i1 %cmp249 to i64
  store i64 %cv250, ptr %slot31, align 8
  %v251 = load i64, ptr %slot31, align 8
  %cond252 = icmp ne i64 %v251, 0
  br i1 %cond252, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v253 = load i64, ptr %slot1, align 8
  %p254 = inttoptr i64 %v253 to ptr
  call void @myl_qbe_fail_frame(ptr %p254) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v255 = load i64, ptr %slot2, align 8
  %v256 = load i64, ptr %slot15, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 %v255, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot3, align 8
  %v259 = load i64, ptr %slot16, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i64 %v258, ptr %p260, align 8, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot4, align 8
  %v262 = load i64, ptr %slot17, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot1, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %call266 = call ptr @myl_qbe_heap(ptr %p265) nomerge, !dbg !112
  %calladdr267 = ptrtoint ptr %call266 to i64
  store i64 %calladdr267, ptr %slot32, align 8
  %v268 = load i64, ptr %slot1, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %call270 = call i64 @myl_qbe_region_mark(ptr %p269) nomerge, !dbg !112
  store i64 %call270, ptr %slot33, align 8
  %v271 = load i64, ptr %slot6, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i32 0, ptr %p272, align 4, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot7, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i32 0, ptr %p274, align 4, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot8, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i32 0, ptr %p276, align 4, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot9, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i32 0, ptr %p278, align 4, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot10, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i32 0, ptr %p280, align 4, !alias.scope !3, !noalias !4
  %v281 = load i64, ptr %slot11, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i32 0, ptr %p282, align 4, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot7, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i32 2, ptr %p284, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v285 = load i64, ptr %slot15, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot34, align 8
  %v288 = load i64, ptr %slot34, align 8
  %v289 = load i64, ptr %slot20, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot16, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot35, align 8
  %v294 = load i64, ptr %slot35, align 8
  %v295 = load i64, ptr %slot21, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 %v294, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot17, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot36, align 8
  %v300 = load i64, ptr %slot36, align 8
  %v301 = load i64, ptr %slot22, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot24, align 8
  store i64 %v303, ptr %slot37, align 8
  %v304 = load i64, ptr %slot37, align 8
  %p305 = inttoptr i64 %v304 to ptr
  store i64 0, ptr %p305, align 8, !alias.scope !3, !noalias !4
  %v306 = load i64, ptr %slot37, align 8
  %p308 = inttoptr i64 %v306 to ptr
  %gep309 = getelementptr i8, ptr %p308, i64 8
  %op307 = ptrtoint ptr %gep309 to i64
  store i64 %op307, ptr %slot38, align 8
  %v310 = load i64, ptr %slot38, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 0, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot11, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i32 1, ptr %p313, align 4, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot33, align 8
  store i64 %v314, ptr %slot39, align 8
  %v315 = load i64, ptr %slot21, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot40, align 8
  %v318 = load i64, ptr %slot40, align 8
  %v319 = load i64, ptr %slot13, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 %v318, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot13, align 8
  store i64 %v321, ptr %slot41, align 8
  %v322 = load i64, ptr %slot37, align 8
  %p324 = inttoptr i64 %v322 to ptr
  %gep325 = getelementptr i8, ptr %p324, i64 0
  %op323 = ptrtoint ptr %gep325 to i64
  store i64 %op323, ptr %slot42, align 8
  %v326 = load i64, ptr %slot21, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot43, align 8
  %v329 = load i64, ptr %slot43, align 8
  %v330 = load i64, ptr %slot13, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i64 %v329, ptr %p331, align 8, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot13, align 8
  store i64 %v332, ptr %slot44, align 8
  %v333 = load i64, ptr %slot8, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %ld335 = load i32, ptr %p334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld335, ptr %slot45, align 8
  %v336 = load i64, ptr %slot9, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i32, ptr %p337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld338, ptr %slot46, align 8
  %v339 = load i32, ptr %slot46, align 8
  %op340 = and i32 %v339, 24
  store i32 %op340, ptr %slot46, align 8
  %v341 = load i32, ptr %slot46, align 8
  %cmp342 = icmp eq i32 %v341, 0
  %cv343 = zext i1 %cmp342 to i32
  store i32 %cv343, ptr %slot47, align 8
  %v344 = load i32, ptr %slot45, align 8
  %v345 = load i32, ptr %slot47, align 8
  %op346 = and i32 %v344, %v345
  store i32 %op346, ptr %slot48, align 8
  %v347 = load i32, ptr %slot48, align 8
  %cv348 = zext i32 %v347 to i64
  %cond349 = icmp ne i64 %cv348, 0
  br i1 %cond349, label %bb_rctake25, label %bb_rccopy25
bb_rctake25:
  %v350 = load i64, ptr %slot14, align 8
  store i64 %v350, ptr %slot49, align 8
  %v351 = load i64, ptr %slot33, align 8
  store i64 %v351, ptr %slot50, align 8
  %v352 = load i64, ptr %slot44, align 8
  %v353 = load i64, ptr %slot49, align 8
  %op354 = sub i64 %v352, %v353
  store i64 %op354, ptr %slot51, align 8
  %v355 = load i64, ptr %slot49, align 8
  %v356 = load i64, ptr %slot44, align 8
  %op357 = sub i64 %v355, %v356
  store i64 %op357, ptr %slot52, align 8
  %v358 = load i64, ptr %slot51, align 8
  %cmp359 = icmp ult i64 %v358, 8
  %cv360 = zext i1 %cmp359 to i32
  store i32 %cv360, ptr %slot53, align 8
  %v361 = load i64, ptr %slot52, align 8
  %cmp362 = icmp ult i64 %v361, 8
  %cv363 = zext i1 %cmp362 to i32
  store i32 %cv363, ptr %slot54, align 8
  %v364 = load i32, ptr %slot53, align 8
  %v365 = load i32, ptr %slot54, align 8
  %op366 = or i32 %v364, %v365
  store i32 %op366, ptr %slot55, align 8
  %v367 = load i32, ptr %slot55, align 8
  %cv368 = zext i32 %v367 to i64
  %cond369 = icmp ne i64 %cv368, 0
  br i1 %cond369, label %bb_rcmoveslow34, label %bb_rcmovecheck34
bb_rcmovecheck34:
  %v370 = load i64, ptr %slot44, align 8
  %p372 = inttoptr i64 %v370 to ptr
  %gep373 = getelementptr i8, ptr %p372, i64 0
  %op371 = ptrtoint ptr %gep373 to i64
  store i64 %op371, ptr %slot56, align 8
  %v374 = load i64, ptr %slot56, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot57, align 8
  %v377 = load i64, ptr %slot57, align 8
  %cmp378 = icmp ne i64 %v377, 0
  %cv379 = zext i1 %cmp378 to i32
  store i32 %cv379, ptr %slot58, align 8
  %v380 = load i32, ptr %slot58, align 8
  %cv381 = zext i32 %v380 to i64
  %cond382 = icmp ne i64 %cv381, 0
  br i1 %cond382, label %bb_rcmoveheader42, label %bb_rcmovenext42
bb_rcmoveheader42:
  %v383 = load i64, ptr %slot57, align 8
  %op384 = sub i64 %v383, 16
  store i64 %op384, ptr %slot59, align 8
  %v385 = load i64, ptr %slot57, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %rgep387 = getelementptr i8, ptr %p386, i64 -16
  %ld388 = load i64, ptr %rgep387, align 8, !alias.scope !9, !noalias !10
  store i64 %ld388, ptr %slot60, align 8
  %v389 = load i64, ptr %slot60, align 8
  %op390 = and i64 %v389, 5764607523034234881
  store i64 %op390, ptr %slot61, align 8
  %v391 = load i64, ptr %slot61, align 8
  %cmp392 = icmp ne i64 %v391, 0
  %cv393 = zext i1 %cmp392 to i32
  store i32 %cv393, ptr %slot62, align 8
  %v394 = load i32, ptr %slot62, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rcmoveslow34, label %bb_rcmovenext42
bb_rcmovenext42:
  %v397 = load i64, ptr %slot44, align 8
  %v398 = load i64, ptr %slot49, align 8
  %p399 = inttoptr i64 %v397 to ptr
  %p400 = inttoptr i64 %v398 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p400, ptr %p399, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v401 = load i64, ptr %slot44, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 0, ptr %p402, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved34
bb_rcmoveslow34:
  %v403 = load i64, ptr %slot32, align 8
  %v404 = load i64, ptr %slot49, align 8
  %v405 = load i64, ptr %slot44, align 8
  %v406 = load i64, ptr %slot50, align 8
  %cv407 = trunc i64 %v406 to i32
  %call408 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v403, i64 %v404, i64 %v405, i32 %cv407) nomerge, !dbg !114
  store i32 %call408, ptr %slot63, align 8
  %v409 = load i32, ptr %slot63, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcsuccess49, label %bb_rcfailure49
bb_rcfailure49:
  %v412 = load i64, ptr %slot32, align 8
  %p413 = inttoptr i64 %v412 to ptr
  %call414 = call i32 @myl_rc_take_failure(ptr %p413) nomerge, !dbg !114
  store i32 %call414, ptr %slot64, align 8
  %v415 = load i64, ptr %slot1, align 8
  %p416 = inttoptr i64 %v415 to ptr
  %v417 = load i32, ptr %slot64, align 8
  %call418 = call i32 @myl_qbe_rc_status(ptr %p416, i32 %v417) nomerge, !dbg !114
  store i32 %call418, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess49:
  br label %bb_rcmoved34
bb_rcmoved34:
  %v419 = load i64, ptr %slot8, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i32 0, ptr %p420, align 4, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot10, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i32 1, ptr %p422, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared25
bb_rccopy25:
  %v423 = load i64, ptr %slot14, align 8
  store i64 %v423, ptr %slot66, align 8
  %v424 = load i64, ptr %slot33, align 8
  store i64 %v424, ptr %slot67, align 8
  %v425 = load i64, ptr %slot44, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot68, align 8
  %v428 = load i64, ptr %slot68, align 8
  %cmp429 = icmp ne i64 %v428, 0
  %cv430 = zext i1 %cmp429 to i32
  store i32 %cv430, ptr %slot69, align 8
  %v431 = load i32, ptr %slot69, align 8
  %cv432 = zext i32 %v431 to i64
  %cond433 = icmp ne i64 %cv432, 0
  br i1 %cond433, label %bb_rcgnn58, label %bb_rcgplain58
bb_rcgnn58:
  %v434 = load i64, ptr %slot68, align 8
  %op435 = sub i64 %v434, 16
  store i64 %op435, ptr %slot70, align 8
  %v436 = load i64, ptr %slot68, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %rgep438 = getelementptr i8, ptr %p437, i64 -16
  %ld439 = load i64, ptr %rgep438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld439, ptr %slot71, align 8
  %v440 = load i64, ptr %slot71, align 8
  %op441 = and i64 %v440, 4611686018427387906
  store i64 %op441, ptr %slot72, align 8
  %v442 = load i64, ptr %slot72, align 8
  %cmp443 = icmp ne i64 %v442, 0
  %cv444 = zext i1 %cmp443 to i32
  store i32 %cv444, ptr %slot73, align 8
  %v445 = load i32, ptr %slot73, align 8
  %cv446 = zext i32 %v445 to i64
  %cond447 = icmp ne i64 %cv446, 0
  br i1 %cond447, label %bb_rcgspecial58, label %bb_rcginc58
bb_rcginc58:
  %v448 = load i64, ptr %slot68, align 8
  %op449 = sub i64 %v448, 32
  store i64 %op449, ptr %slot74, align 8
  %v450 = load i64, ptr %slot68, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %rgep452 = getelementptr i8, ptr %p451, i64 -32
  %ld453 = load i64, ptr %rgep452, align 8, !alias.scope !9, !noalias !10
  store i64 %ld453, ptr %slot75, align 8
  %v454 = load i64, ptr %slot75, align 8
  %op455 = add i64 %v454, 1
  store i64 %op455, ptr %slot76, align 8
  %v456 = load i64, ptr %slot76, align 8
  %cmp457 = icmp eq i64 %v456, 0
  %cv458 = zext i1 %cmp457 to i32
  store i32 %cv458, ptr %slot77, align 8
  %v459 = load i32, ptr %slot77, align 8
  %cv460 = zext i32 %v459 to i64
  %cond461 = icmp ne i64 %cv460, 0
  br i1 %cond461, label %bb_rcglimit58, label %bb_rcgcapacity58
bb_rcglimit58:
  %v462 = load i64, ptr %slot1, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %call464 = call i32 @myl_qbe_rc_status(ptr %p463, i32 2) nomerge, !dbg !114
  store i32 %call464, ptr %slot78, align 8
  br label %bb_failure
bb_rcgcapacity58:
  %v465 = load i64, ptr %slot76, align 8
  %v466 = load i64, ptr %slot68, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %rgep468 = getelementptr i8, ptr %p467, i64 -32
  store i64 %v465, ptr %rgep468, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain58
bb_rcgspecial58:
  %v469 = load i64, ptr %slot71, align 8
  %op470 = and i64 %v469, 4611686018427387904
  store i64 %op470, ptr %slot79, align 8
  %v471 = load i64, ptr %slot79, align 8
  %cmp472 = icmp ne i64 %v471, 0
  %cv473 = zext i1 %cmp472 to i32
  store i32 %cv473, ptr %slot80, align 8
  %v474 = load i32, ptr %slot80, align 8
  %cv475 = zext i32 %v474 to i64
  %cond476 = icmp ne i64 %cv475, 0
  br i1 %cond476, label %bb_rcgslow58, label %bb_rcgplain58
bb_rcgslow58:
  %v477 = load i64, ptr %slot32, align 8
  %v478 = load i64, ptr %slot66, align 8
  %v479 = load i64, ptr %slot44, align 8
  %v480 = load i64, ptr %slot67, align 8
  %cv481 = trunc i64 %v480 to i32
  %call482 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v477, i64 %v478, i64 %v479, i32 %cv481) nomerge, !dbg !114
  store i32 %call482, ptr %slot81, align 8
  %v483 = load i32, ptr %slot81, align 8
  %cv484 = zext i32 %v483 to i64
  %cond485 = icmp ne i64 %cv484, 0
  br i1 %cond485, label %bb_rcsuccess72, label %bb_rcfailure72
bb_rcfailure72:
  %v486 = load i64, ptr %slot32, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %call488 = call i32 @myl_rc_take_failure(ptr %p487) nomerge, !dbg !114
  store i32 %call488, ptr %slot82, align 8
  %v489 = load i64, ptr %slot1, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %v491 = load i32, ptr %slot82, align 8
  %call492 = call i32 @myl_qbe_rc_status(ptr %p490, i32 %v491) nomerge, !dbg !114
  store i32 %call492, ptr %slot83, align 8
  br label %bb_failure
bb_rcsuccess72:
  br label %bb_rcgdone58
bb_rcgplain58:
  %v493 = load i64, ptr %slot68, align 8
  %v494 = load i64, ptr %slot66, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i64 %v493, ptr %p495, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone58
bb_rcgdone58:
  %v496 = load i64, ptr %slot10, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i32 1, ptr %p497, align 4, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot8, align 8
  %p499 = inttoptr i64 %v498 to ptr
  %ld500 = load i32, ptr %p499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld500, ptr %slot84, align 8
  %v501 = load i32, ptr %slot84, align 8
  %cv502 = zext i32 %v501 to i64
  %cond503 = icmp ne i64 %cv502, 0
  br i1 %cond503, label %bb_rcslotdrop79, label %bb_rcslotdone79
bb_rcslotdrop79:
  %v504 = load i64, ptr %slot8, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i32 0, ptr %p505, align 4, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot12, align 8
  store i64 %v506, ptr %slot85, align 8
  %v507 = load i64, ptr %slot9, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %ld509 = load i32, ptr %p508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld509, ptr %slot86, align 8
  %v510 = load i32, ptr %slot86, align 8
  %op511 = and i32 %v510, 28
  store i32 %op511, ptr %slot87, align 8
  %v512 = load i32, ptr %slot87, align 8
  %cv513 = zext i32 %v512 to i64
  %cond514 = icmp ne i64 %cv513, 0
  br i1 %cond514, label %bb_rcslotrole79, label %bb_rcslotowner79
bb_rcslotrole79:
  %v515 = load i64, ptr %slot32, align 8
  store i64 %v515, ptr %slot88, align 8
  %v516 = load i64, ptr %slot85, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot89, align 8
  %v519 = load i64, ptr %slot89, align 8
  %cmp520 = icmp ne i64 %v519, 0
  %cv521 = zext i1 %cmp520 to i32
  store i32 %cv521, ptr %slot90, align 8
  %v522 = load i32, ptr %slot90, align 8
  %cv523 = zext i32 %v522 to i64
  %cond524 = icmp ne i64 %cv523, 0
  br i1 %cond524, label %bb_rcgnn95, label %bb_rcgdone95
bb_rcgnn95:
  %v525 = load i64, ptr %slot89, align 8
  %op526 = sub i64 %v525, 16
  store i64 %op526, ptr %slot91, align 8
  %v527 = load i64, ptr %slot89, align 8
  %p528 = inttoptr i64 %v527 to ptr
  %rgep529 = getelementptr i8, ptr %p528, i64 -16
  %ld530 = load i64, ptr %rgep529, align 8, !alias.scope !9, !noalias !10
  store i64 %ld530, ptr %slot92, align 8
  %v531 = load i64, ptr %slot92, align 8
  %op532 = and i64 %v531, 4611686018427387906
  store i64 %op532, ptr %slot93, align 8
  %v533 = load i64, ptr %slot93, align 8
  %cmp534 = icmp ne i64 %v533, 0
  %cv535 = zext i1 %cmp534 to i32
  store i32 %cv535, ptr %slot94, align 8
  %v536 = load i32, ptr %slot94, align 8
  %cv537 = zext i32 %v536 to i64
  %cond538 = icmp ne i64 %cv537, 0
  br i1 %cond538, label %bb_rcgclear95, label %bb_rcgcounted95
bb_rcgcounted95:
  %v539 = load i64, ptr %slot89, align 8
  %op540 = sub i64 %v539, 24
  store i64 %op540, ptr %slot95, align 8
  %v541 = load i64, ptr %slot89, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %rgep543 = getelementptr i8, ptr %p542, i64 -24
  %ld544 = load i64, ptr %rgep543, align 8, !alias.scope !9, !noalias !10
  store i64 %ld544, ptr %slot96, align 8
  %v545 = load i64, ptr %slot96, align 8
  %op546 = sub i64 %v545, 1
  store i64 %op546, ptr %slot97, align 8
  %v547 = load i64, ptr %slot97, align 8
  %cmp548 = icmp eq i64 %v547, 0
  %cv549 = zext i1 %cmp548 to i32
  store i32 %cv549, ptr %slot98, align 8
  %v550 = load i32, ptr %slot98, align 8
  %cv551 = zext i32 %v550 to i64
  %cond552 = icmp ne i64 %cv551, 0
  br i1 %cond552, label %bb_rcglast95, label %bb_rcgdec95
bb_rcglast95:
  %v553 = load i64, ptr %slot89, align 8
  %op554 = sub i64 %v553, 32
  store i64 %op554, ptr %slot99, align 8
  %v555 = load i64, ptr %slot89, align 8
  %p556 = inttoptr i64 %v555 to ptr
  %rgep557 = getelementptr i8, ptr %p556, i64 -32
  %ld558 = load i64, ptr %rgep557, align 8, !alias.scope !9, !noalias !10
  store i64 %ld558, ptr %slot100, align 8
  %v559 = load i64, ptr %slot100, align 8
  %cmp560 = icmp ne i64 %v559, 0
  %cv561 = zext i1 %cmp560 to i32
  store i32 %cv561, ptr %slot101, align 8
  %v562 = load i32, ptr %slot101, align 8
  %cv563 = zext i32 %v562 to i64
  %cond564 = icmp ne i64 %cv563, 0
  br i1 %cond564, label %bb_rcgdec95, label %bb_rcgslow95
bb_rcgslow95:
  %v565 = load i64, ptr %slot88, align 8
  %v566 = load i64, ptr %slot85, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v565, i64 %v566) nomerge, !dbg !114
  br label %bb_rcgdone95
bb_rcgdec95:
  %v567 = load i64, ptr %slot97, align 8
  %v568 = load i64, ptr %slot89, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %rgep570 = getelementptr i8, ptr %p569, i64 -24
  store i64 %v567, ptr %rgep570, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear95
bb_rcgclear95:
  %v571 = load i64, ptr %slot85, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i64 0, ptr %p572, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone95
bb_rcgdone95:
  br label %bb_rcslotdone79
bb_rcslotowner79:
  %v573 = load i64, ptr %slot32, align 8
  store i64 %v573, ptr %slot102, align 8
  %v574 = load i64, ptr %slot85, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i64, ptr %p575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot103, align 8
  %v577 = load i64, ptr %slot103, align 8
  %cmp578 = icmp ne i64 %v577, 0
  %cv579 = zext i1 %cmp578 to i32
  store i32 %cv579, ptr %slot104, align 8
  %v580 = load i32, ptr %slot104, align 8
  %cv581 = zext i32 %v580 to i64
  %cond582 = icmp ne i64 %cv581, 0
  br i1 %cond582, label %bb_rcgnn110, label %bb_rcgdone110
bb_rcgnn110:
  %v583 = load i64, ptr %slot103, align 8
  %op584 = sub i64 %v583, 16
  store i64 %op584, ptr %slot105, align 8
  %v585 = load i64, ptr %slot103, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %rgep587 = getelementptr i8, ptr %p586, i64 -16
  %ld588 = load i64, ptr %rgep587, align 8, !alias.scope !9, !noalias !10
  store i64 %ld588, ptr %slot106, align 8
  %v589 = load i64, ptr %slot106, align 8
  %op590 = and i64 %v589, 4611686018427387906
  store i64 %op590, ptr %slot107, align 8
  %v591 = load i64, ptr %slot107, align 8
  %cmp592 = icmp ne i64 %v591, 0
  %cv593 = zext i1 %cmp592 to i32
  store i32 %cv593, ptr %slot108, align 8
  %v594 = load i32, ptr %slot108, align 8
  %cv595 = zext i32 %v594 to i64
  %cond596 = icmp ne i64 %cv595, 0
  br i1 %cond596, label %bb_rcgclear110, label %bb_rcgcounted110
bb_rcgcounted110:
  %v597 = load i64, ptr %slot103, align 8
  %op598 = sub i64 %v597, 32
  store i64 %op598, ptr %slot109, align 8
  %v599 = load i64, ptr %slot103, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %rgep601 = getelementptr i8, ptr %p600, i64 -32
  %ld602 = load i64, ptr %rgep601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld602, ptr %slot110, align 8
  %v603 = load i64, ptr %slot110, align 8
  %op604 = sub i64 %v603, 1
  store i64 %op604, ptr %slot111, align 8
  %v605 = load i64, ptr %slot111, align 8
  %cmp606 = icmp eq i64 %v605, 0
  %cv607 = zext i1 %cmp606 to i32
  store i32 %cv607, ptr %slot112, align 8
  %v608 = load i32, ptr %slot112, align 8
  %cv609 = zext i32 %v608 to i64
  %cond610 = icmp ne i64 %cv609, 0
  br i1 %cond610, label %bb_rcglast110, label %bb_rcgdec110
bb_rcglast110:
  %v611 = load i64, ptr %slot103, align 8
  %op612 = sub i64 %v611, 24
  store i64 %op612, ptr %slot113, align 8
  %v613 = load i64, ptr %slot103, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %rgep615 = getelementptr i8, ptr %p614, i64 -24
  %ld616 = load i64, ptr %rgep615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld616, ptr %slot114, align 8
  %v617 = load i64, ptr %slot114, align 8
  %cmp618 = icmp ne i64 %v617, 0
  %cv619 = zext i1 %cmp618 to i32
  store i32 %cv619, ptr %slot115, align 8
  %v620 = load i32, ptr %slot115, align 8
  %cv621 = zext i32 %v620 to i64
  %cond622 = icmp ne i64 %cv621, 0
  br i1 %cond622, label %bb_rcgdec110, label %bb_rcgslow110
bb_rcgslow110:
  %v623 = load i64, ptr %slot102, align 8
  %v624 = load i64, ptr %slot85, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v623, i64 %v624) nomerge, !dbg !114
  br label %bb_rcgdone110
bb_rcgdec110:
  %v625 = load i64, ptr %slot111, align 8
  %v626 = load i64, ptr %slot103, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %rgep628 = getelementptr i8, ptr %p627, i64 -32
  store i64 %v625, ptr %rgep628, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear110
bb_rcgclear110:
  %v629 = load i64, ptr %slot85, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i64 0, ptr %p630, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone110
bb_rcgdone110:
  br label %bb_rcslotdone79
bb_rcslotdone79:
  br label %bb_rcprepared25
bb_rcprepared25:
  %v631 = load i64, ptr %slot14, align 8
  store i64 %v631, ptr %slot116, align 8
  %v632 = load i64, ptr %slot116, align 8
  %v633 = load i64, ptr %slot42, align 8
  %p634 = inttoptr i64 %v632 to ptr
  %p635 = inttoptr i64 %v633 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p635, ptr %p634, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot10, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 0, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot22, align 8
  store i64 %v638, ptr %slot117, align 8
  %v639 = load i64, ptr %slot37, align 8
  %p641 = inttoptr i64 %v639 to ptr
  %gep642 = getelementptr i8, ptr %p641, i64 8
  %op640 = ptrtoint ptr %gep642 to i64
  store i64 %op640, ptr %slot118, align 8
  %v643 = load i64, ptr %slot117, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %ld645 = load i32, ptr %p644, align 4, !alias.scope !3, !noalias !4
  %ext646 = zext i32 %ld645 to i64
  store i64 %ext646, ptr %slot119, align 8
  %v647 = load i64, ptr %slot119, align 8
  %cv648 = trunc i64 %v647 to i32
  %v649 = load i64, ptr %slot118, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i32 %cv648, ptr %p650, align 4, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot37, align 8
  %v652 = load i64, ptr %slot21, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot21, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i64, ptr %p655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld656, ptr %slot120, align 8
  %v657 = load i64, ptr %slot12, align 8
  store i64 %v657, ptr %slot121, align 8
  %v658 = load i64, ptr %slot120, align 8
  %v659 = load i64, ptr %slot121, align 8
  %p660 = inttoptr i64 %v658 to ptr
  %p661 = inttoptr i64 %v659 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p661, ptr %p660, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot9, align 8
  %p663 = inttoptr i64 %v662 to ptr
  store i32 2, ptr %p663, align 4, !alias.scope !3, !noalias !4
  %v664 = load i64, ptr %slot8, align 8
  %p665 = inttoptr i64 %v664 to ptr
  store i32 1, ptr %p665, align 4, !alias.scope !3, !noalias !4
  %v666 = load i64, ptr %slot121, align 8
  %v667 = load i64, ptr %slot21, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 %v666, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot25, align 8
  store i64 %v669, ptr %slot122, align 8
  %v670 = load i64, ptr %slot122, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i64 0, ptr %p671, align 8, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot122, align 8
  %p674 = inttoptr i64 %v672 to ptr
  %gep675 = getelementptr i8, ptr %p674, i64 8
  %op673 = ptrtoint ptr %gep675 to i64
  store i64 %op673, ptr %slot123, align 8
  %v676 = load i64, ptr %slot123, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i64 0, ptr %p677, align 8, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot122, align 8
  %p680 = inttoptr i64 %v678 to ptr
  %gep681 = getelementptr i8, ptr %p680, i64 16
  %op679 = ptrtoint ptr %gep681 to i64
  store i64 %op679, ptr %slot124, align 8
  %v682 = load i64, ptr %slot124, align 8
  %p683 = inttoptr i64 %v682 to ptr
  store i64 0, ptr %p683, align 8, !alias.scope !3, !noalias !4
  %v684 = load i64, ptr %slot122, align 8
  %p686 = inttoptr i64 %v684 to ptr
  %gep687 = getelementptr i8, ptr %p686, i64 24
  %op685 = ptrtoint ptr %gep687 to i64
  store i64 %op685, ptr %slot125, align 8
  %v688 = load i64, ptr %slot125, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 0, ptr %p689, align 8, !alias.scope !3, !noalias !4
  %v690 = load i64, ptr %slot122, align 8
  %p692 = inttoptr i64 %v690 to ptr
  %gep693 = getelementptr i8, ptr %p692, i64 32
  %op691 = ptrtoint ptr %gep693 to i64
  store i64 %op691, ptr %slot126, align 8
  %v694 = load i64, ptr %slot126, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 0, ptr %p695, align 8, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot122, align 8
  %p698 = inttoptr i64 %v696 to ptr
  %gep699 = getelementptr i8, ptr %p698, i64 40
  %op697 = ptrtoint ptr %gep699 to i64
  store i64 %op697, ptr %slot127, align 8
  %v700 = load i64, ptr %slot127, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i64 0, ptr %p701, align 8, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot122, align 8
  %p704 = inttoptr i64 %v702 to ptr
  %gep705 = getelementptr i8, ptr %p704, i64 48
  %op703 = ptrtoint ptr %gep705 to i64
  store i64 %op703, ptr %slot128, align 8
  %v706 = load i64, ptr %slot128, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i64 0, ptr %p707, align 8, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot122, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i32 1, ptr %p709, align 4, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot11, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i32 1, ptr %p711, align 4, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot21, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %ld714 = load i64, ptr %p713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld714, ptr %slot129, align 8
  %v715 = load i64, ptr %slot122, align 8
  %p717 = inttoptr i64 %v715 to ptr
  %gep718 = getelementptr i8, ptr %p717, i64 8
  %op716 = ptrtoint ptr %gep718 to i64
  store i64 %op716, ptr %slot130, align 8
  %v719 = load i64, ptr %slot33, align 8
  store i64 %v719, ptr %slot131, align 8
  %v720 = load i64, ptr %slot21, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i64, ptr %p721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld722, ptr %slot132, align 8
  %v723 = load i64, ptr %slot14, align 8
  store i64 %v723, ptr %slot133, align 8
  %v724 = load i64, ptr %slot33, align 8
  store i64 %v724, ptr %slot134, align 8
  %v725 = load i64, ptr %slot132, align 8
  %op726 = add i64 %v725, 0
  store i64 %op726, ptr %slot135, align 8
  %v727 = load i64, ptr %slot135, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot136, align 8
  %v730 = load i64, ptr %slot136, align 8
  %cmp731 = icmp ne i64 %v730, 0
  %cv732 = zext i1 %cmp731 to i32
  store i32 %cv732, ptr %slot137, align 8
  %v733 = load i32, ptr %slot137, align 8
  %cv734 = zext i32 %v733 to i64
  %cond735 = icmp ne i64 %cv734, 0
  br i1 %cond735, label %bb_rcmoveheader141, label %bb_rcmovenext141
bb_rcmoveheader141:
  %v736 = load i64, ptr %slot136, align 8
  %op737 = sub i64 %v736, 16
  store i64 %op737, ptr %slot138, align 8
  %v738 = load i64, ptr %slot136, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %rgep740 = getelementptr i8, ptr %p739, i64 -16
  %ld741 = load i64, ptr %rgep740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld741, ptr %slot139, align 8
  %v742 = load i64, ptr %slot139, align 8
  %op743 = and i64 %v742, 5764607523034234881
  store i64 %op743, ptr %slot140, align 8
  %v744 = load i64, ptr %slot140, align 8
  %cmp745 = icmp ne i64 %v744, 0
  %cv746 = zext i1 %cmp745 to i32
  store i32 %cv746, ptr %slot141, align 8
  %v747 = load i32, ptr %slot141, align 8
  %cv748 = zext i32 %v747 to i64
  %cond749 = icmp ne i64 %cv748, 0
  br i1 %cond749, label %bb_rcmoveslow138, label %bb_rcmovenext141
bb_rcmovenext141:
  %v750 = load i64, ptr %slot132, align 8
  %v751 = load i64, ptr %slot133, align 8
  %p752 = inttoptr i64 %v750 to ptr
  %p753 = inttoptr i64 %v751 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p753, ptr %p752, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot132, align 8
  %p755 = inttoptr i64 %v754 to ptr
  store i64 0, ptr %p755, align 8, !alias.scope !3, !noalias !4
  %v756 = load i64, ptr %slot132, align 8
  %op757 = add i64 %v756, 8
  store i64 %op757, ptr %slot142, align 8
  %v758 = load i64, ptr %slot142, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i64 0, ptr %p759, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved138
bb_rcmoveslow138:
  %v760 = load i64, ptr %slot32, align 8
  %v761 = load i64, ptr %slot133, align 8
  %v762 = load i64, ptr %slot132, align 8
  %v763 = load i64, ptr %slot134, align 8
  %cv764 = trunc i64 %v763 to i32
  %call765 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v760, i64 %v761, i64 %v762, i32 %cv764) nomerge, !dbg !116
  store i32 %call765, ptr %slot143, align 8
  %v766 = load i32, ptr %slot143, align 8
  %cv767 = zext i32 %v766 to i64
  %cond768 = icmp ne i64 %cv767, 0
  br i1 %cond768, label %bb_rcsuccess149, label %bb_rcfailure149
bb_rcfailure149:
  %v769 = load i64, ptr %slot32, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %call771 = call i32 @myl_rc_take_failure(ptr %p770) nomerge, !dbg !116
  store i32 %call771, ptr %slot144, align 8
  %v772 = load i64, ptr %slot1, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %v774 = load i32, ptr %slot144, align 8
  %call775 = call i32 @myl_qbe_rc_status(ptr %p773, i32 %v774) nomerge, !dbg !116
  store i32 %call775, ptr %slot145, align 8
  br label %bb_failure
bb_rcsuccess149:
  br label %bb_rcmoved138
bb_rcmoved138:
  %v776 = load i64, ptr %slot8, align 8
  %p777 = inttoptr i64 %v776 to ptr
  store i32 0, ptr %p777, align 4, !alias.scope !3, !noalias !4
  %v778 = load i64, ptr %slot10, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 1, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot14, align 8
  store i64 %v780, ptr %slot146, align 8
  %v781 = load i64, ptr %slot146, align 8
  %v782 = load i64, ptr %slot130, align 8
  %p783 = inttoptr i64 %v781 to ptr
  %p784 = inttoptr i64 %v782 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p784, ptr %p783, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v785 = load i64, ptr %slot10, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i32 0, ptr %p786, align 4, !alias.scope !3, !noalias !4
  %v787 = load i64, ptr %slot122, align 8
  %v788 = load i64, ptr %slot21, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i64 %v787, ptr %p789, align 8, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot21, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i64, ptr %p791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld792, ptr %slot147, align 8
  %v793 = load i64, ptr %slot12, align 8
  store i64 %v793, ptr %slot148, align 8
  %v794 = load i64, ptr %slot147, align 8
  %v795 = load i64, ptr %slot148, align 8
  %p796 = inttoptr i64 %v794 to ptr
  %p797 = inttoptr i64 %v795 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p797, ptr %p796, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot9, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 2, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot8, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 1, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot148, align 8
  %v803 = load i64, ptr %slot21, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 %v802, ptr %p804, align 8, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot20, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot149, align 8
  %v808 = load i64, ptr %slot21, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot150, align 8
  %v811 = load i64, ptr %slot1, align 8
  %v812 = load i64, ptr %slot149, align 8
  %v813 = load i64, ptr %slot150, align 8
  %call814 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v811, i64 %v812, i64 %v813) nomerge, !dbg !118
  store i64 %call814, ptr %slot151, align 8
  %v815 = load i64, ptr %slot151, align 8
  %v816 = load i64, ptr %slot20, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot8, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i32, ptr %p819, align 4, !alias.scope !3, !noalias !4
  store i32 %ld820, ptr %slot152, align 8
  %v821 = load i32, ptr %slot152, align 8
  %cv822 = zext i32 %v821 to i64
  %cond823 = icmp ne i64 %cv822, 0
  br i1 %cond823, label %bb_rcslotdrop175, label %bb_rcslotdone175
bb_rcslotdrop175:
  %v824 = load i64, ptr %slot8, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i32 0, ptr %p825, align 4, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot12, align 8
  store i64 %v826, ptr %slot153, align 8
  %v827 = load i64, ptr %slot9, align 8
  %p828 = inttoptr i64 %v827 to ptr
  %ld829 = load i32, ptr %p828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld829, ptr %slot154, align 8
  %v830 = load i32, ptr %slot154, align 8
  %op831 = and i32 %v830, 28
  store i32 %op831, ptr %slot155, align 8
  %v832 = load i32, ptr %slot155, align 8
  %cv833 = zext i32 %v832 to i64
  %cond834 = icmp ne i64 %cv833, 0
  br i1 %cond834, label %bb_rcslotrole175, label %bb_rcslotowner175
bb_rcslotrole175:
  %v835 = load i64, ptr %slot32, align 8
  store i64 %v835, ptr %slot156, align 8
  %v836 = load i64, ptr %slot156, align 8
  %v837 = load i64, ptr %slot153, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v836, i64 %v837) nomerge, !dbg !118
  br label %bb_rcslotdone175
bb_rcslotowner175:
  %v838 = load i64, ptr %slot32, align 8
  store i64 %v838, ptr %slot157, align 8
  %v839 = load i64, ptr %slot157, align 8
  %v840 = load i64, ptr %slot153, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v839, i64 %v840) nomerge, !dbg !118
  br label %bb_rcslotdone175
bb_rcslotdone175:
  %v841 = load i64, ptr %slot20, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i64, ptr %p842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld843, ptr %slot158, align 8
  %v844 = load i64, ptr %slot158, align 8
  %v845 = load i64, ptr %slot18, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 %v844, ptr %p846, align 8, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot15, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ld849 = load i64, ptr %p848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld849, ptr %slot159, align 8
  %v850 = load i64, ptr %slot159, align 8
  %v851 = load i64, ptr %slot26, align 8
  %p852 = inttoptr i64 %v850 to ptr
  %p853 = inttoptr i64 %v851 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p853, ptr %p852, i64 208, i1 false), !alias.scope !10000000
  %v854 = load i64, ptr %slot26, align 8
  %v855 = load i64, ptr %slot20, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i64 %v854, ptr %p856, align 8, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot20, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i64, ptr %p858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld859, ptr %slot160, align 8
  %v860 = load i64, ptr %slot160, align 8
  %op861 = add i64 %v860, 32
  store i64 %op861, ptr %slot161, align 8
  %v862 = load i64, ptr %slot161, align 8
  %v863 = load i64, ptr %slot20, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i64 %v862, ptr %p864, align 8, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot6, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i32, ptr %p866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld867, ptr %slot162, align 8
  %v868 = load i32, ptr %slot162, align 8
  %cv869 = zext i32 %v868 to i64
  %cond870 = icmp ne i64 %cv869, 0
  br i1 %cond870, label %bb_rcslotdrop188, label %bb_rcslotdone188
bb_rcslotdrop188:
  %v871 = load i64, ptr %slot6, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i32 0, ptr %p872, align 4, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot19, align 8
  store i64 %v873, ptr %slot163, align 8
  %v874 = load i64, ptr %slot7, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %ld876 = load i32, ptr %p875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld876, ptr %slot164, align 8
  %v877 = load i32, ptr %slot164, align 8
  %op878 = and i32 %v877, 28
  store i32 %op878, ptr %slot165, align 8
  %v879 = load i32, ptr %slot165, align 8
  %cv880 = zext i32 %v879 to i64
  %cond881 = icmp ne i64 %cv880, 0
  br i1 %cond881, label %bb_rcslotrole188, label %bb_rcslotowner188
bb_rcslotrole188:
  %v882 = load i64, ptr %slot32, align 8
  store i64 %v882, ptr %slot166, align 8
  %v883 = load i64, ptr %slot166, align 8
  %v884 = load i64, ptr %slot163, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v883, i64 %v884) nomerge, !dbg !120
  br label %bb_rcslotdone188
bb_rcslotowner188:
  %v885 = load i64, ptr %slot32, align 8
  store i64 %v885, ptr %slot167, align 8
  %v886 = load i64, ptr %slot167, align 8
  %v887 = load i64, ptr %slot163, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v886, i64 %v887) nomerge, !dbg !120
  br label %bb_rcslotdone188
bb_rcslotdone188:
  %v888 = load i64, ptr %slot15, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %ld890 = load i64, ptr %p889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld890, ptr %slot168, align 8
  %v891 = load i64, ptr %slot168, align 8
  %op892 = add i64 %v891, 32
  store i64 %op892, ptr %slot169, align 8
  %v893 = load i64, ptr %slot19, align 8
  store i64 %v893, ptr %slot170, align 8
  %v894 = load i64, ptr %slot169, align 8
  %v895 = load i64, ptr %slot170, align 8
  %p896 = inttoptr i64 %v894 to ptr
  %p897 = inttoptr i64 %v895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p897, ptr %p896, i64 16, i1 false), !alias.scope !10000000
  %v898 = load i64, ptr %slot169, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i64 0, ptr %p899, align 8, !alias.scope !4, !noalias !3
  %v900 = load i64, ptr %slot169, align 8
  %op901 = add i64 %v900, 8
  store i64 %op901, ptr %slot171, align 8
  %v902 = load i64, ptr %slot171, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i64 0, ptr %p903, align 8, !alias.scope !4, !noalias !3
  %v904 = load i64, ptr %slot6, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 1, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot19, align 8
  %v907 = load i64, ptr %slot20, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i64 %v906, ptr %p908, align 8, !alias.scope !3, !noalias !4
  %v909 = load i64, ptr %slot18, align 8
  %p910 = inttoptr i64 %v909 to ptr
  %ld911 = load i64, ptr %p910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld911, ptr %slot172, align 8
  %v912 = load i64, ptr %slot172, align 8
  %v913 = load i64, ptr %slot21, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i64 %v912, ptr %p914, align 8, !alias.scope !3, !noalias !4
  %v915 = load i64, ptr %slot17, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i64, ptr %p916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld917, ptr %slot173, align 8
  %v918 = load i64, ptr %slot173, align 8
  %v919 = load i64, ptr %slot22, align 8
  %p920 = inttoptr i64 %v919 to ptr
  store i64 %v918, ptr %p920, align 8, !alias.scope !3, !noalias !4
  %v921 = load i64, ptr %slot27, align 8
  store i64 %v921, ptr %slot174, align 8
  %v922 = load i64, ptr %slot174, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i64 0, ptr %p923, align 8, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot174, align 8
  %p926 = inttoptr i64 %v924 to ptr
  %gep927 = getelementptr i8, ptr %p926, i64 8
  %op925 = ptrtoint ptr %gep927 to i64
  store i64 %op925, ptr %slot175, align 8
  %v928 = load i64, ptr %slot175, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i64 0, ptr %p929, align 8, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot174, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot174, align 8
  %v933 = load i64, ptr %slot23, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 %v932, ptr %p934, align 8, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot20, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i64, ptr %p936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld937, ptr %slot176, align 8
  %v938 = load i64, ptr %slot21, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot177, align 8
  %v941 = load i64, ptr %slot22, align 8
  %p942 = inttoptr i64 %v941 to ptr
  %ld943 = load i64, ptr %p942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld943, ptr %slot178, align 8
  %v944 = load i64, ptr %slot23, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %ld946 = load i64, ptr %p945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld946, ptr %slot179, align 8
  %v947 = load i64, ptr %slot1, align 8
  %v948 = load i64, ptr %slot176, align 8
  %v949 = load i64, ptr %slot177, align 8
  %v950 = load i64, ptr %slot178, align 8
  %v951 = load i64, ptr %slot179, align 8
  %call952 = call i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64 %v947, i64 %v948, i64 %v949, i64 %v950, i64 %v951) nomerge, !dbg !122
  store i64 %call952, ptr %slot180, align 8
  %v953 = load i64, ptr %slot180, align 8
  %v954 = load i64, ptr %slot20, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i64 %v953, ptr %p955, align 8, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot15, align 8
  %p957 = inttoptr i64 %v956 to ptr
  %ld958 = load i64, ptr %p957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld958, ptr %slot181, align 8
  %v959 = load i64, ptr %slot181, align 8
  %op960 = add i64 %v959, 32
  store i64 %op960, ptr %slot182, align 8
  %v961 = load i64, ptr %slot19, align 8
  store i64 %v961, ptr %slot183, align 8
  %v962 = load i64, ptr %slot183, align 8
  %v963 = load i64, ptr %slot182, align 8
  %p964 = inttoptr i64 %v962 to ptr
  %p965 = inttoptr i64 %v963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p965, ptr %p964, i64 16, i1 false), !alias.scope !10000000
  %v966 = load i64, ptr %slot183, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i64 0, ptr %p967, align 8, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot183, align 8
  %p970 = inttoptr i64 %v968 to ptr
  %gep971 = getelementptr i8, ptr %p970, i64 8
  %op969 = ptrtoint ptr %gep971 to i64
  store i64 %op969, ptr %slot184, align 8
  %v972 = load i64, ptr %slot184, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i64 0, ptr %p973, align 8, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot6, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 0, ptr %p975, align 4, !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot20, align 8
  %p977 = inttoptr i64 %v976 to ptr
  store i64 0, ptr %p977, align 8, !alias.scope !3, !noalias !4
  %v978 = load i64, ptr %slot18, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %ld980 = load i64, ptr %p979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld980, ptr %slot185, align 8
  %v981 = load i64, ptr %slot185, align 8
  %v982 = load i64, ptr %slot20, align 8
  %p983 = inttoptr i64 %v982 to ptr
  store i64 %v981, ptr %p983, align 8, !alias.scope !3, !noalias !4
  %v984 = load i64, ptr %slot20, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i64, ptr %p985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld986, ptr %slot186, align 8
  %v987 = load i64, ptr %slot6, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %ld989 = load i32, ptr %p988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld989, ptr %slot187, align 8
  %v990 = load i32, ptr %slot187, align 8
  %cv991 = zext i32 %v990 to i64
  %cond992 = icmp ne i64 %cv991, 0
  br i1 %cond992, label %bb_rcslotdrop248, label %bb_rcslotdone248
bb_rcslotdrop248:
  %v993 = load i64, ptr %slot6, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i32 0, ptr %p994, align 4, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot19, align 8
  store i64 %v995, ptr %slot188, align 8
  %v996 = load i64, ptr %slot7, align 8
  %p997 = inttoptr i64 %v996 to ptr
  %ld998 = load i32, ptr %p997, align 4, !alias.scope !3, !noalias !4
  store i32 %ld998, ptr %slot189, align 8
  %v999 = load i32, ptr %slot189, align 8
  %op1000 = and i32 %v999, 28
  store i32 %op1000, ptr %slot190, align 8
  %v1001 = load i32, ptr %slot190, align 8
  %cv1002 = zext i32 %v1001 to i64
  %cond1003 = icmp ne i64 %cv1002, 0
  br i1 %cond1003, label %bb_rcslotrole248, label %bb_rcslotowner248
bb_rcslotrole248:
  %v1004 = load i64, ptr %slot32, align 8
  store i64 %v1004, ptr %slot191, align 8
  %v1005 = load i64, ptr %slot191, align 8
  %v1006 = load i64, ptr %slot188, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1005, i64 %v1006) nomerge, !dbg !124
  br label %bb_rcslotdone248
bb_rcslotowner248:
  %v1007 = load i64, ptr %slot32, align 8
  store i64 %v1007, ptr %slot192, align 8
  %v1008 = load i64, ptr %slot192, align 8
  %v1009 = load i64, ptr %slot188, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v1008, i64 %v1009) nomerge, !dbg !124
  br label %bb_rcslotdone248
bb_rcslotdone248:
  %v1010 = load i64, ptr %slot186, align 8
  ret i64 %v1010
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64, i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016", linkageName: "myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16834026746447143827, i64 0, !"myl_f_abd676da3bb55d619105101993a1e711476c89c86d88222368b6a54b022a2016"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!122 = !DILocation(line: 16, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!124 = !DILocation(line: 32, column: 0, scope: !125)
