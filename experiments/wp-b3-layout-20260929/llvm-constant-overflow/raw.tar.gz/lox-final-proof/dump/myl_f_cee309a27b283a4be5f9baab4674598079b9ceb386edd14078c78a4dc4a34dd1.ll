target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_cee309a27b283a4be5f9baab4674598079b9ceb386edd14078c78a4dc4a34dd1(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v21 = load i64, ptr %slot1, align 8
  %op22 = add i64 %v21, 32
  store i64 %op22, ptr %slot3, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot4, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot5, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot6, align 8
  %v29 = load i64, ptr %slot2, align 8
  %v30 = load i64, ptr %slot4, align 8
  %p31 = inttoptr i64 %v30 to ptr
  store i64 %v29, ptr %p31, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v32 = load i64, ptr %slot4, align 8
  %p33 = inttoptr i64 %v32 to ptr
  %ld34 = load i64, ptr %p33, align 8, !alias.scope !3, !noalias !4
  store i64 %ld34, ptr %slot7, align 8
  %v35 = load i64, ptr %slot7, align 8
  %v36 = load i64, ptr %slot5, align 8
  %p37 = inttoptr i64 %v36 to ptr
  store i64 %v35, ptr %p37, align 8, !alias.scope !3, !noalias !4
  %v38 = load i64, ptr %slot5, align 8
  %p39 = inttoptr i64 %v38 to ptr
  %ld40 = load i64, ptr %p39, align 8, !alias.scope !3, !noalias !4
  store i64 %ld40, ptr %slot8, align 8
  %v41 = load i64, ptr %slot8, align 8
  %op42 = add i64 %v41, 16
  store i64 %op42, ptr %slot9, align 8
  %v43 = load i64, ptr %slot9, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !4, !noalias !3
  store i64 %ld45, ptr %slot10, align 8
  %v46 = load i64, ptr %slot10, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot4, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot11, align 8
  %v52 = load i64, ptr %slot11, align 8
  %v53 = load i64, ptr %slot6, align 8
  %p54 = inttoptr i64 %v53 to ptr
  store i64 %v52, ptr %p54, align 8, !alias.scope !3, !noalias !4
  %v55 = load i64, ptr %slot6, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %ld57 = load i64, ptr %p56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld57, ptr %slot12, align 8
  %v58 = load i64, ptr %slot12, align 8
  %op59 = add i64 %v58, 0
  store i64 %op59, ptr %slot13, align 8
  %v60 = load i64, ptr %slot13, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %ld62 = load i64, ptr %p61, align 8, !alias.scope !4, !noalias !3
  store i64 %ld62, ptr %slot14, align 8
  %v63 = load i64, ptr %slot14, align 8
  %v64 = load i64, ptr %slot6, align 8
  %p65 = inttoptr i64 %v64 to ptr
  store i64 %v63, ptr %p65, align 8, !alias.scope !3, !noalias !4
  %v66 = load i64, ptr %slot6, align 8
  %p67 = inttoptr i64 %v66 to ptr
  %ld68 = load i64, ptr %p67, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot15, align 8
  %v69 = load i64, ptr %slot15, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !6, !noalias !7
  store i64 %ld71, ptr %slot16, align 8
  %v72 = load i64, ptr %slot16, align 8
  %v73 = load i64, ptr %slot6, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot6, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !3, !noalias !4
  store i64 %ld77, ptr %slot17, align 8
  %v78 = load i64, ptr %slot5, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot18, align 8
  %v81 = load i64, ptr %slot18, align 8
  %v82 = load i64, ptr %slot17, align 8
  %cmp83 = icmp sge i64 %v81, %v82
  %cv84 = zext i1 %cmp83 to i64
  store i64 %cv84, ptr %slot19, align 8
  %v85 = load i64, ptr %slot19, align 8
  %v86 = load i64, ptr %slot5, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot5, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot20, align 8
  %v91 = load i64, ptr %slot20, align 8
  ret i64 %v91
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_cee309a27b283a4be5f9baab4674598079b9ceb386edd14078c78a4dc4a34dd1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_cee309a27b283a4be5f9baab4674598079b9ceb386edd14078c78a4dc4a34dd1", linkageName: "myl_f_cee309a27b283a4be5f9baab4674598079b9ceb386edd14078c78a4dc4a34dd1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16583684216154426461, i64 0, !"myl_f_cee309a27b283a4be5f9baab4674598079b9ceb386edd14078c78a4dc4a34dd1"}
