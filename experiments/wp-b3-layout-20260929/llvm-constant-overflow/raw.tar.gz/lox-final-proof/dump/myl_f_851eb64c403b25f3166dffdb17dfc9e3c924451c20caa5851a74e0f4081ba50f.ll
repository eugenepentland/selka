target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v66 = load i64, ptr %slot1, align 8
  %op67 = add i64 %v66, 32
  store i64 %op67, ptr %slot4, align 8
  %mem68 = alloca i8, i64 16, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot5, align 8
  %mem70 = alloca i8, i64 8, align 8
  %ptr71 = ptrtoint ptr %mem70 to i64
  store i64 %ptr71, ptr %slot6, align 8
  %mem72 = alloca i8, i64 8, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot7, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot8, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot9, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot10, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot11, align 8
  %v82 = load i64, ptr %slot8, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 0, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot2, align 8
  %v85 = load i64, ptr %slot6, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  %v87 = load i64, ptr %slot3, align 8
  %v88 = load i64, ptr %slot7, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v90 = load i64, ptr %slot6, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot12, align 8
  %v93 = load i64, ptr %slot12, align 8
  %v94 = load i64, ptr %slot10, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot10, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot13, align 8
  %v99 = load i64, ptr %slot13, align 8
  %op100 = add i64 %v99, 120
  store i64 %op100, ptr %slot14, align 8
  %v101 = load i64, ptr %slot14, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !4, !noalias !3
  store i64 %ld103, ptr %slot15, align 8
  %v104 = load i64, ptr %slot15, align 8
  %v105 = load i64, ptr %slot10, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 %v104, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot10, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot16, align 8
  %v110 = load i64, ptr %slot8, align 8
  store i64 %v110, ptr %slot17, align 8
  %v111 = load i64, ptr %slot16, align 8
  %v112 = load i64, ptr %slot17, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot6, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld116, ptr %slot18, align 8
  %v117 = load i64, ptr %slot18, align 8
  %v118 = load i64, ptr %slot10, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot10, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot19, align 8
  %v123 = load i64, ptr %slot19, align 8
  %op124 = add i64 %v123, 128
  store i64 %op124, ptr %slot20, align 8
  %v125 = load i64, ptr %slot20, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !4, !noalias !3
  store i64 %ld127, ptr %slot21, align 8
  %v128 = load i64, ptr %slot21, align 8
  %v129 = load i64, ptr %slot10, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot11, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 1, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot11, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot22, align 8
  %v136 = load i64, ptr %slot10, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld138, ptr %slot23, align 8
  %v139 = load i64, ptr %slot23, align 8
  %v140 = load i64, ptr %slot22, align 8
  %ovpair142 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v139, i64 %v140)
  %op141 = extractvalue { i64, i1 } %ovpair142, 0
  %ov143 = extractvalue { i64, i1 } %ovpair142, 1
  store i64 %op141, ptr %slot24, align 8
  %cv144 = zext i1 %ov143 to i64
  store i64 %cv144, ptr %slot25, align 8
  %v145 = load i64, ptr %slot25, align 8
  %cond146 = icmp ne i64 %v145, 0
  br i1 %cond146, label %bb_overflow12, label %bb_checked12
bb_overflow12:
  %v147 = load i64, ptr %slot1, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %v149 = load i64, ptr %slot23, align 8
  %v150 = load i64, ptr %slot22, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p148, i64 1, i64 %v149, i64 %v150, i64 64) nomerge, !dbg !110
  unreachable
bb_checked12:
  %v151 = load i64, ptr %slot24, align 8
  %v152 = load i64, ptr %slot10, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot7, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot26, align 8
  %v157 = load i64, ptr %slot26, align 8
  %v158 = load i64, ptr %slot11, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot11, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot27, align 8
  %v163 = load i64, ptr %slot10, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot28, align 8
  %v166 = load i64, ptr %slot28, align 8
  %v167 = load i64, ptr %slot27, align 8
  %ovpair169 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v166, i64 %v167)
  %op168 = extractvalue { i64, i1 } %ovpair169, 0
  %ov170 = extractvalue { i64, i1 } %ovpair169, 1
  store i64 %op168, ptr %slot29, align 8
  %v171 = load i64, ptr %slot28, align 8
  %v172 = load i64, ptr %slot27, align 8
  %op173 = xor i64 %v171, %v172
  store i64 %op173, ptr %slot30, align 8
  %v174 = load i64, ptr %slot28, align 8
  %v175 = load i64, ptr %slot29, align 8
  %op176 = xor i64 %v174, %v175
  store i64 %op176, ptr %slot31, align 8
  %v177 = load i64, ptr %slot30, align 8
  %v178 = load i64, ptr %slot31, align 8
  %op179 = and i64 %v177, %v178
  store i64 %op179, ptr %slot32, align 8
  %cv180 = zext i1 %ov170 to i64
  store i64 %cv180, ptr %slot33, align 8
  %v181 = load i64, ptr %slot33, align 8
  %cond182 = icmp ne i64 %v181, 0
  br i1 %cond182, label %bb_overflow17, label %bb_checked17
bb_overflow17:
  %v183 = load i64, ptr %slot1, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %v185 = load i64, ptr %slot28, align 8
  %v186 = load i64, ptr %slot27, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p184, i64 1, i64 %v185, i64 %v186, i64 64) nomerge, !dbg !112
  unreachable
bb_checked17:
  %v187 = load i64, ptr %slot29, align 8
  %v188 = load i64, ptr %slot10, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot10, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot34, align 8
  %v193 = load i64, ptr %slot9, align 8
  store i64 %v193, ptr %slot35, align 8
  %v194 = load i64, ptr %slot34, align 8
  %v195 = load i64, ptr %slot35, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot9, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot36, align 8
  %v200 = load i64, ptr %slot36, align 8
  %v201 = load i64, ptr %slot10, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot11, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot11, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot37, align 8
  %v208 = load i64, ptr %slot10, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot38, align 8
  %v211 = load i64, ptr %slot38, align 8
  %v212 = load i64, ptr %slot37, align 8
  %cmp213 = icmp slt i64 %v211, %v212
  %cv214 = zext i1 %cmp213 to i64
  store i64 %cv214, ptr %slot39, align 8
  %v215 = load i64, ptr %slot39, align 8
  %v216 = load i64, ptr %slot10, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot10, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot40, align 8
  %v221 = load i64, ptr %slot40, align 8
  %cond222 = icmp ne i64 %v221, 0
  br i1 %cond222, label %bb_next29, label %bb_i19
bb_next29:
  %v223 = load i64, ptr %slot8, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i64, ptr %p224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot41, align 8
  %v226 = load i64, ptr %slot41, align 8
  %op227 = add i64 %v226, 0
  store i64 %op227, ptr %slot42, align 8
  %v228 = load i64, ptr %slot42, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !6, !noalias !7
  store i64 %ld230, ptr %slot43, align 8
  %v231 = load i64, ptr %slot43, align 8
  %v232 = load i64, ptr %slot10, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i64 %v231, ptr %p233, align 8, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot10, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot44, align 8
  %v237 = load i64, ptr %slot44, align 8
  %cmp238 = icmp ugt i64 %v237, 9223372036854775807
  %cv239 = zext i1 %cmp238 to i64
  store i64 %cv239, ptr %slot45, align 8
  %v240 = load i64, ptr %slot45, align 8
  %cond241 = icmp ne i64 %v240, 0
  br i1 %cond241, label %bb_cast_overflow34, label %bb_cast_ok34
bb_cast_overflow34:
  %v242 = load i64, ptr %slot1, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %v244 = load i64, ptr %slot44, align 8
  call void @myl_qbe_fail_cast(ptr %p243, i64 %v244, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok34:
  %v245 = load i64, ptr %slot44, align 8
  %v246 = load i64, ptr %slot10, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 %v245, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot9, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot46, align 8
  %v251 = load i64, ptr %slot46, align 8
  %v252 = load i64, ptr %slot11, align 8
  %p253 = inttoptr i64 %v252 to ptr
  store i64 %v251, ptr %p253, align 8, !alias.scope !3, !noalias !4
  %v254 = load i64, ptr %slot11, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot47, align 8
  %v257 = load i64, ptr %slot10, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot48, align 8
  %v260 = load i64, ptr %slot48, align 8
  %v261 = load i64, ptr %slot47, align 8
  %ovpair263 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v260, i64 %v261)
  %op262 = extractvalue { i64, i1 } %ovpair263, 0
  %ov264 = extractvalue { i64, i1 } %ovpair263, 1
  store i64 %op262, ptr %slot49, align 8
  %v265 = load i64, ptr %slot48, align 8
  %v266 = load i64, ptr %slot49, align 8
  %op267 = xor i64 %v265, %v266
  store i64 %op267, ptr %slot50, align 8
  %v268 = load i64, ptr %slot47, align 8
  %v269 = load i64, ptr %slot49, align 8
  %op270 = xor i64 %v268, %v269
  store i64 %op270, ptr %slot51, align 8
  %v271 = load i64, ptr %slot50, align 8
  %v272 = load i64, ptr %slot51, align 8
  %op273 = and i64 %v271, %v272
  store i64 %op273, ptr %slot52, align 8
  %cv274 = zext i1 %ov264 to i64
  store i64 %cv274, ptr %slot53, align 8
  %v275 = load i64, ptr %slot53, align 8
  %cond276 = icmp ne i64 %v275, 0
  br i1 %cond276, label %bb_overflow38, label %bb_checked38
bb_overflow38:
  %v277 = load i64, ptr %slot1, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %v279 = load i64, ptr %slot48, align 8
  %v280 = load i64, ptr %slot47, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p278, i64 0, i64 %v279, i64 %v280, i64 64) nomerge, !dbg !116
  unreachable
bb_checked38:
  %v281 = load i64, ptr %slot49, align 8
  %v282 = load i64, ptr %slot10, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot10, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot54, align 8
  %v287 = load i64, ptr %slot9, align 8
  store i64 %v287, ptr %slot55, align 8
  %v288 = load i64, ptr %slot54, align 8
  %v289 = load i64, ptr %slot55, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !3, !noalias !4
  br label %bb_i19
bb_i19:
  %v291 = load i64, ptr %slot9, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot56, align 8
  %v294 = load i64, ptr %slot56, align 8
  %v295 = load i64, ptr %slot10, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 %v294, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot8, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot57, align 8
  %v300 = load i64, ptr %slot10, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot58, align 8
  %v303 = load i64, ptr %slot57, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !6, !noalias !7
  store i64 %ld305, ptr %slot59, align 8
  %v306 = load i64, ptr %slot58, align 8
  %v307 = load i64, ptr %slot59, align 8
  %cmp308 = icmp ult i64 %v306, %v307
  %cv309 = zext i1 %cmp308 to i64
  store i64 %cv309, ptr %slot60, align 8
  %v310 = load i64, ptr %slot60, align 8
  %cond311 = icmp ne i64 %v310, 0
  br i1 %cond311, label %bb_success51, label %bb_failed51
bb_failed51:
  %v312 = load i64, ptr %slot1, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %v314 = load i64, ptr %slot58, align 8
  %v315 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p313, i64 %v314, i64 %v315) nomerge, !dbg !118
  unreachable
bb_success51:
  %v316 = load i64, ptr %slot57, align 8
  %op317 = add i64 %v316, 32
  store i64 %op317, ptr %slot61, align 8
  %v318 = load i64, ptr %slot61, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !6, !noalias !7
  store i64 %ld320, ptr %slot62, align 8
  %v321 = load i64, ptr %slot58, align 8
  %op322 = mul i64 %v321, 16
  store i64 %op322, ptr %slot63, align 8
  %v323 = load i64, ptr %slot62, align 8
  %v324 = load i64, ptr %slot63, align 8
  %op325 = add i64 %v323, %v324
  store i64 %op325, ptr %slot64, align 8
  %v326 = load i64, ptr %slot64, align 8
  %v327 = load i64, ptr %slot10, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot10, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot65, align 8
  %v332 = load i64, ptr %slot65, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ret334 = load { i64, i64 }, ptr %p333, align 8
  ret { i64, i64 } %ret334
bb_failure:
  %v335 = load i64, ptr %slot5, align 8
  %p336 = inttoptr i64 %v335 to ptr
  call void @llvm.memset.p0.i64(ptr %p336, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v337 = load i64, ptr %slot5, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ret339 = load { i64, i64 }, ptr %p338, align 8
  ret { i64, i64 } %ret339
bb_entry_failure:
  %v340 = load i64, ptr %slot5, align 8
  %p341 = inttoptr i64 %v340 to ptr
  call void @llvm.memset.p0.i64(ptr %p341, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v342 = load i64, ptr %slot5, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ret344 = load { i64, i64 }, ptr %p343, align 8
  ret { i64, i64 } %ret344
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f", linkageName: "myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7457872719242157329, i64 0, !"myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!110 = !DILocation(line: 7, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!112 = !DILocation(line: 9, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!116 = !DILocation(line: 18, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!118 = !DILocation(line: 21, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!120 = !DILocation(line: 22, column: 0, scope: !121)
