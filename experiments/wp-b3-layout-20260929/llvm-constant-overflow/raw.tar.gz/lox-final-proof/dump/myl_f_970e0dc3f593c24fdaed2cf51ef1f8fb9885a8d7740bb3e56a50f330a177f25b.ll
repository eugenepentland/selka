target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v346 = load i64, ptr %slot1, align 8
  %op347 = add i64 %v346, 32
  store i64 %op347, ptr %slot4, align 8
  %mem348 = alloca i8, i64 8, align 8
  %ptr349 = ptrtoint ptr %mem348 to i64
  store i64 %ptr349, ptr %slot5, align 8
  %mem350 = alloca i8, i64 8, align 8
  %ptr351 = ptrtoint ptr %mem350 to i64
  store i64 %ptr351, ptr %slot6, align 8
  %mem352 = alloca i8, i64 8, align 8
  %ptr353 = ptrtoint ptr %mem352 to i64
  store i64 %ptr353, ptr %slot7, align 8
  %mem354 = alloca i8, i64 8, align 8
  %ptr355 = ptrtoint ptr %mem354 to i64
  store i64 %ptr355, ptr %slot8, align 8
  %mem356 = alloca i8, i64 208, align 8
  %ptr357 = ptrtoint ptr %mem356 to i64
  store i64 %ptr357, ptr %slot9, align 8
  %mem358 = alloca i8, i64 8, align 8
  %ptr359 = ptrtoint ptr %mem358 to i64
  store i64 %ptr359, ptr %slot10, align 8
  %mem360 = alloca i8, i64 208, align 8
  %ptr361 = ptrtoint ptr %mem360 to i64
  store i64 %ptr361, ptr %slot11, align 8
  %mem362 = alloca i8, i64 8, align 8
  %ptr363 = ptrtoint ptr %mem362 to i64
  store i64 %ptr363, ptr %slot12, align 8
  %mem364 = alloca i8, i64 8, align 8
  %ptr365 = ptrtoint ptr %mem364 to i64
  store i64 %ptr365, ptr %slot13, align 8
  %mem366 = alloca i8, i64 8, align 8
  %ptr367 = ptrtoint ptr %mem366 to i64
  store i64 %ptr367, ptr %slot14, align 8
  %mem368 = alloca i8, i64 8, align 8
  %ptr369 = ptrtoint ptr %mem368 to i64
  store i64 %ptr369, ptr %slot15, align 8
  %mem370 = alloca i8, i64 8, align 8
  %ptr371 = ptrtoint ptr %mem370 to i64
  store i64 %ptr371, ptr %slot16, align 8
  %mem372 = alloca i8, i64 8, align 8
  %ptr373 = ptrtoint ptr %mem372 to i64
  store i64 %ptr373, ptr %slot17, align 8
  %mem374 = alloca i8, i64 8, align 8
  %ptr375 = ptrtoint ptr %mem374 to i64
  store i64 %ptr375, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem376 = alloca i8, i64 8, align 8
  %ptr377 = ptrtoint ptr %mem376 to i64
  store i64 %ptr377, ptr %slot19, align 8
  %v378 = load i64, ptr %slot1, align 8
  %op379 = add i64 %v378, 64
  store i64 %op379, ptr %slot20, align 8
  %v380 = load i64, ptr %slot20, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !4, !noalias !3
  store i64 %ld382, ptr %slot21, align 8
  %stack383 = call ptr @llvm.stacksave()
  %stackaddr384 = ptrtoint ptr %stack383 to i64
  %v385 = load i64, ptr %slot21, align 8
  %cmp386 = icmp ult i64 %stackaddr384, %v385
  %cv387 = zext i1 %cmp386 to i64
  store i64 %cv387, ptr %slot22, align 8
  %v388 = load i64, ptr %slot22, align 8
  %cond389 = icmp ne i64 %v388, 0
  br i1 %cond389, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v390 = load i64, ptr %slot1, align 8
  %p391 = inttoptr i64 %v390 to ptr
  call void @myl_qbe_fail_frame(ptr %p391) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v392 = load i64, ptr %slot2, align 8
  %v393 = load i64, ptr %slot12, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 %v392, ptr %p394, align 8, !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot3, align 8
  %v396 = load i64, ptr %slot13, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot1, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %call400 = call ptr @myl_qbe_heap(ptr %p399) nomerge, !dbg !112
  %calladdr401 = ptrtoint ptr %call400 to i64
  store i64 %calladdr401, ptr %slot23, align 8
  %v402 = load i64, ptr %slot1, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %call404 = call i64 @myl_qbe_region_mark(ptr %p403) nomerge, !dbg !112
  store i64 %call404, ptr %slot24, align 8
  %v405 = load i64, ptr %slot5, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i32 0, ptr %p406, align 4, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot6, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i32 0, ptr %p408, align 4, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot7, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i32 0, ptr %p410, align 4, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot8, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 0, ptr %p412, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v413 = load i64, ptr %slot13, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot25, align 8
  %v416 = load i64, ptr %slot25, align 8
  %v417 = load i64, ptr %slot17, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i64 %v416, ptr %p418, align 8, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot17, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %ld421 = load i64, ptr %p420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld421, ptr %slot26, align 8
  %v422 = load i64, ptr %slot26, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i32, ptr %p423, align 4, !alias.scope !4, !noalias !3
  %ext425 = zext i32 %ld424 to i64
  store i64 %ext425, ptr %slot27, align 8
  %v426 = load i64, ptr %slot27, align 8
  %cmp427 = icmp eq i64 %v426, 0
  %cv428 = zext i1 %cmp427 to i64
  store i64 %cv428, ptr %slot28, align 8
  %v429 = load i64, ptr %slot28, align 8
  %cond430 = icmp ne i64 %v429, 0
  br i1 %cond430, label %bb_rcarm11, label %bb_rcarmnext11
bb_rcarm11:
  br label %bb_i2
bb_rcarmnext11:
  %v431 = load i64, ptr %slot27, align 8
  %cmp432 = icmp eq i64 %v431, 1
  %cv433 = zext i1 %cmp432 to i64
  store i64 %cv433, ptr %slot29, align 8
  %v434 = load i64, ptr %slot29, align 8
  %cond435 = icmp ne i64 %v434, 0
  br i1 %cond435, label %bb_rcarm12, label %bb_rcarmnext12
bb_rcarm12:
  %v436 = load i64, ptr %slot11, align 8
  store i64 %v436, ptr %slot30, align 8
  %v437 = load i64, ptr %slot26, align 8
  %op438 = add i64 %v437, 8
  store i64 %op438, ptr %slot31, align 8
  %v439 = load i64, ptr %slot24, align 8
  store i64 %v439, ptr %slot32, align 8
  %v440 = load i64, ptr %slot31, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i8, ptr %p441, align 1, !alias.scope !4, !noalias !3
  %ext443 = zext i8 %ld442 to i64
  store i64 %ext443, ptr %slot33, align 8
  %v444 = load i64, ptr %slot33, align 8
  %cv445 = trunc i64 %v444 to i8
  %v446 = load i64, ptr %slot30, align 8
  %p447 = inttoptr i64 %v446 to ptr
  store i8 %cv445, ptr %p447, align 1, !alias.scope !3, !noalias !4
  %v448 = load i64, ptr %slot8, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i32 0, ptr %p449, align 4, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot7, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i32 1, ptr %p451, align 4, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot30, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i8, ptr %p453, align 1, !alias.scope !3, !noalias !4
  %ext455 = zext i8 %ld454 to i64
  store i64 %ext455, ptr %slot34, align 8
  %v456 = load i64, ptr %slot34, align 8
  %v457 = load i64, ptr %slot14, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot7, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i32 0, ptr %p460, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext12:
  %v461 = load i64, ptr %slot27, align 8
  %cmp462 = icmp eq i64 %v461, 2
  %cv463 = zext i1 %cmp462 to i64
  store i64 %cv463, ptr %slot35, align 8
  %v464 = load i64, ptr %slot35, align 8
  %cond465 = icmp ne i64 %v464, 0
  br i1 %cond465, label %bb_rcarm21, label %bb_rcarmnext21
bb_rcarm21:
  %v466 = load i64, ptr %slot11, align 8
  store i64 %v466, ptr %slot36, align 8
  %v467 = load i64, ptr %slot26, align 8
  %op468 = add i64 %v467, 8
  store i64 %op468, ptr %slot37, align 8
  %v469 = load i64, ptr %slot24, align 8
  store i64 %v469, ptr %slot38, align 8
  %v470 = load i64, ptr %slot37, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %ld472 = load i64, ptr %p471, align 8, !alias.scope !4, !noalias !3
  store i64 %ld472, ptr %slot39, align 8
  %v473 = load i64, ptr %slot39, align 8
  %v474 = load i64, ptr %slot36, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i64 %v473, ptr %p475, align 8, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot8, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 0, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot7, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 1, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot36, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld482, ptr %slot40, align 8
  %v483 = load i64, ptr %slot40, align 8
  %v484 = load i64, ptr %slot15, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 %v483, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot7, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 0, ptr %p487, align 4, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_rcarmnext21:
  %v488 = load i64, ptr %slot27, align 8
  %cmp489 = icmp eq i64 %v488, 3
  %cv490 = zext i1 %cmp489 to i64
  store i64 %cv490, ptr %slot41, align 8
  %v491 = load i64, ptr %slot41, align 8
  %cond492 = icmp ne i64 %v491, 0
  br i1 %cond492, label %bb_rcarm30, label %bb_rcarmnext30
bb_rcarm30:
  %v493 = load i64, ptr %slot11, align 8
  store i64 %v493, ptr %slot42, align 8
  %v494 = load i64, ptr %slot26, align 8
  %op495 = add i64 %v494, 8
  store i64 %op495, ptr %slot43, align 8
  %v496 = load i64, ptr %slot24, align 8
  store i64 %v496, ptr %slot44, align 8
  %v497 = load i64, ptr %slot43, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i64, ptr %p498, align 8, !alias.scope !4, !noalias !3
  store i64 %ld499, ptr %slot45, align 8
  %v500 = load i64, ptr %slot45, align 8
  %v501 = load i64, ptr %slot42, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i64 %v500, ptr %p502, align 8, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot8, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i32 0, ptr %p504, align 4, !alias.scope !3, !noalias !4
  %v505 = load i64, ptr %slot7, align 8
  %p506 = inttoptr i64 %v505 to ptr
  store i32 1, ptr %p506, align 4, !alias.scope !3, !noalias !4
  %v507 = load i64, ptr %slot42, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %ld509 = load i64, ptr %p508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld509, ptr %slot46, align 8
  %v510 = load i64, ptr %slot46, align 8
  %v511 = load i64, ptr %slot16, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i64 %v510, ptr %p512, align 8, !alias.scope !3, !noalias !4
  %v513 = load i64, ptr %slot7, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i32 0, ptr %p514, align 4, !alias.scope !3, !noalias !4
  br label %bb_i13
bb_rcarmnext30:
  br label %bb_failure
bb_i2:
  %p515 = inttoptr i64 ptrtoint (ptr @myl_lit_ba5e6ec8bcb62a3153e50652d005022189b30daccd5c1aad813c296e42b0e80a to i64) to ptr
  %ld516 = load i64, ptr %p515, align 8, !alias.scope !4, !noalias !3
  store i64 %ld516, ptr %slot47, align 8
  %v517 = load i64, ptr %slot47, align 8
  %v518 = load i64, ptr %slot17, align 8
  %p519 = inttoptr i64 %v518 to ptr
  store i64 %v517, ptr %p519, align 8, !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot17, align 8
  %p521 = inttoptr i64 %v520 to ptr
  %ld522 = load i64, ptr %p521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld522, ptr %slot48, align 8
  %v523 = load i64, ptr %slot48, align 8
  %v524 = load i64, ptr %slot10, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot10, align 8
  store i64 %v526, ptr %slot49, align 8
  %v527 = load i64, ptr %slot11, align 8
  store i64 %v527, ptr %slot50, align 8
  %v528 = load i64, ptr %slot49, align 8
  %v529 = load i64, ptr %slot50, align 8
  %p530 = inttoptr i64 %v528 to ptr
  %p531 = inttoptr i64 %v529 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p531, ptr %p530, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot8, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i32 2, ptr %p533, align 4, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot7, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 1, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot9, align 8
  store i64 %v536, ptr %slot51, align 8
  %v537 = load i64, ptr %slot11, align 8
  store i64 %v537, ptr %slot52, align 8
  %v538 = load i64, ptr %slot52, align 8
  %v539 = load i64, ptr %slot51, align 8
  %p540 = inttoptr i64 %v538 to ptr
  %p541 = inttoptr i64 %v539 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p541, ptr %p540, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot6, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i32 2, ptr %p543, align 4, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot8, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i32, ptr %p545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld546, ptr %slot53, align 8
  %v547 = load i32, ptr %slot53, align 8
  %v548 = load i64, ptr %slot6, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i32 %v547, ptr %p549, align 4, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot7, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i32 0, ptr %p551, align 4, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot5, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i32 1, ptr %p553, align 4, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot51, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %ld556 = load i64, ptr %p555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld556, ptr %slot54, align 8
  %v557 = load i64, ptr %slot54, align 8
  %v558 = load i64, ptr %slot17, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot17, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot55, align 8
  %v563 = load i64, ptr %slot17, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot56, align 8
  %v566 = load i64, ptr %slot56, align 8
  %v567 = load i64, ptr %slot10, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot10, align 8
  store i64 %v569, ptr %slot57, align 8
  %v570 = load i64, ptr %slot11, align 8
  store i64 %v570, ptr %slot58, align 8
  %v571 = load i64, ptr %slot24, align 8
  store i64 %v571, ptr %slot59, align 8
  %v572 = load i64, ptr %slot57, align 8
  %p574 = inttoptr i64 %v572 to ptr
  %gep575 = getelementptr i8, ptr %p574, i64 0
  %op573 = ptrtoint ptr %gep575 to i64
  store i64 %op573, ptr %slot60, align 8
  %v576 = load i64, ptr %slot60, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i64, ptr %p577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld578, ptr %slot61, align 8
  %v579 = load i64, ptr %slot61, align 8
  %cmp580 = icmp ne i64 %v579, 0
  %cv581 = zext i1 %cmp580 to i32
  store i32 %cv581, ptr %slot62, align 8
  %v582 = load i32, ptr %slot62, align 8
  %cv583 = zext i32 %v582 to i64
  %cond584 = icmp ne i64 %cv583, 0
  br i1 %cond584, label %bb_rcmoveheader63, label %bb_rcmovenext63
bb_rcmoveheader63:
  %v585 = load i64, ptr %slot61, align 8
  %op586 = sub i64 %v585, 16
  store i64 %op586, ptr %slot63, align 8
  %v587 = load i64, ptr %slot61, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %rgep589 = getelementptr i8, ptr %p588, i64 -16
  %ld590 = load i64, ptr %rgep589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld590, ptr %slot64, align 8
  %v591 = load i64, ptr %slot64, align 8
  %op592 = and i64 %v591, 5764607523034234881
  store i64 %op592, ptr %slot65, align 8
  %v593 = load i64, ptr %slot65, align 8
  %cmp594 = icmp ne i64 %v593, 0
  %cv595 = zext i1 %cmp594 to i32
  store i32 %cv595, ptr %slot66, align 8
  %v596 = load i32, ptr %slot66, align 8
  %cv597 = zext i32 %v596 to i64
  %cond598 = icmp ne i64 %cv597, 0
  br i1 %cond598, label %bb_rcmoveslow60, label %bb_rcmovenext63
bb_rcmovenext63:
  %v599 = load i64, ptr %slot57, align 8
  %v600 = load i64, ptr %slot58, align 8
  %p601 = inttoptr i64 %v599 to ptr
  %p602 = inttoptr i64 %v600 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p602, ptr %p601, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot57, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i64 0, ptr %p604, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved60
bb_rcmoveslow60:
  %v605 = load i64, ptr %slot23, align 8
  %v606 = load i64, ptr %slot58, align 8
  %v607 = load i64, ptr %slot57, align 8
  %v608 = load i64, ptr %slot59, align 8
  %cv609 = trunc i64 %v608 to i32
  %call610 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v605, i64 %v606, i64 %v607, i32 %cv609) nomerge, !dbg !114
  store i32 %call610, ptr %slot67, align 8
  %v611 = load i32, ptr %slot67, align 8
  %cv612 = zext i32 %v611 to i64
  %cond613 = icmp ne i64 %cv612, 0
  br i1 %cond613, label %bb_rcsuccess70, label %bb_rcfailure70
bb_rcfailure70:
  %v614 = load i64, ptr %slot23, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %call616 = call i32 @myl_rc_take_failure(ptr %p615) nomerge, !dbg !114
  store i32 %call616, ptr %slot68, align 8
  %v617 = load i64, ptr %slot1, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %v619 = load i32, ptr %slot68, align 8
  %call620 = call i32 @myl_qbe_rc_status(ptr %p618, i32 %v619) nomerge, !dbg !114
  store i32 %call620, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess70:
  br label %bb_rcmoved60
bb_rcmoved60:
  %v621 = load i64, ptr %slot5, align 8
  %p622 = inttoptr i64 %v621 to ptr
  store i32 0, ptr %p622, align 4, !alias.scope !3, !noalias !4
  %v623 = load i64, ptr %slot8, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i32 2, ptr %p624, align 4, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot7, align 8
  %p626 = inttoptr i64 %v625 to ptr
  store i32 1, ptr %p626, align 4, !alias.scope !3, !noalias !4
  %v627 = load i64, ptr %slot11, align 8
  store i64 %v627, ptr %slot70, align 8
  %v628 = load i64, ptr %slot70, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i64, ptr %p629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld630, ptr %slot71, align 8
  %v631 = load i64, ptr %slot7, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i32 0, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot5, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ld635 = load i32, ptr %p634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld635, ptr %slot72, align 8
  %v636 = load i32, ptr %slot72, align 8
  %cv637 = zext i32 %v636 to i64
  %cond638 = icmp ne i64 %cv637, 0
  br i1 %cond638, label %bb_rcslotdrop81, label %bb_rcslotdone81
bb_rcslotdrop81:
  %v639 = load i64, ptr %slot5, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i32 0, ptr %p640, align 4, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot9, align 8
  store i64 %v641, ptr %slot73, align 8
  %v642 = load i64, ptr %slot6, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %ld644 = load i32, ptr %p643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld644, ptr %slot74, align 8
  %v645 = load i32, ptr %slot74, align 8
  %op646 = and i32 %v645, 28
  store i32 %op646, ptr %slot75, align 8
  %v647 = load i32, ptr %slot75, align 8
  %cv648 = zext i32 %v647 to i64
  %cond649 = icmp ne i64 %cv648, 0
  br i1 %cond649, label %bb_rcslotrole81, label %bb_rcslotowner81
bb_rcslotrole81:
  %v650 = load i64, ptr %slot23, align 8
  store i64 %v650, ptr %slot76, align 8
  %v651 = load i64, ptr %slot73, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot77, align 8
  %v654 = load i64, ptr %slot77, align 8
  %cmp655 = icmp ne i64 %v654, 0
  %cv656 = zext i1 %cmp655 to i32
  store i32 %cv656, ptr %slot78, align 8
  %v657 = load i32, ptr %slot78, align 8
  %cv658 = zext i32 %v657 to i64
  %cond659 = icmp ne i64 %cv658, 0
  br i1 %cond659, label %bb_rcgnn97, label %bb_rcgdone97
bb_rcgnn97:
  %v660 = load i64, ptr %slot77, align 8
  %op661 = sub i64 %v660, 16
  store i64 %op661, ptr %slot79, align 8
  %v662 = load i64, ptr %slot77, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %rgep664 = getelementptr i8, ptr %p663, i64 -16
  %ld665 = load i64, ptr %rgep664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld665, ptr %slot80, align 8
  %v666 = load i64, ptr %slot80, align 8
  %op667 = and i64 %v666, 4611686018427387906
  store i64 %op667, ptr %slot81, align 8
  %v668 = load i64, ptr %slot81, align 8
  %cmp669 = icmp ne i64 %v668, 0
  %cv670 = zext i1 %cmp669 to i32
  store i32 %cv670, ptr %slot82, align 8
  %v671 = load i32, ptr %slot82, align 8
  %cv672 = zext i32 %v671 to i64
  %cond673 = icmp ne i64 %cv672, 0
  br i1 %cond673, label %bb_rcgclear97, label %bb_rcgcounted97
bb_rcgcounted97:
  %v674 = load i64, ptr %slot77, align 8
  %op675 = sub i64 %v674, 24
  store i64 %op675, ptr %slot83, align 8
  %v676 = load i64, ptr %slot77, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %rgep678 = getelementptr i8, ptr %p677, i64 -24
  %ld679 = load i64, ptr %rgep678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld679, ptr %slot84, align 8
  %v680 = load i64, ptr %slot84, align 8
  %op681 = sub i64 %v680, 1
  store i64 %op681, ptr %slot85, align 8
  %v682 = load i64, ptr %slot85, align 8
  %cmp683 = icmp eq i64 %v682, 0
  %cv684 = zext i1 %cmp683 to i32
  store i32 %cv684, ptr %slot86, align 8
  %v685 = load i32, ptr %slot86, align 8
  %cv686 = zext i32 %v685 to i64
  %cond687 = icmp ne i64 %cv686, 0
  br i1 %cond687, label %bb_rcglast97, label %bb_rcgdec97
bb_rcglast97:
  %v688 = load i64, ptr %slot77, align 8
  %op689 = sub i64 %v688, 32
  store i64 %op689, ptr %slot87, align 8
  %v690 = load i64, ptr %slot77, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %rgep692 = getelementptr i8, ptr %p691, i64 -32
  %ld693 = load i64, ptr %rgep692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld693, ptr %slot88, align 8
  %v694 = load i64, ptr %slot88, align 8
  %cmp695 = icmp ne i64 %v694, 0
  %cv696 = zext i1 %cmp695 to i32
  store i32 %cv696, ptr %slot89, align 8
  %v697 = load i32, ptr %slot89, align 8
  %cv698 = zext i32 %v697 to i64
  %cond699 = icmp ne i64 %cv698, 0
  br i1 %cond699, label %bb_rcgdec97, label %bb_rcgslow97
bb_rcgslow97:
  %v700 = load i64, ptr %slot76, align 8
  %v701 = load i64, ptr %slot73, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v700, i64 %v701) nomerge, !dbg !114
  br label %bb_rcgdone97
bb_rcgdec97:
  %v702 = load i64, ptr %slot85, align 8
  %v703 = load i64, ptr %slot77, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %rgep705 = getelementptr i8, ptr %p704, i64 -24
  store i64 %v702, ptr %rgep705, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear97
bb_rcgclear97:
  %v706 = load i64, ptr %slot73, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i64 0, ptr %p707, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone97
bb_rcgdone97:
  br label %bb_rcslotdone81
bb_rcslotowner81:
  %v708 = load i64, ptr %slot23, align 8
  store i64 %v708, ptr %slot90, align 8
  %v709 = load i64, ptr %slot73, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %ld711 = load i64, ptr %p710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld711, ptr %slot91, align 8
  %v712 = load i64, ptr %slot91, align 8
  %cmp713 = icmp ne i64 %v712, 0
  %cv714 = zext i1 %cmp713 to i32
  store i32 %cv714, ptr %slot92, align 8
  %v715 = load i32, ptr %slot92, align 8
  %cv716 = zext i32 %v715 to i64
  %cond717 = icmp ne i64 %cv716, 0
  br i1 %cond717, label %bb_rcgnn112, label %bb_rcgdone112
bb_rcgnn112:
  %v718 = load i64, ptr %slot91, align 8
  %op719 = sub i64 %v718, 16
  store i64 %op719, ptr %slot93, align 8
  %v720 = load i64, ptr %slot91, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %rgep722 = getelementptr i8, ptr %p721, i64 -16
  %ld723 = load i64, ptr %rgep722, align 8, !alias.scope !9, !noalias !10
  store i64 %ld723, ptr %slot94, align 8
  %v724 = load i64, ptr %slot94, align 8
  %op725 = and i64 %v724, 4611686018427387906
  store i64 %op725, ptr %slot95, align 8
  %v726 = load i64, ptr %slot95, align 8
  %cmp727 = icmp ne i64 %v726, 0
  %cv728 = zext i1 %cmp727 to i32
  store i32 %cv728, ptr %slot96, align 8
  %v729 = load i32, ptr %slot96, align 8
  %cv730 = zext i32 %v729 to i64
  %cond731 = icmp ne i64 %cv730, 0
  br i1 %cond731, label %bb_rcgclear112, label %bb_rcgcounted112
bb_rcgcounted112:
  %v732 = load i64, ptr %slot91, align 8
  %op733 = sub i64 %v732, 32
  store i64 %op733, ptr %slot97, align 8
  %v734 = load i64, ptr %slot91, align 8
  %p735 = inttoptr i64 %v734 to ptr
  %rgep736 = getelementptr i8, ptr %p735, i64 -32
  %ld737 = load i64, ptr %rgep736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld737, ptr %slot98, align 8
  %v738 = load i64, ptr %slot98, align 8
  %op739 = sub i64 %v738, 1
  store i64 %op739, ptr %slot99, align 8
  %v740 = load i64, ptr %slot99, align 8
  %cmp741 = icmp eq i64 %v740, 0
  %cv742 = zext i1 %cmp741 to i32
  store i32 %cv742, ptr %slot100, align 8
  %v743 = load i32, ptr %slot100, align 8
  %cv744 = zext i32 %v743 to i64
  %cond745 = icmp ne i64 %cv744, 0
  br i1 %cond745, label %bb_rcglast112, label %bb_rcgdec112
bb_rcglast112:
  %v746 = load i64, ptr %slot91, align 8
  %op747 = sub i64 %v746, 24
  store i64 %op747, ptr %slot101, align 8
  %v748 = load i64, ptr %slot91, align 8
  %p749 = inttoptr i64 %v748 to ptr
  %rgep750 = getelementptr i8, ptr %p749, i64 -24
  %ld751 = load i64, ptr %rgep750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld751, ptr %slot102, align 8
  %v752 = load i64, ptr %slot102, align 8
  %cmp753 = icmp ne i64 %v752, 0
  %cv754 = zext i1 %cmp753 to i32
  store i32 %cv754, ptr %slot103, align 8
  %v755 = load i32, ptr %slot103, align 8
  %cv756 = zext i32 %v755 to i64
  %cond757 = icmp ne i64 %cv756, 0
  br i1 %cond757, label %bb_rcgdec112, label %bb_rcgslow112
bb_rcgslow112:
  %v758 = load i64, ptr %slot90, align 8
  %v759 = load i64, ptr %slot73, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v758, i64 %v759) nomerge, !dbg !114
  br label %bb_rcgdone112
bb_rcgdec112:
  %v760 = load i64, ptr %slot99, align 8
  %v761 = load i64, ptr %slot91, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %rgep763 = getelementptr i8, ptr %p762, i64 -32
  store i64 %v760, ptr %rgep763, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear112
bb_rcgclear112:
  %v764 = load i64, ptr %slot73, align 8
  %p765 = inttoptr i64 %v764 to ptr
  store i64 0, ptr %p765, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone112
bb_rcgdone112:
  br label %bb_rcslotdone81
bb_rcslotdone81:
  %v766 = load i64, ptr %slot71, align 8
  ret i64 %v766
bb_i4:
  %v767 = load i64, ptr %slot14, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i64, ptr %p768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld769, ptr %slot104, align 8
  %v770 = load i64, ptr %slot104, align 8
  %v771 = load i64, ptr %slot17, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i64 %v770, ptr %p772, align 8, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot17, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %ld775 = load i64, ptr %p774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld775, ptr %slot105, align 8
  %v776 = load i64, ptr %slot105, align 8
  %cond777 = icmp ne i64 %v776, 0
  br i1 %cond777, label %bb_next127, label %bb_i8
bb_next127:
  %p778 = inttoptr i64 ptrtoint (ptr @myl_lit_aeb0fdeeaad337003da49a9520ef2341c721f8fadd313ec215e1b80fc0a989d3 to i64) to ptr
  %ld779 = load i64, ptr %p778, align 8, !alias.scope !4, !noalias !3
  store i64 %ld779, ptr %slot106, align 8
  %v780 = load i64, ptr %slot106, align 8
  %v781 = load i64, ptr %slot17, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i64 %v780, ptr %p782, align 8, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot17, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot107, align 8
  %v786 = load i64, ptr %slot107, align 8
  %v787 = load i64, ptr %slot10, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 %v786, ptr %p788, align 8, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot10, align 8
  store i64 %v789, ptr %slot108, align 8
  %v790 = load i64, ptr %slot11, align 8
  store i64 %v790, ptr %slot109, align 8
  %v791 = load i64, ptr %slot108, align 8
  %v792 = load i64, ptr %slot109, align 8
  %p793 = inttoptr i64 %v791 to ptr
  %p794 = inttoptr i64 %v792 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p794, ptr %p793, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v795 = load i64, ptr %slot8, align 8
  %p796 = inttoptr i64 %v795 to ptr
  store i32 2, ptr %p796, align 4, !alias.scope !3, !noalias !4
  %v797 = load i64, ptr %slot7, align 8
  %p798 = inttoptr i64 %v797 to ptr
  store i32 1, ptr %p798, align 4, !alias.scope !3, !noalias !4
  %v799 = load i64, ptr %slot9, align 8
  store i64 %v799, ptr %slot110, align 8
  %v800 = load i64, ptr %slot11, align 8
  store i64 %v800, ptr %slot111, align 8
  %v801 = load i64, ptr %slot111, align 8
  %v802 = load i64, ptr %slot110, align 8
  %p803 = inttoptr i64 %v801 to ptr
  %p804 = inttoptr i64 %v802 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p804, ptr %p803, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot6, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i32 2, ptr %p806, align 4, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot8, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %ld809 = load i32, ptr %p808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld809, ptr %slot112, align 8
  %v810 = load i32, ptr %slot112, align 8
  %v811 = load i64, ptr %slot6, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i32 %v810, ptr %p812, align 4, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot7, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i32 0, ptr %p814, align 4, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot5, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i32 1, ptr %p816, align 4, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot110, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot113, align 8
  %v820 = load i64, ptr %slot113, align 8
  %v821 = load i64, ptr %slot17, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i64 %v820, ptr %p822, align 8, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot17, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot114, align 8
  %v826 = load i64, ptr %slot17, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld828, ptr %slot115, align 8
  %v829 = load i64, ptr %slot115, align 8
  %v830 = load i64, ptr %slot10, align 8
  %p831 = inttoptr i64 %v830 to ptr
  store i64 %v829, ptr %p831, align 8, !alias.scope !3, !noalias !4
  %v832 = load i64, ptr %slot10, align 8
  store i64 %v832, ptr %slot116, align 8
  %v833 = load i64, ptr %slot11, align 8
  store i64 %v833, ptr %slot117, align 8
  %v834 = load i64, ptr %slot24, align 8
  store i64 %v834, ptr %slot118, align 8
  %v835 = load i64, ptr %slot116, align 8
  %p837 = inttoptr i64 %v835 to ptr
  %gep838 = getelementptr i8, ptr %p837, i64 0
  %op836 = ptrtoint ptr %gep838 to i64
  store i64 %op836, ptr %slot119, align 8
  %v839 = load i64, ptr %slot119, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot120, align 8
  %v842 = load i64, ptr %slot120, align 8
  %cmp843 = icmp ne i64 %v842, 0
  %cv844 = zext i1 %cmp843 to i32
  store i32 %cv844, ptr %slot121, align 8
  %v845 = load i32, ptr %slot121, align 8
  %cv846 = zext i32 %v845 to i64
  %cond847 = icmp ne i64 %cv846, 0
  br i1 %cond847, label %bb_rcmoveheader151, label %bb_rcmovenext151
bb_rcmoveheader151:
  %v848 = load i64, ptr %slot120, align 8
  %op849 = sub i64 %v848, 16
  store i64 %op849, ptr %slot122, align 8
  %v850 = load i64, ptr %slot120, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %rgep852 = getelementptr i8, ptr %p851, i64 -16
  %ld853 = load i64, ptr %rgep852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld853, ptr %slot123, align 8
  %v854 = load i64, ptr %slot123, align 8
  %op855 = and i64 %v854, 5764607523034234881
  store i64 %op855, ptr %slot124, align 8
  %v856 = load i64, ptr %slot124, align 8
  %cmp857 = icmp ne i64 %v856, 0
  %cv858 = zext i1 %cmp857 to i32
  store i32 %cv858, ptr %slot125, align 8
  %v859 = load i32, ptr %slot125, align 8
  %cv860 = zext i32 %v859 to i64
  %cond861 = icmp ne i64 %cv860, 0
  br i1 %cond861, label %bb_rcmoveslow148, label %bb_rcmovenext151
bb_rcmovenext151:
  %v862 = load i64, ptr %slot116, align 8
  %v863 = load i64, ptr %slot117, align 8
  %p864 = inttoptr i64 %v862 to ptr
  %p865 = inttoptr i64 %v863 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p865, ptr %p864, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot116, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i64 0, ptr %p867, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved148
bb_rcmoveslow148:
  %v868 = load i64, ptr %slot23, align 8
  %v869 = load i64, ptr %slot117, align 8
  %v870 = load i64, ptr %slot116, align 8
  %v871 = load i64, ptr %slot118, align 8
  %cv872 = trunc i64 %v871 to i32
  %call873 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v868, i64 %v869, i64 %v870, i32 %cv872) nomerge, !dbg !116
  store i32 %call873, ptr %slot126, align 8
  %v874 = load i32, ptr %slot126, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcsuccess158, label %bb_rcfailure158
bb_rcfailure158:
  %v877 = load i64, ptr %slot23, align 8
  %p878 = inttoptr i64 %v877 to ptr
  %call879 = call i32 @myl_rc_take_failure(ptr %p878) nomerge, !dbg !116
  store i32 %call879, ptr %slot127, align 8
  %v880 = load i64, ptr %slot1, align 8
  %p881 = inttoptr i64 %v880 to ptr
  %v882 = load i32, ptr %slot127, align 8
  %call883 = call i32 @myl_qbe_rc_status(ptr %p881, i32 %v882) nomerge, !dbg !116
  store i32 %call883, ptr %slot128, align 8
  br label %bb_failure
bb_rcsuccess158:
  br label %bb_rcmoved148
bb_rcmoved148:
  %v884 = load i64, ptr %slot5, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i32 0, ptr %p885, align 4, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot8, align 8
  %p887 = inttoptr i64 %v886 to ptr
  store i32 2, ptr %p887, align 4, !alias.scope !3, !noalias !4
  %v888 = load i64, ptr %slot7, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i32 1, ptr %p889, align 4, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot11, align 8
  store i64 %v890, ptr %slot129, align 8
  %v891 = load i64, ptr %slot129, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %ld893 = load i64, ptr %p892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld893, ptr %slot130, align 8
  %v894 = load i64, ptr %slot7, align 8
  %p895 = inttoptr i64 %v894 to ptr
  store i32 0, ptr %p895, align 4, !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot5, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %ld898 = load i32, ptr %p897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld898, ptr %slot131, align 8
  %v899 = load i32, ptr %slot131, align 8
  %cv900 = zext i32 %v899 to i64
  %cond901 = icmp ne i64 %cv900, 0
  br i1 %cond901, label %bb_rcslotdrop169, label %bb_rcslotdone169
bb_rcslotdrop169:
  %v902 = load i64, ptr %slot5, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i32 0, ptr %p903, align 4, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot9, align 8
  store i64 %v904, ptr %slot132, align 8
  %v905 = load i64, ptr %slot6, align 8
  %p906 = inttoptr i64 %v905 to ptr
  %ld907 = load i32, ptr %p906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld907, ptr %slot133, align 8
  %v908 = load i32, ptr %slot133, align 8
  %op909 = and i32 %v908, 28
  store i32 %op909, ptr %slot134, align 8
  %v910 = load i32, ptr %slot134, align 8
  %cv911 = zext i32 %v910 to i64
  %cond912 = icmp ne i64 %cv911, 0
  br i1 %cond912, label %bb_rcslotrole169, label %bb_rcslotowner169
bb_rcslotrole169:
  %v913 = load i64, ptr %slot23, align 8
  store i64 %v913, ptr %slot135, align 8
  %v914 = load i64, ptr %slot132, align 8
  %p915 = inttoptr i64 %v914 to ptr
  %ld916 = load i64, ptr %p915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld916, ptr %slot136, align 8
  %v917 = load i64, ptr %slot136, align 8
  %cmp918 = icmp ne i64 %v917, 0
  %cv919 = zext i1 %cmp918 to i32
  store i32 %cv919, ptr %slot137, align 8
  %v920 = load i32, ptr %slot137, align 8
  %cv921 = zext i32 %v920 to i64
  %cond922 = icmp ne i64 %cv921, 0
  br i1 %cond922, label %bb_rcgnn185, label %bb_rcgdone185
bb_rcgnn185:
  %v923 = load i64, ptr %slot136, align 8
  %op924 = sub i64 %v923, 16
  store i64 %op924, ptr %slot138, align 8
  %v925 = load i64, ptr %slot136, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %rgep927 = getelementptr i8, ptr %p926, i64 -16
  %ld928 = load i64, ptr %rgep927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld928, ptr %slot139, align 8
  %v929 = load i64, ptr %slot139, align 8
  %op930 = and i64 %v929, 4611686018427387906
  store i64 %op930, ptr %slot140, align 8
  %v931 = load i64, ptr %slot140, align 8
  %cmp932 = icmp ne i64 %v931, 0
  %cv933 = zext i1 %cmp932 to i32
  store i32 %cv933, ptr %slot141, align 8
  %v934 = load i32, ptr %slot141, align 8
  %cv935 = zext i32 %v934 to i64
  %cond936 = icmp ne i64 %cv935, 0
  br i1 %cond936, label %bb_rcgclear185, label %bb_rcgcounted185
bb_rcgcounted185:
  %v937 = load i64, ptr %slot136, align 8
  %op938 = sub i64 %v937, 24
  store i64 %op938, ptr %slot142, align 8
  %v939 = load i64, ptr %slot136, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %rgep941 = getelementptr i8, ptr %p940, i64 -24
  %ld942 = load i64, ptr %rgep941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld942, ptr %slot143, align 8
  %v943 = load i64, ptr %slot143, align 8
  %op944 = sub i64 %v943, 1
  store i64 %op944, ptr %slot144, align 8
  %v945 = load i64, ptr %slot144, align 8
  %cmp946 = icmp eq i64 %v945, 0
  %cv947 = zext i1 %cmp946 to i32
  store i32 %cv947, ptr %slot145, align 8
  %v948 = load i32, ptr %slot145, align 8
  %cv949 = zext i32 %v948 to i64
  %cond950 = icmp ne i64 %cv949, 0
  br i1 %cond950, label %bb_rcglast185, label %bb_rcgdec185
bb_rcglast185:
  %v951 = load i64, ptr %slot136, align 8
  %op952 = sub i64 %v951, 32
  store i64 %op952, ptr %slot146, align 8
  %v953 = load i64, ptr %slot136, align 8
  %p954 = inttoptr i64 %v953 to ptr
  %rgep955 = getelementptr i8, ptr %p954, i64 -32
  %ld956 = load i64, ptr %rgep955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld956, ptr %slot147, align 8
  %v957 = load i64, ptr %slot147, align 8
  %cmp958 = icmp ne i64 %v957, 0
  %cv959 = zext i1 %cmp958 to i32
  store i32 %cv959, ptr %slot148, align 8
  %v960 = load i32, ptr %slot148, align 8
  %cv961 = zext i32 %v960 to i64
  %cond962 = icmp ne i64 %cv961, 0
  br i1 %cond962, label %bb_rcgdec185, label %bb_rcgslow185
bb_rcgslow185:
  %v963 = load i64, ptr %slot135, align 8
  %v964 = load i64, ptr %slot132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v963, i64 %v964) nomerge, !dbg !116
  br label %bb_rcgdone185
bb_rcgdec185:
  %v965 = load i64, ptr %slot144, align 8
  %v966 = load i64, ptr %slot136, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %rgep968 = getelementptr i8, ptr %p967, i64 -24
  store i64 %v965, ptr %rgep968, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear185
bb_rcgclear185:
  %v969 = load i64, ptr %slot132, align 8
  %p970 = inttoptr i64 %v969 to ptr
  store i64 0, ptr %p970, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone185
bb_rcgdone185:
  br label %bb_rcslotdone169
bb_rcslotowner169:
  %v971 = load i64, ptr %slot23, align 8
  store i64 %v971, ptr %slot149, align 8
  %v972 = load i64, ptr %slot132, align 8
  %p973 = inttoptr i64 %v972 to ptr
  %ld974 = load i64, ptr %p973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld974, ptr %slot150, align 8
  %v975 = load i64, ptr %slot150, align 8
  %cmp976 = icmp ne i64 %v975, 0
  %cv977 = zext i1 %cmp976 to i32
  store i32 %cv977, ptr %slot151, align 8
  %v978 = load i32, ptr %slot151, align 8
  %cv979 = zext i32 %v978 to i64
  %cond980 = icmp ne i64 %cv979, 0
  br i1 %cond980, label %bb_rcgnn200, label %bb_rcgdone200
bb_rcgnn200:
  %v981 = load i64, ptr %slot150, align 8
  %op982 = sub i64 %v981, 16
  store i64 %op982, ptr %slot152, align 8
  %v983 = load i64, ptr %slot150, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %rgep985 = getelementptr i8, ptr %p984, i64 -16
  %ld986 = load i64, ptr %rgep985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld986, ptr %slot153, align 8
  %v987 = load i64, ptr %slot153, align 8
  %op988 = and i64 %v987, 4611686018427387906
  store i64 %op988, ptr %slot154, align 8
  %v989 = load i64, ptr %slot154, align 8
  %cmp990 = icmp ne i64 %v989, 0
  %cv991 = zext i1 %cmp990 to i32
  store i32 %cv991, ptr %slot155, align 8
  %v992 = load i32, ptr %slot155, align 8
  %cv993 = zext i32 %v992 to i64
  %cond994 = icmp ne i64 %cv993, 0
  br i1 %cond994, label %bb_rcgclear200, label %bb_rcgcounted200
bb_rcgcounted200:
  %v995 = load i64, ptr %slot150, align 8
  %op996 = sub i64 %v995, 32
  store i64 %op996, ptr %slot156, align 8
  %v997 = load i64, ptr %slot150, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %rgep999 = getelementptr i8, ptr %p998, i64 -32
  %ld1000 = load i64, ptr %rgep999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1000, ptr %slot157, align 8
  %v1001 = load i64, ptr %slot157, align 8
  %op1002 = sub i64 %v1001, 1
  store i64 %op1002, ptr %slot158, align 8
  %v1003 = load i64, ptr %slot158, align 8
  %cmp1004 = icmp eq i64 %v1003, 0
  %cv1005 = zext i1 %cmp1004 to i32
  store i32 %cv1005, ptr %slot159, align 8
  %v1006 = load i32, ptr %slot159, align 8
  %cv1007 = zext i32 %v1006 to i64
  %cond1008 = icmp ne i64 %cv1007, 0
  br i1 %cond1008, label %bb_rcglast200, label %bb_rcgdec200
bb_rcglast200:
  %v1009 = load i64, ptr %slot150, align 8
  %op1010 = sub i64 %v1009, 24
  store i64 %op1010, ptr %slot160, align 8
  %v1011 = load i64, ptr %slot150, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %rgep1013 = getelementptr i8, ptr %p1012, i64 -24
  %ld1014 = load i64, ptr %rgep1013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1014, ptr %slot161, align 8
  %v1015 = load i64, ptr %slot161, align 8
  %cmp1016 = icmp ne i64 %v1015, 0
  %cv1017 = zext i1 %cmp1016 to i32
  store i32 %cv1017, ptr %slot162, align 8
  %v1018 = load i32, ptr %slot162, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcgdec200, label %bb_rcgslow200
bb_rcgslow200:
  %v1021 = load i64, ptr %slot149, align 8
  %v1022 = load i64, ptr %slot132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1021, i64 %v1022) nomerge, !dbg !116
  br label %bb_rcgdone200
bb_rcgdec200:
  %v1023 = load i64, ptr %slot158, align 8
  %v1024 = load i64, ptr %slot150, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %rgep1026 = getelementptr i8, ptr %p1025, i64 -32
  store i64 %v1023, ptr %rgep1026, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear200
bb_rcgclear200:
  %v1027 = load i64, ptr %slot132, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i64 0, ptr %p1028, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone200
bb_rcgdone200:
  br label %bb_rcslotdone169
bb_rcslotdone169:
  %v1029 = load i64, ptr %slot130, align 8
  ret i64 %v1029
bb_i8:
  %p1030 = inttoptr i64 ptrtoint (ptr @myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8 to i64) to ptr
  %ld1031 = load i64, ptr %p1030, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1031, ptr %slot163, align 8
  %v1032 = load i64, ptr %slot163, align 8
  %v1033 = load i64, ptr %slot17, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  store i64 %v1032, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  %v1035 = load i64, ptr %slot17, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i64, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1037, ptr %slot164, align 8
  %v1038 = load i64, ptr %slot164, align 8
  %v1039 = load i64, ptr %slot10, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i64 %v1038, ptr %p1040, align 8, !alias.scope !3, !noalias !4
  %v1041 = load i64, ptr %slot10, align 8
  store i64 %v1041, ptr %slot165, align 8
  %v1042 = load i64, ptr %slot11, align 8
  store i64 %v1042, ptr %slot166, align 8
  %v1043 = load i64, ptr %slot165, align 8
  %v1044 = load i64, ptr %slot166, align 8
  %p1045 = inttoptr i64 %v1043 to ptr
  %p1046 = inttoptr i64 %v1044 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1046, ptr %p1045, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot8, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i32 2, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot7, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i32 1, ptr %p1050, align 4, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot9, align 8
  store i64 %v1051, ptr %slot167, align 8
  %v1052 = load i64, ptr %slot11, align 8
  store i64 %v1052, ptr %slot168, align 8
  %v1053 = load i64, ptr %slot168, align 8
  %v1054 = load i64, ptr %slot167, align 8
  %p1055 = inttoptr i64 %v1053 to ptr
  %p1056 = inttoptr i64 %v1054 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1056, ptr %p1055, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot6, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 2, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot8, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %ld1061 = load i32, ptr %p1060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1061, ptr %slot169, align 8
  %v1062 = load i32, ptr %slot169, align 8
  %v1063 = load i64, ptr %slot6, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  store i32 %v1062, ptr %p1064, align 4, !alias.scope !3, !noalias !4
  %v1065 = load i64, ptr %slot7, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  store i32 0, ptr %p1066, align 4, !alias.scope !3, !noalias !4
  %v1067 = load i64, ptr %slot5, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i32 1, ptr %p1068, align 4, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot167, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  %ld1071 = load i64, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1071, ptr %slot170, align 8
  %v1072 = load i64, ptr %slot170, align 8
  %v1073 = load i64, ptr %slot17, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  store i64 %v1072, ptr %p1074, align 8, !alias.scope !3, !noalias !4
  %v1075 = load i64, ptr %slot17, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  %ld1077 = load i64, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1077, ptr %slot171, align 8
  %v1078 = load i64, ptr %slot17, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %ld1080 = load i64, ptr %p1079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1080, ptr %slot172, align 8
  %v1081 = load i64, ptr %slot172, align 8
  %v1082 = load i64, ptr %slot10, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i64 %v1081, ptr %p1083, align 8, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot10, align 8
  store i64 %v1084, ptr %slot173, align 8
  %v1085 = load i64, ptr %slot11, align 8
  store i64 %v1085, ptr %slot174, align 8
  %v1086 = load i64, ptr %slot24, align 8
  store i64 %v1086, ptr %slot175, align 8
  %v1087 = load i64, ptr %slot173, align 8
  %p1089 = inttoptr i64 %v1087 to ptr
  %gep1090 = getelementptr i8, ptr %p1089, i64 0
  %op1088 = ptrtoint ptr %gep1090 to i64
  store i64 %op1088, ptr %slot176, align 8
  %v1091 = load i64, ptr %slot176, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %ld1093 = load i64, ptr %p1092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1093, ptr %slot177, align 8
  %v1094 = load i64, ptr %slot177, align 8
  %cmp1095 = icmp ne i64 %v1094, 0
  %cv1096 = zext i1 %cmp1095 to i32
  store i32 %cv1096, ptr %slot178, align 8
  %v1097 = load i32, ptr %slot178, align 8
  %cv1098 = zext i32 %v1097 to i64
  %cond1099 = icmp ne i64 %cv1098, 0
  br i1 %cond1099, label %bb_rcmoveheader237, label %bb_rcmovenext237
bb_rcmoveheader237:
  %v1100 = load i64, ptr %slot177, align 8
  %op1101 = sub i64 %v1100, 16
  store i64 %op1101, ptr %slot179, align 8
  %v1102 = load i64, ptr %slot177, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  %rgep1104 = getelementptr i8, ptr %p1103, i64 -16
  %ld1105 = load i64, ptr %rgep1104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1105, ptr %slot180, align 8
  %v1106 = load i64, ptr %slot180, align 8
  %op1107 = and i64 %v1106, 5764607523034234881
  store i64 %op1107, ptr %slot181, align 8
  %v1108 = load i64, ptr %slot181, align 8
  %cmp1109 = icmp ne i64 %v1108, 0
  %cv1110 = zext i1 %cmp1109 to i32
  store i32 %cv1110, ptr %slot182, align 8
  %v1111 = load i32, ptr %slot182, align 8
  %cv1112 = zext i32 %v1111 to i64
  %cond1113 = icmp ne i64 %cv1112, 0
  br i1 %cond1113, label %bb_rcmoveslow234, label %bb_rcmovenext237
bb_rcmovenext237:
  %v1114 = load i64, ptr %slot173, align 8
  %v1115 = load i64, ptr %slot174, align 8
  %p1116 = inttoptr i64 %v1114 to ptr
  %p1117 = inttoptr i64 %v1115 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1117, ptr %p1116, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot173, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i64 0, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved234
bb_rcmoveslow234:
  %v1120 = load i64, ptr %slot23, align 8
  %v1121 = load i64, ptr %slot174, align 8
  %v1122 = load i64, ptr %slot173, align 8
  %v1123 = load i64, ptr %slot175, align 8
  %cv1124 = trunc i64 %v1123 to i32
  %call1125 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1120, i64 %v1121, i64 %v1122, i32 %cv1124) nomerge, !dbg !118
  store i32 %call1125, ptr %slot183, align 8
  %v1126 = load i32, ptr %slot183, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcsuccess244, label %bb_rcfailure244
bb_rcfailure244:
  %v1129 = load i64, ptr %slot23, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %call1131 = call i32 @myl_rc_take_failure(ptr %p1130) nomerge, !dbg !118
  store i32 %call1131, ptr %slot184, align 8
  %v1132 = load i64, ptr %slot1, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  %v1134 = load i32, ptr %slot184, align 8
  %call1135 = call i32 @myl_qbe_rc_status(ptr %p1133, i32 %v1134) nomerge, !dbg !118
  store i32 %call1135, ptr %slot185, align 8
  br label %bb_failure
bb_rcsuccess244:
  br label %bb_rcmoved234
bb_rcmoved234:
  %v1136 = load i64, ptr %slot5, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  store i32 0, ptr %p1137, align 4, !alias.scope !3, !noalias !4
  %v1138 = load i64, ptr %slot8, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i32 2, ptr %p1139, align 4, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot7, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 1, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot11, align 8
  store i64 %v1142, ptr %slot186, align 8
  %v1143 = load i64, ptr %slot186, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i64, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1145, ptr %slot187, align 8
  %v1146 = load i64, ptr %slot7, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 0, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot5, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i32, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1150, ptr %slot188, align 8
  %v1151 = load i32, ptr %slot188, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcslotdrop255, label %bb_rcslotdone255
bb_rcslotdrop255:
  %v1154 = load i64, ptr %slot5, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i32 0, ptr %p1155, align 4, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot9, align 8
  store i64 %v1156, ptr %slot189, align 8
  %v1157 = load i64, ptr %slot6, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  %ld1159 = load i32, ptr %p1158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1159, ptr %slot190, align 8
  %v1160 = load i32, ptr %slot190, align 8
  %op1161 = and i32 %v1160, 28
  store i32 %op1161, ptr %slot191, align 8
  %v1162 = load i32, ptr %slot191, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcslotrole255, label %bb_rcslotowner255
bb_rcslotrole255:
  %v1165 = load i64, ptr %slot23, align 8
  store i64 %v1165, ptr %slot192, align 8
  %v1166 = load i64, ptr %slot189, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i64, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1168, ptr %slot193, align 8
  %v1169 = load i64, ptr %slot193, align 8
  %cmp1170 = icmp ne i64 %v1169, 0
  %cv1171 = zext i1 %cmp1170 to i32
  store i32 %cv1171, ptr %slot194, align 8
  %v1172 = load i32, ptr %slot194, align 8
  %cv1173 = zext i32 %v1172 to i64
  %cond1174 = icmp ne i64 %cv1173, 0
  br i1 %cond1174, label %bb_rcgnn271, label %bb_rcgdone271
bb_rcgnn271:
  %v1175 = load i64, ptr %slot193, align 8
  %op1176 = sub i64 %v1175, 16
  store i64 %op1176, ptr %slot195, align 8
  %v1177 = load i64, ptr %slot193, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %rgep1179 = getelementptr i8, ptr %p1178, i64 -16
  %ld1180 = load i64, ptr %rgep1179, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1180, ptr %slot196, align 8
  %v1181 = load i64, ptr %slot196, align 8
  %op1182 = and i64 %v1181, 4611686018427387906
  store i64 %op1182, ptr %slot197, align 8
  %v1183 = load i64, ptr %slot197, align 8
  %cmp1184 = icmp ne i64 %v1183, 0
  %cv1185 = zext i1 %cmp1184 to i32
  store i32 %cv1185, ptr %slot198, align 8
  %v1186 = load i32, ptr %slot198, align 8
  %cv1187 = zext i32 %v1186 to i64
  %cond1188 = icmp ne i64 %cv1187, 0
  br i1 %cond1188, label %bb_rcgclear271, label %bb_rcgcounted271
bb_rcgcounted271:
  %v1189 = load i64, ptr %slot193, align 8
  %op1190 = sub i64 %v1189, 24
  store i64 %op1190, ptr %slot199, align 8
  %v1191 = load i64, ptr %slot193, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %rgep1193 = getelementptr i8, ptr %p1192, i64 -24
  %ld1194 = load i64, ptr %rgep1193, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1194, ptr %slot200, align 8
  %v1195 = load i64, ptr %slot200, align 8
  %op1196 = sub i64 %v1195, 1
  store i64 %op1196, ptr %slot201, align 8
  %v1197 = load i64, ptr %slot201, align 8
  %cmp1198 = icmp eq i64 %v1197, 0
  %cv1199 = zext i1 %cmp1198 to i32
  store i32 %cv1199, ptr %slot202, align 8
  %v1200 = load i32, ptr %slot202, align 8
  %cv1201 = zext i32 %v1200 to i64
  %cond1202 = icmp ne i64 %cv1201, 0
  br i1 %cond1202, label %bb_rcglast271, label %bb_rcgdec271
bb_rcglast271:
  %v1203 = load i64, ptr %slot193, align 8
  %op1204 = sub i64 %v1203, 32
  store i64 %op1204, ptr %slot203, align 8
  %v1205 = load i64, ptr %slot193, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %rgep1207 = getelementptr i8, ptr %p1206, i64 -32
  %ld1208 = load i64, ptr %rgep1207, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1208, ptr %slot204, align 8
  %v1209 = load i64, ptr %slot204, align 8
  %cmp1210 = icmp ne i64 %v1209, 0
  %cv1211 = zext i1 %cmp1210 to i32
  store i32 %cv1211, ptr %slot205, align 8
  %v1212 = load i32, ptr %slot205, align 8
  %cv1213 = zext i32 %v1212 to i64
  %cond1214 = icmp ne i64 %cv1213, 0
  br i1 %cond1214, label %bb_rcgdec271, label %bb_rcgslow271
bb_rcgslow271:
  %v1215 = load i64, ptr %slot192, align 8
  %v1216 = load i64, ptr %slot189, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1215, i64 %v1216) nomerge, !dbg !118
  br label %bb_rcgdone271
bb_rcgdec271:
  %v1217 = load i64, ptr %slot201, align 8
  %v1218 = load i64, ptr %slot193, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  %rgep1220 = getelementptr i8, ptr %p1219, i64 -24
  store i64 %v1217, ptr %rgep1220, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear271
bb_rcgclear271:
  %v1221 = load i64, ptr %slot189, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i64 0, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone271
bb_rcgdone271:
  br label %bb_rcslotdone255
bb_rcslotowner255:
  %v1223 = load i64, ptr %slot23, align 8
  store i64 %v1223, ptr %slot206, align 8
  %v1224 = load i64, ptr %slot189, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i64, ptr %p1225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1226, ptr %slot207, align 8
  %v1227 = load i64, ptr %slot207, align 8
  %cmp1228 = icmp ne i64 %v1227, 0
  %cv1229 = zext i1 %cmp1228 to i32
  store i32 %cv1229, ptr %slot208, align 8
  %v1230 = load i32, ptr %slot208, align 8
  %cv1231 = zext i32 %v1230 to i64
  %cond1232 = icmp ne i64 %cv1231, 0
  br i1 %cond1232, label %bb_rcgnn286, label %bb_rcgdone286
bb_rcgnn286:
  %v1233 = load i64, ptr %slot207, align 8
  %op1234 = sub i64 %v1233, 16
  store i64 %op1234, ptr %slot209, align 8
  %v1235 = load i64, ptr %slot207, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %rgep1237 = getelementptr i8, ptr %p1236, i64 -16
  %ld1238 = load i64, ptr %rgep1237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1238, ptr %slot210, align 8
  %v1239 = load i64, ptr %slot210, align 8
  %op1240 = and i64 %v1239, 4611686018427387906
  store i64 %op1240, ptr %slot211, align 8
  %v1241 = load i64, ptr %slot211, align 8
  %cmp1242 = icmp ne i64 %v1241, 0
  %cv1243 = zext i1 %cmp1242 to i32
  store i32 %cv1243, ptr %slot212, align 8
  %v1244 = load i32, ptr %slot212, align 8
  %cv1245 = zext i32 %v1244 to i64
  %cond1246 = icmp ne i64 %cv1245, 0
  br i1 %cond1246, label %bb_rcgclear286, label %bb_rcgcounted286
bb_rcgcounted286:
  %v1247 = load i64, ptr %slot207, align 8
  %op1248 = sub i64 %v1247, 32
  store i64 %op1248, ptr %slot213, align 8
  %v1249 = load i64, ptr %slot207, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %rgep1251 = getelementptr i8, ptr %p1250, i64 -32
  %ld1252 = load i64, ptr %rgep1251, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1252, ptr %slot214, align 8
  %v1253 = load i64, ptr %slot214, align 8
  %op1254 = sub i64 %v1253, 1
  store i64 %op1254, ptr %slot215, align 8
  %v1255 = load i64, ptr %slot215, align 8
  %cmp1256 = icmp eq i64 %v1255, 0
  %cv1257 = zext i1 %cmp1256 to i32
  store i32 %cv1257, ptr %slot216, align 8
  %v1258 = load i32, ptr %slot216, align 8
  %cv1259 = zext i32 %v1258 to i64
  %cond1260 = icmp ne i64 %cv1259, 0
  br i1 %cond1260, label %bb_rcglast286, label %bb_rcgdec286
bb_rcglast286:
  %v1261 = load i64, ptr %slot207, align 8
  %op1262 = sub i64 %v1261, 24
  store i64 %op1262, ptr %slot217, align 8
  %v1263 = load i64, ptr %slot207, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %rgep1265 = getelementptr i8, ptr %p1264, i64 -24
  %ld1266 = load i64, ptr %rgep1265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1266, ptr %slot218, align 8
  %v1267 = load i64, ptr %slot218, align 8
  %cmp1268 = icmp ne i64 %v1267, 0
  %cv1269 = zext i1 %cmp1268 to i32
  store i32 %cv1269, ptr %slot219, align 8
  %v1270 = load i32, ptr %slot219, align 8
  %cv1271 = zext i32 %v1270 to i64
  %cond1272 = icmp ne i64 %cv1271, 0
  br i1 %cond1272, label %bb_rcgdec286, label %bb_rcgslow286
bb_rcgslow286:
  %v1273 = load i64, ptr %slot206, align 8
  %v1274 = load i64, ptr %slot189, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1273, i64 %v1274) nomerge, !dbg !118
  br label %bb_rcgdone286
bb_rcgdec286:
  %v1275 = load i64, ptr %slot215, align 8
  %v1276 = load i64, ptr %slot207, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %rgep1278 = getelementptr i8, ptr %p1277, i64 -32
  store i64 %v1275, ptr %rgep1278, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear286
bb_rcgclear286:
  %v1279 = load i64, ptr %slot189, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i64 0, ptr %p1280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone286
bb_rcgdone286:
  br label %bb_rcslotdone255
bb_rcslotdone255:
  %v1281 = load i64, ptr %slot187, align 8
  ret i64 %v1281
bb_i10:
  %v1282 = load i64, ptr %slot15, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  %ld1284 = load i64, ptr %p1283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1284, ptr %slot220, align 8
  %v1285 = load i64, ptr %slot220, align 8
  %v1286 = load i64, ptr %slot17, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 %v1285, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  %v1288 = load i64, ptr %slot17, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i64, ptr %p1289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1290, ptr %slot221, align 8
  %v1291 = load i64, ptr %slot1, align 8
  %v1292 = load i64, ptr %slot221, align 8
  %call1293 = call i64 @myl_f_f76151122d7f44fd9f99cc06e8901ecc3f4e4ebfc159bdea41c016ba858eaa14(i64 %v1291, i64 %v1292) nomerge, !dbg !120
  store i64 %call1293, ptr %slot222, align 8
  %v1294 = load i64, ptr %slot222, align 8
  %v1295 = load i64, ptr %slot17, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i64 %v1294, ptr %p1296, align 8, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot17, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i64, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1299, ptr %slot223, align 8
  %v1300 = load i64, ptr %slot223, align 8
  %v1301 = load i64, ptr %slot10, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  store i64 %v1300, ptr %p1302, align 8, !alias.scope !3, !noalias !4
  %v1303 = load i64, ptr %slot10, align 8
  store i64 %v1303, ptr %slot224, align 8
  %v1304 = load i64, ptr %slot11, align 8
  store i64 %v1304, ptr %slot225, align 8
  %v1305 = load i64, ptr %slot224, align 8
  %v1306 = load i64, ptr %slot225, align 8
  %p1307 = inttoptr i64 %v1305 to ptr
  %p1308 = inttoptr i64 %v1306 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1308, ptr %p1307, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot8, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i32 2, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot7, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  store i32 1, ptr %p1312, align 4, !alias.scope !3, !noalias !4
  %v1313 = load i64, ptr %slot9, align 8
  store i64 %v1313, ptr %slot226, align 8
  %v1314 = load i64, ptr %slot11, align 8
  store i64 %v1314, ptr %slot227, align 8
  %v1315 = load i64, ptr %slot227, align 8
  %v1316 = load i64, ptr %slot226, align 8
  %p1317 = inttoptr i64 %v1315 to ptr
  %p1318 = inttoptr i64 %v1316 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1318, ptr %p1317, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1319 = load i64, ptr %slot6, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  store i32 2, ptr %p1320, align 4, !alias.scope !3, !noalias !4
  %v1321 = load i64, ptr %slot8, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  %ld1323 = load i32, ptr %p1322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1323, ptr %slot228, align 8
  %v1324 = load i32, ptr %slot228, align 8
  %v1325 = load i64, ptr %slot6, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  store i32 %v1324, ptr %p1326, align 4, !alias.scope !3, !noalias !4
  %v1327 = load i64, ptr %slot7, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  store i32 0, ptr %p1328, align 4, !alias.scope !3, !noalias !4
  %v1329 = load i64, ptr %slot5, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  store i32 1, ptr %p1330, align 4, !alias.scope !3, !noalias !4
  %v1331 = load i64, ptr %slot226, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %ld1333 = load i64, ptr %p1332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1333, ptr %slot229, align 8
  %v1334 = load i64, ptr %slot229, align 8
  %v1335 = load i64, ptr %slot17, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i64 %v1334, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot17, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i64, ptr %p1338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1339, ptr %slot230, align 8
  %v1340 = load i64, ptr %slot17, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  %ld1342 = load i64, ptr %p1341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1342, ptr %slot231, align 8
  %v1343 = load i64, ptr %slot231, align 8
  %v1344 = load i64, ptr %slot10, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i64 %v1343, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot10, align 8
  store i64 %v1346, ptr %slot232, align 8
  %v1347 = load i64, ptr %slot11, align 8
  store i64 %v1347, ptr %slot233, align 8
  %v1348 = load i64, ptr %slot24, align 8
  store i64 %v1348, ptr %slot234, align 8
  %v1349 = load i64, ptr %slot232, align 8
  %p1351 = inttoptr i64 %v1349 to ptr
  %gep1352 = getelementptr i8, ptr %p1351, i64 0
  %op1350 = ptrtoint ptr %gep1352 to i64
  store i64 %op1350, ptr %slot235, align 8
  %v1353 = load i64, ptr %slot235, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i64, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1355, ptr %slot236, align 8
  %v1356 = load i64, ptr %slot236, align 8
  %cmp1357 = icmp ne i64 %v1356, 0
  %cv1358 = zext i1 %cmp1357 to i32
  store i32 %cv1358, ptr %slot237, align 8
  %v1359 = load i32, ptr %slot237, align 8
  %cv1360 = zext i32 %v1359 to i64
  %cond1361 = icmp ne i64 %cv1360, 0
  br i1 %cond1361, label %bb_rcmoveheader324, label %bb_rcmovenext324
bb_rcmoveheader324:
  %v1362 = load i64, ptr %slot236, align 8
  %op1363 = sub i64 %v1362, 16
  store i64 %op1363, ptr %slot238, align 8
  %v1364 = load i64, ptr %slot236, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %rgep1366 = getelementptr i8, ptr %p1365, i64 -16
  %ld1367 = load i64, ptr %rgep1366, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1367, ptr %slot239, align 8
  %v1368 = load i64, ptr %slot239, align 8
  %op1369 = and i64 %v1368, 5764607523034234881
  store i64 %op1369, ptr %slot240, align 8
  %v1370 = load i64, ptr %slot240, align 8
  %cmp1371 = icmp ne i64 %v1370, 0
  %cv1372 = zext i1 %cmp1371 to i32
  store i32 %cv1372, ptr %slot241, align 8
  %v1373 = load i32, ptr %slot241, align 8
  %cv1374 = zext i32 %v1373 to i64
  %cond1375 = icmp ne i64 %cv1374, 0
  br i1 %cond1375, label %bb_rcmoveslow321, label %bb_rcmovenext324
bb_rcmovenext324:
  %v1376 = load i64, ptr %slot232, align 8
  %v1377 = load i64, ptr %slot233, align 8
  %p1378 = inttoptr i64 %v1376 to ptr
  %p1379 = inttoptr i64 %v1377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1379, ptr %p1378, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot232, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i64 0, ptr %p1381, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved321
bb_rcmoveslow321:
  %v1382 = load i64, ptr %slot23, align 8
  %v1383 = load i64, ptr %slot233, align 8
  %v1384 = load i64, ptr %slot232, align 8
  %v1385 = load i64, ptr %slot234, align 8
  %cv1386 = trunc i64 %v1385 to i32
  %call1387 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1382, i64 %v1383, i64 %v1384, i32 %cv1386) nomerge, !dbg !122
  store i32 %call1387, ptr %slot242, align 8
  %v1388 = load i32, ptr %slot242, align 8
  %cv1389 = zext i32 %v1388 to i64
  %cond1390 = icmp ne i64 %cv1389, 0
  br i1 %cond1390, label %bb_rcsuccess331, label %bb_rcfailure331
bb_rcfailure331:
  %v1391 = load i64, ptr %slot23, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %call1393 = call i32 @myl_rc_take_failure(ptr %p1392) nomerge, !dbg !122
  store i32 %call1393, ptr %slot243, align 8
  %v1394 = load i64, ptr %slot1, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %v1396 = load i32, ptr %slot243, align 8
  %call1397 = call i32 @myl_qbe_rc_status(ptr %p1395, i32 %v1396) nomerge, !dbg !122
  store i32 %call1397, ptr %slot244, align 8
  br label %bb_failure
bb_rcsuccess331:
  br label %bb_rcmoved321
bb_rcmoved321:
  %v1398 = load i64, ptr %slot5, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot8, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 2, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot7, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 1, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot11, align 8
  store i64 %v1404, ptr %slot245, align 8
  %v1405 = load i64, ptr %slot245, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot246, align 8
  %v1408 = load i64, ptr %slot7, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i32 0, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  %v1410 = load i64, ptr %slot5, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  %ld1412 = load i32, ptr %p1411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1412, ptr %slot247, align 8
  %v1413 = load i32, ptr %slot247, align 8
  %cv1414 = zext i32 %v1413 to i64
  %cond1415 = icmp ne i64 %cv1414, 0
  br i1 %cond1415, label %bb_rcslotdrop342, label %bb_rcslotdone342
bb_rcslotdrop342:
  %v1416 = load i64, ptr %slot5, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  store i32 0, ptr %p1417, align 4, !alias.scope !3, !noalias !4
  %v1418 = load i64, ptr %slot9, align 8
  store i64 %v1418, ptr %slot248, align 8
  %v1419 = load i64, ptr %slot6, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i32, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1421, ptr %slot249, align 8
  %v1422 = load i32, ptr %slot249, align 8
  %op1423 = and i32 %v1422, 28
  store i32 %op1423, ptr %slot250, align 8
  %v1424 = load i32, ptr %slot250, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rcslotrole342, label %bb_rcslotowner342
bb_rcslotrole342:
  %v1427 = load i64, ptr %slot23, align 8
  store i64 %v1427, ptr %slot251, align 8
  %v1428 = load i64, ptr %slot248, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %ld1430 = load i64, ptr %p1429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1430, ptr %slot252, align 8
  %v1431 = load i64, ptr %slot252, align 8
  %cmp1432 = icmp ne i64 %v1431, 0
  %cv1433 = zext i1 %cmp1432 to i32
  store i32 %cv1433, ptr %slot253, align 8
  %v1434 = load i32, ptr %slot253, align 8
  %cv1435 = zext i32 %v1434 to i64
  %cond1436 = icmp ne i64 %cv1435, 0
  br i1 %cond1436, label %bb_rcgnn358, label %bb_rcgdone358
bb_rcgnn358:
  %v1437 = load i64, ptr %slot252, align 8
  %op1438 = sub i64 %v1437, 16
  store i64 %op1438, ptr %slot254, align 8
  %v1439 = load i64, ptr %slot252, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %rgep1441 = getelementptr i8, ptr %p1440, i64 -16
  %ld1442 = load i64, ptr %rgep1441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1442, ptr %slot255, align 8
  %v1443 = load i64, ptr %slot255, align 8
  %op1444 = and i64 %v1443, 4611686018427387906
  store i64 %op1444, ptr %slot256, align 8
  %v1445 = load i64, ptr %slot256, align 8
  %cmp1446 = icmp ne i64 %v1445, 0
  %cv1447 = zext i1 %cmp1446 to i32
  store i32 %cv1447, ptr %slot257, align 8
  %v1448 = load i32, ptr %slot257, align 8
  %cv1449 = zext i32 %v1448 to i64
  %cond1450 = icmp ne i64 %cv1449, 0
  br i1 %cond1450, label %bb_rcgclear358, label %bb_rcgcounted358
bb_rcgcounted358:
  %v1451 = load i64, ptr %slot252, align 8
  %op1452 = sub i64 %v1451, 24
  store i64 %op1452, ptr %slot258, align 8
  %v1453 = load i64, ptr %slot252, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %rgep1455 = getelementptr i8, ptr %p1454, i64 -24
  %ld1456 = load i64, ptr %rgep1455, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1456, ptr %slot259, align 8
  %v1457 = load i64, ptr %slot259, align 8
  %op1458 = sub i64 %v1457, 1
  store i64 %op1458, ptr %slot260, align 8
  %v1459 = load i64, ptr %slot260, align 8
  %cmp1460 = icmp eq i64 %v1459, 0
  %cv1461 = zext i1 %cmp1460 to i32
  store i32 %cv1461, ptr %slot261, align 8
  %v1462 = load i32, ptr %slot261, align 8
  %cv1463 = zext i32 %v1462 to i64
  %cond1464 = icmp ne i64 %cv1463, 0
  br i1 %cond1464, label %bb_rcglast358, label %bb_rcgdec358
bb_rcglast358:
  %v1465 = load i64, ptr %slot252, align 8
  %op1466 = sub i64 %v1465, 32
  store i64 %op1466, ptr %slot262, align 8
  %v1467 = load i64, ptr %slot252, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %rgep1469 = getelementptr i8, ptr %p1468, i64 -32
  %ld1470 = load i64, ptr %rgep1469, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1470, ptr %slot263, align 8
  %v1471 = load i64, ptr %slot263, align 8
  %cmp1472 = icmp ne i64 %v1471, 0
  %cv1473 = zext i1 %cmp1472 to i32
  store i32 %cv1473, ptr %slot264, align 8
  %v1474 = load i32, ptr %slot264, align 8
  %cv1475 = zext i32 %v1474 to i64
  %cond1476 = icmp ne i64 %cv1475, 0
  br i1 %cond1476, label %bb_rcgdec358, label %bb_rcgslow358
bb_rcgslow358:
  %v1477 = load i64, ptr %slot251, align 8
  %v1478 = load i64, ptr %slot248, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1477, i64 %v1478) nomerge, !dbg !122
  br label %bb_rcgdone358
bb_rcgdec358:
  %v1479 = load i64, ptr %slot260, align 8
  %v1480 = load i64, ptr %slot252, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  %rgep1482 = getelementptr i8, ptr %p1481, i64 -24
  store i64 %v1479, ptr %rgep1482, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear358
bb_rcgclear358:
  %v1483 = load i64, ptr %slot248, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i64 0, ptr %p1484, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone358
bb_rcgdone358:
  br label %bb_rcslotdone342
bb_rcslotowner342:
  %v1485 = load i64, ptr %slot23, align 8
  store i64 %v1485, ptr %slot265, align 8
  %v1486 = load i64, ptr %slot248, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %ld1488 = load i64, ptr %p1487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1488, ptr %slot266, align 8
  %v1489 = load i64, ptr %slot266, align 8
  %cmp1490 = icmp ne i64 %v1489, 0
  %cv1491 = zext i1 %cmp1490 to i32
  store i32 %cv1491, ptr %slot267, align 8
  %v1492 = load i32, ptr %slot267, align 8
  %cv1493 = zext i32 %v1492 to i64
  %cond1494 = icmp ne i64 %cv1493, 0
  br i1 %cond1494, label %bb_rcgnn373, label %bb_rcgdone373
bb_rcgnn373:
  %v1495 = load i64, ptr %slot266, align 8
  %op1496 = sub i64 %v1495, 16
  store i64 %op1496, ptr %slot268, align 8
  %v1497 = load i64, ptr %slot266, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  %rgep1499 = getelementptr i8, ptr %p1498, i64 -16
  %ld1500 = load i64, ptr %rgep1499, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1500, ptr %slot269, align 8
  %v1501 = load i64, ptr %slot269, align 8
  %op1502 = and i64 %v1501, 4611686018427387906
  store i64 %op1502, ptr %slot270, align 8
  %v1503 = load i64, ptr %slot270, align 8
  %cmp1504 = icmp ne i64 %v1503, 0
  %cv1505 = zext i1 %cmp1504 to i32
  store i32 %cv1505, ptr %slot271, align 8
  %v1506 = load i32, ptr %slot271, align 8
  %cv1507 = zext i32 %v1506 to i64
  %cond1508 = icmp ne i64 %cv1507, 0
  br i1 %cond1508, label %bb_rcgclear373, label %bb_rcgcounted373
bb_rcgcounted373:
  %v1509 = load i64, ptr %slot266, align 8
  %op1510 = sub i64 %v1509, 32
  store i64 %op1510, ptr %slot272, align 8
  %v1511 = load i64, ptr %slot266, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %rgep1513 = getelementptr i8, ptr %p1512, i64 -32
  %ld1514 = load i64, ptr %rgep1513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1514, ptr %slot273, align 8
  %v1515 = load i64, ptr %slot273, align 8
  %op1516 = sub i64 %v1515, 1
  store i64 %op1516, ptr %slot274, align 8
  %v1517 = load i64, ptr %slot274, align 8
  %cmp1518 = icmp eq i64 %v1517, 0
  %cv1519 = zext i1 %cmp1518 to i32
  store i32 %cv1519, ptr %slot275, align 8
  %v1520 = load i32, ptr %slot275, align 8
  %cv1521 = zext i32 %v1520 to i64
  %cond1522 = icmp ne i64 %cv1521, 0
  br i1 %cond1522, label %bb_rcglast373, label %bb_rcgdec373
bb_rcglast373:
  %v1523 = load i64, ptr %slot266, align 8
  %op1524 = sub i64 %v1523, 24
  store i64 %op1524, ptr %slot276, align 8
  %v1525 = load i64, ptr %slot266, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %rgep1527 = getelementptr i8, ptr %p1526, i64 -24
  %ld1528 = load i64, ptr %rgep1527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1528, ptr %slot277, align 8
  %v1529 = load i64, ptr %slot277, align 8
  %cmp1530 = icmp ne i64 %v1529, 0
  %cv1531 = zext i1 %cmp1530 to i32
  store i32 %cv1531, ptr %slot278, align 8
  %v1532 = load i32, ptr %slot278, align 8
  %cv1533 = zext i32 %v1532 to i64
  %cond1534 = icmp ne i64 %cv1533, 0
  br i1 %cond1534, label %bb_rcgdec373, label %bb_rcgslow373
bb_rcgslow373:
  %v1535 = load i64, ptr %slot265, align 8
  %v1536 = load i64, ptr %slot248, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1535, i64 %v1536) nomerge, !dbg !122
  br label %bb_rcgdone373
bb_rcgdec373:
  %v1537 = load i64, ptr %slot274, align 8
  %v1538 = load i64, ptr %slot266, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  %rgep1540 = getelementptr i8, ptr %p1539, i64 -32
  store i64 %v1537, ptr %rgep1540, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear373
bb_rcgclear373:
  %v1541 = load i64, ptr %slot248, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i64 0, ptr %p1542, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone373
bb_rcgdone373:
  br label %bb_rcslotdone342
bb_rcslotdone342:
  %v1543 = load i64, ptr %slot246, align 8
  ret i64 %v1543
bb_i13:
  %v1544 = load i64, ptr %slot12, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %ld1546 = load i64, ptr %p1545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1546, ptr %slot279, align 8
  %v1547 = load i64, ptr %slot279, align 8
  %v1548 = load i64, ptr %slot17, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i64 %v1547, ptr %p1549, align 8, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot16, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  %ld1552 = load i64, ptr %p1551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1552, ptr %slot280, align 8
  %v1553 = load i64, ptr %slot280, align 8
  %v1554 = load i64, ptr %slot18, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  store i64 %v1553, ptr %p1555, align 8, !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot17, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  %ld1558 = load i64, ptr %p1557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1558, ptr %slot281, align 8
  %v1559 = load i64, ptr %slot18, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot282, align 8
  %v1562 = load i64, ptr %slot1, align 8
  %v1563 = load i64, ptr %slot281, align 8
  %v1564 = load i64, ptr %slot282, align 8
  %call1565 = call i64 @myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0(i64 %v1562, i64 %v1563, i64 %v1564) nomerge, !dbg !124
  store i64 %call1565, ptr %slot283, align 8
  %v1566 = load i64, ptr %slot283, align 8
  %v1567 = load i64, ptr %slot17, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i64 %v1566, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot17, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %ld1571 = load i64, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1571, ptr %slot284, align 8
  %v1572 = load i64, ptr %slot284, align 8
  %v1573 = load i64, ptr %slot10, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i64 %v1572, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot10, align 8
  store i64 %v1575, ptr %slot285, align 8
  %v1576 = load i64, ptr %slot11, align 8
  store i64 %v1576, ptr %slot286, align 8
  %v1577 = load i64, ptr %slot285, align 8
  %v1578 = load i64, ptr %slot286, align 8
  %p1579 = inttoptr i64 %v1577 to ptr
  %p1580 = inttoptr i64 %v1578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1580, ptr %p1579, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot8, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 2, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot7, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 1, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot5, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %ld1587 = load i32, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1587, ptr %slot287, align 8
  %v1588 = load i32, ptr %slot287, align 8
  %cv1589 = zext i32 %v1588 to i64
  %cond1590 = icmp ne i64 %cv1589, 0
  br i1 %cond1590, label %bb_rcslotdrop398, label %bb_rcslotdone398
bb_rcslotdrop398:
  %v1591 = load i64, ptr %slot5, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 0, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot9, align 8
  store i64 %v1593, ptr %slot288, align 8
  %v1594 = load i64, ptr %slot6, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  %ld1596 = load i32, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1596, ptr %slot289, align 8
  %v1597 = load i32, ptr %slot289, align 8
  %op1598 = and i32 %v1597, 28
  store i32 %op1598, ptr %slot290, align 8
  %v1599 = load i32, ptr %slot290, align 8
  %cv1600 = zext i32 %v1599 to i64
  %cond1601 = icmp ne i64 %cv1600, 0
  br i1 %cond1601, label %bb_rcslotrole398, label %bb_rcslotowner398
bb_rcslotrole398:
  %v1602 = load i64, ptr %slot23, align 8
  store i64 %v1602, ptr %slot291, align 8
  %v1603 = load i64, ptr %slot291, align 8
  %v1604 = load i64, ptr %slot288, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1603, i64 %v1604) nomerge, !dbg !124
  br label %bb_rcslotdone398
bb_rcslotowner398:
  %v1605 = load i64, ptr %slot23, align 8
  store i64 %v1605, ptr %slot292, align 8
  %v1606 = load i64, ptr %slot292, align 8
  %v1607 = load i64, ptr %slot288, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1606, i64 %v1607) nomerge, !dbg !124
  br label %bb_rcslotdone398
bb_rcslotdone398:
  %v1608 = load i64, ptr %slot9, align 8
  store i64 %v1608, ptr %slot293, align 8
  %v1609 = load i64, ptr %slot11, align 8
  store i64 %v1609, ptr %slot294, align 8
  %v1610 = load i64, ptr %slot294, align 8
  %v1611 = load i64, ptr %slot293, align 8
  %p1612 = inttoptr i64 %v1610 to ptr
  %p1613 = inttoptr i64 %v1611 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1613, ptr %p1612, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot6, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 2, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot8, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  %ld1618 = load i32, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1618, ptr %slot295, align 8
  %v1619 = load i32, ptr %slot295, align 8
  %v1620 = load i64, ptr %slot6, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 %v1619, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot7, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot5, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 1, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot293, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot296, align 8
  %v1629 = load i64, ptr %slot296, align 8
  %v1630 = load i64, ptr %slot17, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i64 %v1629, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot17, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i64, ptr %p1633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1634, ptr %slot297, align 8
  %v1635 = load i64, ptr %slot17, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i64, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1637, ptr %slot298, align 8
  %v1638 = load i64, ptr %slot298, align 8
  %v1639 = load i64, ptr %slot10, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  store i64 %v1638, ptr %p1640, align 8, !alias.scope !3, !noalias !4
  %v1641 = load i64, ptr %slot10, align 8
  store i64 %v1641, ptr %slot299, align 8
  %v1642 = load i64, ptr %slot11, align 8
  store i64 %v1642, ptr %slot300, align 8
  %v1643 = load i64, ptr %slot24, align 8
  store i64 %v1643, ptr %slot301, align 8
  %v1644 = load i64, ptr %slot299, align 8
  %p1646 = inttoptr i64 %v1644 to ptr
  %gep1647 = getelementptr i8, ptr %p1646, i64 0
  %op1645 = ptrtoint ptr %gep1647 to i64
  store i64 %op1645, ptr %slot302, align 8
  %v1648 = load i64, ptr %slot302, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot303, align 8
  %v1651 = load i64, ptr %slot303, align 8
  %cmp1652 = icmp ne i64 %v1651, 0
  %cv1653 = zext i1 %cmp1652 to i32
  store i32 %cv1653, ptr %slot304, align 8
  %v1654 = load i32, ptr %slot304, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcmoveheader422, label %bb_rcmovenext422
bb_rcmoveheader422:
  %v1657 = load i64, ptr %slot303, align 8
  %op1658 = sub i64 %v1657, 16
  store i64 %op1658, ptr %slot305, align 8
  %v1659 = load i64, ptr %slot303, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %rgep1661 = getelementptr i8, ptr %p1660, i64 -16
  %ld1662 = load i64, ptr %rgep1661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1662, ptr %slot306, align 8
  %v1663 = load i64, ptr %slot306, align 8
  %op1664 = and i64 %v1663, 5764607523034234881
  store i64 %op1664, ptr %slot307, align 8
  %v1665 = load i64, ptr %slot307, align 8
  %cmp1666 = icmp ne i64 %v1665, 0
  %cv1667 = zext i1 %cmp1666 to i32
  store i32 %cv1667, ptr %slot308, align 8
  %v1668 = load i32, ptr %slot308, align 8
  %cv1669 = zext i32 %v1668 to i64
  %cond1670 = icmp ne i64 %cv1669, 0
  br i1 %cond1670, label %bb_rcmoveslow419, label %bb_rcmovenext422
bb_rcmovenext422:
  %v1671 = load i64, ptr %slot299, align 8
  %v1672 = load i64, ptr %slot300, align 8
  %p1673 = inttoptr i64 %v1671 to ptr
  %p1674 = inttoptr i64 %v1672 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1674, ptr %p1673, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1675 = load i64, ptr %slot299, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  store i64 0, ptr %p1676, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved419
bb_rcmoveslow419:
  %v1677 = load i64, ptr %slot23, align 8
  %v1678 = load i64, ptr %slot300, align 8
  %v1679 = load i64, ptr %slot299, align 8
  %v1680 = load i64, ptr %slot301, align 8
  %cv1681 = trunc i64 %v1680 to i32
  %call1682 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1677, i64 %v1678, i64 %v1679, i32 %cv1681) nomerge, !dbg !126
  store i32 %call1682, ptr %slot309, align 8
  %v1683 = load i32, ptr %slot309, align 8
  %cv1684 = zext i32 %v1683 to i64
  %cond1685 = icmp ne i64 %cv1684, 0
  br i1 %cond1685, label %bb_rcsuccess429, label %bb_rcfailure429
bb_rcfailure429:
  %v1686 = load i64, ptr %slot23, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %call1688 = call i32 @myl_rc_take_failure(ptr %p1687) nomerge, !dbg !126
  store i32 %call1688, ptr %slot310, align 8
  %v1689 = load i64, ptr %slot1, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %v1691 = load i32, ptr %slot310, align 8
  %call1692 = call i32 @myl_qbe_rc_status(ptr %p1690, i32 %v1691) nomerge, !dbg !126
  store i32 %call1692, ptr %slot311, align 8
  br label %bb_failure
bb_rcsuccess429:
  br label %bb_rcmoved419
bb_rcmoved419:
  %v1693 = load i64, ptr %slot5, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot8, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 2, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot7, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 1, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot11, align 8
  store i64 %v1699, ptr %slot312, align 8
  %v1700 = load i64, ptr %slot312, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  %ld1702 = load i64, ptr %p1701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1702, ptr %slot313, align 8
  %v1703 = load i64, ptr %slot7, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 0, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot5, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %ld1707 = load i32, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1707, ptr %slot314, align 8
  %v1708 = load i32, ptr %slot314, align 8
  %cv1709 = zext i32 %v1708 to i64
  %cond1710 = icmp ne i64 %cv1709, 0
  br i1 %cond1710, label %bb_rcslotdrop440, label %bb_rcslotdone440
bb_rcslotdrop440:
  %v1711 = load i64, ptr %slot5, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot9, align 8
  store i64 %v1713, ptr %slot315, align 8
  %v1714 = load i64, ptr %slot6, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  %ld1716 = load i32, ptr %p1715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1716, ptr %slot316, align 8
  %v1717 = load i32, ptr %slot316, align 8
  %op1718 = and i32 %v1717, 28
  store i32 %op1718, ptr %slot317, align 8
  %v1719 = load i32, ptr %slot317, align 8
  %cv1720 = zext i32 %v1719 to i64
  %cond1721 = icmp ne i64 %cv1720, 0
  br i1 %cond1721, label %bb_rcslotrole440, label %bb_rcslotowner440
bb_rcslotrole440:
  %v1722 = load i64, ptr %slot23, align 8
  store i64 %v1722, ptr %slot318, align 8
  %v1723 = load i64, ptr %slot315, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %ld1725 = load i64, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1725, ptr %slot319, align 8
  %v1726 = load i64, ptr %slot319, align 8
  %cmp1727 = icmp ne i64 %v1726, 0
  %cv1728 = zext i1 %cmp1727 to i32
  store i32 %cv1728, ptr %slot320, align 8
  %v1729 = load i32, ptr %slot320, align 8
  %cv1730 = zext i32 %v1729 to i64
  %cond1731 = icmp ne i64 %cv1730, 0
  br i1 %cond1731, label %bb_rcgnn456, label %bb_rcgdone456
bb_rcgnn456:
  %v1732 = load i64, ptr %slot319, align 8
  %op1733 = sub i64 %v1732, 16
  store i64 %op1733, ptr %slot321, align 8
  %v1734 = load i64, ptr %slot319, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %rgep1736 = getelementptr i8, ptr %p1735, i64 -16
  %ld1737 = load i64, ptr %rgep1736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1737, ptr %slot322, align 8
  %v1738 = load i64, ptr %slot322, align 8
  %op1739 = and i64 %v1738, 4611686018427387906
  store i64 %op1739, ptr %slot323, align 8
  %v1740 = load i64, ptr %slot323, align 8
  %cmp1741 = icmp ne i64 %v1740, 0
  %cv1742 = zext i1 %cmp1741 to i32
  store i32 %cv1742, ptr %slot324, align 8
  %v1743 = load i32, ptr %slot324, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcgclear456, label %bb_rcgcounted456
bb_rcgcounted456:
  %v1746 = load i64, ptr %slot319, align 8
  %op1747 = sub i64 %v1746, 24
  store i64 %op1747, ptr %slot325, align 8
  %v1748 = load i64, ptr %slot319, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  %rgep1750 = getelementptr i8, ptr %p1749, i64 -24
  %ld1751 = load i64, ptr %rgep1750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1751, ptr %slot326, align 8
  %v1752 = load i64, ptr %slot326, align 8
  %op1753 = sub i64 %v1752, 1
  store i64 %op1753, ptr %slot327, align 8
  %v1754 = load i64, ptr %slot327, align 8
  %cmp1755 = icmp eq i64 %v1754, 0
  %cv1756 = zext i1 %cmp1755 to i32
  store i32 %cv1756, ptr %slot328, align 8
  %v1757 = load i32, ptr %slot328, align 8
  %cv1758 = zext i32 %v1757 to i64
  %cond1759 = icmp ne i64 %cv1758, 0
  br i1 %cond1759, label %bb_rcglast456, label %bb_rcgdec456
bb_rcglast456:
  %v1760 = load i64, ptr %slot319, align 8
  %op1761 = sub i64 %v1760, 32
  store i64 %op1761, ptr %slot329, align 8
  %v1762 = load i64, ptr %slot319, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %rgep1764 = getelementptr i8, ptr %p1763, i64 -32
  %ld1765 = load i64, ptr %rgep1764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1765, ptr %slot330, align 8
  %v1766 = load i64, ptr %slot330, align 8
  %cmp1767 = icmp ne i64 %v1766, 0
  %cv1768 = zext i1 %cmp1767 to i32
  store i32 %cv1768, ptr %slot331, align 8
  %v1769 = load i32, ptr %slot331, align 8
  %cv1770 = zext i32 %v1769 to i64
  %cond1771 = icmp ne i64 %cv1770, 0
  br i1 %cond1771, label %bb_rcgdec456, label %bb_rcgslow456
bb_rcgslow456:
  %v1772 = load i64, ptr %slot318, align 8
  %v1773 = load i64, ptr %slot315, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1772, i64 %v1773) nomerge, !dbg !126
  br label %bb_rcgdone456
bb_rcgdec456:
  %v1774 = load i64, ptr %slot327, align 8
  %v1775 = load i64, ptr %slot319, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %rgep1777 = getelementptr i8, ptr %p1776, i64 -24
  store i64 %v1774, ptr %rgep1777, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear456
bb_rcgclear456:
  %v1778 = load i64, ptr %slot315, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i64 0, ptr %p1779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone456
bb_rcgdone456:
  br label %bb_rcslotdone440
bb_rcslotowner440:
  %v1780 = load i64, ptr %slot23, align 8
  store i64 %v1780, ptr %slot332, align 8
  %v1781 = load i64, ptr %slot315, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %ld1783 = load i64, ptr %p1782, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1783, ptr %slot333, align 8
  %v1784 = load i64, ptr %slot333, align 8
  %cmp1785 = icmp ne i64 %v1784, 0
  %cv1786 = zext i1 %cmp1785 to i32
  store i32 %cv1786, ptr %slot334, align 8
  %v1787 = load i32, ptr %slot334, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rcgnn471, label %bb_rcgdone471
bb_rcgnn471:
  %v1790 = load i64, ptr %slot333, align 8
  %op1791 = sub i64 %v1790, 16
  store i64 %op1791, ptr %slot335, align 8
  %v1792 = load i64, ptr %slot333, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %rgep1794 = getelementptr i8, ptr %p1793, i64 -16
  %ld1795 = load i64, ptr %rgep1794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1795, ptr %slot336, align 8
  %v1796 = load i64, ptr %slot336, align 8
  %op1797 = and i64 %v1796, 4611686018427387906
  store i64 %op1797, ptr %slot337, align 8
  %v1798 = load i64, ptr %slot337, align 8
  %cmp1799 = icmp ne i64 %v1798, 0
  %cv1800 = zext i1 %cmp1799 to i32
  store i32 %cv1800, ptr %slot338, align 8
  %v1801 = load i32, ptr %slot338, align 8
  %cv1802 = zext i32 %v1801 to i64
  %cond1803 = icmp ne i64 %cv1802, 0
  br i1 %cond1803, label %bb_rcgclear471, label %bb_rcgcounted471
bb_rcgcounted471:
  %v1804 = load i64, ptr %slot333, align 8
  %op1805 = sub i64 %v1804, 32
  store i64 %op1805, ptr %slot339, align 8
  %v1806 = load i64, ptr %slot333, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  %rgep1808 = getelementptr i8, ptr %p1807, i64 -32
  %ld1809 = load i64, ptr %rgep1808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1809, ptr %slot340, align 8
  %v1810 = load i64, ptr %slot340, align 8
  %op1811 = sub i64 %v1810, 1
  store i64 %op1811, ptr %slot341, align 8
  %v1812 = load i64, ptr %slot341, align 8
  %cmp1813 = icmp eq i64 %v1812, 0
  %cv1814 = zext i1 %cmp1813 to i32
  store i32 %cv1814, ptr %slot342, align 8
  %v1815 = load i32, ptr %slot342, align 8
  %cv1816 = zext i32 %v1815 to i64
  %cond1817 = icmp ne i64 %cv1816, 0
  br i1 %cond1817, label %bb_rcglast471, label %bb_rcgdec471
bb_rcglast471:
  %v1818 = load i64, ptr %slot333, align 8
  %op1819 = sub i64 %v1818, 24
  store i64 %op1819, ptr %slot343, align 8
  %v1820 = load i64, ptr %slot333, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %rgep1822 = getelementptr i8, ptr %p1821, i64 -24
  %ld1823 = load i64, ptr %rgep1822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1823, ptr %slot344, align 8
  %v1824 = load i64, ptr %slot344, align 8
  %cmp1825 = icmp ne i64 %v1824, 0
  %cv1826 = zext i1 %cmp1825 to i32
  store i32 %cv1826, ptr %slot345, align 8
  %v1827 = load i32, ptr %slot345, align 8
  %cv1828 = zext i32 %v1827 to i64
  %cond1829 = icmp ne i64 %cv1828, 0
  br i1 %cond1829, label %bb_rcgdec471, label %bb_rcgslow471
bb_rcgslow471:
  %v1830 = load i64, ptr %slot332, align 8
  %v1831 = load i64, ptr %slot315, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1830, i64 %v1831) nomerge, !dbg !126
  br label %bb_rcgdone471
bb_rcgdec471:
  %v1832 = load i64, ptr %slot341, align 8
  %v1833 = load i64, ptr %slot333, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %rgep1835 = getelementptr i8, ptr %p1834, i64 -32
  store i64 %v1832, ptr %rgep1835, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear471
bb_rcgclear471:
  %v1836 = load i64, ptr %slot315, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i64 0, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone471
bb_rcgdone471:
  br label %bb_rcslotdone440
bb_rcslotdone440:
  %v1838 = load i64, ptr %slot313, align 8
  ret i64 %v1838
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_aeb0fdeeaad337003da49a9520ef2341c721f8fadd313ec215e1b80fc0a989d3 = external global i8, align 8
@myl_lit_ba5e6ec8bcb62a3153e50652d005022189b30daccd5c1aad813c296e42b0e80a = external global i8, align 8
@myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0(i64, i64, i64)
declare i64 @myl_f_f76151122d7f44fd9f99cc06e8901ecc3f4e4ebfc159bdea41c016ba858eaa14(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b", linkageName: "myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3215787479645901151, i64 0, !"myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
