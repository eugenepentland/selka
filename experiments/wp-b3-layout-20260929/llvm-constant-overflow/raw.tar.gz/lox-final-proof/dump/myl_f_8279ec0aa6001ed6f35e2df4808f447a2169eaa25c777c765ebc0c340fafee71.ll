target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v517 = load i64, ptr %slot1, align 8
  %op518 = add i64 %v517, 32
  store i64 %op518, ptr %slot4, align 8
  %mem519 = alloca i8, i64 16, align 8
  %ptr520 = ptrtoint ptr %mem519 to i64
  store i64 %ptr520, ptr %slot5, align 8
  %mem521 = alloca i8, i64 8, align 8
  %ptr522 = ptrtoint ptr %mem521 to i64
  store i64 %ptr522, ptr %slot6, align 8
  %mem523 = alloca i8, i64 8, align 8
  %ptr524 = ptrtoint ptr %mem523 to i64
  store i64 %ptr524, ptr %slot7, align 8
  %mem525 = alloca i8, i64 8, align 8
  %ptr526 = ptrtoint ptr %mem525 to i64
  store i64 %ptr526, ptr %slot8, align 8
  %mem527 = alloca i8, i64 8, align 8
  %ptr528 = ptrtoint ptr %mem527 to i64
  store i64 %ptr528, ptr %slot9, align 8
  %mem529 = alloca i8, i64 8, align 8
  %ptr530 = ptrtoint ptr %mem529 to i64
  store i64 %ptr530, ptr %slot10, align 8
  %mem531 = alloca i8, i64 8, align 8
  %ptr532 = ptrtoint ptr %mem531 to i64
  store i64 %ptr532, ptr %slot11, align 8
  %mem533 = alloca i8, i64 8, align 8
  %ptr534 = ptrtoint ptr %mem533 to i64
  store i64 %ptr534, ptr %slot12, align 8
  %mem535 = alloca i8, i64 8, align 8
  %ptr536 = ptrtoint ptr %mem535 to i64
  store i64 %ptr536, ptr %slot13, align 8
  %mem537 = alloca i8, i64 8, align 8
  %ptr538 = ptrtoint ptr %mem537 to i64
  store i64 %ptr538, ptr %slot14, align 8
  %mem539 = alloca i8, i64 8, align 8
  %ptr540 = ptrtoint ptr %mem539 to i64
  store i64 %ptr540, ptr %slot15, align 8
  %mem541 = alloca i8, i64 16, align 8
  %ptr542 = ptrtoint ptr %mem541 to i64
  store i64 %ptr542, ptr %slot16, align 8
  %mem543 = alloca i8, i64 8, align 8
  %ptr544 = ptrtoint ptr %mem543 to i64
  store i64 %ptr544, ptr %slot17, align 8
  %mem545 = alloca i8, i64 8, align 8
  %ptr546 = ptrtoint ptr %mem545 to i64
  store i64 %ptr546, ptr %slot18, align 8
  %mem547 = alloca i8, i64 16, align 8
  %ptr548 = ptrtoint ptr %mem547 to i64
  store i64 %ptr548, ptr %slot19, align 8
  %mem549 = alloca i8, i64 8, align 8
  %ptr550 = ptrtoint ptr %mem549 to i64
  store i64 %ptr550, ptr %slot20, align 8
  %mem551 = alloca i8, i64 8, align 8
  %ptr552 = ptrtoint ptr %mem551 to i64
  store i64 %ptr552, ptr %slot21, align 8
  %mem553 = alloca i8, i64 8, align 8
  %ptr554 = ptrtoint ptr %mem553 to i64
  store i64 %ptr554, ptr %slot22, align 8
  %mem555 = alloca i8, i64 8, align 8
  %ptr556 = ptrtoint ptr %mem555 to i64
  store i64 %ptr556, ptr %slot23, align 8
  %mem557 = alloca i8, i64 8, align 8
  %ptr558 = ptrtoint ptr %mem557 to i64
  store i64 %ptr558, ptr %slot24, align 8
  %mem559 = alloca i8, i64 8, align 8
  %ptr560 = ptrtoint ptr %mem559 to i64
  store i64 %ptr560, ptr %slot25, align 8
  %mem561 = alloca i8, i64 8, align 8
  %ptr562 = ptrtoint ptr %mem561 to i64
  store i64 %ptr562, ptr %slot26, align 8
  %mem563 = alloca i8, i64 8, align 8
  %ptr564 = ptrtoint ptr %mem563 to i64
  store i64 %ptr564, ptr %slot27, align 8
  %mem565 = alloca i8, i64 8, align 8
  %ptr566 = ptrtoint ptr %mem565 to i64
  store i64 %ptr566, ptr %slot28, align 8
  %mem567 = alloca i8, i64 16, align 8
  %ptr568 = ptrtoint ptr %mem567 to i64
  store i64 %ptr568, ptr %slot29, align 8
  %v569 = load i64, ptr %slot24, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 0, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot25, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i64 0, ptr %p572, align 8, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot2, align 8
  %v574 = load i64, ptr %slot22, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i64 %v573, ptr %p575, align 8, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot3, align 8
  %v577 = load i64, ptr %slot23, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i64 %v576, ptr %p578, align 8, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot1, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %call581 = call ptr @myl_qbe_heap(ptr %p580) nomerge, !dbg !110
  %calladdr582 = ptrtoint ptr %call581 to i64
  store i64 %calladdr582, ptr %slot30, align 8
  %v583 = load i64, ptr %slot1, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %call585 = call i64 @myl_qbe_region_mark(ptr %p584) nomerge, !dbg !110
  store i64 %call585, ptr %slot31, align 8
  %v586 = load i64, ptr %slot6, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i32 0, ptr %p587, align 4, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot7, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 0, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot8, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i32 0, ptr %p591, align 4, !alias.scope !3, !noalias !4
  %v592 = load i64, ptr %slot9, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i32 0, ptr %p593, align 4, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot10, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 0, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot11, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 0, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot12, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i32 0, ptr %p599, align 4, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot13, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i32 0, ptr %p601, align 4, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot14, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i32 0, ptr %p603, align 4, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot15, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot7, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i32 2, ptr %p607, align 4, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot9, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 2, ptr %p609, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v610 = load i64, ptr %slot27, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i64 0, ptr %p611, align 8, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot27, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %ld614 = load i64, ptr %p613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld614, ptr %slot32, align 8
  %v615 = load i64, ptr %slot32, align 8
  %cmp616 = icmp sge i64 %v615, 0
  %cv617 = zext i1 %cmp616 to i64
  store i64 %cv617, ptr %slot33, align 8
  %v618 = load i64, ptr %slot33, align 8
  %cond619 = icmp ne i64 %v618, 0
  br i1 %cond619, label %bb_success4, label %bb_failed4
bb_failed4:
  %v620 = load i64, ptr %slot1, align 8
  %p621 = inttoptr i64 %v620 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p621) nomerge, !dbg !112
  unreachable
bb_success4:
  %v622 = load i64, ptr %slot30, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %p624 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v625 = load i64, ptr %slot32, align 8
  %call626 = call ptr @myl_native_list_new(ptr %p623, ptr %p624, i64 %v625) nomerge, !dbg !112
  %calladdr627 = ptrtoint ptr %call626 to i64
  store i64 %calladdr627, ptr %slot34, align 8
  %v628 = load i64, ptr %slot34, align 8
  %cond629 = icmp ne i64 %v628, 0
  br i1 %cond629, label %bb_success6, label %bb_failed6
bb_failed6:
  %v630 = load i64, ptr %slot1, align 8
  %p631 = inttoptr i64 %v630 to ptr
  call void @myl_qbe_fail_allocation(ptr %p631) nomerge, !dbg !112
  unreachable
bb_success6:
  %v632 = load i64, ptr %slot34, align 8
  %v633 = load i64, ptr %slot27, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot27, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot35, align 8
  %v638 = load i64, ptr %slot35, align 8
  %v639 = load i64, ptr %slot17, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 %v638, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot17, align 8
  store i64 %v641, ptr %slot36, align 8
  %v642 = load i64, ptr %slot19, align 8
  store i64 %v642, ptr %slot37, align 8
  %v643 = load i64, ptr %slot36, align 8
  %v644 = load i64, ptr %slot37, align 8
  %p645 = inttoptr i64 %v643 to ptr
  %p646 = inttoptr i64 %v644 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p646, ptr %p645, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot14, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i32 2, ptr %p648, align 4, !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot13, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i32 1, ptr %p650, align 4, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot16, align 8
  store i64 %v651, ptr %slot38, align 8
  %v652 = load i64, ptr %slot19, align 8
  store i64 %v652, ptr %slot39, align 8
  %v653 = load i64, ptr %slot39, align 8
  %v654 = load i64, ptr %slot38, align 8
  %p655 = inttoptr i64 %v653 to ptr
  %p656 = inttoptr i64 %v654 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p656, ptr %p655, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot11, align 8
  %p658 = inttoptr i64 %v657 to ptr
  store i32 2, ptr %p658, align 4, !alias.scope !3, !noalias !4
  %v659 = load i64, ptr %slot14, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %ld661 = load i32, ptr %p660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld661, ptr %slot40, align 8
  %v662 = load i32, ptr %slot40, align 8
  %v663 = load i64, ptr %slot11, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 %v662, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot13, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 0, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot10, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 1, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot38, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %ld671 = load i64, ptr %p670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld671, ptr %slot41, align 8
  %v672 = load i64, ptr %slot41, align 8
  %v673 = load i64, ptr %slot27, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i64 %v672, ptr %p674, align 8, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot27, align 8
  %p676 = inttoptr i64 %v675 to ptr
  %ld677 = load i64, ptr %p676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld677, ptr %slot42, align 8
  %v678 = load i64, ptr %slot42, align 8
  %v679 = load i64, ptr %slot17, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 %v678, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot17, align 8
  store i64 %v681, ptr %slot43, align 8
  %v682 = load i64, ptr %slot10, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i32, ptr %p683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld684, ptr %slot44, align 8
  %v685 = load i64, ptr %slot11, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %ld687 = load i32, ptr %p686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld687, ptr %slot45, align 8
  %v688 = load i32, ptr %slot45, align 8
  %op689 = and i32 %v688, 24
  store i32 %op689, ptr %slot45, align 8
  %v690 = load i32, ptr %slot45, align 8
  %cmp691 = icmp eq i32 %v690, 0
  %cv692 = zext i1 %cmp691 to i32
  store i32 %cv692, ptr %slot46, align 8
  %v693 = load i32, ptr %slot44, align 8
  %v694 = load i32, ptr %slot46, align 8
  %op695 = and i32 %v693, %v694
  store i32 %op695, ptr %slot47, align 8
  %v696 = load i32, ptr %slot47, align 8
  %cv697 = zext i32 %v696 to i64
  %cond698 = icmp ne i64 %cv697, 0
  br i1 %cond698, label %bb_rcprivateown29, label %bb_rcprivateloan29
bb_rcprivateown29:
  %v699 = load i64, ptr %slot19, align 8
  store i64 %v699, ptr %slot48, align 8
  %v700 = load i64, ptr %slot31, align 8
  store i64 %v700, ptr %slot49, align 8
  %v701 = load i64, ptr %slot43, align 8
  %v702 = load i64, ptr %slot48, align 8
  %op703 = sub i64 %v701, %v702
  store i64 %op703, ptr %slot50, align 8
  %v704 = load i64, ptr %slot48, align 8
  %v705 = load i64, ptr %slot43, align 8
  %op706 = sub i64 %v704, %v705
  store i64 %op706, ptr %slot51, align 8
  %v707 = load i64, ptr %slot50, align 8
  %cmp708 = icmp ult i64 %v707, 8
  %cv709 = zext i1 %cmp708 to i32
  store i32 %cv709, ptr %slot52, align 8
  %v710 = load i64, ptr %slot51, align 8
  %cmp711 = icmp ult i64 %v710, 8
  %cv712 = zext i1 %cmp711 to i32
  store i32 %cv712, ptr %slot53, align 8
  %v713 = load i32, ptr %slot52, align 8
  %v714 = load i32, ptr %slot53, align 8
  %op715 = or i32 %v713, %v714
  store i32 %op715, ptr %slot54, align 8
  %v716 = load i32, ptr %slot54, align 8
  %cv717 = zext i32 %v716 to i64
  %cond718 = icmp ne i64 %cv717, 0
  br i1 %cond718, label %bb_rcmoveslow32, label %bb_rcmovecheck32
bb_rcmovecheck32:
  %v719 = load i64, ptr %slot43, align 8
  %p721 = inttoptr i64 %v719 to ptr
  %gep722 = getelementptr i8, ptr %p721, i64 0
  %op720 = ptrtoint ptr %gep722 to i64
  store i64 %op720, ptr %slot55, align 8
  %v723 = load i64, ptr %slot55, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %ld725 = load i64, ptr %p724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld725, ptr %slot56, align 8
  %v726 = load i64, ptr %slot56, align 8
  %cmp727 = icmp ne i64 %v726, 0
  %cv728 = zext i1 %cmp727 to i32
  store i32 %cv728, ptr %slot57, align 8
  %v729 = load i32, ptr %slot57, align 8
  %cv730 = zext i32 %v729 to i64
  %cond731 = icmp ne i64 %cv730, 0
  br i1 %cond731, label %bb_rcmoveheader40, label %bb_rcmovenext40
bb_rcmoveheader40:
  %v732 = load i64, ptr %slot56, align 8
  %op733 = sub i64 %v732, 16
  store i64 %op733, ptr %slot58, align 8
  %v734 = load i64, ptr %slot56, align 8
  %p735 = inttoptr i64 %v734 to ptr
  %rgep736 = getelementptr i8, ptr %p735, i64 -16
  %ld737 = load i64, ptr %rgep736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld737, ptr %slot59, align 8
  %v738 = load i64, ptr %slot59, align 8
  %op739 = and i64 %v738, 5764607523034234881
  store i64 %op739, ptr %slot60, align 8
  %v740 = load i64, ptr %slot60, align 8
  %cmp741 = icmp ne i64 %v740, 0
  %cv742 = zext i1 %cmp741 to i32
  store i32 %cv742, ptr %slot61, align 8
  %v743 = load i32, ptr %slot61, align 8
  %cv744 = zext i32 %v743 to i64
  %cond745 = icmp ne i64 %cv744, 0
  br i1 %cond745, label %bb_rcmoveslow32, label %bb_rcmovenext40
bb_rcmovenext40:
  %v746 = load i64, ptr %slot43, align 8
  %v747 = load i64, ptr %slot48, align 8
  %p748 = inttoptr i64 %v746 to ptr
  %p749 = inttoptr i64 %v747 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p749, ptr %p748, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot43, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 0, ptr %p751, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved32
bb_rcmoveslow32:
  %v752 = load i64, ptr %slot30, align 8
  %v753 = load i64, ptr %slot48, align 8
  %v754 = load i64, ptr %slot43, align 8
  %v755 = load i64, ptr %slot49, align 8
  %cv756 = trunc i64 %v755 to i32
  %call757 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v752, i64 %v753, i64 %v754, i32 %cv756) nomerge, !dbg !114
  store i32 %call757, ptr %slot62, align 8
  %v758 = load i32, ptr %slot62, align 8
  %cv759 = zext i32 %v758 to i64
  %cond760 = icmp ne i64 %cv759, 0
  br i1 %cond760, label %bb_rcsuccess47, label %bb_rcfailure47
bb_rcfailure47:
  %v761 = load i64, ptr %slot30, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %call763 = call i32 @myl_rc_take_failure(ptr %p762) nomerge, !dbg !114
  store i32 %call763, ptr %slot63, align 8
  %v764 = load i64, ptr %slot1, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %v766 = load i32, ptr %slot63, align 8
  %call767 = call i32 @myl_qbe_rc_status(ptr %p765, i32 %v766) nomerge, !dbg !114
  store i32 %call767, ptr %slot64, align 8
  br label %bb_failure
bb_rcsuccess47:
  br label %bb_rcmoved32
bb_rcmoved32:
  %v768 = load i64, ptr %slot10, align 8
  %p769 = inttoptr i64 %v768 to ptr
  store i32 0, ptr %p769, align 4, !alias.scope !3, !noalias !4
  %v770 = load i64, ptr %slot14, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i32 2, ptr %p771, align 4, !alias.scope !3, !noalias !4
  %v772 = load i64, ptr %slot13, align 8
  %p773 = inttoptr i64 %v772 to ptr
  store i32 1, ptr %p773, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared29
bb_rcprivateloan29:
  %v774 = load i64, ptr %slot10, align 8
  %p775 = inttoptr i64 %v774 to ptr
  %ld776 = load i32, ptr %p775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld776, ptr %slot65, align 8
  %v777 = load i64, ptr %slot11, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot66, align 8
  %v780 = load i32, ptr %slot66, align 8
  %cmp781 = icmp eq i32 %v780, 16
  %cv782 = zext i1 %cmp781 to i32
  store i32 %cv782, ptr %slot67, align 8
  %v783 = load i32, ptr %slot67, align 8
  %v784 = load i32, ptr %slot65, align 8
  %op785 = and i32 %v783, %v784
  store i32 %op785, ptr %slot67, align 8
  %v786 = load i32, ptr %slot67, align 8
  %cv787 = zext i32 %v786 to i64
  %cond788 = icmp ne i64 %cv787, 0
  br i1 %cond788, label %bb_rcprivatemove29, label %bb_rcprivatenew29
bb_rcprivatemove29:
  %v789 = load i64, ptr %slot19, align 8
  store i64 %v789, ptr %slot68, align 8
  %v790 = load i64, ptr %slot43, align 8
  %v791 = load i64, ptr %slot68, align 8
  %p792 = inttoptr i64 %v790 to ptr
  %p793 = inttoptr i64 %v791 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p793, ptr %p792, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot43, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i64 0, ptr %p795, align 8, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot14, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i32 2, ptr %p797, align 4, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot14, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 16, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot13, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 1, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot10, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i32 0, ptr %p803, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared29
bb_rcprivatenew29:
  %v804 = load i64, ptr %slot19, align 8
  store i64 %v804, ptr %slot69, align 8
  %v805 = load i64, ptr %slot43, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot70, align 8
  %v808 = load i64, ptr %slot70, align 8
  %cmp809 = icmp ne i64 %v808, 0
  %cv810 = zext i1 %cmp809 to i32
  store i32 %cv810, ptr %slot71, align 8
  %v811 = load i32, ptr %slot71, align 8
  %cv812 = zext i32 %v811 to i64
  %cond813 = icmp ne i64 %cv812, 0
  br i1 %cond813, label %bb_rcgnn65, label %bb_rcgstore65
bb_rcgnn65:
  %v814 = load i64, ptr %slot70, align 8
  %op815 = sub i64 %v814, 16
  store i64 %op815, ptr %slot72, align 8
  %v816 = load i64, ptr %slot70, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %rgep818 = getelementptr i8, ptr %p817, i64 -16
  %ld819 = load i64, ptr %rgep818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld819, ptr %slot73, align 8
  %v820 = load i64, ptr %slot73, align 8
  %op821 = and i64 %v820, 4611686018427387906
  store i64 %op821, ptr %slot74, align 8
  %v822 = load i64, ptr %slot74, align 8
  %cmp823 = icmp ne i64 %v822, 0
  %cv824 = zext i1 %cmp823 to i32
  store i32 %cv824, ptr %slot75, align 8
  %v825 = load i32, ptr %slot75, align 8
  %cv826 = zext i32 %v825 to i64
  %cond827 = icmp ne i64 %cv826, 0
  br i1 %cond827, label %bb_rcgstore65, label %bb_rcginc65
bb_rcginc65:
  %v828 = load i64, ptr %slot70, align 8
  %op829 = sub i64 %v828, 24
  store i64 %op829, ptr %slot76, align 8
  %v830 = load i64, ptr %slot70, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %rgep832 = getelementptr i8, ptr %p831, i64 -24
  %ld833 = load i64, ptr %rgep832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld833, ptr %slot77, align 8
  %v834 = load i64, ptr %slot77, align 8
  %op835 = add i64 %v834, 1
  store i64 %op835, ptr %slot78, align 8
  %v836 = load i64, ptr %slot78, align 8
  %cmp837 = icmp eq i64 %v836, 0
  %cv838 = zext i1 %cmp837 to i32
  store i32 %cv838, ptr %slot79, align 8
  %v839 = load i32, ptr %slot79, align 8
  %cv840 = zext i32 %v839 to i64
  %cond841 = icmp ne i64 %cv840, 0
  br i1 %cond841, label %bb_rcglimit65, label %bb_rcgcapacity65
bb_rcglimit65:
  %v842 = load i64, ptr %slot1, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %call844 = call i32 @myl_qbe_rc_status(ptr %p843, i32 2) nomerge, !dbg !114
  store i32 %call844, ptr %slot80, align 8
  br label %bb_failure
bb_rcgcapacity65:
  %v845 = load i64, ptr %slot78, align 8
  %v846 = load i64, ptr %slot70, align 8
  %p847 = inttoptr i64 %v846 to ptr
  %rgep848 = getelementptr i8, ptr %p847, i64 -24
  store i64 %v845, ptr %rgep848, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore65
bb_rcgstore65:
  %v849 = load i64, ptr %slot70, align 8
  %v850 = load i64, ptr %slot69, align 8
  %p851 = inttoptr i64 %v850 to ptr
  store i64 %v849, ptr %p851, align 8, !alias.scope !3, !noalias !4
  %v852 = load i64, ptr %slot14, align 8
  %p853 = inttoptr i64 %v852 to ptr
  store i32 2, ptr %p853, align 4, !alias.scope !3, !noalias !4
  %v854 = load i64, ptr %slot14, align 8
  %p855 = inttoptr i64 %v854 to ptr
  store i32 16, ptr %p855, align 4, !alias.scope !3, !noalias !4
  %v856 = load i64, ptr %slot13, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 1, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot10, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i32, ptr %p859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld860, ptr %slot81, align 8
  %v861 = load i32, ptr %slot81, align 8
  %cv862 = zext i32 %v861 to i64
  %cond863 = icmp ne i64 %cv862, 0
  br i1 %cond863, label %bb_rcslotdrop81, label %bb_rcslotdone81
bb_rcslotdrop81:
  %v864 = load i64, ptr %slot10, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i32 0, ptr %p865, align 4, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot16, align 8
  store i64 %v866, ptr %slot82, align 8
  %v867 = load i64, ptr %slot11, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %ld869 = load i32, ptr %p868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld869, ptr %slot83, align 8
  %v870 = load i32, ptr %slot83, align 8
  %op871 = and i32 %v870, 28
  store i32 %op871, ptr %slot84, align 8
  %v872 = load i32, ptr %slot84, align 8
  %cv873 = zext i32 %v872 to i64
  %cond874 = icmp ne i64 %cv873, 0
  br i1 %cond874, label %bb_rcslotrole81, label %bb_rcslotowner81
bb_rcslotrole81:
  %v875 = load i64, ptr %slot30, align 8
  store i64 %v875, ptr %slot85, align 8
  %v876 = load i64, ptr %slot82, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld878, ptr %slot86, align 8
  %v879 = load i64, ptr %slot86, align 8
  %cmp880 = icmp ne i64 %v879, 0
  %cv881 = zext i1 %cmp880 to i32
  store i32 %cv881, ptr %slot87, align 8
  %v882 = load i32, ptr %slot87, align 8
  %cv883 = zext i32 %v882 to i64
  %cond884 = icmp ne i64 %cv883, 0
  br i1 %cond884, label %bb_rcgnn97, label %bb_rcgdone97
bb_rcgnn97:
  %v885 = load i64, ptr %slot86, align 8
  %op886 = sub i64 %v885, 16
  store i64 %op886, ptr %slot88, align 8
  %v887 = load i64, ptr %slot86, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %rgep889 = getelementptr i8, ptr %p888, i64 -16
  %ld890 = load i64, ptr %rgep889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld890, ptr %slot89, align 8
  %v891 = load i64, ptr %slot89, align 8
  %op892 = and i64 %v891, 4611686018427387906
  store i64 %op892, ptr %slot90, align 8
  %v893 = load i64, ptr %slot90, align 8
  %cmp894 = icmp ne i64 %v893, 0
  %cv895 = zext i1 %cmp894 to i32
  store i32 %cv895, ptr %slot91, align 8
  %v896 = load i32, ptr %slot91, align 8
  %cv897 = zext i32 %v896 to i64
  %cond898 = icmp ne i64 %cv897, 0
  br i1 %cond898, label %bb_rcgclear97, label %bb_rcgcounted97
bb_rcgcounted97:
  %v899 = load i64, ptr %slot86, align 8
  %op900 = sub i64 %v899, 24
  store i64 %op900, ptr %slot92, align 8
  %v901 = load i64, ptr %slot86, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %rgep903 = getelementptr i8, ptr %p902, i64 -24
  %ld904 = load i64, ptr %rgep903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld904, ptr %slot93, align 8
  %v905 = load i64, ptr %slot93, align 8
  %op906 = sub i64 %v905, 1
  store i64 %op906, ptr %slot94, align 8
  %v907 = load i64, ptr %slot94, align 8
  %cmp908 = icmp eq i64 %v907, 0
  %cv909 = zext i1 %cmp908 to i32
  store i32 %cv909, ptr %slot95, align 8
  %v910 = load i32, ptr %slot95, align 8
  %cv911 = zext i32 %v910 to i64
  %cond912 = icmp ne i64 %cv911, 0
  br i1 %cond912, label %bb_rcglast97, label %bb_rcgdec97
bb_rcglast97:
  %v913 = load i64, ptr %slot86, align 8
  %op914 = sub i64 %v913, 32
  store i64 %op914, ptr %slot96, align 8
  %v915 = load i64, ptr %slot86, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %rgep917 = getelementptr i8, ptr %p916, i64 -32
  %ld918 = load i64, ptr %rgep917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld918, ptr %slot97, align 8
  %v919 = load i64, ptr %slot97, align 8
  %cmp920 = icmp ne i64 %v919, 0
  %cv921 = zext i1 %cmp920 to i32
  store i32 %cv921, ptr %slot98, align 8
  %v922 = load i32, ptr %slot98, align 8
  %cv923 = zext i32 %v922 to i64
  %cond924 = icmp ne i64 %cv923, 0
  br i1 %cond924, label %bb_rcgdec97, label %bb_rcgslow97
bb_rcgslow97:
  %v925 = load i64, ptr %slot85, align 8
  %v926 = load i64, ptr %slot82, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v925, i64 %v926) nomerge, !dbg !114
  br label %bb_rcgdone97
bb_rcgdec97:
  %v927 = load i64, ptr %slot94, align 8
  %v928 = load i64, ptr %slot86, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %rgep930 = getelementptr i8, ptr %p929, i64 -24
  store i64 %v927, ptr %rgep930, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear97
bb_rcgclear97:
  %v931 = load i64, ptr %slot82, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i64 0, ptr %p932, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone97
bb_rcgdone97:
  br label %bb_rcslotdone81
bb_rcslotowner81:
  %v933 = load i64, ptr %slot30, align 8
  store i64 %v933, ptr %slot99, align 8
  %v934 = load i64, ptr %slot82, align 8
  %p935 = inttoptr i64 %v934 to ptr
  %ld936 = load i64, ptr %p935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld936, ptr %slot100, align 8
  %v937 = load i64, ptr %slot100, align 8
  %cmp938 = icmp ne i64 %v937, 0
  %cv939 = zext i1 %cmp938 to i32
  store i32 %cv939, ptr %slot101, align 8
  %v940 = load i32, ptr %slot101, align 8
  %cv941 = zext i32 %v940 to i64
  %cond942 = icmp ne i64 %cv941, 0
  br i1 %cond942, label %bb_rcgnn112, label %bb_rcgdone112
bb_rcgnn112:
  %v943 = load i64, ptr %slot100, align 8
  %op944 = sub i64 %v943, 16
  store i64 %op944, ptr %slot102, align 8
  %v945 = load i64, ptr %slot100, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %rgep947 = getelementptr i8, ptr %p946, i64 -16
  %ld948 = load i64, ptr %rgep947, align 8, !alias.scope !9, !noalias !10
  store i64 %ld948, ptr %slot103, align 8
  %v949 = load i64, ptr %slot103, align 8
  %op950 = and i64 %v949, 4611686018427387906
  store i64 %op950, ptr %slot104, align 8
  %v951 = load i64, ptr %slot104, align 8
  %cmp952 = icmp ne i64 %v951, 0
  %cv953 = zext i1 %cmp952 to i32
  store i32 %cv953, ptr %slot105, align 8
  %v954 = load i32, ptr %slot105, align 8
  %cv955 = zext i32 %v954 to i64
  %cond956 = icmp ne i64 %cv955, 0
  br i1 %cond956, label %bb_rcgclear112, label %bb_rcgcounted112
bb_rcgcounted112:
  %v957 = load i64, ptr %slot100, align 8
  %op958 = sub i64 %v957, 32
  store i64 %op958, ptr %slot106, align 8
  %v959 = load i64, ptr %slot100, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %rgep961 = getelementptr i8, ptr %p960, i64 -32
  %ld962 = load i64, ptr %rgep961, align 8, !alias.scope !9, !noalias !10
  store i64 %ld962, ptr %slot107, align 8
  %v963 = load i64, ptr %slot107, align 8
  %op964 = sub i64 %v963, 1
  store i64 %op964, ptr %slot108, align 8
  %v965 = load i64, ptr %slot108, align 8
  %cmp966 = icmp eq i64 %v965, 0
  %cv967 = zext i1 %cmp966 to i32
  store i32 %cv967, ptr %slot109, align 8
  %v968 = load i32, ptr %slot109, align 8
  %cv969 = zext i32 %v968 to i64
  %cond970 = icmp ne i64 %cv969, 0
  br i1 %cond970, label %bb_rcglast112, label %bb_rcgdec112
bb_rcglast112:
  %v971 = load i64, ptr %slot100, align 8
  %op972 = sub i64 %v971, 24
  store i64 %op972, ptr %slot110, align 8
  %v973 = load i64, ptr %slot100, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %rgep975 = getelementptr i8, ptr %p974, i64 -24
  %ld976 = load i64, ptr %rgep975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld976, ptr %slot111, align 8
  %v977 = load i64, ptr %slot111, align 8
  %cmp978 = icmp ne i64 %v977, 0
  %cv979 = zext i1 %cmp978 to i32
  store i32 %cv979, ptr %slot112, align 8
  %v980 = load i32, ptr %slot112, align 8
  %cv981 = zext i32 %v980 to i64
  %cond982 = icmp ne i64 %cv981, 0
  br i1 %cond982, label %bb_rcgdec112, label %bb_rcgslow112
bb_rcgslow112:
  %v983 = load i64, ptr %slot99, align 8
  %v984 = load i64, ptr %slot82, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v983, i64 %v984) nomerge, !dbg !114
  br label %bb_rcgdone112
bb_rcgdec112:
  %v985 = load i64, ptr %slot108, align 8
  %v986 = load i64, ptr %slot100, align 8
  %p987 = inttoptr i64 %v986 to ptr
  %rgep988 = getelementptr i8, ptr %p987, i64 -32
  store i64 %v985, ptr %rgep988, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear112
bb_rcgclear112:
  %v989 = load i64, ptr %slot82, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 0, ptr %p990, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone112
bb_rcgdone112:
  br label %bb_rcslotdone81
bb_rcslotdone81:
  br label %bb_rcprivateprepared29
bb_rcprivateprepared29:
  %v991 = load i64, ptr %slot6, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i32, ptr %p992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld993, ptr %slot113, align 8
  %v994 = load i32, ptr %slot113, align 8
  %cv995 = zext i32 %v994 to i64
  %cond996 = icmp ne i64 %cv995, 0
  br i1 %cond996, label %bb_rcslotdrop119, label %bb_rcslotdone119
bb_rcslotdrop119:
  %v997 = load i64, ptr %slot6, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i32 0, ptr %p998, align 4, !alias.scope !3, !noalias !4
  %v999 = load i64, ptr %slot24, align 8
  store i64 %v999, ptr %slot114, align 8
  %v1000 = load i64, ptr %slot7, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i32, ptr %p1001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1002, ptr %slot115, align 8
  %v1003 = load i32, ptr %slot115, align 8
  %op1004 = and i32 %v1003, 28
  store i32 %op1004, ptr %slot116, align 8
  %v1005 = load i32, ptr %slot116, align 8
  %cv1006 = zext i32 %v1005 to i64
  %cond1007 = icmp ne i64 %cv1006, 0
  br i1 %cond1007, label %bb_rcslotrole119, label %bb_rcslotowner119
bb_rcslotrole119:
  %v1008 = load i64, ptr %slot30, align 8
  store i64 %v1008, ptr %slot117, align 8
  %v1009 = load i64, ptr %slot114, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %ld1011 = load i64, ptr %p1010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1011, ptr %slot118, align 8
  %v1012 = load i64, ptr %slot118, align 8
  %cmp1013 = icmp ne i64 %v1012, 0
  %cv1014 = zext i1 %cmp1013 to i32
  store i32 %cv1014, ptr %slot119, align 8
  %v1015 = load i32, ptr %slot119, align 8
  %cv1016 = zext i32 %v1015 to i64
  %cond1017 = icmp ne i64 %cv1016, 0
  br i1 %cond1017, label %bb_rcgnn135, label %bb_rcgdone135
bb_rcgnn135:
  %v1018 = load i64, ptr %slot118, align 8
  %op1019 = sub i64 %v1018, 16
  store i64 %op1019, ptr %slot120, align 8
  %v1020 = load i64, ptr %slot118, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %rgep1022 = getelementptr i8, ptr %p1021, i64 -16
  %ld1023 = load i64, ptr %rgep1022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1023, ptr %slot121, align 8
  %v1024 = load i64, ptr %slot121, align 8
  %op1025 = and i64 %v1024, 4611686018427387906
  store i64 %op1025, ptr %slot122, align 8
  %v1026 = load i64, ptr %slot122, align 8
  %cmp1027 = icmp ne i64 %v1026, 0
  %cv1028 = zext i1 %cmp1027 to i32
  store i32 %cv1028, ptr %slot123, align 8
  %v1029 = load i32, ptr %slot123, align 8
  %cv1030 = zext i32 %v1029 to i64
  %cond1031 = icmp ne i64 %cv1030, 0
  br i1 %cond1031, label %bb_rcgclear135, label %bb_rcgcounted135
bb_rcgcounted135:
  %v1032 = load i64, ptr %slot118, align 8
  %op1033 = sub i64 %v1032, 24
  store i64 %op1033, ptr %slot124, align 8
  %v1034 = load i64, ptr %slot118, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %rgep1036 = getelementptr i8, ptr %p1035, i64 -24
  %ld1037 = load i64, ptr %rgep1036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1037, ptr %slot125, align 8
  %v1038 = load i64, ptr %slot125, align 8
  %op1039 = sub i64 %v1038, 1
  store i64 %op1039, ptr %slot126, align 8
  %v1040 = load i64, ptr %slot126, align 8
  %cmp1041 = icmp eq i64 %v1040, 0
  %cv1042 = zext i1 %cmp1041 to i32
  store i32 %cv1042, ptr %slot127, align 8
  %v1043 = load i32, ptr %slot127, align 8
  %cv1044 = zext i32 %v1043 to i64
  %cond1045 = icmp ne i64 %cv1044, 0
  br i1 %cond1045, label %bb_rcglast135, label %bb_rcgdec135
bb_rcglast135:
  %v1046 = load i64, ptr %slot118, align 8
  %op1047 = sub i64 %v1046, 32
  store i64 %op1047, ptr %slot128, align 8
  %v1048 = load i64, ptr %slot118, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  %rgep1050 = getelementptr i8, ptr %p1049, i64 -32
  %ld1051 = load i64, ptr %rgep1050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1051, ptr %slot129, align 8
  %v1052 = load i64, ptr %slot129, align 8
  %cmp1053 = icmp ne i64 %v1052, 0
  %cv1054 = zext i1 %cmp1053 to i32
  store i32 %cv1054, ptr %slot130, align 8
  %v1055 = load i32, ptr %slot130, align 8
  %cv1056 = zext i32 %v1055 to i64
  %cond1057 = icmp ne i64 %cv1056, 0
  br i1 %cond1057, label %bb_rcgdec135, label %bb_rcgslow135
bb_rcgslow135:
  %v1058 = load i64, ptr %slot117, align 8
  %v1059 = load i64, ptr %slot114, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1058, i64 %v1059) nomerge, !dbg !114
  br label %bb_rcgdone135
bb_rcgdec135:
  %v1060 = load i64, ptr %slot126, align 8
  %v1061 = load i64, ptr %slot118, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %rgep1063 = getelementptr i8, ptr %p1062, i64 -24
  store i64 %v1060, ptr %rgep1063, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear135
bb_rcgclear135:
  %v1064 = load i64, ptr %slot114, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  store i64 0, ptr %p1065, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone135
bb_rcgdone135:
  br label %bb_rcslotdone119
bb_rcslotowner119:
  %v1066 = load i64, ptr %slot30, align 8
  store i64 %v1066, ptr %slot131, align 8
  %v1067 = load i64, ptr %slot114, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %ld1069 = load i64, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1069, ptr %slot132, align 8
  %v1070 = load i64, ptr %slot132, align 8
  %cmp1071 = icmp ne i64 %v1070, 0
  %cv1072 = zext i1 %cmp1071 to i32
  store i32 %cv1072, ptr %slot133, align 8
  %v1073 = load i32, ptr %slot133, align 8
  %cv1074 = zext i32 %v1073 to i64
  %cond1075 = icmp ne i64 %cv1074, 0
  br i1 %cond1075, label %bb_rcgnn150, label %bb_rcgdone150
bb_rcgnn150:
  %v1076 = load i64, ptr %slot132, align 8
  %op1077 = sub i64 %v1076, 16
  store i64 %op1077, ptr %slot134, align 8
  %v1078 = load i64, ptr %slot132, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %rgep1080 = getelementptr i8, ptr %p1079, i64 -16
  %ld1081 = load i64, ptr %rgep1080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1081, ptr %slot135, align 8
  %v1082 = load i64, ptr %slot135, align 8
  %op1083 = and i64 %v1082, 4611686018427387906
  store i64 %op1083, ptr %slot136, align 8
  %v1084 = load i64, ptr %slot136, align 8
  %cmp1085 = icmp ne i64 %v1084, 0
  %cv1086 = zext i1 %cmp1085 to i32
  store i32 %cv1086, ptr %slot137, align 8
  %v1087 = load i32, ptr %slot137, align 8
  %cv1088 = zext i32 %v1087 to i64
  %cond1089 = icmp ne i64 %cv1088, 0
  br i1 %cond1089, label %bb_rcgclear150, label %bb_rcgcounted150
bb_rcgcounted150:
  %v1090 = load i64, ptr %slot132, align 8
  %op1091 = sub i64 %v1090, 32
  store i64 %op1091, ptr %slot138, align 8
  %v1092 = load i64, ptr %slot132, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %rgep1094 = getelementptr i8, ptr %p1093, i64 -32
  %ld1095 = load i64, ptr %rgep1094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1095, ptr %slot139, align 8
  %v1096 = load i64, ptr %slot139, align 8
  %op1097 = sub i64 %v1096, 1
  store i64 %op1097, ptr %slot140, align 8
  %v1098 = load i64, ptr %slot140, align 8
  %cmp1099 = icmp eq i64 %v1098, 0
  %cv1100 = zext i1 %cmp1099 to i32
  store i32 %cv1100, ptr %slot141, align 8
  %v1101 = load i32, ptr %slot141, align 8
  %cv1102 = zext i32 %v1101 to i64
  %cond1103 = icmp ne i64 %cv1102, 0
  br i1 %cond1103, label %bb_rcglast150, label %bb_rcgdec150
bb_rcglast150:
  %v1104 = load i64, ptr %slot132, align 8
  %op1105 = sub i64 %v1104, 24
  store i64 %op1105, ptr %slot142, align 8
  %v1106 = load i64, ptr %slot132, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  %rgep1108 = getelementptr i8, ptr %p1107, i64 -24
  %ld1109 = load i64, ptr %rgep1108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1109, ptr %slot143, align 8
  %v1110 = load i64, ptr %slot143, align 8
  %cmp1111 = icmp ne i64 %v1110, 0
  %cv1112 = zext i1 %cmp1111 to i32
  store i32 %cv1112, ptr %slot144, align 8
  %v1113 = load i32, ptr %slot144, align 8
  %cv1114 = zext i32 %v1113 to i64
  %cond1115 = icmp ne i64 %cv1114, 0
  br i1 %cond1115, label %bb_rcgdec150, label %bb_rcgslow150
bb_rcgslow150:
  %v1116 = load i64, ptr %slot131, align 8
  %v1117 = load i64, ptr %slot114, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1116, i64 %v1117) nomerge, !dbg !114
  br label %bb_rcgdone150
bb_rcgdec150:
  %v1118 = load i64, ptr %slot140, align 8
  %v1119 = load i64, ptr %slot132, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %rgep1121 = getelementptr i8, ptr %p1120, i64 -32
  store i64 %v1118, ptr %rgep1121, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear150
bb_rcgclear150:
  %v1122 = load i64, ptr %slot114, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  store i64 0, ptr %p1123, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone150
bb_rcgdone150:
  br label %bb_rcslotdone119
bb_rcslotdone119:
  %v1124 = load i64, ptr %slot24, align 8
  store i64 %v1124, ptr %slot145, align 8
  %v1125 = load i64, ptr %slot19, align 8
  store i64 %v1125, ptr %slot146, align 8
  %v1126 = load i64, ptr %slot146, align 8
  %v1127 = load i64, ptr %slot145, align 8
  %p1128 = inttoptr i64 %v1126 to ptr
  %p1129 = inttoptr i64 %v1127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1129, ptr %p1128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot13, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i32 0, ptr %p1131, align 4, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot7, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i32 2, ptr %p1133, align 4, !alias.scope !3, !noalias !4
  %v1134 = load i64, ptr %slot14, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %ld1136 = load i32, ptr %p1135, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1136, ptr %slot147, align 8
  %v1137 = load i32, ptr %slot147, align 8
  %v1138 = load i64, ptr %slot7, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i32 %v1137, ptr %p1139, align 4, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot6, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 1, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot24, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i64, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1144, ptr %slot148, align 8
  %v1145 = load i64, ptr %slot148, align 8
  %v1146 = load i64, ptr %slot27, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i64 %v1145, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot27, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i64, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1150, ptr %slot149, align 8
  %v1151 = load i64, ptr %slot149, align 8
  %v1152 = load i64, ptr %slot17, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  store i64 %v1151, ptr %p1153, align 8, !alias.scope !3, !noalias !4
  %v1154 = load i64, ptr %slot17, align 8
  store i64 %v1154, ptr %slot150, align 8
  %v1155 = load i64, ptr %slot10, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %ld1157 = load i32, ptr %p1156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1157, ptr %slot151, align 8
  %v1158 = load i64, ptr %slot11, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i32, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1160, ptr %slot152, align 8
  %v1161 = load i32, ptr %slot152, align 8
  %op1162 = and i32 %v1161, 24
  store i32 %op1162, ptr %slot152, align 8
  %v1163 = load i32, ptr %slot152, align 8
  %cmp1164 = icmp eq i32 %v1163, 0
  %cv1165 = zext i1 %cmp1164 to i32
  store i32 %cv1165, ptr %slot153, align 8
  %v1166 = load i32, ptr %slot151, align 8
  %v1167 = load i32, ptr %slot153, align 8
  %op1168 = and i32 %v1166, %v1167
  store i32 %op1168, ptr %slot154, align 8
  %v1169 = load i32, ptr %slot154, align 8
  %cv1170 = zext i32 %v1169 to i64
  %cond1171 = icmp ne i64 %cv1170, 0
  br i1 %cond1171, label %bb_rctake164, label %bb_rccopy164
bb_rctake164:
  %v1172 = load i64, ptr %slot19, align 8
  store i64 %v1172, ptr %slot155, align 8
  %v1173 = load i64, ptr %slot31, align 8
  store i64 %v1173, ptr %slot156, align 8
  %v1174 = load i64, ptr %slot150, align 8
  %v1175 = load i64, ptr %slot155, align 8
  %op1176 = sub i64 %v1174, %v1175
  store i64 %op1176, ptr %slot157, align 8
  %v1177 = load i64, ptr %slot155, align 8
  %v1178 = load i64, ptr %slot150, align 8
  %op1179 = sub i64 %v1177, %v1178
  store i64 %op1179, ptr %slot158, align 8
  %v1180 = load i64, ptr %slot157, align 8
  %cmp1181 = icmp ult i64 %v1180, 8
  %cv1182 = zext i1 %cmp1181 to i32
  store i32 %cv1182, ptr %slot159, align 8
  %v1183 = load i64, ptr %slot158, align 8
  %cmp1184 = icmp ult i64 %v1183, 8
  %cv1185 = zext i1 %cmp1184 to i32
  store i32 %cv1185, ptr %slot160, align 8
  %v1186 = load i32, ptr %slot159, align 8
  %v1187 = load i32, ptr %slot160, align 8
  %op1188 = or i32 %v1186, %v1187
  store i32 %op1188, ptr %slot161, align 8
  %v1189 = load i32, ptr %slot161, align 8
  %cv1190 = zext i32 %v1189 to i64
  %cond1191 = icmp ne i64 %cv1190, 0
  br i1 %cond1191, label %bb_rcmoveslow173, label %bb_rcmovecheck173
bb_rcmovecheck173:
  %v1192 = load i64, ptr %slot150, align 8
  %p1194 = inttoptr i64 %v1192 to ptr
  %gep1195 = getelementptr i8, ptr %p1194, i64 0
  %op1193 = ptrtoint ptr %gep1195 to i64
  store i64 %op1193, ptr %slot162, align 8
  %v1196 = load i64, ptr %slot162, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i64, ptr %p1197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1198, ptr %slot163, align 8
  %v1199 = load i64, ptr %slot163, align 8
  %cmp1200 = icmp ne i64 %v1199, 0
  %cv1201 = zext i1 %cmp1200 to i32
  store i32 %cv1201, ptr %slot164, align 8
  %v1202 = load i32, ptr %slot164, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcmoveheader181, label %bb_rcmovenext181
bb_rcmoveheader181:
  %v1205 = load i64, ptr %slot163, align 8
  %op1206 = sub i64 %v1205, 16
  store i64 %op1206, ptr %slot165, align 8
  %v1207 = load i64, ptr %slot163, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  %rgep1209 = getelementptr i8, ptr %p1208, i64 -16
  %ld1210 = load i64, ptr %rgep1209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1210, ptr %slot166, align 8
  %v1211 = load i64, ptr %slot166, align 8
  %op1212 = and i64 %v1211, 5764607523034234881
  store i64 %op1212, ptr %slot167, align 8
  %v1213 = load i64, ptr %slot167, align 8
  %cmp1214 = icmp ne i64 %v1213, 0
  %cv1215 = zext i1 %cmp1214 to i32
  store i32 %cv1215, ptr %slot168, align 8
  %v1216 = load i32, ptr %slot168, align 8
  %cv1217 = zext i32 %v1216 to i64
  %cond1218 = icmp ne i64 %cv1217, 0
  br i1 %cond1218, label %bb_rcmoveslow173, label %bb_rcmovenext181
bb_rcmovenext181:
  %v1219 = load i64, ptr %slot150, align 8
  %v1220 = load i64, ptr %slot155, align 8
  %p1221 = inttoptr i64 %v1219 to ptr
  %p1222 = inttoptr i64 %v1220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1222, ptr %p1221, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot150, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i64 0, ptr %p1224, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved173
bb_rcmoveslow173:
  %v1225 = load i64, ptr %slot30, align 8
  %v1226 = load i64, ptr %slot155, align 8
  %v1227 = load i64, ptr %slot150, align 8
  %v1228 = load i64, ptr %slot156, align 8
  %cv1229 = trunc i64 %v1228 to i32
  %call1230 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1225, i64 %v1226, i64 %v1227, i32 %cv1229) nomerge, !dbg !116
  store i32 %call1230, ptr %slot169, align 8
  %v1231 = load i32, ptr %slot169, align 8
  %cv1232 = zext i32 %v1231 to i64
  %cond1233 = icmp ne i64 %cv1232, 0
  br i1 %cond1233, label %bb_rcsuccess188, label %bb_rcfailure188
bb_rcfailure188:
  %v1234 = load i64, ptr %slot30, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  %call1236 = call i32 @myl_rc_take_failure(ptr %p1235) nomerge, !dbg !116
  store i32 %call1236, ptr %slot170, align 8
  %v1237 = load i64, ptr %slot1, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  %v1239 = load i32, ptr %slot170, align 8
  %call1240 = call i32 @myl_qbe_rc_status(ptr %p1238, i32 %v1239) nomerge, !dbg !116
  store i32 %call1240, ptr %slot171, align 8
  br label %bb_failure
bb_rcsuccess188:
  br label %bb_rcmoved173
bb_rcmoved173:
  %v1241 = load i64, ptr %slot10, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  store i32 0, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  %v1243 = load i64, ptr %slot14, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  store i32 2, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  %v1245 = load i64, ptr %slot13, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i32 1, ptr %p1246, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared164
bb_rccopy164:
  %v1247 = load i64, ptr %slot19, align 8
  store i64 %v1247, ptr %slot172, align 8
  %v1248 = load i64, ptr %slot31, align 8
  store i64 %v1248, ptr %slot173, align 8
  %v1249 = load i64, ptr %slot150, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i64, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1251, ptr %slot174, align 8
  %v1252 = load i64, ptr %slot174, align 8
  %cmp1253 = icmp ne i64 %v1252, 0
  %cv1254 = zext i1 %cmp1253 to i32
  store i32 %cv1254, ptr %slot175, align 8
  %v1255 = load i32, ptr %slot175, align 8
  %cv1256 = zext i32 %v1255 to i64
  %cond1257 = icmp ne i64 %cv1256, 0
  br i1 %cond1257, label %bb_rcgnn197, label %bb_rcgplain197
bb_rcgnn197:
  %v1258 = load i64, ptr %slot174, align 8
  %op1259 = sub i64 %v1258, 16
  store i64 %op1259, ptr %slot176, align 8
  %v1260 = load i64, ptr %slot174, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %rgep1262 = getelementptr i8, ptr %p1261, i64 -16
  %ld1263 = load i64, ptr %rgep1262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1263, ptr %slot177, align 8
  %v1264 = load i64, ptr %slot177, align 8
  %op1265 = and i64 %v1264, 4611686018427387906
  store i64 %op1265, ptr %slot178, align 8
  %v1266 = load i64, ptr %slot178, align 8
  %cmp1267 = icmp ne i64 %v1266, 0
  %cv1268 = zext i1 %cmp1267 to i32
  store i32 %cv1268, ptr %slot179, align 8
  %v1269 = load i32, ptr %slot179, align 8
  %cv1270 = zext i32 %v1269 to i64
  %cond1271 = icmp ne i64 %cv1270, 0
  br i1 %cond1271, label %bb_rcgspecial197, label %bb_rcginc197
bb_rcginc197:
  %v1272 = load i64, ptr %slot174, align 8
  %op1273 = sub i64 %v1272, 32
  store i64 %op1273, ptr %slot180, align 8
  %v1274 = load i64, ptr %slot174, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %rgep1276 = getelementptr i8, ptr %p1275, i64 -32
  %ld1277 = load i64, ptr %rgep1276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1277, ptr %slot181, align 8
  %v1278 = load i64, ptr %slot181, align 8
  %op1279 = add i64 %v1278, 1
  store i64 %op1279, ptr %slot182, align 8
  %v1280 = load i64, ptr %slot182, align 8
  %cmp1281 = icmp eq i64 %v1280, 0
  %cv1282 = zext i1 %cmp1281 to i32
  store i32 %cv1282, ptr %slot183, align 8
  %v1283 = load i32, ptr %slot183, align 8
  %cv1284 = zext i32 %v1283 to i64
  %cond1285 = icmp ne i64 %cv1284, 0
  br i1 %cond1285, label %bb_rcglimit197, label %bb_rcgcapacity197
bb_rcglimit197:
  %v1286 = load i64, ptr %slot1, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  %call1288 = call i32 @myl_qbe_rc_status(ptr %p1287, i32 2) nomerge, !dbg !116
  store i32 %call1288, ptr %slot184, align 8
  br label %bb_failure
bb_rcgcapacity197:
  %v1289 = load i64, ptr %slot182, align 8
  %v1290 = load i64, ptr %slot174, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  %rgep1292 = getelementptr i8, ptr %p1291, i64 -32
  store i64 %v1289, ptr %rgep1292, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain197
bb_rcgspecial197:
  %v1293 = load i64, ptr %slot177, align 8
  %op1294 = and i64 %v1293, 4611686018427387904
  store i64 %op1294, ptr %slot185, align 8
  %v1295 = load i64, ptr %slot185, align 8
  %cmp1296 = icmp ne i64 %v1295, 0
  %cv1297 = zext i1 %cmp1296 to i32
  store i32 %cv1297, ptr %slot186, align 8
  %v1298 = load i32, ptr %slot186, align 8
  %cv1299 = zext i32 %v1298 to i64
  %cond1300 = icmp ne i64 %cv1299, 0
  br i1 %cond1300, label %bb_rcgslow197, label %bb_rcgplain197
bb_rcgslow197:
  %v1301 = load i64, ptr %slot30, align 8
  %v1302 = load i64, ptr %slot172, align 8
  %v1303 = load i64, ptr %slot150, align 8
  %v1304 = load i64, ptr %slot173, align 8
  %cv1305 = trunc i64 %v1304 to i32
  %call1306 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1301, i64 %v1302, i64 %v1303, i32 %cv1305) nomerge, !dbg !116
  store i32 %call1306, ptr %slot187, align 8
  %v1307 = load i32, ptr %slot187, align 8
  %cv1308 = zext i32 %v1307 to i64
  %cond1309 = icmp ne i64 %cv1308, 0
  br i1 %cond1309, label %bb_rcsuccess211, label %bb_rcfailure211
bb_rcfailure211:
  %v1310 = load i64, ptr %slot30, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  %call1312 = call i32 @myl_rc_take_failure(ptr %p1311) nomerge, !dbg !116
  store i32 %call1312, ptr %slot188, align 8
  %v1313 = load i64, ptr %slot1, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %v1315 = load i32, ptr %slot188, align 8
  %call1316 = call i32 @myl_qbe_rc_status(ptr %p1314, i32 %v1315) nomerge, !dbg !116
  store i32 %call1316, ptr %slot189, align 8
  br label %bb_failure
bb_rcsuccess211:
  br label %bb_rcgdone197
bb_rcgplain197:
  %v1317 = load i64, ptr %slot174, align 8
  %v1318 = load i64, ptr %slot172, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i64 %v1317, ptr %p1319, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone197
bb_rcgdone197:
  %v1320 = load i64, ptr %slot14, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i32 2, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot13, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i32 1, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot10, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i32, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1326, ptr %slot190, align 8
  %v1327 = load i32, ptr %slot190, align 8
  %cv1328 = zext i32 %v1327 to i64
  %cond1329 = icmp ne i64 %cv1328, 0
  br i1 %cond1329, label %bb_rcslotdrop218, label %bb_rcslotdone218
bb_rcslotdrop218:
  %v1330 = load i64, ptr %slot10, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 0, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot16, align 8
  store i64 %v1332, ptr %slot191, align 8
  %v1333 = load i64, ptr %slot11, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %ld1335 = load i32, ptr %p1334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1335, ptr %slot192, align 8
  %v1336 = load i32, ptr %slot192, align 8
  %op1337 = and i32 %v1336, 28
  store i32 %op1337, ptr %slot193, align 8
  %v1338 = load i32, ptr %slot193, align 8
  %cv1339 = zext i32 %v1338 to i64
  %cond1340 = icmp ne i64 %cv1339, 0
  br i1 %cond1340, label %bb_rcslotrole218, label %bb_rcslotowner218
bb_rcslotrole218:
  %v1341 = load i64, ptr %slot30, align 8
  store i64 %v1341, ptr %slot194, align 8
  %v1342 = load i64, ptr %slot191, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i64, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1344, ptr %slot195, align 8
  %v1345 = load i64, ptr %slot195, align 8
  %cmp1346 = icmp ne i64 %v1345, 0
  %cv1347 = zext i1 %cmp1346 to i32
  store i32 %cv1347, ptr %slot196, align 8
  %v1348 = load i32, ptr %slot196, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcgnn234, label %bb_rcgdone234
bb_rcgnn234:
  %v1351 = load i64, ptr %slot195, align 8
  %op1352 = sub i64 %v1351, 16
  store i64 %op1352, ptr %slot197, align 8
  %v1353 = load i64, ptr %slot195, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %rgep1355 = getelementptr i8, ptr %p1354, i64 -16
  %ld1356 = load i64, ptr %rgep1355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1356, ptr %slot198, align 8
  %v1357 = load i64, ptr %slot198, align 8
  %op1358 = and i64 %v1357, 4611686018427387906
  store i64 %op1358, ptr %slot199, align 8
  %v1359 = load i64, ptr %slot199, align 8
  %cmp1360 = icmp ne i64 %v1359, 0
  %cv1361 = zext i1 %cmp1360 to i32
  store i32 %cv1361, ptr %slot200, align 8
  %v1362 = load i32, ptr %slot200, align 8
  %cv1363 = zext i32 %v1362 to i64
  %cond1364 = icmp ne i64 %cv1363, 0
  br i1 %cond1364, label %bb_rcgclear234, label %bb_rcgcounted234
bb_rcgcounted234:
  %v1365 = load i64, ptr %slot195, align 8
  %op1366 = sub i64 %v1365, 24
  store i64 %op1366, ptr %slot201, align 8
  %v1367 = load i64, ptr %slot195, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %rgep1369 = getelementptr i8, ptr %p1368, i64 -24
  %ld1370 = load i64, ptr %rgep1369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1370, ptr %slot202, align 8
  %v1371 = load i64, ptr %slot202, align 8
  %op1372 = sub i64 %v1371, 1
  store i64 %op1372, ptr %slot203, align 8
  %v1373 = load i64, ptr %slot203, align 8
  %cmp1374 = icmp eq i64 %v1373, 0
  %cv1375 = zext i1 %cmp1374 to i32
  store i32 %cv1375, ptr %slot204, align 8
  %v1376 = load i32, ptr %slot204, align 8
  %cv1377 = zext i32 %v1376 to i64
  %cond1378 = icmp ne i64 %cv1377, 0
  br i1 %cond1378, label %bb_rcglast234, label %bb_rcgdec234
bb_rcglast234:
  %v1379 = load i64, ptr %slot195, align 8
  %op1380 = sub i64 %v1379, 32
  store i64 %op1380, ptr %slot205, align 8
  %v1381 = load i64, ptr %slot195, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  %rgep1383 = getelementptr i8, ptr %p1382, i64 -32
  %ld1384 = load i64, ptr %rgep1383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1384, ptr %slot206, align 8
  %v1385 = load i64, ptr %slot206, align 8
  %cmp1386 = icmp ne i64 %v1385, 0
  %cv1387 = zext i1 %cmp1386 to i32
  store i32 %cv1387, ptr %slot207, align 8
  %v1388 = load i32, ptr %slot207, align 8
  %cv1389 = zext i32 %v1388 to i64
  %cond1390 = icmp ne i64 %cv1389, 0
  br i1 %cond1390, label %bb_rcgdec234, label %bb_rcgslow234
bb_rcgslow234:
  %v1391 = load i64, ptr %slot194, align 8
  %v1392 = load i64, ptr %slot191, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1391, i64 %v1392) nomerge, !dbg !116
  br label %bb_rcgdone234
bb_rcgdec234:
  %v1393 = load i64, ptr %slot203, align 8
  %v1394 = load i64, ptr %slot195, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %rgep1396 = getelementptr i8, ptr %p1395, i64 -24
  store i64 %v1393, ptr %rgep1396, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear234
bb_rcgclear234:
  %v1397 = load i64, ptr %slot191, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i64 0, ptr %p1398, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone234
bb_rcgdone234:
  br label %bb_rcslotdone218
bb_rcslotowner218:
  %v1399 = load i64, ptr %slot30, align 8
  store i64 %v1399, ptr %slot208, align 8
  %v1400 = load i64, ptr %slot191, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %ld1402 = load i64, ptr %p1401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1402, ptr %slot209, align 8
  %v1403 = load i64, ptr %slot209, align 8
  %cmp1404 = icmp ne i64 %v1403, 0
  %cv1405 = zext i1 %cmp1404 to i32
  store i32 %cv1405, ptr %slot210, align 8
  %v1406 = load i32, ptr %slot210, align 8
  %cv1407 = zext i32 %v1406 to i64
  %cond1408 = icmp ne i64 %cv1407, 0
  br i1 %cond1408, label %bb_rcgnn249, label %bb_rcgdone249
bb_rcgnn249:
  %v1409 = load i64, ptr %slot209, align 8
  %op1410 = sub i64 %v1409, 16
  store i64 %op1410, ptr %slot211, align 8
  %v1411 = load i64, ptr %slot209, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %rgep1413 = getelementptr i8, ptr %p1412, i64 -16
  %ld1414 = load i64, ptr %rgep1413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1414, ptr %slot212, align 8
  %v1415 = load i64, ptr %slot212, align 8
  %op1416 = and i64 %v1415, 4611686018427387906
  store i64 %op1416, ptr %slot213, align 8
  %v1417 = load i64, ptr %slot213, align 8
  %cmp1418 = icmp ne i64 %v1417, 0
  %cv1419 = zext i1 %cmp1418 to i32
  store i32 %cv1419, ptr %slot214, align 8
  %v1420 = load i32, ptr %slot214, align 8
  %cv1421 = zext i32 %v1420 to i64
  %cond1422 = icmp ne i64 %cv1421, 0
  br i1 %cond1422, label %bb_rcgclear249, label %bb_rcgcounted249
bb_rcgcounted249:
  %v1423 = load i64, ptr %slot209, align 8
  %op1424 = sub i64 %v1423, 32
  store i64 %op1424, ptr %slot215, align 8
  %v1425 = load i64, ptr %slot209, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  %rgep1427 = getelementptr i8, ptr %p1426, i64 -32
  %ld1428 = load i64, ptr %rgep1427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1428, ptr %slot216, align 8
  %v1429 = load i64, ptr %slot216, align 8
  %op1430 = sub i64 %v1429, 1
  store i64 %op1430, ptr %slot217, align 8
  %v1431 = load i64, ptr %slot217, align 8
  %cmp1432 = icmp eq i64 %v1431, 0
  %cv1433 = zext i1 %cmp1432 to i32
  store i32 %cv1433, ptr %slot218, align 8
  %v1434 = load i32, ptr %slot218, align 8
  %cv1435 = zext i32 %v1434 to i64
  %cond1436 = icmp ne i64 %cv1435, 0
  br i1 %cond1436, label %bb_rcglast249, label %bb_rcgdec249
bb_rcglast249:
  %v1437 = load i64, ptr %slot209, align 8
  %op1438 = sub i64 %v1437, 24
  store i64 %op1438, ptr %slot219, align 8
  %v1439 = load i64, ptr %slot209, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %rgep1441 = getelementptr i8, ptr %p1440, i64 -24
  %ld1442 = load i64, ptr %rgep1441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1442, ptr %slot220, align 8
  %v1443 = load i64, ptr %slot220, align 8
  %cmp1444 = icmp ne i64 %v1443, 0
  %cv1445 = zext i1 %cmp1444 to i32
  store i32 %cv1445, ptr %slot221, align 8
  %v1446 = load i32, ptr %slot221, align 8
  %cv1447 = zext i32 %v1446 to i64
  %cond1448 = icmp ne i64 %cv1447, 0
  br i1 %cond1448, label %bb_rcgdec249, label %bb_rcgslow249
bb_rcgslow249:
  %v1449 = load i64, ptr %slot208, align 8
  %v1450 = load i64, ptr %slot191, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1449, i64 %v1450) nomerge, !dbg !116
  br label %bb_rcgdone249
bb_rcgdec249:
  %v1451 = load i64, ptr %slot217, align 8
  %v1452 = load i64, ptr %slot209, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %rgep1454 = getelementptr i8, ptr %p1453, i64 -32
  store i64 %v1451, ptr %rgep1454, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear249
bb_rcgclear249:
  %v1455 = load i64, ptr %slot191, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  store i64 0, ptr %p1456, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone249
bb_rcgdone249:
  br label %bb_rcslotdone218
bb_rcslotdone218:
  br label %bb_rcprepared164
bb_rcprepared164:
  %v1457 = load i64, ptr %slot8, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  %ld1459 = load i32, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1459, ptr %slot222, align 8
  %v1460 = load i32, ptr %slot222, align 8
  %cv1461 = zext i32 %v1460 to i64
  %cond1462 = icmp ne i64 %cv1461, 0
  br i1 %cond1462, label %bb_rcslotdrop256, label %bb_rcslotdone256
bb_rcslotdrop256:
  %v1463 = load i64, ptr %slot8, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i32 0, ptr %p1464, align 4, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot25, align 8
  store i64 %v1465, ptr %slot223, align 8
  %v1466 = load i64, ptr %slot9, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  %ld1468 = load i32, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1468, ptr %slot224, align 8
  %v1469 = load i32, ptr %slot224, align 8
  %op1470 = and i32 %v1469, 28
  store i32 %op1470, ptr %slot225, align 8
  %v1471 = load i32, ptr %slot225, align 8
  %cv1472 = zext i32 %v1471 to i64
  %cond1473 = icmp ne i64 %cv1472, 0
  br i1 %cond1473, label %bb_rcslotrole256, label %bb_rcslotowner256
bb_rcslotrole256:
  %v1474 = load i64, ptr %slot30, align 8
  store i64 %v1474, ptr %slot226, align 8
  %v1475 = load i64, ptr %slot223, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i64, ptr %p1476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1477, ptr %slot227, align 8
  %v1478 = load i64, ptr %slot227, align 8
  %cmp1479 = icmp ne i64 %v1478, 0
  %cv1480 = zext i1 %cmp1479 to i32
  store i32 %cv1480, ptr %slot228, align 8
  %v1481 = load i32, ptr %slot228, align 8
  %cv1482 = zext i32 %v1481 to i64
  %cond1483 = icmp ne i64 %cv1482, 0
  br i1 %cond1483, label %bb_rcgnn272, label %bb_rcgdone272
bb_rcgnn272:
  %v1484 = load i64, ptr %slot227, align 8
  %op1485 = sub i64 %v1484, 16
  store i64 %op1485, ptr %slot229, align 8
  %v1486 = load i64, ptr %slot227, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %rgep1488 = getelementptr i8, ptr %p1487, i64 -16
  %ld1489 = load i64, ptr %rgep1488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1489, ptr %slot230, align 8
  %v1490 = load i64, ptr %slot230, align 8
  %op1491 = and i64 %v1490, 4611686018427387906
  store i64 %op1491, ptr %slot231, align 8
  %v1492 = load i64, ptr %slot231, align 8
  %cmp1493 = icmp ne i64 %v1492, 0
  %cv1494 = zext i1 %cmp1493 to i32
  store i32 %cv1494, ptr %slot232, align 8
  %v1495 = load i32, ptr %slot232, align 8
  %cv1496 = zext i32 %v1495 to i64
  %cond1497 = icmp ne i64 %cv1496, 0
  br i1 %cond1497, label %bb_rcgclear272, label %bb_rcgcounted272
bb_rcgcounted272:
  %v1498 = load i64, ptr %slot227, align 8
  %op1499 = sub i64 %v1498, 24
  store i64 %op1499, ptr %slot233, align 8
  %v1500 = load i64, ptr %slot227, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %rgep1502 = getelementptr i8, ptr %p1501, i64 -24
  %ld1503 = load i64, ptr %rgep1502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1503, ptr %slot234, align 8
  %v1504 = load i64, ptr %slot234, align 8
  %op1505 = sub i64 %v1504, 1
  store i64 %op1505, ptr %slot235, align 8
  %v1506 = load i64, ptr %slot235, align 8
  %cmp1507 = icmp eq i64 %v1506, 0
  %cv1508 = zext i1 %cmp1507 to i32
  store i32 %cv1508, ptr %slot236, align 8
  %v1509 = load i32, ptr %slot236, align 8
  %cv1510 = zext i32 %v1509 to i64
  %cond1511 = icmp ne i64 %cv1510, 0
  br i1 %cond1511, label %bb_rcglast272, label %bb_rcgdec272
bb_rcglast272:
  %v1512 = load i64, ptr %slot227, align 8
  %op1513 = sub i64 %v1512, 32
  store i64 %op1513, ptr %slot237, align 8
  %v1514 = load i64, ptr %slot227, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %rgep1516 = getelementptr i8, ptr %p1515, i64 -32
  %ld1517 = load i64, ptr %rgep1516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1517, ptr %slot238, align 8
  %v1518 = load i64, ptr %slot238, align 8
  %cmp1519 = icmp ne i64 %v1518, 0
  %cv1520 = zext i1 %cmp1519 to i32
  store i32 %cv1520, ptr %slot239, align 8
  %v1521 = load i32, ptr %slot239, align 8
  %cv1522 = zext i32 %v1521 to i64
  %cond1523 = icmp ne i64 %cv1522, 0
  br i1 %cond1523, label %bb_rcgdec272, label %bb_rcgslow272
bb_rcgslow272:
  %v1524 = load i64, ptr %slot226, align 8
  %v1525 = load i64, ptr %slot223, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1524, i64 %v1525) nomerge, !dbg !116
  br label %bb_rcgdone272
bb_rcgdec272:
  %v1526 = load i64, ptr %slot235, align 8
  %v1527 = load i64, ptr %slot227, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %rgep1529 = getelementptr i8, ptr %p1528, i64 -24
  store i64 %v1526, ptr %rgep1529, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear272
bb_rcgclear272:
  %v1530 = load i64, ptr %slot223, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  store i64 0, ptr %p1531, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone272
bb_rcgdone272:
  br label %bb_rcslotdone256
bb_rcslotowner256:
  %v1532 = load i64, ptr %slot30, align 8
  store i64 %v1532, ptr %slot240, align 8
  %v1533 = load i64, ptr %slot223, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  %ld1535 = load i64, ptr %p1534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1535, ptr %slot241, align 8
  %v1536 = load i64, ptr %slot241, align 8
  %cmp1537 = icmp ne i64 %v1536, 0
  %cv1538 = zext i1 %cmp1537 to i32
  store i32 %cv1538, ptr %slot242, align 8
  %v1539 = load i32, ptr %slot242, align 8
  %cv1540 = zext i32 %v1539 to i64
  %cond1541 = icmp ne i64 %cv1540, 0
  br i1 %cond1541, label %bb_rcgnn287, label %bb_rcgdone287
bb_rcgnn287:
  %v1542 = load i64, ptr %slot241, align 8
  %op1543 = sub i64 %v1542, 16
  store i64 %op1543, ptr %slot243, align 8
  %v1544 = load i64, ptr %slot241, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %rgep1546 = getelementptr i8, ptr %p1545, i64 -16
  %ld1547 = load i64, ptr %rgep1546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1547, ptr %slot244, align 8
  %v1548 = load i64, ptr %slot244, align 8
  %op1549 = and i64 %v1548, 4611686018427387906
  store i64 %op1549, ptr %slot245, align 8
  %v1550 = load i64, ptr %slot245, align 8
  %cmp1551 = icmp ne i64 %v1550, 0
  %cv1552 = zext i1 %cmp1551 to i32
  store i32 %cv1552, ptr %slot246, align 8
  %v1553 = load i32, ptr %slot246, align 8
  %cv1554 = zext i32 %v1553 to i64
  %cond1555 = icmp ne i64 %cv1554, 0
  br i1 %cond1555, label %bb_rcgclear287, label %bb_rcgcounted287
bb_rcgcounted287:
  %v1556 = load i64, ptr %slot241, align 8
  %op1557 = sub i64 %v1556, 32
  store i64 %op1557, ptr %slot247, align 8
  %v1558 = load i64, ptr %slot241, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %rgep1560 = getelementptr i8, ptr %p1559, i64 -32
  %ld1561 = load i64, ptr %rgep1560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1561, ptr %slot248, align 8
  %v1562 = load i64, ptr %slot248, align 8
  %op1563 = sub i64 %v1562, 1
  store i64 %op1563, ptr %slot249, align 8
  %v1564 = load i64, ptr %slot249, align 8
  %cmp1565 = icmp eq i64 %v1564, 0
  %cv1566 = zext i1 %cmp1565 to i32
  store i32 %cv1566, ptr %slot250, align 8
  %v1567 = load i32, ptr %slot250, align 8
  %cv1568 = zext i32 %v1567 to i64
  %cond1569 = icmp ne i64 %cv1568, 0
  br i1 %cond1569, label %bb_rcglast287, label %bb_rcgdec287
bb_rcglast287:
  %v1570 = load i64, ptr %slot241, align 8
  %op1571 = sub i64 %v1570, 24
  store i64 %op1571, ptr %slot251, align 8
  %v1572 = load i64, ptr %slot241, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %rgep1574 = getelementptr i8, ptr %p1573, i64 -24
  %ld1575 = load i64, ptr %rgep1574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1575, ptr %slot252, align 8
  %v1576 = load i64, ptr %slot252, align 8
  %cmp1577 = icmp ne i64 %v1576, 0
  %cv1578 = zext i1 %cmp1577 to i32
  store i32 %cv1578, ptr %slot253, align 8
  %v1579 = load i32, ptr %slot253, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcgdec287, label %bb_rcgslow287
bb_rcgslow287:
  %v1582 = load i64, ptr %slot240, align 8
  %v1583 = load i64, ptr %slot223, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1582, i64 %v1583) nomerge, !dbg !116
  br label %bb_rcgdone287
bb_rcgdec287:
  %v1584 = load i64, ptr %slot249, align 8
  %v1585 = load i64, ptr %slot241, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %rgep1587 = getelementptr i8, ptr %p1586, i64 -32
  store i64 %v1584, ptr %rgep1587, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear287
bb_rcgclear287:
  %v1588 = load i64, ptr %slot223, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i64 0, ptr %p1589, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone287
bb_rcgdone287:
  br label %bb_rcslotdone256
bb_rcslotdone256:
  %v1590 = load i64, ptr %slot25, align 8
  store i64 %v1590, ptr %slot254, align 8
  %v1591 = load i64, ptr %slot19, align 8
  store i64 %v1591, ptr %slot255, align 8
  %v1592 = load i64, ptr %slot255, align 8
  %v1593 = load i64, ptr %slot254, align 8
  %p1594 = inttoptr i64 %v1592 to ptr
  %p1595 = inttoptr i64 %v1593 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1595, ptr %p1594, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1596 = load i64, ptr %slot13, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  store i32 0, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  %v1598 = load i64, ptr %slot9, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i32 2, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot14, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %ld1602 = load i32, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1602, ptr %slot256, align 8
  %v1603 = load i32, ptr %slot256, align 8
  %v1604 = load i64, ptr %slot9, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i32 %v1603, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot8, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i32 1, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  %v1608 = load i64, ptr %slot6, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  %ld1610 = load i32, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1610, ptr %slot257, align 8
  %v1611 = load i32, ptr %slot257, align 8
  %cv1612 = zext i32 %v1611 to i64
  %cond1613 = icmp ne i64 %cv1612, 0
  br i1 %cond1613, label %bb_rcslotdrop300, label %bb_rcslotdone300
bb_rcslotdrop300:
  %v1614 = load i64, ptr %slot6, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot24, align 8
  store i64 %v1616, ptr %slot258, align 8
  %v1617 = load i64, ptr %slot7, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i32, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1619, ptr %slot259, align 8
  %v1620 = load i32, ptr %slot259, align 8
  %op1621 = and i32 %v1620, 28
  store i32 %op1621, ptr %slot260, align 8
  %v1622 = load i32, ptr %slot260, align 8
  %cv1623 = zext i32 %v1622 to i64
  %cond1624 = icmp ne i64 %cv1623, 0
  br i1 %cond1624, label %bb_rcslotrole300, label %bb_rcslotowner300
bb_rcslotrole300:
  %v1625 = load i64, ptr %slot30, align 8
  store i64 %v1625, ptr %slot261, align 8
  %v1626 = load i64, ptr %slot258, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot262, align 8
  %v1629 = load i64, ptr %slot262, align 8
  %cmp1630 = icmp ne i64 %v1629, 0
  %cv1631 = zext i1 %cmp1630 to i32
  store i32 %cv1631, ptr %slot263, align 8
  %v1632 = load i32, ptr %slot263, align 8
  %cv1633 = zext i32 %v1632 to i64
  %cond1634 = icmp ne i64 %cv1633, 0
  br i1 %cond1634, label %bb_rcgnn316, label %bb_rcgdone316
bb_rcgnn316:
  %v1635 = load i64, ptr %slot262, align 8
  %op1636 = sub i64 %v1635, 16
  store i64 %op1636, ptr %slot264, align 8
  %v1637 = load i64, ptr %slot262, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %rgep1639 = getelementptr i8, ptr %p1638, i64 -16
  %ld1640 = load i64, ptr %rgep1639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1640, ptr %slot265, align 8
  %v1641 = load i64, ptr %slot265, align 8
  %op1642 = and i64 %v1641, 4611686018427387906
  store i64 %op1642, ptr %slot266, align 8
  %v1643 = load i64, ptr %slot266, align 8
  %cmp1644 = icmp ne i64 %v1643, 0
  %cv1645 = zext i1 %cmp1644 to i32
  store i32 %cv1645, ptr %slot267, align 8
  %v1646 = load i32, ptr %slot267, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcgclear316, label %bb_rcgcounted316
bb_rcgcounted316:
  %v1649 = load i64, ptr %slot262, align 8
  %op1650 = sub i64 %v1649, 24
  store i64 %op1650, ptr %slot268, align 8
  %v1651 = load i64, ptr %slot262, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %rgep1653 = getelementptr i8, ptr %p1652, i64 -24
  %ld1654 = load i64, ptr %rgep1653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1654, ptr %slot269, align 8
  %v1655 = load i64, ptr %slot269, align 8
  %op1656 = sub i64 %v1655, 1
  store i64 %op1656, ptr %slot270, align 8
  %v1657 = load i64, ptr %slot270, align 8
  %cmp1658 = icmp eq i64 %v1657, 0
  %cv1659 = zext i1 %cmp1658 to i32
  store i32 %cv1659, ptr %slot271, align 8
  %v1660 = load i32, ptr %slot271, align 8
  %cv1661 = zext i32 %v1660 to i64
  %cond1662 = icmp ne i64 %cv1661, 0
  br i1 %cond1662, label %bb_rcglast316, label %bb_rcgdec316
bb_rcglast316:
  %v1663 = load i64, ptr %slot262, align 8
  %op1664 = sub i64 %v1663, 32
  store i64 %op1664, ptr %slot272, align 8
  %v1665 = load i64, ptr %slot262, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  %rgep1667 = getelementptr i8, ptr %p1666, i64 -32
  %ld1668 = load i64, ptr %rgep1667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1668, ptr %slot273, align 8
  %v1669 = load i64, ptr %slot273, align 8
  %cmp1670 = icmp ne i64 %v1669, 0
  %cv1671 = zext i1 %cmp1670 to i32
  store i32 %cv1671, ptr %slot274, align 8
  %v1672 = load i32, ptr %slot274, align 8
  %cv1673 = zext i32 %v1672 to i64
  %cond1674 = icmp ne i64 %cv1673, 0
  br i1 %cond1674, label %bb_rcgdec316, label %bb_rcgslow316
bb_rcgslow316:
  %v1675 = load i64, ptr %slot261, align 8
  %v1676 = load i64, ptr %slot258, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1675, i64 %v1676) nomerge, !dbg !116
  br label %bb_rcgdone316
bb_rcgdec316:
  %v1677 = load i64, ptr %slot270, align 8
  %v1678 = load i64, ptr %slot262, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  %rgep1680 = getelementptr i8, ptr %p1679, i64 -24
  store i64 %v1677, ptr %rgep1680, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear316
bb_rcgclear316:
  %v1681 = load i64, ptr %slot258, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i64 0, ptr %p1682, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone316
bb_rcgdone316:
  br label %bb_rcslotdone300
bb_rcslotowner300:
  %v1683 = load i64, ptr %slot30, align 8
  store i64 %v1683, ptr %slot275, align 8
  %v1684 = load i64, ptr %slot258, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %ld1686 = load i64, ptr %p1685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1686, ptr %slot276, align 8
  %v1687 = load i64, ptr %slot276, align 8
  %cmp1688 = icmp ne i64 %v1687, 0
  %cv1689 = zext i1 %cmp1688 to i32
  store i32 %cv1689, ptr %slot277, align 8
  %v1690 = load i32, ptr %slot277, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcgnn331, label %bb_rcgdone331
bb_rcgnn331:
  %v1693 = load i64, ptr %slot276, align 8
  %op1694 = sub i64 %v1693, 16
  store i64 %op1694, ptr %slot278, align 8
  %v1695 = load i64, ptr %slot276, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %rgep1697 = getelementptr i8, ptr %p1696, i64 -16
  %ld1698 = load i64, ptr %rgep1697, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1698, ptr %slot279, align 8
  %v1699 = load i64, ptr %slot279, align 8
  %op1700 = and i64 %v1699, 4611686018427387906
  store i64 %op1700, ptr %slot280, align 8
  %v1701 = load i64, ptr %slot280, align 8
  %cmp1702 = icmp ne i64 %v1701, 0
  %cv1703 = zext i1 %cmp1702 to i32
  store i32 %cv1703, ptr %slot281, align 8
  %v1704 = load i32, ptr %slot281, align 8
  %cv1705 = zext i32 %v1704 to i64
  %cond1706 = icmp ne i64 %cv1705, 0
  br i1 %cond1706, label %bb_rcgclear331, label %bb_rcgcounted331
bb_rcgcounted331:
  %v1707 = load i64, ptr %slot276, align 8
  %op1708 = sub i64 %v1707, 32
  store i64 %op1708, ptr %slot282, align 8
  %v1709 = load i64, ptr %slot276, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %rgep1711 = getelementptr i8, ptr %p1710, i64 -32
  %ld1712 = load i64, ptr %rgep1711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1712, ptr %slot283, align 8
  %v1713 = load i64, ptr %slot283, align 8
  %op1714 = sub i64 %v1713, 1
  store i64 %op1714, ptr %slot284, align 8
  %v1715 = load i64, ptr %slot284, align 8
  %cmp1716 = icmp eq i64 %v1715, 0
  %cv1717 = zext i1 %cmp1716 to i32
  store i32 %cv1717, ptr %slot285, align 8
  %v1718 = load i32, ptr %slot285, align 8
  %cv1719 = zext i32 %v1718 to i64
  %cond1720 = icmp ne i64 %cv1719, 0
  br i1 %cond1720, label %bb_rcglast331, label %bb_rcgdec331
bb_rcglast331:
  %v1721 = load i64, ptr %slot276, align 8
  %op1722 = sub i64 %v1721, 24
  store i64 %op1722, ptr %slot286, align 8
  %v1723 = load i64, ptr %slot276, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %rgep1725 = getelementptr i8, ptr %p1724, i64 -24
  %ld1726 = load i64, ptr %rgep1725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1726, ptr %slot287, align 8
  %v1727 = load i64, ptr %slot287, align 8
  %cmp1728 = icmp ne i64 %v1727, 0
  %cv1729 = zext i1 %cmp1728 to i32
  store i32 %cv1729, ptr %slot288, align 8
  %v1730 = load i32, ptr %slot288, align 8
  %cv1731 = zext i32 %v1730 to i64
  %cond1732 = icmp ne i64 %cv1731, 0
  br i1 %cond1732, label %bb_rcgdec331, label %bb_rcgslow331
bb_rcgslow331:
  %v1733 = load i64, ptr %slot275, align 8
  %v1734 = load i64, ptr %slot258, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1733, i64 %v1734) nomerge, !dbg !116
  br label %bb_rcgdone331
bb_rcgdec331:
  %v1735 = load i64, ptr %slot284, align 8
  %v1736 = load i64, ptr %slot276, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %rgep1738 = getelementptr i8, ptr %p1737, i64 -32
  store i64 %v1735, ptr %rgep1738, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear331
bb_rcgclear331:
  %v1739 = load i64, ptr %slot258, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i64 0, ptr %p1740, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone331
bb_rcgdone331:
  br label %bb_rcslotdone300
bb_rcslotdone300:
  %v1741 = load i64, ptr %slot27, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i64 0, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot27, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot289, align 8
  %v1746 = load i64, ptr %slot289, align 8
  %v1747 = load i64, ptr %slot26, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i64 %v1746, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  br label %bb_ce8
bb_ce8:
  %v1749 = load i64, ptr %slot25, align 8
  store i64 %v1749, ptr %slot290, align 8
  %v1750 = load i64, ptr %slot9, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  store i32 2, ptr %p1751, align 4, !alias.scope !3, !noalias !4
  %v1752 = load i64, ptr %slot290, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  %ld1754 = load i64, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1754, ptr %slot291, align 8
  %v1755 = load i64, ptr %slot291, align 8
  %cmp1756 = icmp ne i64 %v1755, 0
  %cv1757 = zext i1 %cmp1756 to i32
  store i32 %cv1757, ptr %slot292, align 8
  %v1758 = load i32, ptr %slot292, align 8
  %cv1759 = zext i32 %v1758 to i64
  %cond1760 = icmp ne i64 %cv1759, 0
  br i1 %cond1760, label %bb_rcguniquenn339, label %bb_rcgunique339
bb_rcguniquenn339:
  %v1761 = load i64, ptr %slot291, align 8
  %op1762 = sub i64 %v1761, 16
  store i64 %op1762, ptr %slot293, align 8
  %v1763 = load i64, ptr %slot291, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %rgep1765 = getelementptr i8, ptr %p1764, i64 -16
  %ld1766 = load i64, ptr %rgep1765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1766, ptr %slot294, align 8
  %v1767 = load i64, ptr %slot294, align 8
  %op1768 = and i64 %v1767, 6917529027641081858
  store i64 %op1768, ptr %slot295, align 8
  %v1769 = load i64, ptr %slot295, align 8
  %cmp1770 = icmp ne i64 %v1769, 0
  %cv1771 = zext i1 %cmp1770 to i32
  store i32 %cv1771, ptr %slot296, align 8
  %v1772 = load i32, ptr %slot296, align 8
  %cv1773 = zext i32 %v1772 to i64
  %cond1774 = icmp ne i64 %cv1773, 0
  br i1 %cond1774, label %bb_rcguniqueslow339, label %bb_rcguniquecount339
bb_rcguniquecount339:
  %v1775 = load i64, ptr %slot291, align 8
  %op1776 = sub i64 %v1775, 32
  store i64 %op1776, ptr %slot297, align 8
  %v1777 = load i64, ptr %slot291, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  %rgep1779 = getelementptr i8, ptr %p1778, i64 -32
  %ld1780 = load i64, ptr %rgep1779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1780, ptr %slot298, align 8
  %v1781 = load i64, ptr %slot298, align 8
  %cmp1782 = icmp ult i64 %v1781, 2
  %cv1783 = zext i1 %cmp1782 to i32
  store i32 %cv1783, ptr %slot299, align 8
  %v1784 = load i32, ptr %slot299, align 8
  %cv1785 = zext i32 %v1784 to i64
  %cond1786 = icmp ne i64 %cv1785, 0
  br i1 %cond1786, label %bb_rcgunique339, label %bb_rcguniqueslow339
bb_rcguniqueslow339:
  %v1787 = load i64, ptr %slot1, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %p1789 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v1790 = load i64, ptr %slot290, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %v1792 = load i64, ptr %slot8, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %call1794 = call i32 @myl_qbe_rc_unique_local(ptr %p1788, ptr %p1789, ptr %p1791, ptr %p1793) nomerge, !dbg !118
  store i32 %call1794, ptr %slot300, align 8
  %v1795 = load i32, ptr %slot300, align 8
  %cv1796 = zext i32 %v1795 to i64
  %cond1797 = icmp ne i64 %cv1796, 0
  br i1 %cond1797, label %bb_rcunique350, label %bb_failure
bb_rcunique350:
  br label %bb_rcgunique339
bb_rcgunique339:
  %v1798 = load i64, ptr %slot21, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  store i32 0, ptr %p1799, align 4, !alias.scope !3, !noalias !4
  %v1800 = load i64, ptr %slot26, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %ld1802 = load i64, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1802, ptr %slot301, align 8
  %v1803 = load i64, ptr %slot23, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i64, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1805, ptr %slot302, align 8
  %v1806 = load i64, ptr %slot302, align 8
  %v1807 = load i64, ptr %slot301, align 8
  %cmp1808 = icmp sgt i64 %v1806, %v1807
  %cv1809 = zext i1 %cmp1808 to i64
  store i64 %cv1809, ptr %slot303, align 8
  %v1810 = load i64, ptr %slot302, align 8
  %v1811 = load i64, ptr %slot301, align 8
  %op1812 = sub i64 %v1810, %v1811
  store i64 %op1812, ptr %slot304, align 8
  %v1813 = load i64, ptr %slot304, align 8
  %cmp1814 = icmp uge i64 %v1813, 16
  %cv1815 = zext i1 %cmp1814 to i64
  store i64 %cv1815, ptr %slot305, align 8
  %v1816 = load i64, ptr %slot303, align 8
  %v1817 = load i64, ptr %slot305, align 8
  %op1818 = and i64 %v1816, %v1817
  store i64 %op1818, ptr %slot306, align 8
  %v1819 = load i64, ptr %slot306, align 8
  %cond1820 = icmp ne i64 %v1819, 0
  br i1 %cond1820, label %bb_guard351, label %bb_oi8
bb_guard351:
  %v1821 = load i64, ptr %slot301, align 8
  %op1822 = add i64 %v1821, 1152921504606846976
  store i64 %op1822, ptr %slot307, align 8
  %v1823 = load i64, ptr %slot307, align 8
  %cmp1824 = icmp ule i64 %v1823, 2305843009213693952
  %cv1825 = zext i1 %cmp1824 to i64
  store i64 %cv1825, ptr %slot308, align 8
  %v1826 = load i64, ptr %slot308, align 8
  %cond1827 = icmp ne i64 %v1826, 0
  br i1 %cond1827, label %bb_guard357, label %bb_oi8
bb_guard357:
  %v1828 = load i64, ptr %slot302, align 8
  %op1829 = add i64 %v1828, 1152921504606846976
  store i64 %op1829, ptr %slot309, align 8
  %v1830 = load i64, ptr %slot309, align 8
  %cmp1831 = icmp ule i64 %v1830, 2305843009213693952
  %cv1832 = zext i1 %cmp1831 to i64
  store i64 %cv1832, ptr %slot310, align 8
  %v1833 = load i64, ptr %slot310, align 8
  %cond1834 = icmp ne i64 %v1833, 0
  br i1 %cond1834, label %bb_guard359, label %bb_oi8
bb_guard359:
  %v1835 = load i64, ptr %slot25, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i64, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1837, ptr %slot311, align 8
  %v1838 = load i64, ptr %slot311, align 8
  %op1839 = add i64 %v1838, 8
  store i64 %op1839, ptr %slot312, align 8
  %v1840 = load i64, ptr %slot312, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %ld1842 = load i64, ptr %p1841, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1842, ptr %slot313, align 8
  %v1843 = load i64, ptr %slot311, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %ld1845 = load i64, ptr %p1844, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1845, ptr %slot314, align 8
  %v1846 = load i64, ptr %slot313, align 8
  %v1847 = load i64, ptr %slot314, align 8
  %op1848 = sub i64 %v1846, %v1847
  store i64 %op1848, ptr %slot314, align 8
  %v1849 = load i64, ptr %slot302, align 8
  %v1850 = load i64, ptr %slot301, align 8
  %op1851 = sub i64 %v1849, %v1850
  store i64 %op1851, ptr %slot315, align 8
  %v1852 = load i64, ptr %slot314, align 8
  %v1853 = load i64, ptr %slot315, align 8
  %cmp1854 = icmp uge i64 %v1852, %v1853
  %cv1855 = zext i1 %cmp1854 to i64
  store i64 %cv1855, ptr %slot316, align 8
  %v1856 = load i64, ptr %slot316, align 8
  %cond1857 = icmp ne i64 %v1856, 0
  br i1 %cond1857, label %bb_guard361, label %bb_oi8
bb_guard361:
  %v1858 = load i64, ptr %slot311, align 8
  %op1859 = add i64 %v1858, 32
  store i64 %op1859, ptr %slot317, align 8
  %v1860 = load i64, ptr %slot317, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %ld1862 = load i64, ptr %p1861, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1862, ptr %slot318, align 8
  %v1863 = load i64, ptr %slot311, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1865, ptr %slot319, align 8
  %v1866 = load i64, ptr %slot311, align 8
  %op1867 = add i64 %v1866, 16
  store i64 %op1867, ptr %slot320, align 8
  %v1868 = load i64, ptr %slot320, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  %ld1870 = load i64, ptr %p1869, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1870, ptr %slot321, align 8
  %v1871 = load i64, ptr %slot30, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  %v1873 = load i64, ptr %slot311, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  %call1875 = call i32 @myl_rc_list_plain_ready(ptr %p1872, ptr %p1874) nomerge, !dbg !118
  store i32 %call1875, ptr %slot322, align 8
  %v1876 = load i32, ptr %slot322, align 8
  %cv1877 = zext i32 %v1876 to i64
  %cond1878 = icmp ne i64 %cv1877, 0
  br i1 %cond1878, label %bb_rcpresized372, label %bb_oi8
bb_rcpresized372:
  %v1879 = load i64, ptr %slot321, align 8
  %cmp1880 = icmp ult i64 %v1879, 4611686018427387904
  %cv1881 = zext i1 %cmp1880 to i64
  store i64 %cv1881, ptr %slot323, align 8
  %v1882 = load i64, ptr %slot323, align 8
  %cond1883 = icmp ne i64 %v1882, 0
  br i1 %cond1883, label %bb_rcpresized373, label %bb_oi8
bb_rcpresized373:
  br label %bb_fi8
bb_fi8:
  %v1884 = load i64, ptr %slot26, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  %ld1886 = load i64, ptr %p1885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1886, ptr %slot324, align 8
  %v1887 = load i64, ptr %slot324, align 8
  %v1888 = load i64, ptr %slot27, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i64 %v1887, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot23, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %ld1892 = load i64, ptr %p1891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1892, ptr %slot325, align 8
  %v1893 = load i64, ptr %slot325, align 8
  %v1894 = load i64, ptr %slot28, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 %v1893, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot28, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i64, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1898, ptr %slot326, align 8
  %v1899 = load i64, ptr %slot27, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot327, align 8
  %v1902 = load i64, ptr %slot327, align 8
  %v1903 = load i64, ptr %slot326, align 8
  %cmp1904 = icmp slt i64 %v1902, %v1903
  %cv1905 = zext i1 %cmp1904 to i64
  store i64 %cv1905, ptr %slot328, align 8
  %v1906 = load i64, ptr %slot328, align 8
  %v1907 = load i64, ptr %slot27, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i64 %v1906, ptr %p1908, align 8, !alias.scope !3, !noalias !4
  %v1909 = load i64, ptr %slot27, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  %ld1911 = load i64, ptr %p1910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1911, ptr %slot329, align 8
  %v1912 = load i64, ptr %slot329, align 8
  %cond1913 = icmp ne i64 %v1912, 0
  br i1 %cond1913, label %bb_next380, label %bb_i20
bb_next380:
  %v1914 = load i64, ptr %slot27, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i64 18446744073709551615, ptr %p1915, align 8, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot25, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i64, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1918, ptr %slot330, align 8
  %v1919 = load i64, ptr %slot27, align 8
  store i64 %v1919, ptr %slot331, align 8
  %v1920 = load i64, ptr %slot331, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  %ld1922 = load i64, ptr %p1921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1922, ptr %slot332, align 8
  %v1923 = load i64, ptr %slot319, align 8
  %op1924 = mul i64 %v1923, 8
  store i64 %op1924, ptr %slot333, align 8
  %v1925 = load i64, ptr %slot318, align 8
  %v1926 = load i64, ptr %slot333, align 8
  %op1927 = add i64 %v1925, %v1926
  store i64 %op1927, ptr %slot334, align 8
  %v1928 = load i64, ptr %slot332, align 8
  %v1929 = load i64, ptr %slot318, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  %v1931 = load i64, ptr %slot333, align 8
  %egep1932 = getelementptr i8, ptr %p1930, i64 %v1931
  store i64 %v1928, ptr %egep1932, align 8, !alias.scope !12, !noalias !13
  %v1933 = load i64, ptr %slot330, align 8
  %op1934 = add i64 %v1933, 16
  store i64 %op1934, ptr %slot335, align 8
  %v1935 = load i64, ptr %slot319, align 8
  %op1936 = add i64 %v1935, 1
  store i64 %op1936, ptr %slot319, align 8
  %v1937 = load i64, ptr %slot319, align 8
  %v1938 = load i64, ptr %slot330, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i64 %v1937, ptr %p1939, align 8, !alias.scope !6, !noalias !7
  %v1940 = load i64, ptr %slot321, align 8
  %op1941 = add i64 %v1940, 1
  store i64 %op1941, ptr %slot321, align 8
  %v1942 = load i64, ptr %slot321, align 8
  %v1943 = load i64, ptr %slot335, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i64 %v1942, ptr %p1944, align 8, !alias.scope !6, !noalias !7
  %v1945 = load i64, ptr %slot27, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  store i64 0, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  %v1947 = load i64, ptr %slot26, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %ld1949 = load i64, ptr %p1948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1949, ptr %slot336, align 8
  %v1950 = load i64, ptr %slot336, align 8
  %v1951 = load i64, ptr %slot27, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  store i64 %v1950, ptr %p1952, align 8, !alias.scope !3, !noalias !4
  %v1953 = load i64, ptr %slot28, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 1, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot28, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i64, ptr %p1956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1957, ptr %slot337, align 8
  %v1958 = load i64, ptr %slot27, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %ld1960 = load i64, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1960, ptr %slot338, align 8
  %v1961 = load i64, ptr %slot338, align 8
  %v1962 = load i64, ptr %slot337, align 8
  %op1963 = add i64 %v1961, %v1962
  store i64 %op1963, ptr %slot339, align 8
  %v1964 = load i64, ptr %slot339, align 8
  %v1965 = load i64, ptr %slot27, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i64 %v1964, ptr %p1966, align 8, !alias.scope !3, !noalias !4
  %v1967 = load i64, ptr %slot27, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %ld1969 = load i64, ptr %p1968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1969, ptr %slot340, align 8
  %v1970 = load i64, ptr %slot340, align 8
  %v1971 = load i64, ptr %slot26, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  store i64 %v1970, ptr %p1972, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi8
bb_oi8:
  %v1973 = load i64, ptr %slot26, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  %ld1975 = load i64, ptr %p1974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1975, ptr %slot341, align 8
  %v1976 = load i64, ptr %slot341, align 8
  %v1977 = load i64, ptr %slot27, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  store i64 %v1976, ptr %p1978, align 8, !alias.scope !3, !noalias !4
  %v1979 = load i64, ptr %slot23, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  %ld1981 = load i64, ptr %p1980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1981, ptr %slot342, align 8
  %v1982 = load i64, ptr %slot342, align 8
  %v1983 = load i64, ptr %slot28, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  store i64 %v1982, ptr %p1984, align 8, !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot28, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %ld1987 = load i64, ptr %p1986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1987, ptr %slot343, align 8
  %v1988 = load i64, ptr %slot27, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %ld1990 = load i64, ptr %p1989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1990, ptr %slot344, align 8
  %v1991 = load i64, ptr %slot344, align 8
  %v1992 = load i64, ptr %slot343, align 8
  %cmp1993 = icmp slt i64 %v1991, %v1992
  %cv1994 = zext i1 %cmp1993 to i64
  store i64 %cv1994, ptr %slot345, align 8
  %v1995 = load i64, ptr %slot345, align 8
  %v1996 = load i64, ptr %slot27, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i64 %v1995, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  %v1998 = load i64, ptr %slot27, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ld2000 = load i64, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2000, ptr %slot346, align 8
  %v2001 = load i64, ptr %slot346, align 8
  %cond2002 = icmp ne i64 %v2001, 0
  br i1 %cond2002, label %bb_next398, label %bb_i20
bb_next398:
  %v2003 = load i64, ptr %slot27, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  store i64 18446744073709551615, ptr %p2004, align 8, !alias.scope !3, !noalias !4
  %v2005 = load i64, ptr %slot25, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %ld2007 = load i64, ptr %p2006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2007, ptr %slot347, align 8
  %v2008 = load i64, ptr %slot27, align 8
  store i64 %v2008, ptr %slot348, align 8
  %v2009 = load i64, ptr %slot348, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %ld2011 = load i64, ptr %p2010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2011, ptr %slot349, align 8
  %v2012 = load i64, ptr %slot347, align 8
  %op2013 = add i64 %v2012, 0
  store i64 %op2013, ptr %slot350, align 8
  %v2014 = load i64, ptr %slot350, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %ld2016 = load i64, ptr %p2015, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2016, ptr %slot351, align 8
  %v2017 = load i64, ptr %slot347, align 8
  %op2018 = add i64 %v2017, 8
  store i64 %op2018, ptr %slot352, align 8
  %v2019 = load i64, ptr %slot352, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %ld2021 = load i64, ptr %p2020, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2021, ptr %slot353, align 8
  %v2022 = load i64, ptr %slot347, align 8
  %op2023 = add i64 %v2022, 16
  store i64 %op2023, ptr %slot354, align 8
  %v2024 = load i64, ptr %slot354, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %ld2026 = load i64, ptr %p2025, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2026, ptr %slot355, align 8
  %v2027 = load i64, ptr %slot351, align 8
  %v2028 = load i64, ptr %slot353, align 8
  %cmp2029 = icmp ult i64 %v2027, %v2028
  %cv2030 = zext i1 %cmp2029 to i32
  store i32 %cv2030, ptr %slot356, align 8
  %v2031 = load i32, ptr %slot356, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcappend_check402, label %bb_rcappend_slow402
bb_rcappend_check402:
  %v2034 = load i64, ptr %slot21, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %ld2036 = load i32, ptr %p2035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2036, ptr %slot357, align 8
  %v2037 = load i32, ptr %slot357, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcappend_fast402, label %bb_rcappend_query402
bb_rcappend_query402:
  %v2040 = load i64, ptr %slot30, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %v2042 = load i64, ptr %slot347, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %call2044 = call i32 @myl_rc_list_plain_ready(ptr %p2041, ptr %p2043) nomerge, !dbg !120
  store i32 %call2044, ptr %slot358, align 8
  %v2045 = load i32, ptr %slot358, align 8
  %v2046 = load i64, ptr %slot21, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i32 %v2045, ptr %p2047, align 4, !alias.scope !3, !noalias !4
  %v2048 = load i32, ptr %slot358, align 8
  %cv2049 = zext i32 %v2048 to i64
  %cond2050 = icmp ne i64 %cv2049, 0
  br i1 %cond2050, label %bb_rcappend_fast402, label %bb_rcappend_slow402
bb_rcappend_slow402:
  %v2051 = load i64, ptr %slot21, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  store i32 0, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  %v2053 = load i64, ptr %slot348, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %ld2055 = load i64, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2055, ptr %slot359, align 8
  %v2056 = load i64, ptr %slot359, align 8
  %v2057 = load i64, ptr %slot20, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i64 %v2056, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot20, align 8
  store i64 %v2059, ptr %slot360, align 8
  %v2060 = load i64, ptr %slot30, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %v2062 = load i64, ptr %slot347, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %v2064 = load i64, ptr %slot360, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  %call2066 = call i32 @myl_rc_list_append(ptr %p2061, ptr %p2063, ptr %p2065) nomerge, !dbg !120
  store i32 %call2066, ptr %slot361, align 8
  %v2067 = load i32, ptr %slot361, align 8
  %cv2068 = zext i32 %v2067 to i64
  %cond2069 = icmp ne i64 %cv2068, 0
  br i1 %cond2069, label %bb_success414, label %bb_failed414
bb_failed414:
  %v2070 = load i64, ptr %slot1, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2071) nomerge, !dbg !120
  unreachable
bb_success414:
  br label %bb_rcappend_done402
bb_rcappend_fast402:
  %v2072 = load i64, ptr %slot347, align 8
  %op2073 = add i64 %v2072, 32
  store i64 %op2073, ptr %slot362, align 8
  %v2074 = load i64, ptr %slot362, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i64, ptr %p2075, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2076, ptr %slot363, align 8
  %v2077 = load i64, ptr %slot351, align 8
  %op2078 = mul i64 %v2077, 8
  store i64 %op2078, ptr %slot364, align 8
  %v2079 = load i64, ptr %slot363, align 8
  %v2080 = load i64, ptr %slot364, align 8
  %op2081 = add i64 %v2079, %v2080
  store i64 %op2081, ptr %slot365, align 8
  %v2082 = load i64, ptr %slot349, align 8
  %v2083 = load i64, ptr %slot363, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %v2085 = load i64, ptr %slot364, align 8
  %egep2086 = getelementptr i8, ptr %p2084, i64 %v2085
  store i64 %v2082, ptr %egep2086, align 8, !alias.scope !12, !noalias !13
  %v2087 = load i64, ptr %slot347, align 8
  %op2088 = add i64 %v2087, 0
  store i64 %op2088, ptr %slot366, align 8
  %v2089 = load i64, ptr %slot351, align 8
  %op2090 = add i64 %v2089, 1
  store i64 %op2090, ptr %slot367, align 8
  %v2091 = load i64, ptr %slot367, align 8
  %v2092 = load i64, ptr %slot366, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  store i64 %v2091, ptr %p2093, align 8, !alias.scope !6, !noalias !7
  %v2094 = load i64, ptr %slot347, align 8
  %op2095 = add i64 %v2094, 16
  store i64 %op2095, ptr %slot368, align 8
  %v2096 = load i64, ptr %slot355, align 8
  %op2097 = add i64 %v2096, 1
  store i64 %op2097, ptr %slot369, align 8
  %v2098 = load i64, ptr %slot369, align 8
  %v2099 = load i64, ptr %slot368, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i64 %v2098, ptr %p2100, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done402
bb_rcappend_done402:
  %v2101 = load i64, ptr %slot27, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i64 0, ptr %p2102, align 8, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot26, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %ld2105 = load i64, ptr %p2104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2105, ptr %slot370, align 8
  %v2106 = load i64, ptr %slot370, align 8
  %v2107 = load i64, ptr %slot27, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i64 %v2106, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot28, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i64 1, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot28, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot371, align 8
  %v2114 = load i64, ptr %slot27, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i64, ptr %p2115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2116, ptr %slot372, align 8
  %v2117 = load i64, ptr %slot372, align 8
  %v2118 = load i64, ptr %slot371, align 8
  %ovpair2120 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2117, i64 %v2118)
  %op2119 = extractvalue { i64, i1 } %ovpair2120, 0
  %ov2121 = extractvalue { i64, i1 } %ovpair2120, 1
  store i64 %op2119, ptr %slot373, align 8
  %cv2122 = zext i1 %ov2121 to i64
  store i64 %cv2122, ptr %slot374, align 8
  %v2123 = load i64, ptr %slot374, align 8
  %cond2124 = icmp ne i64 %v2123, 0
  br i1 %cond2124, label %bb_overflow426, label %bb_checked426
bb_overflow426:
  %v2125 = load i64, ptr %slot1, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  %v2127 = load i64, ptr %slot372, align 8
  %v2128 = load i64, ptr %slot371, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2126, i64 0, i64 %v2127, i64 %v2128, i64 64) nomerge, !dbg !122
  unreachable
bb_checked426:
  %v2129 = load i64, ptr %slot373, align 8
  %v2130 = load i64, ptr %slot27, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i64 %v2129, ptr %p2131, align 8, !alias.scope !3, !noalias !4
  %v2132 = load i64, ptr %slot27, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %ld2134 = load i64, ptr %p2133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2134, ptr %slot375, align 8
  %v2135 = load i64, ptr %slot375, align 8
  %v2136 = load i64, ptr %slot26, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  store i64 %v2135, ptr %p2137, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi8
bb_i20:
  %v2138 = load i64, ptr %slot22, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i64, ptr %p2139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2140, ptr %slot376, align 8
  %v2141 = load i64, ptr %slot376, align 8
  %v2142 = load i64, ptr %slot27, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i64 %v2141, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot25, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %ld2146 = load i64, ptr %p2145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2146, ptr %slot377, align 8
  %v2147 = load i64, ptr %slot377, align 8
  %v2148 = load i64, ptr %slot28, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  store i64 %v2147, ptr %p2149, align 8, !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot29, align 8
  store i64 %v2150, ptr %slot378, align 8
  %v2151 = load i64, ptr %slot378, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 0, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot378, align 8
  %p2155 = inttoptr i64 %v2153 to ptr
  %gep2156 = getelementptr i8, ptr %p2155, i64 8
  %op2154 = ptrtoint ptr %gep2156 to i64
  store i64 %op2154, ptr %slot379, align 8
  %v2157 = load i64, ptr %slot379, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 0, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot15, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  store i32 1, ptr %p2160, align 4, !alias.scope !3, !noalias !4
  %v2161 = load i64, ptr %slot31, align 8
  store i64 %v2161, ptr %slot380, align 8
  %v2162 = load i64, ptr %slot27, align 8
  store i64 %v2162, ptr %slot381, align 8
  %v2163 = load i64, ptr %slot378, align 8
  %p2165 = inttoptr i64 %v2163 to ptr
  %gep2166 = getelementptr i8, ptr %p2165, i64 0
  %op2164 = ptrtoint ptr %gep2166 to i64
  store i64 %op2164, ptr %slot382, align 8
  %v2167 = load i64, ptr %slot381, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %ld2169 = load i64, ptr %p2168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2169, ptr %slot383, align 8
  %v2170 = load i64, ptr %slot383, align 8
  %v2171 = load i64, ptr %slot382, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  store i64 %v2170, ptr %p2172, align 8, !alias.scope !3, !noalias !4
  %v2173 = load i64, ptr %slot28, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %ld2175 = load i64, ptr %p2174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2175, ptr %slot384, align 8
  %v2176 = load i64, ptr %slot384, align 8
  %v2177 = load i64, ptr %slot18, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  store i64 %v2176, ptr %p2178, align 8, !alias.scope !3, !noalias !4
  %v2179 = load i64, ptr %slot18, align 8
  store i64 %v2179, ptr %slot385, align 8
  %v2180 = load i64, ptr %slot378, align 8
  %p2182 = inttoptr i64 %v2180 to ptr
  %gep2183 = getelementptr i8, ptr %p2182, i64 8
  %op2181 = ptrtoint ptr %gep2183 to i64
  store i64 %op2181, ptr %slot386, align 8
  %v2184 = load i64, ptr %slot28, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  %ld2186 = load i64, ptr %p2185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2186, ptr %slot387, align 8
  %v2187 = load i64, ptr %slot387, align 8
  %v2188 = load i64, ptr %slot18, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i64 %v2187, ptr %p2189, align 8, !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot18, align 8
  store i64 %v2190, ptr %slot388, align 8
  store i32 0, ptr %slot389, align 8
  %v2191 = load i64, ptr %slot12, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i32, ptr %p2192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2193, ptr %slot390, align 8
  %v2194 = load i32, ptr %slot390, align 8
  %op2195 = and i32 %v2194, 24
  store i32 %op2195, ptr %slot390, align 8
  %v2196 = load i32, ptr %slot390, align 8
  %cmp2197 = icmp eq i32 %v2196, 0
  %cv2198 = zext i1 %cmp2197 to i32
  store i32 %cv2198, ptr %slot391, align 8
  %v2199 = load i32, ptr %slot389, align 8
  %v2200 = load i32, ptr %slot391, align 8
  %op2201 = and i32 %v2199, %v2200
  store i32 %op2201, ptr %slot392, align 8
  %v2202 = load i32, ptr %slot392, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rctake444, label %bb_rccopy444
bb_rctake444:
  %v2205 = load i64, ptr %slot19, align 8
  store i64 %v2205, ptr %slot393, align 8
  %v2206 = load i64, ptr %slot31, align 8
  store i64 %v2206, ptr %slot394, align 8
  %v2207 = load i64, ptr %slot388, align 8
  %v2208 = load i64, ptr %slot393, align 8
  %op2209 = sub i64 %v2207, %v2208
  store i64 %op2209, ptr %slot395, align 8
  %v2210 = load i64, ptr %slot393, align 8
  %v2211 = load i64, ptr %slot388, align 8
  %op2212 = sub i64 %v2210, %v2211
  store i64 %op2212, ptr %slot396, align 8
  %v2213 = load i64, ptr %slot395, align 8
  %cmp2214 = icmp ult i64 %v2213, 8
  %cv2215 = zext i1 %cmp2214 to i32
  store i32 %cv2215, ptr %slot397, align 8
  %v2216 = load i64, ptr %slot396, align 8
  %cmp2217 = icmp ult i64 %v2216, 8
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot398, align 8
  %v2219 = load i32, ptr %slot397, align 8
  %v2220 = load i32, ptr %slot398, align 8
  %op2221 = or i32 %v2219, %v2220
  store i32 %op2221, ptr %slot399, align 8
  %v2222 = load i32, ptr %slot399, align 8
  %cv2223 = zext i32 %v2222 to i64
  %cond2224 = icmp ne i64 %cv2223, 0
  br i1 %cond2224, label %bb_rcmoveslow453, label %bb_rcmovecheck453
bb_rcmovecheck453:
  %v2225 = load i64, ptr %slot388, align 8
  %p2227 = inttoptr i64 %v2225 to ptr
  %gep2228 = getelementptr i8, ptr %p2227, i64 0
  %op2226 = ptrtoint ptr %gep2228 to i64
  store i64 %op2226, ptr %slot400, align 8
  %v2229 = load i64, ptr %slot400, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i64, ptr %p2230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2231, ptr %slot401, align 8
  %v2232 = load i64, ptr %slot401, align 8
  %cmp2233 = icmp ne i64 %v2232, 0
  %cv2234 = zext i1 %cmp2233 to i32
  store i32 %cv2234, ptr %slot402, align 8
  %v2235 = load i32, ptr %slot402, align 8
  %cv2236 = zext i32 %v2235 to i64
  %cond2237 = icmp ne i64 %cv2236, 0
  br i1 %cond2237, label %bb_rcmoveheader461, label %bb_rcmovenext461
bb_rcmoveheader461:
  %v2238 = load i64, ptr %slot401, align 8
  %op2239 = sub i64 %v2238, 16
  store i64 %op2239, ptr %slot403, align 8
  %v2240 = load i64, ptr %slot401, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  %rgep2242 = getelementptr i8, ptr %p2241, i64 -16
  %ld2243 = load i64, ptr %rgep2242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2243, ptr %slot404, align 8
  %v2244 = load i64, ptr %slot404, align 8
  %op2245 = and i64 %v2244, 5764607523034234881
  store i64 %op2245, ptr %slot405, align 8
  %v2246 = load i64, ptr %slot405, align 8
  %cmp2247 = icmp ne i64 %v2246, 0
  %cv2248 = zext i1 %cmp2247 to i32
  store i32 %cv2248, ptr %slot406, align 8
  %v2249 = load i32, ptr %slot406, align 8
  %cv2250 = zext i32 %v2249 to i64
  %cond2251 = icmp ne i64 %cv2250, 0
  br i1 %cond2251, label %bb_rcmoveslow453, label %bb_rcmovenext461
bb_rcmovenext461:
  %v2252 = load i64, ptr %slot388, align 8
  %v2253 = load i64, ptr %slot393, align 8
  %p2254 = inttoptr i64 %v2252 to ptr
  %p2255 = inttoptr i64 %v2253 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2255, ptr %p2254, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot388, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i64 0, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved453
bb_rcmoveslow453:
  %v2258 = load i64, ptr %slot30, align 8
  %v2259 = load i64, ptr %slot393, align 8
  %v2260 = load i64, ptr %slot388, align 8
  %v2261 = load i64, ptr %slot394, align 8
  %cv2262 = trunc i64 %v2261 to i32
  %call2263 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2258, i64 %v2259, i64 %v2260, i32 %cv2262) nomerge, !dbg !124
  store i32 %call2263, ptr %slot407, align 8
  %v2264 = load i32, ptr %slot407, align 8
  %cv2265 = zext i32 %v2264 to i64
  %cond2266 = icmp ne i64 %cv2265, 0
  br i1 %cond2266, label %bb_rcsuccess468, label %bb_rcfailure468
bb_rcfailure468:
  %v2267 = load i64, ptr %slot30, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %call2269 = call i32 @myl_rc_take_failure(ptr %p2268) nomerge, !dbg !124
  store i32 %call2269, ptr %slot408, align 8
  %v2270 = load i64, ptr %slot1, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %v2272 = load i32, ptr %slot408, align 8
  %call2273 = call i32 @myl_qbe_rc_status(ptr %p2271, i32 %v2272) nomerge, !dbg !124
  store i32 %call2273, ptr %slot409, align 8
  br label %bb_failure
bb_rcsuccess468:
  br label %bb_rcmoved453
bb_rcmoved453:
  %v2274 = load i64, ptr %slot14, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i32 2, ptr %p2275, align 4, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot13, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i32 1, ptr %p2277, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared444
bb_rccopy444:
  %v2278 = load i64, ptr %slot19, align 8
  store i64 %v2278, ptr %slot410, align 8
  %v2279 = load i64, ptr %slot31, align 8
  store i64 %v2279, ptr %slot411, align 8
  %v2280 = load i64, ptr %slot388, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %ld2282 = load i64, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2282, ptr %slot412, align 8
  %v2283 = load i64, ptr %slot412, align 8
  %cmp2284 = icmp ne i64 %v2283, 0
  %cv2285 = zext i1 %cmp2284 to i32
  store i32 %cv2285, ptr %slot413, align 8
  %v2286 = load i32, ptr %slot413, align 8
  %cv2287 = zext i32 %v2286 to i64
  %cond2288 = icmp ne i64 %cv2287, 0
  br i1 %cond2288, label %bb_rcgnn477, label %bb_rcgplain477
bb_rcgnn477:
  %v2289 = load i64, ptr %slot412, align 8
  %op2290 = sub i64 %v2289, 16
  store i64 %op2290, ptr %slot414, align 8
  %v2291 = load i64, ptr %slot412, align 8
  %p2292 = inttoptr i64 %v2291 to ptr
  %rgep2293 = getelementptr i8, ptr %p2292, i64 -16
  %ld2294 = load i64, ptr %rgep2293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2294, ptr %slot415, align 8
  %v2295 = load i64, ptr %slot415, align 8
  %op2296 = and i64 %v2295, 4611686018427387906
  store i64 %op2296, ptr %slot416, align 8
  %v2297 = load i64, ptr %slot416, align 8
  %cmp2298 = icmp ne i64 %v2297, 0
  %cv2299 = zext i1 %cmp2298 to i32
  store i32 %cv2299, ptr %slot417, align 8
  %v2300 = load i32, ptr %slot417, align 8
  %cv2301 = zext i32 %v2300 to i64
  %cond2302 = icmp ne i64 %cv2301, 0
  br i1 %cond2302, label %bb_rcgspecial477, label %bb_rcginc477
bb_rcginc477:
  %v2303 = load i64, ptr %slot412, align 8
  %op2304 = sub i64 %v2303, 32
  store i64 %op2304, ptr %slot418, align 8
  %v2305 = load i64, ptr %slot412, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %rgep2307 = getelementptr i8, ptr %p2306, i64 -32
  %ld2308 = load i64, ptr %rgep2307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2308, ptr %slot419, align 8
  %v2309 = load i64, ptr %slot419, align 8
  %op2310 = add i64 %v2309, 1
  store i64 %op2310, ptr %slot420, align 8
  %v2311 = load i64, ptr %slot420, align 8
  %cmp2312 = icmp eq i64 %v2311, 0
  %cv2313 = zext i1 %cmp2312 to i32
  store i32 %cv2313, ptr %slot421, align 8
  %v2314 = load i32, ptr %slot421, align 8
  %cv2315 = zext i32 %v2314 to i64
  %cond2316 = icmp ne i64 %cv2315, 0
  br i1 %cond2316, label %bb_rcglimit477, label %bb_rcgcapacity477
bb_rcglimit477:
  %v2317 = load i64, ptr %slot1, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %call2319 = call i32 @myl_qbe_rc_status(ptr %p2318, i32 2) nomerge, !dbg !124
  store i32 %call2319, ptr %slot422, align 8
  br label %bb_failure
bb_rcgcapacity477:
  %v2320 = load i64, ptr %slot420, align 8
  %v2321 = load i64, ptr %slot412, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  %rgep2323 = getelementptr i8, ptr %p2322, i64 -32
  store i64 %v2320, ptr %rgep2323, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain477
bb_rcgspecial477:
  %v2324 = load i64, ptr %slot415, align 8
  %op2325 = and i64 %v2324, 4611686018427387904
  store i64 %op2325, ptr %slot423, align 8
  %v2326 = load i64, ptr %slot423, align 8
  %cmp2327 = icmp ne i64 %v2326, 0
  %cv2328 = zext i1 %cmp2327 to i32
  store i32 %cv2328, ptr %slot424, align 8
  %v2329 = load i32, ptr %slot424, align 8
  %cv2330 = zext i32 %v2329 to i64
  %cond2331 = icmp ne i64 %cv2330, 0
  br i1 %cond2331, label %bb_rcgslow477, label %bb_rcgplain477
bb_rcgslow477:
  %v2332 = load i64, ptr %slot30, align 8
  %v2333 = load i64, ptr %slot410, align 8
  %v2334 = load i64, ptr %slot388, align 8
  %v2335 = load i64, ptr %slot411, align 8
  %cv2336 = trunc i64 %v2335 to i32
  %call2337 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v2332, i64 %v2333, i64 %v2334, i32 %cv2336) nomerge, !dbg !124
  store i32 %call2337, ptr %slot425, align 8
  %v2338 = load i32, ptr %slot425, align 8
  %cv2339 = zext i32 %v2338 to i64
  %cond2340 = icmp ne i64 %cv2339, 0
  br i1 %cond2340, label %bb_rcsuccess491, label %bb_rcfailure491
bb_rcfailure491:
  %v2341 = load i64, ptr %slot30, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %call2343 = call i32 @myl_rc_take_failure(ptr %p2342) nomerge, !dbg !124
  store i32 %call2343, ptr %slot426, align 8
  %v2344 = load i64, ptr %slot1, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  %v2346 = load i32, ptr %slot426, align 8
  %call2347 = call i32 @myl_qbe_rc_status(ptr %p2345, i32 %v2346) nomerge, !dbg !124
  store i32 %call2347, ptr %slot427, align 8
  br label %bb_failure
bb_rcsuccess491:
  br label %bb_rcgdone477
bb_rcgplain477:
  %v2348 = load i64, ptr %slot412, align 8
  %v2349 = load i64, ptr %slot410, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone477
bb_rcgdone477:
  %v2351 = load i64, ptr %slot14, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  store i32 2, ptr %p2352, align 4, !alias.scope !3, !noalias !4
  %v2353 = load i64, ptr %slot13, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i32 1, ptr %p2354, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared444
bb_rcprepared444:
  %v2355 = load i64, ptr %slot19, align 8
  store i64 %v2355, ptr %slot428, align 8
  %v2356 = load i64, ptr %slot428, align 8
  %v2357 = load i64, ptr %slot386, align 8
  %p2358 = inttoptr i64 %v2356 to ptr
  %p2359 = inttoptr i64 %v2357 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2359, ptr %p2358, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot13, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  store i32 0, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  %v2362 = load i64, ptr %slot378, align 8
  %v2363 = load i64, ptr %slot27, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  store i64 %v2362, ptr %p2364, align 8, !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot27, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i64, ptr %p2366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2367, ptr %slot429, align 8
  %v2368 = load i64, ptr %slot16, align 8
  store i64 %v2368, ptr %slot430, align 8
  %v2369 = load i64, ptr %slot429, align 8
  %v2370 = load i64, ptr %slot430, align 8
  %p2371 = inttoptr i64 %v2369 to ptr
  %p2372 = inttoptr i64 %v2370 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2372, ptr %p2371, i64 16, i1 false)
  %v2373 = load i64, ptr %slot11, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  store i32 2, ptr %p2374, align 4, !alias.scope !3, !noalias !4
  %v2375 = load i64, ptr %slot10, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  store i32 1, ptr %p2376, align 4, !alias.scope !3, !noalias !4
  %v2377 = load i64, ptr %slot430, align 8
  %v2378 = load i64, ptr %slot27, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i64 %v2377, ptr %p2379, align 8, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot27, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i64, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2382, ptr %slot431, align 8
  %v2383 = load i64, ptr %slot27, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i64, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2385, ptr %slot432, align 8
  %v2386 = load i64, ptr %slot19, align 8
  store i64 %v2386, ptr %slot433, align 8
  %v2387 = load i64, ptr %slot31, align 8
  store i64 %v2387, ptr %slot434, align 8
  %v2388 = load i64, ptr %slot432, align 8
  %op2389 = add i64 %v2388, 8
  store i64 %op2389, ptr %slot435, align 8
  %v2390 = load i64, ptr %slot435, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %ld2392 = load i64, ptr %p2391, align 8
  store i64 %ld2392, ptr %slot436, align 8
  %v2393 = load i64, ptr %slot436, align 8
  %cmp2394 = icmp ne i64 %v2393, 0
  %cv2395 = zext i1 %cmp2394 to i32
  store i32 %cv2395, ptr %slot437, align 8
  %v2396 = load i32, ptr %slot437, align 8
  %cv2397 = zext i32 %v2396 to i64
  %cond2398 = icmp ne i64 %cv2397, 0
  br i1 %cond2398, label %bb_rcmoveheader546, label %bb_rcmovenext546
bb_rcmoveheader546:
  %v2399 = load i64, ptr %slot436, align 8
  %op2400 = sub i64 %v2399, 16
  store i64 %op2400, ptr %slot438, align 8
  %v2401 = load i64, ptr %slot436, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  %rgep2403 = getelementptr i8, ptr %p2402, i64 -16
  %ld2404 = load i64, ptr %rgep2403, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2404, ptr %slot439, align 8
  %v2405 = load i64, ptr %slot439, align 8
  %op2406 = and i64 %v2405, 5764607523034234881
  store i64 %op2406, ptr %slot440, align 8
  %v2407 = load i64, ptr %slot440, align 8
  %cmp2408 = icmp ne i64 %v2407, 0
  %cv2409 = zext i1 %cmp2408 to i32
  store i32 %cv2409, ptr %slot441, align 8
  %v2410 = load i32, ptr %slot441, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcmoveslow543, label %bb_rcmovenext546
bb_rcmovenext546:
  %v2413 = load i64, ptr %slot432, align 8
  %v2414 = load i64, ptr %slot433, align 8
  %p2415 = inttoptr i64 %v2413 to ptr
  %p2416 = inttoptr i64 %v2414 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2416, ptr %p2415, i64 16, i1 false)
  %v2417 = load i64, ptr %slot432, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  store i64 0, ptr %p2418, align 8
  %v2419 = load i64, ptr %slot432, align 8
  %op2420 = add i64 %v2419, 8
  store i64 %op2420, ptr %slot442, align 8
  %v2421 = load i64, ptr %slot442, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i64 0, ptr %p2422, align 8
  br label %bb_rcmoved543
bb_rcmoveslow543:
  %v2423 = load i64, ptr %slot30, align 8
  %v2424 = load i64, ptr %slot433, align 8
  %v2425 = load i64, ptr %slot432, align 8
  %v2426 = load i64, ptr %slot434, align 8
  %cv2427 = trunc i64 %v2426 to i32
  %call2428 = call i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64 %v2423, i64 %v2424, i64 %v2425, i32 %cv2427) nomerge, !dbg !126
  store i32 %call2428, ptr %slot443, align 8
  %v2429 = load i32, ptr %slot443, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcsuccess554, label %bb_rcfailure554
bb_rcfailure554:
  %v2432 = load i64, ptr %slot30, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  %call2434 = call i32 @myl_rc_take_failure(ptr %p2433) nomerge, !dbg !126
  store i32 %call2434, ptr %slot444, align 8
  %v2435 = load i64, ptr %slot1, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %v2437 = load i32, ptr %slot444, align 8
  %call2438 = call i32 @myl_qbe_rc_status(ptr %p2436, i32 %v2437) nomerge, !dbg !126
  store i32 %call2438, ptr %slot445, align 8
  br label %bb_failure
bb_rcsuccess554:
  br label %bb_rcmoved543
bb_rcmoved543:
  %v2439 = load i64, ptr %slot10, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  store i32 0, ptr %p2440, align 4, !alias.scope !3, !noalias !4
  %v2441 = load i64, ptr %slot14, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 2, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot13, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  store i32 1, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  %v2445 = load i64, ptr %slot19, align 8
  store i64 %v2445, ptr %slot446, align 8
  %v2446 = load i64, ptr %slot13, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i32 0, ptr %p2447, align 4, !alias.scope !3, !noalias !4
  %v2448 = load i64, ptr %slot10, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %ld2450 = load i32, ptr %p2449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2450, ptr %slot447, align 8
  %v2451 = load i32, ptr %slot447, align 8
  %cv2452 = zext i32 %v2451 to i64
  %cond2453 = icmp ne i64 %cv2452, 0
  br i1 %cond2453, label %bb_rcslotdrop564, label %bb_rcslotdone564
bb_rcslotdrop564:
  %v2454 = load i64, ptr %slot10, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i32 0, ptr %p2455, align 4, !alias.scope !3, !noalias !4
  %v2456 = load i64, ptr %slot16, align 8
  store i64 %v2456, ptr %slot448, align 8
  %v2457 = load i64, ptr %slot11, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i32, ptr %p2458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2459, ptr %slot449, align 8
  %v2460 = load i32, ptr %slot449, align 8
  %op2461 = and i32 %v2460, 28
  store i32 %op2461, ptr %slot450, align 8
  %v2462 = load i32, ptr %slot450, align 8
  %cv2463 = zext i32 %v2462 to i64
  %cond2464 = icmp ne i64 %cv2463, 0
  br i1 %cond2464, label %bb_rcslotrole564, label %bb_rcslotowner564
bb_rcslotrole564:
  %v2465 = load i64, ptr %slot30, align 8
  store i64 %v2465, ptr %slot451, align 8
  %v2466 = load i64, ptr %slot451, align 8
  %v2467 = load i64, ptr %slot448, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v2466, i64 %v2467) nomerge, !dbg !126
  br label %bb_rcslotdone564
bb_rcslotowner564:
  %v2468 = load i64, ptr %slot30, align 8
  store i64 %v2468, ptr %slot452, align 8
  %v2469 = load i64, ptr %slot452, align 8
  %v2470 = load i64, ptr %slot448, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v2469, i64 %v2470) nomerge, !dbg !126
  br label %bb_rcslotdone564
bb_rcslotdone564:
  %v2471 = load i64, ptr %slot8, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %ld2473 = load i32, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2473, ptr %slot453, align 8
  %v2474 = load i32, ptr %slot453, align 8
  %cv2475 = zext i32 %v2474 to i64
  %cond2476 = icmp ne i64 %cv2475, 0
  br i1 %cond2476, label %bb_rcslotdrop573, label %bb_rcslotdone573
bb_rcslotdrop573:
  %v2477 = load i64, ptr %slot8, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  store i32 0, ptr %p2478, align 4, !alias.scope !3, !noalias !4
  %v2479 = load i64, ptr %slot25, align 8
  store i64 %v2479, ptr %slot454, align 8
  %v2480 = load i64, ptr %slot9, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %ld2482 = load i32, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2482, ptr %slot455, align 8
  %v2483 = load i32, ptr %slot455, align 8
  %op2484 = and i32 %v2483, 28
  store i32 %op2484, ptr %slot456, align 8
  %v2485 = load i32, ptr %slot456, align 8
  %cv2486 = zext i32 %v2485 to i64
  %cond2487 = icmp ne i64 %cv2486, 0
  br i1 %cond2487, label %bb_rcslotrole573, label %bb_rcslotowner573
bb_rcslotrole573:
  %v2488 = load i64, ptr %slot30, align 8
  store i64 %v2488, ptr %slot457, align 8
  %v2489 = load i64, ptr %slot454, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %ld2491 = load i64, ptr %p2490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2491, ptr %slot458, align 8
  %v2492 = load i64, ptr %slot458, align 8
  %cmp2493 = icmp ne i64 %v2492, 0
  %cv2494 = zext i1 %cmp2493 to i32
  store i32 %cv2494, ptr %slot459, align 8
  %v2495 = load i32, ptr %slot459, align 8
  %cv2496 = zext i32 %v2495 to i64
  %cond2497 = icmp ne i64 %cv2496, 0
  br i1 %cond2497, label %bb_rcgnn589, label %bb_rcgdone589
bb_rcgnn589:
  %v2498 = load i64, ptr %slot458, align 8
  %op2499 = sub i64 %v2498, 16
  store i64 %op2499, ptr %slot460, align 8
  %v2500 = load i64, ptr %slot458, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  %rgep2502 = getelementptr i8, ptr %p2501, i64 -16
  %ld2503 = load i64, ptr %rgep2502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2503, ptr %slot461, align 8
  %v2504 = load i64, ptr %slot461, align 8
  %op2505 = and i64 %v2504, 4611686018427387906
  store i64 %op2505, ptr %slot462, align 8
  %v2506 = load i64, ptr %slot462, align 8
  %cmp2507 = icmp ne i64 %v2506, 0
  %cv2508 = zext i1 %cmp2507 to i32
  store i32 %cv2508, ptr %slot463, align 8
  %v2509 = load i32, ptr %slot463, align 8
  %cv2510 = zext i32 %v2509 to i64
  %cond2511 = icmp ne i64 %cv2510, 0
  br i1 %cond2511, label %bb_rcgclear589, label %bb_rcgcounted589
bb_rcgcounted589:
  %v2512 = load i64, ptr %slot458, align 8
  %op2513 = sub i64 %v2512, 24
  store i64 %op2513, ptr %slot464, align 8
  %v2514 = load i64, ptr %slot458, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %rgep2516 = getelementptr i8, ptr %p2515, i64 -24
  %ld2517 = load i64, ptr %rgep2516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2517, ptr %slot465, align 8
  %v2518 = load i64, ptr %slot465, align 8
  %op2519 = sub i64 %v2518, 1
  store i64 %op2519, ptr %slot466, align 8
  %v2520 = load i64, ptr %slot466, align 8
  %cmp2521 = icmp eq i64 %v2520, 0
  %cv2522 = zext i1 %cmp2521 to i32
  store i32 %cv2522, ptr %slot467, align 8
  %v2523 = load i32, ptr %slot467, align 8
  %cv2524 = zext i32 %v2523 to i64
  %cond2525 = icmp ne i64 %cv2524, 0
  br i1 %cond2525, label %bb_rcglast589, label %bb_rcgdec589
bb_rcglast589:
  %v2526 = load i64, ptr %slot458, align 8
  %op2527 = sub i64 %v2526, 32
  store i64 %op2527, ptr %slot468, align 8
  %v2528 = load i64, ptr %slot458, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %rgep2530 = getelementptr i8, ptr %p2529, i64 -32
  %ld2531 = load i64, ptr %rgep2530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2531, ptr %slot469, align 8
  %v2532 = load i64, ptr %slot469, align 8
  %cmp2533 = icmp ne i64 %v2532, 0
  %cv2534 = zext i1 %cmp2533 to i32
  store i32 %cv2534, ptr %slot470, align 8
  %v2535 = load i32, ptr %slot470, align 8
  %cv2536 = zext i32 %v2535 to i64
  %cond2537 = icmp ne i64 %cv2536, 0
  br i1 %cond2537, label %bb_rcgdec589, label %bb_rcgslow589
bb_rcgslow589:
  %v2538 = load i64, ptr %slot457, align 8
  %v2539 = load i64, ptr %slot454, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2538, i64 %v2539) nomerge, !dbg !126
  br label %bb_rcgdone589
bb_rcgdec589:
  %v2540 = load i64, ptr %slot466, align 8
  %v2541 = load i64, ptr %slot458, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %rgep2543 = getelementptr i8, ptr %p2542, i64 -24
  store i64 %v2540, ptr %rgep2543, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear589
bb_rcgclear589:
  %v2544 = load i64, ptr %slot454, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  store i64 0, ptr %p2545, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone589
bb_rcgdone589:
  br label %bb_rcslotdone573
bb_rcslotowner573:
  %v2546 = load i64, ptr %slot30, align 8
  store i64 %v2546, ptr %slot471, align 8
  %v2547 = load i64, ptr %slot454, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  %ld2549 = load i64, ptr %p2548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2549, ptr %slot472, align 8
  %v2550 = load i64, ptr %slot472, align 8
  %cmp2551 = icmp ne i64 %v2550, 0
  %cv2552 = zext i1 %cmp2551 to i32
  store i32 %cv2552, ptr %slot473, align 8
  %v2553 = load i32, ptr %slot473, align 8
  %cv2554 = zext i32 %v2553 to i64
  %cond2555 = icmp ne i64 %cv2554, 0
  br i1 %cond2555, label %bb_rcgnn604, label %bb_rcgdone604
bb_rcgnn604:
  %v2556 = load i64, ptr %slot472, align 8
  %op2557 = sub i64 %v2556, 16
  store i64 %op2557, ptr %slot474, align 8
  %v2558 = load i64, ptr %slot472, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  %rgep2560 = getelementptr i8, ptr %p2559, i64 -16
  %ld2561 = load i64, ptr %rgep2560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2561, ptr %slot475, align 8
  %v2562 = load i64, ptr %slot475, align 8
  %op2563 = and i64 %v2562, 4611686018427387906
  store i64 %op2563, ptr %slot476, align 8
  %v2564 = load i64, ptr %slot476, align 8
  %cmp2565 = icmp ne i64 %v2564, 0
  %cv2566 = zext i1 %cmp2565 to i32
  store i32 %cv2566, ptr %slot477, align 8
  %v2567 = load i32, ptr %slot477, align 8
  %cv2568 = zext i32 %v2567 to i64
  %cond2569 = icmp ne i64 %cv2568, 0
  br i1 %cond2569, label %bb_rcgclear604, label %bb_rcgcounted604
bb_rcgcounted604:
  %v2570 = load i64, ptr %slot472, align 8
  %op2571 = sub i64 %v2570, 32
  store i64 %op2571, ptr %slot478, align 8
  %v2572 = load i64, ptr %slot472, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  %rgep2574 = getelementptr i8, ptr %p2573, i64 -32
  %ld2575 = load i64, ptr %rgep2574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2575, ptr %slot479, align 8
  %v2576 = load i64, ptr %slot479, align 8
  %op2577 = sub i64 %v2576, 1
  store i64 %op2577, ptr %slot480, align 8
  %v2578 = load i64, ptr %slot480, align 8
  %cmp2579 = icmp eq i64 %v2578, 0
  %cv2580 = zext i1 %cmp2579 to i32
  store i32 %cv2580, ptr %slot481, align 8
  %v2581 = load i32, ptr %slot481, align 8
  %cv2582 = zext i32 %v2581 to i64
  %cond2583 = icmp ne i64 %cv2582, 0
  br i1 %cond2583, label %bb_rcglast604, label %bb_rcgdec604
bb_rcglast604:
  %v2584 = load i64, ptr %slot472, align 8
  %op2585 = sub i64 %v2584, 24
  store i64 %op2585, ptr %slot482, align 8
  %v2586 = load i64, ptr %slot472, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  %rgep2588 = getelementptr i8, ptr %p2587, i64 -24
  %ld2589 = load i64, ptr %rgep2588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2589, ptr %slot483, align 8
  %v2590 = load i64, ptr %slot483, align 8
  %cmp2591 = icmp ne i64 %v2590, 0
  %cv2592 = zext i1 %cmp2591 to i32
  store i32 %cv2592, ptr %slot484, align 8
  %v2593 = load i32, ptr %slot484, align 8
  %cv2594 = zext i32 %v2593 to i64
  %cond2595 = icmp ne i64 %cv2594, 0
  br i1 %cond2595, label %bb_rcgdec604, label %bb_rcgslow604
bb_rcgslow604:
  %v2596 = load i64, ptr %slot471, align 8
  %v2597 = load i64, ptr %slot454, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2596, i64 %v2597) nomerge, !dbg !126
  br label %bb_rcgdone604
bb_rcgdec604:
  %v2598 = load i64, ptr %slot480, align 8
  %v2599 = load i64, ptr %slot472, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  %rgep2601 = getelementptr i8, ptr %p2600, i64 -32
  store i64 %v2598, ptr %rgep2601, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear604
bb_rcgclear604:
  %v2602 = load i64, ptr %slot454, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  store i64 0, ptr %p2603, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone604
bb_rcgdone604:
  br label %bb_rcslotdone573
bb_rcslotdone573:
  %v2604 = load i64, ptr %slot6, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i32, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2606, ptr %slot485, align 8
  %v2607 = load i32, ptr %slot485, align 8
  %cv2608 = zext i32 %v2607 to i64
  %cond2609 = icmp ne i64 %cv2608, 0
  br i1 %cond2609, label %bb_rcslotdrop610, label %bb_rcslotdone610
bb_rcslotdrop610:
  %v2610 = load i64, ptr %slot6, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 0, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot24, align 8
  store i64 %v2612, ptr %slot486, align 8
  %v2613 = load i64, ptr %slot7, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i32, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2615, ptr %slot487, align 8
  %v2616 = load i32, ptr %slot487, align 8
  %op2617 = and i32 %v2616, 28
  store i32 %op2617, ptr %slot488, align 8
  %v2618 = load i32, ptr %slot488, align 8
  %cv2619 = zext i32 %v2618 to i64
  %cond2620 = icmp ne i64 %cv2619, 0
  br i1 %cond2620, label %bb_rcslotrole610, label %bb_rcslotowner610
bb_rcslotrole610:
  %v2621 = load i64, ptr %slot30, align 8
  store i64 %v2621, ptr %slot489, align 8
  %v2622 = load i64, ptr %slot486, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %ld2624 = load i64, ptr %p2623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2624, ptr %slot490, align 8
  %v2625 = load i64, ptr %slot490, align 8
  %cmp2626 = icmp ne i64 %v2625, 0
  %cv2627 = zext i1 %cmp2626 to i32
  store i32 %cv2627, ptr %slot491, align 8
  %v2628 = load i32, ptr %slot491, align 8
  %cv2629 = zext i32 %v2628 to i64
  %cond2630 = icmp ne i64 %cv2629, 0
  br i1 %cond2630, label %bb_rcgnn626, label %bb_rcgdone626
bb_rcgnn626:
  %v2631 = load i64, ptr %slot490, align 8
  %op2632 = sub i64 %v2631, 16
  store i64 %op2632, ptr %slot492, align 8
  %v2633 = load i64, ptr %slot490, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %rgep2635 = getelementptr i8, ptr %p2634, i64 -16
  %ld2636 = load i64, ptr %rgep2635, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2636, ptr %slot493, align 8
  %v2637 = load i64, ptr %slot493, align 8
  %op2638 = and i64 %v2637, 4611686018427387906
  store i64 %op2638, ptr %slot494, align 8
  %v2639 = load i64, ptr %slot494, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot495, align 8
  %v2642 = load i32, ptr %slot495, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcgclear626, label %bb_rcgcounted626
bb_rcgcounted626:
  %v2645 = load i64, ptr %slot490, align 8
  %op2646 = sub i64 %v2645, 24
  store i64 %op2646, ptr %slot496, align 8
  %v2647 = load i64, ptr %slot490, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -24
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot497, align 8
  %v2651 = load i64, ptr %slot497, align 8
  %op2652 = sub i64 %v2651, 1
  store i64 %op2652, ptr %slot498, align 8
  %v2653 = load i64, ptr %slot498, align 8
  %cmp2654 = icmp eq i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot499, align 8
  %v2656 = load i32, ptr %slot499, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcglast626, label %bb_rcgdec626
bb_rcglast626:
  %v2659 = load i64, ptr %slot490, align 8
  %op2660 = sub i64 %v2659, 32
  store i64 %op2660, ptr %slot500, align 8
  %v2661 = load i64, ptr %slot490, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -32
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot501, align 8
  %v2665 = load i64, ptr %slot501, align 8
  %cmp2666 = icmp ne i64 %v2665, 0
  %cv2667 = zext i1 %cmp2666 to i32
  store i32 %cv2667, ptr %slot502, align 8
  %v2668 = load i32, ptr %slot502, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcgdec626, label %bb_rcgslow626
bb_rcgslow626:
  %v2671 = load i64, ptr %slot489, align 8
  %v2672 = load i64, ptr %slot486, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2671, i64 %v2672) nomerge, !dbg !126
  br label %bb_rcgdone626
bb_rcgdec626:
  %v2673 = load i64, ptr %slot498, align 8
  %v2674 = load i64, ptr %slot490, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %rgep2676 = getelementptr i8, ptr %p2675, i64 -24
  store i64 %v2673, ptr %rgep2676, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear626
bb_rcgclear626:
  %v2677 = load i64, ptr %slot486, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  store i64 0, ptr %p2678, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone626
bb_rcgdone626:
  br label %bb_rcslotdone610
bb_rcslotowner610:
  %v2679 = load i64, ptr %slot30, align 8
  store i64 %v2679, ptr %slot503, align 8
  %v2680 = load i64, ptr %slot486, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  %ld2682 = load i64, ptr %p2681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2682, ptr %slot504, align 8
  %v2683 = load i64, ptr %slot504, align 8
  %cmp2684 = icmp ne i64 %v2683, 0
  %cv2685 = zext i1 %cmp2684 to i32
  store i32 %cv2685, ptr %slot505, align 8
  %v2686 = load i32, ptr %slot505, align 8
  %cv2687 = zext i32 %v2686 to i64
  %cond2688 = icmp ne i64 %cv2687, 0
  br i1 %cond2688, label %bb_rcgnn641, label %bb_rcgdone641
bb_rcgnn641:
  %v2689 = load i64, ptr %slot504, align 8
  %op2690 = sub i64 %v2689, 16
  store i64 %op2690, ptr %slot506, align 8
  %v2691 = load i64, ptr %slot504, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %rgep2693 = getelementptr i8, ptr %p2692, i64 -16
  %ld2694 = load i64, ptr %rgep2693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2694, ptr %slot507, align 8
  %v2695 = load i64, ptr %slot507, align 8
  %op2696 = and i64 %v2695, 4611686018427387906
  store i64 %op2696, ptr %slot508, align 8
  %v2697 = load i64, ptr %slot508, align 8
  %cmp2698 = icmp ne i64 %v2697, 0
  %cv2699 = zext i1 %cmp2698 to i32
  store i32 %cv2699, ptr %slot509, align 8
  %v2700 = load i32, ptr %slot509, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcgclear641, label %bb_rcgcounted641
bb_rcgcounted641:
  %v2703 = load i64, ptr %slot504, align 8
  %op2704 = sub i64 %v2703, 32
  store i64 %op2704, ptr %slot510, align 8
  %v2705 = load i64, ptr %slot504, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %rgep2707 = getelementptr i8, ptr %p2706, i64 -32
  %ld2708 = load i64, ptr %rgep2707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2708, ptr %slot511, align 8
  %v2709 = load i64, ptr %slot511, align 8
  %op2710 = sub i64 %v2709, 1
  store i64 %op2710, ptr %slot512, align 8
  %v2711 = load i64, ptr %slot512, align 8
  %cmp2712 = icmp eq i64 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot513, align 8
  %v2714 = load i32, ptr %slot513, align 8
  %cv2715 = zext i32 %v2714 to i64
  %cond2716 = icmp ne i64 %cv2715, 0
  br i1 %cond2716, label %bb_rcglast641, label %bb_rcgdec641
bb_rcglast641:
  %v2717 = load i64, ptr %slot504, align 8
  %op2718 = sub i64 %v2717, 24
  store i64 %op2718, ptr %slot514, align 8
  %v2719 = load i64, ptr %slot504, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %rgep2721 = getelementptr i8, ptr %p2720, i64 -24
  %ld2722 = load i64, ptr %rgep2721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2722, ptr %slot515, align 8
  %v2723 = load i64, ptr %slot515, align 8
  %cmp2724 = icmp ne i64 %v2723, 0
  %cv2725 = zext i1 %cmp2724 to i32
  store i32 %cv2725, ptr %slot516, align 8
  %v2726 = load i32, ptr %slot516, align 8
  %cv2727 = zext i32 %v2726 to i64
  %cond2728 = icmp ne i64 %cv2727, 0
  br i1 %cond2728, label %bb_rcgdec641, label %bb_rcgslow641
bb_rcgslow641:
  %v2729 = load i64, ptr %slot503, align 8
  %v2730 = load i64, ptr %slot486, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2729, i64 %v2730) nomerge, !dbg !126
  br label %bb_rcgdone641
bb_rcgdec641:
  %v2731 = load i64, ptr %slot512, align 8
  %v2732 = load i64, ptr %slot504, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  %rgep2734 = getelementptr i8, ptr %p2733, i64 -32
  store i64 %v2731, ptr %rgep2734, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear641
bb_rcgclear641:
  %v2735 = load i64, ptr %slot486, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i64 0, ptr %p2736, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone641
bb_rcgdone641:
  br label %bb_rcslotdone610
bb_rcslotdone610:
  %v2737 = load i64, ptr %slot446, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %ret2739 = load { i64, i64 }, ptr %p2738, align 8
  ret { i64, i64 } %ret2739
bb_failure:
  %v2740 = load i64, ptr %slot5, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  call void @llvm.memset.p0.i64(ptr %p2741, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v2742 = load i64, ptr %slot5, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %ret2744 = load { i64, i64 }, ptr %p2743, align 8
  ret { i64, i64 } %ret2744
bb_entry_failure:
  %v2745 = load i64, ptr %slot5, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  call void @llvm.memset.p0.i64(ptr %p2746, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v2747 = load i64, ptr %slot5, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  %ret2749 = load { i64, i64 }, ptr %p2748, align 8
  ret { i64, i64 } %ret2749
}

@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64, i64)
declare i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71", linkageName: "myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13381388368070048351, i64 0, !"myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!122 = !DILocation(line: 18, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!124 = !DILocation(line: 24, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!126 = !DILocation(line: 25, column: 0, scope: !127)
