target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %callresult24 = alloca [88 x i8], align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v86 = load i64, ptr %slot1, align 8
  %op87 = add i64 %v86, 32
  store i64 %op87, ptr %slot3, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot4, align 8
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot5, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot6, align 8
  %mem94 = alloca i8, i64 8, align 8
  %ptr95 = ptrtoint ptr %mem94 to i64
  store i64 %ptr95, ptr %slot7, align 8
  %mem96 = alloca i8, i64 392, align 8
  %ptr97 = ptrtoint ptr %mem96 to i64
  store i64 %ptr97, ptr %slot8, align 8
  %mem98 = alloca i8, i64 392, align 8
  %ptr99 = ptrtoint ptr %mem98 to i64
  store i64 %ptr99, ptr %slot9, align 8
  %mem100 = alloca i8, i64 8, align 8
  %ptr101 = ptrtoint ptr %mem100 to i64
  store i64 %ptr101, ptr %slot10, align 8
  %mem102 = alloca i8, i64 8, align 8
  %ptr103 = ptrtoint ptr %mem102 to i64
  store i64 %ptr103, ptr %slot11, align 8
  %mem104 = alloca i8, i64 8, align 8
  %ptr105 = ptrtoint ptr %mem104 to i64
  store i64 %ptr105, ptr %slot12, align 8
  %mem106 = alloca i8, i64 8, align 8
  %ptr107 = ptrtoint ptr %mem106 to i64
  store i64 %ptr107, ptr %slot13, align 8
  %mem108 = alloca i8, i64 88, align 8
  %ptr109 = ptrtoint ptr %mem108 to i64
  store i64 %ptr109, ptr %slot14, align 8
  %mem110 = alloca i8, i64 8, align 8
  %ptr111 = ptrtoint ptr %mem110 to i64
  store i64 %ptr111, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem112 = alloca i8, i64 8, align 8
  %ptr113 = ptrtoint ptr %mem112 to i64
  store i64 %ptr113, ptr %slot16, align 8
  %v114 = load i64, ptr %slot1, align 8
  %op115 = add i64 %v114, 64
  store i64 %op115, ptr %slot17, align 8
  %v116 = load i64, ptr %slot17, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !4, !noalias !3
  store i64 %ld118, ptr %slot18, align 8
  %stack119 = call ptr @llvm.stacksave()
  %stackaddr120 = ptrtoint ptr %stack119 to i64
  %v121 = load i64, ptr %slot18, align 8
  %cmp122 = icmp ult i64 %stackaddr120, %v121
  %cv123 = zext i1 %cmp122 to i64
  store i64 %cv123, ptr %slot19, align 8
  %v124 = load i64, ptr %slot19, align 8
  %cond125 = icmp ne i64 %v124, 0
  br i1 %cond125, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v126 = load i64, ptr %slot1, align 8
  %p127 = inttoptr i64 %v126 to ptr
  call void @myl_qbe_fail_frame(ptr %p127) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v128 = load i64, ptr %slot2, align 8
  %v129 = load i64, ptr %slot10, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot1, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %call133 = call ptr @myl_qbe_heap(ptr %p132) nomerge, !dbg !112
  %calladdr134 = ptrtoint ptr %call133 to i64
  store i64 %calladdr134, ptr %slot20, align 8
  %v135 = load i64, ptr %slot4, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i32 0, ptr %p136, align 4, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot5, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i32 0, ptr %p138, align 4, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot6, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i32 0, ptr %p140, align 4, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot7, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i32 0, ptr %p142, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v143 = load i64, ptr %slot10, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot21, align 8
  %v146 = load i64, ptr %slot21, align 8
  %v147 = load i64, ptr %slot11, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot11, align 8
  %p150 = inttoptr i64 %v149 to ptr
  %ld151 = load i64, ptr %p150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld151, ptr %slot22, align 8
  %v152 = load i64, ptr %slot1, align 8
  %v153 = load i64, ptr %slot22, align 8
  call void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %callresult24, i64 %v152, i64 %v153) nomerge, !dbg !114
  %addr154 = ptrtoint ptr %callresult24 to i64
  store i64 %addr154, ptr %slot23, align 8
  %v155 = load i64, ptr %slot23, align 8
  %v156 = load i64, ptr %slot11, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot11, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot25, align 8
  %v161 = load i64, ptr %slot9, align 8
  store i64 %v161, ptr %slot26, align 8
  %v162 = load i64, ptr %slot25, align 8
  %v163 = load i64, ptr %slot26, align 8
  %p164 = inttoptr i64 %v162 to ptr
  %p165 = inttoptr i64 %v163 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p165, ptr %p164, i64 88, i1 false)
  %v166 = load i64, ptr %slot7, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 2, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot6, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 1, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot4, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i32, ptr %p171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld172, ptr %slot27, align 8
  %v173 = load i32, ptr %slot27, align 8
  %cv174 = zext i32 %v173 to i64
  %cond175 = icmp ne i64 %cv174, 0
  br i1 %cond175, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v176 = load i64, ptr %slot4, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 0, ptr %p177, align 4, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot8, align 8
  store i64 %v178, ptr %slot28, align 8
  %v179 = load i64, ptr %slot5, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i32, ptr %p180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld181, ptr %slot29, align 8
  %v182 = load i32, ptr %slot29, align 8
  %op183 = and i32 %v182, 28
  store i32 %op183, ptr %slot30, align 8
  %v184 = load i32, ptr %slot30, align 8
  %cv185 = zext i32 %v184 to i64
  %cond186 = icmp ne i64 %cv185, 0
  br i1 %cond186, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v187 = load i64, ptr %slot20, align 8
  store i64 %v187, ptr %slot31, align 8
  %v188 = load i64, ptr %slot31, align 8
  %v189 = load i64, ptr %slot28, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v188, i64 %v189) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v190 = load i64, ptr %slot20, align 8
  store i64 %v190, ptr %slot32, align 8
  %v191 = load i64, ptr %slot32, align 8
  %v192 = load i64, ptr %slot28, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v191, i64 %v192) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v193 = load i64, ptr %slot8, align 8
  store i64 %v193, ptr %slot33, align 8
  %v194 = load i64, ptr %slot9, align 8
  store i64 %v194, ptr %slot34, align 8
  %v195 = load i64, ptr %slot34, align 8
  %v196 = load i64, ptr %slot33, align 8
  %p197 = inttoptr i64 %v195 to ptr
  %p198 = inttoptr i64 %v196 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p198, ptr %p197, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot5, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i32 2, ptr %p200, align 4, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot7, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i32, ptr %p202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld203, ptr %slot35, align 8
  %v204 = load i32, ptr %slot35, align 8
  %v205 = load i64, ptr %slot5, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i32 %v204, ptr %p206, align 4, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot6, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i32 0, ptr %p208, align 4, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot4, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i32 1, ptr %p210, align 4, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot33, align 8
  %v212 = load i64, ptr %slot11, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot11, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot36, align 8
  %v217 = load i64, ptr %slot36, align 8
  %op218 = add i64 %v217, 56
  store i64 %op218, ptr %slot37, align 8
  %v219 = load i64, ptr %slot37, align 8
  %v220 = load i64, ptr %slot11, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i64 %v219, ptr %p221, align 8, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot11, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot38, align 8
  %v225 = load i64, ptr %slot14, align 8
  store i64 %v225, ptr %slot39, align 8
  %v226 = load i64, ptr %slot38, align 8
  %v227 = load i64, ptr %slot39, align 8
  %p228 = inttoptr i64 %v226 to ptr
  %p229 = inttoptr i64 %v227 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p229, ptr %p228, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot39, align 8
  %v231 = load i64, ptr %slot11, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 %v230, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot4, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i32, ptr %p234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld235, ptr %slot40, align 8
  %v236 = load i32, ptr %slot40, align 8
  %cv237 = zext i32 %v236 to i64
  %cond238 = icmp ne i64 %cv237, 0
  br i1 %cond238, label %bb_rcslotdrop38, label %bb_rcslotdone38
bb_rcslotdrop38:
  %v239 = load i64, ptr %slot4, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i32 0, ptr %p240, align 4, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot8, align 8
  store i64 %v241, ptr %slot41, align 8
  %v242 = load i64, ptr %slot5, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i32, ptr %p243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld244, ptr %slot42, align 8
  %v245 = load i32, ptr %slot42, align 8
  %op246 = and i32 %v245, 28
  store i32 %op246, ptr %slot43, align 8
  %v247 = load i32, ptr %slot43, align 8
  %cv248 = zext i32 %v247 to i64
  %cond249 = icmp ne i64 %cv248, 0
  br i1 %cond249, label %bb_rcslotrole38, label %bb_rcslotowner38
bb_rcslotrole38:
  %v250 = load i64, ptr %slot20, align 8
  store i64 %v250, ptr %slot44, align 8
  %v251 = load i64, ptr %slot44, align 8
  %v252 = load i64, ptr %slot41, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v251, i64 %v252) nomerge, !dbg !116
  br label %bb_rcslotdone38
bb_rcslotowner38:
  %v253 = load i64, ptr %slot20, align 8
  store i64 %v253, ptr %slot45, align 8
  %v254 = load i64, ptr %slot45, align 8
  %v255 = load i64, ptr %slot41, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v254, i64 %v255) nomerge, !dbg !116
  br label %bb_rcslotdone38
bb_rcslotdone38:
  %v256 = load i64, ptr %slot15, align 8
  store i64 %v256, ptr %slot46, align 8
  %v257 = load i64, ptr %slot46, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i32 0, ptr %p258, align 4, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot46, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i32 1, ptr %p260, align 4, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot46, align 8
  %v262 = load i64, ptr %slot12, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot12, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot47, align 8
  %v267 = load i64, ptr %slot11, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld269, ptr %slot48, align 8
  %v270 = load i64, ptr %slot48, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i32, ptr %p271, align 4, !alias.scope !3, !noalias !4
  %ext273 = zext i32 %ld272 to i64
  store i64 %ext273, ptr %slot49, align 8
  %v274 = load i64, ptr %slot47, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i32, ptr %p275, align 4, !alias.scope !3, !noalias !4
  %ext277 = zext i32 %ld276 to i64
  store i64 %ext277, ptr %slot50, align 8
  %v278 = load i64, ptr %slot49, align 8
  %v279 = load i64, ptr %slot50, align 8
  %cmp280 = icmp eq i64 %v278, %v279
  %cv281 = zext i1 %cmp280 to i64
  store i64 %cv281, ptr %slot51, align 8
  %v282 = load i64, ptr %slot51, align 8
  %v283 = load i64, ptr %slot11, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot11, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot52, align 8
  %v288 = load i64, ptr %slot52, align 8
  %cond289 = icmp ne i64 %v288, 0
  br i1 %cond289, label %bb_next52, label %bb_i12
bb_next52:
  %v290 = load i64, ptr %slot10, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot53, align 8
  %v293 = load i64, ptr %slot53, align 8
  %v294 = load i64, ptr %slot11, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot12, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 5, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot13, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 0, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot11, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot54, align 8
  %v303 = load i64, ptr %slot12, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot55, align 8
  %v306 = load i64, ptr %slot13, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i64, ptr %p307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld308, ptr %slot56, align 8
  %v309 = load i64, ptr %slot1, align 8
  %v310 = load i64, ptr %slot54, align 8
  %v311 = load i64, ptr %slot55, align 8
  %v312 = load i64, ptr %slot56, align 8
  %call313 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v309, i64 %v310, i64 %v311, i64 %v312) nomerge, !dbg !118
  store i64 %call313, ptr %slot57, align 8
  %v314 = load i64, ptr %slot57, align 8
  %v315 = load i64, ptr %slot11, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 %v314, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot4, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i32, ptr %p318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld319, ptr %slot58, align 8
  %v320 = load i32, ptr %slot58, align 8
  %cv321 = zext i32 %v320 to i64
  %cond322 = icmp ne i64 %cv321, 0
  br i1 %cond322, label %bb_rcslotdrop59, label %bb_rcslotdone59
bb_rcslotdrop59:
  %v323 = load i64, ptr %slot4, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 0, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot8, align 8
  store i64 %v325, ptr %slot59, align 8
  %v326 = load i64, ptr %slot5, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i32, ptr %p327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld328, ptr %slot60, align 8
  %v329 = load i32, ptr %slot60, align 8
  %op330 = and i32 %v329, 28
  store i32 %op330, ptr %slot61, align 8
  %v331 = load i32, ptr %slot61, align 8
  %cv332 = zext i32 %v331 to i64
  %cond333 = icmp ne i64 %cv332, 0
  br i1 %cond333, label %bb_rcslotrole59, label %bb_rcslotowner59
bb_rcslotrole59:
  %v334 = load i64, ptr %slot20, align 8
  store i64 %v334, ptr %slot62, align 8
  %v335 = load i64, ptr %slot62, align 8
  %v336 = load i64, ptr %slot59, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v335, i64 %v336) nomerge, !dbg !118
  br label %bb_rcslotdone59
bb_rcslotowner59:
  %v337 = load i64, ptr %slot20, align 8
  store i64 %v337, ptr %slot63, align 8
  %v338 = load i64, ptr %slot63, align 8
  %v339 = load i64, ptr %slot59, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v338, i64 %v339) nomerge, !dbg !118
  br label %bb_rcslotdone59
bb_rcslotdone59:
  br label %bb_i16
bb_i12:
  %v340 = load i64, ptr %slot10, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld342, ptr %slot64, align 8
  %v343 = load i64, ptr %slot64, align 8
  %v344 = load i64, ptr %slot11, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i64 %v343, ptr %p345, align 8, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot12, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i64 1, ptr %p347, align 8, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot11, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld350, ptr %slot65, align 8
  %v351 = load i64, ptr %slot12, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot66, align 8
  %v354 = load i64, ptr %slot1, align 8
  %v355 = load i64, ptr %slot65, align 8
  %v356 = load i64, ptr %slot66, align 8
  %call357 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v354, i64 %v355, i64 %v356) nomerge, !dbg !120
  store i64 %call357, ptr %slot67, align 8
  %v358 = load i64, ptr %slot67, align 8
  %v359 = load i64, ptr %slot11, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot4, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i32, ptr %p362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld363, ptr %slot68, align 8
  %v364 = load i32, ptr %slot68, align 8
  %cv365 = zext i32 %v364 to i64
  %cond366 = icmp ne i64 %cv365, 0
  br i1 %cond366, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v367 = load i64, ptr %slot4, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i32 0, ptr %p368, align 4, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot8, align 8
  store i64 %v369, ptr %slot69, align 8
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i32, ptr %p371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld372, ptr %slot70, align 8
  %v373 = load i32, ptr %slot70, align 8
  %op374 = and i32 %v373, 28
  store i32 %op374, ptr %slot71, align 8
  %v375 = load i32, ptr %slot71, align 8
  %cv376 = zext i32 %v375 to i64
  %cond377 = icmp ne i64 %cv376, 0
  br i1 %cond377, label %bb_rcslotrole72, label %bb_rcslotowner72
bb_rcslotrole72:
  %v378 = load i64, ptr %slot20, align 8
  store i64 %v378, ptr %slot72, align 8
  %v379 = load i64, ptr %slot72, align 8
  %v380 = load i64, ptr %slot69, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v379, i64 %v380) nomerge, !dbg !120
  br label %bb_rcslotdone72
bb_rcslotowner72:
  %v381 = load i64, ptr %slot20, align 8
  store i64 %v381, ptr %slot73, align 8
  %v382 = load i64, ptr %slot73, align 8
  %v383 = load i64, ptr %slot69, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v382, i64 %v383) nomerge, !dbg !120
  br label %bb_rcslotdone72
bb_rcslotdone72:
  br label %bb_i16
bb_i16:
  %v384 = load i64, ptr %slot10, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot74, align 8
  %v387 = load i64, ptr %slot74, align 8
  %v388 = load i64, ptr %slot11, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot12, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 33, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot11, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot75, align 8
  %v395 = load i64, ptr %slot12, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %ld397 = load i64, ptr %p396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld397, ptr %slot76, align 8
  %v398 = load i64, ptr %slot1, align 8
  %v399 = load i64, ptr %slot75, align 8
  %v400 = load i64, ptr %slot76, align 8
  %call401 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v398, i64 %v399, i64 %v400) nomerge, !dbg !122
  store i64 %call401, ptr %slot77, align 8
  %v402 = load i64, ptr %slot77, align 8
  %v403 = load i64, ptr %slot11, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot4, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i32, ptr %p406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld407, ptr %slot78, align 8
  %v408 = load i32, ptr %slot78, align 8
  %cv409 = zext i32 %v408 to i64
  %cond410 = icmp ne i64 %cv409, 0
  br i1 %cond410, label %bb_rcslotdrop85, label %bb_rcslotdone85
bb_rcslotdrop85:
  %v411 = load i64, ptr %slot4, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 0, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot8, align 8
  store i64 %v413, ptr %slot79, align 8
  %v414 = load i64, ptr %slot5, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i32, ptr %p415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld416, ptr %slot80, align 8
  %v417 = load i32, ptr %slot80, align 8
  %op418 = and i32 %v417, 28
  store i32 %op418, ptr %slot81, align 8
  %v419 = load i32, ptr %slot81, align 8
  %cv420 = zext i32 %v419 to i64
  %cond421 = icmp ne i64 %cv420, 0
  br i1 %cond421, label %bb_rcslotrole85, label %bb_rcslotowner85
bb_rcslotrole85:
  %v422 = load i64, ptr %slot20, align 8
  store i64 %v422, ptr %slot82, align 8
  %v423 = load i64, ptr %slot82, align 8
  %v424 = load i64, ptr %slot79, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v423, i64 %v424) nomerge, !dbg !122
  br label %bb_rcslotdone85
bb_rcslotowner85:
  %v425 = load i64, ptr %slot20, align 8
  store i64 %v425, ptr %slot83, align 8
  %v426 = load i64, ptr %slot83, align 8
  %v427 = load i64, ptr %slot79, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v426, i64 %v427) nomerge, !dbg !122
  br label %bb_rcslotdone85
bb_rcslotdone85:
  %v428 = load i64, ptr %slot11, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 0, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot11, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot84, align 8
  %v433 = load i64, ptr %slot4, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i32, ptr %p434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld435, ptr %slot85, align 8
  %v436 = load i32, ptr %slot85, align 8
  %cv437 = zext i32 %v436 to i64
  %cond438 = icmp ne i64 %cv437, 0
  br i1 %cond438, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v439 = load i64, ptr %slot4, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 0, ptr %p440, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone95
bb_rcslotdone95:
  %v441 = load i64, ptr %slot84, align 8
  ret i64 %v441
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8, i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae", linkageName: "myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9235889751679238090, i64 0, !"myl_f_820de49eeb74e7fdd1dc22e23b35078b0fb003c707501bcef27a47c816bf63ae"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!120 = !DILocation(line: 15, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
