target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v149 = load i64, ptr %slot1, align 8
  %op150 = add i64 %v149, 32
  store i64 %op150, ptr %slot5, align 8
  %mem151 = alloca i8, i64 8, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot6, align 8
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot7, align 8
  %mem155 = alloca i8, i64 8, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot8, align 8
  %mem157 = alloca i8, i64 8, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot9, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot10, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot11, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot12, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot13, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot14, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot15, align 8
  %mem171 = alloca i8, i64 32, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot16, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot17, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot18, align 8
  %v177 = load i64, ptr %slot9, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 0, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot13, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 0, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot2, align 8
  %v182 = load i64, ptr %slot6, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot3, align 8
  %v185 = load i64, ptr %slot7, align 8
  %p186 = inttoptr i64 %v185 to ptr
  store i64 %v184, ptr %p186, align 8, !alias.scope !3, !noalias !4
  %v187 = load i64, ptr %slot4, align 8
  %v188 = load i64, ptr %slot8, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v190 = load i64, ptr %slot6, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot19, align 8
  %v193 = load i64, ptr %slot19, align 8
  %v194 = load i64, ptr %slot17, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot17, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot20, align 8
  %v199 = load i64, ptr %slot9, align 8
  store i64 %v199, ptr %slot21, align 8
  %v200 = load i64, ptr %slot20, align 8
  %v201 = load i64, ptr %slot21, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot9, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot22, align 8
  %v206 = load i64, ptr %slot22, align 8
  %op207 = add i64 %v206, 0
  store i64 %op207, ptr %slot23, align 8
  %v208 = load i64, ptr %slot23, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !6, !noalias !7
  store i64 %ld210, ptr %slot24, align 8
  %v211 = load i64, ptr %slot24, align 8
  %v212 = load i64, ptr %slot17, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot17, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot25, align 8
  %v217 = load i64, ptr %slot25, align 8
  %cmp218 = icmp ugt i64 %v217, 9223372036854775807
  %cv219 = zext i1 %cmp218 to i64
  store i64 %cv219, ptr %slot26, align 8
  %v220 = load i64, ptr %slot26, align 8
  %cond221 = icmp ne i64 %v220, 0
  br i1 %cond221, label %bb_cast_overflow8, label %bb_cast_ok8
bb_cast_overflow8:
  %v222 = load i64, ptr %slot1, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %v224 = load i64, ptr %slot25, align 8
  call void @myl_qbe_fail_cast(ptr %p223, i64 %v224, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok8:
  %v225 = load i64, ptr %slot25, align 8
  %v226 = load i64, ptr %slot17, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 %v225, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot18, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 1, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot18, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot27, align 8
  %v233 = load i64, ptr %slot17, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot28, align 8
  %v236 = load i64, ptr %slot28, align 8
  %v237 = load i64, ptr %slot27, align 8
  %ovpair239 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v236, i64 %v237)
  %op238 = extractvalue { i64, i1 } %ovpair239, 0
  %ov240 = extractvalue { i64, i1 } %ovpair239, 1
  store i64 %op238, ptr %slot29, align 8
  %cv241 = zext i1 %ov240 to i64
  store i64 %cv241, ptr %slot30, align 8
  %v242 = load i64, ptr %slot30, align 8
  %cond243 = icmp ne i64 %v242, 0
  br i1 %cond243, label %bb_overflow11, label %bb_checked11
bb_overflow11:
  %v244 = load i64, ptr %slot1, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %v246 = load i64, ptr %slot28, align 8
  %v247 = load i64, ptr %slot27, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p245, i64 1, i64 %v246, i64 %v247, i64 64) nomerge, !dbg !112
  unreachable
bb_checked11:
  %v248 = load i64, ptr %slot29, align 8
  %v249 = load i64, ptr %slot17, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot17, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot31, align 8
  %v254 = load i64, ptr %slot10, align 8
  store i64 %v254, ptr %slot32, align 8
  %v255 = load i64, ptr %slot31, align 8
  %v256 = load i64, ptr %slot32, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 %v255, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot8, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot33, align 8
  %v261 = load i64, ptr %slot33, align 8
  %v262 = load i64, ptr %slot17, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot10, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot34, align 8
  %v267 = load i64, ptr %slot34, align 8
  %v268 = load i64, ptr %slot18, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot18, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot35, align 8
  %v273 = load i64, ptr %slot35, align 8
  %cmp274 = icmp slt i64 %v273, 0
  %cv275 = zext i1 %cmp274 to i64
  store i64 %cv275, ptr %slot36, align 8
  %v276 = load i64, ptr %slot35, align 8
  %cmp277 = icmp sgt i64 %v276, 4294967295
  %cv278 = zext i1 %cmp277 to i64
  store i64 %cv278, ptr %slot37, align 8
  %v279 = load i64, ptr %slot36, align 8
  %v280 = load i64, ptr %slot37, align 8
  %op281 = or i64 %v279, %v280
  store i64 %op281, ptr %slot38, align 8
  %v282 = load i64, ptr %slot38, align 8
  %cond283 = icmp ne i64 %v282, 0
  br i1 %cond283, label %bb_cast_overflow21, label %bb_cast_ok21
bb_cast_overflow21:
  %v284 = load i64, ptr %slot1, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %v286 = load i64, ptr %slot35, align 8
  call void @myl_qbe_fail_cast(ptr %p285, i64 %v286, i64 32) nomerge, !dbg !114
  unreachable
bb_cast_ok21:
  %v287 = load i64, ptr %slot35, align 8
  %v288 = load i64, ptr %slot18, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 %v287, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot18, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot39, align 8
  %v293 = load i64, ptr %slot17, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot40, align 8
  %v296 = load i64, ptr %slot40, align 8
  %v297 = load i64, ptr %slot39, align 8
  %op298 = and i64 %v296, %v297
  store i64 %op298, ptr %slot41, align 8
  %v299 = load i64, ptr %slot41, align 8
  %op300 = shl i64 %v299, 32
  store i64 %op300, ptr %slot42, align 8
  %v301 = load i64, ptr %slot42, align 8
  %op302 = lshr i64 %v301, 32
  store i64 %op302, ptr %slot43, align 8
  %v303 = load i64, ptr %slot43, align 8
  %v304 = load i64, ptr %slot17, align 8
  %p305 = inttoptr i64 %v304 to ptr
  store i64 %v303, ptr %p305, align 8, !alias.scope !3, !noalias !4
  %v306 = load i64, ptr %slot17, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i64, ptr %p307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld308, ptr %slot44, align 8
  %v309 = load i64, ptr %slot44, align 8
  %v310 = load i64, ptr %slot17, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 %v309, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot17, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot45, align 8
  %v315 = load i64, ptr %slot11, align 8
  store i64 %v315, ptr %slot46, align 8
  %v316 = load i64, ptr %slot45, align 8
  %v317 = load i64, ptr %slot46, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i64 %v316, ptr %p318, align 8, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot17, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 1, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot17, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot47, align 8
  %v324 = load i64, ptr %slot47, align 8
  %neg325 = sub i64 0, %v324
  store i64 %neg325, ptr %slot48, align 8
  %v326 = load i64, ptr %slot47, align 8
  %cmp327 = icmp eq i64 %v326, 9223372036854775808
  %cv328 = zext i1 %cmp327 to i64
  store i64 %cv328, ptr %slot49, align 8
  %v329 = load i64, ptr %slot49, align 8
  %cond330 = icmp ne i64 %v329, 0
  br i1 %cond330, label %bb_neg_overflow31, label %bb_neg_checked31
bb_neg_overflow31:
  %v331 = load i64, ptr %slot1, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %v333 = load i64, ptr %slot47, align 8
  %call334 = call i64 @myl_qbe_int_neg(ptr %p332, i64 1, i64 64, i64 %v333) nomerge, !dbg !116
  unreachable
bb_neg_checked31:
  %v335 = load i64, ptr %slot48, align 8
  %v336 = load i64, ptr %slot17, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 %v335, ptr %p337, align 8, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot17, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot50, align 8
  %v341 = load i64, ptr %slot12, align 8
  store i64 %v341, ptr %slot51, align 8
  %v342 = load i64, ptr %slot50, align 8
  %v343 = load i64, ptr %slot51, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 %v342, ptr %p344, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v345 = load i64, ptr %slot6, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot52, align 8
  %v348 = load i64, ptr %slot52, align 8
  %v349 = load i64, ptr %slot17, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i64 %v348, ptr %p350, align 8, !alias.scope !3, !noalias !4
  %v351 = load i64, ptr %slot17, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot53, align 8
  %v354 = load i64, ptr %slot13, align 8
  store i64 %v354, ptr %slot54, align 8
  %v355 = load i64, ptr %slot53, align 8
  %v356 = load i64, ptr %slot54, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot11, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot55, align 8
  %v361 = load i64, ptr %slot55, align 8
  %v362 = load i64, ptr %slot17, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot17, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot56, align 8
  %v367 = load i64, ptr %slot14, align 8
  store i64 %v367, ptr %slot57, align 8
  %v368 = load i64, ptr %slot56, align 8
  %v369 = load i64, ptr %slot57, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot14, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot58, align 8
  %v374 = load i64, ptr %slot58, align 8
  %v375 = load i64, ptr %slot17, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot18, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 0, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot18, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot59, align 8
  %v382 = load i64, ptr %slot17, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot60, align 8
  %v385 = load i64, ptr %slot60, align 8
  %v386 = load i64, ptr %slot59, align 8
  %cmp387 = icmp slt i64 %v385, %v386
  %cv388 = zext i1 %cmp387 to i64
  store i64 %cv388, ptr %slot61, align 8
  %v389 = load i64, ptr %slot61, align 8
  %v390 = load i64, ptr %slot17, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 %v389, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot17, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot62, align 8
  %v395 = load i64, ptr %slot62, align 8
  %cond396 = icmp ne i64 %v395, 0
  br i1 %cond396, label %bb_next46, label %bb_i29
bb_next46:
  %v397 = load i64, ptr %slot13, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot63, align 8
  %v400 = load i64, ptr %slot63, align 8
  %op401 = add i64 %v400, 0
  store i64 %op401, ptr %slot64, align 8
  %v402 = load i64, ptr %slot64, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !6, !noalias !7
  store i64 %ld404, ptr %slot65, align 8
  %v405 = load i64, ptr %slot65, align 8
  %v406 = load i64, ptr %slot17, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot17, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot66, align 8
  %v411 = load i64, ptr %slot66, align 8
  %cmp412 = icmp ugt i64 %v411, 9223372036854775807
  %cv413 = zext i1 %cmp412 to i64
  store i64 %cv413, ptr %slot67, align 8
  %v414 = load i64, ptr %slot67, align 8
  %cond415 = icmp ne i64 %v414, 0
  br i1 %cond415, label %bb_cast_overflow51, label %bb_cast_ok51
bb_cast_overflow51:
  %v416 = load i64, ptr %slot1, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %v418 = load i64, ptr %slot66, align 8
  call void @myl_qbe_fail_cast(ptr %p417, i64 %v418, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok51:
  %v419 = load i64, ptr %slot66, align 8
  %v420 = load i64, ptr %slot17, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 %v419, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot14, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot68, align 8
  %v425 = load i64, ptr %slot68, align 8
  %v426 = load i64, ptr %slot18, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i64 %v425, ptr %p427, align 8, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot18, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %ld430 = load i64, ptr %p429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld430, ptr %slot69, align 8
  %v431 = load i64, ptr %slot17, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i64, ptr %p432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld433, ptr %slot70, align 8
  %v434 = load i64, ptr %slot70, align 8
  %v435 = load i64, ptr %slot69, align 8
  %ovpair437 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v434, i64 %v435)
  %op436 = extractvalue { i64, i1 } %ovpair437, 0
  %ov438 = extractvalue { i64, i1 } %ovpair437, 1
  store i64 %op436, ptr %slot71, align 8
  %v439 = load i64, ptr %slot70, align 8
  %v440 = load i64, ptr %slot71, align 8
  %op441 = xor i64 %v439, %v440
  store i64 %op441, ptr %slot72, align 8
  %v442 = load i64, ptr %slot69, align 8
  %v443 = load i64, ptr %slot71, align 8
  %op444 = xor i64 %v442, %v443
  store i64 %op444, ptr %slot73, align 8
  %v445 = load i64, ptr %slot72, align 8
  %v446 = load i64, ptr %slot73, align 8
  %op447 = and i64 %v445, %v446
  store i64 %op447, ptr %slot74, align 8
  %cv448 = zext i1 %ov438 to i64
  store i64 %cv448, ptr %slot75, align 8
  %v449 = load i64, ptr %slot75, align 8
  %cond450 = icmp ne i64 %v449, 0
  br i1 %cond450, label %bb_overflow55, label %bb_checked55
bb_overflow55:
  %v451 = load i64, ptr %slot1, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %v453 = load i64, ptr %slot70, align 8
  %v454 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p452, i64 0, i64 %v453, i64 %v454, i64 64) nomerge, !dbg !120
  unreachable
bb_checked55:
  %v455 = load i64, ptr %slot71, align 8
  %v456 = load i64, ptr %slot17, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 %v455, ptr %p457, align 8, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot17, align 8
  %p459 = inttoptr i64 %v458 to ptr
  %ld460 = load i64, ptr %p459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld460, ptr %slot76, align 8
  %v461 = load i64, ptr %slot14, align 8
  store i64 %v461, ptr %slot77, align 8
  %v462 = load i64, ptr %slot76, align 8
  %v463 = load i64, ptr %slot77, align 8
  %p464 = inttoptr i64 %v463 to ptr
  store i64 %v462, ptr %p464, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i29:
  %v465 = load i64, ptr %slot14, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %ld467 = load i64, ptr %p466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld467, ptr %slot78, align 8
  %v468 = load i64, ptr %slot78, align 8
  %v469 = load i64, ptr %slot17, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i64 %v468, ptr %p470, align 8, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot13, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot79, align 8
  %v474 = load i64, ptr %slot17, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot80, align 8
  %v477 = load i64, ptr %slot79, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i64, ptr %p478, align 8, !alias.scope !6, !noalias !7
  store i64 %ld479, ptr %slot81, align 8
  %v480 = load i64, ptr %slot80, align 8
  %v481 = load i64, ptr %slot81, align 8
  %cmp482 = icmp ult i64 %v480, %v481
  %cv483 = zext i1 %cmp482 to i64
  store i64 %cv483, ptr %slot82, align 8
  %v484 = load i64, ptr %slot82, align 8
  %cond485 = icmp ne i64 %v484, 0
  br i1 %cond485, label %bb_success68, label %bb_failed68
bb_failed68:
  %v486 = load i64, ptr %slot1, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %v488 = load i64, ptr %slot80, align 8
  %v489 = load i64, ptr %slot81, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p487, i64 %v488, i64 %v489) nomerge, !dbg !122
  unreachable
bb_success68:
  %v490 = load i64, ptr %slot79, align 8
  %op491 = add i64 %v490, 32
  store i64 %op491, ptr %slot83, align 8
  %v492 = load i64, ptr %slot83, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !6, !noalias !7
  store i64 %ld494, ptr %slot84, align 8
  %v495 = load i64, ptr %slot80, align 8
  %op496 = mul i64 %v495, 32
  store i64 %op496, ptr %slot85, align 8
  %v497 = load i64, ptr %slot84, align 8
  %v498 = load i64, ptr %slot85, align 8
  %op499 = add i64 %v497, %v498
  store i64 %op499, ptr %slot86, align 8
  %v500 = load i64, ptr %slot86, align 8
  %v501 = load i64, ptr %slot17, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i64 %v500, ptr %p502, align 8, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot17, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %ld505 = load i64, ptr %p504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld505, ptr %slot87, align 8
  %v506 = load i64, ptr %slot87, align 8
  %v507 = load i64, ptr %slot15, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i64 %v506, ptr %p508, align 8, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot15, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %ld511 = load i64, ptr %p510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld511, ptr %slot88, align 8
  %v512 = load i64, ptr %slot88, align 8
  %v513 = load i64, ptr %slot17, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i64 %v512, ptr %p514, align 8, !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot17, align 8
  %p516 = inttoptr i64 %v515 to ptr
  %ld517 = load i64, ptr %p516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld517, ptr %slot89, align 8
  %v518 = load i64, ptr %slot89, align 8
  %op519 = add i64 %v518, 0
  store i64 %op519, ptr %slot90, align 8
  %v520 = load i64, ptr %slot90, align 8
  %p521 = inttoptr i64 %v520 to ptr
  %ld522 = load i64, ptr %p521, align 8, !alias.scope !12, !noalias !13
  store i64 %ld522, ptr %slot91, align 8
  %v523 = load i64, ptr %slot91, align 8
  %v524 = load i64, ptr %slot17, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot18, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 18446744073709551615, ptr %p527, align 8, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot18, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot92, align 8
  %v531 = load i64, ptr %slot17, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot93, align 8
  %v534 = load i64, ptr %slot93, align 8
  %v535 = load i64, ptr %slot92, align 8
  %cmp536 = icmp eq i64 %v534, %v535
  %cv537 = zext i1 %cmp536 to i64
  store i64 %cv537, ptr %slot94, align 8
  %v538 = load i64, ptr %slot94, align 8
  %v539 = load i64, ptr %slot17, align 8
  %p540 = inttoptr i64 %v539 to ptr
  store i64 %v538, ptr %p540, align 8, !alias.scope !3, !noalias !4
  %v541 = load i64, ptr %slot17, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot95, align 8
  %v544 = load i64, ptr %slot95, align 8
  %cond545 = icmp ne i64 %v544, 0
  br i1 %cond545, label %bb_next82, label %bb_i67
bb_next82:
  %v546 = load i64, ptr %slot15, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot96, align 8
  %v549 = load i64, ptr %slot96, align 8
  %v550 = load i64, ptr %slot17, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i64 %v549, ptr %p551, align 8, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot17, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i64, ptr %p553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld554, ptr %slot97, align 8
  %v555 = load i64, ptr %slot16, align 8
  store i64 %v555, ptr %slot98, align 8
  %v556 = load i64, ptr %slot97, align 8
  %v557 = load i64, ptr %slot98, align 8
  %p558 = inttoptr i64 %v556 to ptr
  %p559 = inttoptr i64 %v557 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p559, ptr %p558, i64 32, i1 false), !alias.scope !10000000
  %v560 = load i64, ptr %slot16, align 8
  %v561 = load i64, ptr %slot17, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 %v560, ptr %p562, align 8, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot17, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot99, align 8
  %v566 = load i64, ptr %slot99, align 8
  %op567 = add i64 %v566, 16
  store i64 %op567, ptr %slot100, align 8
  %v568 = load i64, ptr %slot100, align 8
  %v569 = load i64, ptr %slot17, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 %v568, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot17, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot101, align 8
  %v574 = load i64, ptr %slot101, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i32, ptr %p575, align 4, !alias.scope !3, !noalias !4
  %ext577 = zext i32 %ld576 to i64
  store i64 %ext577, ptr %slot102, align 8
  %v578 = load i64, ptr %slot102, align 8
  %cmp579 = icmp eq i64 %v578, 0
  %cv580 = zext i1 %cmp579 to i64
  store i64 %cv580, ptr %slot103, align 8
  %v581 = load i64, ptr %slot103, align 8
  %cond582 = icmp ne i64 %v581, 0
  br i1 %cond582, label %bb_arm89, label %bb_armnext89
bb_arm89:
  br label %bb_i42
bb_armnext89:
  %v583 = load i64, ptr %slot102, align 8
  %cmp584 = icmp eq i64 %v583, 1
  %cv585 = zext i1 %cmp584 to i64
  store i64 %cv585, ptr %slot104, align 8
  %v586 = load i64, ptr %slot104, align 8
  %cond587 = icmp ne i64 %v586, 0
  br i1 %cond587, label %bb_arm90, label %bb_armnext90
bb_arm90:
  br label %bb_i44
bb_armnext90:
  %v588 = load i64, ptr %slot102, align 8
  %cmp589 = icmp eq i64 %v588, 2
  %cv590 = zext i1 %cmp589 to i64
  store i64 %cv590, ptr %slot105, align 8
  %v591 = load i64, ptr %slot105, align 8
  %cond592 = icmp ne i64 %v591, 0
  br i1 %cond592, label %bb_arm91, label %bb_armnext91
bb_arm91:
  br label %bb_i46
bb_armnext91:
  %v593 = load i64, ptr %slot102, align 8
  %cmp594 = icmp eq i64 %v593, 3
  %cv595 = zext i1 %cmp594 to i64
  store i64 %cv595, ptr %slot106, align 8
  %v596 = load i64, ptr %slot106, align 8
  %cond597 = icmp ne i64 %v596, 0
  br i1 %cond597, label %bb_arm92, label %bb_armnext92
bb_arm92:
  br label %bb_i48
bb_armnext92:
  br label %bb_failure
bb_i42:
  %v598 = load i64, ptr %slot17, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 0, ptr %p599, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i44:
  %v600 = load i64, ptr %slot17, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 1, ptr %p601, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i46:
  %v602 = load i64, ptr %slot17, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i64 1, ptr %p603, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i48:
  %v604 = load i64, ptr %slot17, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i64 1, ptr %p605, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i50:
  %v606 = load i64, ptr %slot17, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %ld608 = load i64, ptr %p607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld608, ptr %slot107, align 8
  %v609 = load i64, ptr %slot107, align 8
  %op610 = xor i64 %v609, 1
  store i64 %op610, ptr %slot108, align 8
  %v611 = load i64, ptr %slot108, align 8
  %v612 = load i64, ptr %slot17, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i64 %v611, ptr %p613, align 8, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot17, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i64, ptr %p615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld616, ptr %slot109, align 8
  %v617 = load i64, ptr %slot109, align 8
  %cond618 = icmp ne i64 %v617, 0
  br i1 %cond618, label %bb_next96, label %bb_i60
bb_next96:
  %v619 = load i64, ptr %slot12, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld621, ptr %slot110, align 8
  %v622 = load i64, ptr %slot110, align 8
  %v623 = load i64, ptr %slot17, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i64 %v622, ptr %p624, align 8, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot18, align 8
  %p626 = inttoptr i64 %v625 to ptr
  store i64 18446744073709551615, ptr %p626, align 8, !alias.scope !3, !noalias !4
  %v627 = load i64, ptr %slot18, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %ld629 = load i64, ptr %p628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld629, ptr %slot111, align 8
  %v630 = load i64, ptr %slot17, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot112, align 8
  %v633 = load i64, ptr %slot112, align 8
  %v634 = load i64, ptr %slot111, align 8
  %cmp635 = icmp ne i64 %v633, %v634
  %cv636 = zext i1 %cmp635 to i64
  store i64 %cv636, ptr %slot113, align 8
  %v637 = load i64, ptr %slot113, align 8
  %v638 = load i64, ptr %slot17, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i64 %v637, ptr %p639, align 8, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot17, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot114, align 8
  %v643 = load i64, ptr %slot114, align 8
  %cond644 = icmp ne i64 %v643, 0
  br i1 %cond644, label %bb_next101, label %bb_i58
bb_next101:
  %v645 = load i64, ptr %slot12, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i64, ptr %p646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld647, ptr %slot115, align 8
  %v648 = load i64, ptr %slot115, align 8
  %v649 = load i64, ptr %slot17, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 %v648, ptr %p650, align 8, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot17, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot116, align 8
  %v654 = load i64, ptr %slot116, align 8
  ret i64 %v654
bb_i58:
  %v655 = load i64, ptr %slot11, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld657, ptr %slot117, align 8
  %v658 = load i64, ptr %slot117, align 8
  %v659 = load i64, ptr %slot17, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i64 %v658, ptr %p660, align 8, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot17, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i64, ptr %p662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld663, ptr %slot118, align 8
  %v664 = load i64, ptr %slot118, align 8
  ret i64 %v664
bb_i60:
  %v665 = load i64, ptr %slot12, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %ld667 = load i64, ptr %p666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld667, ptr %slot119, align 8
  %v668 = load i64, ptr %slot119, align 8
  %v669 = load i64, ptr %slot17, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i64 %v668, ptr %p670, align 8, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot18, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i64 18446744073709551615, ptr %p672, align 8, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot18, align 8
  %p674 = inttoptr i64 %v673 to ptr
  %ld675 = load i64, ptr %p674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld675, ptr %slot120, align 8
  %v676 = load i64, ptr %slot17, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot121, align 8
  %v679 = load i64, ptr %slot121, align 8
  %v680 = load i64, ptr %slot120, align 8
  %cmp681 = icmp eq i64 %v679, %v680
  %cv682 = zext i1 %cmp681 to i64
  store i64 %cv682, ptr %slot122, align 8
  %v683 = load i64, ptr %slot122, align 8
  %v684 = load i64, ptr %slot17, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i64 %v683, ptr %p685, align 8, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot17, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i64, ptr %p687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld688, ptr %slot123, align 8
  %v689 = load i64, ptr %slot123, align 8
  %cond690 = icmp ne i64 %v689, 0
  br i1 %cond690, label %bb_next110, label %bb_i66
bb_next110:
  %v691 = load i64, ptr %slot11, align 8
  %p692 = inttoptr i64 %v691 to ptr
  %ld693 = load i64, ptr %p692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld693, ptr %slot124, align 8
  %v694 = load i64, ptr %slot124, align 8
  %v695 = load i64, ptr %slot17, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 %v694, ptr %p696, align 8, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot17, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot125, align 8
  %v700 = load i64, ptr %slot12, align 8
  store i64 %v700, ptr %slot126, align 8
  %v701 = load i64, ptr %slot125, align 8
  %v702 = load i64, ptr %slot126, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i64 %v701, ptr %p703, align 8, !alias.scope !3, !noalias !4
  br label %bb_i66
bb_i66:
  br label %bb_i74
bb_i67:
  %v704 = load i64, ptr %slot15, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %ld706 = load i64, ptr %p705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld706, ptr %slot127, align 8
  %v707 = load i64, ptr %slot127, align 8
  %v708 = load i64, ptr %slot17, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i64 %v707, ptr %p709, align 8, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot17, align 8
  %p711 = inttoptr i64 %v710 to ptr
  %ld712 = load i64, ptr %p711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld712, ptr %slot128, align 8
  %v713 = load i64, ptr %slot128, align 8
  %op714 = add i64 %v713, 0
  store i64 %op714, ptr %slot129, align 8
  %v715 = load i64, ptr %slot129, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i64, ptr %p716, align 8, !alias.scope !12, !noalias !13
  store i64 %ld717, ptr %slot130, align 8
  %v718 = load i64, ptr %slot130, align 8
  %v719 = load i64, ptr %slot17, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i64 %v718, ptr %p720, align 8, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot7, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i64, ptr %p722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld723, ptr %slot131, align 8
  %v724 = load i64, ptr %slot131, align 8
  %v725 = load i64, ptr %slot18, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i64 %v724, ptr %p726, align 8, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot18, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot132, align 8
  %v730 = load i64, ptr %slot17, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot133, align 8
  %v733 = load i64, ptr %slot133, align 8
  %v734 = load i64, ptr %slot132, align 8
  %cmp735 = icmp eq i64 %v733, %v734
  %cv736 = zext i1 %cmp735 to i64
  store i64 %cv736, ptr %slot134, align 8
  %v737 = load i64, ptr %slot134, align 8
  %v738 = load i64, ptr %slot17, align 8
  %p739 = inttoptr i64 %v738 to ptr
  store i64 %v737, ptr %p739, align 8, !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot17, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %ld742 = load i64, ptr %p741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld742, ptr %slot135, align 8
  %v743 = load i64, ptr %slot135, align 8
  %cond744 = icmp ne i64 %v743, 0
  br i1 %cond744, label %bb_next122, label %bb_i74
bb_next122:
  %v745 = load i64, ptr %slot11, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld747, ptr %slot136, align 8
  %v748 = load i64, ptr %slot136, align 8
  %v749 = load i64, ptr %slot17, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 %v748, ptr %p750, align 8, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot17, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i64, ptr %p752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld753, ptr %slot137, align 8
  %v754 = load i64, ptr %slot137, align 8
  ret i64 %v754
bb_i74:
  %v755 = load i64, ptr %slot11, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %ld757 = load i64, ptr %p756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld757, ptr %slot138, align 8
  %v758 = load i64, ptr %slot138, align 8
  %v759 = load i64, ptr %slot17, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i64 %v758, ptr %p760, align 8, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot18, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i64 1, ptr %p762, align 8, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot18, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld765, ptr %slot139, align 8
  %v766 = load i64, ptr %slot17, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %ld768 = load i64, ptr %p767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld768, ptr %slot140, align 8
  %v769 = load i64, ptr %slot140, align 8
  %v770 = load i64, ptr %slot139, align 8
  %ovpair772 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v769, i64 %v770)
  %op771 = extractvalue { i64, i1 } %ovpair772, 0
  %ov773 = extractvalue { i64, i1 } %ovpair772, 1
  store i64 %op771, ptr %slot141, align 8
  %cv774 = zext i1 %ov773 to i64
  store i64 %cv774, ptr %slot142, align 8
  %v775 = load i64, ptr %slot142, align 8
  %cond776 = icmp ne i64 %v775, 0
  br i1 %cond776, label %bb_overflow127, label %bb_checked127
bb_overflow127:
  %v777 = load i64, ptr %slot1, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %v779 = load i64, ptr %slot140, align 8
  %v780 = load i64, ptr %slot139, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p778, i64 0, i64 %v779, i64 %v780, i64 64) nomerge, !dbg !124
  unreachable
bb_checked127:
  %v781 = load i64, ptr %slot141, align 8
  %v782 = load i64, ptr %slot17, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i64 %v781, ptr %p783, align 8, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot10, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %ld786 = load i64, ptr %p785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld786, ptr %slot143, align 8
  %v787 = load i64, ptr %slot143, align 8
  %v788 = load i64, ptr %slot18, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i64 %v787, ptr %p789, align 8, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot18, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i64, ptr %p791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld792, ptr %slot144, align 8
  %v793 = load i64, ptr %slot17, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i64, ptr %p794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld795, ptr %slot145, align 8
  %v796 = load i64, ptr %slot145, align 8
  %v797 = load i64, ptr %slot144, align 8
  %op798 = and i64 %v796, %v797
  store i64 %op798, ptr %slot146, align 8
  %v799 = load i64, ptr %slot146, align 8
  %v800 = load i64, ptr %slot17, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i64 %v799, ptr %p801, align 8, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot17, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i64, ptr %p803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld804, ptr %slot147, align 8
  %v805 = load i64, ptr %slot11, align 8
  store i64 %v805, ptr %slot148, align 8
  %v806 = load i64, ptr %slot147, align 8
  %v807 = load i64, ptr %slot148, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i64 %v806, ptr %p808, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 32v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d", linkageName: "myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9048138935081588047, i64 0, !"myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!110 = !DILocation(line: 4, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!112 = !DILocation(line: 6, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!114 = !DILocation(line: 10, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!116 = !DILocation(line: 15, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!118 = !DILocation(line: 26, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!120 = !DILocation(line: 28, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!122 = !DILocation(line: 31, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!124 = !DILocation(line: 77, column: 0, scope: !125)
