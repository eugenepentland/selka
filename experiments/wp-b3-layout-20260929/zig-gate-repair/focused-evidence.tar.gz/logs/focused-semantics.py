import json, pathlib, subprocess, time
root = pathlib.Path(__file__).resolve().parents[1]
cases = {
    'glue-final': 'RC-GLUE-1',
    'scope-il': 'RC-SCOPE-IL-1',
    'carry': 'RC-COUNT-CARRY-1',
    'native-contract': 'RC contract layout',
    'native-hold': 'RC held edges',
    'native-stats': 'RC counting separates',
    'native-fast': 'RC runtime fast paths',
}
results = {}
for name, substring in cases.items():
    command = ['zig', 'build', 'test-units', '-Dtest-filter=' + substring, '--summary', 'all']
    start = time.monotonic()
    with (root / '.tmp' / (name + '.log')).open('wb') as output:
        run = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    results[name] = {'command': command, 'status': run.returncode, 'seconds': time.monotonic() - start}
    print(name, run.returncode, flush=True)
    if run.returncode:
        break
(root / '.tmp/focused-semantics.json').write_text(json.dumps(results, indent=2) + '\n')
if any(value['status'] for value in results.values()):
    raise SystemExit(1)
