from pathlib import Path
import json,subprocess,hashlib,os,re
w=Path(__file__).resolve().parent.parent;d=w/'.tmp/pin-proof';d.mkdir(exist_ok=True);c=w/'.tmp/compiler/bin/mylang';s=(w/'src/rc_pin_summary_test.zig').read_text();parts=re.split(r'test "([^"\n]+)" \{',s);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_')};env.update(TMPDIR=str(w/'.tmp'),ZIG_LOCAL_CACHE_DIR=str(w/'.zig-local-cache'),ZIG_GLOBAL_CACHE_DIR=str(w/'.zig-global-cache'));receipt={'compiler':str(c),'compiler_sha256':h(c),'source_tip':'5535e5a3f0b67e23d0fc9f92f594d7b3feb12a3f','rows':[]}
expected = [2, 2, 2, 3, 7, 1, 2, 2, 2, 2, 3, 3, 2]
for i in range(1,len(parts),2):
 name,block=parts[i],parts[i+1];lines=[x.strip()[2:] for x in block.splitlines() if x.strip().startswith('\\\\')];assert lines;src=d/(str((i-1)//2)+'.my');src.write_text('\n'.join(lines)+'\n');arms=[]
 for mode in ['--gc-runtime','--rc-runtime','--rc-runtime=stats']:
  cmd=[str(c),'run',str(src),'--print-result',mode,'--cache-dir='+str(d/'cache')];p=subprocess.run(cmd,env=env,cwd=w,capture_output=True);arms.append({'command':cmd,'status':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==expected[(i-1)//2] and p.stdout.decode().strip()==str(expected[(i-1)//2]) and b'usage:' not in p.stderr,(name,arms[-1])
 assert len({(a['status'],a['stdout']) for a in arms})==1,(name,arms)
 receipt['rows'].append({'name':name,'source':src.name,'source_sha256':h(src),'arms':arms});(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,arms[-1]['status'],arms[-1]['stdout'].strip(),flush=True)
assert h(c)==receipt['compiler_sha256']
for mode in ['--rc-runtime','--rc-runtime=stats','--gc-runtime','--release']:
 cmd=[str(c),'test',str(w/'tests/lang/rc_scope_inline.my'),mode,'--cache-dir',str(d/'scope-cache'),'--force'];p=subprocess.run(cmd,env=env,cwd=w,capture_output=True);assert p.returncode==0,p.stderr.decode();receipt.setdefault('nested_scope_guests',[]).append({'command':cmd,'status':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('semantic pins',len(receipt['rows'])*3,'nested_scope_modes',len(receipt['nested_scope_guests']),flush=True)
