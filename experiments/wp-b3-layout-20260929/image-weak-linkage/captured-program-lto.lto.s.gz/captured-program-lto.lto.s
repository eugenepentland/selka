	.file	"ld-temp.o"
	.section	.text.myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop,"ax",@progbits
	.p2align	4                               # -- Begin function myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	.type	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop,@function
myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop: # @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
.Lfunc_begin0:
	.cfi_startproc
# %bb.0:
	movq	(%rsi), %rax
	movq	$0, (%rsi)
	testq	%rax, %rax
	je	.LBB0_5
# %bb.1:
	movabsq	$4611686018427387906, %rcx      # imm = 0x4000000000000002
	testq	%rcx, -16(%rax)
	je	.LBB0_2
.LBB0_5:
	movq	$0, (%rsi)
	retq
.LBB0_2:
	movl	-24(%rax), %ecx
	cmpl	$1, %ecx
	jne	.LBB0_4
# %bb.3:
	cmpl	$0, -20(%rax)
	je	.LBB0_6
.LBB0_4:
	decl	%ecx
	movl	%ecx, -24(%rax)
	movq	$0, (%rsi)
	retq
.LBB0_6:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rax, %rsi
	callq	myl_rc_edge_release
	movq	$0, (%r14)
	movq	%rbx, %rdi
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_drain                    # TAILCALL
.Lfunc_end0:
	.size	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop, .Lfunc_end0-myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function main
.LCPI1_0:
	.quad	1                               # 0x1
	.zero	8
	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:                                   # @main
.Lfunc_begin1:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$14200, %rsp                    # imm = 0x3778
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, -160(%rbp)                # 8-byte Spill
	movl	%edi, -148(%rbp)                # 4-byte Spill
	movb	$1, exit_without_sweep(%rip)
	leaq	-14224(%rbp), %r14
	movl	$10656, %edx                    # imm = 0x29A0
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movl	$384, %eax                      # imm = 0x180
	.p2align	4
.LBB1_1:                                # =>This Inner Loop Header: Depth=1
	movl	$-1, -14504(%rbp,%rax)
	movl	$-1, -14464(%rbp,%rax)
	movl	$-1, -14424(%rbp,%rax)
	movl	$-1, -14384(%rbp,%rax)
	movl	$-1, -14344(%rbp,%rax)
	movl	$-1, -14304(%rbp,%rax)
	movl	$-1, -14264(%rbp,%rax)
	movl	$-1, -14224(%rbp,%rax)
	addq	$320, %rax                      # imm = 0x140
	cmpq	$10624, %rax                    # imm = 0x2980
	jne	.LBB1_1
# %bb.2:
	movq	$.L.str.172, -3584(%rbp)
	movl	$.L.str.2.173, %edi
	callq	getenv@PLT
	testq	%rax, %rax
	je	.LBB1_32
# %bb.3:
	movq	%rax, %r15
	cmpb	$0, (%rax)
	je	.LBB1_32
# %bb.4:
	movq	%r15, %rdi
	callq	strlen@PLT
	movq	%rax, %rbx
	leaq	1(%rax), %r12
	movq	%r12, %rdi
	callq	malloc@PLT
	movq	%rax, %r14
	shrq	%rbx
	incq	%rbx
	movl	$8, %esi
	movq	%rbx, %rdi
	callq	calloc@PLT
	movq	%r14, %rdi
	movq	%rax, %r14
	testq	%rdi, %rdi
	movq	%rdi, -144(%rbp)                # 8-byte Spill
	je	.LBB1_468
# %bb.5:
	testq	%r14, %r14
	je	.LBB1_468
# %bb.6:
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	memcpy@PLT
	movq	-144(%rbp), %rdi                # 8-byte Reload
	movzbl	(%rdi), %esi
	movb	$1, %bl
	movq	$-1, -48(%rbp)                  # 8-byte Folded Spill
	testb	%sil, %sil
	je	.LBB1_142
# %bb.7:
	xorl	%r9d, %r9d
	movabsq	$4294977024, %rax               # imm = 0x100002600
	movq	%rdi, %rcx
.LBB1_8:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_9 Depth 2
                                        #     Child Loop BB1_15 Depth 2
	movq	%rdi, %rdx
	cmpb	$32, %sil
	ja	.LBB1_12
	.p2align	4
.LBB1_9:                                #   Parent Loop BB1_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movzbl	%sil, %esi
	btq	%rsi, %rax
	jae	.LBB1_11
# %bb.10:                               #   in Loop: Header=BB1_9 Depth=2
	movzbl	1(%rdx), %esi
	incq	%rdx
	cmpb	$32, %sil
	jbe	.LBB1_9
	jmp	.LBB1_12
	.p2align	4
.LBB1_11:                               #   in Loop: Header=BB1_8 Depth=1
	testq	%rsi, %rsi
	je	.LBB1_29
.LBB1_12:                               #   in Loop: Header=BB1_8 Depth=1
	movq	%rcx, (%r14,%r9,8)
	movzbl	(%rdx), %edi
	testb	%dil, %dil
	je	.LBB1_26
# %bb.13:                               #   in Loop: Header=BB1_8 Depth=1
	xorl	%esi, %esi
	jmp	.LBB1_15
	.p2align	4
.LBB1_14:                               #   in Loop: Header=BB1_15 Depth=2
	xorl	$1, %esi
	movzbl	1(%rdx), %edi
	incq	%rdx
	testb	%dil, %dil
	je	.LBB1_25
.LBB1_15:                               #   Parent Loop BB1_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movzbl	%dil, %r8d
	testl	%esi, %esi
	je	.LBB1_18
# %bb.16:                               #   in Loop: Header=BB1_15 Depth=2
	cmpb	$92, %dil
	je	.LBB1_21
# %bb.17:                               #   in Loop: Header=BB1_15 Depth=2
	cmpl	$34, %r8d
	je	.LBB1_14
	jmp	.LBB1_24
	.p2align	4
.LBB1_18:                               #   in Loop: Header=BB1_15 Depth=2
	cmpb	$34, %dil
	ja	.LBB1_24
# %bb.19:                               #   in Loop: Header=BB1_15 Depth=2
	cmpq	$34, %r8
	je	.LBB1_14
# %bb.20:                               #   in Loop: Header=BB1_15 Depth=2
	btq	%r8, %rax
	jae	.LBB1_24
	jmp	.LBB1_27
	.p2align	4
.LBB1_21:                               #   in Loop: Header=BB1_15 Depth=2
	cmpb	$0, 1(%rdx)
	je	.LBB1_23
# %bb.22:                               #   in Loop: Header=BB1_15 Depth=2
	incq	%rdx
.LBB1_23:                               #   in Loop: Header=BB1_15 Depth=2
	movzbl	(%rdx), %edi
.LBB1_24:                               #   in Loop: Header=BB1_15 Depth=2
	movb	%dil, (%rcx)
	incq	%rcx
	movzbl	1(%rdx), %edi
	incq	%rdx
	testb	%dil, %dil
	jne	.LBB1_15
.LBB1_25:                               #   in Loop: Header=BB1_8 Depth=1
	testl	%esi, %esi
	jne	.LBB1_501
.LBB1_26:                               #   in Loop: Header=BB1_8 Depth=1
	xorl	%esi, %esi
	jmp	.LBB1_28
.LBB1_27:                               #   in Loop: Header=BB1_8 Depth=1
	movl	$1, %esi
.LBB1_28:                               #   in Loop: Header=BB1_8 Depth=1
	incq	%r9
	leaq	(%rdx,%rsi), %rdi
	movb	$0, (%rcx)
	incq	%rcx
	movzbl	(%rdx,%rsi), %esi
	testb	%sil, %sil
	jne	.LBB1_8
.LBB1_29:
	testl	%r9d, %r9d
	js	.LBB1_501
# %bb.30:
	je	.LBB1_142
# %bb.31:
	movq	%r9, %rbx
	andl	$2147483647, %ebx               # imm = 0x7FFFFFFF
	xorl	%r12d, %r12d
	xorl	%edi, %edi
	xorl	%esi, %esi
	movl	$0, -68(%rbp)                   # 4-byte Folded Spill
	movl	$0, -100(%rbp)                  # 4-byte Folded Spill
	movl	$0, -116(%rbp)                  # 4-byte Folded Spill
	movl	$0, -84(%rbp)                   # 4-byte Folded Spill
	movl	$0, -120(%rbp)                  # 4-byte Folded Spill
	xorl	%r13d, %r13d
	xorl	%ecx, %ecx
	movq	%r14, -136(%rbp)                # 8-byte Spill
	movq	%rbx, -128(%rbp)                # 8-byte Spill
	jmp	.LBB1_42
.LBB1_32:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -200(%rbp)
	vmovdqu	%ymm0, -224(%rbp)
	vmovdqu	%ymm0, -256(%rbp)
	vmovdqu	%ymm0, -288(%rbp)
	vmovdqu	%ymm0, -320(%rbp)
	vmovdqu	%ymm0, -352(%rbp)
	vmovdqu	%ymm0, -384(%rbp)
	movq	$-1, -64(%rbp)                  # 8-byte Folded Spill
	xorl	%eax, %eax
	movb	$1, -68(%rbp)                   # 1-byte Folded Spill
	xorl	%r13d, %r13d
	movl	$0, -84(%rbp)                   # 4-byte Folded Spill
	movq	$-1, -48(%rbp)                  # 8-byte Folded Spill
	xorl	%r12d, %r12d
	movq	%rax, -144(%rbp)                # 8-byte Spill
	movq	-14128(%rbp), %rbx
	cmpq	$7, %rbx
	ja	.LBB1_498
.LBB1_33:
	movl	$.L.str.192, %edi
	movl	$589824, %esi                   # imm = 0x90000
	xorl	%eax, %eax
	vzeroupper
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB1_498
# %bb.34:
	leaq	1(%rbx), %rcx
	movq	%rcx, -14128(%rbp)
	leaq	(%rbx,%rbx,2), %rcx
	movl	%eax, -14224(%rbp,%rcx,4)
	movabsq	$4294967297, %rax               # imm = 0x100000001
	movq	%rax, -14220(%rbp,%rcx,4)
	cmpl	$0, -3596(%rbp)
	sete	%al
	je	.LBB1_154
.LBB1_35:
	movq	-3616(%rbp), %rdx
	movl	$5, %ecx
	testq	%rdx, %rdx
	je	.LBB1_155
# %bb.36:
	leaq	-3736(%rbp), %rsi
	.p2align	4
.LBB1_37:                               # =>This Inner Loop Header: Depth=1
	cmpl	$0, (%rsi)
	jne	.LBB1_154
# %bb.38:                               #   in Loop: Header=BB1_37 Depth=1
	addq	$16, %rsi
	decq	%rdx
	jne	.LBB1_37
	jmp	.LBB1_155
.LBB1_39:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3596(%rbp)
	.p2align	4
.LBB1_40:                               #   in Loop: Header=BB1_42 Depth=1
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB1_41:                               #   in Loop: Header=BB1_42 Depth=1
	incq	%rcx
	cmpq	%rbx, %rcx
	je	.LBB1_143
.LBB1_42:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_66 Depth 2
                                        #     Child Loop BB1_59 Depth 2
                                        #     Child Loop BB1_108 Depth 2
                                        #     Child Loop BB1_99 Depth 2
                                        #     Child Loop BB1_90 Depth 2
	movq	%rdi, -64(%rbp)                 # 8-byte Spill
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movq	(%r14,%rcx,8), %r15
	movl	$.L.str.7, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB1_53
# %bb.43:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.8, %esi
	movl	$13, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_54
# %bb.44:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.9, %esi
	movl	$14, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_61
# %bb.45:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.10, %esi
	movl	$17, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_69
# %bb.46:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.11, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB1_72
# %bb.47:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.12, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB1_76
# %bb.48:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.13, %esi
	movl	$14, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_117
.LBB1_49:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.14.176, %esi
	movl	$11, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_122
.LBB1_50:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.15.177, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB1_127
# %bb.51:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.18, %esi
	movl	$8, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_77
# %bb.52:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.7, %esi
	movl	$10, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	setne	%cl
	movl	%ecx, %eax
	jmp	.LBB1_79
	.p2align	4
.LBB1_53:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3596(%rbp)
	jne	.LBB1_77
	jmp	.LBB1_39
	.p2align	4
.LBB1_54:                               #   in Loop: Header=BB1_42 Depth=1
	cmpb	$0, 13(%r15)
	je	.LBB1_77
# %bb.55:                               #   in Loop: Header=BB1_42 Depth=1
	movq	%r13, -112(%rbp)                # 8-byte Spill
	movq	%r12, -96(%rbp)                 # 8-byte Spill
	leaq	13(%r15), %r12
	movq	-3616(%rbp), %r13
	testq	%r13, %r13
	je	.LBB1_71
# %bb.56:                               #   in Loop: Header=BB1_42 Depth=1
	cmpq	$8, %r13
	je	.LBB1_68
# %bb.57:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	-3736(%rbp), %r14
	movq	%r13, %rbx
	jmp	.LBB1_59
	.p2align	4
.LBB1_58:                               #   in Loop: Header=BB1_59 Depth=2
	addq	$16, %r14
	decq	%rbx
	je	.LBB1_71
.LBB1_59:                               #   Parent Loop BB1_42 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-8(%r14), %rdi
	movq	%r12, %rsi
	callq	strcmp@PLT
	testl	%eax, %eax
	jne	.LBB1_58
# %bb.60:                               #   in Loop: Header=BB1_59 Depth=2
	cmpl	$0, (%r14)
	jne	.LBB1_58
	jmp	.LBB1_68
.LBB1_61:                               #   in Loop: Header=BB1_42 Depth=1
	cmpb	$0, 14(%r15)
	je	.LBB1_77
# %bb.62:                               #   in Loop: Header=BB1_42 Depth=1
	movq	%r13, -112(%rbp)                # 8-byte Spill
	movq	%r12, -96(%rbp)                 # 8-byte Spill
	leaq	14(%r15), %r12
	movq	-3616(%rbp), %rbx
	testq	%rbx, %rbx
	je	.LBB1_74
# %bb.63:                               #   in Loop: Header=BB1_42 Depth=1
	cmpq	$8, %rbx
	je	.LBB1_68
# %bb.64:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	-3736(%rbp), %r14
	movq	%rbx, %r13
	jmp	.LBB1_66
	.p2align	4
.LBB1_65:                               #   in Loop: Header=BB1_66 Depth=2
	addq	$16, %r14
	decq	%r13
	je	.LBB1_74
.LBB1_66:                               #   Parent Loop BB1_42 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	-8(%r14), %rdi
	movq	%r12, %rsi
	callq	strcmp@PLT
	testl	%eax, %eax
	jne	.LBB1_65
# %bb.67:                               #   in Loop: Header=BB1_66 Depth=2
	cmpl	$1, (%r14)
	jne	.LBB1_65
.LBB1_68:                               #   in Loop: Header=BB1_42 Depth=1
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	movq	-96(%rbp), %r12                 # 8-byte Reload
	movq	-112(%rbp), %r13                # 8-byte Reload
	movq	-136(%rbp), %r14                # 8-byte Reload
	movq	-128(%rbp), %rbx                # 8-byte Reload
	jmp	.LBB1_79
.LBB1_69:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	17(%r15), %rsi
.LBB1_70:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	-14224(%rbp), %rdi
	callq	mylang_scoped_endpoint
	xorl	%ecx, %ecx
	jmp	.LBB1_79
.LBB1_71:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	1(%r13), %rax
	movq	%rax, -3616(%rbp)
	shlq	$4, %r13
	leaq	-3744(%rbp), %rax
	movq	%r12, (%rax,%r13)
	movq	$0, 8(%rax,%r13)
	jmp	.LBB1_75
.LBB1_72:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3608(%rbp)
	jne	.LBB1_77
# %bb.73:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3608(%rbp)
	jmp	.LBB1_40
.LBB1_74:                               #   in Loop: Header=BB1_42 Depth=1
	leaq	1(%rbx), %rax
	movq	%rax, -3616(%rbp)
	shlq	$4, %rbx
	leaq	-3744(%rbp), %rax
	movq	%r12, (%rax,%rbx)
	movq	$1, 8(%rax,%rbx)
.LBB1_75:                               #   in Loop: Header=BB1_42 Depth=1
	movq	-96(%rbp), %r12                 # 8-byte Reload
	movq	-112(%rbp), %r13                # 8-byte Reload
	movq	-136(%rbp), %r14                # 8-byte Reload
	movq	-128(%rbp), %rbx                # 8-byte Reload
	jmp	.LBB1_40
.LBB1_76:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3592(%rbp)
	je	.LBB1_131
	.p2align	4
.LBB1_77:                               #   in Loop: Header=BB1_42 Depth=1
	xorl	%ecx, %ecx
.LBB1_78:                               #   in Loop: Header=BB1_42 Depth=1
	xorl	%eax, %eax
.LBB1_79:                               #   in Loop: Header=BB1_42 Depth=1
	testb	%cl, %cl
	jne	.LBB1_81
# %bb.80:                               #   in Loop: Header=BB1_42 Depth=1
	testb	%al, %al
	je	.LBB1_510
.LBB1_81:                               #   in Loop: Header=BB1_42 Depth=1
	testb	%cl, %cl
	je	.LBB1_40
# %bb.82:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.38, %esi
	movl	$12, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_88
# %bb.83:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.39, %esi
	movl	$13, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_97
# %bb.84:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.40, %esi
	movl	$10, %edx
	movq	%r15, %rdi
	callq	strncmp@PLT
	testl	%eax, %eax
	je	.LBB1_106
# %bb.85:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.41, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB1_115
# %bb.86:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.42, %esi
	movq	%r15, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	jne	.LBB1_571
# %bb.87:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -120(%rbp)                  # 4-byte Folded Reload
	movl	$.L.str.71, %eax
	cmovneq	%rax, %r13
	movl	$1, -120(%rbp)                  # 4-byte Folded Spill
	jmp	.LBB1_40
.LBB1_88:                               #   in Loop: Header=BB1_42 Depth=1
	movzbl	12(%r15), %eax
	testb	%al, %al
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	je	.LBB1_95
# %bb.89:                               #   in Loop: Header=BB1_42 Depth=1
	addq	$13, %r15
	xorl	%edi, %edi
	.p2align	4
.LBB1_90:                               #   Parent Loop BB1_42 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leal	-58(%rax), %ecx
	cmpb	$-10, %cl
	jb	.LBB1_95
# %bb.91:                               #   in Loop: Header=BB1_90 Depth=2
	addb	$-48, %al
	movzbl	%al, %eax
	movq	%rax, %rdx
	notq	%rdx
	movabsq	$-3689348814741910323, %rcx     # imm = 0xCCCCCCCCCCCCCCCD
	mulxq	%rcx, %rcx, %rcx
	shrq	$3, %rcx
	cmpq	%rcx, %rdi
	ja	.LBB1_95
# %bb.92:                               #   in Loop: Header=BB1_90 Depth=2
	leaq	(%rdi,%rdi,4), %rcx
	leaq	(%rax,%rcx,2), %rdi
	movzbl	(%r15), %eax
	incq	%r15
	testb	%al, %al
	jne	.LBB1_90
# %bb.93:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -68(%rbp)                   # 4-byte Folded Reload
	sete	%al
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	jne	.LBB1_96
# %bb.94:                               #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -68(%rbp)                   # 4-byte Folded Spill
	testq	%rdi, %rdi
	jne	.LBB1_41
	jmp	.LBB1_96
.LBB1_95:                               #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -68(%rbp)                   # 4-byte Folded Reload
	sete	%al
	xorl	%edi, %edi
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB1_96:                               #   in Loop: Header=BB1_42 Depth=1
	testb	%al, %al
	movl	$.L.str.71, %r13d
	movl	$.L.str.72, %eax
	cmovneq	%rax, %r13
	movl	$1, -68(%rbp)                   # 4-byte Folded Spill
	jmp	.LBB1_41
.LBB1_97:                               #   in Loop: Header=BB1_42 Depth=1
	movzbl	13(%r15), %eax
	testb	%al, %al
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	je	.LBB1_104
# %bb.98:                               #   in Loop: Header=BB1_42 Depth=1
	addq	$14, %r15
	xorl	%esi, %esi
	.p2align	4
.LBB1_99:                               #   Parent Loop BB1_42 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leal	-58(%rax), %ecx
	cmpb	$-10, %cl
	jb	.LBB1_104
# %bb.100:                              #   in Loop: Header=BB1_99 Depth=2
	addb	$-48, %al
	movzbl	%al, %eax
	movq	%rax, %rdx
	notq	%rdx
	movabsq	$-3689348814741910323, %rcx     # imm = 0xCCCCCCCCCCCCCCCD
	mulxq	%rcx, %rcx, %rcx
	shrq	$3, %rcx
	cmpq	%rcx, %rsi
	ja	.LBB1_104
# %bb.101:                              #   in Loop: Header=BB1_99 Depth=2
	leaq	(%rsi,%rsi,4), %rcx
	leaq	(%rax,%rcx,2), %rsi
	movzbl	(%r15), %eax
	incq	%r15
	testb	%al, %al
	jne	.LBB1_99
# %bb.102:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -100(%rbp)                  # 4-byte Folded Reload
	sete	%al
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	jne	.LBB1_105
# %bb.103:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -100(%rbp)                  # 4-byte Folded Spill
	testq	%rsi, %rsi
	jne	.LBB1_41
	jmp	.LBB1_105
.LBB1_104:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -100(%rbp)                  # 4-byte Folded Reload
	sete	%al
	xorl	%esi, %esi
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB1_105:                              #   in Loop: Header=BB1_42 Depth=1
	testb	%al, %al
	movl	$.L.str.71, %r13d
	movl	$.L.str.72, %eax
	cmovneq	%rax, %r13
	movl	$1, -100(%rbp)                  # 4-byte Folded Spill
	jmp	.LBB1_41
.LBB1_106:                              #   in Loop: Header=BB1_42 Depth=1
	movzbl	10(%r15), %eax
	testb	%al, %al
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	je	.LBB1_113
# %bb.107:                              #   in Loop: Header=BB1_42 Depth=1
	addq	$11, %r15
	xorl	%r12d, %r12d
	.p2align	4
.LBB1_108:                              #   Parent Loop BB1_42 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leal	-58(%rax), %ecx
	cmpb	$-10, %cl
	jb	.LBB1_113
# %bb.109:                              #   in Loop: Header=BB1_108 Depth=2
	addb	$-48, %al
	movzbl	%al, %eax
	movq	%rax, %rdx
	notq	%rdx
	movabsq	$-3689348814741910323, %rcx     # imm = 0xCCCCCCCCCCCCCCCD
	mulxq	%rcx, %rcx, %rcx
	shrq	$3, %rcx
	cmpq	%rcx, %r12
	ja	.LBB1_113
# %bb.110:                              #   in Loop: Header=BB1_108 Depth=2
	leaq	(%r12,%r12,4), %rcx
	leaq	(%rax,%rcx,2), %r12
	movzbl	(%r15), %eax
	incq	%r15
	testb	%al, %al
	jne	.LBB1_108
# %bb.111:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -116(%rbp)                  # 4-byte Folded Reload
	sete	%al
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	jne	.LBB1_114
# %bb.112:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -116(%rbp)                  # 4-byte Folded Spill
	testq	%r12, %r12
	jne	.LBB1_41
	jmp	.LBB1_114
.LBB1_113:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -116(%rbp)                  # 4-byte Folded Reload
	sete	%al
	xorl	%r12d, %r12d
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB1_114:                              #   in Loop: Header=BB1_42 Depth=1
	testb	%al, %al
	movl	$.L.str.71, %r13d
	movl	$.L.str.72, %eax
	cmovneq	%rax, %r13
	movl	$1, -116(%rbp)                  # 4-byte Folded Spill
	jmp	.LBB1_41
.LBB1_115:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -84(%rbp)                   # 4-byte Folded Reload
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	je	.LBB1_132
# %bb.116:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -84(%rbp)                   # 4-byte Folded Spill
	movl	$.L.str.71, %r13d
	jmp	.LBB1_41
.LBB1_117:                              #   in Loop: Header=BB1_42 Depth=1
	movzbl	14(%r15), %eax
	testl	%eax, %eax
	je	.LBB1_133
# %bb.118:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$61, %eax
	jne	.LBB1_49
# %bb.119:                              #   in Loop: Header=BB1_42 Depth=1
	cmpb	$0, 15(%r15)
	je	.LBB1_49
# %bb.120:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3604(%rbp)
	jne	.LBB1_49
# %bb.121:                              #   in Loop: Header=BB1_42 Depth=1
	addq	$15, %r15
	jmp	.LBB1_135
.LBB1_122:                              #   in Loop: Header=BB1_42 Depth=1
	movzbl	11(%r15), %eax
	testl	%eax, %eax
	je	.LBB1_137
# %bb.123:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$61, %eax
	jne	.LBB1_50
# %bb.124:                              #   in Loop: Header=BB1_42 Depth=1
	cmpb	$0, 12(%r15)
	je	.LBB1_50
# %bb.125:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3600(%rbp)
	jne	.LBB1_50
# %bb.126:                              #   in Loop: Header=BB1_42 Depth=1
	addq	$12, %r15
	jmp	.LBB1_139
.LBB1_127:                              #   in Loop: Header=BB1_42 Depth=1
	vmovdqu	-3608(%rbp), %xmm0
	vpinsrd	$3, -3592(%rbp), %xmm0, %xmm0
	xorl	%ecx, %ecx
	vptest	%xmm0, %xmm0
	jne	.LBB1_78
# %bb.128:                              #   in Loop: Header=BB1_42 Depth=1
	cmpq	$0, -3616(%rbp)
	jne	.LBB1_78
# %bb.129:                              #   in Loop: Header=BB1_42 Depth=1
	cmpq	$0, -3752(%rbp)
	movl	$0, %eax
	jne	.LBB1_79
# %bb.130:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3592(%rbp)
	movl	$1, -3600(%rbp)
	movabsq	$4294967297, %rax               # imm = 0x100000001
	movq	%rax, -3608(%rbp)
	movq	$.L.str.172, -3584(%rbp)
	movq	$1, -3616(%rbp)
	movq	$.L.str.192, -3744(%rbp)
	movq	$1, -3736(%rbp)
	movl	$.L.str.17.179, %esi
	jmp	.LBB1_70
.LBB1_131:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3592(%rbp)
	jmp	.LBB1_40
.LBB1_132:                              #   in Loop: Header=BB1_42 Depth=1
	testq	%r13, %r13
	movl	$stress_needs_gc, %eax
	cmoveq	%rax, %r13
	movl	$1, -84(%rbp)                   # 4-byte Folded Spill
	jmp	.LBB1_41
.LBB1_133:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3604(%rbp)
	jne	.LBB1_49
# %bb.134:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.172, %r15d
.LBB1_135:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3604(%rbp)
	cmpb	$0, (%r15)
	je	.LBB1_40
# %bb.136:                              #   in Loop: Header=BB1_42 Depth=1
	movq	%r15, %rdi
	xorl	%esi, %esi
	movl	$10, %edx
	callq	strtoull@PLT
	movq	%rax, -3576(%rbp)
	jmp	.LBB1_40
.LBB1_137:                              #   in Loop: Header=BB1_42 Depth=1
	cmpl	$0, -3600(%rbp)
	jne	.LBB1_50
# %bb.138:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$.L.str.172, %r15d
.LBB1_139:                              #   in Loop: Header=BB1_42 Depth=1
	movl	$1, -3600(%rbp)
	movq	%r15, -3584(%rbp)
	jmp	.LBB1_40
.LBB1_142:
	xorl	%r12d, %r12d
	movq	$-1, -64(%rbp)                  # 8-byte Folded Spill
	movl	$0, -84(%rbp)                   # 4-byte Folded Spill
	xorl	%r13d, %r13d
	jmp	.LBB1_144
.LBB1_143:
	cmpl	$0, -120(%rbp)                  # 4-byte Folded Reload
	sete	%bl
	xorl	%ecx, %ecx
	cmpl	$1, -68(%rbp)                   # 4-byte Folded Reload
	movl	$0, %eax
	sbbq	%rax, %rax
	orq	%rdi, %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	cmpl	$1, -100(%rbp)                  # 4-byte Folded Reload
	sbbq	%rcx, %rcx
	orq	%rsi, %rcx
	movq	%rcx, -64(%rbp)                 # 8-byte Spill
.LBB1_144:
	movq	%r14, %rdi
	callq	free@PLT
	cmpl	$0, -3596(%rbp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -200(%rbp)
	vmovdqu	%ymm0, -224(%rbp)
	vmovdqu	%ymm0, -256(%rbp)
	vmovdqu	%ymm0, -288(%rbp)
	vmovdqu	%ymm0, -320(%rbp)
	vmovdqu	%ymm0, -352(%rbp)
	vmovdqu	%ymm0, -384(%rbp)
	movb	%bl, -68(%rbp)                  # 1-byte Spill
	je	.LBB1_151
# %bb.145:
	movq	-3616(%rbp), %r15
	movq	-14128(%rbp), %rbx
	testq	%r15, %r15
	je	.LBB1_152
# %bb.146:
	movq	%r13, -112(%rbp)                # 8-byte Spill
	movq	%r12, -96(%rbp)                 # 8-byte Spill
	leaq	(%rbx,%rbx,2), %rax
	leaq	-14216(,%rax,4), %r12
	addq	%rbp, %r12
	leaq	-3736(%rbp), %r13
	.p2align	4
.LBB1_147:                              # =>This Inner Loop Header: Depth=1
	cmpq	$7, %rbx
	ja	.LBB1_497
# %bb.148:                              #   in Loop: Header=BB1_147 Depth=1
	movl	(%r13), %r14d
	movq	-8(%r13), %rdi
	movl	$589824, %esi                   # imm = 0x90000
	xorl	%eax, %eax
	vzeroupper
	callq	open@PLT
	testl	%eax, %eax
	js	.LBB1_497
# %bb.149:                              #   in Loop: Header=BB1_147 Depth=1
	incq	%rbx
	movq	%rbx, -14128(%rbp)
	movl	%eax, -8(%r12)
	movl	%r14d, -4(%r12)
	movl	$0, (%r12)
	addq	$12, %r12
	addq	$16, %r13
	decq	%r15
	jne	.LBB1_147
# %bb.150:
	leaq	-14224(%rbp), %r14
	movq	-96(%rbp), %r12                 # 8-byte Reload
	movq	-112(%rbp), %r13                # 8-byte Reload
	cmpl	$0, -3596(%rbp)
	sete	%al
	jne	.LBB1_35
	jmp	.LBB1_154
.LBB1_151:
	movq	-144(%rbp), %rax                # 8-byte Reload
	leaq	-14224(%rbp), %r14
	movq	%rax, -144(%rbp)                # 8-byte Spill
	movq	-14128(%rbp), %rbx
	cmpq	$7, %rbx
	jbe	.LBB1_33
	jmp	.LBB1_498
.LBB1_152:
	movl	-3596(%rbp), %ecx
	testl	%ecx, %ecx
	sete	%al
	testq	%rbx, %rbx
	je	.LBB1_161
# %bb.153:
	testl	%ecx, %ecx
	leaq	-14224(%rbp), %r14
	jne	.LBB1_35
.LBB1_154:
	movl	$7, %ecx
.LBB1_155:
	movq	$0, -328(%rbp)
	movq	%r14, -336(%rbp)
	movl	%ecx, -328(%rbp)
	movq	$acquire, -320(%rbp)
	movq	$complete, -312(%rbp)
	movq	$release, -304(%rbp)
	movq	$read_handle, -296(%rbp)
	movq	$write_handle, -288(%rbp)
	cmpq	$0, -3752(%rbp)
	je	.LBB1_162
.LBB1_156:
	movq	%r14, -280(%rbp)
	movq	$7, -272(%rbp)
	movq	$acquire_network, -264(%rbp)
	movq	$complete, -256(%rbp)
	movq	$release, -248(%rbp)
	movq	$read_handle, -240(%rbp)
	movq	$write_handle, -232(%rbp)
	testb	%al, %al
	je	.LBB1_163
.LBB1_157:
	movq	$clock_now, -376(%rbp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	%xmm0, -368(%rbp)
	cmpl	$0, -3604(%rbp)
	jne	.LBB1_168
# %bb.158:
	xorl	%ebx, %ebx
	leaq	-2544(%rbp), %rsi
	xorl	%edi, %edi
	vzeroupper
	callq	clock_gettime@PLT
	testl	%eax, %eax
	jne	.LBB1_167
# %bb.159:
	movq	-2544(%rbp), %rcx
	movq	-2536(%rbp), %rax
	movabsq	$9223372036854775807, %rdx      # imm = 0x7FFFFFFFFFFFFFFF
	xorq	%rax, %rdx
	movabsq	$1237940039285380275, %rsi      # imm = 0x112E0BE826D694B3
	mulxq	%rsi, %rdx, %rdx
	shrq	$26, %rdx
	cmpq	%rdx, %rcx
	jle	.LBB1_166
# %bb.160:
	xorl	%ebx, %ebx
	jmp	.LBB1_167
.LBB1_161:
	leaq	-336(%rbp), %rcx
	vmovdqu	%ymm0, 24(%rcx)
	vmovdqu	%ymm0, (%rcx)
	leaq	-14224(%rbp), %r14
	cmpq	$0, -3752(%rbp)
	jne	.LBB1_156
.LBB1_162:
	leaq	-280(%rbp), %rcx
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 24(%rcx)
	vmovdqu	%ymm0, (%rcx)
	testb	%al, %al
	jne	.LBB1_157
.LBB1_163:
	xorl	%eax, %eax
	cmpl	$0, -3608(%rbp)
	movl	$clock_now, %ecx
	cmovneq	%rcx, %rax
	movq	%rax, -376(%rbp)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	%xmm0, -368(%rbp)
	cmpl	$0, -3604(%rbp)
	je	.LBB1_165
# %bb.164:
	leaq	-3576(%rbp), %rax
	movq	%rax, -368(%rbp)
	movq	$random_u64, -360(%rbp)
.LBB1_165:
	vmovdqa	%xmm0, -352(%rbp)
	cmpl	$0, -3600(%rbp)
	jne	.LBB1_169
	jmp	.LBB1_170
.LBB1_166:
	imulq	$1000000000, %rcx, %rbx         # imm = 0x3B9ACA00
	addq	%rax, %rbx
.LBB1_167:
	movq	%rbx, -3576(%rbp)
.LBB1_168:
	leaq	-3576(%rbp), %rax
	movq	%rax, -368(%rbp)
	movq	$random_u64, -360(%rbp)
.LBB1_169:
	movq	-3584(%rbp), %rax
	movq	%rax, -352(%rbp)
	movq	$environment_get, -344(%rbp)
.LBB1_170:
	xorl	%ebx, %ebx
	movl	-148(%rbp), %eax                # 4-byte Reload
	testl	%eax, %eax
	setg	%r15b
	cmpl	$2, %eax
	movl	$1, %ecx
	cmovgel	%eax, %ecx
	cmpq	$stress_needs_gc, %r13
	je	.LBB1_220
# %bb.171:
	testq	%r13, %r13
	jne	.LBB1_221
# %bb.172:
	testq	%r12, %r12
	je	.LBB1_176
# %bb.173:
	movl	%ecx, %r13d
	leaq	-2536(%rbp), %rdi
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -2424(%rbp)
	vmovdqu	%ymm0, -2440(%rbp)
	vmovdqu	%ymm0, -2472(%rbp)
	vmovdqu	%ymm0, -2504(%rbp)
	vmovdqu	%ymm0, -2536(%rbp)
	movq	$on_timeout, -2544(%rbp)
	vzeroupper
	callq	sigemptyset@PLT
	leaq	-2544(%rbp), %rsi
	movl	$14, %edi
	xorl	%edx, %edx
	callq	sigaction@PLT
	testl	%eax, %eax
	jne	.LBB1_219
# %bb.174:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -3568(%rbp)
	vmovdqu	%ymm0, -3536(%rbp)
	movl	$14, -3560(%rbp)
	leaq	-3568(%rbp), %rsi
	movl	$timeout_timer, %edx
	movl	$1, %edi
	vzeroupper
	callq	timer_create@PLT
	testl	%eax, %eax
	jne	.LBB1_219
# %bb.175:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -1008(%rbp)
	movq	%r12, -992(%rbp)
	movq	timeout_timer(%rip), %rdi
	leaq	-1008(%rbp), %rdx
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	vzeroupper
	callq	timer_settime@PLT
	testl	%eax, %eax
	movl	%r13d, %ecx
	jne	.LBB1_219
.LBB1_176:
	movb	%r15b, %bl
	movq	-160(%rbp), %rax                # 8-byte Reload
	leaq	(%rax,%rbx,8), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	decl	%ecx
	movl	%ecx, -96(%rbp)                 # 4-byte Spill
	je	.LBB1_203
# %bb.177:
	movl	-96(%rbp), %r15d                # 4-byte Reload
	xorl	%r13d, %r13d
	jmp	.LBB1_179
	.p2align	4
.LBB1_178:                              #   in Loop: Header=BB1_179 Depth=1
	incq	%r13
	cmpq	%r15, %r13
	je	.LBB1_203
.LBB1_179:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_183 Depth 2
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	(%rax,%r13,8), %rbx
	movq	%rbx, %rdi
	vzeroupper
	callq	strlen@PLT
	testq	%rax, %rax
	je	.LBB1_178
# %bb.180:                              #   in Loop: Header=BB1_179 Depth=1
	movq	%rax, %r12
	xorl	%ecx, %ecx
	jmp	.LBB1_183
	.p2align	4
.LBB1_181:                              #   in Loop: Header=BB1_183 Depth=2
	decl	%edx
	leaq	(%rcx,%rdx), %r9
	addq	$2, %r9
.LBB1_182:                              #   in Loop: Header=BB1_183 Depth=2
	movq	%r9, %rcx
	cmpq	%r12, %r9
	je	.LBB1_178
.LBB1_183:                              #   Parent Loop BB1_179 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	1(%rcx), %r9
	movzbl	(%rbx,%rcx), %edi
	testb	%dil, %dil
	jns	.LBB1_182
# %bb.184:                              #   in Loop: Header=BB1_183 Depth=2
	leal	62(%rdi), %r8d
	cmpb	$30, %r8b
	jae	.LBB1_186
# %bb.185:                              #   in Loop: Header=BB1_183 Depth=2
	movl	$128, %esi
	movl	$1, %edx
	movl	$31, %r10d
	jmp	.LBB1_190
.LBB1_186:                              #   in Loop: Header=BB1_183 Depth=2
	movl	%edi, %edx
	andb	$-16, %dl
	cmpb	$-32, %dl
	jne	.LBB1_188
# %bb.187:                              #   in Loop: Header=BB1_183 Depth=2
	movl	$2048, %esi                     # imm = 0x800
	movl	$2, %edx
	movb	$1, %r11b
	movl	$15, %r10d
	jmp	.LBB1_191
.LBB1_188:                              #   in Loop: Header=BB1_183 Depth=2
	leal	16(%rdi), %edx
	cmpb	$4, %dl
	ja	.LBB1_202
# %bb.189:                              #   in Loop: Header=BB1_183 Depth=2
	movl	$65536, %esi                    # imm = 0x10000
	movl	$3, %edx
	movl	$7, %r10d
.LBB1_190:                              #   in Loop: Header=BB1_183 Depth=2
	xorl	%r11d, %r11d
.LBB1_191:                              #   in Loop: Header=BB1_183 Depth=2
	movl	%edx, %r14d
	movq	%r12, %rax
	subq	%r9, %rax
	cmpq	%r14, %rax
	jb	.LBB1_202
# %bb.192:                              #   in Loop: Header=BB1_183 Depth=2
	movzbl	1(%rbx,%rcx), %r9d
	movl	%r9d, %eax
	andl	$-64, %eax
	cmpl	$128, %eax
	jne	.LBB1_202
# %bb.193:                              #   in Loop: Header=BB1_183 Depth=2
	andl	%edi, %r10d
	shll	$6, %r10d
	andl	$63, %r9d
	orl	%r10d, %r9d
	cmpb	$30, %r8b
	jb	.LBB1_197
# %bb.194:                              #   in Loop: Header=BB1_183 Depth=2
	movzbl	2(%rbx,%rcx), %edi
	movl	%edi, %eax
	andl	$-64, %eax
	cmpl	$128, %eax
	jne	.LBB1_202
# %bb.195:                              #   in Loop: Header=BB1_183 Depth=2
	shll	$6, %r9d
	andl	$63, %edi
	orl	%r9d, %edi
	testb	%r11b, %r11b
	je	.LBB1_200
# %bb.196:                              #   in Loop: Header=BB1_183 Depth=2
	movl	%r9d, %r10d
	movl	%edi, %r9d
.LBB1_197:                              #   in Loop: Header=BB1_183 Depth=2
	cmpl	$1114111, %r10d                 # imm = 0x10FFFF
	ja	.LBB1_202
.LBB1_198:                              #   in Loop: Header=BB1_183 Depth=2
	cmpl	%esi, %r9d
	jb	.LBB1_202
# %bb.199:                              #   in Loop: Header=BB1_183 Depth=2
	addl	$-57344, %r10d                  # imm = 0xFFFF2000
	cmpl	$-2049, %r10d                   # imm = 0xF7FF
	jbe	.LBB1_181
	jmp	.LBB1_202
.LBB1_200:                              #   in Loop: Header=BB1_183 Depth=2
	movzbl	3(%rbx,%rcx), %r9d
	movl	%r9d, %eax
	andl	$-64, %eax
	cmpl	$128, %eax
	jne	.LBB1_202
# %bb.201:                              #   in Loop: Header=BB1_183 Depth=2
	shll	$6, %edi
	andl	$63, %r9d
	orl	%edi, %r9d
	movl	%edi, %r10d
	cmpl	$1114111, %r10d                 # imm = 0x10FFFF
	jbe	.LBB1_198
.LBB1_202:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.47, %edi
	movl	$42, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	movl	$2, %r15d
	movl	$112, %ebx
	leaq	-14224(%rbp), %r14
	jmp	.LBB1_577
.LBB1_203:
	leaq	-1008(%rbp), %rdi
	movl	$616, %edx                      # imm = 0x268
	xorl	%esi, %esi
	vzeroupper
	callq	memset@PLT
	movl	$.L.str.72, %ecx
	cmpq	$0, -48(%rbp)                   # 8-byte Folded Reload
	je	.LBB1_477
# %bb.204:
	movq	-64(%rbp), %rax                 # 8-byte Reload
	testq	%rax, %rax
	je	.LBB1_477
# %bb.205:
	cmpq	$-1, %rax
	movl	$1024, %r12d                    # imm = 0x400
	cmovneq	%rax, %r12
	movq	%r12, %rax
	shrq	$59, %rax
	movl	$.L.str.122, %ecx
	jne	.LBB1_477
# %bb.206:
	movl	$.L.str.43, %edi
	callq	getenv@PLT
	testq	%rax, %rax
	je	.LBB1_218
# %bb.207:
	movzbl	(%rax), %edx
	testb	%dl, %dl
	je	.LBB1_218
# %bb.208:
	leal	-48(%rdx), %esi
	movl	$.L.str.108, %ecx
	cmpb	$9, %sil
	ja	.LBB1_477
# %bb.209:
	decq	%rax
	xorl	%esi, %esi
	movabsq	$-3689348814741910323, %rdi     # imm = 0xCCCCCCCCCCCCCCCD
	.p2align	4
.LBB1_210:                              # =>This Inner Loop Header: Depth=1
	addb	$-48, %dl
	movzbl	%dl, %r8d
	movq	%r8, %rdx
	notq	%rdx
	mulxq	%rdi, %rdx, %rdx
	shrq	$3, %rdx
	cmpq	%rdx, %rsi
	ja	.LBB1_477
# %bb.211:                              #   in Loop: Header=BB1_210 Depth=1
	leaq	(%rsi,%rsi,4), %rdx
	leaq	(%r8,%rdx,2), %rsi
	movzbl	2(%rax), %edx
	leal	-48(%rdx), %r8d
	incq	%rax
	cmpb	$10, %r8b
	jb	.LBB1_210
# %bb.212:
	movzbl	%dl, %edx
	leal	-71(%rdx), %edi
	cmpl	$38, %edi
	ja	.LBB1_476
# %bb.213:
	movabsq	$4294967297, %r8                # imm = 0x100000001
	btq	%rdi, %r8
	jb	.LBB1_222
# %bb.214:
	movl	$1024, %r14d                    # imm = 0x400
	movabsq	$68719476752, %r8               # imm = 0x1000000010
	btq	%rdi, %r8
	jb	.LBB1_223
# %bb.215:
	movabsq	$274877907008, %r8              # imm = 0x4000000040
	btq	%rdi, %r8
	jae	.LBB1_476
# %bb.216:
	movl	$1048576, %r14d                 # imm = 0x100000
	jmp	.LBB1_223
.LBB1_218:
	xorl	%r14d, %r14d
	movl	$.L.str.1.46, %edi
	callq	getenv@PLT
	testq	%rax, %rax
	jne	.LBB1_227
	jmp	.LBB1_229
.LBB1_219:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.46, %edi
	movl	$50, %esi
	jmp	.LBB1_499
.LBB1_220:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.44, %edi
	movl	$94, %esi
	jmp	.LBB1_499
.LBB1_221:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movl	$.L.str.45, %esi
	movq	%r13, %rdx
	xorl	%eax, %eax
	vzeroupper
	callq	fprintf@PLT
	jmp	.LBB1_500
.LBB1_222:
	movl	$1073741824, %r14d              # imm = 0x40000000
.LBB1_223:
	cmpb	$0, 2(%rax)
	jne	.LBB1_477
.LBB1_224:
	tzcntq	%r14, %rax
	movq	$-1, %rdx
	shrxq	%rax, %rdx, %rax
	cmpq	%rax, %rsi
	ja	.LBB1_477
# %bb.225:
	imulq	%rsi, %r14
	movl	$.L.str.1.46, %edi
	callq	getenv@PLT
	testq	%rax, %rax
	je	.LBB1_229
.LBB1_227:
	movzbl	(%rax), %edx
	leal	-58(%rdx), %ecx
	cmpb	$-10, %cl
	jae	.LBB1_240
.LBB1_228:
	movl	$.L.str.1.46, %edi
	callq	unsetenv@PLT
	movl	$.L.str.2.47, %edi
	callq	unsetenv@PLT
.LBB1_229:
	movq	%r14, %r13
	leaq	268435456(%r14), %rbx
	cmpq	$268435457, %rbx                # imm = 0x10000001
	jb	.LBB1_234
# %bb.230:
	leaq	-2544(%rbp), %rsi
	movl	$9, %edi
	callq	getrlimit@PLT
	testl	%eax, %eax
	jne	.LBB1_234
# %bb.231:
	movq	-2544(%rbp), %rcx
	movq	-2536(%rbp), %rdx
	cmpq	%rdx, %rbx
	movq	%rdx, %rax
	cmovbq	%rbx, %rax
	cmpq	$-1, %rdx
	cmoveq	%rbx, %rax
	cmpq	$-1, %rcx
	je	.LBB1_233
# %bb.232:
	cmpq	%rax, %rcx
	jbe	.LBB1_234
.LBB1_233:
	movq	%rax, -2544(%rbp)
	leaq	-2544(%rbp), %rsi
	movl	$9, %edi
	callq	setrlimit@PLT
.LBB1_234:
	movl	$1, %edi
	movl	$16008, %esi                    # imm = 0x3E88
	callq	calloc@PLT
	movl	$.L.str.122, %ecx
	testq	%rax, %rax
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	je	.LBB1_477
# %bb.235:
	movq	%rax, %r15
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	%rax, 16(%r15)
	movq	%r12, 24(%r15)
	movq	%rdx, 56(%r15)
	leaq	-384(%rbp), %rax
	movq	%rax, 14712(%r15)
	movl	-96(%rbp), %eax                 # 4-byte Reload
	movl	%eax, 14800(%r15)
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, 14808(%r15)
	leaq	600(%r15), %r14
	xorl	%ebx, %ebx
	cmpq	$1, %r13
	sbbq	%rbx, %rbx
	orq	%r13, %rbx
	movl	$5912, %edx                     # imm = 0x1718
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%rbx, 688(%r15)
	movq	$1, 656(%r15)
	movq	$1048576, 696(%r15)             # imm = 0x100000
	cmpq	$1111, %rbx                     # imm = 0x457
	ja	.LBB1_237
# %bb.236:
	movl	$1, 708(%r15)
	jmp	.LBB1_257
.LBB1_237:
	movl	$1, %edi
	movl	$1112, %esi                     # imm = 0x458
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB1_257
# %bb.238:
	movq	$1112, 624(%r15)                # imm = 0x458
	movq	$1112, 520(%rax)                # imm = 0x458
	cmpq	$1407, %rbx                     # imm = 0x57F
	ja	.LBB1_253
# %bb.239:
	movl	$1, 708(%r15)
	jmp	.LBB1_256
.LBB1_240:
	addq	$2, %rax
	xorl	%r15d, %r15d
	movabsq	$-3689348814741910323, %rcx     # imm = 0xCCCCCCCCCCCCCCCD
	.p2align	4
.LBB1_241:                              # =>This Inner Loop Header: Depth=1
	addb	$-48, %dl
	movzbl	%dl, %esi
	movq	%rsi, %rdx
	notq	%rdx
	mulxq	%rcx, %rdx, %rdx
	shrq	$3, %rdx
	cmpq	%rdx, %r15
	ja	.LBB1_228
# %bb.242:                              #   in Loop: Header=BB1_241 Depth=1
	leaq	(%r15,%r15,4), %rdx
	leaq	(%rsi,%rdx,2), %r15
	movzbl	-1(%rax), %edx
	leal	-48(%rdx), %esi
	incq	%rax
	cmpb	$10, %sil
	jb	.LBB1_241
# %bb.243:
	cmpb	$58, %dl
	jne	.LBB1_228
# %bb.244:
	movzbl	-1(%rax), %ebx
	leal	-58(%rbx), %edx
	cmpb	$-10, %dl
	jb	.LBB1_228
# %bb.245:
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_246:                              # =>This Inner Loop Header: Depth=1
	addb	$-48, %bl
	movzbl	%bl, %esi
	movq	%rsi, %rdx
	notq	%rdx
	mulxq	%rcx, %rdx, %rdx
	shrq	$3, %rdx
	cmpq	%rdx, %r13
	ja	.LBB1_228
# %bb.247:                              #   in Loop: Header=BB1_246 Depth=1
	leaq	(,%r13,4), %rdx
	addq	%r13, %rdx
	leaq	(%rsi,%rdx,2), %r13
	movzbl	(%rax), %ebx
	leal	-48(%rbx), %edx
	incq	%rax
	cmpb	$10, %dl
	jb	.LBB1_246
# %bb.248:
	movl	$.L.str.1.46, %edi
	callq	unsetenv@PLT
	movl	$.L.str.2.47, %edi
	callq	unsetenv@PLT
	testb	%bl, %bl
	jne	.LBB1_229
# %bb.249:
	leaq	-2544(%rbp), %rsi
	movl	$9, %edi
	callq	getrlimit@PLT
	testl	%eax, %eax
	jne	.LBB1_229
# %bb.250:
	cmpq	%r15, -2544(%rbp)
	jne	.LBB1_229
# %bb.251:
	movq	-2536(%rbp), %rcx
	cmpq	%rcx, %r13
	movq	%rcx, %rax
	cmovbq	%r13, %rax
	cmpq	$-1, %rcx
	cmoveq	%r13, %rax
	cmpq	%r15, %rax
	jbe	.LBB1_229
# %bb.252:
	movq	%rax, -2544(%rbp)
	leaq	-2544(%rbp), %rsi
	movl	$9, %edi
	callq	setrlimit@PLT
	jmp	.LBB1_229
.LBB1_253:
	movl	$1, %edi
	movl	$296, %esi                      # imm = 0x128
	movq	%rax, %rbx
	callq	calloc@PLT
	movq	%rax, %rcx
	movq	%rbx, %rax
	testq	%rcx, %rcx
	je	.LBB1_256
# %bb.254:
	vmovdqu	allocator(%rip), %ymm0
	vmovdqu	%ymm0, (%rcx)
	movq	%rax, 32(%rcx)
	movq	$296, 48(%rcx)                  # imm = 0x128
	movq	$myl_rc_map_sentinel, 120(%rcx)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 128(%rcx)
	movq	$63, 144(%rcx)
	vmovdqu	120(%rcx), %ymm1
	vmovdqu	%ymm1, 88(%rcx)
	vmovdqu	%ymm1, 56(%rcx)
	vmovdqu	%xmm0, 152(%rcx)
	movq	$0, 168(%rcx)
	movq	$1408, 624(%r15)                # imm = 0x580
	movq	%rcx, 6240(%r15)
	movl	$raw_module, %esi
	movq	%r14, %rdi
	vzeroupper
	callq	myl_rc_module_register
	testl	%eax, %eax
	je	.LBB1_258
# %bb.255:
	movq	%r14, %rdi
	callq	myl_rc_heap_destroy
	jmp	.LBB1_257
.LBB1_256:
	movq	$0, 624(%r15)
	movq	%rax, %rdi
	callq	free@PLT
.LBB1_257:
	movl	$1, 1872(%r15)
.LBB1_258:
	movq	%r12, -56(%rbp)                 # 8-byte Spill
	movl	-84(%rbp), %eax                 # 4-byte Reload
	movl	%eax, 704(%r15)
	movq	6240(%r15), %r9
	testq	%r9, %r9
	je	.LBB1_382
# %bb.259:
	cmpq	$0, myl_rc_generated_image@GOTPCREL(%rip)
	je	.LBB1_381
# %bb.260:
	cmpq	$0, 192(%r9)
	jne	.LBB1_372
# %bb.261:
	movq	myl_rc_generated_image@GOTPCREL(%rip), %rcx
	cmpl	$1, (%rcx)
	jne	.LBB1_372
# %bb.262:
	cmpq	$23, 16(%rcx)
	jne	.LBB1_372
# %bb.263:
	cmpq	$23, 32(%rcx)
	jne	.LBB1_372
# %bb.264:
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB1_372
# %bb.265:
	movq	24(%rcx), %r12
	testq	%r12, %r12
	je	.LBB1_372
# %bb.266:
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB1_372
# %bb.267:
	cmpq	$myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc, (%rdx)
	jne	.LBB1_372
# %bb.268:
	cmpq	$8, 8(%rdx)
	jne	.LBB1_372
# %bb.269:
	movq	56(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB1_372
# %bb.270:
	cmpq	%rcx, 48(%rdx)
	ja	.LBB1_372
# %bb.271:
	movq	myl_rc_generated_image@GOTPCREL(%rip), %rdx
	movq	40(%rdx), %rbx
	cmpq	%rbx, %rcx
	ja	.LBB1_372
# %bb.272:
	movl	$8, %edx
	.p2align	4
.LBB1_273:                              # =>This Inner Loop Header: Depth=1
	movq	(%rax,%rdx), %rsi
	testq	%rsi, %rsi
	je	.LBB1_372
# %bb.274:                              #   in Loop: Header=BB1_273 Depth=1
	movq	(%rsi), %rdi
	testq	%rdi, %rdi
	je	.LBB1_372
# %bb.275:                              #   in Loop: Header=BB1_273 Depth=1
	cmpq	myl_rc_generated_shapes(%rdx), %rdi
	jne	.LBB1_372
# %bb.276:                              #   in Loop: Header=BB1_273 Depth=1
	movq	8(%rsi), %r8
	cmpq	(%rdi), %r8
	jne	.LBB1_372
# %bb.277:                              #   in Loop: Header=BB1_273 Depth=1
	movq	56(%rsi), %rdi
	testq	%rdi, %rdi
	je	.LBB1_372
# %bb.278:                              #   in Loop: Header=BB1_273 Depth=1
	cmpq	%rbx, %rdi
	ja	.LBB1_372
# %bb.279:                              #   in Loop: Header=BB1_273 Depth=1
	cmpq	%rdi, 48(%rsi)
	ja	.LBB1_372
# %bb.280:                              #   in Loop: Header=BB1_273 Depth=1
	cmpq	%rcx, %rdi
	cmovaq	%rdi, %rcx
	addq	$8, %rdx
	cmpq	$184, %rdx
	jne	.LBB1_273
# %bb.281:
	movq	%r9, -48(%rbp)                  # 8-byte Spill
	cmpq	%rcx, %rbx
	jne	.LBB1_372
# %bb.282:
	leaq	156(%r12), %rax
	xorl	%ecx, %ecx
	jmp	.LBB1_285
	.p2align	4
.LBB1_283:                              #   in Loop: Header=BB1_285 Depth=1
	orb	%dil, %r11b
	jne	.LBB1_372
.LBB1_284:                              #   in Loop: Header=BB1_285 Depth=1
	incq	%rcx
	addq	$200, %rax
	cmpq	$23, %rcx
	je	.LBB1_373
.LBB1_285:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_301 Depth 2
	imulq	$200, %rcx, %rsi
	movq	(%r12,%rsi), %rdi
	testq	%rdi, %rdi
	je	.LBB1_372
# %bb.286:                              #   in Loop: Header=BB1_285 Depth=1
	addq	%r12, %rsi
	movq	8(%rsi), %r8
	testq	%r8, %r8
	je	.LBB1_372
# %bb.287:                              #   in Loop: Header=BB1_285 Depth=1
	movq	%rcx, %r9
	shlq	$6, %r9
	leaq	myl_rc_generated_descriptors(%r9), %r9
	cmpq	(%r9), %rdi
	jne	.LBB1_372
# %bb.288:                              #   in Loop: Header=BB1_285 Depth=1
	movq	(%rdi), %r9
	cmpq	(%r8), %r9
	jne	.LBB1_372
# %bb.289:                              #   in Loop: Header=BB1_285 Depth=1
	cmpl	$0, 192(%rsi)
	jne	.LBB1_372
# %bb.290:                              #   in Loop: Header=BB1_285 Depth=1
	cmpq	%r9, 80(%rsi)
	jne	.LBB1_372
# %bb.291:                              #   in Loop: Header=BB1_285 Depth=1
	movl	64(%rsi), %r10d
	cmpq	$17, %r10
	ja	.LBB1_372
# %bb.292:                              #   in Loop: Header=BB1_285 Depth=1
	movzbl	68(%rsi), %edi
	cmpb	$1, %dil
	ja	.LBB1_372
# %bb.293:                              #   in Loop: Header=BB1_285 Depth=1
	cmpb	$0, 69(%rsi)
	jne	.LBB1_372
# %bb.294:                              #   in Loop: Header=BB1_285 Depth=1
	movzbl	70(%rsi), %r11d
	cmpb	$2, %r11b
	jae	.LBB1_372
# %bb.295:                              #   in Loop: Header=BB1_285 Depth=1
	cmpl	$17, %r10d
	je	.LBB1_283
# %bb.296:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	88(%rsi), %edi
	movl	$65535, %edx                    # imm = 0xFFFF
	shrxl	%r10d, %edx, %r8d
	shlxl	%r10d, %r8d, %r8d
	xorl	%edi, %r8d
	cmpl	$65535, %r8d                    # imm = 0xFFFF
	jne	.LBB1_372
# %bb.297:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	90(%rsi), %r8d
	andnl	%r8d, %edi, %r14d
	jne	.LBB1_372
# %bb.298:                              #   in Loop: Header=BB1_285 Depth=1
	testq	%r10, %r10
	je	.LBB1_303
# %bb.299:                              #   in Loop: Header=BB1_285 Depth=1
	movq	%r9, %r14
	subq	$8, %r14
	jb	.LBB1_372
# %bb.300:                              #   in Loop: Header=BB1_285 Depth=1
	xorl	%r13d, %r13d
	.p2align	4
.LBB1_301:                              #   Parent Loop BB1_285 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movzwl	(%rax,%r13,2), %edx
	cmpq	%rdx, %r14
	jb	.LBB1_372
# %bb.302:                              #   in Loop: Header=BB1_301 Depth=2
	incq	%r13
	cmpq	%r13, %r10
	jne	.LBB1_301
.LBB1_303:                              #   in Loop: Header=BB1_285 Depth=1
	testb	%r11b, %r11b
	je	.LBB1_306
# %bb.304:                              #   in Loop: Header=BB1_285 Depth=1
	cmpq	$4, %r9
	jb	.LBB1_372
# %bb.305:                              #   in Loop: Header=BB1_285 Depth=1
	movl	72(%rsi), %edx
	addq	$-4, %r9
	cmpq	%rdx, %r9
	jae	.LBB1_308
	jmp	.LBB1_372
.LBB1_306:                              #   in Loop: Header=BB1_285 Depth=1
	cmpw	%di, %r8w
	jne	.LBB1_372
# %bb.307:                              #   in Loop: Header=BB1_285 Depth=1
	cmpl	$-1, 72(%rsi)
	jne	.LBB1_372
.LBB1_308:                              #   in Loop: Header=BB1_285 Depth=1
	notl	%edi
	movzwl	92(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.309:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.310:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	94(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.311:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.312:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	96(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.313:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.314:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	98(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.315:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.316:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	100(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.317:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.318:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	102(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.319:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.320:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	104(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.321:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.322:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	106(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.323:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.324:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	108(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.325:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.326:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	110(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.327:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.328:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	112(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.329:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.330:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	114(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.331:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.332:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	116(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.333:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.334:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	118(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.335:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.336:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	120(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.337:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.338:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	122(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.339:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.340:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	124(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.341:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.342:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	126(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.343:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.344:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	128(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.345:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.346:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	130(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.347:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.348:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	132(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.349:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.350:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	134(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.351:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.352:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	136(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.353:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.354:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	138(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.355:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.356:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	140(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.357:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.358:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	142(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.359:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.360:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	144(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.361:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.362:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	146(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.363:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.364:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	148(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.365:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.366:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	150(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.367:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.368:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	152(%rsi), %r9d
	testl	%edi, %r9d
	jne	.LBB1_372
# %bb.369:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %r9d
	cmpl	%r8d, %r9d
	jne	.LBB1_372
# %bb.370:                              #   in Loop: Header=BB1_285 Depth=1
	movzwl	154(%rsi), %esi
	testl	%edi, %esi
	jne	.LBB1_372
# %bb.371:                              #   in Loop: Header=BB1_285 Depth=1
	andl	%r8d, %esi
	cmpl	%r8d, %esi
	je	.LBB1_284
.LBB1_372:
	callq	myl_rc_invariant_failed
.LBB1_373:
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	56(%rcx), %rax
	movq	64(%rcx), %rdx
	movzbl	80(%rcx), %ecx
	movl	$myl_rc_generated_module, %esi
	movabsq	$-7046029254386353131, %rdi     # imm = 0x9E3779B97F4A7C15
	imulq	%rsi, %rdi
	shrxq	%rcx, %rdi, %rcx
	.p2align	4
.LBB1_374:                              # =>This Inner Loop Header: Depth=1
	andq	%rdx, %rcx
	movq	%rcx, %rsi
	shlq	$4, %rsi
	movq	(%rax,%rsi), %rsi
	cmpq	$myl_rc_generated_module, %rsi
	je	.LBB1_377
# %bb.375:                              #   in Loop: Header=BB1_374 Depth=1
	testq	%rsi, %rsi
	je	.LBB1_378
# %bb.376:                              #   in Loop: Header=BB1_374 Depth=1
	incq	%rcx
	jmp	.LBB1_374
.LBB1_377:
	shlq	$4, %rcx
	cmpq	$0, 8(%rax,%rcx)
	jne	.LBB1_385
.LBB1_378:
	movl	$4664, %r13d                    # imm = 0x1238
	addq	624(%r15), %r13
	jb	.LBB1_380
# %bb.379:
	movq	688(%r15), %rax
	testq	%rax, %rax
	setne	%cl
	cmpq	%rax, %r13
	seta	%al
	andb	%cl, %al
	cmpb	$1, %al
	jne	.LBB1_488
.LBB1_380:
	movl	$1, 708(%r15)
	jmp	.LBB1_382
.LBB1_381:
	movl	$myl_rc_generated_module, %esi
	movq	%r14, %rdi
	callq	myl_rc_module_register
	testl	%eax, %eax
	je	.LBB1_385
.LBB1_382:
	movl	$.L.str.17, %esi
	cmpl	$0, 708(%r15)
	jne	.LBB1_384
# %bb.383:
	movl	$.L.str.122, %esi
.LBB1_384:
	movq	%r15, %rdi
	callq	fail
.LBB1_385:
	movq	32(%r15), %rax
	testq	%rax, %rax
	jne	.LBB1_397
.LBB1_386:
	movl	$32, %esi
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	callq	calloc@PLT
	movq	%rax, 40(%r15)
	testq	%rax, %rax
	je	.LBB1_395
# %bb.387:
	callq	fegetround@PLT
	testl	%eax, %eax
	jne	.LBB1_390
# %bb.388:
	movabsq	$4503599627370496, %rax         # imm = 0x10000000000000
	movq	%rax, -2544(%rbp)
	movabsq	$4602678819172646912, %rax      # imm = 0x3FE0000000000000
	movq	%rax, -3568(%rbp)
	movq	$1, -80(%rbp)
	movabsq	$4607182418800017408, %rax      # imm = 0x3FF0000000000000
	movq	%rax, -168(%rbp)
	vmovsd	-2544(%rbp), %xmm0              # xmm0 = mem[0],zero
	vmulsd	-3568(%rbp), %xmm0, %xmm0
	vmovq	%xmm0, %rax
	movabsq	$2251799813685248, %rcx         # imm = 0x8000000000000
	cmpq	%rcx, %rax
	jne	.LBB1_390
# %bb.389:
	vmovsd	-80(%rbp), %xmm0                # xmm0 = mem[0],zero
	vmulsd	-168(%rbp), %xmm0, %xmm0
	vmovq	%xmm0, %rax
	cmpq	$1, %rax
	je	.LBB1_391
.LBB1_390:
	movl	$.L.str.70, %esi
	movq	%r15, %rdi
	callq	fail
.LBB1_391:
	movq	32(%r15), %rax
	testq	%rax, %rax
	jne	.LBB1_397
# %bb.392:
	movq	%r15, %rdi
	callq	myl_qbe_on_stack
	movq	%rax, -1008(%rbp)
	movq	32(%r15), %rax
	testq	%rax, %rax
	jne	.LBB1_397
# %bb.393:
	movl	$.L.str.32, %eax
	cmpq	$0, 8(%r15)
	jne	.LBB1_396
# %bb.394:
	xorl	%eax, %eax
	jmp	.LBB1_397
.LBB1_395:
	movl	$.L.str.122, %eax
.LBB1_396:
	movq	%rax, 32(%r15)
.LBB1_397:
	movq	(%r15), %rcx
	movq	%rcx, -1000(%rbp)
	movq	%rax, -992(%rbp)
	vmovups	584(%r15), %xmm0
	vmovups	%xmm0, -472(%rbp)
	movl	14816(%r15), %eax
	movl	%eax, -456(%rbp)
	vmovdqu	14824(%r15), %ymm0
	vmovdqu	14848(%r15), %ymm1
	vmovdqu	%ymm0, -448(%rbp)
	vmovdqu	%ymm1, -424(%rbp)
	leaq	-984(%rbp), %rdi
	leaq	72(%r15), %rsi
	movl	$512, %edx                      # imm = 0x200
	vzeroupper
	callq	memcpy@PLT
	movq	16000(%r15), %rax
	testq	%rax, %rax
	leaq	-14224(%rbp), %r14
	je	.LBB1_399
# %bb.398:
	movq	%r15, %rdi
	callq	*%rax
.LBB1_399:
	movq	14752(%r15), %rax
	testq	%rax, %rax
	je	.LBB1_401
# %bb.400:
	movq	%r15, %rdi
	callq	*%rax
.LBB1_401:
	movq	15992(%r15), %rax
	testq	%rax, %rax
	leaq	600(%r15), %r12
	je	.LBB1_403
# %bb.402:
	movq	%r15, %rdi
	callq	*%rax
.LBB1_403:
	movq	32(%r15), %rax
	testq	%rax, %rax
	je	.LBB1_406
# %bb.404:
	movq	6240(%r15), %r13
	testq	%r13, %r13
	je	.LBB1_458
# %bb.405:
	leaq	712(%r15), %r14
	movq	%r15, %rbx
	addq	$808, %rbx                      # imm = 0x328
	movq	248(%r13), %r12
	movq	$0, 248(%r13)
	testq	%r12, %r12
	jne	.LBB1_412
	jmp	.LBB1_421
.LBB1_406:
	cmpl	$0, 704(%r15)
	jne	.LBB1_409
# %bb.407:
	cmpq	$0, 14736(%r15)
	jne	.LBB1_409
# %bb.408:
	cmpq	$0, 14744(%r15)
	je	.LBB1_458
.LBB1_409:
	movq	6240(%r15), %rcx
	testq	%rcx, %rcx
	je	.LBB1_458
# %bb.410:
	leaq	712(%r15), %r13
	testq	%rax, %rax
	je	.LBB1_452
# %bb.411:
	movq	%r15, %rbx
	addq	$808, %rbx                      # imm = 0x328
	movq	%r13, %r14
	movq	%rcx, %r13
	movq	248(%r13), %r12
	movq	$0, 248(%r13)
	testq	%r12, %r12
	je	.LBB1_421
.LBB1_412:
	movq	%r14, -56(%rbp)                 # 8-byte Spill
	movq	%rbx, %r14
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	.LBB1_414
	.p2align	4
.LBB1_413:                              #   in Loop: Header=BB1_414 Depth=1
	addq	$8, %r12
	vmovdqu	%xmm0, (%r12)
	movl	$0, 16(%r12)
	movq	%r13, %r12
	testq	%r13, %r13
	je	.LBB1_420
.LBB1_414:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_415 Depth 2
	movq	8(%r12), %r13
	movq	16(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB1_413
	.p2align	4
.LBB1_415:                              #   Parent Loop BB1_414 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rsi), %rbx
	movq	6240(%r15), %rax
	movq	264(%rax), %rcx
	cmpq	$32, %rcx
	je	.LBB1_419
# %bb.416:                              #   in Loop: Header=BB1_415 Depth=2
	movq	624(%r15), %rdx
	cmpq	$40, %rdx
	jb	.LBB1_372
# %bb.417:                              #   in Loop: Header=BB1_415 Depth=2
	movq	48(%rax), %rdi
	cmpq	$39, %rdi
	jbe	.LBB1_372
# %bb.418:                              #   in Loop: Header=BB1_415 Depth=2
	addq	$-40, %rdx
	movq	%rdx, 624(%r15)
	addq	$-40, %rdi
	movq	%rdi, 48(%rax)
	movq	256(%rax), %rdx
	movq	%rdx, (%rsi)
	movq	%rsi, 256(%rax)
	incq	%rcx
	movq	%rcx, 264(%rax)
	movq	%rbx, %rsi
	testq	%rbx, %rbx
	jne	.LBB1_415
	jmp	.LBB1_413
.LBB1_419:                              #   in Loop: Header=BB1_415 Depth=2
	leaq	600(%r15), %rdi
	callq	entry_release
	vpxor	%xmm0, %xmm0, %xmm0
	movq	%rbx, %rsi
	testq	%rbx, %rbx
	jne	.LBB1_415
	jmp	.LBB1_413
.LBB1_420:
	movq	6240(%r15), %r13
	testq	%r13, %r13
	movq	%r14, %rbx
	movq	-56(%rbp), %r14                 # 8-byte Reload
	je	.LBB1_372
.LBB1_421:
	movq	5112(%r15), %rax
	testq	%rax, %rax
	je	.LBB1_423
# %bb.422:
	movq	2072(%r15), %rcx
	subq	%rax, %rcx
	addq	$-80, %rcx
	movq	%rcx, 16(%rax)
	movq	$0, 5112(%r15)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 2072(%r15)
.LBB1_423:
	movq	5184(%r15), %rsi
	testq	%rsi, %rsi
	je	.LBB1_426
# %bb.424:
	movq	1840(%r15), %rax
	testb	$1, %sil
	jne	.LBB1_427
# %bb.425:
	xorl	%edx, %edx
	movq	%rsi, %rcx
	movq	%rdx, %rdi
	cmpq	$1, %rsi
	jne	.LBB1_472
	jmp	.LBB1_431
.LBB1_426:
	movl	$0, (%r14)
	movl	$1024, %edx                     # imm = 0x400
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	jmp	.LBB1_441
.LBB1_427:
	leaq	-1(%rsi), %rcx
	movq	-8(%rax,%rsi,8), %rdi
	movq	$0, -8(%rax,%rsi,8)
	testq	%rdi, %rdi
	je	.LBB1_469
# %bb.428:
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_429:                              # =>This Inner Loop Header: Depth=1
	movq	%rdi, %rdx
	movq	(%rdi), %rdi
	movq	%r8, (%rdx)
	movq	%rdx, %r8
	testq	%rdi, %rdi
	jne	.LBB1_429
# %bb.430:
	movq	%rdx, %rdi
	cmpq	$1, %rsi
	jne	.LBB1_472
.LBB1_431:
	movq	$0, 5184(%r15)
	testq	%rdi, %rdi
	je	.LBB1_440
# %bb.432:
	movl	$2097152, %r12d                 # imm = 0x200000
	jmp	.LBB1_434
	.p2align	4
.LBB1_433:                              #   in Loop: Header=BB1_434 Depth=1
	subq	%rcx, 624(%r15)
	callq	free@PLT
	movq	%r13, %rdi
	testq	%r13, %r13
	je	.LBB1_439
.LBB1_434:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %r13
	movq	24(%rdi), %rax
	subq	%rax, 664(%r15)
	movq	24(%rdi), %rax
	addq	%rax, 728(%r15)
	vmovdqu	768(%r15), %xmm0
	vmovdqa	.LCPI1_0(%rip), %xmm1           # xmm1 = [1,u]
	vpinsrq	$1, 8(%rdi), %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 768(%r15)
	movq	688(%r15), %rax
	cmpq	$2097152, %rax                  # imm = 0x200000
	movl	$2097152, %ecx                  # imm = 0x200000
	cmovbq	%rax, %rcx
	testq	%rax, %rax
	movq	%rcx, %rax
	cmoveq	%r12, %rax
	cmpq	$0, 6240(%r15)
	cmoveq	%rcx, %rax
	movq	8(%rdi), %rcx
	cmpq	$1048576, %rcx                  # imm = 0x100000
	ja	.LBB1_433
# %bb.435:                              #   in Loop: Header=BB1_434 Depth=1
	movq	792(%r15), %rdx
	cmpq	$3, %rdx
	ja	.LBB1_433
# %bb.436:                              #   in Loop: Header=BB1_434 Depth=1
	movq	800(%r15), %rsi
	subq	%rsi, %rax
	jbe	.LBB1_433
# %bb.437:                              #   in Loop: Header=BB1_434 Depth=1
	cmpq	%rax, %rcx
	ja	.LBB1_433
# %bb.438:                              #   in Loop: Header=BB1_434 Depth=1
	movq	1848(%r15), %rax
	movq	%rax, (%rdi)
	movq	%rdi, 1848(%r15)
	incq	%rdx
	movq	%rdx, 792(%r15)
	addq	8(%rdi), %rsi
	movq	%rsi, 800(%r15)
	movq	%r13, %rdi
	testq	%r13, %r13
	jne	.LBB1_434
.LBB1_439:
	movq	6240(%r15), %r13
.LBB1_440:
	movl	$0, (%r14)
	movl	$1024, %edx                     # imm = 0x400
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	testq	%r13, %r13
	leaq	-14224(%rbp), %r14
	je	.LBB1_458
.LBB1_441:
	movq	248(%r13), %rbx
	movq	%r13, %r14
	movq	$0, 248(%r13)
	testq	%rbx, %rbx
	je	.LBB1_450
# %bb.442:
	vpxor	%xmm0, %xmm0, %xmm0
	jmp	.LBB1_444
	.p2align	4
.LBB1_443:                              #   in Loop: Header=BB1_444 Depth=1
	addq	$8, %rbx
	vmovdqu	%xmm0, (%rbx)
	movl	$0, 16(%rbx)
	movq	%r12, %rbx
	testq	%r12, %r12
	je	.LBB1_450
.LBB1_444:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_445 Depth 2
	movq	8(%rbx), %r12
	movq	16(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB1_443
	.p2align	4
.LBB1_445:                              #   Parent Loop BB1_444 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rsi), %r13
	movq	6240(%r15), %rax
	movq	264(%rax), %rcx
	cmpq	$32, %rcx
	je	.LBB1_449
# %bb.446:                              #   in Loop: Header=BB1_445 Depth=2
	movq	624(%r15), %rdx
	cmpq	$40, %rdx
	jb	.LBB1_372
# %bb.447:                              #   in Loop: Header=BB1_445 Depth=2
	movq	48(%rax), %rdi
	cmpq	$39, %rdi
	jbe	.LBB1_372
# %bb.448:                              #   in Loop: Header=BB1_445 Depth=2
	addq	$-40, %rdx
	movq	%rdx, 624(%r15)
	addq	$-40, %rdi
	movq	%rdi, 48(%rax)
	movq	256(%rax), %rdx
	movq	%rdx, (%rsi)
	movq	%rsi, 256(%rax)
	incq	%rcx
	movq	%rcx, 264(%rax)
	movq	%r13, %rsi
	testq	%r13, %r13
	jne	.LBB1_445
	jmp	.LBB1_443
.LBB1_449:                              #   in Loop: Header=BB1_445 Depth=2
	leaq	600(%r15), %rdi
	callq	entry_release
	vpxor	%xmm0, %xmm0, %xmm0
	movq	%r13, %rsi
	testq	%r13, %r13
	jne	.LBB1_445
	jmp	.LBB1_443
.LBB1_450:
	movl	$0, 292(%r14)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 192(%r14)
	movl	$0, 208(%r14)
	movq	24(%r14), %rax
	testq	%rax, %rax
	je	.LBB1_372
# %bb.451:
	leaq	600(%r15), %rdi
	callq	*%rax
	leaq	-14224(%rbp), %r14
	jmp	.LBB1_458
.LBB1_452:
	xorl	%ebx, %ebx
	movq	%r12, %rdi
	xorl	%esi, %esi
	callq	myl_rc_scope_unwind
	movq	%r12, %rdi
	callq	myl_native_arena_release
	movl	$0, (%r13)
	jmp	.LBB1_454
	.p2align	4
.LBB1_453:                              #   in Loop: Header=BB1_454 Depth=1
	incq	%rbx
	cmpq	$128, %rbx
	je	.LBB1_458
.LBB1_454:                              # =>This Inner Loop Header: Depth=1
	movq	808(%r15,%rbx,8), %rsi
	movq	$0, 808(%r15,%rbx,8)
	movq	%r12, %rdi
	callq	myl_rc_edge_release
	movq	6240(%r15), %rax
	testq	%rax, %rax
	je	.LBB1_453
# %bb.455:                              #   in Loop: Header=BB1_454 Depth=1
	cmpq	$0, 200(%rax)
	je	.LBB1_453
# %bb.456:                              #   in Loop: Header=BB1_454 Depth=1
	movq	%r12, %rdi
	callq	myl_rc_drain
	jmp	.LBB1_453
	.p2align	4
.LBB1_461:                              #   in Loop: Header=BB1_458 Depth=1
	movq	%rcx, 14792(%r15)
	testq	%rcx, %rcx
	je	.LBB1_457
.LBB1_462:                              #   in Loop: Header=BB1_458 Depth=1
	movq	%rax, (%rcx)
.LBB1_457:                              #   in Loop: Header=BB1_458 Depth=1
	callq	free@PLT
.LBB1_458:                              # =>This Inner Loop Header: Depth=1
	movq	14792(%r15), %rdi
	testq	%rdi, %rdi
	je	.LBB1_463
# %bb.459:                              #   in Loop: Header=BB1_458 Depth=1
	movq	(%rdi), %rax
	movq	8(%rdi), %rcx
	testq	%rax, %rax
	je	.LBB1_461
# %bb.460:                              #   in Loop: Header=BB1_458 Depth=1
	movq	%rcx, 8(%rax)
	testq	%rcx, %rcx
	jne	.LBB1_462
	jmp	.LBB1_457
.LBB1_463:
	movq	14760(%r15), %rdi
	callq	free@PLT
	movq	40(%r15), %rdi
	callq	free@PLT
	movq	32(%r15), %rbx
	movq	%r15, %rdi
	callq	free@PLT
	testq	%rbx, %rbx
	je	.LBB1_465
# %bb.464:
	movl	$2, %r15d
	cmpl	$0, -456(%rbp)
	jne	.LBB1_573
	jmp	.LBB1_478
.LBB1_465:
	movq	-1008(%rbp), %rbx
	cmpb	$0, -68(%rbp)                   # 1-byte Folded Reload
	jne	.LBB1_467
# %bb.466:
	movl	$.L.str.55, %edi
	movq	%rbx, %rsi
	xorl	%eax, %eax
	callq	printf@PLT
.LBB1_467:
	movzbl	%bl, %r15d
	jmp	.LBB1_573
.LBB1_468:
	movq	%r14, %rdi
	callq	free@PLT
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.3.174, %edi
	movl	$33, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	jmp	.LBB1_513
.LBB1_469:
	xorl	%edx, %edx
	movq	%rdx, %rdi
	cmpq	$1, %rsi
	jne	.LBB1_472
	jmp	.LBB1_431
	.p2align	4
.LBB1_470:                              #   in Loop: Header=BB1_472 Depth=1
	movq	%rdx, %rdi
.LBB1_471:                              #   in Loop: Header=BB1_472 Depth=1
	movq	%rdi, %rdx
	addq	$-2, %rcx
	je	.LBB1_431
.LBB1_472:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB1_473 Depth 2
                                        #     Child Loop BB1_475 Depth 2
	movq	-8(%rax,%rcx,8), %rsi
	movq	$0, -8(%rax,%rcx,8)
	testq	%rsi, %rsi
	je	.LBB1_474
	.p2align	4
.LBB1_473:                              #   Parent Loop BB1_472 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rsi), %rdi
	movq	%rdx, (%rsi)
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	testq	%rdi, %rdi
	jne	.LBB1_473
.LBB1_474:                              #   in Loop: Header=BB1_472 Depth=1
	movq	-16(%rax,%rcx,8), %rsi
	movq	$0, -16(%rax,%rcx,8)
	testq	%rsi, %rsi
	je	.LBB1_470
	.p2align	4
.LBB1_475:                              #   Parent Loop BB1_472 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rsi, %rdi
	movq	(%rsi), %rsi
	movq	%rdx, (%rdi)
	movq	%rdi, %rdx
	testq	%rsi, %rsi
	jne	.LBB1_475
	jmp	.LBB1_471
.LBB1_476:
	movl	$1, %r14d
	testl	%edx, %edx
	je	.LBB1_224
.LBB1_477:
	movq	%rcx, -992(%rbp)
.LBB1_478:
	leaq	-3568(%rbp), %rdi
	movl	$1024, %edx                     # imm = 0x400
	xorl	%esi, %esi
	callq	memset@PLT
	movq	$0, -2544(%rbp)
	movb	$0, -3568(%rbp)
	movl	-448(%rbp), %r12d
	testl	%r12d, %r12d
	je	.LBB1_526
# %bb.479:
	movl	-444(%rbp), %ebx
	testb	$1, %bl
	jne	.LBB1_485
# %bb.480:
	testb	$2, %bl
	jne	.LBB1_502
# %bb.481:
	movq	-400(%rbp), %r8
	testb	$28, %bl
	jne	.LBB1_504
# %bb.482:
	testq	%r8, %r8
	je	.LBB1_526
# %bb.483:
	cmpb	$0, (%r8)
	je	.LBB1_526
# %bb.484:
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.83, %ecx
	jmp	.LBB1_503
.LBB1_485:
	movq	-440(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.73, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
# %bb.486:
	testb	$2, %bl
	je	.LBB1_525
# %bb.487:
	movq	-432(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.74, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	jne	.LBB1_525
	jmp	.LBB1_526
.LBB1_488:
	movl	$1, %edi
	movl	$4664, %esi                     # imm = 0x1238
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB1_382
# %bb.489:
	movq	%r13, 624(%r15)
	movq	-48(%rbp), %r14                 # 8-byte Reload
	addq	$4664, 48(%r14)                 # imm = 0x1238
	movq	$myl_rc_generated_module, 8(%rax)
	movq	%rax, %rcx
	movq	myl_rc_generated_image@GOTPCREL(%rip), %rax
	movq	%rax, 56(%rcx)
	movq	$23, 32(%rcx)
	movq	$23, 40(%rcx)
	movq	$4664, 48(%rcx)                 # imm = 0x1238
	movq	%rcx, %rdi
	addq	$64, %rdi
	movq	%rdi, 24(%rcx)
	movl	$4600, %edx                     # imm = 0x11F8
	movq	%r12, %rsi
	movq	%rcx, %r12
	callq	memcpy@PLT
	xorl	%ecx, %ecx
	movl	$0, %eax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	cmpq	184(%r14), %rbx
	jbe	.LBB1_493
# %bb.490:
	movl	$24, %ecx
	movq	%rbx, %rax
	mulq	%rcx
	jo	.LBB1_569
# %bb.491:
	leaq	600(%r15), %rdi
	movq	%rax, %r13
	movq	%rax, %rsi
	callq	myl_rc_meta_alloc
	testq	%rax, %rax
	je	.LBB1_567
# %bb.492:
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	movq	%r13, %rcx
.LBB1_493:
	movq	%rcx, -48(%rbp)                 # 8-byte Spill
	leaq	-2544(%rbp), %r8
	movl	$1, %esi
	movl	$46, %edx
	leaq	600(%r15), %r14
	movq	%r14, %rdi
	movq	%r12, %rcx
	callq	index_prepare
	testl	%eax, %eax
	je	.LBB1_514
# %bb.494:
	leaq	-2544(%rbp), %rdx
	movq	%r14, %rdi
	movq	%r12, %r13
	movq	%r12, %rsi
	callq	index_commit
	movq	6240(%r15), %rax
	movq	-64(%rbp), %r12                 # 8-byte Reload
	testq	%r12, %r12
	je	.LBB1_496
# %bb.495:
	movq	176(%rax), %rsi
	movq	184(%rax), %rax
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rdx
	movq	%r14, %rdi
	callq	myl_rc_meta_free
	movq	6240(%r15), %rax
	movq	%r12, 176(%rax)
	movq	%rbx, 184(%rax)
.LBB1_496:
	movq	40(%rax), %rcx
	movq	%rcx, (%r13)
	movq	%r13, 40(%rax)
	movq	32(%r15), %rax
	testq	%rax, %rax
	jne	.LBB1_397
	jmp	.LBB1_386
.LBB1_497:
	leaq	-14224(%rbp), %r14
.LBB1_498:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.1.181, %edi
	movl	$56, %esi
.LBB1_499:
	movl	$1, %edx
	vzeroupper
	callq	fwrite@PLT
.LBB1_500:
	movl	$2, %r15d
	movl	$112, %ebx
	jmp	.LBB1_577
.LBB1_501:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.4.175, %edi
	movl	$49, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	jmp	.LBB1_512
.LBB1_502:
	movq	-432(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.76, %ecx
.LBB1_503:
	xorl	%eax, %eax
	callq	append
	jmp	.LBB1_526
.LBB1_504:
	testq	%r8, %r8
	movl	$.L.str.69, %eax
	cmovneq	%r8, %rax
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.77, %ecx
	movq	%rax, %r8
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
# %bb.505:
	testb	$32, %bl
	jne	.LBB1_518
# %bb.506:
	testb	$4, %bl
	je	.LBB1_508
# %bb.507:
	movq	-424(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.80, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
.LBB1_508:
	testb	$8, %bl
	je	.LBB1_523
# %bb.509:
	movq	-416(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.81, %ecx
	jmp	.LBB1_522
.LBB1_510:
	movl	$.L.str.5.180, %esi
.LBB1_511:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	%r15, %rdx
	xorl	%eax, %eax
	callq	fprintf@PLT
.LBB1_512:
	movq	%r14, %rdi
	callq	free@PLT
.LBB1_513:
	movq	-144(%rbp), %rdi                # 8-byte Reload
	callq	free@PLT
	movl	$2, %r15d
	jmp	.LBB1_586
.LBB1_514:
	movq	624(%r15), %r13
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	testq	%rdi, %rdi
	je	.LBB1_568
# %bb.515:
	movq	-48(%rbp), %rdx                 # 8-byte Reload
	subq	%rdx, %r13
	jb	.LBB1_372
# %bb.516:
	movq	6240(%r15), %rax
	movq	48(%rax), %rcx
	subq	%rdx, %rcx
	jb	.LBB1_372
# %bb.517:
	movq	%r13, 624(%r15)
	movq	%rcx, 48(%rax)
	callq	free@PLT
	jmp	.LBB1_568
.LBB1_518:
	testb	$4, %bl
	je	.LBB1_520
# %bb.519:
	movq	-424(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.78, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
.LBB1_520:
	testb	$8, %bl
	je	.LBB1_523
# %bb.521:
	movq	-416(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.79, %ecx
.LBB1_522:
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
.LBB1_523:
	testb	$16, %bl
	je	.LBB1_525
# %bb.524:
	movq	-408(%rbp), %r8
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.82, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_526
.LBB1_525:
	leaq	-3568(%rbp), %rdi
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.75, %ecx
	xorl	%eax, %eax
	callq	append
.LBB1_526:
	movq	-992(%rbp), %r14
	movl	$.L.str.20, %esi
	movq	%r14, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	sete	%al
	movq	-472(%rbp), %r15
	cmpq	$2, %r15
	setae	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	movl	%r12d, -56(%rbp)                # 4-byte Spill
	jne	.LBB1_528
# %bb.527:
	leaq	-3568(%rbp), %r13
	movq	%r13, %rdi
	callq	strlen@PLT
	movq	%rax, -2544(%rbp)
	movq	-952(%rbp), %r8
	movq	-944(%rbp), %r9
	vmovdqu	-936(%rbp), %xmm0
	vmovdqu	%xmm0, (%rsp)
	leaq	-2544(%rbp), %rdx
	movl	$1024, %esi                     # imm = 0x400
	movl	$.L.str.48, %ecx
	movq	%r13, %rdi
	xorl	%eax, %eax
	callq	append
	jmp	.LBB1_530
.LBB1_528:
	testq	%r15, %r15
	jne	.LBB1_530
# %bb.529:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %r12
	movq	%r14, %rdi
	callq	describe
	leaq	-3568(%rbp), %r8
	movl	$.L.str.50, %esi
	movq	%r12, %rdi
	movq	%r14, %rbx
	movq	%r14, %rdx
	movq	%rax, %rcx
	xorl	%eax, %eax
	callq	fprintf@PLT
	jmp	.LBB1_532
.LBB1_530:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %r13
	movq	-976(%rbp), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movq	-968(%rbp), %rax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	leaq	-960(%rbp), %r12
	movq	-960(%rbp), %rbx
	movq	%r14, %rdi
	callq	describe
	leaq	-3568(%rbp), %rcx
	movq	%rcx, 8(%rsp)
	movq	%rax, (%rsp)
	movl	$.L.str.49, %esi
	movq	%r13, %rdi
	movq	-48(%rbp), %rdx                 # 8-byte Reload
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	%rbx, %r8
	movq	%r14, %rbx
	movq	%r14, %r9
	movq	stderr@GOTPCREL(%rip), %r14
	xorl	%eax, %eax
	callq	fprintf@PLT
.LBB1_531:                              # =>This Inner Loop Header: Depth=1
	movq	-24(%r12), %rdx
	movq	-16(%r12), %rcx
	movq	-8(%r12), %r8
	movq	(%r12), %r9
	movq	(%r14), %rdi
	movl	$.L.str.51, %esi
	xorl	%eax, %eax
	callq	fprintf@PLT
	addq	$32, %r12
	decq	%r15
	jne	.LBB1_531
.LBB1_532:
	movq	$0, -80(%rbp)
	movb	$0, -2544(%rbp)
	movl	-56(%rbp), %r8d                 # 4-byte Reload
	testl	%r8d, %r8d
	je	.LBB1_565
# %bb.533:
	movl	-444(%rbp), %eax
	movl	%eax, -48(%rbp)                 # 4-byte Spill
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.94, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.534:
	movq	-400(%rbp), %r14
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.104, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.535:
	testq	%r14, %r14
	movl	$.L.str.60, %r13d
	cmovneq	%r14, %r13
	movzbl	(%r13), %eax
	testb	%al, %al
	je	.LBB1_545
# %bb.536:
	incq	%r13
	leaq	-2544(%rbp), %r15
	leaq	-80(%rbp), %r12
	.p2align	4
.LBB1_537:                              # =>This Inner Loop Header: Depth=1
	movzbl	%al, %r8d
	cmpb	$92, %r8b
	je	.LBB1_539
# %bb.538:                              #   in Loop: Header=BB1_537 Depth=1
	cmpl	$34, %r8d
	jne	.LBB1_542
.LBB1_539:                              #   in Loop: Header=BB1_537 Depth=1
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.105, %ecx
.LBB1_540:                              #   in Loop: Header=BB1_537 Depth=1
	movq	%r15, %rdi
	movq	%r12, %rdx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.541:                              #   in Loop: Header=BB1_537 Depth=1
	movzbl	(%r13), %eax
	incq	%r13
	testb	%al, %al
	jne	.LBB1_537
	jmp	.LBB1_545
.LBB1_542:                              #   in Loop: Header=BB1_537 Depth=1
	movl	$1536, %esi                     # imm = 0x600
	cmpb	$31, %r8b
	ja	.LBB1_544
# %bb.543:                              #   in Loop: Header=BB1_537 Depth=1
	movl	$.L.str.106, %ecx
	jmp	.LBB1_540
.LBB1_544:                              #   in Loop: Header=BB1_537 Depth=1
	movl	$.L.str.107, %ecx
	jmp	.LBB1_540
.LBB1_545:
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.104, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.546:
	testb	$1, -48(%rbp)                   # 1-byte Folded Reload
	je	.LBB1_548
# %bb.547:
	movq	-440(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.95, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_548:
	testb	$2, -48(%rbp)                   # 1-byte Folded Reload
	je	.LBB1_550
# %bb.549:
	movq	-432(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.96, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_550:
	movl	-48(%rbp), %eax                 # 4-byte Reload
	testb	$32, %al
	jne	.LBB1_555
# %bb.551:
	testb	$4, %al
	je	.LBB1_553
# %bb.552:
	movq	-424(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.100, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_553:
	testb	$8, -48(%rbp)                   # 1-byte Folded Reload
	je	.LBB1_561
# %bb.554:
	movq	-416(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.101, %ecx
	jmp	.LBB1_560
.LBB1_555:
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.97, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.556:
	testb	$4, -48(%rbp)                   # 1-byte Folded Reload
	je	.LBB1_558
# %bb.557:
	movq	-424(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.98, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_558:
	testb	$8, -48(%rbp)                   # 1-byte Folded Reload
	je	.LBB1_561
# %bb.559:
	movq	-416(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.99, %ecx
.LBB1_560:
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_561:
	testb	$16, -48(%rbp)                  # 1-byte Folded Reload
	je	.LBB1_563
# %bb.562:
	movq	-408(%rbp), %r8
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.102, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
.LBB1_563:
	leaq	-2544(%rbp), %rdi
	leaq	-80(%rbp), %rdx
	movl	$1536, %esi                     # imm = 0x600
	movl	$.L.str.103, %ecx
	xorl	%eax, %eax
	callq	append
	testl	%eax, %eax
	je	.LBB1_565
# %bb.564:
	cmpq	$0, -80(%rbp)
	jne	.LBB1_572
.LBB1_565:
	movl	$2, %r15d
	cmpb	$82, (%rbx)
	leaq	-14224(%rbp), %r14
	jne	.LBB1_573
.LBB1_566:
	xorl	%r15d, %r15d
	cmpb	$95, 1(%rbx)
	setne	%r15b
	incl	%r15d
	movl	$112, %ebx
	jmp	.LBB1_577
.LBB1_567:
	movq	624(%r15), %r13
.LBB1_568:
	cmpq	$4664, %r13                     # imm = 0x1238
	jb	.LBB1_372
.LBB1_569:
	movq	6240(%r15), %rax
	movq	48(%rax), %rcx
	cmpq	$4663, %rcx                     # imm = 0x1237
	jbe	.LBB1_372
# %bb.570:
	addq	$-4664, %r13                    # imm = 0xEDC8
	movq	%r13, 624(%r15)
	addq	$-4664, %rcx                    # imm = 0xEDC8
	movq	%rcx, 48(%rax)
	movq	%r12, %rdi
	callq	free@PLT
	jmp	.LBB1_382
.LBB1_571:
	movl	$.L.str.6, %esi
	jmp	.LBB1_511
.LBB1_572:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	leaq	-2544(%rbp), %rcx
	movl	$.L.str.52, %esi
	movl	$.L.str.53, %edx
	xorl	%eax, %eax
	callq	fprintf@PLT
	movl	$2, %r15d
	cmpb	$82, (%rbx)
	leaq	-14224(%rbp), %r14
	je	.LBB1_566
.LBB1_573:
	movl	$112, %ebx
	jmp	.LBB1_577
	.p2align	4
.LBB1_574:                              #   in Loop: Header=BB1_577 Depth=1
	vzeroupper
	callq	close@PLT
	movq	-14224(%rbp,%rbx), %rdi
.LBB1_575:                              #   in Loop: Header=BB1_577 Depth=1
	vzeroupper
	callq	free@PLT
	movl	$-1, -14232(%rbp,%rbx)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, -14228(%rbp,%rbx)
	movl	$0, -14196(%rbp,%rbx)
.LBB1_576:                              #   in Loop: Header=BB1_577 Depth=1
	addq	$40, %rbx
	cmpq	$10352, %rbx                    # imm = 0x2870
	je	.LBB1_579
.LBB1_577:                              # =>This Inner Loop Header: Depth=1
	movl	-14232(%rbp,%rbx), %edi
	testl	%edi, %edi
	jns	.LBB1_574
# %bb.578:                              #   in Loop: Header=BB1_577 Depth=1
	movq	-14224(%rbp,%rbx), %rdi
	testq	%rdi, %rdi
	jne	.LBB1_575
	jmp	.LBB1_576
.LBB1_579:
	cmpq	$0, -14128(%rbp)
	je	.LBB1_582
# %bb.580:
	xorl	%ebx, %ebx
	.p2align	4
.LBB1_581:                              # =>This Inner Loop Header: Depth=1
	movl	(%r14), %edi
	vzeroupper
	callq	close@PLT
	incq	%rbx
	addq	$12, %r14
	cmpq	-14128(%rbp), %rbx
	jb	.LBB1_581
.LBB1_582:
	movq	$0, -14128(%rbp)
	cmpq	$0, -3752(%rbp)
	je	.LBB1_585
# %bb.583:
	leaq	-3880(%rbp), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB1_584:                              # =>This Inner Loop Header: Depth=1
	movq	(%rbx), %rdi
	vzeroupper
	callq	free@PLT
	incq	%r14
	addq	$16, %rbx
	cmpq	-3752(%rbp), %r14
	jb	.LBB1_584
.LBB1_585:
	movq	-144(%rbp), %rdi                # 8-byte Reload
	vzeroupper
	callq	free@PLT
.LBB1_586:
	movl	%r15d, %eax
	addq	$14200, %rsp                    # imm = 0x3778
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
                                        # -- End function
	.section	.text.entry_run,"ax",@progbits
	.p2align	4                               # -- Begin function entry_run
	.type	entry_run,@function
entry_run:                              # @entry_run
.Lfunc_begin2:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$216, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	cmpq	$0, 14760(%rdi)
	je	.LBB2_1
# %bb.12:
	cmpq	$0, 32(%rbx)
	jne	.LBB2_13
	jmp	.LBB2_15
.LBB2_1:
	movl	$1, %edi
	movl	$64, %esi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB2_7
# %bb.2:
	movq	%rax, 14760(%rbx)
	movq	14712(%rbx), %rcx
	leaq	160(%rcx), %rdx
	testq	%rcx, %rcx
	movl	$qbe_empty_registry, %ecx
	cmovneq	%rdx, %rcx
	movq	%rcx, (%rax)
	cmpq	$0, 8(%rcx)
	je	.LBB2_4
# %bb.3:
	cmpq	$0, (%rcx)
	je	.LBB2_8
.LBB2_4:
	movq	16(%rcx), %rdx
	testq	%rdx, %rdx
	movl	$10000, %esi                    # imm = 0x2710
	cmovneq	%rdx, %rsi
	movq	%rsi, 24(%rax)
	movq	24(%rcx), %rdx
	testq	%rdx, %rdx
	movl	$1000000, %esi                  # imm = 0xF4240
	cmovneq	%rdx, %rsi
	movq	%rsi, 16(%rax)
	movq	32(%rcx), %rdx
	testq	%rdx, %rdx
	movl	$65536, %edi                    # imm = 0x10000
	cmovneq	%rdx, %rdi
	movq	%rdi, 32(%rax)
	movq	40(%rcx), %rsi
	testq	%rsi, %rsi
	movl	$64, %edx
	cmovneq	%rsi, %rdx
	movq	%rdx, 40(%rax)
	movq	48(%rcx), %r8
	testq	%r8, %r8
	movl	$1048576, %esi                  # imm = 0x100000
	cmovneq	%r8, %rsi
	movq	%rsi, 48(%rax)
	cmpq	$100000, %rdi                   # imm = 0x186A0
	ja	.LBB2_6
# %bb.5:
	cmpq	$129, %rdx
	setae	%dl
	cmpq	$67108865, %rsi                 # imm = 0x4000001
	setae	%sil
	orb	%dl, %sil
	cmpb	$1, %sil
	jne	.LBB2_9
.LBB2_6:
	movl	$.L.str.2, %esi
	jmp	.LBB2_11
.LBB2_7:
	movl	$.L.str.122, %esi
	jmp	.LBB2_11
.LBB2_8:
	movl	$.L.str.1, %esi
	jmp	.LBB2_11
.LBB2_9:
	cmpq	$0, 8(%rcx)
	je	.LBB2_14
# %bb.10:
	movl	$.L.str.3, %esi
.LBB2_11:
	movq	%rbx, %rdi
	callq	fail
	cmpq	$0, 32(%rbx)
	jne	.LBB2_13
.LBB2_15:
	movq	$0, -48(%rbp)
	movq	$0, -120(%rbp)
	movl	712(%rbx), %eax
	movl	%eax, -64(%rbp)                 # 4-byte Spill
	movl	$0, -56(%rbp)
	cmpq	$-1, 16(%rbx)
	je	.LBB2_17
# %bb.16:
	movl	$1, 14824(%rbx)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 14828(%rbx)
	vmovups	%ymm0, 14840(%rbx)
	movq	$.L.str.35, 14872(%rbx)
	movl	$.L.str.34, %esi
	movq	%rbx, %rdi
	vzeroupper
	.pseudoprobe	16001987874931207458 1 2 0 entry_run
	callq	fail
.LBB2_17:
	cmpq	$-1, 56(%rbx)
	je	.LBB2_21
# %bb.18:
	cmpq	$0, 32(%rbx)
	jne	.LBB2_20
# %bb.19:
	movl	$1, 14824(%rbx)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 14828(%rbx)
	vmovups	%ymm0, 14840(%rbx)
	movq	$.L.str.37, 14872(%rbx)
.LBB2_20:
	movl	$.L.str.36, %esi
	movq	%rbx, %rdi
	vzeroupper
	.pseudoprobe	16001987874931207458 1 2 0 entry_run
	callq	fail
.LBB2_21:
	cmpq	$0, 6240(%rbx)
	je	.LBB2_244
# %bb.22:
	leaq	600(%rbx), %r14
	movl	712(%rbx), %ecx
	movl	$myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda, %esi
	movl	$8, %edx
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 2 2 0 entry_run
	callq	rc_list_new
	testq	%rax, %rax
	je	.LBB2_244
# %bb.23:
	movq	%rax, %r12
	movabsq	$5764607523034234880, %rax      # imm = 0x5000000000000000
	movq	%r12, -80(%rbp)
	movq	%r12, -72(%rbp)
	movq	-16(%r12), %rcx
	leaq	1(%rax), %rdx
	testq	%rdx, %rcx
	je	.LBB2_34
# %bb.24:
	testq	%rax, %rcx
	je	.LBB2_35
.LBB2_25:
	movq	6240(%rbx), %rdi
	cmpq	$18, 160(%rdi)
	jb	.LBB2_230
# %bb.26:
	movq	152(%rdi), %rax
	cmpq	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, 272(%rax)
	jne	.LBB2_230
# %bb.27:
	movq	280(%rax), %r13
	testq	%r13, %r13
	je	.LBB2_231
.LBB2_28:
	movq	8(%r13), %r12
	cmpl	$1, 8(%r12)
	jne	.LBB2_43
# %bb.29:
	movq	$0, -112(%rbp)
	movq	6240(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB2_64
# %bb.30:
	movl	$3, %eax
	movl	-64(%rbp), %edx                 # 4-byte Reload
	cmpl	712(%rbx), %edx
	ja	.LBB2_31
# %bb.48:
	movq	-72(%rbp), %rax
	testq	%rax, %rax
	je	.LBB2_52
# %bb.49:
	movq	-16(%rax), %rdx
	testb	$2, %dl
	jne	.LBB2_52
# %bb.50:
	movabsq	$4611686018427387906, %rsi      # imm = 0x4000000000000002
	addq	$-2, %rsi
	testq	%rsi, %rdx
	sete	%sil
	movq	%rdx, %rdi
	shrq	$40, %rdi
	andl	$1048575, %edi                  # imm = 0xFFFFF
	cmpl	-64(%rbp), %edi                 # 4-byte Folded Reload
	setbe	%dil
	btq	$60, %rdx
	jb	.LBB2_62
# %bb.51:
	orb	%dil, %sil
	je	.LBB2_62
.LBB2_52:
	movq	%rax, -112(%rbp)
	movq	$0, -72(%rbp)
	cmpq	$0, 200(%rcx)
	je	.LBB2_54
# %bb.53:
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	myl_rc_drain
.LBB2_54:
	movq	-112(%rbp), %rax
	jmp	.LBB2_61
.LBB2_34:
	movq	$0, -72(%rbp)
	jmp	.LBB2_38
.LBB2_35:
	leaq	-72(%rbp), %rax
	leaq	-80(%rbp), %rcx
	movq	%rcx, %rdx
	subq	%rax, %rdx
	subq	%rcx, %rax
	cmovbq	%rdx, %rax
	testq	%rax, %rax
	je	.LBB2_25
# %bb.36:
	movq	%r12, -80(%rbp)
	movq	$0, -72(%rbp)
	jmp	.LBB2_37
.LBB2_43:
	movq	6240(%rbx), %rax
	cmpq	$0, 200(%rax)
	je	.LBB2_55
.LBB2_44:
	movq	%r12, -112(%rbp)
	leaq	-256(%rbp), %rdx
	movq	%rdx, -104(%rbp)
	movq	$0, -96(%rbp)
	movl	-64(%rbp), %r8d                 # 4-byte Reload
	movl	%r8d, -88(%rbp)
	movl	$0, -84(%rbp)
	leaq	-72(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r13, %rsi
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	flat_transfer
	testl	%eax, %eax
	jns	.LBB2_46
# %bb.45:
	leaq	-112(%rbp), %rsi
	leaq	-72(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rdx
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	transfer
.LBB2_46:
	testl	%eax, %eax
	je	.LBB2_60
.LBB2_47:
	movq	6240(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB2_64
.LBB2_31:
	xorl	%edx, %edx
	cmpl	$0, 292(%rcx)
	jne	.LBB2_33
# %bb.32:
	movl	%eax, 292(%rcx)
	jmp	.LBB2_33
.LBB2_55:
	leaq	-80(%rbp), %rdx
	leaq	-72(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r13, %rsi
	movl	-64(%rbp), %r8d                 # 4-byte Reload
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	flat_transfer
	testl	%eax, %eax
	js	.LBB2_44
# %bb.56:
	je	.LBB2_37
# %bb.57:
	movq	6240(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB2_64
# %bb.58:
	cmpl	$0, 292(%rcx)
	jne	.LBB2_235
# %bb.59:
	movl	%eax, 292(%rcx)
	jmp	.LBB2_235
.LBB2_60:
	movq	-256(%rbp), %rax
.LBB2_61:
	movq	%rax, -80(%rbp)
	movl	$1, %edx
.LBB2_33:
	testl	%edx, %edx
	je	.LBB2_235
.LBB2_37:
	movq	-80(%rbp), %r12
.LBB2_38:
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	movq	%r12, -48(%rbp)
	movl	$1, -56(%rbp)
	testq	%r12, %r12
	je	.LBB2_65
# %bb.39:
	testq	%rax, -16(%r12)
	jne	.LBB2_41
# %bb.40:
	cmpl	$2, -24(%r12)
	jb	.LBB2_66
.LBB2_41:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 5 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.42:
	movq	-48(%rbp), %r12
	jmp	.LBB2_66
.LBB2_65:
	xorl	%r12d, %r12d
.LBB2_66:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_69
# %bb.67:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 5 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_69
# %bb.68:
	movq	32(%r12), %rax
	movq	$0, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_70
.LBB2_69:
	movq	$0, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 5 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_245
.LBB2_70:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_75
# %bb.71:
	testq	%rax, -16(%r12)
	jne	.LBB2_73
# %bb.72:
	cmpl	$2, -24(%r12)
	jb	.LBB2_76
.LBB2_73:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 8 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.74:
	movq	-48(%rbp), %r12
	jmp	.LBB2_76
.LBB2_75:
	xorl	%r12d, %r12d
.LBB2_76:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_79
# %bb.77:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 8 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_79
# %bb.78:
	movq	32(%r12), %rax
	movq	$1, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_80
.LBB2_79:
	movq	$1, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 8 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_246
.LBB2_80:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_85
# %bb.81:
	testq	%rax, -16(%r12)
	jne	.LBB2_83
# %bb.82:
	cmpl	$2, -24(%r12)
	jb	.LBB2_86
.LBB2_83:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 11 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.84:
	movq	-48(%rbp), %r12
	jmp	.LBB2_86
.LBB2_85:
	xorl	%r12d, %r12d
.LBB2_86:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_89
# %bb.87:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 11 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_89
# %bb.88:
	movq	32(%r12), %rax
	movq	$2, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_90
.LBB2_89:
	movq	$2, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 11 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_247
.LBB2_90:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_95
# %bb.91:
	testq	%rax, -16(%r12)
	jne	.LBB2_93
# %bb.92:
	cmpl	$2, -24(%r12)
	jb	.LBB2_96
.LBB2_93:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 14 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.94:
	movq	-48(%rbp), %r12
	jmp	.LBB2_96
.LBB2_95:
	xorl	%r12d, %r12d
.LBB2_96:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_99
# %bb.97:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 14 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_99
# %bb.98:
	movq	32(%r12), %rax
	movq	$3, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_100
.LBB2_99:
	movq	$3, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 14 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_248
.LBB2_100:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_105
# %bb.101:
	testq	%rax, -16(%r12)
	jne	.LBB2_103
# %bb.102:
	cmpl	$2, -24(%r12)
	jb	.LBB2_106
.LBB2_103:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 17 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.104:
	movq	-48(%rbp), %r12
	jmp	.LBB2_106
.LBB2_105:
	xorl	%r12d, %r12d
.LBB2_106:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_109
# %bb.107:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 17 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_109
# %bb.108:
	movq	32(%r12), %rax
	movq	$4, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_110
.LBB2_109:
	movq	$4, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 17 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_249
.LBB2_110:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_115
# %bb.111:
	testq	%rax, -16(%r12)
	jne	.LBB2_113
# %bb.112:
	cmpl	$2, -24(%r12)
	jb	.LBB2_116
.LBB2_113:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 20 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.114:
	movq	-48(%rbp), %r12
	jmp	.LBB2_116
.LBB2_115:
	xorl	%r12d, %r12d
.LBB2_116:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_119
# %bb.117:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 20 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_119
# %bb.118:
	movq	32(%r12), %rax
	movq	$5, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_120
.LBB2_119:
	movq	$5, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 20 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_250
.LBB2_120:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_125
# %bb.121:
	testq	%rax, -16(%r12)
	jne	.LBB2_123
# %bb.122:
	cmpl	$2, -24(%r12)
	jb	.LBB2_126
.LBB2_123:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 23 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.124:
	movq	-48(%rbp), %r12
	jmp	.LBB2_126
.LBB2_125:
	xorl	%r12d, %r12d
.LBB2_126:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_129
# %bb.127:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 23 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_129
# %bb.128:
	movq	32(%r12), %rax
	movq	$6, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_130
.LBB2_129:
	movq	$6, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 23 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_251
.LBB2_130:
	testq	%r12, %r12
	movabsq	$6917529027641081858, %rax      # imm = 0x6000000000000002
	je	.LBB2_135
# %bb.131:
	testq	%rax, -16(%r12)
	jne	.LBB2_133
# %bb.132:
	cmpl	$2, -24(%r12)
	jb	.LBB2_136
.LBB2_133:
	leaq	-48(%rbp), %rsi
	leaq	-56(%rbp), %rdx
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 26 2 0 entry_run
	callq	myl_qbe_rc_unique_local
	testl	%eax, %eax
	je	.LBB2_13
# %bb.134:
	movq	-48(%rbp), %r12
	jmp	.LBB2_136
.LBB2_135:
	xorl	%r12d, %r12d
.LBB2_136:
	movq	(%r12), %r13
	movq	16(%r12), %r15
	cmpq	8(%r12), %r13
	setae	%al
	cmpq	$-1, %r15
	sete	%cl
	orb	%al, %cl
	jne	.LBB2_139
# %bb.137:
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 26 2 0 entry_run
	callq	myl_rc_list_plain_ready
	testl	%eax, %eax
	je	.LBB2_139
# %bb.138:
	movq	32(%r12), %rax
	movq	$7, (%rax,%r13,8)
	incq	%r13
	movq	%r13, (%r12)
	incq	%r15
	movq	%r15, 16(%r12)
	jmp	.LBB2_140
.LBB2_139:
	movq	$7, -112(%rbp)
	movq	(%r12), %rdx
	leaq	-112(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 26 2 0 entry_run
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB2_252
.LBB2_140:
	movabsq	$4611686018427387906, %r13      # imm = 0x4000000000000002
	movq	%r12, -72(%rbp)
	testq	%r12, %r12
	je	.LBB2_146
# %bb.141:
	movq	-16(%r12), %rax
	testq	%r13, %rax
	je	.LBB2_147
# %bb.142:
	leaq	-2(%r13), %rcx
	testq	%rcx, %rax
	je	.LBB2_149
# %bb.143:
	leaq	-80(%rbp), %rdx
	leaq	-72(%rbp), %rcx
	movl	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, %esi
	movq	%r14, %rdi
	movl	-64(%rbp), %r8d                 # 4-byte Reload
	.pseudoprobe	16001987874931207458 30 2 0 entry_run
	callq	myl_rc_native_retain
	testl	%eax, %eax
	je	.LBB2_157
# %bb.144:
	movq	-80(%rbp), %r15
	movq	%r15, -120(%rbp)
	cmpl	$0, -56(%rbp)
	je	.LBB2_161
# %bb.145:
	movl	$0, -56(%rbp)
	jmp	.LBB2_151
.LBB2_146:
	movq	%r12, -80(%rbp)
	movq	%r12, -120(%rbp)
	movl	-56(%rbp), %eax
	xorl	%ecx, %ecx
	testl	%eax, %eax
	cmovel	%eax, %ecx
	movl	%ecx, -56(%rbp)
	movq	%r12, %r15
	movq	(%r15), %r12
	testq	%r12, %r12
	jns	.LBB2_162
	jmp	.LBB2_229
.LBB2_14:
	movl	$1, 56(%rax)
	cmpq	$0, 32(%rbx)
	jne	.LBB2_13
	jmp	.LBB2_15
.LBB2_147:
	movl	-24(%r12), %eax
	cmpl	$-1, %eax
	je	.LBB2_159
# %bb.148:
	incl	%eax
	movl	%eax, -24(%r12)
.LBB2_149:
	movq	%r12, -80(%rbp)
	movq	%r12, -120(%rbp)
	cmpl	$0, -56(%rbp)
	je	.LBB2_156
# %bb.150:
	movl	$0, -56(%rbp)
	movq	%r12, %r15
	testq	%r12, %r12
	je	.LBB2_160
.LBB2_151:
	testq	%r13, -16(%r12)
	jne	.LBB2_155
# %bb.152:
	movl	-24(%r12), %eax
	cmpl	$1, %eax
	jne	.LBB2_154
# %bb.153:
	cmpl	$0, -20(%r12)
	je	.LBB2_228
.LBB2_154:
	decl	%eax
	movl	%eax, -24(%r12)
.LBB2_155:
	movq	$0, -48(%rbp)
	movq	(%r15), %r12
	testq	%r12, %r12
	jns	.LBB2_162
.LBB2_229:
	movq	%rbx, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 35 2 0 entry_run
	callq	myl_qbe_fail_cast
.LBB2_156:
	movq	%r12, %r15
	movq	(%r15), %r12
	testq	%r12, %r12
	jns	.LBB2_162
	jmp	.LBB2_229
.LBB2_62:
	movq	%r12, -256(%rbp)
	leaq	-112(%rbp), %rax
	movq	%rax, -248(%rbp)
	movq	$0, -240(%rbp)
	movl	-64(%rbp), %eax                 # 4-byte Reload
	movl	%eax, -232(%rbp)
	movl	$0, -228(%rbp)
	leaq	-256(%rbp), %rsi
	leaq	-72(%rbp), %rcx
	movq	%r14, %rdi
	movq	%r12, %rdx
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	transfer
	testl	%eax, %eax
	jne	.LBB2_47
	jmp	.LBB2_54
.LBB2_157:
	movq	6240(%rbx), %rax
	testq	%rax, %rax
	je	.LBB2_64
# %bb.158:
	movl	292(%rax), %esi
	movl	$0, 292(%rax)
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 30 2 0 entry_run
	callq	myl_qbe_rc_status
	jmp	.LBB2_13
.LBB2_159:
	movl	$.L.str.1.123, %esi
	jmp	.LBB2_241
.LBB2_160:
	movq	%r12, %r15
.LBB2_161:
	movq	(%r15), %r12
	testq	%r12, %r12
	js	.LBB2_229
.LBB2_162:
	movl	$1, %edi
	movl	$32, %esi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	calloc@PLT
	movq	%rax, %r13
	testq	%rax, %rax
	jne	.LBB2_164
# %bb.163:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_164:
	leaq	-256(%rbp), %rdi
	movl	$24, %esi
	movl	$.L.str.1.160, %edx
	movq	%r12, %rcx
	xorl	%eax, %eax
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	snprintf@PLT
	testl	%eax, %eax
	movq	%r13, -64(%rbp)                 # 8-byte Spill
	jle	.LBB2_193
# %bb.165:
	movl	%eax, %r12d
	movl	$64, %r15d
	cmpl	$65, %eax
	jb	.LBB2_190
# %bb.166:
	movl	$128, %r15d
	cmpl	$129, %r12d
	jb	.LBB2_190
# %bb.167:
	movl	$256, %r15d                     # imm = 0x100
	cmpl	$257, %r12d                     # imm = 0x101
	jb	.LBB2_190
# %bb.168:
	movl	$512, %r15d                     # imm = 0x200
	cmpl	$513, %r12d                     # imm = 0x201
	jb	.LBB2_190
# %bb.169:
	movl	$1024, %r15d                    # imm = 0x400
	cmpl	$1025, %r12d                    # imm = 0x401
	jb	.LBB2_190
# %bb.170:
	movl	$2048, %r15d                    # imm = 0x800
	cmpl	$2049, %r12d                    # imm = 0x801
	jb	.LBB2_190
# %bb.171:
	movl	$4096, %r15d                    # imm = 0x1000
	cmpl	$4097, %r12d                    # imm = 0x1001
	jb	.LBB2_190
# %bb.172:
	movl	$8192, %r15d                    # imm = 0x2000
	cmpl	$8193, %r12d                    # imm = 0x2001
	jb	.LBB2_190
# %bb.173:
	movl	$16384, %r15d                   # imm = 0x4000
	cmpl	$16385, %r12d                   # imm = 0x4001
	jb	.LBB2_190
# %bb.174:
	movl	$32768, %r15d                   # imm = 0x8000
	cmpl	$32769, %r12d                   # imm = 0x8001
	jb	.LBB2_190
# %bb.175:
	movl	$65536, %r15d                   # imm = 0x10000
	cmpl	$65537, %r12d                   # imm = 0x10001
	jb	.LBB2_190
# %bb.176:
	movl	$131072, %r15d                  # imm = 0x20000
	cmpl	$131073, %r12d                  # imm = 0x20001
	jb	.LBB2_190
# %bb.177:
	movl	$262144, %r15d                  # imm = 0x40000
	cmpl	$262145, %r12d                  # imm = 0x40001
	jb	.LBB2_190
# %bb.178:
	movl	$524288, %r15d                  # imm = 0x80000
	cmpl	$524289, %r12d                  # imm = 0x80001
	jb	.LBB2_190
# %bb.179:
	movl	$1048576, %r15d                 # imm = 0x100000
	cmpl	$1048577, %r12d                 # imm = 0x100001
	jb	.LBB2_190
# %bb.180:
	movl	$2097152, %r15d                 # imm = 0x200000
	cmpl	$2097153, %r12d                 # imm = 0x200001
	jb	.LBB2_190
# %bb.181:
	movl	$4194304, %r15d                 # imm = 0x400000
	cmpl	$4194305, %r12d                 # imm = 0x400001
	jb	.LBB2_190
# %bb.182:
	movl	$8388608, %r15d                 # imm = 0x800000
	cmpl	$8388609, %r12d                 # imm = 0x800001
	jb	.LBB2_190
# %bb.183:
	movl	$16777216, %r15d                # imm = 0x1000000
	cmpl	$16777217, %r12d                # imm = 0x1000001
	jb	.LBB2_190
# %bb.184:
	movl	$33554432, %r15d                # imm = 0x2000000
	cmpl	$33554433, %r12d                # imm = 0x2000001
	jb	.LBB2_190
# %bb.185:
	movl	$67108864, %r15d                # imm = 0x4000000
	cmpl	$67108865, %r12d                # imm = 0x4000001
	jb	.LBB2_190
# %bb.186:
	movl	$134217728, %r15d               # imm = 0x8000000
	cmpl	$134217729, %r12d               # imm = 0x8000001
	jb	.LBB2_190
# %bb.187:
	movl	$268435456, %r15d               # imm = 0x10000000
	cmpl	$268435457, %r12d               # imm = 0x10000001
	jb	.LBB2_190
# %bb.188:
	movl	$536870912, %r15d               # imm = 0x20000000
	cmpl	$536870913, %r12d               # imm = 0x20000001
	jb	.LBB2_190
# %bb.189:
	xorl	%r15d, %r15d
	cmpl	$1073741825, %r12d              # imm = 0x40000001
	setae	%r15b
	shll	$30, %r15d
	addq	$1073741824, %r15               # imm = 0x40000000
.LBB2_190:
	movq	%r15, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	malloc@PLT
	testq	%rax, %rax
	je	.LBB2_196
# %bb.191:
	movq	%rax, %r13
	movq	%r15, %r14
	movl	%r12d, %r12d
	movq	-64(%rbp), %r15                 # 8-byte Reload
	movq	%rax, (%r15)
	movq	%r14, 16(%r15)
	leaq	-256(%rbp), %rsi
	movq	%rax, %rdi
	movq	%r12, %rdx
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	memcpy@PLT
	leaq	8(%r15), %rcx
	movq	%r12, 8(%r15)
	addq	$24, %r15
	cmpq	%r12, %r14
	jne	.LBB2_198
# %bb.192:
	movq	%r14, %rax
	movq	%rcx, -128(%rbp)                # 8-byte Spill
	movq	%r14, %r12
	addq	%rax, %r12
	leaq	600(%rbx), %r14
	jmp	.LBB2_194
.LBB2_193:
	leaq	24(%r13), %r15
	addq	$8, %r13
	movq	%r13, -128(%rbp)                # 8-byte Spill
	movl	$64, %r12d
	xorl	%r13d, %r13d
.LBB2_194:
	movq	%r13, %rdi
	movq	%r12, %rsi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB2_197
# %bb.195:
	movq	%rax, %r13
	movq	-64(%rbp), %rax                 # 8-byte Reload
	movq	%r13, (%rax)
	movq	%r12, 16(%rax)
	movq	8(%rax), %r12
	movq	-128(%rbp), %rcx                # 8-byte Reload
	jmp	.LBB2_199
.LBB2_196:
	movq	-64(%rbp), %r13                 # 8-byte Reload
	movq	%r13, %r15
	addq	$24, %r15
	movl	$1, 24(%r13)
	jmp	.LBB2_201
.LBB2_197:
	movl	$1, (%r15)
	jmp	.LBB2_200
.LBB2_198:
	leaq	600(%rbx), %r14
.LBB2_199:
	movb	$10, (%r13,%r12)
	incq	(%rcx)
.LBB2_200:
	movq	-64(%rbp), %r13                 # 8-byte Reload
.LBB2_201:
	cmpl	$0, 28(%r13)
	movabsq	$4611686018427387906, %r12      # imm = 0x4000000000000002
	je	.LBB2_204
# %bb.202:
	movl	$.L.str.1.168, %esi
.LBB2_203:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	fail
	jmp	.LBB2_206
.LBB2_204:
	cmpl	$0, (%r15)
	je	.LBB2_221
# %bb.205:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_206:
	movq	(%r13), %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	free@PLT
	movq	%r13, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	free@PLT
	cmpb	$1, exit_without_sweep(%rip)
	jne	.LBB2_210
# %bb.207:
	cmpl	$0, 704(%rbx)
	jne	.LBB2_210
# %bb.208:
	cmpq	$0, 14736(%rbx)
	jne	.LBB2_210
# %bb.209:
	cmpq	$0, 14744(%rbx)
	je	.LBB2_13
.LBB2_210:
	movq	-120(%rbp), %rax
	testq	%rax, %rax
	je	.LBB2_215
# %bb.211:
	testq	%r12, -16(%rax)
	jne	.LBB2_215
# %bb.212:
	movl	-24(%rax), %ecx
	cmpl	$1, %ecx
	jne	.LBB2_214
# %bb.213:
	cmpl	$0, -20(%rax)
	je	.LBB2_226
.LBB2_214:
	decl	%ecx
	movl	%ecx, -24(%rax)
.LBB2_215:
	cmpl	$0, -56(%rbp)
	je	.LBB2_13
.LBB2_216:
	movq	-48(%rbp), %rax
	testq	%rax, %rax
	je	.LBB2_13
# %bb.217:
	testq	%r12, -16(%rax)
	jne	.LBB2_13
# %bb.218:
	movl	-24(%rax), %ecx
	cmpl	$1, %ecx
	jne	.LBB2_220
# %bb.219:
	cmpl	$0, -20(%rax)
	je	.LBB2_227
.LBB2_220:
	decl	%ecx
	movl	%ecx, -24(%rax)
	jmp	.LBB2_13
.LBB2_221:
	movq	stdout@GOTPCREL(%rip), %rax
	movq	(%rax), %r12
	movq	%r13, %r15
	movq	8(%r13), %r13
	testq	%r13, %r13
	je	.LBB2_223
# %bb.222:
	movq	(%r15), %rdi
	movl	$1, %esi
	movq	%r13, %rdx
	movq	%r12, %rcx
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	fwrite@PLT
	cmpq	%r13, %rax
	jne	.LBB2_225
.LBB2_223:
	movq	%r12, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	fflush@PLT
	testl	%eax, %eax
	movabsq	$4611686018427387906, %r12      # imm = 0x4000000000000002
	movq	%r15, %r13
	je	.LBB2_206
# %bb.224:
	movl	$.L.str.2.169, %esi
	jmp	.LBB2_203
.LBB2_225:
	movl	$.L.str.2.169, %esi
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 36 2 0 entry_run
	callq	fail
	movabsq	$4611686018427387906, %r12      # imm = 0x4000000000000002
	movq	%r15, %r13
	jmp	.LBB2_206
.LBB2_226:
	leaq	-120(%rbp), %rsi
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 39 2 0 entry_run
	callq	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	cmpl	$0, -56(%rbp)
	jne	.LBB2_216
	jmp	.LBB2_13
.LBB2_227:
	leaq	-48(%rbp), %rsi
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 39 2 0 entry_run
	callq	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	jmp	.LBB2_13
.LBB2_228:
	leaq	-48(%rbp), %rsi
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 30 2 0 entry_run
	callq	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	movq	(%r15), %r12
	testq	%r12, %r12
	jns	.LBB2_162
	jmp	.LBB2_229
.LBB2_230:
	movl	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, %esi
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	myl_rc_binding_find_slow
	movq	%rax, %r13
	testq	%r13, %r13
	jne	.LBB2_28
.LBB2_231:
	movl	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, %esi
	movq	%r14, %rdi
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	myl_rc_native_shape
	testq	%rax, %rax
	je	.LBB2_235
# %bb.232:
	movq	6240(%rbx), %rdi
	cmpq	$18, 160(%rdi)
	jb	.LBB2_242
# %bb.233:
	movq	152(%rdi), %rax
	cmpq	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, 272(%rax)
	jne	.LBB2_242
# %bb.234:
	movq	280(%rax), %r13
	testq	%r13, %r13
	jne	.LBB2_28
.LBB2_235:
	movq	6240(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB2_64
# %bb.236:
	movl	292(%rcx), %eax
	movl	$0, 292(%rcx)
	testq	%rax, %rax
	je	.LBB2_13
# %bb.237:
	cmpl	$1, %eax
	jne	.LBB2_239
# %bb.238:
	movl	$.L.str.17, %esi
	cmpl	$0, 708(%rbx)
	jne	.LBB2_241
	jmp	.LBB2_240
.LBB2_239:
	cmpl	$4, %eax
	jae	.LBB2_243
.LBB2_240:
	movq	.Lswitch.table.myl_rc_status_code(,%rax,8), %rsi
.LBB2_241:
	movq	%rbx, %rdi
	callq	fail
.LBB2_13:
	xorl	%eax, %eax
	addq	$216, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB2_242:
	.cfi_def_cfa %rbp, 16
	movl	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, %esi
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	myl_rc_binding_find_slow
	movq	%rax, %r13
	testq	%r13, %r13
	jne	.LBB2_28
	jmp	.LBB2_235
.LBB2_64:
	callq	myl_rc_invariant_failed
.LBB2_243:
	.pseudoprobe	16001987874931207458 3 2 0 entry_run
	callq	abort@PLT
.LBB2_244:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 2 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_245:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 5 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_246:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 8 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_247:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 11 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_248:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 14 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_249:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 17 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_250:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 20 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_251:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 23 2 0 entry_run
	callq	myl_qbe_fail_allocation
.LBB2_252:
	movq	%rbx, %rdi
	.pseudoprobe	16001987874931207458 26 2 0 entry_run
	callq	myl_qbe_fail_allocation
.Lfunc_end2:
	.size	entry_run, .Lfunc_end2-entry_run
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_rc_status,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_rc_status
	.type	myl_qbe_rc_status,@function
myl_qbe_rc_status:                      # @myl_qbe_rc_status
.Lfunc_begin3:
	.cfi_startproc
# %bb.0:
	testl	%esi, %esi
	je	.LBB3_6
# %bb.1:
	cmpl	$1, %esi
	jne	.LBB3_3
# %bb.2:
	movl	$.L.str.17, %eax
	cmpl	$0, 708(%rdi)
	je	.LBB3_4
# %bb.5:
	movq	%rax, %rsi
	jmp	fail                            # TAILCALL
.LBB3_6:
	retq
.LBB3_3:
	cmpl	$4, %esi
	jae	.LBB3_7
.LBB3_4:
	movl	%esi, %eax
	movq	.Lswitch.table.myl_rc_status_code(,%rax,8), %rax
	movq	%rax, %rsi
	jmp	fail                            # TAILCALL
.LBB3_7:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	abort@PLT
.Lfunc_end3:
	.size	myl_qbe_rc_status, .Lfunc_end3-myl_qbe_rc_status
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_rc_trap,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_rc_trap
	.type	myl_qbe_rc_trap,@function
myl_qbe_rc_trap:                        # @myl_qbe_rc_trap
.Lfunc_begin4:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	6240(%rdi), %rax
	testq	%rax, %rax
	je	.LBB4_11
# %bb.1:
	movq	248(%rax), %r14
	movq	$0, 248(%rax)
	testq	%r14, %r14
	je	.LBB4_11
# %bb.2:
	vxorps	%xmm0, %xmm0, %xmm0
	leaq	600(%rdi), %rbx
	jmp	.LBB4_3
	.p2align	4
.LBB4_10:                               #   in Loop: Header=BB4_3 Depth=1
	addq	$8, %r14
	vmovups	%xmm0, (%r14)
	movl	$0, 16(%r14)
	movq	%r15, %r14
	testq	%r15, %r15
	je	.LBB4_11
.LBB4_3:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_4 Depth 2
	movq	8(%r14), %r15
	movq	16(%r14), %rsi
	testq	%rsi, %rsi
	je	.LBB4_10
	.p2align	4
.LBB4_4:                                #   Parent Loop BB4_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rsi), %r12
	movq	6240(%rdi), %rax
	movq	264(%rax), %rcx
	cmpq	$32, %rcx
	je	.LBB4_5
# %bb.6:                                #   in Loop: Header=BB4_4 Depth=2
	movq	624(%rdi), %rdx
	cmpq	$40, %rdx
	jb	.LBB4_12
# %bb.7:                                #   in Loop: Header=BB4_4 Depth=2
	movq	48(%rax), %r8
	cmpq	$39, %r8
	jbe	.LBB4_12
# %bb.8:                                #   in Loop: Header=BB4_4 Depth=2
	addq	$-40, %rdx
	movq	%rdx, 624(%rdi)
	addq	$-40, %r8
	movq	%r8, 48(%rax)
	movq	256(%rax), %rdx
	movq	%rdx, (%rsi)
	movq	%rsi, 256(%rax)
	incq	%rcx
	movq	%rcx, 264(%rax)
	movq	%r12, %rsi
	testq	%r12, %r12
	jne	.LBB4_4
	jmp	.LBB4_10
.LBB4_5:                                #   in Loop: Header=BB4_4 Depth=2
	movq	%rdi, %r13
	movq	%rbx, %rdi
	callq	entry_release
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%r13, %rdi
	movq	%r12, %rsi
	testq	%r12, %r12
	jne	.LBB4_4
	jmp	.LBB4_10
.LBB4_11:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB4_12:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end4:
	.size	myl_qbe_rc_trap, .Lfunc_end4-myl_qbe_rc_trap
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_rc_unique_local,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_rc_unique_local
	.type	myl_qbe_rc_unique_local,@function
myl_qbe_rc_unique_local:                # @myl_qbe_rc_unique_local
.Lfunc_begin5:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rsi), %rcx
	movl	$1, %eax
	testq	%rcx, %rcx
	je	.LBB5_55
# %bb.1:
	movabsq	$2305843009213693954, %r9       # imm = 0x2000000000000002
	movq	-16(%rcx), %r8
	testq	%r9, %r8
	je	.LBB5_16
.LBB5_2:
	movq	6240(%rdi), %rcx
	cmpq	$18, 160(%rcx)
	jb	.LBB5_58
# %bb.3:
	movq	152(%rcx), %r8
	cmpq	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, 272(%r8)
	jne	.LBB5_58
# %bb.4:
	movq	280(%r8), %rcx
	testq	%rcx, %rcx
	je	.LBB5_45
.LBB5_5:
	movq	8(%rcx), %rcx
	cmpl	$1, 8(%rcx)
	jne	.LBB5_45
# %bb.6:
	movq	(%rsi), %rbx
	testq	%rbx, %rbx
	je	.LBB5_21
# %bb.7:
	movq	-16(%rbx), %r10
	movq	%r10, %r11
	shrq	$40, %r11
	andl	$1048575, %r11d                 # imm = 0xFFFFF
	xorl	%r8d, %r8d
	btq	$62, %r10
	cmovbl	%r11d, %r8d
	leaq	600(%rdi), %r14
	cmpl	$0, (%rdx)
	movq	(%rcx), %rcx
	je	.LBB5_22
.LBB5_8:
	cmpq	$8, %rcx
	jne	.LBB5_45
# %bb.9:
	testq	%rbx, %rbx
	je	.LBB5_55
# %bb.10:
	movq	-16(%rbx), %rcx
	movabsq	$6917529027641081858, %rdx      # imm = 0x6000000000000002
	testq	%rdx, %rcx
	jne	.LBB5_12
# %bb.11:
	cmpq	$0, 6240(%rdi)
	je	.LBB5_45
.LBB5_12:
	testq	%r9, %rcx
	je	.LBB5_31
.LBB5_13:
	movq	%rsi, %r12
	movq	%rdi, %r15
	movq	$0, -48(%rbp)
	leaq	-48(%rbp), %rcx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movl	%r8d, %edx
	callq	clone_payload
	testl	%eax, %eax
	je	.LBB5_35
# %bb.14:
	cmpl	$1, %eax
	jne	.LBB5_46
# %bb.15:
	movl	$.L.str.17, %esi
	movq	%r15, %rdi
	cmpl	$0, 708(%r15)
	jne	.LBB5_54
	jmp	.LBB5_47
.LBB5_16:
	btq	$62, %r8
	jb	.LBB5_55
# %bb.17:
	testb	$1, %r8b
	jne	.LBB5_45
# %bb.18:
	movl	-24(%rcx), %r8d
	cmpl	$1, %r8d
	je	.LBB5_39
# %bb.19:
	testl	%r8d, %r8d
	jne	.LBB5_2
# %bb.20:
	cmpl	$0, -20(%rcx)
	jne	.LBB5_55
	jmp	.LBB5_45
.LBB5_21:
	xorl	%r8d, %r8d
	leaq	600(%rdi), %r14
	cmpl	$0, (%rdx)
	movq	(%rcx), %rcx
	jne	.LBB5_8
.LBB5_22:
	cmpq	$8, %rcx
	jne	.LBB5_45
# %bb.23:
	testq	%rbx, %rbx
	je	.LBB5_55
# %bb.24:
	movq	-16(%rbx), %rcx
	movabsq	$6917529027641081858, %r10      # imm = 0x6000000000000002
	testq	%r10, %rcx
	jne	.LBB5_26
# %bb.25:
	cmpq	$0, 6240(%rdi)
	je	.LBB5_45
.LBB5_26:
	testq	%r9, %rcx
	je	.LBB5_40
.LBB5_27:
	movq	%rdx, %r12
	movq	%rsi, %r13
	movq	%rdi, %r15
	movq	$0, -48(%rbp)
	leaq	-48(%rbp), %rcx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movl	%r8d, %edx
	callq	clone_payload
	movl	%eax, %ecx
	xorl	%edx, %edx
	testl	%eax, %eax
	jne	.LBB5_29
# %bb.28:
	movq	-48(%rbp), %rdx
.LBB5_29:
	movl	$1, %eax
	jne	.LBB5_48
# %bb.30:
	movq	%rdx, (%r13)
	movl	$1, (%r12)
	jmp	.LBB5_55
.LBB5_31:
	btq	$62, %rcx
	jb	.LBB5_55
# %bb.32:
	testb	$1, %cl
	jne	.LBB5_45
# %bb.33:
	movl	-24(%rbx), %ecx
	cmpl	$1, %ecx
	je	.LBB5_57
# %bb.34:
	testl	%ecx, %ecx
	je	.LBB5_44
	jmp	.LBB5_13
.LBB5_35:
	movq	-48(%rbp), %rax
	movq	%rax, (%r12)
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	myl_rc_edge_release
	movq	6240(%r15), %rax
	testq	%rax, %rax
	je	.LBB5_38
# %bb.36:
	cmpq	$0, 200(%rax)
	je	.LBB5_38
# %bb.37:
	movq	%r14, %rdi
	callq	myl_rc_drain
.LBB5_38:
	movl	$1, %eax
	jmp	.LBB5_55
.LBB5_39:
	movl	%r8d, %eax
	jmp	.LBB5_55
.LBB5_40:
	btq	$62, %rcx
	jb	.LBB5_55
# %bb.41:
	testb	$1, %cl
	jne	.LBB5_45
# %bb.42:
	movl	-24(%rbx), %ecx
	cmpl	$1, %ecx
	je	.LBB5_57
# %bb.43:
	testl	%ecx, %ecx
	jne	.LBB5_27
.LBB5_44:
	cmpl	$0, -20(%rbx)
	jne	.LBB5_55
.LBB5_45:
	callq	myl_rc_invariant_failed
.LBB5_46:
	cmpl	$4, %eax
	movq	%r15, %rdi
	jae	.LBB5_59
.LBB5_47:
	movl	%eax, %eax
	jmp	.LBB5_53
.LBB5_48:
	testl	%ecx, %ecx
	je	.LBB5_55
# %bb.49:
	movq	%r15, %rdi
	cmpl	$1, %ecx
	jne	.LBB5_51
# %bb.50:
	movl	$.L.str.17, %esi
	cmpl	$0, 708(%rdi)
	jne	.LBB5_54
	jmp	.LBB5_52
.LBB5_57:
	movl	%ecx, %eax
	jmp	.LBB5_55
.LBB5_51:
	cmpl	$4, %ecx
	jae	.LBB5_59
.LBB5_52:
	movl	%ecx, %eax
.LBB5_53:
	movq	.Lswitch.table.myl_rc_status_code(,%rax,8), %rsi
.LBB5_54:
	callq	fail
	xorl	%eax, %eax
.LBB5_55:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB5_58:
	.cfi_def_cfa %rbp, 16
	movq	%rsi, %r8
	movl	$myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, %esi
	movq	%rdi, %r10
	movq	%rcx, %rdi
	callq	myl_rc_binding_find_slow
	movq	%r8, %rsi
	movq	%r10, %rdi
	movq	%rax, %rcx
	movl	$1, %eax
	testq	%rcx, %rcx
	jne	.LBB5_5
	jmp	.LBB5_45
.LBB5_59:
	callq	abort@PLT
.Lfunc_end5:
	.size	myl_qbe_rc_unique_local, .Lfunc_end5-myl_qbe_rc_unique_local
	.cfi_endproc
                                        # -- End function
	.section	.text.fail,"ax",@progbits
	.p2align	4                               # -- Begin function fail
	.type	fail,@function
fail:                                   # @fail
.Lfunc_begin6:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$0, 32(%rdi)
	jne	.LBB6_7
# %bb.1:
	movq	%rdi, %rbx
	movq	%rsi, 32(%rdi)
	movq	$0, -32(%rbp)
	movq	48(%rdi), %r15
	testq	%r15, %r15
	je	.LBB6_5
# %bb.2:
	leaq	-32(%rbp), %r14
	.p2align	4
.LBB6_3:                                # =>This Inner Loop Header: Depth=1
	movq	8(%r15), %rsi
	movq	16(%r15), %rdx
	movq	%rbx, %rdi
	xorl	%ecx, %ecx
	movq	%r14, %r8
	callq	trace_frame
	movq	(%r15), %r15
	testq	%r15, %r15
	jne	.LBB6_3
# %bb.4:
	cmpq	$0, 48(%rbx)
	jne	.LBB6_6
.LBB6_5:
	leaq	-32(%rbp), %rsi
	movq	%rbx, %rdi
	callq	walk_frames
.LBB6_6:
	movq	-32(%rbp), %rax
	xorl	%ecx, %ecx
	subq	584(%rbx), %rax
	cmovaeq	%rax, %rcx
	movq	%rcx, 592(%rbx)
	cmpq	$0, 15968(%rbx)
	jne	.LBB6_8
.LBB6_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB6_8:
	.cfi_def_cfa %rbp, 16
	movq	%rbx, %rdi
	callq	myl_qbe_rc_trap
	movq	15968(%rbx), %rdi
	movl	$1, %esi
	callq	longjmp@PLT
.Lfunc_end6:
	.size	fail, .Lfunc_end6-fail
	.cfi_endproc
                                        # -- End function
	.section	.text.trace_frame,"ax",@progbits
	.p2align	4                               # -- Begin function trace_frame
	.type	trace_frame,@function
trace_frame:                            # @trace_frame
.Lfunc_begin7:
	.cfi_startproc
# %bb.0:
	testq	%rsi, %rsi
	je	.LBB7_2
# %bb.1:
	cmpq	16(%rsi), %rdx
	jae	.LBB7_2
# %bb.4:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpl	$31, %ecx
	ja	.LBB7_11
# %bb.5:
	movq	32(%rsi), %r15
	testq	%r15, %r15
	je	.LBB7_11
# %bb.6:
	movq	40(%rsi), %rax
	testq	%rax, %rax
	jne	.LBB7_7
.LBB7_11:
	incq	(%r8)
	cmpq	16(%rsi), %rdx
	jae	.LBB7_17
# %bb.12:
	movq	584(%rdi), %rax
	cmpq	$15, %rax
	ja	.LBB7_17
# %bb.13:
	movq	(%rsi), %rcx
	movq	8(%rsi), %rsi
	leaq	(%rdx,%rdx,2), %rdx
	movq	(%rsi,%rdx,8), %r8
	leaq	1(%rax), %r9
	shlq	$5, %rax
	movq	%rcx, 72(%rdi,%rax)
	movq	%r8, 80(%rdi,%rax)
	vmovups	8(%rsi,%rdx,8), %xmm0
	movq	%r9, 584(%rdi)
	vmovups	%xmm0, 88(%rdi,%rax)
.LBB7_17:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
	retq
	.p2align	4
.LBB7_9:                                #   in Loop: Header=BB7_7 Depth=1
	.cfi_def_cfa %rbp, 16
	.cfi_offset %rbx, -48
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	addq	$40, %r15
	decq	%rax
	je	.LBB7_11
.LBB7_7:                                # =>This Inner Loop Header: Depth=1
	movq	8(%r15), %r9
	cmpq	%r9, %rdx
	jb	.LBB7_9
# %bb.8:                                #   in Loop: Header=BB7_7 Depth=1
	cmpq	16(%r15), %rdx
	jae	.LBB7_9
# %bb.10:
	movq	(%r15), %rax
	testq	%rax, %rax
	je	.LBB7_11
# %bb.14:
	addq	24(%r15), %rdx
	subq	%r9, %rdx
	incl	%ecx
	movq	%rdi, %rbx
	movq	%rsi, %r12
	movq	%rax, %rsi
	movq	%r8, %r14
	callq	trace_frame
	movq	32(%r15), %rdx
	incq	(%r14)
	cmpq	16(%r12), %rdx
	jae	.LBB7_17
# %bb.15:
	movq	584(%rbx), %rax
	cmpq	$15, %rax
	ja	.LBB7_17
# %bb.16:
	movq	(%r12), %rsi
	movq	8(%r12), %rcx
	leaq	(%rdx,%rdx,2), %rdx
	movq	(%rcx,%rdx,8), %rdi
	leaq	1(%rax), %r8
	shlq	$5, %rax
	movq	%rsi, 72(%rbx,%rax)
	movq	%rdi, 80(%rbx,%rax)
	vmovups	8(%rcx,%rdx,8), %xmm0
	movq	%r8, 584(%rbx)
	vmovups	%xmm0, 88(%rbx,%rax)
	jmp	.LBB7_17
.LBB7_2:
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %rbp
	.cfi_restore %r12
	.cfi_restore %r14
	.cfi_restore %r15
	incq	(%r8)
	retq
.Lfunc_end7:
	.size	trace_frame, .Lfunc_end7-trace_frame
	.cfi_endproc
                                        # -- End function
	.section	.text.trace_visit,"ax",@progbits
	.p2align	4                               # -- Begin function trace_visit
	.type	trace_visit,@function
trace_visit:                            # @trace_visit
.Lfunc_begin8:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rcx, %r8
	xorl	%ecx, %ecx
	callq	trace_frame
	movl	$1, %eax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end8:
	.size	trace_visit, .Lfunc_end8-trace_visit
	.cfi_endproc
                                        # -- End function
	.section	.text.walk_frames,"ax",@progbits
	.p2align	4                               # -- Begin function walk_frames
	.type	walk_frames,@function
walk_frames:                            # @walk_frames
.Lfunc_begin9:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	movq	14784(%rdi), %r15
	movq	15976(%rdi), %r12
	testq	%r15, %r15
	setne	%al
	cmpq	%r15, %r12
	seta	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB9_13
# %bb.1:
	movq	__stop_mylang_frame_map@GOTPCREL(%rip), %rax
	movq	%rax, %rcx
	subq	__start_mylang_frame_map@GOTPCREL(%rip), %rcx
	cmpq	$9, %rcx
	jb	.LBB9_13
# %bb.2:
	cmpq	$0, __start_mylang_frame_map@GOTPCREL(%rip)
	je	.LBB9_13
# %bb.3:
	cmpq	__start_mylang_frame_map@GOTPCREL(%rip), %rax
	jbe	.LBB9_13
# %bb.4:
	movq	%rdi, %r14
	movq	__start_mylang_frame_map@GOTPCREL(%rip), %rax
	testb	$32, 7(%rax)
	jne	.LBB9_5
# %bb.7:
	movq	%rbp, %r13
	addq	$-16, %r12
	.p2align	4
.LBB9_8:                                # =>This Inner Loop Header: Depth=1
	cmpq	%r15, %r13
	jb	.LBB9_13
# %bb.9:                                #   in Loop: Header=BB9_8 Depth=1
	cmpq	%r12, %r13
	ja	.LBB9_13
# %bb.10:                               #   in Loop: Header=BB9_8 Depth=1
	movl	%r13d, %eax
	andl	$7, %eax
	jne	.LBB9_13
# %bb.11:                               #   in Loop: Header=BB9_8 Depth=1
	movq	(%r13), %rbx
	movq	8(%r13), %rsi
	movl	$trace_visit, %edx
	movq	%r14, %rdi
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	callq	visit_return
	cmpq	%r13, %rbx
	movq	%r13, %rcx
	cmovaq	%rbx, %rcx
	testl	%eax, %eax
	cmoveq	%r13, %rcx
	je	.LBB9_13
# %bb.12:                               #   in Loop: Header=BB9_8 Depth=1
	cmpq	%r13, %rbx
	movq	%rcx, %r13
	ja	.LBB9_8
	jmp	.LBB9_13
.LBB9_5:
	movq	%r14, -80(%rbp)
	movq	$trace_visit, -72(%rbp)
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	%rax, -64(%rbp)
	movq	$0, -56(%rbp)
	cmpq	$0, _Unwind_Backtrace@GOTPCREL(%rip)
	sete	%al
	cmpq	$0, _Unwind_GetIP@GOTPCREL(%rip)
	sete	%cl
	orb	%al, %cl
	jne	.LBB9_13
# %bb.6:
	leaq	-80(%rbp), %rsi
	movl	$unwind_step, %edi
	callq	_Unwind_Backtrace@PLT
.LBB9_13:
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end9:
	.size	walk_frames, .Lfunc_end9-walk_frames
	.cfi_endproc
                                        # -- End function
	.section	.text.unwind_step,"ax",@progbits
	.p2align	4                               # -- Begin function unwind_step
	.type	unwind_step,@function
unwind_step:                            # @unwind_step
.Lfunc_begin10:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rsi, %rbx
	movq	(%rsi), %r14
	callq	_Unwind_GetIP@PLT
	movq	8(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	visit_return
	movl	%eax, %ecx
	xorl	%eax, %eax
	testl	%ecx, %ecx
	je	.LBB10_1
# %bb.2:
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB10_1:
	.cfi_def_cfa %rbp, 16
	movl	$1, 24(%rbx)
	movl	$5, %eax
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end10:
	.size	unwind_step, .Lfunc_end10-unwind_step
	.cfi_endproc
                                        # -- End function
	.section	.text.visit_return,"ax",@progbits
	.p2align	4                               # -- Begin function visit_return
	.type	visit_return,@function
visit_return:                           # @visit_return
.Lfunc_begin11:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movq	%rdx, %r14
	movq	%rdi, %r15
	cmpb	$0, frame_sites_ready(%rip)
	jne	.LBB11_7
# %bb.1:
	movb	$1, frame_sites_ready(%rip)
	movq	__start_mylang_frame_map@GOTPCREL(%rip), %r13
	testq	%r13, %r13
	sete	%al
	movq	__stop_mylang_frame_map@GOTPCREL(%rip), %r12
	cmpq	%r13, %r12
	setbe	%cl
	orb	%al, %cl
	jne	.LBB11_7
# %bb.2:
	subq	__start_mylang_frame_map@GOTPCREL(%rip), %r12
	sarq	$2, %r12
	movabsq	$-6148914691236517205, %rax     # imm = 0xAAAAAAAAAAAAAAAB
	movq	%r12, %rdx
	mulxq	%rax, %rbx, %rbx
	shrq	%rbx
	movabsq	$-768614336404564651, %rax      # imm = 0xF555555555555555
	leaq	(%rbx,%rax), %rcx
	incq	%rax
	cmpq	%rax, %rcx
	jb	.LBB11_7
# %bb.3:
	leaq	(,%rbx,8), %rax
	leaq	(%rax,%rax,2), %rdi
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	callq	malloc@PLT
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	%rax, frame_sites(%rip)
	testq	%rax, %rax
	je	.LBB11_29
# %bb.4:
	cmpq	$3, %r12
	jae	.LBB11_12
# %bb.5:
	xorl	%r12d, %r12d
.LBB11_6:
	movl	$24, %edx
	movl	$site_order, %ecx
	movq	%rax, %rdi
	movq	%r12, %rsi
	callq	qsort@PLT
	movq	%r12, frame_site_count(%rip)
	movq	-48(%rbp), %rsi                 # 8-byte Reload
.LBB11_7:
	movq	frame_sites(%rip), %rcx
	testq	%rcx, %rcx
	je	.LBB11_29
# %bb.8:
	movq	frame_site_count(%rip), %rdx
	xorl	%edi, %edi
	testq	%rdx, %rdx
	je	.LBB11_21
# %bb.9:
	movq	%rdx, %rax
	jmp	.LBB11_10
	.p2align	4
.LBB11_19:                              #   in Loop: Header=BB11_10 Depth=1
	movq	%r9, %rax
	cmpq	%rax, %rdi
	jae	.LBB11_21
.LBB11_10:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r8
	subq	%rdi, %r8
	shrq	%r8
	leaq	(%r8,%rdi), %r9
	leaq	(%r9,%r9,2), %r10
	cmpq	%rsi, (%rcx,%r10,8)
	jae	.LBB11_19
# %bb.11:                               #   in Loop: Header=BB11_10 Depth=1
	addq	%r8, %rdi
	incq	%rdi
	cmpq	%rax, %rdi
	jb	.LBB11_10
.LBB11_21:
	movl	$1, %eax
	cmpq	%rdx, %rdi
	jae	.LBB11_41
# %bb.22:
	leaq	(%rdi,%rdi,2), %rdx
	cmpq	%rsi, (%rcx,%rdx,8)
	jne	.LBB11_41
# %bb.23:
	leaq	(%rcx,%rdx,8), %rcx
	movq	16(%rcx), %r12
	testq	%r12, %r12
	je	.LBB11_41
# %bb.24:
	movq	8(%rcx), %r13
.LBB11_25:
	addq	$8, %r13
	movq	%r13, %rbx
	jmp	.LBB11_26
	.p2align	4
.LBB11_39:                              #   in Loop: Header=BB11_26 Depth=1
	addq	$12, %r13
	addq	$12, %rbx
	decq	%r12
	je	.LBB11_40
.LBB11_26:                              # =>This Inner Loop Header: Depth=1
	movl	-4(%r13), %edx
	testl	%edx, %edx
	js	.LBB11_39
# %bb.27:                               #   in Loop: Header=BB11_26 Depth=1
	movslq	(%r13), %rsi
	addq	%rbx, %rsi
	andl	$536870911, %edx                # imm = 0x1FFFFFFF
	movq	%r15, %rdi
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	callq	*%r14
	testl	%eax, %eax
	jne	.LBB11_39
# %bb.28:
	xorl	%eax, %eax
	jmp	.LBB11_41
.LBB11_29:
	movq	__start_mylang_frame_map@GOTPCREL(%rip), %rcx
	testq	%rcx, %rcx
	sete	%al
	movq	__stop_mylang_frame_map@GOTPCREL(%rip), %rdx
	cmpq	%rcx, %rdx
	setbe	%dil
	orb	%al, %dil
	movl	$1, %eax
	jne	.LBB11_41
# %bb.30:
	subq	__start_mylang_frame_map@GOTPCREL(%rip), %rdx
	sarq	$2, %rdx
	movabsq	$-6148914691236517205, %rdi     # imm = 0xAAAAAAAAAAAAAAAB
	mulxq	%rdi, %rdi, %rdi
	cmpq	$3, %rdx
	jb	.LBB11_41
# %bb.31:
	shrq	%rdi
	leaq	-1(%rdi), %rdx
	xorl	%r8d, %r8d
	.p2align	4
.LBB11_32:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB11_34 Depth 2
	leaq	(,%r8,4), %r9
	leaq	(%r9,%r9,2), %r13
	movl	$1, %r12d
	cmpq	%rdx, %r8
	jae	.LBB11_37
# %bb.33:                               #   in Loop: Header=BB11_32 Depth=1
	movq	%rdi, %r9
	subq	%r8, %r9
	leaq	(%rcx,%r13), %r10
	addq	$16, %r10
	.p2align	4
.LBB11_34:                              #   Parent Loop BB11_32 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	testb	$64, 3(%r10)
	je	.LBB11_37
# %bb.35:                               #   in Loop: Header=BB11_34 Depth=2
	incq	%r12
	addq	$12, %r10
	cmpq	%r12, %r9
	jne	.LBB11_34
# %bb.36:                               #   in Loop: Header=BB11_32 Depth=1
	movq	%r9, %r12
.LBB11_37:                              #   in Loop: Header=BB11_32 Depth=1
	addq	%rcx, %r13
	movslq	(%r13), %r9
	addq	%r13, %r9
	cmpq	%rsi, %r9
	je	.LBB11_25
# %bb.38:                               #   in Loop: Header=BB11_32 Depth=1
	addq	%r12, %r8
	cmpq	%rdi, %r8
	jb	.LBB11_32
	jmp	.LBB11_41
.LBB11_40:
	movl	$1, %eax
.LBB11_41:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB11_12:
	.cfi_def_cfa %rbp, 16
	leaq	-1(%rbx), %rcx
	xorl	%r12d, %r12d
	xorl	%edx, %edx
	jmp	.LBB11_13
	.p2align	4
.LBB11_17:                              #   in Loop: Header=BB11_13 Depth=1
	movq	%r8, %rdi
.LBB11_18:                              #   in Loop: Header=BB11_13 Depth=1
	leaq	(%r12,%r12,2), %r8
	leaq	(%rax,%r8,8), %r8
	addq	%r13, %rsi
	movslq	(%rsi), %r9
	addq	%rsi, %r9
	movq	%r9, (%r8)
	movq	%rsi, 8(%r8)
	movq	%rdi, 16(%r8)
	addq	%rdi, %rdx
	incq	%r12
	cmpq	%rbx, %rdx
	jae	.LBB11_6
.LBB11_13:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB11_15 Depth 2
	leaq	(,%rdx,4), %rsi
	leaq	(%rsi,%rsi,2), %rsi
	movl	$1, %edi
	cmpq	%rcx, %rdx
	jae	.LBB11_18
# %bb.14:                               #   in Loop: Header=BB11_13 Depth=1
	movq	%rbx, %r8
	subq	%rdx, %r8
	leaq	(%rsi,%r13), %r9
	addq	$16, %r9
	.p2align	4
.LBB11_15:                              #   Parent Loop BB11_13 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	testb	$64, 3(%r9)
	je	.LBB11_18
# %bb.16:                               #   in Loop: Header=BB11_15 Depth=2
	incq	%rdi
	addq	$12, %r9
	cmpq	%rdi, %r8
	jne	.LBB11_15
	jmp	.LBB11_17
.Lfunc_end11:
	.size	visit_return, .Lfunc_end11-visit_return
	.cfi_endproc
                                        # -- End function
	.section	.text.site_order,"ax",@progbits
	.p2align	4                               # -- Begin function site_order
	.type	site_order,@function
site_order:                             # @site_order
.Lfunc_begin12:
	.cfi_startproc
# %bb.0:
	movq	(%rdi), %rax
	cmpq	(%rsi), %rax
	seta	%al
	sbbb	$0, %al
	movsbl	%al, %eax
	retq
.Lfunc_end12:
	.size	site_order, .Lfunc_end12-site_order
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_fail_allocation,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_fail_allocation
	.type	myl_qbe_fail_allocation,@function
myl_qbe_fail_allocation:                # @myl_qbe_fail_allocation
.Lfunc_begin13:
	.cfi_startproc
# %bb.0:
	movq	6240(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB13_6
# %bb.1:
	movl	292(%rcx), %eax
	movl	$0, 292(%rcx)
	testq	%rax, %rax
	je	.LBB13_6
# %bb.2:
	cmpl	$1, %eax
	jne	.LBB13_4
# %bb.3:
	movl	$.L.str.17, %esi
	cmpl	$0, 708(%rdi)
	je	.LBB13_5
# %bb.8:
	jmp	fail                            # TAILCALL
.LBB13_6:
	cmpl	$0, %fs:cow_depth_exceeded@TPOFF
	movl	$0, %fs:cow_depth_exceeded@TPOFF
	movl	$.L.str.16.30, %esi
	jne	fail                            # TAILCALL
# %bb.7:
	cmpl	$0, 708(%rdi)
	movl	$.L.str.122, %eax
	movl	$.L.str.17, %esi
	cmoveq	%rax, %rsi
	jmp	fail                            # TAILCALL
.LBB13_4:
	cmpl	$4, %eax
	jae	.LBB13_9
.LBB13_5:
	movq	.Lswitch.table.myl_rc_status_code(,%rax,8), %rsi
	jmp	fail                            # TAILCALL
.LBB13_9:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	abort@PLT
.Lfunc_end13:
	.size	myl_qbe_fail_allocation, .Lfunc_end13-myl_qbe_fail_allocation
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_fail_cast,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_fail_cast
	.type	myl_qbe_fail_cast,@function
myl_qbe_fail_cast:                      # @myl_qbe_fail_cast
.Lfunc_begin14:
	.cfi_startproc
# %bb.0:
	cmpq	$0, 32(%rdi)
	je	.LBB14_1
# %bb.2:
	movl	$.L.str.27, %esi
	jmp	fail                            # TAILCALL
.LBB14_1:
	movabsq	$223338299393, %rax             # imm = 0x3400000001
	movq	%rax, 14824(%rdi)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 14832(%rdi)
	movq	%rsi, 14848(%rdi)
	movq	$0, 14856(%rdi)
	movq	$64, 14864(%rdi)
	movq	$.L.str.28, 14872(%rdi)
	movl	$.L.str.27, %esi
	jmp	fail                            # TAILCALL
.Lfunc_end14:
	.size	myl_qbe_fail_cast, .Lfunc_end14-myl_qbe_fail_cast
	.cfi_endproc
                                        # -- End function
	.section	.text.on_timeout,"ax",@progbits
	.p2align	4                               # -- Begin function on_timeout
	.type	on_timeout,@function
on_timeout:                             # @on_timeout
.Lfunc_begin15:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$on_timeout.message, %esi
	movl	$72, %edx
	movl	$2, %edi
	callq	write@PLT
	movl	$1, %edi
	callq	_exit@PLT
.Lfunc_end15:
	.size	on_timeout, .Lfunc_end15-on_timeout
	.cfi_endproc
                                        # -- End function
	.section	.text.append,"ax",@progbits
	.p2align	4                               # -- Begin function append
	.type	append,@function
append:                                 # @append
.Lfunc_begin16:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	subq	$208, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movq	%r8, -192(%rbp)
	movq	%r9, -184(%rbp)
	testb	%al, %al
	je	.LBB16_5
# %bb.4:
	vmovaps	%xmm0, -176(%rbp)
	vmovaps	%xmm1, -160(%rbp)
	vmovaps	%xmm2, -144(%rbp)
	vmovaps	%xmm3, -128(%rbp)
	vmovaps	%xmm4, -112(%rbp)
	vmovaps	%xmm5, -96(%rbp)
	vmovaps	%xmm6, -80(%rbp)
	vmovaps	%xmm7, -64(%rbp)
.LBB16_5:
	leaq	-224(%rbp), %rax
	movq	%rax, -32(%rbp)
	leaq	16(%rbp), %rax
	movq	%rax, -40(%rbp)
	movabsq	$206158430240, %rax             # imm = 0x3000000020
	movq	%rax, -48(%rbp)
	movq	(%rdx), %rax
	addq	%rax, %rdi
	subq	%rax, %rsi
	leaq	-48(%rbp), %rax
	movq	%rcx, %rdx
	movq	%rax, %rcx
	callq	vsnprintf@PLT
	movl	%eax, %ecx
	xorl	%eax, %eax
	testl	%ecx, %ecx
	js	.LBB16_3
# %bb.1:
	movl	%ecx, %ecx
	movq	(%rbx), %rdx
	subq	%rdx, %r14
	cmpq	%rcx, %r14
	jbe	.LBB16_3
# %bb.2:
	addq	%rcx, %rdx
	movq	%rdx, (%rbx)
	movl	$1, %eax
.LBB16_3:
	addq	$208, %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end16:
	.size	append, .Lfunc_end16-append
	.cfi_endproc
                                        # -- End function
	.section	.text.describe,"ax",@progbits
	.p2align	4                               # -- Begin function describe
	.type	describe,@function
describe:                               # @describe
.Lfunc_begin17:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
	movl	$.L.str.17, %esi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_1
# %bb.2:
	movl	$.L.str.29, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_3
# %bb.4:
	movl	$.L.str.34, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_5
# %bb.6:
	movl	$.L.str.36, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_7
# %bb.8:
	movl	$.L.str.30, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_9
# %bb.10:
	movl	$.L.str.20, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_11
# %bb.12:
	movl	$.L.str.21, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_13
# %bb.14:
	movl	$.L.str.22, %esi
	movq	%rbx, %rdi
	callq	strcmp@PLT
	testl	%eax, %eax
	je	.LBB17_15
# %bb.16:
	movl	$.L.str.92, %eax
	cmpb	$82, (%rbx)
	jne	.LBB17_18
# %bb.17:
	cmpb	$95, 1(%rbx)
	movl	$.L.str.93, %ecx
	cmoveq	%rcx, %rax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_1:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.84, %eax
.LBB17_18:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_3:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.85, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_5:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.86, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_7:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.87, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_9:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.88, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_11:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.89, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_13:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.90, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB17_15:
	.cfi_def_cfa %rbp, 16
	movl	$.L.str.91, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end17:
	.size	describe, .Lfunc_end17-describe
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_native_heap_collect,"ax",@progbits
	.p2align	4                               # -- Begin function myl_native_heap_collect
	.type	myl_native_heap_collect,@function
myl_native_heap_collect:                # @myl_native_heap_collect
.Lfunc_begin18:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	testq	%rdi, %rdi
	je	.LBB18_3
# %bb.1:
	cmpq	$0, 5640(%rdi)
	je	.LBB18_4
# %bb.2:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_drain                    # TAILCALL
.LBB18_3:
	.cfi_def_cfa %rbp, 16
	xorl	%edi, %edi
.LBB18_4:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	collect                         # TAILCALL
.Lfunc_end18:
	.size	myl_native_heap_collect, .Lfunc_end18-myl_native_heap_collect
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0                          # -- Begin function collect
.LCPI19_0:
	.zero	32,15
.LCPI19_1:
	.byte	0                               # 0x0
	.byte	1                               # 0x1
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	3                               # 0x3
	.byte	4                               # 0x4
	.byte	0                               # 0x0
	.byte	1                               # 0x1
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	1                               # 0x1
	.byte	2                               # 0x2
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	2                               # 0x2
	.byte	3                               # 0x3
	.byte	3                               # 0x3
	.byte	4                               # 0x4
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI19_2:
	.byte	0                               # 0x0
	.byte	0                               # 0x0
	.byte	0                               # 0x0
	.byte	0                               # 0x0
	.byte	128                             # 0x80
	.byte	64                              # 0x40
	.byte	32                              # 0x20
	.byte	16                              # 0x10
	.section	.rodata,"a",@progbits
.LCPI19_3:
	.byte	15                              # 0xf
	.section	.text.collect,"ax",@progbits
	.p2align	4
	.type	collect,@function
collect:                                # @collect
.Lfunc_begin19:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	andq	$-32, %rsp
	subq	$320, %rsp                      # imm = 0x140
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpl	$0, 116(%rdi)
	jne	.LBB19_102
# %bb.1:
	movq	%rdi, %r15
	incq	80(%rdi)
	movq	$0, 1256(%rdi)
	movl	$0, 1272(%rdi)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%ymm0, 1280(%rdi)
	vmovdqu	%ymm0, 1312(%rdi)
	vmovdqu	%ymm0, 1344(%rdi)
	vmovdqu	%ymm0, 1376(%rdi)
	vmovdqu	%ymm0, 1408(%rdi)
	vmovdqu	%ymm0, 1440(%rdi)
	vmovdqu	%ymm0, 1504(%rdi)
	movq	$0, 1536(%rdi)
	vmovdqu	%ymm0, 1560(%rdi)
	movq	$0, 1592(%rdi)
	vmovdqu	%ymm0, 1616(%rdi)
	movq	$0, 1648(%rdi)
	vmovdqu	%ymm0, 1672(%rdi)
	movq	$0, 1704(%rdi)
	vmovdqu	%ymm0, 1728(%rdi)
	movq	$0, 1760(%rdi)
	vmovdqu	%ymm0, 1784(%rdi)
	movq	$0, 1816(%rdi)
	vmovdqu	%ymm0, 1840(%rdi)
	movq	$0, 1872(%rdi)
	vmovdqu	%ymm0, 1896(%rdi)
	movq	$0, 1928(%rdi)
	vmovdqu	%ymm0, 1952(%rdi)
	movq	$0, 1984(%rdi)
	vmovdqu	%ymm0, 2008(%rdi)
	movq	$0, 2040(%rdi)
	vmovdqu	%ymm0, 2064(%rdi)
	movq	$0, 2096(%rdi)
	vmovdqu	%ymm0, 2120(%rdi)
	movq	$0, 2152(%rdi)
	vmovdqu	%ymm0, 2176(%rdi)
	movq	$0, 2208(%rdi)
	vmovdqu	%ymm0, 2232(%rdi)
	movq	$0, 2264(%rdi)
	vmovdqu	%ymm0, 2288(%rdi)
	movq	$0, 2320(%rdi)
	vmovdqu	%ymm0, 2344(%rdi)
	movq	$0, 2376(%rdi)
	vmovdqu	%ymm0, 2400(%rdi)
	movq	$0, 2432(%rdi)
	vmovdqu	%ymm0, 2456(%rdi)
	movq	$0, 2488(%rdi)
	vmovdqu	%ymm0, 2512(%rdi)
	movq	$0, 2544(%rdi)
	vmovdqu	%ymm0, 2568(%rdi)
	movq	$0, 2600(%rdi)
	vmovdqu	%ymm0, 2624(%rdi)
	movq	$0, 2656(%rdi)
	vmovdqu	%ymm0, 2680(%rdi)
	movq	$0, 2712(%rdi)
	vmovdqu	%ymm0, 2736(%rdi)
	movq	$0, 2768(%rdi)
	vmovdqu	%ymm0, 2792(%rdi)
	movq	$0, 2824(%rdi)
	vmovdqu	%ymm0, 2848(%rdi)
	movq	$0, 2880(%rdi)
	vmovdqu	%ymm0, 2904(%rdi)
	movq	$0, 2936(%rdi)
	vmovdqu	%ymm0, 2960(%rdi)
	movq	$0, 2992(%rdi)
	vmovdqu	%ymm0, 3016(%rdi)
	movq	$0, 3048(%rdi)
	vmovdqu	%ymm0, 3072(%rdi)
	movq	$0, 3104(%rdi)
	vmovdqu	%ymm0, 3128(%rdi)
	movq	$0, 3160(%rdi)
	vmovdqu	%ymm0, 3184(%rdi)
	movq	$0, 3216(%rdi)
	vmovdqu	%ymm0, 3240(%rdi)
	movq	$0, 3272(%rdi)
	vmovdqu	%ymm0, 3296(%rdi)
	movq	$0, 3328(%rdi)
	vmovdqu	%ymm0, 3352(%rdi)
	movq	$0, 3384(%rdi)
	vmovdqu	%ymm0, 3408(%rdi)
	movq	$0, 3440(%rdi)
	vmovdqu	%ymm0, 3464(%rdi)
	movq	$0, 3496(%rdi)
	vmovdqu	%ymm0, 3520(%rdi)
	movq	$0, 3552(%rdi)
	vmovdqu	%ymm0, 3576(%rdi)
	movq	$0, 3608(%rdi)
	vmovdqu	%ymm0, 3632(%rdi)
	movq	$0, 3664(%rdi)
	vmovdqu	%ymm0, 3688(%rdi)
	movq	$0, 3720(%rdi)
	vmovdqu	%ymm0, 3744(%rdi)
	movq	$0, 3776(%rdi)
	vmovdqu	%ymm0, 3800(%rdi)
	movq	$0, 3832(%rdi)
	vmovdqu	%ymm0, 3856(%rdi)
	movq	$0, 3888(%rdi)
	vmovdqu	%ymm0, 3912(%rdi)
	movq	$0, 3944(%rdi)
	vmovdqu	%ymm0, 3968(%rdi)
	movq	$0, 4000(%rdi)
	vmovdqu	%ymm0, 4024(%rdi)
	movq	$0, 4056(%rdi)
	vmovdqu	%ymm0, 4080(%rdi)
	movq	$0, 4112(%rdi)
	vmovdqu	%ymm0, 4136(%rdi)
	movq	$0, 4168(%rdi)
	vmovdqu	%ymm0, 4192(%rdi)
	movq	$0, 4224(%rdi)
	vmovdqu	%ymm0, 4248(%rdi)
	movq	$0, 4280(%rdi)
	vmovdqu	%ymm0, 4304(%rdi)
	movq	$0, 4336(%rdi)
	vmovdqu	%ymm0, 4360(%rdi)
	movq	$0, 4392(%rdi)
	movq	(%rdi), %r14
	testq	%r14, %r14
	jne	.LBB19_3
	jmp	.LBB19_14
	.p2align	4
.LBB19_7:                               #   in Loop: Header=BB19_3 Depth=1
	leaq	72(%r14), %rdi
	movl	$1024, %edx                     # imm = 0x400
	xorl	%esi, %esi
	vzeroupper
	callq	memset@PLT
	movq	(%r14), %r14
	testq	%r14, %r14
	je	.LBB19_14
.LBB19_3:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_9 Depth 2
                                        #     Child Loop BB19_12 Depth 2
	cmpq	$32, 32(%r14)
	jb	.LBB19_7
# %bb.4:                                #   in Loop: Header=BB19_3 Depth=1
	movq	24(%r14), %rdx
	testq	%rdx, %rdx
	je	.LBB19_13
# %bb.5:                                #   in Loop: Header=BB19_3 Depth=1
	movq	8(%r14), %rax
	movl	%edx, %ecx
	andl	$3, %ecx
	cmpq	$4, %rdx
	jae	.LBB19_8
# %bb.6:                                #   in Loop: Header=BB19_3 Depth=1
	xorl	%esi, %esi
	jmp	.LBB19_11
.LBB19_8:                               #   in Loop: Header=BB19_3 Depth=1
	leaq	1136(%r14), %rdi
	andq	$-4, %rdx
	leaq	(%rax,%rax,2), %r8
	leaq	(,%rax,4), %r9
	xorl	%esi, %esi
	.p2align	4
.LBB19_9:                               #   Parent Loop BB19_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andb	$-2, (%rdi)
	andb	$-2, (%rdi,%rax)
	andb	$-2, (%rdi,%rax,2)
	andb	$-2, (%rdi,%r8)
	addq	$4, %rsi
	addq	%r9, %rdi
	cmpq	%rsi, %rdx
	jne	.LBB19_9
# %bb.10:                               #   in Loop: Header=BB19_3 Depth=1
	testq	%rcx, %rcx
	je	.LBB19_13
.LBB19_11:                              #   in Loop: Header=BB19_3 Depth=1
	imulq	%rax, %rsi
	leaq	(%r14,%rsi), %rdx
	addq	$1136, %rdx                     # imm = 0x470
	.p2align	4
.LBB19_12:                              #   Parent Loop BB19_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andb	$-2, (%rdx)
	addq	%rax, %rdx
	decq	%rcx
	jne	.LBB19_12
.LBB19_13:                              #   in Loop: Header=BB19_3 Depth=1
	movq	(%r14), %r14
	testq	%r14, %r14
	jne	.LBB19_3
.LBB19_14:
	movq	$0, 4440(%r15)
	movq	$0, 4416(%r15)
	movl	$0, 4464(%r15)
	incq	4480(%r15)
	movb	$0, 4468(%r15)
	movq	16(%r15), %rbx
	testq	%rbx, %rbx
	je	.LBB19_16
	.p2align	4
.LBB19_172:                             # =>This Inner Loop Header: Depth=1
	movq	8(%rbx), %rdx
	movq	16(%rbx), %rsi
	movq	%r15, %rdi
	vzeroupper
	callq	trace
	movq	(%rbx), %rbx
	testq	%rbx, %rbx
	jne	.LBB19_172
.LBB19_16:
	leaq	1496(%r15), %rax
	movq	%rax, 128(%rsp)                 # 8-byte Spill
	movl	$26, %ebx
	jmp	.LBB19_17
	.p2align	4
.LBB19_19:                              #   in Loop: Header=BB19_17 Depth=1
	incq	%rbx
	cmpq	$154, %rbx
	je	.LBB19_20
.LBB19_17:                              # =>This Inner Loop Header: Depth=1
	movq	(%r15,%rbx,8), %rsi
	testq	%rsi, %rsi
	je	.LBB19_19
# %bb.18:                               #   in Loop: Header=BB19_17 Depth=1
	movq	%r15, %rdi
	vzeroupper
	callq	mark
	jmp	.LBB19_19
.LBB19_20:
	cmpq	$0, (%r15)
	movq	%r15, 16(%rsp)                  # 8-byte Spill
	je	.LBB19_37
# %bb.21:
	movq	4512(%r15), %rax
	testq	%rax, %rax
	je	.LBB19_23
# %bb.22:
	movq	1472(%r15), %rcx
	subq	%rax, %rcx
	addq	$-80, %rcx
	movq	%rcx, 16(%rax)
	movq	$0, 4512(%r15)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 1472(%r15)
.LBB19_23:
	movq	4584(%r15), %rax
	testq	%rax, %rax
	je	.LBB19_37
# %bb.24:
	xorl	%edx, %edx
	movl	$40, %esi
	jmp	.LBB19_25
	.p2align	4
.LBB19_35:                              #   in Loop: Header=BB19_25 Depth=1
	movq	16(%rsp), %rax                  # 8-byte Reload
	movq	4584(%rax), %rax
.LBB19_36:                              #   in Loop: Header=BB19_25 Depth=1
	movq	160(%rsp), %rdx                 # 8-byte Reload
	incq	%rdx
	cmpq	%rax, %rdx
	movq	16(%rsp), %r15                  # 8-byte Reload
	jae	.LBB19_37
.LBB19_25:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_27 Depth 2
                                        #       Child Loop BB19_29 Depth 3
                                        #         Child Loop BB19_32 Depth 4
	movq	1240(%r15), %rcx
	movq	%rdx, 160(%rsp)                 # 8-byte Spill
	movq	(%rcx,%rdx,8), %rdi
	testq	%rdi, %rdi
	jne	.LBB19_27
	jmp	.LBB19_36
	.p2align	4
.LBB19_26:                              #   in Loop: Header=BB19_27 Depth=2
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB19_35
.LBB19_27:                              #   Parent Loop BB19_25 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB19_29 Depth 3
                                        #         Child Loop BB19_32 Depth 4
	movq	16(%rdi), %rax
	testq	%rax, %rax
	je	.LBB19_26
# %bb.28:                               #   in Loop: Header=BB19_27 Depth=2
	leaq	80(%rdi), %r8
	xorl	%r12d, %r12d
	movq	%rdi, 64(%rsp)                  # 8-byte Spill
	movq	%r8, 96(%rsp)                   # 8-byte Spill
	jmp	.LBB19_29
	.p2align	4
.LBB19_34:                              #   in Loop: Header=BB19_29 Depth=3
	addq	%r9, %r12
	addq	$31, %r12
	andq	$-16, %r12
	cmpq	%rax, %r12
	jae	.LBB19_26
.LBB19_29:                              #   Parent Loop BB19_25 Depth=1
                                        #     Parent Loop BB19_27 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB19_32 Depth 4
	movq	8(%r8,%r12), %r14
	bzhiq	%rsi, (%r8,%r12), %r13
	shrq	$2, %r13
	movq	(%r14), %r9
	imulq	%r13, %r9
	cmpq	$1, %r9
	adcq	$0, %r9
	cmpw	$0, 48(%r14)
	je	.LBB19_34
# %bb.30:                               #   in Loop: Header=BB19_29 Depth=3
	cmpl	$1, 88(%r14)
	setne	%cl
	testq	%r13, %r13
	setne	%dl
	andb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB19_34
# %bb.31:                               #   in Loop: Header=BB19_29 Depth=3
	movq	%r9, 24(%rsp)                   # 8-byte Spill
	leaq	(%r8,%r12), %rax
	addq	$16, %rax
	movq	%rax, 32(%rsp)                  # 8-byte Spill
	xorl	%ebx, %ebx
	movq	16(%rsp), %r15                  # 8-byte Reload
	.p2align	4
.LBB19_32:                              #   Parent Loop BB19_25 Depth=1
                                        #     Parent Loop BB19_27 Depth=2
                                        #       Parent Loop BB19_29 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	movq	(%r14), %rdx
	imulq	%rbx, %rdx
	addq	32(%rsp), %rdx                  # 8-byte Folded Reload
	movq	%r15, %rdi
	movq	%r14, %rsi
	vzeroupper
	callq	trace
	incq	%rbx
	cmpq	%rbx, %r13
	jne	.LBB19_32
# %bb.33:                               #   in Loop: Header=BB19_29 Depth=3
	movq	64(%rsp), %rdi                  # 8-byte Reload
	movq	16(%rdi), %rax
	movl	$40, %esi
	movq	96(%rsp), %r8                   # 8-byte Reload
	movq	24(%rsp), %r9                   # 8-byte Reload
	jmp	.LBB19_34
.LBB19_87:                              #   in Loop: Header=BB19_37 Depth=1
	movl	$1, 4464(%r15)
	.p2align	4
.LBB19_37:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_47 Depth 2
                                        #     Child Loop BB19_58 Depth 2
                                        #       Child Loop BB19_59 Depth 3
                                        #     Child Loop BB19_45 Depth 2
	movq	1256(%r15), %rax
	testq	%rax, %rax
	je	.LBB19_88
# %bb.38:                               #   in Loop: Header=BB19_37 Depth=1
	movq	8(%r15), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, 1256(%r15)
	movq	-8(%rcx,%rax,8), %rax
	movb	$0, 4469(%r15)
	movq	%rax, 32(%rsp)                  # 8-byte Spill
	movq	8(%rax), %r13
	movzwl	48(%r13), %eax
	testl	%eax, %eax
	je	.LBB19_64
# %bb.39:                               #   in Loop: Header=BB19_37 Depth=1
	cmpl	$1, 88(%r13)
	je	.LBB19_64
# %bb.40:                               #   in Loop: Header=BB19_37 Depth=1
	movq	32(%rsp), %rdx                  # 8-byte Reload
	leaq	16(%rdx), %r12
	movl	$60, %ecx
	bzhiq	%rcx, (%rdx), %r14
	shrq	$2, %r14
	cmpl	$6, %eax
	ja	.LBB19_42
# %bb.41:                               #   in Loop: Header=BB19_37 Depth=1
	movl	$98, %ecx
	btl	%eax, %ecx
	jae	.LBB19_42
# %bb.46:                               #   in Loop: Header=BB19_37 Depth=1
	testq	%r14, %r14
	movq	16(%rsp), %r15                  # 8-byte Reload
	je	.LBB19_64
	.p2align	4
.LBB19_47:                              #   Parent Loop BB19_37 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%r12), %rsi
	movq	%r15, %rdi
	vzeroupper
	callq	mark
	addq	(%r13), %r12
	decq	%r14
	jne	.LBB19_47
	.p2align	4
.LBB19_64:                              #   in Loop: Header=BB19_37 Depth=1
	movq	32(%rsp), %r14                  # 8-byte Reload
	movq	(%r14), %rax
	testb	$1, %al
	je	.LBB19_37
# %bb.65:                               #   in Loop: Header=BB19_37 Depth=1
	movq	8(%r14), %rcx
	cmpw	$0, 48(%rcx)
	je	.LBB19_37
# %bb.66:                               #   in Loop: Header=BB19_37 Depth=1
	cmpl	$1, 88(%rcx)
	je	.LBB19_37
# %bb.67:                               #   in Loop: Header=BB19_37 Depth=1
	cmpl	$0, 92(%rcx)
	je	.LBB19_68
# %bb.80:                               #   in Loop: Header=BB19_37 Depth=1
	cmpb	$0, 4469(%r15)
	je	.LBB19_37
# %bb.81:                               #   in Loop: Header=BB19_37 Depth=1
	movq	4440(%r15), %rcx
	cmpq	4448(%r15), %rcx
	jne	.LBB19_82
# %bb.83:                               #   in Loop: Header=BB19_37 Depth=1
	leaq	(%rcx,%rcx), %rbx
	testq	%rcx, %rcx
	movl	$256, %eax                      # imm = 0x100
	cmoveq	%rax, %rbx
	cmpq	%rcx, %rbx
	setbe	%al
	movabsq	$2305843009213693951, %rcx      # imm = 0x1FFFFFFFFFFFFFFF
	cmpq	%rcx, %rbx
	seta	%cl
	orb	%al, %cl
	jne	.LBB19_87
# %bb.84:                               #   in Loop: Header=BB19_37 Depth=1
	movq	4432(%r15), %rdi
	leaq	(,%rbx,8), %rsi
	vzeroupper
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB19_87
# %bb.85:                               #   in Loop: Header=BB19_37 Depth=1
	movq	%rax, 4432(%r15)
	movq	%rbx, 4448(%r15)
	movq	4440(%r15), %rcx
	jmp	.LBB19_86
.LBB19_42:                              #   in Loop: Header=BB19_37 Depth=1
	movq	96(%r13), %rax
	movq	%rax, 24(%rsp)                  # 8-byte Spill
	testq	%rax, %rax
	je	.LBB19_43
# %bb.48:                               #   in Loop: Header=BB19_37 Depth=1
	movq	16(%rsp), %rax                  # 8-byte Reload
	cmpl	$0, 104(%rax)
	je	.LBB19_55
# %bb.49:                               #   in Loop: Header=BB19_37 Depth=1
	leaq	192(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	$8, 144(%rsp)
	movq	$0, 152(%rsp)
	leaq	136(%rsp), %rdi
	movq	%r13, %rsi
	xorl	%edx, %edx
	movabsq	$-4294967296, %rcx              # imm = 0xFFFFFFFF00000000
	xorl	%r8d, %r8d
	vzeroupper
	callq	flatten
	testl	%eax, %eax
	je	.LBB19_54
# %bb.50:                               #   in Loop: Header=BB19_37 Depth=1
	movq	152(%rsp), %rax
	cmpq	104(%r13), %rax
	jne	.LBB19_54
# %bb.51:                               #   in Loop: Header=BB19_37 Depth=1
	testq	%rax, %rax
	je	.LBB19_52
# %bb.53:                               #   in Loop: Header=BB19_37 Depth=1
	movq	96(%r13), %rsi
	movq	%rax, 64(%rsp)                  # 8-byte Spill
	leaq	(,%rax,4), %rax
	leaq	(%rax,%rax,2), %rdx
	leaq	192(%rsp), %rdi
	callq	bcmp@PLT
	testl	%eax, %eax
	movq	16(%rsp), %r15                  # 8-byte Reload
	je	.LBB19_56
	jmp	.LBB19_54
.LBB19_68:                              #   in Loop: Header=BB19_37 Depth=1
	movq	(%rcx), %rcx
	movl	$60, %edx
	bzhiq	%rdx, %rax, %rsi
	shrq	$2, %rsi
	testq	%rcx, %rcx
	je	.LBB19_73
# %bb.69:                               #   in Loop: Header=BB19_37 Depth=1
	cmpq	$262128, %rcx                   # imm = 0x3FFF0
	ja	.LBB19_70
# %bb.71:                               #   in Loop: Header=BB19_37 Depth=1
	movl	$262128, %eax                   # imm = 0x3FFF0
	xorl	%edx, %edx
	divl	%ecx
                                        # kill: def $eax killed $eax def $rax
	cmpq	%rax, %rsi
	ja	.LBB19_37
	jmp	.LBB19_73
.LBB19_82:                              #   in Loop: Header=BB19_37 Depth=1
	movq	4432(%r15), %rax
.LBB19_86:                              #   in Loop: Header=BB19_37 Depth=1
	leaq	1(%rcx), %rdx
	movq	%rdx, 4440(%r15)
	movq	%r14, (%rax,%rcx,8)
	jmp	.LBB19_37
.LBB19_43:                              #   in Loop: Header=BB19_37 Depth=1
	testq	%r14, %r14
	movq	16(%rsp), %r15                  # 8-byte Reload
	je	.LBB19_64
# %bb.44:                               #   in Loop: Header=BB19_37 Depth=1
	xorl	%ebx, %ebx
	.p2align	4
.LBB19_45:                              #   Parent Loop BB19_37 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%r13), %rdx
	imulq	%rbx, %rdx
	addq	%r12, %rdx
	movq	%r15, %rdi
	movq	%r13, %rsi
	vzeroupper
	callq	trace
	incq	%rbx
	cmpq	%rbx, %r14
	jne	.LBB19_45
	jmp	.LBB19_64
.LBB19_55:                              #   in Loop: Header=BB19_37 Depth=1
	movq	104(%r13), %rax
	movq	%rax, 64(%rsp)                  # 8-byte Spill
	testq	%rax, %rax
	movq	16(%rsp), %r15                  # 8-byte Reload
	je	.LBB19_64
.LBB19_56:                              #   in Loop: Header=BB19_37 Depth=1
	testq	%r14, %r14
	je	.LBB19_64
# %bb.57:                               #   in Loop: Header=BB19_37 Depth=1
	movq	(%r13), %rax
	movq	%rax, 96(%rsp)                  # 8-byte Spill
	addq	$8, 24(%rsp)                    # 8-byte Folded Spill
	xorl	%ebx, %ebx
	jmp	.LBB19_58
	.p2align	4
.LBB19_63:                              #   in Loop: Header=BB19_58 Depth=2
	incq	%rbx
	addq	96(%rsp), %r12                  # 8-byte Folded Reload
	cmpq	%r14, %rbx
	movq	16(%rsp), %r15                  # 8-byte Reload
	je	.LBB19_64
.LBB19_58:                              #   Parent Loop BB19_37 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB19_59 Depth 3
	movq	24(%rsp), %r13                  # 8-byte Reload
	movq	64(%rsp), %r15                  # 8-byte Reload
	jmp	.LBB19_59
	.p2align	4
.LBB19_61:                              #   in Loop: Header=BB19_59 Depth=3
	movl	-8(%r13), %eax
	movq	(%r12,%rax), %rsi
	movq	16(%rsp), %rdi                  # 8-byte Reload
	vzeroupper
	callq	mark
.LBB19_62:                              #   in Loop: Header=BB19_59 Depth=3
	addq	$12, %r13
	decq	%r15
	je	.LBB19_63
.LBB19_59:                              #   Parent Loop BB19_37 Depth=1
                                        #     Parent Loop BB19_58 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movl	-4(%r13), %eax
	movl	$4294967295, %ecx               # imm = 0xFFFFFFFF
	cmpq	%rcx, %rax
	je	.LBB19_61
# %bb.60:                               #   in Loop: Header=BB19_59 Depth=3
	movl	(%r12,%rax), %eax
	cmpl	(%r13), %eax
	je	.LBB19_61
	jmp	.LBB19_62
.LBB19_70:                              #   in Loop: Header=BB19_37 Depth=1
	xorl	%eax, %eax
	cmpq	%rax, %rsi
	ja	.LBB19_37
.LBB19_73:                              #   in Loop: Header=BB19_37 Depth=1
	imulq	%rsi, %rcx
	addq	$31, %rcx
	cmpq	$15, %rcx
	setae	%al
	andq	$-16, %rcx
	cmpq	$262145, %rcx                   # imm = 0x40001
	setae	%cl
	testb	%cl, %al
	jne	.LBB19_37
# %bb.74:                               #   in Loop: Header=BB19_37 Depth=1
	movq	4416(%r15), %rcx
	cmpq	4424(%r15), %rcx
	jne	.LBB19_75
# %bb.76:                               #   in Loop: Header=BB19_37 Depth=1
	leaq	(%rcx,%rcx), %rbx
	testq	%rcx, %rcx
	movl	$256, %eax                      # imm = 0x100
	cmoveq	%rax, %rbx
	cmpq	%rcx, %rbx
	setbe	%al
	movabsq	$2305843009213693951, %rcx      # imm = 0x1FFFFFFFFFFFFFFF
	cmpq	%rcx, %rbx
	seta	%cl
	orb	%al, %cl
	jne	.LBB19_87
# %bb.77:                               #   in Loop: Header=BB19_37 Depth=1
	movq	4408(%r15), %rdi
	leaq	(,%rbx,8), %rsi
	vzeroupper
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB19_87
# %bb.78:                               #   in Loop: Header=BB19_37 Depth=1
	movq	%rax, 4408(%r15)
	movq	%rbx, 4424(%r15)
	movq	4416(%r15), %rcx
	jmp	.LBB19_79
.LBB19_52:                              #   in Loop: Header=BB19_37 Depth=1
	movq	16(%rsp), %r15                  # 8-byte Reload
	jmp	.LBB19_64
.LBB19_75:                              #   in Loop: Header=BB19_37 Depth=1
	movq	4408(%r15), %rax
.LBB19_79:                              #   in Loop: Header=BB19_37 Depth=1
	leaq	1(%rcx), %rdx
	movq	%rdx, 4416(%r15)
	movq	%r14, (%rax,%rcx,8)
	jmp	.LBB19_37
.LBB19_88:
	movb	$0, 4468(%r15)
	cmpl	$0, 1272(%r15)
	movq	(%r15), %r14
	jne	.LBB19_89
# %bb.103:
	testq	%r14, %r14
	je	.LBB19_104
# %bb.105:
	xorl	%r13d, %r13d
	vpbroadcastq	.LCPI19_2(%rip), %ymm0  # ymm0 = [0,0,0,0,128,64,32,16,0,0,0,0,128,64,32,16,0,0,0,0,128,64,32,16,0,0,0,0,128,64,32,16]
	vmovdqa	%ymm0, 160(%rsp)                # 32-byte Spill
	xorl	%ebx, %ebx
	xorl	%r11d, %r11d
	movq	%r15, %rdx
	jmp	.LBB19_106
	.p2align	4
.LBB19_94:                              #   in Loop: Header=BB19_89 Depth=1
	leaq	72(%r14), %rdi
	movl	$1024, %edx                     # imm = 0x400
	xorl	%esi, %esi
	vzeroupper
	callq	memset@PLT
	movq	(%r14), %r14
.LBB19_89:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_90 Depth 2
                                        #       Child Loop BB19_96 Depth 3
                                        #       Child Loop BB19_99 Depth 3
	testq	%r14, %r14
	je	.LBB19_101
.LBB19_90:                              #   Parent Loop BB19_89 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB19_96 Depth 3
                                        #       Child Loop BB19_99 Depth 3
	cmpq	$32, 32(%r14)
	jb	.LBB19_94
# %bb.91:                               #   in Loop: Header=BB19_90 Depth=2
	movq	24(%r14), %rdx
	testq	%rdx, %rdx
	je	.LBB19_100
# %bb.92:                               #   in Loop: Header=BB19_90 Depth=2
	movq	8(%r14), %rax
	movl	%edx, %ecx
	andl	$3, %ecx
	cmpq	$4, %rdx
	jae	.LBB19_95
# %bb.93:                               #   in Loop: Header=BB19_90 Depth=2
	xorl	%esi, %esi
	jmp	.LBB19_98
.LBB19_95:                              #   in Loop: Header=BB19_90 Depth=2
	leaq	1136(%r14), %rdi
	andq	$-4, %rdx
	leaq	(%rax,%rax,2), %r8
	leaq	(,%rax,4), %r9
	xorl	%esi, %esi
	.p2align	4
.LBB19_96:                              #   Parent Loop BB19_89 Depth=1
                                        #     Parent Loop BB19_90 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	andb	$-2, (%rdi)
	andb	$-2, (%rdi,%rax)
	andb	$-2, (%rdi,%rax,2)
	andb	$-2, (%rdi,%r8)
	addq	$4, %rsi
	addq	%r9, %rdi
	cmpq	%rsi, %rdx
	jne	.LBB19_96
# %bb.97:                               #   in Loop: Header=BB19_90 Depth=2
	testq	%rcx, %rcx
	je	.LBB19_100
.LBB19_98:                              #   in Loop: Header=BB19_90 Depth=2
	imulq	%rax, %rsi
	leaq	(%r14,%rsi), %rdx
	addq	$1136, %rdx                     # imm = 0x470
	.p2align	4
.LBB19_99:                              #   Parent Loop BB19_89 Depth=1
                                        #     Parent Loop BB19_90 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	andb	$-2, (%rdx)
	addq	%rax, %rdx
	decq	%rcx
	jne	.LBB19_99
.LBB19_100:                             #   in Loop: Header=BB19_90 Depth=2
	movq	(%r14), %r14
	testq	%r14, %r14
	jne	.LBB19_90
.LBB19_101:
	movq	$0, 1256(%r15)
	movl	$1, 4464(%r15)
	jmp	.LBB19_102
	.p2align	4
.LBB19_108:                             #   in Loop: Header=BB19_106 Depth=1
	addq	8(%r14), %r13
	incq	%rbx
.LBB19_109:                             #   in Loop: Header=BB19_106 Depth=1
	movq	(%r14), %rax
	movq	%r14, %rdx
	movq	%r11, %r12
	movq	%rax, %r14
	testq	%rax, %rax
	je	.LBB19_161
.LBB19_106:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_119 Depth 2
                                        #       Child Loop BB19_121 Depth 3
                                        #     Child Loop BB19_137 Depth 2
	movq	32(%r14), %rcx
	leaq	1136(%r14), %rdi
	cmpq	$52, %rcx
	jb	.LBB19_111
# %bb.107:                              #   in Loop: Header=BB19_106 Depth=1
	testb	$1, (%rdi)
	jne	.LBB19_108
# %bb.110:                              #   in Loop: Header=BB19_106 Depth=1
	movq	(%r14), %rax
	movq	%rax, (%rdx)
	movq	%r14, %rdi
	movq	%rdx, %r14
	movq	%r11, %r12
	vzeroupper
	callq	free@PLT
	movq	%r12, %r11
	jmp	.LBB19_109
	.p2align	4
.LBB19_111:                             #   in Loop: Header=BB19_106 Depth=1
	movq	8(%r14), %rax
	movq	24(%r14), %r9
	imulq	%rax, %r9
	leaq	(%rdi,%r9), %r8
	cmpq	$32, %rcx
	movq	%rdx, 24(%rsp)                  # 8-byte Spill
	jb	.LBB19_118
# %bb.112:                              #   in Loop: Header=BB19_106 Depth=1
	testq	%r9, %r9
	je	.LBB19_113
# %bb.136:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%rdi, %r9
	xorl	%esi, %esi
	xorl	%r10d, %r10d
	xorl	%edx, %edx
	jmp	.LBB19_137
	.p2align	4
.LBB19_139:                             #   in Loop: Header=BB19_137 Depth=2
	movq	%r10, %rdi
.LBB19_143:                             #   in Loop: Header=BB19_137 Depth=2
	movq	%rdi, %r10
	leaq	(%r9,%rax), %rdi
	incq	%rsi
.LBB19_144:                             #   in Loop: Header=BB19_137 Depth=2
	addq	%rax, %r9
	cmpq	%r8, %r9
	jae	.LBB19_133
.LBB19_137:                             #   Parent Loop BB19_106 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	testb	$1, (%r9)
	je	.LBB19_144
# %bb.138:                              #   in Loop: Header=BB19_137 Depth=2
	cmpq	%r9, %rdi
	jae	.LBB19_139
# %bb.140:                              #   in Loop: Header=BB19_137 Depth=2
	movq	%r9, (%rdi)
	movq	$0, 8(%rdi)
	testq	%r10, %r10
	je	.LBB19_141
# %bb.142:                              #   in Loop: Header=BB19_137 Depth=2
	movq	%rdi, 8(%r10)
	jmp	.LBB19_143
.LBB19_141:                             #   in Loop: Header=BB19_137 Depth=2
	movq	%rdi, %rdx
	jmp	.LBB19_143
	.p2align	4
.LBB19_118:                             #   in Loop: Header=BB19_106 Depth=1
	movq	%r11, 96(%rsp)                  # 8-byte Spill
	movq	%rbx, 32(%rsp)                  # 8-byte Spill
	movq	%r13, 64(%rsp)                  # 8-byte Spill
	addq	$1136, %r9                      # imm = 0x470
	shrq	$4, %r9
	leaq	63(%r9), %r10
	shrq	$6, %r10
	movl	$1, %r15d
	xorl	%edx, %edx
	xorl	%r12d, %r12d
	xorl	%esi, %esi
	jmp	.LBB19_119
	.p2align	4
.LBB19_130:                             #   in Loop: Header=BB19_119 Depth=2
	incq	%r15
	cmpq	%r10, %r15
	je	.LBB19_114
.LBB19_119:                             #   Parent Loop BB19_106 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB19_121 Depth 3
	movq	72(%r14,%r15,8), %r13
	testq	%r13, %r13
	je	.LBB19_130
# %bb.120:                              #   in Loop: Header=BB19_119 Depth=2
	movq	%r15, %r11
	shlq	$6, %r11
	jmp	.LBB19_121
	.p2align	4
.LBB19_124:                             #   in Loop: Header=BB19_121 Depth=3
	movq	%r12, %rdi
.LBB19_128:                             #   in Loop: Header=BB19_121 Depth=3
	addq	%rax, %rbx
	incq	%rsi
	movq	%rdi, %r12
	movq	%rbx, %rdi
.LBB19_129:                             #   in Loop: Header=BB19_121 Depth=3
	blsrq	%r13, %r13
	je	.LBB19_130
.LBB19_121:                             #   Parent Loop BB19_106 Depth=1
                                        #     Parent Loop BB19_119 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	tzcntq	%r13, %rbx
	orq	%r11, %rbx
	cmpq	$71, %rbx
	jb	.LBB19_129
# %bb.122:                              #   in Loop: Header=BB19_121 Depth=3
	cmpq	%r9, %rbx
	jae	.LBB19_129
# %bb.123:                              #   in Loop: Header=BB19_121 Depth=3
	shlq	$4, %rbx
	addq	%r14, %rbx
	cmpq	%rbx, %rdi
	jae	.LBB19_124
# %bb.125:                              #   in Loop: Header=BB19_121 Depth=3
	movq	%rbx, (%rdi)
	movq	$0, 8(%rdi)
	testq	%r12, %r12
	je	.LBB19_126
# %bb.127:                              #   in Loop: Header=BB19_121 Depth=3
	movq	%rdi, 8(%r12)
	jmp	.LBB19_128
.LBB19_126:                             #   in Loop: Header=BB19_121 Depth=3
	movq	%rdi, %rdx
	jmp	.LBB19_128
	.p2align	4
.LBB19_114:                             #   in Loop: Header=BB19_106 Depth=1
	cmpq	%r8, %rdi
	jae	.LBB19_115
# %bb.116:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%r8, (%rdi)
	movq	$0, 8(%rdi)
	testq	%r12, %r12
	movq	16(%rsp), %r15                  # 8-byte Reload
	movq	64(%rsp), %r13                  # 8-byte Reload
	movq	32(%rsp), %rbx                  # 8-byte Reload
	movq	96(%rsp), %r11                  # 8-byte Reload
	je	.LBB19_117
# %bb.131:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%rdi, 8(%r12)
	jmp	.LBB19_132
.LBB19_133:                             #   in Loop: Header=BB19_106 Depth=1
	cmpq	%r8, %rdi
	jae	.LBB19_146
# %bb.134:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%r8, (%rdi)
	movq	$0, 8(%rdi)
	testq	%r10, %r10
	je	.LBB19_135
# %bb.145:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%rdi, 8(%r10)
	jmp	.LBB19_146
.LBB19_115:                             #   in Loop: Header=BB19_106 Depth=1
	movq	16(%rsp), %r15                  # 8-byte Reload
	movq	64(%rsp), %r13                  # 8-byte Reload
	movq	32(%rsp), %rbx                  # 8-byte Reload
	movq	96(%rsp), %r11                  # 8-byte Reload
	jmp	.LBB19_132
.LBB19_113:                             #   in Loop: Header=BB19_106 Depth=1
	xorl	%edx, %edx
	xorl	%r12d, %r12d
	xorl	%esi, %esi
	jmp	.LBB19_147
.LBB19_117:                             #   in Loop: Header=BB19_106 Depth=1
	movq	%rdi, %rdx
	.p2align	4
.LBB19_132:                             #   in Loop: Header=BB19_106 Depth=1
	vmovdqu	72(%r14), %ymm1
	vmovdqu	104(%r14), %ymm2
	vmovdqu	136(%r14), %ymm3
	vmovdqu	168(%r14), %ymm4
	vpand	584(%r14), %ymm1, %ymm5
	vpand	616(%r14), %ymm2, %ymm6
	vpand	648(%r14), %ymm3, %ymm7
	vpand	680(%r14), %ymm4, %ymm0
	vmovdqu	%ymm5, 584(%r14)
	vmovdqu	%ymm6, 616(%r14)
	vmovdqu	%ymm7, 648(%r14)
	vmovdqu	%ymm0, 680(%r14)
	vpxor	%ymm1, %ymm5, %ymm1
	vpxor	%ymm2, %ymm6, %ymm2
	vpxor	%ymm3, %ymm7, %ymm3
	vpxor	%ymm4, %ymm0, %ymm4
	vmovdqu	%ymm1, 72(%r14)
	vmovdqu	%ymm2, 104(%r14)
	vmovdqu	%ymm3, 136(%r14)
	vmovdqu	%ymm4, 168(%r14)
	vpbroadcastb	.LCPI19_3(%rip), %ymm15 # ymm15 = [15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15]
	vpand	%ymm5, %ymm15, %ymm1
	vmovdqa	.LCPI19_1(%rip), %ymm13         # ymm13 = [0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4]
	vpshufb	%ymm1, %ymm13, %ymm1
	vmovdqa	160(%rsp), %ymm12               # 32-byte Reload
	vgf2p8affineqb	$0, %ymm12, %ymm5, %ymm2
	vpshufb	%ymm2, %ymm13, %ymm2
	vpaddb	%ymm1, %ymm2, %ymm1
	vpxor	%xmm14, %xmm14, %xmm14
	vpsadbw	%ymm1, %ymm14, %ymm3
	vpand	%ymm6, %ymm15, %ymm1
	vpshufb	%ymm1, %ymm13, %ymm1
	vgf2p8affineqb	$0, %ymm12, %ymm6, %ymm2
	vpshufb	%ymm2, %ymm13, %ymm2
	vpaddb	%ymm1, %ymm2, %ymm1
	vpsadbw	%ymm1, %ymm14, %ymm2
	vpand	%ymm7, %ymm15, %ymm1
	vpshufb	%ymm1, %ymm13, %ymm1
	vgf2p8affineqb	$0, %ymm12, %ymm7, %ymm4
	vpshufb	%ymm4, %ymm13, %ymm4
	vpaddb	%ymm1, %ymm4, %ymm1
	vpsadbw	%ymm1, %ymm14, %ymm1
	vpand	%ymm0, %ymm15, %ymm4
	vpshufb	%ymm4, %ymm13, %ymm4
	vgf2p8affineqb	$0, %ymm12, %ymm0, %ymm0
	vpshufb	%ymm0, %ymm13, %ymm0
	vpaddb	%ymm4, %ymm0, %ymm0
	vpsadbw	%ymm0, %ymm14, %ymm0
	vmovdqu	200(%r14), %ymm5
	vmovdqu	232(%r14), %ymm6
	vmovdqu	264(%r14), %ymm7
	vmovdqu	296(%r14), %ymm8
	vpand	712(%r14), %ymm5, %ymm9
	vpand	744(%r14), %ymm6, %ymm10
	vpand	776(%r14), %ymm7, %ymm11
	vpand	808(%r14), %ymm8, %ymm4
	vmovdqu	%ymm9, 712(%r14)
	vmovdqu	%ymm10, 744(%r14)
	vmovdqu	%ymm11, 776(%r14)
	vmovdqu	%ymm4, 808(%r14)
	vpxor	%ymm5, %ymm9, %ymm5
	vpxor	%ymm6, %ymm10, %ymm6
	vpxor	%ymm7, %ymm11, %ymm7
	vpxor	%ymm4, %ymm8, %ymm8
	vmovdqu	%ymm5, 200(%r14)
	vmovdqu	%ymm6, 232(%r14)
	vmovdqu	%ymm7, 264(%r14)
	vmovdqu	%ymm8, 296(%r14)
	vpand	%ymm15, %ymm9, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm9, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm5, %ymm6, %ymm5
	vpsadbw	%ymm5, %ymm14, %ymm5
	vpaddq	%ymm3, %ymm5, %ymm3
	vpand	%ymm15, %ymm10, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm10, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm5, %ymm6, %ymm5
	vpsadbw	%ymm5, %ymm14, %ymm5
	vpaddq	%ymm2, %ymm5, %ymm2
	vmovdqa	%ymm2, 96(%rsp)                 # 32-byte Spill
	vpand	%ymm15, %ymm11, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm11, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm5, %ymm6, %ymm5
	vpsadbw	%ymm5, %ymm14, %ymm5
	vpaddq	%ymm1, %ymm5, %ymm1
	vmovdqa	%ymm1, 64(%rsp)                 # 32-byte Spill
	vpand	%ymm4, %ymm15, %ymm5
	vmovdqa	%ymm15, %ymm2
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm4, %ymm4
	vpshufb	%ymm4, %ymm13, %ymm4
	vpaddb	%ymm5, %ymm4, %ymm4
	vpsadbw	%ymm4, %ymm14, %ymm4
	vpaddq	%ymm0, %ymm4, %ymm0
	vmovdqa	%ymm0, 32(%rsp)                 # 32-byte Spill
	vmovdqu	328(%r14), %ymm5
	vmovdqu	360(%r14), %ymm6
	vmovdqu	392(%r14), %ymm7
	vmovdqu	424(%r14), %ymm8
	vpand	840(%r14), %ymm5, %ymm9
	vpand	872(%r14), %ymm6, %ymm10
	vpand	904(%r14), %ymm7, %ymm11
	vpand	936(%r14), %ymm8, %ymm4
	vmovdqu	%ymm9, 840(%r14)
	vmovdqu	%ymm10, 872(%r14)
	vmovdqu	%ymm11, 904(%r14)
	vmovdqu	%ymm4, 936(%r14)
	vpxor	%ymm5, %ymm9, %ymm5
	vpxor	%ymm6, %ymm10, %ymm6
	vpxor	%ymm7, %ymm11, %ymm7
	vpxor	%ymm4, %ymm8, %ymm8
	vmovdqu	%ymm5, 328(%r14)
	vmovdqu	%ymm6, 360(%r14)
	vmovdqu	%ymm7, 392(%r14)
	vmovdqu	%ymm8, 424(%r14)
	vpand	%ymm15, %ymm9, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm9, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm5, %ymm6, %ymm7
	vpand	%ymm15, %ymm10, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm10, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm5, %ymm6, %ymm6
	vpand	%ymm15, %ymm11, %ymm5
	vpshufb	%ymm5, %ymm13, %ymm5
	vgf2p8affineqb	$0, %ymm12, %ymm11, %ymm8
	vpshufb	%ymm8, %ymm13, %ymm8
	vpaddb	%ymm5, %ymm8, %ymm5
	vpand	%ymm4, %ymm15, %ymm8
	vpshufb	%ymm8, %ymm13, %ymm8
	vgf2p8affineqb	$0, %ymm12, %ymm4, %ymm4
	vpshufb	%ymm4, %ymm13, %ymm4
	vpaddb	%ymm4, %ymm8, %ymm4
	vmovdqu	456(%r14), %ymm10
	vmovdqu	488(%r14), %ymm11
	vmovdqu	520(%r14), %ymm0
	vmovdqu	552(%r14), %ymm1
	vpand	968(%r14), %ymm10, %ymm14
	vpand	1000(%r14), %ymm11, %ymm15
	vpand	1032(%r14), %ymm0, %ymm9
	vpand	1064(%r14), %ymm1, %ymm8
	vmovdqu	%ymm14, 968(%r14)
	vmovdqu	%ymm15, 1000(%r14)
	vmovdqu	%ymm9, 1032(%r14)
	vmovdqu	%ymm8, 1064(%r14)
	vpxor	%ymm10, %ymm14, %ymm10
	vmovdqu	%ymm10, 456(%r14)
	vpxor	%ymm11, %ymm15, %ymm10
	vmovdqu	%ymm10, 488(%r14)
	vpxor	%ymm0, %ymm9, %ymm10
	vmovdqu	%ymm10, 520(%r14)
	vpxor	%ymm1, %ymm8, %ymm10
	vmovdqu	%ymm10, 552(%r14)
	vpand	%ymm2, %ymm14, %ymm10
	vpshufb	%ymm10, %ymm13, %ymm10
	vgf2p8affineqb	$0, %ymm12, %ymm14, %ymm11
	vpshufb	%ymm11, %ymm13, %ymm11
	vpaddb	%ymm10, %ymm11, %ymm10
	vpxor	%xmm0, %xmm0, %xmm0
	vpsadbw	%ymm0, %ymm7, %ymm7
	vpsadbw	%ymm0, %ymm10, %ymm10
	vpaddq	%ymm7, %ymm10, %ymm7
	vpaddq	%ymm3, %ymm7, %ymm3
	vpand	%ymm2, %ymm15, %ymm7
	vmovdqa	%ymm2, %ymm11
	vpshufb	%ymm7, %ymm13, %ymm7
	vgf2p8affineqb	$0, %ymm12, %ymm15, %ymm10
	vpshufb	%ymm10, %ymm13, %ymm10
	vpaddb	%ymm7, %ymm10, %ymm7
	vpsadbw	%ymm0, %ymm6, %ymm6
	vpsadbw	%ymm0, %ymm7, %ymm7
	vpaddq	%ymm6, %ymm7, %ymm6
	vpaddq	96(%rsp), %ymm6, %ymm2          # 32-byte Folded Reload
	vpaddq	%ymm3, %ymm2, %ymm2
	vpand	%ymm11, %ymm9, %ymm3
	vpshufb	%ymm3, %ymm13, %ymm3
	vgf2p8affineqb	$0, %ymm12, %ymm9, %ymm6
	vpshufb	%ymm6, %ymm13, %ymm6
	vpaddb	%ymm3, %ymm6, %ymm3
	vpsadbw	%ymm0, %ymm5, %ymm5
	vpsadbw	%ymm0, %ymm3, %ymm3
	vpaddq	%ymm5, %ymm3, %ymm3
	vpaddq	64(%rsp), %ymm3, %ymm1          # 32-byte Folded Reload
	vpaddq	%ymm2, %ymm1, %ymm1
	vpand	%ymm11, %ymm8, %ymm2
	vpshufb	%ymm2, %ymm13, %ymm2
	vgf2p8affineqb	$0, %ymm12, %ymm8, %ymm3
	vpshufb	%ymm3, %ymm13, %ymm3
	vpaddb	%ymm2, %ymm3, %ymm2
	vpsadbw	%ymm0, %ymm4, %ymm3
	vpsadbw	%ymm0, %ymm2, %ymm2
	vpaddq	%ymm3, %ymm2, %ymm2
	vpaddq	32(%rsp), %ymm2, %ymm0          # 32-byte Folded Reload
	vpaddq	%ymm1, %ymm0, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              # xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %r12
	jmp	.LBB19_147
.LBB19_135:                             #   in Loop: Header=BB19_106 Depth=1
	movq	%rdi, %rdx
.LBB19_146:                             #   in Loop: Header=BB19_106 Depth=1
	xorl	%r12d, %r12d
.LBB19_147:                             #   in Loop: Header=BB19_106 Depth=1
	movq	%rdx, 40(%r14)
	movq	%rsi, 48(%r14)
	testq	%r12, %r12
	setne	64(%r14)
	imulq	%rax, %r12
	addq	%r11, %r12
	testq	%rsi, %rsi
	jne	.LBB19_155
# %bb.148:                              #   in Loop: Header=BB19_106 Depth=1
	cmpq	$31, %rcx
	ja	.LBB19_155
# %bb.149:                              #   in Loop: Header=BB19_106 Depth=1
	imulq	$56, %rcx, %rcx
	movq	128(%rsp), %rsi                 # 8-byte Reload
	cmpq	%r14, (%rsi,%rcx)
	je	.LBB19_150
# %bb.151:                              #   in Loop: Header=BB19_106 Depth=1
	movq	4568(%r15), %rcx
	cmpq	4576(%r15), %rcx
	jne	.LBB19_152
# %bb.153:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%rbx, 32(%rsp)                  # 8-byte Spill
	leaq	(%rcx,%rcx), %rbx
	testq	%rcx, %rcx
	movl	$64, %eax
	cmoveq	%rax, %rbx
	movq	4560(%r15), %rdi
	leaq	(,%rbx,8), %rsi
	vzeroupper
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB19_154
# %bb.158:                              #   in Loop: Header=BB19_106 Depth=1
	movq	%rax, 4560(%r15)
	movq	%rbx, 4576(%r15)
	movq	4568(%r15), %rcx
	movq	32(%rsp), %rbx                  # 8-byte Reload
	jmp	.LBB19_159
.LBB19_150:                             #   in Loop: Header=BB19_106 Depth=1
	xorl	%esi, %esi
	jmp	.LBB19_155
.LBB19_152:                             #   in Loop: Header=BB19_106 Depth=1
	movq	4560(%r15), %rax
.LBB19_159:                             #   in Loop: Header=BB19_106 Depth=1
	leaq	1(%rcx), %rdx
	movq	%rdx, 4568(%r15)
	movq	%r14, (%rax,%rcx,8)
	movq	(%r14), %rax
	movq	24(%rsp), %rdx                  # 8-byte Reload
	movq	%rax, (%rdx)
	movq	%r12, %r11
	movq	%rax, %r14
	testq	%rax, %rax
	jne	.LBB19_106
	jmp	.LBB19_161
.LBB19_154:                             #   in Loop: Header=BB19_106 Depth=1
	movq	48(%r14), %rsi
	movq	8(%r14), %rax
	movq	40(%r14), %rdx
	movq	32(%rsp), %rbx                  # 8-byte Reload
	.p2align	4
.LBB19_155:                             #   in Loop: Header=BB19_106 Depth=1
	imulq	%rsi, %rax
	addq	%rax, %r13
	addq	%rsi, %rbx
	movq	$0, 56(%r14)
	testq	%rdx, %rdx
	setne	65(%r14)
	je	.LBB19_157
# %bb.156:                              #   in Loop: Header=BB19_106 Depth=1
	imulq	$56, 32(%r14), %rax
	movq	1512(%r15,%rax), %rcx
	movq	%rcx, 56(%r14)
	movq	%r14, 1512(%r15,%rax)
.LBB19_157:                             #   in Loop: Header=BB19_106 Depth=1
	movq	%r12, %r11
	jmp	.LBB19_109
.LBB19_104:
	xorl	%r12d, %r12d
	xorl	%ebx, %ebx
	xorl	%r13d, %r13d
.LBB19_161:
	movq	176(%r15), %rax
	addq	%r13, %rax
	movq	%rax, 24(%r15)
	movq	64(%r15), %rax
	addq	%rbx, %rax
	subq	4504(%r15), %rax
	movq	%rax, 64(%r15)
	movq	%rbx, 4504(%r15)
	movq	%r12, 4496(%r15)
	movq	4440(%r15), %rdx
	testq	%rdx, %rdx
	je	.LBB19_167
# %bb.162:
	movq	4432(%r15), %rcx
	movl	%edx, %eax
	andl	$3, %eax
	cmpq	$4, %rdx
	jae	.LBB19_170
# %bb.163:
	xorl	%esi, %esi
	jmp	.LBB19_165
.LBB19_170:
	andq	$-4, %rdx
	xorl	%esi, %esi
	.p2align	4
.LBB19_171:                             # =>This Inner Loop Header: Depth=1
	movq	(%rcx,%rsi,8), %rdi
	andq	$-2, (%rdi)
	movq	8(%rcx,%rsi,8), %rdi
	andq	$-2, (%rdi)
	movq	16(%rcx,%rsi,8), %rdi
	andq	$-2, (%rdi)
	movq	24(%rcx,%rsi,8), %rdi
	andq	$-2, (%rdi)
	addq	$4, %rsi
	cmpq	%rsi, %rdx
	jne	.LBB19_171
# %bb.164:
	testq	%rax, %rax
	je	.LBB19_167
.LBB19_165:
	leaq	(%rcx,%rsi,8), %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB19_166:                             # =>This Inner Loop Header: Depth=1
	movq	(%rcx,%rdx,8), %rsi
	andq	$-2, (%rsi)
	incq	%rdx
	cmpq	%rdx, %rax
	jne	.LBB19_166
.LBB19_167:
	movq	%r13, %rax
	shrq	%rax
	cmpq	$4194305, %rax                  # imm = 0x400001
	movl	$4194304, %ecx                  # imm = 0x400000
	cmovaeq	%rax, %rcx
	addq	%r13, %rcx
	movq	$-1, %rax
	cmovbq	%rax, %rcx
	movq	%rcx, 96(%r15)
	movq	%r13, %rcx
	subq	%r12, %rcx
	movq	%rcx, 4488(%r15)
	testq	%r13, %r13
	js	.LBB19_169
# %bb.168:
	addq	%r13, %r13
	addq	$4194304, %r13                  # imm = 0x400000
	cmovaeq	%r13, %rax
.LBB19_169:
	movq	%rax, 4456(%r15)
.LBB19_102:
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB19_54:
	.cfi_def_cfa %rbp, 16
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.3.50, %edi
	movl	$67, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	callq	abort@PLT
.Lfunc_end19:
	.size	collect, .Lfunc_end19-collect
	.cfi_endproc
                                        # -- End function
	.section	.text.trace,"ax",@progbits
	.p2align	4                               # -- Begin function trace
	.type	trace,@function
trace:                                  # @trace
.Lfunc_begin20:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	88(%rsi), %eax
	cmpl	$1, %eax
	jne	.LBB20_1
.LBB20_30:
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB20_1:
	.cfi_def_cfa %rbp, 16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	movzwl	48(%rsi), %ecx
	cmpl	$6, %ecx
	ja	.LBB20_3
# %bb.2:
	movl	$98, %edx
	btl	%ecx, %edx
	jae	.LBB20_3
# %bb.31:
	movq	(%rbx), %rsi
	movq	%r14, %rdi
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	mark                            # TAILCALL
.LBB20_3:
	.cfi_def_cfa %rbp, 16
	movq	96(%r15), %r12
	testq	%r12, %r12
	je	.LBB20_16
# %bb.4:
	cmpl	$0, 104(%r14)
	je	.LBB20_10
# %bb.5:
	leaq	-176(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	$8, -64(%rbp)
	movq	$0, -56(%rbp)
	leaq	-72(%rbp), %rdi
	movabsq	$-4294967296, %rcx              # imm = 0xFFFFFFFF00000000
	movq	%r15, %rsi
	xorl	%edx, %edx
	xorl	%r8d, %r8d
	callq	flatten
	testl	%eax, %eax
	je	.LBB20_9
# %bb.6:
	movq	-56(%rbp), %r13
	cmpq	104(%r15), %r13
	jne	.LBB20_9
# %bb.7:
	testq	%r13, %r13
	je	.LBB20_30
# %bb.8:
	movq	96(%r15), %rsi
	leaq	(,%r13,4), %rax
	leaq	(%rax,%rax,2), %rdx
	leaq	-176(%rbp), %rdi
	callq	bcmp@PLT
	testl	%eax, %eax
	je	.LBB20_11
.LBB20_9:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rcx
	movl	$.L.str.3.50, %edi
	movl	$67, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	callq	abort@PLT
.LBB20_16:
	cmpl	$2, %ecx
	je	.LBB20_22
# %bb.17:
	cmpl	$4, %ecx
	je	.LBB20_22
# %bb.18:
	cmpl	$3, %ecx
	jne	.LBB20_30
# %bb.19:
	cmpq	$0, 32(%r15)
	je	.LBB20_30
# %bb.20:
	leaq	16(%r15), %rcx
	leaq	72(%r15), %rdx
	cmpl	$2, %eax
	cmoveq	%rdx, %rcx
	movq	(%rcx), %r12
	xorl	%r13d, %r13d
	.p2align	4
.LBB20_21:                              # =>This Inner Loop Header: Depth=1
	movq	8(%r12), %rsi
	movq	40(%r15), %rdx
	imulq	%r13, %rdx
	addq	%rbx, %rdx
	movq	%r14, %rdi
	callq	trace
	incq	%r13
	cmpq	32(%r15), %r13
	jb	.LBB20_21
	jmp	.LBB20_30
.LBB20_10:
	movq	104(%r15), %r13
	testq	%r13, %r13
	je	.LBB20_30
.LBB20_11:
	addq	$8, %r12
	movl	$4294967295, %r15d              # imm = 0xFFFFFFFF
	jmp	.LBB20_12
	.p2align	4
.LBB20_14:                              #   in Loop: Header=BB20_12 Depth=1
	movl	-8(%r12), %eax
	movq	(%rbx,%rax), %rsi
	movq	%r14, %rdi
	callq	mark
.LBB20_15:                              #   in Loop: Header=BB20_12 Depth=1
	addq	$12, %r12
	decq	%r13
	je	.LBB20_30
.LBB20_12:                              # =>This Inner Loop Header: Depth=1
	movl	-4(%r12), %eax
	cmpq	%r15, %rax
	je	.LBB20_14
# %bb.13:                               #   in Loop: Header=BB20_12 Depth=1
	movl	(%rbx,%rax), %eax
	cmpl	(%r12), %eax
	je	.LBB20_14
	jmp	.LBB20_15
.LBB20_22:
	leaq	16(%r15), %rdx
	leaq	72(%r15), %rsi
	leaq	24(%r15), %rdi
	leaq	80(%r15), %r8
	cmpl	$2, %eax
	cmoveq	%rsi, %rdx
	cmovneq	%rdi, %r8
	movq	(%r8), %r12
	movl	$0, -44(%rbp)                   # 4-byte Folded Spill
	cmpl	$4, %ecx
	jne	.LBB20_24
# %bb.23:
	movl	(%rbx), %eax
	movl	%eax, -44(%rbp)                 # 4-byte Spill
.LBB20_24:
	testq	%r12, %r12
	je	.LBB20_30
# %bb.25:
	movq	(%rdx), %r13
	addq	$16, %r13
	jmp	.LBB20_26
	.p2align	4
.LBB20_28:                              #   in Loop: Header=BB20_26 Depth=1
	movq	-8(%r13), %rsi
	movq	-16(%r13), %rdx
	addq	%rbx, %rdx
	movq	%r14, %rdi
	callq	trace
.LBB20_29:                              #   in Loop: Header=BB20_26 Depth=1
	addq	$24, %r13
	decq	%r12
	je	.LBB20_30
.LBB20_26:                              # =>This Inner Loop Header: Depth=1
	cmpw	$2, 48(%r15)
	je	.LBB20_28
# %bb.27:                               #   in Loop: Header=BB20_26 Depth=1
	movl	-44(%rbp), %eax                 # 4-byte Reload
	cmpl	(%r13), %eax
	je	.LBB20_28
	jmp	.LBB20_29
.Lfunc_end20:
	.size	trace, .Lfunc_end20-trace
	.cfi_endproc
                                        # -- End function
	.section	.text.mark,"ax",@progbits
	.p2align	4                               # -- Begin function mark
	.type	mark,@function
mark:                                   # @mark
.Lfunc_begin21:
	.cfi_startproc
# %bb.0:
	testq	%rsi, %rsi
	je	.LBB21_32
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	addq	$-16, %rsi
	movq	%rsi, %rax
	shrq	$21, %rax
	movl	%eax, %ecx
	andl	$127, %ecx
	movl	%ecx, %edx
	cmpq	%rax, 4616(%rdi,%rdx,8)
	je	.LBB21_8
# %bb.2:
	movq	4608(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB21_23
# %bb.3:
	movq	4600(%rdi), %r8
	decq	%rdx
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%rax, %r9
	shrq	$32, %r9
	.p2align	4
.LBB21_4:                               # =>This Inner Loop Header: Depth=1
	andq	%rdx, %r9
	movq	(%r8,%r9,8), %r10
	testq	%r10, %r10
	je	.LBB21_6
# %bb.5:                                #   in Loop: Header=BB21_4 Depth=1
	incq	%r9
	cmpq	%rax, %r10
	jne	.LBB21_4
.LBB21_6:
	cmpq	%rax, %r10
	jne	.LBB21_23
# %bb.7:
	movq	%rax, 4616(%rdi,%rcx,8)
.LBB21_8:
	movq	%rsi, %rbx
	andq	$-65536, %rbx                   # imm = 0xFFFF0000
	movl	%esi, %eax
	shrl	$4, %eax
	movl	%esi, %r14d
	shrl	$10, %r14d
	andl	$63, %r14d
	movl	$1, %ecx
	shlxq	%rax, %rcx, %r15
	movq	72(%rbx,%r14,8), %rcx
	btq	%rax, %rcx
	jae	.LBB21_11
# %bb.9:
	testq	%r15, 584(%rbx,%r14,8)
	je	.LBB21_31
# %bb.10:
	movb	$1, 4469(%rdi)
	jmp	.LBB21_31
.LBB21_23:
	movq	(%rsi), %rbx
	movabsq	$4611686018427387907, %rax      # imm = 0x4000000000000003
	testq	%rax, %rbx
	jne	.LBB21_31
# %bb.24:
	movq	1256(%rdi), %rcx
	cmpq	1264(%rdi), %rcx
	jne	.LBB21_25
# %bb.26:
	leaq	(%rcx,%rcx), %rax
	testq	%rcx, %rcx
	movl	$1024, %r14d                    # imm = 0x400
	cmovneq	%rax, %r14
	cmpq	%rcx, %r14
	jbe	.LBB21_30
# %bb.27:
	movq	8(%rdi), %rax
	leaq	(,%r14,8), %rcx
	movq	%rdi, %r15
	movq	%rax, %rdi
	movq	%rsi, %r12
	movq	%rcx, %rsi
	callq	realloc@PLT
	movq	%r15, %rdi
	testq	%rax, %rax
	je	.LBB21_30
# %bb.28:
	movq	%r12, %rsi
	movq	%rax, 8(%rdi)
	movq	%r14, 1264(%rdi)
	movq	1256(%rdi), %rcx
	jmp	.LBB21_29
.LBB21_11:
	movq	1256(%rdi), %rcx
	cmpq	1264(%rdi), %rcx
	jne	.LBB21_12
# %bb.13:
	leaq	(%rcx,%rcx), %rax
	testq	%rcx, %rcx
	movl	$1024, %r12d                    # imm = 0x400
	cmovneq	%rax, %r12
	cmpq	%rcx, %r12
	jbe	.LBB21_30
# %bb.14:
	movq	8(%rdi), %rax
	leaq	(,%r12,8), %rcx
	movq	%rdi, -48(%rbp)                 # 8-byte Spill
	movq	%rax, %rdi
	movq	%rsi, %r13
	movq	%rcx, %rsi
	callq	realloc@PLT
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	testq	%rax, %rax
	je	.LBB21_30
# %bb.15:
	movq	%r13, %rsi
	movq	%rax, 8(%rdi)
	movq	%r12, 1264(%rdi)
	movq	1256(%rdi), %rcx
	jmp	.LBB21_16
.LBB21_30:
	movl	$1, 1272(%rdi)
	jmp	.LBB21_31
.LBB21_12:
	movq	8(%rdi), %rax
.LBB21_16:
	leaq	1(%rcx), %rdx
	movq	%rdx, 1256(%rdi)
	movq	%rsi, (%rax,%rcx,8)
	orq	%r15, 72(%rbx,%r14,8)
	movzbl	4468(%rdi), %eax
	testl	%eax, %eax
	je	.LBB21_20
# %bb.17:
	cmpl	$1, %eax
	jne	.LBB21_18
# %bb.21:
	movq	584(%rbx,%r14,8), %rax
	testq	%r15, %rax
	jne	.LBB21_19
# %bb.22:
	orq	%r15, %rax
	movq	%rax, 584(%rbx,%r14,8)
	movb	$1, 4469(%rdi)
	jmp	.LBB21_31
.LBB21_25:
	movq	8(%rdi), %rax
.LBB21_29:
	leaq	1(%rcx), %rdx
	movq	%rdx, 1256(%rdi)
	movq	%rsi, (%rax,%rcx,8)
	orq	$1, %rbx
	movq	%rbx, (%rsi)
	jmp	.LBB21_31
.LBB21_18:
	movq	584(%rbx,%r14,8), %rax
.LBB21_19:
	andnq	%rax, %r15, %rax
	movq	%rax, 584(%rbx,%r14,8)
.LBB21_20:
	orb	$1, (%rsi)
.LBB21_31:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
.LBB21_32:
	retq
.Lfunc_end21:
	.size	mark, .Lfunc_end21-mark
	.cfi_endproc
                                        # -- End function
	.section	.text.flatten,"ax",@progbits
	.p2align	4                               # -- Begin function flatten
	.type	flatten,@function
flatten:                                # @flatten
.Lfunc_begin22:
	.cfi_startproc
# %bb.0:
	movl	88(%rsi), %r9d
	cmpl	$1, %r9d
	jne	.LBB22_1
# %bb.23:
	movl	$1, %eax
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB22_1:
	movl	$4294967295, %r10d              # imm = 0xFFFFFFFF
	subq	(%rsi), %r10
	xorl	%eax, %eax
	cmpq	%r10, %rdx
	jbe	.LBB22_2
# %bb.24:
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB22_2:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r15
	shrq	$32, %r15
	movzwl	48(%rsi), %r10d
	cmpl	$6, %r10d
	ja	.LBB22_8
# %bb.3:
	movl	$98, %r11d
	btl	%r10d, %r11d
	jae	.LBB22_8
# %bb.4:
	movq	16(%rdi), %rcx
	cmpq	8(%rdi), %rcx
	je	.LBB22_7
# %bb.5:
	movq	(%rdi), %rax
	leaq	1(%rcx), %rsi
	movq	%rsi, 16(%rdi)
	leaq	(%rcx,%rcx,2), %rcx
	movl	%edx, (%rax,%rcx,4)
	movl	%r15d, 4(%rax,%rcx,4)
	movl	%r8d, 8(%rax,%rcx,4)
.LBB22_6:
	movl	$1, %eax
.LBB22_7:
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
                                        # kill: def $eax killed $eax killed $rax
	retq
.LBB22_8:
	.cfi_def_cfa %rbp, 16
	.cfi_offset %rbx, -56
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	16(%rsi), %r11
	leaq	72(%rsi), %rbx
	cmpl	$2, %r9d
	cmoveq	%rbx, %r11
	movq	(%r11), %rbx
	cmpl	$2, %r10d
	movl	%r8d, -44(%rbp)                 # 4-byte Spill
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	movq	%rdi, %r13
	movq	%rcx, %r14
	movq	%rsi, -56(%rbp)                 # 8-byte Spill
	je	.LBB22_15
# %bb.9:
	cmpl	$4, %r10d
	je	.LBB22_15
# %bb.10:
	cmpl	$3, %r10d
	jne	.LBB22_6
# %bb.11:
	cmpq	$0, 32(%rsi)
	je	.LBB22_6
# %bb.12:
	xorl	%r15d, %r15d
.LBB22_13:                              # =>This Inner Loop Header: Depth=1
	movq	8(%rbx), %rax
	movq	40(%rsi), %r9
	imulq	%r15, %r9
	addq	%rdx, %r9
	movq	%rax, %rsi
	movq	%r9, %rdx
	callq	flatten
	testl	%eax, %eax
	je	.LBB22_22
# %bb.14:                               #   in Loop: Header=BB22_13 Depth=1
	incq	%r15
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	cmpq	32(%rsi), %r15
	movl	-44(%rbp), %r8d                 # 4-byte Reload
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	%r13, %rdi
	movq	%r14, %rcx
	jb	.LBB22_13
	jmp	.LBB22_6
.LBB22_15:
	leaq	24(%rsi), %r11
	leaq	80(%rsi), %r12
	cmpl	$2, %r9d
	cmoveq	%r12, %r11
	cmpl	$4, %r10d
	sete	%r9b
	movl	$4294967295, %r10d              # imm = 0xFFFFFFFF
	cmpq	%r10, %r15
	setne	%r10b
	testb	%r10b, %r9b
	jne	.LBB22_7
# %bb.16:
	movq	(%r11), %r12
	testq	%r12, %r12
	je	.LBB22_6
# %bb.17:
	movl	%edx, %eax
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	addq	$16, %rbx
.LBB22_18:                              # =>This Inner Loop Header: Depth=1
	cmpw	$4, 48(%rsi)
	movq	%r15, %r9
	jne	.LBB22_20
# %bb.19:                               #   in Loop: Header=BB22_18 Depth=1
	movl	(%rbx), %r8d
	xorl	%ecx, %ecx
	movq	-72(%rbp), %r9                  # 8-byte Reload
.LBB22_20:                              #   in Loop: Header=BB22_18 Depth=1
	movq	-8(%rbx), %rsi
	movq	-16(%rbx), %rax
	addq	%rdx, %rax
	shlq	$32, %r9
	movl	%ecx, %ecx
	orq	%r9, %rcx
	movq	%rax, %rdx
	callq	flatten
	testl	%eax, %eax
	je	.LBB22_22
# %bb.21:                               #   in Loop: Header=BB22_18 Depth=1
	addq	$24, %rbx
	decq	%r12
	movl	-44(%rbp), %r8d                 # 4-byte Reload
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	%r13, %rdi
	movq	%r14, %rcx
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	jne	.LBB22_18
	jmp	.LBB22_6
.LBB22_22:
	xorl	%eax, %eax
	jmp	.LBB22_7
.Lfunc_end22:
	.size	flatten, .Lfunc_end22-flatten
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_native_arena_reclaim,"ax",@progbits
	.p2align	4                               # -- Begin function myl_native_arena_reclaim
	.type	myl_native_arena_reclaim,@function
myl_native_arena_reclaim:               # @myl_native_arena_reclaim
.Lfunc_begin23:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	%rdi, %rbx
	movq	1248(%rdi), %rdi
	jmp	.LBB23_1
	.p2align	4
.LBB23_4:                               #   in Loop: Header=BB23_1 Depth=1
	callq	free@PLT
	movq	1248(%rbx), %rdi
.LBB23_1:                               # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB23_5
# %bb.2:                                #   in Loop: Header=BB23_1 Depth=1
	movq	(%rdi), %rax
	movq	%rax, 1248(%rbx)
	cmpq	$0, 5640(%rbx)
	je	.LBB23_4
# %bb.3:                                #   in Loop: Header=BB23_1 Depth=1
	movq	8(%rdi), %rax
	subq	%rax, 24(%rbx)
	jmp	.LBB23_4
.LBB23_5:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 192(%rbx)
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end23:
	.size	myl_native_arena_reclaim, .Lfunc_end23-myl_native_arena_reclaim
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function myl_native_arena_release
.LCPI24_0:
	.quad	1                               # 0x1
	.zero	8
	.section	.text.myl_native_arena_release,"ax",@progbits
	.p2align	4
	.type	myl_native_arena_release,@function
myl_native_arena_release:               # @myl_native_arena_release
.Lfunc_begin24:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movq	4512(%rdi), %rax
	testq	%rax, %rax
	je	.LBB24_2
# %bb.1:
	movq	1472(%rbx), %rcx
	subq	%rax, %rcx
	addq	$-80, %rcx
	movq	%rcx, 16(%rax)
	movq	$0, 4512(%rbx)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 1472(%rbx)
.LBB24_2:
	cmpq	$0, 5640(%rbx)
	movq	4584(%rbx), %rdx
	je	.LBB24_3
# %bb.5:
	testq	%rdx, %rdx
	je	.LBB24_6
# %bb.7:
	movq	1240(%rbx), %rax
	testb	$1, %dl
	jne	.LBB24_9
# %bb.8:
	xorl	%r14d, %r14d
	movq	%rdx, %rcx
	cmpq	$1, %rdx
	jne	.LBB24_14
	jmp	.LBB24_21
.LBB24_3:
	testq	%rdx, %rdx
	je	.LBB24_59
# %bb.4:
	movl	$2097152, %r14d                 # imm = 0x200000
	jmp	.LBB24_62
	.p2align	4
.LBB24_60:                              #   in Loop: Header=BB24_62 Depth=1
	movq	4584(%rbx), %rdx
.LBB24_61:                              #   in Loop: Header=BB24_62 Depth=1
	testq	%rdx, %rdx
	je	.LBB24_59
.LBB24_62:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_63 Depth 2
	leaq	-1(%rdx), %rax
	movq	%rax, 4584(%rbx)
	movq	1240(%rbx), %rcx
	movq	-8(%rcx,%rdx,8), %rdi
	movq	$0, -8(%rcx,%rdx,8)
	movq	%rax, %rdx
	testq	%rdi, %rdi
	jne	.LBB24_63
	jmp	.LBB24_61
	.p2align	4
.LBB24_68:                              #   in Loop: Header=BB24_63 Depth=2
	callq	free@PLT
	movq	%r15, %rdi
	testq	%r15, %r15
	je	.LBB24_60
.LBB24_63:                              #   Parent Loop BB24_62 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rdi), %r15
	movq	8(%rdi), %rax
	subq	%rax, 24(%rbx)
	movq	24(%rdi), %rax
	subq	%rax, 64(%rbx)
	movq	24(%rdi), %rax
	addq	%rax, 128(%rbx)
	vmovdqu	168(%rbx), %xmm0
	vmovdqa	.LCPI24_0(%rip), %xmm1          # xmm1 = [1,u]
	vpinsrq	$1, 8(%rdi), %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 168(%rbx)
	movq	88(%rbx), %rax
	cmpq	$2097152, %rax                  # imm = 0x200000
	movl	$2097152, %ecx                  # imm = 0x200000
	cmovbq	%rax, %rcx
	testq	%rax, %rax
	movq	%rcx, %rax
	cmoveq	%r14, %rax
	cmpq	$0, 5640(%rbx)
	cmoveq	%rcx, %rax
	movq	8(%rdi), %rsi
	cmpq	$1048576, %rsi                  # imm = 0x100000
	ja	.LBB24_68
# %bb.64:                               #   in Loop: Header=BB24_63 Depth=2
	movq	192(%rbx), %rcx
	cmpq	$3, %rcx
	ja	.LBB24_68
# %bb.65:                               #   in Loop: Header=BB24_63 Depth=2
	movq	200(%rbx), %rdx
	subq	%rdx, %rax
	jbe	.LBB24_68
# %bb.66:                               #   in Loop: Header=BB24_63 Depth=2
	cmpq	%rax, %rsi
	ja	.LBB24_68
# %bb.67:                               #   in Loop: Header=BB24_63 Depth=2
	movq	1248(%rbx), %rax
	movq	%rax, (%rdi)
	movq	%rdi, 1248(%rbx)
	incq	%rcx
	movq	%rcx, 192(%rbx)
	addq	8(%rdi), %rdx
	movq	%rdx, 200(%rbx)
	movq	%r15, %rdi
	testq	%r15, %r15
	jne	.LBB24_63
	jmp	.LBB24_60
.LBB24_6:
	xorl	%r14d, %r14d
	jmp	.LBB24_22
.LBB24_9:
	leaq	-1(%rdx), %rcx
	movq	-8(%rax,%rdx,8), %rsi
	movq	$0, -8(%rax,%rdx,8)
	testq	%rsi, %rsi
	je	.LBB24_10
# %bb.11:
	xorl	%edi, %edi
	.p2align	4
.LBB24_12:                              # =>This Inner Loop Header: Depth=1
	movq	%rsi, %r14
	movq	(%rsi), %rsi
	movq	%rdi, (%r14)
	movq	%r14, %rdi
	testq	%rsi, %rsi
	jne	.LBB24_12
# %bb.13:
	cmpq	$1, %rdx
	jne	.LBB24_14
	jmp	.LBB24_21
.LBB24_10:
	xorl	%r14d, %r14d
	cmpq	$1, %rdx
	jne	.LBB24_14
	jmp	.LBB24_21
	.p2align	4
.LBB24_17:                              #   in Loop: Header=BB24_14 Depth=1
	movq	%rdx, %r14
.LBB24_19:                              #   in Loop: Header=BB24_14 Depth=1
	addq	$-2, %rcx
	je	.LBB24_20
.LBB24_14:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_70 Depth 2
                                        #     Child Loop BB24_18 Depth 2
	movq	-8(%rax,%rcx,8), %rsi
	movq	$0, -8(%rax,%rcx,8)
	testq	%rsi, %rsi
	je	.LBB24_15
	.p2align	4
.LBB24_70:                              #   Parent Loop BB24_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rsi), %rdi
	movq	%r14, (%rsi)
	movq	%rsi, %rdx
	movq	%rsi, %r14
	movq	%rdi, %rsi
	testq	%rdi, %rdi
	jne	.LBB24_70
# %bb.16:                               #   in Loop: Header=BB24_14 Depth=1
	movq	-16(%rax,%rcx,8), %rsi
	movq	$0, -16(%rax,%rcx,8)
	testq	%rsi, %rsi
	jne	.LBB24_18
	jmp	.LBB24_17
	.p2align	4
.LBB24_15:                              #   in Loop: Header=BB24_14 Depth=1
	movq	%r14, %rdx
	movq	-16(%rax,%rcx,8), %rsi
	movq	$0, -16(%rax,%rcx,8)
	testq	%rsi, %rsi
	je	.LBB24_17
	.p2align	4
.LBB24_18:                              #   Parent Loop BB24_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rsi, %r14
	movq	(%rsi), %rsi
	movq	%rdx, (%r14)
	movq	%r14, %rdx
	testq	%rsi, %rsi
	jne	.LBB24_18
	jmp	.LBB24_19
.LBB24_20:
	xorl	%ecx, %ecx
.LBB24_21:
	movq	%rcx, 4584(%rbx)
.LBB24_22:
	movl	112(%rbx), %eax
	movl	%eax, -52(%rbp)                 # 4-byte Spill
	movl	$0, 112(%rbx)
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	myl_rc_scope_unwind
	movq	%r14, -48(%rbp)                 # 8-byte Spill
	testq	%r14, %r14
	je	.LBB24_42
# %bb.23:
	movl	$40, %edx
	movq	-48(%rbp), %r13                 # 8-byte Reload
	jmp	.LBB24_24
	.p2align	4
.LBB24_35:                              #   in Loop: Header=BB24_24 Depth=1
	movq	(%r13), %r13
	testq	%r13, %r13
	je	.LBB24_36
.LBB24_24:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_26 Depth 2
	cmpq	$0, 16(%r13)
	je	.LBB24_35
# %bb.25:                               #   in Loop: Header=BB24_24 Depth=1
	leaq	80(%r13), %r14
	xorl	%r12d, %r12d
	jmp	.LBB24_26
	.p2align	4
.LBB24_34:                              #   in Loop: Header=BB24_26 Depth=2
	addq	%r15, %r12
	addq	$31, %r12
	andq	$-16, %r12
	cmpq	16(%r13), %r12
	jae	.LBB24_35
.LBB24_26:                              #   Parent Loop BB24_24 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%r14,%r12), %rax
	movq	8(%r14,%r12), %rsi
	bzhiq	%rdx, %rax, %r15
	shrq	$2, %r15
	imulq	(%rsi), %r15
	cmpq	$1, %r15
	adcq	$0, %r15
	testb	$1, %al
	jne	.LBB24_34
# %bb.27:                               #   in Loop: Header=BB24_26 Depth=2
	movq	5640(%rbx), %rdi
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB24_30
# %bb.28:                               #   in Loop: Header=BB24_26 Depth=2
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rsi, (%rcx,%rax)
	jne	.LBB24_30
# %bb.29:                               #   in Loop: Header=BB24_26 Depth=2
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB24_71
.LBB24_32:                              #   in Loop: Header=BB24_26 Depth=2
	leaq	(%r14,%r12), %rsi
	orb	$1, (%rsi)
	movq	24(%rax), %rax
	testq	%rax, %rax
	je	.LBB24_34
# %bb.33:                               #   in Loop: Header=BB24_26 Depth=2
	addq	$16, %rsi
	movq	%rbx, %rdi
	callq	*%rax
	movl	$40, %edx
	jmp	.LBB24_34
.LBB24_30:                              #   in Loop: Header=BB24_26 Depth=2
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB24_32
	jmp	.LBB24_71
.LBB24_36:
	movq	-48(%rbp), %r15                 # 8-byte Reload
	jmp	.LBB24_37
	.p2align	4
.LBB24_56:                              #   in Loop: Header=BB24_37 Depth=1
	movq	(%r15), %r15
	testq	%r15, %r15
	je	.LBB24_42
.LBB24_37:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_39 Depth 2
	cmpq	$0, 16(%r15)
	je	.LBB24_56
# %bb.38:                               #   in Loop: Header=BB24_37 Depth=1
	leaq	80(%r15), %r9
	xorl	%r12d, %r12d
	jmp	.LBB24_39
	.p2align	4
.LBB24_54:                              #   in Loop: Header=BB24_39 Depth=2
	movq	8(%rax), %rsi
	addq	$16, %rdx
	movq	%rbx, %rdi
	callq	myl_rc_edges_release
.LBB24_55:                              #   in Loop: Header=BB24_39 Depth=2
	addq	%r13, %r12
	addq	$31, %r12
	andq	$-16, %r12
	cmpq	16(%r15), %r12
	movq	%r14, %r9
	jae	.LBB24_56
.LBB24_39:                              #   Parent Loop BB24_37 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movl	$40, %eax
	bzhiq	%rax, (%r9,%r12), %rcx
	shrq	$2, %rcx
	movq	8(%r9,%r12), %rsi
	movq	(%rsi), %r13
	imulq	%rcx, %r13
	cmpq	$1, %r13
	adcq	$0, %r13
	movq	5640(%rbx), %rdi
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB24_50
# %bb.40:                               #   in Loop: Header=BB24_39 Depth=2
	movq	152(%rdi), %rdx
	shlq	$4, %rax
	cmpq	%rsi, (%rdx,%rax)
	jne	.LBB24_50
# %bb.41:                               #   in Loop: Header=BB24_39 Depth=2
	addq	%rax, %rdx
	movq	8(%rdx), %rax
	testq	%rax, %rax
	je	.LBB24_71
.LBB24_52:                              #   in Loop: Header=BB24_39 Depth=2
	movq	%r9, %r14
	leaq	(%r9,%r12), %rdx
	movq	16(%rax), %r8
	testq	%r8, %r8
	je	.LBB24_54
# %bb.53:                               #   in Loop: Header=BB24_39 Depth=2
	addq	$16, %rdx
	movq	%rbx, %rdi
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	callq	*%r8
	jmp	.LBB24_55
.LBB24_50:                              #   in Loop: Header=BB24_39 Depth=2
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB24_52
	jmp	.LBB24_71
.LBB24_42:
	movq	%rbx, %rdi
	callq	myl_rc_drain
	cmpl	$0, 112(%rbx)
	jne	.LBB24_71
# %bb.43:
	movl	-52(%rbp), %eax                 # 4-byte Reload
	movl	%eax, 112(%rbx)
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	testq	%rdi, %rdi
	je	.LBB24_59
# %bb.44:
	movl	$2097152, %r15d                 # imm = 0x200000
	jmp	.LBB24_45
	.p2align	4
.LBB24_57:                              #   in Loop: Header=BB24_45 Depth=1
	subq	%rcx, 24(%rbx)
	callq	free@PLT
	movq	%r12, %rdi
	testq	%r12, %r12
	je	.LBB24_59
.LBB24_45:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %r12
	movq	24(%rdi), %rax
	subq	%rax, 64(%rbx)
	movq	24(%rdi), %rax
	addq	%rax, 128(%rbx)
	vmovdqu	168(%rbx), %xmm0
	vmovdqa	.LCPI24_0(%rip), %xmm1          # xmm1 = [1,u]
	vpinsrq	$1, 8(%rdi), %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 168(%rbx)
	movq	88(%rbx), %rax
	cmpq	$2097152, %rax                  # imm = 0x200000
	movl	$2097152, %ecx                  # imm = 0x200000
	cmovbq	%rax, %rcx
	testq	%rax, %rax
	movq	%rcx, %rax
	cmoveq	%r15, %rax
	cmpq	$0, 5640(%rbx)
	cmoveq	%rcx, %rax
	movq	8(%rdi), %rcx
	cmpq	$1048576, %rcx                  # imm = 0x100000
	ja	.LBB24_57
# %bb.46:                               #   in Loop: Header=BB24_45 Depth=1
	movq	192(%rbx), %rdx
	cmpq	$3, %rdx
	ja	.LBB24_57
# %bb.47:                               #   in Loop: Header=BB24_45 Depth=1
	movq	200(%rbx), %rsi
	subq	%rsi, %rax
	jbe	.LBB24_57
# %bb.48:                               #   in Loop: Header=BB24_45 Depth=1
	cmpq	%rax, %rcx
	ja	.LBB24_57
# %bb.49:                               #   in Loop: Header=BB24_45 Depth=1
	movq	1248(%rbx), %rax
	movq	%rax, (%rdi)
	movq	%rdi, 1248(%rbx)
	incq	%rdx
	movq	%rdx, 192(%rbx)
	addq	8(%rdi), %rsi
	movq	%rsi, 200(%rbx)
	movq	%r12, %rdi
	testq	%r12, %r12
	jne	.LBB24_45
.LBB24_59:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB24_71:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end24:
	.size	myl_native_arena_release, .Lfunc_end24-myl_native_arena_release
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_new,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_new
	.type	rc_list_new,@function
rc_list_new:                            # @rc_list_new
.Lfunc_begin25:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%ecx, %r15d
	movq	%rdx, %r14
	movq	%rsi, %r12
	movq	%rdi, %rbx
	movq	5640(%rdi), %rax
	cmpq	%rsi, 272(%rax)
	je	.LBB25_3
# %bb.1:
	movq	%rbx, %rdi
	movq	%r12, %rsi
	callq	myl_rc_native_shape
	testq	%rax, %rax
	je	.LBB25_20
# %bb.2:
	movq	5640(%rbx), %rax
.LBB25_3:
	cmpb	$0, 288(%rax)
	je	.LBB25_9
.LBB25_4:
	movl	$myl_native_list_header_descriptor, %esi
	movl	$1, %edx
	movq	%rbx, %rdi
	movl	%r15d, %ecx
	callq	myl_rc_storage_alloc
	testq	%rax, %rax
	je	.LBB25_20
# %bb.5:
	movq	%r12, 24(%rax)
	testq	%r14, %r14
	je	.LBB25_16
# %bb.6:
	movq	%rax, %r13
	movq	(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB25_15
# %bb.7:
	movq	%rsi, %rax
	mulq	%r14
	jno	.LBB25_15
# %bb.8:
	movq	%r13, %rax
	movq	$0, 32(%r13)
	jmp	.LBB25_17
.LBB25_9:
	movl	$rc_list_module, %esi
	movq	%rbx, %rdi
	callq	myl_rc_module_register
	movq	5640(%rbx), %rcx
	testl	%eax, %eax
	je	.LBB25_18
# %bb.10:
	testq	%rcx, %rcx
	je	.LBB25_22
# %bb.11:
	cmpl	$0, 292(%rcx)
	jne	.LBB25_20
# %bb.19:
	movl	$1, 292(%rcx)
	jmp	.LBB25_20
.LBB25_15:
	imulq	%r14, %rsi
	movq	%rbx, %rdi
	movl	%r15d, %edx
	movl	$1, %ecx
	callq	raw_bytes
	movq	%rax, %rcx
	movq	%r13, %rax
	movq	%rcx, 32(%r13)
	testq	%rcx, %rcx
	je	.LBB25_17
.LBB25_16:
	movq	%r14, 8(%rax)
	jmp	.LBB25_21
.LBB25_17:
	movq	%rbx, %rdi
	movq	%rax, %rsi
	callq	myl_rc_construction_abort
.LBB25_20:
	xorl	%eax, %eax
.LBB25_21:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB25_18:
	.cfi_def_cfa %rbp, 16
	movb	$1, 288(%rcx)
	jmp	.LBB25_4
.LBB25_22:
	callq	myl_rc_invariant_failed
.Lfunc_end25:
	.size	rc_list_new, .Lfunc_end25-rc_list_new
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_edges,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_edges
	.type	rc_list_edges,@function
rc_list_edges:                          # @rc_list_edges
.Lfunc_begin26:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	cmpq	$0, (%rsi)
	je	.LBB26_23
# %bb.1:
	movq	24(%rsi), %rcx
	movq	5640(%rdi), %rax
	cmpq	%rcx, 272(%rax)
	je	.LBB26_23
# %bb.2:
	movl	52(%rcx), %edx
	cmpq	%rdx, 160(%rax)
	jbe	.LBB26_5
# %bb.3:
	movq	152(%rax), %r8
	shlq	$4, %rdx
	cmpq	%rcx, (%r8,%rdx)
	jne	.LBB26_5
# %bb.4:
	addq	%rdx, %r8
	movq	8(%r8), %rax
	testq	%rax, %rax
	je	.LBB26_10
.LBB26_7:
	cmpl	$0, 64(%rax)
	jne	.LBB26_10
# %bb.8:
	cmpb	$0, 69(%rax)
	je	.LBB26_9
.LBB26_10:
	movq	(%rsi), %rcx
	movq	24(%rsi), %rax
	movq	32(%rsi), %rdx
	movq	5640(%rdi), %r8
	movl	52(%rax), %r9d
	cmpq	%r9, 160(%r8)
	jbe	.LBB26_13
# %bb.11:
	movq	152(%r8), %r10
	shlq	$4, %r9
	cmpq	%rax, (%r10,%r9)
	jne	.LBB26_13
# %bb.12:
	addq	%r9, %r10
	movq	8(%r10), %rax
	testq	%rax, %rax
	je	.LBB26_24
.LBB26_15:
	movl	64(%rax), %r8d
	testl	%r8d, %r8d
	je	.LBB26_16
# %bb.19:
	cmpl	$17, %r8d
	jb	.LBB26_17
# %bb.20:
	movq	%rsi, %r14
	movq	8(%rax), %rsi
	jmp	.LBB26_21
.LBB26_16:
	cmpb	$0, 69(%rax)
	je	.LBB26_23
.LBB26_17:
	movq	%rsi, %r14
	movq	8(%rax), %rsi
	cmpq	$3, 40(%rsi)
	jb	.LBB26_21
# %bb.18:
	movq	%rdi, %rbx
	movq	%rax, %rsi
	callq	myl_rc_flat_edges_release
	jmp	.LBB26_22
.LBB26_21:
	movq	%rdi, %rbx
	callq	myl_rc_edges_release
.LBB26_22:
	movq	%rbx, %rdi
	movq	%r14, %rsi
.LBB26_23:
	movq	32(%rsi), %rsi
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_edge_release             # TAILCALL
.LBB26_9:
	.cfi_def_cfa %rbp, 16
	movq	5640(%rdi), %rax
	movq	%rcx, 272(%rax)
	jmp	.LBB26_23
.LBB26_5:
	movq	%rdi, %rdx
	movq	%rax, %rdi
	movq	%rsi, %r8
	movq	%rcx, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r8, %rsi
	movq	%rdx, %rdi
	testq	%rax, %rax
	jne	.LBB26_7
	jmp	.LBB26_10
.LBB26_13:
	movq	%rdi, %r9
	movq	%r8, %rdi
	movq	%rsi, %r8
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r8, %rsi
	movq	%r9, %rdi
	testq	%rax, %rax
	jne	.LBB26_15
.LBB26_24:
	callq	abort@PLT
.Lfunc_end26:
	.size	rc_list_edges, .Lfunc_end26-rc_list_edges
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_clone_adapter,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_clone_adapter
	.type	rc_list_clone_adapter,@function
rc_list_clone_adapter:                  # @rc_list_clone_adapter
.Lfunc_begin27:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rbx
	movl	%edx, %ecx
	movq	%rsi, %r14
	movq	%rdi, %r12
	movq	24(%rsi), %r13
	movq	(%rsi), %rdx
	movq	8(%rsi), %rax
	cmpq	%rdx, %rax
	cmovaq	%rax, %rdx
	movq	%r13, %rsi
	callq	rc_list_new
	testq	%rax, %rax
	je	.LBB27_19
# %bb.1:
	movq	%rax, %r15
	movq	%rbx, -48(%rbp)                 # 8-byte Spill
	movq	(%r14), %rax
	testq	%rax, %rax
	je	.LBB27_13
# %bb.2:
	movq	(%r13), %rdx
	testq	%rdx, %rdx
	je	.LBB27_15
# %bb.3:
	movq	5640(%r12), %rdi
	cmpq	%r13, 272(%rdi)
	je	.LBB27_12
# %bb.4:
	movl	52(%r13), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB27_7
# %bb.5:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%r13, (%rcx,%rax)
	jne	.LBB27_7
# %bb.6:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB27_14
.LBB27_9:
	cmpl	$0, 64(%rax)
	jne	.LBB27_14
# %bb.10:
	cmpb	$0, 69(%rax)
	je	.LBB27_11
.LBB27_14:
	cmpq	$0, (%r14)
	je	.LBB27_13
.LBB27_15:
	xorl	%ebx, %ebx
	.p2align	4
.LBB27_17:                              # =>This Inner Loop Header: Depth=1
	movq	(%r13), %rcx
	imulq	%rbx, %rcx
	addq	32(%r14), %rcx
	movq	(%r15), %rdx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	rc_list_insert_at
	testl	%eax, %eax
	je	.LBB27_18
# %bb.16:                               #   in Loop: Header=BB27_17 Depth=1
	incq	%rbx
	cmpq	(%r14), %rbx
	jb	.LBB27_17
	jmp	.LBB27_13
.LBB27_18:
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	myl_rc_construction_abort
	movq	-48(%rbp), %rbx                 # 8-byte Reload
.LBB27_19:
	movq	$0, (%rbx)
	testq	%r12, %r12
	je	.LBB27_23
# %bb.20:
	movq	5640(%r12), %rcx
	testq	%rcx, %rcx
	je	.LBB27_23
# %bb.21:
	movl	292(%rcx), %eax
	cmpl	$1, %eax
	adcl	$0, %eax
	movl	%eax, 292(%rcx)
	jmp	.LBB27_22
.LBB27_11:
	movq	5640(%r12), %rax
	movq	%r13, 272(%rax)
	movq	(%r14), %rax
	movq	(%r13), %rdx
.LBB27_12:
	imulq	%rax, %rdx
	movq	32(%r15), %rdi
	movq	32(%r14), %rsi
	callq	memcpy@PLT
	movq	(%r14), %rax
	movq	%rax, (%r15)
.LBB27_13:
	movq	$0, 16(%r15)
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	%r15, (%rax)
	xorl	%eax, %eax
.LBB27_22:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB27_7:
	.cfi_def_cfa %rbp, 16
	movq	%r13, %rsi
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB27_9
	jmp	.LBB27_14
.LBB27_23:
	callq	myl_rc_invariant_failed
.Lfunc_end27:
	.size	rc_list_clone_adapter, .Lfunc_end27-rc_list_clone_adapter
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_shell,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_shell
	.type	rc_list_shell,@function
rc_list_shell:                          # @rc_list_shell
.Lfunc_begin28:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r12
	movl	%edx, %ecx
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	(%rsi), %rdx
	movq	8(%rsi), %rax
	cmpq	%rdx, %rax
	cmovaq	%rax, %rdx
	movq	24(%rsi), %rsi
	callq	rc_list_new
	movq	%rax, (%r12)
	testq	%rax, %rax
	je	.LBB28_1
# %bb.4:
	movq	%rax, %r15
	movq	24(%rbx), %rsi
	movq	5640(%r14), %rdi
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB28_7
# %bb.5:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rsi, (%rcx,%rax)
	jne	.LBB28_7
# %bb.6:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB28_15
.LBB28_9:
	movq	(%rbx), %r8
	xorl	%r12d, %r12d
	testq	%r8, %r8
	je	.LBB28_10
# %bb.11:
	movq	8(%rax), %rsi
	movq	32(%r15), %rdx
	movq	32(%rbx), %rcx
	movq	%r14, %rdi
	callq	myl_rc_value_seed
	movq	(%rbx), %rax
	jmp	.LBB28_12
.LBB28_1:
	testq	%r14, %r14
	je	.LBB28_14
# %bb.2:
	movq	5640(%r14), %rax
	testq	%rax, %rax
	je	.LBB28_14
# %bb.3:
	movl	292(%rax), %r12d
	cmpl	$1, %r12d
	adcl	$0, %r12d
	movl	%r12d, 292(%rax)
	jmp	.LBB28_13
.LBB28_10:
	xorl	%eax, %eax
.LBB28_12:
	movq	%rax, (%r15)
.LBB28_13:
	movl	%r12d, %eax
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB28_7:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB28_9
.LBB28_15:
	callq	abort@PLT
.LBB28_14:
	callq	myl_rc_invariant_failed
.Lfunc_end28:
	.size	rc_list_shell, .Lfunc_end28-rc_list_shell
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_next,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_next
	.type	rc_list_next,@function
rc_list_next:                           # @rc_list_next
.Lfunc_begin29:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	24(%rsi), %rax
	movq	5640(%rdi), %rdi
	movl	52(%rax), %r10d
	cmpq	%r10, 160(%rdi)
	jbe	.LBB29_3
# %bb.1:
	movq	152(%rdi), %r11
	shlq	$4, %r10
	cmpq	%rax, (%r11,%r10)
	jne	.LBB29_3
# %bb.2:
	addq	%r10, %r11
	movq	8(%r11), %rax
	testq	%rax, %rax
	je	.LBB29_9
.LBB29_5:
	movq	(%rcx), %r10
	xorl	%edi, %edi
	cmpq	(%rsi), %r10
	jae	.LBB29_8
# %bb.6:
	movq	8(%rax), %r11
	cmpl	$0, 8(%r11)
	je	.LBB29_8
# %bb.7:
	leaq	1(%r10), %rdi
	movq	%rdi, (%rcx)
	movq	24(%rsi), %rcx
	imulq	(%rcx), %r10
	movq	32(%rdx), %rcx
	addq	%r10, %rcx
	movq	-16(%rdx), %rdi
	movq	%rdi, %rbx
	shrq	$40, %rbx
	andl	$1048575, %ebx                  # imm = 0xFFFFF
	xorl	%r14d, %r14d
	btq	$62, %rdi
	cmovael	%r14d, %ebx
	movq	%r11, (%r8)
	movq	%rcx, 8(%r8)
	movq	%rdx, 16(%r8)
	movl	%ebx, 24(%r8)
	movl	$0, 28(%r8)
	movq	8(%rax), %rax
	addq	32(%rsi), %r10
	movq	-16(%rsi), %rcx
	movq	%rcx, %rdx
	shrq	$40, %rdx
	andl	$1048575, %edx                  # imm = 0xFFFFF
	btq	$62, %rcx
	cmovael	%r14d, %edx
	movq	%rax, (%r9)
	movq	%r10, 8(%r9)
	movq	%rsi, 16(%r9)
	movl	%edx, 24(%r9)
	movl	$0, 28(%r9)
	movl	$1, %edi
.LBB29_8:
	movl	%edi, %eax
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB29_3:
	.cfi_def_cfa %rbp, 16
	movq	%rsi, %r10
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r10, %rsi
	testq	%rax, %rax
	jne	.LBB29_5
.LBB29_9:
	callq	abort@PLT
.Lfunc_end29:
	.size	rc_list_next, .Lfunc_end29-rc_list_next
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_span,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_span
	.type	rc_list_span,@function
rc_list_span:                           # @rc_list_span
.Lfunc_begin30:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %rbx
	movq	%rsi, %r14
	movq	(%rcx), %r15
	callq	rc_list_next
	testl	%eax, %eax
	je	.LBB30_1
# %bb.2:
	movq	16(%rbp), %rax
	movq	(%r14), %rcx
	subq	%r15, %rcx
	movq	%rcx, (%rax)
	movq	(%r14), %rax
	movq	%rax, (%rbx)
	movl	$1, %eax
	jmp	.LBB30_3
.LBB30_1:
	xorl	%eax, %eax
.LBB30_3:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end30:
	.size	rc_list_span, .Lfunc_end30-rc_list_span
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_storage_edges,"ax",@progbits
	.p2align	4                               # -- Begin function rc_storage_edges
	.type	rc_storage_edges,@function
rc_storage_edges:                       # @rc_storage_edges
.Lfunc_begin31:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	32(%rsi), %rsi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_edge_release             # TAILCALL
.Lfunc_end31:
	.size	rc_storage_edges, .Lfunc_end31-rc_storage_edges
	.cfi_endproc
                                        # -- End function
	.section	.text.rc_list_insert_at,"ax",@progbits
	.p2align	4                               # -- Begin function rc_list_insert_at
	.type	rc_list_insert_at,@function
rc_list_insert_at:                      # @rc_list_insert_at
.Lfunc_begin32:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	xorl	%r12d, %r12d
	cmpq	$-1, 16(%rsi)
	je	.LBB32_50
# %bb.1:
	movq	%rsi, %r14
	movq	(%rsi), %r15
	cmpq	$-1, %r15
	je	.LBB32_50
# %bb.2:
	movq	24(%r14), %rax
	movq	(%rax), %rsi
	cmpq	%r15, %rdx
	movq	%rdx, -80(%rbp)                 # 8-byte Spill
	movq	%rdi, -56(%rbp)                 # 8-byte Spill
	jne	.LBB32_5
# %bb.3:
	testq	%rsi, %rsi
	je	.LBB32_9
# %bb.4:
	movq	5640(%rdi), %rax
	cmpq	$0, 200(%rax)
	je	.LBB32_28
.LBB32_5:
	cmpq	$129, %rsi
	jae	.LBB32_7
# %bb.6:
	leaq	-208(%rbp), %rax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	jmp	.LBB32_10
.LBB32_7:
	movq	%rcx, %rbx
	xorl	%r12d, %r12d
	movq	%rsi, %r13
	xorl	%edx, %edx
	movl	$1, %ecx
	callq	raw_bytes
	testq	%rax, %rax
	je	.LBB32_50
# %bb.8:
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	movq	(%r14), %r15
	movq	%rbx, %rcx
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	movq	%r13, %rsi
	jmp	.LBB32_10
.LBB32_9:
	leaq	-208(%rbp), %rax
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	xorl	%esi, %esi
	movq	%rdx, %r15
.LBB32_10:
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	movq	-16(%r14), %rax
	movq	32(%r14), %rdx
	movq	%rax, %rbx
	shrq	$40, %rbx
	andl	$1048575, %ebx                  # imm = 0xFFFFF
	xorl	%r12d, %r12d
	btq	$62, %rax
	cmovael	%r12d, %ebx
	testq	%rdx, %rdx
	sete	%al
	movq	%rcx, -72(%rbp)                 # 8-byte Spill
	movq	%rcx, %r13
	subq	%rdx, %r13
	setb	%cl
	orb	%al, %cl
	je	.LBB32_13
# %bb.11:
	incq	%r15
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	myl_rc_list_storage_reserve
	testl	%eax, %eax
	jne	.LBB32_16
	jmp	.LBB32_27
.LBB32_13:
	leaq	1(%r15), %rdx
	movq	%r14, %rsi
	callq	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.LBB32_27
# %bb.14:
	imulq	-48(%rbp), %r15                 # 8-byte Folded Reload
	cmpq	%r15, %r13
	jae	.LBB32_16
# %bb.15:
	addq	32(%r14), %r13
	movq	%r13, -72(%rbp)                 # 8-byte Spill
.LBB32_16:
	movq	24(%r14), %rsi
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	movq	-64(%rbp), %r15                 # 8-byte Reload
	movq	%r15, %rdx
	movq	-72(%rbp), %rcx                 # 8-byte Reload
	movl	%ebx, %r8d
	callq	myl_rc_native_retain
	testl	%eax, %eax
	je	.LBB32_22
# %bb.17:
	movq	(%r14), %rdx
	movq	32(%r14), %rbx
	movq	-80(%rbp), %rax                 # 8-byte Reload
	subq	%rax, %rdx
	jbe	.LBB32_19
# %bb.18:
	leaq	1(%rax), %rdi
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	imulq	%rcx, %rdi
	addq	%rbx, %rdi
	movq	%rcx, %rsi
	imulq	%rax, %rsi
	addq	%rbx, %rsi
	imulq	%rcx, %rdx
	callq	memmove@PLT
	movq	-80(%rbp), %rax                 # 8-byte Reload
.LBB32_19:
	movq	-48(%rbp), %rdx                 # 8-byte Reload
	testq	%rdx, %rdx
	je	.LBB32_21
# %bb.20:
	imulq	%rdx, %rax
	addq	%rax, %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	memcpy@PLT
.LBB32_21:
	incq	(%r14)
	incq	16(%r14)
	movl	$1, %r12d
.LBB32_22:
	leaq	-208(%rbp), %rax
	cmpq	%rax, %r15
	jne	.LBB32_23
	jmp	.LBB32_50
.LBB32_27:
	movq	-64(%rbp), %r15                 # 8-byte Reload
	leaq	-208(%rbp), %rax
	cmpq	%rax, %r15
	je	.LBB32_50
.LBB32_23:
	movq	-56(%rbp), %rbx                 # 8-byte Reload
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	myl_rc_edge_release
	testq	%rbx, %rbx
	je	.LBB32_50
# %bb.24:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB32_50
# %bb.25:
	cmpq	$0, 200(%rax)
	je	.LBB32_50
# %bb.26:
	movq	%rbx, %rdi
	callq	myl_rc_drain
	jmp	.LBB32_50
.LBB32_28:
	movq	32(%r14), %rax
	movq	%rsi, %rbx
	imulq	%rdx, %rbx
	testq	%rax, %rax
	sete	%r8b
	movq	%rcx, %r13
	subq	%rax, %r13
	setb	%al
	orb	%r8b, %al
	je	.LBB32_31
# %bb.29:
	movq	%rsi, %r13
	movq	%rcx, %r15
	incq	%rdx
	movq	%r14, %rsi
	callq	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.LBB32_50
# %bb.30:
	movq	32(%r14), %rdx
	movq	%r15, %rcx
	movq	-56(%rbp), %r9                  # 8-byte Reload
	movq	%r13, %r10
	jmp	.LBB32_38
.LBB32_31:
	cmpq	%rbx, %r13
	setb	%r8b
	jb	.LBB32_33
# %bb.32:
	movq	8(%r14), %rax
	imulq	%rsi, %rax
	cmpq	%rax, %r13
	jb	.LBB32_5
.LBB32_33:
	movl	%r8d, %r15d
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	movq	%rcx, -72(%rbp)                 # 8-byte Spill
	incq	%rdx
	movq	%r14, %rsi
	callq	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.LBB32_50
# %bb.34:
	movq	32(%r14), %rdx
	testb	%r15b, %r15b
	je	.LBB32_36
# %bb.35:
	addq	%rdx, %r13
	movq	%r13, %rcx
	jmp	.LBB32_37
.LBB32_36:
	movq	-72(%rbp), %rcx                 # 8-byte Reload
.LBB32_37:
	movq	-56(%rbp), %r9                  # 8-byte Reload
	movq	-48(%rbp), %r10                 # 8-byte Reload
.LBB32_38:
	addq	%rbx, %rdx
	leaq	(%rcx,%r10), %rax
	cmpq	%rdx, %rax
	jbe	.LBB32_40
# %bb.39:
	leaq	(%r10,%rdx), %rax
	cmpq	%rcx, %rax
	ja	.LBB32_52
.LBB32_40:
	movq	24(%r14), %rsi
	movq	5640(%r9), %rdi
	cmpq	%rsi, 272(%rdi)
	je	.LBB32_48
# %bb.41:
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB32_51
# %bb.42:
	movq	152(%rdi), %r8
	shlq	$4, %rax
	cmpq	%rsi, (%r8,%rax)
	jne	.LBB32_51
# %bb.43:
	addq	%rax, %r8
	movq	8(%r8), %rax
	testq	%rax, %rax
	je	.LBB32_46
.LBB32_44:
	cmpl	$0, 64(%rax)
	jne	.LBB32_46
# %bb.45:
	cmpb	$0, 69(%rax)
	je	.LBB32_47
.LBB32_46:
	movq	-16(%r14), %rax
	movq	24(%r14), %rsi
	movq	%rax, %r8
	shrq	$40, %r8
	andl	$1048575, %r8d                  # imm = 0xFFFFF
	xorl	%r12d, %r12d
	btq	$62, %rax
	cmovael	%r12d, %r8d
	movq	%r9, %rdi
                                        # kill: def $r8d killed $r8d killed $r8
	callq	myl_rc_native_retain
	testl	%eax, %eax
	jne	.LBB32_49
	jmp	.LBB32_50
.LBB32_47:
	movq	5640(%r9), %rax
	movq	%rsi, 272(%rax)
.LBB32_48:
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	%r10, %rdx
	callq	memcpy@PLT
.LBB32_49:
	incq	(%r14)
	incq	16(%r14)
	movl	$1, %r12d
.LBB32_50:
	movl	%r12d, %eax
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB32_51:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB32_44
	jmp	.LBB32_46
.LBB32_52:
	callq	myl_rc_invariant_failed
.Lfunc_end32:
	.size	rc_list_insert_at, .Lfunc_end32-rc_list_insert_at
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_list_storage_reserve,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_list_storage_reserve
	.type	myl_rc_list_storage_reserve,@function
myl_rc_list_storage_reserve:            # @myl_rc_list_storage_reserve
.Lfunc_begin33:
	.cfi_startproc
# %bb.0:
	movq	8(%rsi), %rcx
	movl	$1, %eax
	cmpq	%rcx, %rdx
	jbe	.LBB33_24
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rbx
	cmpq	$5, %rcx
	movl	$4, %r13d
	cmovaeq	%rcx, %r13
	cmpq	$5, %rdx
	jb	.LBB33_4
	.p2align	4
.LBB33_2:                               # =>This Inner Loop Header: Depth=1
	testq	%r13, %r13
	js	.LBB33_18
# %bb.3:                                #   in Loop: Header=BB33_2 Depth=1
	addq	%r13, %r13
	cmpq	%rdx, %r13
	jb	.LBB33_2
.LBB33_4:
	movq	24(%rbx), %rsi
	movq	(%rsi), %rcx
	testq	%rcx, %rcx
	je	.LBB33_7
# %bb.5:
	movq	%rcx, %rax
	mulq	%r13
	jno	.LBB33_7
.LBB33_18:
	xorl	%eax, %eax
	jmp	.LBB33_23
.LBB33_7:
	movq	32(%rbx), %r14
	movq	5640(%rdi), %rax
	cmpq	%rsi, 272(%rax)
	je	.LBB33_20
# %bb.8:
	movl	52(%rsi), %ecx
	cmpq	%rcx, 160(%rax)
	jbe	.LBB33_31
# %bb.9:
	movq	152(%rax), %rdx
	shlq	$4, %rcx
	cmpq	%rsi, (%rdx,%rcx)
	jne	.LBB33_31
# %bb.10:
	addq	%rcx, %rdx
	movq	8(%rdx), %rax
	testq	%rax, %rax
	je	.LBB33_13
.LBB33_11:
	cmpl	$0, 64(%rax)
	jne	.LBB33_13
# %bb.12:
	cmpb	$0, 69(%rax)
	je	.LBB33_19
.LBB33_13:
	movq	24(%rbx), %rax
	movq	(%rax), %rdx
	imulq	%r13, %rdx
	movq	%rdi, %r15
	movq	%r14, %rsi
	movl	$1, %ecx
	callq	storage_extend
	testq	%rax, %rax
	jne	.LBB33_21
# %bb.14:
	movq	-16(%rbx), %rax
	movq	24(%rbx), %rdx
	movq	%rax, %rcx
	shrq	$40, %rcx
	andl	$1048575, %ecx                  # imm = 0xFFFFF
	xorl	%esi, %esi
	btq	$62, %rax
	cmovael	%esi, %ecx
	movq	(%rdx), %rsi
	testq	%rsi, %rsi
	je	.LBB33_16
# %bb.15:
	movq	%rsi, %rax
	mulq	%r13
	movl	$0, %eax
	jo	.LBB33_23
.LBB33_16:
	imulq	%r13, %rsi
	movq	%r15, %rdi
	movl	%ecx, %edx
	movl	$1, %ecx
	callq	raw_bytes
	movq	%rax, %r12
	testq	%rax, %rax
	jne	.LBB33_26
	jmp	.LBB33_18
.LBB33_19:
	movq	5640(%rdi), %rax
	movq	%rsi, 272(%rax)
	movq	24(%rbx), %rax
	movq	(%rax), %rcx
.LBB33_20:
	imulq	%r13, %rcx
	xorl	%r12d, %r12d
	movq	%rdi, %r15
	movq	%r14, %rsi
	movq	%rcx, %rdx
	xorl	%ecx, %ecx
	callq	storage_extend
	testq	%rax, %rax
	je	.LBB33_25
.LBB33_21:
	movq	%rax, 32(%rbx)
.LBB33_22:
	movq	%r13, 8(%rbx)
	movl	$1, %eax
.LBB33_23:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
.LBB33_24:
	retq
.LBB33_25:
	.cfi_def_cfa %rbp, 16
	.cfi_offset %rbx, -56
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	-16(%rbx), %rax
	movq	24(%rbx), %rcx
	movq	(%rcx), %rsi
	imulq	%r13, %rsi
	movq	%rax, %rdx
	shrq	$40, %rdx
	andl	$1048575, %edx                  # imm = 0xFFFFF
	btq	$62, %rax
	cmovael	%r12d, %edx
	movq	%r15, %rdi
                                        # kill: def $edx killed $edx killed $rdx
	xorl	%ecx, %ecx
	callq	raw_bytes
	movq	%rax, %r12
	testq	%rax, %rax
	je	.LBB33_18
.LBB33_26:
	movq	(%rbx), %rdx
	testq	%rdx, %rdx
	je	.LBB33_28
# %bb.27:
	movq	24(%rbx), %rax
	imulq	(%rax), %rdx
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	memcpy@PLT
.LBB33_28:
	movq	%r12, 32(%rbx)
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	myl_rc_edge_release
	movq	5640(%r15), %rax
	testq	%rax, %rax
	je	.LBB33_22
# %bb.29:
	cmpq	$0, 200(%rax)
	je	.LBB33_22
# %bb.30:
	movq	%r15, %rdi
	callq	myl_rc_drain
	jmp	.LBB33_22
.LBB33_31:
	movq	%rdi, %rcx
	movq	%rax, %rdi
	callq	myl_rc_binding_find_slow
	movq	%rcx, %rdi
	testq	%rax, %rax
	jne	.LBB33_11
	jmp	.LBB33_13
.Lfunc_end33:
	.size	myl_rc_list_storage_reserve, .Lfunc_end33-myl_rc_list_storage_reserve
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_list_plain_ready,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_list_plain_ready
	.type	myl_rc_list_plain_ready,@function
myl_rc_list_plain_ready:                # @myl_rc_list_plain_ready
.Lfunc_begin34:
	.cfi_startproc
# %bb.0:
	xorl	%eax, %eax
	testq	%rdi, %rdi
	je	.LBB34_21
# %bb.1:
	movq	5640(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB34_21
# %bb.2:
	testq	%rsi, %rsi
	je	.LBB34_21
# %bb.3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpq	$0, 200(%rcx)
	jne	.LBB34_20
# %bb.4:
	movq	24(%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB34_20
# %bb.5:
	cmpq	280(%rcx), %rsi
	je	.LBB34_19
# %bb.6:
	movzwl	48(%rsi), %edx
	cmpl	$7, %edx
	je	.LBB34_8
# %bb.7:
	testl	%edx, %edx
	jne	.LBB34_20
.LBB34_8:
	movq	(%rsi), %rdx
	popcntq	%rdx, %r8
	cmpl	$1, %r8d
	setne	%r8b
	testb	$15, %dl
	sete	%dl
	orb	%r8b, %dl
	jne	.LBB34_20
# %bb.9:
	cmpq	%rsi, 272(%rcx)
	je	.LBB34_18
# %bb.10:
	movl	52(%rsi), %edx
	cmpq	%rdx, 160(%rcx)
	jbe	.LBB34_13
# %bb.11:
	movq	152(%rcx), %r8
	shlq	$4, %rdx
	cmpq	%rsi, (%r8,%rdx)
	jne	.LBB34_13
# %bb.12:
	addq	%rdx, %r8
	movq	8(%r8), %rcx
	testq	%rcx, %rcx
	je	.LBB34_20
.LBB34_15:
	cmpl	$0, 64(%rcx)
	jne	.LBB34_20
# %bb.16:
	cmpb	$0, 69(%rcx)
	jne	.LBB34_20
# %bb.17:
	movq	5640(%rdi), %rcx
	movq	%rsi, 272(%rcx)
.LBB34_18:
	movq	%rsi, 280(%rcx)
.LBB34_19:
	movl	$1, %eax
.LBB34_20:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbp
.LBB34_21:
	retq
.LBB34_13:
	.cfi_def_cfa %rbp, 16
	.cfi_offset %rbp, -16
	movq	%rdi, %rdx
	movq	%rcx, %rdi
	callq	myl_rc_binding_find_slow
	movq	%rdx, %rdi
	movq	%rax, %rcx
	xorl	%eax, %eax
	testq	%rcx, %rcx
	jne	.LBB34_15
	jmp	.LBB34_20
.Lfunc_end34:
	.size	myl_rc_list_plain_ready, .Lfunc_end34-myl_rc_list_plain_ready
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_qbe_on_stack,"ax",@progbits
	.p2align	4                               # -- Begin function myl_qbe_on_stack
	.type	myl_qbe_on_stack,@function
myl_qbe_on_stack:                       # @myl_qbe_on_stack
.Lfunc_begin35:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$2168, %rsp                     # imm = 0x878
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movl	$30, %edi
	callq	sysconf@PLT
	testq	%rax, %rax
	jle	.LBB35_1
# %bb.2:
	movq	%rax, %rcx
	shrq	$62, %rcx
	jne	.LBB35_4
# %bb.3:
	leaq	(%rax,%rax), %r14
	movq	24(%rbx), %rcx
	movq	$-8388610, %rdx                 # imm = 0xFF7FFFFE
	subq	%r14, %rdx
	shrq	$15, %rdx
	cmpq	%rdx, %rcx
	jbe	.LBB35_7
.LBB35_4:
	movq	$-1, %rsi
	movq	%rbx, %rdi
.LBB35_5:
	callq	stack_refused
	jmp	.LBB35_6
.LBB35_7:
	shlq	$15, %rcx
	movq	%rcx, %rdx
	addq	$8388608, %rdx                  # imm = 0x800000
	movq	%rax, %rcx
	negq	%rcx
	cmpq	%rcx, %rdx
	ja	.LBB35_1
# %bb.8:
	movq	%r14, %rcx
	notq	%rcx
	leaq	(%rdx,%rax), %r12
	decq	%r12
	movq	%r12, %rdx
	orq	%rax, %rdx
	shrq	$32, %rdx
	je	.LBB35_9
# %bb.10:
	movq	%rax, %rsi
	movq	%rax, %r13
	xorl	%eax, %eax
	movl	%eax, %edx
	movq	%r12, %rax
	divq	%rsi
	movq	%rdx, %rax
	subq	%rax, %r12
	cmpq	%rcx, %r12
	jbe	.LBB35_12
.LBB35_1:
	movl	$.L.str.122, %esi
	movq	%rbx, %rdi
	callq	fail
.LBB35_6:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
.LBB35_20:
	addq	$2168, %rsp                     # imm = 0x878
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB35_9:
	.cfi_def_cfa %rbp, 16
	movq	%rax, %r13
	movl	%eax, %esi
	movl	%r12d, %eax
	xorl	%edx, %edx
	divl	%esi
	movl	%edx, %eax
	subq	%rax, %r12
	cmpq	%rcx, %r12
	ja	.LBB35_1
.LBB35_12:
	addq	%r12, %r14
	xorl	%eax, %eax
	movl	%eax, %edi
	movq	%r14, %rsi
	xorl	%edx, %edx
	movl	$131106, %ecx                   # imm = 0x20022
	movl	$-1, %r8d
	movq	%rdi, %r9
	callq	mmap@PLT
	cmpq	$-1, %rax
	je	.LBB35_13
# %bb.14:
	movq	%rax, %r15
	addq	%rax, %r13
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -72(%rbp)
	vmovups	%ymm0, -88(%rbp)
	vmovups	%ymm0, -120(%rbp)
	vmovups	%ymm0, -152(%rbp)
	vmovups	%ymm0, -184(%rbp)
	vmovups	%ymm0, -216(%rbp)
	vmovups	%ymm0, -248(%rbp)
	movq	$entry_run, -264(%rbp)
	movq	%rbx, -256(%rbp)
	movq	%r13, %rdi
	movq	%r12, %rsi
	movl	$3, %edx
	vzeroupper
	callq	mprotect@PLT
	testl	%eax, %eax
	jne	.LBB35_16
# %bb.15:
	leaq	-1232(%rbp), %rdi
	callq	getcontext@PLT
	testl	%eax, %eax
	jne	.LBB35_16
# %bb.17:
	leaq	-8388608(%r12), %rax
	movq	%rax, 14776(%rbx)
	movq	%r13, 14784(%rbx)
	leaq	(%r12,%r13), %rax
	movq	%rax, 15976(%rbx)
	leaq	65536(%r13), %rax
	movq	%rax, 64(%rbx)
	movq	%r13, -1216(%rbp)
	movq	%r12, -1200(%rbp)
	movl	$0, -1208(%rbp)
	leaq	-2200(%rbp), %r12
	movq	%r12, -1224(%rbp)
	leaq	-264(%rbp), %rax
	movq	%rax, %rdx
	movl	%eax, %ecx
	shrq	$32, %rdx
	movl	%edx, %r8d
	movl	$launch, %esi
	xorl	%eax, %eax
                                        # kill: def $al killed $al killed $eax
	leaq	-1232(%rbp), %r13
	movq	%r13, %rdi
	movl	$2, %edx
	callq	makecontext@PLT
	movq	%r12, %rdi
	movq	%r13, %rsi
	callq	swapcontext@PLT
	testl	%eax, %eax
	je	.LBB35_18
.LBB35_16:
	movl	$.L.str.122, %esi
	movq	%rbx, %rdi
	callq	fail
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
.LBB35_19:
	movq	%rax, %r12
	movq	$0, 14784(%rbx)
	movq	$0, 15976(%rbx)
	movq	$0, 64(%rbx)
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	munmap@PLT
	movq	%r12, %rax
	jmp	.LBB35_20
.LBB35_13:
	movq	%rbx, %rdi
	movq	%r14, %rsi
	jmp	.LBB35_5
.LBB35_18:
	movq	-248(%rbp), %rax
	jmp	.LBB35_19
.Lfunc_end35:
	.size	myl_qbe_on_stack, .Lfunc_end35-myl_qbe_on_stack
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function stack_refused
.LCPI36_0:
	.long	1127219200                      # 0x43300000
	.long	1160773632                      # 0x45300000
	.long	0                               # 0x0
	.long	0                               # 0x0
.LCPI36_1:
	.quad	0x4330000000000000              # double 4503599627370496
	.quad	0x4530000000000000              # double 1.9342813113834067E+25
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI36_2:
	.quad	0x3e10000000000000              # double 9.3132257461547852E-10
	.section	.text.stack_refused,"ax",@progbits
	.p2align	4
	.type	stack_refused,@function
stack_refused:                          # @stack_refused
.Lfunc_begin36:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	subq	$128, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	cmpq	$-1, 56(%rdi)
	je	.LBB36_2
# %bb.1:
	movq	%rsi, %rbx
	leaq	-32(%rbp), %rsi
	movq	%rdi, %r14
	movl	$9, %edi
	callq	getrlimit@PLT
	movq	%r14, %rdi
	testl	%eax, %eax
	je	.LBB36_3
.LBB36_2:
	movl	$.L.str.122, %esi
.LBB36_10:
	callq	fail
	addq	$128, %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB36_3:
	.cfi_def_cfa %rbp, 16
	cmpq	$-1, %rbx
	jne	.LBB36_5
# %bb.4:
	vmovupd	.L.str.1.110(%rip), %ymm0
	vmovupd	%ymm0, -80(%rbp)
	movabsq	$28259044202738276, %rax        # imm = 0x64657373657264
	movq	%rax, -48(%rbp)
	jmp	.LBB36_6
.LBB36_5:
	vmovq	%rbx, %xmm0
	vpunpckldq	.LCPI36_0(%rip), %xmm0, %xmm0 # xmm0 = xmm0[0],mem[0],xmm0[1],mem[1]
	vsubpd	.LCPI36_1(%rip), %xmm0, %xmm0
	vshufpd	$1, %xmm0, %xmm0, %xmm1         # xmm1 = xmm0[1,0]
	vaddsd	%xmm0, %xmm1, %xmm0
	vmulsd	.LCPI36_2(%rip), %xmm0, %xmm0
	leaq	-80(%rbp), %rdi
	movl	$48, %esi
	movl	$.L.str.2.111, %edx
	movb	$1, %al
	callq	snprintf@PLT
.LBB36_6:
	movq	-32(%rbp), %rax
	cmpq	$-1, %rax
	jne	.LBB36_8
# %bb.7:
	vmovups	.L.str.3.112+15(%rip), %xmm0
	vmovups	%xmm0, -129(%rbp)
	vmovupd	.L.str.3.112(%rip), %xmm0
	vmovapd	%xmm0, -144(%rbp)
	jmp	.LBB36_9
.LBB36_8:
	vmovq	%rax, %xmm0
	vpunpckldq	.LCPI36_0(%rip), %xmm0, %xmm0 # xmm0 = xmm0[0],mem[0],xmm0[1],mem[1]
	vsubpd	.LCPI36_1(%rip), %xmm0, %xmm0
	vshufpd	$1, %xmm0, %xmm0, %xmm1         # xmm1 = xmm0[1,0]
	vaddsd	%xmm0, %xmm1, %xmm0
	vmulsd	.LCPI36_2(%rip), %xmm0, %xmm0
	leaq	-144(%rbp), %rdi
	movl	$64, %esi
	movl	$.L.str.4.113, %edx
	movb	$1, %al
	vzeroupper
	callq	snprintf@PLT
.LBB36_9:
	movq	stderr@GOTPCREL(%rip), %rax
	movq	(%rax), %rdi
	movq	24(%r14), %rdx
	leaq	-80(%rbp), %rcx
	leaq	-144(%rbp), %r9
	movl	$.L.str.5, %esi
	movl	$32, %r8d
	xorl	%eax, %eax
	vzeroupper
	callq	fprintf@PLT
	movl	$1, 14816(%r14)
	movl	$.L.str.122, %esi
	movq	%r14, %rdi
	jmp	.LBB36_10
.Lfunc_end36:
	.size	stack_refused, .Lfunc_end36-stack_refused
	.cfi_endproc
                                        # -- End function
	.section	.text.launch,"ax",@progbits
	.p2align	4                               # -- Begin function launch
	.type	launch,@function
launch:                                 # @launch
.Lfunc_begin37:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	subq	$16, %rsp
	movl	%edi, %edi
	movl	%edi, %eax
	movl	%esi, %ecx
	shlq	$32, %rcx
	orq	%rax, %rcx
	movq	%rcx, -8(%rbp)
	movq	-8(%rbp), %rdi
	addq	$24, %rdi
	callq	_setjmp@PLT
	movq	-8(%rbp), %rcx
	testl	%eax, %eax
	je	.LBB37_2
# %bb.1:
	xorl	%eax, %eax
                                        # kill: def $rax killed $eax
	jmp	.LBB37_3
.LBB37_2:
	addq	$24, %rcx
	movq	-8(%rbp), %rax
	movq	8(%rax), %rax
	movq	%rcx, 15968(%rax)
	movq	-8(%rbp), %rax
	movq	-8(%rbp), %rcx
	movq	8(%rcx), %rdi
	callq	*(%rax)
	movq	-8(%rbp), %rcx
.LBB37_3:
	movq	%rax, 16(%rcx)
	movq	-8(%rbp), %rax
	movq	8(%rax), %rax
	movq	$0, 15968(%rax)
	addq	$16, %rsp
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end37:
	.size	launch, .Lfunc_end37-launch
	.cfi_endproc
                                        # -- End function
	.section	.text.unlikely.myl_rc_invariant_failed,"ax",@progbits
	.type	myl_rc_invariant_failed,@function # -- Begin function myl_rc_invariant_failed
myl_rc_invariant_failed:                # @myl_rc_invariant_failed
.Lfunc_begin38:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	abort@PLT
.Lfunc_end38:
	.size	myl_rc_invariant_failed, .Lfunc_end38-myl_rc_invariant_failed
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_meta_alloc,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_meta_alloc
	.type	myl_rc_meta_alloc,@function
myl_rc_meta_alloc:                      # @myl_rc_meta_alloc
.Lfunc_begin39:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB39_11
# %bb.1:
	testq	%rsi, %rsi
	je	.LBB39_11
# %bb.2:
	movq	5640(%rdi), %rbx
	testq	%rbx, %rbx
	je	.LBB39_11
# %bb.3:
	movq	24(%rdi), %r14
	addq	%rsi, %r14
	jb	.LBB39_5
# %bb.4:
	movq	88(%rdi), %rax
	testq	%rax, %rax
	setne	%cl
	cmpq	%rax, %r14
	seta	%al
	andb	%cl, %al
	cmpb	$1, %al
	jne	.LBB39_8
.LBB39_5:
	movl	$1, 108(%rdi)
.LBB39_6:
	xorl	%eax, %eax
.LBB39_7:
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB39_8:
	.cfi_def_cfa %rbp, 16
	movq	%rdi, %r15
	movl	$1, %edi
	movq	%rsi, %r12
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB39_6
# %bb.9:
	movq	%r14, 24(%r15)
	addq	%r12, 48(%rbx)
	jmp	.LBB39_7
.LBB39_11:
	callq	myl_rc_invariant_failed
.Lfunc_end39:
	.size	myl_rc_meta_alloc, .Lfunc_end39-myl_rc_meta_alloc
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_meta_free,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_meta_free
	.type	myl_rc_meta_free,@function
myl_rc_meta_free:                       # @myl_rc_meta_free
.Lfunc_begin40:
	.cfi_startproc
# %bb.0:
	testq	%rsi, %rsi
	je	.LBB40_4
# %bb.1:
	movq	24(%rdi), %rax
	subq	%rdx, %rax
	jb	.LBB40_5
# %bb.2:
	movq	5640(%rdi), %rcx
	movq	48(%rcx), %r8
	subq	%rdx, %r8
	jb	.LBB40_5
# %bb.3:
	movq	%rax, 24(%rdi)
	movq	%r8, 48(%rcx)
	movq	%rsi, %rdi
	jmp	free@PLT                        # TAILCALL
.LBB40_4:
	retq
.LBB40_5:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	myl_rc_invariant_failed
.Lfunc_end40:
	.size	myl_rc_meta_free, .Lfunc_end40-myl_rc_meta_free
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_heap_destroy,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_heap_destroy
	.type	myl_rc_heap_destroy,@function
myl_rc_heap_destroy:                    # @myl_rc_heap_destroy
.Lfunc_begin41:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$0, 5640(%rdi)
	je	.LBB41_41
# %bb.1:
	movq	%rdi, %rbx
	callq	myl_rc_drain
	movq	5640(%rbx), %r14
	cmpq	$0, 248(%r14)
	jne	.LBB41_42
# %bb.2:
	cmpq	$0, 192(%r14)
	jne	.LBB41_42
# %bb.3:
	cmpl	$0, 208(%r14)
	jne	.LBB41_42
# %bb.4:
	movq	256(%r14), %rdi
	movq	%r14, %rcx
	testq	%rdi, %rdi
	je	.LBB41_7
# %bb.5:
	leaq	256(%r14), %rax
	.p2align	4
.LBB41_6:                               # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rcx
	movq	%rcx, (%rax)
	callq	free@PLT
	movq	5640(%rbx), %rcx
	leaq	256(%rcx), %rax
	movq	256(%rcx), %rdi
	testq	%rdi, %rdi
	jne	.LBB41_6
.LBB41_7:
	movq	$0, 264(%rcx)
	movq	16(%r14), %rax
	testq	%rax, %rax
	je	.LBB41_9
# %bb.8:
	movq	%rbx, %rdi
	callq	*%rax
	jmp	.LBB41_9
	.p2align	4
.LBB41_10:                              #   in Loop: Header=BB41_9 Depth=1
	movq	(%rdi), %rax
	movq	%rax, 40(%r14)
	movq	48(%rdi), %rcx
	movq	24(%rbx), %rax
	subq	%rcx, %rax
	jb	.LBB41_42
# %bb.11:                               #   in Loop: Header=BB41_9 Depth=1
	movq	5640(%rbx), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB41_42
# %bb.12:                               #   in Loop: Header=BB41_9 Depth=1
	movq	%rax, 24(%rbx)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
.LBB41_9:                               # =>This Inner Loop Header: Depth=1
	movq	40(%r14), %rdi
	testq	%rdi, %rdi
	jne	.LBB41_10
# %bb.13:
	movq	176(%r14), %rdi
	testq	%rdi, %rdi
	je	.LBB41_17
# %bb.14:
	movq	184(%r14), %rax
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rcx
	movq	24(%rbx), %rax
	subq	%rcx, %rax
	jb	.LBB41_42
# %bb.15:
	movq	5640(%rbx), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB41_42
# %bb.16:
	movq	%rax, 24(%rbx)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
.LBB41_17:
	movq	5640(%rbx), %r15
	movq	56(%r15), %rdi
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB41_23
# %bb.18:
	movq	64(%r15), %rax
	cmpq	$-1, %rax
	je	.LBB41_23
# %bb.19:
	testq	%rdi, %rdi
	je	.LBB41_23
# %bb.20:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%rbx), %rcx
	subq	%rax, %rcx
	jb	.LBB41_42
# %bb.21:
	movq	48(%r15), %rdx
	subq	%rax, %rdx
	jb	.LBB41_42
# %bb.22:
	movq	%rcx, 24(%rbx)
	movq	%rdx, 48(%r15)
	callq	free@PLT
.LBB41_23:
	movq	$myl_rc_map_sentinel, 56(%r15)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 64(%r15)
	movq	$63, 80(%r15)
	movq	5640(%rbx), %r15
	movq	88(%r15), %rdi
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB41_29
# %bb.24:
	movq	96(%r15), %rax
	cmpq	$-1, %rax
	je	.LBB41_29
# %bb.25:
	testq	%rdi, %rdi
	je	.LBB41_29
# %bb.26:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%rbx), %rcx
	subq	%rax, %rcx
	jb	.LBB41_42
# %bb.27:
	movq	48(%r15), %rdx
	subq	%rax, %rdx
	jb	.LBB41_42
# %bb.28:
	movq	%rcx, 24(%rbx)
	movq	%rdx, 48(%r15)
	callq	free@PLT
	vxorps	%xmm0, %xmm0, %xmm0
.LBB41_29:
	movq	$myl_rc_map_sentinel, 88(%r15)
	vmovups	%xmm0, 96(%r15)
	movq	$63, 112(%r15)
	movq	5640(%rbx), %r15
	movq	120(%r15), %rdi
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB41_35
# %bb.30:
	movq	128(%r15), %rax
	cmpq	$-1, %rax
	je	.LBB41_35
# %bb.31:
	testq	%rdi, %rdi
	je	.LBB41_35
# %bb.32:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%rbx), %rcx
	subq	%rax, %rcx
	jb	.LBB41_42
# %bb.33:
	movq	48(%r15), %rdx
	subq	%rax, %rdx
	jb	.LBB41_42
# %bb.34:
	movq	%rcx, 24(%rbx)
	movq	%rdx, 48(%r15)
	callq	free@PLT
.LBB41_35:
	movq	$myl_rc_map_sentinel, 120(%r15)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 128(%r15)
	movq	$63, 144(%r15)
	movq	5640(%rbx), %r15
	movq	152(%r15), %rdi
	testq	%rdi, %rdi
	je	.LBB41_39
# %bb.36:
	movq	160(%r15), %rcx
	shlq	$4, %rcx
	movq	24(%rbx), %rax
	subq	%rcx, %rax
	jb	.LBB41_42
# %bb.37:
	movq	48(%r15), %rdx
	subq	%rcx, %rdx
	jb	.LBB41_42
# %bb.38:
	movq	%rax, 24(%rbx)
	movq	%rdx, 48(%r15)
	callq	free@PLT
	vxorps	%xmm0, %xmm0, %xmm0
.LBB41_39:
	addq	$152, %r15
	vmovups	%xmm0, (%r15)
	movq	$0, 16(%r15)
	cmpq	$296, 48(%r14)                  # imm = 0x128
	jne	.LBB41_42
# %bb.40:
	addq	$-296, 24(%rbx)                 # imm = 0xFED8
	movq	%r14, %rdi
	callq	free@PLT
	movq	$0, 5640(%rbx)
.LBB41_41:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB41_42:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end41:
	.size	myl_rc_heap_destroy, .Lfunc_end41-myl_rc_heap_destroy
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_edge_release,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_edge_release
	.type	myl_rc_edge_release,@function
myl_rc_edge_release:                    # @myl_rc_edge_release
.Lfunc_begin42:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	testq	%rsi, %rsi
	je	.LBB42_21
# %bb.1:
	movabsq	$4611686018427387906, %rdx      # imm = 0x4000000000000002
	movq	-16(%rsi), %r9
	testq	%rdx, %r9
	je	.LBB42_2
.LBB42_21:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB42_2:
	.cfi_def_cfa %rbp, 16
	testq	%rdi, %rdi
	je	.LBB42_22
# %bb.3:
	cmpq	$0, 5640(%rdi)
	je	.LBB42_22
# %bb.4:
	testb	$1, %r9b
	jne	.LBB42_22
# %bb.5:
	movl	-24(%rsi), %eax
	testl	%eax, %eax
	je	.LBB42_22
# %bb.6:
	leaq	-24(%rsi), %r8
	decl	%eax
	movl	%eax, (%r8)
	jne	.LBB42_21
# %bb.7:
	cmpl	$0, -20(%rsi)
	jne	.LBB42_21
# %bb.8:
	orq	$1, %r9
	movq	%r9, -16(%rsi)
	movq	5640(%rdi), %rax
	cmpl	$0, 208(%rax)
	jne	.LBB42_20
# %bb.9:
	movq	-8(%rsi), %rcx
	cmpq	%rcx, 272(%rax)
	je	.LBB42_17
# %bb.10:
	movl	52(%rcx), %r9d
	cmpq	%r9, 160(%rax)
	jbe	.LBB42_13
# %bb.11:
	movq	152(%rax), %r10
	shlq	$4, %r9
	cmpq	%rcx, (%r10,%r9)
	jne	.LBB42_13
# %bb.12:
	addq	%r9, %r10
	movq	8(%r10), %rax
	testq	%rax, %rax
	je	.LBB42_19
.LBB42_15:
	cmpl	$0, 64(%rax)
	je	.LBB42_16
.LBB42_19:
	movq	5640(%rdi), %rax
.LBB42_20:
	movq	200(%rax), %rax
	movq	%rax, (%r8)
	movq	5640(%rdi), %rax
	movq	%r8, 200(%rax)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB42_16:
	.cfi_def_cfa %rbp, 16
	movq	-16(%rsi), %r9
.LBB42_17:
	incq	%rdx
	andq	%r9, %rdx
	cmpq	$1, %rdx
	jne	.LBB42_22
# %bb.18:
	movq	5640(%rdi), %rax
	movq	8(%rax), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmpq	*%rax                           # TAILCALL
.LBB42_13:
	.cfi_def_cfa %rbp, 16
	movq	%rdi, %r9
	movq	%rax, %rdi
	movq	%rsi, %r10
	movq	%rcx, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r10, %rsi
	movq	%r9, %rdi
	testq	%rax, %rax
	jne	.LBB42_15
	jmp	.LBB42_19
.LBB42_22:
	callq	myl_rc_invariant_failed
.Lfunc_end42:
	.size	myl_rc_edge_release, .Lfunc_end42-myl_rc_edge_release
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_hold_edge_release,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_hold_edge_release
	.type	myl_rc_hold_edge_release,@function
myl_rc_hold_edge_release:               # @myl_rc_hold_edge_release
.Lfunc_begin43:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	testq	%rsi, %rsi
	je	.LBB43_20
# %bb.1:
	movabsq	$4611686018427387906, %rdx      # imm = 0x4000000000000002
	movq	-16(%rsi), %r9
	testq	%rdx, %r9
	je	.LBB43_2
.LBB43_20:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB43_2:
	.cfi_def_cfa %rbp, 16
	testq	%rdi, %rdi
	je	.LBB43_21
# %bb.3:
	cmpq	$0, 5640(%rdi)
	je	.LBB43_21
# %bb.4:
	testb	$1, %r9b
	jne	.LBB43_21
# %bb.5:
	movl	-20(%rsi), %eax
	testl	%eax, %eax
	je	.LBB43_21
# %bb.6:
	decl	%eax
	movl	%eax, -20(%rsi)
	orl	-24(%rsi), %eax
	jne	.LBB43_20
# %bb.7:
	leaq	-24(%rsi), %r8
	orq	$1, %r9
	movq	%r9, -16(%rsi)
	movq	5640(%rdi), %rax
	cmpl	$0, 208(%rax)
	jne	.LBB43_19
# %bb.8:
	movq	-8(%rsi), %rcx
	cmpq	%rcx, 272(%rax)
	je	.LBB43_16
# %bb.9:
	movl	52(%rcx), %r9d
	cmpq	%r9, 160(%rax)
	jbe	.LBB43_12
# %bb.10:
	movq	152(%rax), %r10
	shlq	$4, %r9
	cmpq	%rcx, (%r10,%r9)
	jne	.LBB43_12
# %bb.11:
	addq	%r9, %r10
	movq	8(%r10), %rax
	testq	%rax, %rax
	je	.LBB43_18
.LBB43_14:
	cmpl	$0, 64(%rax)
	je	.LBB43_15
.LBB43_18:
	movq	5640(%rdi), %rax
.LBB43_19:
	movq	200(%rax), %rax
	movq	%rax, (%r8)
	movq	5640(%rdi), %rax
	movq	%r8, 200(%rax)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB43_15:
	.cfi_def_cfa %rbp, 16
	movq	-16(%rsi), %r9
.LBB43_16:
	incq	%rdx
	andq	%r9, %rdx
	cmpq	$1, %rdx
	jne	.LBB43_21
# %bb.17:
	movq	5640(%rdi), %rax
	movq	8(%rax), %rax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmpq	*%rax                           # TAILCALL
.LBB43_12:
	.cfi_def_cfa %rbp, 16
	movq	%rdi, %r9
	movq	%rax, %rdi
	movq	%rsi, %r10
	movq	%rcx, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r10, %rsi
	movq	%r9, %rdi
	testq	%rax, %rax
	jne	.LBB43_14
	jmp	.LBB43_18
.LBB43_21:
	callq	myl_rc_invariant_failed
.Lfunc_end43:
	.size	myl_rc_hold_edge_release, .Lfunc_end43-myl_rc_hold_edge_release
	.cfi_endproc
                                        # -- End function
	.section	.text.unlikely.myl_rc_binding_find_slow,"ax",@progbits
	.type	myl_rc_binding_find_slow,@function # -- Begin function myl_rc_binding_find_slow
myl_rc_binding_find_slow:               # @myl_rc_binding_find_slow
.Lfunc_begin44:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r10
	pushq	%r9
	pushq	%r8
	pushq	%rdi
	pushq	%rsi
	pushq	%rdx
	pushq	%rcx
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -96
	.cfi_offset %r14, -88
	.cfi_offset %r15, -80
	.cfi_offset %rcx, -72
	.cfi_offset %rdx, -64
	.cfi_offset %rsi, -56
	.cfi_offset %rdi, -48
	.cfi_offset %r8, -40
	.cfi_offset %r9, -32
	.cfi_offset %r10, -24
	movq	%rsi, %rbx
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB44_7
# %bb.1:
	movq	152(%rdi), %r11
	shlq	$4, %rax
	leaq	(%r11,%rax), %r15
	movq	(%r11,%rax), %rax
	cmpq	%rbx, %rax
	je	.LBB44_2
# %bb.3:
	testq	%rax, %rax
	je	.LBB44_4
.LBB44_7:
	movq	120(%rdi), %rax
	movq	128(%rdi), %rcx
	movb	144(%rdi), %r11b
	movabsq	$-7046029254386353131, %rdx     # imm = 0x9E3779B97F4A7C15
	imulq	%rbx, %rdx
	shrxq	%r11, %rdx, %r11
	andq	%rcx, %r11
	movq	%r11, %rdx
	shlq	$4, %rdx
	movq	(%rax,%rdx), %rdx
	cmpq	%rbx, %rdx
	je	.LBB44_11
# %bb.8:
	xorl	%r14d, %r14d
.LBB44_9:                               # =>This Inner Loop Header: Depth=1
	testq	%rdx, %rdx
	je	.LBB44_12
# %bb.10:                               #   in Loop: Header=BB44_9 Depth=1
	incq	%r11
	andq	%rcx, %r11
	movq	%r11, %rdx
	shlq	$4, %rdx
	movq	(%rax,%rdx), %rdx
	cmpq	%rbx, %rdx
	jne	.LBB44_9
.LBB44_11:
	shlq	$4, %r11
	movq	8(%rax,%r11), %r14
	jmp	.LBB44_12
.LBB44_2:
	movq	8(%r15), %r14
.LBB44_12:
	movq	%r14, %rax
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rcx
	popq	%rdx
	popq	%rsi
	popq	%rdi
	popq	%r8
	popq	%r9
	popq	%r10
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB44_4:
	.cfi_def_cfa %rbp, 16
	movq	8(%r15), %r14
	testq	%r14, %r14
	je	.LBB44_7
# %bb.5:
	cmpq	%rbx, (%r14)
	jne	.LBB44_7
# %bb.6:
	movq	%r14, %rdi
	callq	flat_build
	movq	%rbx, (%r15)
	jmp	.LBB44_12
.Lfunc_end44:
	.size	myl_rc_binding_find_slow, .Lfunc_end44-myl_rc_binding_find_slow
	.cfi_endproc
                                        # -- End function
	.section	.text.flat_build,"ax",@progbits
	.p2align	4                               # -- Begin function flat_build
	.type	flat_build,@function
flat_build:                             # @flat_build
.Lfunc_begin45:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$872, %rsp                      # imm = 0x368
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	$17, 64(%rdi)
	movw	$0, 68(%rdi)
	movb	$0, 70(%rdi)
	movq	(%rdi), %r14
	movq	(%r14), %rax
	movq	%rax, 80(%rdi)
	cmpq	$0, 16(%rdi)
	jne	.LBB45_6
# %bb.1:
	cmpq	$0, 24(%rdi)
	jne	.LBB45_6
# %bb.2:
	cmpq	$0, 32(%rdi)
	jne	.LBB45_6
# %bb.3:
	cmpq	$0, 40(%rdi)
	jne	.LBB45_6
# %bb.4:
	cmpq	$0, 48(%rdi)
	jne	.LBB45_6
# %bb.5:
	cmpq	$0, 56(%rdi)
	je	.LBB45_7
.LBB45_6:
	addq	$872, %rsp                      # imm = 0x368
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB45_7:
	.cfi_def_cfa %rbp, 16
	leaq	64(%rdi), %rax
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	leaq	-896(%rbp), %rax
	movl	$624, %edx                      # imm = 0x270
	movq	%rdi, -56(%rbp)                 # 8-byte Spill
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%r14, -912(%rbp)
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	8(%rax), %rax
	movq	%rax, -904(%rbp)
	movl	$-1, -880(%rbp)
	movb	$1, %r12b
	movl	$1, %ecx
	movl	$193, %esi
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
.LBB45_10:                              # =>This Inner Loop Header: Depth=1
	cmpq	$9, %rcx
	movzbl	%r12b, %r12d
	movl	$0, %eax
	cmovael	%eax, %r12d
	decq	%rsi
	je	.LBB45_6
# %bb.11:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	(%rcx,%rcx,4), %rax
	movq	-952(%rbp,%rax,8), %r8
	testq	%r8, %r8
	je	.LBB45_6
# %bb.12:                               #   in Loop: Header=BB45_10 Depth=1
	movq	-944(%rbp,%rax,8), %r11
	testq	%r11, %r11
	je	.LBB45_15
# %bb.13:                               #   in Loop: Header=BB45_10 Depth=1
	movq	(%r8), %rdx
	cmpq	(%r11), %rdx
	jne	.LBB45_6
# %bb.14:                               #   in Loop: Header=BB45_10 Depth=1
	movl	8(%r11), %r13d
	jmp	.LBB45_16
.LBB45_15:                              #   in Loop: Header=BB45_10 Depth=1
	xorl	%r13d, %r13d
.LBB45_16:                              #   in Loop: Header=BB45_10 Depth=1
	movzwl	48(%r8), %edx
	cmpl	$7, %edx
	je	.LBB45_19
# %bb.17:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	-912(,%rax,8), %rdi
	addq	%rbp, %rdi
	cmpl	$1, %edx
	je	.LBB45_21
# %bb.18:                               #   in Loop: Header=BB45_10 Depth=1
	testl	%edx, %edx
	jne	.LBB45_28
.LBB45_19:                              #   in Loop: Header=BB45_10 Depth=1
	testl	%r13d, %r13d
	je	.LBB45_8
	jmp	.LBB45_6
.LBB45_21:                              #   in Loop: Header=BB45_10 Depth=1
	cmpw	$5, 50(%r8)
	jne	.LBB45_23
# %bb.22:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	$0, 56(%r8)
	movzbl	%r12b, %r12d
	movl	$0, %eax
	cmovnel	%eax, %r12d
.LBB45_23:                              #   in Loop: Header=BB45_10 Depth=1
	cmpl	$1, %r13d
	jne	.LBB45_6
# %bb.24:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	$8, (%r8)
	jne	.LBB45_6
# %bb.25:                               #   in Loop: Header=BB45_10 Depth=1
	cmpl	$16, %r14d
	je	.LBB45_6
# %bb.26:                               #   in Loop: Header=BB45_10 Depth=1
	movq	-24(%rdi), %rax
	movl	$4294967287, %edx               # imm = 0xFFFFFFF7
	cmpq	%rdx, %rax
	ja	.LBB45_6
# %bb.27:                               #   in Loop: Header=BB45_10 Depth=1
	movl	%r14d, %edx
	incl	%r14d
	leaq	(%rdx,%rdx,2), %rdx
	movl	%eax, -272(%rbp,%rdx,4)
	movq	-8(%rdi), %rax
	movq	%rax, -268(%rbp,%rdx,4)
.LBB45_8:                               #   in Loop: Header=BB45_10 Depth=1
	decq	%rcx
	testq	%rcx, %rcx
	jne	.LBB45_10
	jmp	.LBB45_78
.LBB45_28:                              #   in Loop: Header=BB45_10 Depth=1
	movl	-8(%rdi), %eax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movl	-4(%rdi), %r9d
	cmpl	$4, %edx
	je	.LBB45_43
# %bb.29:                               #   in Loop: Header=BB45_10 Depth=1
	cmpl	$3, %edx
	je	.LBB45_36
# %bb.30:                               #   in Loop: Header=BB45_10 Depth=1
	cmpl	$2, %edx
	jne	.LBB45_6
# %bb.31:                               #   in Loop: Header=BB45_10 Depth=1
	testl	$-3, %r13d
	jne	.LBB45_6
# %bb.32:                               #   in Loop: Header=BB45_10 Depth=1
	movq	24(%r8), %rdx
	cmpl	$2, %r13d
	jne	.LBB45_34
# %bb.33:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	24(%r11), %rdx
	jne	.LBB45_6
.LBB45_34:                              #   in Loop: Header=BB45_10 Depth=1
	movq	-16(%rdi), %rax
	cmpq	%rdx, %rax
	je	.LBB45_8
# %bb.59:                               #   in Loop: Header=BB45_10 Depth=1
	movq	16(%r8), %r10
	testq	%r10, %r10
	je	.LBB45_6
# %bb.60:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	1(%rax), %rdx
	movq	%rdx, -16(%rdi)
	leaq	(%rax,%rax,2), %rdx
	movq	(%r10,%rdx,8), %rax
	movq	8(%r10,%rdx,8), %r15
	cmpl	$2, %r13d
	jne	.LBB45_71
# %bb.61:                               #   in Loop: Header=BB45_10 Depth=1
	movq	16(%r11), %r10
	cmpq	(%r10,%rdx,8), %rax
	jne	.LBB45_6
# %bb.62:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	(%r10,%rdx,8), %rdx
	movq	8(%rdx), %rdx
	jmp	.LBB45_72
.LBB45_36:                              #   in Loop: Header=BB45_10 Depth=1
	cmpl	$3, %r13d
	je	.LBB45_38
# %bb.37:                               #   in Loop: Header=BB45_10 Depth=1
	testl	%r13d, %r13d
	jne	.LBB45_6
.LBB45_38:                              #   in Loop: Header=BB45_10 Depth=1
	movq	32(%r8), %rdx
	cmpl	$3, %r13d
	jne	.LBB45_41
# %bb.39:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	24(%r11), %rdx
	jne	.LBB45_6
# %bb.40:                               #   in Loop: Header=BB45_10 Depth=1
	movq	40(%r8), %rax
	cmpq	32(%r11), %rax
	jne	.LBB45_6
.LBB45_41:                              #   in Loop: Header=BB45_10 Depth=1
	movq	-16(%rdi), %rax
	cmpq	%rdx, %rax
	je	.LBB45_8
# %bb.54:                               #   in Loop: Header=BB45_10 Depth=1
	movq	56(%r8), %r15
	testq	%r15, %r15
	jne	.LBB45_68
# %bb.55:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	$1, 24(%r8)
	jne	.LBB45_65
# %bb.56:                               #   in Loop: Header=BB45_10 Depth=1
	movq	16(%r8), %rdx
	testq	%rdx, %rdx
	je	.LBB45_65
# %bb.57:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	$0, (%rdx)
	je	.LBB45_67
.LBB45_65:                              #   in Loop: Header=BB45_10 Depth=1
	xorl	%r15d, %r15d
.LBB45_68:                              #   in Loop: Header=BB45_10 Depth=1
	leaq	1(%rax), %rdx
	movq	%rdx, -16(%rdi)
	mulq	40(%r8)
	jo	.LBB45_6
.LBB45_69:                              #   in Loop: Header=BB45_10 Depth=1
	cmpl	$3, %r13d
	jne	.LBB45_71
# %bb.70:                               #   in Loop: Header=BB45_10 Depth=1
	movq	16(%r11), %rdx
	jmp	.LBB45_72
.LBB45_43:                              #   in Loop: Header=BB45_10 Depth=1
	testl	$-5, %r13d
	jne	.LBB45_6
# %bb.44:                               #   in Loop: Header=BB45_10 Depth=1
	movq	-16(%rdi), %rax
	movq	24(%r8), %r10
	cmpq	%r10, %rax
	je	.LBB45_8
# %bb.45:                               #   in Loop: Header=BB45_10 Depth=1
	movq	16(%r8), %rdx
	testq	%rdx, %rdx
	je	.LBB45_6
# %bb.46:                               #   in Loop: Header=BB45_10 Depth=1
	movq	%rbx, -64(%rbp)                 # 8-byte Spill
	leaq	1(%rax), %rbx
	movq	%rbx, -16(%rdi)
	leaq	(%rax,%rax,2), %rbx
	movq	(%rdx,%rbx,8), %rax
	movq	8(%rdx,%rbx,8), %r15
	cmpl	$4, %r13d
	jne	.LBB45_63
# %bb.47:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	24(%r11), %r10
	jne	.LBB45_6
# %bb.48:                               #   in Loop: Header=BB45_10 Depth=1
	cmpl	$-1, -48(%rbp)                  # 4-byte Folded Reload
	jne	.LBB45_6
# %bb.49:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	(,%rbx,8), %r13
	addq	16(%r11), %r13
	cmpq	(%r13), %rax
	jne	.LBB45_6
# %bb.50:                               #   in Loop: Header=BB45_10 Depth=1
	leaq	(%rdx,%rbx,8), %rdx
	movl	16(%rdx), %edx
	cmpl	16(%r13), %edx
	jne	.LBB45_6
# %bb.51:                               #   in Loop: Header=BB45_10 Depth=1
	movl	%edx, %r9d
	movq	-24(%rdi), %rdx
	addq	32(%r11), %rdx
	movq	%rdx, -48(%rbp)                 # 8-byte Spill
	jb	.LBB45_6
# %bb.52:                               #   in Loop: Header=BB45_10 Depth=1
	movl	$4294967287, %edx               # imm = 0xFFFFFFF7
	addq	$4, %rdx
	cmpq	%rdx, -48(%rbp)                 # 8-byte Folded Reload
	ja	.LBB45_6
# %bb.53:                               #   in Loop: Header=BB45_10 Depth=1
	movq	8(%r13), %rdx
	movb	$1, %bl
	jmp	.LBB45_72
.LBB45_71:                              #   in Loop: Header=BB45_10 Depth=1
	xorl	%edx, %edx
	jmp	.LBB45_72
.LBB45_63:                              #   in Loop: Header=BB45_10 Depth=1
	xorl	%edx, %edx
	movq	-64(%rbp), %rbx                 # 8-byte Reload
.LBB45_72:                              #   in Loop: Header=BB45_10 Depth=1
	cmpq	$16, %rcx
	je	.LBB45_6
# %bb.73:                               #   in Loop: Header=BB45_10 Depth=1
	testq	%r15, %r15
	je	.LBB45_6
# %bb.74:                               #   in Loop: Header=BB45_10 Depth=1
	movq	(%r8), %r8
	subq	%rax, %r8
	jb	.LBB45_6
# %bb.75:                               #   in Loop: Header=BB45_10 Depth=1
	cmpq	%r8, (%r15)
	ja	.LBB45_6
# %bb.76:                               #   in Loop: Header=BB45_10 Depth=1
	addq	-24(%rdi), %rax
	jb	.LBB45_6
# %bb.77:                               #   in Loop: Header=BB45_10 Depth=1
	incq	%rcx
	movq	%r15, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movl	%eax, 32(%rdi)
	movl	%r9d, 36(%rdi)
	testq	%rcx, %rcx
	jne	.LBB45_10
	jmp	.LBB45_78
.LBB45_67:                              #   in Loop: Header=BB45_10 Depth=1
	movq	8(%rdx), %r15
	leaq	1(%rax), %rdx
	movq	%rdx, -16(%rdi)
	mulq	40(%r8)
	jno	.LBB45_69
	jmp	.LBB45_6
.LBB45_78:
	leaq	-272(%rbp), %rdi
	movl	%r14d, %esi
	callq	flat_disjoint
	testl	%eax, %eax
	je	.LBB45_6
# %bb.79:
	leaq	-272(%rbp), %rsi
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	movl	%r14d, %edx
	callq	flat_masks
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	testl	%eax, %eax
	je	.LBB45_6
# %bb.80:
	movl	%r14d, 64(%rcx)
	movb	%r12b, 68(%rcx)
	movb	%bl, 70(%rcx)
	jmp	.LBB45_6
.Lfunc_end45:
	.size	flat_build, .Lfunc_end45-flat_build
	.cfi_endproc
                                        # -- End function
	.section	.text.flat_disjoint,"ax",@progbits
	.p2align	4                               # -- Begin function flat_disjoint
	.type	flat_disjoint,@function
flat_disjoint:                          # @flat_disjoint
.Lfunc_begin46:
	.cfi_startproc
# %bb.0:
	movl	$1, %eax
	testl	%esi, %esi
	je	.LBB46_15
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%esi, %ecx
	leaq	8(%rdi), %rdx
	xorl	%esi, %esi
	movl	$4294967295, %r8d               # imm = 0xFFFFFFFF
.LBB46_2:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB46_4 Depth 2
	leaq	(%rsi,%rsi,2), %r9
	leaq	(%rdi,%r9,4), %r9
	movq	%rdx, %r10
	xorl	%r11d, %r11d
	jmp	.LBB46_4
	.p2align	4
.LBB46_3:                               #   in Loop: Header=BB46_4 Depth=2
	incq	%r11
	addq	$12, %r10
	cmpq	%r11, %rcx
	je	.LBB46_11
.LBB46_4:                               #   Parent Loop BB46_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpq	%r11, %rsi
	jae	.LBB46_9
# %bb.5:                                #   in Loop: Header=BB46_4 Depth=2
	movl	4(%r9), %ebx
	cmpl	$-1, %ebx
	je	.LBB46_8
# %bb.6:                                #   in Loop: Header=BB46_4 Depth=2
	cmpl	-4(%r10), %ebx
	jne	.LBB46_8
# %bb.7:                                #   in Loop: Header=BB46_4 Depth=2
	movl	8(%r9), %ebx
	cmpl	(%r10), %ebx
	jne	.LBB46_9
	.p2align	4
.LBB46_8:                               #   in Loop: Header=BB46_4 Depth=2
	movl	(%r9), %ebx
	movl	-8(%r10), %r14d
	movl	%ebx, %r15d
	subl	%r14d, %r15d
	negl	%r15d
	subl	%r14d, %ebx
	cmovbq	%r15, %rbx
	cmpl	$8, %ebx
	jb	.LBB46_13
.LBB46_9:                               #   in Loop: Header=BB46_4 Depth=2
	movl	-4(%r10), %ebx
	cmpq	%r8, %rbx
	je	.LBB46_3
# %bb.10:                               #   in Loop: Header=BB46_4 Depth=2
	movl	(%r9), %r14d
	movl	%r14d, %r15d
	subl	%ebx, %r15d
	movl	%r15d, %r12d
	negl	%r12d
	xorl	%r13d, %r13d
	cmpl	$8, %r12d
	setae	%r13b
	xorl	%r12d, %r12d
	cmpl	$4, %r15d
	setae	%r12b
	cmpl	%ebx, %r14d
	cmovael	%r12d, %r13d
	cmpb	$1, %r13b
	je	.LBB46_3
	jmp	.LBB46_13
	.p2align	4
.LBB46_11:                              #   in Loop: Header=BB46_2 Depth=1
	incq	%rsi
	cmpq	%rcx, %rsi
	jne	.LBB46_2
	jmp	.LBB46_14
.LBB46_13:
	xorl	%eax, %eax
.LBB46_14:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
.LBB46_15:
	retq
.Lfunc_end46:
	.size	flat_disjoint, .Lfunc_end46-flat_disjoint
	.cfi_endproc
                                        # -- End function
	.section	.text.flat_masks,"ax",@progbits
	.p2align	4                               # -- Begin function flat_masks
	.type	flat_masks,@function
flat_masks:                             # @flat_masks
.Lfunc_begin47:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movl	$-1, %ecx
	testl	%edx, %edx
	je	.LBB47_9
# %bb.1:
	movl	%edx, %r9d
	leaq	8(%rsi), %r11
	movl	$-1, %r14d
	xorl	%ebx, %ebx
	xorl	%r8d, %r8d
	jmp	.LBB47_4
	.p2align	4
.LBB47_2:                               #   in Loop: Header=BB47_4 Depth=1
	btsl	%ebx, %r8d
	movl	%r14d, %r10d
.LBB47_3:                               #   in Loop: Header=BB47_4 Depth=1
	incq	%rbx
	addq	$12, %r11
	movl	%r10d, %r14d
	cmpq	%rbx, %r9
	je	.LBB47_10
.LBB47_4:                               # =>This Inner Loop Header: Depth=1
	movl	-4(%r11), %r10d
	cmpl	$-1, %r10d
	je	.LBB47_2
# %bb.5:                                #   in Loop: Header=BB47_4 Depth=1
	xorl	%eax, %eax
	cmpl	$-1, %r14d
	je	.LBB47_7
# %bb.6:                                #   in Loop: Header=BB47_4 Depth=1
	cmpl	%r10d, %r14d
	jne	.LBB47_8
.LBB47_7:                               #   in Loop: Header=BB47_4 Depth=1
	cmpl	$31, (%r11)
	jbe	.LBB47_3
.LBB47_8:
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB47_9:
	.cfi_def_cfa %rbp, 16
	xorl	%r8d, %r8d
	movl	$-1, %r10d
	jmp	.LBB47_13
.LBB47_10:
	xorl	%eax, %eax
	movq	%rsi, %r11
	xorl	%ebx, %ebx
	.p2align	4
.LBB47_11:                              # =>This Inner Loop Header: Depth=1
	movl	(%r11), %r14d
	cmpl	$65527, %r14d                   # imm = 0xFFF7
	ja	.LBB47_8
# %bb.12:                               #   in Loop: Header=BB47_11 Depth=1
	movw	%r14w, 92(%rdi,%rbx,2)
	incq	%rbx
	addq	$12, %r11
	cmpq	%rbx, %r9
	jne	.LBB47_11
.LBB47_13:
	shlxl	%edx, %ecx, %eax
	notl	%eax
	movw	%ax, 24(%rdi)
	movl	%r10d, 8(%rdi)
	vmovd	%r8d, %xmm0
	vpbroadcastw	%xmm0, %ymm0
	vmovdqu	%ymm0, 26(%rdi)
	vmovdqu	%ymm0, 58(%rdi)
	movw	%r8w, 90(%rdi)
	movl	$1, %eax
	testl	%edx, %edx
	je	.LBB47_8
# %bb.14:
	cmpl	$1, %edx
	jne	.LBB47_16
# %bb.15:
	xorl	%ecx, %ecx
	jmp	.LBB47_23
.LBB47_16:
	movl	%edx, %edx
	movl	%edx, %eax
	andl	$-2, %eax
	leaq	20(%rsi), %r8
	xorl	%ecx, %ecx
	movl	$1, %r9d
	jmp	.LBB47_18
	.p2align	4
.LBB47_17:                              #   in Loop: Header=BB47_18 Depth=1
	addq	$2, %rcx
	addq	$24, %r8
	cmpq	%rcx, %rax
	je	.LBB47_22
.LBB47_18:                              # =>This Inner Loop Header: Depth=1
	cmpl	$-1, -16(%r8)
	je	.LBB47_20
# %bb.19:                               #   in Loop: Header=BB47_18 Depth=1
	shlxl	%ecx, %r9d, %r10d
	movl	-12(%r8), %r11d
	orw	%r10w, 28(%rdi,%r11,2)
.LBB47_20:                              #   in Loop: Header=BB47_18 Depth=1
	cmpl	$-1, -4(%r8)
	je	.LBB47_17
# %bb.21:                               #   in Loop: Header=BB47_18 Depth=1
	leal	1(%rcx), %r10d
	shlxl	%r10d, %r9d, %r10d
	movl	(%r8), %r11d
	orw	%r10w, 28(%rdi,%r11,2)
	jmp	.LBB47_17
.LBB47_22:
	movl	$1, %eax
	testb	$1, %dl
	je	.LBB47_8
.LBB47_23:
	leaq	(%rcx,%rcx,2), %rdx
	cmpl	$-1, 4(%rsi,%rdx,4)
	movl	$1, %eax
	je	.LBB47_8
# %bb.24:
	leaq	(%rsi,%rdx,4), %rdx
	movl	$1, %eax
	shlxl	%ecx, %eax, %ecx
	movl	8(%rdx), %edx
	orw	%cx, 28(%rdi,%rdx,2)
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.Lfunc_end47:
	.size	flat_masks, .Lfunc_end47-flat_masks
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_module_register,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_module_register
	.type	myl_rc_module_register,@function
myl_rc_module_register:                 # @myl_rc_module_register
.Lfunc_begin48:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB48_38
# %bb.1:
	movq	%rsi, %rbx
	testq	%rsi, %rsi
	je	.LBB48_38
# %bb.2:
	movq	5640(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB48_38
# %bb.3:
	cmpl	$4, (%rbx)
	jne	.LBB48_38
# %bb.4:
	cmpq	$0, 192(%rcx)
	jne	.LBB48_38
# %bb.5:
	movq	56(%rcx), %rax
	movq	64(%rcx), %rdx
	movzbl	80(%rcx), %ecx
	movabsq	$-7046029254386353131, %rsi     # imm = 0x9E3779B97F4A7C15
	imulq	%rbx, %rsi
	shrxq	%rcx, %rsi, %rcx
	.p2align	4
.LBB48_6:                               # =>This Inner Loop Header: Depth=1
	andq	%rdx, %rcx
	movq	%rcx, %rsi
	shlq	$4, %rsi
	movq	(%rax,%rsi), %rsi
	cmpq	%rbx, %rsi
	je	.LBB48_9
# %bb.7:                                #   in Loop: Header=BB48_6 Depth=1
	testq	%rsi, %rsi
	je	.LBB48_10
# %bb.8:                                #   in Loop: Header=BB48_6 Depth=1
	incq	%rcx
	jmp	.LBB48_6
.LBB48_9:
	shlq	$4, %rcx
	xorl	%r14d, %r14d
	cmpq	$0, 8(%rax,%rcx)
	jne	.LBB48_37
.LBB48_10:
	movq	16(%rbx), %rax
	testq	%rax, %rax
	je	.LBB48_12
# %bb.11:
	cmpq	$0, 8(%rbx)
	je	.LBB48_38
.LBB48_12:
	movq	32(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB48_14
# %bb.13:
	cmpq	$0, 24(%rbx)
	je	.LBB48_38
.LBB48_14:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -72(%rbp)
	movq	$0, -40(%rbp)
	movq	%rdi, -80(%rbp)
	testq	%rax, %rax
	je	.LBB48_19
# %bb.15:
	xorl	%r15d, %r15d
	leaq	-80(%rbp), %r14
	.p2align	4
.LBB48_16:                              # =>This Inner Loop Header: Depth=1
	movq	8(%rbx), %rax
	movq	(%rax,%r15,8), %rsi
	movq	%r14, %rdi
	vzeroupper
	callq	builder_add
	testl	%eax, %eax
	je	.LBB48_28
# %bb.17:                               #   in Loop: Header=BB48_16 Depth=1
	incq	%r15
	cmpq	16(%rbx), %r15
	jb	.LBB48_16
# %bb.18:
	movq	32(%rbx), %rcx
.LBB48_19:
	testq	%rcx, %rcx
	je	.LBB48_26
# %bb.20:
	movl	$8, %r15d
	xorl	%r12d, %r12d
	leaq	-80(%rbp), %r14
	.p2align	4
.LBB48_21:                              # =>This Inner Loop Header: Depth=1
	movq	24(%rbx), %rcx
	movq	-8(%rcx,%r15), %rax
	testq	%rax, %rax
	je	.LBB48_38
# %bb.22:                               #   in Loop: Header=BB48_21 Depth=1
	movq	(%rcx,%r15), %rsi
	testq	%rsi, %rsi
	je	.LBB48_38
# %bb.23:                               #   in Loop: Header=BB48_21 Depth=1
	movq	(%rax), %rax
	cmpq	(%rsi), %rax
	jne	.LBB48_38
# %bb.24:                               #   in Loop: Header=BB48_21 Depth=1
	movq	%r14, %rdi
	vzeroupper
	callq	builder_add
	testl	%eax, %eax
	je	.LBB48_28
# %bb.25:                               #   in Loop: Header=BB48_21 Depth=1
	incq	%r12
	addq	$64, %r15
	cmpq	32(%rbx), %r12
	jb	.LBB48_21
.LBB48_26:
	leaq	-80(%rbp), %rdi
	movq	%rbx, %rsi
	movl	$1, %edx
	vzeroupper
	callq	register_shapes
	movl	%eax, %r14d
	jmp	.LBB48_29
.LBB48_28:
	movl	$1, %r14d
.LBB48_29:
	movq	-80(%rbp), %rbx
	movq	-72(%rbp), %rdi
	movq	-48(%rbp), %r15
	testq	%rdi, %rdi
	je	.LBB48_33
# %bb.30:
	leaq	(,%r15,8), %rax
	leaq	(%rax,%rax,4), %rcx
	movq	24(%rbx), %rax
	subq	%rcx, %rax
	jb	.LBB48_38
# %bb.31:
	movq	5640(%rbx), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB48_38
# %bb.32:
	movq	%rax, 24(%rbx)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
.LBB48_33:
	movq	-64(%rbp), %rdi
	testq	%rdi, %rdi
	je	.LBB48_37
# %bb.34:
	shlq	$4, %r15
	movq	24(%rbx), %rax
	subq	%r15, %rax
	jb	.LBB48_38
# %bb.35:
	movq	5640(%rbx), %rcx
	movq	48(%rcx), %rdx
	subq	%r15, %rdx
	jb	.LBB48_38
# %bb.36:
	movq	%rax, 24(%rbx)
	movq	%rdx, 48(%rcx)
	callq	free@PLT
.LBB48_37:
	movl	%r14d, %eax
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB48_38:
	.cfi_def_cfa %rbp, 16
	vzeroupper
	callq	myl_rc_invariant_failed
.Lfunc_end48:
	.size	myl_rc_module_register, .Lfunc_end48-myl_rc_module_register
	.cfi_endproc
                                        # -- End function
	.section	.text.builder_add,"ax",@progbits
	.p2align	4                               # -- Begin function builder_add
	.type	builder_add,@function
builder_add:                            # @builder_add
.Lfunc_begin49:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rsi, %rsi
	je	.LBB49_55
# %bb.1:
	movabsq	$-4658895280553007687, %r12     # imm = 0xBF58476D1CE4E5B9
	movq	32(%rdi), %rbx
	testq	%rbx, %rbx
	je	.LBB49_6
# %bb.2:
	movq	16(%rdi), %rax
	movq	%rsi, %rcx
	shrq	$3, %rcx
	movq	%rsi, %rdx
	shrq	$33, %rdx
	xorq	%rcx, %rdx
	imulq	%r12, %rdx
	movq	%rdx, %rcx
	shrq	$27, %rcx
	xorq	%rdx, %rcx
	leaq	-1(,%rbx,2), %rdx
	andq	%rdx, %rcx
	movq	(%rax,%rcx,8), %r9
	testq	%r9, %r9
	je	.LBB49_6
# %bb.3:
	movq	8(%rdi), %r8
	.p2align	4
.LBB49_4:                               # =>This Inner Loop Header: Depth=1
	leaq	(%r9,%r9,4), %r9
	cmpq	%rsi, -40(%r8,%r9,8)
	je	.LBB49_15
# %bb.5:                                #   in Loop: Header=BB49_4 Depth=1
	incq	%rcx
	andq	%rdx, %rcx
	movq	(%rax,%rcx,8), %r9
	testq	%r9, %r9
	jne	.LBB49_4
.LBB49_6:
	movq	24(%rdi), %rax
	cmpq	%rbx, %rax
	jne	.LBB49_10
# %bb.7:
	leaq	(%rbx,%rbx), %rax
	testq	%rbx, %rbx
	movl	$16, %r15d
	cmovneq	%rax, %r15
	xorl	%eax, %eax
	cmpq	%rbx, %r15
	jb	.LBB49_16
# %bb.8:
	movl	$40, %ecx
	movq	%r15, %rax
	mulq	%rcx
	jno	.LBB49_17
.LBB49_9:
	xorl	%eax, %eax
	jmp	.LBB49_16
.LBB49_10:
	movq	8(%rdi), %rcx
	movq	16(%rdi), %r14
.LBB49_11:
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movq	%rsi, %r8
	shrq	$33, %r8
	xorq	%rdx, %r8
	imulq	%r12, %r8
	movq	%r8, %rdx
	shrq	$27, %rdx
	xorq	%r8, %rdx
	leaq	-1(,%rbx,2), %r8
	andq	%r8, %rdx
	movq	(%r14,%rdx,8), %r9
	testq	%r9, %r9
	je	.LBB49_14
	.p2align	4
.LBB49_12:                              # =>This Inner Loop Header: Depth=1
	leaq	(%r9,%r9,4), %r9
	cmpq	%rsi, -40(%rcx,%r9,8)
	je	.LBB49_14
# %bb.13:                               #   in Loop: Header=BB49_12 Depth=1
	incq	%rdx
	andq	%r8, %rdx
	movq	(%r14,%rdx,8), %r9
	testq	%r9, %r9
	jne	.LBB49_12
.LBB49_14:
	leaq	(%rax,%rax,4), %r8
	movq	%rsi, (%rcx,%r8,8)
	incq	%rax
	movq	%rax, 24(%rdi)
	movq	%rax, (%r14,%rdx,8)
.LBB49_15:
	movl	$1, %eax
.LBB49_16:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB49_17:
	.cfi_def_cfa %rbp, 16
	movq	(%rdi), %r12
	testq	%r12, %r12
	je	.LBB49_55
# %bb.18:
	testq	%rax, %rax
	je	.LBB49_55
# %bb.19:
	movq	5640(%r12), %rcx
	testq	%rcx, %rcx
	je	.LBB49_55
# %bb.20:
	movq	24(%r12), %rdx
	movq	%rdx, %r13
	addq	%rax, %r13
	jb	.LBB49_23
# %bb.21:
	movq	88(%r12), %r14
	testq	%r14, %r14
	je	.LBB49_24
# %bb.22:
	cmpq	%r14, %r13
	jbe	.LBB49_24
.LBB49_23:
	movl	$1, 108(%r12)
	xorl	%eax, %eax
	jmp	.LBB49_16
.LBB49_24:
	movq	%rdx, -112(%rbp)                # 8-byte Spill
	movq	%rcx, -88(%rbp)                 # 8-byte Spill
	movq	%rsi, -56(%rbp)                 # 8-byte Spill
	movq	%rdi, -64(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movq	%rax, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB49_9
# %bb.25:
	movq	%r13, 24(%r12)
	movq	-88(%rbp), %rdx                 # 8-byte Reload
	movq	48(%rdx), %r8
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	leaq	(%r8,%rcx), %r9
	movq	%r9, 48(%rdx)
	testq	%r15, %r15
	je	.LBB49_55
# %bb.26:
	movq	%r15, %rsi
	shlq	$4, %rsi
	movq	%r13, %rdi
	addq	%rsi, %rdi
	jb	.LBB49_29
# %bb.27:
	testq	%r14, %r14
	je	.LBB49_34
# %bb.28:
	cmpq	%r14, %rdi
	jbe	.LBB49_34
.LBB49_29:
	movl	$1, 108(%r12)
.LBB49_30:
	cmpq	%rcx, %r13
	jb	.LBB49_55
# %bb.31:
	cmpq	%rcx, %r9
	jb	.LBB49_55
# %bb.32:
	movq	-112(%rbp), %rcx                # 8-byte Reload
	movq	%rcx, 24(%r12)
	movq	%r8, 48(%rdx)
	movq	%rax, %rdi
	callq	free@PLT
	jmp	.LBB49_9
.LBB49_34:
	movq	%rdi, -96(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%r9, -80(%rbp)                  # 8-byte Spill
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	movq	%r8, %r14
	movq	%rsi, -104(%rbp)                # 8-byte Spill
	callq	calloc@PLT
	movq	%r14, %r8
	movq	-80(%rbp), %r9                  # 8-byte Reload
	movq	-88(%rbp), %rdx                 # 8-byte Reload
	movq	%rax, %r14
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	-72(%rbp), %rax                 # 8-byte Reload
	testq	%r14, %r14
	je	.LBB49_30
# %bb.35:
	addq	-104(%rbp), %r9                 # 8-byte Folded Reload
	movq	-96(%rbp), %rdi                 # 8-byte Reload
	movq	%rdi, 24(%r12)
	movq	%r9, -80(%rbp)                  # 8-byte Spill
	movq	%r9, 48(%rdx)
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	8(%rcx), %r8
	testq	%rbx, %rbx
	je	.LBB49_37
# %bb.36:
	leaq	(,%rbx,8), %rcx
	leaq	(%rcx,%rcx,4), %rdx
	movq	%rax, %rdi
	movq	%r8, %rsi
	movq	%r8, %r13
	movq	%rdx, -48(%rbp)                 # 8-byte Spill
	callq	memcpy@PLT
	movq	%r13, %r8
	movq	-96(%rbp), %rdi                 # 8-byte Reload
	jmp	.LBB49_38
.LBB49_37:
	movq	$0, -48(%rbp)                   # 8-byte Folded Spill
.LBB49_38:
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	testq	%r8, %r8
	je	.LBB49_42
# %bb.39:
	movq	-48(%rbp), %rax                 # 8-byte Reload
	subq	%rax, %rdi
	movq	-80(%rbp), %r13                 # 8-byte Reload
	jb	.LBB49_55
# %bb.40:
	subq	%rax, %r13
	jb	.LBB49_55
# %bb.41:
	movq	%rdi, 24(%r12)
	movq	-88(%rbp), %rax                 # 8-byte Reload
	movq	%r13, 48(%rax)
	movq	%r8, %rdi
	callq	free@PLT
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	movq	(%rdi), %r12
	movq	32(%rdi), %rbx
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	jmp	.LBB49_43
.LBB49_42:
	movq	-64(%rbp), %rdi                 # 8-byte Reload
.LBB49_43:
	movq	16(%rdi), %rax
	testq	%rax, %rax
	movq	-72(%rbp), %rcx                 # 8-byte Reload
	je	.LBB49_47
# %bb.44:
	shlq	$4, %rbx
	movq	24(%r12), %rcx
	subq	%rbx, %rcx
	jb	.LBB49_55
# %bb.45:
	movq	5640(%r12), %rdx
	movq	48(%rdx), %rsi
	subq	%rbx, %rsi
	jb	.LBB49_55
# %bb.46:
	movq	%rcx, 24(%r12)
	movq	%rsi, 48(%rdx)
	movq	%rax, %rdi
	callq	free@PLT
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	movq	-56(%rbp), %rsi                 # 8-byte Reload
	movq	-72(%rbp), %rcx                 # 8-byte Reload
.LBB49_47:
	movq	%rcx, 8(%rdi)
	movq	%r14, 16(%rdi)
	movq	%r15, 32(%rdi)
	movq	24(%rdi), %rax
	testq	%rax, %rax
	je	.LBB49_54
# %bb.48:
	leaq	-1(,%r15,2), %rdx
	xorl	%r8d, %r8d
	movabsq	$-4658895280553007687, %r12     # imm = 0xBF58476D1CE4E5B9
	jmp	.LBB49_50
.LBB49_49:                              #   in Loop: Header=BB49_50 Depth=1
	incq	%r8
	movq	%r8, (%r14,%r9,8)
	cmpq	%rax, %r8
	je	.LBB49_53
.LBB49_50:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB49_51 Depth 2
	leaq	(%r8,%r8,4), %r9
	movq	(%rcx,%r9,8), %r10
	movq	%r10, %r9
	shrq	$3, %r9
	movq	%r10, %r11
	shrq	$33, %r11
	xorq	%r9, %r11
	imulq	%r12, %r11
	movq	%r11, %r9
	shrq	$27, %r9
	xorq	%r11, %r9
	andq	%rdx, %r9
	movq	(%r14,%r9,8), %r11
	testq	%r11, %r11
	je	.LBB49_49
	.p2align	4
.LBB49_51:                              #   Parent Loop BB49_50 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	(%r11,%r11,4), %r11
	cmpq	%r10, -40(%rcx,%r11,8)
	je	.LBB49_49
# %bb.52:                               #   in Loop: Header=BB49_51 Depth=2
	incq	%r9
	andq	%rdx, %r9
	movq	(%r14,%r9,8), %r11
	testq	%r11, %r11
	jne	.LBB49_51
	jmp	.LBB49_49
.LBB49_53:
	movq	%r15, %rbx
	jmp	.LBB49_11
.LBB49_54:
	xorl	%eax, %eax
	movq	%r15, %rbx
	movabsq	$-4658895280553007687, %r12     # imm = 0xBF58476D1CE4E5B9
	jmp	.LBB49_11
.LBB49_55:
	callq	myl_rc_invariant_failed
.Lfunc_end49:
	.size	builder_add, .Lfunc_end49-builder_add
	.cfi_endproc
                                        # -- End function
	.section	.text.register_shapes,"ax",@progbits
	.p2align	4                               # -- Begin function register_shapes
	.type	register_shapes,@function
register_shapes:                        # @register_shapes
.Lfunc_begin50:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%edx, %r10d
	movq	%rdi, %r15
	movq	(%rdi), %r9
	movq	24(%rdi), %r8
	testq	%r8, %r8
	movq	%rdi, -72(%rbp)                 # 8-byte Spill
	je	.LBB50_38
# %bb.1:
	xorl	%ebx, %ebx
	jmp	.LBB50_4
.LBB50_2:                               #   in Loop: Header=BB50_4 Depth=1
	movq	-72(%rbp), %r15                 # 8-byte Reload
	movq	24(%r15), %r8
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movq	-56(%rbp), %r9                  # 8-byte Reload
	movl	-44(%rbp), %r10d                # 4-byte Reload
	.p2align	4
.LBB50_3:                               #   in Loop: Header=BB50_4 Depth=1
	incq	%rbx
	cmpq	%r8, %rbx
	jae	.LBB50_33
.LBB50_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB50_17 Depth 2
                                        #     Child Loop BB50_29 Depth 2
	movq	8(%r15), %rax
	leaq	(%rbx,%rbx,4), %rcx
	movq	(%rax,%rcx,8), %r14
	movl	8(%r14), %eax
	cmpq	$5, %rax
	ja	.LBB50_131
# %bb.5:                                #   in Loop: Header=BB50_4 Depth=1
	jmpq	*.LJTI50_0(,%rax,8)
.LBB50_6:                               #   in Loop: Header=BB50_4 Depth=1
	cmpq	$8, (%r14)
	jne	.LBB50_131
# %bb.7:                                #   in Loop: Header=BB50_4 Depth=1
	cmpl	$2, %eax
	je	.LBB50_9
# %bb.8:                                #   in Loop: Header=BB50_4 Depth=1
	cmpl	$4, %eax
	jne	.LBB50_3
.LBB50_9:                               #   in Loop: Header=BB50_4 Depth=1
	movq	16(%r14), %rcx
	xorl	%r12d, %r12d
	jmp	.LBB50_11
	.p2align	4
.LBB50_10:                              #   in Loop: Header=BB50_4 Depth=1
	movq	16(%r14), %rcx
	movq	24(%r14), %r12
	testq	%r12, %r12
	setne	%dl
	testq	%rcx, %rcx
	sete	%dil
	andb	%dl, %dil
	cmpb	$1, %dil
	je	.LBB50_131
.LBB50_11:                              #   in Loop: Header=BB50_4 Depth=1
	cmpl	$4, %eax
	jne	.LBB50_14
# %bb.12:                               #   in Loop: Header=BB50_4 Depth=1
	movq	32(%r14), %rax
	addq	$4, %rax
	jb	.LBB50_116
# %bb.13:                               #   in Loop: Header=BB50_4 Depth=1
	cmpq	(%r14), %rax
	ja	.LBB50_131
.LBB50_14:                              #   in Loop: Header=BB50_4 Depth=1
	movl	$1, %eax
	addq	%r12, 40(%r15)
	jb	.LBB50_117
# %bb.15:                               #   in Loop: Header=BB50_4 Depth=1
	testq	%r12, %r12
	je	.LBB50_3
# %bb.16:                               #   in Loop: Header=BB50_4 Depth=1
	addq	$8, %rcx
	movq	%r12, %rdx
	.p2align	4
.LBB50_17:                              #   Parent Loop BB50_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB50_131
# %bb.18:                               #   in Loop: Header=BB50_17 Depth=2
	movq	-8(%rcx), %r8
	addq	(%rdi), %r8
	jb	.LBB50_117
# %bb.19:                               #   in Loop: Header=BB50_17 Depth=2
	cmpq	(%r14), %r8
	ja	.LBB50_131
# %bb.20:                               #   in Loop: Header=BB50_17 Depth=2
	addq	$24, %rcx
	decq	%rdx
	jne	.LBB50_17
# %bb.21:                               #   in Loop: Header=BB50_4 Depth=1
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	jmp	.LBB50_28
.LBB50_22:                              #   in Loop: Header=BB50_4 Depth=1
	movq	24(%r14), %rax
	testq	%rax, %rax
	je	.LBB50_3
# %bb.23:                               #   in Loop: Header=BB50_4 Depth=1
	movq	16(%r14), %rdx
	testq	%rdx, %rdx
	je	.LBB50_131
# %bb.24:                               #   in Loop: Header=BB50_4 Depth=1
	movq	32(%r14), %rcx
	movq	(%rdx), %rdi
	cmpq	%rdi, %rcx
	jb	.LBB50_131
# %bb.25:                               #   in Loop: Header=BB50_4 Depth=1
	decq	%rax
	mulq	%rcx
	movq	%rax, %rcx
	movl	$1, %eax
	jo	.LBB50_117
# %bb.26:                               #   in Loop: Header=BB50_4 Depth=1
	addq	%rdi, %rcx
	jb	.LBB50_117
# %bb.27:                               #   in Loop: Header=BB50_4 Depth=1
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movl	$1, %r12d
	cmpq	(%r14), %rcx
	ja	.LBB50_131
.LBB50_28:                              #   in Loop: Header=BB50_4 Depth=1
	leaq	16(%r14), %r13
	movl	$8, %r15d
	.p2align	4
.LBB50_29:                              #   Parent Loop BB50_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpl	$3, 8(%r14)
	movq	%r13, %rax
	je	.LBB50_31
# %bb.30:                               #   in Loop: Header=BB50_29 Depth=2
	movq	(%r13), %rax
	addq	%r15, %rax
.LBB50_31:                              #   in Loop: Header=BB50_29 Depth=2
	movq	(%rax), %rsi
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	callq	builder_add
	testl	%eax, %eax
	je	.LBB50_116
# %bb.32:                               #   in Loop: Header=BB50_29 Depth=2
	addq	$24, %r15
	decq	%r12
	jne	.LBB50_29
	jmp	.LBB50_2
.LBB50_33:
	movq	%r8, %rax
	shrq	$61, %rax
	movl	$1, %eax
	jne	.LBB50_117
# %bb.34:
	testq	%r8, %r8
	je	.LBB50_38
# %bb.35:
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	shlq	$3, %r8
	movq	(%r15), %rdi
	movq	%r8, -88(%rbp)                  # 8-byte Spill
	movq	%r8, %rsi
	callq	myl_rc_meta_alloc
	testq	%rax, %rax
	je	.LBB50_116
# %bb.36:
	movq	24(%r15), %rcx
	testq	%rcx, %rcx
	je	.LBB50_126
# %bb.37:
	movq	8(%r15), %rdx
	xorl	%r12d, %r12d
	movabsq	$-7046029254386353131, %rbx     # imm = 0x9E3779B97F4A7C15
	xorl	%edi, %edi
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	jmp	.LBB50_48
.LBB50_38:
	xorl	%edi, %edi
	xorl	%r12d, %r12d
.LBB50_39:
	movl	$24, %eax
	mulq	40(%r15)
	movq	%rax, %r14
	movl	$1, %eax
	jo	.LBB50_117
# %bb.40:
	movq	32(%rsi), %r8
	movl	$200, %ecx
	movq	%r8, %rax
	mulq	%rcx
	jno	.LBB50_41
.LBB50_116:
	movl	$1, %eax
.LBB50_117:
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB50_47:                              #   in Loop: Header=BB50_48 Depth=1
	.cfi_def_cfa %rbp, 16
	incq	%rdi
	movq	-80(%rbp), %rcx                 # 8-byte Reload
	cmpq	%rcx, %rdi
	jae	.LBB50_127
.LBB50_48:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB50_53 Depth 2
                                        #       Child Loop BB50_63 Depth 3
                                        #       Child Loop BB50_68 Depth 3
	leaq	(%rdi,%rdi,4), %rcx
	cmpl	$2, 32(%rdx,%rcx,8)
	je	.LBB50_47
# %bb.49:                               #   in Loop: Header=BB50_48 Depth=1
	movq	%rdi, (%rax)
	movl	$1, %r8d
	jmp	.LBB50_53
	.p2align	4
.LBB50_50:                              #   in Loop: Header=BB50_53 Depth=2
	movq	-72(%rbp), %r15                 # 8-byte Reload
.LBB50_51:                              #   in Loop: Header=BB50_53 Depth=2
	cmpq	%r12, %r10
	cmovaq	%r10, %r12
	movl	$2, 32(%r9)
	decq	%r8
.LBB50_52:                              #   in Loop: Header=BB50_53 Depth=2
	testq	%r8, %r8
	je	.LBB50_47
.LBB50_53:                              #   Parent Loop BB50_48 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB50_63 Depth 3
                                        #       Child Loop BB50_68 Depth 3
	movq	-8(%rax,%r8,8), %rcx
	leaq	(%rcx,%rcx,4), %r10
	movl	$1, 32(%rdx,%r10,8)
	movq	(%rdx,%r10,8), %r11
	movl	8(%r11), %ecx
	cmpq	$5, %rcx
	ja	.LBB50_131
# %bb.54:                               #   in Loop: Header=BB50_53 Depth=2
	leaq	(%rdx,%r10,8), %r9
	movq	8(%rdx,%r10,8), %r10
	jmpq	*.LJTI50_1(,%rcx,8)
.LBB50_55:                              #   in Loop: Header=BB50_53 Depth=2
	movq	$1, 16(%r9)
	jmp	.LBB50_67
	.p2align	4
.LBB50_56:                              #   in Loop: Header=BB50_53 Depth=2
	cmpq	24(%r11), %r10
	jae	.LBB50_65
# %bb.57:                               #   in Loop: Header=BB50_53 Depth=2
	addq	$16, %r11
	cmpl	$3, %ecx
	je	.LBB50_62
# %bb.58:                               #   in Loop: Header=BB50_53 Depth=2
	movq	(%r11), %rcx
	leaq	(%r10,%r10,2), %r11
	leaq	(%rcx,%r11,8), %r11
	addq	$8, %r11
	jmp	.LBB50_62
.LBB50_59:                              #   in Loop: Header=BB50_53 Depth=2
	testq	%r10, %r10
	jne	.LBB50_65
# %bb.60:                               #   in Loop: Header=BB50_53 Depth=2
	cmpq	$0, 24(%r11)
	je	.LBB50_65
# %bb.61:                               #   in Loop: Header=BB50_53 Depth=2
	addq	$16, %r11
.LBB50_62:                              #   in Loop: Header=BB50_53 Depth=2
	movq	(%r11), %r11
	movq	16(%r15), %r14
	movq	32(%r15), %rcx
	movq	%r11, %rbx
	shrq	$3, %rbx
	movq	%r11, %r13
	shrq	$33, %r13
	xorq	%rbx, %r13
	movabsq	$-4658895280553007687, %rsi     # imm = 0xBF58476D1CE4E5B9
	imulq	%rsi, %r13
	movq	%r13, %r15
	shrq	$27, %r15
	xorq	%r13, %r15
	leaq	-1(,%rcx,2), %rbx
	andq	%rbx, %r15
	movq	(%r14,%r15,8), %r13
	movq	$-1, %rcx
	testq	%r13, %r13
	je	.LBB50_75
	.p2align	4
.LBB50_63:                              #   Parent Loop BB50_48 Depth=1
                                        #     Parent Loop BB50_53 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	leaq	(,%r13,4), %rsi
	addq	%r13, %rsi
	cmpq	%r11, -40(%rdx,%rsi,8)
	je	.LBB50_74
# %bb.64:                               #   in Loop: Header=BB50_63 Depth=3
	incq	%r15
	andq	%rbx, %r15
	movq	(%r14,%r15,8), %r13
	testq	%r13, %r13
	jne	.LBB50_63
	jmp	.LBB50_75
	.p2align	4
.LBB50_65:                              #   in Loop: Header=BB50_53 Depth=2
	movq	16(%r9), %rcx
	testq	%rcx, %rcx
	je	.LBB50_67
# %bb.66:                               #   in Loop: Header=BB50_53 Depth=2
	incq	%rcx
	movq	%rcx, 16(%r9)
.LBB50_67:                              #   in Loop: Header=BB50_53 Depth=2
	movq	24(%r9), %r10
	incq	%r10
	movq	%r10, 24(%r9)
	movq	(%r15), %rcx
	movq	5640(%rcx), %rcx
	movq	88(%rcx), %r14
	movq	96(%rcx), %r15
	movzbl	112(%rcx), %ecx
	movq	%r11, %rsi
	imulq	%rbx, %rsi
	shrxq	%rcx, %rsi, %r13
	.p2align	4
.LBB50_68:                              #   Parent Loop BB50_48 Depth=1
                                        #     Parent Loop BB50_53 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	andq	%r15, %r13
	movq	%r13, %rcx
	shlq	$4, %rcx
	movq	(%r14,%rcx), %rcx
	cmpq	%r11, %rcx
	je	.LBB50_71
# %bb.69:                               #   in Loop: Header=BB50_68 Depth=3
	testq	%rcx, %rcx
	je	.LBB50_50
# %bb.70:                               #   in Loop: Header=BB50_68 Depth=3
	incq	%r13
	jmp	.LBB50_68
	.p2align	4
.LBB50_71:                              #   in Loop: Header=BB50_53 Depth=2
	shlq	$4, %r13
	movq	8(%r14,%r13), %rcx
	testq	%rcx, %rcx
	je	.LBB50_50
# %bb.72:                               #   in Loop: Header=BB50_53 Depth=2
	movq	48(%rcx), %rcx
	cmpq	%r10, %rcx
	movq	-72(%rbp), %r15                 # 8-byte Reload
	jbe	.LBB50_51
# %bb.73:                               #   in Loop: Header=BB50_53 Depth=2
	movq	%rcx, 24(%r9)
	movq	%rcx, %r10
	jmp	.LBB50_51
.LBB50_74:                              #   in Loop: Header=BB50_53 Depth=2
	decq	%r13
	movq	%r13, %rcx
.LBB50_75:                              #   in Loop: Header=BB50_53 Depth=2
	leaq	(%rcx,%rcx,4), %r11
	movl	32(%rdx,%r11,8), %ebx
	testl	%ebx, %ebx
	movq	-72(%rbp), %r15                 # 8-byte Reload
	je	.LBB50_82
# %bb.76:                               #   in Loop: Header=BB50_53 Depth=2
	cmpl	$1, %ebx
	je	.LBB50_131
# %bb.77:                               #   in Loop: Header=BB50_53 Depth=2
	leaq	(%rdx,%r11,8), %rcx
	movq	16(%rcx), %r11
	cmpq	16(%r9), %r11
	jbe	.LBB50_79
# %bb.78:                               #   in Loop: Header=BB50_53 Depth=2
	movq	%r11, 16(%r9)
.LBB50_79:                              #   in Loop: Header=BB50_53 Depth=2
	movq	24(%rcx), %rcx
	cmpq	24(%r9), %rcx
	movabsq	$-7046029254386353131, %rbx     # imm = 0x9E3779B97F4A7C15
	jbe	.LBB50_81
# %bb.80:                               #   in Loop: Header=BB50_53 Depth=2
	movq	%rcx, 24(%r9)
.LBB50_81:                              #   in Loop: Header=BB50_53 Depth=2
	incq	%r10
	movq	%r10, 8(%r9)
	jmp	.LBB50_52
.LBB50_82:                              #   in Loop: Header=BB50_53 Depth=2
	movq	%rcx, (%rax,%r8,8)
	incq	%r8
	movabsq	$-7046029254386353131, %rbx     # imm = 0x9E3779B97F4A7C15
	jmp	.LBB50_52
.LBB50_41:
	movq	%rax, %rcx
	movq	%rdi, %rbx
	addq	$64, %rbx
	movl	$1, %eax
	jb	.LBB50_117
# %bb.42:
	addq	%r14, %rbx
	jb	.LBB50_117
# %bb.43:
	addq	%rcx, %rbx
	jb	.LBB50_117
# %bb.44:
	movq	%r8, -96(%rbp)                  # 8-byte Spill
	movq	%rdi, -80(%rbp)                 # 8-byte Spill
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%r15, %r13
	movq	%rsi, %r15
	movq	(%r13), %rdi
	movq	%rbx, %rsi
	callq	myl_rc_meta_alloc
	testq	%rax, %rax
	je	.LBB50_116
# %bb.45:
	xorl	%ecx, %ecx
	movl	-44(%rbp), %r10d                # 4-byte Reload
	testl	%r10d, %r10d
	movq	%r15, -64(%rbp)                 # 8-byte Spill
	cmovneq	%r15, %rcx
	movq	%rcx, 8(%rax)
	movq	24(%r13), %rsi
	movq	%rsi, 32(%rax)
	movq	-96(%rbp), %rcx                 # 8-byte Reload
	movq	%rcx, 40(%rax)
	movq	%rbx, 48(%rax)
	leaq	64(%rax), %rcx
	movq	%rcx, 16(%rax)
	movq	-80(%rbp), %rcx                 # 8-byte Reload
	leaq	(%rax,%rcx), %rdx
	addq	$64, %rdx
	addq	%rdx, %r14
	movq	%r14, 24(%rax)
	testq	%rsi, %rsi
	movq	%r13, %r15
	movq	%rax, %r14
	je	.LBB50_104
# %bb.46:
	xorl	%esi, %esi
	jmp	.LBB50_85
.LBB50_83:                              #   in Loop: Header=BB50_85 Depth=1
	movq	-88(%rbp), %rax                 # 8-byte Reload
	movq	%rdx, 24(%rax)
	leaq	(%r9,%r9,2), %rax
	leaq	(%rdx,%rax,8), %rdx
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-80(%rbp), %rsi                 # 8-byte Reload
.LBB50_84:                              #   in Loop: Header=BB50_85 Depth=1
	incq	%rsi
	cmpq	24(%r15), %rsi
	jae	.LBB50_104
.LBB50_85:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB50_91 Depth 2
                                        #     Child Loop BB50_100 Depth 2
                                        #       Child Loop BB50_102 Depth 3
	leaq	(,%rsi,8), %rax
	movq	16(%r14), %rcx
	movq	%rsi, %rdi
	shlq	$6, %rdi
	leaq	(%rcx,%rdi), %r13
	testl	%r10d, %r10d
	movq	8(%r15), %r8
	leaq	(%rax,%rax,4), %rax
	movq	(%r8,%rax), %r8
	movl	$0, %r9d
	cmovneq	%r8, %r9
	movq	%r9, (%rcx,%rdi)
	vmovups	(%r8), %ymm0
	vmovups	%ymm0, 8(%rcx,%rdi)
	movq	32(%r8), %r9
	movq	%r9, 40(%rcx,%rdi)
	movq	8(%r15), %r9
	vmovups	16(%r9,%rax), %xmm0
	cmpq	$0, 16(%r9,%rax)
	vmovups	%xmm0, 48(%rcx,%rdi)
	je	.LBB50_88
# %bb.86:                               #   in Loop: Header=BB50_85 Depth=1
	movl	8(%r8), %eax
	cmpl	$3, %eax
	jne	.LBB50_87
.LBB50_89:                              #   in Loop: Header=BB50_85 Depth=1
	cmpq	$0, 24(%r8)
	je	.LBB50_84
# %bb.90:                               #   in Loop: Header=BB50_85 Depth=1
	movq	16(%r8), %r10
	movq	16(%r15), %r11
	movq	32(%r15), %rax
	movq	%r10, %rcx
	shrq	$3, %rcx
	movq	%r10, %rdi
	shrq	$33, %rdi
	xorq	%rcx, %rdi
	movabsq	$-4658895280553007687, %rcx     # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %rdi
	movq	%rdi, %rbx
	shrq	$27, %rbx
	xorq	%rdi, %rbx
	leaq	-1(,%rax,2), %rax
	andq	%rax, %rbx
	movq	(%r11,%rbx,8), %rdi
	testq	%rdi, %rdi
	je	.LBB50_93
	.p2align	4
.LBB50_91:                              #   Parent Loop BB50_85 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	(%rdi,%rdi,4), %rcx
	cmpq	%r10, -40(%r9,%rcx,8)
	je	.LBB50_94
# %bb.92:                               #   in Loop: Header=BB50_91 Depth=2
	incq	%rbx
	andq	%rax, %rbx
	movq	(%r11,%rbx,8), %rdi
	testq	%rdi, %rdi
	jne	.LBB50_91
.LBB50_93:                              #   in Loop: Header=BB50_85 Depth=1
	xorl	%edi, %edi
.LBB50_94:                              #   in Loop: Header=BB50_85 Depth=1
	movq	16(%r14), %rax
	shlq	$6, %rdi
	addq	%rdi, %rax
	addq	$-56, %rax
	movq	%rax, 24(%r13)
	movl	8(%r8), %eax
	movl	-44(%rbp), %r10d                # 4-byte Reload
	cmpl	$4, %eax
	jne	.LBB50_95
	jmp	.LBB50_96
.LBB50_88:                              #   in Loop: Header=BB50_85 Depth=1
	movl	$0, 16(%r13)
	movl	8(%r8), %eax
	cmpl	$3, %eax
	je	.LBB50_89
.LBB50_87:                              #   in Loop: Header=BB50_85 Depth=1
	cmpl	$4, %eax
	je	.LBB50_96
.LBB50_95:                              #   in Loop: Header=BB50_85 Depth=1
	cmpl	$2, %eax
	jne	.LBB50_84
.LBB50_96:                              #   in Loop: Header=BB50_85 Depth=1
	movq	%r13, -88(%rbp)                 # 8-byte Spill
	movq	%rsi, -80(%rbp)                 # 8-byte Spill
	movq	24(%r8), %r9
	testq	%r9, %r9
	je	.LBB50_83
# %bb.97:                               #   in Loop: Header=BB50_85 Depth=1
	movq	16(%r8), %r8
	xorl	%r10d, %r10d
	jmp	.LBB50_100
	.p2align	4
.LBB50_98:                              #   in Loop: Header=BB50_100 Depth=2
	xorl	%eax, %eax
.LBB50_99:                              #   in Loop: Header=BB50_100 Depth=2
	addq	%rdx, %r11
	movq	%rsi, %r14
	movq	16(%rsi), %rcx
	shlq	$6, %rax
	addq	%rcx, %rax
	addq	$-56, %rax
	movq	%rax, 8(%r11)
	incq	%r10
	cmpq	%r9, %r10
	movq	-72(%rbp), %r15                 # 8-byte Reload
	je	.LBB50_83
.LBB50_100:                             #   Parent Loop BB50_85 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB50_102 Depth 3
	movq	%r14, %rsi
	leaq	(,%r10,8), %rax
	leaq	(%rax,%rax,2), %r11
	movq	16(%r8,%r11), %rax
	movq	%rax, 16(%rdx,%r11)
	vmovups	(%r8,%r11), %xmm0
	vmovups	%xmm0, (%rdx,%r11)
	movq	8(%r8,%r11), %rbx
	movq	16(%r15), %r14
	movq	32(%r15), %rax
	movq	%rbx, %rcx
	shrq	$3, %rcx
	movq	%rbx, %rdi
	shrq	$33, %rdi
	xorq	%rcx, %rdi
	movabsq	$-4658895280553007687, %rcx     # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %rdi
	movq	%r15, %rcx
	movq	%rdi, %r15
	shrq	$27, %r15
	xorq	%rdi, %r15
	leaq	-1(,%rax,2), %rdi
	andq	%rdi, %r15
	movq	(%r14,%r15,8), %rax
	testq	%rax, %rax
	je	.LBB50_98
# %bb.101:                              #   in Loop: Header=BB50_100 Depth=2
	movq	8(%rcx), %rcx
	.p2align	4
.LBB50_102:                             #   Parent Loop BB50_85 Depth=1
                                        #     Parent Loop BB50_100 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	leaq	(%rax,%rax,4), %r13
	cmpq	%rbx, -40(%rcx,%r13,8)
	je	.LBB50_99
# %bb.103:                              #   in Loop: Header=BB50_102 Depth=3
	incq	%r15
	andq	%rdi, %r15
	movq	(%r14,%r15,8), %rax
	testq	%rax, %rax
	jne	.LBB50_102
	jmp	.LBB50_98
.LBB50_104:
	movq	-96(%rbp), %r13                 # 8-byte Reload
	testq	%r13, %r13
	je	.LBB50_112
# %bb.105:
	movq	24(%r14), %rax
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	24(%rcx), %rsi
	xorl	%edx, %edx
	jmp	.LBB50_108
.LBB50_106:                             #   in Loop: Header=BB50_108 Depth=1
	xorl	%r11d, %r11d
.LBB50_107:                             #   in Loop: Header=BB50_108 Depth=1
	shlq	$6, %r11
	movq	16(%r14), %rcx
	movq	24(%r14), %rax
	addq	%r11, %rcx
	addq	$-56, %rcx
	movq	%rcx, 8(%rax,%rdi)
	incq	%rdx
	cmpq	%r13, %rdx
	je	.LBB50_112
.LBB50_108:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB50_110 Depth 2
	imulq	$200, %rdx, %rdi
	movq	%rdx, %rcx
	shlq	$6, %rcx
	vmovups	(%rsi,%rcx), %ymm0
	vmovups	32(%rsi,%rcx), %ymm1
	vmovups	%ymm1, 32(%rax,%rdi)
	vmovups	%ymm0, (%rax,%rdi)
	movq	-64(%rbp), %rax                 # 8-byte Reload
	movq	24(%rax), %rsi
	movq	8(%rsi,%rcx), %r8
	movq	16(%r15), %r9
	movq	32(%r15), %rax
	movq	%r8, %rcx
	shrq	$3, %rcx
	movq	%r8, %r11
	shrq	$33, %r11
	xorq	%rcx, %r11
	movabsq	$-4658895280553007687, %rcx     # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %r11
	movq	%r11, %r10
	shrq	$27, %r10
	xorq	%r11, %r10
	leaq	-1(,%rax,2), %rax
	andq	%rax, %r10
	movq	(%r9,%r10,8), %r11
	testq	%r11, %r11
	je	.LBB50_106
# %bb.109:                              #   in Loop: Header=BB50_108 Depth=1
	movq	8(%r15), %rcx
	.p2align	4
.LBB50_110:                             #   Parent Loop BB50_108 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	leaq	(%r11,%r11,4), %rbx
	cmpq	%r8, -40(%rcx,%rbx,8)
	je	.LBB50_107
# %bb.111:                              #   in Loop: Header=BB50_110 Depth=2
	incq	%r10
	andq	%rax, %r10
	movq	(%r9,%r10,8), %r11
	testq	%r11, %r11
	jne	.LBB50_110
	jmp	.LBB50_106
.LBB50_112:
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	movq	5640(%rdi), %rax
	cmpq	184(%rax), %r12
	jbe	.LBB50_118
# %bb.113:
	movl	$24, %ecx
	movq	%r12, %rax
	mulq	%rcx
	jo	.LBB50_115
# %bb.114:
	movq	%rax, %rsi
	vzeroupper
	callq	myl_rc_meta_alloc
	movl	-44(%rbp), %ecx                 # 4-byte Reload
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	movq	%rax, %rbx
	testq	%rax, %rax
	jne	.LBB50_119
.LBB50_115:
	movq	48(%r14), %rdx
	jmp	.LBB50_125
.LBB50_118:
	xorl	%ebx, %ebx
	movl	-44(%rbp), %ecx                 # 4-byte Reload
.LBB50_119:
	cmpl	$1, %ecx
	movl	$2, %eax
	sbbq	$0, %rax
	mulq	32(%r14)
	jo	.LBB50_124
# %bb.120:
	movl	%ecx, %esi
	leaq	-160(%rbp), %r8
	movq	%rax, %rdx
	movq	%r14, %rcx
	vzeroupper
	callq	index_prepare
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	testl	%eax, %eax
	je	.LBB50_124
# %bb.121:
	leaq	-160(%rbp), %rdx
	movq	%r14, %rsi
	callq	index_commit
	movq	-56(%rbp), %rdi                 # 8-byte Reload
	movq	5640(%rdi), %rax
	testq	%rbx, %rbx
	je	.LBB50_123
# %bb.122:
	movq	176(%rax), %rsi
	movq	184(%rax), %rax
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rdx
	movq	%r14, %r15
	movq	%rdi, %r14
	callq	myl_rc_meta_free
	movq	5640(%r14), %rax
	movq	%r15, %r14
	movq	%rbx, 176(%rax)
	movq	%r12, 184(%rax)
.LBB50_123:
	movq	40(%rax), %rcx
	movq	%rcx, (%r14)
	movq	%r14, 40(%rax)
	xorl	%eax, %eax
	jmp	.LBB50_117
.LBB50_124:
	shlq	$3, %r12
	leaq	(%r12,%r12,2), %rdx
	movq	%rbx, %rsi
	movq	%rdi, %rbx
	vzeroupper
	callq	myl_rc_meta_free
	movq	48(%r14), %rdx
	movq	%rbx, %rdi
.LBB50_125:
	movq	%r14, %rsi
	vzeroupper
	callq	myl_rc_meta_free
	jmp	.LBB50_116
.LBB50_126:
	xorl	%r12d, %r12d
.LBB50_127:
	movq	%rcx, %rbx
	movq	(%r15), %rcx
	movq	24(%rcx), %rdx
	movq	-88(%rbp), %r8                  # 8-byte Reload
	subq	%r8, %rdx
	jb	.LBB50_131
# %bb.128:
	movq	5640(%rcx), %rsi
	movq	48(%rsi), %rdi
	subq	%r8, %rdi
	jb	.LBB50_131
# %bb.129:
	movq	%rdx, 24(%rcx)
	movq	%rdi, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	%rbx, %rax
	shrq	$58, %rax
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movl	$1, %eax
	movq	-56(%rbp), %r9                  # 8-byte Reload
	movl	-44(%rbp), %r10d                # 4-byte Reload
	jne	.LBB50_117
# %bb.130:
	movq	%rbx, %rdi
	shlq	$6, %rdi
	jmp	.LBB50_39
.LBB50_131:
	callq	myl_rc_invariant_failed
.Lfunc_end50:
	.size	register_shapes, .Lfunc_end50-register_shapes
	.cfi_endproc
	.section	.rodata.register_shapes,"a",@progbits
	.p2align	3, 0x0
.LJTI50_0:
	.quad	.LBB50_3
	.quad	.LBB50_6
	.quad	.LBB50_10
	.quad	.LBB50_22
	.quad	.LBB50_10
	.quad	.LBB50_6
.LJTI50_1:
	.quad	.LBB50_65
	.quad	.LBB50_55
	.quad	.LBB50_56
	.quad	.LBB50_59
	.quad	.LBB50_56
	.quad	.LBB50_55
                                        # -- End function
	.section	.text.index_prepare,"ax",@progbits
	.p2align	4                               # -- Begin function index_prepare
	.type	index_prepare,@function
index_prepare:                          # @index_prepare
.Lfunc_begin51:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r8, %rbx
	movq	%rdx, -88(%rbp)                 # 8-byte Spill
	movq	%rsi, %rdx
	movq	%rdi, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 32(%r8)
	vmovups	%ymm0, (%r8)
	movq	5640(%rdi), %r15
	movq	40(%rcx), %rax
	xorl	%edi, %edi
	testq	%rax, %rax
	je	.LBB51_1
# %bb.4:
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	movq	%r14, -72(%rbp)                 # 8-byte Spill
	movq	168(%r15), %rdx
	addq	%rax, %rdx
	leaq	16(,%rdx,4), %rdx
	movq	160(%r15), %r13
	movq	24(%rcx), %rsi
	xorl	%r12d, %r12d
	xorl	%r8d, %r8d
	movq	%r13, %rcx
	jmp	.LBB51_5
.LBB51_8:                               #   in Loop: Header=BB51_5 Depth=1
	movq	152(%r15), %r11
	movq	%r10, %r14
	shlq	$4, %r14
	cmpq	$0, (%r11,%r14)
	je	.LBB51_9
	.p2align	4
.LBB51_10:                              #   in Loop: Header=BB51_5 Depth=1
	incq	%r8
	movq	%r8, %r12
	addq	$200, %rsi
	decq	%rax
	je	.LBB51_2
.LBB51_5:                               # =>This Inner Loop Header: Depth=1
	movq	(%rsi), %r9
	movl	52(%r9), %r9d
	testl	%r9d, %r9d
	setne	%r10b
	cmpl	%edi, %r9d
	seta	%r11b
	andb	%r10b, %r11b
	cmpb	$1, %r11b
	jne	.LBB51_10
# %bb.6:                                #   in Loop: Header=BB51_5 Depth=1
	movl	%r9d, %r10d
	cmpq	%r10, %rdx
	jbe	.LBB51_10
# %bb.7:                                #   in Loop: Header=BB51_5 Depth=1
	cmpq	%r10, %r13
	ja	.LBB51_8
.LBB51_11:                              #   in Loop: Header=BB51_5 Depth=1
	incq	%r10
	cmpq	%r10, %rcx
	cmovbeq	%r10, %rcx
	movl	%r9d, %edi
	addq	$200, %rsi
	decq	%rax
	jne	.LBB51_5
	jmp	.LBB51_2
.LBB51_9:                               #   in Loop: Header=BB51_5 Depth=1
	addq	%r14, %r11
	cmpq	$0, 8(%r11)
	jne	.LBB51_10
	jmp	.LBB51_11
.LBB51_2:
	cmpq	%r13, %rcx
	jne	.LBB51_13
# %bb.3:
	movq	-72(%rbp), %r14                 # 8-byte Reload
.LBB51_25:
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	jmp	.LBB51_26
.LBB51_1:
	xorl	%r12d, %r12d
.LBB51_26:
	addq	$56, %r15
	movq	%r14, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rcx
	vzeroupper
	callq	map_prepare
	testl	%eax, %eax
	je	.LBB51_29
# %bb.27:
	movq	5640(%r14), %rsi
	addq	$88, %rsi
	leaq	16(%rbx), %rcx
	movq	%r14, %rdi
	movq	-88(%rbp), %rdx                 # 8-byte Reload
	callq	map_prepare
	testl	%eax, %eax
	je	.LBB51_29
# %bb.28:
	movq	5640(%r14), %rsi
	addq	$120, %rsi
	leaq	32(%rbx), %rcx
	movq	%r14, %rdi
	movq	%r12, %rdx
	callq	map_prepare
	movl	%eax, %ecx
	movl	$1, %eax
	testl	%ecx, %ecx
	jne	.LBB51_46
	jmp	.LBB51_29
.LBB51_13:
	leaq	(,%r13,2), %rdx
	cmpq	%rdx, %rcx
	cmovaq	%rcx, %rdx
	movq	%rdx, %rax
	shrq	$60, %rax
	movq	-72(%rbp), %r14                 # 8-byte Reload
	jne	.LBB51_29
# %bb.14:
	testq	%r14, %r14
	je	.LBB51_47
# %bb.15:
	testq	%rdx, %rdx
	je	.LBB51_47
# %bb.16:
	testq	%r15, %r15
	je	.LBB51_47
# %bb.17:
	movq	%rdx, %rcx
	shlq	$4, %rcx
	movq	24(%r14), %rsi
	addq	%rcx, %rsi
	jb	.LBB51_20
# %bb.18:
	movq	88(%r14), %rax
	testq	%rax, %rax
	je	.LBB51_21
# %bb.19:
	cmpq	%rax, %rsi
	jbe	.LBB51_21
.LBB51_20:
	movl	$1, 108(%r14)
.LBB51_29:
	movq	(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB51_33
# %bb.30:
	movq	8(%rbx), %rax
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r14), %rcx
	subq	%rax, %rcx
	jb	.LBB51_47
# %bb.31:
	movq	5640(%r14), %rdx
	movq	48(%rdx), %rsi
	subq	%rax, %rsi
	jb	.LBB51_47
# %bb.32:
	movq	%rcx, 24(%r14)
	movq	%rsi, 48(%rdx)
	vzeroupper
	callq	free@PLT
.LBB51_33:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rbx)
	movq	16(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB51_37
# %bb.34:
	movq	24(%rbx), %rax
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r14), %rcx
	subq	%rax, %rcx
	jb	.LBB51_47
# %bb.35:
	movq	5640(%r14), %rdx
	movq	48(%rdx), %rsi
	subq	%rax, %rsi
	jb	.LBB51_47
# %bb.36:
	movq	%rcx, 24(%r14)
	movq	%rsi, 48(%rdx)
	vzeroupper
	callq	free@PLT
	vxorps	%xmm0, %xmm0, %xmm0
.LBB51_37:
	leaq	16(%rbx), %rax
	vmovups	%xmm0, (%rax)
	movq	32(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB51_41
# %bb.38:
	movq	40(%rbx), %rax
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r14), %rcx
	subq	%rax, %rcx
	jb	.LBB51_47
# %bb.39:
	movq	5640(%r14), %rdx
	movq	48(%rdx), %rsi
	subq	%rax, %rsi
	jb	.LBB51_47
# %bb.40:
	movq	%rcx, 24(%r14)
	movq	%rsi, 48(%rdx)
	vzeroupper
	callq	free@PLT
.LBB51_41:
	leaq	32(%rbx), %rax
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rax)
	movq	48(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB51_45
# %bb.42:
	movq	56(%rbx), %rcx
	shlq	$4, %rcx
	movq	24(%r14), %rax
	subq	%rcx, %rax
	jb	.LBB51_47
# %bb.43:
	movq	5640(%r14), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB51_47
# %bb.44:
	movq	%rax, 24(%r14)
	movq	%rsi, 48(%rdx)
	vzeroupper
	callq	free@PLT
.LBB51_45:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 32(%rbx)
	vmovups	%ymm0, (%rbx)
	xorl	%eax, %eax
.LBB51_46:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB51_21:
	.cfi_def_cfa %rbp, 16
	movq	%rsi, -48(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%rcx, %rsi
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	movq	%rdx, -56(%rbp)                 # 8-byte Spill
	vzeroupper
	callq	calloc@PLT
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	testq	%rax, %rax
	je	.LBB51_29
# %bb.22:
	movq	%rax, %rdx
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	%rax, 24(%r14)
	movq	-80(%rbp), %rax                 # 8-byte Reload
	addq	%rax, 48(%r15)
	testq	%r13, %r13
	je	.LBB51_24
# %bb.23:
	movq	152(%r15), %rsi
	shlq	$4, %r13
	movq	%rdx, -48(%rbp)                 # 8-byte Spill
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	movq	%r13, %rdx
	callq	memcpy@PLT
	movq	-48(%rbp), %rdx                 # 8-byte Reload
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB51_24:
	movq	%rdx, 48(%rbx)
	movq	%rcx, 56(%rbx)
	jmp	.LBB51_25
.LBB51_47:
	vzeroupper
	callq	myl_rc_invariant_failed
.Lfunc_end51:
	.size	index_prepare, .Lfunc_end51-index_prepare
	.cfi_endproc
                                        # -- End function
	.section	.text.index_commit,"ax",@progbits
	.p2align	4                               # -- Begin function index_commit
	.type	index_commit,@function
index_commit:                           # @index_commit
.Lfunc_begin52:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdx, %r15
	movq	%rsi, %rbx
	movq	%rdi, %r12
	movq	5640(%rdi), %r13
	cmpq	$0, (%rdx)
	je	.LBB52_12
# %bb.1:
	movq	56(%r13), %rdi
	movq	72(%r13), %r14
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB52_7
# %bb.2:
	movq	64(%r13), %rax
	cmpq	$-1, %rax
	je	.LBB52_7
# %bb.3:
	testq	%rdi, %rdi
	je	.LBB52_7
# %bb.4:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r12), %rcx
	subq	%rax, %rcx
	jb	.LBB52_94
# %bb.5:
	movq	48(%r13), %rdx
	subq	%rax, %rdx
	jb	.LBB52_94
# %bb.6:
	movq	%rcx, 24(%r12)
	movq	%rdx, 48(%r13)
	callq	free@PLT
.LBB52_7:
	movq	$myl_rc_map_sentinel, 56(%r13)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 64(%r13)
	movl	$0, 84(%r13)
	movq	(%r15), %rax
	movq	8(%r15), %rcx
	leaq	1(%rcx), %rdx
	movl	$63, %edi
	cmpq	$2, %rdx
	jb	.LBB52_11
# %bb.8:
	movl	$64, %esi
	movq	%rdx, %rdi
	.p2align	4
.LBB52_9:                               # =>This Inner Loop Header: Depth=1
	shrq	%rdi
	decl	%esi
	cmpq	$3, %rdx
	movq	%rdi, %rdx
	ja	.LBB52_9
# %bb.10:
	cmpl	$63, %esi
	movl	$63, %edi
	cmovbl	%esi, %edi
.LBB52_11:
	movq	%rax, 56(%r13)
	movq	%rcx, 64(%r13)
	movq	%r14, 72(%r13)
	movl	%edi, 80(%r13)
	movl	$0, 84(%r13)
	vmovups	%xmm0, (%r15)
	movq	5640(%r12), %r13
.LBB52_12:
	cmpq	$0, 16(%r15)
	je	.LBB52_24
# %bb.13:
	movq	88(%r13), %rdi
	movq	104(%r13), %r14
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB52_19
# %bb.14:
	movq	96(%r13), %rax
	cmpq	$-1, %rax
	je	.LBB52_19
# %bb.15:
	testq	%rdi, %rdi
	je	.LBB52_19
# %bb.16:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r12), %rcx
	subq	%rax, %rcx
	jb	.LBB52_94
# %bb.17:
	movq	48(%r13), %rdx
	subq	%rax, %rdx
	jb	.LBB52_94
# %bb.18:
	movq	%rcx, 24(%r12)
	movq	%rdx, 48(%r13)
	callq	free@PLT
.LBB52_19:
	leaq	16(%r15), %rax
	movq	$myl_rc_map_sentinel, 88(%r13)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 96(%r13)
	movl	$0, 116(%r13)
	movq	16(%r15), %rcx
	movq	24(%r15), %rdx
	leaq	1(%rdx), %rsi
	movl	$63, %r8d
	cmpq	$2, %rsi
	jb	.LBB52_23
# %bb.20:
	movl	$64, %edi
	movq	%rsi, %r8
	.p2align	4
.LBB52_21:                              # =>This Inner Loop Header: Depth=1
	shrq	%r8
	decl	%edi
	cmpq	$3, %rsi
	movq	%r8, %rsi
	ja	.LBB52_21
# %bb.22:
	cmpl	$63, %edi
	movl	$63, %r8d
	cmovbl	%edi, %r8d
.LBB52_23:
	movq	%rcx, 88(%r13)
	movq	%rdx, 96(%r13)
	movq	%r14, 104(%r13)
	movl	%r8d, 112(%r13)
	movl	$0, 116(%r13)
	vmovups	%xmm0, (%rax)
	movq	5640(%r12), %r13
.LBB52_24:
	cmpq	$0, 32(%r15)
	je	.LBB52_36
# %bb.25:
	movq	120(%r13), %rdi
	movq	136(%r13), %r14
	cmpq	$myl_rc_map_sentinel, %rdi
	je	.LBB52_31
# %bb.26:
	movq	128(%r13), %rax
	cmpq	$-1, %rax
	je	.LBB52_31
# %bb.27:
	testq	%rdi, %rdi
	je	.LBB52_31
# %bb.28:
	shlq	$4, %rax
	addq	$16, %rax
	movq	24(%r12), %rcx
	subq	%rax, %rcx
	jb	.LBB52_94
# %bb.29:
	movq	48(%r13), %rdx
	subq	%rax, %rdx
	jb	.LBB52_94
# %bb.30:
	movq	%rcx, 24(%r12)
	movq	%rdx, 48(%r13)
	callq	free@PLT
.LBB52_31:
	leaq	32(%r15), %rax
	movq	$myl_rc_map_sentinel, 120(%r13)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 128(%r13)
	movl	$0, 148(%r13)
	movq	32(%r15), %rcx
	movq	40(%r15), %rdx
	leaq	1(%rdx), %rsi
	movl	$63, %r8d
	cmpq	$2, %rsi
	jb	.LBB52_35
# %bb.32:
	movl	$64, %edi
	movq	%rsi, %r8
	.p2align	4
.LBB52_33:                              # =>This Inner Loop Header: Depth=1
	shrq	%r8
	decl	%edi
	cmpq	$3, %rsi
	movq	%r8, %rsi
	ja	.LBB52_33
# %bb.34:
	cmpl	$63, %edi
	movl	$63, %r8d
	cmovbl	%edi, %r8d
.LBB52_35:
	movq	%rcx, 120(%r13)
	movq	%rdx, 128(%r13)
	movq	%r14, 136(%r13)
	movl	%r8d, 144(%r13)
	movl	$0, 148(%r13)
	vmovups	%xmm0, (%rax)
	movq	5640(%r12), %r13
.LBB52_36:
	movq	48(%r15), %rax
	testq	%rax, %rax
	je	.LBB52_42
# %bb.37:
	movq	152(%r13), %rdi
	testq	%rdi, %rdi
	je	.LBB52_41
# %bb.38:
	movq	160(%r13), %rcx
	shlq	$4, %rcx
	movq	24(%r12), %rax
	subq	%rcx, %rax
	jb	.LBB52_94
# %bb.39:
	movq	48(%r13), %rdx
	subq	%rcx, %rdx
	jb	.LBB52_94
# %bb.40:
	movq	%rax, 24(%r12)
	movq	%rdx, 48(%r13)
	callq	free@PLT
	movq	48(%r15), %rax
.LBB52_41:
	movq	%rax, 152(%r13)
	movq	56(%r15), %rax
	movq	%rax, 160(%r13)
	movq	$0, 48(%r15)
.LBB52_42:
	movq	8(%rbx), %rax
	testq	%rax, %rax
	je	.LBB52_51
# %bb.43:
	movq	5640(%r12), %rcx
	movq	56(%rcx), %rdx
	cmpq	$myl_rc_map_sentinel, %rdx
	je	.LBB52_94
# %bb.44:
	movq	64(%rcx), %rdi
	cmpq	$-1, %rdi
	je	.LBB52_94
# %bb.45:
	movq	72(%rcx), %rsi
	leaq	1(%rdi), %r8
	shrq	%r8
	cmpq	%r8, %rsi
	ja	.LBB52_94
# %bb.46:
	movzbl	80(%rcx), %r8d
	movq	%rax, %r9
	movabsq	$-7046029254386353131, %r10     # imm = 0x9E3779B97F4A7C15
	imulq	%r10, %r9
	shrxq	%r8, %r9, %r9
	.p2align	4
.LBB52_47:                              # =>This Inner Loop Header: Depth=1
	andq	%rdi, %r9
	movq	%r9, %r8
	shlq	$4, %r8
	movq	(%rdx,%r8), %r10
	testq	%r10, %r10
	je	.LBB52_49
# %bb.48:                               #   in Loop: Header=BB52_47 Depth=1
	incq	%r9
	cmpq	%rax, %r10
	jne	.LBB52_47
.LBB52_49:
	testq	%r10, %r10
	je	.LBB52_50
.LBB52_51:
	movq	32(%rbx), %rax
	testq	%rax, %rax
	je	.LBB52_55
.LBB52_52:
	xorl	%ecx, %ecx
	jmp	.LBB52_53
	.p2align	4
.LBB52_81:                              #   in Loop: Header=BB52_53 Depth=1
	incq	%rcx
	cmpq	%rax, %rcx
	je	.LBB52_55
.LBB52_53:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB52_68 Depth 2
                                        #     Child Loop BB52_77 Depth 2
	movq	56(%rbx), %rdx
	testq	%rdx, %rdx
	je	.LBB52_63
# %bb.54:                               #   in Loop: Header=BB52_53 Depth=1
	movq	8(%rdx), %rdx
	movq	(%rdx,%rcx,8), %rsi
	movq	5640(%r12), %rdi
	movq	88(%rdi), %r8
	cmpq	$myl_rc_map_sentinel, %r8
	jne	.LBB52_65
	jmp	.LBB52_94
	.p2align	4
.LBB52_63:                              #   in Loop: Header=BB52_53 Depth=1
	movq	%rcx, %rsi
	shlq	$6, %rsi
	addq	16(%rbx), %rsi
	movq	5640(%r12), %rdi
	movq	88(%rdi), %r8
	cmpq	$myl_rc_map_sentinel, %r8
	je	.LBB52_94
.LBB52_65:                              #   in Loop: Header=BB52_53 Depth=1
	movq	96(%rdi), %r10
	cmpq	$-1, %r10
	je	.LBB52_94
# %bb.66:                               #   in Loop: Header=BB52_53 Depth=1
	movq	104(%rdi), %r9
	leaq	1(%r10), %rdx
	shrq	%rdx
	cmpq	%rdx, %r9
	ja	.LBB52_94
# %bb.67:                               #   in Loop: Header=BB52_53 Depth=1
	leaq	8(%rsi), %rdx
	movzbl	112(%rdi), %r11d
	movq	%rdx, %r14
	movabsq	$-7046029254386353131, %r15     # imm = 0x9E3779B97F4A7C15
	imulq	%r15, %r14
	shrxq	%r11, %r14, %r14
	.p2align	4
.LBB52_68:                              #   Parent Loop BB52_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%r10, %r14
	movq	%r14, %r11
	shlq	$4, %r11
	movq	(%r8,%r11), %r15
	testq	%r15, %r15
	je	.LBB52_70
# %bb.69:                               #   in Loop: Header=BB52_68 Depth=2
	incq	%r14
	cmpq	%rdx, %r15
	jne	.LBB52_68
.LBB52_70:                              #   in Loop: Header=BB52_53 Depth=1
	testq	%r15, %r15
	je	.LBB52_71
# %bb.72:                               #   in Loop: Header=BB52_53 Depth=1
	movq	(%rsi), %rsi
	testq	%rsi, %rsi
	jne	.LBB52_73
	jmp	.LBB52_81
	.p2align	4
.LBB52_71:                              #   in Loop: Header=BB52_53 Depth=1
	addq	%r11, %r8
	movq	%rdx, (%r8)
	movq	%rdx, 8(%r8)
	incq	%r9
	movq	%r9, 104(%rdi)
	movq	(%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB52_81
.LBB52_73:                              #   in Loop: Header=BB52_53 Depth=1
	movq	5640(%r12), %rdi
	movq	88(%rdi), %r8
	cmpq	$myl_rc_map_sentinel, %r8
	je	.LBB52_94
# %bb.74:                               #   in Loop: Header=BB52_53 Depth=1
	movq	96(%rdi), %r10
	cmpq	$-1, %r10
	je	.LBB52_94
# %bb.75:                               #   in Loop: Header=BB52_53 Depth=1
	movq	104(%rdi), %r9
	leaq	1(%r10), %r11
	shrq	%r11
	cmpq	%r11, %r9
	ja	.LBB52_94
# %bb.76:                               #   in Loop: Header=BB52_53 Depth=1
	movzbl	112(%rdi), %r11d
	movq	%rsi, %r14
	movabsq	$-7046029254386353131, %r15     # imm = 0x9E3779B97F4A7C15
	imulq	%r15, %r14
	shrxq	%r11, %r14, %r14
	.p2align	4
.LBB52_77:                              #   Parent Loop BB52_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%r10, %r14
	movq	%r14, %r11
	shlq	$4, %r11
	movq	(%r8,%r11), %r15
	testq	%r15, %r15
	je	.LBB52_79
# %bb.78:                               #   in Loop: Header=BB52_77 Depth=2
	incq	%r14
	cmpq	%rsi, %r15
	jne	.LBB52_77
.LBB52_79:                              #   in Loop: Header=BB52_53 Depth=1
	testq	%r15, %r15
	jne	.LBB52_81
# %bb.80:                               #   in Loop: Header=BB52_53 Depth=1
	addq	%r11, %r8
	movq	%rsi, (%r8)
	movq	%rdx, 8(%r8)
	incq	%r9
	movq	%r9, 104(%rdi)
	jmp	.LBB52_81
.LBB52_50:
	addq	%r8, %rdx
	movq	%rax, (%rdx)
	movq	%rbx, 8(%rdx)
	incq	%rsi
	movq	%rsi, 72(%rcx)
	movq	32(%rbx), %rax
	testq	%rax, %rax
	jne	.LBB52_52
.LBB52_55:
	movq	%r13, -48(%rbp)                 # 8-byte Spill
	movq	%r12, -64(%rbp)                 # 8-byte Spill
	movq	40(%rbx), %rax
	testq	%rax, %rax
	je	.LBB52_93
# %bb.56:
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	addq	168(%rcx), %rax
	leaq	16(,%rax,4), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	xorl	%r13d, %r13d
	xorl	%r12d, %r12d
	jmp	.LBB52_57
.LBB52_62:                              #   in Loop: Header=BB52_57 Depth=1
	shlq	$4, %rcx
	movq	56(%rbx), %rsi
	testq	%rsi, %rsi
	cmoveq	%rsi, %r14
	movq	%r14, (%rdx,%rcx)
	movq	%r15, 8(%rdx,%rcx)
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	incq	168(%rcx)
	movl	%eax, %r13d
	.p2align	4
.LBB52_92:                              #   in Loop: Header=BB52_57 Depth=1
	incq	%r12
	cmpq	40(%rbx), %r12
	jae	.LBB52_93
.LBB52_57:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB52_88 Depth 2
	movq	24(%rbx), %rax
	imulq	$200, %r12, %rcx
	leaq	(%rax,%rcx), %r15
	movq	(%rax,%rcx), %r14
	movl	52(%r14), %eax
	testl	%eax, %eax
	setne	%cl
	cmpl	%r13d, %eax
	seta	%dl
	andb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB52_82
# %bb.58:                               #   in Loop: Header=BB52_57 Depth=1
	movl	%eax, %ecx
	cmpq	%rcx, -56(%rbp)                 # 8-byte Folded Reload
	jbe	.LBB52_82
# %bb.59:                               #   in Loop: Header=BB52_57 Depth=1
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	152(%rsi), %rdx
	cmpq	%rcx, 160(%rsi)
	jbe	.LBB52_62
# %bb.60:                               #   in Loop: Header=BB52_57 Depth=1
	movq	%rcx, %rsi
	shlq	$4, %rsi
	cmpq	$0, (%rdx,%rsi)
	jne	.LBB52_82
# %bb.61:                               #   in Loop: Header=BB52_57 Depth=1
	addq	%rdx, %rsi
	cmpq	$0, 8(%rsi)
	je	.LBB52_62
	.p2align	4
.LBB52_82:                              #   in Loop: Header=BB52_57 Depth=1
	cmpq	$0, 56(%rbx)
	jne	.LBB52_84
# %bb.83:                               #   in Loop: Header=BB52_57 Depth=1
	movq	%r15, %rdi
	callq	flat_build
.LBB52_84:                              #   in Loop: Header=BB52_57 Depth=1
	movq	-64(%rbp), %rax                 # 8-byte Reload
	movq	5640(%rax), %rax
	movq	120(%rax), %rcx
	cmpq	$myl_rc_map_sentinel, %rcx
	je	.LBB52_94
# %bb.85:                               #   in Loop: Header=BB52_57 Depth=1
	movq	128(%rax), %rsi
	cmpq	$-1, %rsi
	je	.LBB52_94
# %bb.86:                               #   in Loop: Header=BB52_57 Depth=1
	movq	136(%rax), %rdx
	leaq	1(%rsi), %rdi
	shrq	%rdi
	cmpq	%rdi, %rdx
	ja	.LBB52_94
# %bb.87:                               #   in Loop: Header=BB52_57 Depth=1
	movzbl	144(%rax), %edi
	movq	%r14, %r8
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%r9, %r8
	shrxq	%rdi, %r8, %rdi
	.p2align	4
.LBB52_88:                              #   Parent Loop BB52_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%rsi, %rdi
	movq	%rdi, %r8
	shlq	$4, %r8
	movq	(%rcx,%r8), %r9
	testq	%r9, %r9
	je	.LBB52_90
# %bb.89:                               #   in Loop: Header=BB52_88 Depth=2
	incq	%rdi
	cmpq	%r14, %r9
	jne	.LBB52_88
.LBB52_90:                              #   in Loop: Header=BB52_57 Depth=1
	testq	%r9, %r9
	jne	.LBB52_92
# %bb.91:                               #   in Loop: Header=BB52_57 Depth=1
	addq	%r8, %rcx
	movq	%r14, (%rcx)
	movq	%r15, 8(%rcx)
	incq	%rdx
	movq	%rdx, 136(%rax)
	jmp	.LBB52_92
.LBB52_93:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB52_94:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end52:
	.size	index_commit, .Lfunc_end52-index_commit
	.cfi_endproc
                                        # -- End function
	.section	.text.map_prepare,"ax",@progbits
	.p2align	4                               # -- Begin function map_prepare
	.type	map_prepare,@function
map_prepare:                            # @map_prepare
.Lfunc_begin53:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rcx)
	movq	(%rsi), %r14
	xorl	%eax, %eax
	cmpq	$myl_rc_map_sentinel, %r14
	je	.LBB53_1
# %bb.2:
	movq	8(%rsi), %r8
	incq	%r8
	addq	16(%rsi), %rdx
	jae	.LBB53_4
	jmp	.LBB53_27
.LBB53_1:
	xorl	%r8d, %r8d
	addq	16(%rsi), %rdx
	jb	.LBB53_27
.LBB53_4:
	movq	%r8, %r9
	shrq	%r9
	cmpq	%r9, %rdx
	jbe	.LBB53_26
# %bb.5:
	testq	%r8, %r8
	movl	$32, %r15d
	cmovneq	%r8, %r15
	movq	%r15, %r8
	shrq	%r8
	cmpq	%r8, %rdx
	jbe	.LBB53_9
# %bb.6:
	movq	%r15, %r8
	.p2align	4
.LBB53_7:                               # =>This Inner Loop Header: Depth=1
	cmpq	$2147483647, %r8                # imm = 0x7FFFFFFF
	ja	.LBB53_27
# %bb.8:                                #   in Loop: Header=BB53_7 Depth=1
	leaq	(%r8,%r8), %r15
	cmpq	%r8, %rdx
	movq	%r15, %r8
	ja	.LBB53_7
	jmp	.LBB53_10
.LBB53_9:
	movq	%r15, %rdx
	shrq	$60, %rdx
	jne	.LBB53_27
.LBB53_10:
	testq	%rdi, %rdi
	je	.LBB53_34
# %bb.11:
	testq	%r15, %r15
	je	.LBB53_34
# %bb.12:
	movq	5640(%rdi), %r12
	testq	%r12, %r12
	je	.LBB53_34
# %bb.13:
	movq	%r15, %rbx
	shlq	$4, %rbx
	movq	24(%rdi), %r13
	addq	%rbx, %r13
	jb	.LBB53_16
# %bb.14:
	movq	88(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB53_17
# %bb.15:
	cmpq	%rdx, %r13
	jbe	.LBB53_17
.LBB53_16:
	movl	$1, 108(%rdi)
	jmp	.LBB53_27
.LBB53_17:
	movq	%rdi, -48(%rbp)                 # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%rbx, %rsi
	callq	calloc@PLT
	movq	%rax, %rcx
	xorl	%eax, %eax
	testq	%rcx, %rcx
	je	.LBB53_27
# %bb.18:
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	%r13, 24(%rax)
	addq	%rbx, 48(%r12)
	movl	$63, %edx
	cmpq	$2, %r15
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	jb	.LBB53_22
# %bb.19:
	movl	$64, %edi
	movq	%r15, %r8
	movq	%r15, %rdx
	.p2align	4
.LBB53_20:                              # =>This Inner Loop Header: Depth=1
	shrq	%rdx
	decl	%edi
	cmpq	$3, %r8
	movq	%rdx, %r8
	ja	.LBB53_20
# %bb.21:
	cmpl	$63, %edi
	movl	$63, %edx
	cmovbl	%edi, %edx
.LBB53_22:
	decq	%r15
	cmpq	$myl_rc_map_sentinel, %r14
	je	.LBB53_25
# %bb.23:
	movq	8(%rsi), %rsi
	incq	%rsi
	xorl	%edi, %edi
	movabsq	$-7046029254386353131, %r8      # imm = 0x9E3779B97F4A7C15
	jmp	.LBB53_24
	.p2align	4
.LBB53_32:                              #   in Loop: Header=BB53_24 Depth=1
	addq	%rcx, %rbx
	vmovups	(%r9), %xmm0
	vmovups	%xmm0, (%rbx)
.LBB53_33:                              #   in Loop: Header=BB53_24 Depth=1
	incq	%rdi
.LBB53_24:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB53_30 Depth 2
	cmpq	%rsi, %rdi
	je	.LBB53_25
# %bb.28:                               #   in Loop: Header=BB53_24 Depth=1
	movq	%rdi, %r9
	shlq	$4, %r9
	movq	(%r14,%r9), %r10
	testq	%r10, %r10
	je	.LBB53_33
# %bb.29:                               #   in Loop: Header=BB53_24 Depth=1
	addq	%r14, %r9
	movq	%r10, %r11
	imulq	%r8, %r11
	shrxq	%rdx, %r11, %r11
	.p2align	4
.LBB53_30:                              #   Parent Loop BB53_24 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%r15, %r11
	movq	%r11, %rbx
	shlq	$4, %rbx
	movq	(%rcx,%rbx), %r12
	testq	%r12, %r12
	je	.LBB53_32
# %bb.31:                               #   in Loop: Header=BB53_30 Depth=2
	incq	%r11
	cmpq	%r10, %r12
	jne	.LBB53_30
	jmp	.LBB53_32
.LBB53_25:
	movq	%rcx, (%rax)
	movq	%r15, 8(%rax)
.LBB53_26:
	movl	$1, %eax
.LBB53_27:
                                        # kill: def $eax killed $eax killed $rax
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB53_34:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end53:
	.size	map_prepare, .Lfunc_end53-map_prepare
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_edges_release,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_edges_release
	.type	myl_rc_edges_release,@function
myl_rc_edges_release:                   # @myl_rc_edges_release
.Lfunc_begin54:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB54_89
# %bb.1:
	movq	%rdi, %r10
	movq	5640(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB54_89
# %bb.2:
	cmpq	$0, 192(%rdi)
	jne	.LBB54_89
# %bb.3:
	movq	%rdx, %r14
	movq	88(%rdi), %rax
	movq	96(%rdi), %rdx
	movzbl	112(%rdi), %r8d
	movabsq	$-7046029254386353131, %rdi     # imm = 0x9E3779B97F4A7C15
	imulq	%rsi, %rdi
	shrxq	%r8, %rdi, %r8
	.p2align	4
.LBB54_4:                               # =>This Inner Loop Header: Depth=1
	andq	%rdx, %r8
	movq	%r8, %rdi
	shlq	$4, %rdi
	movq	(%rax,%rdi), %rdi
	cmpq	%rsi, %rdi
	je	.LBB54_7
# %bb.5:                                #   in Loop: Header=BB54_4 Depth=1
	testq	%rdi, %rdi
	je	.LBB54_89
# %bb.6:                                #   in Loop: Header=BB54_4 Depth=1
	incq	%r8
	jmp	.LBB54_4
.LBB54_7:
	shlq	$4, %r8
	movq	8(%rax,%r8), %r11
	testq	%r11, %r11
	je	.LBB54_89
# %bb.8:
	movq	%rcx, %rax
	mulq	(%r11)
	jo	.LBB54_89
# %bb.9:
	testq	%r14, %r14
	jne	.LBB54_11
# %bb.10:
	testq	%rax, %rax
	jne	.LBB54_89
.LBB54_11:
	movl	8(%r11), %eax
	testl	%eax, %eax
	je	.LBB54_88
# %bb.12:
	cmpl	$1, %eax
	movq	%r10, -80(%rbp)                 # 8-byte Spill
	jne	.LBB54_15
# %bb.13:
	testq	%rcx, %rcx
	je	.LBB54_88
# %bb.14:
	movabsq	$4611686018427387906, %rbx      # imm = 0x4000000000000002
	xorl	%r15d, %r15d
	leaq	1(%rbx), %r12
	jmp	.LBB54_71
.LBB54_15:
	testq	%rcx, %rcx
	je	.LBB54_88
# %bb.16:
	movq	40(%r11), %rax
	movq	%rax, -104(%rbp)                # 8-byte Spill
	xorl	%r15d, %r15d
	jmp	.LBB54_20
	.p2align	4
.LBB54_17:                              #   in Loop: Header=BB54_20 Depth=1
	movq	176(%rax), %rdx
	leaq	1(%rcx), %rsi
	movq	%rsi, 192(%rax)
	leaq	(%rcx,%rcx,2), %rax
	movq	%r11, (%rdx,%rax,8)
	movq	%r14, 8(%rdx,%rax,8)
	movq	$0, 16(%rdx,%rax,8)
.LBB54_18:                              #   in Loop: Header=BB54_20 Depth=1
	movq	%r10, %rdi
	movl	$1, %esi
	movq	%r11, %r12
	callq	walk
	movq	%r12, %r11
	movq	-80(%rbp), %r10                 # 8-byte Reload
	movq	%rbx, %rcx
.LBB54_19:                              #   in Loop: Header=BB54_20 Depth=1
	addq	(%r11), %r14
	incq	%r15
	cmpq	%rcx, %r15
	je	.LBB54_88
.LBB54_20:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB54_34 Depth 2
                                        #       Child Loop BB54_38 Depth 3
	movl	8(%r11), %r8d
	cmpq	$2, -104(%rbp)                  # 8-byte Folded Reload
	jbe	.LBB54_23
# %bb.21:                               #   in Loop: Header=BB54_20 Depth=1
	movq	%rcx, %rbx
	testl	%r8d, %r8d
	je	.LBB54_18
# %bb.22:                               #   in Loop: Header=BB54_20 Depth=1
	movq	5640(%r10), %rax
	movq	192(%rax), %rcx
	cmpq	184(%rax), %rcx
	jb	.LBB54_17
	jmp	.LBB54_89
	.p2align	4
.LBB54_23:                              #   in Loop: Header=BB54_20 Depth=1
	leal	-1(%r8), %eax
	cmpl	$4, %eax
	ja	.LBB54_29
# %bb.24:                               #   in Loop: Header=BB54_20 Depth=1
	jmpq	*.LJTI54_0(,%rax,8)
.LBB54_25:                              #   in Loop: Header=BB54_20 Depth=1
	movl	$1, %edi
	jmp	.LBB54_30
.LBB54_26:                              #   in Loop: Header=BB54_20 Depth=1
	movq	16(%r11), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	movq	24(%r11), %rdi
	movq	32(%r11), %r13
	addq	%r14, %r13
	movl	$4, %r8d
	movq	$0, -72(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB54_33
.LBB54_27:                              #   in Loop: Header=BB54_20 Depth=1
	movq	16(%r11), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	movq	24(%r11), %rdi
	movl	$2, %r8d
	movq	$0, -72(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB54_32
.LBB54_28:                              #   in Loop: Header=BB54_20 Depth=1
	movq	16(%r11), %rax
	movq	24(%r11), %rdi
	movq	32(%r11), %rdx
	movq	%rdx, -72(%rbp)                 # 8-byte Spill
	movl	8(%rax), %r8d
	jmp	.LBB54_31
.LBB54_29:                              #   in Loop: Header=BB54_20 Depth=1
	xorl	%edi, %edi
.LBB54_30:                              #   in Loop: Header=BB54_20 Depth=1
	movq	$0, -72(%rbp)                   # 8-byte Folded Spill
.LBB54_31:                              #   in Loop: Header=BB54_20 Depth=1
	movq	$0, -56(%rbp)                   # 8-byte Folded Spill
.LBB54_32:                              #   in Loop: Header=BB54_20 Depth=1
	xorl	%r13d, %r13d
.LBB54_33:                              #   in Loop: Header=BB54_20 Depth=1
	movq	%rdi, %r12
	negq	%r12
	xorl	%ebx, %ebx
	movq	%rdi, -48(%rbp)                 # 8-byte Spill
.LBB54_34:                              #   Parent Loop BB54_20 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB54_38 Depth 3
	cmpq	$0, -56(%rbp)                   # 8-byte Folded Reload
	je	.LBB54_48
# %bb.35:                               #   in Loop: Header=BB54_34 Depth=2
	cmpq	%rdi, %rbx
	jae	.LBB54_19
# %bb.36:                               #   in Loop: Header=BB54_34 Depth=2
	leaq	(%rbx,%rbx,2), %rax
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	leaq	(%rdx,%rax,8), %rax
	incq	%rbx
	jmp	.LBB54_38
	.p2align	4
.LBB54_37:                              #   in Loop: Header=BB54_38 Depth=3
	addq	$24, %rax
	leaq	(%r12,%rbx), %rdx
	incq	%rdx
	incq	%rbx
	cmpq	$1, %rdx
	je	.LBB54_19
.LBB54_38:                              #   Parent Loop BB54_20 Depth=1
                                        #     Parent Loop BB54_34 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	8(%rax), %rdx
	movl	8(%rdx), %edi
	testl	%edi, %edi
	je	.LBB54_37
# %bb.39:                               #   in Loop: Header=BB54_38 Depth=3
	testq	%r13, %r13
	je	.LBB54_41
# %bb.40:                               #   in Loop: Header=BB54_38 Depth=3
	movl	16(%rax), %edx
	cmpl	(%r13), %edx
	jne	.LBB54_37
.LBB54_41:                              #   in Loop: Header=BB54_34 Depth=2
	movq	(%rax), %rax
	movq	(%r14,%rax), %rsi
	movq	$0, (%r14,%rax)
	cmpl	$5, %edi
	je	.LBB54_50
.LBB54_42:                              #   in Loop: Header=BB54_34 Depth=2
	testq	%rsi, %rsi
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	je	.LBB54_34
# %bb.43:                               #   in Loop: Header=BB54_34 Depth=2
	movq	-16(%rsi), %rdx
	movabsq	$4611686018427387906, %rax      # imm = 0x4000000000000002
	testq	%rax, %rdx
	jne	.LBB54_34
# %bb.44:                               #   in Loop: Header=BB54_34 Depth=2
	testb	$1, %dl
	jne	.LBB54_89
# %bb.45:                               #   in Loop: Header=BB54_34 Depth=2
	movl	-24(%rsi), %eax
	testl	%eax, %eax
	je	.LBB54_89
# %bb.46:                               #   in Loop: Header=BB54_34 Depth=2
	leaq	-24(%rsi), %r9
	decl	%eax
	movl	%eax, (%r9)
	jne	.LBB54_34
# %bb.47:                               #   in Loop: Header=BB54_34 Depth=2
	cmpl	$0, -20(%rsi)
	jne	.LBB54_34
	jmp	.LBB54_56
	.p2align	4
.LBB54_48:                              #   in Loop: Header=BB54_34 Depth=2
	cmpq	%rdi, %rbx
	je	.LBB54_19
# %bb.49:                               #   in Loop: Header=BB54_34 Depth=2
	movq	%rbx, %rax
	incq	%rbx
	imulq	-72(%rbp), %rax                 # 8-byte Folded Reload
	movl	%r8d, %edi
	movq	(%r14,%rax), %rsi
	movq	$0, (%r14,%rax)
	cmpl	$5, %edi
	jne	.LBB54_42
.LBB54_50:                              #   in Loop: Header=BB54_34 Depth=2
	testq	%rsi, %rsi
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	je	.LBB54_34
# %bb.51:                               #   in Loop: Header=BB54_34 Depth=2
	movq	-16(%rsi), %rdx
	movabsq	$4611686018427387906, %rax      # imm = 0x4000000000000002
	testq	%rax, %rdx
	jne	.LBB54_34
# %bb.52:                               #   in Loop: Header=BB54_34 Depth=2
	testb	$1, %dl
	jne	.LBB54_89
# %bb.53:                               #   in Loop: Header=BB54_34 Depth=2
	movl	-20(%rsi), %eax
	testl	%eax, %eax
	je	.LBB54_89
# %bb.54:                               #   in Loop: Header=BB54_34 Depth=2
	decl	%eax
	movl	%eax, -20(%rsi)
	orl	-24(%rsi), %eax
	jne	.LBB54_34
# %bb.55:                               #   in Loop: Header=BB54_34 Depth=2
	leaq	-24(%rsi), %r9
.LBB54_56:                              #   in Loop: Header=BB54_34 Depth=2
	orq	$1, %rdx
	movq	%rdx, -16(%rsi)
	movq	5640(%r10), %rdi
	cmpl	$0, 208(%rdi)
	je	.LBB54_58
# %bb.57:                               #   in Loop: Header=BB54_34 Depth=2
	movq	200(%rdi), %rax
	movq	%rax, (%r9)
	movq	5640(%r10), %rax
	movq	%r9, 200(%rax)
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	jmp	.LBB54_34
.LBB54_58:                              #   in Loop: Header=BB54_34 Depth=2
	movq	-8(%rsi), %rax
	cmpq	%rax, 272(%rdi)
	movq	%r8, -64(%rbp)                  # 8-byte Spill
	je	.LBB54_65
# %bb.59:                               #   in Loop: Header=BB54_34 Depth=2
	movl	52(%rax), %edx
	cmpq	%rdx, 160(%rdi)
	jbe	.LBB54_67
# %bb.60:                               #   in Loop: Header=BB54_34 Depth=2
	movq	152(%rdi), %r8
	shlq	$4, %rdx
	cmpq	%rax, (%r8,%rdx)
	jne	.LBB54_67
# %bb.61:                               #   in Loop: Header=BB54_34 Depth=2
	addq	%rdx, %r8
	movq	8(%r8), %rax
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	testq	%rax, %rax
	movq	-64(%rbp), %r8                  # 8-byte Reload
	je	.LBB54_63
.LBB54_62:                              #   in Loop: Header=BB54_34 Depth=2
	cmpl	$0, 64(%rax)
	je	.LBB54_64
.LBB54_63:                              #   in Loop: Header=BB54_34 Depth=2
	movq	5640(%r10), %rax
	movq	200(%rax), %rax
	movq	%rax, (%r9)
	movq	5640(%r10), %rax
	movq	%r9, 200(%rax)
	jmp	.LBB54_34
.LBB54_64:                              #   in Loop: Header=BB54_34 Depth=2
	movq	-16(%rsi), %rdx
.LBB54_65:                              #   in Loop: Header=BB54_34 Depth=2
	movq	%r11, -88(%rbp)                 # 8-byte Spill
	movq	%rcx, -96(%rbp)                 # 8-byte Spill
	movabsq	$4611686018427387906, %rax      # imm = 0x4000000000000002
	incq	%rax
	andq	%rdx, %rax
	cmpq	$1, %rax
	jne	.LBB54_89
# %bb.66:                               #   in Loop: Header=BB54_34 Depth=2
	movq	5640(%r10), %rax
	movq	%r10, %rdi
	callq	*8(%rax)
	movq	-80(%rbp), %r10                 # 8-byte Reload
	movq	-96(%rbp), %rcx                 # 8-byte Reload
	movq	-88(%rbp), %r11                 # 8-byte Reload
	movq	-64(%rbp), %r8                  # 8-byte Reload
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	jmp	.LBB54_34
.LBB54_67:                              #   in Loop: Header=BB54_34 Depth=2
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%r11, %r8
	callq	myl_rc_binding_find_slow
	movq	%r8, %r11
	movq	%rdx, %rsi
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	testq	%rax, %rax
	movq	-64(%rbp), %r8                  # 8-byte Reload
	jne	.LBB54_62
	jmp	.LBB54_63
.LBB54_68:                              #   in Loop: Header=BB54_71 Depth=1
	movq	200(%rdi), %rax
.LBB54_69:                              #   in Loop: Header=BB54_71 Depth=1
	movq	%rax, (%r9)
	movq	5640(%r10), %rax
	movq	%r9, 200(%rax)
	.p2align	4
.LBB54_70:                              #   in Loop: Header=BB54_71 Depth=1
	incq	%r15
	cmpq	%r15, %rcx
	je	.LBB54_88
.LBB54_71:                              # =>This Inner Loop Header: Depth=1
	movq	(%r14,%r15,8), %rsi
	movq	$0, (%r14,%r15,8)
	testq	%rsi, %rsi
	je	.LBB54_70
# %bb.72:                               #   in Loop: Header=BB54_71 Depth=1
	movq	-16(%rsi), %rdx
	testq	%rbx, %rdx
	jne	.LBB54_70
# %bb.73:                               #   in Loop: Header=BB54_71 Depth=1
	testb	$1, %dl
	jne	.LBB54_89
# %bb.74:                               #   in Loop: Header=BB54_71 Depth=1
	movl	-24(%rsi), %eax
	testl	%eax, %eax
	je	.LBB54_89
# %bb.75:                               #   in Loop: Header=BB54_71 Depth=1
	leaq	-24(%rsi), %r9
	decl	%eax
	movl	%eax, (%r9)
	jne	.LBB54_70
# %bb.76:                               #   in Loop: Header=BB54_71 Depth=1
	cmpl	$0, -20(%rsi)
	jne	.LBB54_70
# %bb.77:                               #   in Loop: Header=BB54_71 Depth=1
	orq	$1, %rdx
	movq	%rdx, -16(%rsi)
	movq	5640(%r10), %rdi
	cmpl	$0, 208(%rdi)
	jne	.LBB54_68
# %bb.78:                               #   in Loop: Header=BB54_71 Depth=1
	movq	-8(%rsi), %rax
	cmpq	%rax, 272(%rdi)
	je	.LBB54_85
# %bb.79:                               #   in Loop: Header=BB54_71 Depth=1
	movl	52(%rax), %edx
	cmpq	%rdx, 160(%rdi)
	jbe	.LBB54_87
# %bb.80:                               #   in Loop: Header=BB54_71 Depth=1
	movq	152(%rdi), %r8
	shlq	$4, %rdx
	cmpq	%rax, (%r8,%rdx)
	jne	.LBB54_87
# %bb.81:                               #   in Loop: Header=BB54_71 Depth=1
	addq	%rdx, %r8
	movq	8(%r8), %rax
	testq	%rax, %rax
	je	.LBB54_83
.LBB54_82:                              #   in Loop: Header=BB54_71 Depth=1
	cmpl	$0, 64(%rax)
	je	.LBB54_84
.LBB54_83:                              #   in Loop: Header=BB54_71 Depth=1
	movq	5640(%r10), %rax
	movq	200(%rax), %rax
	jmp	.LBB54_69
.LBB54_84:                              #   in Loop: Header=BB54_71 Depth=1
	movq	-16(%rsi), %rdx
.LBB54_85:                              #   in Loop: Header=BB54_71 Depth=1
	andq	%r12, %rdx
	cmpq	$1, %rdx
	jne	.LBB54_89
# %bb.86:                               #   in Loop: Header=BB54_71 Depth=1
	movq	%rcx, %r13
	movq	5640(%r10), %rax
	movq	%r10, %rdi
	callq	*8(%rax)
	movq	-80(%rbp), %r10                 # 8-byte Reload
	movq	%r13, %rcx
	jmp	.LBB54_70
.LBB54_87:                              #   in Loop: Header=BB54_71 Depth=1
	movq	%rsi, %rdx
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	movq	%rdx, %rsi
	testq	%rax, %rax
	jne	.LBB54_82
	jmp	.LBB54_83
.LBB54_88:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB54_89:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end54:
	.size	myl_rc_edges_release, .Lfunc_end54-myl_rc_edges_release
	.cfi_endproc
	.section	.rodata.myl_rc_edges_release,"a",@progbits
	.p2align	3, 0x0
.LJTI54_0:
	.quad	.LBB54_25
	.quad	.LBB54_27
	.quad	.LBB54_28
	.quad	.LBB54_26
	.quad	.LBB54_25
                                        # -- End function
	.section	.text.walk,"ax",@progbits
	.p2align	4                               # -- Begin function walk
	.type	walk,@function
walk:                                   # @walk
.Lfunc_begin55:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	5640(%rdi), %rdx
	movq	192(%rdx), %rax
	testq	%rax, %rax
	je	.LBB55_23
# %bb.1:
	movl	%esi, %ebx
	movq	%rdi, %r14
	leaq	192(%rdx), %rcx
	jmp	.LBB55_2
	.p2align	4
.LBB55_11:                              #   in Loop: Header=BB55_2 Depth=1
	decq	%rax
	movq	%rax, (%rcx)
.LBB55_22:                              #   in Loop: Header=BB55_2 Depth=1
	movq	5640(%r14), %rdx
	leaq	192(%rdx), %rcx
	movq	192(%rdx), %rax
	testq	%rax, %rax
	je	.LBB55_23
.LBB55_2:                               # =>This Inner Loop Header: Depth=1
	movq	176(%rdx), %rsi
	leaq	(%rax,%rax,2), %r8
	movq	-24(%rsi,%r8,8), %rdi
	movl	8(%rdi), %r10d
	leal	-1(%r10), %r9d
	cmpl	$4, %r9d
	ja	.LBB55_24
# %bb.3:                                #   in Loop: Header=BB55_2 Depth=1
	leaq	(%rsi,%r8,8), %rsi
	jmpq	*.LJTI55_0(,%r9,8)
.LBB55_4:                               #   in Loop: Header=BB55_2 Depth=1
	movq	-16(%rsi), %rax
	movq	(%rax), %rsi
	movq	$0, (%rax)
	movq	5640(%r14), %rax
	decq	192(%rax)
	testl	%ebx, %ebx
	je	.LBB55_22
# %bb.5:                                #   in Loop: Header=BB55_2 Depth=1
	cmpl	$5, 8(%rdi)
	jne	.LBB55_9
# %bb.6:                                #   in Loop: Header=BB55_2 Depth=1
	movq	%r14, %rdi
	callq	myl_rc_hold_edge_release
	movq	5640(%r14), %rax
	testq	%rax, %rax
	je	.LBB55_22
# %bb.7:                                #   in Loop: Header=BB55_2 Depth=1
	cmpq	$0, 200(%rax)
	je	.LBB55_22
# %bb.8:                                #   in Loop: Header=BB55_2 Depth=1
	movq	%r14, %rdi
	callq	myl_rc_drain
	jmp	.LBB55_22
	.p2align	4
.LBB55_15:                              #   in Loop: Header=BB55_2 Depth=1
	movq	-8(%rsi), %r9
	cmpq	24(%rdi), %r9
	je	.LBB55_11
# %bb.16:                               #   in Loop: Header=BB55_2 Depth=1
	leaq	(%r9,%r9,2), %r8
	shlq	$3, %r8
	addq	16(%rdi), %r8
	incq	%r9
	movq	%r9, -8(%rsi)
	movq	-16(%rsi), %r9
	cmpl	$4, %r10d
	jne	.LBB55_18
# %bb.17:                               #   in Loop: Header=BB55_2 Depth=1
	movq	32(%rdi), %rdi
	movl	16(%r8), %r10d
	cmpl	(%r9,%rdi), %r10d
	jne	.LBB55_22
.LBB55_18:                              #   in Loop: Header=BB55_2 Depth=1
	movq	8(%r8), %rdi
	cmpl	$0, 8(%rdi)
	je	.LBB55_22
# %bb.19:                               #   in Loop: Header=BB55_2 Depth=1
	cmpq	184(%rdx), %rax
	jae	.LBB55_24
# %bb.20:                               #   in Loop: Header=BB55_2 Depth=1
	addq	(%r8), %r9
	incq	%rax
	movq	%rax, (%rcx)
	movq	%rdi, (%rsi)
	movq	%r9, 8(%rsi)
	jmp	.LBB55_21
.LBB55_10:                              #   in Loop: Header=BB55_2 Depth=1
	movq	-8(%rsi), %r8
	cmpq	24(%rdi), %r8
	je	.LBB55_11
# %bb.12:                               #   in Loop: Header=BB55_2 Depth=1
	leaq	1(%r8), %r9
	movq	%r9, -8(%rsi)
	movq	16(%rdi), %r9
	cmpl	$0, 8(%r9)
	je	.LBB55_22
# %bb.13:                               #   in Loop: Header=BB55_2 Depth=1
	cmpq	184(%rdx), %rax
	jae	.LBB55_24
# %bb.14:                               #   in Loop: Header=BB55_2 Depth=1
	imulq	32(%rdi), %r8
	addq	-16(%rsi), %r8
	incq	%rax
	movq	%rax, (%rcx)
	movq	%r9, (%rsi)
	movq	%r8, 8(%rsi)
.LBB55_21:                              #   in Loop: Header=BB55_2 Depth=1
	movq	$0, 16(%rsi)
	jmp	.LBB55_22
.LBB55_9:                               #   in Loop: Header=BB55_2 Depth=1
	movq	%r14, %rdi
	callq	myl_rc_edge_release
	jmp	.LBB55_22
.LBB55_23:
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB55_24:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end55:
	.size	walk, .Lfunc_end55-walk
	.cfi_endproc
	.section	.rodata.walk,"a",@progbits
	.p2align	3, 0x0
.LJTI55_0:
	.quad	.LBB55_4
	.quad	.LBB55_15
	.quad	.LBB55_10
	.quad	.LBB55_15
	.quad	.LBB55_4
                                        # -- End function
	.section	.text.myl_rc_flat_edges_release,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_flat_edges_release
	.type	myl_rc_flat_edges_release,@function
myl_rc_flat_edges_release:              # @myl_rc_flat_edges_release
.Lfunc_begin56:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB56_34
# %bb.1:
	movq	%rdi, %r10
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB56_34
# %bb.2:
	cmpq	$0, 192(%rax)
	jne	.LBB56_34
# %bb.3:
	movq	%rsi, %r15
	movl	64(%rsi), %esi
	cmpl	$17, %esi
	jae	.LBB56_34
# %bb.4:
	movq	%rdx, %r14
	movq	80(%r15), %rdi
	movq	%rdi, %rax
	mulq	%rcx
	jo	.LBB56_34
# %bb.5:
	testq	%rax, %rax
	sete	%al
	testq	%r14, %r14
	setne	%dl
	orb	%al, %dl
	je	.LBB56_34
# %bb.6:
	testl	%esi, %esi
	sete	%al
	testq	%rcx, %rcx
	sete	%dl
	orb	%al, %dl
	jne	.LBB56_33
# %bb.7:
	movabsq	$4611686018427387906, %r13      # imm = 0x4000000000000002
	leaq	92(%r15), %r11
	leaq	90(%r15), %r8
	xorl	%ebx, %ebx
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movq	%r10, -48(%rbp)                 # 8-byte Spill
	jmp	.LBB56_8
	.p2align	4
.LBB56_31:                              #   in Loop: Header=BB56_8 Depth=1
	movq	80(%r15), %rdi
.LBB56_32:                              #   in Loop: Header=BB56_8 Depth=1
	addq	%rdi, %r14
	incq	%rbx
	cmpq	%rcx, %rbx
	je	.LBB56_33
.LBB56_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB56_11 Depth 2
	cmpb	$0, 70(%r15)
	leaq	88(%r15), %rax
	je	.LBB56_10
# %bb.9:                                #   in Loop: Header=BB56_8 Depth=1
	movl	72(%r15), %eax
	movl	(%r14,%rax), %eax
	cmpq	$32, %rax
	leaq	(%r11,%rax,2), %rax
	cmovaeq	%r8, %rax
.LBB56_10:                              #   in Loop: Header=BB56_8 Depth=1
	movzwl	(%rax), %r12d
	testl	%r12d, %r12d
	jne	.LBB56_11
	jmp	.LBB56_32
.LBB56_28:                              #   in Loop: Header=BB56_11 Depth=2
	movq	200(%rdi), %rax
.LBB56_29:                              #   in Loop: Header=BB56_11 Depth=2
	movq	%rax, (%r9)
	movq	5640(%r10), %rax
	movq	%r9, 200(%rax)
	.p2align	4
.LBB56_30:                              #   in Loop: Header=BB56_11 Depth=2
	blsrl	%r12d, %r12d
	je	.LBB56_31
.LBB56_11:                              #   Parent Loop BB56_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	tzcntl	%r12d, %eax
	movzwl	156(%r15,%rax,2), %eax
	movq	(%r14,%rax), %rsi
	movq	$0, (%r14,%rax)
	testq	%rsi, %rsi
	je	.LBB56_30
# %bb.12:                               #   in Loop: Header=BB56_11 Depth=2
	movq	-16(%rsi), %rdx
	testq	%r13, %rdx
	jne	.LBB56_30
# %bb.13:                               #   in Loop: Header=BB56_11 Depth=2
	testb	$1, %dl
	jne	.LBB56_34
# %bb.14:                               #   in Loop: Header=BB56_11 Depth=2
	movl	-24(%rsi), %eax
	testl	%eax, %eax
	je	.LBB56_34
# %bb.15:                               #   in Loop: Header=BB56_11 Depth=2
	leaq	-24(%rsi), %r9
	decl	%eax
	movl	%eax, (%r9)
	jne	.LBB56_30
# %bb.16:                               #   in Loop: Header=BB56_11 Depth=2
	cmpl	$0, -20(%rsi)
	jne	.LBB56_30
# %bb.17:                               #   in Loop: Header=BB56_11 Depth=2
	orq	$1, %rdx
	movq	%rdx, -16(%rsi)
	movq	5640(%r10), %rdi
	cmpl	$0, 208(%rdi)
	jne	.LBB56_28
# %bb.18:                               #   in Loop: Header=BB56_11 Depth=2
	movq	-8(%rsi), %rax
	cmpq	%rax, 272(%rdi)
	je	.LBB56_26
# %bb.19:                               #   in Loop: Header=BB56_11 Depth=2
	movl	52(%rax), %edx
	cmpq	%rdx, 160(%rdi)
	jbe	.LBB56_22
# %bb.20:                               #   in Loop: Header=BB56_11 Depth=2
	movq	152(%rdi), %r8
	shlq	$4, %rdx
	cmpq	%rax, (%r8,%rdx)
	jne	.LBB56_22
# %bb.21:                               #   in Loop: Header=BB56_11 Depth=2
	addq	%rdx, %r8
	movq	8(%r8), %rax
	testq	%rax, %rax
	leaq	90(%r15), %r8
	je	.LBB56_35
.LBB56_24:                              #   in Loop: Header=BB56_11 Depth=2
	cmpl	$0, 64(%rax)
	je	.LBB56_25
.LBB56_35:                              #   in Loop: Header=BB56_11 Depth=2
	movq	5640(%r10), %rax
	movq	200(%rax), %rax
	jmp	.LBB56_29
.LBB56_25:                              #   in Loop: Header=BB56_11 Depth=2
	movq	-16(%rsi), %rdx
.LBB56_26:                              #   in Loop: Header=BB56_11 Depth=2
	leaq	1(%r13), %rax
	andq	%rax, %rdx
	cmpq	$1, %rdx
	jne	.LBB56_34
# %bb.27:                               #   in Loop: Header=BB56_11 Depth=2
	movq	5640(%r10), %rax
	movq	%r10, %rdi
	callq	*8(%rax)
	movq	-48(%rbp), %r10                 # 8-byte Reload
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	leaq	92(%r15), %r11
	leaq	90(%r15), %r8
	jmp	.LBB56_30
.LBB56_22:                              #   in Loop: Header=BB56_11 Depth=2
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%r11, %r8
	callq	myl_rc_binding_find_slow
	movq	%r8, %r11
	movq	%rdx, %rsi
	testq	%rax, %rax
	leaq	90(%r15), %r8
	jne	.LBB56_24
	jmp	.LBB56_35
.LBB56_33:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB56_34:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end56:
	.size	myl_rc_flat_edges_release, .Lfunc_end56-myl_rc_flat_edges_release
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_drain,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_drain
	.type	myl_rc_drain,@function
myl_rc_drain:                           # @myl_rc_drain
.Lfunc_begin57:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB57_13
# %bb.1:
	movq	%rdi, %rbx
	movq	5640(%rdi), %r13
	testq	%r13, %r13
	je	.LBB57_13
# %bb.2:
	movq	200(%r13), %rax
	testq	%rax, %rax
	je	.LBB57_12
# %bb.3:
	cmpl	$0, 208(%r13)
	jne	.LBB57_12
# %bb.4:
	cmpq	$0, 192(%r13)
	jne	.LBB57_12
# %bb.5:
	movl	$1, 208(%r13)
	xorl	%r14d, %r14d
	cmpq	$myl_rc_storage_retire, 8(%r13)
	sete	%r14b
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -72(%rbp)
	vmovups	%ymm0, -96(%rbp)
	movq	%rax, -104(%rbp)
	movq	$-1, -72(%rbp)
	leaq	-104(%rbp), %rsi
	movq	%rbx, %rdi
	movl	%r14d, %edx
	vzeroupper
	callq	drain_fast
	testq	%rax, %rax
	je	.LBB57_8
# %bb.6:
	leaq	-56(%rbp), %r15
	leaq	-104(%rbp), %r12
	.p2align	4
.LBB57_7:                               # =>This Inner Loop Header: Depth=1
	movq	-104(%rbp), %rdx
	movq	%rbx, %rdi
	movq	%rax, %rsi
	movq	%r15, %rcx
	callq	drain_one
	movq	%rax, -104(%rbp)
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movl	%r14d, %edx
	callq	drain_fast
	testq	%rax, %rax
	jne	.LBB57_7
.LBB57_8:
	movq	$0, 200(%r13)
	movq	-56(%rbp), %rax
	testq	%rax, %rax
	je	.LBB57_11
# %bb.9:
	movq	64(%rbx), %rcx
	subq	%rax, %rcx
	jb	.LBB57_13
# %bb.10:
	movq	%rcx, 64(%rbx)
	addq	80(%rbx), %rax
	movq	$-1, %rcx
	cmovaeq	%rax, %rcx
	movq	%rcx, 80(%rbx)
	movq	-48(%rbp), %rax
	addq	%rax, 5904(%rbx)
.LBB57_11:
	movl	$0, 208(%r13)
.LBB57_12:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB57_13:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end57:
	.size	myl_rc_drain, .Lfunc_end57-myl_rc_drain
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          # -- Begin function drain_fast
.LCPI58_0:
	.quad	1                               # 0x1
	.zero	8
	.section	.text.drain_fast,"ax",@progbits
	.p2align	4
	.type	drain_fast,@function
drain_fast:                             # @drain_fast
.Lfunc_begin58:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rax
	movq	(%rsi), %rsi
	movq	8(%rax), %rcx
	movq	%rcx, -64(%rbp)                 # 8-byte Spill
	movq	16(%rax), %r14
	movq	24(%rax), %r11
	movq	32(%rax), %r15
	movl	40(%rax), %ebx
	vmovdqu	48(%rax), %xmm1
	testq	%rsi, %rsi
	je	.LBB58_1
# %bb.3:
	movl	%edx, %r10d
	movq	%rdi, %r12
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	vmovdqa	.LCPI58_0(%rip), %xmm2          # xmm2 = [1,u]
	movabsq	$4611686018427387907, %r13      # imm = 0x4000000000000003
	movq	%rdi, -88(%rbp)                 # 8-byte Spill
	jmp	.LBB58_4
	.p2align	4
.LBB58_27:                              #   in Loop: Header=BB58_4 Depth=1
	vmovdqa	%xmm1, -112(%rbp)
	movzwl	94(%r14), %r8d
	movl	92(%r14), %ecx
	movq	%r12, %rdi
	leaq	-112(%rbp), %r9
	movl	%ebx, -76(%rbp)                 # 4-byte Spill
	movl	%r10d, %ebx
	movq	%r15, %r12
	movq	%r11, %r15
	callq	drain_pairs
	movq	%r15, %r11
	movq	%r12, %r15
	movq	-88(%rbp), %r12                 # 8-byte Reload
	vmovdqa	.LCPI58_0(%rip), %xmm2          # xmm2 = [1,u]
	movl	%ebx, %r10d
	movl	-76(%rbp), %ebx                 # 4-byte Reload
	movq	%rax, %rdx
	vmovdqa	-112(%rbp), %xmm1
.LBB58_28:                              #   in Loop: Header=BB58_4 Depth=1
	movq	%rdx, %rsi
	testq	%rdx, %rdx
	je	.LBB58_29
.LBB58_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB58_43 Depth 2
                                        #     Child Loop BB58_33 Depth 2
	movq	(%rsi), %rdx
	movq	16(%rsi), %rcx
	cmpq	-64(%rbp), %rcx                 # 8-byte Folded Reload
	je	.LBB58_25
# %bb.5:                                #   in Loop: Header=BB58_4 Depth=1
	movq	5640(%r12), %rdi
	movq	216(%rdi), %rax
	cmpq	%rcx, %rax
	je	.LBB58_6
# %bb.7:                                #   in Loop: Header=BB58_4 Depth=1
	cmpq	%rcx, 224(%rdi)
	je	.LBB58_8
# %bb.9:                                #   in Loop: Header=BB58_4 Depth=1
	movl	52(%rcx), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB58_12
# %bb.10:                               #   in Loop: Header=BB58_4 Depth=1
	movq	152(%rdi), %r8
	shlq	$4, %rax
	cmpq	%rcx, (%r8,%rax)
	jne	.LBB58_12
# %bb.11:                               #   in Loop: Header=BB58_4 Depth=1
	addq	%rax, %r8
	movq	8(%r8), %r14
	testq	%r14, %r14
	je	.LBB58_36
.LBB58_14:                              #   in Loop: Header=BB58_4 Depth=1
	addq	$64, %r14
	movq	216(%rdi), %rax
	jmp	.LBB58_15
	.p2align	4
.LBB58_6:                               #   in Loop: Header=BB58_4 Depth=1
	movq	232(%rdi), %r14
	movl	(%r14), %eax
	testl	%eax, %eax
	jne	.LBB58_18
.LBB58_17:                              #   in Loop: Header=BB58_4 Depth=1
	xorl	%ebx, %ebx
	movabsq	$-4611686018427387901, %r11     # imm = 0xC000000000000003
	testl	%r10d, %r10d
	jne	.LBB58_20
	jmp	.LBB58_23
.LBB58_8:                               #   in Loop: Header=BB58_4 Depth=1
	movq	240(%rdi), %r14
.LBB58_15:                              #   in Loop: Header=BB58_4 Depth=1
	movq	%rax, 224(%rdi)
	movq	232(%rdi), %rax
	movq	%rax, 240(%rdi)
	movq	%rcx, 216(%rdi)
	movq	%r14, 232(%rdi)
	movl	(%r14), %eax
	testl	%eax, %eax
	je	.LBB58_17
.LBB58_18:                              #   in Loop: Header=BB58_4 Depth=1
	movzwl	24(%r14), %ebx
	movabsq	$-3458764513820540929, %r11     # imm = 0xCFFFFFFFFFFFFFFF
	testl	%r10d, %r10d
	je	.LBB58_23
.LBB58_20:                              #   in Loop: Header=BB58_4 Depth=1
	cmpl	$16, %eax
	ja	.LBB58_23
# %bb.21:                               #   in Loop: Header=BB58_4 Depth=1
	xorl	%edi, %edi
	testl	%eax, %eax
	setne	%al
	cmpb	$0, 6(%r14)
	je	.LBB58_22
.LBB58_23:                              #   in Loop: Header=BB58_4 Depth=1
	movq	$-1, %r15
.LBB58_24:                              #   in Loop: Header=BB58_4 Depth=1
	movq	%rcx, -64(%rbp)                 # 8-byte Spill
.LBB58_25:                              #   in Loop: Header=BB58_4 Depth=1
	movq	8(%rsi), %rax
	andq	%r11, %rax
	cmpq	%r15, %rax
	jne	.LBB58_30
# %bb.26:                               #   in Loop: Header=BB58_4 Depth=1
	cmpl	$3, %ebx
	je	.LBB58_27
	.p2align	4
# %bb.31:                               #   in Loop: Header=BB58_4 Depth=1
	testl	%ebx, %ebx
	je	.LBB58_43
.LBB58_32:                              #   in Loop: Header=BB58_4 Depth=1
	movl	%ebx, %eax
	jmp	.LBB58_33
	.p2align	4
.LBB58_35:                              #   in Loop: Header=BB58_33 Depth=2
	testb	$1, %r8b
	jne	.LBB58_36
.LBB58_42:                              #   in Loop: Header=BB58_33 Depth=2
	blsrl	%eax, %eax
	je	.LBB58_43
.LBB58_33:                              #   Parent Loop BB58_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	tzcntl	%eax, %ecx
	movzwl	92(%r14,%rcx,2), %ecx
	movq	24(%rsi,%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB58_42
# %bb.34:                               #   in Loop: Header=BB58_33 Depth=2
	movq	-16(%rcx), %r8
	testq	%r13, %r8
	jne	.LBB58_35
# %bb.37:                               #   in Loop: Header=BB58_33 Depth=2
	leaq	-24(%rcx), %rdi
	movl	(%rdi), %r9d
	cmpl	$1, %r9d
	je	.LBB58_40
# %bb.38:                               #   in Loop: Header=BB58_33 Depth=2
	testl	%r9d, %r9d
	jne	.LBB58_39
	jmp	.LBB58_36
.LBB58_40:                              #   in Loop: Header=BB58_33 Depth=2
	cmpl	$0, -20(%rcx)
	je	.LBB58_41
.LBB58_39:                              #   in Loop: Header=BB58_33 Depth=2
	decl	%r9d
	movl	%r9d, (%rdi)
	jmp	.LBB58_42
.LBB58_41:                              #   in Loop: Header=BB58_33 Depth=2
	orq	$1, %r8
	movq	%r8, -16(%rcx)
	movq	%rdx, -24(%rcx)
	movq	%rdi, %rdx
	jmp	.LBB58_42
	.p2align	4
.LBB58_43:                              #   Parent Loop BB58_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rsi, %rax
	andq	$-65536, %rax                   # imm = 0xFFFF0000
	movq	(%rax), %rcx
	movq	$3, 8(%rsi)
	movq	5648(%r12,%rcx,8), %rdi
	movq	%rdi, (%rsi)
	movq	%rsi, 5648(%r12,%rcx,8)
	vpinsrq	$1, 8(%rax), %xmm2, %xmm0
	vpaddq	%xmm1, %xmm0, %xmm1
	testq	%rdx, %rdx
	je	.LBB58_29
# %bb.44:                               #   in Loop: Header=BB58_43 Depth=2
	movq	-64(%rbp), %rax                 # 8-byte Reload
	cmpq	%rax, 16(%rdx)
	jne	.LBB58_28
# %bb.45:                               #   in Loop: Header=BB58_43 Depth=2
	movq	8(%rdx), %rax
	andq	%r11, %rax
	cmpq	%r15, %rax
	jne	.LBB58_28
# %bb.46:                               #   in Loop: Header=BB58_43 Depth=2
	movq	%rdx, %rsi
	movq	(%rdx), %rdx
	testl	%ebx, %ebx
	jne	.LBB58_32
	jmp	.LBB58_43
.LBB58_22:                              #   in Loop: Header=BB58_4 Depth=1
	movb	%al, %dil
	leaq	1(,%rdi,4), %r15
	jmp	.LBB58_24
.LBB58_12:                              #   in Loop: Header=BB58_4 Depth=1
	movq	%rsi, %r8
	movq	%rcx, %rsi
	vmovdqa	%xmm1, -64(%rbp)                # 16-byte Spill
	callq	myl_rc_binding_find_slow
	vmovdqa	.LCPI58_0(%rip), %xmm2          # xmm2 = [1,u]
	vmovdqa	-64(%rbp), %xmm1                # 16-byte Reload
	movq	%r8, %rsi
	movq	%rax, %r14
	testq	%r14, %r14
	jne	.LBB58_14
.LBB58_36:
	callq	myl_rc_invariant_failed
.LBB58_29:
	xorl	%esi, %esi
	xorl	%edx, %edx
.LBB58_30:
	movq	-72(%rbp), %rax                 # 8-byte Reload
	jmp	.LBB58_2
.LBB58_1:
	xorl	%esi, %esi
	xorl	%edx, %edx
.LBB58_2:
	movq	%rdx, (%rax)
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	%rcx, 8(%rax)
	movq	%r14, 16(%rax)
	movq	%r11, 24(%rax)
	movq	%r15, 32(%rax)
	movl	%ebx, 40(%rax)
	movl	$0, 44(%rax)
	vmovdqu	%xmm1, 48(%rax)
	movq	%rsi, %rax
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end58:
	.size	drain_fast, .Lfunc_end58-drain_fast
	.cfi_endproc
                                        # -- End function
	.section	.text.drain_one,"ax",@progbits
	.p2align	4                               # -- Begin function drain_one
	.type	drain_one,@function
drain_one:                              # @drain_one
.Lfunc_begin59:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	5640(%rdi), %r8
	movq	%rdx, 200(%r8)
	movq	(%rcx), %rax
	movq	%r8, %rdi
	testq	%rax, %rax
	je	.LBB59_3
# %bb.1:
	movq	64(%rbx), %rdx
	subq	%rax, %rdx
	jb	.LBB59_24
# %bb.2:
	movq	%rdx, 64(%rbx)
	addq	80(%rbx), %rax
	movq	$-1, %rdx
	cmovaeq	%rax, %rdx
	movq	%rdx, 80(%rbx)
	movq	8(%rcx), %rax
	addq	%rax, 5904(%rbx)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rcx)
	movq	5640(%rbx), %rdi
.LBB59_3:
	movq	16(%r14), %rsi
	movq	216(%rdi), %rcx
	cmpq	%rsi, %rcx
	je	.LBB59_4
# %bb.5:
	cmpq	%rsi, 224(%rdi)
	je	.LBB59_6
# %bb.7:
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB59_10
# %bb.8:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rsi, (%rcx,%rax)
	jne	.LBB59_10
# %bb.9:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB59_24
.LBB59_12:
	addq	$64, %rax
	movq	216(%rdi), %rcx
	jmp	.LBB59_13
.LBB59_4:
	movq	232(%rdi), %rax
	jmp	.LBB59_14
.LBB59_6:
	movq	240(%rdi), %rax
.LBB59_13:
	movq	%rcx, 224(%rdi)
	movq	232(%rdi), %rcx
	movq	%rcx, 240(%rdi)
	movq	%rsi, 216(%rdi)
	movq	%rax, 232(%rdi)
.LBB59_14:
	movq	%r8, -48(%rbp)                  # 8-byte Spill
	movabsq	$4611686018427387907, %r13      # imm = 0x4000000000000003
	movq	8(%r14), %rcx
	movq	%rcx, %rdx
	andq	%r13, %rdx
	cmpq	$1, %rdx
	jne	.LBB59_24
# %bb.15:
	leaq	24(%r14), %r15
	leaq	-64(%rax), %rsi
	movl	$60, %edx
	bzhiq	%rdx, %rcx, %r12
	shrq	$2, %r12
	cmpl	$16, (%rax)
	ja	.LBB59_33
# %bb.16:
	cmpq	$1, %r12
	jne	.LBB59_32
# %bb.17:
	cmpb	$0, 6(%rax)
	je	.LBB59_18
# %bb.19:
	movl	8(%rax), %ecx
	movl	(%r15,%rcx), %ecx
	leaq	26(%rax), %rdx
	cmpq	$32, %rcx
	leaq	28(%rax,%rcx,2), %rcx
	cmovaeq	%rdx, %rcx
	jmp	.LBB59_20
.LBB59_33:
	movq	-40(%rax), %rax
	testq	%rax, %rax
	je	.LBB59_39
# %bb.34:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	*%rax
	movq	16(%r14), %rsi
	movq	5640(%rbx), %rdi
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB59_37
# %bb.35:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rsi, (%rcx,%rax)
	jne	.LBB59_37
# %bb.36:
	addq	%rax, %rcx
	movq	8(%rcx), %rsi
	testq	%rsi, %rsi
	je	.LBB59_24
.LBB59_39:
	movq	-48(%rbp), %rax                 # 8-byte Reload
	cmpq	$0, 192(%rax)
	jne	.LBB59_24
# %bb.40:
	movq	16(%rsi), %rax
	testq	%rax, %rax
	je	.LBB59_42
# %bb.41:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	*%rax
	movq	-48(%rbp), %r12                 # 8-byte Reload
	cmpq	$0, 192(%r12)
	je	.LBB59_45
	jmp	.LBB59_24
.LBB59_32:
	movq	%rbx, %rdi
	movq	%r15, %rdx
	movq	%r12, %rcx
	callq	myl_rc_flat_edges_release
	movq	-48(%rbp), %r12                 # 8-byte Reload
	cmpq	$0, 192(%r12)
	je	.LBB59_45
	jmp	.LBB59_24
.LBB59_42:
	movq	8(%rsi), %rsi
	movq	%rbx, %rdi
	movq	%r15, %rdx
	movq	%r12, %rcx
	callq	myl_rc_edges_release
	movq	-48(%rbp), %r12                 # 8-byte Reload
	cmpq	$0, 192(%r12)
	je	.LBB59_45
	jmp	.LBB59_24
.LBB59_18:
	leaq	24(%rax), %rcx
.LBB59_20:
	movq	-48(%rbp), %r12                 # 8-byte Reload
	movzwl	(%rcx), %edx
	movq	200(%r12), %rcx
	testl	%edx, %edx
	jne	.LBB59_21
.LBB59_31:
	movq	%rcx, 200(%r12)
	cmpq	$0, 192(%r12)
	jne	.LBB59_24
.LBB59_45:
	movq	8(%r14), %rax
	andq	%rax, %r13
	cmpq	$1, %r13
	jne	.LBB59_24
# %bb.46:
	testq	%rax, %rax
	setns	%cl
	movq	5640(%rbx), %rax
	movq	8(%rax), %rax
	cmpq	$myl_rc_storage_retire, %rax
	sete	%dl
	andb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB59_51
# %bb.47:
	movq	64(%rbx), %rax
	testq	%rax, %rax
	je	.LBB59_24
# %bb.48:
	movq	80(%rbx), %rcx
	cmpq	$-1, %rcx
	je	.LBB59_50
# %bb.49:
	incq	%rcx
	movq	%rcx, 80(%rbx)
.LBB59_50:
	movq	%r14, %rcx
	andq	$-65536, %rcx                   # imm = 0xFFFF0000
	decq	%rax
	movq	%rax, 64(%rbx)
	movq	$3, 8(%r14)
	movq	(%rcx), %rax
	movq	5648(%rbx,%rax,8), %rax
	movq	%rax, (%r14)
	movq	(%rcx), %rax
	movq	%r14, 5648(%rbx,%rax,8)
	movq	8(%rcx), %rax
	addq	%rax, 5904(%rbx)
	jmp	.LBB59_52
	.p2align	4
.LBB59_23:                              #   in Loop: Header=BB59_21 Depth=1
	testb	$1, %r8b
	jne	.LBB59_24
.LBB59_30:                              #   in Loop: Header=BB59_21 Depth=1
	blsrl	%edx, %edx
	je	.LBB59_31
.LBB59_21:                              # =>This Inner Loop Header: Depth=1
	tzcntl	%edx, %esi
	movzwl	92(%rax,%rsi,2), %esi
	movq	(%r15,%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB59_30
# %bb.22:                               #   in Loop: Header=BB59_21 Depth=1
	movq	-16(%rsi), %r8
	testq	%r13, %r8
	jne	.LBB59_23
# %bb.25:                               #   in Loop: Header=BB59_21 Depth=1
	leaq	-24(%rsi), %rdi
	movl	(%rdi), %r9d
	cmpl	$1, %r9d
	je	.LBB59_28
# %bb.26:                               #   in Loop: Header=BB59_21 Depth=1
	testl	%r9d, %r9d
	jne	.LBB59_27
	jmp	.LBB59_24
.LBB59_28:                              #   in Loop: Header=BB59_21 Depth=1
	cmpl	$0, -20(%rsi)
	je	.LBB59_29
.LBB59_27:                              #   in Loop: Header=BB59_21 Depth=1
	decl	%r9d
	movl	%r9d, (%rdi)
	jmp	.LBB59_30
.LBB59_29:                              #   in Loop: Header=BB59_21 Depth=1
	orq	$1, %r8
	movq	%r8, -16(%rsi)
	movq	%rcx, -24(%rsi)
	movq	%rdi, %rcx
	jmp	.LBB59_30
.LBB59_51:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	*%rax
.LBB59_52:
	movq	200(%r12), %rax
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB59_10:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB59_12
	jmp	.LBB59_24
.LBB59_37:
	callq	myl_rc_binding_find_slow
	movq	%rax, %rsi
	testq	%rsi, %rsi
	jne	.LBB59_39
.LBB59_24:
	callq	myl_rc_invariant_failed
.Lfunc_end59:
	.size	drain_one, .Lfunc_end59-drain_one
	.cfi_endproc
                                        # -- End function
	.section	.text.drain_pairs,"ax",@progbits
	.p2align	4                               # -- Begin function drain_pairs
	.type	drain_pairs,@function
drain_pairs:                            # @drain_pairs
.Lfunc_begin60:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r9, -72(%rbp)                  # 8-byte Spill
	movabsq	$4611686018427387907, %rbx      # imm = 0x4000000000000003
	movq	16(%rsi), %r14
	movq	%rsi, %rax
	andq	$-65536, %rax                   # imm = 0xFFFF0000
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	movq	(%rax), %rax
	movzwl	%cx, %r15d
	movzwl	%r8w, %r8d
	movq	%rdi, -56(%rbp)                 # 8-byte Spill
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	movq	5648(%rdi,%rax,8), %r11
	movl	$1, %ecx
	xorl	%r12d, %r12d
	movabsq	$-3458764513820540929, %r13     # imm = 0xCFFFFFFFFFFFFFFF
	movq	24(%rsi,%r15), %rax
	testq	%rax, %rax
	je	.LBB60_10
	.p2align	4
.LBB60_2:
	movq	-16(%rax), %rdi
	testq	%rbx, %rdi
	je	.LBB60_5
# %bb.3:
	testb	$1, %dil
	je	.LBB60_10
	jmp	.LBB60_4
	.p2align	4
.LBB60_5:
	leaq	-24(%rax), %r9
	movl	(%r9), %r10d
	cmpl	$1, %r10d
	je	.LBB60_8
# %bb.6:
	testl	%r10d, %r10d
	jne	.LBB60_7
	jmp	.LBB60_4
.LBB60_8:
	cmpl	$0, -20(%rax)
	je	.LBB60_9
.LBB60_7:
	decl	%r10d
	movl	%r10d, (%r9)
	.p2align	4
.LBB60_10:
	movq	24(%rsi,%r8), %r9
	testq	%r9, %r9
	je	.LBB60_13
.LBB60_11:
	movq	-16(%r9), %rdi
	testq	%rbx, %rdi
	je	.LBB60_15
# %bb.12:
	testb	$1, %dil
	je	.LBB60_13
	jmp	.LBB60_4
	.p2align	4
.LBB60_15:
	leaq	-24(%r9), %rax
	movl	(%rax), %r10d
	cmpl	$1, %r10d
	je	.LBB60_18
# %bb.16:
	testl	%r10d, %r10d
	jne	.LBB60_17
	jmp	.LBB60_4
.LBB60_18:
	cmpl	$0, -20(%r9)
	je	.LBB60_19
.LBB60_17:
	decl	%r10d
	movl	%r10d, (%rax)
	.p2align	4
.LBB60_13:
	movq	$3, 8(%rsi)
	movq	%r11, (%rsi)
	testq	%rdx, %rdx
	je	.LBB60_23
# %bb.14:
	incq	%r12
	movq	%rdx, %rax
	cmpq	%r14, 16(%rax)
	jne	.LBB60_24
.LBB60_21:
	movq	8(%rax), %rdx
	andq	%r13, %rdx
	cmpq	$5, %rdx
	jne	.LBB60_24
# %bb.22:
	movq	(%rax), %rdx
	incq	%rcx
	movq	%rsi, %r11
	movq	%rax, %rsi
	movq	24(%rsi,%r15), %rax
	testq	%rax, %rax
	jne	.LBB60_2
	jmp	.LBB60_10
.LBB60_9:
	orq	$1, %rdi
	movq	%rdi, -16(%rax)
	movq	%rdx, -24(%rax)
	movq	%r9, %rdx
	movq	24(%rsi,%r8), %r9
	testq	%r9, %r9
	jne	.LBB60_11
	jmp	.LBB60_13
.LBB60_19:
	orq	$1, %rdi
	movq	%rdi, -16(%r9)
	movq	%rdx, -24(%r9)
	movq	$3, 8(%rsi)
	movq	%r11, (%rsi)
	incq	%r12
	cmpq	%r14, 16(%rax)
	je	.LBB60_21
	jmp	.LBB60_24
.LBB60_23:
	xorl	%eax, %eax
.LBB60_24:
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	movq	%rsi, 5648(%rdx,%rdi,8)
	vmovq	%rcx, %xmm0
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	imulq	8(%rdx), %rcx
	vmovq	%rcx, %xmm1
	vpunpcklqdq	%xmm1, %xmm0, %xmm0     # xmm0 = xmm0[0],xmm1[0]
	movq	-72(%rbp), %rcx                 # 8-byte Reload
	vpaddq	(%rcx), %xmm0, %xmm0
	vmovdqu	%xmm0, (%rcx)
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB60_4:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end60:
	.size	drain_pairs, .Lfunc_end60-drain_pairs
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_native_has_unique,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_native_has_unique
	.type	myl_rc_native_has_unique,@function
myl_rc_native_has_unique:               # @myl_rc_native_has_unique
.Lfunc_begin61:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	testq	%rdi, %rdi
	je	.LBB61_29
# %bb.1:
	movq	5640(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB61_29
# %bb.2:
	cmpq	$0, 192(%rcx)
	jne	.LBB61_29
# %bb.3:
	vxorps	%xmm0, %xmm0, %xmm0
	movl	$352, %edx                      # imm = 0x160
	movzwl	48(%rsi), %eax
	cmpw	$1, %ax
	jne	.LBB61_15
.LBB61_6:
	cmpw	$5, 50(%rsi)
	jne	.LBB61_21
# %bb.7:
	movq	56(%rsi), %rax
	testq	%rax, %rax
	je	.LBB61_21
# %bb.8:
	movl	52(%rax), %r8d
	cmpq	%r8, 160(%rcx)
	jbe	.LBB61_11
# %bb.9:
	movq	152(%rcx), %r9
	shlq	$4, %r8
	cmpq	%rax, (%r9,%r8)
	jne	.LBB61_11
# %bb.10:
	addq	%r8, %r9
	movq	8(%r9), %rax
	testq	%rax, %rax
	je	.LBB61_29
.LBB61_13:
	cmpq	$0, 24(%rax)
	jne	.LBB61_18
# %bb.14:
	movzwl	48(%rsi), %eax
.LBB61_15:
	movzwl	%ax, %eax
	leal	-2(%rax), %ecx
	cmpl	$3, %ecx
	jae	.LBB61_16
# %bb.19:
	movq	5640(%rdi), %rax
	movq	192(%rax), %rcx
	cmpq	184(%rax), %rcx
	jae	.LBB61_29
# %bb.20:
	movq	176(%rax), %r8
	leaq	1(%rcx), %r9
	movq	%r9, 192(%rax)
	leaq	(%rcx,%rcx,2), %rax
	movq	%rsi, (%r8,%rax,8)
	vmovups	%xmm0, 8(%r8,%rax,8)
.LBB61_21:
	movq	5640(%rdi), %rcx
	movq	192(%rcx), %rsi
	xorl	%eax, %eax
	testq	%rsi, %rsi
	je	.LBB61_28
# %bb.22:
	leaq	(%rsi,%rsi,2), %r8
	decq	%rsi
	shlq	$3, %r8
	addq	176(%rcx), %r8
	.p2align	4
.LBB61_23:                              # =>This Inner Loop Header: Depth=1
	movq	-24(%r8), %r9
	cmpw	$3, 48(%r9)
	jne	.LBB61_25
# %bb.24:                               #   in Loop: Header=BB61_23 Depth=1
	xorl	%r10d, %r10d
	cmpq	$0, 32(%r9)
	setne	%r10b
	movq	-8(%r8), %r11
	cmpq	%r10, %r11
	jae	.LBB61_27
	jmp	.LBB61_4
	.p2align	4
.LBB61_25:                              #   in Loop: Header=BB61_23 Depth=1
	movq	24(%r9), %r10
	movq	-8(%r8), %r11
	cmpq	%r10, %r11
	jb	.LBB61_4
.LBB61_27:                              #   in Loop: Header=BB61_23 Depth=1
	movq	%rsi, 192(%rcx)
	addq	$-24, %r8
	addq	$-1, %rsi
	jb	.LBB61_23
	jmp	.LBB61_28
	.p2align	4
.LBB61_4:
	movq	16(%r9), %rax
	leaq	1(%r11), %rsi
	movq	%rsi, -8(%r8)
	leaq	(%r11,%r11,2), %rsi
	movq	8(%rax,%rsi,8), %rsi
	movzwl	48(%rsi), %eax
	cmpw	$1, %ax
	je	.LBB61_6
	jmp	.LBB61_15
	.p2align	4
.LBB61_16:
	cmpl	$8, %eax
	ja	.LBB61_21
# %bb.17:
	btl	%eax, %edx
	jae	.LBB61_21
	jmp	.LBB61_18
.LBB61_11:
	movq	%rdi, %r8
	movq	%rcx, %rdi
	movq	%rsi, %rcx
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	vxorps	%xmm0, %xmm0, %xmm0
	movq	%rcx, %rsi
	movq	%r8, %rdi
	testq	%rax, %rax
	jne	.LBB61_13
.LBB61_29:
	callq	myl_rc_invariant_failed
.LBB61_28:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB61_18:
	.cfi_def_cfa %rbp, 16
	movq	5640(%rdi), %rax
	movq	$0, 192(%rax)
	movl	$1, %eax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end61:
	.size	myl_rc_native_has_unique, .Lfunc_end61-myl_rc_native_has_unique
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_value_seed,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_value_seed
	.type	myl_rc_value_seed,@function
myl_rc_value_seed:                      # @myl_rc_value_seed
.Lfunc_begin62:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB62_18
# %bb.1:
	movq	%rdx, %r14
	movq	%rdi, %r15
	movq	5640(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB62_18
# %bb.2:
	cmpq	%rcx, %r14
	je	.LBB62_18
# %bb.3:
	cmpq	$0, 192(%rdx)
	jne	.LBB62_18
# %bb.4:
	movq	88(%rdx), %rax
	movq	96(%rdx), %rdi
	movzbl	112(%rdx), %edx
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%rsi, %r9
	shrxq	%rdx, %r9, %rdx
	.p2align	4
.LBB62_5:                               # =>This Inner Loop Header: Depth=1
	andq	%rdi, %rdx
	movq	%rdx, %r9
	shlq	$4, %r9
	movq	(%rax,%r9), %r9
	cmpq	%rsi, %r9
	je	.LBB62_6
# %bb.17:                               #   in Loop: Header=BB62_5 Depth=1
	testq	%r9, %r9
	je	.LBB62_18
# %bb.16:                               #   in Loop: Header=BB62_5 Depth=1
	incq	%rdx
	jmp	.LBB62_5
.LBB62_6:
	shlq	$4, %rdx
	movq	8(%rax,%rdx), %r12
	testq	%r12, %r12
	je	.LBB62_18
# %bb.7:
	movq	%r8, %rax
	mulq	(%r12)
	jo	.LBB62_18
# %bb.8:
	movl	8(%r12), %edx
	orl	$4, %edx
	cmpl	$5, %edx
	jne	.LBB62_9
# %bb.41:
	movq	%r14, %rdi
	xorl	%esi, %esi
	movq	%rax, %rdx
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	memset@PLT                      # TAILCALL
.LBB62_9:
	.cfi_def_cfa %rbp, 16
	movq	%r14, %rdi
	movq	%rcx, %rsi
	movq	%rax, %rdx
	movq	%r8, -48(%rbp)                  # 8-byte Spill
	callq	memcpy@PLT
	movq	-48(%rbp), %r11                 # 8-byte Reload
	cmpl	$0, 8(%r12)
	je	.LBB62_40
# %bb.10:
	testq	%r11, %r11
	je	.LBB62_40
# %bb.11:
	movq	40(%r12), %r13
	xorl	%ebx, %ebx
	jmp	.LBB62_12
	.p2align	4
.LBB62_38:                              #   in Loop: Header=BB62_12 Depth=1
	movq	%r15, %rdi
	xorl	%esi, %esi
	callq	walk
	movq	-48(%rbp), %r11                 # 8-byte Reload
.LBB62_39:                              #   in Loop: Header=BB62_12 Depth=1
	addq	(%r12), %r14
	incq	%rbx
	cmpq	%r11, %rbx
	je	.LBB62_40
.LBB62_12:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB62_25 Depth 2
                                        #       Child Loop BB62_28 Depth 3
	movl	8(%r12), %eax
	cmpq	$2, %r13
	jbe	.LBB62_13
# %bb.35:                               #   in Loop: Header=BB62_12 Depth=1
	testl	%eax, %eax
	je	.LBB62_38
# %bb.36:                               #   in Loop: Header=BB62_12 Depth=1
	movq	5640(%r15), %rax
	movq	192(%rax), %rcx
	cmpq	184(%rax), %rcx
	jae	.LBB62_18
# %bb.37:                               #   in Loop: Header=BB62_12 Depth=1
	movq	176(%rax), %rdx
	leaq	1(%rcx), %rsi
	movq	%rsi, 192(%rax)
	leaq	(%rcx,%rcx,2), %rax
	movq	%r12, (%rdx,%rax,8)
	movq	%r14, 8(%rdx,%rax,8)
	movq	$0, 16(%rdx,%rax,8)
	jmp	.LBB62_38
	.p2align	4
.LBB62_13:                              #   in Loop: Header=BB62_12 Depth=1
	decl	%eax
	cmpl	$4, %eax
	ja	.LBB62_14
# %bb.19:                               #   in Loop: Header=BB62_12 Depth=1
	jmpq	*.LJTI62_0(,%rax,8)
.LBB62_20:                              #   in Loop: Header=BB62_12 Depth=1
	movl	$1, %eax
	xorl	%ecx, %ecx
	jmp	.LBB62_15
.LBB62_23:                              #   in Loop: Header=BB62_12 Depth=1
	movq	16(%r12), %rdx
	movq	24(%r12), %rax
	movq	32(%r12), %rsi
	addq	%r14, %rsi
	xorl	%ecx, %ecx
	jmp	.LBB62_24
.LBB62_22:                              #   in Loop: Header=BB62_12 Depth=1
	movq	16(%r12), %rdx
	movq	24(%r12), %rax
	xorl	%ecx, %ecx
	xorl	%esi, %esi
	jmp	.LBB62_24
.LBB62_21:                              #   in Loop: Header=BB62_12 Depth=1
	movq	24(%r12), %rax
	movq	32(%r12), %rcx
	jmp	.LBB62_15
.LBB62_14:                              #   in Loop: Header=BB62_12 Depth=1
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB62_15:                              #   in Loop: Header=BB62_12 Depth=1
	xorl	%esi, %esi
	xorl	%edx, %edx
.LBB62_24:                              #   in Loop: Header=BB62_12 Depth=1
	movq	%rax, %rdi
	negq	%rdi
	xorl	%r8d, %r8d
.LBB62_25:                              #   Parent Loop BB62_12 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB62_28 Depth 3
	testq	%rdx, %rdx
	je	.LBB62_32
# %bb.26:                               #   in Loop: Header=BB62_25 Depth=2
	cmpq	%rax, %r8
	jae	.LBB62_39
# %bb.27:                               #   in Loop: Header=BB62_25 Depth=2
	leaq	(%r8,%r8,2), %r9
	leaq	(%rdx,%r9,8), %r9
	incq	%r8
	jmp	.LBB62_28
	.p2align	4
.LBB62_34:                              #   in Loop: Header=BB62_28 Depth=3
	addq	$24, %r9
	leaq	(%rdi,%r8), %r10
	incq	%r10
	incq	%r8
	cmpq	$1, %r10
	je	.LBB62_39
.LBB62_28:                              #   Parent Loop BB62_12 Depth=1
                                        #     Parent Loop BB62_25 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	8(%r9), %r10
	cmpl	$0, 8(%r10)
	je	.LBB62_34
# %bb.29:                               #   in Loop: Header=BB62_28 Depth=3
	testq	%rsi, %rsi
	je	.LBB62_31
# %bb.30:                               #   in Loop: Header=BB62_28 Depth=3
	movl	16(%r9), %r10d
	cmpl	(%rsi), %r10d
	jne	.LBB62_34
.LBB62_31:                              #   in Loop: Header=BB62_25 Depth=2
	movq	(%r9), %r9
	movq	$0, (%r14,%r9)
	jmp	.LBB62_25
	.p2align	4
.LBB62_32:                              #   in Loop: Header=BB62_25 Depth=2
	cmpq	%rax, %r8
	je	.LBB62_39
# %bb.33:                               #   in Loop: Header=BB62_25 Depth=2
	leaq	1(%r8), %r9
	imulq	%rcx, %r8
	movq	$0, (%r14,%r8)
	movq	%r9, %r8
	jmp	.LBB62_25
.LBB62_40:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB62_18:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end62:
	.size	myl_rc_value_seed, .Lfunc_end62-myl_rc_value_seed
	.cfi_endproc
	.section	.rodata.myl_rc_value_seed,"a",@progbits
	.p2align	3, 0x0
.LJTI62_0:
	.quad	.LBB62_20
	.quad	.LBB62_22
	.quad	.LBB62_21
	.quad	.LBB62_23
	.quad	.LBB62_20
                                        # -- End function
	.section	.text.myl_rc_construction_abort,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_construction_abort
	.type	myl_rc_construction_abort,@function
myl_rc_construction_abort:              # @myl_rc_construction_abort
.Lfunc_begin63:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rsi, %rsi
	je	.LBB63_6
# %bb.1:
	movq	-16(%rsi), %rax
	testb	$2, %al
	jne	.LBB63_25
# %bb.2:
	movq	%rdi, %rbx
	btq	$62, %rax
	jb	.LBB63_7
# %bb.3:
	movq	%rbx, %rdi
	callq	myl_rc_edge_release
	testq	%rbx, %rbx
	je	.LBB63_6
# %bb.4:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB63_6
# %bb.5:
	cmpq	$0, 200(%rax)
	jne	.LBB63_24
	jmp	.LBB63_6
.LBB63_7:
	testb	$1, %al
	jne	.LBB63_6
# %bb.8:
	orq	$1, %rax
	movq	%rax, -16(%rsi)
	movq	-8(%rsi), %rax
	movq	5640(%rbx), %rdi
	movl	52(%rax), %ecx
	cmpq	%rcx, 160(%rdi)
	movq	%rsi, %r14
	jbe	.LBB63_11
# %bb.9:
	movq	152(%rdi), %rdx
	shlq	$4, %rcx
	cmpq	%rax, (%rdx,%rcx)
	jne	.LBB63_11
# %bb.10:
	addq	%rcx, %rdx
	movq	8(%rdx), %rax
	testq	%rax, %rax
	je	.LBB63_25
.LBB63_13:
	movl	$40, %ecx
	bzhiq	%rcx, -16(%rsi), %r15
	movq	24(%rax), %rax
	testq	%rax, %rax
	je	.LBB63_15
# %bb.14:
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	*%rax
	movq	%r14, %rsi
.LBB63_15:
	movq	-8(%rsi), %rax
	movq	5640(%rbx), %rdi
	movl	52(%rax), %ecx
	cmpq	%rcx, 160(%rdi)
	jbe	.LBB63_18
# %bb.16:
	movq	152(%rdi), %rdx
	shlq	$4, %rcx
	cmpq	%rax, (%rdx,%rcx)
	jne	.LBB63_18
# %bb.17:
	addq	%rcx, %rdx
	movq	8(%rdx), %rax
	shrq	$2, %r15
	movq	16(%rax), %rcx
	testq	%rcx, %rcx
	je	.LBB63_21
.LBB63_20:
	movq	%rbx, %rdi
	movq	%r15, %rdx
	callq	*%rcx
	movq	-8(%r14), %rcx
	movq	%r15, %rax
	mulq	(%rcx)
	jno	.LBB63_23
	jmp	.LBB63_25
.LBB63_6:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB63_11:
	.cfi_def_cfa %rbp, 16
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r14, %rsi
	testq	%rax, %rax
	jne	.LBB63_13
	jmp	.LBB63_25
.LBB63_18:
	movq	%rax, %rsi
	callq	myl_rc_binding_find_slow
	movq	%r14, %rsi
	shrq	$2, %r15
	movq	16(%rax), %rcx
	testq	%rcx, %rcx
	jne	.LBB63_20
.LBB63_21:
	movq	8(%rax), %rax
	movq	%rbx, %rdi
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%r15, %rcx
	callq	myl_rc_edges_release
	movq	-8(%r14), %rcx
	movq	%r15, %rax
	mulq	(%rcx)
	jo	.LBB63_25
.LBB63_23:
	movq	%r14, %rdi
	xorl	%esi, %esi
	movq	%rax, %rdx
	callq	memset@PLT
.LBB63_24:
	movq	%rbx, %rdi
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_drain                    # TAILCALL
.LBB63_25:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end63:
	.size	myl_rc_construction_abort, .Lfunc_end63-myl_rc_construction_abort
	.cfi_endproc
                                        # -- End function
	.section	.text.clock_now,"ax",@progbits
	.p2align	4                               # -- Begin function clock_now
	.type	clock_now,@function
clock_now:                              # @clock_now
.Lfunc_begin64:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -24
	xorl	%ebx, %ebx
	leaq	-24(%rbp), %rsi
	xorl	%edi, %edi
	callq	clock_gettime@PLT
	movl	%eax, %ecx
	movl	$3, %eax
	testl	%ecx, %ecx
	jne	.LBB64_3
# %bb.1:
	movq	-24(%rbp), %rsi
	movq	-16(%rbp), %rcx
	movabsq	$9223372036854775807, %rdx      # imm = 0x7FFFFFFFFFFFFFFF
	xorq	%rcx, %rdx
	movabsq	$1237940039285380275, %rdi      # imm = 0x112E0BE826D694B3
	mulxq	%rdi, %rdx, %rdx
	shrq	$26, %rdx
	xorl	%ebx, %ebx
	cmpq	%rdx, %rsi
	jg	.LBB64_3
# %bb.2:
	imulq	$1000000000, %rsi, %rbx         # imm = 0x3B9ACA00
	addq	%rcx, %rbx
	xorl	%eax, %eax
.LBB64_3:
	movq	%rbx, %rdx
	addq	$24, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end64:
	.size	clock_now, .Lfunc_end64-clock_now
	.cfi_endproc
                                        # -- End function
	.section	.text.random_u64,"ax",@progbits
	.p2align	4                               # -- Begin function random_u64
	.type	random_u64,@function
random_u64:                             # @random_u64
.Lfunc_begin65:
	.cfi_startproc
# %bb.0:
	movabsq	$-7046029254386353131, %rax     # imm = 0x9E3779B97F4A7C15
	addq	(%rdi), %rax
	movq	%rax, (%rdi)
	movq	%rax, %rcx
	shrq	$30, %rcx
	xorq	%rax, %rcx
	movabsq	$-4658895280553007687, %rax     # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$27, %rcx
	xorq	%rax, %rcx
	movabsq	$-7723592293110705685, %rax     # imm = 0x94D049BB133111EB
	imulq	%rcx, %rax
	movq	%rax, %rdx
	shrq	$31, %rdx
	xorq	%rax, %rdx
	xorl	%eax, %eax
	retq
.Lfunc_end65:
	.size	random_u64, .Lfunc_end65-random_u64
	.cfi_endproc
                                        # -- End function
	.section	.text.environment_get,"ax",@progbits
	.p2align	4                               # -- Begin function environment_get
	.type	environment_get,@function
environment_get:                        # @environment_get
.Lfunc_begin66:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$280, %rsp                      # imm = 0x118
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rdi)
	movq	$0, 16(%rdi)
	cmpq	$256, %rcx                      # imm = 0x100
	jb	.LBB66_2
.LBB66_1:
	movl	$2, (%rbx)
.LBB66_15:
	movq	%rbx, %rax
	addq	$280, %rsp                      # imm = 0x118
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB66_2:
	.cfi_def_cfa %rbp, 16
	movq	%rcx, %r15
	movq	%rsi, %r14
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%r8, -48(%rbp)                  # 8-byte Spill
	leaq	-320(%rbp), %rdi
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	callq	memcpy@PLT
	movb	$0, -320(%rbp,%r15)
	cmpb	$0, (%r14)
	je	.LBB66_11
# %bb.3:
	leaq	-320(%rbp), %r13
	jmp	.LBB66_5
	.p2align	4
.LBB66_4:                               #   in Loop: Header=BB66_5 Depth=1
	movq	%r12, %rax
	incq	%r12
	cmpb	$0, 1(%rax)
	movq	%r12, %r14
	je	.LBB66_1
.LBB66_5:                               # =>This Inner Loop Header: Depth=1
	movq	%r14, %rdi
	movl	$44, %esi
	callq	strchr@PLT
	testq	%rax, %rax
	je	.LBB66_8
# %bb.6:                                #   in Loop: Header=BB66_5 Depth=1
	movq	%rax, %r12
	subq	%r14, %rax
	cmpq	%r15, %rax
	jne	.LBB66_4
# %bb.7:                                #   in Loop: Header=BB66_5 Depth=1
	movq	%r14, %rdi
	movq	%r13, %rsi
	movq	%r15, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB66_4
	jmp	.LBB66_11
.LBB66_8:
	movq	%r14, %rdi
	callq	strlen@PLT
	cmpq	%r15, %rax
	jne	.LBB66_1
# %bb.9:
	leaq	-320(%rbp), %rsi
	movq	%r14, %rdi
	movq	%r15, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB66_1
.LBB66_11:
	leaq	-320(%rbp), %rdi
	callq	getenv@PLT
	testq	%rax, %rax
	je	.LBB66_15
# %bb.12:
	movq	%rax, %r14
	movq	%rax, %rdi
	callq	strlen@PLT
	cmpq	-56(%rbp), %rax                 # 8-byte Folded Reload
	jbe	.LBB66_14
# %bb.13:
	movl	$5, (%rbx)
	jmp	.LBB66_15
.LBB66_14:
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	movq	%r14, %rsi
	movq	%rax, %rdx
	movq	%rax, %r14
	callq	memcpy@PLT
	movl	$1, 16(%rbx)
	movq	%r14, 8(%rbx)
	jmp	.LBB66_15
.Lfunc_end66:
	.size	environment_get, .Lfunc_end66-environment_get
	.cfi_endproc
                                        # -- End function
	.section	.text.mylang_scoped_endpoint,"ax",@progbits
	.p2align	4                               # -- Begin function mylang_scoped_endpoint
	.type	mylang_scoped_endpoint,@function
mylang_scoped_endpoint:                 # @mylang_scoped_endpoint
.Lfunc_begin67:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %r15
	movq	%rdi, %r13
	movq	%rsi, %rdi
	callq	strlen@PLT
	movq	%rax, %r14
	addq	$-4097, %rax                    # imm = 0xEFFF
	cmpq	$-4096, %rax                    # imm = 0xF000
	jb	.LBB67_1
# %bb.2:
	movq	10472(%r13), %rbx
	cmpq	$7, %rbx
	jbe	.LBB67_4
.LBB67_1:
	xorl	%eax, %eax
.LBB67_23:
                                        # kill: def $eax killed $eax killed $rax
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB67_4:
	.cfi_def_cfa %rbp, 16
	cmpq	$1, %r14
	jne	.LBB67_12
# %bb.5:
	cmpb	$42, (%r15)
	jne	.LBB67_12
# %bb.6:
	movq	%r13, -48(%rbp)                 # 8-byte Spill
	testq	%rbx, %rbx
	je	.LBB67_21
.LBB67_7:
	movq	-48(%rbp), %rax                 # 8-byte Reload
	leaq	10352(%rax), %r12
	movq	%rbx, %r13
	jmp	.LBB67_9
	.p2align	4
.LBB67_8:                               #   in Loop: Header=BB67_9 Depth=1
	addq	$16, %r12
	decq	%r13
	je	.LBB67_21
.LBB67_9:                               # =>This Inner Loop Header: Depth=1
	cmpq	%r14, (%r12)
	jne	.LBB67_8
# %bb.10:                               #   in Loop: Header=BB67_9 Depth=1
	movq	-8(%r12), %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB67_8
	jmp	.LBB67_1
.LBB67_12:
	movq	%r15, %rdi
	movl	$58, %esi
	callq	strrchr@PLT
	testq	%rax, %rax
	je	.LBB67_1
# %bb.13:
	movq	%rax, %r12
	subq	%r15, %r12
	je	.LBB67_1
# %bb.14:
	cmpq	$63, %r12
	ja	.LBB67_1
# %bb.15:
	leaq	-128(%rbp), %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	movq	%r13, %rbx
	movq	%rax, %r13
	callq	memcpy@PLT
	movb	$0, -128(%rbp,%r12)
	incq	%r13
	movq	%r13, %rdi
	movq	%rbx, %r13
	xorl	%esi, %esi
	movl	$10, %edx
	callq	strtoul@PLT
	leaq	-65536(%rax), %rcx
	cmpq	$-65535, %rcx                   # imm = 0xFFFF0001
	jb	.LBB67_1
# %bb.19:
	leaq	-60(%rbp), %rdx
	movl	$0, -52(%rbp)
	movq	$0, -60(%rbp)
	movw	$2, -64(%rbp)
	movbew	%ax, -62(%rbp)
	leaq	-128(%rbp), %rsi
	movl	$2, %edi
	callq	inet_pton@PLT
	cmpl	$1, %eax
	movl	$0, %eax
	jne	.LBB67_23
# %bb.20:
	movq	10472(%r13), %rbx
	movq	%r13, -48(%rbp)                 # 8-byte Spill
	testq	%rbx, %rbx
	jne	.LBB67_7
.LBB67_21:
	movq	%r14, %rdi
	incq	%rdi
	callq	malloc@PLT
	movq	%rax, %r12
	movl	$0, %eax
	testq	%r12, %r12
	movq	-48(%rbp), %r13                 # 8-byte Reload
	je	.LBB67_23
# %bb.22:
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
	movb	$0, (%r12,%r14)
	movq	%rbx, %rax
	shlq	$4, %rax
	movq	%r12, 10344(%r13,%rax)
	movq	%r14, 10352(%r13,%rax)
	incq	%rbx
	movq	%rbx, 10472(%r13)
	movl	$1, %eax
	jmp	.LBB67_23
.Lfunc_end67:
	.size	mylang_scoped_endpoint, .Lfunc_end67-mylang_scoped_endpoint
	.cfi_endproc
                                        # -- End function
	.section	.text.acquire_network,"ax",@progbits
	.p2align	4                               # -- Begin function acquire_network
	.type	acquire_network,@function
acquire_network:                        # @acquire_network
.Lfunc_begin68:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$232, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	10472(%rdi), %r12
	testq	%r12, %r12
	je	.LBB68_4
# %bb.1:
	testb	$3, %cl
	je	.LBB68_5
# %bb.2:
	movq	%rdx, %r13
	movl	$2, %eax
	cmpq	$127, %rdx
	ja	.LBB68_29
# %bb.6:
	movq	%rdi, %r14
	leaq	-272(%rbp), %rdi
	movq	%r13, %rdx
	callq	memcpy@PLT
	movb	$0, -272(%rbp,%r13)
	leaq	10344(%r14), %r15
	xorl	%ebx, %ebx
	jmp	.LBB68_8
	.p2align	4
.LBB68_7:                               #   in Loop: Header=BB68_8 Depth=1
	addq	$16, %r15
	decq	%r12
	je	.LBB68_28
.LBB68_8:                               # =>This Inner Loop Header: Depth=1
	movq	8(%r15), %rax
	cmpq	$1, %rax
	jne	.LBB68_10
# %bb.9:                                #   in Loop: Header=BB68_8 Depth=1
	movq	(%r15), %rcx
	cmpb	$42, (%rcx)
	je	.LBB68_12
.LBB68_10:                              #   in Loop: Header=BB68_8 Depth=1
	cmpq	%r13, %rax
	jne	.LBB68_7
# %bb.11:                               #   in Loop: Header=BB68_8 Depth=1
	movq	(%r15), %rdi
	leaq	-272(%rbp), %rsi
	movq	%r13, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB68_7
.LBB68_12:
	addq	$104, %r14
	xorl	%ebx, %ebx
	movl	$2, %eax
	jmp	.LBB68_14
	.p2align	4
.LBB68_13:                              #   in Loop: Header=BB68_14 Depth=1
	addq	$2, %rbx
	addq	$80, %r14
	cmpq	$256, %rbx                      # imm = 0x100
	je	.LBB68_29
.LBB68_14:                              # =>This Inner Loop Header: Depth=1
	cmpl	$0, (%r14)
	jns	.LBB68_16
# %bb.15:                               #   in Loop: Header=BB68_14 Depth=1
	cmpq	$0, 8(%r14)
	je	.LBB68_19
.LBB68_16:                              #   in Loop: Header=BB68_14 Depth=1
	cmpl	$0, 40(%r14)
	jns	.LBB68_13
# %bb.17:                               #   in Loop: Header=BB68_14 Depth=1
	cmpq	$0, 48(%r14)
	jne	.LBB68_13
# %bb.18:
	incq	%rbx
	addq	$40, %r14
.LBB68_19:
	leaq	-272(%rbp), %r12
	movq	%r12, %rdi
	movl	$58, %esi
	callq	strrchr@PLT
	movq	%rax, %r15
	subq	%r12, %r15
	sete	%cl
	testq	%rax, %rax
	je	.LBB68_27
# %bb.20:
	testb	%cl, %cl
	jne	.LBB68_27
# %bb.21:
	cmpq	$63, %r15
	ja	.LBB68_27
# %bb.22:
	leaq	-144(%rbp), %rdi
	leaq	-272(%rbp), %rsi
	movq	%r15, %rdx
	movq	%rax, %r12
	callq	memcpy@PLT
	movb	$0, -144(%rbp,%r15)
	incq	%r12
	movq	%r12, %rdi
	xorl	%esi, %esi
	movl	$10, %edx
	callq	strtoul@PLT
	leaq	-65536(%rax), %rcx
	cmpq	$-65535, %rcx                   # imm = 0xFFFF0001
	jb	.LBB68_27
# %bb.23:
	leaq	-52(%rbp), %rdx
	movl	$0, -44(%rbp)
	movq	$0, -52(%rbp)
	movw	$2, -56(%rbp)
	movbew	%ax, -54(%rbp)
	leaq	-144(%rbp), %rsi
	movl	$2, %edi
	callq	inet_pton@PLT
	cmpl	$1, %eax
	jne	.LBB68_27
# %bb.24:
	vmovups	-56(%rbp), %xmm0
	vmovaps	%xmm0, -80(%rbp)
	movl	$2, %edi
	movl	$1, %esi
	xorl	%edx, %edx
	callq	socket@PLT
	testl	%eax, %eax
	js	.LBB68_27
# %bb.25:
	movl	%eax, %r15d
	leaq	-80(%rbp), %rsi
	movl	%eax, %edi
	movl	$16, %edx
	callq	connect@PLT
	testl	%eax, %eax
	je	.LBB68_31
# %bb.26:
	movl	%r15d, %edi
	callq	close@PLT
.LBB68_27:
	movl	$3, %eax
	jmp	.LBB68_29
.LBB68_4:
	movl	$1, %eax
	jmp	.LBB68_29
.LBB68_5:
	movl	$2, %eax
.LBB68_29:
	xorl	%ebx, %ebx
.LBB68_30:
	movq	%rbx, %rdx
	addq	$232, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB68_28:
	.cfi_def_cfa %rbp, 16
	movl	$2, %eax
	jmp	.LBB68_30
.LBB68_31:
	movl	%r15d, (%r14)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 4(%r14)
	movl	$0, 36(%r14)
	xorl	%eax, %eax
	jmp	.LBB68_30
.Lfunc_end68:
	.size	acquire_network, .Lfunc_end68-acquire_network
	.cfi_endproc
                                        # -- End function
	.section	.text.complete,"ax",@progbits
	.p2align	4                               # -- Begin function complete
	.type	complete,@function
complete:                               # @complete
.Lfunc_begin69:
	.cfi_startproc
# %bb.0:
	movl	$3, %eax
	cmpq	$255, %rsi
	ja	.LBB69_6
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	leaq	(%rsi,%rsi,4), %rcx
	leaq	(%rdi,%rcx,8), %rbx
	addq	$104, %rbx
	movl	104(%rdi,%rcx,8), %edi
	testl	%edi, %edi
	js	.LBB69_2
# %bb.3:
	callq	close@PLT
	movq	8(%rbx), %rdi
	jmp	.LBB69_4
.LBB69_2:
	movq	8(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB69_5
.LBB69_4:
	callq	free@PLT
	movl	$-1, (%rbx)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 4(%rbx)
	movl	$0, 36(%rbx)
	xorl	%eax, %eax
.LBB69_5:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %rbp
.LBB69_6:
	vzeroupper
	retq
.Lfunc_end69:
	.size	complete, .Lfunc_end69-complete
	.cfi_endproc
                                        # -- End function
	.section	.text.release,"ax",@progbits
	.p2align	4                               # -- Begin function release
	.type	release,@function
release:                                # @release
.Lfunc_begin70:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	cmpq	$255, %rsi
	ja	.LBB70_5
# %bb.1:
	leaq	(%rsi,%rsi,4), %rax
	leaq	(%rdi,%rax,8), %rbx
	addq	$104, %rbx
	movl	104(%rdi,%rax,8), %edi
	testl	%edi, %edi
	js	.LBB70_2
# %bb.3:
	callq	close@PLT
	movq	8(%rbx), %rdi
	jmp	.LBB70_4
.LBB70_2:
	movq	8(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB70_5
.LBB70_4:
	callq	free@PLT
	movl	$-1, (%rbx)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 4(%rbx)
	movl	$0, 36(%rbx)
.LBB70_5:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.Lfunc_end70:
	.size	release, .Lfunc_end70-release
	.cfi_endproc
                                        # -- End function
	.section	.text.read_handle,"ax",@progbits
	.p2align	4                               # -- Begin function read_handle
	.type	read_handle,@function
read_handle:                            # @read_handle
.Lfunc_begin71:
	.cfi_startproc
# %bb.0:
	movq	%rdi, %rax
	vmovups	.L__const.read_handle.result(%rip), %xmm0
	vmovups	%xmm0, (%rdi)
	movq	$0, 16(%rdi)
	cmpq	$255, %rdx
	ja	.LBB71_18
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rsi,%rdx,8), %r15
	addq	$104, %r15
	movl	104(%rsi,%rdx,8), %edi
	testl	%edi, %edi
	jns	.LBB71_3
# %bb.2:
	cmpq	$0, 8(%r15)
	je	.LBB71_17
.LBB71_3:
	testq	%r8, %r8
	je	.LBB71_6
# %bb.4:
	movq	%rax, %r14
	cmpq	$65536, %r8                     # imm = 0x10000
	movl	$65536, %edx                    # imm = 0x10000
	cmovbq	%r8, %rdx
	movq	8(%r15), %rsi
	testq	%rsi, %rsi
	je	.LBB71_7
# %bb.5:
	movq	16(%r15), %rbx
	movq	24(%r15), %rax
	subq	%rax, %rbx
	cmpq	%rdx, %rbx
	cmovaeq	%rdx, %rbx
	addq	%rax, %rsi
	movq	%rcx, %rdi
	movq	%rbx, %rdx
	callq	memcpy@PLT
	movq	24(%r15), %rcx
	addq	%rbx, %rcx
	movq	%rcx, 24(%r15)
	movq	%r14, %rax
	movl	$0, (%r14)
	movq	%rbx, 8(%r14)
	xorl	%edx, %edx
	cmpq	16(%r15), %rcx
	sete	%dl
	movl	%edx, 16(%r14)
	jmp	.LBB71_17
.LBB71_6:
	movl	$0, (%rax)
	jmp	.LBB71_17
.LBB71_7:
	cmpb	$97, 32(%r15)
	jne	.LBB71_9
# %bb.8:
	movq	%r14, %rax
	movl	$2, (%r14)
	jmp	.LBB71_17
.LBB71_9:
	movq	%rcx, %rsi
	callq	read@PLT
	testq	%rax, %rax
	js	.LBB71_11
# %bb.10:
	movq	%rax, %rcx
	movq	%r14, %rax
	movl	$0, (%r14)
	movq	%rcx, 8(%r14)
	sete	%cl
	movzbl	%cl, %ecx
	movl	%ecx, 16(%r14)
	jmp	.LBB71_17
.LBB71_11:
	callq	__errno_location@PLT
	movl	(%rax), %edx
	cmpq	$40, %rdx
	movq	%r14, %rax
	ja	.LBB71_15
# %bb.12:
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rdx, %rcx
	jae	.LBB71_14
# %bb.13:
	movl	$2, %ecx
.LBB71_16:
	movl	%ecx, (%rax)
.LBB71_17:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
.LBB71_18:
	retq
.LBB71_14:
	.cfi_def_cfa %rbp, 16
	.cfi_offset %rbx, -40
	.cfi_offset %rbp, -16
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	$4, %ecx
	cmpq	$12, %rdx
	je	.LBB71_16
.LBB71_15:
	movl	$3, %ecx
	jmp	.LBB71_16
.Lfunc_end71:
	.size	read_handle, .Lfunc_end71-read_handle
	.cfi_endproc
                                        # -- End function
	.section	.text.write_handle,"ax",@progbits
	.p2align	4                               # -- Begin function write_handle
	.type	write_handle,@function
write_handle:                           # @write_handle
.Lfunc_begin72:
	.cfi_startproc
# %bb.0:
	movl	$3, %eax
	cmpq	$255, %rsi
	jbe	.LBB72_2
# %bb.1:
	xorl	%edx, %edx
	retq
.LBB72_2:
	movq	%rdi, %r8
	leaq	(%rsi,%rsi,4), %rax
	movl	104(%rdi,%rax,8), %edi
	movq	112(%r8,%rax,8), %rsi
	testl	%edi, %edi
	js	.LBB72_3
# %bb.5:
	testq	%rsi, %rsi
	je	.LBB72_7
# %bb.6:
	xorl	%edx, %edx
	movl	$2, %eax
	retq
.LBB72_3:
	xorl	%edx, %edx
	cmpq	$1, %rsi
	movl	$0, %eax
	adcl	$2, %eax
	retq
.LBB72_7:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	leaq	(%r8,%rax,8), %r15
	addq	$104, %r15
	cmpq	$65536, %rcx                    # imm = 0x10000
	movl	$65536, %ebx                    # imm = 0x10000
	cmovbq	%rcx, %rbx
	cmpb	$97, 32(%r15)
	jne	.LBB72_14
# %bb.8:
	movq	%rdx, %r14
	xorl	%esi, %esi
	movl	$2, %edx
	callq	lseek@PLT
	testq	%rax, %rax
	js	.LBB72_9
# %bb.13:
	movl	(%r15), %edi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	movq	%rax, %rcx
	callq	pwrite@PLT
	movq	%rax, %rdx
	xorl	%eax, %eax
	testq	%rdx, %rdx
	jns	.LBB72_22
	jmp	.LBB72_16
.LBB72_14:
	movq	%rdx, %rsi
	movq	%rbx, %rdx
	callq	write@PLT
	movq	%rax, %rdx
	xorl	%eax, %eax
	testq	%rdx, %rdx
	jns	.LBB72_22
.LBB72_16:
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	ja	.LBB72_19
# %bb.17:
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB72_11
# %bb.18:
	xorl	%edx, %edx
	movl	$2, %eax
	jmp	.LBB72_22
.LBB72_9:
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	ja	.LBB72_19
# %bb.10:
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB72_11
# %bb.20:
	movl	$2, %eax
	jmp	.LBB72_21
.LBB72_11:
	cmpq	$12, %rax
	jne	.LBB72_19
# %bb.12:
	movl	$4, %eax
.LBB72_21:
	xorl	%edx, %edx
	jmp	.LBB72_22
.LBB72_19:
	xorl	%edx, %edx
	movl	$3, %eax
.LBB72_22:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
	retq
.Lfunc_end72:
	.size	write_handle, .Lfunc_end72-write_handle
	.cfi_endproc
                                        # -- End function
	.section	.text.acquire,"ax",@progbits
	.p2align	4                               # -- Begin function acquire
	.type	acquire,@function
acquire:                                # @acquire
.Lfunc_begin73:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$4424, %rsp                     # imm = 0x1148
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	cmpq	$0, 96(%rdi)
	je	.LBB73_6
# %bb.1:
	movq	%rdx, %r8
	leaq	-4097(%rdx), %rax
	movl	$2, %r9d
	cmpq	$-4095, %rax                    # imm = 0xF001
	jb	.LBB73_7
# %bb.2:
	movq	%rsi, %r13
	cmpb	$58, 1(%rsi)
	jne	.LBB73_7
# %bb.3:
	movzbl	(%r13), %eax
	movb	%al, -41(%rbp)                  # 1-byte Spill
	movzbl	%al, %eax
	xorl	%ebx, %ebx
	leal	-97(%rax), %r12d
	cmpl	$23, %r12d
	ja	.LBB73_8
# %bb.4:
	movq	%rdi, %r14
	movq	%rax, -176(%rbp)                # 8-byte Spill
	movl	$13108229, %eax                 # imm = 0xC80405
	btl	%r12d, %eax
	jae	.LBB73_9
# %bb.5:
	movl	$2, %eax
	jmp	.LBB73_10
.LBB73_6:
	movl	$1, %r9d
.LBB73_7:
	xorl	%ebx, %ebx
.LBB73_8:
	movl	%r9d, %eax
	movq	%rbx, %rdx
	addq	$4424, %rsp                     # imm = 0x1148
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB73_9:
	.cfi_def_cfa %rbp, 16
	movl	$1, %eax
	movl	$137216, %edx                   # imm = 0x21800
	btl	%r12d, %edx
	jae	.LBB73_8
.LBB73_10:
	testl	%ecx, %eax
	je	.LBB73_7
# %bb.11:
	addq	$2, %r13
	leaq	-2(%r8), %rdx
	movq	-176(%rbp), %rax                # 8-byte Reload
	movl	%eax, %ecx
	andb	$-2, %cl
	movb	%cl, -97(%rbp)                  # 1-byte Spill
	leaq	104(%r14), %rcx
	movq	%rcx, -216(%rbp)                # 8-byte Spill
	xorl	%ecx, %ecx
	cmpb	$114, %al
	setne	%cl
	movl	%ecx, -148(%rbp)                # 4-byte Spill
	decq	%r8
	addl	$-107, %eax
	movq	%rax, -208(%rbp)                # 8-byte Spill
	movl	$13108229, %r15d                # imm = 0xC80405
	xorl	%ecx, %ecx
	movq	%r13, -96(%rbp)                 # 8-byte Spill
	movq	%rdx, -56(%rbp)                 # 8-byte Spill
	movq	%r8, -200(%rbp)                 # 8-byte Spill
	movq	%r14, -120(%rbp)                # 8-byte Spill
	movl	%r12d, -60(%rbp)                # 4-byte Spill
	jmp	.LBB73_14
	.p2align	4
.LBB73_12:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	movl	-60(%rbp), %r12d                # 4-byte Reload
.LBB73_13:                              #   in Loop: Header=BB73_14 Depth=1
	movq	-224(%rbp), %rcx                # 8-byte Reload
	incq	%rcx
	cmpq	96(%r14), %rcx
	jae	.LBB73_7
.LBB73_14:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB73_64 Depth 2
                                        #     Child Loop BB73_20 Depth 2
                                        #     Child Loop BB73_31 Depth 2
                                        #     Child Loop BB73_82 Depth 2
                                        #       Child Loop BB73_83 Depth 3
                                        #       Child Loop BB73_93 Depth 3
	cmpl	$23, %r12d
	movq	%rcx, -224(%rbp)                # 8-byte Spill
	ja	.LBB73_17
# %bb.15:                               #   in Loop: Header=BB73_14 Depth=1
	btl	%r12d, %r15d
	jae	.LBB73_17
# %bb.16:                               #   in Loop: Header=BB73_14 Depth=1
	leaq	(%rcx,%rcx,2), %rax
	cmpl	$0, 4(%r14,%rax,4)
	je	.LBB73_13
.LBB73_17:                              #   in Loop: Header=BB73_14 Depth=1
	leaq	(%rcx,%rcx,2), %rbx
	movl	8(%r14,%rbx,4), %eax
	movl	%eax, -128(%rbp)                # 4-byte Spill
	testl	%eax, %eax
	je	.LBB73_35
.LBB73_18:                              #   in Loop: Header=BB73_14 Depth=1
	leaq	(%r14,%rbx,4), %rax
	movl	(%rax), %eax
	movl	%eax, -76(%rbp)                 # 4-byte Spill
	movq	-216(%rbp), %r12                # 8-byte Reload
	xorl	%ebx, %ebx
	jmp	.LBB73_20
	.p2align	4
.LBB73_19:                              #   in Loop: Header=BB73_20 Depth=2
	addq	$2, %rbx
	addq	$80, %r12
	cmpq	$256, %rbx                      # imm = 0x100
	je	.LBB73_12
.LBB73_20:                              #   Parent Loop BB73_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpl	$0, (%r12)
	jns	.LBB73_22
# %bb.21:                               #   in Loop: Header=BB73_20 Depth=2
	cmpq	$0, 8(%r12)
	je	.LBB73_25
.LBB73_22:                              #   in Loop: Header=BB73_20 Depth=2
	cmpl	$0, 40(%r12)
	jns	.LBB73_19
# %bb.23:                               #   in Loop: Header=BB73_20 Depth=2
	cmpq	$0, 48(%r12)
	jne	.LBB73_19
# %bb.24:                               #   in Loop: Header=BB73_14 Depth=1
	incq	%rbx
	addq	$40, %r12
.LBB73_25:                              #   in Loop: Header=BB73_14 Depth=1
	testq	%rdx, %rdx
	je	.LBB73_41
# %bb.26:                               #   in Loop: Header=BB73_14 Depth=1
	movl	$0, %r14d
	movl	-76(%rbp), %eax                 # 4-byte Reload
	movl	%eax, -72(%rbp)                 # 4-byte Spill
	cmpl	$0, -128(%rbp)                  # 4-byte Folded Reload
	jne	.LBB73_42
# %bb.27:                               #   in Loop: Header=BB73_14 Depth=1
	xorl	%r15d, %r15d
	movl	-76(%rbp), %eax                 # 4-byte Reload
	movl	%eax, -72(%rbp)                 # 4-byte Spill
	xorl	%r14d, %r14d
	jmp	.LBB73_31
	.p2align	4
.LBB73_28:                              #   in Loop: Header=BB73_31 Depth=2
	testl	%r13d, %r13d
	js	.LBB73_56
# %bb.29:                               #   in Loop: Header=BB73_31 Depth=2
	leaq	1(%r15), %r14
	movl	%r13d, -72(%rbp)                # 4-byte Spill
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movq	-56(%rbp), %rdx                 # 8-byte Reload
.LBB73_30:                              #   in Loop: Header=BB73_31 Depth=2
	incq	%r15
	cmpq	%r15, %rdx
	je	.LBB73_42
.LBB73_31:                              #   Parent Loop BB73_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpb	$47, (%r13,%r15)
	jne	.LBB73_30
# %bb.32:                               #   in Loop: Header=BB73_31 Depth=2
	movq	%r15, %rdx
	subq	%r14, %rdx
	cmpq	$4094, %rdx                     # imm = 0xFFE
	ja	.LBB73_54
# %bb.33:                               #   in Loop: Header=BB73_31 Depth=2
	leaq	(%r14,%r13), %rsi
	leaq	-4464(%rbp), %r13
	movq	%r13, %rdi
	callq	memcpy@PLT
	movq	%r13, %rax
	subq	%r14, %rax
	movb	$0, (%rax,%r15)
	movl	-72(%rbp), %r14d                # 4-byte Reload
	movl	%r14d, %edi
	movq	%r13, %rsi
	movl	$720896, %edx                   # imm = 0xB0000
	xorl	%eax, %eax
	callq	openat@PLT
	movl	%eax, %r13d
	cmpl	-76(%rbp), %r14d                # 4-byte Folded Reload
	je	.LBB73_28
# %bb.34:                               #   in Loop: Header=BB73_31 Depth=2
	movl	%r14d, %edi
	callq	close@PLT
	jmp	.LBB73_28
	.p2align	4
.LBB73_35:                              #   in Loop: Header=BB73_14 Depth=1
	testq	%rdx, %rdx
	je	.LBB73_38
# %bb.36:                               #   in Loop: Header=BB73_14 Depth=1
	movl	%r9d, -88(%rbp)                 # 4-byte Spill
	movq	%r13, %rdi
	movl	$92, %esi
	movq	%rdx, %r15
	callq	memchr@PLT
	testq	%rax, %rax
	je	.LBB73_39
# %bb.37:                               #   in Loop: Header=BB73_14 Depth=1
	movq	%r15, %rdx
	movl	$13108229, %r15d                # imm = 0xC80405
	movl	-88(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB73_13
.LBB73_38:                              #   in Loop: Header=BB73_14 Depth=1
	cmpb	$108, -97(%rbp)                 # 1-byte Folded Reload
	jne	.LBB73_13
	jmp	.LBB73_18
.LBB73_39:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%r13, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	memchr@PLT
	testq	%rax, %rax
	je	.LBB73_61
# %bb.40:                               #   in Loop: Header=BB73_14 Depth=1
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movl	$13108229, %r15d                # imm = 0xC80405
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movl	-88(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB73_13
.LBB73_41:                              #   in Loop: Header=BB73_14 Depth=1
	xorl	%r14d, %r14d
	movl	-76(%rbp), %eax                 # 4-byte Reload
	movl	%eax, -72(%rbp)                 # 4-byte Spill
.LBB73_42:                              #   in Loop: Header=BB73_14 Depth=1
	cmpl	$0, -72(%rbp)                   # 4-byte Folded Reload
	js	.LBB73_57
# %bb.43:                               #   in Loop: Header=BB73_14 Depth=1
	movq	%rdx, %r13
	subq	%r14, %r13
	cmpq	$4095, %r13                     # imm = 0xFFF
	movl	$13108229, %r15d                # imm = 0xC80405
	jb	.LBB73_47
# %bb.44:                               #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	movl	-72(%rbp), %edi                 # 4-byte Reload
	cmpl	-76(%rbp), %edi                 # 4-byte Folded Reload
	movq	-120(%rbp), %r14                # 8-byte Reload
	movl	-60(%rbp), %r12d                # 4-byte Reload
	je	.LBB73_46
# %bb.45:                               #   in Loop: Header=BB73_14 Depth=1
	callq	close@PLT
	movl	$2, %r9d
	movq	-56(%rbp), %rdx                 # 8-byte Reload
.LBB73_46:                              #   in Loop: Header=BB73_14 Depth=1
	movq	-96(%rbp), %r13                 # 8-byte Reload
	jmp	.LBB73_13
.LBB73_47:                              #   in Loop: Header=BB73_14 Depth=1
	addq	-96(%rbp), %r14                 # 8-byte Folded Reload
	leaq	-4464(%rbp), %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	memcpy@PLT
	movb	$0, -4464(%rbp,%r13)
	movq	-208(%rbp), %rax                # 8-byte Reload
	cmpl	$13, %eax
	ja	.LBB73_108
# %bb.48:                               #   in Loop: Header=BB73_14 Depth=1
	jmpq	*.LJTI73_0(,%rax,8)
.LBB73_49:                              #   in Loop: Header=BB73_14 Depth=1
	movzbl	-4464(%rbp), %eax
	cmpb	$109, -41(%rbp)                 # 1-byte Folded Reload
	jne	.LBB73_72
# %bb.50:                               #   in Loop: Header=BB73_14 Depth=1
	testb	%al, %al
	movq	-96(%rbp), %r13                 # 8-byte Reload
	je	.LBB73_111
# %bb.51:                               #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	leaq	-368(%rbp), %rdx
	movl	$256, %ecx                      # imm = 0x100
	callq	fstatat@PLT
	testl	%eax, %eax
	je	.LBB73_112
.LBB73_52:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_164
# %bb.53:                               #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jb	.LBB73_128
	jmp	.LBB73_163
.LBB73_54:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	$36, (%rax)
	movl	-72(%rbp), %edi                 # 4-byte Reload
	cmpl	-76(%rbp), %edi                 # 4-byte Folded Reload
	je	.LBB73_57
# %bb.55:                               #   in Loop: Header=BB73_14 Depth=1
	callq	close@PLT
	jmp	.LBB73_57
.LBB73_56:                              #   in Loop: Header=BB73_14 Depth=1
	movq	-96(%rbp), %r13                 # 8-byte Reload
.LBB73_57:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movl	(%rax), %eax
	cmpq	$40, %rax
	movq	-120(%rbp), %r14                # 8-byte Reload
	movl	-60(%rbp), %r12d                # 4-byte Reload
	movl	$13108229, %r15d                # imm = 0xC80405
	ja	.LBB73_60
# %bb.58:                               #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jb	.LBB73_13
# %bb.59:                               #   in Loop: Header=BB73_14 Depth=1
	cmpq	$12, %rax
	je	.LBB73_143
.LBB73_60:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$3, %r9d
	jmp	.LBB73_13
.LBB73_61:                              #   in Loop: Header=BB73_14 Depth=1
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movl	$13108229, %r15d                # imm = 0xC80405
	movq	-200(%rbp), %r8                 # 8-byte Reload
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movl	-88(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB73_64
	.p2align	4
.LBB73_62:                              #   in Loop: Header=BB73_64 Depth=2
	leaq	1(%rax), %rcx
.LBB73_63:                              #   in Loop: Header=BB73_64 Depth=2
	incq	%rax
	cmpq	%rax, %r8
	je	.LBB73_18
.LBB73_64:                              #   Parent Loop BB73_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpq	%rax, %rdx
	je	.LBB73_66
# %bb.65:                               #   in Loop: Header=BB73_64 Depth=2
	cmpb	$47, (%r13,%rax)
	jne	.LBB73_63
.LBB73_66:                              #   in Loop: Header=BB73_64 Depth=2
	movq	%rax, %rsi
	subq	%rcx, %rsi
	je	.LBB73_13
# %bb.67:                               #   in Loop: Header=BB73_64 Depth=2
	cmpq	$2, %rsi
	je	.LBB73_70
# %bb.68:                               #   in Loop: Header=BB73_64 Depth=2
	cmpq	$1, %rsi
	jne	.LBB73_62
# %bb.69:                               #   in Loop: Header=BB73_64 Depth=2
	cmpb	$46, (%r13,%rcx)
	jne	.LBB73_62
	jmp	.LBB73_13
	.p2align	4
.LBB73_70:                              #   in Loop: Header=BB73_64 Depth=2
	cmpb	$46, (%r13,%rcx)
	jne	.LBB73_62
# %bb.71:                               #   in Loop: Header=BB73_64 Depth=2
	cmpb	$46, 1(%r13,%rcx)
	jne	.LBB73_62
	jmp	.LBB73_13
.LBB73_72:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	testb	%al, %al
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	je	.LBB73_174
# %bb.73:                               #   in Loop: Header=BB73_14 Depth=1
	cmpb	$107, -41(%rbp)                 # 1-byte Folded Reload
	jne	.LBB73_117
# %bb.74:                               #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	movl	$511, %edx                      # imm = 0x1FF
	callq	mkdirat@PLT
	testl	%eax, %eax
	je	.LBB73_124
# %bb.75:                               #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_164
# %bb.76:                               #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jb	.LBB73_144
	jmp	.LBB73_163
.LBB73_78:                              #   in Loop: Header=BB73_14 Depth=1
	cmpb	$0, -4464(%rbp)
	leaq	-4464(%rbp), %rsi
	movl	$.L.str.192, %eax
	cmoveq	%rax, %rsi
	movl	-72(%rbp), %edi                 # 4-byte Reload
	movl	$720896, %edx                   # imm = 0xB0000
	xorl	%eax, %eax
	callq	openat@PLT
	testl	%eax, %eax
	js	.LBB73_126
# %bb.79:                               #   in Loop: Header=BB73_14 Depth=1
	movl	%eax, %r14d
	movl	%eax, %edi
	callq	fdopendir@PLT
	movq	%rax, -128(%rbp)                # 8-byte Spill
	testq	%rax, %rax
	movq	-96(%rbp), %r13                 # 8-byte Reload
	je	.LBB73_145
# %bb.80:                               #   in Loop: Header=BB73_14 Depth=1
	movl	$1024, %edi                     # imm = 0x400
	callq	malloc@PLT
	testq	%rax, %rax
	je	.LBB73_158
# %bb.81:                               #   in Loop: Header=BB73_14 Depth=1
	movq	%rax, %r14
	movb	$1, (%rax)
	movl	$1, %r13d
	movl	$1024, %eax                     # imm = 0x400
	movq	%rax, -160(%rbp)                # 8-byte Spill
	callq	__errno_location@PLT
	movq	%rax, -88(%rbp)                 # 8-byte Spill
	movq	$0, -168(%rbp)                  # 8-byte Folded Spill
.LBB73_82:                              #   Parent Loop BB73_14 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB73_83 Depth 3
                                        #       Child Loop BB73_93 Depth 3
	movq	%r13, -144(%rbp)                # 8-byte Spill
	movq	-96(%rbp), %r13                 # 8-byte Reload
.LBB73_83:                              #   Parent Loop BB73_14 Depth=1
                                        #     Parent Loop BB73_82 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	-88(%rbp), %rax                 # 8-byte Reload
	movl	$0, (%rax)
	movq	-128(%rbp), %rdi                # 8-byte Reload
	callq	readdir@PLT
	testq	%rax, %rax
	je	.LBB73_159
# %bb.84:                               #   in Loop: Header=BB73_83 Depth=3
	cmpb	$46, 19(%rax)
	jne	.LBB73_88
# %bb.85:                               #   in Loop: Header=BB73_83 Depth=3
	movzbl	20(%rax), %ecx
	testl	%ecx, %ecx
	je	.LBB73_83
# %bb.86:                               #   in Loop: Header=BB73_83 Depth=3
	cmpl	$46, %ecx
	jne	.LBB73_88
# %bb.87:                               #   in Loop: Header=BB73_83 Depth=3
	cmpb	$0, 21(%rax)
	je	.LBB73_83
.LBB73_88:                              #   in Loop: Header=BB73_82 Depth=2
	addq	$19, %rax
	movq	%rax, -136(%rbp)                # 8-byte Spill
	movq	%rax, %rdi
	callq	strlen@PLT
	movq	-144(%rbp), %rdx                # 8-byte Reload
	cmpq	$65536, %rdx                    # imm = 0x10000
	ja	.LBB73_186
# %bb.89:                               #   in Loop: Header=BB73_82 Depth=2
	cmpq	$255, -168(%rbp)                # 8-byte Folded Reload
	ja	.LBB73_186
# %bb.90:                               #   in Loop: Header=BB73_82 Depth=2
	leaq	-4095(%rax), %rcx
	cmpq	$-4094, %rcx                    # imm = 0xF002
	jb	.LBB73_186
# %bb.91:                               #   in Loop: Header=BB73_82 Depth=2
	leaq	3(%rax), %rsi
	movl	$65536, %ecx                    # imm = 0x10000
	subq	%rdx, %rcx
	cmpq	%rcx, %rsi
	ja	.LBB73_186
# %bb.92:                               #   in Loop: Header=BB73_82 Depth=2
	leaq	3(%rdx), %rcx
	movq	%rcx, -184(%rbp)                # 8-byte Spill
	movq	%rax, -192(%rbp)                # 8-byte Spill
	addq	%rdx, %rax
	addq	$3, %rax
	movq	%rax, -112(%rbp)                # 8-byte Spill
	movq	%r14, %rax
	movq	-160(%rbp), %r13                # 8-byte Reload
.LBB73_93:                              #   Parent Loop BB73_14 Depth=1
                                        #     Parent Loop BB73_82 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%rax, %r14
	cmpq	%r13, -112(%rbp)                # 8-byte Folded Reload
	jbe	.LBB73_98
# %bb.94:                               #   in Loop: Header=BB73_93 Depth=3
	addq	%r13, %r13
	movq	%r14, %rdi
	movq	%r13, %rsi
	callq	realloc@PLT
	testq	%rax, %rax
	jne	.LBB73_93
	jmp	.LBB73_95
.LBB73_98:                              #   in Loop: Header=BB73_82 Depth=2
	movq	%r13, -160(%rbp)                # 8-byte Spill
	movq	-128(%rbp), %rdi                # 8-byte Reload
	callq	dirfd@PLT
	movl	%eax, %edi
	movq	-136(%rbp), %rsi                # 8-byte Reload
	leaq	-368(%rbp), %rdx
	movl	$256, %ecx                      # imm = 0x100
	callq	fstatat@PLT
	testl	%eax, %eax
	je	.LBB73_101
# %bb.99:                               #   in Loop: Header=BB73_82 Depth=2
	xorl	%eax, %eax
	movq	-136(%rbp), %rsi                # 8-byte Reload
	movq	-112(%rbp), %r13                # 8-byte Reload
.LBB73_100:                             #   in Loop: Header=BB73_82 Depth=2
	movq	-144(%rbp), %rcx                # 8-byte Reload
	movb	%al, (%r14,%rcx)
	movq	-192(%rbp), %rdx                # 8-byte Reload
	movw	%dx, 1(%r14,%rcx)
	movq	-184(%rbp), %rdi                # 8-byte Reload
	addq	%r14, %rdi
	callq	memcpy@PLT
	incq	-168(%rbp)                      # 8-byte Folded Spill
	jmp	.LBB73_82
.LBB73_101:                             #   in Loop: Header=BB73_82 Depth=2
	movl	-344(%rbp), %eax
	movl	$61440, %ecx                    # imm = 0xF000
	andl	%ecx, %eax
	cmpl	$40960, %eax                    # imm = 0xA000
	movq	-112(%rbp), %r13                # 8-byte Reload
	je	.LBB73_106
# %bb.102:                              #   in Loop: Header=BB73_82 Depth=2
	cmpl	$32768, %eax                    # imm = 0x8000
	movq	-136(%rbp), %rsi                # 8-byte Reload
	je	.LBB73_105
# %bb.103:                              #   in Loop: Header=BB73_82 Depth=2
	cmpl	$16384, %eax                    # imm = 0x4000
	jne	.LBB73_107
# %bb.104:                              #   in Loop: Header=BB73_82 Depth=2
	movb	$2, %al
	jmp	.LBB73_100
.LBB73_105:                             #   in Loop: Header=BB73_82 Depth=2
	movb	$1, %al
	jmp	.LBB73_100
.LBB73_106:                             #   in Loop: Header=BB73_82 Depth=2
	movb	$3, %al
	movq	-136(%rbp), %rsi                # 8-byte Reload
	jmp	.LBB73_100
.LBB73_107:                             #   in Loop: Header=BB73_82 Depth=2
	xorl	%eax, %eax
	jmp	.LBB73_100
.LBB73_108:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%edx, %edx
	cmpl	$0, -128(%rbp)                  # 4-byte Folded Reload
	sete	%dl
	shll	$11, %edx
	movq	-176(%rbp), %rax                # 8-byte Reload
	cmpl	$97, %eax
	je	.LBB73_130
# %bb.109:                              #   in Loop: Header=BB73_14 Depth=1
	cmpl	$99, %eax
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movq	-120(%rbp), %r14                # 8-byte Reload
	jne	.LBB73_131
# %bb.110:                              #   in Loop: Header=BB73_14 Depth=1
	orl	$524481, %edx                   # imm = 0x800C1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	movl	$438, %ecx                      # imm = 0x1B6
	xorl	%eax, %eax
	callq	openat@PLT
	jmp	.LBB73_132
.LBB73_111:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-368(%rbp), %rsi
	callq	fstat@PLT
	testl	%eax, %eax
	jne	.LBB73_52
.LBB73_112:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$10, %edi
	callq	malloc@PLT
	testq	%rax, %rax
	je	.LBB73_129
# %bb.113:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%rax, %r14
	movb	$1, (%rax)
	movl	-344(%rbp), %eax
	movl	$61440, %ecx                    # imm = 0xF000
	andl	%ecx, %eax
	cmpl	$40960, %eax                    # imm = 0xA000
	je	.LBB73_166
# %bb.114:                              #   in Loop: Header=BB73_14 Depth=1
	cmpl	$32768, %eax                    # imm = 0x8000
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	je	.LBB73_165
# %bb.115:                              #   in Loop: Header=BB73_14 Depth=1
	cmpl	$16384, %eax                    # imm = 0x4000
	jne	.LBB73_167
# %bb.116:                              #   in Loop: Header=BB73_14 Depth=1
	movb	$2, %al
	jmp	.LBB73_168
.LBB73_117:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	xorl	%edx, %edx
	callq	unlinkat@PLT
	testl	%eax, %eax
	je	.LBB73_124
# %bb.118:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %ecx
	cmpq	$40, %rcx
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_164
# %bb.119:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684544, %rsi            # imm = 0x10000102000
	btq	%rcx, %rsi
	jb	.LBB73_144
# %bb.120:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2097154, %esi                  # imm = 0x200002
	btq	%rcx, %rsi
	jae	.LBB73_172
# %bb.121:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%rax, %r14
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	movl	$512, %edx                      # imm = 0x200
	callq	unlinkat@PLT
	testl	%eax, %eax
	je	.LBB73_124
# %bb.122:                              #   in Loop: Header=BB73_14 Depth=1
	movl	(%r14), %eax
	cmpq	$40, %rax
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_164
# %bb.123:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	movl	$2, %r9d
	jb	.LBB73_174
	jmp	.LBB73_163
.LBB73_124:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$1, %edi
	callq	malloc@PLT
	testq	%rax, %rax
	je	.LBB73_129
# %bb.125:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%rax, %r14
	movb	$1, (%rax)
	movl	$1, %ecx
	xorl	%r9d, %r9d
	jmp	.LBB73_150
.LBB73_126:                             #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_164
# %bb.127:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB73_163
.LBB73_128:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	jmp	.LBB73_174
.LBB73_163:                             #   in Loop: Header=BB73_14 Depth=1
	cmpq	$12, %rax
	jne	.LBB73_164
.LBB73_173:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, %r9d
	jmp	.LBB73_174
.LBB73_129:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, %r9d
	jmp	.LBB73_149
.LBB73_130:                             #   in Loop: Header=BB73_14 Depth=1
	orl	$524353, %edx                   # imm = 0x80041
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	movl	$438, %ecx                      # imm = 0x1B6
	xorl	%eax, %eax
	callq	openat@PLT
	movq	-96(%rbp), %r13                 # 8-byte Reload
	movq	-120(%rbp), %r14                # 8-byte Reload
	jmp	.LBB73_132
.LBB73_131:                             #   in Loop: Header=BB73_14 Depth=1
	cmpl	$0, -128(%rbp)                  # 4-byte Folded Reload
	movl	$657408, %edx                   # imm = 0xA0800
	movl	$524288, %eax                   # imm = 0x80000
	cmovnel	%eax, %edx
	addl	-148(%rbp), %edx                # 4-byte Folded Reload
	movl	-72(%rbp), %edi                 # 4-byte Reload
	leaq	-4464(%rbp), %rsi
	xorl	%eax, %eax
	callq	openat@PLT
.LBB73_132:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	cmpl	-76(%rbp), %edi                 # 4-byte Folded Reload
	movl	%eax, -112(%rbp)                # 4-byte Spill
	je	.LBB73_134
# %bb.133:                              #   in Loop: Header=BB73_14 Depth=1
	callq	close@PLT
	movl	-112(%rbp), %eax                # 4-byte Reload
.LBB73_134:                             #   in Loop: Header=BB73_14 Depth=1
	testl	%eax, %eax
	js	.LBB73_140
# %bb.135:                              #   in Loop: Header=BB73_14 Depth=1
	movl	%eax, %edi
	leaq	-368(%rbp), %rsi
	callq	fstat@PLT
	testl	%eax, %eax
	je	.LBB73_151
# %bb.136:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movl	-60(%rbp), %r12d                # 4-byte Reload
	movl	-112(%rbp), %edi                # 4-byte Reload
	ja	.LBB73_162
# %bb.137:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB73_161
# %bb.138:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %ecx
.LBB73_139:                             #   in Loop: Header=BB73_14 Depth=1
	movl	%ecx, %ebx
	callq	close@PLT
	movl	%ebx, %r9d
	xorl	%ebx, %ebx
	jmp	.LBB73_171
.LBB73_140:                             #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movl	-60(%rbp), %r12d                # 4-byte Reload
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	ja	.LBB73_60
# %bb.141:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %r9d
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jb	.LBB73_13
# %bb.142:                              #   in Loop: Header=BB73_14 Depth=1
	cmpq	$12, %rax
	jne	.LBB73_60
	jmp	.LBB73_143
.LBB73_144:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
	movl	$2, %r9d
	jmp	.LBB73_175
.LBB73_145:                             #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	ja	.LBB73_183
# %bb.146:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB73_182
# %bb.147:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, %ecx
.LBB73_148:                             #   in Loop: Header=BB73_14 Depth=1
	movl	%r14d, %edi
	movl	%ecx, %r14d
	callq	close@PLT
	movl	%r14d, %r9d
.LBB73_149:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
.LBB73_150:                             #   in Loop: Header=BB73_14 Depth=1
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	jmp	.LBB73_175
.LBB73_151:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-344(%rbp), %r14d
	movl	-128(%rbp), %edi                # 4-byte Reload
	movl	-112(%rbp), %esi                # 4-byte Reload
	movl	%r14d, %edx
	callq	usable
	testl	%eax, %eax
	je	.LBB73_169
# %bb.152:                              #   in Loop: Header=BB73_14 Depth=1
	cmpb	$116, -41(%rbp)                 # 1-byte Folded Reload
	sete	%al
	andl	$61440, %r14d                   # imm = 0xF000
	cmpl	$32768, %r14d                   # imm = 0x8000
	sete	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB73_160
# %bb.153:                              #   in Loop: Header=BB73_14 Depth=1
	movl	-112(%rbp), %edi                # 4-byte Reload
	xorl	%esi, %esi
	callq	ftruncate@PLT
	testl	%eax, %eax
	je	.LBB73_160
# %bb.154:                              #   in Loop: Header=BB73_14 Depth=1
	callq	__errno_location@PLT
	movl	(%rax), %eax
	cmpq	$40, %rax
	movq	-120(%rbp), %r14                # 8-byte Reload
	movl	-60(%rbp), %r12d                # 4-byte Reload
	movl	-112(%rbp), %edi                # 4-byte Reload
	ja	.LBB73_185
# %bb.155:                              #   in Loop: Header=BB73_14 Depth=1
	movabsq	$1099512684546, %rcx            # imm = 0x10000102002
	btq	%rax, %rcx
	jae	.LBB73_184
# %bb.156:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$2, -88(%rbp)                   # 4-byte Folded Spill
.LBB73_157:                             #   in Loop: Header=BB73_14 Depth=1
	callq	close@PLT
	xorl	%ebx, %ebx
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movl	-88(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB73_181
.LBB73_158:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, -88(%rbp)                   # 4-byte Folded Spill
	jmp	.LBB73_97
.LBB73_159:                             #   in Loop: Header=BB73_14 Depth=1
	movq	-128(%rbp), %rdi                # 8-byte Reload
	callq	closedir@PLT
	xorl	%r9d, %r9d
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movq	-144(%rbp), %rcx                # 8-byte Reload
	jmp	.LBB73_175
.LBB73_95:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$4, -88(%rbp)                   # 4-byte Folded Spill
	movq	-96(%rbp), %r13                 # 8-byte Reload
.LBB73_96:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%r14, %rdi
	callq	free@PLT
.LBB73_97:                              #   in Loop: Header=BB73_14 Depth=1
	movq	-128(%rbp), %rdi                # 8-byte Reload
	callq	closedir@PLT
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movl	-88(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB73_175
.LBB73_160:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-112(%rbp), %eax                # 4-byte Reload
	movl	%eax, (%r12)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 4(%r12)
	vmovups	%xmm0, 16(%r12)
	movzbl	-41(%rbp), %eax                 # 1-byte Folded Reload
	movb	%al, 32(%r12)
	movl	$0, 33(%r12)
	movl	$0, 36(%r12)
	xorl	%r9d, %r9d
	jmp	.LBB73_170
.LBB73_161:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, %ecx
	cmpq	$12, %rax
	je	.LBB73_139
.LBB73_162:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$3, %ecx
	jmp	.LBB73_139
.LBB73_165:                             #   in Loop: Header=BB73_14 Depth=1
	movb	$1, %al
	jmp	.LBB73_168
.LBB73_166:                             #   in Loop: Header=BB73_14 Depth=1
	movb	$3, %al
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	jmp	.LBB73_168
.LBB73_167:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%eax, %eax
.LBB73_168:                             #   in Loop: Header=BB73_14 Depth=1
	movb	%al, 1(%r14)
	movq	-320(%rbp), %rax
	movq	%rax, 2(%r14)
	movl	$10, %ecx
	xorl	%r9d, %r9d
	jmp	.LBB73_175
.LBB73_169:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-112(%rbp), %edi                # 4-byte Reload
	callq	close@PLT
	movl	$2, %r9d
	xorl	%ebx, %ebx
.LBB73_170:                             #   in Loop: Header=BB73_14 Depth=1
	movq	-120(%rbp), %r14                # 8-byte Reload
	movl	-60(%rbp), %r12d                # 4-byte Reload
.LBB73_171:                             #   in Loop: Header=BB73_14 Depth=1
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	jmp	.LBB73_181
.LBB73_172:                             #   in Loop: Header=BB73_14 Depth=1
	cmpq	$12, %rcx
	je	.LBB73_173
.LBB73_164:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$3, %r9d
.LBB73_174:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%ecx, %ecx
	xorl	%r14d, %r14d
.LBB73_175:                             #   in Loop: Header=BB73_14 Depth=1
	movl	-72(%rbp), %edi                 # 4-byte Reload
	cmpl	-76(%rbp), %edi                 # 4-byte Folded Reload
	je	.LBB73_177
# %bb.176:                              #   in Loop: Header=BB73_14 Depth=1
	movq	%r14, -72(%rbp)                 # 8-byte Spill
	movl	%r9d, %r14d
	movq	%rcx, %r15
	callq	close@PLT
	movq	%r15, %rcx
	movl	%r14d, %r9d
	movq	-72(%rbp), %r14                 # 8-byte Reload
	movl	$13108229, %r15d                # imm = 0xC80405
	movq	-56(%rbp), %rdx                 # 8-byte Reload
.LBB73_177:                             #   in Loop: Header=BB73_14 Depth=1
	testq	%r14, %r14
	je	.LBB73_179
# %bb.178:                              #   in Loop: Header=BB73_14 Depth=1
	movl	$4294967295, %eax               # imm = 0xFFFFFFFF
	movq	%rax, (%r12)
	movq	%r14, 8(%r12)
	movq	%rcx, 16(%r12)
	movq	$0, 24(%r12)
	movzbl	-41(%rbp), %eax                 # 1-byte Folded Reload
	movb	%al, 32(%r12)
	movl	$0, 33(%r12)
	movl	$0, 36(%r12)
	jmp	.LBB73_180
.LBB73_179:                             #   in Loop: Header=BB73_14 Depth=1
	xorl	%ebx, %ebx
.LBB73_180:                             #   in Loop: Header=BB73_14 Depth=1
	movq	-120(%rbp), %r14                # 8-byte Reload
	movl	-60(%rbp), %r12d                # 4-byte Reload
.LBB73_181:                             #   in Loop: Header=BB73_14 Depth=1
	testb	$3, %r9b
	jne	.LBB73_13
	jmp	.LBB73_8
.LBB73_182:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, %ecx
	cmpq	$12, %rax
	je	.LBB73_148
.LBB73_183:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$3, %ecx
	jmp	.LBB73_148
.LBB73_186:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$2, -88(%rbp)                   # 4-byte Folded Spill
	jmp	.LBB73_96
.LBB73_184:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$4, -88(%rbp)                   # 4-byte Folded Spill
	cmpq	$12, %rax
	je	.LBB73_157
.LBB73_185:                             #   in Loop: Header=BB73_14 Depth=1
	movl	$3, -88(%rbp)                   # 4-byte Folded Spill
	jmp	.LBB73_157
.LBB73_143:
	movl	$4, %r9d
	jmp	.LBB73_7
.Lfunc_end73:
	.size	acquire, .Lfunc_end73-acquire
	.cfi_endproc
	.section	.rodata.acquire,"a",@progbits
	.p2align	3, 0x0
.LJTI73_0:
	.quad	.LBB73_49
	.quad	.LBB73_78
	.quad	.LBB73_49
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_108
	.quad	.LBB73_49
                                        # -- End function
	.section	.text.usable,"ax",@progbits
	.p2align	4                               # -- Begin function usable
	.type	usable,@function
usable:                                 # @usable
.Lfunc_begin74:
	.cfi_startproc
# %bb.0:
	andl	$61440, %edx                    # imm = 0xF000
	testl	%edi, %edi
	je	.LBB74_1
# %bb.4:
	cmpl	$16384, %edx                    # imm = 0x4000
	setne	%al
	movzbl	%al, %eax
	retq
.LBB74_1:
	cmpl	$32768, %edx                    # imm = 0x8000
	jne	.LBB74_2
# %bb.3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movl	%esi, %edi
	movl	%esi, %ebx
	movl	$3, %esi
	xorl	%eax, %eax
	callq	fcntl@PLT
	andl	$-2049, %eax                    # imm = 0xF7FF
	movl	%ebx, %edi
	movl	$4, %esi
	movl	%eax, %edx
	xorl	%eax, %eax
	callq	fcntl@PLT
	testl	%eax, %eax
	sete	%al
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %rbp
	movzbl	%al, %eax
	retq
.LBB74_2:
	xorl	%eax, %eax
	movzbl	%al, %eax
	retq
.Lfunc_end74:
	.size	usable, .Lfunc_end74-usable
	.cfi_endproc
                                        # -- End function
	.section	.text.unlikely.entry_release,"ax",@progbits
	.type	entry_release,@function         # -- Begin function entry_release
entry_release:                          # @entry_release
.Lfunc_begin75:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$40, %edx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_meta_free                # TAILCALL
.Lfunc_end75:
	.size	entry_release, .Lfunc_end75-entry_release
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_scope_unwind,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_scope_unwind
	.type	myl_rc_scope_unwind,@function
myl_rc_scope_unwind:                    # @myl_rc_scope_unwind
.Lfunc_begin76:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rbx
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB76_1
# %bb.3:
	movq	%rdi, %r12
	movq	248(%rax), %rdi
	cmpq	%rbx, %rdi
	je	.LBB76_54
# %bb.4:
	movabsq	$-1152921504606846979, %r14     # imm = 0xEFFFFFFFFFFFFFFD
	movq	%rdi, %rax
	jmp	.LBB76_5
	.p2align	4
.LBB76_8:                               #   in Loop: Header=BB76_5 Depth=1
	movq	8(%rax), %rax
	cmpq	%rbx, %rax
	je	.LBB76_9
.LBB76_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB76_7 Depth 2
	testq	%rax, %rax
	je	.LBB76_2
# %bb.6:                                #   in Loop: Header=BB76_5 Depth=1
	movq	16(%rax), %rcx
	jmp	.LBB76_7
	.p2align	4
.LBB76_22:                              #   in Loop: Header=BB76_7 Depth=2
	movl	$0, 24(%rcx)
	movq	(%rcx), %rcx
.LBB76_7:                               #   Parent Loop BB76_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	testq	%rcx, %rcx
	je	.LBB76_8
# %bb.18:                               #   in Loop: Header=BB76_7 Depth=2
	cmpl	$0, 24(%rcx)
	je	.LBB76_22
# %bb.19:                               #   in Loop: Header=BB76_7 Depth=2
	movq	8(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB76_22
# %bb.20:                               #   in Loop: Header=BB76_7 Depth=2
	movq	-16(%rdx), %rsi
	testb	$2, %sil
	jne	.LBB76_22
# %bb.21:                               #   in Loop: Header=BB76_7 Depth=2
	andq	%r14, %rsi
	orq	16(%rcx), %rsi
	movq	%rsi, -16(%rdx)
	jmp	.LBB76_22
.LBB76_9:
	movq	%r12, -48(%rbp)                 # 8-byte Spill
	jmp	.LBB76_10
	.p2align	4
.LBB76_53:                              #   in Loop: Header=BB76_10 Depth=1
	movq	5640(%r12), %rax
	movq	248(%rax), %rdi
	cmpq	%rbx, %rdi
	je	.LBB76_54
.LBB76_10:                              # =>This Inner Loop Header: Depth=1
	testq	%rdi, %rdi
	je	.LBB76_2
# %bb.11:                               #   in Loop: Header=BB76_10 Depth=1
	cmpl	$0, 24(%rdi)
	je	.LBB76_53
# %bb.12:                               #   in Loop: Header=BB76_10 Depth=1
	movq	(%rdi), %r15
	testq	%r15, %r15
	je	.LBB76_2
# %bb.13:                               #   in Loop: Header=BB76_10 Depth=1
	movq	5640(%r15), %rax
	testq	%rax, %rax
	je	.LBB76_2
# %bb.14:                               #   in Loop: Header=BB76_10 Depth=1
	cmpq	%rdi, 248(%rax)
	jne	.LBB76_2
# %bb.15:                               #   in Loop: Header=BB76_10 Depth=1
	movq	8(%rdi), %rcx
	movq	%rcx, 248(%rax)
	movl	$0, 24(%rdi)
	movq	$0, 8(%rdi)
	movq	16(%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB76_51
# %bb.16:                               #   in Loop: Header=BB76_10 Depth=1
	cmpq	$0, (%rsi)
	jne	.LBB76_17
# %bb.23:                               #   in Loop: Header=BB76_10 Depth=1
	cmpl	$0, 24(%rsi)
	movq	8(%rsi), %r12
	je	.LBB76_28
# %bb.24:                               #   in Loop: Header=BB76_10 Depth=1
	testq	%r12, %r12
	je	.LBB76_25
# %bb.26:                               #   in Loop: Header=BB76_10 Depth=1
	movq	-16(%r12), %rcx
	testb	$2, %cl
	jne	.LBB76_28
# %bb.27:                               #   in Loop: Header=BB76_10 Depth=1
	andq	%r14, %rcx
	orq	16(%rsi), %rcx
	movq	%rcx, -16(%r12)
	jmp	.LBB76_28
.LBB76_25:                              #   in Loop: Header=BB76_10 Depth=1
	xorl	%r12d, %r12d
.LBB76_28:                              #   in Loop: Header=BB76_10 Depth=1
	movq	$0, 16(%rdi)
	movq	32(%rsi), %r13
	movq	264(%rax), %rcx
	cmpq	$32, %rcx
	je	.LBB76_29
# %bb.30:                               #   in Loop: Header=BB76_10 Depth=1
	movq	24(%r15), %rdx
	cmpq	$40, %rdx
	jb	.LBB76_2
# %bb.31:                               #   in Loop: Header=BB76_10 Depth=1
	movq	48(%rax), %rdi
	cmpq	$39, %rdi
	jbe	.LBB76_2
# %bb.32:                               #   in Loop: Header=BB76_10 Depth=1
	addq	$-40, %rdx
	movq	%rdx, 24(%r15)
	addq	$-40, %rdi
	movq	%rdi, 48(%rax)
	movq	256(%rax), %rdx
	movq	%rdx, (%rsi)
	movq	%rsi, 256(%rax)
	incq	%rcx
	movq	%rcx, 264(%rax)
	testq	%r13, %r13
	je	.LBB76_42
.LBB76_34:                              #   in Loop: Header=BB76_10 Depth=1
	movq	-16(%r13), %rcx
	movabsq	$4611686018427387906, %rax      # imm = 0x4000000000000002
	testq	%rax, %rcx
	jne	.LBB76_40
# %bb.35:                               #   in Loop: Header=BB76_10 Depth=1
	movl	-20(%r13), %eax
	testl	%eax, %eax
	je	.LBB76_2
# %bb.36:                               #   in Loop: Header=BB76_10 Depth=1
	andl	$1, %ecx
	jne	.LBB76_2
# %bb.37:                               #   in Loop: Header=BB76_10 Depth=1
	decl	%eax
	movl	%eax, -20(%r13)
	jne	.LBB76_40
# %bb.38:                               #   in Loop: Header=BB76_10 Depth=1
	cmpl	$0, -24(%r13)
	je	.LBB76_39
	.p2align	4
.LBB76_40:                              #   in Loop: Header=BB76_10 Depth=1
	movq	5640(%r15), %rax
	cmpq	$0, 200(%rax)
	je	.LBB76_42
# %bb.41:                               #   in Loop: Header=BB76_10 Depth=1
	movq	%r15, %rdi
	callq	myl_rc_drain
.LBB76_42:                              #   in Loop: Header=BB76_10 Depth=1
	testq	%r12, %r12
	je	.LBB76_49
# %bb.43:                               #   in Loop: Header=BB76_10 Depth=1
	movq	-16(%r12), %rcx
	movabsq	$4611686018427387906, %rax      # imm = 0x4000000000000002
	testq	%rax, %rcx
	jne	.LBB76_49
# %bb.44:                               #   in Loop: Header=BB76_10 Depth=1
	movl	-20(%r12), %eax
	testl	%eax, %eax
	je	.LBB76_2
# %bb.45:                               #   in Loop: Header=BB76_10 Depth=1
	andl	$1, %ecx
	jne	.LBB76_2
# %bb.46:                               #   in Loop: Header=BB76_10 Depth=1
	decl	%eax
	movl	%eax, -20(%r12)
	jne	.LBB76_49
# %bb.47:                               #   in Loop: Header=BB76_10 Depth=1
	cmpl	$0, -24(%r12)
	je	.LBB76_48
	.p2align	4
.LBB76_49:                              #   in Loop: Header=BB76_10 Depth=1
	movq	5640(%r15), %rax
	cmpq	$0, 200(%rax)
	movq	-48(%rbp), %r12                 # 8-byte Reload
	je	.LBB76_51
# %bb.50:                               #   in Loop: Header=BB76_10 Depth=1
	movq	%r15, %rdi
	callq	myl_rc_drain
.LBB76_51:                              #   in Loop: Header=BB76_10 Depth=1
	movq	5640(%r15), %rax
	cmpq	$0, 200(%rax)
	je	.LBB76_53
# %bb.52:                               #   in Loop: Header=BB76_10 Depth=1
	movq	%r15, %rdi
	callq	myl_rc_drain
	jmp	.LBB76_53
.LBB76_17:                              #   in Loop: Header=BB76_10 Depth=1
	callq	unwind_many
	jmp	.LBB76_51
.LBB76_29:                              #   in Loop: Header=BB76_10 Depth=1
	movq	%r15, %rdi
	callq	entry_release
	testq	%r13, %r13
	jne	.LBB76_34
	jmp	.LBB76_42
.LBB76_39:                              #   in Loop: Header=BB76_10 Depth=1
	addq	$-24, %r13
	movq	%r15, %rdi
	movq	%r13, %rsi
	callq	hold_death
	jmp	.LBB76_42
.LBB76_48:                              #   in Loop: Header=BB76_10 Depth=1
	addq	$-24, %r12
	movq	%r15, %rdi
	movq	%r12, %rsi
	callq	hold_death
	movq	-48(%rbp), %r12                 # 8-byte Reload
	jmp	.LBB76_51
.LBB76_1:
	testq	%rbx, %rbx
	jne	.LBB76_2
.LBB76_54:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB76_2:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end76:
	.size	myl_rc_scope_unwind, .Lfunc_end76-myl_rc_scope_unwind
	.cfi_endproc
                                        # -- End function
	.section	.text.unwind_many,"ax",@progbits
	.p2align	4                               # -- Begin function unwind_many
	.type	unwind_many,@function
unwind_many:                            # @unwind_many
.Lfunc_begin77:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rdi), %rbx
	movq	16(%rdi), %r12
	testq	%r12, %r12
	je	.LBB77_7
# %bb.1:
	movabsq	$-1152921504606846979, %rax     # imm = 0xEFFFFFFFFFFFFFFD
	movq	%r12, %rcx
	jmp	.LBB77_2
	.p2align	4
.LBB77_6:                               #   in Loop: Header=BB77_2 Depth=1
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB77_7
.LBB77_2:                               # =>This Inner Loop Header: Depth=1
	cmpl	$0, 24(%rcx)
	je	.LBB77_6
# %bb.3:                                #   in Loop: Header=BB77_2 Depth=1
	movq	8(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB77_6
# %bb.4:                                #   in Loop: Header=BB77_2 Depth=1
	movq	-16(%rdx), %rsi
	testb	$2, %sil
	jne	.LBB77_6
# %bb.5:                                #   in Loop: Header=BB77_2 Depth=1
	andq	%rax, %rsi
	orq	16(%rcx), %rsi
	movq	%rsi, -16(%rdx)
	jmp	.LBB77_6
.LBB77_7:
	movabsq	$4611686018427387906, %r13      # imm = 0x4000000000000002
	movq	$0, 16(%rdi)
	jmp	.LBB77_8
.LBB77_28:                              #   in Loop: Header=BB77_8 Depth=1
	addq	$-24, %r14
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	hold_death
	.p2align	4
.LBB77_31:                              #   in Loop: Header=BB77_8 Depth=1
	testq	%r12, %r12
	je	.LBB77_32
.LBB77_8:                               # =>This Inner Loop Header: Depth=1
	movq	%r12, %rsi
	movq	(%r12), %r12
	movq	8(%rsi), %r14
	movq	32(%rsi), %r15
	movq	5640(%rbx), %rax
	movq	264(%rax), %rcx
	cmpq	$32, %rcx
	je	.LBB77_9
# %bb.10:                               #   in Loop: Header=BB77_8 Depth=1
	movq	24(%rbx), %rdx
	cmpq	$40, %rdx
	jb	.LBB77_33
# %bb.11:                               #   in Loop: Header=BB77_8 Depth=1
	movq	48(%rax), %rdi
	cmpq	$39, %rdi
	jbe	.LBB77_33
# %bb.12:                               #   in Loop: Header=BB77_8 Depth=1
	addq	$-40, %rdx
	movq	%rdx, 24(%rbx)
	addq	$-40, %rdi
	movq	%rdi, 48(%rax)
	movq	256(%rax), %rdx
	movq	%rdx, (%rsi)
	movq	%rsi, 256(%rax)
	incq	%rcx
	movq	%rcx, 264(%rax)
	testq	%r15, %r15
	je	.LBB77_22
.LBB77_14:                              #   in Loop: Header=BB77_8 Depth=1
	movq	-16(%r15), %rcx
	testq	%r13, %rcx
	jne	.LBB77_20
# %bb.15:                               #   in Loop: Header=BB77_8 Depth=1
	movl	-20(%r15), %eax
	testl	%eax, %eax
	je	.LBB77_33
# %bb.16:                               #   in Loop: Header=BB77_8 Depth=1
	andl	$1, %ecx
	jne	.LBB77_33
# %bb.17:                               #   in Loop: Header=BB77_8 Depth=1
	decl	%eax
	movl	%eax, -20(%r15)
	jne	.LBB77_20
# %bb.18:                               #   in Loop: Header=BB77_8 Depth=1
	cmpl	$0, -24(%r15)
	je	.LBB77_19
	.p2align	4
.LBB77_20:                              #   in Loop: Header=BB77_8 Depth=1
	movq	5640(%rbx), %rax
	cmpq	$0, 200(%rax)
	je	.LBB77_22
# %bb.21:                               #   in Loop: Header=BB77_8 Depth=1
	movq	%rbx, %rdi
	callq	myl_rc_drain
.LBB77_22:                              #   in Loop: Header=BB77_8 Depth=1
	testq	%r14, %r14
	je	.LBB77_29
# %bb.23:                               #   in Loop: Header=BB77_8 Depth=1
	movq	-16(%r14), %rcx
	testq	%r13, %rcx
	jne	.LBB77_29
# %bb.24:                               #   in Loop: Header=BB77_8 Depth=1
	movl	-20(%r14), %eax
	testl	%eax, %eax
	je	.LBB77_33
# %bb.25:                               #   in Loop: Header=BB77_8 Depth=1
	andl	$1, %ecx
	jne	.LBB77_33
# %bb.26:                               #   in Loop: Header=BB77_8 Depth=1
	decl	%eax
	movl	%eax, -20(%r14)
	jne	.LBB77_29
# %bb.27:                               #   in Loop: Header=BB77_8 Depth=1
	cmpl	$0, -24(%r14)
	je	.LBB77_28
	.p2align	4
.LBB77_29:                              #   in Loop: Header=BB77_8 Depth=1
	movq	5640(%rbx), %rax
	cmpq	$0, 200(%rax)
	je	.LBB77_31
# %bb.30:                               #   in Loop: Header=BB77_8 Depth=1
	movq	%rbx, %rdi
	callq	myl_rc_drain
	jmp	.LBB77_31
.LBB77_9:                               #   in Loop: Header=BB77_8 Depth=1
	movq	%rbx, %rdi
	callq	entry_release
	testq	%r15, %r15
	jne	.LBB77_14
	jmp	.LBB77_22
.LBB77_19:                              #   in Loop: Header=BB77_8 Depth=1
	addq	$-24, %r15
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	hold_death
	jmp	.LBB77_22
.LBB77_32:
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB77_33:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end77:
	.size	unwind_many, .Lfunc_end77-unwind_many
	.cfi_endproc
                                        # -- End function
	.section	.text.unlikely.hold_death,"ax",@progbits
	.type	hold_death,@function            # -- Begin function hold_death
hold_death:                             # @hold_death
.Lfunc_begin78:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	8(%rsi), %rax
	testb	$1, %al
	jne	.LBB78_16
# %bb.1:
	movq	%rsi, %rcx
	movq	%rdi, %rbx
	orq	$1, %rax
	movq	%rax, 8(%rsi)
	movq	5640(%rdi), %rdi
	cmpl	$0, 208(%rdi)
	jne	.LBB78_14
# %bb.2:
	movq	16(%rcx), %rsi
	cmpq	%rsi, 272(%rdi)
	je	.LBB78_10
# %bb.3:
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB78_6
# %bb.4:
	movq	152(%rdi), %rdx
	shlq	$4, %rax
	cmpq	%rsi, (%rdx,%rax)
	jne	.LBB78_6
# %bb.5:
	addq	%rax, %rdx
	movq	8(%rdx), %rax
.LBB78_7:
	testq	%rax, %rax
	je	.LBB78_13
# %bb.8:
	cmpl	$0, 64(%rax)
	je	.LBB78_9
.LBB78_13:
	movq	5640(%rbx), %rdi
.LBB78_14:
	movq	200(%rdi), %rax
	movq	%rax, (%rcx)
	movq	5640(%rbx), %rax
	movq	%rcx, 200(%rax)
.LBB78_15:
	movq	%rbx, %rdi
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_drain                    # TAILCALL
.LBB78_9:
	.cfi_def_cfa %rbp, 16
	movq	8(%rcx), %rax
.LBB78_10:
	movabsq	$4611686018427387907, %rdx      # imm = 0x4000000000000003
	andq	%rax, %rdx
	cmpq	$1, %rdx
	jne	.LBB78_16
# %bb.11:
	movq	5640(%rbx), %rax
	addq	$24, %rcx
	movq	%rbx, %rdi
	movq	%rcx, %rsi
	callq	*8(%rax)
	movq	5640(%rbx), %rax
	cmpq	$0, 200(%rax)
	jne	.LBB78_15
# %bb.12:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB78_6:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_binding_find_slow
	jmp	.LBB78_7
.LBB78_16:
	callq	myl_rc_invariant_failed
.Lfunc_end78:
	.size	hold_death, .Lfunc_end78-hold_death
	.cfi_endproc
                                        # -- End function
	.section	.text.transfer,"ax",@progbits
	.p2align	4                               # -- Begin function transfer
	.type	transfer,@function
transfer:                               # @transfer
.Lfunc_begin79:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$536, %rsp                      # imm = 0x218
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB79_25
# %bb.1:
	movq	5640(%rdi), %r13
	testq	%r13, %r13
	je	.LBB79_25
# %bb.2:
	movq	%rsi, %rbx
	movq	8(%rsi), %r15
	testq	%r15, %r15
	je	.LBB79_25
# %bb.3:
	testq	%rcx, %rcx
	je	.LBB79_25
# %bb.4:
	movabsq	$-7046029254386353131, %r8      # imm = 0x9E3779B97F4A7C15
	movq	88(%r13), %rax
	movq	96(%r13), %rsi
	movl	112(%r13), %r9d
	movq	%rdx, %r10
	imulq	%r8, %r10
	shrxq	%r9, %r10, %r10
	andq	%rsi, %r10
	movq	%r10, %r11
	shlq	$4, %r11
	movq	(%rax,%r11), %r11
	cmpq	%rdx, %r11
	je	.LBB79_8
# %bb.5:
	xorl	%r14d, %r14d
	.p2align	4
.LBB79_6:                               # =>This Inner Loop Header: Depth=1
	testq	%r11, %r11
	je	.LBB79_9
# %bb.7:                                #   in Loop: Header=BB79_6 Depth=1
	incq	%r10
	andq	%rsi, %r10
	movq	%r10, %r11
	shlq	$4, %r11
	movq	(%rax,%r11), %r11
	cmpq	%rdx, %r11
	jne	.LBB79_6
.LBB79_8:
	shlq	$4, %r10
	movq	8(%rax,%r10), %r14
.LBB79_9:
	movq	(%rbx), %r10
	imulq	%r10, %r8
	shrxq	%r9, %r8, %rdx
	.p2align	4
.LBB79_10:                              # =>This Inner Loop Header: Depth=1
	andq	%rsi, %rdx
	movq	%rdx, %r8
	shlq	$4, %r8
	movq	(%rax,%r8), %r8
	cmpq	%r10, %r8
	je	.LBB79_11
# %bb.24:                               #   in Loop: Header=BB79_10 Depth=1
	testq	%r8, %r8
	je	.LBB79_25
# %bb.23:                               #   in Loop: Header=BB79_10 Depth=1
	incq	%rdx
	jmp	.LBB79_10
.LBB79_11:
	testq	%r14, %r14
	je	.LBB79_25
# %bb.12:
	shlq	$4, %rdx
	movq	8(%rax,%rdx), %rax
	testq	%rax, %rax
	je	.LBB79_25
# %bb.13:
	movq	(%r14), %rdx
	cmpq	(%rax), %rdx
	jne	.LBB79_25
# %bb.14:
	cmpq	%r15, %rcx
	je	.LBB79_25
# %bb.15:
	movl	24(%rbx), %edx
	movl	$3, %eax
	cmpl	112(%rdi), %edx
	ja	.LBB79_50
# %bb.16:
	cmpl	$1, 8(%r14)
	jne	.LBB79_26
# %bb.17:
	movq	(%rcx), %rax
	testq	%rax, %rax
	je	.LBB79_21
# %bb.18:
	movq	-16(%rax), %rsi
	testb	$2, %sil
	jne	.LBB79_21
# %bb.19:
	btq	$62, %rsi
	setae	%r8b
	movq	%rsi, %r9
	shrq	$40, %r9
	andl	$1048575, %r9d                  # imm = 0xFFFFF
	cmpl	%edx, %r9d
	setbe	%r9b
	btq	$60, %rsi
	jb	.LBB79_26
# %bb.20:
	orb	%r9b, %r8b
	je	.LBB79_26
.LBB79_21:
	movq	%rax, (%r15)
	movq	$0, (%rcx)
	movq	5640(%rdi), %rcx
	xorl	%eax, %eax
	cmpq	$0, 200(%rcx)
	je	.LBB79_50
# %bb.22:
	callq	myl_rc_drain
	xorl	%eax, %eax
	jmp	.LBB79_50
.LBB79_26:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -160(%rbp)
	vmovups	%ymm0, -192(%rbp)
	vmovups	%ymm0, -224(%rbp)
	vmovups	%ymm0, -256(%rbp)
	vmovups	%ymm0, -288(%rbp)
	vmovups	%ymm0, -320(%rbp)
	movq	$0, -128(%rbp)
	movq	%rdi, -88(%rbp)
	leaq	-576(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	$8, -72(%rbp)
	movq	$0, -64(%rbp)
	movl	%edx, -56(%rbp)
	movl	$1, -52(%rbp)
	leaq	-320(%rbp), %rax
	movq	%rax, -48(%rbp)
	movq	40(%r14), %r12
	cmpq	$9, %r12
	jb	.LBB79_35
# %bb.27:
	movq	%rbx, -120(%rbp)                # 8-byte Spill
	movq	%r12, %rax
	shrq	$59, %rax
	jne	.LBB79_25
# %bb.28:
	movq	%r12, %rbx
	shlq	$5, %rbx
	movq	24(%rdi), %rdx
	addq	%rbx, %rdx
	jb	.LBB79_31
# %bb.29:
	movq	88(%rdi), %rax
	testq	%rax, %rax
	je	.LBB79_32
# %bb.30:
	cmpq	%rax, %rdx
	jbe	.LBB79_32
.LBB79_31:
	movl	$1, 108(%rdi)
	movl	$1, %eax
	jmp	.LBB79_50
.LBB79_32:
	movq	%rdx, -96(%rbp)                 # 8-byte Spill
	movq	%rdi, -104(%rbp)                # 8-byte Spill
	movq	%rcx, -112(%rbp)                # 8-byte Spill
	movl	$1, %edi
	movq	%rbx, %rsi
	vzeroupper
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB79_33
# %bb.34:
	movq	-104(%rbp), %rcx                # 8-byte Reload
	movq	-96(%rbp), %rdx                 # 8-byte Reload
	movq	%rdx, 24(%rcx)
	addq	%rbx, 48(%r13)
	movq	%rax, -80(%rbp)
	movq	%r12, -72(%rbp)
	movq	-112(%rbp), %rcx                # 8-byte Reload
	movq	-120(%rbp), %rbx                # 8-byte Reload
.LBB79_35:
	movq	(%r14), %rdx
	movq	%r15, %rdi
	movq	%rcx, %rsi
	movq	%rcx, %r12
	vzeroupper
	callq	memcpy@PLT
	movq	8(%rbx), %rdx
	leaq	-88(%rbp), %rdi
	movl	$transfer_pointer, %r8d
	movq	%r14, %rsi
	movq	%r12, %r15
	movq	%r12, %rcx
	callq	visit
	testl	%eax, %eax
	je	.LBB79_37
# %bb.36:
	movl	%eax, %r12d
	movq	-48(%rbp), %rax
	movq	$0, 184(%rax)
	jmp	.LBB79_48
.LBB79_37:
	leaq	-88(%rbp), %rdi
	callq	finish_clones
	movq	-48(%rbp), %rcx
	testl	%eax, %eax
	je	.LBB79_38
# %bb.47:
	movl	%eax, %r12d
	movq	$0, 184(%rcx)
.LBB79_48:
	movq	%r15, %rcx
	movq	8(%rbx), %rdx
	leaq	-88(%rbp), %rdi
	movl	$rollback_take, %r8d
	movq	%r14, %rsi
	callq	visit
	movq	8(%rbx), %rdi
	movl	$1, %ebx
.LBB79_49:
	movq	(%r14), %rdx
	xorl	%esi, %esi
	callq	memset@PLT
	leaq	-88(%rbp), %rdi
	movl	%ebx, %esi
	callq	dispose_walk
	movl	%r12d, %eax
.LBB79_50:
	addq	$536, %rsp                      # imm = 0x218
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB79_38:
	.cfi_def_cfa %rbp, 16
	movq	184(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB79_46
# %bb.39:
	movabsq	$2305843009213693952, %rax      # imm = 0x2000000000000000
	movq	176(%rcx), %rsi
	movl	%edi, %edx
	andl	$3, %edx
	cmpq	$4, %rdi
	jae	.LBB79_41
# %bb.40:
	xorl	%r8d, %r8d
	jmp	.LBB79_44
.LBB79_33:
	movl	$1, %eax
	jmp	.LBB79_50
.LBB79_41:
	andq	$-4, %rdi
	xorl	%r8d, %r8d
	.p2align	4
.LBB79_42:                              # =>This Inner Loop Header: Depth=1
	movq	(%rsi,%r8,8), %r9
	orq	%rax, -16(%r9)
	movq	8(%rsi,%r8,8), %r9
	orq	%rax, -16(%r9)
	movq	16(%rsi,%r8,8), %r9
	orq	%rax, -16(%r9)
	movq	24(%rsi,%r8,8), %r9
	orq	%rax, -16(%r9)
	addq	$4, %r8
	cmpq	%r8, %rdi
	jne	.LBB79_42
# %bb.43:
	testq	%rdx, %rdx
	je	.LBB79_46
.LBB79_44:
	leaq	(%rsi,%r8,8), %rsi
	xorl	%edi, %edi
	.p2align	4
.LBB79_45:                              # =>This Inner Loop Header: Depth=1
	movq	(%rsi,%rdi,8), %r8
	orq	%rax, -16(%r8)
	incq	%rdi
	cmpq	%rdi, %rdx
	jne	.LBB79_45
.LBB79_46:
	movq	$0, 184(%rcx)
	movq	8(%rbx), %rdx
	leaq	-88(%rbp), %rdi
	movl	$commit_take, %r8d
	movq	%r14, %rsi
	movq	%r15, %rcx
	callq	visit
	movq	%r15, %rdi
	xorl	%r12d, %r12d
	xorl	%ebx, %ebx
	jmp	.LBB79_49
.LBB79_25:
	vzeroupper
	callq	myl_rc_invariant_failed
.Lfunc_end79:
	.size	transfer, .Lfunc_end79-transfer
	.cfi_endproc
                                        # -- End function
	.section	.text.visit,"ax",@progbits
	.p2align	4                               # -- Begin function visit
	.type	visit,@function
visit:                                  # @visit
.Lfunc_begin80:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movq	$0, 24(%rdi)
	movl	8(%rsi), %r13d
	movl	%r13d, %eax
	orl	$4, %eax
	cmpl	$5, %eax
	jne	.LBB80_2
# %bb.1:
	movq	%rbx, %rdi
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	movl	%r13d, %ecx
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmpq	*%r8                            # TAILCALL
.LBB80_2:
	.cfi_def_cfa %rbp, 16
	cmpq	$2, 40(%rsi)
	movq	%r8, -56(%rbp)                  # 8-byte Spill
	jbe	.LBB80_25
# %bb.3:
	xorl	%eax, %eax
	testl	%r13d, %r13d
	je	.LBB80_48
# %bb.4:
	cmpq	$0, 16(%rbx)
	je	.LBB80_50
# %bb.5:
	movq	8(%rbx), %rax
	movq	$1, 24(%rbx)
	movq	%rsi, (%rax)
	movq	%rdx, 8(%rax)
	movq	%rcx, 16(%rax)
	movq	$0, 24(%rax)
.LBB80_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB80_8 Depth 2
	movq	24(%rbx), %rax
	jmp	.LBB80_8
	.p2align	4
.LBB80_7:                               #   in Loop: Header=BB80_8 Depth=2
	decq	%rax
	movq	%rax, 24(%rbx)
.LBB80_8:                               #   Parent Loop BB80_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	testq	%rax, %rax
	je	.LBB80_47
# %bb.9:                                #   in Loop: Header=BB80_8 Depth=2
	movq	8(%rbx), %rcx
	movq	%rax, %rsi
	shlq	$5, %rsi
	leaq	(%rcx,%rsi), %rdx
	movq	-32(%rcx,%rsi), %rsi
	movl	8(%rsi), %ecx
	cmpl	$5, %ecx
	je	.LBB80_12
# %bb.10:                               #   in Loop: Header=BB80_8 Depth=2
	cmpl	$3, %ecx
	je	.LBB80_14
# %bb.11:                               #   in Loop: Header=BB80_8 Depth=2
	cmpl	$1, %ecx
	jne	.LBB80_16
.LBB80_12:                              #   in Loop: Header=BB80_8 Depth=2
	movq	-24(%rdx), %rsi
	movq	-16(%rdx), %rdx
	movq	%rbx, %rdi
	callq	*%r8
	testl	%eax, %eax
	jne	.LBB80_49
# %bb.13:                               #   in Loop: Header=BB80_8 Depth=2
	movq	24(%rbx), %rax
	decq	%rax
	movq	%rax, 24(%rbx)
	movq	-56(%rbp), %r8                  # 8-byte Reload
	jmp	.LBB80_8
	.p2align	4
.LBB80_14:                              #   in Loop: Header=BB80_8 Depth=2
	movq	-8(%rdx), %rcx
	cmpq	24(%rsi), %rcx
	je	.LBB80_7
# %bb.15:                               #   in Loop: Header=BB80_8 Depth=2
	leaq	1(%rcx), %rdi
	movq	%rdi, -8(%rdx)
	movq	16(%rsi), %r10
	cmpl	$0, 8(%r10)
	jne	.LBB80_22
	jmp	.LBB80_8
	.p2align	4
.LBB80_16:                              #   in Loop: Header=BB80_8 Depth=2
	movq	-8(%rdx), %rdi
	cmpq	24(%rsi), %rdi
	je	.LBB80_7
# %bb.17:                               #   in Loop: Header=BB80_8 Depth=2
	leaq	(%rdi,%rdi,2), %r9
	shlq	$3, %r9
	addq	16(%rsi), %r9
	incq	%rdi
	movq	%rdi, -8(%rdx)
	movq	-16(%rdx), %rdi
	cmpl	$4, %ecx
	jne	.LBB80_19
# %bb.18:                               #   in Loop: Header=BB80_8 Depth=2
	movq	32(%rsi), %rcx
	movl	(%rdi,%rcx), %ecx
	cmpl	16(%r9), %ecx
	jne	.LBB80_8
.LBB80_19:                              #   in Loop: Header=BB80_8 Depth=2
	movq	8(%r9), %r10
	cmpl	$0, 8(%r10)
	je	.LBB80_8
# %bb.20:                               #   in Loop: Header=BB80_6 Depth=1
	cmpq	16(%rbx), %rax
	jae	.LBB80_50
# %bb.21:                               #   in Loop: Header=BB80_6 Depth=1
	movq	(%r9), %rcx
	jmp	.LBB80_24
.LBB80_22:                              #   in Loop: Header=BB80_6 Depth=1
	cmpq	16(%rbx), %rax
	jae	.LBB80_50
# %bb.23:                               #   in Loop: Header=BB80_6 Depth=1
	imulq	32(%rsi), %rcx
	movq	-16(%rdx), %rdi
.LBB80_24:                              #   in Loop: Header=BB80_6 Depth=1
	addq	%rcx, %rdi
	addq	-24(%rdx), %rcx
	incq	%rax
	movq	%rax, 24(%rbx)
	movq	%r10, (%rdx)
	movq	%rcx, 8(%rdx)
	movq	%rdi, 16(%rdx)
	movq	$0, 24(%rdx)
	jmp	.LBB80_6
.LBB80_25:
	leal	-1(%r13), %eax
	cmpl	$3, %eax
	movq	%rcx, -88(%rbp)                 # 8-byte Spill
	movq	%rdx, -80(%rbp)                 # 8-byte Spill
	ja	.LBB80_31
# %bb.26:
	jmpq	*.LJTI80_0(,%rax,8)
.LBB80_27:
	movl	$1, %r13d
	movl	$1, %edx
	jmp	.LBB80_32
.LBB80_28:
	movq	16(%rsi), %rax
	movq	24(%rsi), %rdx
	movq	32(%rsi), %rcx
	movq	%rcx, -48(%rbp)                 # 8-byte Spill
	movl	8(%rax), %r13d
	jmp	.LBB80_33
.LBB80_29:
	movq	16(%rsi), %rdi
	movq	24(%rsi), %rdx
	movq	32(%rsi), %r12
	addq	%rcx, %r12
	movl	$4, %r13d
	movq	$0, -48(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB80_35
.LBB80_30:
	movq	16(%rsi), %rdi
	movq	24(%rsi), %rdx
	movl	$2, %r13d
	movq	$0, -48(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB80_34
.LBB80_31:
	xorl	%edx, %edx
.LBB80_32:
	movq	$0, -48(%rbp)                   # 8-byte Folded Spill
.LBB80_33:
	xorl	%edi, %edi
.LBB80_34:
	xorl	%r12d, %r12d
.LBB80_35:
	movq	%rdx, %r15
	negq	%r15
	xorl	%r14d, %r14d
	movq	%rdx, -72(%rbp)                 # 8-byte Spill
	movq	%rdi, -64(%rbp)                 # 8-byte Spill
.LBB80_36:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB80_40 Depth 2
	testq	%rdi, %rdi
	je	.LBB80_44
# %bb.37:                               #   in Loop: Header=BB80_36 Depth=1
	xorl	%eax, %eax
	cmpq	%rdx, %r14
	movq	-56(%rbp), %r8                  # 8-byte Reload
	jae	.LBB80_48
# %bb.38:                               #   in Loop: Header=BB80_36 Depth=1
	leaq	(%r14,%r14,2), %rax
	leaq	(%rdi,%rax,8), %rax
	incq	%r14
	jmp	.LBB80_40
	.p2align	4
.LBB80_39:                              #   in Loop: Header=BB80_40 Depth=2
	addq	$24, %rax
	leaq	(%r15,%r14), %rcx
	incq	%rcx
	incq	%r14
	cmpq	$1, %rcx
	je	.LBB80_47
.LBB80_40:                              #   Parent Loop BB80_36 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	8(%rax), %rcx
	movl	8(%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB80_39
# %bb.41:                               #   in Loop: Header=BB80_40 Depth=2
	testq	%r12, %r12
	je	.LBB80_43
# %bb.42:                               #   in Loop: Header=BB80_40 Depth=2
	movl	16(%rax), %edx
	cmpl	(%r12), %edx
	jne	.LBB80_39
.LBB80_43:                              #   in Loop: Header=BB80_36 Depth=1
	movq	(%rax), %rdx
	jmp	.LBB80_46
.LBB80_44:                              #   in Loop: Header=BB80_36 Depth=1
	cmpq	%rdx, %r14
	movq	-56(%rbp), %r8                  # 8-byte Reload
	je	.LBB80_47
# %bb.45:                               #   in Loop: Header=BB80_36 Depth=1
	movq	%r14, %rdx
	incq	%r14
	imulq	-48(%rbp), %rdx                 # 8-byte Folded Reload
	movl	%r13d, %ecx
.LBB80_46:                              #   in Loop: Header=BB80_36 Depth=1
	movq	-80(%rbp), %rax                 # 8-byte Reload
	leaq	(%rax,%rdx), %rsi
	addq	-88(%rbp), %rdx                 # 8-byte Folded Reload
	movq	%rbx, %rdi
	callq	*%r8
	testl	%eax, %eax
	movq	-72(%rbp), %rdx                 # 8-byte Reload
	movq	-64(%rbp), %rdi                 # 8-byte Reload
	je	.LBB80_36
	jmp	.LBB80_48
.LBB80_47:
	xorl	%eax, %eax
.LBB80_48:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB80_49:
	.cfi_def_cfa %rbp, 16
	movq	$0, 24(%rbx)
	jmp	.LBB80_48
.LBB80_50:
	callq	myl_rc_invariant_failed
.Lfunc_end80:
	.size	visit, .Lfunc_end80-visit
	.cfi_endproc
	.section	.rodata.visit,"a",@progbits
	.p2align	3, 0x0
.LJTI80_0:
	.quad	.LBB80_27
	.quad	.LBB80_30
	.quad	.LBB80_28
	.quad	.LBB80_29
                                        # -- End function
	.section	.text.schedule_clone,"ax",@progbits
	.p2align	4                               # -- Begin function schedule_clone
	.type	schedule_clone,@function
schedule_clone:                         # @schedule_clone
.Lfunc_begin81:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, %r10
	movq	$0, (%rcx)
	movq	40(%rdi), %r12
	cmpl	$0, 172(%r12)
	je	.LBB81_4
# %bb.1:
	testq	%rsi, %rsi
	je	.LBB81_4
# %bb.2:
	movq	-8(%rsi), %rax
	cmpq	$myl_native_list_header_descriptor, %rax
	sete	%cl
	cmpq	$dict_type, %rax
	sete	%r8b
	orb	%cl, %r8b
	cmpq	$rc_dict_type, %rax
	sete	%al
	orb	%r8b, %al
	je	.LBB81_4
# %bb.3:
	xorl	%r11d, %r11d
	movq	(%rdi), %rbx
	movq	5640(%rbx), %rax
	cmpb	$0, 288(%rax)
	jne	.LBB81_67
	jmp	.LBB81_23
.LBB81_4:
	movq	160(%r12), %r13
	testq	%r13, %r13
	je	.LBB81_14
# %bb.5:
	movq	48(%r12), %rax
	movq	%rsi, %rcx
	shrq	$4, %rcx
	movl	%edx, %r8d
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%r8, %r9
	xorq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$30, %rcx
	xorq	%r9, %rcx
	movabsq	$-4658895280553007687, %r8      # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %r8
	movq	%r8, %rcx
	shrq	$27, %rcx
	xorq	%r8, %rcx
	movabsq	$-7723592293110705685, %r9      # imm = 0x94D049BB133111EB
	imulq	%rcx, %r9
	movq	%r9, %r8
	shrq	$31, %r8
	xorq	%r9, %r8
	leaq	-1(%r13), %r9
	jmp	.LBB81_7
	.p2align	4
.LBB81_6:                               #   in Loop: Header=BB81_7 Depth=1
	incq	%r8
.LBB81_7:                               # =>This Inner Loop Header: Depth=1
	andq	%r9, %r8
	leaq	(%r8,%r8,2), %rcx
	movq	(%rax,%rcx,8), %rcx
	testq	%rcx, %rcx
	je	.LBB81_10
# %bb.8:                                #   in Loop: Header=BB81_7 Depth=1
	cmpq	%rsi, %rcx
	jne	.LBB81_6
# %bb.9:                                #   in Loop: Header=BB81_7 Depth=1
	leaq	(%r8,%r8,2), %rcx
	cmpl	%edx, 16(%rax,%rcx,8)
	jne	.LBB81_6
.LBB81_10:
	leaq	(%r8,%r8,2), %rcx
	leaq	(%rax,%rcx,8), %rax
.LBB81_11:
	movq	8(%rax), %rax
	testq	%rax, %rax
	je	.LBB81_19
# %bb.12:
	movq	-16(%rax), %rsi
	movabsq	$4611686018427387904, %rcx      # imm = 0x4000000000000000
	orq	$2, %rcx
	testq	%rcx, %rsi
	je	.LBB81_26
# %bb.13:
	testl	%edx, %edx
	jne	.LBB81_31
	jmp	.LBB81_33
.LBB81_14:
	movq	152(%r12), %r15
	testq	%r15, %r15
	je	.LBB81_66
# %bb.15:
	leaq	56(%r12), %rax
	movq	%r15, %r8
	jmp	.LBB81_17
	.p2align	4
.LBB81_16:                              #   in Loop: Header=BB81_17 Depth=1
	addq	$24, %rax
	decq	%r8
	je	.LBB81_20
.LBB81_17:                              # =>This Inner Loop Header: Depth=1
	cmpq	%rsi, (%rax)
	jne	.LBB81_16
# %bb.18:                               #   in Loop: Header=BB81_17 Depth=1
	cmpl	%edx, 16(%rax)
	jne	.LBB81_16
	jmp	.LBB81_11
.LBB81_19:
	movq	152(%r12), %r15
.LBB81_20:
	testq	%r13, %r13
	je	.LBB81_35
# %bb.21:
	movq	%r13, %rax
	shrq	%rax
	movb	$1, %r11b
	cmpq	%rax, %r15
	jae	.LBB81_36
.LBB81_22:
	movq	(%rdi), %rbx
	movq	5640(%rbx), %rax
	cmpb	$0, 288(%rax)
	jne	.LBB81_67
.LBB81_23:
	cmpq	$myl_native_list_header_descriptor, -8(%rsi)
	jne	.LBB81_67
# %bb.24:
	movl	%r11d, -80(%rbp)                # 4-byte Spill
	movq	%rdi, %r14
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movl	%edx, %r15d
	movq	%r10, %r13
	movl	$rc_list_module, %esi
	movq	%rbx, %rdi
	callq	myl_rc_module_register
	movl	%eax, %ecx
	movl	$1, %eax
	testl	%ecx, %ecx
	jne	.LBB81_115
# %bb.25:
	movq	5640(%rbx), %rax
	movb	$1, 288(%rax)
	movq	%r14, %rdi
	movq	(%r14), %rax
	movq	5640(%rax), %rax
	movq	%r13, %r10
	movl	%r15d, %edx
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movl	-80(%rbp), %r11d                # 4-byte Reload
	jmp	.LBB81_67
.LBB81_26:
	testb	$1, %sil
	jne	.LBB81_153
# %bb.27:
	movl	-24(%rax), %ecx
	cmpl	$-1, %ecx
	je	.LBB81_39
# %bb.28:
	testl	%ecx, %ecx
	jne	.LBB81_30
# %bb.29:
	cmpl	$0, -20(%rax)
	je	.LBB81_153
.LBB81_30:
	incl	%ecx
	movl	%ecx, -24(%rax)
	testl	%edx, %edx
	je	.LBB81_33
.LBB81_31:
	cmpl	$0, 172(%r12)
	jne	.LBB81_33
# %bb.32:
	movabsq	$2305843009213693951, %rcx      # imm = 0x1FFFFFFFFFFFFFFF
	incq	%rcx
	orq	%rcx, %rsi
	movq	%rsi, -16(%rax)
.LBB81_33:
	movq	%rax, (%r10)
.LBB81_34:
	xorl	%eax, %eax
	jmp	.LBB81_115
.LBB81_35:
	movb	$1, %r11b
	cmpq	$4, %r15
	jb	.LBB81_22
.LBB81_36:
	leaq	(,%r13,2), %rax
	testq	%r13, %r13
	movl	$32, %r8d
	cmovneq	%rax, %r8
	movl	$1, %eax
	cmpq	%r13, %r8
	jb	.LBB81_115
# %bb.37:
	movl	%edx, -44(%rbp)                 # 4-byte Spill
	movl	$24, %ecx
	movq	%r8, %rax
	mulq	%rcx
	jo	.LBB81_114
# %bb.40:
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB81_153
# %bb.41:
	testq	%rax, %rax
	je	.LBB81_153
# %bb.42:
	movq	5640(%rdx), %r11
	testq	%r11, %r11
	je	.LBB81_153
# %bb.43:
	movq	24(%rdx), %rbx
	movq	%rax, %r9
	addq	%rax, %rbx
	movl	$1, %eax
	jb	.LBB81_46
# %bb.44:
	movq	88(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB81_47
# %bb.45:
	cmpq	%rcx, %rbx
	ja	.LBB81_46
.LBB81_47:
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movq	%rdx, -88(%rbp)                 # 8-byte Spill
	movq	%r8, -112(%rbp)                 # 8-byte Spill
	movq	%rdi, -72(%rbp)                 # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movq	%r10, -96(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%r9, %rsi
	movq	%r9, -80(%rbp)                  # 8-byte Spill
	callq	calloc@PLT
	movq	%rax, %r14
	movl	$1, %eax
	testq	%r14, %r14
	je	.LBB81_115
# %bb.48:
	movq	-88(%rbp), %r9                  # 8-byte Reload
	movq	%rbx, 24(%r9)
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	-80(%rbp), %rcx                 # 8-byte Reload
	addq	%rcx, 48(%rax)
	testq	%r13, %r13
	je	.LBB81_50
# %bb.49:
	movq	48(%r12), %rcx
	movq	%r13, %r15
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	jmp	.LBB81_52
.LBB81_39:
	movl	$2, %eax
	jmp	.LBB81_115
.LBB81_50:
	testq	%r15, %r15
	movq	-96(%rbp), %r10                 # 8-byte Reload
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	je	.LBB81_151
# %bb.51:
	leaq	56(%r12), %rcx
.LBB81_52:
	movq	-112(%rbp), %rax                # 8-byte Reload
	leaq	-1(%rax), %r11
	xorl	%r8d, %r8d
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	jmp	.LBB81_55
.LBB81_53:                              #   in Loop: Header=BB81_55 Depth=1
	leaq	(%rbx,%rbx,2), %rax
	movq	-56(%rbp), %r9                  # 8-byte Reload
	movq	16(%r9), %rcx
	movq	%rcx, 16(%r14,%rax,8)
	vmovups	(%r9), %xmm0
	vmovups	%xmm0, (%r14,%rax,8)
	movq	-80(%rbp), %rcx                 # 8-byte Reload
.LBB81_54:                              #   in Loop: Header=BB81_55 Depth=1
	incq	%r8
	cmpq	%r15, %r8
	je	.LBB81_61
.LBB81_55:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB81_58 Depth 2
	leaq	(%r8,%r8,2), %rax
	movq	(%rcx,%rax,8), %r10
	testq	%r10, %r10
	je	.LBB81_54
# %bb.56:                               #   in Loop: Header=BB81_55 Depth=1
	leaq	(%rcx,%rax,8), %rax
	movq	%rax, -56(%rbp)                 # 8-byte Spill
	movl	16(%rax), %eax
	movq	%r10, %r9
	shrq	$4, %r9
	movq	%rax, %rbx
	movabsq	$-7046029254386353131, %rcx     # imm = 0x9E3779B97F4A7C15
	imulq	%rcx, %rbx
	xorq	%r9, %rbx
	movq	%rbx, %r9
	shrq	$30, %r9
	xorq	%rbx, %r9
	movabsq	$-4658895280553007687, %rcx     # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$27, %rcx
	xorq	%r9, %rcx
	movabsq	$-7723592293110705685, %r9      # imm = 0x94D049BB133111EB
	imulq	%r9, %rcx
	movq	%rcx, %rbx
	shrq	$31, %rbx
	xorq	%rcx, %rbx
	jmp	.LBB81_58
	.p2align	4
.LBB81_57:                              #   in Loop: Header=BB81_58 Depth=2
	incq	%rbx
.LBB81_58:                              #   Parent Loop BB81_55 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%r11, %rbx
	leaq	(%rbx,%rbx,2), %rcx
	movq	(%r14,%rcx,8), %r9
	testq	%r9, %r9
	je	.LBB81_53
# %bb.59:                               #   in Loop: Header=BB81_58 Depth=2
	cmpq	%r10, %r9
	jne	.LBB81_57
# %bb.60:                               #   in Loop: Header=BB81_58 Depth=2
	leaq	(%rbx,%rbx,2), %rcx
	cmpl	%eax, 16(%r14,%rcx,8)
	jne	.LBB81_57
	jmp	.LBB81_53
.LBB81_61:
	shlq	$3, %r13
	leaq	(,%r13,2), %r8
	addq	%r13, %r8
	movq	-96(%rbp), %r10                 # 8-byte Reload
	movq	-88(%rbp), %r9                  # 8-byte Reload
	movq	48(%r12), %rax
	testq	%rax, %rax
	je	.LBB81_65
.LBB81_62:
	movq	24(%r9), %rcx
	subq	%r8, %rcx
	jb	.LBB81_153
# %bb.63:
	movq	5640(%r9), %rdx
	movq	48(%rdx), %rsi
	subq	%r8, %rsi
	jb	.LBB81_153
# %bb.64:
	movq	%rcx, 24(%r9)
	movq	%rsi, 48(%rdx)
	movq	%rax, %rdi
	callq	free@PLT
	movq	-96(%rbp), %r10                 # 8-byte Reload
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movq	-72(%rbp), %rdi                 # 8-byte Reload
.LBB81_65:
	movq	%r14, 48(%r12)
	movq	-112(%rbp), %rax                # 8-byte Reload
	movq	%rax, 160(%r12)
.LBB81_66:
	movb	$1, %r11b
	movq	(%rdi), %rbx
	movq	5640(%rbx), %rax
	cmpb	$0, 288(%rax)
	je	.LBB81_23
.LBB81_67:
	movq	-8(%rsi), %r8
	movl	52(%r8), %ecx
	cmpq	%rcx, 160(%rax)
	jbe	.LBB81_152
# %bb.68:
	movq	152(%rax), %r9
	shlq	$4, %rcx
	cmpq	%r8, (%r9,%rcx)
	jne	.LBB81_152
# %bb.69:
	addq	%rcx, %r9
	movq	8(%r9), %rbx
	testq	%rbx, %rbx
	je	.LBB81_153
.LBB81_70:
	cmpq	$0, 24(%rbx)
	jne	.LBB81_153
# %bb.71:
	cmpq	$0, 40(%rbx)
	je	.LBB81_74
# %bb.72:
	cmpq	$0, 48(%rbx)
	jne	.LBB81_77
.LBB81_127:
	xorl	%r8d, %r8d
	testl	%edx, %edx
	jne	.LBB81_80
	jmp	.LBB81_82
.LBB81_74:
	cmpq	$0, 16(%rbx)
	jne	.LBB81_153
# %bb.75:
	cmpq	$0, 48(%rbx)
	jne	.LBB81_77
# %bb.76:
	movq	8(%rbx), %rax
	cmpl	$0, 8(%rax)
	je	.LBB81_127
.LBB81_77:
	movq	(%r12), %r14
	movq	8(%r12), %r13
	movq	16(%r12), %rcx
	cmpq	%rcx, %r13
	jae	.LBB81_84
# %bb.78:
	movb	$1, %r8b
	testq	%r14, %r14
	je	.LBB81_114
# %bb.79:
	testl	%edx, %edx
	je	.LBB81_82
.LBB81_80:
	movq	24(%r12), %r9
	movq	32(%r12), %r15
	movq	40(%r12), %rax
	cmpq	%rax, %r15
	jae	.LBB81_87
# %bb.81:
	testq	%r9, %r9
	je	.LBB81_114
.LBB81_82:
	movl	%r8d, -56(%rbp)                 # 4-byte Spill
	movl	%r11d, %r15d
	movq	$0, -104(%rbp)
	movq	40(%rbx), %r8
	testq	%r8, %r8
	movl	%edx, -44(%rbp)                 # 4-byte Spill
	je	.LBB81_96
# %bb.83:
	movq	(%rdi), %rdi
	leaq	-104(%rbp), %rcx
	movq	%rsi, %r14
	movq	%r10, %r13
	callq	*%r8
	jmp	.LBB81_100
.LBB81_84:
	leaq	(%rcx,%rcx), %rax
	testq	%rcx, %rcx
	movl	$16, %r15d
	cmovneq	%rax, %r15
	movl	$1, %eax
	cmpq	%rcx, %r15
	jb	.LBB81_115
# %bb.85:
	movl	%edx, -44(%rbp)                 # 4-byte Spill
	movl	$40, %ecx
	movq	%r15, %rax
	mulq	%rcx
	jno	.LBB81_107
.LBB81_114:
	movl	$1, %eax
	jmp	.LBB81_115
.LBB81_87:
	leaq	(%rax,%rax), %rcx
	testq	%rax, %rax
	movl	$16, %r13d
	cmovneq	%rcx, %r13
	cmpq	%rax, %r13
	setb	%al
	movq	%r13, %rcx
	shrq	$61, %rcx
	setne	%cl
	orb	%al, %cl
	movl	$1, %eax
	jne	.LBB81_115
# %bb.88:
	movq	%r9, -88(%rbp)                  # 8-byte Spill
	movq	(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB81_153
# %bb.89:
	testq	%r13, %r13
	je	.LBB81_153
# %bb.90:
	movq	5640(%rcx), %r14
	movq	%r14, -112(%rbp)                # 8-byte Spill
	testq	%r14, %r14
	je	.LBB81_153
# %bb.91:
	movq	24(%rcx), %r9
	leaq	(,%r13,8), %r14
	addq	%r14, %r9
	jb	.LBB81_94
# %bb.92:
	movq	%r9, %r14
	movq	88(%rcx), %r9
	movq	%r9, -64(%rbp)                  # 8-byte Spill
	testq	%r9, %r9
	je	.LBB81_137
# %bb.93:
	cmpq	-64(%rbp), %r14                 # 8-byte Folded Reload
	jbe	.LBB81_137
.LBB81_94:
	movl	$1, 108(%rcx)
	jmp	.LBB81_115
.LBB81_96:
	movq	%r10, %r13
	movabsq	$288230376151711743, %r8        # imm = 0x3FFFFFFFFFFFFFF
	movabsq	$274877906943, %r10             # imm = 0x3FFFFFFFFF
	movq	-8(%rsi), %r14
	movq	%r14, -144(%rbp)
	movq	-16(%rsi), %rax
	movq	%rax, %rcx
	shrq	$2, %rcx
	btq	$62, %rax
	movq	%r10, %r9
	cmovaeq	%r8, %r9
	andq	%rcx, %r9
	movq	%r9, -136(%rbp)
	movl	%edx, -128(%rbp)
	movl	$0, -124(%rbp)
	movq	(%rdi), %r8
	testq	%r8, %r8
	je	.LBB81_153
# %bb.97:
	movq	5640(%r8), %r11
	testq	%r11, %r11
	je	.LBB81_153
# %bb.98:
	movq	$0, -104(%rbp)
	testq	%r14, %r14
	je	.LBB81_153
# %bb.99:
	movq	%r9, %rax
	mulq	(%r14)
	movq	%rax, %rdx
	movl	$1, %eax
	movq	%rsi, %r14
	jno	.LBB81_122
.LBB81_100:
	testl	%eax, %eax
	jne	.LBB81_115
# %bb.101:
	movq	-104(%rbp), %rax
	testq	%rax, %rax
	je	.LBB81_153
# %bb.102:
	testb	%r15b, %r15b
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movl	-56(%rbp), %r9d                 # 4-byte Reload
	je	.LBB81_103
# %bb.116:
	movq	160(%r12), %rdi
	testq	%rdi, %rdi
	je	.LBB81_136
# %bb.117:
	movq	48(%r12), %rsi
	movq	%r14, %rcx
	shrq	$4, %rcx
	movl	%edx, %r8d
	movabsq	$-7046029254386353131, %r9      # imm = 0x9E3779B97F4A7C15
	imulq	%r8, %r9
	xorq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$30, %rcx
	xorq	%r9, %rcx
	movabsq	$-4658895280553007687, %r8      # imm = 0xBF58476D1CE4E5B9
	imulq	%rcx, %r8
	movq	%r8, %rcx
	shrq	$27, %rcx
	xorq	%r8, %rcx
	movabsq	$-7723592293110705685, %r9      # imm = 0x94D049BB133111EB
	imulq	%rcx, %r9
	movq	%r9, %r8
	shrq	$31, %r8
	xorq	%r9, %r8
	decq	%rdi
	andq	%rdi, %r8
	leaq	(%r8,%r8,2), %rcx
	movq	(%rsi,%rcx,8), %rcx
	testq	%rcx, %rcx
	je	.LBB81_145
# %bb.118:
	movl	-56(%rbp), %r9d                 # 4-byte Reload
	jmp	.LBB81_120
	.p2align	4
.LBB81_119:                             #   in Loop: Header=BB81_120 Depth=1
	incq	%r8
	andq	%rdi, %r8
	leaq	(%r8,%r8,2), %rcx
	movq	(%rsi,%rcx,8), %rcx
	testq	%rcx, %rcx
	je	.LBB81_146
.LBB81_120:                             # =>This Inner Loop Header: Depth=1
	cmpq	%r14, %rcx
	jne	.LBB81_119
# %bb.121:                              #   in Loop: Header=BB81_120 Depth=1
	leaq	(%r8,%r8,2), %rcx
	cmpl	%edx, 16(%rsi,%rcx,8)
	jne	.LBB81_119
	jmp	.LBB81_146
.LBB81_103:
	testb	%r9b, %r9b
	je	.LBB81_104
.LBB81_148:
	movq	(%r12), %rcx
	movq	8(%r12), %rsi
	leaq	1(%rsi), %rdi
	movq	%rdi, 8(%r12)
	leaq	(%rsi,%rsi,4), %rsi
	movq	%r14, (%rcx,%rsi,8)
	movq	%rax, 8(%rcx,%rsi,8)
	movq	%rbx, 16(%rcx,%rsi,8)
	movq	$0, 24(%rcx,%rsi,8)
	movl	%edx, 32(%rcx,%rsi,8)
	movl	$0, 36(%rcx,%rsi,8)
	movq	-104(%rbp), %rax
	testl	%edx, %edx
	jne	.LBB81_105
	jmp	.LBB81_106
.LBB81_107:
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB81_153
# %bb.108:
	testq	%rax, %rax
	je	.LBB81_153
# %bb.109:
	movq	5640(%rdx), %r9
	testq	%r9, %r9
	je	.LBB81_153
# %bb.110:
	movq	24(%rdx), %rcx
	movq	%rax, %r8
	addq	%rax, %rcx
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movl	$1, %eax
	jb	.LBB81_46
# %bb.111:
	movq	88(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB81_128
# %bb.112:
	cmpq	%rcx, -56(%rbp)                 # 8-byte Folded Reload
	jbe	.LBB81_128
.LBB81_46:
	movl	$1, 108(%rdx)
.LBB81_115:
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB81_122:
	.cfi_def_cfa %rbp, 16
	xorl	%ecx, %ecx
	cmpl	$0, -44(%rbp)                   # 4-byte Folded Reload
	sete	%cl
	leaq	16(,%rcx,8), %rcx
	movabsq	$288230376151711743, %rsi       # imm = 0x3FFFFFFFFFFFFFF
	cmoveq	%rsi, %r10
	addq	%rcx, %rdx
	jb	.LBB81_100
# %bb.123:
	cmpq	%r10, %r9
	ja	.LBB81_100
# %bb.124:
	movl	$3, %eax
	movl	-44(%rbp), %ecx                 # 4-byte Reload
	cmpl	112(%r8), %ecx
	ja	.LBB81_100
# %bb.125:
	movq	%rdi, -72(%rbp)                 # 8-byte Spill
	leaq	-144(%rbp), %rsi
	leaq	-104(%rbp), %rdx
	movq	%r8, %rdi
	callq	*(%r11)
	movq	-104(%rbp), %rdx
	testl	%eax, %eax
	je	.LBB81_149
# %bb.126:
	testq	%rdx, %rdx
	je	.LBB81_100
	jmp	.LBB81_153
.LBB81_128:
	movq	%r9, -112(%rbp)                 # 8-byte Spill
	movq	%rdx, -88(%rbp)                 # 8-byte Spill
	movl	%r11d, -80(%rbp)                # 4-byte Spill
	movq	%rdi, -72(%rbp)                 # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movq	%r10, -96(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%r8, %rsi
	movq	%r8, -120(%rbp)                 # 8-byte Spill
	callq	calloc@PLT
	movq	%rax, %rcx
	movl	$1, %eax
	testq	%rcx, %rcx
	je	.LBB81_115
# %bb.129:
	movq	-88(%rbp), %rdi                 # 8-byte Reload
	movq	-56(%rbp), %rax                 # 8-byte Reload
	movq	%rax, 24(%rdi)
	movq	-112(%rbp), %rax                # 8-byte Reload
	movq	-120(%rbp), %rdx                # 8-byte Reload
	addq	%rdx, 48(%rax)
	testq	%r13, %r13
	je	.LBB81_131
# %bb.130:
	shlq	$3, %r13
	leaq	(,%r13,4), %rdx
	addq	%r13, %rdx
	movq	%rcx, %rdi
	movq	%r14, %rsi
	movq	%rcx, %r13
	callq	memcpy@PLT
	movq	%r13, %rcx
	movq	-88(%rbp), %rdi                 # 8-byte Reload
.LBB81_131:
	testq	%r14, %r14
	je	.LBB81_135
# %bb.132:
	movq	%rcx, %r13
	movq	16(%r12), %rax
	shlq	$3, %rax
	leaq	(%rax,%rax,4), %rcx
	movq	24(%rdi), %rax
	subq	%rcx, %rax
	jb	.LBB81_153
# %bb.133:
	movq	5640(%rdi), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB81_153
# %bb.134:
	movq	%rax, 24(%rdi)
	movq	%rsi, 48(%rdx)
	movq	%r14, %rdi
	callq	free@PLT
	movq	%r13, %rcx
.LBB81_135:
	movq	%r15, 16(%r12)
	movq	%rcx, (%r12)
	movb	$1, %r8b
	movq	-96(%rbp), %r10                 # 8-byte Reload
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	movl	-80(%rbp), %r11d                # 4-byte Reload
	testl	%edx, %edx
	jne	.LBB81_80
	jmp	.LBB81_82
.LBB81_136:
	movq	152(%r12), %rcx
	leaq	(%rcx,%rcx,2), %rcx
	leaq	(%r12,%rcx,8), %rcx
	addq	$56, %rcx
	jmp	.LBB81_147
.LBB81_137:
	movq	%rcx, -120(%rbp)                # 8-byte Spill
	movl	%r8d, -56(%rbp)                 # 4-byte Spill
	movl	%r11d, -80(%rbp)                # 4-byte Spill
	movq	%rdi, -72(%rbp)                 # 8-byte Spill
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	movl	%edx, -44(%rbp)                 # 4-byte Spill
	movq	%r10, -96(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	leaq	(,%r13,8), %rsi
	callq	calloc@PLT
	movq	%rax, %rcx
	movl	$1, %eax
	testq	%rcx, %rcx
	je	.LBB81_115
# %bb.138:
	movq	-120(%rbp), %rax                # 8-byte Reload
	movq	%r14, 24(%rax)
	movq	-112(%rbp), %rax                # 8-byte Reload
	leaq	(,%r13,8), %rdx
	addq	%rdx, 48(%rax)
	testq	%r15, %r15
	movq	-88(%rbp), %r14                 # 8-byte Reload
	je	.LBB81_140
# %bb.139:
	shlq	$3, %r15
	movq	%rcx, %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	movq	%rcx, %r15
	callq	memcpy@PLT
	movq	%r15, %rcx
.LBB81_140:
	testq	%r14, %r14
	je	.LBB81_144
# %bb.141:
	movq	%r14, %rdi
	movq	%rcx, %r14
	movq	40(%r12), %rcx
	shlq	$3, %rcx
	movq	-120(%rbp), %r8                 # 8-byte Reload
	movq	24(%r8), %rax
	subq	%rcx, %rax
	jb	.LBB81_153
# %bb.142:
	movq	5640(%r8), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB81_153
# %bb.143:
	movq	%rax, 24(%r8)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
	movq	%r14, %rcx
.LBB81_144:
	movq	%r13, 40(%r12)
	movq	%rcx, 24(%r12)
	movq	-96(%rbp), %r10                 # 8-byte Reload
	movl	-44(%rbp), %edx                 # 4-byte Reload
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	movl	-80(%rbp), %r11d                # 4-byte Reload
	movl	-56(%rbp), %r8d                 # 4-byte Reload
	jmp	.LBB81_82
.LBB81_145:
	movl	-56(%rbp), %r9d                 # 4-byte Reload
.LBB81_146:
	leaq	(%r8,%r8,2), %rcx
	leaq	(%rsi,%rcx,8), %rcx
.LBB81_147:
	movq	%r14, (%rcx)
	movq	%rax, 8(%rcx)
	movl	%edx, 16(%rcx)
	movl	$0, 20(%rcx)
	incq	152(%r12)
	movq	-104(%rbp), %rax
	testb	%r9b, %r9b
	jne	.LBB81_148
.LBB81_104:
	testl	%edx, %edx
	je	.LBB81_106
.LBB81_105:
	movq	24(%r12), %rcx
	movq	32(%r12), %rdx
	leaq	1(%rdx), %rsi
	movq	%rsi, 32(%r12)
	movq	%rax, (%rcx,%rdx,8)
.LBB81_106:
	movq	%rax, (%r13)
	jmp	.LBB81_34
.LBB81_149:
	testq	%rdx, %rdx
	movq	-72(%rbp), %rax                 # 8-byte Reload
	je	.LBB81_153
# %bb.150:
	movq	(%rax), %rdi
	movq	8(%rbx), %rsi
	movq	-136(%rbp), %r8
	movq	%r14, %rcx
	callq	myl_rc_value_seed
	xorl	%eax, %eax
	jmp	.LBB81_100
.LBB81_151:
	xorl	%r8d, %r8d
	movq	-72(%rbp), %rdi                 # 8-byte Reload
	movq	48(%r12), %rax
	testq	%rax, %rax
	jne	.LBB81_62
	jmp	.LBB81_65
.LBB81_152:
	movq	%rdi, %rcx
	movq	%rax, %rdi
	movq	%rsi, %r9
	movq	%r8, %rsi
	movl	%r11d, %r8d
	callq	myl_rc_binding_find_slow
	movl	%r8d, %r11d
	movq	%rcx, %rdi
	movq	%r9, %rsi
	movq	%rax, %rbx
	testq	%rbx, %rbx
	jne	.LBB81_70
.LBB81_153:
	callq	myl_rc_invariant_failed
.Lfunc_end81:
	.size	schedule_clone, .Lfunc_end81-schedule_clone
	.cfi_endproc
                                        # -- End function
	.section	.text.transfer_pointer,"ax",@progbits
	.p2align	4                               # -- Begin function transfer_pointer
	.type	transfer_pointer,@function
transfer_pointer:                       # @transfer_pointer
.Lfunc_begin82:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	(%rdx), %rdx
	cmpl	$5, %ecx
	jne	.LBB82_2
# %bb.1:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	transfer_hold                   # TAILCALL
.LBB82_2:
	.cfi_def_cfa %rbp, 16
	testq	%rdx, %rdx
	je	.LBB82_23
# %bb.3:
	movq	-16(%rdx), %rcx
	testb	$2, %cl
	jne	.LBB82_23
# %bb.4:
	btq	$62, %rcx
	jb	.LBB82_7
# %bb.5:
	xorl	%eax, %eax
	btq	$60, %rcx
	jae	.LBB82_11
# %bb.6:
	movl	32(%rdi), %r8d
	jmp	.LBB82_21
.LBB82_7:
	movq	%rcx, %rax
	shrq	$40, %rax
	andl	$1048575, %eax                  # imm = 0xFFFFF
	movl	32(%rdi), %r8d
	cmpl	%r8d, %eax
	jbe	.LBB82_10
# %bb.8:
	movq	40(%rdi), %rax
	cmpl	$0, 168(%rax)
	movl	%r8d, %eax
	jne	.LBB82_21
# %bb.9:
	movl	$3, %eax
	jmp	.LBB82_24
.LBB82_10:
	btq	$60, %rcx
	jb	.LBB82_21
.LBB82_11:
	movabsq	$2305843009213693952, %r11      # imm = 0x2000000000000000
	movq	40(%rdi), %r13
	cmpl	$0, 172(%r13)
	sete	%r8b
	movq	%rcx, %r9
	shrq	$61, %r9
	andl	$1, %r9d
	orb	%r8b, %r9b
	jne	.LBB82_17
# %bb.12:
	movq	-8(%rdx), %r8
	cmpq	$myl_native_list_header_descriptor, %r8
	setne	%r9b
	cmpq	$dict_type, %r8
	setne	%r10b
	andb	%r9b, %r10b
	cmpq	$rc_dict_type, %r8
	setne	%r8b
	testb	%r8b, %r10b
	jne	.LBB82_17
# %bb.13:
	btq	$60, %rcx
	jb	.LBB82_45
# %bb.14:
	movq	176(%r13), %rbx
	movq	184(%r13), %r15
	movq	192(%r13), %rcx
	cmpq	%rcx, %r15
	jae	.LBB82_25
# %bb.15:
	movq	%rbx, %r14
	testq	%rbx, %rbx
	je	.LBB82_26
.LBB82_16:
	movq	%r14, 176(%r13)
	leaq	1(%r15), %rcx
	movq	%rcx, 184(%r13)
	movq	%rdx, (%r14,%r15,8)
.LBB82_17:
	cmpl	$0, 36(%rdi)
	jne	.LBB82_23
# %bb.18:
	testl	%eax, %eax
	je	.LBB82_27
# %bb.19:
	movq	40(%rdi), %rax
	cmpl	$0, 172(%rax)
	jne	.LBB82_23
# %bb.20:
	orq	%r11, -16(%rdx)
	jmp	.LBB82_23
.LBB82_21:
	movq	%rsi, %rbx
	movq	40(%rdi), %rcx
	cmpl	$0, 172(%rcx)
	cmovel	%r8d, %eax
	leaq	-112(%rbp), %rcx
	movq	%rdx, %rsi
	movl	%eax, %edx
	callq	schedule_clone
	testl	%eax, %eax
	jne	.LBB82_24
# %bb.22:
	movq	-112(%rbp), %rdx
	movq	%rbx, %rsi
.LBB82_23:
	movq	%rdx, (%rsi)
	xorl	%eax, %eax
.LBB82_24:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB82_25:
	.cfi_def_cfa %rbp, 16
	leaq	(%rcx,%rcx), %r8
	testq	%rcx, %rcx
	movl	$16, %r12d
	cmovneq	%r8, %r12
	cmpq	%rcx, %r12
	setb	%cl
	leaq	-1(%r11), %r8
	cmpq	%r8, %r12
	seta	%r8b
	orb	%cl, %r8b
	jne	.LBB82_26
# %bb.29:
	movq	(%rdi), %r8
	testq	%r8, %r8
	je	.LBB82_45
# %bb.30:
	testq	%r12, %r12
	je	.LBB82_45
# %bb.31:
	movq	5640(%r8), %r9
	testq	%r9, %r9
	je	.LBB82_45
# %bb.32:
	leaq	(,%r12,8), %r10
	movq	24(%r8), %r11
	addq	%r10, %r11
	jb	.LBB82_35
# %bb.33:
	movq	88(%r8), %rcx
	testq	%rcx, %rcx
	je	.LBB82_37
# %bb.34:
	cmpq	%rcx, %r11
	jbe	.LBB82_37
.LBB82_35:
	movl	$1, 108(%r8)
.LBB82_26:
	movl	$1, %eax
	jmp	.LBB82_24
.LBB82_27:
	movq	%rsi, %rbx
	movq	%rdx, %r14
	movq	%rdx, %rdi
	callq	myl_rc_owner_take
	testl	%eax, %eax
	jne	.LBB82_24
# %bb.28:
	movq	%rbx, %rsi
	movq	%r14, %rdx
	jmp	.LBB82_23
.LBB82_37:
	movq	%r11, -48(%rbp)                 # 8-byte Spill
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movq	%r8, -64(%rbp)                  # 8-byte Spill
	movq	%rax, -104(%rbp)                # 8-byte Spill
	movq	%rdi, -96(%rbp)                 # 8-byte Spill
	movq	%rdx, -88(%rbp)                 # 8-byte Spill
	movq	%rsi, -80(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%r10, %rsi
	callq	calloc@PLT
	movq	%rax, %r14
	testq	%rax, %rax
	movl	$1, %eax
	je	.LBB82_24
# %bb.38:
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	%rsi, 24(%rcx)
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	leaq	(,%r12,8), %r8
	addq	48(%rdx), %r8
	movq	%r8, 48(%rdx)
	testq	%r15, %r15
	je	.LBB82_40
# %bb.39:
	leaq	(,%r15,8), %rdx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movq	%r8, -72(%rbp)                  # 8-byte Spill
	callq	memcpy@PLT
	movq	-48(%rbp), %rsi                 # 8-byte Reload
	movq	-72(%rbp), %r8                  # 8-byte Reload
	movq	-56(%rbp), %rdx                 # 8-byte Reload
	movq	-64(%rbp), %rcx                 # 8-byte Reload
.LBB82_40:
	testq	%rbx, %rbx
	je	.LBB82_44
# %bb.41:
	movq	192(%r13), %rax
	shlq	$3, %rax
	subq	%rax, %rsi
	jb	.LBB82_45
# %bb.42:
	subq	%rax, %r8
	jb	.LBB82_45
# %bb.43:
	movq	%rsi, 24(%rcx)
	movq	%r8, 48(%rdx)
	movq	%rbx, %rdi
	callq	free@PLT
	movq	184(%r13), %r15
.LBB82_44:
	movq	%r12, 192(%r13)
	movq	-80(%rbp), %rsi                 # 8-byte Reload
	movq	-88(%rbp), %rdx                 # 8-byte Reload
	movq	-96(%rbp), %rdi                 # 8-byte Reload
	movq	-104(%rbp), %rax                # 8-byte Reload
	movabsq	$2305843009213693952, %r11      # imm = 0x2000000000000000
	jmp	.LBB82_16
.LBB82_45:
	callq	myl_rc_invariant_failed
.Lfunc_end82:
	.size	transfer_pointer, .Lfunc_end82-transfer_pointer
	.cfi_endproc
                                        # -- End function
	.section	.text.finish_clones,"ax",@progbits
	.p2align	4                               # -- Begin function finish_clones
	.type	finish_clones,@function
finish_clones:                          # @finish_clones
.Lfunc_begin83:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	40(%rdi), %rbx
	movl	$0, 36(%rdi)
	movq	8(%rbx), %rax
	testq	%rax, %rax
	je	.LBB83_88
# %bb.1:
	movq	%rdi, %r14
	movq	%rdi, -48(%rbp)                 # 8-byte Spill
	movq	%rbx, -144(%rbp)                # 8-byte Spill
	jmp	.LBB83_5
	.p2align	4
.LBB83_2:                               #   in Loop: Header=BB83_5 Depth=1
	decq	8(%rbx)
.LBB83_3:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-48(%rbp), %r14                 # 8-byte Reload
	movq	-144(%rbp), %rbx                # 8-byte Reload
.LBB83_4:                               #   in Loop: Header=BB83_5 Depth=1
	movq	8(%rbx), %rax
	testq	%rax, %rax
	je	.LBB83_88
.LBB83_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB83_8 Depth 2
                                        #     Child Loop BB83_34 Depth 2
                                        #       Child Loop BB83_46 Depth 3
                                        #         Child Loop BB83_50 Depth 4
                                        #     Child Loop BB83_63 Depth 2
	movq	(%rbx), %rdx
	leaq	(%rax,%rax,4), %rsi
	leaq	(%rdx,%rsi,8), %rcx
	movq	-24(%rdx,%rsi,8), %rsi
	movq	56(%rsi), %r10
	testq	%r10, %r10
	je	.LBB83_57
# %bb.6:                                #   in Loop: Header=BB83_5 Depth=1
	movq	$0, -160(%rbp)
	movq	(%r14), %rdi
	movq	-40(%rcx), %rsi
	movq	-32(%rcx), %rdx
	addq	$-16, %rcx
	leaq	-160(%rbp), %rax
	movq	%rax, (%rsp)
	leaq	-136(%rbp), %r8
	leaq	-192(%rbp), %r9
	callq	*%r10
	testl	%eax, %eax
	je	.LBB83_2
# %bb.7:                                #   in Loop: Header=BB83_5 Depth=1
	movq	-160(%rbp), %rax
	movq	%rax, -152(%rbp)                # 8-byte Spill
	movq	(%r14), %rbx
	movq	-192(%rbp), %rcx
	movq	5640(%rbx), %r15
	movq	88(%r15), %rax
	movq	96(%r15), %rdx
	movzbl	112(%r15), %esi
	movq	%rcx, %rdi
	movabsq	$-7046029254386353131, %r8      # imm = 0x9E3779B97F4A7C15
	imulq	%r8, %rdi
	shrxq	%rsi, %rdi, %rsi
	.p2align	4
.LBB83_8:                               #   Parent Loop BB83_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%rdx, %rsi
	movq	%rsi, %rdi
	shlq	$4, %rdi
	movq	(%rax,%rdi), %rdi
	cmpq	%rcx, %rdi
	je	.LBB83_11
# %bb.9:                                #   in Loop: Header=BB83_8 Depth=2
	testq	%rdi, %rdi
	je	.LBB83_93
# %bb.10:                               #   in Loop: Header=BB83_8 Depth=2
	incq	%rsi
	jmp	.LBB83_8
	.p2align	4
.LBB83_11:                              #   in Loop: Header=BB83_5 Depth=1
	shlq	$4, %rsi
	movq	8(%rax,%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB83_93
# %bb.12:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-136(%rbp), %rax
	testq	%rax, %rax
	je	.LBB83_93
# %bb.13:                               #   in Loop: Header=BB83_5 Depth=1
	movq	(%rax), %rax
	cmpq	(%rsi), %rax
	jne	.LBB83_93
# %bb.14:                               #   in Loop: Header=BB83_5 Depth=1
	movq	40(%rsi), %rcx
	cmpq	$2, %rcx
	movq	%rsi, -88(%rbp)                 # 8-byte Spill
	jb	.LBB83_30
# %bb.15:                               #   in Loop: Header=BB83_5 Depth=1
	movq	16(%r14), %r12
	cmpq	%r12, %rcx
	jbe	.LBB83_30
# %bb.16:                               #   in Loop: Header=BB83_5 Depth=1
	cmpq	$0, 24(%r14)
	jne	.LBB83_93
# %bb.17:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rcx, %rax
	shrq	$59, %rax
	jne	.LBB83_93
# %bb.18:                               #   in Loop: Header=BB83_5 Depth=1
	testq	%rbx, %rbx
	je	.LBB83_93
# %bb.19:                               #   in Loop: Header=BB83_5 Depth=1
	testq	%r15, %r15
	je	.LBB83_93
# %bb.20:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rcx, %r14
	shlq	$5, %r14
	movq	24(%rbx), %r13
	addq	%r14, %r13
	jb	.LBB83_90
# %bb.21:                               #   in Loop: Header=BB83_5 Depth=1
	movq	88(%rbx), %rax
	testq	%rax, %rax
	je	.LBB83_23
# %bb.22:                               #   in Loop: Header=BB83_5 Depth=1
	cmpq	%rax, %r13
	ja	.LBB83_90
.LBB83_23:                              #   in Loop: Header=BB83_5 Depth=1
	movq	%rcx, -72(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%r14, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB83_92
# %bb.24:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%r13, 24(%rbx)
	addq	48(%r15), %r14
	movq	%r14, 48(%r15)
	movq	-72(%rbp), %rdx                 # 8-byte Reload
	movq	%rdx, %rcx
	cmpq	$9, %r12
	jb	.LBB83_29
# %bb.25:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	8(%rcx), %rdi
	movq	%rdx, %rcx
	testq	%rdi, %rdi
	je	.LBB83_29
# %bb.26:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rax, -64(%rbp)                 # 8-byte Spill
	shlq	$5, %r12
	subq	%r12, %r13
	jb	.LBB83_93
# %bb.27:                               #   in Loop: Header=BB83_5 Depth=1
	subq	%r12, %r14
	jb	.LBB83_93
# %bb.28:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%r13, 24(%rbx)
	movq	%r14, 48(%r15)
	callq	free@PLT
	movq	-88(%rbp), %rax                 # 8-byte Reload
	movq	40(%rax), %rcx
	movq	-64(%rbp), %rax                 # 8-byte Reload
	movq	-72(%rbp), %rdx                 # 8-byte Reload
.LBB83_29:                              #   in Loop: Header=BB83_5 Depth=1
	movq	-48(%rbp), %r14                 # 8-byte Reload
	movq	%rax, 8(%r14)
	movq	%rdx, 16(%r14)
	movq	-88(%rbp), %rsi                 # 8-byte Reload
.LBB83_30:                              #   in Loop: Header=BB83_5 Depth=1
	movl	-112(%rbp), %eax
	movl	%eax, 32(%r14)
	cmpq	$0, -152(%rbp)                  # 8-byte Folded Reload
	je	.LBB83_3
# %bb.31:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-184(%rbp), %r13
	movq	-128(%rbp), %r14
	xorl	%edx, %edx
	movq	%rcx, -72(%rbp)                 # 8-byte Spill
	jmp	.LBB83_34
	.p2align	4
.LBB83_32:                              #   in Loop: Header=BB83_34 Depth=2
	movl	$transfer_pointer, %r8d
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	movq	%r14, %rdx
	movq	%r13, %rcx
	callq	visit
	testl	%eax, %eax
	jne	.LBB83_89
.LBB83_33:                              #   in Loop: Header=BB83_34 Depth=2
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	incq	%rdx
	movq	-88(%rbp), %rsi                 # 8-byte Reload
	movq	(%rsi), %rax
	addq	%rax, %r14
	addq	%rax, %r13
	cmpq	-152(%rbp), %rdx                # 8-byte Folded Reload
	movq	-72(%rbp), %rcx                 # 8-byte Reload
	je	.LBB83_3
.LBB83_34:                              #   Parent Loop BB83_5 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB83_46 Depth 3
                                        #         Child Loop BB83_50 Depth 4
	cmpq	$2, %rcx
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	ja	.LBB83_32
# %bb.35:                               #   in Loop: Header=BB83_34 Depth=2
	movl	8(%rsi), %eax
	movq	%rax, -80(%rbp)                 # 8-byte Spill
	decl	%eax
	cmpl	$4, %eax
	ja	.LBB83_41
# %bb.36:                               #   in Loop: Header=BB83_34 Depth=2
	jmpq	*.LJTI83_0(,%rax,8)
.LBB83_37:                              #   in Loop: Header=BB83_34 Depth=2
	movl	$1, %ecx
	jmp	.LBB83_42
.LBB83_38:                              #   in Loop: Header=BB83_34 Depth=2
	movq	16(%rsi), %rdx
	movq	24(%rsi), %rcx
	movq	32(%rsi), %r12
	addq	%r13, %r12
	movl	$4, %eax
	movq	%rax, -80(%rbp)                 # 8-byte Spill
	movq	$0, -56(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB83_45
.LBB83_39:                              #   in Loop: Header=BB83_34 Depth=2
	movq	16(%rsi), %rdx
	movq	24(%rsi), %rcx
	movl	$2, %eax
	movq	%rax, -80(%rbp)                 # 8-byte Spill
	movq	$0, -56(%rbp)                   # 8-byte Folded Spill
	jmp	.LBB83_44
.LBB83_40:                              #   in Loop: Header=BB83_34 Depth=2
	movq	16(%rsi), %rax
	movq	24(%rsi), %rcx
	movq	32(%rsi), %rdx
	movq	%rdx, -56(%rbp)                 # 8-byte Spill
	movl	8(%rax), %eax
	movq	%rax, -80(%rbp)                 # 8-byte Spill
	jmp	.LBB83_43
.LBB83_41:                              #   in Loop: Header=BB83_34 Depth=2
	xorl	%ecx, %ecx
.LBB83_42:                              #   in Loop: Header=BB83_34 Depth=2
	movq	$0, -56(%rbp)                   # 8-byte Folded Spill
.LBB83_43:                              #   in Loop: Header=BB83_34 Depth=2
	xorl	%edx, %edx
.LBB83_44:                              #   in Loop: Header=BB83_34 Depth=2
	xorl	%r12d, %r12d
.LBB83_45:                              #   in Loop: Header=BB83_34 Depth=2
	movq	%rcx, %r15
	negq	%r15
	xorl	%ebx, %ebx
	movq	%rcx, -104(%rbp)                # 8-byte Spill
	movq	%rdx, -96(%rbp)                 # 8-byte Spill
.LBB83_46:                              #   Parent Loop BB83_5 Depth=1
                                        #     Parent Loop BB83_34 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB83_50 Depth 4
	testq	%rdx, %rdx
	je	.LBB83_54
# %bb.47:                               #   in Loop: Header=BB83_46 Depth=3
	cmpq	%rcx, %rbx
	jae	.LBB83_33
# %bb.48:                               #   in Loop: Header=BB83_46 Depth=3
	leaq	(%rbx,%rbx,2), %rax
	leaq	(%rdx,%rax,8), %rax
	incq	%rbx
	jmp	.LBB83_50
	.p2align	4
.LBB83_49:                              #   in Loop: Header=BB83_50 Depth=4
	addq	$24, %rax
	leaq	(%r15,%rbx), %rcx
	incq	%rcx
	incq	%rbx
	cmpq	$1, %rcx
	je	.LBB83_33
.LBB83_50:                              #   Parent Loop BB83_5 Depth=1
                                        #     Parent Loop BB83_34 Depth=2
                                        #       Parent Loop BB83_46 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	movq	8(%rax), %rcx
	movl	8(%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB83_49
# %bb.51:                               #   in Loop: Header=BB83_50 Depth=4
	testq	%r12, %r12
	je	.LBB83_53
# %bb.52:                               #   in Loop: Header=BB83_50 Depth=4
	movl	16(%rax), %edx
	cmpl	(%r12), %edx
	jne	.LBB83_49
.LBB83_53:                              #   in Loop: Header=BB83_46 Depth=3
	movq	(%rax), %rdx
	jmp	.LBB83_56
	.p2align	4
.LBB83_54:                              #   in Loop: Header=BB83_46 Depth=3
	cmpq	%rcx, %rbx
	je	.LBB83_33
# %bb.55:                               #   in Loop: Header=BB83_46 Depth=3
	movq	%rbx, %rdx
	incq	%rbx
	imulq	-56(%rbp), %rdx                 # 8-byte Folded Reload
	movq	-80(%rbp), %rax                 # 8-byte Reload
	movl	%eax, %ecx
.LBB83_56:                              #   in Loop: Header=BB83_46 Depth=3
	leaq	(%r14,%rdx), %rsi
	addq	%r13, %rdx
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	callq	transfer_pointer
	testl	%eax, %eax
	movq	-104(%rbp), %rcx                # 8-byte Reload
	movq	-96(%rbp), %rdx                 # 8-byte Reload
	je	.LBB83_46
	jmp	.LBB83_89
	.p2align	4
.LBB83_57:                              #   in Loop: Header=BB83_5 Depth=1
	movq	48(%rsi), %r10
	testq	%r10, %r10
	je	.LBB83_60
# %bb.58:                               #   in Loop: Header=BB83_5 Depth=1
	movq	(%r14), %rdi
	movq	-40(%rcx), %rsi
	movq	-32(%rcx), %rdx
	addq	$-16, %rcx
	leaq	-136(%rbp), %r8
	leaq	-192(%rbp), %r9
	callq	*%r10
	testl	%eax, %eax
	je	.LBB83_86
# %bb.59:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-192(%rbp), %rax
	jmp	.LBB83_62
.LBB83_60:                              #   in Loop: Header=BB83_5 Depth=1
	movq	-40(%rcx), %rdi
	movq	-16(%rcx), %rdx
	movq	-16(%rdi), %rdi
	movq	%rdi, %r8
	shrq	$2, %r8
	btq	$62, %rdi
	movabsq	$274877906943, %rdi             # imm = 0x3FFFFFFFFF
	movabsq	$288230376151711743, %r9        # imm = 0x3FFFFFFFFFFFFFF
	cmovaeq	%r9, %rdi
	andq	%r8, %rdi
	cmpq	%rdi, %rdx
	je	.LBB83_87
# %bb.61:                               #   in Loop: Header=BB83_5 Depth=1
	movq	8(%rsi), %rax
	leaq	1(%rdx), %rsi
	movq	%rsi, -16(%rcx)
	imulq	(%rax), %rdx
	movq	-32(%rcx), %rsi
	leaq	(%rsi,%rdx), %rdi
	movl	-8(%rcx), %r8d
	movq	%rax, -136(%rbp)
	movq	%rdi, -128(%rbp)
	movq	%rsi, -120(%rbp)
	movl	%r8d, -112(%rbp)
	movl	$0, -108(%rbp)
	movq	-40(%rcx), %rcx
	addq	%rcx, %rdx
	movq	%rax, -192(%rbp)
	movq	%rdx, -184(%rbp)
	movq	%rcx, -176(%rbp)
	movq	$0, -168(%rbp)
.LBB83_62:                              #   in Loop: Header=BB83_5 Depth=1
	movq	(%r14), %r13
	movq	5640(%r13), %r15
	movq	88(%r15), %rcx
	movq	96(%r15), %rdx
	movzbl	112(%r15), %esi
	movq	%rax, %rdi
	movabsq	$-7046029254386353131, %r8      # imm = 0x9E3779B97F4A7C15
	imulq	%r8, %rdi
	shrxq	%rsi, %rdi, %rsi
	.p2align	4
.LBB83_63:                              #   Parent Loop BB83_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	andq	%rdx, %rsi
	movq	%rsi, %rdi
	shlq	$4, %rdi
	movq	(%rcx,%rdi), %rdi
	cmpq	%rax, %rdi
	je	.LBB83_66
# %bb.64:                               #   in Loop: Header=BB83_63 Depth=2
	testq	%rdi, %rdi
	je	.LBB83_93
# %bb.65:                               #   in Loop: Header=BB83_63 Depth=2
	incq	%rsi
	jmp	.LBB83_63
	.p2align	4
.LBB83_66:                              #   in Loop: Header=BB83_5 Depth=1
	shlq	$4, %rsi
	movq	8(%rcx,%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB83_93
# %bb.67:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-136(%rbp), %rax
	testq	%rax, %rax
	je	.LBB83_93
# %bb.68:                               #   in Loop: Header=BB83_5 Depth=1
	movq	(%rax), %rax
	cmpq	(%rsi), %rax
	jne	.LBB83_93
# %bb.69:                               #   in Loop: Header=BB83_5 Depth=1
	movq	40(%rsi), %r12
	cmpq	$2, %r12
	jb	.LBB83_85
# %bb.70:                               #   in Loop: Header=BB83_5 Depth=1
	movq	16(%r14), %rcx
	cmpq	%rcx, %r12
	jbe	.LBB83_85
# %bb.71:                               #   in Loop: Header=BB83_5 Depth=1
	cmpq	$0, 24(%r14)
	jne	.LBB83_93
# %bb.72:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%r12, %rax
	shrq	$59, %rax
	jne	.LBB83_93
# %bb.73:                               #   in Loop: Header=BB83_5 Depth=1
	testq	%r13, %r13
	je	.LBB83_93
# %bb.74:                               #   in Loop: Header=BB83_5 Depth=1
	testq	%r15, %r15
	je	.LBB83_93
# %bb.75:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%r12, %r14
	shlq	$5, %r14
	movq	24(%r13), %rbx
	addq	%r14, %rbx
	jb	.LBB83_91
# %bb.76:                               #   in Loop: Header=BB83_5 Depth=1
	movq	88(%r13), %rax
	testq	%rax, %rax
	je	.LBB83_78
# %bb.77:                               #   in Loop: Header=BB83_5 Depth=1
	cmpq	%rax, %rbx
	ja	.LBB83_91
.LBB83_78:                              #   in Loop: Header=BB83_5 Depth=1
	movq	%rcx, -64(%rbp)                 # 8-byte Spill
	movq	%rsi, -104(%rbp)                # 8-byte Spill
	movl	$1, %edi
	movq	%r14, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB83_92
# %bb.79:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rbx, 24(%r13)
	addq	48(%r15), %r14
	movq	%r14, 48(%r15)
	movq	-64(%rbp), %rsi                 # 8-byte Reload
	cmpq	$9, %rsi
	jb	.LBB83_84
# %bb.80:                               #   in Loop: Header=BB83_5 Depth=1
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	8(%rcx), %rdi
	testq	%rdi, %rdi
	je	.LBB83_84
# %bb.81:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rax, -96(%rbp)                 # 8-byte Spill
	shlq	$5, %rsi
	subq	%rsi, %rbx
	jb	.LBB83_93
# %bb.82:                               #   in Loop: Header=BB83_5 Depth=1
	subq	%rsi, %r14
	jb	.LBB83_93
# %bb.83:                               #   in Loop: Header=BB83_5 Depth=1
	movq	%rbx, 24(%r13)
	movq	%r14, 48(%r15)
	callq	free@PLT
	movq	-96(%rbp), %rax                 # 8-byte Reload
.LBB83_84:                              #   in Loop: Header=BB83_5 Depth=1
	movq	-48(%rbp), %r14                 # 8-byte Reload
	movq	%rax, 8(%r14)
	movq	%r12, 16(%r14)
	movq	-104(%rbp), %rsi                # 8-byte Reload
.LBB83_85:                              #   in Loop: Header=BB83_5 Depth=1
	movl	-112(%rbp), %eax
	movl	%eax, 32(%r14)
	movq	-128(%rbp), %rdx
	movq	-184(%rbp), %rcx
	movl	$transfer_pointer, %r8d
	movq	%r14, %rdi
	callq	visit
	testl	%eax, %eax
	movq	-144(%rbp), %rbx                # 8-byte Reload
	je	.LBB83_4
	jmp	.LBB83_89
.LBB83_86:                              #   in Loop: Header=BB83_5 Depth=1
	movq	8(%rbx), %rax
.LBB83_87:                              #   in Loop: Header=BB83_5 Depth=1
	decq	%rax
	movq	%rax, 8(%rbx)
	jmp	.LBB83_4
.LBB83_88:
	xorl	%eax, %eax
.LBB83_89:
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB83_90:
	.cfi_def_cfa %rbp, 16
	movl	$1, 108(%rbx)
	movl	$1, %eax
	jmp	.LBB83_89
.LBB83_91:
	movl	$1, 108(%r13)
.LBB83_92:
	movl	$1, %eax
	jmp	.LBB83_89
.LBB83_93:
	callq	myl_rc_invariant_failed
.Lfunc_end83:
	.size	finish_clones, .Lfunc_end83-finish_clones
	.cfi_endproc
	.section	.rodata.finish_clones,"a",@progbits
	.p2align	3, 0x0
.LJTI83_0:
	.quad	.LBB83_37
	.quad	.LBB83_39
	.quad	.LBB83_40
	.quad	.LBB83_38
	.quad	.LBB83_37
                                        # -- End function
	.section	.text.rollback_take,"ax",@progbits
	.p2align	4                               # -- Begin function rollback_take
	.type	rollback_take,@function
rollback_take:                          # @rollback_take
.Lfunc_begin84:
	.cfi_startproc
# %bb.0:
	movq	(%rsi), %rsi
	cmpq	%rsi, (%rdx)
	je	.LBB84_8
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	(%rdi), %rbx
	cmpl	$5, %ecx
	jne	.LBB84_6
# %bb.2:
	movq	%rbx, %rdi
	callq	myl_rc_hold_edge_release
	testq	%rbx, %rbx
	je	.LBB84_7
# %bb.3:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB84_7
# %bb.4:
	cmpq	$0, 200(%rax)
	je	.LBB84_7
# %bb.5:
	movq	%rbx, %rdi
	callq	myl_rc_drain
	jmp	.LBB84_7
.LBB84_6:
	movq	%rbx, %rdi
	callq	myl_rc_edge_release
.LBB84_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %rbp
.LBB84_8:
	xorl	%eax, %eax
	retq
.Lfunc_end84:
	.size	rollback_take, .Lfunc_end84-rollback_take
	.cfi_endproc
                                        # -- End function
	.section	.text.commit_take,"ax",@progbits
	.p2align	4                               # -- Begin function commit_take
	.type	commit_take,@function
commit_take:                            # @commit_take
.Lfunc_begin85:
	.cfi_startproc
# %bb.0:
	movq	%rsi, %rax
	movq	(%rdx), %rsi
	cmpq	(%rax), %rsi
	je	.LBB85_8
# %bb.1:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -24
	movq	(%rdi), %rbx
	cmpl	$5, %ecx
	jne	.LBB85_6
# %bb.2:
	movq	%rbx, %rdi
	callq	myl_rc_hold_edge_release
	testq	%rbx, %rbx
	je	.LBB85_7
# %bb.3:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB85_7
# %bb.4:
	cmpq	$0, 200(%rax)
	je	.LBB85_7
# %bb.5:
	movq	%rbx, %rdi
	callq	myl_rc_drain
	jmp	.LBB85_7
.LBB85_6:
	movq	%rbx, %rdi
	callq	myl_rc_edge_release
.LBB85_7:
	addq	$8, %rsp
	popq	%rbx
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbx
	.cfi_restore %rbp
.LBB85_8:
	xorl	%eax, %eax
	retq
.Lfunc_end85:
	.size	commit_take, .Lfunc_end85-commit_take
	.cfi_endproc
                                        # -- End function
	.section	.text.dispose_walk,"ax",@progbits
	.p2align	4                               # -- Begin function dispose_walk
	.type	dispose_walk,@function
dispose_walk:                           # @dispose_walk
.Lfunc_begin86:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movq	40(%rdi), %r14
	testl	%esi, %esi
	je	.LBB86_4
# %bb.1:
	cmpq	$0, 32(%r14)
	je	.LBB86_4
# %bb.2:
	xorl	%r15d, %r15d
	.p2align	4
.LBB86_3:                               # =>This Inner Loop Header: Depth=1
	movq	(%rbx), %rdi
	movq	24(%r14), %rax
	movq	(%rax,%r15,8), %rsi
	callq	myl_rc_construction_abort
	incq	%r15
	cmpq	32(%r14), %r15
	jb	.LBB86_3
.LBB86_4:
	movq	(%rbx), %rdi
	movq	176(%r14), %rax
	testq	%rax, %rax
	je	.LBB86_8
# %bb.5:
	movq	192(%r14), %rdx
	shlq	$3, %rdx
	movq	24(%rdi), %rcx
	subq	%rdx, %rcx
	jb	.LBB86_26
# %bb.6:
	movq	5640(%rdi), %rsi
	movq	48(%rsi), %r8
	subq	%rdx, %r8
	jb	.LBB86_26
# %bb.7:
	movq	%rcx, 24(%rdi)
	movq	%r8, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	(%rbx), %rdi
.LBB86_8:
	movq	24(%r14), %rax
	testq	%rax, %rax
	je	.LBB86_12
# %bb.9:
	movq	40(%r14), %rdx
	shlq	$3, %rdx
	movq	24(%rdi), %rcx
	subq	%rdx, %rcx
	jb	.LBB86_26
# %bb.10:
	movq	5640(%rdi), %rsi
	movq	48(%rsi), %r8
	subq	%rdx, %r8
	jb	.LBB86_26
# %bb.11:
	movq	%rcx, 24(%rdi)
	movq	%r8, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	(%rbx), %rdi
.LBB86_12:
	movq	48(%r14), %rax
	testq	%rax, %rax
	je	.LBB86_16
# %bb.13:
	movq	160(%r14), %rcx
	shlq	$3, %rcx
	leaq	(%rcx,%rcx,2), %rdx
	movq	24(%rdi), %rcx
	subq	%rdx, %rcx
	jb	.LBB86_26
# %bb.14:
	movq	5640(%rdi), %rsi
	movq	48(%rsi), %r8
	subq	%rdx, %r8
	jb	.LBB86_26
# %bb.15:
	movq	%rcx, 24(%rdi)
	movq	%r8, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	(%rbx), %rdi
.LBB86_16:
	movq	(%r14), %rax
	testq	%rax, %rax
	je	.LBB86_20
# %bb.17:
	movq	16(%r14), %rcx
	shlq	$3, %rcx
	leaq	(%rcx,%rcx,4), %rdx
	movq	24(%rdi), %rcx
	subq	%rdx, %rcx
	jb	.LBB86_26
# %bb.18:
	movq	5640(%rdi), %rsi
	movq	48(%rsi), %r8
	subq	%rdx, %r8
	jb	.LBB86_26
# %bb.19:
	movq	%rcx, 24(%rdi)
	movq	%r8, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	(%rbx), %rdi
.LBB86_20:
	movq	16(%rbx), %rcx
	cmpq	$9, %rcx
	jb	.LBB86_25
# %bb.21:
	movq	8(%rbx), %rax
	testq	%rax, %rax
	je	.LBB86_25
# %bb.22:
	shlq	$5, %rcx
	movq	24(%rdi), %rdx
	subq	%rcx, %rdx
	jb	.LBB86_26
# %bb.23:
	movq	5640(%rdi), %rsi
	movq	48(%rsi), %r8
	subq	%rcx, %r8
	jb	.LBB86_26
# %bb.24:
	movq	%rdx, 24(%rdi)
	movq	%r8, 48(%rsi)
	movq	%rax, %rdi
	callq	free@PLT
	movq	(%rbx), %rdi
.LBB86_25:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	myl_rc_drain                    # TAILCALL
.LBB86_26:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end86:
	.size	dispose_walk, .Lfunc_end86-dispose_walk
	.cfi_endproc
                                        # -- End function
	.section	.text.transfer_hold,"ax",@progbits
	.p2align	4                               # -- Begin function transfer_hold
	.type	transfer_hold,@function
transfer_hold:                          # @transfer_hold
.Lfunc_begin87:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$16, %rsp
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdx, %rdx
	je	.LBB87_1
# %bb.2:
	movabsq	$4611686018427387906, %r15      # imm = 0x4000000000000002
	movq	-16(%rdx), %rcx
	leaq	-2(%r15), %rax
	testq	%rax, %rcx
	je	.LBB87_23
# %bb.3:
	movq	%rcx, %r8
	shrq	$40, %r8
	andl	$1048575, %r8d                  # imm = 0xFFFFF
	movl	32(%rdi), %eax
	cmpl	%eax, %r8d
	jbe	.LBB87_23
# %bb.4:
	movq	40(%rdi), %rcx
	cmpl	$0, 168(%rcx)
	je	.LBB87_5
# %bb.6:
	leaq	-40(%rbp), %rcx
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rdx, %rsi
	movl	%eax, %edx
	callq	schedule_clone
	testl	%eax, %eax
	jne	.LBB87_33
# %bb.7:
	movq	%rbx, %rax
	movq	(%rbx), %rbx
	movq	-40(%rbp), %rsi
	testq	%rsi, %rsi
	je	.LBB87_16
# %bb.8:
	movq	-16(%rsi), %rcx
	testq	%r15, %rcx
	jne	.LBB87_16
# %bb.9:
	testq	%rbx, %rbx
	je	.LBB87_34
# %bb.10:
	cmpq	$0, 5640(%rbx)
	je	.LBB87_34
# %bb.11:
	testb	$1, %cl
	jne	.LBB87_34
# %bb.12:
	movl	-20(%rsi), %ecx
	movl	-24(%rsi), %edx
	orl	%ecx, %edx
	je	.LBB87_34
# %bb.13:
	cmpl	$-1, %ecx
	je	.LBB87_14
# %bb.15:
	incl	%ecx
	movl	%ecx, -20(%rsi)
	movq	(%rax), %rbx
.LBB87_16:
	movq	%rbx, %rdi
	movq	%rsi, %r15
	callq	myl_rc_edge_release
	testq	%rbx, %rbx
	je	.LBB87_17
# %bb.18:
	movb	$1, %r12b
	xorl	%eax, %eax
	movq	%r14, %rsi
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB87_22
.LBB87_20:
	cmpq	$0, 200(%rcx)
	je	.LBB87_22
# %bb.21:
	movq	%rbx, %rdi
	movl	%eax, %ebx
	callq	myl_rc_drain
	movl	%ebx, %eax
	movq	%r14, %rsi
.LBB87_22:
	testb	%r12b, %r12b
	movq	%r15, %rdx
	jne	.LBB87_32
	jmp	.LBB87_33
.LBB87_1:
	xorl	%edx, %edx
	jmp	.LBB87_32
.LBB87_23:
	cmpl	$0, 36(%rdi)
	jne	.LBB87_32
# %bb.24:
	testq	%r15, %rcx
	jne	.LBB87_32
# %bb.25:
	movq	(%rdi), %rax
	testq	%rax, %rax
	je	.LBB87_34
# %bb.26:
	cmpq	$0, 5640(%rax)
	je	.LBB87_34
# %bb.27:
	testb	$1, %cl
	jne	.LBB87_34
# %bb.28:
	movl	-20(%rdx), %eax
	movl	-24(%rdx), %ecx
	orl	%eax, %ecx
	je	.LBB87_34
# %bb.29:
	cmpl	$-1, %eax
	je	.LBB87_30
# %bb.31:
	incl	%eax
	movl	%eax, -20(%rdx)
	jmp	.LBB87_32
.LBB87_5:
	movl	$3, %eax
	jmp	.LBB87_33
.LBB87_17:
	movq	%r14, %rsi
	movq	%r15, %rdx
.LBB87_32:
	movq	%rdx, (%rsi)
	xorl	%eax, %eax
.LBB87_33:
	addq	$16, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB87_30:
	.cfi_def_cfa %rbp, 16
	movl	$2, %eax
	jmp	.LBB87_33
.LBB87_14:
	movq	%rbx, %rdi
	movq	%rsi, %r15
	callq	myl_rc_edge_release
	movq	%r14, %rsi
	movl	$2, %eax
	xorl	%r12d, %r12d
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	jne	.LBB87_20
	jmp	.LBB87_22
.LBB87_34:
	callq	myl_rc_invariant_failed
.Lfunc_end87:
	.size	transfer_hold, .Lfunc_end87-transfer_hold
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_owner_take,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_owner_take
	.type	myl_rc_owner_take,@function
myl_rc_owner_take:                      # @myl_rc_owner_take
.Lfunc_begin88:
	.cfi_startproc
# %bb.0:
	movq	-16(%rdi), %rcx
	xorl	%eax, %eax
	movabsq	$4611686018427387906, %rdx      # imm = 0x4000000000000002
	testq	%rdx, %rcx
	je	.LBB88_1
# %bb.7:
	retq
.LBB88_1:
	testb	$1, %cl
	jne	.LBB88_8
# %bb.2:
	movl	-24(%rdi), %ecx
	cmpl	$-1, %ecx
	je	.LBB88_3
# %bb.4:
	testl	%ecx, %ecx
	jne	.LBB88_6
# %bb.5:
	cmpl	$0, -20(%rdi)
	je	.LBB88_8
.LBB88_6:
	incl	%ecx
	movl	%ecx, -24(%rdi)
	retq
.LBB88_3:
	movl	$2, %eax
	retq
.LBB88_8:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	myl_rc_invariant_failed
.Lfunc_end88:
	.size	myl_rc_owner_take, .Lfunc_end88-myl_rc_owner_take
	.cfi_endproc
                                        # -- End function
	.section	.text.retain_pointer,"ax",@progbits
	.p2align	4                               # -- Begin function retain_pointer
	.type	retain_pointer,@function
retain_pointer:                         # @retain_pointer
.Lfunc_begin89:
	.cfi_startproc
# %bb.0:
	movq	(%rdx), %rdx
	testq	%rdx, %rdx
	je	.LBB89_5
# %bb.1:
	movq	-16(%rdx), %r8
	btq	$62, %r8
	jae	.LBB89_3
# %bb.2:
	movq	%r8, %r9
	shrq	$40, %r9
	andl	$1048575, %r9d                  # imm = 0xFFFFF
	movl	$3, %eax
	cmpl	32(%rdi), %r9d
	jbe	.LBB89_3
# %bb.16:
	retq
.LBB89_5:
	cmpl	$5, %ecx
	jne	.LBB89_14
# %bb.6:
	movq	$0, (%rsi)
	xorl	%eax, %eax
	retq
.LBB89_3:
	cmpl	$5, %ecx
	jne	.LBB89_7
# %bb.4:
	jmp	transfer_hold                   # TAILCALL
.LBB89_7:
	movabsq	$4611686018427387904, %rax      # imm = 0x4000000000000000
	addq	$2, %rax
	testq	%rax, %r8
	je	.LBB89_8
.LBB89_14:
	movq	%rdx, (%rsi)
	xorl	%eax, %eax
	retq
.LBB89_8:
	testb	$1, %r8b
	jne	.LBB89_17
# %bb.9:
	movl	-24(%rdx), %eax
	cmpl	$-1, %eax
	je	.LBB89_10
# %bb.11:
	testl	%eax, %eax
	jne	.LBB89_13
# %bb.12:
	cmpl	$0, -20(%rdx)
	je	.LBB89_17
.LBB89_13:
	incl	%eax
	movl	%eax, -24(%rdx)
	movq	%rdx, (%rsi)
	xorl	%eax, %eax
	retq
.LBB89_10:
	movl	$2, %eax
	retq
.LBB89_17:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	myl_rc_invariant_failed
.Lfunc_end89:
	.size	retain_pointer, .Lfunc_end89-retain_pointer
	.cfi_endproc
                                        # -- End function
	.section	.text.clone_payload,"ax",@progbits
	.p2align	4                               # -- Begin function clone_payload
	.type	clone_payload,@function
clone_payload:                          # @clone_payload
.Lfunc_begin90:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$520, %rsp                      # imm = 0x208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rcx, -48(%rbp)                 # 8-byte Spill
	movq	%rdi, %r14
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -144(%rbp)
	vmovups	%ymm0, -176(%rbp)
	vmovups	%ymm0, -208(%rbp)
	vmovups	%ymm0, -240(%rbp)
	vmovups	%ymm0, -272(%rbp)
	vmovups	%ymm0, -304(%rbp)
	movq	$0, -112(%rbp)
	movq	-16(%rsi), %rax
	xorl	%ebx, %ebx
	btq	$61, %rax
	movl	$0, %ecx
	jae	.LBB90_4
# %bb.1:
	movq	-8(%rsi), %rdi
	movl	$1, %ecx
	cmpq	$myl_native_list_header_descriptor, %rdi
	je	.LBB90_4
# %bb.2:
	cmpq	$dict_type, %rdi
	je	.LBB90_4
# %bb.3:
	xorl	%ecx, %ecx
	cmpq	$rc_dict_type, %rdi
	sete	%cl
.LBB90_4:
	movq	%rax, %r15
	shrq	$40, %r15
	andl	$1048575, %r15d                 # imm = 0xFFFFF
	cmpl	%edx, %r15d
	cmovael	%edx, %r15d
	movl	%ecx, -132(%rbp)
	btq	$62, %rax
	cmovael	%ebx, %r15d
	testl	%ecx, %ecx
	cmovel	%edx, %r15d
	movq	%r14, -104(%rbp)
	leaq	-560(%rbp), %rax
	movq	%rax, -96(%rbp)
	movq	$8, -88(%rbp)
	movq	$0, -80(%rbp)
	movl	%r15d, -72(%rbp)
	movl	$0, -68(%rbp)
	leaq	-304(%rbp), %r13
	movq	%r13, -64(%rbp)
	leaq	-104(%rbp), %rdi
	leaq	-56(%rbp), %rcx
	movl	%r15d, %edx
	vzeroupper
	callq	schedule_clone
	testl	%eax, %eax
	jne	.LBB90_5
# %bb.6:
	leaq	-104(%rbp), %rdi
	callq	finish_clones
	xorl	%r12d, %r12d
	movq	-64(%rbp), %r13
	testl	%eax, %eax
	je	.LBB90_8
# %bb.7:
	xorl	%ebx, %ebx
.LBB90_5:
	movl	%eax, %r12d
	movq	$0, 184(%r13)
	movq	-56(%rbp), %r13
	testl	%r15d, %r15d
	je	.LBB90_17
	jmp	.LBB90_23
.LBB90_8:
	movq	184(%r13), %rsi
	movb	$1, %bl
	testq	%rsi, %rsi
	je	.LBB90_16
# %bb.9:
	movabsq	$2305843009213693952, %rax      # imm = 0x2000000000000000
	movq	176(%r13), %rdx
	movl	%esi, %ecx
	andl	$3, %ecx
	cmpq	$4, %rsi
	jae	.LBB90_11
# %bb.10:
	xorl	%edi, %edi
	jmp	.LBB90_14
.LBB90_11:
	andq	$-4, %rsi
	xorl	%edi, %edi
	.p2align	4
.LBB90_12:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdx,%rdi,8), %r8
	orq	%rax, -16(%r8)
	movq	8(%rdx,%rdi,8), %r8
	orq	%rax, -16(%r8)
	movq	16(%rdx,%rdi,8), %r8
	orq	%rax, -16(%r8)
	movq	24(%rdx,%rdi,8), %r8
	orq	%rax, -16(%r8)
	addq	$4, %rdi
	cmpq	%rdi, %rsi
	jne	.LBB90_12
# %bb.13:
	testq	%rcx, %rcx
	je	.LBB90_24
.LBB90_14:
	leaq	(%rdx,%rdi,8), %rdx
	xorl	%r12d, %r12d
	xorl	%esi, %esi
	.p2align	4
.LBB90_15:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdx,%rsi,8), %rdi
	orq	%rax, -16(%rdi)
	incq	%rsi
	cmpq	%rsi, %rcx
	jne	.LBB90_15
.LBB90_16:
	movq	$0, 184(%r13)
	movq	-56(%rbp), %r13
	testl	%r15d, %r15d
	jne	.LBB90_23
.LBB90_17:
	testl	%r12d, %r12d
	je	.LBB90_23
# %bb.18:
	testq	%r13, %r13
	je	.LBB90_23
# %bb.19:
	movq	%r14, %rdi
	movq	%r13, %rsi
	callq	myl_rc_edge_release
	testq	%r14, %r14
	je	.LBB90_23
# %bb.20:
	movq	5640(%r14), %rax
	testq	%rax, %rax
	je	.LBB90_23
# %bb.21:
	cmpq	$0, 200(%rax)
	je	.LBB90_23
# %bb.22:
	movq	%r14, %rdi
	callq	myl_rc_drain
.LBB90_23:
	xorl	%esi, %esi
	testl	%r12d, %r12d
	setne	%sil
	leaq	-104(%rbp), %rdi
	callq	dispose_walk
	xorl	%eax, %eax
	testb	%bl, %bl
	cmovneq	%r13, %rax
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	movq	%rax, (%rcx)
	movl	%r12d, %eax
	addq	$520, %rsp                      # imm = 0x208
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB90_24:
	.cfi_def_cfa %rbp, 16
	xorl	%r12d, %r12d
	movq	$0, 184(%r13)
	movq	-56(%rbp), %r13
	testl	%r15d, %r15d
	je	.LBB90_17
	jmp	.LBB90_23
.Lfunc_end90:
	.size	clone_payload, .Lfunc_end90-clone_payload
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_storage_alloc,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_storage_alloc
	.type	myl_rc_storage_alloc,@function
myl_rc_storage_alloc:                   # @myl_rc_storage_alloc
.Lfunc_begin91:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB91_62
# %bb.1:
	movq	%rsi, %r14
	testq	%rsi, %rsi
	je	.LBB91_62
# %bb.2:
	movq	%rdi, %rbx
	movq	5640(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB91_62
# %bb.3:
	movl	%ecx, %r12d
	movq	%rdx, %r15
	testl	%ecx, %ecx
	setne	%al
	cmpq	$1, %rdx
	setne	%cl
	orb	%al, %cl
	jne	.LBB91_40
# %bb.4:
	cmpq	$allocate, (%rdi)
	je	.LBB91_5
.LBB91_40:
	cmpq	%r14, 272(%rdi)
	je	.LBB91_42
# %bb.41:
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	myl_rc_native_shape
	testq	%rax, %rax
	je	.LBB91_67
.LBB91_42:
	testl	%r12d, %r12d
	setne	%al
	cmpq	$2, %r15
	setb	%cl
	orb	%al, %cl
	jne	.LBB91_56
# %bb.43:
	movq	(%r14), %r13
	testq	%r13, %r13
	je	.LBB91_56
# %bb.44:
	cmpq	$16, 8(%r14)
	ja	.LBB91_56
# %bb.45:
	movq	5640(%rbx), %rax
	cmpq	$allocate, (%rax)
	jne	.LBB91_56
# %bb.46:
	cmpq	$8168, %r13                     # imm = 0x1FE8
	ja	.LBB91_47
# %bb.48:
	movl	$8168, %eax                     # imm = 0x1FE8
	xorl	%edx, %edx
	divl	%r13d
                                        # kill: def $eax killed $eax def $rax
	jmp	.LBB91_49
.LBB91_5:
	movq	32(%rdi), %r13
	cmpq	%r14, 528(%r13)
	je	.LBB91_6
# %bb.7:
	movl	52(%r14), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB91_10
# %bb.8:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%r14, (%rcx,%rax)
	jne	.LBB91_10
# %bb.9:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.LBB91_14
.LBB91_12:
	movl	192(%rax), %esi
	testl	%esi, %esi
	je	.LBB91_14
# %bb.13:
	decl	%esi
.LBB91_18:
	movq	%r14, 528(%r13)
	movq	%rsi, 536(%r13)
	movq	5648(%rbx,%rsi,8), %r15
	testq	%r15, %r15
	jne	.LBB91_20
.LBB91_23:
	movq	%rbx, %rdi
	callq	slab_refill
	movq	%rax, %r15
	testq	%rax, %rax
	jne	.LBB91_21
.LBB91_24:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB91_62
# %bb.25:
	cmpl	$0, 292(%rax)
	jne	.LBB91_67
# %bb.26:
	movl	$1, 292(%rax)
	jmp	.LBB91_67
.LBB91_6:
	movq	536(%r13), %rsi
	movq	5648(%rbx,%rsi,8), %r15
	testq	%r15, %r15
	je	.LBB91_23
.LBB91_20:
	movq	(%r15), %rax
	movq	%rax, 5648(%rbx,%rsi,8)
.LBB91_21:
	leaq	24(%r15), %rax
	movq	(%r14), %rdi
	movq	%rdi, %rcx
	shrq	$4, %rcx
	cmpq	$8, %rcx
	ja	.LBB91_69
# %bb.22:
	jmpq	*.LJTI91_0(,%rcx,8)
.LBB91_27:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 136(%r15)
.LBB91_28:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 120(%r15)
.LBB91_29:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 104(%r15)
.LBB91_30:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 88(%r15)
.LBB91_31:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 72(%r15)
.LBB91_32:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 56(%r15)
.LBB91_33:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 40(%r15)
.LBB91_34:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, (%rax)
.LBB91_35:
	movq	%rdi, %rdx
	andq	$15, %rdx
	je	.LBB91_38
# %bb.36:
	andq	$-16, %rdi
	addq	%rax, %rdi
.LBB91_37:
	xorl	%esi, %esi
	movq	%rax, %r12
	callq	memset@PLT
	movq	%r12, %rax
.LBB91_38:
	movq	$1, (%r15)
	movq	$4, 8(%r15)
	movq	%r14, 16(%r15)
.LBB91_39:
	vmovdqu	64(%rbx), %xmm0
	vpcmpeqd	%xmm1, %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 64(%rbx)
	jmp	.LBB91_68
.LBB91_47:
	xorl	%eax, %eax
.LBB91_49:
	cmpq	%rax, %r15
	ja	.LBB91_56
# %bb.50:
	imulq	%r15, %r13
	leaq	24(%r13), %rax
	movl	$32, %esi
	cmpq	$8192, %rax                     # imm = 0x2000
	ja	.LBB91_52
# %bb.51:
	leaq	39(%r13), %rax
	shrq	$4, %rax
	movzbl	class_of(%rax), %esi
.LBB91_52:
	movq	5648(%rbx,%rsi,8), %r12
	testq	%r12, %r12
	je	.LBB91_55
# %bb.53:
	movq	(%r12), %rax
	movq	%rax, 5648(%rbx,%rsi,8)
	jmp	.LBB91_54
.LBB91_69:
	movq	%rdi, %rdx
	movq	%rax, %rdi
	jmp	.LBB91_37
.LBB91_55:
	movq	%rbx, %rdi
	callq	slab_refill
	movq	%rax, %r12
	testq	%rax, %rax
	je	.LBB91_24
.LBB91_54:
	leaq	24(%r12), %rdi
	movq	%r13, %rsi
	callq	zero_payload
	leaq	24(%r12), %rax
	movq	$1, (%r12)
	shlq	$2, %r15
	movq	%r15, 8(%r12)
	movq	%r14, 16(%r12)
	jmp	.LBB91_39
.LBB91_10:
	movq	%r14, %rsi
	callq	myl_rc_binding_find_slow
	testq	%rax, %rax
	jne	.LBB91_12
.LBB91_14:
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	myl_rc_native_shape
	testq	%rax, %rax
	je	.LBB91_67
# %bb.15:
	cmpq	$16, 8(%r14)
	ja	.LBB91_56
# %bb.16:
	movq	(%r14), %rax
	cmpq	$8168, %rax                     # imm = 0x1FE8
	jbe	.LBB91_17
.LBB91_56:
	movq	%r14, -72(%rbp)
	movq	%r15, -64(%rbp)
	movl	%r12d, -56(%rbp)
	movl	$0, -52(%rbp)
	movq	5640(%rbx), %r8
	testq	%r8, %r8
	je	.LBB91_62
# %bb.57:
	movq	$0, -48(%rbp)
	movq	%r15, %rax
	mulq	(%r14)
	movl	$1, %ecx
	jo	.LBB91_65
# %bb.58:
	xorl	%edx, %edx
	testl	%r12d, %r12d
	sete	%dl
	leaq	16(,%rdx,8), %rdx
	addq	%rdx, %rax
	jb	.LBB91_65
# %bb.59:
	movl	$3, %ecx
	cmpl	112(%rbx), %r12d
	ja	.LBB91_65
# %bb.60:
	leaq	-72(%rbp), %rsi
	leaq	-48(%rbp), %rdx
	movq	%rbx, %rdi
	callq	*(%r8)
	movl	%eax, %ecx
	movq	-48(%rbp), %rax
	testl	%ecx, %ecx
	je	.LBB91_61
# %bb.63:
	testq	%rax, %rax
	jne	.LBB91_62
# %bb.64:
	movq	5640(%rbx), %r8
	testq	%r8, %r8
	je	.LBB91_62
.LBB91_65:
	cmpl	$0, 292(%r8)
	jne	.LBB91_67
# %bb.66:
	movl	%ecx, 292(%r8)
.LBB91_67:
	xorl	%eax, %eax
.LBB91_68:
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB91_61:
	.cfi_def_cfa %rbp, 16
	testq	%rax, %rax
	jne	.LBB91_68
.LBB91_62:
	callq	myl_rc_invariant_failed
.LBB91_17:
	addq	$39, %rax
	shrq	$4, %rax
	movzbl	class_of(%rax), %r15d
	movq	5640(%rbx), %rdi
	movq	%r14, %rsi
	callq	myl_rc_binding_find
	movq	%r15, %rsi
	movl	%esi, %ecx
	incl	%ecx
	movl	%ecx, 192(%rax)
	jmp	.LBB91_18
.Lfunc_end91:
	.size	myl_rc_storage_alloc, .Lfunc_end91-myl_rc_storage_alloc
	.cfi_endproc
	.section	.rodata.myl_rc_storage_alloc,"a",@progbits
	.p2align	3, 0x0
.LJTI91_0:
	.quad	.LBB91_35
	.quad	.LBB91_34
	.quad	.LBB91_33
	.quad	.LBB91_32
	.quad	.LBB91_31
	.quad	.LBB91_30
	.quad	.LBB91_29
	.quad	.LBB91_28
	.quad	.LBB91_27
                                        # -- End function
	.section	.text.allocate,"ax",@progbits
	.p2align	4                               # -- Begin function allocate
	.type	allocate,@function
allocate:                               # @allocate
.Lfunc_begin92:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rdi, %rbx
	movq	$0, (%rdx)
	movl	16(%rsi), %r15d
	movq	(%rsi), %r13
	testq	%r15, %r15
	je	.LBB92_3
# %bb.1:
	movq	8(%rsi), %rsi
	movq	%rsi, %rax
	shrq	$38, %rax
	setne	%al
	cmpl	$1048576, %r15d                 # imm = 0x100000
	setae	%cl
	orb	%al, %cl
	je	.LBB92_13
.LBB92_2:
	xorl	%ecx, %ecx
	jmp	.LBB92_146
.LBB92_3:
	movl	$1, %eax
	testq	%r13, %r13
	je	.LBB92_147
# %bb.4:
	cmpq	$16, 8(%r13)
	ja	.LBB92_147
# %bb.5:
	movq	8(%rsi), %rdi
	movq	%rdi, %rcx
	shrq	$58, %rcx
	jne	.LBB92_147
# %bb.6:
	movq	(%r13), %r14
	testq	%r14, %r14
	je	.LBB92_8
# %bb.7:
	movq	$-25, %rax
	movq	%rdx, %rcx
	xorl	%edx, %edx
	divq	%r14
	movq	%rcx, %rdx
	movq	%rax, %rcx
	movl	$1, %eax
	cmpq	%rcx, %rdi
	ja	.LBB92_147
.LBB92_8:
	testq	%rbx, %rbx
	je	.LBB92_156
# %bb.9:
	cmpq	$0, 5640(%rbx)
	je	.LBB92_156
# %bb.10:
	imulq	%rdi, %r14
	leaq	24(%r14), %r12
	cmpq	$8192, %r12                     # imm = 0x2000
	ja	.LBB92_75
# %bb.11:
	movq	%rsi, %r12
	movq	%rdx, %r13
	leaq	39(%r14), %rax
	shrq	$4, %rax
	movzbl	class_of(%rax), %esi
	movq	5648(%rbx,%rsi,8), %r15
	testq	%r15, %r15
	je	.LBB92_106
# %bb.12:
	movq	(%r15), %rax
	movq	%rax, 5648(%rbx,%rsi,8)
	jmp	.LBB92_107
.LBB92_13:
	movl	%r15d, %r10d
	movq	(%r13), %r14
	movq	%rsi, -112(%rbp)                # 8-byte Spill
	imulq	%rsi, %r14
	cmpq	$1, %r14
	movq	%r14, %r11
	adcq	$0, %r11
	cmpl	$0, 104(%rbx)
	je	.LBB92_15
# %bb.14:
	cmpl	$0, 116(%rbx)
	je	.LBB92_22
.LBB92_15:
	movq	4512(%rbx), %rax
	testq	%rax, %rax
	je	.LBB92_26
.LBB92_16:
	movq	1472(%rbx), %rcx
	movq	1480(%rbx), %rsi
	movq	%rsi, %rdi
	subq	%rcx, %rdi
	subq	$16, %rdi
	setb	%r8b
	cmpl	%r10d, 32(%rax)
	jne	.LBB92_21
# %bb.17:
	testb	%r8b, %r8b
	jne	.LBB92_21
# %bb.18:
	cmpq	%rdi, %r11
	ja	.LBB92_21
# %bb.19:
	shlq	$40, %r15
	movq	-112(%rbp), %rdi                # 8-byte Reload
	leaq	(%r15,%rdi,4), %rdi
	movabsq	$4611686018427387904, %r8       # imm = 0x4000000000000000
	orq	%rdi, %r8
	movq	%r8, (%rcx)
	movq	%r13, 8(%rcx)
	incq	24(%rax)
	leaq	80(%rax), %rdi
	subq	%rdi, %r11
	leaq	(%r11,%rcx), %rdi
	addq	$31, %rdi
	andq	$-16, %rdi
	movq	8(%rax), %r8
	addq	$-80, %r8
	cmpq	%r8, %rdi
	leaq	80(%rax,%rdi), %rax
	cmovbq	%rax, %rsi
	movq	%rsi, 1472(%rbx)
	vmovdqu	64(%rbx), %xmm0
	vpcmpeqd	%xmm1, %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 64(%rbx)
	incq	144(%rbx)
.LBB92_20:
	addq	$16, %rcx
	jmp	.LBB92_146
.LBB92_21:
	leaq	1472(%rbx), %rsi
	subq	%rax, %rcx
	addq	$-80, %rcx
	movq	%rcx, 16(%rax)
	movq	$0, 4512(%rbx)
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, (%rsi)
	jmp	.LBB92_26
.LBB92_22:
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%rdx, %r12
	cmpq	$0, 5640(%rbx)
	je	.LBB92_24
# %bb.23:
	movq	%rbx, %rdi
	callq	myl_rc_drain
	jmp	.LBB92_25
.LBB92_24:
	movq	%rbx, %rdi
	callq	collect
.LBB92_25:
	movq	%r12, %rdx
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
	movq	4512(%rbx), %rax
	testq	%rax, %rax
	jne	.LBB92_16
.LBB92_26:
	cmpq	%r15, 4584(%rbx)
	jbe	.LBB92_31
# %bb.27:
	movq	1240(%rbx), %rax
	movq	(%rax,%r15,8), %r12
	testq	%r12, %r12
	je	.LBB92_31
# %bb.28:
	movq	16(%r12), %rax
	cmpq	$-15, %rax
	jb	.LBB92_61
# %bb.29:
	movq	8(%r12), %rcx
	jmp	.LBB92_63
.LBB92_31:
	xorl	%eax, %eax
	cmpq	$-112, %r14
	ja	.LBB92_2
	jmp	.LBB92_32
.LBB92_61:
	addq	$15, %rax
	andq	$-16, %rax
	movq	8(%r12), %rcx
	leaq	-80(%rcx), %rsi
	subq	%rax, %rsi
	jb	.LBB92_63
# %bb.62:
	subq	$16, %rsi
	setb	%dil
	cmpq	%rsi, %r11
	seta	%sil
	orb	%dil, %sil
	cmpb	$1, %sil
	jne	.LBB92_132
.LBB92_63:
	cmpq	$524288, %rcx                   # imm = 0x80000
	movl	$524288, %eax                   # imm = 0x80000
	cmovbq	%rcx, %rax
	addl	%eax, %eax
	cmpq	$-112, %r14
	ja	.LBB92_2
.LBB92_32:
	movq	%r13, -88(%rbp)                 # 8-byte Spill
	leaq	111(%r11), %r12
	andq	$-16, %r12
	cmpq	%r12, %rax
	cmovbeq	%r12, %rax
	cmpq	$65537, %rax                    # imm = 0x10001
	movl	$65536, %r9d                    # imm = 0x10000
	cmovaeq	%rax, %r9
	movq	5640(%rbx), %r13
	movq	4592(%rbx), %rcx
	testq	%r13, %r13
	movq	%r9, -72(%rbp)                  # 8-byte Spill
	je	.LBB92_43
# %bb.33:
	cmpq	%r15, %rcx
	jbe	.LBB92_65
# %bb.34:
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	movq	$0, -104(%rbp)                  # 8-byte Folded Spill
	movq	-88(%rbp), %r13                 # 8-byte Reload
.LBB92_35:
	leaq	1248(%rbx), %r14
	movq	1248(%rbx), %rdi
	testq	%rdi, %rdi
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	je	.LBB92_73
# %bb.36:
	xorl	%eax, %eax
	movq	%rdi, %r8
	movq	%r14, %rcx
	jmp	.LBB92_39
	.p2align	4
.LBB92_37:                              #   in Loop: Header=BB92_39 Depth=1
	movq	%rsi, %rax
.LBB92_38:                              #   in Loop: Header=BB92_39 Depth=1
	movq	(%rcx), %r8
	testq	%r8, %r8
	je	.LBB92_71
.LBB92_39:                              # =>This Inner Loop Header: Depth=1
	movq	%rcx, %rsi
	movq	%r8, %rcx
	movq	8(%r8), %r8
	cmpq	%r12, %r8
	jb	.LBB92_38
# %bb.40:                               #   in Loop: Header=BB92_39 Depth=1
	cmpq	%r9, %r8
	ja	.LBB92_38
# %bb.41:                               #   in Loop: Header=BB92_39 Depth=1
	testq	%rax, %rax
	je	.LBB92_37
# %bb.42:                               #   in Loop: Header=BB92_39 Depth=1
	movq	(%rax), %r9
	cmpq	8(%r9), %r8
	movq	-72(%rbp), %r9                  # 8-byte Reload
	ja	.LBB92_37
	jmp	.LBB92_38
.LBB92_43:
	cmpq	%r15, %rcx
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	ja	.LBB92_48
# %bb.44:
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	testq	%rcx, %rcx
	movl	$8, %eax
	cmovneq	%rcx, %rax
	.p2align	4
.LBB92_45:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r13
	addq	%rax, %rax
	cmpq	%r15, %r13
	jbe	.LBB92_45
# %bb.46:
	movq	1240(%rbx), %rdi
	leaq	(,%r13,8), %rsi
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB92_105
# %bb.47:
	movq	4592(%rbx), %rcx
	leaq	(%rax,%rcx,8), %rdi
	movq	%r13, %rdx
	subq	%rcx, %rdx
	shlq	$3, %rdx
	xorl	%esi, %esi
	movq	%rax, %r14
	callq	memset@PLT
	movq	%r14, 1240(%rbx)
	movq	%r13, 4592(%rbx)
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
	movq	-72(%rbp), %r9                  # 8-byte Reload
.LBB92_48:
	movq	24(%rbx), %rcx
	movq	88(%rbx), %rax
	movq	%rax, %rsi
	subq	%rcx, %rsi
	jb	.LBB92_50
# %bb.49:
	cmpq	%rsi, %r12
	jbe	.LBB92_52
.LBB92_50:
	cmpl	$0, 116(%rbx)
	jne	.LBB92_52
# %bb.51:
	movq	%rbx, %rdi
	movq	%rdx, %r14
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	callq	myl_native_heap_collect
	movq	-72(%rbp), %r9                  # 8-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
	movq	%r14, %rdx
	movq	24(%rbx), %rcx
	movq	88(%rbx), %rax
.LBB92_52:
	xorl	%esi, %esi
	subq	%rcx, %rax
	cmovaeq	%rax, %rsi
	cmpq	%rsi, %r12
	ja	.LBB92_70
# %bb.53:
	movq	%rsi, %r14
	andq	$-16, %r14
	cmpq	%rsi, %r9
	cmovbq	%r9, %r14
	movq	1248(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB92_85
# %bb.54:
	leaq	1248(%rbx), %rcx
	xorl	%eax, %eax
	jmp	.LBB92_57
.LBB92_55:                              #   in Loop: Header=BB92_57 Depth=1
	movq	%rdi, %rax
.LBB92_56:                              #   in Loop: Header=BB92_57 Depth=1
	movq	(%rcx), %rsi
	testq	%rsi, %rsi
	je	.LBB92_83
.LBB92_57:                              # =>This Inner Loop Header: Depth=1
	movq	%rcx, %rdi
	movq	%rsi, %rcx
	movq	8(%rsi), %rsi
	cmpq	%r12, %rsi
	jb	.LBB92_56
# %bb.58:                               #   in Loop: Header=BB92_57 Depth=1
	cmpq	%r14, %rsi
	ja	.LBB92_56
# %bb.59:                               #   in Loop: Header=BB92_57 Depth=1
	testq	%rax, %rax
	je	.LBB92_55
# %bb.60:                               #   in Loop: Header=BB92_57 Depth=1
	movq	(%rax), %r8
	cmpq	8(%r8), %rsi
	ja	.LBB92_55
	jmp	.LBB92_56
.LBB92_65:
	testq	%rcx, %rcx
	movl	$8, %eax
	cmovneq	%rcx, %rax
	.p2align	4
.LBB92_66:                              # =>This Inner Loop Header: Depth=1
	movq	%rax, %r14
	addq	%rax, %rax
	cmpq	%r15, %r14
	jbe	.LBB92_66
# %bb.67:
	leaq	(,%r14,8), %rsi
	movq	24(%rbx), %rdi
	addq	%rsi, %rdi
	jb	.LBB92_70
# %bb.68:
	movq	88(%rbx), %rax
	testq	%rax, %rax
	je	.LBB92_101
# %bb.69:
	cmpq	%rax, %rdi
	jbe	.LBB92_101
.LBB92_70:
	movl	$1, 108(%rbx)
	xorl	%ecx, %ecx
	jmp	.LBB92_146
.LBB92_71:
	testq	%rax, %rax
	je	.LBB92_73
# %bb.72:
	movq	(%rax), %r12
	movq	(%r12), %rcx
	movq	%rcx, (%rax)
	decq	192(%rbx)
	movq	8(%r12), %rax
	subq	%rax, 200(%rbx)
	leaq	80(%r12), %rdi
	movq	16(%r12), %rax
	xorl	%esi, %esi
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	movq	%rax, %rdx
	movl	%r10d, %r14d
	callq	memset@PLT
	movl	%r14d, %r10d
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	%xmm0, 16(%r12)
	movl	$160, %eax
	jmp	.LBB92_120
.LBB92_73:
	movq	24(%rbx), %rsi
	movq	88(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB92_92
# %bb.74:
	xorl	%eax, %eax
	subq	%rsi, %rcx
	cmovaeq	%rcx, %rax
	jmp	.LBB92_93
.LBB92_75:
	cmpq	$-57, %r12
	ja	.LBB92_147
# %bb.76:
	movq	%rsi, -112(%rbp)                # 8-byte Spill
	movq	%rdx, %r13
	addq	$80, %r14
	movq	24(%rbx), %rax
	movq	%rax, %rcx
	addq	%r14, %rcx
	jb	.LBB92_79
# %bb.77:
	movq	88(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB92_108
# %bb.78:
	subq	%rax, %rcx
	setb	%al
	cmpq	%rcx, %r14
	seta	%cl
	orb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB92_108
.LBB92_79:
	movq	%rbx, %rdi
	callq	trim_empty
	movq	24(%rbx), %rax
	movq	%rax, %rcx
	addq	%r14, %rcx
	jb	.LBB92_82
# %bb.80:
	movq	88(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB92_108
# %bb.81:
	subq	%rax, %rcx
	setb	%al
	cmpq	%rcx, %r14
	seta	%cl
	orb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB92_108
.LBB92_82:
	movl	$1, 108(%rbx)
	movl	$1, %eax
	jmp	.LBB92_147
.LBB92_83:
	testq	%rax, %rax
	je	.LBB92_85
# %bb.84:
	movq	%rdx, %r13
	movq	(%rax), %r12
	movq	(%r12), %rcx
	movq	%rcx, (%rax)
	decq	192(%rbx)
	movq	8(%r12), %rax
	subq	%rax, 200(%rbx)
	leaq	80(%r12), %rdi
	movq	16(%r12), %rdx
	xorl	%esi, %esi
	movq	%r11, %r14
	callq	memset@PLT
	movq	%r14, %r11
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqa	%xmm0, 16(%r12)
	incq	160(%rbx)
	movq	8(%r12), %r14
	movl	-44(%rbp), %r10d                # 4-byte Reload
	jmp	.LBB92_87
.LBB92_85:
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movq	%rdx, %r13
	movl	$1, %edi
	movq	%r14, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB92_143
.LBB92_86:
	movq	%rax, %r12
	movq	%r14, 8(%rax)
	incq	152(%rbx)
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
.LBB92_87:
	addq	%r14, 24(%rbx)
	movq	1240(%rbx), %rax
	movq	(%rax,%r15,8), %rcx
	movq	%rcx, (%r12)
	movl	%r10d, 32(%r12)
	movq	%r12, (%rax,%r15,8)
	cmpq	%r15, 4584(%rbx)
	ja	.LBB92_89
# %bb.88:
	leaq	1(%r15), %rax
	movq	%rax, 4584(%rbx)
.LBB92_89:
	incq	168(%rbx)
	movq	176(%rbx), %rax
	addq	8(%r12), %rax
	movq	%rax, 176(%rbx)
	cmpq	184(%rbx), %rax
	movq	%r13, %rdx
	jbe	.LBB92_91
# %bb.90:
	movq	%rax, 184(%rbx)
.LBB92_91:
	xorl	%eax, %eax
	movq	-88(%rbp), %r13                 # 8-byte Reload
	jmp	.LBB92_132
.LBB92_92:
	movq	%rsi, %rax
	notq	%rax
.LBB92_93:
	xorl	%ecx, %ecx
	cmpq	%rax, %r12
	cmovbeq	%rdi, %rcx
	movq	%rcx, -96(%rbp)                 # 8-byte Spill
	testq	%rdi, %rdi
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	je	.LBB92_112
# %bb.94:
	cmpq	%rax, %r12
	jbe	.LBB92_112
# %bb.95:
	movq	%rdx, %r13
	jmp	.LBB92_97
	.p2align	4
.LBB92_96:                              #   in Loop: Header=BB92_97 Depth=1
	callq	free@PLT
	movq	(%r14), %rdi
	testq	%rdi, %rdi
	je	.LBB92_99
.LBB92_97:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rax
	movq	%rax, 1248(%rbx)
	cmpq	$0, 5640(%rbx)
	je	.LBB92_96
# %bb.98:                               #   in Loop: Header=BB92_97 Depth=1
	movq	8(%rdi), %rax
	subq	%rax, 24(%rbx)
	jmp	.LBB92_96
.LBB92_99:
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 192(%rbx)
	movq	24(%rbx), %rsi
	movq	88(%rbx), %rax
	testq	%rax, %rax
	je	.LBB92_110
# %bb.100:
	xorl	%edx, %edx
	subq	%rsi, %rax
	movl	$0, %ecx
	movq	%rcx, -96(%rbp)                 # 8-byte Spill
	cmovbq	%rdx, %rax
	jmp	.LBB92_111
.LBB92_101:
	movq	%rdi, -96(%rbp)                 # 8-byte Spill
	movq	%rcx, -80(%rbp)                 # 8-byte Spill
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB92_105
# %bb.102:
	movq	-96(%rbp), %rcx                 # 8-byte Reload
	movq	%rcx, 24(%rbx)
	leaq	(,%r14,8), %rcx
	addq	%rcx, 48(%r13)
	movq	-80(%rbp), %rdx                 # 8-byte Reload
	testq	%rdx, %rdx
	movq	%rax, -104(%rbp)                # 8-byte Spill
	je	.LBB92_104
# %bb.103:
	movq	1240(%rbx), %rsi
	shlq	$3, %rdx
	movq	%rax, %rdi
	callq	memcpy@PLT
.LBB92_104:
	movq	%r14, -80(%rbp)                 # 8-byte Spill
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	-88(%rbp), %r13                 # 8-byte Reload
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
	movq	-72(%rbp), %r9                  # 8-byte Reload
	jmp	.LBB92_35
.LBB92_105:
	xorl	%ecx, %ecx
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	jmp	.LBB92_146
.LBB92_106:
	movq	%rbx, %rdi
	callq	slab_refill
	movq	%rax, %r15
	movl	$1, %eax
	testq	%r15, %r15
	je	.LBB92_147
.LBB92_107:
	leaq	24(%r15), %rdi
	movq	%r14, %rsi
	callq	zero_payload
	xorl	%ecx, %ecx
	movq	%r12, %rax
	jmp	.LBB92_155
.LBB92_108:
	movq	%r14, %rdi
	callq	large_block
	testq	%rax, %rax
	je	.LBB92_150
# %bb.109:
	movq	%rax, %r15
	jmp	.LBB92_151
.LBB92_110:
	movq	%rsi, %rax
	notq	%rax
	movq	$0, -96(%rbp)                   # 8-byte Folded Spill
.LBB92_111:
	movq	%r13, %rdx
	movq	-72(%rbp), %r9                  # 8-byte Reload
.LBB92_112:
	cmpq	%rax, %r12
	jbe	.LBB92_118
# %bb.113:
	movl	$1, 108(%rbx)
.LBB92_114:
	movq	-104(%rbp), %rdi                # 8-byte Reload
	testq	%rdi, %rdi
	je	.LBB92_2
# %bb.115:
	movq	-80(%rbp), %rsi                 # 8-byte Reload
	shlq	$3, %rsi
	movq	24(%rbx), %rax
	subq	%rsi, %rax
	jb	.LBB92_156
# %bb.116:
	movq	%rdx, %r14
	movq	5640(%rbx), %rcx
	movq	48(%rcx), %rdx
	subq	%rsi, %rdx
	jb	.LBB92_156
# %bb.117:
	movq	%rax, 24(%rbx)
	movq	%rdx, 48(%rcx)
	callq	free@PLT
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	jmp	.LBB92_146
.LBB92_118:
	movq	%r14, %r13
	movq	%rsi, -72(%rbp)                 # 8-byte Spill
	movq	%rax, %r14
	andq	$-16, %r14
	cmpq	%rax, %r9
	cmovbq	%r9, %r14
	movl	$1, %edi
	movq	%r14, %rsi
	movq	%rdx, -64(%rbp)                 # 8-byte Spill
	callq	calloc@PLT
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	%rax, %r12
	testq	%rax, %rax
	je	.LBB92_138
.LBB92_119:
	movq	%r14, 8(%r12)
	movq	-72(%rbp), %r13                 # 8-byte Reload
	addq	%r14, %r13
	movq	%r13, 24(%rbx)
	movl	$152, %eax
	movq	-88(%rbp), %r13                 # 8-byte Reload
.LBB92_120:
	incq	(%rbx,%rax)
	movq	1240(%rbx), %rdi
	cmpq	$0, -104(%rbp)                  # 8-byte Folded Reload
	je	.LBB92_126
# %bb.121:
	testq	%rdi, %rdi
	movq	-56(%rbp), %r11                 # 8-byte Reload
	je	.LBB92_125
# %bb.122:
	movl	%r10d, -44(%rbp)                # 4-byte Spill
	movq	4592(%rbx), %rcx
	shlq	$3, %rcx
	movq	24(%rbx), %rax
	subq	%rcx, %rax
	jb	.LBB92_156
# %bb.123:
	movq	%rdx, %r14
	movq	5640(%rbx), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB92_156
# %bb.124:
	movq	%rax, 24(%rbx)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
	movq	%r14, %rdx
	movl	-44(%rbp), %r10d                # 4-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
.LBB92_125:
	movq	-104(%rbp), %rdi                # 8-byte Reload
	movq	%rdi, 1240(%rbx)
	movq	-80(%rbp), %rax                 # 8-byte Reload
	movq	%rax, 4592(%rbx)
	jmp	.LBB92_127
.LBB92_126:
	movq	-56(%rbp), %r11                 # 8-byte Reload
.LBB92_127:
	movq	(%rdi,%r15,8), %rax
	movq	%rax, (%r12)
	movl	%r10d, 32(%r12)
	movq	%r12, (%rdi,%r15,8)
	cmpq	%r15, 4584(%rbx)
	ja	.LBB92_129
# %bb.128:
	leaq	1(%r15), %rax
	movq	%rax, 4584(%rbx)
.LBB92_129:
	incq	168(%rbx)
	movq	176(%rbx), %rax
	addq	8(%r12), %rax
	movq	%rax, 176(%rbx)
	cmpq	184(%rbx), %rax
	jbe	.LBB92_131
# %bb.130:
	movq	%rax, 184(%rbx)
.LBB92_131:
	xorl	%eax, %eax
.LBB92_132:
	movabsq	$4611686018427387904, %rsi      # imm = 0x4000000000000000
	shlq	$40, %r15
	movq	-112(%rbp), %rcx                # 8-byte Reload
	leaq	(%r15,%rcx,4), %rcx
	orq	%rsi, %rcx
	movq	%rcx, 80(%r12,%rax)
	movq	%r13, 88(%r12,%rax)
	incq	24(%r12)
	leaq	(%r11,%rax), %rcx
	addq	$16, %rcx
	movq	%rcx, 16(%r12)
	vmovdqu	64(%rbx), %xmm0
	vpcmpeqd	%xmm1, %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 64(%rbx)
	incq	144(%rbx)
	leaq	(%r12,%rax), %rcx
	addq	$80, %rcx
	cmpl	112(%rbx), %r10d
	jne	.LBB92_20
# %bb.133:
	cmpl	$0, 116(%rbx)
	jne	.LBB92_20
# %bb.134:
	cmpl	$0, 104(%rbx)
	jne	.LBB92_20
# %bb.135:
	movq	8(%r12), %rax
	movq	16(%r12), %rdi
	addq	$15, %rdi
	andq	$-16, %rdi
	leaq	-80(%rax), %r8
	cmpq	%r8, %rdi
	jae	.LBB92_20
# %bb.136:
	leaq	80(%r12), %r8
	addq	%rdi, %r8
	addq	%r12, %rax
	movq	%r8, 1472(%rbx)
	movq	%rax, 1480(%rbx)
	leaq	(%rsi,%r15), %rax
	addq	$4, %rax
	movq	%rax, 1488(%rbx)
	movq	%r12, 4512(%rbx)
	jmp	.LBB92_20
.LBB92_138:
	movq	-96(%rbp), %rdi                 # 8-byte Reload
	testq	%rdi, %rdi
	je	.LBB92_114
# %bb.139:
	movq	%r14, %r12
	jmp	.LBB92_141
.LBB92_140:                             #   in Loop: Header=BB92_141 Depth=1
	callq	free@PLT
	movq	(%r13), %rdi
	testq	%rdi, %rdi
	je	.LBB92_148
.LBB92_141:                             # =>This Inner Loop Header: Depth=1
	movq	(%rdi), %rax
	movq	%rax, 1248(%rbx)
	cmpq	$0, 5640(%rbx)
	je	.LBB92_140
# %bb.142:                              #   in Loop: Header=BB92_141 Depth=1
	movq	8(%rdi), %rax
	subq	%rax, 24(%rbx)
	jmp	.LBB92_140
.LBB92_143:
	cmpq	$0, 192(%rbx)
	je	.LBB92_145
# %bb.144:
	movq	%rbx, %rdi
	callq	myl_native_arena_reclaim
	movl	$1, %edi
	movq	%r14, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	jne	.LBB92_86
.LBB92_145:
	xorl	%ecx, %ecx
	movq	%r13, %rdx
.LBB92_146:
	movq	%rcx, (%rdx)
	xorl	%eax, %eax
	testq	%rcx, %rcx
	sete	%al
.LBB92_147:
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB92_148:
	.cfi_def_cfa %rbp, 16
	vpxor	%xmm0, %xmm0, %xmm0
	vmovdqu	%xmm0, 192(%rbx)
	movl	$1, %edi
	movq	%r12, %rsi
	callq	calloc@PLT
	testq	%rax, %rax
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movl	-44(%rbp), %r10d                # 4-byte Reload
	je	.LBB92_114
# %bb.149:
	movq	%rax, %r12
	movq	24(%rbx), %rax
	movq	%rax, -72(%rbp)                 # 8-byte Spill
	jmp	.LBB92_119
.LBB92_150:
	movq	%rbx, %rdi
	callq	trim_empty
	movq	%r14, %rdi
	callq	large_block
	movq	%rax, %r15
	testq	%rax, %rax
	movl	$1, %eax
	je	.LBB92_147
.LBB92_151:
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	movq	-112(%rbp), %rax                # 8-byte Reload
	je	.LBB92_156
# %bb.152:
	movq	32(%rcx), %rcx
	movq	512(%rcx), %rdx
	movq	$0, (%r15)
	movq	%rdx, 8(%r15)
	movq	%r14, 16(%r15)
	movq	%r12, 24(%r15)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, 40(%r15)
	testq	%rdx, %rdx
	je	.LBB92_154
# %bb.153:
	movq	%r15, (%rdx)
.LBB92_154:
	movq	%r15, 512(%rcx)
	addq	%r14, 24(%rbx)
	addq	%r14, 520(%rcx)
	addq	$56, %r15
	movabsq	$-9223372036854775808, %rcx     # imm = 0x8000000000000000
.LBB92_155:
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	$1, (%r15)
	shlq	$2, %rax
	orq	%rcx, %rax
	movq	%rax, 8(%r15)
	movq	%rdx, 16(%r15)
	vmovdqu	64(%rbx), %xmm0
	vpcmpeqd	%xmm1, %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 64(%rbx)
	addq	$24, %r15
	movq	%r15, (%r13)
	xorl	%eax, %eax
	jmp	.LBB92_147
.LBB92_156:
	callq	myl_rc_invariant_failed
.Lfunc_end92:
	.size	allocate, .Lfunc_end92-allocate
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_binding_find,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_binding_find
	.type	myl_rc_binding_find,@function
myl_rc_binding_find:                    # @myl_rc_binding_find
.Lfunc_begin93:
	.cfi_startproc
# %bb.0:
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB93_3
# %bb.1:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rsi, (%rcx,%rax)
	jne	.LBB93_3
# %bb.2:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
	retq
.LBB93_3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	callq	myl_rc_binding_find_slow
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	.cfi_restore %rbp
	retq
.Lfunc_end93:
	.size	myl_rc_binding_find, .Lfunc_end93-myl_rc_binding_find
	.cfi_endproc
                                        # -- End function
	.section	.text.slab_refill,"ax",@progbits
	.p2align	4                               # -- Begin function slab_refill
	.type	slab_refill,@function
slab_refill:                            # @slab_refill
.Lfunc_begin94:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB94_46
# %bb.1:
	movq	%rsi, %r12
	movq	%rdi, %rbx
	movq	32(%rax), %r14
	movq	%rsi, %r15
	shlq	$4, %r15
	movq	8(%r14,%r15), %rcx
	testq	%rcx, %rcx
	je	.LBB94_2
# %bb.24:
	movq	72(%rcx), %rax
	testq	%rax, %rax
	je	.LBB94_26
.LBB94_25:
	movq	$0, 72(%rcx)
	movq	48(%rcx), %r13
	movq	64(%rcx), %r11
	movq	%r13, 56(%rcx)
	cmpq	%r11, %r13
	je	.LBB94_38
	jmp	.LBB94_44
.LBB94_2:
	cmpq	$0, 1096(%r14)
	jne	.LBB94_6
# %bb.3:
	movq	5904(%rbx), %rax
	cmpq	$1048576, %rax                  # imm = 0x100000
	jb	.LBB94_6
# %bb.4:
	movq	520(%r14), %rcx
	shrq	$2, %rcx
	cmpq	%rcx, %rax
	jb	.LBB94_6
# %bb.5:
	movq	%rbx, %rdi
	callq	trim_empty
.LBB94_6:
	movq	24(%rbx), %rax
	cmpq	$-65537, %rax                   # imm = 0xFFFEFFFF
	ja	.LBB94_9
# %bb.7:
	movq	88(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB94_13
# %bb.8:
	subq	%rax, %rcx
	setb	%al
	cmpq	$65536, %rcx                    # imm = 0x10000
	setb	%cl
	orb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB94_13
.LBB94_9:
	movq	%rbx, %rdi
	callq	trim_empty
	movq	24(%rbx), %rax
	cmpq	$-65537, %rax                   # imm = 0xFFFEFFFF
	ja	.LBB94_12
# %bb.10:
	movq	88(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB94_13
# %bb.11:
	subq	%rax, %rcx
	setb	%al
	cmpq	$65536, %rcx                    # imm = 0x10000
	setb	%cl
	orb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB94_13
.LBB94_12:
	movl	$1, 108(%rbx)
	xorl	%eax, %eax
	jmp	.LBB94_45
.LBB94_13:
	movq	%rbx, %rdi
	callq	range_take
	testq	%rax, %rax
	jne	.LBB94_15
# %bb.14:
	movq	%rbx, %rdi
	callq	trim_empty
	movq	%rbx, %rdi
	callq	range_take
	testq	%rax, %rax
	je	.LBB94_47
.LBB94_15:
	movq	%rax, %rcx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 48(%rax)
	vmovups	%ymm0, 16(%rax)
	movq	strides(,%r12,8), %rsi
	movq	%rsi, 8(%rax)
	movq	%r12, (%rax)
	cmpq	$65448, %rsi                    # imm = 0xFFA8
	ja	.LBB94_16
# %bb.17:
	movl	$65448, %eax                    # imm = 0xFFA8
	xorl	%edx, %edx
	divl	%esi
                                        # kill: def $eax killed $eax def $rax
	jmp	.LBB94_18
.LBB94_16:
	xorl	%eax, %eax
.LBB94_18:
	movq	%rax, 64(%rcx)
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB94_46
# %bb.19:
	movq	32(%rax), %rax
	leaq	(%rax,%r15), %rdx
	movq	(%rax,%r15), %rsi
	movq	%rsi, 24(%rcx)
	testq	%rsi, %rsi
	je	.LBB94_21
# %bb.20:
	movq	%rcx, 16(%rsi)
.LBB94_21:
	movq	%rcx, (%rdx)
	movq	8(%rdx), %rsi
	movq	$0, 32(%rcx)
	movq	%rsi, 40(%rcx)
	movq	8(%rdx), %rsi
	testq	%rsi, %rsi
	je	.LBB94_23
# %bb.22:
	movq	%rcx, 32(%rsi)
.LBB94_23:
	movq	%rcx, 8(%rdx)
	addq	$65536, 24(%rbx)                # imm = 0x10000
	addq	$65536, 520(%rax)               # imm = 0x10000
	movq	72(%rcx), %rax
	testq	%rax, %rax
	jne	.LBB94_25
.LBB94_26:
	movq	8(%rcx), %rdi
	movq	48(%rcx), %r13
	movq	64(%rcx), %r11
	movq	%r11, %r8
	subq	%r13, %r8
	cmpq	$4096, %rdi                     # imm = 0x1000
	ja	.LBB94_27
# %bb.28:
	movl	$4096, %eax                     # imm = 0x1000
	xorl	%edx, %edx
	divl	%edi
                                        # kill: def $eax killed $eax def $rax
	jmp	.LBB94_29
.LBB94_27:
	xorl	%eax, %eax
.LBB94_29:
	cmpq	$4097, %rdi                     # imm = 0x1001
	movl	$1, %edx
	cmovbq	%rax, %rdx
	cmpq	%r8, %rdx
	cmovaeq	%r8, %rdx
	movq	%r13, %r9
	imulq	%rdi, %r9
	leaq	(%rcx,%r9), %rax
	addq	$88, %rax
	testq	%rdx, %rdx
	je	.LBB94_36
# %bb.30:
	cmpq	$1, %rdx
	jne	.LBB94_32
# %bb.31:
	xorl	%r10d, %r10d
	jmp	.LBB94_35
.LBB94_32:
	movq	%r11, -56(%rbp)                 # 8-byte Spill
	movq	%r12, -72(%rbp)                 # 8-byte Spill
	movq	%r15, -80(%rbp)                 # 8-byte Spill
	movq	%r14, -88(%rbp)                 # 8-byte Spill
	movq	%rbx, -96(%rbp)                 # 8-byte Spill
	movl	%edx, %r11d
	andl	$8190, %r11d                    # imm = 0x1FFE
	leaq	2(%r13), %r8
	imulq	%rdi, %r8
	leaq	(%rcx,%r8), %r12
	addq	$88, %r12
	movq	%r13, %rsi
	leaq	(%rdi,%rdi), %r13
	movq	%rsi, -64(%rbp)                 # 8-byte Spill
	leaq	1(%rsi), %r8
	movq	%rdi, -48(%rbp)                 # 8-byte Spill
	imulq	%rdi, %r8
	leaq	(%rcx,%r8), %r14
	addq	$96, %r14
	addq	%rcx, %r8
	addq	$88, %r8
	leaq	(%r9,%rcx), %r15
	addq	$96, %r15
	xorl	%ebx, %ebx
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB94_33:                              # =>This Inner Loop Header: Depth=1
	leaq	1(%r10), %rsi
	leaq	(%r8,%r9), %rdi
	cmpq	%rdx, %rsi
	cmovaeq	%rbx, %rdi
	movq	%rdi, -8(%r15,%r9)
	movq	$3, (%r15,%r9)
	addq	$2, %r10
	leaq	(%r12,%r9), %rsi
	cmpq	%rdx, %r10
	cmovaeq	%rbx, %rsi
	movq	%rsi, -8(%r14,%r9)
	movq	$3, (%r14,%r9)
	addq	%r13, %r9
	cmpq	%r10, %r11
	jne	.LBB94_33
# %bb.34:
	testb	$1, %dl
	movq	-96(%rbp), %rbx                 # 8-byte Reload
	movq	-88(%rbp), %r14                 # 8-byte Reload
	movq	-80(%rbp), %r15                 # 8-byte Reload
	movq	-72(%rbp), %r12                 # 8-byte Reload
	movq	-64(%rbp), %r13                 # 8-byte Reload
	movq	-56(%rbp), %r11                 # 8-byte Reload
	movq	-48(%rbp), %rdi                 # 8-byte Reload
	je	.LBB94_36
.LBB94_35:
	movq	%r10, %rsi
	imulq	%rdi, %rsi
	incq	%r10
	imulq	%r10, %rdi
	addq	%rax, %rdi
	movq	%rdi, %r8
	xorl	%edi, %edi
	cmpq	%rdx, %r10
	cmovbq	%r8, %rdi
	movq	%rdi, (%rax,%rsi)
	movq	$3, 8(%rax,%rsi)
.LBB94_36:
	addq	%rdx, %r13
	movq	%r13, 48(%rcx)
	addq	%rdx, 56(%rcx)
	cmpq	%r11, %r13
	jne	.LBB94_44
.LBB94_38:
	movq	32(%rcx), %rdx
	movq	40(%rcx), %rsi
	testq	%rdx, %rdx
	je	.LBB94_40
# %bb.39:
	movq	%rsi, 40(%rdx)
	addq	$32, %rcx
	testq	%rsi, %rsi
	je	.LBB94_43
.LBB94_42:
	movq	%rdx, 32(%rsi)
.LBB94_43:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rcx)
.LBB94_44:
	movq	(%rax), %rcx
	movq	%rcx, 5648(%rbx,%r12,8)
.LBB94_45:
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB94_40:
	.cfi_def_cfa %rbp, 16
	addq	%r15, %r14
	movq	%rsi, 8(%r14)
	addq	$32, %rcx
	testq	%rsi, %rsi
	jne	.LBB94_42
	jmp	.LBB94_43
.LBB94_47:
	xorl	%eax, %eax
	jmp	.LBB94_45
.LBB94_46:
	vzeroupper
	callq	myl_rc_invariant_failed
.Lfunc_end94:
	.size	slab_refill, .Lfunc_end94-slab_refill
	.cfi_endproc
                                        # -- End function
	.section	.text.zero_payload,"ax",@progbits
	.p2align	4                               # -- Begin function zero_payload
	.type	zero_payload,@function
zero_payload:                           # @zero_payload
.Lfunc_begin95:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	%rsi, %rax
	shrq	$4, %rax
	cmpq	$8, %rax
	ja	.LBB95_12
# %bb.1:
	jmpq	*.LJTI95_0(,%rax,8)
.LBB95_2:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 112(%rdi)
.LBB95_3:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 96(%rdi)
.LBB95_4:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 80(%rdi)
.LBB95_5:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 64(%rdi)
.LBB95_6:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 48(%rdi)
.LBB95_7:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 32(%rdi)
.LBB95_8:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 16(%rdi)
.LBB95_9:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, (%rdi)
.LBB95_10:
	movq	%rsi, %rdx
	andq	$15, %rdx
	je	.LBB95_14
# %bb.11:
	andq	$-16, %rsi
	addq	%rsi, %rdi
	xorl	%esi, %esi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	memset@PLT                      # TAILCALL
.LBB95_14:
	.cfi_def_cfa %rbp, 16
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB95_12:
	.cfi_def_cfa %rbp, 16
	movq	%rsi, %rdx
	xorl	%esi, %esi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	memset@PLT                      # TAILCALL
.Lfunc_end95:
	.size	zero_payload, .Lfunc_end95-zero_payload
	.cfi_endproc
	.section	.rodata.zero_payload,"a",@progbits
	.p2align	3, 0x0
.LJTI95_0:
	.quad	.LBB95_10
	.quad	.LBB95_9
	.quad	.LBB95_8
	.quad	.LBB95_7
	.quad	.LBB95_6
	.quad	.LBB95_5
	.quad	.LBB95_4
	.quad	.LBB95_3
	.quad	.LBB95_2
                                        # -- End function
	.section	.text.trim_empty,"ax",@progbits
	.p2align	4                               # -- Begin function trim_empty
	.type	trim_empty,@function
trim_empty:                             # @trim_empty
.Lfunc_begin96:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB96_29
# %bb.1:
	movq	%rdi, %rbx
	xorl	%ecx, %ecx
	vxorps	%xmm0, %xmm0, %xmm0
	jmp	.LBB96_2
	.p2align	4
.LBB96_27:                              #   in Loop: Header=BB96_2 Depth=1
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	incq	%rcx
	cmpq	$32, %rcx
	je	.LBB96_28
.LBB96_2:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB96_5 Depth 2
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB96_29
# %bb.3:                                #   in Loop: Header=BB96_2 Depth=1
	movq	32(%rax), %r15
	movq	5648(%rbx,%rcx,8), %rax
	movq	%rcx, -48(%rbp)                 # 8-byte Spill
	movq	$0, 5648(%rbx,%rcx,8)
	testq	%rax, %rax
	je	.LBB96_27
# %bb.4:                                #   in Loop: Header=BB96_2 Depth=1
	movq	-48(%rbp), %rcx                 # 8-byte Reload
	shlq	$4, %rcx
	addq	%rcx, %r15
	jmp	.LBB96_5
	.p2align	4
.LBB96_25:                              #   in Loop: Header=BB96_5 Depth=2
	movq	1096(%r14), %rcx
	movq	%rcx, (%r13)
	movq	%r13, 1096(%r14)
	incq	%rax
	movq	%rax, 1104(%r14)
.LBB96_26:                              #   in Loop: Header=BB96_5 Depth=2
	movq	%r12, %rax
	testq	%r12, %r12
	je	.LBB96_27
.LBB96_5:                               #   Parent Loop BB96_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rax), %r12
	movq	%rax, %r13
	andq	$-65536, %r13                   # imm = 0xFFFF0000
	movq	72(%r13), %rcx
	testq	%rcx, %rcx
	jne	.LBB96_10
# %bb.6:                                #   in Loop: Header=BB96_5 Depth=2
	movq	48(%r13), %rdx
	cmpq	64(%r13), %rdx
	jne	.LBB96_10
# %bb.7:                                #   in Loop: Header=BB96_5 Depth=2
	movq	8(%r15), %rcx
	movq	$0, 32(%r13)
	movq	%rcx, 40(%r13)
	movq	8(%r15), %rcx
	testq	%rcx, %rcx
	je	.LBB96_9
# %bb.8:                                #   in Loop: Header=BB96_5 Depth=2
	movq	%r13, 32(%rcx)
.LBB96_9:                               #   in Loop: Header=BB96_5 Depth=2
	movq	%r13, 8(%r15)
	movq	72(%r13), %rcx
	.p2align	4
.LBB96_10:                              #   in Loop: Header=BB96_5 Depth=2
	movq	%rcx, (%rax)
	movq	%rax, 72(%r13)
	decq	56(%r13)
	jne	.LBB96_26
# %bb.11:                               #   in Loop: Header=BB96_5 Depth=2
	movq	5640(%rbx), %rdx
	testq	%rdx, %rdx
	je	.LBB96_29
# %bb.12:                               #   in Loop: Header=BB96_5 Depth=2
	movq	(%r13), %rax
	movq	32(%r13), %rcx
	shlq	$4, %rax
	addq	32(%rdx), %rax
	movq	40(%r13), %rdx
	testq	%rcx, %rcx
	je	.LBB96_14
# %bb.13:                               #   in Loop: Header=BB96_5 Depth=2
	movq	%rdx, 40(%rcx)
	testq	%rdx, %rdx
	je	.LBB96_17
.LBB96_16:                              #   in Loop: Header=BB96_5 Depth=2
	movq	%rcx, 32(%rdx)
.LBB96_17:                              #   in Loop: Header=BB96_5 Depth=2
	leaq	32(%r13), %rcx
	vmovaps	%xmm0, (%rcx)
	movq	16(%r13), %rdx
	movq	24(%r13), %rcx
	testq	%rdx, %rdx
	je	.LBB96_19
# %bb.18:                               #   in Loop: Header=BB96_5 Depth=2
	movq	%rcx, 24(%rdx)
	testq	%rcx, %rcx
	je	.LBB96_22
.LBB96_21:                              #   in Loop: Header=BB96_5 Depth=2
	movq	16(%r13), %rax
	movq	%rax, 16(%rcx)
.LBB96_22:                              #   in Loop: Header=BB96_5 Depth=2
	addq	$-65536, 24(%rbx)               # imm = 0xFFFF0000
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB96_29
# %bb.23:                               #   in Loop: Header=BB96_5 Depth=2
	movq	32(%rax), %r14
	addq	$-65536, 520(%r14)              # imm = 0xFFFF0000
	movq	1104(%r14), %rax
	cmpq	$16, %rax
	jb	.LBB96_25
# %bb.24:                               #   in Loop: Header=BB96_5 Depth=2
	leaq	4096(%r13), %rdi
	movl	$61440, %esi                    # imm = 0xF000
	movl	$4, %edx
	callq	madvise@PLT
	vxorps	%xmm0, %xmm0, %xmm0
	movq	1104(%r14), %rax
	jmp	.LBB96_25
.LBB96_14:                              #   in Loop: Header=BB96_5 Depth=2
	movq	%rdx, 8(%rax)
	testq	%rdx, %rdx
	jne	.LBB96_16
	jmp	.LBB96_17
.LBB96_19:                              #   in Loop: Header=BB96_5 Depth=2
	movq	%rcx, (%rax)
	testq	%rcx, %rcx
	jne	.LBB96_21
	jmp	.LBB96_22
.LBB96_28:
	movq	$0, 5904(%rbx)
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB96_29:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end96:
	.size	trim_empty, .Lfunc_end96-trim_empty
	.cfi_endproc
                                        # -- End function
	.section	.text.range_take,"ax",@progbits
	.p2align	4                               # -- Begin function range_take
	.type	range_take,@function
range_take:                             # @range_take
.Lfunc_begin97:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB97_26
# %bb.1:
	movq	32(%rax), %r15
	movq	1096(%r15), %rax
	testq	%rax, %rax
	je	.LBB97_3
# %bb.2:
	movq	(%rax), %rcx
	movq	%rcx, 1096(%r15)
	decq	1104(%r15)
	jmp	.LBB97_25
.LBB97_3:
	movq	544(%r15), %rax
	cmpq	552(%r15), %rax
	jne	.LBB97_24
# %bb.4:
	movq	1080(%r15), %rcx
	cmpq	$64, %rcx
	jb	.LBB97_15
# %bb.5:
	addq	$-64, %rcx
	cmpq	1088(%r15), %rcx
	jne	.LBB97_15
# %bb.6:
	leaq	(%rcx,%rcx), %rax
	testq	%rcx, %rcx
	movl	$64, %ebx
	cmovneq	%rax, %rbx
	movq	%rbx, %rax
	subq	%rcx, %rax
	shlq	$3, %rax
	movq	24(%rdi), %rcx
	movq	%rcx, %rdx
	addq	%rax, %rdx
	jae	.LBB97_7
.LBB97_10:
	movl	$1, 108(%rdi)
	xorl	%eax, %eax
	jmp	.LBB97_25
.LBB97_7:
	movq	88(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB97_11
# %bb.8:
	subq	%rcx, %rdx
	jb	.LBB97_10
# %bb.9:
	cmpq	%rdx, %rax
	ja	.LBB97_10
.LBB97_11:
	movq	%rdi, %r14
	leaq	(,%rbx,8), %rsi
	movq	1072(%r15), %rdi
	callq	realloc@PLT
	testq	%rax, %rax
	je	.LBB97_12
# %bb.13:
	movq	%rbx, %rcx
	subq	1088(%r15), %rcx
	shlq	$3, %rcx
	addq	%rcx, 24(%r14)
	movq	5640(%r14), %rdx
	testq	%rdx, %rdx
	je	.LBB97_26
# %bb.14:
	movq	32(%rdx), %rdx
	addq	%rcx, 520(%rdx)
	movq	%rax, 1072(%r15)
	movq	%rbx, 1088(%r15)
.LBB97_15:
	movl	$2162688, %esi                  # imm = 0x210000
	xorl	%edi, %edi
	movl	$3, %edx
	movl	$34, %ecx
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	mmap@PLT
	movq	%rax, %rbx
	xorl	%eax, %eax
	cmpq	$-1, %rbx
	je	.LBB97_25
# %bb.16:
	leaq	65535(%rbx), %rax
	andq	$-65536, %rax                   # imm = 0xFFFF0000
	cmpq	%rax, %rbx
	je	.LBB97_18
# %bb.17:
	movq	%rax, %rsi
	subq	%rbx, %rsi
	movq	%rbx, %rdi
	movq	%rax, %r14
	callq	munmap@PLT
	movq	%r14, %rax
.LBB97_18:
	leaq	2097152(%rax), %r14
	addq	$2162688, %rbx                  # imm = 0x210000
	cmpq	%rbx, %r14
	je	.LBB97_20
# %bb.19:
	subq	%r14, %rbx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movq	%rax, %rbx
	callq	munmap@PLT
	movq	%rbx, %rax
.LBB97_20:
	movq	1080(%r15), %rcx
	cmpq	$63, %rcx
	ja	.LBB97_22
# %bb.21:
	movq	%rax, 560(%r15,%rcx,8)
	jmp	.LBB97_23
.LBB97_22:
	movq	1072(%r15), %rdx
	movq	%rax, -512(%rdx,%rcx,8)
.LBB97_23:
	incq	%rcx
	movq	%rcx, 1080(%r15)
	movq	%r14, 552(%r15)
.LBB97_24:
	leaq	65536(%rax), %rcx
	movq	%rcx, 544(%r15)
.LBB97_25:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB97_12:
	.cfi_def_cfa %rbp, 16
	xorl	%eax, %eax
	jmp	.LBB97_25
.LBB97_26:
	callq	myl_rc_invariant_failed
.Lfunc_end97:
	.size	range_take, .Lfunc_end97-range_take
	.cfi_endproc
                                        # -- End function
	.section	.text.large_block,"ax",@progbits
	.p2align	4                               # -- Begin function large_block
	.type	large_block,@function
large_block:                            # @large_block
.Lfunc_begin98:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rdi, %rbx
	cmpq	$131071, %rdi                   # imm = 0x1FFFF
	ja	.LBB98_1
# %bb.6:
	movl	$1, %edi
	movq	%rbx, %rsi
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	calloc@PLT                      # TAILCALL
.LBB98_1:
	.cfi_def_cfa %rbp, 16
	cmpq	$-4097, %rbx                    # imm = 0xEFFF
	jbe	.LBB98_3
# %bb.2:
	xorl	%r14d, %r14d
	jmp	.LBB98_5
.LBB98_3:
	addq	$4095, %rbx                     # imm = 0xFFF
	andq	$-4096, %rbx                    # imm = 0xF000
	xorl	%r14d, %r14d
	xorl	%edi, %edi
	movq	%rbx, %rsi
	movl	$3, %edx
	movl	$34, %ecx
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	mmap@PLT
	cmpq	$-1, %rax
	je	.LBB98_5
# %bb.4:
	movq	%rbx, 32(%rax)
	movq	%rax, %r14
.LBB98_5:
	movq	%r14, %rax
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end98:
	.size	large_block, .Lfunc_end98-large_block
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_storage_retire,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_storage_retire
	.type	myl_rc_storage_retire,@function
myl_rc_storage_retire:                  # @myl_rc_storage_retire
.Lfunc_begin99:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	cmpq	$0, -16(%rsi)
	js	.LBB99_5
# %bb.1:
	movq	64(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB99_15
# %bb.2:
	leaq	-24(%rsi), %rax
	movq	80(%rdi), %rdx
	cmpq	$-1, %rdx
	je	.LBB99_4
# %bb.3:
	incq	%rdx
	movq	%rdx, 80(%rdi)
.LBB99_4:
	movq	%rax, %rdx
	andq	$-65536, %rdx                   # imm = 0xFFFF0000
	decq	%rcx
	movq	%rcx, 64(%rdi)
	movq	$3, -16(%rsi)
	movq	(%rdx), %rcx
	movq	5648(%rdi,%rcx,8), %rcx
	movq	%rcx, -24(%rsi)
	movq	(%rdx), %rcx
	movq	%rax, 5648(%rdi,%rcx,8)
	movq	8(%rdx), %rax
	addq	%rax, 5904(%rdi)
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB99_5:
	.cfi_def_cfa %rbp, 16
	movq	80(%rdi), %rax
	cmpq	$-1, %rax
	je	.LBB99_7
# %bb.6:
	incq	%rax
	movq	%rax, 80(%rdi)
.LBB99_7:
	decq	64(%rdi)
	movq	-80(%rsi), %rax
	testq	%rax, %rax
	je	.LBB99_9
# %bb.8:
	movq	-72(%rsi), %rcx
	movq	%rcx, 8(%rax)
	testq	%rcx, %rcx
	je	.LBB99_13
.LBB99_12:
	movq	%rax, (%rcx)
.LBB99_13:
	movq	-64(%rsi), %rax
	subq	%rax, 24(%rdi)
	movq	5640(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB99_15
# %bb.14:
	addq	$-80, %rsi
	movq	32(%rcx), %rcx
	subq	%rax, 520(%rcx)
	movq	%rsi, %rdi
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	large_release                   # TAILCALL
.LBB99_9:
	.cfi_def_cfa %rbp, 16
	movq	5640(%rdi), %rdx
	testq	%rdx, %rdx
	je	.LBB99_15
# %bb.10:
	movq	-72(%rsi), %rcx
	movq	32(%rdx), %rdx
	movq	%rcx, 512(%rdx)
	testq	%rcx, %rcx
	jne	.LBB99_12
	jmp	.LBB99_13
.LBB99_15:
	callq	myl_rc_invariant_failed
.Lfunc_end99:
	.size	myl_rc_storage_retire, .Lfunc_end99-myl_rc_storage_retire
	.cfi_endproc
                                        # -- End function
	.section	.text.large_release,"ax",@progbits
	.p2align	4                               # -- Begin function large_release
	.type	large_release,@function
large_release:                          # @large_release
.Lfunc_begin100:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movq	32(%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB100_2
# %bb.1:
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	munmap@PLT                      # TAILCALL
.LBB100_2:
	.cfi_def_cfa %rbp, 16
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.Lfunc_end100:
	.size	large_release, .Lfunc_end100-large_release
	.cfi_endproc
                                        # -- End function
	.section	.text.destroy,"ax",@progbits
	.p2align	4                               # -- Begin function destroy
	.type	destroy,@function
destroy:                                # @destroy
.Lfunc_begin101:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB101_37
# %bb.1:
	movq	%rdi, %rbx
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB101_37
# %bb.2:
	movq	32(%rax), %rax
	movq	%rax, -48(%rbp)                 # 8-byte Spill
	xorl	%eax, %eax
	movq	5648(%rbx,%rax,8), %rcx
	testq	%rcx, %rcx
	jne	.LBB101_38
	.p2align	4
.LBB101_5:                              # =>This Inner Loop Header: Depth=1
	movq	$0, 5648(%rbx,%rax,8)
	incq	%rax
	cmpq	$32, %rax
	je	.LBB101_6
# %bb.3:                                #   in Loop: Header=BB101_5 Depth=1
	movq	5648(%rbx,%rax,8), %rcx
	testq	%rcx, %rcx
	je	.LBB101_5
	.p2align	4
.LBB101_38:                             # =>This Inner Loop Header: Depth=1
	movq	%rcx, %rdx
	andq	$-65536, %rdx                   # imm = 0xFFFF0000
	decq	56(%rdx)
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	jne	.LBB101_38
	jmp	.LBB101_5
.LBB101_6:
	movq	$0, 5904(%rbx)
	xorl	%r15d, %r15d
	jmp	.LBB101_7
	.p2align	4
.LBB101_31:                             #   in Loop: Header=BB101_7 Depth=1
	incq	%r15
	cmpq	$32, %r15
	je	.LBB101_14
.LBB101_7:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB101_9 Depth 2
	movq	%r15, %r12
	shlq	$4, %r12
	movq	-48(%rbp), %rax                 # 8-byte Reload
	movq	(%rax,%r12), %r13
	testq	%r13, %r13
	je	.LBB101_31
# %bb.8:                                #   in Loop: Header=BB101_7 Depth=1
	addq	-48(%rbp), %r12                 # 8-byte Folded Reload
	jmp	.LBB101_9
	.p2align	4
.LBB101_30:                             #   in Loop: Header=BB101_9 Depth=2
	movq	1096(%r14), %rcx
	movq	%rcx, (%r13)
	movq	%r13, 1096(%r14)
	incq	%rax
	movq	%rax, 1104(%r14)
	movq	(%r12), %r13
	testq	%r13, %r13
	je	.LBB101_31
.LBB101_9:                              #   Parent Loop BB101_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB101_37
# %bb.10:                               #   in Loop: Header=BB101_9 Depth=2
	movq	(%r13), %rax
	shlq	$4, %rax
	addq	32(%rcx), %rax
	cmpq	$0, 72(%r13)
	jne	.LBB101_12
# %bb.11:                               #   in Loop: Header=BB101_9 Depth=2
	movq	48(%r13), %rcx
	cmpq	64(%r13), %rcx
	je	.LBB101_22
.LBB101_12:                             #   in Loop: Header=BB101_9 Depth=2
	movq	32(%r13), %rcx
	movq	40(%r13), %rdx
	testq	%rcx, %rcx
	je	.LBB101_18
# %bb.13:                               #   in Loop: Header=BB101_9 Depth=2
	movq	%rdx, 40(%rcx)
	testq	%rdx, %rdx
	je	.LBB101_21
.LBB101_20:                             #   in Loop: Header=BB101_9 Depth=2
	movq	%rcx, 32(%rdx)
.LBB101_21:                             #   in Loop: Header=BB101_9 Depth=2
	leaq	32(%r13), %rcx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rcx)
.LBB101_22:                             #   in Loop: Header=BB101_9 Depth=2
	movq	16(%r13), %rdx
	movq	24(%r13), %rcx
	testq	%rdx, %rdx
	je	.LBB101_24
# %bb.23:                               #   in Loop: Header=BB101_9 Depth=2
	movq	%rcx, 24(%rdx)
	testq	%rcx, %rcx
	je	.LBB101_27
.LBB101_26:                             #   in Loop: Header=BB101_9 Depth=2
	movq	16(%r13), %rax
	movq	%rax, 16(%rcx)
.LBB101_27:                             #   in Loop: Header=BB101_9 Depth=2
	addq	$-65536, 24(%rbx)               # imm = 0xFFFF0000
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB101_37
# %bb.28:                               #   in Loop: Header=BB101_9 Depth=2
	movq	32(%rax), %r14
	addq	$-65536, 520(%r14)              # imm = 0xFFFF0000
	movq	1104(%r14), %rax
	cmpq	$16, %rax
	jb	.LBB101_30
# %bb.29:                               #   in Loop: Header=BB101_9 Depth=2
	leaq	4096(%r13), %rdi
	movl	$61440, %esi                    # imm = 0xF000
	movl	$4, %edx
	callq	madvise@PLT
	movq	1104(%r14), %rax
	jmp	.LBB101_30
	.p2align	4
.LBB101_24:                             #   in Loop: Header=BB101_9 Depth=2
	movq	%rcx, (%rax)
	testq	%rcx, %rcx
	jne	.LBB101_26
	jmp	.LBB101_27
	.p2align	4
.LBB101_18:                             #   in Loop: Header=BB101_9 Depth=2
	movq	%rdx, 8(%rax)
	testq	%rdx, %rdx
	jne	.LBB101_20
	jmp	.LBB101_21
.LBB101_14:
	movq	-48(%rbp), %r14                 # 8-byte Reload
	cmpq	$0, 1080(%r14)
	je	.LBB101_32
# %bb.15:
	leaq	560(%r14), %r15
	movq	$-512, %r12                     # imm = 0xFE00
	xorl	%r13d, %r13d
	jmp	.LBB101_16
	.p2align	4
.LBB101_35:                             #   in Loop: Header=BB101_16 Depth=1
	movq	1072(%r14), %rax
	addq	%r12, %rax
.LBB101_36:                             #   in Loop: Header=BB101_16 Depth=1
	movq	(%rax), %rdi
	movl	$2097152, %esi                  # imm = 0x200000
	callq	munmap@PLT
	incq	%r13
	addq	$8, %r12
	cmpq	1080(%r14), %r13
	jae	.LBB101_32
.LBB101_16:                             # =>This Inner Loop Header: Depth=1
	cmpq	$63, %r13
	ja	.LBB101_35
# %bb.17:                               #   in Loop: Header=BB101_16 Depth=1
	leaq	(%r15,%r13,8), %rax
	jmp	.LBB101_36
.LBB101_32:
	movq	1088(%r14), %rax
	shlq	$3, %rax
	subq	%rax, 24(%rbx)
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB101_37
# %bb.33:
	movq	32(%rcx), %rcx
	subq	%rax, 520(%rcx)
	movq	1072(%r14), %rdi
	callq	free@PLT
	addq	$-1112, 24(%rbx)                # imm = 0xFBA8
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB101_37
# %bb.34:
	movq	32(%rax), %rax
	addq	$-1112, 520(%rax)               # imm = 0xFBA8
	movq	%r14, %rdi
	addq	$8, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	free@PLT                        # TAILCALL
.LBB101_37:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end101:
	.size	destroy, .Lfunc_end101-destroy
	.cfi_endproc
                                        # -- End function
	.section	.text.teardown,"ax",@progbits
	.p2align	4                               # -- Begin function teardown
	.type	teardown,@function
teardown:                               # @teardown
.Lfunc_begin102:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	5640(%rdi), %rax
	cmpl	$0, 208(%rax)
	jne	.LBB102_38
# %bb.1:
	cmpq	$0, 192(%rax)
	jne	.LBB102_38
# %bb.2:
	movq	%rdi, %rbx
	movq	32(%rax), %r14
	xorl	%eax, %eax
	movq	5648(%rbx,%rax,8), %rcx
	testq	%rcx, %rcx
	jne	.LBB102_39
	.p2align	4
.LBB102_5:                              # =>This Inner Loop Header: Depth=1
	movq	$0, 5648(%rbx,%rax,8)
	incq	%rax
	cmpq	$32, %rax
	je	.LBB102_6
# %bb.3:                                #   in Loop: Header=BB102_5 Depth=1
	movq	5648(%rbx,%rax,8), %rcx
	testq	%rcx, %rcx
	je	.LBB102_5
	.p2align	4
.LBB102_39:                             # =>This Inner Loop Header: Depth=1
	movq	%rcx, %rdx
	andq	$-65536, %rdx                   # imm = 0xFFFF0000
	decq	56(%rdx)
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	jne	.LBB102_39
	jmp	.LBB102_5
.LBB102_6:
	movq	$0, 5904(%rbx)
	movq	512(%r14), %rdi
	xorl	%r15d, %r15d
	testq	%rdi, %rdi
	je	.LBB102_10
	.p2align	4
.LBB102_8:                              # =>This Inner Loop Header: Depth=1
	movq	8(%rdi), %rax
	movq	%rax, 512(%r14)
	movq	16(%rdi), %rax
	subq	%rax, 24(%rbx)
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB102_38
# %bb.9:                                #   in Loop: Header=BB102_8 Depth=1
	movq	32(%rcx), %rcx
	subq	%rax, 520(%rcx)
	callq	large_release
	incq	%r15
	movq	512(%r14), %rdi
	testq	%rdi, %rdi
	jne	.LBB102_8
.LBB102_10:
	xorl	%r13d, %r13d
	movq	%r14, -48(%rbp)                 # 8-byte Spill
	jmp	.LBB102_11
	.p2align	4
.LBB102_32:                             #   in Loop: Header=BB102_11 Depth=1
	movq	-56(%rbp), %r13                 # 8-byte Reload
	incq	%r13
	cmpq	$32, %r13
	movq	-48(%rbp), %r14                 # 8-byte Reload
	je	.LBB102_33
.LBB102_11:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB102_13 Depth 2
	movq	%r13, -56(%rbp)                 # 8-byte Spill
	shlq	$4, %r13
	movq	%r14, %rax
	movq	(%r14,%r13), %r14
	testq	%r14, %r14
	je	.LBB102_32
# %bb.12:                               #   in Loop: Header=BB102_11 Depth=1
	addq	%rax, %r13
	jmp	.LBB102_13
	.p2align	4
.LBB102_31:                             #   in Loop: Header=BB102_13 Depth=2
	movq	1096(%r12), %rcx
	movq	%rcx, (%r14)
	movq	%r14, 1096(%r12)
	incq	%rax
	movq	%rax, 1104(%r12)
	movq	(%r13), %r14
	testq	%r14, %r14
	je	.LBB102_32
.LBB102_13:                             #   Parent Loop BB102_11 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	addq	56(%r14), %r15
	movq	$0, 56(%r14)
	testq	%rbx, %rbx
	je	.LBB102_38
# %bb.14:                               #   in Loop: Header=BB102_13 Depth=2
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB102_38
# %bb.15:                               #   in Loop: Header=BB102_13 Depth=2
	movq	(%r14), %rax
	shlq	$4, %rax
	addq	32(%rcx), %rax
	cmpq	$0, 72(%r14)
	jne	.LBB102_17
# %bb.16:                               #   in Loop: Header=BB102_13 Depth=2
	movq	48(%r14), %rcx
	cmpq	64(%r14), %rcx
	je	.LBB102_23
.LBB102_17:                             #   in Loop: Header=BB102_13 Depth=2
	movq	32(%r14), %rcx
	movq	40(%r14), %rdx
	testq	%rcx, %rcx
	je	.LBB102_19
# %bb.18:                               #   in Loop: Header=BB102_13 Depth=2
	movq	%rdx, 40(%rcx)
	testq	%rdx, %rdx
	je	.LBB102_22
.LBB102_21:                             #   in Loop: Header=BB102_13 Depth=2
	movq	%rcx, 32(%rdx)
.LBB102_22:                             #   in Loop: Header=BB102_13 Depth=2
	leaq	32(%r14), %rcx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, (%rcx)
.LBB102_23:                             #   in Loop: Header=BB102_13 Depth=2
	movq	16(%r14), %rdx
	movq	24(%r14), %rcx
	testq	%rdx, %rdx
	je	.LBB102_25
# %bb.24:                               #   in Loop: Header=BB102_13 Depth=2
	movq	%rcx, 24(%rdx)
	testq	%rcx, %rcx
	je	.LBB102_28
.LBB102_27:                             #   in Loop: Header=BB102_13 Depth=2
	movq	16(%r14), %rax
	movq	%rax, 16(%rcx)
.LBB102_28:                             #   in Loop: Header=BB102_13 Depth=2
	addq	$-65536, 24(%rbx)               # imm = 0xFFFF0000
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB102_38
# %bb.29:                               #   in Loop: Header=BB102_13 Depth=2
	movq	32(%rax), %r12
	addq	$-65536, 520(%r12)              # imm = 0xFFFF0000
	movq	1104(%r12), %rax
	cmpq	$16, %rax
	jb	.LBB102_31
# %bb.30:                               #   in Loop: Header=BB102_13 Depth=2
	leaq	4096(%r14), %rdi
	movl	$61440, %esi                    # imm = 0xF000
	movl	$4, %edx
	callq	madvise@PLT
	movq	1104(%r12), %rax
	jmp	.LBB102_31
	.p2align	4
.LBB102_25:                             #   in Loop: Header=BB102_13 Depth=2
	movq	%rcx, (%rax)
	testq	%rcx, %rcx
	jne	.LBB102_27
	jmp	.LBB102_28
	.p2align	4
.LBB102_19:                             #   in Loop: Header=BB102_13 Depth=2
	movq	%rdx, 8(%rax)
	testq	%rdx, %rdx
	jne	.LBB102_21
	jmp	.LBB102_22
.LBB102_33:
	movq	64(%rbx), %rax
	subq	%r15, %rax
	jb	.LBB102_38
# %bb.34:
	movq	1088(%r14), %rcx
	leaq	1112(,%rcx,8), %rcx
	cmpq	%rcx, 520(%r14)
	jne	.LBB102_38
# %bb.35:
	movq	%rax, 64(%rbx)
	movq	5640(%rbx), %rax
	movq	$0, 200(%rax)
	movq	80(%rbx), %rax
	cmpq	$-1, %rax
	je	.LBB102_37
# %bb.36:
	incq	%rax
	movq	%rax, 80(%rbx)
.LBB102_37:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB102_38:
	.cfi_def_cfa %rbp, 16
	callq	myl_rc_invariant_failed
.Lfunc_end102:
	.size	teardown, .Lfunc_end102-teardown
	.cfi_endproc
                                        # -- End function
	.section	.text.raw_bytes,"ax",@progbits
	.p2align	4                               # -- Begin function raw_bytes
	.type	raw_bytes,@function
raw_bytes:                              # @raw_bytes
.Lfunc_begin103:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rdi, %rdi
	je	.LBB103_8
# %bb.1:
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB103_8
# %bb.2:
	testl	%edx, %edx
	je	.LBB103_9
# %bb.3:
	movl	$16, %r8d
	movabsq	$274877906943, %r9              # imm = 0x3FFFFFFFFF
.LBB103_4:
	movq	$raw_type, -56(%rbp)
	movq	%rsi, -48(%rbp)
	movl	%edx, -40(%rbp)
	movl	$0, -36(%rbp)
	movq	$0, -32(%rbp)
	addq	%rsi, %r8
	setb	%cl
	cmpq	%r9, %rsi
	seta	%sil
	orb	%cl, %sil
	movl	$1, %ecx
	jne	.LBB103_33
# %bb.5:
	movl	$3, %ecx
	cmpl	112(%rdi), %edx
	ja	.LBB103_33
# %bb.6:
	leaq	-56(%rbp), %rsi
	leaq	-32(%rbp), %rdx
	movq	%rdi, %rbx
	callq	*(%rax)
	movl	%eax, %ecx
	movq	-32(%rbp), %rax
	testl	%ecx, %ecx
	je	.LBB103_7
# %bb.31:
	testq	%rax, %rax
	jne	.LBB103_8
# %bb.32:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB103_8
.LBB103_33:
	cmpl	$0, 292(%rax)
	jne	.LBB103_35
# %bb.34:
	movl	%ecx, 292(%rax)
.LBB103_35:
	xorl	%eax, %eax
.LBB103_36:
	addq	$40, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB103_9:
	.cfi_def_cfa %rbp, 16
	movl	$24, %r8d
	movabsq	$288230376151711743, %r9        # imm = 0x3FFFFFFFFFFFFFF
	cmpq	$8168, %rsi                     # imm = 0x1FE8
	ja	.LBB103_4
# %bb.10:
	cmpq	$allocate, (%rax)
	jne	.LBB103_4
# %bb.11:
	leaq	39(%rsi), %rax
	shrq	$4, %rax
	movzbl	class_of(%rax), %edx
	movq	5648(%rdi,%rdx,8), %rax
	testq	%rax, %rax
	je	.LBB103_16
# %bb.12:
	movq	(%rax), %r8
	movq	%r8, 5648(%rdi,%rdx,8)
	jmp	.LBB103_13
.LBB103_7:
	testq	%rax, %rax
	jne	.LBB103_36
	jmp	.LBB103_8
.LBB103_16:
	movq	%rdi, %rbx
	movq	%rsi, %r14
	movq	%rdx, %rsi
	movl	%ecx, %r15d
	callq	slab_refill
	movl	%r15d, %ecx
	movq	%r14, %rsi
	movq	%rbx, %rdi
	testq	%rax, %rax
	je	.LBB103_17
.LBB103_13:
	testl	%ecx, %ecx
	je	.LBB103_30
# %bb.14:
	leaq	24(%rax), %rcx
	movq	%rsi, %rdx
	shrq	$4, %rdx
	cmpq	$8, %rdx
	ja	.LBB103_37
# %bb.15:
	jmpq	*.LJTI103_0(,%rdx,8)
.LBB103_20:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 136(%rax)
.LBB103_21:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 120(%rax)
.LBB103_22:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 104(%rax)
.LBB103_23:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 88(%rax)
.LBB103_24:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 72(%rax)
.LBB103_25:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 56(%rax)
.LBB103_26:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, 40(%rax)
.LBB103_27:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovaps	%xmm0, (%rcx)
.LBB103_28:
	movq	%rsi, %rdx
	andq	$15, %rdx
	je	.LBB103_30
# %bb.29:
	movl	%esi, %r8d
	andl	$8176, %r8d                     # imm = 0x1FF0
	addq	%r8, %rcx
	movq	%rdi, %rbx
	movq	%rcx, %rdi
	movq	%rsi, %r14
	xorl	%esi, %esi
	movq	%rax, %r15
	callq	memset@PLT
	movq	%r15, %rax
	movq	%r14, %rsi
	movq	%rbx, %rdi
.LBB103_30:
	movq	$1, (%rax)
	shlq	$2, %rsi
	movq	%rsi, 8(%rax)
	movq	$raw_type, 16(%rax)
	vmovdqu	64(%rdi), %xmm0
	vpcmpeqd	%xmm1, %xmm1, %xmm1
	vpsubq	%xmm1, %xmm0, %xmm0
	vmovdqu	%xmm0, 64(%rdi)
	addq	$24, %rax
	jmp	.LBB103_36
.LBB103_17:
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB103_8
# %bb.18:
	cmpl	$0, 292(%rax)
	jne	.LBB103_35
# %bb.19:
	movl	$1, 292(%rax)
	jmp	.LBB103_35
.LBB103_37:
	movq	%rdi, %r14
	movq	%rcx, %rdi
	movq	%rsi, %rbx
	xorl	%esi, %esi
	movq	%rbx, %rdx
	movq	%rax, %r15
	callq	memset@PLT
	movq	%r15, %rax
	movq	%rbx, %rsi
	movq	%r14, %rdi
	jmp	.LBB103_30
.LBB103_8:
	callq	myl_rc_invariant_failed
.Lfunc_end103:
	.size	raw_bytes, .Lfunc_end103-raw_bytes
	.cfi_endproc
	.section	.rodata.raw_bytes,"a",@progbits
	.p2align	3, 0x0
.LJTI103_0:
	.quad	.LBB103_28
	.quad	.LBB103_27
	.quad	.LBB103_26
	.quad	.LBB103_25
	.quad	.LBB103_24
	.quad	.LBB103_23
	.quad	.LBB103_22
	.quad	.LBB103_21
	.quad	.LBB103_20
                                        # -- End function
	.section	.text.storage_extend,"ax",@progbits
	.p2align	4                               # -- Begin function storage_extend
	.type	storage_extend,@function
storage_extend:                         # @storage_extend
.Lfunc_begin104:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	testq	%rsi, %rsi
	je	.LBB104_7
# %bb.1:
	movq	-16(%rsi), %rax
	movabsq	$-4611686018427387901, %r8      # imm = 0xC000000000000003
	andq	%rax, %r8
	negq	%r8
	jno	.LBB104_7
# %bb.2:
	cmpl	$1, -24(%rsi)
	jne	.LBB104_7
# %bb.3:
	cmpl	$0, -20(%rsi)
	jne	.LBB104_7
# %bb.9:
	movabsq	$1152921504606846976, %r8       # imm = 0x1000000000000000
	andq	%r8, %rax
	movq	%rdx, %r8
	shrq	$58, %r8
	orq	%rax, %r8
	jne	.LBB104_7
# %bb.11:
	movq	-8(%rsi), %rax
	movq	(%rax), %rbx
	testq	%rbx, %rbx
	je	.LBB104_7
# %bb.12:
	movq	$-81, %rax
	movq	%rdx, %r13
	xorl	%edx, %edx
	divq	%rbx
	movq	%rax, %rdx
	xorl	%eax, %eax
	cmpq	%rdx, %r13
	ja	.LBB104_8
# %bb.13:
	imulq	%r13, %rbx
	leaq	24(%rbx), %r12
	cmpq	-56(%rsi), %r12
	jbe	.LBB104_7
# %bb.14:
	movl	%ecx, -44(%rbp)                 # 4-byte Spill
	addq	$80, %rbx
	movq	%rbx, %r14
	movq	%rsi, %r15
	subq	-64(%rsi), %r14
	movq	%rdi, -56(%rbp)                 # 8-byte Spill
	movq	%r14, %rsi
	callq	reserve
	testl	%eax, %eax
	je	.LBB104_7
# %bb.15:
	movq	%r15, %rdi
	movq	-64(%r15), %r15
	addq	$-80, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	large_grow
	testq	%rax, %rax
	je	.LBB104_7
# %bb.16:
	cmpl	$0, -44(%rbp)                   # 4-byte Folded Reload
	je	.LBB104_19
# %bb.17:
	cmpq	$0, 32(%rax)
	jne	.LBB104_19
# %bb.18:
	addq	%rax, %r15
	movq	%r15, %rdi
	xorl	%esi, %esi
	movq	%r14, %rdx
	movq	%rax, %r15
	callq	memset@PLT
	movq	%r15, %rax
.LBB104_19:
	movq	(%rax), %rcx
	testq	%rcx, %rcx
	je	.LBB104_25
# %bb.20:
	movq	%rax, 8(%rcx)
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	jmp	.LBB104_28
.LBB104_7:
	xorl	%eax, %eax
.LBB104_8:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB104_25:
	.cfi_def_cfa %rbp, 16
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	testq	%rcx, %rcx
	je	.LBB104_34
# %bb.26:
	movq	5640(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB104_34
# %bb.27:
	movq	32(%rdx), %rdx
	movq	%rax, 512(%rdx)
.LBB104_28:
	movq	8(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB104_30
# %bb.29:
	movq	%rax, (%rdx)
.LBB104_30:
	movq	%rbx, 16(%rax)
	movq	%r12, 24(%rax)
	movabsq	$-1152921504606846973, %rdx     # imm = 0xF000000000000003
	andq	64(%rax), %rdx
	leaq	(%rdx,%r13,4), %rdx
	movq	%rdx, 64(%rax)
	addq	%r14, 24(%rcx)
	movq	5640(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB104_34
# %bb.31:
	movq	32(%rdx), %rdx
	addq	%r14, 520(%rdx)
	movq	80(%rcx), %rdx
	cmpq	$-1, %rdx
	je	.LBB104_33
# %bb.32:
	incq	%rdx
	movq	%rdx, 80(%rcx)
.LBB104_33:
	addq	$80, %rax
	jmp	.LBB104_8
.LBB104_34:
	callq	myl_rc_invariant_failed
.Lfunc_end104:
	.size	storage_extend, .Lfunc_end104-storage_extend
	.cfi_endproc
                                        # -- End function
	.section	.text.reserve,"ax",@progbits
	.p2align	4                               # -- Begin function reserve
	.type	reserve,@function
reserve:                                # @reserve
.Lfunc_begin105:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	24(%rdi), %rcx
	movq	%rcx, %rax
	addq	%rsi, %rax
	jb	.LBB105_3
# %bb.1:
	movq	88(%rbx), %rdx
	movl	$1, %eax
	testq	%rdx, %rdx
	je	.LBB105_7
# %bb.2:
	subq	%rcx, %rdx
	setb	%cl
	cmpq	%rdx, %r14
	seta	%dl
	orb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB105_7
.LBB105_3:
	movq	%rbx, %rdi
	callq	trim_empty
	movq	24(%rbx), %rcx
	movq	%rcx, %rax
	addq	%r14, %rax
	jb	.LBB105_6
# %bb.4:
	movq	88(%rbx), %rdx
	movl	$1, %eax
	testq	%rdx, %rdx
	je	.LBB105_7
# %bb.5:
	subq	%rcx, %rdx
	setb	%cl
	cmpq	%rdx, %r14
	seta	%dl
	orb	%cl, %dl
	cmpb	$1, %dl
	jne	.LBB105_7
.LBB105_6:
	movl	$1, 108(%rbx)
	xorl	%eax, %eax
.LBB105_7:
	popq	%rbx
	popq	%r14
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end105:
	.size	reserve, .Lfunc_end105-reserve
	.cfi_endproc
                                        # -- End function
	.section	.text.large_grow,"ax",@progbits
	.p2align	4                               # -- Begin function large_grow
	.type	large_grow,@function
large_grow:                             # @large_grow
.Lfunc_begin106:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rbx
	movq	32(%rdi), %rsi
	testq	%rsi, %rsi
	setne	%cl
	cmpq	$131072, %rdx                   # imm = 0x20000
	setae	%r8b
	orb	%cl, %r8b
	jne	.LBB106_2
# %bb.1:
	movq	%rdx, %rsi
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	jmp	realloc@PLT                     # TAILCALL
.LBB106_2:
	.cfi_def_cfa %rbp, 16
	testq	%rsi, %rsi
	je	.LBB106_5
# %bb.3:
	cmpq	$-4097, %rdx                    # imm = 0xEFFF
	ja	.LBB106_11
# %bb.7:
	addq	$4095, %rdx                     # imm = 0xFFF
	andq	$-4096, %rdx                    # imm = 0xF000
	cmpq	%rsi, %rdx
	jbe	.LBB106_12
# %bb.8:
	movq	%rdx, %rbx
	movl	$1, %ecx
	xorl	%eax, %eax
	callq	mremap@PLT
	cmpq	$-1, %rax
	je	.LBB106_11
# %bb.9:
	movq	%rax, %rdi
	movq	%rbx, 32(%rax)
	jmp	.LBB106_12
.LBB106_5:
	movq	%rdi, %r14
	movq	%rdx, %rdi
	callq	large_block
	testq	%rax, %rax
	je	.LBB106_11
# %bb.6:
	movq	32(%rax), %r15
	movq	%rax, %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	movq	%rax, %rbx
	callq	memcpy@PLT
	movq	%r15, 32(%rbx)
	movq	%r14, %rdi
	callq	free@PLT
	movq	%rbx, %rdi
	jmp	.LBB106_12
.LBB106_11:
	xorl	%edi, %edi
.LBB106_12:
	movq	%rdi, %rax
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end106:
	.size	large_grow, .Lfunc_end106-large_grow
	.cfi_endproc
                                        # -- End function
	.section	.text.myl_rc_native_shape,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_native_shape
	.type	myl_rc_native_shape,@function
myl_rc_native_shape:                    # @myl_rc_native_shape
.Lfunc_begin107:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%rsi, %rbx
	movq	5640(%rdi), %rax
	movl	52(%rsi), %ecx
	cmpq	%rcx, 160(%rax)
	jbe	.LBB107_3
# %bb.1:
	movq	152(%rax), %rdx
	shlq	$4, %rcx
	cmpq	%rbx, (%rdx,%rcx)
	jne	.LBB107_3
# %bb.2:
	addq	%rcx, %rdx
	movq	8(%rdx), %rax
	testq	%rax, %rax
	jne	.LBB107_43
.LBB107_5:
	movq	(%rbx), %rax
	movq	%rax, -168(%rbp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -160(%rbp)
	movzwl	48(%rbx), %eax
	testl	%eax, %eax
	je	.LBB107_9
# %bb.6:
	cmpl	$7, %eax
	je	.LBB107_9
# %bb.7:
	cmpl	$1, %eax
	jne	.LBB107_45
# %bb.8:
	movl	$1, -160(%rbp)
.LBB107_9:
	vmovups	%ymm0, -200(%rbp)
	vmovups	%ymm0, -216(%rbp)
	movq	%rbx, -232(%rbp)
	leaq	-168(%rbp), %rax
	movq	%rax, -224(%rbp)
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.LBB107_46
# %bb.10:
	cmpq	$0, 192(%rax)
	jne	.LBB107_46
# %bb.11:
	movl	52(%rbx), %ecx
	cmpq	%rcx, 160(%rax)
	jbe	.LBB107_14
# %bb.12:
	movq	152(%rax), %rdx
	shlq	$4, %rcx
	cmpq	%rbx, (%rdx,%rcx)
	jne	.LBB107_14
# %bb.13:
	addq	%rcx, %rdx
	movq	8(%rdx), %rax
	testq	%rax, %rax
	je	.LBB107_26
.LBB107_16:
	cmpq	$0, 16(%rax)
	jne	.LBB107_46
# %bb.17:
	cmpq	$0, 24(%rax)
	jne	.LBB107_46
# %bb.18:
	cmpq	$0, 32(%rax)
	jne	.LBB107_46
# %bb.19:
	cmpq	$0, 40(%rax)
	jne	.LBB107_46
# %bb.20:
	cmpq	$0, 48(%rax)
	jne	.LBB107_46
# %bb.21:
	cmpq	$0, 56(%rax)
	jne	.LBB107_46
# %bb.22:
	movq	5640(%rdi), %rdi
	jmp	.LBB107_23
.LBB107_3:
	movq	%rdi, %rcx
	movq	%rax, %rdi
	movq	%rbx, %rsi
	callq	myl_rc_binding_find_slow
	movq	%rcx, %rdi
	testq	%rax, %rax
	jne	.LBB107_43
	jmp	.LBB107_5
.LBB107_14:
	movq	%rdi, %rcx
	movq	%rax, %rdi
	movq	%rbx, %rsi
	vzeroupper
	callq	myl_rc_binding_find_slow
	movq	%rcx, %rdi
	testq	%rax, %rax
	jne	.LBB107_16
.LBB107_26:
	movl	$4, -128(%rbp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, -124(%rbp)
	movl	$0, -108(%rbp)
	leaq	-232(%rbp), %rax
	movq	%rax, -104(%rbp)
	movq	$1, -96(%rbp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -80(%rbp)
	movq	$0, -48(%rbp)
	movq	%rdi, %r14
	movq	%rdi, -88(%rbp)
	leaq	-88(%rbp), %rdi
	leaq	-168(%rbp), %rsi
	vzeroupper
	callq	builder_add
	testl	%eax, %eax
	je	.LBB107_27
# %bb.28:
	leaq	-88(%rbp), %rdi
	leaq	-128(%rbp), %rsi
	xorl	%edx, %edx
	callq	register_shapes
	testl	%eax, %eax
	sete	%r15b
	jmp	.LBB107_29
.LBB107_27:
	xorl	%r15d, %r15d
.LBB107_29:
	movq	-88(%rbp), %r12
	movq	-80(%rbp), %rdi
	movq	-56(%rbp), %r13
	testq	%rdi, %rdi
	movq	%r14, %rax
	je	.LBB107_33
# %bb.30:
	leaq	(,%r13,8), %rax
	leaq	(%rax,%rax,4), %rcx
	movq	24(%r12), %rax
	subq	%rcx, %rax
	jb	.LBB107_46
# %bb.31:
	movq	5640(%r12), %rdx
	movq	48(%rdx), %rsi
	subq	%rcx, %rsi
	jb	.LBB107_46
# %bb.32:
	movq	%rax, 24(%r12)
	movq	%rsi, 48(%rdx)
	callq	free@PLT
	movq	%r14, %rax
.LBB107_33:
	movq	-72(%rbp), %rdi
	testq	%rdi, %rdi
	je	.LBB107_37
# %bb.34:
	shlq	$4, %r13
	movq	24(%r12), %rax
	subq	%r13, %rax
	jb	.LBB107_46
# %bb.35:
	movq	5640(%r12), %rcx
	movq	48(%rcx), %rdx
	subq	%r13, %rdx
	jb	.LBB107_46
# %bb.36:
	movq	%rax, 24(%r12)
	movq	%rdx, 48(%rcx)
	callq	free@PLT
	movq	%r14, %rax
.LBB107_37:
	movq	5640(%rax), %rdi
	testb	%r15b, %r15b
	je	.LBB107_38
.LBB107_23:
	movl	52(%rbx), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB107_42
# %bb.24:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%rbx, (%rcx,%rax)
	jne	.LBB107_42
# %bb.25:
	addq	%rax, %rcx
	movq	8(%rcx), %rax
.LBB107_43:
	movq	8(%rax), %rax
.LBB107_44:
	addq	$200, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	vzeroupper
	retq
.LBB107_38:
	.cfi_def_cfa %rbp, 16
	testq	%rdi, %rdi
	je	.LBB107_46
# %bb.39:
	cmpl	$0, 292(%rdi)
	je	.LBB107_41
# %bb.40:
	xorl	%eax, %eax
	jmp	.LBB107_44
.LBB107_41:
	movl	$1, 292(%rdi)
	xorl	%eax, %eax
	jmp	.LBB107_44
.LBB107_42:
	movq	%rbx, %rsi
	vzeroupper
	callq	myl_rc_binding_find_slow
	jmp	.LBB107_43
.LBB107_46:
	vzeroupper
	callq	myl_rc_invariant_failed
.LBB107_45:
	vzeroupper
	callq	abort@PLT
.Lfunc_end107:
	.size	myl_rc_native_shape, .Lfunc_end107-myl_rc_native_shape
	.cfi_endproc
                                        # -- End function
	.section	.text.flat_transfer,"ax",@progbits
	.p2align	4                               # -- Begin function flat_transfer
	.type	flat_transfer,@function
flat_transfer:                          # @flat_transfer
.Lfunc_begin108:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	pushq	%rax
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	64(%rsi), %r9d
	cmpq	$16, %r9
	jbe	.LBB108_3
.LBB108_1:
	movl	$-1, %eax
.LBB108_2:
	addq	$8, %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB108_3:
	.cfi_def_cfa %rbp, 16
	testq	%rdi, %rdi
	je	.LBB108_28
# %bb.4:
	cmpq	%rcx, %rdx
	je	.LBB108_28
# %bb.5:
	testq	%rcx, %rcx
	je	.LBB108_28
# %bb.6:
	testq	%rdx, %rdx
	je	.LBB108_28
# %bb.7:
	cmpq	$0, 5640(%rdi)
	je	.LBB108_28
# %bb.8:
	movq	80(%rsi), %rbx
	movq	%rdx, %rax
	subq	%rcx, %rax
	jbe	.LBB108_11
# %bb.9:
	cmpq	%rbx, %rax
	jb	.LBB108_1
	jmp	.LBB108_13
.LBB108_11:
	movq	%rcx, %rax
	subq	%rdx, %rax
	cmpq	%rbx, %rax
	jb	.LBB108_1
.LBB108_13:
	movl	$3, %eax
	cmpl	112(%rdi), %r8d
	ja	.LBB108_2
# %bb.14:
	cmpb	$0, 70(%rsi)
	je	.LBB108_16
# %bb.15:
	movl	72(%rsi), %eax
	movl	(%rcx,%rax), %eax
	leaq	90(%rsi), %r10
	cmpq	$32, %rax
	leaq	92(%rsi,%rax,2), %rax
	cmovaeq	%r10, %rax
	testq	%r9, %r9
	jne	.LBB108_17
	jmp	.LBB108_29
.LBB108_16:
	leaq	88(%rsi), %rax
	testq	%r9, %r9
	je	.LBB108_29
.LBB108_17:
	movzwl	(%rax), %eax
	xorl	%r10d, %r10d
	jmp	.LBB108_20
.LBB108_18:                             #   in Loop: Header=BB108_20 Depth=1
	shrq	$40, %r14
	andl	$1048575, %r14d                 # imm = 0xFFFFF
	cmpl	%r8d, %r14d
	ja	.LBB108_1
	.p2align	4
.LBB108_19:                             #   in Loop: Header=BB108_20 Depth=1
	incq	%r10
	cmpq	%r10, %r9
	je	.LBB108_29
.LBB108_20:                             # =>This Inner Loop Header: Depth=1
	btl	%r10d, %eax
	jae	.LBB108_19
# %bb.21:                               #   in Loop: Header=BB108_20 Depth=1
	movzwl	156(%rsi,%r10,2), %r11d
	movq	(%rcx,%r11), %r11
	testq	%r11, %r11
	je	.LBB108_19
# %bb.22:                               #   in Loop: Header=BB108_20 Depth=1
	movq	-16(%r11), %r14
	testb	$2, %r14b
	jne	.LBB108_19
# %bb.23:                               #   in Loop: Header=BB108_20 Depth=1
	btq	$60, %r14
	jb	.LBB108_1
# %bb.24:                               #   in Loop: Header=BB108_20 Depth=1
	btq	$62, %r14
	jb	.LBB108_18
# %bb.25:                               #   in Loop: Header=BB108_20 Depth=1
	testb	$1, %r14b
	jne	.LBB108_28
# %bb.26:                               #   in Loop: Header=BB108_20 Depth=1
	cmpl	$0, -24(%r11)
	jne	.LBB108_19
# %bb.27:                               #   in Loop: Header=BB108_20 Depth=1
	cmpl	$0, -20(%r11)
	jne	.LBB108_19
.LBB108_28:
	callq	myl_rc_invariant_failed
.LBB108_29:
	cmpq	$97, %rbx
	setb	%al
	testb	$7, %bl
	sete	%sil
	testb	%sil, %al
	je	.LBB108_33
# %bb.30:
	shrq	$3, %rbx
	decq	%rbx
	cmpq	$11, %rbx
	ja	.LBB108_60
# %bb.31:
	jmpq	*.LJTI108_0(,%rbx,8)
.LBB108_32:
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	jmp	.LBB108_59
.LBB108_33:
	movq	%rdi, %r15
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	%rbx, %rdx
	movq	%rcx, %r14
	callq	memcpy@PLT
	movq	%r14, %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	memset@PLT
	movq	%r15, %rdi
	jmp	.LBB108_60
.LBB108_36:
	movq	88(%rcx), %rax
	movq	%rax, 88(%rdx)
.LBB108_37:
	movq	80(%rcx), %rax
	movq	%rax, 80(%rdx)
.LBB108_38:
	movq	72(%rcx), %rax
	movq	%rax, 72(%rdx)
.LBB108_39:
	movq	64(%rcx), %rax
	movq	%rax, 64(%rdx)
.LBB108_40:
	movq	56(%rcx), %rax
	movq	%rax, 56(%rdx)
.LBB108_41:
	movq	48(%rcx), %rax
	movq	%rax, 48(%rdx)
	movq	40(%rcx), %rax
	movq	%rax, 40(%rdx)
	movq	32(%rcx), %rax
	movq	%rax, 32(%rdx)
	movq	24(%rcx), %rax
	movq	%rax, 24(%rdx)
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdx)
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	cmpq	$11, %rbx
	ja	.LBB108_60
# %bb.42:
	jmpq	*.LJTI108_1(,%rbx,8)
.LBB108_43:
	movq	$0, 88(%rcx)
.LBB108_44:
	movq	$0, 80(%rcx)
.LBB108_45:
	movq	$0, 72(%rcx)
.LBB108_46:
	movq	$0, 64(%rcx)
.LBB108_47:
	movq	$0, 56(%rcx)
.LBB108_48:
	movq	$0, 48(%rcx)
	jmp	.LBB108_54
.LBB108_49:
	movq	32(%rcx), %rax
	movq	%rax, 32(%rdx)
	movq	24(%rcx), %rax
	movq	%rax, 24(%rdx)
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdx)
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	jmp	.LBB108_55
.LBB108_50:
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdx)
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	jmp	.LBB108_57
.LBB108_51:
	movq	24(%rcx), %rax
	movq	%rax, 24(%rdx)
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdx)
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	jmp	.LBB108_56
.LBB108_52:
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
	jmp	.LBB108_58
.LBB108_53:
	movq	40(%rcx), %rax
	movq	%rax, 40(%rdx)
	movq	32(%rcx), %rax
	movq	%rax, 32(%rdx)
	movq	24(%rcx), %rax
	movq	%rax, 24(%rdx)
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdx)
	movq	8(%rcx), %rax
	movq	%rax, 8(%rdx)
	movq	(%rcx), %rax
	movq	%rax, (%rdx)
.LBB108_54:
	movq	$0, 40(%rcx)
.LBB108_55:
	movq	$0, 32(%rcx)
.LBB108_56:
	movq	$0, 24(%rcx)
.LBB108_57:
	movq	$0, 16(%rcx)
.LBB108_58:
	movq	$0, 8(%rcx)
.LBB108_59:
	movq	$0, (%rcx)
.LBB108_60:
	movq	5640(%rdi), %rcx
	xorl	%eax, %eax
	cmpq	$0, 200(%rcx)
	je	.LBB108_2
# %bb.61:
	callq	myl_rc_drain
	xorl	%eax, %eax
	jmp	.LBB108_2
.Lfunc_end108:
	.size	flat_transfer, .Lfunc_end108-flat_transfer
	.cfi_endproc
	.section	.rodata.flat_transfer,"a",@progbits
	.p2align	3, 0x0
.LJTI108_0:
	.quad	.LBB108_32
	.quad	.LBB108_52
	.quad	.LBB108_50
	.quad	.LBB108_51
	.quad	.LBB108_49
	.quad	.LBB108_53
	.quad	.LBB108_41
	.quad	.LBB108_40
	.quad	.LBB108_39
	.quad	.LBB108_38
	.quad	.LBB108_37
	.quad	.LBB108_36
.LJTI108_1:
	.quad	.LBB108_59
	.quad	.LBB108_58
	.quad	.LBB108_57
	.quad	.LBB108_56
	.quad	.LBB108_55
	.quad	.LBB108_54
	.quad	.LBB108_48
	.quad	.LBB108_47
	.quad	.LBB108_46
	.quad	.LBB108_45
	.quad	.LBB108_44
	.quad	.LBB108_43
                                        # -- End function
	.section	.text.myl_rc_native_retain,"ax",@progbits
	.p2align	4                               # -- Begin function myl_rc_native_retain
	.type	myl_rc_native_retain,@function
myl_rc_native_retain:                   # @myl_rc_native_retain
.Lfunc_begin109:
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$552, %rsp                      # imm = 0x228
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movl	%r8d, -44(%rbp)                 # 4-byte Spill
	movq	%rcx, %r9
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %rbx
	movq	5640(%rdi), %rdi
	movl	52(%rsi), %eax
	cmpq	%rax, 160(%rdi)
	jbe	.LBB109_3
# %bb.1:
	movq	152(%rdi), %rcx
	shlq	$4, %rax
	cmpq	%r15, (%rcx,%rax)
	jne	.LBB109_3
# %bb.2:
	addq	%rax, %rcx
	movq	8(%rcx), %r12
	testq	%r12, %r12
	je	.LBB109_93
.LBB109_5:
	cmpl	$0, 64(%r12)
	jne	.LBB109_32
# %bb.6:
	movq	5640(%rbx), %rax
	cmpq	$0, 200(%rax)
	je	.LBB109_7
.LBB109_32:
	movq	80(%r12), %r13
	cmpb	$0, 68(%r12)
	setne	%al
	testq	%r13, %r13
	setne	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB109_84
# %bb.33:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB109_92
# %bb.34:
	testq	%r9, %r9
	je	.LBB109_92
# %bb.35:
	testq	%r14, %r14
	je	.LBB109_92
# %bb.36:
	cmpq	$0, 192(%rax)
	jne	.LBB109_92
# %bb.37:
	movq	%r14, %rax
	subq	%r9, %rax
	ja	.LBB109_39
# %bb.38:
	movq	%r9, %rax
	subq	%r14, %rax
.LBB109_39:
	cmpq	%r13, %rax
	jae	.LBB109_40
.LBB109_84:
	movq	8(%r12), %r13
	testq	%r13, %r13
	je	.LBB109_85
# %bb.86:
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB109_92
# %bb.87:
	cmpq	$0, 192(%rax)
	jne	.LBB109_92
# %bb.88:
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	movzbl	69(%r12), %eax
	testl	%eax, %eax
	je	.LBB109_89
# %bb.90:
	cmpb	$3, %al
	jae	.LBB109_92
# %bb.91:
	cmpl	$2, %eax
	jne	.LBB109_95
	jmp	.LBB109_92
.LBB109_40:
	movl	-44(%rbp), %eax                 # 4-byte Reload
	cmpl	112(%rbx), %eax
	jbe	.LBB109_42
# %bb.41:
	movq	%r14, %rdi
	xorl	%esi, %esi
	movq	%r13, %rdx
	callq	memset@PLT
	movq	5640(%rbx), %rcx
	movl	$3, %r14d
	cmpq	$0, 200(%rcx)
	jne	.LBB109_78
	jmp	.LBB109_82
.LBB109_89:
	movq	(%r12), %rsi
	movq	%rbx, %rdi
	callq	myl_rc_native_has_unique
	cmpl	$1, %eax
	movl	$2, %eax
	sbbl	$0, %eax
	movb	%al, 69(%r12)
	cmpl	$2, %eax
	jne	.LBB109_95
	jmp	.LBB109_92
.LBB109_7:
	movq	(%r15), %rdx
	testq	%rdx, %rdx
	je	.LBB109_32
# %bb.8:
	movq	%r14, %rax
	subq	%r9, %rax
	ja	.LBB109_10
# %bb.9:
	movq	%r9, %rax
	subq	%r14, %rax
.LBB109_10:
	cmpq	%rdx, %rax
	jb	.LBB109_32
# %bb.11:
	movl	-44(%rbp), %eax                 # 4-byte Reload
	cmpl	112(%rbx), %eax
	jbe	.LBB109_16
# %bb.12:
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movq	5640(%rbx), %rax
	testq	%rax, %rax
	je	.LBB109_92
# %bb.13:
	cmpl	$0, 292(%rax)
	je	.LBB109_15
# %bb.14:
	xorl	%eax, %eax
	jmp	.LBB109_124
.LBB109_42:
	cmpq	$97, %r13
	setae	%al
	testb	$7, %r13b
	setne	%cl
	orb	%al, %cl
	jne	.LBB109_57
# %bb.43:
	movq	%r13, %rax
	shrq	$3, %rax
	decq	%rax
	cmpq	$11, %rax
	ja	.LBB109_58
# %bb.44:
	jmpq	*.LJTI109_1(,%rax,8)
.LBB109_45:
	movq	88(%r9), %rax
	movq	%rax, 88(%r14)
.LBB109_46:
	movq	80(%r9), %rax
	movq	%rax, 80(%r14)
.LBB109_47:
	movq	72(%r9), %rax
	movq	%rax, 72(%r14)
.LBB109_48:
	movq	64(%r9), %rax
	movq	%rax, 64(%r14)
.LBB109_49:
	movq	56(%r9), %rax
	movq	%rax, 56(%r14)
.LBB109_50:
	movq	48(%r9), %rax
	movq	%rax, 48(%r14)
.LBB109_51:
	movq	40(%r9), %rax
	movq	%rax, 40(%r14)
.LBB109_52:
	movq	32(%r9), %rax
	movq	%rax, 32(%r14)
.LBB109_53:
	movq	24(%r9), %rax
	movq	%rax, 24(%r14)
.LBB109_54:
	movq	16(%r9), %rax
	movq	%rax, 16(%r14)
.LBB109_55:
	movq	8(%r9), %rax
	movq	%rax, 8(%r14)
.LBB109_56:
	movq	(%r9), %rax
	movq	%rax, (%r14)
.LBB109_58:
	cmpb	$0, 70(%r12)
	je	.LBB109_59
.LBB109_60:
	movq	%r14, %r15
	movl	72(%r12), %eax
	movl	(%r9,%rax), %eax
	leaq	90(%r12), %rcx
	cmpq	$32, %rax
	leaq	92(%r12,%rax,2), %rax
	cmovaeq	%rcx, %rax
	movzwl	(%rax), %eax
	xorl	%r14d, %r14d
	testl	%eax, %eax
	jne	.LBB109_62
	jmp	.LBB109_77
.LBB109_57:
	movq	%r14, %rdi
	movq	%r9, %rsi
	movq	%r13, %rdx
	movq	%r9, %r15
	callq	memcpy@PLT
	movq	%r15, %r9
	cmpb	$0, 70(%r12)
	jne	.LBB109_60
.LBB109_59:
	movq	%r14, %r15
	leaq	88(%r12), %rax
	movzwl	(%rax), %eax
	xorl	%r14d, %r14d
	testl	%eax, %eax
	je	.LBB109_77
.LBB109_62:
	movabsq	$4611686018427387904, %rcx      # imm = 0x4000000000000000
	leaq	2(%rcx), %rdx
	jmp	.LBB109_63
.LBB109_74:                             #   in Loop: Header=BB109_63 Depth=1
	cmpl	$0, -20(%rsi)
	je	.LBB109_92
.LBB109_75:                             #   in Loop: Header=BB109_63 Depth=1
	incl	%edi
	movl	%edi, -24(%rsi)
.LBB109_76:                             #   in Loop: Header=BB109_63 Depth=1
	blsrl	%eax, %eax
	je	.LBB109_77
.LBB109_63:                             # =>This Inner Loop Header: Depth=1
	tzcntl	%eax, %esi
	movzwl	156(%r12,%rsi,2), %esi
	movq	(%r9,%rsi), %rsi
	testq	%rsi, %rsi
	je	.LBB109_76
# %bb.64:                               #   in Loop: Header=BB109_63 Depth=1
	movq	-16(%rsi), %rdi
	testq	%rcx, %rdi
	je	.LBB109_67
# %bb.65:                               #   in Loop: Header=BB109_63 Depth=1
	movq	%rdi, %r8
	shrq	$40, %r8
	andl	$1048575, %r8d                  # imm = 0xFFFFF
	cmpl	-44(%rbp), %r8d                 # 4-byte Folded Reload
	ja	.LBB109_66
.LBB109_67:                             #   in Loop: Header=BB109_63 Depth=1
	testq	%rdx, %rdi
	jne	.LBB109_76
# %bb.68:                               #   in Loop: Header=BB109_63 Depth=1
	testb	$1, %dil
	jne	.LBB109_92
# %bb.69:                               #   in Loop: Header=BB109_63 Depth=1
	movl	-24(%rsi), %edi
	testl	%edi, %edi
	je	.LBB109_74
# %bb.70:                               #   in Loop: Header=BB109_63 Depth=1
	cmpl	$-1, %edi
	jne	.LBB109_75
# %bb.71:
	movl	$2, %r14d
	jmp	.LBB109_72
.LBB109_66:
	movl	$3, %r14d
	.p2align	4
.LBB109_72:                             # =>This Inner Loop Header: Depth=1
	tzcntl	%eax, %ecx
	movzwl	156(%r12,%rcx,2), %ecx
	movq	$0, (%r15,%rcx)
	blsrl	%eax, %eax
	jne	.LBB109_72
# %bb.73:
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	myl_rc_flat_edges_release
	movq	%r15, %rdi
	xorl	%esi, %esi
	movq	%r13, %rdx
	callq	memset@PLT
.LBB109_77:
	movq	5640(%rbx), %rax
	cmpq	$0, 200(%rax)
	je	.LBB109_79
.LBB109_78:
	movq	%rbx, %rdi
	callq	myl_rc_drain
.LBB109_79:
	testl	%r14d, %r14d
	je	.LBB109_80
# %bb.81:
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB109_92
.LBB109_82:
	xorl	%eax, %eax
	cmpl	$0, 292(%rcx)
	jne	.LBB109_124
# %bb.83:
	movl	%r14d, 292(%rcx)
	jmp	.LBB109_124
.LBB109_80:
	movl	$1, %eax
	jmp	.LBB109_124
.LBB109_16:
	cmpq	$97, %rdx
	setae	%al
	testb	$7, %dl
	setne	%cl
	orb	%al, %cl
	jne	.LBB109_31
# %bb.17:
	shrq	$3, %rdx
	movl	$1, %eax
	decq	%rdx
	cmpq	$11, %rdx
	ja	.LBB109_124
# %bb.18:
	jmpq	*.LJTI109_0(,%rdx,8)
.LBB109_19:
	movq	88(%r9), %rcx
	movq	%rcx, 88(%r14)
.LBB109_20:
	movq	80(%r9), %rcx
	movq	%rcx, 80(%r14)
.LBB109_21:
	movq	72(%r9), %rcx
	movq	%rcx, 72(%r14)
.LBB109_22:
	movq	64(%r9), %rcx
	movq	%rcx, 64(%r14)
.LBB109_23:
	movq	56(%r9), %rcx
	movq	%rcx, 56(%r14)
.LBB109_24:
	movq	48(%r9), %rcx
	movq	%rcx, 48(%r14)
.LBB109_25:
	movq	40(%r9), %rcx
	movq	%rcx, 40(%r14)
.LBB109_26:
	movq	32(%r9), %rcx
	movq	%rcx, 32(%r14)
.LBB109_27:
	movq	24(%r9), %rcx
	movq	%rcx, 24(%r14)
.LBB109_28:
	movq	16(%r9), %rcx
	movq	%rcx, 16(%r14)
.LBB109_29:
	movq	8(%r9), %rcx
	movq	%rcx, 8(%r14)
.LBB109_30:
	movq	(%r9), %rcx
	movq	%rcx, (%r14)
	jmp	.LBB109_124
.LBB109_31:
	movq	%r14, %rdi
	movq	%r9, %rsi
	callq	memcpy@PLT
	movl	$1, %eax
	jmp	.LBB109_124
.LBB109_15:
	movl	$3, 292(%rax)
	xorl	%eax, %eax
	jmp	.LBB109_124
.LBB109_3:
	movq	%r15, %rsi
	callq	myl_rc_binding_find_slow
	movq	%rax, %r12
	testq	%r12, %r12
	jne	.LBB109_5
.LBB109_93:
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r9, -56(%rbp)                  # 8-byte Spill
	callq	myl_rc_native_shape
	testq	%rax, %rax
	je	.LBB109_85
# %bb.94:
	movq	%rax, %r13
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	myl_rc_native_has_unique
	testl	%eax, %eax
	jne	.LBB109_92
.LBB109_95:
	movq	(%r15), %rdx
	movq	%r14, -72(%rbp)                 # 8-byte Spill
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movq	5640(%rbx), %r14
	testq	%r14, %r14
	je	.LBB109_92
# %bb.96:
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, -176(%rbp)
	vmovups	%ymm0, -208(%rbp)
	vmovups	%ymm0, -240(%rbp)
	vmovups	%ymm0, -272(%rbp)
	vmovups	%ymm0, -304(%rbp)
	vmovups	%ymm0, -336(%rbp)
	movq	$0, -144(%rbp)
	movq	%rbx, -128(%rbp)
	leaq	-592(%rbp), %rax
	movq	%rax, -120(%rbp)
	movq	$8, -112(%rbp)
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%xmm0, -104(%rbp)
	leaq	-336(%rbp), %rax
	movq	%rax, -88(%rbp)
	movq	88(%r14), %rax
	movq	96(%r14), %rdx
	movzbl	112(%r14), %ecx
	movabsq	$-7046029254386353131, %rsi     # imm = 0x9E3779B97F4A7C15
	imulq	%r13, %rsi
	shrxq	%rcx, %rsi, %r9
	andq	%rdx, %r9
	movq	%r9, %rsi
	shlq	$4, %rsi
	movq	(%rax,%rsi), %rsi
	movq	%r9, %rdi
	cmpq	%r13, %rsi
	movq	-56(%rbp), %rcx                 # 8-byte Reload
	je	.LBB109_100
# %bb.97:
	xorl	%r15d, %r15d
	movq	%rsi, %r8
	movq	%r9, %rdi
	.p2align	4
.LBB109_98:                             # =>This Inner Loop Header: Depth=1
	testq	%r8, %r8
	je	.LBB109_101
# %bb.99:                               #   in Loop: Header=BB109_98 Depth=1
	incq	%rdi
	andq	%rdx, %rdi
	movq	%rdi, %r8
	shlq	$4, %r8
	movq	(%rax,%r8), %r8
	cmpq	%r13, %r8
	jne	.LBB109_98
.LBB109_100:
	shlq	$4, %rdi
	movq	8(%rax,%rdi), %r15
	jmp	.LBB109_101
	.p2align	4
.LBB109_113:                            #   in Loop: Header=BB109_101 Depth=1
	testq	%rsi, %rsi
	je	.LBB109_92
# %bb.114:                              #   in Loop: Header=BB109_101 Depth=1
	incq	%r9
	andq	%rdx, %r9
	movq	%r9, %rsi
	shlq	$4, %rsi
	movq	(%rax,%rsi), %rsi
.LBB109_101:                            # =>This Inner Loop Header: Depth=1
	cmpq	%r13, %rsi
	jne	.LBB109_113
# %bb.102:
	testq	%r15, %r15
	je	.LBB109_92
# %bb.103:
	shlq	$4, %r9
	movq	8(%rax,%r9), %rax
	testq	%rax, %rax
	je	.LBB109_92
# %bb.104:
	movq	(%r15), %rdx
	cmpq	(%rax), %rdx
	jne	.LBB109_92
# %bb.105:
	cmpq	-72(%rbp), %rcx                 # 8-byte Folded Reload
	je	.LBB109_92
# %bb.106:
	movl	$3, %r12d
	movl	-44(%rbp), %eax                 # 4-byte Reload
	cmpl	112(%rbx), %eax
	ja	.LBB109_121
# %bb.107:
	movq	40(%r15), %r12
	cmpq	$9, %r12
	jb	.LBB109_118
# %bb.108:
	movq	%rbx, -64(%rbp)                 # 8-byte Spill
	movq	%r12, %rax
	shrq	$59, %rax
	jne	.LBB109_92
# %bb.109:
	movq	%r12, %rbx
	shlq	$5, %rbx
	movq	-64(%rbp), %rdx                 # 8-byte Reload
	movq	24(%rdx), %rsi
	addq	%rbx, %rsi
	jb	.LBB109_112
# %bb.110:
	movq	88(%rdx), %rax
	testq	%rax, %rax
	je	.LBB109_115
# %bb.111:
	cmpq	%rax, %rsi
	jbe	.LBB109_115
.LBB109_112:
	movl	$1, 108(%rdx)
	movl	$1, %r12d
	movq	%rdx, %rbx
	jmp	.LBB109_121
.LBB109_85:
	movq	(%r15), %rdx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	xorl	%eax, %eax
	jmp	.LBB109_124
.LBB109_115:
	movq	%rsi, -80(%rbp)                 # 8-byte Spill
	movq	%rcx, -56(%rbp)                 # 8-byte Spill
	movl	$1, %edi
	movq	%rbx, %rsi
	vzeroupper
	callq	calloc@PLT
	testq	%rax, %rax
	je	.LBB109_116
# %bb.117:
	movq	-64(%rbp), %rcx                 # 8-byte Reload
	movq	-80(%rbp), %rdx                 # 8-byte Reload
	movq	%rdx, 24(%rcx)
	addq	%rbx, 48(%r14)
	movq	%rcx, %rbx
	movq	%rax, -120(%rbp)
	movq	%r12, -112(%rbp)
	movq	-56(%rbp), %rcx                 # 8-byte Reload
.LBB109_118:
	movl	$1, %r8d
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	-72(%rbp), %r14                 # 8-byte Reload
	movq	%r14, %rdx
	movq	%rcx, %r12
	vzeroupper
	callq	myl_rc_value_seed
	movl	-44(%rbp), %eax                 # 4-byte Reload
	movl	%eax, -96(%rbp)
	leaq	-128(%rbp), %rdi
	movl	$retain_pointer, %r8d
	movq	%r15, %rsi
	movq	%r14, %rdx
	movq	%r12, %rcx
	callq	visit
	testl	%eax, %eax
	jne	.LBB109_120
# %bb.119:
	leaq	-128(%rbp), %rdi
	callq	finish_clones
	testl	%eax, %eax
	je	.LBB109_125
.LBB109_120:
	movl	%eax, %r12d
	movl	$1, %ecx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r14, %rdx
	callq	myl_rc_edges_release
	movq	(%r13), %rdx
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
.LBB109_121:
	leaq	-128(%rbp), %rdi
	movl	$1, %esi
	vzeroupper
	callq	dispose_walk
	movq	5640(%rbx), %rcx
	testq	%rcx, %rcx
	je	.LBB109_92
# %bb.122:
	xorl	%eax, %eax
	cmpl	$0, 292(%rcx)
	jne	.LBB109_124
# %bb.123:
	movl	%r12d, 292(%rcx)
.LBB109_124:
	addq	$552, %rsp                      # imm = 0x228
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.LBB109_125:
	.cfi_def_cfa %rbp, 16
	leaq	-128(%rbp), %rdi
	xorl	%esi, %esi
	callq	dispose_walk
	movl	$1, %eax
	jmp	.LBB109_124
.LBB109_116:
	movl	$1, %r12d
	movq	-64(%rbp), %rbx                 # 8-byte Reload
	jmp	.LBB109_121
.LBB109_92:
	vzeroupper
	callq	myl_rc_invariant_failed
.Lfunc_end109:
	.size	myl_rc_native_retain, .Lfunc_end109-myl_rc_native_retain
	.cfi_endproc
	.section	.rodata.myl_rc_native_retain,"a",@progbits
	.p2align	3, 0x0
.LJTI109_0:
	.quad	.LBB109_30
	.quad	.LBB109_29
	.quad	.LBB109_28
	.quad	.LBB109_27
	.quad	.LBB109_26
	.quad	.LBB109_25
	.quad	.LBB109_24
	.quad	.LBB109_23
	.quad	.LBB109_22
	.quad	.LBB109_21
	.quad	.LBB109_20
	.quad	.LBB109_19
.LJTI109_1:
	.quad	.LBB109_56
	.quad	.LBB109_55
	.quad	.LBB109_54
	.quad	.LBB109_53
	.quad	.LBB109_52
	.quad	.LBB109_51
	.quad	.LBB109_50
	.quad	.LBB109_49
	.quad	.LBB109_48
	.quad	.LBB109_47
	.quad	.LBB109_46
	.quad	.LBB109_45
                                        # -- End function
	.type	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0,@object # @myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0
	.section	.rodata.myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0,"a",@progbits
	.p2align	3, 0x0
myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	16                              # 0x10
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0, 112

	.type	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda,@object # @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	.section	.rodata.myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda,"a",@progbits
	.p2align	3, 0x0
myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	18                              # 0x12
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda, 112

	.type	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,@object # @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527
	.section	.rodata.myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,"a",@progbits
	.p2align	3, 0x0
myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	1                               # 0x1
	.short	1                               # 0x1
	.long	17                              # 0x11
	.quad	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, 112

	.type	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b,@object # @myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b
	.section	.rodata.myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b,"a",@progbits
	.p2align	3, 0x0
myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b:
	.quad	1                               # 0x1
	.quad	1                               # 0x1
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	33                              # 0x21
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b, 112

	.type	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9,@object # @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9
	.section	.rodata.myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9,"a",@progbits
	.p2align	3, 0x0
myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	1                               # 0x1
	.short	4                               # 0x4
	.long	19                              # 0x13
	.quad	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, 112

	.type	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef,@object # @myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef
	.section	.rodata.myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef,"a",@progbits
	.p2align	3, 0x0
myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef:
	.quad	2                               # 0x2
	.quad	2                               # 0x2
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	20                              # 0x14
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef, 112

	.type	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1,@object # @myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1
	.section	.rodata.myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1,"a",@progbits
	.p2align	3, 0x0
myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1:
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	21                              # 0x15
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1, 112

	.type	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80,@object # @myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80
	.section	.rodata.myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80,"a",@progbits
	.p2align	3, 0x0
myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	8                               # 0x8
	.short	0                               # 0x0
	.long	22                              # 0x16
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80, 112

	.type	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba,@object # @myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba
	.section	.rodata.myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba,"a",@progbits
	.p2align	3, 0x0
myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba:
	.quad	1                               # 0x1
	.quad	1                               # 0x1
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	23                              # 0x17
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba, 112

	.type	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af,@object # @myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af
	.section	.rodata.myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af,"a",@progbits
	.p2align	3, 0x0
myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af:
	.quad	4                               # 0x4
	.quad	4                               # 0x4
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	24                              # 0x18
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af, 112

	.type	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e,@object # @myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e
	.section	.rodata.myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e,"a",@progbits
	.p2align	3, 0x0
myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	25                              # 0x19
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e, 112

	.type	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18,@object # @myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18
	.section	.rodata.myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18,"a",@progbits
	.p2align	3, 0x0
myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields
	.quad	1                               # 0x1
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	7                               # 0x7
	.short	0                               # 0x0
	.long	26                              # 0x1a
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18, 112

	.type	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde,@object # @myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde
	.section	.rodata.myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde,"a",@progbits
	.p2align	3, 0x0
myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde:
	.quad	2                               # 0x2
	.quad	2                               # 0x2
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	27                              # 0x1b
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde, 112

	.type	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511,@object # @myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511
	.section	.rodata.myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511,"a",@progbits
	.p2align	3, 0x0
myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	28                              # 0x1c
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511, 112

	.type	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc,@object # @myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc
	.section	.rodata.myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc,"a",@progbits
	.p2align	3, 0x0
myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc:
	.quad	4                               # 0x4
	.quad	4                               # 0x4
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	36                              # 0x24
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc, 112

	.type	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a,@object # @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a
	.section	.rodata.myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a,"a",@progbits
	.p2align	3, 0x0
myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	1                               # 0x1
	.short	2                               # 0x2
	.long	29                              # 0x1d
	.quad	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, 112

	.type	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded,@object # @myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded
	.section	.rodata.myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded,"a",@progbits
	.p2align	3, 0x0
myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	30                              # 0x1e
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded, 112

	.type	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903,@object # @myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903
	.section	.rodata.myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903,"a",@progbits
	.p2align	3, 0x0
myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903:
	.quad	1                               # 0x1
	.quad	1                               # 0x1
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	31                              # 0x1f
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903, 112

	.type	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9,@object # @myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9
	.section	.rodata.myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9,"a",@progbits
	.p2align	3, 0x0
myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	32                              # 0x20
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9, 112

	.type	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5,@object # @myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5
	.section	.rodata.myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5,"a",@progbits
	.p2align	3, 0x0
myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	34                              # 0x22
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5, 112

	.type	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d,@object # @myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d
	.section	.rodata.myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d,"a",@progbits
	.p2align	3, 0x0
myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	35                              # 0x23
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d, 112

	.type	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98,@object # @myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98
	.section	.rodata.myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98,"a",@progbits
	.p2align	3, 0x0
myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	37                              # 0x25
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98, 112

	.type	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037,@object # @myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037
	.section	.rodata.myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037,"a",@progbits
	.p2align	3, 0x0
myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.short	8                               # 0x8
	.short	0                               # 0x0
	.long	38                              # 0x26
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037, 112

	.type	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,@object # @myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc
	.section	.rodata.myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc, 40

	.type	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,@object # @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc
	.section	.rodata.myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc:
	.quad	8                               # 0x8
	.long	1                               # 0x1
	.zero	4
	.zero	24
	.size	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc, 40

	.type	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc,@object # @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc
	.section	.rodata.myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc, 40

	.type	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc,@object # @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc
	.section	.rodata.myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc:
	.quad	8                               # 0x8
	.long	1                               # 0x1
	.zero	4
	.zero	24
	.size	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc, 40

	.type	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc,@object # @myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc
	.section	.rodata.myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc:
	.quad	2                               # 0x2
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc, 40

	.type	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc,@object # @myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc
	.section	.rodata.myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc:
	.zero	40
	.size	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc, 40

	.type	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc,@object # @myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc
	.section	.rodata.myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc, 40

	.type	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc,@object # @myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc
	.section	.rodata.myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc:
	.quad	1                               # 0x1
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc, 40

	.type	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc,@object # @myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc
	.section	.rodata.myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc:
	.quad	4                               # 0x4
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc, 40

	.type	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc,@object # @myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc
	.section	.rodata.myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc, 40

	.type	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc,@object # @myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc
	.section	.rodata.myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc:
	.quad	8                               # 0x8
	.long	2                               # 0x2
	.zero	4
	.quad	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields
	.quad	1                               # 0x1
	.zero	8
	.size	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc, 40

	.type	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc,@object # @myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc
	.section	.rodata.myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc:
	.quad	2                               # 0x2
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc, 40

	.type	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc,@object # @myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc
	.section	.rodata.myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc, 40

	.type	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc,@object # @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc
	.section	.rodata.myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc:
	.quad	8                               # 0x8
	.long	1                               # 0x1
	.zero	4
	.zero	24
	.size	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc, 40

	.type	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc,@object # @myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc
	.section	.rodata.myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc, 40

	.type	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc,@object # @myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc
	.section	.rodata.myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc:
	.quad	1                               # 0x1
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc, 40

	.type	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc,@object # @myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc
	.section	.rodata.myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc, 40

	.type	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc,@object # @myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc
	.section	.rodata.myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc:
	.quad	1                               # 0x1
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc, 40

	.type	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc,@object # @myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc
	.section	.rodata.myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc, 40

	.type	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc,@object # @myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc
	.section	.rodata.myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc, 40

	.type	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc,@object # @myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc
	.section	.rodata.myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc:
	.quad	4                               # 0x4
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc, 40

	.type	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc,@object # @myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc
	.section	.rodata.myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc, 40

	.type	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc,@object # @myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc
	.section	.rodata.myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc,"a",@progbits
	.p2align	3, 0x0
myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc:
	.quad	8                               # 0x8
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc, 40

	.type	myl_rc_generated_shapes,@object # @myl_rc_generated_shapes
	.section	.rodata.myl_rc_generated_shapes,"a",@progbits
	.p2align	4, 0x0
myl_rc_generated_shapes:
	.quad	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc
	.quad	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc
	.quad	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc
	.quad	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc
	.quad	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc
	.quad	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc
	.quad	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc
	.quad	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc
	.quad	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc
	.quad	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc
	.quad	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc
	.quad	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc
	.quad	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc
	.quad	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc
	.quad	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc
	.quad	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc
	.quad	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc
	.quad	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc
	.quad	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc
	.quad	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc
	.quad	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc
	.quad	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc
	.quad	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc
	.size	myl_rc_generated_shapes, 184

	.type	myl_rc_generated_descriptors,@object # @myl_rc_generated_descriptors
	.section	.rodata.myl_rc_generated_descriptors,"a",@progbits
	.p2align	4, 0x0
myl_rc_generated_descriptors:
	.quad	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0
	.quad	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527
	.quad	myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	.quad	myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9
	.quad	myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef
	.quad	myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1
	.quad	myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80
	.quad	myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba
	.quad	myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af
	.quad	myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e
	.quad	myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18
	.quad	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde
	.quad	myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511
	.quad	myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a
	.quad	myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded
	.quad	myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903
	.quad	myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9
	.quad	myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b
	.quad	myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5
	.quad	myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d
	.quad	myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc
	.quad	myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98
	.quad	myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037
	.quad	myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.size	myl_rc_generated_descriptors, 1472

	.type	qbe_empty_registry,@object      # @qbe_empty_registry
	.section	.rodata.qbe_empty_registry,"a",@progbits
	.p2align	3, 0x0
qbe_empty_registry:
	.zero	56
	.size	qbe_empty_registry, 56

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1:
	.asciz	"HostMissingRegistration"
	.size	.L.str.1, 24

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"HostInvalidBudget"
	.size	.L.str.2, 18

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"HostUnknownFunction"
	.size	.L.str.3, 20

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"entry::main"
	.size	.L.str.4, 12

	.type	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations,@object # @myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations
	.section	.rodata.myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations,"a",@progbits
	.p2align	4, 0x0
myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations:
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	15                              # 0xf
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	18                              # 0x12
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	21                              # 0x15
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	24                              # 0x18
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	27                              # 0x1b
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	30                              # 0x1e
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	33                              # 0x21
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	36                              # 0x24
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	14                              # 0xe
	.quad	.L.str.14
	.quad	3                               # 0x3
	.quad	5                               # 0x5
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	19                              # 0x13
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	15                              # 0xf
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	15                              # 0xf
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	15                              # 0xf
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	.L.str.14
	.quad	4                               # 0x4
	.quad	5                               # 0x5
	.quad	.L.str.14
	.quad	5                               # 0x5
	.quad	12                              # 0xc
	.quad	.L.str.14
	.quad	5                               # 0x5
	.quad	5                               # 0x5
	.size	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations, 936

	.type	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages,@object # @myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages
	.section	.data.myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages,"aw",@progbits
	.p2align	4, 0x0
myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages:
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.quad	.L.str.172
	.size	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages, 312

	.type	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta,@object # @myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta
	.section	.rodata.myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta,"a",@progbits
	.p2align	3, 0x0
myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta:
	.quad	.L.str.4
	.quad	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations
	.quad	39                              # 0x27
	.quad	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages
	.quad	0
	.quad	0                               # 0x0
	.size	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta, 48

	.type	mylang_frame_map_functions,@object # @mylang_frame_map_functions
	.section	.rodata.mylang_frame_map_functions,"a",@progbits
	.p2align	3, 0x0
mylang_frame_map_functions:
	.quad	myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta
	.size	mylang_frame_map_functions, 8

	.type	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields,@object # @myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields
	.section	.rodata.myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields,"a",@progbits
	.p2align	4, 0x0
myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields:
	.quad	0                               # 0x0
	.quad	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0
	.long	0                               # 0x0
	.zero	4
	.size	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields, 24

	.type	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields,@object # @myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields
	.section	.rodata.myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields,"a",@progbits
	.p2align	4, 0x0
myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields:
	.quad	0                               # 0x0
	.quad	myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc
	.long	0                               # 0x0
	.zero	4
	.size	myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields, 24

	.type	.L.str.14,@object               # @.str.14
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.14:
	.asciz	"entry.my"
	.size	.L.str.14, 9

	.type	myl_rc_generated_module,@object # @myl_rc_generated_module
	.section	.rodata.myl_rc_generated_module,"a",@progbits
	.p2align	3, 0x0
myl_rc_generated_module:
	.long	4                               # 0x4
	.zero	4
	.quad	myl_rc_generated_shapes
	.quad	23                              # 0x17
	.quad	myl_rc_generated_descriptors
	.quad	23                              # 0x17
	.size	myl_rc_generated_module, 40

	.type	exit_without_sweep,@object      # @exit_without_sweep
	.section	.bss.exit_without_sweep,"aw",@nobits
	.p2align	2, 0x0
exit_without_sweep:
	.byte	0                               # 0x0
	.size	exit_without_sweep, 1

	.type	.L.str.16.30,@object            # @.str.16.30
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.16.30:
	.asciz	"R_COW_DEPTH"
	.size	.L.str.16.30, 12

	.type	.L.str.17,@object               # @.str.17
.L.str.17:
	.asciz	"R_MEMORY_BUDGET"
	.size	.L.str.17, 16

	.type	.L.str.20,@object               # @.str.20
.L.str.20:
	.asciz	"R_REQUIRES"
	.size	.L.str.20, 11

	.type	.L.str.21,@object               # @.str.21
.L.str.21:
	.asciz	"R_ENSURES"
	.size	.L.str.21, 10

	.type	.L.str.22,@object               # @.str.22
.L.str.22:
	.asciz	"R_INVARIANT"
	.size	.L.str.22, 12

	.type	.L.str.27,@object               # @.str.27
.L.str.27:
	.asciz	"R_OVERFLOW"
	.size	.L.str.27, 11

	.type	.L.str.28,@object               # @.str.28
.L.str.28:
	.asciz	"cast"
	.size	.L.str.28, 5

	.type	.L.str.29,@object               # @.str.29
.L.str.29:
	.asciz	"R_STEP_LIMIT"
	.size	.L.str.29, 13

	.type	.L.str.30,@object               # @.str.30
.L.str.30:
	.asciz	"R_FRAME_LIMIT"
	.size	.L.str.30, 14

	.type	.L.str.32,@object               # @.str.32
.L.str.32:
	.asciz	"R_INTERNAL"
	.size	.L.str.32, 11

	.type	.L.str.34,@object               # @.str.34
.L.str.34:
	.asciz	"R_NO_STEP_ACCOUNTING"
	.size	.L.str.34, 21

	.type	.L.str.35,@object               # @.str.35
.L.str.35:
	.asciz	"run it under `mylang run --max-steps=N`, or rebuild it with --mode Debug"
	.size	.L.str.35, 73

	.type	.L.str.36,@object               # @.str.36
.L.str.36:
	.asciz	"R_NO_FRAME_ACCOUNTING"
	.size	.L.str.36, 22

	.type	.L.str.37,@object               # @.str.37
.L.str.37:
	.asciz	"run it under `mylang run --max-frames=N`, or rebuild it with --mode Debug"
	.size	.L.str.37, 74

	.type	.L.str.38,@object               # @.str.38
.L.str.38:
	.asciz	"--max-steps="
	.size	.L.str.38, 13

	.type	.L.str.39,@object               # @.str.39
.L.str.39:
	.asciz	"--max-frames="
	.size	.L.str.39, 14

	.type	.L.str.40,@object               # @.str.40
.L.str.40:
	.asciz	"--timeout="
	.size	.L.str.40, 11

	.type	.L.str.41,@object               # @.str.41
.L.str.41:
	.asciz	"--gc-stress"
	.size	.L.str.41, 12

	.type	stress_needs_gc,@object         # @stress_needs_gc
	.section	.rodata.stress_needs_gc,"a",@progbits
	.p2align	4, 0x0
stress_needs_gc:
	.asciz	"GcStressNeedsGcRuntime"
	.size	stress_needs_gc, 23

	.type	.L.str.42,@object               # @.str.42
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.42:
	.asciz	"--print-result"
	.size	.L.str.42, 15

	.type	.L.str.44,@object               # @.str.44
.L.str.44:
	.asciz	"mylang: --gc-stress needs a program built with --gc-runtime; this one uses reference counting\n"
	.size	.L.str.44, 95

	.type	.L.str.45,@object               # @.str.45
.L.str.45:
	.asciz	"%s: QBE runtime failure\n"
	.size	.L.str.45, 25

	.type	.L.str.46,@object               # @.str.46
.L.str.46:
	.asciz	"mylang: cannot arm the --timeout wall-clock guard\n"
	.size	.L.str.46, 51

	.type	.L.str.47,@object               # @.str.47
.L.str.47:
	.asciz	"mylang: guest argument is not valid UTF-8\n"
	.size	.L.str.47, 43

	.type	.L.str.48,@object               # @.str.48
.L.str.48:
	.asciz	"; broken by the caller %s at %s:%lu:%lu"
	.size	.L.str.48, 40

	.type	.L.str.49,@object               # @.str.49
.L.str.49:
	.asciz	"%s:%lu:%lu: error[%s]: %s%s\n"
	.size	.L.str.49, 29

	.type	.L.str.50,@object               # @.str.50
.L.str.50:
	.asciz	"%s: %s%s\n"
	.size	.L.str.50, 10

	.type	.L.str.51,@object               # @.str.51
.L.str.51:
	.asciz	"  in %s at %s:%lu:%lu\n"
	.size	.L.str.51, 23

	.type	.L.str.52,@object               # @.str.52
.L.str.52:
	.asciz	"%s%s\n"
	.size	.L.str.52, 6

	.type	.L.str.53,@object               # @.str.53
.L.str.53:
	.asciz	"\036MYLANG-TRAP "
	.size	.L.str.53, 14

	.type	.L.str.55,@object               # @.str.55
.L.str.55:
	.asciz	"%ld\n"
	.size	.L.str.55, 5

	.hidden	__start_mylang_frame_map
	.hidden	__stop_mylang_frame_map
	.type	frame_sites,@object             # @frame_sites
	.section	.bss.frame_sites,"aw",@nobits
	.p2align	3, 0x0
frame_sites:
	.quad	0
	.size	frame_sites, 8

	.type	frame_site_count,@object        # @frame_site_count
	.section	.bss.frame_site_count,"aw",@nobits
	.p2align	3, 0x0
frame_site_count:
	.quad	0                               # 0x0
	.size	frame_site_count, 8

	.type	frame_sites_ready,@object       # @frame_sites_ready
	.section	.bss.frame_sites_ready,"aw",@nobits
	.p2align	2, 0x0
frame_sites_ready:
	.byte	0                               # 0x0
	.size	frame_sites_ready, 1

	.type	.L.str.60,@object               # @.str.60
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.60:
	.asciz	"operation"
	.size	.L.str.60, 10

	.type	.L.str.69,@object               # @.str.69
.L.str.69:
	.asciz	"arithmetic"
	.size	.L.str.69, 11

	.type	.L.str.70,@object               # @.str.70
.L.str.70:
	.asciz	"R_FLOAT_ENVIRONMENT"
	.size	.L.str.70, 20

	.type	.L.str.71,@object               # @.str.71
.L.str.71:
	.asciz	"RepeatedRuntimeOption"
	.size	.L.str.71, 22

	.type	.L.str.72,@object               # @.str.72
.L.str.72:
	.asciz	"InvalidBudget"
	.size	.L.str.72, 14

	.type	timeout_timer,@object           # @timeout_timer
	.section	.bss.timeout_timer,"aw",@nobits
	.p2align	3, 0x0
timeout_timer:
	.quad	0
	.size	timeout_timer, 8

	.type	on_timeout.message,@object      # @on_timeout.message
	.section	.rodata.on_timeout.message,"a",@progbits
	.p2align	4, 0x0
on_timeout.message:
	.asciz	"R_TIMEOUT: wall-clock budget exhausted; raise it with --timeout=SECONDS\n"
	.size	on_timeout.message, 73

	.type	.L.str.73,@object               # @.str.73
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.73:
	.asciz	" (index %ld"
	.size	.L.str.73, 12

	.type	.L.str.74,@object               # @.str.74
.L.str.74:
	.asciz	", length %lu"
	.size	.L.str.74, 13

	.type	.L.str.75,@object               # @.str.75
.L.str.75:
	.asciz	")"
	.size	.L.str.75, 2

	.type	.L.str.76,@object               # @.str.76
.L.str.76:
	.asciz	" (length %lu)"
	.size	.L.str.76, 14

	.type	.L.str.77,@object               # @.str.77
.L.str.77:
	.asciz	" (%s:"
	.size	.L.str.77, 6

	.type	.L.str.78,@object               # @.str.78
.L.str.78:
	.asciz	" left %lu"
	.size	.L.str.78, 10

	.type	.L.str.79,@object               # @.str.79
.L.str.79:
	.asciz	", right %lu"
	.size	.L.str.79, 12

	.type	.L.str.80,@object               # @.str.80
.L.str.80:
	.asciz	" left %ld"
	.size	.L.str.80, 10

	.type	.L.str.81,@object               # @.str.81
.L.str.81:
	.asciz	", right %ld"
	.size	.L.str.81, 12

	.type	.L.str.82,@object               # @.str.82
.L.str.82:
	.asciz	", width %lu"
	.size	.L.str.82, 12

	.type	.L.str.83,@object               # @.str.83
.L.str.83:
	.asciz	": %s"
	.size	.L.str.83, 5

	.type	.L.str.84,@object               # @.str.84
.L.str.84:
	.asciz	"memory budget exhausted"
	.size	.L.str.84, 24

	.type	.L.str.85,@object               # @.str.85
.L.str.85:
	.asciz	"instruction budget exhausted; raise it with --max-steps=N"
	.size	.L.str.85, 58

	.type	.L.str.86,@object               # @.str.86
.L.str.86:
	.asciz	"this build omits instruction-budget accounting"
	.size	.L.str.86, 47

	.type	.L.str.87,@object               # @.str.87
.L.str.87:
	.asciz	"this build omits call-depth accounting"
	.size	.L.str.87, 39

	.type	.L.str.88,@object               # @.str.88
.L.str.88:
	.asciz	"call-depth budget exhausted; raise it with --max-frames=N (each frame reserves 32 KiB of stack, so --max-memory must cover N x 32 KiB)"
	.size	.L.str.88, 135

	.type	.L.str.89,@object               # @.str.89
.L.str.89:
	.asciz	"precondition violated"
	.size	.L.str.89, 22

	.type	.L.str.90,@object               # @.str.90
.L.str.90:
	.asciz	"postcondition violated"
	.size	.L.str.90, 23

	.type	.L.str.91,@object               # @.str.91
.L.str.91:
	.asciz	"invariant violated"
	.size	.L.str.91, 19

	.type	.L.str.92,@object               # @.str.92
.L.str.92:
	.asciz	"QBE runtime failure"
	.size	.L.str.92, 20

	.type	.L.str.93,@object               # @.str.93
.L.str.93:
	.asciz	"native execution failed"
	.size	.L.str.93, 24

	.type	.L.str.94,@object               # @.str.94
.L.str.94:
	.asciz	"{\"version\":%u,\"operation\":"
	.size	.L.str.94, 27

	.type	.L.str.95,@object               # @.str.95
.L.str.95:
	.asciz	",\"index\":%ld"
	.size	.L.str.95, 13

	.type	.L.str.96,@object               # @.str.96
.L.str.96:
	.asciz	",\"length\":%lu"
	.size	.L.str.96, 14

	.type	.L.str.97,@object               # @.str.97
.L.str.97:
	.asciz	",\"unsigned\":true"
	.size	.L.str.97, 17

	.type	.L.str.98,@object               # @.str.98
.L.str.98:
	.asciz	",\"left\":%lu"
	.size	.L.str.98, 12

	.type	.L.str.99,@object               # @.str.99
.L.str.99:
	.asciz	",\"right\":%lu"
	.size	.L.str.99, 13

	.type	.L.str.100,@object              # @.str.100
.L.str.100:
	.asciz	",\"left\":%ld"
	.size	.L.str.100, 12

	.type	.L.str.101,@object              # @.str.101
.L.str.101:
	.asciz	",\"right\":%ld"
	.size	.L.str.101, 13

	.type	.L.str.102,@object              # @.str.102
.L.str.102:
	.asciz	",\"width\":%lu"
	.size	.L.str.102, 13

	.type	.L.str.103,@object              # @.str.103
.L.str.103:
	.asciz	"}"
	.size	.L.str.103, 2

	.type	.L.str.104,@object              # @.str.104
.L.str.104:
	.asciz	"\""
	.size	.L.str.104, 2

	.type	.L.str.105,@object              # @.str.105
.L.str.105:
	.asciz	"\\%c"
	.size	.L.str.105, 4

	.type	.L.str.106,@object              # @.str.106
.L.str.106:
	.asciz	"\\u%04x"
	.size	.L.str.106, 7

	.type	.L.str.107,@object              # @.str.107
.L.str.107:
	.asciz	"%c"
	.size	.L.str.107, 3

	.type	.L.str.108,@object              # @.str.108
.L.str.108:
	.asciz	"InvalidMemoryLimit"
	.size	.L.str.108, 19

	.type	.L.str.43,@object               # @.str.43
.L.str.43:
	.asciz	"MYLANG_MEMORY_LIMIT"
	.size	.L.str.43, 20

	.type	.L.str.1.46,@object             # @.str.1.46
.L.str.1.46:
	.asciz	"MYLANG_HOST_LIMIT_RESTORE"
	.size	.L.str.1.46, 26

	.type	.L.str.2.47,@object             # @.str.2.47
.L.str.2.47:
	.asciz	"MYLANG_HOST_LIMIT_CHECKPOINT"
	.size	.L.str.2.47, 29

	.type	.L.str.3.50,@object             # @.str.3.50
.L.str.3.50:
	.asciz	"mylang runtime: a descriptor's scan plan disagrees with its fields\n"
	.size	.L.str.3.50, 68

	.type	list_scan,@object               # @list_scan
	.section	.rodata.list_scan,"a",@progbits
	.p2align	2, 0x0
list_scan:
	.long	32                              # 0x20
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.size	list_scan, 12

	.type	list_fields,@object             # @list_fields
	.section	.rodata.list_fields,"a",@progbits
	.p2align	4, 0x0
list_fields:
	.quad	32                              # 0x20
	.quad	myl_rc_pointer_leaf
	.long	0                               # 0x0
	.zero	4
	.size	list_fields, 24

	.type	rc_list_descriptors,@object     # @rc_list_descriptors
	.section	.rodata.rc_list_descriptors,"a",@progbits
	.p2align	4, 0x0
rc_list_descriptors:
	.quad	myl_native_list_header_descriptor
	.quad	rc_list_shape
	.quad	rc_list_edges
	.quad	0
	.quad	rc_list_clone_adapter
	.quad	rc_list_shell
	.quad	rc_list_next
	.quad	rc_list_span
	.quad	rc_storage_type
	.quad	rc_list_shape
	.quad	rc_storage_edges
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.size	rc_list_descriptors, 128

	.type	rc_list_module,@object          # @rc_list_module
	.section	.rodata.rc_list_module,"a",@progbits
	.p2align	3, 0x0
rc_list_module:
	.long	4                               # 0x4
	.zero	4
	.quad	0
	.quad	0                               # 0x0
	.quad	rc_list_descriptors
	.quad	2                               # 0x2
	.size	rc_list_module, 40

	.type	rc_storage_type,@object         # @rc_storage_type
	.section	.rodata.rc_storage_type,"a",@progbits
	.p2align	3, 0x0
rc_storage_type:
	.quad	72                              # 0x48
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	3                               # 0x3
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	rc_storage_type, 112

	.type	rc_list_shape,@object           # @rc_list_shape
	.section	.rodata.rc_list_shape,"a",@progbits
	.p2align	3, 0x0
rc_list_shape:
	.quad	72                              # 0x48
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	rc_list_shape, 40

	.type	rc_dict_type,@object            # @rc_dict_type
	.section	.rodata.rc_dict_type,"a",@progbits
	.p2align	3, 0x0
rc_dict_type:
	.quad	304                             # 0x130
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	6                               # 0x6
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	rc_dict_type, 112

	.type	dict_type,@object               # @dict_type
	.section	.rodata.dict_type,"a",@progbits
	.p2align	3, 0x0
dict_type:
	.quad	304                             # 0x130
	.quad	8                               # 0x8
	.quad	dict_fields
	.quad	2                               # 0x2
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	2                               # 0x2
	.short	0                               # 0x0
	.long	0                               # 0x0
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.quad	dict_scan
	.quad	2                               # 0x2
	.size	dict_type, 112

	.type	dict_scan,@object               # @dict_scan
	.section	.rodata.dict_scan,"a",@progbits
	.p2align	4, 0x0
dict_scan:
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	208                             # 0xd0
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.size	dict_scan, 24

	.type	dict_fields,@object             # @dict_fields
	.section	.rodata.dict_fields,"a",@progbits
	.p2align	4, 0x0
dict_fields:
	.quad	0                               # 0x0
	.quad	myl_rc_pointer_leaf
	.long	0                               # 0x0
	.zero	4
	.quad	208                             # 0xd0
	.quad	myl_rc_pointer_leaf
	.long	0                               # 0x0
	.zero	4
	.size	dict_fields, 48

	.type	.L.str.1.110,@object            # @.str.1.110
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1.110:
	.asciz	"more native stack than can be addressed"
	.size	.L.str.1.110, 40

	.type	.L.str.2.111,@object            # @.str.2.111
.L.str.2.111:
	.asciz	"%.1f GiB of native stack"
	.size	.L.str.2.111, 25

	.type	.L.str.3.112,@object            # @.str.3.112
.L.str.3.112:
	.asciz	"the system refused the mapping"
	.size	.L.str.3.112, 31

	.type	.L.str.4.113,@object            # @.str.4.113
.L.str.4.113:
	.asciz	"this process may map only %.1f GiB"
	.size	.L.str.4.113, 35

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"mylang: a call-depth budget of %lu frames (--max-frames) reserves %s (%u KiB per frame), but %s; raise --max-memory (and MYLANG_HOST_MEMORY_LIMIT, which a guest inherits) or lower --max-frames\n"
	.size	.L.str.5, 194

	.type	.L.str.122,@object              # @.str.122
.L.str.122:
	.asciz	"OutOfMemory"
	.size	.L.str.122, 12

	.type	.L.str.1.123,@object            # @.str.1.123
.L.str.1.123:
	.asciz	"R_REFERENCE_COUNT_LIMIT"
	.size	.L.str.1.123, 24

	.type	.L.str.2.124,@object            # @.str.2.124
.L.str.2.124:
	.asciz	"R_ARENA_ESCAPE"
	.size	.L.str.2.124, 15

	.type	.Lswitch.table.myl_rc_status_code,@object # @switch.table.myl_rc_status_code
	.section	.rodata..Lswitch.table.myl_rc_status_code,"a",@progbits
	.p2align	3, 0x0
.Lswitch.table.myl_rc_status_code:
	.quad	0
	.quad	.L.str.122
	.quad	.L.str.1.123
	.quad	.L.str.2.124
	.size	.Lswitch.table.myl_rc_status_code, 32

	.type	myl_rc_map_sentinel,@object     # @myl_rc_map_sentinel
	.section	.rodata.myl_rc_map_sentinel,"a",@progbits
	.p2align	4, 0x0
myl_rc_map_sentinel:
	.zero	16
	.size	myl_rc_map_sentinel, 16

	.type	.L.str.1.160,@object            # @.str.1.160
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.1.160:
	.asciz	"%lld"
	.size	.L.str.1.160, 5

	.type	.L.str.1.168,@object            # @.str.1.168
.L.str.1.168:
	.asciz	"InternalError"
	.size	.L.str.1.168, 14

	.type	.L.str.2.169,@object            # @.str.2.169
.L.str.2.169:
	.asciz	"R_OUTPUT"
	.size	.L.str.2.169, 9

	.type	.L.str.172,@object              # @.str.172
.L.str.172:
	.zero	1
	.size	.L.str.172, 1

	.type	.L.str.1.181,@object            # @.str.1.181
.L.str.1.181:
	.asciz	"mylang: a requested directory grant could not be opened\n"
	.size	.L.str.1.181, 57

	.type	.L.str.2.173,@object            # @.str.2.173
.L.str.2.173:
	.asciz	"MYLANG_OPTIONS"
	.size	.L.str.2.173, 15

	.type	.L.str.3.174,@object            # @.str.3.174
.L.str.3.174:
	.asciz	"OutOfMemory: QBE runtime failure\n"
	.size	.L.str.3.174, 34

	.type	.L.str.4.175,@object            # @.str.4.175
.L.str.4.175:
	.asciz	"mylang: MYLANG_OPTIONS has an unterminated quote\n"
	.size	.L.str.4.175, 50

	.type	.L.str.5.180,@object            # @.str.5.180
.L.str.5.180:
	.asciz	"mylang: the option %s is not a usable capability grant\n"
	.size	.L.str.5.180, 56

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"mylang: MYLANG_OPTIONS names %s, which is not a runtime option\n"
	.size	.L.str.6, 64

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"--restrict"
	.size	.L.str.7, 11

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"--allow-read="
	.size	.L.str.8, 14

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"--allow-write="
	.size	.L.str.9, 15

	.type	.L.str.10,@object               # @.str.10
.L.str.10:
	.asciz	"--allow-endpoint="
	.size	.L.str.10, 18

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	"--allow-clock"
	.size	.L.str.11, 14

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	"--allow-host"
	.size	.L.str.12, 13

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"--allow-random"
	.size	.L.str.13, 15

	.type	.L.str.14.176,@object           # @.str.14.176
.L.str.14.176:
	.asciz	"--allow-env"
	.size	.L.str.14.176, 12

	.type	.L.str.15.177,@object           # @.str.15.177
.L.str.15.177:
	.asciz	"--allow-all"
	.size	.L.str.15.177, 12

	.type	.L.str.17.179,@object           # @.str.17.179
.L.str.17.179:
	.asciz	"*"
	.size	.L.str.17.179, 2

	.type	.L.str.18,@object               # @.str.18
.L.str.18:
	.asciz	"--allow-"
	.size	.L.str.18, 9

	.type	.L.str.192,@object              # @.str.192
.L.str.192:
	.asciz	"."
	.size	.L.str.192, 2

	.type	.L__const.read_handle.result,@object # @__const.read_handle.result
	.section	.rodata..L__const.read_handle.result,"a",@progbits
	.p2align	3, 0x0
.L__const.read_handle.result:
	.long	3                               # 0x3
	.zero	4
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.zero	4
	.size	.L__const.read_handle.result, 24

	.type	cow_depth_exceeded,@object      # @cow_depth_exceeded
	.section	.tbss.cow_depth_exceeded,"awT",@nobits
	.p2align	2, 0x0
cow_depth_exceeded:
	.long	0                               # 0x0
	.size	cow_depth_exceeded, 4

	.type	myl_native_list_header_descriptor,@object # @myl_native_list_header_descriptor
	.section	.rodata.myl_native_list_header_descriptor,"a",@progbits
	.p2align	3, 0x0
myl_native_list_header_descriptor:
	.quad	72                              # 0x48
	.quad	8                               # 0x8
	.quad	list_fields
	.quad	1                               # 0x1
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	2                               # 0x2
	.short	0                               # 0x0
	.long	2                               # 0x2
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.quad	list_scan
	.quad	1                               # 0x1
	.size	myl_native_list_header_descriptor, 112

	.type	myl_rc_pointer_leaf,@object     # @myl_rc_pointer_leaf
	.section	.rodata.myl_rc_pointer_leaf,"a",@progbits
	.p2align	3, 0x0
myl_rc_pointer_leaf:
	.quad	8                               # 0x8
	.quad	8                               # 0x8
	.quad	0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	1                               # 0x1
	.short	0                               # 0x0
	.long	7                               # 0x7
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	myl_rc_pointer_leaf, 112

	.type	strides,@object                 # @strides
	.section	.rodata.strides,"a",@progbits
	.p2align	4, 0x0
strides:
	.quad	16                              # 0x10
	.quad	32                              # 0x20
	.quad	48                              # 0x30
	.quad	64                              # 0x40
	.quad	80                              # 0x50
	.quad	96                              # 0x60
	.quad	112                             # 0x70
	.quad	128                             # 0x80
	.quad	160                             # 0xa0
	.quad	192                             # 0xc0
	.quad	224                             # 0xe0
	.quad	256                             # 0x100
	.quad	320                             # 0x140
	.quad	384                             # 0x180
	.quad	448                             # 0x1c0
	.quad	512                             # 0x200
	.quad	640                             # 0x280
	.quad	768                             # 0x300
	.quad	896                             # 0x380
	.quad	1024                            # 0x400
	.quad	1280                            # 0x500
	.quad	1536                            # 0x600
	.quad	1792                            # 0x700
	.quad	2048                            # 0x800
	.quad	2560                            # 0xa00
	.quad	3072                            # 0xc00
	.quad	3584                            # 0xe00
	.quad	4096                            # 0x1000
	.quad	5120                            # 0x1400
	.quad	6144                            # 0x1800
	.quad	7168                            # 0x1c00
	.quad	8192                            # 0x2000
	.size	strides, 256

	.type	allocator,@object               # @allocator
	.section	.rodata.allocator,"a",@progbits
	.p2align	3, 0x0
allocator:
	.quad	allocate
	.quad	myl_rc_storage_retire
	.quad	destroy
	.quad	teardown
	.size	allocator, 32

	.type	class_of,@object                # @class_of
	.section	.rodata.class_of,"a",@progbits
	.p2align	4, 0x0
class_of:
	.ascii	"\000\000\001\002\003\004\005\006\007\b\b\t\t\n\n\013\013\f\f\f\f\r\r\r\r\016\016\016\016\017\017\017\017\020\020\020\020\020\020\020\020\021\021\021\021\021\021\021\021\022\022\022\022\022\022\022\022\023\023\023\023\023\023\023\023\024\024\024\024\024\024\024\024\024\024\024\024\024\024\024\024\025\025\025\025\025\025\025\025\025\025\025\025\025\025\025\025\026\026\026\026\026\026\026\026\026\026\026\026\026\026\026\026\027\027\027\027\027\027\027\027\027\027\027\027\027\027\027\027\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\030\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\031\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\032\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\033\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\034\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\035\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\036\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037\037"
	.size	class_of, 513

	.type	raw_descriptor,@object          # @raw_descriptor
	.section	.rodata.raw_descriptor,"a",@progbits
	.p2align	3, 0x0
raw_descriptor:
	.quad	raw_type
	.quad	raw_shape
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.size	raw_descriptor, 64

	.type	raw_module,@object              # @raw_module
	.section	.rodata.raw_module,"a",@progbits
	.p2align	3, 0x0
raw_module:
	.long	4                               # 0x4
	.zero	4
	.quad	0
	.quad	0                               # 0x0
	.quad	raw_descriptor
	.quad	1                               # 0x1
	.size	raw_module, 40

	.type	raw_type,@object                # @raw_type
	.section	.rodata.raw_type,"a",@progbits
	.p2align	3, 0x0
raw_type:
	.quad	1                               # 0x1
	.quad	1                               # 0x1
	.quad	0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.short	0                               # 0x0
	.short	0                               # 0x0
	.long	1                               # 0x1
	.quad	0
	.quad	0
	.quad	0
	.quad	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.quad	0
	.quad	0                               # 0x0
	.size	raw_type, 112

	.type	raw_shape,@object               # @raw_shape
	.section	.rodata.raw_shape,"a",@progbits
	.p2align	3, 0x0
raw_shape:
	.quad	1                               # 0x1
	.long	0                               # 0x0
	.zero	4
	.zero	24
	.size	raw_shape, 40

	.section	.pseudo_probe_desc,"G",@progbits,.pseudo_probe_desc_myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491,comdat
	.quad	-2444756198778344158
	.quad	0
	.byte	70
	.ascii	"myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491"
	.weak	_Unwind_Backtrace
	.weak	_Unwind_GetIP
	.weak	myl_rc_generated_image
	.weak	__start_mylang_frame_map
	.weak	__stop_mylang_frame_map
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym entry_run
	.addrsig_sym trace_visit
	.addrsig_sym _Unwind_Backtrace
	.addrsig_sym _Unwind_GetIP
	.addrsig_sym unwind_step
	.addrsig_sym site_order
	.addrsig_sym on_timeout
	.addrsig_sym rc_list_edges
	.addrsig_sym rc_list_clone_adapter
	.addrsig_sym rc_list_shell
	.addrsig_sym rc_list_next
	.addrsig_sym rc_list_span
	.addrsig_sym rc_storage_edges
	.addrsig_sym launch
	.addrsig_sym clock_now
	.addrsig_sym random_u64
	.addrsig_sym environment_get
	.addrsig_sym acquire_network
	.addrsig_sym complete
	.addrsig_sym release
	.addrsig_sym read_handle
	.addrsig_sym write_handle
	.addrsig_sym acquire
	.addrsig_sym transfer_pointer
	.addrsig_sym rollback_take
	.addrsig_sym commit_take
	.addrsig_sym retain_pointer
	.addrsig_sym allocate
	.addrsig_sym myl_rc_storage_retire
	.addrsig_sym destroy
	.addrsig_sym teardown
	.addrsig_sym myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0
	.addrsig_sym myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	.addrsig_sym myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527
	.addrsig_sym myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b
	.addrsig_sym myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9
	.addrsig_sym myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef
	.addrsig_sym myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1
	.addrsig_sym myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80
	.addrsig_sym myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba
	.addrsig_sym myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af
	.addrsig_sym myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e
	.addrsig_sym myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18
	.addrsig_sym myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde
	.addrsig_sym myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511
	.addrsig_sym myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc
	.addrsig_sym myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a
	.addrsig_sym myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded
	.addrsig_sym myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903
	.addrsig_sym myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9
	.addrsig_sym myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5
	.addrsig_sym myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d
	.addrsig_sym myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98
	.addrsig_sym myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037
	.addrsig_sym myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc
	.addrsig_sym myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc
	.addrsig_sym myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc
	.addrsig_sym myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc
	.addrsig_sym myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc
	.addrsig_sym myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc
	.addrsig_sym myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc
	.addrsig_sym myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc
	.addrsig_sym myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc
	.addrsig_sym myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc
	.addrsig_sym myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc
	.addrsig_sym myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc
	.addrsig_sym myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc
	.addrsig_sym myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc
	.addrsig_sym myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc
	.addrsig_sym myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc
	.addrsig_sym myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc
	.addrsig_sym myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc
	.addrsig_sym myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc
	.addrsig_sym myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc
	.addrsig_sym myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc
	.addrsig_sym myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc
	.addrsig_sym myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc
	.addrsig_sym myl_rc_generated_shapes
	.addrsig_sym myl_rc_generated_descriptors
	.addrsig_sym qbe_empty_registry
	.addrsig_sym myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_locations
	.addrsig_sym myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta_messages
	.addrsig_sym myl_f_b03087d584d97cdc25f5d720d519c6a9e6073555f6119fd89958780bd3b0c491_meta
	.addrsig_sym mylang_frame_map_functions
	.addrsig_sym myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields
	.addrsig_sym myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields
	.addrsig_sym myl_rc_generated_image
	.addrsig_sym myl_rc_generated_module
	.addrsig_sym stress_needs_gc
	.addrsig_sym __start_mylang_frame_map
	.addrsig_sym __stop_mylang_frame_map
	.addrsig_sym timeout_timer
	.addrsig_sym on_timeout.message
	.addrsig_sym list_scan
	.addrsig_sym list_fields
	.addrsig_sym rc_list_descriptors
	.addrsig_sym rc_list_module
	.addrsig_sym rc_storage_type
	.addrsig_sym rc_list_shape
	.addrsig_sym rc_dict_type
	.addrsig_sym dict_type
	.addrsig_sym dict_scan
	.addrsig_sym dict_fields
	.addrsig_sym myl_rc_map_sentinel
	.addrsig_sym myl_native_list_header_descriptor
	.addrsig_sym myl_rc_pointer_leaf
	.addrsig_sym raw_descriptor
	.addrsig_sym raw_module
	.addrsig_sym raw_type
	.addrsig_sym raw_shape
