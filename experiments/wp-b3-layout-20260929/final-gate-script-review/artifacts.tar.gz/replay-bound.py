"""Replay revised identity checks using the preserved counter-data oracle."""
from pathlib import Path
import hashlib
import json
import math

out=Path(__file__).resolve().parent
peer=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
verify=(out/'final/verify-phase-b.py').read_text()
start=verify.index("for size in ('dev', 'smoke', 'full'):\n")
stop=verify.index('\nsupplement_lines =',start)
segment=verify[start:stop]
(out/'final-performance-loop.py').write_text(segment)
builder=json.loads((peer/'.tmp-rc-quick/bin/phase-b-registered-release-combined/compiler.json').read_text())
fresh_receipt=json.loads((peer/'.tmp/phase-b-fresh-a5-pinned-control/receipt.json').read_text())
results=[]
for case in ('positive','tag','size','compiler_hash','runtime','compiler_path'):
    def read(path):
        name=path.name
        if name.startswith('a5-control-'): return json.loads((out/f'fresh-{name.removeprefix("a5-control-")}').read_text())
        size=name.rsplit('-',1)[1]
        if name.startswith('results-m17-codex-'): return json.loads((out/f'approved-{size}').read_text())
        if name.startswith('results-m16-codex-'): return json.loads((out/f'original-{size}').read_text())
        candidate=json.loads((out/f'approved-{size}').read_text())
        candidate.update(tag='FINAL-REVIEW',size=size.removesuffix('.json'),compiler=dict(builder))
        if case=='tag': candidate['tag']='UNRELATED'
        if case=='size': candidate['size']='WRONG'
        if case=='compiler_hash': candidate['compiler']['sha256']='0'*64
        if case=='runtime': candidate['compiler']['runtime']='--gc-runtime'
        if case=='compiler_path': candidate['compiler']['compiler']='unrelated/path/mylang'
        return candidate
    namespace={'quick':Path('unused'),'tag':'FINAL-REVIEW','gate':Path('unused'),'read':read,
               'sha':lambda p:hashlib.sha256((out/f'fresh-{p.name.removeprefix("a5-control-")}').read_bytes()).hexdigest(),
               'fresh_receipt':fresh_receipt,'build_identity':builder,'math':math,'result':{'performance':{}}}
    try:
        exec(compile(segment,'final-performance-loop.py','exec'),namespace)
        assert case=='positive',case
        rows={size:namespace['result']['performance'][size]['matching_output_pairs'] for size in ('dev','smoke','full')}
        results.append({'case':case,'accepted':True,'rows':rows})
    except AssertionError:
        if case=='positive': raise
        results.append({'case':case,'accepted':False})
receipt={'final_verifier_sha256':hashlib.sha256(verify.encode()).hexdigest(),'results':results,
         'scope':'Performance-loop identity admission only, no physical sampling or final gate execution.'}
(out/'bound-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
