for size in ('dev', 'smoke', 'full'):
    candidate = read(quick / f'results-{tag}-{size}.json')
    assert candidate['tag'] == tag and candidate['size'] == size
    assert candidate['compiler'] == build_identity
    a5 = read(quick / f'results-m17-codex-{size}.json')
    a1 = read(quick / f'results-m16-codex-{size}.json')
    fresh = read(gate / f'a5-control-{size}.json')
    assert sha(gate / f'a5-control-{size}.json') == fresh_receipt['sizes'][size]['results_sha256']
    baseline = {(r['id'], r['arm']): r for r in a5['rows']}
    original = {(r['id'], r['arm']): r for r in a1['rows']}
    control = {(r['id'], r['arm']): r for r in fresh['rows']}
    candidate_keys = {(r['id'], r['arm']) for r in candidate['rows']}
    assert not candidate['failures'] and not fresh['failures']
    assert len(candidate['rows']) == len(baseline) == len(original) == len(control) == len(candidate_keys) == 86
    assert candidate_keys == set(baseline) == set(original) == set(control)
    rows = []
    for row in candidate['rows']:
        key = row['id'], row['arm']
        old, start, live = baseline[key], original[key], control[key]
        assert row['gc'] == old['gc'] == start['gc'] == live['gc'], (size, key, 'GC denominator')
        assert math.isclose(row['ratio'], row['rc'] / row['gc'], rel_tol=1e-12)
        movement = 100 * (row['rc'] / old['rc'] - 1)
        live_movement = 100 * (row['rc'] / live['rc'] - 1)
        # Approved A5 and quick.py define smoke as differential correctness.
        # Preserve every smoke movement; enforce the performance limits at dev/full.
        if size != 'smoke':
            assert movement <= 1 and live_movement <= 1, (size, key, movement, live_movement)
            assert row['ratio'] <= 1.3, (size, key, row['ratio'])
        elif old['ratio'] <= 1.3:
            assert row['ratio'] <= 1.3, (size, key, 'new smoke cap miss', row['ratio'])
        rows.append(dict(row, approved_a5_rc=old['rc'], original_a1_rc=start['rc'],
                         fresh_a5_rc=live['rc'], movement_percent=movement,
                         fresh_control_movement_percent=live_movement))
    result['performance'][size] = {'performance_acceptance_required': size != 'smoke',
                                   'summary': candidate['summary'], 'matching_output_pairs': 86,
                                   'maximum_regression_percent': max(r['movement_percent'] for r in rows),
                                   'moves_over_1_percent': [r for r in rows if abs(r['movement_percent']) > 1],
                                   'cap_misses': [r for r in rows if r['ratio'] > 1.3], 'rows': rows}
