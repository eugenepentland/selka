"""Pin source/scripts and retain unchanged approved-main timing controls."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path.cwd()
tag = sys.argv[1]
assert tag and '/' not in tag and tag not in ('.', '..')
gate = root / '.tmp-gate' / tag
assert not gate.exists(), 'a gate tag must have a fresh evidence directory'
assert subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).strip() == ''
gate.mkdir()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
control = root / '.tmp/phase-b-fresh-a5-pinned-control'
for size in ('dev', 'smoke', 'full'):
    shutil.copyfile(control / f'results-{size}.json', gate / f'a5-control-{size}.json')
for name in ('identity', 'receipt'):
    shutil.copyfile(control / f'{name}.json', gate / f'a5-control-{name}.json')
identity = {
    'source_commit': git('rev-parse', 'HEAD'),
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'gate_script_sha256': sha(root / '.tmp/phase-b-gate.sh'),
    'verification_script_sha256': sha(root / '.tmp/verify-phase-b.py'),
    'acceptance_policy': 'Approved A5: dev/full <=1% against approved and fresh controls, all caps; smoke differential outputs and no new cap misses.',
    'acceptance_basis_sha256': {name: sha(root / name) for name in (
        'experiments/rc-perf-20260927/quick.py',
        'docs/audits/codex-next-integration-closeout-2026-09-29.md')},
    'approved_baseline_results_sha256': {str(path.relative_to(root)): sha(path)
        for size in ('dev', 'smoke', 'full') for baseline in ('m16-codex', 'm17-codex')
        for path in [root / f'.tmp-rc-quick/results-{baseline}-{size}.json']},
    'full_measurement_script_sha256': sha(root / '.tmp/phase-b-full-measure.sh'),
    'supplement_script_sha256': sha(root / '.tmp/phase-b-supplement.sh'),
    'module_matrix_script_sha256': sha(root / '.tmp/phase-b-final-module-matrix.sh'),
    'module_oracle_source_sha256': {name: sha(root / name) for name in (
        'experiments/module-scale-20260929/corpus_byte.py',
        'experiments/module-scale-20260929/corpus_programs.json',
        'tests/module_compile_oracle.py')},
    'gc_cache_sha256': sha(root / '.tmp-rc-quick/gc-cache.json'),
    'measurement_environment': {'RC_QUICK_CPUS': '2,3,10,11'},
    'gate_adaptation': json.loads((root / '.tmp/phase-b-gate-adaptation.json').read_text()),
}
(gate / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity, indent=2))
