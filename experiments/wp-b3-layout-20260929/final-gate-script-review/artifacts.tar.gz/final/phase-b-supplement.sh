#!/usr/bin/env bash
set -euo pipefail
export TMPDIR="$PWD/.tmp" ZIG_GLOBAL_CACHE_DIR="$PWD/.zig-global-cache"
phase_b_tag=${1:?tag}
phase_b_source=$(git rev-parse HEAD)
phase_b_root=$PWD
phase_b_work=$PWD/.tmp-gate/$phase_b_tag/supplement
phase_b_compiler=$PWD/.tmp-rc-quick/compilers/$phase_b_tag/bin/mylang
mkdir -p "$phase_b_work/lox"
printf 'source %s\ncompiler %s\n' "$phase_b_source" "$(sha256sum "$phase_b_compiler" | cut -d' ' -f1)" > "$phase_b_work/summary.txt"
scripts/build-slot.sh gate zig build --cache-dir .zig-phase-b-cache -j4 --maxrss 8589934592 test-rc-fuzz -Dfuzz-seeds=100 --summary all -- --jobs 3 --out "$phase_b_work/fuzz" > "$phase_b_work/fuzz.log" 2>&1
printf 'fuzz100 0\n' >> "$phase_b_work/summary.txt"
cp -a .tmp-rc-quick/lox/benchmarks/lox/ports/mylang/. "$phase_b_work/lox/"
for phase_b_runtime in rc gc; do
  phase_b_options=()
  if [ "$phase_b_runtime" = gc ]; then phase_b_options+=(--gc-runtime); fi
  for phase_b_backend in qbe release; do
    phase_b_backend_options=()
    if [ "$phase_b_backend" = release ]; then phase_b_backend_options+=(--release); fi
    (cd "$phase_b_work/lox" && "$phase_b_root/scripts/build-slot.sh" build "$phase_b_compiler" build main.my --project "${phase_b_options[@]}" "${phase_b_backend_options[@]}" -o "$phase_b_work/lox-$phase_b_runtime-$phase_b_backend" --cache-dir "$phase_b_work/objects-$phase_b_runtime-$phase_b_backend") > "$phase_b_work/lox-build-$phase_b_runtime-$phase_b_backend.log" 2>&1
    printf 'lox-project-build-%s-%s 0\n' "$phase_b_runtime" "$phase_b_backend" >> "$phase_b_work/summary.txt"
  done
done
scripts/build-slot.sh build "$phase_b_compiler" doc-coverage . > "$phase_b_work/doc-coverage.log" 2>&1
printf 'doc-coverage 0\n' >> "$phase_b_work/summary.txt"
test "$(git rev-parse HEAD)" = "$phase_b_source"
