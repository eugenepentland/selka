#!/usr/bin/env bash
set -euo pipefail
export TMPDIR="$PWD/.tmp" ZIG_GLOBAL_CACHE_DIR="$PWD/.zig-global-cache"
phase_b_tag=${1:?tag}
phase_b_source=$(git rev-parse HEAD)
phase_b_compiler=$PWD/.tmp-rc-quick/compilers/$phase_b_tag/bin/mylang
phase_b_matrix=$PWD/.tmp-gate/$phase_b_tag/module-matrix
mkdir -p "$phase_b_matrix"
printf 'source %s\ncompiler %s\n' "$phase_b_source" "$(sha256sum "$phase_b_compiler" | cut -d' ' -f1)" > "$phase_b_matrix/summary.txt"
scripts/build-slot.sh build python3 experiments/module-scale-20260929/corpus_byte.py "$phase_b_compiler" "$phase_b_matrix/corpus-work" --lox-entry "$PWD/.tmp-rc-quick/lox/benchmarks/lox/ports/mylang/main.my" --json "$phase_b_matrix/corpus.json" --source "$phase_b_source" --jobs 2 > "$phase_b_matrix/corpus.log" 2>&1
printf 'corpus29 0\n' >> "$phase_b_matrix/summary.txt"
for phase_b_mode in rc gc stats sites; do
  scripts/build-slot.sh build python3 tests/module_compile_oracle.py "$phase_b_compiler" tests/fixtures/module_compile/main.my tests/fixtures/module_rc/main.my --jobs 1 --runtime "$phase_b_mode" --json "$phase_b_matrix/$phase_b_mode.json" --work "$phase_b_matrix/work-$phase_b_mode" > "$phase_b_matrix/$phase_b_mode.log" 2>&1
  printf 'runtime-%s 0\n' "$phase_b_mode" >> "$phase_b_matrix/summary.txt"
done
test "$(git rev-parse HEAD)" = "$phase_b_source"
