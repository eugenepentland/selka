#!/usr/bin/env bash
set -euo pipefail
export TMPDIR="$PWD/.tmp" ZIG_GLOBAL_CACHE_DIR="$PWD/.zig-global-cache" RC_QUICK_CPUS=2,3,10,11
phase_b_tag=${1:?tag}
phase_b_gate=$PWD/.tmp-gate/$phase_b_tag
# Run after canonical dev/smoke measurements, while later nonreserved gate jobs run.
python3 - "$phase_b_tag" <<'BEFORE_PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd(); tag=sys.argv[1]; gate=root/'.tmp-gate'/tag
read=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
i=read(gate/'source-identity.json'); m=read(gate/'candidate-binaries.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==i['source_commit']==m['source_commit']
assert subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip()==''
assert os.environ['RC_QUICK_CPUS']=='2,3,10,11'
assert 'measure-smoke 0' in (gate/'summary.txt').read_text().splitlines()
assert len(m['binaries'])==58
for name,digest in m['binaries'].items(): assert sha(root/'.tmp-rc-quick/bin'/tag/name)==digest,name
compiler=root/'.tmp-rc-quick/compilers'/tag/'bin/mylang'; assert sha(compiler)==m['compiler_sha256']
assert sha(root/'.tmp/phase-b-full-measure.sh')==i['full_measurement_script_sha256']
assert not (root/f'.tmp-rc-quick/results-{tag}-full.json').exists()
assert not (gate/'full-measurement.json').exists()
BEFORE_PY
python3 experiments/rc-perf-20260927/quick.py measure --tag "$phase_b_tag" --size full --jobs 4 > "$phase_b_gate/measure-full.log" 2>&1
python3 - "$phase_b_tag" <<'AFTER_PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd(); tag=sys.argv[1]; gate=root/'.tmp-gate'/tag
read=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
i=read(gate/'source-identity.json'); m=read(gate/'candidate-binaries.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==i['source_commit']==m['source_commit']
assert subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip()==''
for name,digest in m['binaries'].items(): assert sha(root/'.tmp-rc-quick/bin'/tag/name)==digest,name
compiler=root/'.tmp-rc-quick/compilers'/tag/'bin/mylang'; assert sha(compiler)==m['compiler_sha256']
result=root/f'.tmp-rc-quick/results-{tag}-full.json'; data=read(result)
assert data['tag']==tag and data['size']=='full' and not data['failures'] and len(data['rows'])==86
assert data['compiler']==read(root/'.tmp-rc-quick/bin'/tag/'compiler.json')
receipt={'source_commit':i['source_commit'],'tag':tag,'size':'full','status':0,
 'command':['python3','experiments/rc-perf-20260927/quick.py','measure','--tag',tag,'--size','full','--jobs','4'],
 'environment':{'RC_QUICK_CPUS':os.environ['RC_QUICK_CPUS']},'compiler_sha256':sha(compiler),
 'binary_manifest_sha256':sha(gate/'candidate-binaries.json'),'result_sha256':sha(result),
 'log_sha256':sha(gate/'measure-full.log'),'runner_sha256':sha(root/'.tmp/phase-b-full-measure.sh'),
 'binary_digests_unchanged':len(m['binaries'])}
(gate/'full-measurement.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt,indent=2))
AFTER_PY
