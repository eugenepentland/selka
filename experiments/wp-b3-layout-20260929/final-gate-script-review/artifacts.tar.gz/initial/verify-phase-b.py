"""Verify a frozen Phase B gate, supplementary coverage, and all corpus rows."""
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

root = Path.cwd()
tag = sys.argv[1]
gate = root / '.tmp-gate' / tag
quick = root / '.tmp-rc-quick'
supplement = gate / 'supplement'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


identity = read(gate / 'source-identity.json')
source = identity['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip() == identity['source_tree']
assert subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).strip() == ''
assert sha(root / '.tmp/phase-b-gate.sh') == identity['gate_script_sha256']
assert sha(root / '.tmp/verify-phase-b.py') == identity['verification_script_sha256']
for name, expected_hash in identity['acceptance_basis_sha256'].items():
    assert sha(root / name) == expected_hash, name
for name, expected_hash in identity['approved_baseline_results_sha256'].items():
    assert sha(root / name) == expected_hash, name
assert sha(root / '.tmp/phase-b-supplement.sh') == identity['supplement_script_sha256']
assert sha(root / '.tmp/phase-b-final-module-matrix.sh') == identity['module_matrix_script_sha256']
for name, expected_hash in identity['module_oracle_source_sha256'].items():
    assert sha(root / name) == expected_hash, name
assert identity['measurement_environment']['RC_QUICK_CPUS'] == '2,3,10,11'
compiler = quick / 'compilers' / tag / 'bin/mylang'
compiler_hash = sha(compiler)
assert sha(root / 'zig-out/bin/mylang') == compiler_hash
qbe_hash = sha(compiler.parent / 'qbe')
assert sha(root / 'zig-out/bin/qbe') == qbe_hash
build_identity = read(quick / 'bin' / tag / 'compiler.json')
assert build_identity['sha256'] == compiler_hash and build_identity['runtime'] == '--rc-runtime'

expected = {'build', 'corpus-build', 'measure-dev', 'measure-smoke', 'test',
            'test-qbe', 'test-qbe-build', 'fmt-check', 'test-native-memory', 'test-native-heap'}
expected.update('sweep' + mode + release for mode in
                ('--rc-runtime=stats', '--rc-runtime', '--gc-runtime', '=default')
                for release in ('', '-release'))
expected.add('sweep-gc-stress')
expected.update('lox-' + kind + runtime + release for kind in ('tests', 'driver')
                for runtime in ('', '--gc-runtime') for release in ('', '--release'))
lines = (gate / 'summary.txt').read_text().splitlines()
assert lines[0] == 'commit ' + source[:8] and lines[-1] == 'done', lines
records = [line.split() for line in lines[1:-1]]
assert len(records) == len(expected) == 27
assert {record[0] for record in records} == expected
assert all(record[1] == '0' for record in records), records
result = {'acceptance_policy': identity['acceptance_policy'],
          'acceptance_basis_sha256': identity['acceptance_basis_sha256'],
          'source_commit': source, 'source_tree': identity['source_tree'], 'tag': tag,
          'compiler_sha256': compiler_hash, 'qbe_sha256': qbe_hash,
          'gate_statuses': {r[0]: 0 for r in records},
          'guest_modes': {}, 'zig': {}, 'performance': {}}
names = None
for mode in sorted(step for step in expected if step.startswith('sweep')):
    data = read(gate / (mode + '.json'))
    assert all(data[field] == 0 for field in ('failed', 'skipped', 'cached', 'dropped', 'unloaded')), mode
    current_names = [test['name'] for test in data['tests']]
    assert data['passed'] == data['executed'] == len(current_names) == len(set(current_names))
    assert len(current_names) >= 1464 and all(t['status'] == 'passed' for t in data['tests'])
    if names is None:
        names = set(current_names)
    assert set(current_names) == names, mode
    result['guest_modes'][mode] = {k: v for k, v in data.items() if k != 'tests'}
    result['guest_modes'][mode]['names_sha256'] = hashlib.sha256('\n'.join(sorted(names)).encode()).hexdigest()
for step in ('test', 'test-qbe', 'test-qbe-build', 'fmt-check', 'test-native-memory', 'test-native-heap'):
    log = (gate / (step + '.log')).read_text()
    summaries = re.findall(r'Build Summary: .+', log)
    assert summaries and not re.search(r'\b(failed|failure)\b', summaries[-1]), step
    result['zig'][step] = summaries[-1]
for step in sorted(step for step in expected if step.startswith('lox-')):
    log = (gate / (step + '.log')).read_text()
    count = 65 if step.startswith('lox-tests') else 13
    assert re.search(rf'\b{count} passed, 0 cached, 0 failed, 0 skipped', log), step
    assert not re.search(r'\b[1-9][0-9]* (dropped|unloaded|test sources not loaded)', log), step
    if step.startswith('lox-tests'):
        assert '0 dropped across 10 programs' in log, step

accepted_gc = read(root / '.tmp/a5/accepted-gc-verification.json')
assert sha(quick / 'gc-builds.json') == accepted_gc['manifest_sha256']
assert len(accepted_gc['binary_sha256']) == accepted_gc['unique_binaries'] == 58
for name, expected_hash in accepted_gc['binary_sha256'].items():
    assert sha(quick / 'bin/gc' / name) == expected_hash, name
assert sha(quick / 'gc-cache.json') == identity['gc_cache_sha256'], 'GC measurement cache changed'
result['accepted_gc'] = accepted_gc
fresh_identity = read(gate / 'a5-control-identity.json')
fresh_receipt = read(gate / 'a5-control-receipt.json')
assert sha(gate / 'a5-control-identity.json') == fresh_receipt['identity_sha256']
assert fresh_identity['measurement_cpus'] == '2,3,10,11'
assert fresh_receipt['environment'] == {'RC_QUICK_CPUS': '2,3,10,11', 'inherited_by_quick_py': True}
assert fresh_identity['runner_sha256'] == fresh_receipt['runner_sha256'] == sha(root / '.tmp/run-phase-b-pinned-control.sh')
assert len(fresh_identity['binaries']) == 58
assert sha(quick / 'compilers/m17-codex/bin/mylang') == fresh_identity['compiler_sha256']
for name, expected_hash in fresh_identity['binaries'].items():
    assert sha(quick / 'bin/m17-codex' / name) == expected_hash, name
result['fresh_a5_control'] = fresh_receipt
for size in ('dev', 'smoke', 'full'):
    candidate = read(quick / f'results-{tag}-{size}.json')
    a5 = read(quick / f'results-m17-codex-{size}.json')
    a1 = read(quick / f'results-m16-codex-{size}.json')
    fresh = read(gate / f'a5-control-{size}.json')
    assert sha(gate / f'a5-control-{size}.json') == fresh_receipt['sizes'][size]['results_sha256']
    baseline = {(r['id'], r['arm']): r for r in a5['rows']}
    original = {(r['id'], r['arm']): r for r in a1['rows']}
    control = {(r['id'], r['arm']): r for r in fresh['rows']}
    candidate_keys = {(r['id'], r['arm']) for r in candidate['rows']}
    assert not candidate['failures'] and not fresh['failures']
    assert len(candidate['rows']) == len(baseline) == len(original) == len(control) == len(candidate_keys) == 86
    assert candidate_keys == set(baseline) == set(original) == set(control)
    rows = []
    for row in candidate['rows']:
        key = row['id'], row['arm']
        old, start, live = baseline[key], original[key], control[key]
        assert row['gc'] == old['gc'] == start['gc'] == live['gc'], (size, key, 'GC denominator')
        assert math.isclose(row['ratio'], row['rc'] / row['gc'], rel_tol=1e-12)
        movement = 100 * (row['rc'] / old['rc'] - 1)
        live_movement = 100 * (row['rc'] / live['rc'] - 1)
        # Approved A5 and quick.py define smoke as differential correctness.
        # Preserve every smoke movement; enforce the performance limits at dev/full.
        if size != 'smoke':
            assert movement <= 1 and live_movement <= 1, (size, key, movement, live_movement)
            assert row['ratio'] <= 1.3, (size, key, row['ratio'])
        elif old['ratio'] <= 1.3:
            assert row['ratio'] <= 1.3, (size, key, 'new smoke cap miss', row['ratio'])
        rows.append(dict(row, approved_a5_rc=old['rc'], original_a1_rc=start['rc'],
                         fresh_a5_rc=live['rc'], movement_percent=movement,
                         fresh_control_movement_percent=live_movement))
    result['performance'][size] = {'performance_acceptance_required': size != 'smoke',
                                   'summary': candidate['summary'], 'matching_output_pairs': 86,
                                   'maximum_regression_percent': max(r['movement_percent'] for r in rows),
                                   'moves_over_1_percent': [r for r in rows if abs(r['movement_percent']) > 1],
                                   'cap_misses': [r for r in rows if r['ratio'] > 1.3], 'rows': rows}

supplement_lines = (supplement / 'summary.txt').read_text().splitlines()
assert supplement_lines == ['source ' + source, 'compiler ' + compiler_hash, 'fuzz100 0',
                            'lox-project-build-rc-qbe 0', 'lox-project-build-rc-release 0',
                            'lox-project-build-gc-qbe 0', 'lox-project-build-gc-release 0', 'doc-coverage 0']
fuzz = read(supplement / 'fuzz/summary.json')
assert fuzz['start'] == 1 and fuzz['count'] == 100
assert fuzz['tally'] == {'ok': 98, 'invalid': 0, 'stress-only': 2, 'RC-DIFF': 0}
assert sorted(f['seed'] for f in fuzz['findings']) == [19, 87]
assert all(f['status'] == 'stress-only' and f['rc'] == [] for f in fuzz['findings'])
for finding in fuzz['findings']:
    finding['program_sha256'] = sha(Path(finding['program']))
result['fuzz'] = fuzz
coverage = (supplement / 'doc-coverage.log').read_text()
assert 'doc-coverage: 0 failures' in coverage
result['doc_coverage'] = coverage
doctest = re.search(r'Doc examples: (.+)', (gate / 'test.log').read_text())
assert doctest and '0 mis-tagged, 0 failed' in doctest[1]
result['doc_examples'] = doctest[1]
matrix = gate / 'module-matrix'
assert (matrix / 'summary.txt').read_text().splitlines() == [
    'source ' + source, 'compiler ' + compiler_hash, 'corpus29 0',
    'runtime-rc 0', 'runtime-gc 0', 'runtime-stats 0', 'runtime-sites 0']
corpus = read(matrix / 'corpus.json')
assert corpus['source'] == source and corpus['compiler_sha256'] == compiler_hash
totals = corpus['totals']
assert totals['distinct_programs'] == totals['equal'] == totals['executables_identical'] == 29
assert totals['corpus_rows'] == 43 and totals['modules'] == totals['interfaces_compared'] == 62
assert totals['units_compared'] >= 664 and totals['reference_failed'] == 0 and totals['different'] == []
assert len(corpus['results']) == 29
for row in corpus['results']:
    assert row['status'] == 'equal' and row['executables_identical']
    assert row['link_compiled_function_objects'] == 0 and row['problems'] == [], row['build_key']
result['module_matrix'] = {'corpus': totals, 'runtimes': {}}
for mode in ('rc', 'gc', 'stats', 'sites'):
    data = read(matrix / (mode + '.json'))
    total = data['totals']
    assert total['programs'] == total['equal'] == total['executables_identical'] == 2
    assert total['reference_failed'] == 0 and total['different'] == []
    assert total['modules'] == total['interfaces_compared'] == 9 and total['units_compared'] >= 80
    assert len(data['results']) == 2
    for row in data['results']:
        assert row['status'] == 'equal' and row['executables_identical']
        assert row['link_compiled_function_objects'] == 0 and row['problems'] == []
    result['module_matrix']['runtimes'][mode] = total
paths = list(gate.glob('*.log')) + list(gate.glob('*.json')) + [gate / 'summary.txt']
paths += list(supplement.glob('*.log')) + [supplement / 'summary.txt', supplement / 'fuzz/summary.json']
paths += [quick / f'results-{tag}-{size}.json' for size in ('dev', 'smoke', 'full')]
paths += [root / '.tmp/phase-b-gate.sh', root / '.tmp/phase-b-supplement.sh', root / '.tmp/verify-phase-b.py']
paths += list(matrix.glob('*.log')) + list(matrix.glob('*.json')) + [matrix / 'summary.txt']
paths += [root / '.tmp/phase-b-final-module-matrix.sh', root / '.tmp/run-phase-b-pinned-control.sh']
result['raw_evidence_sha256'] = {str(p.relative_to(root)): sha(p) for p in sorted(paths)}
print(json.dumps(result, indent=2))
