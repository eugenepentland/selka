"""Demonstrate the original performance loop accepting unrelated metadata."""
from pathlib import Path
import copy
import hashlib
import json
import math

peer=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
out=Path(__file__).resolve().parent
verify=(out/'initial/verify-phase-b.py').read_text()
start=verify.index("for size in ('dev', 'smoke', 'full'):\n")
stop=verify.index('\nsupplement_lines =',start)
segment=verify[start:stop]
(out/'initial-performance-loop.py').write_text(segment)
manifest={}
for size in ('dev','smoke','full'):
    for label,path in [('approved',peer/f'.tmp-rc-quick/results-m17-codex-{size}.json'),
                       ('original',peer/f'.tmp-rc-quick/results-m16-codex-{size}.json'),
                       ('fresh',peer/f'.tmp/phase-b-fresh-a5-pinned-control/results-{size}.json')]:
        data=path.read_bytes()
        dest=out/f'{label}-{size}.json';dest.write_bytes(data)
        manifest[dest.name]=hashlib.sha256(data).hexdigest()


def read(path):
    name=path.name
    if name.startswith('a5-control-'): return json.loads((out/f'fresh-{name.removeprefix("a5-control-")}').read_text())
    size=name.rsplit('-',1)[1]
    if name.startswith('results-m17-codex-'): return json.loads((out/f'approved-{size}').read_text())
    if name.startswith('results-m16-codex-'): return json.loads((out/f'original-{size}').read_text())
    candidate=json.loads((out/f'approved-{size}').read_text())
    candidate.update(tag='UNRELATED',size='WRONG',compiler={'sha256':'0'*64,'runtime':'--gc-runtime'})
    return candidate

fresh_receipt=json.loads((peer/'.tmp/phase-b-fresh-a5-pinned-control/receipt.json').read_text())
namespace={'quick':Path('unused'), 'tag':'FINAL-REVIEW', 'gate':Path('unused'), 'read':read,
           'sha':lambda p:hashlib.sha256((out/f'fresh-{p.name.removeprefix("a5-control-")}').read_bytes()).hexdigest(),
           'fresh_receipt':fresh_receipt,'math':math,'result':{'performance':{}}}
exec(compile(segment,'initial-performance-loop.py','exec'),namespace)
result={'original_verifier_sha256':hashlib.sha256(verify.encode()).hexdigest(),
        'accepted_unrelated_candidate':True,
        'unrelated_metadata':{'tag':'UNRELATED','size':'WRONG','compiler_sha256':'0'*64,'runtime':'--gc-runtime'},
        'sizes':{size:namespace['result']['performance'][size]['matching_output_pairs'] for size in ('dev','smoke','full')},
        'input_sha256':manifest}
(out/'unbound-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
