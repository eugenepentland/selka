rc_elements_release:
.LFB109:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdx, %r8
	movq	5640(%rdi), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L1420
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L1420
	movq	8(%rax), %rsi
.L1421:
	testq	%rsi, %rsi
	je	.L1428
	movl	64(%rsi), %eax
	testl	%eax, %eax
	jne	.L1423
	cmpb	$0, 69(%rsi)
	je	.L1430
.L1425:
	movq	8(%rsi), %rax
	cmpq	$2, 40(%rax)
	ja	.L1431
	movq	%r8, %rdx
	movq	%rax, %rsi
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	jmp	myl_rc_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1423:
	.cfi_restore_state
	cmpl	$16, %eax
	jbe	.L1425
	movq	8(%rsi), %rax
	movq	%r8, %rdx
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	movq	%rax, %rsi
	jmp	myl_rc_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1431:
	.cfi_restore_state
	movq	%r8, %rdx
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	jmp	myl_rc_flat_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1430:
	.cfi_restore_state
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_elements_release.cold, @function
rc_elements_release.cold:
.LFSB109:
.L1420:
	.cfi_def_cfa_offset 48
	movq	%rcx, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rdi, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %rdi
	movq	16(%rsp), %r8
	movq	24(%rsp), %rcx
	movq	%rax, %rsi
	jmp	.L1421
.L1428:
	call	abort@PLT
	.cfi_endproc
.LFE109:
	.text
