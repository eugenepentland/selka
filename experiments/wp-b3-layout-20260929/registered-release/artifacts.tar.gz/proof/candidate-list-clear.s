myl_rc_list_clear:
.LFB131:
	.cfi_startproc
	endbr64
	movq	(%rsi), %rcx
	testq	%rcx, %rcx
	je	.L3569
	movq	16(%rsi), %rdx
	xorl	%eax, %eax
	cmpq	$-1, %rdx
	je	.L3570
	addq	$1, %rdx
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	$0, (%rsi)
	movq	%rsi, %rax
	movq	%rdx, 16(%rsi)
	movq	32(%rsi), %rdx
	movq	24(%rsi), %rsi
	movq	%rax, 24(%rsp)
	movq	%rcx, 16(%rsp)
	movq	%rdi, 8(%rsp)
	call	rc_elements_release
	movq	24(%rsp), %rax
	movq	16(%rsp), %rcx
	xorl	%esi, %esi
	movq	24(%rax), %rdx
	movq	32(%rax), %rdi
	imulq	(%rdx), %rcx
	movq	%rcx, %rdx
	call	memset@PLT
	movq	8(%rsp), %rdi
	call	myl_rc_drain@PLT
	movl	$1, %eax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3570:
	ret
	.p2align 4,,10
	.p2align 3
.L3569:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE131:
