	.file	"native_collections.c"
	.text
	.p2align 4
	.type	sort_f64, @function
sort_f64:
.LFB83:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$2408, %rsp
	.cfi_def_cfa_offset 2464
	movq	%fs:40, %rbp
	movq	%rbp, 2392(%rsp)
	movq	%rsi, %rbp
	cmpq	$31, %rsi
	jbe	.L83
	movq	%rbp, %rax
	xorl	%edx, %edx
.L3:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L3
	leaq	(%rdx,%rax), %r14
	cmpq	%rbp, %r14
	jb	.L193
	movl	$32, %r14d
	xorl	%r8d, %r8d
.L2:
	xorl	%r9d, %r9d
	xorl	%ebx, %ebx
	movq	%rbp, %r13
.L76:
	cmpq	%r13, %rbx
	jnb	.L5
	leaq	1(%rbx), %rcx
	cmpq	%rcx, %r13
	je	.L6
.L77:
	movq	8(%r15,%rbx,8), %rdx
	movsd	(%r15,%rbx,8), %xmm1
	movq	%rdx, %xmm0
	comisd	%xmm0, %xmm1
	jbe	.L174
.L11:
	leaq	2(%rbx), %rax
	cmpq	%r13, %rax
	jnb	.L10
.L9:
	movq	%rdx, %xmm0
	movq	(%r15,%rax,8), %rdx
	movq	%rdx, %xmm1
	comisd	%xmm1, %xmm0
	ja	.L14
	ucomisd	%xmm0, %xmm0
	jnp	.L96
	ucomisd	%xmm1, %xmm1
	jnp	.L14
.L96:
	leaq	-1(%rax), %rcx
.L10:
	cmpq	%rcx, %rbx
	jnb	.L18
	movq	%rcx, %rdx
	movq	%rbx, %rax
.L17:
	movq	(%r15,%rax,8), %rsi
	movq	(%r15,%rdx,8), %rdi
	movq	%rdi, (%r15,%rax,8)
	addq	$1, %rax
	movq	%rsi, (%r15,%rdx,8)
	subq	$1, %rdx
	cmpq	%rdx, %rax
	jb	.L17
.L18:
	subq	%rbx, %rcx
	leaq	1(%rcx), %rsi
	cmpq	%r14, %rsi
	jb	.L194
.L19:
	testq	%r9, %r9
	jne	.L79
	movq	%rbx, 80(%rsp)
	addq	%rsi, %rbx
	movq	$0, 96(%rsp)
	movq	%rsi, 88(%rsp)
	cmpq	%r13, %rbx
	jb	.L195
.L75:
	movq	%r8, %rdi
	call	free@PLT
	movl	$1, %eax
.L1:
	movq	2392(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L196
	addq	$2408, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L5:
	.cfi_restore_state
	cmpq	$1, %r9
	jbe	.L75
	movl	$0, 4(%rsp)
	xorl	%esi, %esi
.L80:
	movq	%rsi, 56(%rsp)
	leaq	(%r9,%r9,2), %rax
	movq	%rbx, 64(%rsp)
	leaq	80(%rsp,%rax,8), %rcx
	movq	%r13, 72(%rsp)
	movq	%r14, 48(%rsp)
	movq	%r8, %r14
	.p2align 4
	.p2align 3
.L72:
	movl	4(%rsp), %eax
	cmpl	-32(%rcx), %eax
	jl	.L74
	cmpq	$96, %r9
	jne	.L190
.L74:
	movq	-24(%rcx), %r11
	movq	-48(%rcx), %r10
	subq	$1, %r9
	movq	-16(%rcx), %r8
	movq	%r11, %rdi
	subq	%r10, %rdi
	je	.L37
	leaq	0(,%r11,8), %rax
	leaq	(%r15,%rax), %rbx
	movq	(%rbx), %xmm2
	ucomisd	%xmm2, %xmm2
	movapd	%xmm2, %xmm1
	setnp	%r12b
	xorl	%esi, %esi
	jmp	.L40
	.p2align 4,,10
	.p2align 3
.L198:
	ucomisd	%xmm0, %xmm0
	jnp	.L97
	testb	%r12b, %r12b
	jne	.L90
.L97:
	leaq	1(%rdx), %rsi
	cmpq	%rdi, %rsi
	jnb	.L197
.L40:
	movq	%rdi, %rdx
	subq	%rsi, %rdx
	shrq	%rdx
	addq	%rsi, %rdx
	leaq	(%r10,%rdx), %rbp
	movsd	(%r15,%rbp,8), %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L198
.L90:
	movq	%rdx, %rdi
	cmpq	%rdi, %rsi
	jb	.L40
.L197:
	addq	%rsi, %r10
	cmpq	%r10, %r11
	je	.L37
	testq	%r8, %r8
	je	.L37
	movsd	-8(%r15,%r11,8), %xmm1
	leaq	0(,%r10,8), %r12
	movq	%r8, %rdi
	ucomisd	%xmm1, %xmm1
	setp	%bpl
	xorl	%esi, %esi
	jmp	.L44
	.p2align 4,,10
	.p2align 3
.L200:
	ucomisd	%xmm0, %xmm0
	jp	.L91
	testb	%bpl, %bpl
	jne	.L42
.L91:
	movq	%rdx, %rdi
	cmpq	%rdi, %rsi
	jnb	.L199
.L44:
	movq	%rdi, %rdx
	subq	%rsi, %rdx
	shrq	%rdx
	addq	%rsi, %rdx
	leaq	(%r15,%rdx,8), %r13
	movsd	0(%r13,%rax), %xmm0
	comisd	%xmm0, %xmm1
	jbe	.L200
.L42:
	leaq	1(%rdx), %rsi
	cmpq	%rdi, %rsi
	jb	.L44
.L199:
	movq	%r11, %rdx
	addq	%rsi, %r11
	movq	%rcx, 32(%rsp)
	subq	%r10, %rdx
	leaq	0(,%rsi,8), %r10
	movq	%r9, 24(%rsp)
	leaq	(%r15,%r11,8), %r13
	shrq	$3, %r10
	cmpq	%rdx, %rsi
	jb	.L45
	leaq	0(,%rdx,8), %rbp
	addq	%r15, %r12
	movq	%r14, %rdi
	movq	%r10, 16(%rsp)
	movq	%rbp, %rdx
	movq	%r12, %rsi
	movq	%r8, 8(%rsp)
	movq	%xmm2, 40(%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %r10
	movq	%rbp, %rdx
	movq	%r14, %rsi
	shrq	$3, %rdx
	movq	8(%rsp), %r8
	movq	24(%rsp), %r9
	leaq	(%r14,%rbp), %rdi
	cmpq	%r10, %rdx
	movq	%r10, %rax
	movq	32(%rsp), %rcx
	cmovbe	%rdx, %rax
	cmpq	$1, %rax
	jbe	.L46
	movq	40(%rsp), %xmm2
	.p2align 4
	.p2align 3
.L52:
	leaq	-8(,%rax,8), %r10
	movq	(%rsi), %xmm3
	movq	%r12, %rax
	leaq	(%r12,%r10), %rdx
	jmp	.L51
	.p2align 4,,10
	.p2align 3
.L202:
	ucomisd	%xmm3, %xmm3
	jnp	.L48
	ucomisd	%xmm2, %xmm2
	jnp	.L47
.L48:
	movq	%xmm3, -8(%rax)
	addq	$8, %rsi
	movq	(%rsi), %xmm3
	cmpq	%rax, %rdx
	je	.L201
.L51:
	addq	$8, %rax
	comisd	%xmm2, %xmm3
	jbe	.L202
.L47:
	movq	%xmm2, -8(%rax)
	addq	$8, %rbx
	movq	(%rbx), %xmm2
	cmpq	%rax, %rdx
	jne	.L51
.L201:
	movq	%rdi, %rax
	movq	%r13, %rdx
	addq	%r10, %r12
	subq	%rsi, %rax
	subq	%rbx, %rdx
	shrq	$3, %rax
	shrq	$3, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	cmpq	$1, %rax
	jbe	.L46
	movq	(%rbx), %xmm2
	jmp	.L52
.L53:
	cmpq	%rdi, %rsi
	jnb	.L37
	subq	%rsi, %rdi
	movq	%rcx, 24(%rsp)
	movq	%rdi, %rdx
	movq	%r12, %rdi
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %r8
	movq	16(%rsp), %r9
	movq	24(%rsp), %rcx
	.p2align 4
	.p2align 3
.L37:
	addq	%r8, -40(%rcx)
	subq	$24, %rcx
	cmpq	$1, %r9
	jne	.L72
.L190:
	movq	%r14, %r8
	movq	56(%rsp), %rsi
	movq	48(%rsp), %r14
	movq	64(%rsp), %rbx
	movq	72(%rsp), %r13
.L73:
	cmpq	%r13, %rbx
	jnb	.L75
	movl	4(%rsp), %ecx
	leaq	-3(%r9,%r9,2), %rax
	movl	%ecx, 96(%rsp,%rax,8)
	leaq	(%r9,%r9,2), %rax
	addq	$1, %r9
	movq	%rbx, 80(%rsp,%rax,8)
	addq	%rsi, %rbx
	movq	$0, 96(%rsp,%rax,8)
	movq	%rsi, 88(%rsp,%rax,8)
	jmp	.L76
.L46:
	cmpq	%rdi, %rsi
	jnb	.L37
	cmpq	%r13, %rbx
	jb	.L57
	jmp	.L53
	.p2align 4,,10
	.p2align 3
.L204:
	ucomisd	%xmm0, %xmm0
	jp	.L203
.L55:
	addq	$8, %rsi
	movq	%rdx, %rax
.L56:
	movq	%rax, -8(%r12)
	cmpq	%r13, %rbx
	jnb	.L53
	cmpq	%rdi, %rsi
	jnb	.L37
.L57:
	movq	(%rbx), %rax
	movq	(%rsi), %rdx
	addq	$8, %r12
	movq	%rax, %xmm1
	movq	%rdx, %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L204
	addq	$8, %rbx
	jmp	.L56
.L45:
	subq	%r12, %rax
	leaq	(%r14,%rsi,8), %rbp
	movq	%r14, %rdi
	movq	%r8, 16(%rsp)
	shrq	$3, %rax
	leaq	0(,%rsi,8), %rdx
	movq	%rbx, %rsi
	cmpq	%r10, %rax
	cmovbe	%rax, %r10
	addq	%r15, %r12
	movq	%r10, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %r10
	movq	16(%rsp), %r8
	movq	24(%rsp), %r9
	movq	32(%rsp), %rcx
	cmpq	$1, %r10
	jbe	.L189
	.p2align 4
	.p2align 3
.L65:
	negq	%r10
	movq	-8(%rbx), %xmm2
	movq	-8(%rbp), %xmm3
	movq	%r13, %rax
	salq	$3, %r10
	leaq	8(%r13,%r10), %rdx
	jmp	.L64
	.p2align 4,,10
	.p2align 3
.L206:
	ucomisd	%xmm2, %xmm2
	jnp	.L61
	ucomisd	%xmm3, %xmm3
	jnp	.L60
.L61:
	movq	%xmm3, (%rax)
	subq	$8, %rbp
	movq	-8(%rbp), %xmm3
	cmpq	%rax, %rdx
	je	.L205
.L64:
	subq	$8, %rax
	comisd	%xmm3, %xmm2
	jbe	.L206
.L60:
	movq	%xmm2, (%rax)
	subq	$8, %rbx
	movq	-8(%rbx), %xmm2
	cmpq	%rax, %rdx
	jne	.L64
.L205:
	leaq	8(%r13,%r10), %r13
	movq	%rbp, %rax
	movq	%rbx, %r10
	subq	%r12, %r10
	subq	%r14, %rax
	shrq	$3, %r10
	shrq	$3, %rax
	cmpq	%rax, %r10
	cmova	%rax, %r10
	cmpq	$1, %r10
	ja	.L65
	jmp	.L189
	.p2align 4,,10
	.p2align 3
.L207:
	ucomisd	%xmm0, %xmm0
	jnp	.L98
	ucomisd	%xmm1, %xmm1
	jnp	.L67
.L98:
	subq	$8, %rbp
	movq	%rdx, %rax
.L69:
	movq	%rax, 0(%r13)
.L189:
	cmpq	%rbp, %r14
	jnb	.L37
	cmpq	%rbx, %r12
	jnb	.L66
	movq	-8(%rbp), %rdx
	movq	-8(%rbx), %rax
	subq	$8, %r13
	movq	%rdx, %xmm1
	movq	%rax, %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L207
.L67:
	subq	$8, %rbx
	jmp	.L69
.L203:
	ucomisd	%xmm1, %xmm1
	jp	.L55
	addq	$8, %rbx
	jmp	.L56
.L66:
	cmpq	%rbp, %r14
	jnb	.L37
	movq	%rbp, %rdx
	movq	%r13, %rdi
	movq	%r14, %rsi
	movq	%rcx, 24(%rsp)
	subq	%r14, %rdx
	movq	%r9, 16(%rsp)
	subq	%rdx, %rdi
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	movq	24(%rsp), %rcx
	movq	16(%rsp), %r9
	movq	8(%rsp), %r8
	addq	%r8, -40(%rcx)
	subq	$24, %rcx
	cmpq	$1, %r9
	jne	.L72
	jmp	.L190
.L14:
	leaq	1(%rax), %rcx
	cmpq	%r13, %rcx
	jnb	.L86
	movq	%rcx, %rax
	jmp	.L9
.L174:
	ucomisd	%xmm1, %xmm1
	jnp	.L13
	ucomisd	%xmm0, %xmm0
	jnp	.L11
.L13:
	leaq	1(%rcx), %rax
	cmpq	%r13, %rax
	jnb	.L18
.L208:
	movsd	(%r15,%rax,8), %xmm0
	movsd	-8(%r15,%rax,8), %xmm1
	comisd	%xmm0, %xmm1
	ja	.L18
	ucomisd	%xmm1, %xmm1
	jnp	.L87
	ucomisd	%xmm0, %xmm0
	jnp	.L18
.L87:
	movq	%rax, %rcx
	leaq	1(%rcx), %rax
	cmpq	%r13, %rax
	jb	.L208
	jmp	.L18
	.p2align 4,,10
	.p2align 3
.L195:
	leaq	1(%rbx), %rcx
	movl	$1, %r9d
	cmpq	%rcx, %r13
	jne	.L77
	movl	$1, %esi
	cmpq	$1, %r14
	jbe	.L78
.L79:
	leaq	-3(%r9,%r9,2), %rdx
	xorl	%ecx, %ecx
	movq	88(%rsp,%rdx,8), %rax
	movq	80(%rsp,%rdx,8), %rdx
	leaq	(%rax,%rdx,2), %rdx
	addq	%rdx, %rax
	addq	%rsi, %rax
	jmp	.L35
.L209:
	subq	%r13, %rdx
	subq	%r13, %rax
.L33:
	addq	%rdx, %rdx
	addq	%rax, %rax
.L35:
	addl	$1, %ecx
	cmpq	%r13, %rdx
	jnb	.L209
	cmpq	%r13, %rax
	jb	.L33
	movl	%ecx, 4(%rsp)
	cmpq	$1, %r9
	jne	.L80
	jmp	.L73
	.p2align 4,,10
	.p2align 3
.L6:
	movl	$1, %esi
	cmpq	$1, %r14
	ja	.L19
.L78:
	leaq	(%r14,%rbx), %rbp
	movq	%r14, %rsi
.L20:
	cmpq	%rbp, %rcx
	jnb	.L19
	leaq	0(,%rcx,8), %rax
	subq	$1, %rbp
	subq	$1, %rcx
	leaq	(%r15,%rax), %r12
	leaq	-8(%r15,%rax), %r11
	jmp	.L30
.L210:
	ucomisd	%xmm3, %xmm3
	jp	.L29
.L24:
	movq	%xmm2, (%rdi)
.L28:
	addq	$8, %r12
	addq	$8, %r11
	cmpq	%rcx, %rbp
	je	.L19
.L30:
	movq	(%r11), %rax
	movq	(%r12), %xmm2
	movq	%rcx, %rdx
	addq	$1, %rcx
	movq	%r11, %rdi
	movq	%rax, %xmm0
	movapd	%xmm2, %xmm1
	comisd	%xmm2, %xmm0
	jbe	.L175
.L26:
	movq	%rax, (%r12)
	cmpq	%rdx, %rbx
	jnb	.L24
	leaq	-16(%r12), %r10
	leaq	-8(%r11), %rax
	subq	%r11, %r10
.L25:
	movq	(%rax), %xmm3
	comisd	%xmm1, %xmm3
	jbe	.L210
.L29:
	subq	$1, %rdx
	movq	%xmm3, 8(%rax)
	addq	%r10, %rdi
	subq	$8, %rax
	cmpq	%rdx, %rbx
	jb	.L25
	jmp	.L24
.L175:
	ucomisd	%xmm0, %xmm0
	jnp	.L28
	ucomisd	%xmm2, %xmm2
	jp	.L28
	jmp	.L26
.L193:
	movq	%rbp, %rdi
	shrq	%rdi
	salq	$3, %rdi
	call	malloc@PLT
	movq	%rax, %r8
	testq	%rax, %rax
	jne	.L2
	xorl	%eax, %eax
	jmp	.L1
	.p2align 4,,10
	.p2align 3
.L194:
	movq	%r13, %rax
	leaq	(%rsi,%rbx), %rcx
	subq	%rbx, %rax
	cmpq	%r14, %rax
	jnb	.L78
	movq	%rax, %rsi
	movq	%r13, %rbp
	jmp	.L20
.L83:
	movq	%rbp, %r14
	xorl	%r8d, %r8d
	jmp	.L2
.L86:
	movq	%rax, %rcx
	jmp	.L10
.L196:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE83:
	.size	sort_f64, .-sort_f64
	.p2align 4
	.type	sort_i64, @function
sort_i64:
.LFB81:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$2424, %rsp
	.cfi_def_cfa_offset 2480
	movq	%fs:40, %r14
	movq	%r14, 2408(%rsp)
	movq	%rsi, %r14
	cmpq	$31, %rsi
	jbe	.L277
	movq	%r14, %rax
	xorl	%edx, %edx
.L213:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L213
	leaq	(%rdx,%rax), %r12
	cmpq	%r14, %r12
	jb	.L335
	movl	$32, %r12d
	xorl	%r11d, %r11d
.L212:
	movq	%r12, %rcx
	xorl	%r8d, %r8d
	xorl	%ebx, %ebx
	movq	%r11, %r13
	movq	%r14, %r12
.L270:
	cmpq	%r12, %rbx
	jnb	.L215
	leaq	1(%rbx), %rax
	cmpq	%rax, %r12
	je	.L216
.L271:
	movq	8(%r15,%rbx,8), %rdi
	cmpq	(%r15,%rbx,8), %rdi
	jge	.L217
	jmp	.L221
.L218:
	movq	(%r15,%rax,8), %rsi
	cmpq	%rdi, %rsi
	jge	.L222
	movq	%rsi, %rdi
.L221:
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%r12, %rax
	jb	.L218
.L222:
	movq	%rdx, %rsi
	movq	%rbx, %rax
	cmpq	%rdx, %rbx
	jnb	.L223
.L219:
	movq	(%r15,%rax,8), %rdi
	movq	(%r15,%rsi,8), %r9
	movq	%r9, (%r15,%rax,8)
	addq	$1, %rax
	movq	%rdi, (%r15,%rsi,8)
	subq	$1, %rsi
	cmpq	%rsi, %rax
	jb	.L219
.L223:
	subq	%rbx, %rdx
	leaq	1(%rdx), %rbp
	cmpq	%rcx, %rbp
	jb	.L336
.L224:
	testq	%r8, %r8
	jne	.L273
	movq	%rbx, 96(%rsp)
	addq	%rbp, %rbx
	movq	$0, 112(%rsp)
	movq	%rbp, 104(%rsp)
	cmpq	%r12, %rbx
	jnb	.L329
	leaq	1(%rbx), %rax
	movl	$1, %r8d
	cmpq	%rax, %r12
	jne	.L271
	movl	$1, %ebp
	cmpq	$1, %rcx
	jbe	.L272
.L273:
	leaq	-3(%r8,%r8,2), %rdx
	xorl	%esi, %esi
	movq	104(%rsp,%rdx,8), %rax
	movq	96(%rsp,%rdx,8), %rdx
	leaq	(%rax,%rdx,2), %rdx
	addq	%rdx, %rax
	addq	%rbp, %rax
	jmp	.L235
.L337:
	subq	%r12, %rdx
	subq	%r12, %rax
.L233:
	addq	%rdx, %rdx
	addq	%rax, %rax
.L235:
	addl	$1, %esi
	cmpq	%r12, %rdx
	jnb	.L337
	cmpq	%r12, %rax
	jb	.L233
	movl	%esi, 12(%rsp)
	cmpq	$1, %r8
	jne	.L274
	jmp	.L267
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L338:
	movq	-8(%r15,%rax,8), %rdi
	cmpq	%rdi, (%r15,%rax,8)
	jl	.L223
.L217:
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%r12, %rax
	jb	.L338
	subq	%rbx, %rdx
	leaq	1(%rdx), %rbp
	cmpq	%rcx, %rbp
	jnb	.L224
.L336:
	movq	%r12, %rdx
	leaq	0(%rbp,%rbx), %rax
	subq	%rbx, %rdx
	cmpq	%rcx, %rdx
	jnb	.L272
	movq	%rdx, %rbp
	movq	%r12, %r14
	jmp	.L225
	.p2align 4,,10
	.p2align 3
.L215:
	cmpq	$1, %r8
	jbe	.L329
	movl	$0, 12(%rsp)
	xorl	%ebp, %ebp
.L274:
	movq	%rcx, 64(%rsp)
	leaq	(%r8,%r8,2), %rax
	movq	%rbp, 72(%rsp)
	leaq	96(%rsp,%rax,8), %r14
	movq	%rbx, 80(%rsp)
	movq	%r12, 88(%rsp)
	.p2align 4
	.p2align 3
.L266:
	movl	12(%rsp), %eax
	cmpl	%eax, -32(%r14)
	jg	.L268
	cmpq	$96, %r8
	jne	.L333
.L268:
	movq	-24(%r14), %rdi
	movq	-48(%r14), %r11
	subq	$1, %r8
	xorl	%r10d, %r10d
	movq	-16(%r14), %rcx
	leaq	0(,%rdi,8), %r9
	movq	%rdi, %rdx
	leaq	(%r15,%r9), %rbx
	subq	%r11, %rdx
	.p2align 4
	.p2align 3
.L237:
	cmpq	%rdx, %r10
	jnb	.L339
.L238:
	movq	%rdx, %rax
	subq	%r10, %rax
	shrq	%rax
	addq	%r10, %rax
	leaq	(%r11,%rax), %rsi
	movq	(%r15,%rsi,8), %rsi
	cmpq	%rsi, (%rbx)
	jl	.L283
	leaq	1(%rax), %r10
	cmpq	%rdx, %r10
	jb	.L238
.L339:
	addq	%r11, %r10
	cmpq	%r10, %rdi
	je	.L240
	leaq	-8(%r15,%rdi,8), %rbp
	movq	%rcx, %rdx
	xorl	%esi, %esi
	.p2align 4
	.p2align 3
.L242:
	cmpq	%rdx, %rsi
	jnb	.L340
.L243:
	movq	%rdx, %rax
	movq	0(%rbp), %r12
	subq	%rsi, %rax
	shrq	%rax
	addq	%rsi, %rax
	leaq	(%r15,%rax,8), %r11
	cmpq	%r12, (%r11,%r9)
	jge	.L284
	leaq	1(%rax), %rsi
	cmpq	%rdx, %rsi
	jb	.L243
.L340:
	movq	%rdi, %rax
	leaq	0(,%rsi,8), %rdx
	addq	%rsi, %rdi
	subq	%r10, %rax
	movq	%rdx, %r11
	salq	$3, %r10
	leaq	(%r15,%rdi,8), %rbp
	leaq	(%r15,%r10), %r12
	shrq	$3, %r11
	cmpq	%rax, %rsi
	jb	.L244
	leaq	0(,%rax,8), %r9
	movq	%r13, %rdi
	movq	%r12, %rsi
	movq	%r8, 40(%rsp)
	movq	%r9, %rdx
	movq	%r11, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%r9, 16(%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %r9
	movq	32(%rsp), %r11
	movq	%r13, %rdi
	movq	24(%rsp), %rcx
	movq	40(%rsp), %r8
	movq	%r9, %rax
	leaq	0(%r13,%r9), %rdx
	shrq	$3, %rax
	cmpq	%r11, %rax
	cmova	%r11, %rax
	cmpq	$1, %rax
	jbe	.L332
	.p2align 4
	.p2align 3
.L249:
	leaq	-8(,%rax,8), %r11
	movq	(%rdi), %r9
	movq	(%rbx), %rsi
	movq	%r12, %rax
	leaq	(%r12,%r11), %r10
	jmp	.L248
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L342:
	movq	%r9, -8(%rax)
	addq	$8, %rdi
	movq	(%rdi), %r9
	cmpq	%rax, %r10
	je	.L341
.L248:
	addq	$8, %rax
	cmpq	%r9, %rsi
	jge	.L342
	movq	%rsi, -8(%rax)
	addq	$8, %rbx
	movq	(%rbx), %rsi
	cmpq	%rax, %r10
	jne	.L248
.L341:
	movq	%rdx, %rax
	movq	%rbp, %rsi
	addq	%r11, %r12
	subq	%rdi, %rax
	subq	%rbx, %rsi
	shrq	$3, %rax
	shrq	$3, %rsi
	cmpq	%rsi, %rax
	cmova	%rsi, %rax
	cmpq	$1, %rax
	ja	.L249
	cmpq	%rbp, %rbx
	jb	.L343
.L250:
	cmpq	%rdx, %rdi
	jnb	.L240
	subq	%rdi, %rdx
	movq	%rdi, %rsi
	movq	%r12, %rdi
	movq	%r8, 24(%rsp)
	movq	%rcx, 16(%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	.p2align 4
	.p2align 3
.L240:
	addq	%rcx, -40(%r14)
	subq	$24, %r14
	cmpq	$1, %r8
	jne	.L266
.L333:
	movq	64(%rsp), %rcx
	movq	72(%rsp), %rbp
	movq	80(%rsp), %rbx
	movq	88(%rsp), %r12
.L267:
	cmpq	%r12, %rbx
	jnb	.L329
	movl	12(%rsp), %edx
	leaq	-3(%r8,%r8,2), %rax
	movl	%edx, 112(%rsp,%rax,8)
	leaq	(%r8,%r8,2), %rax
	addq	$1, %r8
	movq	%rbx, 96(%rsp,%rax,8)
	addq	%rbp, %rbx
	movq	$0, 112(%rsp,%rax,8)
	movq	%rbp, 104(%rsp,%rax,8)
	jmp	.L270
	.p2align 4,,10
	.p2align 3
.L344:
	addq	$8, %rdi
	movq	%rsi, %rax
.L252:
	movq	%rax, -8(%r12)
.L332:
	cmpq	%rbp, %rbx
	jnb	.L250
.L343:
	cmpq	%rdx, %rdi
	jnb	.L240
	movq	(%rbx), %rax
	movq	(%rdi), %rsi
	addq	$8, %r12
	cmpq	%rax, %rsi
	jle	.L344
	addq	$8, %rbx
	jmp	.L252
	.p2align 4,,10
	.p2align 3
.L283:
	movq	%rax, %rdx
	jmp	.L237
	.p2align 4,,10
	.p2align 3
.L284:
	movq	%rax, %rdx
	jmp	.L242
.L244:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	movq	%r8, 56(%rsp)
	movq	%r11, 48(%rsp)
	movq	%r9, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%r10, 40(%rsp)
	call	memcpy@PLT
	movq	48(%rsp), %r11
	movq	16(%rsp), %rdx
	movq	32(%rsp), %r9
	subq	40(%rsp), %r9
	shrq	$3, %r9
	addq	%r13, %rdx
	movq	24(%rsp), %rcx
	movq	56(%rsp), %r8
	cmpq	%r11, %r9
	cmova	%r11, %r9
	cmpq	$1, %r9
	jbe	.L256
	.p2align 4
	.p2align 3
.L260:
	negq	%r9
	movq	-8(%rbx), %rdi
	movq	-8(%rdx), %rsi
	movq	%rbp, %rax
	salq	$3, %r9
	leaq	8(%rbp,%r9), %r10
	jmp	.L259
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L346:
	movq	%rsi, (%rax)
	subq	$8, %rdx
	movq	-8(%rdx), %rsi
	cmpq	%rax, %r10
	je	.L345
.L259:
	subq	$8, %rax
	cmpq	%rdi, %rsi
	jge	.L346
	movq	%rdi, (%rax)
	subq	$8, %rbx
	movq	-8(%rbx), %rdi
	cmpq	%rax, %r10
	jne	.L259
.L345:
	leaq	8(%rbp,%r9), %rbp
	movq	%rdx, %rax
	movq	%rbx, %r9
	subq	%r12, %r9
	subq	%r13, %rax
	shrq	$3, %r9
	shrq	$3, %rax
	cmpq	%rax, %r9
	cmova	%rax, %r9
	cmpq	$1, %r9
	ja	.L260
.L256:
	cmpq	%rbx, %r12
	jnb	.L261
	cmpq	%rdx, %r13
	jb	.L264
	jmp	.L240
	.p2align 4,,10
	.p2align 3
.L347:
	subq	$8, %rbx
	movq	%rsi, %rax
.L263:
	movq	%rax, 0(%rbp)
	cmpq	%rdx, %r13
	jnb	.L240
	cmpq	%rbx, %r12
	jnb	.L261
.L264:
	movq	-8(%rdx), %rax
	movq	-8(%rbx), %rsi
	subq	$8, %rbp
	cmpq	%rax, %rsi
	jg	.L347
	subq	$8, %rdx
	jmp	.L263
.L261:
	cmpq	%rdx, %r13
	jnb	.L240
	subq	%r13, %rdx
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r8, 24(%rsp)
	subq	%rdx, %rdi
	movq	%rcx, 16(%rsp)
	call	memcpy@PLT
	movq	24(%rsp), %r8
	movq	16(%rsp), %rcx
	addq	%rcx, -40(%r14)
	subq	$24, %r14
	cmpq	$1, %r8
	jne	.L266
	jmp	.L333
.L329:
	movq	%r13, %rdi
	call	free@PLT
	movl	$1, %eax
.L211:
	movq	2408(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L348
	addq	$2424, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L216:
	.cfi_restore_state
	movl	$1, %ebp
	cmpq	$1, %rcx
	ja	.L224
.L272:
	leaq	(%rcx,%rbx), %r14
	movq	%rcx, %rbp
.L225:
	cmpq	%r14, %rax
	jnb	.L224
	leaq	-8(%r15,%rax,8), %r11
	jmp	.L230
.L227:
	addq	$1, %rax
	addq	$8, %r11
	cmpq	%r14, %rax
	je	.L224
.L230:
	movq	8(%r11), %r10
	cmpq	(%r11), %r10
	jge	.L227
	movq	%r11, %rdx
	movq	%rax, %rsi
	jmp	.L229
.L349:
	subq	$8, %rdx
	cmpq	-8(%rdi), %r10
	jge	.L228
.L229:
	movq	(%rdx), %r9
	subq	$1, %rsi
	movq	%rdx, %rdi
	movq	%r9, 8(%rdx)
	cmpq	%rsi, %rbx
	jb	.L349
.L228:
	movq	%r10, (%rdi)
	jmp	.L227
.L335:
	movq	%r14, %rdi
	shrq	%rdi
	salq	$3, %rdi
	call	malloc@PLT
	movq	%rax, %r11
	testq	%rax, %rax
	jne	.L212
	xorl	%eax, %eax
	jmp	.L211
	.p2align 4,,10
	.p2align 3
.L277:
	movq	%r14, %r12
	xorl	%r11d, %r11d
	jmp	.L212
.L348:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE81:
	.size	sort_i64, .-sort_i64
	.p2align 4
	.type	sort_u64, @function
sort_u64:
.LFB82:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$2424, %rsp
	.cfi_def_cfa_offset 2480
	movq	%fs:40, %r14
	movq	%r14, 2408(%rsp)
	movq	%rsi, %r14
	cmpq	$31, %rsi
	jbe	.L416
	movq	%r14, %rax
	xorl	%edx, %edx
.L352:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L352
	leaq	(%rdx,%rax), %r12
	cmpq	%r14, %r12
	jb	.L477
	movl	$32, %r12d
	xorl	%r11d, %r11d
.L351:
	movq	%r12, %rcx
	xorl	%r8d, %r8d
	xorl	%ebx, %ebx
	movq	%r11, %r13
	movq	%r14, %r12
.L410:
	cmpq	%r12, %rbx
	jnb	.L354
	leaq	1(%rbx), %rax
	movl	$1, %ebp
	cmpq	%rax, %r12
	je	.L355
.L411:
	movq	8(%r15,%rbx,8), %rdi
	cmpq	(%r15,%rbx,8), %rdi
	jnb	.L356
	jmp	.L360
.L357:
	movq	(%r15,%rax,8), %rsi
	cmpq	%rdi, %rsi
	jnb	.L361
	movq	%rsi, %rdi
.L360:
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%r12, %rax
	jb	.L357
.L361:
	movq	%rdx, %rsi
	movq	%rbx, %rax
	cmpq	%rdx, %rbx
	jnb	.L362
.L358:
	movq	(%r15,%rax,8), %rdi
	movq	(%r15,%rsi,8), %r9
	movq	%r9, (%r15,%rax,8)
	addq	$1, %rax
	movq	%rdi, (%r15,%rsi,8)
	subq	$1, %rsi
	cmpq	%rsi, %rax
	jb	.L358
.L362:
	subq	%rbx, %rdx
	leaq	1(%rdx), %rbp
.L355:
	cmpq	%rcx, %rbp
	jb	.L412
.L363:
	testq	%r8, %r8
	jne	.L413
	movq	%rbx, 96(%rsp)
	addq	%rbp, %rbx
	movq	$0, 112(%rsp)
	movq	%rbp, 104(%rsp)
	cmpq	%r12, %rbx
	jnb	.L471
	leaq	1(%rbx), %rax
	movl	$1, %r8d
	cmpq	%rax, %r12
	jne	.L411
	movl	$1, %ebp
	cmpq	$1, %rcx
	ja	.L412
.L413:
	leaq	-3(%r8,%r8,2), %rdx
	xorl	%esi, %esi
	movq	104(%rsp,%rdx,8), %rax
	movq	96(%rsp,%rdx,8), %rdx
	leaq	(%rax,%rdx,2), %rdx
	addq	%rdx, %rax
	addq	%rbp, %rax
	jmp	.L375
.L478:
	subq	%r12, %rdx
	subq	%r12, %rax
.L373:
	addq	%rdx, %rdx
	addq	%rax, %rax
.L375:
	addl	$1, %esi
	cmpq	%r12, %rdx
	jnb	.L478
	cmpq	%r12, %rax
	jb	.L373
	movl	%esi, 12(%rsp)
	cmpq	$1, %r8
	jne	.L414
	jmp	.L407
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L479:
	movq	-8(%r15,%rax,8), %rdi
	cmpq	%rdi, (%r15,%rax,8)
	jb	.L362
.L356:
	movq	%rax, %rdx
	addq	$1, %rax
	cmpq	%r12, %rax
	jb	.L479
	subq	%rbx, %rdx
	leaq	1(%rdx), %rbp
	jmp	.L355
.L354:
	cmpq	$1, %r8
	jbe	.L471
	movl	$0, 12(%rsp)
	xorl	%ebp, %ebp
.L414:
	movq	%rcx, 64(%rsp)
	leaq	(%r8,%r8,2), %rax
	movq	%rbp, 72(%rsp)
	leaq	96(%rsp,%rax,8), %r14
	movq	%rbx, 80(%rsp)
	movq	%r12, 88(%rsp)
	.p2align 4
	.p2align 3
.L406:
	movl	12(%rsp), %eax
	cmpl	-32(%r14), %eax
	jl	.L408
	cmpq	$96, %r8
	jne	.L475
.L408:
	movq	-24(%r14), %rdi
	movq	-48(%r14), %r11
	subq	$1, %r8
	xorl	%r10d, %r10d
	movq	-16(%r14), %rcx
	leaq	0(,%rdi,8), %r9
	movq	%rdi, %rdx
	leaq	(%r15,%r9), %rbx
	subq	%r11, %rdx
	.p2align 4
	.p2align 3
.L377:
	cmpq	%rdx, %r10
	jnb	.L480
.L378:
	movq	%rdx, %rax
	subq	%r10, %rax
	shrq	%rax
	addq	%r10, %rax
	leaq	(%r11,%rax), %rsi
	movq	(%r15,%rsi,8), %rsi
	cmpq	%rsi, (%rbx)
	jb	.L423
	leaq	1(%rax), %r10
	cmpq	%rdx, %r10
	jb	.L378
.L480:
	addq	%r11, %r10
	cmpq	%r10, %rdi
	je	.L380
	leaq	-8(%r15,%rdi,8), %rbp
	movq	%rcx, %rdx
	xorl	%esi, %esi
	.p2align 4
	.p2align 3
.L382:
	cmpq	%rdx, %rsi
	jnb	.L481
.L383:
	movq	%rdx, %rax
	movq	0(%rbp), %r12
	subq	%rsi, %rax
	shrq	%rax
	addq	%rsi, %rax
	leaq	(%r15,%rax,8), %r11
	cmpq	%r12, (%r11,%r9)
	jnb	.L424
	leaq	1(%rax), %rsi
	cmpq	%rdx, %rsi
	jb	.L383
.L481:
	movq	%rdi, %rax
	leaq	0(,%rsi,8), %rdx
	addq	%rsi, %rdi
	subq	%r10, %rax
	movq	%rdx, %r11
	salq	$3, %r10
	leaq	(%r15,%rdi,8), %rbp
	shrq	$3, %r11
	leaq	(%r15,%r10), %r12
	cmpq	%rax, %rsi
	jb	.L384
	leaq	0(,%rax,8), %r9
	movq	%r13, %rdi
	movq	%r12, %rsi
	movq	%r8, 40(%rsp)
	movq	%r9, %rdx
	movq	%r11, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%r9, 16(%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %r9
	movq	32(%rsp), %r11
	movq	%r13, %rdi
	movq	24(%rsp), %rcx
	movq	40(%rsp), %r8
	movq	%r9, %rax
	leaq	0(%r13,%r9), %rdx
	shrq	$3, %rax
	cmpq	%r11, %rax
	cmova	%r11, %rax
	cmpq	$1, %rax
	jbe	.L474
	.p2align 4
	.p2align 3
.L389:
	leaq	-8(,%rax,8), %r11
	movq	(%rdi), %r9
	movq	(%rbx), %rsi
	movq	%r12, %rax
	leaq	(%r12,%r11), %r10
	jmp	.L388
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L483:
	movq	%rsi, -8(%rax)
	addq	$8, %rbx
	movq	(%rbx), %rsi
	cmpq	%rax, %r10
	je	.L482
.L388:
	addq	$8, %rax
	cmpq	%r9, %rsi
	jb	.L483
	movq	%r9, -8(%rax)
	addq	$8, %rdi
	movq	(%rdi), %r9
	cmpq	%rax, %r10
	jne	.L388
.L482:
	movq	%rdx, %rax
	movq	%rbp, %rsi
	addq	%r11, %r12
	subq	%rdi, %rax
	subq	%rbx, %rsi
	shrq	$3, %rax
	shrq	$3, %rsi
	cmpq	%rsi, %rax
	cmova	%rsi, %rax
	cmpq	$1, %rax
	ja	.L389
	cmpq	%rbp, %rbx
	jb	.L484
.L390:
	cmpq	%rdx, %rdi
	jnb	.L380
	subq	%rdi, %rdx
	movq	%rdi, %rsi
	movq	%r12, %rdi
	movq	%r8, 24(%rsp)
	movq	%rcx, 16(%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	.p2align 4
	.p2align 3
.L380:
	addq	%rcx, -40(%r14)
	subq	$24, %r14
	cmpq	$1, %r8
	jne	.L406
.L475:
	movq	64(%rsp), %rcx
	movq	72(%rsp), %rbp
	movq	80(%rsp), %rbx
	movq	88(%rsp), %r12
.L407:
	cmpq	%r12, %rbx
	jnb	.L471
	movl	12(%rsp), %edx
	leaq	-3(%r8,%r8,2), %rax
	movl	%edx, 112(%rsp,%rax,8)
	leaq	(%r8,%r8,2), %rax
	addq	$1, %r8
	movq	%rbx, 96(%rsp,%rax,8)
	addq	%rbp, %rbx
	movq	$0, 112(%rsp,%rax,8)
	movq	%rbp, 104(%rsp,%rax,8)
	jmp	.L410
	.p2align 4,,10
	.p2align 3
.L485:
	addq	$8, %rdi
	movq	%rsi, %rax
.L392:
	movq	%rax, -8(%r12)
.L474:
	cmpq	%rbp, %rbx
	jnb	.L390
.L484:
	cmpq	%rdx, %rdi
	jnb	.L380
	movq	(%rbx), %rax
	movq	(%rdi), %rsi
	addq	$8, %r12
	cmpq	%rsi, %rax
	jnb	.L485
	addq	$8, %rbx
	jmp	.L392
	.p2align 4,,10
	.p2align 3
.L423:
	movq	%rax, %rdx
	jmp	.L377
	.p2align 4,,10
	.p2align 3
.L424:
	movq	%rax, %rdx
	jmp	.L382
.L384:
	movq	%rbx, %rsi
	movq	%r13, %rdi
	movq	%r8, 56(%rsp)
	movq	%r11, 40(%rsp)
	movq	%r9, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%r10, 48(%rsp)
	call	memcpy@PLT
	movq	40(%rsp), %r11
	movq	16(%rsp), %rdx
	movq	32(%rsp), %r9
	subq	48(%rsp), %r9
	shrq	$3, %r9
	addq	%r13, %rdx
	movq	24(%rsp), %rcx
	movq	56(%rsp), %r8
	cmpq	%r11, %r9
	cmova	%r11, %r9
	cmpq	$1, %r9
	jbe	.L396
	.p2align 4
	.p2align 3
.L400:
	negq	%r9
	movq	-8(%rbx), %rdi
	movq	-8(%rdx), %rsi
	movq	%rbp, %rax
	salq	$3, %r9
	leaq	8(%rbp,%r9), %r10
	jmp	.L399
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L487:
	movq	%rsi, (%rax)
	subq	$8, %rdx
	movq	-8(%rdx), %rsi
	cmpq	%rax, %r10
	je	.L486
.L399:
	subq	$8, %rax
	cmpq	%rdi, %rsi
	jnb	.L487
	movq	%rdi, (%rax)
	subq	$8, %rbx
	movq	-8(%rbx), %rdi
	cmpq	%rax, %r10
	jne	.L399
.L486:
	leaq	8(%rbp,%r9), %rbp
	movq	%rdx, %rax
	movq	%rbx, %r9
	subq	%r12, %r9
	subq	%r13, %rax
	shrq	$3, %r9
	shrq	$3, %rax
	cmpq	%rax, %r9
	cmova	%rax, %r9
	cmpq	$1, %r9
	ja	.L400
.L396:
	cmpq	%rbx, %r12
	jnb	.L401
	cmpq	%rdx, %r13
	jb	.L404
	jmp	.L380
	.p2align 4,,10
	.p2align 3
.L488:
	subq	$8, %rbx
	movq	%rsi, %rax
.L403:
	movq	%rax, 0(%rbp)
	cmpq	%rdx, %r13
	jnb	.L380
	cmpq	%rbx, %r12
	jnb	.L401
.L404:
	movq	-8(%rdx), %rax
	movq	-8(%rbx), %rsi
	subq	$8, %rbp
	cmpq	%rsi, %rax
	jb	.L488
	subq	$8, %rdx
	jmp	.L403
.L401:
	cmpq	%rdx, %r13
	jnb	.L380
	subq	%r13, %rdx
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r8, 24(%rsp)
	subq	%rdx, %rdi
	movq	%rcx, 16(%rsp)
	call	memcpy@PLT
	movq	24(%rsp), %r8
	movq	16(%rsp), %rcx
	addq	%rcx, -40(%r14)
	subq	$24, %r14
	cmpq	$1, %r8
	jne	.L406
	jmp	.L475
.L471:
	movq	%r13, %rdi
	call	free@PLT
	movl	$1, %eax
.L350:
	movq	2408(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L489
	addq	$2424, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L412:
	.cfi_restore_state
	movq	%r12, %rax
	leaq	(%rcx,%rbx), %r11
	leaq	0(%rbp,%rbx), %r9
	subq	%rbx, %rax
	leaq	-8(%r15,%r9,8), %rbp
	cmpq	%rcx, %rax
	cmovb	%r12, %r11
	cmovnb	%rcx, %rax
	cmpq	%r11, %r9
	jb	.L369
	jmp	.L370
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L366:
	addq	$1, %r9
	addq	$8, %rbp
	cmpq	%r11, %r9
	je	.L370
.L369:
	movq	8(%rbp), %r10
	cmpq	0(%rbp), %r10
	jnb	.L366
	movq	%rbp, %rdx
	movq	%r9, %rsi
	jmp	.L368
.L490:
	subq	$8, %rdx
	cmpq	(%rdx), %r10
	jnb	.L367
.L368:
	movq	(%rdx), %rdi
	subq	$1, %rsi
	movq	%rdx, %r14
	movq	%rdi, 8(%rdx)
	cmpq	%rsi, %rbx
	jb	.L490
.L367:
	addq	$1, %r9
	movq	%r10, (%r14)
	addq	$8, %rbp
	cmpq	%r11, %r9
	jne	.L369
.L370:
	movq	%rax, %rbp
	jmp	.L363
.L477:
	movq	%r14, %rdi
	shrq	%rdi
	salq	$3, %rdi
	call	malloc@PLT
	movq	%rax, %r11
	testq	%rax, %rax
	jne	.L351
	xorl	%eax, %eax
	jmp	.L350
	.p2align 4,,10
	.p2align 3
.L416:
	movq	%r14, %r12
	xorl	%r11d, %r11d
	jmp	.L351
.L489:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE82:
	.size	sort_u64, .-sort_u64
	.p2align 4
	.type	sort_text, @function
sort_text:
.LFB84:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r8
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$2456, %rsp
	.cfi_def_cfa_offset 2512
	movq	%fs:40, %r13
	movq	%r13, 2440(%rsp)
	movq	%rsi, %r13
	cmpq	$31, %rsi
	jbe	.L559
	movq	%r13, %rax
	xorl	%edx, %edx
.L493:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L493
	leaq	(%rdx,%rax), %rbp
	cmpq	%r13, %rbp
	jb	.L629
	movq	$0, 24(%rsp)
	movl	$32, %ebp
.L492:
	movq	$0, 56(%rsp)
	movq	%r13, %r15
	xorl	%ebx, %ebx
	movq	%r8, %r10
	movq	%rbp, %r13
.L552:
	cmpq	%r15, %rbx
	jnb	.L495
	leaq	1(%rbx), %r12
	cmpq	%r12, %r15
	je	.L496
.L553:
	movq	(%r10,%rbx,8), %rsi
	movq	8(%r10,%rbx,8), %rdi
	movq	%r10, 8(%rsp)
	call	myl_native_text_compare@PLT
	movq	8(%rsp), %r14
	testl	%eax, %eax
	jns	.L497
	jmp	.L501
.L498:
	movq	-8(%r14,%r12,8), %rsi
	movq	(%r14,%r12,8), %rdi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L624
.L501:
	movq	%r12, %rbp
	addq	$1, %r12
	cmpq	%r15, %r12
	jb	.L498
.L624:
	movq	%r14, %r10
	movq	%rbp, %rdx
	movq	%rbx, %rax
	cmpq	%rbp, %rbx
	jnb	.L503
.L499:
	movq	(%r10,%rax,8), %rcx
	movq	(%r10,%rdx,8), %rsi
	movq	%rsi, (%r10,%rax,8)
	addq	$1, %rax
	movq	%rcx, (%r10,%rdx,8)
	subq	$1, %rdx
	cmpq	%rdx, %rax
	jb	.L499
	subq	%rbx, %rbp
	leaq	1(%rbp), %r14
	cmpq	%r13, %r14
	jnb	.L505
.L631:
	movq	%r15, %rax
	leaq	(%r14,%rbx), %r12
	subq	%rbx, %rax
	cmpq	%r13, %rax
	jnb	.L554
	movq	%rax, %r14
	movq	%r15, %rcx
	jmp	.L506
	.p2align 4,,10
	.p2align 3
.L630:
	movq	-8(%r14,%r12,8), %rsi
	movq	(%r14,%r12,8), %rdi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	js	.L618
.L497:
	movq	%r12, %rbp
	addq	$1, %r12
	cmpq	%r15, %r12
	jb	.L630
.L618:
	movq	%r14, %r10
.L503:
	subq	%rbx, %rbp
	leaq	1(%rbp), %r14
	cmpq	%r13, %r14
	jb	.L631
.L505:
	cmpq	$0, 56(%rsp)
	jne	.L555
	movq	%rbx, 128(%rsp)
	addq	%r14, %rbx
	movq	$0, 144(%rsp)
	movq	%r14, 136(%rsp)
	cmpq	%r15, %rbx
	jb	.L632
.L551:
	movq	24(%rsp), %rdi
	call	free@PLT
	movl	$1, %eax
.L491:
	movq	2440(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L633
	addq	$2456, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L495:
	.cfi_restore_state
	cmpq	$1, 56(%rsp)
	jbe	.L551
	xorl	%r14d, %r14d
	xorl	%r8d, %r8d
.L556:
	movq	56(%rsp), %rax
	movq	%r14, 104(%rsp)
	movl	%r8d, 76(%rsp)
	leaq	(%rax,%rax,2), %rax
	movq	%rbx, 112(%rsp)
	leaq	128(%rsp,%rax,8), %rax
	movq	%r15, 120(%rsp)
	movq	%rax, 48(%rsp)
	movq	%r13, 96(%rsp)
	movq	%r10, %r13
	.p2align 4
	.p2align 3
.L548:
	movq	48(%rsp), %rax
	movl	76(%rsp), %ecx
	cmpl	-32(%rax), %ecx
	jl	.L550
	cmpq	$96, 56(%rsp)
	jne	.L634
.L550:
	movq	48(%rsp), %rcx
	subq	$1, 56(%rsp)
	xorl	%r15d, %r15d
	movq	-24(%rcx), %rax
	movq	-16(%rcx), %rdx
	movq	-48(%rcx), %r14
	leaq	0(,%rax,8), %rcx
	movq	%rdx, 64(%rsp)
	movq	%rcx, 8(%rsp)
	leaq	0(%r13,%rcx), %rbx
	movq	%rax, 16(%rsp)
	subq	%r14, %rax
	movq	%rax, %r12
	.p2align 4
	.p2align 3
.L519:
	cmpq	%r12, %r15
	jnb	.L635
.L520:
	movq	%r12, %rbp
	movq	(%rbx), %rdi
	subq	%r15, %rbp
	shrq	%rbp
	addq	%r15, %rbp
	leaq	(%r14,%rbp), %rax
	movq	0(%r13,%rax,8), %rsi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	js	.L564
	leaq	1(%rbp), %r15
	cmpq	%r12, %r15
	jb	.L520
.L635:
	movq	16(%rsp), %rax
	addq	%r15, %r14
	cmpq	%r14, %rax
	je	.L522
	leaq	-8(%r13,%rax,8), %rbp
	movq	64(%rsp), %r12
	movq	%rbx, 32(%rsp)
	xorl	%r15d, %r15d
	movq	%r13, %rbx
	movq	%rbp, %r13
	.p2align 4
	.p2align 3
.L524:
	cmpq	%r12, %r15
	jnb	.L636
.L525:
	movq	%r12, %rax
	movq	8(%rsp), %rcx
	movq	0(%r13), %rsi
	subq	%r15, %rax
	shrq	%rax
	leaq	(%rax,%r15), %rbp
	leaq	(%rbx,%rbp,8), %rax
	movq	(%rax,%rcx), %rdi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L565
	leaq	1(%rbp), %r15
	cmpq	%r12, %r15
	jb	.L525
.L636:
	movq	16(%rsp), %rcx
	leaq	0(,%r15,8), %rdx
	movq	%rbx, %r13
	leaq	0(,%r14,8), %r9
	movq	%rdx, %r10
	movq	32(%rsp), %rbx
	leaq	0(%r13,%r9), %r8
	movq	%rcx, %rax
	addq	%r15, %rcx
	shrq	$3, %r10
	subq	%r14, %rax
	leaq	0(%r13,%rcx,8), %rcx
	cmpq	%rax, %r15
	jb	.L526
	movq	24(%rsp), %r15
	leaq	0(,%rax,8), %rbp
	movq	%r8, %rsi
	movq	%r10, 40(%rsp)
	movq	%rbp, %rdx
	movq	%rcx, 16(%rsp)
	movq	%r15, %rdi
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	leaq	(%r15,%rbp), %rax
	movq	40(%rsp), %r10
	movq	8(%rsp), %r8
	movq	%rax, 32(%rsp)
	movq	%rbp, %rax
	movq	16(%rsp), %rcx
	shrq	$3, %rax
	cmpq	%r10, %rax
	cmova	%r10, %rax
	cmpq	$1, %rax
	jbe	.L566
	movq	%r13, 80(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r8, %rcx
	.p2align 4
	.p2align 3
.L531:
	movq	(%r15), %r13
	movq	(%rbx), %r12
	movq	%rcx, 8(%rsp)
	movq	%rcx, %rbp
	leaq	-8(,%rax,8), %rdi
	movq	%rdi, 16(%rsp)
	leaq	(%rcx,%rdi), %r14
	jmp	.L530
	.p2align 4,,10
	.p2align 3
.L638:
	movq	%r13, -8(%rbp)
	addq	$8, %r15
	movq	(%r15), %r13
	cmpq	%rbp, %r14
	je	.L637
.L530:
	movq	%r13, %rsi
	movq	%r12, %rdi
	addq	$8, %rbp
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L638
	movq	%r12, -8(%rbp)
	addq	$8, %rbx
	movq	(%rbx), %r12
	cmpq	%rbp, %r14
	jne	.L530
.L637:
	movq	32(%rsp), %rax
	movq	40(%rsp), %rdx
	movq	8(%rsp), %rcx
	addq	16(%rsp), %rcx
	subq	%r15, %rax
	subq	%rbx, %rdx
	shrq	$3, %rax
	shrq	$3, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	cmpq	$1, %rax
	ja	.L531
	movq	%rcx, %r8
	movq	80(%rsp), %r13
	movq	40(%rsp), %rcx
.L527:
	cmpq	%rcx, %rbx
	jnb	.L532
	cmpq	32(%rsp), %r15
	jnb	.L522
	movq	%r8, %rbp
	movq	%rcx, %r14
	jmp	.L536
	.p2align 4,,10
	.p2align 3
.L640:
	movq	%r12, -8(%rbp)
	addq	$8, %r15
	cmpq	32(%rsp), %r15
	jnb	.L522
.L628:
	cmpq	%r14, %rbx
	jnb	.L639
.L536:
	movq	(%r15), %r12
	movq	(%rbx), %rdi
	addq	$8, %rbp
	movq	%r12, %rsi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L640
	movq	(%rbx), %rax
	addq	$8, %rbx
	movq	%rax, -8(%rbp)
	cmpq	32(%rsp), %r15
	jb	.L628
	.p2align 4
	.p2align 3
.L522:
	movq	48(%rsp), %rax
	movq	64(%rsp), %rcx
	addq	%rcx, -40(%rax)
	subq	$24, %rax
	movq	%rax, 48(%rsp)
	cmpq	$1, 56(%rsp)
	jne	.L548
	movq	%r13, %r10
	movq	104(%rsp), %r14
	movl	76(%rsp), %r8d
	movq	112(%rsp), %rbx
	movq	96(%rsp), %r13
	movq	120(%rsp), %r15
.L549:
	cmpq	%r15, %rbx
	jnb	.L551
	movq	56(%rsp), %rcx
	leaq	-3(%rcx,%rcx,2), %rax
	movl	%r8d, 144(%rsp,%rax,8)
	leaq	(%rcx,%rcx,2), %rax
	movq	%rbx, 128(%rsp,%rax,8)
	addq	%r14, %rbx
	movq	$0, 144(%rsp,%rax,8)
	movq	%r14, 136(%rsp,%rax,8)
	leaq	1(%rcx), %rax
	movq	%rax, 56(%rsp)
	jmp	.L552
	.p2align 4,,10
	.p2align 3
.L564:
	movq	%rbp, %r12
	jmp	.L519
	.p2align 4,,10
	.p2align 3
.L565:
	movq	%rbp, %r12
	jmp	.L524
.L526:
	movq	24(%rsp), %r15
	movq	%rbx, %rsi
	movq	%r10, 88(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r15, %rdi
	movq	%r8, 32(%rsp)
	movq	%r9, 80(%rsp)
	movq	%rdx, 16(%rsp)
	call	memcpy@PLT
	movq	88(%rsp), %r10
	movq	8(%rsp), %rbp
	subq	80(%rsp), %rbp
	addq	16(%rsp), %r15
	shrq	$3, %rbp
	movq	%r10, %rax
	movq	32(%rsp), %r8
	movq	40(%rsp), %rcx
	cmpq	%r10, %rbp
	cmovbe	%rbp, %rax
	cmpq	$1, %rax
	jbe	.L538
	movq	%r13, 40(%rsp)
	.p2align 4
	.p2align 3
.L542:
	negq	%rax
	movq	%rcx, 8(%rsp)
	movq	-8(%rbx), %r13
	movq	%rcx, %r14
	leaq	0(,%rax,8), %rdx
	movq	-8(%r15), %r12
	movq	%rdx, 16(%rsp)
	leaq	8(%rcx,%rdx), %rbp
	jmp	.L541
	.p2align 4,,10
	.p2align 3
.L642:
	movq	%r12, (%r14)
	subq	$8, %r15
	movq	-8(%r15), %r12
	cmpq	%r14, %rbp
	je	.L641
.L541:
	movq	%r13, %rsi
	movq	%r12, %rdi
	subq	$8, %r14
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L642
	movq	%r13, (%r14)
	subq	$8, %rbx
	movq	-8(%rbx), %r13
	cmpq	%r14, %rbp
	jne	.L541
.L641:
	movq	16(%rsp), %rdx
	movq	8(%rsp), %rcx
	movq	%rbx, %rax
	subq	32(%rsp), %rax
	leaq	8(%rcx,%rdx), %rcx
	movq	%r15, %rdx
	subq	24(%rsp), %rdx
	shrq	$3, %rax
	shrq	$3, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	cmpq	$1, %rax
	ja	.L542
	movq	32(%rsp), %r8
	movq	40(%rsp), %r13
.L538:
	cmpq	%rbx, %r8
	jnb	.L543
	cmpq	%r15, 24(%rsp)
	jnb	.L522
	movq	%r8, %r14
	movq	%rcx, %rbp
	.p2align 4
	.p2align 3
.L547:
	movq	-8(%r15), %r12
	movq	-8(%rbx), %rsi
	subq	$8, %rbp
	movq	%r12, %rdi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L544
	movq	-8(%rbx), %rdx
	leaq	-8(%rbx), %rax
	movq	%rdx, 0(%rbp)
	cmpq	%rax, %r14
	jnb	.L622
	cmpq	%r15, 24(%rsp)
	jnb	.L522
	movq	%rax, %rbx
	jmp	.L547
	.p2align 4,,10
	.p2align 3
.L544:
	movq	%r12, 0(%rbp)
	subq	$8, %r15
	cmpq	%rbx, %r14
	jnb	.L622
	cmpq	%r15, 24(%rsp)
	jb	.L547
	jmp	.L522
.L622:
	movq	%rbp, %rcx
.L543:
	movq	24(%rsp), %rsi
	cmpq	%r15, %rsi
	jnb	.L522
	movq	%r15, %rdx
	subq	%rsi, %rdx
	subq	%rdx, %rcx
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L522
.L639:
	movq	%rbp, %r8
.L532:
	movq	32(%rsp), %rax
	cmpq	%rax, %r15
	jnb	.L522
	subq	%r15, %rax
	movq	%r15, %rsi
	movq	%r8, %rdi
	movq	%rax, %rdx
	call	memcpy@PLT
	jmp	.L522
.L634:
	movq	%r13, %r10
	movq	104(%rsp), %r14
	movq	112(%rsp), %rbx
	movl	%ecx, %r8d
	movq	96(%rsp), %r13
	movq	120(%rsp), %r15
	jmp	.L549
.L566:
	movq	24(%rsp), %r15
	jmp	.L527
.L632:
	movq	$1, 56(%rsp)
	leaq	1(%rbx), %r12
	cmpq	%r12, %r15
	jne	.L553
	movl	$1, %r14d
	cmpq	$1, %r13
	jbe	.L554
.L555:
	movq	56(%rsp), %rax
	xorl	%r8d, %r8d
	leaq	-3(%rax,%rax,2), %rdx
	movq	136(%rsp,%rdx,8), %rax
	movq	128(%rsp,%rdx,8), %rdx
	leaq	(%rax,%rdx,2), %rdx
	addq	%rdx, %rax
	addq	%r14, %rax
	jmp	.L517
.L643:
	subq	%r15, %rdx
	subq	%r15, %rax
.L515:
	addq	%rdx, %rdx
	addq	%rax, %rax
.L517:
	addl	$1, %r8d
	cmpq	%r15, %rdx
	jnb	.L643
	cmpq	%r15, %rax
	jb	.L515
	cmpq	$1, 56(%rsp)
	jne	.L556
	jmp	.L549
	.p2align 4,,10
	.p2align 3
.L496:
	movl	$1, %r14d
	cmpq	$1, %r13
	ja	.L505
.L554:
	leaq	0(%r13,%rbx), %rcx
	movq	%r13, %r14
.L506:
	cmpq	%rcx, %r12
	jnb	.L505
	leaq	-8(%r10,%r12,8), %rbp
	movq	%r14, 32(%rsp)
	movq	%r12, %rdx
	movq	%rbp, %r14
	movq	%r13, 16(%rsp)
	movq	%rbx, %rbp
	movq	%rcx, 40(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r15, 64(%rsp)
	jmp	.L512
.L508:
	addq	$1, %rdx
	addq	$8, %r14
	cmpq	40(%rsp), %rdx
	jnb	.L644
.L512:
	movq	(%r14), %rsi
	movq	8(%r14), %rdi
	movq	%rdx, 8(%rsp)
	call	myl_native_text_compare@PLT
	movq	8(%rsp), %rdx
	testl	%eax, %eax
	jns	.L508
	movq	8(%r14), %r15
	movq	%r14, %r13
	movq	%rdx, %r12
	jmp	.L510
.L509:
	movq	-8(%r13), %rsi
	movq	%r15, %rdi
	subq	$8, %r13
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	jns	.L625
.L510:
	movq	0(%r13), %rax
	subq	$1, %r12
	movq	%r13, %rbx
	movq	%rax, 8(%r13)
	cmpq	%r12, %rbp
	jb	.L509
.L625:
	movq	8(%rsp), %rdx
	movq	%r15, (%rbx)
	addq	$8, %r14
	addq	$1, %rdx
	cmpq	40(%rsp), %rdx
	jb	.L512
.L644:
	movq	16(%rsp), %r13
	movq	32(%rsp), %r14
	movq	%rbp, %rbx
	movq	48(%rsp), %r10
	movq	64(%rsp), %r15
	jmp	.L505
.L629:
	movq	%r13, %rdi
	movq	%r8, 8(%rsp)
	shrq	%rdi
	salq	$3, %rdi
	call	malloc@PLT
	movq	8(%rsp), %r8
	testq	%rax, %rax
	movq	%rax, 24(%rsp)
	jne	.L492
	xorl	%eax, %eax
	jmp	.L491
	.p2align 4,,10
	.p2align 3
.L559:
	movq	$0, 24(%rsp)
	movq	%r13, %rbp
	jmp	.L492
.L633:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE84:
	.size	sort_text, .-sort_text
	.p2align 4
	.type	sort_bytes, @function
sort_bytes:
.LFB85:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r8
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$2456, %rsp
	.cfi_def_cfa_offset 2512
	movq	%fs:40, %r13
	movq	%r13, 2440(%rsp)
	movq	%rsi, %r13
	cmpq	$31, %rsi
	jbe	.L713
	movq	%r13, %rax
	xorl	%edx, %edx
.L647:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L647
	leaq	(%rdx,%rax), %rbp
	cmpq	%r13, %rbp
	jb	.L783
	movq	$0, 24(%rsp)
	movl	$32, %ebp
.L646:
	movq	$0, 56(%rsp)
	movq	%r13, %r15
	xorl	%ebx, %ebx
	movq	%r8, %r10
	movq	%rbp, %r13
.L706:
	cmpq	%r15, %rbx
	jnb	.L649
	leaq	1(%rbx), %r12
	cmpq	%r12, %r15
	je	.L650
.L707:
	movq	(%r10,%rbx,8), %rsi
	movq	8(%r10,%rbx,8), %rdi
	movq	%r10, 8(%rsp)
	call	myl_native_bytes_compare@PLT
	movq	8(%rsp), %r14
	testl	%eax, %eax
	jns	.L651
	jmp	.L655
.L652:
	movq	-8(%r14,%r12,8), %rsi
	movq	(%r14,%r12,8), %rdi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L778
.L655:
	movq	%r12, %rbp
	addq	$1, %r12
	cmpq	%r15, %r12
	jb	.L652
.L778:
	movq	%r14, %r10
	movq	%rbp, %rdx
	movq	%rbx, %rax
	cmpq	%rbp, %rbx
	jnb	.L657
.L653:
	movq	(%r10,%rax,8), %rcx
	movq	(%r10,%rdx,8), %rsi
	movq	%rsi, (%r10,%rax,8)
	addq	$1, %rax
	movq	%rcx, (%r10,%rdx,8)
	subq	$1, %rdx
	cmpq	%rdx, %rax
	jb	.L653
	subq	%rbx, %rbp
	leaq	1(%rbp), %r14
	cmpq	%r13, %r14
	jnb	.L659
.L785:
	movq	%r15, %rax
	leaq	(%r14,%rbx), %r12
	subq	%rbx, %rax
	cmpq	%r13, %rax
	jnb	.L708
	movq	%rax, %r14
	movq	%r15, %rcx
	jmp	.L660
	.p2align 4,,10
	.p2align 3
.L784:
	movq	-8(%r14,%r12,8), %rsi
	movq	(%r14,%r12,8), %rdi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	js	.L772
.L651:
	movq	%r12, %rbp
	addq	$1, %r12
	cmpq	%r15, %r12
	jb	.L784
.L772:
	movq	%r14, %r10
.L657:
	subq	%rbx, %rbp
	leaq	1(%rbp), %r14
	cmpq	%r13, %r14
	jb	.L785
.L659:
	cmpq	$0, 56(%rsp)
	jne	.L709
	movq	%rbx, 128(%rsp)
	addq	%r14, %rbx
	movq	$0, 144(%rsp)
	movq	%r14, 136(%rsp)
	cmpq	%r15, %rbx
	jb	.L786
.L705:
	movq	24(%rsp), %rdi
	call	free@PLT
	movl	$1, %eax
.L645:
	movq	2440(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L787
	addq	$2456, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L649:
	.cfi_restore_state
	cmpq	$1, 56(%rsp)
	jbe	.L705
	xorl	%r14d, %r14d
	xorl	%r8d, %r8d
.L710:
	movq	56(%rsp), %rax
	movq	%r14, 104(%rsp)
	movl	%r8d, 76(%rsp)
	leaq	(%rax,%rax,2), %rax
	movq	%rbx, 112(%rsp)
	leaq	128(%rsp,%rax,8), %rax
	movq	%r15, 120(%rsp)
	movq	%rax, 48(%rsp)
	movq	%r13, 96(%rsp)
	movq	%r10, %r13
	.p2align 4
	.p2align 3
.L702:
	movq	48(%rsp), %rax
	movl	76(%rsp), %ecx
	cmpl	-32(%rax), %ecx
	jl	.L704
	cmpq	$96, 56(%rsp)
	jne	.L788
.L704:
	movq	48(%rsp), %rcx
	subq	$1, 56(%rsp)
	xorl	%r15d, %r15d
	movq	-24(%rcx), %rax
	movq	-16(%rcx), %rdx
	movq	-48(%rcx), %r14
	leaq	0(,%rax,8), %rcx
	movq	%rdx, 64(%rsp)
	movq	%rcx, 8(%rsp)
	leaq	0(%r13,%rcx), %rbx
	movq	%rax, 16(%rsp)
	subq	%r14, %rax
	movq	%rax, %r12
	.p2align 4
	.p2align 3
.L673:
	cmpq	%r12, %r15
	jnb	.L789
.L674:
	movq	%r12, %rbp
	movq	(%rbx), %rdi
	subq	%r15, %rbp
	shrq	%rbp
	addq	%r15, %rbp
	leaq	(%r14,%rbp), %rax
	movq	0(%r13,%rax,8), %rsi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	js	.L718
	leaq	1(%rbp), %r15
	cmpq	%r12, %r15
	jb	.L674
.L789:
	movq	16(%rsp), %rax
	addq	%r15, %r14
	cmpq	%r14, %rax
	je	.L676
	leaq	-8(%r13,%rax,8), %rbp
	movq	64(%rsp), %r12
	movq	%rbx, 32(%rsp)
	xorl	%r15d, %r15d
	movq	%r13, %rbx
	movq	%rbp, %r13
	.p2align 4
	.p2align 3
.L678:
	cmpq	%r12, %r15
	jnb	.L790
.L679:
	movq	%r12, %rax
	movq	8(%rsp), %rcx
	movq	0(%r13), %rsi
	subq	%r15, %rax
	shrq	%rax
	leaq	(%rax,%r15), %rbp
	leaq	(%rbx,%rbp,8), %rax
	movq	(%rax,%rcx), %rdi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L719
	leaq	1(%rbp), %r15
	cmpq	%r12, %r15
	jb	.L679
.L790:
	movq	16(%rsp), %rcx
	leaq	0(,%r15,8), %rdx
	movq	%rbx, %r13
	leaq	0(,%r14,8), %r9
	movq	%rdx, %r10
	movq	32(%rsp), %rbx
	leaq	0(%r13,%r9), %r8
	movq	%rcx, %rax
	addq	%r15, %rcx
	shrq	$3, %r10
	subq	%r14, %rax
	leaq	0(%r13,%rcx,8), %rcx
	cmpq	%rax, %r15
	jb	.L680
	movq	24(%rsp), %r15
	leaq	0(,%rax,8), %rbp
	movq	%r8, %rsi
	movq	%r10, 40(%rsp)
	movq	%rbp, %rdx
	movq	%rcx, 16(%rsp)
	movq	%r15, %rdi
	movq	%r8, 8(%rsp)
	call	memcpy@PLT
	leaq	(%r15,%rbp), %rax
	movq	40(%rsp), %r10
	movq	8(%rsp), %r8
	movq	%rax, 32(%rsp)
	movq	%rbp, %rax
	movq	16(%rsp), %rcx
	shrq	$3, %rax
	cmpq	%r10, %rax
	cmova	%r10, %rax
	cmpq	$1, %rax
	jbe	.L720
	movq	%r13, 80(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r8, %rcx
	.p2align 4
	.p2align 3
.L685:
	movq	(%r15), %r13
	movq	(%rbx), %r12
	movq	%rcx, 8(%rsp)
	movq	%rcx, %rbp
	leaq	-8(,%rax,8), %rdi
	movq	%rdi, 16(%rsp)
	leaq	(%rcx,%rdi), %r14
	jmp	.L684
	.p2align 4,,10
	.p2align 3
.L792:
	movq	%r13, -8(%rbp)
	addq	$8, %r15
	movq	(%r15), %r13
	cmpq	%rbp, %r14
	je	.L791
.L684:
	movq	%r13, %rsi
	movq	%r12, %rdi
	addq	$8, %rbp
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L792
	movq	%r12, -8(%rbp)
	addq	$8, %rbx
	movq	(%rbx), %r12
	cmpq	%rbp, %r14
	jne	.L684
.L791:
	movq	32(%rsp), %rax
	movq	40(%rsp), %rdx
	movq	8(%rsp), %rcx
	addq	16(%rsp), %rcx
	subq	%r15, %rax
	subq	%rbx, %rdx
	shrq	$3, %rax
	shrq	$3, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	cmpq	$1, %rax
	ja	.L685
	movq	%rcx, %r8
	movq	80(%rsp), %r13
	movq	40(%rsp), %rcx
.L681:
	cmpq	%rcx, %rbx
	jnb	.L686
	cmpq	32(%rsp), %r15
	jnb	.L676
	movq	%r8, %rbp
	movq	%rcx, %r14
	jmp	.L690
	.p2align 4,,10
	.p2align 3
.L794:
	movq	%r12, -8(%rbp)
	addq	$8, %r15
	cmpq	32(%rsp), %r15
	jnb	.L676
.L782:
	cmpq	%r14, %rbx
	jnb	.L793
.L690:
	movq	(%r15), %r12
	movq	(%rbx), %rdi
	addq	$8, %rbp
	movq	%r12, %rsi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L794
	movq	(%rbx), %rax
	addq	$8, %rbx
	movq	%rax, -8(%rbp)
	cmpq	32(%rsp), %r15
	jb	.L782
	.p2align 4
	.p2align 3
.L676:
	movq	48(%rsp), %rax
	movq	64(%rsp), %rcx
	addq	%rcx, -40(%rax)
	subq	$24, %rax
	movq	%rax, 48(%rsp)
	cmpq	$1, 56(%rsp)
	jne	.L702
	movq	%r13, %r10
	movq	104(%rsp), %r14
	movl	76(%rsp), %r8d
	movq	112(%rsp), %rbx
	movq	96(%rsp), %r13
	movq	120(%rsp), %r15
.L703:
	cmpq	%r15, %rbx
	jnb	.L705
	movq	56(%rsp), %rcx
	leaq	-3(%rcx,%rcx,2), %rax
	movl	%r8d, 144(%rsp,%rax,8)
	leaq	(%rcx,%rcx,2), %rax
	movq	%rbx, 128(%rsp,%rax,8)
	addq	%r14, %rbx
	movq	$0, 144(%rsp,%rax,8)
	movq	%r14, 136(%rsp,%rax,8)
	leaq	1(%rcx), %rax
	movq	%rax, 56(%rsp)
	jmp	.L706
	.p2align 4,,10
	.p2align 3
.L718:
	movq	%rbp, %r12
	jmp	.L673
	.p2align 4,,10
	.p2align 3
.L719:
	movq	%rbp, %r12
	jmp	.L678
.L680:
	movq	24(%rsp), %r15
	movq	%rbx, %rsi
	movq	%r10, 88(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r15, %rdi
	movq	%r8, 32(%rsp)
	movq	%r9, 80(%rsp)
	movq	%rdx, 16(%rsp)
	call	memcpy@PLT
	movq	88(%rsp), %r10
	movq	8(%rsp), %rbp
	subq	80(%rsp), %rbp
	addq	16(%rsp), %r15
	shrq	$3, %rbp
	movq	%r10, %rax
	movq	32(%rsp), %r8
	movq	40(%rsp), %rcx
	cmpq	%r10, %rbp
	cmovbe	%rbp, %rax
	cmpq	$1, %rax
	jbe	.L692
	movq	%r13, 40(%rsp)
	.p2align 4
	.p2align 3
.L696:
	negq	%rax
	movq	%rcx, 8(%rsp)
	movq	-8(%rbx), %r13
	movq	%rcx, %r14
	leaq	0(,%rax,8), %rdx
	movq	-8(%r15), %r12
	movq	%rdx, 16(%rsp)
	leaq	8(%rcx,%rdx), %rbp
	jmp	.L695
	.p2align 4,,10
	.p2align 3
.L796:
	movq	%r12, (%r14)
	subq	$8, %r15
	movq	-8(%r15), %r12
	cmpq	%r14, %rbp
	je	.L795
.L695:
	movq	%r13, %rsi
	movq	%r12, %rdi
	subq	$8, %r14
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L796
	movq	%r13, (%r14)
	subq	$8, %rbx
	movq	-8(%rbx), %r13
	cmpq	%r14, %rbp
	jne	.L695
.L795:
	movq	16(%rsp), %rdx
	movq	8(%rsp), %rcx
	movq	%rbx, %rax
	subq	32(%rsp), %rax
	leaq	8(%rcx,%rdx), %rcx
	movq	%r15, %rdx
	subq	24(%rsp), %rdx
	shrq	$3, %rax
	shrq	$3, %rdx
	cmpq	%rdx, %rax
	cmova	%rdx, %rax
	cmpq	$1, %rax
	ja	.L696
	movq	32(%rsp), %r8
	movq	40(%rsp), %r13
.L692:
	cmpq	%rbx, %r8
	jnb	.L697
	cmpq	%r15, 24(%rsp)
	jnb	.L676
	movq	%r8, %r14
	movq	%rcx, %rbp
	.p2align 4
	.p2align 3
.L701:
	movq	-8(%r15), %r12
	movq	-8(%rbx), %rsi
	subq	$8, %rbp
	movq	%r12, %rdi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L698
	movq	-8(%rbx), %rdx
	leaq	-8(%rbx), %rax
	movq	%rdx, 0(%rbp)
	cmpq	%rax, %r14
	jnb	.L776
	cmpq	%r15, 24(%rsp)
	jnb	.L676
	movq	%rax, %rbx
	jmp	.L701
	.p2align 4,,10
	.p2align 3
.L698:
	movq	%r12, 0(%rbp)
	subq	$8, %r15
	cmpq	%rbx, %r14
	jnb	.L776
	cmpq	%r15, 24(%rsp)
	jb	.L701
	jmp	.L676
.L776:
	movq	%rbp, %rcx
.L697:
	movq	24(%rsp), %rsi
	cmpq	%r15, %rsi
	jnb	.L676
	movq	%r15, %rdx
	subq	%rsi, %rdx
	subq	%rdx, %rcx
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L676
.L793:
	movq	%rbp, %r8
.L686:
	movq	32(%rsp), %rax
	cmpq	%rax, %r15
	jnb	.L676
	subq	%r15, %rax
	movq	%r15, %rsi
	movq	%r8, %rdi
	movq	%rax, %rdx
	call	memcpy@PLT
	jmp	.L676
.L788:
	movq	%r13, %r10
	movq	104(%rsp), %r14
	movq	112(%rsp), %rbx
	movl	%ecx, %r8d
	movq	96(%rsp), %r13
	movq	120(%rsp), %r15
	jmp	.L703
.L720:
	movq	24(%rsp), %r15
	jmp	.L681
.L786:
	movq	$1, 56(%rsp)
	leaq	1(%rbx), %r12
	cmpq	%r12, %r15
	jne	.L707
	movl	$1, %r14d
	cmpq	$1, %r13
	jbe	.L708
.L709:
	movq	56(%rsp), %rax
	xorl	%r8d, %r8d
	leaq	-3(%rax,%rax,2), %rdx
	movq	136(%rsp,%rdx,8), %rax
	movq	128(%rsp,%rdx,8), %rdx
	leaq	(%rax,%rdx,2), %rdx
	addq	%rdx, %rax
	addq	%r14, %rax
	jmp	.L671
.L797:
	subq	%r15, %rdx
	subq	%r15, %rax
.L669:
	addq	%rdx, %rdx
	addq	%rax, %rax
.L671:
	addl	$1, %r8d
	cmpq	%r15, %rdx
	jnb	.L797
	cmpq	%r15, %rax
	jb	.L669
	cmpq	$1, 56(%rsp)
	jne	.L710
	jmp	.L703
	.p2align 4,,10
	.p2align 3
.L650:
	movl	$1, %r14d
	cmpq	$1, %r13
	ja	.L659
.L708:
	leaq	0(%r13,%rbx), %rcx
	movq	%r13, %r14
.L660:
	cmpq	%rcx, %r12
	jnb	.L659
	leaq	-8(%r10,%r12,8), %rbp
	movq	%r14, 32(%rsp)
	movq	%r12, %rdx
	movq	%rbp, %r14
	movq	%r13, 16(%rsp)
	movq	%rbx, %rbp
	movq	%rcx, 40(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r15, 64(%rsp)
	jmp	.L666
.L662:
	addq	$1, %rdx
	addq	$8, %r14
	cmpq	40(%rsp), %rdx
	jnb	.L798
.L666:
	movq	(%r14), %rsi
	movq	8(%r14), %rdi
	movq	%rdx, 8(%rsp)
	call	myl_native_bytes_compare@PLT
	movq	8(%rsp), %rdx
	testl	%eax, %eax
	jns	.L662
	movq	8(%r14), %r15
	movq	%r14, %r13
	movq	%rdx, %r12
	jmp	.L664
.L663:
	movq	-8(%r13), %rsi
	movq	%r15, %rdi
	subq	$8, %r13
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jns	.L779
.L664:
	movq	0(%r13), %rax
	subq	$1, %r12
	movq	%r13, %rbx
	movq	%rax, 8(%r13)
	cmpq	%r12, %rbp
	jb	.L663
.L779:
	movq	8(%rsp), %rdx
	movq	%r15, (%rbx)
	addq	$8, %r14
	addq	$1, %rdx
	cmpq	40(%rsp), %rdx
	jb	.L666
.L798:
	movq	16(%rsp), %r13
	movq	32(%rsp), %r14
	movq	%rbp, %rbx
	movq	48(%rsp), %r10
	movq	64(%rsp), %r15
	jmp	.L659
.L783:
	movq	%r13, %rdi
	movq	%r8, 8(%rsp)
	shrq	%rdi
	salq	$3, %rdi
	call	malloc@PLT
	movq	8(%rsp), %r8
	testq	%rax, %rax
	movq	%rax, 24(%rsp)
	jne	.L646
	xorl	%eax, %eax
	jmp	.L645
	.p2align 4,,10
	.p2align 3
.L713:
	movq	$0, 24(%rsp)
	movq	%r13, %rbp
	jmp	.L646
.L787:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE85:
	.size	sort_bytes, .-sort_bytes
	.p2align 4
	.type	rc_storage_edges, @function
rc_storage_edges:
.LFB111:
	.cfi_startproc
	endbr64
	movq	32(%rsi), %rsi
	jmp	myl_rc_edge_release@PLT
	.cfi_endproc
.LFE111:
	.size	rc_storage_edges, .-rc_storage_edges
	.p2align 4
	.type	myl_native_list_clone_at.part.0, @function
myl_native_list_clone_at.part.0:
.LFB140:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movq	%fs:40, %r12
	movq	%r12, 88(%rsp)
	movl	%ecx, %r12d
	leaq	16(%rsp), %rbp
	movq	%rsi, (%rsp)
	movq	%rsp, %rdx
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	movq	%rbp, %rsi
	call	myl_native_root_push@PLT
	movl	$1, %edx
	leaq	myl_native_list_header_descriptor(%rip), %rsi
	movq	%rbx, %rdi
	movl	%r12d, %ecx
	call	myl_native_heap_alloc_at@PLT
	movq	%rax, 8(%rsp)
	testq	%rax, %rax
	je	.L801
	leaq	8(%rsp), %rdx
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	movq	%rbx, %rdi
	leaq	48(%rsp), %rsi
	call	myl_native_root_push@PLT
	movq	(%rsp), %rdx
	movq	8(%rsp), %rcx
	movq	(%rdx), %rax
	movq	8(%rdx), %rdx
	movq	%r13, 24(%rcx)
	cmpq	%rdx, %rax
	movq	%rdx, %rdi
	cmovnb	%rax, %rdi
	orq	%rdx, %rax
	movq	%rdi, %r15
	jne	.L802
	leaq	48(%rsp), %rsi
	movq	%rbx, %rdi
	call	myl_native_root_pop@PLT
	movq	8(%rsp), %rax
.L803:
	movq	(%rsp), %rdx
	movq	%r15, %xmm1
	movq	(%rdx), %xmm0
	punpcklqdq	%xmm1, %xmm0
	movups	%xmm0, (%rax)
.L801:
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	call	myl_native_root_pop@PLT
	movq	8(%rsp), %rax
	movq	88(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L816
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L802:
	.cfi_restore_state
	movl	%r12d, %ecx
	movq	%rdi, %rdx
	movq	%r13, %rsi
	movq	%rbx, %rdi
	call	myl_native_heap_alloc_at@PLT
	movq	%rax, %rcx
	testq	%rax, %rax
	je	.L804
	movq	(%rsp), %rax
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	jne	.L817
.L804:
	movq	8(%rsp), %rax
	leaq	48(%rsp), %rsi
	movq	%rbx, %rdi
	movq	%rcx, 32(%rax)
	call	myl_native_root_pop@PLT
	movq	8(%rsp), %rax
	cmpq	$0, 32(%rax)
	jne	.L803
	movq	$0, 8(%rsp)
	jmp	.L801
	.p2align 4,,10
	.p2align 3
.L817:
	movq	24(%rax), %rsi
	movq	%rcx, %rdi
	imulq	(%rsi), %rdx
	movq	32(%rax), %rsi
	call	memcpy@PLT
	movq	%rax, %rcx
	jmp	.L804
.L816:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE140:
	.size	myl_native_list_clone_at.part.0, .-myl_native_list_clone_at.part.0
	.p2align 4
	.type	keyed_permute.isra.0, @function
keyed_permute.isra.0:
.LFB141:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.L818
	movq	%rcx, %rax
	movq	%rsi, %rbx
	movq	%rcx, %r15
	shrq	$32, %rax
	jne	.L1122
	testq	%rcx, %rcx
	je	.L818
	leaq	-1(%rcx), %rax
	cmpq	$2, %rax
	jbe	.L1045
	shrq	$2, %rcx
	xorl	%eax, %eax
	salq	$4, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L919:
	movdqu	(%r12,%rax,2), %xmm0
	movdqu	16(%r12,%rax,2), %xmm1
	shufps	$136, %xmm1, %xmm0
	movups	%xmm0, (%r12,%rax)
	addq	$16, %rax
	cmpq	%rcx, %rax
	jne	.L919
	testb	$3, %r15b
	je	.L921
	movq	%r15, %rax
	andq	$-4, %rax
.L918:
	movq	(%r12,%rax,8), %rcx
	movl	%ecx, (%r12,%rax,4)
	leaq	1(%rax), %rcx
	cmpq	%r15, %rcx
	jnb	.L921
	movq	8(%r12,%rax,8), %rcx
	movl	%ecx, 4(%r12,%rax,4)
	leaq	2(%rax), %rcx
	cmpq	%r15, %rcx
	jnb	.L921
	movq	16(%r12,%rax,8), %rcx
	movl	%ecx, 8(%r12,%rax,4)
.L921:
	movq	%r15, %rcx
	xorl	%r14d, %r14d
	leaq	.L986(%rip), %r13
	movq	%rbx, %r15
	.p2align 4
	.p2align 3
.L822:
	movl	(%r12,%r14,4), %eax
	cmpq	%r14, %rax
	je	.L923
	cmpq	$64, %rdx
	ja	.L924
	leaq	.L926(%rip), %rdi
	movslq	(%rdi,%rdx,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L926:
	.long	.L924-.L926
	.long	.L935-.L926
	.long	.L934-.L926
	.long	.L924-.L926
	.long	.L933-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L932-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L931-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L930-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L929-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L928-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L927-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L924-.L926
	.long	.L925-.L926
	.text
.L1120:
	movq	%rbx, %rdx
	movq	%r15, %r14
	movq	%r12, %rbx
	movq	8(%rsp), %r15
	movq	%r8, %r12
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	.p2align 4
	.p2align 3
.L938:
	imulq	%rdx, %rax
	movq	%rax, %rbp
	addq	%rbx, %rbp
	cmpq	$64, %rdx
	jbe	.L1123
.L962:
	movq	%r8, %rsi
	movq	%rbp, %rdi
	movq	%rcx, 16(%rsp)
	movq	%rdx, 8(%rsp)
	movq	%r8, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %r8
	movq	8(%rsp), %rdx
	movq	16(%rsp), %rcx
	.p2align 4
	.p2align 3
.L923:
	addq	$1, %r14
	addq	%rdx, %r15
	cmpq	%rcx, %r14
	jb	.L822
.L818:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1122:
	.cfi_restore_state
	movq	%rsi, %r14
	xorl	%r13d, %r13d
	cmpq	$0, (%r12)
	je	.L1124
	.p2align 4
	.p2align 3
.L823:
	cmpq	$64, %rdx
	ja	.L825
	leaq	.L827(%rip), %rcx
	movslq	(%rcx,%rdx,4), %rax
	addq	%rcx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L827:
	.long	.L825-.L827
	.long	.L836-.L827
	.long	.L835-.L827
	.long	.L825-.L827
	.long	.L834-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L833-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L832-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L831-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L830-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L829-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L828-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L825-.L827
	.long	.L826-.L827
	.text
	.p2align 4,,10
	.p2align 3
.L825:
	movq	%r8, %rdi
	movq	%r14, %rsi
	movq	%rdx, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %rdx
	movq	%rax, %r8
	.p2align 4
	.p2align 3
.L916:
	movq	(%r12,%r13,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1039
	movq	(%r12,%rax,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1039
	movq	(%r12,%rax,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1043
	movq	(%r12,%rax,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1043
	movq	(%r12,%rax,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1043
	movq	(%r12,%rax,8), %rax
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	prefetcht0	(%rbx,%rcx)
	cmpq	%r13, %rax
	je	.L1043
	movq	(%r12,%rax,8), %r9
	movq	%rdx, %rax
	imulq	%r9, %rax
	prefetcht0	(%rbx,%rax)
	cmpq	%r13, %r9
	je	.L1044
	movq	(%r12,%r9,8), %r9
	movq	%rdx, %rax
	imulq	%r9, %rax
	prefetcht0	(%rbx,%rax)
	movq	%r13, %rax
.L915:
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%r13, %rbp
	je	.L838
	movq	%r8, 16(%rsp)
	leaq	.L842(%rip), %rcx
	movq	%r14, (%rsp)
	movq	%r13, %r14
	movq	%rbp, %r13
	movq	%rdx, %rbp
	movq	%r15, 8(%rsp)
	movq	%r12, %r15
	movq	%r9, %r12
.L839:
	cmpq	%r14, %r12
	je	.L914
	movq	(%r15,%r12,8), %r12
	movq	%rbp, %rsi
	imulq	%r12, %rsi
	prefetcht0	(%rbx,%rsi)
.L914:
	movq	%rbp, %rsi
	imulq	%rbp, %rax
	movq	%rbp, %rdx
	imulq	%r13, %rsi
	leaq	(%rbx,%rax), %rdi
	addq	%rbx, %rsi
	cmpq	$64, %rbp
	jbe	.L1125
.L840:
	call	memcpy@PLT
	movq	(%r15,%r13,8), %rsi
	movq	%r13, %rax
	movq	%r13, (%r15,%r13,8)
	cmpq	%r14, %rsi
	je	.L1110
	movq	%rsi, %r13
	leaq	.L842(%rip), %rcx
	jmp	.L839
	.p2align 4,,10
	.p2align 3
.L924:
	movq	%r8, %rdi
	movq	%r15, %rsi
	movq	%rcx, 8(%rsp)
	movq	%rdx, (%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rcx
	movq	(%rsp), %rdx
	movq	%rax, %r8
	.p2align 4
	.p2align 3
.L936:
	movl	(%r12,%r14,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1047
	movl	(%r12,%rax,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1047
	movl	(%r12,%rax,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1051
	movl	(%r12,%rax,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1051
	movl	(%r12,%rax,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1051
	movl	(%r12,%rax,4), %eax
	movq	%rdx, %rsi
	imulq	%rax, %rsi
	prefetcht0	(%rbx,%rsi)
	cmpq	%r14, %rax
	je	.L1051
	movl	(%r12,%rax,4), %r9d
	movq	%rdx, %rax
	imulq	%r9, %rax
	prefetcht0	(%rbx,%rax)
	cmpq	%r14, %r9
	je	.L1052
	movl	(%r12,%r9,4), %r9d
	movq	%rdx, %rax
	imulq	%r9, %rax
	prefetcht0	(%rbx,%rax)
	movq	%r14, %rax
.L937:
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%r14, %rbp
	je	.L938
	movq	%rcx, 16(%rsp)
	movq	%r15, 8(%rsp)
	movq	%r14, %r15
	movq	%r9, %r14
	movq	%r8, 24(%rsp)
	movq	%r12, %r8
	movq	%rbx, %r12
	movq	%rdx, %rbx
.L939:
	cmpq	%r15, %r14
	je	.L961
	movl	(%r8,%r14,4), %r14d
	movq	%rbx, %rsi
	imulq	%r14, %rsi
	prefetcht0	(%r12,%rsi)
.L961:
	movq	%rbx, %rsi
	imulq	%rbx, %rax
	imulq	%rbp, %rsi
	leaq	(%r12,%rax), %rdi
	addq	%r12, %rsi
	cmpq	$64, %rbx
	jbe	.L1126
.L984:
	movq	%rbx, %rdx
	movq	%r8, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %r8
	movq	%rbp, %rax
	movl	(%r8,%rbp,4), %esi
	movl	%ebp, (%r8,%rbp,4)
	cmpq	%r15, %rsi
	je	.L1120
	movq	%rsi, %rbp
	jmp	.L939
.L1124:
	leaq	(%rsi,%rdx), %r14
	movl	$1, %r13d
	jmp	.L824
	.p2align 4,,10
	.p2align 3
.L913:
	leaq	1(%rax), %r13
	cmpq	%r13, %r15
	je	.L818
	addq	%rdx, %r14
.L824:
	movq	(%r12,%r13,8), %rax
	cmpq	%r13, %rax
	jne	.L823
	jmp	.L913
.L886:
	leaq	(%rbx,%rbp,2), %rdi
.L901:
	movzwl	(%r8), %eax
	movw	%ax, (%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L904
	addq	$2, %r14
	movq	%rax, %r13
.L835:
	movzwl	(%r14), %eax
	movw	%ax, (%r8)
	jmp	.L916
.L889:
	leaq	(%rbx,%rbp), %rdi
.L902:
	movzbl	(%r8), %eax
	movb	%al, (%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L903
	addq	$1, %r14
	movq	%rax, %r13
.L836:
	movzbl	(%r14), %eax
	movb	%al, (%r8)
	jmp	.L916
.L862:
	movq	%rbp, %rax
	salq	$6, %rax
	leaq	(%rbx,%rax), %rdi
.L892:
	movdqu	(%r8), %xmm0
	leaq	1(%r13), %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%r8), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%r8), %xmm0
	movups	%xmm0, 48(%rdi)
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L912
	addq	$64, %r14
	movq	%rax, %r13
.L826:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r14), %xmm0
	movups	%xmm0, 16(%r8)
	movdqu	32(%r14), %xmm0
	movups	%xmm0, 32(%r8)
	movdqu	48(%r14), %xmm0
	movups	%xmm0, 48(%r8)
	jmp	.L916
.L865:
	imulq	$56, %rbp, %rax
	leaq	(%rbx,%rax), %rdi
.L894:
	movdqu	(%r8), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%r8), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%r8), %rax
	movq	%rax, 48(%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L911
	addq	$56, %r14
	movq	%rax, %r13
.L828:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r14), %xmm0
	movups	%xmm0, 16(%r8)
	movdqu	32(%r14), %xmm0
	movups	%xmm0, 32(%r8)
	movq	48(%r14), %rax
	movq	%rax, 48(%r8)
	jmp	.L916
.L868:
	leaq	0(%rbp,%rbp,4), %rax
	leaq	(%rbx,%rax,8), %rdi
.L895:
	movdqu	(%r8), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%r8), %rax
	movq	%rax, 32(%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L910
	addq	$40, %r14
	movq	%rax, %r13
.L829:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r14), %xmm0
	movups	%xmm0, 16(%r8)
	movq	32(%r14), %rax
	movq	%rax, 32(%r8)
	jmp	.L916
.L871:
	movq	%rbp, %rax
	salq	$5, %rax
	leaq	(%rbx,%rax), %rdi
.L896:
	movdqu	(%r8), %xmm0
	leaq	1(%r13), %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rdi)
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L909
	addq	$32, %r14
	movq	%rax, %r13
.L830:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r14), %xmm0
	movups	%xmm0, 16(%r8)
	jmp	.L916
.L874:
	leaq	(%rcx,%rbp), %rax
	leaq	(%rbx,%rax,8), %rdi
.L897:
	movdqu	(%r8), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%r8), %rax
	movq	%rax, 16(%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L908
	addq	$24, %r14
	movq	%rax, %r13
.L831:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	movq	16(%r14), %rax
	movq	%rax, 16(%r8)
	jmp	.L916
.L877:
	movq	%rbp, %rax
	salq	$4, %rax
	leaq	(%rbx,%rax), %rdi
.L898:
	movdqu	(%r8), %xmm0
	leaq	1(%r13), %rax
	movups	%xmm0, (%rdi)
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L907
	addq	$16, %r14
	movq	%rax, %r13
.L832:
	movdqu	(%r14), %xmm0
	movups	%xmm0, (%r8)
	jmp	.L916
.L880:
	leaq	(%rbx,%rcx), %rdi
.L899:
	movq	(%r8), %rax
	movq	%rax, (%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L906
	addq	$8, %r14
	movq	%rax, %r13
.L833:
	movq	(%r14), %rax
	movq	%rax, (%r8)
	jmp	.L916
.L883:
	leaq	(%rbx,%rbp,4), %rdi
.L900:
	movl	(%r8), %eax
	movl	%eax, (%rdi)
	leaq	1(%r13), %rax
	cmpq	%rax, %r15
	je	.L818
	cmpq	(%r12,%rax,8), %rax
	je	.L905
	addq	$4, %r14
	movq	%rax, %r13
.L834:
	movl	(%r14), %eax
	movl	%eax, (%r8)
	jmp	.L916
.L1027:
	leaq	(%r10,%rbp), %rax
	leaq	(%rbx,%rax,8), %rbp
.L966:
	movdqu	(%r8), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rbp)
	movq	32(%r8), %rax
	movq	%rax, 32(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L981
	addq	$40, %r15
	movq	%rax, %r14
.L928:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r8)
	movq	32(%r15), %rax
	movq	%rax, 32(%r8)
	jmp	.L936
.L1024:
	salq	$5, %rbp
	addq	%rbx, %rbp
.L967:
	movdqu	(%r8), %xmm0
	leaq	1(%r14), %rax
	movups	%xmm0, 0(%rbp)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rbp)
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L980
	addq	$32, %r15
	movq	%rax, %r14
.L929:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r8)
	jmp	.L936
.L1021:
	addq	%rbp, %r10
	leaq	(%rbx,%r10,8), %rbp
.L968:
	movdqu	(%r8), %xmm0
	movups	%xmm0, 0(%rbp)
	movq	16(%r8), %rax
	movq	%rax, 16(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L979
	addq	$24, %r15
	movq	%rax, %r14
.L930:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	movq	16(%r15), %rax
	movq	%rax, 16(%r8)
	jmp	.L936
.L1018:
	salq	$4, %rbp
	addq	%rbx, %rbp
.L969:
	movdqu	(%r8), %xmm0
	leaq	1(%r14), %rax
	movups	%xmm0, 0(%rbp)
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L978
	addq	$16, %r15
	movq	%rax, %r14
.L931:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	jmp	.L936
.L1015:
	leaq	(%rbx,%rbp,8), %rbp
.L970:
	movq	(%r8), %rax
	movq	%rax, 0(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L977
	addq	$8, %r15
	movq	%rax, %r14
.L932:
	movq	(%r15), %rax
	movq	%rax, (%r8)
	jmp	.L936
.L1012:
	leaq	(%rbx,%r10), %rbp
.L971:
	movl	(%r8), %eax
	movl	%eax, 0(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L976
	addq	$4, %r15
	movq	%rax, %r14
.L933:
	movl	(%r15), %eax
	movl	%eax, (%r8)
	jmp	.L936
.L1009:
	leaq	(%rbx,%rbp,2), %rbp
.L972:
	movzwl	(%r8), %eax
	movw	%ax, 0(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L975
	addq	$2, %r15
	movq	%rax, %r14
.L934:
	movzwl	(%r15), %eax
	movw	%ax, (%r8)
	jmp	.L936
.L1005:
	addq	%rbx, %rbp
.L973:
	movzbl	(%r8), %eax
	movb	%al, 0(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L974
	addq	$1, %r15
	movq	%rax, %r14
.L935:
	movzbl	(%r15), %eax
	movb	%al, (%r8)
	jmp	.L936
.L1033:
	salq	$6, %rbp
	addq	%rbx, %rbp
.L963:
	movdqu	(%r8), %xmm0
	leaq	1(%r14), %rax
	movups	%xmm0, 0(%rbp)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rbp)
	movdqu	32(%r8), %xmm0
	movups	%xmm0, 32(%rbp)
	movdqu	48(%r8), %xmm0
	movups	%xmm0, 48(%rbp)
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L983
	addq	$64, %r15
	movq	%rax, %r14
.L925:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r8)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%r8)
	movdqu	48(%r15), %xmm0
	movups	%xmm0, 48(%r8)
	jmp	.L936
.L1030:
	imulq	$56, %rbp, %rbp
	addq	%rbx, %rbp
.L965:
	movdqu	(%r8), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%r8), %xmm0
	movups	%xmm0, 16(%rbp)
	movdqu	32(%r8), %xmm0
	movups	%xmm0, 32(%rbp)
	movq	48(%r8), %rax
	movq	%rax, 48(%rbp)
	leaq	1(%r14), %rax
	cmpq	%rcx, %rax
	jnb	.L818
	movl	(%r12,%rax,4), %esi
	cmpq	%rsi, %rax
	je	.L982
	addq	$56, %r15
	movq	%rax, %r14
.L927:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r8)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r8)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%r8)
	movq	48(%r15), %rax
	movq	%rax, 48(%r8)
	jmp	.L936
	.p2align 4,,10
	.p2align 3
.L1126:
	movslq	0(%r13,%rbx,4), %rax
	addq	%r13, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L986:
	.long	.L984-.L986
	.long	.L1113-.L986
	.long	.L1114-.L986
	.long	.L984-.L986
	.long	.L1058-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1115-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1116-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1059-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1117-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1060-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1118-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L984-.L986
	.long	.L1119-.L986
	.text
	.p2align 4,,10
	.p2align 3
.L1125:
	movslq	(%rcx,%rbp,4), %rax
	addq	%rcx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L842:
	.long	.L840-.L842
	.long	.L1102-.L842
	.long	.L1103-.L842
	.long	.L840-.L842
	.long	.L1104-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1056-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1105-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1057-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1106-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1107-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1108-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L840-.L842
	.long	.L1109-.L842
	.text
.L1110:
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
	movq	%rbp, %rdx
	.p2align 4
	.p2align 3
.L838:
	imulq	%rdx, %rax
	leaq	(%rbx,%rax), %rdi
	cmpq	$64, %rdx
	jbe	.L1127
.L891:
	movq	%r8, %rsi
	movq	%rdx, 8(%rsp)
	movq	%r8, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %r8
	movq	8(%rsp), %rdx
	movq	%r13, %rax
	jmp	.L913
	.p2align 4,,10
	.p2align 3
.L1127:
	leaq	.L893(%rip), %rsi
	movslq	(%rsi,%rdx,4), %rax
	addq	%rsi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L893:
	.long	.L891-.L893
	.long	.L902-.L893
	.long	.L901-.L893
	.long	.L891-.L893
	.long	.L900-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L899-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L898-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L897-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L896-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L895-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L894-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L891-.L893
	.long	.L892-.L893
	.text
	.p2align 4,,10
	.p2align 3
.L1123:
	leaq	.L964(%rip), %rdi
	movslq	(%rdi,%rdx,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L964:
	.long	.L962-.L964
	.long	.L973-.L964
	.long	.L972-.L964
	.long	.L962-.L964
	.long	.L971-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L970-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L969-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L968-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L967-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L966-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L965-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L962-.L964
	.long	.L963-.L964
	.text
.L1043:
	movq	%r13, %r9
	jmp	.L915
.L1051:
	movq	%r14, %r9
	jmp	.L937
.L1047:
	movq	%r14, %r9
	movq	%r14, %rax
	jmp	.L937
.L1039:
	movq	%r13, %r9
	movq	%r13, %rax
	jmp	.L915
.L1109:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
.L852:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%rsi), %xmm0
	movups	%xmm0, 48(%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L862
	cmpq	%r9, %r13
	je	.L863
	movq	(%r12,%r9,8), %r9
	movq	%rax, %rsi
	salq	$6, %rsi
	movq	%r9, %rcx
	addq	%rbx, %rsi
	salq	$6, %rcx
	prefetcht0	(%rbx,%rcx)
	movq	%rbp, %rcx
	movq	%rax, %rbp
	salq	$6, %rcx
	leaq	(%rbx,%rcx), %rdi
	jmp	.L852
.L1108:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
.L853:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%rsi), %rax
	movq	%rax, 48(%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L865
	cmpq	%r9, %r13
	je	.L866
	movq	(%r12,%r9,8), %r9
	imulq	$56, %rbp, %rdi
	movq	%rax, %rbp
	imulq	$56, %rax, %rsi
	imulq	$56, %r9, %rcx
	addq	%rbx, %rdi
	addq	%rbx, %rsi
	prefetcht0	(%rbx,%rcx)
	jmp	.L853
.L1107:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
.L854:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%rsi), %rax
	movq	%rax, 32(%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L868
	cmpq	%r9, %r13
	je	.L869
	movq	(%r12,%r9,8), %r9
	leaq	(%r9,%r9,4), %rcx
	prefetcht0	(%rbx,%rcx,8)
	leaq	(%rax,%rax,4), %rcx
	leaq	(%rbx,%rcx,8), %rsi
	leaq	0(%rbp,%rbp,4), %rcx
	movq	%rax, %rbp
	leaq	(%rbx,%rcx,8), %rdi
	jmp	.L854
.L1106:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
.L855:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L871
	cmpq	%r9, %r13
	je	.L872
	movq	(%r12,%r9,8), %r9
	movq	%rax, %rsi
	salq	$5, %rsi
	movq	%r9, %rcx
	addq	%rbx, %rsi
	salq	$5, %rcx
	prefetcht0	(%rbx,%rcx)
	movq	%rbp, %rcx
	movq	%rax, %rbp
	salq	$5, %rcx
	leaq	(%rbx,%rcx), %rdi
	jmp	.L855
.L1115:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
.L1002:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1015
	cmpq	%r9, %r14
	je	.L1128
	movl	(%r12,%r9,4), %edi
	movq	(%rbx,%rax,8), %rsi
	prefetcht0	(%rbx,%rdi,8)
	movq	%rsi, (%rbx,%rbp,8)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %rdi
	je	.L1129
	movl	(%r12,%rdi,4), %r9d
	leaq	(%rbx,%rbp,8), %rsi
	leaq	(%rbx,%rax,8), %rdi
	prefetcht0	(%rbx,%r9,8)
	jmp	.L1002
	.p2align 4,,10
	.p2align 3
.L1113:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
.L1007:
	movzbl	(%rsi), %eax
	movb	%al, (%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1005
	cmpq	%r9, %r14
	je	.L1130
	movl	(%r12,%r9,4), %edi
	movzbl	(%rbx,%rax), %esi
	prefetcht0	(%rbx,%rdi)
	movb	%sil, (%rbx,%rbp)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %rdi
	je	.L1131
	movl	(%r12,%rdi,4), %r9d
	leaq	(%rbx,%rbp), %rsi
	leaq	(%rbx,%rax), %rdi
	prefetcht0	(%rbx,%r9)
	jmp	.L1007
	.p2align 4,,10
	.p2align 3
.L1058:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	leaq	0(,%rbp,4), %r10
	movq	24(%rsp), %r8
.L1003:
	movl	(%rsi), %eax
	movl	%eax, (%rdi)
	movl	(%r12,%r10), %eax
	movl	%ebp, (%r12,%r10)
	cmpq	%r14, %rax
	je	.L1012
	cmpq	%r9, %r14
	je	.L1132
	movl	(%r12,%r9,4), %r9d
	movl	(%rbx,%rax,4), %esi
	leaq	0(,%rax,4), %rdi
	prefetcht0	(%rbx,%r9,4)
	movl	%esi, (%rbx,%r10)
	movl	(%r12,%rdi), %ebp
	movl	%eax, (%r12,%rdi)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %r9
	je	.L1133
	movl	(%r12,%r9,4), %r9d
	leaq	0(,%rbp,4), %r10
	addq	%rbx, %rdi
	leaq	(%rbx,%r10), %rsi
	prefetcht0	(%rbx,%r9,4)
	jmp	.L1003
	.p2align 4,,10
	.p2align 3
.L1114:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
.L1004:
	movzwl	(%rsi), %eax
	movw	%ax, (%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1009
	cmpq	%r9, %r14
	je	.L1134
	movl	(%r12,%r9,4), %edi
	movzwl	(%rbx,%rax,2), %esi
	prefetcht0	(%rbx,%rdi,2)
	movw	%si, (%rbx,%rbp,2)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %rdi
	je	.L1135
	movl	(%r12,%rdi,4), %r9d
	leaq	0(%rbp,%rbp), %rsi
	leaq	(%rax,%rax), %rdi
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	prefetcht0	(%rbx,%r9,2)
	jmp	.L1004
	.p2align 4,,10
	.p2align 3
.L872:
	movq	%rax, %rcx
	salq	$5, %rbp
	salq	$5, %rcx
	addq	%rbx, %rbp
	addq	%rbx, %rcx
	movdqu	(%rcx), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rbp)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	movq	%rbp, %rsi
	movq	%rcx, %rdi
	salq	$5, %rsi
	addq	%rbx, %rsi
	jmp	.L855
	.p2align 4,,10
	.p2align 3
.L869:
	leaq	0(%rbp,%rbp,4), %rcx
	leaq	(%rbx,%rcx,8), %rsi
	leaq	(%rax,%rax,4), %rcx
	leaq	(%rbx,%rcx,8), %rcx
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rsi)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rsi)
	movq	32(%rcx), %rdi
	movq	%rdi, 32(%rsi)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	imulq	$40, %rbp, %rsi
	movq	%rcx, %rdi
	addq	%rbx, %rsi
	jmp	.L854
	.p2align 4,,10
	.p2align 3
.L866:
	imulq	$56, %rax, %rdi
	imulq	$56, %rbp, %rcx
	addq	%rbx, %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, (%rbx,%rcx)
	movdqu	16(%rdi), %xmm0
	movups	%xmm0, 16(%rbx,%rcx)
	movdqu	32(%rdi), %xmm0
	movups	%xmm0, 32(%rbx,%rcx)
	movq	48(%rdi), %rsi
	movq	%rsi, 48(%rbx,%rcx)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	imulq	$56, %rbp, %rsi
	addq	%rbx, %rsi
	jmp	.L853
	.p2align 4,,10
	.p2align 3
.L863:
	movq	%rax, %rcx
	salq	$6, %rbp
	salq	$6, %rcx
	addq	%rbx, %rcx
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rbx,%rbp)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rbx,%rbp)
	movdqu	32(%rcx), %xmm0
	movups	%xmm0, 32(%rbx,%rbp)
	movdqu	48(%rcx), %xmm0
	movups	%xmm0, 48(%rbx,%rbp)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	movq	%rbp, %rsi
	movq	%rcx, %rdi
	salq	$6, %rsi
	addq	%rbx, %rsi
	jmp	.L852
	.p2align 4,,10
	.p2align 3
.L1130:
	leaq	(%rbx,%rbp), %rdi
	leaq	(%rbx,%rax), %rsi
	movq	%rax, %rbp
	jmp	.L1007
.L1132:
	leaq	(%rbx,%r10), %rdi
	leaq	(%rbx,%rax,4), %rsi
	movq	%rax, %rbp
	leaq	0(,%rax,4), %r10
	jmp	.L1003
.L1128:
	leaq	(%rbx,%rbp,8), %rdi
	leaq	(%rbx,%rax,8), %rsi
	movq	%rax, %rbp
	jmp	.L1002
.L1134:
	leaq	(%rbx,%rbp,2), %rdi
	leaq	(%rbx,%rax,2), %rsi
	movq	%rax, %rbp
	jmp	.L1004
.L1044:
	movq	%r13, %rax
	jmp	.L915
.L1045:
	xorl	%eax, %eax
	jmp	.L918
.L1052:
	movq	%r14, %rax
	jmp	.L937
.L903:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$2, %r14
	cmpq	%r13, %rax
	jne	.L836
	jmp	.L913
.L980:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$64, %r15
	cmpq	%rax, %r14
	jne	.L929
	jmp	.L923
.L979:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$48, %r15
	cmpq	%rax, %r14
	jne	.L930
	jmp	.L923
.L977:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$16, %r15
	cmpq	%rax, %r14
	jne	.L932
	jmp	.L923
.L983:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	subq	$-128, %r15
	cmpq	%rax, %r14
	jne	.L925
	jmp	.L923
.L974:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$2, %r15
	cmpq	%rax, %r14
	jne	.L935
	jmp	.L923
.L978:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$32, %r15
	cmpq	%rax, %r14
	jne	.L931
	jmp	.L923
.L905:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$8, %r14
	cmpq	%rax, %r13
	jne	.L834
	jmp	.L913
.L982:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$112, %r15
	cmpq	%rax, %r14
	jne	.L927
	jmp	.L923
.L911:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$112, %r14
	cmpq	%rax, %r13
	jne	.L828
	jmp	.L913
.L912:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	subq	$-128, %r14
	cmpq	%rax, %r13
	jne	.L826
	jmp	.L913
.L907:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$32, %r14
	cmpq	%rax, %r13
	jne	.L832
	jmp	.L913
.L981:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$80, %r15
	cmpq	%rax, %r14
	jne	.L928
	jmp	.L923
.L904:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$4, %r14
	cmpq	%rax, %r13
	jne	.L835
	jmp	.L913
.L908:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$48, %r14
	cmpq	%rax, %r13
	jne	.L831
	jmp	.L913
.L909:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$64, %r14
	cmpq	%rax, %r13
	jne	.L830
	jmp	.L913
.L976:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$8, %r15
	cmpq	%rax, %r14
	jne	.L933
	jmp	.L923
.L975:
	addq	$2, %r14
	cmpq	%rcx, %r14
	jnb	.L818
	movl	(%r12,%r14,4), %eax
	addq	$4, %r15
	cmpq	%rax, %r14
	jne	.L934
	jmp	.L923
.L910:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$80, %r14
	cmpq	%rax, %r13
	jne	.L829
	jmp	.L913
.L906:
	addq	$2, %r13
	cmpq	%r13, %r15
	je	.L818
	movq	(%r12,%r13,8), %rax
	addq	$16, %r14
	cmpq	%rax, %r13
	jne	.L833
	jmp	.L913
.L1131:
	leaq	(%rbx,%rbp), %rsi
	leaq	(%rbx,%rax), %rdi
	movq	%r14, %r9
	jmp	.L1007
.L1133:
	leaq	0(,%rbp,4), %r10
	addq	%rbx, %rdi
	movq	%r14, %r9
	leaq	(%rbx,%r10), %rsi
	jmp	.L1003
.L1105:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L857:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L877
	cmpq	%r9, %r13
	je	.L878
	movq	(%r12,%r9,8), %r9
	movq	%rbp, %rdi
	movq	%rax, %rsi
	movq	%rax, %rbp
	salq	$4, %rsi
	salq	$4, %rdi
	movq	%r9, %rcx
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	salq	$4, %rcx
	prefetcht0	(%rbx,%rcx)
	jmp	.L857
.L878:
	movq	%rax, %rdi
	salq	$4, %rbp
	salq	$4, %rdi
	addq	%rbx, %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, (%rbx,%rbp)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	movq	%rbp, %rsi
	salq	$4, %rsi
	addq	%rbx, %rsi
	jmp	.L857
.L1056:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	leaq	0(,%rbp,8), %rcx
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L858:
	movq	(%rsi), %rax
	movq	%rax, (%rdi)
	movq	(%r12,%rcx), %rax
	movq	%rbp, (%r12,%rcx)
	cmpq	%r13, %rax
	je	.L880
	cmpq	%r9, %r13
	je	.L881
	movq	(%r12,%r9,8), %r9
	leaq	(%rbx,%rcx), %rdi
	leaq	(%rbx,%rax,8), %rsi
	movq	%rax, %rbp
	leaq	0(,%rax,8), %rcx
	prefetcht0	(%rbx,%r9,8)
	jmp	.L858
.L881:
	movq	(%rbx,%rax,8), %rsi
	leaq	0(,%rax,8), %rdi
	movq	%rsi, (%rbx,%rcx)
	movq	(%r12,%rdi), %rbp
	movq	%rax, (%r12,%rdi)
	cmpq	%rbp, %r13
	je	.L838
	leaq	0(,%rbp,8), %rcx
	addq	%rbx, %rdi
	leaq	(%rbx,%rcx), %rsi
	jmp	.L858
.L1104:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L859:
	movl	(%rsi), %eax
	movl	%eax, (%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L883
	cmpq	%r9, %r13
	je	.L884
	movq	(%r12,%r9,8), %r9
	leaq	(%rbx,%rbp,4), %rdi
	leaq	(%rbx,%rax,4), %rsi
	movq	%rax, %rbp
	prefetcht0	(%rbx,%r9,4)
	jmp	.L859
.L884:
	movl	(%rbx,%rax,4), %ecx
	movl	%ecx, (%rbx,%rbp,4)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	leaq	(%rbx,%rbp,4), %rsi
	leaq	(%rbx,%rax,4), %rdi
	jmp	.L859
.L1103:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L860:
	movzwl	(%rsi), %eax
	movw	%ax, (%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L886
	cmpq	%r9, %r13
	je	.L887
	movq	(%r12,%r9,8), %r9
	leaq	(%rbx,%rbp,2), %rdi
	leaq	(%rbx,%rax,2), %rsi
	movq	%rax, %rbp
	prefetcht0	(%rbx,%r9,2)
	jmp	.L860
.L887:
	movzwl	(%rbx,%rax,2), %ecx
	movw	%cx, (%rbx,%rbp,2)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	leaq	(%rbx,%rbp,2), %rsi
	leaq	(%rbx,%rax,2), %rdi
	jmp	.L860
.L1102:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L861:
	movzbl	(%rsi), %eax
	movb	%al, (%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L889
	cmpq	%r9, %r13
	je	.L890
	movq	(%r12,%r9,8), %r9
	leaq	(%rbx,%rbp), %rdi
	leaq	(%rbx,%rax), %rsi
	movq	%rax, %rbp
	prefetcht0	(%rbx,%r9)
	jmp	.L861
.L890:
	movzbl	(%rbx,%rax), %ecx
	movb	%cl, (%rbx,%rbp)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	leaq	(%rbx,%rbp), %rsi
	leaq	(%rbx,%rax), %rdi
	jmp	.L861
.L1119:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	jmp	.L996
	.p2align 4,,10
	.p2align 3
.L940:
	movl	(%r12,%r9,4), %r9d
	movq	%rbp, %rsi
	salq	$6, %rsi
	movq	%r9, %rax
	addq	%rbx, %rsi
	salq	$6, %rax
	prefetcht0	(%rbx,%rax)
.L996:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%rsi), %xmm0
	movups	%xmm0, 48(%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1033
	cmpq	%r9, %r14
	je	.L1136
	movq	%rax, %rdi
	movl	(%r12,%r9,4), %r9d
	salq	$6, %rbp
	salq	$6, %rdi
	addq	%rbx, %rdi
	movq	%r9, %rsi
	movdqu	(%rdi), %xmm0
	salq	$6, %rsi
	prefetcht0	(%rbx,%rsi)
	movups	%xmm0, (%rbx,%rbp)
	movdqu	16(%rdi), %xmm0
	movups	%xmm0, 16(%rbx,%rbp)
	movdqu	32(%rdi), %xmm0
	movups	%xmm0, 32(%rbx,%rbp)
	movdqu	48(%rdi), %xmm0
	movups	%xmm0, 48(%rbx,%rbp)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%r14, %rbp
	je	.L938
	cmpq	%r14, %r9
	jne	.L940
	movq	%rbp, %rsi
	movq	%r14, %r9
	salq	$6, %rsi
	addq	%rbx, %rsi
	jmp	.L996
.L1136:
	movq	%rbp, %rdi
	movq	%rax, %rsi
	movq	%rax, %rbp
	salq	$6, %rsi
	salq	$6, %rdi
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	jmp	.L996
.L1129:
	leaq	(%rbx,%rbp,8), %rsi
	leaq	(%rbx,%rax,8), %rdi
	movq	%r14, %r9
	jmp	.L1002
.L1135:
	leaq	0(%rbp,%rbp), %rsi
	leaq	(%rax,%rax), %rdi
	movq	%r14, %r9
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	jmp	.L1004
.L1057:
	movq	%r13, %rbp
	movq	%r12, %r9
	movq	%r14, %r13
	movq	%r15, %r12
	movq	(%rsp), %r14
	movq	8(%rsp), %r15
	leaq	(%rbp,%rbp), %rcx
	movq	16(%rsp), %r8
	.p2align 4
	.p2align 3
.L856:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rdi)
	movq	(%r12,%rbp,8), %rax
	movq	%rbp, (%r12,%rbp,8)
	cmpq	%r13, %rax
	je	.L874
	cmpq	%r9, %r13
	je	.L875
	movq	(%r12,%r9,8), %r9
	addq	%rbp, %rcx
	movq	%rax, %rbp
	leaq	(%rbx,%rcx,8), %rdi
	leaq	(%rax,%rax), %rcx
	leaq	(%r9,%r9,2), %rsi
	prefetcht0	(%rbx,%rsi,8)
	leaq	(%rax,%rax,2), %rsi
	leaq	(%rbx,%rsi,8), %rsi
	jmp	.L856
.L875:
	leaq	(%rax,%rax,2), %rsi
	addq	%rbp, %rcx
	leaq	(%rbx,%rsi,8), %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, (%rbx,%rcx,8)
	movq	16(%rdi), %rsi
	movq	%rsi, 16(%rbx,%rcx,8)
	movq	(%r12,%rax,8), %rbp
	movq	%rax, (%r12,%rax,8)
	cmpq	%rbp, %r13
	je	.L838
	leaq	(%rbp,%rbp), %rcx
	leaq	(%rcx,%rbp), %rax
	leaq	(%rbx,%rax,8), %rsi
	jmp	.L856
.L1116:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	jmp	.L1001
	.p2align 4,,10
	.p2align 3
.L950:
	movl	(%r12,%r9,4), %r9d
	movq	%rbp, %rsi
	salq	$4, %rsi
	movq	%r9, %rax
	addq	%rbx, %rsi
	salq	$4, %rax
	prefetcht0	(%rbx,%rax)
.L1001:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1018
	cmpq	%r9, %r14
	je	.L1137
	movq	%rax, %rdi
	movl	(%r12,%r9,4), %r9d
	salq	$4, %rbp
	salq	$4, %rdi
	addq	%rbx, %rdi
	movq	%r9, %rsi
	movdqu	(%rdi), %xmm0
	salq	$4, %rsi
	prefetcht0	(%rbx,%rsi)
	movups	%xmm0, (%rbx,%rbp)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %r9
	jne	.L950
	movq	%rbp, %rsi
	movq	%r14, %r9
	salq	$4, %rsi
	addq	%rbx, %rsi
	jmp	.L1001
.L1137:
	movq	%rbp, %rdi
	movq	%rax, %rsi
	movq	%rax, %rbp
	salq	$4, %rsi
	salq	$4, %rdi
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	jmp	.L1001
.L1118:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	jmp	.L997
	.p2align 4,,10
	.p2align 3
.L942:
	movl	(%r12,%r9,4), %r9d
	imulq	$56, %rbp, %rsi
	imulq	$56, %r9, %rax
	addq	%rbx, %rsi
	prefetcht0	(%rbx,%rax)
.L997:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%rsi), %rax
	movq	%rax, 48(%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1030
	cmpq	%r9, %r14
	je	.L1138
	movl	(%r12,%r9,4), %r9d
	imulq	$56, %rax, %rdi
	imulq	$56, %r9, %rsi
	addq	%rbx, %rdi
	movdqu	(%rdi), %xmm0
	prefetcht0	(%rbx,%rsi)
	imulq	$56, %rbp, %rsi
	movups	%xmm0, (%rbx,%rsi)
	movdqu	16(%rdi), %xmm0
	movups	%xmm0, 16(%rbx,%rsi)
	movdqu	32(%rdi), %xmm0
	movups	%xmm0, 32(%rbx,%rsi)
	movq	48(%rdi), %r11
	movq	%r11, 48(%rbx,%rsi)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%r14, %rbp
	je	.L938
	cmpq	%r14, %r9
	jne	.L942
	imulq	$56, %rbp, %rsi
	movq	%r14, %r9
	addq	%rbx, %rsi
	jmp	.L997
.L1138:
	imulq	$56, %rbp, %rdi
	movq	%rax, %rbp
	imulq	$56, %rax, %rsi
	addq	%rbx, %rdi
	addq	%rbx, %rsi
	jmp	.L997
.L1060:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	leaq	0(,%rbp,4), %r10
	movq	24(%rsp), %r8
	jmp	.L998
	.p2align 4,,10
	.p2align 3
.L944:
	movl	(%r12,%r9,4), %r9d
	leaq	0(,%rbp,4), %r10
	leaq	(%r9,%r9,4), %rax
	prefetcht0	(%rbx,%rax,8)
	leaq	(%r10,%rbp), %rax
	leaq	(%rbx,%rax,8), %rsi
.L998:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%rsi), %rax
	movq	%rax, 32(%rdi)
	movl	(%r12,%r10), %eax
	movl	%ebp, (%r12,%r10)
	cmpq	%r14, %rax
	je	.L1027
	cmpq	%r9, %r14
	je	.L1139
	movl	(%r12,%r9,4), %r9d
	addq	%rbp, %r10
	leaq	(%r9,%r9,4), %rsi
	prefetcht0	(%rbx,%rsi,8)
	leaq	0(,%rax,4), %rsi
	leaq	(%rsi,%rax), %rdi
	leaq	(%rbx,%rdi,8), %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, (%rbx,%r10,8)
	movdqu	16(%rdi), %xmm0
	movups	%xmm0, 16(%rbx,%r10,8)
	movq	32(%rdi), %rbp
	movq	%rbp, 32(%rbx,%r10,8)
	movl	(%r12,%rsi), %ebp
	movl	%eax, (%r12,%rsi)
	cmpq	%r14, %rbp
	je	.L938
	cmpq	%r14, %r9
	jne	.L944
	leaq	0(,%rbp,4), %r10
	movq	%r14, %r9
	leaq	(%r10,%rbp), %rax
	leaq	(%rbx,%rax,8), %rsi
	jmp	.L998
.L1139:
	addq	%rbp, %r10
	leaq	(%rax,%rax,4), %rsi
	movq	%rax, %rbp
	leaq	(%rbx,%r10,8), %rdi
	leaq	(%rbx,%rsi,8), %rsi
	leaq	0(,%rax,4), %r10
	jmp	.L998
.L1117:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	movq	24(%rsp), %r8
	jmp	.L999
	.p2align 4,,10
	.p2align 3
.L946:
	movl	(%r12,%rsi,4), %r9d
	movq	%rbp, %rsi
	salq	$5, %rsi
	movq	%r9, %rax
	addq	%rbx, %rsi
	salq	$5, %rax
	prefetcht0	(%rbx,%rax)
.L999:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1024
	cmpq	%r9, %r14
	je	.L1140
	movl	(%r12,%r9,4), %esi
	salq	$5, %rbp
	addq	%rbx, %rbp
	movq	%rsi, %rdi
	salq	$5, %rdi
	prefetcht0	(%rbx,%rdi)
	movq	%rax, %rdi
	salq	$5, %rdi
	addq	%rbx, %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rdi), %xmm0
	movups	%xmm0, 16(%rbp)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %rsi
	jne	.L946
	movq	%rbp, %rsi
	movq	%r14, %r9
	salq	$5, %rsi
	addq	%rbx, %rsi
	jmp	.L999
.L1140:
	movq	%rbp, %rdi
	movq	%rax, %rsi
	movq	%rax, %rbp
	salq	$5, %rsi
	salq	$5, %rdi
	addq	%rbx, %rsi
	addq	%rbx, %rdi
	jmp	.L999
.L1059:
	movq	%rbx, %rdx
	movq	%r14, %r9
	movq	%r12, %rbx
	movq	%r15, %r14
	movq	%r8, %r12
	movq	8(%rsp), %r15
	movq	16(%rsp), %rcx
	leaq	(%rbp,%rbp), %r10
	movq	24(%rsp), %r8
	jmp	.L1000
	.p2align 4,,10
	.p2align 3
.L948:
	movl	(%r12,%rsi,4), %r9d
	leaq	(%rbp,%rbp), %r10
	leaq	(%r9,%r9,2), %rax
	prefetcht0	(%rbx,%rax,8)
	leaq	(%r10,%rbp), %rax
	leaq	(%rbx,%rax,8), %rsi
.L1000:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rdi)
	movl	(%r12,%rbp,4), %eax
	movl	%ebp, (%r12,%rbp,4)
	cmpq	%r14, %rax
	je	.L1021
	cmpq	%r9, %r14
	je	.L1141
	movl	(%r12,%r9,4), %esi
	addq	%r10, %rbp
	leaq	(%rsi,%rsi,2), %rdi
	prefetcht0	(%rbx,%rdi,8)
	leaq	(%rax,%rax,2), %rdi
	leaq	(%rbx,%rdi,8), %rdi
	movdqu	(%rdi), %xmm0
	movups	%xmm0, (%rbx,%rbp,8)
	movq	16(%rdi), %r10
	movq	%r10, 16(%rbx,%rbp,8)
	movl	(%r12,%rax,4), %ebp
	movl	%eax, (%r12,%rax,4)
	cmpq	%rbp, %r14
	je	.L938
	cmpq	%r14, %rsi
	jne	.L948
	leaq	(%rbp,%rbp), %r10
	movq	%r14, %r9
	leaq	(%r10,%rbp), %rax
	leaq	(%rbx,%rax,8), %rsi
	jmp	.L1000
.L1141:
	addq	%r10, %rbp
	leaq	(%rax,%rax,2), %rsi
	leaq	(%rax,%rax), %r10
	leaq	(%rbx,%rbp,8), %rdi
	leaq	(%rbx,%rsi,8), %rsi
	movq	%rax, %rbp
	jmp	.L1000
	.cfi_endproc
.LFE141:
	.size	keyed_permute.isra.0, .-keyed_permute.isra.0
	.p2align 4
	.type	keyed_place, @function
keyed_place:
.LFB92:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	(%rdi), %rax
	movq	8(%rdi), %rsi
	cmpq	%rsi, %rax
	je	.L1176
	movq	%rdi, 8(%rsp)
	movq	%rdx, %r12
	testq	%rdx, %rdx
	je	.L1144
	movq	24(%rsi), %rdx
	movq	32(%rax), %rcx
	movq	32(%rsi), %r14
	movq	(%rdx), %r13
	cmpq	$1, %r13
	je	.L1160
	cmpq	$2, %r13
	je	.L1146
	leaq	(%rbx,%r12,8), %r15
	leaq	-4(%r13), %rbp
.L1158:
	movq	(%rbx), %rsi
	imulq	%r13, %rsi
	addq	%r14, %rsi
	cmpq	$60, %rbp
	ja	.L1147
	leaq	.L1149(%rip), %rdi
	movslq	(%rdi,%rbp,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1149:
	.long	.L1156-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1155-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1154-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1153-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1152-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1151-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1150-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1147-.L1149
	.long	.L1148-.L1149
	.text
	.p2align 4,,10
	.p2align 3
.L1147:
	movq	%rcx, %rdi
	movq	%r13, %rdx
	addq	$8, %rbx
	call	memcpy@PLT
	leaq	(%rax,%r13), %rcx
	cmpq	%r15, %rbx
	jne	.L1158
.L1157:
	movq	8(%rsp), %rax
	movq	(%rax), %rax
.L1144:
	addq	$1, 16(%rax)
	movq	%r12, (%rax)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L1177:
	.cfi_restore_state
	movq	(%rbx), %rax
	addq	$8, %rcx
	leaq	(%r14,%rax,4), %rsi
.L1156:
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	leaq	8(%rbx), %rax
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	movl	(%r14,%rax,4), %eax
	movl	%eax, 4(%rcx)
	cmpq	%rbx, %r15
	jne	.L1177
	jmp	.L1157
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L1178:
	movq	(%rbx), %rax
	addq	$16, %rcx
	leaq	(%r14,%rax,8), %rsi
.L1155:
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	leaq	8(%rbx), %rax
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	movq	(%r14,%rax,8), %rax
	movq	%rax, 8(%rcx)
	cmpq	%rbx, %r15
	jne	.L1178
	jmp	.L1157
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L1179:
	movq	(%rbx), %rsi
	addq	$32, %rcx
	salq	$4, %rsi
	addq	%r14, %rsi
.L1154:
	movdqu	(%rsi), %xmm0
	leaq	8(%rbx), %rax
	movups	%xmm0, (%rcx)
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	salq	$4, %rax
	movdqu	(%r14,%rax), %xmm0
	movups	%xmm0, 16(%rcx)
	cmpq	%rbx, %r15
	jne	.L1179
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1180:
	movq	(%rbx), %rax
	addq	$48, %rcx
	leaq	(%rax,%rax,2), %rax
	leaq	(%r14,%rax,8), %rsi
.L1153:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	leaq	8(%rbx), %rax
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	leaq	(%rax,%rax,2), %rax
	leaq	(%r14,%rax,8), %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, 24(%rcx)
	movq	16(%rax), %rax
	movq	%rax, 40(%rcx)
	cmpq	%rbx, %r15
	jne	.L1180
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1181:
	movq	(%rbx), %rsi
	addq	$64, %rcx
	salq	$5, %rsi
	addq	%r14, %rsi
.L1152:
	movdqu	(%rsi), %xmm0
	leaq	8(%rbx), %rax
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	salq	$5, %rax
	addq	%r14, %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, 32(%rcx)
	movdqu	16(%rax), %xmm0
	movups	%xmm0, 48(%rcx)
	cmpq	%rbx, %r15
	jne	.L1181
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1182:
	movq	(%rbx), %rax
	addq	$80, %rcx
	leaq	(%rax,%rax,4), %rax
	leaq	(%r14,%rax,8), %rsi
.L1151:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movq	32(%rsi), %rax
	movq	%rax, 32(%rcx)
	leaq	8(%rbx), %rax
	cmpq	%rax, %r15
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	leaq	(%rax,%rax,4), %rax
	leaq	(%r14,%rax,8), %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, 40(%rcx)
	movdqu	16(%rax), %xmm0
	movups	%xmm0, 56(%rcx)
	movq	32(%rax), %rax
	movq	%rax, 72(%rcx)
	cmpq	%rbx, %r15
	jne	.L1182
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1183:
	imulq	$56, (%rbx), %rsi
	addq	$112, %rcx
	addq	%r14, %rsi
.L1150:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rcx)
	movq	48(%rsi), %rax
	movq	%rax, 48(%rcx)
	leaq	8(%rbx), %rax
	cmpq	%rax, %r15
	je	.L1157
	imulq	$56, 8(%rbx), %rax
	addq	$16, %rbx
	addq	%r14, %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, 56(%rcx)
	movdqu	16(%rax), %xmm0
	movups	%xmm0, 72(%rcx)
	movdqu	32(%rax), %xmm0
	movups	%xmm0, 88(%rcx)
	movq	48(%rax), %rax
	movq	%rax, 104(%rcx)
	cmpq	%rbx, %r15
	jne	.L1183
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1184:
	movq	(%rbx), %rsi
	subq	$-128, %rcx
	salq	$6, %rsi
	addq	%r14, %rsi
.L1148:
	movdqu	(%rsi), %xmm0
	leaq	8(%rbx), %rax
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rcx)
	movdqu	48(%rsi), %xmm0
	movups	%xmm0, 48(%rcx)
	cmpq	%r15, %rax
	je	.L1157
	movq	8(%rbx), %rax
	addq	$16, %rbx
	salq	$6, %rax
	addq	%r14, %rax
	movdqu	(%rax), %xmm0
	movups	%xmm0, 64(%rcx)
	movdqu	16(%rax), %xmm0
	movups	%xmm0, 80(%rcx)
	movdqu	32(%rax), %xmm0
	movups	%xmm0, 96(%rcx)
	movdqu	48(%rax), %xmm0
	movups	%xmm0, 112(%rcx)
	cmpq	%rbx, %r15
	jne	.L1184
	jmp	.L1157
	.p2align 4,,10
	.p2align 3
.L1176:
	movq	32(%rax), %rsi
	movq	24(%rax), %rax
	movq	%rdx, %rcx
	movq	%rbx, %rdx
	movq	16(%rdi), %r8
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	movq	%rax, %rdi
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	keyed_permute.isra.0
.L1160:
	.cfi_restore_state
	xorl	%eax, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1145:
	movq	(%rbx,%rax,8), %rdx
	movzbl	(%r14,%rdx), %edx
	movb	%dl, (%rcx,%rax)
	addq	$1, %rax
	cmpq	%rax, %r12
	jne	.L1145
	jmp	.L1157
.L1146:
	leaq	(%rbx,%r12,8), %rdx
	.p2align 5
	.p2align 4
	.p2align 3
.L1159:
	movq	(%rbx), %rax
	addq	$8, %rbx
	addq	$2, %rcx
	movzwl	(%r14,%rax,2), %eax
	movw	%ax, -2(%rcx)
	cmpq	%rdx, %rbx
	jne	.L1159
	jmp	.L1157
	.cfi_endproc
.LFE92:
	.size	keyed_place, .-keyed_place
	.p2align 4
	.type	keyed_sort_entries, @function
keyed_sort_entries:
.LFB97:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$200, %rsp
	.cfi_def_cfa_offset 256
	movq	%rdi, 136(%rsp)
	movl	%ecx, 76(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 184(%rsp)
	movq	8(%rdi), %rax
	movq	(%rax), %r15
	movq	%r15, %rax
	shrq	$59, %rax
	je	.L1186
.L1188:
	xorl	%eax, %eax
.L1185:
	movq	184(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L1403
	addq	$200, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L1186:
	.cfi_restore_state
	movq	24(%rsi), %rax
	movq	%r15, %r14
	movq	%rsi, %rbp
	movq	%rdx, %r12
	salq	$5, %r14
	movq	(%rax), %rax
	movq	%r14, %rdi
	movq	%rax, 80(%rsp)
	call	malloc@PLT
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L1188
	testq	%r15, %r15
	je	.L1189
	movq	32(%rbp), %r13
	cmpl	$1, (%r12)
	je	.L1190
	cmpq	$1, %r15
	je	.L1313
	movq	%rax, %rdx
	movq	%r15, %rax
	pxor	%xmm2, %xmm2
	movl	$2, %ecx
	shrq	%rax
	movq	%rcx, %xmm1
	movdqa	.LC0(%rip), %xmm0
	salq	$5, %rax
	punpcklqdq	%xmm1, %xmm1
	addq	%rbx, %rax
.L1192:
	movdqa	%xmm0, %xmm3
	movhlps	%xmm0, %xmm4
	paddq	%xmm1, %xmm0
	addq	$32, %rdx
	pslldq	$8, %xmm3
	movups	%xmm3, -32(%rdx)
	movdqa	%xmm2, %xmm3
	punpcklqdq	%xmm4, %xmm3
	movups	%xmm3, -16(%rdx)
	cmpq	%rdx, %rax
	jne	.L1192
	testb	$1, %r15b
	je	.L1196
	movq	%r15, %rdx
	andq	$-2, %rdx
.L1191:
	movq	%rdx, %rax
	salq	$4, %rax
	movq	%rdx, 8(%rbx,%rax)
	movq	$0, (%rbx,%rax)
.L1196:
	movabsq	$-9223372036854775808, %rbp
	xorl	%r14d, %r14d
.L1199:
	movq	%r14, %rcx
	movq	%r15, %rax
	movq	%r14, 32(%rsp)
	movq	%r15, %rsi
	subq	%rcx, %rax
	addq	$16, %r14
	cmpq	$15, %rax
	cmova	%r14, %rsi
	addq	$1, %rcx
	cmpq	%rsi, %rcx
	jnb	.L1244
	movq	%r15, 56(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%r14, 88(%rsp)
.L1198:
	movq	%rcx, %rdx
	movq	%rcx, 40(%rsp)
	salq	$4, %rdx
	movq	%rbx, 48(%rsp)
	movdqu	(%rbx,%rdx), %xmm0
	leaq	(%rdx,%rbx), %r15
	movq	%rcx, %rdx
	movaps	%xmm0, 160(%rsp)
.L1243:
	movl	76(%rsp), %ecx
	movq	%r15, %r10
	subq	$16, %r15
	movq	%r15, 16(%rsp)
	testl	%ecx, %ecx
	jne	.L1315
	movl	(%r12), %eax
	movq	%r15, %rcx
	leaq	160(%rsp), %rsi
	cmpl	$1, %eax
	je	.L1404
.L1202:
	testl	%eax, %eax
	je	.L1405
.L1205:
	movq	80(%rsp), %rax
	movq	8(%rsi), %r9
	movq	%r13, %rbx
	movq	%rdx, (%rsp)
	movq	%r15, 24(%rsp)
	movq	%r12, %r13
	xorl	%r12d, %r12d
	imulq	%rax, %r9
	movq	%r10, 8(%rsp)
	imulq	8(%rcx), %rax
	movq	%r9, %r14
	movq	%rax, %r15
	jmp	.L1240
	.p2align 4,,10
	.p2align 3
.L1213:
	movzbl	12(%r13,%r12), %esi
	testl	%r8d, %r8d
	je	.L1406
	cmpb	$2, %sil
	je	.L1237
	cmpb	$4, %sil
	je	.L1238
	cmpb	$1, %sil
	jne	.L1239
	movzbl	(%rdi), %esi
	movzbl	(%rax), %eax
	.p2align 4
	.p2align 3
.L1228:
	cmpq	%rax, %rsi
	jb	.L1393
.L1226:
	cmpq	%rsi, %rax
	setb	%al
	movzbl	%al, %eax
.L1210:
	testl	%eax, %eax
	jne	.L1407
.L1212:
	addq	$1, %r12
	cmpl	0(%r13), %r12d
	jnb	.L1408
.L1240:
	movzbl	20(%r13,%r12), %eax
	leaq	(%rax,%r14), %rsi
	addq	%r15, %rax
	leaq	(%rbx,%rsi), %rdi
	movzbl	4(%r13,%r12), %esi
	addq	%rbx, %rax
	cmpb	$3, %sil
	je	.L1409
	cmpb	$4, %sil
	je	.L1410
	movzbl	%sil, %r8d
	cmpb	$2, %sil
	jne	.L1213
	movq	(%rdi), %rsi
	movq	(%rax), %rdi
	movq	%rsi, %xmm1
	movq	%rdi, %xmm0
	ucomisd	%xmm1, %xmm1
	jp	.L1214
	pxor	%xmm2, %xmm2
	ucomisd	%xmm2, %xmm1
	jp	.L1328
	je	.L1316
.L1328:
	testq	%rsi, %rsi
	jns	.L1215
	ucomisd	%xmm0, %xmm0
	jp	.L1393
	pxor	%xmm1, %xmm1
	notq	%rsi
	ucomisd	%xmm1, %xmm0
	jp	.L1220
	je	.L1218
.L1220:
	movq	%rdi, %rax
	testq	%rdi, %rdi
	jns	.L1225
	notq	%rax
	cmpq	%rax, %rsi
	jnb	.L1226
.L1393:
	movq	%r13, %r12
	movq	8(%rsp), %r10
	movq	(%rsp), %rdx
	movq	%rbx, %r13
	movq	24(%rsp), %r15
	jmp	.L1241
.L1397:
	movq	%r15, %r14
	movq	128(%rsp), %r15
.L1300:
	leaq	0(,%r15,8), %rdx
	leaq	8(%r14), %rax
	leaq	(%rbx,%rdx), %rcx
	cmpq	%rcx, %rax
	jnb	.L1332
	movq	%r15, %rcx
	salq	$4, %rcx
	addq	%r14, %rcx
	cmpq	%rcx, %rbx
	jb	.L1301
.L1332:
	movq	%r15, %rdx
	xorl	%eax, %eax
	shrq	%rdx
	salq	$4, %rdx
.L1303:
	movq	8(%r14,%rax,2), %xmm0
	movhps	24(%r14,%rax,2), %xmm0
	movups	%xmm0, (%rbx,%rax)
	addq	$16, %rax
	cmpq	%rax, %rdx
	jne	.L1303
	testb	$1, %r15b
	je	.L1189
	movq	%r15, %rax
	andq	$-2, %rax
	movq	%rax, %rdx
	salq	$4, %rdx
	movq	8(%r14,%rdx), %rdx
	movq	%rdx, (%rbx,%rax,8)
.L1189:
	movq	136(%rsp), %rdi
	movq	%r15, %rdx
	movq	%rbx, %rsi
	call	keyed_place
	movq	%rbx, %rdi
	call	free@PLT
	movl	$1, %eax
	jmp	.L1185
	.p2align 4,,10
	.p2align 3
.L1406:
	cmpb	$2, %sil
	je	.L1233
	cmpb	$4, %sil
	je	.L1234
	cmpb	$1, %sil
	jne	.L1235
	movsbq	(%rdi), %rsi
	movsbq	(%rax), %rax
	xorq	%rbp, %rsi
.L1236:
	xorq	%rbp, %rax
	jmp	.L1228
.L1316:
	xorl	%esi, %esi
.L1215:
	orq	%rbp, %rsi
	ucomisd	%xmm0, %xmm0
	jp	.L1222
	pxor	%xmm1, %xmm1
	ucomisd	%xmm1, %xmm0
	jp	.L1224
	je	.L1218
.L1224:
	movq	%rdi, %rax
	testq	%rdi, %rdi
	jns	.L1225
	notq	%rax
	jmp	.L1226
.L1218:
	xorl	%eax, %eax
.L1225:
	orq	%rbp, %rax
	jmp	.L1228
.L1239:
	movq	(%rdi), %rsi
	movq	(%rax), %rax
	jmp	.L1228
.L1409:
	movq	(%rax), %rsi
	movq	(%rdi), %rdi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	js	.L1393
	setne	%al
	movzbl	%al, %eax
	jmp	.L1210
.L1410:
	movq	(%rax), %rsi
	movq	(%rdi), %rdi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	je	.L1212
	movq	8(%rsp), %r10
	movq	24(%rsp), %r15
	movq	%r13, %r12
	shrl	$31, %eax
	movq	(%rsp), %rdx
	movq	%rbx, %r13
.L1206:
	testl	%eax, %eax
	je	.L1319
.L1241:
	movdqu	-16(%r10), %xmm0
	subq	$1, %rdx
	movups	%xmm0, (%r10)
	cmpq	%rdx, 32(%rsp)
	jb	.L1243
	movq	40(%rsp), %rcx
	movq	48(%rsp), %rbx
	movq	16(%rsp), %rax
.L1207:
	movdqa	160(%rsp), %xmm0
	addq	$1, %rcx
	movups	%xmm0, (%rax)
	cmpq	64(%rsp), %rcx
	jb	.L1198
	movq	56(%rsp), %r15
	movq	88(%rsp), %r14
.L1244:
	cmpq	%r15, %r14
	jb	.L1199
	cmpq	$16, %r15
	jbe	.L1245
	movq	%r15, %rax
	movq	%rbx, 56(%rsp)
	movabsq	$-9223372036854775808, %rbp
	movq	$16, 112(%rsp)
	salq	$4, %rax
	movq	%r15, 128(%rsp)
	movq	128(%rsp), %r14
	leaq	(%rbx,%rax), %r15
	movq	%r13, 144(%rsp)
	movq	%r12, %r13
.L1246:
	movq	112(%rsp), %rax
	movq	%rbx, 152(%rsp)
	xorl	%r12d, %r12d
	movq	144(%rsp), %rbx
	movq	%rax, %r11
	movq	%rax, 120(%rsp)
	addq	%rax, %rax
	movq	%rax, 112(%rsp)
	movq	%r11, 40(%rsp)
	.p2align 4
	.p2align 3
.L1296:
	movq	%r14, %rax
	movq	120(%rsp), %rcx
	subq	%r12, %rax
	cmpq	%rcx, %rax
	jb	.L1247
	movq	40(%rsp), %rdi
	movq	%r14, %rax
	subq	%rdi, %rax
	cmpq	%rcx, %rax
	jb	.L1320
	leaq	(%rdi,%rcx), %rax
	movq	%rdi, %r11
	movq	%rax, 32(%rsp)
.L1248:
	cmpq	%r11, %r12
	jnb	.L1321
	cmpq	32(%rsp), %r11
	jnb	.L1321
	movq	%r12, %r9
	movq	%r14, 88(%rsp)
	movq	%r12, %r10
	salq	$4, %r9
	movq	%r12, 64(%rsp)
	movq	%r12, 96(%rsp)
	addq	%r15, %r9
	movq	%r15, 104(%rsp)
	jmp	.L1291
	.p2align 4,,10
	.p2align 3
.L1263:
	movzbl	12(%r15,%r13), %eax
	testl	%r10d, %r10d
	je	.L1411
	cmpb	$2, %al
	je	.L1281
	cmpb	$4, %al
	je	.L1282
	cmpb	$1, %al
	jne	.L1283
	movzbl	(%rsi), %eax
	movzbl	(%rdx), %edx
	.p2align 4
	.p2align 3
.L1284:
	cmpq	%rdx, %rax
	jb	.L1395
.L1273:
	cmpq	%rax, %rdx
	setb	%al
	movzbl	%al, %eax
.L1259:
	testl	%eax, %eax
	je	.L1386
.L1398:
	movq	48(%rsp), %rcx
	movq	(%rsp), %r9
	movq	%r15, %r13
	movq	8(%rsp), %r11
	movq	16(%rsp), %r10
.L1256:
	movdqu	(%rcx), %xmm0
	addq	$1, %r10
	addq	$16, %r9
	movups	%xmm0, -16(%r9)
	cmpq	40(%rsp), %r10
	jnb	.L1396
.L1416:
	cmpq	32(%rsp), %r11
	jnb	.L1412
.L1291:
	movq	56(%rsp), %rdi
	movq	%r11, %rax
	movq	%r10, %rcx
	addq	$1, 64(%rsp)
	salq	$4, %rax
	salq	$4, %rcx
	leaq	(%rdi,%rax), %r8
	movl	76(%rsp), %eax
	addq	%rdi, %rcx
	testl	%eax, %eax
	jne	.L1322
	movl	0(%r13), %edi
	movq	%r8, %rdx
	movq	%rcx, %rax
	cmpl	$1, %edi
	je	.L1413
.L1251:
	testl	%edi, %edi
	je	.L1256
.L1254:
	movq	80(%rsp), %rsi
	movq	8(%rdx), %r14
	movq	%r9, (%rsp)
	movq	%r13, %r15
	movq	%rcx, 48(%rsp)
	xorl	%r13d, %r13d
	imulq	%rsi, %r14
	movq	%r8, 24(%rsp)
	imulq	8(%rax), %rsi
	movq	%r11, 8(%rsp)
	movq	%r10, 16(%rsp)
	movq	%rsi, %r12
	.p2align 4
	.p2align 3
.L1289:
	movzbl	20(%r15,%r13), %edx
	movzbl	4(%r15,%r13), %eax
	leaq	(%r14,%rdx), %rsi
	addq	%r12, %rdx
	addq	%rbx, %rsi
	addq	%rbx, %rdx
	cmpb	$3, %al
	je	.L1414
	cmpb	$4, %al
	je	.L1415
	movzbl	%al, %r10d
	cmpb	$2, %al
	jne	.L1263
	movq	(%rsi), %rax
	movq	(%rdx), %rsi
	movq	%rax, %xmm0
	movq	%rsi, %xmm1
	ucomisd	%xmm0, %xmm0
	jp	.L1264
	pxor	%xmm2, %xmm2
	ucomisd	%xmm2, %xmm0
	jp	.L1329
	je	.L1323
.L1329:
	testq	%rax, %rax
	jns	.L1265
	ucomisd	%xmm1, %xmm1
	jp	.L1395
	pxor	%xmm0, %xmm0
	notq	%rax
	ucomisd	%xmm0, %xmm1
	jp	.L1331
	je	.L1270
.L1331:
	movq	%rsi, %rdx
	testq	%rsi, %rsi
	jns	.L1272
	notq	%rsi
	movq	%rsi, %rdx
	cmpq	%rdx, %rax
	jnb	.L1273
	.p2align 4
	.p2align 3
.L1395:
	movq	24(%rsp), %r8
	movq	(%rsp), %r9
	movq	%r15, %r13
	movq	8(%rsp), %r11
	movq	16(%rsp), %r10
.L1288:
	movdqu	(%r8), %xmm0
	addq	$1, %r11
	addq	$16, %r9
	movups	%xmm0, -16(%r9)
	cmpq	40(%rsp), %r10
	jb	.L1416
.L1396:
	movq	88(%rsp), %r14
	movq	64(%rsp), %rdi
	movq	96(%rsp), %r12
	movq	104(%rsp), %r15
	cmpq	32(%rsp), %r11
	jb	.L1295
	.p2align 4
	.p2align 3
.L1299:
	movq	112(%rsp), %rax
	addq	%rax, 40(%rsp)
	addq	%rax, %r12
	cmpq	%r14, %r12
	jb	.L1296
	movq	56(%rsp), %rax
	movq	152(%rsp), %rbx
	movq	%r15, 56(%rsp)
	movq	128(%rsp), %rdi
	cmpq	%rdi, 112(%rsp)
	jnb	.L1397
	movq	%rax, %r15
	movq	%rdi, %r14
	jmp	.L1246
.L1237:
	movzwl	(%rdi), %esi
	movzwl	(%rax), %eax
	jmp	.L1228
.L1238:
	movl	(%rdi), %esi
	movl	(%rax), %eax
	jmp	.L1228
.L1315:
	movl	(%r12), %eax
	movq	%r15, %rsi
	leaq	160(%rsp), %rcx
	cmpl	$1, %eax
	jne	.L1202
.L1404:
	movzbl	4(%r12), %eax
	cmpb	$3, %al
	je	.L1203
	cmpb	$4, %al
	jne	.L1205
	movq	(%rcx), %rax
	movq	(%rsi), %rdi
	movq	%r10, 8(%rsp)
	movq	%rdx, (%rsp)
	movq	%rax, %rsi
	call	myl_native_bytes_compare@PLT
	movq	(%rsp), %rdx
	movq	8(%rsp), %r10
	shrl	$31, %eax
	jmp	.L1206
.L1408:
	movq	(%rsp), %r8
	movq	%r13, %r12
	movq	%rbx, %r13
	movq	48(%rsp), %rbx
	movq	40(%rsp), %rcx
	salq	$4, %r8
	leaq	(%rbx,%r8), %rax
	movq	%rax, 16(%rsp)
	jmp	.L1207
.L1235:
	movq	(%rdi), %rsi
	movq	(%rax), %rax
	xorq	%rbp, %rsi
	jmp	.L1236
.L1234:
	movslq	(%rdi), %rsi
	movslq	(%rax), %rax
	xorq	%rbp, %rsi
	jmp	.L1236
.L1233:
	movswq	(%rdi), %rsi
	movswq	(%rax), %rax
	xorq	%rbp, %rsi
	jmp	.L1236
	.p2align 4,,10
	.p2align 3
.L1411:
	cmpb	$2, %al
	je	.L1277
	cmpb	$4, %al
	je	.L1278
	cmpb	$1, %al
	jne	.L1279
	movsbq	(%rsi), %rax
	movsbq	(%rdx), %rdx
	xorq	%rbp, %rax
.L1280:
	xorq	%rbp, %rdx
	jmp	.L1284
	.p2align 4,,10
	.p2align 3
.L1323:
	xorl	%eax, %eax
.L1265:
	orq	%rbp, %rax
	ucomisd	%xmm1, %xmm1
	jp	.L1269
	pxor	%xmm0, %xmm0
	ucomisd	%xmm0, %xmm1
	jp	.L1330
	je	.L1270
.L1330:
	movq	%rsi, %rdx
	testq	%rsi, %rsi
	jns	.L1272
	notq	%rsi
	movq	%rsi, %rdx
	jmp	.L1273
	.p2align 4,,10
	.p2align 3
.L1270:
	xorl	%edx, %edx
.L1272:
	orq	%rbp, %rdx
	jmp	.L1284
	.p2align 4,,10
	.p2align 3
.L1283:
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	jmp	.L1284
	.p2align 4,,10
	.p2align 3
.L1414:
	movq	(%rdx), %rax
	movq	(%rsi), %rdi
	movq	%rax, %rsi
	call	myl_native_text_compare@PLT
	testl	%eax, %eax
	js	.L1395
	setne	%al
	movzbl	%al, %eax
	jmp	.L1259
	.p2align 4,,10
	.p2align 3
.L1415:
	movq	(%rdx), %rax
	movq	(%rsi), %rdi
	movq	%rax, %rsi
	call	myl_native_bytes_compare@PLT
	testl	%eax, %eax
	jne	.L1417
.L1386:
	movl	(%r15), %edi
.L1275:
	addq	$1, %r13
	cmpl	%edi, %r13d
	jb	.L1289
	jmp	.L1398
	.p2align 4,,10
	.p2align 3
.L1282:
	movl	(%rsi), %eax
	movl	(%rdx), %edx
	jmp	.L1284
	.p2align 4,,10
	.p2align 3
.L1281:
	movzwl	(%rsi), %eax
	movzwl	(%rdx), %edx
	jmp	.L1284
	.p2align 4,,10
	.p2align 3
.L1322:
	movl	0(%r13), %edi
	movq	%rcx, %rdx
	movq	%r8, %rax
	cmpl	$1, %edi
	jne	.L1251
.L1413:
	movzbl	4(%r13), %esi
	cmpb	$3, %sil
	je	.L1252
	cmpb	$4, %sil
	jne	.L1254
	movq	(%rax), %rsi
	movq	(%rdx), %rdi
	movq	%r10, 48(%rsp)
	movq	%r11, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	movq	%rcx, (%rsp)
	call	myl_native_bytes_compare@PLT
.L1402:
	shrl	$31, %eax
	movq	(%rsp), %rcx
	movq	8(%rsp), %r8
	movq	16(%rsp), %r9
	movq	24(%rsp), %r11
	movq	48(%rsp), %r10
	testl	%eax, %eax
	jne	.L1288
	jmp	.L1256
	.p2align 4,,10
	.p2align 3
.L1278:
	movslq	(%rsi), %rax
	movslq	(%rdx), %rdx
	xorq	%rbp, %rax
	jmp	.L1280
	.p2align 4,,10
	.p2align 3
.L1277:
	movswq	(%rsi), %rax
	movswq	(%rdx), %rdx
	xorq	%rbp, %rax
	jmp	.L1280
	.p2align 4,,10
	.p2align 3
.L1279:
	movq	(%rsi), %rax
	movq	(%rdx), %rdx
	xorq	%rbp, %rax
	jmp	.L1280
	.p2align 4,,10
	.p2align 3
.L1264:
	ucomisd	%xmm1, %xmm1
	jp	.L1275
	pxor	%xmm0, %xmm0
	ucomisd	%xmm0, %xmm1
	jp	.L1333
	movq	$-1, %rax
	je	.L1270
.L1333:
	movq	%rsi, %rdx
	testq	%rsi, %rsi
	jns	.L1326
	notq	%rdx
	movq	$-1, %rax
	jmp	.L1273
	.p2align 4,,10
	.p2align 3
.L1269:
	cmpq	$-1, %rax
	je	.L1275
	jmp	.L1395
	.p2align 4,,10
	.p2align 3
.L1247:
	cmpq	%r14, %r12
	jnb	.L1299
	movq	%r14, 32(%rsp)
	movq	%r14, %r11
	movq	%r12, %r10
	movq	%r12, %rdi
	movq	%r14, %r8
.L1310:
	movq	%r8, %rsi
	movq	%rdi, %rdx
	movq	%r10, %rcx
	xorl	%eax, %eax
	salq	$4, %rdx
	subq	%r10, %rsi
	salq	$4, %rcx
	addq	56(%rsp), %rcx
	salq	$4, %rsi
	addq	%r15, %rdx
	.p2align 5
	.p2align 4
	.p2align 3
.L1294:
	movdqu	(%rcx,%rax), %xmm0
	movups	%xmm0, (%rdx,%rax)
	addq	$16, %rax
	cmpq	%rax, %rsi
	jne	.L1294
	addq	%r8, %rdi
	subq	%r10, %rdi
.L1293:
	cmpq	32(%rsp), %r11
	jnb	.L1299
.L1295:
	movq	32(%rsp), %rdx
	movq	56(%rsp), %rax
	salq	$4, %rdi
	leaq	(%r15,%rdi), %rsi
	subq	%r11, %rdx
	salq	$4, %r11
	leaq	(%rax,%r11), %rcx
	salq	$4, %rdx
	xorl	%eax, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1298:
	movdqu	(%rcx,%rax), %xmm0
	movups	%xmm0, (%rsi,%rax)
	addq	$16, %rax
	cmpq	%rdx, %rax
	jne	.L1298
	jmp	.L1299
.L1412:
	movq	88(%rsp), %r14
	movq	64(%rsp), %rdi
	movq	96(%rsp), %r12
	movq	104(%rsp), %r15
.L1249:
	movq	40(%rsp), %r8
	cmpq	%r8, %r10
	jb	.L1310
	jmp	.L1293
	.p2align 4,,10
	.p2align 3
.L1252:
	movq	(%rax), %rsi
	movq	(%rdx), %rdi
	movq	%r10, 48(%rsp)
	movq	%r11, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	movq	%rcx, (%rsp)
	call	myl_native_text_compare@PLT
	jmp	.L1402
.L1326:
	movq	$-1, %rax
	orq	%rbp, %rdx
	jmp	.L1284
.L1214:
	ucomisd	%xmm0, %xmm0
	jp	.L1212
	pxor	%xmm1, %xmm1
	ucomisd	%xmm1, %xmm0
	jp	.L1231
	movq	$-1, %rsi
	je	.L1218
.L1231:
	movq	%rdi, %rax
	testq	%rdi, %rdi
	jns	.L1317
	notq	%rax
	movq	$-1, %rsi
	jmp	.L1226
.L1222:
	cmpq	$-1, %rsi
	je	.L1212
	jmp	.L1393
	.p2align 4,,10
	.p2align 3
.L1405:
	movq	48(%rsp), %rbx
	movq	%rdx, %r8
	movq	40(%rsp), %rcx
	salq	$4, %r8
	leaq	(%rbx,%r8), %rax
	movq	%rax, 16(%rsp)
	jmp	.L1207
.L1203:
	movq	(%rcx), %rax
	movq	(%rsi), %rdi
	movq	%r10, 8(%rsp)
	movq	%rdx, (%rsp)
	movq	%rax, %rsi
	call	myl_native_text_compare@PLT
	movq	(%rsp), %rdx
	movq	8(%rsp), %r10
	shrl	$31, %eax
	jmp	.L1206
.L1317:
	movq	$-1, %rsi
	orq	%rbp, %rax
	jmp	.L1228
.L1190:
	movq	%rax, (%rsp)
	movq	%rax, %rdi
	xorl	%ebp, %ebp
	xorl	%ebx, %ebx
	jmp	.L1195
.L1194:
	addq	$1, %rbp
	addq	$16, %rdi
	addq	80(%rsp), %rbx
	cmpq	%rbp, %r15
	je	.L1418
.L1195:
	movzbl	4(%r12), %eax
	movq	%rbp, 8(%rdi)
	movq	$0, (%rdi)
	subl	$3, %eax
	cmpb	$1, %al
	ja	.L1194
	movq	%rbp, %rax
	salq	$4, %rax
	cmpq	%rax, %r14
	movq	%rax, %rsi
	cmovnb	%r14, %rsi
	movq	%rsi, %rdx
	subq	%rax, %rdx
	cmpq	%rdx, %r14
	movq	%rdx, %rcx
	cmovnb	%r14, %rcx
	subq	%rsi, %rax
	movzbl	20(%r12), %esi
	addq	%rcx, %rax
	cmovc	%rcx, %rax
	subq	%rcx, %rdx
	addq	%rbx, %rsi
	addq	%r13, %rsi
	leaq	(%rax,%rdx), %rcx
	movl	$8, %edx
	call	__memcpy_chk@PLT
	movq	%rax, %rdi
	jmp	.L1194
.L1418:
	movq	(%rsp), %rbx
	jmp	.L1196
.L1245:
	leaq	-1(%r15), %rax
	movq	%rbx, %r14
	cmpq	$7, %rax
	ja	.L1300
	leaq	0(,%r15,8), %rdx
	leaq	8(%rbx), %rax
.L1301:
	movq	%rbx, %rcx
	addq	%rbx, %rdx
.L1306:
	movq	(%rax), %rsi
	addq	$8, %rcx
	addq	$16, %rax
	movq	%rsi, -8(%rcx)
	cmpq	%rcx, %rdx
	jne	.L1306
	jmp	.L1189
.L1313:
	xorl	%edx, %edx
	jmp	.L1191
.L1320:
	movq	%r14, 32(%rsp)
	movq	%rdi, %r11
	jmp	.L1248
.L1321:
	movq	40(%rsp), %r11
	movq	%r12, %r10
	movq	%r12, %rdi
	jmp	.L1249
.L1417:
	movq	48(%rsp), %rcx
	movq	24(%rsp), %r8
	movq	%r15, %r13
	movq	(%rsp), %r9
	movq	8(%rsp), %r11
	movq	16(%rsp), %r10
	js	.L1288
	jmp	.L1256
.L1403:
	call	__stack_chk_fail@PLT
	.p2align 4,,10
	.p2align 3
.L1407:
	movq	8(%rsp), %r15
	movq	%r13, %r12
	movq	40(%rsp), %rcx
	movq	%rbx, %r13
	movq	48(%rsp), %rbx
	movq	%r15, 16(%rsp)
	movq	%r15, %rax
	jmp	.L1207
.L1319:
	movq	%r10, 16(%rsp)
	movq	40(%rsp), %rcx
	movq	%r10, %rax
	movq	48(%rsp), %rbx
	jmp	.L1207
	.cfi_endproc
.LFE97:
	.size	keyed_sort_entries, .-keyed_sort_entries
	.section	.text.unlikely,"ax",@progbits
.LCOLDB3:
	.text
.LHOTB3:
	.p2align 4
	.type	rc_elements_release, @function
rc_elements_release:
.LFB109:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdx, %r8
	movq	5640(%rdi), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L1420
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L1420
	movq	8(%rax), %rsi
.L1421:
	testq	%rsi, %rsi
	je	.L1428
	movl	64(%rsi), %eax
	testl	%eax, %eax
	jne	.L1423
	cmpb	$0, 69(%rsi)
	je	.L1430
.L1425:
	movq	8(%rsi), %rax
	cmpq	$2, 40(%rax)
	ja	.L1431
	movq	%r8, %rdx
	movq	%rax, %rsi
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	jmp	myl_rc_registered_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1423:
	.cfi_restore_state
	cmpl	$16, %eax
	jbe	.L1425
	movq	8(%rsi), %rax
	movq	%r8, %rdx
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	movq	%rax, %rsi
	jmp	myl_rc_registered_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1431:
	.cfi_restore_state
	movq	%r8, %rdx
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	jmp	myl_rc_flat_edges_release@PLT
	.p2align 4,,10
	.p2align 3
.L1430:
	.cfi_restore_state
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_elements_release.cold, @function
rc_elements_release.cold:
.LFSB109:
.L1420:
	.cfi_def_cfa_offset 48
	movq	%rcx, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rdi, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %rdi
	movq	16(%rsp), %r8
	movq	24(%rsp), %rcx
	movq	%rax, %rsi
	jmp	.L1421
.L1428:
	call	abort@PLT
	.cfi_endproc
.LFE109:
	.text
	.size	rc_elements_release, .-rc_elements_release
	.section	.text.unlikely
	.size	rc_elements_release.cold, .-rc_elements_release.cold
.LCOLDE3:
	.text
.LHOTE3:
	.section	.text.unlikely
.LCOLDB4:
	.text
.LHOTB4:
	.p2align 4
	.type	rc_list_next, @function
rc_list_next:
.LFB114:
	.cfi_startproc
	endbr64
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movq	%rsi, %r10
	movq	%rdx, %r11
	movq	24(%rsi), %rsi
	movq	5640(%rdi), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L1433
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L1433
	movq	8(%rax), %rsi
.L1434:
	testq	%rsi, %rsi
	je	.L1443
	movq	(%rcx), %rax
	xorl	%edx, %edx
	cmpq	(%r10), %rax
	jnb	.L1432
	movq	8(%rsi), %rsi
	movl	8(%rsi), %edi
	testl	%edi, %edi
	je	.L1432
	leaq	1(%rax), %rdi
	movq	%rsi, %xmm0
	pxor	%xmm1, %xmm1
	movq	%rdi, (%rcx)
	movq	24(%r10), %rcx
	movabsq	$4611686018427387904, %rdi
	imulq	(%rcx), %rax
	movq	32(%r11), %rcx
	addq	%rax, %rcx
	movq	%rcx, %xmm2
	movq	-16(%r11), %rcx
	punpcklqdq	%xmm2, %xmm0
	shrq	$40, %rcx
	andl	$1048575, %ecx
	testq	%rdi, -16(%r11)
	movups	%xmm0, (%r8)
	movq	%rsi, %xmm0
	cmove	%edx, %ecx
	movups	%xmm1, 16(%r8)
	addq	32(%r10), %rax
	movq	%rax, %xmm3
	movq	%r11, 16(%r8)
	movl	%ecx, 24(%r8)
	movq	-16(%r10), %rcx
	punpcklqdq	%xmm3, %xmm0
	movups	%xmm1, 16(%r9)
	movq	%rcx, %rax
	movq	%r10, 16(%r9)
	shrq	$40, %rax
	movups	%xmm0, (%r9)
	andl	$1048575, %eax
	testq	%rdi, %rcx
	cmove	%edx, %eax
	movl	$1, %edx
	movl	%eax, 24(%r9)
.L1432:
	movl	%edx, %eax
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_next.cold, @function
rc_list_next.cold:
.LFSB114:
.L1443:
	.cfi_def_cfa_offset 64
	call	abort@PLT
.L1433:
	movq	%r9, 40(%rsp)
	movq	%r8, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%r11, 16(%rsp)
	movq	%r10, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %r10
	movq	16(%rsp), %r11
	movq	24(%rsp), %rcx
	movq	32(%rsp), %r8
	movq	%rax, %rsi
	movq	40(%rsp), %r9
	jmp	.L1434
	.cfi_endproc
.LFE114:
	.text
	.size	rc_list_next, .-rc_list_next
	.section	.text.unlikely
	.size	rc_list_next.cold, .-rc_list_next.cold
.LCOLDE4:
	.text
.LHOTE4:
	.section	.text.unlikely
.LCOLDB5:
	.text
.LHOTB5:
	.p2align 4
	.type	rc_list_span, @function
rc_list_span:
.LFB115:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%rsi, %r10
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	movq	24(%rsi), %rsi
	movq	5640(%rdi), %rbx
	movq	(%rcx), %r11
	movl	52(%rsi), %eax
	cmpq	160(%rbx), %rax
	jnb	.L1446
	salq	$4, %rax
	addq	152(%rbx), %rax
	cmpq	(%rax), %rsi
	jne	.L1446
	movq	8(%rax), %rdi
.L1447:
	testq	%rdi, %rdi
	je	.L1456
	movq	(%rcx), %rax
	xorl	%esi, %esi
	cmpq	(%r10), %rax
	jnb	.L1445
	movq	8(%rdi), %rdi
	movl	8(%rdi), %ebx
	testl	%ebx, %ebx
	je	.L1445
	leaq	1(%rax), %rbx
	movq	%rdi, %xmm0
	pxor	%xmm1, %xmm1
	movabsq	$4611686018427387904, %r14
	movq	%rbx, (%rcx)
	movq	24(%r10), %rbx
	imulq	(%rbx), %rax
	movq	32(%rdx), %rbx
	addq	%rax, %rbx
	movq	%rbx, %xmm2
	movq	-16(%rdx), %rbx
	punpcklqdq	%xmm2, %xmm0
	shrq	$40, %rbx
	andl	$1048575, %ebx
	testq	%r14, -16(%rdx)
	movups	%xmm0, (%r8)
	movq	%rdi, %xmm0
	movups	%xmm1, 16(%r8)
	cmove	%esi, %ebx
	addq	32(%r10), %rax
	movq	%rdx, 16(%r8)
	movq	-16(%r10), %rdx
	movq	%rax, %xmm3
	punpcklqdq	%xmm3, %xmm0
	movl	%ebx, 24(%r8)
	movq	%rdx, %rax
	movups	%xmm1, 16(%r9)
	shrq	$40, %rax
	movups	%xmm0, (%r9)
	andl	$1048575, %eax
	testq	%r14, %rdx
	movq	80(%rsp), %rdx
	movq	%r10, 16(%r9)
	cmove	%esi, %eax
	movl	$1, %esi
	movl	%eax, 24(%r9)
	movq	(%r10), %rax
	subq	%r11, %rax
	movq	%rax, (%rdx)
	movq	(%r10), %rax
	movq	%rax, (%rcx)
.L1445:
	addq	$56, %rsp
	.cfi_def_cfa_offset 24
	movl	%esi, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_span.cold, @function
rc_list_span.cold:
.LFSB115:
.L1456:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -24
	.cfi_offset 14, -16
	call	abort@PLT
.L1446:
	movq	%r9, 40(%rsp)
	movq	%r8, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%r10, 8(%rsp)
	movq	%r11, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rsp), %r11
	movq	8(%rsp), %r10
	movq	16(%rsp), %rdx
	movq	24(%rsp), %rcx
	movq	%rax, %rdi
	movq	32(%rsp), %r8
	movq	40(%rsp), %r9
	jmp	.L1447
	.cfi_endproc
.LFE115:
	.text
	.size	rc_list_span, .-rc_list_span
	.section	.text.unlikely
	.size	rc_list_span.cold, .-rc_list_span.cold
.LCOLDE5:
	.text
.LHOTE5:
	.section	.text.unlikely
.LCOLDB6:
	.text
.LHOTB6:
	.p2align 4
	.type	rc_list_edges, @function
rc_list_edges:
.LFB110:
	.cfi_startproc
	endbr64
	movq	%rsi, %r8
	cmpq	$0, (%rsi)
	jne	.L1470
.L1467:
	movq	32(%r8), %rsi
	jmp	myl_rc_edge_release@PLT
	.p2align 4,,10
	.p2align 3
.L1470:
	movq	5640(%rdi), %rcx
	movq	24(%rsi), %rdx
	cmpq	272(%rcx), %rdx
	je	.L1467
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movl	52(%rdx), %eax
	cmpq	160(%rcx), %rax
	jnb	.L1460
	salq	$4, %rax
	addq	152(%rcx), %rax
	cmpq	(%rax), %rdx
	jne	.L1460
	movq	8(%rax), %rax
.L1461:
	testq	%rax, %rax
	je	.L1462
	movl	64(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L1462
	cmpb	$0, 69(%rax)
	jne	.L1462
	movq	5640(%rdi), %rax
	movq	32(%r8), %rsi
	movq	%rdx, 272(%rax)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	jmp	myl_rc_edge_release@PLT
	.p2align 4,,10
	.p2align 3
.L1462:
	.cfi_restore_state
	movq	24(%r8), %rsi
	movq	(%r8), %rcx
	movq	%r8, 16(%rsp)
	movq	32(%r8), %rdx
	movq	%rdi, 8(%rsp)
	call	rc_elements_release
	movq	16(%rsp), %r8
	movq	8(%rsp), %rdi
	movq	32(%r8), %rsi
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	jmp	myl_rc_edge_release@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_edges.cold, @function
rc_list_edges.cold:
.LFSB110:
.L1460:
	.cfi_def_cfa_offset 48
	movq	%rdx, %rsi
	movq	%r8, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%rdi, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %rdi
	movq	16(%rsp), %rdx
	movq	24(%rsp), %r8
	jmp	.L1461
	.cfi_endproc
.LFE110:
	.text
	.size	rc_list_edges, .-rc_list_edges
	.section	.text.unlikely
	.size	rc_list_edges.cold, .-rc_list_edges.cold
.LCOLDE6:
	.text
.LHOTE6:
	.section	.text.unlikely
.LCOLDB7:
	.text
.LHOTB7:
	.p2align 4
	.type	rc_list_shell, @function
rc_list_shell:
.LFB113:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rcx, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdi, %r14
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	5640(%rdi), %rax
	movq	(%rsi), %r13
	movq	8(%rsi), %rbp
	movq	24(%rsi), %r12
	movl	%edx, (%rsp)
	cmpq	272(%rax), %r12
	je	.L1472
	movq	%r12, %rsi
	call	myl_rc_native_shape@PLT
	testq	%rax, %rax
	je	.L1474
	movq	5640(%r14), %rax
.L1472:
	cmpb	$0, 288(%rax)
	je	.L1497
.L1475:
	movl	(%rsp), %ecx
	movl	$1, %edx
	leaq	myl_native_list_header_descriptor(%rip), %rsi
	movq	%r14, %rdi
	call	myl_rc_storage_alloc@PLT
	movq	%rax, %r9
	testq	%rax, %rax
	je	.L1474
	cmpq	%rbp, %r13
	movq	%rbp, %rdx
	movq	%r12, 24(%rax)
	cmovnb	%r13, %rdx
	orq	%r13, %rbp
	jne	.L1498
.L1477:
	movq	%rdx, 8(%r9)
	movq	%r9, (%r15)
	movq	24(%rbx), %rsi
	movq	5640(%r14), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L1499
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L1479
	movq	8(%rax), %rax
.L1480:
	testq	%rax, %rax
	je	.L1495
	movq	(%rbx), %r8
	testq	%r8, %r8
	jne	.L1500
.L1482:
	movq	%r8, (%r9)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1497:
	.cfi_restore_state
	leaq	rc_list_module(%rip), %rsi
	movq	%r14, %rdi
	call	myl_rc_module_register@PLT
	testl	%eax, %eax
	je	.L1476
	movl	%eax, %esi
	movq	%r14, %rdi
	call	myl_rc_record_failure@PLT
.L1474:
	movq	$0, (%r15)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r14, %rdi
	xorl	%esi, %esi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	myl_rc_native_result@PLT
	.p2align 4,,10
	.p2align 3
.L1498:
	.cfi_restore_state
	movl	(%rsp), %ecx
	movq	%r12, %rsi
	movq	%r14, %rdi
	movq	%rdx, (%rsp)
	movq	%rax, 8(%rsp)
	call	myl_rc_native_storage@PLT
	movq	8(%rsp), %r9
	movq	(%rsp), %rdx
	testq	%rax, %rax
	movq	%rax, 32(%r9)
	jne	.L1477
	movq	%r9, %rsi
	movq	%r14, %rdi
	call	myl_rc_native_abort@PLT
	jmp	.L1474
	.p2align 4,,10
	.p2align 3
.L1500:
	movq	32(%r9), %rdx
	movq	32(%rbx), %rcx
	movq	%r14, %rdi
	movq	%r9, (%rsp)
	movq	8(%rax), %rsi
	call	myl_rc_value_seed@PLT
	movq	(%rbx), %r8
	movq	(%rsp), %r9
	jmp	.L1482
	.p2align 4,,10
	.p2align 3
.L1476:
	movq	5640(%r14), %rax
	movb	$1, 288(%rax)
	jmp	.L1475
.L1499:
	jmp	.L1479
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_shell.cold, @function
rc_list_shell.cold:
.LFSB113:
.L1479:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	%r14, %rdi
	movq	%r9, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rsp), %r9
	jmp	.L1480
.L1495:
	call	abort@PLT
	.cfi_endproc
.LFE113:
	.text
	.size	rc_list_shell, .-rc_list_shell
	.section	.text.unlikely
	.size	rc_list_shell.cold, .-rc_list_shell.cold
.LCOLDE7:
	.text
.LHOTE7:
	.p2align 4
	.type	keyed_sort_words, @function
keyed_sort_words:
.LFB98:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %rax
	movq	%rsi, %r9
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movl	%ecx, %r13d
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%r13, %r8
	negq	%r13
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movq	8(%rax), %r10
	movq	24(%rsi), %rax
	movq	%rdi, 24(%rsp)
	movq	%rdx, %rdi
	movq	32(%rsi), %rsi
	movq	(%rax), %r14
	movq	(%r10), %rbx
	movzbl	20(%rdi), %eax
	movzbl	4(%rdx), %edx
	movq	%rsi, 16(%rsp)
	movzbl	12(%rdi), %r15d
	movb	%al, (%rsp)
	testq	%rbx, %rbx
	je	.L1798
	addq	%rsi, %rax
	movq	%rax, 80(%rsp)
	cmpl	$2, %edx
	je	.L1503
	testl	%edx, %edx
	je	.L1504
	cmpb	$1, %r15b
	je	.L1505
	cmpb	$2, %r15b
	je	.L1506
	movq	%rax, %rsi
	movq	$-1, %r12
	xorl	%eax, %eax
	xorl	%r11d, %r11d
	cmpb	$4, %r15b
	je	.L1508
.L1507:
	movq	(%rsi), %rcx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %r11
	addq	%r14, %rsi
	cmpq	%r11, %rbx
	jne	.L1507
	.p2align 4
	.p2align 3
.L1509:
	movq	%rbx, %rsi
	subq	%r12, %rax
	shrq	$32, %rsi
	je	.L2019
.L1502:
	movl	$1, %ecx
	jmp	.L1691
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1693:
	addl	$1, %ecx
	cmpl	$63, %ecx
	je	.L2020
.L1691:
	movl	$1, %r11d
	salq	%cl, %r11
	cmpq	%rbx, %r11
	jb	.L1693
	movl	%ecx, %ebp
	negl	%ecx
	subq	$1, %r11
	shrq	%cl, %rax
	testq	%rax, %rax
	je	.L1796
	cmpl	$32, %ebp
	ja	.L1797
	leaq	0(,%rbx,8), %rax
	movq	%r11, 48(%rsp)
	movq	%rax, %rdi
	movl	%edx, 32(%rsp)
	movq	%rax, 80(%rsp)
	call	malloc@PLT
	movq	80(%rsp), %rdi
	movq	%rax, %r12
	call	malloc@PLT
	movq	%rax, %r8
	testq	%r12, %r12
	je	.L1739
	testq	%rax, %rax
	je	.L1739
	testq	%rbx, %rbx
	movl	32(%rsp), %edx
	movq	48(%rsp), %r11
	je	.L2021
	movzbl	(%rsp), %r9d
	cmpl	$2, %edx
	je	.L1742
	testl	%edx, %edx
	je	.L1743
	cmpb	$1, %r15b
	je	.L1744
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	leaq	(%rax,%r9), %rsi
	jmp	.L1748
	.p2align 4,,10
	.p2align 3
.L2023:
	movq	(%rsi), %rax
.L1747:
	xorl	%r13d, %eax
	addq	%r14, %rsi
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r12,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L2022
.L1748:
	cmpb	$2, %r15b
	je	.L1745
	cmpb	$4, %r15b
	jne	.L2023
	movl	(%rsi), %eax
	jmp	.L1747
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L1508:
	movl	(%rsi), %ecx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %r11
	addq	%r14, %rsi
	cmpq	%r11, %rbx
	jne	.L1508
	jmp	.L1509
	.p2align 4,,10
	.p2align 3
.L2020:
	shrq	%rax
	movl	%ecx, %ebp
	jne	.L1797
	movabsq	$9223372036854775807, %r11
.L1796:
	cmpq	$8, %r14
	jne	.L1695
	cmpb	$0, (%rsp)
	jne	.L1695
	movq	24(%rsp), %rax
	cmpq	%r9, (%rax)
	je	.L1695
	movl	$1, 80(%rsp)
	movq	16(%rsp), %r8
	cmpq	%r9, %r10
	je	.L1695
.L1696:
	testq	%r8, %r8
	je	.L1526
	testq	%rbx, %rbx
	je	.L1699
	movzbl	(%rsp), %r10d
	cmpl	$2, %edx
	je	.L1700
	testl	%edx, %edx
	je	.L1701
	cmpb	$1, %r15b
	je	.L1702
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	addq	%rax, %r10
	jmp	.L1706
	.p2align 4,,10
	.p2align 3
.L2024:
	cmpb	$4, %r15b
	je	.L1704
	movq	(%r10), %rax
.L1705:
	xorq	%r13, %rax
	addq	%r14, %r10
	subq	%r12, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L1707
.L1706:
	cmpb	$2, %r15b
	jne	.L2024
	movzwl	(%r10), %eax
	jmp	.L1705
	.p2align 4,,10
	.p2align 3
.L1695:
	leaq	0(,%rbx,8), %rdi
	movq	%r11, 48(%rsp)
	movl	%edx, 32(%rsp)
	call	malloc@PLT
	movq	48(%rsp), %r11
	movl	32(%rsp), %edx
	movl	$0, 80(%rsp)
	movq	%rax, %r8
	jmp	.L1696
	.p2align 4,,10
	.p2align 3
.L2019:
	cmpq	%rbx, %rax
	jnb	.L1502
	leaq	1(%rax), %r8
	movl	$4, %esi
	movq	%r9, 88(%rsp)
	movq	%r8, %rdi
	movl	%edx, 64(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r8, 32(%rsp)
	call	calloc@PLT
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L1526
	movl	64(%rsp), %edx
	movq	32(%rsp), %r8
	movq	48(%rsp), %r10
	movq	88(%rsp), %r9
	cmpl	$2, %edx
	je	.L1527
	testl	%edx, %edx
	je	.L1528
	cmpb	$1, %r15b
	je	.L1529
	movq	80(%rsp), %rsi
	xorl	%ecx, %ecx
	jmp	.L1533
	.p2align 4,,10
	.p2align 3
.L2025:
	cmpb	$4, %r15b
	je	.L1531
	movq	(%rsi), %rax
.L1532:
	xorq	%r13, %rax
	addq	$1, %rcx
	addq	%r14, %rsi
	subq	%r12, %rax
	addl	$1, 0(%rbp,%rax,4)
	cmpq	%rcx, %rbx
	je	.L1534
.L1533:
	cmpb	$2, %r15b
	jne	.L2025
	movzwl	(%rsi), %eax
	jmp	.L1532
	.p2align 4,,10
	.p2align 3
.L1503:
	movq	%rax, %r11
	xorl	%esi, %esi
	xorl	%eax, %eax
	movq	$-1, %r12
	movabsq	$-9223372036854775808, %rbp
	pxor	%xmm1, %xmm1
	jmp	.L1524
	.p2align 4,,10
	.p2align 3
.L1837:
	testq	%rcx, %rcx
	jns	.L1522
	notq	%rcx
.L1521:
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %rsi
	addq	%r14, %r11
	cmpq	%rsi, %rbx
	je	.L1509
.L1524:
	movq	(%r11), %rcx
	movq	%rcx, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1800
	ucomisd	%xmm1, %xmm0
	jp	.L1837
	jne	.L1837
	xorl	%ecx, %ecx
.L1522:
	orq	%rbp, %rcx
	jmp	.L1521
	.p2align 4,,10
	.p2align 3
.L1800:
	movq	$-1, %rcx
	jmp	.L1521
.L1699:
	xorl	%esi, %esi
	movq	%r8, %rdi
	movq	%r8, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	testl	%eax, %eax
	jne	.L1736
	.p2align 4
	.p2align 3
.L1714:
	movl	80(%rsp), %eax
	testl	%eax, %eax
	jne	.L1526
	movq	%r8, %rdi
	call	free@PLT
.L1526:
	xorl	%ebx, %ebx
.L1501:
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ebx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L1504:
	.cfi_restore_state
	movq	%rax, %r11
	xorl	%esi, %esi
	xorl	%eax, %eax
	movq	$-1, %r12
	movabsq	$-9223372036854775808, %rbp
	jmp	.L1519
	.p2align 4,,10
	.p2align 3
.L2026:
	cmpb	$4, %r15b
	je	.L1516
	cmpb	$1, %r15b
	je	.L1517
	movq	(%r11), %rcx
.L1520:
	xorq	%rbp, %rcx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %rsi
	addq	%r14, %r11
	cmpq	%rsi, %rbx
	je	.L1509
.L1519:
	cmpb	$2, %r15b
	jne	.L2026
	movswq	(%r11), %rcx
	jmp	.L1520
	.p2align 4,,10
	.p2align 3
.L1797:
	movq	%rdi, %rdx
	movq	24(%rsp), %rdi
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r8d, %ecx
	popq	%rbx
	.cfi_def_cfa_offset 48
	movq	%r9, %rsi
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	keyed_sort_entries
.L1742:
	.cfi_restore_state
	movq	16(%rsp), %r15
	xorl	%edx, %edx
	pxor	%xmm1, %xmm1
	movl	%ebp, %ecx
	movabsq	$-9223372036854775808, %rdi
	addq	%r9, %r15
	movq	%r15, %rsi
	jmp	.L1772
.L1843:
	testq	%rax, %rax
	jns	.L1770
	notq	%rax
.L1769:
	xorl	%r13d, %eax
	addq	%r14, %rsi
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r12,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L2027
.L1772:
	movq	(%rsi), %rax
	movq	%rax, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1829
	ucomisd	%xmm1, %xmm0
	jp	.L1843
	jne	.L1843
	xorl	%eax, %eax
.L1770:
	orq	%rdi, %rax
	jmp	.L1769
.L1701:
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	movabsq	$-9223372036854775808, %rdi
	addq	%rax, %r10
	.p2align 4
	.p2align 3
.L1723:
	cmpb	$2, %r15b
	je	.L1719
	cmpb	$4, %r15b
	je	.L1720
	cmpb	$1, %r15b
	je	.L1721
	movq	(%r10), %rax
.L1724:
	xorq	%rdi, %rax
	addq	%r14, %r10
	xorq	%r13, %rax
	subq	%r12, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1723
.L1707:
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r8, 16(%rsp)
	movq	%r11, (%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	testl	%eax, %eax
	je	.L1714
	movq	(%rsp), %r11
	cmpq	$1, %rbx
	je	.L1824
.L1715:
	movq	%rbx, %rdx
	movq	%r11, %xmm1
	movq	%r8, %rax
	shrq	%rdx
	punpcklqdq	%xmm1, %xmm1
	salq	$4, %rdx
	addq	%r8, %rdx
	.p2align 5
	.p2align 4
	.p2align 3
.L1734:
	movdqu	(%rax), %xmm0
	addq	$16, %rax
	pand	%xmm1, %xmm0
	movups	%xmm0, -16(%rax)
	cmpq	%rdx, %rax
	jne	.L1734
	testb	$1, %bl
	je	.L1736
	movq	%rbx, %rax
	andq	$-2, %rax
.L1733:
	andq	%r11, (%r8,%rax,8)
.L1736:
	movq	24(%rsp), %rdi
	movq	%rbx, %rdx
	movq	%r8, %rsi
	movq	%r8, 16(%rsp)
	call	keyed_place
	movl	80(%rsp), %edx
	testl	%edx, %edx
	je	.L2028
.L1689:
	movl	$1, %ebx
	jmp	.L1501
.L2021:
	xorl	%esi, %esi
	movq	%r12, %rdi
	movq	%rax, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	testl	%eax, %eax
	jne	.L1774
.L1753:
	xorl	%ebx, %ebx
.L1775:
	movq	%r12, %rdi
	movq	%r8, 16(%rsp)
	call	free@PLT
	movq	16(%rsp), %rdi
	call	free@PLT
	jmp	.L1501
.L1700:
	movq	16(%rsp), %rax
	xorl	%esi, %esi
	pxor	%xmm1, %xmm1
	movl	%ebp, %ecx
	movabsq	$-9223372036854775808, %rdi
	addq	%rax, %r10
	jmp	.L1728
	.p2align 4,,10
	.p2align 3
.L1841:
	testq	%rax, %rax
	jns	.L1726
	notq	%rax
.L1725:
	xorq	%r13, %rax
	addq	%r14, %r10
	subq	%r12, %rax
	salq	%cl, %rax
	orq	%rsi, %rax
	movq	%rax, (%r8,%rsi,8)
	addq	$1, %rsi
	cmpq	%rsi, %rbx
	je	.L1707
.L1728:
	movq	(%r10), %rax
	movq	%rax, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1822
	ucomisd	%xmm1, %xmm0
	jp	.L1841
	jne	.L1841
	xorl	%eax, %eax
.L1726:
	orq	%rdi, %rax
	jmp	.L1725
.L1798:
	movl	$1, %eax
	movq	$-1, %r12
	jmp	.L1502
	.p2align 4,,10
	.p2align 3
.L1704:
	movl	(%r10), %eax
	jmp	.L1705
.L1822:
	movq	$-1, %rax
	jmp	.L1725
	.p2align 4,,10
	.p2align 3
.L1517:
	movsbq	(%r11), %rcx
	jmp	.L1520
	.p2align 4,,10
	.p2align 3
.L1516:
	movslq	(%r11), %rcx
	jmp	.L1520
.L1505:
	cmpq	$1, %r14
	jne	.L2029
	movq	%rax, %rsi
	leaq	(%rbx,%rax), %r11
	movq	$-1, %r12
	xorl	%eax, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L1513:
	movzbl	(%rsi), %ecx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %rsi
	cmpq	%r11, %rsi
	jne	.L1513
	jmp	.L1509
.L2027:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movq	%r8, (%rsp)
	movl	%ecx, %ebp
	movq	%r11, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r11
	movq	(%rsp), %r8
	testl	%eax, %eax
	je	.L1753
	xorl	%edx, %edx
	pxor	%xmm1, %xmm1
	movl	%ebp, %ecx
	movabsq	$-9223372036854775808, %rsi
	jmp	.L1791
.L1844:
	testq	%rax, %rax
	jns	.L1789
	notq	%rax
.L1788:
	xorq	%r13, %rax
	shrq	$32, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L1780
.L1791:
	movq	(%r12,%rdx,8), %rax
	andq	%r11, %rax
	imulq	%r14, %rax
	movq	(%r15,%rax), %rax
	movq	%rax, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1831
	ucomisd	%xmm1, %xmm0
	jp	.L1844
	jne	.L1844
	xorl	%eax, %eax
.L1789:
	orq	%rsi, %rax
	jmp	.L1788
.L1743:
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	leaq	(%rax,%r9), %rsi
	.p2align 4
	.p2align 3
.L1766:
	cmpb	$2, %r15b
	je	.L1762
	cmpb	$4, %r15b
	je	.L1763
	cmpb	$1, %r15b
	je	.L1764
	movq	(%rsi), %rax
.L1768:
	xorl	%r13d, %eax
	addq	%r14, %rsi
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r12,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1766
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movq	%r8, 48(%rsp)
	movl	%ecx, %ebp
	movq	%r9, 32(%rsp)
	movq	%r11, (%rsp)
	call	sort_u64
	movq	(%rsp), %r11
	movq	32(%rsp), %r9
	testl	%eax, %eax
	movq	48(%rsp), %r8
	je	.L1753
	movq	16(%rsp), %rdi
	xorl	%edx, %edx
	movl	%ebp, %ecx
	movabsq	$-9223372036854775808, %rsi
	.p2align 4
	.p2align 3
.L1786:
	movq	(%r12,%rdx,8), %rax
	andq	%r11, %rax
	imulq	%r14, %rax
	addq	%r9, %rax
	addq	%rdi, %rax
	cmpb	$2, %r15b
	je	.L1782
	cmpb	$4, %r15b
	je	.L1783
	cmpb	$1, %r15b
	je	.L1784
	movq	(%rax), %rax
.L1787:
	xorq	%rsi, %rax
	xorq	%r13, %rax
	shrq	$32, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1786
.L1780:
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r11, (%rsp)
	movq	%r8, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	movq	(%rsp), %r11
	testl	%eax, %eax
	je	.L1753
	movq	80(%rsp), %rcx
	movq	%r8, %rax
	addq	%r8, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L1792:
	movq	(%rax), %rdx
	addq	$8, %rax
	andq	%r11, %rdx
	movq	(%r12,%rdx,8), %rdi
	andq	%r11, %rdi
	movq	%rdi, -8(%rax)
	cmpq	%rcx, %rax
	jne	.L1792
.L1793:
	movq	24(%rsp), %rdi
	movq	%rbx, %rdx
	movq	%r8, %rsi
	movq	%r8, 16(%rsp)
	movl	$1, %ebx
	call	keyed_place
	movq	16(%rsp), %r8
	jmp	.L1775
	.p2align 4,,10
	.p2align 3
.L1745:
	movzwl	(%rsi), %eax
	jmp	.L1747
.L2022:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movq	%r8, 48(%rsp)
	movl	%ecx, %ebp
	movq	%r9, 32(%rsp)
	movq	%r11, (%rsp)
	call	sort_u64
	movq	(%rsp), %r11
	movq	32(%rsp), %r9
	testl	%eax, %eax
	movq	48(%rsp), %r8
	je	.L1753
	movq	16(%rsp), %rsi
	xorl	%edx, %edx
	movl	%ebp, %ecx
	jmp	.L1779
	.p2align 4,,10
	.p2align 3
.L2030:
	movq	(%rax), %rax
.L1778:
	xorq	%r13, %rax
	shrq	$32, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	je	.L1780
.L1779:
	movq	(%r12,%rdx,8), %rax
	andq	%r11, %rax
	imulq	%r14, %rax
	addq	%r9, %rax
	addq	%rsi, %rax
	cmpb	$2, %r15b
	je	.L1776
	cmpb	$4, %r15b
	jne	.L2030
	movl	(%rax), %eax
	jmp	.L1778
	.p2align 4,,10
	.p2align 3
.L1776:
	movzwl	(%rax), %eax
	jmp	.L1778
.L1829:
	movq	$-1, %rax
	jmp	.L1769
.L1831:
	movq	$-1, %rax
	jmp	.L1788
.L1506:
	movq	%rax, %r11
	xorl	%esi, %esi
	xorl	%eax, %eax
	movq	$-1, %r12
	.p2align 6
	.p2align 4
	.p2align 3
.L1510:
	movzwl	(%r11), %ecx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %rsi
	addq	%r14, %r11
	cmpq	%rsi, %rbx
	jne	.L1510
	jmp	.L1509
.L2028:
	movq	16(%rsp), %rdi
	call	free@PLT
	jmp	.L1689
.L1528:
	movq	80(%rsp), %rsi
	xorl	%ecx, %ecx
	movabsq	$-9223372036854775808, %rdi
	jmp	.L1543
	.p2align 4,,10
	.p2align 3
.L2031:
	cmpb	$4, %r15b
	je	.L1540
	cmpb	$1, %r15b
	je	.L1541
	movq	(%rsi), %rax
.L1544:
	xorq	%rdi, %rax
	addq	$1, %rcx
	addq	%r14, %rsi
	xorq	%r13, %rax
	subq	%r12, %rax
	addl	$1, 0(%rbp,%rax,4)
	cmpq	%rcx, %rbx
	je	.L1534
.L1543:
	cmpb	$2, %r15b
	jne	.L2031
	movswq	(%rsi), %rax
	jmp	.L1544
.L1529:
	movq	80(%rsp), %rax
	movq	%rax, %rcx
	leaq	(%rbx,%rax), %rsi
	cmpq	$1, %r14
	jne	.L2032
.L1537:
	movzbl	(%rcx), %eax
	addq	$1, %rcx
	xorq	%r13, %rax
	subq	%r12, %rax
	addl	$1, 0(%rbp,%rax,4)
	cmpq	%rsi, %rcx
	jne	.L1537
.L1534:
	movq	%rbp, %rax
	leaq	0(%rbp,%r8,4), %rdi
	xorl	%ecx, %ecx
	.p2align 4
	.p2align 4
	.p2align 3
.L1549:
	movl	(%rax), %esi
	movl	%ecx, (%rax)
	addq	$4, %rax
	addl	%esi, %ecx
	cmpq	%rax, %rdi
	jne	.L1549
	cmpq	$8, %r14
	jne	.L1550
	cmpb	$0, (%rsp)
	jne	.L1550
	movq	24(%rsp), %rax
	cmpq	%r9, (%rax)
	je	.L1550
	movl	$1, (%rsp)
	movq	16(%rsp), %r8
	cmpq	%r9, %r10
	je	.L1550
.L1551:
	testq	%r8, %r8
	je	.L2033
	cmpl	$2, %edx
	je	.L1554
	testl	%edx, %edx
	je	.L1555
	cmpb	$1, %r15b
	je	.L1556
	movq	80(%rsp), %rsi
	movq	%r8, %rax
	leaq	(%r8,%rbx,8), %r9
	jmp	.L1560
	.p2align 4,,10
	.p2align 3
.L2034:
	cmpb	$4, %r15b
	je	.L1558
	movq	(%rsi), %rdx
.L1559:
	xorq	%r13, %rdx
	addq	$8, %rax
	addq	%r14, %rsi
	subq	%r12, %rdx
	leaq	0(%rbp,%rdx,4), %rcx
	movl	(%rcx), %edx
	leal	1(%rdx), %edi
	movl	%edi, (%rcx)
	movl	%edx, %edi
	movq	%rdi, -8(%rax)
	cmpq	%rax, %r9
	je	.L1561
.L1560:
	cmpb	$2, %r15b
	jne	.L2034
	movzwl	(%rsi), %edx
	jmp	.L1559
.L1556:
	movq	80(%rsp), %rdi
	xorl	%edx, %edx
	cmpq	$1, %r14
	jne	.L2035
.L1562:
	movzbl	(%rdi,%rdx), %eax
	xorq	%r13, %rax
	subq	%r12, %rax
	leaq	0(%rbp,%rax,4), %rcx
	movl	(%rcx), %eax
	movq	%rax, (%r8,%rdx,8)
	leal	1(%rax), %esi
	addq	$1, %rdx
	movl	%esi, (%rcx)
	cmpq	%rdx, %rbx
	jne	.L1562
.L1561:
	movq	%rbp, %rdi
	movq	%r8, 80(%rsp)
	movq	%r10, 16(%rsp)
	call	free@PLT
	movq	16(%rsp), %r10
	movq	80(%rsp), %r8
	movq	24(%r10), %rax
	movq	(%rax), %rdx
	movq	24(%rsp), %rax
	movq	(%rax), %rax
	cmpq	%rax, %r10
	movq	32(%rax), %r14
	je	.L1575
	movq	32(%r10), %r12
	cmpq	$1, %rdx
	je	.L1808
	cmpq	$2, %rdx
	je	.L1577
	leaq	(%r8,%rbx,8), %rax
	movq	%r8, 32(%rsp)
	movq	%r12, %r13
	movq	%r8, %r15
	movq	%rax, 16(%rsp)
	leaq	.L1580(%rip), %rbp
	movq	%rdx, %r12
	movq	%rbx, 80(%rsp)
	leaq	-4(%rdx), %rbx
.L1589:
	movq	(%r15), %rax
	imulq	%r12, %rax
	leaq	(%r14,%rax), %rdi
	cmpq	$60, %rbx
	ja	.L1578
	movslq	0(%rbp,%rbx,4), %rax
	addq	%rbp, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1580:
	.long	.L1961-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1962-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1963-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1964-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1965-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1966-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1967-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1578-.L1580
	.long	.L1968-.L1580
	.text
.L1578:
	movq	%r13, %rsi
	movq	%r12, %rdx
	addq	$8, %r15
	addq	%r12, %r13
	call	memcpy@PLT
	cmpq	%r15, 16(%rsp)
	jne	.L1589
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
.L1588:
	movq	24(%rsp), %rax
	movq	(%rax), %rax
	addq	$1, 16(%rax)
	movq	%rbx, (%rax)
.L1591:
	movl	(%rsp), %ecx
	testl	%ecx, %ecx
	jne	.L1689
	movq	%r8, %rdi
	call	free@PLT
	jmp	.L1689
.L1550:
	leaq	0(,%rbx,8), %rdi
	movl	%edx, 32(%rsp)
	movq	%r10, 16(%rsp)
	call	malloc@PLT
	movl	$0, (%rsp)
	movl	32(%rsp), %edx
	movq	16(%rsp), %r10
	movq	%rax, %r8
	jmp	.L1551
.L1575:
	testq	%rdx, %rdx
	je	.L1591
	movq	24(%rsp), %rax
	movq	16(%rax), %r12
	leaq	-1(%rbx), %rax
	cmpq	$2, %rax
	jbe	.L1809
	movq	%rbx, %rcx
	xorl	%eax, %eax
	shrq	$2, %rcx
	salq	$4, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L1594:
	movdqu	(%r8,%rax,2), %xmm0
	movdqu	16(%r8,%rax,2), %xmm5
	shufps	$136, %xmm5, %xmm0
	movups	%xmm0, (%r8,%rax)
	addq	$16, %rax
	cmpq	%rax, %rcx
	jne	.L1594
	testb	$3, %bl
	je	.L1595
	movq	%rbx, %rax
	andq	$-4, %rax
.L1593:
	movq	(%r8,%rax,8), %rcx
	movl	%ecx, (%r8,%rax,4)
	leaq	1(%rax), %rcx
	cmpq	%rbx, %rcx
	jnb	.L1595
	movq	8(%r8,%rax,8), %rcx
	movl	%ecx, 4(%r8,%rax,4)
	leaq	2(%rax), %rcx
	cmpq	%rbx, %rcx
	jnb	.L1595
	movq	16(%r8,%rax,8), %rcx
	movl	%ecx, 8(%r8,%rax,4)
.L1595:
	leaq	(%r12,%rdx), %r13
	cmpq	$1, %rdx
	je	.L1596
	movq	%rbx, 16(%rsp)
	movq	%r13, %rcx
	xorl	%ebp, %ebp
	movq	%rdx, %r13
	movq	%r14, %r9
	movq	%r14, %r10
	movq	%r12, %r15
	.p2align 4
	.p2align 3
.L1675:
	movl	(%r8,%rbp,4), %eax
	cmpq	%rax, %rbp
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	cmpq	$64, %r13
	jbe	.L2036
.L1598:
	movq	%r10, %rsi
	movq	%r13, %rdx
	movq	%r15, %rdi
	movq	%r9, 48(%rsp)
	movq	%rcx, 32(%rsp)
	movq	%r8, 80(%rsp)
	movq	%r10, 24(%rsp)
	call	memcpy@PLT
	movq	24(%rsp), %r10
	movq	80(%rsp), %r8
	movq	32(%rsp), %rcx
	movq	48(%rsp), %r9
.L1674:
	movl	(%r8,%rbp,4), %r14d
	movq	%r13, %rax
	imulq	%r14, %rax
	leaq	0(,%r14,4), %r12
	movq	%r14, %rsi
	leaq	(%r8,%r12), %rdx
	movl	(%rdx), %r11d
	prefetcht0	(%r9,%rax)
	movq	%r11, %rax
	cmpq	%rbp, %r14
	je	.L1813
	movq	%r13, %rdx
	imulq	%r11, %rdx
	prefetcht0	(%r9,%rdx)
	leaq	(%r8,%r11,4), %rdx
	movl	(%rdx), %edi
	movl	%edi, 24(%rsp)
	cmpq	%rbp, %r11
	je	.L1810
	movq	%r13, %rax
	leaq	(%r8,%rdi,4), %rdx
	imulq	%rdi, %rax
	movl	(%rdx), %r11d
	movq	%r11, %rsi
	prefetcht0	(%r9,%rax)
	cmpq	%rbp, %rdi
	je	.L1811
	movq	%r13, %rdx
	imulq	%r11, %rdx
	prefetcht0	(%r9,%rdx)
	leaq	(%r8,%r11,4), %rdx
	movl	(%rdx), %edi
	cmpq	%rbp, %r11
	je	.L1812
	movq	%r13, %rax
	imulq	%rdi, %rax
	prefetcht0	(%r9,%rax)
	cmpq	%rbp, %rdi
	je	.L1672
	movl	(%r8,%rdi,4), %edi
	movq	%r13, %rax
	imulq	%rdi, %rax
	leaq	(%r8,%rdi,4), %rdx
	movq	%rdi, %rsi
	movl	(%rdx), %r11d
	prefetcht0	(%r9,%rax)
	cmpq	%rbp, %rdi
	je	.L1813
	movq	%r13, %rdx
	imulq	%r11, %rdx
	prefetcht0	(%r9,%rdx)
	movl	%ebp, %edx
	cmpq	%rbp, %r11
	je	.L1673
	movl	(%r8,%r11,4), %r11d
	movq	%r13, %rsi
	imulq	%r11, %rsi
	prefetcht0	(%r9,%rsi)
.L1673:
	movl	%edx, (%rbx)
.L2016:
	movq	%r10, 24(%rsp)
	movq	%rbp, %rax
	movq	%r13, %rdx
	movq	%rcx, %rbp
	movq	%r8, %r13
	movq	%rax, %rcx
	.p2align 4
	.p2align 3
.L1649:
	cmpq	%rcx, %r11
	je	.L1650
	movl	0(%r13,%r11,4), %r11d
	movq	%rdx, %rax
	imulq	%r11, %rax
	prefetcht0	(%r9,%rax)
.L1650:
	movq	%rdx, %rbx
	imulq	%r14, %rbx
	addq	%r9, %rbx
	cmpq	$64, %rdx
	ja	.L1612
	leaq	.L1614(%rip), %rdi
	movslq	(%rdi,%rdx,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1614:
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1985-.L1614
	.long	.L1612-.L1614
	.long	.L1621-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1620-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1619-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1618-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1617-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1616-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1615-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1612-.L1614
	.long	.L1613-.L1614
	.text
	.p2align 4,,10
	.p2align 3
.L1612:
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	movq	%r9, 64(%rsp)
	movq	%rcx, 48(%rsp)
	movq	%r11, 32(%rsp)
	movq	%rdx, 80(%rsp)
	call	memcpy@PLT
	movq	80(%rsp), %rdx
	movq	32(%rsp), %r11
	movq	48(%rsp), %rcx
	movq	64(%rsp), %r9
	leaq	-4(%rdx), %r10
	cmpq	$60, %r10
	ja	.L1641
	leaq	.L1642(%rip), %rsi
	movslq	(%rsi,%r10,4), %rax
	addq	%rsi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1642:
	.long	.L1640-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1639-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1638-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1637-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1636-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1635-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1634-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1641-.L1642
	.long	.L1633-.L1642
	.text
.L1641:
	movq	%r15, %rsi
	movq	%rbx, %rdi
	movq	%r10, 88(%rsp)
	movq	%r9, 64(%rsp)
	movq	%rcx, 48(%rsp)
	movq	%r11, 32(%rsp)
	movq	%rdx, 80(%rsp)
	call	memcpy@PLT
	movq	88(%rsp), %r10
	movq	80(%rsp), %rdx
	movq	32(%rsp), %r11
	movq	48(%rsp), %rcx
	cmpq	$60, %r10
	movq	64(%rsp), %r9
	ja	.L1643
	leaq	.L1644(%rip), %rdi
	movslq	(%rdi,%r10,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1644:
	.long	.L1632-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1631-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1630-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1629-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1628-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1627-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1626-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1643-.L1644
	.long	.L1624-.L1644
	.text
.L1643:
	movq	%rbp, %rsi
	movq	%r15, %rdi
	movq	%r9, 64(%rsp)
	movq	%rcx, 48(%rsp)
	movq	%r11, 32(%rsp)
	movq	%rdx, 80(%rsp)
	call	memcpy@PLT
	movq	80(%rsp), %rdx
	movq	32(%rsp), %r11
	movq	48(%rsp), %rcx
	movq	64(%rsp), %r9
	.p2align 4
	.p2align 3
.L1625:
	movl	0(%r13,%r12), %eax
	movl	%r14d, 0(%r13,%r12)
	cmpq	%rcx, %rax
	je	.L1988
	movq	%rax, %r14
	leaq	0(,%rax,4), %r12
	jmp	.L1649
.L1613:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rbp)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rbp)
	movdqu	48(%rbx), %xmm0
	movups	%xmm0, 48(%rbp)
.L1633:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%rbx)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%rbx)
	movdqu	48(%r15), %xmm0
	movups	%xmm0, 48(%rbx)
.L1624:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%r15)
	movdqu	32(%rbp), %xmm0
	movups	%xmm0, 32(%r15)
	movdqu	48(%rbp), %xmm0
	movups	%xmm0, 48(%r15)
	jmp	.L1625
.L1615:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rbp)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rbp)
	movq	48(%rbx), %rax
	movq	%rax, 48(%rbp)
.L1634:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%rbx)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%rbx)
	movq	48(%r15), %rax
	movq	%rax, 48(%rbx)
.L1626:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%r15)
	movdqu	32(%rbp), %xmm0
	movups	%xmm0, 32(%r15)
	movq	48(%rbp), %rax
	movq	%rax, 48(%r15)
	jmp	.L1625
.L1617:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rbp)
.L1636:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%rbx)
.L1628:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%r15)
	jmp	.L1625
.L1618:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
	movq	16(%rbx), %rax
	movq	%rax, 16(%rbp)
.L1637:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
	movq	16(%r15), %rax
	movq	%rax, 16(%rbx)
.L1629:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	movq	16(%rbp), %rax
	movq	%rax, 16(%r15)
	jmp	.L1625
.L1616:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rbp)
	movq	32(%rbx), %rax
	movq	%rax, 32(%rbp)
.L1635:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%rbx)
	movq	32(%r15), %rax
	movq	%rax, 32(%rbx)
.L1627:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%rbp), %xmm0
	movups	%xmm0, 16(%r15)
	movq	32(%rbp), %rax
	movq	%rax, 32(%r15)
	jmp	.L1625
.L1619:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, 0(%rbp)
.L1638:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%rbx)
.L1630:
	movdqu	0(%rbp), %xmm0
	movups	%xmm0, (%r15)
	jmp	.L1625
.L1620:
	movq	(%rbx), %rax
	movq	%rax, 0(%rbp)
.L1639:
	movq	(%r15), %rax
	movq	%rax, (%rbx)
.L1631:
	movq	0(%rbp), %rax
	movq	%rax, (%r15)
	jmp	.L1625
.L1621:
	movl	(%rbx), %eax
	movl	%eax, 0(%rbp)
.L1640:
	movl	(%r15), %eax
	movl	%eax, (%rbx)
.L1632:
	movl	0(%rbp), %eax
	movl	%eax, (%r15)
	jmp	.L1625
.L1651:
	movq	%r10, %rdi
	movq	%r13, %rdx
	movq	%r15, %rsi
	movq	%r9, 32(%rsp)
	movq	%rcx, 80(%rsp)
	movq	%r8, 24(%rsp)
	call	memcpy@PLT
	movq	24(%rsp), %r8
	movq	80(%rsp), %rcx
	movq	32(%rsp), %r9
	movq	%rax, %r10
.L1597:
	addq	$1, %rbp
	addq	%r13, %r10
	cmpq	%rbp, 16(%rsp)
	jne	.L1675
	jmp	.L1591
.L1988:
	movq	%rcx, %rax
	movq	24(%rsp), %r10
	movq	%r13, %r8
	movq	%rbp, %rcx
	movq	%rdx, %r13
	movq	%rax, %rbp
.L1610:
	cmpq	$64, %r13
	ja	.L1651
	leaq	.L1653(%rip), %rdi
	movslq	(%rdi,%r13,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1653:
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1645-.L1653
	.long	.L1651-.L1653
	.long	.L1660-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1659-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1658-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1657-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1656-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1655-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1654-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1651-.L1653
	.long	.L1652-.L1653
	.text
.L1654:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r10)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r10)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%r10)
	movq	48(%r15), %rax
	movq	%rax, 48(%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1669
	addq	$56, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1601:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%r10), %xmm0
	movups	%xmm0, 16(%r15)
	movdqu	32(%r10), %xmm0
	movups	%xmm0, 32(%r15)
	movq	48(%r10), %rax
	movq	%rax, 48(%r15)
	jmp	.L1674
.L1655:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r10)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r10)
	movq	32(%r15), %rax
	movq	%rax, 32(%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1668
	addq	$40, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1602:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%r10), %xmm0
	movups	%xmm0, 16(%r15)
	movq	32(%r10), %rax
	movq	%rax, 32(%r15)
	jmp	.L1674
.L1659:
	movq	(%r15), %rax
	movq	%rax, (%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1664
	addq	$8, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1606:
	movq	(%r10), %rax
	movq	%rax, (%r15)
	jmp	.L1674
.L1657:
	movdqu	(%r15), %xmm0
	movups	%xmm0, (%r10)
	movq	16(%r15), %rax
	movq	%rax, 16(%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1666
	addq	$24, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1604:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	movq	16(%r10), %rax
	movq	%rax, 16(%r15)
	jmp	.L1674
.L1652:
	movdqu	(%r15), %xmm0
	leaq	1(%rbp), %rax
	movups	%xmm0, (%r10)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r10)
	movdqu	32(%r15), %xmm0
	movups	%xmm0, 32(%r10)
	movdqu	48(%r15), %xmm0
	movups	%xmm0, 48(%r10)
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1670
	addq	$64, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1599:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%r10), %xmm0
	movups	%xmm0, 16(%r15)
	movdqu	32(%r10), %xmm0
	movups	%xmm0, 32(%r15)
	movdqu	48(%r10), %xmm0
	movups	%xmm0, 48(%r15)
	jmp	.L1674
.L1656:
	movdqu	(%r15), %xmm0
	leaq	1(%rbp), %rax
	movups	%xmm0, (%r10)
	movdqu	16(%r15), %xmm0
	movups	%xmm0, 16(%r10)
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1667
	addq	$32, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1603:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	movdqu	16(%r10), %xmm0
	movups	%xmm0, 16(%r15)
	jmp	.L1674
.L1660:
	movl	(%r15), %eax
	movl	%eax, (%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1663
	addq	$4, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1607:
	movl	(%r10), %eax
	movl	%eax, (%r15)
	jmp	.L1674
.L1658:
	movdqu	(%r15), %xmm0
	leaq	1(%rbp), %rax
	movups	%xmm0, (%r10)
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1665
	addq	$16, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1605:
	movdqu	(%r10), %xmm0
	movups	%xmm0, (%r15)
	jmp	.L1674
.L2036:
	leaq	.L1600(%rip), %rdx
	movslq	(%rdx,%r13,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L1600:
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1608-.L1600
	.long	.L1598-.L1600
	.long	.L1607-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1606-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1605-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1604-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1603-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1602-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1601-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1598-.L1600
	.long	.L1599-.L1600
	.text
	.p2align 4,,10
	.p2align 3
.L1719:
	movswq	(%r10), %rax
	jmp	.L1724
	.p2align 4,,10
	.p2align 3
.L1720:
	movslq	(%r10), %rax
	jmp	.L1724
	.p2align 4,,10
	.p2align 3
.L1721:
	movsbq	(%r10), %rax
	jmp	.L1724
.L1702:
	cmpq	$1, %r14
	jne	.L2037
	leaq	-1(%rbx), %rax
	cmpq	$14, %rax
	jbe	.L1820
	movq	16(%rsp), %rdi
	leaq	(%rbx,%r10), %rax
	addq	%rdi, %rax
	leaq	(%rdi,%r10), %rdx
	cmpq	%rax, %r8
	jnb	.L1840
	leaq	(%r8,%rbx,8), %rax
	cmpq	%rax, %rdx
	jb	.L1821
.L1840:
	movq	%rbx, %rax
	movl	$12, %r9d
	movq	%r8, %rcx
	movq	%rdx, %rsi
	shrq	$4, %rax
	movq	%r13, %xmm7
	movq	%r12, %xmm6
	movdqa	.LC0(%rip), %xmm4
	salq	$7, %rax
	punpcklqdq	%xmm7, %xmm7
	punpcklqdq	%xmm6, %xmm6
	leaq	(%rax,%r8), %rdi
	movl	$2, %eax
	movd	%ebp, %xmm10
	movq	%rax, %xmm14
	movl	$4, %eax
	pxor	%xmm9, %xmm9
	movq	%rax, %xmm13
	movl	$6, %eax
	pxor	%xmm8, %xmm8
	movq	%rax, %xmm12
	movl	$8, %eax
	punpcklqdq	%xmm14, %xmm14
	movq	%rax, %xmm11
	movl	$10, %eax
	punpcklqdq	%xmm13, %xmm13
	movq	%rax, %xmm5
	punpcklqdq	%xmm12, %xmm12
	punpcklqdq	%xmm11, %xmm11
	punpcklqdq	%xmm5, %xmm5
	movaps	%xmm5, (%rsp)
	movq	%r9, %xmm5
	movl	$14, %r9d
	punpcklqdq	%xmm5, %xmm5
	movaps	%xmm5, 32(%rsp)
	movq	%r9, %xmm5
	movl	$16, %r9d
	punpcklqdq	%xmm5, %xmm5
	movaps	%xmm5, 48(%rsp)
	movq	%r9, %xmm5
	punpcklqdq	%xmm5, %xmm5
	movaps	%xmm5, 64(%rsp)
	.p2align 4
	.p2align 3
.L1712:
	movdqu	(%rsi), %xmm0
	pxor	%xmm2, %xmm2
	subq	$-128, %rcx
	addq	$16, %rsi
	movdqa	%xmm0, %xmm1
	punpckhbw	%xmm9, %xmm0
	punpcklbw	%xmm9, %xmm1
	movdqa	%xmm0, %xmm5
	punpckhwd	%xmm8, %xmm0
	movdqa	%xmm1, %xmm3
	punpckhwd	%xmm8, %xmm1
	punpcklwd	%xmm8, %xmm5
	punpcklwd	%xmm8, %xmm3
	movdqa	%xmm3, %xmm15
	punpckhdq	%xmm2, %xmm3
	punpckldq	%xmm2, %xmm15
	pxor	%xmm7, %xmm3
	pxor	%xmm7, %xmm15
	psubq	%xmm6, %xmm3
	psubq	%xmm6, %xmm15
	psllq	%xmm10, %xmm3
	psllq	%xmm10, %xmm15
	por	%xmm4, %xmm15
	movups	%xmm15, -128(%rcx)
	movdqa	%xmm4, %xmm15
	paddq	%xmm14, %xmm15
	por	%xmm15, %xmm3
	movdqa	%xmm4, %xmm15
	movups	%xmm3, -112(%rcx)
	movdqa	%xmm1, %xmm3
	paddq	%xmm13, %xmm15
	punpckldq	%xmm2, %xmm3
	pxor	%xmm7, %xmm3
	psubq	%xmm6, %xmm3
	psllq	%xmm10, %xmm3
	por	%xmm15, %xmm3
	movups	%xmm3, -96(%rcx)
	movdqa	%xmm1, %xmm3
	movdqa	%xmm4, %xmm1
	punpckhdq	%xmm2, %xmm3
	paddq	%xmm12, %xmm1
	pxor	%xmm7, %xmm3
	psubq	%xmm6, %xmm3
	psllq	%xmm10, %xmm3
	por	%xmm1, %xmm3
	movdqa	%xmm5, %xmm1
	punpckldq	%xmm2, %xmm1
	movups	%xmm3, -80(%rcx)
	movdqa	%xmm4, %xmm3
	pxor	%xmm7, %xmm1
	paddq	%xmm11, %xmm3
	psubq	%xmm6, %xmm1
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movdqa	(%rsp), %xmm3
	movups	%xmm1, -64(%rcx)
	movdqa	%xmm5, %xmm1
	punpckhdq	%xmm2, %xmm1
	paddq	%xmm4, %xmm3
	pxor	%xmm7, %xmm1
	psubq	%xmm6, %xmm1
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movdqa	32(%rsp), %xmm3
	movups	%xmm1, -48(%rcx)
	movdqa	%xmm0, %xmm1
	punpckhdq	%xmm2, %xmm0
	punpckldq	%xmm2, %xmm1
	paddq	%xmm4, %xmm3
	pxor	%xmm7, %xmm0
	pxor	%xmm7, %xmm1
	psubq	%xmm6, %xmm0
	psubq	%xmm6, %xmm1
	psllq	%xmm10, %xmm0
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movups	%xmm1, -32(%rcx)
	movdqa	48(%rsp), %xmm1
	paddq	%xmm4, %xmm1
	paddq	64(%rsp), %xmm4
	por	%xmm1, %xmm0
	movups	%xmm0, -16(%rcx)
	cmpq	%rdi, %rcx
	jne	.L1712
	testb	$15, %bl
	je	.L1716
	movq	16(%rsp), %r9
	movq	%rbx, %rax
	andq	$-16, %rax
	leaq	(%r9,%rax), %rcx
	leaq	1(%rax), %rdi
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rax, %rcx
	movq	%rcx, (%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	2(%rax), %rdi
	movq	%rcx, 8(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	3(%rax), %rdi
	movq	%rcx, 16(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	4(%rax), %rdi
	movq	%rcx, 24(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	5(%rax), %rdi
	movq	%rcx, 32(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	6(%rax), %rdi
	movq	%rcx, 40(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	7(%rax), %rdi
	movq	%rcx, 48(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	movzbl	7(%rax,%rdx), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	8(%rax), %rdi
	movq	%rcx, 56(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	9(%rax), %rdi
	movq	%rcx, 64(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	10(%rax), %rdi
	movq	%rcx, 72(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	11(%rax), %rdi
	movq	%rcx, 80(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	orq	%rdi, %rcx
	leaq	12(%rax), %rdi
	movq	%rcx, 88(%r8,%rax,8)
	cmpq	%rbx, %rdi
	jnb	.L1716
	leaq	(%r9,%rdi), %rcx
	movzbl	(%rcx,%r10), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	subq	%r12, %rsi
	salq	%cl, %rsi
	movq	%rsi, %rcx
	leaq	13(%rax), %rsi
	orq	%rdi, %rcx
	movq	%rcx, 96(%r8,%rax,8)
	cmpq	%rbx, %rsi
	jnb	.L1716
	movzbl	13(%rax,%rdx), %edx
	movl	%ebp, %ecx
	xorq	%r13, %rdx
	subq	%r12, %rdx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	14(%rax), %rsi
	movq	%rdx, 104(%r8,%rax,8)
	cmpq	%rbx, %rsi
	jnb	.L1716
	leaq	(%r9,%rsi), %rdx
	movzbl	(%rdx,%r10), %edx
	xorq	%r13, %rdx
	subq	%r12, %rdx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	movq	%rdx, 112(%r8,%rax,8)
.L1716:
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r11, (%rsp)
	movq	%r8, 16(%rsp)
	call	sort_u64
	movq	(%rsp), %r11
	movq	16(%rsp), %r8
	testl	%eax, %eax
	jne	.L1715
	jmp	.L1714
.L1527:
	movq	80(%rsp), %rsi
	xorl	%ecx, %ecx
	pxor	%xmm1, %xmm1
	movabsq	$-9223372036854775808, %rdi
	jmp	.L1548
.L1838:
	testq	%rax, %rax
	jns	.L1546
	notq	%rax
.L1545:
	xorq	%r13, %rax
	addq	$1, %rcx
	addq	%r14, %rsi
	subq	%r12, %rax
	addl	$1, 0(%rbp,%rax,4)
	cmpq	%rcx, %rbx
	je	.L1534
.L1548:
	movq	(%rsi), %rax
	movq	%rax, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1802
	ucomisd	%xmm1, %xmm0
	jp	.L1838
	jne	.L1838
	xorl	%eax, %eax
.L1546:
	orq	%rdi, %rax
	jmp	.L1545
	.p2align 4,,10
	.p2align 3
.L1762:
	movswq	(%rsi), %rax
	jmp	.L1768
	.p2align 4,,10
	.p2align 3
.L1763:
	movslq	(%rsi), %rax
	jmp	.L1768
	.p2align 4,,10
	.p2align 3
.L1764:
	movsbq	(%rsi), %rax
	jmp	.L1768
	.p2align 4,,10
	.p2align 3
.L1782:
	movswq	(%rax), %rax
	jmp	.L1787
	.p2align 4,,10
	.p2align 3
.L1783:
	movslq	(%rax), %rax
	jmp	.L1787
	.p2align 4,,10
	.p2align 3
.L1784:
	movsbq	(%rax), %rax
	jmp	.L1787
.L1554:
	movq	80(%rsp), %rax
	movq	%r8, %rdx
	leaq	(%r8,%rbx,8), %r9
	pxor	%xmm1, %xmm1
	movabsq	$-9223372036854775808, %r11
	jmp	.L1574
.L1839:
	testq	%rcx, %rcx
	jns	.L1572
	notq	%rcx
.L1571:
	xorq	%r13, %rcx
	addq	$8, %rdx
	addq	%r14, %rax
	subq	%r12, %rcx
	leaq	0(%rbp,%rcx,4), %rsi
	movl	(%rsi), %ecx
	leal	1(%rcx), %edi
	movl	%edi, (%rsi)
	movl	%ecx, %edi
	movq	%rdi, -8(%rdx)
	cmpq	%rdx, %r9
	je	.L1561
.L1574:
	movq	(%rax), %rcx
	movq	%rcx, %xmm0
	ucomisd	%xmm0, %xmm0
	jp	.L1806
	ucomisd	%xmm1, %xmm0
	jp	.L1839
	jne	.L1839
	xorl	%ecx, %ecx
.L1572:
	orq	%r11, %rcx
	jmp	.L1571
.L1531:
	movl	(%rsi), %eax
	jmp	.L1532
.L1802:
	movq	$-1, %rax
	jmp	.L1545
.L1744:
	cmpq	$1, %r14
	jne	.L2038
	leaq	-1(%rbx), %rax
	cmpq	$14, %rax
	jbe	.L1826
	movq	16(%rsp), %rdi
	leaq	(%rbx,%r9), %rax
	addq	%rdi, %rax
	leaq	(%rdi,%r9), %r15
	cmpq	%rax, %r12
	jnb	.L1842
	movq	80(%rsp), %rax
	addq	%r12, %rax
	cmpq	%rax, %r15
	jb	.L1827
.L1842:
	movl	$4294967295, %eax
	movq	%rbx, %rdi
	movq	%rbx, %r10
	movq	%r15, %rcx
	movq	%rax, %xmm6
	andq	$-16, %rdi
	shrq	$4, %r10
	movq	%r12, %rdx
	movl	$2, %eax
	leaq	(%r15,%rdi), %rsi
	punpcklqdq	%xmm6, %xmm6
	movl	$14, %r14d
	movq	%rax, %xmm14
	movl	$4, %eax
	movq	%r13, %xmm7
	movdqa	.LC0(%rip), %xmm4
	movq	%rax, %xmm13
	movl	$6, %eax
	punpcklqdq	%xmm7, %xmm7
	movq	%rax, %xmm12
	movl	$8, %eax
	movd	%ebp, %xmm10
	movq	%rax, %xmm11
	movl	$10, %eax
	pxor	%xmm8, %xmm8
	movq	%rax, %xmm5
	movl	$12, %eax
	punpcklqdq	%xmm14, %xmm14
	punpcklqdq	%xmm5, %xmm5
	movq	%rax, %xmm9
	punpcklqdq	%xmm13, %xmm13
	movaps	%xmm5, (%rsp)
	movq	%r14, %xmm5
	movl	$16, %r14d
	punpcklqdq	%xmm12, %xmm12
	punpcklqdq	%xmm5, %xmm5
	punpcklqdq	%xmm11, %xmm11
	punpcklqdq	%xmm9, %xmm9
	movaps	%xmm5, 32(%rsp)
	movq	%r14, %xmm5
	punpcklqdq	%xmm5, %xmm5
	movaps	%xmm5, 48(%rsp)
	.p2align 4
	.p2align 3
.L1756:
	movdqu	(%rcx), %xmm0
	pxor	%xmm2, %xmm2
	addq	$16, %rcx
	subq	$-128, %rdx
	movdqa	%xmm0, %xmm1
	punpckhbw	%xmm8, %xmm0
	punpcklbw	%xmm8, %xmm1
	movdqa	%xmm0, %xmm5
	punpckhwd	%xmm2, %xmm0
	movdqa	%xmm1, %xmm3
	punpcklwd	%xmm2, %xmm5
	punpckhwd	%xmm2, %xmm1
	punpcklwd	%xmm2, %xmm3
	pxor	%xmm2, %xmm2
	movdqa	%xmm3, %xmm15
	punpckhdq	%xmm2, %xmm3
	punpckldq	%xmm2, %xmm15
	pxor	%xmm7, %xmm3
	pxor	%xmm7, %xmm15
	pand	%xmm6, %xmm3
	pand	%xmm6, %xmm15
	psllq	%xmm10, %xmm3
	psllq	%xmm10, %xmm15
	por	%xmm4, %xmm15
	movups	%xmm15, -128(%rdx)
	movdqa	%xmm4, %xmm15
	paddq	%xmm14, %xmm15
	por	%xmm15, %xmm3
	movdqa	%xmm4, %xmm15
	movups	%xmm3, -112(%rdx)
	movdqa	%xmm1, %xmm3
	paddq	%xmm13, %xmm15
	punpckldq	%xmm2, %xmm3
	pxor	%xmm7, %xmm3
	pand	%xmm6, %xmm3
	psllq	%xmm10, %xmm3
	por	%xmm15, %xmm3
	movups	%xmm3, -96(%rdx)
	movdqa	%xmm1, %xmm3
	movdqa	%xmm4, %xmm1
	punpckhdq	%xmm2, %xmm3
	paddq	%xmm12, %xmm1
	pxor	%xmm7, %xmm3
	pand	%xmm6, %xmm3
	psllq	%xmm10, %xmm3
	por	%xmm1, %xmm3
	movdqa	%xmm5, %xmm1
	punpckldq	%xmm2, %xmm1
	movups	%xmm3, -80(%rdx)
	movdqa	%xmm4, %xmm3
	pxor	%xmm7, %xmm1
	paddq	%xmm11, %xmm3
	pand	%xmm6, %xmm1
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movdqa	(%rsp), %xmm3
	movups	%xmm1, -64(%rdx)
	movdqa	%xmm5, %xmm1
	punpckhdq	%xmm2, %xmm1
	paddq	%xmm4, %xmm3
	pxor	%xmm7, %xmm1
	pand	%xmm6, %xmm1
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movdqa	%xmm4, %xmm3
	movups	%xmm1, -48(%rdx)
	movdqa	%xmm0, %xmm1
	paddq	%xmm9, %xmm3
	punpckhdq	%xmm2, %xmm0
	punpckldq	%xmm2, %xmm1
	pxor	%xmm7, %xmm0
	pxor	%xmm7, %xmm1
	pand	%xmm6, %xmm0
	pand	%xmm6, %xmm1
	psllq	%xmm10, %xmm0
	psllq	%xmm10, %xmm1
	por	%xmm3, %xmm1
	movups	%xmm1, -32(%rdx)
	movdqa	32(%rsp), %xmm1
	paddq	%xmm4, %xmm1
	paddq	48(%rsp), %xmm4
	por	%xmm1, %xmm0
	movups	%xmm0, -16(%rdx)
	cmpq	%rsi, %rcx
	jne	.L1756
	cmpq	%rdi, %rbx
	je	.L1761
	movzbl	(%r15,%rdi), %edx
	movl	%ebp, %ecx
	movq	%r10, %rax
	leaq	1(%rdi), %rsi
	salq	$7, %rax
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rdi, %rdx
	movq	%rdx, (%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movq	16(%rsp), %r10
	leaq	(%r10,%rsi), %rdx
	movzbl	(%rdx,%r9), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	2(%rdi), %rsi
	movq	%rdx, 8(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	2(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	3(%rdi), %rsi
	movq	%rdx, 16(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	3(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	4(%rdi), %rsi
	movq	%rdx, 24(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	leaq	(%r10,%rsi), %rdx
	movzbl	(%rdx,%r9), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	5(%rdi), %rsi
	movq	%rdx, 32(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	leaq	(%r10,%rsi), %rdx
	movzbl	(%rdx,%r9), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	6(%rdi), %rsi
	movq	%rdx, 40(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	leaq	(%r10,%rsi), %rdx
	movzbl	(%rdx,%r9), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	movq	%rdx, 48(%r12,%rax)
	leaq	7(%rdi), %rdx
	cmpq	%rbx, %rdx
	jnb	.L1761
	leaq	(%r10,%rdx), %rcx
	movzbl	(%rcx,%r9), %esi
	movl	%ebp, %ecx
	xorq	%r13, %rsi
	movl	%esi, %esi
	salq	%cl, %rsi
	orq	%rsi, %rdx
	leaq	8(%rdi), %rsi
	movq	%rdx, 56(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	8(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	9(%rdi), %rsi
	movq	%rdx, 64(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	9(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	10(%rdi), %rsi
	movq	%rdx, 72(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	10(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	11(%rdi), %rsi
	movq	%rdx, 80(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	11(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	12(%rdi), %rsi
	movq	%rdx, 88(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	12(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	13(%rdi), %rsi
	movq	%rdx, 96(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	13(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	leaq	14(%rdi), %rsi
	movq	%rdx, 104(%r12,%rax)
	cmpq	%rbx, %rsi
	jnb	.L1761
	movzbl	14(%rdi,%r15), %edx
	xorq	%r13, %rdx
	movl	%edx, %edx
	salq	%cl, %rdx
	orq	%rsi, %rdx
	movq	%rdx, 112(%r12,%rax)
.L1761:
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movq	%r8, (%rsp)
	movq	%r11, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r11
	movq	(%rsp), %r8
	testl	%eax, %eax
	je	.L1753
	xorl	%edx, %edx
	movl	%ebp, %ecx
	.p2align 5
	.p2align 4
	.p2align 3
.L1758:
	movq	%r13, %rax
	shrq	$32, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1758
	jmp	.L1780
.L1558:
	movl	(%rsi), %edx
	jmp	.L1559
.L1806:
	movq	$-1, %rcx
	jmp	.L1571
.L1555:
	movq	80(%rsp), %rsi
	movq	%r8, %rax
	leaq	(%r8,%rbx,8), %r11
	movabsq	$-9223372036854775808, %r9
	jmp	.L1569
.L2039:
	cmpb	$4, %r15b
	je	.L1566
	cmpb	$1, %r15b
	je	.L1567
	movq	(%rsi), %rdx
.L1570:
	xorq	%r9, %rdx
	addq	$8, %rax
	addq	%r14, %rsi
	xorq	%r13, %rdx
	subq	%r12, %rdx
	leaq	0(%rbp,%rdx,4), %rcx
	movl	(%rcx), %edx
	leal	1(%rdx), %edi
	movl	%edi, (%rcx)
	movl	%edx, %edi
	movq	%rdi, -8(%rax)
	cmpq	%rax, %r11
	je	.L1561
.L1569:
	cmpb	$2, %r15b
	jne	.L2039
	movswq	(%rsi), %rdx
	jmp	.L1570
.L2029:
	movq	%rax, %r11
	xorl	%esi, %esi
	xorl	%eax, %eax
	movq	$-1, %r12
	.p2align 6
	.p2align 4
	.p2align 3
.L1512:
	movzbl	(%r11), %ecx
	xorq	%r13, %rcx
	cmpq	%rcx, %r12
	cmova	%rcx, %r12
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	addq	$1, %rsi
	addq	%r14, %r11
	cmpq	%rsi, %rbx
	jne	.L1512
	jmp	.L1509
.L1824:
	xorl	%eax, %eax
	jmp	.L1733
.L1813:
	movq	%r11, %r14
	movq	%rbp, %r11
.L1671:
	movl	%esi, (%rdx)
	cmpq	%rbp, %r14
	je	.L1610
	leaq	0(,%r14,4), %r12
	jmp	.L2016
.L1541:
	movsbq	(%rsi), %rax
	jmp	.L1544
.L1540:
	movslq	(%rsi), %rax
	jmp	.L1544
.L1645:
	movzwl	(%r15), %eax
	movw	%ax, (%r10)
	leaq	1(%rbp), %rax
	cmpq	%rax, 16(%rsp)
	je	.L1591
	movl	(%r8,%rax,4), %edx
	cmpq	%rdx, %rax
	je	.L1662
	addq	$2, %r10
	leaq	(%r8,%rax,4), %rbx
	movq	%rax, %rbp
.L1608:
	movzwl	(%r10), %eax
	movw	%ax, (%r15)
	jmp	.L1674
.L2033:
	movq	%rbp, %rdi
	call	free@PLT
	jmp	.L1526
.L1567:
	movsbq	(%rsi), %rdx
	jmp	.L1570
.L1566:
	movslq	(%rsi), %rdx
	jmp	.L1570
.L2037:
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	addq	%rax, %r10
.L1709:
	movzbl	(%r10), %eax
	addq	%r14, %r10
	xorq	%r13, %rax
	subq	%r12, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1709
	jmp	.L1707
.L1810:
	movl	%eax, %esi
	movq	%rdi, %r14
	jmp	.L1671
.L2038:
	movq	16(%rsp), %r15
	xorl	%edx, %edx
	movl	%ebp, %ecx
	addq	%r9, %r15
.L1751:
	movzbl	(%r15), %eax
	addq	%r14, %r15
	xorq	%r13, %rax
	movl	%eax, %eax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r12,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1751
	movq	%rbx, %rsi
	movq	%r12, %rdi
	movq	%r11, (%rsp)
	movl	%ecx, %ebp
	movq	%r8, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	movq	(%rsp), %r11
	testl	%eax, %eax
	je	.L1753
	xorl	%edx, %edx
	movl	%ebp, %ecx
.L1752:
	movq	%r13, %rax
	shrq	$32, %rax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r8,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1752
	jmp	.L1780
.L1812:
	movq	%rdi, %r14
	jmp	.L1671
.L1811:
	movq	%r11, %r14
	movl	24(%rsp), %esi
	movq	%rbp, %r11
	jmp	.L1671
.L1672:
	movl	%ebp, %edx
	movq	%rbp, %r11
	jmp	.L1673
.L1808:
	xorl	%eax, %eax
.L1576:
	movzbl	(%r12,%rax), %ecx
	movq	(%r8,%rax,8), %rdx
	addq	$1, %rax
	movb	%cl, (%r14,%rdx)
	cmpq	%rax, %rbx
	jne	.L1576
	jmp	.L1588
.L1577:
	movq	%r8, %rax
	leaq	(%r8,%rbx,8), %rsi
.L1590:
	movzwl	(%r12), %ecx
	movq	(%rax), %rdx
	addq	$8, %rax
	addq	$2, %r12
	movw	%cx, (%r14,%rdx,2)
	cmpq	%rax, %rsi
	jne	.L1590
	jmp	.L1588
.L1826:
	movq	16(%rsp), %rax
	xorl	%edx, %edx
	movl	%ebp, %ecx
	leaq	(%rax,%r9), %r15
.L1760:
	movzbl	(%r15,%rdx), %eax
	xorq	%r13, %rax
	movl	%eax, %eax
	salq	%cl, %rax
	orq	%rdx, %rax
	movq	%rax, (%r12,%rdx,8)
	addq	$1, %rdx
	cmpq	%rdx, %rbx
	jne	.L1760
	movl	%ecx, %ebp
	jmp	.L1761
.L2035:
	movq	80(%rsp), %rcx
	movq	%r8, %rdx
	leaq	(%r8,%rbx,8), %rsi
.L1563:
	movzbl	(%rcx), %eax
	addq	$8, %rdx
	addq	%r14, %rcx
	xorq	%r13, %rax
	subq	%r12, %rax
	leaq	0(%rbp,%rax,4), %rdi
	movl	(%rdi), %eax
	leal	1(%rax), %r9d
	movq	%rax, -8(%rdx)
	movl	%r9d, (%rdi)
	cmpq	%rdx, %rsi
	jne	.L1563
	jmp	.L1561
.L1827:
	xorl	%edx, %edx
	movl	%ebp, %ecx
	jmp	.L1760
.L1820:
	movq	16(%rsp), %rax
	xorl	%esi, %esi
	movl	%ebp, %ecx
	leaq	(%rax,%r10), %rdx
.L1717:
	movzbl	(%rdx,%rsi), %eax
	xorq	%r13, %rax
	subq	%r12, %rax
	salq	%cl, %rax
	orq	%rsi, %rax
	movq	%rax, (%r8,%rsi,8)
	addq	$1, %rsi
	cmpq	%rsi, %rbx
	jne	.L1717
	jmp	.L1707
.L2032:
	movq	%rax, %rsi
	xorl	%ecx, %ecx
.L1536:
	movzbl	(%rsi), %eax
	addq	$1, %rcx
	addq	%r14, %rsi
	xorq	%r13, %rax
	subq	%r12, %rax
	addl	$1, 0(%rbp,%rax,4)
	cmpq	%rcx, %rbx
	jne	.L1536
	jmp	.L1534
.L1821:
	xorl	%esi, %esi
	movl	%ebp, %ecx
	jmp	.L1717
.L1596:
	movq	%r14, %r15
	xorl	%eax, %eax
.L1687:
	movl	(%r8,%rax,4), %edx
	cmpq	%rax, %rdx
	je	.L1676
.L2018:
	movzbl	(%r15), %edx
	leaq	(%r8,%rax,4), %rbp
	movb	%dl, (%r12)
	movl	(%r8,%rax,4), %esi
	leaq	0(,%rsi,4), %rcx
	leaq	(%r14,%rsi), %rdi
	movq	%rsi, %r10
	leaq	(%r8,%rcx), %r9
	prefetcht0	(%rdi)
	movl	(%r9), %edx
	movl	%edx, 24(%rsp)
	cmpq	%rax, %rsi
	je	.L1818
	leaq	(%r8,%rdx,4), %r9
	prefetcht0	(%r14,%rdx)
	movl	(%r9), %r11d
	movl	%r11d, 16(%rsp)
	cmpq	%rax, %rdx
	je	.L1815
	leaq	(%r8,%r11,4), %r9
	prefetcht0	(%r14,%r11)
	movl	(%r9), %edx
	movq	%rdx, %r10
	cmpq	%rax, %r11
	je	.L1816
	leaq	(%r8,%rdx,4), %r9
	prefetcht0	(%r14,%rdx)
	movl	(%r9), %r11d
	cmpq	%rax, %rdx
	je	.L1817
	movl	%eax, %r9d
	movq	%rax, %rdx
	prefetcht0	(%r14,%r11)
	cmpq	%rax, %r11
	je	.L1679
	movl	(%r8,%r11,4), %r11d
	leaq	(%r8,%r11,4), %r9
	movq	%r11, %r10
	prefetcht0	(%r14,%r11)
	movl	(%r9), %edx
	cmpq	%rax, %r11
	je	.L1818
	movl	%eax, %r9d
	prefetcht0	(%r14,%rdx)
	cmpq	%rax, %rdx
	je	.L1679
	movl	(%r8,%rdx,4), %edx
	prefetcht0	(%r14,%rdx)
.L1679:
	movl	%r9d, 0(%rbp)
.L1684:
	cmpq	%rax, %rdx
	je	.L1682
.L2040:
	movzbl	(%rdi), %r9d
	movl	(%r8,%rdx,4), %edx
	prefetcht0	(%r14,%rdx)
	movb	%r9b, 0(%r13)
	movzbl	(%r12), %r9d
	movb	%r9b, (%rdi)
	movzbl	0(%r13), %edi
	movb	%dil, (%r12)
	movl	(%r8,%rcx), %edi
	movl	%esi, (%r8,%rcx)
	cmpq	%rax, %rdi
	je	.L1683
	movq	%rdi, %rsi
	leaq	(%r14,%rdi), %rdi
	leaq	0(,%rsi,4), %rcx
	cmpq	%rax, %rdx
	jne	.L2040
.L1682:
	movzbl	(%rdi), %edx
	movb	%dl, 0(%r13)
	movzbl	(%r12), %edx
	movb	%dl, (%rdi)
	movzbl	0(%r13), %edx
	movb	%dl, (%r12)
	movl	(%r8,%rcx), %edx
	movl	%esi, (%r8,%rcx)
	cmpq	%rax, %rdx
	je	.L1683
.L1685:
	movzbl	(%r14,%rdx), %esi
	movb	%sil, 0(%r13)
	movzbl	(%r12), %esi
	movb	%sil, (%r14,%rdx)
	movzbl	0(%r13), %ecx
	movq	%rdx, %rsi
	movb	%cl, (%r12)
	leaq	(%r8,%rdx,4), %rcx
	movl	(%rcx), %edx
	movl	%esi, (%rcx)
	cmpq	%rax, %rdx
	jne	.L1685
.L1683:
	movzbl	(%r12), %edx
	addq	$1, %rax
	movb	%dl, (%r15)
	cmpq	%rax, %rbx
	je	.L1591
	movl	(%r8,%rax,4), %edx
	addq	$1, %r15
	cmpq	%rdx, %rax
	jne	.L2018
.L1676:
	addq	$1, %rax
	addq	$1, %r15
	cmpq	%rax, %rbx
	jne	.L1687
	jmp	.L1591
.L1809:
	xorl	%eax, %eax
	jmp	.L1593
.L1818:
	movq	%rdx, %rsi
	movq	%rax, %rdx
.L1677:
	movl	%r10d, (%r9)
	leaq	(%r14,%rsi), %rdi
	leaq	0(,%rsi,4), %rcx
	cmpq	%rax, %rsi
	jne	.L1684
	jmp	.L1683
.L1665:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$32, %r10
	cmpq	%rax, %rbp
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1605
.L1666:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$48, %r10
	cmpq	%rax, %rbp
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1604
.L1662:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$4, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1608
.L1668:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$80, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1602
.L1667:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$64, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1603
.L1669:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$112, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1601
.L1670:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	subq	$-128, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1599
.L1664:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$16, %r10
	cmpq	%rax, %rbp
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1606
.L1663:
	addq	$2, %rbp
	cmpq	%rbp, 16(%rsp)
	je	.L1591
	movl	(%r8,%rbp,4), %eax
	addq	$8, %r10
	cmpq	%rbp, %rax
	je	.L1597
	leaq	(%r8,%rbp,4), %rbx
	jmp	.L1607
.L1817:
	movq	%r11, %rsi
	jmp	.L1677
.L1816:
	movq	%rdx, %rsi
	movl	16(%rsp), %r10d
	movq	%rax, %rdx
	jmp	.L1677
.L1815:
	movl	24(%rsp), %r10d
	movq	%r11, %rsi
	jmp	.L1677
.L1985:
	movq	%rcx, %rax
	movq	%r13, %r8
	movq	%rbp, %rcx
	movq	24(%rsp), %r10
	movq	%rdx, %r13
	movq	%rax, %rbp
	jmp	.L1623
	.p2align 4,,10
	.p2align 3
.L1647:
	movl	(%r8,%rax,4), %r11d
	leaq	(%r9,%r14,2), %rbx
	prefetcht0	(%r9,%r11,2)
.L2017:
	leaq	0(,%r14,4), %r12
.L1623:
	movzwl	(%rbx), %eax
	movw	%ax, (%rcx)
	movzwl	(%r15), %eax
	movw	%ax, (%rbx)
	movzwl	(%rcx), %eax
	movw	%ax, (%r15)
	movl	(%r8,%r12), %esi
	movl	%r14d, (%r8,%r12)
	cmpq	%rbp, %rsi
	je	.L1645
	cmpq	%r11, %rbp
	je	.L2041
	movl	(%r8,%r11,4), %eax
	movzwl	(%r9,%rsi,2), %r11d
	prefetcht0	(%r9,%rax,2)
	movw	%r11w, (%rcx)
	movzwl	(%r15), %r11d
	movw	%r11w, (%r9,%rsi,2)
	movzwl	(%rcx), %edx
	movw	%dx, (%r15)
	movl	(%r8,%rsi,4), %r14d
	movl	%esi, (%r8,%rsi,4)
	cmpq	%rbp, %r14
	je	.L1610
	cmpq	%rbp, %rax
	jne	.L1647
	leaq	(%r9,%r14,2), %rbx
	movq	%rbp, %r11
	jmp	.L2017
.L2041:
	leaq	(%r9,%rsi,2), %rbx
	movq	%rsi, %r14
	jmp	.L2017
.L1739:
	movq	%r12, %rdi
	movq	%r8, 16(%rsp)
	call	free@PLT
	movq	16(%rsp), %rdi
	call	free@PLT
	jmp	.L1526
.L1774:
	xorl	%esi, %esi
	movq	%r8, %rdi
	movq	%r8, 16(%rsp)
	call	sort_u64
	movq	16(%rsp), %r8
	testl	%eax, %eax
	je	.L1753
	jmp	.L1793
.L1968:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1579
	.p2align 4,,10
	.p2align 3
.L2042:
	movq	0(%r13), %rdi
	subq	$-128, %r12
	salq	$6, %rdi
	addq	%r14, %rdi
.L1579:
	movdqu	(%r12), %xmm0
	leaq	8(%r13), %rdx
	movups	%xmm0, (%rdi)
	movdqu	16(%r12), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%r12), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%r12), %xmm0
	movups	%xmm0, 48(%rdi)
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movdqu	64(%r12), %xmm0
	addq	$16, %r13
	salq	$6, %rdx
	movups	%xmm0, (%r14,%rdx)
	movdqu	80(%r12), %xmm0
	movups	%xmm0, 16(%r14,%rdx)
	movdqu	96(%r12), %xmm0
	movups	%xmm0, 32(%r14,%rdx)
	movdqu	112(%r12), %xmm0
	movups	%xmm0, 48(%r14,%rdx)
	cmpq	%r13, %rax
	jne	.L2042
	jmp	.L1588
.L1967:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1581
	.p2align 4,,10
	.p2align 3
.L2043:
	imulq	$56, 0(%r13), %rdi
	addq	$112, %r12
	addq	%r14, %rdi
.L1581:
	movdqu	(%r12), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%r12), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%r12), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%r12), %rdx
	movq	%rdx, 48(%rdi)
	leaq	8(%r13), %rdx
	cmpq	%rdx, %rax
	je	.L1588
	imulq	$56, 8(%r13), %rdx
	movdqu	56(%r12), %xmm0
	addq	$16, %r13
	movups	%xmm0, (%r14,%rdx)
	movdqu	72(%r12), %xmm0
	movups	%xmm0, 16(%r14,%rdx)
	movdqu	88(%r12), %xmm0
	movups	%xmm0, 32(%r14,%rdx)
	movq	104(%r12), %rcx
	movq	%rcx, 48(%r14,%rdx)
	cmpq	%r13, %rax
	jne	.L2043
	jmp	.L1588
.L1966:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1582
	.p2align 4,,10
	.p2align 3
.L2044:
	movq	0(%r13), %rdx
	addq	$80, %r12
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%r14,%rdx,8), %rdi
.L1582:
	movdqu	(%r12), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%r12), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%r12), %rdx
	movq	%rdx, 32(%rdi)
	leaq	8(%r13), %rdx
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movdqu	40(%r12), %xmm0
	addq	$16, %r13
	leaq	(%rdx,%rdx,4), %rdx
	movups	%xmm0, (%r14,%rdx,8)
	movdqu	56(%r12), %xmm0
	movups	%xmm0, 16(%r14,%rdx,8)
	movq	72(%r12), %rcx
	movq	%rcx, 32(%r14,%rdx,8)
	cmpq	%rax, %r13
	jne	.L2044
	jmp	.L1588
.L1965:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1583
	.p2align 4,,10
	.p2align 3
.L2045:
	movq	0(%r13), %rdi
	addq	$64, %r12
	salq	$5, %rdi
	addq	%r14, %rdi
.L1583:
	movdqu	(%r12), %xmm0
	leaq	8(%r13), %rdx
	movups	%xmm0, (%rdi)
	movdqu	16(%r12), %xmm0
	movups	%xmm0, 16(%rdi)
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movdqu	32(%r12), %xmm0
	addq	$16, %r13
	salq	$5, %rdx
	movups	%xmm0, (%r14,%rdx)
	movdqu	48(%r12), %xmm0
	movups	%xmm0, 16(%r14,%rdx)
	cmpq	%rax, %r13
	jne	.L2045
	jmp	.L1588
.L1964:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1584
	.p2align 4,,10
	.p2align 3
.L2046:
	movq	0(%r13), %rdx
	addq	$48, %r12
	leaq	(%rdx,%rdx,2), %rdx
	leaq	(%r14,%rdx,8), %rdi
.L1584:
	movdqu	(%r12), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%r12), %rdx
	movq	%rdx, 16(%rdi)
	leaq	8(%r13), %rdx
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movdqu	24(%r12), %xmm0
	addq	$16, %r13
	leaq	(%rdx,%rdx,2), %rdx
	movups	%xmm0, (%r14,%rdx,8)
	movq	40(%r12), %rcx
	movq	%rcx, 16(%r14,%rdx,8)
	cmpq	%r13, %rax
	jne	.L2046
	jmp	.L1588
.L1963:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1585
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L2047:
	movq	0(%r13), %rdi
	addq	$32, %r12
	salq	$4, %rdi
	addq	%r14, %rdi
.L1585:
	movdqu	(%r12), %xmm0
	leaq	8(%r13), %rdx
	movups	%xmm0, (%rdi)
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movdqu	16(%r12), %xmm0
	addq	$16, %r13
	salq	$4, %rdx
	movups	%xmm0, (%r14,%rdx)
	cmpq	%rax, %r13
	jne	.L2047
	jmp	.L1588
.L1962:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1586
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L2048:
	movq	0(%r13), %rdx
	addq	$16, %r12
	leaq	(%r14,%rdx,8), %rdi
.L1586:
	movq	(%r12), %rdx
	movq	%rdx, (%rdi)
	leaq	8(%r13), %rdx
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movq	8(%r12), %rcx
	addq	$16, %r13
	movq	%rcx, (%r14,%rdx,8)
	cmpq	%rax, %r13
	jne	.L2048
	jmp	.L1588
.L1961:
	movq	%r13, %r12
	movq	80(%rsp), %rbx
	movq	32(%rsp), %r8
	movq	%r15, %r13
	movq	16(%rsp), %rax
	jmp	.L1587
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L2049:
	movq	0(%r13), %rdx
	addq	$8, %r12
	leaq	(%r14,%rdx,4), %rdi
.L1587:
	movl	(%r12), %edx
	movl	%edx, (%rdi)
	leaq	8(%r13), %rdx
	cmpq	%rdx, %rax
	je	.L1588
	movq	8(%r13), %rdx
	movl	4(%r12), %ecx
	addq	$16, %r13
	movl	%ecx, (%r14,%rdx,4)
	cmpq	%r13, %rax
	jne	.L2049
	jmp	.L1588
	.cfi_endproc
.LFE98:
	.size	keyed_sort_words, .-keyed_sort_words
	.p2align 4
	.type	sort_generic, @function
sort_generic:
.LFB86:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$2456, %rsp
	.cfi_def_cfa_offset 2512
	movq	%rdi, 64(%rsp)
	movl	%edx, 28(%rsp)
	movq	%fs:40, %r13
	movq	%r13, 2440(%rsp)
	movq	%rcx, %r13
	cmpq	$31, %rsi
	jbe	.L2283
	movq	%rsi, %rax
	xorl	%edx, %edx
.L2052:
	movq	%rax, %rcx
	shrq	%rax
	andl	$1, %ecx
	orq	%rcx, %rdx
	cmpq	$31, %rax
	ja	.L2052
	addq	%rdx, %rax
	movq	%rax, 104(%rsp)
	cmpq	%rbx, %rax
	jb	.L2543
	movq	$32, 104(%rsp)
	movq	$0, 120(%rsp)
.L2051:
	leaq	128(%rsp), %r14
	movq	%rbx, %rbp
	movq	120(%rsp), %rbx
	xorl	%esi, %esi
	movq	%r14, 112(%rsp)
	xorl	%r14d, %r14d
.L2272:
	cmpq	%rbp, %r14
	jnb	.L2054
	leaq	1(%r14), %r8
	movq	%r8, %rax
	cmpq	%r8, %rbp
	je	.L2055
.L2273:
	movq	%r13, %rcx
	movq	64(%rsp), %rdx
	movl	28(%rsp), %r9d
	imulq	%r14, %rcx
	leaq	(%rdx,%rcx), %rdi
	addq	%r13, %rcx
	addq	%rcx, %rdx
	testl	%r9d, %r9d
	jne	.L2056
	cmpq	$2, %r13
	je	.L2057
	cmpq	$4, %r13
	je	.L2058
	movzbl	(%rdi), %r11d
	cmpb	%r11b, (%rdx)
	jl	.L2544
.L2059:
	leaq	2(%r14), %rdi
	cmpq	%rbp, %rdi
	jnb	.L2102
	leaq	0(%r13,%rcx), %r9
	movq	%r8, %rax
	cmpq	$2, %r13
	je	.L2085
	movq	%rdx, %r8
	subq	%rcx, %r8
	cmpq	$4, %r13
	je	.L2107
.L2545:
	movzbl	(%rdx), %r11d
	cmpb	%r11b, (%r8,%r9)
	jl	.L2102
	leaq	1(%rdi), %r8
	cmpq	%rbp, %r8
	jnb	.L2299
	addq	$1, %rdx
.L2110:
	movq	%rdi, %rax
	movq	%r8, %rdi
	movq	%rdx, %r8
	subq	%rcx, %r8
	cmpq	$4, %r13
	jne	.L2545
.L2107:
	movl	(%rdx), %r11d
	cmpl	%r11d, (%r8,%r9)
	jl	.L2102
	leaq	1(%rdi), %r8
	cmpq	%rbp, %r8
	jnb	.L2299
	addq	$4, %rdx
	jmp	.L2110
.L2085:
	movq	%rdx, %r8
	movzwl	(%rdx), %r11d
	subq	%rcx, %r8
	cmpw	%r11w, (%r8,%r9)
	jl	.L2102
	leaq	1(%rdi), %r8
	addq	$2, %rdx
	movq	%rdi, %rax
	cmpq	%rbp, %r8
	jnb	.L2102
	movq	%r8, %rdi
	jmp	.L2085
.L2090:
	leaq	1(%rax), %rcx
	addq	$2, %rdx
	cmpq	%rbp, %rcx
	jnb	.L2102
	movq	%rcx, %rax
.L2092:
	movq	%rdx, %rcx
	movzwl	(%rdx), %r11d
	subq	%r8, %rcx
	cmpw	%r11w, (%rcx,%rdi)
	jnb	.L2090
.L2087:
	subq	$1, %rax
.L2102:
	subq	%r14, %rax
	leaq	1(%rax), %rcx
	cmpq	104(%rsp), %rcx
	jb	.L2546
.L2111:
	testq	%rsi, %rsi
	jne	.L2275
	movq	%r14, 128(%rsp)
	addq	%rcx, %r14
	movq	$0, 144(%rsp)
	movq	%rcx, 136(%rsp)
	cmpq	%rbp, %r14
	jb	.L2547
.L2271:
	movq	120(%rsp), %rdi
	call	free@PLT
	movl	$1, %eax
.L2050:
	movq	2440(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L2548
	addq	$2456, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L2054:
	.cfi_restore_state
	cmpq	$1, %rsi
	jbe	.L2271
	movl	$0, 32(%rsp)
	movq	%rsi, %r11
	xorl	%ecx, %ecx
.L2276:
	movq	112(%rsp), %rdi
	movq	%r14, 72(%rsp)
	leaq	(%rsi,%rsi,2), %rax
	movq	%r11, %r10
	movq	%rcx, 80(%rsp)
	movq	%rbp, 88(%rsp)
	movq	64(%rsp), %rbp
	leaq	(%rdi,%rax,8), %r12
	.p2align 4
	.p2align 3
.L2268:
	movl	32(%rsp), %eax
	cmpl	%eax, -32(%r12)
	jg	.L2270
	cmpq	$96, %r10
	jne	.L2541
.L2270:
	movq	-24(%r12), %rsi
	movq	%r13, %rdi
	movq	-16(%r12), %rax
	subq	$1, %r10
	movq	-48(%r12), %rcx
	movl	28(%rsp), %r9d
	imulq	%rsi, %rdi
	movq	%rsi, %r8
	movq	%rax, 16(%rsp)
	subq	%rcx, %r8
	leaq	0(%rbp,%rdi), %r14
	movq	%r14, %r15
	testl	%r9d, %r9d
	je	.L2302
	xorl	%edx, %edx
	cmpq	$1, %r13
	je	.L2303
	cmpq	$2, %r13
	je	.L2166
	cmpq	%r8, %rdx
	jnb	.L2484
	.p2align 4
	.p2align 3
.L2551:
	movl	(%r14), %r9d
.L2167:
	movq	%r8, %rax
	subq	%rdx, %rax
	shrq	%rax
	addq	%rdx, %rax
	leaq	(%rcx,%rax), %r11
	cmpl	0(%rbp,%r11,4), %r9d
	jnb	.L2170
	cmpq	%rax, %rdx
	jnb	.L2549
	movq	%rax, %r8
	jmp	.L2167
	.p2align 4,,10
	.p2align 3
.L2550:
	leaq	1(%rax), %rdx
.L2166:
	cmpq	%r8, %rdx
	jnb	.L2486
	movzwl	(%r14), %r9d
.L2175:
	movq	%r8, %rax
	subq	%rdx, %rax
	shrq	%rax
	addq	%rdx, %rax
	leaq	(%rcx,%rax), %r11
	cmpw	0(%rbp,%r11,2), %r9w
	jnb	.L2550
	cmpq	%rax, %rdx
	jnb	.L2486
	movq	%rax, %r8
	jmp	.L2175
	.p2align 4,,10
	.p2align 3
.L2170:
	leaq	1(%rax), %rdx
	cmpq	%r8, %rdx
	jb	.L2551
.L2484:
	addq	%rdx, %rcx
	cmpq	%rcx, %rsi
	je	.L2188
.L2538:
	leaq	-4(%rbp,%rsi,4), %r8
	cmpq	$1, %r13
	je	.L2309
	cmpq	$2, %r13
	je	.L2310
	movq	16(%rsp), %r9
	xorl	%eax, %eax
	.p2align 4
	.p2align 3
.L2196:
	cmpq	%r9, %rax
	jnb	.L2208
	movq	%rcx, 8(%rsp)
.L2194:
	movq	%r9, %rdx
	movl	(%r8), %ecx
	subq	%rax, %rdx
	shrq	%rdx
	addq	%rax, %rdx
	leaq	0(%rbp,%rdx,4), %r11
	cmpl	%ecx, (%r11,%rdi)
	jb	.L2193
	cmpq	%rdx, %rax
	jnb	.L2552
	movq	%rdx, %r9
	jmp	.L2194
	.p2align 4,,10
	.p2align 3
.L2302:
	xorl	%r9d, %r9d
	jmp	.L2164
	.p2align 4,,10
	.p2align 3
.L2554:
	movsbq	(%r14), %r11
	movsbq	(%rdx), %rdx
.L2183:
	cmpq	%rdx, %r11
	jl	.L2184
.L2555:
	leaq	1(%rax), %r9
.L2164:
	cmpq	%r8, %r9
	jnb	.L2553
.L2185:
	movq	%r8, %rax
	subq	%r9, %rax
	shrq	%rax
	addq	%r9, %rax
	leaq	(%rcx,%rax), %rdx
	imulq	%r13, %rdx
	addq	%rbp, %rdx
	cmpq	$2, %r13
	je	.L2181
	cmpq	$4, %r13
	jne	.L2554
	movslq	(%r14), %r11
	movslq	(%rdx), %rdx
	cmpq	%rdx, %r11
	jge	.L2555
.L2184:
	cmpq	%rax, %r9
	jnb	.L2556
	movq	%rax, %r8
	jmp	.L2185
	.p2align 4,,10
	.p2align 3
.L2181:
	movswq	(%r14), %r11
	movswq	(%rdx), %rdx
	jmp	.L2183
	.p2align 4,,10
	.p2align 3
.L2553:
	addq	%r9, %rcx
	cmpq	%rcx, %rsi
	je	.L2188
.L2537:
	leaq	-1(%rsi), %r9
	movq	16(%rsp), %r8
	xorl	%eax, %eax
	imulq	%r13, %r9
	addq	%rbp, %r9
	jmp	.L2189
	.p2align 4,,10
	.p2align 3
.L2557:
	movsbq	(%r11), %r11
	movq	%r11, 8(%rsp)
	movsbq	(%r9), %r11
.L2203:
	cmpq	%r11, 8(%rsp)
	jge	.L2204
.L2558:
	leaq	1(%rdx), %rax
.L2189:
	cmpq	%r8, %rax
	jnb	.L2208
.L2205:
	movq	%r8, %rdx
	movq	%r13, %r11
	subq	%rax, %rdx
	shrq	%rdx
	addq	%rax, %rdx
	imulq	%rdx, %r11
	addq	%rdi, %r11
	addq	%rbp, %r11
	cmpq	$2, %r13
	je	.L2201
	cmpq	$4, %r13
	jne	.L2557
	movslq	(%r11), %r11
	movq	%r11, 8(%rsp)
	movslq	(%r9), %r11
	cmpq	%r11, 8(%rsp)
	jl	.L2558
.L2204:
	cmpq	%rdx, %rax
	jnb	.L2208
	movq	%rdx, %r8
	jmp	.L2205
	.p2align 4,,10
	.p2align 3
.L2564:
	movl	(%r15), %edi
	movl	(%rsi), %eax
	leaq	4(%rcx), %r9
	cmpl	%eax, %edi
	jge	.L2236
.L2559:
	addq	$4, %r15
	movl	%edi, (%rcx)
	cmpq	%r8, %r15
	jnb	.L2336
.L2542:
	cmpq	%rdx, %rsi
	jnb	.L2336
	movl	(%r15), %edi
	movl	(%rsi), %eax
	movq	%r9, %rcx
	leaq	4(%rcx), %r9
	cmpl	%eax, %edi
	jl	.L2559
.L2236:
	movl	%eax, (%rcx)
	addq	$4, %rsi
	cmpq	%r8, %r15
	jb	.L2542
.L2336:
	movq	%r9, %rcx
.L2211:
	cmpq	%rdx, %rsi
	jb	.L2560
.L2188:
	movq	16(%rsp), %rax
	addq	%rax, -40(%r12)
	subq	$24, %r12
	cmpq	$1, %r10
	jne	.L2268
.L2541:
	movq	72(%rsp), %r14
	movq	80(%rsp), %rcx
	movq	%r10, %r11
	movq	88(%rsp), %rbp
.L2269:
	cmpq	%rbp, %r14
	jnb	.L2271
	movl	32(%rsp), %edi
	leaq	-3(%r11,%r11,2), %rax
	leaq	1(%r11), %rsi
	movl	%edi, 144(%rsp,%rax,8)
	leaq	(%r11,%r11,2), %rax
	movq	%r14, 128(%rsp,%rax,8)
	addq	%rcx, %r14
	movq	$0, 144(%rsp,%rax,8)
	movq	%rcx, 136(%rsp,%rax,8)
	jmp	.L2272
	.p2align 4,,10
	.p2align 3
.L2552:
	movq	8(%rsp), %rcx
	.p2align 4
	.p2align 3
.L2208:
	movq	%rsi, %rdx
	addq	%rax, %rsi
	imulq	%r13, %rsi
	subq	%rcx, %rdx
	imulq	%r13, %rcx
	leaq	0(%rbp,%rsi), %r8
	addq	%rbp, %rcx
	cmpq	%rdx, %rax
	jb	.L2561
	imulq	%r13, %rdx
	movq	%rcx, %rsi
	movq	%rbx, %rdi
	movq	%r10, 56(%rsp)
	movq	%r8, 48(%rsp)
	movq	%rcx, 8(%rsp)
	movq	%rdx, 40(%rsp)
	call	memcpy@PLT
	movq	40(%rsp), %rdx
	movq	48(%rsp), %r8
	movq	%rbx, %rsi
	movq	8(%rsp), %rcx
	movq	56(%rsp), %r10
	addq	%rbx, %rdx
	cmpq	%r14, %r8
	jbe	.L2211
	cmpq	%rdx, %rbx
	jnb	.L2211
	movl	28(%rsp), %edi
	testl	%edi, %edi
	je	.L2215
	cmpq	$1, %r13
	je	.L2216
	cmpq	$2, %r13
	jne	.L2220
	jmp	.L2217
	.p2align 4,,10
	.p2align 3
.L2562:
	addq	$4, %rsi
	movl	%edi, %eax
	.p2align 4
	.p2align 3
.L2219:
	movl	%eax, -4(%rcx)
	cmpq	%r8, %r15
	jnb	.L2211
	cmpq	%rdx, %rsi
	jnb	.L2188
.L2220:
	movl	(%r15), %eax
	movl	(%rsi), %edi
	addq	$4, %rcx
	cmpl	%edi, %eax
	jnb	.L2562
	addq	$4, %r15
	jmp	.L2219
	.p2align 4,,10
	.p2align 3
.L2563:
	addq	$1, %rsi
	movl	%edi, %eax
	.p2align 4
	.p2align 3
.L2226:
	movb	%al, -1(%rcx)
	cmpq	%r8, %r15
	jnb	.L2211
	cmpq	%rdx, %rsi
	jnb	.L2188
.L2216:
	movzbl	(%r15), %eax
	movzbl	(%rsi), %edi
	addq	$1, %rcx
	cmpb	%dil, %al
	jnb	.L2563
	addq	$1, %r15
	jmp	.L2226
	.p2align 4,,10
	.p2align 3
.L2222:
	addq	$2, %rsi
	movl	%edi, %eax
	.p2align 4
	.p2align 3
.L2223:
	movw	%ax, -2(%rcx)
	cmpq	%r8, %r15
	jnb	.L2211
	cmpq	%rdx, %rsi
	jnb	.L2188
.L2217:
	movzwl	(%r15), %eax
	movzwl	(%rsi), %edi
	addq	$2, %rcx
	cmpw	%di, %ax
	jnb	.L2222
	addq	$2, %r15
	jmp	.L2223
	.p2align 4,,10
	.p2align 3
.L2215:
	cmpq	$2, %r13
	je	.L2318
.L2229:
	cmpq	$4, %r13
	je	.L2564
.L2232:
	movzbl	(%r15), %edi
	movzbl	(%rsi), %eax
	leaq	1(%rcx), %r9
	cmpb	%al, %dil
	jge	.L2565
	addq	$1, %r15
	movb	%dil, (%rcx)
	movq	%r9, %rcx
	cmpq	%r8, %r15
	jnb	.L2211
	cmpq	%rdx, %rsi
	jb	.L2229
	cmpq	%rdx, %rsi
	jnb	.L2188
	.p2align 4
	.p2align 3
.L2560:
	subq	%rsi, %rdx
	movq	%rcx, %rdi
	movq	%r10, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %r10
	jmp	.L2188
	.p2align 4,,10
	.p2align 3
.L2201:
	movswq	(%r11), %r11
	movq	%r11, 8(%rsp)
	movswq	(%r9), %r11
	jmp	.L2203
	.p2align 4,,10
	.p2align 3
.L2561:
	imulq	%r13, %rax
	movq	%r14, %rsi
	movq	%rbx, %rdi
	movq	%r10, 56(%rsp)
	movq	%r8, 48(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%rax, %rdx
	movq	%rax, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rdx
	movq	40(%rsp), %rcx
	movq	48(%rsp), %r8
	movq	56(%rsp), %r10
	addq	%rbx, %rdx
	cmpq	%r14, %rcx
	jnb	.L2243
	cmpq	%rdx, %rbx
	jnb	.L2188
	movl	28(%rsp), %eax
	testl	%eax, %eax
	je	.L2244
	cmpq	$1, %r13
	je	.L2245
	cmpq	$2, %r13
	jne	.L2249
	jmp	.L2246
	.p2align 4,,10
	.p2align 3
.L2247:
	movl	%esi, %eax
	subq	$4, %r15
	movl	%eax, (%r8)
	cmpq	%r15, %rcx
	jnb	.L2243
	.p2align 4
	.p2align 3
.L2566:
	cmpq	%rdx, %rbx
	jnb	.L2188
.L2249:
	movl	-4(%rdx), %eax
	movl	-4(%r15), %esi
	subq	$4, %r8
	cmpl	%esi, %eax
	jb	.L2247
	movl	%eax, (%r8)
	subq	$4, %rdx
	cmpq	%r15, %rcx
	jb	.L2566
	.p2align 4
	.p2align 3
.L2243:
	cmpq	%rdx, %rbx
	jnb	.L2188
	subq	%rbx, %rdx
	movq	%r8, %rdi
	movq	%rbx, %rsi
	movq	%r10, 8(%rsp)
	subq	%rdx, %rdi
	call	memcpy@PLT
	movq	8(%rsp), %r10
	jmp	.L2188
	.p2align 4,,10
	.p2align 3
.L2255:
	subq	$1, %r15
	movl	%esi, %eax
	.p2align 4
	.p2align 3
.L2256:
	movb	%al, (%r8)
	cmpq	%r15, %rcx
	jnb	.L2243
	cmpq	%rdx, %rbx
	jnb	.L2188
.L2245:
	movzbl	-1(%rdx), %eax
	movzbl	-1(%r15), %esi
	subq	$1, %r8
	cmpb	%sil, %al
	jb	.L2255
	subq	$1, %rdx
	jmp	.L2256
	.p2align 4,,10
	.p2align 3
.L2567:
	subq	$2, %r15
	movl	%esi, %eax
	.p2align 4
	.p2align 3
.L2253:
	movw	%ax, (%r8)
	cmpq	%rdx, %rbx
	jnb	.L2188
	cmpq	%r15, %rcx
	jnb	.L2243
.L2246:
	movzwl	-2(%rdx), %eax
	movzwl	-2(%r15), %esi
	subq	$2, %r8
	cmpw	%si, %ax
	jb	.L2567
	subq	$2, %rdx
	jmp	.L2253
	.p2align 4,,10
	.p2align 3
.L2244:
	movq	%rdx, %rax
	subq	%r13, %r14
	subq	%r13, %rax
	cmpq	$2, %r13
	je	.L2258
.L2259:
	cmpq	$4, %r13
	je	.L2260
.L2568:
	movzbl	(%rax), %esi
	movzbl	(%r14), %edi
	leaq	-1(%r8), %r9
	cmpb	%dil, %sil
	jge	.L2261
	movb	%dil, -1(%r8)
	cmpq	%rdx, %rbx
	jnb	.L2325
	cmpq	%r14, %rcx
	jnb	.L2325
	movq	%r14, %r15
	leaq	-1(%rdx), %rax
	movq	%r9, %r8
	subq	$1, %r14
	cmpq	$4, %r13
	jne	.L2568
	.p2align 4
	.p2align 3
.L2260:
	movl	(%rax), %esi
	movl	(%r14), %edi
	leaq	-4(%r8), %r9
	cmpl	%edi, %esi
	jge	.L2267
.L2569:
	movl	%edi, -4(%r8)
	cmpq	%rdx, %rbx
	jnb	.L2325
	cmpq	%r14, %rcx
	jnb	.L2325
	movq	%r14, %r15
	movl	-4(%rdx), %esi
	movl	-4(%r14), %edi
	movq	%r9, %r8
	leaq	-4(%rdx), %rax
	subq	$4, %r14
	leaq	-4(%r8), %r9
	cmpl	%edi, %esi
	jl	.L2569
.L2267:
	movl	%esi, -4(%r8)
	cmpq	%rax, %rbx
	jnb	.L2326
	cmpq	%r15, %rcx
	jnb	.L2326
	movq	%rax, %rdx
	leaq	-4(%r15), %r14
	movq	%r9, %r8
	subq	$4, %rax
	jmp	.L2260
	.p2align 4,,10
	.p2align 3
.L2570:
	movw	%di, -2(%r8)
	cmpq	%r14, %rcx
	jnb	.L2325
	cmpq	%rdx, %rbx
	jnb	.L2325
	movq	%r14, %r15
	leaq	-2(%rdx), %rax
	subq	$2, %r14
.L2264:
	movq	%r9, %r8
.L2258:
	movzwl	(%rax), %esi
	movzwl	(%r14), %edi
	leaq	-2(%r8), %r9
	cmpw	%di, %si
	jl	.L2570
	movw	%si, -2(%r8)
	cmpq	%rax, %rbx
	jnb	.L2326
	cmpq	%r15, %rcx
	jnb	.L2326
	movq	%rax, %rdx
	leaq	-2(%r15), %r14
	subq	$2, %rax
	jmp	.L2264
	.p2align 4,,10
	.p2align 3
.L2318:
	movzwl	(%rbx), %eax
	movzwl	(%r15), %edi
	leaq	2(%rcx), %r9
	cmpw	%ax, %di
	jge	.L2234
.L2571:
	addq	$2, %r15
	movw	%di, (%rcx)
	cmpq	%r8, %r15
	jnb	.L2336
	cmpq	%rdx, %rsi
	jnb	.L2336
.L2238:
	movzwl	(%r15), %edi
	movq	%r9, %rcx
	leaq	2(%rcx), %r9
	cmpw	%ax, %di
	jl	.L2571
.L2234:
	addq	$2, %rsi
	movw	%ax, (%rcx)
	cmpq	%rdx, %rsi
	jnb	.L2336
	cmpq	%r8, %r15
	jnb	.L2336
	movzwl	(%rsi), %eax
	jmp	.L2238
	.p2align 4,,10
	.p2align 3
.L2556:
	addq	%r9, %rcx
	cmpq	%rsi, %rcx
	jne	.L2537
	jmp	.L2188
	.p2align 4,,10
	.p2align 3
.L2193:
	movq	8(%rsp), %rcx
	leaq	1(%rdx), %rax
	jmp	.L2196
	.p2align 4,,10
	.p2align 3
.L2549:
	addq	%rdx, %rcx
	cmpq	%rsi, %rcx
	jne	.L2538
	jmp	.L2188
	.p2align 4,,10
	.p2align 3
.L2303:
	leaq	0(%rbp,%rcx), %r9
	cmpq	%r8, %rdx
	jnb	.L2487
.L2177:
	movzbl	(%r14), %edi
.L2179:
	movq	%r8, %rax
	subq	%rdx, %rax
	shrq	%rax
	addq	%rdx, %rax
	cmpb	(%r9,%rax), %dil
	jnb	.L2178
	cmpq	%rax, %rdx
	jnb	.L2487
	movq	%rax, %r8
	jmp	.L2179
	.p2align 4,,10
	.p2align 3
.L2178:
	leaq	1(%rax), %rdx
	cmpq	%r8, %rdx
	jb	.L2177
.L2487:
	addq	%rdx, %rcx
	cmpq	%rcx, %rsi
	je	.L2188
	leaq	-1(%rbp,%rsi), %r8
.L2309:
	movq	16(%rsp), %rdi
	xorl	%eax, %eax
.L2190:
	cmpq	%rdi, %rax
	jnb	.L2208
	movzbl	(%r8), %r9d
.L2200:
	movq	%rdi, %rdx
	subq	%rax, %rdx
	shrq	%rdx
	addq	%rax, %rdx
	cmpb	%r9b, (%r14,%rdx)
	jb	.L2199
	cmpq	%rdx, %rax
	jnb	.L2208
	movq	%rdx, %rdi
	jmp	.L2200
	.p2align 4,,10
	.p2align 3
.L2199:
	leaq	1(%rdx), %rax
	jmp	.L2190
	.p2align 4,,10
	.p2align 3
.L2261:
	movb	%sil, -1(%r8)
	cmpq	%r15, %rcx
	jnb	.L2326
	cmpq	%rax, %rbx
	jnb	.L2326
	movq	%rax, %rdx
	leaq	-1(%r15), %r14
	movq	%r9, %r8
	subq	$1, %rax
	jmp	.L2259
	.p2align 4,,10
	.p2align 3
.L2565:
	movb	%al, (%rcx)
	addq	$1, %rsi
	movq	%r9, %rcx
	cmpq	%r8, %r15
	jnb	.L2211
	cmpq	%rdx, %rsi
	jb	.L2232
	cmpq	%rdx, %rsi
	jnb	.L2188
	jmp	.L2560
	.p2align 4,,10
	.p2align 3
.L2486:
	addq	%rdx, %rcx
	cmpq	%rcx, %rsi
	je	.L2188
	leaq	-2(%rbp,%rsi,2), %r8
.L2310:
	movq	%rbx, 8(%rsp)
	movq	16(%rsp), %r9
	xorl	%eax, %eax
	jmp	.L2191
	.p2align 4,,10
	.p2align 3
.L2572:
	leaq	1(%rdx), %rax
.L2191:
	cmpq	%r9, %rax
	jnb	.L2517
	movzwl	(%r8), %ebx
.L2198:
	movq	%r9, %rdx
	subq	%rax, %rdx
	shrq	%rdx
	addq	%rax, %rdx
	leaq	0(%rbp,%rdx,2), %r11
	cmpw	%bx, (%r11,%rdi)
	jb	.L2572
	cmpq	%rdx, %rax
	jnb	.L2517
	movq	%rdx, %r9
	jmp	.L2198
.L2517:
	movq	8(%rsp), %rbx
	jmp	.L2208
.L2325:
	movq	%r9, %r8
	jmp	.L2243
.L2326:
	movq	%r9, %r8
	movq	%rax, %rdx
	jmp	.L2243
.L2056:
	cmpq	$2, %r13
	je	.L2076
	cmpq	$4, %r13
	je	.L2077
	movzbl	(%rdi), %edi
	cmpb	%dil, (%rdx)
	leaq	2(%r14), %rdx
	jb	.L2573
	cmpq	%rbp, %rdx
	jnb	.L2102
	movq	64(%rsp), %rdi
	movzbl	(%rdi,%r8), %eax
.L2094:
	movl	%eax, %ecx
	movzbl	(%rdi,%rdx), %eax
	cmpb	%cl, %al
	jnb	.L2093
	leaq	-1(%rdx), %rax
	subq	%r14, %rax
	leaq	1(%rax), %rcx
	cmpq	104(%rsp), %rcx
	jnb	.L2111
.L2546:
	movq	%rbp, %rdx
	leaq	(%rcx,%r14), %rax
	subq	%r14, %rdx
	cmpq	104(%rsp), %rdx
	jnb	.L2274
	movq	%rbp, 8(%rsp)
	movq	%rdx, %rcx
	jmp	.L2112
.L2547:
	leaq	1(%r14), %r8
	movl	$1, %esi
	movq	%r8, %rax
	cmpq	%r8, %rbp
	jne	.L2273
	movl	$1, %ecx
	cmpq	$1, 104(%rsp)
	jbe	.L2274
.L2275:
	leaq	-3(%rsi,%rsi,2), %rax
	xorl	%edi, %edi
	movq	136(%rsp,%rax,8), %rdx
	movq	128(%rsp,%rax,8), %rax
	leaq	(%rdx,%rax,2), %rax
	addq	%rax, %rdx
	addq	%rcx, %rdx
	jmp	.L2163
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L2574:
	subq	%rbp, %rax
	subq	%rbp, %rdx
.L2161:
	addq	%rax, %rax
	addq	%rdx, %rdx
.L2163:
	addl	$1, %edi
	cmpq	%rbp, %rax
	jnb	.L2574
	cmpq	%rbp, %rdx
	jb	.L2161
	movl	%edi, 32(%rsp)
	cmpq	$1, %rsi
	je	.L2327
	movq	%rsi, %r11
	jmp	.L2276
.L2055:
	movl	$1, %ecx
	cmpq	$1, 104(%rsp)
	ja	.L2111
.L2274:
	movq	104(%rsp), %rcx
	leaq	(%rcx,%r14), %rdi
	movq	%rdi, 8(%rsp)
.L2112:
	cmpq	8(%rsp), %rax
	jnb	.L2111
	cmpq	$1, %r13
	je	.L2114
	leaq	-1(%rax), %rdx
	movq	64(%rsp), %rdi
	movq	%rbx, 40(%rsp)
	imulq	%r13, %rdx
	movq	%rcx, 48(%rsp)
	leaq	-8(%rdi,%rax,4), %r12
	movq	%rbp, 72(%rsp)
	movq	%rsi, 56(%rsp)
	leaq	(%rdi,%rdx), %r11
	movq	%rdx, 88(%rsp)
	movq	%rdx, %r15
	leaq	-4(%rdi,%rax,2), %rdx
	movq	%r13, %rdi
	movq	%rdx, %rsi
	imulq	%rax, %rdi
	movq	%rdi, 80(%rsp)
	movl	28(%rsp), %edi
.L2146:
	testl	%edi, %edi
	jne	.L2116
.L2115:
	cmpq	$2, %r13
	je	.L2141
	movq	80(%rsp), %rbx
	movq	%r11, %rdx
	subq	88(%rsp), %rdx
	movl	(%rdx,%rbx), %ebx
	movl	%ebx, 32(%rsp)
	cmpl	(%r11), %ebx
	jge	.L2142
.L2138:
	movl	%ebx, %edx
	movw	%bx, 16(%rsp)
	movl	%ebx, %r10d
	movabsq	$-4294967296, %rcx
	andq	96(%rsp), %rcx
	orq	%rdx, %rcx
	leaq	-1(%rax), %rdx
	movq	%rcx, 96(%rsp)
	movq	%r11, %rcx
	cmpq	$2, %r13
	je	.L2301
.L2578:
	movl	%ebx, 16(%rsp)
	movq	%r12, %r10
	movq	%r11, %r8
	leaq	4(%r15), %rbp
.L2118:
	movl	(%rcx), %ebx
	movq	%r8, %r9
	subq	%r15, %r9
	movl	%ebx, (%r9,%rbp)
	cmpq	%rdx, %r14
	jnb	.L2126
	testl	%edi, %edi
	jne	.L2575
	movl	32(%rsp), %ebx
	cmpl	(%r10), %ebx
	jge	.L2121
.L2480:
	subq	$4, %r8
	subq	$4, %r10
	subq	$1, %rdx
	movq	%r8, %rcx
	jmp	.L2118
.L2576:
	addq	$1, %rax
	cmpq	8(%rsp), %rax
	je	.L2508
	addq	$4, %r11
	addq	$4, %r15
	addq	$4, %r12
	addq	$2, %rsi
.L2116:
	cmpq	$2, %r13
	je	.L2134
	movq	80(%rsp), %rbx
	movq	%r11, %rdx
	subq	88(%rsp), %rdx
	movl	(%rdx,%rbx), %ebx
	cmpl	(%r11), %ebx
	jnb	.L2576
	movl	%ebx, 32(%rsp)
	jmp	.L2138
.L2577:
	addq	$1, %rax
	cmpq	%rax, 8(%rsp)
	je	.L2507
	addq	$2, %r11
	addq	$2, %r15
	addq	$4, %r12
	addq	$2, %rsi
.L2141:
	movq	80(%rsp), %rbx
	movq	%r11, %rdx
	subq	88(%rsp), %rdx
	movzwl	(%rdx,%rbx), %r10d
	movw	%r10w, 16(%rsp)
	cmpw	(%r11), %r10w
	jge	.L2577
.L2140:
	movq	96(%rsp), %rbx
	leaq	-1(%rax), %rdx
	movw	%r10w, %bx
	movq	%rbx, %rcx
	movq	%rcx, 96(%rsp)
	movl	%ecx, %ebx
	movl	%ecx, 32(%rsp)
	movq	%r11, %rcx
	cmpq	$2, %r13
	jne	.L2578
.L2301:
	movq	%rax, 32(%rsp)
	movq	%rsi, %rbx
	movq	%r11, %r9
	leaq	2(%r15), %rbp
.L2117:
	movzwl	(%rcx), %eax
	movq	%r9, %r8
	subq	%r15, %r8
	movw	%ax, (%r8,%rbp)
	cmpq	%rdx, %r14
	jnb	.L2503
	testl	%edi, %edi
	jne	.L2579
	movzwl	16(%rsp), %eax
	cmpw	(%rbx), %ax
	jge	.L2503
.L2481:
	subq	$2, %r9
	subq	$2, %rbx
	subq	$1, %rdx
	movq	%r9, %rcx
	jmp	.L2117
.L2139:
	addq	$1, %rax
	cmpq	%rax, 8(%rsp)
	je	.L2507
	addq	$2, %r11
	addq	$2, %r15
	addq	$4, %r12
	addq	$2, %rsi
.L2134:
	movq	80(%rsp), %rbx
	movq	%r11, %rdx
	subq	88(%rsp), %rdx
	movzwl	(%rdx,%rbx), %r10d
	cmpw	(%r11), %r10w
	jnb	.L2139
	movw	%r10w, 16(%rsp)
	jmp	.L2140
.L2575:
	movl	16(%rsp), %ebx
	cmpl	(%r10), %ebx
	jb	.L2480
.L2121:
	cmpq	$2, %r13
	je	.L2129
.L2126:
	movl	96(%rsp), %ebx
	movl	%ebx, (%rcx)
.L2132:
	addq	$1, %rax
	addq	%r13, %r11
	addq	%r13, %r15
	addq	$4, %r12
	addq	$2, %rsi
	cmpq	%rax, 8(%rsp)
	jne	.L2146
.L2508:
	movq	40(%rsp), %rbx
	movq	48(%rsp), %rcx
	movq	56(%rsp), %rsi
	movq	72(%rsp), %rbp
	jmp	.L2111
.L2579:
	cmpw	(%rbx), %r10w
	jb	.L2481
.L2503:
	movq	32(%rsp), %rax
.L2129:
	movzwl	96(%rsp), %ebx
	movw	%bx, (%rcx)
	jmp	.L2132
.L2142:
	addq	$1, %rax
	cmpq	%rax, 8(%rsp)
	je	.L2508
	addq	$4, %r11
	addq	$4, %r15
	addq	$4, %r12
	addq	$2, %rsi
	jmp	.L2115
.L2573:
	cmpq	%rbp, %rdx
	jnb	.L2535
	movq	64(%rsp), %rdi
	movzbl	(%rdi,%r8), %eax
.L2075:
	movl	%eax, %ecx
	movzbl	(%rdi,%rdx), %eax
	cmpb	%cl, %al
	jb	.L2580
	leaq	-1(%rdx), %rax
	cmpq	%rax, %r14
	jnb	.L2102
.L2065:
	movq	64(%rsp), %rdi
	movq	%rax, %rcx
	movq	%r14, %rdx
.L2106:
	movzbl	(%rdi,%rdx), %r8d
	movzbl	(%rdi,%rcx), %r9d
	movb	%r9b, (%rdi,%rdx)
	addq	$1, %rdx
	movb	%r8b, (%rdi,%rcx)
	subq	$1, %rcx
	cmpq	%rcx, %rdx
	jb	.L2106
	jmp	.L2102
.L2544:
	leaq	2(%r14), %r9
	cmpq	%rbp, %r9
	jnb	.L2535
.L2062:
	leaq	0(%r13,%rcx), %r11
	leaq	-1(%r9), %rax
	cmpq	$2, %r13
	je	.L2066
	movq	%rdx, %r8
	subq	%rcx, %r8
	cmpq	$4, %r13
	je	.L2096
.L2581:
	movzbl	(%rdx), %r10d
	cmpb	%r10b, (%r8,%r11)
	jge	.L2095
	leaq	1(%r9), %r8
	cmpq	%rbp, %r8
	jnb	.L2296
	addq	$1, %rdx
.L2100:
	movq	%r9, %rax
	movq	%r8, %r9
	movq	%rdx, %r8
	subq	%rcx, %r8
	cmpq	$4, %r13
	jne	.L2581
.L2096:
	movl	(%rdx), %r10d
	cmpl	%r10d, (%r8,%r11)
	jge	.L2095
	leaq	1(%r9), %r8
	cmpq	%rbp, %r8
	jnb	.L2296
	addq	$4, %rdx
	jmp	.L2100
.L2066:
	movq	%rdx, %r8
	movzwl	(%rdx), %r10d
	subq	%rcx, %r8
	cmpw	%r10w, (%r8,%r11)
	jge	.L2095
	leaq	1(%r9), %r8
	addq	$2, %rdx
	movq	%r9, %rax
	cmpq	%rbp, %r8
	jnb	.L2095
	movq	%r8, %r9
	jmp	.L2066
.L2296:
	movq	%r9, %rax
.L2095:
	cmpq	%rax, %r14
	jnb	.L2102
	cmpq	$1, %r13
	je	.L2065
	cmpq	$2, %r13
	je	.L2073
.L2070:
	movq	64(%rsp), %r8
	movq	%rax, %rdx
	leaq	(%rax,%r14), %rcx
.L2103:
	movl	(%rdi), %r9d
	movl	(%r8,%rdx,4), %r10d
	addq	$4, %rdi
	movl	%r10d, -4(%rdi)
	movl	%r9d, (%r8,%rdx,4)
	subq	$1, %rdx
	movq	%rcx, %r9
	subq	%rdx, %r9
	cmpq	%rdx, %r9
	jb	.L2103
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2580:
	leaq	1(%rdx), %rcx
	cmpq	%rbp, %rcx
	jnb	.L2582
	movq	%rcx, %rdx
	jmp	.L2075
.L2093:
	leaq	1(%rdx), %rcx
	cmpq	%rbp, %rcx
	jnb	.L2583
	movq	%rcx, %rdx
	jmp	.L2094
.L2586:
	leaq	2(%r14), %r9
	leaq	2(%rcx), %r11
	cmpq	%rbp, %r9
	jnb	.L2534
.L2072:
	movq	%rdx, %rax
	movzwl	(%rdx), %r10d
	subq	%rcx, %rax
	cmpw	%r10w, (%rax,%r11)
	jb	.L2584
	leaq	-1(%r9), %rax
	cmpq	%rax, %r14
	jnb	.L2102
.L2073:
	movq	64(%rsp), %r8
	movq	%rax, %rdx
	leaq	(%rax,%r14), %rcx
.L2105:
	movzwl	(%rdi), %r9d
	movzwl	(%r8,%rdx,2), %r10d
	addq	$2, %rdi
	movw	%r10w, -2(%rdi)
	movw	%r9w, (%r8,%rdx,2)
	subq	$1, %rdx
	movq	%rcx, %r9
	subq	%rdx, %r9
	cmpq	%rdx, %r9
	jb	.L2105
	jmp	.L2102
.L2077:
	movl	(%rdi), %r11d
	cmpl	%r11d, (%rdx)
	jnb	.L2082
	leaq	2(%r14), %r9
	cmpq	%rbp, %r9
	jnb	.L2533
	leaq	4(%rcx), %r8
	movq	%r9, %rax
.L2069:
	movq	%rdx, %r9
	movl	(%rdx), %r11d
	subq	%rcx, %r9
	cmpl	%r11d, (%r9,%r8)
	jb	.L2585
	subq	$1, %rax
.L2532:
	cmpq	%rax, %r14
	jb	.L2070
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2585:
	leaq	1(%rax), %r9
	addq	$4, %rdx
	cmpq	%rbp, %r9
	jnb	.L2532
	movq	%r9, %rax
	jmp	.L2069
.L2076:
	movzwl	(%rdi), %r11d
	cmpw	%r11w, (%rdx)
	jb	.L2586
	leaq	2(%r14), %rcx
	cmpq	%rbp, %rcx
	jnb	.L2102
	movq	64(%rsp), %rax
	addq	%r8, %r8
	leaq	2(%r8), %rdi
	leaq	(%rax,%r8), %rdx
	movq	%rcx, %rax
	jmp	.L2092
.L2058:
	movl	(%rdi), %r11d
	cmpl	%r11d, (%rdx)
	jge	.L2059
	leaq	2(%r14), %r9
	cmpq	%rbp, %r9
	jb	.L2062
.L2533:
	cmpq	%r8, %r14
	jb	.L2070
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2057:
	movzwl	(%rdi), %r11d
	cmpw	%r11w, (%rdx)
	jge	.L2059
	leaq	2(%r14), %r9
	cmpq	%rbp, %r9
	jb	.L2062
.L2534:
	cmpq	%r8, %r14
	jb	.L2073
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2543:
	movq	%rbx, %rdi
	shrq	%rdi
	imulq	%r13, %rdi
	call	malloc@PLT
	movq	%rax, 120(%rsp)
	testq	%rax, %rax
	jne	.L2051
	xorl	%eax, %eax
	jmp	.L2050
	.p2align 4,,10
	.p2align 3
.L2114:
	movq	64(%rsp), %rdx
	movq	8(%rsp), %r10
	movq	96(%rsp), %r12
	leaq	(%rdx,%rax), %rdi
	leaq	-1(%rdx,%rax), %r11
.L2158:
	movl	28(%rsp), %r15d
	testl	%r15d, %r15d
	je	.L2150
.L2152:
	movzbl	(%rdi), %r9d
	cmpb	(%r11), %r9b
	jnb	.L2587
.L2149:
	movq	64(%rsp), %rdx
	leaq	-1(%rax), %r8
	movb	%r9b, %r12b
	leaq	-1(%rdx,%rax), %rdx
	movzbl	(%rdx), %r15d
	movb	%r15b, 1(%rdx)
	cmpq	%r8, %r14
	jnb	.L2153
	cmpl	$0, 28(%rsp)
	je	.L2156
.L2154:
	cmpb	-1(%rdx), %r9b
	jb	.L2588
	addq	$1, %rax
	movb	%r12b, (%rdx)
	cmpq	%rax, %r10
	je	.L2514
	addq	$1, %rdi
	addq	$1, %r11
	jmp	.L2152
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L2589:
	movzbl	-1(%rdx), %r15d
	subq	$1, %r8
	subq	$1, %rdx
	movb	%r15b, 1(%rdx)
	cmpq	%r8, %r14
	jnb	.L2153
.L2156:
	cmpb	-1(%rdx), %r9b
	jl	.L2589
	addq	$1, %rax
	movb	%r12b, (%rdx)
	cmpq	%rax, %r10
	je	.L2514
	addq	$1, %rdi
	addq	$1, %r11
.L2150:
	movzbl	(%rdi), %r9d
	cmpb	(%r11), %r9b
	jl	.L2149
	addq	$1, %rax
	addq	$1, %rdi
	addq	$1, %r11
	cmpq	%rax, %r10
	jne	.L2150
.L2514:
	movq	%r12, 96(%rsp)
	jmp	.L2111
	.p2align 4,,10
	.p2align 3
.L2588:
	movzbl	-1(%rdx), %r15d
	subq	$1, %r8
	subq	$1, %rdx
	movb	%r15b, 1(%rdx)
	cmpq	%r8, %r14
	jb	.L2154
.L2153:
	addq	$1, %rax
	movb	%r12b, (%rdx)
	addq	$1, %rdi
	addq	$1, %r11
	cmpq	%r10, %rax
	jne	.L2158
	movq	%r12, 96(%rsp)
	jmp	.L2111
	.p2align 4,,10
	.p2align 3
.L2584:
	leaq	1(%r9), %rax
	addq	$2, %rdx
	cmpq	%rbp, %rax
	jnb	.L2590
	movq	%rax, %r9
	jmp	.L2072
.L2082:
	leaq	2(%r14), %rcx
	cmpq	%rbp, %rcx
	jnb	.L2102
	movq	64(%rsp), %rax
	salq	$2, %r8
	leaq	4(%r8), %rdi
	leaq	(%rax,%r8), %rdx
	movq	%rcx, %rax
	jmp	.L2088
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L2291:
	movq	%rcx, %rax
.L2088:
	movq	%rdx, %rcx
	movl	(%rdx), %r11d
	subq	%r8, %rcx
	cmpl	%r11d, (%rcx,%rdi)
	jb	.L2087
	leaq	1(%rax), %rcx
	addq	$4, %rdx
	cmpq	%rbp, %rcx
	jb	.L2291
	jmp	.L2102
.L2587:
	addq	$1, %rax
	addq	$1, %rdi
	addq	$1, %r11
	cmpq	%rax, %r10
	jne	.L2152
	jmp	.L2514
.L2583:
	movq	%rdx, %rax
	jmp	.L2102
.L2582:
	movq	%rdx, %rax
	cmpq	%rdx, %r14
	jb	.L2065
	jmp	.L2102
	.p2align 4,,10
	.p2align 3
.L2507:
	movq	40(%rsp), %rbx
	movq	48(%rsp), %rcx
	movl	%edi, 28(%rsp)
	movq	56(%rsp), %rsi
	movq	72(%rsp), %rbp
	jmp	.L2111
.L2327:
	movl	$1, %r11d
	jmp	.L2269
.L2299:
	movq	%rdi, %rax
	jmp	.L2102
.L2283:
	movq	%rsi, 104(%rsp)
	movq	$0, 120(%rsp)
	jmp	.L2051
.L2590:
	movq	%r9, %rax
	cmpq	%r9, %r14
	jb	.L2073
	jmp	.L2102
.L2548:
	call	__stack_chk_fail@PLT
	.p2align 4,,10
	.p2align 3
.L2535:
	cmpq	%r8, %r14
	jb	.L2065
	jmp	.L2102
	.cfi_endproc
.LFE86:
	.size	sort_generic, .-sort_generic
	.p2align 4
	.globl	myl_native_list_new
	.type	myl_native_list_new, @function
myl_native_list_new:
.LFB51:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$88, %rsp
	.cfi_def_cfa_offset 128
	movq	%fs:40, %rax
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	testq	%rsi, %rsi
	je	.L2599
	movq	%rdi, %rbx
	movq	%rsi, %rbp
	movq	%rdx, %r12
	testq	%rdi, %rdi
	je	.L2594
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.L2594
	movl	112(%rdi), %r14d
	cmpq	272(%rax), %rsi
	je	.L2595
	call	myl_rc_native_shape@PLT
	testq	%rax, %rax
	je	.L2599
	movq	5640(%rbx), %rax
.L2595:
	cmpb	$0, 288(%rax)
	je	.L2625
.L2597:
	movl	%r14d, %ecx
	movl	$1, %edx
	leaq	myl_native_list_header_descriptor(%rip), %rsi
	movq	%rbx, %rdi
	call	myl_rc_storage_alloc@PLT
	movq	%rax, %r8
	testq	%rax, %rax
	je	.L2599
	movq	%rbp, 24(%rax)
	testq	%r12, %r12
	jne	.L2626
.L2600:
	movq	%r12, 8(%r8)
.L2591:
	movq	72(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L2627
	addq	$88, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movq	%r8, %rax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2594:
	.cfi_restore_state
	movl	$1, %edx
	leaq	myl_native_list_header_descriptor(%rip), %rsi
	movq	%rbx, %rdi
	call	myl_native_heap_alloc@PLT
	movq	%rax, 24(%rsp)
	testq	%rax, %rax
	je	.L2599
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	leaq	24(%rsp), %rdx
	movq	%rbx, %rdi
	leaq	32(%rsp), %rsi
	call	myl_native_root_push@PLT
	movq	24(%rsp), %rcx
	movq	%rbp, 24(%rcx)
	testq	%r12, %r12
	je	.L2601
	movq	%r12, %rdx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	movq	%rcx, 8(%rsp)
	call	myl_native_heap_alloc@PLT
	movq	8(%rsp), %rcx
	movq	%rax, 32(%rcx)
	movq	24(%rsp), %rcx
	cmpq	$0, 32(%rcx)
	je	.L2628
.L2601:
	movq	%r12, 8(%rcx)
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdi
	call	myl_native_root_pop@PLT
	movq	24(%rsp), %r8
	jmp	.L2591
	.p2align 4,,10
	.p2align 3
.L2625:
	leaq	rc_list_module(%rip), %rsi
	movq	%rbx, %rdi
	call	myl_rc_module_register@PLT
	testl	%eax, %eax
	je	.L2598
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	myl_rc_record_failure@PLT
.L2599:
	xorl	%r8d, %r8d
	jmp	.L2591
	.p2align 4,,10
	.p2align 3
.L2626:
	movl	%r14d, %ecx
	movq	%r12, %rdx
	movq	%rbp, %rsi
	movq	%rbx, %rdi
	movq	%rax, 8(%rsp)
	call	myl_rc_native_storage@PLT
	movq	8(%rsp), %r8
	movq	%rax, 32(%r8)
	testq	%rax, %rax
	jne	.L2600
	movq	%r8, %rsi
	movq	%rbx, %rdi
	call	myl_rc_native_abort@PLT
	jmp	.L2599
	.p2align 4,,10
	.p2align 3
.L2598:
	movq	5640(%rbx), %rax
	movb	$1, 288(%rax)
	jmp	.L2597
.L2628:
	leaq	32(%rsp), %rsi
	movq	%rbx, %rdi
	call	myl_native_root_pop@PLT
	jmp	.L2599
.L2627:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE51:
	.size	myl_native_list_new, .-myl_native_list_new
	.p2align 4
	.globl	myl_native_list_get
	.type	myl_native_list_get, @function
myl_native_list_get:
.LFB56:
	.cfi_startproc
	endbr64
	cmpq	(%rdi), %rsi
	jnb	.L2645
	movq	24(%rdi), %rax
	movq	%rdx, %rcx
	movq	(%rax), %rdx
	imulq	%rdx, %rsi
	addq	32(%rdi), %rsi
	cmpq	$64, %rdx
	ja	.L2631
	leaq	.L2633(%rip), %rdi
	movslq	(%rdi,%rdx,4), %rax
	addq	%rdi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L2633:
	.long	.L2631-.L2633
	.long	.L2642-.L2633
	.long	.L2641-.L2633
	.long	.L2631-.L2633
	.long	.L2640-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2639-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2638-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2637-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2636-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2635-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2634-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2631-.L2633
	.long	.L2632-.L2633
	.text
	.p2align 4,,10
	.p2align 3
.L2645:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2631:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$1, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2632:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rcx)
	movdqu	48(%rsi), %xmm0
	movups	%xmm0, 48(%rcx)
.L2647:
	movl	$1, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2634:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movdqu	32(%rsi), %xmm0
	movups	%xmm0, 32(%rcx)
	movq	48(%rsi), %rax
	movq	%rax, 48(%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2635:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movq	32(%rsi), %rax
	movq	%rax, 32(%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2636:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2637:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2638:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2639:
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2640:
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2641:
	movzwl	(%rsi), %eax
	movw	%ax, (%rcx)
	jmp	.L2647
	.p2align 4,,10
	.p2align 3
.L2642:
	movzbl	(%rsi), %eax
	movb	%al, (%rcx)
	jmp	.L2647
	.cfi_endproc
.LFE56:
	.size	myl_native_list_get, .-myl_native_list_get
	.p2align 4
	.globl	myl_native_list_set
	.type	myl_native_list_set, @function
myl_native_list_set:
.LFB57:
	.cfi_startproc
	endbr64
	cmpq	(%rdi), %rsi
	jnb	.L2666
	movq	24(%rdi), %rax
	movq	%rdx, %rcx
	movq	(%rax), %rdx
	imulq	%rdx, %rsi
	addq	32(%rdi), %rsi
	movq	%rsi, %rdi
	cmpq	$64, %rdx
	ja	.L2652
	leaq	.L2654(%rip), %rsi
	movslq	(%rsi,%rdx,4), %rax
	addq	%rsi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L2654:
	.long	.L2652-.L2654
	.long	.L2663-.L2654
	.long	.L2662-.L2654
	.long	.L2652-.L2654
	.long	.L2661-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2660-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2659-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2658-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2657-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2656-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2655-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2652-.L2654
	.long	.L2653-.L2654
	.text
	.p2align 4,,10
	.p2align 3
.L2666:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2652:
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	movq	%rcx, %rsi
	call	memcpy@PLT
	movl	$1, %eax
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2653:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rcx), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%rcx), %xmm0
	movups	%xmm0, 48(%rdi)
.L2668:
	movl	$1, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2655:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rcx), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%rcx), %rax
	movq	%rax, 48(%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2656:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%rcx), %rax
	movq	%rax, 32(%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2657:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2658:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%rcx), %rax
	movq	%rax, 16(%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2659:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2660:
	movq	(%rcx), %rax
	movq	%rax, (%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2661:
	movl	(%rcx), %eax
	movl	%eax, (%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2662:
	movzwl	(%rcx), %eax
	movw	%ax, (%rdi)
	jmp	.L2668
	.p2align 4,,10
	.p2align 3
.L2663:
	movzbl	(%rcx), %eax
	movb	%al, (%rdi)
	jmp	.L2668
	.cfi_endproc
.LFE57:
	.size	myl_native_list_set, .-myl_native_list_set
	.p2align 4
	.globl	myl_native_list_pop
	.type	myl_native_list_pop, @function
myl_native_list_pop:
.LFB58:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	xorl	%edx, %edx
	testq	%rax, %rax
	je	.L2690
	cmpq	$-1, 16(%rdi)
	je	.L2690
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	leaq	-1(%rax), %rcx
	movq	24(%rdi), %rax
	movq	%rsi, %r9
	movq	%rcx, (%rdi)
	movq	%rdi, %r8
	movq	(%rax), %rdx
	imulq	%rdx, %rcx
	addq	32(%rdi), %rcx
	cmpq	$64, %rdx
	ja	.L2673
	leaq	.L2675(%rip), %rsi
	movslq	(%rsi,%rdx,4), %rax
	addq	%rsi, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L2675:
	.long	.L2673-.L2675
	.long	.L2684-.L2675
	.long	.L2683-.L2675
	.long	.L2673-.L2675
	.long	.L2682-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2681-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2680-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2679-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2678-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2677-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2676-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2673-.L2675
	.long	.L2674-.L2675
	.text
	.p2align 4,,10
	.p2align 3
.L2690:
	.cfi_def_cfa_offset 8
	movl	%edx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2673:
	.cfi_def_cfa_offset 32
	movq	%rcx, %rsi
	movq	%r9, %rdi
	movq	%r8, 8(%rsp)
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %r8
	movq	(%rsp), %rcx
.L2685:
	movq	24(%r8), %rax
	xorl	%esi, %esi
	movq	%rcx, %rdi
	movq	%r8, (%rsp)
	movq	(%rax), %rdx
	call	memset@PLT
	movq	(%rsp), %r8
	movl	$1, %eax
	addq	$1, 16(%r8)
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L2684:
	.cfi_restore_state
	movzbl	(%rcx), %eax
	movb	%al, (%r9)
	jmp	.L2685
.L2683:
	movzwl	(%rcx), %eax
	movw	%ax, (%r9)
	jmp	.L2685
.L2682:
	movl	(%rcx), %eax
	movl	%eax, (%r9)
	jmp	.L2685
.L2681:
	movq	(%rcx), %rax
	movq	%rax, (%r9)
	jmp	.L2685
.L2680:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	jmp	.L2685
.L2679:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	movq	16(%rcx), %rax
	movq	%rax, 16(%r9)
	jmp	.L2685
.L2678:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%r9)
	jmp	.L2685
.L2677:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%r9)
	movq	32(%rcx), %rax
	movq	%rax, 32(%r9)
	jmp	.L2685
.L2676:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%r9)
	movdqu	32(%rcx), %xmm0
	movups	%xmm0, 32(%r9)
	movq	48(%rcx), %rax
	movq	%rax, 48(%r9)
	jmp	.L2685
.L2674:
	movdqu	(%rcx), %xmm0
	movups	%xmm0, (%r9)
	movdqu	16(%rcx), %xmm0
	movups	%xmm0, 16(%r9)
	movdqu	32(%rcx), %xmm0
	movups	%xmm0, 32(%r9)
	movdqu	48(%rcx), %xmm0
	movups	%xmm0, 48(%r9)
	jmp	.L2685
	.cfi_endproc
.LFE58:
	.size	myl_native_list_pop, .-myl_native_list_pop
	.p2align 4
	.globl	myl_native_list_clear
	.type	myl_native_list_clear, @function
myl_native_list_clear:
.LFB59:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rdx
	testq	%rdx, %rdx
	je	.L2701
	xorl	%eax, %eax
	cmpq	$-1, 16(%rdi)
	je	.L2702
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	24(%rdi), %rax
	movq	%rdi, %rcx
	movq	32(%rdi), %rdi
	xorl	%esi, %esi
	movq	%rcx, 8(%rsp)
	imulq	(%rax), %rdx
	call	memset@PLT
	movq	8(%rsp), %rcx
	movl	$1, %eax
	addq	$1, 16(%rcx)
	movq	$0, (%rcx)
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2702:
	ret
	.p2align 4,,10
	.p2align 3
.L2701:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE59:
	.size	myl_native_list_clear, .-myl_native_list_clear
	.p2align 4
	.globl	myl_native_list_index
	.type	myl_native_list_index, @function
myl_native_list_index:
.LFB63:
	.cfi_startproc
	endbr64
	cmpq	$0, (%rdi)
	je	.L2713
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rdx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	xorl	%ebx, %ebx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	jmp	.L2709
	.p2align 4,,10
	.p2align 3
.L2718:
	jne	.L2716
	addq	$1, %rbx
	cmpq	0(%rbp), %rbx
	jnb	.L2717
.L2709:
	movq	24(%rbp), %rdi
	movq	%r12, %rdx
	movq	(%rdi), %rsi
	imulq	%rbx, %rsi
	addq	32(%rbp), %rsi
	call	myl_native_equal@PLT
	testl	%eax, %eax
	jns	.L2718
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2717:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2716:
	.cfi_restore_state
	movq	%rbx, 0(%r13)
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
.L2713:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE63:
	.size	myl_native_list_index, .-myl_native_list_index
	.p2align 4
	.globl	myl_native_list_remove
	.type	myl_native_list_remove, @function
myl_native_list_remove:
.LFB64:
	.cfi_startproc
	endbr64
	cmpq	$0, (%rdi)
	je	.L2739
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	xorl	%ebx, %ebx
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	jmp	.L2720
	.p2align 4,,10
	.p2align 3
.L2742:
	jne	.L2740
	addq	$1, %rbx
	cmpq	0(%rbp), %rbx
	jnb	.L2741
.L2720:
	movq	24(%rbp), %rdi
	movq	%r12, %rdx
	movq	(%rdi), %rsi
	imulq	%rbx, %rsi
	addq	32(%rbp), %rsi
	call	myl_native_equal@PLT
	testl	%eax, %eax
	jns	.L2742
.L2728:
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2740:
	.cfi_restore_state
	cmpq	$-1, 16(%rbp)
	je	.L2728
	movq	24(%rbp), %rax
	movq	32(%rbp), %r12
	movq	(%rax), %rcx
	movq	0(%rbp), %rax
	subq	$1, %rax
	movq	%rax, %rdx
	subq	%rbx, %rdx
	jne	.L2743
.L2725:
	imulq	%rcx, %rax
	movq	%rcx, %rdx
	xorl	%esi, %esi
	leaq	(%r12,%rax), %rdi
	call	memset@PLT
	subq	$1, 0(%rbp)
	movl	$1, %eax
	addq	$1, 16(%rbp)
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2741:
	.cfi_restore_state
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2743:
	.cfi_restore_state
	addq	$1, %rbx
	imulq	%rcx, %rdx
	movq	%rcx, 8(%rsp)
	imulq	%rcx, %rbx
	leaq	(%r12,%rbx), %rsi
	subq	%rcx, %rbx
	leaq	(%r12,%rbx), %rdi
	call	memmove@PLT
	movq	0(%rbp), %rax
	movq	8(%rsp), %rcx
	subq	$1, %rax
	jmp	.L2725
.L2739:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE64:
	.size	myl_native_list_remove, .-myl_native_list_remove
	.p2align 4
	.globl	myl_native_list_pop_at
	.type	myl_native_list_pop_at, @function
myl_native_list_pop_at:
.LFB65:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rax
	xorl	%ecx, %ecx
	testq	%rax, %rax
	je	.L2758
	cmpq	$-1, 16(%rdi)
	je	.L2758
	testq	%rsi, %rsi
	js	.L2760
	movq	%rsi, %r8
	cmpq	%rax, %rsi
	jnb	.L2758
.L2747:
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%r8, %r10
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 64
	movq	32(%rdi), %r9
	movq	%rdx, %rdi
	movq	24(%rbx), %rdx
	movq	%r8, 24(%rsp)
	movq	(%rdx), %rcx
	movq	%r9, 8(%rsp)
	imulq	%rcx, %r10
	movq	%rcx, %rdx
	movq	%rcx, (%rsp)
	leaq	(%r9,%r10), %rsi
	movq	%r10, 16(%rsp)
	movq	%rsi, %r14
	call	memcpy@PLT
	movq	(%rbx), %rax
	movq	(%rsp), %rcx
	movq	8(%rsp), %r9
	movq	16(%rsp), %r10
	subq	$1, %rax
	movq	%rax, %rdx
	subq	24(%rsp), %rdx
	jne	.L2761
.L2748:
	imulq	%rcx, %rax
	movq	%rcx, %rdx
	xorl	%esi, %esi
	leaq	(%r9,%rax), %rdi
	call	memset@PLT
	subq	$1, (%rbx)
	movl	$1, %eax
	addq	$1, 16(%rbx)
	addq	$40, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2760:
	.cfi_restore 3
	.cfi_restore 14
	addq	%rsi, %rax
	movq	%rax, %r8
	jns	.L2747
.L2758:
	movl	%ecx, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2761:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -24
	.cfi_offset 14, -16
	imulq	%rcx, %rdx
	leaq	(%r10,%rcx), %rsi
	movq	%r14, %rdi
	movq	%rcx, 8(%rsp)
	addq	%r9, %rsi
	movq	%r9, (%rsp)
	call	memmove@PLT
	movq	(%rbx), %rax
	movq	8(%rsp), %rcx
	movq	(%rsp), %r9
	subq	$1, %rax
	jmp	.L2748
	.cfi_endproc
.LFE65:
	.size	myl_native_list_pop_at, .-myl_native_list_pop_at
	.p2align 4
	.globl	myl_native_list_reverse
	.type	myl_native_list_reverse, @function
myl_native_list_reverse:
.LFB66:
	.cfi_startproc
	endbr64
	movq	(%rdi), %rsi
	movq	%rsi, %rax
	shrq	%rax
	je	.L2804
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	24(%rdi), %rax
	movq	(%rax), %r10
	testq	%r10, %r10
	je	.L2762
	movq	32(%rdi), %r9
	movq	%r10, %r12
	leaq	-1(%r10), %rbx
	xorl	%r8d, %r8d
	xorl	%r11d, %r11d
	shrq	$4, %r12
	movq	%r9, %rdx
	.p2align 4
	.p2align 3
.L2774:
	subq	$1, %rsi
	subq	%r11, %rsi
	imulq	%r10, %rsi
	cmpq	$6, %rbx
	jbe	.L2777
	leaq	16(%rsi), %rax
	cmpq	%r8, %rax
	jle	.L2779
	leaq	16(%r8), %rax
	cmpq	%rax, %rsi
	jl	.L2777
.L2779:
	cmpq	$14, %rbx
	jbe	.L2778
	movq	%r12, %rcx
	leaq	(%r9,%rsi), %rdi
	xorl	%eax, %eax
	salq	$4, %rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L2768:
	movdqu	(%rdx,%rax), %xmm0
	movdqu	(%rdi,%rax), %xmm1
	movups	%xmm1, (%rdx,%rax)
	movups	%xmm0, (%rdi,%rax)
	addq	$16, %rax
	cmpq	%rcx, %rax
	jne	.L2768
	cmpq	%rcx, %r10
	je	.L2807
	movq	%r10, %rax
	subq	%rcx, %rax
	leaq	-1(%rax), %rdi
	cmpq	$6, %rdi
	jbe	.L2770
.L2767:
	leaq	(%rsi,%rcx), %rdi
	leaq	(%rcx,%r8), %r13
	movq	(%r9,%r13), %xmm0
	movq	(%r9,%rdi), %xmm1
	movq	%xmm1, (%r9,%r13)
	movq	%xmm0, (%r9,%rdi)
	testb	$7, %al
	je	.L2807
	andq	$-8, %rax
	addq	%rax, %rcx
.L2770:
	leaq	(%rsi,%rcx), %rax
	leaq	(%rcx,%r8), %rdi
	movzbl	(%r9,%rax), %r14d
	movzbl	(%r9,%rdi), %r13d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	leaq	1(%rcx), %rax
	cmpq	%r10, %rax
	jnb	.L2807
	leaq	(%rax,%r8), %rdi
	addq	%rsi, %rax
	movzbl	(%r9,%rax), %r14d
	movzbl	(%r9,%rdi), %r13d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	leaq	2(%rcx), %rax
	cmpq	%r10, %rax
	jnb	.L2807
	leaq	(%rax,%r8), %rdi
	addq	%rsi, %rax
	movzbl	(%r9,%rax), %r14d
	movzbl	(%r9,%rdi), %r13d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	leaq	3(%rcx), %rax
	cmpq	%r10, %rax
	jnb	.L2807
	leaq	(%rax,%r8), %rdi
	addq	%rsi, %rax
	movzbl	(%r9,%rax), %r14d
	movzbl	(%r9,%rdi), %r13d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	leaq	4(%rcx), %rax
	cmpq	%r10, %rax
	jnb	.L2807
	leaq	(%r8,%rax), %rdi
	addq	%rsi, %rax
	movzbl	(%r9,%rax), %r14d
	movzbl	(%r9,%rdi), %r13d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	leaq	5(%rcx), %rax
	cmpq	%r10, %rax
	jnb	.L2807
	leaq	(%r8,%rax), %rdi
	addq	%rsi, %rax
	addq	$6, %rcx
	movzbl	(%r9,%rdi), %r13d
	movzbl	(%r9,%rax), %r14d
	movb	%r14b, (%r9,%rdi)
	movb	%r13b, (%r9,%rax)
	cmpq	%r10, %rcx
	jnb	.L2807
	leaq	(%r8,%rcx), %rax
	addq	%rsi, %rcx
	movzbl	(%r9,%rax), %edi
	movzbl	(%r9,%rcx), %esi
	movb	%sil, (%r9,%rax)
	movb	%dil, (%r9,%rcx)
.L2807:
	addq	%r10, %rdx
.L2773:
	movq	0(%rbp), %rsi
	addq	$1, %r11
	addq	%r10, %r8
	movq	%rsi, %rax
	shrq	%rax
	cmpq	%rax, %r11
	jb	.L2774
.L2762:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2777:
	.cfi_restore_state
	movq	%rdx, %rax
	addq	%r10, %rdx
	.p2align 5
	.p2align 4
	.p2align 3
.L2772:
	movq	%rax, %rcx
	movzbl	(%rax), %edi
	addq	$1, %rax
	subq	%r8, %rcx
	movzbl	(%rcx,%rsi), %r13d
	movb	%r13b, -1(%rax)
	movb	%dil, (%rcx,%rsi)
	cmpq	%rax, %rdx
	jne	.L2772
	jmp	.L2773
.L2778:
	movq	%r10, %rax
	xorl	%ecx, %ecx
	jmp	.L2767
.L2804:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	ret
	.cfi_endproc
.LFE66:
	.size	myl_native_list_reverse, .-myl_native_list_reverse
	.p2align 4
	.globl	myl_native_list_sort
	.type	myl_native_list_sort, @function
myl_native_list_sort:
.LFB87:
	.cfi_startproc
	endbr64
	cmpl	$4, %esi
	ja	.L2823
	movq	(%rdi), %r8
	cmpq	$1, %r8
	jbe	.L2819
	movq	24(%rdi), %rax
	movq	(%rax), %rcx
	leaq	-1(%rcx), %rax
	cmpq	$1, %rax
	jbe	.L2810
	cmpq	$4, %rcx
	je	.L2810
	cmpq	$8, %rcx
	jne	.L2823
	movq	%r8, %rax
	shrq	$61, %rax
	jne	.L2823
	movq	32(%rdi), %rdi
	cmpl	$2, %esi
	je	.L2831
	cmpl	$3, %esi
	je	.L2832
	cmpl	$4, %esi
	je	.L2833
	testl	%esi, %esi
	movq	%r8, %rsi
	jne	.L2817
	jmp	sort_i64
	.p2align 4,,10
	.p2align 3
.L2823:
	xorl	%r9d, %r9d
.L2808:
	movl	%r9d, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2810:
	xorl	%r9d, %r9d
	cmpl	$1, %esi
	ja	.L2808
	movq	%r8, %rax
	mulq	%rcx
	jo	.L2808
	movq	32(%rdi), %rdi
	movl	%esi, %edx
	movq	%r8, %rsi
	jmp	sort_generic
	.p2align 4,,10
	.p2align 3
.L2819:
	movl	$1, %r9d
	movl	%r9d, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L2833:
	movq	%r8, %rsi
	jmp	sort_bytes
	.p2align 4,,10
	.p2align 3
.L2817:
	jmp	sort_u64
	.p2align 4,,10
	.p2align 3
.L2831:
	movq	%r8, %rsi
	jmp	sort_f64
	.p2align 4,,10
	.p2align 3
.L2832:
	movq	%r8, %rsi
	jmp	sort_text
	.cfi_endproc
.LFE87:
	.size	myl_native_list_sort, .-myl_native_list_sort
	.p2align 4
	.globl	myl_native_list_sort_keyed
	.type	myl_native_list_sort_keyed, @function
myl_native_list_sort_keyed:
.LFB99:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$256, %rsp
	.cfi_def_cfa_offset 304
	movq	%fs:40, %rax
	movq	%rax, 248(%rsp)
	xorl	%eax, %eax
	testq	%rsi, %rsi
	je	.L2838
	movq	%rdx, %r10
	testq	%rdx, %rdx
	je	.L2838
	movq	(%rsi), %rax
	cmpq	%rax, (%rdx)
	je	.L2950
.L2838:
	xorl	%eax, %eax
.L2834:
	movq	248(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L2951
	addq	$256, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L2950:
	.cfi_restore_state
	movq	24(%rsi), %rdx
	movq	%rdi, %r11
	movq	(%rdx), %rdi
	movq	%rdi, %rbp
	cmpq	%r11, %rsi
	je	.L2839
	cmpq	$0, (%r11)
	jne	.L2838
	cmpq	%rax, 8(%r11)
	jb	.L2838
	movq	24(%r11), %rdx
	cmpq	%rdi, (%rdx)
	jne	.L2838
.L2839:
	movq	24(%r10), %rdx
	movq	(%rdx), %rdi
	movl	%ecx, %edx
	andl	$15, %edx
	leal	-1(%rdx), %ebx
	movl	%edx, 80(%rsp)
	cmpl	$7, %ebx
	ja	.L2838
	movq	%rcx, %rbx
	shrq	$4, %rbx
	andl	$15, %ebx
	cmpl	$7, %ebx
	je	.L2952
	movl	%ebx, %r15d
	andl	$3, %ebx
	movb	%r8b, 100(%rsp)
	movl	%r15d, %r14d
	leaq	widths.0(%rip), %r15
	movb	%bl, 84(%rsp)
	subl	$2, %ebx
	shrl	$2, %r14d
	movzbl	(%r15,%r14), %r14d
	movb	%r14b, 92(%rsp)
	movl	%r14d, %r15d
	cmpb	$1, %bl
	ja	.L2891
	cmpb	$8, %r14b
	jne	.L2838
.L2891:
	movzbl	%r15b, %ebx
.L2841:
	movzbl	%r8b, %r14d
	addq	%r14, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	testb	$14, %cl
	je	.L2845
	movq	%rcx, %rbx
	movq	%r8, %r14
	shrq	$8, %rbx
	shrq	$8, %r14
	andl	$15, %ebx
	movq	%r14, %r12
	cmpl	$7, %ebx
	je	.L2953
	movl	%ebx, %r15d
	andl	$3, %ebx
	movb	%r12b, 101(%rsp)
	movl	%r15d, %r14d
	leaq	widths.0(%rip), %r15
	movb	%bl, 85(%rsp)
	subl	$2, %ebx
	shrl	$2, %r14d
	movzbl	(%r15,%r14), %r14d
	movb	%r14b, 93(%rsp)
	cmpb	$1, %bl
	ja	.L2892
	cmpb	$8, %r14b
	jne	.L2838
.L2892:
	movzbl	%r14b, %ebx
.L2847:
	movzbl	%r12b, %r15d
	addq	%r15, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	cmpl	$2, %edx
	jbe	.L2845
	movq	%rcx, %rbx
	movq	%r8, %r14
	shrq	$12, %rbx
	shrq	$16, %r14
	andl	$15, %ebx
	movq	%r14, %r12
	cmpl	$7, %ebx
	je	.L2954
	movl	%ebx, %r15d
	andl	$3, %ebx
	movb	%r12b, 102(%rsp)
	movl	%r15d, %r14d
	leaq	widths.0(%rip), %r15
	movb	%bl, 86(%rsp)
	subl	$2, %ebx
	shrl	$2, %r14d
	movzbl	(%r15,%r14), %r15d
	movb	%r15b, 94(%rsp)
	cmpb	$1, %bl
	ja	.L2893
	cmpb	$8, %r15b
	jne	.L2838
.L2893:
	movzbl	%r15b, %ebx
.L2850:
	movzbl	%r12b, %r15d
	addq	%r15, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	testb	$12, %cl
	je	.L2845
	movq	%rcx, %rbx
	movq	%r8, %r14
	shrq	$16, %rbx
	shrq	$24, %r14
	andl	$15, %ebx
	movq	%r14, %r12
	cmpl	$7, %ebx
	je	.L2955
	movl	%ebx, %r15d
	andl	$3, %ebx
	movb	%r12b, 103(%rsp)
	movl	%r15d, %r14d
	leaq	widths.0(%rip), %r15
	movb	%bl, 87(%rsp)
	subl	$2, %ebx
	shrl	$2, %r14d
	movzbl	(%r15,%r14), %r15d
	movb	%r15b, 95(%rsp)
	cmpb	$1, %bl
	ja	.L2894
	cmpb	$8, %r15b
	jne	.L2838
.L2894:
	movzbl	%r15b, %ebx
.L2853:
	movzbl	%r12b, %r15d
	addq	%r15, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	cmpl	$4, %edx
	jbe	.L2845
	movq	%rcx, %rbx
	movq	%r8, %r14
	shrq	$20, %rbx
	shrq	$32, %r14
	andl	$15, %ebx
	movq	%r14, %r12
	cmpl	$7, %ebx
	je	.L2956
	movl	%ebx, %r14d
	andl	$3, %ebx
	movb	%r12b, 104(%rsp)
	movl	%r14d, %r15d
	leaq	widths.0(%rip), %r14
	movb	%bl, 88(%rsp)
	subl	$2, %ebx
	shrl	$2, %r15d
	movzbl	(%r14,%r15), %r15d
	movb	%r15b, 96(%rsp)
	cmpb	$1, %bl
	ja	.L2895
	cmpb	$8, %r15b
	jne	.L2838
.L2895:
	movzbl	%r15b, %ebx
.L2856:
	movzbl	%r12b, %r15d
	addq	%r15, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	cmpl	$5, %edx
	je	.L2845
	movq	%rcx, %rbx
	movq	%r8, %r15
	shrq	$24, %rbx
	shrq	$40, %r15
	andl	$15, %ebx
	movq	%r15, %r12
	cmpl	$7, %ebx
	je	.L2957
	movl	%ebx, %r14d
	andl	$3, %ebx
	movb	%r12b, 105(%rsp)
	movl	%r14d, %r15d
	leaq	widths.0(%rip), %r14
	movb	%bl, 89(%rsp)
	subl	$2, %ebx
	shrl	$2, %r15d
	movzbl	(%r14,%r15), %r14d
	movb	%r14b, 97(%rsp)
	cmpb	$1, %bl
	ja	.L2896
	cmpb	$8, %r14b
	jne	.L2838
.L2896:
	movzbl	%r14b, %ebx
.L2859:
	movzbl	%r12b, %r15d
	addq	%r15, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	cmpl	$6, %edx
	je	.L2845
	movl	%ecx, %ebx
	movq	%r8, %r15
	shrq	$48, %r15
	shrl	$28, %ebx
	movq	%r15, %r12
	cmpl	$7, %ebx
	je	.L2958
	movl	%ebx, %r14d
	andl	$3, %ebx
	movb	%r12b, 106(%rsp)
	movl	%r14d, %r15d
	leaq	widths.0(%rip), %r14
	movb	%bl, 90(%rsp)
	subl	$2, %ebx
	shrl	$2, %r15d
	movzbl	(%r14,%r15), %r14d
	movb	%r14b, 98(%rsp)
	cmpb	$1, %bl
	ja	.L2897
	cmpb	$8, %r14b
	jne	.L2838
.L2897:
	movzbl	%r14b, %ebx
.L2862:
	movzbl	%r12b, %r14d
	addq	%r14, %rbx
	cmpq	%rbx, %rdi
	jb	.L2838
	testb	$8, %cl
	je	.L2845
	shrq	$32, %rcx
	shrq	$56, %r8
	andl	$15, %ecx
	cmpl	$7, %ecx
	je	.L2864
	movl	%ecx, %ebx
	leaq	widths.0(%rip), %r15
	shrl	$2, %ecx
	movb	%r8b, 107(%rsp)
	andl	$3, %ebx
	movzbl	(%r15,%rcx), %ecx
	movb	%bl, 91(%rsp)
	subl	$2, %ebx
	movb	%cl, 99(%rsp)
	cmpb	$1, %bl
	ja	.L2887
	cmpb	$8, %cl
	jne	.L2838
.L2887:
	addq	%r8, %rcx
	cmpq	%rcx, %rdi
	jb	.L2838
.L2845:
	cmpq	$1, %rax
	jbe	.L2959
	leaq	112(%rsp), %r8
	cmpq	%r11, %rsi
	je	.L2960
.L2882:
	xorl	%ecx, %ecx
	testq	%r9, %r9
	movq	%r11, 48(%rsp)
	movq	%rsi, 56(%rsp)
	setne	%cl
	movq	%r8, 64(%rsp)
	cmpl	$1, %edx
	jne	.L2883
	movzbl	84(%rsp), %eax
	subl	$3, %eax
	cmpb	$1, %al
	ja	.L2961
.L2883:
	leaq	80(%rsp), %rdx
	leaq	48(%rsp), %rdi
	movq	%r10, %rsi
	movq	%r8, 8(%rsp)
	call	keyed_sort_entries
	movq	8(%rsp), %r8
.L2884:
	leaq	112(%rsp), %rcx
	cmpq	%rcx, %r8
	je	.L2834
	movq	%r8, %rdi
	movl	%eax, 8(%rsp)
	call	free@PLT
	movl	8(%rsp), %eax
	jmp	.L2834
	.p2align 4,,10
	.p2align 3
.L2952:
	movb	$4, 84(%rsp)
	movl	$8, %ebx
	movb	$8, 92(%rsp)
	movb	%r8b, 100(%rsp)
	jmp	.L2841
	.p2align 4,,10
	.p2align 3
.L2953:
	movb	$4, 85(%rsp)
	movl	$8, %ebx
	movb	$8, 93(%rsp)
	movb	%r14b, 101(%rsp)
	jmp	.L2847
	.p2align 4,,10
	.p2align 3
.L2954:
	movb	$4, 86(%rsp)
	movl	$8, %ebx
	movb	$8, 94(%rsp)
	movb	%r14b, 102(%rsp)
	jmp	.L2850
	.p2align 4,,10
	.p2align 3
.L2959:
	cmpq	%r11, %rsi
	je	.L2868
	testb	$1, %al
	je	.L2868
	movq	32(%r11), %rax
	movq	32(%rsi), %rsi
	cmpq	$64, %rbp
	ja	.L2869
	leaq	.L2871(%rip), %rcx
	movslq	(%rcx,%rbp,4), %rdx
	addq	%rcx, %rdx
	notrack jmp	*%rdx
	.section	.rodata
	.align 4
	.align 4
.L2871:
	.long	.L2869-.L2871
	.long	.L2880-.L2871
	.long	.L2879-.L2871
	.long	.L2869-.L2871
	.long	.L2878-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2877-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2876-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2875-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2874-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2873-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2872-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2869-.L2871
	.long	.L2870-.L2871
	.text
.L2869:
	movq	%rbp, %rdx
	movq	%rax, %rdi
	movq	%r11, 8(%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %r11
.L2881:
	addq	$1, 16(%r11)
	movq	$1, (%r11)
.L2868:
	movl	$1, %eax
	jmp	.L2834
.L2870:
	movl	$16, %ecx
	movq	%rax, %rdi
	rep movsl
	jmp	.L2881
.L2872:
	movl	$14, %ecx
	movq	%rax, %rdi
	rep movsl
	jmp	.L2881
.L2873:
	movl	$10, %ecx
	movq	%rax, %rdi
	rep movsl
	jmp	.L2881
.L2874:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rax)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rax)
	jmp	.L2881
.L2875:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rax)
	movq	16(%rsi), %rdx
	movq	%rdx, 16(%rax)
	jmp	.L2881
.L2876:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rax)
	jmp	.L2881
.L2877:
	movq	(%rsi), %rdx
	movq	%rdx, (%rax)
	jmp	.L2881
.L2878:
	movl	(%rsi), %edx
	movl	%edx, (%rax)
	jmp	.L2881
.L2879:
	movzwl	(%rsi), %edx
	movw	%dx, (%rax)
	jmp	.L2881
.L2880:
	movzbl	(%rsi), %edx
	movb	%dl, (%rax)
	jmp	.L2881
	.p2align 4,,10
	.p2align 3
.L2955:
	movb	$4, 87(%rsp)
	movl	$8, %ebx
	movb	$8, 95(%rsp)
	movb	%r14b, 103(%rsp)
	jmp	.L2853
	.p2align 4,,10
	.p2align 3
.L2956:
	movb	$4, 88(%rsp)
	movl	$8, %ebx
	movb	$8, 96(%rsp)
	movb	%r14b, 104(%rsp)
	jmp	.L2856
	.p2align 4,,10
	.p2align 3
.L2960:
	leaq	(%rbp,%rbp), %rdi
	cmpq	$128, %rdi
	jbe	.L2882
	movq	%r9, 40(%rsp)
	movq	%r10, 32(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%r11, 16(%rsp)
	movl	%edx, 8(%rsp)
	call	malloc@PLT
	movl	8(%rsp), %edx
	movq	16(%rsp), %r11
	testq	%rax, %rax
	movq	24(%rsp), %rsi
	movq	32(%rsp), %r10
	movq	%rax, %r8
	movq	40(%rsp), %r9
	jne	.L2882
	jmp	.L2838
	.p2align 4,,10
	.p2align 3
.L2957:
	movb	$4, 89(%rsp)
	movl	$8, %ebx
	movb	$8, 97(%rsp)
	movb	%r15b, 105(%rsp)
	jmp	.L2859
	.p2align 4,,10
	.p2align 3
.L2958:
	movb	$4, 90(%rsp)
	movl	$8, %ebx
	movb	$8, 98(%rsp)
	movb	%r15b, 106(%rsp)
	jmp	.L2862
	.p2align 4,,10
	.p2align 3
.L2864:
	movb	$4, 91(%rsp)
	movl	$8, %ecx
	movb	$8, 99(%rsp)
	movb	%r8b, 107(%rsp)
	jmp	.L2887
.L2961:
	leaq	80(%rsp), %rdx
	leaq	48(%rsp), %rdi
	movq	%r10, %rsi
	movq	%r8, 8(%rsp)
	call	keyed_sort_words
	movq	8(%rsp), %r8
	jmp	.L2884
.L2951:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE99:
	.size	myl_native_list_sort_keyed, .-myl_native_list_sort_keyed
	.p2align 4
	.globl	myl_native_list_header
	.type	myl_native_list_header, @function
myl_native_list_header:
.LFB101:
	.cfi_startproc
	endbr64
	xorl	%eax, %eax
	testq	%rdi, %rdi
	je	.L2962
	leaq	myl_native_list_header_descriptor(%rip), %rax
	cmpq	%rax, -8(%rdi)
	sete	%al
	movzbl	%al, %eax
.L2962:
	ret
	.cfi_endproc
.LFE101:
	.size	myl_native_list_header, .-myl_native_list_header
	.p2align 4
	.globl	myl_native_slice_start
	.type	myl_native_slice_start, @function
myl_native_slice_start:
.LFB105:
	.cfi_startproc
	endbr64
	movabsq	$-9223372036854775808, %rax
	cmpq	%rax, %rsi
	je	.L2976
	testq	%rdx, %rdx
	jle	.L2971
	testq	%rsi, %rsi
	jns	.L2968
	leaq	(%rsi,%rdi), %rax
	xorl	%edx, %edx
	testq	%rax, %rax
	cmovs	%rdx, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2971:
	testq	%rsi, %rsi
	js	.L2969
	movq	%rsi, %rax
	cmpq	%rdi, %rsi
	jl	.L2966
	leaq	-1(%rdi), %rax
.L2966:
	ret
	.p2align 4,,10
	.p2align 3
.L2976:
	xorl	%esi, %esi
	testq	%rdx, %rdx
	jle	.L2977
.L2968:
	cmpq	%rsi, %rdi
	movq	%rsi, %rax
	cmovle	%rdi, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2977:
	leaq	-1(%rdi), %rax
	movq	%rax, %rsi
	testq	%rax, %rax
	jns	.L2966
.L2969:
	leaq	(%rdi,%rsi), %rax
	movq	$-1, %rdx
	testq	%rax, %rax
	cmovs	%rdx, %rax
	ret
	.cfi_endproc
.LFE105:
	.size	myl_native_slice_start, .-myl_native_slice_start
	.p2align 4
	.globl	myl_native_slice_stop
	.type	myl_native_slice_stop, @function
myl_native_slice_stop:
.LFB106:
	.cfi_startproc
	endbr64
	movabsq	$9223372036854775807, %rax
	cmpq	%rax, %rsi
	je	.L2988
	testq	%rdx, %rdx
	jle	.L2983
	cmpq	%rdi, %rsi
	movq	%rdi, %rax
	cmovle	%rsi, %rax
	testq	%rsi, %rsi
	js	.L2981
	ret
	.p2align 4,,10
	.p2align 3
.L2980:
	movq	%rdi, %rsi
	notq	%rsi
.L2983:
	testq	%rsi, %rsi
	js	.L2989
	leaq	-1(%rdi), %rax
	cmpq	%rsi, %rdi
	cmovg	%rsi, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2988:
	testq	%rdx, %rdx
	jle	.L2980
	testq	%rdi, %rdi
	jns	.L2990
	movq	%rdi, %rsi
.L2981:
	leaq	(%rdi,%rsi), %rax
	xorl	%edx, %edx
	testq	%rax, %rax
	cmovs	%rdx, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2990:
	movq	%rdi, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L2989:
	leaq	(%rdi,%rsi), %rax
	movq	$-1, %rdx
	testq	%rax, %rax
	cmovs	%rdx, %rax
	ret
	.cfi_endproc
.LFE106:
	.size	myl_native_slice_stop, .-myl_native_slice_stop
	.p2align 4
	.globl	myl_native_slice_count
	.type	myl_native_slice_count, @function
myl_native_slice_count:
.LFB107:
	.cfi_startproc
	endbr64
	movq	%rdx, %rcx
	xorl	%eax, %eax
	testq	%rdx, %rdx
	jg	.L2997
	cmpq	%rsi, %rdi
	jle	.L2991
	subq	%rsi, %rdi
	negq	%rcx
	subq	%rdx, %rdi
	leaq	-1(%rdi), %rax
	cqto
	idivq	%rcx
.L2991:
	ret
	.p2align 4,,10
	.p2align 3
.L2997:
	cmpq	%rsi, %rdi
	jge	.L2991
	subq	%rdi, %rsi
	leaq	-1(%rdx,%rsi), %rax
	cqto
	idivq	%rcx
	ret
	.cfi_endproc
.LFE107:
	.size	myl_native_slice_count, .-myl_native_slice_count
	.p2align 4
	.globl	myl_rc_list_require
	.type	myl_rc_list_require, @function
myl_rc_list_require:
.LFB116:
	.cfi_startproc
	endbr64
	movq	5640(%rdi), %rdx
	xorl	%eax, %eax
	cmpb	$0, 288(%rdx)
	je	.L3006
	ret
	.p2align 4,,10
	.p2align 3
.L3006:
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	leaq	rc_list_module(%rip), %rsi
	movq	%rdi, 8(%rsp)
	call	myl_rc_module_register@PLT
	testl	%eax, %eax
	jne	.L2998
	movq	8(%rsp), %rdi
	movq	5640(%rdi), %rdx
	movb	$1, 288(%rdx)
.L2998:
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE116:
	.size	myl_rc_list_require, .-myl_rc_list_require
	.p2align 4
	.globl	myl_rc_list_storage_new
	.type	myl_rc_list_storage_new, @function
myl_rc_list_storage_new:
.LFB118:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rsi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movl	%ecx, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rdx, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	movq	5640(%rdi), %rax
	cmpb	$0, 288(%rax)
	je	.L3020
.L3008:
	movl	%r12d, %ecx
	movl	$1, %edx
	leaq	rc_storage_type(%rip), %rsi
	movq	%rbx, %rdi
	call	myl_rc_storage_alloc@PLT
	movq	%rax, %r8
	testq	%rax, %rax
	je	.L3011
	movq	%r13, 24(%rax)
	testq	%rbp, %rbp
	jne	.L3021
.L3012:
	movq	%rbp, 8(%r8)
.L3007:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movq	%r8, %rax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3020:
	.cfi_restore_state
	leaq	rc_list_module(%rip), %rsi
	call	myl_rc_module_register@PLT
	testl	%eax, %eax
	je	.L3009
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	myl_rc_record_failure@PLT
.L3011:
	xorl	%r8d, %r8d
	jmp	.L3007
	.p2align 4,,10
	.p2align 3
.L3021:
	movl	%r12d, %ecx
	movq	%rbp, %rdx
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movq	%rax, 8(%rsp)
	call	myl_rc_native_storage@PLT
	movq	8(%rsp), %r8
	movq	%rax, 32(%r8)
	testq	%rax, %rax
	jne	.L3012
	movq	%r8, %rsi
	movq	%rbx, %rdi
	call	myl_rc_native_abort@PLT
	jmp	.L3011
	.p2align 4,,10
	.p2align 3
.L3009:
	movq	5640(%rbx), %rax
	movb	$1, 288(%rax)
	jmp	.L3008
	.cfi_endproc
.LFE118:
	.size	myl_rc_list_storage_new, .-myl_rc_list_storage_new
	.section	.text.unlikely
.LCOLDB16:
	.text
.LHOTB16:
	.p2align 4
	.globl	myl_rc_list_storage_reserve
	.type	myl_rc_list_storage_reserve, @function
myl_rc_list_storage_reserve:
.LFB119:
	.cfi_startproc
	endbr64
	movq	8(%rsi), %r8
	cmpq	%rdx, %r8
	jnb	.L3060
	movl	$4, %eax
	cmpq	%rax, %r8
	cmovb	%rax, %r8
	cmpq	%rdx, %r8
	jb	.L3027
	jmp	.L3024
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L3025:
	addq	%r8, %r8
	cmpq	%rdx, %r8
	jnb	.L3024
.L3027:
	testq	%r8, %r8
	jns	.L3025
.L3061:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3024:
	movq	24(%rsi), %r10
	movq	(%r10), %rcx
	testq	%rcx, %rcx
	je	.L3028
	movq	%rcx, %rax
	mulq	%r8
	jo	.L3061
.L3028:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rsi, %r9
	movq	%rdi, %r11
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	movq	5640(%rdi), %rdx
	movq	32(%rsi), %rbx
	cmpq	272(%rdx), %r10
	je	.L3032
	movl	52(%r10), %eax
	cmpq	160(%rdx), %rax
	jnb	.L3033
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %r10
	jne	.L3033
	movq	8(%rax), %rax
.L3034:
	testq	%rax, %rax
	je	.L3035
	movl	64(%rax), %edx
	testl	%edx, %edx
	jne	.L3035
	cmpb	$0, 69(%rax)
	jne	.L3035
	movq	5640(%r11), %rax
	movq	%r10, 272(%rax)
.L3032:
	imulq	%r8, %rcx
	movq	%r11, %rdi
	movq	%rbx, %rsi
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	movq	%r11, (%rsp)
	movq	%rcx, %rdx
	call	myl_rc_storage_extend_opaque@PLT
	movq	(%rsp), %r11
	movq	8(%rsp), %r8
	testq	%rax, %rax
	movq	16(%rsp), %r9
	je	.L3064
.L3037:
	movq	%rax, 32(%r9)
.L3043:
	movq	%r8, 8(%r9)
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3060:
	.cfi_restore 3
	movl	$1, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3035:
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -16
	imulq	%r8, %rcx
	movq	%r11, %rdi
	movq	%rbx, %rsi
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	movq	%r11, (%rsp)
	movq	%rcx, %rdx
	call	myl_rc_storage_extend@PLT
	movq	(%rsp), %r11
	movq	8(%rsp), %r8
	testq	%rax, %rax
	movq	16(%rsp), %r9
	jne	.L3037
	movq	-16(%r9), %rax
	movq	24(%r9), %rsi
	movq	%r11, %rdi
	movq	%r9, 16(%rsp)
	movabsq	$4611686018427387904, %rdx
	movq	%r8, 8(%rsp)
	movq	%rax, %rcx
	movq	%r11, (%rsp)
	shrq	$40, %rcx
	andl	$1048575, %ecx
	testq	%rdx, %rax
	movl	$0, %eax
	movq	%r8, %rdx
	cmove	%eax, %ecx
	call	myl_rc_native_storage@PLT
	movq	16(%rsp), %r9
	movq	8(%rsp), %r8
	movq	(%rsp), %r11
	movq	%rax, %rcx
.L3040:
	testq	%rcx, %rcx
	je	.L3031
	movq	(%r9), %rdx
	testq	%rdx, %rdx
	jne	.L3065
.L3042:
	movq	%rcx, 32(%r9)
	movq	%rbx, %rsi
	movq	%r11, %rdi
	movq	%r8, 8(%rsp)
	movq	%r9, (%rsp)
	call	myl_rc_owner_release@PLT
	movq	(%rsp), %r9
	movq	8(%rsp), %r8
	jmp	.L3043
.L3031:
	addq	$32, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
.L3064:
	.cfi_restore_state
	movq	-16(%r9), %rax
	movq	%r8, %rsi
	movq	%r11, %rdi
	movq	%r9, 16(%rsp)
	movabsq	$4611686018427387904, %rcx
	movq	%r8, 8(%rsp)
	movq	%rax, %rdx
	movq	%r11, (%rsp)
	shrq	$40, %rdx
	andl	$1048575, %edx
	testq	%rcx, %rax
	movl	$0, %eax
	cmove	%eax, %edx
	movq	24(%r9), %rax
	imulq	(%rax), %rsi
	call	myl_rc_storage_block@PLT
	movq	(%rsp), %r11
	movq	8(%rsp), %r8
	movq	16(%rsp), %r9
	movq	%rax, %rcx
	jmp	.L3040
.L3065:
	movq	24(%r9), %rax
	movq	%rcx, %rdi
	movq	%rbx, %rsi
	movq	%r11, 16(%rsp)
	movq	%r8, 8(%rsp)
	imulq	(%rax), %rdx
	movq	%r9, (%rsp)
	call	memcpy@PLT
	movq	16(%rsp), %r11
	movq	8(%rsp), %r8
	movq	(%rsp), %r9
	movq	%rax, %rcx
	jmp	.L3042
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_storage_reserve.cold, @function
myl_rc_list_storage_reserve.cold:
.LFSB119:
.L3033:
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -16
	movq	%r10, %rsi
	movq	%r11, %rdi
	movq	%r9, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%r10, 8(%rsp)
	movq	%r11, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	24(%rsp), %r9
	movq	(%rsp), %r11
	movq	8(%rsp), %r10
	movq	16(%rsp), %r8
	movq	24(%r9), %rdx
	movq	(%rdx), %rcx
	jmp	.L3034
	.cfi_endproc
.LFE119:
	.text
	.size	myl_rc_list_storage_reserve, .-myl_rc_list_storage_reserve
	.section	.text.unlikely
	.size	myl_rc_list_storage_reserve.cold, .-myl_rc_list_storage_reserve.cold
.LCOLDE16:
	.text
.LHOTE16:
	.section	.text.unlikely
.LCOLDB17:
	.text
.LHOTB17:
	.p2align 4
	.type	rc_list_insert_at, @function
rc_list_insert_at:
.LFB121:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	movq	%fs:40, %rax
	movq	%rax, 152(%rsp)
	xorl	%eax, %eax
	cmpq	$-1, 16(%rsi)
	je	.L3069
	movq	(%rsi), %rax
	movq	%rsi, %rbx
	cmpq	$-1, %rax
	je	.L3069
	movq	%rdx, %r13
	movq	24(%rsi), %rdx
	movq	%rdi, %rbp
	movq	(%rdx), %r12
	cmpq	%r13, %rax
	je	.L3141
.L3070:
	leaq	16(%rsp), %r14
	movq	%r14, %r15
	cmpq	$128, %r12
	ja	.L3142
.L3071:
	movabsq	$4611686018427387904, %rdi
	movq	-16(%rbx), %rsi
	movq	%rsi, %rdx
	shrq	$40, %rdx
	andl	$1048575, %edx
	testq	%rdi, %rsi
	movl	$0, %esi
	cmovne	%edx, %esi
	movq	32(%rbx), %rdx
	movl	%esi, 12(%rsp)
	leaq	1(%rax), %rsi
	testq	%rdx, %rdx
	je	.L3083
	cmpq	%rdx, %rcx
	jb	.L3083
	imulq	%r12, %rax
	movq	%rcx, %r8
	subq	%rdx, %r8
	cmpq	%rax, %r8
	jnb	.L3083
	movq	%rsi, %rdx
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	movq	%r8, (%rsp)
	call	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.L3092
	movq	(%rsp), %rcx
	addq	32(%rbx), %rcx
.L3093:
	movq	24(%rbx), %rsi
	movl	12(%rsp), %r8d
	movq	%r15, %rdx
	movq	%rbp, %rdi
	call	myl_rc_native_retain@PLT
	movl	%eax, %ecx
	testl	%eax, %eax
	jne	.L3085
.L3092:
	xorl	%ecx, %ecx
.L3086:
	cmpq	%r14, %r15
	je	.L3066
	movq	%r15, %rsi
	movq	%rbp, %rdi
	movl	%ecx, (%rsp)
	call	myl_rc_owner_release@PLT
	movl	(%rsp), %ecx
.L3066:
	movq	152(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3143
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%ecx, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3083:
	.cfi_restore_state
	movq	%rsi, %rdx
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	movq	%rcx, (%rsp)
	call	myl_rc_list_storage_reserve
	movq	(%rsp), %rcx
	testl	%eax, %eax
	je	.L3092
	jmp	.L3093
	.p2align 4,,10
	.p2align 3
.L3079:
	movq	-16(%rbx), %rax
	movq	24(%rbx), %rsi
	movq	%rbp, %rdi
	movabsq	$4611686018427387904, %rdx
	movq	%rax, %r8
	shrq	$40, %r8
	andl	$1048575, %r8d
	testq	%rdx, %rax
	movl	$0, %eax
	movq	%r13, %rdx
	cmove	%eax, %r8d
	call	myl_rc_native_retain@PLT
	movl	%eax, %ecx
	testl	%eax, %eax
	jne	.L3080
	.p2align 4
	.p2align 3
.L3069:
	xorl	%ecx, %ecx
	jmp	.L3066
	.p2align 4,,10
	.p2align 3
.L3142:
	xorl	%edx, %edx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	movq	%rcx, (%rsp)
	call	myl_rc_storage_bytes@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L3069
	movq	(%rbx), %rax
	movq	(%rsp), %rcx
	jmp	.L3071
	.p2align 4,,10
	.p2align 3
.L3085:
	movq	(%rbx), %rdx
	movq	32(%rbx), %r8
	cmpq	%rdx, %r13
	jb	.L3144
.L3087:
	testq	%r12, %r12
	jne	.L3145
.L3088:
	addq	$1, (%rbx)
	addq	$1, 16(%rbx)
	jmp	.L3086
	.p2align 4,,10
	.p2align 3
.L3141:
	testq	%r12, %r12
	je	.L3097
	movq	5640(%rdi), %rdx
	cmpq	$0, 200(%rdx)
	jne	.L3070
	movq	32(%rsi), %rdx
	movq	%rax, %r14
	imulq	%r12, %r14
	testq	%rdx, %rdx
	je	.L3072
	cmpq	%rdx, %rcx
	jb	.L3072
	movq	%rcx, %r15
	subq	%rdx, %r15
	movq	8(%rsi), %rdx
	imulq	%r12, %rdx
	cmpq	%rdx, %r15
	jnb	.L3101
	cmpq	%r14, %r15
	jnb	.L3070
.L3074:
	leaq	1(%r13), %rdx
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.L3069
	movq	32(%rbx), %r13
	leaq	0(%r13,%r15), %rcx
.L3094:
	addq	%r14, %r13
	leaq	(%rcx,%r12), %rax
	cmpq	%rax, %r13
	jnb	.L3075
	leaq	0(%r13,%r12), %rax
	cmpq	%rax, %rcx
	jb	.L3138
.L3075:
	movq	5640(%rbp), %rdx
	movq	24(%rbx), %r14
	cmpq	272(%rdx), %r14
	je	.L3076
	movl	52(%r14), %eax
	cmpq	160(%rdx), %rax
	jnb	.L3077
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %r14
	jne	.L3077
	movq	8(%rax), %rax
.L3078:
	testq	%rax, %rax
	je	.L3079
	movl	64(%rax), %edx
	testl	%edx, %edx
	jne	.L3079
	cmpb	$0, 69(%rax)
	jne	.L3079
	movq	5640(%rbp), %rax
	movq	%r14, 272(%rax)
.L3076:
	movq	%rcx, %rsi
	movq	%r12, %rdx
	movq	%r13, %rdi
	call	memcpy@PLT
	movl	$1, %ecx
.L3080:
	addq	$1, (%rbx)
	addq	$1, 16(%rbx)
	jmp	.L3066
	.p2align 4,,10
	.p2align 3
.L3145:
	imulq	%r12, %r13
	movq	%r12, %rdx
	movq	%r15, %rsi
	movl	%ecx, (%rsp)
	leaq	(%r8,%r13), %rdi
	call	memcpy@PLT
	movl	(%rsp), %ecx
	jmp	.L3088
	.p2align 4,,10
	.p2align 3
.L3144:
	movl	%eax, 12(%rsp)
	movq	%r13, %rax
	subq	%r13, %rdx
	imulq	%r12, %rax
	movq	%r8, (%rsp)
	imulq	%r12, %rdx
	leaq	(%r8,%rax), %rsi
	addq	%r12, %rax
	leaq	(%r8,%rax), %rdi
	call	memmove@PLT
	movl	12(%rsp), %ecx
	movq	(%rsp), %r8
	jmp	.L3087
	.p2align 4,,10
	.p2align 3
.L3097:
	leaq	16(%rsp), %r14
	movq	%r14, %r15
	jmp	.L3071
.L3101:
	cmpq	%r14, %r15
	jb	.L3074
.L3072:
	leaq	1(%r13), %rdx
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	movq	%rcx, (%rsp)
	call	myl_rc_list_storage_reserve
	testl	%eax, %eax
	je	.L3069
	movq	32(%rbx), %r13
	movq	(%rsp), %rcx
	jmp	.L3094
.L3143:
	call	__stack_chk_fail@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_insert_at.cold, @function
rc_list_insert_at.cold:
.LFSB121:
.L3138:
	.cfi_def_cfa_offset 224
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	call	myl_rc_invariant_failed@PLT
.L3077:
	movq	%r14, %rsi
	movq	%rbp, %rdi
	movq	%rcx, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rsp), %rcx
	jmp	.L3078
	.cfi_endproc
.LFE121:
	.text
	.size	rc_list_insert_at, .-rc_list_insert_at
	.section	.text.unlikely
	.size	rc_list_insert_at.cold, .-rc_list_insert_at.cold
.LCOLDE17:
	.text
.LHOTE17:
	.p2align 4
	.globl	myl_native_list_append
	.type	myl_native_list_append, @function
myl_native_list_append:
.LFB54:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	subq	$96, %rsp
	.cfi_def_cfa_offset 144
	movq	%rsi, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 88(%rsp)
	xorl	%eax, %eax
	cmpq	$-1, 16(%rsi)
	je	.L3147
	movq	%rdx, %rbx
	movq	%rdi, %rbp
	movq	(%rsi), %rdx
	movq	%rsi, %rax
	testq	%rdi, %rdi
	je	.L3148
	cmpq	$0, 5640(%rdi)
	je	.L3148
	movq	%rbx, %rcx
	call	rc_list_insert_at
.L3146:
	movq	88(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L3204
	addq	$96, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3148:
	.cfi_restore_state
	cmpq	8(%rsi), %rdx
	jnb	.L3150
	movq	24(%rsi), %rcx
	movq	32(%rsi), %rdi
	movq	(%rcx), %rcx
	imulq	%rcx, %rdx
	addq	%rdx, %rdi
	cmpq	$64, %rcx
	ja	.L3151
	leaq	.L3153(%rip), %r8
	movslq	(%r8,%rcx,4), %rdx
	addq	%r8, %rdx
	notrack jmp	*%rdx
	.section	.rodata
	.align 4
	.align 4
.L3153:
	.long	.L3151-.L3153
	.long	.L3162-.L3153
	.long	.L3161-.L3153
	.long	.L3151-.L3153
	.long	.L3160-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3159-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3158-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3157-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3156-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3155-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3154-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3151-.L3153
	.long	.L3152-.L3153
	.text
	.p2align 4,,10
	.p2align 3
.L3166:
	leaq	48(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
	leaq	16(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
	.p2align 4
	.p2align 3
.L3147:
	xorl	%eax, %eax
	jmp	.L3146
	.p2align 4,,10
	.p2align 3
.L3150:
	leaq	8(%rsp), %rdx
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	movq	%rbp, %rdi
	leaq	16(%rsp), %rsi
	call	myl_native_root_push@PLT
	movq	8(%rsp), %rax
	movq	%rbx, %rdx
	movq	%rbp, %rdi
	leaq	48(%rsp), %rsi
	movq	24(%rax), %rcx
	call	myl_native_root_push@PLT
	movq	8(%rsp), %rax
	movq	8(%rax), %rdx
	cmpq	$3, %rdx
	jbe	.L3184
	testq	%rdx, %rdx
	js	.L3166
	leaq	(%rdx,%rdx), %r14
.L3165:
	movq	32(%rax), %rsi
	testq	%rsi, %rsi
	je	.L3167
	cmpq	%rsi, %rbx
	jb	.L3167
	movq	24(%rax), %rdx
	movq	%rbx, %rcx
	subq	%rsi, %rcx
	movq	(%rdx), %rdx
	imulq	(%rax), %rdx
	cmpq	%rdx, %rcx
	jb	.L3168
.L3167:
	movq	%r14, %rdx
	movq	%rbp, %rdi
	call	myl_native_heap_extend@PLT
	movq	8(%rsp), %rsi
	movq	%rax, %rcx
	movq	%rsi, %rax
	testq	%rcx, %rcx
	je	.L3168
	movq	(%rsi), %rdi
.L3169:
	movq	24(%rsi), %rdx
	movq	(%rdx), %rdx
	imulq	%rdx, %rdi
	addq	%rcx, %rdi
	cmpq	$64, %rdx
	ja	.L3170
	leaq	.L3172(%rip), %r9
	movslq	(%r9,%rdx,4), %r8
	addq	%r9, %r8
	notrack jmp	*%r8
	.section	.rodata
	.align 4
	.align 4
.L3172:
	.long	.L3170-.L3172
	.long	.L3181-.L3172
	.long	.L3180-.L3172
	.long	.L3170-.L3172
	.long	.L3179-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3178-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3177-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3176-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3175-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3174-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3173-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3170-.L3172
	.long	.L3171-.L3172
	.text
	.p2align 4,,10
	.p2align 3
.L3168:
	movq	%rax, %rsi
	movq	%rbp, %rdi
	call	myl_native_object_region@PLT
	movq	8(%rsp), %rdx
	movq	%rbp, %rdi
	movl	%eax, %ecx
	movq	24(%rdx), %rsi
	movq	%r14, %rdx
	call	myl_native_heap_alloc_at@PLT
	movq	%rax, %rcx
	testq	%rax, %rax
	je	.L3166
	movq	8(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rax, %rsi
	testq	%rdi, %rdi
	je	.L3169
	movq	24(%rax), %rdx
	movq	32(%rax), %rsi
	imulq	(%rdx), %rdi
	movq	%rdi, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	movq	%rax, %rcx
	movq	8(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rax, %rsi
	jmp	.L3169
	.p2align 4,,10
	.p2align 3
.L3184:
	movl	$4, %r14d
	jmp	.L3165
	.p2align 4,,10
	.p2align 3
.L3151:
	movq	%rcx, %rdx
	movq	%rbx, %rsi
	call	memcpy@PLT
	movq	8(%rsp), %rax
	.p2align 4
	.p2align 3
.L3163:
	addq	$1, (%rax)
	addq	$1, 16(%rax)
.L3164:
	movl	$1, %eax
	jmp	.L3146
	.p2align 4,,10
	.p2align 3
.L3170:
	movq	%rbx, %rsi
	movq	%rcx, (%rsp)
	call	memcpy@PLT
	movq	8(%rsp), %rax
	movq	(%rsp), %rcx
	.p2align 4
	.p2align 3
.L3182:
	addq	$1, (%rax)
	leaq	48(%rsp), %rsi
	movq	%rbp, %rdi
	addq	$1, 16(%rax)
	movq	%rcx, 32(%rax)
	movq	%r14, 8(%rax)
	call	myl_native_root_pop@PLT
	leaq	16(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
	jmp	.L3164
.L3161:
	movzwl	(%rbx), %eax
	movw	%ax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3163
.L3162:
	movzbl	(%rbx), %eax
	movb	%al, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3163
.L3152:
	movdqu	(%rbx), %xmm0
	movq	%rsi, %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%rbx), %xmm0
	movups	%xmm0, 48(%rdi)
	jmp	.L3163
.L3154:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%rbx), %rax
	movq	%rax, 48(%rdi)
	movq	%rsi, %rax
	jmp	.L3163
.L3155:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%rbx), %rax
	movq	%rax, 32(%rdi)
	movq	%rsi, %rax
	jmp	.L3163
.L3156:
	movdqu	(%rbx), %xmm0
	movq	%rsi, %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	jmp	.L3163
.L3157:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%rbx), %rax
	movq	%rax, 16(%rdi)
	movq	%rsi, %rax
	jmp	.L3163
.L3158:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	jmp	.L3163
.L3159:
	movq	(%rbx), %rax
	movq	%rax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3163
.L3160:
	movl	(%rbx), %eax
	movl	%eax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3163
.L3173:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rdi)
	movq	48(%rbx), %rax
	movq	%rax, 48(%rdi)
	movq	%rsi, %rax
	jmp	.L3182
.L3174:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movq	32(%rbx), %rax
	movq	%rax, 32(%rdi)
	movq	%rsi, %rax
	jmp	.L3182
.L3171:
	movdqu	(%rbx), %xmm0
	movq	%rsi, %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	movdqu	32(%rbx), %xmm0
	movups	%xmm0, 32(%rdi)
	movdqu	48(%rbx), %xmm0
	movups	%xmm0, 48(%rdi)
	jmp	.L3182
.L3175:
	movdqu	(%rbx), %xmm0
	movq	%rsi, %rax
	movups	%xmm0, (%rdi)
	movdqu	16(%rbx), %xmm0
	movups	%xmm0, 16(%rdi)
	jmp	.L3182
.L3176:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	movq	16(%rbx), %rax
	movq	%rax, 16(%rdi)
	movq	%rsi, %rax
	jmp	.L3182
.L3177:
	movdqu	(%rbx), %xmm0
	movups	%xmm0, (%rdi)
	jmp	.L3182
.L3178:
	movq	(%rbx), %rax
	movq	%rax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3182
.L3179:
	movl	(%rbx), %eax
	movl	%eax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3182
.L3180:
	movzwl	(%rbx), %eax
	movw	%ax, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3182
.L3181:
	movzbl	(%rbx), %eax
	movb	%al, (%rdi)
	movq	8(%rsp), %rax
	jmp	.L3182
.L3204:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE54:
	.size	myl_native_list_append, .-myl_native_list_append
	.p2align 4
	.globl	myl_native_list_append_scalar
	.type	myl_native_list_append_scalar, @function
myl_native_list_append_scalar:
.LFB55:
	.cfi_startproc
	endbr64
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdx, 8(%rsp)
	leaq	8(%rsp), %rdx
	call	myl_native_list_append
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE55:
	.size	myl_native_list_append_scalar, .-myl_native_list_append_scalar
	.p2align 4
	.globl	myl_native_list_extend
	.type	myl_native_list_extend, @function
myl_native_list_extend:
.LFB61:
	.cfi_startproc
	endbr64
	testq	%rsi, %rsi
	je	.L3218
	testq	%rdx, %rdx
	je	.L3218
	movq	24(%rdx), %rax
	cmpq	24(%rsi), %rax
	je	.L3222
.L3218:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3222:
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%rdx, %r14
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	(%rdx), %r13
	xorl	%ebx, %ebx
	testq	%r13, %r13
	jne	.L3209
	jmp	.L3211
	.p2align 4,,10
	.p2align 3
.L3223:
	addq	$1, %rbx
	cmpq	%rbx, %r13
	je	.L3211
	movq	24(%r14), %rax
.L3209:
	movq	(%rax), %rdx
	movq	%rbp, %rsi
	movq	%r12, %rdi
	imulq	%rbx, %rdx
	addq	32(%r14), %rdx
	call	myl_native_list_append
	testl	%eax, %eax
	jne	.L3223
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3211:
	.cfi_restore_state
	popq	%rbx
	.cfi_def_cfa_offset 40
	movl	$1, %eax
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE61:
	.size	myl_native_list_extend, .-myl_native_list_extend
	.section	.text.unlikely
.LCOLDB18:
	.text
.LHOTB18:
	.p2align 4
	.type	rc_list_clone, @function
rc_list_clone:
.LFB133:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movq	%rdx, %r13
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	movq	5640(%rdi), %rax
	movq	(%rsi), %r14
	movl	%ecx, 8(%rsp)
	movq	8(%rsi), %rbx
	cmpq	272(%rax), %rdx
	je	.L3225
	movq	%rdx, %rsi
	call	myl_rc_native_shape@PLT
	testq	%rax, %rax
	je	.L3227
	movq	5640(%r12), %rax
.L3225:
	cmpb	$0, 288(%rax)
	je	.L3259
.L3228:
	movl	8(%rsp), %ecx
	movl	$1, %edx
	leaq	myl_native_list_header_descriptor(%rip), %rsi
	movq	%r12, %rdi
	call	myl_rc_storage_alloc@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L3227
	cmpq	%rbx, %r14
	movq	%rbx, %rdx
	movq	%r13, 24(%rax)
	cmovnb	%r14, %rdx
	orq	%r14, %rbx
	jne	.L3260
	movq	%rdx, 8(%r15)
	movq	0(%rbp), %rdx
	testq	%rdx, %rdx
	je	.L3240
.L3232:
	movq	0(%r13), %rax
	testq	%rax, %rax
	jne	.L3261
.L3234:
	xorl	%ebx, %ebx
	jmp	.L3242
	.p2align 4,,10
	.p2align 3
.L3241:
	addq	$1, %rbx
	cmpq	0(%rbp), %rbx
	jnb	.L3240
.L3242:
	movq	0(%r13), %rcx
	movq	(%r15), %rdx
	movq	%r15, %rsi
	movq	%r12, %rdi
	imulq	%rbx, %rcx
	addq	32(%rbp), %rcx
	call	rc_list_insert_at
	testl	%eax, %eax
	jne	.L3241
.L3257:
	movq	%r15, %rsi
	movq	%r12, %rdi
	call	myl_rc_native_abort@PLT
.L3227:
	xorl	%r15d, %r15d
.L3224:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r15, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3259:
	.cfi_restore_state
	leaq	rc_list_module(%rip), %rsi
	movq	%r12, %rdi
	call	myl_rc_module_register@PLT
	testl	%eax, %eax
	jne	.L3262
	movq	5640(%r12), %rax
	movb	$1, 288(%rax)
	jmp	.L3228
	.p2align 4,,10
	.p2align 3
.L3260:
	movl	8(%rsp), %ecx
	movq	%r13, %rsi
	movq	%r12, %rdi
	movq	%rdx, 8(%rsp)
	call	myl_rc_native_storage@PLT
	movq	8(%rsp), %rdx
	testq	%rax, %rax
	movq	%rax, 32(%r15)
	je	.L3257
	movq	%rdx, 8(%r15)
	movq	0(%rbp), %rdx
	testq	%rdx, %rdx
	jne	.L3232
	.p2align 4
	.p2align 3
.L3240:
	movq	$0, 16(%r15)
	jmp	.L3224
	.p2align 4,,10
	.p2align 3
.L3262:
	movl	%eax, %esi
	movq	%r12, %rdi
	call	myl_rc_record_failure@PLT
	jmp	.L3227
	.p2align 4,,10
	.p2align 3
.L3261:
	movq	5640(%r12), %rcx
	cmpq	272(%rcx), %r13
	je	.L3235
	movl	52(%r13), %eax
	cmpq	160(%rcx), %rax
	jnb	.L3236
	salq	$4, %rax
	addq	152(%rcx), %rax
	cmpq	(%rax), %r13
	jne	.L3236
	movq	8(%rax), %rax
	testq	%rax, %rax
	je	.L3234
.L3237:
	movl	64(%rax), %edx
	testl	%edx, %edx
	jne	.L3239
	cmpb	$0, 69(%rax)
	jne	.L3239
	movq	5640(%r12), %rax
	movq	0(%rbp), %rdx
	movq	%r13, 272(%rax)
	movq	0(%r13), %rax
.L3235:
	imulq	%rax, %rdx
	movq	32(%r15), %rdi
	movq	32(%rbp), %rsi
	call	memcpy@PLT
	movq	0(%rbp), %rax
	movq	%rax, (%r15)
	jmp	.L3240
	.p2align 4,,10
	.p2align 3
.L3239:
	cmpq	$0, 0(%rbp)
	jne	.L3234
	jmp	.L3240
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	rc_list_clone.cold, @function
rc_list_clone.cold:
.LFSB133:
.L3236:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	%r13, %rsi
	movq	%r12, %rdi
	call	myl_rc_binding_find_slow@PLT
	testq	%rax, %rax
	jne	.L3237
	jmp	.L3239
	.cfi_endproc
.LFE133:
	.text
	.size	rc_list_clone, .-rc_list_clone
	.section	.text.unlikely
	.size	rc_list_clone.cold, .-rc_list_clone.cold
.LCOLDE18:
	.text
.LHOTE18:
	.p2align 4
	.globl	myl_native_list_copy
	.type	myl_native_list_copy, @function
myl_native_list_copy:
.LFB100:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdi, %rbx
	subq	$72, %rsp
	.cfi_def_cfa_offset 112
	movq	%fs:40, %rbp
	movq	%rbp, 56(%rsp)
	movq	%rsi, %rbp
	testq	%rdi, %rdi
	je	.L3264
	cmpq	$0, 5640(%rdi)
	je	.L3264
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3279
	movq	24(%rbp), %rdx
	movl	112(%rdi), %ecx
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movq	%rbp, %rsi
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	jmp	rc_list_clone
	.p2align 4,,10
	.p2align 3
.L3264:
	.cfi_restore_state
	leaq	8(%rsp), %rdx
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movq	%rbp, 8(%rsp)
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	call	myl_native_root_push@PLT
	movq	0(%rbp), %rdx
	movq	24(%rbp), %rsi
	movq	%rbx, %rdi
	call	myl_native_list_new
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L3266
	movq	0(%rbp), %rdx
	testq	%rdx, %rdx
	jne	.L3280
.L3267:
	movq	%rdx, (%r12)
.L3266:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	call	myl_native_root_pop@PLT
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3279
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movq	%r12, %rax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3280:
	.cfi_restore_state
	movq	32(%rax), %rdi
	movq	24(%rbp), %rax
	movq	32(%rbp), %rsi
	imulq	(%rax), %rdx
	call	memcpy@PLT
	movq	0(%rbp), %rdx
	jmp	.L3267
.L3279:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE100:
	.size	myl_native_list_copy, .-myl_native_list_copy
	.p2align 4
	.globl	myl_native_list_clone_at
	.type	myl_native_list_clone_at, @function
myl_native_list_clone_at:
.LFB104:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L3282
	cmpq	$0, 5640(%rdi)
	je	.L3282
	jmp	rc_list_clone
	.p2align 4,,10
	.p2align 3
.L3282:
	jmp	myl_native_list_clone_at.part.0
	.cfi_endproc
.LFE104:
	.size	myl_native_list_clone_at, .-myl_native_list_clone_at
	.p2align 4
	.type	rc_list_clone_adapter, @function
rc_list_clone_adapter:
.LFB112:
	.cfi_startproc
	endbr64
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movq	%rcx, %rbx
	movl	%edx, %ecx
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	24(%rsi), %rdx
	movq	%rdi, 8(%rsp)
	call	rc_list_clone
	movq	8(%rsp), %rdi
	movq	%rax, (%rbx)
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	movq	%rax, %rsi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	myl_rc_native_result@PLT
	.cfi_endproc
.LFE112:
	.size	rc_list_clone_adapter, .-rc_list_clone_adapter
	.p2align 4
	.globl	myl_native_list_literal_copy
	.type	myl_native_list_literal_copy, @function
myl_native_list_literal_copy:
.LFB102:
	.cfi_startproc
	endbr64
	movl	112(%rdi), %ecx
	movq	24(%rsi), %rdx
	cmpq	$0, 5640(%rdi)
	je	.L3289
	jmp	rc_list_clone
	.p2align 4,,10
	.p2align 3
.L3289:
	jmp	myl_native_list_clone_at.part.0
	.cfi_endproc
.LFE102:
	.size	myl_native_list_literal_copy, .-myl_native_list_literal_copy
	.p2align 4
	.globl	myl_native_list_literal_value
	.type	myl_native_list_literal_value, @function
myl_native_list_literal_value:
.LFB103:
	.cfi_startproc
	endbr64
	movl	112(%rdi), %ecx
	testl	%ecx, %ecx
	jne	.L3293
	movq	%rsi, %rax
	ret
	.p2align 4,,10
	.p2align 3
.L3293:
	movq	24(%rsi), %rdx
	cmpq	$0, 5640(%rdi)
	je	.L3292
	jmp	rc_list_clone
	.p2align 4,,10
	.p2align 3
.L3292:
	jmp	myl_native_list_clone_at.part.0
	.cfi_endproc
.LFE103:
	.size	myl_native_list_literal_value, .-myl_native_list_literal_value
	.p2align 4
	.globl	myl_native_list_slice_step
	.type	myl_native_list_slice_step, @function
myl_native_list_slice_step:
.LFB108:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	xorl	%r14d, %r14d
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	movq	%rsi, 8(%rsp)
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	testq	%r8, %r8
	je	.L3294
	movq	%rdx, %rbx
	movq	%rcx, %rdx
	movq	(%rsi), %rax
	movq	%rdi, %r12
	movabsq	$-9223372036854775808, %rcx
	movq	%r8, %rbp
	cmpq	%rcx, %rbx
	je	.L3366
	testq	%r8, %r8
	jle	.L3300
	testq	%rbx, %rbx
	jns	.L3301
	movabsq	$9223372036854775807, %rcx
	addq	%rax, %rbx
	js	.L3367
	cmpq	%rcx, %rdx
	je	.L3305
.L3304:
	testq	%rdx, %rdx
	js	.L3368
.L3321:
	cmpq	%rdx, %rax
	cmovg	%rdx, %rax
.L3309:
	xorl	%r13d, %r13d
	cmpq	%rbx, %rax
	jg	.L3305
.L3325:
	leaq	16(%rsp), %rax
	leaq	8(%rsp), %rdx
	movq	%r12, %rdi
	movq	%rax, %rsi
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	movq	%rax, (%rsp)
	call	myl_native_root_push@PLT
	movq	8(%rsp), %rax
	movq	%r13, %rdx
	movq	%r12, %rdi
	movq	24(%rax), %rsi
	call	myl_native_list_new
	movq	%rax, %r14
	testq	%rax, %rax
	je	.L3327
	testq	%r13, %r13
	je	.L3336
	xorl	%r15d, %r15d
	testq	%r12, %r12
	jne	.L3329
	jmp	.L3330
	.p2align 4,,10
	.p2align 3
.L3370:
	movq	(%r14), %rdx
	movq	%rsi, %rcx
	movq	%r12, %rdi
	movq	%r14, %rsi
	call	rc_list_insert_at
	testl	%eax, %eax
	je	.L3369
	addq	$1, %r15
	addq	%rbp, %rbx
	cmpq	%r13, %r15
	je	.L3336
.L3329:
	movq	8(%rsp), %rax
	movq	%rbx, %rsi
	movq	24(%rax), %rdx
	movq	(%rdx), %rdx
	imulq	%rdx, %rsi
	addq	32(%rax), %rsi
	cmpq	$0, 5640(%r12)
	jne	.L3370
	movq	%rdx, %rdi
	addq	%rbp, %rbx
	imulq	%r15, %rdi
	addq	$1, %r15
	addq	32(%r14), %rdi
	call	memcpy@PLT
	cmpq	%r13, %r15
	jne	.L3329
.L3336:
	movq	%r13, (%r14)
.L3335:
	movq	(%rsp), %rsi
	movq	%r12, %rdi
	call	myl_native_root_pop@PLT
.L3294:
	movq	56(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3371
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r14, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3366:
	.cfi_restore_state
	testq	%r8, %r8
	jle	.L3372
	testq	%rax, %rax
	jns	.L3340
	movabsq	$9223372036854775807, %rcx
	cmpq	%rcx, %rdx
	je	.L3373
	movq	%rax, %rbx
	testq	%rdx, %rdx
	jns	.L3321
.L3346:
	xorl	%eax, %eax
	.p2align 4
	.p2align 3
.L3305:
	subq	%rbx, %rax
	leaq	-1(%rbp,%rax), %rax
	cqto
	idivq	%rbp
	movq	%rax, %r13
	jmp	.L3325
	.p2align 4,,10
	.p2align 3
.L3330:
	movq	8(%rsp), %rax
	movq	%r15, %rdi
	movq	%rbx, %rsi
	addq	$1, %r15
	addq	%rbp, %rbx
	movq	24(%rax), %rdx
	movq	(%rdx), %rdx
	imulq	%rdx, %rdi
	addq	32(%r14), %rdi
	imulq	%rdx, %rsi
	addq	32(%rax), %rsi
	call	memcpy@PLT
	cmpq	%r15, %r13
	jne	.L3330
	jmp	.L3336
	.p2align 4,,10
	.p2align 3
.L3301:
	cmpq	%rbx, %rax
	jge	.L3306
	movabsq	$9223372036854775807, %rcx
	movq	%rax, %rbx
	cmpq	%rcx, %rdx
	jne	.L3304
	testq	%rax, %rax
	js	.L3346
	xorl	%r13d, %r13d
	jmp	.L3325
	.p2align 4,,10
	.p2align 3
.L3372:
	movq	%rax, %rbx
	subq	$1, %rbx
	js	.L3374
.L3360:
	movabsq	$9223372036854775807, %rcx
	cmpq	%rcx, %rdx
	je	.L3375
.L3312:
	testq	%rdx, %rdx
	js	.L3376
	leaq	-1(%rax), %rcx
	cmpq	%rdx, %rax
	cmovle	%rcx, %rdx
.L3324:
	cmpq	%rbx, %rdx
	jge	.L3320
.L3314:
	movq	%rbx, %rax
	movq	%rbp, %rcx
	subq	%rdx, %rax
	negq	%rcx
	subq	%rbp, %rax
	subq	$1, %rax
	cqto
	idivq	%rcx
	movq	%rax, %r13
	jmp	.L3325
	.p2align 4,,10
	.p2align 3
.L3300:
	testq	%rbx, %rbx
	js	.L3377
	cmpq	%rbx, %rax
	jg	.L3360
	movabsq	$9223372036854775807, %rcx
	leaq	-1(%rax), %rbx
	cmpq	%rcx, %rdx
	jne	.L3312
	testq	%rax, %rax
	jns	.L3319
	.p2align 4
	.p2align 3
.L3320:
	leaq	16(%rsp), %rax
	leaq	8(%rsp), %rdx
	movq	%r12, %rdi
	movq	%rax, %rsi
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	movq	%rax, (%rsp)
	call	myl_native_root_push@PLT
	movq	8(%rsp), %rax
	xorl	%edx, %edx
	movq	%r12, %rdi
	movq	24(%rax), %rsi
	call	myl_native_list_new
	movq	%rax, %r14
	testq	%rax, %rax
	jne	.L3378
.L3327:
	xorl	%r14d, %r14d
	jmp	.L3335
	.p2align 4,,10
	.p2align 3
.L3369:
	movq	%r14, %rsi
	movq	%r12, %rdi
	xorl	%r14d, %r14d
	call	myl_rc_native_abort@PLT
	jmp	.L3335
	.p2align 4,,10
	.p2align 3
.L3340:
	xorl	%ebx, %ebx
.L3306:
	movabsq	$9223372036854775807, %rcx
	cmpq	%rcx, %rdx
	jne	.L3304
	jmp	.L3309
	.p2align 4,,10
	.p2align 3
.L3368:
	addq	%rdx, %rax
	movl	$0, %edx
	cmovs	%rdx, %rax
	jmp	.L3309
	.p2align 4,,10
	.p2align 3
.L3377:
	movq	$-1, %rcx
	addq	%rax, %rbx
	cmovs	%rcx, %rbx
	movabsq	$9223372036854775807, %rcx
	cmpq	%rcx, %rdx
	jne	.L3312
	leaq	-1(%rax), %rdx
	testq	%rax, %rax
	js	.L3314
.L3319:
	movq	$-1, %rdx
	jmp	.L3324
	.p2align 4,,10
	.p2align 3
.L3367:
	xorl	%ebx, %ebx
	cmpq	%rcx, %rdx
	jne	.L3304
	xorl	%r13d, %r13d
	xorl	%ebx, %ebx
	testq	%rax, %rax
	js	.L3325
	jmp	.L3309
	.p2align 4,,10
	.p2align 3
.L3376:
	addq	%rax, %rdx
	movq	$-1, %rax
	cmovs	%rax, %rdx
	jmp	.L3324
.L3378:
	xorl	%r13d, %r13d
	jmp	.L3336
.L3373:
	movq	%rax, %rbx
	xorl	%eax, %eax
	jmp	.L3305
.L3374:
	movabsq	$9223372036854775807, %rcx
	cmpq	%rcx, %rdx
	je	.L3379
	testq	%rdx, %rdx
	js	.L3320
	movq	%rbx, %rdx
	movq	$-1, %rbx
	jmp	.L3324
.L3375:
	movq	$-1, %rdx
	jmp	.L3314
.L3379:
	testq	%rax, %rax
	je	.L3320
	movq	%rbx, %rdx
	movq	$-1, %rbx
	jmp	.L3314
.L3371:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE108:
	.size	myl_native_list_slice_step, .-myl_native_list_slice_step
	.p2align 4
	.globl	myl_native_list_insert
	.type	myl_native_list_insert, @function
myl_native_list_insert:
.LFB62:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	%rcx, %rbx
	addq	$-128, %rsp
	.cfi_def_cfa_offset 176
	movq	%rsi, 40(%rsp)
	movq	%fs:40, %rcx
	movq	%rcx, 120(%rsp)
	xorl	%ecx, %ecx
	testq	%rdi, %rdi
	je	.L3381
	cmpq	$0, 5640(%rdi)
	je	.L3381
	movq	(%rsi), %rax
	movq	%rdx, %rdi
	cmpq	%rdx, %rax
	cmovbe	%rax, %rdi
	testq	%rdx, %rdx
	jns	.L3383
	movq	%rdx, %rdi
	addq	%rax, %rdx
	negq	%rdi
	cmpq	%rdi, %rax
	movq	%rcx, %rdi
	cmovnb	%rdx, %rdi
.L3383:
	movq	%rdi, %rdx
	movq	%rbx, %rcx
	movq	%rbp, %rdi
	call	rc_list_insert_at
.L3380:
	movq	120(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L3425
	subq	$-128, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%rbp
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3381:
	.cfi_restore_state
	testq	%rsi, %rsi
	je	.L3385
	cmpq	$-1, 16(%rsi)
	je	.L3385
	movq	(%rsi), %rax
	leaq	myl_rc_pointer_leaf(%rip), %rcx
	leaq	48(%rsp), %rsi
	movq	%rbp, %rdi
	cmpq	%rax, %rdx
	movq	%rax, %r9
	cmovbe	%rdx, %r9
	addq	%rdx, %rax
	testq	%rdx, %rdx
	cmovs	%rax, %r9
	xorl	%eax, %eax
	testq	%r9, %r9
	cmovns	%r9, %rax
	testq	%rdx, %rdx
	leaq	40(%rsp), %rdx
	cmovs	%rax, %r9
	movq	%r9, (%rsp)
	call	myl_native_root_push@PLT
	movq	40(%rsp), %rax
	movq	%rbp, %rdi
	movq	%rbx, %rdx
	leaq	80(%rsp), %rsi
	movq	24(%rax), %rcx
	call	myl_native_root_push@PLT
	movq	40(%rsp), %r10
	movq	(%rsp), %r9
	movq	32(%r10), %r12
	movq	(%r10), %rsi
	movq	8(%r10), %rdi
	cmpq	%r12, %rbx
	leaq	1(%rsi), %rcx
	jb	.L3388
	movq	24(%r10), %rax
	movq	(%rax), %r8
	movq	%r8, %rax
	imulq	%rsi, %rax
	addq	%r12, %rax
	cmpq	%rax, %rbx
	jnb	.L3388
	movq	%rbx, %rax
	xorl	%edx, %edx
	subq	%r12, %rax
	divq	%r8
	movq	%rax, %r11
	cmpq	%rcx, %rdi
	jnb	.L3389
.L3400:
	movl	$4, %r8d
	cmpq	%r8, %rdi
	cmovnb	%rdi, %r8
	movq	%r8, %r12
	cmpq	%rcx, %r8
	jb	.L3392
	jmp	.L3390
	.p2align 4
	.p2align 4,,10
	.p2align 3
.L3426:
	addq	%r12, %r12
	cmpq	%rcx, %r12
	jnb	.L3390
.L3392:
	testq	%r12, %r12
	jns	.L3426
.L3391:
	leaq	80(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
	leaq	48(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
.L3385:
	xorl	%eax, %eax
	jmp	.L3380
	.p2align 4,,10
	.p2align 3
.L3388:
	movq	$-1, %r11
	cmpq	%rcx, %rdi
	jb	.L3400
	movq	24(%r10), %rax
	movq	(%rax), %r8
.L3395:
	cmpq	%rsi, %r9
	jb	.L3403
	movq	%r9, %rcx
	imulq	%r8, %rcx
	addq	%r12, %rcx
.L3397:
	movq	%rcx, %rdi
	movq	%r8, %rdx
	movq	%rbx, %rsi
	call	memcpy@PLT
	movq	40(%rsp), %rax
	leaq	80(%rsp), %rsi
	movq	%rbp, %rdi
	addq	$1, (%rax)
	addq	$1, 16(%rax)
	call	myl_native_root_pop@PLT
	leaq	48(%rsp), %rsi
	movq	%rbp, %rdi
	call	myl_native_root_pop@PLT
	movl	$1, %eax
	jmp	.L3380
	.p2align 4,,10
	.p2align 3
.L3390:
	movq	%r10, %rsi
	movq	%rbp, %rdi
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	movq	%r10, (%rsp)
	call	myl_native_object_region@PLT
	movq	(%rsp), %r10
	movq	%r12, %rdx
	movq	%rbp, %rdi
	movl	%eax, %ecx
	movq	24(%r10), %rsi
	call	myl_native_heap_alloc_at@PLT
	movq	%rax, %rcx
	testq	%rax, %rax
	je	.L3391
	movq	(%rsp), %r10
	movq	8(%rsp), %r9
	movq	16(%rsp), %r11
	movq	(%r10), %rdx
	testq	%rdx, %rdx
	jne	.L3427
.L3393:
	movq	40(%rsp), %rax
	movq	%rcx, 32(%r10)
	movq	%r12, 8(%r10)
	movq	24(%rax), %rdx
	movq	32(%rax), %r12
	movq	(%rax), %rsi
	movq	(%rdx), %r8
	cmpq	$-1, %r11
	je	.L3395
.L3389:
	movq	%r8, %rbx
	imulq	%r11, %rbx
	addq	%r12, %rbx
	cmpq	%rsi, %r9
	jb	.L3404
	movq	%r9, %rcx
	movl	$1, %r10d
	imulq	%r8, %rcx
	addq	%r12, %rcx
.L3398:
	cmpq	%r9, %r11
	jb	.L3397
	testb	%r10b, %r10b
	je	.L3397
	addq	$1, %r11
	imulq	%r8, %r11
	leaq	(%r12,%r11), %rbx
	jmp	.L3397
	.p2align 4,,10
	.p2align 3
.L3404:
	movl	$1, %r10d
.L3396:
	movq	%r9, %rax
	subq	%r9, %rsi
	movb	%r10b, 39(%rsp)
	imulq	%r8, %rax
	movq	%rsi, %rdx
	movq	%r11, 24(%rsp)
	imulq	%r8, %rdx
	movq	%r9, 16(%rsp)
	movq	%r8, 8(%rsp)
	leaq	(%r12,%rax), %rcx
	addq	%r8, %rax
	movq	%rcx, %rsi
	leaq	(%r12,%rax), %rdi
	movq	%rcx, (%rsp)
	call	memmove@PLT
	movzbl	39(%rsp), %r10d
	movq	24(%rsp), %r11
	movq	16(%rsp), %r9
	movq	8(%rsp), %r8
	movq	(%rsp), %rcx
	jmp	.L3398
	.p2align 4,,10
	.p2align 3
.L3427:
	movq	24(%r10), %rax
	movq	32(%r10), %rsi
	movq	%rcx, %rdi
	imulq	(%rax), %rdx
	call	memcpy@PLT
	movq	16(%rsp), %r11
	movq	8(%rsp), %r9
	movq	(%rsp), %r10
	movq	%rax, %rcx
	jmp	.L3393
	.p2align 4,,10
	.p2align 3
.L3403:
	movq	$-1, %r11
	xorl	%r10d, %r10d
	jmp	.L3396
.L3425:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE62:
	.size	myl_native_list_insert, .-myl_native_list_insert
	.section	.text.unlikely
.LCOLDB19:
	.text
.LHOTB19:
	.p2align 4
	.globl	myl_rc_list_plain_ready
	.type	myl_rc_list_plain_ready, @function
myl_rc_list_plain_ready:
.LFB123:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L3457
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.L3457
	cmpq	$0, 200(%rax)
	jne	.L3457
	testq	%rsi, %rsi
	je	.L3457
	movq	24(%rsi), %rdx
	testq	%rdx, %rdx
	je	.L3457
	cmpq	280(%rax), %rdx
	je	.L3459
	movzwl	48(%rdx), %ecx
	testw	%cx, %cx
	je	.L3439
	cmpw	$7, %cx
	jne	.L3457
.L3439:
	movq	(%rdx), %rcx
	leaq	-4(%rcx), %rsi
	testq	$-5, %rsi
	je	.L3440
	subq	$1, %rcx
	cmpq	$1, %rcx
	jbe	.L3440
.L3457:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3440:
	cmpq	272(%rax), %rdx
	je	.L3460
	movl	52(%rdx), %ecx
	cmpq	160(%rax), %rcx
	jnb	.L3436
	salq	$4, %rcx
	addq	152(%rax), %rcx
	cmpq	(%rcx), %rdx
	jne	.L3436
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.L3457
	movl	64(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L3457
	cmpb	$0, 69(%rax)
	jne	.L3457
	movq	5640(%rdi), %rax
	movq	%rdx, 272(%rax)
.L3460:
	movq	%rdx, 280(%rax)
.L3459:
	movl	$1, %eax
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_plain_ready.cold, @function
myl_rc_list_plain_ready.cold:
.LFSB123:
.L3436:
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdx, %rsi
	movq	%rdx, 8(%rsp)
	movq	%rdi, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rsp), %rdi
	movq	8(%rsp), %rdx
	testq	%rax, %rax
	je	.L3431
	cmpl	$0, 64(%rax)
	jne	.L3431
	cmpb	$0, 69(%rax)
	jne	.L3431
	movq	5640(%rdi), %rax
	movq	%rdx, 272(%rax)
	movq	%rdx, 280(%rax)
	movl	$1, %eax
.L3428:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L3431:
	.cfi_restore_state
	xorl	%eax, %eax
	jmp	.L3428
	.cfi_endproc
.LFE123:
	.text
	.size	myl_rc_list_plain_ready, .-myl_rc_list_plain_ready
	.section	.text.unlikely
	.size	myl_rc_list_plain_ready.cold, .-myl_rc_list_plain_ready.cold
.LCOLDE19:
	.text
.LHOTE19:
	.section	.text.unlikely
.LCOLDB20:
	.text
.LHOTB20:
	.p2align 4
	.globl	myl_rc_list_plain_ready_hot
	.type	myl_rc_list_plain_ready_hot, @function
myl_rc_list_plain_ready_hot:
.LFB124:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L3496
	movq	5640(%rdi), %rax
	testq	%rax, %rax
	je	.L3496
	cmpq	$0, 200(%rax)
	jne	.L3496
	testq	%rsi, %rsi
	je	.L3496
	movq	24(%rsi), %rdx
	testq	%rdx, %rdx
	je	.L3496
	cmpq	280(%rax), %rdx
	je	.L3498
	movzwl	48(%rdx), %ecx
	testw	%cx, %cx
	je	.L3478
	cmpw	$7, %cx
	jne	.L3496
.L3478:
	movq	(%rdx), %rcx
	leaq	-4(%rcx), %rsi
	testq	$-5, %rsi
	je	.L3479
	subq	$1, %rcx
	cmpq	$1, %rcx
	jbe	.L3479
.L3496:
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3479:
	cmpq	272(%rax), %rdx
	je	.L3499
	movl	52(%rdx), %ecx
	cmpq	160(%rax), %rcx
	jnb	.L3475
	salq	$4, %rcx
	addq	152(%rax), %rcx
	cmpq	(%rcx), %rdx
	jne	.L3475
	movq	8(%rcx), %rax
	testq	%rax, %rax
	je	.L3496
	movl	64(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L3496
	cmpb	$0, 69(%rax)
	jne	.L3496
	movq	5640(%rdi), %rax
	movq	%rdx, 272(%rax)
.L3499:
	movq	%rdx, 280(%rax)
.L3498:
	movl	$1, %eax
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_plain_ready_hot.cold, @function
myl_rc_list_plain_ready_hot.cold:
.LFSB124:
.L3475:
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdx, %rsi
	movq	%rdx, 8(%rsp)
	movq	%rdi, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rsp), %rdi
	movq	8(%rsp), %rdx
	testq	%rax, %rax
	je	.L3470
	cmpl	$0, 64(%rax)
	jne	.L3470
	cmpb	$0, 69(%rax)
	jne	.L3470
	movq	5640(%rdi), %rax
	movq	%rdx, 272(%rax)
	movq	%rdx, 280(%rax)
	movl	$1, %eax
.L3467:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L3470:
	.cfi_restore_state
	xorl	%eax, %eax
	jmp	.L3467
	.cfi_endproc
.LFE124:
	.text
	.size	myl_rc_list_plain_ready_hot, .-myl_rc_list_plain_ready_hot
	.section	.text.unlikely
	.size	myl_rc_list_plain_ready_hot.cold, .-myl_rc_list_plain_ready_hot.cold
.LCOLDE20:
	.text
.LHOTE20:
	.p2align 4
	.globl	myl_rc_list_append
	.type	myl_rc_list_append, @function
myl_rc_list_append:
.LFB125:
	.cfi_startproc
	endbr64
	movq	%rdx, %rcx
	movq	(%rsi), %rdx
	jmp	rc_list_insert_at
	.cfi_endproc
.LFE125:
	.size	myl_rc_list_append, .-myl_rc_list_append
	.p2align 4
	.globl	myl_rc_list_insert
	.type	myl_rc_list_insert, @function
myl_rc_list_insert:
.LFB126:
	.cfi_startproc
	endbr64
	movq	(%rsi), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rdx, %rsi
	cmpq	%rdx, %rax
	cmovbe	%rax, %rsi
	testq	%rdx, %rdx
	jns	.L3509
	movq	%rdx, %rsi
	addq	%rax, %rdx
	negq	%rsi
	cmpq	%rsi, %rax
	movl	$0, %esi
	cmovnb	%rdx, %rsi
.L3509:
	movq	%rsi, %rdx
	movq	%rdi, %rsi
	movq	%r8, %rdi
	jmp	rc_list_insert_at
	.cfi_endproc
.LFE126:
	.size	myl_rc_list_insert, .-myl_rc_list_insert
	.p2align 4
	.globl	myl_rc_list_set
	.type	myl_rc_list_set, @function
myl_rc_list_set:
.LFB127:
	.cfi_startproc
	endbr64
	cmpq	(%rsi), %rdx
	jnb	.L3512
	movabsq	$4611686018427387904, %r9
	movq	-16(%rsi), %rax
	movq	%rax, %r8
	shrq	$40, %r8
	andl	$1048575, %r8d
	testq	%r9, %rax
	movl	$0, %eax
	cmove	%eax, %r8d
	movq	24(%rsi), %rax
	imulq	(%rax), %rdx
	addq	32(%rsi), %rdx
	movq	%rax, %rsi
	jmp	myl_rc_native_retain_replace@PLT
	.p2align 4,,10
	.p2align 3
.L3512:
	xorl	%eax, %eax
	ret
	.cfi_endproc
.LFE127:
	.size	myl_rc_list_set, .-myl_rc_list_set
	.section	.text.unlikely
.LCOLDB21:
	.text
.LHOTB21:
	.p2align 4
	.globl	myl_rc_list_pop
	.type	myl_rc_list_pop, @function
myl_rc_list_pop:
.LFB129:
	.cfi_startproc
	endbr64
	movq	(%rsi), %r9
	testq	%r9, %r9
	je	.L3524
	cmpq	$-1, 16(%rsi)
	je	.L3524
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	leaq	-1(%r9), %r10
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rsi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 64
	movq	24(%rsi), %rsi
	movq	(%rsi), %r11
	imulq	%r11, %r10
	addq	32(%rbx), %r10
	testq	%rdx, %rdx
	je	.L3517
	movl	112(%rdi), %r8d
	movq	%r10, %rcx
	movq	%r11, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r10, 8(%rsp)
	call	myl_rc_native_take@PLT
	movq	8(%rsp), %r10
	movq	16(%rsp), %r9
	testl	%eax, %eax
	movq	24(%rsp), %r11
	movl	$-1, %eax
	je	.L3515
.L3518:
	movq	(%rbx), %rdi
	movq	%rdi, %rdx
	subq	%r9, %rdx
	jne	.L3535
.L3522:
	subq	$1, %rdi
	movq	%r11, %rdx
	xorl	%esi, %esi
	imulq	%r11, %rdi
	addq	32(%rbx), %rdi
	call	memset@PLT
	subq	$1, (%rbx)
	movq	%rbp, %rdi
	addq	$1, 16(%rbx)
	call	myl_rc_drain@PLT
	movl	$1, %eax
.L3515:
	addq	$40, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3524:
	.cfi_restore 3
	.cfi_restore 6
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3517:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	5640(%rdi), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L3519
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L3519
	movq	8(%rax), %rax
.L3520:
	testq	%rax, %rax
	je	.L3530
	movq	8(%rax), %rsi
	movq	%r10, %rdx
	movl	$1, %ecx
	movq	%rbp, %rdi
	movq	%r11, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r10, 8(%rsp)
	call	myl_rc_edges_release@PLT
	movq	24(%rsp), %r11
	movq	16(%rsp), %r9
	movq	8(%rsp), %r10
	jmp	.L3518
	.p2align 4,,10
	.p2align 3
.L3535:
	imulq	%r11, %rdx
	leaq	(%r10,%r11), %rsi
	movq	%r10, %rdi
	movq	%r11, 8(%rsp)
	call	memmove@PLT
	movq	(%rbx), %rdi
	movq	8(%rsp), %r11
	jmp	.L3522
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_pop.cold, @function
myl_rc_list_pop.cold:
.LFSB129:
.L3519:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	%rbp, %rdi
	movq	%r10, 24(%rsp)
	movq	%r11, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %r9
	movq	16(%rsp), %r11
	movq	24(%rsp), %r10
	jmp	.L3520
.L3530:
	call	abort@PLT
	.cfi_endproc
.LFE129:
	.text
	.size	myl_rc_list_pop, .-myl_rc_list_pop
	.section	.text.unlikely
	.size	myl_rc_list_pop.cold, .-myl_rc_list_pop.cold
.LCOLDE21:
	.text
.LHOTE21:
	.section	.text.unlikely
.LCOLDB22:
	.text
.LHOTB22:
	.p2align 4
	.globl	myl_rc_list_pop_at
	.type	myl_rc_list_pop_at, @function
myl_rc_list_pop_at:
.LFB130:
	.cfi_startproc
	endbr64
	movq	(%rsi), %rax
	movq	%rdx, %r9
	testq	%rdx, %rdx
	js	.L3558
.L3537:
	cmpq	%rax, %r9
	jnb	.L3547
	cmpq	$-1, 16(%rsi)
	je	.L3547
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%r9, %r11
	movq	%rcx, %rdx
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rsi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 64
	movq	24(%rsi), %rsi
	movq	(%rsi), %r10
	imulq	%r10, %r11
	addq	32(%rbx), %r11
	testq	%rcx, %rcx
	je	.L3539
	movl	112(%rdi), %r8d
	movq	%r11, %rcx
	movq	%r10, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r11, 8(%rsp)
	call	myl_rc_native_take@PLT
	movq	8(%rsp), %r11
	movq	16(%rsp), %r9
	testl	%eax, %eax
	movq	24(%rsp), %r10
	movl	$-1, %eax
	je	.L3536
	movq	(%rbx), %rax
	leaq	-1(%rax), %rdi
	movq	%rdi, %rdx
	subq	%r9, %rdx
	jne	.L3559
.L3544:
	imulq	%r10, %rdi
	movq	%r10, %rdx
	addq	32(%rbx), %rdi
	xorl	%esi, %esi
	call	memset@PLT
	subq	$1, (%rbx)
	movq	%rbp, %rdi
	addq	$1, 16(%rbx)
	call	myl_rc_drain@PLT
	movl	$1, %eax
.L3536:
	addq	$40, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3547:
	.cfi_restore 3
	.cfi_restore 6
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L3558:
	negq	%rdx
	cmpq	%rdx, %rax
	jb	.L3547
	addq	%rax, %r9
	jmp	.L3537
	.p2align 4,,10
	.p2align 3
.L3539:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	5640(%rdi), %rdx
	movl	52(%rsi), %eax
	cmpq	160(%rdx), %rax
	jnb	.L3541
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L3541
	movq	8(%rax), %rax
.L3542:
	testq	%rax, %rax
	je	.L3553
	movq	8(%rax), %rsi
	movq	%r11, %rdx
	movq	%rbp, %rdi
	movl	$1, %ecx
	movq	%r10, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r11, 8(%rsp)
	call	myl_rc_edges_release@PLT
	movq	(%rbx), %rax
	movq	16(%rsp), %r9
	movq	24(%rsp), %r10
	movq	8(%rsp), %r11
	leaq	-1(%rax), %rdi
	movq	%rdi, %rdx
	subq	%r9, %rdx
	je	.L3544
.L3559:
	imulq	%r10, %rdx
	leaq	(%r11,%r10), %rsi
	movq	%r11, %rdi
	movq	%r10, 8(%rsp)
	call	memmove@PLT
	movq	(%rbx), %rax
	movq	8(%rsp), %r10
	leaq	-1(%rax), %rdi
	jmp	.L3544
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_pop_at.cold, @function
myl_rc_list_pop_at.cold:
.LFSB130:
.L3541:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -24
	.cfi_offset 6, -16
	movq	%rbp, %rdi
	movq	%r11, 24(%rsp)
	movq	%r10, 16(%rsp)
	movq	%r9, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %r9
	movq	16(%rsp), %r10
	movq	24(%rsp), %r11
	jmp	.L3542
.L3553:
	call	abort@PLT
	.cfi_endproc
.LFE130:
	.text
	.size	myl_rc_list_pop_at, .-myl_rc_list_pop_at
	.section	.text.unlikely
	.size	myl_rc_list_pop_at.cold, .-myl_rc_list_pop_at.cold
.LCOLDE22:
	.text
.LHOTE22:
	.p2align 4
	.globl	myl_rc_list_clear
	.type	myl_rc_list_clear, @function
myl_rc_list_clear:
.LFB131:
	.cfi_startproc
	endbr64
	movq	(%rsi), %rcx
	testq	%rcx, %rcx
	je	.L3569
	movq	16(%rsi), %rdx
	xorl	%eax, %eax
	cmpq	$-1, %rdx
	je	.L3570
	addq	$1, %rdx
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	$0, (%rsi)
	movq	%rsi, %rax
	movq	%rdx, 16(%rsi)
	movq	32(%rsi), %rdx
	movq	24(%rsi), %rsi
	movq	%rax, 24(%rsp)
	movq	%rcx, 16(%rsp)
	movq	%rdi, 8(%rsp)
	call	rc_elements_release
	movq	24(%rsp), %rax
	movq	16(%rsp), %rcx
	xorl	%esi, %esi
	movq	24(%rax), %rdx
	movq	32(%rax), %rdi
	imulq	(%rdx), %rcx
	movq	%rcx, %rdx
	call	memset@PLT
	movq	8(%rsp), %rdi
	call	myl_rc_drain@PLT
	movl	$1, %eax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3570:
	ret
	.p2align 4,,10
	.p2align 3
.L3569:
	movl	$1, %eax
	ret
	.cfi_endproc
.LFE131:
	.size	myl_rc_list_clear, .-myl_rc_list_clear
	.section	.text.unlikely
.LCOLDB23:
	.text
.LHOTB23:
	.p2align 4
	.globl	myl_rc_list_remove
	.type	myl_rc_list_remove, @function
myl_rc_list_remove:
.LFB132:
	.cfi_startproc
	endbr64
	cmpq	$0, (%rsi)
	je	.L3596
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	movq	%rdi, %r14
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	xorl	%ebx, %ebx
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	jmp	.L3574
	.p2align 4,,10
	.p2align 3
.L3598:
	movq	0(%rbp), %rax
	jne	.L3597
	addq	$1, %rbx
	cmpq	%rax, %rbx
	jnb	.L3577
.L3574:
	movq	24(%rbp), %rdi
	movq	%r12, %rdx
	movq	(%rdi), %rsi
	imulq	%rbx, %rsi
	addq	32(%rbp), %rsi
	call	myl_native_equal@PLT
	testl	%eax, %eax
	jns	.L3598
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$-1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3597:
	.cfi_restore_state
	cmpq	%rax, %rbx
	jnb	.L3577
	cmpq	$-1, 16(%rbp)
	jne	.L3599
.L3577:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3599:
	.cfi_restore_state
	movq	24(%rbp), %rsi
	movq	5640(%r14), %rdx
	movq	(%rsi), %r12
	movl	52(%rsi), %eax
	movq	%r12, %r8
	imulq	%rbx, %r8
	addq	32(%rbp), %r8
	cmpq	160(%rdx), %rax
	jnb	.L3579
	salq	$4, %rax
	addq	152(%rdx), %rax
	cmpq	(%rax), %rsi
	jne	.L3579
	movq	8(%rax), %rax
.L3580:
	testq	%rax, %rax
	je	.L3590
	movq	8(%rax), %rsi
	movq	%r8, %rdx
	movq	%r14, %rdi
	movl	$1, %ecx
	movq	%r8, 8(%rsp)
	call	myl_rc_edges_release@PLT
	movq	0(%rbp), %rax
	movq	8(%rsp), %r8
	leaq	-1(%rax), %rdi
	movq	%rdi, %rdx
	subq	%rbx, %rdx
	jne	.L3600
.L3582:
	movq	%r12, %rdx
	imulq	%r12, %rdi
	xorl	%esi, %esi
	addq	32(%rbp), %rdi
	call	memset@PLT
	subq	$1, 0(%rbp)
	movq	%r14, %rdi
	addq	$1, 16(%rbp)
	call	myl_rc_drain@PLT
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	ret
.L3600:
	.cfi_restore_state
	imulq	%r12, %rdx
	movq	%r8, %rdi
	leaq	(%r8,%r12), %rsi
	call	memmove@PLT
	movq	0(%rbp), %rax
	leaq	-1(%rax), %rdi
	jmp	.L3582
.L3596:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 14
	xorl	%eax, %eax
	ret
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_remove.cold, @function
myl_rc_list_remove.cold:
.LFSB132:
.L3590:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -40
	.cfi_offset 6, -32
	.cfi_offset 12, -24
	.cfi_offset 14, -16
	call	abort@PLT
.L3579:
	movq	%r14, %rdi
	movq	%r8, 8(%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	8(%rsp), %r8
	jmp	.L3580
	.cfi_endproc
.LFE132:
	.text
	.size	myl_rc_list_remove, .-myl_rc_list_remove
	.section	.text.unlikely
	.size	myl_rc_list_remove.cold, .-myl_rc_list_remove.cold
.LCOLDE23:
	.text
.LHOTE23:
	.section	.text.unlikely
.LCOLDB24:
	.text
.LHOTB24:
	.p2align 4
	.globl	myl_rc_list_sort_keyed
	.type	myl_rc_list_sort_keyed, @function
myl_rc_list_sort_keyed:
.LFB134:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$264, %rsp
	.cfi_def_cfa_offset 320
	movq	8(%rsi), %r10
	movq	(%rsi), %rdi
	movq	%fs:40, %rbx
	movq	%rbx, 248(%rsp)
	movq	%rsi, %rbx
	cmpq	%r10, %rdi
	je	.L3602
	movq	24(%r10), %rdx
	cmpq	$0, (%rdx)
	jne	.L3739
.L3603:
	movabsq	$4611686018427387904, %rsi
	movq	-16(%rdi), %rax
	movq	%rbp, %rdi
	movq	%rax, %rcx
	shrq	$40, %rcx
	andl	$1048575, %ecx
	testq	%rsi, %rax
	movl	$0, %eax
	movq	%r10, %rsi
	cmove	%eax, %ecx
	call	rc_list_clone
	movq	%rax, %r8
	testq	%rax, %rax
	je	.L3617
	movq	16(%rbx), %rsi
	testq	%rsi, %rsi
	je	.L3620
	movq	(%rax), %r9
	cmpq	(%rsi), %r9
	je	.L3740
.L3620:
	xorl	%eax, %eax
.L3616:
	movq	%r8, %rsi
	movq	%rbp, %rdi
	movl	%eax, (%rsp)
	call	myl_rc_native_abort@PLT
	movl	(%rsp), %eax
.L3601:
	movq	248(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L3738
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3739:
	.cfi_restore_state
	movq	5640(%rbp), %rcx
	cmpq	272(%rcx), %rdx
	je	.L3604
	movl	52(%rdx), %eax
	cmpq	160(%rcx), %rax
	jnb	.L3605
	salq	$4, %rax
	addq	152(%rcx), %rax
	cmpq	(%rax), %rdx
	jne	.L3605
	movq	8(%rax), %rax
	testq	%rax, %rax
	je	.L3603
.L3606:
	movl	64(%rax), %ecx
	testl	%ecx, %ecx
	jne	.L3607
	cmpb	$0, 69(%rax)
	jne	.L3607
	movq	5640(%rbp), %rax
	movq	%rdx, 272(%rax)
.L3604:
	movq	248(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L3738
	movq	24(%rbx), %rcx
	movq	16(%rbx), %rdx
	movq	%r10, %rsi
	movq	40(%rbx), %r9
	movq	32(%rbx), %r8
	addq	$264, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	myl_native_list_sort_keyed
	.p2align 4,,10
	.p2align 3
.L3602:
	.cfi_restore_state
	movq	16(%rbx), %rsi
	testq	%r10, %r10
	je	.L3617
	testq	%rsi, %rsi
	je	.L3617
	movq	(%r10), %r9
	cmpq	(%rsi), %r9
	jne	.L3617
	movq	%r10, %xmm0
	xorl	%r8d, %r8d
	punpcklqdq	%xmm0, %xmm0
.L3621:
	movq	24(%rbx), %rax
	movq	24(%r10), %rdi
	movq	40(%rbx), %r12
	movq	32(%rbx), %rdx
	movl	%eax, %r11d
	movq	(%rdi), %r13
	movq	24(%rsi), %rdi
	andl	$15, %r11d
	leal	-1(%r11), %r10d
	movl	%r11d, 80(%rsp)
	movq	(%rdi), %rdi
	cmpl	$7, %r10d
	ja	.L3623
	movq	%rax, %r10
	shrq	$4, %r10
	andl	$15, %r10d
	cmpl	$7, %r10d
	je	.L3741
	movl	%r10d, %ecx
	leaq	widths.0(%rip), %r15
	shrl	$2, %r10d
	movb	%dl, 100(%rsp)
	andl	$3, %ecx
	movzbl	(%r15,%r10), %r10d
	movb	%cl, 84(%rsp)
	subl	$2, %ecx
	movb	%r10b, 92(%rsp)
	cmpb	$1, %cl
	ja	.L3625
	cmpb	$8, %r10b
	jne	.L3623
.L3625:
	movzbl	%dl, %ecx
	addq	%rcx, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	testb	$14, %al
	je	.L3629
	movq	%rax, %r10
	shrq	$8, %r10
	movl	%r10d, %ecx
	movq	%rdx, %r10
	andl	$15, %ecx
	shrq	$8, %r10
	cmpl	$7, %ecx
	je	.L3742
	movl	%ecx, %r15d
	movl	%ecx, %r14d
	leaq	widths.0(%rip), %rcx
	movb	%r10b, 101(%rsp)
	shrl	$2, %r15d
	andl	$3, %r14d
	movzbl	(%rcx,%r15), %ecx
	leal	-2(%r14), %r15d
	movb	%r14b, 85(%rsp)
	movb	%cl, 93(%rsp)
	cmpb	$1, %r15b
	ja	.L3631
	cmpb	$8, %cl
	jne	.L3623
.L3631:
	movzbl	%r10b, %r10d
	addq	%rcx, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	cmpl	$2, %r11d
	jbe	.L3629
	movq	%rax, %r10
	movq	%rdx, %rcx
	shrq	$12, %r10
	shrq	$16, %rcx
	andl	$15, %r10d
	cmpl	$7, %r10d
	je	.L3743
	movl	%r10d, %r14d
	movl	%r10d, %r15d
	leaq	widths.0(%rip), %r10
	movb	%cl, 102(%rsp)
	shrl	$2, %r14d
	andl	$3, %r15d
	movzbl	(%r10,%r14), %r14d
	movb	%r15b, 86(%rsp)
	subl	$2, %r15d
	movb	%r14b, 94(%rsp)
	cmpb	$1, %r15b
	ja	.L3634
	cmpb	$8, %r14b
	jne	.L3623
.L3634:
	movzbl	%cl, %r10d
	addq	%r14, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	testb	$12, %al
	je	.L3629
	movq	%rax, %r10
	movq	%rdx, %rcx
	shrq	$16, %r10
	shrq	$24, %rcx
	andl	$15, %r10d
	cmpl	$7, %r10d
	je	.L3744
	movl	%r10d, %r14d
	movl	%r10d, %r15d
	leaq	widths.0(%rip), %r10
	movb	%cl, 103(%rsp)
	shrl	$2, %r14d
	andl	$3, %r15d
	movzbl	(%r10,%r14), %r14d
	movb	%r15b, 87(%rsp)
	subl	$2, %r15d
	movb	%r14b, 95(%rsp)
	cmpb	$1, %r15b
	ja	.L3637
	cmpb	$8, %r14b
	jne	.L3623
.L3637:
	movzbl	%cl, %r10d
	addq	%r14, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	cmpl	$4, %r11d
	jbe	.L3629
	movq	%rax, %r10
	movq	%rdx, %rcx
	shrq	$20, %r10
	shrq	$32, %rcx
	andl	$15, %r10d
	cmpl	$7, %r10d
	je	.L3745
	movl	%r10d, %r14d
	movl	%r10d, %r15d
	leaq	widths.0(%rip), %r10
	movb	%cl, 104(%rsp)
	shrl	$2, %r14d
	andl	$3, %r15d
	movzbl	(%r10,%r14), %r14d
	movb	%r15b, 88(%rsp)
	subl	$2, %r15d
	movb	%r14b, 96(%rsp)
	cmpb	$1, %r15b
	ja	.L3670
	cmpb	$8, %r14b
	jne	.L3623
.L3670:
	movzbl	%r14b, %r15d
.L3640:
	movzbl	%cl, %r10d
	addq	%r15, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	cmpl	$5, %r11d
	je	.L3629
	movq	%rax, %r10
	movq	%rdx, %rcx
	shrq	$24, %r10
	shrq	$40, %rcx
	andl	$15, %r10d
	cmpl	$7, %r10d
	je	.L3746
	movl	%r10d, %r14d
	movl	%r10d, %r15d
	leaq	widths.0(%rip), %r10
	movb	%cl, 105(%rsp)
	shrl	$2, %r14d
	andl	$3, %r15d
	movzbl	(%r10,%r14), %r14d
	movb	%r15b, 89(%rsp)
	subl	$2, %r15d
	movb	%r14b, 97(%rsp)
	cmpb	$1, %r15b
	ja	.L3643
	cmpb	$8, %r14b
	jne	.L3623
.L3643:
	movzbl	%cl, %r10d
	addq	%r14, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	cmpl	$6, %r11d
	je	.L3629
	movl	%eax, %r10d
	movq	%rdx, %rcx
	shrl	$28, %r10d
	shrq	$48, %rcx
	cmpl	$7, %r10d
	je	.L3747
	movl	%r10d, %r14d
	movl	%r10d, %r15d
	leaq	widths.0(%rip), %r10
	movb	%cl, 106(%rsp)
	shrl	$2, %r14d
	andl	$3, %r15d
	movzbl	(%r10,%r14), %r14d
	movb	%r15b, 90(%rsp)
	subl	$2, %r15d
	movb	%r14b, 98(%rsp)
	cmpb	$1, %r15b
	ja	.L3672
	cmpb	$8, %r14b
	jne	.L3623
.L3672:
	movzbl	%r14b, %r15d
.L3646:
	movzbl	%cl, %r10d
	addq	%r15, %r10
	cmpq	%r10, %rdi
	jb	.L3623
	testb	$8, %al
	je	.L3629
	shrq	$32, %rax
	shrq	$56, %rdx
	andl	$15, %eax
	cmpl	$7, %eax
	je	.L3648
	movl	%eax, %r10d
	leaq	widths.0(%rip), %rcx
	shrl	$2, %eax
	movb	%dl, 107(%rsp)
	andl	$3, %r10d
	movzbl	(%rcx,%rax), %eax
	movb	%r10b, 91(%rsp)
	subl	$2, %r10d
	movb	%al, 99(%rsp)
	cmpb	$1, %r10b
	ja	.L3659
	cmpb	$8, %al
	jne	.L3623
.L3659:
	addq	%rdx, %rax
	cmpq	%rax, %rdi
	jb	.L3623
.L3629:
	cmpq	$1, %r9
	jbe	.L3662
	leaq	112(%rsp), %r10
	leaq	(%r13,%r13), %rdi
	movq	%r10, %r9
	cmpq	$128, %rdi
	ja	.L3748
.L3653:
	xorl	%ecx, %ecx
	testq	%r12, %r12
	movq	%r9, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	setne	%cl
	cmpl	$1, %r11d
	jne	.L3654
	movzbl	84(%rsp), %eax
	subl	$3, %eax
	cmpb	$1, %al
	ja	.L3749
.L3654:
	leaq	80(%rsp), %rdx
	leaq	48(%rsp), %rdi
	movq	%r10, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r8, (%rsp)
	call	keyed_sort_entries
	movq	24(%rsp), %r10
	movq	16(%rsp), %r9
	movq	(%rsp), %r8
.L3655:
	movl	%eax, %edx
	andl	$1, %edx
	cmpq	%r10, %r9
	je	.L3652
	movq	%r9, %rdi
	movl	%eax, 24(%rsp)
	movb	%dl, 16(%rsp)
	movq	%r8, (%rsp)
	call	free@PLT
	movq	(%rsp), %r8
	movzbl	16(%rsp), %edx
	movl	24(%rsp), %eax
.L3652:
	testq	%r8, %r8
	je	.L3601
	testb	%dl, %dl
	je	.L3618
	movq	(%rbx), %rcx
	xorl	%eax, %eax
	cmpq	$0, (%rcx)
	jne	.L3616
	movq	(%r8), %rdx
	cmpq	%rdx, 8(%rcx)
	jb	.L3616
	testq	%rdx, %rdx
	jne	.L3750
.L3658:
	movq	%rdx, (%rcx)
	movl	$1, %eax
	movq	$0, (%r8)
	jmp	.L3616
	.p2align 4,,10
	.p2align 3
.L3740:
	movq	%rax, %xmm0
	movq	%rax, %r10
	punpcklqdq	%xmm0, %xmm0
	jmp	.L3621
	.p2align 4,,10
	.p2align 3
.L3617:
	xorl	%eax, %eax
	jmp	.L3601
	.p2align 4,,10
	.p2align 3
.L3607:
	cmpq	%rdi, %r10
	je	.L3602
	movq	24(%r10), %rdx
	jmp	.L3603
	.p2align 4,,10
	.p2align 3
.L3748:
	movq	%r10, 40(%rsp)
	movq	%rsi, 32(%rsp)
	movl	%r11d, 24(%rsp)
	movq	%r8, 16(%rsp)
	movaps	%xmm0, (%rsp)
	call	malloc@PLT
	movdqa	(%rsp), %xmm0
	movq	16(%rsp), %r8
	testq	%rax, %rax
	movl	24(%rsp), %r11d
	movq	32(%rsp), %rsi
	movq	%rax, %r9
	movq	40(%rsp), %r10
	jne	.L3653
	.p2align 4
	.p2align 3
.L3623:
	xorl	%eax, %eax
.L3618:
	testq	%r8, %r8
	je	.L3601
	jmp	.L3616
	.p2align 4,,10
	.p2align 3
.L3741:
	movb	$4, 84(%rsp)
	movl	$8, %r10d
	movb	$8, 92(%rsp)
	movb	%dl, 100(%rsp)
	jmp	.L3625
	.p2align 4,,10
	.p2align 3
.L3742:
	movb	$4, 85(%rsp)
	movl	$8, %ecx
	movb	$8, 93(%rsp)
	movb	%r10b, 101(%rsp)
	jmp	.L3631
	.p2align 4,,10
	.p2align 3
.L3749:
	leaq	80(%rsp), %rdx
	leaq	48(%rsp), %rdi
	movq	%r10, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r8, (%rsp)
	call	keyed_sort_words
	movq	(%rsp), %r8
	movq	16(%rsp), %r9
	movq	24(%rsp), %r10
	jmp	.L3655
	.p2align 4,,10
	.p2align 3
.L3743:
	movb	$4, 86(%rsp)
	movl	$8, %r14d
	movb	$8, 94(%rsp)
	movb	%cl, 102(%rsp)
	jmp	.L3634
	.p2align 4,,10
	.p2align 3
.L3662:
	movl	$1, %edx
	movl	$1, %eax
	jmp	.L3652
	.p2align 4,,10
	.p2align 3
.L3744:
	movb	$4, 87(%rsp)
	movl	$8, %r14d
	movb	$8, 95(%rsp)
	movb	%cl, 103(%rsp)
	jmp	.L3637
	.p2align 4,,10
	.p2align 3
.L3745:
	movb	$4, 88(%rsp)
	movl	$8, %r15d
	movb	$8, 96(%rsp)
	movb	%cl, 104(%rsp)
	jmp	.L3640
	.p2align 4,,10
	.p2align 3
.L3746:
	movb	$4, 89(%rsp)
	movl	$8, %r14d
	movb	$8, 97(%rsp)
	movb	%cl, 105(%rsp)
	jmp	.L3643
	.p2align 4,,10
	.p2align 3
.L3747:
	movb	$4, 90(%rsp)
	movl	$8, %r15d
	movb	$8, 98(%rsp)
	movb	%cl, 106(%rsp)
	jmp	.L3646
	.p2align 4,,10
	.p2align 3
.L3750:
	movq	24(%r8), %rax
	movq	32(%rcx), %rdi
	movq	%r8, (%rsp)
	movq	32(%r8), %rsi
	imulq	(%rax), %rdx
	call	memcpy@PLT
	movq	(%rsp), %r8
	movq	(%rbx), %rcx
	movq	(%r8), %rdx
	jmp	.L3658
	.p2align 4,,10
	.p2align 3
.L3648:
	movb	$4, 91(%rsp)
	movl	$8, %eax
	movb	$8, 99(%rsp)
	movb	%dl, 107(%rsp)
	jmp	.L3659
.L3738:
	call	__stack_chk_fail@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_sort_keyed.cold, @function
myl_rc_list_sort_keyed.cold:
.LFSB134:
.L3605:
	.cfi_def_cfa_offset 320
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	%rbp, %rdi
	movq	%rdx, %rsi
	movq	%r10, 16(%rsp)
	movq	%rdx, (%rsp)
	call	myl_rc_binding_find_slow@PLT
	movq	(%rbx), %rdi
	movq	16(%rsp), %r10
	testq	%rax, %rax
	je	.L3607
	movq	(%rsp), %rdx
	jmp	.L3606
	.cfi_endproc
.LFE134:
	.text
	.size	myl_rc_list_sort_keyed, .-myl_rc_list_sort_keyed
	.section	.text.unlikely
	.size	myl_rc_list_sort_keyed.cold, .-myl_rc_list_sort_keyed.cold
.LCOLDE24:
	.text
.LHOTE24:
	.section	.text.unlikely
.LCOLDB25:
	.text
.LHOTB25:
	.p2align 4
	.globl	myl_rc_list_abort_parts
	.type	myl_rc_list_abort_parts, @function
myl_rc_list_abort_parts:
.LFB135:
	.cfi_startproc
	endbr64
	pushq	%r14
	.cfi_def_cfa_offset 16
	.cfi_offset 14, -16
	pushq	%r13
	.cfi_def_cfa_offset 24
	.cfi_offset 13, -24
	pushq	%r12
	.cfi_def_cfa_offset 32
	.cfi_offset 12, -32
	pushq	%rbp
	.cfi_def_cfa_offset 40
	.cfi_offset 6, -40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	movq	24(%rsi), %rax
	cmpw	$1, 48(%rax)
	jne	.L3767
	movq	(%rsi), %rax
	movq	%rdi, %r14
	movq	%rsi, %r13
	testq	%rax, %rax
	je	.L3756
	movq	32(%rsi), %rbp
	movq	%rdx, %r12
	xorl	%ebx, %ebx
	jmp	.L3755
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L3754:
	addq	$1, %rbx
	cmpq	%rax, %rbx
	jnb	.L3756
.L3755:
	movq	0(%rbp,%rbx,8), %rsi
	testq	%rsi, %rsi
	je	.L3754
	cmpq	%r12, %rsi
	je	.L3754
	testb	$64, -9(%rsi)
	je	.L3754
	movq	%r14, %rdi
	addq	$1, %rbx
	call	myl_rc_native_abort@PLT
	movq	0(%r13), %rax
	cmpq	%rax, %rbx
	jb	.L3755
.L3756:
	popq	%rbx
	.cfi_def_cfa_offset 40
	movq	%r13, %rsi
	popq	%rbp
	.cfi_def_cfa_offset 32
	movq	%r14, %rdi
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r13
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	jmp	myl_rc_native_abort@PLT
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	myl_rc_list_abort_parts.cold, @function
myl_rc_list_abort_parts.cold:
.LFSB135:
.L3767:
	.cfi_def_cfa_offset 48
	.cfi_offset 3, -48
	.cfi_offset 6, -40
	.cfi_offset 12, -32
	.cfi_offset 13, -24
	.cfi_offset 14, -16
	call	abort@PLT
	.cfi_endproc
.LFE135:
	.text
	.size	myl_rc_list_abort_parts, .-myl_rc_list_abort_parts
	.section	.text.unlikely
	.size	myl_rc_list_abort_parts.cold, .-myl_rc_list_abort_parts.cold
.LCOLDE25:
	.text
.LHOTE25:
	.section	.rodata
	.type	widths.0, @object
	.size	widths.0, 4
widths.0:
	.base64	"CAQCAQ=="
	.section	.data.rel.ro.local,"aw"
	.align 32
	.type	rc_list_module, @object
	.size	rc_list_module, 40
rc_list_module:
	.long	5
	.zero	20
	.quad	rc_list_descriptors
	.quad	2
	.align 32
	.type	rc_list_descriptors, @object
	.size	rc_list_descriptors, 128
rc_list_descriptors:
	.quad	myl_native_list_header_descriptor
	.quad	rc_list_shape
	.quad	rc_list_edges
	.zero	8
	.quad	rc_list_clone_adapter
	.quad	rc_list_shell
	.quad	rc_list_next
	.quad	rc_list_span
	.quad	rc_storage_type
	.quad	rc_list_shape
	.quad	rc_storage_edges
	.zero	40
	.section	.rodata
	.align 32
	.type	rc_list_shape, @object
	.size	rc_list_shape, 40
rc_list_shape:
	.quad	72
	.long	0
	.zero	28
	.align 32
	.type	rc_storage_type, @object
	.size	rc_storage_type, 112
rc_storage_type:
	.quad	72
	.quad	8
	.zero	32
	.value	0
	.zero	2
	.long	3
	.zero	56
	.globl	myl_native_list_header_type
	.section	.data.rel.ro.local
	.align 8
	.type	myl_native_list_header_type, @object
	.size	myl_native_list_header_type, 8
myl_native_list_header_type:
	.quad	myl_native_list_header_descriptor
	.globl	myl_native_list_header_descriptor
	.align 32
	.type	myl_native_list_header_descriptor, @object
	.size	myl_native_list_header_descriptor, 112
myl_native_list_header_descriptor:
	.quad	72
	.quad	8
	.quad	list_fields
	.quad	1
	.zero	16
	.value	2
	.zero	2
	.long	2
	.zero	40
	.quad	list_scan
	.quad	1
	.section	.rodata
	.align 8
	.type	list_scan, @object
	.size	list_scan, 12
list_scan:
	.long	32
	.long	-1
	.zero	4
	.section	.data.rel.ro,"aw"
	.align 16
	.type	list_fields, @object
	.size	list_fields, 24
list_fields:
	.quad	32
	.quad	myl_rc_pointer_leaf
	.zero	8
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC0:
	.quad	0
	.quad	1
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
