#define _GNU_SOURCE
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/user.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
static uint64_t peek(pid_t pid,uint64_t address) {
 errno=0; long value=ptrace(PTRACE_PEEKDATA,pid,(void *)(uintptr_t)address,0);
 if(errno){fprintf(stderr,"peek %lx: %s\n",(unsigned long)address,strerror(errno));exit(2);}return (uint64_t)value;
}
static void poke(pid_t pid,uint64_t address,uint64_t value) {
 if(ptrace(PTRACE_POKEDATA,pid,(void *)(uintptr_t)address,(void *)(uintptr_t)value)<0){perror("poke");exit(2);}
}
static void continued(pid_t pid,int request){if(ptrace(request,pid,0,0)<0){perror("continue");exit(2);}}
int main(int argc,char **argv){
 if(argc!=4&&argc!=5){fprintf(stderr,"snapshot binary count json\n");return 2;}
 unsigned limit=(unsigned)strtoul(argv[2],0,10);FILE *out=fopen(argv[3],"w");if(!out){perror("fopen");return 2;}
 pid_t pid=fork();if(pid<0){perror("fork");return 2;}
 if(!pid){if(ptrace(PTRACE_TRACEME,0,0,0)<0){perror("traceme");_exit(2);}execl(argv[1],argv[1],NULL);perror("exec");_exit(2);}
 int status;if(waitpid(pid,&status,0)!=pid||!WIFSTOPPED(status)){fprintf(stderr,"initial stop missing\n");return 2;}
 /* This exact source5535 ET_EXEC symbol is pinned by the caller's ELF receipt. */
 int gated=argc==5;uint64_t address=gated?UINT64_C(0x102e760):UINT64_C(0x1032a70);uint64_t original=peek(pid,address);poke(pid,address,(original&~UINT64_C(0xff))|0xcc);
 fprintf(out,"{\"binary\":\"%s\",\"entry\":\"0x%lx\",\"samples\":[",argv[1],(unsigned long)address);
 unsigned samples=0;continued(pid,PTRACE_CONT);
 for(;;){
  if(waitpid(pid,&status,0)!=pid){perror("waitpid");return 2;}
  if(WIFEXITED(status)){fprintf(out,"],\"samples_count\":%u,\"exit_status\":%d}\n",samples,WEXITSTATUS(status));fclose(out);return WEXITSTATUS(status);}
  if(WIFSIGNALED(status)){fprintf(stderr,"child signal %d\n",WTERMSIG(status));return 2;}
  if(!WIFSTOPPED(status)){fprintf(stderr,"unknown child status\n");return 2;}
  struct user_regs_struct regs;if(ptrace(PTRACE_GETREGS,pid,0,&regs)<0){perror("getregs");return 2;}
  if(WSTOPSIG(status)!=SIGTRAP||regs.rip!=address+1){fprintf(stderr,"unexpected stop rip=%llx signal=%d\n",(unsigned long long)regs.rip,WSTOPSIG(status));return 2;}
  if(gated){
   poke(pid,address,original);regs.rip=address;if(ptrace(PTRACE_SETREGS,pid,0,&regs)<0){perror("gate setregs");return 2;}
   address=UINT64_C(0x1032a70);original=peek(pid,address);poke(pid,address,(original&~UINT64_C(0xff))|0xcc);gated=0;continued(pid,PTRACE_CONT);continue;
  }
  uint64_t rc=peek(pid,regs.rdi+0x1608);uint64_t entries=peek(pid,rc+0x58),mask=peek(pid,rc+0x60),count=peek(pid,rc+0x68);unsigned shift=(unsigned)(peek(pid,rc+0x70)&0xffffffffu);
  if(shift>63||mask>UINT64_C(0x100000)){fprintf(stderr,"invalid map extent\n");return 2;}
  uint64_t key=regs.rsi,home=((key*UINT64_C(0x9e3779b97f4a7c15))>>shift)&mask,slot=home;unsigned misses=0;
  for(;;){uint64_t found=peek(pid,entries+16*slot);if(found==key)break;if(!found||misses>mask){fprintf(stderr,"lookup refused unexpected key\n");return 2;}++misses;slot=(slot+1)&mask;}
  fprintf(out,"%s{\"call\":%u,\"key\":\"0x%lx\",\"entries\":\"0x%lx\",\"mask\":%lu,\"count\":%lu,\"shift\":%u,\"home\":%lu,\"slot\":%lu,\"occupied_misses\":%u}",samples?",":"",samples,(unsigned long)key,(unsigned long)entries,(unsigned long)mask,(unsigned long)count,shift,(unsigned long)home,(unsigned long)slot,misses);++samples;
  poke(pid,address,original);regs.rip=address;if(ptrace(PTRACE_SETREGS,pid,0,&regs)<0){perror("setregs");return 2;}
  if(samples==limit){continued(pid,PTRACE_CONT);continue;}
  continued(pid,PTRACE_SINGLESTEP);if(waitpid(pid,&status,0)!=pid||!WIFSTOPPED(status)||WSTOPSIG(status)!=SIGTRAP){fprintf(stderr,"step failed\n");return 2;}
  poke(pid,address,(original&~UINT64_C(0xff))|0xcc);continued(pid,PTRACE_CONT);
 }
}
