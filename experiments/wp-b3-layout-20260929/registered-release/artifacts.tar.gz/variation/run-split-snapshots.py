import hashlib,json,subprocess
from pathlib import Path
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary=W/'text_ops.symbols';before=h(binary);rows=[]
for trial in range(6):
 out=W/f'split-snapshot-{trial}.json';command=[str(W/'snapshot'),str(binary),'100',str(out),'split']
 p=subprocess.run(command,cwd=ROOT,capture_output=True)
 (W/f'split-snapshot-{trial}.stdout').write_bytes(p.stdout);(W/f'split-snapshot-{trial}.stderr').write_bytes(p.stderr)
 assert p.returncode==0,(trial,p.stderr.decode(errors='replace'))
 data=json.loads(out.read_text());assert data['samples_count']==100 and data['exit_status']==0
 if rows:assert p.stdout==(W/'split-snapshot-0.stdout').read_bytes()
 groups={}
 for sample in data['samples']:
  g=groups.setdefault(sample['key'],{'calls':0,'misses':set(),'mask':sample['mask'],'shift':sample['shift']});g['calls']+=1;g['misses'].add(sample['occupied_misses'])
 for g in groups.values():g['misses']=sorted(g['misses'])
 rows.append(dict(trial=trial,command=command,status=p.returncode,keys=groups,stdout_sha256=h(W/f'split-snapshot-{trial}.stdout')))
 print(trial,groups,flush=True)
assert h(binary)==before
(W/'split-snapshots-receipt.json').write_text(json.dumps(dict(binary_sha256=before,source_git=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),trials=rows,breakpoint='after first text_split entry0x102e760, edge entry0x1032a70; original instruction restored and execution resumed after100samples. Files/source unchanged.',timings_collected=False,passed=True),indent=2)+'\n')
