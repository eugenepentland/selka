from pathlib import Path
import json,os,subprocess,hashlib
root=Path.cwd();work=root/'.tmp-module';compiler=root/'zig-out/bin/mylang';runs=[]
for backend in ('qbe','llvm'):
 for mode in ('gc','rc'):
  cmd=[str(root/'scripts/build-slot.sh'),'build',str(compiler),'test','tests/lang/rc_plain_replacements.my','--force','--json','--gc-stress' if mode=='gc' else '--rc-runtime=stats']
  if backend=='llvm':cmd.append('--release')
  run=subprocess.run(cmd,text=True,capture_output=True,env=dict(os.environ,TMPDIR=str(work/'tmp'),ZIG_LOCAL_CACHE_DIR=str(root/'.zig-cache-module')))
  record={'backend':backend,'mode':mode,'command':cmd,'status':run.returncode,'stdout':run.stdout,'stderr':run.stderr};runs.append(record)
  (work/'validation.json').write_text(json.dumps({'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'runs':runs},indent=2)+'\n')
  assert run.returncode==0,record
  result=json.loads(run.stdout);assert result['passed']==result['executed']==3 and all(result.get(k,0)==0 for k in ('failed','dropped','unloaded','cached','skipped')),result
  print(backend,mode,'3/3',flush=True)
