from pathlib import Path
import shutil
import subprocess
root=Path.cwd();stage=root/'.tmp/p1-share-stage'
p=root/'src/core/runtime/core_rt.c';s=p.read_text();draft=(stage/'core_rt.c').read_text()
walk=draft[draft.index('/* SHARED-COUNTS-2:'):draft.index('/* Drop one owner')]
a=s.index('static void core_dict_free_pending');b=s.index('/* Drop one owner')
s=s[:a]+walk+s[b:]
needle='/* CAS keeps immortality sticky even if a retain saturates while a release is'
fix='''/* A plain aggregate becoming immortal must first mark its descendants:
   later publication stops at an immortal root, just as at a shared root. */
void myl_core_share(myl_block *root);
__attribute__((cold, noinline, preserve_most)) static void count_saturate_plain(myl_block *block) {
    myl_core_share(block);
    block->count = MYL_SATURATED;
}

'''
assert s.count(needle)==1;s=s.replace(needle,fix+needle)
needle='    if (count < MYL_SHARED) {\n        block->count = MYL_SATURATED;\n        return;\n    }'
assert s.count(needle)==1;s=s.replace(needle,'    if (count < MYL_SHARED) {\n        count_saturate_plain(block);\n        return;\n    }')
p.write_text(s)
subprocess.run(['git', 'apply', str(stage/'children.patch')], cwd=root, check=True)
p=root/'src/core/count_runtime.zig';s=p.read_text();anchor='    .{ .anchor = "    memcpy(other->hashes, meta->hashes, (size_t)meta->elen * 8);\\n",'
pos=s.index(anchor)
s=s[:pos]+'''    .{
        .anchor = "    child->count = count | MYL_SHARED;\\n",
        .after = "    uint32_t myl_share_class = class_of(child);\\n    myl_count_event(MYL_COUNT_SHARE_MARKS, myl_share_class ? (size_t)myl_share_class * MYL_GRANULE : malloc_usable_size(child));\\n",
    },
'''+s[pos:];p.write_text(s)
p=root/'src/core/shared_counts_test.zig';s=p.read_text().replace('"count_load", "myl_core_retain_slow",','"count_load", "count_saturate_plain", "core_share_child", "myl_core_retain_slow",');p.write_text(s)
p=root/'SPEC.md';s=p.read_text();pos=s.index('- [SHARED-COUNTS-1]')
s=s[:pos]+'''- [SHARED-COUNTS-2] Publication marks every reachable plain managed block shared with an iterative walk before enqueueing a task; shared and immortal roots stop traversal. One child iterator serves publication and destruction, preserving alias multiplicity, union guards, dictionary tombstones, view owners and provider pairs. Plain saturation first shares its descendant graph before becoming permanently immortal, so later publication may safely stop at that root. Counting builds report each newly marked block and its allocated bytes; repeated publication adds neither marks nor owners.
'''+s[pos:];p.write_text(s)
shutil.copy2(stage/'share_fixture.c',root/'src/core/share_walk_fixture.c')

shutil.copy2(root/'.tmp/p1-task-stage/native_fixture.zig',root/'src/core/native_fixture.zig')
shutil.copy2(stage/'share_walk_test.zig',root/'src/core/share_walk_test.zig')
p=root/'src/core/root_test.zig';s=p.read_text().replace('comptime {','comptime {\n    _ = @import("share_walk_test.zig");',1);p.write_text(s)
