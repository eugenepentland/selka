const std = @import("std");
const counting = @import("src/core/count_runtime.zig");
pub fn main(init: std.process.Init) !void {
    const text = try counting.source(init.arena.allocator(), @embedFile("runtime.c"));
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = ".tmp/p1-thread-stage/counted.c", .data = text });
}
