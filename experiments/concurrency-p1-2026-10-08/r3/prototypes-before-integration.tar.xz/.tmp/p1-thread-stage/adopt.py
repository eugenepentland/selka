from pathlib import Path
import shutil
import subprocess
root=Path.cwd();stage=root/'.tmp/p1-thread-stage/src/core'
subprocess.run(['git', 'apply', '--check', str(root/'.tmp/p1-thread-stage/changes.patch')], cwd=root, check=True)
subprocess.run(['git', 'apply', str(root/'.tmp/p1-thread-stage/changes.patch')], cwd=root, check=True)
p=root/'src/core/driver.zig';s=p.read_text()
needle='    try argv.appendSlice(allocator, &.{ "-Wno-override-module", "-o", linked });'
assert s.count(needle)==1;s=s.replace(needle,'    try argv.append(allocator, "-pthread");\n'+needle)
needle='    try argv.appendSlice(allocator, &.{ "-std=c11", "-o", partial, source });'
assert s.count(needle)==1;s=s.replace(needle,'    try argv.appendSlice(allocator, &.{ "-std=c11", "-pthread", "-o", partial, source });')
p.write_text(s)
p=root/'src/core/root_test.zig';s=p.read_text().replace('comptime {','comptime {\n    _ = @import("runtime_threads_test.zig");',1);p.write_text(s)
p=root/'SPEC.md';s=p.read_text().replace('with an acquire fence before final destruction','with an acquire on the last-owner CAS before final destruction')
tag='- [RUNTIME-THREADS-1] The native allocator, error traces, IO sites, worker stack metadata and counting slots are thread-local. A persistent allocator registry preserves retired-thread free lists; leak, text-walk and counter reports aggregate only after quiescence. Shared heap/live-byte accounting is atomic. After workers start, complete print/write/debug units (including dynamic print options and units above 64 KiB) stage in TLS and append under one stream mutex; before workers start the ordinary buffered path remains. Full provider operations and handle changes serialize under a separate IO mutex. Fatal reporting has one winner, a bounded stream-lock attempt with raw-fd fallback, and skips provider/Host cleanup after workers start. Task reports use captured guest PCs, with `<unknown>` when unavailable. Each worker installs its own alternate signal stack and stack bounds and blocks SIGALRM.\n'
pos=s.index('- [SHARED-COUNTS-1]');s=s[:pos]+tag+s[pos:];p.write_text(s)
