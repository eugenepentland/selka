from pathlib import Path
root=Path(__file__).parent/'src/core'
p=root/'runtime/core_count.c';s=p.read_text()
s=s.replace('Single-threaded, like the counts themselves.', 'Thread-local slots are combined after task quiescence.')
s=s.replace('myl_count_fn *myl_count_current;', 'MYL_TLS myl_count_fn *myl_count_current;').replace('myl_count_site *myl_count_copy_site;', 'MYL_TLS myl_count_site *myl_count_copy_site;').replace('myl_count_site *myl_count_push_site;', 'MYL_TLS myl_count_site *myl_count_push_site;')
s=s.replace('static uint64_t myl_count_live, myl_count_peak;', 'static _Atomic uint64_t myl_count_live, myl_count_peak;')
pos=s.index('/* Site kinds,')
s=s[:pos]+'''/* Linker records are immutable identities; each native thread owns copies of
   their slots. Records survive thread retirement for the one quiescent dump. */
typedef struct myl_count_thread {
    myl_count_fn *functions;
    myl_count_site *sites;
    myl_count_fn outside;
    struct myl_count_thread *next;
} myl_count_thread;
static pthread_mutex_t myl_count_mutex = PTHREAD_MUTEX_INITIALIZER;
static myl_count_thread *myl_count_threads;
static MYL_TLS myl_count_thread *myl_count_local;

static size_t myl_count_functions_size(void) {
    return __start_myl_count_fns ? (size_t)(__stop_myl_count_fns - __start_myl_count_fns) : 0;
}
static size_t myl_count_sites_size(void) {
    return __start_myl_count_sites ? (size_t)(__stop_myl_count_sites - __start_myl_count_sites) : 0;
}
static myl_count_thread *myl_count_thread_get(void) {
    if (myl_count_local) return myl_count_local;
    myl_count_thread *local = calloc(1, sizeof *local);
    if (!local) out_of_memory();
    size_t functions = myl_count_functions_size(), sites = myl_count_sites_size();
    local->functions = calloc(functions ? functions : 1, sizeof *local->functions);
    local->sites = calloc(sites ? sites : 1, sizeof *local->sites);
    if (!local->functions || !local->sites) out_of_memory();
    if (functions) memcpy(local->functions, __start_myl_count_fns, functions * sizeof *local->functions);
    if (sites) memcpy(local->sites, __start_myl_count_sites, sites * sizeof *local->sites);
    local->outside.name = "<outside>";
    pthread_mutex_lock(&myl_count_mutex);
    local->next = myl_count_threads;
    myl_count_threads = local;
    pthread_mutex_unlock(&myl_count_mutex);
    myl_count_local = local;
    return local;
}

myl_count_fn *myl_count_function_local(const myl_count_fn *identity) {
    return &myl_count_thread_get()->functions[identity - __start_myl_count_fns];
}
myl_count_site *myl_count_site_local(const myl_count_site *identity) {
    return &myl_count_thread_get()->sites[identity - __start_myl_count_sites];
}

static void myl_count_add_live(size_t bytes) {
    uint64_t live = atomic_fetch_add_explicit(&myl_count_live, bytes, memory_order_relaxed) + bytes;
    uint64_t peak = atomic_load_explicit(&myl_count_peak, memory_order_relaxed);
    while (peak < live && !atomic_compare_exchange_weak_explicit(&myl_count_peak, &peak, live,
            memory_order_relaxed, memory_order_relaxed)) {}
}
static void myl_count_sub_live(size_t bytes) {
    uint64_t live = atomic_load_explicit(&myl_count_live, memory_order_relaxed);
    while (!atomic_compare_exchange_weak_explicit(&myl_count_live, &live, live - (bytes < live ? bytes : live),
            memory_order_relaxed, memory_order_relaxed)) {}
}

'''+s[pos:]
s=s.replace('return myl_count_current ? myl_count_current : &myl_count_outside;', 'return myl_count_current ? myl_count_current : &myl_count_thread_get()->outside;')
s=s.replace('myl_count_site *site = myl_count_copy_site;', 'myl_count_site *site = myl_count_copy_site ? myl_count_site_local(myl_count_copy_site) : NULL;')
s=s.replace('myl_count_push_site->c[2]', 'myl_count_site_local(myl_count_push_site)->c[2]')
s=s.replace('    myl_count_live += bytes;\n    if (myl_count_live > myl_count_peak) myl_count_peak = myl_count_live;', '    myl_count_add_live(bytes);')
s=s.replace('    myl_count_live -= bytes < myl_count_live ? bytes : myl_count_live;', '    myl_count_sub_live(bytes);')
s=s.replace('    myl_count_live += after;\n    myl_count_live -= before < myl_count_live ? before : myl_count_live;\n    if (myl_count_live > myl_count_peak) myl_count_peak = myl_count_live;', '    if (after >= before) myl_count_add_live(after - before);\n    else myl_count_sub_live(before - after);')
pos=s.index('/* Write every counter once:')
s=s[:pos]+'''/* No thread mutates a slot after the scheduler's quiescence barrier. Copy the
   immutable metadata, then sum the private slots into report-owned storage. */
static bool myl_count_aggregate(myl_count_fn **functions, myl_count_site **sites) {
    size_t nf = myl_count_functions_size(), ns = myl_count_sites_size();
    *functions = calloc(nf ? nf : 1, sizeof **functions);
    *sites = calloc(ns ? ns : 1, sizeof **sites);
    if (!*functions || !*sites) { free(*functions); free(*sites); return false; }
    if (nf) memcpy(*functions, __start_myl_count_fns, nf * sizeof **functions);
    if (ns) memcpy(*sites, __start_myl_count_sites, ns * sizeof **sites);
    pthread_mutex_lock(&myl_count_mutex);
    for (myl_count_thread *thread = myl_count_threads; thread; thread = thread->next) {
        for (size_t f = 0; f < nf; ++f)
            for (int c = 0; c < MYL_COUNT_SLOTS; ++c) (*functions)[f].c[c] += thread->functions[f].c[c];
        for (size_t site = 0; site < ns; ++site)
            for (int c = 0; c < 4; ++c) (*sites)[site].c[c] += thread->sites[site].c[c];
        for (int c = 0; c < MYL_COUNT_SLOTS; ++c) myl_count_outside.c[c] += thread->outside.c[c];
    }
    pthread_mutex_unlock(&myl_count_mutex);
    return true;
}

'''+s[pos:]
s=s.replace('    const myl_count_fn *fns = __start_myl_count_fns, *fns_end = __stop_myl_count_fns;\n    const myl_count_site *sites = __start_myl_count_sites, *sites_end = __stop_myl_count_sites;', '''    myl_count_fn *fns;
    myl_count_site *sites;
    if (!myl_count_aggregate(&fns, &sites)) { fclose(file); return; }
    const myl_count_fn *fns_end = fns + myl_count_functions_size();
    const myl_count_site *sites_end = sites + myl_count_sites_size();''')
# Final close is the one successful report path; the early aggregate failure
# frees its own partial storage before returning.
pos=s.rindex('    if (fclose(file)');s=s[:pos]+'    free(fns);\n    free(sites);\n'+s[pos:]
p.write_text(s)
p=root/'emit_count.zig';s=p.read_text()
for name in ('myl_count_current','myl_count_copy_site','myl_count_push_site'):
 s=s.replace('@'+name+' = external global ptr', '@'+name+' = external thread_local(initialexec) global ptr')
s=s.replace('    \\\\@myl_count_current = ', '    \\\\declare ptr @myl_count_function_local(ptr) nounwind\n    \\\\declare ptr @myl_count_site_local(ptr) nounwind\n    \\\\@myl_count_current = ',1)
a=s.index('    const at = "ptr getelementptr',s.index('pub fn increment('));b=s.index('\n}\n',a)
s=s[:a]+'''    const record = if (std.mem.startsWith(u8, step.record, "%")) step.record else local: {
        const name = try std.fmt.allocPrint(a, "{s}.record", .{step.loaded});
        try out.print(a, "  {s} = call ptr @myl_count_{s}_local(ptr {s})\\n", .{ name, if (step.offset == function_calls) "function" else "site", step.record });
        break :local name;
    };
    try out.print(a, "  {s}.at = getelementptr inbounds i8, ptr {s}, i64 {d}\\n", .{ step.loaded, record, step.offset });
    try out.print(a, "  {s} = load i64, ptr {s}.at, align 8\\n  {s} = add i64 {s}, {s}\\n  store i64 {s}, ptr {s}.at, align 8\\n", .{
        step.loaded, step.loaded, step.sum, step.loaded, step.amount, step.sum, step.loaded,
    });'''+s[b:]
a=s.index('pub fn prologue(');b=s.index('\n}\n',a)
start=s.index('    try out.print',a)
s=s[:start]+'''    try out.print(a, "  %myl.cnt.saved = load ptr, ptr @myl_count_current, align 8\\n  %myl.cnt.active = call ptr @myl_count_function_local(ptr @myl.cf.{d})\\n  store ptr %myl.cnt.active, ptr @myl_count_current, align 8\\n", .{record});
    try increment(a, out, .{ .record = "%myl.cnt.active", .offset = function_calls, .amount = "1", .loaded = "%myl.cnt.calls", .sum = "%myl.cnt.calls.1" });'''+s[b:]
p.write_text(s)
