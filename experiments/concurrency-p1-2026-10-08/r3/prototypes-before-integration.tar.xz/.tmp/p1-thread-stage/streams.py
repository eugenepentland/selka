from pathlib import Path
p=Path(__file__).parent/'src/core/runtime/core_rt.c';s=p.read_text()
s=s.replace('static _Atomic bool core_pool_started;', '''static _Atomic bool core_pool_started;
static _Atomic uint32_t core_fatal_winner;
static MYL_TLS bool core_fatal_owner, core_fatal_raw;
static pthread_mutex_t core_stream_mutex = PTHREAD_MUTEX_INITIALIZER;
typedef struct { uintptr_t submit, group; int64_t item; } core_task_context;
static MYL_TLS core_task_context core_running_task;''')
s=s.replace('static void os_exit(int status) { core_io_cleanup(); _exit(status); }', '''static void core_fatal_begin(void);
static void core_task_report(void);
static void os_exit(int status) { if (core_parallel()) { core_fatal_begin(); core_task_report(); _exit(status ? 1 : 0); } core_io_cleanup(); _exit(status); }''')
a=s.index('static void stream_flush(myl_stream *stream) {');b=s.index('static void out_of_memory(void) {',a)
s=s[:a]+'''/* A complete print/write is staged privately, including units larger than the
   ordinary 64 KiB stream buffer. The stream lock covers the complete append. */
typedef struct { unsigned char *bytes; size_t used, capacity; } core_stage;
static MYL_TLS core_stage core_staging[2];

static void core_fatal_begin(void) {
    if (!core_parallel() || core_fatal_owner) return;
    uint32_t expected = 0;
    if (!atomic_compare_exchange_strong_explicit(&core_fatal_winner, &expected, 1,
            memory_order_acq_rel, memory_order_relaxed)) {
        for (;;) (void)syscall(SYS_futex, &core_fatal_winner, FUTEX_WAIT_PRIVATE, 1, NULL, NULL, 0);
    }
    core_fatal_owner = true;
    /* Never wait for a thread stopped inside a stream write, especially when
       this is a synchronous signal on the lock's own thread. */
    for (unsigned attempt = 0; attempt < 1024; ++attempt) {
        if (!pthread_mutex_trylock(&core_stream_mutex)) return;
    }
    core_fatal_raw = true;
}

static void stream_flush_unlocked(myl_stream *stream) {
    size_t used = stream->used;
    stream->used = 0;
    if (!os_write(stream == &streams[1] ? 2 : 1, stream->bytes, used) && stream == &streams[0]) output_refused();
}

static void stream_write_unlocked(myl_stream *stream, const void *data, size_t len) {
    const unsigned char *bytes = data;
    while (len > 0) {
        if (stream->used == sizeof stream->bytes) stream_flush_unlocked(stream);
        size_t room = sizeof stream->bytes - stream->used;
        size_t take = len < room ? len : room;
        memcpy(stream->bytes + stream->used, bytes, take);
        stream->used += take;
        bytes += take;
        len -= take;
    }
}

static void stream_commit(myl_stream *stream) {
    if (!core_parallel() || core_fatal_owner) return;
    core_stage *stage = &core_staging[stream == &streams[1]];
    if (!stage->used) return;
    pthread_mutex_lock(&core_stream_mutex);
    stream_write_unlocked(stream, stage->bytes, stage->used);
    stage->used = 0;
    if (stream == &streams[1]) stream_flush_unlocked(stream);
    pthread_mutex_unlock(&core_stream_mutex);
}

static void stream_flush(myl_stream *stream) {
    if (core_fatal_raw) return;
    if (!core_parallel() || core_fatal_owner) { stream_flush_unlocked(stream); return; }
    stream_commit(stream);
    pthread_mutex_lock(&core_stream_mutex);
    stream_flush_unlocked(stream);
    pthread_mutex_unlock(&core_stream_mutex);
}

static void output_refused(void) {
    core_fatal_begin();
    static const char text[] = "error[R_OUTPUT]: native execution failed\\nstandard output refused a write\\n";
    stream_flush(&streams[1]);
    os_write(2, (const unsigned char *)text, sizeof text - 1);
    os_exit(1);
}

static void stream_write(myl_stream *stream, const void *data, size_t len) {
    if (core_fatal_raw) { os_write(2, data, len); return; }
    if (!core_parallel() || core_fatal_owner) { stream_write_unlocked(stream, data, len); return; }
    core_stage *stage = &core_staging[stream == &streams[1]];
    if (len > SIZE_MAX - stage->used) out_of_memory();
    size_t need = stage->used + len;
    if (need > stage->capacity) {
        size_t capacity = stage->capacity ? stage->capacity : 256;
        while (capacity < need && capacity <= SIZE_MAX / 2) capacity *= 2;
        if (capacity < need) capacity = need;
        unsigned char *grown = realloc(stage->bytes, capacity);
        if (!grown) out_of_memory();
        stage->bytes = grown;
        stage->capacity = capacity;
    }
    if (len) memcpy(stage->bytes + stage->used, data, len);
    stage->used += len;
}

static void flush_all(void) {
    stream_flush(&streams[0]);
    stream_flush(&streams[1]);
}

'''+s[b:]
s=s.replace('static void out_of_memory(void) {\n    flush_all();', 'static void out_of_memory(void) {\n    core_fatal_begin();\n    flush_all();')
s=s.replace('    if (fd == 2) stream_flush(stream_for(fd));', '    stream_commit(stream_for(fd));\n    if (fd == 2) stream_flush(stream_for(fd));',1)
s=s.replace('void myl_core_trap(const myl_core_site *site, int64_t a, int64_t b) {', 'void myl_core_trap(const myl_core_site *site, int64_t a, int64_t b) {\n    core_fatal_begin();')
s=s.replace('static void core_io_failure(const char *code){', 'static void core_io_failure(const char *code){\n    core_fatal_begin();')
s=s.replace('void myl_core_assert_fail(const myl_core_site *site) {','void myl_core_assert_fail(const myl_core_site *site) {\n    core_fatal_begin();')
# Only the fatal winner may initialize/read the DWARF scratch. Raw mode avoids the
# unwinder after failure to acquire the output lock, and still names the task.
s=s.replace('static int os_stack(void **pcs, int capacity) { return backtrace(pcs, capacity); }', 'static int os_stack(void **pcs, int capacity) { return core_fatal_raw ? 0 : backtrace(pcs, capacity); }')
pos=s.index('/* The old core\'s description of a budget\'s trap')
s=s[:pos]+'''/* R5: sites are the caller PCs captured by group_open and task_submit.
   Raw fallback requires no allocation or shared report scratch. */
static void core_task_report(void) {
    if (!core_running_task.submit) return;
    char text[192];
    int length = snprintf(text, sizeof text, "task submitted at 0x%llx (item %lld), group opened at 0x%llx\\n",
        (unsigned long long)core_running_task.submit, (long long)core_running_task.item,
        (unsigned long long)core_running_task.group);
    os_write(2, (const unsigned char *)text, (size_t)length);
    if (core_fatal_raw) return;
    trap_capture = NULL;
    trap_lines_left = 2;
    (void)dwarf_frames(core_running_task.submit - 1, 0);
    if (core_running_task.group) (void)dwarf_frames(core_running_task.group - 1, 0);
    stream_flush(&streams[1]);
}

'''+s[pos:]
p.write_text(s)
p=Path(__file__).parent/'src/core/runtime/core_io.c';s=p.read_text()
for name in ('write','write_bytes','write_buffer'):
 # Each helper is one output unit; print itself commits at print_end.
 import re
 pattern=r'(void myl_core_stream_'+name+r'\([^\n]+\)\{myl_core_print_str\(fd,\w+\);)(\})'
 s,n=re.subn(pattern,r'\1stream_commit(stream_for(fd));\2',s)
 assert n==1,(name,n)
p.write_text(s)
p=Path(__file__).parent/'src/core/count_runtime.zig';s=p.read_text().replace('.after = "myl_count_dump(); "', '.after = "if (!core_parallel()) myl_count_dump(); "');p.write_text(s)
