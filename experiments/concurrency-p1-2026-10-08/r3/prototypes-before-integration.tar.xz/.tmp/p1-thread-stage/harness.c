#include "runtime.c"
#undef NDEBUG
#include <assert.h>
static pthread_barrier_t gate;
static myl_block *transferred[8];
static myl_block *clock_cap;
static const myl_core_site locations[8];
static void *thread_body(void *input) {
    intptr_t id = (intptr_t)input;
    core_worker_runtime_start();
    sigset_t mask;
    assert(!pthread_sigmask(SIG_SETMASK, NULL, &mask));
    assert(sigismember(&mask, SIGALRM) == 1);
    stack_t alternate;
    assert(!sigaltstack(NULL, &alternate));
    assert(!(alternate.ss_flags & SS_DISABLE));
    assert(core_stack_top && core_stack_bytes);
    error_trace.origin = &locations[id];
    core_io_site = &locations[id];
    transferred[id] = myl_core_list_new_slow(10, 8);
    core_text_walked += (uint64_t)id + 1;
    for (int i = 0; i < 1000; ++i) assert(!myl_core_clock_advance(clock_cap, 1));
    pthread_barrier_wait(&gate);
    assert(error_trace.origin == &locations[id]);
    assert(core_io_site == &locations[id]);
    myl_core_release(transferred[(id + 1) % 8]);
    myl_block *text = block_new(MYL_KIND_STR, 70000, 1);
    memset(block_data(text), 'a' + (int)id, 70000);
    text->len = 70000;
    for (int i = 0; i < 2; ++i) {
        myl_core_print_str(1, text);
        myl_core_print_end(1);
    }
    myl_core_release(text);
    return NULL;
}
int main(void) {
    myl_core_start();
    core_io_initialize();
    (void)core_ascii_char(0);
    core_thread_register();
    clock_cap = myl_core_stand_in(0, 0);
    atomic_store_explicit(&core_pool_started, true, memory_order_release);
    assert(!pthread_barrier_init(&gate, NULL, 8));
    pthread_t threads[8];
    for (intptr_t id = 0; id < 8; ++id) assert(!pthread_create(&threads[id], NULL, thread_body, (void *)id));
    for (int id = 0; id < 8; ++id) assert(!pthread_join(threads[id], NULL));
    assert(core_io_state(clock_cap)->value == 8000);
    myl_core_release(clock_cap);
    assert(core_thread_walk_total() == 36);
    assert(live_count() == 0);
    flush_all();
    return 0;
}
