#!/usr/bin/env python3
"""P1-2 TLS model comparison, run only after the committed implementation is green."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

root = Path.cwd()
area = root / 'experiments/concurrency-p1-2026-10-08'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
env = dict(os.environ, TMPDIR=str(root / '.tmp'), ZIG_GLOBAL_CACHE_DIR='/home/epentland/ai/canopy/.zig-global-cache')
identity = {'source': source, 'models': {}}
for model, llvm, native in [('IE', 'initialexec', 'initial-exec'), ('LE', 'localexec', 'local-exec')]:
    archive = root / f'.tmp/p1-tls-{model}-src'
    archive.mkdir(exist_ok=False)
    saved = root / '.tmp/p1-tls-source.tar'
    with saved.open('wb') as output:
        subprocess.run(['git', 'archive', 'HEAD'], stdout=output, check=True)
    with tarfile.open(saved) as contents:
        contents.extractall(archive, filter='data')
    for name in ['src/core/emit_llvm.zig', 'src/core/emit_count.zig']:
        path = archive / name
        text = path.read_text()
        assert 'thread_local(initialexec)' in text
        path.write_text(text.replace('thread_local(initialexec)', f'thread_local({llvm})'))
    runtime = archive / 'src/core/runtime/core_rt.c'
    text = runtime.read_text()
    assert 'tls_model("initial-exec")' in text
    runtime.write_text(text.replace('tls_model("initial-exec")', f'tls_model("{native}")'))
    prefix = Path('/home/epentland/.cache/mylang') / f'conc-p1-tls-{model}-{source[:9]}'
    log = area / f'r3/logs/tls-{model}-compiler.log'
    started = time.monotonic()
    with log.open('w') as output:
        subprocess.run([str(root / 'scripts/build-slot.sh'), 'build', 'zig', 'build', '-Doptimize=ReleaseFast', '--prefix', str(prefix), '--summary', 'all'], cwd=archive, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
    compiler = prefix / 'bin/mylang'
    identity['models'][model] = {'compiler': str(compiler), 'sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(), 'seconds': time.monotonic() - started}
    (area / 'r3/results/tls-identities.json').write_text(json.dumps(identity, indent=2) + '\n')
    subprocess.run(['python3', str(area / 'tools/tax_layout.py'), 'build', '--compiler', str(compiler), '--tag', model], env=env, check=True)
subprocess.run(['python3', str(area / 'tools/tax_layout.py'), 'measure', '--tags', 'base,IE,LE', '--output', str(area / 'r3/results/tls-rows.json')], env=env, check=True)
