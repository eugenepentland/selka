from pathlib import Path
import re
p=Path(__file__).parent/'src/core/runtime/core_io.c';s=p.read_text()
header='''/* RUNTIME-THREADS-1: serialize complete capability/provider operations, including
   callbacks into a shared embedding provider and the handle/scratch registries.
   Nesting occurs through convenience wrappers and finalizers; only the outer
   operation takes the mutex. Startup freezes options before worker publication. */
static pthread_mutex_t core_io_mutex = PTHREAD_MUTEX_INITIALIZER;
static MYL_TLS unsigned core_io_depth;
static bool core_io_enter(void) {
    if (!core_parallel()) return false;
    if (core_io_depth++ == 0) pthread_mutex_lock(&core_io_mutex);
    return true;
}
static void core_io_leave(bool *active) {
    if (*active && --core_io_depth == 0) pthread_mutex_unlock(&core_io_mutex);
}
#define CORE_IO_GUARD bool core_io_guard __attribute__((cleanup(core_io_leave))) = core_io_enter()

'''
s=header+s
# Runtime public helpers are the capability boundary. Stream output has its own
# complete-unit mutex; the token test helper is pure. Do not wrap provider adapter
# callbacks independently because all their callers hold the outer operation.
pattern=r'(^[^\n;{}]*\b(myl_core_[A-Za-z_0-9]+)\([^;{}]*\)\s*\{)'
wrapped=[]
def wrap(m):
 name=m.group(2)
 if name.startswith('myl_core_stream_') or name=='myl_core_s3_token_roundtrip':return m.group(1)
 wrapped.append(name);return m.group(1)+'CORE_IO_GUARD;'
s=re.sub(pattern,wrap,s,flags=re.M)
for name in ('core_io_finalize','core_io_cleanup','core_io_live_handles','core_io_copy','core_io_copy_free'):
 pattern=r'(^[^\n;{}]*\b'+name+r'\([^;{}]*\)\s*\{)'
 s,n=re.subn(pattern,r'\1CORE_IO_GUARD;',s,flags=re.M);assert n==1,(name,n)
p.write_text(s)
(Path(__file__).parent/'io-wrapped.txt').write_text('\n'.join(wrapped)+'\n')
print('guarded public operations',len(wrapped))
