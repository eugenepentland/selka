from pathlib import Path
root=Path(__file__).parent/'src/core'
p=root/'runtime/core_rt.c';s=p.read_text()
s=s.replace('#define _POSIX_C_SOURCE 200809L','#define _GNU_SOURCE\n#define _POSIX_C_SOURCE 200809L',1)
s=s.replace('#include <malloc.h>', '#include <malloc.h>\n#include <pthread.h>\n#include <stdatomic.h>\n#include <signal.h>\n#include <errno.h>\n#include <sched.h>\n#include <sys/syscall.h>\n#include <linux/futex.h>\n\n/* RUNTIME-THREADS-1: the executable owns TLS; no dynamic library can unload it. */\n#define MYL_TLS _Thread_local __attribute__((tls_model("initial-exec")))\nstatic _Atomic bool core_pool_started;\nstatic bool core_parallel(void) { return atomic_load_explicit(&core_pool_started, memory_order_acquire); }',1)
s=s.replace('static uint64_t heap_ceiling, heap_held;', 'static uint64_t heap_ceiling;\nstatic _Atomic uint64_t heap_held;')
s=s.replace('    heap_ceiling = 0;\n','')
a=s.index('static void heap_charge(');b=s.index('/* Blocks ever carved',a)
s=s[:a]+'''static void heap_charge(size_t bytes) {
    if (!heap_ceiling) return;
    uint64_t held = atomic_load_explicit(&heap_held, memory_order_relaxed);
    for (;;) {
        if (held > heap_ceiling || bytes > heap_ceiling - held) heap_exhausted();
        if (atomic_compare_exchange_weak_explicit(&heap_held, &held, held + bytes,
                memory_order_relaxed, memory_order_relaxed)) return;
    }
}

static void heap_refund(size_t bytes) {
    if (!heap_ceiling) return;
    uint64_t held = atomic_load_explicit(&heap_held, memory_order_relaxed);
    while (!atomic_compare_exchange_weak_explicit(&heap_held, &held, held - (bytes < held ? bytes : held),
            memory_order_relaxed, memory_order_relaxed)) {}
}

'''+s[b:]
s=s.replace('static int64_t live_blocks;', 'static _Atomic int64_t live_blocks;')
s=s.replace(' * Single-threaded, like the counts. The common cases', ' * Free lists and chunk cursors belong to the current thread. The common cases')
s=s.replace('void *myl_core_free_lists[MYL_CLASSES + 1];','MYL_TLS void *myl_core_free_lists[MYL_CLASSES + 1];')
s=s.replace('static unsigned char *chunk_next, *chunk_end;', '''static MYL_TLS unsigned char *chunk_next, *chunk_end;
static MYL_TLS uint64_t core_text_walked;

/* Keep thread allocator identities until exit. Pool workers live until process
   exit; the destructor also preserves free lists from short-lived native test
   threads, so a registry entry never points into retired TLS. Report readers
   hold this mutex and run only after task quiescence. */
typedef struct core_thread_record {
    void **lists;
    uint64_t *walked;
    void *retired_lists[MYL_CLASSES + 1];
    uint64_t retired_walked;
    struct core_thread_record *next;
} core_thread_record;
static core_thread_record *core_thread_records;
static pthread_mutex_t core_thread_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_once_t core_thread_key_once = PTHREAD_ONCE_INIT;
static pthread_key_t core_thread_key;
static MYL_TLS core_thread_record *core_thread_registered;

static void core_thread_retire(void *pointer) {
    core_thread_record *record = pointer;
    pthread_mutex_lock(&core_thread_mutex);
    memcpy(record->retired_lists, record->lists, sizeof record->retired_lists);
    record->retired_walked = *record->walked;
    record->lists = record->retired_lists;
    record->walked = &record->retired_walked;
    pthread_mutex_unlock(&core_thread_mutex);
}

static void core_thread_key_initialize(void) {
    if (pthread_key_create(&core_thread_key, core_thread_retire)) out_of_memory();
}

static void core_thread_register(void) {
    if (core_thread_registered) return;
    core_thread_record *record = calloc(1, sizeof *record);
    if (!record) out_of_memory();
    record->lists = free_lists;
    record->walked = &core_text_walked;
    pthread_once(&core_thread_key_once, core_thread_key_initialize);
    if (pthread_setspecific(core_thread_key, record)) out_of_memory();
    pthread_mutex_lock(&core_thread_mutex);
    record->next = core_thread_records;
    core_thread_records = record;
    pthread_mutex_unlock(&core_thread_mutex);
    core_thread_registered = record;
}

static uint64_t core_thread_walk_total(void) {
    uint64_t total = 0;
    core_thread_register();
    pthread_mutex_lock(&core_thread_mutex);
    for (core_thread_record *at = core_thread_records; at; at = at->next) total += *at->walked;
    pthread_mutex_unlock(&core_thread_mutex);
    return total;
}''')
s=s.replace('static void *small_alloc(uint32_t class) {\n', 'static void *small_alloc(uint32_t class) {\n    core_thread_register();\n')
s=s.replace('++live_blocks;', 'atomic_fetch_add_explicit(&live_blocks, 1, memory_order_relaxed);').replace('--live_blocks;', 'atomic_fetch_sub_explicit(&live_blocks, 1, memory_order_relaxed);')
a=s.index('static int64_t live_count(void) {');b=s.index('static void block_free',a)
s=s[:a]+'''static int64_t live_count(void) {
    int64_t live = atomic_load_explicit(&live_blocks, memory_order_relaxed);
    pthread_mutex_lock(&core_thread_mutex);
    for (core_thread_record *record = core_thread_records; record; record = record->next) {
        for (int class = 1; class <= MYL_CLASSES; ++class) {
            for (void *at = record->lists[class]; at; at = *(void **)at) --live;
        }
    }
    pthread_mutex_unlock(&core_thread_mutex);
    return live;
}

'''+s[b:]
s=s.replace('static void block_free(myl_block *block) {\n    uint32_t class = class_of(block);\n', 'static void block_free(myl_block *block) {\n    uint32_t class = class_of(block);\n    core_thread_register();\n')
s=s.replace('static struct {\n    const myl_core_site *origin;', 'static MYL_TLS struct {\n    const myl_core_site *origin;')
s=s.replace('static char *trap_capture;', 'static MYL_TLS char *trap_capture;').replace('static size_t trap_capture_size;', 'static MYL_TLS size_t trap_capture_size;').replace('static int trap_lines_left = -1;', 'static MYL_TLS int trap_lines_left = -1;')
s=s.replace('static const myl_core_site *core_io_site;', 'static MYL_TLS const myl_core_site *core_io_site;')
p.write_text(s)
p=root/'runtime/core_text.c';s=p.read_text().replace('static uint64_t core_text_walked;\n','').replace('(unsigned long long)core_text_walked)', '(unsigned long long)core_thread_walk_total())');p.write_text(s)
for name in ('emit_llvm.zig','emit_count.zig'):
 p=root/name;s=p.read_text().replace('@myl_core_free_lists = external global', '@myl_core_free_lists = external thread_local(initialexec) global');p.write_text(s)
