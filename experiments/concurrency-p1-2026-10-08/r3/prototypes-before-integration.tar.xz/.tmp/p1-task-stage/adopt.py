from pathlib import Path
import shutil
root=Path.cwd();stage=root/'.tmp/p1-task-stage'
p=root/'src/core/runtime/core_rt.c';s=p.read_text()
s=s.replace('static void core_dict_finalize(myl_block *dict);','static void core_dict_finalize(myl_block *dict);\nstatic void core_task_finalize(myl_block *block);\nstatic void core_tasks_quiesce(void);')
s=s.replace('        core_io_finalize(dying);','        core_task_finalize(dying);\n        core_io_finalize(dying);')
s=s.replace('int32_t myl_core_exit(int64_t status) {','int32_t myl_core_exit(int64_t status) {\n    core_tasks_quiesce();')
p.write_text(s)
p=root/'src/core/runtime/core_test.c';s=p.read_text().replace('static bool core_test_bounded;','static bool core_test_bounded;\nstatic bool core_test_batch_parent;')
s=s.replace('bool myl_core_test_open(myl_block *input,myl_block *output){','bool myl_core_test_open(myl_block *input,myl_block *output){\n    if (core_parallel()) core_io_fail("R_TASK_FORK");\n    core_test_batch_parent = true;')
s=s.replace('int64_t myl_core_test_run(void){','int64_t myl_core_test_run(void){\n    if (core_parallel()) core_io_fail("R_TASK_FORK");')
s=s.replace('        if(child==0){','        if(child==0){\n            core_test_batch_parent = false;')
s=s.replace('core_test_on_stack(trial);alarm(0);flush_all();','core_test_on_stack(trial);core_tasks_quiesce();alarm(0);flush_all();')
p.write_text(s)
shutil.copy2(stage/'core_tasks.c',root/'src/core/runtime/core_tasks.c')
shutil.copy2(stage/'runtime/task_fixture.c',root/'src/core/task_scheduler_fixture.c')
# Keep the TSAN-BUILD-1 case for P1-5, which adds the production switch/spec.
s=(stage/'task_scheduler_test.zig').read_text().split('// spec-case: TSAN-BUILD-1')[0]
(root/'src/core/task_scheduler_test.zig').write_text(s)
p=root/'src/core/root_test.zig';s=p.read_text().replace('comptime {','comptime {\n    _ = @import("task_scheduler_test.zig");',1);p.write_text(s)
p=root/'src/core/driver.zig';s=p.read_text().replace('@embedFile("runtime/core_test.c");','@embedFile("runtime/core_test.c") ++ "\\n" ++ @embedFile("runtime/core_tasks.c");');p.write_text(s)
p=root/'src/core/emit_llvm.zig';s=p.read_text();anchor='        try fastPaths(self.allocator, out, if (self.options.counters)'
pos=s.index(anchor);s=s[:pos]+'        try out.appendSlice(self.allocator, task_bridge);\n'+s[pos:]
anchor='const runtime_fast_paths ='
pos=s.index(anchor)
bridge='''// R4: weak_odr survives LLVM dead stripping when its only caller is the
// separately compiled C runtime, while the linker merges one copy per unit.
const task_bridge =
    \\\\define weak_odr hidden ptr @myl_core_task_call(ptr %run, ptr %env) nounwind {
    \\\\  %result = call fastcc ptr %run(ptr %env)
    \\\\  ret ptr %result
    \\\\}
    \\\\
;

'''
s=s[:pos]+bridge+s[pos:];p.write_text(s)
# Standalone C fixtures provide their own C ABI adapter, never calling fastcc.
p=root/'src/core/runtime_threads_fixture.c';s=p.read_text().replace('#include <assert.h>','#include <assert.h>\nmyl_block *myl_core_task_call(void *run, myl_block *env) { return ((myl_block *(*)(myl_block *))run)(env); }');p.write_text(s)
p=root/'src/core/shared_counts_test.zig';s=p.read_text().replace('    \\\\#include <assert.h>','    \\\\#include <assert.h>\n    \\\\myl_block *myl_core_task_call(void *run, myl_block *env) { return ((myl_block *(*)(myl_block *))run)(env); }');p.write_text(s)
p=root/'SPEC.md';s=p.read_text();pos=s.index('- [SHARED-COUNTS-1]')
s=s[:pos]+'''- [TASK-SCHEDULER-1] Structured CPU tasks use a lazy fixed OS-thread pool with Chase–Lev owner deques, round-robin stealing and futex parking. Waiting runs queued work, including the waiter's own deque. The submitting thread participates; first submission starts N−1 workers, and one thread executes synchronously without sharing or retaining the environment. Task results are published with release/acquire synchronization and each result call returns an owner. Group close joins and releases its handle list; finalization also joins. Thread counts are positive MYLANG_THREADS values or affinity count; tests default to one and step/frame budgets force one. Range chunks are zero for empty input, otherwise min(items, 4×threads), with one at one thread. Batch parents cannot start a pool and a process with workers cannot fork tests. Workers inherit the process stack limit (64 MiB if unlimited), have a guard page, and block SIGALRM. Every LLVM unit supplies a C-to-fastcc task bridge; submit and group return PCs identify task trap sites.
'''+s[pos:];p.write_text(s)
