from pathlib import Path
import re
root=Path.cwd(); stage=root/'.tmp/p1-task-stage'; out=stage/'runtime'; out.mkdir(exist_ok=True)
thread=root/'.tmp/p1-thread-stage/src/core/runtime'
order=re.findall(r'@embedFile\("runtime/([^"\n]+)"\)',(root/'src/core/driver.zig').read_text().split('/// One build:')[0])
texts={name:((thread/name) if (thread/name).exists() else root/'src/core/runtime'/name).read_text() for name in order}
share=root/'.tmp/p1-share-stage'
a=(share/'core_rt.c').read_text(); b=texts['core_rt.c']
a=a[a.index('/* SHARED-COUNTS-2:'):a.index('/* Drop one owner')]
b=b[:b.index('static void core_dict_free_pending')]+a+b[b.index('/* Drop one owner'):]
b=b.replace('static void core_dict_finalize(myl_block *dict);','static void core_dict_finalize(myl_block *dict);\nstatic void core_task_finalize(myl_block *block);\nstatic void core_tasks_quiesce(void);')
b=b.replace('        core_io_finalize(dying);','        core_task_finalize(dying);\n        core_io_finalize(dying);')
b=b.replace('int32_t myl_core_exit(int64_t status) {','int32_t myl_core_exit(int64_t status) {\n    core_tasks_quiesce();')
texts['core_rt.c']=b
texts['core_dict.c']=(share/'core_dict.c').read_text()
texts['core_io.c']=(share/'core_io.c').read_text()
b=texts['core_test.c'].replace('static bool core_test_bounded;','static bool core_test_bounded;\nstatic bool core_test_batch_parent;')
b=b.replace('bool myl_core_test_open(myl_block *input,myl_block *output){','bool myl_core_test_open(myl_block *input,myl_block *output){\n    if (core_parallel()) core_io_fail("R_TASK_FORK");\n    core_test_batch_parent = true;')
b=b.replace('int64_t myl_core_test_run(void){','int64_t myl_core_test_run(void){\n    if (core_parallel()) core_io_fail("R_TASK_FORK");')
b=b.replace('        if(child==0){','        if(child==0){\n            core_test_batch_parent = false;')
b=b.replace('core_test_on_stack(trial);alarm(0);flush_all();','core_test_on_stack(trial);core_tasks_quiesce();alarm(0);flush_all();')
texts['core_test.c']=b
for name,text in texts.items(): (out/name).write_text(text)
(out/'core_tasks.c').write_text((stage/'core_tasks.c').read_text())
(out/'core_rt_all.c').write_text('\n'.join(texts.values())+'\n'+(stage/'core_tasks.c').read_text())
