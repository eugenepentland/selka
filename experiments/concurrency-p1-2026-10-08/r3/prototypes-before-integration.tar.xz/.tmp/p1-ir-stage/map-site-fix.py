from pathlib import Path
root=Path.cwd();thread=root/'.tmp/p1-thread-stage';ir=root/'.tmp/p1-ir-stage';task=root/'.tmp/p1-task-stage'
p=thread/'src/core/runtime/core_rt.c';s=p.read_text();old='''    int length = core_running_task.item < 0
        ? snprintf(text, sizeof text, "in task submitted at %s\\n", site)
        : snprintf(text, sizeof text, "in task submitted at %s (item %lld)\\n", site, (long long)core_running_task.item);'''
new='''    int length;
    if (core_running_task.item < 0) length = snprintf(text, sizeof text, "in task submitted at %s\\n", site);
    else if (!strcmp(site, "<unknown>")) length = snprintf(text, sizeof text, "in task submitted at <unknown> (item %lld)\\n", (long long)core_running_task.item);
    else length = snprintf(text, sizeof text, "in parallel.map item %lld at %s\\n", (long long)core_running_task.item, site);'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=task/'core_tasks.c';s=p.read_text();needle='int64_t myl_core_map_chunks(int64_t items) {';assert needle in s;s=s.replace(needle,'''/* Generated range thunks update this before each item. Nested execution saves
 * and restores the complete context in core_task_execute. */
void myl_core_task_item(int64_t item) { core_running_task.item = item; }
'''+needle);p.write_text(s)
p=ir/'task_ir_program.zig';s=p.read_text()
s=s.replace('fn rangeBody(a: std.mem.Allocator, m: *ir.Module, s: RangeShape) Error!u32 {','fn rangeBody(a: std.mem.Allocator, m: *ir.Module, s: RangeShape, fail: bool) Error!u32 {\n    const mark = try builder.helper(a, m, "myl_core_task_item", &.{.i64}, .void);')
needle='    const item = try h.emit(.{ .op = .list_get, .ty = .i64, .a = items, .b = cursor, .check = .exact });'
assert s.count(needle)==1
s=s.replace(needle,'''    _ = try call(&h, mark, &.{cursor});
    if (fail) {
        const denominator = try h.emit(.{ .op = .sub, .ty = .i64, .a = cursor, .b = try h.int(.i64, 17), .check = .exact });
        _ = try h.emit(.{ .op = .div, .ty = .i64, .a = try h.int(.i64, 1), .b = denominator, .check = .exact, .span = 200 });
    }
'''+needle)
s=s.replace('pub fn mapRanges(a: std.mem.Allocator) Error!ir.Module {','''pub fn mapRanges(a: std.mem.Allocator) Error!ir.Module {
    return rangeProgram(a, false);
}
/// A map fails on item 17, beyond its range's first item at one/two threads.
pub fn mapTrapped(a: std.mem.Allocator) Error!ir.Module {
    return rangeProgram(a, true);
}
fn rangeProgram(a: std.mem.Allocator, fail: bool) Error!ir.Module {''')
s=s.replace('const thunk = try rangeBody(a, &m, s);','const thunk = try rangeBody(a, &m, s, fail);')
# Ordinary submits use -1; range submit already passes start.
needle='try h.int(.i64, @intCast(i)) });'
print('capture submit candidates', [l for l in s.splitlines() if 'api.submit' in l])
p.write_text(s)
p=ir/'task_ir_test.zig';s=p.read_text().replace('enum { captures, ranges, trapped }','enum { captures, ranges, trapped, range_trapped }').replace('        .trapped => try program.trapped(a),','        .trapped => try program.trapped(a),\n        .range_trapped => try program.mapTrapped(a),')
s+='''
fn mapFatal() Error!usize {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    var directory = std.testing.tmpDir(.{});
    defer directory.cleanup();
    const root = directory.dir.realPathFileAlloc(io, ".", a) catch return error.TestUnexpectedResult;
    var artifact = try build(a, root, .{ .flavor = .range_trapped, .release = true });
    var passed: usize = 0;
    for ([_][]const u8{ "1", "2", "8" }) |threads| {
        const result = try run(a, &artifact, threads, false);
        try std.testing.expectEqual(@as(u8, 1), result.status);
        try std.testing.expectEqual(@as(usize, 1), std.mem.count(u8, result.stderr, "error[R_DIVISION_BY_ZERO]"));
        try std.testing.expectEqual(@as(usize, 1), std.mem.count(u8, result.stderr, "in parallel.map item 17 at task-hand.my:11"));
        passed += 1;
    }
    return passed;
}
// spec-case: TASK-SCHEDULER-1
test "range task reports the current item rather than its first item at 1 2 8 threads" {
    try std.testing.expectEqual(@as(usize, 3), try mapFatal());
}
''';p.write_text(s)
