from pathlib import Path
root=Path.cwd(); stage=root/'.tmp/p1-ir-stage'
s=(root/'src/core/driver.zig').read_text()
def change(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old))
 s=s.replace(old,new)
change('const count_runtime = @import("count_runtime.zig");','const count_runtime = @import("count_runtime.zig");\nconst sanitize_llvm = @import("sanitize_llvm.zig");')
change('    try validateLayout(allocator, environ, log);','    try validateLayout(allocator, environ, log);\n    try validateSanitize(allocator, environ, log);')
change('    for (layoutArguments(environment)) |argument| unit_cache.field(&hash, argument);','    for (layoutArguments(environment)) |argument| unit_cache.field(&hash, argument);\n    for (sanitizeArguments(environment)) |argument| unit_cache.field(&hash, argument);')
anchor='/// Optional LLVM optimization records from a separate compile of the exact units.'
helpers='''// TSAN-BUILD-1: instrument C and every emitted LLVM definition; the same
// option salts the runtime ABI and thereby unit, foreign and program keys.
const sanitize_variable = "MYLANG_CORE_SANITIZE";
const thread_sanitizer = "-fsanitize=thread";

fn sanitizeArguments(environment: *const std.process.Environ.Map) []const []const u8 {
    const value = environment.get(sanitize_variable) orelse return &.{};
    return if (std.mem.eql(u8, value, "thread")) &.{thread_sanitizer} else &.{};
}

fn validateSanitize(a: std.mem.Allocator, environment: *const std.process.Environ.Map, log: *std.ArrayList(u8)) Error!void {
    if (environment.get(sanitize_variable) == null or sanitizeArguments(environment).len != 0) return;
    try log.appendSlice(a, "error: MYLANG_CORE_SANITIZE must be thread\\n");
    return error.ToolFailed;
}

fn instrumented(a: std.mem.Allocator, environment: *const std.process.Environ.Map, llvm: []const u8) std.mem.Allocator.Error![]const u8 {
    return if (sanitizeArguments(environment).len != 0) sanitize_llvm.instrument(a, llvm) else llvm;
}

'''
change(anchor,helpers+anchor)
change('    if (sanitizer.len != 0) try argv.append(allocator, sanitizer);','    if (sanitizer.len != 0) try argv.append(allocator, sanitizer);\n    try argv.appendSlice(allocator, sanitizeArguments(environ));')
change('    if (environ.get(layout_variable) != null and layoutArguments(environ).len == 0) return .{};', '    if (environ.get(layout_variable) != null and layoutArguments(environ).len == 0) return .{};\n    if (environ.get(sanitize_variable) != null and sanitizeArguments(environ).len == 0) return .{};')
change('.{ .sub_path = source, .data = unit.llvm }) catch return result;', '.{ .sub_path = source, .data = try instrumented(a, environ, unit.llvm) }) catch return result;')
change('.{ .sub_path = source, .data = unit.llvm }) catch return error.WriteFailed;', '.{ .sub_path = source, .data = try instrumented(a, native.environment, unit.llvm) }) catch return error.WriteFailed;')
change('    try argv.appendSlice(native.arena, layoutArguments(native.environment));','    try argv.appendSlice(native.arena, layoutArguments(native.environment));\n    try argv.appendSlice(native.arena, sanitizeArguments(native.environment));')
change('    try argv.appendSlice(allocator, layoutArguments(native.environment));','    try argv.appendSlice(allocator, layoutArguments(native.environment));\n    try argv.appendSlice(allocator, sanitizeArguments(native.environment));')
change('        try argv.appendSlice(a, target.cpu_flags);','        try argv.appendSlice(a, target.cpu_flags);\n        try argv.appendSlice(a, sanitizeArguments(native.environment));')
# This is a draft patch, applied after P1-2's pthread flags and P1-4's runtime asset.
import difflib
(stage/'driver-sanitize.patch').write_text(''.join(difflib.unified_diff((root/'src/core/driver.zig').read_text().splitlines(True),s.splitlines(True),fromfile='a/src/core/driver.zig',tofile='b/src/core/driver.zig')))
(stage/'driver-with-sanitize.zig').write_text(s)
