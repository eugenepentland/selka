# P2-0 lowering analysis — draft, executable proof pending

This is a read-only analysis of the current compiler. P2 is not authorized by this report: its start still needs the front-end plan's F4 exit and the user's go. The task and range-thunk programs must pass the integrated P1 suite before the conclusion below is final.

## Existing Core IR is sufficient

The proposed surface needs new checking and lowering, not a new Core operation. Today's IR already supplies typed `func_ref`, ordinary helper `call` with `.runtime_c` linkage, records, `box_make`/`box_get`, lists, loops and phis. `src/core/test_builder.zig` provides SSA construction and runtime helper declarations. `src/core/build_host.zig` already demonstrates boxing an argument record around a helper call; `build_values.zig` and `build_render.zig` use the same representation pattern. `src/core/build_fn.zig` maps noncapturing callable signatures and recognizes function references. The existing ownership pass borrows ordinary call arguments and owns managed call results.

P1's native task/group kinds do not need corresponding IR type tags. The builder gives their handles opaque managed box representations and never emits `box_get` on a handle. Their runtime headers carry the actual kind and child layout. The value returned by `task_result` is the thunk's genuine result box and is the only object unboxed for the user. A handle's internal payload is not a source record.

| Surface construct | Existing-IR lowering | Ownership/lifetime |
|---|---|---|
| `with parallel.group() as g` | `.runtime_c` call to `myl_core_group_open()` returning a managed opaque handle | Result is +1; add its close operation to structured scope exits, then release the handle normally |
| `g.submit(fn, args...)` | Evaluate arguments; make a record; `box_make`; typed `func_ref` of a generated `run(env)->box[R]`; call `myl_core_task_submit(g, run, env, -1)` | Arguments are borrowed; multi-thread runtime shares/retains the environment before publication; at one thread it runs immediately without that retain/share |
| Generated task thunk | `box_get` environment; field projections; direct or indirect typed call to the original function; `box_make` its result; return | Existing ownership inserts the retained children needed by the result; runtime releases the task environment after invocation |
| `t.result()` | Call `myl_core_task_result(t)` then `box_get` | Each helper result is +1; the original handle retains its result for repeated reads |
| Scope exit | Call `myl_core_group_close(g)` on fallthrough, return, break, continue and propagated failure | Close waits while running available work; handles remain valid after the group scope |
| `parallel.map(fn, items, context...)` | Compute `k=map_chunks(len(items))`; on multiple threads share items/context once; build contiguous range environments; submit generated range-loop thunks; gather chunk results in input order into one list | Per-range result lists are owned; appended managed elements retain or transfer ownership under existing list operations; internal handle collections do not escape to source code |
| Nested groups/maps | The same helper sequence inside the thunk | Worker-local submit and waiting support nested work without a separate scheduler interface |

Use `start = i*n/k`, `end = (i+1)*n/k`, with overflow-safe arithmetic or quotient/remainder partitioning in the actual builder. Empty input returns an empty list without dividing by zero or starting workers. `map_chunks(0)` returns 0; one thread yields one range for nonempty input and source item order. A `Result` return is an ordinary element of `list[Result[R,E]]`, not a scheduler error. Zero-argument submit uses an empty environment record; a void-returning task can box an empty result record if the existing box mapping does not admit void directly. These are representation choices, not new IR operations.

The thunk pointer uses `fastcc`. C must call it only through P1's emitted C-ABI `myl_core_task_call` bridge, which invokes `call fastcc ptr %run(ptr %env)`. Its final linkage must survive optimization and deduplicate across units. `func_ref` makes the thunk address visible to existing partitioning and reachability code (`emit_units.zig`); it must not be removed as an otherwise-unused function.

## Sites and errors

Group open and submit capture their C return addresses. Put the original source span on each emitted helper call; the return-PC DWARF lookup then identifies the submit/group site without adding ABI site parameters. Range tasks pass their starting item index and call the internal `myl_core_task_item(cursor)` helper before each loop body, so a later item reports its own index. A plain submit passes −1. The scheduler saves/restores that cursor during nested work. The required fallback when no guest line information is available is `in task submitted at <unknown>`. The scheduler saves/restores task context around nested work. Phase-1 returned-error traces start at the caller's `.result()` propagation; transporting a worker's trace is later work.

Fatal errors still terminate the process with status 1. They do not become `Result` values. Task-side output is one complete print/write/debug unit at a time; output order between tasks is unspecified, while one-thread execution retains sequential order. No provider operation or Host cleanup is entered on the fatal multi-thread path.

## Files P2 will touch

These are analysis targets, not P1 edits.

| Area | Existing files / likely addition | Required work |
|---|---|---|
| Embedded module | `src/standard_library.zig`, `src/stdlib/parallel.my`, module/catalog tests | Reserve and embed `parallel`; advertise builtin signatures without pretending variadic `map`/`submit` are ordinary generics |
| Types and typed nodes | `src/typed.zig`, `src/type_catalog.zig`, `src/nominal_catalog.zig`, related identity/cache serialization | Represent Group/Task[R] nominal identities and dedicated checked task operations; include every new field/tag in semantic identities |
| Calls and function values | `src/sema_calls.zig`, `src/sema_expressions.zig`, `src/callables.zig`, likely `src/sema_tasks.zig` | Check function arity, return type and 0–5 context/0–6 submit arguments; retain existing noncapturing callable rules; reject mut arguments |
| Structured scopes and handles | `src/sema_statements.zig`, `src/sema_loops.zig`, `src/sema.zig`, typed traversal | Recognize group only as a with item; enforce handle confinement, single assignment, no loop/comprehension binding and a result-read use |
| Type containment | `src/typed.zig`, nominal/catalog helpers, task checker | Recursively reject Host and owned-resource-containing arguments/context, with a visited-type guard; ordinary capabilities remain allowed |
| Diagnostics | `src/diagnostic.zig` and diagnostic/source tests | Add E_TASK_GROUP/ESCAPE/HANDLE/RESULT_UNREAD/MUT/HOST/RESOURCE with task-site locations and alternatives |
| Core builder | `src/core/build.zig`, `src/core/build_cap.zig`, likely `src/core/build_tasks.zig`; `test_builder.zig` patterns | Generate capture and result boxes/thunks, runtime calls and ordered map gather; track group close alongside file scope close |
| CLI and trial launch | `src/core/cli_args.zig`, `src/core/cli_run.zig`, `src/core/test_runner_options.zig`, `test_runner_execute.zig`, `test_runner_directory.zig` and their tests | Add --threads, set MYLANG_THREADS per child, reserve N job permits and N−1 stack headroom, retain budget-forced sequential execution |
| Documentation/gates | SPEC.md, docs/concurrency.md, CLI help/doctests, build's test-concurrency target | Document phase-1 semantics/fatal cleanup limitation and run the P2 correctness/scaling gates |

`build.zig` currently lowers `.with_scope` at line 723 and maintains resource scope depths. `build_cap.closeScopes` closes crossed scopes in reverse order. `returnValue` invokes it for returns; propagated `?` failures also call `returnValue`; loop exits call it with their target depth. Generalize the close-operation record so file and group scopes share those existing exit paths. Do not introduce a separate partial exit mechanism that omits `?`, break or continue.

Handle checking needs a whole-function assignment/use inventory before ordinary lowering: E_TASK_HANDLE concerns assignment anywhere in the function, and E_TASK_RESULT_UNREAD is syntactic use across branches rather than waiting until runtime. Generated map handle lists are compiler implementation storage, not permission for user handles to enter collections.

The current callable schema is immediate scalar storage with no captured state (`callables.intern`), and its signature contains mutates/effect data. Reuse this rather than allowing capturing closures as a special task case. Resource/Host containment must distinguish owned handles from capabilities: `typed.resourceKind` recognizes direct resources, but nested lists, dictionaries, records and unions need a recursive walk. Existing data-type admissibility rejects more than the task rule, so it cannot be substituted wholesale.

## Proof and remaining integration risks

The ignored draft `task_ir_program.zig` has two hand-built programs: mixed list/record/dictionary/string/nested-list captures returning retained shared children, and a map-shaped range thunk with explicit loops/phis and ordered gathering. The former mutates the parent list after submission and reads each result twice. The latter checks both one-range sequential execution and multi-range execution without any frontend change. Their final integrated test paths/results belong here after P1-5 passes.

The IR vocabulary has no identified gap. The main P2 risks are checker confinement, all-exit close lowering, generated thunk reachability, overflow-safe range boundaries, and CLI permit/stack accounting. If executable proof exposes a genuine IR or ownership-pass gap, the P1 hard-stop rule applies; do not edit ir.zig or own.zig to hide it.
