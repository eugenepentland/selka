
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093500 <myl_native_octets_find>:
 1093500:	test   %rcx,%rcx
 1093503:	je     109355a <myl_native_octets_find+0x5a>
 1093505:	push   %rbp
 1093506:	mov    %rsp,%rbp
 1093509:	push   %r15
 109350b:	push   %r14
 109350d:	push   %r13
 109350f:	push   %r12
 1093511:	push   %rbx
 1093512:	sub    $0x18,%rsp
 1093516:	mov    $0xffffffffffffffff,%rax
 109351d:	mov    %rsi,%r14
 1093520:	sub    %rcx,%r14
 1093523:	jb     10937c5 <myl_native_octets_find+0x2c5>
 1093529:	mov    %rsi,%rbx
 109352c:	cmp    $0x1,%rcx
 1093530:	jne    109355d <myl_native_octets_find+0x5d>
 1093532:	movzbl (%rdx),%esi
 1093535:	mov    %rdi,%r14
 1093538:	mov    %rbx,%rdx
 109353b:	call   10ad540 <memchr@plt>
 1093540:	mov    %rax,%rcx
 1093543:	mov    %rax,%rdx
 1093546:	sub    %r14,%rdx
 1093549:	xor    %eax,%eax
 109354b:	cmp    $0x1,%rcx
 109354f:	sbb    %rax,%rax
 1093552:	or     %rdx,%rax
 1093555:	jmp    10937c5 <myl_native_octets_find+0x2c5>
 109355a:	xor    %eax,%eax
 109355c:	ret
 109355d:	mov    %rcx,-0x30(%rbp)
 1093561:	mov    %rdx,%r15
 1093564:	movzbl (%rdx),%r12d
 1093568:	lea    0x1(%r14),%rdx
 109356c:	mov    %rdi,%r13
 109356f:	mov    %r12d,%esi
 1093572:	call   10ad540 <memchr@plt>
 1093577:	test   %rax,%rax
 109357a:	je     10937be <myl_native_octets_find+0x2be>
 1093580:	mov    %r13,%rcx
 1093583:	lea    (%r14,%r13,1),%r10
 1093587:	lea    (%r14,%r13,1),%r11
 109358b:	inc    %r11
 109358e:	lea    0x1(%rax),%rdi
 1093592:	mov    $0x1,%edx
 1093597:	mov    -0x30(%rbp),%rsi
 109359b:	mov    %r15,%r8
 109359e:	xchg   %ax,%ax
 10935a0:	movzbl (%rax,%rdx,1),%r9d
 10935a5:	cmp    (%r8,%rdx,1),%r9b
 10935a9:	jne    10935bb <myl_native_octets_find+0xbb>
 10935ab:	inc    %rdx
 10935ae:	cmp    %rdx,%rsi
 10935b1:	jne    10935a0 <myl_native_octets_find+0xa0>
 10935b3:	sub    %rcx,%rax
 10935b6:	jmp    10937c5 <myl_native_octets_find+0x2c5>
 10935bb:	cmp    %r10,%rax
 10935be:	je     10937be <myl_native_octets_find+0x2be>
 10935c4:	mov    %r10,-0x38(%rbp)
 10935c8:	mov    %r11,%r14
 10935cb:	mov    %r11,%rdx
 10935ce:	sub    %rdi,%rdx
 10935d1:	mov    %r12d,%esi
 10935d4:	call   10ad540 <memchr@plt>
 10935d9:	test   %rax,%rax
 10935dc:	je     10937be <myl_native_octets_find+0x2be>
 10935e2:	lea    0x1(%rax),%rdi
 10935e6:	mov    $0x1,%edx
 10935eb:	mov    %r13,%rcx
 10935ee:	mov    -0x30(%rbp),%rsi
 10935f2:	mov    %r15,%r8
 10935f5:	mov    -0x38(%rbp),%r10
 10935f9:	mov    %r14,%r11
 10935fc:	nopl   0x0(%rax)
 1093600:	movzbl (%rax,%rdx,1),%r9d
 1093605:	cmp    (%r8,%rdx,1),%r9b
 1093609:	jne    1093615 <myl_native_octets_find+0x115>
 109360b:	inc    %rdx
 109360e:	cmp    %rdx,%rsi
 1093611:	jne    1093600 <myl_native_octets_find+0x100>
 1093613:	jmp    10935b3 <myl_native_octets_find+0xb3>
 1093615:	cmp    %r10,%rax
 1093618:	je     10937be <myl_native_octets_find+0x2be>
 109361e:	mov    %r11,%rdx
 1093621:	sub    %rdi,%rdx
 1093624:	mov    %r12d,%esi
 1093627:	call   10ad540 <memchr@plt>
 109362c:	test   %rax,%rax
 109362f:	je     10937be <myl_native_octets_find+0x2be>
 1093635:	lea    0x1(%rax),%rdi
 1093639:	mov    $0x1,%edx
 109363e:	mov    %r13,%rcx
 1093641:	mov    -0x30(%rbp),%rsi
 1093645:	mov    %r15,%r8
 1093648:	mov    -0x38(%rbp),%r10
 109364c:	mov    %r14,%r11
 109364f:	movzbl (%rax,%rdx,1),%r9d
 1093654:	cmp    (%r8,%rdx,1),%r9b
 1093658:	jne    1093667 <myl_native_octets_find+0x167>
 109365a:	inc    %rdx
 109365d:	cmp    %rdx,%rsi
 1093660:	jne    109364f <myl_native_octets_find+0x14f>
 1093662:	jmp    10935b3 <myl_native_octets_find+0xb3>
 1093667:	cmp    %r10,%rax
 109366a:	je     10937be <myl_native_octets_find+0x2be>
 1093670:	mov    %r11,%rdx
 1093673:	sub    %rdi,%rdx
 1093676:	mov    %r12d,%esi
 1093679:	call   10ad540 <memchr@plt>
 109367e:	test   %rax,%rax
 1093681:	je     10937be <myl_native_octets_find+0x2be>
 1093687:	lea    0x1(%rax),%rdi
 109368b:	mov    $0x1,%edx
 1093690:	mov    %r13,%rcx
 1093693:	mov    -0x30(%rbp),%rsi
 1093697:	mov    %r15,%r8
 109369a:	mov    -0x38(%rbp),%r10
 109369e:	mov    %r14,%r11
 10936a1:	movzbl (%rax,%rdx,1),%r9d
 10936a6:	cmp    (%r8,%rdx,1),%r9b
 10936aa:	jne    10936b9 <myl_native_octets_find+0x1b9>
 10936ac:	inc    %rdx
 10936af:	cmp    %rdx,%rsi
 10936b2:	jne    10936a1 <myl_native_octets_find+0x1a1>
 10936b4:	jmp    10935b3 <myl_native_octets_find+0xb3>
 10936b9:	cmp    %r10,%rax
 10936bc:	je     10937be <myl_native_octets_find+0x2be>
 10936c2:	mov    %r11,%rdx
 10936c5:	sub    %rdi,%rdx
 10936c8:	mov    %r12d,%esi
 10936cb:	call   10ad540 <memchr@plt>
 10936d0:	test   %rax,%rax
 10936d3:	je     10937be <myl_native_octets_find+0x2be>
 10936d9:	lea    0x1(%rax),%rdi
 10936dd:	mov    $0x1,%ecx
 10936e2:	mov    -0x30(%rbp),%rdx
 10936e6:	mov    %r15,%rsi
 10936e9:	movzbl (%rax,%rcx,1),%r8d
 10936ee:	cmp    (%rsi,%rcx,1),%r8b
 10936f2:	jne    1093704 <myl_native_octets_find+0x204>
 10936f4:	inc    %rcx
 10936f7:	cmp    %rcx,%rdx
 10936fa:	jne    10936e9 <myl_native_octets_find+0x1e9>
 10936fc:	mov    %r13,%rcx
 10936ff:	jmp    10935b3 <myl_native_octets_find+0xb3>
 1093704:	cmp    -0x38(%rbp),%rax
 1093708:	je     10937be <myl_native_octets_find+0x2be>
 109370e:	mov    %r14,%rdx
 1093711:	sub    %rdi,%rdx
 1093714:	mov    %r12d,%esi
 1093717:	call   10ad540 <memchr@plt>
 109371c:	test   %rax,%rax
 109371f:	je     10937be <myl_native_octets_find+0x2be>
 1093725:	lea    0x1(%rax),%rdi
 1093729:	mov    $0x1,%ecx
 109372e:	mov    -0x30(%rbp),%rdx
 1093732:	mov    %r15,%rsi
 1093735:	movzbl (%rax,%rcx,1),%r8d
 109373a:	cmp    (%rsi,%rcx,1),%r8b
 109373e:	jne    109374a <myl_native_octets_find+0x24a>
 1093740:	inc    %rcx
 1093743:	cmp    %rcx,%rdx
 1093746:	jne    1093735 <myl_native_octets_find+0x235>
 1093748:	jmp    10936fc <myl_native_octets_find+0x1fc>
 109374a:	cmp    -0x38(%rbp),%rax
 109374e:	je     10937be <myl_native_octets_find+0x2be>
 1093750:	mov    %r14,%rdx
 1093753:	sub    %rdi,%rdx
 1093756:	mov    %r12d,%esi
 1093759:	call   10ad540 <memchr@plt>
 109375e:	test   %rax,%rax
 1093761:	je     10937be <myl_native_octets_find+0x2be>
 1093763:	lea    0x1(%rax),%rdi
 1093767:	mov    $0x1,%ecx
 109376c:	movzbl (%rax,%rcx,1),%edx
 1093770:	cmp    (%r15,%rcx,1),%dl
 1093774:	jne    1093784 <myl_native_octets_find+0x284>
 1093776:	inc    %rcx
 1093779:	cmp    %rcx,-0x30(%rbp)
 109377d:	jne    109376c <myl_native_octets_find+0x26c>
 109377f:	jmp    10936fc <myl_native_octets_find+0x1fc>
 1093784:	cmp    -0x38(%rbp),%rax
 1093788:	je     10937be <myl_native_octets_find+0x2be>
 109378a:	sub    %rdi,%r14
 109378d:	mov    %r12d,%esi
 1093790:	mov    %r14,%rdx
 1093793:	call   10ad540 <memchr@plt>
 1093798:	test   %rax,%rax
 109379b:	je     10937be <myl_native_octets_find+0x2be>
 109379d:	lea    0x1(%rax),%rdi
 10937a1:	mov    $0x1,%ecx
 10937a6:	movzbl (%rax,%rcx,1),%edx
 10937aa:	cmp    (%r15,%rcx,1),%dl
 10937ae:	jne    10937d4 <myl_native_octets_find+0x2d4>
 10937b0:	inc    %rcx
 10937b3:	cmp    %rcx,-0x30(%rbp)
 10937b7:	jne    10937a6 <myl_native_octets_find+0x2a6>
 10937b9:	jmp    10936fc <myl_native_octets_find+0x1fc>
 10937be:	mov    $0xffffffffffffffff,%rax
 10937c5:	add    $0x18,%rsp
 10937c9:	pop    %rbx
 10937ca:	pop    %r12
 10937cc:	pop    %r13
 10937ce:	pop    %r14
 10937d0:	pop    %r15
 10937d2:	pop    %rbp
 10937d3:	ret
 10937d4:	cmp    -0x38(%rbp),%rax
 10937d8:	mov    $0xffffffffffffffff,%rax
 10937df:	je     10937c5 <myl_native_octets_find+0x2c5>
 10937e1:	add    %r13,%rbx
 10937e4:	sub    %rdi,%rbx
 10937e7:	mov    %rbx,%rsi
 10937ea:	mov    %r15,%rdx
 10937ed:	mov    -0x30(%rbp),%rcx
 10937f1:	call   10ad550 <memmem@plt>
 10937f6:	mov    %rax,%rcx
 10937f9:	mov    %rax,%rdx
 10937fc:	sub    %r13,%rdx
 10937ff:	jmp    1093549 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
