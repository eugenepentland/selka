Expanded runtime benchmark: **subset**.

6 cases; 5 measured rounds; 1 warmups; 360 measured samples across all six configurations.

Optimized default build policies; instruction sets are not matched across arms. No forced target tuning or disabled MyLang checks.

Times below are **ns per CLI iteration**, not necessarily per element. See the unit column and contracts. Application and native-library workloads include their documented algorithms. Ratios are medians of paired rounds against Go; 95% intervals use 2,000 bootstrap resamples. No aggregate ranking pools different workloads.

| Case / profile | Level | Unit | Arm | Median ns/iteration | Min–max | Ratio to Go | 95% interval |
|---|---|---|---|---:|---:|---:|---:|
| string_equal / small | micro | one string equality comparison | my-llvm | 3.66 | 3.62–3.68 | 0.812 | 0.790–0.826 |
| string_equal / small | micro | one string equality comparison | my-qbe | 20.93 | 20.90–21.15 | 4.638 | 4.497–4.750 |
| string_equal / small | micro | one string equality comparison | rust | 2.93 | 2.91–2.97 | 0.650 | 0.639–0.659 |
| string_equal / small | micro | one string equality comparison | go | 4.50 | 4.43–4.65 | 1.000 | 1.000–1.000 |
| string_equal / small | micro | one string equality comparison | zig-safe | 3.94 | 3.93–3.99 | 0.885 | 0.845–0.887 |
| string_equal / small | micro | one string equality comparison | zig-fast | 3.73 | 3.71–3.77 | 0.824 | 0.796–0.850 |
| string_equal / large | micro | one string equality comparison | my-llvm | 12.13 | 11.95–12.32 | 0.336 | 0.331–0.342 |
| string_equal / large | micro | one string equality comparison | my-qbe | 231.12 | 231.05–231.33 | 6.421 | 6.366–6.466 |
| string_equal / large | micro | one string equality comparison | rust | 29.75 | 29.59–32.57 | 0.827 | 0.818–0.903 |
| string_equal / large | micro | one string equality comparison | go | 36.03 | 35.74–36.30 | 1.000 | 1.000–1.000 |
| string_equal / large | micro | one string equality comparison | zig-safe | 63.40 | 63.05–63.69 | 1.758 | 1.746–1.782 |
| string_equal / large | micro | one string equality comparison | zig-fast | 48.59 | 48.47–49.11 | 1.348 | 1.337–1.374 |
| string_search / small | micro | one substring search | my-llvm | 19.23 | 19.15–19.31 | 0.794 | 0.793–0.807 |
| string_search / small | micro | one substring search | my-qbe | 24.25 | 24.04–24.29 | 1.004 | 0.989–1.012 |
| string_search / small | micro | one substring search | rust | 42.04 | 41.89–42.15 | 1.740 | 1.734–1.758 |
| string_search / small | micro | one substring search | go | 24.15 | 23.92–24.31 | 1.000 | 1.000–1.000 |
| string_search / small | micro | one substring search | zig-safe | 87.47 | 87.08–87.81 | 3.627 | 3.598–3.661 |
| string_search / small | micro | one substring search | zig-fast | 73.12 | 72.85–73.75 | 3.034 | 3.022–3.057 |
| string_search / large | micro | one substring search | my-llvm | 99.76 | 98.52–101.49 | 0.156 | 0.154–0.158 |
| string_search / large | micro | one substring search | my-qbe | 91.06 | 89.12–91.13 | 0.142 | 0.139–0.143 |
| string_search / large | micro | one substring search | rust | 1268.76 | 1262.31–1297.31 | 1.979 | 1.968–2.025 |
| string_search / large | micro | one substring search | go | 642.39 | 637.72–643.88 | 1.000 | 1.000–1.000 |
| string_search / large | micro | one substring search | zig-safe | 2876.38 | 2861.60–2890.72 | 4.490 | 4.455–4.504 |
| string_search / large | micro | one substring search | zig-fast | 2564.33 | 2557.45–2572.48 | 3.999 | 3.981–4.011 |
| bytes_scan / small | micro | one full byte-buffer scan | my-llvm | 3.47 | 3.44–3.49 | 0.159 | 0.150–0.161 |
| bytes_scan / small | micro | one full byte-buffer scan | my-qbe | 8.02 | 7.98–8.05 | 0.368 | 0.348–0.374 |
| bytes_scan / small | micro | one full byte-buffer scan | rust | 17.58 | 17.46–17.61 | 0.806 | 0.762–0.817 |
| bytes_scan / small | micro | one full byte-buffer scan | go | 21.67 | 21.50–23.06 | 1.000 | 1.000–1.000 |
| bytes_scan / small | micro | one full byte-buffer scan | zig-safe | 27.80 | 27.14–28.20 | 1.262 | 1.182–1.292 |
| bytes_scan / small | micro | one full byte-buffer scan | zig-fast | 12.04 | 11.88–12.05 | 0.548 | 0.522–0.560 |
| bytes_scan / large | micro | one full byte-buffer scan | my-llvm | 74.94 | 74.89–75.81 | 0.072 | 0.071–0.074 |
| bytes_scan / large | micro | one full byte-buffer scan | my-qbe | 78.26 | 77.80–78.51 | 0.075 | 0.074–0.077 |
| bytes_scan / large | micro | one full byte-buffer scan | rust | 1035.09 | 1033.40–1043.77 | 0.994 | 0.987–1.016 |
| bytes_scan / large | micro | one full byte-buffer scan | go | 1043.93 | 1018.83–1057.80 | 1.000 | 1.000–1.000 |
| bytes_scan / large | micro | one full byte-buffer scan | zig-safe | 1453.29 | 1394.36–1502.58 | 1.392 | 1.332–1.442 |
| bytes_scan / large | micro | one full byte-buffer scan | zig-fast | 691.54 | 690.78–696.17 | 0.665 | 0.654–0.678 |
| string_join / small | micro | one full fragment join and output fold | my-llvm | 162.98 | 161.83–163.76 | 0.413 | 0.411–0.416 |
| string_join / small | micro | one full fragment join and output fold | my-qbe | 189.50 | 188.75–190.71 | 0.480 | 0.480–0.482 |
| string_join / small | micro | one full fragment join and output fold | rust | 218.39 | 216.38–225.45 | 0.555 | 0.549–0.570 |
| string_join / small | micro | one full fragment join and output fold | go | 394.08 | 393.04–395.72 | 1.000 | 1.000–1.000 |
| string_join / small | micro | one full fragment join and output fold | zig-safe | 307.45 | 306.38–309.75 | 0.780 | 0.774–0.787 |
| string_join / small | micro | one full fragment join and output fold | zig-fast | 264.68 | 264.02–267.51 | 0.673 | 0.668–0.677 |
| string_join / large | micro | one full fragment join and output fold | my-llvm | 5790.19 | 5737.13–5929.06 | 0.231 | 0.228–0.237 |
| string_join / large | micro | one full fragment join and output fold | my-qbe | 5861.06 | 5820.06–5925.59 | 0.233 | 0.231–0.237 |
| string_join / large | micro | one full fragment join and output fold | rust | 13257.72 | 13212.32–13390.65 | 0.528 | 0.525–0.538 |
| string_join / large | micro | one full fragment join and output fold | go | 25074.92 | 24895.18–25248.90 | 1.000 | 1.000–1.000 |
| string_join / large | micro | one full fragment join and output fold | zig-safe | 17582.65 | 17477.22–17689.72 | 0.702 | 0.692–0.707 |
| string_join / large | micro | one full fragment join and output fold | zig-fast | 16430.02 | 16329.02–17726.24 | 0.655 | 0.649–0.712 |
| int_parse / small | micro | one strict signed decimal parse | my-llvm | 9.85 | 9.84–10.01 | 0.420 | 0.413–0.426 |
| int_parse / small | micro | one strict signed decimal parse | my-qbe | 18.08 | 18.00–18.10 | 0.768 | 0.758–0.773 |
| int_parse / small | micro | one strict signed decimal parse | rust | 4.38 | 4.33–4.41 | 0.186 | 0.184–0.187 |
| int_parse / small | micro | one strict signed decimal parse | go | 23.45 | 23.41–23.87 | 1.000 | 1.000–1.000 |
| int_parse / small | micro | one strict signed decimal parse | zig-safe | 5.69 | 5.67–5.70 | 0.242 | 0.239–0.243 |
| int_parse / small | micro | one strict signed decimal parse | zig-fast | 5.62 | 5.60–5.66 | 0.240 | 0.235–0.241 |
| int_parse / large | micro | one strict signed decimal parse | my-llvm | 11.16 | 11.13–11.20 | 0.420 | 0.416–0.423 |
| int_parse / large | micro | one strict signed decimal parse | my-qbe | 19.12 | 19.07–19.22 | 0.718 | 0.716–0.727 |
| int_parse / large | micro | one strict signed decimal parse | rust | 5.07 | 4.94–5.15 | 0.191 | 0.186–0.195 |
| int_parse / large | micro | one strict signed decimal parse | go | 26.58 | 26.44–26.72 | 1.000 | 1.000–1.000 |
| int_parse / large | micro | one strict signed decimal parse | zig-safe | 6.72 | 6.65–6.91 | 0.254 | 0.249–0.260 |
| int_parse / large | micro | one strict signed decimal parse | zig-fast | 6.22 | 6.17–6.43 | 0.234 | 0.232–0.241 |
| int_format / small | micro | one signed decimal formatting and output fold | my-llvm | 57.22 | 57.03–57.36 | 3.570 | 3.519–3.596 |
| int_format / small | micro | one signed decimal formatting and output fold | my-qbe | 83.85 | 83.48–84.48 | 5.257 | 5.147–5.296 |
| int_format / small | micro | one signed decimal formatting and output fold | rust | 14.51 | 14.30–14.73 | 0.898 | 0.891–0.920 |
| int_format / small | micro | one signed decimal formatting and output fold | go | 16.02 | 15.92–16.29 | 1.000 | 1.000–1.000 |
| int_format / small | micro | one signed decimal formatting and output fold | zig-safe | 39.60 | 39.01–39.96 | 2.474 | 2.395–2.510 |
| int_format / small | micro | one signed decimal formatting and output fold | zig-fast | 31.32 | 31.24–31.63 | 1.967 | 1.918–1.979 |
| int_format / large | micro | one signed decimal formatting and output fold | my-llvm | 58.21 | 57.89–58.55 | 3.368 | 3.350–3.402 |
| int_format / large | micro | one signed decimal formatting and output fold | my-qbe | 85.60 | 85.31–86.00 | 4.969 | 4.902–5.002 |
| int_format / large | micro | one signed decimal formatting and output fold | rust | 15.08 | 14.89–15.66 | 0.876 | 0.856–0.911 |
| int_format / large | micro | one signed decimal formatting and output fold | go | 17.21 | 17.11–17.40 | 1.000 | 1.000–1.000 |
| int_format / large | micro | one signed decimal formatting and output fold | zig-safe | 42.01 | 41.49–42.40 | 2.433 | 2.404–2.478 |
| int_format / large | micro | one signed decimal formatting and output fold | zig-fast | 35.10 | 34.80–35.61 | 2.035 | 2.033–2.072 |

Calibration limits: string_equal/small (iteration_cap), string_search/small (slowest_arm_budget), string_search/large (slowest_arm_budget), bytes_scan/small (iteration_cap), bytes_scan/large (slowest_arm_budget), string_join/small (slowest_arm_budget), int_parse/small (iteration_cap), int_format/large (slowest_arm_budget).

Per-core activity: {"2": 99.27287416683498, "3": 0.11117849201536284}.
Governor: powersave.
Sibling reservation is operator-managed; busy counters record average load and cannot exclude short interference.

Operation inventory coverage does not establish 80% of everyday CPU time. Separate application profiles are required.
