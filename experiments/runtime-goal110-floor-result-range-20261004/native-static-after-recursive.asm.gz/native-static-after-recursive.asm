
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-floor-result-range-diagnostic/native-matrix/rc-v5-llvm-accounted0/after/guest:     file format elf64-x86-64


Disassembly of section .text:

0000000001020b60 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>:
 1020b60:	push   %rax
 1020b61:	cmp    %rsp,0x40(%rdi)
 1020b65:	ja     1020bd5 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x75>
 1020b67:	mov    %rdx,%rcx
 1020b6a:	mov    %rsi,%rax
 1020b6d:	test   %rdx,%rdx
 1020b70:	jle    1020bd3 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x73>
 1020b72:	movabs $0x8000000000000010,%rdx
 1020b7c:	cmp    %rdx,%rax
 1020b7f:	jle    1020bda <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x7a>
 1020b81:	lea    -0x11(%rax),%r8
 1020b85:	movabs $0x89705f3112a28fe5,%rdx
 1020b8f:	mov    %rax,%rsi
 1020b92:	mov    %r8,%rax
 1020b95:	imul   %rdx
 1020b98:	lea    (%rdx,%rsi,1),%rax
 1020b9c:	add    $0xffffffffffffffef,%rax
 1020ba0:	mov    %rax,%rdx
 1020ba3:	shr    $0x3f,%rdx
 1020ba7:	sar    $0x1d,%rax
 1020bab:	add    %rdx,%rax
 1020bae:	imul   $0x3b9aca07,%rax,%rax
 1020bb5:	sub    %rax,%r8
 1020bb8:	mov    %r8,%rsi
 1020bbb:	sar    $0x3f,%rsi
 1020bbf:	and    $0x3b9aca07,%esi
 1020bc5:	add    %r8,%rsi
 1020bc8:	dec    %rcx
 1020bcb:	mov    %rcx,%rdx
 1020bce:	call   1020b60 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>
 1020bd3:	pop    %rcx
 1020bd4:	ret
 1020bd5:	call   1024e40 <myl_qbe_fail_frame>
 1020bda:	mov    $0x1,%esi
 1020bdf:	mov    $0x11,%ecx
 1020be4:	mov    %rax,%rdx
 1020be7:	call   1024dd0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
