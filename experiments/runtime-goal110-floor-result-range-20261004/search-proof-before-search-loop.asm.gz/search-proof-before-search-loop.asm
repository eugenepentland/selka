
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104f550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd80>:
 104f550:	mov    0x8(%rsp),%rsi
 104f555:	add    %rbx,%rsi
 104f558:	jo     1051d20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3550>
 104f55e:	mov    %rax,%r13
 104f561:	mov    0x30(%rsp),%rcx
 104f566:	mov    0x8(%rcx),%rax
 104f56a:	cmpq   $0x0,(%rax)
 104f56e:	je     1051d32 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3562>
 104f574:	mov    0x20(%rax),%rax
 104f578:	mov    (%rax),%r14
 104f57b:	test   %r14,%r14
 104f57e:	je     104f5a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f580:	movabs $0x4000000000000002,%rax
 104f58a:	test   %rax,-0x10(%r14)
 104f58e:	jne    104f5a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f590:	mov    -0x18(%r14),%rax
 104f594:	inc    %rax
 104f597:	je     1051019 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
 104f59d:	mov    %rax,-0x18(%r14)
 104f5a1:	mov    %r14,0x70(%rsp)
 104f5a6:	mov    0x10(%rcx),%rax
 104f5aa:	and    $0x3,%esi
 104f5ad:	mov    (%rax),%rdx
 104f5b0:	cmp    %rdx,%rsi
 104f5b3:	jae    1051d3e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x356e>
 104f5b9:	mov    0x20(%rax),%rax
 104f5bd:	mov    (%rax,%rsi,8),%rax
 104f5c1:	mov    (%rax),%rcx
 104f5c4:	test   %rcx,%rcx
 104f5c7:	je     104f600 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe30>
 104f5c9:	mov    $0xffffffffffffffff,%r15
 104f5d0:	cmp    (%r14),%rcx
 104f5d3:	ja     104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f5d9:	mov    0x10(%r14),%ebp
 104f5dd:	test   $0x4,%bpl
 104f5e1:	jne    104f605 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe35>
 104f5e3:	lea    0x18(%r14),%rdi
 104f5e7:	testb  $0x4,0x10(%rax)
 104f5eb:	je     104f61b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4b>
 104f5ed:	mov    0x18(%rax),%rcx
 104f5f1:	mov    0x14(%rax),%edx
 104f5f4:	add    %rcx,%rdx
 104f5f7:	add    $0x18,%rdx
 104f5fb:	jmp    104f61f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4f>
 104f5fd:	nopl   (%rax)
 104f600:	xor    %r15d,%r15d
 104f603:	jmp    104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f605:	mov    0x18(%r14),%rcx
 104f609:	mov    0x14(%r14),%edx
 104f60d:	lea    (%rcx,%rdx,1),%rdi
 104f611:	add    $0x18,%rdi
 104f615:	testb  $0x4,0x10(%rax)
 104f619:	jne    104f5ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe1d>
 104f61b:	lea    0x18(%rax),%rdx
 104f61f:	mov    0x8(%r14),%rsi
 104f623:	mov    0x8(%rax),%rcx
 104f627:	call   1093500 <myl_native_octets_find>
 104f62c:	cmp    $0xffffffffffffffff,%rax
 104f630:	movabs $0x89705f3112a28fe5,%rdi
 104f63a:	je     104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f63c:	test   $0x1,%bpl
 104f640:	jne    104f657 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe87>
 104f642:	mov    %r14,%rdi
 104f645:	mov    %rax,%rsi
 104f648:	call   1090f30 <index_walk>
 104f64d:	movabs $0x89705f3112a28fe5,%rdi
 104f657:	mov    %rax,%r15
 104f65a:	nopw   0x0(%rax,%rax,1)
 104f660:	mov    %r15,%r12
 104f663:	inc    %r12
 104f666:	jo     1051d46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3576>
 104f66c:	test   %r14,%r14
 104f66f:	mov    0x10(%rsp),%rbp
 104f674:	je     104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f676:	movabs $0x4000000000000002,%rax
 104f680:	test   %rax,-0x10(%r14)
 104f684:	jne    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f686:	mov    -0x18(%r14),%rax
 104f68a:	dec    %rax
 104f68d:	jne    104f696 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xec6>
 104f68f:	cmpq   $0x0,-0x20(%r14)
 104f694:	je     104f6e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf15>
 104f696:	mov    %rax,-0x18(%r14)
 104f69a:	mov    %r13,%rcx
 104f69d:	add    %r12,%rcx
 104f6a0:	jo     104f70f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf3f>
 104f6a2:	mov    %rcx,%rax
 104f6a5:	imul   %rdi
 104f6a8:	add    %rcx,%rdx
 104f6ab:	mov    %rdx,%rax
 104f6ae:	shr    $0x3f,%rax
 104f6b2:	sar    $0x1d,%rdx
 104f6b6:	add    %rax,%rdx
 104f6b9:	imul   $0x3b9aca07,%rdx,%rax
 104f6c0:	sub    %rax,%rcx
 104f6c3:	mov    %rcx,%rax
 104f6c6:	sar    $0x3f,%rax
 104f6ca:	and    $0x3b9aca07,%eax
 104f6cf:	add    %rcx,%rax
 104f6d2:	inc    %rbx
 104f6d5:	cmp    %rbx,0x28(%rsp)
 104f6da:	jne    104f550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd80>
