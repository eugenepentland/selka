.text
.balign 16
.globl myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22
myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	pushq %rbx
	pushq %r12
	movq 8(%rdi), %rax
	movq 56(%rdi), %rcx
	cmpq %rcx, %rax
	jz .Lbb58
	subq $32, %rsp
	movq %rsp, %rbx
	movq 48(%rdi), %rcx
	movq %rcx, (%rbx)
	movq myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22_meta@gotpcrel(%rip), %rcx
	movq %rcx, 8(%rbx)
	movq $0, 16(%rbx)
	movq %rbx, 48(%rdi)
	addq $1, %rax
	movq %rax, 8(%rdi)
	movq $0, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $1, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $2, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $3, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $4, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $5, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movl $0, %r10d
	movl $0, %r9d
.p2align 4
.Lbb9:
	movq $6, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $7, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $8, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $9, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	cmpq %rsi, %r10
	jge .Lbb52
	movq $10, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $11, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $12, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movl $2, %r8d
	movq %r10, %rax
	movq %rdx, %rcx
	cqto
	idivq %r8
	xchgq %rdx, %rcx
	movq 32(%rdi), %rax
	cmpl $0, %eax
	jnz .Lbb57
	movq $13, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $14, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $15, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	cmpq $0, %rcx
	setnz %al
	movzbq %al, %rax
	movq %rcx, %r8
	xorq $2, %r8
	cmpq $0, %r8
	setl %r8b
	movzbq %r8b, %r8
	andq %r8, %rax
	negq %rax
	andq $2, %rax
	addq %rcx, %rax
	cmpq %rax, %rdx
	jz .Lbb26
	movq $19, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $20, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movl $0, %ecx
	jmp .Lbb31
.Lbb26:
	movq $16, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $17, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $18, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %rcx
	cmpq %rax, %rcx
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movl $1, %ecx
.Lbb31:
	movq $21, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $22, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $23, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $24, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $25, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq %rcx, %rax
	addq %r9, %rax
	movq %rax, %r8
	xorq %r9, %r8
	movq %rax, %r11
	xorq %rcx, %r11
	andq %r11, %r8
	cmpq $0, %r8
	jl .Lbb50
	movq $26, 16(%rbx)
	movq (%rdi), %rcx
	movq 16(%rdi), %r8
	cmpq %rcx, %r8
	jz .Lbb56
	addq $1, %rcx
	movq %rcx, (%rdi)
	movq $27, 16(%rbx)
	movq (%rdi), %rcx
	movq 16(%rdi), %r8
	cmpq %rcx, %r8
	jz .Lbb56
	addq $1, %rcx
	movq %rcx, (%rdi)
	movl $1000000007, %r8d
	movq %rdx, %rcx
	cqto
	idivq %r8
	xchgq %rdx, %rcx
	movq 32(%rdi), %rax
	cmpl $0, %eax
	jnz .Lbb57
	movq $28, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $29, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $30, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $31, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $9223372036854775806, %rax
	cmpq %rax, %r10
	jg .Lbb48
	movq $32, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	movq $33, 16(%rbx)
	movq (%rdi), %rax
	movq 16(%rdi), %r8
	cmpq %rax, %r8
	jz .Lbb56
	addq $1, %rax
	movq %rax, (%rdi)
	cmpq $0, %rcx
	setnz %al
	movzbq %al, %rax
	movq %rcx, %r8
	xorq $1000000007, %r8
	cmpq $0, %r8
	setl %r8b
	movzbq %r8b, %r8
	andq %r8, %rax
	negq %rax
	andq $1000000007, %rax
	movq %rax, %r9
	addq %rcx, %r9
	addq $1, %r10
	jmp .Lbb9
.Lbb48:
	movq %r10, %rdx
	movl $64, %r8d
	movl $1, %ecx
	movl $0, %esi
	movq %rdi, %r12
	callq myl_qbe_fail_overflow_op
	movq %r12, %rdi
	jmp .Lbb57
.Lbb50:
	movq %r9, %rax
	movl $64, %r8d
	movq %rax, %rdx
	movl $0, %esi
	movq %rdi, %r12
	callq myl_qbe_fail_overflow_op
	movq %r12, %rdi
	jmp .Lbb57
.Lbb52:
	movq %r9, %rax
	movq $34, 16(%rbx)
	movq (%rdi), %rcx
	movq 16(%rdi), %rdx
	cmpq %rcx, %rdx
	jz .Lbb56
	addq $1, %rcx
	movq %rcx, (%rdi)
	movq $35, 16(%rbx)
	movq (%rdi), %rcx
	movq 16(%rdi), %rdx
	cmpq %rcx, %rdx
	jz .Lbb56
	addq $1, %rcx
	movq %rcx, (%rdi)
	movq (%rbx), %rcx
	movq %rcx, 48(%rdi)
	movq 8(%rdi), %rcx
	subq $1, %rcx
	movq %rcx, 8(%rdi)
	jmp .Lbb59
.Lbb56:
	movq %rdi, %r12
	callq myl_qbe_fail_step
	movq %r12, %rdi
.Lbb57:
	movq (%rbx), %rax
	movq %rax, 48(%rdi)
	movq 8(%rdi), %rax
	subq $1, %rax
	movq %rax, 8(%rdi)
	movl $0, %eax
	jmp .Lbb59
.Lbb58:
	callq myl_qbe_fail_frame
	movl $0, %eax
.Lbb59:
	movq %rbp, %rsp
	subq $16, %rsp
	popq %r12
	popq %rbx
	leave
	ret
.type myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22, @function
.size myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22, .-myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22
/* end function myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22 */

.section .note.GNU-stack,"",@progbits
