
.mylang-cache/goal110-floor-result-range-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001090ec0 <index_walk>:
 1090ec0:	push   %rbp
 1090ec1:	mov    %rsp,%rbp
 1090ec4:	push   %r15
 1090ec6:	push   %r14
 1090ec8:	push   %rbx
 1090ec9:	push   %rax
 1090eca:	mov    0x8(%rdi),%rdx
 1090ece:	mov    %rdx,%rax
 1090ed1:	sub    %rsi,%rax
 1090ed4:	jbe    1090f3a <index_walk+0x7a>
 1090ed6:	mov    0x10(%rdi),%r9d
 1090eda:	lea    0x18(%rdi),%r8
 1090ede:	mov    %r8,%rcx
 1090ee1:	test   $0x4,%r9b
 1090ee5:	je     1090ef6 <index_walk+0x36>
 1090ee7:	mov    0x18(%rdi),%rcx
 1090eeb:	mov    0x14(%rdi),%r10d
 1090eef:	add    %r10,%rcx
 1090ef2:	add    $0x18,%rcx
 1090ef6:	cmp    %rax,%rsi
 1090ef9:	mov    %rax,%r10
 1090efc:	cmovb  %rsi,%r10
 1090f00:	cmp    $0x401,%r10
 1090f07:	jb     1090f27 <index_walk+0x67>
 1090f09:	test   $0x8,%r9b
 1090f0d:	jne    1090f55 <index_walk+0x95>
 1090f0f:	test   $0x4,%r9b
 1090f13:	je     1090f27 <index_walk+0x67>
 1090f15:	mov    (%r8),%rbx
 1090f18:	test   %rbx,%rbx
 1090f1b:	je     1090f27 <index_walk+0x67>
 1090f1d:	testb  $0x8,0x10(%rbx)
 1090f21:	jne    10914f7 <index_walk+0x637>
 1090f27:	cmp    %rax,%rsi
 1090f2a:	jbe    1090f42 <index_walk+0x82>
 1090f2c:	lea    0x8(%rsi),%rax
 1090f30:	cmp    %rdx,%rax
 1090f33:	jbe    1090f64 <index_walk+0xa4>
 1090f35:	xor    %r8d,%r8d
 1090f38:	jmp    1090fb6 <index_walk+0xf6>
 1090f3a:	mov    (%rdi),%rax
 1090f3d:	jmp    1091520 <index_walk+0x660>
 1090f42:	cmp    $0x8,%rsi
 1090f46:	jae    1090fe1 <index_walk+0x121>
 1090f4c:	xor    %eax,%eax
 1090f4e:	xor    %edx,%edx
 1090f50:	jmp    1091209 <index_walk+0x349>
 1090f55:	add    $0x8,%rsp
 1090f59:	pop    %rbx
 1090f5a:	pop    %r14
 1090f5c:	pop    %r15
 1090f5e:	pop    %rbp
 1090f5f:	jmp    1091540 <index_at>
 1090f64:	movabs $0x101010101010101,%rax
 1090f6e:	xor    %r8d,%r8d
 1090f71:	mov    %rsi,%r9
 1090f74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1090f80:	mov    (%rcx,%r9,1),%rsi
 1090f84:	mov    %rsi,%r10
 1090f87:	not    %r10
 1090f8a:	add    %r10,%r10
 1090f8d:	and    %rsi,%r10
 1090f90:	shr    $0x7,%r10
 1090f94:	and    %rax,%r10
 1090f97:	imul   %rax,%r10
 1090f9b:	shr    $0x38,%r10
 1090f9f:	sub    %r10,%r8
 1090fa2:	add    $0x8,%r8
 1090fa6:	lea    0x8(%r9),%rsi
 1090faa:	add    $0x10,%r9
 1090fae:	cmp    %rdx,%r9
 1090fb1:	mov    %rsi,%r9
 1090fb4:	jbe    1090f80 <index_walk+0xc0>
 1090fb6:	mov    (%rdi),%rax
 1090fb9:	mov    %rdx,%rdi
 1090fbc:	sub    %rsi,%rdi
 1090fbf:	jbe    1091385 <index_walk+0x4c5>
 1090fc5:	cmp    $0x3,%rdi
 1090fc9:	jbe    1091370 <index_walk+0x4b0>
 1090fcf:	cmp    $0x10,%rdi
 1090fd3:	jae    1091231 <index_walk+0x371>
 1090fd9:	xor    %r9d,%r9d
 1090fdc:	jmp    109130f <index_walk+0x44f>
 1090fe1:	lea    -0x8(%rsi),%r8
 1090fe5:	cmp    $0x78,%r8
 1090fe9:	jae    1090ff9 <index_walk+0x139>
 1090feb:	mov    $0x8,%edi
 1090ff0:	xor    %edx,%edx
 1090ff2:	xor    %eax,%eax
 1090ff4:	jmp    10911c1 <index_walk+0x301>
 1090ff9:	shr    $0x3,%r8
 1090ffd:	inc    %r8
 1091000:	mov    %r8,%r9
 1091003:	and    $0xfffffffffffffff0,%r9
 1091007:	lea    0x0(,%r9,8),%rdx
 109100f:	lea    0x8(,%r9,8),%rdi
 1091017:	vpxor  %xmm2,%xmm2,%xmm2
 109101b:	xor    %eax,%eax
 109101d:	vpbroadcastq -0x89ee6(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 1091026:	vpbroadcastq -0x89ee7(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 109102f:	vpbroadcastq -0x89f68(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 1091038:	vpcmpeqd %ymm4,%ymm4,%ymm4
 109103c:	vpxor  %xmm7,%xmm7,%xmm7
 1091040:	vpxor  %xmm6,%xmm6,%xmm6
 1091044:	vpxor  %xmm5,%xmm5,%xmm5
 1091048:	nopl   0x0(%rax,%rax,1)
 1091050:	vmovdqu (%rcx,%rax,8),%ymm8
 1091055:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 109105b:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 1091061:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 1091067:	vpxor  %ymm4,%ymm8,%ymm12
 109106b:	vpaddq %ymm12,%ymm12,%ymm12
 1091070:	vpxor  %ymm4,%ymm9,%ymm13
 1091074:	vpaddq %ymm13,%ymm13,%ymm13
 1091079:	vpxor  %ymm4,%ymm10,%ymm14
 109107d:	vpaddq %ymm14,%ymm14,%ymm14
 1091082:	vpxor  %ymm4,%ymm11,%ymm15
 1091086:	vpaddq %ymm15,%ymm15,%ymm15
 109108b:	vpand  %ymm12,%ymm8,%ymm8
 1091090:	vpand  %ymm13,%ymm9,%ymm9
 1091095:	vpand  %ymm14,%ymm10,%ymm10
 109109a:	vpand  %ymm15,%ymm11,%ymm11
 109109f:	vpsrlq $0x7,%ymm8,%ymm8
 10910a5:	vpsrlq $0x7,%ymm9,%ymm9
 10910ab:	vpsrlq $0x7,%ymm10,%ymm10
 10910b1:	vpsrlq $0x7,%ymm11,%ymm11
 10910b7:	vpand  %ymm0,%ymm8,%ymm8
 10910bb:	vpand  %ymm0,%ymm9,%ymm9
 10910bf:	vpand  %ymm0,%ymm10,%ymm10
 10910c3:	vpand  %ymm0,%ymm11,%ymm11
 10910c7:	vpmuludq %ymm1,%ymm8,%ymm12
 10910cb:	vpsrlq $0x20,%ymm8,%ymm13
 10910d1:	vpmuludq %ymm0,%ymm13,%ymm13
 10910d5:	vpaddq %ymm13,%ymm12,%ymm12
 10910da:	vpsllq $0x20,%ymm12,%ymm12
 10910e0:	vpmuludq %ymm0,%ymm8,%ymm8
 10910e4:	vpaddq %ymm12,%ymm8,%ymm8
 10910e9:	vpmuludq %ymm1,%ymm9,%ymm12
 10910ed:	vpsrlq $0x20,%ymm9,%ymm13
 10910f3:	vpmuludq %ymm0,%ymm13,%ymm13
 10910f7:	vpaddq %ymm13,%ymm12,%ymm12
 10910fc:	vpsllq $0x20,%ymm12,%ymm12
 1091102:	vpmuludq %ymm0,%ymm9,%ymm9
 1091106:	vpaddq %ymm12,%ymm9,%ymm9
 109110b:	vpmuludq %ymm1,%ymm10,%ymm12
 109110f:	vpsrlq $0x20,%ymm10,%ymm13
 1091115:	vpmuludq %ymm0,%ymm13,%ymm13
 1091119:	vpaddq %ymm13,%ymm12,%ymm12
 109111e:	vpsllq $0x20,%ymm12,%ymm12
 1091124:	vpmuludq %ymm0,%ymm10,%ymm10
 1091128:	vpaddq %ymm12,%ymm10,%ymm10
 109112d:	vpmuludq %ymm1,%ymm11,%ymm12
 1091131:	vpsrlq $0x20,%ymm11,%ymm13
 1091137:	vpmuludq %ymm0,%ymm13,%ymm13
 109113b:	vpaddq %ymm13,%ymm12,%ymm12
 1091140:	vpsllq $0x20,%ymm12,%ymm12
 1091146:	vpmuludq %ymm0,%ymm11,%ymm11
 109114a:	vpaddq %ymm12,%ymm11,%ymm11
 109114f:	vpsrlq $0x38,%ymm8,%ymm8
 1091155:	vpsubq %ymm8,%ymm2,%ymm2
 109115a:	vpsrlq $0x38,%ymm9,%ymm8
 1091160:	vpsubq %ymm8,%ymm7,%ymm7
 1091165:	vpsrlq $0x38,%ymm10,%ymm8
 109116b:	vpsubq %ymm8,%ymm6,%ymm6
 1091170:	vpsrlq $0x38,%ymm11,%ymm8
 1091176:	vpsubq %ymm8,%ymm5,%ymm5
 109117b:	vpaddq %ymm3,%ymm2,%ymm2
 109117f:	vpaddq %ymm3,%ymm7,%ymm7
 1091183:	vpaddq %ymm3,%ymm6,%ymm6
 1091187:	vpaddq %ymm3,%ymm5,%ymm5
 109118b:	add    $0x10,%rax
 109118f:	cmp    %rax,%r9
 1091192:	jne    1091050 <index_walk+0x190>
 1091198:	vpaddq %ymm2,%ymm7,%ymm0
 109119c:	vpaddq %ymm0,%ymm6,%ymm0
 10911a0:	vpaddq %ymm0,%ymm5,%ymm0
 10911a4:	vextracti128 $0x1,%ymm0,%xmm1
 10911aa:	vpaddq %xmm1,%xmm0,%xmm0
 10911ae:	vpshufd $0xee,%xmm0,%xmm1
 10911b3:	vpaddq %xmm1,%xmm0,%xmm0
 10911b7:	vmovq  %xmm0,%rax
 10911bc:	cmp    %r9,%r8
 10911bf:	je     1091209 <index_walk+0x349>
 10911c1:	movabs $0x101010101010101,%r8
 10911cb:	nopl   0x0(%rax,%rax,1)
 10911d0:	mov    (%rcx,%rdx,1),%r9
 10911d4:	mov    %rdi,%rdx
 10911d7:	mov    %r9,%rdi
 10911da:	not    %rdi
 10911dd:	add    %rdi,%rdi
 10911e0:	and    %r9,%rdi
 10911e3:	shr    $0x7,%rdi
 10911e7:	and    %r8,%rdi
 10911ea:	imul   %r8,%rdi
 10911ee:	shr    $0x38,%rdi
 10911f2:	sub    %rdi,%rax
 10911f5:	add    $0x8,%rax
 10911f9:	lea    0x8(%rdx),%rdi
 10911fd:	cmp    %rsi,%rdi
 1091200:	jbe    10911d0 <index_walk+0x310>
 1091202:	add    $0xfffffffffffffff8,%rdi
 1091206:	mov    %rdi,%rdx
 1091209:	mov    %rsi,%rdi
 109120c:	sub    %rdx,%rdi
 109120f:	jbe    1091520 <index_walk+0x660>
 1091215:	cmp    $0x3,%rdi
 1091219:	jbe    10914e0 <index_walk+0x620>
 109121f:	cmp    $0x10,%rdi
 1091223:	jae    109138d <index_walk+0x4cd>
 1091229:	xor    %r8d,%r8d
 109122c:	jmp    109146f <index_walk+0x5af>
 1091231:	mov    %rdi,%r9
 1091234:	and    $0xfffffffffffffff0,%r9
 1091238:	vmovq  %r8,%xmm0
 109123d:	lea    (%rsi,%rcx,1),%r8
 1091241:	add    $0xc,%r8
 1091245:	vpxor  %xmm1,%xmm1,%xmm1
 1091249:	xor    %r10d,%r10d
 109124c:	vmovdqa -0x8f824(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 1091254:	vpbroadcastq -0x8a145(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 109125d:	vpxor  %xmm4,%xmm4,%xmm4
 1091261:	vpxor  %xmm5,%xmm5,%xmm5
 1091265:	data16 cs nopw 0x0(%rax,%rax,1)
 1091270:	vmovd  -0xc(%r8,%r10,1),%xmm6
 1091277:	vmovd  -0x8(%r8,%r10,1),%xmm7
 109127e:	vmovd  -0x4(%r8,%r10,1),%xmm8
 1091285:	vmovd  (%r8,%r10,1),%xmm9
 109128b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109128f:	vpmovzxbq %xmm6,%ymm6
 1091294:	vpand  %ymm3,%ymm6,%ymm6
 1091298:	vpaddq %ymm6,%ymm0,%ymm0
 109129c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 10912a0:	vpmovzxbq %xmm6,%ymm6
 10912a5:	vpand  %ymm3,%ymm6,%ymm6
 10912a9:	vpaddq %ymm6,%ymm1,%ymm1
 10912ad:	vpcmpgtb %xmm2,%xmm8,%xmm6
 10912b1:	vpmovzxbq %xmm6,%ymm6
 10912b6:	vpand  %ymm3,%ymm6,%ymm6
 10912ba:	vpaddq %ymm6,%ymm4,%ymm4
 10912be:	vpcmpgtb %xmm2,%xmm9,%xmm6
 10912c2:	vpmovzxbq %xmm6,%ymm6
 10912c7:	vpand  %ymm3,%ymm6,%ymm6
 10912cb:	vpaddq %ymm6,%ymm5,%ymm5
 10912cf:	add    $0x10,%r10
 10912d3:	cmp    %r10,%r9
 10912d6:	jne    1091270 <index_walk+0x3b0>
 10912d8:	vpaddq %ymm0,%ymm1,%ymm0
 10912dc:	vpaddq %ymm0,%ymm4,%ymm0
 10912e0:	vpaddq %ymm0,%ymm5,%ymm0
 10912e4:	vextracti128 $0x1,%ymm0,%xmm1
 10912ea:	vpaddq %xmm1,%xmm0,%xmm0
 10912ee:	vpshufd $0xee,%xmm0,%xmm1
 10912f3:	vpaddq %xmm1,%xmm0,%xmm0
 10912f7:	vmovq  %xmm0,%r8
 10912fc:	cmp    %r9,%rdi
 10912ff:	je     1091385 <index_walk+0x4c5>
 1091305:	test   $0xc,%dil
 1091309:	je     109152e <index_walk+0x66e>
 109130f:	mov    %rdi,%r10
 1091312:	and    $0xfffffffffffffffc,%r10
 1091316:	vmovq  %r8,%xmm0
 109131b:	lea    (%rcx,%rsi,1),%r8
 109131f:	vmovdqa -0x8f8f7(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091327:	vpbroadcastq -0x8a218(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1091330:	vmovd  (%r8,%r9,1),%xmm3
 1091336:	vpcmpgtb %xmm1,%xmm3,%xmm3
 109133a:	vpmovzxbq %xmm3,%ymm3
 109133f:	vpand  %ymm2,%ymm3,%ymm3
 1091343:	vpaddq %ymm3,%ymm0,%ymm0
 1091347:	add    $0x4,%r9
 109134b:	cmp    %r9,%r10
 109134e:	jne    1091330 <index_walk+0x470>
 1091350:	vextracti128 $0x1,%ymm0,%xmm1
 1091356:	vpaddq %xmm1,%xmm0,%xmm0
 109135a:	vpshufd $0xee,%xmm0,%xmm1
 109135f:	vpaddq %xmm1,%xmm0,%xmm0
 1091363:	vmovq  %xmm0,%r8
 1091368:	cmp    %r10,%rdi
 109136b:	je     1091385 <index_walk+0x4c5>
 109136d:	add    %r10,%rsi
 1091370:	xor    %edi,%edi
 1091372:	cmpb   $0xc0,(%rcx,%rsi,1)
 1091376:	setge  %dil
 109137a:	add    %rdi,%r8
 109137d:	inc    %rsi
 1091380:	cmp    %rsi,%rdx
 1091383:	jne    1091370 <index_walk+0x4b0>
 1091385:	sub    %r8,%rax
 1091388:	jmp    1091520 <index_walk+0x660>
 109138d:	mov    %rdi,%r8
 1091390:	and    $0xfffffffffffffff0,%r8
 1091394:	vmovq  %rax,%xmm0
 1091399:	lea    (%rdx,%rcx,1),%rax
 109139d:	add    $0xc,%rax
 10913a1:	vpxor  %xmm1,%xmm1,%xmm1
 10913a5:	xor    %r9d,%r9d
 10913a8:	vmovdqa -0x8f980(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 10913b0:	vpbroadcastq -0x8a2a1(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 10913b9:	vpxor  %xmm4,%xmm4,%xmm4
 10913bd:	vpxor  %xmm5,%xmm5,%xmm5
 10913c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10913d0:	vmovd  -0xc(%rax,%r9,1),%xmm6
 10913d7:	vmovd  -0x8(%rax,%r9,1),%xmm7
 10913de:	vmovd  -0x4(%rax,%r9,1),%xmm8
 10913e5:	vmovd  (%rax,%r9,1),%xmm9
 10913eb:	vpcmpgtb %xmm2,%xmm6,%xmm6
 10913ef:	vpmovzxbq %xmm6,%ymm6
 10913f4:	vpand  %ymm3,%ymm6,%ymm6
 10913f8:	vpaddq %ymm6,%ymm0,%ymm0
 10913fc:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1091400:	vpmovzxbq %xmm6,%ymm6
 1091405:	vpand  %ymm3,%ymm6,%ymm6
 1091409:	vpaddq %ymm6,%ymm1,%ymm1
 109140d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1091411:	vpmovzxbq %xmm6,%ymm6
 1091416:	vpand  %ymm3,%ymm6,%ymm6
 109141a:	vpaddq %ymm6,%ymm4,%ymm4
 109141e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1091422:	vpmovzxbq %xmm6,%ymm6
 1091427:	vpand  %ymm3,%ymm6,%ymm6
 109142b:	vpaddq %ymm6,%ymm5,%ymm5
 109142f:	add    $0x10,%r9
 1091433:	cmp    %r9,%r8
 1091436:	jne    10913d0 <index_walk+0x510>
 1091438:	vpaddq %ymm0,%ymm1,%ymm0
 109143c:	vpaddq %ymm0,%ymm4,%ymm0
 1091440:	vpaddq %ymm0,%ymm5,%ymm0
 1091444:	vextracti128 $0x1,%ymm0,%xmm1
 109144a:	vpaddq %xmm1,%xmm0,%xmm0
 109144e:	vpshufd $0xee,%xmm0,%xmm1
 1091453:	vpaddq %xmm1,%xmm0,%xmm0
 1091457:	vmovq  %xmm0,%rax
 109145c:	cmp    %r8,%rdi
 109145f:	je     1091520 <index_walk+0x660>
 1091465:	test   $0xc,%dil
 1091469:	je     1091536 <index_walk+0x676>
 109146f:	mov    %esi,%r9d
 1091472:	and    $0x3,%r9d
 1091476:	sub    %r9,%rdi
 1091479:	vmovq  %rax,%xmm0
 109147e:	mov    %rsi,%rax
 1091481:	and    $0xfffffffffffffffc,%rax
 1091485:	add    %rdx,%r8
 1091488:	vmovdqa -0x8fa60(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091490:	vpbroadcastq -0x8a381(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1091499:	nopl   0x0(%rax)
 10914a0:	vmovd  (%rcx,%r8,1),%xmm3
 10914a6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 10914aa:	vpmovzxbq %xmm3,%ymm3
 10914af:	vpand  %ymm2,%ymm3,%ymm3
 10914b3:	vpaddq %ymm3,%ymm0,%ymm0
 10914b7:	add    $0x4,%r8
 10914bb:	cmp    %r8,%rax
 10914be:	jne    10914a0 <index_walk+0x5e0>
 10914c0:	vextracti128 $0x1,%ymm0,%xmm1
 10914c6:	vpaddq %xmm1,%xmm0,%xmm0
 10914ca:	vpshufd $0xee,%xmm0,%xmm1
 10914cf:	vpaddq %xmm1,%xmm0,%xmm0
 10914d3:	vmovq  %xmm0,%rax
 10914d8:	test   %r9,%r9
 10914db:	je     1091520 <index_walk+0x660>
 10914dd:	add    %rdi,%rdx
 10914e0:	xor    %edi,%edi
 10914e2:	cmpb   $0xc0,(%rcx,%rdx,1)
 10914e6:	setge  %dil
 10914ea:	add    %rdi,%rax
 10914ed:	inc    %rdx
 10914f0:	cmp    %rdx,%rsi
 10914f3:	jne    10914e0 <index_walk+0x620>
 10914f5:	jmp    1091520 <index_walk+0x660>
 10914f7:	mov    0x14(%rdi),%eax
 10914fa:	add    %rax,%rsi
 10914fd:	mov    %rdi,%r15
 1091500:	mov    %rbx,%rdi
 1091503:	call   1091540 <index_at>
 1091508:	mov    %rax,%r14
 109150b:	mov    0x14(%r15),%esi
 109150f:	mov    %rbx,%rdi
 1091512:	call   1091540 <index_at>
 1091517:	mov    %rax,%rcx
 109151a:	mov    %r14,%rax
 109151d:	sub    %rcx,%rax
 1091520:	add    $0x8,%rsp
 1091524:	pop    %rbx
 1091525:	pop    %r14
 1091527:	pop    %r15
 1091529:	pop    %rbp
 109152a:	vzeroupper
 109152d:	ret
 109152e:	add    %r9,%rsi
 1091531:	jmp    1091370 <index_walk+0x4b0>
 1091536:	add    %r8,%rdx
 1091539:	jmp    10914e0 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
