
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-floor-result-range-diagnostic/native-matrix/rc-v5-llvm-accounted0/after/guest:     file format elf64-x86-64


Disassembly of section .text:

000000000101fab0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 101fab0:	push   %rbp
 101fab1:	push   %r15
 101fab3:	push   %r14
 101fab5:	push   %r13
 101fab7:	push   %r12
 101fab9:	push   %rbx
 101faba:	sub    $0x58,%rsp
 101fabe:	mov    %rdx,0x20(%rsp)
 101fac3:	mov    %rdi,%rbx
 101fac6:	cmp    %rsp,0x40(%rdi)
 101faca:	ja     1020ae2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1032>
 101fad0:	mov    %rsi,%r14
 101fad3:	cmpq   $0xffffffffffffffff,0x10(%rbx)
 101fad8:	jne    1020241 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x791>
 101fade:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 101fae3:	jne    102028c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7dc>
 101fae9:	cmpq   $0x0,(%r14)
 101faed:	je     10202d6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x826>
 101faf3:	mov    0x20(%r14),%rax
 101faf7:	mov    (%rax),%rsi
 101fafa:	mov    %rbx,%rdi
 101fafd:	call   1020bf0 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb02:	mov    (%r14),%rdx
 101fb05:	cmp    $0x1,%rdx
 101fb09:	jbe    1020aea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x103a>
 101fb0f:	mov    %rax,%r12
 101fb12:	mov    0x20(%r14),%rax
 101fb16:	mov    0x8(%rax),%rsi
 101fb1a:	mov    %rbx,%rdi
 101fb1d:	call   1020bf0 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb22:	mov    %rax,0x8(%rsp)
 101fb27:	mov    (%r14),%rdx
 101fb2a:	cmp    $0x2,%rdx
 101fb2e:	jbe    1020af7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1047>
 101fb34:	mov    0x20(%r14),%rax
 101fb38:	mov    0x10(%rax),%rsi
 101fb3c:	mov    %rbx,%rdi
 101fb3f:	call   1020bf0 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb44:	mov    (%r14),%rdx
 101fb47:	cmp    $0x3,%rdx
 101fb4b:	jbe    1020b04 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1054>
 101fb51:	mov    %rax,%r13
 101fb54:	mov    0x20(%r14),%rax
 101fb58:	mov    0x18(%rax),%rsi
 101fb5c:	mov    %rbx,%rdi
 101fb5f:	call   1020bf0 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb64:	mov    %rax,0x50(%rsp)
 101fb69:	mov    $0x1,%edi
 101fb6e:	mov    $0x20,%esi
 101fb73:	call   1037b50 <calloc@plt>
 101fb78:	mov    %rax,%r15
 101fb7b:	test   %rax,%rax
 101fb7e:	jne    101fb88 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd8>
 101fb80:	mov    %rbx,%rdi
 101fb83:	call   1024c90 <myl_qbe_fail_allocation>
 101fb88:	mov    %r13,0x18(%rsp)
 101fb8d:	mov    %rbx,0x10(%rsp)
 101fb92:	lea    0x30(%rsp),%rdi
 101fb97:	mov    $0x18,%esi
 101fb9c:	mov    $0x1007739,%edx
 101fba1:	mov    $0x29,%ecx
 101fba6:	xor    %eax,%eax
 101fba8:	call   1037b60 <snprintf@plt>
 101fbad:	lea    0x18(%r15),%r14
 101fbb1:	test   %eax,%eax
 101fbb3:	jle    101fda3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2f3>
 101fbb9:	mov    %eax,%ebp
 101fbbb:	mov    $0x40,%r13d
 101fbc1:	cmp    $0x41,%eax
 101fbc4:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fbca:	mov    $0x80,%r13d
 101fbd0:	cmp    $0x81,%ebp
 101fbd6:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fbdc:	mov    $0x100,%r13d
 101fbe2:	cmp    $0x101,%ebp
 101fbe8:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fbee:	mov    $0x200,%r13d
 101fbf4:	cmp    $0x201,%ebp
 101fbfa:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc00:	mov    $0x400,%r13d
 101fc06:	cmp    $0x401,%ebp
 101fc0c:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc12:	mov    $0x800,%r13d
 101fc18:	cmp    $0x801,%ebp
 101fc1e:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc24:	mov    $0x1000,%r13d
 101fc2a:	cmp    $0x1001,%ebp
 101fc30:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc36:	mov    $0x2000,%r13d
 101fc3c:	cmp    $0x2001,%ebp
 101fc42:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc48:	mov    $0x4000,%r13d
 101fc4e:	cmp    $0x4001,%ebp
 101fc54:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc5a:	mov    $0x8000,%r13d
 101fc60:	cmp    $0x8001,%ebp
 101fc66:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc6c:	mov    $0x10000,%r13d
 101fc72:	cmp    $0x10001,%ebp
 101fc78:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc7e:	mov    $0x20000,%r13d
 101fc84:	cmp    $0x20001,%ebp
 101fc8a:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fc90:	mov    $0x40000,%r13d
 101fc96:	cmp    $0x40001,%ebp
 101fc9c:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fca2:	mov    $0x80000,%r13d
 101fca8:	cmp    $0x80001,%ebp
 101fcae:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fcb4:	mov    $0x100000,%r13d
 101fcba:	cmp    $0x100001,%ebp
 101fcc0:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fcc6:	mov    $0x200000,%r13d
 101fccc:	cmp    $0x200001,%ebp
 101fcd2:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fcd8:	mov    $0x400000,%r13d
 101fcde:	cmp    $0x400001,%ebp
 101fce4:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fce6:	mov    $0x800000,%r13d
 101fcec:	cmp    $0x800001,%ebp
 101fcf2:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fcf4:	mov    $0x1000000,%r13d
 101fcfa:	cmp    $0x1000001,%ebp
 101fd00:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd02:	mov    $0x2000000,%r13d
 101fd08:	cmp    $0x2000001,%ebp
 101fd0e:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd10:	mov    $0x4000000,%r13d
 101fd16:	cmp    $0x4000001,%ebp
 101fd1c:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd1e:	mov    $0x8000000,%r13d
 101fd24:	cmp    $0x8000001,%ebp
 101fd2a:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd2c:	mov    $0x10000000,%r13d
 101fd32:	cmp    $0x10000001,%ebp
 101fd38:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd3a:	mov    $0x20000000,%r13d
 101fd40:	cmp    $0x20000001,%ebp
 101fd46:	jb     101fd60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b0>
 101fd48:	xor    %r13d,%r13d
 101fd4b:	cmp    $0x40000001,%ebp
 101fd51:	setae  %r13b
 101fd55:	shl    $0x1e,%r13d
 101fd59:	add    $0x40000000,%r13
 101fd60:	mov    %r13,%rdi
 101fd63:	call   1037b70 <malloc@plt>
 101fd68:	test   %rax,%rax
 101fd6b:	je     101fdde <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x32e>
 101fd6d:	mov    %rax,%rbx
 101fd70:	mov    %r14,0x28(%rsp)
 101fd75:	mov    %ebp,%ebp
 101fd77:	mov    %rax,(%r15)
 101fd7a:	mov    %r13,0x10(%r15)
 101fd7e:	lea    0x30(%rsp),%rsi
 101fd83:	mov    %rax,%rdi
 101fd86:	mov    %rbp,%rdx
 101fd89:	call   1037b30 <memcpy@plt>
 101fd8e:	mov    %r15,%r14
 101fd91:	add    $0x8,%r14
 101fd95:	mov    %rbp,0x8(%r15)
 101fd99:	cmp    %rbp,%r13
 101fd9c:	jne    101fdd5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x325>
 101fd9e:	add    %r13,%r13
 101fda1:	jmp    101fdb7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x307>
 101fda3:	mov    %r14,0x28(%rsp)
 101fda8:	mov    %r15,%r14
 101fdab:	add    $0x8,%r14
 101fdaf:	mov    $0x40,%r13d
 101fdb5:	xor    %ebx,%ebx
 101fdb7:	mov    %rbx,%rdi
 101fdba:	mov    %r13,%rsi
 101fdbd:	call   1037b80 <realloc@plt>
 101fdc2:	test   %rax,%rax
 101fdc5:	je     101fde7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x337>
 101fdc7:	mov    %rax,%rbx
 101fdca:	mov    %rax,(%r15)
 101fdcd:	mov    %r13,0x10(%r15)
 101fdd1:	mov    0x8(%r15),%rbp
 101fdd5:	movb   $0xa,(%rbx,%rbp,1)
 101fdd9:	incq   (%r14)
 101fddc:	jmp    101fdf2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x342>
 101fdde:	movl   $0x1,(%r14)
 101fde5:	jmp    101fdf2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x342>
 101fde7:	mov    0x28(%rsp),%rax
 101fdec:	movl   $0x1,(%rax)
 101fdf2:	mov    0x10(%rsp),%rbx
 101fdf7:	mov    0x18(%rsp),%r14
 101fdfc:	mov    %rbx,%rdi
 101fdff:	mov    %r15,%rsi
 101fe02:	mov    0x20(%rsp),%rdx
 101fe07:	call   102dc60 <myl_qbe_stream_finish>
 101fe0c:	cmp    $0xd,%r12
 101fe10:	ja     1020052 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5a2>
 101fe16:	mov    0x50(%rsp),%r10
 101fe1b:	jmp    *0x1009d70(,%r12,8)
 101fe23:	mov    0x8(%rsp),%r12
 101fe28:	and    $0x1,%r12d
 101fe2c:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101fe31:	mov    0x8(%rsp),%rdx
 101fe36:	mov    %rdx,%rcx
 101fe39:	add    %r14,%rcx
 101fe3c:	jo     1020b38 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1088>
 101fe42:	movabs $0x5555555555555556,%rdx
 101fe4c:	mov    %rcx,%rax
 101fe4f:	imul   %rdx
 101fe52:	mov    %rdx,%rax
 101fe55:	shr    $0x3f,%rax
 101fe59:	add    %rdx,%rax
 101fe5c:	lea    (%rax,%rax,2),%rax
 101fe60:	sub    %rax,%rcx
 101fe63:	mov    %rcx,%r12
 101fe66:	sar    $0x3f,%r12
 101fe6a:	and    $0x3,%r12d
 101fe6e:	add    %rcx,%r12
 101fe71:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101fe76:	movabs $0x7fffffffffffffff,%rdx
 101fe80:	inc    %rdx
 101fe83:	xor    %ecx,%ecx
 101fe85:	mov    0x8(%rsp),%rax
 101fe8a:	cmp    %rdx,%rax
 101fe8d:	setne  %cl
 101fe90:	neg    %rcx
 101fe93:	mov    %rax,%rdx
 101fe96:	or     %rcx,%rdx
 101fe99:	or     $0x1,%rcx
 101fe9d:	shr    $0x20,%rdx
 101fea1:	je     1020413 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x963>
 101fea7:	cqto
 101fea9:	idiv   %rcx
 101feac:	mov    %rdx,%r12
 101feaf:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101feb4:	movabs $0x4000000000000001,%rcx
 101febe:	mov    0x8(%rsp),%rsi
 101fec3:	mov    %rsi,%rax
 101fec6:	imul   %rcx
 101fec9:	mov    %rdx,%rax
 101fecc:	shr    $0x3f,%rax
 101fed0:	sar    $0x3d,%rdx
 101fed4:	add    %rax,%rdx
 101fed7:	add    %rdx,%rsi
 101feda:	shl    $0x3f,%rdx
 101fede:	add    %rsi,%rdx
 101fee1:	mov    %rdx,%rax
 101fee4:	sar    $0x3f,%rax
 101fee8:	mov    $0x3f,%cl
 101feea:	bzhi   %rcx,%rax,%r12
 101feef:	add    %rdx,%r12
 101fef2:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101fef7:	lea    -0x10(%r14),%rax
 101fefb:	movabs $0xffffffffffffff1,%rcx
 101ff05:	cmp    %rcx,%rax
 101ff08:	jae    10202e2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x832>
 101ff0e:	xor    %edi,%edi
 101ff10:	movabs $0x89705f3112a28fe5,%r8
 101ff1a:	mov    0x8(%rsp),%r12
 101ff1f:	nop
 101ff20:	mov    %edi,%eax
 101ff22:	and    $0x1,%eax
 101ff25:	xor    %ecx,%ecx
 101ff27:	cmp    %r10,%rax
 101ff2a:	sete   %cl
 101ff2d:	mov    %r12,%rsi
 101ff30:	add    %rcx,%rsi
 101ff33:	jo     1020ac8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1018>
 101ff39:	mov    %rsi,%rax
 101ff3c:	imul   %r8
 101ff3f:	add    %rsi,%rdx
 101ff42:	mov    %rdx,%rax
 101ff45:	shr    $0x3f,%rax
 101ff49:	sar    $0x1d,%rdx
 101ff4d:	add    %rax,%rdx
 101ff50:	imul   $0x3b9aca07,%rdx,%rax
 101ff57:	sub    %rax,%rsi
 101ff5a:	mov    %rsi,%r12
 101ff5d:	sar    $0x3f,%r12
 101ff61:	and    $0x3b9aca07,%r12d
 101ff68:	add    %rsi,%r12
 101ff6b:	inc    %rdi
 101ff6e:	cmp    %rdi,%r14
 101ff71:	jne    101ff20 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x470>
 101ff73:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101ff78:	movabs $0x5555555555555556,%rcx
 101ff82:	mov    0x8(%rsp),%rsi
 101ff87:	mov    %rsi,%rax
 101ff8a:	imul   %rcx
 101ff8d:	mov    %rdx,%rax
 101ff90:	shr    $0x3f,%rax
 101ff94:	add    %rdx,%rax
 101ff97:	lea    (%rax,%rax,2),%rax
 101ff9b:	sub    %rax,%rsi
 101ff9e:	mov    %rsi,%r12
 101ffa1:	sar    $0x3f,%r12
 101ffa5:	and    $0x3,%r12d
 101ffa9:	add    %rsi,%r12
 101ffac:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101ffb1:	movabs $0x89705f3112a28fe5,%rcx
 101ffbb:	mov    0x8(%rsp),%rsi
 101ffc0:	mov    %rsi,%rax
 101ffc3:	imul   %rcx
 101ffc6:	add    %rsi,%rdx
 101ffc9:	mov    %rdx,%rax
 101ffcc:	shr    $0x3f,%rax
 101ffd0:	sar    $0x1d,%rdx
 101ffd4:	add    %rax,%rdx
 101ffd7:	imul   $0x3b9aca07,%rdx,%rax
 101ffde:	sub    %rax,%rsi
 101ffe1:	mov    %rsi,%r12
 101ffe4:	sar    $0x3f,%r12
 101ffe8:	and    $0x3b9aca07,%r12d
 101ffef:	add    %rsi,%r12
 101fff2:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 101fff7:	test   %r14,%r14
 101fffa:	je     1020b45 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1095>
 1020000:	movabs $0x7fffffffffffffff,%rdx
 102000a:	inc    %rdx
 102000d:	mov    0x8(%rsp),%rax
 1020012:	mov    %rax,%rcx
 1020015:	xor    %rdx,%rcx
 1020018:	mov    %r14,%rsi
 102001b:	not    %rsi
 102001e:	xor    %edx,%edx
 1020020:	or     %rcx,%rsi
 1020023:	setne  %dl
 1020026:	lea    -0x2(,%rdx,2),%rcx
 102002e:	xor    %r14,%rcx
 1020031:	cqto
 1020033:	idiv   %rcx
 1020036:	mov    %rdx,%r12
 1020039:	xor    %rcx,%r12
 102003c:	sar    $0x3f,%r12
 1020040:	and    %rcx,%r12
 1020043:	test   %rdx,%rdx
 1020046:	cmove  %rdx,%r12
 102004a:	add    %rdx,%r12
 102004d:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 1020052:	mov    %rbx,%rdi
 1020055:	mov    0x8(%rsp),%rsi
 102005a:	mov    %r14,%rdx
 102005d:	call   1020b60 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>
 1020062:	mov    %rax,%r12
 1020065:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 102006a:	movabs $0x5555555555555556,%rcx
 1020074:	mov    0x8(%rsp),%r12
 1020079:	mov    %r12,%rax
 102007c:	imul   %rcx
 102007f:	mov    %rdx,%rax
 1020082:	shr    $0x3f,%rax
 1020086:	add    %rdx,%rax
 1020089:	lea    (%rax,%rax,2),%rax
 102008d:	jmp    102058a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xada>
 1020092:	movabs $0x5555555555555556,%rcx
 102009c:	mov    0x8(%rsp),%rsi
 10200a1:	mov    %rsi,%rax
 10200a4:	imul   %rcx
 10200a7:	mov    %rdx,%rax
 10200aa:	shr    $0x3f,%rax
 10200ae:	add    %rdx,%rax
 10200b1:	lea    (%rax,%rax,2),%rax
 10200b5:	sub    %rax,%rsi
 10200b8:	xor    %eax,%eax
 10200ba:	test   %rsi,%rsi
 10200bd:	setle  %al
 10200c0:	lea    (%rax,%rax,2),%rax
 10200c4:	lea    (%rax,%rsi,1),%r12
 10200c8:	add    $0xfffffffffffffffd,%r12
 10200cc:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 10200d1:	lea    -0x10(%r14),%rax
 10200d5:	movabs $0xffffffffffffff1,%rcx
 10200df:	cmp    %rcx,%rax
 10200e2:	jae    1020358 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8a8>
 10200e8:	xor    %edi,%edi
 10200ea:	movabs $0xaaaaaaaaaaaaaaab,%r8
 10200f4:	movabs $0x89705f3112a28fe5,%r9
 10200fe:	xor    %r10d,%r10d
 1020101:	mov    0x8(%rsp),%r12
 1020106:	cs nopw 0x0(%rax,%rax,1)
 1020110:	mov    %rdi,%rdx
 1020113:	mulx   %r8,%rax,%rax
 1020118:	shr    $1,%rax
 102011b:	lea    (%rax,%rax,2),%rax
 102011f:	mov    $0xffffffffffffffef,%rcx
 1020126:	add    %r10,%rax
 1020129:	je     1020130 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x680>
 102012b:	mov    $0x17,%ecx
 1020130:	mov    %r12,%rsi
 1020133:	add    %rcx,%rsi
 1020136:	jo     1020ad5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1025>
 102013c:	mov    %rsi,%rax
 102013f:	imul   %r9
 1020142:	add    %rsi,%rdx
 1020145:	mov    %rdx,%rax
 1020148:	shr    $0x3f,%rax
 102014c:	sar    $0x1d,%rdx
 1020150:	add    %rax,%rdx
 1020153:	imul   $0x3b9aca07,%rdx,%rax
 102015a:	sub    %rax,%rsi
 102015d:	mov    %rsi,%r12
 1020160:	sar    $0x3f,%r12
 1020164:	and    $0x3b9aca07,%r12d
 102016b:	add    %rsi,%r12
 102016e:	inc    %rdi
 1020171:	dec    %r10
 1020174:	dec    %r14
 1020177:	jne    1020110 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x660>
 1020179:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 102017e:	lea    -0x10(%r14),%rax
 1020182:	movabs $0xffffffffffffff1,%rcx
 102018c:	cmp    %rcx,%rax
 102018f:	jae    10203ee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x93e>
 1020195:	xor    %ecx,%ecx
 1020197:	test   %r10,%r10
 102019a:	sete   %cl
 102019d:	xor    %eax,%eax
 102019f:	cmp    $0x1,%r10
 10201a3:	sete   %al
 10201a6:	lea    -0x2(%r14),%rdx
 10201aa:	shr    $1,%rdx
 10201ad:	je     1020429 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x979>
 10201b3:	inc    %rdx
 10201b6:	mov    %rdx,%rsi
 10201b9:	and    $0xfffffffffffffffe,%rsi
 10201bd:	xor    %r12d,%r12d
 10201c0:	add    %ecx,%r12d
 10201c3:	imul   $0x12e0be63,%r12,%rdi
 10201ca:	shr    $0x20,%rdi
 10201ce:	mov    %r12d,%r8d
 10201d1:	sub    %edi,%r8d
 10201d4:	shr    $1,%r8d
 10201d7:	add    %edi,%r8d
 10201da:	shr    $0x1d,%r8d
 10201de:	imul   $0x3b9aca07,%r8d,%edi
 10201e5:	sub    %edi,%r12d
 10201e8:	add    %rax,%r12
 10201eb:	imul   $0x44b82f99,%r12,%rdi
 10201f2:	shr    $0x3c,%rdi
 10201f6:	imul   $0x3b9aca07,%edi,%edi
 10201fc:	sub    %edi,%r12d
 10201ff:	add    %rcx,%r12
 1020202:	imul   $0x44b82f99,%r12,%rdi
 1020209:	shr    $0x3c,%rdi
 102020d:	imul   $0x3b9aca07,%edi,%edi
 1020213:	sub    %edi,%r12d
 1020216:	add    %rax,%r12
 1020219:	imul   $0x44b82f99,%r12,%rdi
 1020220:	shr    $0x3c,%rdi
 1020224:	imul   $0x3b9aca07,%edi,%edi
 102022a:	sub    %edi,%r12d
 102022d:	add    $0xfffffffffffffffe,%rsi
 1020231:	jne    10201c0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x710>
 1020233:	test   $0x1,%dl
 1020236:	jne    102042c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x97c>
 102023c:	jmp    1020462 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b2>
 1020241:	cmpq   $0x0,0x20(%rbx)
 1020246:	jne    1020271 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7c1>
 1020248:	movl   $0x1,0x39e8(%rbx)
 1020252:	vxorps %xmm0,%xmm0,%xmm0
 1020256:	vmovups %ymm0,0x39ec(%rbx)
 102025e:	vmovups %ymm0,0x39f8(%rbx)
 1020266:	movq   $0x1007552,0x3a18(%rbx)
 1020271:	mov    $0x1007a87,%esi
 1020276:	mov    %rbx,%rdi
 1020279:	vzeroupper
 102027c:	call   10245e0 <fail>
 1020281:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 1020286:	je     101fae9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x39>
 102028c:	cmpq   $0x0,0x20(%rbx)
 1020291:	jne    10202bc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x80c>
 1020293:	movl   $0x1,0x39e8(%rbx)
 102029d:	vxorps %xmm0,%xmm0,%xmm0
 10202a1:	vmovups %ymm0,0x39ec(%rbx)
 10202a9:	vmovups %ymm0,0x39f8(%rbx)
 10202b1:	movq   $0x100759b,0x3a18(%rbx)
 10202bc:	mov    $0x1007a9c,%esi
 10202c1:	mov    %rbx,%rdi
 10202c4:	vzeroupper
 10202c7:	call   10245e0 <fail>
 10202cc:	cmpq   $0x0,(%r14)
 10202d0:	jne    101faf3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43>
 10202d6:	mov    %rbx,%rdi
 10202d9:	xor    %esi,%esi
 10202db:	xor    %edx,%edx
 10202dd:	call   1024d20 <myl_qbe_fail_normalized_index_bounds>
 10202e2:	test   %r14,%r14
 10202e5:	jle    102041f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96f>
 10202eb:	xor    %edi,%edi
 10202ed:	movabs $0x89705f3112a28fe5,%r8
 10202f7:	mov    0x8(%rsp),%r12
 10202fc:	nopl   0x0(%rax)
 1020300:	mov    %edi,%eax
 1020302:	and    $0x1,%eax
 1020305:	xor    %ecx,%ecx
 1020307:	cmp    %r10,%rax
 102030a:	sete   %cl
 102030d:	mov    %r12,%rsi
 1020310:	add    %rcx,%rsi
 1020313:	jo     1020b1e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x106e>
 1020319:	mov    %rsi,%rax
 102031c:	imul   %r8
 102031f:	add    %rsi,%rdx
 1020322:	mov    %rdx,%rax
 1020325:	shr    $0x3f,%rax
 1020329:	sar    $0x1d,%rdx
 102032d:	add    %rax,%rdx
 1020330:	imul   $0x3b9aca07,%rdx,%rax
 1020337:	sub    %rax,%rsi
 102033a:	mov    %rsi,%r12
 102033d:	sar    $0x3f,%r12
 1020341:	and    $0x3b9aca07,%r12d
 1020348:	add    %rsi,%r12
 102034b:	inc    %rdi
 102034e:	cmp    %rdi,%r14
 1020351:	jne    1020300 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x850>
 1020353:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 1020358:	test   %r14,%r14
 102035b:	jle    102041f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96f>
 1020361:	xor    %edi,%edi
 1020363:	movabs $0xaaaaaaaaaaaaaaab,%r8
 102036d:	movabs $0x89705f3112a28fe5,%r9
 1020377:	xor    %r10d,%r10d
 102037a:	mov    0x8(%rsp),%r12
 102037f:	nop
 1020380:	mov    %rdi,%rdx
 1020383:	mulx   %r8,%rax,%rax
 1020388:	shr    $1,%rax
 102038b:	lea    (%rax,%rax,2),%rax
 102038f:	mov    $0xffffffffffffffef,%rcx
 1020396:	add    %r10,%rax
 1020399:	je     10203a0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8f0>
 102039b:	mov    $0x17,%ecx
 10203a0:	mov    %r12,%rsi
 10203a3:	add    %rcx,%rsi
 10203a6:	jo     1020b2b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x107b>
 10203ac:	mov    %rsi,%rax
 10203af:	imul   %r9
 10203b2:	add    %rsi,%rdx
 10203b5:	mov    %rdx,%rax
 10203b8:	shr    $0x3f,%rax
 10203bc:	sar    $0x1d,%rdx
 10203c0:	add    %rax,%rdx
 10203c3:	imul   $0x3b9aca07,%rdx,%rax
 10203ca:	sub    %rax,%rsi
 10203cd:	mov    %rsi,%r12
 10203d0:	sar    $0x3f,%r12
 10203d4:	and    $0x3b9aca07,%r12d
 10203db:	add    %rsi,%r12
 10203de:	inc    %rdi
 10203e1:	dec    %r10
 10203e4:	dec    %r14
 10203e7:	jne    1020380 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8d0>
 10203e9:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 10203ee:	test   %r14,%r14
 10203f1:	jle    1020483 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9d3>
 10203f7:	movabs $0x44b82f989,%rax
 1020401:	cmp    $0x1,%r14
 1020405:	jne    102048b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9db>
 102040b:	xor    %r12d,%r12d
 102040e:	jmp    1020573 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac3>
 1020413:	xor    %edx,%edx
 1020415:	div    %ecx
 1020417:	mov    %edx,%r12d
 102041a:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 102041f:	mov    0x8(%rsp),%r12
 1020424:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 1020429:	xor    %r12d,%r12d
 102042c:	add    %rcx,%r12
 102042f:	movabs $0x44b82f989,%rcx
 1020439:	mov    %r12,%rdx
 102043c:	mulx   %rcx,%rcx,%rcx
 1020441:	imul   $0x3b9aca07,%rcx,%rcx
 1020448:	sub    %rcx,%r12
 102044b:	add    %rax,%r12
 102044e:	imul   $0x44b82f99,%r12,%rax
 1020455:	shr    $0x3c,%rax
 1020459:	imul   $0x3b9aca07,%eax,%eax
 102045f:	sub    %eax,%r12d
 1020462:	test   $0x1,%r14b
 1020466:	je     102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 102046c:	cmp    $0x1,%r10
 1020470:	adc    $0x0,%r12
 1020474:	movabs $0x44b82f989,%rax
 102047e:	jmp    102057b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xacb>
 1020483:	xor    %r12d,%r12d
 1020486:	jmp    102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 102048b:	xor    %edx,%edx
 102048d:	test   %r10,%r10
 1020490:	sete   %dl
 1020493:	xor    %ecx,%ecx
 1020495:	cmp    $0x1,%r10
 1020499:	sete   %cl
 102049c:	lea    -0x2(%r14),%rsi
 10204a0:	shr    $1,%rsi
 10204a3:	je     102053e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa8e>
 10204a9:	inc    %rsi
 10204ac:	movabs $0x7fffffffffffffff,%rdi
 10204b6:	dec    %rdi
 10204b9:	and    %rsi,%rdi
 10204bc:	xor    %r12d,%r12d
 10204bf:	nop
 10204c0:	add    %edx,%r12d
 10204c3:	imul   $0x12e0be63,%r12,%r8
 10204ca:	shr    $0x20,%r8
 10204ce:	mov    %r12d,%r9d
 10204d1:	sub    %r8d,%r9d
 10204d4:	shr    $1,%r9d
 10204d7:	add    %r8d,%r9d
 10204da:	shr    $0x1d,%r9d
 10204de:	imul   $0x3b9aca07,%r9d,%r8d
 10204e5:	sub    %r8d,%r12d
 10204e8:	add    %rcx,%r12
 10204eb:	imul   $0x44b82f99,%r12,%r8
 10204f2:	shr    $0x3c,%r8
 10204f6:	imul   $0x3b9aca07,%r8d,%r8d
 10204fd:	sub    %r8d,%r12d
 1020500:	add    %rdx,%r12
 1020503:	imul   $0x44b82f99,%r12,%r8
 102050a:	shr    $0x3c,%r8
 102050e:	imul   $0x3b9aca07,%r8d,%r8d
 1020515:	sub    %r8d,%r12d
 1020518:	add    %rcx,%r12
 102051b:	imul   $0x44b82f99,%r12,%r8
 1020522:	shr    $0x3c,%r8
 1020526:	imul   $0x3b9aca07,%r8d,%r8d
 102052d:	sub    %r8d,%r12d
 1020530:	add    $0xfffffffffffffffe,%rdi
 1020534:	jne    10204c0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa10>
 1020536:	test   $0x1,%sil
 102053a:	jne    1020541 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa91>
 102053c:	jmp    102056d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xabd>
 102053e:	xor    %r12d,%r12d
 1020541:	add    %rdx,%r12
 1020544:	mov    %r12,%rdx
 1020547:	mulx   %rax,%rdx,%rdx
 102054c:	imul   $0x3b9aca07,%rdx,%rdx
 1020553:	sub    %rdx,%r12
 1020556:	add    %rcx,%r12
 1020559:	imul   $0x44b82f99,%r12,%rcx
 1020560:	shr    $0x3c,%rcx
 1020564:	imul   $0x3b9aca07,%ecx,%ecx
 102056a:	sub    %ecx,%r12d
 102056d:	test   $0x1,%r14b
 1020571:	je     102058d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xadd>
 1020573:	cmp    $0x1,%r10
 1020577:	adc    $0x0,%r12
 102057b:	mov    %r12,%rdx
 102057e:	mulx   %rax,%rax,%rax
 1020583:	imul   $0x3b9aca07,%rax,%rax
 102058a:	sub    %rax,%r12
 102058d:	mov    $0x1,%edi
 1020592:	mov    $0x20,%esi
 1020597:	call   1037b50 <calloc@plt>
 102059c:	mov    %rax,%r14
 102059f:	test   %rax,%rax
 10205a2:	jne    10205ac <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xafc>
 10205a4:	mov    %rbx,%rdi
 10205a7:	call   1024c90 <myl_qbe_fail_allocation>
 10205ac:	lea    0x30(%rsp),%rdi
 10205b1:	mov    $0x18,%esi
 10205b6:	mov    $0x1007739,%edx
 10205bb:	mov    %r12,%rcx
 10205be:	xor    %eax,%eax
 10205c0:	call   1037b60 <snprintf@plt>
 10205c5:	lea    0x18(%r14),%r12
 10205c9:	test   %eax,%eax
 10205cb:	jle    10207ce <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd1e>
 10205d1:	mov    %eax,%ebp
 10205d3:	mov    $0x40,%r15d
 10205d9:	cmp    $0x41,%eax
 10205dc:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10205e2:	mov    $0x80,%r15d
 10205e8:	cmp    $0x81,%ebp
 10205ee:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10205f4:	mov    $0x100,%r15d
 10205fa:	cmp    $0x101,%ebp
 1020600:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020606:	mov    $0x200,%r15d
 102060c:	cmp    $0x201,%ebp
 1020612:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020618:	mov    $0x400,%r15d
 102061e:	cmp    $0x401,%ebp
 1020624:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 102062a:	mov    $0x800,%r15d
 1020630:	cmp    $0x801,%ebp
 1020636:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 102063c:	mov    $0x1000,%r15d
 1020642:	cmp    $0x1001,%ebp
 1020648:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 102064e:	mov    $0x2000,%r15d
 1020654:	cmp    $0x2001,%ebp
 102065a:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020660:	mov    $0x4000,%r15d
 1020666:	cmp    $0x4001,%ebp
 102066c:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020672:	mov    $0x8000,%r15d
 1020678:	cmp    $0x8001,%ebp
 102067e:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020684:	mov    $0x10000,%r15d
 102068a:	cmp    $0x10001,%ebp
 1020690:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020696:	mov    $0x20000,%r15d
 102069c:	cmp    $0x20001,%ebp
 10206a2:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206a8:	mov    $0x40000,%r15d
 10206ae:	cmp    $0x40001,%ebp
 10206b4:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206ba:	mov    $0x80000,%r15d
 10206c0:	cmp    $0x80001,%ebp
 10206c6:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206cc:	mov    $0x100000,%r15d
 10206d2:	cmp    $0x100001,%ebp
 10206d8:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206de:	mov    $0x200000,%r15d
 10206e4:	cmp    $0x200001,%ebp
 10206ea:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206f0:	mov    $0x400000,%r15d
 10206f6:	cmp    $0x400001,%ebp
 10206fc:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 10206fe:	mov    $0x800000,%r15d
 1020704:	cmp    $0x800001,%ebp
 102070a:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 102070c:	mov    $0x1000000,%r15d
 1020712:	cmp    $0x1000001,%ebp
 1020718:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 102071a:	mov    $0x2000000,%r15d
 1020720:	cmp    $0x2000001,%ebp
 1020726:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020728:	mov    $0x4000000,%r15d
 102072e:	cmp    $0x4000001,%ebp
 1020734:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020736:	mov    $0x8000000,%r15d
 102073c:	cmp    $0x8000001,%ebp
 1020742:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020744:	mov    $0x10000000,%r15d
 102074a:	cmp    $0x10000001,%ebp
 1020750:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020752:	mov    $0x20000000,%r15d
 1020758:	cmp    $0x20000001,%ebp
 102075e:	jb     1020778 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc8>
 1020760:	xor    %r15d,%r15d
 1020763:	cmp    $0x40000001,%ebp
 1020769:	setae  %r15b
 102076d:	shl    $0x1e,%r15d
 1020771:	add    $0x40000000,%r15
 1020778:	mov    %r15,%rdi
 102077b:	call   1037b70 <malloc@plt>
 1020780:	test   %rax,%rax
 1020783:	je     10207f7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd47>
 1020785:	mov    %ebp,%ebx
 1020787:	mov    %rax,(%r14)
 102078a:	mov    %r15,0x10(%r14)
 102078e:	lea    0x30(%rsp),%rsi
 1020793:	mov    %rax,%rbp
 1020796:	mov    %rax,%rdi
 1020799:	mov    %rbx,%rdx
 102079c:	call   1037b30 <memcpy@plt>
 10207a1:	mov    %r14,%r13
 10207a4:	add    $0x8,%r13
 10207a8:	mov    %rbx,0x8(%r14)
 10207ac:	cmp    %rbx,%r15
 10207af:	jne    1020801 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd51>
 10207b1:	add    %r15,%r15
 10207b4:	mov    %rbp,%rdi
 10207b7:	mov    %r15,%rsi
 10207ba:	call   1037b80 <realloc@plt>
 10207bf:	test   %rax,%rax
 10207c2:	jne    10207ea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd3a>
 10207c4:	movl   $0x1,(%r12)
 10207cc:	jmp    102080c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd5c>
 10207ce:	mov    %r14,%r13
 10207d1:	add    $0x8,%r13
 10207d5:	mov    $0x40,%r15d
 10207db:	xor    %edi,%edi
 10207dd:	mov    %r15,%rsi
 10207e0:	call   1037b80 <realloc@plt>
 10207e5:	test   %rax,%rax
 10207e8:	je     10207c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd14>
 10207ea:	mov    %rax,(%r14)
 10207ed:	mov    %r15,0x10(%r14)
 10207f1:	mov    0x8(%r14),%rbx
 10207f5:	jmp    1020804 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd54>
 10207f7:	movl   $0x1,(%r12)
 10207ff:	jmp    1020811 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd61>
 1020801:	mov    %rbp,%rax
 1020804:	movb   $0xa,(%rax,%rbx,1)
 1020808:	incq   0x0(%r13)
 102080c:	mov    0x10(%rsp),%rbx
 1020811:	mov    %rbx,%rdi
 1020814:	mov    %r14,%rsi
 1020817:	mov    0x20(%rsp),%rdx
 102081c:	call   102dc60 <myl_qbe_stream_finish>
 1020821:	mov    $0x1,%edi
 1020826:	mov    $0x20,%esi
 102082b:	call   1037b50 <calloc@plt>
 1020830:	mov    %rax,%r14
 1020833:	test   %rax,%rax
 1020836:	jne    1020840 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd90>
 1020838:	mov    %rbx,%rdi
 102083b:	call   1024c90 <myl_qbe_fail_allocation>
 1020840:	lea    0x30(%rsp),%rdi
 1020845:	mov    $0x18,%esi
 102084a:	mov    $0x1007739,%edx
 102084f:	mov    $0x2b,%ecx
 1020854:	xor    %eax,%eax
 1020856:	call   1037b60 <snprintf@plt>
 102085b:	lea    0x18(%r14),%r12
 102085f:	test   %eax,%eax
 1020861:	jle    1020a64 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfb4>
 1020867:	mov    %eax,%ebp
 1020869:	mov    $0x40,%r15d
 102086f:	cmp    $0x41,%eax
 1020872:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020878:	mov    $0x80,%r15d
 102087e:	cmp    $0x81,%ebp
 1020884:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 102088a:	mov    $0x100,%r15d
 1020890:	cmp    $0x101,%ebp
 1020896:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 102089c:	mov    $0x200,%r15d
 10208a2:	cmp    $0x201,%ebp
 10208a8:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10208ae:	mov    $0x400,%r15d
 10208b4:	cmp    $0x401,%ebp
 10208ba:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10208c0:	mov    $0x800,%r15d
 10208c6:	cmp    $0x801,%ebp
 10208cc:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10208d2:	mov    $0x1000,%r15d
 10208d8:	cmp    $0x1001,%ebp
 10208de:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10208e4:	mov    $0x2000,%r15d
 10208ea:	cmp    $0x2001,%ebp
 10208f0:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10208f6:	mov    $0x4000,%r15d
 10208fc:	cmp    $0x4001,%ebp
 1020902:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020908:	mov    $0x8000,%r15d
 102090e:	cmp    $0x8001,%ebp
 1020914:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 102091a:	mov    $0x10000,%r15d
 1020920:	cmp    $0x10001,%ebp
 1020926:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 102092c:	mov    $0x20000,%r15d
 1020932:	cmp    $0x20001,%ebp
 1020938:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 102093e:	mov    $0x40000,%r15d
 1020944:	cmp    $0x40001,%ebp
 102094a:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020950:	mov    $0x80000,%r15d
 1020956:	cmp    $0x80001,%ebp
 102095c:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020962:	mov    $0x100000,%r15d
 1020968:	cmp    $0x100001,%ebp
 102096e:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020974:	mov    $0x200000,%r15d
 102097a:	cmp    $0x200001,%ebp
 1020980:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020986:	mov    $0x400000,%r15d
 102098c:	cmp    $0x400001,%ebp
 1020992:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 1020994:	mov    $0x800000,%r15d
 102099a:	cmp    $0x800001,%ebp
 10209a0:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209a2:	mov    $0x1000000,%r15d
 10209a8:	cmp    $0x1000001,%ebp
 10209ae:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209b0:	mov    $0x2000000,%r15d
 10209b6:	cmp    $0x2000001,%ebp
 10209bc:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209be:	mov    $0x4000000,%r15d
 10209c4:	cmp    $0x4000001,%ebp
 10209ca:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209cc:	mov    $0x8000000,%r15d
 10209d2:	cmp    $0x8000001,%ebp
 10209d8:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209da:	mov    $0x10000000,%r15d
 10209e0:	cmp    $0x10000001,%ebp
 10209e6:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209e8:	mov    $0x20000000,%r15d
 10209ee:	cmp    $0x20000001,%ebp
 10209f4:	jb     1020a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5e>
 10209f6:	xor    %r15d,%r15d
 10209f9:	cmp    $0x40000001,%ebp
 10209ff:	setae  %r15b
 1020a03:	shl    $0x1e,%r15d
 1020a07:	add    $0x40000000,%r15
 1020a0e:	mov    %r15,%rdi
 1020a11:	call   1037b70 <malloc@plt>
 1020a16:	test   %rax,%rax
 1020a19:	je     1020a8d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfdd>
 1020a1b:	mov    %ebp,%ebx
 1020a1d:	mov    %rax,(%r14)
 1020a20:	mov    %r15,0x10(%r14)
 1020a24:	lea    0x30(%rsp),%rsi
 1020a29:	mov    %rax,%rbp
 1020a2c:	mov    %rax,%rdi
 1020a2f:	mov    %rbx,%rdx
 1020a32:	call   1037b30 <memcpy@plt>
 1020a37:	mov    %r14,%r13
 1020a3a:	add    $0x8,%r13
 1020a3e:	mov    %rbx,0x8(%r14)
 1020a42:	cmp    %rbx,%r15
 1020a45:	jne    1020a97 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfe7>
 1020a47:	add    %r15,%r15
 1020a4a:	mov    %rbp,%rdi
 1020a4d:	mov    %r15,%rsi
 1020a50:	call   1037b80 <realloc@plt>
 1020a55:	test   %rax,%rax
 1020a58:	jne    1020a80 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfd0>
 1020a5a:	movl   $0x1,(%r12)
 1020a62:	jmp    1020aa2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xff2>
 1020a64:	mov    %r14,%r13
 1020a67:	add    $0x8,%r13
 1020a6b:	mov    $0x40,%r15d
 1020a71:	xor    %edi,%edi
 1020a73:	mov    %r15,%rsi
 1020a76:	call   1037b80 <realloc@plt>
 1020a7b:	test   %rax,%rax
 1020a7e:	je     1020a5a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfaa>
 1020a80:	mov    %rax,(%r14)
 1020a83:	mov    %r15,0x10(%r14)
 1020a87:	mov    0x8(%r14),%rbx
 1020a8b:	jmp    1020a9a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfea>
 1020a8d:	movl   $0x1,(%r12)
 1020a95:	jmp    1020aa7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xff7>
 1020a97:	mov    %rbp,%rax
 1020a9a:	movb   $0xa,(%rax,%rbx,1)
 1020a9e:	incq   0x0(%r13)
 1020aa2:	mov    0x10(%rsp),%rbx
 1020aa7:	mov    %rbx,%rdi
 1020aaa:	mov    %r14,%rsi
 1020aad:	mov    0x20(%rsp),%rdx
 1020ab2:	call   102dc60 <myl_qbe_stream_finish>
 1020ab7:	xor    %eax,%eax
 1020ab9:	add    $0x58,%rsp
 1020abd:	pop    %rbx
 1020abe:	pop    %r12
 1020ac0:	pop    %r13
 1020ac2:	pop    %r14
 1020ac4:	pop    %r15
 1020ac6:	pop    %rbp
 1020ac7:	ret
 1020ac8:	mov    %rbx,%rdi
 1020acb:	xor    %esi,%esi
 1020acd:	mov    %r12,%rdx
 1020ad0:	call   1024dd0 <myl_qbe_fail_overflow_op>
 1020ad5:	mov    %rbx,%rdi
 1020ad8:	xor    %esi,%esi
 1020ada:	mov    %r12,%rdx
 1020add:	call   1024dd0 <myl_qbe_fail_overflow_op>
 1020ae2:	mov    %rbx,%rdi
 1020ae5:	call   1024e40 <myl_qbe_fail_frame>
 1020aea:	mov    $0x1,%esi
 1020aef:	mov    %rbx,%rdi
 1020af2:	call   1024d20 <myl_qbe_fail_normalized_index_bounds>
 1020af7:	mov    $0x2,%esi
 1020afc:	mov    %rbx,%rdi
 1020aff:	call   1024d20 <myl_qbe_fail_normalized_index_bounds>
 1020b04:	mov    $0x3,%esi
 1020b09:	mov    %rbx,%rdi
 1020b0c:	call   1024d20 <myl_qbe_fail_normalized_index_bounds>
 1020b11:	mov    %rbx,%rdi
 1020b14:	mov    0x8(%rsp),%rsi
 1020b19:	call   1024d80 <myl_qbe_fail_division>
 1020b1e:	mov    %rbx,%rdi
 1020b21:	xor    %esi,%esi
 1020b23:	mov    %r12,%rdx
 1020b26:	call   1024dd0 <myl_qbe_fail_overflow_op>
 1020b2b:	mov    %rbx,%rdi
 1020b2e:	xor    %esi,%esi
 1020b30:	mov    %r12,%rdx
 1020b33:	call   1024dd0 <myl_qbe_fail_overflow_op>
 1020b38:	mov    %rbx,%rdi
 1020b3b:	xor    %esi,%esi
 1020b3d:	mov    %r14,%rcx
 1020b40:	call   1024dd0 <myl_qbe_fail_overflow_op>
 1020b45:	mov    %rbx,%rdi
 1020b48:	mov    0x8(%rsp),%rsi
 1020b4d:	call   1024d80 <myl_qbe_fail_division>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
