
.mylang-cache/goal110-floor-result-range-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104f530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd60>:
 104f530:	mov    0x8(%rsp),%rsi
 104f535:	add    %rbx,%rsi
 104f538:	jo     1051d00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3530>
 104f53e:	mov    %rax,%r13
 104f541:	mov    0x30(%rsp),%rcx
 104f546:	mov    0x8(%rcx),%rax
 104f54a:	cmpq   $0x0,(%rax)
 104f54e:	je     1051d12 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3542>
 104f554:	mov    0x20(%rax),%rax
 104f558:	mov    (%rax),%r14
 104f55b:	test   %r14,%r14
 104f55e:	je     104f581 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb1>
 104f560:	movabs $0x4000000000000002,%rax
 104f56a:	test   %rax,-0x10(%r14)
 104f56e:	jne    104f581 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb1>
 104f570:	mov    -0x18(%r14),%rax
 104f574:	inc    %rax
 104f577:	je     1050ff9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2829>
 104f57d:	mov    %rax,-0x18(%r14)
 104f581:	mov    %r14,0x70(%rsp)
 104f586:	mov    0x10(%rcx),%rax
 104f58a:	and    $0x3,%esi
 104f58d:	mov    (%rax),%rdx
 104f590:	cmp    %rdx,%rsi
 104f593:	jae    1051d1e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x354e>
 104f599:	mov    0x20(%rax),%rax
 104f59d:	mov    (%rax,%rsi,8),%rax
 104f5a1:	mov    (%rax),%rcx
 104f5a4:	test   %rcx,%rcx
 104f5a7:	je     104f5e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104f5a9:	mov    $0xffffffffffffffff,%r15
 104f5b0:	cmp    (%r14),%rcx
 104f5b3:	ja     104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f5b9:	mov    0x10(%r14),%ebp
 104f5bd:	test   $0x4,%bpl
 104f5c1:	jne    104f5e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe15>
 104f5c3:	lea    0x18(%r14),%rdi
 104f5c7:	testb  $0x4,0x10(%rax)
 104f5cb:	je     104f5fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe2b>
 104f5cd:	mov    0x18(%rax),%rcx
 104f5d1:	mov    0x14(%rax),%edx
 104f5d4:	add    %rcx,%rdx
 104f5d7:	add    $0x18,%rdx
 104f5db:	jmp    104f5ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe2f>
 104f5dd:	nopl   (%rax)
 104f5e0:	xor    %r15d,%r15d
 104f5e3:	jmp    104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f5e5:	mov    0x18(%r14),%rcx
 104f5e9:	mov    0x14(%r14),%edx
 104f5ed:	lea    (%rcx,%rdx,1),%rdi
 104f5f1:	add    $0x18,%rdi
 104f5f5:	testb  $0x4,0x10(%rax)
 104f5f9:	jne    104f5cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdfd>
 104f5fb:	lea    0x18(%rax),%rdx
 104f5ff:	mov    0x8(%r14),%rsi
 104f603:	mov    0x8(%rax),%rcx
 104f607:	call   1093480 <myl_native_octets_find>
 104f60c:	cmp    $0xffffffffffffffff,%rax
 104f610:	movabs $0x89705f3112a28fe5,%rdi
 104f61a:	je     104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f61c:	test   $0x1,%bpl
 104f620:	jne    104f637 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe67>
 104f622:	mov    %r14,%rdi
 104f625:	mov    %rax,%rsi
 104f628:	call   1090ec0 <index_walk>
 104f62d:	movabs $0x89705f3112a28fe5,%rdi
 104f637:	mov    %rax,%r15
 104f63a:	nopw   0x0(%rax,%rax,1)
 104f640:	mov    %r15,%r12
 104f643:	inc    %r12
 104f646:	jo     1051d26 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3556>
 104f64c:	test   %r14,%r14
 104f64f:	mov    0x10(%rsp),%rbp
 104f654:	je     104f67a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeaa>
 104f656:	movabs $0x4000000000000002,%rax
 104f660:	test   %rax,-0x10(%r14)
 104f664:	jne    104f67a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeaa>
 104f666:	mov    -0x18(%r14),%rax
 104f66a:	dec    %rax
 104f66d:	jne    104f676 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xea6>
 104f66f:	cmpq   $0x0,-0x20(%r14)
 104f674:	je     104f6c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xef5>
 104f676:	mov    %rax,-0x18(%r14)
 104f67a:	mov    %r13,%rcx
 104f67d:	add    %r12,%rcx
 104f680:	jo     104f6ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf1f>
 104f682:	mov    %rcx,%rax
 104f685:	imul   %rdi
 104f688:	add    %rcx,%rdx
 104f68b:	mov    %rdx,%rax
 104f68e:	shr    $0x3f,%rax
 104f692:	sar    $0x1d,%rdx
 104f696:	add    %rax,%rdx
 104f699:	imul   $0x3b9aca07,%rdx,%rax
 104f6a0:	sub    %rax,%rcx
 104f6a3:	mov    %rcx,%rax
 104f6a6:	sar    $0x3f,%rax
 104f6aa:	and    $0x3b9aca07,%eax
 104f6af:	add    %rcx,%rax
 104f6b2:	inc    %rbx
 104f6b5:	cmp    %rbx,0x28(%rsp)
 104f6ba:	jne    104f530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd60>
