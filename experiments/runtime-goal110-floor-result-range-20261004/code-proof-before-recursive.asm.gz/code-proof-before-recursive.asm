
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-floor-result-range-diagnostic/native-matrix/rc-v5-llvm-accounted0/before/guest:     file format elf64-x86-64


Disassembly of section .text:

0000000001020b00 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>:
 1020b00:	push   %rax
 1020b01:	cmp    %rsp,0x40(%rdi)
 1020b05:	ja     1020b75 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x75>
 1020b07:	mov    %rsi,%rax
 1020b0a:	test   %rdx,%rdx
 1020b0d:	jle    1020b73 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x73>
 1020b0f:	movabs $0x8000000000000010,%rcx
 1020b19:	cmp    %rcx,%rax
 1020b1c:	jle    1020b7a <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816+0x7a>
 1020b1e:	dec    %rdx
 1020b21:	lea    -0x11(%rax),%rcx
 1020b25:	movabs $0x89705f3112a28fe5,%rsi
 1020b2f:	mov    %rax,%r9
 1020b32:	mov    %rcx,%rax
 1020b35:	mov    %rdx,%r8
 1020b38:	imul   %rsi
 1020b3b:	lea    (%rdx,%r9,1),%rax
 1020b3f:	add    $0xffffffffffffffef,%rax
 1020b43:	mov    %rax,%rdx
 1020b46:	shr    $0x3f,%rdx
 1020b4a:	sar    $0x1d,%rax
 1020b4e:	add    %rdx,%rax
 1020b51:	imul   $0x3b9aca07,%rax,%rax
 1020b58:	sub    %rax,%rcx
 1020b5b:	mov    %rcx,%rsi
 1020b5e:	sar    $0x3f,%rsi
 1020b62:	and    $0x3b9aca07,%esi
 1020b68:	add    %rcx,%rsi
 1020b6b:	mov    %r8,%rdx
 1020b6e:	call   1020b00 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>
 1020b73:	pop    %rcx
 1020b74:	ret
 1020b75:	call   1024de0 <myl_qbe_fail_frame>
 1020b7a:	mov    $0x1,%esi
 1020b7f:	mov    $0x11,%ecx
 1020b84:	mov    %rax,%rdx
 1020b87:	call   1024d70 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
