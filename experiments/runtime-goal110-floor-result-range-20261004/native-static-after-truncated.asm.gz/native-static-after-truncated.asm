
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-floor-result-range-diagnostic/native-matrix/rc-v5-llvm-accounted0/after/guest:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
