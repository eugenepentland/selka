
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-floor-result-range-diagnostic/native-matrix/rc-v5-llvm-accounted0/before/guest:     file format elf64-x86-64


Disassembly of section .text:

000000000101fab0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 101fab0:	push   %rbp
 101fab1:	push   %r15
 101fab3:	push   %r14
 101fab5:	push   %r13
 101fab7:	push   %r12
 101fab9:	push   %rbx
 101faba:	sub    $0x58,%rsp
 101fabe:	mov    %rdx,0x20(%rsp)
 101fac3:	mov    %rdi,%rbx
 101fac6:	cmp    %rsp,0x40(%rdi)
 101faca:	ja     1020a8e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfde>
 101fad0:	mov    %rsi,%r14
 101fad3:	cmpq   $0xffffffffffffffff,0x10(%rbx)
 101fad8:	jne    102026e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7be>
 101fade:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 101fae3:	jne    10202b9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x809>
 101fae9:	cmpq   $0x0,(%r14)
 101faed:	je     1020303 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x853>
 101faf3:	mov    0x20(%r14),%rax
 101faf7:	mov    (%rax),%rsi
 101fafa:	mov    %rbx,%rdi
 101fafd:	call   1020b90 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb02:	mov    (%r14),%rdx
 101fb05:	cmp    $0x1,%rdx
 101fb09:	jbe    1020a96 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfe6>
 101fb0f:	mov    %rax,%r15
 101fb12:	mov    0x20(%r14),%rax
 101fb16:	mov    0x8(%rax),%rsi
 101fb1a:	mov    %rbx,%rdi
 101fb1d:	call   1020b90 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb22:	mov    %rax,0x8(%rsp)
 101fb27:	mov    (%r14),%rdx
 101fb2a:	cmp    $0x2,%rdx
 101fb2e:	jbe    1020aa3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xff3>
 101fb34:	mov    0x20(%r14),%rax
 101fb38:	mov    0x10(%rax),%rsi
 101fb3c:	mov    %rbx,%rdi
 101fb3f:	call   1020b90 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb44:	mov    (%r14),%rdx
 101fb47:	cmp    $0x3,%rdx
 101fb4b:	jbe    1020ab0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1000>
 101fb51:	mov    %rax,%r13
 101fb54:	mov    0x20(%r14),%rax
 101fb58:	mov    0x18(%rax),%rsi
 101fb5c:	mov    %rbx,%rdi
 101fb5f:	call   1020b90 <myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b>
 101fb64:	mov    %rax,0x50(%rsp)
 101fb69:	mov    $0x1,%edi
 101fb6e:	mov    $0x20,%esi
 101fb73:	call   1037af0 <calloc@plt>
 101fb78:	mov    %rax,%r12
 101fb7b:	test   %rax,%rax
 101fb7e:	jne    101fb88 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd8>
 101fb80:	mov    %rbx,%rdi
 101fb83:	call   1024c30 <myl_qbe_fail_allocation>
 101fb88:	mov    %r13,0x18(%rsp)
 101fb8d:	mov    %rbx,0x10(%rsp)
 101fb92:	lea    0x30(%rsp),%rdi
 101fb97:	mov    $0x18,%esi
 101fb9c:	mov    $0x1007739,%edx
 101fba1:	mov    $0x29,%ecx
 101fba6:	xor    %eax,%eax
 101fba8:	call   1037b00 <snprintf@plt>
 101fbad:	lea    0x18(%r12),%r14
 101fbb2:	test   %eax,%eax
 101fbb4:	jle    101fda7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2f7>
 101fbba:	mov    %eax,%ebp
 101fbbc:	mov    $0x40,%r13d
 101fbc2:	cmp    $0x41,%eax
 101fbc5:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fbcb:	mov    $0x80,%r13d
 101fbd1:	cmp    $0x81,%ebp
 101fbd7:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fbdd:	mov    $0x100,%r13d
 101fbe3:	cmp    $0x101,%ebp
 101fbe9:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fbef:	mov    $0x200,%r13d
 101fbf5:	cmp    $0x201,%ebp
 101fbfb:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc01:	mov    $0x400,%r13d
 101fc07:	cmp    $0x401,%ebp
 101fc0d:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc13:	mov    $0x800,%r13d
 101fc19:	cmp    $0x801,%ebp
 101fc1f:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc25:	mov    $0x1000,%r13d
 101fc2b:	cmp    $0x1001,%ebp
 101fc31:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc37:	mov    $0x2000,%r13d
 101fc3d:	cmp    $0x2001,%ebp
 101fc43:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc49:	mov    $0x4000,%r13d
 101fc4f:	cmp    $0x4001,%ebp
 101fc55:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc5b:	mov    $0x8000,%r13d
 101fc61:	cmp    $0x8001,%ebp
 101fc67:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc6d:	mov    $0x10000,%r13d
 101fc73:	cmp    $0x10001,%ebp
 101fc79:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc7f:	mov    $0x20000,%r13d
 101fc85:	cmp    $0x20001,%ebp
 101fc8b:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fc91:	mov    $0x40000,%r13d
 101fc97:	cmp    $0x40001,%ebp
 101fc9d:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fca3:	mov    $0x80000,%r13d
 101fca9:	cmp    $0x80001,%ebp
 101fcaf:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fcb5:	mov    $0x100000,%r13d
 101fcbb:	cmp    $0x100001,%ebp
 101fcc1:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fcc7:	mov    $0x200000,%r13d
 101fccd:	cmp    $0x200001,%ebp
 101fcd3:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fcd9:	mov    $0x400000,%r13d
 101fcdf:	cmp    $0x400001,%ebp
 101fce5:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fce7:	mov    $0x800000,%r13d
 101fced:	cmp    $0x800001,%ebp
 101fcf3:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fcf5:	mov    $0x1000000,%r13d
 101fcfb:	cmp    $0x1000001,%ebp
 101fd01:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd03:	mov    $0x2000000,%r13d
 101fd09:	cmp    $0x2000001,%ebp
 101fd0f:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd11:	mov    $0x4000000,%r13d
 101fd17:	cmp    $0x4000001,%ebp
 101fd1d:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd1f:	mov    $0x8000000,%r13d
 101fd25:	cmp    $0x8000001,%ebp
 101fd2b:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd2d:	mov    $0x10000000,%r13d
 101fd33:	cmp    $0x10000001,%ebp
 101fd39:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd3b:	mov    $0x20000000,%r13d
 101fd41:	cmp    $0x20000001,%ebp
 101fd47:	jb     101fd61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2b1>
 101fd49:	xor    %r13d,%r13d
 101fd4c:	cmp    $0x40000001,%ebp
 101fd52:	setae  %r13b
 101fd56:	shl    $0x1e,%r13d
 101fd5a:	add    $0x40000000,%r13
 101fd61:	mov    %r13,%rdi
 101fd64:	call   1037b10 <malloc@plt>
 101fd69:	test   %rax,%rax
 101fd6c:	je     101fde5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x335>
 101fd6e:	mov    %rax,%rbx
 101fd71:	mov    %r14,0x28(%rsp)
 101fd76:	mov    %ebp,%ebp
 101fd78:	mov    %rax,(%r12)
 101fd7c:	mov    %r13,0x10(%r12)
 101fd81:	lea    0x30(%rsp),%rsi
 101fd86:	mov    %rax,%rdi
 101fd89:	mov    %rbp,%rdx
 101fd8c:	call   1037ad0 <memcpy@plt>
 101fd91:	mov    %r12,%r14
 101fd94:	add    $0x8,%r14
 101fd98:	mov    %rbp,0x8(%r12)
 101fd9d:	cmp    %rbp,%r13
 101fda0:	jne    101fddc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x32c>
 101fda2:	add    %r13,%r13
 101fda5:	jmp    101fdbb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x30b>
 101fda7:	mov    %r14,0x28(%rsp)
 101fdac:	mov    %r12,%r14
 101fdaf:	add    $0x8,%r14
 101fdb3:	mov    $0x40,%r13d
 101fdb9:	xor    %ebx,%ebx
 101fdbb:	mov    %rbx,%rdi
 101fdbe:	mov    %r13,%rsi
 101fdc1:	call   1037b20 <realloc@plt>
 101fdc6:	test   %rax,%rax
 101fdc9:	je     101fdee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x33e>
 101fdcb:	mov    %rax,%rbx
 101fdce:	mov    %rax,(%r12)
 101fdd2:	mov    %r13,0x10(%r12)
 101fdd7:	mov    0x8(%r12),%rbp
 101fddc:	movb   $0xa,(%rbx,%rbp,1)
 101fde0:	incq   (%r14)
 101fde3:	jmp    101fdf9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x349>
 101fde5:	movl   $0x1,(%r14)
 101fdec:	jmp    101fdf9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x349>
 101fdee:	mov    0x28(%rsp),%rax
 101fdf3:	movl   $0x1,(%rax)
 101fdf9:	mov    0x10(%rsp),%rbx
 101fdfe:	mov    0x18(%rsp),%r14
 101fe03:	mov    %rbx,%rdi
 101fe06:	mov    %r12,%rsi
 101fe09:	mov    0x20(%rsp),%rdx
 101fe0e:	call   102dc00 <myl_qbe_stream_finish>
 101fe13:	cmp    $0xd,%r15
 101fe17:	ja     102005f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5af>
 101fe1d:	mov    0x50(%rsp),%r9
 101fe22:	jmp    *0x1009d70(,%r15,8)
 101fe2a:	mov    0x8(%rsp),%r15
 101fe2f:	and    $0x1,%r15d
 101fe33:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101fe38:	mov    0x8(%rsp),%rdx
 101fe3d:	mov    %rdx,%rcx
 101fe40:	add    %r14,%rcx
 101fe43:	jo     1020ae4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1034>
 101fe49:	movabs $0x5555555555555556,%rdx
 101fe53:	mov    %rcx,%rax
 101fe56:	imul   %rdx
 101fe59:	mov    %rdx,%rax
 101fe5c:	shr    $0x3f,%rax
 101fe60:	add    %rdx,%rax
 101fe63:	lea    (%rax,%rax,2),%rax
 101fe67:	sub    %rax,%rcx
 101fe6a:	mov    %rcx,%r15
 101fe6d:	sar    $0x3f,%r15
 101fe71:	and    $0x3,%r15d
 101fe75:	add    %rcx,%r15
 101fe78:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101fe7d:	xor    %ecx,%ecx
 101fe7f:	mov    0x8(%rsp),%rax
 101fe84:	mov    %rax,%rdx
 101fe87:	neg    %rdx
 101fe8a:	setno  %cl
 101fe8d:	neg    %rcx
 101fe90:	mov    %rax,%rdx
 101fe93:	or     %rcx,%rdx
 101fe96:	or     $0x1,%rcx
 101fe9a:	shr    $0x20,%rdx
 101fe9e:	je     1020431 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x981>
 101fea4:	cqto
 101fea6:	idiv   %rcx
 101fea9:	mov    %rdx,%r15
 101feac:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101feb1:	movabs $0x4000000000000001,%rcx
 101febb:	mov    0x8(%rsp),%rsi
 101fec0:	mov    %rsi,%rax
 101fec3:	imul   %rcx
 101fec6:	mov    %rdx,%rax
 101fec9:	shr    $0x3f,%rax
 101fecd:	sar    $0x3d,%rdx
 101fed1:	add    %rax,%rdx
 101fed4:	add    %rdx,%rsi
 101fed7:	shl    $0x3f,%rdx
 101fedb:	add    %rsi,%rdx
 101fede:	movabs $0x8000000000000000,%rax
 101fee8:	dec    %rax
 101feeb:	mov    %rdx,%r15
 101feee:	sar    $0x3f,%r15
 101fef2:	and    %rax,%r15
 101fef5:	add    %rdx,%r15
 101fef8:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101fefd:	lea    -0x10(%r14),%rax
 101ff01:	movabs $0xffffffffffffff1,%rcx
 101ff0b:	cmp    %rcx,%rax
 101ff0e:	jae    102030f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85f>
 101ff14:	xor    %edi,%edi
 101ff16:	movabs $0x89705f3112a28fe5,%r8
 101ff20:	mov    0x8(%rsp),%r15
 101ff25:	data16 cs nopw 0x0(%rax,%rax,1)
 101ff30:	mov    %edi,%eax
 101ff32:	and    $0x1,%eax
 101ff35:	xor    %ecx,%ecx
 101ff37:	cmp    %r9,%rax
 101ff3a:	sete   %cl
 101ff3d:	mov    %r15,%rsi
 101ff40:	add    %rcx,%rsi
 101ff43:	jo     1020a74 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfc4>
 101ff49:	mov    %rsi,%rax
 101ff4c:	imul   %r8
 101ff4f:	add    %rsi,%rdx
 101ff52:	mov    %rdx,%rax
 101ff55:	shr    $0x3f,%rax
 101ff59:	sar    $0x1d,%rdx
 101ff5d:	add    %rax,%rdx
 101ff60:	imul   $0x3b9aca07,%rdx,%rax
 101ff67:	sub    %rax,%rsi
 101ff6a:	mov    %rsi,%r15
 101ff6d:	sar    $0x3f,%r15
 101ff71:	and    $0x3b9aca07,%r15d
 101ff78:	add    %rsi,%r15
 101ff7b:	inc    %rdi
 101ff7e:	cmp    %rdi,%r14
 101ff81:	jne    101ff30 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x480>
 101ff83:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101ff88:	movabs $0x5555555555555556,%rcx
 101ff92:	mov    0x8(%rsp),%rsi
 101ff97:	mov    %rsi,%rax
 101ff9a:	imul   %rcx
 101ff9d:	mov    %rdx,%rax
 101ffa0:	shr    $0x3f,%rax
 101ffa4:	add    %rdx,%rax
 101ffa7:	lea    (%rax,%rax,2),%rax
 101ffab:	sub    %rax,%rsi
 101ffae:	mov    %rsi,%r15
 101ffb1:	sar    $0x3f,%r15
 101ffb5:	and    $0x3,%r15d
 101ffb9:	add    %rsi,%r15
 101ffbc:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 101ffc1:	movabs $0x89705f3112a28fe5,%rcx
 101ffcb:	mov    0x8(%rsp),%rsi
 101ffd0:	mov    %rsi,%rax
 101ffd3:	imul   %rcx
 101ffd6:	add    %rsi,%rdx
 101ffd9:	mov    %rdx,%rax
 101ffdc:	shr    $0x3f,%rax
 101ffe0:	sar    $0x1d,%rdx
 101ffe4:	add    %rax,%rdx
 101ffe7:	imul   $0x3b9aca07,%rdx,%rax
 101ffee:	sub    %rax,%rsi
 101fff1:	mov    %rsi,%r15
 101fff4:	sar    $0x3f,%r15
 101fff8:	and    $0x3b9aca07,%r15d
 101ffff:	add    %rsi,%r15
 1020002:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 1020007:	test   %r14,%r14
 102000a:	je     1020af1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1041>
 1020010:	movabs $0x8000000000000000,%rdx
 102001a:	mov    0x8(%rsp),%rax
 102001f:	mov    %rax,%rcx
 1020022:	xor    %rdx,%rcx
 1020025:	mov    %r14,%rsi
 1020028:	not    %rsi
 102002b:	xor    %edx,%edx
 102002d:	or     %rcx,%rsi
 1020030:	setne  %dl
 1020033:	lea    -0x2(,%rdx,2),%rcx
 102003b:	xor    %r14,%rcx
 102003e:	cqto
 1020040:	idiv   %rcx
 1020043:	mov    %rdx,%r15
 1020046:	xor    %rcx,%r15
 1020049:	sar    $0x3f,%r15
 102004d:	and    %rcx,%r15
 1020050:	test   %rdx,%rdx
 1020053:	cmove  %rdx,%r15
 1020057:	add    %rdx,%r15
 102005a:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102005f:	mov    %rbx,%rdi
 1020062:	mov    0x8(%rsp),%rsi
 1020067:	mov    %r14,%rdx
 102006a:	call   1020b00 <myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816>
 102006f:	mov    %rax,%r15
 1020072:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 1020077:	movabs $0x5555555555555556,%rcx
 1020081:	mov    0x8(%rsp),%r15
 1020086:	mov    %r15,%rax
 1020089:	imul   %rcx
 102008c:	mov    %rdx,%rax
 102008f:	shr    $0x3f,%rax
 1020093:	add    %rdx,%rax
 1020096:	lea    (%rax,%rax,2),%rax
 102009a:	sub    %rax,%r15
 102009d:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 10200a2:	movabs $0x5555555555555556,%rcx
 10200ac:	mov    0x8(%rsp),%rsi
 10200b1:	mov    %rsi,%rax
 10200b4:	imul   %rcx
 10200b7:	mov    %rdx,%rax
 10200ba:	shr    $0x3f,%rax
 10200be:	add    %rdx,%rax
 10200c1:	lea    (%rax,%rax,2),%rax
 10200c5:	sub    %rax,%rsi
 10200c8:	xor    %eax,%eax
 10200ca:	test   %rsi,%rsi
 10200cd:	setle  %al
 10200d0:	lea    (%rax,%rax,2),%rax
 10200d4:	lea    (%rax,%rsi,1),%r15
 10200d8:	add    $0xfffffffffffffffd,%r15
 10200dc:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 10200e1:	lea    -0x10(%r14),%rax
 10200e5:	movabs $0xffffffffffffff1,%rcx
 10200ef:	cmp    %rcx,%rax
 10200f2:	jae    1020388 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8d8>
 10200f8:	xor    %edi,%edi
 10200fa:	movabs $0xaaaaaaaaaaaaaaab,%r8
 1020104:	movabs $0x89705f3112a28fe5,%r9
 102010e:	xor    %r10d,%r10d
 1020111:	mov    0x8(%rsp),%r15
 1020116:	cs nopw 0x0(%rax,%rax,1)
 1020120:	mov    %rdi,%rdx
 1020123:	mulx   %r8,%rax,%rax
 1020128:	shr    $1,%rax
 102012b:	lea    (%rax,%rax,2),%rax
 102012f:	mov    $0xffffffffffffffef,%rcx
 1020136:	add    %r10,%rax
 1020139:	je     1020140 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x690>
 102013b:	mov    $0x17,%ecx
 1020140:	mov    %r15,%rsi
 1020143:	add    %rcx,%rsi
 1020146:	jo     1020a81 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfd1>
 102014c:	mov    %rsi,%rax
 102014f:	imul   %r9
 1020152:	add    %rsi,%rdx
 1020155:	mov    %rdx,%rax
 1020158:	shr    $0x3f,%rax
 102015c:	sar    $0x1d,%rdx
 1020160:	add    %rax,%rdx
 1020163:	imul   $0x3b9aca07,%rdx,%rax
 102016a:	sub    %rax,%rsi
 102016d:	mov    %rsi,%r15
 1020170:	sar    $0x3f,%r15
 1020174:	and    $0x3b9aca07,%r15d
 102017b:	add    %rsi,%r15
 102017e:	inc    %rdi
 1020181:	dec    %r10
 1020184:	dec    %r14
 1020187:	jne    1020120 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x670>
 1020189:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102018e:	lea    -0x10(%r14),%rax
 1020192:	movabs $0xffffffffffffff1,%rcx
 102019c:	cmp    %rcx,%rax
 102019f:	jae    102041e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 10201a5:	movabs $0x1ffffffffffffffe,%rcx
 10201af:	and    %r14,%rcx
 10201b2:	xor    %esi,%esi
 10201b4:	test   %r9,%r9
 10201b7:	sete   %sil
 10201bb:	xor    %r8d,%r8d
 10201be:	cmp    $0x1,%r9
 10201c2:	sete   %r8b
 10201c6:	xor    %r15d,%r15d
 10201c9:	movabs $0x89705f3112a28fe5,%rdi
 10201d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10201e0:	add    %rsi,%r15
 10201e3:	mov    %r15,%rax
 10201e6:	imul   %rdi
 10201e9:	add    %r15,%rdx
 10201ec:	mov    %rdx,%rax
 10201ef:	shr    $0x3f,%rax
 10201f3:	sar    $0x1d,%rdx
 10201f7:	add    %rax,%rdx
 10201fa:	imul   $0x3b9aca07,%rdx,%rax
 1020201:	sub    %rax,%r15
 1020204:	mov    %r15,%rax
 1020207:	sar    $0x3f,%rax
 102020b:	and    $0x3b9aca07,%eax
 1020210:	add    %r8,%r15
 1020213:	add    %rax,%r15
 1020216:	mov    %r15,%rax
 1020219:	imul   %rdi
 102021c:	add    %r15,%rdx
 102021f:	mov    %rdx,%rax
 1020222:	shr    $0x3f,%rax
 1020226:	sar    $0x1d,%rdx
 102022a:	add    %rax,%rdx
 102022d:	imul   $0x3b9aca07,%rdx,%rax
 1020234:	mov    %r15,%rdx
 1020237:	sub    %rax,%rdx
 102023a:	mov    %rdx,%r15
 102023d:	sar    $0x3f,%r15
 1020241:	and    $0x3b9aca07,%r15d
 1020248:	add    %rdx,%r15
 102024b:	add    $0xfffffffffffffffe,%rcx
 102024f:	jne    10201e0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x730>
 1020251:	test   $0x1,%r14b
 1020255:	je     1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102025b:	cmp    $0x1,%r9
 102025f:	adc    $0x0,%r15
 1020263:	mov    %r15,%rax
 1020266:	imul   %rdi
 1020269:	jmp    102050f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa5f>
 102026e:	cmpq   $0x0,0x20(%rbx)
 1020273:	jne    102029e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7ee>
 1020275:	movl   $0x1,0x39e8(%rbx)
 102027f:	vxorps %xmm0,%xmm0,%xmm0
 1020283:	vmovups %ymm0,0x39ec(%rbx)
 102028b:	vmovups %ymm0,0x39f8(%rbx)
 1020293:	movq   $0x1007552,0x3a18(%rbx)
 102029e:	mov    $0x1007a87,%esi
 10202a3:	mov    %rbx,%rdi
 10202a6:	vzeroupper
 10202a9:	call   1024580 <fail>
 10202ae:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 10202b3:	je     101fae9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x39>
 10202b9:	cmpq   $0x0,0x20(%rbx)
 10202be:	jne    10202e9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x839>
 10202c0:	movl   $0x1,0x39e8(%rbx)
 10202ca:	vxorps %xmm0,%xmm0,%xmm0
 10202ce:	vmovups %ymm0,0x39ec(%rbx)
 10202d6:	vmovups %ymm0,0x39f8(%rbx)
 10202de:	movq   $0x100759b,0x3a18(%rbx)
 10202e9:	mov    $0x1007a9c,%esi
 10202ee:	mov    %rbx,%rdi
 10202f1:	vzeroupper
 10202f4:	call   1024580 <fail>
 10202f9:	cmpq   $0x0,(%r14)
 10202fd:	jne    101faf3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43>
 1020303:	mov    %rbx,%rdi
 1020306:	xor    %esi,%esi
 1020308:	xor    %edx,%edx
 102030a:	call   1024cc0 <myl_qbe_fail_normalized_index_bounds>
 102030f:	test   %r14,%r14
 1020312:	jle    102043d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x98d>
 1020318:	xor    %edi,%edi
 102031a:	movabs $0x89705f3112a28fe5,%r8
 1020324:	mov    0x8(%rsp),%r15
 1020329:	nopl   0x0(%rax)
 1020330:	mov    %edi,%eax
 1020332:	and    $0x1,%eax
 1020335:	xor    %ecx,%ecx
 1020337:	cmp    %r9,%rax
 102033a:	sete   %cl
 102033d:	mov    %r15,%rsi
 1020340:	add    %rcx,%rsi
 1020343:	jo     1020aca <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x101a>
 1020349:	mov    %rsi,%rax
 102034c:	imul   %r8
 102034f:	add    %rsi,%rdx
 1020352:	mov    %rdx,%rax
 1020355:	shr    $0x3f,%rax
 1020359:	sar    $0x1d,%rdx
 102035d:	add    %rax,%rdx
 1020360:	imul   $0x3b9aca07,%rdx,%rax
 1020367:	sub    %rax,%rsi
 102036a:	mov    %rsi,%r15
 102036d:	sar    $0x3f,%r15
 1020371:	and    $0x3b9aca07,%r15d
 1020378:	add    %rsi,%r15
 102037b:	inc    %rdi
 102037e:	cmp    %rdi,%r14
 1020381:	jne    1020330 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x880>
 1020383:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 1020388:	test   %r14,%r14
 102038b:	jle    102043d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x98d>
 1020391:	xor    %edi,%edi
 1020393:	movabs $0xaaaaaaaaaaaaaaab,%r8
 102039d:	movabs $0x89705f3112a28fe5,%r9
 10203a7:	xor    %r10d,%r10d
 10203aa:	mov    0x8(%rsp),%r15
 10203af:	nop
 10203b0:	mov    %rdi,%rdx
 10203b3:	mulx   %r8,%rax,%rax
 10203b8:	shr    $1,%rax
 10203bb:	lea    (%rax,%rax,2),%rax
 10203bf:	mov    $0xffffffffffffffef,%rcx
 10203c6:	add    %r10,%rax
 10203c9:	je     10203d0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x920>
 10203cb:	mov    $0x17,%ecx
 10203d0:	mov    %r15,%rsi
 10203d3:	add    %rcx,%rsi
 10203d6:	jo     1020ad7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1027>
 10203dc:	mov    %rsi,%rax
 10203df:	imul   %r9
 10203e2:	add    %rsi,%rdx
 10203e5:	mov    %rdx,%rax
 10203e8:	shr    $0x3f,%rax
 10203ec:	sar    $0x1d,%rdx
 10203f0:	add    %rax,%rdx
 10203f3:	imul   $0x3b9aca07,%rdx,%rax
 10203fa:	sub    %rax,%rsi
 10203fd:	mov    %rsi,%r15
 1020400:	sar    $0x3f,%r15
 1020404:	and    $0x3b9aca07,%r15d
 102040b:	add    %rsi,%r15
 102040e:	inc    %rdi
 1020411:	dec    %r10
 1020414:	dec    %r14
 1020417:	jne    10203b0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x900>
 1020419:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102041e:	test   %r14,%r14
 1020421:	jle    1020447 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x997>
 1020423:	cmp    $0x1,%r14
 1020427:	jne    102044f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x99f>
 1020429:	xor    %r15d,%r15d
 102042c:	jmp    10204f7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa47>
 1020431:	xor    %edx,%edx
 1020433:	div    %ecx
 1020435:	mov    %edx,%r15d
 1020438:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102043d:	mov    0x8(%rsp),%r15
 1020442:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 1020447:	xor    %r15d,%r15d
 102044a:	jmp    1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 102044f:	movabs $0x8000000000000000,%rcx
 1020459:	add    $0xfffffffffffffffe,%rcx
 102045d:	and    %r14,%rcx
 1020460:	xor    %esi,%esi
 1020462:	test   %r9,%r9
 1020465:	sete   %sil
 1020469:	xor    %edi,%edi
 102046b:	cmp    $0x1,%r9
 102046f:	sete   %dil
 1020473:	xor    %r15d,%r15d
 1020476:	movabs $0x89705f3112a28fe5,%r8
 1020480:	add    %rsi,%r15
 1020483:	mov    %r15,%rax
 1020486:	imul   %r8
 1020489:	add    %r15,%rdx
 102048c:	mov    %rdx,%rax
 102048f:	shr    $0x3f,%rax
 1020493:	sar    $0x1d,%rdx
 1020497:	add    %rax,%rdx
 102049a:	imul   $0x3b9aca07,%rdx,%rax
 10204a1:	sub    %rax,%r15
 10204a4:	mov    %r15,%rax
 10204a7:	sar    $0x3f,%rax
 10204ab:	and    $0x3b9aca07,%eax
 10204b0:	add    %rdi,%r15
 10204b3:	add    %rax,%r15
 10204b6:	mov    %r15,%rax
 10204b9:	imul   %r8
 10204bc:	add    %r15,%rdx
 10204bf:	mov    %rdx,%rax
 10204c2:	shr    $0x3f,%rax
 10204c6:	sar    $0x1d,%rdx
 10204ca:	add    %rax,%rdx
 10204cd:	imul   $0x3b9aca07,%rdx,%rax
 10204d4:	mov    %r15,%rdx
 10204d7:	sub    %rax,%rdx
 10204da:	mov    %rdx,%r15
 10204dd:	sar    $0x3f,%r15
 10204e1:	and    $0x3b9aca07,%r15d
 10204e8:	add    %rdx,%r15
 10204eb:	add    $0xfffffffffffffffe,%rcx
 10204ef:	jne    1020480 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9d0>
 10204f1:	test   $0x1,%r14b
 10204f5:	je     1020539 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa89>
 10204f7:	cmp    $0x1,%r9
 10204fb:	adc    $0x0,%r15
 10204ff:	movabs $0x89705f3112a28fe5,%rcx
 1020509:	mov    %r15,%rax
 102050c:	imul   %rcx
 102050f:	add    %r15,%rdx
 1020512:	mov    %rdx,%rax
 1020515:	shr    $0x3f,%rax
 1020519:	sar    $0x1d,%rdx
 102051d:	add    %rax,%rdx
 1020520:	imul   $0x3b9aca07,%rdx,%rax
 1020527:	sub    %rax,%r15
 102052a:	mov    %r15,%rax
 102052d:	sar    $0x3f,%rax
 1020531:	and    $0x3b9aca07,%eax
 1020536:	add    %rax,%r15
 1020539:	mov    $0x1,%edi
 102053e:	mov    $0x20,%esi
 1020543:	call   1037af0 <calloc@plt>
 1020548:	mov    %rax,%r14
 102054b:	test   %rax,%rax
 102054e:	jne    1020558 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaa8>
 1020550:	mov    %rbx,%rdi
 1020553:	call   1024c30 <myl_qbe_fail_allocation>
 1020558:	lea    0x30(%rsp),%rdi
 102055d:	mov    $0x18,%esi
 1020562:	mov    $0x1007739,%edx
 1020567:	mov    %r15,%rcx
 102056a:	xor    %eax,%eax
 102056c:	call   1037b00 <snprintf@plt>
 1020571:	lea    0x18(%r14),%r12
 1020575:	test   %eax,%eax
 1020577:	jle    102077a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcca>
 102057d:	mov    %eax,%ebp
 102057f:	mov    $0x40,%r15d
 1020585:	cmp    $0x41,%eax
 1020588:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102058e:	mov    $0x80,%r15d
 1020594:	cmp    $0x81,%ebp
 102059a:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205a0:	mov    $0x100,%r15d
 10205a6:	cmp    $0x101,%ebp
 10205ac:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205b2:	mov    $0x200,%r15d
 10205b8:	cmp    $0x201,%ebp
 10205be:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205c4:	mov    $0x400,%r15d
 10205ca:	cmp    $0x401,%ebp
 10205d0:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205d6:	mov    $0x800,%r15d
 10205dc:	cmp    $0x801,%ebp
 10205e2:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205e8:	mov    $0x1000,%r15d
 10205ee:	cmp    $0x1001,%ebp
 10205f4:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10205fa:	mov    $0x2000,%r15d
 1020600:	cmp    $0x2001,%ebp
 1020606:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102060c:	mov    $0x4000,%r15d
 1020612:	cmp    $0x4001,%ebp
 1020618:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102061e:	mov    $0x8000,%r15d
 1020624:	cmp    $0x8001,%ebp
 102062a:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 1020630:	mov    $0x10000,%r15d
 1020636:	cmp    $0x10001,%ebp
 102063c:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 1020642:	mov    $0x20000,%r15d
 1020648:	cmp    $0x20001,%ebp
 102064e:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 1020654:	mov    $0x40000,%r15d
 102065a:	cmp    $0x40001,%ebp
 1020660:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 1020666:	mov    $0x80000,%r15d
 102066c:	cmp    $0x80001,%ebp
 1020672:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 1020678:	mov    $0x100000,%r15d
 102067e:	cmp    $0x100001,%ebp
 1020684:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102068a:	mov    $0x200000,%r15d
 1020690:	cmp    $0x200001,%ebp
 1020696:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102069c:	mov    $0x400000,%r15d
 10206a2:	cmp    $0x400001,%ebp
 10206a8:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206aa:	mov    $0x800000,%r15d
 10206b0:	cmp    $0x800001,%ebp
 10206b6:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206b8:	mov    $0x1000000,%r15d
 10206be:	cmp    $0x1000001,%ebp
 10206c4:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206c6:	mov    $0x2000000,%r15d
 10206cc:	cmp    $0x2000001,%ebp
 10206d2:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206d4:	mov    $0x4000000,%r15d
 10206da:	cmp    $0x4000001,%ebp
 10206e0:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206e2:	mov    $0x8000000,%r15d
 10206e8:	cmp    $0x8000001,%ebp
 10206ee:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206f0:	mov    $0x10000000,%r15d
 10206f6:	cmp    $0x10000001,%ebp
 10206fc:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 10206fe:	mov    $0x20000000,%r15d
 1020704:	cmp    $0x20000001,%ebp
 102070a:	jb     1020724 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc74>
 102070c:	xor    %r15d,%r15d
 102070f:	cmp    $0x40000001,%ebp
 1020715:	setae  %r15b
 1020719:	shl    $0x1e,%r15d
 102071d:	add    $0x40000000,%r15
 1020724:	mov    %r15,%rdi
 1020727:	call   1037b10 <malloc@plt>
 102072c:	test   %rax,%rax
 102072f:	je     10207a3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcf3>
 1020731:	mov    %ebp,%ebx
 1020733:	mov    %rax,(%r14)
 1020736:	mov    %r15,0x10(%r14)
 102073a:	lea    0x30(%rsp),%rsi
 102073f:	mov    %rax,%rbp
 1020742:	mov    %rax,%rdi
 1020745:	mov    %rbx,%rdx
 1020748:	call   1037ad0 <memcpy@plt>
 102074d:	mov    %r14,%r13
 1020750:	add    $0x8,%r13
 1020754:	mov    %rbx,0x8(%r14)
 1020758:	cmp    %rbx,%r15
 102075b:	jne    10207ad <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcfd>
 102075d:	add    %r15,%r15
 1020760:	mov    %rbp,%rdi
 1020763:	mov    %r15,%rsi
 1020766:	call   1037b20 <realloc@plt>
 102076b:	test   %rax,%rax
 102076e:	jne    1020796 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xce6>
 1020770:	movl   $0x1,(%r12)
 1020778:	jmp    10207b8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd08>
 102077a:	mov    %r14,%r13
 102077d:	add    $0x8,%r13
 1020781:	mov    $0x40,%r15d
 1020787:	xor    %edi,%edi
 1020789:	mov    %r15,%rsi
 102078c:	call   1037b20 <realloc@plt>
 1020791:	test   %rax,%rax
 1020794:	je     1020770 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcc0>
 1020796:	mov    %rax,(%r14)
 1020799:	mov    %r15,0x10(%r14)
 102079d:	mov    0x8(%r14),%rbx
 10207a1:	jmp    10207b0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd00>
 10207a3:	movl   $0x1,(%r12)
 10207ab:	jmp    10207bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd0d>
 10207ad:	mov    %rbp,%rax
 10207b0:	movb   $0xa,(%rax,%rbx,1)
 10207b4:	incq   0x0(%r13)
 10207b8:	mov    0x10(%rsp),%rbx
 10207bd:	mov    %rbx,%rdi
 10207c0:	mov    %r14,%rsi
 10207c3:	mov    0x20(%rsp),%rdx
 10207c8:	call   102dc00 <myl_qbe_stream_finish>
 10207cd:	mov    $0x1,%edi
 10207d2:	mov    $0x20,%esi
 10207d7:	call   1037af0 <calloc@plt>
 10207dc:	mov    %rax,%r14
 10207df:	test   %rax,%rax
 10207e2:	jne    10207ec <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd3c>
 10207e4:	mov    %rbx,%rdi
 10207e7:	call   1024c30 <myl_qbe_fail_allocation>
 10207ec:	lea    0x30(%rsp),%rdi
 10207f1:	mov    $0x18,%esi
 10207f6:	mov    $0x1007739,%edx
 10207fb:	mov    $0x2b,%ecx
 1020800:	xor    %eax,%eax
 1020802:	call   1037b00 <snprintf@plt>
 1020807:	lea    0x18(%r14),%r12
 102080b:	test   %eax,%eax
 102080d:	jle    1020a10 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf60>
 1020813:	mov    %eax,%ebp
 1020815:	mov    $0x40,%r15d
 102081b:	cmp    $0x41,%eax
 102081e:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020824:	mov    $0x80,%r15d
 102082a:	cmp    $0x81,%ebp
 1020830:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020836:	mov    $0x100,%r15d
 102083c:	cmp    $0x101,%ebp
 1020842:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020848:	mov    $0x200,%r15d
 102084e:	cmp    $0x201,%ebp
 1020854:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102085a:	mov    $0x400,%r15d
 1020860:	cmp    $0x401,%ebp
 1020866:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102086c:	mov    $0x800,%r15d
 1020872:	cmp    $0x801,%ebp
 1020878:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102087e:	mov    $0x1000,%r15d
 1020884:	cmp    $0x1001,%ebp
 102088a:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020890:	mov    $0x2000,%r15d
 1020896:	cmp    $0x2001,%ebp
 102089c:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208a2:	mov    $0x4000,%r15d
 10208a8:	cmp    $0x4001,%ebp
 10208ae:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208b4:	mov    $0x8000,%r15d
 10208ba:	cmp    $0x8001,%ebp
 10208c0:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208c6:	mov    $0x10000,%r15d
 10208cc:	cmp    $0x10001,%ebp
 10208d2:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208d8:	mov    $0x20000,%r15d
 10208de:	cmp    $0x20001,%ebp
 10208e4:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208ea:	mov    $0x40000,%r15d
 10208f0:	cmp    $0x40001,%ebp
 10208f6:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10208fc:	mov    $0x80000,%r15d
 1020902:	cmp    $0x80001,%ebp
 1020908:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102090e:	mov    $0x100000,%r15d
 1020914:	cmp    $0x100001,%ebp
 102091a:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020920:	mov    $0x200000,%r15d
 1020926:	cmp    $0x200001,%ebp
 102092c:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020932:	mov    $0x400000,%r15d
 1020938:	cmp    $0x400001,%ebp
 102093e:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020940:	mov    $0x800000,%r15d
 1020946:	cmp    $0x800001,%ebp
 102094c:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102094e:	mov    $0x1000000,%r15d
 1020954:	cmp    $0x1000001,%ebp
 102095a:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102095c:	mov    $0x2000000,%r15d
 1020962:	cmp    $0x2000001,%ebp
 1020968:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 102096a:	mov    $0x4000000,%r15d
 1020970:	cmp    $0x4000001,%ebp
 1020976:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020978:	mov    $0x8000000,%r15d
 102097e:	cmp    $0x8000001,%ebp
 1020984:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020986:	mov    $0x10000000,%r15d
 102098c:	cmp    $0x10000001,%ebp
 1020992:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 1020994:	mov    $0x20000000,%r15d
 102099a:	cmp    $0x20000001,%ebp
 10209a0:	jb     10209ba <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf0a>
 10209a2:	xor    %r15d,%r15d
 10209a5:	cmp    $0x40000001,%ebp
 10209ab:	setae  %r15b
 10209af:	shl    $0x1e,%r15d
 10209b3:	add    $0x40000000,%r15
 10209ba:	mov    %r15,%rdi
 10209bd:	call   1037b10 <malloc@plt>
 10209c2:	test   %rax,%rax
 10209c5:	je     1020a39 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf89>
 10209c7:	mov    %ebp,%ebx
 10209c9:	mov    %rax,(%r14)
 10209cc:	mov    %r15,0x10(%r14)
 10209d0:	lea    0x30(%rsp),%rsi
 10209d5:	mov    %rax,%rbp
 10209d8:	mov    %rax,%rdi
 10209db:	mov    %rbx,%rdx
 10209de:	call   1037ad0 <memcpy@plt>
 10209e3:	mov    %r14,%r13
 10209e6:	add    $0x8,%r13
 10209ea:	mov    %rbx,0x8(%r14)
 10209ee:	cmp    %rbx,%r15
 10209f1:	jne    1020a43 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf93>
 10209f3:	add    %r15,%r15
 10209f6:	mov    %rbp,%rdi
 10209f9:	mov    %r15,%rsi
 10209fc:	call   1037b20 <realloc@plt>
 1020a01:	test   %rax,%rax
 1020a04:	jne    1020a2c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf7c>
 1020a06:	movl   $0x1,(%r12)
 1020a0e:	jmp    1020a4e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf9e>
 1020a10:	mov    %r14,%r13
 1020a13:	add    $0x8,%r13
 1020a17:	mov    $0x40,%r15d
 1020a1d:	xor    %edi,%edi
 1020a1f:	mov    %r15,%rsi
 1020a22:	call   1037b20 <realloc@plt>
 1020a27:	test   %rax,%rax
 1020a2a:	je     1020a06 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf56>
 1020a2c:	mov    %rax,(%r14)
 1020a2f:	mov    %r15,0x10(%r14)
 1020a33:	mov    0x8(%r14),%rbx
 1020a37:	jmp    1020a46 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf96>
 1020a39:	movl   $0x1,(%r12)
 1020a41:	jmp    1020a53 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfa3>
 1020a43:	mov    %rbp,%rax
 1020a46:	movb   $0xa,(%rax,%rbx,1)
 1020a4a:	incq   0x0(%r13)
 1020a4e:	mov    0x10(%rsp),%rbx
 1020a53:	mov    %rbx,%rdi
 1020a56:	mov    %r14,%rsi
 1020a59:	mov    0x20(%rsp),%rdx
 1020a5e:	call   102dc00 <myl_qbe_stream_finish>
 1020a63:	xor    %eax,%eax
 1020a65:	add    $0x58,%rsp
 1020a69:	pop    %rbx
 1020a6a:	pop    %r12
 1020a6c:	pop    %r13
 1020a6e:	pop    %r14
 1020a70:	pop    %r15
 1020a72:	pop    %rbp
 1020a73:	ret
 1020a74:	mov    %rbx,%rdi
 1020a77:	xor    %esi,%esi
 1020a79:	mov    %r15,%rdx
 1020a7c:	call   1024d70 <myl_qbe_fail_overflow_op>
 1020a81:	mov    %rbx,%rdi
 1020a84:	xor    %esi,%esi
 1020a86:	mov    %r15,%rdx
 1020a89:	call   1024d70 <myl_qbe_fail_overflow_op>
 1020a8e:	mov    %rbx,%rdi
 1020a91:	call   1024de0 <myl_qbe_fail_frame>
 1020a96:	mov    $0x1,%esi
 1020a9b:	mov    %rbx,%rdi
 1020a9e:	call   1024cc0 <myl_qbe_fail_normalized_index_bounds>
 1020aa3:	mov    $0x2,%esi
 1020aa8:	mov    %rbx,%rdi
 1020aab:	call   1024cc0 <myl_qbe_fail_normalized_index_bounds>
 1020ab0:	mov    $0x3,%esi
 1020ab5:	mov    %rbx,%rdi
 1020ab8:	call   1024cc0 <myl_qbe_fail_normalized_index_bounds>
 1020abd:	mov    %rbx,%rdi
 1020ac0:	mov    0x8(%rsp),%rsi
 1020ac5:	call   1024d20 <myl_qbe_fail_division>
 1020aca:	mov    %rbx,%rdi
 1020acd:	xor    %esi,%esi
 1020acf:	mov    %r15,%rdx
 1020ad2:	call   1024d70 <myl_qbe_fail_overflow_op>
 1020ad7:	mov    %rbx,%rdi
 1020ada:	xor    %esi,%esi
 1020adc:	mov    %r15,%rdx
 1020adf:	call   1024d70 <myl_qbe_fail_overflow_op>
 1020ae4:	mov    %rbx,%rdi
 1020ae7:	xor    %esi,%esi
 1020ae9:	mov    %r14,%rcx
 1020aec:	call   1024d70 <myl_qbe_fail_overflow_op>
 1020af1:	mov    %rbx,%rdi
 1020af4:	mov    0x8(%rsp),%rsi
 1020af9:	call   1024d20 <myl_qbe_fail_division>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
