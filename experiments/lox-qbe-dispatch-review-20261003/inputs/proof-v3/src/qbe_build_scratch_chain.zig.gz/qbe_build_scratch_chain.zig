//! QBE-only decision trees entering existing, proved private-scratch comparisons.
//! Original comparison blocks, true predecessors and false suffixes are retained.
const std = @import("std");
const il = @import("qbe_build_llvm_il.zig");
const cells = @import("qbe_build_scratch_cells.zig");
const Allocator = std.mem.Allocator;
const Instruction = il.Instruction;
const Block = il.Block;
const Error = cells.Error;
const max_nodes = 32;
const max_chains = 8;
const namespace = "qbe_dispatch_";

const Node = struct {
    block: usize,
    selector: []const u8,
    scratch: [2][]const u8,
    constant: i64,
    temps: [5][]const u8,
};
const Incoming = struct { predecessor: usize, is_false: bool, instruction: ?*Instruction };
const Chain = struct { nodes: []Node, incoming: *Instruction };
const Plan = struct {
    arena: Allocator,
    function: *const il.Function,
    facts: cells.Facts,
    labels: std.StringHashMapUnmanaged(usize) = .empty,
    nodes: []?Node,
    incoming: []std.ArrayList(Incoming),
    chains: std.ArrayList(Chain) = .empty,
};

/// Transform only QBE's missed member text. Unsupported or unproved units keep
/// their exact bytes; allocations are released with the caller's unit scratch.
pub fn transform(allocator: Allocator, source: []const u8) error{OutOfMemory}![]const u8 {
    if (source.len > 2 * 1024 * 1024 or std.mem.indexOf(u8, source, namespace) != null) return source;
    if (std.mem.indexOf(u8, source, "=l ceql ") == null) return source;
    var arena: std.heap.ArenaAllocator = .init(allocator);
    defer arena.deinit();
    return transformed(allocator, arena.allocator(), source) catch |err| switch (err) {
        error.Declined => source,
        error.OutOfMemory => error.OutOfMemory,
    };
}

fn transformed(output: Allocator, arena: Allocator, source: []const u8) Error![]const u8 {
    var diagnostic: il.Diagnostic = .{};
    const unit = il.parse(arena, source, &diagnostic) catch |err| switch (err) {
        error.TranslationFailed => return error.Declined,
        error.OutOfMemory => return error.OutOfMemory,
    };
    var plan = try prepare(arena, &unit.function);
    try findChains(&plan);
    if (plan.chains.items.len == 0) return source;
    return render(output, &plan, source);
}

fn prepare(arena: Allocator, function: *const il.Function) Error!Plan {
    const blocks = function.blocks.items;
    if (blocks.len == 0 or blocks.len > 8192) return error.Declined;
    if (!stops(blocks[blocks.len - 1].terminator())) return error.Declined;
    var plan: Plan = .{ .arena = arena, .function = function, .facts = try cells.Facts.collect(arena, function), .nodes = try arena.alloc(?Node, blocks.len), .incoming = try arena.alloc(std.ArrayList(Incoming), blocks.len) };
    @memset(plan.incoming, .empty);
    for (blocks, plan.nodes, 0..) |block, *node, index| {
        for (block.instructions.items, 0..) |instruction, at| {
            if (stops(instruction) and at + 1 != block.instructions.items.len) return error.Declined;
        }
        const entry = try plan.labels.getOrPut(arena, block.label);
        if (entry.found_existing) return error.Declined;
        entry.value_ptr.* = index;
        node.* = pattern(block, index);
    }
    for (blocks, 0..) |block, index| try edges(&plan, block, index);
    return plan;
}

fn stops(instruction: ?*Instruction) bool {
    const last = instruction orelse return false;
    return switch (last.opcode) {
        .jmp, .jnz, .ret, .hlt => true,
        else => false,
    };
}

fn edges(plan: *Plan, block: *Block, index: usize) Error!void {
    const last = block.terminator();
    if (last) |instruction| switch (instruction.extra) {
        .label => |label| try edge(plan, label, .{ .predecessor = index, .is_false = false, .instruction = instruction }),
        .branch => |labels| {
            try edge(plan, labels[0], .{ .predecessor = index, .is_false = false, .instruction = instruction });
            try edge(plan, labels[1], .{ .predecessor = index, .is_false = true, .instruction = instruction });
        },
        else => {},
    };
    if (!stops(last) and index + 1 < plan.nodes.len) try plan.incoming[index + 1].append(plan.arena, .{ .predecessor = index, .is_false = false, .instruction = null });
}

fn edge(plan: *Plan, label: []const u8, incoming: Incoming) Error!void {
    const index = plan.labels.get(label) orelse return error.Declined;
    try plan.incoming[index].append(plan.arena, incoming);
}

fn load(instruction: *Instruction, name: []const u8) ?[]const u8 {
    if (instruction.opcode != .loadl or !cells.letter(instruction, "l") or instruction.args.len != 1) return null;
    if (!cells.isTemp(instruction.args[0], name)) return null;
    return instruction.dest;
}

fn store(instruction: *Instruction, name: []const u8) bool {
    return instruction.opcode == .storel and instruction.dest == null and instruction.args.len == 2 and cells.isTemp(instruction.args[1], name);
}

fn pattern(block: *Block, index: usize) ?Node {
    const ins = block.instructions.items;
    if (ins.len != 9 or ins[0].args.len != 1) return null;
    const selector = ins[0].args[0].tempName() orelse return null;
    const first = load(ins[0], selector) orelse return null;
    if (ins[1].args.len != 2 or ins[2].args.len != 2) return null;
    const scratch0 = ins[1].args[1].tempName() orelse return null;
    const scratch1 = ins[2].args[1].tempName() orelse return null;
    if (!store(ins[1], scratch0) or !cells.isTemp(ins[1].args[0], first)) return null;
    if (!store(ins[2], scratch1)) return null;
    const constant = cells.integer(ins[2].args[0]) orelse return null;
    const literal = load(ins[3], scratch1) orelse return null;
    const selected = load(ins[4], scratch0) orelse return null;
    if (ins[5].opcode != .ceql or !cells.letter(ins[5], "l") or ins[5].args.len != 2) return null;
    if (!cells.isTemp(ins[5].args[0], selected) or !cells.isTemp(ins[5].args[1], literal)) return null;
    const compared = ins[5].dest orelse return null;
    if (!store(ins[6], scratch0) or !cells.isTemp(ins[6].args[0], compared)) return null;
    const tested = load(ins[7], scratch0) orelse return null;
    if (ins[8].opcode != .jnz or ins[8].dest != null or ins[8].args.len != 1 or ins[8].extra != .branch) return null;
    if (!cells.isTemp(ins[8].args[0], tested)) return null;
    return .{ .block = index, .selector = selector, .scratch = .{ scratch0, scratch1 }, .constant = constant, .temps = .{ first, literal, selected, compared, tested } };
}

fn next(plan: *const Plan, node: Node) usize {
    const terminator = plan.function.blocks.items[node.block].terminator().?;
    return plan.labels.get(terminator.extra.branch[1]).?;
}

fn findChains(plan: *Plan) Error!void {
    const continued = try plan.arena.alloc(bool, plan.nodes.len);
    @memset(continued, false);
    for (plan.nodes) |possible| if (possible) |node| {
        continued[next(plan, node)] = true;
    };
    for (plan.nodes, continued) |possible, continuation| {
        const head = possible orelse continue;
        if (continuation) continue;
        if (plan.chains.items.len == max_chains) break;
        if (try chain(plan, head)) |found| try plan.chains.append(plan.arena, found);
    }
}

fn chain(plan: *Plan, head: Node) Error!?Chain {
    var found: std.ArrayList(Node) = .empty;
    var cursor = head.block;
    while (plan.nodes[cursor]) |node| {
        if (found.items.len == max_nodes) return null;
        for (found.items) |prior| if (prior.block == cursor) return null;
        try found.append(plan.arena, node);
        cursor = next(plan, node);
    }
    if (found.items.len < 4 or !sameCells(head)) return null;
    const entries = plan.incoming[head.block].items;
    if (entries.len != 1 or !entries[0].is_false) return null;
    for (found.items, 0..) |node, index| {
        if (!validNode(plan, node, head)) return null;
        if (index == 0) continue;
        if (node.constant <= found.items[index - 1].constant) return null;
        const predecessors = plan.incoming[node.block].items;
        if (predecessors.len != 1 or !predecessors[0].is_false or predecessors[0].predecessor != found.items[index - 1].block) return null;
    }
    for (found.items) |node| if (node.block == entries[0].predecessor) return null;
    return .{ .nodes = found.items, .incoming = entries[0].instruction.? };
}

fn sameCells(node: Node) bool {
    return !std.mem.eql(u8, node.selector, node.scratch[0]) and !std.mem.eql(u8, node.selector, node.scratch[1]) and !std.mem.eql(u8, node.scratch[0], node.scratch[1]);
}

fn validNode(plan: *Plan, node: Node, head: Node) bool {
    if (!std.mem.eql(u8, node.selector, head.selector)) return false;
    for (node.scratch, head.scratch) |actual, expected| if (!std.mem.eql(u8, actual, expected)) return false;
    for (node.temps) |name| if (!plan.facts.single(name)) return false;
    return plan.facts.privateCell(node.selector) and plan.facts.privateCell(node.scratch[0]) and plan.facts.privateCell(node.scratch[1]);
}

fn render(allocator: Allocator, plan: *const Plan, source: []const u8) Error![]const u8 {
    var result: std.Io.Writer.Allocating = .init(allocator);
    errdefer result.deinit();
    var line: usize = 0;
    var split = std.mem.splitScalar(u8, source, '\n');
    var closed = false;
    while (split.next()) |original| {
        line += 1;
        if (line > plan.function.line and std.mem.eql(u8, il.strip(original), "}")) {
            if (closed) return error.Declined;
            closed = true;
            try decisions(&result.writer, plan);
        }
        if (closed and std.mem.indexOf(u8, original, "function ") != null) return error.Declined;
        try rewrittenLine(&result.writer, plan, original, line);
        if (split.index != null) result.writer.writeByte('\n') catch return error.OutOfMemory;
    }
    if (!closed) return error.Declined;
    return result.toOwnedSlice();
}

fn rewrittenLine(writer: *std.Io.Writer, plan: *const Plan, original: []const u8, line: usize) Error!void {
    for (plan.chains.items, 0..) |found, index| {
        if (found.incoming.line != line) continue;
        const before_comment = original[0 .. std.mem.indexOfScalar(u8, original, '#') orelse original.len];
        const label = found.incoming.extra.branch[1];
        const at = std.mem.lastIndexOf(u8, before_comment, label) orelse return error.Declined;
        writer.print("{s}@{s}{d}_0_{d}{s}", .{ original[0..at], namespace, index, found.nodes.len, original[at + label.len ..] }) catch return error.OutOfMemory;
        return;
    }
    writer.writeAll(original) catch return error.OutOfMemory;
}

fn decisions(writer: *std.Io.Writer, plan: *const Plan) Error!void {
    for (plan.chains.items, 0..) |found, index| {
        writer.writeAll(" # QBE-SCRATCH-CHAIN-1 original comparison leaves retained\n") catch return error.OutOfMemory;
        try decision(writer, plan, found.nodes, .{ .number = index, .first = 0, .last = found.nodes.len });
    }
}

const Range = struct { number: usize, first: usize, last: usize };
fn decision(writer: *std.Io.Writer, plan: *const Plan, nodes: []const Node, range: Range) Error!void {
    if (range.last - range.first < 2) return;
    writer.print("@{s}{d}_{d}_{d}\n", .{ namespace, range.number, range.first, range.last }) catch return error.OutOfMemory;
    if (range.first == 0 and range.last == nodes.len) writer.print(" %{s}{d}_selector =l loadl %{s}\n", .{ namespace, range.number, nodes[0].selector }) catch return error.OutOfMemory;
    const middle = range.first + (range.last - range.first) / 2;
    const compare = " %{s}{d}_{d}_{d}_test =w csltl %{s}{d}_selector, {d}\n jnz %{s}{d}_{d}_{d}_test, ";
    writer.print(compare, .{ namespace, range.number, range.first, range.last, namespace, range.number, nodes[middle].constant, namespace, range.number, range.first, range.last }) catch return error.OutOfMemory;
    try target(writer, plan, nodes, .{ .number = range.number, .first = range.first, .last = middle });
    writer.writeAll(", ") catch return error.OutOfMemory;
    try target(writer, plan, nodes, .{ .number = range.number, .first = middle, .last = range.last });
    writer.writeByte('\n') catch return error.OutOfMemory;
    try decision(writer, plan, nodes, .{ .number = range.number, .first = range.first, .last = middle });
    try decision(writer, plan, nodes, .{ .number = range.number, .first = middle, .last = range.last });
}

fn target(writer: *std.Io.Writer, plan: *const Plan, nodes: []const Node, range: Range) Error!void {
    if (range.last - range.first == 1) {
        writer.writeAll(plan.function.blocks.items[nodes[range.first].block].label) catch return error.OutOfMemory;
    } else writer.print("@{s}{d}_{d}_{d}", .{ namespace, range.number, range.first, range.last }) catch return error.OutOfMemory;
}
