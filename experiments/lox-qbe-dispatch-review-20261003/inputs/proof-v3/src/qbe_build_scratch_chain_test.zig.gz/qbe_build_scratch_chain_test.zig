//! Refusal and actual native equivalence probes for private-scratch dispatch.
const std = @import("std");
const pass = @import("qbe_build_scratch_chain.zig");
const fs = @import("qbe_build_io.zig");
const bundled = @import("qbe_build_assets");
const t = std.testing;
const boundaries = [_]i64{ std.math.minInt(i64), -7, 10, std.math.maxInt(i64) };

fn fixture(a: std.mem.Allocator, constants: []const i64) ![]const u8 {
    var out: std.Io.Writer.Allocating = .init(a);
    errdefer out.deinit();
    try out.writer.writeAll("export function l $dispatch(l %input) {\n@start\n %selector =l alloc8 8\n %scratch0 =l alloc8 8\n" ++
        " %scratch1 =l alloc8 8\n %other =l alloc8 8\n storel %input, %selector\n storel 0, %scratch0\n storel 0, %scratch1\n" ++
        " %enter =l copy 0\n jnz %enter, @bypass, @case0\n");
    const comparison = "@case{d}\n %a{d} =l loadl %selector\n storel %a{d}, %scratch0\n storel {d}, %scratch1\n" ++
        " %b{d} =l loadl %scratch1\n %c{d} =l loadl %scratch0\n %d{d} =l ceql %c{d}, %b{d}\n" ++
        " storel %d{d}, %scratch0\n %e{d} =l loadl %scratch0\n jnz %e{d}, @hit{d}, ";
    for (constants, 0..) |constant, i| {
        try out.writer.print(comparison, .{ i, i, i, constant, i, i, i, i, i, i, i, i, i });
        if (i + 1 < constants.len) try out.writer.print("@case{d}\n", .{i + 1}) else try out.writer.writeAll("@default\n");
    }
    for (constants, 0..) |_, i| {
        try out.writer.print("@hit{d}\n %p{d} =l phi @case{d} 1\n %h{d} =l loadl %scratch0\n %k{d} =l loadl %scratch1\n %r{d} =l xor %h{d}, %k{d}\n %f{d} =l xor %r{d}, %p{d}\n ret %f{d}\n", .{ i, i, i, i, i, i, i, i, i, i, i, i });
    }
    try out.writer.writeAll("@bypass\n ret 0\n@default\n %dh =l loadl %scratch0\n %dk =l loadl %scratch1\n %dr =l xor %dh, %dk\n ret %dr\n}\n");
    return out.toOwnedSlice();
}

// spec: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 native cells retain comparison leaves PHI predecessors and default suffix" {
    var arena: std.heap.ArenaAllocator = .init(t.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const original = try fixture(a, &boundaries);
    const candidate = try pass.transform(a, original);
    try t.expect(candidate.ptr != original.ptr);
    try preservedLeaves(a, original, candidate);
    try t.expect(std.mem.indexOf(u8, candidate, "jnz %enter, @bypass, @qbe_dispatch_0_0_4") != null);
    try t.expect(std.mem.indexOf(u8, candidate, "csltl %qbe_dispatch_0_selector, 10") != null);
    try t.expectEqualStrings(candidate, try pass.transform(a, candidate));
}

fn preservedLeaves(a: std.mem.Allocator, original: []const u8, candidate: []const u8) !void {
    for (0..4) |i| {
        const label = try std.fmt.allocPrint(a, "\n@case{d}\n", .{i});
        const start = std.mem.indexOf(u8, original, label).? + 1;
        const end = std.mem.indexOfPos(u8, original, start + label.len, "\n@").?;
        try t.expect(std.mem.indexOf(u8, candidate, original[start..end]) != null);
        const phi = try std.fmt.allocPrint(a, " =l phi @case{d} 1", .{i});
        try t.expect(std.mem.indexOf(u8, candidate, phi) != null);
    }
}

const Replacement = struct { before: []const u8, after: []const u8 };

fn refusal(replacement: Replacement) !void {
    var arena: std.heap.ArenaAllocator = .init(t.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const source = try fixture(a, &boundaries);
    try t.expect(std.mem.indexOf(u8, source, replacement.before) != null);
    const input = try std.mem.replaceOwned(u8, a, source, replacement.before, replacement.after);
    const output = try pass.transform(a, input);
    try t.expectEqualStrings(input, output);
    try t.expectEqual(input.ptr, output.ptr);
}

fn refusals(replacements: []const Replacement) !void {
    for (replacements) |replacement| try refusal(replacement);
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 escaped arithmetic stored indirect and phi cell addresses refuse" {
    try refusals(&.{
        .{ .before = " %enter =l copy 0", .after = " %escaped =l call $observe(l %scratch0)\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " %alias =l add %scratch0, 0\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " storel %scratch0, %other\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " %escaped =l call %scratch0()\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " %alias =l phi @start %scratch0\n %enter =l copy 0" },
    });
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 invalid storage widths aliases and ambiguous temporaries refuse" {
    try refusals(&.{
        .{ .before = "%scratch1", .after = "%scratch0" },
        .{ .before = "%scratch0 =l alloc8 8", .after = "%scratch0 =l alloc8 16" },
        .{ .before = "%d0 =l ceql", .after = "%d0 =w ceqw" },
        .{ .before = "@hit0\n", .after = "@hit0\n %extra =l copy %a0\n" },
        .{ .before = " %enter =l copy 0", .after = " %a0 =l copy 5\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " %alias =l copy %scratch0\n storel %alias, %other\n %enter =l copy 0" },
    });
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 effects selector writes foreign entries and unordered constants refuse" {
    try refusals(&.{
        .{ .before = "@case1\n", .after = "@case1\n call $callback()\n" },
        .{ .before = "@case1\n", .after = "@case1\n storel 0, %selector\n" },
        .{ .before = "@case1\n", .after = "@case1\n %join =l phi @case0 1\n" },
        .{ .before = "jnz %enter, @bypass, @case0", .after = "jnz %enter, @case1, @case0" },
        .{ .before = "storel -7, %scratch1", .after = "storel 10, %scratch1" },
        .{ .before = "storel -7, %scratch1", .after = "storel -9223372036854775808, %scratch1" },
        .{ .before = "@case1\n", .after = "@case1\n dbgloc 55\n" },
        .{ .before = "@case1\n", .after = "@case1\n call $myl_qbe_tick()\n" },
    });
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 bounded readonly copy alias is private but subsequent escape refuses" {
    var arena: std.heap.ArenaAllocator = .init(t.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const original = try fixture(a, &boundaries);
    const input = try std.mem.replaceOwned(u8, a, original, " %enter =l copy 0", " %alias =l copy %scratch0\n %observed =w loadub %alias\n %enter =l copy 0");
    try t.expect(std.mem.indexOf(u8, try pass.transform(a, input), "# QBE-SCRATCH-CHAIN-1") != null);
    try refusal(.{ .before = " %enter =l copy 0", .after = " %alias =l copy %scratch0\n %observed =w loadub %alias\n call $observe(l %alias)\n %enter =l copy 0" });
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 malformed input reserved names and overlong chains remain original" {
    try refusals(&.{
        .{ .before = " %enter =l copy 0", .after = " # qbe_dispatch_0 collision\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " malformed instruction\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " jmp @case2\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " jnz %input, @case2, @case0\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " ret 0\n %enter =l copy 0" },
        .{ .before = " %enter =l copy 0", .after = " hlt\n %enter =l copy 0" },
        .{ .before = "jnz %e3, @hit3, @default", .after = "jnz %e3, @hit3, @missing" },
    });
    try overlong();
}

fn overlong() !void {
    var constants: [33]i64 = undefined;
    for (&constants, 0..) |*value, index| value.* = @intCast(index);
    const original = try fixture(t.allocator, &constants);
    defer t.allocator.free(original);
    try t.expectEqualStrings(original, try pass.transform(t.allocator, original));
}

fn nativeOutputs(a: std.mem.Allocator, original: []const u8) ![]const u8 {
    var source = try std.mem.replaceOwned(u8, a, original, "$dispatch(l %input)", "$dispatch(l %input, l %out)");
    for (0..4) |index| {
        const before = try std.fmt.allocPrint(a, " ret %f{d}\n", .{index});
        const after = try std.fmt.allocPrint(a, " storel %h{d}, %out\n %out1_{d} =l add %out, 8\n storel %k{d}, %out1_{d}\n" ++
            " %saved_{d} =l loadl %selector\n %out2_{d} =l add %out, 16\n storel %saved_{d}, %out2_{d}\n ret %f{d}\n", .{ index, index, index, index, index, index, index, index, index });
        source = try std.mem.replaceOwned(u8, a, source, before, after);
    }
    return std.mem.replaceOwned(u8, a, source, " ret %dr\n", " storel %dh, %out\n %dout1 =l add %out, 8\n storel %dk, %dout1\n" ++
        " %dsaved =l loadl %selector\n %dout2 =l add %out, 16\n storel %dsaved, %dout2\n ret %dr\n");
}

fn native() !void {
    var environment: std.process.Environ.Map = .init(t.allocator);
    defer environment.deinit();
    var context = try fs.Context.init(t.allocator, t.io, &environment);
    defer context.deinit();
    const a = context.allocator;
    var directory = t.tmpDir(.{});
    defer directory.cleanup();
    const root = try directory.dir.realPathFileAlloc(t.io, ".", a);
    const original = try nativeOutputs(a, try fixture(a, &boundaries));
    const candidate = try pass.transform(a, original);
    try t.expect(std.mem.indexOf(u8, candidate, "# QBE-SCRATCH-CHAIN-1") != null);
    const source = try std.fs.path.join(a, &.{ root, "probe.ssa" });
    const assembly = try std.fs.path.join(a, &.{ root, "probe.s" });
    const harness = try std.fs.path.join(a, &.{ root, "probe.c" });
    const binary = try std.fs.path.join(a, &.{ root, "probe" });
    const control = try std.mem.replaceOwned(u8, a, original, "$dispatch(", "$control(");
    try context.write(source, try std.mem.concat(a, u8, &.{ control, candidate }));
    try context.write(harness, "#include <stdint.h>\n#include <limits.h>\n#include <assert.h>\nextern int64_t control(int64_t,int64_t*);extern int64_t dispatch(int64_t,int64_t*);\n" ++
        "int main(void){int64_t v[]={INT64_MIN,INT64_MIN+1,-8,-7,-6,-1,0,1,9,10,11,INT64_MAX-1,INT64_MAX};\n" ++
        "for(unsigned i=0;i<sizeof(v)/sizeof(v[0]);i++){int found=v[i]==INT64_MIN||v[i]==-7||v[i]==10||v[i]==INT64_MAX;\n" ++
        "int64_t want=found?v[i]:INT64_MAX,c[3]={99,99,99},d[3]={88,88,88};assert(control(v[i],c)==want);assert(dispatch(v[i],d)==want);\n" ++
        "assert(c[0]==found);assert(d[0]==found);assert(c[1]==want);assert(d[1]==want);assert(c[2]==v[i]);assert(d[2]==v[i]);}\nreturn 0;}\n");
    const qbe = t.environ.getPosix("MYLANG_QBE") orelse return error.ToolNotFound;
    const zig = t.environ.getPosix("MYLANG_ZIG") orelse return error.ToolNotFound;
    try context.command(&.{ qbe, "-o", assembly, source }, null);
    try context.command(&.{ zig, "cc", "-O2", "-UNDEBUG", "-fsanitize=undefined", harness, assembly, "-o", binary }, null);
    try context.command(&.{binary}, null);
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 actual QBE native signed endpoints holes scratch outputs and PHIs agree" {
    try native();
}

// spec-case: QBE-SCRATCH-CHAIN-1
test "QBE-SCRATCH-CHAIN-1 downstream pass and cell proof participate in native driver identity" {
    try t.expect(named(&bundled.driver_inputs, "qbe_build_scratch_chain.zig"));
    try t.expect(named(&bundled.driver_inputs, "qbe_build_scratch_cells.zig"));
    try t.expect(!named(&bundled.driver_inputs, "qbe_build_scratch_chain_test.zig"));
}

fn named(paths: []const []const u8, name: []const u8) bool {
    for (paths) |path| if (std.mem.eql(u8, path, name)) return true;
    return false;
}
