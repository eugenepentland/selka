
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/span-run/trees-llvm-after-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101a430 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 101a430:	push   %rbp
 101a431:	push   %r15
 101a433:	push   %r14
 101a435:	push   %r13
 101a437:	push   %r12
 101a439:	push   %rbx
 101a43a:	sub    $0x108,%rsp
 101a441:	mov    %rdi,%rbx
 101a444:	cmp    %rsp,0x40(%rdi)
 101a448:	ja     101aa78 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x648>
 101a44e:	mov    %rsi,%r15
 101a451:	test   %rsi,%rsi
 101a454:	je     101aa1a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ea>
 101a45a:	mov    0x2c8(%rbx),%ebp
 101a460:	vxorps %xmm0,%xmm0,%xmm0
 101a464:	vmovups %ymm0,0x10(%rsp)
 101a46a:	movq   $0x1009be8,0x80(%rsp)
 101a476:	movl   $0x0,0x98(%rsp)
 101a481:	lea    0x40(%rsp),%rax
 101a486:	mov    %rax,0x88(%rsp)
 101a48e:	lea    0x10(%rsp),%rax
 101a493:	mov    %rax,0x90(%rsp)
 101a49b:	movq   $0x1009be8,0xa0(%rsp)
 101a4a7:	movl   $0x0,0xb8(%rsp)
 101a4b2:	lea    0x50(%rsp),%rax
 101a4b7:	mov    %rax,0xa8(%rsp)
 101a4bf:	lea    0x18(%rsp),%rax
 101a4c4:	mov    %rax,0xb0(%rsp)
 101a4cc:	movq   $0x1009be8,0xc0(%rsp)
 101a4d8:	movl   $0x0,0xd8(%rsp)
 101a4e3:	mov    %rsp,%rax
 101a4e6:	mov    %rax,0xc8(%rsp)
 101a4ee:	lea    0x20(%rsp),%rax
 101a4f3:	mov    %rax,0xd0(%rsp)
 101a4fb:	movq   $0x1009be8,0xe0(%rsp)
 101a507:	movl   $0x0,0xf8(%rsp)
 101a512:	lea    0x100(%rsp),%rax
 101a51a:	mov    %rax,0xe8(%rsp)
 101a522:	lea    0x28(%rsp),%r13
 101a527:	mov    %r13,0xf0(%rsp)
 101a52f:	test   %rbx,%rbx
 101a532:	je     101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a538:	mov    0x1860(%rbx),%rax
 101a53f:	test   %rax,%rax
 101a542:	je     101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a548:	mov    0x3d80(%rbx),%rcx
 101a54f:	mov    0x70(%rax),%rax
 101a553:	mov    %rcx,0x60(%rsp)
 101a558:	lea    0x80(%rsp),%rcx
 101a560:	mov    %rcx,0x68(%rsp)
 101a565:	movq   $0x4,0x70(%rsp)
 101a56e:	mov    %rax,0x78(%rsp)
 101a573:	lea    0x60(%rsp),%r12
 101a578:	mov    %r12,0x3d80(%rbx)
 101a57f:	mov    %r15,%rax
 101a582:	neg    %rax
 101a585:	jo     101aa80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x650>
 101a58b:	dec    %r15
 101a58e:	mov    %rbx,%rdi
 101a591:	mov    %r15,%rsi
 101a594:	vzeroupper
 101a597:	call   101a430 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a59c:	mov    %rax,(%rsp)
 101a5a0:	mov    %rdx,0x8(%rsp)
 101a5a5:	movq   $0x100a308,0xc0(%rsp)
 101a5b1:	movl   $0x2,0xd8(%rsp)
 101a5bc:	mov    %rax,0x40(%rsp)
 101a5c1:	mov    %rdx,0x48(%rsp)
 101a5c6:	movq   $0x100a308,0x80(%rsp)
 101a5d2:	movl   $0x2,0x98(%rsp)
 101a5dd:	movl   $0x0,0x20(%rsp)
 101a5e5:	movl   $0x1,0x10(%rsp)
 101a5ed:	cmpq   $0x0,0x1860(%rbx)
 101a5f5:	je     101aa68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x638>
 101a5fb:	lea    0x258(%rbx),%r14
 101a602:	mov    0x2c8(%rbx),%ecx
 101a608:	mov    $0x10098b8,%esi
 101a60d:	mov    $0x1,%edx
 101a612:	mov    %r14,%rdi
 101a615:	call   1029a70 <myl_rc_storage_alloc>
 101a61a:	test   %rax,%rax
 101a61d:	je     101aa68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x638>
 101a623:	vmovups 0x40(%rsp),%xmm0
 101a629:	vmovups %xmm0,(%rax)
 101a62d:	mov    %rax,0x40(%rsp)
 101a632:	movq   $0x1009fd8,0x80(%rsp)
 101a63e:	movl   $0x2,0x98(%rsp)
 101a649:	movl   $0x1,0x10(%rsp)
 101a651:	movl   $0x0,0x28(%rsp)
 101a659:	mov    %rbx,%rdi
 101a65c:	mov    %r15,%rsi
 101a65f:	call   101a430 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a664:	mov    %rax,(%rsp)
 101a668:	mov    %rdx,0x8(%rsp)
 101a66d:	movq   $0x100a308,0xc0(%rsp)
 101a679:	movl   $0x2,0xd8(%rsp)
 101a684:	mov    %rax,0x50(%rsp)
 101a689:	mov    %rdx,0x58(%rsp)
 101a68e:	movq   $0x100a308,0xa0(%rsp)
 101a69a:	movl   $0x2,0xb8(%rsp)
 101a6a5:	movl   $0x0,0x20(%rsp)
 101a6ad:	movl   $0x1,0x18(%rsp)
 101a6b5:	cmpq   $0x0,0x1860(%rbx)
 101a6bd:	je     101aa70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x640>
 101a6c3:	mov    0x2c8(%rbx),%ecx
 101a6c9:	mov    $0x10098b8,%esi
 101a6ce:	mov    $0x1,%edx
 101a6d3:	mov    %r14,%rdi
 101a6d6:	call   1029a70 <myl_rc_storage_alloc>
 101a6db:	test   %rax,%rax
 101a6de:	je     101aa70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x640>
 101a6e4:	vmovups 0x50(%rsp),%xmm0
 101a6ea:	vmovups %xmm0,(%rax)
 101a6ee:	mov    %rax,0x50(%rsp)
 101a6f3:	movq   $0x1009fd8,0xa0(%rsp)
 101a6ff:	movl   $0x2,0xb8(%rsp)
 101a70a:	movl   $0x1,0x18(%rsp)
 101a712:	mov    0x10(%rsp),%edx
 101a716:	mov    0x98(%rsp),%ecx
 101a71d:	cmp    $0x2,%ecx
 101a720:	setne  %sil
 101a724:	test   $0x1,%dl
 101a727:	sete   %dil
 101a72b:	or     %sil,%dil
 101a72e:	je     101a84b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x41b>
 101a734:	test   $0x1,%dl
 101a737:	sete   %dl
 101a73a:	vxorps %xmm0,%xmm0,%xmm0
 101a73e:	vmovaps %xmm0,0x30(%rsp)
 101a744:	movq   $0x100a308,0xe0(%rsp)
 101a750:	movl   $0x2,0xf8(%rsp)
 101a75b:	lea    0x30(%rsp),%rsi
 101a760:	mov    %rsi,0xe8(%rsp)
 101a768:	mov    %r13,0xf0(%rsp)
 101a770:	movl   $0x1,0x28(%rsp)
 101a778:	test   $0x18,%cl
 101a77b:	setne  %cl
 101a77e:	or     %dl,%cl
 101a780:	je     101a857 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x427>
 101a786:	mov    %rsp,%rdx
 101a789:	lea    0x40(%rsp),%rcx
 101a78e:	mov    $0x1009fd8,%esi
 101a793:	mov    %r14,%rdi
 101a796:	mov    %ebp,%r8d
 101a799:	call   102b1d0 <myl_rc_native_retain>
 101a79e:	test   %eax,%eax
 101a7a0:	je     101a8fe <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4ce>
 101a7a6:	movq   $0x1009fd8,0xc0(%rsp)
 101a7b2:	movl   $0x2,0xd8(%rsp)
 101a7bd:	movl   $0x1,0x20(%rsp)
 101a7c5:	cmpl   $0x0,0x10(%rsp)
 101a7ca:	je     101a7dc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3ac>
 101a7cc:	lea    0x80(%rsp),%rsi
 101a7d4:	mov    %rbx,%rdi
 101a7d7:	call   101cef0 <myl_qbe_rc_slot_drop>
 101a7dc:	mov    (%rsp),%rax
 101a7e0:	mov    %rax,0x30(%rsp)
 101a7e5:	movl   $0x0,0x20(%rsp)
 101a7ed:	testb  $0x18,0xb8(%rsp)
 101a7f5:	mov    0x50(%rsp),%rax
 101a7fa:	jne    101a805 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d5>
 101a7fc:	mov    0x18(%rsp),%ecx
 101a800:	and    $0x1,%ecx
 101a803:	jne    101a869 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 101a805:	test   %rax,%rax
 101a808:	je     101a932 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x502>
 101a80e:	movabs $0x5000000000000001,%rcx
 101a818:	test   %rcx,-0x10(%rax)
 101a81c:	je     101a932 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x502>
 101a822:	mov    %rsp,%rdx
 101a825:	lea    0x50(%rsp),%rcx
 101a82a:	mov    $0x1009fd8,%esi
 101a82f:	mov    %r14,%rdi
 101a832:	mov    %ebp,%r8d
 101a835:	call   102ac60 <myl_rc_native_take>
 101a83a:	test   %eax,%eax
 101a83c:	je     101aa30 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x600>
 101a842:	mov    (%rsp),%rax
 101a846:	jmp    101a93f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x50f>
 101a84b:	mov    0x40(%rsp),%rcx
 101a850:	mov    %rcx,0x30(%rsp)
 101a855:	jmp    101a869 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 101a857:	mov    0x40(%rsp),%rcx
 101a85c:	mov    %rcx,0x30(%rsp)
 101a861:	movl   $0x0,0x10(%rsp)
 101a869:	mov    %rax,0x38(%rsp)
 101a86e:	movl   $0x0,0x18(%rsp)
 101a876:	vmovaps 0x30(%rsp),%xmm0
 101a87c:	vmovaps %xmm0,0x40(%rsp)
 101a882:	movq   $0x100a308,0x80(%rsp)
 101a88e:	movl   $0x2,0x98(%rsp)
 101a899:	movl   $0x0,0x28(%rsp)
 101a8a1:	vmovaps %xmm0,(%rsp)
 101a8a6:	movl   $0x0,0x10(%rsp)
 101a8ae:	cmp    %r12,0x3d80(%rbx)
 101a8b5:	jne    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a8bb:	mov    0x1860(%rbx),%rax
 101a8c2:	test   %rax,%rax
 101a8c5:	je     101a8d7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4a7>
 101a8c7:	mov    0x70(%rax),%rax
 101a8cb:	cmp    0x78(%rsp),%rax
 101a8d0:	je     101a8e4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4b4>
 101a8d2:	jmp    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a8d7:	xor    %eax,%eax
 101a8d9:	cmp    0x78(%rsp),%rax
 101a8de:	jne    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a8e4:	mov    0x60(%rsp),%rax
 101a8e9:	mov    %rax,0x3d80(%rbx)
 101a8f0:	mov    (%rsp),%rax
 101a8f4:	mov    0x8(%rsp),%rdx
 101a8f9:	jmp    101aa1e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ee>
 101a8fe:	mov    0x1860(%rbx),%rcx
 101a905:	test   %rcx,%rcx
 101a908:	je     101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a90e:	mov    0x78(%rcx),%eax
 101a911:	movl   $0x0,0x78(%rcx)
 101a918:	test   %rax,%rax
 101a91b:	je     101a989 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x559>
 101a91d:	cmp    $0x1,%eax
 101a920:	jne    101a970 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x540>
 101a922:	mov    $0x100745e,%esi
 101a927:	cmpl   $0x0,0x2c4(%rbx)
 101a92e:	jne    101a981 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x551>
 101a930:	jmp    101a979 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x549>
 101a932:	mov    %rax,(%rsp)
 101a936:	movq   $0x0,0x50(%rsp)
 101a93f:	movl   $0x0,0x18(%rsp)
 101a947:	movq   $0x1009fd8,0xc0(%rsp)
 101a953:	movl   $0x2,0xd8(%rsp)
 101a95e:	mov    %rax,0x38(%rsp)
 101a963:	movl   $0x0,0x20(%rsp)
 101a96b:	jmp    101a876 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x446>
 101a970:	cmp    $0x4,%eax
 101a973:	jae    101aa63 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x633>
 101a979:	mov    0x100d470(,%rax,8),%rsi
 101a981:	mov    %rbx,%rdi
 101a984:	call   101da80 <fail>
 101a989:	cmp    %r12,0x3d80(%rbx)
 101a990:	jne    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a996:	mov    0x78(%rsp),%rsi
 101a99b:	mov    %r14,%rdi
 101a99e:	call   10277d0 <myl_rc_scope_unwind>
 101a9a3:	mov    0x70(%rsp),%r14
 101a9a8:	test   %r14,%r14
 101a9ab:	je     101a9ea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ba>
 101a9ad:	mov    %r14,%r15
 101a9b0:	shl    $0x5,%r15
 101a9b4:	add    $0xffffffffffffffe0,%r15
 101a9b8:	jmp    101a9d4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5a4>
 101a9ba:	nopw   0x0(%rax,%rax,1)
 101a9c0:	add    %r15,%rsi
 101a9c3:	mov    %rbx,%rdi
 101a9c6:	call   101cef0 <myl_qbe_rc_slot_drop>
 101a9cb:	add    $0xffffffffffffffe0,%r15
 101a9cf:	dec    %r14
 101a9d2:	je     101a9ea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ba>
 101a9d4:	mov    0x68(%rsp),%rsi
 101a9d9:	mov    0x10(%rsi,%r15,1),%rax
 101a9de:	test   %rax,%rax
 101a9e1:	je     101a9c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x590>
 101a9e3:	cmpl   $0x0,(%rax)
 101a9e6:	jne    101a9c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x590>
 101a9e8:	jmp    101a9cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x59b>
 101a9ea:	cmp    %r12,0x3d80(%rbx)
 101a9f1:	jne    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101a9f3:	mov    0x1860(%rbx),%rax
 101a9fa:	test   %rax,%rax
 101a9fd:	je     101aa05 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d5>
 101a9ff:	mov    0x70(%rax),%rax
 101aa03:	jmp    101aa07 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d7>
 101aa05:	xor    %eax,%eax
 101aa07:	cmp    0x78(%rsp),%rax
 101aa0c:	jne    101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101aa0e:	mov    0x60(%rsp),%rax
 101aa13:	mov    %rax,0x3d80(%rbx)
 101aa1a:	xor    %eax,%eax
 101aa1c:	xor    %edx,%edx
 101aa1e:	add    $0x108,%rsp
 101aa25:	pop    %rbx
 101aa26:	pop    %r12
 101aa28:	pop    %r13
 101aa2a:	pop    %r14
 101aa2c:	pop    %r15
 101aa2e:	pop    %rbp
 101aa2f:	ret
 101aa30:	mov    0x1860(%rbx),%rax
 101aa37:	test   %rax,%rax
 101aa3a:	je     101aa5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62b>
 101aa3c:	mov    0x78(%rax),%esi
 101aa3f:	movl   $0x0,0x78(%rax)
 101aa46:	mov    %rbx,%rdi
 101aa49:	call   101ce60 <myl_qbe_rc_status>
 101aa4e:	cmp    %r12,0x3d80(%rbx)
 101aa55:	je     101a996 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x566>
 101aa5b:	vzeroupper
 101aa5e:	call   1023371 <myl_rc_invariant_failed>
 101aa63:	call   102ea30 <abort@plt>
 101aa68:	mov    %rbx,%rdi
 101aa6b:	call   101e130 <myl_qbe_fail_allocation>
 101aa70:	mov    %rbx,%rdi
 101aa73:	call   101e130 <myl_qbe_fail_allocation>
 101aa78:	mov    %rbx,%rdi
 101aa7b:	call   101e230 <myl_qbe_fail_frame>
 101aa80:	movabs $0x8000000000000000,%rdx
 101aa8a:	mov    $0x1,%esi
 101aa8f:	mov    $0x1,%ecx
 101aa94:	mov    %rbx,%rdi
 101aa97:	vzeroupper
 101aa9a:	call   101e1c0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
