
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/span-run/trees-qbe-after-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001012940 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1012940:	endbr64
 1012944:	push   %rbp
 1012945:	mov    %rsp,%rbp
 1012948:	sub    $0x178,%rsp
 101294f:	push   %rbx
 1012950:	push   %r12
 1012952:	push   %r13
 1012954:	push   %r14
 1012956:	push   %r15
 1012958:	mov    %rsi,%r13
 101295b:	mov    0x40(%rdi),%rax
 101295f:	lea    -0x18(%rbp),%rcx
 1012963:	cmp    %rax,%rcx
 1012966:	jb     1013230 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8f0>
 101296c:	cmp    $0x0,%r13
 1012970:	je     1013201 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c1>
 1012976:	mov    %rdi,%rbx
 1012979:	call   10194d0 <myl_qbe_heap>
 101297e:	mov    %rbx,%rdi
 1012981:	mov    %rax,%rbx
 1012984:	mov    %rdi,%r12
 1012987:	call   101b810 <myl_qbe_region_mark>
 101298c:	mov    %r13,%rdx
 101298f:	mov    %r12,%rdi
 1012992:	mov    %rax,-0x10(%rbp)
 1012996:	mov    %rdx,%r13
 1012999:	mov    $0x20,%edx
 101299e:	mov    $0x0,%esi
 10129a3:	mov    %rdi,%r12
 10129a6:	lea    -0xa0(%rbp),%rdi
 10129ad:	call   10299a0 <compiler_rt.fastMemset>
 10129b2:	mov    %r13,%rdx
 10129b5:	mov    %r12,%rdi
 10129b8:	lea    -0xe627(%rip),%rax        # 1004398 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10129bf:	mov    %rax,-0x120(%rbp)
 10129c6:	movl   $0x0,-0x108(%rbp)
 10129d0:	lea    -0x80(%rbp),%rax
 10129d4:	mov    %rax,-0x118(%rbp)
 10129db:	lea    -0xa0(%rbp),%rax
 10129e2:	mov    %rax,-0x110(%rbp)
 10129e9:	lea    -0xe658(%rip),%rax        # 1004398 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10129f0:	mov    %rax,-0x100(%rbp)
 10129f7:	movl   $0x0,-0xe8(%rbp)
 1012a01:	lea    -0x70(%rbp),%rax
 1012a05:	mov    %rax,-0xf8(%rbp)
 1012a0c:	lea    -0xa0(%rbp),%rax
 1012a13:	add    $0x8,%rax
 1012a17:	mov    %rax,-0xf0(%rbp)
 1012a1e:	lea    -0xe68d(%rip),%rax        # 1004398 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012a25:	mov    %rax,-0xe0(%rbp)
 1012a2c:	movl   $0x0,-0xc8(%rbp)
 1012a36:	lea    -0x60(%rbp),%rax
 1012a3a:	mov    %rax,-0xd8(%rbp)
 1012a41:	lea    -0xa0(%rbp),%rax
 1012a48:	add    $0x10,%rax
 1012a4c:	mov    %rax,-0xd0(%rbp)
 1012a53:	lea    -0xe6c2(%rip),%rax        # 1004398 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012a5a:	mov    %rax,-0xc0(%rbp)
 1012a61:	movl   $0x0,-0xa8(%rbp)
 1012a6b:	lea    -0x50(%rbp),%rax
 1012a6f:	mov    %rax,-0xb8(%rbp)
 1012a76:	lea    -0xa0(%rbp),%rax
 1012a7d:	mov    %rax,%r13
 1012a80:	add    $0x18,%r13
 1012a84:	mov    %r13,-0xb0(%rbp)
 1012a8b:	mov    $0x4,%ecx
 1012a90:	mov    %rdx,%r12
 1012a93:	lea    -0x120(%rbp),%rdx
 1012a9a:	lea    -0x140(%rbp),%rsi
 1012aa1:	mov    %rdi,%r14
 1012aa4:	call   1018be0 <myl_qbe_rc_frame_enter>
 1012aa9:	mov    %r14,%rdi
 1012aac:	mov    %r12,-0x48(%rbp)
 1012ab0:	movq   $0x1,-0x40(%rbp)
 1012ab8:	movabs $0x8000000000000001,%rax
 1012ac2:	cmp    %rax,%r12
 1012ac5:	jl     10131e7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8a7>
 1012acb:	mov    %r12,%rsi
 1012ace:	sub    $0x1,%rsi
 1012ad2:	mov    %rsi,-0x48(%rbp)
 1012ad6:	mov    %rsi,%r15
 1012ad9:	mov    %rdi,%r14
 1012adc:	call   1012940 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012ae1:	mov    %r15,%rsi
 1012ae4:	mov    %r14,%rdi
 1012ae7:	mov    %rax,%rcx
 1012aea:	mov    %rdx,%rax
 1012aed:	mov    %r12,%rdx
 1012af0:	mov    %rcx,-0x170(%rbp)
 1012af7:	mov    %rax,-0x168(%rbp)
 1012afe:	lea    -0x170(%rbp),%rax
 1012b05:	mov    %rax,-0x48(%rbp)
 1012b09:	mov    -0x170(%rbp),%rax
 1012b10:	mov    %rax,-0x60(%rbp)
 1012b14:	mov    -0x168(%rbp),%rax
 1012b1b:	mov    %rax,-0x58(%rbp)
 1012b1f:	lea    0x1b41a(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012b26:	mov    %rax,-0xe0(%rbp)
 1012b2d:	movl   $0x2,-0xc8(%rbp)
 1012b37:	movl   $0x1,-0x90(%rbp)
 1012b41:	mov    -0x60(%rbp),%rax
 1012b45:	mov    %rax,-0x80(%rbp)
 1012b49:	mov    -0x58(%rbp),%rax
 1012b4d:	mov    %rax,-0x78(%rbp)
 1012b51:	lea    0x1b3e8(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012b58:	mov    %rax,-0x120(%rbp)
 1012b5f:	movl   $0x2,-0x108(%rbp)
 1012b69:	movl   $0x2,-0x108(%rbp)
 1012b73:	movl   $0x0,-0x90(%rbp)
 1012b7d:	movl   $0x1,-0xa0(%rbp)
 1012b87:	lea    -0x80(%rbp),%rax
 1012b8b:	mov    %rax,-0x48(%rbp)
 1012b8f:	mov    %rdx,%r15
 1012b92:	mov    $0x1,%edx
 1012b97:	mov    %rsi,%r14
 1012b9a:	lea    0x1b08f(%rip),%rsi        # 102dc30 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012ba1:	mov    %rdi,%r12
 1012ba4:	mov    %rbx,%rdi
 1012ba7:	call   101dbb0 <myl_native_heap_alloc>
 1012bac:	mov    %r15,%rdx
 1012baf:	mov    %r14,%rsi
 1012bb2:	mov    %r12,%rdi
 1012bb5:	cmp    $0x0,%eax
 1012bb8:	jne    1012bc1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x281>
 1012bba:	call   1019250 <myl_qbe_fail_allocation>
 1012bbf:	ud2
 1012bc1:	mov    -0x48(%rbp),%rcx
 1012bc5:	mov    (%rcx),%r8
 1012bc8:	mov    %r8,(%rax)
 1012bcb:	mov    0x8(%rcx),%rcx
 1012bcf:	mov    %rcx,0x8(%rax)
 1012bd3:	movl   $0x0,-0xa0(%rbp)
 1012bdd:	mov    %rax,-0x48(%rbp)
 1012be1:	mov    -0x48(%rbp),%rcx
 1012be5:	mov    %rcx,-0x80(%rbp)
 1012be9:	lea    0x1b0b0(%rip),%rcx        # 102dca0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012bf0:	mov    %rcx,-0x120(%rbp)
 1012bf7:	movl   $0x2,-0x108(%rbp)
 1012c01:	movl   $0x1,-0xa0(%rbp)
 1012c0b:	mov    %rax,-0x48(%rbp)
 1012c0f:	movl   $0x0,-0x88(%rbp)
 1012c19:	mov    %rdx,%r15
 1012c1c:	mov    $0x8,%edx
 1012c21:	mov    %rsi,%r14
 1012c24:	mov    $0x0,%esi
 1012c29:	mov    %rdi,%r12
 1012c2c:	lea    -0x38(%rbp),%rdi
 1012c30:	call   10299a0 <compiler_rt.fastMemset>
 1012c35:	mov    %r15,%rdx
 1012c38:	mov    %r14,%rsi
 1012c3b:	mov    %r12,%rdi
 1012c3e:	mov    -0x10(%rbp),%r15
 1012c42:	mov    -0x48(%rbp),%rax
 1012c46:	mov    %rax,-0x38(%rbp)
 1012c4a:	movl   $0x0,-0xa0(%rbp)
 1012c54:	lea    -0x38(%rbp),%rax
 1012c58:	mov    %rax,-0x48(%rbp)
 1012c5c:	mov    -0x38(%rbp),%rax
 1012c60:	mov    %rax,-0x80(%rbp)
 1012c64:	lea    0x1b265(%rip),%rax        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012c6b:	mov    %rax,-0x120(%rbp)
 1012c72:	movl   $0x2,-0x108(%rbp)
 1012c7c:	movl   $0x1,-0xa0(%rbp)
 1012c86:	lea    -0x80(%rbp),%rax
 1012c8a:	mov    %rax,-0x48(%rbp)
 1012c8e:	movl   $0x0,-0x88(%rbp)
 1012c98:	mov    %rdx,-0x40(%rbp)
 1012c9c:	mov    %rsi,-0x40(%rbp)
 1012ca0:	mov    %rdi,%r12
 1012ca3:	call   1012940 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012ca8:	mov    %r12,%rdi
 1012cab:	mov    %rax,%rcx
 1012cae:	mov    %rdx,%rax
 1012cb1:	mov    %rcx,-0x160(%rbp)
 1012cb8:	mov    %rax,-0x158(%rbp)
 1012cbf:	lea    -0x160(%rbp),%rax
 1012cc6:	mov    %rax,-0x40(%rbp)
 1012cca:	mov    -0x160(%rbp),%rax
 1012cd1:	mov    %rax,-0x60(%rbp)
 1012cd5:	mov    -0x158(%rbp),%rax
 1012cdc:	mov    %rax,-0x58(%rbp)
 1012ce0:	lea    0x1b259(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012ce7:	mov    %rax,-0xe0(%rbp)
 1012cee:	movl   $0x2,-0xc8(%rbp)
 1012cf8:	movl   $0x1,-0x90(%rbp)
 1012d02:	mov    -0x60(%rbp),%rax
 1012d06:	mov    %rax,-0x70(%rbp)
 1012d0a:	mov    -0x58(%rbp),%rax
 1012d0e:	mov    %rax,-0x68(%rbp)
 1012d12:	lea    0x1b227(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012d19:	mov    %rax,-0x100(%rbp)
 1012d20:	movl   $0x2,-0xe8(%rbp)
 1012d2a:	movl   $0x2,-0xe8(%rbp)
 1012d34:	movl   $0x0,-0x90(%rbp)
 1012d3e:	movl   $0x1,-0x98(%rbp)
 1012d48:	lea    -0x70(%rbp),%rax
 1012d4c:	mov    %rax,-0x40(%rbp)
 1012d50:	mov    $0x1,%edx
 1012d55:	lea    0x1aed4(%rip),%rsi        # 102dc30 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012d5c:	mov    %rdi,%r12
 1012d5f:	mov    %rbx,%rdi
 1012d62:	call   101dbb0 <myl_native_heap_alloc>
 1012d67:	mov    %r12,%rdi
 1012d6a:	cmp    $0x0,%eax
 1012d6d:	jne    1012d79 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 1012d6f:	mov    %rdi,%rbx
 1012d72:	call   1019250 <myl_qbe_fail_allocation>
 1012d77:	ud2
 1012d79:	xchg   %rdi,%rbx
 1012d7c:	mov    -0x40(%rbp),%rcx
 1012d80:	mov    (%rcx),%rdx
 1012d83:	mov    %rdx,(%rax)
 1012d86:	mov    0x8(%rcx),%rcx
 1012d8a:	mov    %rcx,0x8(%rax)
 1012d8e:	movl   $0x0,-0x98(%rbp)
 1012d98:	mov    %rax,-0x40(%rbp)
 1012d9c:	mov    -0x40(%rbp),%rcx
 1012da0:	mov    %rcx,-0x70(%rbp)
 1012da4:	lea    0x1aef5(%rip),%rcx        # 102dca0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012dab:	mov    %rcx,-0x100(%rbp)
 1012db2:	movl   $0x2,-0xe8(%rbp)
 1012dbc:	movl   $0x1,-0x98(%rbp)
 1012dc6:	mov    %rax,-0x40(%rbp)
 1012dca:	movl   $0x0,-0x88(%rbp)
 1012dd4:	mov    $0x8,%edx
 1012dd9:	mov    $0x0,%esi
 1012dde:	mov    %rdi,%r12
 1012de1:	lea    -0x30(%rbp),%rdi
 1012de5:	call   10299a0 <compiler_rt.fastMemset>
 1012dea:	mov    %r12,%rdi
 1012ded:	mov    -0x40(%rbp),%rax
 1012df1:	mov    %rax,-0x30(%rbp)
 1012df5:	movl   $0x0,-0x98(%rbp)
 1012dff:	lea    -0x30(%rbp),%rax
 1012e03:	mov    %rax,-0x40(%rbp)
 1012e07:	mov    -0x30(%rbp),%rax
 1012e0b:	mov    %rax,-0x70(%rbp)
 1012e0f:	lea    0x1b0ba(%rip),%rax        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012e16:	mov    %rax,-0x100(%rbp)
 1012e1d:	movl   $0x2,-0xe8(%rbp)
 1012e27:	movl   $0x1,-0x98(%rbp)
 1012e31:	lea    -0x70(%rbp),%rax
 1012e35:	mov    %rax,-0x40(%rbp)
 1012e39:	movl   $0x0,-0x88(%rbp)
 1012e43:	mov    -0xa0(%rbp),%eax
 1012e49:	mov    -0x108(%rbp),%ecx
 1012e4f:	cmp    $0x2,%ecx
 1012e52:	sete   %cl
 1012e55:	movzbl %cl,%ecx
 1012e58:	and    %ecx,%eax
 1012e5a:	lea    -0x28(%rbp),%rcx
 1012e5e:	mov    %rcx,%r12
 1012e61:	add    $0x8,%r12
 1012e65:	cmp    $0x0,%eax
 1012e68:	jne    1013123 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7e3>
 1012e6e:	mov    $0x10,%edx
 1012e73:	mov    $0x0,%esi
 1012e78:	mov    %rdi,%r14
 1012e7b:	lea    -0x28(%rbp),%rdi
 1012e7f:	call   10299a0 <compiler_rt.fastMemset>
 1012e84:	mov    %r15,%r8
 1012e87:	mov    %r14,%rdi
 1012e8a:	lea    0x1b0af(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e91:	mov    %rax,-0xc0(%rbp)
 1012e98:	movl   $0x2,-0xa8(%rbp)
 1012ea2:	lea    -0x28(%rbp),%rax
 1012ea6:	mov    %rax,-0xb8(%rbp)
 1012ead:	mov    %r13,-0xb0(%rbp)
 1012eb4:	movl   $0x1,-0x88(%rbp)
 1012ebe:	mov    -0x48(%rbp),%rax
 1012ec2:	mov    -0xa0(%rbp),%ecx
 1012ec8:	mov    -0x108(%rbp),%edx
 1012ece:	and    $0x18,%edx
 1012ed1:	cmp    $0x0,%edx
 1012ed4:	sete   %dl
 1012ed7:	movzbl %dl,%edx
 1012eda:	test   %ecx,%edx
 1012edc:	jne    1012f7b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x63b>
 1012ee2:	mov    %r8,%r14
 1012ee5:	mov    %rax,%rcx
 1012ee8:	lea    -0x60(%rbp),%rdx
 1012eec:	lea    0x1afdd(%rip),%rsi        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012ef3:	mov    %rdi,%r13
 1012ef6:	call   10297f0 <myl_rc_native_retain>
 1012efb:	mov    %r13,%rdi
 1012efe:	cmp    $0x0,%eax
 1012f01:	jne    1012f1d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5dd>
 1012f03:	call   1021420 <myl_rc_take_failure>
 1012f08:	mov    %rbx,%rdi
 1012f0b:	mov    %eax,%esi
 1012f0d:	mov    %rdi,%rbx
 1012f10:	call   1018af0 <myl_qbe_rc_status>
 1012f15:	mov    %rbx,%rdi
 1012f18:	jmp    1013033 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6f3>
 1012f1d:	xchg   %rbx,%rdi
 1012f20:	lea    0x1afa9(%rip),%rax        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012f27:	mov    %rax,-0xe0(%rbp)
 1012f2e:	movl   $0x2,-0xc8(%rbp)
 1012f38:	movl   $0x1,-0x90(%rbp)
 1012f42:	mov    -0xa0(%rbp),%eax
 1012f48:	cmp    $0x0,%eax
 1012f4b:	jne    1012f52 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x612>
 1012f4d:	mov    %r14,%r8
 1012f50:	jmp    1012f67 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x627>
 1012f52:	lea    -0x120(%rbp),%rsi
 1012f59:	mov    %rdi,%r13
 1012f5c:	call   1018cc0 <myl_qbe_rc_slot_drop>
 1012f61:	mov    %r14,%r8
 1012f64:	mov    %r13,%rdi
 1012f67:	mov    -0x60(%rbp),%rax
 1012f6b:	mov    %rax,-0x28(%rbp)
 1012f6f:	movl   $0x0,-0x90(%rbp)
 1012f79:	jmp    1012f8f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x64f>
 1012f7b:	xchg   %rbx,%rdi
 1012f7e:	mov    (%rax),%rax
 1012f81:	mov    %rax,-0x28(%rbp)
 1012f85:	movl   $0x0,-0xa0(%rbp)
 1012f8f:	mov    -0x40(%rbp),%rax
 1012f93:	mov    -0x98(%rbp),%ecx
 1012f99:	mov    -0xe8(%rbp),%edx
 1012f9f:	and    $0x18,%edx
 1012fa2:	cmp    $0x0,%edx
 1012fa5:	sete   %dl
 1012fa8:	movzbl %dl,%edx
 1012fab:	test   %ecx,%edx
 1012fad:	jne    10130bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77f>
 1012fb3:	mov    (%rax),%rcx
 1012fb6:	cmp    $0x0,%rcx
 1012fba:	je     1012fd6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x696>
 1012fbc:	sub    $0x10,%rcx
 1012fc0:	mov    (%rcx),%rcx
 1012fc3:	movabs $0x5000000000000001,%rdx
 1012fcd:	and    %rdx,%rcx
 1012fd0:	cmp    $0x0,%rcx
 1012fd4:	jne    1012ffd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6bd>
 1012fd6:	mov    (%rax),%rcx
 1012fd9:	mov    %rcx,-0x60(%rbp)
 1012fdd:	mov    $0x8,%edx
 1012fe2:	mov    $0x0,%esi
 1012fe7:	mov    %rdi,%rbx
 1012fea:	mov    %rax,%rdi
 1012fed:	call   10299a0 <compiler_rt.fastMemset>
 1012ff2:	mov    %rbx,%rdi
 1012ff5:	mov    %r12,%rbx
 1012ff8:	jmp    1013080 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x740>
 1012ffd:	xchg   %rdi,%rbx
 1013000:	mov    %rax,%rcx
 1013003:	lea    -0x60(%rbp),%rdx
 1013007:	lea    0x1aec2(%rip),%rsi        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101300e:	mov    %rdi,%r13
 1013011:	call   10294b0 <myl_rc_native_take>
 1013016:	mov    %r13,%rdi
 1013019:	cmp    $0x0,%eax
 101301c:	jne    101307a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x73a>
 101301e:	call   1021420 <myl_rc_take_failure>
 1013023:	mov    %rbx,%rdi
 1013026:	mov    %eax,%esi
 1013028:	mov    %rdi,%rbx
 101302b:	call   1018af0 <myl_qbe_rc_status>
 1013030:	mov    %rbx,%rdi
 1013033:	lea    -0x140(%rbp),%rsi
 101303a:	mov    %rdi,%rbx
 101303d:	call   1018df0 <myl_qbe_rc_frame_cleanup>
 1013042:	mov    %rbx,%rdi
 1013045:	lea    -0x140(%rbp),%rsi
 101304c:	call   1018c60 <myl_qbe_rc_frame_leave>
 1013051:	mov    $0x10,%edx
 1013056:	mov    $0x0,%esi
 101305b:	lea    -0x150(%rbp),%rdi
 1013062:	call   10299a0 <compiler_rt.fastMemset>
 1013067:	mov    -0x150(%rbp),%rax
 101306e:	mov    -0x148(%rbp),%rdx
 1013075:	jmp    1013225 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8e5>
 101307a:	mov    %rbx,%rdi
 101307d:	mov    %r12,%rbx
 1013080:	movl   $0x0,-0x98(%rbp)
 101308a:	lea    0x1ae3f(%rip),%rax        # 102ded0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013091:	mov    %rax,-0xe0(%rbp)
 1013098:	movl   $0x2,-0xc8(%rbp)
 10130a2:	movl   $0x1,-0x90(%rbp)
 10130ac:	mov    -0x60(%rbp),%rax
 10130b0:	mov    %rax,(%rbx)
 10130b3:	movl   $0x0,-0x90(%rbp)
 10130bd:	jmp    10130d2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x792>
 10130bf:	mov    %r12,%rbx
 10130c2:	mov    (%rax),%rax
 10130c5:	mov    %rax,(%rbx)
 10130c8:	movl   $0x0,-0x98(%rbp)
 10130d2:	lea    -0x28(%rbp),%rax
 10130d6:	mov    %rax,-0x48(%rbp)
 10130da:	mov    -0x28(%rbp),%rax
 10130de:	mov    %rax,-0x80(%rbp)
 10130e2:	mov    -0x20(%rbp),%rax
 10130e6:	mov    %rax,-0x78(%rbp)
 10130ea:	lea    0x1ae4f(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10130f1:	mov    %rax,-0x120(%rbp)
 10130f8:	movl   $0x2,-0x108(%rbp)
 1013102:	movl   $0x1,-0xa0(%rbp)
 101310c:	lea    -0x80(%rbp),%rax
 1013110:	mov    %rax,-0x48(%rbp)
 1013114:	movl   $0x0,-0x88(%rbp)
 101311e:	jmp    10131b7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x877>
 1013123:	mov    %rbx,%rdi
 1013126:	mov    %r12,%rbx
 1013129:	mov    $0x10,%edx
 101312e:	mov    $0x0,%esi
 1013133:	mov    %rdi,%r12
 1013136:	lea    -0x28(%rbp),%rdi
 101313a:	call   10299a0 <compiler_rt.fastMemset>
 101313f:	mov    %r12,%rdi
 1013142:	mov    -0x48(%rbp),%rax
 1013146:	mov    (%rax),%rax
 1013149:	mov    %rax,-0x28(%rbp)
 101314d:	movl   $0x0,-0xa0(%rbp)
 1013157:	mov    -0x40(%rbp),%rax
 101315b:	mov    (%rax),%rax
 101315e:	mov    %rax,(%rbx)
 1013161:	movl   $0x0,-0x98(%rbp)
 101316b:	lea    -0x28(%rbp),%rax
 101316f:	mov    %rax,-0x48(%rbp)
 1013173:	mov    -0x28(%rbp),%rax
 1013177:	mov    %rax,-0x80(%rbp)
 101317b:	mov    -0x20(%rbp),%rax
 101317f:	mov    %rax,-0x78(%rbp)
 1013183:	lea    0x1adb6(%rip),%rax        # 102df40 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101318a:	mov    %rax,-0x120(%rbp)
 1013191:	movl   $0x2,-0x108(%rbp)
 101319b:	movl   $0x1,-0xa0(%rbp)
 10131a5:	lea    -0x80(%rbp),%rax
 10131a9:	mov    %rax,-0x48(%rbp)
 10131ad:	movl   $0x0,-0x88(%rbp)
 10131b7:	mov    -0x80(%rbp),%rax
 10131bb:	mov    %rax,-0x60(%rbp)
 10131bf:	mov    -0x78(%rbp),%rax
 10131c3:	mov    %rax,-0x58(%rbp)
 10131c7:	movl   $0x0,-0xa0(%rbp)
 10131d1:	lea    -0x140(%rbp),%rsi
 10131d8:	call   1018c60 <myl_qbe_rc_frame_leave>
 10131dd:	mov    -0x60(%rbp),%rax
 10131e1:	mov    -0x58(%rbp),%rdx
 10131e5:	jmp    1013225 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8e5>
 10131e7:	mov    %r12,%rdx
 10131ea:	mov    $0x40,%r8d
 10131f0:	mov    $0x1,%ecx
 10131f5:	mov    $0x1,%esi
 10131fa:	call   1019390 <myl_qbe_fail_overflow_op>
 10131ff:	ud2
 1013201:	movq   $0x0,-0x150(%rbp)
 101320c:	movq   $0x0,-0x148(%rbp)
 1013217:	mov    -0x150(%rbp),%rax
 101321e:	mov    -0x148(%rbp),%rdx
 1013225:	pop    %r15
 1013227:	pop    %r14
 1013229:	pop    %r13
 101322b:	pop    %r12
 101322d:	pop    %rbx
 101322e:	leave
 101322f:	ret
 1013230:	call   10194e0 <myl_qbe_fail_frame>
 1013235:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
