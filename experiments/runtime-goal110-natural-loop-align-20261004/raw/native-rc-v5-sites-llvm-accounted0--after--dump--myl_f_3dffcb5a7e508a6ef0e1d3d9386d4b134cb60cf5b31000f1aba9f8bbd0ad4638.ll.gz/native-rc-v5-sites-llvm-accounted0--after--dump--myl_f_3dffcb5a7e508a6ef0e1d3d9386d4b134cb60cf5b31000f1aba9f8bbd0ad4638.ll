target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v167 = load i64, ptr %slot1, align 8
  %op168 = add i64 %v167, 32
  store i64 %op168, ptr %slot4, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot5, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot6, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot7, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot8, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot9, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot10, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot11, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot12, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot13, align 8
  %v187 = load i64, ptr %slot2, align 8
  %v188 = load i64, ptr %slot5, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot3, align 8
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v193 = load i64, ptr %slot5, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot14, align 8
  %v196 = load i64, ptr %slot14, align 8
  %v197 = load i64, ptr %slot12, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot12, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot15, align 8
  %v202 = load i64, ptr %slot7, align 8
  store i64 %v202, ptr %slot16, align 8
  %v203 = load i64, ptr %slot15, align 8
  %v204 = load i64, ptr %slot16, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot12, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 0, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot12, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot17, align 8
  %v211 = load i64, ptr %slot8, align 8
  store i64 %v211, ptr %slot18, align 8
  %v212 = load i64, ptr %slot17, align 8
  %v213 = load i64, ptr %slot18, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 %v212, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v215 to ptr
  %ld217 = load i64, ptr %p216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld217, ptr %slot19, align 8
  %v218 = load i64, ptr %slot19, align 8
  %v219 = load i64, ptr %slot12, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot12, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot20, align 8
  %v224 = load i64, ptr %slot9, align 8
  store i64 %v224, ptr %slot21, align 8
  %v225 = load i64, ptr %slot20, align 8
  %v226 = load i64, ptr %slot21, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 %v225, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot8, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld230, ptr %slot22, align 8
  %v231 = load i64, ptr %slot9, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot23, align 8
  %v234 = load i64, ptr %slot23, align 8
  %v235 = load i64, ptr %slot22, align 8
  %cmp236 = icmp sgt i64 %v234, %v235
  %cv237 = zext i1 %cmp236 to i64
  store i64 %cv237, ptr %slot24, align 8
  %v238 = load i64, ptr %slot23, align 8
  %v239 = load i64, ptr %slot22, align 8
  %op240 = sub i64 %v238, %v239
  store i64 %op240, ptr %slot25, align 8
  %v241 = load i64, ptr %slot25, align 8
  %cmp242 = icmp uge i64 %v241, 16
  %cv243 = zext i1 %cmp242 to i64
  store i64 %cv243, ptr %slot26, align 8
  %v244 = load i64, ptr %slot24, align 8
  %v245 = load i64, ptr %slot26, align 8
  %op246 = and i64 %v244, %v245
  store i64 %op246, ptr %slot27, align 8
  %v247 = load i64, ptr %slot27, align 8
  %cond248 = icmp ne i64 %v247, 0
  br i1 %cond248, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v249 = load i64, ptr %slot22, align 8
  %op250 = add i64 %v249, 1152921504606846976
  store i64 %op250, ptr %slot28, align 8
  %v251 = load i64, ptr %slot28, align 8
  %cmp252 = icmp ule i64 %v251, 2305843009213693952
  %cv253 = zext i1 %cmp252 to i64
  store i64 %cv253, ptr %slot29, align 8
  %v254 = load i64, ptr %slot29, align 8
  %cond255 = icmp ne i64 %v254, 0
  br i1 %cond255, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v256 = load i64, ptr %slot23, align 8
  %op257 = add i64 %v256, 1152921504606846976
  store i64 %op257, ptr %slot30, align 8
  %v258 = load i64, ptr %slot30, align 8
  %cmp259 = icmp ule i64 %v258, 2305843009213693952
  %cv260 = zext i1 %cmp259 to i64
  store i64 %cv260, ptr %slot31, align 8
  %v261 = load i64, ptr %slot31, align 8
  %cond262 = icmp ne i64 %v261, 0
  br i1 %cond262, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v263 = load i64, ptr %slot8, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot32, align 8
  %v266 = load i64, ptr %slot32, align 8
  %v267 = load i64, ptr %slot12, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot9, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot33, align 8
  %v272 = load i64, ptr %slot33, align 8
  %v273 = load i64, ptr %slot13, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i64 %v272, ptr %p274, align 8, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot13, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot34, align 8
  %v278 = load i64, ptr %slot12, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot35, align 8
  %v281 = load i64, ptr %slot35, align 8
  %v282 = load i64, ptr %slot34, align 8
  %cmp283 = icmp slt i64 %v281, %v282
  %cv284 = zext i1 %cmp283 to i64
  store i64 %cv284, ptr %slot36, align 8
  %v285 = load i64, ptr %slot36, align 8
  %v286 = load i64, ptr %slot12, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot12, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot37, align 8
  %v291 = load i64, ptr %slot37, align 8
  %cond292 = icmp ne i64 %v291, 0
  br i1 %cond292, label %bb_next24, label %bb_i35
bb_next24:
  %v293 = load i64, ptr %slot8, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot38, align 8
  %v296 = load i64, ptr %slot38, align 8
  %v297 = load i64, ptr %slot12, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot13, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 3, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot13, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %ld303 = load i64, ptr %p302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld303, ptr %slot39, align 8
  %v304 = load i64, ptr %slot12, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot40, align 8
  %v307 = load i64, ptr %slot40, align 8
  %op308 = add i64 %v307, 1152921504606846978
  store i64 %op308, ptr %slot41, align 8
  %v309 = load i64, ptr %slot41, align 8
  %v310 = load i64, ptr %slot39, align 8
  %op311 = urem i64 %v309, %v310
  store i64 %op311, ptr %slot42, align 8
  %v312 = load i64, ptr %slot42, align 8
  %v313 = load i64, ptr %slot12, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot13, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 0, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot13, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot12, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot44, align 8
  %v323 = load i64, ptr %slot44, align 8
  %v324 = load i64, ptr %slot43, align 8
  %cmp325 = icmp eq i64 %v323, %v324
  %cv326 = zext i1 %cmp325 to i64
  store i64 %cv326, ptr %slot45, align 8
  %v327 = load i64, ptr %slot45, align 8
  %v328 = load i64, ptr %slot12, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i64 %v327, ptr %p329, align 8, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot12, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld332, ptr %slot46, align 8
  %v333 = load i64, ptr %slot46, align 8
  %cond334 = icmp ne i64 %v333, 0
  br i1 %cond334, label %bb_next33, label %bb_fi20
bb_next33:
  %v335 = load i64, ptr %slot12, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 17, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot12, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot47, align 8
  %v340 = load i64, ptr %slot47, align 8
  %neg341 = sub i64 0, %v340
  store i64 %neg341, ptr %slot48, align 8
  %v342 = load i64, ptr %slot47, align 8
  %cmp343 = icmp eq i64 %v342, 9223372036854775808
  %cv344 = zext i1 %cmp343 to i64
  store i64 %cv344, ptr %slot49, align 8
  %v345 = load i64, ptr %slot49, align 8
  %cond346 = icmp ne i64 %v345, 0
  br i1 %cond346, label %bb_neg_overflow34, label %bb_neg_checked34
bb_neg_overflow34:
  %p347 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64) to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !4, !noalias !3
  store i64 %ld348, ptr %slot50, align 8
  %v349 = load i64, ptr %slot50, align 8
  %op350 = add i64 %v349, 1
  store i64 %op350, ptr %slot51, align 8
  %v351 = load i64, ptr %slot51, align 8
  %p352 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64) to ptr
  store i64 %v351, ptr %p352, align 8, !alias.scope !4, !noalias !3
  %p353 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64), ptr %p353, align 8, !alias.scope !4, !noalias !3
  %v354 = load i64, ptr %slot1, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %v356 = load i64, ptr %slot47, align 8
  %call357 = call i64 @myl_qbe_int_neg(ptr %p355, i64 1, i64 64, i64 %v356) nomerge, !dbg !110
  unreachable
bb_neg_checked34:
  %v358 = load i64, ptr %slot48, align 8
  %v359 = load i64, ptr %slot12, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot12, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i64, ptr %p362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld363, ptr %slot52, align 8
  %v364 = load i64, ptr %slot10, align 8
  store i64 %v364, ptr %slot53, align 8
  %v365 = load i64, ptr %slot52, align 8
  %v366 = load i64, ptr %slot53, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 %v365, ptr %p367, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi20:
  %v368 = load i64, ptr %slot12, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 23, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot54, align 8
  %v373 = load i64, ptr %slot10, align 8
  store i64 %v373, ptr %slot55, align 8
  %v374 = load i64, ptr %slot54, align 8
  %v375 = load i64, ptr %slot55, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi22:
  %v377 = load i64, ptr %slot10, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot56, align 8
  %v380 = load i64, ptr %slot56, align 8
  %v381 = load i64, ptr %slot12, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot57, align 8
  %v386 = load i64, ptr %slot11, align 8
  store i64 %v386, ptr %slot58, align 8
  %v387 = load i64, ptr %slot57, align 8
  %v388 = load i64, ptr %slot58, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot7, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot59, align 8
  %v393 = load i64, ptr %slot59, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot11, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot60, align 8
  %v399 = load i64, ptr %slot60, align 8
  %v400 = load i64, ptr %slot13, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot13, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot61, align 8
  %v405 = load i64, ptr %slot12, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot62, align 8
  %v408 = load i64, ptr %slot62, align 8
  %v409 = load i64, ptr %slot61, align 8
  %ovpair411 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v408, i64 %v409)
  %op410 = extractvalue { i64, i1 } %ovpair411, 0
  %ov412 = extractvalue { i64, i1 } %ovpair411, 1
  store i64 %op410, ptr %slot63, align 8
  %v413 = load i64, ptr %slot62, align 8
  %v414 = load i64, ptr %slot63, align 8
  %op415 = xor i64 %v413, %v414
  store i64 %op415, ptr %slot64, align 8
  %v416 = load i64, ptr %slot61, align 8
  %v417 = load i64, ptr %slot63, align 8
  %op418 = xor i64 %v416, %v417
  store i64 %op418, ptr %slot65, align 8
  %v419 = load i64, ptr %slot64, align 8
  %v420 = load i64, ptr %slot65, align 8
  %op421 = and i64 %v419, %v420
  store i64 %op421, ptr %slot66, align 8
  %cv422 = zext i1 %ov412 to i64
  store i64 %cv422, ptr %slot67, align 8
  %v423 = load i64, ptr %slot67, align 8
  %cond424 = icmp ne i64 %v423, 0
  br i1 %cond424, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v425 = load i64, ptr %slot1, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %v427 = load i64, ptr %slot62, align 8
  %v428 = load i64, ptr %slot61, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p426, i64 0, i64 %v427, i64 %v428, i64 64) nomerge, !dbg !112
  unreachable
bb_checked47:
  %v429 = load i64, ptr %slot63, align 8
  %v430 = load i64, ptr %slot12, align 8
  %p431 = inttoptr i64 %v430 to ptr
  store i64 %v429, ptr %p431, align 8, !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot13, align 8
  %p433 = inttoptr i64 %v432 to ptr
  store i64 1000000007, ptr %p433, align 8, !alias.scope !3, !noalias !4
  %v434 = load i64, ptr %slot13, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i64, ptr %p435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld436, ptr %slot68, align 8
  %v437 = load i64, ptr %slot12, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld439, ptr %slot69, align 8
  %v440 = load i64, ptr %slot68, align 8
  %cmp441 = icmp eq i64 %v440, 0
  %cv442 = zext i1 %cmp441 to i64
  store i64 %cv442, ptr %slot70, align 8
  %v443 = load i64, ptr %slot70, align 8
  %cond444 = icmp ne i64 %v443, 0
  br i1 %cond444, label %bb_division54, label %bb_nonzero54
bb_division54:
  %v445 = load i64, ptr %slot1, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %v447 = load i64, ptr %slot69, align 8
  %v448 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_division(ptr %p446, i64 6, i64 %v447, i64 %v448) nomerge, !dbg !114
  unreachable
bb_nonzero54:
  %v449 = load i64, ptr %slot69, align 8
  %cmp450 = icmp eq i64 %v449, 9223372036854775808
  %cv451 = zext i1 %cmp450 to i64
  store i64 %cv451, ptr %slot71, align 8
  %v452 = load i64, ptr %slot68, align 8
  %cmp453 = icmp eq i64 %v452, 18446744073709551615
  %cv454 = zext i1 %cmp453 to i64
  store i64 %cv454, ptr %slot72, align 8
  %v455 = load i64, ptr %slot71, align 8
  %v456 = load i64, ptr %slot72, align 8
  %op457 = and i64 %v455, %v456
  store i64 %op457, ptr %slot73, align 8
  %v458 = load i64, ptr %slot73, align 8
  %neg459 = sub i64 0, %v458
  store i64 %neg459, ptr %slot74, align 8
  %v460 = load i64, ptr %slot68, align 8
  %op461 = xor i64 %v460, 1
  store i64 %op461, ptr %slot75, align 8
  %v462 = load i64, ptr %slot75, align 8
  %v463 = load i64, ptr %slot74, align 8
  %op464 = and i64 %v462, %v463
  store i64 %op464, ptr %slot75, align 8
  %v465 = load i64, ptr %slot68, align 8
  %v466 = load i64, ptr %slot75, align 8
  %op467 = xor i64 %v465, %v466
  store i64 %op467, ptr %slot76, align 8
  %v468 = load i64, ptr %slot69, align 8
  %v469 = load i64, ptr %slot76, align 8
  %op470 = srem i64 %v468, %v469
  store i64 %op470, ptr %slot77, align 8
  %v471 = load i64, ptr %slot77, align 8
  %cmp472 = icmp ne i64 %v471, 0
  %cv473 = zext i1 %cmp472 to i64
  store i64 %cv473, ptr %slot78, align 8
  %v474 = load i64, ptr %slot77, align 8
  %v475 = load i64, ptr %slot76, align 8
  %op476 = xor i64 %v474, %v475
  store i64 %op476, ptr %slot79, align 8
  %v477 = load i64, ptr %slot79, align 8
  %cmp478 = icmp slt i64 %v477, 0
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot80, align 8
  %v480 = load i64, ptr %slot78, align 8
  %v481 = load i64, ptr %slot80, align 8
  %op482 = and i64 %v480, %v481
  store i64 %op482, ptr %slot81, align 8
  %v483 = load i64, ptr %slot81, align 8
  %neg484 = sub i64 0, %v483
  store i64 %neg484, ptr %slot82, align 8
  %v485 = load i64, ptr %slot76, align 8
  %v486 = load i64, ptr %slot82, align 8
  %op487 = and i64 %v485, %v486
  store i64 %op487, ptr %slot83, align 8
  %v488 = load i64, ptr %slot77, align 8
  %v489 = load i64, ptr %slot83, align 8
  %op490 = add i64 %v488, %v489
  store i64 %op490, ptr %slot77, align 8
  %v491 = load i64, ptr %slot77, align 8
  %floorbounded492 = icmp ult i64 %v491, 1000000007
  call void @llvm.assume(i1 %floorbounded492)
  %v493 = load i64, ptr %slot77, align 8
  %v494 = load i64, ptr %slot12, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i64 %v493, ptr %p495, align 8, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot12, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %ld498 = load i64, ptr %p497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld498, ptr %slot84, align 8
  %v499 = load i64, ptr %slot7, align 8
  store i64 %v499, ptr %slot85, align 8
  %v500 = load i64, ptr %slot84, align 8
  %v501 = load i64, ptr %slot85, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i64 %v500, ptr %p502, align 8, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot8, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %ld505 = load i64, ptr %p504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld505, ptr %slot86, align 8
  %v506 = load i64, ptr %slot86, align 8
  %v507 = load i64, ptr %slot12, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i64 %v506, ptr %p508, align 8, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot13, align 8
  %p510 = inttoptr i64 %v509 to ptr
  store i64 1, ptr %p510, align 8, !alias.scope !3, !noalias !4
  %v511 = load i64, ptr %slot13, align 8
  %p512 = inttoptr i64 %v511 to ptr
  %ld513 = load i64, ptr %p512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld513, ptr %slot87, align 8
  %v514 = load i64, ptr %slot12, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ld516 = load i64, ptr %p515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld516, ptr %slot88, align 8
  %v517 = load i64, ptr %slot88, align 8
  %v518 = load i64, ptr %slot87, align 8
  %op519 = add i64 %v517, %v518
  store i64 %op519, ptr %slot89, align 8
  %v520 = load i64, ptr %slot89, align 8
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot12, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i64, ptr %p524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld525, ptr %slot90, align 8
  %v526 = load i64, ptr %slot8, align 8
  store i64 %v526, ptr %slot91, align 8
  %v527 = load i64, ptr %slot90, align 8
  %v528 = load i64, ptr %slot91, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !121
bb_oi6:
  %v530 = load i64, ptr %slot8, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot92, align 8
  %v533 = load i64, ptr %slot92, align 8
  %v534 = load i64, ptr %slot12, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot9, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot93, align 8
  %v539 = load i64, ptr %slot93, align 8
  %v540 = load i64, ptr %slot13, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot13, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot94, align 8
  %v545 = load i64, ptr %slot12, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot95, align 8
  %v548 = load i64, ptr %slot95, align 8
  %v549 = load i64, ptr %slot94, align 8
  %cmp550 = icmp slt i64 %v548, %v549
  %cv551 = zext i1 %cmp550 to i64
  store i64 %cv551, ptr %slot96, align 8
  %v552 = load i64, ptr %slot96, align 8
  %v553 = load i64, ptr %slot12, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i64 %v552, ptr %p554, align 8, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot12, align 8
  %p556 = inttoptr i64 %v555 to ptr
  %ld557 = load i64, ptr %p556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld557, ptr %slot97, align 8
  %v558 = load i64, ptr %slot97, align 8
  %cond559 = icmp ne i64 %v558, 0
  br i1 %cond559, label %bb_next82, label %bb_i35
bb_next82:
  %v560 = load i64, ptr %slot8, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot98, align 8
  %v563 = load i64, ptr %slot98, align 8
  %v564 = load i64, ptr %slot12, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i64 %v563, ptr %p565, align 8, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot13, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 3, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot13, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot99, align 8
  %v571 = load i64, ptr %slot12, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot100, align 8
  %v574 = load i64, ptr %slot99, align 8
  %cmp575 = icmp eq i64 %v574, 0
  %cv576 = zext i1 %cmp575 to i64
  store i64 %cv576, ptr %slot101, align 8
  %v577 = load i64, ptr %slot101, align 8
  %cond578 = icmp ne i64 %v577, 0
  br i1 %cond578, label %bb_division85, label %bb_nonzero85
bb_division85:
  %v579 = load i64, ptr %slot1, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %v581 = load i64, ptr %slot100, align 8
  %v582 = load i64, ptr %slot99, align 8
  call void @myl_qbe_fail_division(ptr %p580, i64 6, i64 %v581, i64 %v582) nomerge, !dbg !116
  unreachable
bb_nonzero85:
  %v583 = load i64, ptr %slot100, align 8
  %cmp584 = icmp eq i64 %v583, 9223372036854775808
  %cv585 = zext i1 %cmp584 to i64
  store i64 %cv585, ptr %slot102, align 8
  %v586 = load i64, ptr %slot99, align 8
  %cmp587 = icmp eq i64 %v586, 18446744073709551615
  %cv588 = zext i1 %cmp587 to i64
  store i64 %cv588, ptr %slot103, align 8
  %v589 = load i64, ptr %slot102, align 8
  %v590 = load i64, ptr %slot103, align 8
  %op591 = and i64 %v589, %v590
  store i64 %op591, ptr %slot104, align 8
  %v592 = load i64, ptr %slot104, align 8
  %neg593 = sub i64 0, %v592
  store i64 %neg593, ptr %slot105, align 8
  %v594 = load i64, ptr %slot99, align 8
  %op595 = xor i64 %v594, 1
  store i64 %op595, ptr %slot106, align 8
  %v596 = load i64, ptr %slot106, align 8
  %v597 = load i64, ptr %slot105, align 8
  %op598 = and i64 %v596, %v597
  store i64 %op598, ptr %slot106, align 8
  %v599 = load i64, ptr %slot99, align 8
  %v600 = load i64, ptr %slot106, align 8
  %op601 = xor i64 %v599, %v600
  store i64 %op601, ptr %slot107, align 8
  %v602 = load i64, ptr %slot100, align 8
  %v603 = load i64, ptr %slot107, align 8
  %op604 = srem i64 %v602, %v603
  store i64 %op604, ptr %slot108, align 8
  %v605 = load i64, ptr %slot108, align 8
  %cmp606 = icmp ne i64 %v605, 0
  %cv607 = zext i1 %cmp606 to i64
  store i64 %cv607, ptr %slot109, align 8
  %v608 = load i64, ptr %slot108, align 8
  %v609 = load i64, ptr %slot107, align 8
  %op610 = xor i64 %v608, %v609
  store i64 %op610, ptr %slot110, align 8
  %v611 = load i64, ptr %slot110, align 8
  %cmp612 = icmp slt i64 %v611, 0
  %cv613 = zext i1 %cmp612 to i64
  store i64 %cv613, ptr %slot111, align 8
  %v614 = load i64, ptr %slot109, align 8
  %v615 = load i64, ptr %slot111, align 8
  %op616 = and i64 %v614, %v615
  store i64 %op616, ptr %slot112, align 8
  %v617 = load i64, ptr %slot112, align 8
  %neg618 = sub i64 0, %v617
  store i64 %neg618, ptr %slot113, align 8
  %v619 = load i64, ptr %slot107, align 8
  %v620 = load i64, ptr %slot113, align 8
  %op621 = and i64 %v619, %v620
  store i64 %op621, ptr %slot114, align 8
  %v622 = load i64, ptr %slot108, align 8
  %v623 = load i64, ptr %slot114, align 8
  %op624 = add i64 %v622, %v623
  store i64 %op624, ptr %slot108, align 8
  %v625 = load i64, ptr %slot108, align 8
  %floorbounded626 = icmp ult i64 %v625, 3
  call void @llvm.assume(i1 %floorbounded626)
  %v627 = load i64, ptr %slot108, align 8
  %v628 = load i64, ptr %slot12, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot13, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i64 0, ptr %p631, align 8, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot13, align 8
  %p633 = inttoptr i64 %v632 to ptr
  %ld634 = load i64, ptr %p633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld634, ptr %slot115, align 8
  %v635 = load i64, ptr %slot12, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot116, align 8
  %v638 = load i64, ptr %slot116, align 8
  %v639 = load i64, ptr %slot115, align 8
  %cmp640 = icmp eq i64 %v638, %v639
  %cv641 = zext i1 %cmp640 to i64
  store i64 %cv641, ptr %slot117, align 8
  %v642 = load i64, ptr %slot117, align 8
  %v643 = load i64, ptr %slot12, align 8
  %p644 = inttoptr i64 %v643 to ptr
  store i64 %v642, ptr %p644, align 8, !alias.scope !3, !noalias !4
  %v645 = load i64, ptr %slot12, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i64, ptr %p646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld647, ptr %slot118, align 8
  %v648 = load i64, ptr %slot118, align 8
  %cond649 = icmp ne i64 %v648, 0
  br i1 %cond649, label %bb_next103, label %bb_i20
bb_next103:
  %v650 = load i64, ptr %slot12, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i64 17, ptr %p651, align 8, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot12, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %ld654 = load i64, ptr %p653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld654, ptr %slot119, align 8
  %v655 = load i64, ptr %slot119, align 8
  %neg656 = sub i64 0, %v655
  store i64 %neg656, ptr %slot120, align 8
  %v657 = load i64, ptr %slot119, align 8
  %cmp658 = icmp eq i64 %v657, 9223372036854775808
  %cv659 = zext i1 %cmp658 to i64
  store i64 %cv659, ptr %slot121, align 8
  %v660 = load i64, ptr %slot121, align 8
  %cond661 = icmp ne i64 %v660, 0
  br i1 %cond661, label %bb_neg_overflow104, label %bb_neg_checked104
bb_neg_overflow104:
  %p662 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64) to ptr
  %ld663 = load i64, ptr %p662, align 8, !alias.scope !4, !noalias !3
  store i64 %ld663, ptr %slot122, align 8
  %v664 = load i64, ptr %slot122, align 8
  %op665 = add i64 %v664, 1
  store i64 %op665, ptr %slot123, align 8
  %v666 = load i64, ptr %slot123, align 8
  %p667 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64) to ptr
  store i64 %v666, ptr %p667, align 8, !alias.scope !4, !noalias !3
  %p668 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64), ptr %p668, align 8, !alias.scope !4, !noalias !3
  %v669 = load i64, ptr %slot1, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %v671 = load i64, ptr %slot119, align 8
  %call672 = call i64 @myl_qbe_int_neg(ptr %p670, i64 1, i64 64, i64 %v671) nomerge, !dbg !110
  unreachable
bb_neg_checked104:
  %v673 = load i64, ptr %slot120, align 8
  %v674 = load i64, ptr %slot12, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot12, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot124, align 8
  %v679 = load i64, ptr %slot10, align 8
  store i64 %v679, ptr %slot125, align 8
  %v680 = load i64, ptr %slot124, align 8
  %v681 = load i64, ptr %slot125, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i64 %v680, ptr %p682, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i20:
  %v683 = load i64, ptr %slot12, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i64 23, ptr %p684, align 8, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot12, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %ld687 = load i64, ptr %p686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld687, ptr %slot126, align 8
  %v688 = load i64, ptr %slot10, align 8
  store i64 %v688, ptr %slot127, align 8
  %v689 = load i64, ptr %slot126, align 8
  %v690 = load i64, ptr %slot127, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i64 %v689, ptr %p691, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v692 = load i64, ptr %slot10, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %ld694 = load i64, ptr %p693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld694, ptr %slot128, align 8
  %v695 = load i64, ptr %slot128, align 8
  %v696 = load i64, ptr %slot12, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 %v695, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot12, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot129, align 8
  %v701 = load i64, ptr %slot11, align 8
  store i64 %v701, ptr %slot130, align 8
  %v702 = load i64, ptr %slot129, align 8
  %v703 = load i64, ptr %slot130, align 8
  %p704 = inttoptr i64 %v703 to ptr
  store i64 %v702, ptr %p704, align 8, !alias.scope !3, !noalias !4
  %v705 = load i64, ptr %slot7, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i64, ptr %p706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld707, ptr %slot131, align 8
  %v708 = load i64, ptr %slot131, align 8
  %v709 = load i64, ptr %slot12, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i64 %v708, ptr %p710, align 8, !alias.scope !3, !noalias !4
  %v711 = load i64, ptr %slot11, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %ld713 = load i64, ptr %p712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld713, ptr %slot132, align 8
  %v714 = load i64, ptr %slot132, align 8
  %v715 = load i64, ptr %slot13, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 %v714, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot13, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot133, align 8
  %v720 = load i64, ptr %slot12, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i64, ptr %p721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld722, ptr %slot134, align 8
  %v723 = load i64, ptr %slot134, align 8
  %v724 = load i64, ptr %slot133, align 8
  %ovpair726 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v723, i64 %v724)
  %op725 = extractvalue { i64, i1 } %ovpair726, 0
  %ov727 = extractvalue { i64, i1 } %ovpair726, 1
  store i64 %op725, ptr %slot135, align 8
  %v728 = load i64, ptr %slot134, align 8
  %v729 = load i64, ptr %slot135, align 8
  %op730 = xor i64 %v728, %v729
  store i64 %op730, ptr %slot136, align 8
  %v731 = load i64, ptr %slot133, align 8
  %v732 = load i64, ptr %slot135, align 8
  %op733 = xor i64 %v731, %v732
  store i64 %op733, ptr %slot137, align 8
  %v734 = load i64, ptr %slot136, align 8
  %v735 = load i64, ptr %slot137, align 8
  %op736 = and i64 %v734, %v735
  store i64 %op736, ptr %slot138, align 8
  %cv737 = zext i1 %ov727 to i64
  store i64 %cv737, ptr %slot139, align 8
  %v738 = load i64, ptr %slot139, align 8
  %cond739 = icmp ne i64 %v738, 0
  br i1 %cond739, label %bb_overflow117, label %bb_checked117
bb_overflow117:
  %v740 = load i64, ptr %slot1, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %v742 = load i64, ptr %slot134, align 8
  %v743 = load i64, ptr %slot133, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p741, i64 0, i64 %v742, i64 %v743, i64 64) nomerge, !dbg !112
  unreachable
bb_checked117:
  %v744 = load i64, ptr %slot135, align 8
  %v745 = load i64, ptr %slot12, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i64 %v744, ptr %p746, align 8, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot13, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i64 1000000007, ptr %p748, align 8, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot13, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %ld751 = load i64, ptr %p750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld751, ptr %slot140, align 8
  %v752 = load i64, ptr %slot12, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i64, ptr %p753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld754, ptr %slot141, align 8
  %v755 = load i64, ptr %slot140, align 8
  %cmp756 = icmp eq i64 %v755, 0
  %cv757 = zext i1 %cmp756 to i64
  store i64 %cv757, ptr %slot142, align 8
  %v758 = load i64, ptr %slot142, align 8
  %cond759 = icmp ne i64 %v758, 0
  br i1 %cond759, label %bb_division124, label %bb_nonzero124
bb_division124:
  %v760 = load i64, ptr %slot1, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %v762 = load i64, ptr %slot141, align 8
  %v763 = load i64, ptr %slot140, align 8
  call void @myl_qbe_fail_division(ptr %p761, i64 6, i64 %v762, i64 %v763) nomerge, !dbg !114
  unreachable
bb_nonzero124:
  %v764 = load i64, ptr %slot141, align 8
  %cmp765 = icmp eq i64 %v764, 9223372036854775808
  %cv766 = zext i1 %cmp765 to i64
  store i64 %cv766, ptr %slot143, align 8
  %v767 = load i64, ptr %slot140, align 8
  %cmp768 = icmp eq i64 %v767, 18446744073709551615
  %cv769 = zext i1 %cmp768 to i64
  store i64 %cv769, ptr %slot144, align 8
  %v770 = load i64, ptr %slot143, align 8
  %v771 = load i64, ptr %slot144, align 8
  %op772 = and i64 %v770, %v771
  store i64 %op772, ptr %slot145, align 8
  %v773 = load i64, ptr %slot145, align 8
  %neg774 = sub i64 0, %v773
  store i64 %neg774, ptr %slot146, align 8
  %v775 = load i64, ptr %slot140, align 8
  %op776 = xor i64 %v775, 1
  store i64 %op776, ptr %slot147, align 8
  %v777 = load i64, ptr %slot147, align 8
  %v778 = load i64, ptr %slot146, align 8
  %op779 = and i64 %v777, %v778
  store i64 %op779, ptr %slot147, align 8
  %v780 = load i64, ptr %slot140, align 8
  %v781 = load i64, ptr %slot147, align 8
  %op782 = xor i64 %v780, %v781
  store i64 %op782, ptr %slot148, align 8
  %v783 = load i64, ptr %slot141, align 8
  %v784 = load i64, ptr %slot148, align 8
  %op785 = srem i64 %v783, %v784
  store i64 %op785, ptr %slot149, align 8
  %v786 = load i64, ptr %slot149, align 8
  %cmp787 = icmp ne i64 %v786, 0
  %cv788 = zext i1 %cmp787 to i64
  store i64 %cv788, ptr %slot150, align 8
  %v789 = load i64, ptr %slot149, align 8
  %v790 = load i64, ptr %slot148, align 8
  %op791 = xor i64 %v789, %v790
  store i64 %op791, ptr %slot151, align 8
  %v792 = load i64, ptr %slot151, align 8
  %cmp793 = icmp slt i64 %v792, 0
  %cv794 = zext i1 %cmp793 to i64
  store i64 %cv794, ptr %slot152, align 8
  %v795 = load i64, ptr %slot150, align 8
  %v796 = load i64, ptr %slot152, align 8
  %op797 = and i64 %v795, %v796
  store i64 %op797, ptr %slot153, align 8
  %v798 = load i64, ptr %slot153, align 8
  %neg799 = sub i64 0, %v798
  store i64 %neg799, ptr %slot154, align 8
  %v800 = load i64, ptr %slot148, align 8
  %v801 = load i64, ptr %slot154, align 8
  %op802 = and i64 %v800, %v801
  store i64 %op802, ptr %slot155, align 8
  %v803 = load i64, ptr %slot149, align 8
  %v804 = load i64, ptr %slot155, align 8
  %op805 = add i64 %v803, %v804
  store i64 %op805, ptr %slot149, align 8
  %v806 = load i64, ptr %slot149, align 8
  %floorbounded807 = icmp ult i64 %v806, 1000000007
  call void @llvm.assume(i1 %floorbounded807)
  %v808 = load i64, ptr %slot149, align 8
  %v809 = load i64, ptr %slot12, align 8
  %p810 = inttoptr i64 %v809 to ptr
  store i64 %v808, ptr %p810, align 8, !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot12, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i64, ptr %p812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld813, ptr %slot156, align 8
  %v814 = load i64, ptr %slot7, align 8
  store i64 %v814, ptr %slot157, align 8
  %v815 = load i64, ptr %slot156, align 8
  %v816 = load i64, ptr %slot157, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot8, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot158, align 8
  %v821 = load i64, ptr %slot158, align 8
  %v822 = load i64, ptr %slot12, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 %v821, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot13, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i64 1, ptr %p825, align 8, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot13, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld828, ptr %slot159, align 8
  %v829 = load i64, ptr %slot12, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i64, ptr %p830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld831, ptr %slot160, align 8
  %v832 = load i64, ptr %slot160, align 8
  %v833 = load i64, ptr %slot159, align 8
  %op834 = add i64 %v832, %v833
  %ovpair835 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v832, i64 %v833)
  %ov836 = extractvalue { i64, i1 } %ovpair835, 1
  store i64 %op834, ptr %slot161, align 8
  %cv837 = zext i1 %ov836 to i64
  store i64 %cv837, ptr %slot162, align 8
  %v838 = load i64, ptr %slot162, align 8
  %cond839 = icmp ne i64 %v838, 0
  br i1 %cond839, label %bb_overflow143, label %bb_checked143
bb_overflow143:
  %v840 = load i64, ptr %slot1, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %v842 = load i64, ptr %slot160, align 8
  %v843 = load i64, ptr %slot159, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p841, i64 0, i64 %v842, i64 %v843, i64 64) nomerge, !dbg !118
  unreachable
bb_checked143:
  %v844 = load i64, ptr %slot161, align 8
  %v845 = load i64, ptr %slot12, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 %v844, ptr %p846, align 8, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot12, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ld849 = load i64, ptr %p848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld849, ptr %slot163, align 8
  %v850 = load i64, ptr %slot8, align 8
  store i64 %v850, ptr %slot164, align 8
  %v851 = load i64, ptr %slot163, align 8
  %v852 = load i64, ptr %slot164, align 8
  %p853 = inttoptr i64 %v852 to ptr
  store i64 %v851, ptr %p853, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !122
bb_i35:
  %v854 = load i64, ptr %slot7, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld856, ptr %slot165, align 8
  %v857 = load i64, ptr %slot165, align 8
  %v858 = load i64, ptr %slot12, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i64 %v857, ptr %p859, align 8, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot12, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i64, ptr %p861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld862, ptr %slot166, align 8
  %v863 = load i64, ptr %slot166, align 8
  ret i64 %v863
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 = external global i8, align 8
@myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 = external global i8, align 8
@myl_rc_site_current = external global i8, align 8

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", linkageName: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4316030661171315038, i64 0, !"myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!110 = !DILocation(line: 18, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
!120 = !{!"llvm.loop.align", i32 32}
!121 = distinct !{!121, !120}
!122 = distinct !{!122, !120}
