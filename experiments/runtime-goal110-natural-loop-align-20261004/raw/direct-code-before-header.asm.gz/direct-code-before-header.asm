0x102ce99: mov    (%rsi),%rdx
0x102ce9c: cmp    %rdx,%r13
0x102ce9f: jae    102e379 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4789>
0x102cea5: cmp    $0xb,%rdi
0x102cea9: ja     102daac <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3ebc>
0x102ceaf: mov    0x20(%rsi),%rax
0x102ceb3: mov    (%rax,%r13,8),%r15
0x102ceb7: jmp    *0x1009e90(,%rdi,8)
