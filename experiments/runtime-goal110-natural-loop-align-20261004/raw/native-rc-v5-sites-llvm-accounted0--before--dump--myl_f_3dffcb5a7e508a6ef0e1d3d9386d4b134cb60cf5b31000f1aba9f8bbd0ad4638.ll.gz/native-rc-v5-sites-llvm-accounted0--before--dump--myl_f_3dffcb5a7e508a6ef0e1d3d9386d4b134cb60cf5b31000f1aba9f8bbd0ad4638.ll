target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v167 = load i64, ptr %slot1, align 8
  %op168 = add i64 %v167, 32
  store i64 %op168, ptr %slot4, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot5, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot6, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot7, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot8, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot9, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot10, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot11, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot12, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot13, align 8
  %v187 = load i64, ptr %slot2, align 8
  %v188 = load i64, ptr %slot5, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot3, align 8
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v193 = load i64, ptr %slot5, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot14, align 8
  %v196 = load i64, ptr %slot14, align 8
  %v197 = load i64, ptr %slot12, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot12, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot15, align 8
  %v202 = load i64, ptr %slot7, align 8
  store i64 %v202, ptr %slot16, align 8
  %v203 = load i64, ptr %slot15, align 8
  %v204 = load i64, ptr %slot16, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot12, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 0, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot12, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot17, align 8
  %v211 = load i64, ptr %slot8, align 8
  store i64 %v211, ptr %slot18, align 8
  %v212 = load i64, ptr %slot17, align 8
  %v213 = load i64, ptr %slot18, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 %v212, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v215 to ptr
  %ld217 = load i64, ptr %p216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld217, ptr %slot19, align 8
  %v218 = load i64, ptr %slot19, align 8
  %v219 = load i64, ptr %slot12, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot12, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot20, align 8
  %v224 = load i64, ptr %slot9, align 8
  store i64 %v224, ptr %slot21, align 8
  %v225 = load i64, ptr %slot20, align 8
  %v226 = load i64, ptr %slot21, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 %v225, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot8, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld230, ptr %slot22, align 8
  %v231 = load i64, ptr %slot9, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot23, align 8
  %v234 = load i64, ptr %slot23, align 8
  %v235 = load i64, ptr %slot22, align 8
  %cmp236 = icmp sgt i64 %v234, %v235
  %cv237 = zext i1 %cmp236 to i64
  store i64 %cv237, ptr %slot24, align 8
  %v238 = load i64, ptr %slot23, align 8
  %v239 = load i64, ptr %slot22, align 8
  %op240 = sub i64 %v238, %v239
  store i64 %op240, ptr %slot25, align 8
  %v241 = load i64, ptr %slot25, align 8
  %cmp242 = icmp uge i64 %v241, 16
  %cv243 = zext i1 %cmp242 to i64
  store i64 %cv243, ptr %slot26, align 8
  %v244 = load i64, ptr %slot24, align 8
  %v245 = load i64, ptr %slot26, align 8
  %op246 = and i64 %v244, %v245
  store i64 %op246, ptr %slot27, align 8
  %v247 = load i64, ptr %slot27, align 8
  %cond248 = icmp ne i64 %v247, 0
  br i1 %cond248, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v249 = load i64, ptr %slot22, align 8
  %op250 = add i64 %v249, 1152921504606846976
  store i64 %op250, ptr %slot28, align 8
  %v251 = load i64, ptr %slot28, align 8
  %cmp252 = icmp ule i64 %v251, 2305843009213693952
  %cv253 = zext i1 %cmp252 to i64
  store i64 %cv253, ptr %slot29, align 8
  %v254 = load i64, ptr %slot29, align 8
  %cond255 = icmp ne i64 %v254, 0
  br i1 %cond255, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v256 = load i64, ptr %slot23, align 8
  %op257 = add i64 %v256, 1152921504606846976
  store i64 %op257, ptr %slot30, align 8
  %v258 = load i64, ptr %slot30, align 8
  %cmp259 = icmp ule i64 %v258, 2305843009213693952
  %cv260 = zext i1 %cmp259 to i64
  store i64 %cv260, ptr %slot31, align 8
  %v261 = load i64, ptr %slot31, align 8
  %cond262 = icmp ne i64 %v261, 0
  br i1 %cond262, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v263 = load i64, ptr %slot8, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot32, align 8
  %v266 = load i64, ptr %slot32, align 8
  %v267 = load i64, ptr %slot12, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot9, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot33, align 8
  %v272 = load i64, ptr %slot33, align 8
  %v273 = load i64, ptr %slot13, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i64 %v272, ptr %p274, align 8, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot13, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot34, align 8
  %v278 = load i64, ptr %slot12, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot35, align 8
  %v281 = load i64, ptr %slot35, align 8
  %v282 = load i64, ptr %slot34, align 8
  %cmp283 = icmp slt i64 %v281, %v282
  %cv284 = zext i1 %cmp283 to i64
  store i64 %cv284, ptr %slot36, align 8
  %v285 = load i64, ptr %slot36, align 8
  %v286 = load i64, ptr %slot12, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot12, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot37, align 8
  %v291 = load i64, ptr %slot37, align 8
  %cond292 = icmp ne i64 %v291, 0
  br i1 %cond292, label %bb_next24, label %bb_i35
bb_next24:
  %v293 = load i64, ptr %slot8, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot38, align 8
  %v296 = load i64, ptr %slot38, align 8
  %v297 = load i64, ptr %slot12, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot13, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 3, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot13, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %ld303 = load i64, ptr %p302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld303, ptr %slot39, align 8
  %v304 = load i64, ptr %slot12, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot40, align 8
  %v307 = load i64, ptr %slot40, align 8
  %op308 = add i64 %v307, 1152921504606846978
  store i64 %op308, ptr %slot41, align 8
  %v309 = load i64, ptr %slot41, align 8
  %v310 = load i64, ptr %slot39, align 8
  %op311 = urem i64 %v309, %v310
  store i64 %op311, ptr %slot42, align 8
  %v312 = load i64, ptr %slot42, align 8
  %v313 = load i64, ptr %slot12, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot13, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 0, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot13, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot12, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot44, align 8
  %v323 = load i64, ptr %slot44, align 8
  %v324 = load i64, ptr %slot43, align 8
  %cmp325 = icmp eq i64 %v323, %v324
  %cv326 = zext i1 %cmp325 to i64
  store i64 %cv326, ptr %slot45, align 8
  %v327 = load i64, ptr %slot45, align 8
  %v328 = load i64, ptr %slot12, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i64 %v327, ptr %p329, align 8, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot12, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld332, ptr %slot46, align 8
  %v333 = load i64, ptr %slot46, align 8
  %cond334 = icmp ne i64 %v333, 0
  br i1 %cond334, label %bb_next33, label %bb_fi20
bb_next33:
  %v335 = load i64, ptr %slot12, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 17, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot12, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot47, align 8
  %v340 = load i64, ptr %slot47, align 8
  %neg341 = sub i64 0, %v340
  store i64 %neg341, ptr %slot48, align 8
  %v342 = load i64, ptr %slot47, align 8
  %cmp343 = icmp eq i64 %v342, 9223372036854775808
  %cv344 = zext i1 %cmp343 to i64
  store i64 %cv344, ptr %slot49, align 8
  %v345 = load i64, ptr %slot49, align 8
  %cond346 = icmp ne i64 %v345, 0
  br i1 %cond346, label %bb_neg_overflow34, label %bb_neg_checked34
bb_neg_overflow34:
  %p347 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64) to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !4, !noalias !3
  store i64 %ld348, ptr %slot50, align 8
  %v349 = load i64, ptr %slot50, align 8
  %op350 = add i64 %v349, 1
  store i64 %op350, ptr %slot51, align 8
  %v351 = load i64, ptr %slot51, align 8
  %p352 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64) to ptr
  store i64 %v351, ptr %p352, align 8, !alias.scope !4, !noalias !3
  %p353 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 to i64), ptr %p353, align 8, !alias.scope !4, !noalias !3
  %v354 = load i64, ptr %slot1, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %v356 = load i64, ptr %slot47, align 8
  %call357 = call i64 @myl_qbe_int_neg(ptr %p355, i64 1, i64 64, i64 %v356) nomerge, !dbg !110
  unreachable
bb_neg_checked34:
  %v358 = load i64, ptr %slot48, align 8
  %v359 = load i64, ptr %slot12, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot12, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i64, ptr %p362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld363, ptr %slot52, align 8
  %v364 = load i64, ptr %slot10, align 8
  store i64 %v364, ptr %slot53, align 8
  %v365 = load i64, ptr %slot52, align 8
  %v366 = load i64, ptr %slot53, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 %v365, ptr %p367, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi20:
  %v368 = load i64, ptr %slot12, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 23, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot54, align 8
  %v373 = load i64, ptr %slot10, align 8
  store i64 %v373, ptr %slot55, align 8
  %v374 = load i64, ptr %slot54, align 8
  %v375 = load i64, ptr %slot55, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi22:
  %v377 = load i64, ptr %slot10, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot56, align 8
  %v380 = load i64, ptr %slot56, align 8
  %v381 = load i64, ptr %slot12, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot57, align 8
  %v386 = load i64, ptr %slot11, align 8
  store i64 %v386, ptr %slot58, align 8
  %v387 = load i64, ptr %slot57, align 8
  %v388 = load i64, ptr %slot58, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot7, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot59, align 8
  %v393 = load i64, ptr %slot59, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot11, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot60, align 8
  %v399 = load i64, ptr %slot60, align 8
  %v400 = load i64, ptr %slot13, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot13, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot61, align 8
  %v405 = load i64, ptr %slot12, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot62, align 8
  %v408 = load i64, ptr %slot62, align 8
  %v409 = load i64, ptr %slot61, align 8
  %ovpair411 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v408, i64 %v409)
  %op410 = extractvalue { i64, i1 } %ovpair411, 0
  %ov412 = extractvalue { i64, i1 } %ovpair411, 1
  store i64 %op410, ptr %slot63, align 8
  %v413 = load i64, ptr %slot62, align 8
  %v414 = load i64, ptr %slot63, align 8
  %op415 = xor i64 %v413, %v414
  store i64 %op415, ptr %slot64, align 8
  %v416 = load i64, ptr %slot61, align 8
  %v417 = load i64, ptr %slot63, align 8
  %op418 = xor i64 %v416, %v417
  store i64 %op418, ptr %slot65, align 8
  %v419 = load i64, ptr %slot64, align 8
  %v420 = load i64, ptr %slot65, align 8
  %op421 = and i64 %v419, %v420
  store i64 %op421, ptr %slot66, align 8
  %cv422 = zext i1 %ov412 to i64
  store i64 %cv422, ptr %slot67, align 8
  %v423 = load i64, ptr %slot67, align 8
  %cond424 = icmp ne i64 %v423, 0
  br i1 %cond424, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v425 = load i64, ptr %slot1, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %v427 = load i64, ptr %slot62, align 8
  %v428 = load i64, ptr %slot61, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p426, i64 0, i64 %v427, i64 %v428, i64 64) nomerge, !dbg !112
  unreachable
bb_checked47:
  %v429 = load i64, ptr %slot63, align 8
  %v430 = load i64, ptr %slot12, align 8
  %p431 = inttoptr i64 %v430 to ptr
  store i64 %v429, ptr %p431, align 8, !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot13, align 8
  %p433 = inttoptr i64 %v432 to ptr
  store i64 1000000007, ptr %p433, align 8, !alias.scope !3, !noalias !4
  %v434 = load i64, ptr %slot13, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i64, ptr %p435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld436, ptr %slot68, align 8
  %v437 = load i64, ptr %slot12, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld439, ptr %slot69, align 8
  %v440 = load i64, ptr %slot68, align 8
  %cmp441 = icmp eq i64 %v440, 0
  %cv442 = zext i1 %cmp441 to i64
  store i64 %cv442, ptr %slot70, align 8
  %v443 = load i64, ptr %slot70, align 8
  %cond444 = icmp ne i64 %v443, 0
  br i1 %cond444, label %bb_division54, label %bb_nonzero54
bb_division54:
  %v445 = load i64, ptr %slot1, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %v447 = load i64, ptr %slot69, align 8
  %v448 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_division(ptr %p446, i64 6, i64 %v447, i64 %v448) nomerge, !dbg !114
  unreachable
bb_nonzero54:
  %v449 = load i64, ptr %slot69, align 8
  %cmp450 = icmp eq i64 %v449, 9223372036854775808
  %cv451 = zext i1 %cmp450 to i64
  store i64 %cv451, ptr %slot71, align 8
  %v452 = load i64, ptr %slot68, align 8
  %cmp453 = icmp eq i64 %v452, 18446744073709551615
  %cv454 = zext i1 %cmp453 to i64
  store i64 %cv454, ptr %slot72, align 8
  %v455 = load i64, ptr %slot71, align 8
  %v456 = load i64, ptr %slot72, align 8
  %op457 = and i64 %v455, %v456
  store i64 %op457, ptr %slot73, align 8
  %v458 = load i64, ptr %slot73, align 8
  %neg459 = sub i64 0, %v458
  store i64 %neg459, ptr %slot74, align 8
  %v460 = load i64, ptr %slot68, align 8
  %op461 = xor i64 %v460, 1
  store i64 %op461, ptr %slot75, align 8
  %v462 = load i64, ptr %slot75, align 8
  %v463 = load i64, ptr %slot74, align 8
  %op464 = and i64 %v462, %v463
  store i64 %op464, ptr %slot75, align 8
  %v465 = load i64, ptr %slot68, align 8
  %v466 = load i64, ptr %slot75, align 8
  %op467 = xor i64 %v465, %v466
  store i64 %op467, ptr %slot76, align 8
  %v468 = load i64, ptr %slot69, align 8
  %v469 = load i64, ptr %slot76, align 8
  %op470 = srem i64 %v468, %v469
  store i64 %op470, ptr %slot77, align 8
  %v471 = load i64, ptr %slot77, align 8
  %cmp472 = icmp ne i64 %v471, 0
  %cv473 = zext i1 %cmp472 to i64
  store i64 %cv473, ptr %slot78, align 8
  %v474 = load i64, ptr %slot77, align 8
  %v475 = load i64, ptr %slot76, align 8
  %op476 = xor i64 %v474, %v475
  store i64 %op476, ptr %slot79, align 8
  %v477 = load i64, ptr %slot79, align 8
  %cmp478 = icmp slt i64 %v477, 0
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot80, align 8
  %v480 = load i64, ptr %slot78, align 8
  %v481 = load i64, ptr %slot80, align 8
  %op482 = and i64 %v480, %v481
  store i64 %op482, ptr %slot81, align 8
  %v483 = load i64, ptr %slot81, align 8
  %neg484 = sub i64 0, %v483
  store i64 %neg484, ptr %slot82, align 8
  %v485 = load i64, ptr %slot76, align 8
  %v486 = load i64, ptr %slot82, align 8
  %op487 = and i64 %v485, %v486
  store i64 %op487, ptr %slot83, align 8
  %v488 = load i64, ptr %slot77, align 8
  %v489 = load i64, ptr %slot83, align 8
  %op490 = add i64 %v488, %v489
  store i64 %op490, ptr %slot77, align 8
  %v491 = load i64, ptr %slot77, align 8
  %v492 = load i64, ptr %slot12, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i64 %v491, ptr %p493, align 8, !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot12, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %ld496 = load i64, ptr %p495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld496, ptr %slot84, align 8
  %v497 = load i64, ptr %slot7, align 8
  store i64 %v497, ptr %slot85, align 8
  %v498 = load i64, ptr %slot84, align 8
  %v499 = load i64, ptr %slot85, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i64 %v498, ptr %p500, align 8, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot8, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %ld503 = load i64, ptr %p502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld503, ptr %slot86, align 8
  %v504 = load i64, ptr %slot86, align 8
  %v505 = load i64, ptr %slot12, align 8
  %p506 = inttoptr i64 %v505 to ptr
  store i64 %v504, ptr %p506, align 8, !alias.scope !3, !noalias !4
  %v507 = load i64, ptr %slot13, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i64 1, ptr %p508, align 8, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot13, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %ld511 = load i64, ptr %p510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld511, ptr %slot87, align 8
  %v512 = load i64, ptr %slot12, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %ld514 = load i64, ptr %p513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld514, ptr %slot88, align 8
  %v515 = load i64, ptr %slot88, align 8
  %v516 = load i64, ptr %slot87, align 8
  %op517 = add i64 %v515, %v516
  store i64 %op517, ptr %slot89, align 8
  %v518 = load i64, ptr %slot89, align 8
  %v519 = load i64, ptr %slot12, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i64 %v518, ptr %p520, align 8, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i64, ptr %p522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld523, ptr %slot90, align 8
  %v524 = load i64, ptr %slot8, align 8
  store i64 %v524, ptr %slot91, align 8
  %v525 = load i64, ptr %slot90, align 8
  %v526 = load i64, ptr %slot91, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 %v525, ptr %p527, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v528 = load i64, ptr %slot8, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot92, align 8
  %v531 = load i64, ptr %slot92, align 8
  %v532 = load i64, ptr %slot12, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 %v531, ptr %p533, align 8, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot9, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot93, align 8
  %v537 = load i64, ptr %slot93, align 8
  %v538 = load i64, ptr %slot13, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i64 %v537, ptr %p539, align 8, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot13, align 8
  %p541 = inttoptr i64 %v540 to ptr
  %ld542 = load i64, ptr %p541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld542, ptr %slot94, align 8
  %v543 = load i64, ptr %slot12, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i64, ptr %p544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld545, ptr %slot95, align 8
  %v546 = load i64, ptr %slot95, align 8
  %v547 = load i64, ptr %slot94, align 8
  %cmp548 = icmp slt i64 %v546, %v547
  %cv549 = zext i1 %cmp548 to i64
  store i64 %cv549, ptr %slot96, align 8
  %v550 = load i64, ptr %slot96, align 8
  %v551 = load i64, ptr %slot12, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 %v550, ptr %p552, align 8, !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot12, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot97, align 8
  %v556 = load i64, ptr %slot97, align 8
  %cond557 = icmp ne i64 %v556, 0
  br i1 %cond557, label %bb_next82, label %bb_i35
bb_next82:
  %v558 = load i64, ptr %slot8, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %ld560 = load i64, ptr %p559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld560, ptr %slot98, align 8
  %v561 = load i64, ptr %slot98, align 8
  %v562 = load i64, ptr %slot12, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot13, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i64 3, ptr %p565, align 8, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot13, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot99, align 8
  %v569 = load i64, ptr %slot12, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot100, align 8
  %v572 = load i64, ptr %slot99, align 8
  %cmp573 = icmp eq i64 %v572, 0
  %cv574 = zext i1 %cmp573 to i64
  store i64 %cv574, ptr %slot101, align 8
  %v575 = load i64, ptr %slot101, align 8
  %cond576 = icmp ne i64 %v575, 0
  br i1 %cond576, label %bb_division85, label %bb_nonzero85
bb_division85:
  %v577 = load i64, ptr %slot1, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %v579 = load i64, ptr %slot100, align 8
  %v580 = load i64, ptr %slot99, align 8
  call void @myl_qbe_fail_division(ptr %p578, i64 6, i64 %v579, i64 %v580) nomerge, !dbg !116
  unreachable
bb_nonzero85:
  %v581 = load i64, ptr %slot100, align 8
  %cmp582 = icmp eq i64 %v581, 9223372036854775808
  %cv583 = zext i1 %cmp582 to i64
  store i64 %cv583, ptr %slot102, align 8
  %v584 = load i64, ptr %slot99, align 8
  %cmp585 = icmp eq i64 %v584, 18446744073709551615
  %cv586 = zext i1 %cmp585 to i64
  store i64 %cv586, ptr %slot103, align 8
  %v587 = load i64, ptr %slot102, align 8
  %v588 = load i64, ptr %slot103, align 8
  %op589 = and i64 %v587, %v588
  store i64 %op589, ptr %slot104, align 8
  %v590 = load i64, ptr %slot104, align 8
  %neg591 = sub i64 0, %v590
  store i64 %neg591, ptr %slot105, align 8
  %v592 = load i64, ptr %slot99, align 8
  %op593 = xor i64 %v592, 1
  store i64 %op593, ptr %slot106, align 8
  %v594 = load i64, ptr %slot106, align 8
  %v595 = load i64, ptr %slot105, align 8
  %op596 = and i64 %v594, %v595
  store i64 %op596, ptr %slot106, align 8
  %v597 = load i64, ptr %slot99, align 8
  %v598 = load i64, ptr %slot106, align 8
  %op599 = xor i64 %v597, %v598
  store i64 %op599, ptr %slot107, align 8
  %v600 = load i64, ptr %slot100, align 8
  %v601 = load i64, ptr %slot107, align 8
  %op602 = srem i64 %v600, %v601
  store i64 %op602, ptr %slot108, align 8
  %v603 = load i64, ptr %slot108, align 8
  %cmp604 = icmp ne i64 %v603, 0
  %cv605 = zext i1 %cmp604 to i64
  store i64 %cv605, ptr %slot109, align 8
  %v606 = load i64, ptr %slot108, align 8
  %v607 = load i64, ptr %slot107, align 8
  %op608 = xor i64 %v606, %v607
  store i64 %op608, ptr %slot110, align 8
  %v609 = load i64, ptr %slot110, align 8
  %cmp610 = icmp slt i64 %v609, 0
  %cv611 = zext i1 %cmp610 to i64
  store i64 %cv611, ptr %slot111, align 8
  %v612 = load i64, ptr %slot109, align 8
  %v613 = load i64, ptr %slot111, align 8
  %op614 = and i64 %v612, %v613
  store i64 %op614, ptr %slot112, align 8
  %v615 = load i64, ptr %slot112, align 8
  %neg616 = sub i64 0, %v615
  store i64 %neg616, ptr %slot113, align 8
  %v617 = load i64, ptr %slot107, align 8
  %v618 = load i64, ptr %slot113, align 8
  %op619 = and i64 %v617, %v618
  store i64 %op619, ptr %slot114, align 8
  %v620 = load i64, ptr %slot108, align 8
  %v621 = load i64, ptr %slot114, align 8
  %op622 = add i64 %v620, %v621
  store i64 %op622, ptr %slot108, align 8
  %v623 = load i64, ptr %slot108, align 8
  %v624 = load i64, ptr %slot12, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i64 %v623, ptr %p625, align 8, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot13, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i64 0, ptr %p627, align 8, !alias.scope !3, !noalias !4
  %v628 = load i64, ptr %slot13, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i64, ptr %p629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld630, ptr %slot115, align 8
  %v631 = load i64, ptr %slot12, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i64, ptr %p632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld633, ptr %slot116, align 8
  %v634 = load i64, ptr %slot116, align 8
  %v635 = load i64, ptr %slot115, align 8
  %cmp636 = icmp eq i64 %v634, %v635
  %cv637 = zext i1 %cmp636 to i64
  store i64 %cv637, ptr %slot117, align 8
  %v638 = load i64, ptr %slot117, align 8
  %v639 = load i64, ptr %slot12, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 %v638, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot12, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot118, align 8
  %v644 = load i64, ptr %slot118, align 8
  %cond645 = icmp ne i64 %v644, 0
  br i1 %cond645, label %bb_next103, label %bb_i20
bb_next103:
  %v646 = load i64, ptr %slot12, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i64 17, ptr %p647, align 8, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot12, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot119, align 8
  %v651 = load i64, ptr %slot119, align 8
  %neg652 = sub i64 0, %v651
  store i64 %neg652, ptr %slot120, align 8
  %v653 = load i64, ptr %slot119, align 8
  %cmp654 = icmp eq i64 %v653, 9223372036854775808
  %cv655 = zext i1 %cmp654 to i64
  store i64 %cv655, ptr %slot121, align 8
  %v656 = load i64, ptr %slot121, align 8
  %cond657 = icmp ne i64 %v656, 0
  br i1 %cond657, label %bb_neg_overflow104, label %bb_neg_checked104
bb_neg_overflow104:
  %p658 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64) to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !4, !noalias !3
  store i64 %ld659, ptr %slot122, align 8
  %v660 = load i64, ptr %slot122, align 8
  %op661 = add i64 %v660, 1
  store i64 %op661, ptr %slot123, align 8
  %v662 = load i64, ptr %slot123, align 8
  %p663 = inttoptr i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64) to ptr
  store i64 %v662, ptr %p663, align 8, !alias.scope !4, !noalias !3
  %p664 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 to i64), ptr %p664, align 8, !alias.scope !4, !noalias !3
  %v665 = load i64, ptr %slot1, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %v667 = load i64, ptr %slot119, align 8
  %call668 = call i64 @myl_qbe_int_neg(ptr %p666, i64 1, i64 64, i64 %v667) nomerge, !dbg !110
  unreachable
bb_neg_checked104:
  %v669 = load i64, ptr %slot120, align 8
  %v670 = load i64, ptr %slot12, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i64 %v669, ptr %p671, align 8, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot12, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld674, ptr %slot124, align 8
  %v675 = load i64, ptr %slot10, align 8
  store i64 %v675, ptr %slot125, align 8
  %v676 = load i64, ptr %slot124, align 8
  %v677 = load i64, ptr %slot125, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i64 %v676, ptr %p678, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i20:
  %v679 = load i64, ptr %slot12, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 23, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot12, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i64, ptr %p682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld683, ptr %slot126, align 8
  %v684 = load i64, ptr %slot10, align 8
  store i64 %v684, ptr %slot127, align 8
  %v685 = load i64, ptr %slot126, align 8
  %v686 = load i64, ptr %slot127, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v688 = load i64, ptr %slot10, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot128, align 8
  %v691 = load i64, ptr %slot128, align 8
  %v692 = load i64, ptr %slot12, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot12, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot129, align 8
  %v697 = load i64, ptr %slot11, align 8
  store i64 %v697, ptr %slot130, align 8
  %v698 = load i64, ptr %slot129, align 8
  %v699 = load i64, ptr %slot130, align 8
  %p700 = inttoptr i64 %v699 to ptr
  store i64 %v698, ptr %p700, align 8, !alias.scope !3, !noalias !4
  %v701 = load i64, ptr %slot7, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %ld703 = load i64, ptr %p702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld703, ptr %slot131, align 8
  %v704 = load i64, ptr %slot131, align 8
  %v705 = load i64, ptr %slot12, align 8
  %p706 = inttoptr i64 %v705 to ptr
  store i64 %v704, ptr %p706, align 8, !alias.scope !3, !noalias !4
  %v707 = load i64, ptr %slot11, align 8
  %p708 = inttoptr i64 %v707 to ptr
  %ld709 = load i64, ptr %p708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld709, ptr %slot132, align 8
  %v710 = load i64, ptr %slot132, align 8
  %v711 = load i64, ptr %slot13, align 8
  %p712 = inttoptr i64 %v711 to ptr
  store i64 %v710, ptr %p712, align 8, !alias.scope !3, !noalias !4
  %v713 = load i64, ptr %slot13, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %ld715 = load i64, ptr %p714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld715, ptr %slot133, align 8
  %v716 = load i64, ptr %slot12, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot134, align 8
  %v719 = load i64, ptr %slot134, align 8
  %v720 = load i64, ptr %slot133, align 8
  %ovpair722 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v719, i64 %v720)
  %op721 = extractvalue { i64, i1 } %ovpair722, 0
  %ov723 = extractvalue { i64, i1 } %ovpair722, 1
  store i64 %op721, ptr %slot135, align 8
  %v724 = load i64, ptr %slot134, align 8
  %v725 = load i64, ptr %slot135, align 8
  %op726 = xor i64 %v724, %v725
  store i64 %op726, ptr %slot136, align 8
  %v727 = load i64, ptr %slot133, align 8
  %v728 = load i64, ptr %slot135, align 8
  %op729 = xor i64 %v727, %v728
  store i64 %op729, ptr %slot137, align 8
  %v730 = load i64, ptr %slot136, align 8
  %v731 = load i64, ptr %slot137, align 8
  %op732 = and i64 %v730, %v731
  store i64 %op732, ptr %slot138, align 8
  %cv733 = zext i1 %ov723 to i64
  store i64 %cv733, ptr %slot139, align 8
  %v734 = load i64, ptr %slot139, align 8
  %cond735 = icmp ne i64 %v734, 0
  br i1 %cond735, label %bb_overflow117, label %bb_checked117
bb_overflow117:
  %v736 = load i64, ptr %slot1, align 8
  %p737 = inttoptr i64 %v736 to ptr
  %v738 = load i64, ptr %slot134, align 8
  %v739 = load i64, ptr %slot133, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p737, i64 0, i64 %v738, i64 %v739, i64 64) nomerge, !dbg !112
  unreachable
bb_checked117:
  %v740 = load i64, ptr %slot135, align 8
  %v741 = load i64, ptr %slot12, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i64 %v740, ptr %p742, align 8, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot13, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i64 1000000007, ptr %p744, align 8, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot13, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld747, ptr %slot140, align 8
  %v748 = load i64, ptr %slot12, align 8
  %p749 = inttoptr i64 %v748 to ptr
  %ld750 = load i64, ptr %p749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld750, ptr %slot141, align 8
  %v751 = load i64, ptr %slot140, align 8
  %cmp752 = icmp eq i64 %v751, 0
  %cv753 = zext i1 %cmp752 to i64
  store i64 %cv753, ptr %slot142, align 8
  %v754 = load i64, ptr %slot142, align 8
  %cond755 = icmp ne i64 %v754, 0
  br i1 %cond755, label %bb_division124, label %bb_nonzero124
bb_division124:
  %v756 = load i64, ptr %slot1, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %v758 = load i64, ptr %slot141, align 8
  %v759 = load i64, ptr %slot140, align 8
  call void @myl_qbe_fail_division(ptr %p757, i64 6, i64 %v758, i64 %v759) nomerge, !dbg !114
  unreachable
bb_nonzero124:
  %v760 = load i64, ptr %slot141, align 8
  %cmp761 = icmp eq i64 %v760, 9223372036854775808
  %cv762 = zext i1 %cmp761 to i64
  store i64 %cv762, ptr %slot143, align 8
  %v763 = load i64, ptr %slot140, align 8
  %cmp764 = icmp eq i64 %v763, 18446744073709551615
  %cv765 = zext i1 %cmp764 to i64
  store i64 %cv765, ptr %slot144, align 8
  %v766 = load i64, ptr %slot143, align 8
  %v767 = load i64, ptr %slot144, align 8
  %op768 = and i64 %v766, %v767
  store i64 %op768, ptr %slot145, align 8
  %v769 = load i64, ptr %slot145, align 8
  %neg770 = sub i64 0, %v769
  store i64 %neg770, ptr %slot146, align 8
  %v771 = load i64, ptr %slot140, align 8
  %op772 = xor i64 %v771, 1
  store i64 %op772, ptr %slot147, align 8
  %v773 = load i64, ptr %slot147, align 8
  %v774 = load i64, ptr %slot146, align 8
  %op775 = and i64 %v773, %v774
  store i64 %op775, ptr %slot147, align 8
  %v776 = load i64, ptr %slot140, align 8
  %v777 = load i64, ptr %slot147, align 8
  %op778 = xor i64 %v776, %v777
  store i64 %op778, ptr %slot148, align 8
  %v779 = load i64, ptr %slot141, align 8
  %v780 = load i64, ptr %slot148, align 8
  %op781 = srem i64 %v779, %v780
  store i64 %op781, ptr %slot149, align 8
  %v782 = load i64, ptr %slot149, align 8
  %cmp783 = icmp ne i64 %v782, 0
  %cv784 = zext i1 %cmp783 to i64
  store i64 %cv784, ptr %slot150, align 8
  %v785 = load i64, ptr %slot149, align 8
  %v786 = load i64, ptr %slot148, align 8
  %op787 = xor i64 %v785, %v786
  store i64 %op787, ptr %slot151, align 8
  %v788 = load i64, ptr %slot151, align 8
  %cmp789 = icmp slt i64 %v788, 0
  %cv790 = zext i1 %cmp789 to i64
  store i64 %cv790, ptr %slot152, align 8
  %v791 = load i64, ptr %slot150, align 8
  %v792 = load i64, ptr %slot152, align 8
  %op793 = and i64 %v791, %v792
  store i64 %op793, ptr %slot153, align 8
  %v794 = load i64, ptr %slot153, align 8
  %neg795 = sub i64 0, %v794
  store i64 %neg795, ptr %slot154, align 8
  %v796 = load i64, ptr %slot148, align 8
  %v797 = load i64, ptr %slot154, align 8
  %op798 = and i64 %v796, %v797
  store i64 %op798, ptr %slot155, align 8
  %v799 = load i64, ptr %slot149, align 8
  %v800 = load i64, ptr %slot155, align 8
  %op801 = add i64 %v799, %v800
  store i64 %op801, ptr %slot149, align 8
  %v802 = load i64, ptr %slot149, align 8
  %v803 = load i64, ptr %slot12, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 %v802, ptr %p804, align 8, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot12, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot156, align 8
  %v808 = load i64, ptr %slot7, align 8
  store i64 %v808, ptr %slot157, align 8
  %v809 = load i64, ptr %slot156, align 8
  %v810 = load i64, ptr %slot157, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 %v809, ptr %p811, align 8, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot8, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot158, align 8
  %v815 = load i64, ptr %slot158, align 8
  %v816 = load i64, ptr %slot12, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot13, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i64 1, ptr %p819, align 8, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot13, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %ld822 = load i64, ptr %p821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld822, ptr %slot159, align 8
  %v823 = load i64, ptr %slot12, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot160, align 8
  %v826 = load i64, ptr %slot160, align 8
  %v827 = load i64, ptr %slot159, align 8
  %op828 = add i64 %v826, %v827
  %ovpair829 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v826, i64 %v827)
  %ov830 = extractvalue { i64, i1 } %ovpair829, 1
  store i64 %op828, ptr %slot161, align 8
  %cv831 = zext i1 %ov830 to i64
  store i64 %cv831, ptr %slot162, align 8
  %v832 = load i64, ptr %slot162, align 8
  %cond833 = icmp ne i64 %v832, 0
  br i1 %cond833, label %bb_overflow143, label %bb_checked143
bb_overflow143:
  %v834 = load i64, ptr %slot1, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %v836 = load i64, ptr %slot160, align 8
  %v837 = load i64, ptr %slot159, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p835, i64 0, i64 %v836, i64 %v837, i64 64) nomerge, !dbg !118
  unreachable
bb_checked143:
  %v838 = load i64, ptr %slot161, align 8
  %v839 = load i64, ptr %slot12, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i64 %v838, ptr %p840, align 8, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot12, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i64, ptr %p842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld843, ptr %slot163, align 8
  %v844 = load i64, ptr %slot8, align 8
  store i64 %v844, ptr %slot164, align 8
  %v845 = load i64, ptr %slot163, align 8
  %v846 = load i64, ptr %slot164, align 8
  %p847 = inttoptr i64 %v846 to ptr
  store i64 %v845, ptr %p847, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i35:
  %v848 = load i64, ptr %slot7, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %ld850 = load i64, ptr %p849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld850, ptr %slot165, align 8
  %v851 = load i64, ptr %slot165, align 8
  %v852 = load i64, ptr %slot12, align 8
  %p853 = inttoptr i64 %v852 to ptr
  store i64 %v851, ptr %p853, align 8, !alias.scope !3, !noalias !4
  %v854 = load i64, ptr %slot12, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld856, ptr %slot166, align 8
  %v857 = load i64, ptr %slot166, align 8
  ret i64 %v857
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite0 = external global i8, align 8
@myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638_rcsite1 = external global i8, align 8
@myl_rc_site_current = external global i8, align 8

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", linkageName: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4316030661171315038, i64 0, !"myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!110 = !DILocation(line: 18, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
