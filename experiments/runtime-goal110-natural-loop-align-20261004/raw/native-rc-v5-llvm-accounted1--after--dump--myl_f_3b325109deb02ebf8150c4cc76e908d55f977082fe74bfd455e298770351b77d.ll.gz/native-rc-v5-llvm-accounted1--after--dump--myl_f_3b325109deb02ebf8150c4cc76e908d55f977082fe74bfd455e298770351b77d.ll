target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v64 = load i64, ptr %slot1, align 8
  %op65 = add i64 %v64, 32
  store i64 %op65, ptr %slot4, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot5, align 8
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot6, align 8
  %mem70 = alloca i8, i64 8, align 8
  %ptr71 = ptrtoint ptr %mem70 to i64
  store i64 %ptr71, ptr %slot7, align 8
  %mem72 = alloca i8, i64 8, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot8, align 8
  %v74 = load i64, ptr %slot1, align 8
  %op75 = add i64 %v74, 8
  store i64 %op75, ptr %slot9, align 8
  %v76 = load i64, ptr %slot9, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %ld78 = load i64, ptr %p77, align 8, !alias.scope !4, !noalias !3
  store i64 %ld78, ptr %slot10, align 8
  %v79 = load i64, ptr %slot1, align 8
  %op80 = add i64 %v79, 56
  store i64 %op80, ptr %slot11, align 8
  %v81 = load i64, ptr %slot11, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !4, !noalias !3
  store i64 %ld83, ptr %slot12, align 8
  %v84 = load i64, ptr %slot10, align 8
  %v85 = load i64, ptr %slot12, align 8
  %cmp86 = icmp eq i64 %v84, %v85
  %cv87 = zext i1 %cmp86 to i64
  store i64 %cv87, ptr %slot13, align 8
  %v88 = load i64, ptr %slot13, align 8
  %cond89 = icmp ne i64 %v88, 0
  br i1 %cond89, label %bb_limitfail2, label %bb_frameadmit0
bb_limitfail2:
  %v90 = load i64, ptr %slot1, align 8
  %p91 = inttoptr i64 %v90 to ptr
  call void @myl_qbe_fail_frame(ptr %p91)
  br label %bb_entry_failure
bb_frameadmit0:
  %mem92 = alloca i8, i64 32, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot14, align 8
  %v94 = load i64, ptr %slot1, align 8
  %op95 = add i64 %v94, 48
  store i64 %op95, ptr %slot15, align 8
  %v96 = load i64, ptr %slot15, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !4, !noalias !3
  store i64 %ld98, ptr %slot16, align 8
  %v99 = load i64, ptr %slot16, align 8
  %v100 = load i64, ptr %slot14, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 %v99, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot14, align 8
  %p104 = inttoptr i64 %v102 to ptr
  %gep105 = getelementptr i8, ptr %p104, i64 8
  %op103 = ptrtoint ptr %gep105 to i64
  store i64 %op103, ptr %slot17, align 8
  %v106 = load i64, ptr %slot17, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 ptrtoint (ptr @myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d_meta to i64), ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot14, align 8
  %p110 = inttoptr i64 %v108 to ptr
  %gep111 = getelementptr i8, ptr %p110, i64 16
  %op109 = ptrtoint ptr %gep111 to i64
  store i64 %op109, ptr %slot18, align 8
  %v112 = load i64, ptr %slot18, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 0, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot14, align 8
  %v115 = load i64, ptr %slot15, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !4, !noalias !3
  %v117 = load i64, ptr %slot10, align 8
  %op118 = add i64 %v117, 1
  store i64 %op118, ptr %slot19, align 8
  %v119 = load i64, ptr %slot19, align 8
  %v120 = load i64, ptr %slot9, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 %v119, ptr %p121, align 8, !alias.scope !4, !noalias !3
  %v122 = load i64, ptr %slot14, align 8
  %p124 = inttoptr i64 %v122 to ptr
  %gep125 = getelementptr i8, ptr %p124, i64 16
  %op123 = ptrtoint ptr %gep125 to i64
  store i64 %op123, ptr %slot20, align 8
  %v126 = load i64, ptr %slot2, align 8
  %v127 = load i64, ptr %slot5, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot3, align 8
  %v130 = load i64, ptr %slot6, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i64 %v129, ptr %p131, align 8, !alias.scope !3, !noalias !4
  %v132 = load i64, ptr %slot1, align 8
  %op133 = add i64 %v132, 16
  store i64 %op133, ptr %slot21, align 8
  br label %bb_i0
bb_i0:
  %v134 = load i64, ptr %slot20, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i64 0, ptr %p135, align 8, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot1, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !4, !noalias !3
  store i64 %ld138, ptr %slot22, align 8
  %v139 = load i64, ptr %slot21, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !4, !noalias !3
  store i64 %ld141, ptr %slot23, align 8
  %v142 = load i64, ptr %slot22, align 8
  %v143 = load i64, ptr %slot23, align 8
  %cmp144 = icmp eq i64 %v142, %v143
  %cv145 = zext i1 %cmp144 to i64
  store i64 %cv145, ptr %slot24, align 8
  %v146 = load i64, ptr %slot24, align 8
  %cond147 = icmp ne i64 %v146, 0
  br i1 %cond147, label %bb_step_limit, label %bb_step21
bb_step21:
  %v148 = load i64, ptr %slot22, align 8
  %op149 = add i64 %v148, 1
  store i64 %op149, ptr %slot25, align 8
  %v150 = load i64, ptr %slot25, align 8
  %v151 = load i64, ptr %slot1, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !4, !noalias !3
  %v153 = load i64, ptr %slot5, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %ld155 = load i64, ptr %p154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld155, ptr %slot26, align 8
  %v156 = load i64, ptr %slot26, align 8
  %v157 = load i64, ptr %slot7, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 %v156, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot20, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 1, ptr %p160, align 8, !alias.scope !3, !noalias !4
  %v161 = load i64, ptr %slot1, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %ld163 = load i64, ptr %p162, align 8, !alias.scope !4, !noalias !3
  store i64 %ld163, ptr %slot27, align 8
  %v164 = load i64, ptr %slot21, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %ld166 = load i64, ptr %p165, align 8, !alias.scope !4, !noalias !3
  store i64 %ld166, ptr %slot28, align 8
  %v167 = load i64, ptr %slot27, align 8
  %v168 = load i64, ptr %slot28, align 8
  %cmp169 = icmp eq i64 %v167, %v168
  %cv170 = zext i1 %cmp169 to i64
  store i64 %cv170, ptr %slot29, align 8
  %v171 = load i64, ptr %slot29, align 8
  %cond172 = icmp ne i64 %v171, 0
  br i1 %cond172, label %bb_step_limit, label %bb_step26
bb_step26:
  %v173 = load i64, ptr %slot27, align 8
  %op174 = add i64 %v173, 1
  store i64 %op174, ptr %slot30, align 8
  %v175 = load i64, ptr %slot30, align 8
  %v176 = load i64, ptr %slot1, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !4, !noalias !3
  %v178 = load i64, ptr %slot6, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot31, align 8
  %v181 = load i64, ptr %slot31, align 8
  %v182 = load i64, ptr %slot8, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot20, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 2, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot1, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !4, !noalias !3
  store i64 %ld188, ptr %slot32, align 8
  %v189 = load i64, ptr %slot21, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !4, !noalias !3
  store i64 %ld191, ptr %slot33, align 8
  %v192 = load i64, ptr %slot32, align 8
  %v193 = load i64, ptr %slot33, align 8
  %cmp194 = icmp eq i64 %v192, %v193
  %cv195 = zext i1 %cmp194 to i64
  store i64 %cv195, ptr %slot34, align 8
  %v196 = load i64, ptr %slot34, align 8
  %cond197 = icmp ne i64 %v196, 0
  br i1 %cond197, label %bb_step_limit, label %bb_step31
bb_step31:
  %v198 = load i64, ptr %slot32, align 8
  %op199 = add i64 %v198, 1
  store i64 %op199, ptr %slot35, align 8
  %v200 = load i64, ptr %slot35, align 8
  %v201 = load i64, ptr %slot1, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !4, !noalias !3
  %v203 = load i64, ptr %slot8, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot36, align 8
  %v206 = load i64, ptr %slot7, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot37, align 8
  %v209 = load i64, ptr %slot36, align 8
  %cmp210 = icmp eq i64 %v209, 0
  %cv211 = zext i1 %cmp210 to i64
  store i64 %cv211, ptr %slot38, align 8
  %v212 = load i64, ptr %slot38, align 8
  %cond213 = icmp ne i64 %v212, 0
  br i1 %cond213, label %bb_division34, label %bb_nonzero34
bb_division34:
  %v214 = load i64, ptr %slot1, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %v216 = load i64, ptr %slot37, align 8
  %v217 = load i64, ptr %slot36, align 8
  call void @myl_qbe_fail_division(ptr %p215, i64 6, i64 %v216, i64 %v217)
  br label %bb_failure
bb_nonzero34:
  %v218 = load i64, ptr %slot37, align 8
  %cmp219 = icmp eq i64 %v218, 9223372036854775808
  %cv220 = zext i1 %cmp219 to i64
  store i64 %cv220, ptr %slot39, align 8
  %v221 = load i64, ptr %slot36, align 8
  %cmp222 = icmp eq i64 %v221, 18446744073709551615
  %cv223 = zext i1 %cmp222 to i64
  store i64 %cv223, ptr %slot40, align 8
  %v224 = load i64, ptr %slot39, align 8
  %v225 = load i64, ptr %slot40, align 8
  %op226 = and i64 %v224, %v225
  store i64 %op226, ptr %slot41, align 8
  %v227 = load i64, ptr %slot41, align 8
  %neg228 = sub i64 0, %v227
  store i64 %neg228, ptr %slot42, align 8
  %v229 = load i64, ptr %slot36, align 8
  %op230 = xor i64 %v229, 1
  store i64 %op230, ptr %slot43, align 8
  %v231 = load i64, ptr %slot43, align 8
  %v232 = load i64, ptr %slot42, align 8
  %op233 = and i64 %v231, %v232
  store i64 %op233, ptr %slot43, align 8
  %v234 = load i64, ptr %slot36, align 8
  %v235 = load i64, ptr %slot43, align 8
  %op236 = xor i64 %v234, %v235
  store i64 %op236, ptr %slot44, align 8
  %v237 = load i64, ptr %slot37, align 8
  %v238 = load i64, ptr %slot44, align 8
  %op239 = srem i64 %v237, %v238
  store i64 %op239, ptr %slot45, align 8
  %v240 = load i64, ptr %slot45, align 8
  %cmp241 = icmp ne i64 %v240, 0
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot46, align 8
  %v243 = load i64, ptr %slot45, align 8
  %v244 = load i64, ptr %slot44, align 8
  %op245 = xor i64 %v243, %v244
  store i64 %op245, ptr %slot47, align 8
  %v246 = load i64, ptr %slot47, align 8
  %cmp247 = icmp slt i64 %v246, 0
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot48, align 8
  %v249 = load i64, ptr %slot46, align 8
  %v250 = load i64, ptr %slot48, align 8
  %op251 = and i64 %v249, %v250
  store i64 %op251, ptr %slot49, align 8
  %v252 = load i64, ptr %slot49, align 8
  %neg253 = sub i64 0, %v252
  store i64 %neg253, ptr %slot50, align 8
  %v254 = load i64, ptr %slot44, align 8
  %v255 = load i64, ptr %slot50, align 8
  %op256 = and i64 %v254, %v255
  store i64 %op256, ptr %slot51, align 8
  %v257 = load i64, ptr %slot45, align 8
  %v258 = load i64, ptr %slot51, align 8
  %op259 = add i64 %v257, %v258
  store i64 %op259, ptr %slot45, align 8
  %v260 = load i64, ptr %slot45, align 8
  %v261 = load i64, ptr %slot7, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i64 %v260, ptr %p262, align 8, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot4, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !4, !noalias !3
  store i64 %ld265, ptr %slot52, align 8
  %v266 = load i64, ptr %slot52, align 8
  %cond267 = icmp ne i64 %v266, 0
  br i1 %cond267, label %bb_failure, label %bb_ok48
bb_ok48:
  %v268 = load i64, ptr %slot20, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 3, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot1, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !4, !noalias !3
  store i64 %ld272, ptr %slot53, align 8
  %v273 = load i64, ptr %slot21, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !4, !noalias !3
  store i64 %ld275, ptr %slot54, align 8
  %v276 = load i64, ptr %slot53, align 8
  %v277 = load i64, ptr %slot54, align 8
  %cmp278 = icmp eq i64 %v276, %v277
  %cv279 = zext i1 %cmp278 to i64
  store i64 %cv279, ptr %slot55, align 8
  %v280 = load i64, ptr %slot55, align 8
  %cond281 = icmp ne i64 %v280, 0
  br i1 %cond281, label %bb_step_limit, label %bb_step52
bb_step52:
  %v282 = load i64, ptr %slot53, align 8
  %op283 = add i64 %v282, 1
  store i64 %op283, ptr %slot56, align 8
  %v284 = load i64, ptr %slot56, align 8
  %v285 = load i64, ptr %slot1, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !4, !noalias !3
  %v287 = load i64, ptr %slot7, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot57, align 8
  %v290 = load i64, ptr %slot14, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot58, align 8
  %v293 = load i64, ptr %slot58, align 8
  %v294 = load i64, ptr %slot15, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !4, !noalias !3
  %v296 = load i64, ptr %slot9, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !4, !noalias !3
  store i64 %ld298, ptr %slot59, align 8
  %v299 = load i64, ptr %slot59, align 8
  %op300 = sub i64 %v299, 1
  store i64 %op300, ptr %slot60, align 8
  %v301 = load i64, ptr %slot60, align 8
  %v302 = load i64, ptr %slot9, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 %v301, ptr %p303, align 8, !alias.scope !4, !noalias !3
  %v304 = load i64, ptr %slot57, align 8
  ret i64 %v304
bb_step_limit:
  %v305 = load i64, ptr %slot1, align 8
  %p306 = inttoptr i64 %v305 to ptr
  call void @myl_qbe_fail_step(ptr %p306)
  br label %bb_failure
bb_failure:
  %v307 = load i64, ptr %slot14, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %ld309 = load i64, ptr %p308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld309, ptr %slot61, align 8
  %v310 = load i64, ptr %slot61, align 8
  %v311 = load i64, ptr %slot15, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 %v310, ptr %p312, align 8, !alias.scope !4, !noalias !3
  %v313 = load i64, ptr %slot9, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !4, !noalias !3
  store i64 %ld315, ptr %slot62, align 8
  %v316 = load i64, ptr %slot62, align 8
  %op317 = sub i64 %v316, 1
  store i64 %op317, ptr %slot63, align 8
  %v318 = load i64, ptr %slot63, align 8
  %v319 = load i64, ptr %slot9, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 %v318, ptr %p320, align 8, !alias.scope !4, !noalias !3
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d_meta = external global i8, align 8

declare void @myl_qbe_fail_division(ptr, i64, i64, i64) cold
declare void @myl_qbe_fail_frame(ptr) cold
declare void @myl_qbe_fail_step(ptr) cold

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
