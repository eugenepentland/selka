Expanded runtime benchmark: **subset**.

6 cases; 5 measured rounds; 1 warmups; 360 measured samples across all six configurations.

Optimized default build policies; instruction sets are not matched across arms. No forced target tuning or disabled MyLang checks.

Times below are **ns per CLI iteration**, not necessarily per element. See the unit column and contracts. Application and native-library workloads include their documented algorithms. Ratios are medians of paired rounds against Go; 95% intervals use 2,000 bootstrap resamples. No aggregate ranking pools different workloads.

| Case / profile | Level | Unit | Arm | Median ns/iteration | Min–max | Ratio to Go | 95% interval |
|---|---|---|---|---:|---:|---:|---:|
| string_equal / small | micro | one string equality comparison | my-llvm | 3.64 | 3.61–3.66 | 0.860 | 0.840–0.886 |
| string_equal / small | micro | one string equality comparison | my-qbe | 21.10 | 21.04–21.15 | 4.989 | 4.911–5.139 |
| string_equal / small | micro | one string equality comparison | rust | 2.90 | 2.88–2.92 | 0.688 | 0.673–0.712 |
| string_equal / small | micro | one string equality comparison | go | 4.22 | 4.11–4.30 | 1.000 | 1.000–1.000 |
| string_equal / small | micro | one string equality comparison | zig-safe | 3.92 | 3.91–3.93 | 0.928 | 0.911–0.958 |
| string_equal / small | micro | one string equality comparison | zig-fast | 3.69 | 3.67–3.72 | 0.875 | 0.856–0.905 |
| string_equal / large | micro | one string equality comparison | my-llvm | 11.92 | 11.88–12.49 | 0.331 | 0.330–0.352 |
| string_equal / large | micro | one string equality comparison | my-qbe | 230.86 | 230.66–233.85 | 6.434 | 6.396–6.506 |
| string_equal / large | micro | one string equality comparison | rust | 29.41 | 29.34–29.56 | 0.820 | 0.816–0.828 |
| string_equal / large | micro | one string equality comparison | go | 35.95 | 35.50–36.10 | 1.000 | 1.000–1.000 |
| string_equal / large | micro | one string equality comparison | zig-safe | 62.85 | 62.78–63.38 | 1.759 | 1.741–1.768 |
| string_equal / large | micro | one string equality comparison | zig-fast | 48.01 | 47.95–48.23 | 1.336 | 1.336–1.352 |
| string_search / small | micro | one substring search | my-llvm | 19.21 | 19.12–19.29 | 0.796 | 0.793–0.804 |
| string_search / small | micro | one substring search | my-qbe | 24.11 | 24.07–24.26 | 0.998 | 0.996–1.015 |
| string_search / small | micro | one substring search | rust | 41.99 | 41.79–42.14 | 1.745 | 1.731–1.756 |
| string_search / small | micro | one substring search | go | 24.13 | 23.91–24.17 | 1.000 | 1.000–1.000 |
| string_search / small | micro | one substring search | zig-safe | 87.01 | 86.82–87.48 | 3.604 | 3.593–3.659 |
| string_search / small | micro | one substring search | zig-fast | 73.02 | 72.55–73.18 | 3.026 | 3.006–3.056 |
| string_search / large | micro | one substring search | my-llvm | 85.02 | 84.06–86.01 | 0.133 | 0.132–0.135 |
| string_search / large | micro | one substring search | my-qbe | 90.84 | 89.11–91.47 | 0.143 | 0.140–0.144 |
| string_search / large | micro | one substring search | rust | 1272.17 | 1259.71–1275.50 | 1.997 | 1.979–2.000 |
| string_search / large | micro | one substring search | go | 636.95 | 636.53–637.60 | 1.000 | 1.000–1.000 |
| string_search / large | micro | one substring search | zig-safe | 2847.36 | 2845.07–2858.99 | 4.467 | 4.466–4.492 |
| string_search / large | micro | one substring search | zig-fast | 2522.49 | 2507.14–2536.11 | 3.960 | 3.934–3.984 |
| bytes_scan / small | micro | one full byte-buffer scan | my-llvm | 3.45 | 3.44–3.47 | 0.162 | 0.157–0.166 |
| bytes_scan / small | micro | one full byte-buffer scan | my-qbe | 8.00 | 7.87–8.06 | 0.373 | 0.357–0.387 |
| bytes_scan / small | micro | one full byte-buffer scan | rust | 17.33 | 17.23–17.52 | 0.816 | 0.782–0.839 |
| bytes_scan / small | micro | one full byte-buffer scan | go | 21.29 | 20.82–22.14 | 1.000 | 1.000–1.000 |
| bytes_scan / small | micro | one full byte-buffer scan | zig-safe | 27.86 | 27.49–28.44 | 1.298 | 1.258–1.342 |
| bytes_scan / small | micro | one full byte-buffer scan | zig-fast | 11.87 | 11.81–12.00 | 0.555 | 0.542–0.570 |
| bytes_scan / large | micro | one full byte-buffer scan | my-llvm | 74.92 | 74.74–75.05 | 0.072 | 0.069–0.072 |
| bytes_scan / large | micro | one full byte-buffer scan | my-qbe | 79.24 | 78.75–80.05 | 0.076 | 0.073–0.077 |
| bytes_scan / large | micro | one full byte-buffer scan | rust | 1027.41 | 1025.37–1028.50 | 0.987 | 0.945–0.989 |
| bytes_scan / large | micro | one full byte-buffer scan | go | 1041.23 | 1038.43–1084.54 | 1.000 | 1.000–1.000 |
| bytes_scan / large | micro | one full byte-buffer scan | zig-safe | 1441.08 | 1384.73–1471.04 | 1.377 | 1.277–1.416 |
| bytes_scan / large | micro | one full byte-buffer scan | zig-fast | 688.58 | 687.19–690.45 | 0.661 | 0.634–0.665 |
| string_join / small | micro | one full fragment join and output fold | my-llvm | 158.74 | 158.28–159.45 | 0.403 | 0.401–0.406 |
| string_join / small | micro | one full fragment join and output fold | my-qbe | 188.49 | 187.26–189.05 | 0.479 | 0.474–0.483 |
| string_join / small | micro | one full fragment join and output fold | rust | 217.90 | 216.71–226.62 | 0.555 | 0.547–0.574 |
| string_join / small | micro | one full fragment join and output fold | go | 393.20 | 391.52–395.95 | 1.000 | 1.000–1.000 |
| string_join / small | micro | one full fragment join and output fold | zig-safe | 307.90 | 305.66–309.73 | 0.779 | 0.777–0.788 |
| string_join / small | micro | one full fragment join and output fold | zig-fast | 264.29 | 263.50–268.98 | 0.675 | 0.665–0.681 |
| string_join / large | micro | one full fragment join and output fold | my-llvm | 5701.81 | 5613.95–5808.95 | 0.228 | 0.223–0.232 |
| string_join / large | micro | one full fragment join and output fold | my-qbe | 5853.21 | 5817.15–5931.12 | 0.234 | 0.232–0.238 |
| string_join / large | micro | one full fragment join and output fold | rust | 13321.22 | 13233.33–13365.58 | 0.532 | 0.526–0.535 |
| string_join / large | micro | one full fragment join and output fold | go | 25043.72 | 24907.31–25150.09 | 1.000 | 1.000–1.000 |
| string_join / large | micro | one full fragment join and output fold | zig-safe | 17414.21 | 17357.76–17563.81 | 0.695 | 0.694–0.702 |
| string_join / large | micro | one full fragment join and output fold | zig-fast | 16563.36 | 16520.35–16648.03 | 0.661 | 0.657–0.668 |
| int_parse / small | micro | one strict signed decimal parse | my-llvm | 9.85 | 9.84–10.22 | 0.421 | 0.417–0.441 |
| int_parse / small | micro | one strict signed decimal parse | my-qbe | 18.08 | 17.96–18.25 | 0.776 | 0.766–0.781 |
| int_parse / small | micro | one strict signed decimal parse | rust | 4.33 | 4.28–4.36 | 0.185 | 0.185–0.186 |
| int_parse / small | micro | one strict signed decimal parse | go | 23.36 | 23.18–23.60 | 1.000 | 1.000–1.000 |
| int_parse / small | micro | one strict signed decimal parse | zig-safe | 5.66 | 5.65–5.68 | 0.242 | 0.241–0.244 |
| int_parse / small | micro | one strict signed decimal parse | zig-fast | 5.61 | 5.58–5.76 | 0.241 | 0.240–0.244 |
| int_parse / large | micro | one strict signed decimal parse | my-llvm | 11.11 | 11.07–11.15 | 0.421 | 0.420–0.422 |
| int_parse / large | micro | one strict signed decimal parse | my-qbe | 19.12 | 19.08–19.20 | 0.725 | 0.721–0.727 |
| int_parse / large | micro | one strict signed decimal parse | rust | 4.97 | 4.94–5.09 | 0.188 | 0.187–0.193 |
| int_parse / large | micro | one strict signed decimal parse | go | 26.40 | 26.38–26.45 | 1.000 | 1.000–1.000 |
| int_parse / large | micro | one strict signed decimal parse | zig-safe | 6.78 | 6.67–6.84 | 0.257 | 0.252–0.259 |
| int_parse / large | micro | one strict signed decimal parse | zig-fast | 6.17 | 6.11–6.22 | 0.234 | 0.231–0.236 |
| int_format / small | micro | one signed decimal formatting and output fold | my-llvm | 55.01 | 54.64–55.73 | 3.472 | 3.384–3.504 |
| int_format / small | micro | one signed decimal formatting and output fold | my-qbe | 83.11 | 82.64–83.13 | 5.249 | 5.047–5.259 |
| int_format / small | micro | one signed decimal formatting and output fold | rust | 14.65 | 14.33–14.69 | 0.923 | 0.870–0.929 |
| int_format / small | micro | one signed decimal formatting and output fold | go | 15.83 | 15.74–16.47 | 1.000 | 1.000–1.000 |
| int_format / small | micro | one signed decimal formatting and output fold | zig-safe | 38.61 | 38.44–38.86 | 2.438 | 2.359–2.447 |
| int_format / small | micro | one signed decimal formatting and output fold | zig-fast | 30.89 | 30.85–31.09 | 1.948 | 1.887–1.964 |
| int_format / large | micro | one signed decimal formatting and output fold | my-llvm | 56.04 | 55.79–56.37 | 3.268 | 3.248–3.296 |
| int_format / large | micro | one signed decimal formatting and output fold | my-qbe | 84.10 | 83.92–84.35 | 4.896 | 4.884–4.932 |
| int_format / large | micro | one signed decimal formatting and output fold | rust | 14.96 | 14.94–15.66 | 0.874 | 0.869–0.912 |
| int_format / large | micro | one signed decimal formatting and output fold | go | 17.16 | 17.10–17.20 | 1.000 | 1.000–1.000 |
| int_format / large | micro | one signed decimal formatting and output fold | zig-safe | 40.94 | 40.72–41.20 | 2.394 | 2.371–2.396 |
| int_format / large | micro | one signed decimal formatting and output fold | zig-fast | 34.25 | 34.11–34.33 | 1.994 | 1.988–2.002 |

Calibration limits: string_equal/small (iteration_cap), string_equal/large (slowest_arm_budget), string_search/small (slowest_arm_budget), string_search/large (slowest_arm_budget), bytes_scan/small (iteration_cap), bytes_scan/large (slowest_arm_budget), int_parse/small (iteration_cap).

Per-core activity: {"2": 99.38862848991236, "3": 0.030590394616090547}.
Governor: powersave.
Sibling reservation is operator-managed; busy counters record average load and cannot exclude short interference.

Operation inventory coverage does not establish 80% of everyday CPU time. Separate application profiles are required.
