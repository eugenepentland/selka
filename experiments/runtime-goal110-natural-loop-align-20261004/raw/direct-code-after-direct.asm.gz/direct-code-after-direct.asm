0x102cf35: mov    %r15,%rdx
0x102cf38: add    %r11,%rdx
0x102cf3b: jo     102e582 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4922>
0x102cf41: imul   $0x3,%rdx,%rax
0x102cf45: jo     102e5a3 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4943>
0x102cf4b: movabs $0x7ffffffffffffff8,%rcx
0x102cf55: cmp    %rcx,%rax
0x102cf58: jg     102e5ca <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x496a>
0x102cf5e: add    $0x7,%rax
0x102cf62: mov    $0x3,%r12d
0x102cf68: jmp    102d577 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3917>
