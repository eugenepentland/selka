target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v163 = load i64, ptr %slot1, align 8
  %op164 = add i64 %v163, 32
  store i64 %op164, ptr %slot4, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot5, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot6, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot7, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot8, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot9, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot10, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot11, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot12, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot13, align 8
  %v183 = load i64, ptr %slot2, align 8
  %v184 = load i64, ptr %slot5, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 %v183, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot3, align 8
  %v187 = load i64, ptr %slot6, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v189 = load i64, ptr %slot5, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot14, align 8
  %v192 = load i64, ptr %slot14, align 8
  %v193 = load i64, ptr %slot12, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot12, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %ld197 = load i64, ptr %p196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld197, ptr %slot15, align 8
  %v198 = load i64, ptr %slot7, align 8
  store i64 %v198, ptr %slot16, align 8
  %v199 = load i64, ptr %slot15, align 8
  %v200 = load i64, ptr %slot16, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot12, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 0, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot12, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot17, align 8
  %v207 = load i64, ptr %slot8, align 8
  store i64 %v207, ptr %slot18, align 8
  %v208 = load i64, ptr %slot17, align 8
  %v209 = load i64, ptr %slot18, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot19, align 8
  %v214 = load i64, ptr %slot19, align 8
  %v215 = load i64, ptr %slot12, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot12, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot20, align 8
  %v220 = load i64, ptr %slot9, align 8
  store i64 %v220, ptr %slot21, align 8
  %v221 = load i64, ptr %slot20, align 8
  %v222 = load i64, ptr %slot21, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot8, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot22, align 8
  %v227 = load i64, ptr %slot9, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot23, align 8
  %v230 = load i64, ptr %slot23, align 8
  %v231 = load i64, ptr %slot22, align 8
  %cmp232 = icmp sgt i64 %v230, %v231
  %cv233 = zext i1 %cmp232 to i64
  store i64 %cv233, ptr %slot24, align 8
  %v234 = load i64, ptr %slot23, align 8
  %v235 = load i64, ptr %slot22, align 8
  %op236 = sub i64 %v234, %v235
  store i64 %op236, ptr %slot25, align 8
  %v237 = load i64, ptr %slot25, align 8
  %cmp238 = icmp uge i64 %v237, 16
  %cv239 = zext i1 %cmp238 to i64
  store i64 %cv239, ptr %slot26, align 8
  %v240 = load i64, ptr %slot24, align 8
  %v241 = load i64, ptr %slot26, align 8
  %op242 = and i64 %v240, %v241
  store i64 %op242, ptr %slot27, align 8
  %v243 = load i64, ptr %slot27, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v245 = load i64, ptr %slot22, align 8
  %op246 = add i64 %v245, 1152921504606846976
  store i64 %op246, ptr %slot28, align 8
  %v247 = load i64, ptr %slot28, align 8
  %cmp248 = icmp ule i64 %v247, 2305843009213693952
  %cv249 = zext i1 %cmp248 to i64
  store i64 %cv249, ptr %slot29, align 8
  %v250 = load i64, ptr %slot29, align 8
  %cond251 = icmp ne i64 %v250, 0
  br i1 %cond251, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v252 = load i64, ptr %slot23, align 8
  %op253 = add i64 %v252, 1152921504606846976
  store i64 %op253, ptr %slot30, align 8
  %v254 = load i64, ptr %slot30, align 8
  %cmp255 = icmp ule i64 %v254, 2305843009213693952
  %cv256 = zext i1 %cmp255 to i64
  store i64 %cv256, ptr %slot31, align 8
  %v257 = load i64, ptr %slot31, align 8
  %cond258 = icmp ne i64 %v257, 0
  br i1 %cond258, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v259 = load i64, ptr %slot8, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot32, align 8
  %v262 = load i64, ptr %slot32, align 8
  %v263 = load i64, ptr %slot12, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot9, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot33, align 8
  %v268 = load i64, ptr %slot33, align 8
  %v269 = load i64, ptr %slot13, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot13, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot34, align 8
  %v274 = load i64, ptr %slot12, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot35, align 8
  %v277 = load i64, ptr %slot35, align 8
  %v278 = load i64, ptr %slot34, align 8
  %cmp279 = icmp slt i64 %v277, %v278
  %cv280 = zext i1 %cmp279 to i64
  store i64 %cv280, ptr %slot36, align 8
  %v281 = load i64, ptr %slot36, align 8
  %v282 = load i64, ptr %slot12, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot12, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot37, align 8
  %v287 = load i64, ptr %slot37, align 8
  %cond288 = icmp ne i64 %v287, 0
  br i1 %cond288, label %bb_next24, label %bb_i35
bb_next24:
  %v289 = load i64, ptr %slot8, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot38, align 8
  %v292 = load i64, ptr %slot38, align 8
  %v293 = load i64, ptr %slot12, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 %v292, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot13, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 3, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot13, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot39, align 8
  %v300 = load i64, ptr %slot12, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot40, align 8
  %v303 = load i64, ptr %slot40, align 8
  %op304 = add i64 %v303, 1152921504606846978
  store i64 %op304, ptr %slot41, align 8
  %v305 = load i64, ptr %slot41, align 8
  %v306 = load i64, ptr %slot39, align 8
  %op307 = urem i64 %v305, %v306
  store i64 %op307, ptr %slot42, align 8
  %v308 = load i64, ptr %slot42, align 8
  %v309 = load i64, ptr %slot12, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i64 %v308, ptr %p310, align 8, !alias.scope !3, !noalias !4
  %v311 = load i64, ptr %slot13, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 0, ptr %p312, align 8, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot13, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot43, align 8
  %v316 = load i64, ptr %slot12, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i64, ptr %p317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld318, ptr %slot44, align 8
  %v319 = load i64, ptr %slot44, align 8
  %v320 = load i64, ptr %slot43, align 8
  %cmp321 = icmp eq i64 %v319, %v320
  %cv322 = zext i1 %cmp321 to i64
  store i64 %cv322, ptr %slot45, align 8
  %v323 = load i64, ptr %slot45, align 8
  %v324 = load i64, ptr %slot12, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot12, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot46, align 8
  %v329 = load i64, ptr %slot46, align 8
  %cond330 = icmp ne i64 %v329, 0
  br i1 %cond330, label %bb_next33, label %bb_fi20
bb_next33:
  %v331 = load i64, ptr %slot12, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i64 17, ptr %p332, align 8, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot12, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %ld335 = load i64, ptr %p334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld335, ptr %slot47, align 8
  %v336 = load i64, ptr %slot47, align 8
  %neg337 = sub i64 0, %v336
  store i64 %neg337, ptr %slot48, align 8
  %v338 = load i64, ptr %slot47, align 8
  %cmp339 = icmp eq i64 %v338, 9223372036854775808
  %cv340 = zext i1 %cmp339 to i64
  store i64 %cv340, ptr %slot49, align 8
  %v341 = load i64, ptr %slot49, align 8
  %cond342 = icmp ne i64 %v341, 0
  br i1 %cond342, label %bb_neg_overflow34, label %bb_neg_checked34
bb_neg_overflow34:
  %v343 = load i64, ptr %slot1, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %v345 = load i64, ptr %slot47, align 8
  %call346 = call i64 @myl_qbe_int_neg(ptr %p344, i64 1, i64 64, i64 %v345) nomerge, !dbg !110
  unreachable
bb_neg_checked34:
  %v347 = load i64, ptr %slot48, align 8
  %v348 = load i64, ptr %slot12, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot12, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot50, align 8
  %v353 = load i64, ptr %slot10, align 8
  store i64 %v353, ptr %slot51, align 8
  %v354 = load i64, ptr %slot50, align 8
  %v355 = load i64, ptr %slot51, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i64 %v354, ptr %p356, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi20:
  %v357 = load i64, ptr %slot12, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 23, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot12, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %ld361 = load i64, ptr %p360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld361, ptr %slot52, align 8
  %v362 = load i64, ptr %slot10, align 8
  store i64 %v362, ptr %slot53, align 8
  %v363 = load i64, ptr %slot52, align 8
  %v364 = load i64, ptr %slot53, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi22:
  %v366 = load i64, ptr %slot10, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot54, align 8
  %v369 = load i64, ptr %slot54, align 8
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot12, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot55, align 8
  %v375 = load i64, ptr %slot11, align 8
  store i64 %v375, ptr %slot56, align 8
  %v376 = load i64, ptr %slot55, align 8
  %v377 = load i64, ptr %slot56, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 %v376, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot7, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot57, align 8
  %v382 = load i64, ptr %slot57, align 8
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i64 %v382, ptr %p384, align 8, !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot11, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i64, ptr %p386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld387, ptr %slot58, align 8
  %v388 = load i64, ptr %slot58, align 8
  %v389 = load i64, ptr %slot13, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 %v388, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot13, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot59, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot60, align 8
  %v397 = load i64, ptr %slot60, align 8
  %v398 = load i64, ptr %slot59, align 8
  %ovpair400 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v397, i64 %v398)
  %op399 = extractvalue { i64, i1 } %ovpair400, 0
  %ov401 = extractvalue { i64, i1 } %ovpair400, 1
  store i64 %op399, ptr %slot61, align 8
  %v402 = load i64, ptr %slot60, align 8
  %v403 = load i64, ptr %slot61, align 8
  %op404 = xor i64 %v402, %v403
  store i64 %op404, ptr %slot62, align 8
  %v405 = load i64, ptr %slot59, align 8
  %v406 = load i64, ptr %slot61, align 8
  %op407 = xor i64 %v405, %v406
  store i64 %op407, ptr %slot63, align 8
  %v408 = load i64, ptr %slot62, align 8
  %v409 = load i64, ptr %slot63, align 8
  %op410 = and i64 %v408, %v409
  store i64 %op410, ptr %slot64, align 8
  %cv411 = zext i1 %ov401 to i64
  store i64 %cv411, ptr %slot65, align 8
  %v412 = load i64, ptr %slot65, align 8
  %cond413 = icmp ne i64 %v412, 0
  br i1 %cond413, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v414 = load i64, ptr %slot1, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %v416 = load i64, ptr %slot60, align 8
  %v417 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p415, i64 0, i64 %v416, i64 %v417, i64 64) nomerge, !dbg !112
  unreachable
bb_checked47:
  %v418 = load i64, ptr %slot61, align 8
  %v419 = load i64, ptr %slot12, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot13, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 1000000007, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot13, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot66, align 8
  %v426 = load i64, ptr %slot12, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot67, align 8
  %v429 = load i64, ptr %slot66, align 8
  %cmp430 = icmp eq i64 %v429, 0
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot68, align 8
  %v432 = load i64, ptr %slot68, align 8
  %cond433 = icmp ne i64 %v432, 0
  br i1 %cond433, label %bb_division54, label %bb_nonzero54
bb_division54:
  %v434 = load i64, ptr %slot1, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %v436 = load i64, ptr %slot67, align 8
  %v437 = load i64, ptr %slot66, align 8
  call void @myl_qbe_fail_division(ptr %p435, i64 6, i64 %v436, i64 %v437) nomerge, !dbg !114
  unreachable
bb_nonzero54:
  %v438 = load i64, ptr %slot67, align 8
  %cmp439 = icmp eq i64 %v438, 9223372036854775808
  %cv440 = zext i1 %cmp439 to i64
  store i64 %cv440, ptr %slot69, align 8
  %v441 = load i64, ptr %slot66, align 8
  %cmp442 = icmp eq i64 %v441, 18446744073709551615
  %cv443 = zext i1 %cmp442 to i64
  store i64 %cv443, ptr %slot70, align 8
  %v444 = load i64, ptr %slot69, align 8
  %v445 = load i64, ptr %slot70, align 8
  %op446 = and i64 %v444, %v445
  store i64 %op446, ptr %slot71, align 8
  %v447 = load i64, ptr %slot71, align 8
  %neg448 = sub i64 0, %v447
  store i64 %neg448, ptr %slot72, align 8
  %v449 = load i64, ptr %slot66, align 8
  %op450 = xor i64 %v449, 1
  store i64 %op450, ptr %slot73, align 8
  %v451 = load i64, ptr %slot73, align 8
  %v452 = load i64, ptr %slot72, align 8
  %op453 = and i64 %v451, %v452
  store i64 %op453, ptr %slot73, align 8
  %v454 = load i64, ptr %slot66, align 8
  %v455 = load i64, ptr %slot73, align 8
  %op456 = xor i64 %v454, %v455
  store i64 %op456, ptr %slot74, align 8
  %v457 = load i64, ptr %slot67, align 8
  %v458 = load i64, ptr %slot74, align 8
  %op459 = srem i64 %v457, %v458
  store i64 %op459, ptr %slot75, align 8
  %v460 = load i64, ptr %slot75, align 8
  %cmp461 = icmp ne i64 %v460, 0
  %cv462 = zext i1 %cmp461 to i64
  store i64 %cv462, ptr %slot76, align 8
  %v463 = load i64, ptr %slot75, align 8
  %v464 = load i64, ptr %slot74, align 8
  %op465 = xor i64 %v463, %v464
  store i64 %op465, ptr %slot77, align 8
  %v466 = load i64, ptr %slot77, align 8
  %cmp467 = icmp slt i64 %v466, 0
  %cv468 = zext i1 %cmp467 to i64
  store i64 %cv468, ptr %slot78, align 8
  %v469 = load i64, ptr %slot76, align 8
  %v470 = load i64, ptr %slot78, align 8
  %op471 = and i64 %v469, %v470
  store i64 %op471, ptr %slot79, align 8
  %v472 = load i64, ptr %slot79, align 8
  %neg473 = sub i64 0, %v472
  store i64 %neg473, ptr %slot80, align 8
  %v474 = load i64, ptr %slot74, align 8
  %v475 = load i64, ptr %slot80, align 8
  %op476 = and i64 %v474, %v475
  store i64 %op476, ptr %slot81, align 8
  %v477 = load i64, ptr %slot75, align 8
  %v478 = load i64, ptr %slot81, align 8
  %op479 = add i64 %v477, %v478
  store i64 %op479, ptr %slot75, align 8
  %v480 = load i64, ptr %slot75, align 8
  %v481 = load i64, ptr %slot12, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i64 %v480, ptr %p482, align 8, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot12, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i64, ptr %p484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld485, ptr %slot82, align 8
  %v486 = load i64, ptr %slot7, align 8
  store i64 %v486, ptr %slot83, align 8
  %v487 = load i64, ptr %slot82, align 8
  %v488 = load i64, ptr %slot83, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i64 %v487, ptr %p489, align 8, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot8, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot84, align 8
  %v493 = load i64, ptr %slot84, align 8
  %v494 = load i64, ptr %slot12, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i64 %v493, ptr %p495, align 8, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot13, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 1, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot13, align 8
  %p499 = inttoptr i64 %v498 to ptr
  %ld500 = load i64, ptr %p499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld500, ptr %slot85, align 8
  %v501 = load i64, ptr %slot12, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %ld503 = load i64, ptr %p502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld503, ptr %slot86, align 8
  %v504 = load i64, ptr %slot86, align 8
  %v505 = load i64, ptr %slot85, align 8
  %op506 = add i64 %v504, %v505
  store i64 %op506, ptr %slot87, align 8
  %v507 = load i64, ptr %slot87, align 8
  %v508 = load i64, ptr %slot12, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot12, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot88, align 8
  %v513 = load i64, ptr %slot8, align 8
  store i64 %v513, ptr %slot89, align 8
  %v514 = load i64, ptr %slot88, align 8
  %v515 = load i64, ptr %slot89, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i64 %v514, ptr %p516, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v517 = load i64, ptr %slot8, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i64, ptr %p518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld519, ptr %slot90, align 8
  %v520 = load i64, ptr %slot90, align 8
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot9, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i64, ptr %p524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld525, ptr %slot91, align 8
  %v526 = load i64, ptr %slot91, align 8
  %v527 = load i64, ptr %slot13, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i64 %v526, ptr %p528, align 8, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot13, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ld531 = load i64, ptr %p530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld531, ptr %slot92, align 8
  %v532 = load i64, ptr %slot12, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot93, align 8
  %v535 = load i64, ptr %slot93, align 8
  %v536 = load i64, ptr %slot92, align 8
  %cmp537 = icmp slt i64 %v535, %v536
  %cv538 = zext i1 %cmp537 to i64
  store i64 %cv538, ptr %slot94, align 8
  %v539 = load i64, ptr %slot94, align 8
  %v540 = load i64, ptr %slot12, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot12, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot95, align 8
  %v545 = load i64, ptr %slot95, align 8
  %cond546 = icmp ne i64 %v545, 0
  br i1 %cond546, label %bb_next82, label %bb_i35
bb_next82:
  %v547 = load i64, ptr %slot8, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld549, ptr %slot96, align 8
  %v550 = load i64, ptr %slot96, align 8
  %v551 = load i64, ptr %slot12, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 %v550, ptr %p552, align 8, !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot13, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i64 3, ptr %p554, align 8, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot13, align 8
  %p556 = inttoptr i64 %v555 to ptr
  %ld557 = load i64, ptr %p556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld557, ptr %slot97, align 8
  %v558 = load i64, ptr %slot12, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %ld560 = load i64, ptr %p559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld560, ptr %slot98, align 8
  %v561 = load i64, ptr %slot97, align 8
  %cmp562 = icmp eq i64 %v561, 0
  %cv563 = zext i1 %cmp562 to i64
  store i64 %cv563, ptr %slot99, align 8
  %v564 = load i64, ptr %slot99, align 8
  %cond565 = icmp ne i64 %v564, 0
  br i1 %cond565, label %bb_division85, label %bb_nonzero85
bb_division85:
  %v566 = load i64, ptr %slot1, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %v568 = load i64, ptr %slot98, align 8
  %v569 = load i64, ptr %slot97, align 8
  call void @myl_qbe_fail_division(ptr %p567, i64 6, i64 %v568, i64 %v569) nomerge, !dbg !116
  unreachable
bb_nonzero85:
  %v570 = load i64, ptr %slot98, align 8
  %cmp571 = icmp eq i64 %v570, 9223372036854775808
  %cv572 = zext i1 %cmp571 to i64
  store i64 %cv572, ptr %slot100, align 8
  %v573 = load i64, ptr %slot97, align 8
  %cmp574 = icmp eq i64 %v573, 18446744073709551615
  %cv575 = zext i1 %cmp574 to i64
  store i64 %cv575, ptr %slot101, align 8
  %v576 = load i64, ptr %slot100, align 8
  %v577 = load i64, ptr %slot101, align 8
  %op578 = and i64 %v576, %v577
  store i64 %op578, ptr %slot102, align 8
  %v579 = load i64, ptr %slot102, align 8
  %neg580 = sub i64 0, %v579
  store i64 %neg580, ptr %slot103, align 8
  %v581 = load i64, ptr %slot97, align 8
  %op582 = xor i64 %v581, 1
  store i64 %op582, ptr %slot104, align 8
  %v583 = load i64, ptr %slot104, align 8
  %v584 = load i64, ptr %slot103, align 8
  %op585 = and i64 %v583, %v584
  store i64 %op585, ptr %slot104, align 8
  %v586 = load i64, ptr %slot97, align 8
  %v587 = load i64, ptr %slot104, align 8
  %op588 = xor i64 %v586, %v587
  store i64 %op588, ptr %slot105, align 8
  %v589 = load i64, ptr %slot98, align 8
  %v590 = load i64, ptr %slot105, align 8
  %op591 = srem i64 %v589, %v590
  store i64 %op591, ptr %slot106, align 8
  %v592 = load i64, ptr %slot106, align 8
  %cmp593 = icmp ne i64 %v592, 0
  %cv594 = zext i1 %cmp593 to i64
  store i64 %cv594, ptr %slot107, align 8
  %v595 = load i64, ptr %slot106, align 8
  %v596 = load i64, ptr %slot105, align 8
  %op597 = xor i64 %v595, %v596
  store i64 %op597, ptr %slot108, align 8
  %v598 = load i64, ptr %slot108, align 8
  %cmp599 = icmp slt i64 %v598, 0
  %cv600 = zext i1 %cmp599 to i64
  store i64 %cv600, ptr %slot109, align 8
  %v601 = load i64, ptr %slot107, align 8
  %v602 = load i64, ptr %slot109, align 8
  %op603 = and i64 %v601, %v602
  store i64 %op603, ptr %slot110, align 8
  %v604 = load i64, ptr %slot110, align 8
  %neg605 = sub i64 0, %v604
  store i64 %neg605, ptr %slot111, align 8
  %v606 = load i64, ptr %slot105, align 8
  %v607 = load i64, ptr %slot111, align 8
  %op608 = and i64 %v606, %v607
  store i64 %op608, ptr %slot112, align 8
  %v609 = load i64, ptr %slot106, align 8
  %v610 = load i64, ptr %slot112, align 8
  %op611 = add i64 %v609, %v610
  store i64 %op611, ptr %slot106, align 8
  %v612 = load i64, ptr %slot106, align 8
  %v613 = load i64, ptr %slot12, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i64 %v612, ptr %p614, align 8, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot13, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i64 0, ptr %p616, align 8, !alias.scope !3, !noalias !4
  %v617 = load i64, ptr %slot13, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %ld619 = load i64, ptr %p618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld619, ptr %slot113, align 8
  %v620 = load i64, ptr %slot12, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot114, align 8
  %v623 = load i64, ptr %slot114, align 8
  %v624 = load i64, ptr %slot113, align 8
  %cmp625 = icmp eq i64 %v623, %v624
  %cv626 = zext i1 %cmp625 to i64
  store i64 %cv626, ptr %slot115, align 8
  %v627 = load i64, ptr %slot115, align 8
  %v628 = load i64, ptr %slot12, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot12, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot116, align 8
  %v633 = load i64, ptr %slot116, align 8
  %cond634 = icmp ne i64 %v633, 0
  br i1 %cond634, label %bb_next103, label %bb_i20
bb_next103:
  %v635 = load i64, ptr %slot12, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i64 17, ptr %p636, align 8, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot12, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i64, ptr %p638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld639, ptr %slot117, align 8
  %v640 = load i64, ptr %slot117, align 8
  %neg641 = sub i64 0, %v640
  store i64 %neg641, ptr %slot118, align 8
  %v642 = load i64, ptr %slot117, align 8
  %cmp643 = icmp eq i64 %v642, 9223372036854775808
  %cv644 = zext i1 %cmp643 to i64
  store i64 %cv644, ptr %slot119, align 8
  %v645 = load i64, ptr %slot119, align 8
  %cond646 = icmp ne i64 %v645, 0
  br i1 %cond646, label %bb_neg_overflow104, label %bb_neg_checked104
bb_neg_overflow104:
  %v647 = load i64, ptr %slot1, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %v649 = load i64, ptr %slot117, align 8
  %call650 = call i64 @myl_qbe_int_neg(ptr %p648, i64 1, i64 64, i64 %v649) nomerge, !dbg !110
  unreachable
bb_neg_checked104:
  %v651 = load i64, ptr %slot118, align 8
  %v652 = load i64, ptr %slot12, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot12, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i64, ptr %p655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld656, ptr %slot120, align 8
  %v657 = load i64, ptr %slot10, align 8
  store i64 %v657, ptr %slot121, align 8
  %v658 = load i64, ptr %slot120, align 8
  %v659 = load i64, ptr %slot121, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i64 %v658, ptr %p660, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i20:
  %v661 = load i64, ptr %slot12, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 23, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot12, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot122, align 8
  %v666 = load i64, ptr %slot10, align 8
  store i64 %v666, ptr %slot123, align 8
  %v667 = load i64, ptr %slot122, align 8
  %v668 = load i64, ptr %slot123, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 %v667, ptr %p669, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v670 = load i64, ptr %slot10, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot124, align 8
  %v673 = load i64, ptr %slot124, align 8
  %v674 = load i64, ptr %slot12, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot12, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot125, align 8
  %v679 = load i64, ptr %slot11, align 8
  store i64 %v679, ptr %slot126, align 8
  %v680 = load i64, ptr %slot125, align 8
  %v681 = load i64, ptr %slot126, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i64 %v680, ptr %p682, align 8, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot7, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %ld685 = load i64, ptr %p684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld685, ptr %slot127, align 8
  %v686 = load i64, ptr %slot127, align 8
  %v687 = load i64, ptr %slot12, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i64 %v686, ptr %p688, align 8, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot11, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot128, align 8
  %v692 = load i64, ptr %slot128, align 8
  %v693 = load i64, ptr %slot13, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 %v692, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot13, align 8
  %p696 = inttoptr i64 %v695 to ptr
  %ld697 = load i64, ptr %p696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld697, ptr %slot129, align 8
  %v698 = load i64, ptr %slot12, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot130, align 8
  %v701 = load i64, ptr %slot130, align 8
  %v702 = load i64, ptr %slot129, align 8
  %ovpair704 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v701, i64 %v702)
  %op703 = extractvalue { i64, i1 } %ovpair704, 0
  %ov705 = extractvalue { i64, i1 } %ovpair704, 1
  store i64 %op703, ptr %slot131, align 8
  %v706 = load i64, ptr %slot130, align 8
  %v707 = load i64, ptr %slot131, align 8
  %op708 = xor i64 %v706, %v707
  store i64 %op708, ptr %slot132, align 8
  %v709 = load i64, ptr %slot129, align 8
  %v710 = load i64, ptr %slot131, align 8
  %op711 = xor i64 %v709, %v710
  store i64 %op711, ptr %slot133, align 8
  %v712 = load i64, ptr %slot132, align 8
  %v713 = load i64, ptr %slot133, align 8
  %op714 = and i64 %v712, %v713
  store i64 %op714, ptr %slot134, align 8
  %cv715 = zext i1 %ov705 to i64
  store i64 %cv715, ptr %slot135, align 8
  %v716 = load i64, ptr %slot135, align 8
  %cond717 = icmp ne i64 %v716, 0
  br i1 %cond717, label %bb_overflow117, label %bb_checked117
bb_overflow117:
  %v718 = load i64, ptr %slot1, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %v720 = load i64, ptr %slot130, align 8
  %v721 = load i64, ptr %slot129, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p719, i64 0, i64 %v720, i64 %v721, i64 64) nomerge, !dbg !112
  unreachable
bb_checked117:
  %v722 = load i64, ptr %slot131, align 8
  %v723 = load i64, ptr %slot12, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i64 %v722, ptr %p724, align 8, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot13, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i64 1000000007, ptr %p726, align 8, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot13, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot136, align 8
  %v730 = load i64, ptr %slot12, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot137, align 8
  %v733 = load i64, ptr %slot136, align 8
  %cmp734 = icmp eq i64 %v733, 0
  %cv735 = zext i1 %cmp734 to i64
  store i64 %cv735, ptr %slot138, align 8
  %v736 = load i64, ptr %slot138, align 8
  %cond737 = icmp ne i64 %v736, 0
  br i1 %cond737, label %bb_division124, label %bb_nonzero124
bb_division124:
  %v738 = load i64, ptr %slot1, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %v740 = load i64, ptr %slot137, align 8
  %v741 = load i64, ptr %slot136, align 8
  call void @myl_qbe_fail_division(ptr %p739, i64 6, i64 %v740, i64 %v741) nomerge, !dbg !114
  unreachable
bb_nonzero124:
  %v742 = load i64, ptr %slot137, align 8
  %cmp743 = icmp eq i64 %v742, 9223372036854775808
  %cv744 = zext i1 %cmp743 to i64
  store i64 %cv744, ptr %slot139, align 8
  %v745 = load i64, ptr %slot136, align 8
  %cmp746 = icmp eq i64 %v745, 18446744073709551615
  %cv747 = zext i1 %cmp746 to i64
  store i64 %cv747, ptr %slot140, align 8
  %v748 = load i64, ptr %slot139, align 8
  %v749 = load i64, ptr %slot140, align 8
  %op750 = and i64 %v748, %v749
  store i64 %op750, ptr %slot141, align 8
  %v751 = load i64, ptr %slot141, align 8
  %neg752 = sub i64 0, %v751
  store i64 %neg752, ptr %slot142, align 8
  %v753 = load i64, ptr %slot136, align 8
  %op754 = xor i64 %v753, 1
  store i64 %op754, ptr %slot143, align 8
  %v755 = load i64, ptr %slot143, align 8
  %v756 = load i64, ptr %slot142, align 8
  %op757 = and i64 %v755, %v756
  store i64 %op757, ptr %slot143, align 8
  %v758 = load i64, ptr %slot136, align 8
  %v759 = load i64, ptr %slot143, align 8
  %op760 = xor i64 %v758, %v759
  store i64 %op760, ptr %slot144, align 8
  %v761 = load i64, ptr %slot137, align 8
  %v762 = load i64, ptr %slot144, align 8
  %op763 = srem i64 %v761, %v762
  store i64 %op763, ptr %slot145, align 8
  %v764 = load i64, ptr %slot145, align 8
  %cmp765 = icmp ne i64 %v764, 0
  %cv766 = zext i1 %cmp765 to i64
  store i64 %cv766, ptr %slot146, align 8
  %v767 = load i64, ptr %slot145, align 8
  %v768 = load i64, ptr %slot144, align 8
  %op769 = xor i64 %v767, %v768
  store i64 %op769, ptr %slot147, align 8
  %v770 = load i64, ptr %slot147, align 8
  %cmp771 = icmp slt i64 %v770, 0
  %cv772 = zext i1 %cmp771 to i64
  store i64 %cv772, ptr %slot148, align 8
  %v773 = load i64, ptr %slot146, align 8
  %v774 = load i64, ptr %slot148, align 8
  %op775 = and i64 %v773, %v774
  store i64 %op775, ptr %slot149, align 8
  %v776 = load i64, ptr %slot149, align 8
  %neg777 = sub i64 0, %v776
  store i64 %neg777, ptr %slot150, align 8
  %v778 = load i64, ptr %slot144, align 8
  %v779 = load i64, ptr %slot150, align 8
  %op780 = and i64 %v778, %v779
  store i64 %op780, ptr %slot151, align 8
  %v781 = load i64, ptr %slot145, align 8
  %v782 = load i64, ptr %slot151, align 8
  %op783 = add i64 %v781, %v782
  store i64 %op783, ptr %slot145, align 8
  %v784 = load i64, ptr %slot145, align 8
  %v785 = load i64, ptr %slot12, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i64 %v784, ptr %p786, align 8, !alias.scope !3, !noalias !4
  %v787 = load i64, ptr %slot12, align 8
  %p788 = inttoptr i64 %v787 to ptr
  %ld789 = load i64, ptr %p788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld789, ptr %slot152, align 8
  %v790 = load i64, ptr %slot7, align 8
  store i64 %v790, ptr %slot153, align 8
  %v791 = load i64, ptr %slot152, align 8
  %v792 = load i64, ptr %slot153, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 %v791, ptr %p793, align 8, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot8, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld796, ptr %slot154, align 8
  %v797 = load i64, ptr %slot154, align 8
  %v798 = load i64, ptr %slot12, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot13, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i64 1, ptr %p801, align 8, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot13, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i64, ptr %p803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld804, ptr %slot155, align 8
  %v805 = load i64, ptr %slot12, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot156, align 8
  %v808 = load i64, ptr %slot156, align 8
  %v809 = load i64, ptr %slot155, align 8
  %op810 = add i64 %v808, %v809
  %ovpair811 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v808, i64 %v809)
  %ov812 = extractvalue { i64, i1 } %ovpair811, 1
  store i64 %op810, ptr %slot157, align 8
  %cv813 = zext i1 %ov812 to i64
  store i64 %cv813, ptr %slot158, align 8
  %v814 = load i64, ptr %slot158, align 8
  %cond815 = icmp ne i64 %v814, 0
  br i1 %cond815, label %bb_overflow143, label %bb_checked143
bb_overflow143:
  %v816 = load i64, ptr %slot1, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %v818 = load i64, ptr %slot156, align 8
  %v819 = load i64, ptr %slot155, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p817, i64 0, i64 %v818, i64 %v819, i64 64) nomerge, !dbg !118
  unreachable
bb_checked143:
  %v820 = load i64, ptr %slot157, align 8
  %v821 = load i64, ptr %slot12, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i64 %v820, ptr %p822, align 8, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot12, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot159, align 8
  %v826 = load i64, ptr %slot8, align 8
  store i64 %v826, ptr %slot160, align 8
  %v827 = load i64, ptr %slot159, align 8
  %v828 = load i64, ptr %slot160, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i35:
  %v830 = load i64, ptr %slot7, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld832, ptr %slot161, align 8
  %v833 = load i64, ptr %slot161, align 8
  %v834 = load i64, ptr %slot12, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 %v833, ptr %p835, align 8, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot12, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot162, align 8
  %v839 = load i64, ptr %slot162, align 8
  ret i64 %v839
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", linkageName: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4316030661171315038, i64 0, !"myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!110 = !DILocation(line: 18, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
