target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_73f9bfebc60ce1b361ae437a0ef261224aaaef2e9cbd6eaa354fcc9949919970(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v61 = load i64, ptr %slot1, align 8
  %op62 = add i64 %v61, 32
  store i64 %op62, ptr %slot3, align 8
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot4, align 8
  %mem65 = alloca i8, i64 8, align 8
  %ptr66 = ptrtoint ptr %mem65 to i64
  store i64 %ptr66, ptr %slot5, align 8
  %mem67 = alloca i8, i64 8, align 8
  %ptr68 = ptrtoint ptr %mem67 to i64
  store i64 %ptr68, ptr %slot6, align 8
  %v69 = load i64, ptr %slot1, align 8
  %op70 = add i64 %v69, 8
  store i64 %op70, ptr %slot7, align 8
  %v71 = load i64, ptr %slot7, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !4, !noalias !3
  store i64 %ld73, ptr %slot8, align 8
  %v74 = load i64, ptr %slot1, align 8
  %op75 = add i64 %v74, 56
  store i64 %op75, ptr %slot9, align 8
  %v76 = load i64, ptr %slot9, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %ld78 = load i64, ptr %p77, align 8, !alias.scope !4, !noalias !3
  store i64 %ld78, ptr %slot10, align 8
  %v79 = load i64, ptr %slot8, align 8
  %v80 = load i64, ptr %slot10, align 8
  %cmp81 = icmp eq i64 %v79, %v80
  %cv82 = zext i1 %cmp81 to i64
  store i64 %cv82, ptr %slot11, align 8
  %v83 = load i64, ptr %slot11, align 8
  %cond84 = icmp ne i64 %v83, 0
  br i1 %cond84, label %bb_limitfail2, label %bb_frameadmit0
bb_limitfail2:
  %v85 = load i64, ptr %slot1, align 8
  %p86 = inttoptr i64 %v85 to ptr
  call void @myl_qbe_fail_frame(ptr %p86)
  br label %bb_entry_failure
bb_frameadmit0:
  %mem87 = alloca i8, i64 32, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot12, align 8
  %v89 = load i64, ptr %slot1, align 8
  %op90 = add i64 %v89, 48
  store i64 %op90, ptr %slot13, align 8
  %v91 = load i64, ptr %slot13, align 8
  %p92 = inttoptr i64 %v91 to ptr
  %ld93 = load i64, ptr %p92, align 8, !alias.scope !4, !noalias !3
  store i64 %ld93, ptr %slot14, align 8
  %v94 = load i64, ptr %slot14, align 8
  %v95 = load i64, ptr %slot12, align 8
  %p96 = inttoptr i64 %v95 to ptr
  store i64 %v94, ptr %p96, align 8, !alias.scope !3, !noalias !4
  %v97 = load i64, ptr %slot12, align 8
  %p99 = inttoptr i64 %v97 to ptr
  %gep100 = getelementptr i8, ptr %p99, i64 8
  %op98 = ptrtoint ptr %gep100 to i64
  store i64 %op98, ptr %slot15, align 8
  %v101 = load i64, ptr %slot15, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 ptrtoint (ptr @myl_f_73f9bfebc60ce1b361ae437a0ef261224aaaef2e9cbd6eaa354fcc9949919970_meta to i64), ptr %p102, align 8, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot12, align 8
  %p105 = inttoptr i64 %v103 to ptr
  %gep106 = getelementptr i8, ptr %p105, i64 16
  %op104 = ptrtoint ptr %gep106 to i64
  store i64 %op104, ptr %slot16, align 8
  %v107 = load i64, ptr %slot16, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 0, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot12, align 8
  %v110 = load i64, ptr %slot13, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !4, !noalias !3
  %v112 = load i64, ptr %slot8, align 8
  %op113 = add i64 %v112, 1
  store i64 %op113, ptr %slot17, align 8
  %v114 = load i64, ptr %slot17, align 8
  %v115 = load i64, ptr %slot7, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !4, !noalias !3
  %v117 = load i64, ptr %slot12, align 8
  %p119 = inttoptr i64 %v117 to ptr
  %gep120 = getelementptr i8, ptr %p119, i64 16
  %op118 = ptrtoint ptr %gep120 to i64
  store i64 %op118, ptr %slot18, align 8
  %v121 = load i64, ptr %slot2, align 8
  %v122 = load i64, ptr %slot4, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i64 %v121, ptr %p123, align 8, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot1, align 8
  %op125 = add i64 %v124, 16
  store i64 %op125, ptr %slot19, align 8
  br label %bb_i0
bb_i0:
  %v126 = load i64, ptr %slot18, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 0, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot1, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !4, !noalias !3
  store i64 %ld130, ptr %slot20, align 8
  %v131 = load i64, ptr %slot19, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !4, !noalias !3
  store i64 %ld133, ptr %slot21, align 8
  %v134 = load i64, ptr %slot20, align 8
  %v135 = load i64, ptr %slot21, align 8
  %cmp136 = icmp eq i64 %v134, %v135
  %cv137 = zext i1 %cmp136 to i64
  store i64 %cv137, ptr %slot22, align 8
  %v138 = load i64, ptr %slot22, align 8
  %cond139 = icmp ne i64 %v138, 0
  br i1 %cond139, label %bb_step_limit, label %bb_step21
bb_step21:
  %v140 = load i64, ptr %slot20, align 8
  %op141 = add i64 %v140, 1
  store i64 %op141, ptr %slot23, align 8
  %v142 = load i64, ptr %slot23, align 8
  %v143 = load i64, ptr %slot1, align 8
  %p144 = inttoptr i64 %v143 to ptr
  store i64 %v142, ptr %p144, align 8, !alias.scope !4, !noalias !3
  %v145 = load i64, ptr %slot4, align 8
  %p146 = inttoptr i64 %v145 to ptr
  %ld147 = load i64, ptr %p146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld147, ptr %slot24, align 8
  %v148 = load i64, ptr %slot24, align 8
  %v149 = load i64, ptr %slot5, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i64 %v148, ptr %p150, align 8, !alias.scope !3, !noalias !4
  %v151 = load i64, ptr %slot18, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 1, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot1, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %ld155 = load i64, ptr %p154, align 8, !alias.scope !4, !noalias !3
  store i64 %ld155, ptr %slot25, align 8
  %v156 = load i64, ptr %slot19, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !4, !noalias !3
  store i64 %ld158, ptr %slot26, align 8
  %v159 = load i64, ptr %slot25, align 8
  %v160 = load i64, ptr %slot26, align 8
  %cmp161 = icmp eq i64 %v159, %v160
  %cv162 = zext i1 %cmp161 to i64
  store i64 %cv162, ptr %slot27, align 8
  %v163 = load i64, ptr %slot27, align 8
  %cond164 = icmp ne i64 %v163, 0
  br i1 %cond164, label %bb_step_limit, label %bb_step26
bb_step26:
  %v165 = load i64, ptr %slot25, align 8
  %op166 = add i64 %v165, 1
  store i64 %op166, ptr %slot28, align 8
  %v167 = load i64, ptr %slot28, align 8
  %v168 = load i64, ptr %slot1, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 %v167, ptr %p169, align 8, !alias.scope !4, !noalias !3
  %v170 = load i64, ptr %slot6, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i64 2, ptr %p171, align 8, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot18, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i64 2, ptr %p173, align 8, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot1, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !4, !noalias !3
  store i64 %ld176, ptr %slot29, align 8
  %v177 = load i64, ptr %slot19, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !4, !noalias !3
  store i64 %ld179, ptr %slot30, align 8
  %v180 = load i64, ptr %slot29, align 8
  %v181 = load i64, ptr %slot30, align 8
  %cmp182 = icmp eq i64 %v180, %v181
  %cv183 = zext i1 %cmp182 to i64
  store i64 %cv183, ptr %slot31, align 8
  %v184 = load i64, ptr %slot31, align 8
  %cond185 = icmp ne i64 %v184, 0
  br i1 %cond185, label %bb_step_limit, label %bb_step30
bb_step30:
  %v186 = load i64, ptr %slot29, align 8
  %op187 = add i64 %v186, 1
  store i64 %op187, ptr %slot32, align 8
  %v188 = load i64, ptr %slot32, align 8
  %v189 = load i64, ptr %slot1, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !4, !noalias !3
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot33, align 8
  %v194 = load i64, ptr %slot5, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i64, ptr %p195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld196, ptr %slot34, align 8
  %v197 = load i64, ptr %slot33, align 8
  %cmp198 = icmp eq i64 %v197, 0
  %cv199 = zext i1 %cmp198 to i64
  store i64 %cv199, ptr %slot35, align 8
  %v200 = load i64, ptr %slot35, align 8
  %cond201 = icmp ne i64 %v200, 0
  br i1 %cond201, label %bb_division33, label %bb_nonzero33
bb_division33:
  %v202 = load i64, ptr %slot1, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %v204 = load i64, ptr %slot34, align 8
  %v205 = load i64, ptr %slot33, align 8
  call void @myl_qbe_fail_division(ptr %p203, i64 6, i64 %v204, i64 %v205)
  br label %bb_failure
bb_nonzero33:
  %v206 = load i64, ptr %slot34, align 8
  %cmp207 = icmp eq i64 %v206, 9223372036854775808
  %cv208 = zext i1 %cmp207 to i64
  store i64 %cv208, ptr %slot36, align 8
  %v209 = load i64, ptr %slot33, align 8
  %cmp210 = icmp eq i64 %v209, 18446744073709551615
  %cv211 = zext i1 %cmp210 to i64
  store i64 %cv211, ptr %slot37, align 8
  %v212 = load i64, ptr %slot36, align 8
  %v213 = load i64, ptr %slot37, align 8
  %op214 = and i64 %v212, %v213
  store i64 %op214, ptr %slot38, align 8
  %v215 = load i64, ptr %slot38, align 8
  %neg216 = sub i64 0, %v215
  store i64 %neg216, ptr %slot39, align 8
  %v217 = load i64, ptr %slot33, align 8
  %op218 = xor i64 %v217, 1
  store i64 %op218, ptr %slot40, align 8
  %v219 = load i64, ptr %slot40, align 8
  %v220 = load i64, ptr %slot39, align 8
  %op221 = and i64 %v219, %v220
  store i64 %op221, ptr %slot40, align 8
  %v222 = load i64, ptr %slot33, align 8
  %v223 = load i64, ptr %slot40, align 8
  %op224 = xor i64 %v222, %v223
  store i64 %op224, ptr %slot41, align 8
  %v225 = load i64, ptr %slot34, align 8
  %v226 = load i64, ptr %slot41, align 8
  %op227 = srem i64 %v225, %v226
  store i64 %op227, ptr %slot42, align 8
  %v228 = load i64, ptr %slot42, align 8
  %cmp229 = icmp ne i64 %v228, 0
  %cv230 = zext i1 %cmp229 to i64
  store i64 %cv230, ptr %slot43, align 8
  %v231 = load i64, ptr %slot42, align 8
  %v232 = load i64, ptr %slot41, align 8
  %op233 = xor i64 %v231, %v232
  store i64 %op233, ptr %slot44, align 8
  %v234 = load i64, ptr %slot44, align 8
  %cmp235 = icmp slt i64 %v234, 0
  %cv236 = zext i1 %cmp235 to i64
  store i64 %cv236, ptr %slot45, align 8
  %v237 = load i64, ptr %slot43, align 8
  %v238 = load i64, ptr %slot45, align 8
  %op239 = and i64 %v237, %v238
  store i64 %op239, ptr %slot46, align 8
  %v240 = load i64, ptr %slot46, align 8
  %neg241 = sub i64 0, %v240
  store i64 %neg241, ptr %slot47, align 8
  %v242 = load i64, ptr %slot41, align 8
  %v243 = load i64, ptr %slot47, align 8
  %op244 = and i64 %v242, %v243
  store i64 %op244, ptr %slot48, align 8
  %v245 = load i64, ptr %slot42, align 8
  %v246 = load i64, ptr %slot48, align 8
  %op247 = add i64 %v245, %v246
  store i64 %op247, ptr %slot42, align 8
  %v248 = load i64, ptr %slot42, align 8
  %floorbounded249 = icmp ult i64 %v248, 2
  call void @llvm.assume(i1 %floorbounded249)
  %v250 = load i64, ptr %slot42, align 8
  %v251 = load i64, ptr %slot5, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot3, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !4, !noalias !3
  store i64 %ld255, ptr %slot49, align 8
  %v256 = load i64, ptr %slot49, align 8
  %cond257 = icmp ne i64 %v256, 0
  br i1 %cond257, label %bb_failure, label %bb_ok47
bb_ok47:
  %v258 = load i64, ptr %slot18, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 3, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot1, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !4, !noalias !3
  store i64 %ld262, ptr %slot50, align 8
  %v263 = load i64, ptr %slot19, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !4, !noalias !3
  store i64 %ld265, ptr %slot51, align 8
  %v266 = load i64, ptr %slot50, align 8
  %v267 = load i64, ptr %slot51, align 8
  %cmp268 = icmp eq i64 %v266, %v267
  %cv269 = zext i1 %cmp268 to i64
  store i64 %cv269, ptr %slot52, align 8
  %v270 = load i64, ptr %slot52, align 8
  %cond271 = icmp ne i64 %v270, 0
  br i1 %cond271, label %bb_step_limit, label %bb_step51
bb_step51:
  %v272 = load i64, ptr %slot50, align 8
  %op273 = add i64 %v272, 1
  store i64 %op273, ptr %slot53, align 8
  %v274 = load i64, ptr %slot53, align 8
  %v275 = load i64, ptr %slot1, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i64 %v274, ptr %p276, align 8, !alias.scope !4, !noalias !3
  %v277 = load i64, ptr %slot5, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot54, align 8
  %v280 = load i64, ptr %slot12, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot55, align 8
  %v283 = load i64, ptr %slot55, align 8
  %v284 = load i64, ptr %slot13, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i64 %v283, ptr %p285, align 8, !alias.scope !4, !noalias !3
  %v286 = load i64, ptr %slot7, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %ld288 = load i64, ptr %p287, align 8, !alias.scope !4, !noalias !3
  store i64 %ld288, ptr %slot56, align 8
  %v289 = load i64, ptr %slot56, align 8
  %op290 = sub i64 %v289, 1
  store i64 %op290, ptr %slot57, align 8
  %v291 = load i64, ptr %slot57, align 8
  %v292 = load i64, ptr %slot7, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !4, !noalias !3
  %v294 = load i64, ptr %slot54, align 8
  ret i64 %v294
bb_step_limit:
  %v295 = load i64, ptr %slot1, align 8
  %p296 = inttoptr i64 %v295 to ptr
  call void @myl_qbe_fail_step(ptr %p296)
  br label %bb_failure
bb_failure:
  %v297 = load i64, ptr %slot12, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot58, align 8
  %v300 = load i64, ptr %slot58, align 8
  %v301 = load i64, ptr %slot13, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !4, !noalias !3
  %v303 = load i64, ptr %slot7, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !4, !noalias !3
  store i64 %ld305, ptr %slot59, align 8
  %v306 = load i64, ptr %slot59, align 8
  %op307 = sub i64 %v306, 1
  store i64 %op307, ptr %slot60, align 8
  %v308 = load i64, ptr %slot60, align 8
  %v309 = load i64, ptr %slot7, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i64 %v308, ptr %p310, align 8, !alias.scope !4, !noalias !3
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_73f9bfebc60ce1b361ae437a0ef261224aaaef2e9cbd6eaa354fcc9949919970_meta = external global i8, align 8

declare void @llvm.assume(i1)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) cold
declare void @myl_qbe_fail_frame(ptr) cold
declare void @myl_qbe_fail_step(ptr) cold

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
