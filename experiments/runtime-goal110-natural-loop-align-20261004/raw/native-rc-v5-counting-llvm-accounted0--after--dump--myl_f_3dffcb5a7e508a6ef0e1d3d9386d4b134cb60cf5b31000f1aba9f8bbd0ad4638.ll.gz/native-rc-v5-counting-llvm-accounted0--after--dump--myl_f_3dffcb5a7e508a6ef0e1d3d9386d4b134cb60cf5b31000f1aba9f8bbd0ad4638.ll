target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v163 = load i64, ptr %slot1, align 8
  %op164 = add i64 %v163, 32
  store i64 %op164, ptr %slot4, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot5, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot6, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot7, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot8, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot9, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot10, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot11, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot12, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot13, align 8
  %v183 = load i64, ptr %slot2, align 8
  %v184 = load i64, ptr %slot5, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 %v183, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot3, align 8
  %v187 = load i64, ptr %slot6, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v189 = load i64, ptr %slot5, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot14, align 8
  %v192 = load i64, ptr %slot14, align 8
  %v193 = load i64, ptr %slot12, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot12, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %ld197 = load i64, ptr %p196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld197, ptr %slot15, align 8
  %v198 = load i64, ptr %slot7, align 8
  store i64 %v198, ptr %slot16, align 8
  %v199 = load i64, ptr %slot15, align 8
  %v200 = load i64, ptr %slot16, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot12, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 0, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot12, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot17, align 8
  %v207 = load i64, ptr %slot8, align 8
  store i64 %v207, ptr %slot18, align 8
  %v208 = load i64, ptr %slot17, align 8
  %v209 = load i64, ptr %slot18, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot19, align 8
  %v214 = load i64, ptr %slot19, align 8
  %v215 = load i64, ptr %slot12, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot12, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot20, align 8
  %v220 = load i64, ptr %slot9, align 8
  store i64 %v220, ptr %slot21, align 8
  %v221 = load i64, ptr %slot20, align 8
  %v222 = load i64, ptr %slot21, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot8, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot22, align 8
  %v227 = load i64, ptr %slot9, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot23, align 8
  %v230 = load i64, ptr %slot23, align 8
  %v231 = load i64, ptr %slot22, align 8
  %cmp232 = icmp sgt i64 %v230, %v231
  %cv233 = zext i1 %cmp232 to i64
  store i64 %cv233, ptr %slot24, align 8
  %v234 = load i64, ptr %slot23, align 8
  %v235 = load i64, ptr %slot22, align 8
  %op236 = sub i64 %v234, %v235
  store i64 %op236, ptr %slot25, align 8
  %v237 = load i64, ptr %slot25, align 8
  %cmp238 = icmp uge i64 %v237, 16
  %cv239 = zext i1 %cmp238 to i64
  store i64 %cv239, ptr %slot26, align 8
  %v240 = load i64, ptr %slot24, align 8
  %v241 = load i64, ptr %slot26, align 8
  %op242 = and i64 %v240, %v241
  store i64 %op242, ptr %slot27, align 8
  %v243 = load i64, ptr %slot27, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v245 = load i64, ptr %slot22, align 8
  %op246 = add i64 %v245, 1152921504606846976
  store i64 %op246, ptr %slot28, align 8
  %v247 = load i64, ptr %slot28, align 8
  %cmp248 = icmp ule i64 %v247, 2305843009213693952
  %cv249 = zext i1 %cmp248 to i64
  store i64 %cv249, ptr %slot29, align 8
  %v250 = load i64, ptr %slot29, align 8
  %cond251 = icmp ne i64 %v250, 0
  br i1 %cond251, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v252 = load i64, ptr %slot23, align 8
  %op253 = add i64 %v252, 1152921504606846976
  store i64 %op253, ptr %slot30, align 8
  %v254 = load i64, ptr %slot30, align 8
  %cmp255 = icmp ule i64 %v254, 2305843009213693952
  %cv256 = zext i1 %cmp255 to i64
  store i64 %cv256, ptr %slot31, align 8
  %v257 = load i64, ptr %slot31, align 8
  %cond258 = icmp ne i64 %v257, 0
  br i1 %cond258, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v259 = load i64, ptr %slot8, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot32, align 8
  %v262 = load i64, ptr %slot32, align 8
  %v263 = load i64, ptr %slot12, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot9, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot33, align 8
  %v268 = load i64, ptr %slot33, align 8
  %v269 = load i64, ptr %slot13, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot13, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot34, align 8
  %v274 = load i64, ptr %slot12, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot35, align 8
  %v277 = load i64, ptr %slot35, align 8
  %v278 = load i64, ptr %slot34, align 8
  %cmp279 = icmp slt i64 %v277, %v278
  %cv280 = zext i1 %cmp279 to i64
  store i64 %cv280, ptr %slot36, align 8
  %v281 = load i64, ptr %slot36, align 8
  %v282 = load i64, ptr %slot12, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot12, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot37, align 8
  %v287 = load i64, ptr %slot37, align 8
  %cond288 = icmp ne i64 %v287, 0
  br i1 %cond288, label %bb_next24, label %bb_i35
bb_next24:
  %v289 = load i64, ptr %slot8, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot38, align 8
  %v292 = load i64, ptr %slot38, align 8
  %v293 = load i64, ptr %slot12, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 %v292, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot13, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 3, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot13, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot39, align 8
  %v300 = load i64, ptr %slot12, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot40, align 8
  %v303 = load i64, ptr %slot40, align 8
  %op304 = add i64 %v303, 1152921504606846978
  store i64 %op304, ptr %slot41, align 8
  %v305 = load i64, ptr %slot41, align 8
  %v306 = load i64, ptr %slot39, align 8
  %op307 = urem i64 %v305, %v306
  store i64 %op307, ptr %slot42, align 8
  %v308 = load i64, ptr %slot42, align 8
  %v309 = load i64, ptr %slot12, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i64 %v308, ptr %p310, align 8, !alias.scope !3, !noalias !4
  %v311 = load i64, ptr %slot13, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 0, ptr %p312, align 8, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot13, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot43, align 8
  %v316 = load i64, ptr %slot12, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i64, ptr %p317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld318, ptr %slot44, align 8
  %v319 = load i64, ptr %slot44, align 8
  %v320 = load i64, ptr %slot43, align 8
  %cmp321 = icmp eq i64 %v319, %v320
  %cv322 = zext i1 %cmp321 to i64
  store i64 %cv322, ptr %slot45, align 8
  %v323 = load i64, ptr %slot45, align 8
  %v324 = load i64, ptr %slot12, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot12, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot46, align 8
  %v329 = load i64, ptr %slot46, align 8
  %cond330 = icmp ne i64 %v329, 0
  br i1 %cond330, label %bb_next33, label %bb_fi20
bb_next33:
  %v331 = load i64, ptr %slot12, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i64 17, ptr %p332, align 8, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot12, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %ld335 = load i64, ptr %p334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld335, ptr %slot47, align 8
  %v336 = load i64, ptr %slot47, align 8
  %neg337 = sub i64 0, %v336
  store i64 %neg337, ptr %slot48, align 8
  %v338 = load i64, ptr %slot47, align 8
  %cmp339 = icmp eq i64 %v338, 9223372036854775808
  %cv340 = zext i1 %cmp339 to i64
  store i64 %cv340, ptr %slot49, align 8
  %v341 = load i64, ptr %slot49, align 8
  %cond342 = icmp ne i64 %v341, 0
  br i1 %cond342, label %bb_neg_overflow34, label %bb_neg_checked34
bb_neg_overflow34:
  %v343 = load i64, ptr %slot1, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %v345 = load i64, ptr %slot47, align 8
  %call346 = call i64 @myl_qbe_int_neg(ptr %p344, i64 1, i64 64, i64 %v345) nomerge, !dbg !110
  unreachable
bb_neg_checked34:
  %v347 = load i64, ptr %slot48, align 8
  %v348 = load i64, ptr %slot12, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot12, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot50, align 8
  %v353 = load i64, ptr %slot10, align 8
  store i64 %v353, ptr %slot51, align 8
  %v354 = load i64, ptr %slot50, align 8
  %v355 = load i64, ptr %slot51, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i64 %v354, ptr %p356, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi20:
  %v357 = load i64, ptr %slot12, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 23, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot12, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %ld361 = load i64, ptr %p360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld361, ptr %slot52, align 8
  %v362 = load i64, ptr %slot10, align 8
  store i64 %v362, ptr %slot53, align 8
  %v363 = load i64, ptr %slot52, align 8
  %v364 = load i64, ptr %slot53, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi22:
  %v366 = load i64, ptr %slot10, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot54, align 8
  %v369 = load i64, ptr %slot54, align 8
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot12, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot55, align 8
  %v375 = load i64, ptr %slot11, align 8
  store i64 %v375, ptr %slot56, align 8
  %v376 = load i64, ptr %slot55, align 8
  %v377 = load i64, ptr %slot56, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 %v376, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot7, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot57, align 8
  %v382 = load i64, ptr %slot57, align 8
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i64 %v382, ptr %p384, align 8, !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot11, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i64, ptr %p386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld387, ptr %slot58, align 8
  %v388 = load i64, ptr %slot58, align 8
  %v389 = load i64, ptr %slot13, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 %v388, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot13, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot59, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot60, align 8
  %v397 = load i64, ptr %slot60, align 8
  %v398 = load i64, ptr %slot59, align 8
  %ovpair400 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v397, i64 %v398)
  %op399 = extractvalue { i64, i1 } %ovpair400, 0
  %ov401 = extractvalue { i64, i1 } %ovpair400, 1
  store i64 %op399, ptr %slot61, align 8
  %v402 = load i64, ptr %slot60, align 8
  %v403 = load i64, ptr %slot61, align 8
  %op404 = xor i64 %v402, %v403
  store i64 %op404, ptr %slot62, align 8
  %v405 = load i64, ptr %slot59, align 8
  %v406 = load i64, ptr %slot61, align 8
  %op407 = xor i64 %v405, %v406
  store i64 %op407, ptr %slot63, align 8
  %v408 = load i64, ptr %slot62, align 8
  %v409 = load i64, ptr %slot63, align 8
  %op410 = and i64 %v408, %v409
  store i64 %op410, ptr %slot64, align 8
  %cv411 = zext i1 %ov401 to i64
  store i64 %cv411, ptr %slot65, align 8
  %v412 = load i64, ptr %slot65, align 8
  %cond413 = icmp ne i64 %v412, 0
  br i1 %cond413, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v414 = load i64, ptr %slot1, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %v416 = load i64, ptr %slot60, align 8
  %v417 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p415, i64 0, i64 %v416, i64 %v417, i64 64) nomerge, !dbg !112
  unreachable
bb_checked47:
  %v418 = load i64, ptr %slot61, align 8
  %v419 = load i64, ptr %slot12, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot13, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 1000000007, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot13, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot66, align 8
  %v426 = load i64, ptr %slot12, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot67, align 8
  %v429 = load i64, ptr %slot66, align 8
  %cmp430 = icmp eq i64 %v429, 0
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot68, align 8
  %v432 = load i64, ptr %slot68, align 8
  %cond433 = icmp ne i64 %v432, 0
  br i1 %cond433, label %bb_division54, label %bb_nonzero54
bb_division54:
  %v434 = load i64, ptr %slot1, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %v436 = load i64, ptr %slot67, align 8
  %v437 = load i64, ptr %slot66, align 8
  call void @myl_qbe_fail_division(ptr %p435, i64 6, i64 %v436, i64 %v437) nomerge, !dbg !114
  unreachable
bb_nonzero54:
  %v438 = load i64, ptr %slot67, align 8
  %cmp439 = icmp eq i64 %v438, 9223372036854775808
  %cv440 = zext i1 %cmp439 to i64
  store i64 %cv440, ptr %slot69, align 8
  %v441 = load i64, ptr %slot66, align 8
  %cmp442 = icmp eq i64 %v441, 18446744073709551615
  %cv443 = zext i1 %cmp442 to i64
  store i64 %cv443, ptr %slot70, align 8
  %v444 = load i64, ptr %slot69, align 8
  %v445 = load i64, ptr %slot70, align 8
  %op446 = and i64 %v444, %v445
  store i64 %op446, ptr %slot71, align 8
  %v447 = load i64, ptr %slot71, align 8
  %neg448 = sub i64 0, %v447
  store i64 %neg448, ptr %slot72, align 8
  %v449 = load i64, ptr %slot66, align 8
  %op450 = xor i64 %v449, 1
  store i64 %op450, ptr %slot73, align 8
  %v451 = load i64, ptr %slot73, align 8
  %v452 = load i64, ptr %slot72, align 8
  %op453 = and i64 %v451, %v452
  store i64 %op453, ptr %slot73, align 8
  %v454 = load i64, ptr %slot66, align 8
  %v455 = load i64, ptr %slot73, align 8
  %op456 = xor i64 %v454, %v455
  store i64 %op456, ptr %slot74, align 8
  %v457 = load i64, ptr %slot67, align 8
  %v458 = load i64, ptr %slot74, align 8
  %op459 = srem i64 %v457, %v458
  store i64 %op459, ptr %slot75, align 8
  %v460 = load i64, ptr %slot75, align 8
  %cmp461 = icmp ne i64 %v460, 0
  %cv462 = zext i1 %cmp461 to i64
  store i64 %cv462, ptr %slot76, align 8
  %v463 = load i64, ptr %slot75, align 8
  %v464 = load i64, ptr %slot74, align 8
  %op465 = xor i64 %v463, %v464
  store i64 %op465, ptr %slot77, align 8
  %v466 = load i64, ptr %slot77, align 8
  %cmp467 = icmp slt i64 %v466, 0
  %cv468 = zext i1 %cmp467 to i64
  store i64 %cv468, ptr %slot78, align 8
  %v469 = load i64, ptr %slot76, align 8
  %v470 = load i64, ptr %slot78, align 8
  %op471 = and i64 %v469, %v470
  store i64 %op471, ptr %slot79, align 8
  %v472 = load i64, ptr %slot79, align 8
  %neg473 = sub i64 0, %v472
  store i64 %neg473, ptr %slot80, align 8
  %v474 = load i64, ptr %slot74, align 8
  %v475 = load i64, ptr %slot80, align 8
  %op476 = and i64 %v474, %v475
  store i64 %op476, ptr %slot81, align 8
  %v477 = load i64, ptr %slot75, align 8
  %v478 = load i64, ptr %slot81, align 8
  %op479 = add i64 %v477, %v478
  store i64 %op479, ptr %slot75, align 8
  %v480 = load i64, ptr %slot75, align 8
  %floorbounded481 = icmp ult i64 %v480, 1000000007
  call void @llvm.assume(i1 %floorbounded481)
  %v482 = load i64, ptr %slot75, align 8
  %v483 = load i64, ptr %slot12, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i64 %v482, ptr %p484, align 8, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot12, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i64, ptr %p486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot82, align 8
  %v488 = load i64, ptr %slot7, align 8
  store i64 %v488, ptr %slot83, align 8
  %v489 = load i64, ptr %slot82, align 8
  %v490 = load i64, ptr %slot83, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 %v489, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot8, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot84, align 8
  %v495 = load i64, ptr %slot84, align 8
  %v496 = load i64, ptr %slot12, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 %v495, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot13, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 1, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot13, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot85, align 8
  %v503 = load i64, ptr %slot12, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %ld505 = load i64, ptr %p504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld505, ptr %slot86, align 8
  %v506 = load i64, ptr %slot86, align 8
  %v507 = load i64, ptr %slot85, align 8
  %op508 = add i64 %v506, %v507
  store i64 %op508, ptr %slot87, align 8
  %v509 = load i64, ptr %slot87, align 8
  %v510 = load i64, ptr %slot12, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i64 %v509, ptr %p511, align 8, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot12, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %ld514 = load i64, ptr %p513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld514, ptr %slot88, align 8
  %v515 = load i64, ptr %slot8, align 8
  store i64 %v515, ptr %slot89, align 8
  %v516 = load i64, ptr %slot88, align 8
  %v517 = load i64, ptr %slot89, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 %v516, ptr %p518, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !121
bb_oi6:
  %v519 = load i64, ptr %slot8, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i64, ptr %p520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld521, ptr %slot90, align 8
  %v522 = load i64, ptr %slot90, align 8
  %v523 = load i64, ptr %slot12, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i64 %v522, ptr %p524, align 8, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot9, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld527, ptr %slot91, align 8
  %v528 = load i64, ptr %slot91, align 8
  %v529 = load i64, ptr %slot13, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i64 %v528, ptr %p530, align 8, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot13, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot92, align 8
  %v534 = load i64, ptr %slot12, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot93, align 8
  %v537 = load i64, ptr %slot93, align 8
  %v538 = load i64, ptr %slot92, align 8
  %cmp539 = icmp slt i64 %v537, %v538
  %cv540 = zext i1 %cmp539 to i64
  store i64 %cv540, ptr %slot94, align 8
  %v541 = load i64, ptr %slot94, align 8
  %v542 = load i64, ptr %slot12, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot12, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot95, align 8
  %v547 = load i64, ptr %slot95, align 8
  %cond548 = icmp ne i64 %v547, 0
  br i1 %cond548, label %bb_next82, label %bb_i35
bb_next82:
  %v549 = load i64, ptr %slot8, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %ld551 = load i64, ptr %p550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld551, ptr %slot96, align 8
  %v552 = load i64, ptr %slot96, align 8
  %v553 = load i64, ptr %slot12, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i64 %v552, ptr %p554, align 8, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot13, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 3, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot13, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot97, align 8
  %v560 = load i64, ptr %slot12, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot98, align 8
  %v563 = load i64, ptr %slot97, align 8
  %cmp564 = icmp eq i64 %v563, 0
  %cv565 = zext i1 %cmp564 to i64
  store i64 %cv565, ptr %slot99, align 8
  %v566 = load i64, ptr %slot99, align 8
  %cond567 = icmp ne i64 %v566, 0
  br i1 %cond567, label %bb_division85, label %bb_nonzero85
bb_division85:
  %v568 = load i64, ptr %slot1, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %v570 = load i64, ptr %slot98, align 8
  %v571 = load i64, ptr %slot97, align 8
  call void @myl_qbe_fail_division(ptr %p569, i64 6, i64 %v570, i64 %v571) nomerge, !dbg !116
  unreachable
bb_nonzero85:
  %v572 = load i64, ptr %slot98, align 8
  %cmp573 = icmp eq i64 %v572, 9223372036854775808
  %cv574 = zext i1 %cmp573 to i64
  store i64 %cv574, ptr %slot100, align 8
  %v575 = load i64, ptr %slot97, align 8
  %cmp576 = icmp eq i64 %v575, 18446744073709551615
  %cv577 = zext i1 %cmp576 to i64
  store i64 %cv577, ptr %slot101, align 8
  %v578 = load i64, ptr %slot100, align 8
  %v579 = load i64, ptr %slot101, align 8
  %op580 = and i64 %v578, %v579
  store i64 %op580, ptr %slot102, align 8
  %v581 = load i64, ptr %slot102, align 8
  %neg582 = sub i64 0, %v581
  store i64 %neg582, ptr %slot103, align 8
  %v583 = load i64, ptr %slot97, align 8
  %op584 = xor i64 %v583, 1
  store i64 %op584, ptr %slot104, align 8
  %v585 = load i64, ptr %slot104, align 8
  %v586 = load i64, ptr %slot103, align 8
  %op587 = and i64 %v585, %v586
  store i64 %op587, ptr %slot104, align 8
  %v588 = load i64, ptr %slot97, align 8
  %v589 = load i64, ptr %slot104, align 8
  %op590 = xor i64 %v588, %v589
  store i64 %op590, ptr %slot105, align 8
  %v591 = load i64, ptr %slot98, align 8
  %v592 = load i64, ptr %slot105, align 8
  %op593 = srem i64 %v591, %v592
  store i64 %op593, ptr %slot106, align 8
  %v594 = load i64, ptr %slot106, align 8
  %cmp595 = icmp ne i64 %v594, 0
  %cv596 = zext i1 %cmp595 to i64
  store i64 %cv596, ptr %slot107, align 8
  %v597 = load i64, ptr %slot106, align 8
  %v598 = load i64, ptr %slot105, align 8
  %op599 = xor i64 %v597, %v598
  store i64 %op599, ptr %slot108, align 8
  %v600 = load i64, ptr %slot108, align 8
  %cmp601 = icmp slt i64 %v600, 0
  %cv602 = zext i1 %cmp601 to i64
  store i64 %cv602, ptr %slot109, align 8
  %v603 = load i64, ptr %slot107, align 8
  %v604 = load i64, ptr %slot109, align 8
  %op605 = and i64 %v603, %v604
  store i64 %op605, ptr %slot110, align 8
  %v606 = load i64, ptr %slot110, align 8
  %neg607 = sub i64 0, %v606
  store i64 %neg607, ptr %slot111, align 8
  %v608 = load i64, ptr %slot105, align 8
  %v609 = load i64, ptr %slot111, align 8
  %op610 = and i64 %v608, %v609
  store i64 %op610, ptr %slot112, align 8
  %v611 = load i64, ptr %slot106, align 8
  %v612 = load i64, ptr %slot112, align 8
  %op613 = add i64 %v611, %v612
  store i64 %op613, ptr %slot106, align 8
  %v614 = load i64, ptr %slot106, align 8
  %floorbounded615 = icmp ult i64 %v614, 3
  call void @llvm.assume(i1 %floorbounded615)
  %v616 = load i64, ptr %slot106, align 8
  %v617 = load i64, ptr %slot12, align 8
  %p618 = inttoptr i64 %v617 to ptr
  store i64 %v616, ptr %p618, align 8, !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot13, align 8
  %p620 = inttoptr i64 %v619 to ptr
  store i64 0, ptr %p620, align 8, !alias.scope !3, !noalias !4
  %v621 = load i64, ptr %slot13, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ld623 = load i64, ptr %p622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld623, ptr %slot113, align 8
  %v624 = load i64, ptr %slot12, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %ld626 = load i64, ptr %p625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld626, ptr %slot114, align 8
  %v627 = load i64, ptr %slot114, align 8
  %v628 = load i64, ptr %slot113, align 8
  %cmp629 = icmp eq i64 %v627, %v628
  %cv630 = zext i1 %cmp629 to i64
  store i64 %cv630, ptr %slot115, align 8
  %v631 = load i64, ptr %slot115, align 8
  %v632 = load i64, ptr %slot12, align 8
  %p633 = inttoptr i64 %v632 to ptr
  store i64 %v631, ptr %p633, align 8, !alias.scope !3, !noalias !4
  %v634 = load i64, ptr %slot12, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %ld636 = load i64, ptr %p635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld636, ptr %slot116, align 8
  %v637 = load i64, ptr %slot116, align 8
  %cond638 = icmp ne i64 %v637, 0
  br i1 %cond638, label %bb_next103, label %bb_i20
bb_next103:
  %v639 = load i64, ptr %slot12, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 17, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot12, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot117, align 8
  %v644 = load i64, ptr %slot117, align 8
  %neg645 = sub i64 0, %v644
  store i64 %neg645, ptr %slot118, align 8
  %v646 = load i64, ptr %slot117, align 8
  %cmp647 = icmp eq i64 %v646, 9223372036854775808
  %cv648 = zext i1 %cmp647 to i64
  store i64 %cv648, ptr %slot119, align 8
  %v649 = load i64, ptr %slot119, align 8
  %cond650 = icmp ne i64 %v649, 0
  br i1 %cond650, label %bb_neg_overflow104, label %bb_neg_checked104
bb_neg_overflow104:
  %v651 = load i64, ptr %slot1, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %v653 = load i64, ptr %slot117, align 8
  %call654 = call i64 @myl_qbe_int_neg(ptr %p652, i64 1, i64 64, i64 %v653) nomerge, !dbg !110
  unreachable
bb_neg_checked104:
  %v655 = load i64, ptr %slot118, align 8
  %v656 = load i64, ptr %slot12, align 8
  %p657 = inttoptr i64 %v656 to ptr
  store i64 %v655, ptr %p657, align 8, !alias.scope !3, !noalias !4
  %v658 = load i64, ptr %slot12, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %ld660 = load i64, ptr %p659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld660, ptr %slot120, align 8
  %v661 = load i64, ptr %slot10, align 8
  store i64 %v661, ptr %slot121, align 8
  %v662 = load i64, ptr %slot120, align 8
  %v663 = load i64, ptr %slot121, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i64 %v662, ptr %p664, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i20:
  %v665 = load i64, ptr %slot12, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i64 23, ptr %p666, align 8, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot12, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot122, align 8
  %v670 = load i64, ptr %slot10, align 8
  store i64 %v670, ptr %slot123, align 8
  %v671 = load i64, ptr %slot122, align 8
  %v672 = load i64, ptr %slot123, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i64 %v671, ptr %p673, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v674 = load i64, ptr %slot10, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot124, align 8
  %v677 = load i64, ptr %slot124, align 8
  %v678 = load i64, ptr %slot12, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i64 %v677, ptr %p679, align 8, !alias.scope !3, !noalias !4
  %v680 = load i64, ptr %slot12, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %ld682 = load i64, ptr %p681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld682, ptr %slot125, align 8
  %v683 = load i64, ptr %slot11, align 8
  store i64 %v683, ptr %slot126, align 8
  %v684 = load i64, ptr %slot125, align 8
  %v685 = load i64, ptr %slot126, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot7, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i64, ptr %p688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld689, ptr %slot127, align 8
  %v690 = load i64, ptr %slot127, align 8
  %v691 = load i64, ptr %slot12, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot11, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %ld695 = load i64, ptr %p694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld695, ptr %slot128, align 8
  %v696 = load i64, ptr %slot128, align 8
  %v697 = load i64, ptr %slot13, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i64 %v696, ptr %p698, align 8, !alias.scope !3, !noalias !4
  %v699 = load i64, ptr %slot13, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %ld701 = load i64, ptr %p700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld701, ptr %slot129, align 8
  %v702 = load i64, ptr %slot12, align 8
  %p703 = inttoptr i64 %v702 to ptr
  %ld704 = load i64, ptr %p703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld704, ptr %slot130, align 8
  %v705 = load i64, ptr %slot130, align 8
  %v706 = load i64, ptr %slot129, align 8
  %ovpair708 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v705, i64 %v706)
  %op707 = extractvalue { i64, i1 } %ovpair708, 0
  %ov709 = extractvalue { i64, i1 } %ovpair708, 1
  store i64 %op707, ptr %slot131, align 8
  %v710 = load i64, ptr %slot130, align 8
  %v711 = load i64, ptr %slot131, align 8
  %op712 = xor i64 %v710, %v711
  store i64 %op712, ptr %slot132, align 8
  %v713 = load i64, ptr %slot129, align 8
  %v714 = load i64, ptr %slot131, align 8
  %op715 = xor i64 %v713, %v714
  store i64 %op715, ptr %slot133, align 8
  %v716 = load i64, ptr %slot132, align 8
  %v717 = load i64, ptr %slot133, align 8
  %op718 = and i64 %v716, %v717
  store i64 %op718, ptr %slot134, align 8
  %cv719 = zext i1 %ov709 to i64
  store i64 %cv719, ptr %slot135, align 8
  %v720 = load i64, ptr %slot135, align 8
  %cond721 = icmp ne i64 %v720, 0
  br i1 %cond721, label %bb_overflow117, label %bb_checked117
bb_overflow117:
  %v722 = load i64, ptr %slot1, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %v724 = load i64, ptr %slot130, align 8
  %v725 = load i64, ptr %slot129, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p723, i64 0, i64 %v724, i64 %v725, i64 64) nomerge, !dbg !112
  unreachable
bb_checked117:
  %v726 = load i64, ptr %slot131, align 8
  %v727 = load i64, ptr %slot12, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 %v726, ptr %p728, align 8, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot13, align 8
  %p730 = inttoptr i64 %v729 to ptr
  store i64 1000000007, ptr %p730, align 8, !alias.scope !3, !noalias !4
  %v731 = load i64, ptr %slot13, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i64, ptr %p732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld733, ptr %slot136, align 8
  %v734 = load i64, ptr %slot12, align 8
  %p735 = inttoptr i64 %v734 to ptr
  %ld736 = load i64, ptr %p735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld736, ptr %slot137, align 8
  %v737 = load i64, ptr %slot136, align 8
  %cmp738 = icmp eq i64 %v737, 0
  %cv739 = zext i1 %cmp738 to i64
  store i64 %cv739, ptr %slot138, align 8
  %v740 = load i64, ptr %slot138, align 8
  %cond741 = icmp ne i64 %v740, 0
  br i1 %cond741, label %bb_division124, label %bb_nonzero124
bb_division124:
  %v742 = load i64, ptr %slot1, align 8
  %p743 = inttoptr i64 %v742 to ptr
  %v744 = load i64, ptr %slot137, align 8
  %v745 = load i64, ptr %slot136, align 8
  call void @myl_qbe_fail_division(ptr %p743, i64 6, i64 %v744, i64 %v745) nomerge, !dbg !114
  unreachable
bb_nonzero124:
  %v746 = load i64, ptr %slot137, align 8
  %cmp747 = icmp eq i64 %v746, 9223372036854775808
  %cv748 = zext i1 %cmp747 to i64
  store i64 %cv748, ptr %slot139, align 8
  %v749 = load i64, ptr %slot136, align 8
  %cmp750 = icmp eq i64 %v749, 18446744073709551615
  %cv751 = zext i1 %cmp750 to i64
  store i64 %cv751, ptr %slot140, align 8
  %v752 = load i64, ptr %slot139, align 8
  %v753 = load i64, ptr %slot140, align 8
  %op754 = and i64 %v752, %v753
  store i64 %op754, ptr %slot141, align 8
  %v755 = load i64, ptr %slot141, align 8
  %neg756 = sub i64 0, %v755
  store i64 %neg756, ptr %slot142, align 8
  %v757 = load i64, ptr %slot136, align 8
  %op758 = xor i64 %v757, 1
  store i64 %op758, ptr %slot143, align 8
  %v759 = load i64, ptr %slot143, align 8
  %v760 = load i64, ptr %slot142, align 8
  %op761 = and i64 %v759, %v760
  store i64 %op761, ptr %slot143, align 8
  %v762 = load i64, ptr %slot136, align 8
  %v763 = load i64, ptr %slot143, align 8
  %op764 = xor i64 %v762, %v763
  store i64 %op764, ptr %slot144, align 8
  %v765 = load i64, ptr %slot137, align 8
  %v766 = load i64, ptr %slot144, align 8
  %op767 = srem i64 %v765, %v766
  store i64 %op767, ptr %slot145, align 8
  %v768 = load i64, ptr %slot145, align 8
  %cmp769 = icmp ne i64 %v768, 0
  %cv770 = zext i1 %cmp769 to i64
  store i64 %cv770, ptr %slot146, align 8
  %v771 = load i64, ptr %slot145, align 8
  %v772 = load i64, ptr %slot144, align 8
  %op773 = xor i64 %v771, %v772
  store i64 %op773, ptr %slot147, align 8
  %v774 = load i64, ptr %slot147, align 8
  %cmp775 = icmp slt i64 %v774, 0
  %cv776 = zext i1 %cmp775 to i64
  store i64 %cv776, ptr %slot148, align 8
  %v777 = load i64, ptr %slot146, align 8
  %v778 = load i64, ptr %slot148, align 8
  %op779 = and i64 %v777, %v778
  store i64 %op779, ptr %slot149, align 8
  %v780 = load i64, ptr %slot149, align 8
  %neg781 = sub i64 0, %v780
  store i64 %neg781, ptr %slot150, align 8
  %v782 = load i64, ptr %slot144, align 8
  %v783 = load i64, ptr %slot150, align 8
  %op784 = and i64 %v782, %v783
  store i64 %op784, ptr %slot151, align 8
  %v785 = load i64, ptr %slot145, align 8
  %v786 = load i64, ptr %slot151, align 8
  %op787 = add i64 %v785, %v786
  store i64 %op787, ptr %slot145, align 8
  %v788 = load i64, ptr %slot145, align 8
  %floorbounded789 = icmp ult i64 %v788, 1000000007
  call void @llvm.assume(i1 %floorbounded789)
  %v790 = load i64, ptr %slot145, align 8
  %v791 = load i64, ptr %slot12, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 %v790, ptr %p792, align 8, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot12, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i64, ptr %p794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld795, ptr %slot152, align 8
  %v796 = load i64, ptr %slot7, align 8
  store i64 %v796, ptr %slot153, align 8
  %v797 = load i64, ptr %slot152, align 8
  %v798 = load i64, ptr %slot153, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot8, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot154, align 8
  %v803 = load i64, ptr %slot154, align 8
  %v804 = load i64, ptr %slot12, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i64 %v803, ptr %p805, align 8, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot13, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i64 1, ptr %p807, align 8, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot13, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot155, align 8
  %v811 = load i64, ptr %slot12, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i64, ptr %p812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld813, ptr %slot156, align 8
  %v814 = load i64, ptr %slot156, align 8
  %v815 = load i64, ptr %slot155, align 8
  %op816 = add i64 %v814, %v815
  %ovpair817 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v814, i64 %v815)
  %ov818 = extractvalue { i64, i1 } %ovpair817, 1
  store i64 %op816, ptr %slot157, align 8
  %cv819 = zext i1 %ov818 to i64
  store i64 %cv819, ptr %slot158, align 8
  %v820 = load i64, ptr %slot158, align 8
  %cond821 = icmp ne i64 %v820, 0
  br i1 %cond821, label %bb_overflow143, label %bb_checked143
bb_overflow143:
  %v822 = load i64, ptr %slot1, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %v824 = load i64, ptr %slot156, align 8
  %v825 = load i64, ptr %slot155, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p823, i64 0, i64 %v824, i64 %v825, i64 64) nomerge, !dbg !118
  unreachable
bb_checked143:
  %v826 = load i64, ptr %slot157, align 8
  %v827 = load i64, ptr %slot12, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i64 %v826, ptr %p828, align 8, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot12, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i64, ptr %p830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld831, ptr %slot159, align 8
  %v832 = load i64, ptr %slot8, align 8
  store i64 %v832, ptr %slot160, align 8
  %v833 = load i64, ptr %slot159, align 8
  %v834 = load i64, ptr %slot160, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 %v833, ptr %p835, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !122
bb_i35:
  %v836 = load i64, ptr %slot7, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot161, align 8
  %v839 = load i64, ptr %slot161, align 8
  %v840 = load i64, ptr %slot12, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i64 %v839, ptr %p841, align 8, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot12, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i64, ptr %p843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld844, ptr %slot162, align 8
  %v845 = load i64, ptr %slot162, align 8
  ret i64 %v845
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", linkageName: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4316030661171315038, i64 0, !"myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!110 = !DILocation(line: 18, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
!120 = !{!"llvm.loop.align", i32 32}
!121 = distinct !{!121, !120}
!122 = distinct !{!122, !120}
