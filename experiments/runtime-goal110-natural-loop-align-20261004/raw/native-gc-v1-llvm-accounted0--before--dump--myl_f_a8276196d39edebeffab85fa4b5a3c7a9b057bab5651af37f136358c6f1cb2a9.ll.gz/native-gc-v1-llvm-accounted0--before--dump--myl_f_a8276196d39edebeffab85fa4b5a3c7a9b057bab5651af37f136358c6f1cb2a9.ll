target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a8276196d39edebeffab85fa4b5a3c7a9b057bab5651af37f136358c6f1cb2a9(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v25 = load i64, ptr %slot1, align 8
  %op26 = add i64 %v25, 32
  store i64 %op26, ptr %slot3, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot4, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot5, align 8
  %mem31 = alloca i8, i64 8, align 8
  %ptr32 = ptrtoint ptr %mem31 to i64
  store i64 %ptr32, ptr %slot6, align 8
  %v33 = load i64, ptr %slot2, align 8
  %v34 = load i64, ptr %slot4, align 8
  %p35 = inttoptr i64 %v34 to ptr
  store i64 %v33, ptr %p35, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v36 = load i64, ptr %slot4, align 8
  %p37 = inttoptr i64 %v36 to ptr
  %ld38 = load i64, ptr %p37, align 8, !alias.scope !3, !noalias !4
  store i64 %ld38, ptr %slot7, align 8
  %v39 = load i64, ptr %slot7, align 8
  %v40 = load i64, ptr %slot5, align 8
  %p41 = inttoptr i64 %v40 to ptr
  store i64 %v39, ptr %p41, align 8, !alias.scope !3, !noalias !4
  %v42 = load i64, ptr %slot6, align 8
  %p43 = inttoptr i64 %v42 to ptr
  store i64 1000000007, ptr %p43, align 8, !alias.scope !3, !noalias !4
  %v44 = load i64, ptr %slot6, align 8
  %p45 = inttoptr i64 %v44 to ptr
  %ld46 = load i64, ptr %p45, align 8, !alias.scope !3, !noalias !4
  store i64 %ld46, ptr %slot8, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  %ld49 = load i64, ptr %p48, align 8, !alias.scope !3, !noalias !4
  store i64 %ld49, ptr %slot9, align 8
  %v50 = load i64, ptr %slot8, align 8
  %cmp51 = icmp eq i64 %v50, 0
  %cv52 = zext i1 %cmp51 to i64
  store i64 %cv52, ptr %slot10, align 8
  %v53 = load i64, ptr %slot10, align 8
  %cond54 = icmp ne i64 %v53, 0
  br i1 %cond54, label %bb_division3, label %bb_nonzero3
bb_division3:
  %v55 = load i64, ptr %slot1, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %v57 = load i64, ptr %slot9, align 8
  %v58 = load i64, ptr %slot8, align 8
  call void @myl_qbe_fail_division(ptr %p56, i64 6, i64 %v57, i64 %v58) nomerge, !dbg !110
  unreachable
bb_nonzero3:
  %v59 = load i64, ptr %slot9, align 8
  %cmp60 = icmp eq i64 %v59, 9223372036854775808
  %cv61 = zext i1 %cmp60 to i64
  store i64 %cv61, ptr %slot11, align 8
  %v62 = load i64, ptr %slot8, align 8
  %cmp63 = icmp eq i64 %v62, 18446744073709551615
  %cv64 = zext i1 %cmp63 to i64
  store i64 %cv64, ptr %slot12, align 8
  %v65 = load i64, ptr %slot11, align 8
  %v66 = load i64, ptr %slot12, align 8
  %op67 = and i64 %v65, %v66
  store i64 %op67, ptr %slot13, align 8
  %v68 = load i64, ptr %slot13, align 8
  %neg69 = sub i64 0, %v68
  store i64 %neg69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot8, align 8
  %op71 = xor i64 %v70, 1
  store i64 %op71, ptr %slot15, align 8
  %v72 = load i64, ptr %slot15, align 8
  %v73 = load i64, ptr %slot14, align 8
  %op74 = and i64 %v72, %v73
  store i64 %op74, ptr %slot15, align 8
  %v75 = load i64, ptr %slot8, align 8
  %v76 = load i64, ptr %slot15, align 8
  %op77 = xor i64 %v75, %v76
  store i64 %op77, ptr %slot16, align 8
  %v78 = load i64, ptr %slot9, align 8
  %v79 = load i64, ptr %slot16, align 8
  %op80 = srem i64 %v78, %v79
  store i64 %op80, ptr %slot17, align 8
  %v81 = load i64, ptr %slot17, align 8
  %cmp82 = icmp ne i64 %v81, 0
  %cv83 = zext i1 %cmp82 to i64
  store i64 %cv83, ptr %slot18, align 8
  %v84 = load i64, ptr %slot17, align 8
  %v85 = load i64, ptr %slot16, align 8
  %op86 = xor i64 %v84, %v85
  store i64 %op86, ptr %slot19, align 8
  %v87 = load i64, ptr %slot19, align 8
  %cmp88 = icmp slt i64 %v87, 0
  %cv89 = zext i1 %cmp88 to i64
  store i64 %cv89, ptr %slot20, align 8
  %v90 = load i64, ptr %slot18, align 8
  %v91 = load i64, ptr %slot20, align 8
  %op92 = and i64 %v90, %v91
  store i64 %op92, ptr %slot21, align 8
  %v93 = load i64, ptr %slot21, align 8
  %neg94 = sub i64 0, %v93
  store i64 %neg94, ptr %slot22, align 8
  %v95 = load i64, ptr %slot16, align 8
  %v96 = load i64, ptr %slot22, align 8
  %op97 = and i64 %v95, %v96
  store i64 %op97, ptr %slot23, align 8
  %v98 = load i64, ptr %slot17, align 8
  %v99 = load i64, ptr %slot23, align 8
  %op100 = add i64 %v98, %v99
  store i64 %op100, ptr %slot17, align 8
  %v101 = load i64, ptr %slot17, align 8
  %v102 = load i64, ptr %slot5, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 %v101, ptr %p103, align 8, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot5, align 8
  %p105 = inttoptr i64 %v104 to ptr
  %ld106 = load i64, ptr %p105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld106, ptr %slot24, align 8
  %v107 = load i64, ptr %slot24, align 8
  ret i64 %v107
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a8276196d39edebeffab85fa4b5a3c7a9b057bab5651af37f136358c6f1cb2a9", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a8276196d39edebeffab85fa4b5a3c7a9b057bab5651af37f136358c6f1cb2a9", linkageName: "myl_f_a8276196d39edebeffab85fa4b5a3c7a9b057bab5651af37f136358c6f1cb2a9", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15774273631881968003, i64 0, !"myl_f_a8276196d39edebeffab85fa4b5a3c7a9b057bab5651af37f136358c6f1cb2a9"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
