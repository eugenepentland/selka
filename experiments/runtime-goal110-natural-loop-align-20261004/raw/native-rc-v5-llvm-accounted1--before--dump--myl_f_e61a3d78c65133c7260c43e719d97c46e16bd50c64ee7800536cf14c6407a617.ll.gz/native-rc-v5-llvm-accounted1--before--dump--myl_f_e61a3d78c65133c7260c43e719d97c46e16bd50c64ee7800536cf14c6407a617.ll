target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v79 = load i64, ptr %slot1, align 8
  %op80 = add i64 %v79, 32
  store i64 %op80, ptr %slot4, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot5, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot6, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot7, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot8, align 8
  %v89 = load i64, ptr %slot1, align 8
  %op90 = add i64 %v89, 8
  store i64 %op90, ptr %slot9, align 8
  %v91 = load i64, ptr %slot9, align 8
  %p92 = inttoptr i64 %v91 to ptr
  %ld93 = load i64, ptr %p92, align 8, !alias.scope !4, !noalias !3
  store i64 %ld93, ptr %slot10, align 8
  %v94 = load i64, ptr %slot1, align 8
  %op95 = add i64 %v94, 56
  store i64 %op95, ptr %slot11, align 8
  %v96 = load i64, ptr %slot11, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !4, !noalias !3
  store i64 %ld98, ptr %slot12, align 8
  %v99 = load i64, ptr %slot10, align 8
  %v100 = load i64, ptr %slot12, align 8
  %cmp101 = icmp eq i64 %v99, %v100
  %cv102 = zext i1 %cmp101 to i64
  store i64 %cv102, ptr %slot13, align 8
  %v103 = load i64, ptr %slot13, align 8
  %cond104 = icmp ne i64 %v103, 0
  br i1 %cond104, label %bb_limitfail2, label %bb_frameadmit0
bb_limitfail2:
  %v105 = load i64, ptr %slot1, align 8
  %p106 = inttoptr i64 %v105 to ptr
  call void @myl_qbe_fail_frame(ptr %p106)
  br label %bb_entry_failure
bb_frameadmit0:
  %mem107 = alloca i8, i64 32, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot14, align 8
  %v109 = load i64, ptr %slot1, align 8
  %op110 = add i64 %v109, 48
  store i64 %op110, ptr %slot15, align 8
  %v111 = load i64, ptr %slot15, align 8
  %p112 = inttoptr i64 %v111 to ptr
  %ld113 = load i64, ptr %p112, align 8, !alias.scope !4, !noalias !3
  store i64 %ld113, ptr %slot16, align 8
  %v114 = load i64, ptr %slot16, align 8
  %v115 = load i64, ptr %slot14, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot14, align 8
  %p119 = inttoptr i64 %v117 to ptr
  %gep120 = getelementptr i8, ptr %p119, i64 8
  %op118 = ptrtoint ptr %gep120 to i64
  store i64 %op118, ptr %slot17, align 8
  %v121 = load i64, ptr %slot17, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i64 ptrtoint (ptr @myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617_meta to i64), ptr %p122, align 8, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot14, align 8
  %p125 = inttoptr i64 %v123 to ptr
  %gep126 = getelementptr i8, ptr %p125, i64 16
  %op124 = ptrtoint ptr %gep126 to i64
  store i64 %op124, ptr %slot18, align 8
  %v127 = load i64, ptr %slot18, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 0, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot14, align 8
  %v130 = load i64, ptr %slot15, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i64 %v129, ptr %p131, align 8, !alias.scope !4, !noalias !3
  %v132 = load i64, ptr %slot10, align 8
  %op133 = add i64 %v132, 1
  store i64 %op133, ptr %slot19, align 8
  %v134 = load i64, ptr %slot19, align 8
  %v135 = load i64, ptr %slot9, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i64 %v134, ptr %p136, align 8, !alias.scope !4, !noalias !3
  %v137 = load i64, ptr %slot14, align 8
  %p139 = inttoptr i64 %v137 to ptr
  %gep140 = getelementptr i8, ptr %p139, i64 16
  %op138 = ptrtoint ptr %gep140 to i64
  store i64 %op138, ptr %slot20, align 8
  %v141 = load i64, ptr %slot2, align 8
  %v142 = load i64, ptr %slot5, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot3, align 8
  %v145 = load i64, ptr %slot6, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot1, align 8
  %op148 = add i64 %v147, 16
  store i64 %op148, ptr %slot21, align 8
  br label %bb_i0
bb_i0:
  %v149 = load i64, ptr %slot20, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i64 0, ptr %p150, align 8, !alias.scope !3, !noalias !4
  %v151 = load i64, ptr %slot1, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i64, ptr %p152, align 8, !alias.scope !4, !noalias !3
  store i64 %ld153, ptr %slot22, align 8
  %v154 = load i64, ptr %slot21, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !4, !noalias !3
  store i64 %ld156, ptr %slot23, align 8
  %v157 = load i64, ptr %slot22, align 8
  %v158 = load i64, ptr %slot23, align 8
  %cmp159 = icmp eq i64 %v157, %v158
  %cv160 = zext i1 %cmp159 to i64
  store i64 %cv160, ptr %slot24, align 8
  %v161 = load i64, ptr %slot24, align 8
  %cond162 = icmp ne i64 %v161, 0
  br i1 %cond162, label %bb_step_limit, label %bb_step21
bb_step21:
  %v163 = load i64, ptr %slot22, align 8
  %op164 = add i64 %v163, 1
  store i64 %op164, ptr %slot25, align 8
  %v165 = load i64, ptr %slot25, align 8
  %v166 = load i64, ptr %slot1, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !4, !noalias !3
  %v168 = load i64, ptr %slot5, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot26, align 8
  %v171 = load i64, ptr %slot26, align 8
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i64 %v171, ptr %p173, align 8, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot20, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 1, ptr %p175, align 8, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot1, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %ld178 = load i64, ptr %p177, align 8, !alias.scope !4, !noalias !3
  store i64 %ld178, ptr %slot27, align 8
  %v179 = load i64, ptr %slot21, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !4, !noalias !3
  store i64 %ld181, ptr %slot28, align 8
  %v182 = load i64, ptr %slot27, align 8
  %v183 = load i64, ptr %slot28, align 8
  %cmp184 = icmp eq i64 %v182, %v183
  %cv185 = zext i1 %cmp184 to i64
  store i64 %cv185, ptr %slot29, align 8
  %v186 = load i64, ptr %slot29, align 8
  %cond187 = icmp ne i64 %v186, 0
  br i1 %cond187, label %bb_step_limit, label %bb_step26
bb_step26:
  %v188 = load i64, ptr %slot27, align 8
  %op189 = add i64 %v188, 1
  store i64 %op189, ptr %slot30, align 8
  %v190 = load i64, ptr %slot30, align 8
  %v191 = load i64, ptr %slot1, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !4, !noalias !3
  %v193 = load i64, ptr %slot6, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot31, align 8
  %v196 = load i64, ptr %slot31, align 8
  %v197 = load i64, ptr %slot8, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot20, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 2, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot1, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !4, !noalias !3
  store i64 %ld203, ptr %slot32, align 8
  %v204 = load i64, ptr %slot21, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !4, !noalias !3
  store i64 %ld206, ptr %slot33, align 8
  %v207 = load i64, ptr %slot32, align 8
  %v208 = load i64, ptr %slot33, align 8
  %cmp209 = icmp eq i64 %v207, %v208
  %cv210 = zext i1 %cmp209 to i64
  store i64 %cv210, ptr %slot34, align 8
  %v211 = load i64, ptr %slot34, align 8
  %cond212 = icmp ne i64 %v211, 0
  br i1 %cond212, label %bb_step_limit, label %bb_step31
bb_step31:
  %v213 = load i64, ptr %slot32, align 8
  %op214 = add i64 %v213, 1
  store i64 %op214, ptr %slot35, align 8
  %v215 = load i64, ptr %slot35, align 8
  %v216 = load i64, ptr %slot1, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !4, !noalias !3
  %v218 = load i64, ptr %slot8, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot36, align 8
  %v221 = load i64, ptr %slot7, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot37, align 8
  %v224 = load i64, ptr %slot37, align 8
  %v225 = load i64, ptr %slot36, align 8
  %ovpair227 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v224, i64 %v225)
  %op226 = extractvalue { i64, i1 } %ovpair227, 0
  %ov228 = extractvalue { i64, i1 } %ovpair227, 1
  store i64 %op226, ptr %slot38, align 8
  %v229 = load i64, ptr %slot37, align 8
  %v230 = load i64, ptr %slot38, align 8
  %op231 = xor i64 %v229, %v230
  store i64 %op231, ptr %slot39, align 8
  %v232 = load i64, ptr %slot36, align 8
  %v233 = load i64, ptr %slot38, align 8
  %op234 = xor i64 %v232, %v233
  store i64 %op234, ptr %slot40, align 8
  %v235 = load i64, ptr %slot39, align 8
  %v236 = load i64, ptr %slot40, align 8
  %op237 = and i64 %v235, %v236
  store i64 %op237, ptr %slot41, align 8
  %cv238 = zext i1 %ov228 to i64
  store i64 %cv238, ptr %slot42, align 8
  %v239 = load i64, ptr %slot42, align 8
  %cond240 = icmp ne i64 %v239, 0
  br i1 %cond240, label %bb_overflow34, label %bb_checked34
bb_overflow34:
  %v241 = load i64, ptr %slot1, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %v243 = load i64, ptr %slot37, align 8
  %v244 = load i64, ptr %slot36, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p242, i64 0, i64 %v243, i64 %v244, i64 64)
  br label %bb_failure
bb_checked34:
  %v245 = load i64, ptr %slot38, align 8
  %v246 = load i64, ptr %slot7, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 %v245, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot20, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 3, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot1, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !4, !noalias !3
  store i64 %ld252, ptr %slot43, align 8
  %v253 = load i64, ptr %slot21, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !4, !noalias !3
  store i64 %ld255, ptr %slot44, align 8
  %v256 = load i64, ptr %slot43, align 8
  %v257 = load i64, ptr %slot44, align 8
  %cmp258 = icmp eq i64 %v256, %v257
  %cv259 = zext i1 %cmp258 to i64
  store i64 %cv259, ptr %slot45, align 8
  %v260 = load i64, ptr %slot45, align 8
  %cond261 = icmp ne i64 %v260, 0
  br i1 %cond261, label %bb_step_limit, label %bb_step42
bb_step42:
  %v262 = load i64, ptr %slot43, align 8
  %op263 = add i64 %v262, 1
  store i64 %op263, ptr %slot46, align 8
  %v264 = load i64, ptr %slot46, align 8
  %v265 = load i64, ptr %slot1, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !4, !noalias !3
  %v267 = load i64, ptr %slot8, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 3, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot20, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 4, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot1, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !4, !noalias !3
  store i64 %ld273, ptr %slot47, align 8
  %v274 = load i64, ptr %slot21, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !4, !noalias !3
  store i64 %ld276, ptr %slot48, align 8
  %v277 = load i64, ptr %slot47, align 8
  %v278 = load i64, ptr %slot48, align 8
  %cmp279 = icmp eq i64 %v277, %v278
  %cv280 = zext i1 %cmp279 to i64
  store i64 %cv280, ptr %slot49, align 8
  %v281 = load i64, ptr %slot49, align 8
  %cond282 = icmp ne i64 %v281, 0
  br i1 %cond282, label %bb_step_limit, label %bb_step46
bb_step46:
  %v283 = load i64, ptr %slot47, align 8
  %op284 = add i64 %v283, 1
  store i64 %op284, ptr %slot50, align 8
  %v285 = load i64, ptr %slot50, align 8
  %v286 = load i64, ptr %slot1, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !4, !noalias !3
  %v288 = load i64, ptr %slot8, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot51, align 8
  %v291 = load i64, ptr %slot7, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot52, align 8
  %v294 = load i64, ptr %slot51, align 8
  %cmp295 = icmp eq i64 %v294, 0
  %cv296 = zext i1 %cmp295 to i64
  store i64 %cv296, ptr %slot53, align 8
  %v297 = load i64, ptr %slot53, align 8
  %cond298 = icmp ne i64 %v297, 0
  br i1 %cond298, label %bb_division49, label %bb_nonzero49
bb_division49:
  %v299 = load i64, ptr %slot1, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %v301 = load i64, ptr %slot52, align 8
  %v302 = load i64, ptr %slot51, align 8
  call void @myl_qbe_fail_division(ptr %p300, i64 6, i64 %v301, i64 %v302)
  br label %bb_failure
bb_nonzero49:
  %v303 = load i64, ptr %slot52, align 8
  %cmp304 = icmp eq i64 %v303, 9223372036854775808
  %cv305 = zext i1 %cmp304 to i64
  store i64 %cv305, ptr %slot54, align 8
  %v306 = load i64, ptr %slot51, align 8
  %cmp307 = icmp eq i64 %v306, 18446744073709551615
  %cv308 = zext i1 %cmp307 to i64
  store i64 %cv308, ptr %slot55, align 8
  %v309 = load i64, ptr %slot54, align 8
  %v310 = load i64, ptr %slot55, align 8
  %op311 = and i64 %v309, %v310
  store i64 %op311, ptr %slot56, align 8
  %v312 = load i64, ptr %slot56, align 8
  %neg313 = sub i64 0, %v312
  store i64 %neg313, ptr %slot57, align 8
  %v314 = load i64, ptr %slot51, align 8
  %op315 = xor i64 %v314, 1
  store i64 %op315, ptr %slot58, align 8
  %v316 = load i64, ptr %slot58, align 8
  %v317 = load i64, ptr %slot57, align 8
  %op318 = and i64 %v316, %v317
  store i64 %op318, ptr %slot58, align 8
  %v319 = load i64, ptr %slot51, align 8
  %v320 = load i64, ptr %slot58, align 8
  %op321 = xor i64 %v319, %v320
  store i64 %op321, ptr %slot59, align 8
  %v322 = load i64, ptr %slot52, align 8
  %v323 = load i64, ptr %slot59, align 8
  %op324 = srem i64 %v322, %v323
  store i64 %op324, ptr %slot60, align 8
  %v325 = load i64, ptr %slot60, align 8
  %cmp326 = icmp ne i64 %v325, 0
  %cv327 = zext i1 %cmp326 to i64
  store i64 %cv327, ptr %slot61, align 8
  %v328 = load i64, ptr %slot60, align 8
  %v329 = load i64, ptr %slot59, align 8
  %op330 = xor i64 %v328, %v329
  store i64 %op330, ptr %slot62, align 8
  %v331 = load i64, ptr %slot62, align 8
  %cmp332 = icmp slt i64 %v331, 0
  %cv333 = zext i1 %cmp332 to i64
  store i64 %cv333, ptr %slot63, align 8
  %v334 = load i64, ptr %slot61, align 8
  %v335 = load i64, ptr %slot63, align 8
  %op336 = and i64 %v334, %v335
  store i64 %op336, ptr %slot64, align 8
  %v337 = load i64, ptr %slot64, align 8
  %neg338 = sub i64 0, %v337
  store i64 %neg338, ptr %slot65, align 8
  %v339 = load i64, ptr %slot59, align 8
  %v340 = load i64, ptr %slot65, align 8
  %op341 = and i64 %v339, %v340
  store i64 %op341, ptr %slot66, align 8
  %v342 = load i64, ptr %slot60, align 8
  %v343 = load i64, ptr %slot66, align 8
  %op344 = add i64 %v342, %v343
  store i64 %op344, ptr %slot60, align 8
  %v345 = load i64, ptr %slot60, align 8
  %v346 = load i64, ptr %slot7, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i64 %v345, ptr %p347, align 8, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot4, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !4, !noalias !3
  store i64 %ld350, ptr %slot67, align 8
  %v351 = load i64, ptr %slot67, align 8
  %cond352 = icmp ne i64 %v351, 0
  br i1 %cond352, label %bb_failure, label %bb_ok63
bb_ok63:
  %v353 = load i64, ptr %slot20, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 5, ptr %p354, align 8, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot1, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !4, !noalias !3
  store i64 %ld357, ptr %slot68, align 8
  %v358 = load i64, ptr %slot21, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !4, !noalias !3
  store i64 %ld360, ptr %slot69, align 8
  %v361 = load i64, ptr %slot68, align 8
  %v362 = load i64, ptr %slot69, align 8
  %cmp363 = icmp eq i64 %v361, %v362
  %cv364 = zext i1 %cmp363 to i64
  store i64 %cv364, ptr %slot70, align 8
  %v365 = load i64, ptr %slot70, align 8
  %cond366 = icmp ne i64 %v365, 0
  br i1 %cond366, label %bb_step_limit, label %bb_step67
bb_step67:
  %v367 = load i64, ptr %slot68, align 8
  %op368 = add i64 %v367, 1
  store i64 %op368, ptr %slot71, align 8
  %v369 = load i64, ptr %slot71, align 8
  %v370 = load i64, ptr %slot1, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !4, !noalias !3
  %v372 = load i64, ptr %slot7, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot72, align 8
  %v375 = load i64, ptr %slot14, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %ld377 = load i64, ptr %p376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld377, ptr %slot73, align 8
  %v378 = load i64, ptr %slot73, align 8
  %v379 = load i64, ptr %slot15, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i64 %v378, ptr %p380, align 8, !alias.scope !4, !noalias !3
  %v381 = load i64, ptr %slot9, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !4, !noalias !3
  store i64 %ld383, ptr %slot74, align 8
  %v384 = load i64, ptr %slot74, align 8
  %op385 = sub i64 %v384, 1
  store i64 %op385, ptr %slot75, align 8
  %v386 = load i64, ptr %slot75, align 8
  %v387 = load i64, ptr %slot9, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i64 %v386, ptr %p388, align 8, !alias.scope !4, !noalias !3
  %v389 = load i64, ptr %slot72, align 8
  ret i64 %v389
bb_step_limit:
  %v390 = load i64, ptr %slot1, align 8
  %p391 = inttoptr i64 %v390 to ptr
  call void @myl_qbe_fail_step(ptr %p391)
  br label %bb_failure
bb_failure:
  %v392 = load i64, ptr %slot14, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot76, align 8
  %v395 = load i64, ptr %slot76, align 8
  %v396 = load i64, ptr %slot15, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !4, !noalias !3
  %v398 = load i64, ptr %slot9, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !4, !noalias !3
  store i64 %ld400, ptr %slot77, align 8
  %v401 = load i64, ptr %slot77, align 8
  %op402 = sub i64 %v401, 1
  store i64 %op402, ptr %slot78, align 8
  %v403 = load i64, ptr %slot78, align 8
  %v404 = load i64, ptr %slot9, align 8
  %p405 = inttoptr i64 %v404 to ptr
  store i64 %v403, ptr %p405, align 8, !alias.scope !4, !noalias !3
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617_meta = external global i8, align 8

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) cold
declare void @myl_qbe_fail_frame(ptr) cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) cold
declare void @myl_qbe_fail_step(ptr) cold

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
