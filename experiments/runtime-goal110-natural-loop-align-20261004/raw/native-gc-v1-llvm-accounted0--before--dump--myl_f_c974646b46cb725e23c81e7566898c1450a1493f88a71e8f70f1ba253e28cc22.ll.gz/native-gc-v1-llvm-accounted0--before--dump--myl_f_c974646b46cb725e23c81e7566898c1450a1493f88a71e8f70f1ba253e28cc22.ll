target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v157 = load i64, ptr %slot1, align 8
  %op158 = add i64 %v157, 32
  store i64 %op158, ptr %slot4, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot5, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot6, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot7, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot8, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot9, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot10, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot11, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot12, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot13, align 8
  %v177 = load i64, ptr %slot2, align 8
  %v178 = load i64, ptr %slot5, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot3, align 8
  %v181 = load i64, ptr %slot6, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v183 = load i64, ptr %slot12, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 0, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot12, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld187, ptr %slot14, align 8
  %v188 = load i64, ptr %slot14, align 8
  %v189 = load i64, ptr %slot7, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot12, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 0, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot12, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot15, align 8
  %v196 = load i64, ptr %slot15, align 8
  %v197 = load i64, ptr %slot8, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot5, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot16, align 8
  %v202 = load i64, ptr %slot16, align 8
  %v203 = load i64, ptr %slot12, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 %v202, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot12, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot17, align 8
  %v208 = load i64, ptr %slot17, align 8
  %v209 = load i64, ptr %slot9, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot8, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot18, align 8
  %v214 = load i64, ptr %slot9, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot19, align 8
  %v217 = load i64, ptr %slot19, align 8
  %v218 = load i64, ptr %slot18, align 8
  %cmp219 = icmp sgt i64 %v217, %v218
  %cv220 = zext i1 %cmp219 to i64
  store i64 %cv220, ptr %slot20, align 8
  %v221 = load i64, ptr %slot19, align 8
  %v222 = load i64, ptr %slot18, align 8
  %op223 = sub i64 %v221, %v222
  store i64 %op223, ptr %slot21, align 8
  %v224 = load i64, ptr %slot21, align 8
  %cmp225 = icmp uge i64 %v224, 16
  %cv226 = zext i1 %cmp225 to i64
  store i64 %cv226, ptr %slot22, align 8
  %v227 = load i64, ptr %slot20, align 8
  %v228 = load i64, ptr %slot22, align 8
  %op229 = and i64 %v227, %v228
  store i64 %op229, ptr %slot23, align 8
  %v230 = load i64, ptr %slot23, align 8
  %cond231 = icmp ne i64 %v230, 0
  br i1 %cond231, label %bb_guard4, label %bb_oi6
bb_guard4:
  %v232 = load i64, ptr %slot18, align 8
  %op233 = add i64 %v232, 1152921504606846976
  store i64 %op233, ptr %slot24, align 8
  %v234 = load i64, ptr %slot24, align 8
  %cmp235 = icmp ule i64 %v234, 2305843009213693952
  %cv236 = zext i1 %cmp235 to i64
  store i64 %cv236, ptr %slot25, align 8
  %v237 = load i64, ptr %slot25, align 8
  %cond238 = icmp ne i64 %v237, 0
  br i1 %cond238, label %bb_guard10, label %bb_oi6
bb_guard10:
  %v239 = load i64, ptr %slot19, align 8
  %op240 = add i64 %v239, 1152921504606846976
  store i64 %op240, ptr %slot26, align 8
  %v241 = load i64, ptr %slot26, align 8
  %cmp242 = icmp ule i64 %v241, 2305843009213693952
  %cv243 = zext i1 %cmp242 to i64
  store i64 %cv243, ptr %slot27, align 8
  %v244 = load i64, ptr %slot27, align 8
  %cond245 = icmp ne i64 %v244, 0
  br i1 %cond245, label %bb_guard12, label %bb_oi6
bb_guard12:
  br label %bb_fi6
bb_fi6:
  %v246 = load i64, ptr %slot8, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot28, align 8
  %v249 = load i64, ptr %slot28, align 8
  %v250 = load i64, ptr %slot12, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i64 %v249, ptr %p251, align 8, !alias.scope !3, !noalias !4
  %v252 = load i64, ptr %slot9, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot29, align 8
  %v255 = load i64, ptr %slot29, align 8
  %v256 = load i64, ptr %slot13, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 %v255, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot13, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot30, align 8
  %v261 = load i64, ptr %slot12, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot31, align 8
  %v264 = load i64, ptr %slot31, align 8
  %v265 = load i64, ptr %slot30, align 8
  %cmp266 = icmp slt i64 %v264, %v265
  %cv267 = zext i1 %cmp266 to i64
  store i64 %cv267, ptr %slot32, align 8
  %v268 = load i64, ptr %slot32, align 8
  %v269 = load i64, ptr %slot12, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot12, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot33, align 8
  %v274 = load i64, ptr %slot33, align 8
  %cond275 = icmp ne i64 %v274, 0
  br i1 %cond275, label %bb_next20, label %bb_i34
bb_next20:
  %v276 = load i64, ptr %slot8, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot34, align 8
  %v279 = load i64, ptr %slot34, align 8
  %v280 = load i64, ptr %slot12, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot13, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 2, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot13, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot35, align 8
  %v287 = load i64, ptr %slot12, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot36, align 8
  %v290 = load i64, ptr %slot35, align 8
  %cmp291 = icmp eq i64 %v290, 0
  %cv292 = zext i1 %cmp291 to i64
  store i64 %cv292, ptr %slot37, align 8
  %v293 = load i64, ptr %slot37, align 8
  %cond294 = icmp ne i64 %v293, 0
  br i1 %cond294, label %bb_division23, label %bb_nonzero23
bb_division23:
  %v295 = load i64, ptr %slot1, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %v297 = load i64, ptr %slot36, align 8
  %v298 = load i64, ptr %slot35, align 8
  call void @myl_qbe_fail_division(ptr %p296, i64 6, i64 %v297, i64 %v298) nomerge, !dbg !110
  unreachable
bb_nonzero23:
  %v299 = load i64, ptr %slot36, align 8
  %cmp300 = icmp eq i64 %v299, 9223372036854775808
  %cv301 = zext i1 %cmp300 to i64
  store i64 %cv301, ptr %slot38, align 8
  %v302 = load i64, ptr %slot35, align 8
  %cmp303 = icmp eq i64 %v302, 18446744073709551615
  %cv304 = zext i1 %cmp303 to i64
  store i64 %cv304, ptr %slot39, align 8
  %v305 = load i64, ptr %slot38, align 8
  %v306 = load i64, ptr %slot39, align 8
  %op307 = and i64 %v305, %v306
  store i64 %op307, ptr %slot40, align 8
  %v308 = load i64, ptr %slot40, align 8
  %neg309 = sub i64 0, %v308
  store i64 %neg309, ptr %slot41, align 8
  %v310 = load i64, ptr %slot35, align 8
  %op311 = xor i64 %v310, 1
  store i64 %op311, ptr %slot42, align 8
  %v312 = load i64, ptr %slot42, align 8
  %v313 = load i64, ptr %slot41, align 8
  %op314 = and i64 %v312, %v313
  store i64 %op314, ptr %slot42, align 8
  %v315 = load i64, ptr %slot35, align 8
  %v316 = load i64, ptr %slot42, align 8
  %op317 = xor i64 %v315, %v316
  store i64 %op317, ptr %slot43, align 8
  %v318 = load i64, ptr %slot36, align 8
  %v319 = load i64, ptr %slot43, align 8
  %op320 = srem i64 %v318, %v319
  store i64 %op320, ptr %slot44, align 8
  %v321 = load i64, ptr %slot44, align 8
  %cmp322 = icmp ne i64 %v321, 0
  %cv323 = zext i1 %cmp322 to i64
  store i64 %cv323, ptr %slot45, align 8
  %v324 = load i64, ptr %slot44, align 8
  %v325 = load i64, ptr %slot43, align 8
  %op326 = xor i64 %v324, %v325
  store i64 %op326, ptr %slot46, align 8
  %v327 = load i64, ptr %slot46, align 8
  %cmp328 = icmp slt i64 %v327, 0
  %cv329 = zext i1 %cmp328 to i64
  store i64 %cv329, ptr %slot47, align 8
  %v330 = load i64, ptr %slot45, align 8
  %v331 = load i64, ptr %slot47, align 8
  %op332 = and i64 %v330, %v331
  store i64 %op332, ptr %slot48, align 8
  %v333 = load i64, ptr %slot48, align 8
  %neg334 = sub i64 0, %v333
  store i64 %neg334, ptr %slot49, align 8
  %v335 = load i64, ptr %slot43, align 8
  %v336 = load i64, ptr %slot49, align 8
  %op337 = and i64 %v335, %v336
  store i64 %op337, ptr %slot50, align 8
  %v338 = load i64, ptr %slot44, align 8
  %v339 = load i64, ptr %slot50, align 8
  %op340 = add i64 %v338, %v339
  store i64 %op340, ptr %slot44, align 8
  %v341 = load i64, ptr %slot44, align 8
  %v342 = load i64, ptr %slot12, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot6, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i64, ptr %p345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot51, align 8
  %v347 = load i64, ptr %slot51, align 8
  %v348 = load i64, ptr %slot13, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot13, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot52, align 8
  %v353 = load i64, ptr %slot12, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot53, align 8
  %v356 = load i64, ptr %slot53, align 8
  %v357 = load i64, ptr %slot52, align 8
  %cmp358 = icmp eq i64 %v356, %v357
  %cv359 = zext i1 %cmp358 to i64
  store i64 %cv359, ptr %slot54, align 8
  %v360 = load i64, ptr %slot54, align 8
  %v361 = load i64, ptr %slot12, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 %v360, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot12, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot55, align 8
  %v366 = load i64, ptr %slot55, align 8
  %cond367 = icmp ne i64 %v366, 0
  br i1 %cond367, label %bb_next42, label %bb_fi19
bb_next42:
  %v368 = load i64, ptr %slot12, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 1, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot56, align 8
  %v373 = load i64, ptr %slot56, align 8
  %v374 = load i64, ptr %slot10, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 %v373, ptr %p375, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v376 = load i64, ptr %slot12, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 0, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot12, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot57, align 8
  %v381 = load i64, ptr %slot57, align 8
  %v382 = load i64, ptr %slot10, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 %v381, ptr %p383, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v384 = load i64, ptr %slot10, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot58, align 8
  %v387 = load i64, ptr %slot58, align 8
  %v388 = load i64, ptr %slot12, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot12, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot59, align 8
  %v393 = load i64, ptr %slot59, align 8
  %v394 = load i64, ptr %slot11, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot7, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot60, align 8
  %v399 = load i64, ptr %slot60, align 8
  %v400 = load i64, ptr %slot12, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot11, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot61, align 8
  %v405 = load i64, ptr %slot61, align 8
  %v406 = load i64, ptr %slot13, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot13, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot62, align 8
  %v411 = load i64, ptr %slot12, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot63, align 8
  %v414 = load i64, ptr %slot63, align 8
  %v415 = load i64, ptr %slot62, align 8
  %ovpair417 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v414, i64 %v415)
  %op416 = extractvalue { i64, i1 } %ovpair417, 0
  %ov418 = extractvalue { i64, i1 } %ovpair417, 1
  store i64 %op416, ptr %slot64, align 8
  %v419 = load i64, ptr %slot63, align 8
  %v420 = load i64, ptr %slot64, align 8
  %op421 = xor i64 %v419, %v420
  store i64 %op421, ptr %slot65, align 8
  %v422 = load i64, ptr %slot62, align 8
  %v423 = load i64, ptr %slot64, align 8
  %op424 = xor i64 %v422, %v423
  store i64 %op424, ptr %slot66, align 8
  %v425 = load i64, ptr %slot65, align 8
  %v426 = load i64, ptr %slot66, align 8
  %op427 = and i64 %v425, %v426
  store i64 %op427, ptr %slot67, align 8
  %cv428 = zext i1 %ov418 to i64
  store i64 %cv428, ptr %slot68, align 8
  %v429 = load i64, ptr %slot68, align 8
  %cond430 = icmp ne i64 %v429, 0
  br i1 %cond430, label %bb_overflow50, label %bb_checked50
bb_overflow50:
  %v431 = load i64, ptr %slot1, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %v433 = load i64, ptr %slot63, align 8
  %v434 = load i64, ptr %slot62, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p432, i64 0, i64 %v433, i64 %v434, i64 64) nomerge, !dbg !112
  unreachable
bb_checked50:
  %v435 = load i64, ptr %slot64, align 8
  %v436 = load i64, ptr %slot12, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i64 %v435, ptr %p437, align 8, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot13, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 1000000007, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot13, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i64, ptr %p441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld442, ptr %slot69, align 8
  %v443 = load i64, ptr %slot12, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot70, align 8
  %v446 = load i64, ptr %slot69, align 8
  %cmp447 = icmp eq i64 %v446, 0
  %cv448 = zext i1 %cmp447 to i64
  store i64 %cv448, ptr %slot71, align 8
  %v449 = load i64, ptr %slot71, align 8
  %cond450 = icmp ne i64 %v449, 0
  br i1 %cond450, label %bb_division57, label %bb_nonzero57
bb_division57:
  %v451 = load i64, ptr %slot1, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %v453 = load i64, ptr %slot70, align 8
  %v454 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_division(ptr %p452, i64 6, i64 %v453, i64 %v454) nomerge, !dbg !114
  unreachable
bb_nonzero57:
  %v455 = load i64, ptr %slot70, align 8
  %cmp456 = icmp eq i64 %v455, 9223372036854775808
  %cv457 = zext i1 %cmp456 to i64
  store i64 %cv457, ptr %slot72, align 8
  %v458 = load i64, ptr %slot69, align 8
  %cmp459 = icmp eq i64 %v458, 18446744073709551615
  %cv460 = zext i1 %cmp459 to i64
  store i64 %cv460, ptr %slot73, align 8
  %v461 = load i64, ptr %slot72, align 8
  %v462 = load i64, ptr %slot73, align 8
  %op463 = and i64 %v461, %v462
  store i64 %op463, ptr %slot74, align 8
  %v464 = load i64, ptr %slot74, align 8
  %neg465 = sub i64 0, %v464
  store i64 %neg465, ptr %slot75, align 8
  %v466 = load i64, ptr %slot69, align 8
  %op467 = xor i64 %v466, 1
  store i64 %op467, ptr %slot76, align 8
  %v468 = load i64, ptr %slot76, align 8
  %v469 = load i64, ptr %slot75, align 8
  %op470 = and i64 %v468, %v469
  store i64 %op470, ptr %slot76, align 8
  %v471 = load i64, ptr %slot69, align 8
  %v472 = load i64, ptr %slot76, align 8
  %op473 = xor i64 %v471, %v472
  store i64 %op473, ptr %slot77, align 8
  %v474 = load i64, ptr %slot70, align 8
  %v475 = load i64, ptr %slot77, align 8
  %op476 = srem i64 %v474, %v475
  store i64 %op476, ptr %slot78, align 8
  %v477 = load i64, ptr %slot78, align 8
  %cmp478 = icmp ne i64 %v477, 0
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot79, align 8
  %v480 = load i64, ptr %slot78, align 8
  %v481 = load i64, ptr %slot77, align 8
  %op482 = xor i64 %v480, %v481
  store i64 %op482, ptr %slot80, align 8
  %v483 = load i64, ptr %slot80, align 8
  %cmp484 = icmp slt i64 %v483, 0
  %cv485 = zext i1 %cmp484 to i64
  store i64 %cv485, ptr %slot81, align 8
  %v486 = load i64, ptr %slot79, align 8
  %v487 = load i64, ptr %slot81, align 8
  %op488 = and i64 %v486, %v487
  store i64 %op488, ptr %slot82, align 8
  %v489 = load i64, ptr %slot82, align 8
  %neg490 = sub i64 0, %v489
  store i64 %neg490, ptr %slot83, align 8
  %v491 = load i64, ptr %slot77, align 8
  %v492 = load i64, ptr %slot83, align 8
  %op493 = and i64 %v491, %v492
  store i64 %op493, ptr %slot84, align 8
  %v494 = load i64, ptr %slot78, align 8
  %v495 = load i64, ptr %slot84, align 8
  %op496 = add i64 %v494, %v495
  store i64 %op496, ptr %slot78, align 8
  %v497 = load i64, ptr %slot78, align 8
  %v498 = load i64, ptr %slot12, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot12, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot85, align 8
  %v503 = load i64, ptr %slot85, align 8
  %v504 = load i64, ptr %slot7, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i64 %v503, ptr %p505, align 8, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot8, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %ld508 = load i64, ptr %p507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld508, ptr %slot86, align 8
  %v509 = load i64, ptr %slot86, align 8
  %v510 = load i64, ptr %slot12, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i64 %v509, ptr %p511, align 8, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot13, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 1, ptr %p513, align 8, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot13, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ld516 = load i64, ptr %p515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld516, ptr %slot87, align 8
  %v517 = load i64, ptr %slot12, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i64, ptr %p518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld519, ptr %slot88, align 8
  %v520 = load i64, ptr %slot88, align 8
  %v521 = load i64, ptr %slot87, align 8
  %op522 = add i64 %v520, %v521
  store i64 %op522, ptr %slot89, align 8
  %v523 = load i64, ptr %slot89, align 8
  %v524 = load i64, ptr %slot12, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot12, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot90, align 8
  %v529 = load i64, ptr %slot90, align 8
  %v530 = load i64, ptr %slot8, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v532 = load i64, ptr %slot8, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot91, align 8
  %v535 = load i64, ptr %slot91, align 8
  %v536 = load i64, ptr %slot12, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 %v535, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot9, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot92, align 8
  %v541 = load i64, ptr %slot92, align 8
  %v542 = load i64, ptr %slot13, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot13, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot93, align 8
  %v547 = load i64, ptr %slot12, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld549, ptr %slot94, align 8
  %v550 = load i64, ptr %slot94, align 8
  %v551 = load i64, ptr %slot93, align 8
  %cmp552 = icmp slt i64 %v550, %v551
  %cv553 = zext i1 %cmp552 to i64
  store i64 %cv553, ptr %slot95, align 8
  %v554 = load i64, ptr %slot95, align 8
  %v555 = load i64, ptr %slot12, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot12, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot96, align 8
  %v560 = load i64, ptr %slot96, align 8
  %cond561 = icmp ne i64 %v560, 0
  br i1 %cond561, label %bb_next83, label %bb_i34
bb_next83:
  %v562 = load i64, ptr %slot8, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %ld564 = load i64, ptr %p563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot97, align 8
  %v565 = load i64, ptr %slot97, align 8
  %v566 = load i64, ptr %slot12, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 %v565, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot13, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i64 2, ptr %p569, align 8, !alias.scope !3, !noalias !4
  %v570 = load i64, ptr %slot13, align 8
  %p571 = inttoptr i64 %v570 to ptr
  %ld572 = load i64, ptr %p571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld572, ptr %slot98, align 8
  %v573 = load i64, ptr %slot12, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i64, ptr %p574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld575, ptr %slot99, align 8
  %v576 = load i64, ptr %slot98, align 8
  %cmp577 = icmp eq i64 %v576, 0
  %cv578 = zext i1 %cmp577 to i64
  store i64 %cv578, ptr %slot100, align 8
  %v579 = load i64, ptr %slot100, align 8
  %cond580 = icmp ne i64 %v579, 0
  br i1 %cond580, label %bb_division86, label %bb_nonzero86
bb_division86:
  %v581 = load i64, ptr %slot1, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %v583 = load i64, ptr %slot99, align 8
  %v584 = load i64, ptr %slot98, align 8
  call void @myl_qbe_fail_division(ptr %p582, i64 6, i64 %v583, i64 %v584) nomerge, !dbg !110
  unreachable
bb_nonzero86:
  %v585 = load i64, ptr %slot99, align 8
  %cmp586 = icmp eq i64 %v585, 9223372036854775808
  %cv587 = zext i1 %cmp586 to i64
  store i64 %cv587, ptr %slot101, align 8
  %v588 = load i64, ptr %slot98, align 8
  %cmp589 = icmp eq i64 %v588, 18446744073709551615
  %cv590 = zext i1 %cmp589 to i64
  store i64 %cv590, ptr %slot102, align 8
  %v591 = load i64, ptr %slot101, align 8
  %v592 = load i64, ptr %slot102, align 8
  %op593 = and i64 %v591, %v592
  store i64 %op593, ptr %slot103, align 8
  %v594 = load i64, ptr %slot103, align 8
  %neg595 = sub i64 0, %v594
  store i64 %neg595, ptr %slot104, align 8
  %v596 = load i64, ptr %slot98, align 8
  %op597 = xor i64 %v596, 1
  store i64 %op597, ptr %slot105, align 8
  %v598 = load i64, ptr %slot105, align 8
  %v599 = load i64, ptr %slot104, align 8
  %op600 = and i64 %v598, %v599
  store i64 %op600, ptr %slot105, align 8
  %v601 = load i64, ptr %slot98, align 8
  %v602 = load i64, ptr %slot105, align 8
  %op603 = xor i64 %v601, %v602
  store i64 %op603, ptr %slot106, align 8
  %v604 = load i64, ptr %slot99, align 8
  %v605 = load i64, ptr %slot106, align 8
  %op606 = srem i64 %v604, %v605
  store i64 %op606, ptr %slot107, align 8
  %v607 = load i64, ptr %slot107, align 8
  %cmp608 = icmp ne i64 %v607, 0
  %cv609 = zext i1 %cmp608 to i64
  store i64 %cv609, ptr %slot108, align 8
  %v610 = load i64, ptr %slot107, align 8
  %v611 = load i64, ptr %slot106, align 8
  %op612 = xor i64 %v610, %v611
  store i64 %op612, ptr %slot109, align 8
  %v613 = load i64, ptr %slot109, align 8
  %cmp614 = icmp slt i64 %v613, 0
  %cv615 = zext i1 %cmp614 to i64
  store i64 %cv615, ptr %slot110, align 8
  %v616 = load i64, ptr %slot108, align 8
  %v617 = load i64, ptr %slot110, align 8
  %op618 = and i64 %v616, %v617
  store i64 %op618, ptr %slot111, align 8
  %v619 = load i64, ptr %slot111, align 8
  %neg620 = sub i64 0, %v619
  store i64 %neg620, ptr %slot112, align 8
  %v621 = load i64, ptr %slot106, align 8
  %v622 = load i64, ptr %slot112, align 8
  %op623 = and i64 %v621, %v622
  store i64 %op623, ptr %slot113, align 8
  %v624 = load i64, ptr %slot107, align 8
  %v625 = load i64, ptr %slot113, align 8
  %op626 = add i64 %v624, %v625
  store i64 %op626, ptr %slot107, align 8
  %v627 = load i64, ptr %slot107, align 8
  %v628 = load i64, ptr %slot12, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot6, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot114, align 8
  %v633 = load i64, ptr %slot114, align 8
  %v634 = load i64, ptr %slot13, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i64 %v633, ptr %p635, align 8, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot13, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot115, align 8
  %v639 = load i64, ptr %slot12, align 8
  %p640 = inttoptr i64 %v639 to ptr
  %ld641 = load i64, ptr %p640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld641, ptr %slot116, align 8
  %v642 = load i64, ptr %slot116, align 8
  %v643 = load i64, ptr %slot115, align 8
  %cmp644 = icmp eq i64 %v642, %v643
  %cv645 = zext i1 %cmp644 to i64
  store i64 %cv645, ptr %slot117, align 8
  %v646 = load i64, ptr %slot117, align 8
  %v647 = load i64, ptr %slot12, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i64 %v646, ptr %p648, align 8, !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot12, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %ld651 = load i64, ptr %p650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld651, ptr %slot118, align 8
  %v652 = load i64, ptr %slot118, align 8
  %cond653 = icmp ne i64 %v652, 0
  br i1 %cond653, label %bb_next105, label %bb_i19
bb_next105:
  %v654 = load i64, ptr %slot12, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 1, ptr %p655, align 8, !alias.scope !3, !noalias !4
  %v656 = load i64, ptr %slot12, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %ld658 = load i64, ptr %p657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld658, ptr %slot119, align 8
  %v659 = load i64, ptr %slot119, align 8
  %v660 = load i64, ptr %slot10, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i64 %v659, ptr %p661, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v662 = load i64, ptr %slot12, align 8
  %p663 = inttoptr i64 %v662 to ptr
  store i64 0, ptr %p663, align 8, !alias.scope !3, !noalias !4
  %v664 = load i64, ptr %slot12, align 8
  %p665 = inttoptr i64 %v664 to ptr
  %ld666 = load i64, ptr %p665, align 8, !alias.scope !3, !noalias !4
  store i64 %ld666, ptr %slot120, align 8
  %v667 = load i64, ptr %slot120, align 8
  %v668 = load i64, ptr %slot10, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 %v667, ptr %p669, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v670 = load i64, ptr %slot10, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot121, align 8
  %v673 = load i64, ptr %slot121, align 8
  %v674 = load i64, ptr %slot12, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot12, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot122, align 8
  %v679 = load i64, ptr %slot122, align 8
  %v680 = load i64, ptr %slot11, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot7, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot123, align 8
  %v685 = load i64, ptr %slot123, align 8
  %v686 = load i64, ptr %slot12, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot11, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot124, align 8
  %v691 = load i64, ptr %slot124, align 8
  %v692 = load i64, ptr %slot13, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot13, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot125, align 8
  %v697 = load i64, ptr %slot12, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot126, align 8
  %v700 = load i64, ptr %slot126, align 8
  %v701 = load i64, ptr %slot125, align 8
  %ovpair703 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v700, i64 %v701)
  %op702 = extractvalue { i64, i1 } %ovpair703, 0
  %ov704 = extractvalue { i64, i1 } %ovpair703, 1
  store i64 %op702, ptr %slot127, align 8
  %v705 = load i64, ptr %slot126, align 8
  %v706 = load i64, ptr %slot127, align 8
  %op707 = xor i64 %v705, %v706
  store i64 %op707, ptr %slot128, align 8
  %v708 = load i64, ptr %slot125, align 8
  %v709 = load i64, ptr %slot127, align 8
  %op710 = xor i64 %v708, %v709
  store i64 %op710, ptr %slot129, align 8
  %v711 = load i64, ptr %slot128, align 8
  %v712 = load i64, ptr %slot129, align 8
  %op713 = and i64 %v711, %v712
  store i64 %op713, ptr %slot130, align 8
  %cv714 = zext i1 %ov704 to i64
  store i64 %cv714, ptr %slot131, align 8
  %v715 = load i64, ptr %slot131, align 8
  %cond716 = icmp ne i64 %v715, 0
  br i1 %cond716, label %bb_overflow113, label %bb_checked113
bb_overflow113:
  %v717 = load i64, ptr %slot1, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %v719 = load i64, ptr %slot126, align 8
  %v720 = load i64, ptr %slot125, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p718, i64 0, i64 %v719, i64 %v720, i64 64) nomerge, !dbg !112
  unreachable
bb_checked113:
  %v721 = load i64, ptr %slot127, align 8
  %v722 = load i64, ptr %slot12, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 %v721, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot13, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i64 1000000007, ptr %p725, align 8, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot13, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %ld728 = load i64, ptr %p727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld728, ptr %slot132, align 8
  %v729 = load i64, ptr %slot12, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i64, ptr %p730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld731, ptr %slot133, align 8
  %v732 = load i64, ptr %slot132, align 8
  %cmp733 = icmp eq i64 %v732, 0
  %cv734 = zext i1 %cmp733 to i64
  store i64 %cv734, ptr %slot134, align 8
  %v735 = load i64, ptr %slot134, align 8
  %cond736 = icmp ne i64 %v735, 0
  br i1 %cond736, label %bb_division120, label %bb_nonzero120
bb_division120:
  %v737 = load i64, ptr %slot1, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %v739 = load i64, ptr %slot133, align 8
  %v740 = load i64, ptr %slot132, align 8
  call void @myl_qbe_fail_division(ptr %p738, i64 6, i64 %v739, i64 %v740) nomerge, !dbg !114
  unreachable
bb_nonzero120:
  %v741 = load i64, ptr %slot133, align 8
  %cmp742 = icmp eq i64 %v741, 9223372036854775808
  %cv743 = zext i1 %cmp742 to i64
  store i64 %cv743, ptr %slot135, align 8
  %v744 = load i64, ptr %slot132, align 8
  %cmp745 = icmp eq i64 %v744, 18446744073709551615
  %cv746 = zext i1 %cmp745 to i64
  store i64 %cv746, ptr %slot136, align 8
  %v747 = load i64, ptr %slot135, align 8
  %v748 = load i64, ptr %slot136, align 8
  %op749 = and i64 %v747, %v748
  store i64 %op749, ptr %slot137, align 8
  %v750 = load i64, ptr %slot137, align 8
  %neg751 = sub i64 0, %v750
  store i64 %neg751, ptr %slot138, align 8
  %v752 = load i64, ptr %slot132, align 8
  %op753 = xor i64 %v752, 1
  store i64 %op753, ptr %slot139, align 8
  %v754 = load i64, ptr %slot139, align 8
  %v755 = load i64, ptr %slot138, align 8
  %op756 = and i64 %v754, %v755
  store i64 %op756, ptr %slot139, align 8
  %v757 = load i64, ptr %slot132, align 8
  %v758 = load i64, ptr %slot139, align 8
  %op759 = xor i64 %v757, %v758
  store i64 %op759, ptr %slot140, align 8
  %v760 = load i64, ptr %slot133, align 8
  %v761 = load i64, ptr %slot140, align 8
  %op762 = srem i64 %v760, %v761
  store i64 %op762, ptr %slot141, align 8
  %v763 = load i64, ptr %slot141, align 8
  %cmp764 = icmp ne i64 %v763, 0
  %cv765 = zext i1 %cmp764 to i64
  store i64 %cv765, ptr %slot142, align 8
  %v766 = load i64, ptr %slot141, align 8
  %v767 = load i64, ptr %slot140, align 8
  %op768 = xor i64 %v766, %v767
  store i64 %op768, ptr %slot143, align 8
  %v769 = load i64, ptr %slot143, align 8
  %cmp770 = icmp slt i64 %v769, 0
  %cv771 = zext i1 %cmp770 to i64
  store i64 %cv771, ptr %slot144, align 8
  %v772 = load i64, ptr %slot142, align 8
  %v773 = load i64, ptr %slot144, align 8
  %op774 = and i64 %v772, %v773
  store i64 %op774, ptr %slot145, align 8
  %v775 = load i64, ptr %slot145, align 8
  %neg776 = sub i64 0, %v775
  store i64 %neg776, ptr %slot146, align 8
  %v777 = load i64, ptr %slot140, align 8
  %v778 = load i64, ptr %slot146, align 8
  %op779 = and i64 %v777, %v778
  store i64 %op779, ptr %slot147, align 8
  %v780 = load i64, ptr %slot141, align 8
  %v781 = load i64, ptr %slot147, align 8
  %op782 = add i64 %v780, %v781
  store i64 %op782, ptr %slot141, align 8
  %v783 = load i64, ptr %slot141, align 8
  %v784 = load i64, ptr %slot12, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i64 %v783, ptr %p785, align 8, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot12, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i64, ptr %p787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld788, ptr %slot148, align 8
  %v789 = load i64, ptr %slot148, align 8
  %v790 = load i64, ptr %slot7, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i64 %v789, ptr %p791, align 8, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot8, align 8
  %p793 = inttoptr i64 %v792 to ptr
  %ld794 = load i64, ptr %p793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld794, ptr %slot149, align 8
  %v795 = load i64, ptr %slot149, align 8
  %v796 = load i64, ptr %slot12, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i64 %v795, ptr %p797, align 8, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot13, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 1, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot13, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot150, align 8
  %v803 = load i64, ptr %slot12, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i64, ptr %p804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld805, ptr %slot151, align 8
  %v806 = load i64, ptr %slot151, align 8
  %v807 = load i64, ptr %slot150, align 8
  %op808 = add i64 %v806, %v807
  %ovpair809 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v806, i64 %v807)
  %ov810 = extractvalue { i64, i1 } %ovpair809, 1
  store i64 %op808, ptr %slot152, align 8
  %cv811 = zext i1 %ov810 to i64
  store i64 %cv811, ptr %slot153, align 8
  %v812 = load i64, ptr %slot153, align 8
  %cond813 = icmp ne i64 %v812, 0
  br i1 %cond813, label %bb_overflow138, label %bb_checked138
bb_overflow138:
  %v814 = load i64, ptr %slot1, align 8
  %p815 = inttoptr i64 %v814 to ptr
  %v816 = load i64, ptr %slot151, align 8
  %v817 = load i64, ptr %slot150, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p815, i64 0, i64 %v816, i64 %v817, i64 64) nomerge, !dbg !116
  unreachable
bb_checked138:
  %v818 = load i64, ptr %slot152, align 8
  %v819 = load i64, ptr %slot12, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i64 %v818, ptr %p820, align 8, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot12, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld823, ptr %slot154, align 8
  %v824 = load i64, ptr %slot154, align 8
  %v825 = load i64, ptr %slot8, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i64 %v824, ptr %p826, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i34:
  %v827 = load i64, ptr %slot7, align 8
  %p828 = inttoptr i64 %v827 to ptr
  %ld829 = load i64, ptr %p828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld829, ptr %slot155, align 8
  %v830 = load i64, ptr %slot155, align 8
  %v831 = load i64, ptr %slot12, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 %v830, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot12, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld835, ptr %slot156, align 8
  %v836 = load i64, ptr %slot156, align 8
  ret i64 %v836
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", linkageName: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7472279511045523184, i64 0, !"myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
