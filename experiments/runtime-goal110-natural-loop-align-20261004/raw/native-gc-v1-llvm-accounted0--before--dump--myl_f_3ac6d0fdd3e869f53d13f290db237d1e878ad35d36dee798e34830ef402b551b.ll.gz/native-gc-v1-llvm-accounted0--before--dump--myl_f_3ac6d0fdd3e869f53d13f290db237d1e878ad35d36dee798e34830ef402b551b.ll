target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i32, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v30 = load i64, ptr %slot1, align 8
  %op31 = add i64 %v30, 32
  store i64 %op31, ptr %slot3, align 8
  %mem32 = alloca i8, i64 16, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot4, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot5, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot6, align 8
  %mem38 = alloca i8, i64 8, align 8
  %ptr39 = ptrtoint ptr %mem38 to i64
  store i64 %ptr39, ptr %slot7, align 8
  %mem40 = alloca i8, i64 8, align 8
  %ptr41 = ptrtoint ptr %mem40 to i64
  store i64 %ptr41, ptr %slot8, align 8
  %mem42 = alloca i8, i64 16, align 8
  %ptr43 = ptrtoint ptr %mem42 to i64
  store i64 %ptr43, ptr %slot9, align 8
  %v44 = load i64, ptr %slot6, align 8
  %p45 = inttoptr i64 %v44 to ptr
  store i64 0, ptr %p45, align 8, !alias.scope !3, !noalias !4
  %v46 = load i64, ptr %slot2, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v49 = load i64, ptr %slot5, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot10, align 8
  %v52 = load i64, ptr %slot10, align 8
  %v53 = load i64, ptr %slot8, align 8
  %p54 = inttoptr i64 %v53 to ptr
  store i64 %v52, ptr %p54, align 8, !alias.scope !3, !noalias !4
  %v55 = load i64, ptr %slot8, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %ld57 = load i64, ptr %p56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld57, ptr %slot11, align 8
  %v58 = load i64, ptr %slot11, align 8
  %v59 = load i64, ptr %slot6, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 %v58, ptr %p60, align 8, !alias.scope !3, !noalias !4
  %v61 = load i64, ptr %slot6, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot12, align 8
  %v64 = load i64, ptr %slot6, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i64, ptr %p65, align 8, !alias.scope !3, !noalias !4
  store i64 %ld66, ptr %slot13, align 8
  %v67 = load i64, ptr %slot13, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %call69 = call ptr @myl_native_text_payload(ptr %p68) nomerge, !dbg !110
  %calladdr70 = ptrtoint ptr %call69 to i64
  store i64 %calladdr70, ptr %slot14, align 8
  %v71 = load i64, ptr %slot13, align 8
  %op72 = add i64 %v71, 8
  store i64 %op72, ptr %slot15, align 8
  %v73 = load i64, ptr %slot15, align 8
  %p74 = inttoptr i64 %v73 to ptr
  %ld75 = load i64, ptr %p74, align 8, !alias.scope !4, !noalias !3
  store i64 %ld75, ptr %slot16, align 8
  %v76 = load i64, ptr %slot14, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %v78 = load i64, ptr %slot16, align 8
  %v79 = load i64, ptr %slot4, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %call81 = call i32 @myl_native_bytes_number_parse(ptr %p77, i64 %v78, i32 0, ptr %p80) nomerge, !dbg !110
  store i32 %call81, ptr %slot17, align 8
  %v82 = load i64, ptr %slot4, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot18, align 8
  %v85 = load i64, ptr %slot9, align 8
  store i64 %v85, ptr %slot19, align 8
  %v86 = load i64, ptr %slot19, align 8
  %p88 = inttoptr i64 %v86 to ptr
  %gep89 = getelementptr i8, ptr %p88, i64 8
  %op87 = ptrtoint ptr %gep89 to i64
  store i64 %op87, ptr %slot20, align 8
  %v90 = load i32, ptr %slot17, align 8
  %cv91 = zext i32 %v90 to i64
  %cond92 = icmp ne i64 %cv91, 0
  br i1 %cond92, label %bb_some12, label %bb_none12
bb_some12:
  %v93 = load i64, ptr %slot19, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i32 1, ptr %p94, align 4, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot18, align 8
  %v96 = load i64, ptr %slot20, align 8
  %p97 = inttoptr i64 %v96 to ptr
  store i64 %v95, ptr %p97, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed12
bb_none12:
  %v98 = load i64, ptr %slot19, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i32 0, ptr %p99, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed12
bb_parsed12:
  %v100 = load i64, ptr %slot19, align 8
  %v101 = load i64, ptr %slot8, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 %v100, ptr %p102, align 8, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot8, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld105, ptr %slot21, align 8
  %v106 = load i64, ptr %slot21, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i32, ptr %p107, align 4, !alias.scope !3, !noalias !4
  %ext109 = zext i32 %ld108 to i64
  store i64 %ext109, ptr %slot22, align 8
  %v110 = load i64, ptr %slot22, align 8
  %cmp111 = icmp eq i64 %v110, 0
  %cv112 = zext i1 %cmp111 to i64
  store i64 %cv112, ptr %slot23, align 8
  %v113 = load i64, ptr %slot23, align 8
  %cond114 = icmp ne i64 %v113, 0
  br i1 %cond114, label %bb_arm15, label %bb_armnext15
bb_arm15:
  br label %bb_i6
bb_armnext15:
  %v115 = load i64, ptr %slot22, align 8
  %cmp116 = icmp eq i64 %v115, 1
  %cv117 = zext i1 %cmp116 to i64
  store i64 %cv117, ptr %slot24, align 8
  %v118 = load i64, ptr %slot24, align 8
  %cond119 = icmp ne i64 %v118, 0
  br i1 %cond119, label %bb_arm16, label %bb_armnext16
bb_arm16:
  %v120 = load i64, ptr %slot21, align 8
  %op121 = add i64 %v120, 8
  store i64 %op121, ptr %slot25, align 8
  %v122 = load i64, ptr %slot25, align 8
  %p123 = inttoptr i64 %v122 to ptr
  %ld124 = load i64, ptr %p123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot26, align 8
  %v125 = load i64, ptr %slot26, align 8
  %v126 = load i64, ptr %slot7, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 %v125, ptr %p127, align 8, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_armnext16:
  br label %bb_failure
bb_i4:
  %v128 = load i64, ptr %slot7, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot27, align 8
  %v131 = load i64, ptr %slot27, align 8
  %v132 = load i64, ptr %slot8, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot8, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot28, align 8
  %v137 = load i64, ptr %slot28, align 8
  ret i64 %v137
bb_i6:
  %v138 = load i64, ptr %slot8, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 0, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot8, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot29, align 8
  %v143 = load i64, ptr %slot29, align 8
  ret i64 %v143
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", linkageName: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10980889420309157548, i64 0, !"myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
