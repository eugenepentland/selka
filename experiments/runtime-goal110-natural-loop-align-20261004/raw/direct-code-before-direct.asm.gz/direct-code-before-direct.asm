0x102cf04: mov    %r15,%rdx
0x102cf07: add    %r11,%rdx
0x102cf0a: jo     102e574 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4984>
0x102cf10: imul   $0x3,%rdx,%rax
0x102cf14: jo     102e593 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x49a3>
0x102cf1a: movabs $0x7ffffffffffffff8,%rcx
0x102cf24: cmp    %rcx,%rax
0x102cf27: jg     102e5b8 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x49c8>
0x102cf2d: add    $0x7,%rax
0x102cf31: mov    $0x3,%r12d
0x102cf37: mov    %rbp,%rcx
0x102cf3a: add    %rax,%rcx
0x102cf3d: jno    102ce7f <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x328f>
