Candidate **goal110-natural-loop-align-5818cee8-debug**: focused comparison.

Source `5818cee8e679c1f30fd5966963210511fcf69919`; session `9456e694-5282-477b-ad5f-80a7da4a3826`.

All 80 frozen targets are retained in JSON. Each backend/case/size remains a separate target.

| Case / size | Backend | ns/iteration | Frozen ratio | Same-session original reference | Paired 95% interval | Current winner | Status |
|---|---|---:|---:|---:|---:|---|---|
| string_equal / small | my-llvm | 3.6363 | 1.207 | 1.255 (rust) | 1.245–1.265 | rust | open; slower_in_this_session |
| string_equal / small | my-qbe | 21.1004 | 7.002 | 7.281 (rust) | 7.222–7.341 | rust | open; slower_in_this_session |
| string_equal / large | my-llvm | 11.9156 | 0.385 | 0.405 (rust) | 0.403–0.425 | my-llvm | at_or_below; faster_in_this_session |
| string_equal / large | my-qbe | 230.8583 | 7.463 | 7.849 (rust) | 7.809–7.934 | my-llvm | open; slower_in_this_session |
| string_search / small | my-llvm | 19.2122 | 0.967 | 0.998 (my-llvm) | 0.994–1.002 | my-llvm | at_or_below; inconclusive |
| string_search / small | my-qbe | 24.1062 | 1.213 | 1.252 (my-llvm) | 1.248–1.261 | my-llvm | open; slower_in_this_session |
| string_search / large | my-llvm | 85.0163 | 0.864 | 0.883 (my-qbe) | 0.866–0.893 | my-llvm | at_or_below; faster_in_this_session |
| string_search / large | my-qbe | 90.8385 | 0.923 | 0.943 (my-qbe) | 0.927–0.952 | my-llvm | at_or_below; faster_in_this_session |
| bytes_scan / small | my-llvm | 3.4469 | 0.402 | 0.408 (my-llvm) | 0.407–0.410 | my-llvm | at_or_below; faster_in_this_session |
| bytes_scan / small | my-qbe | 7.9982 | 0.932 | 0.946 (my-llvm) | 0.931–0.952 | my-llvm | at_or_below; faster_in_this_session |
| bytes_scan / large | my-llvm | 74.9177 | 0.211 | 0.214 (my-llvm) | 0.204–0.215 | my-llvm | at_or_below; faster_in_this_session |
| bytes_scan / large | my-qbe | 79.2420 | 0.224 | 0.227 (my-llvm) | 0.216–0.229 | my-llvm | at_or_below; faster_in_this_session |
| string_join / small | my-llvm | 158.7379 | 0.721 | 0.728 (rust) | 0.701–0.734 | my-llvm | at_or_below; faster_in_this_session |
| string_join / small | my-qbe | 188.4941 | 0.856 | 0.865 (rust) | 0.826–0.870 | my-llvm | at_or_below; faster_in_this_session |
| string_join / large | my-llvm | 5701.8121 | 0.425 | 0.428 (rust) | 0.424–0.435 | my-llvm | at_or_below; faster_in_this_session |
| string_join / large | my-qbe | 5853.2147 | 0.436 | 0.439 (rust) | 0.437–0.447 | my-llvm | at_or_below; faster_in_this_session |
| int_parse / small | my-llvm | 9.8504 | 2.197 | 2.277 (rust) | 2.262–2.388 | rust | open; slower_in_this_session |
| int_parse / small | my-qbe | 18.0824 | 4.033 | 4.179 (rust) | 4.152–4.232 | rust | open; slower_in_this_session |
| int_parse / large | my-llvm | 11.1103 | 2.196 | 2.235 (rust) | 2.181–2.246 | rust | open; slower_in_this_session |
| int_parse / large | my-qbe | 19.1227 | 3.780 | 3.847 (rust) | 3.752–3.876 | rust | open; slower_in_this_session |
| int_format / small | my-llvm | 55.0053 | 3.792 | 3.754 (rust) | 3.745–3.890 | rust | open; slower_in_this_session |
| int_format / small | my-qbe | 83.1114 | 5.730 | 5.672 (rust) | 5.648–5.802 | rust | open; slower_in_this_session |
| int_format / large | my-llvm | 56.0396 | 3.693 | 3.745 (rust) | 3.562–3.767 | rust | open; slower_in_this_session |
| int_format / large | my-qbe | 84.0989 | 5.542 | 5.620 (rust) | 5.369–5.641 | rust | open; slower_in_this_session |

Frozen-target ratios condition on historical medians and have no same-session implication by themselves.
Paired intervals resample the same round indices, then divide medians; archived rounds are never paired.
Overlapping intervals are inconclusive. Near target (within 5%) does not meet the numerical goal.
Faster in this exploratory session is not demonstrated faster: independent confirmation is required.
Winner selection, multiple comparisons and repeated tuning are not corrected by these intervals.
Calibration limits and host interference remain material, especially for tiny or eliminated kernels.
