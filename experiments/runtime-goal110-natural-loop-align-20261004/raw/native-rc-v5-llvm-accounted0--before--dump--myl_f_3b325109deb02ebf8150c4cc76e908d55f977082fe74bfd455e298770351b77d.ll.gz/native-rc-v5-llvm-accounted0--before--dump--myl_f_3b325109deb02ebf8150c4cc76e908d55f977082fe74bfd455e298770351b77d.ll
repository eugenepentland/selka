target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v28 = load i64, ptr %slot1, align 8
  %op29 = add i64 %v28, 32
  store i64 %op29, ptr %slot4, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot5, align 8
  %mem32 = alloca i8, i64 8, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot6, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot7, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot8, align 8
  %v38 = load i64, ptr %slot2, align 8
  %v39 = load i64, ptr %slot5, align 8
  %p40 = inttoptr i64 %v39 to ptr
  store i64 %v38, ptr %p40, align 8, !alias.scope !3, !noalias !4
  %v41 = load i64, ptr %slot3, align 8
  %v42 = load i64, ptr %slot6, align 8
  %p43 = inttoptr i64 %v42 to ptr
  store i64 %v41, ptr %p43, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v44 = load i64, ptr %slot5, align 8
  %p45 = inttoptr i64 %v44 to ptr
  %ld46 = load i64, ptr %p45, align 8, !alias.scope !3, !noalias !4
  store i64 %ld46, ptr %slot9, align 8
  %v47 = load i64, ptr %slot9, align 8
  %v48 = load i64, ptr %slot7, align 8
  %p49 = inttoptr i64 %v48 to ptr
  store i64 %v47, ptr %p49, align 8, !alias.scope !3, !noalias !4
  %v50 = load i64, ptr %slot6, align 8
  %p51 = inttoptr i64 %v50 to ptr
  %ld52 = load i64, ptr %p51, align 8, !alias.scope !3, !noalias !4
  store i64 %ld52, ptr %slot10, align 8
  %v53 = load i64, ptr %slot10, align 8
  %v54 = load i64, ptr %slot8, align 8
  %p55 = inttoptr i64 %v54 to ptr
  store i64 %v53, ptr %p55, align 8, !alias.scope !3, !noalias !4
  %v56 = load i64, ptr %slot8, align 8
  %p57 = inttoptr i64 %v56 to ptr
  %ld58 = load i64, ptr %p57, align 8, !alias.scope !3, !noalias !4
  store i64 %ld58, ptr %slot11, align 8
  %v59 = load i64, ptr %slot7, align 8
  %p60 = inttoptr i64 %v59 to ptr
  %ld61 = load i64, ptr %p60, align 8, !alias.scope !3, !noalias !4
  store i64 %ld61, ptr %slot12, align 8
  %v62 = load i64, ptr %slot11, align 8
  %cmp63 = icmp eq i64 %v62, 0
  %cv64 = zext i1 %cmp63 to i64
  store i64 %cv64, ptr %slot13, align 8
  %v65 = load i64, ptr %slot13, align 8
  %cond66 = icmp ne i64 %v65, 0
  br i1 %cond66, label %bb_division4, label %bb_nonzero4
bb_division4:
  %v67 = load i64, ptr %slot1, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %v69 = load i64, ptr %slot12, align 8
  %v70 = load i64, ptr %slot11, align 8
  call void @myl_qbe_fail_division(ptr %p68, i64 6, i64 %v69, i64 %v70) nomerge, !dbg !110
  unreachable
bb_nonzero4:
  %v71 = load i64, ptr %slot12, align 8
  %cmp72 = icmp eq i64 %v71, 9223372036854775808
  %cv73 = zext i1 %cmp72 to i64
  store i64 %cv73, ptr %slot14, align 8
  %v74 = load i64, ptr %slot11, align 8
  %cmp75 = icmp eq i64 %v74, 18446744073709551615
  %cv76 = zext i1 %cmp75 to i64
  store i64 %cv76, ptr %slot15, align 8
  %v77 = load i64, ptr %slot14, align 8
  %v78 = load i64, ptr %slot15, align 8
  %op79 = and i64 %v77, %v78
  store i64 %op79, ptr %slot16, align 8
  %v80 = load i64, ptr %slot16, align 8
  %neg81 = sub i64 0, %v80
  store i64 %neg81, ptr %slot17, align 8
  %v82 = load i64, ptr %slot11, align 8
  %op83 = xor i64 %v82, 1
  store i64 %op83, ptr %slot18, align 8
  %v84 = load i64, ptr %slot18, align 8
  %v85 = load i64, ptr %slot17, align 8
  %op86 = and i64 %v84, %v85
  store i64 %op86, ptr %slot18, align 8
  %v87 = load i64, ptr %slot11, align 8
  %v88 = load i64, ptr %slot18, align 8
  %op89 = xor i64 %v87, %v88
  store i64 %op89, ptr %slot19, align 8
  %v90 = load i64, ptr %slot12, align 8
  %v91 = load i64, ptr %slot19, align 8
  %op92 = srem i64 %v90, %v91
  store i64 %op92, ptr %slot20, align 8
  %v93 = load i64, ptr %slot20, align 8
  %cmp94 = icmp ne i64 %v93, 0
  %cv95 = zext i1 %cmp94 to i64
  store i64 %cv95, ptr %slot21, align 8
  %v96 = load i64, ptr %slot20, align 8
  %v97 = load i64, ptr %slot19, align 8
  %op98 = xor i64 %v96, %v97
  store i64 %op98, ptr %slot22, align 8
  %v99 = load i64, ptr %slot22, align 8
  %cmp100 = icmp slt i64 %v99, 0
  %cv101 = zext i1 %cmp100 to i64
  store i64 %cv101, ptr %slot23, align 8
  %v102 = load i64, ptr %slot21, align 8
  %v103 = load i64, ptr %slot23, align 8
  %op104 = and i64 %v102, %v103
  store i64 %op104, ptr %slot24, align 8
  %v105 = load i64, ptr %slot24, align 8
  %neg106 = sub i64 0, %v105
  store i64 %neg106, ptr %slot25, align 8
  %v107 = load i64, ptr %slot19, align 8
  %v108 = load i64, ptr %slot25, align 8
  %op109 = and i64 %v107, %v108
  store i64 %op109, ptr %slot26, align 8
  %v110 = load i64, ptr %slot20, align 8
  %v111 = load i64, ptr %slot26, align 8
  %op112 = add i64 %v110, %v111
  store i64 %op112, ptr %slot20, align 8
  %v113 = load i64, ptr %slot20, align 8
  %v114 = load i64, ptr %slot7, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot7, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot27, align 8
  %v119 = load i64, ptr %slot27, align 8
  ret i64 %v119
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d", linkageName: "myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2117980670881469978, i64 0, !"myl_f_3b325109deb02ebf8150c4cc76e908d55f977082fe74bfd455e298770351b77d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
