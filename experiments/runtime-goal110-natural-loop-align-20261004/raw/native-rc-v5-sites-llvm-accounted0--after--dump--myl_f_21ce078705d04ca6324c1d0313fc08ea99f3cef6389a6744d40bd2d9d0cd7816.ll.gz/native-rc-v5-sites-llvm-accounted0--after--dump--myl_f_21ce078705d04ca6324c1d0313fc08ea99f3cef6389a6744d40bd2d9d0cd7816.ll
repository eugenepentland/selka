target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v51 = load i64, ptr %slot1, align 8
  %op52 = add i64 %v51, 32
  store i64 %op52, ptr %slot4, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot5, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot6, align 8
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot7, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot8, align 8
  %mem61 = alloca i8, i64 8, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot9, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot10, align 8
  %v65 = load i64, ptr %slot1, align 8
  %op66 = add i64 %v65, 64
  store i64 %op66, ptr %slot11, align 8
  %v67 = load i64, ptr %slot11, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !4, !noalias !3
  store i64 %ld69, ptr %slot12, align 8
  %stack70 = call ptr @llvm.stacksave()
  %stackaddr71 = ptrtoint ptr %stack70 to i64
  %v72 = load i64, ptr %slot12, align 8
  %cmp73 = icmp ult i64 %stackaddr71, %v72
  %cv74 = zext i1 %cmp73 to i64
  store i64 %cv74, ptr %slot13, align 8
  %v75 = load i64, ptr %slot13, align 8
  %cond76 = icmp ne i64 %v75, 0
  br i1 %cond76, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v77 = load i64, ptr %slot1, align 8
  %p78 = inttoptr i64 %v77 to ptr
  call void @myl_qbe_fail_frame(ptr %p78) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v79 = load i64, ptr %slot2, align 8
  %v80 = load i64, ptr %slot5, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i64 %v79, ptr %p81, align 8, !alias.scope !3, !noalias !4
  %v82 = load i64, ptr %slot3, align 8
  %v83 = load i64, ptr %slot6, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 %v82, ptr %p84, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v85 = load i64, ptr %slot6, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot14, align 8
  %v88 = load i64, ptr %slot14, align 8
  %v89 = load i64, ptr %slot7, align 8
  %p90 = inttoptr i64 %v89 to ptr
  store i64 %v88, ptr %p90, align 8, !alias.scope !3, !noalias !4
  %v91 = load i64, ptr %slot8, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 0, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot8, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot15, align 8
  %v96 = load i64, ptr %slot7, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot16, align 8
  %v99 = load i64, ptr %slot16, align 8
  %v100 = load i64, ptr %slot15, align 8
  %cmp101 = icmp sle i64 %v99, %v100
  %cv102 = zext i1 %cmp101 to i64
  store i64 %cv102, ptr %slot17, align 8
  %v103 = load i64, ptr %slot17, align 8
  %v104 = load i64, ptr %slot7, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 %v103, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot7, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld108, ptr %slot18, align 8
  %v109 = load i64, ptr %slot18, align 8
  %cond110 = icmp ne i64 %v109, 0
  br i1 %cond110, label %bb_next12, label %bb_i6
bb_next12:
  %v111 = load i64, ptr %slot5, align 8
  %p112 = inttoptr i64 %v111 to ptr
  %ld113 = load i64, ptr %p112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld113, ptr %slot19, align 8
  %v114 = load i64, ptr %slot19, align 8
  %v115 = load i64, ptr %slot7, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot7, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot20, align 8
  %v120 = load i64, ptr %slot20, align 8
  ret i64 %v120
bb_i6:
  %v121 = load i64, ptr %slot5, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot21, align 8
  %v124 = load i64, ptr %slot21, align 8
  %v125 = load i64, ptr %slot7, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 %v124, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot8, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 17, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot8, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot22, align 8
  %v132 = load i64, ptr %slot7, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i64, ptr %p133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld134, ptr %slot23, align 8
  %v135 = load i64, ptr %slot23, align 8
  %v136 = load i64, ptr %slot22, align 8
  %op137 = sub i64 %v135, %v136
  store i64 %op137, ptr %slot24, align 8
  %v138 = load i64, ptr %slot23, align 8
  %cmp139 = icmp slt i64 %v138, 9223372036854775825
  %cv140 = zext i1 %cmp139 to i64
  store i64 %cv140, ptr %slot25, align 8
  %v141 = load i64, ptr %slot25, align 8
  %cond142 = icmp ne i64 %v141, 0
  br i1 %cond142, label %bb_overflow17, label %bb_checked17
bb_overflow17:
  %v143 = load i64, ptr %slot1, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %v145 = load i64, ptr %slot23, align 8
  %v146 = load i64, ptr %slot22, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p144, i64 1, i64 %v145, i64 %v146, i64 64) nomerge, !dbg !112
  unreachable
bb_checked17:
  %v147 = load i64, ptr %slot24, align 8
  %v148 = load i64, ptr %slot7, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot8, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 1000000007, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot8, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot26, align 8
  %v155 = load i64, ptr %slot7, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot27, align 8
  %v158 = load i64, ptr %slot26, align 8
  %cmp159 = icmp eq i64 %v158, 0
  %cv160 = zext i1 %cmp159 to i64
  store i64 %cv160, ptr %slot28, align 8
  %v161 = load i64, ptr %slot28, align 8
  %cond162 = icmp ne i64 %v161, 0
  br i1 %cond162, label %bb_division21, label %bb_nonzero21
bb_division21:
  %v163 = load i64, ptr %slot1, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %v165 = load i64, ptr %slot27, align 8
  %v166 = load i64, ptr %slot26, align 8
  call void @myl_qbe_fail_division(ptr %p164, i64 6, i64 %v165, i64 %v166) nomerge, !dbg !114
  unreachable
bb_nonzero21:
  %v167 = load i64, ptr %slot27, align 8
  %cmp168 = icmp eq i64 %v167, 9223372036854775808
  %cv169 = zext i1 %cmp168 to i64
  store i64 %cv169, ptr %slot29, align 8
  %v170 = load i64, ptr %slot26, align 8
  %cmp171 = icmp eq i64 %v170, 18446744073709551615
  %cv172 = zext i1 %cmp171 to i64
  store i64 %cv172, ptr %slot30, align 8
  %v173 = load i64, ptr %slot29, align 8
  %v174 = load i64, ptr %slot30, align 8
  %op175 = and i64 %v173, %v174
  store i64 %op175, ptr %slot31, align 8
  %v176 = load i64, ptr %slot31, align 8
  %neg177 = sub i64 0, %v176
  store i64 %neg177, ptr %slot32, align 8
  %v178 = load i64, ptr %slot26, align 8
  %op179 = xor i64 %v178, 1
  store i64 %op179, ptr %slot33, align 8
  %v180 = load i64, ptr %slot33, align 8
  %v181 = load i64, ptr %slot32, align 8
  %op182 = and i64 %v180, %v181
  store i64 %op182, ptr %slot33, align 8
  %v183 = load i64, ptr %slot26, align 8
  %v184 = load i64, ptr %slot33, align 8
  %op185 = xor i64 %v183, %v184
  store i64 %op185, ptr %slot34, align 8
  %v186 = load i64, ptr %slot27, align 8
  %v187 = load i64, ptr %slot34, align 8
  %op188 = srem i64 %v186, %v187
  store i64 %op188, ptr %slot35, align 8
  %v189 = load i64, ptr %slot35, align 8
  %cmp190 = icmp ne i64 %v189, 0
  %cv191 = zext i1 %cmp190 to i64
  store i64 %cv191, ptr %slot36, align 8
  %v192 = load i64, ptr %slot35, align 8
  %v193 = load i64, ptr %slot34, align 8
  %op194 = xor i64 %v192, %v193
  store i64 %op194, ptr %slot37, align 8
  %v195 = load i64, ptr %slot37, align 8
  %cmp196 = icmp slt i64 %v195, 0
  %cv197 = zext i1 %cmp196 to i64
  store i64 %cv197, ptr %slot38, align 8
  %v198 = load i64, ptr %slot36, align 8
  %v199 = load i64, ptr %slot38, align 8
  %op200 = and i64 %v198, %v199
  store i64 %op200, ptr %slot39, align 8
  %v201 = load i64, ptr %slot39, align 8
  %neg202 = sub i64 0, %v201
  store i64 %neg202, ptr %slot40, align 8
  %v203 = load i64, ptr %slot34, align 8
  %v204 = load i64, ptr %slot40, align 8
  %op205 = and i64 %v203, %v204
  store i64 %op205, ptr %slot41, align 8
  %v206 = load i64, ptr %slot35, align 8
  %v207 = load i64, ptr %slot41, align 8
  %op208 = add i64 %v206, %v207
  store i64 %op208, ptr %slot35, align 8
  %v209 = load i64, ptr %slot35, align 8
  %floorbounded210 = icmp ult i64 %v209, 1000000007
  call void @llvm.assume(i1 %floorbounded210)
  %v211 = load i64, ptr %slot35, align 8
  %v212 = load i64, ptr %slot7, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot6, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot42, align 8
  %v217 = load i64, ptr %slot42, align 8
  %v218 = load i64, ptr %slot8, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot9, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i64 1, ptr %p221, align 8, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot9, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot43, align 8
  %v225 = load i64, ptr %slot8, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot44, align 8
  %v228 = load i64, ptr %slot44, align 8
  %v229 = load i64, ptr %slot43, align 8
  %ovpair231 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v228, i64 %v229)
  %op230 = extractvalue { i64, i1 } %ovpair231, 0
  %ov232 = extractvalue { i64, i1 } %ovpair231, 1
  store i64 %op230, ptr %slot45, align 8
  %cv233 = zext i1 %ov232 to i64
  store i64 %cv233, ptr %slot46, align 8
  %v234 = load i64, ptr %slot46, align 8
  %cond235 = icmp ne i64 %v234, 0
  br i1 %cond235, label %bb_overflow38, label %bb_checked38
bb_overflow38:
  %v236 = load i64, ptr %slot1, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %v238 = load i64, ptr %slot44, align 8
  %v239 = load i64, ptr %slot43, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p237, i64 1, i64 %v238, i64 %v239, i64 64) nomerge, !dbg !116
  unreachable
bb_checked38:
  %v240 = load i64, ptr %slot45, align 8
  %v241 = load i64, ptr %slot8, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot7, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot47, align 8
  %v246 = load i64, ptr %slot8, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot48, align 8
  %v249 = load i64, ptr %slot1, align 8
  %v250 = load i64, ptr %slot47, align 8
  %v251 = load i64, ptr %slot48, align 8
  %call252 = call i64 @myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816(i64 %v249, i64 %v250, i64 %v251) nomerge, !dbg !118
  store i64 %call252, ptr %slot49, align 8
  %v253 = load i64, ptr %slot49, align 8
  %v254 = load i64, ptr %slot7, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot7, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot50, align 8
  %v259 = load i64, ptr %slot50, align 8
  ret i64 %v259
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816", linkageName: "myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14868068991231004346, i64 0, !"myl_f_21ce078705d04ca6324c1d0313fc08ea99f3cef6389a6744d40bd2d9d0cd7816"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!112 = !DILocation(line: 9, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!114 = !DILocation(line: 11, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!116 = !DILocation(line: 14, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!118 = !DILocation(line: 15, column: 0, scope: !119)
