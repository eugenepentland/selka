target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v173 = load i64, ptr %slot1, align 8
  %op174 = add i64 %v173, 32
  store i64 %op174, ptr %slot5, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot6, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot7, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot8, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot9, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot10, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot11, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot12, align 8
  %mem189 = alloca i8, i64 8, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot13, align 8
  %mem191 = alloca i8, i64 8, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot14, align 8
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot15, align 8
  %v195 = load i64, ptr %slot2, align 8
  %v196 = load i64, ptr %slot6, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot3, align 8
  %v199 = load i64, ptr %slot7, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot4, align 8
  %v202 = load i64, ptr %slot8, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v204 = load i64, ptr %slot6, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot16, align 8
  %v207 = load i64, ptr %slot16, align 8
  %v208 = load i64, ptr %slot14, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i64 %v207, ptr %p209, align 8, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot14, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot17, align 8
  %v213 = load i64, ptr %slot9, align 8
  store i64 %v213, ptr %slot18, align 8
  %v214 = load i64, ptr %slot17, align 8
  %v215 = load i64, ptr %slot18, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot14, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 0, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot14, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot19, align 8
  %v222 = load i64, ptr %slot10, align 8
  store i64 %v222, ptr %slot20, align 8
  %v223 = load i64, ptr %slot19, align 8
  %v224 = load i64, ptr %slot20, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot7, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot21, align 8
  %v229 = load i64, ptr %slot21, align 8
  %v230 = load i64, ptr %slot14, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot14, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot22, align 8
  %v235 = load i64, ptr %slot11, align 8
  store i64 %v235, ptr %slot23, align 8
  %v236 = load i64, ptr %slot22, align 8
  %v237 = load i64, ptr %slot23, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot10, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot24, align 8
  %v242 = load i64, ptr %slot11, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot25, align 8
  %v245 = load i64, ptr %slot25, align 8
  %v246 = load i64, ptr %slot24, align 8
  %cmp247 = icmp sgt i64 %v245, %v246
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot26, align 8
  %v249 = load i64, ptr %slot25, align 8
  %v250 = load i64, ptr %slot24, align 8
  %op251 = sub i64 %v249, %v250
  store i64 %op251, ptr %slot27, align 8
  %v252 = load i64, ptr %slot27, align 8
  %cmp253 = icmp uge i64 %v252, 16
  %cv254 = zext i1 %cmp253 to i64
  store i64 %cv254, ptr %slot28, align 8
  %v255 = load i64, ptr %slot26, align 8
  %v256 = load i64, ptr %slot28, align 8
  %op257 = and i64 %v255, %v256
  store i64 %op257, ptr %slot29, align 8
  %v258 = load i64, ptr %slot29, align 8
  %cond259 = icmp ne i64 %v258, 0
  br i1 %cond259, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v260 = load i64, ptr %slot24, align 8
  %op261 = add i64 %v260, 1152921504606846976
  store i64 %op261, ptr %slot30, align 8
  %v262 = load i64, ptr %slot30, align 8
  %cmp263 = icmp ule i64 %v262, 2305843009213693952
  %cv264 = zext i1 %cmp263 to i64
  store i64 %cv264, ptr %slot31, align 8
  %v265 = load i64, ptr %slot31, align 8
  %cond266 = icmp ne i64 %v265, 0
  br i1 %cond266, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v267 = load i64, ptr %slot25, align 8
  %op268 = add i64 %v267, 1152921504606846976
  store i64 %op268, ptr %slot32, align 8
  %v269 = load i64, ptr %slot32, align 8
  %cmp270 = icmp ule i64 %v269, 2305843009213693952
  %cv271 = zext i1 %cmp270 to i64
  store i64 %cv271, ptr %slot33, align 8
  %v272 = load i64, ptr %slot33, align 8
  %cond273 = icmp ne i64 %v272, 0
  br i1 %cond273, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v274 = load i64, ptr %slot10, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot34, align 8
  %v277 = load i64, ptr %slot34, align 8
  %v278 = load i64, ptr %slot14, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot11, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot35, align 8
  %v283 = load i64, ptr %slot35, align 8
  %v284 = load i64, ptr %slot15, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i64 %v283, ptr %p285, align 8, !alias.scope !3, !noalias !4
  %v286 = load i64, ptr %slot15, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %ld288 = load i64, ptr %p287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld288, ptr %slot36, align 8
  %v289 = load i64, ptr %slot14, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot37, align 8
  %v292 = load i64, ptr %slot37, align 8
  %v293 = load i64, ptr %slot36, align 8
  %cmp294 = icmp slt i64 %v292, %v293
  %cv295 = zext i1 %cmp294 to i64
  store i64 %cv295, ptr %slot38, align 8
  %v296 = load i64, ptr %slot38, align 8
  %v297 = load i64, ptr %slot14, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot14, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot39, align 8
  %v302 = load i64, ptr %slot39, align 8
  %cond303 = icmp ne i64 %v302, 0
  br i1 %cond303, label %bb_next24, label %bb_i34
bb_next24:
  %v304 = load i64, ptr %slot10, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot40, align 8
  %v307 = load i64, ptr %slot40, align 8
  %v308 = load i64, ptr %slot14, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot15, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 2, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot15, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot41, align 8
  %v315 = load i64, ptr %slot14, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot42, align 8
  %v318 = load i64, ptr %slot41, align 8
  %cmp319 = icmp eq i64 %v318, 0
  %cv320 = zext i1 %cmp319 to i64
  store i64 %cv320, ptr %slot43, align 8
  %v321 = load i64, ptr %slot43, align 8
  %cond322 = icmp ne i64 %v321, 0
  br i1 %cond322, label %bb_division27, label %bb_nonzero27
bb_division27:
  %v323 = load i64, ptr %slot1, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %v325 = load i64, ptr %slot42, align 8
  %v326 = load i64, ptr %slot41, align 8
  call void @myl_qbe_fail_division(ptr %p324, i64 6, i64 %v325, i64 %v326) nomerge, !dbg !110
  unreachable
bb_nonzero27:
  %v327 = load i64, ptr %slot42, align 8
  %cmp328 = icmp eq i64 %v327, 9223372036854775808
  %cv329 = zext i1 %cmp328 to i64
  store i64 %cv329, ptr %slot44, align 8
  %v330 = load i64, ptr %slot41, align 8
  %cmp331 = icmp eq i64 %v330, 18446744073709551615
  %cv332 = zext i1 %cmp331 to i64
  store i64 %cv332, ptr %slot45, align 8
  %v333 = load i64, ptr %slot44, align 8
  %v334 = load i64, ptr %slot45, align 8
  %op335 = and i64 %v333, %v334
  store i64 %op335, ptr %slot46, align 8
  %v336 = load i64, ptr %slot46, align 8
  %neg337 = sub i64 0, %v336
  store i64 %neg337, ptr %slot47, align 8
  %v338 = load i64, ptr %slot41, align 8
  %op339 = xor i64 %v338, 1
  store i64 %op339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot48, align 8
  %v341 = load i64, ptr %slot47, align 8
  %op342 = and i64 %v340, %v341
  store i64 %op342, ptr %slot48, align 8
  %v343 = load i64, ptr %slot41, align 8
  %v344 = load i64, ptr %slot48, align 8
  %op345 = xor i64 %v343, %v344
  store i64 %op345, ptr %slot49, align 8
  %v346 = load i64, ptr %slot42, align 8
  %v347 = load i64, ptr %slot49, align 8
  %op348 = srem i64 %v346, %v347
  store i64 %op348, ptr %slot50, align 8
  %v349 = load i64, ptr %slot50, align 8
  %cmp350 = icmp ne i64 %v349, 0
  %cv351 = zext i1 %cmp350 to i64
  store i64 %cv351, ptr %slot51, align 8
  %v352 = load i64, ptr %slot50, align 8
  %v353 = load i64, ptr %slot49, align 8
  %op354 = xor i64 %v352, %v353
  store i64 %op354, ptr %slot52, align 8
  %v355 = load i64, ptr %slot52, align 8
  %cmp356 = icmp slt i64 %v355, 0
  %cv357 = zext i1 %cmp356 to i64
  store i64 %cv357, ptr %slot53, align 8
  %v358 = load i64, ptr %slot51, align 8
  %v359 = load i64, ptr %slot53, align 8
  %op360 = and i64 %v358, %v359
  store i64 %op360, ptr %slot54, align 8
  %v361 = load i64, ptr %slot54, align 8
  %neg362 = sub i64 0, %v361
  store i64 %neg362, ptr %slot55, align 8
  %v363 = load i64, ptr %slot49, align 8
  %v364 = load i64, ptr %slot55, align 8
  %op365 = and i64 %v363, %v364
  store i64 %op365, ptr %slot56, align 8
  %v366 = load i64, ptr %slot50, align 8
  %v367 = load i64, ptr %slot56, align 8
  %op368 = add i64 %v366, %v367
  store i64 %op368, ptr %slot50, align 8
  %v369 = load i64, ptr %slot50, align 8
  %floorbounded370 = icmp ult i64 %v369, 2
  call void @llvm.assume(i1 %floorbounded370)
  %v371 = load i64, ptr %slot50, align 8
  %v372 = load i64, ptr %slot14, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 %v371, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot8, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot57, align 8
  %v377 = load i64, ptr %slot57, align 8
  %v378 = load i64, ptr %slot15, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 %v377, ptr %p379, align 8, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot15, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot58, align 8
  %v383 = load i64, ptr %slot14, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot59, align 8
  %v386 = load i64, ptr %slot59, align 8
  %v387 = load i64, ptr %slot58, align 8
  %cmp388 = icmp eq i64 %v386, %v387
  %cv389 = zext i1 %cmp388 to i64
  store i64 %cv389, ptr %slot60, align 8
  %v390 = load i64, ptr %slot60, align 8
  %v391 = load i64, ptr %slot14, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 %v390, ptr %p392, align 8, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot14, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %ld395 = load i64, ptr %p394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld395, ptr %slot61, align 8
  %v396 = load i64, ptr %slot61, align 8
  %cond397 = icmp ne i64 %v396, 0
  br i1 %cond397, label %bb_next46, label %bb_fi19
bb_next46:
  %v398 = load i64, ptr %slot14, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 1, ptr %p399, align 8, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot14, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i64, ptr %p401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld402, ptr %slot62, align 8
  %v403 = load i64, ptr %slot12, align 8
  store i64 %v403, ptr %slot63, align 8
  %v404 = load i64, ptr %slot62, align 8
  %v405 = load i64, ptr %slot63, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v407 = load i64, ptr %slot14, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 0, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot14, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i64, ptr %p410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot64, align 8
  %v412 = load i64, ptr %slot12, align 8
  store i64 %v412, ptr %slot65, align 8
  %v413 = load i64, ptr %slot64, align 8
  %v414 = load i64, ptr %slot65, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i64 %v413, ptr %p415, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v416 = load i64, ptr %slot12, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i64, ptr %p417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld418, ptr %slot66, align 8
  %v419 = load i64, ptr %slot66, align 8
  %v420 = load i64, ptr %slot14, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 %v419, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot14, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot67, align 8
  %v425 = load i64, ptr %slot13, align 8
  store i64 %v425, ptr %slot68, align 8
  %v426 = load i64, ptr %slot67, align 8
  %v427 = load i64, ptr %slot68, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i64 %v426, ptr %p428, align 8, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot9, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot69, align 8
  %v432 = load i64, ptr %slot69, align 8
  %v433 = load i64, ptr %slot14, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot13, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i64, ptr %p436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld437, ptr %slot70, align 8
  %v438 = load i64, ptr %slot70, align 8
  %v439 = load i64, ptr %slot15, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i64 %v438, ptr %p440, align 8, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot15, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i64, ptr %p442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld443, ptr %slot71, align 8
  %v444 = load i64, ptr %slot14, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot72, align 8
  %v447 = load i64, ptr %slot72, align 8
  %v448 = load i64, ptr %slot71, align 8
  %ovpair450 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v447, i64 %v448)
  %op449 = extractvalue { i64, i1 } %ovpair450, 0
  %ov451 = extractvalue { i64, i1 } %ovpair450, 1
  store i64 %op449, ptr %slot73, align 8
  %v452 = load i64, ptr %slot72, align 8
  %v453 = load i64, ptr %slot73, align 8
  %op454 = xor i64 %v452, %v453
  store i64 %op454, ptr %slot74, align 8
  %v455 = load i64, ptr %slot71, align 8
  %v456 = load i64, ptr %slot73, align 8
  %op457 = xor i64 %v455, %v456
  store i64 %op457, ptr %slot75, align 8
  %v458 = load i64, ptr %slot74, align 8
  %v459 = load i64, ptr %slot75, align 8
  %op460 = and i64 %v458, %v459
  store i64 %op460, ptr %slot76, align 8
  %cv461 = zext i1 %ov451 to i64
  store i64 %cv461, ptr %slot77, align 8
  %v462 = load i64, ptr %slot77, align 8
  %cond463 = icmp ne i64 %v462, 0
  br i1 %cond463, label %bb_overflow57, label %bb_checked57
bb_overflow57:
  %v464 = load i64, ptr %slot1, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %v466 = load i64, ptr %slot72, align 8
  %v467 = load i64, ptr %slot71, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p465, i64 0, i64 %v466, i64 %v467, i64 64) nomerge, !dbg !112
  unreachable
bb_checked57:
  %v468 = load i64, ptr %slot73, align 8
  %v469 = load i64, ptr %slot14, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i64 %v468, ptr %p470, align 8, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot15, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 1000000007, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot15, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld475, ptr %slot78, align 8
  %v476 = load i64, ptr %slot14, align 8
  %p477 = inttoptr i64 %v476 to ptr
  %ld478 = load i64, ptr %p477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld478, ptr %slot79, align 8
  %v479 = load i64, ptr %slot78, align 8
  %cmp480 = icmp eq i64 %v479, 0
  %cv481 = zext i1 %cmp480 to i64
  store i64 %cv481, ptr %slot80, align 8
  %v482 = load i64, ptr %slot80, align 8
  %cond483 = icmp ne i64 %v482, 0
  br i1 %cond483, label %bb_division64, label %bb_nonzero64
bb_division64:
  %v484 = load i64, ptr %slot1, align 8
  %p485 = inttoptr i64 %v484 to ptr
  %v486 = load i64, ptr %slot79, align 8
  %v487 = load i64, ptr %slot78, align 8
  call void @myl_qbe_fail_division(ptr %p485, i64 6, i64 %v486, i64 %v487) nomerge, !dbg !114
  unreachable
bb_nonzero64:
  %v488 = load i64, ptr %slot79, align 8
  %cmp489 = icmp eq i64 %v488, 9223372036854775808
  %cv490 = zext i1 %cmp489 to i64
  store i64 %cv490, ptr %slot81, align 8
  %v491 = load i64, ptr %slot78, align 8
  %cmp492 = icmp eq i64 %v491, 18446744073709551615
  %cv493 = zext i1 %cmp492 to i64
  store i64 %cv493, ptr %slot82, align 8
  %v494 = load i64, ptr %slot81, align 8
  %v495 = load i64, ptr %slot82, align 8
  %op496 = and i64 %v494, %v495
  store i64 %op496, ptr %slot83, align 8
  %v497 = load i64, ptr %slot83, align 8
  %neg498 = sub i64 0, %v497
  store i64 %neg498, ptr %slot84, align 8
  %v499 = load i64, ptr %slot78, align 8
  %op500 = xor i64 %v499, 1
  store i64 %op500, ptr %slot85, align 8
  %v501 = load i64, ptr %slot85, align 8
  %v502 = load i64, ptr %slot84, align 8
  %op503 = and i64 %v501, %v502
  store i64 %op503, ptr %slot85, align 8
  %v504 = load i64, ptr %slot78, align 8
  %v505 = load i64, ptr %slot85, align 8
  %op506 = xor i64 %v504, %v505
  store i64 %op506, ptr %slot86, align 8
  %v507 = load i64, ptr %slot79, align 8
  %v508 = load i64, ptr %slot86, align 8
  %op509 = srem i64 %v507, %v508
  store i64 %op509, ptr %slot87, align 8
  %v510 = load i64, ptr %slot87, align 8
  %cmp511 = icmp ne i64 %v510, 0
  %cv512 = zext i1 %cmp511 to i64
  store i64 %cv512, ptr %slot88, align 8
  %v513 = load i64, ptr %slot87, align 8
  %v514 = load i64, ptr %slot86, align 8
  %op515 = xor i64 %v513, %v514
  store i64 %op515, ptr %slot89, align 8
  %v516 = load i64, ptr %slot89, align 8
  %cmp517 = icmp slt i64 %v516, 0
  %cv518 = zext i1 %cmp517 to i64
  store i64 %cv518, ptr %slot90, align 8
  %v519 = load i64, ptr %slot88, align 8
  %v520 = load i64, ptr %slot90, align 8
  %op521 = and i64 %v519, %v520
  store i64 %op521, ptr %slot91, align 8
  %v522 = load i64, ptr %slot91, align 8
  %neg523 = sub i64 0, %v522
  store i64 %neg523, ptr %slot92, align 8
  %v524 = load i64, ptr %slot86, align 8
  %v525 = load i64, ptr %slot92, align 8
  %op526 = and i64 %v524, %v525
  store i64 %op526, ptr %slot93, align 8
  %v527 = load i64, ptr %slot87, align 8
  %v528 = load i64, ptr %slot93, align 8
  %op529 = add i64 %v527, %v528
  store i64 %op529, ptr %slot87, align 8
  %v530 = load i64, ptr %slot87, align 8
  %floorbounded531 = icmp ult i64 %v530, 1000000007
  call void @llvm.assume(i1 %floorbounded531)
  %v532 = load i64, ptr %slot87, align 8
  %v533 = load i64, ptr %slot14, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i64 %v532, ptr %p534, align 8, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot14, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot94, align 8
  %v538 = load i64, ptr %slot9, align 8
  store i64 %v538, ptr %slot95, align 8
  %v539 = load i64, ptr %slot94, align 8
  %v540 = load i64, ptr %slot95, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot10, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot96, align 8
  %v545 = load i64, ptr %slot96, align 8
  %v546 = load i64, ptr %slot14, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot15, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 1, ptr %p549, align 8, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot15, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot97, align 8
  %v553 = load i64, ptr %slot14, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot98, align 8
  %v556 = load i64, ptr %slot98, align 8
  %v557 = load i64, ptr %slot97, align 8
  %op558 = add i64 %v556, %v557
  store i64 %op558, ptr %slot99, align 8
  %v559 = load i64, ptr %slot99, align 8
  %v560 = load i64, ptr %slot14, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i64 %v559, ptr %p561, align 8, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot14, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %ld564 = load i64, ptr %p563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot100, align 8
  %v565 = load i64, ptr %slot10, align 8
  store i64 %v565, ptr %slot101, align 8
  %v566 = load i64, ptr %slot100, align 8
  %v567 = load i64, ptr %slot101, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !119
bb_oi6:
  %v569 = load i64, ptr %slot10, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot102, align 8
  %v572 = load i64, ptr %slot102, align 8
  %v573 = load i64, ptr %slot14, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i64 %v572, ptr %p574, align 8, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot11, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot103, align 8
  %v578 = load i64, ptr %slot103, align 8
  %v579 = load i64, ptr %slot15, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i64 %v578, ptr %p580, align 8, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot15, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %ld583 = load i64, ptr %p582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld583, ptr %slot104, align 8
  %v584 = load i64, ptr %slot14, align 8
  %p585 = inttoptr i64 %v584 to ptr
  %ld586 = load i64, ptr %p585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld586, ptr %slot105, align 8
  %v587 = load i64, ptr %slot105, align 8
  %v588 = load i64, ptr %slot104, align 8
  %cmp589 = icmp slt i64 %v587, %v588
  %cv590 = zext i1 %cmp589 to i64
  store i64 %cv590, ptr %slot106, align 8
  %v591 = load i64, ptr %slot106, align 8
  %v592 = load i64, ptr %slot14, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i64 %v591, ptr %p593, align 8, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot14, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld596, ptr %slot107, align 8
  %v597 = load i64, ptr %slot107, align 8
  %cond598 = icmp ne i64 %v597, 0
  br i1 %cond598, label %bb_next92, label %bb_i34
bb_next92:
  %v599 = load i64, ptr %slot10, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ld601 = load i64, ptr %p600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot108, align 8
  %v602 = load i64, ptr %slot108, align 8
  %v603 = load i64, ptr %slot14, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i64 %v602, ptr %p604, align 8, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot15, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i64 2, ptr %p606, align 8, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot15, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i64, ptr %p608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld609, ptr %slot109, align 8
  %v610 = load i64, ptr %slot14, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot110, align 8
  %v613 = load i64, ptr %slot109, align 8
  %cmp614 = icmp eq i64 %v613, 0
  %cv615 = zext i1 %cmp614 to i64
  store i64 %cv615, ptr %slot111, align 8
  %v616 = load i64, ptr %slot111, align 8
  %cond617 = icmp ne i64 %v616, 0
  br i1 %cond617, label %bb_division95, label %bb_nonzero95
bb_division95:
  %v618 = load i64, ptr %slot1, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %v620 = load i64, ptr %slot110, align 8
  %v621 = load i64, ptr %slot109, align 8
  call void @myl_qbe_fail_division(ptr %p619, i64 6, i64 %v620, i64 %v621) nomerge, !dbg !110
  unreachable
bb_nonzero95:
  %v622 = load i64, ptr %slot110, align 8
  %cmp623 = icmp eq i64 %v622, 9223372036854775808
  %cv624 = zext i1 %cmp623 to i64
  store i64 %cv624, ptr %slot112, align 8
  %v625 = load i64, ptr %slot109, align 8
  %cmp626 = icmp eq i64 %v625, 18446744073709551615
  %cv627 = zext i1 %cmp626 to i64
  store i64 %cv627, ptr %slot113, align 8
  %v628 = load i64, ptr %slot112, align 8
  %v629 = load i64, ptr %slot113, align 8
  %op630 = and i64 %v628, %v629
  store i64 %op630, ptr %slot114, align 8
  %v631 = load i64, ptr %slot114, align 8
  %neg632 = sub i64 0, %v631
  store i64 %neg632, ptr %slot115, align 8
  %v633 = load i64, ptr %slot109, align 8
  %op634 = xor i64 %v633, 1
  store i64 %op634, ptr %slot116, align 8
  %v635 = load i64, ptr %slot116, align 8
  %v636 = load i64, ptr %slot115, align 8
  %op637 = and i64 %v635, %v636
  store i64 %op637, ptr %slot116, align 8
  %v638 = load i64, ptr %slot109, align 8
  %v639 = load i64, ptr %slot116, align 8
  %op640 = xor i64 %v638, %v639
  store i64 %op640, ptr %slot117, align 8
  %v641 = load i64, ptr %slot110, align 8
  %v642 = load i64, ptr %slot117, align 8
  %op643 = srem i64 %v641, %v642
  store i64 %op643, ptr %slot118, align 8
  %v644 = load i64, ptr %slot118, align 8
  %cmp645 = icmp ne i64 %v644, 0
  %cv646 = zext i1 %cmp645 to i64
  store i64 %cv646, ptr %slot119, align 8
  %v647 = load i64, ptr %slot118, align 8
  %v648 = load i64, ptr %slot117, align 8
  %op649 = xor i64 %v647, %v648
  store i64 %op649, ptr %slot120, align 8
  %v650 = load i64, ptr %slot120, align 8
  %cmp651 = icmp slt i64 %v650, 0
  %cv652 = zext i1 %cmp651 to i64
  store i64 %cv652, ptr %slot121, align 8
  %v653 = load i64, ptr %slot119, align 8
  %v654 = load i64, ptr %slot121, align 8
  %op655 = and i64 %v653, %v654
  store i64 %op655, ptr %slot122, align 8
  %v656 = load i64, ptr %slot122, align 8
  %neg657 = sub i64 0, %v656
  store i64 %neg657, ptr %slot123, align 8
  %v658 = load i64, ptr %slot117, align 8
  %v659 = load i64, ptr %slot123, align 8
  %op660 = and i64 %v658, %v659
  store i64 %op660, ptr %slot124, align 8
  %v661 = load i64, ptr %slot118, align 8
  %v662 = load i64, ptr %slot124, align 8
  %op663 = add i64 %v661, %v662
  store i64 %op663, ptr %slot118, align 8
  %v664 = load i64, ptr %slot118, align 8
  %floorbounded665 = icmp ult i64 %v664, 2
  call void @llvm.assume(i1 %floorbounded665)
  %v666 = load i64, ptr %slot118, align 8
  %v667 = load i64, ptr %slot14, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 %v666, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot8, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %ld671 = load i64, ptr %p670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld671, ptr %slot125, align 8
  %v672 = load i64, ptr %slot125, align 8
  %v673 = load i64, ptr %slot15, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i64 %v672, ptr %p674, align 8, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot15, align 8
  %p676 = inttoptr i64 %v675 to ptr
  %ld677 = load i64, ptr %p676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld677, ptr %slot126, align 8
  %v678 = load i64, ptr %slot14, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i64, ptr %p679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld680, ptr %slot127, align 8
  %v681 = load i64, ptr %slot127, align 8
  %v682 = load i64, ptr %slot126, align 8
  %cmp683 = icmp eq i64 %v681, %v682
  %cv684 = zext i1 %cmp683 to i64
  store i64 %cv684, ptr %slot128, align 8
  %v685 = load i64, ptr %slot128, align 8
  %v686 = load i64, ptr %slot14, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot14, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot129, align 8
  %v691 = load i64, ptr %slot129, align 8
  %cond692 = icmp ne i64 %v691, 0
  br i1 %cond692, label %bb_next114, label %bb_i19
bb_next114:
  %v693 = load i64, ptr %slot14, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 1, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot14, align 8
  %p696 = inttoptr i64 %v695 to ptr
  %ld697 = load i64, ptr %p696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld697, ptr %slot130, align 8
  %v698 = load i64, ptr %slot12, align 8
  store i64 %v698, ptr %slot131, align 8
  %v699 = load i64, ptr %slot130, align 8
  %v700 = load i64, ptr %slot131, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i64 %v699, ptr %p701, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v702 = load i64, ptr %slot14, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i64 0, ptr %p703, align 8, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot14, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %ld706 = load i64, ptr %p705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld706, ptr %slot132, align 8
  %v707 = load i64, ptr %slot12, align 8
  store i64 %v707, ptr %slot133, align 8
  %v708 = load i64, ptr %slot132, align 8
  %v709 = load i64, ptr %slot133, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i64 %v708, ptr %p710, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v711 = load i64, ptr %slot12, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %ld713 = load i64, ptr %p712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld713, ptr %slot134, align 8
  %v714 = load i64, ptr %slot134, align 8
  %v715 = load i64, ptr %slot14, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 %v714, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot14, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot135, align 8
  %v720 = load i64, ptr %slot13, align 8
  store i64 %v720, ptr %slot136, align 8
  %v721 = load i64, ptr %slot135, align 8
  %v722 = load i64, ptr %slot136, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 %v721, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot9, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i64, ptr %p725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld726, ptr %slot137, align 8
  %v727 = load i64, ptr %slot137, align 8
  %v728 = load i64, ptr %slot14, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i64 %v727, ptr %p729, align 8, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot13, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot138, align 8
  %v733 = load i64, ptr %slot138, align 8
  %v734 = load i64, ptr %slot15, align 8
  %p735 = inttoptr i64 %v734 to ptr
  store i64 %v733, ptr %p735, align 8, !alias.scope !3, !noalias !4
  %v736 = load i64, ptr %slot15, align 8
  %p737 = inttoptr i64 %v736 to ptr
  %ld738 = load i64, ptr %p737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld738, ptr %slot139, align 8
  %v739 = load i64, ptr %slot14, align 8
  %p740 = inttoptr i64 %v739 to ptr
  %ld741 = load i64, ptr %p740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld741, ptr %slot140, align 8
  %v742 = load i64, ptr %slot140, align 8
  %v743 = load i64, ptr %slot139, align 8
  %ovpair745 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v742, i64 %v743)
  %op744 = extractvalue { i64, i1 } %ovpair745, 0
  %ov746 = extractvalue { i64, i1 } %ovpair745, 1
  store i64 %op744, ptr %slot141, align 8
  %v747 = load i64, ptr %slot140, align 8
  %v748 = load i64, ptr %slot141, align 8
  %op749 = xor i64 %v747, %v748
  store i64 %op749, ptr %slot142, align 8
  %v750 = load i64, ptr %slot139, align 8
  %v751 = load i64, ptr %slot141, align 8
  %op752 = xor i64 %v750, %v751
  store i64 %op752, ptr %slot143, align 8
  %v753 = load i64, ptr %slot142, align 8
  %v754 = load i64, ptr %slot143, align 8
  %op755 = and i64 %v753, %v754
  store i64 %op755, ptr %slot144, align 8
  %cv756 = zext i1 %ov746 to i64
  store i64 %cv756, ptr %slot145, align 8
  %v757 = load i64, ptr %slot145, align 8
  %cond758 = icmp ne i64 %v757, 0
  br i1 %cond758, label %bb_overflow125, label %bb_checked125
bb_overflow125:
  %v759 = load i64, ptr %slot1, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %v761 = load i64, ptr %slot140, align 8
  %v762 = load i64, ptr %slot139, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p760, i64 0, i64 %v761, i64 %v762, i64 64) nomerge, !dbg !112
  unreachable
bb_checked125:
  %v763 = load i64, ptr %slot141, align 8
  %v764 = load i64, ptr %slot14, align 8
  %p765 = inttoptr i64 %v764 to ptr
  store i64 %v763, ptr %p765, align 8, !alias.scope !3, !noalias !4
  %v766 = load i64, ptr %slot15, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i64 1000000007, ptr %p767, align 8, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot15, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i64, ptr %p769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld770, ptr %slot146, align 8
  %v771 = load i64, ptr %slot14, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %ld773 = load i64, ptr %p772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld773, ptr %slot147, align 8
  %v774 = load i64, ptr %slot146, align 8
  %cmp775 = icmp eq i64 %v774, 0
  %cv776 = zext i1 %cmp775 to i64
  store i64 %cv776, ptr %slot148, align 8
  %v777 = load i64, ptr %slot148, align 8
  %cond778 = icmp ne i64 %v777, 0
  br i1 %cond778, label %bb_division132, label %bb_nonzero132
bb_division132:
  %v779 = load i64, ptr %slot1, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %v781 = load i64, ptr %slot147, align 8
  %v782 = load i64, ptr %slot146, align 8
  call void @myl_qbe_fail_division(ptr %p780, i64 6, i64 %v781, i64 %v782) nomerge, !dbg !114
  unreachable
bb_nonzero132:
  %v783 = load i64, ptr %slot147, align 8
  %cmp784 = icmp eq i64 %v783, 9223372036854775808
  %cv785 = zext i1 %cmp784 to i64
  store i64 %cv785, ptr %slot149, align 8
  %v786 = load i64, ptr %slot146, align 8
  %cmp787 = icmp eq i64 %v786, 18446744073709551615
  %cv788 = zext i1 %cmp787 to i64
  store i64 %cv788, ptr %slot150, align 8
  %v789 = load i64, ptr %slot149, align 8
  %v790 = load i64, ptr %slot150, align 8
  %op791 = and i64 %v789, %v790
  store i64 %op791, ptr %slot151, align 8
  %v792 = load i64, ptr %slot151, align 8
  %neg793 = sub i64 0, %v792
  store i64 %neg793, ptr %slot152, align 8
  %v794 = load i64, ptr %slot146, align 8
  %op795 = xor i64 %v794, 1
  store i64 %op795, ptr %slot153, align 8
  %v796 = load i64, ptr %slot153, align 8
  %v797 = load i64, ptr %slot152, align 8
  %op798 = and i64 %v796, %v797
  store i64 %op798, ptr %slot153, align 8
  %v799 = load i64, ptr %slot146, align 8
  %v800 = load i64, ptr %slot153, align 8
  %op801 = xor i64 %v799, %v800
  store i64 %op801, ptr %slot154, align 8
  %v802 = load i64, ptr %slot147, align 8
  %v803 = load i64, ptr %slot154, align 8
  %op804 = srem i64 %v802, %v803
  store i64 %op804, ptr %slot155, align 8
  %v805 = load i64, ptr %slot155, align 8
  %cmp806 = icmp ne i64 %v805, 0
  %cv807 = zext i1 %cmp806 to i64
  store i64 %cv807, ptr %slot156, align 8
  %v808 = load i64, ptr %slot155, align 8
  %v809 = load i64, ptr %slot154, align 8
  %op810 = xor i64 %v808, %v809
  store i64 %op810, ptr %slot157, align 8
  %v811 = load i64, ptr %slot157, align 8
  %cmp812 = icmp slt i64 %v811, 0
  %cv813 = zext i1 %cmp812 to i64
  store i64 %cv813, ptr %slot158, align 8
  %v814 = load i64, ptr %slot156, align 8
  %v815 = load i64, ptr %slot158, align 8
  %op816 = and i64 %v814, %v815
  store i64 %op816, ptr %slot159, align 8
  %v817 = load i64, ptr %slot159, align 8
  %neg818 = sub i64 0, %v817
  store i64 %neg818, ptr %slot160, align 8
  %v819 = load i64, ptr %slot154, align 8
  %v820 = load i64, ptr %slot160, align 8
  %op821 = and i64 %v819, %v820
  store i64 %op821, ptr %slot161, align 8
  %v822 = load i64, ptr %slot155, align 8
  %v823 = load i64, ptr %slot161, align 8
  %op824 = add i64 %v822, %v823
  store i64 %op824, ptr %slot155, align 8
  %v825 = load i64, ptr %slot155, align 8
  %floorbounded826 = icmp ult i64 %v825, 1000000007
  call void @llvm.assume(i1 %floorbounded826)
  %v827 = load i64, ptr %slot155, align 8
  %v828 = load i64, ptr %slot14, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot14, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld832, ptr %slot162, align 8
  %v833 = load i64, ptr %slot9, align 8
  store i64 %v833, ptr %slot163, align 8
  %v834 = load i64, ptr %slot162, align 8
  %v835 = load i64, ptr %slot163, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i64 %v834, ptr %p836, align 8, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot10, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld839, ptr %slot164, align 8
  %v840 = load i64, ptr %slot164, align 8
  %v841 = load i64, ptr %slot14, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i64 %v840, ptr %p842, align 8, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot15, align 8
  %p844 = inttoptr i64 %v843 to ptr
  store i64 1, ptr %p844, align 8, !alias.scope !3, !noalias !4
  %v845 = load i64, ptr %slot15, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld847, ptr %slot165, align 8
  %v848 = load i64, ptr %slot14, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %ld850 = load i64, ptr %p849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld850, ptr %slot166, align 8
  %v851 = load i64, ptr %slot166, align 8
  %v852 = load i64, ptr %slot165, align 8
  %op853 = add i64 %v851, %v852
  %ovpair854 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v851, i64 %v852)
  %ov855 = extractvalue { i64, i1 } %ovpair854, 1
  store i64 %op853, ptr %slot167, align 8
  %cv856 = zext i1 %ov855 to i64
  store i64 %cv856, ptr %slot168, align 8
  %v857 = load i64, ptr %slot168, align 8
  %cond858 = icmp ne i64 %v857, 0
  br i1 %cond858, label %bb_overflow151, label %bb_checked151
bb_overflow151:
  %v859 = load i64, ptr %slot1, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %v861 = load i64, ptr %slot166, align 8
  %v862 = load i64, ptr %slot165, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p860, i64 0, i64 %v861, i64 %v862, i64 64) nomerge, !dbg !116
  unreachable
bb_checked151:
  %v863 = load i64, ptr %slot167, align 8
  %v864 = load i64, ptr %slot14, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i64 %v863, ptr %p865, align 8, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot14, align 8
  %p867 = inttoptr i64 %v866 to ptr
  %ld868 = load i64, ptr %p867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld868, ptr %slot169, align 8
  %v869 = load i64, ptr %slot10, align 8
  store i64 %v869, ptr %slot170, align 8
  %v870 = load i64, ptr %slot169, align 8
  %v871 = load i64, ptr %slot170, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 %v870, ptr %p872, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !120
bb_i34:
  %v873 = load i64, ptr %slot9, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ld875 = load i64, ptr %p874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld875, ptr %slot171, align 8
  %v876 = load i64, ptr %slot171, align 8
  %v877 = load i64, ptr %slot14, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 %v876, ptr %p878, align 8, !alias.scope !3, !noalias !4
  %v879 = load i64, ptr %slot14, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot172, align 8
  %v882 = load i64, ptr %slot172, align 8
  ret i64 %v882
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", linkageName: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4238653121982337121, i64 0, !"myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
!118 = !{!"llvm.loop.align", i32 32}
!119 = distinct !{!119, !118}
!120 = distinct !{!120, !118}
