target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i32, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v89 = load i64, ptr %slot1, align 8
  %op90 = add i64 %v89, 32
  store i64 %op90, ptr %slot3, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot4, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot5, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot6, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot7, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot8, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot9, align 8
  %mem103 = alloca i8, i64 16, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot10, align 8
  %mem105 = alloca i8, i64 16, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot11, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot12, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot13, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot14, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot15, align 8
  %mem115 = alloca i8, i64 16, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot16, align 8
  %v117 = load i64, ptr %slot13, align 8
  %p118 = inttoptr i64 %v117 to ptr
  store i64 0, ptr %p118, align 8, !alias.scope !3, !noalias !4
  %v119 = load i64, ptr %slot2, align 8
  %v120 = load i64, ptr %slot12, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 %v119, ptr %p121, align 8, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot1, align 8
  %p123 = inttoptr i64 %v122 to ptr
  %call124 = call ptr @myl_qbe_heap(ptr %p123) nomerge, !dbg !110
  %calladdr125 = ptrtoint ptr %call124 to i64
  store i64 %calladdr125, ptr %slot17, align 8
  %v126 = load i64, ptr %slot1, align 8
  %p127 = inttoptr i64 %v126 to ptr
  %call128 = call i64 @myl_qbe_region_mark(ptr %p127) nomerge, !dbg !110
  store i64 %call128, ptr %slot18, align 8
  %v129 = load i64, ptr %slot4, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i32 0, ptr %p130, align 4, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot5, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i32 0, ptr %p132, align 4, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i32 0, ptr %p134, align 4, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot7, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i32 0, ptr %p136, align 4, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot8, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i32 0, ptr %p138, align 4, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot5, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i32 2, ptr %p140, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v141 = load i64, ptr %slot12, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld143, ptr %slot19, align 8
  %v144 = load i64, ptr %slot19, align 8
  %v145 = load i64, ptr %slot15, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot15, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot20, align 8
  %v150 = load i64, ptr %slot20, align 8
  %v151 = load i64, ptr %slot9, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot9, align 8
  store i64 %v153, ptr %slot21, align 8
  store i32 0, ptr %slot22, align 8
  %v154 = load i64, ptr %slot6, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i32, ptr %p155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld156, ptr %slot23, align 8
  %v157 = load i32, ptr %slot23, align 8
  %op158 = and i32 %v157, 24
  store i32 %op158, ptr %slot23, align 8
  %v159 = load i32, ptr %slot23, align 8
  %cmp160 = icmp eq i32 %v159, 0
  %cv161 = zext i1 %cmp160 to i32
  store i32 %cv161, ptr %slot24, align 8
  %v162 = load i32, ptr %slot22, align 8
  %v163 = load i32, ptr %slot24, align 8
  %op164 = and i32 %v162, %v163
  store i32 %op164, ptr %slot25, align 8
  %v165 = load i32, ptr %slot25, align 8
  %cv166 = zext i32 %v165 to i64
  %cond167 = icmp ne i64 %cv166, 0
  br i1 %cond167, label %bb_rcprivateown11, label %bb_rcprivateloan11
bb_rcprivateown11:
  %v168 = load i64, ptr %slot10, align 8
  store i64 %v168, ptr %slot26, align 8
  %v169 = load i64, ptr %slot18, align 8
  store i64 %v169, ptr %slot27, align 8
  %v170 = load i64, ptr %slot21, align 8
  %v171 = load i64, ptr %slot26, align 8
  %op172 = sub i64 %v170, %v171
  store i64 %op172, ptr %slot28, align 8
  %v173 = load i64, ptr %slot26, align 8
  %v174 = load i64, ptr %slot21, align 8
  %op175 = sub i64 %v173, %v174
  store i64 %op175, ptr %slot29, align 8
  %v176 = load i64, ptr %slot28, align 8
  %cmp177 = icmp ult i64 %v176, 8
  %cv178 = zext i1 %cmp177 to i32
  store i32 %cv178, ptr %slot30, align 8
  %v179 = load i64, ptr %slot29, align 8
  %cmp180 = icmp ult i64 %v179, 8
  %cv181 = zext i1 %cmp180 to i32
  store i32 %cv181, ptr %slot31, align 8
  %v182 = load i32, ptr %slot30, align 8
  %v183 = load i32, ptr %slot31, align 8
  %op184 = or i32 %v182, %v183
  store i32 %op184, ptr %slot32, align 8
  %v185 = load i32, ptr %slot32, align 8
  %cv186 = zext i32 %v185 to i64
  %cond187 = icmp ne i64 %cv186, 0
  br i1 %cond187, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v188 = load i64, ptr %slot21, align 8
  %p190 = inttoptr i64 %v188 to ptr
  %gep191 = getelementptr i8, ptr %p190, i64 0
  %op189 = ptrtoint ptr %gep191 to i64
  store i64 %op189, ptr %slot33, align 8
  %v192 = load i64, ptr %slot33, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ld194 = load i64, ptr %p193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld194, ptr %slot34, align 8
  %v195 = load i64, ptr %slot34, align 8
  %cmp196 = icmp ne i64 %v195, 0
  %cv197 = zext i1 %cmp196 to i32
  store i32 %cv197, ptr %slot35, align 8
  %v198 = load i32, ptr %slot35, align 8
  %cv199 = zext i32 %v198 to i64
  %cond200 = icmp ne i64 %cv199, 0
  br i1 %cond200, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v201 = load i64, ptr %slot34, align 8
  %op202 = sub i64 %v201, 16
  store i64 %op202, ptr %slot36, align 8
  %v203 = load i64, ptr %slot34, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %rgep205 = getelementptr i8, ptr %p204, i64 -16
  %ld206 = load i64, ptr %rgep205, align 8, !alias.scope !9, !noalias !10
  store i64 %ld206, ptr %slot37, align 8
  %v207 = load i64, ptr %slot37, align 8
  %op208 = and i64 %v207, 5764607523034234881
  store i64 %op208, ptr %slot38, align 8
  %v209 = load i64, ptr %slot38, align 8
  %cmp210 = icmp ne i64 %v209, 0
  %cv211 = zext i1 %cmp210 to i32
  store i32 %cv211, ptr %slot39, align 8
  %v212 = load i32, ptr %slot39, align 8
  %cv213 = zext i32 %v212 to i64
  %cond214 = icmp ne i64 %cv213, 0
  br i1 %cond214, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v215 = load i64, ptr %slot21, align 8
  %v216 = load i64, ptr %slot26, align 8
  %p217 = inttoptr i64 %v215 to ptr
  %p218 = inttoptr i64 %v216 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p218, ptr %p217, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot21, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 0, ptr %p220, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %v221 = load i64, ptr %slot17, align 8
  %v222 = load i64, ptr %slot26, align 8
  %v223 = load i64, ptr %slot21, align 8
  %v224 = load i64, ptr %slot27, align 8
  %cv225 = trunc i64 %v224 to i32
  %call226 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v221, i64 %v222, i64 %v223, i32 %cv225) nomerge, !dbg !112
  store i32 %call226, ptr %slot40, align 8
  %v227 = load i32, ptr %slot40, align 8
  %cv228 = zext i32 %v227 to i64
  %cond229 = icmp ne i64 %cv228, 0
  br i1 %cond229, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v230 = load i64, ptr %slot17, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %call232 = call i32 @myl_rc_take_failure(ptr %p231) nomerge, !dbg !112
  store i32 %call232, ptr %slot41, align 8
  %v233 = load i64, ptr %slot1, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %v235 = load i32, ptr %slot41, align 8
  %call236 = call i32 @myl_qbe_rc_status(ptr %p234, i32 %v235) nomerge, !dbg !112
  store i32 %call236, ptr %slot42, align 8
  br label %bb_failure
bb_rcsuccess29:
  br label %bb_rcmoved14
bb_rcmoved14:
  %v237 = load i64, ptr %slot8, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i32 2, ptr %p238, align 4, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot7, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i32 1, ptr %p240, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateloan11:
  %v241 = load i64, ptr %slot10, align 8
  store i64 %v241, ptr %slot43, align 8
  %v242 = load i64, ptr %slot17, align 8
  %v243 = load i64, ptr %slot43, align 8
  %v244 = load i64, ptr %slot21, align 8
  %call245 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan(i64 %v242, i64 %v243, i64 %v244) nomerge, !dbg !112
  store i32 %call245, ptr %slot44, align 8
  %v246 = load i32, ptr %slot44, align 8
  %cv247 = zext i32 %v246 to i64
  %cond248 = icmp ne i64 %cv247, 0
  br i1 %cond248, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %v249 = load i64, ptr %slot17, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %call251 = call i32 @myl_rc_take_failure(ptr %p250) nomerge, !dbg !112
  store i32 %call251, ptr %slot45, align 8
  %v252 = load i64, ptr %slot1, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %v254 = load i32, ptr %slot45, align 8
  %call255 = call i32 @myl_qbe_rc_status(ptr %p253, i32 %v254) nomerge, !dbg !112
  store i32 %call255, ptr %slot46, align 8
  br label %bb_failure
bb_rcsuccess37:
  %v256 = load i64, ptr %slot8, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i32 2, ptr %p257, align 4, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot8, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i32 16, ptr %p259, align 4, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot7, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i32 1, ptr %p261, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateprepared11:
  %v262 = load i64, ptr %slot4, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i32, ptr %p263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld264, ptr %slot47, align 8
  %v265 = load i32, ptr %slot47, align 8
  %cv266 = zext i32 %v265 to i64
  %cond267 = icmp ne i64 %cv266, 0
  br i1 %cond267, label %bb_rcslotdrop55, label %bb_rcslotdone55
bb_rcslotdrop55:
  %v268 = load i64, ptr %slot4, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i32 0, ptr %p269, align 4, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot13, align 8
  store i64 %v270, ptr %slot48, align 8
  %v271 = load i64, ptr %slot5, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i32, ptr %p272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld273, ptr %slot49, align 8
  %v274 = load i32, ptr %slot49, align 8
  %op275 = and i32 %v274, 28
  store i32 %op275, ptr %slot50, align 8
  %v276 = load i32, ptr %slot50, align 8
  %cv277 = zext i32 %v276 to i64
  %cond278 = icmp ne i64 %cv277, 0
  br i1 %cond278, label %bb_rcslotrole55, label %bb_rcslotowner55
bb_rcslotrole55:
  %v279 = load i64, ptr %slot17, align 8
  store i64 %v279, ptr %slot51, align 8
  %v280 = load i64, ptr %slot51, align 8
  %v281 = load i64, ptr %slot48, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v280, i64 %v281) nomerge, !dbg !112
  br label %bb_rcslotdone55
bb_rcslotowner55:
  %v282 = load i64, ptr %slot17, align 8
  store i64 %v282, ptr %slot52, align 8
  %v283 = load i64, ptr %slot52, align 8
  %v284 = load i64, ptr %slot48, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v283, i64 %v284) nomerge, !dbg !112
  br label %bb_rcslotdone55
bb_rcslotdone55:
  %v285 = load i64, ptr %slot13, align 8
  store i64 %v285, ptr %slot53, align 8
  %v286 = load i64, ptr %slot10, align 8
  store i64 %v286, ptr %slot54, align 8
  %v287 = load i64, ptr %slot54, align 8
  %v288 = load i64, ptr %slot53, align 8
  %p289 = inttoptr i64 %v287 to ptr
  %p290 = inttoptr i64 %v288 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p290, ptr %p289, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot7, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i32 0, ptr %p292, align 4, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot5, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i32 2, ptr %p294, align 4, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot8, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %ld297 = load i32, ptr %p296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld297, ptr %slot55, align 8
  %v298 = load i32, ptr %slot55, align 8
  %v299 = load i64, ptr %slot5, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i32 %v298, ptr %p300, align 4, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot4, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i32 1, ptr %p302, align 4, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot13, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot56, align 8
  %v306 = load i64, ptr %slot13, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i64, ptr %p307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld308, ptr %slot57, align 8
  %v309 = load i64, ptr %slot57, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %call311 = call ptr @myl_native_text_payload(ptr %p310) nomerge, !dbg !114
  %calladdr312 = ptrtoint ptr %call311 to i64
  store i64 %calladdr312, ptr %slot58, align 8
  %v313 = load i64, ptr %slot57, align 8
  %op314 = add i64 %v313, 8
  store i64 %op314, ptr %slot59, align 8
  %v315 = load i64, ptr %slot59, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8
  store i64 %ld317, ptr %slot60, align 8
  %v318 = load i64, ptr %slot58, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %v320 = load i64, ptr %slot60, align 8
  %v321 = load i64, ptr %slot11, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %call323 = call i32 @myl_native_bytes_number_parse(ptr %p319, i64 %v320, i32 0, ptr %p322) nomerge, !dbg !114
  store i32 %call323, ptr %slot61, align 8
  %v324 = load i64, ptr %slot11, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %ld326 = load i64, ptr %p325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld326, ptr %slot62, align 8
  %v327 = load i64, ptr %slot16, align 8
  store i64 %v327, ptr %slot63, align 8
  %v328 = load i64, ptr %slot63, align 8
  %p330 = inttoptr i64 %v328 to ptr
  %gep331 = getelementptr i8, ptr %p330, i64 8
  %op329 = ptrtoint ptr %gep331 to i64
  store i64 %op329, ptr %slot64, align 8
  %v332 = load i32, ptr %slot61, align 8
  %cv333 = zext i32 %v332 to i64
  %cond334 = icmp ne i64 %cv333, 0
  br i1 %cond334, label %bb_some79, label %bb_none79
bb_some79:
  %v335 = load i64, ptr %slot63, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 1, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot62, align 8
  %v338 = load i64, ptr %slot64, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i64 %v337, ptr %p339, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed79
bb_none79:
  %v340 = load i64, ptr %slot63, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i32 0, ptr %p341, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed79
bb_parsed79:
  %v342 = load i64, ptr %slot63, align 8
  %v343 = load i64, ptr %slot15, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 %v342, ptr %p344, align 8, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot15, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot65, align 8
  %v348 = load i64, ptr %slot65, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i32, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %ext351 = zext i32 %ld350 to i64
  store i64 %ext351, ptr %slot66, align 8
  %v352 = load i64, ptr %slot66, align 8
  %cmp353 = icmp eq i64 %v352, 0
  %cv354 = zext i1 %cmp353 to i64
  store i64 %cv354, ptr %slot67, align 8
  %v355 = load i64, ptr %slot67, align 8
  %cond356 = icmp ne i64 %v355, 0
  br i1 %cond356, label %bb_rcarm82, label %bb_rcarmnext82
bb_rcarm82:
  br label %bb_i6
bb_rcarmnext82:
  %v357 = load i64, ptr %slot66, align 8
  %cmp358 = icmp eq i64 %v357, 1
  %cv359 = zext i1 %cmp358 to i64
  store i64 %cv359, ptr %slot68, align 8
  %v360 = load i64, ptr %slot68, align 8
  %cond361 = icmp ne i64 %v360, 0
  br i1 %cond361, label %bb_rcarm83, label %bb_rcarmnext83
bb_rcarm83:
  %v362 = load i64, ptr %slot10, align 8
  store i64 %v362, ptr %slot69, align 8
  %v363 = load i64, ptr %slot65, align 8
  %op364 = add i64 %v363, 8
  store i64 %op364, ptr %slot70, align 8
  %v365 = load i64, ptr %slot18, align 8
  store i64 %v365, ptr %slot71, align 8
  %v366 = load i64, ptr %slot70, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot72, align 8
  %v369 = load i64, ptr %slot72, align 8
  %v370 = load i64, ptr %slot69, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot8, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i32 0, ptr %p373, align 4, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot7, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i32 1, ptr %p375, align 4, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot69, align 8
  %p377 = inttoptr i64 %v376 to ptr
  %ld378 = load i64, ptr %p377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld378, ptr %slot73, align 8
  %v379 = load i64, ptr %slot73, align 8
  %v380 = load i64, ptr %slot14, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 %v379, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot7, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i32 0, ptr %p383, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext83:
  br label %bb_failure
bb_i4:
  %v384 = load i64, ptr %slot14, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot74, align 8
  %v387 = load i64, ptr %slot74, align 8
  %v388 = load i64, ptr %slot15, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot15, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot75, align 8
  %v393 = load i64, ptr %slot4, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %ld395 = load i32, ptr %p394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld395, ptr %slot76, align 8
  %v396 = load i32, ptr %slot76, align 8
  %cv397 = zext i32 %v396 to i64
  %cond398 = icmp ne i64 %cv397, 0
  br i1 %cond398, label %bb_rcslotdrop99, label %bb_rcslotdone99
bb_rcslotdrop99:
  %v399 = load i64, ptr %slot4, align 8
  %p400 = inttoptr i64 %v399 to ptr
  store i32 0, ptr %p400, align 4, !alias.scope !3, !noalias !4
  %v401 = load i64, ptr %slot13, align 8
  store i64 %v401, ptr %slot77, align 8
  %v402 = load i64, ptr %slot5, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i32, ptr %p403, align 4, !alias.scope !3, !noalias !4
  store i32 %ld404, ptr %slot78, align 8
  %v405 = load i32, ptr %slot78, align 8
  %op406 = and i32 %v405, 28
  store i32 %op406, ptr %slot79, align 8
  %v407 = load i32, ptr %slot79, align 8
  %cv408 = zext i32 %v407 to i64
  %cond409 = icmp ne i64 %cv408, 0
  br i1 %cond409, label %bb_rcslotrole99, label %bb_rcslotowner99
bb_rcslotrole99:
  %v410 = load i64, ptr %slot17, align 8
  store i64 %v410, ptr %slot80, align 8
  %v411 = load i64, ptr %slot80, align 8
  %v412 = load i64, ptr %slot77, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v411, i64 %v412) nomerge, !dbg !116
  br label %bb_rcslotdone99
bb_rcslotowner99:
  %v413 = load i64, ptr %slot17, align 8
  store i64 %v413, ptr %slot81, align 8
  %v414 = load i64, ptr %slot81, align 8
  %v415 = load i64, ptr %slot77, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v414, i64 %v415) nomerge, !dbg !116
  br label %bb_rcslotdone99
bb_rcslotdone99:
  %v416 = load i64, ptr %slot75, align 8
  ret i64 %v416
bb_i6:
  %v417 = load i64, ptr %slot15, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i64 0, ptr %p418, align 8, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot15, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %ld421 = load i64, ptr %p420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld421, ptr %slot82, align 8
  %v422 = load i64, ptr %slot4, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i32, ptr %p423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld424, ptr %slot83, align 8
  %v425 = load i32, ptr %slot83, align 8
  %cv426 = zext i32 %v425 to i64
  %cond427 = icmp ne i64 %cv426, 0
  br i1 %cond427, label %bb_rcslotdrop121, label %bb_rcslotdone121
bb_rcslotdrop121:
  %v428 = load i64, ptr %slot4, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i32 0, ptr %p429, align 4, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot13, align 8
  store i64 %v430, ptr %slot84, align 8
  %v431 = load i64, ptr %slot5, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i32, ptr %p432, align 4, !alias.scope !3, !noalias !4
  store i32 %ld433, ptr %slot85, align 8
  %v434 = load i32, ptr %slot85, align 8
  %op435 = and i32 %v434, 28
  store i32 %op435, ptr %slot86, align 8
  %v436 = load i32, ptr %slot86, align 8
  %cv437 = zext i32 %v436 to i64
  %cond438 = icmp ne i64 %cv437, 0
  br i1 %cond438, label %bb_rcslotrole121, label %bb_rcslotowner121
bb_rcslotrole121:
  %v439 = load i64, ptr %slot17, align 8
  store i64 %v439, ptr %slot87, align 8
  %v440 = load i64, ptr %slot87, align 8
  %v441 = load i64, ptr %slot84, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v440, i64 %v441) nomerge, !dbg !118
  br label %bb_rcslotdone121
bb_rcslotowner121:
  %v442 = load i64, ptr %slot17, align 8
  store i64 %v442, ptr %slot88, align 8
  %v443 = load i64, ptr %slot88, align 8
  %v444 = load i64, ptr %slot84, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v443, i64 %v444) nomerge, !dbg !118
  br label %bb_rcslotdone121
bb_rcslotdone121:
  %v445 = load i64, ptr %slot82, align 8
  ret i64 %v445
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", linkageName: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10980889420309157548, i64 0, !"myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
