target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i32, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v175 = load i64, ptr %slot1, align 8
  %op176 = add i64 %v175, 32
  store i64 %op176, ptr %slot3, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot4, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot5, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot6, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot7, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot8, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot9, align 8
  %mem189 = alloca i8, i64 16, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot10, align 8
  %mem191 = alloca i8, i64 16, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot11, align 8
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot12, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot13, align 8
  %mem197 = alloca i8, i64 8, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot14, align 8
  %mem199 = alloca i8, i64 8, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot15, align 8
  %mem201 = alloca i8, i64 16, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot16, align 8
  %v203 = load i64, ptr %slot13, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot2, align 8
  %v206 = load i64, ptr %slot12, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot1, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %call210 = call ptr @myl_qbe_heap(ptr %p209) nomerge, !dbg !110
  %calladdr211 = ptrtoint ptr %call210 to i64
  store i64 %calladdr211, ptr %slot17, align 8
  %v212 = load i64, ptr %slot1, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %call214 = call i64 @myl_qbe_region_mark(ptr %p213) nomerge, !dbg !110
  store i64 %call214, ptr %slot18, align 8
  %v215 = load i64, ptr %slot4, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 0, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot5, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i32 0, ptr %p218, align 4, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot6, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 0, ptr %p220, align 4, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot7, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i32 0, ptr %p222, align 4, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot8, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i32 0, ptr %p224, align 4, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot5, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i32 2, ptr %p226, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v227 = load i64, ptr %slot12, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot19, align 8
  %v230 = load i64, ptr %slot19, align 8
  %v231 = load i64, ptr %slot15, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 %v230, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot15, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot20, align 8
  %v236 = load i64, ptr %slot20, align 8
  %v237 = load i64, ptr %slot9, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot9, align 8
  store i64 %v239, ptr %slot21, align 8
  store i32 0, ptr %slot22, align 8
  %v240 = load i64, ptr %slot6, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i32, ptr %p241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld242, ptr %slot23, align 8
  %v243 = load i32, ptr %slot23, align 8
  %op244 = and i32 %v243, 24
  store i32 %op244, ptr %slot23, align 8
  %v245 = load i32, ptr %slot23, align 8
  %cmp246 = icmp eq i32 %v245, 0
  %cv247 = zext i1 %cmp246 to i32
  store i32 %cv247, ptr %slot24, align 8
  %v248 = load i32, ptr %slot22, align 8
  %v249 = load i32, ptr %slot24, align 8
  %op250 = and i32 %v248, %v249
  store i32 %op250, ptr %slot25, align 8
  %v251 = load i32, ptr %slot25, align 8
  %cv252 = zext i32 %v251 to i64
  %cond253 = icmp ne i64 %cv252, 0
  br i1 %cond253, label %bb_rcprivateown11, label %bb_rcprivateloan11
bb_rcprivateown11:
  %v254 = load i64, ptr %slot10, align 8
  store i64 %v254, ptr %slot26, align 8
  %v255 = load i64, ptr %slot18, align 8
  store i64 %v255, ptr %slot27, align 8
  %v256 = load i64, ptr %slot21, align 8
  %v257 = load i64, ptr %slot26, align 8
  %op258 = sub i64 %v256, %v257
  store i64 %op258, ptr %slot28, align 8
  %v259 = load i64, ptr %slot26, align 8
  %v260 = load i64, ptr %slot21, align 8
  %op261 = sub i64 %v259, %v260
  store i64 %op261, ptr %slot29, align 8
  %v262 = load i64, ptr %slot28, align 8
  %cmp263 = icmp ult i64 %v262, 8
  %cv264 = zext i1 %cmp263 to i32
  store i32 %cv264, ptr %slot30, align 8
  %v265 = load i64, ptr %slot29, align 8
  %cmp266 = icmp ult i64 %v265, 8
  %cv267 = zext i1 %cmp266 to i32
  store i32 %cv267, ptr %slot31, align 8
  %v268 = load i32, ptr %slot30, align 8
  %v269 = load i32, ptr %slot31, align 8
  %op270 = or i32 %v268, %v269
  store i32 %op270, ptr %slot32, align 8
  %v271 = load i32, ptr %slot32, align 8
  %cv272 = zext i32 %v271 to i64
  %cond273 = icmp ne i64 %cv272, 0
  br i1 %cond273, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v274 = load i64, ptr %slot21, align 8
  %p276 = inttoptr i64 %v274 to ptr
  %gep277 = getelementptr i8, ptr %p276, i64 0
  %op275 = ptrtoint ptr %gep277 to i64
  store i64 %op275, ptr %slot33, align 8
  %v278 = load i64, ptr %slot33, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot34, align 8
  %v281 = load i64, ptr %slot34, align 8
  %cmp282 = icmp ne i64 %v281, 0
  %cv283 = zext i1 %cmp282 to i32
  store i32 %cv283, ptr %slot35, align 8
  %v284 = load i32, ptr %slot35, align 8
  %cv285 = zext i32 %v284 to i64
  %cond286 = icmp ne i64 %cv285, 0
  br i1 %cond286, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v287 = load i64, ptr %slot34, align 8
  %op288 = sub i64 %v287, 16
  store i64 %op288, ptr %slot36, align 8
  %v289 = load i64, ptr %slot34, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %rgep291 = getelementptr i8, ptr %p290, i64 -16
  %ld292 = load i64, ptr %rgep291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld292, ptr %slot37, align 8
  %v293 = load i64, ptr %slot37, align 8
  %op294 = and i64 %v293, 5764607523034234881
  store i64 %op294, ptr %slot38, align 8
  %v295 = load i64, ptr %slot38, align 8
  %cmp296 = icmp ne i64 %v295, 0
  %cv297 = zext i1 %cmp296 to i32
  store i32 %cv297, ptr %slot39, align 8
  %v298 = load i32, ptr %slot39, align 8
  %cv299 = zext i32 %v298 to i64
  %cond300 = icmp ne i64 %cv299, 0
  br i1 %cond300, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v301 = load i64, ptr %slot21, align 8
  %v302 = load i64, ptr %slot26, align 8
  %p303 = inttoptr i64 %v301 to ptr
  %p304 = inttoptr i64 %v302 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p304, ptr %p303, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot21, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i64 0, ptr %p306, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %v307 = load i64, ptr %slot17, align 8
  %v308 = load i64, ptr %slot26, align 8
  %v309 = load i64, ptr %slot21, align 8
  %v310 = load i64, ptr %slot27, align 8
  %cv311 = trunc i64 %v310 to i32
  %call312 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v307, i64 %v308, i64 %v309, i32 %cv311) nomerge, !dbg !112
  store i32 %call312, ptr %slot40, align 8
  %v313 = load i32, ptr %slot40, align 8
  %cv314 = zext i32 %v313 to i64
  %cond315 = icmp ne i64 %cv314, 0
  br i1 %cond315, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v316 = load i64, ptr %slot17, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %call318 = call i32 @myl_rc_take_failure(ptr %p317) nomerge, !dbg !112
  store i32 %call318, ptr %slot41, align 8
  %v319 = load i64, ptr %slot1, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %v321 = load i32, ptr %slot41, align 8
  %call322 = call i32 @myl_qbe_rc_status(ptr %p320, i32 %v321) nomerge, !dbg !112
  store i32 %call322, ptr %slot42, align 8
  br label %bb_failure
bb_rcsuccess29:
  br label %bb_rcmoved14
bb_rcmoved14:
  %v323 = load i64, ptr %slot8, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 2, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot7, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 1, ptr %p326, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateloan11:
  %v327 = load i64, ptr %slot10, align 8
  store i64 %v327, ptr %slot43, align 8
  %v328 = load i64, ptr %slot21, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot44, align 8
  %v331 = load i64, ptr %slot44, align 8
  %cmp332 = icmp ne i64 %v331, 0
  %cv333 = zext i1 %cmp332 to i32
  store i32 %cv333, ptr %slot45, align 8
  %v334 = load i32, ptr %slot45, align 8
  %cv335 = zext i32 %v334 to i64
  %cond336 = icmp ne i64 %cv335, 0
  br i1 %cond336, label %bb_rcgnn37, label %bb_rcgstore37
bb_rcgnn37:
  %v337 = load i64, ptr %slot44, align 8
  %op338 = sub i64 %v337, 16
  store i64 %op338, ptr %slot46, align 8
  %v339 = load i64, ptr %slot44, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %rgep341 = getelementptr i8, ptr %p340, i64 -16
  %ld342 = load i64, ptr %rgep341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld342, ptr %slot47, align 8
  %v343 = load i64, ptr %slot47, align 8
  %op344 = and i64 %v343, 4611686018427387906
  store i64 %op344, ptr %slot48, align 8
  %v345 = load i64, ptr %slot48, align 8
  %cmp346 = icmp ne i64 %v345, 0
  %cv347 = zext i1 %cmp346 to i32
  store i32 %cv347, ptr %slot49, align 8
  %v348 = load i32, ptr %slot49, align 8
  %cv349 = zext i32 %v348 to i64
  %cond350 = icmp ne i64 %cv349, 0
  br i1 %cond350, label %bb_rcgstore37, label %bb_rcginc37
bb_rcginc37:
  %v351 = load i64, ptr %slot44, align 8
  %op352 = sub i64 %v351, 24
  store i64 %op352, ptr %slot50, align 8
  %v353 = load i64, ptr %slot44, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %rgep355 = getelementptr i8, ptr %p354, i64 -24
  %ld356 = load i64, ptr %rgep355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld356, ptr %slot51, align 8
  %v357 = load i64, ptr %slot51, align 8
  %op358 = add i64 %v357, 1
  store i64 %op358, ptr %slot52, align 8
  %v359 = load i64, ptr %slot52, align 8
  %cmp360 = icmp eq i64 %v359, 0
  %cv361 = zext i1 %cmp360 to i32
  store i32 %cv361, ptr %slot53, align 8
  %v362 = load i32, ptr %slot53, align 8
  %cv363 = zext i32 %v362 to i64
  %cond364 = icmp ne i64 %cv363, 0
  br i1 %cond364, label %bb_rcglimit37, label %bb_rcgcapacity37
bb_rcglimit37:
  %v365 = load i64, ptr %slot1, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %call367 = call i32 @myl_qbe_rc_status(ptr %p366, i32 2) nomerge, !dbg !112
  store i32 %call367, ptr %slot54, align 8
  br label %bb_failure
bb_rcgcapacity37:
  %v368 = load i64, ptr %slot52, align 8
  %v369 = load i64, ptr %slot44, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %rgep371 = getelementptr i8, ptr %p370, i64 -24
  store i64 %v368, ptr %rgep371, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore37
bb_rcgstore37:
  %v372 = load i64, ptr %slot44, align 8
  %v373 = load i64, ptr %slot43, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i64 %v372, ptr %p374, align 8, !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot8, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i32 2, ptr %p376, align 4, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot8, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i32 16, ptr %p378, align 4, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot7, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i32 1, ptr %p380, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateprepared11:
  %v381 = load i64, ptr %slot4, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i32, ptr %p382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld383, ptr %slot55, align 8
  %v384 = load i32, ptr %slot55, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v387 = load i64, ptr %slot4, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i32 0, ptr %p388, align 4, !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot13, align 8
  store i64 %v389, ptr %slot56, align 8
  %v390 = load i64, ptr %slot5, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i32, ptr %p391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld392, ptr %slot57, align 8
  %v393 = load i32, ptr %slot57, align 8
  %op394 = and i32 %v393, 28
  store i32 %op394, ptr %slot58, align 8
  %v395 = load i32, ptr %slot58, align 8
  %cv396 = zext i32 %v395 to i64
  %cond397 = icmp ne i64 %cv396, 0
  br i1 %cond397, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v398 = load i64, ptr %slot17, align 8
  store i64 %v398, ptr %slot59, align 8
  %v399 = load i64, ptr %slot56, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot60, align 8
  %v402 = load i64, ptr %slot60, align 8
  %cmp403 = icmp ne i64 %v402, 0
  %cv404 = zext i1 %cmp403 to i32
  store i32 %cv404, ptr %slot61, align 8
  %v405 = load i32, ptr %slot61, align 8
  %cv406 = zext i32 %v405 to i64
  %cond407 = icmp ne i64 %cv406, 0
  br i1 %cond407, label %bb_rcgnn107, label %bb_rcgdone107
bb_rcgnn107:
  %v408 = load i64, ptr %slot60, align 8
  %op409 = sub i64 %v408, 16
  store i64 %op409, ptr %slot62, align 8
  %v410 = load i64, ptr %slot60, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %rgep412 = getelementptr i8, ptr %p411, i64 -16
  %ld413 = load i64, ptr %rgep412, align 8, !alias.scope !9, !noalias !10
  store i64 %ld413, ptr %slot63, align 8
  %v414 = load i64, ptr %slot63, align 8
  %op415 = and i64 %v414, 4611686018427387906
  store i64 %op415, ptr %slot64, align 8
  %v416 = load i64, ptr %slot64, align 8
  %cmp417 = icmp ne i64 %v416, 0
  %cv418 = zext i1 %cmp417 to i32
  store i32 %cv418, ptr %slot65, align 8
  %v419 = load i32, ptr %slot65, align 8
  %cv420 = zext i32 %v419 to i64
  %cond421 = icmp ne i64 %cv420, 0
  br i1 %cond421, label %bb_rcgclear107, label %bb_rcgcounted107
bb_rcgcounted107:
  %v422 = load i64, ptr %slot60, align 8
  %op423 = sub i64 %v422, 24
  store i64 %op423, ptr %slot66, align 8
  %v424 = load i64, ptr %slot60, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %rgep426 = getelementptr i8, ptr %p425, i64 -24
  %ld427 = load i64, ptr %rgep426, align 8, !alias.scope !9, !noalias !10
  store i64 %ld427, ptr %slot67, align 8
  %v428 = load i64, ptr %slot67, align 8
  %op429 = sub i64 %v428, 1
  store i64 %op429, ptr %slot68, align 8
  %v430 = load i64, ptr %slot68, align 8
  %cmp431 = icmp eq i64 %v430, 0
  %cv432 = zext i1 %cmp431 to i32
  store i32 %cv432, ptr %slot69, align 8
  %v433 = load i32, ptr %slot69, align 8
  %cv434 = zext i32 %v433 to i64
  %cond435 = icmp ne i64 %cv434, 0
  br i1 %cond435, label %bb_rcglast107, label %bb_rcgdec107
bb_rcglast107:
  %v436 = load i64, ptr %slot60, align 8
  %op437 = sub i64 %v436, 32
  store i64 %op437, ptr %slot70, align 8
  %v438 = load i64, ptr %slot60, align 8
  %p439 = inttoptr i64 %v438 to ptr
  %rgep440 = getelementptr i8, ptr %p439, i64 -32
  %ld441 = load i64, ptr %rgep440, align 8, !alias.scope !9, !noalias !10
  store i64 %ld441, ptr %slot71, align 8
  %v442 = load i64, ptr %slot71, align 8
  %cmp443 = icmp ne i64 %v442, 0
  %cv444 = zext i1 %cmp443 to i32
  store i32 %cv444, ptr %slot72, align 8
  %v445 = load i32, ptr %slot72, align 8
  %cv446 = zext i32 %v445 to i64
  %cond447 = icmp ne i64 %cv446, 0
  br i1 %cond447, label %bb_rcgdec107, label %bb_rcgslow107
bb_rcgslow107:
  %v448 = load i64, ptr %slot59, align 8
  %v449 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v448, i64 %v449) nomerge, !dbg !112
  br label %bb_rcgdone107
bb_rcgdec107:
  %v450 = load i64, ptr %slot68, align 8
  %v451 = load i64, ptr %slot60, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %rgep453 = getelementptr i8, ptr %p452, i64 -24
  store i64 %v450, ptr %rgep453, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear107
bb_rcgclear107:
  %v454 = load i64, ptr %slot56, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i64 0, ptr %p455, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone107
bb_rcgdone107:
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v456 = load i64, ptr %slot17, align 8
  store i64 %v456, ptr %slot73, align 8
  %v457 = load i64, ptr %slot56, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot74, align 8
  %v460 = load i64, ptr %slot74, align 8
  %cmp461 = icmp ne i64 %v460, 0
  %cv462 = zext i1 %cmp461 to i32
  store i32 %cv462, ptr %slot75, align 8
  %v463 = load i32, ptr %slot75, align 8
  %cv464 = zext i32 %v463 to i64
  %cond465 = icmp ne i64 %cv464, 0
  br i1 %cond465, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v466 = load i64, ptr %slot74, align 8
  %op467 = sub i64 %v466, 16
  store i64 %op467, ptr %slot76, align 8
  %v468 = load i64, ptr %slot74, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %rgep470 = getelementptr i8, ptr %p469, i64 -16
  %ld471 = load i64, ptr %rgep470, align 8, !alias.scope !9, !noalias !10
  store i64 %ld471, ptr %slot77, align 8
  %v472 = load i64, ptr %slot77, align 8
  %op473 = and i64 %v472, 4611686018427387906
  store i64 %op473, ptr %slot78, align 8
  %v474 = load i64, ptr %slot78, align 8
  %cmp475 = icmp ne i64 %v474, 0
  %cv476 = zext i1 %cmp475 to i32
  store i32 %cv476, ptr %slot79, align 8
  %v477 = load i32, ptr %slot79, align 8
  %cv478 = zext i32 %v477 to i64
  %cond479 = icmp ne i64 %cv478, 0
  br i1 %cond479, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v480 = load i64, ptr %slot74, align 8
  %op481 = sub i64 %v480, 32
  store i64 %op481, ptr %slot80, align 8
  %v482 = load i64, ptr %slot74, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %rgep484 = getelementptr i8, ptr %p483, i64 -32
  %ld485 = load i64, ptr %rgep484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld485, ptr %slot81, align 8
  %v486 = load i64, ptr %slot81, align 8
  %op487 = sub i64 %v486, 1
  store i64 %op487, ptr %slot82, align 8
  %v488 = load i64, ptr %slot82, align 8
  %cmp489 = icmp eq i64 %v488, 0
  %cv490 = zext i1 %cmp489 to i32
  store i32 %cv490, ptr %slot83, align 8
  %v491 = load i32, ptr %slot83, align 8
  %cv492 = zext i32 %v491 to i64
  %cond493 = icmp ne i64 %cv492, 0
  br i1 %cond493, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v494 = load i64, ptr %slot74, align 8
  %op495 = sub i64 %v494, 24
  store i64 %op495, ptr %slot84, align 8
  %v496 = load i64, ptr %slot74, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %rgep498 = getelementptr i8, ptr %p497, i64 -24
  %ld499 = load i64, ptr %rgep498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld499, ptr %slot85, align 8
  %v500 = load i64, ptr %slot85, align 8
  %cmp501 = icmp ne i64 %v500, 0
  %cv502 = zext i1 %cmp501 to i32
  store i32 %cv502, ptr %slot86, align 8
  %v503 = load i32, ptr %slot86, align 8
  %cv504 = zext i32 %v503 to i64
  %cond505 = icmp ne i64 %cv504, 0
  br i1 %cond505, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v506 = load i64, ptr %slot73, align 8
  %v507 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v506, i64 %v507) nomerge, !dbg !112
  br label %bb_rcgdone122
bb_rcgdec122:
  %v508 = load i64, ptr %slot82, align 8
  %v509 = load i64, ptr %slot74, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %rgep511 = getelementptr i8, ptr %p510, i64 -32
  store i64 %v508, ptr %rgep511, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v512 = load i64, ptr %slot56, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 0, ptr %p513, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v514 = load i64, ptr %slot13, align 8
  store i64 %v514, ptr %slot87, align 8
  %v515 = load i64, ptr %slot10, align 8
  store i64 %v515, ptr %slot88, align 8
  %v516 = load i64, ptr %slot88, align 8
  %v517 = load i64, ptr %slot87, align 8
  %p518 = inttoptr i64 %v516 to ptr
  %p519 = inttoptr i64 %v517 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p519, ptr %p518, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot7, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 0, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot5, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 2, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot8, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ld526 = load i32, ptr %p525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld526, ptr %slot89, align 8
  %v527 = load i32, ptr %slot89, align 8
  %v528 = load i64, ptr %slot5, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i32 %v527, ptr %p529, align 4, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot4, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 1, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot13, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot90, align 8
  %v535 = load i64, ptr %slot13, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot91, align 8
  %v538 = load i64, ptr %slot91, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %call540 = call ptr @myl_native_text_payload(ptr %p539) nomerge, !dbg !114
  %calladdr541 = ptrtoint ptr %call540 to i64
  store i64 %calladdr541, ptr %slot92, align 8
  %v542 = load i64, ptr %slot91, align 8
  %op543 = add i64 %v542, 8
  store i64 %op543, ptr %slot93, align 8
  %v544 = load i64, ptr %slot93, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8
  store i64 %ld546, ptr %slot94, align 8
  %v547 = load i64, ptr %slot92, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %v549 = load i64, ptr %slot94, align 8
  %v550 = load i64, ptr %slot11, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %call552 = call i32 @myl_native_bytes_number_parse(ptr %p548, i64 %v549, i32 0, ptr %p551) nomerge, !dbg !114
  store i32 %call552, ptr %slot95, align 8
  %v553 = load i64, ptr %slot11, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot96, align 8
  %v556 = load i64, ptr %slot16, align 8
  store i64 %v556, ptr %slot97, align 8
  %v557 = load i64, ptr %slot97, align 8
  %p559 = inttoptr i64 %v557 to ptr
  %gep560 = getelementptr i8, ptr %p559, i64 8
  %op558 = ptrtoint ptr %gep560 to i64
  store i64 %op558, ptr %slot98, align 8
  %v561 = load i32, ptr %slot95, align 8
  %cv562 = zext i32 %v561 to i64
  %cond563 = icmp ne i64 %cv562, 0
  br i1 %cond563, label %bb_some143, label %bb_none143
bb_some143:
  %v564 = load i64, ptr %slot97, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i32 1, ptr %p565, align 4, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot96, align 8
  %v567 = load i64, ptr %slot98, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_none143:
  %v569 = load i64, ptr %slot97, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 0, ptr %p570, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_parsed143:
  %v571 = load i64, ptr %slot97, align 8
  %v572 = load i64, ptr %slot15, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i64 %v571, ptr %p573, align 8, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot15, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i64, ptr %p575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot99, align 8
  %v577 = load i64, ptr %slot99, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i32, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %ext580 = zext i32 %ld579 to i64
  store i64 %ext580, ptr %slot100, align 8
  %v581 = load i64, ptr %slot100, align 8
  %cmp582 = icmp eq i64 %v581, 0
  %cv583 = zext i1 %cmp582 to i64
  store i64 %cv583, ptr %slot101, align 8
  %v584 = load i64, ptr %slot101, align 8
  %cond585 = icmp ne i64 %v584, 0
  br i1 %cond585, label %bb_rcarm146, label %bb_rcarmnext146
bb_rcarm146:
  br label %bb_i6
bb_rcarmnext146:
  %v586 = load i64, ptr %slot100, align 8
  %cmp587 = icmp eq i64 %v586, 1
  %cv588 = zext i1 %cmp587 to i64
  store i64 %cv588, ptr %slot102, align 8
  %v589 = load i64, ptr %slot102, align 8
  %cond590 = icmp ne i64 %v589, 0
  br i1 %cond590, label %bb_rcarm147, label %bb_rcarmnext147
bb_rcarm147:
  %v591 = load i64, ptr %slot10, align 8
  store i64 %v591, ptr %slot103, align 8
  %v592 = load i64, ptr %slot99, align 8
  %op593 = add i64 %v592, 8
  store i64 %op593, ptr %slot104, align 8
  %v594 = load i64, ptr %slot18, align 8
  store i64 %v594, ptr %slot105, align 8
  %v595 = load i64, ptr %slot104, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot106, align 8
  %v598 = load i64, ptr %slot106, align 8
  %v599 = load i64, ptr %slot103, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i64 %v598, ptr %p600, align 8, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot8, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i32 0, ptr %p602, align 4, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot7, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i32 1, ptr %p604, align 4, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot103, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %ld607 = load i64, ptr %p606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld607, ptr %slot107, align 8
  %v608 = load i64, ptr %slot107, align 8
  %v609 = load i64, ptr %slot14, align 8
  %p610 = inttoptr i64 %v609 to ptr
  store i64 %v608, ptr %p610, align 8, !alias.scope !3, !noalias !4
  %v611 = load i64, ptr %slot7, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i32 0, ptr %p612, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext147:
  br label %bb_failure
bb_i4:
  %v613 = load i64, ptr %slot14, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %ld615 = load i64, ptr %p614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld615, ptr %slot108, align 8
  %v616 = load i64, ptr %slot108, align 8
  %v617 = load i64, ptr %slot15, align 8
  %p618 = inttoptr i64 %v617 to ptr
  store i64 %v616, ptr %p618, align 8, !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot15, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld621, ptr %slot109, align 8
  %v622 = load i64, ptr %slot4, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i32, ptr %p623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld624, ptr %slot110, align 8
  %v625 = load i32, ptr %slot110, align 8
  %cv626 = zext i32 %v625 to i64
  %cond627 = icmp ne i64 %cv626, 0
  br i1 %cond627, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v628 = load i64, ptr %slot4, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i32 0, ptr %p629, align 4, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot13, align 8
  store i64 %v630, ptr %slot111, align 8
  %v631 = load i64, ptr %slot5, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i32, ptr %p632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld633, ptr %slot112, align 8
  %v634 = load i32, ptr %slot112, align 8
  %op635 = and i32 %v634, 28
  store i32 %op635, ptr %slot113, align 8
  %v636 = load i32, ptr %slot113, align 8
  %cv637 = zext i32 %v636 to i64
  %cond638 = icmp ne i64 %cv637, 0
  br i1 %cond638, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v639 = load i64, ptr %slot17, align 8
  store i64 %v639, ptr %slot114, align 8
  %v640 = load i64, ptr %slot111, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot115, align 8
  %v643 = load i64, ptr %slot115, align 8
  %cmp644 = icmp ne i64 %v643, 0
  %cv645 = zext i1 %cmp644 to i32
  store i32 %cv645, ptr %slot116, align 8
  %v646 = load i32, ptr %slot116, align 8
  %cv647 = zext i32 %v646 to i64
  %cond648 = icmp ne i64 %cv647, 0
  br i1 %cond648, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v649 = load i64, ptr %slot115, align 8
  %op650 = sub i64 %v649, 16
  store i64 %op650, ptr %slot117, align 8
  %v651 = load i64, ptr %slot115, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %rgep653 = getelementptr i8, ptr %p652, i64 -16
  %ld654 = load i64, ptr %rgep653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld654, ptr %slot118, align 8
  %v655 = load i64, ptr %slot118, align 8
  %op656 = and i64 %v655, 4611686018427387906
  store i64 %op656, ptr %slot119, align 8
  %v657 = load i64, ptr %slot119, align 8
  %cmp658 = icmp ne i64 %v657, 0
  %cv659 = zext i1 %cmp658 to i32
  store i32 %cv659, ptr %slot120, align 8
  %v660 = load i32, ptr %slot120, align 8
  %cv661 = zext i32 %v660 to i64
  %cond662 = icmp ne i64 %cv661, 0
  br i1 %cond662, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v663 = load i64, ptr %slot115, align 8
  %op664 = sub i64 %v663, 24
  store i64 %op664, ptr %slot121, align 8
  %v665 = load i64, ptr %slot115, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %rgep667 = getelementptr i8, ptr %p666, i64 -24
  %ld668 = load i64, ptr %rgep667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld668, ptr %slot122, align 8
  %v669 = load i64, ptr %slot122, align 8
  %op670 = sub i64 %v669, 1
  store i64 %op670, ptr %slot123, align 8
  %v671 = load i64, ptr %slot123, align 8
  %cmp672 = icmp eq i64 %v671, 0
  %cv673 = zext i1 %cmp672 to i32
  store i32 %cv673, ptr %slot124, align 8
  %v674 = load i32, ptr %slot124, align 8
  %cv675 = zext i32 %v674 to i64
  %cond676 = icmp ne i64 %cv675, 0
  br i1 %cond676, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v677 = load i64, ptr %slot115, align 8
  %op678 = sub i64 %v677, 32
  store i64 %op678, ptr %slot125, align 8
  %v679 = load i64, ptr %slot115, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %rgep681 = getelementptr i8, ptr %p680, i64 -32
  %ld682 = load i64, ptr %rgep681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld682, ptr %slot126, align 8
  %v683 = load i64, ptr %slot126, align 8
  %cmp684 = icmp ne i64 %v683, 0
  %cv685 = zext i1 %cmp684 to i32
  store i32 %cv685, ptr %slot127, align 8
  %v686 = load i32, ptr %slot127, align 8
  %cv687 = zext i32 %v686 to i64
  %cond688 = icmp ne i64 %cv687, 0
  br i1 %cond688, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v689 = load i64, ptr %slot114, align 8
  %v690 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v689, i64 %v690) nomerge, !dbg !116
  br label %bb_rcgdone179
bb_rcgdec179:
  %v691 = load i64, ptr %slot123, align 8
  %v692 = load i64, ptr %slot115, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %rgep694 = getelementptr i8, ptr %p693, i64 -24
  store i64 %v691, ptr %rgep694, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v695 = load i64, ptr %slot111, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 0, ptr %p696, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v697 = load i64, ptr %slot17, align 8
  store i64 %v697, ptr %slot128, align 8
  %v698 = load i64, ptr %slot111, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot129, align 8
  %v701 = load i64, ptr %slot129, align 8
  %cmp702 = icmp ne i64 %v701, 0
  %cv703 = zext i1 %cmp702 to i32
  store i32 %cv703, ptr %slot130, align 8
  %v704 = load i32, ptr %slot130, align 8
  %cv705 = zext i32 %v704 to i64
  %cond706 = icmp ne i64 %cv705, 0
  br i1 %cond706, label %bb_rcgnn194, label %bb_rcgdone194
bb_rcgnn194:
  %v707 = load i64, ptr %slot129, align 8
  %op708 = sub i64 %v707, 16
  store i64 %op708, ptr %slot131, align 8
  %v709 = load i64, ptr %slot129, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %rgep711 = getelementptr i8, ptr %p710, i64 -16
  %ld712 = load i64, ptr %rgep711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld712, ptr %slot132, align 8
  %v713 = load i64, ptr %slot132, align 8
  %op714 = and i64 %v713, 4611686018427387906
  store i64 %op714, ptr %slot133, align 8
  %v715 = load i64, ptr %slot133, align 8
  %cmp716 = icmp ne i64 %v715, 0
  %cv717 = zext i1 %cmp716 to i32
  store i32 %cv717, ptr %slot134, align 8
  %v718 = load i32, ptr %slot134, align 8
  %cv719 = zext i32 %v718 to i64
  %cond720 = icmp ne i64 %cv719, 0
  br i1 %cond720, label %bb_rcgclear194, label %bb_rcgcounted194
bb_rcgcounted194:
  %v721 = load i64, ptr %slot129, align 8
  %op722 = sub i64 %v721, 32
  store i64 %op722, ptr %slot135, align 8
  %v723 = load i64, ptr %slot129, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %rgep725 = getelementptr i8, ptr %p724, i64 -32
  %ld726 = load i64, ptr %rgep725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld726, ptr %slot136, align 8
  %v727 = load i64, ptr %slot136, align 8
  %op728 = sub i64 %v727, 1
  store i64 %op728, ptr %slot137, align 8
  %v729 = load i64, ptr %slot137, align 8
  %cmp730 = icmp eq i64 %v729, 0
  %cv731 = zext i1 %cmp730 to i32
  store i32 %cv731, ptr %slot138, align 8
  %v732 = load i32, ptr %slot138, align 8
  %cv733 = zext i32 %v732 to i64
  %cond734 = icmp ne i64 %cv733, 0
  br i1 %cond734, label %bb_rcglast194, label %bb_rcgdec194
bb_rcglast194:
  %v735 = load i64, ptr %slot129, align 8
  %op736 = sub i64 %v735, 24
  store i64 %op736, ptr %slot139, align 8
  %v737 = load i64, ptr %slot129, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %rgep739 = getelementptr i8, ptr %p738, i64 -24
  %ld740 = load i64, ptr %rgep739, align 8, !alias.scope !9, !noalias !10
  store i64 %ld740, ptr %slot140, align 8
  %v741 = load i64, ptr %slot140, align 8
  %cmp742 = icmp ne i64 %v741, 0
  %cv743 = zext i1 %cmp742 to i32
  store i32 %cv743, ptr %slot141, align 8
  %v744 = load i32, ptr %slot141, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcgdec194, label %bb_rcgslow194
bb_rcgslow194:
  %v747 = load i64, ptr %slot128, align 8
  %v748 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v747, i64 %v748) nomerge, !dbg !116
  br label %bb_rcgdone194
bb_rcgdec194:
  %v749 = load i64, ptr %slot137, align 8
  %v750 = load i64, ptr %slot129, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %rgep752 = getelementptr i8, ptr %p751, i64 -32
  store i64 %v749, ptr %rgep752, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear194
bb_rcgclear194:
  %v753 = load i64, ptr %slot111, align 8
  %p754 = inttoptr i64 %v753 to ptr
  store i64 0, ptr %p754, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone194
bb_rcgdone194:
  br label %bb_rcslotdone163
bb_rcslotdone163:
  %v755 = load i64, ptr %slot109, align 8
  ret i64 %v755
bb_i6:
  %v756 = load i64, ptr %slot15, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i64 0, ptr %p757, align 8, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot15, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %ld760 = load i64, ptr %p759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld760, ptr %slot142, align 8
  %v761 = load i64, ptr %slot4, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %ld763 = load i32, ptr %p762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld763, ptr %slot143, align 8
  %v764 = load i32, ptr %slot143, align 8
  %cv765 = zext i32 %v764 to i64
  %cond766 = icmp ne i64 %cv765, 0
  br i1 %cond766, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  %v767 = load i64, ptr %slot4, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i32 0, ptr %p768, align 4, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot13, align 8
  store i64 %v769, ptr %slot144, align 8
  %v770 = load i64, ptr %slot5, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %ld772 = load i32, ptr %p771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld772, ptr %slot145, align 8
  %v773 = load i32, ptr %slot145, align 8
  %op774 = and i32 %v773, 28
  store i32 %op774, ptr %slot146, align 8
  %v775 = load i32, ptr %slot146, align 8
  %cv776 = zext i32 %v775 to i64
  %cond777 = icmp ne i64 %cv776, 0
  br i1 %cond777, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v778 = load i64, ptr %slot17, align 8
  store i64 %v778, ptr %slot147, align 8
  %v779 = load i64, ptr %slot144, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %ld781 = load i64, ptr %p780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld781, ptr %slot148, align 8
  %v782 = load i64, ptr %slot148, align 8
  %cmp783 = icmp ne i64 %v782, 0
  %cv784 = zext i1 %cmp783 to i32
  store i32 %cv784, ptr %slot149, align 8
  %v785 = load i32, ptr %slot149, align 8
  %cv786 = zext i32 %v785 to i64
  %cond787 = icmp ne i64 %cv786, 0
  br i1 %cond787, label %bb_rcgnn257, label %bb_rcgdone257
bb_rcgnn257:
  %v788 = load i64, ptr %slot148, align 8
  %op789 = sub i64 %v788, 16
  store i64 %op789, ptr %slot150, align 8
  %v790 = load i64, ptr %slot148, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %rgep792 = getelementptr i8, ptr %p791, i64 -16
  %ld793 = load i64, ptr %rgep792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld793, ptr %slot151, align 8
  %v794 = load i64, ptr %slot151, align 8
  %op795 = and i64 %v794, 4611686018427387906
  store i64 %op795, ptr %slot152, align 8
  %v796 = load i64, ptr %slot152, align 8
  %cmp797 = icmp ne i64 %v796, 0
  %cv798 = zext i1 %cmp797 to i32
  store i32 %cv798, ptr %slot153, align 8
  %v799 = load i32, ptr %slot153, align 8
  %cv800 = zext i32 %v799 to i64
  %cond801 = icmp ne i64 %cv800, 0
  br i1 %cond801, label %bb_rcgclear257, label %bb_rcgcounted257
bb_rcgcounted257:
  %v802 = load i64, ptr %slot148, align 8
  %op803 = sub i64 %v802, 24
  store i64 %op803, ptr %slot154, align 8
  %v804 = load i64, ptr %slot148, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %rgep806 = getelementptr i8, ptr %p805, i64 -24
  %ld807 = load i64, ptr %rgep806, align 8, !alias.scope !9, !noalias !10
  store i64 %ld807, ptr %slot155, align 8
  %v808 = load i64, ptr %slot155, align 8
  %op809 = sub i64 %v808, 1
  store i64 %op809, ptr %slot156, align 8
  %v810 = load i64, ptr %slot156, align 8
  %cmp811 = icmp eq i64 %v810, 0
  %cv812 = zext i1 %cmp811 to i32
  store i32 %cv812, ptr %slot157, align 8
  %v813 = load i32, ptr %slot157, align 8
  %cv814 = zext i32 %v813 to i64
  %cond815 = icmp ne i64 %cv814, 0
  br i1 %cond815, label %bb_rcglast257, label %bb_rcgdec257
bb_rcglast257:
  %v816 = load i64, ptr %slot148, align 8
  %op817 = sub i64 %v816, 32
  store i64 %op817, ptr %slot158, align 8
  %v818 = load i64, ptr %slot148, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %rgep820 = getelementptr i8, ptr %p819, i64 -32
  %ld821 = load i64, ptr %rgep820, align 8, !alias.scope !9, !noalias !10
  store i64 %ld821, ptr %slot159, align 8
  %v822 = load i64, ptr %slot159, align 8
  %cmp823 = icmp ne i64 %v822, 0
  %cv824 = zext i1 %cmp823 to i32
  store i32 %cv824, ptr %slot160, align 8
  %v825 = load i32, ptr %slot160, align 8
  %cv826 = zext i32 %v825 to i64
  %cond827 = icmp ne i64 %cv826, 0
  br i1 %cond827, label %bb_rcgdec257, label %bb_rcgslow257
bb_rcgslow257:
  %v828 = load i64, ptr %slot147, align 8
  %v829 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v828, i64 %v829) nomerge, !dbg !118
  br label %bb_rcgdone257
bb_rcgdec257:
  %v830 = load i64, ptr %slot156, align 8
  %v831 = load i64, ptr %slot148, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %rgep833 = getelementptr i8, ptr %p832, i64 -24
  store i64 %v830, ptr %rgep833, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear257
bb_rcgclear257:
  %v834 = load i64, ptr %slot144, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 0, ptr %p835, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone257
bb_rcgdone257:
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v836 = load i64, ptr %slot17, align 8
  store i64 %v836, ptr %slot161, align 8
  %v837 = load i64, ptr %slot144, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld839, ptr %slot162, align 8
  %v840 = load i64, ptr %slot162, align 8
  %cmp841 = icmp ne i64 %v840, 0
  %cv842 = zext i1 %cmp841 to i32
  store i32 %cv842, ptr %slot163, align 8
  %v843 = load i32, ptr %slot163, align 8
  %cv844 = zext i32 %v843 to i64
  %cond845 = icmp ne i64 %cv844, 0
  br i1 %cond845, label %bb_rcgnn272, label %bb_rcgdone272
bb_rcgnn272:
  %v846 = load i64, ptr %slot162, align 8
  %op847 = sub i64 %v846, 16
  store i64 %op847, ptr %slot164, align 8
  %v848 = load i64, ptr %slot162, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %rgep850 = getelementptr i8, ptr %p849, i64 -16
  %ld851 = load i64, ptr %rgep850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld851, ptr %slot165, align 8
  %v852 = load i64, ptr %slot165, align 8
  %op853 = and i64 %v852, 4611686018427387906
  store i64 %op853, ptr %slot166, align 8
  %v854 = load i64, ptr %slot166, align 8
  %cmp855 = icmp ne i64 %v854, 0
  %cv856 = zext i1 %cmp855 to i32
  store i32 %cv856, ptr %slot167, align 8
  %v857 = load i32, ptr %slot167, align 8
  %cv858 = zext i32 %v857 to i64
  %cond859 = icmp ne i64 %cv858, 0
  br i1 %cond859, label %bb_rcgclear272, label %bb_rcgcounted272
bb_rcgcounted272:
  %v860 = load i64, ptr %slot162, align 8
  %op861 = sub i64 %v860, 32
  store i64 %op861, ptr %slot168, align 8
  %v862 = load i64, ptr %slot162, align 8
  %p863 = inttoptr i64 %v862 to ptr
  %rgep864 = getelementptr i8, ptr %p863, i64 -32
  %ld865 = load i64, ptr %rgep864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld865, ptr %slot169, align 8
  %v866 = load i64, ptr %slot169, align 8
  %op867 = sub i64 %v866, 1
  store i64 %op867, ptr %slot170, align 8
  %v868 = load i64, ptr %slot170, align 8
  %cmp869 = icmp eq i64 %v868, 0
  %cv870 = zext i1 %cmp869 to i32
  store i32 %cv870, ptr %slot171, align 8
  %v871 = load i32, ptr %slot171, align 8
  %cv872 = zext i32 %v871 to i64
  %cond873 = icmp ne i64 %cv872, 0
  br i1 %cond873, label %bb_rcglast272, label %bb_rcgdec272
bb_rcglast272:
  %v874 = load i64, ptr %slot162, align 8
  %op875 = sub i64 %v874, 24
  store i64 %op875, ptr %slot172, align 8
  %v876 = load i64, ptr %slot162, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %rgep878 = getelementptr i8, ptr %p877, i64 -24
  %ld879 = load i64, ptr %rgep878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld879, ptr %slot173, align 8
  %v880 = load i64, ptr %slot173, align 8
  %cmp881 = icmp ne i64 %v880, 0
  %cv882 = zext i1 %cmp881 to i32
  store i32 %cv882, ptr %slot174, align 8
  %v883 = load i32, ptr %slot174, align 8
  %cv884 = zext i32 %v883 to i64
  %cond885 = icmp ne i64 %cv884, 0
  br i1 %cond885, label %bb_rcgdec272, label %bb_rcgslow272
bb_rcgslow272:
  %v886 = load i64, ptr %slot161, align 8
  %v887 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v886, i64 %v887) nomerge, !dbg !118
  br label %bb_rcgdone272
bb_rcgdec272:
  %v888 = load i64, ptr %slot170, align 8
  %v889 = load i64, ptr %slot162, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %rgep891 = getelementptr i8, ptr %p890, i64 -32
  store i64 %v888, ptr %rgep891, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear272
bb_rcgclear272:
  %v892 = load i64, ptr %slot144, align 8
  %p893 = inttoptr i64 %v892 to ptr
  store i64 0, ptr %p893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone272
bb_rcgdone272:
  br label %bb_rcslotdone241
bb_rcslotdone241:
  %v894 = load i64, ptr %slot142, align 8
  ret i64 %v894
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", linkageName: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10980889420309157548, i64 0, !"myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
