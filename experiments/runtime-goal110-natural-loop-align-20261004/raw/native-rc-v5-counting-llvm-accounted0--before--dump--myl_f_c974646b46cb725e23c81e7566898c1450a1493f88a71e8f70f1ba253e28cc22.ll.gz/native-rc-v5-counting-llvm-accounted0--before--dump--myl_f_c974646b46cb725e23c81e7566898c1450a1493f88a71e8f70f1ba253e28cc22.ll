target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v170 = load i64, ptr %slot1, align 8
  %op171 = add i64 %v170, 32
  store i64 %op171, ptr %slot4, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot5, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot6, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot7, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot8, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot9, align 8
  %mem182 = alloca i8, i64 8, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot10, align 8
  %mem184 = alloca i8, i64 8, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot11, align 8
  %mem186 = alloca i8, i64 8, align 8
  %ptr187 = ptrtoint ptr %mem186 to i64
  store i64 %ptr187, ptr %slot12, align 8
  %mem188 = alloca i8, i64 8, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot13, align 8
  %v190 = load i64, ptr %slot2, align 8
  %v191 = load i64, ptr %slot5, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot3, align 8
  %v194 = load i64, ptr %slot6, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v196 = load i64, ptr %slot12, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 0, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot12, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot14, align 8
  %v201 = load i64, ptr %slot7, align 8
  store i64 %v201, ptr %slot15, align 8
  %v202 = load i64, ptr %slot14, align 8
  %v203 = load i64, ptr %slot15, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 %v202, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot12, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 0, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot12, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot16, align 8
  %v210 = load i64, ptr %slot8, align 8
  store i64 %v210, ptr %slot17, align 8
  %v211 = load i64, ptr %slot16, align 8
  %v212 = load i64, ptr %slot17, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot5, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot18, align 8
  %v217 = load i64, ptr %slot18, align 8
  %v218 = load i64, ptr %slot12, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot12, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot19, align 8
  %v223 = load i64, ptr %slot9, align 8
  store i64 %v223, ptr %slot20, align 8
  %v224 = load i64, ptr %slot19, align 8
  %v225 = load i64, ptr %slot20, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot8, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot21, align 8
  %v230 = load i64, ptr %slot9, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot22, align 8
  %v233 = load i64, ptr %slot22, align 8
  %v234 = load i64, ptr %slot21, align 8
  %cmp235 = icmp sgt i64 %v233, %v234
  %cv236 = zext i1 %cmp235 to i64
  store i64 %cv236, ptr %slot23, align 8
  %v237 = load i64, ptr %slot22, align 8
  %v238 = load i64, ptr %slot21, align 8
  %op239 = sub i64 %v237, %v238
  store i64 %op239, ptr %slot24, align 8
  %v240 = load i64, ptr %slot24, align 8
  %cmp241 = icmp uge i64 %v240, 16
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot25, align 8
  %v243 = load i64, ptr %slot23, align 8
  %v244 = load i64, ptr %slot25, align 8
  %op245 = and i64 %v243, %v244
  store i64 %op245, ptr %slot26, align 8
  %v246 = load i64, ptr %slot26, align 8
  %cond247 = icmp ne i64 %v246, 0
  br i1 %cond247, label %bb_guard7, label %bb_oi6
bb_guard7:
  %v248 = load i64, ptr %slot21, align 8
  %op249 = add i64 %v248, 1152921504606846976
  store i64 %op249, ptr %slot27, align 8
  %v250 = load i64, ptr %slot27, align 8
  %cmp251 = icmp ule i64 %v250, 2305843009213693952
  %cv252 = zext i1 %cmp251 to i64
  store i64 %cv252, ptr %slot28, align 8
  %v253 = load i64, ptr %slot28, align 8
  %cond254 = icmp ne i64 %v253, 0
  br i1 %cond254, label %bb_guard13, label %bb_oi6
bb_guard13:
  %v255 = load i64, ptr %slot22, align 8
  %op256 = add i64 %v255, 1152921504606846976
  store i64 %op256, ptr %slot29, align 8
  %v257 = load i64, ptr %slot29, align 8
  %cmp258 = icmp ule i64 %v257, 2305843009213693952
  %cv259 = zext i1 %cmp258 to i64
  store i64 %cv259, ptr %slot30, align 8
  %v260 = load i64, ptr %slot30, align 8
  %cond261 = icmp ne i64 %v260, 0
  br i1 %cond261, label %bb_guard15, label %bb_oi6
bb_guard15:
  br label %bb_fi6
bb_fi6:
  %v262 = load i64, ptr %slot8, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot31, align 8
  %v265 = load i64, ptr %slot31, align 8
  %v266 = load i64, ptr %slot12, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i64 %v265, ptr %p267, align 8, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot9, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot32, align 8
  %v271 = load i64, ptr %slot32, align 8
  %v272 = load i64, ptr %slot13, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i64 %v271, ptr %p273, align 8, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot13, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot33, align 8
  %v277 = load i64, ptr %slot12, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot34, align 8
  %v280 = load i64, ptr %slot34, align 8
  %v281 = load i64, ptr %slot33, align 8
  %cmp282 = icmp slt i64 %v280, %v281
  %cv283 = zext i1 %cmp282 to i64
  store i64 %cv283, ptr %slot35, align 8
  %v284 = load i64, ptr %slot35, align 8
  %v285 = load i64, ptr %slot12, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot12, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot36, align 8
  %v290 = load i64, ptr %slot36, align 8
  %cond291 = icmp ne i64 %v290, 0
  br i1 %cond291, label %bb_next23, label %bb_i34
bb_next23:
  %v292 = load i64, ptr %slot8, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld294, ptr %slot37, align 8
  %v295 = load i64, ptr %slot37, align 8
  %v296 = load i64, ptr %slot12, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot13, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 2, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot13, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot38, align 8
  %v303 = load i64, ptr %slot12, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot39, align 8
  %v306 = load i64, ptr %slot38, align 8
  %cmp307 = icmp eq i64 %v306, 0
  %cv308 = zext i1 %cmp307 to i64
  store i64 %cv308, ptr %slot40, align 8
  %v309 = load i64, ptr %slot40, align 8
  %cond310 = icmp ne i64 %v309, 0
  br i1 %cond310, label %bb_division26, label %bb_nonzero26
bb_division26:
  %v311 = load i64, ptr %slot1, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %v313 = load i64, ptr %slot39, align 8
  %v314 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_division(ptr %p312, i64 6, i64 %v313, i64 %v314) nomerge, !dbg !110
  unreachable
bb_nonzero26:
  %v315 = load i64, ptr %slot39, align 8
  %cmp316 = icmp eq i64 %v315, 9223372036854775808
  %cv317 = zext i1 %cmp316 to i64
  store i64 %cv317, ptr %slot41, align 8
  %v318 = load i64, ptr %slot38, align 8
  %cmp319 = icmp eq i64 %v318, 18446744073709551615
  %cv320 = zext i1 %cmp319 to i64
  store i64 %cv320, ptr %slot42, align 8
  %v321 = load i64, ptr %slot41, align 8
  %v322 = load i64, ptr %slot42, align 8
  %op323 = and i64 %v321, %v322
  store i64 %op323, ptr %slot43, align 8
  %v324 = load i64, ptr %slot43, align 8
  %neg325 = sub i64 0, %v324
  store i64 %neg325, ptr %slot44, align 8
  %v326 = load i64, ptr %slot38, align 8
  %op327 = xor i64 %v326, 1
  store i64 %op327, ptr %slot45, align 8
  %v328 = load i64, ptr %slot45, align 8
  %v329 = load i64, ptr %slot44, align 8
  %op330 = and i64 %v328, %v329
  store i64 %op330, ptr %slot45, align 8
  %v331 = load i64, ptr %slot38, align 8
  %v332 = load i64, ptr %slot45, align 8
  %op333 = xor i64 %v331, %v332
  store i64 %op333, ptr %slot46, align 8
  %v334 = load i64, ptr %slot39, align 8
  %v335 = load i64, ptr %slot46, align 8
  %op336 = srem i64 %v334, %v335
  store i64 %op336, ptr %slot47, align 8
  %v337 = load i64, ptr %slot47, align 8
  %cmp338 = icmp ne i64 %v337, 0
  %cv339 = zext i1 %cmp338 to i64
  store i64 %cv339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot47, align 8
  %v341 = load i64, ptr %slot46, align 8
  %op342 = xor i64 %v340, %v341
  store i64 %op342, ptr %slot49, align 8
  %v343 = load i64, ptr %slot49, align 8
  %cmp344 = icmp slt i64 %v343, 0
  %cv345 = zext i1 %cmp344 to i64
  store i64 %cv345, ptr %slot50, align 8
  %v346 = load i64, ptr %slot48, align 8
  %v347 = load i64, ptr %slot50, align 8
  %op348 = and i64 %v346, %v347
  store i64 %op348, ptr %slot51, align 8
  %v349 = load i64, ptr %slot51, align 8
  %neg350 = sub i64 0, %v349
  store i64 %neg350, ptr %slot52, align 8
  %v351 = load i64, ptr %slot46, align 8
  %v352 = load i64, ptr %slot52, align 8
  %op353 = and i64 %v351, %v352
  store i64 %op353, ptr %slot53, align 8
  %v354 = load i64, ptr %slot47, align 8
  %v355 = load i64, ptr %slot53, align 8
  %op356 = add i64 %v354, %v355
  store i64 %op356, ptr %slot47, align 8
  %v357 = load i64, ptr %slot47, align 8
  %v358 = load i64, ptr %slot12, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i64 %v357, ptr %p359, align 8, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot6, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld362, ptr %slot54, align 8
  %v363 = load i64, ptr %slot54, align 8
  %v364 = load i64, ptr %slot13, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot13, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot55, align 8
  %v369 = load i64, ptr %slot12, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot56, align 8
  %v372 = load i64, ptr %slot56, align 8
  %v373 = load i64, ptr %slot55, align 8
  %cmp374 = icmp eq i64 %v372, %v373
  %cv375 = zext i1 %cmp374 to i64
  store i64 %cv375, ptr %slot57, align 8
  %v376 = load i64, ptr %slot57, align 8
  %v377 = load i64, ptr %slot12, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 %v376, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot12, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot58, align 8
  %v382 = load i64, ptr %slot58, align 8
  %cond383 = icmp ne i64 %v382, 0
  br i1 %cond383, label %bb_next45, label %bb_fi19
bb_next45:
  %v384 = load i64, ptr %slot12, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 1, ptr %p385, align 8, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot12, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot59, align 8
  %v389 = load i64, ptr %slot10, align 8
  store i64 %v389, ptr %slot60, align 8
  %v390 = load i64, ptr %slot59, align 8
  %v391 = load i64, ptr %slot60, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 %v390, ptr %p392, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v393 = load i64, ptr %slot12, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 0, ptr %p394, align 8, !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot12, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %ld397 = load i64, ptr %p396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld397, ptr %slot61, align 8
  %v398 = load i64, ptr %slot10, align 8
  store i64 %v398, ptr %slot62, align 8
  %v399 = load i64, ptr %slot61, align 8
  %v400 = load i64, ptr %slot62, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v402 = load i64, ptr %slot10, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot63, align 8
  %v405 = load i64, ptr %slot63, align 8
  %v406 = load i64, ptr %slot12, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot12, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot64, align 8
  %v411 = load i64, ptr %slot11, align 8
  store i64 %v411, ptr %slot65, align 8
  %v412 = load i64, ptr %slot64, align 8
  %v413 = load i64, ptr %slot65, align 8
  %p414 = inttoptr i64 %v413 to ptr
  store i64 %v412, ptr %p414, align 8, !alias.scope !3, !noalias !4
  %v415 = load i64, ptr %slot7, align 8
  %p416 = inttoptr i64 %v415 to ptr
  %ld417 = load i64, ptr %p416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld417, ptr %slot66, align 8
  %v418 = load i64, ptr %slot66, align 8
  %v419 = load i64, ptr %slot12, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot11, align 8
  %p422 = inttoptr i64 %v421 to ptr
  %ld423 = load i64, ptr %p422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld423, ptr %slot67, align 8
  %v424 = load i64, ptr %slot67, align 8
  %v425 = load i64, ptr %slot13, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i64 %v424, ptr %p426, align 8, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot13, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %ld429 = load i64, ptr %p428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld429, ptr %slot68, align 8
  %v430 = load i64, ptr %slot12, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot69, align 8
  %v433 = load i64, ptr %slot69, align 8
  %v434 = load i64, ptr %slot68, align 8
  %ovpair436 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v433, i64 %v434)
  %op435 = extractvalue { i64, i1 } %ovpair436, 0
  %ov437 = extractvalue { i64, i1 } %ovpair436, 1
  store i64 %op435, ptr %slot70, align 8
  %v438 = load i64, ptr %slot69, align 8
  %v439 = load i64, ptr %slot70, align 8
  %op440 = xor i64 %v438, %v439
  store i64 %op440, ptr %slot71, align 8
  %v441 = load i64, ptr %slot68, align 8
  %v442 = load i64, ptr %slot70, align 8
  %op443 = xor i64 %v441, %v442
  store i64 %op443, ptr %slot72, align 8
  %v444 = load i64, ptr %slot71, align 8
  %v445 = load i64, ptr %slot72, align 8
  %op446 = and i64 %v444, %v445
  store i64 %op446, ptr %slot73, align 8
  %cv447 = zext i1 %ov437 to i64
  store i64 %cv447, ptr %slot74, align 8
  %v448 = load i64, ptr %slot74, align 8
  %cond449 = icmp ne i64 %v448, 0
  br i1 %cond449, label %bb_overflow56, label %bb_checked56
bb_overflow56:
  %v450 = load i64, ptr %slot1, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %v452 = load i64, ptr %slot69, align 8
  %v453 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p451, i64 0, i64 %v452, i64 %v453, i64 64) nomerge, !dbg !112
  unreachable
bb_checked56:
  %v454 = load i64, ptr %slot70, align 8
  %v455 = load i64, ptr %slot12, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i64 %v454, ptr %p456, align 8, !alias.scope !3, !noalias !4
  %v457 = load i64, ptr %slot13, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 1000000007, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot13, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %ld461 = load i64, ptr %p460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld461, ptr %slot75, align 8
  %v462 = load i64, ptr %slot12, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot76, align 8
  %v465 = load i64, ptr %slot75, align 8
  %cmp466 = icmp eq i64 %v465, 0
  %cv467 = zext i1 %cmp466 to i64
  store i64 %cv467, ptr %slot77, align 8
  %v468 = load i64, ptr %slot77, align 8
  %cond469 = icmp ne i64 %v468, 0
  br i1 %cond469, label %bb_division63, label %bb_nonzero63
bb_division63:
  %v470 = load i64, ptr %slot1, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %v472 = load i64, ptr %slot76, align 8
  %v473 = load i64, ptr %slot75, align 8
  call void @myl_qbe_fail_division(ptr %p471, i64 6, i64 %v472, i64 %v473) nomerge, !dbg !114
  unreachable
bb_nonzero63:
  %v474 = load i64, ptr %slot76, align 8
  %cmp475 = icmp eq i64 %v474, 9223372036854775808
  %cv476 = zext i1 %cmp475 to i64
  store i64 %cv476, ptr %slot78, align 8
  %v477 = load i64, ptr %slot75, align 8
  %cmp478 = icmp eq i64 %v477, 18446744073709551615
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot79, align 8
  %v480 = load i64, ptr %slot78, align 8
  %v481 = load i64, ptr %slot79, align 8
  %op482 = and i64 %v480, %v481
  store i64 %op482, ptr %slot80, align 8
  %v483 = load i64, ptr %slot80, align 8
  %neg484 = sub i64 0, %v483
  store i64 %neg484, ptr %slot81, align 8
  %v485 = load i64, ptr %slot75, align 8
  %op486 = xor i64 %v485, 1
  store i64 %op486, ptr %slot82, align 8
  %v487 = load i64, ptr %slot82, align 8
  %v488 = load i64, ptr %slot81, align 8
  %op489 = and i64 %v487, %v488
  store i64 %op489, ptr %slot82, align 8
  %v490 = load i64, ptr %slot75, align 8
  %v491 = load i64, ptr %slot82, align 8
  %op492 = xor i64 %v490, %v491
  store i64 %op492, ptr %slot83, align 8
  %v493 = load i64, ptr %slot76, align 8
  %v494 = load i64, ptr %slot83, align 8
  %op495 = srem i64 %v493, %v494
  store i64 %op495, ptr %slot84, align 8
  %v496 = load i64, ptr %slot84, align 8
  %cmp497 = icmp ne i64 %v496, 0
  %cv498 = zext i1 %cmp497 to i64
  store i64 %cv498, ptr %slot85, align 8
  %v499 = load i64, ptr %slot84, align 8
  %v500 = load i64, ptr %slot83, align 8
  %op501 = xor i64 %v499, %v500
  store i64 %op501, ptr %slot86, align 8
  %v502 = load i64, ptr %slot86, align 8
  %cmp503 = icmp slt i64 %v502, 0
  %cv504 = zext i1 %cmp503 to i64
  store i64 %cv504, ptr %slot87, align 8
  %v505 = load i64, ptr %slot85, align 8
  %v506 = load i64, ptr %slot87, align 8
  %op507 = and i64 %v505, %v506
  store i64 %op507, ptr %slot88, align 8
  %v508 = load i64, ptr %slot88, align 8
  %neg509 = sub i64 0, %v508
  store i64 %neg509, ptr %slot89, align 8
  %v510 = load i64, ptr %slot83, align 8
  %v511 = load i64, ptr %slot89, align 8
  %op512 = and i64 %v510, %v511
  store i64 %op512, ptr %slot90, align 8
  %v513 = load i64, ptr %slot84, align 8
  %v514 = load i64, ptr %slot90, align 8
  %op515 = add i64 %v513, %v514
  store i64 %op515, ptr %slot84, align 8
  %v516 = load i64, ptr %slot84, align 8
  %v517 = load i64, ptr %slot12, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 %v516, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot12, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i64, ptr %p520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld521, ptr %slot91, align 8
  %v522 = load i64, ptr %slot7, align 8
  store i64 %v522, ptr %slot92, align 8
  %v523 = load i64, ptr %slot91, align 8
  %v524 = load i64, ptr %slot92, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot8, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot93, align 8
  %v529 = load i64, ptr %slot93, align 8
  %v530 = load i64, ptr %slot12, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot13, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 1, ptr %p533, align 8, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot13, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot94, align 8
  %v537 = load i64, ptr %slot12, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i64, ptr %p538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld539, ptr %slot95, align 8
  %v540 = load i64, ptr %slot95, align 8
  %v541 = load i64, ptr %slot94, align 8
  %op542 = add i64 %v540, %v541
  store i64 %op542, ptr %slot96, align 8
  %v543 = load i64, ptr %slot96, align 8
  %v544 = load i64, ptr %slot12, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 %v543, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot12, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot97, align 8
  %v549 = load i64, ptr %slot8, align 8
  store i64 %v549, ptr %slot98, align 8
  %v550 = load i64, ptr %slot97, align 8
  %v551 = load i64, ptr %slot98, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 %v550, ptr %p552, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v553 = load i64, ptr %slot8, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot99, align 8
  %v556 = load i64, ptr %slot99, align 8
  %v557 = load i64, ptr %slot12, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i64 %v556, ptr %p558, align 8, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot9, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %ld561 = load i64, ptr %p560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld561, ptr %slot100, align 8
  %v562 = load i64, ptr %slot100, align 8
  %v563 = load i64, ptr %slot13, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i64 %v562, ptr %p564, align 8, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot13, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i64, ptr %p566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld567, ptr %slot101, align 8
  %v568 = load i64, ptr %slot12, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot102, align 8
  %v571 = load i64, ptr %slot102, align 8
  %v572 = load i64, ptr %slot101, align 8
  %cmp573 = icmp slt i64 %v571, %v572
  %cv574 = zext i1 %cmp573 to i64
  store i64 %cv574, ptr %slot103, align 8
  %v575 = load i64, ptr %slot103, align 8
  %v576 = load i64, ptr %slot12, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i64 %v575, ptr %p577, align 8, !alias.scope !3, !noalias !4
  %v578 = load i64, ptr %slot12, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i64, ptr %p579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld580, ptr %slot104, align 8
  %v581 = load i64, ptr %slot104, align 8
  %cond582 = icmp ne i64 %v581, 0
  br i1 %cond582, label %bb_next91, label %bb_i34
bb_next91:
  %v583 = load i64, ptr %slot8, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot105, align 8
  %v586 = load i64, ptr %slot105, align 8
  %v587 = load i64, ptr %slot12, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot13, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 2, ptr %p590, align 8, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot13, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i64, ptr %p592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld593, ptr %slot106, align 8
  %v594 = load i64, ptr %slot12, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld596, ptr %slot107, align 8
  %v597 = load i64, ptr %slot106, align 8
  %cmp598 = icmp eq i64 %v597, 0
  %cv599 = zext i1 %cmp598 to i64
  store i64 %cv599, ptr %slot108, align 8
  %v600 = load i64, ptr %slot108, align 8
  %cond601 = icmp ne i64 %v600, 0
  br i1 %cond601, label %bb_division94, label %bb_nonzero94
bb_division94:
  %v602 = load i64, ptr %slot1, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %v604 = load i64, ptr %slot107, align 8
  %v605 = load i64, ptr %slot106, align 8
  call void @myl_qbe_fail_division(ptr %p603, i64 6, i64 %v604, i64 %v605) nomerge, !dbg !110
  unreachable
bb_nonzero94:
  %v606 = load i64, ptr %slot107, align 8
  %cmp607 = icmp eq i64 %v606, 9223372036854775808
  %cv608 = zext i1 %cmp607 to i64
  store i64 %cv608, ptr %slot109, align 8
  %v609 = load i64, ptr %slot106, align 8
  %cmp610 = icmp eq i64 %v609, 18446744073709551615
  %cv611 = zext i1 %cmp610 to i64
  store i64 %cv611, ptr %slot110, align 8
  %v612 = load i64, ptr %slot109, align 8
  %v613 = load i64, ptr %slot110, align 8
  %op614 = and i64 %v612, %v613
  store i64 %op614, ptr %slot111, align 8
  %v615 = load i64, ptr %slot111, align 8
  %neg616 = sub i64 0, %v615
  store i64 %neg616, ptr %slot112, align 8
  %v617 = load i64, ptr %slot106, align 8
  %op618 = xor i64 %v617, 1
  store i64 %op618, ptr %slot113, align 8
  %v619 = load i64, ptr %slot113, align 8
  %v620 = load i64, ptr %slot112, align 8
  %op621 = and i64 %v619, %v620
  store i64 %op621, ptr %slot113, align 8
  %v622 = load i64, ptr %slot106, align 8
  %v623 = load i64, ptr %slot113, align 8
  %op624 = xor i64 %v622, %v623
  store i64 %op624, ptr %slot114, align 8
  %v625 = load i64, ptr %slot107, align 8
  %v626 = load i64, ptr %slot114, align 8
  %op627 = srem i64 %v625, %v626
  store i64 %op627, ptr %slot115, align 8
  %v628 = load i64, ptr %slot115, align 8
  %cmp629 = icmp ne i64 %v628, 0
  %cv630 = zext i1 %cmp629 to i64
  store i64 %cv630, ptr %slot116, align 8
  %v631 = load i64, ptr %slot115, align 8
  %v632 = load i64, ptr %slot114, align 8
  %op633 = xor i64 %v631, %v632
  store i64 %op633, ptr %slot117, align 8
  %v634 = load i64, ptr %slot117, align 8
  %cmp635 = icmp slt i64 %v634, 0
  %cv636 = zext i1 %cmp635 to i64
  store i64 %cv636, ptr %slot118, align 8
  %v637 = load i64, ptr %slot116, align 8
  %v638 = load i64, ptr %slot118, align 8
  %op639 = and i64 %v637, %v638
  store i64 %op639, ptr %slot119, align 8
  %v640 = load i64, ptr %slot119, align 8
  %neg641 = sub i64 0, %v640
  store i64 %neg641, ptr %slot120, align 8
  %v642 = load i64, ptr %slot114, align 8
  %v643 = load i64, ptr %slot120, align 8
  %op644 = and i64 %v642, %v643
  store i64 %op644, ptr %slot121, align 8
  %v645 = load i64, ptr %slot115, align 8
  %v646 = load i64, ptr %slot121, align 8
  %op647 = add i64 %v645, %v646
  store i64 %op647, ptr %slot115, align 8
  %v648 = load i64, ptr %slot115, align 8
  %v649 = load i64, ptr %slot12, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 %v648, ptr %p650, align 8, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot6, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot122, align 8
  %v654 = load i64, ptr %slot122, align 8
  %v655 = load i64, ptr %slot13, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i64 %v654, ptr %p656, align 8, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot13, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot123, align 8
  %v660 = load i64, ptr %slot12, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %ld662 = load i64, ptr %p661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld662, ptr %slot124, align 8
  %v663 = load i64, ptr %slot124, align 8
  %v664 = load i64, ptr %slot123, align 8
  %cmp665 = icmp eq i64 %v663, %v664
  %cv666 = zext i1 %cmp665 to i64
  store i64 %cv666, ptr %slot125, align 8
  %v667 = load i64, ptr %slot125, align 8
  %v668 = load i64, ptr %slot12, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 %v667, ptr %p669, align 8, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot12, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot126, align 8
  %v673 = load i64, ptr %slot126, align 8
  %cond674 = icmp ne i64 %v673, 0
  br i1 %cond674, label %bb_next113, label %bb_i19
bb_next113:
  %v675 = load i64, ptr %slot12, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i64 1, ptr %p676, align 8, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot12, align 8
  %p678 = inttoptr i64 %v677 to ptr
  %ld679 = load i64, ptr %p678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld679, ptr %slot127, align 8
  %v680 = load i64, ptr %slot10, align 8
  store i64 %v680, ptr %slot128, align 8
  %v681 = load i64, ptr %slot127, align 8
  %v682 = load i64, ptr %slot128, align 8
  %p683 = inttoptr i64 %v682 to ptr
  store i64 %v681, ptr %p683, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v684 = load i64, ptr %slot12, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i64 0, ptr %p685, align 8, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot12, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i64, ptr %p687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld688, ptr %slot129, align 8
  %v689 = load i64, ptr %slot10, align 8
  store i64 %v689, ptr %slot130, align 8
  %v690 = load i64, ptr %slot129, align 8
  %v691 = load i64, ptr %slot130, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v693 = load i64, ptr %slot10, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %ld695 = load i64, ptr %p694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld695, ptr %slot131, align 8
  %v696 = load i64, ptr %slot131, align 8
  %v697 = load i64, ptr %slot12, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i64 %v696, ptr %p698, align 8, !alias.scope !3, !noalias !4
  %v699 = load i64, ptr %slot12, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %ld701 = load i64, ptr %p700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld701, ptr %slot132, align 8
  %v702 = load i64, ptr %slot11, align 8
  store i64 %v702, ptr %slot133, align 8
  %v703 = load i64, ptr %slot132, align 8
  %v704 = load i64, ptr %slot133, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot7, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i64, ptr %p707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot134, align 8
  %v709 = load i64, ptr %slot134, align 8
  %v710 = load i64, ptr %slot12, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot11, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %ld714 = load i64, ptr %p713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld714, ptr %slot135, align 8
  %v715 = load i64, ptr %slot135, align 8
  %v716 = load i64, ptr %slot13, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i64 %v715, ptr %p717, align 8, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot13, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %ld720 = load i64, ptr %p719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld720, ptr %slot136, align 8
  %v721 = load i64, ptr %slot12, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i64, ptr %p722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld723, ptr %slot137, align 8
  %v724 = load i64, ptr %slot137, align 8
  %v725 = load i64, ptr %slot136, align 8
  %ovpair727 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v724, i64 %v725)
  %op726 = extractvalue { i64, i1 } %ovpair727, 0
  %ov728 = extractvalue { i64, i1 } %ovpair727, 1
  store i64 %op726, ptr %slot138, align 8
  %v729 = load i64, ptr %slot137, align 8
  %v730 = load i64, ptr %slot138, align 8
  %op731 = xor i64 %v729, %v730
  store i64 %op731, ptr %slot139, align 8
  %v732 = load i64, ptr %slot136, align 8
  %v733 = load i64, ptr %slot138, align 8
  %op734 = xor i64 %v732, %v733
  store i64 %op734, ptr %slot140, align 8
  %v735 = load i64, ptr %slot139, align 8
  %v736 = load i64, ptr %slot140, align 8
  %op737 = and i64 %v735, %v736
  store i64 %op737, ptr %slot141, align 8
  %cv738 = zext i1 %ov728 to i64
  store i64 %cv738, ptr %slot142, align 8
  %v739 = load i64, ptr %slot142, align 8
  %cond740 = icmp ne i64 %v739, 0
  br i1 %cond740, label %bb_overflow124, label %bb_checked124
bb_overflow124:
  %v741 = load i64, ptr %slot1, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %v743 = load i64, ptr %slot137, align 8
  %v744 = load i64, ptr %slot136, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p742, i64 0, i64 %v743, i64 %v744, i64 64) nomerge, !dbg !112
  unreachable
bb_checked124:
  %v745 = load i64, ptr %slot138, align 8
  %v746 = load i64, ptr %slot12, align 8
  %p747 = inttoptr i64 %v746 to ptr
  store i64 %v745, ptr %p747, align 8, !alias.scope !3, !noalias !4
  %v748 = load i64, ptr %slot13, align 8
  %p749 = inttoptr i64 %v748 to ptr
  store i64 1000000007, ptr %p749, align 8, !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot13, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i64, ptr %p751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld752, ptr %slot143, align 8
  %v753 = load i64, ptr %slot12, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ld755 = load i64, ptr %p754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld755, ptr %slot144, align 8
  %v756 = load i64, ptr %slot143, align 8
  %cmp757 = icmp eq i64 %v756, 0
  %cv758 = zext i1 %cmp757 to i64
  store i64 %cv758, ptr %slot145, align 8
  %v759 = load i64, ptr %slot145, align 8
  %cond760 = icmp ne i64 %v759, 0
  br i1 %cond760, label %bb_division131, label %bb_nonzero131
bb_division131:
  %v761 = load i64, ptr %slot1, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %v763 = load i64, ptr %slot144, align 8
  %v764 = load i64, ptr %slot143, align 8
  call void @myl_qbe_fail_division(ptr %p762, i64 6, i64 %v763, i64 %v764) nomerge, !dbg !114
  unreachable
bb_nonzero131:
  %v765 = load i64, ptr %slot144, align 8
  %cmp766 = icmp eq i64 %v765, 9223372036854775808
  %cv767 = zext i1 %cmp766 to i64
  store i64 %cv767, ptr %slot146, align 8
  %v768 = load i64, ptr %slot143, align 8
  %cmp769 = icmp eq i64 %v768, 18446744073709551615
  %cv770 = zext i1 %cmp769 to i64
  store i64 %cv770, ptr %slot147, align 8
  %v771 = load i64, ptr %slot146, align 8
  %v772 = load i64, ptr %slot147, align 8
  %op773 = and i64 %v771, %v772
  store i64 %op773, ptr %slot148, align 8
  %v774 = load i64, ptr %slot148, align 8
  %neg775 = sub i64 0, %v774
  store i64 %neg775, ptr %slot149, align 8
  %v776 = load i64, ptr %slot143, align 8
  %op777 = xor i64 %v776, 1
  store i64 %op777, ptr %slot150, align 8
  %v778 = load i64, ptr %slot150, align 8
  %v779 = load i64, ptr %slot149, align 8
  %op780 = and i64 %v778, %v779
  store i64 %op780, ptr %slot150, align 8
  %v781 = load i64, ptr %slot143, align 8
  %v782 = load i64, ptr %slot150, align 8
  %op783 = xor i64 %v781, %v782
  store i64 %op783, ptr %slot151, align 8
  %v784 = load i64, ptr %slot144, align 8
  %v785 = load i64, ptr %slot151, align 8
  %op786 = srem i64 %v784, %v785
  store i64 %op786, ptr %slot152, align 8
  %v787 = load i64, ptr %slot152, align 8
  %cmp788 = icmp ne i64 %v787, 0
  %cv789 = zext i1 %cmp788 to i64
  store i64 %cv789, ptr %slot153, align 8
  %v790 = load i64, ptr %slot152, align 8
  %v791 = load i64, ptr %slot151, align 8
  %op792 = xor i64 %v790, %v791
  store i64 %op792, ptr %slot154, align 8
  %v793 = load i64, ptr %slot154, align 8
  %cmp794 = icmp slt i64 %v793, 0
  %cv795 = zext i1 %cmp794 to i64
  store i64 %cv795, ptr %slot155, align 8
  %v796 = load i64, ptr %slot153, align 8
  %v797 = load i64, ptr %slot155, align 8
  %op798 = and i64 %v796, %v797
  store i64 %op798, ptr %slot156, align 8
  %v799 = load i64, ptr %slot156, align 8
  %neg800 = sub i64 0, %v799
  store i64 %neg800, ptr %slot157, align 8
  %v801 = load i64, ptr %slot151, align 8
  %v802 = load i64, ptr %slot157, align 8
  %op803 = and i64 %v801, %v802
  store i64 %op803, ptr %slot158, align 8
  %v804 = load i64, ptr %slot152, align 8
  %v805 = load i64, ptr %slot158, align 8
  %op806 = add i64 %v804, %v805
  store i64 %op806, ptr %slot152, align 8
  %v807 = load i64, ptr %slot152, align 8
  %v808 = load i64, ptr %slot12, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i64 %v807, ptr %p809, align 8, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot12, align 8
  %p811 = inttoptr i64 %v810 to ptr
  %ld812 = load i64, ptr %p811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld812, ptr %slot159, align 8
  %v813 = load i64, ptr %slot7, align 8
  store i64 %v813, ptr %slot160, align 8
  %v814 = load i64, ptr %slot159, align 8
  %v815 = load i64, ptr %slot160, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i64 %v814, ptr %p816, align 8, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot8, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot161, align 8
  %v820 = load i64, ptr %slot161, align 8
  %v821 = load i64, ptr %slot12, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i64 %v820, ptr %p822, align 8, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot13, align 8
  %p824 = inttoptr i64 %v823 to ptr
  store i64 1, ptr %p824, align 8, !alias.scope !3, !noalias !4
  %v825 = load i64, ptr %slot13, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld827, ptr %slot162, align 8
  %v828 = load i64, ptr %slot12, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i64, ptr %p829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld830, ptr %slot163, align 8
  %v831 = load i64, ptr %slot163, align 8
  %v832 = load i64, ptr %slot162, align 8
  %op833 = add i64 %v831, %v832
  %ovpair834 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v831, i64 %v832)
  %ov835 = extractvalue { i64, i1 } %ovpair834, 1
  store i64 %op833, ptr %slot164, align 8
  %cv836 = zext i1 %ov835 to i64
  store i64 %cv836, ptr %slot165, align 8
  %v837 = load i64, ptr %slot165, align 8
  %cond838 = icmp ne i64 %v837, 0
  br i1 %cond838, label %bb_overflow150, label %bb_checked150
bb_overflow150:
  %v839 = load i64, ptr %slot1, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %v841 = load i64, ptr %slot163, align 8
  %v842 = load i64, ptr %slot162, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p840, i64 0, i64 %v841, i64 %v842, i64 64) nomerge, !dbg !116
  unreachable
bb_checked150:
  %v843 = load i64, ptr %slot164, align 8
  %v844 = load i64, ptr %slot12, align 8
  %p845 = inttoptr i64 %v844 to ptr
  store i64 %v843, ptr %p845, align 8, !alias.scope !3, !noalias !4
  %v846 = load i64, ptr %slot12, align 8
  %p847 = inttoptr i64 %v846 to ptr
  %ld848 = load i64, ptr %p847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld848, ptr %slot166, align 8
  %v849 = load i64, ptr %slot8, align 8
  store i64 %v849, ptr %slot167, align 8
  %v850 = load i64, ptr %slot166, align 8
  %v851 = load i64, ptr %slot167, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 %v850, ptr %p852, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i34:
  %v853 = load i64, ptr %slot7, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot168, align 8
  %v856 = load i64, ptr %slot168, align 8
  %v857 = load i64, ptr %slot12, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i64 %v856, ptr %p858, align 8, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot12, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i64, ptr %p860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld861, ptr %slot169, align 8
  %v862 = load i64, ptr %slot169, align 8
  ret i64 %v862
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", linkageName: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7472279511045523184, i64 0, !"myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
