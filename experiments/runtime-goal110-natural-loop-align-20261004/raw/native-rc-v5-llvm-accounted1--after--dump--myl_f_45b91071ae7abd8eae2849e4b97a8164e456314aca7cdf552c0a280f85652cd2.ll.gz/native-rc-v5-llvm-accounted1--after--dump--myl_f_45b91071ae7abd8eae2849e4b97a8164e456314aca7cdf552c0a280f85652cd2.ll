target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v54 = load i64, ptr %slot1, align 8
  %op55 = add i64 %v54, 32
  store i64 %op55, ptr %slot3, align 8
  %mem56 = alloca i8, i64 8, align 8
  %ptr57 = ptrtoint ptr %mem56 to i64
  store i64 %ptr57, ptr %slot4, align 8
  %mem58 = alloca i8, i64 8, align 8
  %ptr59 = ptrtoint ptr %mem58 to i64
  store i64 %ptr59, ptr %slot5, align 8
  %mem60 = alloca i8, i64 8, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot6, align 8
  %v62 = load i64, ptr %slot1, align 8
  %op63 = add i64 %v62, 8
  store i64 %op63, ptr %slot7, align 8
  %v64 = load i64, ptr %slot7, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i64, ptr %p65, align 8, !alias.scope !4, !noalias !3
  store i64 %ld66, ptr %slot8, align 8
  %v67 = load i64, ptr %slot1, align 8
  %op68 = add i64 %v67, 56
  store i64 %op68, ptr %slot9, align 8
  %v69 = load i64, ptr %slot9, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !4, !noalias !3
  store i64 %ld71, ptr %slot10, align 8
  %v72 = load i64, ptr %slot8, align 8
  %v73 = load i64, ptr %slot10, align 8
  %cmp74 = icmp eq i64 %v72, %v73
  %cv75 = zext i1 %cmp74 to i64
  store i64 %cv75, ptr %slot11, align 8
  %v76 = load i64, ptr %slot11, align 8
  %cond77 = icmp ne i64 %v76, 0
  br i1 %cond77, label %bb_limitfail2, label %bb_frameadmit0
bb_limitfail2:
  %v78 = load i64, ptr %slot1, align 8
  %p79 = inttoptr i64 %v78 to ptr
  call void @myl_qbe_fail_frame(ptr %p79)
  br label %bb_entry_failure
bb_frameadmit0:
  %mem80 = alloca i8, i64 32, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot12, align 8
  %v82 = load i64, ptr %slot1, align 8
  %op83 = add i64 %v82, 48
  store i64 %op83, ptr %slot13, align 8
  %v84 = load i64, ptr %slot13, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ld86 = load i64, ptr %p85, align 8, !alias.scope !4, !noalias !3
  store i64 %ld86, ptr %slot14, align 8
  %v87 = load i64, ptr %slot14, align 8
  %v88 = load i64, ptr %slot12, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  %v90 = load i64, ptr %slot12, align 8
  %p92 = inttoptr i64 %v90 to ptr
  %gep93 = getelementptr i8, ptr %p92, i64 8
  %op91 = ptrtoint ptr %gep93 to i64
  store i64 %op91, ptr %slot15, align 8
  %v94 = load i64, ptr %slot15, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 ptrtoint (ptr @myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2_meta to i64), ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot12, align 8
  %p98 = inttoptr i64 %v96 to ptr
  %gep99 = getelementptr i8, ptr %p98, i64 16
  %op97 = ptrtoint ptr %gep99 to i64
  store i64 %op97, ptr %slot16, align 8
  %v100 = load i64, ptr %slot16, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 0, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot12, align 8
  %v103 = load i64, ptr %slot13, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !4, !noalias !3
  %v105 = load i64, ptr %slot8, align 8
  %op106 = add i64 %v105, 1
  store i64 %op106, ptr %slot17, align 8
  %v107 = load i64, ptr %slot17, align 8
  %v108 = load i64, ptr %slot7, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 %v107, ptr %p109, align 8, !alias.scope !4, !noalias !3
  %v110 = load i64, ptr %slot12, align 8
  %p112 = inttoptr i64 %v110 to ptr
  %gep113 = getelementptr i8, ptr %p112, i64 16
  %op111 = ptrtoint ptr %gep113 to i64
  store i64 %op111, ptr %slot18, align 8
  %v114 = load i64, ptr %slot2, align 8
  %v115 = load i64, ptr %slot4, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot1, align 8
  %op118 = add i64 %v117, 16
  store i64 %op118, ptr %slot19, align 8
  br label %bb_i0
bb_i0:
  %v119 = load i64, ptr %slot18, align 8
  %p120 = inttoptr i64 %v119 to ptr
  store i64 0, ptr %p120, align 8, !alias.scope !3, !noalias !4
  %v121 = load i64, ptr %slot1, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !4, !noalias !3
  store i64 %ld123, ptr %slot20, align 8
  %v124 = load i64, ptr %slot19, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !4, !noalias !3
  store i64 %ld126, ptr %slot21, align 8
  %v127 = load i64, ptr %slot20, align 8
  %v128 = load i64, ptr %slot21, align 8
  %cmp129 = icmp eq i64 %v127, %v128
  %cv130 = zext i1 %cmp129 to i64
  store i64 %cv130, ptr %slot22, align 8
  %v131 = load i64, ptr %slot22, align 8
  %cond132 = icmp ne i64 %v131, 0
  br i1 %cond132, label %bb_step_limit, label %bb_step21
bb_step21:
  %v133 = load i64, ptr %slot20, align 8
  %op134 = add i64 %v133, 1
  store i64 %op134, ptr %slot23, align 8
  %v135 = load i64, ptr %slot23, align 8
  %v136 = load i64, ptr %slot1, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !4, !noalias !3
  %v138 = load i64, ptr %slot4, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot24, align 8
  %v141 = load i64, ptr %slot24, align 8
  %v142 = load i64, ptr %slot5, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot18, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 1, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot1, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !4, !noalias !3
  store i64 %ld148, ptr %slot25, align 8
  %v149 = load i64, ptr %slot19, align 8
  %p150 = inttoptr i64 %v149 to ptr
  %ld151 = load i64, ptr %p150, align 8, !alias.scope !4, !noalias !3
  store i64 %ld151, ptr %slot26, align 8
  %v152 = load i64, ptr %slot25, align 8
  %v153 = load i64, ptr %slot26, align 8
  %cmp154 = icmp eq i64 %v152, %v153
  %cv155 = zext i1 %cmp154 to i64
  store i64 %cv155, ptr %slot27, align 8
  %v156 = load i64, ptr %slot27, align 8
  %cond157 = icmp ne i64 %v156, 0
  br i1 %cond157, label %bb_step_limit, label %bb_step26
bb_step26:
  %v158 = load i64, ptr %slot25, align 8
  %op159 = add i64 %v158, 1
  store i64 %op159, ptr %slot28, align 8
  %v160 = load i64, ptr %slot28, align 8
  %v161 = load i64, ptr %slot1, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !4, !noalias !3
  %v163 = load i64, ptr %slot6, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 18446744073709551615, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot18, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 2, ptr %p166, align 8, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot1, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !4, !noalias !3
  store i64 %ld169, ptr %slot29, align 8
  %v170 = load i64, ptr %slot19, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !4, !noalias !3
  store i64 %ld172, ptr %slot30, align 8
  %v173 = load i64, ptr %slot29, align 8
  %v174 = load i64, ptr %slot30, align 8
  %cmp175 = icmp eq i64 %v173, %v174
  %cv176 = zext i1 %cmp175 to i64
  store i64 %cv176, ptr %slot31, align 8
  %v177 = load i64, ptr %slot31, align 8
  %cond178 = icmp ne i64 %v177, 0
  br i1 %cond178, label %bb_step_limit, label %bb_step30
bb_step30:
  %v179 = load i64, ptr %slot29, align 8
  %op180 = add i64 %v179, 1
  store i64 %op180, ptr %slot32, align 8
  %v181 = load i64, ptr %slot32, align 8
  %v182 = load i64, ptr %slot1, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !4, !noalias !3
  %v184 = load i64, ptr %slot6, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot33, align 8
  %v187 = load i64, ptr %slot5, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot34, align 8
  %v190 = load i64, ptr %slot33, align 8
  %cmp191 = icmp eq i64 %v190, 0
  %cv192 = zext i1 %cmp191 to i64
  store i64 %cv192, ptr %slot35, align 8
  %v193 = load i64, ptr %slot35, align 8
  %cond194 = icmp ne i64 %v193, 0
  br i1 %cond194, label %bb_division33, label %bb_nonzero33
bb_division33:
  %v195 = load i64, ptr %slot1, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %v197 = load i64, ptr %slot34, align 8
  %v198 = load i64, ptr %slot33, align 8
  call void @myl_qbe_fail_division(ptr %p196, i64 4, i64 %v197, i64 %v198)
  br label %bb_failure
bb_nonzero33:
  %v199 = load i64, ptr %slot34, align 8
  %cmp200 = icmp eq i64 %v199, 9223372036854775808
  %cv201 = zext i1 %cmp200 to i64
  store i64 %cv201, ptr %slot36, align 8
  %v202 = load i64, ptr %slot33, align 8
  %cmp203 = icmp eq i64 %v202, 18446744073709551615
  %cv204 = zext i1 %cmp203 to i64
  store i64 %cv204, ptr %slot37, align 8
  %v205 = load i64, ptr %slot36, align 8
  %v206 = load i64, ptr %slot37, align 8
  %op207 = and i64 %v205, %v206
  store i64 %op207, ptr %slot38, align 8
  %v208 = load i64, ptr %slot38, align 8
  %neg209 = sub i64 0, %v208
  store i64 %neg209, ptr %slot39, align 8
  %v210 = load i64, ptr %slot33, align 8
  %op211 = xor i64 %v210, 1
  store i64 %op211, ptr %slot40, align 8
  %v212 = load i64, ptr %slot40, align 8
  %v213 = load i64, ptr %slot39, align 8
  %op214 = and i64 %v212, %v213
  store i64 %op214, ptr %slot40, align 8
  %v215 = load i64, ptr %slot33, align 8
  %v216 = load i64, ptr %slot40, align 8
  %op217 = xor i64 %v215, %v216
  store i64 %op217, ptr %slot41, align 8
  %v218 = load i64, ptr %slot34, align 8
  %v219 = load i64, ptr %slot41, align 8
  %op220 = srem i64 %v218, %v219
  store i64 %op220, ptr %slot42, align 8
  %v221 = load i64, ptr %slot42, align 8
  %v222 = load i64, ptr %slot5, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot18, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 3, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot1, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !4, !noalias !3
  store i64 %ld228, ptr %slot43, align 8
  %v229 = load i64, ptr %slot19, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !4, !noalias !3
  store i64 %ld231, ptr %slot44, align 8
  %v232 = load i64, ptr %slot43, align 8
  %v233 = load i64, ptr %slot44, align 8
  %cmp234 = icmp eq i64 %v232, %v233
  %cv235 = zext i1 %cmp234 to i64
  store i64 %cv235, ptr %slot45, align 8
  %v236 = load i64, ptr %slot45, align 8
  %cond237 = icmp ne i64 %v236, 0
  br i1 %cond237, label %bb_step_limit, label %bb_step44
bb_step44:
  %v238 = load i64, ptr %slot43, align 8
  %op239 = add i64 %v238, 1
  store i64 %op239, ptr %slot46, align 8
  %v240 = load i64, ptr %slot46, align 8
  %v241 = load i64, ptr %slot1, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !4, !noalias !3
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot47, align 8
  %v246 = load i64, ptr %slot12, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot48, align 8
  %v249 = load i64, ptr %slot48, align 8
  %v250 = load i64, ptr %slot13, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i64 %v249, ptr %p251, align 8, !alias.scope !4, !noalias !3
  %v252 = load i64, ptr %slot7, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !4, !noalias !3
  store i64 %ld254, ptr %slot49, align 8
  %v255 = load i64, ptr %slot49, align 8
  %op256 = sub i64 %v255, 1
  store i64 %op256, ptr %slot50, align 8
  %v257 = load i64, ptr %slot50, align 8
  %v258 = load i64, ptr %slot7, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !4, !noalias !3
  %v260 = load i64, ptr %slot47, align 8
  ret i64 %v260
bb_step_limit:
  %v261 = load i64, ptr %slot1, align 8
  %p262 = inttoptr i64 %v261 to ptr
  call void @myl_qbe_fail_step(ptr %p262)
  br label %bb_failure
bb_failure:
  %v263 = load i64, ptr %slot12, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot51, align 8
  %v266 = load i64, ptr %slot51, align 8
  %v267 = load i64, ptr %slot13, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !4, !noalias !3
  %v269 = load i64, ptr %slot7, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !4, !noalias !3
  store i64 %ld271, ptr %slot52, align 8
  %v272 = load i64, ptr %slot52, align 8
  %op273 = sub i64 %v272, 1
  store i64 %op273, ptr %slot53, align 8
  %v274 = load i64, ptr %slot53, align 8
  %v275 = load i64, ptr %slot7, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i64 %v274, ptr %p276, align 8, !alias.scope !4, !noalias !3
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2_meta = external global i8, align 8

declare void @myl_qbe_fail_division(ptr, i64, i64, i64) cold
declare void @myl_qbe_fail_frame(ptr) cold
declare void @myl_qbe_fail_step(ptr) cold

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
