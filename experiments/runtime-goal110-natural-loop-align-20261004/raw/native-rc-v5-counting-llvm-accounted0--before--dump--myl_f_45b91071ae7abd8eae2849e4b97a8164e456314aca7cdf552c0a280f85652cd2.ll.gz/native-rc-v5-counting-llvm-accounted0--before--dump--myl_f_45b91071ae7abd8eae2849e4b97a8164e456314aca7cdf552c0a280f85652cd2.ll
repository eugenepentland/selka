target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v19 = load i64, ptr %slot1, align 8
  %op20 = add i64 %v19, 32
  store i64 %op20, ptr %slot3, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot4, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot5, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot6, align 8
  %v27 = load i64, ptr %slot2, align 8
  %v28 = load i64, ptr %slot4, align 8
  %p29 = inttoptr i64 %v28 to ptr
  store i64 %v27, ptr %p29, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v30 = load i64, ptr %slot4, align 8
  %p31 = inttoptr i64 %v30 to ptr
  %ld32 = load i64, ptr %p31, align 8, !alias.scope !3, !noalias !4
  store i64 %ld32, ptr %slot7, align 8
  %v33 = load i64, ptr %slot7, align 8
  %v34 = load i64, ptr %slot5, align 8
  %p35 = inttoptr i64 %v34 to ptr
  store i64 %v33, ptr %p35, align 8, !alias.scope !3, !noalias !4
  %v36 = load i64, ptr %slot6, align 8
  %p37 = inttoptr i64 %v36 to ptr
  store i64 18446744073709551615, ptr %p37, align 8, !alias.scope !3, !noalias !4
  %v38 = load i64, ptr %slot6, align 8
  %p39 = inttoptr i64 %v38 to ptr
  %ld40 = load i64, ptr %p39, align 8, !alias.scope !3, !noalias !4
  store i64 %ld40, ptr %slot8, align 8
  %v41 = load i64, ptr %slot5, align 8
  %p42 = inttoptr i64 %v41 to ptr
  %ld43 = load i64, ptr %p42, align 8, !alias.scope !3, !noalias !4
  store i64 %ld43, ptr %slot9, align 8
  %v44 = load i64, ptr %slot8, align 8
  %cmp45 = icmp eq i64 %v44, 0
  %cv46 = zext i1 %cmp45 to i64
  store i64 %cv46, ptr %slot10, align 8
  %v47 = load i64, ptr %slot10, align 8
  %cond48 = icmp ne i64 %v47, 0
  br i1 %cond48, label %bb_division3, label %bb_nonzero3
bb_division3:
  %v49 = load i64, ptr %slot1, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %v51 = load i64, ptr %slot9, align 8
  %v52 = load i64, ptr %slot8, align 8
  call void @myl_qbe_fail_division(ptr %p50, i64 4, i64 %v51, i64 %v52) nomerge, !dbg !110
  unreachable
bb_nonzero3:
  %v53 = load i64, ptr %slot9, align 8
  %cmp54 = icmp eq i64 %v53, 9223372036854775808
  %cv55 = zext i1 %cmp54 to i64
  store i64 %cv55, ptr %slot11, align 8
  %v56 = load i64, ptr %slot8, align 8
  %cmp57 = icmp eq i64 %v56, 18446744073709551615
  %cv58 = zext i1 %cmp57 to i64
  store i64 %cv58, ptr %slot12, align 8
  %v59 = load i64, ptr %slot11, align 8
  %v60 = load i64, ptr %slot12, align 8
  %op61 = and i64 %v59, %v60
  store i64 %op61, ptr %slot13, align 8
  %v62 = load i64, ptr %slot13, align 8
  %neg63 = sub i64 0, %v62
  store i64 %neg63, ptr %slot14, align 8
  %v64 = load i64, ptr %slot8, align 8
  %op65 = xor i64 %v64, 1
  store i64 %op65, ptr %slot15, align 8
  %v66 = load i64, ptr %slot15, align 8
  %v67 = load i64, ptr %slot14, align 8
  %op68 = and i64 %v66, %v67
  store i64 %op68, ptr %slot15, align 8
  %v69 = load i64, ptr %slot8, align 8
  %v70 = load i64, ptr %slot15, align 8
  %op71 = xor i64 %v69, %v70
  store i64 %op71, ptr %slot16, align 8
  %v72 = load i64, ptr %slot9, align 8
  %v73 = load i64, ptr %slot16, align 8
  %op74 = srem i64 %v72, %v73
  store i64 %op74, ptr %slot17, align 8
  %v75 = load i64, ptr %slot17, align 8
  %v76 = load i64, ptr %slot5, align 8
  %p77 = inttoptr i64 %v76 to ptr
  store i64 %v75, ptr %p77, align 8, !alias.scope !3, !noalias !4
  %v78 = load i64, ptr %slot5, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot18, align 8
  %v81 = load i64, ptr %slot18, align 8
  ret i64 %v81
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2", linkageName: "myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8641939061737324218, i64 0, !"myl_f_45b91071ae7abd8eae2849e4b97a8164e456314aca7cdf552c0a280f85652cd2"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
