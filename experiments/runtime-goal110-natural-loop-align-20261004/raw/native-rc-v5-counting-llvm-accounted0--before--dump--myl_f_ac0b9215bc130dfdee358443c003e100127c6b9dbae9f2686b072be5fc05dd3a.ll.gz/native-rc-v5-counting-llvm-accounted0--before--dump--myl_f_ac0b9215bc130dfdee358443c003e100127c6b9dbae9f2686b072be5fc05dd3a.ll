target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v173 = load i64, ptr %slot1, align 8
  %op174 = add i64 %v173, 32
  store i64 %op174, ptr %slot5, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot6, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot7, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot8, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot9, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot10, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot11, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot12, align 8
  %mem189 = alloca i8, i64 8, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot13, align 8
  %mem191 = alloca i8, i64 8, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot14, align 8
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot15, align 8
  %v195 = load i64, ptr %slot2, align 8
  %v196 = load i64, ptr %slot6, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot3, align 8
  %v199 = load i64, ptr %slot7, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot4, align 8
  %v202 = load i64, ptr %slot8, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v204 = load i64, ptr %slot6, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot16, align 8
  %v207 = load i64, ptr %slot16, align 8
  %v208 = load i64, ptr %slot14, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i64 %v207, ptr %p209, align 8, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot14, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot17, align 8
  %v213 = load i64, ptr %slot9, align 8
  store i64 %v213, ptr %slot18, align 8
  %v214 = load i64, ptr %slot17, align 8
  %v215 = load i64, ptr %slot18, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot14, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 0, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot14, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot19, align 8
  %v222 = load i64, ptr %slot10, align 8
  store i64 %v222, ptr %slot20, align 8
  %v223 = load i64, ptr %slot19, align 8
  %v224 = load i64, ptr %slot20, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot7, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot21, align 8
  %v229 = load i64, ptr %slot21, align 8
  %v230 = load i64, ptr %slot14, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot14, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot22, align 8
  %v235 = load i64, ptr %slot11, align 8
  store i64 %v235, ptr %slot23, align 8
  %v236 = load i64, ptr %slot22, align 8
  %v237 = load i64, ptr %slot23, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot10, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot24, align 8
  %v242 = load i64, ptr %slot11, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot25, align 8
  %v245 = load i64, ptr %slot25, align 8
  %v246 = load i64, ptr %slot24, align 8
  %cmp247 = icmp sgt i64 %v245, %v246
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot26, align 8
  %v249 = load i64, ptr %slot25, align 8
  %v250 = load i64, ptr %slot24, align 8
  %op251 = sub i64 %v249, %v250
  store i64 %op251, ptr %slot27, align 8
  %v252 = load i64, ptr %slot27, align 8
  %cmp253 = icmp uge i64 %v252, 16
  %cv254 = zext i1 %cmp253 to i64
  store i64 %cv254, ptr %slot28, align 8
  %v255 = load i64, ptr %slot26, align 8
  %v256 = load i64, ptr %slot28, align 8
  %op257 = and i64 %v255, %v256
  store i64 %op257, ptr %slot29, align 8
  %v258 = load i64, ptr %slot29, align 8
  %cond259 = icmp ne i64 %v258, 0
  br i1 %cond259, label %bb_guard8, label %bb_oi6
bb_guard8:
  %v260 = load i64, ptr %slot24, align 8
  %op261 = add i64 %v260, 1152921504606846976
  store i64 %op261, ptr %slot30, align 8
  %v262 = load i64, ptr %slot30, align 8
  %cmp263 = icmp ule i64 %v262, 2305843009213693952
  %cv264 = zext i1 %cmp263 to i64
  store i64 %cv264, ptr %slot31, align 8
  %v265 = load i64, ptr %slot31, align 8
  %cond266 = icmp ne i64 %v265, 0
  br i1 %cond266, label %bb_guard14, label %bb_oi6
bb_guard14:
  %v267 = load i64, ptr %slot25, align 8
  %op268 = add i64 %v267, 1152921504606846976
  store i64 %op268, ptr %slot32, align 8
  %v269 = load i64, ptr %slot32, align 8
  %cmp270 = icmp ule i64 %v269, 2305843009213693952
  %cv271 = zext i1 %cmp270 to i64
  store i64 %cv271, ptr %slot33, align 8
  %v272 = load i64, ptr %slot33, align 8
  %cond273 = icmp ne i64 %v272, 0
  br i1 %cond273, label %bb_guard16, label %bb_oi6
bb_guard16:
  br label %bb_fi6
bb_fi6:
  %v274 = load i64, ptr %slot10, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot34, align 8
  %v277 = load i64, ptr %slot34, align 8
  %v278 = load i64, ptr %slot14, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot11, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot35, align 8
  %v283 = load i64, ptr %slot35, align 8
  %v284 = load i64, ptr %slot15, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i64 %v283, ptr %p285, align 8, !alias.scope !3, !noalias !4
  %v286 = load i64, ptr %slot15, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %ld288 = load i64, ptr %p287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld288, ptr %slot36, align 8
  %v289 = load i64, ptr %slot14, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot37, align 8
  %v292 = load i64, ptr %slot37, align 8
  %v293 = load i64, ptr %slot36, align 8
  %cmp294 = icmp slt i64 %v292, %v293
  %cv295 = zext i1 %cmp294 to i64
  store i64 %cv295, ptr %slot38, align 8
  %v296 = load i64, ptr %slot38, align 8
  %v297 = load i64, ptr %slot14, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot14, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot39, align 8
  %v302 = load i64, ptr %slot39, align 8
  %cond303 = icmp ne i64 %v302, 0
  br i1 %cond303, label %bb_next24, label %bb_i34
bb_next24:
  %v304 = load i64, ptr %slot10, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot40, align 8
  %v307 = load i64, ptr %slot40, align 8
  %v308 = load i64, ptr %slot14, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot15, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 2, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot15, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot41, align 8
  %v315 = load i64, ptr %slot14, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot42, align 8
  %v318 = load i64, ptr %slot41, align 8
  %cmp319 = icmp eq i64 %v318, 0
  %cv320 = zext i1 %cmp319 to i64
  store i64 %cv320, ptr %slot43, align 8
  %v321 = load i64, ptr %slot43, align 8
  %cond322 = icmp ne i64 %v321, 0
  br i1 %cond322, label %bb_division27, label %bb_nonzero27
bb_division27:
  %v323 = load i64, ptr %slot1, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %v325 = load i64, ptr %slot42, align 8
  %v326 = load i64, ptr %slot41, align 8
  call void @myl_qbe_fail_division(ptr %p324, i64 6, i64 %v325, i64 %v326) nomerge, !dbg !110
  unreachable
bb_nonzero27:
  %v327 = load i64, ptr %slot42, align 8
  %cmp328 = icmp eq i64 %v327, 9223372036854775808
  %cv329 = zext i1 %cmp328 to i64
  store i64 %cv329, ptr %slot44, align 8
  %v330 = load i64, ptr %slot41, align 8
  %cmp331 = icmp eq i64 %v330, 18446744073709551615
  %cv332 = zext i1 %cmp331 to i64
  store i64 %cv332, ptr %slot45, align 8
  %v333 = load i64, ptr %slot44, align 8
  %v334 = load i64, ptr %slot45, align 8
  %op335 = and i64 %v333, %v334
  store i64 %op335, ptr %slot46, align 8
  %v336 = load i64, ptr %slot46, align 8
  %neg337 = sub i64 0, %v336
  store i64 %neg337, ptr %slot47, align 8
  %v338 = load i64, ptr %slot41, align 8
  %op339 = xor i64 %v338, 1
  store i64 %op339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot48, align 8
  %v341 = load i64, ptr %slot47, align 8
  %op342 = and i64 %v340, %v341
  store i64 %op342, ptr %slot48, align 8
  %v343 = load i64, ptr %slot41, align 8
  %v344 = load i64, ptr %slot48, align 8
  %op345 = xor i64 %v343, %v344
  store i64 %op345, ptr %slot49, align 8
  %v346 = load i64, ptr %slot42, align 8
  %v347 = load i64, ptr %slot49, align 8
  %op348 = srem i64 %v346, %v347
  store i64 %op348, ptr %slot50, align 8
  %v349 = load i64, ptr %slot50, align 8
  %cmp350 = icmp ne i64 %v349, 0
  %cv351 = zext i1 %cmp350 to i64
  store i64 %cv351, ptr %slot51, align 8
  %v352 = load i64, ptr %slot50, align 8
  %v353 = load i64, ptr %slot49, align 8
  %op354 = xor i64 %v352, %v353
  store i64 %op354, ptr %slot52, align 8
  %v355 = load i64, ptr %slot52, align 8
  %cmp356 = icmp slt i64 %v355, 0
  %cv357 = zext i1 %cmp356 to i64
  store i64 %cv357, ptr %slot53, align 8
  %v358 = load i64, ptr %slot51, align 8
  %v359 = load i64, ptr %slot53, align 8
  %op360 = and i64 %v358, %v359
  store i64 %op360, ptr %slot54, align 8
  %v361 = load i64, ptr %slot54, align 8
  %neg362 = sub i64 0, %v361
  store i64 %neg362, ptr %slot55, align 8
  %v363 = load i64, ptr %slot49, align 8
  %v364 = load i64, ptr %slot55, align 8
  %op365 = and i64 %v363, %v364
  store i64 %op365, ptr %slot56, align 8
  %v366 = load i64, ptr %slot50, align 8
  %v367 = load i64, ptr %slot56, align 8
  %op368 = add i64 %v366, %v367
  store i64 %op368, ptr %slot50, align 8
  %v369 = load i64, ptr %slot50, align 8
  %v370 = load i64, ptr %slot14, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot8, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot57, align 8
  %v375 = load i64, ptr %slot57, align 8
  %v376 = load i64, ptr %slot15, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 %v375, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot15, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot58, align 8
  %v381 = load i64, ptr %slot14, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot59, align 8
  %v384 = load i64, ptr %slot59, align 8
  %v385 = load i64, ptr %slot58, align 8
  %cmp386 = icmp eq i64 %v384, %v385
  %cv387 = zext i1 %cmp386 to i64
  store i64 %cv387, ptr %slot60, align 8
  %v388 = load i64, ptr %slot60, align 8
  %v389 = load i64, ptr %slot14, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 %v388, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot14, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot61, align 8
  %v394 = load i64, ptr %slot61, align 8
  %cond395 = icmp ne i64 %v394, 0
  br i1 %cond395, label %bb_next46, label %bb_fi19
bb_next46:
  %v396 = load i64, ptr %slot14, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 1, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot14, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld400, ptr %slot62, align 8
  %v401 = load i64, ptr %slot12, align 8
  store i64 %v401, ptr %slot63, align 8
  %v402 = load i64, ptr %slot62, align 8
  %v403 = load i64, ptr %slot63, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v405 = load i64, ptr %slot14, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 0, ptr %p406, align 8, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot14, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot64, align 8
  %v410 = load i64, ptr %slot12, align 8
  store i64 %v410, ptr %slot65, align 8
  %v411 = load i64, ptr %slot64, align 8
  %v412 = load i64, ptr %slot65, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v414 = load i64, ptr %slot12, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot66, align 8
  %v417 = load i64, ptr %slot66, align 8
  %v418 = load i64, ptr %slot14, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot14, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot67, align 8
  %v423 = load i64, ptr %slot13, align 8
  store i64 %v423, ptr %slot68, align 8
  %v424 = load i64, ptr %slot67, align 8
  %v425 = load i64, ptr %slot68, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i64 %v424, ptr %p426, align 8, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot9, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %ld429 = load i64, ptr %p428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld429, ptr %slot69, align 8
  %v430 = load i64, ptr %slot69, align 8
  %v431 = load i64, ptr %slot14, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i64 %v430, ptr %p432, align 8, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot13, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i64, ptr %p434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld435, ptr %slot70, align 8
  %v436 = load i64, ptr %slot70, align 8
  %v437 = load i64, ptr %slot15, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i64 %v436, ptr %p438, align 8, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot15, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i64, ptr %p440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld441, ptr %slot71, align 8
  %v442 = load i64, ptr %slot14, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %ld444 = load i64, ptr %p443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld444, ptr %slot72, align 8
  %v445 = load i64, ptr %slot72, align 8
  %v446 = load i64, ptr %slot71, align 8
  %ovpair448 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v445, i64 %v446)
  %op447 = extractvalue { i64, i1 } %ovpair448, 0
  %ov449 = extractvalue { i64, i1 } %ovpair448, 1
  store i64 %op447, ptr %slot73, align 8
  %v450 = load i64, ptr %slot72, align 8
  %v451 = load i64, ptr %slot73, align 8
  %op452 = xor i64 %v450, %v451
  store i64 %op452, ptr %slot74, align 8
  %v453 = load i64, ptr %slot71, align 8
  %v454 = load i64, ptr %slot73, align 8
  %op455 = xor i64 %v453, %v454
  store i64 %op455, ptr %slot75, align 8
  %v456 = load i64, ptr %slot74, align 8
  %v457 = load i64, ptr %slot75, align 8
  %op458 = and i64 %v456, %v457
  store i64 %op458, ptr %slot76, align 8
  %cv459 = zext i1 %ov449 to i64
  store i64 %cv459, ptr %slot77, align 8
  %v460 = load i64, ptr %slot77, align 8
  %cond461 = icmp ne i64 %v460, 0
  br i1 %cond461, label %bb_overflow57, label %bb_checked57
bb_overflow57:
  %v462 = load i64, ptr %slot1, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %v464 = load i64, ptr %slot72, align 8
  %v465 = load i64, ptr %slot71, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p463, i64 0, i64 %v464, i64 %v465, i64 64) nomerge, !dbg !112
  unreachable
bb_checked57:
  %v466 = load i64, ptr %slot73, align 8
  %v467 = load i64, ptr %slot14, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i64 %v466, ptr %p468, align 8, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot15, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i64 1000000007, ptr %p470, align 8, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot15, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot78, align 8
  %v474 = load i64, ptr %slot14, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot79, align 8
  %v477 = load i64, ptr %slot78, align 8
  %cmp478 = icmp eq i64 %v477, 0
  %cv479 = zext i1 %cmp478 to i64
  store i64 %cv479, ptr %slot80, align 8
  %v480 = load i64, ptr %slot80, align 8
  %cond481 = icmp ne i64 %v480, 0
  br i1 %cond481, label %bb_division64, label %bb_nonzero64
bb_division64:
  %v482 = load i64, ptr %slot1, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %v484 = load i64, ptr %slot79, align 8
  %v485 = load i64, ptr %slot78, align 8
  call void @myl_qbe_fail_division(ptr %p483, i64 6, i64 %v484, i64 %v485) nomerge, !dbg !114
  unreachable
bb_nonzero64:
  %v486 = load i64, ptr %slot79, align 8
  %cmp487 = icmp eq i64 %v486, 9223372036854775808
  %cv488 = zext i1 %cmp487 to i64
  store i64 %cv488, ptr %slot81, align 8
  %v489 = load i64, ptr %slot78, align 8
  %cmp490 = icmp eq i64 %v489, 18446744073709551615
  %cv491 = zext i1 %cmp490 to i64
  store i64 %cv491, ptr %slot82, align 8
  %v492 = load i64, ptr %slot81, align 8
  %v493 = load i64, ptr %slot82, align 8
  %op494 = and i64 %v492, %v493
  store i64 %op494, ptr %slot83, align 8
  %v495 = load i64, ptr %slot83, align 8
  %neg496 = sub i64 0, %v495
  store i64 %neg496, ptr %slot84, align 8
  %v497 = load i64, ptr %slot78, align 8
  %op498 = xor i64 %v497, 1
  store i64 %op498, ptr %slot85, align 8
  %v499 = load i64, ptr %slot85, align 8
  %v500 = load i64, ptr %slot84, align 8
  %op501 = and i64 %v499, %v500
  store i64 %op501, ptr %slot85, align 8
  %v502 = load i64, ptr %slot78, align 8
  %v503 = load i64, ptr %slot85, align 8
  %op504 = xor i64 %v502, %v503
  store i64 %op504, ptr %slot86, align 8
  %v505 = load i64, ptr %slot79, align 8
  %v506 = load i64, ptr %slot86, align 8
  %op507 = srem i64 %v505, %v506
  store i64 %op507, ptr %slot87, align 8
  %v508 = load i64, ptr %slot87, align 8
  %cmp509 = icmp ne i64 %v508, 0
  %cv510 = zext i1 %cmp509 to i64
  store i64 %cv510, ptr %slot88, align 8
  %v511 = load i64, ptr %slot87, align 8
  %v512 = load i64, ptr %slot86, align 8
  %op513 = xor i64 %v511, %v512
  store i64 %op513, ptr %slot89, align 8
  %v514 = load i64, ptr %slot89, align 8
  %cmp515 = icmp slt i64 %v514, 0
  %cv516 = zext i1 %cmp515 to i64
  store i64 %cv516, ptr %slot90, align 8
  %v517 = load i64, ptr %slot88, align 8
  %v518 = load i64, ptr %slot90, align 8
  %op519 = and i64 %v517, %v518
  store i64 %op519, ptr %slot91, align 8
  %v520 = load i64, ptr %slot91, align 8
  %neg521 = sub i64 0, %v520
  store i64 %neg521, ptr %slot92, align 8
  %v522 = load i64, ptr %slot86, align 8
  %v523 = load i64, ptr %slot92, align 8
  %op524 = and i64 %v522, %v523
  store i64 %op524, ptr %slot93, align 8
  %v525 = load i64, ptr %slot87, align 8
  %v526 = load i64, ptr %slot93, align 8
  %op527 = add i64 %v525, %v526
  store i64 %op527, ptr %slot87, align 8
  %v528 = load i64, ptr %slot87, align 8
  %v529 = load i64, ptr %slot14, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i64 %v528, ptr %p530, align 8, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot14, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot94, align 8
  %v534 = load i64, ptr %slot9, align 8
  store i64 %v534, ptr %slot95, align 8
  %v535 = load i64, ptr %slot94, align 8
  %v536 = load i64, ptr %slot95, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 %v535, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot10, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot96, align 8
  %v541 = load i64, ptr %slot96, align 8
  %v542 = load i64, ptr %slot14, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot15, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 1, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot15, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot97, align 8
  %v549 = load i64, ptr %slot14, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %ld551 = load i64, ptr %p550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld551, ptr %slot98, align 8
  %v552 = load i64, ptr %slot98, align 8
  %v553 = load i64, ptr %slot97, align 8
  %op554 = add i64 %v552, %v553
  store i64 %op554, ptr %slot99, align 8
  %v555 = load i64, ptr %slot99, align 8
  %v556 = load i64, ptr %slot14, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i64 %v555, ptr %p557, align 8, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot14, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %ld560 = load i64, ptr %p559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld560, ptr %slot100, align 8
  %v561 = load i64, ptr %slot10, align 8
  store i64 %v561, ptr %slot101, align 8
  %v562 = load i64, ptr %slot100, align 8
  %v563 = load i64, ptr %slot101, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i64 %v562, ptr %p564, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v565 = load i64, ptr %slot10, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i64, ptr %p566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld567, ptr %slot102, align 8
  %v568 = load i64, ptr %slot102, align 8
  %v569 = load i64, ptr %slot14, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 %v568, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot11, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot103, align 8
  %v574 = load i64, ptr %slot103, align 8
  %v575 = load i64, ptr %slot15, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot15, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot104, align 8
  %v580 = load i64, ptr %slot14, align 8
  %p581 = inttoptr i64 %v580 to ptr
  %ld582 = load i64, ptr %p581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld582, ptr %slot105, align 8
  %v583 = load i64, ptr %slot105, align 8
  %v584 = load i64, ptr %slot104, align 8
  %cmp585 = icmp slt i64 %v583, %v584
  %cv586 = zext i1 %cmp585 to i64
  store i64 %cv586, ptr %slot106, align 8
  %v587 = load i64, ptr %slot106, align 8
  %v588 = load i64, ptr %slot14, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i64 %v587, ptr %p589, align 8, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot14, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %ld592 = load i64, ptr %p591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld592, ptr %slot107, align 8
  %v593 = load i64, ptr %slot107, align 8
  %cond594 = icmp ne i64 %v593, 0
  br i1 %cond594, label %bb_next92, label %bb_i34
bb_next92:
  %v595 = load i64, ptr %slot10, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot108, align 8
  %v598 = load i64, ptr %slot108, align 8
  %v599 = load i64, ptr %slot14, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i64 %v598, ptr %p600, align 8, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot15, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i64 2, ptr %p602, align 8, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot15, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %ld605 = load i64, ptr %p604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld605, ptr %slot109, align 8
  %v606 = load i64, ptr %slot14, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %ld608 = load i64, ptr %p607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld608, ptr %slot110, align 8
  %v609 = load i64, ptr %slot109, align 8
  %cmp610 = icmp eq i64 %v609, 0
  %cv611 = zext i1 %cmp610 to i64
  store i64 %cv611, ptr %slot111, align 8
  %v612 = load i64, ptr %slot111, align 8
  %cond613 = icmp ne i64 %v612, 0
  br i1 %cond613, label %bb_division95, label %bb_nonzero95
bb_division95:
  %v614 = load i64, ptr %slot1, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %v616 = load i64, ptr %slot110, align 8
  %v617 = load i64, ptr %slot109, align 8
  call void @myl_qbe_fail_division(ptr %p615, i64 6, i64 %v616, i64 %v617) nomerge, !dbg !110
  unreachable
bb_nonzero95:
  %v618 = load i64, ptr %slot110, align 8
  %cmp619 = icmp eq i64 %v618, 9223372036854775808
  %cv620 = zext i1 %cmp619 to i64
  store i64 %cv620, ptr %slot112, align 8
  %v621 = load i64, ptr %slot109, align 8
  %cmp622 = icmp eq i64 %v621, 18446744073709551615
  %cv623 = zext i1 %cmp622 to i64
  store i64 %cv623, ptr %slot113, align 8
  %v624 = load i64, ptr %slot112, align 8
  %v625 = load i64, ptr %slot113, align 8
  %op626 = and i64 %v624, %v625
  store i64 %op626, ptr %slot114, align 8
  %v627 = load i64, ptr %slot114, align 8
  %neg628 = sub i64 0, %v627
  store i64 %neg628, ptr %slot115, align 8
  %v629 = load i64, ptr %slot109, align 8
  %op630 = xor i64 %v629, 1
  store i64 %op630, ptr %slot116, align 8
  %v631 = load i64, ptr %slot116, align 8
  %v632 = load i64, ptr %slot115, align 8
  %op633 = and i64 %v631, %v632
  store i64 %op633, ptr %slot116, align 8
  %v634 = load i64, ptr %slot109, align 8
  %v635 = load i64, ptr %slot116, align 8
  %op636 = xor i64 %v634, %v635
  store i64 %op636, ptr %slot117, align 8
  %v637 = load i64, ptr %slot110, align 8
  %v638 = load i64, ptr %slot117, align 8
  %op639 = srem i64 %v637, %v638
  store i64 %op639, ptr %slot118, align 8
  %v640 = load i64, ptr %slot118, align 8
  %cmp641 = icmp ne i64 %v640, 0
  %cv642 = zext i1 %cmp641 to i64
  store i64 %cv642, ptr %slot119, align 8
  %v643 = load i64, ptr %slot118, align 8
  %v644 = load i64, ptr %slot117, align 8
  %op645 = xor i64 %v643, %v644
  store i64 %op645, ptr %slot120, align 8
  %v646 = load i64, ptr %slot120, align 8
  %cmp647 = icmp slt i64 %v646, 0
  %cv648 = zext i1 %cmp647 to i64
  store i64 %cv648, ptr %slot121, align 8
  %v649 = load i64, ptr %slot119, align 8
  %v650 = load i64, ptr %slot121, align 8
  %op651 = and i64 %v649, %v650
  store i64 %op651, ptr %slot122, align 8
  %v652 = load i64, ptr %slot122, align 8
  %neg653 = sub i64 0, %v652
  store i64 %neg653, ptr %slot123, align 8
  %v654 = load i64, ptr %slot117, align 8
  %v655 = load i64, ptr %slot123, align 8
  %op656 = and i64 %v654, %v655
  store i64 %op656, ptr %slot124, align 8
  %v657 = load i64, ptr %slot118, align 8
  %v658 = load i64, ptr %slot124, align 8
  %op659 = add i64 %v657, %v658
  store i64 %op659, ptr %slot118, align 8
  %v660 = load i64, ptr %slot118, align 8
  %v661 = load i64, ptr %slot14, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot8, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot125, align 8
  %v666 = load i64, ptr %slot125, align 8
  %v667 = load i64, ptr %slot15, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 %v666, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot15, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %ld671 = load i64, ptr %p670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld671, ptr %slot126, align 8
  %v672 = load i64, ptr %slot14, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld674, ptr %slot127, align 8
  %v675 = load i64, ptr %slot127, align 8
  %v676 = load i64, ptr %slot126, align 8
  %cmp677 = icmp eq i64 %v675, %v676
  %cv678 = zext i1 %cmp677 to i64
  store i64 %cv678, ptr %slot128, align 8
  %v679 = load i64, ptr %slot128, align 8
  %v680 = load i64, ptr %slot14, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot14, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot129, align 8
  %v685 = load i64, ptr %slot129, align 8
  %cond686 = icmp ne i64 %v685, 0
  br i1 %cond686, label %bb_next114, label %bb_i19
bb_next114:
  %v687 = load i64, ptr %slot14, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i64 1, ptr %p688, align 8, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot14, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot130, align 8
  %v692 = load i64, ptr %slot12, align 8
  store i64 %v692, ptr %slot131, align 8
  %v693 = load i64, ptr %slot130, align 8
  %v694 = load i64, ptr %slot131, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 %v693, ptr %p695, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v696 = load i64, ptr %slot14, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 0, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot14, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot132, align 8
  %v701 = load i64, ptr %slot12, align 8
  store i64 %v701, ptr %slot133, align 8
  %v702 = load i64, ptr %slot132, align 8
  %v703 = load i64, ptr %slot133, align 8
  %p704 = inttoptr i64 %v703 to ptr
  store i64 %v702, ptr %p704, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v705 = load i64, ptr %slot12, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i64, ptr %p706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld707, ptr %slot134, align 8
  %v708 = load i64, ptr %slot134, align 8
  %v709 = load i64, ptr %slot14, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i64 %v708, ptr %p710, align 8, !alias.scope !3, !noalias !4
  %v711 = load i64, ptr %slot14, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %ld713 = load i64, ptr %p712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld713, ptr %slot135, align 8
  %v714 = load i64, ptr %slot13, align 8
  store i64 %v714, ptr %slot136, align 8
  %v715 = load i64, ptr %slot135, align 8
  %v716 = load i64, ptr %slot136, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i64 %v715, ptr %p717, align 8, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot9, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %ld720 = load i64, ptr %p719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld720, ptr %slot137, align 8
  %v721 = load i64, ptr %slot137, align 8
  %v722 = load i64, ptr %slot14, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 %v721, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot13, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i64, ptr %p725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld726, ptr %slot138, align 8
  %v727 = load i64, ptr %slot138, align 8
  %v728 = load i64, ptr %slot15, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i64 %v727, ptr %p729, align 8, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot15, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot139, align 8
  %v733 = load i64, ptr %slot14, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %ld735 = load i64, ptr %p734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld735, ptr %slot140, align 8
  %v736 = load i64, ptr %slot140, align 8
  %v737 = load i64, ptr %slot139, align 8
  %ovpair739 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v736, i64 %v737)
  %op738 = extractvalue { i64, i1 } %ovpair739, 0
  %ov740 = extractvalue { i64, i1 } %ovpair739, 1
  store i64 %op738, ptr %slot141, align 8
  %v741 = load i64, ptr %slot140, align 8
  %v742 = load i64, ptr %slot141, align 8
  %op743 = xor i64 %v741, %v742
  store i64 %op743, ptr %slot142, align 8
  %v744 = load i64, ptr %slot139, align 8
  %v745 = load i64, ptr %slot141, align 8
  %op746 = xor i64 %v744, %v745
  store i64 %op746, ptr %slot143, align 8
  %v747 = load i64, ptr %slot142, align 8
  %v748 = load i64, ptr %slot143, align 8
  %op749 = and i64 %v747, %v748
  store i64 %op749, ptr %slot144, align 8
  %cv750 = zext i1 %ov740 to i64
  store i64 %cv750, ptr %slot145, align 8
  %v751 = load i64, ptr %slot145, align 8
  %cond752 = icmp ne i64 %v751, 0
  br i1 %cond752, label %bb_overflow125, label %bb_checked125
bb_overflow125:
  %v753 = load i64, ptr %slot1, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %v755 = load i64, ptr %slot140, align 8
  %v756 = load i64, ptr %slot139, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p754, i64 0, i64 %v755, i64 %v756, i64 64) nomerge, !dbg !112
  unreachable
bb_checked125:
  %v757 = load i64, ptr %slot141, align 8
  %v758 = load i64, ptr %slot14, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i64 %v757, ptr %p759, align 8, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot15, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i64 1000000007, ptr %p761, align 8, !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot15, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %ld764 = load i64, ptr %p763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld764, ptr %slot146, align 8
  %v765 = load i64, ptr %slot14, align 8
  %p766 = inttoptr i64 %v765 to ptr
  %ld767 = load i64, ptr %p766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld767, ptr %slot147, align 8
  %v768 = load i64, ptr %slot146, align 8
  %cmp769 = icmp eq i64 %v768, 0
  %cv770 = zext i1 %cmp769 to i64
  store i64 %cv770, ptr %slot148, align 8
  %v771 = load i64, ptr %slot148, align 8
  %cond772 = icmp ne i64 %v771, 0
  br i1 %cond772, label %bb_division132, label %bb_nonzero132
bb_division132:
  %v773 = load i64, ptr %slot1, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %v775 = load i64, ptr %slot147, align 8
  %v776 = load i64, ptr %slot146, align 8
  call void @myl_qbe_fail_division(ptr %p774, i64 6, i64 %v775, i64 %v776) nomerge, !dbg !114
  unreachable
bb_nonzero132:
  %v777 = load i64, ptr %slot147, align 8
  %cmp778 = icmp eq i64 %v777, 9223372036854775808
  %cv779 = zext i1 %cmp778 to i64
  store i64 %cv779, ptr %slot149, align 8
  %v780 = load i64, ptr %slot146, align 8
  %cmp781 = icmp eq i64 %v780, 18446744073709551615
  %cv782 = zext i1 %cmp781 to i64
  store i64 %cv782, ptr %slot150, align 8
  %v783 = load i64, ptr %slot149, align 8
  %v784 = load i64, ptr %slot150, align 8
  %op785 = and i64 %v783, %v784
  store i64 %op785, ptr %slot151, align 8
  %v786 = load i64, ptr %slot151, align 8
  %neg787 = sub i64 0, %v786
  store i64 %neg787, ptr %slot152, align 8
  %v788 = load i64, ptr %slot146, align 8
  %op789 = xor i64 %v788, 1
  store i64 %op789, ptr %slot153, align 8
  %v790 = load i64, ptr %slot153, align 8
  %v791 = load i64, ptr %slot152, align 8
  %op792 = and i64 %v790, %v791
  store i64 %op792, ptr %slot153, align 8
  %v793 = load i64, ptr %slot146, align 8
  %v794 = load i64, ptr %slot153, align 8
  %op795 = xor i64 %v793, %v794
  store i64 %op795, ptr %slot154, align 8
  %v796 = load i64, ptr %slot147, align 8
  %v797 = load i64, ptr %slot154, align 8
  %op798 = srem i64 %v796, %v797
  store i64 %op798, ptr %slot155, align 8
  %v799 = load i64, ptr %slot155, align 8
  %cmp800 = icmp ne i64 %v799, 0
  %cv801 = zext i1 %cmp800 to i64
  store i64 %cv801, ptr %slot156, align 8
  %v802 = load i64, ptr %slot155, align 8
  %v803 = load i64, ptr %slot154, align 8
  %op804 = xor i64 %v802, %v803
  store i64 %op804, ptr %slot157, align 8
  %v805 = load i64, ptr %slot157, align 8
  %cmp806 = icmp slt i64 %v805, 0
  %cv807 = zext i1 %cmp806 to i64
  store i64 %cv807, ptr %slot158, align 8
  %v808 = load i64, ptr %slot156, align 8
  %v809 = load i64, ptr %slot158, align 8
  %op810 = and i64 %v808, %v809
  store i64 %op810, ptr %slot159, align 8
  %v811 = load i64, ptr %slot159, align 8
  %neg812 = sub i64 0, %v811
  store i64 %neg812, ptr %slot160, align 8
  %v813 = load i64, ptr %slot154, align 8
  %v814 = load i64, ptr %slot160, align 8
  %op815 = and i64 %v813, %v814
  store i64 %op815, ptr %slot161, align 8
  %v816 = load i64, ptr %slot155, align 8
  %v817 = load i64, ptr %slot161, align 8
  %op818 = add i64 %v816, %v817
  store i64 %op818, ptr %slot155, align 8
  %v819 = load i64, ptr %slot155, align 8
  %v820 = load i64, ptr %slot14, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 %v819, ptr %p821, align 8, !alias.scope !3, !noalias !4
  %v822 = load i64, ptr %slot14, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot162, align 8
  %v825 = load i64, ptr %slot9, align 8
  store i64 %v825, ptr %slot163, align 8
  %v826 = load i64, ptr %slot162, align 8
  %v827 = load i64, ptr %slot163, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i64 %v826, ptr %p828, align 8, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot10, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i64, ptr %p830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld831, ptr %slot164, align 8
  %v832 = load i64, ptr %slot164, align 8
  %v833 = load i64, ptr %slot14, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i64 %v832, ptr %p834, align 8, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot15, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i64 1, ptr %p836, align 8, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot15, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld839, ptr %slot165, align 8
  %v840 = load i64, ptr %slot14, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i64, ptr %p841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld842, ptr %slot166, align 8
  %v843 = load i64, ptr %slot166, align 8
  %v844 = load i64, ptr %slot165, align 8
  %op845 = add i64 %v843, %v844
  %ovpair846 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v843, i64 %v844)
  %ov847 = extractvalue { i64, i1 } %ovpair846, 1
  store i64 %op845, ptr %slot167, align 8
  %cv848 = zext i1 %ov847 to i64
  store i64 %cv848, ptr %slot168, align 8
  %v849 = load i64, ptr %slot168, align 8
  %cond850 = icmp ne i64 %v849, 0
  br i1 %cond850, label %bb_overflow151, label %bb_checked151
bb_overflow151:
  %v851 = load i64, ptr %slot1, align 8
  %p852 = inttoptr i64 %v851 to ptr
  %v853 = load i64, ptr %slot166, align 8
  %v854 = load i64, ptr %slot165, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p852, i64 0, i64 %v853, i64 %v854, i64 64) nomerge, !dbg !116
  unreachable
bb_checked151:
  %v855 = load i64, ptr %slot167, align 8
  %v856 = load i64, ptr %slot14, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i64 %v855, ptr %p857, align 8, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot14, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i64, ptr %p859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld860, ptr %slot169, align 8
  %v861 = load i64, ptr %slot10, align 8
  store i64 %v861, ptr %slot170, align 8
  %v862 = load i64, ptr %slot169, align 8
  %v863 = load i64, ptr %slot170, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i64 %v862, ptr %p864, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i34:
  %v865 = load i64, ptr %slot9, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot171, align 8
  %v868 = load i64, ptr %slot171, align 8
  %v869 = load i64, ptr %slot14, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i64 %v868, ptr %p870, align 8, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot14, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %ld873 = load i64, ptr %p872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld873, ptr %slot172, align 8
  %v874 = load i64, ptr %slot172, align 8
  ret i64 %v874
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", linkageName: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4238653121982337121, i64 0, !"myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
