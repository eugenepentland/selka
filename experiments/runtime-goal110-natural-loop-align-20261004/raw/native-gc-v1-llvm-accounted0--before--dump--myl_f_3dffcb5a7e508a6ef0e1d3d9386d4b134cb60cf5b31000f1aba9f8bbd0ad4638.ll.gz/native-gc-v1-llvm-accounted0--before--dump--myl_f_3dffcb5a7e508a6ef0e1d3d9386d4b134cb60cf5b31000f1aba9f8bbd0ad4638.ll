target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v150 = load i64, ptr %slot1, align 8
  %op151 = add i64 %v150, 32
  store i64 %op151, ptr %slot4, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot5, align 8
  %mem154 = alloca i8, i64 8, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot6, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot7, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot8, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot9, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot10, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot11, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot12, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot13, align 8
  %v170 = load i64, ptr %slot2, align 8
  %v171 = load i64, ptr %slot5, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i64 %v170, ptr %p172, align 8, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot3, align 8
  %v174 = load i64, ptr %slot6, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 %v173, ptr %p175, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v176 = load i64, ptr %slot5, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %ld178 = load i64, ptr %p177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld178, ptr %slot14, align 8
  %v179 = load i64, ptr %slot14, align 8
  %v180 = load i64, ptr %slot12, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i64 %v179, ptr %p181, align 8, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot12, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot15, align 8
  %v185 = load i64, ptr %slot15, align 8
  %v186 = load i64, ptr %slot7, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot12, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 0, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot12, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot16, align 8
  %v193 = load i64, ptr %slot16, align 8
  %v194 = load i64, ptr %slot8, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot6, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot17, align 8
  %v199 = load i64, ptr %slot17, align 8
  %v200 = load i64, ptr %slot12, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot12, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot18, align 8
  %v205 = load i64, ptr %slot18, align 8
  %v206 = load i64, ptr %slot9, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot8, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot19, align 8
  %v211 = load i64, ptr %slot9, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot20, align 8
  %v214 = load i64, ptr %slot20, align 8
  %v215 = load i64, ptr %slot19, align 8
  %cmp216 = icmp sgt i64 %v214, %v215
  %cv217 = zext i1 %cmp216 to i64
  store i64 %cv217, ptr %slot21, align 8
  %v218 = load i64, ptr %slot20, align 8
  %v219 = load i64, ptr %slot19, align 8
  %op220 = sub i64 %v218, %v219
  store i64 %op220, ptr %slot22, align 8
  %v221 = load i64, ptr %slot22, align 8
  %cmp222 = icmp uge i64 %v221, 16
  %cv223 = zext i1 %cmp222 to i64
  store i64 %cv223, ptr %slot23, align 8
  %v224 = load i64, ptr %slot21, align 8
  %v225 = load i64, ptr %slot23, align 8
  %op226 = and i64 %v224, %v225
  store i64 %op226, ptr %slot24, align 8
  %v227 = load i64, ptr %slot24, align 8
  %cond228 = icmp ne i64 %v227, 0
  br i1 %cond228, label %bb_guard5, label %bb_oi6
bb_guard5:
  %v229 = load i64, ptr %slot19, align 8
  %op230 = add i64 %v229, 1152921504606846976
  store i64 %op230, ptr %slot25, align 8
  %v231 = load i64, ptr %slot25, align 8
  %cmp232 = icmp ule i64 %v231, 2305843009213693952
  %cv233 = zext i1 %cmp232 to i64
  store i64 %cv233, ptr %slot26, align 8
  %v234 = load i64, ptr %slot26, align 8
  %cond235 = icmp ne i64 %v234, 0
  br i1 %cond235, label %bb_guard11, label %bb_oi6
bb_guard11:
  %v236 = load i64, ptr %slot20, align 8
  %op237 = add i64 %v236, 1152921504606846976
  store i64 %op237, ptr %slot27, align 8
  %v238 = load i64, ptr %slot27, align 8
  %cmp239 = icmp ule i64 %v238, 2305843009213693952
  %cv240 = zext i1 %cmp239 to i64
  store i64 %cv240, ptr %slot28, align 8
  %v241 = load i64, ptr %slot28, align 8
  %cond242 = icmp ne i64 %v241, 0
  br i1 %cond242, label %bb_guard13, label %bb_oi6
bb_guard13:
  br label %bb_fi6
bb_fi6:
  %v243 = load i64, ptr %slot8, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot29, align 8
  %v246 = load i64, ptr %slot29, align 8
  %v247 = load i64, ptr %slot12, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot9, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot30, align 8
  %v252 = load i64, ptr %slot30, align 8
  %v253 = load i64, ptr %slot13, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i64 %v252, ptr %p254, align 8, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot13, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot31, align 8
  %v258 = load i64, ptr %slot12, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot32, align 8
  %v261 = load i64, ptr %slot32, align 8
  %v262 = load i64, ptr %slot31, align 8
  %cmp263 = icmp slt i64 %v261, %v262
  %cv264 = zext i1 %cmp263 to i64
  store i64 %cv264, ptr %slot33, align 8
  %v265 = load i64, ptr %slot33, align 8
  %v266 = load i64, ptr %slot12, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i64 %v265, ptr %p267, align 8, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot12, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot34, align 8
  %v271 = load i64, ptr %slot34, align 8
  %cond272 = icmp ne i64 %v271, 0
  br i1 %cond272, label %bb_next21, label %bb_i35
bb_next21:
  %v273 = load i64, ptr %slot8, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot35, align 8
  %v276 = load i64, ptr %slot35, align 8
  %v277 = load i64, ptr %slot12, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i64 %v276, ptr %p278, align 8, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot13, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i64 3, ptr %p280, align 8, !alias.scope !3, !noalias !4
  %v281 = load i64, ptr %slot13, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot36, align 8
  %v284 = load i64, ptr %slot12, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot37, align 8
  %v287 = load i64, ptr %slot37, align 8
  %op288 = add i64 %v287, 1152921504606846978
  store i64 %op288, ptr %slot38, align 8
  %v289 = load i64, ptr %slot38, align 8
  %v290 = load i64, ptr %slot36, align 8
  %op291 = urem i64 %v289, %v290
  store i64 %op291, ptr %slot39, align 8
  %v292 = load i64, ptr %slot39, align 8
  %v293 = load i64, ptr %slot12, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 %v292, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot13, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 0, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot13, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot40, align 8
  %v300 = load i64, ptr %slot12, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot41, align 8
  %v303 = load i64, ptr %slot41, align 8
  %v304 = load i64, ptr %slot40, align 8
  %cmp305 = icmp eq i64 %v303, %v304
  %cv306 = zext i1 %cmp305 to i64
  store i64 %cv306, ptr %slot42, align 8
  %v307 = load i64, ptr %slot42, align 8
  %v308 = load i64, ptr %slot12, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot12, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld312, ptr %slot43, align 8
  %v313 = load i64, ptr %slot43, align 8
  %cond314 = icmp ne i64 %v313, 0
  br i1 %cond314, label %bb_next30, label %bb_fi20
bb_next30:
  %v315 = load i64, ptr %slot12, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 17, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot12, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot44, align 8
  %v320 = load i64, ptr %slot44, align 8
  %neg321 = sub i64 0, %v320
  store i64 %neg321, ptr %slot45, align 8
  %v322 = load i64, ptr %slot44, align 8
  %cmp323 = icmp eq i64 %v322, 9223372036854775808
  %cv324 = zext i1 %cmp323 to i64
  store i64 %cv324, ptr %slot46, align 8
  %v325 = load i64, ptr %slot46, align 8
  %cond326 = icmp ne i64 %v325, 0
  br i1 %cond326, label %bb_neg_overflow31, label %bb_neg_checked31
bb_neg_overflow31:
  %v327 = load i64, ptr %slot1, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %v329 = load i64, ptr %slot44, align 8
  %call330 = call i64 @myl_qbe_int_neg(ptr %p328, i64 1, i64 64, i64 %v329) nomerge, !dbg !110
  unreachable
bb_neg_checked31:
  %v331 = load i64, ptr %slot45, align 8
  %v332 = load i64, ptr %slot12, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot12, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot47, align 8
  %v337 = load i64, ptr %slot47, align 8
  %v338 = load i64, ptr %slot10, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i64 %v337, ptr %p339, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi20:
  %v340 = load i64, ptr %slot12, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i64 23, ptr %p341, align 8, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot12, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ld344 = load i64, ptr %p343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld344, ptr %slot48, align 8
  %v345 = load i64, ptr %slot48, align 8
  %v346 = load i64, ptr %slot10, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i64 %v345, ptr %p347, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi22
bb_fi22:
  %v348 = load i64, ptr %slot10, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld350, ptr %slot49, align 8
  %v351 = load i64, ptr %slot49, align 8
  %v352 = load i64, ptr %slot12, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 %v351, ptr %p353, align 8, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot12, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot50, align 8
  %v357 = load i64, ptr %slot50, align 8
  %v358 = load i64, ptr %slot11, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i64 %v357, ptr %p359, align 8, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot7, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld362, ptr %slot51, align 8
  %v363 = load i64, ptr %slot51, align 8
  %v364 = load i64, ptr %slot12, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot11, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot52, align 8
  %v369 = load i64, ptr %slot52, align 8
  %v370 = load i64, ptr %slot13, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot13, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot53, align 8
  %v375 = load i64, ptr %slot12, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %ld377 = load i64, ptr %p376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld377, ptr %slot54, align 8
  %v378 = load i64, ptr %slot54, align 8
  %v379 = load i64, ptr %slot53, align 8
  %ovpair381 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v378, i64 %v379)
  %op380 = extractvalue { i64, i1 } %ovpair381, 0
  %ov382 = extractvalue { i64, i1 } %ovpair381, 1
  store i64 %op380, ptr %slot55, align 8
  %v383 = load i64, ptr %slot54, align 8
  %v384 = load i64, ptr %slot55, align 8
  %op385 = xor i64 %v383, %v384
  store i64 %op385, ptr %slot56, align 8
  %v386 = load i64, ptr %slot53, align 8
  %v387 = load i64, ptr %slot55, align 8
  %op388 = xor i64 %v386, %v387
  store i64 %op388, ptr %slot57, align 8
  %v389 = load i64, ptr %slot56, align 8
  %v390 = load i64, ptr %slot57, align 8
  %op391 = and i64 %v389, %v390
  store i64 %op391, ptr %slot58, align 8
  %cv392 = zext i1 %ov382 to i64
  store i64 %cv392, ptr %slot59, align 8
  %v393 = load i64, ptr %slot59, align 8
  %cond394 = icmp ne i64 %v393, 0
  br i1 %cond394, label %bb_overflow41, label %bb_checked41
bb_overflow41:
  %v395 = load i64, ptr %slot1, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %v397 = load i64, ptr %slot54, align 8
  %v398 = load i64, ptr %slot53, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p396, i64 0, i64 %v397, i64 %v398, i64 64) nomerge, !dbg !112
  unreachable
bb_checked41:
  %v399 = load i64, ptr %slot55, align 8
  %v400 = load i64, ptr %slot12, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot13, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i64 1000000007, ptr %p403, align 8, !alias.scope !3, !noalias !4
  %v404 = load i64, ptr %slot13, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %ld406 = load i64, ptr %p405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld406, ptr %slot60, align 8
  %v407 = load i64, ptr %slot12, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot61, align 8
  %v410 = load i64, ptr %slot60, align 8
  %cmp411 = icmp eq i64 %v410, 0
  %cv412 = zext i1 %cmp411 to i64
  store i64 %cv412, ptr %slot62, align 8
  %v413 = load i64, ptr %slot62, align 8
  %cond414 = icmp ne i64 %v413, 0
  br i1 %cond414, label %bb_division48, label %bb_nonzero48
bb_division48:
  %v415 = load i64, ptr %slot1, align 8
  %p416 = inttoptr i64 %v415 to ptr
  %v417 = load i64, ptr %slot61, align 8
  %v418 = load i64, ptr %slot60, align 8
  call void @myl_qbe_fail_division(ptr %p416, i64 6, i64 %v417, i64 %v418) nomerge, !dbg !114
  unreachable
bb_nonzero48:
  %v419 = load i64, ptr %slot61, align 8
  %cmp420 = icmp eq i64 %v419, 9223372036854775808
  %cv421 = zext i1 %cmp420 to i64
  store i64 %cv421, ptr %slot63, align 8
  %v422 = load i64, ptr %slot60, align 8
  %cmp423 = icmp eq i64 %v422, 18446744073709551615
  %cv424 = zext i1 %cmp423 to i64
  store i64 %cv424, ptr %slot64, align 8
  %v425 = load i64, ptr %slot63, align 8
  %v426 = load i64, ptr %slot64, align 8
  %op427 = and i64 %v425, %v426
  store i64 %op427, ptr %slot65, align 8
  %v428 = load i64, ptr %slot65, align 8
  %neg429 = sub i64 0, %v428
  store i64 %neg429, ptr %slot66, align 8
  %v430 = load i64, ptr %slot60, align 8
  %op431 = xor i64 %v430, 1
  store i64 %op431, ptr %slot67, align 8
  %v432 = load i64, ptr %slot67, align 8
  %v433 = load i64, ptr %slot66, align 8
  %op434 = and i64 %v432, %v433
  store i64 %op434, ptr %slot67, align 8
  %v435 = load i64, ptr %slot60, align 8
  %v436 = load i64, ptr %slot67, align 8
  %op437 = xor i64 %v435, %v436
  store i64 %op437, ptr %slot68, align 8
  %v438 = load i64, ptr %slot61, align 8
  %v439 = load i64, ptr %slot68, align 8
  %op440 = srem i64 %v438, %v439
  store i64 %op440, ptr %slot69, align 8
  %v441 = load i64, ptr %slot69, align 8
  %cmp442 = icmp ne i64 %v441, 0
  %cv443 = zext i1 %cmp442 to i64
  store i64 %cv443, ptr %slot70, align 8
  %v444 = load i64, ptr %slot69, align 8
  %v445 = load i64, ptr %slot68, align 8
  %op446 = xor i64 %v444, %v445
  store i64 %op446, ptr %slot71, align 8
  %v447 = load i64, ptr %slot71, align 8
  %cmp448 = icmp slt i64 %v447, 0
  %cv449 = zext i1 %cmp448 to i64
  store i64 %cv449, ptr %slot72, align 8
  %v450 = load i64, ptr %slot70, align 8
  %v451 = load i64, ptr %slot72, align 8
  %op452 = and i64 %v450, %v451
  store i64 %op452, ptr %slot73, align 8
  %v453 = load i64, ptr %slot73, align 8
  %neg454 = sub i64 0, %v453
  store i64 %neg454, ptr %slot74, align 8
  %v455 = load i64, ptr %slot68, align 8
  %v456 = load i64, ptr %slot74, align 8
  %op457 = and i64 %v455, %v456
  store i64 %op457, ptr %slot75, align 8
  %v458 = load i64, ptr %slot69, align 8
  %v459 = load i64, ptr %slot75, align 8
  %op460 = add i64 %v458, %v459
  store i64 %op460, ptr %slot69, align 8
  %v461 = load i64, ptr %slot69, align 8
  %v462 = load i64, ptr %slot12, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 %v461, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot12, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot76, align 8
  %v467 = load i64, ptr %slot76, align 8
  %v468 = load i64, ptr %slot7, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i64 %v467, ptr %p469, align 8, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot8, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %ld472 = load i64, ptr %p471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld472, ptr %slot77, align 8
  %v473 = load i64, ptr %slot77, align 8
  %v474 = load i64, ptr %slot12, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i64 %v473, ptr %p475, align 8, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot13, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i64 1, ptr %p477, align 8, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot13, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot78, align 8
  %v481 = load i64, ptr %slot12, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ld483 = load i64, ptr %p482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld483, ptr %slot79, align 8
  %v484 = load i64, ptr %slot79, align 8
  %v485 = load i64, ptr %slot78, align 8
  %op486 = add i64 %v484, %v485
  store i64 %op486, ptr %slot80, align 8
  %v487 = load i64, ptr %slot80, align 8
  %v488 = load i64, ptr %slot12, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i64 %v487, ptr %p489, align 8, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot12, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot81, align 8
  %v493 = load i64, ptr %slot81, align 8
  %v494 = load i64, ptr %slot8, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i64 %v493, ptr %p495, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v496 = load i64, ptr %slot8, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %ld498 = load i64, ptr %p497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld498, ptr %slot82, align 8
  %v499 = load i64, ptr %slot82, align 8
  %v500 = load i64, ptr %slot12, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i64 %v499, ptr %p501, align 8, !alias.scope !3, !noalias !4
  %v502 = load i64, ptr %slot9, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i64, ptr %p503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld504, ptr %slot83, align 8
  %v505 = load i64, ptr %slot83, align 8
  %v506 = load i64, ptr %slot13, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 %v505, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot13, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i64, ptr %p509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld510, ptr %slot84, align 8
  %v511 = load i64, ptr %slot12, align 8
  %p512 = inttoptr i64 %v511 to ptr
  %ld513 = load i64, ptr %p512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld513, ptr %slot85, align 8
  %v514 = load i64, ptr %slot85, align 8
  %v515 = load i64, ptr %slot84, align 8
  %cmp516 = icmp slt i64 %v514, %v515
  %cv517 = zext i1 %cmp516 to i64
  store i64 %cv517, ptr %slot86, align 8
  %v518 = load i64, ptr %slot86, align 8
  %v519 = load i64, ptr %slot12, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i64 %v518, ptr %p520, align 8, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i64, ptr %p522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld523, ptr %slot87, align 8
  %v524 = load i64, ptr %slot87, align 8
  %cond525 = icmp ne i64 %v524, 0
  br i1 %cond525, label %bb_next74, label %bb_i35
bb_next74:
  %v526 = load i64, ptr %slot8, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot88, align 8
  %v529 = load i64, ptr %slot88, align 8
  %v530 = load i64, ptr %slot12, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot13, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 3, ptr %p533, align 8, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot13, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot89, align 8
  %v537 = load i64, ptr %slot12, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i64, ptr %p538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld539, ptr %slot90, align 8
  %v540 = load i64, ptr %slot89, align 8
  %cmp541 = icmp eq i64 %v540, 0
  %cv542 = zext i1 %cmp541 to i64
  store i64 %cv542, ptr %slot91, align 8
  %v543 = load i64, ptr %slot91, align 8
  %cond544 = icmp ne i64 %v543, 0
  br i1 %cond544, label %bb_division77, label %bb_nonzero77
bb_division77:
  %v545 = load i64, ptr %slot1, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %v547 = load i64, ptr %slot90, align 8
  %v548 = load i64, ptr %slot89, align 8
  call void @myl_qbe_fail_division(ptr %p546, i64 6, i64 %v547, i64 %v548) nomerge, !dbg !116
  unreachable
bb_nonzero77:
  %v549 = load i64, ptr %slot90, align 8
  %cmp550 = icmp eq i64 %v549, 9223372036854775808
  %cv551 = zext i1 %cmp550 to i64
  store i64 %cv551, ptr %slot92, align 8
  %v552 = load i64, ptr %slot89, align 8
  %cmp553 = icmp eq i64 %v552, 18446744073709551615
  %cv554 = zext i1 %cmp553 to i64
  store i64 %cv554, ptr %slot93, align 8
  %v555 = load i64, ptr %slot92, align 8
  %v556 = load i64, ptr %slot93, align 8
  %op557 = and i64 %v555, %v556
  store i64 %op557, ptr %slot94, align 8
  %v558 = load i64, ptr %slot94, align 8
  %neg559 = sub i64 0, %v558
  store i64 %neg559, ptr %slot95, align 8
  %v560 = load i64, ptr %slot89, align 8
  %op561 = xor i64 %v560, 1
  store i64 %op561, ptr %slot96, align 8
  %v562 = load i64, ptr %slot96, align 8
  %v563 = load i64, ptr %slot95, align 8
  %op564 = and i64 %v562, %v563
  store i64 %op564, ptr %slot96, align 8
  %v565 = load i64, ptr %slot89, align 8
  %v566 = load i64, ptr %slot96, align 8
  %op567 = xor i64 %v565, %v566
  store i64 %op567, ptr %slot97, align 8
  %v568 = load i64, ptr %slot90, align 8
  %v569 = load i64, ptr %slot97, align 8
  %op570 = srem i64 %v568, %v569
  store i64 %op570, ptr %slot98, align 8
  %v571 = load i64, ptr %slot98, align 8
  %cmp572 = icmp ne i64 %v571, 0
  %cv573 = zext i1 %cmp572 to i64
  store i64 %cv573, ptr %slot99, align 8
  %v574 = load i64, ptr %slot98, align 8
  %v575 = load i64, ptr %slot97, align 8
  %op576 = xor i64 %v574, %v575
  store i64 %op576, ptr %slot100, align 8
  %v577 = load i64, ptr %slot100, align 8
  %cmp578 = icmp slt i64 %v577, 0
  %cv579 = zext i1 %cmp578 to i64
  store i64 %cv579, ptr %slot101, align 8
  %v580 = load i64, ptr %slot99, align 8
  %v581 = load i64, ptr %slot101, align 8
  %op582 = and i64 %v580, %v581
  store i64 %op582, ptr %slot102, align 8
  %v583 = load i64, ptr %slot102, align 8
  %neg584 = sub i64 0, %v583
  store i64 %neg584, ptr %slot103, align 8
  %v585 = load i64, ptr %slot97, align 8
  %v586 = load i64, ptr %slot103, align 8
  %op587 = and i64 %v585, %v586
  store i64 %op587, ptr %slot104, align 8
  %v588 = load i64, ptr %slot98, align 8
  %v589 = load i64, ptr %slot104, align 8
  %op590 = add i64 %v588, %v589
  store i64 %op590, ptr %slot98, align 8
  %v591 = load i64, ptr %slot98, align 8
  %v592 = load i64, ptr %slot12, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i64 %v591, ptr %p593, align 8, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot13, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i64 0, ptr %p595, align 8, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot13, align 8
  %p597 = inttoptr i64 %v596 to ptr
  %ld598 = load i64, ptr %p597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld598, ptr %slot105, align 8
  %v599 = load i64, ptr %slot12, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ld601 = load i64, ptr %p600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot106, align 8
  %v602 = load i64, ptr %slot106, align 8
  %v603 = load i64, ptr %slot105, align 8
  %cmp604 = icmp eq i64 %v602, %v603
  %cv605 = zext i1 %cmp604 to i64
  store i64 %cv605, ptr %slot107, align 8
  %v606 = load i64, ptr %slot107, align 8
  %v607 = load i64, ptr %slot12, align 8
  %p608 = inttoptr i64 %v607 to ptr
  store i64 %v606, ptr %p608, align 8, !alias.scope !3, !noalias !4
  %v609 = load i64, ptr %slot12, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %ld611 = load i64, ptr %p610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld611, ptr %slot108, align 8
  %v612 = load i64, ptr %slot108, align 8
  %cond613 = icmp ne i64 %v612, 0
  br i1 %cond613, label %bb_next95, label %bb_i20
bb_next95:
  %v614 = load i64, ptr %slot12, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 17, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot12, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i64, ptr %p617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld618, ptr %slot109, align 8
  %v619 = load i64, ptr %slot109, align 8
  %neg620 = sub i64 0, %v619
  store i64 %neg620, ptr %slot110, align 8
  %v621 = load i64, ptr %slot109, align 8
  %cmp622 = icmp eq i64 %v621, 9223372036854775808
  %cv623 = zext i1 %cmp622 to i64
  store i64 %cv623, ptr %slot111, align 8
  %v624 = load i64, ptr %slot111, align 8
  %cond625 = icmp ne i64 %v624, 0
  br i1 %cond625, label %bb_neg_overflow96, label %bb_neg_checked96
bb_neg_overflow96:
  %v626 = load i64, ptr %slot1, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %v628 = load i64, ptr %slot109, align 8
  %call629 = call i64 @myl_qbe_int_neg(ptr %p627, i64 1, i64 64, i64 %v628) nomerge, !dbg !110
  unreachable
bb_neg_checked96:
  %v630 = load i64, ptr %slot110, align 8
  %v631 = load i64, ptr %slot12, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i64 %v630, ptr %p632, align 8, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot12, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ld635 = load i64, ptr %p634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld635, ptr %slot112, align 8
  %v636 = load i64, ptr %slot112, align 8
  %v637 = load i64, ptr %slot10, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i64 %v636, ptr %p638, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i20:
  %v639 = load i64, ptr %slot12, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i64 23, ptr %p640, align 8, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot12, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot113, align 8
  %v644 = load i64, ptr %slot113, align 8
  %v645 = load i64, ptr %slot10, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i64 %v644, ptr %p646, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v647 = load i64, ptr %slot10, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %ld649 = load i64, ptr %p648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld649, ptr %slot114, align 8
  %v650 = load i64, ptr %slot114, align 8
  %v651 = load i64, ptr %slot12, align 8
  %p652 = inttoptr i64 %v651 to ptr
  store i64 %v650, ptr %p652, align 8, !alias.scope !3, !noalias !4
  %v653 = load i64, ptr %slot12, align 8
  %p654 = inttoptr i64 %v653 to ptr
  %ld655 = load i64, ptr %p654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld655, ptr %slot115, align 8
  %v656 = load i64, ptr %slot115, align 8
  %v657 = load i64, ptr %slot11, align 8
  %p658 = inttoptr i64 %v657 to ptr
  store i64 %v656, ptr %p658, align 8, !alias.scope !3, !noalias !4
  %v659 = load i64, ptr %slot7, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %ld661 = load i64, ptr %p660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld661, ptr %slot116, align 8
  %v662 = load i64, ptr %slot116, align 8
  %v663 = load i64, ptr %slot12, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i64 %v662, ptr %p664, align 8, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot11, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %ld667 = load i64, ptr %p666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld667, ptr %slot117, align 8
  %v668 = load i64, ptr %slot117, align 8
  %v669 = load i64, ptr %slot13, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i64 %v668, ptr %p670, align 8, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot13, align 8
  %p672 = inttoptr i64 %v671 to ptr
  %ld673 = load i64, ptr %p672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld673, ptr %slot118, align 8
  %v674 = load i64, ptr %slot12, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot119, align 8
  %v677 = load i64, ptr %slot119, align 8
  %v678 = load i64, ptr %slot118, align 8
  %ovpair680 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v677, i64 %v678)
  %op679 = extractvalue { i64, i1 } %ovpair680, 0
  %ov681 = extractvalue { i64, i1 } %ovpair680, 1
  store i64 %op679, ptr %slot120, align 8
  %v682 = load i64, ptr %slot119, align 8
  %v683 = load i64, ptr %slot120, align 8
  %op684 = xor i64 %v682, %v683
  store i64 %op684, ptr %slot121, align 8
  %v685 = load i64, ptr %slot118, align 8
  %v686 = load i64, ptr %slot120, align 8
  %op687 = xor i64 %v685, %v686
  store i64 %op687, ptr %slot122, align 8
  %v688 = load i64, ptr %slot121, align 8
  %v689 = load i64, ptr %slot122, align 8
  %op690 = and i64 %v688, %v689
  store i64 %op690, ptr %slot123, align 8
  %cv691 = zext i1 %ov681 to i64
  store i64 %cv691, ptr %slot124, align 8
  %v692 = load i64, ptr %slot124, align 8
  %cond693 = icmp ne i64 %v692, 0
  br i1 %cond693, label %bb_overflow106, label %bb_checked106
bb_overflow106:
  %v694 = load i64, ptr %slot1, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %v696 = load i64, ptr %slot119, align 8
  %v697 = load i64, ptr %slot118, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p695, i64 0, i64 %v696, i64 %v697, i64 64) nomerge, !dbg !112
  unreachable
bb_checked106:
  %v698 = load i64, ptr %slot120, align 8
  %v699 = load i64, ptr %slot12, align 8
  %p700 = inttoptr i64 %v699 to ptr
  store i64 %v698, ptr %p700, align 8, !alias.scope !3, !noalias !4
  %v701 = load i64, ptr %slot13, align 8
  %p702 = inttoptr i64 %v701 to ptr
  store i64 1000000007, ptr %p702, align 8, !alias.scope !3, !noalias !4
  %v703 = load i64, ptr %slot13, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i64, ptr %p704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld705, ptr %slot125, align 8
  %v706 = load i64, ptr %slot12, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i64, ptr %p707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot126, align 8
  %v709 = load i64, ptr %slot125, align 8
  %cmp710 = icmp eq i64 %v709, 0
  %cv711 = zext i1 %cmp710 to i64
  store i64 %cv711, ptr %slot127, align 8
  %v712 = load i64, ptr %slot127, align 8
  %cond713 = icmp ne i64 %v712, 0
  br i1 %cond713, label %bb_division113, label %bb_nonzero113
bb_division113:
  %v714 = load i64, ptr %slot1, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %v716 = load i64, ptr %slot126, align 8
  %v717 = load i64, ptr %slot125, align 8
  call void @myl_qbe_fail_division(ptr %p715, i64 6, i64 %v716, i64 %v717) nomerge, !dbg !114
  unreachable
bb_nonzero113:
  %v718 = load i64, ptr %slot126, align 8
  %cmp719 = icmp eq i64 %v718, 9223372036854775808
  %cv720 = zext i1 %cmp719 to i64
  store i64 %cv720, ptr %slot128, align 8
  %v721 = load i64, ptr %slot125, align 8
  %cmp722 = icmp eq i64 %v721, 18446744073709551615
  %cv723 = zext i1 %cmp722 to i64
  store i64 %cv723, ptr %slot129, align 8
  %v724 = load i64, ptr %slot128, align 8
  %v725 = load i64, ptr %slot129, align 8
  %op726 = and i64 %v724, %v725
  store i64 %op726, ptr %slot130, align 8
  %v727 = load i64, ptr %slot130, align 8
  %neg728 = sub i64 0, %v727
  store i64 %neg728, ptr %slot131, align 8
  %v729 = load i64, ptr %slot125, align 8
  %op730 = xor i64 %v729, 1
  store i64 %op730, ptr %slot132, align 8
  %v731 = load i64, ptr %slot132, align 8
  %v732 = load i64, ptr %slot131, align 8
  %op733 = and i64 %v731, %v732
  store i64 %op733, ptr %slot132, align 8
  %v734 = load i64, ptr %slot125, align 8
  %v735 = load i64, ptr %slot132, align 8
  %op736 = xor i64 %v734, %v735
  store i64 %op736, ptr %slot133, align 8
  %v737 = load i64, ptr %slot126, align 8
  %v738 = load i64, ptr %slot133, align 8
  %op739 = srem i64 %v737, %v738
  store i64 %op739, ptr %slot134, align 8
  %v740 = load i64, ptr %slot134, align 8
  %cmp741 = icmp ne i64 %v740, 0
  %cv742 = zext i1 %cmp741 to i64
  store i64 %cv742, ptr %slot135, align 8
  %v743 = load i64, ptr %slot134, align 8
  %v744 = load i64, ptr %slot133, align 8
  %op745 = xor i64 %v743, %v744
  store i64 %op745, ptr %slot136, align 8
  %v746 = load i64, ptr %slot136, align 8
  %cmp747 = icmp slt i64 %v746, 0
  %cv748 = zext i1 %cmp747 to i64
  store i64 %cv748, ptr %slot137, align 8
  %v749 = load i64, ptr %slot135, align 8
  %v750 = load i64, ptr %slot137, align 8
  %op751 = and i64 %v749, %v750
  store i64 %op751, ptr %slot138, align 8
  %v752 = load i64, ptr %slot138, align 8
  %neg753 = sub i64 0, %v752
  store i64 %neg753, ptr %slot139, align 8
  %v754 = load i64, ptr %slot133, align 8
  %v755 = load i64, ptr %slot139, align 8
  %op756 = and i64 %v754, %v755
  store i64 %op756, ptr %slot140, align 8
  %v757 = load i64, ptr %slot134, align 8
  %v758 = load i64, ptr %slot140, align 8
  %op759 = add i64 %v757, %v758
  store i64 %op759, ptr %slot134, align 8
  %v760 = load i64, ptr %slot134, align 8
  %v761 = load i64, ptr %slot12, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i64 %v760, ptr %p762, align 8, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot12, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld765, ptr %slot141, align 8
  %v766 = load i64, ptr %slot141, align 8
  %v767 = load i64, ptr %slot7, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i64 %v766, ptr %p768, align 8, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot8, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i64, ptr %p770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld771, ptr %slot142, align 8
  %v772 = load i64, ptr %slot142, align 8
  %v773 = load i64, ptr %slot12, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i64 %v772, ptr %p774, align 8, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot13, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i64 1, ptr %p776, align 8, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot13, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i64, ptr %p778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld779, ptr %slot143, align 8
  %v780 = load i64, ptr %slot12, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %ld782 = load i64, ptr %p781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld782, ptr %slot144, align 8
  %v783 = load i64, ptr %slot144, align 8
  %v784 = load i64, ptr %slot143, align 8
  %op785 = add i64 %v783, %v784
  %ovpair786 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v783, i64 %v784)
  %ov787 = extractvalue { i64, i1 } %ovpair786, 1
  store i64 %op785, ptr %slot145, align 8
  %cv788 = zext i1 %ov787 to i64
  store i64 %cv788, ptr %slot146, align 8
  %v789 = load i64, ptr %slot146, align 8
  %cond790 = icmp ne i64 %v789, 0
  br i1 %cond790, label %bb_overflow131, label %bb_checked131
bb_overflow131:
  %v791 = load i64, ptr %slot1, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %v793 = load i64, ptr %slot144, align 8
  %v794 = load i64, ptr %slot143, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p792, i64 0, i64 %v793, i64 %v794, i64 64) nomerge, !dbg !118
  unreachable
bb_checked131:
  %v795 = load i64, ptr %slot145, align 8
  %v796 = load i64, ptr %slot12, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i64 %v795, ptr %p797, align 8, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot12, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld800, ptr %slot147, align 8
  %v801 = load i64, ptr %slot147, align 8
  %v802 = load i64, ptr %slot8, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i64 %v801, ptr %p803, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i35:
  %v804 = load i64, ptr %slot7, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i64, ptr %p805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld806, ptr %slot148, align 8
  %v807 = load i64, ptr %slot148, align 8
  %v808 = load i64, ptr %slot12, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i64 %v807, ptr %p809, align 8, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot12, align 8
  %p811 = inttoptr i64 %v810 to ptr
  %ld812 = load i64, ptr %p811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld812, ptr %slot149, align 8
  %v813 = load i64, ptr %slot149, align 8
  ret i64 %v813
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", linkageName: "myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4316030661171315038, i64 0, !"myl_f_3dffcb5a7e508a6ef0e1d3d9386d4b134cb60cf5b31000f1aba9f8bbd0ad4638"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!110 = !DILocation(line: 18, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
