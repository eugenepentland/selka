target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v35 = load i64, ptr %slot1, align 8
  %op36 = add i64 %v35, 32
  store i64 %op36, ptr %slot4, align 8
  %mem37 = alloca i8, i64 8, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot5, align 8
  %mem39 = alloca i8, i64 8, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot6, align 8
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot7, align 8
  %mem43 = alloca i8, i64 8, align 8
  %ptr44 = ptrtoint ptr %mem43 to i64
  store i64 %ptr44, ptr %slot8, align 8
  %v45 = load i64, ptr %slot2, align 8
  %v46 = load i64, ptr %slot5, align 8
  %p47 = inttoptr i64 %v46 to ptr
  store i64 %v45, ptr %p47, align 8, !alias.scope !3, !noalias !4
  %v48 = load i64, ptr %slot3, align 8
  %v49 = load i64, ptr %slot6, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 %v48, ptr %p50, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v51 = load i64, ptr %slot5, align 8
  %p52 = inttoptr i64 %v51 to ptr
  %ld53 = load i64, ptr %p52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld53, ptr %slot9, align 8
  %v54 = load i64, ptr %slot9, align 8
  %v55 = load i64, ptr %slot7, align 8
  %p56 = inttoptr i64 %v55 to ptr
  store i64 %v54, ptr %p56, align 8, !alias.scope !3, !noalias !4
  %v57 = load i64, ptr %slot6, align 8
  %p58 = inttoptr i64 %v57 to ptr
  %ld59 = load i64, ptr %p58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld59, ptr %slot10, align 8
  %v60 = load i64, ptr %slot10, align 8
  %v61 = load i64, ptr %slot8, align 8
  %p62 = inttoptr i64 %v61 to ptr
  store i64 %v60, ptr %p62, align 8, !alias.scope !3, !noalias !4
  %v63 = load i64, ptr %slot8, align 8
  %p64 = inttoptr i64 %v63 to ptr
  %ld65 = load i64, ptr %p64, align 8, !alias.scope !3, !noalias !4
  store i64 %ld65, ptr %slot11, align 8
  %v66 = load i64, ptr %slot7, align 8
  %p67 = inttoptr i64 %v66 to ptr
  %ld68 = load i64, ptr %p67, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot12, align 8
  %v69 = load i64, ptr %slot12, align 8
  %v70 = load i64, ptr %slot11, align 8
  %ovpair72 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v69, i64 %v70)
  %op71 = extractvalue { i64, i1 } %ovpair72, 0
  %ov73 = extractvalue { i64, i1 } %ovpair72, 1
  store i64 %op71, ptr %slot13, align 8
  %v74 = load i64, ptr %slot12, align 8
  %v75 = load i64, ptr %slot13, align 8
  %op76 = xor i64 %v74, %v75
  store i64 %op76, ptr %slot14, align 8
  %v77 = load i64, ptr %slot11, align 8
  %v78 = load i64, ptr %slot13, align 8
  %op79 = xor i64 %v77, %v78
  store i64 %op79, ptr %slot15, align 8
  %v80 = load i64, ptr %slot14, align 8
  %v81 = load i64, ptr %slot15, align 8
  %op82 = and i64 %v80, %v81
  store i64 %op82, ptr %slot16, align 8
  %cv83 = zext i1 %ov73 to i64
  store i64 %cv83, ptr %slot17, align 8
  %v84 = load i64, ptr %slot17, align 8
  %cond85 = icmp ne i64 %v84, 0
  br i1 %cond85, label %bb_overflow4, label %bb_checked4
bb_overflow4:
  %v86 = load i64, ptr %slot1, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %v88 = load i64, ptr %slot12, align 8
  %v89 = load i64, ptr %slot11, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p87, i64 0, i64 %v88, i64 %v89, i64 64) nomerge, !dbg !110
  unreachable
bb_checked4:
  %v90 = load i64, ptr %slot13, align 8
  %v91 = load i64, ptr %slot7, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot8, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 3, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot8, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i64, ptr %p96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld97, ptr %slot18, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  %ld100 = load i64, ptr %p99, align 8, !alias.scope !3, !noalias !4
  store i64 %ld100, ptr %slot19, align 8
  %v101 = load i64, ptr %slot18, align 8
  %cmp102 = icmp eq i64 %v101, 0
  %cv103 = zext i1 %cmp102 to i64
  store i64 %cv103, ptr %slot20, align 8
  %v104 = load i64, ptr %slot20, align 8
  %cond105 = icmp ne i64 %v104, 0
  br i1 %cond105, label %bb_division11, label %bb_nonzero11
bb_division11:
  %v106 = load i64, ptr %slot1, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %v108 = load i64, ptr %slot19, align 8
  %v109 = load i64, ptr %slot18, align 8
  call void @myl_qbe_fail_division(ptr %p107, i64 6, i64 %v108, i64 %v109) nomerge, !dbg !112
  unreachable
bb_nonzero11:
  %v110 = load i64, ptr %slot19, align 8
  %cmp111 = icmp eq i64 %v110, 9223372036854775808
  %cv112 = zext i1 %cmp111 to i64
  store i64 %cv112, ptr %slot21, align 8
  %v113 = load i64, ptr %slot18, align 8
  %cmp114 = icmp eq i64 %v113, 18446744073709551615
  %cv115 = zext i1 %cmp114 to i64
  store i64 %cv115, ptr %slot22, align 8
  %v116 = load i64, ptr %slot21, align 8
  %v117 = load i64, ptr %slot22, align 8
  %op118 = and i64 %v116, %v117
  store i64 %op118, ptr %slot23, align 8
  %v119 = load i64, ptr %slot23, align 8
  %neg120 = sub i64 0, %v119
  store i64 %neg120, ptr %slot24, align 8
  %v121 = load i64, ptr %slot18, align 8
  %op122 = xor i64 %v121, 1
  store i64 %op122, ptr %slot25, align 8
  %v123 = load i64, ptr %slot25, align 8
  %v124 = load i64, ptr %slot24, align 8
  %op125 = and i64 %v123, %v124
  store i64 %op125, ptr %slot25, align 8
  %v126 = load i64, ptr %slot18, align 8
  %v127 = load i64, ptr %slot25, align 8
  %op128 = xor i64 %v126, %v127
  store i64 %op128, ptr %slot26, align 8
  %v129 = load i64, ptr %slot19, align 8
  %v130 = load i64, ptr %slot26, align 8
  %op131 = srem i64 %v129, %v130
  store i64 %op131, ptr %slot27, align 8
  %v132 = load i64, ptr %slot27, align 8
  %cmp133 = icmp ne i64 %v132, 0
  %cv134 = zext i1 %cmp133 to i64
  store i64 %cv134, ptr %slot28, align 8
  %v135 = load i64, ptr %slot27, align 8
  %v136 = load i64, ptr %slot26, align 8
  %op137 = xor i64 %v135, %v136
  store i64 %op137, ptr %slot29, align 8
  %v138 = load i64, ptr %slot29, align 8
  %cmp139 = icmp slt i64 %v138, 0
  %cv140 = zext i1 %cmp139 to i64
  store i64 %cv140, ptr %slot30, align 8
  %v141 = load i64, ptr %slot28, align 8
  %v142 = load i64, ptr %slot30, align 8
  %op143 = and i64 %v141, %v142
  store i64 %op143, ptr %slot31, align 8
  %v144 = load i64, ptr %slot31, align 8
  %neg145 = sub i64 0, %v144
  store i64 %neg145, ptr %slot32, align 8
  %v146 = load i64, ptr %slot26, align 8
  %v147 = load i64, ptr %slot32, align 8
  %op148 = and i64 %v146, %v147
  store i64 %op148, ptr %slot33, align 8
  %v149 = load i64, ptr %slot27, align 8
  %v150 = load i64, ptr %slot33, align 8
  %op151 = add i64 %v149, %v150
  store i64 %op151, ptr %slot27, align 8
  %v152 = load i64, ptr %slot27, align 8
  %v153 = load i64, ptr %slot7, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot7, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot34, align 8
  %v158 = load i64, ptr %slot34, align 8
  ret i64 %v158
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617", linkageName: "myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6493721973426384237, i64 0, !"myl_f_e61a3d78c65133c7260c43e719d97c46e16bd50c64ee7800536cf14c6407a617"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
