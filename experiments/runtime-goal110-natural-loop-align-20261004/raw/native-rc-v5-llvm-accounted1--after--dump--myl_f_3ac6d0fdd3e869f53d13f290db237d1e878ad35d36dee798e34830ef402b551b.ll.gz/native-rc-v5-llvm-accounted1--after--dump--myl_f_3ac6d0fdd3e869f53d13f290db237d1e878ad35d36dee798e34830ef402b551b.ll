target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v230 = load i64, ptr %slot1, align 8
  %op231 = add i64 %v230, 32
  store i64 %op231, ptr %slot3, align 8
  %mem232 = alloca i8, i64 8, align 8
  %ptr233 = ptrtoint ptr %mem232 to i64
  store i64 %ptr233, ptr %slot4, align 8
  %mem234 = alloca i8, i64 8, align 8
  %ptr235 = ptrtoint ptr %mem234 to i64
  store i64 %ptr235, ptr %slot5, align 8
  %mem236 = alloca i8, i64 8, align 8
  %ptr237 = ptrtoint ptr %mem236 to i64
  store i64 %ptr237, ptr %slot6, align 8
  %mem238 = alloca i8, i64 8, align 8
  %ptr239 = ptrtoint ptr %mem238 to i64
  store i64 %ptr239, ptr %slot7, align 8
  %mem240 = alloca i8, i64 8, align 8
  %ptr241 = ptrtoint ptr %mem240 to i64
  store i64 %ptr241, ptr %slot8, align 8
  %mem242 = alloca i8, i64 8, align 8
  %ptr243 = ptrtoint ptr %mem242 to i64
  store i64 %ptr243, ptr %slot9, align 8
  %mem244 = alloca i8, i64 16, align 8
  %ptr245 = ptrtoint ptr %mem244 to i64
  store i64 %ptr245, ptr %slot10, align 8
  %mem246 = alloca i8, i64 16, align 8
  %ptr247 = ptrtoint ptr %mem246 to i64
  store i64 %ptr247, ptr %slot11, align 8
  %mem248 = alloca i8, i64 8, align 8
  %ptr249 = ptrtoint ptr %mem248 to i64
  store i64 %ptr249, ptr %slot12, align 8
  %mem250 = alloca i8, i64 8, align 8
  %ptr251 = ptrtoint ptr %mem250 to i64
  store i64 %ptr251, ptr %slot13, align 8
  %mem252 = alloca i8, i64 8, align 8
  %ptr253 = ptrtoint ptr %mem252 to i64
  store i64 %ptr253, ptr %slot14, align 8
  %mem254 = alloca i8, i64 8, align 8
  %ptr255 = ptrtoint ptr %mem254 to i64
  store i64 %ptr255, ptr %slot15, align 8
  %v256 = load i64, ptr %slot1, align 8
  %op257 = add i64 %v256, 8
  store i64 %op257, ptr %slot16, align 8
  %v258 = load i64, ptr %slot16, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !4, !noalias !3
  store i64 %ld260, ptr %slot17, align 8
  %v261 = load i64, ptr %slot1, align 8
  %op262 = add i64 %v261, 56
  store i64 %op262, ptr %slot18, align 8
  %v263 = load i64, ptr %slot18, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !4, !noalias !3
  store i64 %ld265, ptr %slot19, align 8
  %v266 = load i64, ptr %slot17, align 8
  %v267 = load i64, ptr %slot19, align 8
  %cmp268 = icmp eq i64 %v266, %v267
  %cv269 = zext i1 %cmp268 to i64
  store i64 %cv269, ptr %slot20, align 8
  %v270 = load i64, ptr %slot20, align 8
  %cond271 = icmp ne i64 %v270, 0
  br i1 %cond271, label %bb_limitfail2, label %bb_frameadmit0
bb_limitfail2:
  %v272 = load i64, ptr %slot1, align 8
  %p273 = inttoptr i64 %v272 to ptr
  call void @myl_qbe_fail_frame(ptr %p273)
  br label %bb_entry_failure
bb_frameadmit0:
  %mem274 = alloca i8, i64 32, align 8
  %ptr275 = ptrtoint ptr %mem274 to i64
  store i64 %ptr275, ptr %slot21, align 8
  %v276 = load i64, ptr %slot1, align 8
  %op277 = add i64 %v276, 48
  store i64 %op277, ptr %slot22, align 8
  %v278 = load i64, ptr %slot22, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !4, !noalias !3
  store i64 %ld280, ptr %slot23, align 8
  %v281 = load i64, ptr %slot23, align 8
  %v282 = load i64, ptr %slot21, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 %v281, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot21, align 8
  %p286 = inttoptr i64 %v284 to ptr
  %gep287 = getelementptr i8, ptr %p286, i64 8
  %op285 = ptrtoint ptr %gep287 to i64
  store i64 %op285, ptr %slot24, align 8
  %v288 = load i64, ptr %slot24, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_meta to i64), ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot21, align 8
  %p292 = inttoptr i64 %v290 to ptr
  %gep293 = getelementptr i8, ptr %p292, i64 16
  %op291 = ptrtoint ptr %gep293 to i64
  store i64 %op291, ptr %slot25, align 8
  %v294 = load i64, ptr %slot25, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 0, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot21, align 8
  %v297 = load i64, ptr %slot22, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 %v296, ptr %p298, align 8, !alias.scope !4, !noalias !3
  %v299 = load i64, ptr %slot17, align 8
  %op300 = add i64 %v299, 1
  store i64 %op300, ptr %slot26, align 8
  %v301 = load i64, ptr %slot26, align 8
  %v302 = load i64, ptr %slot16, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 %v301, ptr %p303, align 8, !alias.scope !4, !noalias !3
  %v304 = load i64, ptr %slot21, align 8
  %p306 = inttoptr i64 %v304 to ptr
  %gep307 = getelementptr i8, ptr %p306, i64 16
  %op305 = ptrtoint ptr %gep307 to i64
  store i64 %op305, ptr %slot27, align 8
  %mem308 = alloca i8, i64 16, align 8
  %ptr309 = ptrtoint ptr %mem308 to i64
  store i64 %ptr309, ptr %slot28, align 8
  %v310 = load i64, ptr %slot13, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 0, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot2, align 8
  %v313 = load i64, ptr %slot12, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot1, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %call317 = call ptr @myl_qbe_heap(ptr %p316)
  %calladdr318 = ptrtoint ptr %call317 to i64
  store i64 %calladdr318, ptr %slot29, align 8
  %v319 = load i64, ptr %slot1, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %call321 = call i64 @myl_qbe_region_mark(ptr %p320)
  store i64 %call321, ptr %slot30, align 8
  %v322 = load i64, ptr %slot4, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i32 0, ptr %p323, align 4, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot5, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i32 0, ptr %p325, align 4, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot6, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i32 0, ptr %p327, align 4, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot7, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i32 0, ptr %p329, align 4, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot8, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i32 0, ptr %p331, align 4, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot5, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i32 2, ptr %p333, align 4, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot1, align 8
  %op335 = add i64 %v334, 16
  store i64 %op335, ptr %slot31, align 8
  br label %bb_i0
bb_i0:
  %v336 = load i64, ptr %slot27, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i64 0, ptr %p337, align 8, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot1, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !4, !noalias !3
  store i64 %ld340, ptr %slot32, align 8
  %v341 = load i64, ptr %slot31, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i64, ptr %p342, align 8, !alias.scope !4, !noalias !3
  store i64 %ld343, ptr %slot33, align 8
  %v344 = load i64, ptr %slot32, align 8
  %v345 = load i64, ptr %slot33, align 8
  %cmp346 = icmp eq i64 %v344, %v345
  %cv347 = zext i1 %cmp346 to i64
  store i64 %cv347, ptr %slot34, align 8
  %v348 = load i64, ptr %slot34, align 8
  %cond349 = icmp ne i64 %v348, 0
  br i1 %cond349, label %bb_step_limit, label %bb_step23
bb_step23:
  %v350 = load i64, ptr %slot32, align 8
  %op351 = add i64 %v350, 1
  store i64 %op351, ptr %slot35, align 8
  %v352 = load i64, ptr %slot35, align 8
  %v353 = load i64, ptr %slot1, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 %v352, ptr %p354, align 8, !alias.scope !4, !noalias !3
  %v355 = load i64, ptr %slot12, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot36, align 8
  %v358 = load i64, ptr %slot36, align 8
  %v359 = load i64, ptr %slot15, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot27, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 1, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot1, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !4, !noalias !3
  store i64 %ld365, ptr %slot37, align 8
  %v366 = load i64, ptr %slot31, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !4, !noalias !3
  store i64 %ld368, ptr %slot38, align 8
  %v369 = load i64, ptr %slot37, align 8
  %v370 = load i64, ptr %slot38, align 8
  %cmp371 = icmp eq i64 %v369, %v370
  %cv372 = zext i1 %cmp371 to i64
  store i64 %cv372, ptr %slot39, align 8
  %v373 = load i64, ptr %slot39, align 8
  %cond374 = icmp ne i64 %v373, 0
  br i1 %cond374, label %bb_step_limit, label %bb_step28
bb_step28:
  %v375 = load i64, ptr %slot37, align 8
  %op376 = add i64 %v375, 1
  store i64 %op376, ptr %slot40, align 8
  %v377 = load i64, ptr %slot40, align 8
  %v378 = load i64, ptr %slot1, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 %v377, ptr %p379, align 8, !alias.scope !4, !noalias !3
  %v380 = load i64, ptr %slot15, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot41, align 8
  %v383 = load i64, ptr %slot41, align 8
  %v384 = load i64, ptr %slot9, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 %v383, ptr %p385, align 8, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot9, align 8
  store i64 %v386, ptr %slot42, align 8
  store i32 0, ptr %slot43, align 8
  %v387 = load i64, ptr %slot6, align 8
  %p388 = inttoptr i64 %v387 to ptr
  %ld389 = load i32, ptr %p388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld389, ptr %slot44, align 8
  %v390 = load i32, ptr %slot44, align 8
  %op391 = and i32 %v390, 24
  store i32 %op391, ptr %slot44, align 8
  %v392 = load i32, ptr %slot44, align 8
  %cmp393 = icmp eq i32 %v392, 0
  %cv394 = zext i1 %cmp393 to i32
  store i32 %cv394, ptr %slot45, align 8
  %v395 = load i32, ptr %slot43, align 8
  %v396 = load i32, ptr %slot45, align 8
  %op397 = and i32 %v395, %v396
  store i32 %op397, ptr %slot46, align 8
  %v398 = load i32, ptr %slot46, align 8
  %cv399 = zext i32 %v398 to i64
  %cond400 = icmp ne i64 %cv399, 0
  br i1 %cond400, label %bb_rcprivateown37, label %bb_rcprivateloan37
bb_rcprivateown37:
  %v401 = load i64, ptr %slot10, align 8
  store i64 %v401, ptr %slot47, align 8
  %v402 = load i64, ptr %slot30, align 8
  store i64 %v402, ptr %slot48, align 8
  %v403 = load i64, ptr %slot42, align 8
  %v404 = load i64, ptr %slot47, align 8
  %op405 = sub i64 %v403, %v404
  store i64 %op405, ptr %slot49, align 8
  %v406 = load i64, ptr %slot47, align 8
  %v407 = load i64, ptr %slot42, align 8
  %op408 = sub i64 %v406, %v407
  store i64 %op408, ptr %slot50, align 8
  %v409 = load i64, ptr %slot49, align 8
  %cmp410 = icmp ult i64 %v409, 8
  %cv411 = zext i1 %cmp410 to i32
  store i32 %cv411, ptr %slot51, align 8
  %v412 = load i64, ptr %slot50, align 8
  %cmp413 = icmp ult i64 %v412, 8
  %cv414 = zext i1 %cmp413 to i32
  store i32 %cv414, ptr %slot52, align 8
  %v415 = load i32, ptr %slot51, align 8
  %v416 = load i32, ptr %slot52, align 8
  %op417 = or i32 %v415, %v416
  store i32 %op417, ptr %slot53, align 8
  %v418 = load i32, ptr %slot53, align 8
  %cv419 = zext i32 %v418 to i64
  %cond420 = icmp ne i64 %cv419, 0
  br i1 %cond420, label %bb_rcmoveslow40, label %bb_rcmovecheck40
bb_rcmovecheck40:
  %v421 = load i64, ptr %slot42, align 8
  %p423 = inttoptr i64 %v421 to ptr
  %gep424 = getelementptr i8, ptr %p423, i64 0
  %op422 = ptrtoint ptr %gep424 to i64
  store i64 %op422, ptr %slot54, align 8
  %v425 = load i64, ptr %slot54, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot55, align 8
  %v428 = load i64, ptr %slot55, align 8
  %cmp429 = icmp ne i64 %v428, 0
  %cv430 = zext i1 %cmp429 to i32
  store i32 %cv430, ptr %slot56, align 8
  %v431 = load i32, ptr %slot56, align 8
  %cv432 = zext i32 %v431 to i64
  %cond433 = icmp ne i64 %cv432, 0
  br i1 %cond433, label %bb_rcmoveheader48, label %bb_rcmovenext48
bb_rcmoveheader48:
  %v434 = load i64, ptr %slot55, align 8
  %op435 = sub i64 %v434, 16
  store i64 %op435, ptr %slot57, align 8
  %v436 = load i64, ptr %slot55, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %rgep438 = getelementptr i8, ptr %p437, i64 -16
  %ld439 = load i64, ptr %rgep438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld439, ptr %slot58, align 8
  %v440 = load i64, ptr %slot58, align 8
  %op441 = and i64 %v440, 5764607523034234881
  store i64 %op441, ptr %slot59, align 8
  %v442 = load i64, ptr %slot59, align 8
  %cmp443 = icmp ne i64 %v442, 0
  %cv444 = zext i1 %cmp443 to i32
  store i32 %cv444, ptr %slot60, align 8
  %v445 = load i32, ptr %slot60, align 8
  %cv446 = zext i32 %v445 to i64
  %cond447 = icmp ne i64 %cv446, 0
  br i1 %cond447, label %bb_rcmoveslow40, label %bb_rcmovenext48
bb_rcmovenext48:
  %v448 = load i64, ptr %slot42, align 8
  %v449 = load i64, ptr %slot47, align 8
  %p450 = inttoptr i64 %v448 to ptr
  %p451 = inttoptr i64 %v449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p451, ptr %p450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot42, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i64 0, ptr %p453, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved40
bb_rcmoveslow40:
  %v454 = load i64, ptr %slot29, align 8
  %v455 = load i64, ptr %slot47, align 8
  %v456 = load i64, ptr %slot42, align 8
  %v457 = load i64, ptr %slot48, align 8
  %cv458 = trunc i64 %v457 to i32
  %call459 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v454, i64 %v455, i64 %v456, i32 %cv458)
  store i32 %call459, ptr %slot61, align 8
  %v460 = load i32, ptr %slot61, align 8
  %cv461 = zext i32 %v460 to i64
  %cond462 = icmp ne i64 %cv461, 0
  br i1 %cond462, label %bb_rcsuccess55, label %bb_rcfailure55
bb_rcfailure55:
  %v463 = load i64, ptr %slot29, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %call465 = call i32 @myl_rc_take_failure(ptr %p464)
  store i32 %call465, ptr %slot62, align 8
  %v466 = load i64, ptr %slot1, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %v468 = load i32, ptr %slot62, align 8
  %call469 = call i32 @myl_qbe_rc_status(ptr %p467, i32 %v468)
  store i32 %call469, ptr %slot63, align 8
  br label %bb_failure
bb_rcsuccess55:
  br label %bb_rcmoved40
bb_rcmoved40:
  %v470 = load i64, ptr %slot8, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 2, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot7, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 1, ptr %p473, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared37
bb_rcprivateloan37:
  %v474 = load i64, ptr %slot10, align 8
  store i64 %v474, ptr %slot64, align 8
  %v475 = load i64, ptr %slot42, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %ld477 = load i64, ptr %p476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld477, ptr %slot65, align 8
  %v478 = load i64, ptr %slot65, align 8
  %cmp479 = icmp ne i64 %v478, 0
  %cv480 = zext i1 %cmp479 to i32
  store i32 %cv480, ptr %slot66, align 8
  %v481 = load i32, ptr %slot66, align 8
  %cv482 = zext i32 %v481 to i64
  %cond483 = icmp ne i64 %cv482, 0
  br i1 %cond483, label %bb_rcgnn63, label %bb_rcgstore63
bb_rcgnn63:
  %v484 = load i64, ptr %slot65, align 8
  %op485 = sub i64 %v484, 16
  store i64 %op485, ptr %slot67, align 8
  %v486 = load i64, ptr %slot65, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %rgep488 = getelementptr i8, ptr %p487, i64 -16
  %ld489 = load i64, ptr %rgep488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld489, ptr %slot68, align 8
  %v490 = load i64, ptr %slot68, align 8
  %op491 = and i64 %v490, 4611686018427387906
  store i64 %op491, ptr %slot69, align 8
  %v492 = load i64, ptr %slot69, align 8
  %cmp493 = icmp ne i64 %v492, 0
  %cv494 = zext i1 %cmp493 to i32
  store i32 %cv494, ptr %slot70, align 8
  %v495 = load i32, ptr %slot70, align 8
  %cv496 = zext i32 %v495 to i64
  %cond497 = icmp ne i64 %cv496, 0
  br i1 %cond497, label %bb_rcgstore63, label %bb_rcginc63
bb_rcginc63:
  %v498 = load i64, ptr %slot65, align 8
  %op499 = sub i64 %v498, 24
  store i64 %op499, ptr %slot71, align 8
  %v500 = load i64, ptr %slot65, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %rgep502 = getelementptr i8, ptr %p501, i64 -24
  %ld503 = load i64, ptr %rgep502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld503, ptr %slot72, align 8
  %v504 = load i64, ptr %slot72, align 8
  %op505 = add i64 %v504, 1
  store i64 %op505, ptr %slot73, align 8
  %v506 = load i64, ptr %slot73, align 8
  %cmp507 = icmp eq i64 %v506, 0
  %cv508 = zext i1 %cmp507 to i32
  store i32 %cv508, ptr %slot74, align 8
  %v509 = load i32, ptr %slot74, align 8
  %cv510 = zext i32 %v509 to i64
  %cond511 = icmp ne i64 %cv510, 0
  br i1 %cond511, label %bb_rcglimit63, label %bb_rcgcapacity63
bb_rcglimit63:
  %v512 = load i64, ptr %slot1, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %call514 = call i32 @myl_qbe_rc_status(ptr %p513, i32 2)
  store i32 %call514, ptr %slot75, align 8
  br label %bb_failure
bb_rcgcapacity63:
  %v515 = load i64, ptr %slot73, align 8
  %v516 = load i64, ptr %slot65, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %rgep518 = getelementptr i8, ptr %p517, i64 -24
  store i64 %v515, ptr %rgep518, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore63
bb_rcgstore63:
  %v519 = load i64, ptr %slot65, align 8
  %v520 = load i64, ptr %slot64, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 %v519, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot8, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 2, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot8, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i32 16, ptr %p525, align 4, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot7, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i32 1, ptr %p527, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared37
bb_rcprivateprepared37:
  %v528 = load i64, ptr %slot4, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i32, ptr %p529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld530, ptr %slot76, align 8
  %v531 = load i32, ptr %slot76, align 8
  %cv532 = zext i32 %v531 to i64
  %cond533 = icmp ne i64 %cv532, 0
  br i1 %cond533, label %bb_rcslotdrop117, label %bb_rcslotdone117
bb_rcslotdrop117:
  %v534 = load i64, ptr %slot4, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 0, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot13, align 8
  store i64 %v536, ptr %slot77, align 8
  %v537 = load i64, ptr %slot5, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i32, ptr %p538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld539, ptr %slot78, align 8
  %v540 = load i32, ptr %slot78, align 8
  %op541 = and i32 %v540, 28
  store i32 %op541, ptr %slot79, align 8
  %v542 = load i32, ptr %slot79, align 8
  %cv543 = zext i32 %v542 to i64
  %cond544 = icmp ne i64 %cv543, 0
  br i1 %cond544, label %bb_rcslotrole117, label %bb_rcslotowner117
bb_rcslotrole117:
  %v545 = load i64, ptr %slot29, align 8
  store i64 %v545, ptr %slot80, align 8
  %v546 = load i64, ptr %slot77, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot81, align 8
  %v549 = load i64, ptr %slot81, align 8
  %cmp550 = icmp ne i64 %v549, 0
  %cv551 = zext i1 %cmp550 to i32
  store i32 %cv551, ptr %slot82, align 8
  %v552 = load i32, ptr %slot82, align 8
  %cv553 = zext i32 %v552 to i64
  %cond554 = icmp ne i64 %cv553, 0
  br i1 %cond554, label %bb_rcgnn133, label %bb_rcgdone133
bb_rcgnn133:
  %v555 = load i64, ptr %slot81, align 8
  %op556 = sub i64 %v555, 16
  store i64 %op556, ptr %slot83, align 8
  %v557 = load i64, ptr %slot81, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %rgep559 = getelementptr i8, ptr %p558, i64 -16
  %ld560 = load i64, ptr %rgep559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld560, ptr %slot84, align 8
  %v561 = load i64, ptr %slot84, align 8
  %op562 = and i64 %v561, 4611686018427387906
  store i64 %op562, ptr %slot85, align 8
  %v563 = load i64, ptr %slot85, align 8
  %cmp564 = icmp ne i64 %v563, 0
  %cv565 = zext i1 %cmp564 to i32
  store i32 %cv565, ptr %slot86, align 8
  %v566 = load i32, ptr %slot86, align 8
  %cv567 = zext i32 %v566 to i64
  %cond568 = icmp ne i64 %cv567, 0
  br i1 %cond568, label %bb_rcgclear133, label %bb_rcgcounted133
bb_rcgcounted133:
  %v569 = load i64, ptr %slot81, align 8
  %op570 = sub i64 %v569, 24
  store i64 %op570, ptr %slot87, align 8
  %v571 = load i64, ptr %slot81, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %rgep573 = getelementptr i8, ptr %p572, i64 -24
  %ld574 = load i64, ptr %rgep573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld574, ptr %slot88, align 8
  %v575 = load i64, ptr %slot88, align 8
  %op576 = sub i64 %v575, 1
  store i64 %op576, ptr %slot89, align 8
  %v577 = load i64, ptr %slot89, align 8
  %cmp578 = icmp eq i64 %v577, 0
  %cv579 = zext i1 %cmp578 to i32
  store i32 %cv579, ptr %slot90, align 8
  %v580 = load i32, ptr %slot90, align 8
  %cv581 = zext i32 %v580 to i64
  %cond582 = icmp ne i64 %cv581, 0
  br i1 %cond582, label %bb_rcglast133, label %bb_rcgdec133
bb_rcglast133:
  %v583 = load i64, ptr %slot81, align 8
  %op584 = sub i64 %v583, 32
  store i64 %op584, ptr %slot91, align 8
  %v585 = load i64, ptr %slot81, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %rgep587 = getelementptr i8, ptr %p586, i64 -32
  %ld588 = load i64, ptr %rgep587, align 8, !alias.scope !9, !noalias !10
  store i64 %ld588, ptr %slot92, align 8
  %v589 = load i64, ptr %slot92, align 8
  %cmp590 = icmp ne i64 %v589, 0
  %cv591 = zext i1 %cmp590 to i32
  store i32 %cv591, ptr %slot93, align 8
  %v592 = load i32, ptr %slot93, align 8
  %cv593 = zext i32 %v592 to i64
  %cond594 = icmp ne i64 %cv593, 0
  br i1 %cond594, label %bb_rcgdec133, label %bb_rcgslow133
bb_rcgslow133:
  %v595 = load i64, ptr %slot80, align 8
  %v596 = load i64, ptr %slot77, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v595, i64 %v596)
  br label %bb_rcgdone133
bb_rcgdec133:
  %v597 = load i64, ptr %slot89, align 8
  %v598 = load i64, ptr %slot81, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %rgep600 = getelementptr i8, ptr %p599, i64 -24
  store i64 %v597, ptr %rgep600, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear133
bb_rcgclear133:
  %v601 = load i64, ptr %slot77, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i64 0, ptr %p602, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone133
bb_rcgdone133:
  br label %bb_rcslotdone117
bb_rcslotowner117:
  %v603 = load i64, ptr %slot29, align 8
  store i64 %v603, ptr %slot94, align 8
  %v604 = load i64, ptr %slot77, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %ld606 = load i64, ptr %p605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld606, ptr %slot95, align 8
  %v607 = load i64, ptr %slot95, align 8
  %cmp608 = icmp ne i64 %v607, 0
  %cv609 = zext i1 %cmp608 to i32
  store i32 %cv609, ptr %slot96, align 8
  %v610 = load i32, ptr %slot96, align 8
  %cv611 = zext i32 %v610 to i64
  %cond612 = icmp ne i64 %cv611, 0
  br i1 %cond612, label %bb_rcgnn148, label %bb_rcgdone148
bb_rcgnn148:
  %v613 = load i64, ptr %slot95, align 8
  %op614 = sub i64 %v613, 16
  store i64 %op614, ptr %slot97, align 8
  %v615 = load i64, ptr %slot95, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %rgep617 = getelementptr i8, ptr %p616, i64 -16
  %ld618 = load i64, ptr %rgep617, align 8, !alias.scope !9, !noalias !10
  store i64 %ld618, ptr %slot98, align 8
  %v619 = load i64, ptr %slot98, align 8
  %op620 = and i64 %v619, 4611686018427387906
  store i64 %op620, ptr %slot99, align 8
  %v621 = load i64, ptr %slot99, align 8
  %cmp622 = icmp ne i64 %v621, 0
  %cv623 = zext i1 %cmp622 to i32
  store i32 %cv623, ptr %slot100, align 8
  %v624 = load i32, ptr %slot100, align 8
  %cv625 = zext i32 %v624 to i64
  %cond626 = icmp ne i64 %cv625, 0
  br i1 %cond626, label %bb_rcgclear148, label %bb_rcgcounted148
bb_rcgcounted148:
  %v627 = load i64, ptr %slot95, align 8
  %op628 = sub i64 %v627, 32
  store i64 %op628, ptr %slot101, align 8
  %v629 = load i64, ptr %slot95, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %rgep631 = getelementptr i8, ptr %p630, i64 -32
  %ld632 = load i64, ptr %rgep631, align 8, !alias.scope !9, !noalias !10
  store i64 %ld632, ptr %slot102, align 8
  %v633 = load i64, ptr %slot102, align 8
  %op634 = sub i64 %v633, 1
  store i64 %op634, ptr %slot103, align 8
  %v635 = load i64, ptr %slot103, align 8
  %cmp636 = icmp eq i64 %v635, 0
  %cv637 = zext i1 %cmp636 to i32
  store i32 %cv637, ptr %slot104, align 8
  %v638 = load i32, ptr %slot104, align 8
  %cv639 = zext i32 %v638 to i64
  %cond640 = icmp ne i64 %cv639, 0
  br i1 %cond640, label %bb_rcglast148, label %bb_rcgdec148
bb_rcglast148:
  %v641 = load i64, ptr %slot95, align 8
  %op642 = sub i64 %v641, 24
  store i64 %op642, ptr %slot105, align 8
  %v643 = load i64, ptr %slot95, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %rgep645 = getelementptr i8, ptr %p644, i64 -24
  %ld646 = load i64, ptr %rgep645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld646, ptr %slot106, align 8
  %v647 = load i64, ptr %slot106, align 8
  %cmp648 = icmp ne i64 %v647, 0
  %cv649 = zext i1 %cmp648 to i32
  store i32 %cv649, ptr %slot107, align 8
  %v650 = load i32, ptr %slot107, align 8
  %cv651 = zext i32 %v650 to i64
  %cond652 = icmp ne i64 %cv651, 0
  br i1 %cond652, label %bb_rcgdec148, label %bb_rcgslow148
bb_rcgslow148:
  %v653 = load i64, ptr %slot94, align 8
  %v654 = load i64, ptr %slot77, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v653, i64 %v654)
  br label %bb_rcgdone148
bb_rcgdec148:
  %v655 = load i64, ptr %slot103, align 8
  %v656 = load i64, ptr %slot95, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %rgep658 = getelementptr i8, ptr %p657, i64 -32
  store i64 %v655, ptr %rgep658, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear148
bb_rcgclear148:
  %v659 = load i64, ptr %slot77, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i64 0, ptr %p660, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone148
bb_rcgdone148:
  br label %bb_rcslotdone117
bb_rcslotdone117:
  %v661 = load i64, ptr %slot13, align 8
  store i64 %v661, ptr %slot108, align 8
  %v662 = load i64, ptr %slot10, align 8
  store i64 %v662, ptr %slot109, align 8
  %v663 = load i64, ptr %slot109, align 8
  %v664 = load i64, ptr %slot108, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %p666 = inttoptr i64 %v664 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p666, ptr %p665, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot7, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot5, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 2, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot8, align 8
  %p672 = inttoptr i64 %v671 to ptr
  %ld673 = load i32, ptr %p672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld673, ptr %slot110, align 8
  %v674 = load i32, ptr %slot110, align 8
  %v675 = load i64, ptr %slot5, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i32 %v674, ptr %p676, align 4, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot4, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i32 1, ptr %p678, align 4, !alias.scope !3, !noalias !4
  %v679 = load i64, ptr %slot27, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 2, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot1, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i64, ptr %p682, align 8, !alias.scope !4, !noalias !3
  store i64 %ld683, ptr %slot111, align 8
  %v684 = load i64, ptr %slot31, align 8
  %p685 = inttoptr i64 %v684 to ptr
  %ld686 = load i64, ptr %p685, align 8, !alias.scope !4, !noalias !3
  store i64 %ld686, ptr %slot112, align 8
  %v687 = load i64, ptr %slot111, align 8
  %v688 = load i64, ptr %slot112, align 8
  %cmp689 = icmp eq i64 %v687, %v688
  %cv690 = zext i1 %cmp689 to i64
  store i64 %cv690, ptr %slot113, align 8
  %v691 = load i64, ptr %slot113, align 8
  %cond692 = icmp ne i64 %v691, 0
  br i1 %cond692, label %bb_step_limit, label %bb_step162
bb_step162:
  %v693 = load i64, ptr %slot111, align 8
  %op694 = add i64 %v693, 1
  store i64 %op694, ptr %slot114, align 8
  %v695 = load i64, ptr %slot114, align 8
  %v696 = load i64, ptr %slot1, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 %v695, ptr %p697, align 8, !alias.scope !4, !noalias !3
  %v698 = load i64, ptr %slot13, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot115, align 8
  %v701 = load i64, ptr %slot13, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %ld703 = load i64, ptr %p702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld703, ptr %slot116, align 8
  %v704 = load i64, ptr %slot116, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %call706 = call ptr @myl_native_text_payload(ptr %p705)
  %calladdr707 = ptrtoint ptr %call706 to i64
  store i64 %calladdr707, ptr %slot117, align 8
  %v708 = load i64, ptr %slot116, align 8
  %op709 = add i64 %v708, 8
  store i64 %op709, ptr %slot118, align 8
  %v710 = load i64, ptr %slot118, align 8
  %p711 = inttoptr i64 %v710 to ptr
  %ld712 = load i64, ptr %p711, align 8
  store i64 %ld712, ptr %slot119, align 8
  %v713 = load i64, ptr %slot117, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %v715 = load i64, ptr %slot119, align 8
  %v716 = load i64, ptr %slot11, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %call718 = call i32 @myl_native_bytes_number_parse(ptr %p714, i64 %v715, i32 0, ptr %p717)
  store i32 %call718, ptr %slot120, align 8
  %v719 = load i64, ptr %slot11, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %ld721 = load i64, ptr %p720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld721, ptr %slot121, align 8
  %v722 = load i64, ptr %slot28, align 8
  store i64 %v722, ptr %slot122, align 8
  %v723 = load i64, ptr %slot122, align 8
  %p725 = inttoptr i64 %v723 to ptr
  %gep726 = getelementptr i8, ptr %p725, i64 8
  %op724 = ptrtoint ptr %gep726 to i64
  store i64 %op724, ptr %slot123, align 8
  %v727 = load i32, ptr %slot120, align 8
  %cv728 = zext i32 %v727 to i64
  %cond729 = icmp ne i64 %cv728, 0
  br i1 %cond729, label %bb_some173, label %bb_none173
bb_some173:
  %v730 = load i64, ptr %slot122, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i32 1, ptr %p731, align 4, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot121, align 8
  %v733 = load i64, ptr %slot123, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed173
bb_none173:
  %v735 = load i64, ptr %slot122, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i32 0, ptr %p736, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed173
bb_parsed173:
  %v737 = load i64, ptr %slot122, align 8
  %v738 = load i64, ptr %slot15, align 8
  %p739 = inttoptr i64 %v738 to ptr
  store i64 %v737, ptr %p739, align 8, !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot3, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %ld742 = load i64, ptr %p741, align 8, !alias.scope !4, !noalias !3
  store i64 %ld742, ptr %slot124, align 8
  %v743 = load i64, ptr %slot124, align 8
  %cond744 = icmp ne i64 %v743, 0
  br i1 %cond744, label %bb_failure, label %bb_ok174
bb_ok174:
  %v745 = load i64, ptr %slot27, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i64 3, ptr %p746, align 8, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot1, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i64, ptr %p748, align 8, !alias.scope !4, !noalias !3
  store i64 %ld749, ptr %slot125, align 8
  %v750 = load i64, ptr %slot31, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i64, ptr %p751, align 8, !alias.scope !4, !noalias !3
  store i64 %ld752, ptr %slot126, align 8
  %v753 = load i64, ptr %slot125, align 8
  %v754 = load i64, ptr %slot126, align 8
  %cmp755 = icmp eq i64 %v753, %v754
  %cv756 = zext i1 %cmp755 to i64
  store i64 %cv756, ptr %slot127, align 8
  %v757 = load i64, ptr %slot127, align 8
  %cond758 = icmp ne i64 %v757, 0
  br i1 %cond758, label %bb_step_limit, label %bb_step178
bb_step178:
  %v759 = load i64, ptr %slot125, align 8
  %op760 = add i64 %v759, 1
  store i64 %op760, ptr %slot128, align 8
  %v761 = load i64, ptr %slot128, align 8
  %v762 = load i64, ptr %slot1, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 %v761, ptr %p763, align 8, !alias.scope !4, !noalias !3
  %v764 = load i64, ptr %slot15, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %ld766 = load i64, ptr %p765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld766, ptr %slot129, align 8
  %v767 = load i64, ptr %slot129, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i32, ptr %p768, align 4, !alias.scope !3, !noalias !4
  %ext770 = zext i32 %ld769 to i64
  store i64 %ext770, ptr %slot130, align 8
  %v771 = load i64, ptr %slot130, align 8
  %cmp772 = icmp eq i64 %v771, 0
  %cv773 = zext i1 %cmp772 to i64
  store i64 %cv773, ptr %slot131, align 8
  %v774 = load i64, ptr %slot131, align 8
  %cond775 = icmp ne i64 %v774, 0
  br i1 %cond775, label %bb_rcarm181, label %bb_rcarmnext181
bb_rcarm181:
  br label %bb_i6
bb_rcarmnext181:
  %v776 = load i64, ptr %slot130, align 8
  %cmp777 = icmp eq i64 %v776, 1
  %cv778 = zext i1 %cmp777 to i64
  store i64 %cv778, ptr %slot132, align 8
  %v779 = load i64, ptr %slot132, align 8
  %cond780 = icmp ne i64 %v779, 0
  br i1 %cond780, label %bb_rcarm182, label %bb_rcarmnext182
bb_rcarm182:
  %v781 = load i64, ptr %slot10, align 8
  store i64 %v781, ptr %slot133, align 8
  %v782 = load i64, ptr %slot129, align 8
  %op783 = add i64 %v782, 8
  store i64 %op783, ptr %slot134, align 8
  %v784 = load i64, ptr %slot30, align 8
  store i64 %v784, ptr %slot135, align 8
  %v785 = load i64, ptr %slot134, align 8
  %p786 = inttoptr i64 %v785 to ptr
  %ld787 = load i64, ptr %p786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld787, ptr %slot136, align 8
  %v788 = load i64, ptr %slot136, align 8
  %v789 = load i64, ptr %slot133, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i64 %v788, ptr %p790, align 8, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot8, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i32 0, ptr %p792, align 4, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot7, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i32 1, ptr %p794, align 4, !alias.scope !3, !noalias !4
  %v795 = load i64, ptr %slot133, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld797, ptr %slot137, align 8
  %v798 = load i64, ptr %slot137, align 8
  %v799 = load i64, ptr %slot14, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i64 %v798, ptr %p800, align 8, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot7, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i32 0, ptr %p802, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext182:
  br label %bb_failure
bb_i4:
  %v803 = load i64, ptr %slot27, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 4, ptr %p804, align 8, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot1, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !4, !noalias !3
  store i64 %ld807, ptr %slot138, align 8
  %v808 = load i64, ptr %slot31, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !4, !noalias !3
  store i64 %ld810, ptr %slot139, align 8
  %v811 = load i64, ptr %slot138, align 8
  %v812 = load i64, ptr %slot139, align 8
  %cmp813 = icmp eq i64 %v811, %v812
  %cv814 = zext i1 %cmp813 to i64
  store i64 %cv814, ptr %slot140, align 8
  %v815 = load i64, ptr %slot140, align 8
  %cond816 = icmp ne i64 %v815, 0
  br i1 %cond816, label %bb_step_limit, label %bb_step194
bb_step194:
  %v817 = load i64, ptr %slot138, align 8
  %op818 = add i64 %v817, 1
  store i64 %op818, ptr %slot141, align 8
  %v819 = load i64, ptr %slot141, align 8
  %v820 = load i64, ptr %slot1, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 %v819, ptr %p821, align 8, !alias.scope !4, !noalias !3
  %v822 = load i64, ptr %slot14, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot142, align 8
  %v825 = load i64, ptr %slot142, align 8
  %v826 = load i64, ptr %slot15, align 8
  %p827 = inttoptr i64 %v826 to ptr
  store i64 %v825, ptr %p827, align 8, !alias.scope !3, !noalias !4
  %v828 = load i64, ptr %slot27, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 5, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot1, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !4, !noalias !3
  store i64 %ld832, ptr %slot143, align 8
  %v833 = load i64, ptr %slot31, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !4, !noalias !3
  store i64 %ld835, ptr %slot144, align 8
  %v836 = load i64, ptr %slot143, align 8
  %v837 = load i64, ptr %slot144, align 8
  %cmp838 = icmp eq i64 %v836, %v837
  %cv839 = zext i1 %cmp838 to i64
  store i64 %cv839, ptr %slot145, align 8
  %v840 = load i64, ptr %slot145, align 8
  %cond841 = icmp ne i64 %v840, 0
  br i1 %cond841, label %bb_step_limit, label %bb_step199
bb_step199:
  %v842 = load i64, ptr %slot143, align 8
  %op843 = add i64 %v842, 1
  store i64 %op843, ptr %slot146, align 8
  %v844 = load i64, ptr %slot146, align 8
  %v845 = load i64, ptr %slot1, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 %v844, ptr %p846, align 8, !alias.scope !4, !noalias !3
  %v847 = load i64, ptr %slot15, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ld849 = load i64, ptr %p848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld849, ptr %slot147, align 8
  %v850 = load i64, ptr %slot4, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %ld852 = load i32, ptr %p851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld852, ptr %slot148, align 8
  %v853 = load i32, ptr %slot148, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v856 = load i64, ptr %slot4, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 0, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot13, align 8
  store i64 %v858, ptr %slot149, align 8
  %v859 = load i64, ptr %slot5, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i32, ptr %p860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld861, ptr %slot150, align 8
  %v862 = load i32, ptr %slot150, align 8
  %op863 = and i32 %v862, 28
  store i32 %op863, ptr %slot151, align 8
  %v864 = load i32, ptr %slot151, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v867 = load i64, ptr %slot29, align 8
  store i64 %v867, ptr %slot152, align 8
  %v868 = load i64, ptr %slot149, align 8
  %p869 = inttoptr i64 %v868 to ptr
  %ld870 = load i64, ptr %p869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld870, ptr %slot153, align 8
  %v871 = load i64, ptr %slot153, align 8
  %cmp872 = icmp ne i64 %v871, 0
  %cv873 = zext i1 %cmp872 to i32
  store i32 %cv873, ptr %slot154, align 8
  %v874 = load i32, ptr %slot154, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcgnn222, label %bb_rcgdone222
bb_rcgnn222:
  %v877 = load i64, ptr %slot153, align 8
  %op878 = sub i64 %v877, 16
  store i64 %op878, ptr %slot155, align 8
  %v879 = load i64, ptr %slot153, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %rgep881 = getelementptr i8, ptr %p880, i64 -16
  %ld882 = load i64, ptr %rgep881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld882, ptr %slot156, align 8
  %v883 = load i64, ptr %slot156, align 8
  %op884 = and i64 %v883, 4611686018427387906
  store i64 %op884, ptr %slot157, align 8
  %v885 = load i64, ptr %slot157, align 8
  %cmp886 = icmp ne i64 %v885, 0
  %cv887 = zext i1 %cmp886 to i32
  store i32 %cv887, ptr %slot158, align 8
  %v888 = load i32, ptr %slot158, align 8
  %cv889 = zext i32 %v888 to i64
  %cond890 = icmp ne i64 %cv889, 0
  br i1 %cond890, label %bb_rcgclear222, label %bb_rcgcounted222
bb_rcgcounted222:
  %v891 = load i64, ptr %slot153, align 8
  %op892 = sub i64 %v891, 24
  store i64 %op892, ptr %slot159, align 8
  %v893 = load i64, ptr %slot153, align 8
  %p894 = inttoptr i64 %v893 to ptr
  %rgep895 = getelementptr i8, ptr %p894, i64 -24
  %ld896 = load i64, ptr %rgep895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld896, ptr %slot160, align 8
  %v897 = load i64, ptr %slot160, align 8
  %op898 = sub i64 %v897, 1
  store i64 %op898, ptr %slot161, align 8
  %v899 = load i64, ptr %slot161, align 8
  %cmp900 = icmp eq i64 %v899, 0
  %cv901 = zext i1 %cmp900 to i32
  store i32 %cv901, ptr %slot162, align 8
  %v902 = load i32, ptr %slot162, align 8
  %cv903 = zext i32 %v902 to i64
  %cond904 = icmp ne i64 %cv903, 0
  br i1 %cond904, label %bb_rcglast222, label %bb_rcgdec222
bb_rcglast222:
  %v905 = load i64, ptr %slot153, align 8
  %op906 = sub i64 %v905, 32
  store i64 %op906, ptr %slot163, align 8
  %v907 = load i64, ptr %slot153, align 8
  %p908 = inttoptr i64 %v907 to ptr
  %rgep909 = getelementptr i8, ptr %p908, i64 -32
  %ld910 = load i64, ptr %rgep909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld910, ptr %slot164, align 8
  %v911 = load i64, ptr %slot164, align 8
  %cmp912 = icmp ne i64 %v911, 0
  %cv913 = zext i1 %cmp912 to i32
  store i32 %cv913, ptr %slot165, align 8
  %v914 = load i32, ptr %slot165, align 8
  %cv915 = zext i32 %v914 to i64
  %cond916 = icmp ne i64 %cv915, 0
  br i1 %cond916, label %bb_rcgdec222, label %bb_rcgslow222
bb_rcgslow222:
  %v917 = load i64, ptr %slot152, align 8
  %v918 = load i64, ptr %slot149, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v917, i64 %v918)
  br label %bb_rcgdone222
bb_rcgdec222:
  %v919 = load i64, ptr %slot161, align 8
  %v920 = load i64, ptr %slot153, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %rgep922 = getelementptr i8, ptr %p921, i64 -24
  store i64 %v919, ptr %rgep922, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear222
bb_rcgclear222:
  %v923 = load i64, ptr %slot149, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i64 0, ptr %p924, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone222
bb_rcgdone222:
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v925 = load i64, ptr %slot29, align 8
  store i64 %v925, ptr %slot166, align 8
  %v926 = load i64, ptr %slot149, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i64, ptr %p927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld928, ptr %slot167, align 8
  %v929 = load i64, ptr %slot167, align 8
  %cmp930 = icmp ne i64 %v929, 0
  %cv931 = zext i1 %cmp930 to i32
  store i32 %cv931, ptr %slot168, align 8
  %v932 = load i32, ptr %slot168, align 8
  %cv933 = zext i32 %v932 to i64
  %cond934 = icmp ne i64 %cv933, 0
  br i1 %cond934, label %bb_rcgnn237, label %bb_rcgdone237
bb_rcgnn237:
  %v935 = load i64, ptr %slot167, align 8
  %op936 = sub i64 %v935, 16
  store i64 %op936, ptr %slot169, align 8
  %v937 = load i64, ptr %slot167, align 8
  %p938 = inttoptr i64 %v937 to ptr
  %rgep939 = getelementptr i8, ptr %p938, i64 -16
  %ld940 = load i64, ptr %rgep939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld940, ptr %slot170, align 8
  %v941 = load i64, ptr %slot170, align 8
  %op942 = and i64 %v941, 4611686018427387906
  store i64 %op942, ptr %slot171, align 8
  %v943 = load i64, ptr %slot171, align 8
  %cmp944 = icmp ne i64 %v943, 0
  %cv945 = zext i1 %cmp944 to i32
  store i32 %cv945, ptr %slot172, align 8
  %v946 = load i32, ptr %slot172, align 8
  %cv947 = zext i32 %v946 to i64
  %cond948 = icmp ne i64 %cv947, 0
  br i1 %cond948, label %bb_rcgclear237, label %bb_rcgcounted237
bb_rcgcounted237:
  %v949 = load i64, ptr %slot167, align 8
  %op950 = sub i64 %v949, 32
  store i64 %op950, ptr %slot173, align 8
  %v951 = load i64, ptr %slot167, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %rgep953 = getelementptr i8, ptr %p952, i64 -32
  %ld954 = load i64, ptr %rgep953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld954, ptr %slot174, align 8
  %v955 = load i64, ptr %slot174, align 8
  %op956 = sub i64 %v955, 1
  store i64 %op956, ptr %slot175, align 8
  %v957 = load i64, ptr %slot175, align 8
  %cmp958 = icmp eq i64 %v957, 0
  %cv959 = zext i1 %cmp958 to i32
  store i32 %cv959, ptr %slot176, align 8
  %v960 = load i32, ptr %slot176, align 8
  %cv961 = zext i32 %v960 to i64
  %cond962 = icmp ne i64 %cv961, 0
  br i1 %cond962, label %bb_rcglast237, label %bb_rcgdec237
bb_rcglast237:
  %v963 = load i64, ptr %slot167, align 8
  %op964 = sub i64 %v963, 24
  store i64 %op964, ptr %slot177, align 8
  %v965 = load i64, ptr %slot167, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %rgep967 = getelementptr i8, ptr %p966, i64 -24
  %ld968 = load i64, ptr %rgep967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld968, ptr %slot178, align 8
  %v969 = load i64, ptr %slot178, align 8
  %cmp970 = icmp ne i64 %v969, 0
  %cv971 = zext i1 %cmp970 to i32
  store i32 %cv971, ptr %slot179, align 8
  %v972 = load i32, ptr %slot179, align 8
  %cv973 = zext i32 %v972 to i64
  %cond974 = icmp ne i64 %cv973, 0
  br i1 %cond974, label %bb_rcgdec237, label %bb_rcgslow237
bb_rcgslow237:
  %v975 = load i64, ptr %slot166, align 8
  %v976 = load i64, ptr %slot149, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v975, i64 %v976)
  br label %bb_rcgdone237
bb_rcgdec237:
  %v977 = load i64, ptr %slot175, align 8
  %v978 = load i64, ptr %slot167, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %rgep980 = getelementptr i8, ptr %p979, i64 -32
  store i64 %v977, ptr %rgep980, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear237
bb_rcgclear237:
  %v981 = load i64, ptr %slot149, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i64 0, ptr %p982, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone237
bb_rcgdone237:
  br label %bb_rcslotdone206
bb_rcslotdone206:
  %v983 = load i64, ptr %slot21, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %ld985 = load i64, ptr %p984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld985, ptr %slot180, align 8
  %v986 = load i64, ptr %slot180, align 8
  %v987 = load i64, ptr %slot22, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i64 %v986, ptr %p988, align 8, !alias.scope !4, !noalias !3
  %v989 = load i64, ptr %slot16, align 8
  %p990 = inttoptr i64 %v989 to ptr
  %ld991 = load i64, ptr %p990, align 8, !alias.scope !4, !noalias !3
  store i64 %ld991, ptr %slot181, align 8
  %v992 = load i64, ptr %slot181, align 8
  %op993 = sub i64 %v992, 1
  store i64 %op993, ptr %slot182, align 8
  %v994 = load i64, ptr %slot182, align 8
  %v995 = load i64, ptr %slot16, align 8
  %p996 = inttoptr i64 %v995 to ptr
  store i64 %v994, ptr %p996, align 8, !alias.scope !4, !noalias !3
  %v997 = load i64, ptr %slot147, align 8
  ret i64 %v997
bb_i6:
  %v998 = load i64, ptr %slot27, align 8
  %p999 = inttoptr i64 %v998 to ptr
  store i64 6, ptr %p999, align 8, !alias.scope !3, !noalias !4
  %v1000 = load i64, ptr %slot1, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i64, ptr %p1001, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1002, ptr %slot183, align 8
  %v1003 = load i64, ptr %slot31, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i64, ptr %p1004, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1005, ptr %slot184, align 8
  %v1006 = load i64, ptr %slot183, align 8
  %v1007 = load i64, ptr %slot184, align 8
  %cmp1008 = icmp eq i64 %v1006, %v1007
  %cv1009 = zext i1 %cmp1008 to i64
  store i64 %cv1009, ptr %slot185, align 8
  %v1010 = load i64, ptr %slot185, align 8
  %cond1011 = icmp ne i64 %v1010, 0
  br i1 %cond1011, label %bb_step_limit, label %bb_step284
bb_step284:
  %v1012 = load i64, ptr %slot183, align 8
  %op1013 = add i64 %v1012, 1
  store i64 %op1013, ptr %slot186, align 8
  %v1014 = load i64, ptr %slot186, align 8
  %v1015 = load i64, ptr %slot1, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  store i64 %v1014, ptr %p1016, align 8, !alias.scope !4, !noalias !3
  %v1017 = load i64, ptr %slot15, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  store i64 0, ptr %p1018, align 8, !alias.scope !3, !noalias !4
  %v1019 = load i64, ptr %slot27, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i64 7, ptr %p1020, align 8, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot1, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i64, ptr %p1022, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1023, ptr %slot187, align 8
  %v1024 = load i64, ptr %slot31, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %ld1026 = load i64, ptr %p1025, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1026, ptr %slot188, align 8
  %v1027 = load i64, ptr %slot187, align 8
  %v1028 = load i64, ptr %slot188, align 8
  %cmp1029 = icmp eq i64 %v1027, %v1028
  %cv1030 = zext i1 %cmp1029 to i64
  store i64 %cv1030, ptr %slot189, align 8
  %v1031 = load i64, ptr %slot189, align 8
  %cond1032 = icmp ne i64 %v1031, 0
  br i1 %cond1032, label %bb_step_limit, label %bb_step288
bb_step288:
  %v1033 = load i64, ptr %slot187, align 8
  %op1034 = add i64 %v1033, 1
  store i64 %op1034, ptr %slot190, align 8
  %v1035 = load i64, ptr %slot190, align 8
  %v1036 = load i64, ptr %slot1, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i64 %v1035, ptr %p1037, align 8, !alias.scope !4, !noalias !3
  %v1038 = load i64, ptr %slot15, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %ld1040 = load i64, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1040, ptr %slot191, align 8
  %v1041 = load i64, ptr %slot4, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  %ld1043 = load i32, ptr %p1042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1043, ptr %slot192, align 8
  %v1044 = load i32, ptr %slot192, align 8
  %cv1045 = zext i32 %v1044 to i64
  %cond1046 = icmp ne i64 %cv1045, 0
  br i1 %cond1046, label %bb_rcslotdrop295, label %bb_rcslotdone295
bb_rcslotdrop295:
  %v1047 = load i64, ptr %slot4, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i32 0, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot13, align 8
  store i64 %v1049, ptr %slot193, align 8
  %v1050 = load i64, ptr %slot5, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %ld1052 = load i32, ptr %p1051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1052, ptr %slot194, align 8
  %v1053 = load i32, ptr %slot194, align 8
  %op1054 = and i32 %v1053, 28
  store i32 %op1054, ptr %slot195, align 8
  %v1055 = load i32, ptr %slot195, align 8
  %cv1056 = zext i32 %v1055 to i64
  %cond1057 = icmp ne i64 %cv1056, 0
  br i1 %cond1057, label %bb_rcslotrole295, label %bb_rcslotowner295
bb_rcslotrole295:
  %v1058 = load i64, ptr %slot29, align 8
  store i64 %v1058, ptr %slot196, align 8
  %v1059 = load i64, ptr %slot193, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %ld1061 = load i64, ptr %p1060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1061, ptr %slot197, align 8
  %v1062 = load i64, ptr %slot197, align 8
  %cmp1063 = icmp ne i64 %v1062, 0
  %cv1064 = zext i1 %cmp1063 to i32
  store i32 %cv1064, ptr %slot198, align 8
  %v1065 = load i32, ptr %slot198, align 8
  %cv1066 = zext i32 %v1065 to i64
  %cond1067 = icmp ne i64 %cv1066, 0
  br i1 %cond1067, label %bb_rcgnn311, label %bb_rcgdone311
bb_rcgnn311:
  %v1068 = load i64, ptr %slot197, align 8
  %op1069 = sub i64 %v1068, 16
  store i64 %op1069, ptr %slot199, align 8
  %v1070 = load i64, ptr %slot197, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %rgep1072 = getelementptr i8, ptr %p1071, i64 -16
  %ld1073 = load i64, ptr %rgep1072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1073, ptr %slot200, align 8
  %v1074 = load i64, ptr %slot200, align 8
  %op1075 = and i64 %v1074, 4611686018427387906
  store i64 %op1075, ptr %slot201, align 8
  %v1076 = load i64, ptr %slot201, align 8
  %cmp1077 = icmp ne i64 %v1076, 0
  %cv1078 = zext i1 %cmp1077 to i32
  store i32 %cv1078, ptr %slot202, align 8
  %v1079 = load i32, ptr %slot202, align 8
  %cv1080 = zext i32 %v1079 to i64
  %cond1081 = icmp ne i64 %cv1080, 0
  br i1 %cond1081, label %bb_rcgclear311, label %bb_rcgcounted311
bb_rcgcounted311:
  %v1082 = load i64, ptr %slot197, align 8
  %op1083 = sub i64 %v1082, 24
  store i64 %op1083, ptr %slot203, align 8
  %v1084 = load i64, ptr %slot197, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %rgep1086 = getelementptr i8, ptr %p1085, i64 -24
  %ld1087 = load i64, ptr %rgep1086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1087, ptr %slot204, align 8
  %v1088 = load i64, ptr %slot204, align 8
  %op1089 = sub i64 %v1088, 1
  store i64 %op1089, ptr %slot205, align 8
  %v1090 = load i64, ptr %slot205, align 8
  %cmp1091 = icmp eq i64 %v1090, 0
  %cv1092 = zext i1 %cmp1091 to i32
  store i32 %cv1092, ptr %slot206, align 8
  %v1093 = load i32, ptr %slot206, align 8
  %cv1094 = zext i32 %v1093 to i64
  %cond1095 = icmp ne i64 %cv1094, 0
  br i1 %cond1095, label %bb_rcglast311, label %bb_rcgdec311
bb_rcglast311:
  %v1096 = load i64, ptr %slot197, align 8
  %op1097 = sub i64 %v1096, 32
  store i64 %op1097, ptr %slot207, align 8
  %v1098 = load i64, ptr %slot197, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %rgep1100 = getelementptr i8, ptr %p1099, i64 -32
  %ld1101 = load i64, ptr %rgep1100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1101, ptr %slot208, align 8
  %v1102 = load i64, ptr %slot208, align 8
  %cmp1103 = icmp ne i64 %v1102, 0
  %cv1104 = zext i1 %cmp1103 to i32
  store i32 %cv1104, ptr %slot209, align 8
  %v1105 = load i32, ptr %slot209, align 8
  %cv1106 = zext i32 %v1105 to i64
  %cond1107 = icmp ne i64 %cv1106, 0
  br i1 %cond1107, label %bb_rcgdec311, label %bb_rcgslow311
bb_rcgslow311:
  %v1108 = load i64, ptr %slot196, align 8
  %v1109 = load i64, ptr %slot193, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v1108, i64 %v1109)
  br label %bb_rcgdone311
bb_rcgdec311:
  %v1110 = load i64, ptr %slot205, align 8
  %v1111 = load i64, ptr %slot197, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  %rgep1113 = getelementptr i8, ptr %p1112, i64 -24
  store i64 %v1110, ptr %rgep1113, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear311
bb_rcgclear311:
  %v1114 = load i64, ptr %slot193, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i64 0, ptr %p1115, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone311
bb_rcgdone311:
  br label %bb_rcslotdone295
bb_rcslotowner295:
  %v1116 = load i64, ptr %slot29, align 8
  store i64 %v1116, ptr %slot210, align 8
  %v1117 = load i64, ptr %slot193, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i64, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1119, ptr %slot211, align 8
  %v1120 = load i64, ptr %slot211, align 8
  %cmp1121 = icmp ne i64 %v1120, 0
  %cv1122 = zext i1 %cmp1121 to i32
  store i32 %cv1122, ptr %slot212, align 8
  %v1123 = load i32, ptr %slot212, align 8
  %cv1124 = zext i32 %v1123 to i64
  %cond1125 = icmp ne i64 %cv1124, 0
  br i1 %cond1125, label %bb_rcgnn326, label %bb_rcgdone326
bb_rcgnn326:
  %v1126 = load i64, ptr %slot211, align 8
  %op1127 = sub i64 %v1126, 16
  store i64 %op1127, ptr %slot213, align 8
  %v1128 = load i64, ptr %slot211, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %rgep1130 = getelementptr i8, ptr %p1129, i64 -16
  %ld1131 = load i64, ptr %rgep1130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1131, ptr %slot214, align 8
  %v1132 = load i64, ptr %slot214, align 8
  %op1133 = and i64 %v1132, 4611686018427387906
  store i64 %op1133, ptr %slot215, align 8
  %v1134 = load i64, ptr %slot215, align 8
  %cmp1135 = icmp ne i64 %v1134, 0
  %cv1136 = zext i1 %cmp1135 to i32
  store i32 %cv1136, ptr %slot216, align 8
  %v1137 = load i32, ptr %slot216, align 8
  %cv1138 = zext i32 %v1137 to i64
  %cond1139 = icmp ne i64 %cv1138, 0
  br i1 %cond1139, label %bb_rcgclear326, label %bb_rcgcounted326
bb_rcgcounted326:
  %v1140 = load i64, ptr %slot211, align 8
  %op1141 = sub i64 %v1140, 32
  store i64 %op1141, ptr %slot217, align 8
  %v1142 = load i64, ptr %slot211, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %rgep1144 = getelementptr i8, ptr %p1143, i64 -32
  %ld1145 = load i64, ptr %rgep1144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1145, ptr %slot218, align 8
  %v1146 = load i64, ptr %slot218, align 8
  %op1147 = sub i64 %v1146, 1
  store i64 %op1147, ptr %slot219, align 8
  %v1148 = load i64, ptr %slot219, align 8
  %cmp1149 = icmp eq i64 %v1148, 0
  %cv1150 = zext i1 %cmp1149 to i32
  store i32 %cv1150, ptr %slot220, align 8
  %v1151 = load i32, ptr %slot220, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcglast326, label %bb_rcgdec326
bb_rcglast326:
  %v1154 = load i64, ptr %slot211, align 8
  %op1155 = sub i64 %v1154, 24
  store i64 %op1155, ptr %slot221, align 8
  %v1156 = load i64, ptr %slot211, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %rgep1158 = getelementptr i8, ptr %p1157, i64 -24
  %ld1159 = load i64, ptr %rgep1158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1159, ptr %slot222, align 8
  %v1160 = load i64, ptr %slot222, align 8
  %cmp1161 = icmp ne i64 %v1160, 0
  %cv1162 = zext i1 %cmp1161 to i32
  store i32 %cv1162, ptr %slot223, align 8
  %v1163 = load i32, ptr %slot223, align 8
  %cv1164 = zext i32 %v1163 to i64
  %cond1165 = icmp ne i64 %cv1164, 0
  br i1 %cond1165, label %bb_rcgdec326, label %bb_rcgslow326
bb_rcgslow326:
  %v1166 = load i64, ptr %slot210, align 8
  %v1167 = load i64, ptr %slot193, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v1166, i64 %v1167)
  br label %bb_rcgdone326
bb_rcgdec326:
  %v1168 = load i64, ptr %slot219, align 8
  %v1169 = load i64, ptr %slot211, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %rgep1171 = getelementptr i8, ptr %p1170, i64 -32
  store i64 %v1168, ptr %rgep1171, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear326
bb_rcgclear326:
  %v1172 = load i64, ptr %slot193, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i64 0, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone326
bb_rcgdone326:
  br label %bb_rcslotdone295
bb_rcslotdone295:
  %v1174 = load i64, ptr %slot21, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot224, align 8
  %v1177 = load i64, ptr %slot224, align 8
  %v1178 = load i64, ptr %slot22, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i64 %v1177, ptr %p1179, align 8, !alias.scope !4, !noalias !3
  %v1180 = load i64, ptr %slot16, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  %ld1182 = load i64, ptr %p1181, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1182, ptr %slot225, align 8
  %v1183 = load i64, ptr %slot225, align 8
  %op1184 = sub i64 %v1183, 1
  store i64 %op1184, ptr %slot226, align 8
  %v1185 = load i64, ptr %slot226, align 8
  %v1186 = load i64, ptr %slot16, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i64 %v1185, ptr %p1187, align 8, !alias.scope !4, !noalias !3
  %v1188 = load i64, ptr %slot191, align 8
  ret i64 %v1188
bb_step_limit:
  %v1189 = load i64, ptr %slot1, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  call void @myl_qbe_fail_step(ptr %p1190)
  br label %bb_failure
bb_failure:
  %v1191 = load i64, ptr %slot21, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i64, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1193, ptr %slot227, align 8
  %v1194 = load i64, ptr %slot227, align 8
  %v1195 = load i64, ptr %slot22, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i64 %v1194, ptr %p1196, align 8, !alias.scope !4, !noalias !3
  %v1197 = load i64, ptr %slot16, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %ld1199 = load i64, ptr %p1198, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1199, ptr %slot228, align 8
  %v1200 = load i64, ptr %slot228, align 8
  %op1201 = sub i64 %v1200, 1
  store i64 %op1201, ptr %slot229, align 8
  %v1202 = load i64, ptr %slot229, align 8
  %v1203 = load i64, ptr %slot16, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i64 %v1202, ptr %p1204, align 8, !alias.scope !4, !noalias !3
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare void @myl_qbe_fail_frame(ptr) cold
declare void @myl_qbe_fail_step(ptr) cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
