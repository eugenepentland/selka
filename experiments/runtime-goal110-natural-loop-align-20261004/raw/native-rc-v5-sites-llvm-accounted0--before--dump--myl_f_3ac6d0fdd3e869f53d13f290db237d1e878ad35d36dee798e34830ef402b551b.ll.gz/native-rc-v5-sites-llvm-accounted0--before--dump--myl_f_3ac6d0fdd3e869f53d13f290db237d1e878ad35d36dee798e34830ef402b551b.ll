target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v119 = load i64, ptr %slot1, align 8
  %op120 = add i64 %v119, 32
  store i64 %op120, ptr %slot3, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot4, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot5, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot6, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot7, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot8, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot9, align 8
  %mem133 = alloca i8, i64 16, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot10, align 8
  %mem135 = alloca i8, i64 16, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot11, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot12, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot13, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot14, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot15, align 8
  %mem145 = alloca i8, i64 16, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot16, align 8
  %v147 = load i64, ptr %slot13, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 0, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot2, align 8
  %v150 = load i64, ptr %slot12, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot1, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %call154 = call ptr @myl_qbe_heap(ptr %p153) nomerge, !dbg !110
  %calladdr155 = ptrtoint ptr %call154 to i64
  store i64 %calladdr155, ptr %slot17, align 8
  %p156 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite0 to i64) to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !4, !noalias !3
  store i64 %ld157, ptr %slot18, align 8
  %v158 = load i64, ptr %slot18, align 8
  %op159 = add i64 %v158, 1
  store i64 %op159, ptr %slot19, align 8
  %v160 = load i64, ptr %slot19, align 8
  %p161 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite0 to i64) to ptr
  store i64 %v160, ptr %p161, align 8, !alias.scope !4, !noalias !3
  %p162 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite0 to i64), ptr %p162, align 8, !alias.scope !4, !noalias !3
  %v163 = load i64, ptr %slot1, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %call165 = call i64 @myl_qbe_region_mark(ptr %p164) nomerge, !dbg !110
  store i64 %call165, ptr %slot20, align 8
  %v166 = load i64, ptr %slot4, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot5, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot6, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i32 0, ptr %p173, align 4, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot8, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 0, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot5, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 2, ptr %p177, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v178 = load i64, ptr %slot12, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot21, align 8
  %v181 = load i64, ptr %slot21, align 8
  %v182 = load i64, ptr %slot15, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot15, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot22, align 8
  %v187 = load i64, ptr %slot22, align 8
  %v188 = load i64, ptr %slot9, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot9, align 8
  store i64 %v190, ptr %slot23, align 8
  store i32 0, ptr %slot24, align 8
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i32, ptr %p192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld193, ptr %slot25, align 8
  %v194 = load i32, ptr %slot25, align 8
  %op195 = and i32 %v194, 24
  store i32 %op195, ptr %slot25, align 8
  %v196 = load i32, ptr %slot25, align 8
  %cmp197 = icmp eq i32 %v196, 0
  %cv198 = zext i1 %cmp197 to i32
  store i32 %cv198, ptr %slot26, align 8
  %v199 = load i32, ptr %slot24, align 8
  %v200 = load i32, ptr %slot26, align 8
  %op201 = and i32 %v199, %v200
  store i32 %op201, ptr %slot27, align 8
  %v202 = load i32, ptr %slot27, align 8
  %cv203 = zext i32 %v202 to i64
  %cond204 = icmp ne i64 %cv203, 0
  br i1 %cond204, label %bb_rcprivateown11, label %bb_rcprivateloan11
bb_rcprivateown11:
  %v205 = load i64, ptr %slot10, align 8
  store i64 %v205, ptr %slot28, align 8
  %v206 = load i64, ptr %slot20, align 8
  store i64 %v206, ptr %slot29, align 8
  %v207 = load i64, ptr %slot23, align 8
  %v208 = load i64, ptr %slot28, align 8
  %op209 = sub i64 %v207, %v208
  store i64 %op209, ptr %slot30, align 8
  %v210 = load i64, ptr %slot28, align 8
  %v211 = load i64, ptr %slot23, align 8
  %op212 = sub i64 %v210, %v211
  store i64 %op212, ptr %slot31, align 8
  %v213 = load i64, ptr %slot30, align 8
  %cmp214 = icmp ult i64 %v213, 8
  %cv215 = zext i1 %cmp214 to i32
  store i32 %cv215, ptr %slot32, align 8
  %v216 = load i64, ptr %slot31, align 8
  %cmp217 = icmp ult i64 %v216, 8
  %cv218 = zext i1 %cmp217 to i32
  store i32 %cv218, ptr %slot33, align 8
  %v219 = load i32, ptr %slot32, align 8
  %v220 = load i32, ptr %slot33, align 8
  %op221 = or i32 %v219, %v220
  store i32 %op221, ptr %slot34, align 8
  %v222 = load i32, ptr %slot34, align 8
  %cv223 = zext i32 %v222 to i64
  %cond224 = icmp ne i64 %cv223, 0
  br i1 %cond224, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v225 = load i64, ptr %slot23, align 8
  %p227 = inttoptr i64 %v225 to ptr
  %gep228 = getelementptr i8, ptr %p227, i64 0
  %op226 = ptrtoint ptr %gep228 to i64
  store i64 %op226, ptr %slot35, align 8
  %v229 = load i64, ptr %slot35, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld231, ptr %slot36, align 8
  %v232 = load i64, ptr %slot36, align 8
  %cmp233 = icmp ne i64 %v232, 0
  %cv234 = zext i1 %cmp233 to i32
  store i32 %cv234, ptr %slot37, align 8
  %v235 = load i32, ptr %slot37, align 8
  %cv236 = zext i32 %v235 to i64
  %cond237 = icmp ne i64 %cv236, 0
  br i1 %cond237, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v238 = load i64, ptr %slot36, align 8
  %op239 = sub i64 %v238, 16
  store i64 %op239, ptr %slot38, align 8
  %v240 = load i64, ptr %slot36, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %rgep242 = getelementptr i8, ptr %p241, i64 -16
  %ld243 = load i64, ptr %rgep242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld243, ptr %slot39, align 8
  %v244 = load i64, ptr %slot39, align 8
  %op245 = and i64 %v244, 5764607523034234881
  store i64 %op245, ptr %slot40, align 8
  %v246 = load i64, ptr %slot40, align 8
  %cmp247 = icmp ne i64 %v246, 0
  %cv248 = zext i1 %cmp247 to i32
  store i32 %cv248, ptr %slot41, align 8
  %v249 = load i32, ptr %slot41, align 8
  %cv250 = zext i32 %v249 to i64
  %cond251 = icmp ne i64 %cv250, 0
  br i1 %cond251, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v252 = load i64, ptr %slot23, align 8
  %v253 = load i64, ptr %slot28, align 8
  %p254 = inttoptr i64 %v252 to ptr
  %p255 = inttoptr i64 %v253 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p255, ptr %p254, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot23, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 0, ptr %p257, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %p258 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite1 to i64) to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !4, !noalias !3
  store i64 %ld259, ptr %slot42, align 8
  %v260 = load i64, ptr %slot42, align 8
  %op261 = add i64 %v260, 1
  store i64 %op261, ptr %slot43, align 8
  %v262 = load i64, ptr %slot43, align 8
  %p263 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite1 to i64) to ptr
  store i64 %v262, ptr %p263, align 8, !alias.scope !4, !noalias !3
  %p264 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite1 to i64), ptr %p264, align 8, !alias.scope !4, !noalias !3
  %v265 = load i64, ptr %slot17, align 8
  %v266 = load i64, ptr %slot28, align 8
  %v267 = load i64, ptr %slot23, align 8
  %v268 = load i64, ptr %slot29, align 8
  %cv269 = trunc i64 %v268 to i32
  %call270 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v265, i64 %v266, i64 %v267, i32 %cv269) nomerge, !dbg !112
  store i32 %call270, ptr %slot44, align 8
  %v271 = load i32, ptr %slot44, align 8
  %cv272 = zext i32 %v271 to i64
  %cond273 = icmp ne i64 %cv272, 0
  br i1 %cond273, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %p274 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite2 to i64) to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !4, !noalias !3
  store i64 %ld275, ptr %slot45, align 8
  %v276 = load i64, ptr %slot45, align 8
  %op277 = add i64 %v276, 1
  store i64 %op277, ptr %slot46, align 8
  %v278 = load i64, ptr %slot46, align 8
  %p279 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite2 to i64) to ptr
  store i64 %v278, ptr %p279, align 8, !alias.scope !4, !noalias !3
  %p280 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite2 to i64), ptr %p280, align 8, !alias.scope !4, !noalias !3
  %v281 = load i64, ptr %slot17, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %call283 = call i32 @myl_rc_take_failure(ptr %p282) nomerge, !dbg !112
  store i32 %call283, ptr %slot47, align 8
  %p284 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite3 to i64) to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !4, !noalias !3
  store i64 %ld285, ptr %slot48, align 8
  %v286 = load i64, ptr %slot48, align 8
  %op287 = add i64 %v286, 1
  store i64 %op287, ptr %slot49, align 8
  %v288 = load i64, ptr %slot49, align 8
  %p289 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite3 to i64) to ptr
  store i64 %v288, ptr %p289, align 8, !alias.scope !4, !noalias !3
  %p290 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite3 to i64), ptr %p290, align 8, !alias.scope !4, !noalias !3
  %v291 = load i64, ptr %slot1, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %v293 = load i32, ptr %slot47, align 8
  %call294 = call i32 @myl_qbe_rc_status(ptr %p292, i32 %v293) nomerge, !dbg !112
  store i32 %call294, ptr %slot50, align 8
  br label %bb_failure
bb_rcsuccess29:
  br label %bb_rcmoved14
bb_rcmoved14:
  %v295 = load i64, ptr %slot8, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i32 2, ptr %p296, align 4, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot7, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i32 1, ptr %p298, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateloan11:
  %v299 = load i64, ptr %slot10, align 8
  store i64 %v299, ptr %slot51, align 8
  %p300 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite4 to i64) to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !4, !noalias !3
  store i64 %ld301, ptr %slot52, align 8
  %v302 = load i64, ptr %slot52, align 8
  %op303 = add i64 %v302, 1
  store i64 %op303, ptr %slot53, align 8
  %v304 = load i64, ptr %slot53, align 8
  %p305 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite4 to i64) to ptr
  store i64 %v304, ptr %p305, align 8, !alias.scope !4, !noalias !3
  %p306 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite4 to i64), ptr %p306, align 8, !alias.scope !4, !noalias !3
  %v307 = load i64, ptr %slot17, align 8
  %v308 = load i64, ptr %slot51, align 8
  %v309 = load i64, ptr %slot23, align 8
  %call310 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan(i64 %v307, i64 %v308, i64 %v309) nomerge, !dbg !112
  store i32 %call310, ptr %slot54, align 8
  %v311 = load i32, ptr %slot54, align 8
  %cv312 = zext i32 %v311 to i64
  %cond313 = icmp ne i64 %cv312, 0
  br i1 %cond313, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %p314 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite5 to i64) to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !4, !noalias !3
  store i64 %ld315, ptr %slot55, align 8
  %v316 = load i64, ptr %slot55, align 8
  %op317 = add i64 %v316, 1
  store i64 %op317, ptr %slot56, align 8
  %v318 = load i64, ptr %slot56, align 8
  %p319 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite5 to i64) to ptr
  store i64 %v318, ptr %p319, align 8, !alias.scope !4, !noalias !3
  %p320 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite5 to i64), ptr %p320, align 8, !alias.scope !4, !noalias !3
  %v321 = load i64, ptr %slot17, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %call323 = call i32 @myl_rc_take_failure(ptr %p322) nomerge, !dbg !112
  store i32 %call323, ptr %slot57, align 8
  %p324 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite6 to i64) to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !4, !noalias !3
  store i64 %ld325, ptr %slot58, align 8
  %v326 = load i64, ptr %slot58, align 8
  %op327 = add i64 %v326, 1
  store i64 %op327, ptr %slot59, align 8
  %v328 = load i64, ptr %slot59, align 8
  %p329 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite6 to i64) to ptr
  store i64 %v328, ptr %p329, align 8, !alias.scope !4, !noalias !3
  %p330 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite6 to i64), ptr %p330, align 8, !alias.scope !4, !noalias !3
  %v331 = load i64, ptr %slot1, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %v333 = load i32, ptr %slot57, align 8
  %call334 = call i32 @myl_qbe_rc_status(ptr %p332, i32 %v333) nomerge, !dbg !112
  store i32 %call334, ptr %slot60, align 8
  br label %bb_failure
bb_rcsuccess37:
  %v335 = load i64, ptr %slot8, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 2, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot8, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 16, ptr %p338, align 4, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot7, align 8
  %p340 = inttoptr i64 %v339 to ptr
  store i32 1, ptr %p340, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateprepared11:
  %v341 = load i64, ptr %slot4, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i32, ptr %p342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld343, ptr %slot61, align 8
  %v344 = load i32, ptr %slot61, align 8
  %cv345 = zext i32 %v344 to i64
  %cond346 = icmp ne i64 %cv345, 0
  br i1 %cond346, label %bb_rcslotdrop55, label %bb_rcslotdone55
bb_rcslotdrop55:
  %v347 = load i64, ptr %slot4, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i32 0, ptr %p348, align 4, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot13, align 8
  store i64 %v349, ptr %slot62, align 8
  %v350 = load i64, ptr %slot5, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i32, ptr %p351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld352, ptr %slot63, align 8
  %v353 = load i32, ptr %slot63, align 8
  %op354 = and i32 %v353, 28
  store i32 %op354, ptr %slot64, align 8
  %v355 = load i32, ptr %slot64, align 8
  %cv356 = zext i32 %v355 to i64
  %cond357 = icmp ne i64 %cv356, 0
  br i1 %cond357, label %bb_rcslotrole55, label %bb_rcslotowner55
bb_rcslotrole55:
  %v358 = load i64, ptr %slot17, align 8
  store i64 %v358, ptr %slot65, align 8
  %p359 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite9 to i64) to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !4, !noalias !3
  store i64 %ld360, ptr %slot66, align 8
  %v361 = load i64, ptr %slot66, align 8
  %op362 = add i64 %v361, 1
  store i64 %op362, ptr %slot67, align 8
  %v363 = load i64, ptr %slot67, align 8
  %p364 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite9 to i64) to ptr
  store i64 %v363, ptr %p364, align 8, !alias.scope !4, !noalias !3
  %p365 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite9 to i64), ptr %p365, align 8, !alias.scope !4, !noalias !3
  %v366 = load i64, ptr %slot65, align 8
  %v367 = load i64, ptr %slot62, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v366, i64 %v367) nomerge, !dbg !112
  br label %bb_rcslotdone55
bb_rcslotowner55:
  %v368 = load i64, ptr %slot17, align 8
  store i64 %v368, ptr %slot68, align 8
  %p369 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite10 to i64) to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !4, !noalias !3
  store i64 %ld370, ptr %slot69, align 8
  %v371 = load i64, ptr %slot69, align 8
  %op372 = add i64 %v371, 1
  store i64 %op372, ptr %slot70, align 8
  %v373 = load i64, ptr %slot70, align 8
  %p374 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite10 to i64) to ptr
  store i64 %v373, ptr %p374, align 8, !alias.scope !4, !noalias !3
  %p375 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite10 to i64), ptr %p375, align 8, !alias.scope !4, !noalias !3
  %v376 = load i64, ptr %slot68, align 8
  %v377 = load i64, ptr %slot62, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v376, i64 %v377) nomerge, !dbg !112
  br label %bb_rcslotdone55
bb_rcslotdone55:
  %v378 = load i64, ptr %slot13, align 8
  store i64 %v378, ptr %slot71, align 8
  %v379 = load i64, ptr %slot10, align 8
  store i64 %v379, ptr %slot72, align 8
  %v380 = load i64, ptr %slot72, align 8
  %v381 = load i64, ptr %slot71, align 8
  %p382 = inttoptr i64 %v380 to ptr
  %p383 = inttoptr i64 %v381 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p383, ptr %p382, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot7, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i32 0, ptr %p385, align 4, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot5, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 2, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot8, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i32, ptr %p389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld390, ptr %slot73, align 8
  %v391 = load i32, ptr %slot73, align 8
  %v392 = load i64, ptr %slot5, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i32 %v391, ptr %p393, align 4, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot4, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i32 1, ptr %p395, align 4, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot13, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot74, align 8
  %v399 = load i64, ptr %slot13, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot75, align 8
  %p402 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite11 to i64) to ptr
  %ld403 = load i64, ptr %p402, align 8, !alias.scope !4, !noalias !3
  store i64 %ld403, ptr %slot76, align 8
  %v404 = load i64, ptr %slot76, align 8
  %op405 = add i64 %v404, 1
  store i64 %op405, ptr %slot77, align 8
  %v406 = load i64, ptr %slot77, align 8
  %p407 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite11 to i64) to ptr
  store i64 %v406, ptr %p407, align 8, !alias.scope !4, !noalias !3
  %p408 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite11 to i64), ptr %p408, align 8, !alias.scope !4, !noalias !3
  %v409 = load i64, ptr %slot75, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %call411 = call ptr @myl_native_text_payload(ptr %p410) nomerge, !dbg !114
  %calladdr412 = ptrtoint ptr %call411 to i64
  store i64 %calladdr412, ptr %slot78, align 8
  %v413 = load i64, ptr %slot75, align 8
  %op414 = add i64 %v413, 8
  store i64 %op414, ptr %slot79, align 8
  %v415 = load i64, ptr %slot79, align 8
  %p416 = inttoptr i64 %v415 to ptr
  %ld417 = load i64, ptr %p416, align 8
  store i64 %ld417, ptr %slot80, align 8
  %p418 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite12 to i64) to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !4, !noalias !3
  store i64 %ld419, ptr %slot81, align 8
  %v420 = load i64, ptr %slot81, align 8
  %op421 = add i64 %v420, 1
  store i64 %op421, ptr %slot82, align 8
  %v422 = load i64, ptr %slot82, align 8
  %p423 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite12 to i64) to ptr
  store i64 %v422, ptr %p423, align 8, !alias.scope !4, !noalias !3
  %p424 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite12 to i64), ptr %p424, align 8, !alias.scope !4, !noalias !3
  %v425 = load i64, ptr %slot78, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %v427 = load i64, ptr %slot80, align 8
  %v428 = load i64, ptr %slot11, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %call430 = call i32 @myl_native_bytes_number_parse(ptr %p426, i64 %v427, i32 0, ptr %p429) nomerge, !dbg !114
  store i32 %call430, ptr %slot83, align 8
  %v431 = load i64, ptr %slot11, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i64, ptr %p432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld433, ptr %slot84, align 8
  %v434 = load i64, ptr %slot16, align 8
  store i64 %v434, ptr %slot85, align 8
  %v435 = load i64, ptr %slot85, align 8
  %p437 = inttoptr i64 %v435 to ptr
  %gep438 = getelementptr i8, ptr %p437, i64 8
  %op436 = ptrtoint ptr %gep438 to i64
  store i64 %op436, ptr %slot86, align 8
  %v439 = load i32, ptr %slot83, align 8
  %cv440 = zext i32 %v439 to i64
  %cond441 = icmp ne i64 %cv440, 0
  br i1 %cond441, label %bb_some79, label %bb_none79
bb_some79:
  %v442 = load i64, ptr %slot85, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i32 1, ptr %p443, align 4, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot84, align 8
  %v445 = load i64, ptr %slot86, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 %v444, ptr %p446, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed79
bb_none79:
  %v447 = load i64, ptr %slot85, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 0, ptr %p448, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed79
bb_parsed79:
  %v449 = load i64, ptr %slot85, align 8
  %v450 = load i64, ptr %slot15, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot15, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot87, align 8
  %v455 = load i64, ptr %slot87, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i32, ptr %p456, align 4, !alias.scope !3, !noalias !4
  %ext458 = zext i32 %ld457 to i64
  store i64 %ext458, ptr %slot88, align 8
  %v459 = load i64, ptr %slot88, align 8
  %cmp460 = icmp eq i64 %v459, 0
  %cv461 = zext i1 %cmp460 to i64
  store i64 %cv461, ptr %slot89, align 8
  %v462 = load i64, ptr %slot89, align 8
  %cond463 = icmp ne i64 %v462, 0
  br i1 %cond463, label %bb_rcarm82, label %bb_rcarmnext82
bb_rcarm82:
  br label %bb_i6
bb_rcarmnext82:
  %v464 = load i64, ptr %slot88, align 8
  %cmp465 = icmp eq i64 %v464, 1
  %cv466 = zext i1 %cmp465 to i64
  store i64 %cv466, ptr %slot90, align 8
  %v467 = load i64, ptr %slot90, align 8
  %cond468 = icmp ne i64 %v467, 0
  br i1 %cond468, label %bb_rcarm83, label %bb_rcarmnext83
bb_rcarm83:
  %v469 = load i64, ptr %slot10, align 8
  store i64 %v469, ptr %slot91, align 8
  %v470 = load i64, ptr %slot87, align 8
  %op471 = add i64 %v470, 8
  store i64 %op471, ptr %slot92, align 8
  %v472 = load i64, ptr %slot20, align 8
  store i64 %v472, ptr %slot93, align 8
  %v473 = load i64, ptr %slot92, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld475, ptr %slot94, align 8
  %v476 = load i64, ptr %slot94, align 8
  %v477 = load i64, ptr %slot91, align 8
  %p478 = inttoptr i64 %v477 to ptr
  store i64 %v476, ptr %p478, align 8, !alias.scope !3, !noalias !4
  %v479 = load i64, ptr %slot8, align 8
  %p480 = inttoptr i64 %v479 to ptr
  store i32 0, ptr %p480, align 4, !alias.scope !3, !noalias !4
  %v481 = load i64, ptr %slot7, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i32 1, ptr %p482, align 4, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot91, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i64, ptr %p484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld485, ptr %slot95, align 8
  %v486 = load i64, ptr %slot95, align 8
  %v487 = load i64, ptr %slot14, align 8
  %p488 = inttoptr i64 %v487 to ptr
  store i64 %v486, ptr %p488, align 8, !alias.scope !3, !noalias !4
  %v489 = load i64, ptr %slot7, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i32 0, ptr %p490, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext83:
  br label %bb_failure
bb_i4:
  %v491 = load i64, ptr %slot14, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %ld493 = load i64, ptr %p492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld493, ptr %slot96, align 8
  %v494 = load i64, ptr %slot96, align 8
  %v495 = load i64, ptr %slot15, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i64 %v494, ptr %p496, align 8, !alias.scope !3, !noalias !4
  %v497 = load i64, ptr %slot15, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i64, ptr %p498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld499, ptr %slot97, align 8
  %v500 = load i64, ptr %slot4, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i32, ptr %p501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld502, ptr %slot98, align 8
  %v503 = load i32, ptr %slot98, align 8
  %cv504 = zext i32 %v503 to i64
  %cond505 = icmp ne i64 %cv504, 0
  br i1 %cond505, label %bb_rcslotdrop99, label %bb_rcslotdone99
bb_rcslotdrop99:
  %v506 = load i64, ptr %slot4, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i32 0, ptr %p507, align 4, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot13, align 8
  store i64 %v508, ptr %slot99, align 8
  %v509 = load i64, ptr %slot5, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %ld511 = load i32, ptr %p510, align 4, !alias.scope !3, !noalias !4
  store i32 %ld511, ptr %slot100, align 8
  %v512 = load i32, ptr %slot100, align 8
  %op513 = and i32 %v512, 28
  store i32 %op513, ptr %slot101, align 8
  %v514 = load i32, ptr %slot101, align 8
  %cv515 = zext i32 %v514 to i64
  %cond516 = icmp ne i64 %cv515, 0
  br i1 %cond516, label %bb_rcslotrole99, label %bb_rcslotowner99
bb_rcslotrole99:
  %v517 = load i64, ptr %slot17, align 8
  store i64 %v517, ptr %slot102, align 8
  %p518 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite13 to i64) to ptr
  %ld519 = load i64, ptr %p518, align 8, !alias.scope !4, !noalias !3
  store i64 %ld519, ptr %slot103, align 8
  %v520 = load i64, ptr %slot103, align 8
  %op521 = add i64 %v520, 1
  store i64 %op521, ptr %slot104, align 8
  %v522 = load i64, ptr %slot104, align 8
  %p523 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite13 to i64) to ptr
  store i64 %v522, ptr %p523, align 8, !alias.scope !4, !noalias !3
  %p524 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite13 to i64), ptr %p524, align 8, !alias.scope !4, !noalias !3
  %v525 = load i64, ptr %slot102, align 8
  %v526 = load i64, ptr %slot99, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v525, i64 %v526) nomerge, !dbg !116
  br label %bb_rcslotdone99
bb_rcslotowner99:
  %v527 = load i64, ptr %slot17, align 8
  store i64 %v527, ptr %slot105, align 8
  %p528 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite14 to i64) to ptr
  %ld529 = load i64, ptr %p528, align 8, !alias.scope !4, !noalias !3
  store i64 %ld529, ptr %slot106, align 8
  %v530 = load i64, ptr %slot106, align 8
  %op531 = add i64 %v530, 1
  store i64 %op531, ptr %slot107, align 8
  %v532 = load i64, ptr %slot107, align 8
  %p533 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite14 to i64) to ptr
  store i64 %v532, ptr %p533, align 8, !alias.scope !4, !noalias !3
  %p534 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite14 to i64), ptr %p534, align 8, !alias.scope !4, !noalias !3
  %v535 = load i64, ptr %slot105, align 8
  %v536 = load i64, ptr %slot99, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v535, i64 %v536) nomerge, !dbg !116
  br label %bb_rcslotdone99
bb_rcslotdone99:
  %v537 = load i64, ptr %slot97, align 8
  ret i64 %v537
bb_i6:
  %v538 = load i64, ptr %slot15, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i64 0, ptr %p539, align 8, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot15, align 8
  %p541 = inttoptr i64 %v540 to ptr
  %ld542 = load i64, ptr %p541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld542, ptr %slot108, align 8
  %v543 = load i64, ptr %slot4, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i32, ptr %p544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld545, ptr %slot109, align 8
  %v546 = load i32, ptr %slot109, align 8
  %cv547 = zext i32 %v546 to i64
  %cond548 = icmp ne i64 %cv547, 0
  br i1 %cond548, label %bb_rcslotdrop121, label %bb_rcslotdone121
bb_rcslotdrop121:
  %v549 = load i64, ptr %slot4, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i32 0, ptr %p550, align 4, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot13, align 8
  store i64 %v551, ptr %slot110, align 8
  %v552 = load i64, ptr %slot5, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i32, ptr %p553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld554, ptr %slot111, align 8
  %v555 = load i32, ptr %slot111, align 8
  %op556 = and i32 %v555, 28
  store i32 %op556, ptr %slot112, align 8
  %v557 = load i32, ptr %slot112, align 8
  %cv558 = zext i32 %v557 to i64
  %cond559 = icmp ne i64 %cv558, 0
  br i1 %cond559, label %bb_rcslotrole121, label %bb_rcslotowner121
bb_rcslotrole121:
  %v560 = load i64, ptr %slot17, align 8
  store i64 %v560, ptr %slot113, align 8
  %p561 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite17 to i64) to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !4, !noalias !3
  store i64 %ld562, ptr %slot114, align 8
  %v563 = load i64, ptr %slot114, align 8
  %op564 = add i64 %v563, 1
  store i64 %op564, ptr %slot115, align 8
  %v565 = load i64, ptr %slot115, align 8
  %p566 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite17 to i64) to ptr
  store i64 %v565, ptr %p566, align 8, !alias.scope !4, !noalias !3
  %p567 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite17 to i64), ptr %p567, align 8, !alias.scope !4, !noalias !3
  %v568 = load i64, ptr %slot113, align 8
  %v569 = load i64, ptr %slot110, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v568, i64 %v569) nomerge, !dbg !118
  br label %bb_rcslotdone121
bb_rcslotowner121:
  %v570 = load i64, ptr %slot17, align 8
  store i64 %v570, ptr %slot116, align 8
  %p571 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite18 to i64) to ptr
  %ld572 = load i64, ptr %p571, align 8, !alias.scope !4, !noalias !3
  store i64 %ld572, ptr %slot117, align 8
  %v573 = load i64, ptr %slot117, align 8
  %op574 = add i64 %v573, 1
  store i64 %op574, ptr %slot118, align 8
  %v575 = load i64, ptr %slot118, align 8
  %p576 = inttoptr i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite18 to i64) to ptr
  store i64 %v575, ptr %p576, align 8, !alias.scope !4, !noalias !3
  %p577 = inttoptr i64 ptrtoint (ptr @myl_rc_site_current to i64) to ptr
  store i64 ptrtoint (ptr @myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite18 to i64), ptr %p577, align 8, !alias.scope !4, !noalias !3
  %v578 = load i64, ptr %slot116, align 8
  %v579 = load i64, ptr %slot110, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v578, i64 %v579) nomerge, !dbg !118
  br label %bb_rcslotdone121
bb_rcslotdone121:
  %v580 = load i64, ptr %slot108, align 8
  ret i64 %v580
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite0 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite1 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite10 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite11 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite12 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite13 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite14 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite17 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite18 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite2 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite3 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite4 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite5 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite6 = external global i8, align 8
@myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b_rcsite9 = external global i8, align 8
@myl_rc_site_current = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", linkageName: "myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10980889420309157548, i64 0, !"myl_f_3ac6d0fdd3e869f53d13f290db237d1e878ad35d36dee798e34830ef402b551b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
