target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v170 = load i64, ptr %slot1, align 8
  %op171 = add i64 %v170, 32
  store i64 %op171, ptr %slot4, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot5, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot6, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot7, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot8, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot9, align 8
  %mem182 = alloca i8, i64 8, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot10, align 8
  %mem184 = alloca i8, i64 8, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot11, align 8
  %mem186 = alloca i8, i64 8, align 8
  %ptr187 = ptrtoint ptr %mem186 to i64
  store i64 %ptr187, ptr %slot12, align 8
  %mem188 = alloca i8, i64 8, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot13, align 8
  %v190 = load i64, ptr %slot2, align 8
  %v191 = load i64, ptr %slot5, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot3, align 8
  %v194 = load i64, ptr %slot6, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v196 = load i64, ptr %slot12, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 0, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot12, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot14, align 8
  %v201 = load i64, ptr %slot7, align 8
  store i64 %v201, ptr %slot15, align 8
  %v202 = load i64, ptr %slot14, align 8
  %v203 = load i64, ptr %slot15, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 %v202, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot12, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 0, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot12, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot16, align 8
  %v210 = load i64, ptr %slot8, align 8
  store i64 %v210, ptr %slot17, align 8
  %v211 = load i64, ptr %slot16, align 8
  %v212 = load i64, ptr %slot17, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot5, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot18, align 8
  %v217 = load i64, ptr %slot18, align 8
  %v218 = load i64, ptr %slot12, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot12, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot19, align 8
  %v223 = load i64, ptr %slot9, align 8
  store i64 %v223, ptr %slot20, align 8
  %v224 = load i64, ptr %slot19, align 8
  %v225 = load i64, ptr %slot20, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot8, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot21, align 8
  %v230 = load i64, ptr %slot9, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot22, align 8
  %v233 = load i64, ptr %slot22, align 8
  %v234 = load i64, ptr %slot21, align 8
  %cmp235 = icmp sgt i64 %v233, %v234
  %cv236 = zext i1 %cmp235 to i64
  store i64 %cv236, ptr %slot23, align 8
  %v237 = load i64, ptr %slot22, align 8
  %v238 = load i64, ptr %slot21, align 8
  %op239 = sub i64 %v237, %v238
  store i64 %op239, ptr %slot24, align 8
  %v240 = load i64, ptr %slot24, align 8
  %cmp241 = icmp uge i64 %v240, 16
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot25, align 8
  %v243 = load i64, ptr %slot23, align 8
  %v244 = load i64, ptr %slot25, align 8
  %op245 = and i64 %v243, %v244
  store i64 %op245, ptr %slot26, align 8
  %v246 = load i64, ptr %slot26, align 8
  %cond247 = icmp ne i64 %v246, 0
  br i1 %cond247, label %bb_guard7, label %bb_oi6
bb_guard7:
  %v248 = load i64, ptr %slot21, align 8
  %op249 = add i64 %v248, 1152921504606846976
  store i64 %op249, ptr %slot27, align 8
  %v250 = load i64, ptr %slot27, align 8
  %cmp251 = icmp ule i64 %v250, 2305843009213693952
  %cv252 = zext i1 %cmp251 to i64
  store i64 %cv252, ptr %slot28, align 8
  %v253 = load i64, ptr %slot28, align 8
  %cond254 = icmp ne i64 %v253, 0
  br i1 %cond254, label %bb_guard13, label %bb_oi6
bb_guard13:
  %v255 = load i64, ptr %slot22, align 8
  %op256 = add i64 %v255, 1152921504606846976
  store i64 %op256, ptr %slot29, align 8
  %v257 = load i64, ptr %slot29, align 8
  %cmp258 = icmp ule i64 %v257, 2305843009213693952
  %cv259 = zext i1 %cmp258 to i64
  store i64 %cv259, ptr %slot30, align 8
  %v260 = load i64, ptr %slot30, align 8
  %cond261 = icmp ne i64 %v260, 0
  br i1 %cond261, label %bb_guard15, label %bb_oi6
bb_guard15:
  br label %bb_fi6
bb_fi6:
  %v262 = load i64, ptr %slot8, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot31, align 8
  %v265 = load i64, ptr %slot31, align 8
  %v266 = load i64, ptr %slot12, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i64 %v265, ptr %p267, align 8, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot9, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot32, align 8
  %v271 = load i64, ptr %slot32, align 8
  %v272 = load i64, ptr %slot13, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i64 %v271, ptr %p273, align 8, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot13, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot33, align 8
  %v277 = load i64, ptr %slot12, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot34, align 8
  %v280 = load i64, ptr %slot34, align 8
  %v281 = load i64, ptr %slot33, align 8
  %cmp282 = icmp slt i64 %v280, %v281
  %cv283 = zext i1 %cmp282 to i64
  store i64 %cv283, ptr %slot35, align 8
  %v284 = load i64, ptr %slot35, align 8
  %v285 = load i64, ptr %slot12, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot12, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot36, align 8
  %v290 = load i64, ptr %slot36, align 8
  %cond291 = icmp ne i64 %v290, 0
  br i1 %cond291, label %bb_next23, label %bb_i34
bb_next23:
  %v292 = load i64, ptr %slot8, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld294, ptr %slot37, align 8
  %v295 = load i64, ptr %slot37, align 8
  %v296 = load i64, ptr %slot12, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot13, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 2, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot13, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot38, align 8
  %v303 = load i64, ptr %slot12, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot39, align 8
  %v306 = load i64, ptr %slot38, align 8
  %cmp307 = icmp eq i64 %v306, 0
  %cv308 = zext i1 %cmp307 to i64
  store i64 %cv308, ptr %slot40, align 8
  %v309 = load i64, ptr %slot40, align 8
  %cond310 = icmp ne i64 %v309, 0
  br i1 %cond310, label %bb_division26, label %bb_nonzero26
bb_division26:
  %v311 = load i64, ptr %slot1, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %v313 = load i64, ptr %slot39, align 8
  %v314 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_division(ptr %p312, i64 6, i64 %v313, i64 %v314) nomerge, !dbg !110
  unreachable
bb_nonzero26:
  %v315 = load i64, ptr %slot39, align 8
  %cmp316 = icmp eq i64 %v315, 9223372036854775808
  %cv317 = zext i1 %cmp316 to i64
  store i64 %cv317, ptr %slot41, align 8
  %v318 = load i64, ptr %slot38, align 8
  %cmp319 = icmp eq i64 %v318, 18446744073709551615
  %cv320 = zext i1 %cmp319 to i64
  store i64 %cv320, ptr %slot42, align 8
  %v321 = load i64, ptr %slot41, align 8
  %v322 = load i64, ptr %slot42, align 8
  %op323 = and i64 %v321, %v322
  store i64 %op323, ptr %slot43, align 8
  %v324 = load i64, ptr %slot43, align 8
  %neg325 = sub i64 0, %v324
  store i64 %neg325, ptr %slot44, align 8
  %v326 = load i64, ptr %slot38, align 8
  %op327 = xor i64 %v326, 1
  store i64 %op327, ptr %slot45, align 8
  %v328 = load i64, ptr %slot45, align 8
  %v329 = load i64, ptr %slot44, align 8
  %op330 = and i64 %v328, %v329
  store i64 %op330, ptr %slot45, align 8
  %v331 = load i64, ptr %slot38, align 8
  %v332 = load i64, ptr %slot45, align 8
  %op333 = xor i64 %v331, %v332
  store i64 %op333, ptr %slot46, align 8
  %v334 = load i64, ptr %slot39, align 8
  %v335 = load i64, ptr %slot46, align 8
  %op336 = srem i64 %v334, %v335
  store i64 %op336, ptr %slot47, align 8
  %v337 = load i64, ptr %slot47, align 8
  %cmp338 = icmp ne i64 %v337, 0
  %cv339 = zext i1 %cmp338 to i64
  store i64 %cv339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot47, align 8
  %v341 = load i64, ptr %slot46, align 8
  %op342 = xor i64 %v340, %v341
  store i64 %op342, ptr %slot49, align 8
  %v343 = load i64, ptr %slot49, align 8
  %cmp344 = icmp slt i64 %v343, 0
  %cv345 = zext i1 %cmp344 to i64
  store i64 %cv345, ptr %slot50, align 8
  %v346 = load i64, ptr %slot48, align 8
  %v347 = load i64, ptr %slot50, align 8
  %op348 = and i64 %v346, %v347
  store i64 %op348, ptr %slot51, align 8
  %v349 = load i64, ptr %slot51, align 8
  %neg350 = sub i64 0, %v349
  store i64 %neg350, ptr %slot52, align 8
  %v351 = load i64, ptr %slot46, align 8
  %v352 = load i64, ptr %slot52, align 8
  %op353 = and i64 %v351, %v352
  store i64 %op353, ptr %slot53, align 8
  %v354 = load i64, ptr %slot47, align 8
  %v355 = load i64, ptr %slot53, align 8
  %op356 = add i64 %v354, %v355
  store i64 %op356, ptr %slot47, align 8
  %v357 = load i64, ptr %slot47, align 8
  %floorbounded358 = icmp ult i64 %v357, 2
  call void @llvm.assume(i1 %floorbounded358)
  %v359 = load i64, ptr %slot47, align 8
  %v360 = load i64, ptr %slot12, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot6, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i64, ptr %p363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld364, ptr %slot54, align 8
  %v365 = load i64, ptr %slot54, align 8
  %v366 = load i64, ptr %slot13, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 %v365, ptr %p367, align 8, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot13, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld370, ptr %slot55, align 8
  %v371 = load i64, ptr %slot12, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot56, align 8
  %v374 = load i64, ptr %slot56, align 8
  %v375 = load i64, ptr %slot55, align 8
  %cmp376 = icmp eq i64 %v374, %v375
  %cv377 = zext i1 %cmp376 to i64
  store i64 %cv377, ptr %slot57, align 8
  %v378 = load i64, ptr %slot57, align 8
  %v379 = load i64, ptr %slot12, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i64 %v378, ptr %p380, align 8, !alias.scope !3, !noalias !4
  %v381 = load i64, ptr %slot12, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot58, align 8
  %v384 = load i64, ptr %slot58, align 8
  %cond385 = icmp ne i64 %v384, 0
  br i1 %cond385, label %bb_next45, label %bb_fi19
bb_next45:
  %v386 = load i64, ptr %slot12, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 1, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot12, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot59, align 8
  %v391 = load i64, ptr %slot10, align 8
  store i64 %v391, ptr %slot60, align 8
  %v392 = load i64, ptr %slot59, align 8
  %v393 = load i64, ptr %slot60, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 %v392, ptr %p394, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v395 = load i64, ptr %slot12, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 0, ptr %p396, align 8, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot12, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot61, align 8
  %v400 = load i64, ptr %slot10, align 8
  store i64 %v400, ptr %slot62, align 8
  %v401 = load i64, ptr %slot61, align 8
  %v402 = load i64, ptr %slot62, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i64 %v401, ptr %p403, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v404 = load i64, ptr %slot10, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %ld406 = load i64, ptr %p405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld406, ptr %slot63, align 8
  %v407 = load i64, ptr %slot63, align 8
  %v408 = load i64, ptr %slot12, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 %v407, ptr %p409, align 8, !alias.scope !3, !noalias !4
  %v410 = load i64, ptr %slot12, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i64, ptr %p411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld412, ptr %slot64, align 8
  %v413 = load i64, ptr %slot11, align 8
  store i64 %v413, ptr %slot65, align 8
  %v414 = load i64, ptr %slot64, align 8
  %v415 = load i64, ptr %slot65, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot7, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot66, align 8
  %v420 = load i64, ptr %slot66, align 8
  %v421 = load i64, ptr %slot12, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot11, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot67, align 8
  %v426 = load i64, ptr %slot67, align 8
  %v427 = load i64, ptr %slot13, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i64 %v426, ptr %p428, align 8, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot13, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot68, align 8
  %v432 = load i64, ptr %slot12, align 8
  %p433 = inttoptr i64 %v432 to ptr
  %ld434 = load i64, ptr %p433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld434, ptr %slot69, align 8
  %v435 = load i64, ptr %slot69, align 8
  %v436 = load i64, ptr %slot68, align 8
  %ovpair438 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v435, i64 %v436)
  %op437 = extractvalue { i64, i1 } %ovpair438, 0
  %ov439 = extractvalue { i64, i1 } %ovpair438, 1
  store i64 %op437, ptr %slot70, align 8
  %v440 = load i64, ptr %slot69, align 8
  %v441 = load i64, ptr %slot70, align 8
  %op442 = xor i64 %v440, %v441
  store i64 %op442, ptr %slot71, align 8
  %v443 = load i64, ptr %slot68, align 8
  %v444 = load i64, ptr %slot70, align 8
  %op445 = xor i64 %v443, %v444
  store i64 %op445, ptr %slot72, align 8
  %v446 = load i64, ptr %slot71, align 8
  %v447 = load i64, ptr %slot72, align 8
  %op448 = and i64 %v446, %v447
  store i64 %op448, ptr %slot73, align 8
  %cv449 = zext i1 %ov439 to i64
  store i64 %cv449, ptr %slot74, align 8
  %v450 = load i64, ptr %slot74, align 8
  %cond451 = icmp ne i64 %v450, 0
  br i1 %cond451, label %bb_overflow56, label %bb_checked56
bb_overflow56:
  %v452 = load i64, ptr %slot1, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %v454 = load i64, ptr %slot69, align 8
  %v455 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p453, i64 0, i64 %v454, i64 %v455, i64 64) nomerge, !dbg !112
  unreachable
bb_checked56:
  %v456 = load i64, ptr %slot70, align 8
  %v457 = load i64, ptr %slot12, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot13, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 1000000007, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot13, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i64, ptr %p462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld463, ptr %slot75, align 8
  %v464 = load i64, ptr %slot12, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot76, align 8
  %v467 = load i64, ptr %slot75, align 8
  %cmp468 = icmp eq i64 %v467, 0
  %cv469 = zext i1 %cmp468 to i64
  store i64 %cv469, ptr %slot77, align 8
  %v470 = load i64, ptr %slot77, align 8
  %cond471 = icmp ne i64 %v470, 0
  br i1 %cond471, label %bb_division63, label %bb_nonzero63
bb_division63:
  %v472 = load i64, ptr %slot1, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %v474 = load i64, ptr %slot76, align 8
  %v475 = load i64, ptr %slot75, align 8
  call void @myl_qbe_fail_division(ptr %p473, i64 6, i64 %v474, i64 %v475) nomerge, !dbg !114
  unreachable
bb_nonzero63:
  %v476 = load i64, ptr %slot76, align 8
  %cmp477 = icmp eq i64 %v476, 9223372036854775808
  %cv478 = zext i1 %cmp477 to i64
  store i64 %cv478, ptr %slot78, align 8
  %v479 = load i64, ptr %slot75, align 8
  %cmp480 = icmp eq i64 %v479, 18446744073709551615
  %cv481 = zext i1 %cmp480 to i64
  store i64 %cv481, ptr %slot79, align 8
  %v482 = load i64, ptr %slot78, align 8
  %v483 = load i64, ptr %slot79, align 8
  %op484 = and i64 %v482, %v483
  store i64 %op484, ptr %slot80, align 8
  %v485 = load i64, ptr %slot80, align 8
  %neg486 = sub i64 0, %v485
  store i64 %neg486, ptr %slot81, align 8
  %v487 = load i64, ptr %slot75, align 8
  %op488 = xor i64 %v487, 1
  store i64 %op488, ptr %slot82, align 8
  %v489 = load i64, ptr %slot82, align 8
  %v490 = load i64, ptr %slot81, align 8
  %op491 = and i64 %v489, %v490
  store i64 %op491, ptr %slot82, align 8
  %v492 = load i64, ptr %slot75, align 8
  %v493 = load i64, ptr %slot82, align 8
  %op494 = xor i64 %v492, %v493
  store i64 %op494, ptr %slot83, align 8
  %v495 = load i64, ptr %slot76, align 8
  %v496 = load i64, ptr %slot83, align 8
  %op497 = srem i64 %v495, %v496
  store i64 %op497, ptr %slot84, align 8
  %v498 = load i64, ptr %slot84, align 8
  %cmp499 = icmp ne i64 %v498, 0
  %cv500 = zext i1 %cmp499 to i64
  store i64 %cv500, ptr %slot85, align 8
  %v501 = load i64, ptr %slot84, align 8
  %v502 = load i64, ptr %slot83, align 8
  %op503 = xor i64 %v501, %v502
  store i64 %op503, ptr %slot86, align 8
  %v504 = load i64, ptr %slot86, align 8
  %cmp505 = icmp slt i64 %v504, 0
  %cv506 = zext i1 %cmp505 to i64
  store i64 %cv506, ptr %slot87, align 8
  %v507 = load i64, ptr %slot85, align 8
  %v508 = load i64, ptr %slot87, align 8
  %op509 = and i64 %v507, %v508
  store i64 %op509, ptr %slot88, align 8
  %v510 = load i64, ptr %slot88, align 8
  %neg511 = sub i64 0, %v510
  store i64 %neg511, ptr %slot89, align 8
  %v512 = load i64, ptr %slot83, align 8
  %v513 = load i64, ptr %slot89, align 8
  %op514 = and i64 %v512, %v513
  store i64 %op514, ptr %slot90, align 8
  %v515 = load i64, ptr %slot84, align 8
  %v516 = load i64, ptr %slot90, align 8
  %op517 = add i64 %v515, %v516
  store i64 %op517, ptr %slot84, align 8
  %v518 = load i64, ptr %slot84, align 8
  %floorbounded519 = icmp ult i64 %v518, 1000000007
  call void @llvm.assume(i1 %floorbounded519)
  %v520 = load i64, ptr %slot84, align 8
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot12, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i64, ptr %p524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld525, ptr %slot91, align 8
  %v526 = load i64, ptr %slot7, align 8
  store i64 %v526, ptr %slot92, align 8
  %v527 = load i64, ptr %slot91, align 8
  %v528 = load i64, ptr %slot92, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot8, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot93, align 8
  %v533 = load i64, ptr %slot93, align 8
  %v534 = load i64, ptr %slot12, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot13, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 1, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot13, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot94, align 8
  %v541 = load i64, ptr %slot12, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot95, align 8
  %v544 = load i64, ptr %slot95, align 8
  %v545 = load i64, ptr %slot94, align 8
  %op546 = add i64 %v544, %v545
  store i64 %op546, ptr %slot96, align 8
  %v547 = load i64, ptr %slot96, align 8
  %v548 = load i64, ptr %slot12, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 %v547, ptr %p549, align 8, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot12, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot97, align 8
  %v553 = load i64, ptr %slot8, align 8
  store i64 %v553, ptr %slot98, align 8
  %v554 = load i64, ptr %slot97, align 8
  %v555 = load i64, ptr %slot98, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !119
bb_oi6:
  %v557 = load i64, ptr %slot8, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot99, align 8
  %v560 = load i64, ptr %slot99, align 8
  %v561 = load i64, ptr %slot12, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 %v560, ptr %p562, align 8, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot9, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot100, align 8
  %v566 = load i64, ptr %slot100, align 8
  %v567 = load i64, ptr %slot13, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot13, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot101, align 8
  %v572 = load i64, ptr %slot12, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot102, align 8
  %v575 = load i64, ptr %slot102, align 8
  %v576 = load i64, ptr %slot101, align 8
  %cmp577 = icmp slt i64 %v575, %v576
  %cv578 = zext i1 %cmp577 to i64
  store i64 %cv578, ptr %slot103, align 8
  %v579 = load i64, ptr %slot103, align 8
  %v580 = load i64, ptr %slot12, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 %v579, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot12, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld584, ptr %slot104, align 8
  %v585 = load i64, ptr %slot104, align 8
  %cond586 = icmp ne i64 %v585, 0
  br i1 %cond586, label %bb_next91, label %bb_i34
bb_next91:
  %v587 = load i64, ptr %slot8, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %ld589 = load i64, ptr %p588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld589, ptr %slot105, align 8
  %v590 = load i64, ptr %slot105, align 8
  %v591 = load i64, ptr %slot12, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i64 %v590, ptr %p592, align 8, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot13, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 2, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot13, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot106, align 8
  %v598 = load i64, ptr %slot12, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i64, ptr %p599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld600, ptr %slot107, align 8
  %v601 = load i64, ptr %slot106, align 8
  %cmp602 = icmp eq i64 %v601, 0
  %cv603 = zext i1 %cmp602 to i64
  store i64 %cv603, ptr %slot108, align 8
  %v604 = load i64, ptr %slot108, align 8
  %cond605 = icmp ne i64 %v604, 0
  br i1 %cond605, label %bb_division94, label %bb_nonzero94
bb_division94:
  %v606 = load i64, ptr %slot1, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %v608 = load i64, ptr %slot107, align 8
  %v609 = load i64, ptr %slot106, align 8
  call void @myl_qbe_fail_division(ptr %p607, i64 6, i64 %v608, i64 %v609) nomerge, !dbg !110
  unreachable
bb_nonzero94:
  %v610 = load i64, ptr %slot107, align 8
  %cmp611 = icmp eq i64 %v610, 9223372036854775808
  %cv612 = zext i1 %cmp611 to i64
  store i64 %cv612, ptr %slot109, align 8
  %v613 = load i64, ptr %slot106, align 8
  %cmp614 = icmp eq i64 %v613, 18446744073709551615
  %cv615 = zext i1 %cmp614 to i64
  store i64 %cv615, ptr %slot110, align 8
  %v616 = load i64, ptr %slot109, align 8
  %v617 = load i64, ptr %slot110, align 8
  %op618 = and i64 %v616, %v617
  store i64 %op618, ptr %slot111, align 8
  %v619 = load i64, ptr %slot111, align 8
  %neg620 = sub i64 0, %v619
  store i64 %neg620, ptr %slot112, align 8
  %v621 = load i64, ptr %slot106, align 8
  %op622 = xor i64 %v621, 1
  store i64 %op622, ptr %slot113, align 8
  %v623 = load i64, ptr %slot113, align 8
  %v624 = load i64, ptr %slot112, align 8
  %op625 = and i64 %v623, %v624
  store i64 %op625, ptr %slot113, align 8
  %v626 = load i64, ptr %slot106, align 8
  %v627 = load i64, ptr %slot113, align 8
  %op628 = xor i64 %v626, %v627
  store i64 %op628, ptr %slot114, align 8
  %v629 = load i64, ptr %slot107, align 8
  %v630 = load i64, ptr %slot114, align 8
  %op631 = srem i64 %v629, %v630
  store i64 %op631, ptr %slot115, align 8
  %v632 = load i64, ptr %slot115, align 8
  %cmp633 = icmp ne i64 %v632, 0
  %cv634 = zext i1 %cmp633 to i64
  store i64 %cv634, ptr %slot116, align 8
  %v635 = load i64, ptr %slot115, align 8
  %v636 = load i64, ptr %slot114, align 8
  %op637 = xor i64 %v635, %v636
  store i64 %op637, ptr %slot117, align 8
  %v638 = load i64, ptr %slot117, align 8
  %cmp639 = icmp slt i64 %v638, 0
  %cv640 = zext i1 %cmp639 to i64
  store i64 %cv640, ptr %slot118, align 8
  %v641 = load i64, ptr %slot116, align 8
  %v642 = load i64, ptr %slot118, align 8
  %op643 = and i64 %v641, %v642
  store i64 %op643, ptr %slot119, align 8
  %v644 = load i64, ptr %slot119, align 8
  %neg645 = sub i64 0, %v644
  store i64 %neg645, ptr %slot120, align 8
  %v646 = load i64, ptr %slot114, align 8
  %v647 = load i64, ptr %slot120, align 8
  %op648 = and i64 %v646, %v647
  store i64 %op648, ptr %slot121, align 8
  %v649 = load i64, ptr %slot115, align 8
  %v650 = load i64, ptr %slot121, align 8
  %op651 = add i64 %v649, %v650
  store i64 %op651, ptr %slot115, align 8
  %v652 = load i64, ptr %slot115, align 8
  %floorbounded653 = icmp ult i64 %v652, 2
  call void @llvm.assume(i1 %floorbounded653)
  %v654 = load i64, ptr %slot115, align 8
  %v655 = load i64, ptr %slot12, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i64 %v654, ptr %p656, align 8, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot6, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot122, align 8
  %v660 = load i64, ptr %slot122, align 8
  %v661 = load i64, ptr %slot13, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot13, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot123, align 8
  %v666 = load i64, ptr %slot12, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %ld668 = load i64, ptr %p667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld668, ptr %slot124, align 8
  %v669 = load i64, ptr %slot124, align 8
  %v670 = load i64, ptr %slot123, align 8
  %cmp671 = icmp eq i64 %v669, %v670
  %cv672 = zext i1 %cmp671 to i64
  store i64 %cv672, ptr %slot125, align 8
  %v673 = load i64, ptr %slot125, align 8
  %v674 = load i64, ptr %slot12, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot12, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot126, align 8
  %v679 = load i64, ptr %slot126, align 8
  %cond680 = icmp ne i64 %v679, 0
  br i1 %cond680, label %bb_next113, label %bb_i19
bb_next113:
  %v681 = load i64, ptr %slot12, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i64 1, ptr %p682, align 8, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot12, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %ld685 = load i64, ptr %p684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld685, ptr %slot127, align 8
  %v686 = load i64, ptr %slot10, align 8
  store i64 %v686, ptr %slot128, align 8
  %v687 = load i64, ptr %slot127, align 8
  %v688 = load i64, ptr %slot128, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 %v687, ptr %p689, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v690 = load i64, ptr %slot12, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i64 0, ptr %p691, align 8, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot12, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %ld694 = load i64, ptr %p693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld694, ptr %slot129, align 8
  %v695 = load i64, ptr %slot10, align 8
  store i64 %v695, ptr %slot130, align 8
  %v696 = load i64, ptr %slot129, align 8
  %v697 = load i64, ptr %slot130, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i64 %v696, ptr %p698, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v699 = load i64, ptr %slot10, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %ld701 = load i64, ptr %p700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld701, ptr %slot131, align 8
  %v702 = load i64, ptr %slot131, align 8
  %v703 = load i64, ptr %slot12, align 8
  %p704 = inttoptr i64 %v703 to ptr
  store i64 %v702, ptr %p704, align 8, !alias.scope !3, !noalias !4
  %v705 = load i64, ptr %slot12, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i64, ptr %p706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld707, ptr %slot132, align 8
  %v708 = load i64, ptr %slot11, align 8
  store i64 %v708, ptr %slot133, align 8
  %v709 = load i64, ptr %slot132, align 8
  %v710 = load i64, ptr %slot133, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot7, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %ld714 = load i64, ptr %p713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld714, ptr %slot134, align 8
  %v715 = load i64, ptr %slot134, align 8
  %v716 = load i64, ptr %slot12, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i64 %v715, ptr %p717, align 8, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot11, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %ld720 = load i64, ptr %p719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld720, ptr %slot135, align 8
  %v721 = load i64, ptr %slot135, align 8
  %v722 = load i64, ptr %slot13, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 %v721, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot13, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i64, ptr %p725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld726, ptr %slot136, align 8
  %v727 = load i64, ptr %slot12, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot137, align 8
  %v730 = load i64, ptr %slot137, align 8
  %v731 = load i64, ptr %slot136, align 8
  %ovpair733 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v730, i64 %v731)
  %op732 = extractvalue { i64, i1 } %ovpair733, 0
  %ov734 = extractvalue { i64, i1 } %ovpair733, 1
  store i64 %op732, ptr %slot138, align 8
  %v735 = load i64, ptr %slot137, align 8
  %v736 = load i64, ptr %slot138, align 8
  %op737 = xor i64 %v735, %v736
  store i64 %op737, ptr %slot139, align 8
  %v738 = load i64, ptr %slot136, align 8
  %v739 = load i64, ptr %slot138, align 8
  %op740 = xor i64 %v738, %v739
  store i64 %op740, ptr %slot140, align 8
  %v741 = load i64, ptr %slot139, align 8
  %v742 = load i64, ptr %slot140, align 8
  %op743 = and i64 %v741, %v742
  store i64 %op743, ptr %slot141, align 8
  %cv744 = zext i1 %ov734 to i64
  store i64 %cv744, ptr %slot142, align 8
  %v745 = load i64, ptr %slot142, align 8
  %cond746 = icmp ne i64 %v745, 0
  br i1 %cond746, label %bb_overflow124, label %bb_checked124
bb_overflow124:
  %v747 = load i64, ptr %slot1, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %v749 = load i64, ptr %slot137, align 8
  %v750 = load i64, ptr %slot136, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p748, i64 0, i64 %v749, i64 %v750, i64 64) nomerge, !dbg !112
  unreachable
bb_checked124:
  %v751 = load i64, ptr %slot138, align 8
  %v752 = load i64, ptr %slot12, align 8
  %p753 = inttoptr i64 %v752 to ptr
  store i64 %v751, ptr %p753, align 8, !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot13, align 8
  %p755 = inttoptr i64 %v754 to ptr
  store i64 1000000007, ptr %p755, align 8, !alias.scope !3, !noalias !4
  %v756 = load i64, ptr %slot13, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %ld758 = load i64, ptr %p757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld758, ptr %slot143, align 8
  %v759 = load i64, ptr %slot12, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i64, ptr %p760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld761, ptr %slot144, align 8
  %v762 = load i64, ptr %slot143, align 8
  %cmp763 = icmp eq i64 %v762, 0
  %cv764 = zext i1 %cmp763 to i64
  store i64 %cv764, ptr %slot145, align 8
  %v765 = load i64, ptr %slot145, align 8
  %cond766 = icmp ne i64 %v765, 0
  br i1 %cond766, label %bb_division131, label %bb_nonzero131
bb_division131:
  %v767 = load i64, ptr %slot1, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %v769 = load i64, ptr %slot144, align 8
  %v770 = load i64, ptr %slot143, align 8
  call void @myl_qbe_fail_division(ptr %p768, i64 6, i64 %v769, i64 %v770) nomerge, !dbg !114
  unreachable
bb_nonzero131:
  %v771 = load i64, ptr %slot144, align 8
  %cmp772 = icmp eq i64 %v771, 9223372036854775808
  %cv773 = zext i1 %cmp772 to i64
  store i64 %cv773, ptr %slot146, align 8
  %v774 = load i64, ptr %slot143, align 8
  %cmp775 = icmp eq i64 %v774, 18446744073709551615
  %cv776 = zext i1 %cmp775 to i64
  store i64 %cv776, ptr %slot147, align 8
  %v777 = load i64, ptr %slot146, align 8
  %v778 = load i64, ptr %slot147, align 8
  %op779 = and i64 %v777, %v778
  store i64 %op779, ptr %slot148, align 8
  %v780 = load i64, ptr %slot148, align 8
  %neg781 = sub i64 0, %v780
  store i64 %neg781, ptr %slot149, align 8
  %v782 = load i64, ptr %slot143, align 8
  %op783 = xor i64 %v782, 1
  store i64 %op783, ptr %slot150, align 8
  %v784 = load i64, ptr %slot150, align 8
  %v785 = load i64, ptr %slot149, align 8
  %op786 = and i64 %v784, %v785
  store i64 %op786, ptr %slot150, align 8
  %v787 = load i64, ptr %slot143, align 8
  %v788 = load i64, ptr %slot150, align 8
  %op789 = xor i64 %v787, %v788
  store i64 %op789, ptr %slot151, align 8
  %v790 = load i64, ptr %slot144, align 8
  %v791 = load i64, ptr %slot151, align 8
  %op792 = srem i64 %v790, %v791
  store i64 %op792, ptr %slot152, align 8
  %v793 = load i64, ptr %slot152, align 8
  %cmp794 = icmp ne i64 %v793, 0
  %cv795 = zext i1 %cmp794 to i64
  store i64 %cv795, ptr %slot153, align 8
  %v796 = load i64, ptr %slot152, align 8
  %v797 = load i64, ptr %slot151, align 8
  %op798 = xor i64 %v796, %v797
  store i64 %op798, ptr %slot154, align 8
  %v799 = load i64, ptr %slot154, align 8
  %cmp800 = icmp slt i64 %v799, 0
  %cv801 = zext i1 %cmp800 to i64
  store i64 %cv801, ptr %slot155, align 8
  %v802 = load i64, ptr %slot153, align 8
  %v803 = load i64, ptr %slot155, align 8
  %op804 = and i64 %v802, %v803
  store i64 %op804, ptr %slot156, align 8
  %v805 = load i64, ptr %slot156, align 8
  %neg806 = sub i64 0, %v805
  store i64 %neg806, ptr %slot157, align 8
  %v807 = load i64, ptr %slot151, align 8
  %v808 = load i64, ptr %slot157, align 8
  %op809 = and i64 %v807, %v808
  store i64 %op809, ptr %slot158, align 8
  %v810 = load i64, ptr %slot152, align 8
  %v811 = load i64, ptr %slot158, align 8
  %op812 = add i64 %v810, %v811
  store i64 %op812, ptr %slot152, align 8
  %v813 = load i64, ptr %slot152, align 8
  %floorbounded814 = icmp ult i64 %v813, 1000000007
  call void @llvm.assume(i1 %floorbounded814)
  %v815 = load i64, ptr %slot152, align 8
  %v816 = load i64, ptr %slot12, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot12, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot159, align 8
  %v821 = load i64, ptr %slot7, align 8
  store i64 %v821, ptr %slot160, align 8
  %v822 = load i64, ptr %slot159, align 8
  %v823 = load i64, ptr %slot160, align 8
  %p824 = inttoptr i64 %v823 to ptr
  store i64 %v822, ptr %p824, align 8, !alias.scope !3, !noalias !4
  %v825 = load i64, ptr %slot8, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld827, ptr %slot161, align 8
  %v828 = load i64, ptr %slot161, align 8
  %v829 = load i64, ptr %slot12, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i64 %v828, ptr %p830, align 8, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot13, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 1, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot13, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld835, ptr %slot162, align 8
  %v836 = load i64, ptr %slot12, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot163, align 8
  %v839 = load i64, ptr %slot163, align 8
  %v840 = load i64, ptr %slot162, align 8
  %op841 = add i64 %v839, %v840
  %ovpair842 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v839, i64 %v840)
  %ov843 = extractvalue { i64, i1 } %ovpair842, 1
  store i64 %op841, ptr %slot164, align 8
  %cv844 = zext i1 %ov843 to i64
  store i64 %cv844, ptr %slot165, align 8
  %v845 = load i64, ptr %slot165, align 8
  %cond846 = icmp ne i64 %v845, 0
  br i1 %cond846, label %bb_overflow150, label %bb_checked150
bb_overflow150:
  %v847 = load i64, ptr %slot1, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %v849 = load i64, ptr %slot163, align 8
  %v850 = load i64, ptr %slot162, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p848, i64 0, i64 %v849, i64 %v850, i64 64) nomerge, !dbg !116
  unreachable
bb_checked150:
  %v851 = load i64, ptr %slot164, align 8
  %v852 = load i64, ptr %slot12, align 8
  %p853 = inttoptr i64 %v852 to ptr
  store i64 %v851, ptr %p853, align 8, !alias.scope !3, !noalias !4
  %v854 = load i64, ptr %slot12, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld856, ptr %slot166, align 8
  %v857 = load i64, ptr %slot8, align 8
  store i64 %v857, ptr %slot167, align 8
  %v858 = load i64, ptr %slot166, align 8
  %v859 = load i64, ptr %slot167, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i64 %v858, ptr %p860, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !120
bb_i34:
  %v861 = load i64, ptr %slot7, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i64, ptr %p862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld863, ptr %slot168, align 8
  %v864 = load i64, ptr %slot168, align 8
  %v865 = load i64, ptr %slot12, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i64 %v864, ptr %p866, align 8, !alias.scope !3, !noalias !4
  %v867 = load i64, ptr %slot12, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %ld869 = load i64, ptr %p868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld869, ptr %slot169, align 8
  %v870 = load i64, ptr %slot169, align 8
  ret i64 %v870
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", linkageName: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7472279511045523184, i64 0, !"myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
!118 = !{!"llvm.loop.align", i32 32}
!119 = distinct !{!119, !118}
!120 = distinct !{!120, !118}
