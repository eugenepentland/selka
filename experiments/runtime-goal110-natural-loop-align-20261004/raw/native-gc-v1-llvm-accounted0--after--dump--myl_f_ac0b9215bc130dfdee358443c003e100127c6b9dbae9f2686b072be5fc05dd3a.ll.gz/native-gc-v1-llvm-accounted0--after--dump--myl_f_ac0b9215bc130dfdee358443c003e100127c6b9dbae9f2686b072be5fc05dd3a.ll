target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v160 = load i64, ptr %slot1, align 8
  %op161 = add i64 %v160, 32
  store i64 %op161, ptr %slot5, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot6, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot7, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot8, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot9, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot10, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot11, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot12, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot13, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot14, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot15, align 8
  %v182 = load i64, ptr %slot2, align 8
  %v183 = load i64, ptr %slot6, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot3, align 8
  %v186 = load i64, ptr %slot7, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot4, align 8
  %v189 = load i64, ptr %slot8, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot16, align 8
  %v194 = load i64, ptr %slot16, align 8
  %v195 = load i64, ptr %slot14, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot14, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot17, align 8
  %v200 = load i64, ptr %slot17, align 8
  %v201 = load i64, ptr %slot9, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot14, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot14, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot18, align 8
  %v208 = load i64, ptr %slot18, align 8
  %v209 = load i64, ptr %slot10, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot7, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot19, align 8
  %v214 = load i64, ptr %slot19, align 8
  %v215 = load i64, ptr %slot14, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot14, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot20, align 8
  %v220 = load i64, ptr %slot20, align 8
  %v221 = load i64, ptr %slot11, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 %v220, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot10, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i64, ptr %p224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot21, align 8
  %v226 = load i64, ptr %slot11, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot22, align 8
  %v229 = load i64, ptr %slot22, align 8
  %v230 = load i64, ptr %slot21, align 8
  %cmp231 = icmp sgt i64 %v229, %v230
  %cv232 = zext i1 %cmp231 to i64
  store i64 %cv232, ptr %slot23, align 8
  %v233 = load i64, ptr %slot22, align 8
  %v234 = load i64, ptr %slot21, align 8
  %op235 = sub i64 %v233, %v234
  store i64 %op235, ptr %slot24, align 8
  %v236 = load i64, ptr %slot24, align 8
  %cmp237 = icmp uge i64 %v236, 16
  %cv238 = zext i1 %cmp237 to i64
  store i64 %cv238, ptr %slot25, align 8
  %v239 = load i64, ptr %slot23, align 8
  %v240 = load i64, ptr %slot25, align 8
  %op241 = and i64 %v239, %v240
  store i64 %op241, ptr %slot26, align 8
  %v242 = load i64, ptr %slot26, align 8
  %cond243 = icmp ne i64 %v242, 0
  br i1 %cond243, label %bb_guard5, label %bb_oi6
bb_guard5:
  %v244 = load i64, ptr %slot21, align 8
  %op245 = add i64 %v244, 1152921504606846976
  store i64 %op245, ptr %slot27, align 8
  %v246 = load i64, ptr %slot27, align 8
  %cmp247 = icmp ule i64 %v246, 2305843009213693952
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot28, align 8
  %v249 = load i64, ptr %slot28, align 8
  %cond250 = icmp ne i64 %v249, 0
  br i1 %cond250, label %bb_guard11, label %bb_oi6
bb_guard11:
  %v251 = load i64, ptr %slot22, align 8
  %op252 = add i64 %v251, 1152921504606846976
  store i64 %op252, ptr %slot29, align 8
  %v253 = load i64, ptr %slot29, align 8
  %cmp254 = icmp ule i64 %v253, 2305843009213693952
  %cv255 = zext i1 %cmp254 to i64
  store i64 %cv255, ptr %slot30, align 8
  %v256 = load i64, ptr %slot30, align 8
  %cond257 = icmp ne i64 %v256, 0
  br i1 %cond257, label %bb_guard13, label %bb_oi6
bb_guard13:
  br label %bb_fi6
bb_fi6:
  %v258 = load i64, ptr %slot10, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot31, align 8
  %v261 = load i64, ptr %slot31, align 8
  %v262 = load i64, ptr %slot14, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot11, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot32, align 8
  %v267 = load i64, ptr %slot32, align 8
  %v268 = load i64, ptr %slot15, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot15, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot33, align 8
  %v273 = load i64, ptr %slot14, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot34, align 8
  %v276 = load i64, ptr %slot34, align 8
  %v277 = load i64, ptr %slot33, align 8
  %cmp278 = icmp slt i64 %v276, %v277
  %cv279 = zext i1 %cmp278 to i64
  store i64 %cv279, ptr %slot35, align 8
  %v280 = load i64, ptr %slot35, align 8
  %v281 = load i64, ptr %slot14, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 %v280, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot14, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot36, align 8
  %v286 = load i64, ptr %slot36, align 8
  %cond287 = icmp ne i64 %v286, 0
  br i1 %cond287, label %bb_next21, label %bb_i34
bb_next21:
  %v288 = load i64, ptr %slot10, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot37, align 8
  %v291 = load i64, ptr %slot37, align 8
  %v292 = load i64, ptr %slot14, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot15, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 2, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot15, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot38, align 8
  %v299 = load i64, ptr %slot14, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot39, align 8
  %v302 = load i64, ptr %slot38, align 8
  %cmp303 = icmp eq i64 %v302, 0
  %cv304 = zext i1 %cmp303 to i64
  store i64 %cv304, ptr %slot40, align 8
  %v305 = load i64, ptr %slot40, align 8
  %cond306 = icmp ne i64 %v305, 0
  br i1 %cond306, label %bb_division24, label %bb_nonzero24
bb_division24:
  %v307 = load i64, ptr %slot1, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %v309 = load i64, ptr %slot39, align 8
  %v310 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_division(ptr %p308, i64 6, i64 %v309, i64 %v310) nomerge, !dbg !110
  unreachable
bb_nonzero24:
  %v311 = load i64, ptr %slot39, align 8
  %cmp312 = icmp eq i64 %v311, 9223372036854775808
  %cv313 = zext i1 %cmp312 to i64
  store i64 %cv313, ptr %slot41, align 8
  %v314 = load i64, ptr %slot38, align 8
  %cmp315 = icmp eq i64 %v314, 18446744073709551615
  %cv316 = zext i1 %cmp315 to i64
  store i64 %cv316, ptr %slot42, align 8
  %v317 = load i64, ptr %slot41, align 8
  %v318 = load i64, ptr %slot42, align 8
  %op319 = and i64 %v317, %v318
  store i64 %op319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot43, align 8
  %neg321 = sub i64 0, %v320
  store i64 %neg321, ptr %slot44, align 8
  %v322 = load i64, ptr %slot38, align 8
  %op323 = xor i64 %v322, 1
  store i64 %op323, ptr %slot45, align 8
  %v324 = load i64, ptr %slot45, align 8
  %v325 = load i64, ptr %slot44, align 8
  %op326 = and i64 %v324, %v325
  store i64 %op326, ptr %slot45, align 8
  %v327 = load i64, ptr %slot38, align 8
  %v328 = load i64, ptr %slot45, align 8
  %op329 = xor i64 %v327, %v328
  store i64 %op329, ptr %slot46, align 8
  %v330 = load i64, ptr %slot39, align 8
  %v331 = load i64, ptr %slot46, align 8
  %op332 = srem i64 %v330, %v331
  store i64 %op332, ptr %slot47, align 8
  %v333 = load i64, ptr %slot47, align 8
  %cmp334 = icmp ne i64 %v333, 0
  %cv335 = zext i1 %cmp334 to i64
  store i64 %cv335, ptr %slot48, align 8
  %v336 = load i64, ptr %slot47, align 8
  %v337 = load i64, ptr %slot46, align 8
  %op338 = xor i64 %v336, %v337
  store i64 %op338, ptr %slot49, align 8
  %v339 = load i64, ptr %slot49, align 8
  %cmp340 = icmp slt i64 %v339, 0
  %cv341 = zext i1 %cmp340 to i64
  store i64 %cv341, ptr %slot50, align 8
  %v342 = load i64, ptr %slot48, align 8
  %v343 = load i64, ptr %slot50, align 8
  %op344 = and i64 %v342, %v343
  store i64 %op344, ptr %slot51, align 8
  %v345 = load i64, ptr %slot51, align 8
  %neg346 = sub i64 0, %v345
  store i64 %neg346, ptr %slot52, align 8
  %v347 = load i64, ptr %slot46, align 8
  %v348 = load i64, ptr %slot52, align 8
  %op349 = and i64 %v347, %v348
  store i64 %op349, ptr %slot53, align 8
  %v350 = load i64, ptr %slot47, align 8
  %v351 = load i64, ptr %slot53, align 8
  %op352 = add i64 %v350, %v351
  store i64 %op352, ptr %slot47, align 8
  %v353 = load i64, ptr %slot47, align 8
  %floorbounded354 = icmp ult i64 %v353, 2
  call void @llvm.assume(i1 %floorbounded354)
  %v355 = load i64, ptr %slot47, align 8
  %v356 = load i64, ptr %slot14, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot8, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot54, align 8
  %v361 = load i64, ptr %slot54, align 8
  %v362 = load i64, ptr %slot15, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot15, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot55, align 8
  %v367 = load i64, ptr %slot14, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld369, ptr %slot56, align 8
  %v370 = load i64, ptr %slot56, align 8
  %v371 = load i64, ptr %slot55, align 8
  %cmp372 = icmp eq i64 %v370, %v371
  %cv373 = zext i1 %cmp372 to i64
  store i64 %cv373, ptr %slot57, align 8
  %v374 = load i64, ptr %slot57, align 8
  %v375 = load i64, ptr %slot14, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot14, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot58, align 8
  %v380 = load i64, ptr %slot58, align 8
  %cond381 = icmp ne i64 %v380, 0
  br i1 %cond381, label %bb_next43, label %bb_fi19
bb_next43:
  %v382 = load i64, ptr %slot14, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 1, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot14, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot59, align 8
  %v387 = load i64, ptr %slot59, align 8
  %v388 = load i64, ptr %slot12, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v390 = load i64, ptr %slot14, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 0, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot14, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot60, align 8
  %v395 = load i64, ptr %slot60, align 8
  %v396 = load i64, ptr %slot12, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v398 = load i64, ptr %slot12, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld400, ptr %slot61, align 8
  %v401 = load i64, ptr %slot61, align 8
  %v402 = load i64, ptr %slot14, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i64 %v401, ptr %p403, align 8, !alias.scope !3, !noalias !4
  %v404 = load i64, ptr %slot14, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %ld406 = load i64, ptr %p405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld406, ptr %slot62, align 8
  %v407 = load i64, ptr %slot62, align 8
  %v408 = load i64, ptr %slot13, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 %v407, ptr %p409, align 8, !alias.scope !3, !noalias !4
  %v410 = load i64, ptr %slot9, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i64, ptr %p411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld412, ptr %slot63, align 8
  %v413 = load i64, ptr %slot63, align 8
  %v414 = load i64, ptr %slot14, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i64 %v413, ptr %p415, align 8, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot13, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i64, ptr %p417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld418, ptr %slot64, align 8
  %v419 = load i64, ptr %slot64, align 8
  %v420 = load i64, ptr %slot15, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 %v419, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot15, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot65, align 8
  %v425 = load i64, ptr %slot14, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot66, align 8
  %v428 = load i64, ptr %slot66, align 8
  %v429 = load i64, ptr %slot65, align 8
  %ovpair431 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v428, i64 %v429)
  %op430 = extractvalue { i64, i1 } %ovpair431, 0
  %ov432 = extractvalue { i64, i1 } %ovpair431, 1
  store i64 %op430, ptr %slot67, align 8
  %v433 = load i64, ptr %slot66, align 8
  %v434 = load i64, ptr %slot67, align 8
  %op435 = xor i64 %v433, %v434
  store i64 %op435, ptr %slot68, align 8
  %v436 = load i64, ptr %slot65, align 8
  %v437 = load i64, ptr %slot67, align 8
  %op438 = xor i64 %v436, %v437
  store i64 %op438, ptr %slot69, align 8
  %v439 = load i64, ptr %slot68, align 8
  %v440 = load i64, ptr %slot69, align 8
  %op441 = and i64 %v439, %v440
  store i64 %op441, ptr %slot70, align 8
  %cv442 = zext i1 %ov432 to i64
  store i64 %cv442, ptr %slot71, align 8
  %v443 = load i64, ptr %slot71, align 8
  %cond444 = icmp ne i64 %v443, 0
  br i1 %cond444, label %bb_overflow51, label %bb_checked51
bb_overflow51:
  %v445 = load i64, ptr %slot1, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %v447 = load i64, ptr %slot66, align 8
  %v448 = load i64, ptr %slot65, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p446, i64 0, i64 %v447, i64 %v448, i64 64) nomerge, !dbg !112
  unreachable
bb_checked51:
  %v449 = load i64, ptr %slot67, align 8
  %v450 = load i64, ptr %slot14, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot15, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i64 1000000007, ptr %p453, align 8, !alias.scope !3, !noalias !4
  %v454 = load i64, ptr %slot15, align 8
  %p455 = inttoptr i64 %v454 to ptr
  %ld456 = load i64, ptr %p455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld456, ptr %slot72, align 8
  %v457 = load i64, ptr %slot14, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot73, align 8
  %v460 = load i64, ptr %slot72, align 8
  %cmp461 = icmp eq i64 %v460, 0
  %cv462 = zext i1 %cmp461 to i64
  store i64 %cv462, ptr %slot74, align 8
  %v463 = load i64, ptr %slot74, align 8
  %cond464 = icmp ne i64 %v463, 0
  br i1 %cond464, label %bb_division58, label %bb_nonzero58
bb_division58:
  %v465 = load i64, ptr %slot1, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %v467 = load i64, ptr %slot73, align 8
  %v468 = load i64, ptr %slot72, align 8
  call void @myl_qbe_fail_division(ptr %p466, i64 6, i64 %v467, i64 %v468) nomerge, !dbg !114
  unreachable
bb_nonzero58:
  %v469 = load i64, ptr %slot73, align 8
  %cmp470 = icmp eq i64 %v469, 9223372036854775808
  %cv471 = zext i1 %cmp470 to i64
  store i64 %cv471, ptr %slot75, align 8
  %v472 = load i64, ptr %slot72, align 8
  %cmp473 = icmp eq i64 %v472, 18446744073709551615
  %cv474 = zext i1 %cmp473 to i64
  store i64 %cv474, ptr %slot76, align 8
  %v475 = load i64, ptr %slot75, align 8
  %v476 = load i64, ptr %slot76, align 8
  %op477 = and i64 %v475, %v476
  store i64 %op477, ptr %slot77, align 8
  %v478 = load i64, ptr %slot77, align 8
  %neg479 = sub i64 0, %v478
  store i64 %neg479, ptr %slot78, align 8
  %v480 = load i64, ptr %slot72, align 8
  %op481 = xor i64 %v480, 1
  store i64 %op481, ptr %slot79, align 8
  %v482 = load i64, ptr %slot79, align 8
  %v483 = load i64, ptr %slot78, align 8
  %op484 = and i64 %v482, %v483
  store i64 %op484, ptr %slot79, align 8
  %v485 = load i64, ptr %slot72, align 8
  %v486 = load i64, ptr %slot79, align 8
  %op487 = xor i64 %v485, %v486
  store i64 %op487, ptr %slot80, align 8
  %v488 = load i64, ptr %slot73, align 8
  %v489 = load i64, ptr %slot80, align 8
  %op490 = srem i64 %v488, %v489
  store i64 %op490, ptr %slot81, align 8
  %v491 = load i64, ptr %slot81, align 8
  %cmp492 = icmp ne i64 %v491, 0
  %cv493 = zext i1 %cmp492 to i64
  store i64 %cv493, ptr %slot82, align 8
  %v494 = load i64, ptr %slot81, align 8
  %v495 = load i64, ptr %slot80, align 8
  %op496 = xor i64 %v494, %v495
  store i64 %op496, ptr %slot83, align 8
  %v497 = load i64, ptr %slot83, align 8
  %cmp498 = icmp slt i64 %v497, 0
  %cv499 = zext i1 %cmp498 to i64
  store i64 %cv499, ptr %slot84, align 8
  %v500 = load i64, ptr %slot82, align 8
  %v501 = load i64, ptr %slot84, align 8
  %op502 = and i64 %v500, %v501
  store i64 %op502, ptr %slot85, align 8
  %v503 = load i64, ptr %slot85, align 8
  %neg504 = sub i64 0, %v503
  store i64 %neg504, ptr %slot86, align 8
  %v505 = load i64, ptr %slot80, align 8
  %v506 = load i64, ptr %slot86, align 8
  %op507 = and i64 %v505, %v506
  store i64 %op507, ptr %slot87, align 8
  %v508 = load i64, ptr %slot81, align 8
  %v509 = load i64, ptr %slot87, align 8
  %op510 = add i64 %v508, %v509
  store i64 %op510, ptr %slot81, align 8
  %v511 = load i64, ptr %slot81, align 8
  %floorbounded512 = icmp ult i64 %v511, 1000000007
  call void @llvm.assume(i1 %floorbounded512)
  %v513 = load i64, ptr %slot81, align 8
  %v514 = load i64, ptr %slot14, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 %v513, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot14, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot88, align 8
  %v519 = load i64, ptr %slot88, align 8
  %v520 = load i64, ptr %slot9, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 %v519, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot10, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld524, ptr %slot89, align 8
  %v525 = load i64, ptr %slot89, align 8
  %v526 = load i64, ptr %slot14, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 %v525, ptr %p527, align 8, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot15, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 1, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot15, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot90, align 8
  %v533 = load i64, ptr %slot14, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i64, ptr %p534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot91, align 8
  %v536 = load i64, ptr %slot91, align 8
  %v537 = load i64, ptr %slot90, align 8
  %op538 = add i64 %v536, %v537
  store i64 %op538, ptr %slot92, align 8
  %v539 = load i64, ptr %slot92, align 8
  %v540 = load i64, ptr %slot14, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot14, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot93, align 8
  %v545 = load i64, ptr %slot93, align 8
  %v546 = load i64, ptr %slot10, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !119
bb_oi6:
  %v548 = load i64, ptr %slot10, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i64, ptr %p549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld550, ptr %slot94, align 8
  %v551 = load i64, ptr %slot94, align 8
  %v552 = load i64, ptr %slot14, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i64 %v551, ptr %p553, align 8, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot11, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %ld556 = load i64, ptr %p555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld556, ptr %slot95, align 8
  %v557 = load i64, ptr %slot95, align 8
  %v558 = load i64, ptr %slot15, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot15, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot96, align 8
  %v563 = load i64, ptr %slot14, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot97, align 8
  %v566 = load i64, ptr %slot97, align 8
  %v567 = load i64, ptr %slot96, align 8
  %cmp568 = icmp slt i64 %v566, %v567
  %cv569 = zext i1 %cmp568 to i64
  store i64 %cv569, ptr %slot98, align 8
  %v570 = load i64, ptr %slot98, align 8
  %v571 = load i64, ptr %slot14, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i64 %v570, ptr %p572, align 8, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot14, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i64, ptr %p574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld575, ptr %slot99, align 8
  %v576 = load i64, ptr %slot99, align 8
  %cond577 = icmp ne i64 %v576, 0
  br i1 %cond577, label %bb_next84, label %bb_i34
bb_next84:
  %v578 = load i64, ptr %slot10, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i64, ptr %p579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld580, ptr %slot100, align 8
  %v581 = load i64, ptr %slot100, align 8
  %v582 = load i64, ptr %slot14, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i64 %v581, ptr %p583, align 8, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot15, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i64 2, ptr %p585, align 8, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot15, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ld588 = load i64, ptr %p587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld588, ptr %slot101, align 8
  %v589 = load i64, ptr %slot14, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld591, ptr %slot102, align 8
  %v592 = load i64, ptr %slot101, align 8
  %cmp593 = icmp eq i64 %v592, 0
  %cv594 = zext i1 %cmp593 to i64
  store i64 %cv594, ptr %slot103, align 8
  %v595 = load i64, ptr %slot103, align 8
  %cond596 = icmp ne i64 %v595, 0
  br i1 %cond596, label %bb_division87, label %bb_nonzero87
bb_division87:
  %v597 = load i64, ptr %slot1, align 8
  %p598 = inttoptr i64 %v597 to ptr
  %v599 = load i64, ptr %slot102, align 8
  %v600 = load i64, ptr %slot101, align 8
  call void @myl_qbe_fail_division(ptr %p598, i64 6, i64 %v599, i64 %v600) nomerge, !dbg !110
  unreachable
bb_nonzero87:
  %v601 = load i64, ptr %slot102, align 8
  %cmp602 = icmp eq i64 %v601, 9223372036854775808
  %cv603 = zext i1 %cmp602 to i64
  store i64 %cv603, ptr %slot104, align 8
  %v604 = load i64, ptr %slot101, align 8
  %cmp605 = icmp eq i64 %v604, 18446744073709551615
  %cv606 = zext i1 %cmp605 to i64
  store i64 %cv606, ptr %slot105, align 8
  %v607 = load i64, ptr %slot104, align 8
  %v608 = load i64, ptr %slot105, align 8
  %op609 = and i64 %v607, %v608
  store i64 %op609, ptr %slot106, align 8
  %v610 = load i64, ptr %slot106, align 8
  %neg611 = sub i64 0, %v610
  store i64 %neg611, ptr %slot107, align 8
  %v612 = load i64, ptr %slot101, align 8
  %op613 = xor i64 %v612, 1
  store i64 %op613, ptr %slot108, align 8
  %v614 = load i64, ptr %slot108, align 8
  %v615 = load i64, ptr %slot107, align 8
  %op616 = and i64 %v614, %v615
  store i64 %op616, ptr %slot108, align 8
  %v617 = load i64, ptr %slot101, align 8
  %v618 = load i64, ptr %slot108, align 8
  %op619 = xor i64 %v617, %v618
  store i64 %op619, ptr %slot109, align 8
  %v620 = load i64, ptr %slot102, align 8
  %v621 = load i64, ptr %slot109, align 8
  %op622 = srem i64 %v620, %v621
  store i64 %op622, ptr %slot110, align 8
  %v623 = load i64, ptr %slot110, align 8
  %cmp624 = icmp ne i64 %v623, 0
  %cv625 = zext i1 %cmp624 to i64
  store i64 %cv625, ptr %slot111, align 8
  %v626 = load i64, ptr %slot110, align 8
  %v627 = load i64, ptr %slot109, align 8
  %op628 = xor i64 %v626, %v627
  store i64 %op628, ptr %slot112, align 8
  %v629 = load i64, ptr %slot112, align 8
  %cmp630 = icmp slt i64 %v629, 0
  %cv631 = zext i1 %cmp630 to i64
  store i64 %cv631, ptr %slot113, align 8
  %v632 = load i64, ptr %slot111, align 8
  %v633 = load i64, ptr %slot113, align 8
  %op634 = and i64 %v632, %v633
  store i64 %op634, ptr %slot114, align 8
  %v635 = load i64, ptr %slot114, align 8
  %neg636 = sub i64 0, %v635
  store i64 %neg636, ptr %slot115, align 8
  %v637 = load i64, ptr %slot109, align 8
  %v638 = load i64, ptr %slot115, align 8
  %op639 = and i64 %v637, %v638
  store i64 %op639, ptr %slot116, align 8
  %v640 = load i64, ptr %slot110, align 8
  %v641 = load i64, ptr %slot116, align 8
  %op642 = add i64 %v640, %v641
  store i64 %op642, ptr %slot110, align 8
  %v643 = load i64, ptr %slot110, align 8
  %floorbounded644 = icmp ult i64 %v643, 2
  call void @llvm.assume(i1 %floorbounded644)
  %v645 = load i64, ptr %slot110, align 8
  %v646 = load i64, ptr %slot14, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i64 %v645, ptr %p647, align 8, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot8, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot117, align 8
  %v651 = load i64, ptr %slot117, align 8
  %v652 = load i64, ptr %slot15, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot15, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i64, ptr %p655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld656, ptr %slot118, align 8
  %v657 = load i64, ptr %slot14, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot119, align 8
  %v660 = load i64, ptr %slot119, align 8
  %v661 = load i64, ptr %slot118, align 8
  %cmp662 = icmp eq i64 %v660, %v661
  %cv663 = zext i1 %cmp662 to i64
  store i64 %cv663, ptr %slot120, align 8
  %v664 = load i64, ptr %slot120, align 8
  %v665 = load i64, ptr %slot14, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i64 %v664, ptr %p666, align 8, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot14, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot121, align 8
  %v670 = load i64, ptr %slot121, align 8
  %cond671 = icmp ne i64 %v670, 0
  br i1 %cond671, label %bb_next106, label %bb_i19
bb_next106:
  %v672 = load i64, ptr %slot14, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i64 1, ptr %p673, align 8, !alias.scope !3, !noalias !4
  %v674 = load i64, ptr %slot14, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot122, align 8
  %v677 = load i64, ptr %slot122, align 8
  %v678 = load i64, ptr %slot12, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i64 %v677, ptr %p679, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v680 = load i64, ptr %slot14, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 0, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot14, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot123, align 8
  %v685 = load i64, ptr %slot123, align 8
  %v686 = load i64, ptr %slot12, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v688 = load i64, ptr %slot12, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot124, align 8
  %v691 = load i64, ptr %slot124, align 8
  %v692 = load i64, ptr %slot14, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot14, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot125, align 8
  %v697 = load i64, ptr %slot125, align 8
  %v698 = load i64, ptr %slot13, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i64 %v697, ptr %p699, align 8, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot9, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot126, align 8
  %v703 = load i64, ptr %slot126, align 8
  %v704 = load i64, ptr %slot14, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot13, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i64, ptr %p707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot127, align 8
  %v709 = load i64, ptr %slot127, align 8
  %v710 = load i64, ptr %slot15, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot15, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %ld714 = load i64, ptr %p713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld714, ptr %slot128, align 8
  %v715 = load i64, ptr %slot14, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i64, ptr %p716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld717, ptr %slot129, align 8
  %v718 = load i64, ptr %slot129, align 8
  %v719 = load i64, ptr %slot128, align 8
  %ovpair721 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v718, i64 %v719)
  %op720 = extractvalue { i64, i1 } %ovpair721, 0
  %ov722 = extractvalue { i64, i1 } %ovpair721, 1
  store i64 %op720, ptr %slot130, align 8
  %v723 = load i64, ptr %slot129, align 8
  %v724 = load i64, ptr %slot130, align 8
  %op725 = xor i64 %v723, %v724
  store i64 %op725, ptr %slot131, align 8
  %v726 = load i64, ptr %slot128, align 8
  %v727 = load i64, ptr %slot130, align 8
  %op728 = xor i64 %v726, %v727
  store i64 %op728, ptr %slot132, align 8
  %v729 = load i64, ptr %slot131, align 8
  %v730 = load i64, ptr %slot132, align 8
  %op731 = and i64 %v729, %v730
  store i64 %op731, ptr %slot133, align 8
  %cv732 = zext i1 %ov722 to i64
  store i64 %cv732, ptr %slot134, align 8
  %v733 = load i64, ptr %slot134, align 8
  %cond734 = icmp ne i64 %v733, 0
  br i1 %cond734, label %bb_overflow114, label %bb_checked114
bb_overflow114:
  %v735 = load i64, ptr %slot1, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %v737 = load i64, ptr %slot129, align 8
  %v738 = load i64, ptr %slot128, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p736, i64 0, i64 %v737, i64 %v738, i64 64) nomerge, !dbg !112
  unreachable
bb_checked114:
  %v739 = load i64, ptr %slot130, align 8
  %v740 = load i64, ptr %slot14, align 8
  %p741 = inttoptr i64 %v740 to ptr
  store i64 %v739, ptr %p741, align 8, !alias.scope !3, !noalias !4
  %v742 = load i64, ptr %slot15, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i64 1000000007, ptr %p743, align 8, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot15, align 8
  %p745 = inttoptr i64 %v744 to ptr
  %ld746 = load i64, ptr %p745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld746, ptr %slot135, align 8
  %v747 = load i64, ptr %slot14, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i64, ptr %p748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld749, ptr %slot136, align 8
  %v750 = load i64, ptr %slot135, align 8
  %cmp751 = icmp eq i64 %v750, 0
  %cv752 = zext i1 %cmp751 to i64
  store i64 %cv752, ptr %slot137, align 8
  %v753 = load i64, ptr %slot137, align 8
  %cond754 = icmp ne i64 %v753, 0
  br i1 %cond754, label %bb_division121, label %bb_nonzero121
bb_division121:
  %v755 = load i64, ptr %slot1, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %v757 = load i64, ptr %slot136, align 8
  %v758 = load i64, ptr %slot135, align 8
  call void @myl_qbe_fail_division(ptr %p756, i64 6, i64 %v757, i64 %v758) nomerge, !dbg !114
  unreachable
bb_nonzero121:
  %v759 = load i64, ptr %slot136, align 8
  %cmp760 = icmp eq i64 %v759, 9223372036854775808
  %cv761 = zext i1 %cmp760 to i64
  store i64 %cv761, ptr %slot138, align 8
  %v762 = load i64, ptr %slot135, align 8
  %cmp763 = icmp eq i64 %v762, 18446744073709551615
  %cv764 = zext i1 %cmp763 to i64
  store i64 %cv764, ptr %slot139, align 8
  %v765 = load i64, ptr %slot138, align 8
  %v766 = load i64, ptr %slot139, align 8
  %op767 = and i64 %v765, %v766
  store i64 %op767, ptr %slot140, align 8
  %v768 = load i64, ptr %slot140, align 8
  %neg769 = sub i64 0, %v768
  store i64 %neg769, ptr %slot141, align 8
  %v770 = load i64, ptr %slot135, align 8
  %op771 = xor i64 %v770, 1
  store i64 %op771, ptr %slot142, align 8
  %v772 = load i64, ptr %slot142, align 8
  %v773 = load i64, ptr %slot141, align 8
  %op774 = and i64 %v772, %v773
  store i64 %op774, ptr %slot142, align 8
  %v775 = load i64, ptr %slot135, align 8
  %v776 = load i64, ptr %slot142, align 8
  %op777 = xor i64 %v775, %v776
  store i64 %op777, ptr %slot143, align 8
  %v778 = load i64, ptr %slot136, align 8
  %v779 = load i64, ptr %slot143, align 8
  %op780 = srem i64 %v778, %v779
  store i64 %op780, ptr %slot144, align 8
  %v781 = load i64, ptr %slot144, align 8
  %cmp782 = icmp ne i64 %v781, 0
  %cv783 = zext i1 %cmp782 to i64
  store i64 %cv783, ptr %slot145, align 8
  %v784 = load i64, ptr %slot144, align 8
  %v785 = load i64, ptr %slot143, align 8
  %op786 = xor i64 %v784, %v785
  store i64 %op786, ptr %slot146, align 8
  %v787 = load i64, ptr %slot146, align 8
  %cmp788 = icmp slt i64 %v787, 0
  %cv789 = zext i1 %cmp788 to i64
  store i64 %cv789, ptr %slot147, align 8
  %v790 = load i64, ptr %slot145, align 8
  %v791 = load i64, ptr %slot147, align 8
  %op792 = and i64 %v790, %v791
  store i64 %op792, ptr %slot148, align 8
  %v793 = load i64, ptr %slot148, align 8
  %neg794 = sub i64 0, %v793
  store i64 %neg794, ptr %slot149, align 8
  %v795 = load i64, ptr %slot143, align 8
  %v796 = load i64, ptr %slot149, align 8
  %op797 = and i64 %v795, %v796
  store i64 %op797, ptr %slot150, align 8
  %v798 = load i64, ptr %slot144, align 8
  %v799 = load i64, ptr %slot150, align 8
  %op800 = add i64 %v798, %v799
  store i64 %op800, ptr %slot144, align 8
  %v801 = load i64, ptr %slot144, align 8
  %floorbounded802 = icmp ult i64 %v801, 1000000007
  call void @llvm.assume(i1 %floorbounded802)
  %v803 = load i64, ptr %slot144, align 8
  %v804 = load i64, ptr %slot14, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i64 %v803, ptr %p805, align 8, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot14, align 8
  %p807 = inttoptr i64 %v806 to ptr
  %ld808 = load i64, ptr %p807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld808, ptr %slot151, align 8
  %v809 = load i64, ptr %slot151, align 8
  %v810 = load i64, ptr %slot9, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 %v809, ptr %p811, align 8, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot10, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot152, align 8
  %v815 = load i64, ptr %slot152, align 8
  %v816 = load i64, ptr %slot14, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot15, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i64 1, ptr %p819, align 8, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot15, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %ld822 = load i64, ptr %p821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld822, ptr %slot153, align 8
  %v823 = load i64, ptr %slot14, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i64, ptr %p824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld825, ptr %slot154, align 8
  %v826 = load i64, ptr %slot154, align 8
  %v827 = load i64, ptr %slot153, align 8
  %op828 = add i64 %v826, %v827
  %ovpair829 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v826, i64 %v827)
  %ov830 = extractvalue { i64, i1 } %ovpair829, 1
  store i64 %op828, ptr %slot155, align 8
  %cv831 = zext i1 %ov830 to i64
  store i64 %cv831, ptr %slot156, align 8
  %v832 = load i64, ptr %slot156, align 8
  %cond833 = icmp ne i64 %v832, 0
  br i1 %cond833, label %bb_overflow139, label %bb_checked139
bb_overflow139:
  %v834 = load i64, ptr %slot1, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %v836 = load i64, ptr %slot154, align 8
  %v837 = load i64, ptr %slot153, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p835, i64 0, i64 %v836, i64 %v837, i64 64) nomerge, !dbg !116
  unreachable
bb_checked139:
  %v838 = load i64, ptr %slot155, align 8
  %v839 = load i64, ptr %slot14, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i64 %v838, ptr %p840, align 8, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot14, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i64, ptr %p842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld843, ptr %slot157, align 8
  %v844 = load i64, ptr %slot157, align 8
  %v845 = load i64, ptr %slot10, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 %v844, ptr %p846, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !120
bb_i34:
  %v847 = load i64, ptr %slot9, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ld849 = load i64, ptr %p848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld849, ptr %slot158, align 8
  %v850 = load i64, ptr %slot158, align 8
  %v851 = load i64, ptr %slot14, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 %v850, ptr %p852, align 8, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot14, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot159, align 8
  %v856 = load i64, ptr %slot159, align 8
  ret i64 %v856
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", linkageName: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4238653121982337121, i64 0, !"myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
!118 = !{!"llvm.loop.align", i32 32}
!119 = distinct !{!119, !118}
!120 = distinct !{!120, !118}
