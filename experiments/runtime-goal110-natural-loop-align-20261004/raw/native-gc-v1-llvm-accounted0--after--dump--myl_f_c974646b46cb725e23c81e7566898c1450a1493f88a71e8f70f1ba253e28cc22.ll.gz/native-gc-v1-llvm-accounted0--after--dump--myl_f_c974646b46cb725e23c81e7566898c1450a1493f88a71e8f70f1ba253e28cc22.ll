target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v157 = load i64, ptr %slot1, align 8
  %op158 = add i64 %v157, 32
  store i64 %op158, ptr %slot4, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot5, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot6, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot7, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot8, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot9, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot10, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot11, align 8
  %mem173 = alloca i8, i64 8, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot12, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot13, align 8
  %v177 = load i64, ptr %slot2, align 8
  %v178 = load i64, ptr %slot5, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot3, align 8
  %v181 = load i64, ptr %slot6, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v183 = load i64, ptr %slot12, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 0, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot12, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld187, ptr %slot14, align 8
  %v188 = load i64, ptr %slot14, align 8
  %v189 = load i64, ptr %slot7, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot12, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 0, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot12, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot15, align 8
  %v196 = load i64, ptr %slot15, align 8
  %v197 = load i64, ptr %slot8, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot5, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot16, align 8
  %v202 = load i64, ptr %slot16, align 8
  %v203 = load i64, ptr %slot12, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 %v202, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot12, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot17, align 8
  %v208 = load i64, ptr %slot17, align 8
  %v209 = load i64, ptr %slot9, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot8, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot18, align 8
  %v214 = load i64, ptr %slot9, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot19, align 8
  %v217 = load i64, ptr %slot19, align 8
  %v218 = load i64, ptr %slot18, align 8
  %cmp219 = icmp sgt i64 %v217, %v218
  %cv220 = zext i1 %cmp219 to i64
  store i64 %cv220, ptr %slot20, align 8
  %v221 = load i64, ptr %slot19, align 8
  %v222 = load i64, ptr %slot18, align 8
  %op223 = sub i64 %v221, %v222
  store i64 %op223, ptr %slot21, align 8
  %v224 = load i64, ptr %slot21, align 8
  %cmp225 = icmp uge i64 %v224, 16
  %cv226 = zext i1 %cmp225 to i64
  store i64 %cv226, ptr %slot22, align 8
  %v227 = load i64, ptr %slot20, align 8
  %v228 = load i64, ptr %slot22, align 8
  %op229 = and i64 %v227, %v228
  store i64 %op229, ptr %slot23, align 8
  %v230 = load i64, ptr %slot23, align 8
  %cond231 = icmp ne i64 %v230, 0
  br i1 %cond231, label %bb_guard4, label %bb_oi6
bb_guard4:
  %v232 = load i64, ptr %slot18, align 8
  %op233 = add i64 %v232, 1152921504606846976
  store i64 %op233, ptr %slot24, align 8
  %v234 = load i64, ptr %slot24, align 8
  %cmp235 = icmp ule i64 %v234, 2305843009213693952
  %cv236 = zext i1 %cmp235 to i64
  store i64 %cv236, ptr %slot25, align 8
  %v237 = load i64, ptr %slot25, align 8
  %cond238 = icmp ne i64 %v237, 0
  br i1 %cond238, label %bb_guard10, label %bb_oi6
bb_guard10:
  %v239 = load i64, ptr %slot19, align 8
  %op240 = add i64 %v239, 1152921504606846976
  store i64 %op240, ptr %slot26, align 8
  %v241 = load i64, ptr %slot26, align 8
  %cmp242 = icmp ule i64 %v241, 2305843009213693952
  %cv243 = zext i1 %cmp242 to i64
  store i64 %cv243, ptr %slot27, align 8
  %v244 = load i64, ptr %slot27, align 8
  %cond245 = icmp ne i64 %v244, 0
  br i1 %cond245, label %bb_guard12, label %bb_oi6
bb_guard12:
  br label %bb_fi6
bb_fi6:
  %v246 = load i64, ptr %slot8, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot28, align 8
  %v249 = load i64, ptr %slot28, align 8
  %v250 = load i64, ptr %slot12, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i64 %v249, ptr %p251, align 8, !alias.scope !3, !noalias !4
  %v252 = load i64, ptr %slot9, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot29, align 8
  %v255 = load i64, ptr %slot29, align 8
  %v256 = load i64, ptr %slot13, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 %v255, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot13, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot30, align 8
  %v261 = load i64, ptr %slot12, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot31, align 8
  %v264 = load i64, ptr %slot31, align 8
  %v265 = load i64, ptr %slot30, align 8
  %cmp266 = icmp slt i64 %v264, %v265
  %cv267 = zext i1 %cmp266 to i64
  store i64 %cv267, ptr %slot32, align 8
  %v268 = load i64, ptr %slot32, align 8
  %v269 = load i64, ptr %slot12, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot12, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot33, align 8
  %v274 = load i64, ptr %slot33, align 8
  %cond275 = icmp ne i64 %v274, 0
  br i1 %cond275, label %bb_next20, label %bb_i34
bb_next20:
  %v276 = load i64, ptr %slot8, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot34, align 8
  %v279 = load i64, ptr %slot34, align 8
  %v280 = load i64, ptr %slot12, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot13, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 2, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot13, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot35, align 8
  %v287 = load i64, ptr %slot12, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot36, align 8
  %v290 = load i64, ptr %slot35, align 8
  %cmp291 = icmp eq i64 %v290, 0
  %cv292 = zext i1 %cmp291 to i64
  store i64 %cv292, ptr %slot37, align 8
  %v293 = load i64, ptr %slot37, align 8
  %cond294 = icmp ne i64 %v293, 0
  br i1 %cond294, label %bb_division23, label %bb_nonzero23
bb_division23:
  %v295 = load i64, ptr %slot1, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %v297 = load i64, ptr %slot36, align 8
  %v298 = load i64, ptr %slot35, align 8
  call void @myl_qbe_fail_division(ptr %p296, i64 6, i64 %v297, i64 %v298) nomerge, !dbg !110
  unreachable
bb_nonzero23:
  %v299 = load i64, ptr %slot36, align 8
  %cmp300 = icmp eq i64 %v299, 9223372036854775808
  %cv301 = zext i1 %cmp300 to i64
  store i64 %cv301, ptr %slot38, align 8
  %v302 = load i64, ptr %slot35, align 8
  %cmp303 = icmp eq i64 %v302, 18446744073709551615
  %cv304 = zext i1 %cmp303 to i64
  store i64 %cv304, ptr %slot39, align 8
  %v305 = load i64, ptr %slot38, align 8
  %v306 = load i64, ptr %slot39, align 8
  %op307 = and i64 %v305, %v306
  store i64 %op307, ptr %slot40, align 8
  %v308 = load i64, ptr %slot40, align 8
  %neg309 = sub i64 0, %v308
  store i64 %neg309, ptr %slot41, align 8
  %v310 = load i64, ptr %slot35, align 8
  %op311 = xor i64 %v310, 1
  store i64 %op311, ptr %slot42, align 8
  %v312 = load i64, ptr %slot42, align 8
  %v313 = load i64, ptr %slot41, align 8
  %op314 = and i64 %v312, %v313
  store i64 %op314, ptr %slot42, align 8
  %v315 = load i64, ptr %slot35, align 8
  %v316 = load i64, ptr %slot42, align 8
  %op317 = xor i64 %v315, %v316
  store i64 %op317, ptr %slot43, align 8
  %v318 = load i64, ptr %slot36, align 8
  %v319 = load i64, ptr %slot43, align 8
  %op320 = srem i64 %v318, %v319
  store i64 %op320, ptr %slot44, align 8
  %v321 = load i64, ptr %slot44, align 8
  %cmp322 = icmp ne i64 %v321, 0
  %cv323 = zext i1 %cmp322 to i64
  store i64 %cv323, ptr %slot45, align 8
  %v324 = load i64, ptr %slot44, align 8
  %v325 = load i64, ptr %slot43, align 8
  %op326 = xor i64 %v324, %v325
  store i64 %op326, ptr %slot46, align 8
  %v327 = load i64, ptr %slot46, align 8
  %cmp328 = icmp slt i64 %v327, 0
  %cv329 = zext i1 %cmp328 to i64
  store i64 %cv329, ptr %slot47, align 8
  %v330 = load i64, ptr %slot45, align 8
  %v331 = load i64, ptr %slot47, align 8
  %op332 = and i64 %v330, %v331
  store i64 %op332, ptr %slot48, align 8
  %v333 = load i64, ptr %slot48, align 8
  %neg334 = sub i64 0, %v333
  store i64 %neg334, ptr %slot49, align 8
  %v335 = load i64, ptr %slot43, align 8
  %v336 = load i64, ptr %slot49, align 8
  %op337 = and i64 %v335, %v336
  store i64 %op337, ptr %slot50, align 8
  %v338 = load i64, ptr %slot44, align 8
  %v339 = load i64, ptr %slot50, align 8
  %op340 = add i64 %v338, %v339
  store i64 %op340, ptr %slot44, align 8
  %v341 = load i64, ptr %slot44, align 8
  %floorbounded342 = icmp ult i64 %v341, 2
  call void @llvm.assume(i1 %floorbounded342)
  %v343 = load i64, ptr %slot44, align 8
  %v344 = load i64, ptr %slot12, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i64 %v343, ptr %p345, align 8, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot6, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld348, ptr %slot51, align 8
  %v349 = load i64, ptr %slot51, align 8
  %v350 = load i64, ptr %slot13, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 %v349, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot13, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %ld354 = load i64, ptr %p353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld354, ptr %slot52, align 8
  %v355 = load i64, ptr %slot12, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot53, align 8
  %v358 = load i64, ptr %slot53, align 8
  %v359 = load i64, ptr %slot52, align 8
  %cmp360 = icmp eq i64 %v358, %v359
  %cv361 = zext i1 %cmp360 to i64
  store i64 %cv361, ptr %slot54, align 8
  %v362 = load i64, ptr %slot54, align 8
  %v363 = load i64, ptr %slot12, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot12, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld367, ptr %slot55, align 8
  %v368 = load i64, ptr %slot55, align 8
  %cond369 = icmp ne i64 %v368, 0
  br i1 %cond369, label %bb_next42, label %bb_fi19
bb_next42:
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 1, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot12, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i64, ptr %p373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld374, ptr %slot56, align 8
  %v375 = load i64, ptr %slot56, align 8
  %v376 = load i64, ptr %slot10, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 %v375, ptr %p377, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v378 = load i64, ptr %slot12, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 0, ptr %p379, align 8, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot12, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot57, align 8
  %v383 = load i64, ptr %slot57, align 8
  %v384 = load i64, ptr %slot10, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 %v383, ptr %p385, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v386 = load i64, ptr %slot10, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot58, align 8
  %v389 = load i64, ptr %slot58, align 8
  %v390 = load i64, ptr %slot12, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 %v389, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot12, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot59, align 8
  %v395 = load i64, ptr %slot59, align 8
  %v396 = load i64, ptr %slot11, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot7, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld400, ptr %slot60, align 8
  %v401 = load i64, ptr %slot60, align 8
  %v402 = load i64, ptr %slot12, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i64 %v401, ptr %p403, align 8, !alias.scope !3, !noalias !4
  %v404 = load i64, ptr %slot11, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %ld406 = load i64, ptr %p405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld406, ptr %slot61, align 8
  %v407 = load i64, ptr %slot61, align 8
  %v408 = load i64, ptr %slot13, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 %v407, ptr %p409, align 8, !alias.scope !3, !noalias !4
  %v410 = load i64, ptr %slot13, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i64, ptr %p411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld412, ptr %slot62, align 8
  %v413 = load i64, ptr %slot12, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot63, align 8
  %v416 = load i64, ptr %slot63, align 8
  %v417 = load i64, ptr %slot62, align 8
  %ovpair419 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v416, i64 %v417)
  %op418 = extractvalue { i64, i1 } %ovpair419, 0
  %ov420 = extractvalue { i64, i1 } %ovpair419, 1
  store i64 %op418, ptr %slot64, align 8
  %v421 = load i64, ptr %slot63, align 8
  %v422 = load i64, ptr %slot64, align 8
  %op423 = xor i64 %v421, %v422
  store i64 %op423, ptr %slot65, align 8
  %v424 = load i64, ptr %slot62, align 8
  %v425 = load i64, ptr %slot64, align 8
  %op426 = xor i64 %v424, %v425
  store i64 %op426, ptr %slot66, align 8
  %v427 = load i64, ptr %slot65, align 8
  %v428 = load i64, ptr %slot66, align 8
  %op429 = and i64 %v427, %v428
  store i64 %op429, ptr %slot67, align 8
  %cv430 = zext i1 %ov420 to i64
  store i64 %cv430, ptr %slot68, align 8
  %v431 = load i64, ptr %slot68, align 8
  %cond432 = icmp ne i64 %v431, 0
  br i1 %cond432, label %bb_overflow50, label %bb_checked50
bb_overflow50:
  %v433 = load i64, ptr %slot1, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %v435 = load i64, ptr %slot63, align 8
  %v436 = load i64, ptr %slot62, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p434, i64 0, i64 %v435, i64 %v436, i64 64) nomerge, !dbg !112
  unreachable
bb_checked50:
  %v437 = load i64, ptr %slot64, align 8
  %v438 = load i64, ptr %slot12, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 %v437, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot13, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i64 1000000007, ptr %p441, align 8, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot13, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %ld444 = load i64, ptr %p443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld444, ptr %slot69, align 8
  %v445 = load i64, ptr %slot12, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ld447 = load i64, ptr %p446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld447, ptr %slot70, align 8
  %v448 = load i64, ptr %slot69, align 8
  %cmp449 = icmp eq i64 %v448, 0
  %cv450 = zext i1 %cmp449 to i64
  store i64 %cv450, ptr %slot71, align 8
  %v451 = load i64, ptr %slot71, align 8
  %cond452 = icmp ne i64 %v451, 0
  br i1 %cond452, label %bb_division57, label %bb_nonzero57
bb_division57:
  %v453 = load i64, ptr %slot1, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %v455 = load i64, ptr %slot70, align 8
  %v456 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_division(ptr %p454, i64 6, i64 %v455, i64 %v456) nomerge, !dbg !114
  unreachable
bb_nonzero57:
  %v457 = load i64, ptr %slot70, align 8
  %cmp458 = icmp eq i64 %v457, 9223372036854775808
  %cv459 = zext i1 %cmp458 to i64
  store i64 %cv459, ptr %slot72, align 8
  %v460 = load i64, ptr %slot69, align 8
  %cmp461 = icmp eq i64 %v460, 18446744073709551615
  %cv462 = zext i1 %cmp461 to i64
  store i64 %cv462, ptr %slot73, align 8
  %v463 = load i64, ptr %slot72, align 8
  %v464 = load i64, ptr %slot73, align 8
  %op465 = and i64 %v463, %v464
  store i64 %op465, ptr %slot74, align 8
  %v466 = load i64, ptr %slot74, align 8
  %neg467 = sub i64 0, %v466
  store i64 %neg467, ptr %slot75, align 8
  %v468 = load i64, ptr %slot69, align 8
  %op469 = xor i64 %v468, 1
  store i64 %op469, ptr %slot76, align 8
  %v470 = load i64, ptr %slot76, align 8
  %v471 = load i64, ptr %slot75, align 8
  %op472 = and i64 %v470, %v471
  store i64 %op472, ptr %slot76, align 8
  %v473 = load i64, ptr %slot69, align 8
  %v474 = load i64, ptr %slot76, align 8
  %op475 = xor i64 %v473, %v474
  store i64 %op475, ptr %slot77, align 8
  %v476 = load i64, ptr %slot70, align 8
  %v477 = load i64, ptr %slot77, align 8
  %op478 = srem i64 %v476, %v477
  store i64 %op478, ptr %slot78, align 8
  %v479 = load i64, ptr %slot78, align 8
  %cmp480 = icmp ne i64 %v479, 0
  %cv481 = zext i1 %cmp480 to i64
  store i64 %cv481, ptr %slot79, align 8
  %v482 = load i64, ptr %slot78, align 8
  %v483 = load i64, ptr %slot77, align 8
  %op484 = xor i64 %v482, %v483
  store i64 %op484, ptr %slot80, align 8
  %v485 = load i64, ptr %slot80, align 8
  %cmp486 = icmp slt i64 %v485, 0
  %cv487 = zext i1 %cmp486 to i64
  store i64 %cv487, ptr %slot81, align 8
  %v488 = load i64, ptr %slot79, align 8
  %v489 = load i64, ptr %slot81, align 8
  %op490 = and i64 %v488, %v489
  store i64 %op490, ptr %slot82, align 8
  %v491 = load i64, ptr %slot82, align 8
  %neg492 = sub i64 0, %v491
  store i64 %neg492, ptr %slot83, align 8
  %v493 = load i64, ptr %slot77, align 8
  %v494 = load i64, ptr %slot83, align 8
  %op495 = and i64 %v493, %v494
  store i64 %op495, ptr %slot84, align 8
  %v496 = load i64, ptr %slot78, align 8
  %v497 = load i64, ptr %slot84, align 8
  %op498 = add i64 %v496, %v497
  store i64 %op498, ptr %slot78, align 8
  %v499 = load i64, ptr %slot78, align 8
  %floorbounded500 = icmp ult i64 %v499, 1000000007
  call void @llvm.assume(i1 %floorbounded500)
  %v501 = load i64, ptr %slot78, align 8
  %v502 = load i64, ptr %slot12, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot12, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot85, align 8
  %v507 = load i64, ptr %slot85, align 8
  %v508 = load i64, ptr %slot7, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot8, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot86, align 8
  %v513 = load i64, ptr %slot86, align 8
  %v514 = load i64, ptr %slot12, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 %v513, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot13, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i64 1, ptr %p517, align 8, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot13, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %ld520 = load i64, ptr %p519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld520, ptr %slot87, align 8
  %v521 = load i64, ptr %slot12, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i64, ptr %p522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld523, ptr %slot88, align 8
  %v524 = load i64, ptr %slot88, align 8
  %v525 = load i64, ptr %slot87, align 8
  %op526 = add i64 %v524, %v525
  store i64 %op526, ptr %slot89, align 8
  %v527 = load i64, ptr %slot89, align 8
  %v528 = load i64, ptr %slot12, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot12, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot90, align 8
  %v533 = load i64, ptr %slot90, align 8
  %v534 = load i64, ptr %slot8, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6, !llvm.loop !119
bb_oi6:
  %v536 = load i64, ptr %slot8, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot91, align 8
  %v539 = load i64, ptr %slot91, align 8
  %v540 = load i64, ptr %slot12, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot9, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot92, align 8
  %v545 = load i64, ptr %slot92, align 8
  %v546 = load i64, ptr %slot13, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot13, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i64, ptr %p549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld550, ptr %slot93, align 8
  %v551 = load i64, ptr %slot12, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i64, ptr %p552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld553, ptr %slot94, align 8
  %v554 = load i64, ptr %slot94, align 8
  %v555 = load i64, ptr %slot93, align 8
  %cmp556 = icmp slt i64 %v554, %v555
  %cv557 = zext i1 %cmp556 to i64
  store i64 %cv557, ptr %slot95, align 8
  %v558 = load i64, ptr %slot95, align 8
  %v559 = load i64, ptr %slot12, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i64 %v558, ptr %p560, align 8, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot12, align 8
  %p562 = inttoptr i64 %v561 to ptr
  %ld563 = load i64, ptr %p562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld563, ptr %slot96, align 8
  %v564 = load i64, ptr %slot96, align 8
  %cond565 = icmp ne i64 %v564, 0
  br i1 %cond565, label %bb_next83, label %bb_i34
bb_next83:
  %v566 = load i64, ptr %slot8, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot97, align 8
  %v569 = load i64, ptr %slot97, align 8
  %v570 = load i64, ptr %slot12, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i64 %v569, ptr %p571, align 8, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot13, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i64 2, ptr %p573, align 8, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot13, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i64, ptr %p575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot98, align 8
  %v577 = load i64, ptr %slot12, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot99, align 8
  %v580 = load i64, ptr %slot98, align 8
  %cmp581 = icmp eq i64 %v580, 0
  %cv582 = zext i1 %cmp581 to i64
  store i64 %cv582, ptr %slot100, align 8
  %v583 = load i64, ptr %slot100, align 8
  %cond584 = icmp ne i64 %v583, 0
  br i1 %cond584, label %bb_division86, label %bb_nonzero86
bb_division86:
  %v585 = load i64, ptr %slot1, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %v587 = load i64, ptr %slot99, align 8
  %v588 = load i64, ptr %slot98, align 8
  call void @myl_qbe_fail_division(ptr %p586, i64 6, i64 %v587, i64 %v588) nomerge, !dbg !110
  unreachable
bb_nonzero86:
  %v589 = load i64, ptr %slot99, align 8
  %cmp590 = icmp eq i64 %v589, 9223372036854775808
  %cv591 = zext i1 %cmp590 to i64
  store i64 %cv591, ptr %slot101, align 8
  %v592 = load i64, ptr %slot98, align 8
  %cmp593 = icmp eq i64 %v592, 18446744073709551615
  %cv594 = zext i1 %cmp593 to i64
  store i64 %cv594, ptr %slot102, align 8
  %v595 = load i64, ptr %slot101, align 8
  %v596 = load i64, ptr %slot102, align 8
  %op597 = and i64 %v595, %v596
  store i64 %op597, ptr %slot103, align 8
  %v598 = load i64, ptr %slot103, align 8
  %neg599 = sub i64 0, %v598
  store i64 %neg599, ptr %slot104, align 8
  %v600 = load i64, ptr %slot98, align 8
  %op601 = xor i64 %v600, 1
  store i64 %op601, ptr %slot105, align 8
  %v602 = load i64, ptr %slot105, align 8
  %v603 = load i64, ptr %slot104, align 8
  %op604 = and i64 %v602, %v603
  store i64 %op604, ptr %slot105, align 8
  %v605 = load i64, ptr %slot98, align 8
  %v606 = load i64, ptr %slot105, align 8
  %op607 = xor i64 %v605, %v606
  store i64 %op607, ptr %slot106, align 8
  %v608 = load i64, ptr %slot99, align 8
  %v609 = load i64, ptr %slot106, align 8
  %op610 = srem i64 %v608, %v609
  store i64 %op610, ptr %slot107, align 8
  %v611 = load i64, ptr %slot107, align 8
  %cmp612 = icmp ne i64 %v611, 0
  %cv613 = zext i1 %cmp612 to i64
  store i64 %cv613, ptr %slot108, align 8
  %v614 = load i64, ptr %slot107, align 8
  %v615 = load i64, ptr %slot106, align 8
  %op616 = xor i64 %v614, %v615
  store i64 %op616, ptr %slot109, align 8
  %v617 = load i64, ptr %slot109, align 8
  %cmp618 = icmp slt i64 %v617, 0
  %cv619 = zext i1 %cmp618 to i64
  store i64 %cv619, ptr %slot110, align 8
  %v620 = load i64, ptr %slot108, align 8
  %v621 = load i64, ptr %slot110, align 8
  %op622 = and i64 %v620, %v621
  store i64 %op622, ptr %slot111, align 8
  %v623 = load i64, ptr %slot111, align 8
  %neg624 = sub i64 0, %v623
  store i64 %neg624, ptr %slot112, align 8
  %v625 = load i64, ptr %slot106, align 8
  %v626 = load i64, ptr %slot112, align 8
  %op627 = and i64 %v625, %v626
  store i64 %op627, ptr %slot113, align 8
  %v628 = load i64, ptr %slot107, align 8
  %v629 = load i64, ptr %slot113, align 8
  %op630 = add i64 %v628, %v629
  store i64 %op630, ptr %slot107, align 8
  %v631 = load i64, ptr %slot107, align 8
  %floorbounded632 = icmp ult i64 %v631, 2
  call void @llvm.assume(i1 %floorbounded632)
  %v633 = load i64, ptr %slot107, align 8
  %v634 = load i64, ptr %slot12, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i64 %v633, ptr %p635, align 8, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot6, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot114, align 8
  %v639 = load i64, ptr %slot114, align 8
  %v640 = load i64, ptr %slot13, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i64 %v639, ptr %p641, align 8, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot13, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %ld644 = load i64, ptr %p643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld644, ptr %slot115, align 8
  %v645 = load i64, ptr %slot12, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i64, ptr %p646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld647, ptr %slot116, align 8
  %v648 = load i64, ptr %slot116, align 8
  %v649 = load i64, ptr %slot115, align 8
  %cmp650 = icmp eq i64 %v648, %v649
  %cv651 = zext i1 %cmp650 to i64
  store i64 %cv651, ptr %slot117, align 8
  %v652 = load i64, ptr %slot117, align 8
  %v653 = load i64, ptr %slot12, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i64 %v652, ptr %p654, align 8, !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot12, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld657, ptr %slot118, align 8
  %v658 = load i64, ptr %slot118, align 8
  %cond659 = icmp ne i64 %v658, 0
  br i1 %cond659, label %bb_next105, label %bb_i19
bb_next105:
  %v660 = load i64, ptr %slot12, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i64 1, ptr %p661, align 8, !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot12, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %ld664 = load i64, ptr %p663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld664, ptr %slot119, align 8
  %v665 = load i64, ptr %slot119, align 8
  %v666 = load i64, ptr %slot10, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i64 %v665, ptr %p667, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v668 = load i64, ptr %slot12, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 0, ptr %p669, align 8, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot12, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot120, align 8
  %v673 = load i64, ptr %slot120, align 8
  %v674 = load i64, ptr %slot10, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v676 = load i64, ptr %slot10, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot121, align 8
  %v679 = load i64, ptr %slot121, align 8
  %v680 = load i64, ptr %slot12, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot12, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot122, align 8
  %v685 = load i64, ptr %slot122, align 8
  %v686 = load i64, ptr %slot11, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot7, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot123, align 8
  %v691 = load i64, ptr %slot123, align 8
  %v692 = load i64, ptr %slot12, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot11, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot124, align 8
  %v697 = load i64, ptr %slot124, align 8
  %v698 = load i64, ptr %slot13, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i64 %v697, ptr %p699, align 8, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot13, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot125, align 8
  %v703 = load i64, ptr %slot12, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i64, ptr %p704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld705, ptr %slot126, align 8
  %v706 = load i64, ptr %slot126, align 8
  %v707 = load i64, ptr %slot125, align 8
  %ovpair709 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v706, i64 %v707)
  %op708 = extractvalue { i64, i1 } %ovpair709, 0
  %ov710 = extractvalue { i64, i1 } %ovpair709, 1
  store i64 %op708, ptr %slot127, align 8
  %v711 = load i64, ptr %slot126, align 8
  %v712 = load i64, ptr %slot127, align 8
  %op713 = xor i64 %v711, %v712
  store i64 %op713, ptr %slot128, align 8
  %v714 = load i64, ptr %slot125, align 8
  %v715 = load i64, ptr %slot127, align 8
  %op716 = xor i64 %v714, %v715
  store i64 %op716, ptr %slot129, align 8
  %v717 = load i64, ptr %slot128, align 8
  %v718 = load i64, ptr %slot129, align 8
  %op719 = and i64 %v717, %v718
  store i64 %op719, ptr %slot130, align 8
  %cv720 = zext i1 %ov710 to i64
  store i64 %cv720, ptr %slot131, align 8
  %v721 = load i64, ptr %slot131, align 8
  %cond722 = icmp ne i64 %v721, 0
  br i1 %cond722, label %bb_overflow113, label %bb_checked113
bb_overflow113:
  %v723 = load i64, ptr %slot1, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %v725 = load i64, ptr %slot126, align 8
  %v726 = load i64, ptr %slot125, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p724, i64 0, i64 %v725, i64 %v726, i64 64) nomerge, !dbg !112
  unreachable
bb_checked113:
  %v727 = load i64, ptr %slot127, align 8
  %v728 = load i64, ptr %slot12, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i64 %v727, ptr %p729, align 8, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot13, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i64 1000000007, ptr %p731, align 8, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot13, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot132, align 8
  %v735 = load i64, ptr %slot12, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot133, align 8
  %v738 = load i64, ptr %slot132, align 8
  %cmp739 = icmp eq i64 %v738, 0
  %cv740 = zext i1 %cmp739 to i64
  store i64 %cv740, ptr %slot134, align 8
  %v741 = load i64, ptr %slot134, align 8
  %cond742 = icmp ne i64 %v741, 0
  br i1 %cond742, label %bb_division120, label %bb_nonzero120
bb_division120:
  %v743 = load i64, ptr %slot1, align 8
  %p744 = inttoptr i64 %v743 to ptr
  %v745 = load i64, ptr %slot133, align 8
  %v746 = load i64, ptr %slot132, align 8
  call void @myl_qbe_fail_division(ptr %p744, i64 6, i64 %v745, i64 %v746) nomerge, !dbg !114
  unreachable
bb_nonzero120:
  %v747 = load i64, ptr %slot133, align 8
  %cmp748 = icmp eq i64 %v747, 9223372036854775808
  %cv749 = zext i1 %cmp748 to i64
  store i64 %cv749, ptr %slot135, align 8
  %v750 = load i64, ptr %slot132, align 8
  %cmp751 = icmp eq i64 %v750, 18446744073709551615
  %cv752 = zext i1 %cmp751 to i64
  store i64 %cv752, ptr %slot136, align 8
  %v753 = load i64, ptr %slot135, align 8
  %v754 = load i64, ptr %slot136, align 8
  %op755 = and i64 %v753, %v754
  store i64 %op755, ptr %slot137, align 8
  %v756 = load i64, ptr %slot137, align 8
  %neg757 = sub i64 0, %v756
  store i64 %neg757, ptr %slot138, align 8
  %v758 = load i64, ptr %slot132, align 8
  %op759 = xor i64 %v758, 1
  store i64 %op759, ptr %slot139, align 8
  %v760 = load i64, ptr %slot139, align 8
  %v761 = load i64, ptr %slot138, align 8
  %op762 = and i64 %v760, %v761
  store i64 %op762, ptr %slot139, align 8
  %v763 = load i64, ptr %slot132, align 8
  %v764 = load i64, ptr %slot139, align 8
  %op765 = xor i64 %v763, %v764
  store i64 %op765, ptr %slot140, align 8
  %v766 = load i64, ptr %slot133, align 8
  %v767 = load i64, ptr %slot140, align 8
  %op768 = srem i64 %v766, %v767
  store i64 %op768, ptr %slot141, align 8
  %v769 = load i64, ptr %slot141, align 8
  %cmp770 = icmp ne i64 %v769, 0
  %cv771 = zext i1 %cmp770 to i64
  store i64 %cv771, ptr %slot142, align 8
  %v772 = load i64, ptr %slot141, align 8
  %v773 = load i64, ptr %slot140, align 8
  %op774 = xor i64 %v772, %v773
  store i64 %op774, ptr %slot143, align 8
  %v775 = load i64, ptr %slot143, align 8
  %cmp776 = icmp slt i64 %v775, 0
  %cv777 = zext i1 %cmp776 to i64
  store i64 %cv777, ptr %slot144, align 8
  %v778 = load i64, ptr %slot142, align 8
  %v779 = load i64, ptr %slot144, align 8
  %op780 = and i64 %v778, %v779
  store i64 %op780, ptr %slot145, align 8
  %v781 = load i64, ptr %slot145, align 8
  %neg782 = sub i64 0, %v781
  store i64 %neg782, ptr %slot146, align 8
  %v783 = load i64, ptr %slot140, align 8
  %v784 = load i64, ptr %slot146, align 8
  %op785 = and i64 %v783, %v784
  store i64 %op785, ptr %slot147, align 8
  %v786 = load i64, ptr %slot141, align 8
  %v787 = load i64, ptr %slot147, align 8
  %op788 = add i64 %v786, %v787
  store i64 %op788, ptr %slot141, align 8
  %v789 = load i64, ptr %slot141, align 8
  %floorbounded790 = icmp ult i64 %v789, 1000000007
  call void @llvm.assume(i1 %floorbounded790)
  %v791 = load i64, ptr %slot141, align 8
  %v792 = load i64, ptr %slot12, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 %v791, ptr %p793, align 8, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot12, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld796, ptr %slot148, align 8
  %v797 = load i64, ptr %slot148, align 8
  %v798 = load i64, ptr %slot7, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot8, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot149, align 8
  %v803 = load i64, ptr %slot149, align 8
  %v804 = load i64, ptr %slot12, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i64 %v803, ptr %p805, align 8, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot13, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i64 1, ptr %p807, align 8, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot13, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot150, align 8
  %v811 = load i64, ptr %slot12, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i64, ptr %p812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld813, ptr %slot151, align 8
  %v814 = load i64, ptr %slot151, align 8
  %v815 = load i64, ptr %slot150, align 8
  %op816 = add i64 %v814, %v815
  %ovpair817 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v814, i64 %v815)
  %ov818 = extractvalue { i64, i1 } %ovpair817, 1
  store i64 %op816, ptr %slot152, align 8
  %cv819 = zext i1 %ov818 to i64
  store i64 %cv819, ptr %slot153, align 8
  %v820 = load i64, ptr %slot153, align 8
  %cond821 = icmp ne i64 %v820, 0
  br i1 %cond821, label %bb_overflow138, label %bb_checked138
bb_overflow138:
  %v822 = load i64, ptr %slot1, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %v824 = load i64, ptr %slot151, align 8
  %v825 = load i64, ptr %slot150, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p823, i64 0, i64 %v824, i64 %v825, i64 64) nomerge, !dbg !116
  unreachable
bb_checked138:
  %v826 = load i64, ptr %slot152, align 8
  %v827 = load i64, ptr %slot12, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i64 %v826, ptr %p828, align 8, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot12, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i64, ptr %p830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld831, ptr %slot154, align 8
  %v832 = load i64, ptr %slot154, align 8
  %v833 = load i64, ptr %slot8, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i64 %v832, ptr %p834, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6, !llvm.loop !120
bb_i34:
  %v835 = load i64, ptr %slot7, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i64, ptr %p836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld837, ptr %slot155, align 8
  %v838 = load i64, ptr %slot155, align 8
  %v839 = load i64, ptr %slot12, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i64 %v838, ptr %p840, align 8, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot12, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i64, ptr %p842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld843, ptr %slot156, align 8
  %v844 = load i64, ptr %slot156, align 8
  ret i64 %v844
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.assume(i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", linkageName: "myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7472279511045523184, i64 0, !"myl_f_c974646b46cb725e23c81e7566898c1450a1493f88a71e8f70f1ba253e28cc22"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
!118 = !{!"llvm.loop.align", i32 32}
!119 = distinct !{!119, !118}
!120 = distinct !{!120, !118}
