target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v160 = load i64, ptr %slot1, align 8
  %op161 = add i64 %v160, 32
  store i64 %op161, ptr %slot5, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot6, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot7, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot8, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot9, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot10, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot11, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot12, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot13, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot14, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot15, align 8
  %v182 = load i64, ptr %slot2, align 8
  %v183 = load i64, ptr %slot6, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot3, align 8
  %v186 = load i64, ptr %slot7, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot4, align 8
  %v189 = load i64, ptr %slot8, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot16, align 8
  %v194 = load i64, ptr %slot16, align 8
  %v195 = load i64, ptr %slot14, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot14, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot17, align 8
  %v200 = load i64, ptr %slot17, align 8
  %v201 = load i64, ptr %slot9, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot14, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot14, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot18, align 8
  %v208 = load i64, ptr %slot18, align 8
  %v209 = load i64, ptr %slot10, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot7, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot19, align 8
  %v214 = load i64, ptr %slot19, align 8
  %v215 = load i64, ptr %slot14, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot14, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot20, align 8
  %v220 = load i64, ptr %slot20, align 8
  %v221 = load i64, ptr %slot11, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 %v220, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot10, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i64, ptr %p224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot21, align 8
  %v226 = load i64, ptr %slot11, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot22, align 8
  %v229 = load i64, ptr %slot22, align 8
  %v230 = load i64, ptr %slot21, align 8
  %cmp231 = icmp sgt i64 %v229, %v230
  %cv232 = zext i1 %cmp231 to i64
  store i64 %cv232, ptr %slot23, align 8
  %v233 = load i64, ptr %slot22, align 8
  %v234 = load i64, ptr %slot21, align 8
  %op235 = sub i64 %v233, %v234
  store i64 %op235, ptr %slot24, align 8
  %v236 = load i64, ptr %slot24, align 8
  %cmp237 = icmp uge i64 %v236, 16
  %cv238 = zext i1 %cmp237 to i64
  store i64 %cv238, ptr %slot25, align 8
  %v239 = load i64, ptr %slot23, align 8
  %v240 = load i64, ptr %slot25, align 8
  %op241 = and i64 %v239, %v240
  store i64 %op241, ptr %slot26, align 8
  %v242 = load i64, ptr %slot26, align 8
  %cond243 = icmp ne i64 %v242, 0
  br i1 %cond243, label %bb_guard5, label %bb_oi6
bb_guard5:
  %v244 = load i64, ptr %slot21, align 8
  %op245 = add i64 %v244, 1152921504606846976
  store i64 %op245, ptr %slot27, align 8
  %v246 = load i64, ptr %slot27, align 8
  %cmp247 = icmp ule i64 %v246, 2305843009213693952
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot28, align 8
  %v249 = load i64, ptr %slot28, align 8
  %cond250 = icmp ne i64 %v249, 0
  br i1 %cond250, label %bb_guard11, label %bb_oi6
bb_guard11:
  %v251 = load i64, ptr %slot22, align 8
  %op252 = add i64 %v251, 1152921504606846976
  store i64 %op252, ptr %slot29, align 8
  %v253 = load i64, ptr %slot29, align 8
  %cmp254 = icmp ule i64 %v253, 2305843009213693952
  %cv255 = zext i1 %cmp254 to i64
  store i64 %cv255, ptr %slot30, align 8
  %v256 = load i64, ptr %slot30, align 8
  %cond257 = icmp ne i64 %v256, 0
  br i1 %cond257, label %bb_guard13, label %bb_oi6
bb_guard13:
  br label %bb_fi6
bb_fi6:
  %v258 = load i64, ptr %slot10, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot31, align 8
  %v261 = load i64, ptr %slot31, align 8
  %v262 = load i64, ptr %slot14, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot11, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot32, align 8
  %v267 = load i64, ptr %slot32, align 8
  %v268 = load i64, ptr %slot15, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot15, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot33, align 8
  %v273 = load i64, ptr %slot14, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot34, align 8
  %v276 = load i64, ptr %slot34, align 8
  %v277 = load i64, ptr %slot33, align 8
  %cmp278 = icmp slt i64 %v276, %v277
  %cv279 = zext i1 %cmp278 to i64
  store i64 %cv279, ptr %slot35, align 8
  %v280 = load i64, ptr %slot35, align 8
  %v281 = load i64, ptr %slot14, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 %v280, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot14, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot36, align 8
  %v286 = load i64, ptr %slot36, align 8
  %cond287 = icmp ne i64 %v286, 0
  br i1 %cond287, label %bb_next21, label %bb_i34
bb_next21:
  %v288 = load i64, ptr %slot10, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot37, align 8
  %v291 = load i64, ptr %slot37, align 8
  %v292 = load i64, ptr %slot14, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot15, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 2, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot15, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot38, align 8
  %v299 = load i64, ptr %slot14, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot39, align 8
  %v302 = load i64, ptr %slot38, align 8
  %cmp303 = icmp eq i64 %v302, 0
  %cv304 = zext i1 %cmp303 to i64
  store i64 %cv304, ptr %slot40, align 8
  %v305 = load i64, ptr %slot40, align 8
  %cond306 = icmp ne i64 %v305, 0
  br i1 %cond306, label %bb_division24, label %bb_nonzero24
bb_division24:
  %v307 = load i64, ptr %slot1, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %v309 = load i64, ptr %slot39, align 8
  %v310 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_division(ptr %p308, i64 6, i64 %v309, i64 %v310) nomerge, !dbg !110
  unreachable
bb_nonzero24:
  %v311 = load i64, ptr %slot39, align 8
  %cmp312 = icmp eq i64 %v311, 9223372036854775808
  %cv313 = zext i1 %cmp312 to i64
  store i64 %cv313, ptr %slot41, align 8
  %v314 = load i64, ptr %slot38, align 8
  %cmp315 = icmp eq i64 %v314, 18446744073709551615
  %cv316 = zext i1 %cmp315 to i64
  store i64 %cv316, ptr %slot42, align 8
  %v317 = load i64, ptr %slot41, align 8
  %v318 = load i64, ptr %slot42, align 8
  %op319 = and i64 %v317, %v318
  store i64 %op319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot43, align 8
  %neg321 = sub i64 0, %v320
  store i64 %neg321, ptr %slot44, align 8
  %v322 = load i64, ptr %slot38, align 8
  %op323 = xor i64 %v322, 1
  store i64 %op323, ptr %slot45, align 8
  %v324 = load i64, ptr %slot45, align 8
  %v325 = load i64, ptr %slot44, align 8
  %op326 = and i64 %v324, %v325
  store i64 %op326, ptr %slot45, align 8
  %v327 = load i64, ptr %slot38, align 8
  %v328 = load i64, ptr %slot45, align 8
  %op329 = xor i64 %v327, %v328
  store i64 %op329, ptr %slot46, align 8
  %v330 = load i64, ptr %slot39, align 8
  %v331 = load i64, ptr %slot46, align 8
  %op332 = srem i64 %v330, %v331
  store i64 %op332, ptr %slot47, align 8
  %v333 = load i64, ptr %slot47, align 8
  %cmp334 = icmp ne i64 %v333, 0
  %cv335 = zext i1 %cmp334 to i64
  store i64 %cv335, ptr %slot48, align 8
  %v336 = load i64, ptr %slot47, align 8
  %v337 = load i64, ptr %slot46, align 8
  %op338 = xor i64 %v336, %v337
  store i64 %op338, ptr %slot49, align 8
  %v339 = load i64, ptr %slot49, align 8
  %cmp340 = icmp slt i64 %v339, 0
  %cv341 = zext i1 %cmp340 to i64
  store i64 %cv341, ptr %slot50, align 8
  %v342 = load i64, ptr %slot48, align 8
  %v343 = load i64, ptr %slot50, align 8
  %op344 = and i64 %v342, %v343
  store i64 %op344, ptr %slot51, align 8
  %v345 = load i64, ptr %slot51, align 8
  %neg346 = sub i64 0, %v345
  store i64 %neg346, ptr %slot52, align 8
  %v347 = load i64, ptr %slot46, align 8
  %v348 = load i64, ptr %slot52, align 8
  %op349 = and i64 %v347, %v348
  store i64 %op349, ptr %slot53, align 8
  %v350 = load i64, ptr %slot47, align 8
  %v351 = load i64, ptr %slot53, align 8
  %op352 = add i64 %v350, %v351
  store i64 %op352, ptr %slot47, align 8
  %v353 = load i64, ptr %slot47, align 8
  %v354 = load i64, ptr %slot14, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 %v353, ptr %p355, align 8, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot8, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot54, align 8
  %v359 = load i64, ptr %slot54, align 8
  %v360 = load i64, ptr %slot15, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot15, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i64, ptr %p363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld364, ptr %slot55, align 8
  %v365 = load i64, ptr %slot14, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld367, ptr %slot56, align 8
  %v368 = load i64, ptr %slot56, align 8
  %v369 = load i64, ptr %slot55, align 8
  %cmp370 = icmp eq i64 %v368, %v369
  %cv371 = zext i1 %cmp370 to i64
  store i64 %cv371, ptr %slot57, align 8
  %v372 = load i64, ptr %slot57, align 8
  %v373 = load i64, ptr %slot14, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i64 %v372, ptr %p374, align 8, !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot14, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %ld377 = load i64, ptr %p376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld377, ptr %slot58, align 8
  %v378 = load i64, ptr %slot58, align 8
  %cond379 = icmp ne i64 %v378, 0
  br i1 %cond379, label %bb_next43, label %bb_fi19
bb_next43:
  %v380 = load i64, ptr %slot14, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 1, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot14, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot59, align 8
  %v385 = load i64, ptr %slot59, align 8
  %v386 = load i64, ptr %slot12, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi19:
  %v388 = load i64, ptr %slot14, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 0, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot14, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot60, align 8
  %v393 = load i64, ptr %slot60, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi21
bb_fi21:
  %v396 = load i64, ptr %slot12, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot61, align 8
  %v399 = load i64, ptr %slot61, align 8
  %v400 = load i64, ptr %slot14, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot14, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot62, align 8
  %v405 = load i64, ptr %slot62, align 8
  %v406 = load i64, ptr %slot13, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot9, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot63, align 8
  %v411 = load i64, ptr %slot63, align 8
  %v412 = load i64, ptr %slot14, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot13, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot64, align 8
  %v417 = load i64, ptr %slot64, align 8
  %v418 = load i64, ptr %slot15, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot15, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot65, align 8
  %v423 = load i64, ptr %slot14, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot66, align 8
  %v426 = load i64, ptr %slot66, align 8
  %v427 = load i64, ptr %slot65, align 8
  %ovpair429 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v426, i64 %v427)
  %op428 = extractvalue { i64, i1 } %ovpair429, 0
  %ov430 = extractvalue { i64, i1 } %ovpair429, 1
  store i64 %op428, ptr %slot67, align 8
  %v431 = load i64, ptr %slot66, align 8
  %v432 = load i64, ptr %slot67, align 8
  %op433 = xor i64 %v431, %v432
  store i64 %op433, ptr %slot68, align 8
  %v434 = load i64, ptr %slot65, align 8
  %v435 = load i64, ptr %slot67, align 8
  %op436 = xor i64 %v434, %v435
  store i64 %op436, ptr %slot69, align 8
  %v437 = load i64, ptr %slot68, align 8
  %v438 = load i64, ptr %slot69, align 8
  %op439 = and i64 %v437, %v438
  store i64 %op439, ptr %slot70, align 8
  %cv440 = zext i1 %ov430 to i64
  store i64 %cv440, ptr %slot71, align 8
  %v441 = load i64, ptr %slot71, align 8
  %cond442 = icmp ne i64 %v441, 0
  br i1 %cond442, label %bb_overflow51, label %bb_checked51
bb_overflow51:
  %v443 = load i64, ptr %slot1, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %v445 = load i64, ptr %slot66, align 8
  %v446 = load i64, ptr %slot65, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p444, i64 0, i64 %v445, i64 %v446, i64 64) nomerge, !dbg !112
  unreachable
bb_checked51:
  %v447 = load i64, ptr %slot67, align 8
  %v448 = load i64, ptr %slot14, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 %v447, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot15, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 1000000007, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot15, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot72, align 8
  %v455 = load i64, ptr %slot14, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot73, align 8
  %v458 = load i64, ptr %slot72, align 8
  %cmp459 = icmp eq i64 %v458, 0
  %cv460 = zext i1 %cmp459 to i64
  store i64 %cv460, ptr %slot74, align 8
  %v461 = load i64, ptr %slot74, align 8
  %cond462 = icmp ne i64 %v461, 0
  br i1 %cond462, label %bb_division58, label %bb_nonzero58
bb_division58:
  %v463 = load i64, ptr %slot1, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %v465 = load i64, ptr %slot73, align 8
  %v466 = load i64, ptr %slot72, align 8
  call void @myl_qbe_fail_division(ptr %p464, i64 6, i64 %v465, i64 %v466) nomerge, !dbg !114
  unreachable
bb_nonzero58:
  %v467 = load i64, ptr %slot73, align 8
  %cmp468 = icmp eq i64 %v467, 9223372036854775808
  %cv469 = zext i1 %cmp468 to i64
  store i64 %cv469, ptr %slot75, align 8
  %v470 = load i64, ptr %slot72, align 8
  %cmp471 = icmp eq i64 %v470, 18446744073709551615
  %cv472 = zext i1 %cmp471 to i64
  store i64 %cv472, ptr %slot76, align 8
  %v473 = load i64, ptr %slot75, align 8
  %v474 = load i64, ptr %slot76, align 8
  %op475 = and i64 %v473, %v474
  store i64 %op475, ptr %slot77, align 8
  %v476 = load i64, ptr %slot77, align 8
  %neg477 = sub i64 0, %v476
  store i64 %neg477, ptr %slot78, align 8
  %v478 = load i64, ptr %slot72, align 8
  %op479 = xor i64 %v478, 1
  store i64 %op479, ptr %slot79, align 8
  %v480 = load i64, ptr %slot79, align 8
  %v481 = load i64, ptr %slot78, align 8
  %op482 = and i64 %v480, %v481
  store i64 %op482, ptr %slot79, align 8
  %v483 = load i64, ptr %slot72, align 8
  %v484 = load i64, ptr %slot79, align 8
  %op485 = xor i64 %v483, %v484
  store i64 %op485, ptr %slot80, align 8
  %v486 = load i64, ptr %slot73, align 8
  %v487 = load i64, ptr %slot80, align 8
  %op488 = srem i64 %v486, %v487
  store i64 %op488, ptr %slot81, align 8
  %v489 = load i64, ptr %slot81, align 8
  %cmp490 = icmp ne i64 %v489, 0
  %cv491 = zext i1 %cmp490 to i64
  store i64 %cv491, ptr %slot82, align 8
  %v492 = load i64, ptr %slot81, align 8
  %v493 = load i64, ptr %slot80, align 8
  %op494 = xor i64 %v492, %v493
  store i64 %op494, ptr %slot83, align 8
  %v495 = load i64, ptr %slot83, align 8
  %cmp496 = icmp slt i64 %v495, 0
  %cv497 = zext i1 %cmp496 to i64
  store i64 %cv497, ptr %slot84, align 8
  %v498 = load i64, ptr %slot82, align 8
  %v499 = load i64, ptr %slot84, align 8
  %op500 = and i64 %v498, %v499
  store i64 %op500, ptr %slot85, align 8
  %v501 = load i64, ptr %slot85, align 8
  %neg502 = sub i64 0, %v501
  store i64 %neg502, ptr %slot86, align 8
  %v503 = load i64, ptr %slot80, align 8
  %v504 = load i64, ptr %slot86, align 8
  %op505 = and i64 %v503, %v504
  store i64 %op505, ptr %slot87, align 8
  %v506 = load i64, ptr %slot81, align 8
  %v507 = load i64, ptr %slot87, align 8
  %op508 = add i64 %v506, %v507
  store i64 %op508, ptr %slot81, align 8
  %v509 = load i64, ptr %slot81, align 8
  %v510 = load i64, ptr %slot14, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i64 %v509, ptr %p511, align 8, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot14, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %ld514 = load i64, ptr %p513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld514, ptr %slot88, align 8
  %v515 = load i64, ptr %slot88, align 8
  %v516 = load i64, ptr %slot9, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i64 %v515, ptr %p517, align 8, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot10, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %ld520 = load i64, ptr %p519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld520, ptr %slot89, align 8
  %v521 = load i64, ptr %slot89, align 8
  %v522 = load i64, ptr %slot14, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i64 %v521, ptr %p523, align 8, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot15, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 1, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot15, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot90, align 8
  %v529 = load i64, ptr %slot14, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ld531 = load i64, ptr %p530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld531, ptr %slot91, align 8
  %v532 = load i64, ptr %slot91, align 8
  %v533 = load i64, ptr %slot90, align 8
  %op534 = add i64 %v532, %v533
  store i64 %op534, ptr %slot92, align 8
  %v535 = load i64, ptr %slot92, align 8
  %v536 = load i64, ptr %slot14, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 %v535, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot14, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot93, align 8
  %v541 = load i64, ptr %slot93, align 8
  %v542 = load i64, ptr %slot10, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  br label %bb_fi6
bb_oi6:
  %v544 = load i64, ptr %slot10, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot94, align 8
  %v547 = load i64, ptr %slot94, align 8
  %v548 = load i64, ptr %slot14, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 %v547, ptr %p549, align 8, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot11, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot95, align 8
  %v553 = load i64, ptr %slot95, align 8
  %v554 = load i64, ptr %slot15, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i64 %v553, ptr %p555, align 8, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot15, align 8
  %p557 = inttoptr i64 %v556 to ptr
  %ld558 = load i64, ptr %p557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld558, ptr %slot96, align 8
  %v559 = load i64, ptr %slot14, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %ld561 = load i64, ptr %p560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld561, ptr %slot97, align 8
  %v562 = load i64, ptr %slot97, align 8
  %v563 = load i64, ptr %slot96, align 8
  %cmp564 = icmp slt i64 %v562, %v563
  %cv565 = zext i1 %cmp564 to i64
  store i64 %cv565, ptr %slot98, align 8
  %v566 = load i64, ptr %slot98, align 8
  %v567 = load i64, ptr %slot14, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot14, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot99, align 8
  %v572 = load i64, ptr %slot99, align 8
  %cond573 = icmp ne i64 %v572, 0
  br i1 %cond573, label %bb_next84, label %bb_i34
bb_next84:
  %v574 = load i64, ptr %slot10, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i64, ptr %p575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot100, align 8
  %v577 = load i64, ptr %slot100, align 8
  %v578 = load i64, ptr %slot14, align 8
  %p579 = inttoptr i64 %v578 to ptr
  store i64 %v577, ptr %p579, align 8, !alias.scope !3, !noalias !4
  %v580 = load i64, ptr %slot15, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 2, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot15, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld584, ptr %slot101, align 8
  %v585 = load i64, ptr %slot14, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot102, align 8
  %v588 = load i64, ptr %slot101, align 8
  %cmp589 = icmp eq i64 %v588, 0
  %cv590 = zext i1 %cmp589 to i64
  store i64 %cv590, ptr %slot103, align 8
  %v591 = load i64, ptr %slot103, align 8
  %cond592 = icmp ne i64 %v591, 0
  br i1 %cond592, label %bb_division87, label %bb_nonzero87
bb_division87:
  %v593 = load i64, ptr %slot1, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %v595 = load i64, ptr %slot102, align 8
  %v596 = load i64, ptr %slot101, align 8
  call void @myl_qbe_fail_division(ptr %p594, i64 6, i64 %v595, i64 %v596) nomerge, !dbg !110
  unreachable
bb_nonzero87:
  %v597 = load i64, ptr %slot102, align 8
  %cmp598 = icmp eq i64 %v597, 9223372036854775808
  %cv599 = zext i1 %cmp598 to i64
  store i64 %cv599, ptr %slot104, align 8
  %v600 = load i64, ptr %slot101, align 8
  %cmp601 = icmp eq i64 %v600, 18446744073709551615
  %cv602 = zext i1 %cmp601 to i64
  store i64 %cv602, ptr %slot105, align 8
  %v603 = load i64, ptr %slot104, align 8
  %v604 = load i64, ptr %slot105, align 8
  %op605 = and i64 %v603, %v604
  store i64 %op605, ptr %slot106, align 8
  %v606 = load i64, ptr %slot106, align 8
  %neg607 = sub i64 0, %v606
  store i64 %neg607, ptr %slot107, align 8
  %v608 = load i64, ptr %slot101, align 8
  %op609 = xor i64 %v608, 1
  store i64 %op609, ptr %slot108, align 8
  %v610 = load i64, ptr %slot108, align 8
  %v611 = load i64, ptr %slot107, align 8
  %op612 = and i64 %v610, %v611
  store i64 %op612, ptr %slot108, align 8
  %v613 = load i64, ptr %slot101, align 8
  %v614 = load i64, ptr %slot108, align 8
  %op615 = xor i64 %v613, %v614
  store i64 %op615, ptr %slot109, align 8
  %v616 = load i64, ptr %slot102, align 8
  %v617 = load i64, ptr %slot109, align 8
  %op618 = srem i64 %v616, %v617
  store i64 %op618, ptr %slot110, align 8
  %v619 = load i64, ptr %slot110, align 8
  %cmp620 = icmp ne i64 %v619, 0
  %cv621 = zext i1 %cmp620 to i64
  store i64 %cv621, ptr %slot111, align 8
  %v622 = load i64, ptr %slot110, align 8
  %v623 = load i64, ptr %slot109, align 8
  %op624 = xor i64 %v622, %v623
  store i64 %op624, ptr %slot112, align 8
  %v625 = load i64, ptr %slot112, align 8
  %cmp626 = icmp slt i64 %v625, 0
  %cv627 = zext i1 %cmp626 to i64
  store i64 %cv627, ptr %slot113, align 8
  %v628 = load i64, ptr %slot111, align 8
  %v629 = load i64, ptr %slot113, align 8
  %op630 = and i64 %v628, %v629
  store i64 %op630, ptr %slot114, align 8
  %v631 = load i64, ptr %slot114, align 8
  %neg632 = sub i64 0, %v631
  store i64 %neg632, ptr %slot115, align 8
  %v633 = load i64, ptr %slot109, align 8
  %v634 = load i64, ptr %slot115, align 8
  %op635 = and i64 %v633, %v634
  store i64 %op635, ptr %slot116, align 8
  %v636 = load i64, ptr %slot110, align 8
  %v637 = load i64, ptr %slot116, align 8
  %op638 = add i64 %v636, %v637
  store i64 %op638, ptr %slot110, align 8
  %v639 = load i64, ptr %slot110, align 8
  %v640 = load i64, ptr %slot14, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i64 %v639, ptr %p641, align 8, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot8, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %ld644 = load i64, ptr %p643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld644, ptr %slot117, align 8
  %v645 = load i64, ptr %slot117, align 8
  %v646 = load i64, ptr %slot15, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i64 %v645, ptr %p647, align 8, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot15, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot118, align 8
  %v651 = load i64, ptr %slot14, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot119, align 8
  %v654 = load i64, ptr %slot119, align 8
  %v655 = load i64, ptr %slot118, align 8
  %cmp656 = icmp eq i64 %v654, %v655
  %cv657 = zext i1 %cmp656 to i64
  store i64 %cv657, ptr %slot120, align 8
  %v658 = load i64, ptr %slot120, align 8
  %v659 = load i64, ptr %slot14, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i64 %v658, ptr %p660, align 8, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot14, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i64, ptr %p662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld663, ptr %slot121, align 8
  %v664 = load i64, ptr %slot121, align 8
  %cond665 = icmp ne i64 %v664, 0
  br i1 %cond665, label %bb_next106, label %bb_i19
bb_next106:
  %v666 = load i64, ptr %slot14, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i64 1, ptr %p667, align 8, !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot14, align 8
  %p669 = inttoptr i64 %v668 to ptr
  %ld670 = load i64, ptr %p669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld670, ptr %slot122, align 8
  %v671 = load i64, ptr %slot122, align 8
  %v672 = load i64, ptr %slot12, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i64 %v671, ptr %p673, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i19:
  %v674 = load i64, ptr %slot14, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 0, ptr %p675, align 8, !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot14, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot123, align 8
  %v679 = load i64, ptr %slot123, align 8
  %v680 = load i64, ptr %slot12, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v682 = load i64, ptr %slot12, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot124, align 8
  %v685 = load i64, ptr %slot124, align 8
  %v686 = load i64, ptr %slot14, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot14, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot125, align 8
  %v691 = load i64, ptr %slot125, align 8
  %v692 = load i64, ptr %slot13, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot9, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot126, align 8
  %v697 = load i64, ptr %slot126, align 8
  %v698 = load i64, ptr %slot14, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i64 %v697, ptr %p699, align 8, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot13, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot127, align 8
  %v703 = load i64, ptr %slot127, align 8
  %v704 = load i64, ptr %slot15, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot15, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i64, ptr %p707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot128, align 8
  %v709 = load i64, ptr %slot14, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %ld711 = load i64, ptr %p710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld711, ptr %slot129, align 8
  %v712 = load i64, ptr %slot129, align 8
  %v713 = load i64, ptr %slot128, align 8
  %ovpair715 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v712, i64 %v713)
  %op714 = extractvalue { i64, i1 } %ovpair715, 0
  %ov716 = extractvalue { i64, i1 } %ovpair715, 1
  store i64 %op714, ptr %slot130, align 8
  %v717 = load i64, ptr %slot129, align 8
  %v718 = load i64, ptr %slot130, align 8
  %op719 = xor i64 %v717, %v718
  store i64 %op719, ptr %slot131, align 8
  %v720 = load i64, ptr %slot128, align 8
  %v721 = load i64, ptr %slot130, align 8
  %op722 = xor i64 %v720, %v721
  store i64 %op722, ptr %slot132, align 8
  %v723 = load i64, ptr %slot131, align 8
  %v724 = load i64, ptr %slot132, align 8
  %op725 = and i64 %v723, %v724
  store i64 %op725, ptr %slot133, align 8
  %cv726 = zext i1 %ov716 to i64
  store i64 %cv726, ptr %slot134, align 8
  %v727 = load i64, ptr %slot134, align 8
  %cond728 = icmp ne i64 %v727, 0
  br i1 %cond728, label %bb_overflow114, label %bb_checked114
bb_overflow114:
  %v729 = load i64, ptr %slot1, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %v731 = load i64, ptr %slot129, align 8
  %v732 = load i64, ptr %slot128, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p730, i64 0, i64 %v731, i64 %v732, i64 64) nomerge, !dbg !112
  unreachable
bb_checked114:
  %v733 = load i64, ptr %slot130, align 8
  %v734 = load i64, ptr %slot14, align 8
  %p735 = inttoptr i64 %v734 to ptr
  store i64 %v733, ptr %p735, align 8, !alias.scope !3, !noalias !4
  %v736 = load i64, ptr %slot15, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i64 1000000007, ptr %p737, align 8, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot15, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot135, align 8
  %v741 = load i64, ptr %slot14, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld743, ptr %slot136, align 8
  %v744 = load i64, ptr %slot135, align 8
  %cmp745 = icmp eq i64 %v744, 0
  %cv746 = zext i1 %cmp745 to i64
  store i64 %cv746, ptr %slot137, align 8
  %v747 = load i64, ptr %slot137, align 8
  %cond748 = icmp ne i64 %v747, 0
  br i1 %cond748, label %bb_division121, label %bb_nonzero121
bb_division121:
  %v749 = load i64, ptr %slot1, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %v751 = load i64, ptr %slot136, align 8
  %v752 = load i64, ptr %slot135, align 8
  call void @myl_qbe_fail_division(ptr %p750, i64 6, i64 %v751, i64 %v752) nomerge, !dbg !114
  unreachable
bb_nonzero121:
  %v753 = load i64, ptr %slot136, align 8
  %cmp754 = icmp eq i64 %v753, 9223372036854775808
  %cv755 = zext i1 %cmp754 to i64
  store i64 %cv755, ptr %slot138, align 8
  %v756 = load i64, ptr %slot135, align 8
  %cmp757 = icmp eq i64 %v756, 18446744073709551615
  %cv758 = zext i1 %cmp757 to i64
  store i64 %cv758, ptr %slot139, align 8
  %v759 = load i64, ptr %slot138, align 8
  %v760 = load i64, ptr %slot139, align 8
  %op761 = and i64 %v759, %v760
  store i64 %op761, ptr %slot140, align 8
  %v762 = load i64, ptr %slot140, align 8
  %neg763 = sub i64 0, %v762
  store i64 %neg763, ptr %slot141, align 8
  %v764 = load i64, ptr %slot135, align 8
  %op765 = xor i64 %v764, 1
  store i64 %op765, ptr %slot142, align 8
  %v766 = load i64, ptr %slot142, align 8
  %v767 = load i64, ptr %slot141, align 8
  %op768 = and i64 %v766, %v767
  store i64 %op768, ptr %slot142, align 8
  %v769 = load i64, ptr %slot135, align 8
  %v770 = load i64, ptr %slot142, align 8
  %op771 = xor i64 %v769, %v770
  store i64 %op771, ptr %slot143, align 8
  %v772 = load i64, ptr %slot136, align 8
  %v773 = load i64, ptr %slot143, align 8
  %op774 = srem i64 %v772, %v773
  store i64 %op774, ptr %slot144, align 8
  %v775 = load i64, ptr %slot144, align 8
  %cmp776 = icmp ne i64 %v775, 0
  %cv777 = zext i1 %cmp776 to i64
  store i64 %cv777, ptr %slot145, align 8
  %v778 = load i64, ptr %slot144, align 8
  %v779 = load i64, ptr %slot143, align 8
  %op780 = xor i64 %v778, %v779
  store i64 %op780, ptr %slot146, align 8
  %v781 = load i64, ptr %slot146, align 8
  %cmp782 = icmp slt i64 %v781, 0
  %cv783 = zext i1 %cmp782 to i64
  store i64 %cv783, ptr %slot147, align 8
  %v784 = load i64, ptr %slot145, align 8
  %v785 = load i64, ptr %slot147, align 8
  %op786 = and i64 %v784, %v785
  store i64 %op786, ptr %slot148, align 8
  %v787 = load i64, ptr %slot148, align 8
  %neg788 = sub i64 0, %v787
  store i64 %neg788, ptr %slot149, align 8
  %v789 = load i64, ptr %slot143, align 8
  %v790 = load i64, ptr %slot149, align 8
  %op791 = and i64 %v789, %v790
  store i64 %op791, ptr %slot150, align 8
  %v792 = load i64, ptr %slot144, align 8
  %v793 = load i64, ptr %slot150, align 8
  %op794 = add i64 %v792, %v793
  store i64 %op794, ptr %slot144, align 8
  %v795 = load i64, ptr %slot144, align 8
  %v796 = load i64, ptr %slot14, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i64 %v795, ptr %p797, align 8, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot14, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld800, ptr %slot151, align 8
  %v801 = load i64, ptr %slot151, align 8
  %v802 = load i64, ptr %slot9, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i64 %v801, ptr %p803, align 8, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot10, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i64, ptr %p805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld806, ptr %slot152, align 8
  %v807 = load i64, ptr %slot152, align 8
  %v808 = load i64, ptr %slot14, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i64 %v807, ptr %p809, align 8, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot15, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 1, ptr %p811, align 8, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot15, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot153, align 8
  %v815 = load i64, ptr %slot14, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %ld817 = load i64, ptr %p816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld817, ptr %slot154, align 8
  %v818 = load i64, ptr %slot154, align 8
  %v819 = load i64, ptr %slot153, align 8
  %op820 = add i64 %v818, %v819
  %ovpair821 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v818, i64 %v819)
  %ov822 = extractvalue { i64, i1 } %ovpair821, 1
  store i64 %op820, ptr %slot155, align 8
  %cv823 = zext i1 %ov822 to i64
  store i64 %cv823, ptr %slot156, align 8
  %v824 = load i64, ptr %slot156, align 8
  %cond825 = icmp ne i64 %v824, 0
  br i1 %cond825, label %bb_overflow139, label %bb_checked139
bb_overflow139:
  %v826 = load i64, ptr %slot1, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %v828 = load i64, ptr %slot154, align 8
  %v829 = load i64, ptr %slot153, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p827, i64 0, i64 %v828, i64 %v829, i64 64) nomerge, !dbg !116
  unreachable
bb_checked139:
  %v830 = load i64, ptr %slot155, align 8
  %v831 = load i64, ptr %slot14, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 %v830, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot14, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld835, ptr %slot157, align 8
  %v836 = load i64, ptr %slot157, align 8
  %v837 = load i64, ptr %slot10, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i64 %v836, ptr %p838, align 8, !alias.scope !3, !noalias !4
  br label %bb_oi6
bb_i34:
  %v839 = load i64, ptr %slot9, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot158, align 8
  %v842 = load i64, ptr %slot158, align 8
  %v843 = load i64, ptr %slot14, align 8
  %p844 = inttoptr i64 %v843 to ptr
  store i64 %v842, ptr %p844, align 8, !alias.scope !3, !noalias !4
  %v845 = load i64, ptr %slot14, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld847, ptr %slot159, align 8
  %v848 = load i64, ptr %slot159, align 8
  ret i64 %v848
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", linkageName: "myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4238653121982337121, i64 0, !"myl_f_ac0b9215bc130dfdee358443c003e100127c6b9dbae9f2686b072be5fc05dd3a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!112 = !DILocation(line: 26, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!114 = !DILocation(line: 28, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
