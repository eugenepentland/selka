target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i32, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v175 = load i64, ptr %slot1, align 8
  %op176 = add i64 %v175, 32
  store i64 %op176, ptr %slot3, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot4, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot5, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot6, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot7, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot8, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot9, align 8
  %mem189 = alloca i8, i64 16, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot10, align 8
  %mem191 = alloca i8, i64 16, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot11, align 8
  %mem193 = alloca i8, i64 8, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot13, align 8
  %mem197 = alloca i8, i64 8, align 8
  %mem199 = alloca i8, i64 8, align 8
  %mem201 = alloca i8, i64 16, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot16, align 8
  %v203 = load i64, ptr %slot13, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot2, align 8
  store i64 %v205, ptr %mem193, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot1, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %call208 = call ptr @myl_qbe_heap(ptr %p207) nomerge, !dbg !110
  %calladdr209 = ptrtoint ptr %call208 to i64
  store i64 %calladdr209, ptr %slot17, align 8
  %v210 = load i64, ptr %slot1, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %call212 = call i64 @myl_qbe_region_mark(ptr %p211) nomerge, !dbg !110
  store i64 %call212, ptr %slot18, align 8
  %v213 = load i64, ptr %slot4, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i32 0, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot5, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 0, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot6, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i32 0, ptr %p218, align 4, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot7, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 0, ptr %p220, align 4, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot8, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i32 0, ptr %p222, align 4, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot5, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i32 2, ptr %p224, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld225 = load i64, ptr %mem193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot19, align 8
  %v226 = load i64, ptr %slot19, align 8
  store i64 %v226, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld227 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot20, align 8
  %v228 = load i64, ptr %slot20, align 8
  %v229 = load i64, ptr %slot9, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot9, align 8
  store i64 %v231, ptr %slot21, align 8
  store i32 0, ptr %slot22, align 8
  %v232 = load i64, ptr %slot6, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i32, ptr %p233, align 4, !alias.scope !3, !noalias !4
  store i32 %ld234, ptr %slot23, align 8
  %v235 = load i32, ptr %slot23, align 8
  %op236 = and i32 %v235, 24
  store i32 %op236, ptr %slot23, align 8
  %v237 = load i32, ptr %slot23, align 8
  %cmp238 = icmp eq i32 %v237, 0
  %cv239 = zext i1 %cmp238 to i32
  store i32 %cv239, ptr %slot24, align 8
  %v240 = load i32, ptr %slot22, align 8
  %v241 = load i32, ptr %slot24, align 8
  %op242 = and i32 %v240, %v241
  store i32 %op242, ptr %slot25, align 8
  %v243 = load i32, ptr %slot25, align 8
  %cv244 = zext i32 %v243 to i64
  %cond245 = icmp ne i64 %cv244, 0
  br i1 %cond245, label %bb_rcprivateown11, label %bb_rcprivateloan11
bb_rcprivateown11:
  %v246 = load i64, ptr %slot10, align 8
  store i64 %v246, ptr %slot26, align 8
  %v247 = load i64, ptr %slot18, align 8
  store i64 %v247, ptr %slot27, align 8
  %v248 = load i64, ptr %slot21, align 8
  %v249 = load i64, ptr %slot26, align 8
  %op250 = sub i64 %v248, %v249
  store i64 %op250, ptr %slot28, align 8
  %v251 = load i64, ptr %slot26, align 8
  %v252 = load i64, ptr %slot21, align 8
  %op253 = sub i64 %v251, %v252
  store i64 %op253, ptr %slot29, align 8
  %v254 = load i64, ptr %slot28, align 8
  %cmp255 = icmp ult i64 %v254, 8
  %cv256 = zext i1 %cmp255 to i32
  store i32 %cv256, ptr %slot30, align 8
  %v257 = load i64, ptr %slot29, align 8
  %cmp258 = icmp ult i64 %v257, 8
  %cv259 = zext i1 %cmp258 to i32
  store i32 %cv259, ptr %slot31, align 8
  %v260 = load i32, ptr %slot30, align 8
  %v261 = load i32, ptr %slot31, align 8
  %op262 = or i32 %v260, %v261
  store i32 %op262, ptr %slot32, align 8
  %v263 = load i32, ptr %slot32, align 8
  %cv264 = zext i32 %v263 to i64
  %cond265 = icmp ne i64 %cv264, 0
  br i1 %cond265, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v266 = load i64, ptr %slot21, align 8
  %p268 = inttoptr i64 %v266 to ptr
  %gep269 = getelementptr i8, ptr %p268, i64 0
  %op267 = ptrtoint ptr %gep269 to i64
  store i64 %op267, ptr %slot33, align 8
  %v270 = load i64, ptr %slot33, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot34, align 8
  %v273 = load i64, ptr %slot34, align 8
  %cmp274 = icmp ne i64 %v273, 0
  %cv275 = zext i1 %cmp274 to i32
  store i32 %cv275, ptr %slot35, align 8
  %v276 = load i32, ptr %slot35, align 8
  %cv277 = zext i32 %v276 to i64
  %cond278 = icmp ne i64 %cv277, 0
  br i1 %cond278, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v279 = load i64, ptr %slot34, align 8
  %op280 = sub i64 %v279, 16
  store i64 %op280, ptr %slot36, align 8
  %v281 = load i64, ptr %slot34, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %rgep283 = getelementptr i8, ptr %p282, i64 -16
  %ld284 = load i64, ptr %rgep283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld284, ptr %slot37, align 8
  %v285 = load i64, ptr %slot37, align 8
  %op286 = and i64 %v285, 5764607523034234881
  store i64 %op286, ptr %slot38, align 8
  %v287 = load i64, ptr %slot38, align 8
  %cmp288 = icmp ne i64 %v287, 0
  %cv289 = zext i1 %cmp288 to i32
  store i32 %cv289, ptr %slot39, align 8
  %v290 = load i32, ptr %slot39, align 8
  %cv291 = zext i32 %v290 to i64
  %cond292 = icmp ne i64 %cv291, 0
  br i1 %cond292, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v293 = load i64, ptr %slot21, align 8
  %v294 = load i64, ptr %slot26, align 8
  %p295 = inttoptr i64 %v293 to ptr
  %p296 = inttoptr i64 %v294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p296, ptr %p295, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot21, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 0, ptr %p298, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %v299 = load i64, ptr %slot17, align 8
  %v300 = load i64, ptr %slot26, align 8
  %v301 = load i64, ptr %slot21, align 8
  %v302 = load i64, ptr %slot27, align 8
  %cv303 = trunc i64 %v302 to i32
  %call304 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v299, i64 %v300, i64 %v301, i32 %cv303) nomerge, !dbg !112
  store i32 %call304, ptr %slot40, align 8
  %v305 = load i32, ptr %slot40, align 8
  %cv306 = zext i32 %v305 to i64
  %cond307 = icmp ne i64 %cv306, 0
  br i1 %cond307, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v308 = load i64, ptr %slot17, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %call310 = call i32 @myl_rc_take_failure(ptr %p309) nomerge, !dbg !112
  store i32 %call310, ptr %slot41, align 8
  %v311 = load i64, ptr %slot1, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %v313 = load i32, ptr %slot41, align 8
  %call314 = call i32 @myl_qbe_rc_status(ptr %p312, i32 %v313) nomerge, !dbg !112
  store i32 %call314, ptr %slot42, align 8
  br label %bb_failure
bb_rcsuccess29:
  br label %bb_rcmoved14
bb_rcmoved14:
  %v315 = load i64, ptr %slot8, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i32 2, ptr %p316, align 4, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot7, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 1, ptr %p318, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateloan11:
  %v319 = load i64, ptr %slot10, align 8
  store i64 %v319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot21, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot44, align 8
  %v323 = load i64, ptr %slot44, align 8
  %cmp324 = icmp ne i64 %v323, 0
  %cv325 = zext i1 %cmp324 to i32
  store i32 %cv325, ptr %slot45, align 8
  %v326 = load i32, ptr %slot45, align 8
  %cv327 = zext i32 %v326 to i64
  %cond328 = icmp ne i64 %cv327, 0
  br i1 %cond328, label %bb_rcgnn37, label %bb_rcgstore37
bb_rcgnn37:
  %v329 = load i64, ptr %slot44, align 8
  %op330 = sub i64 %v329, 16
  store i64 %op330, ptr %slot46, align 8
  %v331 = load i64, ptr %slot44, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %rgep333 = getelementptr i8, ptr %p332, i64 -16
  %ld334 = load i64, ptr %rgep333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld334, ptr %slot47, align 8
  %v335 = load i64, ptr %slot47, align 8
  %op336 = and i64 %v335, 4611686018427387906
  store i64 %op336, ptr %slot48, align 8
  %v337 = load i64, ptr %slot48, align 8
  %cmp338 = icmp ne i64 %v337, 0
  %cv339 = zext i1 %cmp338 to i32
  store i32 %cv339, ptr %slot49, align 8
  %v340 = load i32, ptr %slot49, align 8
  %cv341 = zext i32 %v340 to i64
  %cond342 = icmp ne i64 %cv341, 0
  br i1 %cond342, label %bb_rcgstore37, label %bb_rcginc37
bb_rcginc37:
  %v343 = load i64, ptr %slot44, align 8
  %op344 = sub i64 %v343, 24
  store i64 %op344, ptr %slot50, align 8
  %v345 = load i64, ptr %slot44, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %rgep347 = getelementptr i8, ptr %p346, i64 -24
  %ld348 = load i64, ptr %rgep347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld348, ptr %slot51, align 8
  %v349 = load i64, ptr %slot51, align 8
  %op350 = add i64 %v349, 1
  store i64 %op350, ptr %slot52, align 8
  %v351 = load i64, ptr %slot52, align 8
  %cmp352 = icmp eq i64 %v351, 0
  %cv353 = zext i1 %cmp352 to i32
  store i32 %cv353, ptr %slot53, align 8
  %v354 = load i32, ptr %slot53, align 8
  %cv355 = zext i32 %v354 to i64
  %cond356 = icmp ne i64 %cv355, 0
  br i1 %cond356, label %bb_rcglimit37, label %bb_rcgcapacity37
bb_rcglimit37:
  %v357 = load i64, ptr %slot1, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %call359 = call i32 @myl_qbe_rc_status(ptr %p358, i32 2) nomerge, !dbg !112
  store i32 %call359, ptr %slot54, align 8
  br label %bb_failure
bb_rcgcapacity37:
  %v360 = load i64, ptr %slot52, align 8
  %v361 = load i64, ptr %slot44, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %rgep363 = getelementptr i8, ptr %p362, i64 -24
  store i64 %v360, ptr %rgep363, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore37
bb_rcgstore37:
  %v364 = load i64, ptr %slot44, align 8
  %v365 = load i64, ptr %slot43, align 8
  %p366 = inttoptr i64 %v365 to ptr
  store i64 %v364, ptr %p366, align 8, !alias.scope !3, !noalias !4
  %v367 = load i64, ptr %slot8, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i32 2, ptr %p368, align 4, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot8, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i32 16, ptr %p370, align 4, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot7, align 8
  %p372 = inttoptr i64 %v371 to ptr
  store i32 1, ptr %p372, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateprepared11:
  %v373 = load i64, ptr %slot4, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i32, ptr %p374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld375, ptr %slot55, align 8
  %v376 = load i32, ptr %slot55, align 8
  %cv377 = zext i32 %v376 to i64
  %cond378 = icmp ne i64 %cv377, 0
  br i1 %cond378, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v379 = load i64, ptr %slot4, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i32 0, ptr %p380, align 4, !alias.scope !3, !noalias !4
  %v381 = load i64, ptr %slot13, align 8
  store i64 %v381, ptr %slot56, align 8
  %v382 = load i64, ptr %slot5, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i32, ptr %p383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld384, ptr %slot57, align 8
  %v385 = load i32, ptr %slot57, align 8
  %op386 = and i32 %v385, 28
  store i32 %op386, ptr %slot58, align 8
  %v387 = load i32, ptr %slot58, align 8
  %cv388 = zext i32 %v387 to i64
  %cond389 = icmp ne i64 %cv388, 0
  br i1 %cond389, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v390 = load i64, ptr %slot17, align 8
  store i64 %v390, ptr %slot59, align 8
  %v391 = load i64, ptr %slot56, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot60, align 8
  %v394 = load i64, ptr %slot60, align 8
  %cmp395 = icmp ne i64 %v394, 0
  %cv396 = zext i1 %cmp395 to i32
  store i32 %cv396, ptr %slot61, align 8
  %v397 = load i32, ptr %slot61, align 8
  %cv398 = zext i32 %v397 to i64
  %cond399 = icmp ne i64 %cv398, 0
  br i1 %cond399, label %bb_rcgnn107, label %bb_rcgdone107
bb_rcgnn107:
  %v400 = load i64, ptr %slot60, align 8
  %op401 = sub i64 %v400, 16
  store i64 %op401, ptr %slot62, align 8
  %v402 = load i64, ptr %slot60, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %rgep404 = getelementptr i8, ptr %p403, i64 -16
  %ld405 = load i64, ptr %rgep404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld405, ptr %slot63, align 8
  %v406 = load i64, ptr %slot63, align 8
  %op407 = and i64 %v406, 4611686018427387906
  store i64 %op407, ptr %slot64, align 8
  %v408 = load i64, ptr %slot64, align 8
  %cmp409 = icmp ne i64 %v408, 0
  %cv410 = zext i1 %cmp409 to i32
  store i32 %cv410, ptr %slot65, align 8
  %v411 = load i32, ptr %slot65, align 8
  %cv412 = zext i32 %v411 to i64
  %cond413 = icmp ne i64 %cv412, 0
  br i1 %cond413, label %bb_rcgclear107, label %bb_rcgcounted107
bb_rcgcounted107:
  %v414 = load i64, ptr %slot60, align 8
  %op415 = sub i64 %v414, 24
  store i64 %op415, ptr %slot66, align 8
  %v416 = load i64, ptr %slot60, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %rgep418 = getelementptr i8, ptr %p417, i64 -24
  %ld419 = load i64, ptr %rgep418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld419, ptr %slot67, align 8
  %v420 = load i64, ptr %slot67, align 8
  %op421 = sub i64 %v420, 1
  store i64 %op421, ptr %slot68, align 8
  %v422 = load i64, ptr %slot68, align 8
  %cmp423 = icmp eq i64 %v422, 0
  %cv424 = zext i1 %cmp423 to i32
  store i32 %cv424, ptr %slot69, align 8
  %v425 = load i32, ptr %slot69, align 8
  %cv426 = zext i32 %v425 to i64
  %cond427 = icmp ne i64 %cv426, 0
  br i1 %cond427, label %bb_rcglast107, label %bb_rcgdec107
bb_rcglast107:
  %v428 = load i64, ptr %slot60, align 8
  %op429 = sub i64 %v428, 32
  store i64 %op429, ptr %slot70, align 8
  %v430 = load i64, ptr %slot60, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %rgep432 = getelementptr i8, ptr %p431, i64 -32
  %ld433 = load i64, ptr %rgep432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld433, ptr %slot71, align 8
  %v434 = load i64, ptr %slot71, align 8
  %cmp435 = icmp ne i64 %v434, 0
  %cv436 = zext i1 %cmp435 to i32
  store i32 %cv436, ptr %slot72, align 8
  %v437 = load i32, ptr %slot72, align 8
  %cv438 = zext i32 %v437 to i64
  %cond439 = icmp ne i64 %cv438, 0
  br i1 %cond439, label %bb_rcgdec107, label %bb_rcgslow107
bb_rcgslow107:
  %v440 = load i64, ptr %slot59, align 8
  %v441 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v440, i64 %v441) nomerge, !dbg !112
  br label %bb_rcgdone107
bb_rcgdec107:
  %v442 = load i64, ptr %slot68, align 8
  %v443 = load i64, ptr %slot60, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %rgep445 = getelementptr i8, ptr %p444, i64 -24
  store i64 %v442, ptr %rgep445, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear107
bb_rcgclear107:
  %v446 = load i64, ptr %slot56, align 8
  %p447 = inttoptr i64 %v446 to ptr
  store i64 0, ptr %p447, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone107
bb_rcgdone107:
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v448 = load i64, ptr %slot17, align 8
  store i64 %v448, ptr %slot73, align 8
  %v449 = load i64, ptr %slot56, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot74, align 8
  %v452 = load i64, ptr %slot74, align 8
  %cmp453 = icmp ne i64 %v452, 0
  %cv454 = zext i1 %cmp453 to i32
  store i32 %cv454, ptr %slot75, align 8
  %v455 = load i32, ptr %slot75, align 8
  %cv456 = zext i32 %v455 to i64
  %cond457 = icmp ne i64 %cv456, 0
  br i1 %cond457, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v458 = load i64, ptr %slot74, align 8
  %op459 = sub i64 %v458, 16
  store i64 %op459, ptr %slot76, align 8
  %v460 = load i64, ptr %slot74, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %rgep462 = getelementptr i8, ptr %p461, i64 -16
  %ld463 = load i64, ptr %rgep462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld463, ptr %slot77, align 8
  %v464 = load i64, ptr %slot77, align 8
  %op465 = and i64 %v464, 4611686018427387906
  store i64 %op465, ptr %slot78, align 8
  %v466 = load i64, ptr %slot78, align 8
  %cmp467 = icmp ne i64 %v466, 0
  %cv468 = zext i1 %cmp467 to i32
  store i32 %cv468, ptr %slot79, align 8
  %v469 = load i32, ptr %slot79, align 8
  %cv470 = zext i32 %v469 to i64
  %cond471 = icmp ne i64 %cv470, 0
  br i1 %cond471, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v472 = load i64, ptr %slot74, align 8
  %op473 = sub i64 %v472, 32
  store i64 %op473, ptr %slot80, align 8
  %v474 = load i64, ptr %slot74, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %rgep476 = getelementptr i8, ptr %p475, i64 -32
  %ld477 = load i64, ptr %rgep476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld477, ptr %slot81, align 8
  %v478 = load i64, ptr %slot81, align 8
  %op479 = sub i64 %v478, 1
  store i64 %op479, ptr %slot82, align 8
  %v480 = load i64, ptr %slot82, align 8
  %cmp481 = icmp eq i64 %v480, 0
  %cv482 = zext i1 %cmp481 to i32
  store i32 %cv482, ptr %slot83, align 8
  %v483 = load i32, ptr %slot83, align 8
  %cv484 = zext i32 %v483 to i64
  %cond485 = icmp ne i64 %cv484, 0
  br i1 %cond485, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v486 = load i64, ptr %slot74, align 8
  %op487 = sub i64 %v486, 24
  store i64 %op487, ptr %slot84, align 8
  %v488 = load i64, ptr %slot74, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %rgep490 = getelementptr i8, ptr %p489, i64 -24
  %ld491 = load i64, ptr %rgep490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld491, ptr %slot85, align 8
  %v492 = load i64, ptr %slot85, align 8
  %cmp493 = icmp ne i64 %v492, 0
  %cv494 = zext i1 %cmp493 to i32
  store i32 %cv494, ptr %slot86, align 8
  %v495 = load i32, ptr %slot86, align 8
  %cv496 = zext i32 %v495 to i64
  %cond497 = icmp ne i64 %cv496, 0
  br i1 %cond497, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v498 = load i64, ptr %slot73, align 8
  %v499 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v498, i64 %v499) nomerge, !dbg !112
  br label %bb_rcgdone122
bb_rcgdec122:
  %v500 = load i64, ptr %slot82, align 8
  %v501 = load i64, ptr %slot74, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %rgep503 = getelementptr i8, ptr %p502, i64 -32
  store i64 %v500, ptr %rgep503, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v504 = load i64, ptr %slot56, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i64 0, ptr %p505, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v506 = load i64, ptr %slot13, align 8
  store i64 %v506, ptr %slot87, align 8
  %v507 = load i64, ptr %slot10, align 8
  store i64 %v507, ptr %slot88, align 8
  %v508 = load i64, ptr %slot88, align 8
  %v509 = load i64, ptr %slot87, align 8
  %p510 = inttoptr i64 %v508 to ptr
  %p511 = inttoptr i64 %v509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p511, ptr %p510, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot7, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i32 0, ptr %p513, align 4, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot5, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 2, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot8, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i32, ptr %p517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld518, ptr %slot89, align 8
  %v519 = load i32, ptr %slot89, align 8
  %v520 = load i64, ptr %slot5, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 %v519, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot4, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 1, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot13, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ld526 = load i64, ptr %p525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld526, ptr %slot90, align 8
  %v527 = load i64, ptr %slot13, align 8
  %p528 = inttoptr i64 %v527 to ptr
  %ld529 = load i64, ptr %p528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld529, ptr %slot91, align 8
  %v530 = load i64, ptr %slot91, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %call532 = call ptr @myl_native_text_payload(ptr %p531) nomerge, !dbg !114
  %calladdr533 = ptrtoint ptr %call532 to i64
  store i64 %calladdr533, ptr %slot92, align 8
  %v534 = load i64, ptr %slot91, align 8
  %op535 = add i64 %v534, 8
  store i64 %op535, ptr %slot93, align 8
  %v536 = load i64, ptr %slot93, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8
  store i64 %ld538, ptr %slot94, align 8
  %v539 = load i64, ptr %slot92, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %v541 = load i64, ptr %slot94, align 8
  %v542 = load i64, ptr %slot11, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %call544 = call i32 @myl_native_bytes_number_parse(ptr %p540, i64 %v541, i32 0, ptr %p543) nomerge, !dbg !114
  store i32 %call544, ptr %slot95, align 8
  %v545 = load i64, ptr %slot11, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot96, align 8
  %v548 = load i64, ptr %slot16, align 8
  store i64 %v548, ptr %slot97, align 8
  %v549 = load i64, ptr %slot97, align 8
  %p551 = inttoptr i64 %v549 to ptr
  %gep552 = getelementptr i8, ptr %p551, i64 8
  %op550 = ptrtoint ptr %gep552 to i64
  store i64 %op550, ptr %slot98, align 8
  %v553 = load i32, ptr %slot95, align 8
  %cv554 = zext i32 %v553 to i64
  %cond555 = icmp ne i64 %cv554, 0
  br i1 %cond555, label %bb_some143, label %bb_none143
bb_some143:
  %v556 = load i64, ptr %slot97, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i32 1, ptr %p557, align 4, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot96, align 8
  %v559 = load i64, ptr %slot98, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i64 %v558, ptr %p560, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_none143:
  %v561 = load i64, ptr %slot97, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i32 0, ptr %p562, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_parsed143:
  %v563 = load i64, ptr %slot97, align 8
  store i64 %v563, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld564 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot99, align 8
  %v565 = load i64, ptr %slot99, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i32, ptr %p566, align 4, !alias.scope !3, !noalias !4
  %ext568 = zext i32 %ld567 to i64
  store i64 %ext568, ptr %slot100, align 8
  %v569 = load i64, ptr %slot100, align 8
  %cmp570 = icmp eq i64 %v569, 0
  %cv571 = zext i1 %cmp570 to i64
  store i64 %cv571, ptr %slot101, align 8
  %v572 = load i64, ptr %slot101, align 8
  %cond573 = icmp ne i64 %v572, 0
  br i1 %cond573, label %bb_rcarm146, label %bb_rcarmnext146
bb_rcarm146:
  br label %bb_i6
bb_rcarmnext146:
  %v574 = load i64, ptr %slot100, align 8
  %cmp575 = icmp eq i64 %v574, 1
  %cv576 = zext i1 %cmp575 to i64
  store i64 %cv576, ptr %slot102, align 8
  %v577 = load i64, ptr %slot102, align 8
  %cond578 = icmp ne i64 %v577, 0
  br i1 %cond578, label %bb_rcarm147, label %bb_rcarmnext147
bb_rcarm147:
  %v579 = load i64, ptr %slot10, align 8
  store i64 %v579, ptr %slot103, align 8
  %v580 = load i64, ptr %slot99, align 8
  %op581 = add i64 %v580, 8
  store i64 %op581, ptr %slot104, align 8
  %v582 = load i64, ptr %slot18, align 8
  store i64 %v582, ptr %slot105, align 8
  %v583 = load i64, ptr %slot104, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot106, align 8
  %v586 = load i64, ptr %slot106, align 8
  %v587 = load i64, ptr %slot103, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot8, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i32 0, ptr %p590, align 4, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot7, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 1, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot103, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %ld595 = load i64, ptr %p594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld595, ptr %slot107, align 8
  %v596 = load i64, ptr %slot107, align 8
  store i64 %v596, ptr %mem197, align 8, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot7, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 0, ptr %p598, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext147:
  br label %bb_failure
bb_i4:
  %ld599 = load i64, ptr %mem197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld599, ptr %slot108, align 8
  %v600 = load i64, ptr %slot108, align 8
  store i64 %v600, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld601 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot109, align 8
  %v602 = load i64, ptr %slot4, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i32, ptr %p603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld604, ptr %slot110, align 8
  %v605 = load i32, ptr %slot110, align 8
  %cv606 = zext i32 %v605 to i64
  %cond607 = icmp ne i64 %cv606, 0
  br i1 %cond607, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v608 = load i64, ptr %slot4, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 0, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot13, align 8
  store i64 %v610, ptr %slot111, align 8
  %v611 = load i64, ptr %slot5, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i32, ptr %p612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld613, ptr %slot112, align 8
  %v614 = load i32, ptr %slot112, align 8
  %op615 = and i32 %v614, 28
  store i32 %op615, ptr %slot113, align 8
  %v616 = load i32, ptr %slot113, align 8
  %cv617 = zext i32 %v616 to i64
  %cond618 = icmp ne i64 %cv617, 0
  br i1 %cond618, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v619 = load i64, ptr %slot17, align 8
  store i64 %v619, ptr %slot114, align 8
  %v620 = load i64, ptr %slot111, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot115, align 8
  %v623 = load i64, ptr %slot115, align 8
  %cmp624 = icmp ne i64 %v623, 0
  %cv625 = zext i1 %cmp624 to i32
  store i32 %cv625, ptr %slot116, align 8
  %v626 = load i32, ptr %slot116, align 8
  %cv627 = zext i32 %v626 to i64
  %cond628 = icmp ne i64 %cv627, 0
  br i1 %cond628, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v629 = load i64, ptr %slot115, align 8
  %op630 = sub i64 %v629, 16
  store i64 %op630, ptr %slot117, align 8
  %v631 = load i64, ptr %slot115, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %rgep633 = getelementptr i8, ptr %p632, i64 -16
  %ld634 = load i64, ptr %rgep633, align 8, !alias.scope !9, !noalias !10
  store i64 %ld634, ptr %slot118, align 8
  %v635 = load i64, ptr %slot118, align 8
  %op636 = and i64 %v635, 4611686018427387906
  store i64 %op636, ptr %slot119, align 8
  %v637 = load i64, ptr %slot119, align 8
  %cmp638 = icmp ne i64 %v637, 0
  %cv639 = zext i1 %cmp638 to i32
  store i32 %cv639, ptr %slot120, align 8
  %v640 = load i32, ptr %slot120, align 8
  %cv641 = zext i32 %v640 to i64
  %cond642 = icmp ne i64 %cv641, 0
  br i1 %cond642, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v643 = load i64, ptr %slot115, align 8
  %op644 = sub i64 %v643, 24
  store i64 %op644, ptr %slot121, align 8
  %v645 = load i64, ptr %slot115, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %rgep647 = getelementptr i8, ptr %p646, i64 -24
  %ld648 = load i64, ptr %rgep647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld648, ptr %slot122, align 8
  %v649 = load i64, ptr %slot122, align 8
  %op650 = sub i64 %v649, 1
  store i64 %op650, ptr %slot123, align 8
  %v651 = load i64, ptr %slot123, align 8
  %cmp652 = icmp eq i64 %v651, 0
  %cv653 = zext i1 %cmp652 to i32
  store i32 %cv653, ptr %slot124, align 8
  %v654 = load i32, ptr %slot124, align 8
  %cv655 = zext i32 %v654 to i64
  %cond656 = icmp ne i64 %cv655, 0
  br i1 %cond656, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v657 = load i64, ptr %slot115, align 8
  %op658 = sub i64 %v657, 32
  store i64 %op658, ptr %slot125, align 8
  %v659 = load i64, ptr %slot115, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %rgep661 = getelementptr i8, ptr %p660, i64 -32
  %ld662 = load i64, ptr %rgep661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld662, ptr %slot126, align 8
  %v663 = load i64, ptr %slot126, align 8
  %cmp664 = icmp ne i64 %v663, 0
  %cv665 = zext i1 %cmp664 to i32
  store i32 %cv665, ptr %slot127, align 8
  %v666 = load i32, ptr %slot127, align 8
  %cv667 = zext i32 %v666 to i64
  %cond668 = icmp ne i64 %cv667, 0
  br i1 %cond668, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v669 = load i64, ptr %slot114, align 8
  %v670 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v669, i64 %v670) nomerge, !dbg !116
  br label %bb_rcgdone179
bb_rcgdec179:
  %v671 = load i64, ptr %slot123, align 8
  %v672 = load i64, ptr %slot115, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %rgep674 = getelementptr i8, ptr %p673, i64 -24
  store i64 %v671, ptr %rgep674, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v675 = load i64, ptr %slot111, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i64 0, ptr %p676, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v677 = load i64, ptr %slot17, align 8
  store i64 %v677, ptr %slot128, align 8
  %v678 = load i64, ptr %slot111, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i64, ptr %p679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld680, ptr %slot129, align 8
  %v681 = load i64, ptr %slot129, align 8
  %cmp682 = icmp ne i64 %v681, 0
  %cv683 = zext i1 %cmp682 to i32
  store i32 %cv683, ptr %slot130, align 8
  %v684 = load i32, ptr %slot130, align 8
  %cv685 = zext i32 %v684 to i64
  %cond686 = icmp ne i64 %cv685, 0
  br i1 %cond686, label %bb_rcgnn194, label %bb_rcgdone194
bb_rcgnn194:
  %v687 = load i64, ptr %slot129, align 8
  %op688 = sub i64 %v687, 16
  store i64 %op688, ptr %slot131, align 8
  %v689 = load i64, ptr %slot129, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %rgep691 = getelementptr i8, ptr %p690, i64 -16
  %ld692 = load i64, ptr %rgep691, align 8, !alias.scope !9, !noalias !10
  store i64 %ld692, ptr %slot132, align 8
  %v693 = load i64, ptr %slot132, align 8
  %op694 = and i64 %v693, 4611686018427387906
  store i64 %op694, ptr %slot133, align 8
  %v695 = load i64, ptr %slot133, align 8
  %cmp696 = icmp ne i64 %v695, 0
  %cv697 = zext i1 %cmp696 to i32
  store i32 %cv697, ptr %slot134, align 8
  %v698 = load i32, ptr %slot134, align 8
  %cv699 = zext i32 %v698 to i64
  %cond700 = icmp ne i64 %cv699, 0
  br i1 %cond700, label %bb_rcgclear194, label %bb_rcgcounted194
bb_rcgcounted194:
  %v701 = load i64, ptr %slot129, align 8
  %op702 = sub i64 %v701, 32
  store i64 %op702, ptr %slot135, align 8
  %v703 = load i64, ptr %slot129, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %rgep705 = getelementptr i8, ptr %p704, i64 -32
  %ld706 = load i64, ptr %rgep705, align 8, !alias.scope !9, !noalias !10
  store i64 %ld706, ptr %slot136, align 8
  %v707 = load i64, ptr %slot136, align 8
  %op708 = sub i64 %v707, 1
  store i64 %op708, ptr %slot137, align 8
  %v709 = load i64, ptr %slot137, align 8
  %cmp710 = icmp eq i64 %v709, 0
  %cv711 = zext i1 %cmp710 to i32
  store i32 %cv711, ptr %slot138, align 8
  %v712 = load i32, ptr %slot138, align 8
  %cv713 = zext i32 %v712 to i64
  %cond714 = icmp ne i64 %cv713, 0
  br i1 %cond714, label %bb_rcglast194, label %bb_rcgdec194
bb_rcglast194:
  %v715 = load i64, ptr %slot129, align 8
  %op716 = sub i64 %v715, 24
  store i64 %op716, ptr %slot139, align 8
  %v717 = load i64, ptr %slot129, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %rgep719 = getelementptr i8, ptr %p718, i64 -24
  %ld720 = load i64, ptr %rgep719, align 8, !alias.scope !9, !noalias !10
  store i64 %ld720, ptr %slot140, align 8
  %v721 = load i64, ptr %slot140, align 8
  %cmp722 = icmp ne i64 %v721, 0
  %cv723 = zext i1 %cmp722 to i32
  store i32 %cv723, ptr %slot141, align 8
  %v724 = load i32, ptr %slot141, align 8
  %cv725 = zext i32 %v724 to i64
  %cond726 = icmp ne i64 %cv725, 0
  br i1 %cond726, label %bb_rcgdec194, label %bb_rcgslow194
bb_rcgslow194:
  %v727 = load i64, ptr %slot128, align 8
  %v728 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v727, i64 %v728) nomerge, !dbg !116
  br label %bb_rcgdone194
bb_rcgdec194:
  %v729 = load i64, ptr %slot137, align 8
  %v730 = load i64, ptr %slot129, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %rgep732 = getelementptr i8, ptr %p731, i64 -32
  store i64 %v729, ptr %rgep732, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear194
bb_rcgclear194:
  %v733 = load i64, ptr %slot111, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 0, ptr %p734, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone194
bb_rcgdone194:
  br label %bb_rcslotdone163
bb_rcslotdone163:
  %v735 = load i64, ptr %slot109, align 8
  ret i64 %v735
bb_i6:
  store i64 0, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld736 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld736, ptr %slot142, align 8
  %v737 = load i64, ptr %slot4, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %ld739 = load i32, ptr %p738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld739, ptr %slot143, align 8
  %v740 = load i32, ptr %slot143, align 8
  %cv741 = zext i32 %v740 to i64
  %cond742 = icmp ne i64 %cv741, 0
  br i1 %cond742, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  %v743 = load i64, ptr %slot4, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i32 0, ptr %p744, align 4, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot13, align 8
  store i64 %v745, ptr %slot144, align 8
  %v746 = load i64, ptr %slot5, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i32, ptr %p747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld748, ptr %slot145, align 8
  %v749 = load i32, ptr %slot145, align 8
  %op750 = and i32 %v749, 28
  store i32 %op750, ptr %slot146, align 8
  %v751 = load i32, ptr %slot146, align 8
  %cv752 = zext i32 %v751 to i64
  %cond753 = icmp ne i64 %cv752, 0
  br i1 %cond753, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v754 = load i64, ptr %slot17, align 8
  store i64 %v754, ptr %slot147, align 8
  %v755 = load i64, ptr %slot144, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %ld757 = load i64, ptr %p756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld757, ptr %slot148, align 8
  %v758 = load i64, ptr %slot148, align 8
  %cmp759 = icmp ne i64 %v758, 0
  %cv760 = zext i1 %cmp759 to i32
  store i32 %cv760, ptr %slot149, align 8
  %v761 = load i32, ptr %slot149, align 8
  %cv762 = zext i32 %v761 to i64
  %cond763 = icmp ne i64 %cv762, 0
  br i1 %cond763, label %bb_rcgnn257, label %bb_rcgdone257
bb_rcgnn257:
  %v764 = load i64, ptr %slot148, align 8
  %op765 = sub i64 %v764, 16
  store i64 %op765, ptr %slot150, align 8
  %v766 = load i64, ptr %slot148, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %rgep768 = getelementptr i8, ptr %p767, i64 -16
  %ld769 = load i64, ptr %rgep768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld769, ptr %slot151, align 8
  %v770 = load i64, ptr %slot151, align 8
  %op771 = and i64 %v770, 4611686018427387906
  store i64 %op771, ptr %slot152, align 8
  %v772 = load i64, ptr %slot152, align 8
  %cmp773 = icmp ne i64 %v772, 0
  %cv774 = zext i1 %cmp773 to i32
  store i32 %cv774, ptr %slot153, align 8
  %v775 = load i32, ptr %slot153, align 8
  %cv776 = zext i32 %v775 to i64
  %cond777 = icmp ne i64 %cv776, 0
  br i1 %cond777, label %bb_rcgclear257, label %bb_rcgcounted257
bb_rcgcounted257:
  %v778 = load i64, ptr %slot148, align 8
  %op779 = sub i64 %v778, 24
  store i64 %op779, ptr %slot154, align 8
  %v780 = load i64, ptr %slot148, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %rgep782 = getelementptr i8, ptr %p781, i64 -24
  %ld783 = load i64, ptr %rgep782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld783, ptr %slot155, align 8
  %v784 = load i64, ptr %slot155, align 8
  %op785 = sub i64 %v784, 1
  store i64 %op785, ptr %slot156, align 8
  %v786 = load i64, ptr %slot156, align 8
  %cmp787 = icmp eq i64 %v786, 0
  %cv788 = zext i1 %cmp787 to i32
  store i32 %cv788, ptr %slot157, align 8
  %v789 = load i32, ptr %slot157, align 8
  %cv790 = zext i32 %v789 to i64
  %cond791 = icmp ne i64 %cv790, 0
  br i1 %cond791, label %bb_rcglast257, label %bb_rcgdec257
bb_rcglast257:
  %v792 = load i64, ptr %slot148, align 8
  %op793 = sub i64 %v792, 32
  store i64 %op793, ptr %slot158, align 8
  %v794 = load i64, ptr %slot148, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %rgep796 = getelementptr i8, ptr %p795, i64 -32
  %ld797 = load i64, ptr %rgep796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld797, ptr %slot159, align 8
  %v798 = load i64, ptr %slot159, align 8
  %cmp799 = icmp ne i64 %v798, 0
  %cv800 = zext i1 %cmp799 to i32
  store i32 %cv800, ptr %slot160, align 8
  %v801 = load i32, ptr %slot160, align 8
  %cv802 = zext i32 %v801 to i64
  %cond803 = icmp ne i64 %cv802, 0
  br i1 %cond803, label %bb_rcgdec257, label %bb_rcgslow257
bb_rcgslow257:
  %v804 = load i64, ptr %slot147, align 8
  %v805 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v804, i64 %v805) nomerge, !dbg !118
  br label %bb_rcgdone257
bb_rcgdec257:
  %v806 = load i64, ptr %slot156, align 8
  %v807 = load i64, ptr %slot148, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %rgep809 = getelementptr i8, ptr %p808, i64 -24
  store i64 %v806, ptr %rgep809, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear257
bb_rcgclear257:
  %v810 = load i64, ptr %slot144, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 0, ptr %p811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone257
bb_rcgdone257:
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v812 = load i64, ptr %slot17, align 8
  store i64 %v812, ptr %slot161, align 8
  %v813 = load i64, ptr %slot144, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i64, ptr %p814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld815, ptr %slot162, align 8
  %v816 = load i64, ptr %slot162, align 8
  %cmp817 = icmp ne i64 %v816, 0
  %cv818 = zext i1 %cmp817 to i32
  store i32 %cv818, ptr %slot163, align 8
  %v819 = load i32, ptr %slot163, align 8
  %cv820 = zext i32 %v819 to i64
  %cond821 = icmp ne i64 %cv820, 0
  br i1 %cond821, label %bb_rcgnn272, label %bb_rcgdone272
bb_rcgnn272:
  %v822 = load i64, ptr %slot162, align 8
  %op823 = sub i64 %v822, 16
  store i64 %op823, ptr %slot164, align 8
  %v824 = load i64, ptr %slot162, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %rgep826 = getelementptr i8, ptr %p825, i64 -16
  %ld827 = load i64, ptr %rgep826, align 8, !alias.scope !9, !noalias !10
  store i64 %ld827, ptr %slot165, align 8
  %v828 = load i64, ptr %slot165, align 8
  %op829 = and i64 %v828, 4611686018427387906
  store i64 %op829, ptr %slot166, align 8
  %v830 = load i64, ptr %slot166, align 8
  %cmp831 = icmp ne i64 %v830, 0
  %cv832 = zext i1 %cmp831 to i32
  store i32 %cv832, ptr %slot167, align 8
  %v833 = load i32, ptr %slot167, align 8
  %cv834 = zext i32 %v833 to i64
  %cond835 = icmp ne i64 %cv834, 0
  br i1 %cond835, label %bb_rcgclear272, label %bb_rcgcounted272
bb_rcgcounted272:
  %v836 = load i64, ptr %slot162, align 8
  %op837 = sub i64 %v836, 32
  store i64 %op837, ptr %slot168, align 8
  %v838 = load i64, ptr %slot162, align 8
  %p839 = inttoptr i64 %v838 to ptr
  %rgep840 = getelementptr i8, ptr %p839, i64 -32
  %ld841 = load i64, ptr %rgep840, align 8, !alias.scope !9, !noalias !10
  store i64 %ld841, ptr %slot169, align 8
  %v842 = load i64, ptr %slot169, align 8
  %op843 = sub i64 %v842, 1
  store i64 %op843, ptr %slot170, align 8
  %v844 = load i64, ptr %slot170, align 8
  %cmp845 = icmp eq i64 %v844, 0
  %cv846 = zext i1 %cmp845 to i32
  store i32 %cv846, ptr %slot171, align 8
  %v847 = load i32, ptr %slot171, align 8
  %cv848 = zext i32 %v847 to i64
  %cond849 = icmp ne i64 %cv848, 0
  br i1 %cond849, label %bb_rcglast272, label %bb_rcgdec272
bb_rcglast272:
  %v850 = load i64, ptr %slot162, align 8
  %op851 = sub i64 %v850, 24
  store i64 %op851, ptr %slot172, align 8
  %v852 = load i64, ptr %slot162, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %rgep854 = getelementptr i8, ptr %p853, i64 -24
  %ld855 = load i64, ptr %rgep854, align 8, !alias.scope !9, !noalias !10
  store i64 %ld855, ptr %slot173, align 8
  %v856 = load i64, ptr %slot173, align 8
  %cmp857 = icmp ne i64 %v856, 0
  %cv858 = zext i1 %cmp857 to i32
  store i32 %cv858, ptr %slot174, align 8
  %v859 = load i32, ptr %slot174, align 8
  %cv860 = zext i32 %v859 to i64
  %cond861 = icmp ne i64 %cv860, 0
  br i1 %cond861, label %bb_rcgdec272, label %bb_rcgslow272
bb_rcgslow272:
  %v862 = load i64, ptr %slot161, align 8
  %v863 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v862, i64 %v863) nomerge, !dbg !118
  br label %bb_rcgdone272
bb_rcgdec272:
  %v864 = load i64, ptr %slot170, align 8
  %v865 = load i64, ptr %slot162, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %rgep867 = getelementptr i8, ptr %p866, i64 -32
  store i64 %v864, ptr %rgep867, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear272
bb_rcgclear272:
  %v868 = load i64, ptr %slot144, align 8
  %p869 = inttoptr i64 %v868 to ptr
  store i64 0, ptr %p869, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone272
bb_rcgdone272:
  br label %bb_rcslotdone241
bb_rcslotdone241:
  %v870 = load i64, ptr %slot142, align 8
  ret i64 %v870
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", linkageName: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3519549293126700163, i64 0, !"myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
