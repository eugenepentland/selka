target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v90 = load i64, ptr %slot1, align 8
  %op91 = add i64 %v90, 32
  store i64 %op91, ptr %slot4, align 8
  %mem92 = alloca i8, i64 16, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot5, align 8
  %mem94 = alloca i8, i64 8, align 8
  %mem96 = alloca i8, i64 8, align 8
  %mem98 = alloca i8, i64 8, align 8
  %mem100 = alloca i8, i64 8, align 8
  %mem102 = alloca i8, i64 8, align 8
  %mem104 = alloca i8, i64 8, align 8
  %mem106 = alloca i8, i64 8, align 8
  %mem108 = alloca i8, i64 16, align 8
  %ptr109 = ptrtoint ptr %mem108 to i64
  store i64 %ptr109, ptr %slot13, align 8
  %mem110 = alloca i8, i64 16, align 8
  %ptr111 = ptrtoint ptr %mem110 to i64
  store i64 %ptr111, ptr %slot14, align 8
  %mem112 = alloca i8, i64 16, align 8
  %ptr113 = ptrtoint ptr %mem112 to i64
  store i64 %ptr113, ptr %slot15, align 8
  %mem114 = alloca i8, i64 16, align 8
  %ptr115 = ptrtoint ptr %mem114 to i64
  store i64 %ptr115, ptr %slot16, align 8
  %v116 = load i64, ptr %slot2, align 8
  store i64 %v116, ptr %mem94, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot3, align 8
  store i64 %v117, ptr %mem96, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld118 = load i64, ptr %mem94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot17, align 8
  %v119 = load i64, ptr %slot17, align 8
  store i64 %v119, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %ld120 = load i64, ptr %mem96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot18, align 8
  %v121 = load i64, ptr %slot18, align 8
  store i64 %v121, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  br label %bb_i3
bb_i3:
  %ld122 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot19, align 8
  %v123 = load i64, ptr %slot19, align 8
  store i64 %v123, ptr %mem102, align 8, !alias.scope !3, !noalias !4
  %ld124 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot20, align 8
  %v125 = load i64, ptr %slot20, align 8
  store i64 %v125, ptr %mem100, align 8, !alias.scope !3, !noalias !4
  %ld126 = load i64, ptr %mem100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld126, ptr %slot21, align 8
  %v127 = load i64, ptr %slot21, align 8
  store i64 %v127, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 5, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  %ld128 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld128, ptr %slot22, align 8
  %ld129 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot23, align 8
  %v130 = load i64, ptr %slot22, align 8
  %cmp131 = icmp eq i64 %v130, 0
  %cv132 = zext i1 %cmp131 to i64
  store i64 %cv132, ptr %slot24, align 8
  %v133 = load i64, ptr %slot24, align 8
  %cond134 = icmp ne i64 %v133, 0
  br i1 %cond134, label %bb_division7, label %bb_nonzero7
bb_division7:
  %v135 = load i64, ptr %slot1, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %v137 = load i64, ptr %slot23, align 8
  %v138 = load i64, ptr %slot22, align 8
  call void @myl_qbe_fail_division(ptr %p136, i64 6, i64 %v137, i64 %v138) nomerge, !dbg !110
  unreachable
bb_nonzero7:
  %v139 = load i64, ptr %slot23, align 8
  %cmp140 = icmp eq i64 %v139, 9223372036854775808
  %cv141 = zext i1 %cmp140 to i64
  store i64 %cv141, ptr %slot25, align 8
  %v142 = load i64, ptr %slot22, align 8
  %cmp143 = icmp eq i64 %v142, 18446744073709551615
  %cv144 = zext i1 %cmp143 to i64
  store i64 %cv144, ptr %slot26, align 8
  %v145 = load i64, ptr %slot25, align 8
  %v146 = load i64, ptr %slot26, align 8
  %op147 = and i64 %v145, %v146
  store i64 %op147, ptr %slot27, align 8
  %v148 = load i64, ptr %slot27, align 8
  %neg149 = sub i64 0, %v148
  store i64 %neg149, ptr %slot28, align 8
  %v150 = load i64, ptr %slot22, align 8
  %op151 = xor i64 %v150, 1
  store i64 %op151, ptr %slot29, align 8
  %v152 = load i64, ptr %slot29, align 8
  %v153 = load i64, ptr %slot28, align 8
  %op154 = and i64 %v152, %v153
  store i64 %op154, ptr %slot29, align 8
  %v155 = load i64, ptr %slot22, align 8
  %v156 = load i64, ptr %slot29, align 8
  %op157 = xor i64 %v155, %v156
  store i64 %op157, ptr %slot30, align 8
  %v158 = load i64, ptr %slot23, align 8
  %v159 = load i64, ptr %slot30, align 8
  %op160 = srem i64 %v158, %v159
  store i64 %op160, ptr %slot31, align 8
  %v161 = load i64, ptr %slot31, align 8
  %cmp162 = icmp ne i64 %v161, 0
  %cv163 = zext i1 %cmp162 to i64
  store i64 %cv163, ptr %slot32, align 8
  %v164 = load i64, ptr %slot31, align 8
  %v165 = load i64, ptr %slot30, align 8
  %op166 = xor i64 %v164, %v165
  store i64 %op166, ptr %slot33, align 8
  %v167 = load i64, ptr %slot33, align 8
  %cmp168 = icmp slt i64 %v167, 0
  %cv169 = zext i1 %cmp168 to i64
  store i64 %cv169, ptr %slot34, align 8
  %v170 = load i64, ptr %slot32, align 8
  %v171 = load i64, ptr %slot34, align 8
  %op172 = and i64 %v170, %v171
  store i64 %op172, ptr %slot35, align 8
  %v173 = load i64, ptr %slot35, align 8
  %neg174 = sub i64 0, %v173
  store i64 %neg174, ptr %slot36, align 8
  %v175 = load i64, ptr %slot30, align 8
  %v176 = load i64, ptr %slot36, align 8
  %op177 = and i64 %v175, %v176
  store i64 %op177, ptr %slot37, align 8
  %v178 = load i64, ptr %slot31, align 8
  %v179 = load i64, ptr %slot37, align 8
  %op180 = add i64 %v178, %v179
  store i64 %op180, ptr %slot31, align 8
  %v181 = load i64, ptr %slot31, align 8
  store i64 %v181, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  %ld182 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot38, align 8
  %ld183 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld183, ptr %slot39, align 8
  %v184 = load i64, ptr %slot39, align 8
  %v185 = load i64, ptr %slot38, align 8
  %cmp186 = icmp eq i64 %v184, %v185
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot40, align 8
  %v188 = load i64, ptr %slot40, align 8
  store i64 %v188, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %ld189 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot41, align 8
  %v190 = load i64, ptr %slot41, align 8
  %cond191 = icmp ne i64 %v190, 0
  br i1 %cond191, label %bb_next25, label %bb_i14
bb_next25:
  store i64 1, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot13, align 8
  store i64 %v192, ptr %slot42, align 8
  %v193 = load i64, ptr %slot42, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i32 1, ptr %p194, align 4, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot42, align 8
  %p197 = inttoptr i64 %v195 to ptr
  %gep198 = getelementptr i8, ptr %p197, i64 8
  %op196 = ptrtoint ptr %gep198 to i64
  store i64 %op196, ptr %slot43, align 8
  %ld199 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot44, align 8
  %v200 = load i64, ptr %slot44, align 8
  %v201 = load i64, ptr %slot43, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot42, align 8
  store i64 %v203, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %p204 = inttoptr i64 ptrtoint (ptr @myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p204, i64 7) "call-inline-cost"="0", !dbg !112
  br label %bb_i19
bb_i14:
  %ld205 = load i64, ptr %mem100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot45, align 8
  %v206 = load i64, ptr %slot45, align 8
  store i64 %v206, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %ld207 = load i64, ptr %mem102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot46, align 8
  %v208 = load i64, ptr %slot46, align 8
  store i64 %v208, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  %ld209 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot47, align 8
  %ld210 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot48, align 8
  %v211 = load i64, ptr %slot48, align 8
  %v212 = load i64, ptr %slot47, align 8
  %ovpair214 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v211, i64 %v212)
  %op213 = extractvalue { i64, i1 } %ovpair214, 0
  %ov215 = extractvalue { i64, i1 } %ovpair214, 1
  store i64 %op213, ptr %slot49, align 8
  %v216 = load i64, ptr %slot48, align 8
  %v217 = load i64, ptr %slot49, align 8
  %op218 = xor i64 %v216, %v217
  store i64 %op218, ptr %slot50, align 8
  %v219 = load i64, ptr %slot47, align 8
  %v220 = load i64, ptr %slot49, align 8
  %op221 = xor i64 %v219, %v220
  store i64 %op221, ptr %slot51, align 8
  %v222 = load i64, ptr %slot50, align 8
  %v223 = load i64, ptr %slot51, align 8
  %op224 = and i64 %v222, %v223
  store i64 %op224, ptr %slot52, align 8
  %cv225 = zext i1 %ov215 to i64
  store i64 %cv225, ptr %slot53, align 8
  %v226 = load i64, ptr %slot53, align 8
  %cond227 = icmp ne i64 %v226, 0
  br i1 %cond227, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v228 = load i64, ptr %slot1, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %v230 = load i64, ptr %slot48, align 8
  %v231 = load i64, ptr %slot47, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p229, i64 0, i64 %v230, i64 %v231, i64 64) nomerge, !dbg !114
  unreachable
bb_checked32:
  %v232 = load i64, ptr %slot49, align 8
  store i64 %v232, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot14, align 8
  store i64 %v233, ptr %slot54, align 8
  %v234 = load i64, ptr %slot54, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i32 0, ptr %p235, align 4, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot54, align 8
  %p238 = inttoptr i64 %v236 to ptr
  %gep239 = getelementptr i8, ptr %p238, i64 8
  %op237 = ptrtoint ptr %gep239 to i64
  store i64 %op237, ptr %slot55, align 8
  %ld240 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld240, ptr %slot56, align 8
  %v241 = load i64, ptr %slot56, align 8
  %v242 = load i64, ptr %slot55, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i64 %v241, ptr %p243, align 8, !alias.scope !3, !noalias !4
  %v244 = load i64, ptr %slot54, align 8
  store i64 %v244, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  br label %bb_i19
bb_i19:
  %ld245 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot57, align 8
  %v246 = load i64, ptr %slot57, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i32, ptr %p247, align 4, !alias.scope !3, !noalias !4
  %ext249 = zext i32 %ld248 to i64
  store i64 %ext249, ptr %slot58, align 8
  %v250 = load i64, ptr %slot58, align 8
  %cmp251 = icmp eq i64 %v250, 0
  %cv252 = zext i1 %cmp251 to i64
  store i64 %cv252, ptr %slot59, align 8
  %v253 = load i64, ptr %slot59, align 8
  %cond254 = icmp ne i64 %v253, 0
  br i1 %cond254, label %bb_tryok41, label %bb_tryerror41
bb_tryerror41:
  %p255 = inttoptr i64 ptrtoint (ptr @myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p255, i64 12884901907) "call-inline-cost"="0", !dbg !116
  %v256 = load i64, ptr %slot15, align 8
  store i64 %v256, ptr %slot60, align 8
  %v257 = load i64, ptr %slot60, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i32 1, ptr %p258, align 4, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot60, align 8
  %p261 = inttoptr i64 %v259 to ptr
  %gep262 = getelementptr i8, ptr %p261, i64 8
  %op260 = ptrtoint ptr %gep262 to i64
  store i64 %op260, ptr %slot61, align 8
  %v263 = load i64, ptr %slot57, align 8
  %op264 = add i64 %v263, 8
  store i64 %op264, ptr %slot62, align 8
  %v265 = load i64, ptr %slot62, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot63, align 8
  %v268 = load i64, ptr %slot63, align 8
  %v269 = load i64, ptr %slot61, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot60, align 8
  store i64 %v271, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_tryok41:
  %v272 = load i64, ptr %slot57, align 8
  %op273 = add i64 %v272, 8
  store i64 %op273, ptr %slot64, align 8
  %v274 = load i64, ptr %slot64, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot65, align 8
  %v277 = load i64, ptr %slot65, align 8
  store i64 %v277, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i21:
  %ld278 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot66, align 8
  %v279 = load i64, ptr %slot66, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ret281 = load { i64, i64 }, ptr %p280, align 8
  ret { i64, i64 } %ret281
bb_i22:
  %ld282 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot67, align 8
  %v283 = load i64, ptr %slot67, align 8
  store i64 %v283, ptr %mem98, align 8, !alias.scope !3, !noalias !4
  %ld284 = load i64, ptr %mem98, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot68, align 8
  %v285 = load i64, ptr %slot68, align 8
  store i64 %v285, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 3, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  %ld286 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot69, align 8
  %ld287 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot70, align 8
  %v288 = load i64, ptr %slot70, align 8
  %v289 = load i64, ptr %slot69, align 8
  %ovpair291 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v288, i64 %v289)
  %op290 = extractvalue { i64, i1 } %ovpair291, 0
  %ov292 = extractvalue { i64, i1 } %ovpair291, 1
  store i64 %op290, ptr %slot71, align 8
  %v298 = load i64, ptr %slot70, align 8
  %wide293 = zext i64 %v298 to i128
  %v299 = load i64, ptr %slot69, align 8
  %wide294 = zext i64 %v299 to i128
  %product295 = mul i128 %wide293, %wide294
  %high296 = lshr i128 %product295, 64
  %op297 = trunc i128 %high296 to i64
  store i64 %op297, ptr %slot72, align 8
  %v300 = load i64, ptr %slot70, align 8
  %cmp301 = icmp slt i64 %v300, 0
  %cv302 = zext i1 %cmp301 to i64
  store i64 %cv302, ptr %slot73, align 8
  %v303 = load i64, ptr %slot69, align 8
  %cmp304 = icmp slt i64 %v303, 0
  %cv305 = zext i1 %cmp304 to i64
  store i64 %cv305, ptr %slot74, align 8
  %v306 = load i64, ptr %slot73, align 8
  %neg307 = sub i64 0, %v306
  store i64 %neg307, ptr %slot75, align 8
  %v308 = load i64, ptr %slot74, align 8
  %neg309 = sub i64 0, %v308
  store i64 %neg309, ptr %slot76, align 8
  %v310 = load i64, ptr %slot69, align 8
  %v311 = load i64, ptr %slot75, align 8
  %op312 = and i64 %v310, %v311
  store i64 %op312, ptr %slot77, align 8
  %v313 = load i64, ptr %slot70, align 8
  %v314 = load i64, ptr %slot76, align 8
  %op315 = and i64 %v313, %v314
  store i64 %op315, ptr %slot78, align 8
  %v316 = load i64, ptr %slot72, align 8
  %v317 = load i64, ptr %slot77, align 8
  %op318 = sub i64 %v316, %v317
  store i64 %op318, ptr %slot79, align 8
  %v319 = load i64, ptr %slot79, align 8
  %v320 = load i64, ptr %slot78, align 8
  %op321 = sub i64 %v319, %v320
  store i64 %op321, ptr %slot79, align 8
  %v322 = load i64, ptr %slot71, align 8
  %op323 = ashr i64 %v322, 63
  store i64 %op323, ptr %slot80, align 8
  %cv324 = zext i1 %ov292 to i64
  store i64 %cv324, ptr %slot81, align 8
  %v325 = load i64, ptr %slot81, align 8
  %cond326 = icmp ne i64 %v325, 0
  br i1 %cond326, label %bb_overflow54, label %bb_checked54
bb_overflow54:
  %v327 = load i64, ptr %slot1, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %v329 = load i64, ptr %slot70, align 8
  %v330 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p328, i64 2, i64 %v329, i64 %v330, i64 64) nomerge, !dbg !118
  unreachable
bb_checked54:
  %v331 = load i64, ptr %slot71, align 8
  store i64 %v331, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 1, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  %ld332 = load i64, ptr %mem106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld332, ptr %slot82, align 8
  %ld333 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot83, align 8
  %v334 = load i64, ptr %slot83, align 8
  %v335 = load i64, ptr %slot82, align 8
  %ovpair337 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v334, i64 %v335)
  %op336 = extractvalue { i64, i1 } %ovpair337, 0
  %ov338 = extractvalue { i64, i1 } %ovpair337, 1
  store i64 %op336, ptr %slot84, align 8
  %cv339 = zext i1 %ov338 to i64
  store i64 %cv339, ptr %slot85, align 8
  %v340 = load i64, ptr %slot85, align 8
  %cond341 = icmp ne i64 %v340, 0
  br i1 %cond341, label %bb_overflow67, label %bb_checked67
bb_overflow67:
  %v342 = load i64, ptr %slot1, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %v344 = load i64, ptr %slot83, align 8
  %v345 = load i64, ptr %slot82, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p343, i64 0, i64 %v344, i64 %v345, i64 64) nomerge, !dbg !120
  unreachable
bb_checked67:
  %v346 = load i64, ptr %slot84, align 8
  store i64 %v346, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot16, align 8
  store i64 %v347, ptr %slot86, align 8
  %v348 = load i64, ptr %slot86, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 0, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot86, align 8
  %p352 = inttoptr i64 %v350 to ptr
  %gep353 = getelementptr i8, ptr %p352, i64 8
  %op351 = ptrtoint ptr %gep353 to i64
  store i64 %op351, ptr %slot87, align 8
  %ld354 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld354, ptr %slot88, align 8
  %v355 = load i64, ptr %slot88, align 8
  %v356 = load i64, ptr %slot87, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot86, align 8
  store i64 %v358, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  %ld359 = load i64, ptr %mem104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot89, align 8
  %v360 = load i64, ptr %slot89, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ret362 = load { i64, i64 }, ptr %p361, align 8
  ret { i64, i64 } %ret362
bb_failure:
  %v363 = load i64, ptr %slot5, align 8
  %p364 = inttoptr i64 %v363 to ptr
  call void @llvm.memset.p0.i64(ptr %p364, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v365 = load i64, ptr %slot5, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ret367 = load { i64, i64 }, ptr %p366, align 8
  ret { i64, i64 } %ret367
bb_entry_failure:
  %v368 = load i64, ptr %slot5, align 8
  %p369 = inttoptr i64 %v368 to ptr
  call void @llvm.memset.p0.i64(ptr %p369, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ret372 = load { i64, i64 }, ptr %p371, align 8
  ret { i64, i64 } %ret372
}

@myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596_meta = external global i8, align 8
@myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef_meta = external global i8, align 8

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596", linkageName: "myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4667182802457884180, i64 0, !"myl_f_5369b4c66e5b43253a9b5eea086246fe91113f976d8e1318e9f59662c8ee3596"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!110 = !DILocation(line: 8, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!112 = !DILocation(line: 13, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!114 = !DILocation(line: 17, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!116 = !DILocation(line: 20, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!118 = !DILocation(line: 26, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!120 = !DILocation(line: 28, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!122 = !DILocation(line: 30, column: 0, scope: !123)
