
/home/epentland/ai/canopy/mylang-worktrees/goal110-presize-ready-20261004/.mylang-cache/goal110-presize-ready-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000108fe60 <index_walk>:
 108fe60:	push   %rbp
 108fe61:	mov    %rsp,%rbp
 108fe64:	push   %r15
 108fe66:	push   %r14
 108fe68:	push   %rbx
 108fe69:	push   %rax
 108fe6a:	mov    0x8(%rdi),%rdx
 108fe6e:	mov    %rdx,%rax
 108fe71:	sub    %rsi,%rax
 108fe74:	jbe    108feda <index_walk+0x7a>
 108fe76:	mov    0x10(%rdi),%r9d
 108fe7a:	lea    0x18(%rdi),%r8
 108fe7e:	mov    %r8,%rcx
 108fe81:	test   $0x4,%r9b
 108fe85:	je     108fe96 <index_walk+0x36>
 108fe87:	mov    0x18(%rdi),%rcx
 108fe8b:	mov    0x14(%rdi),%r10d
 108fe8f:	add    %r10,%rcx
 108fe92:	add    $0x18,%rcx
 108fe96:	cmp    %rax,%rsi
 108fe99:	mov    %rax,%r10
 108fe9c:	cmovb  %rsi,%r10
 108fea0:	cmp    $0x401,%r10
 108fea7:	jb     108fec7 <index_walk+0x67>
 108fea9:	test   $0x8,%r9b
 108fead:	jne    108fef5 <index_walk+0x95>
 108feaf:	test   $0x4,%r9b
 108feb3:	je     108fec7 <index_walk+0x67>
 108feb5:	mov    (%r8),%rbx
 108feb8:	test   %rbx,%rbx
 108febb:	je     108fec7 <index_walk+0x67>
 108febd:	testb  $0x8,0x10(%rbx)
 108fec1:	jne    1090497 <index_walk+0x637>
 108fec7:	cmp    %rax,%rsi
 108feca:	jbe    108fee2 <index_walk+0x82>
 108fecc:	lea    0x8(%rsi),%rax
 108fed0:	cmp    %rdx,%rax
 108fed3:	jbe    108ff04 <index_walk+0xa4>
 108fed5:	xor    %r8d,%r8d
 108fed8:	jmp    108ff56 <index_walk+0xf6>
 108feda:	mov    (%rdi),%rax
 108fedd:	jmp    10904c0 <index_walk+0x660>
 108fee2:	cmp    $0x8,%rsi
 108fee6:	jae    108ff81 <index_walk+0x121>
 108feec:	xor    %eax,%eax
 108feee:	xor    %edx,%edx
 108fef0:	jmp    10901a9 <index_walk+0x349>
 108fef5:	add    $0x8,%rsp
 108fef9:	pop    %rbx
 108fefa:	pop    %r14
 108fefc:	pop    %r15
 108fefe:	pop    %rbp
 108feff:	jmp    10904e0 <index_at>
 108ff04:	movabs $0x101010101010101,%rax
 108ff0e:	xor    %r8d,%r8d
 108ff11:	mov    %rsi,%r9
 108ff14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 108ff20:	mov    (%rcx,%r9,1),%rsi
 108ff24:	mov    %rsi,%r10
 108ff27:	not    %r10
 108ff2a:	add    %r10,%r10
 108ff2d:	and    %rsi,%r10
 108ff30:	shr    $0x7,%r10
 108ff34:	and    %rax,%r10
 108ff37:	imul   %rax,%r10
 108ff3b:	shr    $0x38,%r10
 108ff3f:	sub    %r10,%r8
 108ff42:	add    $0x8,%r8
 108ff46:	lea    0x8(%r9),%rsi
 108ff4a:	add    $0x10,%r9
 108ff4e:	cmp    %rdx,%r9
 108ff51:	mov    %rsi,%r9
 108ff54:	jbe    108ff20 <index_walk+0xc0>
 108ff56:	mov    (%rdi),%rax
 108ff59:	mov    %rdx,%rdi
 108ff5c:	sub    %rsi,%rdi
 108ff5f:	jbe    1090325 <index_walk+0x4c5>
 108ff65:	cmp    $0x3,%rdi
 108ff69:	jbe    1090310 <index_walk+0x4b0>
 108ff6f:	cmp    $0x10,%rdi
 108ff73:	jae    10901d1 <index_walk+0x371>
 108ff79:	xor    %r9d,%r9d
 108ff7c:	jmp    10902af <index_walk+0x44f>
 108ff81:	lea    -0x8(%rsi),%r8
 108ff85:	cmp    $0x78,%r8
 108ff89:	jae    108ff99 <index_walk+0x139>
 108ff8b:	mov    $0x8,%edi
 108ff90:	xor    %edx,%edx
 108ff92:	xor    %eax,%eax
 108ff94:	jmp    1090161 <index_walk+0x301>
 108ff99:	shr    $0x3,%r8
 108ff9d:	inc    %r8
 108ffa0:	mov    %r8,%r9
 108ffa3:	and    $0xfffffffffffffff0,%r9
 108ffa7:	lea    0x0(,%r9,8),%rdx
 108ffaf:	lea    0x8(,%r9,8),%rdi
 108ffb7:	vpxor  %xmm2,%xmm2,%xmm2
 108ffbb:	xor    %eax,%eax
 108ffbd:	vpbroadcastq -0x88e86(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 108ffc6:	vpbroadcastq -0x88e87(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 108ffcf:	vpbroadcastq -0x88f08(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 108ffd8:	vpcmpeqd %ymm4,%ymm4,%ymm4
 108ffdc:	vpxor  %xmm7,%xmm7,%xmm7
 108ffe0:	vpxor  %xmm6,%xmm6,%xmm6
 108ffe4:	vpxor  %xmm5,%xmm5,%xmm5
 108ffe8:	nopl   0x0(%rax,%rax,1)
 108fff0:	vmovdqu (%rcx,%rax,8),%ymm8
 108fff5:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 108fffb:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 1090001:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 1090007:	vpxor  %ymm4,%ymm8,%ymm12
 109000b:	vpaddq %ymm12,%ymm12,%ymm12
 1090010:	vpxor  %ymm4,%ymm9,%ymm13
 1090014:	vpaddq %ymm13,%ymm13,%ymm13
 1090019:	vpxor  %ymm4,%ymm10,%ymm14
 109001d:	vpaddq %ymm14,%ymm14,%ymm14
 1090022:	vpxor  %ymm4,%ymm11,%ymm15
 1090026:	vpaddq %ymm15,%ymm15,%ymm15
 109002b:	vpand  %ymm12,%ymm8,%ymm8
 1090030:	vpand  %ymm13,%ymm9,%ymm9
 1090035:	vpand  %ymm14,%ymm10,%ymm10
 109003a:	vpand  %ymm15,%ymm11,%ymm11
 109003f:	vpsrlq $0x7,%ymm8,%ymm8
 1090045:	vpsrlq $0x7,%ymm9,%ymm9
 109004b:	vpsrlq $0x7,%ymm10,%ymm10
 1090051:	vpsrlq $0x7,%ymm11,%ymm11
 1090057:	vpand  %ymm0,%ymm8,%ymm8
 109005b:	vpand  %ymm0,%ymm9,%ymm9
 109005f:	vpand  %ymm0,%ymm10,%ymm10
 1090063:	vpand  %ymm0,%ymm11,%ymm11
 1090067:	vpmuludq %ymm1,%ymm8,%ymm12
 109006b:	vpsrlq $0x20,%ymm8,%ymm13
 1090071:	vpmuludq %ymm0,%ymm13,%ymm13
 1090075:	vpaddq %ymm13,%ymm12,%ymm12
 109007a:	vpsllq $0x20,%ymm12,%ymm12
 1090080:	vpmuludq %ymm0,%ymm8,%ymm8
 1090084:	vpaddq %ymm12,%ymm8,%ymm8
 1090089:	vpmuludq %ymm1,%ymm9,%ymm12
 109008d:	vpsrlq $0x20,%ymm9,%ymm13
 1090093:	vpmuludq %ymm0,%ymm13,%ymm13
 1090097:	vpaddq %ymm13,%ymm12,%ymm12
 109009c:	vpsllq $0x20,%ymm12,%ymm12
 10900a2:	vpmuludq %ymm0,%ymm9,%ymm9
 10900a6:	vpaddq %ymm12,%ymm9,%ymm9
 10900ab:	vpmuludq %ymm1,%ymm10,%ymm12
 10900af:	vpsrlq $0x20,%ymm10,%ymm13
 10900b5:	vpmuludq %ymm0,%ymm13,%ymm13
 10900b9:	vpaddq %ymm13,%ymm12,%ymm12
 10900be:	vpsllq $0x20,%ymm12,%ymm12
 10900c4:	vpmuludq %ymm0,%ymm10,%ymm10
 10900c8:	vpaddq %ymm12,%ymm10,%ymm10
 10900cd:	vpmuludq %ymm1,%ymm11,%ymm12
 10900d1:	vpsrlq $0x20,%ymm11,%ymm13
 10900d7:	vpmuludq %ymm0,%ymm13,%ymm13
 10900db:	vpaddq %ymm13,%ymm12,%ymm12
 10900e0:	vpsllq $0x20,%ymm12,%ymm12
 10900e6:	vpmuludq %ymm0,%ymm11,%ymm11
 10900ea:	vpaddq %ymm12,%ymm11,%ymm11
 10900ef:	vpsrlq $0x38,%ymm8,%ymm8
 10900f5:	vpsubq %ymm8,%ymm2,%ymm2
 10900fa:	vpsrlq $0x38,%ymm9,%ymm8
 1090100:	vpsubq %ymm8,%ymm7,%ymm7
 1090105:	vpsrlq $0x38,%ymm10,%ymm8
 109010b:	vpsubq %ymm8,%ymm6,%ymm6
 1090110:	vpsrlq $0x38,%ymm11,%ymm8
 1090116:	vpsubq %ymm8,%ymm5,%ymm5
 109011b:	vpaddq %ymm3,%ymm2,%ymm2
 109011f:	vpaddq %ymm3,%ymm7,%ymm7
 1090123:	vpaddq %ymm3,%ymm6,%ymm6
 1090127:	vpaddq %ymm3,%ymm5,%ymm5
 109012b:	add    $0x10,%rax
 109012f:	cmp    %rax,%r9
 1090132:	jne    108fff0 <index_walk+0x190>
 1090138:	vpaddq %ymm2,%ymm7,%ymm0
 109013c:	vpaddq %ymm0,%ymm6,%ymm0
 1090140:	vpaddq %ymm0,%ymm5,%ymm0
 1090144:	vextracti128 $0x1,%ymm0,%xmm1
 109014a:	vpaddq %xmm1,%xmm0,%xmm0
 109014e:	vpshufd $0xee,%xmm0,%xmm1
 1090153:	vpaddq %xmm1,%xmm0,%xmm0
 1090157:	vmovq  %xmm0,%rax
 109015c:	cmp    %r9,%r8
 109015f:	je     10901a9 <index_walk+0x349>
 1090161:	movabs $0x101010101010101,%r8
 109016b:	nopl   0x0(%rax,%rax,1)
 1090170:	mov    (%rcx,%rdx,1),%r9
 1090174:	mov    %rdi,%rdx
 1090177:	mov    %r9,%rdi
 109017a:	not    %rdi
 109017d:	add    %rdi,%rdi
 1090180:	and    %r9,%rdi
 1090183:	shr    $0x7,%rdi
 1090187:	and    %r8,%rdi
 109018a:	imul   %r8,%rdi
 109018e:	shr    $0x38,%rdi
 1090192:	sub    %rdi,%rax
 1090195:	add    $0x8,%rax
 1090199:	lea    0x8(%rdx),%rdi
 109019d:	cmp    %rsi,%rdi
 10901a0:	jbe    1090170 <index_walk+0x310>
 10901a2:	add    $0xfffffffffffffff8,%rdi
 10901a6:	mov    %rdi,%rdx
 10901a9:	mov    %rsi,%rdi
 10901ac:	sub    %rdx,%rdi
 10901af:	jbe    10904c0 <index_walk+0x660>
 10901b5:	cmp    $0x3,%rdi
 10901b9:	jbe    1090480 <index_walk+0x620>
 10901bf:	cmp    $0x10,%rdi
 10901c3:	jae    109032d <index_walk+0x4cd>
 10901c9:	xor    %r8d,%r8d
 10901cc:	jmp    109040f <index_walk+0x5af>
 10901d1:	mov    %rdi,%r9
 10901d4:	and    $0xfffffffffffffff0,%r9
 10901d8:	vmovq  %r8,%xmm0
 10901dd:	lea    (%rsi,%rcx,1),%r8
 10901e1:	add    $0xc,%r8
 10901e5:	vpxor  %xmm1,%xmm1,%xmm1
 10901e9:	xor    %r10d,%r10d
 10901ec:	vmovdqa -0x8e7c4(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 10901f4:	vpbroadcastq -0x890e5(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 10901fd:	vpxor  %xmm4,%xmm4,%xmm4
 1090201:	vpxor  %xmm5,%xmm5,%xmm5
 1090205:	data16 cs nopw 0x0(%rax,%rax,1)
 1090210:	vmovd  -0xc(%r8,%r10,1),%xmm6
 1090217:	vmovd  -0x8(%r8,%r10,1),%xmm7
 109021e:	vmovd  -0x4(%r8,%r10,1),%xmm8
 1090225:	vmovd  (%r8,%r10,1),%xmm9
 109022b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109022f:	vpmovzxbq %xmm6,%ymm6
 1090234:	vpand  %ymm3,%ymm6,%ymm6
 1090238:	vpaddq %ymm6,%ymm0,%ymm0
 109023c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1090240:	vpmovzxbq %xmm6,%ymm6
 1090245:	vpand  %ymm3,%ymm6,%ymm6
 1090249:	vpaddq %ymm6,%ymm1,%ymm1
 109024d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1090251:	vpmovzxbq %xmm6,%ymm6
 1090256:	vpand  %ymm3,%ymm6,%ymm6
 109025a:	vpaddq %ymm6,%ymm4,%ymm4
 109025e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1090262:	vpmovzxbq %xmm6,%ymm6
 1090267:	vpand  %ymm3,%ymm6,%ymm6
 109026b:	vpaddq %ymm6,%ymm5,%ymm5
 109026f:	add    $0x10,%r10
 1090273:	cmp    %r10,%r9
 1090276:	jne    1090210 <index_walk+0x3b0>
 1090278:	vpaddq %ymm0,%ymm1,%ymm0
 109027c:	vpaddq %ymm0,%ymm4,%ymm0
 1090280:	vpaddq %ymm0,%ymm5,%ymm0
 1090284:	vextracti128 $0x1,%ymm0,%xmm1
 109028a:	vpaddq %xmm1,%xmm0,%xmm0
 109028e:	vpshufd $0xee,%xmm0,%xmm1
 1090293:	vpaddq %xmm1,%xmm0,%xmm0
 1090297:	vmovq  %xmm0,%r8
 109029c:	cmp    %r9,%rdi
 109029f:	je     1090325 <index_walk+0x4c5>
 10902a5:	test   $0xc,%dil
 10902a9:	je     10904ce <index_walk+0x66e>
 10902af:	mov    %rdi,%r10
 10902b2:	and    $0xfffffffffffffffc,%r10
 10902b6:	vmovq  %r8,%xmm0
 10902bb:	lea    (%rcx,%rsi,1),%r8
 10902bf:	vmovdqa -0x8e897(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 10902c7:	vpbroadcastq -0x891b8(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 10902d0:	vmovd  (%r8,%r9,1),%xmm3
 10902d6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 10902da:	vpmovzxbq %xmm3,%ymm3
 10902df:	vpand  %ymm2,%ymm3,%ymm3
 10902e3:	vpaddq %ymm3,%ymm0,%ymm0
 10902e7:	add    $0x4,%r9
 10902eb:	cmp    %r9,%r10
 10902ee:	jne    10902d0 <index_walk+0x470>
 10902f0:	vextracti128 $0x1,%ymm0,%xmm1
 10902f6:	vpaddq %xmm1,%xmm0,%xmm0
 10902fa:	vpshufd $0xee,%xmm0,%xmm1
 10902ff:	vpaddq %xmm1,%xmm0,%xmm0
 1090303:	vmovq  %xmm0,%r8
 1090308:	cmp    %r10,%rdi
 109030b:	je     1090325 <index_walk+0x4c5>
 109030d:	add    %r10,%rsi
 1090310:	xor    %edi,%edi
 1090312:	cmpb   $0xc0,(%rcx,%rsi,1)
 1090316:	setge  %dil
 109031a:	add    %rdi,%r8
 109031d:	inc    %rsi
 1090320:	cmp    %rsi,%rdx
 1090323:	jne    1090310 <index_walk+0x4b0>
 1090325:	sub    %r8,%rax
 1090328:	jmp    10904c0 <index_walk+0x660>
 109032d:	mov    %rdi,%r8
 1090330:	and    $0xfffffffffffffff0,%r8
 1090334:	vmovq  %rax,%xmm0
 1090339:	lea    (%rdx,%rcx,1),%rax
 109033d:	add    $0xc,%rax
 1090341:	vpxor  %xmm1,%xmm1,%xmm1
 1090345:	xor    %r9d,%r9d
 1090348:	vmovdqa -0x8e920(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 1090350:	vpbroadcastq -0x89241(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 1090359:	vpxor  %xmm4,%xmm4,%xmm4
 109035d:	vpxor  %xmm5,%xmm5,%xmm5
 1090361:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1090370:	vmovd  -0xc(%rax,%r9,1),%xmm6
 1090377:	vmovd  -0x8(%rax,%r9,1),%xmm7
 109037e:	vmovd  -0x4(%rax,%r9,1),%xmm8
 1090385:	vmovd  (%rax,%r9,1),%xmm9
 109038b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109038f:	vpmovzxbq %xmm6,%ymm6
 1090394:	vpand  %ymm3,%ymm6,%ymm6
 1090398:	vpaddq %ymm6,%ymm0,%ymm0
 109039c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 10903a0:	vpmovzxbq %xmm6,%ymm6
 10903a5:	vpand  %ymm3,%ymm6,%ymm6
 10903a9:	vpaddq %ymm6,%ymm1,%ymm1
 10903ad:	vpcmpgtb %xmm2,%xmm8,%xmm6
 10903b1:	vpmovzxbq %xmm6,%ymm6
 10903b6:	vpand  %ymm3,%ymm6,%ymm6
 10903ba:	vpaddq %ymm6,%ymm4,%ymm4
 10903be:	vpcmpgtb %xmm2,%xmm9,%xmm6
 10903c2:	vpmovzxbq %xmm6,%ymm6
 10903c7:	vpand  %ymm3,%ymm6,%ymm6
 10903cb:	vpaddq %ymm6,%ymm5,%ymm5
 10903cf:	add    $0x10,%r9
 10903d3:	cmp    %r9,%r8
 10903d6:	jne    1090370 <index_walk+0x510>
 10903d8:	vpaddq %ymm0,%ymm1,%ymm0
 10903dc:	vpaddq %ymm0,%ymm4,%ymm0
 10903e0:	vpaddq %ymm0,%ymm5,%ymm0
 10903e4:	vextracti128 $0x1,%ymm0,%xmm1
 10903ea:	vpaddq %xmm1,%xmm0,%xmm0
 10903ee:	vpshufd $0xee,%xmm0,%xmm1
 10903f3:	vpaddq %xmm1,%xmm0,%xmm0
 10903f7:	vmovq  %xmm0,%rax
 10903fc:	cmp    %r8,%rdi
 10903ff:	je     10904c0 <index_walk+0x660>
 1090405:	test   $0xc,%dil
 1090409:	je     10904d6 <index_walk+0x676>
 109040f:	mov    %esi,%r9d
 1090412:	and    $0x3,%r9d
 1090416:	sub    %r9,%rdi
 1090419:	vmovq  %rax,%xmm0
 109041e:	mov    %rsi,%rax
 1090421:	and    $0xfffffffffffffffc,%rax
 1090425:	add    %rdx,%r8
 1090428:	vmovdqa -0x8ea00(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1090430:	vpbroadcastq -0x89321(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1090439:	nopl   0x0(%rax)
 1090440:	vmovd  (%rcx,%r8,1),%xmm3
 1090446:	vpcmpgtb %xmm1,%xmm3,%xmm3
 109044a:	vpmovzxbq %xmm3,%ymm3
 109044f:	vpand  %ymm2,%ymm3,%ymm3
 1090453:	vpaddq %ymm3,%ymm0,%ymm0
 1090457:	add    $0x4,%r8
 109045b:	cmp    %r8,%rax
 109045e:	jne    1090440 <index_walk+0x5e0>
 1090460:	vextracti128 $0x1,%ymm0,%xmm1
 1090466:	vpaddq %xmm1,%xmm0,%xmm0
 109046a:	vpshufd $0xee,%xmm0,%xmm1
 109046f:	vpaddq %xmm1,%xmm0,%xmm0
 1090473:	vmovq  %xmm0,%rax
 1090478:	test   %r9,%r9
 109047b:	je     10904c0 <index_walk+0x660>
 109047d:	add    %rdi,%rdx
 1090480:	xor    %edi,%edi
 1090482:	cmpb   $0xc0,(%rcx,%rdx,1)
 1090486:	setge  %dil
 109048a:	add    %rdi,%rax
 109048d:	inc    %rdx
 1090490:	cmp    %rdx,%rsi
 1090493:	jne    1090480 <index_walk+0x620>
 1090495:	jmp    10904c0 <index_walk+0x660>
 1090497:	mov    0x14(%rdi),%eax
 109049a:	add    %rax,%rsi
 109049d:	mov    %rdi,%r15
 10904a0:	mov    %rbx,%rdi
 10904a3:	call   10904e0 <index_at>
 10904a8:	mov    %rax,%r14
 10904ab:	mov    0x14(%r15),%esi
 10904af:	mov    %rbx,%rdi
 10904b2:	call   10904e0 <index_at>
 10904b7:	mov    %rax,%rcx
 10904ba:	mov    %r14,%rax
 10904bd:	sub    %rcx,%rax
 10904c0:	add    $0x8,%rsp
 10904c4:	pop    %rbx
 10904c5:	pop    %r14
 10904c7:	pop    %r15
 10904c9:	pop    %rbp
 10904ca:	vzeroupper
 10904cd:	ret
 10904ce:	add    %r9,%rsi
 10904d1:	jmp    1090310 <index_walk+0x4b0>
 10904d6:	add    %r8,%rdx
 10904d9:	jmp    1090480 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
