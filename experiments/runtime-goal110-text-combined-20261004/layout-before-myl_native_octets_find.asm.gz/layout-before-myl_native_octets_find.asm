
/home/epentland/ai/canopy/mylang-worktrees/goal110-presize-ready-20261004/.mylang-cache/goal110-presize-ready-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001092440 <myl_native_octets_find>:
 1092440:	test   %rcx,%rcx
 1092443:	je     109249a <myl_native_octets_find+0x5a>
 1092445:	push   %rbp
 1092446:	mov    %rsp,%rbp
 1092449:	push   %r15
 109244b:	push   %r14
 109244d:	push   %r13
 109244f:	push   %r12
 1092451:	push   %rbx
 1092452:	sub    $0x18,%rsp
 1092456:	mov    $0xffffffffffffffff,%rax
 109245d:	mov    %rsi,%r14
 1092460:	sub    %rcx,%r14
 1092463:	jb     1092705 <myl_native_octets_find+0x2c5>
 1092469:	mov    %rsi,%rbx
 109246c:	cmp    $0x1,%rcx
 1092470:	jne    109249d <myl_native_octets_find+0x5d>
 1092472:	movzbl (%rdx),%esi
 1092475:	mov    %rdi,%r14
 1092478:	mov    %rbx,%rdx
 109247b:	call   10abca0 <memchr@plt>
 1092480:	mov    %rax,%rcx
 1092483:	mov    %rax,%rdx
 1092486:	sub    %r14,%rdx
 1092489:	xor    %eax,%eax
 109248b:	cmp    $0x1,%rcx
 109248f:	sbb    %rax,%rax
 1092492:	or     %rdx,%rax
 1092495:	jmp    1092705 <myl_native_octets_find+0x2c5>
 109249a:	xor    %eax,%eax
 109249c:	ret
 109249d:	mov    %rcx,-0x30(%rbp)
 10924a1:	mov    %rdx,%r15
 10924a4:	movzbl (%rdx),%r12d
 10924a8:	lea    0x1(%r14),%rdx
 10924ac:	mov    %rdi,%r13
 10924af:	mov    %r12d,%esi
 10924b2:	call   10abca0 <memchr@plt>
 10924b7:	test   %rax,%rax
 10924ba:	je     10926fe <myl_native_octets_find+0x2be>
 10924c0:	mov    %r13,%rcx
 10924c3:	lea    (%r14,%r13,1),%r10
 10924c7:	lea    (%r14,%r13,1),%r11
 10924cb:	inc    %r11
 10924ce:	lea    0x1(%rax),%rdi
 10924d2:	mov    $0x1,%edx
 10924d7:	mov    -0x30(%rbp),%rsi
 10924db:	mov    %r15,%r8
 10924de:	xchg   %ax,%ax
 10924e0:	movzbl (%rax,%rdx,1),%r9d
 10924e5:	cmp    (%r8,%rdx,1),%r9b
 10924e9:	jne    10924fb <myl_native_octets_find+0xbb>
 10924eb:	inc    %rdx
 10924ee:	cmp    %rdx,%rsi
 10924f1:	jne    10924e0 <myl_native_octets_find+0xa0>
 10924f3:	sub    %rcx,%rax
 10924f6:	jmp    1092705 <myl_native_octets_find+0x2c5>
 10924fb:	cmp    %r10,%rax
 10924fe:	je     10926fe <myl_native_octets_find+0x2be>
 1092504:	mov    %r10,-0x38(%rbp)
 1092508:	mov    %r11,%r14
 109250b:	mov    %r11,%rdx
 109250e:	sub    %rdi,%rdx
 1092511:	mov    %r12d,%esi
 1092514:	call   10abca0 <memchr@plt>
 1092519:	test   %rax,%rax
 109251c:	je     10926fe <myl_native_octets_find+0x2be>
 1092522:	lea    0x1(%rax),%rdi
 1092526:	mov    $0x1,%edx
 109252b:	mov    %r13,%rcx
 109252e:	mov    -0x30(%rbp),%rsi
 1092532:	mov    %r15,%r8
 1092535:	mov    -0x38(%rbp),%r10
 1092539:	mov    %r14,%r11
 109253c:	nopl   0x0(%rax)
 1092540:	movzbl (%rax,%rdx,1),%r9d
 1092545:	cmp    (%r8,%rdx,1),%r9b
 1092549:	jne    1092555 <myl_native_octets_find+0x115>
 109254b:	inc    %rdx
 109254e:	cmp    %rdx,%rsi
 1092551:	jne    1092540 <myl_native_octets_find+0x100>
 1092553:	jmp    10924f3 <myl_native_octets_find+0xb3>
 1092555:	cmp    %r10,%rax
 1092558:	je     10926fe <myl_native_octets_find+0x2be>
 109255e:	mov    %r11,%rdx
 1092561:	sub    %rdi,%rdx
 1092564:	mov    %r12d,%esi
 1092567:	call   10abca0 <memchr@plt>
 109256c:	test   %rax,%rax
 109256f:	je     10926fe <myl_native_octets_find+0x2be>
 1092575:	lea    0x1(%rax),%rdi
 1092579:	mov    $0x1,%edx
 109257e:	mov    %r13,%rcx
 1092581:	mov    -0x30(%rbp),%rsi
 1092585:	mov    %r15,%r8
 1092588:	mov    -0x38(%rbp),%r10
 109258c:	mov    %r14,%r11
 109258f:	movzbl (%rax,%rdx,1),%r9d
 1092594:	cmp    (%r8,%rdx,1),%r9b
 1092598:	jne    10925a7 <myl_native_octets_find+0x167>
 109259a:	inc    %rdx
 109259d:	cmp    %rdx,%rsi
 10925a0:	jne    109258f <myl_native_octets_find+0x14f>
 10925a2:	jmp    10924f3 <myl_native_octets_find+0xb3>
 10925a7:	cmp    %r10,%rax
 10925aa:	je     10926fe <myl_native_octets_find+0x2be>
 10925b0:	mov    %r11,%rdx
 10925b3:	sub    %rdi,%rdx
 10925b6:	mov    %r12d,%esi
 10925b9:	call   10abca0 <memchr@plt>
 10925be:	test   %rax,%rax
 10925c1:	je     10926fe <myl_native_octets_find+0x2be>
 10925c7:	lea    0x1(%rax),%rdi
 10925cb:	mov    $0x1,%edx
 10925d0:	mov    %r13,%rcx
 10925d3:	mov    -0x30(%rbp),%rsi
 10925d7:	mov    %r15,%r8
 10925da:	mov    -0x38(%rbp),%r10
 10925de:	mov    %r14,%r11
 10925e1:	movzbl (%rax,%rdx,1),%r9d
 10925e6:	cmp    (%r8,%rdx,1),%r9b
 10925ea:	jne    10925f9 <myl_native_octets_find+0x1b9>
 10925ec:	inc    %rdx
 10925ef:	cmp    %rdx,%rsi
 10925f2:	jne    10925e1 <myl_native_octets_find+0x1a1>
 10925f4:	jmp    10924f3 <myl_native_octets_find+0xb3>
 10925f9:	cmp    %r10,%rax
 10925fc:	je     10926fe <myl_native_octets_find+0x2be>
 1092602:	mov    %r11,%rdx
 1092605:	sub    %rdi,%rdx
 1092608:	mov    %r12d,%esi
 109260b:	call   10abca0 <memchr@plt>
 1092610:	test   %rax,%rax
 1092613:	je     10926fe <myl_native_octets_find+0x2be>
 1092619:	lea    0x1(%rax),%rdi
 109261d:	mov    $0x1,%ecx
 1092622:	mov    -0x30(%rbp),%rdx
 1092626:	mov    %r15,%rsi
 1092629:	movzbl (%rax,%rcx,1),%r8d
 109262e:	cmp    (%rsi,%rcx,1),%r8b
 1092632:	jne    1092644 <myl_native_octets_find+0x204>
 1092634:	inc    %rcx
 1092637:	cmp    %rcx,%rdx
 109263a:	jne    1092629 <myl_native_octets_find+0x1e9>
 109263c:	mov    %r13,%rcx
 109263f:	jmp    10924f3 <myl_native_octets_find+0xb3>
 1092644:	cmp    -0x38(%rbp),%rax
 1092648:	je     10926fe <myl_native_octets_find+0x2be>
 109264e:	mov    %r14,%rdx
 1092651:	sub    %rdi,%rdx
 1092654:	mov    %r12d,%esi
 1092657:	call   10abca0 <memchr@plt>
 109265c:	test   %rax,%rax
 109265f:	je     10926fe <myl_native_octets_find+0x2be>
 1092665:	lea    0x1(%rax),%rdi
 1092669:	mov    $0x1,%ecx
 109266e:	mov    -0x30(%rbp),%rdx
 1092672:	mov    %r15,%rsi
 1092675:	movzbl (%rax,%rcx,1),%r8d
 109267a:	cmp    (%rsi,%rcx,1),%r8b
 109267e:	jne    109268a <myl_native_octets_find+0x24a>
 1092680:	inc    %rcx
 1092683:	cmp    %rcx,%rdx
 1092686:	jne    1092675 <myl_native_octets_find+0x235>
 1092688:	jmp    109263c <myl_native_octets_find+0x1fc>
 109268a:	cmp    -0x38(%rbp),%rax
 109268e:	je     10926fe <myl_native_octets_find+0x2be>
 1092690:	mov    %r14,%rdx
 1092693:	sub    %rdi,%rdx
 1092696:	mov    %r12d,%esi
 1092699:	call   10abca0 <memchr@plt>
 109269e:	test   %rax,%rax
 10926a1:	je     10926fe <myl_native_octets_find+0x2be>
 10926a3:	lea    0x1(%rax),%rdi
 10926a7:	mov    $0x1,%ecx
 10926ac:	movzbl (%rax,%rcx,1),%edx
 10926b0:	cmp    (%r15,%rcx,1),%dl
 10926b4:	jne    10926c4 <myl_native_octets_find+0x284>
 10926b6:	inc    %rcx
 10926b9:	cmp    %rcx,-0x30(%rbp)
 10926bd:	jne    10926ac <myl_native_octets_find+0x26c>
 10926bf:	jmp    109263c <myl_native_octets_find+0x1fc>
 10926c4:	cmp    -0x38(%rbp),%rax
 10926c8:	je     10926fe <myl_native_octets_find+0x2be>
 10926ca:	sub    %rdi,%r14
 10926cd:	mov    %r12d,%esi
 10926d0:	mov    %r14,%rdx
 10926d3:	call   10abca0 <memchr@plt>
 10926d8:	test   %rax,%rax
 10926db:	je     10926fe <myl_native_octets_find+0x2be>
 10926dd:	lea    0x1(%rax),%rdi
 10926e1:	mov    $0x1,%ecx
 10926e6:	movzbl (%rax,%rcx,1),%edx
 10926ea:	cmp    (%r15,%rcx,1),%dl
 10926ee:	jne    1092714 <myl_native_octets_find+0x2d4>
 10926f0:	inc    %rcx
 10926f3:	cmp    %rcx,-0x30(%rbp)
 10926f7:	jne    10926e6 <myl_native_octets_find+0x2a6>
 10926f9:	jmp    109263c <myl_native_octets_find+0x1fc>
 10926fe:	mov    $0xffffffffffffffff,%rax
 1092705:	add    $0x18,%rsp
 1092709:	pop    %rbx
 109270a:	pop    %r12
 109270c:	pop    %r13
 109270e:	pop    %r14
 1092710:	pop    %r15
 1092712:	pop    %rbp
 1092713:	ret
 1092714:	cmp    -0x38(%rbp),%rax
 1092718:	mov    $0xffffffffffffffff,%rax
 109271f:	je     1092705 <myl_native_octets_find+0x2c5>
 1092721:	add    %r13,%rbx
 1092724:	sub    %rdi,%rbx
 1092727:	mov    %rbx,%rsi
 109272a:	mov    %r15,%rdx
 109272d:	mov    -0x30(%rbp),%rcx
 1092731:	call   10abcb0 <memmem@plt>
 1092736:	mov    %rax,%rcx
 1092739:	mov    %rax,%rdx
 109273c:	sub    %r13,%rdx
 109273f:	jmp    1092489 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
