
.mylang-cache/goal110-text-combined/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001074df0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>:
 1074df0:	push   %rbp
 1074df1:	push   %r15
 1074df3:	push   %r14
 1074df5:	push   %r13
 1074df7:	push   %r12
 1074df9:	push   %rbx
 1074dfa:	sub    $0x38,%rsp
 1074dfe:	mov    %rdi,%r14
 1074e01:	mov    0x2c8(%rdi),%ebp
 1074e07:	mov    %rsi,0x10(%rsp)
 1074e0c:	mov    0x8(%rsi),%r15
 1074e10:	cmp    $0xffffffffffffffff,%r15
 1074e14:	je     107546c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x67c>
 1074e1a:	lea    0x258(%r14),%rbx
 1074e21:	mov    0x268(%r14),%rax
 1074e28:	mov    %rax,0x18(%rsp)
 1074e2d:	lea    0x10(%rsp),%rax
 1074e32:	mov    %rax,0x20(%rsp)
 1074e37:	movq   $0x1031628,0x28(%rsp)
 1074e40:	lea    0x18(%rsp),%r12
 1074e45:	mov    %r12,0x268(%r14)
 1074e4c:	mov    $0x1031698,%esi
 1074e51:	mov    %rbx,%rdi
 1074e54:	mov    %r15,%rdx
 1074e57:	call   108f590 <myl_native_list_new>
 1074e5c:	test   %rax,%rax
 1074e5f:	je     1074ea8 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb8>
 1074e61:	mov    0x20(%rax),%rdi
 1074e65:	test   %rdi,%rdi
 1074e68:	je     1074ea5 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb5>
 1074e6a:	mov    0x10(%rsp),%rsi
 1074e6f:	mov    0x8(%rsi),%rdx
 1074e73:	lea    -0x1(%rdx),%rcx
 1074e77:	cmp    %r15,%rcx
 1074e7a:	jae    1074ea5 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb5>
 1074e7c:	testb  $0x4,0x10(%rsi)
 1074e80:	jne    1074e8b <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x9b>
 1074e82:	mov    %rax,%r13
 1074e85:	add    $0x18,%rsi
 1074e89:	jmp    1074e9d <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xad>
 1074e8b:	mov    %rax,%r13
 1074e8e:	mov    0x18(%rsi),%rax
 1074e92:	mov    0x14(%rsi),%ecx
 1074e95:	lea    (%rax,%rcx,1),%rsi
 1074e99:	add    $0x18,%rsi
 1074e9d:	call   10acc10 <memcpy@plt>
 1074ea2:	mov    %r13,%rax
 1074ea5:	mov    %r15,(%rax)
 1074ea8:	cmp    %r12,0x268(%r14)
 1074eaf:	jne    1074ebd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xcd>
 1074eb1:	mov    0x18(%rsp),%rcx
 1074eb6:	mov    %rcx,0x268(%r14)
 1074ebd:	test   %rax,%rax
 1074ec0:	je     107546c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x67c>
 1074ec6:	movabs $0x5000000000000000,%rcx
 1074ed0:	mov    %rax,(%rsp)
 1074ed4:	mov    %rax,0x8(%rsp)
 1074ed9:	mov    -0x10(%rax),%rdx
 1074edd:	lea    0x1(%rcx),%rsi
 1074ee1:	test   %rsi,%rdx
 1074ee4:	je     1074f41 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x151>
 1074ee6:	test   %rcx,%rdx
 1074ee9:	je     1074f23 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x133>
 1074eeb:	mov    %rsp,%rdx
 1074eee:	lea    0x8(%rsp),%rcx
 1074ef3:	mov    $0x100bb28,%esi
 1074ef8:	mov    %rbx,%rdi
 1074efb:	mov    %ebp,%r8d
 1074efe:	call   10a7a00 <myl_rc_native_take>
 1074f03:	test   %eax,%eax
 1074f05:	je     10750a9 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x2b9>
 1074f0b:	mov    (%rsp),%rax
 1074f0f:	movabs $0x4000000000000002,%r12
 1074f19:	mov    (%rax),%rsi
 1074f1c:	test   %rax,%rax
 1074f1f:	jne    1074f5c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x16c>
 1074f21:	jmp    1074f73 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 1074f23:	lea    0x8(%rsp),%rcx
 1074f28:	mov    %rsp,%rdx
 1074f2b:	mov    %rdx,%rsi
 1074f2e:	sub    %rcx,%rsi
 1074f31:	sub    %rdx,%rcx
 1074f34:	cmovb  %rsi,%rcx
 1074f38:	test   %rcx,%rcx
 1074f3b:	je     1074eeb <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xfb>
 1074f3d:	mov    %rax,(%rsp)
 1074f41:	movq   $0x0,0x8(%rsp)
 1074f4a:	movabs $0x4000000000000002,%r12
 1074f54:	mov    (%rax),%rsi
 1074f57:	test   %rax,%rax
 1074f5a:	je     1074f73 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 1074f5c:	test   %r12,-0x10(%rax)
 1074f60:	jne    1074f73 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 1074f62:	mov    -0x18(%rax),%rcx
 1074f66:	inc    %rcx
 1074f69:	je     1075433 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x643>
 1074f6f:	mov    %rcx,-0x18(%rax)
 1074f73:	mov    %rax,(%rsp)
 1074f77:	lea    -0x10(%rsi),%rdx
 1074f7b:	movabs $0xffffffffffff1,%rcx
 1074f85:	cmp    %rcx,%rdx
 1074f88:	jae    1074fa5 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x1b5>
 1074f8a:	mov    0x20(%rax),%rcx
 1074f8e:	mov    %edx,%edi
 1074f90:	not    %edi
 1074f92:	vpxor  %xmm0,%xmm0,%xmm0
 1074f96:	test   $0x30,%dil
 1074f9a:	jne    1074fce <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x1de>
 1074f9c:	vpxor  %xmm1,%xmm1,%xmm1
 1074fa0:	mov    %rsi,%r8
 1074fa3:	jmp    1075020 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x230>
 1074fa5:	test   %rsi,%rsi
 1074fa8:	jle    10750f5 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x305>
 1074fae:	mov    0x20(%rax),%rdi
 1074fb2:	cmp    $0xf,%rsi
 1074fb6:	ja     10750fd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x30d>
 1074fbc:	mov    $0x1,%r8d
 1074fc2:	xor    %edx,%edx
 1074fc4:	xor    %ecx,%ecx
 1074fc6:	mov    %rsi,%r15
 1074fc9:	jmp    1075336 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x546>
 1074fce:	mov    %edx,%edi
 1074fd0:	shr    $0x4,%edi
 1074fd3:	inc    %edi
 1074fd5:	and    $0x3,%edi
 1074fd8:	vpxor  %xmm2,%xmm2,%xmm2
 1074fdc:	mov    %rdi,%r8
 1074fdf:	mov    %rcx,%r9
 1074fe2:	vpxor  %xmm1,%xmm1,%xmm1
 1074fe6:	cs nopw 0x0(%rax,%rax,1)
 1074ff0:	vpsadbw (%r9),%xmm2,%xmm3
 1074ff5:	vpaddq %xmm1,%xmm3,%xmm1
 1074ff9:	add    $0x10,%r9
 1074ffd:	dec    %r8
 1075000:	jne    1074ff0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x200>
 1075002:	shl    $0x4,%edi
 1075005:	add    %rdi,%rcx
 1075008:	mov    %rsi,%r8
 107500b:	sub    %rdi,%r8
 107500e:	cmp    $0x30,%rdx
 1075012:	jb     1075051 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x261>
 1075014:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1075020:	vpsadbw (%rcx),%xmm0,%xmm2
 1075024:	vpaddq %xmm1,%xmm2,%xmm1
 1075028:	vpsadbw 0x10(%rcx),%xmm0,%xmm2
 107502d:	vpsadbw 0x20(%rcx),%xmm0,%xmm3
 1075032:	vpaddq %xmm2,%xmm3,%xmm2
 1075036:	vpaddq %xmm1,%xmm2,%xmm1
 107503a:	vpsadbw 0x30(%rcx),%xmm0,%xmm2
 107503f:	vpaddq %xmm1,%xmm2,%xmm1
 1075043:	add    $0x40,%rcx
 1075047:	add    $0xffffffffffffffc0,%r8
 107504b:	cmp    $0xf,%r8
 107504f:	ja     1075020 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x230>
 1075051:	vpshufd $0xee,%xmm1,%xmm0
 1075056:	vpaddq %xmm0,%xmm1,%xmm0
 107505a:	vmovq  %xmm0,%r15
 107505f:	test   %r8,%r8
 1075062:	je     107532a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 1075068:	mov    %r8,%r10
 107506b:	and    $0x3,%r10
 107506f:	je     10751cd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x3dd>
 1075075:	xor    %edx,%edx
 1075077:	nopw   0x0(%rax,%rax,1)
 1075080:	movzbl (%rcx,%rdx,1),%edi
 1075084:	add    %rdi,%r15
 1075087:	inc    %rdx
 107508a:	cmp    %rdx,%r10
 107508d:	jne    1075080 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x290>
 107508f:	mov    %r8,%rdx
 1075092:	and    $0xfffffffffffffffc,%rdx
 1075096:	lea    (%rcx,%r10,1),%rdi
 107509a:	cmp    $0x4,%r8
 107509e:	jae    10751dd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x3ed>
 10750a4:	jmp    107532a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 10750a9:	mov    0x1860(%r14),%rax
 10750b0:	test   %rax,%rax
 10750b3:	je     1075455 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x665>
 10750b9:	mov    0x124(%rax),%r15d
 10750c0:	movl   $0x0,0x124(%rax)
 10750ca:	test   %r15,%r15
 10750cd:	je     10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10750d3:	cmp    $0x1,%r15d
 10750d7:	jne    107543a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x64a>
 10750dd:	mov    $0x1007df2,%esi
 10750e2:	cmpl   $0x0,0x2c4(%r14)
 10750ea:	je     1075440 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x650>
 10750f0:	jmp    1075448 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x658>
 10750f5:	mov    %rsi,%r15
 10750f8:	jmp    10753a9 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 10750fd:	movabs $0x7ffffffffffffff0,%rcx
 1075107:	and    %rsi,%rcx
 107510a:	vmovq  %rsi,%xmm0
 107510f:	vpxor  %xmm1,%xmm1,%xmm1
 1075113:	xor    %edx,%edx
 1075115:	vpxor  %xmm5,%xmm5,%xmm5
 1075119:	vpxor  %xmm6,%xmm6,%xmm6
 107511d:	vpxor  %xmm7,%xmm7,%xmm7
 1075121:	vpxor  %xmm2,%xmm2,%xmm2
 1075125:	vpxor  %xmm3,%xmm3,%xmm3
 1075129:	vpxor  %xmm4,%xmm4,%xmm4
 107512d:	nopl   (%rax)
 1075130:	vpmovzxbq (%rdi,%rdx,1),%ymm8
 1075136:	vpmovzxbq 0x4(%rdi,%rdx,1),%ymm9
 107513d:	vpmovzxbq 0x8(%rdi,%rdx,1),%ymm10
 1075144:	vpmovzxbq 0xc(%rdi,%rdx,1),%ymm11
 107514b:	vpaddq %ymm1,%ymm8,%ymm1
 107514f:	vpaddq %ymm5,%ymm9,%ymm5
 1075153:	vpaddq %ymm6,%ymm10,%ymm6
 1075157:	vpaddq %ymm7,%ymm11,%ymm7
 107515b:	vpaddq %ymm0,%ymm8,%ymm0
 107515f:	vpaddq %ymm2,%ymm9,%ymm2
 1075163:	vpaddq %ymm3,%ymm10,%ymm3
 1075167:	vpaddq %ymm4,%ymm11,%ymm4
 107516b:	add    $0x10,%rdx
 107516f:	cmp    %rdx,%rcx
 1075172:	jne    1075130 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x340>
 1075174:	vpaddq %ymm1,%ymm5,%ymm1
 1075178:	vpaddq %ymm1,%ymm6,%ymm1
 107517c:	vpaddq %ymm1,%ymm7,%ymm1
 1075180:	vextracti128 $0x1,%ymm1,%xmm5
 1075186:	vpaddq %xmm5,%xmm1,%xmm1
 107518a:	vpshufd $0xee,%xmm1,%xmm5
 107518f:	vpaddq %xmm5,%xmm1,%xmm1
 1075193:	vmovq  %xmm1,%rdx
 1075198:	vpaddq %ymm0,%ymm2,%ymm0
 107519c:	vpaddq %ymm0,%ymm3,%ymm0
 10751a0:	vpaddq %ymm0,%ymm4,%ymm0
 10751a4:	vextracti128 $0x1,%ymm0,%xmm1
 10751aa:	vpaddq %xmm1,%xmm0,%xmm0
 10751ae:	vpshufd $0xee,%xmm0,%xmm1
 10751b3:	vpaddq %xmm1,%xmm0,%xmm0
 10751b7:	vmovq  %xmm0,%r15
 10751bc:	cmp    %rcx,%rsi
 10751bf:	jne    107532f <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53f>
 10751c5:	mov    %rsi,%rcx
 10751c8:	jmp    1075369 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x579>
 10751cd:	mov    %rcx,%rdi
 10751d0:	mov    %r8,%rdx
 10751d3:	cmp    $0x4,%r8
 10751d7:	jb     107532a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 10751dd:	lea    -0x4(%rdx),%r8
 10751e1:	cmp    $0x1c,%r8
 10751e5:	jb     10752fd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x50d>
 10751eb:	shr    $0x2,%r8
 10751ef:	inc    %r8
 10751f2:	movabs $0x7ffffffffffffff0,%r9
 10751fc:	or     $0x8,%r9
 1075200:	and    %r8,%r9
 1075203:	lea    0x0(,%r9,4),%r11
 107520b:	lea    (%rdi,%r9,4),%rdi
 107520f:	sub    %r11,%rdx
 1075212:	vmovq  %r15,%xmm4
 1075217:	add    %r10,%rcx
 107521a:	add    $0x10,%rcx
 107521e:	vpxor  %xmm5,%xmm5,%xmm5
 1075222:	xor    %r10d,%r10d
 1075225:	vmovd  -0x7388d(%rip),%xmm0        # 10019a0 <__abi_tag+0x16a4>
 107522d:	vmovd  -0x73845(%rip),%xmm1        # 10019f0 <__abi_tag+0x16f4>
 1075235:	vmovd  -0x738bd(%rip),%xmm2        # 1001980 <__abi_tag+0x1684>
 107523d:	vmovd  -0x73925(%rip),%xmm3        # 1001920 <__abi_tag+0x1624>
 1075245:	data16 cs nopw 0x0(%rax,%rax,1)
 1075250:	vmovdqu -0x10(%rcx,%r10,4),%xmm6
 1075257:	vmovdqu (%rcx,%r10,4),%xmm7
 107525d:	vpshufb %xmm0,%xmm6,%xmm8
 1075262:	vpshufb %xmm1,%xmm6,%xmm9
 1075267:	vpshufb %xmm2,%xmm6,%xmm10
 107526c:	vpshufb %xmm3,%xmm6,%xmm6
 1075271:	vpshufb %xmm0,%xmm7,%xmm11
 1075276:	vpshufb %xmm1,%xmm7,%xmm12
 107527b:	vpshufb %xmm2,%xmm7,%xmm13
 1075280:	vpshufb %xmm3,%xmm7,%xmm7
 1075285:	vpmovzxbq %xmm8,%ymm8
 107528a:	vpaddq %ymm4,%ymm8,%ymm4
 107528e:	vpmovzxbq %xmm11,%ymm8
 1075293:	vpaddq %ymm5,%ymm8,%ymm5
 1075297:	vpmovzxbq %xmm9,%ymm8
 107529c:	vpmovzxbq %xmm12,%ymm9
 10752a1:	vpmovzxbq %xmm10,%ymm10
 10752a6:	vpaddq %ymm10,%ymm8,%ymm8
 10752ab:	vpaddq %ymm4,%ymm8,%ymm4
 10752af:	vpmovzxbq %xmm13,%ymm8
 10752b4:	vpaddq %ymm8,%ymm9,%ymm8
 10752b9:	vpaddq %ymm5,%ymm8,%ymm5
 10752bd:	vpmovzxbq %xmm6,%ymm6
 10752c2:	vpaddq %ymm6,%ymm4,%ymm4
 10752c6:	vpmovzxbq %xmm7,%ymm6
 10752cb:	vpaddq %ymm6,%ymm5,%ymm5
 10752cf:	add    $0x8,%r10
 10752d3:	cmp    %r10,%r9
 10752d6:	jne    1075250 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x460>
 10752dc:	vpaddq %ymm4,%ymm5,%ymm0
 10752e0:	vextracti128 $0x1,%ymm0,%xmm1
 10752e6:	vpaddq %xmm1,%xmm0,%xmm0
 10752ea:	vpshufd $0xee,%xmm0,%xmm1
 10752ef:	vpaddq %xmm1,%xmm0,%xmm0
 10752f3:	vmovq  %xmm0,%r15
 10752f8:	cmp    %r9,%r8
 10752fb:	je     107532a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 10752fd:	xor    %ecx,%ecx
 10752ff:	vpxor  %xmm0,%xmm0,%xmm0
 1075303:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1075310:	vmovd  (%rdi,%rcx,1),%xmm1
 1075315:	vpsadbw %xmm0,%xmm1,%xmm1
 1075319:	vmovq  %xmm1,%r8
 107531e:	add    %r8,%r15
 1075321:	add    $0x4,%rcx
 1075325:	cmp    %rcx,%rdx
 1075328:	jne    1075310 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x520>
 107532a:	add    %rsi,%r15
 107532d:	jmp    10753a9 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 107532f:	mov    %rcx,%r8
 1075332:	or     $0x1,%r8
 1075336:	lea    (%rdi,%rcx,1),%r9
 107533a:	mov    %rsi,%r10
 107533d:	sub    %rcx,%r10
 1075340:	xor    %ecx,%ecx
 1075342:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1075350:	movzbl (%r9,%rcx,1),%r11d
 1075355:	add    %r11,%rdx
 1075358:	add    %r11,%r15
 107535b:	inc    %rcx
 107535e:	cmp    %rcx,%r10
 1075361:	jne    1075350 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x560>
 1075363:	add    %r8,%rcx
 1075366:	dec    %rcx
 1075369:	mov    $0xffffffff,%r8d
 107536f:	cmp    %r8,%rcx
 1075372:	setb   %cl
 1075375:	lea    (%rdx,%rsi,1),%r8
 1075379:	or     %rdx,%r8
 107537c:	setns  %dl
 107537f:	test   %dl,%cl
 1075381:	cmove  %rsi,%r15
 1075385:	jne    10753a9 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 1075387:	xor    %r8d,%r8d
 107538a:	mov    %rsi,%rdx
 107538d:	mov    %rsi,%r15
 1075390:	movzbl (%rdi,%r8,1),%ecx
 1075395:	add    %rcx,%r15
 1075398:	jo     107545f <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x66f>
 107539e:	inc    %r8
 10753a1:	mov    %r15,%rdx
 10753a4:	cmp    %r8,%rsi
 10753a7:	jne    1075390 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5a0>
 10753a9:	test   %rax,%rax
 10753ac:	je     10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10753ae:	test   %r12,-0x10(%rax)
 10753b2:	jne    10753c8 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5d8>
 10753b4:	mov    -0x18(%rax),%rcx
 10753b8:	dec    %rcx
 10753bb:	jne    10753c4 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5d4>
 10753bd:	cmpq   $0x0,-0x20(%rax)
 10753c2:	je     10753f7 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x607>
 10753c4:	mov    %rcx,-0x18(%rax)
 10753c8:	test   %r12,-0x10(%rax)
 10753cc:	jne    10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10753ce:	mov    -0x20(%rax),%rcx
 10753d2:	dec    %rcx
 10753d5:	jne    10753de <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5ee>
 10753d7:	cmpq   $0x0,-0x18(%rax)
 10753dc:	je     107541b <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x62b>
 10753de:	mov    %rcx,-0x20(%rax)
 10753e2:	mov    %r15,%rax
 10753e5:	add    $0x38,%rsp
 10753e9:	pop    %rbx
 10753ea:	pop    %r12
 10753ec:	pop    %r13
 10753ee:	pop    %r14
 10753f0:	pop    %r15
 10753f2:	pop    %rbp
 10753f3:	vzeroupper
 10753f6:	ret
 10753f7:	mov    %rbx,%rdi
 10753fa:	mov    %rax,%rsi
 10753fd:	mov    %rax,%r14
 1075400:	vzeroupper
 1075403:	call   109b5c0 <myl_rc_hold_edge_release>
 1075408:	mov    %rbx,%rdi
 107540b:	call   109e5e0 <myl_rc_drain>
 1075410:	mov    %r14,%rax
 1075413:	test   %r12,-0x10(%rax)
 1075417:	jne    10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 1075419:	jmp    10753ce <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5de>
 107541b:	mov    %rbx,%rdi
 107541e:	mov    %rax,%rsi
 1075421:	vzeroupper
 1075424:	call   109b460 <myl_rc_edge_release>
 1075429:	mov    %rbx,%rdi
 107542c:	call   109e5e0 <myl_rc_drain>
 1075431:	jmp    10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 1075433:	mov    $0x1007dbf,%esi
 1075438:	jmp    1075448 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x658>
 107543a:	cmp    $0x4,%r15d
 107543e:	jae    107545a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x66a>
 1075440:	mov    0x10315e0(,%r15,8),%rsi
 1075448:	mov    %r14,%rdi
 107544b:	call   108be0e <fail>
 1075450:	xor    %r15d,%r15d
 1075453:	jmp    10753e2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 1075455:	call   109afb7 <myl_rc_invariant_failed>
 107545a:	call   10acc30 <abort@plt>
 107545f:	mov    %r14,%rdi
 1075462:	xor    %esi,%esi
 1075464:	vzeroupper
 1075467:	call   108c820 <myl_qbe_fail_overflow_op>
 107546c:	mov    %r14,%rdi
 107546f:	call   108c4d0 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
