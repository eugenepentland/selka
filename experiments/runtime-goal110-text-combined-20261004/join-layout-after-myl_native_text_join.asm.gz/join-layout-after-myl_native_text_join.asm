
.mylang-cache/goal110-text-combined/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

00000000010937d0 <myl_native_text_join>:
 10937d0:	push   %rbp
 10937d1:	mov    %rsp,%rbp
 10937d4:	push   %r15
 10937d6:	push   %r14
 10937d8:	push   %r13
 10937da:	push   %r12
 10937dc:	push   %rbx
 10937dd:	sub    $0x88,%rsp
 10937e4:	mov    %rdi,%r8
 10937e7:	mov    %rsi,-0x68(%rbp)
 10937eb:	mov    %rdx,-0xb0(%rbp)
 10937f2:	mov    (%rdx),%rbx
 10937f5:	mov    0x20(%rdx),%rdi
 10937f9:	mov    0x8(%rsi),%r9
 10937fd:	mov    0x10(%rsi),%r13d
 1093801:	and    $0x1,%r13d
 1093805:	cmp    $0x2,%rbx
 1093809:	jb     1093823 <myl_native_text_join+0x53>
 109380b:	lea    -0x1(%rbx),%rcx
 109380f:	test   %r9,%r9
 1093812:	je     109382f <myl_native_text_join+0x5f>
 1093814:	mov    %r9,%rax
 1093817:	mul    %rcx
 109381a:	jno    109382f <myl_native_text_join+0x5f>
 109381c:	xor    %eax,%eax
 109381e:	jmp    1093adf <myl_native_text_join+0x30f>
 1093823:	xor    %r15d,%r15d
 1093826:	test   %rbx,%rbx
 1093829:	je     1093871 <myl_native_text_join+0xa1>
 109382b:	xor    %ecx,%ecx
 109382d:	jmp    109383a <myl_native_text_join+0x6a>
 109382f:	mov    %rcx,%r15
 1093832:	imul   %r9,%r15
 1093836:	imul   (%rsi),%rcx
 109383a:	xor    %eax,%eax
 109383c:	mov    %r15,%r14
 109383f:	mov    %rcx,%r15
 1093842:	xor    %ecx,%ecx
 1093844:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1093850:	mov    (%rdi,%rcx,8),%rdx
 1093854:	add    0x8(%rdx),%r14
 1093858:	jb     1093adf <myl_native_text_join+0x30f>
 109385e:	add    (%rdx),%r15
 1093861:	and    0x10(%rdx),%r13d
 1093865:	inc    %rcx
 1093868:	cmp    %rcx,%rbx
 109386b:	jne    1093850 <myl_native_text_join+0x80>
 109386d:	xor    %ecx,%ecx
 109386f:	jmp    1093876 <myl_native_text_join+0xa6>
 1093871:	mov    $0x1,%cl
 1093873:	xor    %r14d,%r14d
 1093876:	mov    0x10(%r8),%rax
 109387a:	mov    %rax,-0xa8(%rbp)
 1093881:	lea    -0x68(%rbp),%rax
 1093885:	mov    %rax,-0xa0(%rbp)
 109388c:	movq   $0x1031628,-0x98(%rbp)
 1093897:	lea    -0xa8(%rbp),%rdx
 109389e:	mov    %rdx,-0x88(%rbp)
 10938a5:	lea    -0xb0(%rbp),%rax
 10938ac:	mov    %rax,-0x80(%rbp)
 10938b0:	movq   $0x1031628,-0x78(%rbp)
 10938b8:	lea    -0x88(%rbp),%rsi
 10938bf:	mov    %rsi,0x10(%r8)
 10938c3:	cmp    %r14,%r15
 10938c6:	mov    %rdi,-0x50(%rbp)
 10938ca:	jne    10938d9 <myl_native_text_join+0x109>
 10938cc:	cmp    $0xffffffffffffffe7,%r14
 10938d0:	jbe    109394a <myl_native_text_join+0x17a>
 10938d2:	xor    %eax,%eax
 10938d4:	jmp    1093ad1 <myl_native_text_join+0x301>
 10938d9:	cmp    $0x100,%r14
 10938e0:	jb     109394a <myl_native_text_join+0x17a>
 10938e2:	mov    %r14,%rax
 10938e5:	shr    $0x20,%rax
 10938e9:	jne    10938cc <myl_native_text_join+0xfc>
 10938eb:	mov    %ecx,-0x30(%rbp)
 10938ee:	mov    %r9,-0x38(%rbp)
 10938f2:	lea    -0x1(%r15),%rax
 10938f6:	shr    $0x7,%rax
 10938fa:	lea    0x17(,%rax,4),%rax
 1093902:	and    $0xfffffffffffffff8,%rax
 1093906:	cmp    $0x1,%r15
 109390a:	mov    $0x10,%ecx
 109390f:	cmovae %rax,%rcx
 1093913:	lea    0x7(%r14),%rax
 1093917:	movabs $0x1fffffff8,%rsi
 1093921:	and    %rax,%rsi
 1093924:	add    %rcx,%rsi
 1093927:	mov    %r8,-0x40(%rbp)
 109392b:	mov    %r8,%rdi
 109392e:	call   108ea60 <myl_native_heap_alloc_block>
 1093933:	test   %rax,%rax
 1093936:	je     10939bc <myl_native_text_join+0x1ec>
 109393c:	mov    %rax,%rcx
 109393f:	mov    %r15,(%rcx)
 1093942:	mov    $0x8,%r12d
 1093948:	jmp    1093990 <myl_native_text_join+0x1c0>
 109394a:	xor    %eax,%eax
 109394c:	cmp    $0xffffffffffffffe7,%r14
 1093950:	ja     1093ad1 <myl_native_text_join+0x301>
 1093956:	cmpq   $0x0,0x1608(%r8)
 109395e:	je     1093ad1 <myl_native_text_join+0x301>
 1093964:	mov    %ecx,-0x30(%rbp)
 1093967:	mov    %r9,-0x38(%rbp)
 109396b:	lea    0x18(%r14),%rsi
 109396f:	mov    0x70(%r8),%edx
 1093973:	xor    %r12d,%r12d
 1093976:	mov    %r8,-0x40(%rbp)
 109397a:	mov    %r8,%rdi
 109397d:	xor    %ecx,%ecx
 109397f:	call   10a71a0 <raw_bytes>
 1093984:	test   %rax,%rax
 1093987:	je     10939bc <myl_native_text_join+0x1ec>
 1093989:	movq   $0x0,(%rax)
 1093990:	mov    %r14,0x8(%rax)
 1093994:	mov    %r12d,0x10(%rax)
 1093998:	movl   $0x0,0x14(%rax)
 109399f:	mov    -0x68(%rbp),%r11
 10939a3:	testb  $0x4,0x10(%r11)
 10939a8:	mov    -0x40(%rbp),%r8
 10939ac:	mov    -0x50(%rbp),%r9
 10939b0:	mov    -0x38(%rbp),%r10
 10939b4:	jne    10939c7 <myl_native_text_join+0x1f7>
 10939b6:	add    $0x18,%r11
 10939ba:	jmp    10939d7 <myl_native_text_join+0x207>
 10939bc:	xor    %eax,%eax
 10939be:	mov    -0x40(%rbp),%r8
 10939c2:	jmp    1093ac3 <myl_native_text_join+0x2f3>
 10939c7:	mov    0x18(%r11),%rcx
 10939cb:	mov    0x14(%r11),%edx
 10939cf:	lea    (%rcx,%rdx,1),%r11
 10939d3:	add    $0x18,%r11
 10939d7:	mov    -0x30(%rbp),%ecx
 10939da:	test   %cl,%cl
 10939dc:	mov    %rax,-0x48(%rbp)
 10939e0:	jne    1093ab0 <myl_native_text_join+0x2e0>
 10939e6:	lea    0x18(%rax),%rcx
 10939ea:	mov    %rcx,-0x60(%rbp)
 10939ee:	mov    (%r9),%rsi
 10939f1:	mov    0x8(%rsi),%rdi
 10939f5:	test   %rdi,%rdi
 10939f8:	mov    %r11,-0x58(%rbp)
 10939fc:	je     1093aaa <myl_native_text_join+0x2da>
 1093a02:	testb  $0x4,0x10(%rsi)
 1093a06:	jne    1093a0e <myl_native_text_join+0x23e>
 1093a08:	add    $0x18,%rsi
 1093a0c:	jmp    1093a1d <myl_native_text_join+0x24d>
 1093a0e:	mov    0x18(%rsi),%rcx
 1093a12:	mov    0x14(%rsi),%edx
 1093a15:	lea    (%rcx,%rdx,1),%rsi
 1093a19:	add    $0x18,%rsi
 1093a1d:	cmp    $0x10,%rdi
 1093a21:	jbe    1093a51 <myl_native_text_join+0x281>
 1093a23:	mov    %rdi,%r12
 1093a26:	mov    -0x60(%rbp),%rdi
 1093a2a:	mov    %r12,%rdx
 1093a2d:	mov    %r8,%r14
 1093a30:	mov    %r10,-0x38(%rbp)
 1093a34:	call   10acc10 <memcpy@plt>
 1093a39:	mov    %r12,%rdi
 1093a3c:	mov    -0x58(%rbp),%r11
 1093a40:	mov    -0x38(%rbp),%r10
 1093a44:	mov    -0x50(%rbp),%r9
 1093a48:	mov    %r14,%r8
 1093a4b:	mov    -0x48(%rbp),%rax
 1093a4f:	jmp    1093aaa <myl_native_text_join+0x2da>
 1093a51:	cmp    $0x7,%rdi
 1093a55:	jbe    1093a6d <myl_native_text_join+0x29d>
 1093a57:	mov    (%rsi),%rcx
 1093a5a:	mov    -0x8(%rsi,%rdi,1),%rdx
 1093a5f:	lea    0x18(%rax),%rsi
 1093a63:	mov    %rcx,(%rsi)
 1093a66:	mov    %rdx,-0x8(%rsi,%rdi,1)
 1093a6b:	jmp    1093aaa <myl_native_text_join+0x2da>
 1093a6d:	cmp    $0x3,%rdi
 1093a71:	jbe    1093a85 <myl_native_text_join+0x2b5>
 1093a73:	mov    (%rsi),%ecx
 1093a75:	mov    -0x4(%rsi,%rdi,1),%edx
 1093a79:	lea    0x18(%rax),%rsi
 1093a7d:	mov    %ecx,(%rsi)
 1093a7f:	mov    %edx,-0x4(%rsi,%rdi,1)
 1093a83:	jmp    1093aaa <myl_native_text_join+0x2da>
 1093a85:	cmp    $0x1,%rdi
 1093a89:	jne    1093a96 <myl_native_text_join+0x2c6>
 1093a8b:	movzbl (%rsi),%ecx
 1093a8e:	lea    0x18(%rax),%rdx
 1093a92:	mov    %cl,(%rdx)
 1093a94:	jmp    1093aaa <myl_native_text_join+0x2da>
 1093a96:	movzwl (%rsi),%ecx
 1093a99:	movzwl -0x2(%rsi,%rdi,1),%edx
 1093a9e:	lea    0x18(%rax),%rsi
 1093aa2:	mov    %cx,(%rsi)
 1093aa5:	mov    %dx,-0x2(%rsi,%rdi,1)
 1093aaa:	cmp    $0x1,%rbx
 1093aae:	jne    1093b0e <myl_native_text_join+0x33e>
 1093ab0:	test   %r13d,%r13d
 1093ab3:	je     1093c83 <myl_native_text_join+0x4b3>
 1093ab9:	mov    %r15,(%rax)
 1093abc:	movl   $0x1,0x10(%rax)
 1093ac3:	lea    -0xa8(%rbp),%rdx
 1093aca:	lea    -0x88(%rbp),%rsi
 1093ad1:	mov    0x10(%r8),%rcx
 1093ad5:	cmp    %rsi,%rcx
 1093ad8:	je     1093af1 <myl_native_text_join+0x321>
 1093ada:	cmp    %rdx,%rcx
 1093add:	je     1093b01 <myl_native_text_join+0x331>
 1093adf:	add    $0x88,%rsp
 1093ae6:	pop    %rbx
 1093ae7:	pop    %r12
 1093ae9:	pop    %r13
 1093aeb:	pop    %r14
 1093aed:	pop    %r15
 1093aef:	pop    %rbp
 1093af0:	ret
 1093af1:	mov    -0x88(%rbp),%rcx
 1093af8:	mov    %rcx,0x10(%r8)
 1093afc:	cmp    %rdx,%rcx
 1093aff:	jne    1093adf <myl_native_text_join+0x30f>
 1093b01:	mov    -0xa8(%rbp),%rcx
 1093b08:	mov    %rcx,0x10(%r8)
 1093b0c:	jmp    1093adf <myl_native_text_join+0x30f>
 1093b0e:	mov    $0x1,%r14d
 1093b14:	mov    %r8,-0x40(%rbp)
 1093b18:	mov    %r10,-0x38(%rbp)
 1093b1c:	jmp    1093b4d <myl_native_text_join+0x37d>
 1093b1e:	mov    %r12,%rdx
 1093b21:	call   10acc10 <memcpy@plt>
 1093b26:	mov    -0x58(%rbp),%r11
 1093b2a:	mov    -0x38(%rbp),%r10
 1093b2e:	mov    -0x50(%rbp),%r9
 1093b32:	mov    -0x40(%rbp),%r8
 1093b36:	mov    -0x48(%rbp),%rax
 1093b3a:	mov    -0x30(%rbp),%rdi
 1093b3e:	add    %r12,%rdi
 1093b41:	inc    %r14
 1093b44:	cmp    %r14,%rbx
 1093b47:	je     1093ab0 <myl_native_text_join+0x2e0>
 1093b4d:	test   %r10,%r10
 1093b50:	je     1093be7 <myl_native_text_join+0x417>
 1093b56:	mov    -0x60(%rbp),%rcx
 1093b5a:	mov    %rdi,-0x30(%rbp)
 1093b5e:	add    %rcx,%rdi
 1093b61:	cmp    $0x11,%r10
 1093b65:	jb     1093b8a <myl_native_text_join+0x3ba>
 1093b67:	mov    %r11,%rsi
 1093b6a:	mov    %r10,%rdx
 1093b6d:	mov    %r8,%r12
 1093b70:	call   10acc10 <memcpy@plt>
 1093b75:	mov    -0x58(%rbp),%r11
 1093b79:	mov    -0x38(%rbp),%r10
 1093b7d:	mov    -0x50(%rbp),%r9
 1093b81:	mov    %r12,%r8
 1093b84:	mov    -0x48(%rbp),%rax
 1093b88:	jmp    1093be0 <myl_native_text_join+0x410>
 1093b8a:	cmp    $0x8,%r10
 1093b8e:	jb     1093ba2 <myl_native_text_join+0x3d2>
 1093b90:	mov    (%r11),%rcx
 1093b93:	mov    -0x8(%r11,%r10,1),%rdx
 1093b98:	mov    %rcx,(%rdi)
 1093b9b:	mov    %rdx,-0x8(%rdi,%r10,1)
 1093ba0:	jmp    1093be0 <myl_native_text_join+0x410>
 1093ba2:	cmp    $0x4,%r10
 1093ba6:	jb     1093bb9 <myl_native_text_join+0x3e9>
 1093ba8:	mov    (%r11),%ecx
 1093bab:	mov    -0x4(%r11,%r10,1),%edx
 1093bb0:	mov    %ecx,(%rdi)
 1093bb2:	mov    %edx,-0x4(%rdi,%r10,1)
 1093bb7:	jmp    1093be0 <myl_native_text_join+0x410>
 1093bb9:	cmp    $0x2,%r10
 1093bbd:	jb     1093bd4 <myl_native_text_join+0x404>
 1093bbf:	movzwl (%r11),%ecx
 1093bc3:	movzwl -0x2(%r11,%r10,1),%edx
 1093bc9:	mov    %cx,(%rdi)
 1093bcc:	mov    %dx,-0x2(%rdi,%r10,1)
 1093bd2:	jmp    1093be0 <myl_native_text_join+0x410>
 1093bd4:	movzbl (%r11),%ecx
 1093bd8:	mov    %cl,(%rdi)
 1093bda:	nopw   0x0(%rax,%rax,1)
 1093be0:	mov    -0x30(%rbp),%rdi
 1093be4:	add    %r10,%rdi
 1093be7:	mov    (%r9,%r14,8),%rsi
 1093beb:	mov    0x8(%rsi),%r12
 1093bef:	test   %r12,%r12
 1093bf2:	je     1093b3e <myl_native_text_join+0x36e>
 1093bf8:	testb  $0x4,0x10(%rsi)
 1093bfc:	jne    1093c04 <myl_native_text_join+0x434>
 1093bfe:	add    $0x18,%rsi
 1093c02:	jmp    1093c13 <myl_native_text_join+0x443>
 1093c04:	mov    0x18(%rsi),%rcx
 1093c08:	mov    0x14(%rsi),%edx
 1093c0b:	lea    (%rcx,%rdx,1),%rsi
 1093c0f:	add    $0x18,%rsi
 1093c13:	mov    -0x60(%rbp),%rcx
 1093c17:	mov    %rdi,-0x30(%rbp)
 1093c1b:	add    %rcx,%rdi
 1093c1e:	cmp    $0x11,%r12
 1093c22:	jae    1093b1e <myl_native_text_join+0x34e>
 1093c28:	cmp    $0x8,%r12
 1093c2c:	jb     1093c43 <myl_native_text_join+0x473>
 1093c2e:	mov    (%rsi),%rcx
 1093c31:	mov    -0x8(%rsi,%r12,1),%rdx
 1093c36:	mov    %rcx,(%rdi)
 1093c39:	mov    %rdx,-0x8(%rdi,%r12,1)
 1093c3e:	jmp    1093b3a <myl_native_text_join+0x36a>
 1093c43:	cmp    $0x4,%r12
 1093c47:	jb     1093c5c <myl_native_text_join+0x48c>
 1093c49:	mov    (%rsi),%ecx
 1093c4b:	mov    -0x4(%rsi,%r12,1),%edx
 1093c50:	mov    %ecx,(%rdi)
 1093c52:	mov    %edx,-0x4(%rdi,%r12,1)
 1093c57:	jmp    1093b3a <myl_native_text_join+0x36a>
 1093c5c:	cmp    $0x1,%r12
 1093c60:	jne    1093c6c <myl_native_text_join+0x49c>
 1093c62:	movzbl (%rsi),%ecx
 1093c65:	mov    %cl,(%rdi)
 1093c67:	jmp    1093b3a <myl_native_text_join+0x36a>
 1093c6c:	movzwl (%rsi),%ecx
 1093c6f:	movzwl -0x2(%rsi,%r12,1),%edx
 1093c75:	mov    %cx,(%rdi)
 1093c78:	mov    %dx,-0x2(%rdi,%r12,1)
 1093c7e:	jmp    1093b3a <myl_native_text_join+0x36a>
 1093c83:	mov    %rax,%rdi
 1093c86:	mov    %r15,%rsi
 1093c89:	mov    %r8,%rbx
 1093c8c:	call   1090900 <publish_wide>
 1093c91:	mov    %rbx,%r8
 1093c94:	mov    -0x48(%rbp),%rax
 1093c98:	jmp    1093ac3 <myl_native_text_join+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
