
.mylang-cache/goal110-text-combined/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104a250 <myl_native_bytes_number_parse>:
 104a250:	push   %rbp
 104a251:	mov    %rsp,%rbp
 104a254:	push   %r14
 104a256:	push   %rbx
 104a257:	mov    %rdi,%rax
 104a25a:	test   %rdi,%rdi
 104a25d:	mov    $0x1,%edi
 104a262:	cmovne %rax,%rdi
 104a266:	cmovne %rsi,%rax
 104a26a:	test   %edx,%edx
 104a26c:	je     104a27d <myl_native_bytes_number_parse+0x2d>
 104a26e:	mov    %rax,%rsi
 104a271:	mov    %rcx,%rdx
 104a274:	pop    %rbx
 104a275:	pop    %r14
 104a277:	pop    %rbp
 104a278:	jmp    104b2d0 <myl_native_number_parse+0xee0>
 104a27d:	xor    %r8d,%r8d
 104a280:	test   %rax,%rax
 104a283:	je     104a2c0 <myl_native_bytes_number_parse+0x70>
 104a285:	vmovdqa -0x488dd(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a28d:	jmp    104a298 <myl_native_bytes_number_parse+0x48>
 104a28f:	nop
 104a290:	inc    %r8
 104a293:	cmp    %r8,%rax
 104a296:	je     104a2bd <myl_native_bytes_number_parse+0x6d>
 104a298:	movzbl (%rdi,%r8,1),%edx
 104a29d:	vmovd  %edx,%xmm1
 104a2a1:	vpbroadcastd %xmm1,%xmm1
 104a2a6:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a2aa:	vmovmskps %xmm1,%r9d
 104a2ae:	test   %r9d,%r9d
 104a2b1:	jne    104a290 <myl_native_bytes_number_parse+0x40>
 104a2b3:	add    $0xf5,%dl
 104a2b6:	cmp    $0x1,%dl
 104a2b9:	jbe    104a290 <myl_native_bytes_number_parse+0x40>
 104a2bb:	jmp    104a2c0 <myl_native_bytes_number_parse+0x70>
 104a2bd:	mov    %rsi,%r8
 104a2c0:	cmp    %rax,%r8
 104a2c3:	mov    %rax,%rdx
 104a2c6:	cmovb  %r8,%rdx
 104a2ca:	vmovdqa -0x48922(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a2d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104a2e0:	cmp    %r8,%rax
 104a2e3:	jbe    104a313 <myl_native_bytes_number_parse+0xc3>
 104a2e5:	movzbl -0x1(%rdi,%rax,1),%esi
 104a2ea:	dec    %rax
 104a2ed:	vmovd  %esi,%xmm1
 104a2f1:	vpbroadcastd %xmm1,%xmm1
 104a2f6:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a2fa:	vmovmskps %xmm1,%r9d
 104a2fe:	test   %r9d,%r9d
 104a301:	jne    104a2e0 <myl_native_bytes_number_parse+0x90>
 104a303:	add    $0xf5,%sil
 104a307:	cmp    $0x2,%sil
 104a30b:	jb     104a2e0 <myl_native_bytes_number_parse+0x90>
 104a30d:	inc    %rax
 104a310:	mov    %rax,%rdx
 104a313:	sub    %r8,%rdx
 104a316:	je     104a339 <myl_native_bytes_number_parse+0xe9>
 104a318:	add    %r8,%rdi
 104a31b:	movzbl (%rdi),%eax
 104a31e:	cmp    $0x2d,%eax
 104a321:	je     104a328 <myl_native_bytes_number_parse+0xd8>
 104a323:	cmp    $0x2b,%eax
 104a326:	jne    104a340 <myl_native_bytes_number_parse+0xf0>
 104a328:	cmp    $0x2d,%al
 104a32a:	sete   %sil
 104a32e:	mov    $0x1,%r9d
 104a334:	cmp    %rdx,%r9
 104a337:	jne    104a34a <myl_native_bytes_number_parse+0xfa>
 104a339:	xor    %eax,%eax
 104a33b:	pop    %rbx
 104a33c:	pop    %r14
 104a33e:	pop    %rbp
 104a33f:	ret
 104a340:	xor    %r9d,%r9d
 104a343:	xor    %esi,%esi
 104a345:	cmp    %rdx,%r9
 104a348:	je     104a339 <myl_native_bytes_number_parse+0xe9>
 104a34a:	jae    104a3b9 <myl_native_bytes_number_parse+0x169>
 104a34c:	movabs $0xccccccccccccccc,%r10
 104a356:	movzbl %sil,%r11d
 104a35a:	add    $0x7,%r11
 104a35e:	xor    %eax,%eax
 104a360:	xor    %r8d,%r8d
 104a363:	jmp    104a380 <myl_native_bytes_number_parse+0x130>
 104a365:	data16 cs nopw 0x0(%rax,%rax,1)
 104a370:	lea    (%r8,%r8,4),%r8
 104a374:	lea    (%rbx,%r8,2),%r8
 104a378:	mov    %r14,%r9
 104a37b:	cmp    %rdx,%r14
 104a37e:	jae    104a3c6 <myl_native_bytes_number_parse+0x176>
 104a380:	movzbl (%rdi,%r9,1),%ebx
 104a385:	add    $0xffffffd0,%ebx
 104a388:	cmp    $0x9,%ebx
 104a38b:	ja     104a33b <myl_native_bytes_number_parse+0xeb>
 104a38d:	cmp    %r10,%r8
 104a390:	ja     104a33b <myl_native_bytes_number_parse+0xeb>
 104a392:	mov    %ebx,%ebx
 104a394:	jne    104a39b <myl_native_bytes_number_parse+0x14b>
 104a396:	cmp    %ebx,%r11d
 104a399:	jb     104a33b <myl_native_bytes_number_parse+0xeb>
 104a39b:	lea    0x1(%r9),%r14
 104a39f:	cmp    %rdx,%r14
 104a3a2:	jae    104a370 <myl_native_bytes_number_parse+0x120>
 104a3a4:	cmpb   $0x5f,(%rdi,%r14,1)
 104a3a9:	jne    104a370 <myl_native_bytes_number_parse+0x120>
 104a3ab:	add    $0x2,%r9
 104a3af:	mov    %r9,%r14
 104a3b2:	cmp    %rdx,%r9
 104a3b5:	jne    104a370 <myl_native_bytes_number_parse+0x120>
 104a3b7:	jmp    104a33b <myl_native_bytes_number_parse+0xeb>
 104a3b9:	xor    %r8d,%r8d
 104a3bc:	test   %sil,%sil
 104a3bf:	je     104a3dd <myl_native_bytes_number_parse+0x18d>
 104a3c1:	neg    %r8
 104a3c4:	jmp    104a3dd <myl_native_bytes_number_parse+0x18d>
 104a3c6:	test   %sil,%sil
 104a3c9:	je     104a3dd <myl_native_bytes_number_parse+0x18d>
 104a3cb:	mov    %r8,%rax
 104a3ce:	neg    %rax
 104a3d1:	jno    104a3c1 <myl_native_bytes_number_parse+0x171>
 104a3d3:	movabs $0x8000000000000000,%r8
 104a3dd:	mov    %r8,(%rcx)
 104a3e0:	mov    $0x1,%eax
 104a3e5:	pop    %rbx
 104a3e6:	pop    %r14
 104a3e8:	pop    %rbp
 104a3e9:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
