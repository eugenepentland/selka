
/home/epentland/ai/canopy/mylang-worktrees/goal110-presize-ready-20261004/.mylang-cache/goal110-presize-ready-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001073fd0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>:
 1073fd0:	push   %rbp
 1073fd1:	push   %r15
 1073fd3:	push   %r14
 1073fd5:	push   %r13
 1073fd7:	push   %r12
 1073fd9:	push   %rbx
 1073fda:	sub    $0x38,%rsp
 1073fde:	mov    %rdi,%r14
 1073fe1:	mov    0x2c8(%rdi),%ebp
 1073fe7:	mov    %rsi,0x10(%rsp)
 1073fec:	mov    0x8(%rsi),%r15
 1073ff0:	cmp    $0xffffffffffffffff,%r15
 1073ff4:	je     107464c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x67c>
 1073ffa:	lea    0x258(%r14),%rbx
 1074001:	mov    0x268(%r14),%rax
 1074008:	mov    %rax,0x18(%rsp)
 107400d:	lea    0x10(%rsp),%rax
 1074012:	mov    %rax,0x20(%rsp)
 1074017:	movq   $0x1031628,0x28(%rsp)
 1074020:	lea    0x18(%rsp),%r12
 1074025:	mov    %r12,0x268(%r14)
 107402c:	mov    $0x1031698,%esi
 1074031:	mov    %rbx,%rdi
 1074034:	mov    %r15,%rdx
 1074037:	call   108e500 <myl_native_list_new>
 107403c:	test   %rax,%rax
 107403f:	je     1074088 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb8>
 1074041:	mov    0x20(%rax),%rdi
 1074045:	test   %rdi,%rdi
 1074048:	je     1074085 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb5>
 107404a:	mov    0x10(%rsp),%rsi
 107404f:	mov    0x8(%rsi),%rdx
 1074053:	lea    -0x1(%rdx),%rcx
 1074057:	cmp    %r15,%rcx
 107405a:	jae    1074085 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xb5>
 107405c:	testb  $0x4,0x10(%rsi)
 1074060:	jne    107406b <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x9b>
 1074062:	mov    %rax,%r13
 1074065:	add    $0x18,%rsi
 1074069:	jmp    107407d <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xad>
 107406b:	mov    %rax,%r13
 107406e:	mov    0x18(%rsi),%rax
 1074072:	mov    0x14(%rsi),%ecx
 1074075:	lea    (%rax,%rcx,1),%rsi
 1074079:	add    $0x18,%rsi
 107407d:	call   10aba80 <memcpy@plt>
 1074082:	mov    %r13,%rax
 1074085:	mov    %r15,(%rax)
 1074088:	cmp    %r12,0x268(%r14)
 107408f:	jne    107409d <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xcd>
 1074091:	mov    0x18(%rsp),%rcx
 1074096:	mov    %rcx,0x268(%r14)
 107409d:	test   %rax,%rax
 10740a0:	je     107464c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x67c>
 10740a6:	movabs $0x5000000000000000,%rcx
 10740b0:	mov    %rax,(%rsp)
 10740b4:	mov    %rax,0x8(%rsp)
 10740b9:	mov    -0x10(%rax),%rdx
 10740bd:	lea    0x1(%rcx),%rsi
 10740c1:	test   %rsi,%rdx
 10740c4:	je     1074121 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x151>
 10740c6:	test   %rcx,%rdx
 10740c9:	je     1074103 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x133>
 10740cb:	mov    %rsp,%rdx
 10740ce:	lea    0x8(%rsp),%rcx
 10740d3:	mov    $0x100bb28,%esi
 10740d8:	mov    %rbx,%rdi
 10740db:	mov    %ebp,%r8d
 10740de:	call   10a6870 <myl_rc_native_take>
 10740e3:	test   %eax,%eax
 10740e5:	je     1074289 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x2b9>
 10740eb:	mov    (%rsp),%rax
 10740ef:	movabs $0x4000000000000002,%r12
 10740f9:	mov    (%rax),%rsi
 10740fc:	test   %rax,%rax
 10740ff:	jne    107413c <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x16c>
 1074101:	jmp    1074153 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 1074103:	lea    0x8(%rsp),%rcx
 1074108:	mov    %rsp,%rdx
 107410b:	mov    %rdx,%rsi
 107410e:	sub    %rcx,%rsi
 1074111:	sub    %rdx,%rcx
 1074114:	cmovb  %rsi,%rcx
 1074118:	test   %rcx,%rcx
 107411b:	je     10740cb <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0xfb>
 107411d:	mov    %rax,(%rsp)
 1074121:	movq   $0x0,0x8(%rsp)
 107412a:	movabs $0x4000000000000002,%r12
 1074134:	mov    (%rax),%rsi
 1074137:	test   %rax,%rax
 107413a:	je     1074153 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 107413c:	test   %r12,-0x10(%rax)
 1074140:	jne    1074153 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x183>
 1074142:	mov    -0x18(%rax),%rcx
 1074146:	inc    %rcx
 1074149:	je     1074613 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x643>
 107414f:	mov    %rcx,-0x18(%rax)
 1074153:	mov    %rax,(%rsp)
 1074157:	lea    -0x10(%rsi),%rdx
 107415b:	movabs $0xffffffffffff1,%rcx
 1074165:	cmp    %rcx,%rdx
 1074168:	jae    1074185 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x1b5>
 107416a:	mov    0x20(%rax),%rcx
 107416e:	mov    %edx,%edi
 1074170:	not    %edi
 1074172:	vpxor  %xmm0,%xmm0,%xmm0
 1074176:	test   $0x30,%dil
 107417a:	jne    10741ae <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x1de>
 107417c:	vpxor  %xmm1,%xmm1,%xmm1
 1074180:	mov    %rsi,%r8
 1074183:	jmp    1074200 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x230>
 1074185:	test   %rsi,%rsi
 1074188:	jle    10742d5 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x305>
 107418e:	mov    0x20(%rax),%rdi
 1074192:	cmp    $0xf,%rsi
 1074196:	ja     10742dd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x30d>
 107419c:	mov    $0x1,%r8d
 10741a2:	xor    %edx,%edx
 10741a4:	xor    %ecx,%ecx
 10741a6:	mov    %rsi,%r15
 10741a9:	jmp    1074516 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x546>
 10741ae:	mov    %edx,%edi
 10741b0:	shr    $0x4,%edi
 10741b3:	inc    %edi
 10741b5:	and    $0x3,%edi
 10741b8:	vpxor  %xmm2,%xmm2,%xmm2
 10741bc:	mov    %rdi,%r8
 10741bf:	mov    %rcx,%r9
 10741c2:	vpxor  %xmm1,%xmm1,%xmm1
 10741c6:	cs nopw 0x0(%rax,%rax,1)
 10741d0:	vpsadbw (%r9),%xmm2,%xmm3
 10741d5:	vpaddq %xmm1,%xmm3,%xmm1
 10741d9:	add    $0x10,%r9
 10741dd:	dec    %r8
 10741e0:	jne    10741d0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x200>
 10741e2:	shl    $0x4,%edi
 10741e5:	add    %rdi,%rcx
 10741e8:	mov    %rsi,%r8
 10741eb:	sub    %rdi,%r8
 10741ee:	cmp    $0x30,%rdx
 10741f2:	jb     1074231 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x261>
 10741f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1074200:	vpsadbw (%rcx),%xmm0,%xmm2
 1074204:	vpaddq %xmm1,%xmm2,%xmm1
 1074208:	vpsadbw 0x10(%rcx),%xmm0,%xmm2
 107420d:	vpsadbw 0x20(%rcx),%xmm0,%xmm3
 1074212:	vpaddq %xmm2,%xmm3,%xmm2
 1074216:	vpaddq %xmm1,%xmm2,%xmm1
 107421a:	vpsadbw 0x30(%rcx),%xmm0,%xmm2
 107421f:	vpaddq %xmm1,%xmm2,%xmm1
 1074223:	add    $0x40,%rcx
 1074227:	add    $0xffffffffffffffc0,%r8
 107422b:	cmp    $0xf,%r8
 107422f:	ja     1074200 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x230>
 1074231:	vpshufd $0xee,%xmm1,%xmm0
 1074236:	vpaddq %xmm0,%xmm1,%xmm0
 107423a:	vmovq  %xmm0,%r15
 107423f:	test   %r8,%r8
 1074242:	je     107450a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 1074248:	mov    %r8,%r10
 107424b:	and    $0x3,%r10
 107424f:	je     10743ad <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x3dd>
 1074255:	xor    %edx,%edx
 1074257:	nopw   0x0(%rax,%rax,1)
 1074260:	movzbl (%rcx,%rdx,1),%edi
 1074264:	add    %rdi,%r15
 1074267:	inc    %rdx
 107426a:	cmp    %rdx,%r10
 107426d:	jne    1074260 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x290>
 107426f:	mov    %r8,%rdx
 1074272:	and    $0xfffffffffffffffc,%rdx
 1074276:	lea    (%rcx,%r10,1),%rdi
 107427a:	cmp    $0x4,%r8
 107427e:	jae    10743bd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x3ed>
 1074284:	jmp    107450a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 1074289:	mov    0x1860(%r14),%rax
 1074290:	test   %rax,%rax
 1074293:	je     1074635 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x665>
 1074299:	mov    0x124(%rax),%r15d
 10742a0:	movl   $0x0,0x124(%rax)
 10742aa:	test   %r15,%r15
 10742ad:	je     10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10742b3:	cmp    $0x1,%r15d
 10742b7:	jne    107461a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x64a>
 10742bd:	mov    $0x1007df2,%esi
 10742c2:	cmpl   $0x0,0x2c4(%r14)
 10742ca:	je     1074620 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x650>
 10742d0:	jmp    1074628 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x658>
 10742d5:	mov    %rsi,%r15
 10742d8:	jmp    1074589 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 10742dd:	movabs $0x7ffffffffffffff0,%rcx
 10742e7:	and    %rsi,%rcx
 10742ea:	vmovq  %rsi,%xmm0
 10742ef:	vpxor  %xmm1,%xmm1,%xmm1
 10742f3:	xor    %edx,%edx
 10742f5:	vpxor  %xmm5,%xmm5,%xmm5
 10742f9:	vpxor  %xmm6,%xmm6,%xmm6
 10742fd:	vpxor  %xmm7,%xmm7,%xmm7
 1074301:	vpxor  %xmm2,%xmm2,%xmm2
 1074305:	vpxor  %xmm3,%xmm3,%xmm3
 1074309:	vpxor  %xmm4,%xmm4,%xmm4
 107430d:	nopl   (%rax)
 1074310:	vpmovzxbq (%rdi,%rdx,1),%ymm8
 1074316:	vpmovzxbq 0x4(%rdi,%rdx,1),%ymm9
 107431d:	vpmovzxbq 0x8(%rdi,%rdx,1),%ymm10
 1074324:	vpmovzxbq 0xc(%rdi,%rdx,1),%ymm11
 107432b:	vpaddq %ymm1,%ymm8,%ymm1
 107432f:	vpaddq %ymm5,%ymm9,%ymm5
 1074333:	vpaddq %ymm6,%ymm10,%ymm6
 1074337:	vpaddq %ymm7,%ymm11,%ymm7
 107433b:	vpaddq %ymm0,%ymm8,%ymm0
 107433f:	vpaddq %ymm2,%ymm9,%ymm2
 1074343:	vpaddq %ymm3,%ymm10,%ymm3
 1074347:	vpaddq %ymm4,%ymm11,%ymm4
 107434b:	add    $0x10,%rdx
 107434f:	cmp    %rdx,%rcx
 1074352:	jne    1074310 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x340>
 1074354:	vpaddq %ymm1,%ymm5,%ymm1
 1074358:	vpaddq %ymm1,%ymm6,%ymm1
 107435c:	vpaddq %ymm1,%ymm7,%ymm1
 1074360:	vextracti128 $0x1,%ymm1,%xmm5
 1074366:	vpaddq %xmm5,%xmm1,%xmm1
 107436a:	vpshufd $0xee,%xmm1,%xmm5
 107436f:	vpaddq %xmm5,%xmm1,%xmm1
 1074373:	vmovq  %xmm1,%rdx
 1074378:	vpaddq %ymm0,%ymm2,%ymm0
 107437c:	vpaddq %ymm0,%ymm3,%ymm0
 1074380:	vpaddq %ymm0,%ymm4,%ymm0
 1074384:	vextracti128 $0x1,%ymm0,%xmm1
 107438a:	vpaddq %xmm1,%xmm0,%xmm0
 107438e:	vpshufd $0xee,%xmm0,%xmm1
 1074393:	vpaddq %xmm1,%xmm0,%xmm0
 1074397:	vmovq  %xmm0,%r15
 107439c:	cmp    %rcx,%rsi
 107439f:	jne    107450f <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53f>
 10743a5:	mov    %rsi,%rcx
 10743a8:	jmp    1074549 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x579>
 10743ad:	mov    %rcx,%rdi
 10743b0:	mov    %r8,%rdx
 10743b3:	cmp    $0x4,%r8
 10743b7:	jb     107450a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 10743bd:	lea    -0x4(%rdx),%r8
 10743c1:	cmp    $0x1c,%r8
 10743c5:	jb     10744dd <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x50d>
 10743cb:	shr    $0x2,%r8
 10743cf:	inc    %r8
 10743d2:	movabs $0x7ffffffffffffff0,%r9
 10743dc:	or     $0x8,%r9
 10743e0:	and    %r8,%r9
 10743e3:	lea    0x0(,%r9,4),%r11
 10743eb:	lea    (%rdi,%r9,4),%rdi
 10743ef:	sub    %r11,%rdx
 10743f2:	vmovq  %r15,%xmm4
 10743f7:	add    %r10,%rcx
 10743fa:	add    $0x10,%rcx
 10743fe:	vpxor  %xmm5,%xmm5,%xmm5
 1074402:	xor    %r10d,%r10d
 1074405:	vmovd  -0x72a6d(%rip),%xmm0        # 10019a0 <__abi_tag+0x16a4>
 107440d:	vmovd  -0x72a25(%rip),%xmm1        # 10019f0 <__abi_tag+0x16f4>
 1074415:	vmovd  -0x72a9d(%rip),%xmm2        # 1001980 <__abi_tag+0x1684>
 107441d:	vmovd  -0x72b05(%rip),%xmm3        # 1001920 <__abi_tag+0x1624>
 1074425:	data16 cs nopw 0x0(%rax,%rax,1)
 1074430:	vmovdqu -0x10(%rcx,%r10,4),%xmm6
 1074437:	vmovdqu (%rcx,%r10,4),%xmm7
 107443d:	vpshufb %xmm0,%xmm6,%xmm8
 1074442:	vpshufb %xmm1,%xmm6,%xmm9
 1074447:	vpshufb %xmm2,%xmm6,%xmm10
 107444c:	vpshufb %xmm3,%xmm6,%xmm6
 1074451:	vpshufb %xmm0,%xmm7,%xmm11
 1074456:	vpshufb %xmm1,%xmm7,%xmm12
 107445b:	vpshufb %xmm2,%xmm7,%xmm13
 1074460:	vpshufb %xmm3,%xmm7,%xmm7
 1074465:	vpmovzxbq %xmm8,%ymm8
 107446a:	vpaddq %ymm4,%ymm8,%ymm4
 107446e:	vpmovzxbq %xmm11,%ymm8
 1074473:	vpaddq %ymm5,%ymm8,%ymm5
 1074477:	vpmovzxbq %xmm9,%ymm8
 107447c:	vpmovzxbq %xmm12,%ymm9
 1074481:	vpmovzxbq %xmm10,%ymm10
 1074486:	vpaddq %ymm10,%ymm8,%ymm8
 107448b:	vpaddq %ymm4,%ymm8,%ymm4
 107448f:	vpmovzxbq %xmm13,%ymm8
 1074494:	vpaddq %ymm8,%ymm9,%ymm8
 1074499:	vpaddq %ymm5,%ymm8,%ymm5
 107449d:	vpmovzxbq %xmm6,%ymm6
 10744a2:	vpaddq %ymm6,%ymm4,%ymm4
 10744a6:	vpmovzxbq %xmm7,%ymm6
 10744ab:	vpaddq %ymm6,%ymm5,%ymm5
 10744af:	add    $0x8,%r10
 10744b3:	cmp    %r10,%r9
 10744b6:	jne    1074430 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x460>
 10744bc:	vpaddq %ymm4,%ymm5,%ymm0
 10744c0:	vextracti128 $0x1,%ymm0,%xmm1
 10744c6:	vpaddq %xmm1,%xmm0,%xmm0
 10744ca:	vpshufd $0xee,%xmm0,%xmm1
 10744cf:	vpaddq %xmm1,%xmm0,%xmm0
 10744d3:	vmovq  %xmm0,%r15
 10744d8:	cmp    %r9,%r8
 10744db:	je     107450a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x53a>
 10744dd:	xor    %ecx,%ecx
 10744df:	vpxor  %xmm0,%xmm0,%xmm0
 10744e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10744f0:	vmovd  (%rdi,%rcx,1),%xmm1
 10744f5:	vpsadbw %xmm0,%xmm1,%xmm1
 10744f9:	vmovq  %xmm1,%r8
 10744fe:	add    %r8,%r15
 1074501:	add    $0x4,%rcx
 1074505:	cmp    %rcx,%rdx
 1074508:	jne    10744f0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x520>
 107450a:	add    %rsi,%r15
 107450d:	jmp    1074589 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 107450f:	mov    %rcx,%r8
 1074512:	or     $0x1,%r8
 1074516:	lea    (%rdi,%rcx,1),%r9
 107451a:	mov    %rsi,%r10
 107451d:	sub    %rcx,%r10
 1074520:	xor    %ecx,%ecx
 1074522:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1074530:	movzbl (%r9,%rcx,1),%r11d
 1074535:	add    %r11,%rdx
 1074538:	add    %r11,%r15
 107453b:	inc    %rcx
 107453e:	cmp    %rcx,%r10
 1074541:	jne    1074530 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x560>
 1074543:	add    %r8,%rcx
 1074546:	dec    %rcx
 1074549:	mov    $0xffffffff,%r8d
 107454f:	cmp    %r8,%rcx
 1074552:	setb   %cl
 1074555:	lea    (%rdx,%rsi,1),%r8
 1074559:	or     %rdx,%r8
 107455c:	setns  %dl
 107455f:	test   %dl,%cl
 1074561:	cmove  %rsi,%r15
 1074565:	jne    1074589 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5b9>
 1074567:	xor    %r8d,%r8d
 107456a:	mov    %rsi,%rdx
 107456d:	mov    %rsi,%r15
 1074570:	movzbl (%rdi,%r8,1),%ecx
 1074575:	add    %rcx,%r15
 1074578:	jo     107463f <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x66f>
 107457e:	inc    %r8
 1074581:	mov    %r15,%rdx
 1074584:	cmp    %r8,%rsi
 1074587:	jne    1074570 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5a0>
 1074589:	test   %rax,%rax
 107458c:	je     10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 107458e:	test   %r12,-0x10(%rax)
 1074592:	jne    10745a8 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5d8>
 1074594:	mov    -0x18(%rax),%rcx
 1074598:	dec    %rcx
 107459b:	jne    10745a4 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5d4>
 107459d:	cmpq   $0x0,-0x20(%rax)
 10745a2:	je     10745d7 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x607>
 10745a4:	mov    %rcx,-0x18(%rax)
 10745a8:	test   %r12,-0x10(%rax)
 10745ac:	jne    10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10745ae:	mov    -0x20(%rax),%rcx
 10745b2:	dec    %rcx
 10745b5:	jne    10745be <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5ee>
 10745b7:	cmpq   $0x0,-0x18(%rax)
 10745bc:	je     10745fb <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x62b>
 10745be:	mov    %rcx,-0x20(%rax)
 10745c2:	mov    %r15,%rax
 10745c5:	add    $0x38,%rsp
 10745c9:	pop    %rbx
 10745ca:	pop    %r12
 10745cc:	pop    %r13
 10745ce:	pop    %r14
 10745d0:	pop    %r15
 10745d2:	pop    %rbp
 10745d3:	vzeroupper
 10745d6:	ret
 10745d7:	mov    %rbx,%rdi
 10745da:	mov    %rax,%rsi
 10745dd:	mov    %rax,%r14
 10745e0:	vzeroupper
 10745e3:	call   109a430 <myl_rc_hold_edge_release>
 10745e8:	mov    %rbx,%rdi
 10745eb:	call   109d450 <myl_rc_drain>
 10745f0:	mov    %r14,%rax
 10745f3:	test   %r12,-0x10(%rax)
 10745f7:	jne    10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 10745f9:	jmp    10745ae <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5de>
 10745fb:	mov    %rbx,%rdi
 10745fe:	mov    %rax,%rsi
 1074601:	vzeroupper
 1074604:	call   109a2d0 <myl_rc_edge_release>
 1074609:	mov    %rbx,%rdi
 107460c:	call   109d450 <myl_rc_drain>
 1074611:	jmp    10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 1074613:	mov    $0x1007dbf,%esi
 1074618:	jmp    1074628 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x658>
 107461a:	cmp    $0x4,%r15d
 107461e:	jae    107463a <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x66a>
 1074620:	mov    0x10315e0(,%r15,8),%rsi
 1074628:	mov    %r14,%rdi
 107462b:	call   108ad7e <fail>
 1074630:	xor    %r15d,%r15d
 1074633:	jmp    10745c2 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85+0x5f2>
 1074635:	call   1099e27 <myl_rc_invariant_failed>
 107463a:	call   10abaa0 <abort@plt>
 107463f:	mov    %r14,%rdi
 1074642:	xor    %esi,%esi
 1074644:	vzeroupper
 1074647:	call   108b790 <myl_qbe_fail_overflow_op>
 107464c:	mov    %r14,%rdi
 107464f:	call   108b440 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
