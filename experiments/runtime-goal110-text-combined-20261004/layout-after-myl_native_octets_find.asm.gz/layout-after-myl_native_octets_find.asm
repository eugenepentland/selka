
.mylang-cache/goal110-text-combined/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

00000000010934c0 <myl_native_octets_find>:
 10934c0:	test   %rcx,%rcx
 10934c3:	je     109351a <myl_native_octets_find+0x5a>
 10934c5:	push   %rbp
 10934c6:	mov    %rsp,%rbp
 10934c9:	push   %r15
 10934cb:	push   %r14
 10934cd:	push   %r13
 10934cf:	push   %r12
 10934d1:	push   %rbx
 10934d2:	sub    $0x18,%rsp
 10934d6:	mov    $0xffffffffffffffff,%rax
 10934dd:	mov    %rsi,%r14
 10934e0:	sub    %rcx,%r14
 10934e3:	jb     1093785 <myl_native_octets_find+0x2c5>
 10934e9:	mov    %rsi,%rbx
 10934ec:	cmp    $0x1,%rcx
 10934f0:	jne    109351d <myl_native_octets_find+0x5d>
 10934f2:	movzbl (%rdx),%esi
 10934f5:	mov    %rdi,%r14
 10934f8:	mov    %rbx,%rdx
 10934fb:	call   10ace30 <memchr@plt>
 1093500:	mov    %rax,%rcx
 1093503:	mov    %rax,%rdx
 1093506:	sub    %r14,%rdx
 1093509:	xor    %eax,%eax
 109350b:	cmp    $0x1,%rcx
 109350f:	sbb    %rax,%rax
 1093512:	or     %rdx,%rax
 1093515:	jmp    1093785 <myl_native_octets_find+0x2c5>
 109351a:	xor    %eax,%eax
 109351c:	ret
 109351d:	mov    %rcx,-0x30(%rbp)
 1093521:	mov    %rdx,%r15
 1093524:	movzbl (%rdx),%r12d
 1093528:	lea    0x1(%r14),%rdx
 109352c:	mov    %rdi,%r13
 109352f:	mov    %r12d,%esi
 1093532:	call   10ace30 <memchr@plt>
 1093537:	test   %rax,%rax
 109353a:	je     109377e <myl_native_octets_find+0x2be>
 1093540:	mov    %r13,%rcx
 1093543:	lea    (%r14,%r13,1),%r10
 1093547:	lea    (%r14,%r13,1),%r11
 109354b:	inc    %r11
 109354e:	lea    0x1(%rax),%rdi
 1093552:	mov    $0x1,%edx
 1093557:	mov    -0x30(%rbp),%rsi
 109355b:	mov    %r15,%r8
 109355e:	xchg   %ax,%ax
 1093560:	movzbl (%rax,%rdx,1),%r9d
 1093565:	cmp    (%r8,%rdx,1),%r9b
 1093569:	jne    109357b <myl_native_octets_find+0xbb>
 109356b:	inc    %rdx
 109356e:	cmp    %rdx,%rsi
 1093571:	jne    1093560 <myl_native_octets_find+0xa0>
 1093573:	sub    %rcx,%rax
 1093576:	jmp    1093785 <myl_native_octets_find+0x2c5>
 109357b:	cmp    %r10,%rax
 109357e:	je     109377e <myl_native_octets_find+0x2be>
 1093584:	mov    %r10,-0x38(%rbp)
 1093588:	mov    %r11,%r14
 109358b:	mov    %r11,%rdx
 109358e:	sub    %rdi,%rdx
 1093591:	mov    %r12d,%esi
 1093594:	call   10ace30 <memchr@plt>
 1093599:	test   %rax,%rax
 109359c:	je     109377e <myl_native_octets_find+0x2be>
 10935a2:	lea    0x1(%rax),%rdi
 10935a6:	mov    $0x1,%edx
 10935ab:	mov    %r13,%rcx
 10935ae:	mov    -0x30(%rbp),%rsi
 10935b2:	mov    %r15,%r8
 10935b5:	mov    -0x38(%rbp),%r10
 10935b9:	mov    %r14,%r11
 10935bc:	nopl   0x0(%rax)
 10935c0:	movzbl (%rax,%rdx,1),%r9d
 10935c5:	cmp    (%r8,%rdx,1),%r9b
 10935c9:	jne    10935d5 <myl_native_octets_find+0x115>
 10935cb:	inc    %rdx
 10935ce:	cmp    %rdx,%rsi
 10935d1:	jne    10935c0 <myl_native_octets_find+0x100>
 10935d3:	jmp    1093573 <myl_native_octets_find+0xb3>
 10935d5:	cmp    %r10,%rax
 10935d8:	je     109377e <myl_native_octets_find+0x2be>
 10935de:	mov    %r11,%rdx
 10935e1:	sub    %rdi,%rdx
 10935e4:	mov    %r12d,%esi
 10935e7:	call   10ace30 <memchr@plt>
 10935ec:	test   %rax,%rax
 10935ef:	je     109377e <myl_native_octets_find+0x2be>
 10935f5:	lea    0x1(%rax),%rdi
 10935f9:	mov    $0x1,%edx
 10935fe:	mov    %r13,%rcx
 1093601:	mov    -0x30(%rbp),%rsi
 1093605:	mov    %r15,%r8
 1093608:	mov    -0x38(%rbp),%r10
 109360c:	mov    %r14,%r11
 109360f:	movzbl (%rax,%rdx,1),%r9d
 1093614:	cmp    (%r8,%rdx,1),%r9b
 1093618:	jne    1093627 <myl_native_octets_find+0x167>
 109361a:	inc    %rdx
 109361d:	cmp    %rdx,%rsi
 1093620:	jne    109360f <myl_native_octets_find+0x14f>
 1093622:	jmp    1093573 <myl_native_octets_find+0xb3>
 1093627:	cmp    %r10,%rax
 109362a:	je     109377e <myl_native_octets_find+0x2be>
 1093630:	mov    %r11,%rdx
 1093633:	sub    %rdi,%rdx
 1093636:	mov    %r12d,%esi
 1093639:	call   10ace30 <memchr@plt>
 109363e:	test   %rax,%rax
 1093641:	je     109377e <myl_native_octets_find+0x2be>
 1093647:	lea    0x1(%rax),%rdi
 109364b:	mov    $0x1,%edx
 1093650:	mov    %r13,%rcx
 1093653:	mov    -0x30(%rbp),%rsi
 1093657:	mov    %r15,%r8
 109365a:	mov    -0x38(%rbp),%r10
 109365e:	mov    %r14,%r11
 1093661:	movzbl (%rax,%rdx,1),%r9d
 1093666:	cmp    (%r8,%rdx,1),%r9b
 109366a:	jne    1093679 <myl_native_octets_find+0x1b9>
 109366c:	inc    %rdx
 109366f:	cmp    %rdx,%rsi
 1093672:	jne    1093661 <myl_native_octets_find+0x1a1>
 1093674:	jmp    1093573 <myl_native_octets_find+0xb3>
 1093679:	cmp    %r10,%rax
 109367c:	je     109377e <myl_native_octets_find+0x2be>
 1093682:	mov    %r11,%rdx
 1093685:	sub    %rdi,%rdx
 1093688:	mov    %r12d,%esi
 109368b:	call   10ace30 <memchr@plt>
 1093690:	test   %rax,%rax
 1093693:	je     109377e <myl_native_octets_find+0x2be>
 1093699:	lea    0x1(%rax),%rdi
 109369d:	mov    $0x1,%ecx
 10936a2:	mov    -0x30(%rbp),%rdx
 10936a6:	mov    %r15,%rsi
 10936a9:	movzbl (%rax,%rcx,1),%r8d
 10936ae:	cmp    (%rsi,%rcx,1),%r8b
 10936b2:	jne    10936c4 <myl_native_octets_find+0x204>
 10936b4:	inc    %rcx
 10936b7:	cmp    %rcx,%rdx
 10936ba:	jne    10936a9 <myl_native_octets_find+0x1e9>
 10936bc:	mov    %r13,%rcx
 10936bf:	jmp    1093573 <myl_native_octets_find+0xb3>
 10936c4:	cmp    -0x38(%rbp),%rax
 10936c8:	je     109377e <myl_native_octets_find+0x2be>
 10936ce:	mov    %r14,%rdx
 10936d1:	sub    %rdi,%rdx
 10936d4:	mov    %r12d,%esi
 10936d7:	call   10ace30 <memchr@plt>
 10936dc:	test   %rax,%rax
 10936df:	je     109377e <myl_native_octets_find+0x2be>
 10936e5:	lea    0x1(%rax),%rdi
 10936e9:	mov    $0x1,%ecx
 10936ee:	mov    -0x30(%rbp),%rdx
 10936f2:	mov    %r15,%rsi
 10936f5:	movzbl (%rax,%rcx,1),%r8d
 10936fa:	cmp    (%rsi,%rcx,1),%r8b
 10936fe:	jne    109370a <myl_native_octets_find+0x24a>
 1093700:	inc    %rcx
 1093703:	cmp    %rcx,%rdx
 1093706:	jne    10936f5 <myl_native_octets_find+0x235>
 1093708:	jmp    10936bc <myl_native_octets_find+0x1fc>
 109370a:	cmp    -0x38(%rbp),%rax
 109370e:	je     109377e <myl_native_octets_find+0x2be>
 1093710:	mov    %r14,%rdx
 1093713:	sub    %rdi,%rdx
 1093716:	mov    %r12d,%esi
 1093719:	call   10ace30 <memchr@plt>
 109371e:	test   %rax,%rax
 1093721:	je     109377e <myl_native_octets_find+0x2be>
 1093723:	lea    0x1(%rax),%rdi
 1093727:	mov    $0x1,%ecx
 109372c:	movzbl (%rax,%rcx,1),%edx
 1093730:	cmp    (%r15,%rcx,1),%dl
 1093734:	jne    1093744 <myl_native_octets_find+0x284>
 1093736:	inc    %rcx
 1093739:	cmp    %rcx,-0x30(%rbp)
 109373d:	jne    109372c <myl_native_octets_find+0x26c>
 109373f:	jmp    10936bc <myl_native_octets_find+0x1fc>
 1093744:	cmp    -0x38(%rbp),%rax
 1093748:	je     109377e <myl_native_octets_find+0x2be>
 109374a:	sub    %rdi,%r14
 109374d:	mov    %r12d,%esi
 1093750:	mov    %r14,%rdx
 1093753:	call   10ace30 <memchr@plt>
 1093758:	test   %rax,%rax
 109375b:	je     109377e <myl_native_octets_find+0x2be>
 109375d:	lea    0x1(%rax),%rdi
 1093761:	mov    $0x1,%ecx
 1093766:	movzbl (%rax,%rcx,1),%edx
 109376a:	cmp    (%r15,%rcx,1),%dl
 109376e:	jne    1093794 <myl_native_octets_find+0x2d4>
 1093770:	inc    %rcx
 1093773:	cmp    %rcx,-0x30(%rbp)
 1093777:	jne    1093766 <myl_native_octets_find+0x2a6>
 1093779:	jmp    10936bc <myl_native_octets_find+0x1fc>
 109377e:	mov    $0xffffffffffffffff,%rax
 1093785:	add    $0x18,%rsp
 1093789:	pop    %rbx
 109378a:	pop    %r12
 109378c:	pop    %r13
 109378e:	pop    %r14
 1093790:	pop    %r15
 1093792:	pop    %rbp
 1093793:	ret
 1093794:	cmp    -0x38(%rbp),%rax
 1093798:	mov    $0xffffffffffffffff,%rax
 109379f:	je     1093785 <myl_native_octets_find+0x2c5>
 10937a1:	add    %r13,%rbx
 10937a4:	sub    %rdi,%rbx
 10937a7:	mov    %rbx,%rsi
 10937aa:	mov    %r15,%rdx
 10937ad:	mov    -0x30(%rbp),%rcx
 10937b1:	call   10ace40 <memmem@plt>
 10937b6:	mov    %rax,%rcx
 10937b9:	mov    %rax,%rdx
 10937bc:	sub    %r13,%rdx
 10937bf:	jmp    1093509 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
