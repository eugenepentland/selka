
/home/epentland/ai/canopy/mylang-worktrees/goal110-presize-ready-20261004/.mylang-cache/goal110-presize-ready-debug/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001092750 <myl_native_text_join>:
 1092750:	push   %rbp
 1092751:	mov    %rsp,%rbp
 1092754:	push   %r15
 1092756:	push   %r14
 1092758:	push   %r13
 109275a:	push   %r12
 109275c:	push   %rbx
 109275d:	sub    $0x88,%rsp
 1092764:	mov    %rdi,%r8
 1092767:	mov    %rsi,-0x68(%rbp)
 109276b:	mov    %rdx,-0xb0(%rbp)
 1092772:	mov    (%rdx),%rbx
 1092775:	mov    0x20(%rdx),%rdi
 1092779:	mov    0x8(%rsi),%r9
 109277d:	mov    0x10(%rsi),%r13d
 1092781:	and    $0x1,%r13d
 1092785:	cmp    $0x2,%rbx
 1092789:	jb     10927a3 <myl_native_text_join+0x53>
 109278b:	lea    -0x1(%rbx),%rcx
 109278f:	test   %r9,%r9
 1092792:	je     10927af <myl_native_text_join+0x5f>
 1092794:	mov    %r9,%rax
 1092797:	mul    %rcx
 109279a:	jno    10927af <myl_native_text_join+0x5f>
 109279c:	xor    %eax,%eax
 109279e:	jmp    1092a5f <myl_native_text_join+0x30f>
 10927a3:	xor    %r15d,%r15d
 10927a6:	test   %rbx,%rbx
 10927a9:	je     10927f1 <myl_native_text_join+0xa1>
 10927ab:	xor    %ecx,%ecx
 10927ad:	jmp    10927ba <myl_native_text_join+0x6a>
 10927af:	mov    %rcx,%r15
 10927b2:	imul   %r9,%r15
 10927b6:	imul   (%rsi),%rcx
 10927ba:	xor    %eax,%eax
 10927bc:	mov    %r15,%r14
 10927bf:	mov    %rcx,%r15
 10927c2:	xor    %ecx,%ecx
 10927c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10927d0:	mov    (%rdi,%rcx,8),%rdx
 10927d4:	add    0x8(%rdx),%r14
 10927d8:	jb     1092a5f <myl_native_text_join+0x30f>
 10927de:	add    (%rdx),%r15
 10927e1:	and    0x10(%rdx),%r13d
 10927e5:	inc    %rcx
 10927e8:	cmp    %rcx,%rbx
 10927eb:	jne    10927d0 <myl_native_text_join+0x80>
 10927ed:	xor    %ecx,%ecx
 10927ef:	jmp    10927f6 <myl_native_text_join+0xa6>
 10927f1:	mov    $0x1,%cl
 10927f3:	xor    %r14d,%r14d
 10927f6:	mov    0x10(%r8),%rax
 10927fa:	mov    %rax,-0xa8(%rbp)
 1092801:	lea    -0x68(%rbp),%rax
 1092805:	mov    %rax,-0xa0(%rbp)
 109280c:	movq   $0x1031628,-0x98(%rbp)
 1092817:	lea    -0xa8(%rbp),%rdx
 109281e:	mov    %rdx,-0x88(%rbp)
 1092825:	lea    -0xb0(%rbp),%rax
 109282c:	mov    %rax,-0x80(%rbp)
 1092830:	movq   $0x1031628,-0x78(%rbp)
 1092838:	lea    -0x88(%rbp),%rsi
 109283f:	mov    %rsi,0x10(%r8)
 1092843:	cmp    %r14,%r15
 1092846:	mov    %rdi,-0x50(%rbp)
 109284a:	jne    1092859 <myl_native_text_join+0x109>
 109284c:	cmp    $0xffffffffffffffe7,%r14
 1092850:	jbe    10928ca <myl_native_text_join+0x17a>
 1092852:	xor    %eax,%eax
 1092854:	jmp    1092a51 <myl_native_text_join+0x301>
 1092859:	cmp    $0x100,%r14
 1092860:	jb     10928ca <myl_native_text_join+0x17a>
 1092862:	mov    %r14,%rax
 1092865:	shr    $0x20,%rax
 1092869:	jne    109284c <myl_native_text_join+0xfc>
 109286b:	mov    %ecx,-0x30(%rbp)
 109286e:	mov    %r9,-0x38(%rbp)
 1092872:	lea    -0x1(%r15),%rax
 1092876:	shr    $0x7,%rax
 109287a:	lea    0x17(,%rax,4),%rax
 1092882:	and    $0xfffffffffffffff8,%rax
 1092886:	cmp    $0x1,%r15
 109288a:	mov    $0x10,%ecx
 109288f:	cmovae %rax,%rcx
 1092893:	lea    0x7(%r14),%rax
 1092897:	movabs $0x1fffffff8,%rsi
 10928a1:	and    %rax,%rsi
 10928a4:	add    %rcx,%rsi
 10928a7:	mov    %r8,-0x40(%rbp)
 10928ab:	mov    %r8,%rdi
 10928ae:	call   108d9d0 <myl_native_heap_alloc_block>
 10928b3:	test   %rax,%rax
 10928b6:	je     109293c <myl_native_text_join+0x1ec>
 10928bc:	mov    %rax,%rcx
 10928bf:	mov    %r15,(%rcx)
 10928c2:	mov    $0x8,%r12d
 10928c8:	jmp    1092910 <myl_native_text_join+0x1c0>
 10928ca:	xor    %eax,%eax
 10928cc:	cmp    $0xffffffffffffffe7,%r14
 10928d0:	ja     1092a51 <myl_native_text_join+0x301>
 10928d6:	cmpq   $0x0,0x1608(%r8)
 10928de:	je     1092a51 <myl_native_text_join+0x301>
 10928e4:	mov    %ecx,-0x30(%rbp)
 10928e7:	mov    %r9,-0x38(%rbp)
 10928eb:	lea    0x18(%r14),%rsi
 10928ef:	mov    0x70(%r8),%edx
 10928f3:	xor    %r12d,%r12d
 10928f6:	mov    %r8,-0x40(%rbp)
 10928fa:	mov    %r8,%rdi
 10928fd:	xor    %ecx,%ecx
 10928ff:	call   10a6010 <raw_bytes>
 1092904:	test   %rax,%rax
 1092907:	je     109293c <myl_native_text_join+0x1ec>
 1092909:	movq   $0x0,(%rax)
 1092910:	mov    %r14,0x8(%rax)
 1092914:	mov    %r12d,0x10(%rax)
 1092918:	movl   $0x0,0x14(%rax)
 109291f:	mov    -0x68(%rbp),%r11
 1092923:	testb  $0x4,0x10(%r11)
 1092928:	mov    -0x40(%rbp),%r8
 109292c:	mov    -0x50(%rbp),%r9
 1092930:	mov    -0x38(%rbp),%r10
 1092934:	jne    1092947 <myl_native_text_join+0x1f7>
 1092936:	add    $0x18,%r11
 109293a:	jmp    1092957 <myl_native_text_join+0x207>
 109293c:	xor    %eax,%eax
 109293e:	mov    -0x40(%rbp),%r8
 1092942:	jmp    1092a43 <myl_native_text_join+0x2f3>
 1092947:	mov    0x18(%r11),%rcx
 109294b:	mov    0x14(%r11),%edx
 109294f:	lea    (%rcx,%rdx,1),%r11
 1092953:	add    $0x18,%r11
 1092957:	mov    -0x30(%rbp),%ecx
 109295a:	test   %cl,%cl
 109295c:	mov    %rax,-0x48(%rbp)
 1092960:	jne    1092a30 <myl_native_text_join+0x2e0>
 1092966:	lea    0x18(%rax),%rcx
 109296a:	mov    %rcx,-0x60(%rbp)
 109296e:	mov    (%r9),%rsi
 1092971:	mov    0x8(%rsi),%rdi
 1092975:	test   %rdi,%rdi
 1092978:	mov    %r11,-0x58(%rbp)
 109297c:	je     1092a2a <myl_native_text_join+0x2da>
 1092982:	testb  $0x4,0x10(%rsi)
 1092986:	jne    109298e <myl_native_text_join+0x23e>
 1092988:	add    $0x18,%rsi
 109298c:	jmp    109299d <myl_native_text_join+0x24d>
 109298e:	mov    0x18(%rsi),%rcx
 1092992:	mov    0x14(%rsi),%edx
 1092995:	lea    (%rcx,%rdx,1),%rsi
 1092999:	add    $0x18,%rsi
 109299d:	cmp    $0x10,%rdi
 10929a1:	jbe    10929d1 <myl_native_text_join+0x281>
 10929a3:	mov    %rdi,%r12
 10929a6:	mov    -0x60(%rbp),%rdi
 10929aa:	mov    %r12,%rdx
 10929ad:	mov    %r8,%r14
 10929b0:	mov    %r10,-0x38(%rbp)
 10929b4:	call   10aba80 <memcpy@plt>
 10929b9:	mov    %r12,%rdi
 10929bc:	mov    -0x58(%rbp),%r11
 10929c0:	mov    -0x38(%rbp),%r10
 10929c4:	mov    -0x50(%rbp),%r9
 10929c8:	mov    %r14,%r8
 10929cb:	mov    -0x48(%rbp),%rax
 10929cf:	jmp    1092a2a <myl_native_text_join+0x2da>
 10929d1:	cmp    $0x7,%rdi
 10929d5:	jbe    10929ed <myl_native_text_join+0x29d>
 10929d7:	mov    (%rsi),%rcx
 10929da:	mov    -0x8(%rsi,%rdi,1),%rdx
 10929df:	lea    0x18(%rax),%rsi
 10929e3:	mov    %rcx,(%rsi)
 10929e6:	mov    %rdx,-0x8(%rsi,%rdi,1)
 10929eb:	jmp    1092a2a <myl_native_text_join+0x2da>
 10929ed:	cmp    $0x3,%rdi
 10929f1:	jbe    1092a05 <myl_native_text_join+0x2b5>
 10929f3:	mov    (%rsi),%ecx
 10929f5:	mov    -0x4(%rsi,%rdi,1),%edx
 10929f9:	lea    0x18(%rax),%rsi
 10929fd:	mov    %ecx,(%rsi)
 10929ff:	mov    %edx,-0x4(%rsi,%rdi,1)
 1092a03:	jmp    1092a2a <myl_native_text_join+0x2da>
 1092a05:	cmp    $0x1,%rdi
 1092a09:	jne    1092a16 <myl_native_text_join+0x2c6>
 1092a0b:	movzbl (%rsi),%ecx
 1092a0e:	lea    0x18(%rax),%rdx
 1092a12:	mov    %cl,(%rdx)
 1092a14:	jmp    1092a2a <myl_native_text_join+0x2da>
 1092a16:	movzwl (%rsi),%ecx
 1092a19:	movzwl -0x2(%rsi,%rdi,1),%edx
 1092a1e:	lea    0x18(%rax),%rsi
 1092a22:	mov    %cx,(%rsi)
 1092a25:	mov    %dx,-0x2(%rsi,%rdi,1)
 1092a2a:	cmp    $0x1,%rbx
 1092a2e:	jne    1092a8e <myl_native_text_join+0x33e>
 1092a30:	test   %r13d,%r13d
 1092a33:	je     1092c03 <myl_native_text_join+0x4b3>
 1092a39:	mov    %r15,(%rax)
 1092a3c:	movl   $0x1,0x10(%rax)
 1092a43:	lea    -0xa8(%rbp),%rdx
 1092a4a:	lea    -0x88(%rbp),%rsi
 1092a51:	mov    0x10(%r8),%rcx
 1092a55:	cmp    %rsi,%rcx
 1092a58:	je     1092a71 <myl_native_text_join+0x321>
 1092a5a:	cmp    %rdx,%rcx
 1092a5d:	je     1092a81 <myl_native_text_join+0x331>
 1092a5f:	add    $0x88,%rsp
 1092a66:	pop    %rbx
 1092a67:	pop    %r12
 1092a69:	pop    %r13
 1092a6b:	pop    %r14
 1092a6d:	pop    %r15
 1092a6f:	pop    %rbp
 1092a70:	ret
 1092a71:	mov    -0x88(%rbp),%rcx
 1092a78:	mov    %rcx,0x10(%r8)
 1092a7c:	cmp    %rdx,%rcx
 1092a7f:	jne    1092a5f <myl_native_text_join+0x30f>
 1092a81:	mov    -0xa8(%rbp),%rcx
 1092a88:	mov    %rcx,0x10(%r8)
 1092a8c:	jmp    1092a5f <myl_native_text_join+0x30f>
 1092a8e:	mov    $0x1,%r14d
 1092a94:	mov    %r8,-0x40(%rbp)
 1092a98:	mov    %r10,-0x38(%rbp)
 1092a9c:	jmp    1092acd <myl_native_text_join+0x37d>
 1092a9e:	mov    %r12,%rdx
 1092aa1:	call   10aba80 <memcpy@plt>
 1092aa6:	mov    -0x58(%rbp),%r11
 1092aaa:	mov    -0x38(%rbp),%r10
 1092aae:	mov    -0x50(%rbp),%r9
 1092ab2:	mov    -0x40(%rbp),%r8
 1092ab6:	mov    -0x48(%rbp),%rax
 1092aba:	mov    -0x30(%rbp),%rdi
 1092abe:	add    %r12,%rdi
 1092ac1:	inc    %r14
 1092ac4:	cmp    %r14,%rbx
 1092ac7:	je     1092a30 <myl_native_text_join+0x2e0>
 1092acd:	test   %r10,%r10
 1092ad0:	je     1092b67 <myl_native_text_join+0x417>
 1092ad6:	mov    -0x60(%rbp),%rcx
 1092ada:	mov    %rdi,-0x30(%rbp)
 1092ade:	add    %rcx,%rdi
 1092ae1:	cmp    $0x11,%r10
 1092ae5:	jb     1092b0a <myl_native_text_join+0x3ba>
 1092ae7:	mov    %r11,%rsi
 1092aea:	mov    %r10,%rdx
 1092aed:	mov    %r8,%r12
 1092af0:	call   10aba80 <memcpy@plt>
 1092af5:	mov    -0x58(%rbp),%r11
 1092af9:	mov    -0x38(%rbp),%r10
 1092afd:	mov    -0x50(%rbp),%r9
 1092b01:	mov    %r12,%r8
 1092b04:	mov    -0x48(%rbp),%rax
 1092b08:	jmp    1092b60 <myl_native_text_join+0x410>
 1092b0a:	cmp    $0x8,%r10
 1092b0e:	jb     1092b22 <myl_native_text_join+0x3d2>
 1092b10:	mov    (%r11),%rcx
 1092b13:	mov    -0x8(%r11,%r10,1),%rdx
 1092b18:	mov    %rcx,(%rdi)
 1092b1b:	mov    %rdx,-0x8(%rdi,%r10,1)
 1092b20:	jmp    1092b60 <myl_native_text_join+0x410>
 1092b22:	cmp    $0x4,%r10
 1092b26:	jb     1092b39 <myl_native_text_join+0x3e9>
 1092b28:	mov    (%r11),%ecx
 1092b2b:	mov    -0x4(%r11,%r10,1),%edx
 1092b30:	mov    %ecx,(%rdi)
 1092b32:	mov    %edx,-0x4(%rdi,%r10,1)
 1092b37:	jmp    1092b60 <myl_native_text_join+0x410>
 1092b39:	cmp    $0x2,%r10
 1092b3d:	jb     1092b54 <myl_native_text_join+0x404>
 1092b3f:	movzwl (%r11),%ecx
 1092b43:	movzwl -0x2(%r11,%r10,1),%edx
 1092b49:	mov    %cx,(%rdi)
 1092b4c:	mov    %dx,-0x2(%rdi,%r10,1)
 1092b52:	jmp    1092b60 <myl_native_text_join+0x410>
 1092b54:	movzbl (%r11),%ecx
 1092b58:	mov    %cl,(%rdi)
 1092b5a:	nopw   0x0(%rax,%rax,1)
 1092b60:	mov    -0x30(%rbp),%rdi
 1092b64:	add    %r10,%rdi
 1092b67:	mov    (%r9,%r14,8),%rsi
 1092b6b:	mov    0x8(%rsi),%r12
 1092b6f:	test   %r12,%r12
 1092b72:	je     1092abe <myl_native_text_join+0x36e>
 1092b78:	testb  $0x4,0x10(%rsi)
 1092b7c:	jne    1092b84 <myl_native_text_join+0x434>
 1092b7e:	add    $0x18,%rsi
 1092b82:	jmp    1092b93 <myl_native_text_join+0x443>
 1092b84:	mov    0x18(%rsi),%rcx
 1092b88:	mov    0x14(%rsi),%edx
 1092b8b:	lea    (%rcx,%rdx,1),%rsi
 1092b8f:	add    $0x18,%rsi
 1092b93:	mov    -0x60(%rbp),%rcx
 1092b97:	mov    %rdi,-0x30(%rbp)
 1092b9b:	add    %rcx,%rdi
 1092b9e:	cmp    $0x11,%r12
 1092ba2:	jae    1092a9e <myl_native_text_join+0x34e>
 1092ba8:	cmp    $0x8,%r12
 1092bac:	jb     1092bc3 <myl_native_text_join+0x473>
 1092bae:	mov    (%rsi),%rcx
 1092bb1:	mov    -0x8(%rsi,%r12,1),%rdx
 1092bb6:	mov    %rcx,(%rdi)
 1092bb9:	mov    %rdx,-0x8(%rdi,%r12,1)
 1092bbe:	jmp    1092aba <myl_native_text_join+0x36a>
 1092bc3:	cmp    $0x4,%r12
 1092bc7:	jb     1092bdc <myl_native_text_join+0x48c>
 1092bc9:	mov    (%rsi),%ecx
 1092bcb:	mov    -0x4(%rsi,%r12,1),%edx
 1092bd0:	mov    %ecx,(%rdi)
 1092bd2:	mov    %edx,-0x4(%rdi,%r12,1)
 1092bd7:	jmp    1092aba <myl_native_text_join+0x36a>
 1092bdc:	cmp    $0x1,%r12
 1092be0:	jne    1092bec <myl_native_text_join+0x49c>
 1092be2:	movzbl (%rsi),%ecx
 1092be5:	mov    %cl,(%rdi)
 1092be7:	jmp    1092aba <myl_native_text_join+0x36a>
 1092bec:	movzwl (%rsi),%ecx
 1092bef:	movzwl -0x2(%rsi,%r12,1),%edx
 1092bf5:	mov    %cx,(%rdi)
 1092bf8:	mov    %dx,-0x2(%rdi,%r12,1)
 1092bfe:	jmp    1092aba <myl_native_text_join+0x36a>
 1092c03:	mov    %rax,%rdi
 1092c06:	mov    %r15,%rsi
 1092c09:	mov    %r8,%rbx
 1092c0c:	call   108f870 <publish_wide>
 1092c11:	mov    %rbx,%r8
 1092c14:	mov    -0x48(%rbp),%rax
 1092c18:	jmp    1092a43 <myl_native_text_join+0x2f3>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
