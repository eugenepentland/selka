1050bd0: mov    %rax,%r14
1050bd3: mov    0x8(%rsp),%rax
1050bd8: add    %r15,%rax
1050bdb: jo     1051db1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3621>
1050be1: test   $0x1,%al
1050be3: jne    1050c80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24f0>
1050be9: movq   $0x10bb2b0,0x70(%rsp)
1050bf2: movq   $0x10bb2b0,0x1c8(%rsp)
1050bfe: movq   $0x10bb2b0,0x48(%rsp)
1050c07: mov    0x6a692(%rip),%rax        # 10bb2a0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
1050c0e: test   %rax,0x50(%rsp)
1050c13: movabs $0x4000000000000002,%rbx
1050c1d: je     1050d3a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25aa>
1050c23: cmpq   $0x0,0xf0(%rsp)
1050c2c: sete   %cl
1050c2f: movabs $0x5000000000000000,%rdx
1050c39: test   %rdx,%rax
1050c3c: setne  %al
1050c3f: or     %cl,%al
1050c41: je     1050d56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25c6>
1050c47: mov    $0x1030c78,%esi
1050c4c: lea    0x258(%rbp),%rdi
1050c53: lea    0x70(%rsp),%rdx
1050c58: lea    0x48(%rsp),%rcx
1050c5d: mov    0x44(%rsp),%r8d
1050c62: call   10a7a00 <myl_rc_native_take>
1050c67: test   %eax,%eax
1050c69: jne    1050d06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2576>
1050c6f: jmp    1050f7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27eb>
1050c74: data16 data16 cs nopw 0x0(%rax,%rax,1)
1050c80: movq   $0x10ba620,0x70(%rsp)
1050c89: movq   $0x10ba620,0x1c8(%rsp)
1050c95: movq   $0x10ba620,0x48(%rsp)
1050c9e: mov    0x6996b(%rip),%rax        # 10ba610 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
1050ca5: test   %rax,0x50(%rsp)
1050caa: movabs $0x4000000000000002,%rbx
1050cb4: je     1050d84 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25f4>
1050cba: cmpq   $0x0,0xf0(%rsp)
1050cc3: sete   %cl
1050cc6: movabs $0x5000000000000000,%rdx
1050cd0: test   %rdx,%rax
1050cd3: setne  %al
1050cd6: or     %cl,%al
1050cd8: je     1050d7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25eb>
1050cde: mov    $0x1030c78,%esi
1050ce3: lea    0x258(%rbp),%rdi
1050cea: lea    0x70(%rsp),%rdx
1050cef: lea    0x48(%rsp),%rcx
1050cf4: mov    0x44(%rsp),%r8d
1050cf9: call   10a7a00 <myl_rc_native_take>
1050cfe: test   %eax,%eax
1050d00: je     1050faa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x281a>
1050d06: mov    0x70(%rsp),%r12
1050d0b: mov    %r12,0xa8(%rsp)
1050d13: mov    %r12,0x48(%rsp)
1050d18: test   %r12,%r12
1050d1b: je     1050f0a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x277a>
1050d21: test   %rbx,-0x10(%r12)
1050d26: je     1050d9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
1050d28: mov    %r12,0x70(%rsp)
1050d2d: mov    %r12,0xa0(%rsp)
1050d35: jmp    1050dd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2649>
1050d3a: mov    $0x10bb2b0,%r12d
1050d40: mov    %r12,0xa8(%rsp)
1050d48: mov    %r12,0x48(%rsp)
1050d4d: test   %rbx,-0x10(%r12)
1050d52: jne    1050d28 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
1050d54: jmp    1050d9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
1050d56: movq   $0x10bb2b0,0x70(%rsp)
1050d5f: mov    $0x10bb2b0,%r12d
1050d65: mov    %r12,0xa8(%rsp)
1050d6d: mov    %r12,0x48(%rsp)
1050d72: test   %rbx,-0x10(%r12)
1050d77: jne    1050d28 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
1050d79: jmp    1050d9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
1050d7b: movq   $0x10ba620,0x70(%rsp)
1050d84: mov    $0x10ba620,%r12d
1050d8a: mov    %r12,0xa8(%rsp)
1050d92: mov    %r12,0x48(%rsp)
1050d97: test   %rbx,-0x10(%r12)
1050d9c: jne    1050d28 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
1050d9e: mov    -0x18(%r12),%rax
1050da3: inc    %rax
1050da6: je     1050fd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
1050dac: mov    %rax,-0x18(%r12)
1050db1: mov    %r12,0x70(%rsp)
1050db6: mov    %r12,0xa0(%rsp)
1050dbe: mov    -0x20(%r12),%rax
1050dc3: dec    %rax
1050dc6: jne    1050dd4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
1050dc8: cmpq   $0x0,-0x18(%r12)
1050dce: je     1050f49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27b9>
1050dd4: mov    %rax,-0x20(%r12)
1050dd9: movq   $0x0,0xa8(%rsp)
1050de5: mov    0x30(%rsp),%rax
1050dea: mov    0x20(%rax),%rdx
1050dee: lea    0x258(%rbp),%rdi
1050df5: mov    %r12,%rsi
1050df8: call   10937d0 <myl_native_text_join>
1050dfd: test   %rax,%rax
1050e00: je     1051d99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3609>
1050e06: mov    %rax,%rbx
1050e09: mov    %rax,0x48(%rsp)
1050e0e: mov    %rax,0x70(%rsp)
1050e13: mov    %rax,0x1c8(%rsp)
1050e1b: mov    %rbp,%rdi
1050e1e: mov    %rax,%rsi
1050e21: call   1074df0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
1050e26: mov    %rax,%r13
1050e29: movabs $0x4000000000000002,%rax
1050e33: test   %rax,-0x10(%rbx)
1050e37: je     1050e50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c0>
1050e39: movq   $0x0,0x1c8(%rsp)
1050e45: test   %r12,%r12
1050e48: jne    1050e79 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e9>
1050e4a: jmp    1050eb1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
1050e4c: nopl   0x0(%rax)
1050e50: mov    -0x20(%rbx),%rax
1050e54: dec    %rax
1050e57: jne    1050e64 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26d4>
1050e59: cmpq   $0x0,-0x18(%rbx)
1050e5e: je     1050f27 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2797>
1050e64: mov    %rax,-0x20(%rbx)
1050e68: movq   $0x0,0x1c8(%rsp)
1050e74: test   %r12,%r12
1050e77: je     1050eb1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
1050e79: movabs $0x4000000000000002,%rax
1050e83: test   %rax,-0x10(%r12)
1050e88: jne    1050ea5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2715>
1050e8a: mov    -0x18(%r12),%rax
1050e8f: dec    %rax
1050e92: jne    1050ea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2710>
1050e94: cmpq   $0x0,-0x20(%r12)
1050e9a: je     1050f62 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27d2>
1050ea0: mov    %rax,-0x18(%r12)
1050ea5: movq   $0x0,0xa0(%rsp)
1050eb1: mov    %r14,%rcx
1050eb4: add    %r13,%rcx
1050eb7: jo     1051da1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3611>
1050ebd: mov    %rcx,%rax
1050ec0: movabs $0x89705f3112a28fe5,%rdx
1050eca: imul   %rdx
1050ecd: add    %rcx,%rdx
1050ed0: mov    %rdx,%rax
1050ed3: shr    $0x3f,%rax
1050ed7: sar    $0x1d,%rdx
1050edb: add    %rax,%rdx
1050ede: imul   $0x3b9aca07,%rdx,%rax
1050ee5: sub    %rax,%rcx
1050ee8: mov    %rcx,%rax
1050eeb: sar    $0x3f,%rax
1050eef: and    $0x3b9aca07,%eax
1050ef4: add    %rcx,%rax
1050ef7: inc    %r15
1050efa: cmp    %r15,0x28(%rsp)
1050eff: jne    1050bd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2440>
