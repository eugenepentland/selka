
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-vm-stack-read-20261003/.tmp-lox-vm-stack-read-v2-20261003/qualified-inline-llvm-rc:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
