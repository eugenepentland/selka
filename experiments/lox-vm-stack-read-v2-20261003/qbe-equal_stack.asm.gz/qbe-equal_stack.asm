
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-vm-stack-read-20261003/.tmp-lox-vm-stack-read-v2-20261003/qualified-inline-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001125ac0 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5>:
 1125ac0:	endbr64
 1125ac4:	push   %rbp
 1125ac5:	mov    %rsp,%rbp
 1125ac8:	sub    $0x20,%rsp
 1125acc:	movabs $0x8000000000000001,%rax
 1125ad6:	cmp    %rax,%rdx
 1125ad9:	jl     1125dcd <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x30d>
 1125adf:	mov    %rsi,%rax
 1125ae2:	mov    (%rsi),%rsi
 1125ae5:	mov    %rdx,%r9
 1125ae8:	sub    $0x1,%r9
 1125aec:	cmp    %rsi,%r9
 1125aef:	setb   %cl
 1125af2:	movzbq %cl,%rcx
 1125af6:	cmp    $0x0,%ecx
 1125af9:	jne    1125b74 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xb4>
 1125afb:	cmp    $0x0,%r9
 1125aff:	jge    1125b2e <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x6e>
 1125b01:	movabs $0x7fffffffffffffff,%rcx
 1125b0b:	cmp    %rcx,%rsi
 1125b0e:	ja     1125b68 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xa8>
 1125b10:	mov    %rsi,%rcx
 1125b13:	add    %r9,%rcx
 1125b16:	mov    %rsi,%r8
 1125b19:	xor    %rcx,%r8
 1125b1c:	mov    %r9,%r10
 1125b1f:	xor    %rcx,%r10
 1125b22:	and    %r10,%r8
 1125b25:	cmp    $0x0,%r8
 1125b29:	jl     1125b50 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x90>
 1125b2b:	mov    %rcx,%r9
 1125b2e:	mov    (%rax),%rcx
 1125b31:	cmp    %rcx,%r9
 1125b34:	jb     1125b43 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x83>
 1125b36:	mov    %rcx,%rdx
 1125b39:	mov    %r9,%rsi
 1125b3c:	call   115a6b0 <myl_qbe_fail_normalized_index_bounds>
 1125b41:	ud2
 1125b43:	mov    0x20(%rax),%rcx
 1125b47:	imul   $0x10,%r9,%r8
 1125b4b:	add    %r8,%rcx
 1125b4e:	jmp    1125b7f <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xbf>
 1125b50:	mov    $0x40,%r8d
 1125b56:	mov    %r9,%rcx
 1125b59:	mov    %rsi,%rdx
 1125b5c:	mov    $0x0,%esi
 1125b61:	call   115a8c0 <myl_qbe_fail_overflow_op>
 1125b66:	ud2
 1125b68:	mov    $0x140,%edx
 1125b6d:	call   115aa00 <myl_qbe_fail_cast>
 1125b72:	ud2
 1125b74:	mov    0x20(%rax),%rcx
 1125b78:	imul   $0x10,%r9,%r8
 1125b7c:	add    %r8,%rcx
 1125b7f:	mov    (%rcx),%r8
 1125b82:	mov    %r8,-0x20(%rbp)
 1125b86:	mov    0x8(%rcx),%rcx
 1125b8a:	mov    %rcx,-0x18(%rbp)
 1125b8e:	movabs $0x8000000000000002,%rcx
 1125b98:	cmp    %rcx,%rdx
 1125b9b:	jl     1125db6 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f6>
 1125ba1:	mov    %rdx,%rcx
 1125ba4:	sub    $0x2,%rcx
 1125ba8:	cmp    %rsi,%rcx
 1125bab:	jb     1125c28 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x168>
 1125bad:	cmp    $0x0,%rcx
 1125bb1:	jl     1125bb8 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xf8>
 1125bb3:	mov    %rax,%rsi
 1125bb6:	jmp    1125be8 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x128>
 1125bb8:	movabs $0x7fffffffffffffff,%rdx
 1125bc2:	cmp    %rdx,%rsi
 1125bc5:	ja     1125c1c <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x15c>
 1125bc7:	mov    %rsi,%r9
 1125bca:	add    %rcx,%r9
 1125bcd:	mov    %rsi,%rdx
 1125bd0:	xor    %r9,%rdx
 1125bd3:	mov    %rcx,%r8
 1125bd6:	xor    %r9,%r8
 1125bd9:	and    %r8,%rdx
 1125bdc:	cmp    $0x0,%rdx
 1125be0:	jl     1125c07 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x147>
 1125be2:	mov    %r9,%rcx
 1125be5:	mov    %rax,%rsi
 1125be8:	mov    (%rsi),%rdx
 1125beb:	cmp    %rdx,%rcx
 1125bee:	jb     1125bfa <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x13a>
 1125bf0:	mov    %rcx,%rsi
 1125bf3:	call   115a6b0 <myl_qbe_fail_normalized_index_bounds>
 1125bf8:	ud2
 1125bfa:	mov    0x20(%rsi),%rax
 1125bfe:	imul   $0x10,%rcx,%rcx
 1125c02:	add    %rcx,%rax
 1125c05:	jmp    1125c36 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x176>
 1125c07:	mov    $0x40,%r8d
 1125c0d:	mov    %rsi,%rdx
 1125c10:	mov    $0x0,%esi
 1125c15:	call   115a8c0 <myl_qbe_fail_overflow_op>
 1125c1a:	ud2
 1125c1c:	mov    $0x140,%edx
 1125c21:	call   115aa00 <myl_qbe_fail_cast>
 1125c26:	ud2
 1125c28:	mov    %rax,%rsi
 1125c2b:	mov    0x20(%rsi),%rax
 1125c2f:	imul   $0x10,%rcx,%rcx
 1125c33:	add    %rcx,%rax
 1125c36:	mov    (%rax),%rcx
 1125c39:	mov    %rcx,-0x10(%rbp)
 1125c3d:	mov    0x8(%rax),%rax
 1125c41:	mov    %rax,-0x8(%rbp)
 1125c45:	mov    -0x10(%rbp),%eax
 1125c48:	cmp    $0x0,%rax
 1125c4c:	je     1125d78 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2b8>
 1125c52:	cmp    $0x1,%rax
 1125c56:	sete   %cl
 1125c59:	movzbq %cl,%rcx
 1125c5d:	cmp    $0x0,%ecx
 1125c60:	jne    1125d32 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x272>
 1125c66:	cmp    $0x2,%rax
 1125c6a:	je     1125cca <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x20a>
 1125c6c:	cmp    $0x3,%rax
 1125c70:	jne    1125d93 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2d3>
 1125c76:	mov    -0x8(%rbp),%rcx
 1125c7a:	mov    -0x20(%rbp),%eax
 1125c7d:	cmp    $0x0,%rax
 1125c81:	je     1125cc0 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x200>
 1125c83:	cmp    $0x1,%rax
 1125c87:	je     1125cb6 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x1f6>
 1125c89:	cmp    $0x2,%rax
 1125c8d:	je     1125cac <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x1ec>
 1125c8f:	cmp    $0x3,%rax
 1125c93:	jne    1125d93 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2d3>
 1125c99:	mov    -0x18(%rbp),%rax
 1125c9d:	cmp    %rax,%rcx
 1125ca0:	sete   %al
 1125ca3:	movzbq %al,%rax
 1125ca7:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125cac:	mov    $0x0,%eax
 1125cb1:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125cb6:	mov    $0x0,%eax
 1125cbb:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125cc0:	mov    $0x0,%eax
 1125cc5:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125cca:	mov    -0x8(%rbp),%rcx
 1125cce:	mov    -0x20(%rbp),%eax
 1125cd1:	cmp    $0x0,%rax
 1125cd5:	je     1125d28 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x268>
 1125cd7:	cmp    $0x1,%rax
 1125cdb:	je     1125d1e <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x25e>
 1125cdd:	cmp    $0x2,%rax
 1125ce1:	je     1125cf7 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x237>
 1125ce3:	cmp    $0x3,%rax
 1125ce7:	jne    1125d93 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2d3>
 1125ced:	mov    $0x0,%eax
 1125cf2:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125cf7:	mov    -0x18(%rbp),%rax
 1125cfb:	movq   %rcx,%xmm1
 1125d00:	movq   %rax,%xmm0
 1125d05:	ucomisd %xmm0,%xmm1
 1125d09:	sete   %al
 1125d0c:	movzbq %al,%rax
 1125d10:	setnp  %cl
 1125d13:	movzbq %cl,%rcx
 1125d17:	and    %ecx,%eax
 1125d19:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d1e:	mov    $0x0,%eax
 1125d23:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d28:	mov    $0x0,%eax
 1125d2d:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d32:	movzbq -0x8(%rbp),%rcx
 1125d37:	mov    -0x20(%rbp),%eax
 1125d3a:	cmp    $0x0,%rax
 1125d3e:	je     1125d71 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2b1>
 1125d40:	cmp    $0x1,%rax
 1125d44:	je     1125d60 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2a0>
 1125d46:	cmp    $0x2,%rax
 1125d4a:	je     1125d59 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x299>
 1125d4c:	cmp    $0x3,%rax
 1125d50:	jne    1125d93 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2d3>
 1125d52:	mov    $0x0,%eax
 1125d57:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d59:	mov    $0x0,%eax
 1125d5e:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d60:	movzbq -0x18(%rbp),%rax
 1125d65:	cmp    %rax,%rcx
 1125d68:	sete   %al
 1125d6b:	movzbq %al,%rax
 1125d6f:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d71:	mov    $0x0,%eax
 1125d76:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d78:	mov    -0x20(%rbp),%eax
 1125d7b:	cmp    $0x0,%rax
 1125d7f:	je     1125daf <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2ef>
 1125d81:	cmp    $0x1,%rax
 1125d85:	je     1125da8 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2e8>
 1125d87:	cmp    $0x2,%rax
 1125d8b:	je     1125da1 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2e1>
 1125d8d:	cmp    $0x3,%rax
 1125d91:	je     1125d9a <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2da>
 1125d93:	mov    $0x0,%eax
 1125d98:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125d9a:	mov    $0x0,%eax
 1125d9f:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125da1:	mov    $0x0,%eax
 1125da6:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125da8:	mov    $0x0,%eax
 1125dad:	jmp    1125db4 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x2f4>
 1125daf:	mov    $0x1,%eax
 1125db4:	leave
 1125db5:	ret
 1125db6:	mov    $0x40,%r8d
 1125dbc:	mov    $0x2,%ecx
 1125dc1:	mov    $0x1,%esi
 1125dc6:	call   115a8c0 <myl_qbe_fail_overflow_op>
 1125dcb:	ud2
 1125dcd:	mov    $0x40,%r8d
 1125dd3:	mov    $0x1,%ecx
 1125dd8:	mov    $0x1,%esi
 1125ddd:	call   115a8c0 <myl_qbe_fail_overflow_op>
 1125de2:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
