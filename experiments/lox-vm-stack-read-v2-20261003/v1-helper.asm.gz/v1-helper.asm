
.tmp-lox-vm-stack-read-20261003/equal-qbe:     file format elf64-x86-64


Disassembly of section .text:

0000000001125ae0 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5>:
 1125ae0:	endbr64
 1125ae4:	push   %rbp
 1125ae5:	mov    %rsp,%rbp
 1125ae8:	sub    $0x20,%rsp
 1125aec:	mov    0x40(%rdi),%rax
 1125af0:	lea    -0x8(%rbp),%rcx
 1125af4:	cmp    %rax,%rcx
 1125af7:	jb     1125ca6 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x1c6>
 1125afd:	movabs $0x8000000000000001,%rax
 1125b07:	cmp    %rax,%rdx
 1125b0a:	jl     1125c8f <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x1af>
 1125b10:	mov    (%rsi),%rax
 1125b13:	mov    %rdx,%rcx
 1125b16:	sub    $0x1,%rcx
 1125b1a:	cmp    %rax,%rcx
 1125b1d:	setb   %r8b
 1125b21:	movzbq %r8b,%r8
 1125b25:	cmp    $0x0,%r8d
 1125b29:	jne    1125ba7 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xc7>
 1125b2b:	cmp    $0x0,%rcx
 1125b2f:	jge    1125b5e <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x7e>
 1125b31:	movabs $0x7fffffffffffffff,%r8
 1125b3b:	cmp    %r8,%rax
 1125b3e:	ja     1125b98 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xb8>
 1125b40:	mov    %rax,%r9
 1125b43:	add    %rcx,%r9
 1125b46:	mov    %rax,%r8
 1125b49:	xor    %r9,%r8
 1125b4c:	mov    %rcx,%r10
 1125b4f:	xor    %r9,%r10
 1125b52:	and    %r10,%r8
 1125b55:	cmp    $0x0,%r8
 1125b59:	jl     1125b80 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xa0>
 1125b5b:	mov    %r9,%rcx
 1125b5e:	mov    (%rsi),%rax
 1125b61:	cmp    %rax,%rcx
 1125b64:	jb     1125b73 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x93>
 1125b66:	mov    %rax,%rdx
 1125b69:	mov    %rcx,%rsi
 1125b6c:	call   115a570 <myl_qbe_fail_normalized_index_bounds>
 1125b71:	ud2
 1125b73:	mov    0x20(%rsi),%rax
 1125b77:	imul   $0x10,%rcx,%rcx
 1125b7b:	add    %rcx,%rax
 1125b7e:	jmp    1125bb2 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0xd2>
 1125b80:	mov    %rax,%rsi
 1125b83:	mov    $0x40,%r8d
 1125b89:	mov    %rsi,%rdx
 1125b8c:	mov    $0x0,%esi
 1125b91:	call   115a780 <myl_qbe_fail_overflow_op>
 1125b96:	ud2
 1125b98:	mov    %rax,%rsi
 1125b9b:	mov    $0x140,%edx
 1125ba0:	call   115a8c0 <myl_qbe_fail_cast>
 1125ba5:	ud2
 1125ba7:	mov    0x20(%rsi),%rax
 1125bab:	imul   $0x10,%rcx,%rcx
 1125baf:	add    %rcx,%rax
 1125bb2:	mov    (%rax),%rcx
 1125bb5:	mov    %rcx,-0x18(%rbp)
 1125bb9:	mov    0x8(%rax),%rax
 1125bbd:	mov    %rax,-0x10(%rbp)
 1125bc1:	movabs $0x8000000000000002,%rax
 1125bcb:	cmp    %rax,%rdx
 1125bce:	jl     1125c78 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x198>
 1125bd4:	mov    (%rsi),%rax
 1125bd7:	mov    %rdx,%rcx
 1125bda:	sub    $0x2,%rcx
 1125bde:	cmp    %rax,%rcx
 1125be1:	jb     1125c5f <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x17f>
 1125be3:	cmp    $0x0,%rcx
 1125be7:	jge    1125c16 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x136>
 1125be9:	movabs $0x7fffffffffffffff,%rdx
 1125bf3:	cmp    %rdx,%rax
 1125bf6:	ja     1125c50 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x170>
 1125bf8:	mov    %rax,%r9
 1125bfb:	add    %rcx,%r9
 1125bfe:	mov    %rax,%rdx
 1125c01:	xor    %r9,%rdx
 1125c04:	mov    %rcx,%r8
 1125c07:	xor    %r9,%r8
 1125c0a:	and    %r8,%rdx
 1125c0d:	cmp    $0x0,%rdx
 1125c11:	jl     1125c38 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x158>
 1125c13:	mov    %r9,%rcx
 1125c16:	mov    (%rsi),%rdx
 1125c19:	cmp    %rdx,%rcx
 1125c1c:	jb     1125c28 <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x148>
 1125c1e:	mov    %rcx,%rsi
 1125c21:	call   115a570 <myl_qbe_fail_normalized_index_bounds>
 1125c26:	ud2
 1125c28:	mov    0x20(%rsi),%rax
 1125c2c:	imul   $0x10,%rcx,%rcx
 1125c30:	mov    %rax,%rsi
 1125c33:	add    %rcx,%rsi
 1125c36:	jmp    1125c6d <myl_f_432edef79ffd67a21359fd311aaa808ded11e8afb9a2c5969ead355cc07a3fc5+0x18d>
 1125c38:	mov    %rax,%rsi
 1125c3b:	mov    $0x40,%r8d
 1125c41:	mov    %rsi,%rdx
 1125c44:	mov    $0x0,%esi
 1125c49:	call   115a780 <myl_qbe_fail_overflow_op>
 1125c4e:	ud2
 1125c50:	mov    %rax,%rsi
 1125c53:	mov    $0x140,%edx
 1125c58:	call   115a8c0 <myl_qbe_fail_cast>
 1125c5d:	ud2
 1125c5f:	mov    0x20(%rsi),%rax
 1125c63:	imul   $0x10,%rcx,%rcx
 1125c67:	mov    %rax,%rsi
 1125c6a:	add    %rcx,%rsi
 1125c6d:	lea    -0x18(%rbp),%rdx
 1125c71:	call   1121cb0 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b>
 1125c76:	leave
 1125c77:	ret
 1125c78:	mov    $0x40,%r8d
 1125c7e:	mov    $0x2,%ecx
 1125c83:	mov    $0x1,%esi
 1125c88:	call   115a780 <myl_qbe_fail_overflow_op>
 1125c8d:	ud2
 1125c8f:	mov    $0x40,%r8d
 1125c95:	mov    $0x1,%ecx
 1125c9a:	mov    $0x1,%esi
 1125c9f:	call   115a780 <myl_qbe_fail_overflow_op>
 1125ca4:	ud2
 1125ca6:	call   115a940 <myl_qbe_fail_frame>
 1125cab:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
