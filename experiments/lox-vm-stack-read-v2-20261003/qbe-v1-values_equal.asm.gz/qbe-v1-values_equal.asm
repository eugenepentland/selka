
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-vm-stack-read-20261003/.tmp-lox-vm-stack-read-20261003/qualified-equal-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001121cb0 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b>:
 1121cb0:	endbr64
 1121cb4:	mov    (%rsi),%eax
 1121cb6:	cmp    $0x0,%rax
 1121cba:	je     1121de3 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x133>
 1121cc0:	cmp    $0x1,%rax
 1121cc4:	sete   %cl
 1121cc7:	movzbq %cl,%rcx
 1121ccb:	cmp    $0x0,%ecx
 1121cce:	jne    1121d9e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0xee>
 1121cd4:	cmp    $0x2,%rax
 1121cd8:	je     1121d37 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x87>
 1121cda:	cmp    $0x3,%rax
 1121cde:	jne    1121dfd <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x14d>
 1121ce4:	mov    0x8(%rsi),%rcx
 1121ce8:	mov    (%rdx),%eax
 1121cea:	cmp    $0x0,%rax
 1121cee:	je     1121d2d <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x7d>
 1121cf0:	cmp    $0x1,%rax
 1121cf4:	je     1121d23 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x73>
 1121cf6:	cmp    $0x2,%rax
 1121cfa:	je     1121d19 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x69>
 1121cfc:	cmp    $0x3,%rax
 1121d00:	jne    1121dfd <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x14d>
 1121d06:	mov    0x8(%rdx),%rax
 1121d0a:	cmp    %rax,%rcx
 1121d0d:	sete   %al
 1121d10:	movzbq %al,%rax
 1121d14:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d19:	mov    $0x0,%eax
 1121d1e:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d23:	mov    $0x0,%eax
 1121d28:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d2d:	mov    $0x0,%eax
 1121d32:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d37:	mov    0x8(%rsi),%rcx
 1121d3b:	mov    (%rdx),%eax
 1121d3d:	cmp    $0x0,%rax
 1121d41:	je     1121d94 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0xe4>
 1121d43:	cmp    $0x1,%rax
 1121d47:	je     1121d8a <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0xda>
 1121d49:	cmp    $0x2,%rax
 1121d4d:	je     1121d63 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0xb3>
 1121d4f:	cmp    $0x3,%rax
 1121d53:	jne    1121dfd <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x14d>
 1121d59:	mov    $0x0,%eax
 1121d5e:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d63:	mov    0x8(%rdx),%rax
 1121d67:	movq   %rcx,%xmm1
 1121d6c:	movq   %rax,%xmm0
 1121d71:	ucomisd %xmm0,%xmm1
 1121d75:	sete   %al
 1121d78:	movzbq %al,%rax
 1121d7c:	setnp  %cl
 1121d7f:	movzbq %cl,%rcx
 1121d83:	and    %ecx,%eax
 1121d85:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d8a:	mov    $0x0,%eax
 1121d8f:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d94:	mov    $0x0,%eax
 1121d99:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121d9e:	movzbq 0x8(%rsi),%rcx
 1121da3:	mov    (%rdx),%eax
 1121da5:	cmp    $0x0,%rax
 1121da9:	je     1121ddc <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x12c>
 1121dab:	cmp    $0x1,%rax
 1121daf:	je     1121dcb <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x11b>
 1121db1:	cmp    $0x2,%rax
 1121db5:	je     1121dc4 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x114>
 1121db7:	cmp    $0x3,%rax
 1121dbb:	jne    1121dfd <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x14d>
 1121dbd:	mov    $0x0,%eax
 1121dc2:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121dc4:	mov    $0x0,%eax
 1121dc9:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121dcb:	movzbq 0x8(%rdx),%rax
 1121dd0:	cmp    %rax,%rcx
 1121dd3:	sete   %al
 1121dd6:	movzbq %al,%rax
 1121dda:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121ddc:	mov    $0x0,%eax
 1121de1:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121de3:	mov    (%rdx),%eax
 1121de5:	cmp    $0x0,%rax
 1121de9:	je     1121e19 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x169>
 1121deb:	cmp    $0x1,%rax
 1121def:	je     1121e12 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x162>
 1121df1:	cmp    $0x2,%rax
 1121df5:	je     1121e0b <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x15b>
 1121df7:	cmp    $0x3,%rax
 1121dfb:	je     1121e04 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x154>
 1121dfd:	mov    $0x0,%eax
 1121e02:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121e04:	mov    $0x0,%eax
 1121e09:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121e0b:	mov    $0x0,%eax
 1121e10:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121e12:	mov    $0x0,%eax
 1121e17:	jmp    1121e1e <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b+0x16e>
 1121e19:	mov    $0x1,%eax
 1121e1e:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
