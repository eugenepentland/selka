
.tmp-mut-argument/read-version/controls/parity-micro-list_append_sum-after-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

000000000100a070 <entry_run>:
 100a070:	push   %rbp
 100a071:	mov    %rsp,%rbp
 100a074:	push   %r15
 100a076:	push   %r14
 100a078:	push   %r13
 100a07a:	push   %r12
 100a07c:	push   %rbx
 100a07d:	sub    $0x178,%rsp
 100a084:	mov    %rdi,%rbx
 100a087:	cmpq   $0x0,0x38a0(%rdi)
 100a08f:	je     100a0a1 <entry_run+0x31>
 100a091:	cmpq   $0x0,0x20(%rbx)
 100a096:	jne    100b52b <entry_run+0x14bb>
 100a09c:	jmp    100a1b1 <entry_run+0x141>
 100a0a1:	mov    $0x1,%edi
 100a0a6:	mov    $0x40,%esi
 100a0ab:	call   101bcb0 <calloc@plt>
 100a0b0:	test   %rax,%rax
 100a0b3:	je     100a180 <entry_run+0x110>
 100a0b9:	mov    %rax,0x38a0(%rbx)
 100a0c0:	mov    0x3870(%rbx),%rcx
 100a0c7:	lea    0xa0(%rcx),%rdx
 100a0ce:	test   %rcx,%rcx
 100a0d1:	mov    $0x1002d48,%ecx
 100a0d6:	cmovne %rdx,%rcx
 100a0da:	mov    %rcx,(%rax)
 100a0dd:	cmpq   $0x0,0x8(%rcx)
 100a0e2:	je     100a0ee <entry_run+0x7e>
 100a0e4:	cmpq   $0x0,(%rcx)
 100a0e8:	je     100a187 <entry_run+0x117>
 100a0ee:	mov    0x10(%rcx),%rdx
 100a0f2:	test   %rdx,%rdx
 100a0f5:	mov    $0x2710,%esi
 100a0fa:	cmovne %rdx,%rsi
 100a0fe:	mov    %rsi,0x18(%rax)
 100a102:	mov    0x18(%rcx),%rdx
 100a106:	test   %rdx,%rdx
 100a109:	mov    $0xf4240,%esi
 100a10e:	cmovne %rdx,%rsi
 100a112:	mov    %rsi,0x10(%rax)
 100a116:	mov    0x20(%rcx),%rdx
 100a11a:	test   %rdx,%rdx
 100a11d:	mov    $0x10000,%edi
 100a122:	cmovne %rdx,%rdi
 100a126:	mov    %rdi,0x20(%rax)
 100a12a:	mov    0x28(%rcx),%rsi
 100a12e:	test   %rsi,%rsi
 100a131:	mov    $0x40,%edx
 100a136:	cmovne %rsi,%rdx
 100a13a:	mov    %rdx,0x28(%rax)
 100a13e:	mov    0x30(%rcx),%r8
 100a142:	test   %r8,%r8
 100a145:	mov    $0x100000,%esi
 100a14a:	cmovne %r8,%rsi
 100a14e:	mov    %rsi,0x30(%rax)
 100a152:	cmp    $0x186a0,%rdi
 100a159:	ja     100a179 <entry_run+0x109>
 100a15b:	cmp    $0x81,%rdx
 100a162:	setae  %dl
 100a165:	cmp    $0x4000001,%rsi
 100a16c:	setae  %sil
 100a170:	or     %dl,%sil
 100a173:	cmp    $0x1,%sil
 100a177:	jne    100a18e <entry_run+0x11e>
 100a179:	mov    $0x1002eda,%esi
 100a17e:	jmp    100a19e <entry_run+0x12e>
 100a180:	mov    $0x1002d82,%esi
 100a185:	jmp    100a19e <entry_run+0x12e>
 100a187:	mov    $0x100302b,%esi
 100a18c:	jmp    100a19e <entry_run+0x12e>
 100a18e:	cmpq   $0x0,0x8(%rcx)
 100a193:	je     100aaef <entry_run+0xa7f>
 100a199:	mov    $0x1003017,%esi
 100a19e:	mov    %rbx,%rdi
 100a1a1:	call   100bdd0 <fail>
 100a1a6:	cmpq   $0x0,0x20(%rbx)
 100a1ab:	jne    100b52b <entry_run+0x14bb>
 100a1b1:	movq   $0x0,-0x178(%rbp)
 100a1bc:	movq   $0x0,-0x40(%rbp)
 100a1c4:	movq   $0x0,-0xa8(%rbp)
 100a1cf:	mov    0x2c8(%rbx),%r12d
 100a1d6:	vxorps %xmm0,%xmm0,%xmm0
 100a1da:	vmovups %ymm0,-0x60(%rbp)
 100a1df:	vmovups %ymm0,-0x70(%rbp)
 100a1e4:	lea    -0x60(%rbp),%rax
 100a1e8:	movq   $0x1001ab8,-0x168(%rbp)
 100a1f3:	movl   $0x2,-0x150(%rbp)
 100a1fd:	lea    -0x178(%rbp),%r15
 100a204:	mov    %r15,-0x160(%rbp)
 100a20b:	lea    -0x70(%rbp),%r13
 100a20f:	mov    %r13,-0x158(%rbp)
 100a216:	movq   $0x1001ab8,-0x148(%rbp)
 100a221:	movl   $0x2,-0x130(%rbp)
 100a22b:	lea    -0x40(%rbp),%rcx
 100a22f:	mov    %rcx,-0x140(%rbp)
 100a236:	lea    -0x68(%rbp),%rcx
 100a23a:	mov    %rcx,-0x138(%rbp)
 100a241:	movq   $0x1001ab8,-0x128(%rbp)
 100a24c:	movl   $0x2,-0x110(%rbp)
 100a256:	lea    -0xa8(%rbp),%rcx
 100a25d:	mov    %rcx,-0x120(%rbp)
 100a264:	mov    %rax,-0x118(%rbp)
 100a26b:	movq   $0x1001c78,-0x108(%rbp)
 100a276:	movl   $0x0,-0xf0(%rbp)
 100a280:	lea    -0x78(%rbp),%rax
 100a284:	mov    %rax,-0x100(%rbp)
 100a28b:	lea    -0x58(%rbp),%rax
 100a28f:	mov    %rax,-0xf8(%rbp)
 100a296:	movq   $0x1001c78,-0xe8(%rbp)
 100a2a1:	movl   $0x0,-0xd0(%rbp)
 100a2ab:	lea    -0x38(%rbp),%rax
 100a2af:	mov    %rax,-0xe0(%rbp)
 100a2b6:	lea    -0x50(%rbp),%rax
 100a2ba:	mov    %rax,-0xd8(%rbp)
 100a2c1:	movq   $0x1001c78,-0xc8(%rbp)
 100a2cc:	movl   $0x0,-0xb0(%rbp)
 100a2d6:	lea    -0x198(%rbp),%rax
 100a2dd:	mov    %rax,-0xc0(%rbp)
 100a2e4:	lea    -0x48(%rbp),%rax
 100a2e8:	mov    %rax,-0xb8(%rbp)
 100a2ef:	mov    0x1860(%rbx),%rax
 100a2f6:	test   %rax,%rax
 100a2f9:	je     100b554 <entry_run+0x14e4>
 100a2ff:	mov    0x3d80(%rbx),%rcx
 100a306:	mov    0x70(%rax),%rax
 100a30a:	mov    %rcx,-0x98(%rbp)
 100a311:	lea    -0x168(%rbp),%rcx
 100a318:	mov    %rcx,-0x90(%rbp)
 100a31f:	movq   $0x6,-0x88(%rbp)
 100a32a:	mov    %rax,-0x80(%rbp)
 100a32e:	lea    -0x98(%rbp),%rax
 100a335:	mov    %rax,0x3d80(%rbx)
 100a33c:	cmpq   $0xffffffffffffffff,0x10(%rbx)
 100a341:	je     100a378 <entry_run+0x308>
 100a343:	movl   $0x1,0x38e0(%rbx)
 100a34d:	vmovups %ymm0,0x38e4(%rbx)
 100a355:	vmovups %ymm0,0x38f0(%rbx)
 100a35d:	movq   $0x100311a,0x3910(%rbx)
 100a368:	mov    $0x100356d,%esi
 100a36d:	mov    %rbx,%rdi
 100a370:	vzeroupper
 100a373:	call   100bdd0 <fail>
 100a378:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 100a37d:	je     100a3bf <entry_run+0x34f>
 100a37f:	cmpq   $0x0,0x20(%rbx)
 100a384:	jne    100a3af <entry_run+0x33f>
 100a386:	movl   $0x1,0x38e0(%rbx)
 100a390:	vxorps %xmm0,%xmm0,%xmm0
 100a394:	vmovups %ymm0,0x38e4(%rbx)
 100a39c:	vmovups %ymm0,0x38f0(%rbx)
 100a3a4:	movq   $0x1003163,0x3910(%rbx)
 100a3af:	mov    $0x1003582,%esi
 100a3b4:	mov    %rbx,%rdi
 100a3b7:	vzeroupper
 100a3ba:	call   100bdd0 <fail>
 100a3bf:	movq   $0x0,-0x30(%rbp)
 100a3c7:	cmpq   $0x0,0x1860(%rbx)
 100a3cf:	je     100b582 <entry_run+0x1512>
 100a3d5:	lea    0x258(%rbx),%rdi
 100a3dc:	mov    0x2c8(%rbx),%ecx
 100a3e2:	mov    $0x1001a48,%esi
 100a3e7:	xor    %edx,%edx
 100a3e9:	vzeroupper
 100a3ec:	call   100f950 <rc_list_new>
 100a3f1:	test   %rax,%rax
 100a3f4:	je     100b582 <entry_run+0x1512>
 100a3fa:	movabs $0x5000000000000001,%r14
 100a404:	mov    %rax,-0x38(%rbp)
 100a408:	movq   $0x1001ab8,-0xe8(%rbp)
 100a413:	movl   $0x2,-0xd0(%rbp)
 100a41d:	mov    %rax,-0x78(%rbp)
 100a421:	movq   $0x1001ab8,-0x108(%rbp)
 100a42c:	movl   $0x2,-0xf0(%rbp)
 100a436:	movl   $0x0,-0x50(%rbp)
 100a43d:	movl   $0x1,-0x58(%rbp)
 100a444:	mov    %rax,-0x30(%rbp)
 100a448:	test   %r14,-0x10(%rax)
 100a44c:	je     100a49e <entry_run+0x42e>
 100a44e:	lea    -0x38(%rbp),%rsi
 100a452:	lea    -0x30(%rbp),%rdx
 100a456:	lea    0x258(%rbx),%rdi
 100a45d:	mov    %r12d,%ecx
 100a460:	call   1017ec0 <myl_rc_native_take>
 100a465:	test   %eax,%eax
 100a467:	jne    100a4a6 <entry_run+0x436>
 100a469:	mov    0x1860(%rbx),%rcx
 100a470:	test   %rcx,%rcx
 100a473:	je     100b554 <entry_run+0x14e4>
 100a479:	mov    0x78(%rcx),%eax
 100a47c:	movl   $0x0,0x78(%rcx)
 100a483:	test   %eax,%eax
 100a485:	lea    -0x98(%rbp),%r12
 100a48c:	lea    0x258(%rbx),%r15
 100a493:	jne    100a847 <entry_run+0x7d7>
 100a499:	jmp    100b365 <entry_run+0x12f5>
 100a49e:	movq   $0x0,-0x30(%rbp)
 100a4a6:	movl   $0x0,-0x58(%rbp)
 100a4ad:	movq   $0x1001ab8,-0xe8(%rbp)
 100a4b8:	movl   $0x2,-0xd0(%rbp)
 100a4c2:	movl   $0x1,-0x50(%rbp)
 100a4c9:	cmpl   $0x0,-0x70(%rbp)
 100a4cd:	je     100a4e6 <entry_run+0x476>
 100a4cf:	lea    -0x168(%rbp),%rsi
 100a4d6:	mov    %rbx,%rdi
 100a4d9:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100a4de:	mov    -0xd0(%rbp),%ecx
 100a4e4:	jmp    100a4eb <entry_run+0x47b>
 100a4e6:	mov    $0x2,%ecx
 100a4eb:	mov    -0x38(%rbp),%rax
 100a4ef:	mov    %rax,-0x178(%rbp)
 100a4f6:	movl   $0x0,-0x50(%rbp)
 100a4fd:	movq   $0x1001ab8,-0x168(%rbp)
 100a508:	mov    %r15,-0x160(%rbp)
 100a50f:	mov    %r13,-0x158(%rbp)
 100a516:	mov    %ecx,-0x150(%rbp)
 100a51c:	movl   $0x1,-0x70(%rbp)
 100a523:	cmp    $0x8,%ecx
 100a526:	jne    100a5fe <entry_run+0x58e>
 100a52c:	movq   $0x0,-0x38(%rbp)
 100a534:	test   %rax,%rax
 100a537:	lea    0x258(%rbx),%r15
 100a53e:	lea    -0x38(%rbp),%rsi
 100a542:	je     100a590 <entry_run+0x520>
 100a544:	mov    -0x10(%rax),%rcx
 100a548:	movabs $0x4000000000000002,%rdx
 100a552:	test   %rdx,%rcx
 100a555:	jne    100a590 <entry_run+0x520>
 100a557:	cmpq   $0x0,0x1860(%rbx)
 100a55f:	je     100b554 <entry_run+0x14e4>
 100a565:	test   $0x1,%cl
 100a568:	jne    100b554 <entry_run+0x14e4>
 100a56e:	mov    -0x18(%rax),%rcx
 100a572:	mov    -0x20(%rax),%rdx
 100a576:	or     %rcx,%rdx
 100a579:	je     100b554 <entry_run+0x14e4>
 100a57f:	cmp    $0xffffffffffffffff,%rcx
 100a583:	je     100b45b <entry_run+0x13eb>
 100a589:	inc    %rcx
 100a58c:	mov    %rcx,-0x18(%rax)
 100a590:	mov    %rax,-0x38(%rbp)
 100a594:	movq   $0x1001ab8,-0xe8(%rbp)
 100a59f:	mov    %rsi,-0xe0(%rbp)
 100a5a6:	lea    -0x50(%rbp),%rcx
 100a5aa:	mov    %rcx,-0xd8(%rbp)
 100a5b1:	movl   $0x8,-0xd0(%rbp)
 100a5bb:	mov    %rax,-0x78(%rbp)
 100a5bf:	movq   $0x1001ab8,-0x108(%rbp)
 100a5ca:	lea    -0x78(%rbp),%rcx
 100a5ce:	mov    %rcx,-0x100(%rbp)
 100a5d5:	lea    -0x58(%rbp),%rcx
 100a5d9:	mov    %rcx,-0xf8(%rbp)
 100a5e0:	movl   $0x8,-0xf0(%rbp)
 100a5ea:	movl   $0x1,-0x58(%rbp)
 100a5f1:	movl   $0x0,-0x50(%rbp)
 100a5f8:	mov    %rax,-0x30(%rbp)
 100a5fc:	jmp    100a651 <entry_run+0x5e1>
 100a5fe:	mov    -0x58(%rbp),%ecx
 100a601:	testb  $0x18,-0xf0(%rbp)
 100a608:	mov    %rax,-0x30(%rbp)
 100a60c:	lea    0x258(%rbx),%r15
 100a613:	jne    100a651 <entry_run+0x5e1>
 100a615:	and    $0x1,%ecx
 100a618:	je     100a651 <entry_run+0x5e1>
 100a61a:	test   %rax,%rax
 100a61d:	je     100aa0f <entry_run+0x99f>
 100a623:	test   %r14,-0x10(%rax)
 100a627:	je     100aa0f <entry_run+0x99f>
 100a62d:	lea    -0x38(%rbp),%rsi
 100a631:	lea    -0x30(%rbp),%rdx
 100a635:	mov    %r15,%rdi
 100a638:	mov    %r12d,%ecx
 100a63b:	call   1017ec0 <myl_rc_native_take>
 100a640:	test   %eax,%eax
 100a642:	lea    -0x68(%rbp),%r12
 100a646:	jne    100aa1f <entry_run+0x9af>
 100a64c:	jmp    100a81e <entry_run+0x7ae>
 100a651:	lea    -0x38(%rbp),%rdx
 100a655:	lea    -0x30(%rbp),%rcx
 100a659:	mov    $0x1001ab8,%esi
 100a65e:	mov    %r15,%rdi
 100a661:	mov    %r12d,%r8d
 100a664:	call   10182e0 <myl_rc_native_retain>
 100a669:	test   %eax,%eax
 100a66b:	je     100a81e <entry_run+0x7ae>
 100a671:	movq   $0x1001ab8,-0xe8(%rbp)
 100a67c:	movl   $0x2,-0xd0(%rbp)
 100a686:	movl   $0x1,-0x50(%rbp)
 100a68d:	cmpl   $0x0,-0x58(%rbp)
 100a691:	lea    -0x68(%rbp),%r12
 100a695:	je     100a6a6 <entry_run+0x636>
 100a697:	mov    %rbx,%rdi
 100a69a:	lea    -0x108(%rbp),%rsi
 100a6a1:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100a6a6:	cmpl   $0x0,-0x68(%rbp)
 100a6aa:	lea    -0x40(%rbp),%r14
 100a6ae:	je     100a6bf <entry_run+0x64f>
 100a6b0:	lea    -0x148(%rbp),%rsi
 100a6b7:	mov    %rbx,%rdi
 100a6ba:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100a6bf:	mov    -0x38(%rbp),%rax
 100a6c3:	mov    %rax,-0x40(%rbp)
 100a6c7:	movl   $0x0,-0x50(%rbp)
 100a6ce:	movq   $0x1001ab8,-0x148(%rbp)
 100a6d9:	mov    %r14,-0x140(%rbp)
 100a6e0:	mov    %r12,-0x138(%rbp)
 100a6e7:	mov    -0xd0(%rbp),%eax
 100a6ed:	mov    %eax,-0x130(%rbp)
 100a6f3:	movl   $0x1,-0x68(%rbp)
 100a6fa:	cmpl   $0x0,-0x70(%rbp)
 100a6fe:	je     100a70f <entry_run+0x69f>
 100a700:	lea    -0x168(%rbp),%rsi
 100a707:	mov    %rbx,%rdi
 100a70a:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100a70f:	movq   $0xf42400,-0x30(%rbp)
 100a717:	movq   $0x1001ab8,-0x148(%rbp)
 100a722:	movl   $0x2,-0x130(%rbp)
 100a72c:	mov    %r14,-0x140(%rbp)
 100a733:	mov    %r12,-0x138(%rbp)
 100a73a:	mov    0x1860(%rbx),%rcx
 100a741:	test   %rcx,%rcx
 100a744:	je     100b554 <entry_run+0x14e4>
 100a74a:	mov    0x40(%rcx),%rax
 100a74e:	test   %rax,%rax
 100a751:	je     100b554 <entry_run+0x14e4>
 100a757:	movabs $0xbf58476d1ce4e5b9,%r12
 100a761:	mov    0x30(%rcx),%rcx
 100a765:	mov    $0x1001ab8,%esi
 100a76a:	mov    $0x1001ab8,%edx
 100a76f:	shr    $0x3,%rdx
 100a773:	shr    $0x21,%rsi
 100a777:	xor    %rdx,%rsi
 100a77a:	imul   %r12,%rsi
 100a77e:	mov    %rsi,%rdx
 100a781:	shr    $0x1b,%rdx
 100a785:	xor    %rsi,%rdx
 100a788:	xor    $0x2,%rdx
 100a78c:	dec    %rax
 100a78f:	jmp    100a7a3 <entry_run+0x733>
 100a791:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a7a0:	inc    %rdx
 100a7a3:	and    %rax,%rdx
 100a7a6:	lea    (%rdx,%rdx,4),%rsi
 100a7aa:	mov    (%rcx,%rsi,8),%rsi
 100a7ae:	test   %rsi,%rsi
 100a7b1:	je     100b554 <entry_run+0x14e4>
 100a7b7:	cmp    $0x1001ab8,%rsi
 100a7be:	jne    100a7a0 <entry_run+0x730>
 100a7c0:	lea    (%rdx,%rdx,4),%rsi
 100a7c4:	cmpl   $0x2,0x20(%rcx,%rsi,8)
 100a7c9:	jne    100a7a0 <entry_run+0x730>
 100a7cb:	lea    (%rcx,%rsi,8),%rdx
 100a7cf:	mov    0x8(%rdx),%rdx
 100a7d3:	test   %rdx,%rdx
 100a7d6:	je     100b554 <entry_run+0x14e4>
 100a7dc:	mov    0x8(%rdx),%rsi
 100a7e0:	cmpl   $0x1,0x8(%rsi)
 100a7e4:	jne    100b554 <entry_run+0x14e4>
 100a7ea:	movabs $0x4000000000000002,%r14
 100a7f4:	mov    -0x40(%rbp),%r13
 100a7f8:	test   %r13,%r13
 100a7fb:	je     100a867 <entry_run+0x7f7>
 100a7fd:	mov    -0x10(%r13),%rdi
 100a801:	lea    -0x2(%r14),%r8
 100a805:	mov    %rdi,%r9
 100a808:	shr    $0x28,%r9
 100a80c:	and    $0xfffff,%r9d
 100a813:	xor    %edx,%edx
 100a815:	test   %r8,%rdi
 100a818:	cmovne %r9d,%edx
 100a81c:	jmp    100a869 <entry_run+0x7f9>
 100a81e:	mov    0x1860(%rbx),%rcx
 100a825:	test   %rcx,%rcx
 100a828:	je     100b554 <entry_run+0x14e4>
 100a82e:	mov    0x78(%rcx),%eax
 100a831:	movl   $0x0,0x78(%rcx)
 100a838:	test   %eax,%eax
 100a83a:	lea    -0x98(%rbp),%r12
 100a841:	je     100b365 <entry_run+0x12f5>
 100a847:	cmp    $0x1,%eax
 100a84a:	jne    100aa01 <entry_run+0x991>
 100a850:	mov    $0x10034a2,%esi
 100a855:	cmpl   $0x0,0x2c4(%rbx)
 100a85c:	jne    100b35d <entry_run+0x12ed>
 100a862:	jmp    100b34e <entry_run+0x12de>
 100a867:	xor    %edx,%edx
 100a869:	mov    %rsi,%rdi
 100a86c:	shr    $0x3,%rdi
 100a870:	mov    %rsi,%r8
 100a873:	shr    $0x21,%r8
 100a877:	xor    %rdi,%r8
 100a87a:	imul   %r12,%r8
 100a87e:	mov    %r8,%rdi
 100a881:	shr    $0x1b,%rdi
 100a885:	xor    %r8,%rdi
 100a888:	xor    $0x1,%rdi
 100a88c:	and    %rax,%rdi
 100a88f:	cmpl   $0x0,-0x68(%rbp)
 100a893:	lea    (%rdi,%rdi,4),%r8
 100a897:	mov    (%rcx,%r8,8),%r8
 100a89b:	jne    100a8be <entry_run+0x84e>
 100a89d:	jmp    100a96e <entry_run+0x8fe>
 100a8a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a8b0:	inc    %rdi
 100a8b3:	and    %rax,%rdi
 100a8b6:	lea    (%rdi,%rdi,4),%r8
 100a8ba:	mov    (%rcx,%r8,8),%r8
 100a8be:	test   %r8,%r8
 100a8c1:	je     100b554 <entry_run+0x14e4>
 100a8c7:	cmp    %rsi,%r8
 100a8ca:	jne    100a8b0 <entry_run+0x840>
 100a8cc:	lea    (%rdi,%rdi,4),%r8
 100a8d0:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a8d6:	jne    100a8b0 <entry_run+0x840>
 100a8d8:	lea    (%rcx,%r8,8),%rax
 100a8dc:	cmpq   $0x0,0x8(%rax)
 100a8e1:	je     100b554 <entry_run+0x14e4>
 100a8e7:	cmpq   $0x8,(%rsi)
 100a8eb:	jne    100b554 <entry_run+0x14e4>
 100a8f1:	test   %r13,%r13
 100a8f4:	je     100ab47 <entry_run+0xad7>
 100a8fa:	mov    -0x10(%r13),%rax
 100a8fe:	movabs $0x2000000000000002,%rcx
 100a908:	test   %rcx,%rax
 100a90b:	je     100aa55 <entry_run+0x9e5>
 100a911:	movq   $0x0,-0x190(%rbp)
 100a91c:	lea    -0x190(%rbp),%rcx
 100a923:	mov    %r15,%rdi
 100a926:	mov    %r13,%rsi
 100a929:	call   1016d60 <clone_payload>
 100a92e:	test   %eax,%eax
 100a930:	je     100aa86 <entry_run+0xa16>
 100a936:	cmp    $0x1,%eax
 100a939:	je     100b339 <entry_run+0x12c9>
 100a93f:	cmp    $0x4,%eax
 100a942:	lea    -0x98(%rbp),%r12
 100a949:	jb     100b353 <entry_run+0x12e3>
 100a94f:	jmp    100aa0a <entry_run+0x99a>
 100a954:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a960:	inc    %rdi
 100a963:	and    %rax,%rdi
 100a966:	lea    (%rdi,%rdi,4),%r8
 100a96a:	mov    (%rcx,%r8,8),%r8
 100a96e:	test   %r8,%r8
 100a971:	je     100b554 <entry_run+0x14e4>
 100a977:	cmp    %rsi,%r8
 100a97a:	jne    100a960 <entry_run+0x8f0>
 100a97c:	lea    (%rdi,%rdi,4),%r8
 100a980:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a986:	jne    100a960 <entry_run+0x8f0>
 100a988:	lea    (%rcx,%r8,8),%rax
 100a98c:	cmpq   $0x0,0x8(%rax)
 100a991:	je     100b554 <entry_run+0x14e4>
 100a997:	cmpq   $0x8,(%rsi)
 100a99b:	jne    100b554 <entry_run+0x14e4>
 100a9a1:	test   %r13,%r13
 100a9a4:	je     100ab47 <entry_run+0xad7>
 100a9aa:	mov    -0x10(%r13),%rax
 100a9ae:	movabs $0x2000000000000002,%rcx
 100a9b8:	test   %rcx,%rax
 100a9bb:	je     100ab06 <entry_run+0xa96>
 100a9c1:	movq   $0x0,-0x190(%rbp)
 100a9cc:	lea    -0x190(%rbp),%rcx
 100a9d3:	mov    %r15,%rdi
 100a9d6:	mov    %r13,%rsi
 100a9d9:	call   1016d60 <clone_payload>
 100a9de:	xor    %ecx,%ecx
 100a9e0:	test   %eax,%eax
 100a9e2:	jne    100a9eb <entry_run+0x97b>
 100a9e4:	mov    -0x190(%rbp),%rcx
 100a9eb:	jne    100ab36 <entry_run+0xac6>
 100a9f1:	mov    %rcx,-0x40(%rbp)
 100a9f5:	movl   $0x1,-0x68(%rbp)
 100a9fc:	jmp    100ab47 <entry_run+0xad7>
 100aa01:	cmp    $0x4,%eax
 100aa04:	jb     100b353 <entry_run+0x12e3>
 100aa0a:	call   101bde0 <abort@plt>
 100aa0f:	mov    %rax,-0x38(%rbp)
 100aa13:	movq   $0x0,-0x30(%rbp)
 100aa1b:	lea    -0x68(%rbp),%r12
 100aa1f:	movl   $0x0,-0x58(%rbp)
 100aa26:	movq   $0x1001ab8,-0xe8(%rbp)
 100aa31:	movl   $0x2,-0xd0(%rbp)
 100aa3b:	movl   $0x1,-0x50(%rbp)
 100aa42:	cmpl   $0x0,-0x68(%rbp)
 100aa46:	lea    -0x40(%rbp),%r14
 100aa4a:	jne    100a6b0 <entry_run+0x640>
 100aa50:	jmp    100a6bf <entry_run+0x64f>
 100aa55:	lea    -0x2(%r14),%rcx
 100aa59:	test   %rcx,%rax
 100aa5c:	jne    100ab47 <entry_run+0xad7>
 100aa62:	test   $0x1,%al
 100aa64:	jne    100b554 <entry_run+0x14e4>
 100aa6a:	mov    -0x20(%r13),%rax
 100aa6e:	cmp    $0x1,%rax
 100aa72:	je     100ab47 <entry_run+0xad7>
 100aa78:	test   %rax,%rax
 100aa7b:	je     100ab2a <entry_run+0xaba>
 100aa81:	jmp    100a911 <entry_run+0x8a1>
 100aa86:	mov    -0x190(%rbp),%rax
 100aa8d:	mov    %rax,-0x40(%rbp)
 100aa91:	mov    -0x10(%r13),%rax
 100aa95:	test   %r14,%rax
 100aa98:	jne    100aae5 <entry_run+0xa75>
 100aa9a:	mov    0x1860(%rbx),%rcx
 100aaa1:	test   %rcx,%rcx
 100aaa4:	je     100b554 <entry_run+0x14e4>
 100aaaa:	test   $0x1,%al
 100aaac:	jne    100b554 <entry_run+0x14e4>
 100aab2:	lea    -0x20(%r13),%rdx
 100aab6:	mov    (%rdx),%rsi
 100aab9:	test   %rsi,%rsi
 100aabc:	je     100b554 <entry_run+0x14e4>
 100aac2:	dec    %rsi
 100aac5:	mov    %rsi,(%rdx)
 100aac8:	jne    100aae5 <entry_run+0xa75>
 100aaca:	cmpq   $0x0,-0x18(%r13)
 100aacf:	jne    100aae5 <entry_run+0xa75>
 100aad1:	or     $0x1,%rax
 100aad5:	mov    %rax,-0x10(%r13)
 100aad9:	mov    0x60(%rcx),%rax
 100aadd:	mov    %rax,-0x20(%r13)
 100aae1:	mov    %rdx,0x60(%rcx)
 100aae5:	mov    %r15,%rdi
 100aae8:	call   1012db0 <myl_rc_drain>
 100aaed:	jmp    100ab47 <entry_run+0xad7>
 100aaef:	movl   $0x1,0x38(%rax)
 100aaf6:	cmpq   $0x0,0x20(%rbx)
 100aafb:	jne    100b52b <entry_run+0x14bb>
 100ab01:	jmp    100a1b1 <entry_run+0x141>
 100ab06:	lea    -0x2(%r14),%rcx
 100ab0a:	test   %rcx,%rax
 100ab0d:	jne    100ab47 <entry_run+0xad7>
 100ab0f:	test   $0x1,%al
 100ab11:	jne    100b554 <entry_run+0x14e4>
 100ab17:	mov    -0x20(%r13),%rax
 100ab1b:	cmp    $0x1,%rax
 100ab1f:	je     100ab47 <entry_run+0xad7>
 100ab21:	test   %rax,%rax
 100ab24:	jne    100a9c1 <entry_run+0x951>
 100ab2a:	cmpq   $0x0,-0x18(%r13)
 100ab2f:	jne    100ab47 <entry_run+0xad7>
 100ab31:	jmp    100b554 <entry_run+0x14e4>
 100ab36:	cmp    $0x1,%eax
 100ab39:	je     100b339 <entry_run+0x12c9>
 100ab3f:	test   %eax,%eax
 100ab41:	jne    100b53f <entry_run+0x14cf>
 100ab47:	lea    -0x30(%rbp),%r13
 100ab4b:	xor    %edx,%edx
 100ab4d:	xor    %r14d,%r14d
 100ab50:	jmp    100ab99 <entry_run+0xb29>
 100ab52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100ab60:	mov    (%rsi),%rdx
 100ab63:	mov    %r15,%rdi
 100ab66:	mov    %r13,%rcx
 100ab69:	call   1010020 <rc_list_insert_at>
 100ab6e:	xor    %edx,%edx
 100ab70:	test   %eax,%eax
 100ab72:	je     100b55c <entry_run+0x14ec>
 100ab78:	xor    %eax,%eax
 100ab7a:	cmp    $0xf423ff,%r14
 100ab81:	lea    0x1(%r14),%r14
 100ab85:	setb   %al
 100ab88:	mov    %rax,-0x30(%rbp)
 100ab8c:	cmp    $0xf42400,%r14
 100ab93:	je     100ad1b <entry_run+0xcab>
 100ab99:	mov    %r14,-0x30(%rbp)
 100ab9d:	mov    -0x40(%rbp),%rsi
 100aba1:	mov    (%rsi),%rcx
 100aba4:	mov    0x10(%rsi),%rax
 100aba8:	cmp    0x8(%rsi),%rcx
 100abac:	setae  %dil
 100abb0:	cmp    $0xffffffffffffffff,%rax
 100abb4:	sete   %r8b
 100abb8:	or     %dil,%r8b
 100abbb:	jne    100ab60 <entry_run+0xaf0>
 100abbd:	mov    $0x1,%edi
 100abc2:	test   %edx,%edx
 100abc4:	je     100abdf <entry_run+0xb6f>
 100abc6:	mov    0x20(%rsi),%rdx
 100abca:	mov    %r14,(%rdx,%rcx,8)
 100abce:	inc    %rcx
 100abd1:	mov    %rcx,(%rsi)
 100abd4:	inc    %rax
 100abd7:	mov    %rax,0x10(%rsi)
 100abdb:	mov    %edi,%edx
 100abdd:	jmp    100ab78 <entry_run+0xb08>
 100abdf:	mov    0x1860(%rbx),%rdi
 100abe6:	test   %rdi,%rdi
 100abe9:	je     100ab60 <entry_run+0xaf0>
 100abef:	cmpq   $0x0,0x60(%rdi)
 100abf4:	jne    100ab60 <entry_run+0xaf0>
 100abfa:	mov    0x18(%rsi),%rdx
 100abfe:	test   %rdx,%rdx
 100ac01:	je     100ab60 <entry_run+0xaf0>
 100ac07:	mov    0x30(%rdx),%r8d
 100ac0b:	cmp    $0x7,%r8d
 100ac0f:	je     100ac1a <entry_run+0xbaa>
 100ac11:	test   %r8d,%r8d
 100ac14:	jne    100ab60 <entry_run+0xaf0>
 100ac1a:	mov    (%rdx),%r8
 100ac1d:	popcnt %r8,%r9
 100ac22:	cmp    $0x1,%r9d
 100ac26:	setne  %r9b
 100ac2a:	test   $0xf,%r8b
 100ac2e:	sete   %r8b
 100ac32:	or     %r9b,%r8b
 100ac35:	jne    100ab60 <entry_run+0xaf0>
 100ac3b:	mov    0x40(%rdi),%r8
 100ac3f:	test   %r8,%r8
 100ac42:	je     100ab60 <entry_run+0xaf0>
 100ac48:	mov    0x30(%rdi),%rdi
 100ac4c:	mov    0x24(%rdi),%r9d
 100ac50:	test   %r9,%r9
 100ac53:	sete   %r10b
 100ac57:	cmp    %r9,%r8
 100ac5a:	setb   %r11b
 100ac5e:	or     %r10b,%r11b
 100ac61:	jne    100ac7b <entry_run+0xc0b>
 100ac63:	dec    %r9d
 100ac66:	lea    (%r9,%r9,4),%r10
 100ac6a:	cmp    %rdx,(%rdi,%r10,8)
 100ac6e:	jne    100ac7b <entry_run+0xc0b>
 100ac70:	lea    (%rdi,%r10,8),%r10
 100ac74:	cmpl   $0x2,0x20(%r10)
 100ac79:	je     100acf2 <entry_run+0xc82>
 100ac7b:	mov    %rdx,%r9
 100ac7e:	shr    $0x3,%r9
 100ac82:	mov    %rdx,%r10
 100ac85:	shr    $0x21,%r10
 100ac89:	xor    %r9,%r10
 100ac8c:	imul   %r12,%r10
 100ac90:	mov    %r10,%r9
 100ac93:	shr    $0x1b,%r9
 100ac97:	xor    %r10,%r9
 100ac9a:	xor    $0x2,%r9
 100ac9e:	dec    %r8
 100aca1:	jmp    100acb3 <entry_run+0xc43>
 100aca3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100acb0:	inc    %r9
 100acb3:	and    %r8,%r9
 100acb6:	lea    (%r9,%r9,4),%r10
 100acba:	mov    (%rdi,%r10,8),%r10
 100acbe:	test   %r10,%r10
 100acc1:	je     100ab60 <entry_run+0xaf0>
 100acc7:	cmp    %rdx,%r10
 100acca:	jne    100acb0 <entry_run+0xc40>
 100accc:	lea    (%r9,%r9,4),%r10
 100acd0:	cmpl   $0x2,0x20(%rdi,%r10,8)
 100acd6:	jne    100acb0 <entry_run+0xc40>
 100acd8:	lea    0x1(%r9),%edx
 100acdc:	mov    $0xffffffff,%r8d
 100ace2:	cmp    %r8,%r9
 100ace5:	mov    $0x0,%r8d
 100aceb:	cmovae %r8d,%edx
 100acef:	mov    %edx,0x24(%rdi)
 100acf2:	lea    (%r9,%r9,4),%rdx
 100acf6:	mov    0x8(%rdi,%rdx,8),%rdx
 100acfb:	test   %rdx,%rdx
 100acfe:	je     100ab60 <entry_run+0xaf0>
 100ad04:	xor    %edi,%edi
 100ad06:	cmpl   $0x0,0x78(%rdx)
 100ad0a:	sete   %dl
 100ad0d:	jne    100ab60 <entry_run+0xaf0>
 100ad13:	mov    %dl,%dil
 100ad16:	jmp    100abc6 <entry_run+0xb56>
 100ad1b:	movq   $0x0,-0x30(%rbp)
 100ad23:	mov    -0x40(%rbp),%rax
 100ad27:	cmpl   $0x8,-0x130(%rbp)
 100ad2e:	jne    100ae1b <entry_run+0xdab>
 100ad34:	mov    -0x68(%rbp),%ecx
 100ad37:	and    $0x1,%ecx
 100ad3a:	je     100ae1b <entry_run+0xdab>
 100ad40:	movq   $0x0,-0x38(%rbp)
 100ad48:	test   %rax,%rax
 100ad4b:	lea    -0x98(%rbp),%r12
 100ad52:	lea    -0x38(%rbp),%r14
 100ad56:	je     100ada4 <entry_run+0xd34>
 100ad58:	mov    -0x10(%rax),%rcx
 100ad5c:	movabs $0x4000000000000002,%rdx
 100ad66:	test   %rdx,%rcx
 100ad69:	jne    100ada4 <entry_run+0xd34>
 100ad6b:	cmpq   $0x0,0x1860(%rbx)
 100ad73:	je     100b554 <entry_run+0x14e4>
 100ad79:	test   $0x1,%cl
 100ad7c:	jne    100b554 <entry_run+0x14e4>
 100ad82:	mov    -0x18(%rax),%rcx
 100ad86:	mov    -0x20(%rax),%rdx
 100ad8a:	or     %rcx,%rdx
 100ad8d:	je     100b554 <entry_run+0x14e4>
 100ad93:	cmp    $0xffffffffffffffff,%rcx
 100ad97:	je     100b3fc <entry_run+0x138c>
 100ad9d:	inc    %rcx
 100ada0:	mov    %rcx,-0x18(%rax)
 100ada4:	movq   $0x1001ab8,-0xe8(%rbp)
 100adaf:	mov    %r14,-0xe0(%rbp)
 100adb6:	lea    -0x50(%rbp),%rcx
 100adba:	mov    %rcx,-0xd8(%rbp)
 100adc1:	movl   $0x8,-0xd0(%rbp)
 100adcb:	mov    %rax,-0x78(%rbp)
 100adcf:	movq   $0x1001ab8,-0x108(%rbp)
 100adda:	lea    -0x78(%rbp),%rcx
 100adde:	mov    %rcx,-0x100(%rbp)
 100ade5:	lea    -0x58(%rbp),%rcx
 100ade9:	mov    %rcx,-0xf8(%rbp)
 100adf0:	movl   $0x8,-0xf0(%rbp)
 100adfa:	movl   $0x1,-0x58(%rbp)
 100ae01:	movl   $0x0,-0x50(%rbp)
 100ae08:	mov    %rax,-0x30(%rbp)
 100ae0c:	movq   $0x0,-0x38(%rbp)
 100ae14:	test   %rax,%rax
 100ae17:	jne    100ae37 <entry_run+0xdc7>
 100ae19:	jmp    100ae83 <entry_run+0xe13>
 100ae1b:	lea    -0x98(%rbp),%r12
 100ae22:	lea    -0x38(%rbp),%r14
 100ae26:	mov    %rax,-0x30(%rbp)
 100ae2a:	movq   $0x0,-0x38(%rbp)
 100ae32:	test   %rax,%rax
 100ae35:	je     100ae83 <entry_run+0xe13>
 100ae37:	mov    -0x10(%rax),%rcx
 100ae3b:	movabs $0x4000000000000002,%rdx
 100ae45:	test   %rdx,%rcx
 100ae48:	jne    100ae83 <entry_run+0xe13>
 100ae4a:	cmpq   $0x0,0x1860(%rbx)
 100ae52:	je     100b554 <entry_run+0x14e4>
 100ae58:	test   $0x1,%cl
 100ae5b:	jne    100b554 <entry_run+0x14e4>
 100ae61:	mov    -0x18(%rax),%rcx
 100ae65:	mov    -0x20(%rax),%rdx
 100ae69:	or     %rcx,%rdx
 100ae6c:	je     100b554 <entry_run+0x14e4>
 100ae72:	cmp    $0xffffffffffffffff,%rcx
 100ae76:	je     100b3fc <entry_run+0x138c>
 100ae7c:	inc    %rcx
 100ae7f:	mov    %rcx,-0x18(%rax)
 100ae83:	mov    %rax,-0x38(%rbp)
 100ae87:	movq   $0x1001ab8,-0xe8(%rbp)
 100ae92:	mov    %r14,-0xe0(%rbp)
 100ae99:	lea    -0x50(%rbp),%rcx
 100ae9d:	mov    %rcx,-0xd8(%rbp)
 100aea4:	movl   $0x8,-0xd0(%rbp)
 100aeae:	movl   $0x1,-0x50(%rbp)
 100aeb5:	cmpl   $0x0,-0x58(%rbp)
 100aeb9:	je     100aece <entry_run+0xe5e>
 100aebb:	mov    %rbx,%rdi
 100aebe:	lea    -0x108(%rbp),%rsi
 100aec5:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100aeca:	mov    -0x38(%rbp),%rax
 100aece:	mov    %rax,-0x78(%rbp)
 100aed2:	movq   $0x1001ab8,-0x108(%rbp)
 100aedd:	lea    -0x78(%rbp),%rcx
 100aee1:	mov    %rcx,-0x100(%rbp)
 100aee8:	lea    -0x58(%rbp),%rcx
 100aeec:	mov    %rcx,-0xf8(%rbp)
 100aef3:	movl   $0x8,-0xf0(%rbp)
 100aefd:	mov    %rax,-0x30(%rbp)
 100af01:	movq   $0x1001ab8,-0xe8(%rbp)
 100af0c:	mov    %r14,-0xe0(%rbp)
 100af13:	lea    -0x50(%rbp),%rcx
 100af17:	mov    %rcx,-0xd8(%rbp)
 100af1e:	movl   $0x8,-0xd0(%rbp)
 100af28:	movl   $0x1,-0x50(%rbp)
 100af2f:	movl   $0x0,-0x58(%rbp)
 100af36:	cmpl   $0x0,-0x60(%rbp)
 100af3a:	je     100af4f <entry_run+0xedf>
 100af3c:	mov    %rbx,%rdi
 100af3f:	lea    -0x128(%rbp),%rsi
 100af46:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100af4b:	mov    -0x38(%rbp),%rax
 100af4f:	mov    %rax,-0xa8(%rbp)
 100af56:	movq   $0x1001ab8,-0x128(%rbp)
 100af61:	lea    -0xa8(%rbp),%rcx
 100af68:	mov    %rcx,-0x120(%rbp)
 100af6f:	lea    -0x60(%rbp),%rcx
 100af73:	mov    %rcx,-0x118(%rbp)
 100af7a:	movl   $0x8,-0x110(%rbp)
 100af84:	movl   $0x1,-0x60(%rbp)
 100af8b:	movl   $0x0,-0x50(%rbp)
 100af92:	mov    (%rax),%rsi
 100af95:	mov    %rsi,-0x30(%rbp)
 100af99:	test   %rsi,%rsi
 100af9c:	js     100b58d <entry_run+0x151d>
 100afa2:	lea    -0x10(%rsi),%rcx
 100afa6:	movabs $0xffffffffffffff1,%rdx
 100afb0:	cmp    %rdx,%rcx
 100afb3:	jae    100afda <entry_run+0xf6a>
 100afb5:	mov    0x20(%rax),%rcx
 100afb9:	xor    %eax,%eax
 100afbb:	xor    %edi,%edi
 100afbd:	xor    %r12d,%r12d
 100afc0:	mov    (%rcx,%rdi,8),%rdx
 100afc4:	add    %rdx,%r12
 100afc7:	jo     100b564 <entry_run+0x14f4>
 100afcd:	inc    %rdi
 100afd0:	mov    %r12,%rax
 100afd3:	cmp    %rdi,%rsi
 100afd6:	jne    100afc0 <entry_run+0xf50>
 100afd8:	jmp    100b00d <entry_run+0xf9d>
 100afda:	test   %rsi,%rsi
 100afdd:	je     100b00a <entry_run+0xf9a>
 100afdf:	mov    0x20(%rax),%rcx
 100afe3:	xor    %eax,%eax
 100afe5:	xor    %edi,%edi
 100afe7:	xor    %r12d,%r12d
 100afea:	nopw   0x0(%rax,%rax,1)
 100aff0:	mov    (%rcx,%rdi,8),%rdx
 100aff4:	add    %rdx,%r12
 100aff7:	jo     100b573 <entry_run+0x1503>
 100affd:	inc    %rdi
 100b000:	mov    %r12,%rax
 100b003:	cmp    %rdi,%rsi
 100b006:	jne    100aff0 <entry_run+0xf80>
 100b008:	jmp    100b00d <entry_run+0xf9d>
 100b00a:	xor    %r12d,%r12d
 100b00d:	movq   $0x1,-0x30(%rbp)
 100b015:	mov    $0x1,%edi
 100b01a:	mov    $0x20,%esi
 100b01f:	call   101bcb0 <calloc@plt>
 100b024:	mov    %rax,-0xa0(%rbp)
 100b02b:	test   %rax,%rax
 100b02e:	jne    100b038 <entry_run+0xfc8>
 100b030:	mov    %rbx,%rdi
 100b033:	call   100c480 <myl_qbe_fail_allocation>
 100b038:	lea    -0x190(%rbp),%rdi
 100b03f:	mov    $0x18,%esi
 100b044:	mov    $0x1003272,%edx
 100b049:	mov    %r12,%rcx
 100b04c:	xor    %eax,%eax
 100b04e:	call   101bdf0 <snprintf@plt>
 100b053:	test   %eax,%eax
 100b055:	jle    100b25f <entry_run+0x11ef>
 100b05b:	mov    %eax,%r13d
 100b05e:	mov    $0x40,%edi
 100b063:	cmp    $0x41,%eax
 100b066:	jb     100b201 <entry_run+0x1191>
 100b06c:	mov    $0x80,%edi
 100b071:	cmp    $0x81,%r13d
 100b078:	jb     100b201 <entry_run+0x1191>
 100b07e:	mov    $0x100,%edi
 100b083:	cmp    $0x101,%r13d
 100b08a:	jb     100b201 <entry_run+0x1191>
 100b090:	mov    $0x200,%edi
 100b095:	cmp    $0x201,%r13d
 100b09c:	jb     100b201 <entry_run+0x1191>
 100b0a2:	mov    $0x400,%edi
 100b0a7:	cmp    $0x401,%r13d
 100b0ae:	jb     100b201 <entry_run+0x1191>
 100b0b4:	mov    $0x800,%edi
 100b0b9:	cmp    $0x801,%r13d
 100b0c0:	jb     100b201 <entry_run+0x1191>
 100b0c6:	mov    $0x1000,%edi
 100b0cb:	cmp    $0x1001,%r13d
 100b0d2:	jb     100b201 <entry_run+0x1191>
 100b0d8:	mov    $0x2000,%edi
 100b0dd:	cmp    $0x2001,%r13d
 100b0e4:	jb     100b201 <entry_run+0x1191>
 100b0ea:	mov    $0x4000,%edi
 100b0ef:	cmp    $0x4001,%r13d
 100b0f6:	jb     100b201 <entry_run+0x1191>
 100b0fc:	mov    $0x8000,%edi
 100b101:	cmp    $0x8001,%r13d
 100b108:	jb     100b201 <entry_run+0x1191>
 100b10e:	mov    $0x10000,%edi
 100b113:	cmp    $0x10001,%r13d
 100b11a:	jb     100b201 <entry_run+0x1191>
 100b120:	mov    $0x20000,%edi
 100b125:	cmp    $0x20001,%r13d
 100b12c:	jb     100b201 <entry_run+0x1191>
 100b132:	mov    $0x40000,%edi
 100b137:	cmp    $0x40001,%r13d
 100b13e:	jb     100b201 <entry_run+0x1191>
 100b144:	mov    $0x80000,%edi
 100b149:	cmp    $0x80001,%r13d
 100b150:	jb     100b201 <entry_run+0x1191>
 100b156:	mov    $0x100000,%edi
 100b15b:	cmp    $0x100001,%r13d
 100b162:	jb     100b201 <entry_run+0x1191>
 100b168:	mov    $0x200000,%edi
 100b16d:	cmp    $0x200001,%r13d
 100b174:	jb     100b201 <entry_run+0x1191>
 100b17a:	mov    $0x400000,%edi
 100b17f:	cmp    $0x400001,%r13d
 100b186:	jb     100b201 <entry_run+0x1191>
 100b188:	mov    $0x800000,%edi
 100b18d:	cmp    $0x800001,%r13d
 100b194:	jb     100b201 <entry_run+0x1191>
 100b196:	mov    $0x1000000,%edi
 100b19b:	cmp    $0x1000001,%r13d
 100b1a2:	jb     100b201 <entry_run+0x1191>
 100b1a4:	mov    $0x2000000,%edi
 100b1a9:	cmp    $0x2000001,%r13d
 100b1b0:	jb     100b201 <entry_run+0x1191>
 100b1b2:	mov    $0x4000000,%edi
 100b1b7:	cmp    $0x4000001,%r13d
 100b1be:	jb     100b201 <entry_run+0x1191>
 100b1c0:	mov    $0x8000000,%edi
 100b1c5:	cmp    $0x8000001,%r13d
 100b1cc:	jb     100b201 <entry_run+0x1191>
 100b1ce:	mov    $0x10000000,%edi
 100b1d3:	cmp    $0x10000001,%r13d
 100b1da:	jb     100b201 <entry_run+0x1191>
 100b1dc:	mov    $0x20000000,%edi
 100b1e1:	cmp    $0x20000001,%r13d
 100b1e8:	jb     100b201 <entry_run+0x1191>
 100b1ea:	xor    %edi,%edi
 100b1ec:	cmp    $0x40000001,%r13d
 100b1f3:	setae  %dil
 100b1f7:	shl    $0x1e,%edi
 100b1fa:	add    $0x40000000,%rdi
 100b201:	mov    %rdi,%r12
 100b204:	call   101bca0 <malloc@plt>
 100b209:	test   %rax,%rax
 100b20c:	je     100b2e0 <entry_run+0x1270>
 100b212:	mov    %rax,%r14
 100b215:	mov    %r13d,%r13d
 100b218:	mov    -0xa0(%rbp),%r15
 100b21f:	mov    %rax,(%r15)
 100b222:	mov    %r12,0x10(%r15)
 100b226:	lea    -0x190(%rbp),%rsi
 100b22d:	mov    %rax,%rdi
 100b230:	mov    %r13,%rdx
 100b233:	call   101bcc0 <memcpy@plt>
 100b238:	lea    0x8(%r15),%rax
 100b23c:	mov    %r13,0x8(%r15)
 100b240:	add    $0x18,%r15
 100b244:	cmp    %r13,%r12
 100b247:	jne    100b2aa <entry_run+0x123a>
 100b249:	mov    %r12,%rsi
 100b24c:	mov    %rax,-0x170(%rbp)
 100b253:	add    %r12,%rsi
 100b256:	mov    -0xa0(%rbp),%r13
 100b25d:	jmp    100b280 <entry_run+0x1210>
 100b25f:	mov    -0xa0(%rbp),%r13
 100b266:	lea    0x18(%r13),%r15
 100b26a:	mov    %r13,%rax
 100b26d:	add    $0x8,%rax
 100b271:	mov    %rax,-0x170(%rbp)
 100b278:	mov    $0x40,%esi
 100b27d:	xor    %r14d,%r14d
 100b280:	mov    %r14,%rdi
 100b283:	mov    %rsi,%r12
 100b286:	call   101be00 <realloc@plt>
 100b28b:	test   %rax,%rax
 100b28e:	je     100b322 <entry_run+0x12b2>
 100b294:	mov    %rax,%r14
 100b297:	mov    %rax,0x0(%r13)
 100b29b:	mov    %r12,0x10(%r13)
 100b29f:	mov    0x8(%r13),%r13
 100b2a3:	mov    -0x170(%rbp),%rax
 100b2aa:	movb   $0xa,(%r14,%r13,1)
 100b2af:	incq   (%rax)
 100b2b2:	mov    -0xa0(%rbp),%r13
 100b2b9:	cmpl   $0x0,0x1c(%r13)
 100b2be:	lea    -0x98(%rbp),%r12
 100b2c5:	je     100b304 <entry_run+0x1294>
 100b2c7:	mov    $0x1002f32,%esi
 100b2cc:	mov    %rbx,%rdi
 100b2cf:	call   100bdd0 <fail>
 100b2d4:	lea    0x258(%rbx),%r15
 100b2db:	jmp    100b480 <entry_run+0x1410>
 100b2e0:	mov    -0xa0(%rbp),%r13
 100b2e7:	mov    %r13,%r15
 100b2ea:	add    $0x18,%r15
 100b2ee:	movl   $0x1,0x18(%r13)
 100b2f6:	cmpl   $0x0,0x1c(%r13)
 100b2fb:	lea    -0x98(%rbp),%r12
 100b302:	jne    100b2c7 <entry_run+0x1257>
 100b304:	cmpl   $0x0,(%r15)
 100b308:	je     100b406 <entry_run+0x1396>
 100b30e:	mov    %rbx,%rdi
 100b311:	call   100c480 <myl_qbe_fail_allocation>
 100b316:	lea    0x258(%rbx),%r15
 100b31d:	jmp    100b480 <entry_run+0x1410>
 100b322:	movl   $0x1,(%r15)
 100b329:	cmpl   $0x0,0x1c(%r13)
 100b32e:	lea    -0x98(%rbp),%r12
 100b335:	jne    100b2c7 <entry_run+0x1257>
 100b337:	jmp    100b304 <entry_run+0x1294>
 100b339:	mov    $0x10034a2,%esi
 100b33e:	cmpl   $0x0,0x2c4(%rbx)
 100b345:	lea    -0x98(%rbp),%r12
 100b34c:	jne    100b35d <entry_run+0x12ed>
 100b34e:	mov    $0x1,%eax
 100b353:	mov    %eax,%eax
 100b355:	mov    0x1004940(,%rax,8),%rsi
 100b35d:	mov    %rbx,%rdi
 100b360:	call   100bdd0 <fail>
 100b365:	cmp    %r12,0x3d80(%rbx)
 100b36c:	jne    100b554 <entry_run+0x14e4>
 100b372:	mov    -0x80(%rbp),%rsi
 100b376:	mov    %r15,%rdi
 100b379:	call   1014d80 <myl_rc_scope_unwind>
 100b37e:	mov    -0x88(%rbp),%r14
 100b385:	test   %r14,%r14
 100b388:	je     100b3cc <entry_run+0x135c>
 100b38a:	mov    %r14,%r15
 100b38d:	shl    $0x5,%r15
 100b391:	add    $0xffffffffffffffe0,%r15
 100b395:	jmp    100b3b4 <entry_run+0x1344>
 100b397:	nopw   0x0(%rax,%rax,1)
 100b3a0:	add    %r15,%rsi
 100b3a3:	mov    %rbx,%rdi
 100b3a6:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100b3ab:	add    $0xffffffffffffffe0,%r15
 100b3af:	dec    %r14
 100b3b2:	je     100b3cc <entry_run+0x135c>
 100b3b4:	mov    -0x90(%rbp),%rsi
 100b3bb:	mov    0x10(%rsi,%r15,1),%rax
 100b3c0:	test   %rax,%rax
 100b3c3:	je     100b3a0 <entry_run+0x1330>
 100b3c5:	cmpl   $0x0,(%rax)
 100b3c8:	jne    100b3a0 <entry_run+0x1330>
 100b3ca:	jmp    100b3ab <entry_run+0x133b>
 100b3cc:	cmp    %r12,0x3d80(%rbx)
 100b3d3:	jne    100b554 <entry_run+0x14e4>
 100b3d9:	mov    0x1860(%rbx),%rax
 100b3e0:	test   %rax,%rax
 100b3e3:	je     100b515 <entry_run+0x14a5>
 100b3e9:	mov    0x70(%rax),%rax
 100b3ed:	cmp    -0x80(%rbp),%rax
 100b3f1:	je     100b51d <entry_run+0x14ad>
 100b3f7:	jmp    100b554 <entry_run+0x14e4>
 100b3fc:	mov    $0x100346f,%esi
 100b401:	jmp    100b35d <entry_run+0x12ed>
 100b406:	mov    0x11f03(%rip),%rax        # 101d310 <stdout@GLIBC_2.2.5>
 100b40d:	mov    (%rax),%r14
 100b410:	mov    0x8(%r13),%r12
 100b414:	test   %r12,%r12
 100b417:	lea    0x258(%rbx),%r15
 100b41e:	je     100b439 <entry_run+0x13c9>
 100b420:	mov    0x0(%r13),%rdi
 100b424:	mov    $0x1,%esi
 100b429:	mov    %r12,%rdx
 100b42c:	mov    %r14,%rcx
 100b42f:	call   101bd70 <fwrite@plt>
 100b434:	cmp    %r12,%rax
 100b437:	jne    100b46c <entry_run+0x13fc>
 100b439:	mov    %r14,%rdi
 100b43c:	call   101be10 <fflush@plt>
 100b441:	test   %eax,%eax
 100b443:	lea    -0x98(%rbp),%r12
 100b44a:	je     100b480 <entry_run+0x1410>
 100b44c:	mov    $0x1003432,%esi
 100b451:	mov    %rbx,%rdi
 100b454:	call   100bdd0 <fail>
 100b459:	jmp    100b480 <entry_run+0x1410>
 100b45b:	mov    $0x100346f,%esi
 100b460:	lea    -0x98(%rbp),%r12
 100b467:	jmp    100b35d <entry_run+0x12ed>
 100b46c:	mov    $0x1003432,%esi
 100b471:	mov    %rbx,%rdi
 100b474:	call   100bdd0 <fail>
 100b479:	lea    -0x98(%rbp),%r12
 100b480:	mov    0x0(%r13),%rdi
 100b484:	call   101bd10 <free@plt>
 100b489:	mov    %r13,%rdi
 100b48c:	call   101bd10 <free@plt>
 100b491:	movq   $0x0,-0x30(%rbp)
 100b499:	cmp    %r12,0x3d80(%rbx)
 100b4a0:	jne    100b554 <entry_run+0x14e4>
 100b4a6:	mov    -0x80(%rbp),%rsi
 100b4aa:	mov    %r15,%rdi
 100b4ad:	call   1014d80 <myl_rc_scope_unwind>
 100b4b2:	mov    -0x88(%rbp),%r14
 100b4b9:	test   %r14,%r14
 100b4bc:	je     100b4fc <entry_run+0x148c>
 100b4be:	mov    %r14,%r15
 100b4c1:	shl    $0x5,%r15
 100b4c5:	add    $0xffffffffffffffe0,%r15
 100b4c9:	jmp    100b4e4 <entry_run+0x1474>
 100b4cb:	nopl   0x0(%rax,%rax,1)
 100b4d0:	add    %r15,%rsi
 100b4d3:	mov    %rbx,%rdi
 100b4d6:	call   100b5a0 <myl_qbe_rc_slot_drop>
 100b4db:	add    $0xffffffffffffffe0,%r15
 100b4df:	dec    %r14
 100b4e2:	je     100b4fc <entry_run+0x148c>
 100b4e4:	mov    -0x90(%rbp),%rsi
 100b4eb:	mov    0x10(%rsi,%r15,1),%rax
 100b4f0:	test   %rax,%rax
 100b4f3:	je     100b4d0 <entry_run+0x1460>
 100b4f5:	cmpl   $0x0,(%rax)
 100b4f8:	jne    100b4d0 <entry_run+0x1460>
 100b4fa:	jmp    100b4db <entry_run+0x146b>
 100b4fc:	cmp    %r12,0x3d80(%rbx)
 100b503:	jne    100b554 <entry_run+0x14e4>
 100b505:	mov    0x1860(%rbx),%rax
 100b50c:	test   %rax,%rax
 100b50f:	jne    100b3e9 <entry_run+0x1379>
 100b515:	xor    %eax,%eax
 100b517:	cmp    -0x80(%rbp),%rax
 100b51b:	jne    100b554 <entry_run+0x14e4>
 100b51d:	mov    -0x98(%rbp),%rax
 100b524:	mov    %rax,0x3d80(%rbx)
 100b52b:	xor    %eax,%eax
 100b52d:	add    $0x178,%rsp
 100b534:	pop    %rbx
 100b535:	pop    %r12
 100b537:	pop    %r13
 100b539:	pop    %r14
 100b53b:	pop    %r15
 100b53d:	pop    %rbp
 100b53e:	ret
 100b53f:	cmp    $0x4,%eax
 100b542:	jae    100aa0a <entry_run+0x99a>
 100b548:	lea    -0x98(%rbp),%r12
 100b54f:	jmp    100b353 <entry_run+0x12e3>
 100b554:	vzeroupper
 100b557:	call   10108d4 <myl_rc_invariant_failed>
 100b55c:	mov    %rbx,%rdi
 100b55f:	call   100c480 <myl_qbe_fail_allocation>
 100b564:	mov    %rax,-0x30(%rbp)
 100b568:	mov    %rbx,%rdi
 100b56b:	mov    %rax,%rsi
 100b56e:	call   100c510 <myl_qbe_fail_overflow_op>
 100b573:	mov    %rax,-0x30(%rbp)
 100b577:	mov    %rbx,%rdi
 100b57a:	mov    %rax,%rsi
 100b57d:	call   100c510 <myl_qbe_fail_overflow_op>
 100b582:	mov    %rbx,%rdi
 100b585:	vzeroupper
 100b588:	call   100c480 <myl_qbe_fail_allocation>
 100b58d:	mov    %rbx,%rdi
 100b590:	call   100c570 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
