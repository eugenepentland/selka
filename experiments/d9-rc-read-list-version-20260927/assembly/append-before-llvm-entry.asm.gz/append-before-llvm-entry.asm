
.tmp-mut-argument/read-version/controls/parity-micro-list_append_sum-before-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

000000000100a050 <entry_run>:
 100a050:	push   %rbp
 100a051:	mov    %rsp,%rbp
 100a054:	push   %r15
 100a056:	push   %r14
 100a058:	push   %r13
 100a05a:	push   %r12
 100a05c:	push   %rbx
 100a05d:	sub    $0x178,%rsp
 100a064:	mov    %rdi,%rbx
 100a067:	cmpq   $0x0,0x38a0(%rdi)
 100a06f:	je     100a081 <entry_run+0x31>
 100a071:	cmpq   $0x0,0x20(%rbx)
 100a076:	jne    100b445 <entry_run+0x13f5>
 100a07c:	jmp    100a191 <entry_run+0x141>
 100a081:	mov    $0x1,%edi
 100a086:	mov    $0x40,%esi
 100a08b:	call   101bc20 <calloc@plt>
 100a090:	test   %rax,%rax
 100a093:	je     100a160 <entry_run+0x110>
 100a099:	mov    %rax,0x38a0(%rbx)
 100a0a0:	mov    0x3870(%rbx),%rcx
 100a0a7:	lea    0xa0(%rcx),%rdx
 100a0ae:	test   %rcx,%rcx
 100a0b1:	mov    $0x1002d48,%ecx
 100a0b6:	cmovne %rdx,%rcx
 100a0ba:	mov    %rcx,(%rax)
 100a0bd:	cmpq   $0x0,0x8(%rcx)
 100a0c2:	je     100a0ce <entry_run+0x7e>
 100a0c4:	cmpq   $0x0,(%rcx)
 100a0c8:	je     100a167 <entry_run+0x117>
 100a0ce:	mov    0x10(%rcx),%rdx
 100a0d2:	test   %rdx,%rdx
 100a0d5:	mov    $0x2710,%esi
 100a0da:	cmovne %rdx,%rsi
 100a0de:	mov    %rsi,0x18(%rax)
 100a0e2:	mov    0x18(%rcx),%rdx
 100a0e6:	test   %rdx,%rdx
 100a0e9:	mov    $0xf4240,%esi
 100a0ee:	cmovne %rdx,%rsi
 100a0f2:	mov    %rsi,0x10(%rax)
 100a0f6:	mov    0x20(%rcx),%rdx
 100a0fa:	test   %rdx,%rdx
 100a0fd:	mov    $0x10000,%edi
 100a102:	cmovne %rdx,%rdi
 100a106:	mov    %rdi,0x20(%rax)
 100a10a:	mov    0x28(%rcx),%rsi
 100a10e:	test   %rsi,%rsi
 100a111:	mov    $0x40,%edx
 100a116:	cmovne %rsi,%rdx
 100a11a:	mov    %rdx,0x28(%rax)
 100a11e:	mov    0x30(%rcx),%r8
 100a122:	test   %r8,%r8
 100a125:	mov    $0x100000,%esi
 100a12a:	cmovne %r8,%rsi
 100a12e:	mov    %rsi,0x30(%rax)
 100a132:	cmp    $0x186a0,%rdi
 100a139:	ja     100a159 <entry_run+0x109>
 100a13b:	cmp    $0x81,%rdx
 100a142:	setae  %dl
 100a145:	cmp    $0x4000001,%rsi
 100a14c:	setae  %sil
 100a150:	or     %dl,%sil
 100a153:	cmp    $0x1,%sil
 100a157:	jne    100a16e <entry_run+0x11e>
 100a159:	mov    $0x1002eda,%esi
 100a15e:	jmp    100a17e <entry_run+0x12e>
 100a160:	mov    $0x1002d82,%esi
 100a165:	jmp    100a17e <entry_run+0x12e>
 100a167:	mov    $0x100302b,%esi
 100a16c:	jmp    100a17e <entry_run+0x12e>
 100a16e:	cmpq   $0x0,0x8(%rcx)
 100a173:	je     100aacf <entry_run+0xa7f>
 100a179:	mov    $0x1003017,%esi
 100a17e:	mov    %rbx,%rdi
 100a181:	call   100bd40 <fail>
 100a186:	cmpq   $0x0,0x20(%rbx)
 100a18b:	jne    100b445 <entry_run+0x13f5>
 100a191:	movq   $0x0,-0x178(%rbp)
 100a19c:	movq   $0x0,-0x40(%rbp)
 100a1a4:	movq   $0x0,-0xa8(%rbp)
 100a1af:	mov    0x2c8(%rbx),%r12d
 100a1b6:	vxorps %xmm0,%xmm0,%xmm0
 100a1ba:	vmovups %ymm0,-0x60(%rbp)
 100a1bf:	vmovups %ymm0,-0x70(%rbp)
 100a1c4:	lea    -0x60(%rbp),%rax
 100a1c8:	movq   $0x1001ab8,-0x168(%rbp)
 100a1d3:	movl   $0x2,-0x150(%rbp)
 100a1dd:	lea    -0x178(%rbp),%r15
 100a1e4:	mov    %r15,-0x160(%rbp)
 100a1eb:	lea    -0x70(%rbp),%r13
 100a1ef:	mov    %r13,-0x158(%rbp)
 100a1f6:	movq   $0x1001ab8,-0x148(%rbp)
 100a201:	movl   $0x2,-0x130(%rbp)
 100a20b:	lea    -0x40(%rbp),%rcx
 100a20f:	mov    %rcx,-0x140(%rbp)
 100a216:	lea    -0x68(%rbp),%rcx
 100a21a:	mov    %rcx,-0x138(%rbp)
 100a221:	movq   $0x1001ab8,-0x128(%rbp)
 100a22c:	movl   $0x2,-0x110(%rbp)
 100a236:	lea    -0xa8(%rbp),%rcx
 100a23d:	mov    %rcx,-0x120(%rbp)
 100a244:	mov    %rax,-0x118(%rbp)
 100a24b:	movq   $0x1001c78,-0x108(%rbp)
 100a256:	movl   $0x0,-0xf0(%rbp)
 100a260:	lea    -0x78(%rbp),%rax
 100a264:	mov    %rax,-0x100(%rbp)
 100a26b:	lea    -0x58(%rbp),%rax
 100a26f:	mov    %rax,-0xf8(%rbp)
 100a276:	movq   $0x1001c78,-0xe8(%rbp)
 100a281:	movl   $0x0,-0xd0(%rbp)
 100a28b:	lea    -0x38(%rbp),%rax
 100a28f:	mov    %rax,-0xe0(%rbp)
 100a296:	lea    -0x50(%rbp),%rax
 100a29a:	mov    %rax,-0xd8(%rbp)
 100a2a1:	movq   $0x1001c78,-0xc8(%rbp)
 100a2ac:	movl   $0x0,-0xb0(%rbp)
 100a2b6:	lea    -0x198(%rbp),%rax
 100a2bd:	mov    %rax,-0xc0(%rbp)
 100a2c4:	lea    -0x48(%rbp),%rax
 100a2c8:	mov    %rax,-0xb8(%rbp)
 100a2cf:	mov    0x1860(%rbx),%rax
 100a2d6:	test   %rax,%rax
 100a2d9:	je     100b4cf <entry_run+0x147f>
 100a2df:	mov    0x3d80(%rbx),%rcx
 100a2e6:	mov    0x70(%rax),%rax
 100a2ea:	mov    %rcx,-0x98(%rbp)
 100a2f1:	lea    -0x168(%rbp),%rcx
 100a2f8:	mov    %rcx,-0x90(%rbp)
 100a2ff:	movq   $0x6,-0x88(%rbp)
 100a30a:	mov    %rax,-0x80(%rbp)
 100a30e:	lea    -0x98(%rbp),%rax
 100a315:	mov    %rax,0x3d80(%rbx)
 100a31c:	cmpq   $0xffffffffffffffff,0x10(%rbx)
 100a321:	je     100a358 <entry_run+0x308>
 100a323:	movl   $0x1,0x38e0(%rbx)
 100a32d:	vmovups %ymm0,0x38e4(%rbx)
 100a335:	vmovups %ymm0,0x38f0(%rbx)
 100a33d:	movq   $0x100311a,0x3910(%rbx)
 100a348:	mov    $0x100356d,%esi
 100a34d:	mov    %rbx,%rdi
 100a350:	vzeroupper
 100a353:	call   100bd40 <fail>
 100a358:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 100a35d:	je     100a39f <entry_run+0x34f>
 100a35f:	cmpq   $0x0,0x20(%rbx)
 100a364:	jne    100a38f <entry_run+0x33f>
 100a366:	movl   $0x1,0x38e0(%rbx)
 100a370:	vxorps %xmm0,%xmm0,%xmm0
 100a374:	vmovups %ymm0,0x38e4(%rbx)
 100a37c:	vmovups %ymm0,0x38f0(%rbx)
 100a384:	movq   $0x1003163,0x3910(%rbx)
 100a38f:	mov    $0x1003582,%esi
 100a394:	mov    %rbx,%rdi
 100a397:	vzeroupper
 100a39a:	call   100bd40 <fail>
 100a39f:	movq   $0x0,-0x30(%rbp)
 100a3a7:	cmpq   $0x0,0x1860(%rbx)
 100a3af:	je     100b4ee <entry_run+0x149e>
 100a3b5:	lea    0x258(%rbx),%rdi
 100a3bc:	mov    0x2c8(%rbx),%ecx
 100a3c2:	mov    $0x1001a48,%esi
 100a3c7:	xor    %edx,%edx
 100a3c9:	vzeroupper
 100a3cc:	call   100f8c0 <rc_list_new>
 100a3d1:	test   %rax,%rax
 100a3d4:	je     100b4ee <entry_run+0x149e>
 100a3da:	movabs $0x5000000000000001,%r14
 100a3e4:	mov    %rax,-0x38(%rbp)
 100a3e8:	movq   $0x1001ab8,-0xe8(%rbp)
 100a3f3:	movl   $0x2,-0xd0(%rbp)
 100a3fd:	mov    %rax,-0x78(%rbp)
 100a401:	movq   $0x1001ab8,-0x108(%rbp)
 100a40c:	movl   $0x2,-0xf0(%rbp)
 100a416:	movl   $0x0,-0x50(%rbp)
 100a41d:	movl   $0x1,-0x58(%rbp)
 100a424:	mov    %rax,-0x30(%rbp)
 100a428:	test   %r14,-0x10(%rax)
 100a42c:	je     100a47e <entry_run+0x42e>
 100a42e:	lea    -0x38(%rbp),%rsi
 100a432:	lea    -0x30(%rbp),%rdx
 100a436:	lea    0x258(%rbx),%rdi
 100a43d:	mov    %r12d,%ecx
 100a440:	call   1017e30 <myl_rc_native_take>
 100a445:	test   %eax,%eax
 100a447:	jne    100a486 <entry_run+0x436>
 100a449:	mov    0x1860(%rbx),%rcx
 100a450:	test   %rcx,%rcx
 100a453:	je     100b4cf <entry_run+0x147f>
 100a459:	mov    0x78(%rcx),%eax
 100a45c:	movl   $0x0,0x78(%rcx)
 100a463:	test   %eax,%eax
 100a465:	lea    -0x98(%rbp),%r12
 100a46c:	lea    0x258(%rbx),%r15
 100a473:	jne    100a827 <entry_run+0x7d7>
 100a479:	jmp    100b3a4 <entry_run+0x1354>
 100a47e:	movq   $0x0,-0x30(%rbp)
 100a486:	movl   $0x0,-0x58(%rbp)
 100a48d:	movq   $0x1001ab8,-0xe8(%rbp)
 100a498:	movl   $0x2,-0xd0(%rbp)
 100a4a2:	movl   $0x1,-0x50(%rbp)
 100a4a9:	cmpl   $0x0,-0x70(%rbp)
 100a4ad:	je     100a4c6 <entry_run+0x476>
 100a4af:	lea    -0x168(%rbp),%rsi
 100a4b6:	mov    %rbx,%rdi
 100a4b9:	call   100b510 <myl_qbe_rc_slot_drop>
 100a4be:	mov    -0xd0(%rbp),%ecx
 100a4c4:	jmp    100a4cb <entry_run+0x47b>
 100a4c6:	mov    $0x2,%ecx
 100a4cb:	mov    -0x38(%rbp),%rax
 100a4cf:	mov    %rax,-0x178(%rbp)
 100a4d6:	movl   $0x0,-0x50(%rbp)
 100a4dd:	movq   $0x1001ab8,-0x168(%rbp)
 100a4e8:	mov    %r15,-0x160(%rbp)
 100a4ef:	mov    %r13,-0x158(%rbp)
 100a4f6:	mov    %ecx,-0x150(%rbp)
 100a4fc:	movl   $0x1,-0x70(%rbp)
 100a503:	cmp    $0x8,%ecx
 100a506:	jne    100a5de <entry_run+0x58e>
 100a50c:	movq   $0x0,-0x38(%rbp)
 100a514:	test   %rax,%rax
 100a517:	lea    0x258(%rbx),%r15
 100a51e:	lea    -0x38(%rbp),%rsi
 100a522:	je     100a570 <entry_run+0x520>
 100a524:	mov    -0x10(%rax),%rcx
 100a528:	movabs $0x4000000000000002,%rdx
 100a532:	test   %rdx,%rcx
 100a535:	jne    100a570 <entry_run+0x520>
 100a537:	cmpq   $0x0,0x1860(%rbx)
 100a53f:	je     100b4cf <entry_run+0x147f>
 100a545:	test   $0x1,%cl
 100a548:	jne    100b4cf <entry_run+0x147f>
 100a54e:	mov    -0x18(%rax),%rcx
 100a552:	mov    -0x20(%rax),%rdx
 100a556:	or     %rcx,%rdx
 100a559:	je     100b4cf <entry_run+0x147f>
 100a55f:	cmp    $0xffffffffffffffff,%rcx
 100a563:	je     100b4a9 <entry_run+0x1459>
 100a569:	inc    %rcx
 100a56c:	mov    %rcx,-0x18(%rax)
 100a570:	mov    %rax,-0x38(%rbp)
 100a574:	movq   $0x1001ab8,-0xe8(%rbp)
 100a57f:	mov    %rsi,-0xe0(%rbp)
 100a586:	lea    -0x50(%rbp),%rcx
 100a58a:	mov    %rcx,-0xd8(%rbp)
 100a591:	movl   $0x8,-0xd0(%rbp)
 100a59b:	mov    %rax,-0x78(%rbp)
 100a59f:	movq   $0x1001ab8,-0x108(%rbp)
 100a5aa:	lea    -0x78(%rbp),%rcx
 100a5ae:	mov    %rcx,-0x100(%rbp)
 100a5b5:	lea    -0x58(%rbp),%rcx
 100a5b9:	mov    %rcx,-0xf8(%rbp)
 100a5c0:	movl   $0x8,-0xf0(%rbp)
 100a5ca:	movl   $0x1,-0x58(%rbp)
 100a5d1:	movl   $0x0,-0x50(%rbp)
 100a5d8:	mov    %rax,-0x30(%rbp)
 100a5dc:	jmp    100a631 <entry_run+0x5e1>
 100a5de:	mov    -0x58(%rbp),%ecx
 100a5e1:	testb  $0x18,-0xf0(%rbp)
 100a5e8:	mov    %rax,-0x30(%rbp)
 100a5ec:	lea    0x258(%rbx),%r15
 100a5f3:	jne    100a631 <entry_run+0x5e1>
 100a5f5:	and    $0x1,%ecx
 100a5f8:	je     100a631 <entry_run+0x5e1>
 100a5fa:	test   %rax,%rax
 100a5fd:	je     100a9ef <entry_run+0x99f>
 100a603:	test   %r14,-0x10(%rax)
 100a607:	je     100a9ef <entry_run+0x99f>
 100a60d:	lea    -0x38(%rbp),%rsi
 100a611:	lea    -0x30(%rbp),%rdx
 100a615:	mov    %r15,%rdi
 100a618:	mov    %r12d,%ecx
 100a61b:	call   1017e30 <myl_rc_native_take>
 100a620:	test   %eax,%eax
 100a622:	lea    -0x68(%rbp),%r12
 100a626:	jne    100a9ff <entry_run+0x9af>
 100a62c:	jmp    100a7fe <entry_run+0x7ae>
 100a631:	lea    -0x38(%rbp),%rdx
 100a635:	lea    -0x30(%rbp),%rcx
 100a639:	mov    $0x1001ab8,%esi
 100a63e:	mov    %r15,%rdi
 100a641:	mov    %r12d,%r8d
 100a644:	call   1018250 <myl_rc_native_retain>
 100a649:	test   %eax,%eax
 100a64b:	je     100a7fe <entry_run+0x7ae>
 100a651:	movq   $0x1001ab8,-0xe8(%rbp)
 100a65c:	movl   $0x2,-0xd0(%rbp)
 100a666:	movl   $0x1,-0x50(%rbp)
 100a66d:	cmpl   $0x0,-0x58(%rbp)
 100a671:	lea    -0x68(%rbp),%r12
 100a675:	je     100a686 <entry_run+0x636>
 100a677:	mov    %rbx,%rdi
 100a67a:	lea    -0x108(%rbp),%rsi
 100a681:	call   100b510 <myl_qbe_rc_slot_drop>
 100a686:	cmpl   $0x0,-0x68(%rbp)
 100a68a:	lea    -0x40(%rbp),%r14
 100a68e:	je     100a69f <entry_run+0x64f>
 100a690:	lea    -0x148(%rbp),%rsi
 100a697:	mov    %rbx,%rdi
 100a69a:	call   100b510 <myl_qbe_rc_slot_drop>
 100a69f:	mov    -0x38(%rbp),%rax
 100a6a3:	mov    %rax,-0x40(%rbp)
 100a6a7:	movl   $0x0,-0x50(%rbp)
 100a6ae:	movq   $0x1001ab8,-0x148(%rbp)
 100a6b9:	mov    %r14,-0x140(%rbp)
 100a6c0:	mov    %r12,-0x138(%rbp)
 100a6c7:	mov    -0xd0(%rbp),%eax
 100a6cd:	mov    %eax,-0x130(%rbp)
 100a6d3:	movl   $0x1,-0x68(%rbp)
 100a6da:	cmpl   $0x0,-0x70(%rbp)
 100a6de:	je     100a6ef <entry_run+0x69f>
 100a6e0:	lea    -0x168(%rbp),%rsi
 100a6e7:	mov    %rbx,%rdi
 100a6ea:	call   100b510 <myl_qbe_rc_slot_drop>
 100a6ef:	movq   $0xf42400,-0x30(%rbp)
 100a6f7:	movq   $0x1001ab8,-0x148(%rbp)
 100a702:	movl   $0x2,-0x130(%rbp)
 100a70c:	mov    %r14,-0x140(%rbp)
 100a713:	mov    %r12,-0x138(%rbp)
 100a71a:	mov    0x1860(%rbx),%rcx
 100a721:	test   %rcx,%rcx
 100a724:	je     100b4cf <entry_run+0x147f>
 100a72a:	mov    0x40(%rcx),%rax
 100a72e:	test   %rax,%rax
 100a731:	je     100b4cf <entry_run+0x147f>
 100a737:	movabs $0xbf58476d1ce4e5b9,%r12
 100a741:	mov    0x30(%rcx),%rcx
 100a745:	mov    $0x1001ab8,%esi
 100a74a:	mov    $0x1001ab8,%edx
 100a74f:	shr    $0x3,%rdx
 100a753:	shr    $0x21,%rsi
 100a757:	xor    %rdx,%rsi
 100a75a:	imul   %r12,%rsi
 100a75e:	mov    %rsi,%rdx
 100a761:	shr    $0x1b,%rdx
 100a765:	xor    %rsi,%rdx
 100a768:	xor    $0x2,%rdx
 100a76c:	dec    %rax
 100a76f:	jmp    100a783 <entry_run+0x733>
 100a771:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a780:	inc    %rdx
 100a783:	and    %rax,%rdx
 100a786:	lea    (%rdx,%rdx,4),%rsi
 100a78a:	mov    (%rcx,%rsi,8),%rsi
 100a78e:	test   %rsi,%rsi
 100a791:	je     100b4cf <entry_run+0x147f>
 100a797:	cmp    $0x1001ab8,%rsi
 100a79e:	jne    100a780 <entry_run+0x730>
 100a7a0:	lea    (%rdx,%rdx,4),%rsi
 100a7a4:	cmpl   $0x2,0x20(%rcx,%rsi,8)
 100a7a9:	jne    100a780 <entry_run+0x730>
 100a7ab:	lea    (%rcx,%rsi,8),%rdx
 100a7af:	mov    0x8(%rdx),%rdx
 100a7b3:	test   %rdx,%rdx
 100a7b6:	je     100b4cf <entry_run+0x147f>
 100a7bc:	mov    0x8(%rdx),%rsi
 100a7c0:	cmpl   $0x1,0x8(%rsi)
 100a7c4:	jne    100b4cf <entry_run+0x147f>
 100a7ca:	movabs $0x4000000000000002,%r14
 100a7d4:	mov    -0x40(%rbp),%r13
 100a7d8:	test   %r13,%r13
 100a7db:	je     100a847 <entry_run+0x7f7>
 100a7dd:	mov    -0x10(%r13),%rdi
 100a7e1:	lea    -0x2(%r14),%r8
 100a7e5:	mov    %rdi,%r9
 100a7e8:	shr    $0x28,%r9
 100a7ec:	and    $0xfffff,%r9d
 100a7f3:	xor    %edx,%edx
 100a7f5:	test   %r8,%rdi
 100a7f8:	cmovne %r9d,%edx
 100a7fc:	jmp    100a849 <entry_run+0x7f9>
 100a7fe:	mov    0x1860(%rbx),%rcx
 100a805:	test   %rcx,%rcx
 100a808:	je     100b4cf <entry_run+0x147f>
 100a80e:	mov    0x78(%rcx),%eax
 100a811:	movl   $0x0,0x78(%rcx)
 100a818:	test   %eax,%eax
 100a81a:	lea    -0x98(%rbp),%r12
 100a821:	je     100b3a4 <entry_run+0x1354>
 100a827:	cmp    $0x1,%eax
 100a82a:	jne    100a9e1 <entry_run+0x991>
 100a830:	mov    $0x10034a2,%esi
 100a835:	cmpl   $0x0,0x2c4(%rbx)
 100a83c:	jne    100b39c <entry_run+0x134c>
 100a842:	jmp    100b38d <entry_run+0x133d>
 100a847:	xor    %edx,%edx
 100a849:	mov    %rsi,%rdi
 100a84c:	shr    $0x3,%rdi
 100a850:	mov    %rsi,%r8
 100a853:	shr    $0x21,%r8
 100a857:	xor    %rdi,%r8
 100a85a:	imul   %r12,%r8
 100a85e:	mov    %r8,%rdi
 100a861:	shr    $0x1b,%rdi
 100a865:	xor    %r8,%rdi
 100a868:	xor    $0x1,%rdi
 100a86c:	and    %rax,%rdi
 100a86f:	cmpl   $0x0,-0x68(%rbp)
 100a873:	lea    (%rdi,%rdi,4),%r8
 100a877:	mov    (%rcx,%r8,8),%r8
 100a87b:	jne    100a89e <entry_run+0x84e>
 100a87d:	jmp    100a94e <entry_run+0x8fe>
 100a882:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a890:	inc    %rdi
 100a893:	and    %rax,%rdi
 100a896:	lea    (%rdi,%rdi,4),%r8
 100a89a:	mov    (%rcx,%r8,8),%r8
 100a89e:	test   %r8,%r8
 100a8a1:	je     100b4cf <entry_run+0x147f>
 100a8a7:	cmp    %rsi,%r8
 100a8aa:	jne    100a890 <entry_run+0x840>
 100a8ac:	lea    (%rdi,%rdi,4),%r8
 100a8b0:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a8b6:	jne    100a890 <entry_run+0x840>
 100a8b8:	lea    (%rcx,%r8,8),%rax
 100a8bc:	cmpq   $0x0,0x8(%rax)
 100a8c1:	je     100b4cf <entry_run+0x147f>
 100a8c7:	cmpq   $0x8,(%rsi)
 100a8cb:	jne    100b4cf <entry_run+0x147f>
 100a8d1:	test   %r13,%r13
 100a8d4:	je     100ab27 <entry_run+0xad7>
 100a8da:	mov    -0x10(%r13),%rax
 100a8de:	movabs $0x2000000000000002,%rcx
 100a8e8:	test   %rcx,%rax
 100a8eb:	je     100aa35 <entry_run+0x9e5>
 100a8f1:	movq   $0x0,-0x190(%rbp)
 100a8fc:	lea    -0x190(%rbp),%rcx
 100a903:	mov    %r15,%rdi
 100a906:	mov    %r13,%rsi
 100a909:	call   1016cd0 <clone_payload>
 100a90e:	test   %eax,%eax
 100a910:	je     100aa66 <entry_run+0xa16>
 100a916:	cmp    $0x1,%eax
 100a919:	je     100b378 <entry_run+0x1328>
 100a91f:	cmp    $0x4,%eax
 100a922:	lea    -0x98(%rbp),%r12
 100a929:	jb     100b392 <entry_run+0x1342>
 100a92f:	jmp    100a9ea <entry_run+0x99a>
 100a934:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a940:	inc    %rdi
 100a943:	and    %rax,%rdi
 100a946:	lea    (%rdi,%rdi,4),%r8
 100a94a:	mov    (%rcx,%r8,8),%r8
 100a94e:	test   %r8,%r8
 100a951:	je     100b4cf <entry_run+0x147f>
 100a957:	cmp    %rsi,%r8
 100a95a:	jne    100a940 <entry_run+0x8f0>
 100a95c:	lea    (%rdi,%rdi,4),%r8
 100a960:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a966:	jne    100a940 <entry_run+0x8f0>
 100a968:	lea    (%rcx,%r8,8),%rax
 100a96c:	cmpq   $0x0,0x8(%rax)
 100a971:	je     100b4cf <entry_run+0x147f>
 100a977:	cmpq   $0x8,(%rsi)
 100a97b:	jne    100b4cf <entry_run+0x147f>
 100a981:	test   %r13,%r13
 100a984:	je     100ab27 <entry_run+0xad7>
 100a98a:	mov    -0x10(%r13),%rax
 100a98e:	movabs $0x2000000000000002,%rcx
 100a998:	test   %rcx,%rax
 100a99b:	je     100aae6 <entry_run+0xa96>
 100a9a1:	movq   $0x0,-0x190(%rbp)
 100a9ac:	lea    -0x190(%rbp),%rcx
 100a9b3:	mov    %r15,%rdi
 100a9b6:	mov    %r13,%rsi
 100a9b9:	call   1016cd0 <clone_payload>
 100a9be:	xor    %ecx,%ecx
 100a9c0:	test   %eax,%eax
 100a9c2:	jne    100a9cb <entry_run+0x97b>
 100a9c4:	mov    -0x190(%rbp),%rcx
 100a9cb:	jne    100ab16 <entry_run+0xac6>
 100a9d1:	mov    %rcx,-0x40(%rbp)
 100a9d5:	movl   $0x1,-0x68(%rbp)
 100a9dc:	jmp    100ab27 <entry_run+0xad7>
 100a9e1:	cmp    $0x4,%eax
 100a9e4:	jb     100b392 <entry_run+0x1342>
 100a9ea:	call   101bd50 <abort@plt>
 100a9ef:	mov    %rax,-0x38(%rbp)
 100a9f3:	movq   $0x0,-0x30(%rbp)
 100a9fb:	lea    -0x68(%rbp),%r12
 100a9ff:	movl   $0x0,-0x58(%rbp)
 100aa06:	movq   $0x1001ab8,-0xe8(%rbp)
 100aa11:	movl   $0x2,-0xd0(%rbp)
 100aa1b:	movl   $0x1,-0x50(%rbp)
 100aa22:	cmpl   $0x0,-0x68(%rbp)
 100aa26:	lea    -0x40(%rbp),%r14
 100aa2a:	jne    100a690 <entry_run+0x640>
 100aa30:	jmp    100a69f <entry_run+0x64f>
 100aa35:	lea    -0x2(%r14),%rcx
 100aa39:	test   %rcx,%rax
 100aa3c:	jne    100ab27 <entry_run+0xad7>
 100aa42:	test   $0x1,%al
 100aa44:	jne    100b4cf <entry_run+0x147f>
 100aa4a:	mov    -0x20(%r13),%rax
 100aa4e:	cmp    $0x1,%rax
 100aa52:	je     100ab27 <entry_run+0xad7>
 100aa58:	test   %rax,%rax
 100aa5b:	je     100ab0a <entry_run+0xaba>
 100aa61:	jmp    100a8f1 <entry_run+0x8a1>
 100aa66:	mov    -0x190(%rbp),%rax
 100aa6d:	mov    %rax,-0x40(%rbp)
 100aa71:	mov    -0x10(%r13),%rax
 100aa75:	test   %r14,%rax
 100aa78:	jne    100aac5 <entry_run+0xa75>
 100aa7a:	mov    0x1860(%rbx),%rcx
 100aa81:	test   %rcx,%rcx
 100aa84:	je     100b4cf <entry_run+0x147f>
 100aa8a:	test   $0x1,%al
 100aa8c:	jne    100b4cf <entry_run+0x147f>
 100aa92:	lea    -0x20(%r13),%rdx
 100aa96:	mov    (%rdx),%rsi
 100aa99:	test   %rsi,%rsi
 100aa9c:	je     100b4cf <entry_run+0x147f>
 100aaa2:	dec    %rsi
 100aaa5:	mov    %rsi,(%rdx)
 100aaa8:	jne    100aac5 <entry_run+0xa75>
 100aaaa:	cmpq   $0x0,-0x18(%r13)
 100aaaf:	jne    100aac5 <entry_run+0xa75>
 100aab1:	or     $0x1,%rax
 100aab5:	mov    %rax,-0x10(%r13)
 100aab9:	mov    0x60(%rcx),%rax
 100aabd:	mov    %rax,-0x20(%r13)
 100aac1:	mov    %rdx,0x60(%rcx)
 100aac5:	mov    %r15,%rdi
 100aac8:	call   1012d20 <myl_rc_drain>
 100aacd:	jmp    100ab27 <entry_run+0xad7>
 100aacf:	movl   $0x1,0x38(%rax)
 100aad6:	cmpq   $0x0,0x20(%rbx)
 100aadb:	jne    100b445 <entry_run+0x13f5>
 100aae1:	jmp    100a191 <entry_run+0x141>
 100aae6:	lea    -0x2(%r14),%rcx
 100aaea:	test   %rcx,%rax
 100aaed:	jne    100ab27 <entry_run+0xad7>
 100aaef:	test   $0x1,%al
 100aaf1:	jne    100b4cf <entry_run+0x147f>
 100aaf7:	mov    -0x20(%r13),%rax
 100aafb:	cmp    $0x1,%rax
 100aaff:	je     100ab27 <entry_run+0xad7>
 100ab01:	test   %rax,%rax
 100ab04:	jne    100a9a1 <entry_run+0x951>
 100ab0a:	cmpq   $0x0,-0x18(%r13)
 100ab0f:	jne    100ab27 <entry_run+0xad7>
 100ab11:	jmp    100b4cf <entry_run+0x147f>
 100ab16:	cmp    $0x1,%eax
 100ab19:	je     100b378 <entry_run+0x1328>
 100ab1f:	test   %eax,%eax
 100ab21:	jne    100b4ba <entry_run+0x146a>
 100ab27:	lea    -0x30(%rbp),%r13
 100ab2b:	xor    %edx,%edx
 100ab2d:	xor    %r14d,%r14d
 100ab30:	jmp    100ab79 <entry_run+0xb29>
 100ab32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100ab40:	mov    (%rsi),%rdx
 100ab43:	mov    %r15,%rdi
 100ab46:	mov    %r13,%rcx
 100ab49:	call   100ff90 <rc_list_insert_at>
 100ab4e:	xor    %edx,%edx
 100ab50:	test   %eax,%eax
 100ab52:	je     100b4d7 <entry_run+0x1487>
 100ab58:	xor    %eax,%eax
 100ab5a:	cmp    $0xf423ff,%r14
 100ab61:	lea    0x1(%r14),%r14
 100ab65:	setb   %al
 100ab68:	mov    %rax,-0x30(%rbp)
 100ab6c:	cmp    $0xf42400,%r14
 100ab73:	je     100acfb <entry_run+0xcab>
 100ab79:	mov    %r14,-0x30(%rbp)
 100ab7d:	mov    -0x40(%rbp),%rsi
 100ab81:	mov    (%rsi),%rcx
 100ab84:	mov    0x10(%rsi),%rax
 100ab88:	cmp    0x8(%rsi),%rcx
 100ab8c:	setae  %dil
 100ab90:	cmp    $0xffffffffffffffff,%rax
 100ab94:	sete   %r8b
 100ab98:	or     %dil,%r8b
 100ab9b:	jne    100ab40 <entry_run+0xaf0>
 100ab9d:	mov    $0x1,%edi
 100aba2:	test   %edx,%edx
 100aba4:	je     100abbf <entry_run+0xb6f>
 100aba6:	mov    0x20(%rsi),%rdx
 100abaa:	mov    %r14,(%rdx,%rcx,8)
 100abae:	inc    %rcx
 100abb1:	mov    %rcx,(%rsi)
 100abb4:	inc    %rax
 100abb7:	mov    %rax,0x10(%rsi)
 100abbb:	mov    %edi,%edx
 100abbd:	jmp    100ab58 <entry_run+0xb08>
 100abbf:	mov    0x1860(%rbx),%rdi
 100abc6:	test   %rdi,%rdi
 100abc9:	je     100ab40 <entry_run+0xaf0>
 100abcf:	cmpq   $0x0,0x60(%rdi)
 100abd4:	jne    100ab40 <entry_run+0xaf0>
 100abda:	mov    0x18(%rsi),%rdx
 100abde:	test   %rdx,%rdx
 100abe1:	je     100ab40 <entry_run+0xaf0>
 100abe7:	mov    0x30(%rdx),%r8d
 100abeb:	cmp    $0x7,%r8d
 100abef:	je     100abfa <entry_run+0xbaa>
 100abf1:	test   %r8d,%r8d
 100abf4:	jne    100ab40 <entry_run+0xaf0>
 100abfa:	mov    (%rdx),%r8
 100abfd:	popcnt %r8,%r9
 100ac02:	cmp    $0x1,%r9d
 100ac06:	setne  %r9b
 100ac0a:	test   $0xf,%r8b
 100ac0e:	sete   %r8b
 100ac12:	or     %r9b,%r8b
 100ac15:	jne    100ab40 <entry_run+0xaf0>
 100ac1b:	mov    0x40(%rdi),%r8
 100ac1f:	test   %r8,%r8
 100ac22:	je     100ab40 <entry_run+0xaf0>
 100ac28:	mov    0x30(%rdi),%rdi
 100ac2c:	mov    0x24(%rdi),%r9d
 100ac30:	test   %r9,%r9
 100ac33:	sete   %r10b
 100ac37:	cmp    %r9,%r8
 100ac3a:	setb   %r11b
 100ac3e:	or     %r10b,%r11b
 100ac41:	jne    100ac5b <entry_run+0xc0b>
 100ac43:	dec    %r9d
 100ac46:	lea    (%r9,%r9,4),%r10
 100ac4a:	cmp    %rdx,(%rdi,%r10,8)
 100ac4e:	jne    100ac5b <entry_run+0xc0b>
 100ac50:	lea    (%rdi,%r10,8),%r10
 100ac54:	cmpl   $0x2,0x20(%r10)
 100ac59:	je     100acd2 <entry_run+0xc82>
 100ac5b:	mov    %rdx,%r9
 100ac5e:	shr    $0x3,%r9
 100ac62:	mov    %rdx,%r10
 100ac65:	shr    $0x21,%r10
 100ac69:	xor    %r9,%r10
 100ac6c:	imul   %r12,%r10
 100ac70:	mov    %r10,%r9
 100ac73:	shr    $0x1b,%r9
 100ac77:	xor    %r10,%r9
 100ac7a:	xor    $0x2,%r9
 100ac7e:	dec    %r8
 100ac81:	jmp    100ac93 <entry_run+0xc43>
 100ac83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100ac90:	inc    %r9
 100ac93:	and    %r8,%r9
 100ac96:	lea    (%r9,%r9,4),%r10
 100ac9a:	mov    (%rdi,%r10,8),%r10
 100ac9e:	test   %r10,%r10
 100aca1:	je     100ab40 <entry_run+0xaf0>
 100aca7:	cmp    %rdx,%r10
 100acaa:	jne    100ac90 <entry_run+0xc40>
 100acac:	lea    (%r9,%r9,4),%r10
 100acb0:	cmpl   $0x2,0x20(%rdi,%r10,8)
 100acb6:	jne    100ac90 <entry_run+0xc40>
 100acb8:	lea    0x1(%r9),%edx
 100acbc:	mov    $0xffffffff,%r8d
 100acc2:	cmp    %r8,%r9
 100acc5:	mov    $0x0,%r8d
 100accb:	cmovae %r8d,%edx
 100accf:	mov    %edx,0x24(%rdi)
 100acd2:	lea    (%r9,%r9,4),%rdx
 100acd6:	mov    0x8(%rdi,%rdx,8),%rdx
 100acdb:	test   %rdx,%rdx
 100acde:	je     100ab40 <entry_run+0xaf0>
 100ace4:	xor    %edi,%edi
 100ace6:	cmpl   $0x0,0x78(%rdx)
 100acea:	sete   %dl
 100aced:	jne    100ab40 <entry_run+0xaf0>
 100acf3:	mov    %dl,%dil
 100acf6:	jmp    100aba6 <entry_run+0xb56>
 100acfb:	movq   $0x0,-0x30(%rbp)
 100ad03:	mov    -0x40(%rbp),%rax
 100ad07:	cmpl   $0x8,-0x130(%rbp)
 100ad0e:	jne    100adfb <entry_run+0xdab>
 100ad14:	mov    -0x68(%rbp),%ecx
 100ad17:	and    $0x1,%ecx
 100ad1a:	je     100adfb <entry_run+0xdab>
 100ad20:	movq   $0x0,-0x38(%rbp)
 100ad28:	test   %rax,%rax
 100ad2b:	lea    -0x98(%rbp),%r12
 100ad32:	lea    -0x38(%rbp),%r14
 100ad36:	je     100ad84 <entry_run+0xd34>
 100ad38:	mov    -0x10(%rax),%rcx
 100ad3c:	movabs $0x4000000000000002,%rdx
 100ad46:	test   %rdx,%rcx
 100ad49:	jne    100ad84 <entry_run+0xd34>
 100ad4b:	cmpq   $0x0,0x1860(%rbx)
 100ad53:	je     100b4cf <entry_run+0x147f>
 100ad59:	test   $0x1,%cl
 100ad5c:	jne    100b4cf <entry_run+0x147f>
 100ad62:	mov    -0x18(%rax),%rcx
 100ad66:	mov    -0x20(%rax),%rdx
 100ad6a:	or     %rcx,%rdx
 100ad6d:	je     100b4cf <entry_run+0x147f>
 100ad73:	cmp    $0xffffffffffffffff,%rcx
 100ad77:	je     100b459 <entry_run+0x1409>
 100ad7d:	inc    %rcx
 100ad80:	mov    %rcx,-0x18(%rax)
 100ad84:	movq   $0x1001ab8,-0xe8(%rbp)
 100ad8f:	mov    %r14,-0xe0(%rbp)
 100ad96:	lea    -0x50(%rbp),%rcx
 100ad9a:	mov    %rcx,-0xd8(%rbp)
 100ada1:	movl   $0x8,-0xd0(%rbp)
 100adab:	mov    %rax,-0x78(%rbp)
 100adaf:	movq   $0x1001ab8,-0x108(%rbp)
 100adba:	lea    -0x78(%rbp),%rcx
 100adbe:	mov    %rcx,-0x100(%rbp)
 100adc5:	lea    -0x58(%rbp),%rcx
 100adc9:	mov    %rcx,-0xf8(%rbp)
 100add0:	movl   $0x8,-0xf0(%rbp)
 100adda:	movl   $0x1,-0x58(%rbp)
 100ade1:	movl   $0x0,-0x50(%rbp)
 100ade8:	mov    %rax,-0x30(%rbp)
 100adec:	movq   $0x0,-0x38(%rbp)
 100adf4:	test   %rax,%rax
 100adf7:	jne    100ae17 <entry_run+0xdc7>
 100adf9:	jmp    100ae63 <entry_run+0xe13>
 100adfb:	lea    -0x98(%rbp),%r12
 100ae02:	lea    -0x38(%rbp),%r14
 100ae06:	mov    %rax,-0x30(%rbp)
 100ae0a:	movq   $0x0,-0x38(%rbp)
 100ae12:	test   %rax,%rax
 100ae15:	je     100ae63 <entry_run+0xe13>
 100ae17:	mov    -0x10(%rax),%rcx
 100ae1b:	movabs $0x4000000000000002,%rdx
 100ae25:	test   %rdx,%rcx
 100ae28:	jne    100ae63 <entry_run+0xe13>
 100ae2a:	cmpq   $0x0,0x1860(%rbx)
 100ae32:	je     100b4cf <entry_run+0x147f>
 100ae38:	test   $0x1,%cl
 100ae3b:	jne    100b4cf <entry_run+0x147f>
 100ae41:	mov    -0x18(%rax),%rcx
 100ae45:	mov    -0x20(%rax),%rdx
 100ae49:	or     %rcx,%rdx
 100ae4c:	je     100b4cf <entry_run+0x147f>
 100ae52:	cmp    $0xffffffffffffffff,%rcx
 100ae56:	je     100b459 <entry_run+0x1409>
 100ae5c:	inc    %rcx
 100ae5f:	mov    %rcx,-0x18(%rax)
 100ae63:	mov    %rax,-0x38(%rbp)
 100ae67:	movq   $0x1001ab8,-0xe8(%rbp)
 100ae72:	mov    %r14,-0xe0(%rbp)
 100ae79:	lea    -0x50(%rbp),%rcx
 100ae7d:	mov    %rcx,-0xd8(%rbp)
 100ae84:	movl   $0x8,-0xd0(%rbp)
 100ae8e:	movl   $0x1,-0x50(%rbp)
 100ae95:	cmpl   $0x0,-0x58(%rbp)
 100ae99:	je     100aeae <entry_run+0xe5e>
 100ae9b:	mov    %rbx,%rdi
 100ae9e:	lea    -0x108(%rbp),%rsi
 100aea5:	call   100b510 <myl_qbe_rc_slot_drop>
 100aeaa:	mov    -0x38(%rbp),%rax
 100aeae:	mov    %rax,-0x78(%rbp)
 100aeb2:	movq   $0x1001ab8,-0x108(%rbp)
 100aebd:	lea    -0x78(%rbp),%rcx
 100aec1:	mov    %rcx,-0x100(%rbp)
 100aec8:	lea    -0x58(%rbp),%rcx
 100aecc:	mov    %rcx,-0xf8(%rbp)
 100aed3:	movl   $0x8,-0xf0(%rbp)
 100aedd:	mov    %rax,-0x30(%rbp)
 100aee1:	movq   $0x1001ab8,-0xe8(%rbp)
 100aeec:	mov    %r14,-0xe0(%rbp)
 100aef3:	lea    -0x50(%rbp),%rcx
 100aef7:	mov    %rcx,-0xd8(%rbp)
 100aefe:	movl   $0x8,-0xd0(%rbp)
 100af08:	movl   $0x1,-0x50(%rbp)
 100af0f:	movl   $0x0,-0x58(%rbp)
 100af16:	cmpl   $0x0,-0x60(%rbp)
 100af1a:	je     100af2f <entry_run+0xedf>
 100af1c:	mov    %rbx,%rdi
 100af1f:	lea    -0x128(%rbp),%rsi
 100af26:	call   100b510 <myl_qbe_rc_slot_drop>
 100af2b:	mov    -0x38(%rbp),%rax
 100af2f:	mov    %rax,-0xa8(%rbp)
 100af36:	movq   $0x1001ab8,-0x128(%rbp)
 100af41:	lea    -0xa8(%rbp),%rcx
 100af48:	mov    %rcx,-0x120(%rbp)
 100af4f:	lea    -0x60(%rbp),%rcx
 100af53:	mov    %rcx,-0x118(%rbp)
 100af5a:	movl   $0x8,-0x110(%rbp)
 100af64:	movl   $0x1,-0x60(%rbp)
 100af6b:	movl   $0x0,-0x50(%rbp)
 100af72:	mov    (%rax),%rsi
 100af75:	mov    %rsi,-0x30(%rbp)
 100af79:	test   %rsi,%rsi
 100af7c:	js     100b4f9 <entry_run+0x14a9>
 100af82:	je     100afaa <entry_run+0xf5a>
 100af84:	mov    0x20(%rax),%rcx
 100af88:	xor    %eax,%eax
 100af8a:	xor    %edi,%edi
 100af8c:	xor    %r14d,%r14d
 100af8f:	nop
 100af90:	mov    (%rcx,%rdi,8),%rdx
 100af94:	add    %rdx,%r14
 100af97:	jo     100b4df <entry_run+0x148f>
 100af9d:	inc    %rdi
 100afa0:	mov    %r14,%rax
 100afa3:	cmp    %rdi,%rsi
 100afa6:	jne    100af90 <entry_run+0xf40>
 100afa8:	jmp    100afad <entry_run+0xf5d>
 100afaa:	xor    %r14d,%r14d
 100afad:	movq   $0x1,-0x30(%rbp)
 100afb5:	mov    $0x1,%edi
 100afba:	mov    $0x20,%esi
 100afbf:	call   101bc20 <calloc@plt>
 100afc4:	mov    %rax,-0xa0(%rbp)
 100afcb:	test   %rax,%rax
 100afce:	jne    100afd8 <entry_run+0xf88>
 100afd0:	mov    %rbx,%rdi
 100afd3:	call   100c3f0 <myl_qbe_fail_allocation>
 100afd8:	lea    -0x190(%rbp),%rdi
 100afdf:	mov    $0x18,%esi
 100afe4:	mov    $0x1003272,%edx
 100afe9:	mov    %r14,%rcx
 100afec:	xor    %eax,%eax
 100afee:	call   101bd60 <snprintf@plt>
 100aff3:	test   %eax,%eax
 100aff5:	jle    100b1ff <entry_run+0x11af>
 100affb:	mov    %eax,%r13d
 100affe:	mov    $0x40,%edi
 100b003:	cmp    $0x41,%eax
 100b006:	jb     100b1a1 <entry_run+0x1151>
 100b00c:	mov    $0x80,%edi
 100b011:	cmp    $0x81,%r13d
 100b018:	jb     100b1a1 <entry_run+0x1151>
 100b01e:	mov    $0x100,%edi
 100b023:	cmp    $0x101,%r13d
 100b02a:	jb     100b1a1 <entry_run+0x1151>
 100b030:	mov    $0x200,%edi
 100b035:	cmp    $0x201,%r13d
 100b03c:	jb     100b1a1 <entry_run+0x1151>
 100b042:	mov    $0x400,%edi
 100b047:	cmp    $0x401,%r13d
 100b04e:	jb     100b1a1 <entry_run+0x1151>
 100b054:	mov    $0x800,%edi
 100b059:	cmp    $0x801,%r13d
 100b060:	jb     100b1a1 <entry_run+0x1151>
 100b066:	mov    $0x1000,%edi
 100b06b:	cmp    $0x1001,%r13d
 100b072:	jb     100b1a1 <entry_run+0x1151>
 100b078:	mov    $0x2000,%edi
 100b07d:	cmp    $0x2001,%r13d
 100b084:	jb     100b1a1 <entry_run+0x1151>
 100b08a:	mov    $0x4000,%edi
 100b08f:	cmp    $0x4001,%r13d
 100b096:	jb     100b1a1 <entry_run+0x1151>
 100b09c:	mov    $0x8000,%edi
 100b0a1:	cmp    $0x8001,%r13d
 100b0a8:	jb     100b1a1 <entry_run+0x1151>
 100b0ae:	mov    $0x10000,%edi
 100b0b3:	cmp    $0x10001,%r13d
 100b0ba:	jb     100b1a1 <entry_run+0x1151>
 100b0c0:	mov    $0x20000,%edi
 100b0c5:	cmp    $0x20001,%r13d
 100b0cc:	jb     100b1a1 <entry_run+0x1151>
 100b0d2:	mov    $0x40000,%edi
 100b0d7:	cmp    $0x40001,%r13d
 100b0de:	jb     100b1a1 <entry_run+0x1151>
 100b0e4:	mov    $0x80000,%edi
 100b0e9:	cmp    $0x80001,%r13d
 100b0f0:	jb     100b1a1 <entry_run+0x1151>
 100b0f6:	mov    $0x100000,%edi
 100b0fb:	cmp    $0x100001,%r13d
 100b102:	jb     100b1a1 <entry_run+0x1151>
 100b108:	mov    $0x200000,%edi
 100b10d:	cmp    $0x200001,%r13d
 100b114:	jb     100b1a1 <entry_run+0x1151>
 100b11a:	mov    $0x400000,%edi
 100b11f:	cmp    $0x400001,%r13d
 100b126:	jb     100b1a1 <entry_run+0x1151>
 100b128:	mov    $0x800000,%edi
 100b12d:	cmp    $0x800001,%r13d
 100b134:	jb     100b1a1 <entry_run+0x1151>
 100b136:	mov    $0x1000000,%edi
 100b13b:	cmp    $0x1000001,%r13d
 100b142:	jb     100b1a1 <entry_run+0x1151>
 100b144:	mov    $0x2000000,%edi
 100b149:	cmp    $0x2000001,%r13d
 100b150:	jb     100b1a1 <entry_run+0x1151>
 100b152:	mov    $0x4000000,%edi
 100b157:	cmp    $0x4000001,%r13d
 100b15e:	jb     100b1a1 <entry_run+0x1151>
 100b160:	mov    $0x8000000,%edi
 100b165:	cmp    $0x8000001,%r13d
 100b16c:	jb     100b1a1 <entry_run+0x1151>
 100b16e:	mov    $0x10000000,%edi
 100b173:	cmp    $0x10000001,%r13d
 100b17a:	jb     100b1a1 <entry_run+0x1151>
 100b17c:	mov    $0x20000000,%edi
 100b181:	cmp    $0x20000001,%r13d
 100b188:	jb     100b1a1 <entry_run+0x1151>
 100b18a:	xor    %edi,%edi
 100b18c:	cmp    $0x40000001,%r13d
 100b193:	setae  %dil
 100b197:	shl    $0x1e,%edi
 100b19a:	add    $0x40000000,%rdi
 100b1a1:	mov    %rdi,%r12
 100b1a4:	call   101bc10 <malloc@plt>
 100b1a9:	test   %rax,%rax
 100b1ac:	je     100b276 <entry_run+0x1226>
 100b1b2:	mov    %rax,%r14
 100b1b5:	mov    %r13d,%r13d
 100b1b8:	mov    -0xa0(%rbp),%r15
 100b1bf:	mov    %rax,(%r15)
 100b1c2:	mov    %r12,0x10(%r15)
 100b1c6:	lea    -0x190(%rbp),%rsi
 100b1cd:	mov    %rax,%rdi
 100b1d0:	mov    %r13,%rdx
 100b1d3:	call   101bc30 <memcpy@plt>
 100b1d8:	lea    0x8(%r15),%rax
 100b1dc:	mov    %r13,0x8(%r15)
 100b1e0:	add    $0x18,%r15
 100b1e4:	cmp    %r13,%r12
 100b1e7:	jne    100b24a <entry_run+0x11fa>
 100b1e9:	mov    %r12,%rsi
 100b1ec:	mov    %rax,-0x170(%rbp)
 100b1f3:	add    %r12,%rsi
 100b1f6:	mov    -0xa0(%rbp),%r13
 100b1fd:	jmp    100b220 <entry_run+0x11d0>
 100b1ff:	mov    -0xa0(%rbp),%r13
 100b206:	lea    0x18(%r13),%r15
 100b20a:	mov    %r13,%rax
 100b20d:	add    $0x8,%rax
 100b211:	mov    %rax,-0x170(%rbp)
 100b218:	mov    $0x40,%esi
 100b21d:	xor    %r14d,%r14d
 100b220:	mov    %r14,%rdi
 100b223:	mov    %rsi,%r12
 100b226:	call   101bd70 <realloc@plt>
 100b22b:	test   %rax,%rax
 100b22e:	je     100b35a <entry_run+0x130a>
 100b234:	mov    %rax,%r14
 100b237:	mov    %rax,0x0(%r13)
 100b23b:	mov    %r12,0x10(%r13)
 100b23f:	mov    0x8(%r13),%r13
 100b243:	mov    -0x170(%rbp),%rax
 100b24a:	movb   $0xa,(%r14,%r13,1)
 100b24f:	incq   (%rax)
 100b252:	mov    -0xa0(%rbp),%r13
 100b259:	cmpl   $0x0,0x1c(%r13)
 100b25e:	lea    -0x98(%rbp),%r12
 100b265:	je     100b29a <entry_run+0x124a>
 100b267:	mov    $0x1002f32,%esi
 100b26c:	mov    %rbx,%rdi
 100b26f:	call   100bd40 <fail>
 100b274:	jmp    100b2ac <entry_run+0x125c>
 100b276:	mov    -0xa0(%rbp),%r13
 100b27d:	mov    %r13,%r15
 100b280:	add    $0x18,%r15
 100b284:	movl   $0x1,0x18(%r13)
 100b28c:	cmpl   $0x0,0x1c(%r13)
 100b291:	lea    -0x98(%rbp),%r12
 100b298:	jne    100b267 <entry_run+0x1217>
 100b29a:	cmpl   $0x0,(%r15)
 100b29e:	je     100b463 <entry_run+0x1413>
 100b2a4:	mov    %rbx,%rdi
 100b2a7:	call   100c3f0 <myl_qbe_fail_allocation>
 100b2ac:	mov    0x0(%r13),%rdi
 100b2b0:	call   101bc80 <free@plt>
 100b2b5:	mov    %r13,%rdi
 100b2b8:	call   101bc80 <free@plt>
 100b2bd:	movq   $0x0,-0x30(%rbp)
 100b2c5:	cmp    %r12,0x3d80(%rbx)
 100b2cc:	lea    0x258(%rbx),%rdi
 100b2d3:	jne    100b4cf <entry_run+0x147f>
 100b2d9:	mov    -0x80(%rbp),%rsi
 100b2dd:	call   1014cf0 <myl_rc_scope_unwind>
 100b2e2:	mov    -0x88(%rbp),%r14
 100b2e9:	test   %r14,%r14
 100b2ec:	je     100b32c <entry_run+0x12dc>
 100b2ee:	mov    %r14,%r15
 100b2f1:	shl    $0x5,%r15
 100b2f5:	add    $0xffffffffffffffe0,%r15
 100b2f9:	jmp    100b314 <entry_run+0x12c4>
 100b2fb:	nopl   0x0(%rax,%rax,1)
 100b300:	add    %r15,%rsi
 100b303:	mov    %rbx,%rdi
 100b306:	call   100b510 <myl_qbe_rc_slot_drop>
 100b30b:	add    $0xffffffffffffffe0,%r15
 100b30f:	dec    %r14
 100b312:	je     100b32c <entry_run+0x12dc>
 100b314:	mov    -0x90(%rbp),%rsi
 100b31b:	mov    0x10(%rsi,%r15,1),%rax
 100b320:	test   %rax,%rax
 100b323:	je     100b300 <entry_run+0x12b0>
 100b325:	cmpl   $0x0,(%rax)
 100b328:	jne    100b300 <entry_run+0x12b0>
 100b32a:	jmp    100b30b <entry_run+0x12bb>
 100b32c:	cmp    %r12,0x3d80(%rbx)
 100b333:	jne    100b4cf <entry_run+0x147f>
 100b339:	mov    0x1860(%rbx),%rax
 100b340:	test   %rax,%rax
 100b343:	jne    100b429 <entry_run+0x13d9>
 100b349:	xor    %eax,%eax
 100b34b:	cmp    -0x80(%rbp),%rax
 100b34f:	je     100b437 <entry_run+0x13e7>
 100b355:	jmp    100b4cf <entry_run+0x147f>
 100b35a:	movl   $0x1,(%r15)
 100b361:	cmpl   $0x0,0x1c(%r13)
 100b366:	lea    -0x98(%rbp),%r12
 100b36d:	jne    100b267 <entry_run+0x1217>
 100b373:	jmp    100b29a <entry_run+0x124a>
 100b378:	mov    $0x10034a2,%esi
 100b37d:	cmpl   $0x0,0x2c4(%rbx)
 100b384:	lea    -0x98(%rbp),%r12
 100b38b:	jne    100b39c <entry_run+0x134c>
 100b38d:	mov    $0x1,%eax
 100b392:	mov    %eax,%eax
 100b394:	mov    0x1004940(,%rax,8),%rsi
 100b39c:	mov    %rbx,%rdi
 100b39f:	call   100bd40 <fail>
 100b3a4:	cmp    %r12,0x3d80(%rbx)
 100b3ab:	jne    100b4cf <entry_run+0x147f>
 100b3b1:	mov    -0x80(%rbp),%rsi
 100b3b5:	mov    %r15,%rdi
 100b3b8:	call   1014cf0 <myl_rc_scope_unwind>
 100b3bd:	mov    -0x88(%rbp),%r14
 100b3c4:	test   %r14,%r14
 100b3c7:	je     100b40c <entry_run+0x13bc>
 100b3c9:	mov    %r14,%r15
 100b3cc:	shl    $0x5,%r15
 100b3d0:	add    $0xffffffffffffffe0,%r15
 100b3d4:	jmp    100b3f4 <entry_run+0x13a4>
 100b3d6:	cs nopw 0x0(%rax,%rax,1)
 100b3e0:	add    %r15,%rsi
 100b3e3:	mov    %rbx,%rdi
 100b3e6:	call   100b510 <myl_qbe_rc_slot_drop>
 100b3eb:	add    $0xffffffffffffffe0,%r15
 100b3ef:	dec    %r14
 100b3f2:	je     100b40c <entry_run+0x13bc>
 100b3f4:	mov    -0x90(%rbp),%rsi
 100b3fb:	mov    0x10(%rsi,%r15,1),%rax
 100b400:	test   %rax,%rax
 100b403:	je     100b3e0 <entry_run+0x1390>
 100b405:	cmpl   $0x0,(%rax)
 100b408:	jne    100b3e0 <entry_run+0x1390>
 100b40a:	jmp    100b3eb <entry_run+0x139b>
 100b40c:	cmp    %r12,0x3d80(%rbx)
 100b413:	jne    100b4cf <entry_run+0x147f>
 100b419:	mov    0x1860(%rbx),%rax
 100b420:	test   %rax,%rax
 100b423:	je     100b349 <entry_run+0x12f9>
 100b429:	mov    0x70(%rax),%rax
 100b42d:	cmp    -0x80(%rbp),%rax
 100b431:	jne    100b4cf <entry_run+0x147f>
 100b437:	mov    -0x98(%rbp),%rax
 100b43e:	mov    %rax,0x3d80(%rbx)
 100b445:	xor    %eax,%eax
 100b447:	add    $0x178,%rsp
 100b44e:	pop    %rbx
 100b44f:	pop    %r12
 100b451:	pop    %r13
 100b453:	pop    %r14
 100b455:	pop    %r15
 100b457:	pop    %rbp
 100b458:	ret
 100b459:	mov    $0x100346f,%esi
 100b45e:	jmp    100b39c <entry_run+0x134c>
 100b463:	mov    0x11e16(%rip),%rax        # 101d280 <stdout@GLIBC_2.2.5>
 100b46a:	mov    (%rax),%r14
 100b46d:	mov    0x8(%r13),%r15
 100b471:	test   %r15,%r15
 100b474:	je     100b48f <entry_run+0x143f>
 100b476:	mov    0x0(%r13),%rdi
 100b47a:	mov    $0x1,%esi
 100b47f:	mov    %r15,%rdx
 100b482:	mov    %r14,%rcx
 100b485:	call   101bce0 <fwrite@plt>
 100b48a:	cmp    %r15,%rax
 100b48d:	jne    100b49f <entry_run+0x144f>
 100b48f:	mov    %r14,%rdi
 100b492:	call   101bd80 <fflush@plt>
 100b497:	test   %eax,%eax
 100b499:	je     100b2ac <entry_run+0x125c>
 100b49f:	mov    $0x1003432,%esi
 100b4a4:	jmp    100b26c <entry_run+0x121c>
 100b4a9:	mov    $0x100346f,%esi
 100b4ae:	lea    -0x98(%rbp),%r12
 100b4b5:	jmp    100b39c <entry_run+0x134c>
 100b4ba:	cmp    $0x4,%eax
 100b4bd:	jae    100a9ea <entry_run+0x99a>
 100b4c3:	lea    -0x98(%rbp),%r12
 100b4ca:	jmp    100b392 <entry_run+0x1342>
 100b4cf:	vzeroupper
 100b4d2:	call   1010844 <myl_rc_invariant_failed>
 100b4d7:	mov    %rbx,%rdi
 100b4da:	call   100c3f0 <myl_qbe_fail_allocation>
 100b4df:	mov    %rax,-0x30(%rbp)
 100b4e3:	mov    %rbx,%rdi
 100b4e6:	mov    %rax,%rsi
 100b4e9:	call   100c480 <myl_qbe_fail_overflow_op>
 100b4ee:	mov    %rbx,%rdi
 100b4f1:	vzeroupper
 100b4f4:	call   100c3f0 <myl_qbe_fail_allocation>
 100b4f9:	mov    %rbx,%rdi
 100b4fc:	call   100c4e0 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
