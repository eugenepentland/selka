 1007b90:	mov    %rcx,-0x60(%rbp)
 1007b94:	mov    %rax,-0x58(%rbp)
 1007b98:	cmp    %rax,%rcx
 1007b9b:	setl   %r10b
 1007b9f:	movzbq %r10b,%r10
 1007ba3:	mov    %r10,-0x60(%rbp)
 1007ba7:	jge    1007c22 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee2>
 1007ba9:	mov    %rax,-0x60(%rbp)
 1007bad:	movq   $0x0,-0x60(%rbp)
 1007bb5:	mov    %rcx,-0x60(%rbp)
 1007bb9:	mov    (%r9,%rcx,8),%r11
 1007bbd:	mov    %r11,-0x60(%rbp)
 1007bc1:	mov    %rdx,-0x60(%rbp)
 1007bc5:	mov    %r11,-0x58(%rbp)
 1007bc9:	mov    %rdx,%r10
 1007bcc:	add    %r11,%rdx
 1007bcf:	mov    %r10,%rbx
 1007bd2:	xor    %rdx,%rbx
 1007bd5:	mov    %r11,%r12
 1007bd8:	xor    %rdx,%r12
 1007bdb:	and    %r12,%rbx
 1007bde:	cmp    $0x0,%rbx
 1007be2:	jl     1007c0a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xeca>
 1007be4:	mov    %rdx,-0x60(%rbp)
 1007be8:	mov    %rax,-0x60(%rbp)
 1007bec:	movq   $0x0,-0x60(%rbp)
 1007bf4:	mov    %rcx,-0x60(%rbp)
 1007bf8:	movq   $0x1,-0x58(%rbp)
 1007c00:	add    $0x1,%rcx
 1007c04:	mov    %rcx,-0x60(%rbp)
 1007c08:	jmp    1007b90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe50>
