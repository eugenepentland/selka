
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/read-version/controls/parity-micro-list_append_sum-after-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001006d40 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 1006d40:	endbr64
 1006d44:	push   %rbp
 1006d45:	mov    %rsp,%rbp
 1006d48:	sub    $0x1c8,%rsp
 1006d4f:	push   %rbx
 1006d50:	push   %r12
 1006d52:	push   %r13
 1006d54:	push   %r14
 1006d56:	push   %r15
 1006d58:	mov    %rsi,-0x20(%rbp)
 1006d5c:	mov    %rdi,-0x38(%rbp)
 1006d60:	mov    $0x20,%edx
 1006d65:	mov    $0x0,%esi
 1006d6a:	mov    %rdi,%rbx
 1006d6d:	lea    -0x98(%rbp),%rdi
 1006d74:	call   1017c30 <compiler_rt.fastMemset>
 1006d79:	mov    %rbx,%rdi
 1006d7c:	movq   $0x0,-0x78(%rbp)
 1006d84:	movq   $0x0,-0x70(%rbp)
 1006d8c:	movq   $0x0,-0x68(%rbp)
 1006d94:	mov    %rdi,%rbx
 1006d97:	call   10088d0 <myl_qbe_heap>
 1006d9c:	mov    %rbx,%rdi
 1006d9f:	mov    %rax,%rbx
 1006da2:	mov    %rdi,%r12
 1006da5:	call   100a490 <myl_qbe_region_mark>
 1006daa:	mov    %r12,%rdi
 1006dad:	mov    %rax,-0x18(%rbp)
 1006db1:	mov    $0x30,%edx
 1006db6:	mov    $0x0,%esi
 1006dbb:	mov    %rdi,%r12
 1006dbe:	lea    -0xe0(%rbp),%rdi
 1006dc5:	call   1017c30 <compiler_rt.fastMemset>
 1006dca:	mov    %r12,%rdi
 1006dcd:	lea    0x130ec(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1006dd4:	mov    %rax,-0x1a0(%rbp)
 1006ddb:	movl   $0x2,-0x188(%rbp)
 1006de5:	lea    -0x78(%rbp),%rax
 1006de9:	mov    %rax,-0x198(%rbp)
 1006df0:	lea    -0xe0(%rbp),%rax
 1006df7:	mov    %rax,-0x190(%rbp)
 1006dfe:	lea    -0x1a0(%rbp),%rax
 1006e05:	mov    %rax,%r12
 1006e08:	add    $0x20,%r12
 1006e0c:	mov    %r12,-0x8(%rbp)
 1006e10:	lea    0x130a9(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1006e17:	mov    %rax,-0x180(%rbp)
 1006e1e:	movl   $0x2,-0x168(%rbp)
 1006e28:	lea    -0x70(%rbp),%rax
 1006e2c:	mov    %rax,-0x178(%rbp)
 1006e33:	lea    -0xe0(%rbp),%rax
 1006e3a:	mov    %rax,%rcx
 1006e3d:	add    $0x8,%rcx
 1006e41:	mov    %rcx,-0x170(%rbp)
 1006e48:	lea    -0x1a0(%rbp),%rax
 1006e4f:	add    $0x40,%rax
 1006e53:	mov    %rax,-0x50(%rbp)
 1006e57:	lea    0x13062(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1006e5e:	mov    %rax,-0x160(%rbp)
 1006e65:	movl   $0x2,-0x148(%rbp)
 1006e6f:	lea    -0x68(%rbp),%rax
 1006e73:	mov    %rax,-0x158(%rbp)
 1006e7a:	lea    -0xe0(%rbp),%rax
 1006e81:	mov    %rax,%r12
 1006e84:	add    $0x10,%r12
 1006e88:	mov    %r12,-0x40(%rbp)
 1006e8c:	mov    %r12,-0x150(%rbp)
 1006e93:	lea    -0x1a0(%rbp),%rax
 1006e9a:	mov    %rax,%rsi
 1006e9d:	add    $0x60,%rsi
 1006ea1:	mov    %rsi,-0x48(%rbp)
 1006ea5:	lea    -0x4bb4(%rip),%rax        # 10022f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1006eac:	mov    %rax,-0x140(%rbp)
 1006eb3:	movl   $0x0,-0x128(%rbp)
 1006ebd:	lea    -0xb0(%rbp),%rax
 1006ec4:	mov    %rax,-0x138(%rbp)
 1006ecb:	lea    -0xe0(%rbp),%rax
 1006ed2:	mov    %rax,%r14
 1006ed5:	add    $0x18,%r14
 1006ed9:	mov    %r14,-0x28(%rbp)
 1006edd:	mov    %r14,-0x130(%rbp)
 1006ee4:	lea    -0x4bf3(%rip),%rax        # 10022f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1006eeb:	mov    %rax,-0x120(%rbp)
 1006ef2:	movl   $0x0,-0x108(%rbp)
 1006efc:	lea    -0xa8(%rbp),%rax
 1006f03:	mov    %rax,-0x118(%rbp)
 1006f0a:	lea    -0xe0(%rbp),%rax
 1006f11:	mov    %rax,%r13
 1006f14:	add    $0x20,%r13
 1006f18:	mov    %r13,-0x30(%rbp)
 1006f1c:	mov    %r13,-0x110(%rbp)
 1006f23:	lea    -0x4c32(%rip),%rax        # 10022f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1006f2a:	mov    %rax,-0x100(%rbp)
 1006f31:	movl   $0x0,-0xe8(%rbp)
 1006f3b:	lea    -0xa0(%rbp),%rax
 1006f42:	mov    %rax,-0xf8(%rbp)
 1006f49:	lea    -0xe0(%rbp),%rax
 1006f50:	add    $0x28,%rax
 1006f54:	mov    %rax,-0xf0(%rbp)
 1006f5b:	mov    %rcx,%r15
 1006f5e:	mov    $0x6,%ecx
 1006f63:	lea    -0x1a0(%rbp),%rdx
 1006f6a:	lea    -0x1c0(%rbp),%rsi
 1006f71:	mov    %rdi,%r12
 1006f74:	call   1007fb0 <myl_qbe_rc_frame_enter>
 1006f79:	mov    %r12,%rdi
 1006f7c:	mov    %rdi,%r12
 1006f7f:	call   10088e0 <myl_qbe_require_step_accounting>
 1006f84:	mov    %r12,%rdi
 1006f87:	mov    %rdi,%r12
 1006f8a:	call   1008940 <myl_qbe_require_frame_accounting>
 1006f8f:	mov    %r12,%rdi
 1006f92:	movq   $0x0,-0x60(%rbp)
 1006f9a:	mov    $0x0,%edx
 1006f9f:	lea    -0x4dfe(%rip),%rsi        # 10021a8 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1006fa6:	mov    %rdi,%r12
 1006fa9:	mov    %rbx,%rdi
 1006fac:	call   100ea70 <myl_native_list_new>
 1006fb1:	mov    %r15,%rcx
 1006fb4:	mov    %r12,%rdi
 1006fb7:	mov    -0x18(%rbp),%r8
 1006fbb:	cmp    $0x0,%eax
 1006fbe:	jne    1006fca <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x28a>
 1006fc0:	mov    %rdi,%rbx
 1006fc3:	call   1008620 <myl_qbe_fail_allocation>
 1006fc8:	ud2
 1006fca:	xchg   %rdi,%rbx
 1006fcd:	mov    %rax,-0x60(%rbp)
 1006fd1:	mov    -0x60(%rbp),%rdx
 1006fd5:	mov    %rdx,-0xa8(%rbp)
 1006fdc:	lea    0x12edd(%rip),%rdx        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1006fe3:	mov    %rdx,-0x120(%rbp)
 1006fea:	movl   $0x2,-0x108(%rbp)
 1006ff4:	movl   $0x1,-0xc0(%rbp)
 1006ffe:	mov    -0xa8(%rbp),%rdx
 1007005:	mov    %rdx,-0xb0(%rbp)
 100700c:	lea    0x12ead(%rip),%rdx        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007013:	mov    %rdx,-0x140(%rbp)
 100701a:	movl   $0x2,-0x128(%rbp)
 1007024:	movl   $0x2,-0x128(%rbp)
 100702e:	movl   $0x0,-0xc0(%rbp)
 1007038:	movl   $0x1,-0xc8(%rbp)
 1007042:	mov    %rax,-0x60(%rbp)
 1007046:	lea    -0xa8(%rbp),%rsi
 100704d:	lea    -0x60(%rbp),%rdx
 1007051:	sub    %rsi,%rdx
 1007054:	lea    -0x60(%rbp),%r9
 1007058:	lea    -0xa8(%rbp),%rsi
 100705f:	sub    %r9,%rsi
 1007062:	cmp    $0x8,%rdx
 1007066:	setb   %dl
 1007069:	movzbl %dl,%edx
 100706c:	mov    %edx,-0x10(%rbp)
 100706f:	cmp    $0x8,%rsi
 1007073:	setb   %r9b
 1007077:	movzbl %r9b,%r9d
 100707b:	mov    %r9d,-0xc(%rbp)
 100707f:	or     %r9d,%edx
 1007082:	jne    10070ee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3ae>
 1007084:	cmp    $0x0,%rax
 1007088:	jne    100708f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x34f>
 100708a:	mov    %rcx,%r15
 100708d:	jmp    10070ac <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x36c>
 100708f:	sub    $0x10,%rax
 1007093:	mov    (%rax),%rax
 1007096:	mov    %rcx,%r15
 1007099:	movabs $0x5000000000000001,%rcx
 10070a3:	and    %rcx,%rax
 10070a6:	cmp    $0x0,%rax
 10070aa:	jne    10070eb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3ab>
 10070ac:	mov    -0x60(%rbp),%rax
 10070b0:	mov    %rax,-0xa8(%rbp)
 10070b7:	mov    $0x8,%edx
 10070bc:	mov    $0x0,%esi
 10070c1:	mov    %rdi,%r12
 10070c4:	lea    -0x60(%rbp),%rdi
 10070c8:	call   1017c30 <compiler_rt.fastMemset>
 10070cd:	mov    %r15,%rcx
 10070d0:	mov    %r12,%rdi
 10070d3:	mov    -0xc(%rbp),%r9d
 10070d7:	mov    -0x10(%rbp),%edx
 10070da:	mov    -0x48(%rbp),%rsi
 10070de:	mov    -0x8(%rbp),%r12
 10070e2:	mov    -0x18(%rbp),%r8
 10070e6:	mov    %rcx,%r15
 10070e9:	jmp    1007140 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x400>
 10070eb:	mov    %r15,%rcx
 10070ee:	mov    %rcx,%r15
 10070f1:	lea    -0x60(%rbp),%rcx
 10070f5:	lea    -0xa8(%rbp),%rdx
 10070fc:	lea    0x12dbd(%rip),%rsi        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007103:	mov    %rdi,%r12
 1007106:	call   1017460 <myl_rc_native_take>
 100710b:	mov    %r12,%rdi
 100710e:	mov    -0xc(%rbp),%r9d
 1007112:	mov    -0x10(%rbp),%edx
 1007115:	mov    -0x48(%rbp),%rsi
 1007119:	mov    -0x8(%rbp),%r12
 100711d:	mov    -0x18(%rbp),%r8
 1007121:	cmp    $0x0,%eax
 1007124:	jne    1007140 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x400>
 1007126:	call   100f570 <myl_rc_take_failure>
 100712b:	mov    %rbx,%rdi
 100712e:	mov    %eax,%esi
 1007130:	mov    %rdi,%rbx
 1007133:	call   1007ec0 <myl_qbe_rc_status>
 1007138:	mov    %rbx,%rdi
 100713b:	jmp    1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007140:	movl   $0x0,-0xc8(%rbp)
 100714a:	lea    0x12d6f(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007151:	mov    %rax,-0x120(%rbp)
 1007158:	movl   $0x2,-0x108(%rbp)
 1007162:	movl   $0x1,-0xc0(%rbp)
 100716c:	mov    -0xe0(%rbp),%eax
 1007172:	cmp    $0x0,%eax
 1007175:	jne    100717c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43c>
 1007177:	mov    %r15,%rcx
 100717a:	jmp    10071a7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x467>
 100717c:	lea    -0x1a0(%rbp),%rsi
 1007183:	mov    %rdi,%r12
 1007186:	mov    %rbx,%rdi
 1007189:	call   1008090 <myl_qbe_rc_slot_drop>
 100718e:	mov    %r15,%rcx
 1007191:	mov    %r12,%rdi
 1007194:	mov    -0xc(%rbp),%r9d
 1007198:	mov    -0x10(%rbp),%edx
 100719b:	mov    -0x48(%rbp),%rsi
 100719f:	mov    -0x8(%rbp),%r12
 10071a3:	mov    -0x18(%rbp),%r8
 10071a7:	mov    -0xa8(%rbp),%rax
 10071ae:	mov    %rax,-0x78(%rbp)
 10071b2:	movl   $0x0,-0xc0(%rbp)
 10071bc:	lea    0x12cfd(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10071c3:	mov    %rax,-0x1a0(%rbp)
 10071ca:	movl   $0x2,-0x188(%rbp)
 10071d4:	lea    -0x78(%rbp),%rax
 10071d8:	mov    %rax,-0x198(%rbp)
 10071df:	lea    -0xe0(%rbp),%rax
 10071e6:	mov    %rax,-0x190(%rbp)
 10071ed:	mov    -0x108(%rbp),%eax
 10071f3:	mov    %eax,-0x188(%rbp)
 10071f9:	movl   $0x1,-0xe0(%rbp)
 1007203:	mov    %rcx,%r15
 1007206:	mov    %eax,%ecx
 1007208:	mov    -0x78(%rbp),%rax
 100720c:	cmp    $0x8,%ecx
 100720f:	je     1007220 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4e0>
 1007211:	mov    %r12,%r13
 1007214:	mov    %rax,-0x60(%rbp)
 1007218:	mov    %r15,%rcx
 100721b:	jmp    1007314 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5d4>
 1007220:	movq   $0x0,-0xa8(%rbp)
 100722b:	lea    -0xa8(%rbp),%rdx
 1007232:	mov    %rax,%rsi
 1007235:	mov    %rdi,%r12
 1007238:	call   100fac0 <myl_rc_hold_acquire>
 100723d:	mov    %r12,%rdi
 1007240:	mov    %eax,%esi
 1007242:	mov    %rdi,%r12
 1007245:	mov    %rbx,%rdi
 1007248:	call   1007ec0 <myl_qbe_rc_status>
 100724d:	mov    %r15,%rcx
 1007250:	mov    %r12,%rdi
 1007253:	mov    -0xc(%rbp),%r9d
 1007257:	mov    -0x10(%rbp),%edx
 100725a:	mov    -0x48(%rbp),%rsi
 100725e:	mov    %r13,%r12
 1007261:	mov    -0x8(%rbp),%r13
 1007265:	mov    -0x18(%rbp),%r8
 1007269:	cmp    $0x0,%eax
 100726c:	jne    1007276 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x536>
 100726e:	mov    %rbx,%rdi
 1007271:	jmp    1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007276:	lea    0x12c43(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 100727d:	mov    %rax,-0x120(%rbp)
 1007284:	movl   $0x2,-0x108(%rbp)
 100728e:	lea    -0xa8(%rbp),%rax
 1007295:	mov    %rax,-0x118(%rbp)
 100729c:	mov    %r12,-0x110(%rbp)
 10072a3:	movl   $0x8,-0x108(%rbp)
 10072ad:	movl   $0x1,-0xc0(%rbp)
 10072b7:	mov    -0xa8(%rbp),%rax
 10072be:	mov    %rax,-0xb0(%rbp)
 10072c5:	lea    0x12bf4(%rip),%r10        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10072cc:	mov    %r10,-0x140(%rbp)
 10072d3:	movl   $0x2,-0x128(%rbp)
 10072dd:	lea    -0xb0(%rbp),%r10
 10072e4:	mov    %r10,-0x138(%rbp)
 10072eb:	mov    %r14,-0x130(%rbp)
 10072f2:	movl   $0x8,-0x128(%rbp)
 10072fc:	movl   $0x1,-0xc8(%rbp)
 1007306:	movl   $0x0,-0xc0(%rbp)
 1007310:	mov    %rax,-0x60(%rbp)
 1007314:	mov    -0xc8(%rbp),%r10d
 100731b:	mov    -0x128(%rbp),%r11d
 1007322:	and    $0x18,%r11d
 1007326:	cmp    $0x0,%r11d
 100732a:	sete   %r11b
 100732e:	movzbl %r11b,%r11d
 1007332:	test   %r10d,%r11d
 1007335:	jne    10073d4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x694>
 100733b:	mov    %rcx,%r14
 100733e:	lea    -0x60(%rbp),%rcx
 1007342:	lea    -0xa8(%rbp),%rdx
 1007349:	mov    %rsi,%r15
 100734c:	lea    0x12b6d(%rip),%rsi        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007353:	mov    %rdi,%r12
 1007356:	call   1017840 <myl_rc_native_retain>
 100735b:	mov    %r15,%rsi
 100735e:	mov    %r12,%rdi
 1007361:	cmp    $0x0,%eax
 1007364:	jne    1007380 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x640>
 1007366:	call   100f570 <myl_rc_take_failure>
 100736b:	mov    %rbx,%rdi
 100736e:	mov    %eax,%esi
 1007370:	mov    %rdi,%rbx
 1007373:	call   1007ec0 <myl_qbe_rc_status>
 1007378:	mov    %rbx,%rdi
 100737b:	jmp    1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007380:	lea    0x12b39(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007387:	mov    %rax,-0x120(%rbp)
 100738e:	movl   $0x2,-0x108(%rbp)
 1007398:	movl   $0x1,-0xc0(%rbp)
 10073a2:	mov    -0xc8(%rbp),%eax
 10073a8:	cmp    $0x0,%eax
 10073ab:	jne    10073b5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x675>
 10073ad:	mov    %r14,%rcx
 10073b0:	mov    %r13,%rsi
 10073b3:	jmp    10073c9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x689>
 10073b5:	mov    %rdi,%r12
 10073b8:	mov    %rbx,%rdi
 10073bb:	call   1008090 <myl_qbe_rc_slot_drop>
 10073c0:	mov    %r14,%rcx
 10073c3:	mov    %r13,%rsi
 10073c6:	mov    %r12,%rdi
 10073c9:	mov    %rcx,%r13
 10073cc:	xchg   %rbx,%rdi
 10073cf:	jmp    10074b0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x770>
 10073d4:	mov    %r13,%rsi
 10073d7:	or     %r9d,%edx
 10073da:	jne    100743c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6fc>
 10073dc:	cmp    $0x0,%rax
 10073e0:	jne    10073e7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6a7>
 10073e2:	mov    %rcx,%r14
 10073e5:	jmp    1007404 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6c4>
 10073e7:	sub    $0x10,%rax
 10073eb:	mov    (%rax),%rax
 10073ee:	mov    %rcx,%r14
 10073f1:	movabs $0x5000000000000001,%rcx
 10073fb:	and    %rcx,%rax
 10073fe:	cmp    $0x0,%rax
 1007402:	jne    1007439 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6f9>
 1007404:	mov    -0x60(%rbp),%rax
 1007408:	mov    %rax,-0xa8(%rbp)
 100740f:	mov    $0x8,%edx
 1007414:	mov    %rsi,%r13
 1007417:	mov    $0x0,%esi
 100741c:	mov    %rdi,%r12
 100741f:	lea    -0x60(%rbp),%rdi
 1007423:	call   1017c30 <compiler_rt.fastMemset>
 1007428:	mov    %r14,%rcx
 100742b:	mov    %r13,%rsi
 100742e:	mov    %r12,%rdi
 1007431:	mov    %rcx,%r13
 1007434:	xchg   %rbx,%rdi
 1007437:	jmp    1007484 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x744>
 1007439:	mov    %r14,%rcx
 100743c:	mov    %rcx,%r13
 100743f:	lea    -0x60(%rbp),%rcx
 1007443:	lea    -0xa8(%rbp),%rdx
 100744a:	mov    %rsi,%r14
 100744d:	lea    0x12a6c(%rip),%rsi        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007454:	mov    %rdi,%r12
 1007457:	call   1017460 <myl_rc_native_take>
 100745c:	mov    %r14,%rsi
 100745f:	mov    %r12,%rdi
 1007462:	cmp    $0x0,%eax
 1007465:	jne    1007481 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x741>
 1007467:	call   100f570 <myl_rc_take_failure>
 100746c:	mov    %rbx,%rdi
 100746f:	mov    %eax,%esi
 1007471:	mov    %rdi,%rbx
 1007474:	call   1007ec0 <myl_qbe_rc_status>
 1007479:	mov    %rbx,%rdi
 100747c:	jmp    1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007481:	xchg   %rbx,%rdi
 1007484:	movl   $0x0,-0xc8(%rbp)
 100748e:	lea    0x12a2b(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007495:	mov    %rax,-0x120(%rbp)
 100749c:	movl   $0x2,-0x108(%rbp)
 10074a6:	movl   $0x1,-0xc0(%rbp)
 10074b0:	mov    -0xd8(%rbp),%eax
 10074b6:	cmp    $0x0,%eax
 10074b9:	je     10074c6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x786>
 10074bb:	mov    %rdi,%r12
 10074be:	call   1008090 <myl_qbe_rc_slot_drop>
 10074c3:	mov    %r12,%rdi
 10074c6:	mov    -0xa8(%rbp),%rax
 10074cd:	mov    %rax,-0x70(%rbp)
 10074d1:	movl   $0x0,-0xc0(%rbp)
 10074db:	lea    0x129de(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10074e2:	mov    %rax,-0x180(%rbp)
 10074e9:	movl   $0x2,-0x168(%rbp)
 10074f3:	lea    -0x70(%rbp),%rax
 10074f7:	mov    %rax,-0x178(%rbp)
 10074fe:	mov    %r13,-0x170(%rbp)
 1007505:	mov    -0x108(%rbp),%eax
 100750b:	mov    %eax,-0x168(%rbp)
 1007511:	movl   $0x1,-0xd8(%rbp)
 100751b:	mov    -0xe0(%rbp),%eax
 1007521:	cmp    $0x0,%eax
 1007524:	jne    100752b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7eb>
 1007526:	mov    %r13,%rcx
 1007529:	jmp    1007540 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x800>
 100752b:	lea    -0x1a0(%rbp),%rsi
 1007532:	mov    %rdi,%r12
 1007535:	call   1008090 <myl_qbe_rc_slot_drop>
 100753a:	mov    %r13,%rcx
 100753d:	mov    %r12,%rdi
 1007540:	movq   $0x0,-0x60(%rbp)
 1007548:	movq   $0xf42400,-0x60(%rbp)
 1007550:	lea    0x12969(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007557:	mov    %rax,-0x180(%rbp)
 100755e:	movl   $0x2,-0x168(%rbp)
 1007568:	lea    -0x70(%rbp),%rax
 100756c:	mov    %rax,-0x178(%rbp)
 1007573:	mov    %rcx,-0x170(%rbp)
 100757a:	lea    -0x70(%rbp),%rdx
 100757e:	lea    0x1293b(%rip),%rsi        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007585:	mov    %rdi,%r12
 1007588:	call   1008410 <myl_qbe_rc_unique_local>
 100758d:	mov    %r12,%rdi
 1007590:	cmp    $0x0,%eax
 1007593:	je     1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007599:	mov    %rbx,%rdi
 100759c:	mov    %rdi,%rbx
 100759f:	mov    $0x0,%eax
 10075a4:	mov    $0x0,%r12d
 10075aa:	nopw   0x0(%rax,%rax,1)
 10075b0:	mov    %r12,-0x60(%rbp)
 10075b4:	movq   $0xf42400,-0x58(%rbp)
 10075bc:	cmp    $0xf42400,%r12
 10075c3:	setl   %cl
 10075c6:	movzbq %cl,%rcx
 10075ca:	mov    %rcx,-0x60(%rbp)
 10075ce:	jge    10076a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x969>
 10075d4:	mov    %r12,-0x60(%rbp)
 10075d8:	mov    -0x70(%rbp),%r13
 10075dc:	mov    0x0(%r13),%r15
 10075e0:	mov    0x8(%r13),%rcx
 10075e4:	mov    0x10(%r13),%r14
 10075e8:	cmp    %rcx,%r15
 10075eb:	setb   %cl
 10075ee:	movzbl %cl,%ecx
 10075f1:	cmp    $0xffffffffffffffff,%r14
 10075f5:	setne  %dl
 10075f8:	movzbl %dl,%edx
 10075fb:	test   %ecx,%edx
 10075fd:	je     1007614 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8d4>
 10075ff:	cmp    $0x0,%eax
 1007602:	jne    100763a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8fa>
 1007604:	mov    %r13,%rsi
 1007607:	mov    %rbx,%rdi
 100760a:	call   100ed70 <myl_rc_list_plain_ready>
 100760f:	cmp    $0x0,%eax
 1007612:	jne    100763a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8fa>
 1007614:	lea    -0x60(%rbp),%rdx
 1007618:	mov    %r13,%rsi
 100761b:	mov    %rbx,%rdi
 100761e:	call   100ec40 <myl_rc_list_append>
 1007623:	cmp    $0x0,%eax
 1007626:	je     100762f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ef>
 1007628:	mov    $0x0,%eax
 100762d:	jmp    1007658 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x918>
 100762f:	mov    -0x38(%rbp),%rdi
 1007633:	call   1008620 <myl_qbe_fail_allocation>
 1007638:	ud2
 100763a:	mov    0x20(%r13),%rcx
 100763e:	mov    %r12,(%rcx,%r15,8)
 1007642:	mov    %r15,%rcx
 1007645:	add    $0x1,%rcx
 1007649:	mov    %rcx,0x0(%r13)
 100764d:	mov    %r14,%rcx
 1007650:	add    $0x1,%rcx
 1007654:	mov    %rcx,0x10(%r13)
 1007658:	movq   $0x0,-0x60(%rbp)
 1007660:	mov    %r12,-0x60(%rbp)
 1007664:	movq   $0x1,-0x58(%rbp)
 100766c:	movabs $0x7ffffffffffffffe,%rcx
 1007676:	cmp    %rcx,%r12
 1007679:	jg     1007688 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x948>
 100767b:	add    $0x1,%r12
 100767f:	mov    %r12,-0x60(%rbp)
 1007683:	jmp    10075b0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x870>
 1007688:	mov    %r12,%rdx
 100768b:	mov    -0x38(%rbp),%rdi
 100768f:	mov    $0x40,%r8d
 1007695:	mov    $0x1,%ecx
 100769a:	mov    $0x0,%esi
 100769f:	mov    %rdi,%r15
 10076a2:	call   1008710 <myl_qbe_fail_overflow_op>
 10076a7:	ud2
 10076a9:	mov    -0x30(%rbp),%r13
 10076ad:	mov    -0x28(%rbp),%r14
 10076b1:	mov    %rbx,%rdi
 10076b4:	mov    -0x40(%rbp),%rbx
 10076b8:	mov    -0x20(%rbp),%rdx
 10076bc:	mov    -0x38(%rbp),%r15
 10076c0:	movq   $0x0,-0x60(%rbp)
 10076c8:	mov    -0x70(%rbp),%rsi
 10076cc:	mov    -0x168(%rbp),%eax
 10076d2:	cmp    $0x8,%eax
 10076d5:	sete   %al
 10076d8:	movzbl %al,%eax
 10076db:	mov    -0xd8(%rbp),%ecx
 10076e1:	test   %eax,%ecx
 10076e3:	jne    10076ee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9ae>
 10076e5:	mov    %rsi,-0x60(%rbp)
 10076e9:	jmp    10077d0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa90>
 10076ee:	movq   $0x0,-0xa8(%rbp)
 10076f9:	mov    %rdx,%r12
 10076fc:	lea    -0xa8(%rbp),%rdx
 1007703:	mov    %rdi,%rbx
 1007706:	call   100fac0 <myl_rc_hold_acquire>
 100770b:	mov    %rbx,%rdi
 100770e:	mov    %eax,%esi
 1007710:	mov    %rdi,%rbx
 1007713:	mov    %r15,%rdi
 1007716:	call   1007ec0 <myl_qbe_rc_status>
 100771b:	mov    %r12,%rdx
 100771e:	mov    %rbx,%rdi
 1007721:	mov    -0x40(%rbp),%rbx
 1007725:	cmp    $0x0,%eax
 1007728:	jne    1007732 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9f2>
 100772a:	mov    %r15,%rdi
 100772d:	jmp    1007809 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xac9>
 1007732:	lea    0x12787(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007739:	mov    %rax,-0x120(%rbp)
 1007740:	movl   $0x2,-0x108(%rbp)
 100774a:	lea    -0xa8(%rbp),%rax
 1007751:	mov    %rax,-0x118(%rbp)
 1007758:	mov    %r13,-0x110(%rbp)
 100775f:	movl   $0x8,-0x108(%rbp)
 1007769:	movl   $0x1,-0xc0(%rbp)
 1007773:	mov    -0xa8(%rbp),%rsi
 100777a:	mov    %rsi,-0xb0(%rbp)
 1007781:	lea    0x12738(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007788:	mov    %rax,-0x140(%rbp)
 100778f:	movl   $0x2,-0x128(%rbp)
 1007799:	lea    -0xb0(%rbp),%rax
 10077a0:	mov    %rax,-0x138(%rbp)
 10077a7:	mov    %r14,-0x130(%rbp)
 10077ae:	movl   $0x8,-0x128(%rbp)
 10077b8:	movl   $0x1,-0xc8(%rbp)
 10077c2:	movl   $0x0,-0xc0(%rbp)
 10077cc:	mov    %rsi,-0x60(%rbp)
 10077d0:	movq   $0x0,-0xa8(%rbp)
 10077db:	mov    %rdx,%r12
 10077de:	lea    -0xa8(%rbp),%rdx
 10077e5:	call   100fac0 <myl_rc_hold_acquire>
 10077ea:	mov    %r15,%rdi
 10077ed:	mov    %eax,%esi
 10077ef:	mov    %rdi,%r15
 10077f2:	call   1007ec0 <myl_qbe_rc_status>
 10077f7:	mov    %r15,%rdi
 10077fa:	mov    %eax,%ecx
 10077fc:	mov    -0x48(%rbp),%rsi
 1007800:	mov    -0x50(%rbp),%rax
 1007804:	cmp    $0x0,%ecx
 1007807:	jne    1007831 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaf1>
 1007809:	lea    -0x1c0(%rbp),%rsi
 1007810:	mov    %rdi,%rbx
 1007813:	call   10081c0 <myl_qbe_rc_frame_cleanup>
 1007818:	mov    %rbx,%rdi
 100781b:	lea    -0x1c0(%rbp),%rsi
 1007822:	call   1008030 <myl_qbe_rc_frame_leave>
 1007827:	mov    $0x0,%eax
 100782c:	jmp    1007cbb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf7b>
 1007831:	lea    0x12688(%rip),%rcx        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007838:	mov    %rcx,-0x120(%rbp)
 100783f:	movl   $0x2,-0x108(%rbp)
 1007849:	lea    -0xa8(%rbp),%rcx
 1007850:	mov    %rcx,-0x118(%rbp)
 1007857:	mov    %r13,-0x110(%rbp)
 100785e:	movl   $0x8,-0x108(%rbp)
 1007868:	movl   $0x1,-0xc0(%rbp)
 1007872:	mov    -0xc8(%rbp),%ecx
 1007878:	cmp    $0x0,%ecx
 100787b:	jne    1007882 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb42>
 100787d:	mov    %rax,%rsi
 1007880:	jmp    1007891 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb51>
 1007882:	mov    %rdi,%r15
 1007885:	call   1008090 <myl_qbe_rc_slot_drop>
 100788a:	mov    %r15,%rdi
 100788d:	mov    -0x50(%rbp),%rsi
 1007891:	mov    -0xa8(%rbp),%rax
 1007898:	mov    %rax,-0xb0(%rbp)
 100789f:	lea    0x1261a(%rip),%rcx        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10078a6:	mov    %rcx,-0x140(%rbp)
 10078ad:	movl   $0x2,-0x128(%rbp)
 10078b7:	lea    -0xb0(%rbp),%rcx
 10078be:	mov    %rcx,-0x138(%rbp)
 10078c5:	mov    %r14,-0x130(%rbp)
 10078cc:	movl   $0x8,-0x128(%rbp)
 10078d6:	movl   $0x1,-0xc8(%rbp)
 10078e0:	movl   $0x0,-0xc0(%rbp)
 10078ea:	mov    %rax,-0x60(%rbp)
 10078ee:	mov    %rax,-0xa8(%rbp)
 10078f5:	lea    0x125c4(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10078fc:	mov    %rax,-0x120(%rbp)
 1007903:	movl   $0x2,-0x108(%rbp)
 100790d:	lea    -0xa8(%rbp),%rax
 1007914:	mov    %rax,-0x118(%rbp)
 100791b:	mov    %r13,-0x110(%rbp)
 1007922:	movl   $0x8,-0x108(%rbp)
 100792c:	movl   $0x1,-0xc0(%rbp)
 1007936:	movl   $0x0,-0xc8(%rbp)
 1007940:	mov    -0xd0(%rbp),%eax
 1007946:	cmp    $0x0,%eax
 1007949:	je     1007956 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc16>
 100794b:	mov    %rdi,%r13
 100794e:	call   1008090 <myl_qbe_rc_slot_drop>
 1007953:	mov    %r13,%rdi
 1007956:	mov    -0xa8(%rbp),%r8
 100795d:	mov    %r8,-0x68(%rbp)
 1007961:	lea    0x12558(%rip),%rax        # 1019ec0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007968:	mov    %rax,-0x160(%rbp)
 100796f:	movl   $0x2,-0x148(%rbp)
 1007979:	lea    -0x68(%rbp),%rax
 100797d:	mov    %rax,-0x158(%rbp)
 1007984:	mov    %rbx,-0x150(%rbp)
 100798b:	movl   $0x8,-0x148(%rbp)
 1007995:	movl   $0x1,-0xd0(%rbp)
 100799f:	movl   $0x0,-0xc0(%rbp)
 10079a9:	movq   $0x0,-0x60(%rbp)
 10079b1:	mov    (%r8),%rsi
 10079b4:	mov    %rsi,-0x60(%rbp)
 10079b8:	movabs $0x7fffffffffffffff,%rax
 10079c2:	cmp    %rax,%rsi
 10079c5:	ja     1007cc6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf86>
 10079cb:	mov    %rsi,-0x60(%rbp)
 10079cf:	cmp    $0x0,%rsi
 10079d3:	setg   %al
 10079d6:	movzbq %al,%rax
 10079da:	cmp    $0x10,%rsi
 10079de:	setae  %cl
 10079e1:	movzbq %cl,%rcx
 10079e5:	test   %rax,%rcx
 10079e8:	jne    10079fd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcbd>
 10079ea:	mov    %rsi,%rax
 10079ed:	mov    %r12,%rsi
 10079f0:	mov    $0x0,%edx
 10079f5:	mov    $0x0,%r9d
 10079fb:	jmp    1007a70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd30>
 10079fd:	movabs $0x1000000000000000,%rax
 1007a07:	mov    %rsi,%rcx
 1007a0a:	add    %rax,%rcx
 1007a0d:	movabs $0x2000000000000000,%rax
 1007a17:	cmp    %rax,%rcx
 1007a1a:	jbe    1007a2f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xcef>
 1007a1c:	mov    %rsi,%rax
 1007a1f:	mov    %r12,%rsi
 1007a22:	mov    $0x0,%edx
 1007a27:	mov    $0x0,%r9d
 1007a2d:	jmp    1007a70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd30>
 1007a2f:	mov    (%r8),%rax
 1007a32:	cmp    %rax,%rsi
 1007a35:	je     1007a4a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd0a>
 1007a37:	mov    %rsi,%rax
 1007a3a:	mov    %r12,%rsi
 1007a3d:	mov    $0x0,%edx
 1007a42:	mov    $0x0,%r9d
 1007a48:	jmp    1007a70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd30>
 1007a4a:	cmp    %rax,%rsi
 1007a4d:	jle    1007b70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe30>
 1007a53:	mov    %rsi,%rax
 1007a56:	mov    %r12,%rsi
 1007a59:	mov    $0x0,%edx
 1007a5e:	mov    $0x0,%r9d
 1007a64:	cs nopw 0x0(%rax,%rax,1)
 1007a6e:	xchg   %ax,%ax
 1007a70:	mov    %r9,-0x60(%rbp)
 1007a74:	mov    %rax,-0x58(%rbp)
 1007a78:	cmp    %rax,%r9
 1007a7b:	setl   %cl
 1007a7e:	movzbq %cl,%rcx
 1007a82:	mov    %rcx,-0x60(%rbp)
 1007a86:	jge    1007c22 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee2>
 1007a8c:	mov    %rax,-0x60(%rbp)
 1007a90:	mov    (%r8),%rcx
 1007a93:	cmp    %rcx,%rax
 1007a96:	jne    1007b69 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe29>
 1007a9c:	movq   $0x0,-0x60(%rbp)
 1007aa4:	mov    %r9,-0x60(%rbp)
 1007aa8:	mov    (%r8),%rcx
 1007aab:	cmp    %rcx,%r9
 1007aae:	jae    1007b5c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe1c>
 1007ab4:	mov    0x20(%r8),%rcx
 1007ab8:	mov    (%rcx,%r9,8),%rcx
 1007abc:	mov    %rcx,-0x60(%rbp)
 1007ac0:	mov    %rdx,-0x60(%rbp)
 1007ac4:	mov    %rcx,-0x58(%rbp)
 1007ac8:	mov    %rdx,%r10
 1007acb:	add    %rcx,%rdx
 1007ace:	mov    %r10,%r11
 1007ad1:	xor    %rdx,%r11
 1007ad4:	mov    %rcx,%rbx
 1007ad7:	xor    %rdx,%rbx
 1007ada:	and    %rbx,%r11
 1007add:	cmp    $0x0,%r11
 1007ae1:	jl     1007b47 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe07>
 1007ae3:	mov    %rdx,-0x60(%rbp)
 1007ae7:	mov    %rax,-0x60(%rbp)
 1007aeb:	mov    (%r8),%rcx
 1007aee:	cmp    %rcx,%rax
 1007af1:	jne    1007b40 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe00>
 1007af3:	movq   $0x0,-0x60(%rbp)
 1007afb:	mov    %r9,-0x60(%rbp)
 1007aff:	movq   $0x1,-0x58(%rbp)
 1007b07:	movabs $0x7ffffffffffffffe,%rcx
 1007b11:	cmp    %rcx,%r9
 1007b14:	jg     1007b23 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xde3>
 1007b16:	add    $0x1,%r9
 1007b1a:	mov    %r9,-0x60(%rbp)
 1007b1e:	jmp    1007a70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd30>
 1007b23:	mov    %r9,%rsi
 1007b26:	mov    $0x40,%r8d
 1007b2c:	mov    $0x1,%ecx
 1007b31:	mov    %rsi,%rdx
 1007b34:	mov    $0x0,%esi
 1007b39:	call   1008710 <myl_qbe_fail_overflow_op>
 1007b3e:	ud2
 1007b40:	call   1008690 <myl_qbe_fail_iteration>
 1007b45:	ud2
 1007b47:	mov    %r10,%rdx
 1007b4a:	mov    $0x40,%r8d
 1007b50:	mov    $0x0,%esi
 1007b55:	call   1008710 <myl_qbe_fail_overflow_op>
 1007b5a:	ud2
 1007b5c:	mov    %rcx,%rdx
 1007b5f:	mov    %r9,%rsi
 1007b62:	call   10086a0 <myl_qbe_fail_normalized_index_bounds>
 1007b67:	ud2
 1007b69:	call   1008690 <myl_qbe_fail_iteration>
 1007b6e:	ud2
 1007b70:	mov    0x20(%r8),%r9
 1007b74:	mov    %rsi,%rax
 1007b77:	mov    %r12,%rsi
 1007b7a:	mov    $0x0,%edx
 1007b7f:	mov    $0x0,%ecx
 1007b84:	cs nopw 0x0(%rax,%rax,1)
 1007b8e:	xchg   %ax,%ax
 1007b90:	mov    %rcx,-0x60(%rbp)
 1007b94:	mov    %rax,-0x58(%rbp)
 1007b98:	cmp    %rax,%rcx
 1007b9b:	setl   %r10b
 1007b9f:	movzbq %r10b,%r10
 1007ba3:	mov    %r10,-0x60(%rbp)
 1007ba7:	jge    1007c22 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee2>
 1007ba9:	mov    %rax,-0x60(%rbp)
 1007bad:	movq   $0x0,-0x60(%rbp)
 1007bb5:	mov    %rcx,-0x60(%rbp)
 1007bb9:	mov    (%r9,%rcx,8),%r11
 1007bbd:	mov    %r11,-0x60(%rbp)
 1007bc1:	mov    %rdx,-0x60(%rbp)
 1007bc5:	mov    %r11,-0x58(%rbp)
 1007bc9:	mov    %rdx,%r10
 1007bcc:	add    %r11,%rdx
 1007bcf:	mov    %r10,%rbx
 1007bd2:	xor    %rdx,%rbx
 1007bd5:	mov    %r11,%r12
 1007bd8:	xor    %rdx,%r12
 1007bdb:	and    %r12,%rbx
 1007bde:	cmp    $0x0,%rbx
 1007be2:	jl     1007c0a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xeca>
 1007be4:	mov    %rdx,-0x60(%rbp)
 1007be8:	mov    %rax,-0x60(%rbp)
 1007bec:	movq   $0x0,-0x60(%rbp)
 1007bf4:	mov    %rcx,-0x60(%rbp)
 1007bf8:	movq   $0x1,-0x58(%rbp)
 1007c00:	add    $0x1,%rcx
 1007c04:	mov    %rcx,-0x60(%rbp)
 1007c08:	jmp    1007b90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe50>
 1007c0a:	mov    %r10,%rdx
 1007c0d:	mov    %r11,%rcx
 1007c10:	mov    $0x40,%r8d
 1007c16:	mov    $0x0,%esi
 1007c1b:	call   1008710 <myl_qbe_fail_overflow_op>
 1007c20:	ud2
 1007c22:	mov    %rsi,%r12
 1007c25:	mov    %r12,-0x60(%rbp)
 1007c29:	mov    %rdx,-0x58(%rbp)
 1007c2d:	mov    %r12,%rsi
 1007c30:	mov    %rdi,%rbx
 1007c33:	call   100a550 <myl_qbe_stream_begin>
 1007c38:	mov    %r12,%rdx
 1007c3b:	mov    %rbx,%rdi
 1007c3e:	mov    %rax,%rsi
 1007c41:	mov    %rdx,%r13
 1007c44:	mov    $0x0,%edx
 1007c49:	mov    %rsi,%r12
 1007c4c:	lea    -0x58(%rbp),%rsi
 1007c50:	mov    %rdi,%rbx
 1007c53:	mov    %r12,%rdi
 1007c56:	call   1007ce0 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1007c5b:	mov    %r12,%rsi
 1007c5e:	mov    %rbx,%rdi
 1007c61:	mov    %rsi,%r12
 1007c64:	mov    $0xa,%esi
 1007c69:	mov    %rdi,%rbx
 1007c6c:	mov    %r12,%rdi
 1007c6f:	call   100a4a0 <myl_qbe_print_byte>
 1007c74:	mov    %r13,%rdx
 1007c77:	mov    %r12,%rsi
 1007c7a:	mov    %rbx,%rdi
 1007c7d:	mov    %rdi,%rbx
 1007c80:	call   100a590 <myl_qbe_stream_finish>
 1007c85:	mov    %rbx,%rdi
 1007c88:	movq   $0x0,-0x60(%rbp)
 1007c90:	movq   $0x0,-0x60(%rbp)
 1007c98:	lea    -0x1c0(%rbp),%rsi
 1007c9f:	mov    %rdi,%rbx
 1007ca2:	call   10081c0 <myl_qbe_rc_frame_cleanup>
 1007ca7:	mov    %rbx,%rdi
 1007caa:	lea    -0x1c0(%rbp),%rsi
 1007cb1:	call   1008030 <myl_qbe_rc_frame_leave>
 1007cb6:	mov    $0x0,%eax
 1007cbb:	pop    %r15
 1007cbd:	pop    %r14
 1007cbf:	pop    %r13
 1007cc1:	pop    %r12
 1007cc3:	pop    %rbx
 1007cc4:	leave
 1007cc5:	ret
 1007cc6:	mov    $0x140,%edx
 1007ccb:	call   1008850 <myl_qbe_fail_cast>
 1007cd0:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
