#include <stdint.h>
#include <stdio.h>
__attribute__((noinline)) uint64_t sum(const uint32_t *a) {
    uint64_t s=0; for(unsigned i=0;i<4096;i++) s+=a[i]; return s;
}
int main(void) {
    uint32_t a[4096]; for(unsigned i=0;i<4096;i++) a[i]=i%97;
    uint64_t s=0; for(unsigned r=0;r<128;r++) { __asm__ volatile("" ::: "memory"); s+=sum(a); }
    printf("%llu\n", (unsigned long long)s); return 0;
}
