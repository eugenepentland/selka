//! Whole-function private-cell and scalar-use facts for a QBE-only dispatch pass.
const std = @import("std");
const il = @import("qbe_build_llvm_il.zig");
const Allocator = std.mem.Allocator;
const Instruction = il.Instruction;

/// A bounded analysis can decline without changing its original input.
pub const Error = error{ OutOfMemory, Declined };
const Use = struct { instruction: *const Instruction, argument: ?usize };
const Temp = struct {
    definitions: usize = 0,
    definition: ?*const Instruction = null,
    block: usize = 0,
    uses: std.ArrayList(Use) = .empty,
    cell: ?bool = null,
};

/// Definition/use indexes, allocated in the caller's per-unit scratch arena.
pub const Facts = struct {
    arena: Allocator,
    temporaries: std.StringHashMapUnmanaged(Temp) = .empty,

    /// Index every reference, including phi operands and indirect call targets.
    pub fn collect(arena: Allocator, function: *const il.Function) Error!Facts {
        var self: Facts = .{ .arena = arena };
        for (function.parameters) |parameter| try self.define(parameter.name, null, 0);
        var count: usize = 0;
        for (function.blocks.items, 0..) |block, index| for (block.instructions.items) |instruction| {
            count += 1;
            if (count > 32768) return error.Declined;
            if (instruction.dest) |name| try self.define(name, instruction, index);
            for (instruction.args, 0..) |argument, at| {
                if (argument == .call) return error.Declined;
                if (argument.tempName()) |name| try self.use(name, instruction, at);
            }
            switch (instruction.extra) {
                .target => |target| if (target == .indirect) try self.use(target.indirect, instruction, null),
                .phi => |inputs| for (inputs) |input| {
                    if (input.value == .call) return error.Declined;
                    if (input.value.tempName()) |name| try self.use(name, instruction, null);
                },
                else => {},
            }
        };
        return self;
    }

    fn define(self: *Facts, name: []const u8, instruction: ?*const Instruction, block: usize) Error!void {
        const entry = try self.temporaries.getOrPut(self.arena, name);
        if (!entry.found_existing) entry.value_ptr.* = .{};
        entry.value_ptr.definitions += 1;
        entry.value_ptr.definition = instruction;
        entry.value_ptr.block = block;
    }

    fn use(self: *Facts, name: []const u8, instruction: *const Instruction, index: ?usize) Error!void {
        const entry = try self.temporaries.getOrPut(self.arena, name);
        if (!entry.found_existing) entry.value_ptr.* = .{};
        try entry.value_ptr.uses.append(self.arena, .{ .instruction = instruction, .argument = index });
    }

    /// Fresh comparison temporaries may not be read by handlers or phi inputs.
    pub fn single(self: *const Facts, name: []const u8) bool {
        const temp = self.temporaries.get(name) orelse return false;
        return temp.definitions == 1 and temp.uses.items.len == 1;
    }

    /// A unique entry alloc8 of eight bytes whose address stays in the frame.
    /// At most eight copy aliases are followed; each alias has one readonly use.
    pub fn privateCell(self: *Facts, name: []const u8) bool {
        const temp = self.temporaries.getPtr(name) orelse return false;
        if (temp.cell) |answer| return answer;
        temp.cell = false;
        if (temp.definitions != 1 or temp.block != 0) return false;
        const definition = temp.definition orelse return false;
        if (definition.opcode != .alloc8 or !letter(definition, "l") or definition.args.len != 1) return false;
        if (integer(definition.args[0]) != 8) return false;
        var aliases: usize = 8;
        const answer = self.addressUses(name, true, &aliases);
        temp.cell = answer;
        return answer;
    }

    fn addressUses(self: *const Facts, name: []const u8, direct: bool, aliases: *usize) bool {
        const temp = self.temporaries.get(name) orelse return false;
        for (temp.uses.items) |used| {
            const at = used.argument orelse return false;
            const instruction = used.instruction;
            if (instruction.opcode.isLoad() and at == 0 and instruction.args.len == 1) continue;
            if (direct) {
                if (instruction.opcode == .storel and at == 1 and instruction.args.len == 2 and instruction.dest == null) continue;
            }
            if (instruction.opcode != .copy or at != 0 or instruction.args.len != 1) return false;
            if (!letter(instruction, "l")) return false;
            const alias = instruction.dest orelse return false;
            if (aliases.* == 0 or !self.single(alias)) return false;
            aliases.* -= 1;
            if (!self.addressUses(alias, false, aliases)) return false;
        }
        return true;
    }
};

/// Exactly the requested base type, with no inferred width conversion.
pub fn letter(instruction: *const Instruction, expected: []const u8) bool {
    const actual = instruction.qbe_type orelse return false;
    return std.mem.eql(u8, actual, expected);
}

/// Signed full-width constants; other representations conservatively decline.
pub fn integer(operand: il.Operand) ?i64 {
    if (operand != .constant) return null;
    return std.fmt.parseInt(i64, operand.constant.text, 0) catch null;
}

/// An exact direct temporary operand.
pub fn isTemp(operand: il.Operand, name: []const u8) bool {
    const actual = operand.tempName() orelse return false;
    return std.mem.eql(u8, actual, name);
}
