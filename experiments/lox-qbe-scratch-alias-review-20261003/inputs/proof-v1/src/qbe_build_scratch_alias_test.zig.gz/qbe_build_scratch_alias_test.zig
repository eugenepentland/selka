//! Address-copy refusals and actual QBE load-width/value equivalence.
const std = @import("std");
const pass = @import("qbe_build_scratch_alias.zig");
const fs = @import("qbe_build_io.zig");
const t = std.testing;
const fixture = "export function l $probe(l %input, l %out) {\n@start\n" ++
    " %cell =l alloc8 8\n storel 0, %cell\n %byte_address =l copy %cell\n" ++
    " %word_address =l copy %cell\n %signed_address =l copy %cell\n %float_address =l copy %cell\n" ++
    " storel %input, %cell\n %byte =l loadub %byte_address # retain narrow read\n" ++
    " %word =l loadl %word_address\n %signed =l loadsb %signed_address\n" ++
    " %float =d loadd %float_address\n %bits =l cast %float\n" ++
    " storel %byte, %out\n %o1 =l add %out, 8\n storel %word, %o1\n" ++
    " %o2 =l add %out, 16\n storel %signed, %o2\n %o3 =l add %out, 24\n storel %bits, %o3\n ret %word\n}\n";

// spec: QBE-SCRATCH-ALIAS-1
test "QBE-SCRATCH-ALIAS-1 direct aliases retain load widths position comments and later stores" {
    var arena: std.heap.ArenaAllocator = .init(t.allocator);
    defer arena.deinit();
    const output = try pass.transform(arena.allocator(), fixture);
    try t.expect(output.ptr != fixture.ptr);
    try t.expect(std.mem.indexOf(u8, output, "=l copy %cell") == null);
    try t.expect(std.mem.indexOf(u8, output, "storel %input, %cell\n %byte =l loadub %cell # retain narrow read") != null);
    try t.expect(std.mem.indexOf(u8, output, "%word =l loadl %cell") != null);
    try t.expect(std.mem.indexOf(u8, output, "%signed =l loadsb %cell") != null);
    try t.expect(std.mem.indexOf(u8, output, "%float =d loadd %cell") != null);
    try t.expectEqualStrings(output, try pass.transform(arena.allocator(), output));
}

const Replacement = struct { before: []const u8, after: []const u8 };
fn refusals(replacements: []const Replacement) !void {
    var arena: std.heap.ArenaAllocator = .init(t.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    for (replacements) |replacement| {
        try t.expect(std.mem.indexOf(u8, fixture, replacement.before) != null);
        const source = try std.mem.replaceOwned(u8, a, fixture, replacement.before, replacement.after);
        const output = try pass.transform(a, source);
        try t.expectEqualStrings(source, output);
        try t.expectEqual(source.ptr, output.ptr);
    }
}

// spec-case: QBE-SCRATCH-ALIAS-1
test "QBE-SCRATCH-ALIAS-1 escaped written arithmetic and multiple-use addresses remain original" {
    try refusals(&.{
        .{ .before = " storel %input, %cell", .after = " call $observe(l %cell)\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " storel %cell, %out\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " %escaped =l add %cell, 0\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " storel 0, %byte_address\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " call $observe(l %byte_address)\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " %extra =l loadl %byte_address\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " %extra =l call %byte_address()\n storel %input, %cell" },
    });
}

// spec-case: QBE-SCRATCH-ALIAS-1
test "QBE-SCRATCH-ALIAS-1 non-entry non-unique and unsupported cells retain original bytes" {
    try refusals(&.{
        .{ .before = "%cell =l alloc8 8", .after = "%cell =l alloc8 16" },
        .{ .before = "%cell =l alloc8 8", .after = "%cell =l copy %out" },
        .{ .before = "%cell =l alloc8 8", .after = "%cell =l alloc8 8\n %cell =l alloc8 8" },
        .{ .before = "%cell =l alloc8 8", .after = "jmp @next\n@next\n %cell =l alloc8 8" },
        .{ .before = " storel 0, %cell", .after = " storeb 0, %cell" },
        .{ .before = " storel %input, %cell", .after = " malformed operation\n storel %input, %cell" },
    });
}

// spec-case: QBE-SCRATCH-ALIAS-1
test "QBE-SCRATCH-ALIAS-1 ambiguous pointer definitions and analysis limits refuse" {
    try refusals(&.{
        .{ .before = " storel %input, %cell", .after = " %byte_address =l copy %cell\n storel %input, %cell" },
        .{ .before = " storel %input, %cell", .after = " %byte_address =l phi @start %cell\n storel %input, %cell" },
    });
    const oversized = try t.allocator.alloc(u8, 2 * 1024 * 1024 + 1);
    defer t.allocator.free(oversized);
    @memset(oversized, ' ');
    try t.expectEqual(oversized.ptr, (try pass.transform(t.allocator, oversized)).ptr);
}

fn nativeOracle() !void {
    var environment: std.process.Environ.Map = .init(t.allocator);
    defer environment.deinit();
    var context = try fs.Context.init(t.allocator, t.io, &environment);
    defer context.deinit();
    const a = context.allocator;
    var directory = t.tmpDir(.{});
    defer directory.cleanup();
    const root = try directory.dir.realPathFileAlloc(t.io, ".", a);
    const candidate = try pass.transform(a, fixture);
    try t.expect(std.mem.indexOf(u8, candidate, "QBE-SCRATCH-ALIAS-1") != null);
    const source = try std.fs.path.join(a, &.{ root, "probe.ssa" });
    const assembly = try std.fs.path.join(a, &.{ root, "probe.s" });
    const harness = try std.fs.path.join(a, &.{ root, "probe.c" });
    const binary = try std.fs.path.join(a, &.{ root, "probe" });
    const control = try std.mem.replaceOwned(u8, a, fixture, "$probe(", "$control(");
    try context.write(source, try std.mem.concat(a, u8, &.{ control, candidate }));
    try context.write(harness, "#include <stdint.h>\n#include <assert.h>\nextern uint64_t control(uint64_t,uint64_t*),probe(uint64_t,uint64_t*);\n" ++
        "int main(void){uint64_t v[]={0,1,127,128,255,256,257,UINT64_MAX,UINT64_C(0x8000000000000000),UINT64_C(0x7fffffffffffffff)," ++
        "UINT64_C(0x3ff0000000000000),UINT64_C(0x7ff80000000000ff),UINT64_C(0xfff0000000000000)};\n" ++
        "for(unsigned i=0;i<sizeof(v)/sizeof(v[0]);i++){uint64_t c[4]={9,9,9,9},d[4]={8,8,8,8};" ++
        "assert(control(v[i],c)==v[i]);assert(probe(v[i],d)==v[i]);unsigned char b=*(unsigned char*)&v[i];" ++
        "uint64_t s=(uint64_t)(int64_t)(signed char)b;assert(c[0]==b);assert(d[0]==b);assert(c[1]==v[i]);assert(d[1]==v[i]);" ++
        "assert(c[2]==s);assert(d[2]==s);assert(c[3]==v[i]);assert(d[3]==v[i]);}return 0;}\n");
    const qbe = t.environ.getPosix("MYLANG_QBE") orelse return error.ToolNotFound;
    const zig = t.environ.getPosix("MYLANG_ZIG") orelse return error.ToolNotFound;
    try context.command(&.{ qbe, "-o", assembly, source }, null);
    try context.command(&.{ zig, "cc", "-O2", "-fsanitize=undefined", harness, assembly, "-o", binary }, null);
    try context.command(&.{binary}, null);
}

// spec-case: QBE-SCRATCH-ALIAS-1
test "QBE-SCRATCH-ALIAS-1 actual native narrow signed full and float bit reads agree" {
    try nativeOracle();
}
