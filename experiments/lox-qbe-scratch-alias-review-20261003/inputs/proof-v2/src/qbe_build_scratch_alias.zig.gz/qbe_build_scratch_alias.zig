//! QBE-only canonical addresses for single-use private stack-cell aliases.
//! Every load stays at its original position, with its original width.
const std = @import("std");
const il = @import("qbe_build_llvm_il.zig");
const cells = @import("qbe_build_scratch_cells.zig");
const Allocator = std.mem.Allocator;
const Error = cells.Error;
const Patch = struct { copy: *const il.Instruction, load: *const il.Instruction, alias: []const u8, cell: []const u8 };

/// Unsupported units retain their bytes. An alias must have one definition
/// and one load use, and its uniquely allocated cell address cannot escape.
pub fn transform(allocator: Allocator, source: []const u8) error{OutOfMemory}![]const u8 {
    if (source.len > 2 * 1024 * 1024 or std.mem.indexOf(u8, source, "=l copy ") == null) return source;
    var arena: std.heap.ArenaAllocator = .init(allocator);
    defer arena.deinit();
    return transformed(allocator, arena.allocator(), source) catch |err| switch (err) {
        error.Declined => source,
        error.OutOfMemory => error.OutOfMemory,
    };
}

fn transformed(output: Allocator, arena: Allocator, source: []const u8) Error![]const u8 {
    var diagnostic: il.Diagnostic = .{};
    const unit = il.parse(arena, source, &diagnostic) catch |err| switch (err) {
        error.TranslationFailed => return error.Declined,
        error.OutOfMemory => return error.OutOfMemory,
    };
    var facts = try cells.Facts.collect(arena, &unit.function);
    var patches: std.ArrayList(Patch) = .empty;
    for (unit.function.blocks.items) |block| for (block.instructions.items) |instruction| {
        if (admit(&facts, instruction)) |patch| {
            if (patches.items.len == 256) return error.Declined;
            try patches.append(arena, patch);
        }
    };
    if (patches.items.len == 0) return source;
    return render(output, source, patches.items);
}

fn admit(facts: *cells.Facts, copy: *const il.Instruction) ?Patch {
    if (copy.opcode != .copy or !cells.letter(copy, "l") or copy.args.len != 1) return null;
    const cell = copy.args[0].tempName() orelse return null;
    const alias = copy.dest orelse return null;
    if (!facts.single(alias) or !facts.privateCell(cell)) return null;
    const temp = facts.temporaries.get(alias) orelse return null;
    const use = temp.uses.items[0];
    const load = use.instruction;
    if (use.argument != 0 or !load.opcode.isLoad() or load.args.len != 1) return null;
    if (!cells.isTemp(load.args[0], alias)) return null;
    return .{ .copy = copy, .load = load, .alias = alias, .cell = cell };
}

fn render(allocator: Allocator, source: []const u8, patches: []const Patch) Error![]const u8 {
    var result: std.Io.Writer.Allocating = .init(allocator);
    errdefer result.deinit();
    var lines = std.mem.splitScalar(u8, source, '\n');
    var number: usize = 0;
    while (lines.next()) |line| {
        number += 1;
        try renderLine(&result.writer, line, number, patches);
        if (lines.index != null) result.writer.writeByte('\n') catch return error.OutOfMemory;
    }
    return result.toOwnedSlice();
}

fn renderLine(writer: *std.Io.Writer, line: []const u8, number: usize, patches: []const Patch) Error!void {
    for (patches) |patch| {
        const comment = std.mem.indexOfScalar(u8, line, '#') orelse line.len;
        if (number == patch.copy.line) {
            writer.print(" # QBE-SCRATCH-ALIAS-1 eliminated private address copy {s}", .{line[comment..]}) catch return error.OutOfMemory;
            return;
        }
        if (number == patch.load.line) {
            // The last '%' before the comment starts the sole load address.
            const at = std.mem.lastIndexOfScalar(u8, line[0..comment], '%') orelse return error.Declined;
            const end = at + 1 + patch.alias.len;
            if (end > comment or !std.mem.eql(u8, line[at + 1 .. end], patch.alias)) return error.Declined;
            writer.print("{s}%{s}{s}", .{ line[0..at], patch.cell, line[end..] }) catch return error.OutOfMemory;
            return;
        }
    }
    writer.writeAll(line) catch return error.OutOfMemory;
}
