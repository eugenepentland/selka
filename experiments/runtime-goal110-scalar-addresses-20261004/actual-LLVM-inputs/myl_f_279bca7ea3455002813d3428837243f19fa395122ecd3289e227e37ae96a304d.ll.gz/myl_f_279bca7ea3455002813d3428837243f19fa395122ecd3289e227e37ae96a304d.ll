target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_279bca7ea3455002813d3428837243f19fa395122ecd3289e227e37ae96a304d(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v26 = load i64, ptr %slot1, align 8
  %op27 = add i64 %v26, 32
  store i64 %op27, ptr %slot3, align 8
  %mem28 = alloca i8, i64 8, align 8
  %mem30 = alloca i8, i64 8, align 8
  %mem32 = alloca i8, i64 8, align 8
  %v34 = load i64, ptr %slot2, align 8
  store i64 %v34, ptr %mem28, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld35 = load i64, ptr %mem28, align 8, !alias.scope !3, !noalias !4
  store i64 %ld35, ptr %slot7, align 8
  %v36 = load i64, ptr %slot7, align 8
  store i64 %v36, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  store i64 5, ptr %mem32, align 8, !alias.scope !3, !noalias !4
  %ld37 = load i64, ptr %mem32, align 8, !alias.scope !3, !noalias !4
  store i64 %ld37, ptr %slot8, align 8
  %ld38 = load i64, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  store i64 %ld38, ptr %slot9, align 8
  %v39 = load i64, ptr %slot9, align 8
  %v40 = load i64, ptr %slot8, align 8
  %ovpair42 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v39, i64 %v40)
  %op41 = extractvalue { i64, i1 } %ovpair42, 0
  %ov43 = extractvalue { i64, i1 } %ovpair42, 1
  store i64 %op41, ptr %slot10, align 8
  %v49 = load i64, ptr %slot9, align 8
  %wide44 = zext i64 %v49 to i128
  %v50 = load i64, ptr %slot8, align 8
  %wide45 = zext i64 %v50 to i128
  %product46 = mul i128 %wide44, %wide45
  %high47 = lshr i128 %product46, 64
  %op48 = trunc i128 %high47 to i64
  store i64 %op48, ptr %slot11, align 8
  %v51 = load i64, ptr %slot9, align 8
  %cmp52 = icmp slt i64 %v51, 0
  %cv53 = zext i1 %cmp52 to i64
  store i64 %cv53, ptr %slot12, align 8
  %v54 = load i64, ptr %slot8, align 8
  %cmp55 = icmp slt i64 %v54, 0
  %cv56 = zext i1 %cmp55 to i64
  store i64 %cv56, ptr %slot13, align 8
  %v57 = load i64, ptr %slot12, align 8
  %neg58 = sub i64 0, %v57
  store i64 %neg58, ptr %slot14, align 8
  %v59 = load i64, ptr %slot13, align 8
  %neg60 = sub i64 0, %v59
  store i64 %neg60, ptr %slot15, align 8
  %v61 = load i64, ptr %slot8, align 8
  %v62 = load i64, ptr %slot14, align 8
  %op63 = and i64 %v61, %v62
  store i64 %op63, ptr %slot16, align 8
  %v64 = load i64, ptr %slot9, align 8
  %v65 = load i64, ptr %slot15, align 8
  %op66 = and i64 %v64, %v65
  store i64 %op66, ptr %slot17, align 8
  %v67 = load i64, ptr %slot11, align 8
  %v68 = load i64, ptr %slot16, align 8
  %op69 = sub i64 %v67, %v68
  store i64 %op69, ptr %slot18, align 8
  %v70 = load i64, ptr %slot18, align 8
  %v71 = load i64, ptr %slot17, align 8
  %op72 = sub i64 %v70, %v71
  store i64 %op72, ptr %slot18, align 8
  %v73 = load i64, ptr %slot10, align 8
  %op74 = ashr i64 %v73, 63
  store i64 %op74, ptr %slot19, align 8
  %cv75 = zext i1 %ov43 to i64
  store i64 %cv75, ptr %slot20, align 8
  %v76 = load i64, ptr %slot20, align 8
  %cond77 = icmp ne i64 %v76, 0
  br i1 %cond77, label %bb_overflow3, label %bb_checked3
bb_overflow3:
  %v78 = load i64, ptr %slot1, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %v80 = load i64, ptr %slot9, align 8
  %v81 = load i64, ptr %slot8, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p79, i64 2, i64 %v80, i64 %v81, i64 64) nomerge, !dbg !110
  unreachable
bb_checked3:
  %v82 = load i64, ptr %slot10, align 8
  store i64 %v82, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  store i64 11, ptr %mem32, align 8, !alias.scope !3, !noalias !4
  %ld83 = load i64, ptr %mem32, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot21, align 8
  %ld84 = load i64, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot22, align 8
  %v85 = load i64, ptr %slot22, align 8
  %v86 = load i64, ptr %slot21, align 8
  %op87 = add i64 %v85, %v86
  store i64 %op87, ptr %slot23, align 8
  %v88 = load i64, ptr %slot22, align 8
  %cmp89 = icmp sgt i64 %v88, 9223372036854775796
  %cv90 = zext i1 %cmp89 to i64
  store i64 %cv90, ptr %slot24, align 8
  %v91 = load i64, ptr %slot24, align 8
  %cond92 = icmp ne i64 %v91, 0
  br i1 %cond92, label %bb_overflow16, label %bb_checked16
bb_overflow16:
  %v93 = load i64, ptr %slot1, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %v95 = load i64, ptr %slot22, align 8
  %v96 = load i64, ptr %slot21, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p94, i64 0, i64 %v95, i64 %v96, i64 64) nomerge, !dbg !112
  unreachable
bb_checked16:
  %v97 = load i64, ptr %slot23, align 8
  store i64 %v97, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  %ld98 = load i64, ptr %mem30, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot25, align 8
  %v99 = load i64, ptr %slot25, align 8
  ret i64 %v99
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_279bca7ea3455002813d3428837243f19fa395122ecd3289e227e37ae96a304d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_279bca7ea3455002813d3428837243f19fa395122ecd3289e227e37ae96a304d", linkageName: "myl_f_279bca7ea3455002813d3428837243f19fa395122ecd3289e227e37ae96a304d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10144782891971816676, i64 0, !"myl_f_279bca7ea3455002813d3428837243f19fa395122ecd3289e227e37ae96a304d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
