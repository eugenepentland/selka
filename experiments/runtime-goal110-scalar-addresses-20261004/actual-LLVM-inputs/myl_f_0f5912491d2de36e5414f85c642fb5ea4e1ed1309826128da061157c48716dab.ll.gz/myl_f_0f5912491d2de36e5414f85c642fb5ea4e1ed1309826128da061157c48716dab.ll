target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_0f5912491d2de36e5414f85c642fb5ea4e1ed1309826128da061157c48716dab(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v48 = load i64, ptr %slot1, align 8
  %op49 = add i64 %v48, 32
  store i64 %op49, ptr %slot4, align 8
  %mem50 = alloca i8, i64 16, align 8
  %ptr51 = ptrtoint ptr %mem50 to i64
  store i64 %ptr51, ptr %slot5, align 8
  %mem52 = alloca i8, i64 8, align 8
  %mem54 = alloca i8, i64 8, align 8
  %mem56 = alloca i8, i64 8, align 8
  %mem58 = alloca i8, i64 8, align 8
  %mem60 = alloca i8, i64 16, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot10, align 8
  %mem62 = alloca i8, i64 16, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot11, align 8
  %v64 = load i64, ptr %slot2, align 8
  store i64 %v64, ptr %mem52, align 8, !alias.scope !3, !noalias !4
  %v65 = load i64, ptr %slot3, align 8
  store i64 %v65, ptr %mem54, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld66 = load i64, ptr %mem52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld66, ptr %slot12, align 8
  %v67 = load i64, ptr %slot12, align 8
  store i64 %v67, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 4, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld68 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot13, align 8
  %ld69 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot13, align 8
  %cmp71 = icmp eq i64 %v70, 0
  %cv72 = zext i1 %cmp71 to i64
  store i64 %cv72, ptr %slot15, align 8
  %v73 = load i64, ptr %slot15, align 8
  %cond74 = icmp ne i64 %v73, 0
  br i1 %cond74, label %bb_division3, label %bb_nonzero3
bb_division3:
  %v75 = load i64, ptr %slot1, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %v77 = load i64, ptr %slot14, align 8
  %v78 = load i64, ptr %slot13, align 8
  call void @myl_qbe_fail_division(ptr %p76, i64 6, i64 %v77, i64 %v78) nomerge, !dbg !110
  unreachable
bb_nonzero3:
  %v79 = load i64, ptr %slot14, align 8
  %cmp80 = icmp eq i64 %v79, 9223372036854775808
  %cv81 = zext i1 %cmp80 to i64
  store i64 %cv81, ptr %slot16, align 8
  %v82 = load i64, ptr %slot13, align 8
  %cmp83 = icmp eq i64 %v82, 18446744073709551615
  %cv84 = zext i1 %cmp83 to i64
  store i64 %cv84, ptr %slot17, align 8
  %v85 = load i64, ptr %slot16, align 8
  %v86 = load i64, ptr %slot17, align 8
  %op87 = and i64 %v85, %v86
  store i64 %op87, ptr %slot18, align 8
  %v88 = load i64, ptr %slot18, align 8
  %neg89 = sub i64 0, %v88
  store i64 %neg89, ptr %slot19, align 8
  %v90 = load i64, ptr %slot13, align 8
  %op91 = xor i64 %v90, 1
  store i64 %op91, ptr %slot20, align 8
  %v92 = load i64, ptr %slot20, align 8
  %v93 = load i64, ptr %slot19, align 8
  %op94 = and i64 %v92, %v93
  store i64 %op94, ptr %slot20, align 8
  %v95 = load i64, ptr %slot13, align 8
  %v96 = load i64, ptr %slot20, align 8
  %op97 = xor i64 %v95, %v96
  store i64 %op97, ptr %slot21, align 8
  %v98 = load i64, ptr %slot14, align 8
  %v99 = load i64, ptr %slot21, align 8
  %op100 = srem i64 %v98, %v99
  store i64 %op100, ptr %slot22, align 8
  %v101 = load i64, ptr %slot22, align 8
  %cmp102 = icmp ne i64 %v101, 0
  %cv103 = zext i1 %cmp102 to i64
  store i64 %cv103, ptr %slot23, align 8
  %v104 = load i64, ptr %slot22, align 8
  %v105 = load i64, ptr %slot21, align 8
  %op106 = xor i64 %v104, %v105
  store i64 %op106, ptr %slot24, align 8
  %v107 = load i64, ptr %slot24, align 8
  %cmp108 = icmp slt i64 %v107, 0
  %cv109 = zext i1 %cmp108 to i64
  store i64 %cv109, ptr %slot25, align 8
  %v110 = load i64, ptr %slot23, align 8
  %v111 = load i64, ptr %slot25, align 8
  %op112 = and i64 %v110, %v111
  store i64 %op112, ptr %slot26, align 8
  %v113 = load i64, ptr %slot26, align 8
  %neg114 = sub i64 0, %v113
  store i64 %neg114, ptr %slot27, align 8
  %v115 = load i64, ptr %slot21, align 8
  %v116 = load i64, ptr %slot27, align 8
  %op117 = and i64 %v115, %v116
  store i64 %op117, ptr %slot28, align 8
  %v118 = load i64, ptr %slot22, align 8
  %v119 = load i64, ptr %slot28, align 8
  %op120 = add i64 %v118, %v119
  store i64 %op120, ptr %slot22, align 8
  %v121 = load i64, ptr %slot22, align 8
  store i64 %v121, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld122 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot29, align 8
  %ld123 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot30, align 8
  %v124 = load i64, ptr %slot30, align 8
  %v125 = load i64, ptr %slot29, align 8
  %cmp126 = icmp eq i64 %v124, %v125
  %cv127 = zext i1 %cmp126 to i64
  store i64 %cv127, ptr %slot31, align 8
  %v128 = load i64, ptr %slot31, align 8
  store i64 %v128, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  %ld129 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot32, align 8
  %v130 = load i64, ptr %slot32, align 8
  %cond131 = icmp ne i64 %v130, 0
  br i1 %cond131, label %bb_next21, label %bb_i8
bb_next21:
  %v132 = load i64, ptr %slot10, align 8
  store i64 %v132, ptr %slot33, align 8
  %v133 = load i64, ptr %slot33, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i32 0, ptr %p134, align 4, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot33, align 8
  store i64 %v135, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  %ld136 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot34, align 8
  %v137 = load i64, ptr %slot34, align 8
  %p138 = inttoptr i64 %v137 to ptr
  %ret139 = load { i64, i64 }, ptr %p138, align 8
  ret { i64, i64 } %ret139
bb_i8:
  %ld140 = load i64, ptr %mem52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot35, align 8
  %v141 = load i64, ptr %slot35, align 8
  store i64 %v141, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  %ld142 = load i64, ptr %mem54, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot36, align 8
  %v143 = load i64, ptr %slot36, align 8
  store i64 %v143, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld144 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld144, ptr %slot37, align 8
  %ld145 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot38, align 8
  %v146 = load i64, ptr %slot38, align 8
  %v147 = load i64, ptr %slot37, align 8
  %ovpair149 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v146, i64 %v147)
  %op148 = extractvalue { i64, i1 } %ovpair149, 0
  %ov150 = extractvalue { i64, i1 } %ovpair149, 1
  store i64 %op148, ptr %slot39, align 8
  %v151 = load i64, ptr %slot38, align 8
  %v152 = load i64, ptr %slot39, align 8
  %op153 = xor i64 %v151, %v152
  store i64 %op153, ptr %slot40, align 8
  %v154 = load i64, ptr %slot37, align 8
  %v155 = load i64, ptr %slot39, align 8
  %op156 = xor i64 %v154, %v155
  store i64 %op156, ptr %slot41, align 8
  %v157 = load i64, ptr %slot40, align 8
  %v158 = load i64, ptr %slot41, align 8
  %op159 = and i64 %v157, %v158
  store i64 %op159, ptr %slot42, align 8
  %cv160 = zext i1 %ov150 to i64
  store i64 %cv160, ptr %slot43, align 8
  %v161 = load i64, ptr %slot43, align 8
  %cond162 = icmp ne i64 %v161, 0
  br i1 %cond162, label %bb_overflow27, label %bb_checked27
bb_overflow27:
  %v163 = load i64, ptr %slot1, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %v165 = load i64, ptr %slot38, align 8
  %v166 = load i64, ptr %slot37, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p164, i64 0, i64 %v165, i64 %v166, i64 64) nomerge, !dbg !112
  unreachable
bb_checked27:
  %v167 = load i64, ptr %slot39, align 8
  store i64 %v167, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot11, align 8
  store i64 %v168, ptr %slot44, align 8
  %v169 = load i64, ptr %slot44, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i32 1, ptr %p170, align 4, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot44, align 8
  %p173 = inttoptr i64 %v171 to ptr
  %gep174 = getelementptr i8, ptr %p173, i64 8
  %op172 = ptrtoint ptr %gep174 to i64
  store i64 %op172, ptr %slot45, align 8
  %ld175 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld175, ptr %slot46, align 8
  %v176 = load i64, ptr %slot46, align 8
  %v177 = load i64, ptr %slot45, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot44, align 8
  store i64 %v179, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  %ld180 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot47, align 8
  %v181 = load i64, ptr %slot47, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ret183 = load { i64, i64 }, ptr %p182, align 8
  ret { i64, i64 } %ret183
bb_failure:
  %v184 = load i64, ptr %slot5, align 8
  %p185 = inttoptr i64 %v184 to ptr
  call void @llvm.memset.p0.i64(ptr %p185, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v186 = load i64, ptr %slot5, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ret188 = load { i64, i64 }, ptr %p187, align 8
  ret { i64, i64 } %ret188
bb_entry_failure:
  %v189 = load i64, ptr %slot5, align 8
  %p190 = inttoptr i64 %v189 to ptr
  call void @llvm.memset.p0.i64(ptr %p190, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v191 = load i64, ptr %slot5, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ret193 = load { i64, i64 }, ptr %p192, align 8
  ret { i64, i64 } %ret193
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0f5912491d2de36e5414f85c642fb5ea4e1ed1309826128da061157c48716dab", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0f5912491d2de36e5414f85c642fb5ea4e1ed1309826128da061157c48716dab", linkageName: "myl_f_0f5912491d2de36e5414f85c642fb5ea4e1ed1309826128da061157c48716dab", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4727973461085092229, i64 0, !"myl_f_0f5912491d2de36e5414f85c642fb5ea4e1ed1309826128da061157c48716dab"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!112 = !DILocation(line: 11, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!114 = !DILocation(line: 13, column: 0, scope: !115)
