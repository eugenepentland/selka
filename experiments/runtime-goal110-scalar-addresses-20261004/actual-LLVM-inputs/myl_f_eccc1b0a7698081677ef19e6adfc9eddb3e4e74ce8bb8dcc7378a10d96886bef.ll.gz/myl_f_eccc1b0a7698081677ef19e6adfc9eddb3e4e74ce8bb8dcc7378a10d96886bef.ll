target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v50 = load i64, ptr %slot1, align 8
  %op51 = add i64 %v50, 32
  store i64 %op51, ptr %slot4, align 8
  %mem52 = alloca i8, i64 16, align 8
  %ptr53 = ptrtoint ptr %mem52 to i64
  store i64 %ptr53, ptr %slot5, align 8
  %mem54 = alloca i8, i64 8, align 8
  %mem56 = alloca i8, i64 8, align 8
  %mem58 = alloca i8, i64 8, align 8
  %mem60 = alloca i8, i64 8, align 8
  %mem62 = alloca i8, i64 16, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot10, align 8
  %mem64 = alloca i8, i64 16, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot11, align 8
  %v66 = load i64, ptr %slot2, align 8
  store i64 %v66, ptr %mem54, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot3, align 8
  store i64 %v67, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld68 = load i64, ptr %mem54, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot12, align 8
  %v69 = load i64, ptr %slot12, align 8
  store i64 %v69, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 5, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  %ld70 = load i64, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  store i64 %ld70, ptr %slot13, align 8
  %ld71 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld71, ptr %slot14, align 8
  %v72 = load i64, ptr %slot13, align 8
  %cmp73 = icmp eq i64 %v72, 0
  %cv74 = zext i1 %cmp73 to i64
  store i64 %cv74, ptr %slot15, align 8
  %v75 = load i64, ptr %slot15, align 8
  %cond76 = icmp ne i64 %v75, 0
  br i1 %cond76, label %bb_division3, label %bb_nonzero3
bb_division3:
  %v77 = load i64, ptr %slot1, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %v79 = load i64, ptr %slot14, align 8
  %v80 = load i64, ptr %slot13, align 8
  call void @myl_qbe_fail_division(ptr %p78, i64 6, i64 %v79, i64 %v80) nomerge, !dbg !110
  unreachable
bb_nonzero3:
  %v81 = load i64, ptr %slot14, align 8
  %cmp82 = icmp eq i64 %v81, 9223372036854775808
  %cv83 = zext i1 %cmp82 to i64
  store i64 %cv83, ptr %slot16, align 8
  %v84 = load i64, ptr %slot13, align 8
  %cmp85 = icmp eq i64 %v84, 18446744073709551615
  %cv86 = zext i1 %cmp85 to i64
  store i64 %cv86, ptr %slot17, align 8
  %v87 = load i64, ptr %slot16, align 8
  %v88 = load i64, ptr %slot17, align 8
  %op89 = and i64 %v87, %v88
  store i64 %op89, ptr %slot18, align 8
  %v90 = load i64, ptr %slot18, align 8
  %neg91 = sub i64 0, %v90
  store i64 %neg91, ptr %slot19, align 8
  %v92 = load i64, ptr %slot13, align 8
  %op93 = xor i64 %v92, 1
  store i64 %op93, ptr %slot20, align 8
  %v94 = load i64, ptr %slot20, align 8
  %v95 = load i64, ptr %slot19, align 8
  %op96 = and i64 %v94, %v95
  store i64 %op96, ptr %slot20, align 8
  %v97 = load i64, ptr %slot13, align 8
  %v98 = load i64, ptr %slot20, align 8
  %op99 = xor i64 %v97, %v98
  store i64 %op99, ptr %slot21, align 8
  %v100 = load i64, ptr %slot14, align 8
  %v101 = load i64, ptr %slot21, align 8
  %op102 = srem i64 %v100, %v101
  store i64 %op102, ptr %slot22, align 8
  %v103 = load i64, ptr %slot22, align 8
  %cmp104 = icmp ne i64 %v103, 0
  %cv105 = zext i1 %cmp104 to i64
  store i64 %cv105, ptr %slot23, align 8
  %v106 = load i64, ptr %slot22, align 8
  %v107 = load i64, ptr %slot21, align 8
  %op108 = xor i64 %v106, %v107
  store i64 %op108, ptr %slot24, align 8
  %v109 = load i64, ptr %slot24, align 8
  %cmp110 = icmp slt i64 %v109, 0
  %cv111 = zext i1 %cmp110 to i64
  store i64 %cv111, ptr %slot25, align 8
  %v112 = load i64, ptr %slot23, align 8
  %v113 = load i64, ptr %slot25, align 8
  %op114 = and i64 %v112, %v113
  store i64 %op114, ptr %slot26, align 8
  %v115 = load i64, ptr %slot26, align 8
  %neg116 = sub i64 0, %v115
  store i64 %neg116, ptr %slot27, align 8
  %v117 = load i64, ptr %slot21, align 8
  %v118 = load i64, ptr %slot27, align 8
  %op119 = and i64 %v117, %v118
  store i64 %op119, ptr %slot28, align 8
  %v120 = load i64, ptr %slot22, align 8
  %v121 = load i64, ptr %slot28, align 8
  %op122 = add i64 %v120, %v121
  store i64 %op122, ptr %slot22, align 8
  %v123 = load i64, ptr %slot22, align 8
  store i64 %v123, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  %ld124 = load i64, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot29, align 8
  %ld125 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot30, align 8
  %v126 = load i64, ptr %slot30, align 8
  %v127 = load i64, ptr %slot29, align 8
  %cmp128 = icmp eq i64 %v126, %v127
  %cv129 = zext i1 %cmp128 to i64
  store i64 %cv129, ptr %slot31, align 8
  %v130 = load i64, ptr %slot31, align 8
  store i64 %v130, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld131 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot32, align 8
  %v132 = load i64, ptr %slot32, align 8
  %cond133 = icmp ne i64 %v132, 0
  br i1 %cond133, label %bb_next21, label %bb_i9
bb_next21:
  store i64 1, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot10, align 8
  store i64 %v134, ptr %slot33, align 8
  %v135 = load i64, ptr %slot33, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i32 1, ptr %p136, align 4, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot33, align 8
  %p139 = inttoptr i64 %v137 to ptr
  %gep140 = getelementptr i8, ptr %p139, i64 8
  %op138 = ptrtoint ptr %gep140 to i64
  store i64 %op138, ptr %slot34, align 8
  %ld141 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot35, align 8
  %v142 = load i64, ptr %slot35, align 8
  %v143 = load i64, ptr %slot34, align 8
  %p144 = inttoptr i64 %v143 to ptr
  store i64 %v142, ptr %p144, align 8, !alias.scope !3, !noalias !4
  %v145 = load i64, ptr %slot33, align 8
  store i64 %v145, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %p146 = inttoptr i64 ptrtoint (ptr @myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p146, i64 7) "call-inline-cost"="0", !dbg !112
  %ld147 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld147, ptr %slot36, align 8
  %v148 = load i64, ptr %slot36, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ret150 = load { i64, i64 }, ptr %p149, align 8
  ret { i64, i64 } %ret150
bb_i9:
  %ld151 = load i64, ptr %mem54, align 8, !alias.scope !3, !noalias !4
  store i64 %ld151, ptr %slot37, align 8
  %v152 = load i64, ptr %slot37, align 8
  store i64 %v152, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld153 = load i64, ptr %mem56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld153, ptr %slot38, align 8
  %v154 = load i64, ptr %slot38, align 8
  store i64 %v154, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  %ld155 = load i64, ptr %mem60, align 8, !alias.scope !3, !noalias !4
  store i64 %ld155, ptr %slot39, align 8
  %ld156 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot40, align 8
  %v157 = load i64, ptr %slot40, align 8
  %v158 = load i64, ptr %slot39, align 8
  %ovpair160 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v157, i64 %v158)
  %op159 = extractvalue { i64, i1 } %ovpair160, 0
  %ov161 = extractvalue { i64, i1 } %ovpair160, 1
  store i64 %op159, ptr %slot41, align 8
  %v162 = load i64, ptr %slot40, align 8
  %v163 = load i64, ptr %slot41, align 8
  %op164 = xor i64 %v162, %v163
  store i64 %op164, ptr %slot42, align 8
  %v165 = load i64, ptr %slot39, align 8
  %v166 = load i64, ptr %slot41, align 8
  %op167 = xor i64 %v165, %v166
  store i64 %op167, ptr %slot43, align 8
  %v168 = load i64, ptr %slot42, align 8
  %v169 = load i64, ptr %slot43, align 8
  %op170 = and i64 %v168, %v169
  store i64 %op170, ptr %slot44, align 8
  %cv171 = zext i1 %ov161 to i64
  store i64 %cv171, ptr %slot45, align 8
  %v172 = load i64, ptr %slot45, align 8
  %cond173 = icmp ne i64 %v172, 0
  br i1 %cond173, label %bb_overflow29, label %bb_checked29
bb_overflow29:
  %v174 = load i64, ptr %slot1, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %v176 = load i64, ptr %slot40, align 8
  %v177 = load i64, ptr %slot39, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p175, i64 0, i64 %v176, i64 %v177, i64 64) nomerge, !dbg !114
  unreachable
bb_checked29:
  %v178 = load i64, ptr %slot41, align 8
  store i64 %v178, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot11, align 8
  store i64 %v179, ptr %slot46, align 8
  %v180 = load i64, ptr %slot46, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i32 0, ptr %p181, align 4, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot46, align 8
  %p184 = inttoptr i64 %v182 to ptr
  %gep185 = getelementptr i8, ptr %p184, i64 8
  %op183 = ptrtoint ptr %gep185 to i64
  store i64 %op183, ptr %slot47, align 8
  %ld186 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot48, align 8
  %v187 = load i64, ptr %slot48, align 8
  %v188 = load i64, ptr %slot47, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot46, align 8
  store i64 %v190, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  %ld191 = load i64, ptr %mem58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot49, align 8
  %v192 = load i64, ptr %slot49, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ret194 = load { i64, i64 }, ptr %p193, align 8
  ret { i64, i64 } %ret194
bb_failure:
  %v195 = load i64, ptr %slot5, align 8
  %p196 = inttoptr i64 %v195 to ptr
  call void @llvm.memset.p0.i64(ptr %p196, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v197 = load i64, ptr %slot5, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ret199 = load { i64, i64 }, ptr %p198, align 8
  ret { i64, i64 } %ret199
bb_entry_failure:
  %v200 = load i64, ptr %slot5, align 8
  %p201 = inttoptr i64 %v200 to ptr
  call void @llvm.memset.p0.i64(ptr %p201, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v202 = load i64, ptr %slot5, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ret204 = load { i64, i64 }, ptr %p203, align 8
  ret { i64, i64 } %ret204
}

@myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef_meta = external global i8, align 8

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef", linkageName: "myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17475239091883156453, i64 0, !"myl_f_eccc1b0a7698081677ef19e6adfc9eddb3e4e74ce8bb8dcc7378a10d96886bef"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!114 = !DILocation(line: 12, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!116 = !DILocation(line: 14, column: 0, scope: !117)
