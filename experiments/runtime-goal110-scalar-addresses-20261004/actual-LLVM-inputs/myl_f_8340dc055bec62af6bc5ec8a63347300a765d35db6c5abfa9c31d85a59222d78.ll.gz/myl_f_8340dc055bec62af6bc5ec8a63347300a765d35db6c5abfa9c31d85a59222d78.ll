target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_8340dc055bec62af6bc5ec8a63347300a765d35db6c5abfa9c31d85a59222d78(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v190 = load i64, ptr %slot1, align 8
  %op191 = add i64 %v190, 32
  store i64 %op191, ptr %slot4, align 8
  %mem192 = alloca i8, i64 8, align 8
  %mem194 = alloca i8, i64 8, align 8
  %mem196 = alloca i8, i64 8, align 8
  %ptr197 = ptrtoint ptr %mem196 to i64
  store i64 %ptr197, ptr %slot7, align 8
  %mem198 = alloca i8, i64 8, align 8
  %ptr199 = ptrtoint ptr %mem198 to i64
  store i64 %ptr199, ptr %slot8, align 8
  %mem200 = alloca i8, i64 8, align 8
  %ptr201 = ptrtoint ptr %mem200 to i64
  store i64 %ptr201, ptr %slot9, align 8
  %mem202 = alloca i8, i64 8, align 8
  %ptr203 = ptrtoint ptr %mem202 to i64
  store i64 %ptr203, ptr %slot10, align 8
  %mem204 = alloca i8, i64 8, align 8
  %ptr205 = ptrtoint ptr %mem204 to i64
  store i64 %ptr205, ptr %slot11, align 8
  %mem206 = alloca i8, i64 8, align 8
  %ptr207 = ptrtoint ptr %mem206 to i64
  store i64 %ptr207, ptr %slot12, align 8
  %mem208 = alloca i8, i64 8, align 8
  %ptr209 = ptrtoint ptr %mem208 to i64
  store i64 %ptr209, ptr %slot13, align 8
  %mem210 = alloca i8, i64 8, align 8
  %ptr211 = ptrtoint ptr %mem210 to i64
  store i64 %ptr211, ptr %slot14, align 8
  %mem212 = alloca i8, i64 8, align 8
  %ptr213 = ptrtoint ptr %mem212 to i64
  store i64 %ptr213, ptr %slot15, align 8
  %mem214 = alloca i8, i64 8, align 8
  %mem216 = alloca i8, i64 8, align 8
  store i64 0, ptr %mem198, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem204, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem208, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem210, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot2, align 8
  store i64 %v218, ptr %mem192, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot3, align 8
  store i64 %v219, ptr %mem194, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  store i64 0, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld220 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot18, align 8
  %v221 = load i64, ptr %slot7, align 8
  store i64 %v221, ptr %slot19, align 8
  %v222 = load i64, ptr %slot18, align 8
  %v223 = load i64, ptr %slot19, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %ld225 = load i64, ptr %mem192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot20, align 8
  %v226 = load i64, ptr %slot20, align 8
  store i64 %v226, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld227 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot21, align 8
  %v228 = load i64, ptr %slot8, align 8
  store i64 %v228, ptr %slot22, align 8
  %v229 = load i64, ptr %slot21, align 8
  %v230 = load i64, ptr %slot22, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %ld232 = load i64, ptr %mem198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot23, align 8
  %v233 = load i64, ptr %slot23, align 8
  %op234 = add i64 %v233, 0
  store i64 %op234, ptr %slot24, align 8
  %v235 = load i64, ptr %slot24, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !6, !noalias !7
  store i64 %ld237, ptr %slot25, align 8
  %v238 = load i64, ptr %slot25, align 8
  store i64 %v238, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld239 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot26, align 8
  %v240 = load i64, ptr %slot26, align 8
  %cmp241 = icmp ugt i64 %v240, 9223372036854775807
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot27, align 8
  %v243 = load i64, ptr %slot27, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_cast_overflow10, label %bb_cast_ok10
bb_cast_overflow10:
  %v245 = load i64, ptr %slot1, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %v247 = load i64, ptr %slot26, align 8
  call void @myl_qbe_fail_cast(ptr %p246, i64 %v247, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok10:
  %v248 = load i64, ptr %slot26, align 8
  store i64 %v248, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld249 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot28, align 8
  %v250 = load i64, ptr %slot9, align 8
  store i64 %v250, ptr %slot29, align 8
  %v251 = load i64, ptr %slot28, align 8
  %v252 = load i64, ptr %slot29, align 8
  %p253 = inttoptr i64 %v252 to ptr
  store i64 %v251, ptr %p253, align 8, !alias.scope !3, !noalias !4
  br label %bb_i7
bb_i7:
  %ld254 = load i64, ptr %mem196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot30, align 8
  %v255 = load i64, ptr %slot30, align 8
  store i64 %v255, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld256 = load i64, ptr %mem200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot31, align 8
  %v257 = load i64, ptr %slot31, align 8
  store i64 %v257, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld258 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot32, align 8
  %ld259 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot33, align 8
  %v260 = load i64, ptr %slot33, align 8
  %v261 = load i64, ptr %slot32, align 8
  %cmp262 = icmp slt i64 %v260, %v261
  %cv263 = zext i1 %cmp262 to i64
  store i64 %cv263, ptr %slot34, align 8
  %v264 = load i64, ptr %slot34, align 8
  store i64 %v264, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld265 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot35, align 8
  %v266 = load i64, ptr %slot35, align 8
  %cond267 = icmp ne i64 %v266, 0
  br i1 %cond267, label %bb_next19, label %bb_i43
bb_next19:
  %ld268 = load i64, ptr %mem196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld268, ptr %slot36, align 8
  %v269 = load i64, ptr %slot36, align 8
  store i64 %v269, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld270 = load i64, ptr %mem200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot37, align 8
  %v271 = load i64, ptr %slot37, align 8
  store i64 %v271, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld272 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot38, align 8
  %ld273 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot39, align 8
  %v274 = load i64, ptr %slot39, align 8
  %v275 = load i64, ptr %slot38, align 8
  %ovpair277 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v274, i64 %v275)
  %op276 = extractvalue { i64, i1 } %ovpair277, 0
  %ov278 = extractvalue { i64, i1 } %ovpair277, 1
  store i64 %op276, ptr %slot40, align 8
  %v279 = load i64, ptr %slot39, align 8
  %v280 = load i64, ptr %slot40, align 8
  %op281 = xor i64 %v279, %v280
  store i64 %op281, ptr %slot41, align 8
  %v282 = load i64, ptr %slot38, align 8
  %v283 = load i64, ptr %slot40, align 8
  %op284 = xor i64 %v282, %v283
  store i64 %op284, ptr %slot42, align 8
  %v285 = load i64, ptr %slot41, align 8
  %v286 = load i64, ptr %slot42, align 8
  %op287 = and i64 %v285, %v286
  store i64 %op287, ptr %slot43, align 8
  %cv288 = zext i1 %ov278 to i64
  store i64 %cv288, ptr %slot44, align 8
  %v289 = load i64, ptr %slot44, align 8
  %cond290 = icmp ne i64 %v289, 0
  br i1 %cond290, label %bb_overflow23, label %bb_checked23
bb_overflow23:
  %v291 = load i64, ptr %slot1, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %v293 = load i64, ptr %slot39, align 8
  %v294 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p292, i64 0, i64 %v293, i64 %v294, i64 64) nomerge, !dbg !112
  unreachable
bb_checked23:
  %v295 = load i64, ptr %slot40, align 8
  store i64 %v295, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 2, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld296 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld296, ptr %slot45, align 8
  %ld297 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld297, ptr %slot46, align 8
  %v298 = load i64, ptr %slot45, align 8
  %cmp299 = icmp eq i64 %v298, 0
  %cv300 = zext i1 %cmp299 to i64
  store i64 %cv300, ptr %slot47, align 8
  %v301 = load i64, ptr %slot47, align 8
  %cond302 = icmp ne i64 %v301, 0
  br i1 %cond302, label %bb_division30, label %bb_nonzero30
bb_division30:
  %v303 = load i64, ptr %slot1, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %v305 = load i64, ptr %slot46, align 8
  %v306 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_division(ptr %p304, i64 5, i64 %v305, i64 %v306) nomerge, !dbg !114
  unreachable
bb_nonzero30:
  %v307 = load i64, ptr %slot46, align 8
  %cmp308 = icmp eq i64 %v307, 9223372036854775808
  %cv309 = zext i1 %cmp308 to i64
  store i64 %cv309, ptr %slot48, align 8
  %v310 = load i64, ptr %slot45, align 8
  %cmp311 = icmp eq i64 %v310, 18446744073709551615
  %cv312 = zext i1 %cmp311 to i64
  store i64 %cv312, ptr %slot49, align 8
  %v313 = load i64, ptr %slot48, align 8
  %v314 = load i64, ptr %slot49, align 8
  %op315 = and i64 %v313, %v314
  store i64 %op315, ptr %slot50, align 8
  %v316 = load i64, ptr %slot50, align 8
  %cond317 = icmp ne i64 %v316, 0
  br i1 %cond317, label %bb_overflow30, label %bb_checked30
bb_overflow30:
  %v318 = load i64, ptr %slot1, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %v320 = load i64, ptr %slot46, align 8
  %v321 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p319, i64 5, i64 %v320, i64 %v321, i64 64) nomerge, !dbg !114
  unreachable
bb_checked30:
  %v322 = load i64, ptr %slot46, align 8
  %v323 = load i64, ptr %slot45, align 8
  %op324 = sdiv i64 %v322, %v323
  store i64 %op324, ptr %slot51, align 8
  %v325 = load i64, ptr %slot46, align 8
  %v326 = load i64, ptr %slot45, align 8
  %op327 = srem i64 %v325, %v326
  store i64 %op327, ptr %slot52, align 8
  %v328 = load i64, ptr %slot52, align 8
  %cmp329 = icmp ne i64 %v328, 0
  %cv330 = zext i1 %cmp329 to i64
  store i64 %cv330, ptr %slot53, align 8
  %v331 = load i64, ptr %slot52, align 8
  %v332 = load i64, ptr %slot45, align 8
  %op333 = xor i64 %v331, %v332
  store i64 %op333, ptr %slot54, align 8
  %v334 = load i64, ptr %slot54, align 8
  %cmp335 = icmp slt i64 %v334, 0
  %cv336 = zext i1 %cmp335 to i64
  store i64 %cv336, ptr %slot55, align 8
  %v337 = load i64, ptr %slot53, align 8
  %v338 = load i64, ptr %slot55, align 8
  %op339 = and i64 %v337, %v338
  store i64 %op339, ptr %slot56, align 8
  %v340 = load i64, ptr %slot56, align 8
  %neg341 = sub i64 0, %v340
  store i64 %neg341, ptr %slot57, align 8
  %v342 = load i64, ptr %slot51, align 8
  %v343 = load i64, ptr %slot56, align 8
  %op344 = sub i64 %v342, %v343
  store i64 %op344, ptr %slot51, align 8
  %v345 = load i64, ptr %slot51, align 8
  store i64 %v345, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld346 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot58, align 8
  %v347 = load i64, ptr %slot10, align 8
  store i64 %v347, ptr %slot59, align 8
  %v348 = load i64, ptr %slot58, align 8
  %v349 = load i64, ptr %slot59, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i64 %v348, ptr %p350, align 8, !alias.scope !3, !noalias !4
  %ld351 = load i64, ptr %mem192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld351, ptr %slot60, align 8
  %v352 = load i64, ptr %slot60, align 8
  store i64 %v352, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld353 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot61, align 8
  %v354 = load i64, ptr %slot11, align 8
  store i64 %v354, ptr %slot62, align 8
  %v355 = load i64, ptr %slot61, align 8
  %v356 = load i64, ptr %slot62, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %ld358 = load i64, ptr %mem202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot63, align 8
  %v359 = load i64, ptr %slot63, align 8
  store i64 %v359, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld360 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot64, align 8
  %v361 = load i64, ptr %slot12, align 8
  store i64 %v361, ptr %slot65, align 8
  %v362 = load i64, ptr %slot64, align 8
  %v363 = load i64, ptr %slot65, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %ld365 = load i64, ptr %mem204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot66, align 8
  %ld366 = load i64, ptr %mem206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot67, align 8
  %v367 = load i64, ptr %slot66, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !6, !noalias !7
  store i64 %ld369, ptr %slot68, align 8
  %v370 = load i64, ptr %slot67, align 8
  %v371 = load i64, ptr %slot68, align 8
  %cmp372 = icmp ult i64 %v370, %v371
  %cv373 = zext i1 %cmp372 to i64
  store i64 %cv373, ptr %slot69, align 8
  %v374 = load i64, ptr %slot69, align 8
  %cond375 = icmp ne i64 %v374, 0
  br i1 %cond375, label %bb_positive21, label %bb_i21
bb_positive21:
  %v376 = load i64, ptr %slot66, align 8
  %op377 = add i64 %v376, 32
  store i64 %op377, ptr %slot70, align 8
  %v378 = load i64, ptr %slot70, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !6, !noalias !7
  store i64 %ld380, ptr %slot71, align 8
  %v381 = load i64, ptr %slot67, align 8
  %op382 = mul i64 %v381, 8
  store i64 %op382, ptr %slot72, align 8
  %v383 = load i64, ptr %slot71, align 8
  %v384 = load i64, ptr %slot72, align 8
  %op385 = add i64 %v383, %v384
  store i64 %op385, ptr %slot73, align 8
  %v386 = load i64, ptr %slot71, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %v388 = load i64, ptr %slot72, align 8
  %egep389 = getelementptr i8, ptr %p387, i64 %v388
  %ld390 = load i64, ptr %egep389, align 8, !alias.scope !12, !noalias !13
  store i64 %ld390, ptr %slot74, align 8
  %v391 = load i64, ptr %slot74, align 8
  store i64 %v391, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_i21:
  %ld392 = load i64, ptr %mem206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot75, align 8
  %v393 = load i64, ptr %slot75, align 8
  store i64 %v393, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld394 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot76, align 8
  %ld395 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld395, ptr %slot77, align 8
  %v396 = load i64, ptr %slot77, align 8
  %v397 = load i64, ptr %slot76, align 8
  %cmp398 = icmp slt i64 %v396, %v397
  %cv399 = zext i1 %cmp398 to i64
  store i64 %cv399, ptr %slot78, align 8
  %v400 = load i64, ptr %slot78, align 8
  store i64 %v400, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld401 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot79, align 8
  %v402 = load i64, ptr %slot79, align 8
  %cond403 = icmp ne i64 %v402, 0
  br i1 %cond403, label %bb_next63, label %bb_i30
bb_next63:
  %ld404 = load i64, ptr %mem204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot80, align 8
  %v405 = load i64, ptr %slot80, align 8
  %op406 = add i64 %v405, 0
  store i64 %op406, ptr %slot81, align 8
  %v407 = load i64, ptr %slot81, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !6, !noalias !7
  store i64 %ld409, ptr %slot82, align 8
  %v410 = load i64, ptr %slot82, align 8
  store i64 %v410, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld411 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot83, align 8
  %v412 = load i64, ptr %slot83, align 8
  %cmp413 = icmp ugt i64 %v412, 9223372036854775807
  %cv414 = zext i1 %cmp413 to i64
  store i64 %cv414, ptr %slot84, align 8
  %v415 = load i64, ptr %slot84, align 8
  %cond416 = icmp ne i64 %v415, 0
  br i1 %cond416, label %bb_cast_overflow68, label %bb_cast_ok68
bb_cast_overflow68:
  %v417 = load i64, ptr %slot1, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %v419 = load i64, ptr %slot83, align 8
  call void @myl_qbe_fail_cast(ptr %p418, i64 %v419, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok68:
  %v420 = load i64, ptr %slot83, align 8
  store i64 %v420, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld421 = load i64, ptr %mem206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld421, ptr %slot85, align 8
  %v422 = load i64, ptr %slot85, align 8
  store i64 %v422, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld423 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld423, ptr %slot86, align 8
  %ld424 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot87, align 8
  %v425 = load i64, ptr %slot87, align 8
  %v426 = load i64, ptr %slot86, align 8
  %ovpair428 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v425, i64 %v426)
  %op427 = extractvalue { i64, i1 } %ovpair428, 0
  %ov429 = extractvalue { i64, i1 } %ovpair428, 1
  store i64 %op427, ptr %slot88, align 8
  %v430 = load i64, ptr %slot87, align 8
  %v431 = load i64, ptr %slot88, align 8
  %op432 = xor i64 %v430, %v431
  store i64 %op432, ptr %slot89, align 8
  %v433 = load i64, ptr %slot86, align 8
  %v434 = load i64, ptr %slot88, align 8
  %op435 = xor i64 %v433, %v434
  store i64 %op435, ptr %slot90, align 8
  %v436 = load i64, ptr %slot89, align 8
  %v437 = load i64, ptr %slot90, align 8
  %op438 = and i64 %v436, %v437
  store i64 %op438, ptr %slot91, align 8
  %cv439 = zext i1 %ov429 to i64
  store i64 %cv439, ptr %slot92, align 8
  %v440 = load i64, ptr %slot92, align 8
  %cond441 = icmp ne i64 %v440, 0
  br i1 %cond441, label %bb_overflow72, label %bb_checked72
bb_overflow72:
  %v442 = load i64, ptr %slot1, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %v444 = load i64, ptr %slot87, align 8
  %v445 = load i64, ptr %slot86, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p443, i64 0, i64 %v444, i64 %v445, i64 64) nomerge, !dbg !118
  unreachable
bb_checked72:
  %v446 = load i64, ptr %slot88, align 8
  store i64 %v446, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld447 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld447, ptr %slot93, align 8
  %v448 = load i64, ptr %slot12, align 8
  store i64 %v448, ptr %slot94, align 8
  %v449 = load i64, ptr %slot93, align 8
  %v450 = load i64, ptr %slot94, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_i30:
  %ld452 = load i64, ptr %mem206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot95, align 8
  %v453 = load i64, ptr %slot95, align 8
  store i64 %v453, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld454 = load i64, ptr %mem204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot96, align 8
  %ld455 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot97, align 8
  %v456 = load i64, ptr %slot96, align 8
  %p457 = inttoptr i64 %v456 to ptr
  %ld458 = load i64, ptr %p457, align 8, !alias.scope !6, !noalias !7
  store i64 %ld458, ptr %slot98, align 8
  %v459 = load i64, ptr %slot97, align 8
  %v460 = load i64, ptr %slot98, align 8
  %cmp461 = icmp ult i64 %v459, %v460
  %cv462 = zext i1 %cmp461 to i64
  store i64 %cv462, ptr %slot99, align 8
  %v463 = load i64, ptr %slot99, align 8
  %cond464 = icmp ne i64 %v463, 0
  br i1 %cond464, label %bb_success85, label %bb_failed85
bb_failed85:
  %v465 = load i64, ptr %slot1, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %v467 = load i64, ptr %slot97, align 8
  %v468 = load i64, ptr %slot98, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p466, i64 %v467, i64 %v468) nomerge, !dbg !120
  unreachable
bb_success85:
  %v469 = load i64, ptr %slot96, align 8
  %op470 = add i64 %v469, 32
  store i64 %op470, ptr %slot100, align 8
  %v471 = load i64, ptr %slot100, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !6, !noalias !7
  store i64 %ld473, ptr %slot101, align 8
  %v474 = load i64, ptr %slot97, align 8
  %op475 = mul i64 %v474, 8
  store i64 %op475, ptr %slot102, align 8
  %v476 = load i64, ptr %slot101, align 8
  %v477 = load i64, ptr %slot102, align 8
  %op478 = add i64 %v476, %v477
  store i64 %op478, ptr %slot103, align 8
  %v479 = load i64, ptr %slot101, align 8
  %p480 = inttoptr i64 %v479 to ptr
  %v481 = load i64, ptr %slot102, align 8
  %egep482 = getelementptr i8, ptr %p480, i64 %v481
  %ld483 = load i64, ptr %egep482, align 8, !alias.scope !12, !noalias !13
  store i64 %ld483, ptr %slot104, align 8
  %v484 = load i64, ptr %slot104, align 8
  store i64 %v484, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_i32:
  %ld485 = load i64, ptr %mem194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld485, ptr %slot105, align 8
  %v486 = load i64, ptr %slot105, align 8
  store i64 %v486, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld487 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot106, align 8
  %ld488 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld488, ptr %slot107, align 8
  %v489 = load i64, ptr %slot107, align 8
  %v490 = load i64, ptr %slot106, align 8
  %cmp491 = icmp slt i64 %v489, %v490
  %cv492 = zext i1 %cmp491 to i64
  store i64 %cv492, ptr %slot108, align 8
  %v493 = load i64, ptr %slot108, align 8
  store i64 %v493, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld494 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot109, align 8
  %v495 = load i64, ptr %slot109, align 8
  %cond496 = icmp ne i64 %v495, 0
  br i1 %cond496, label %bb_next96, label %bb_i40
bb_next96:
  %ld497 = load i64, ptr %mem202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld497, ptr %slot110, align 8
  %v498 = load i64, ptr %slot110, align 8
  store i64 %v498, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 1, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld499 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld499, ptr %slot111, align 8
  %ld500 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld500, ptr %slot112, align 8
  %v501 = load i64, ptr %slot112, align 8
  %v502 = load i64, ptr %slot111, align 8
  %ovpair504 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v501, i64 %v502)
  %op503 = extractvalue { i64, i1 } %ovpair504, 0
  %ov505 = extractvalue { i64, i1 } %ovpair504, 1
  store i64 %op503, ptr %slot113, align 8
  %cv506 = zext i1 %ov505 to i64
  store i64 %cv506, ptr %slot114, align 8
  %v507 = load i64, ptr %slot114, align 8
  %cond508 = icmp ne i64 %v507, 0
  br i1 %cond508, label %bb_overflow99, label %bb_checked99
bb_overflow99:
  %v509 = load i64, ptr %slot1, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %v511 = load i64, ptr %slot112, align 8
  %v512 = load i64, ptr %slot111, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p510, i64 0, i64 %v511, i64 %v512, i64 64) nomerge, !dbg !122
  unreachable
bb_checked99:
  %v513 = load i64, ptr %slot113, align 8
  store i64 %v513, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld514 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld514, ptr %slot115, align 8
  %v515 = load i64, ptr %slot7, align 8
  store i64 %v515, ptr %slot116, align 8
  %v516 = load i64, ptr %slot115, align 8
  %v517 = load i64, ptr %slot116, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 %v516, ptr %p518, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i40:
  %ld519 = load i64, ptr %mem202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld519, ptr %slot117, align 8
  %v520 = load i64, ptr %slot117, align 8
  store i64 %v520, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld521 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld521, ptr %slot118, align 8
  %v522 = load i64, ptr %slot9, align 8
  store i64 %v522, ptr %slot119, align 8
  %v523 = load i64, ptr %slot118, align 8
  %v524 = load i64, ptr %slot119, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  br label %bb_i7
bb_i43:
  %ld526 = load i64, ptr %mem196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld526, ptr %slot120, align 8
  %v527 = load i64, ptr %slot120, align 8
  store i64 %v527, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld528 = load i64, ptr %mem192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot121, align 8
  %v529 = load i64, ptr %slot121, align 8
  store i64 %v529, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld530 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot122, align 8
  %v531 = load i64, ptr %slot13, align 8
  store i64 %v531, ptr %slot123, align 8
  %v532 = load i64, ptr %slot122, align 8
  %v533 = load i64, ptr %slot123, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i64 %v532, ptr %p534, align 8, !alias.scope !3, !noalias !4
  %ld535 = load i64, ptr %mem208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot124, align 8
  %v536 = load i64, ptr %slot124, align 8
  %op537 = add i64 %v536, 0
  store i64 %op537, ptr %slot125, align 8
  %v538 = load i64, ptr %slot125, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !6, !noalias !7
  store i64 %ld540, ptr %slot126, align 8
  %v541 = load i64, ptr %slot126, align 8
  store i64 %v541, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld542 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld542, ptr %slot127, align 8
  %v543 = load i64, ptr %slot127, align 8
  %cmp544 = icmp ugt i64 %v543, 9223372036854775807
  %cv545 = zext i1 %cmp544 to i64
  store i64 %cv545, ptr %slot128, align 8
  %v546 = load i64, ptr %slot128, align 8
  %cond547 = icmp ne i64 %v546, 0
  br i1 %cond547, label %bb_cast_overflow115, label %bb_cast_ok115
bb_cast_overflow115:
  %v548 = load i64, ptr %slot1, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %v550 = load i64, ptr %slot127, align 8
  call void @myl_qbe_fail_cast(ptr %p549, i64 %v550, i64 320) nomerge, !dbg !124
  unreachable
bb_cast_ok115:
  %v551 = load i64, ptr %slot127, align 8
  store i64 %v551, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld552 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot129, align 8
  %ld553 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld553, ptr %slot130, align 8
  %v554 = load i64, ptr %slot130, align 8
  %v555 = load i64, ptr %slot129, align 8
  %cmp556 = icmp slt i64 %v554, %v555
  %cv557 = zext i1 %cmp556 to i64
  store i64 %cv557, ptr %slot131, align 8
  %v558 = load i64, ptr %slot131, align 8
  store i64 %v558, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld559 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot132, align 8
  %v560 = load i64, ptr %slot132, align 8
  %cond561 = icmp ne i64 %v560, 0
  br i1 %cond561, label %bb_next120, label %bb_i68
bb_next120:
  %ld562 = load i64, ptr %mem192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot133, align 8
  %v563 = load i64, ptr %slot133, align 8
  store i64 %v563, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld564 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot134, align 8
  %v565 = load i64, ptr %slot14, align 8
  store i64 %v565, ptr %slot135, align 8
  %v566 = load i64, ptr %slot134, align 8
  %v567 = load i64, ptr %slot135, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %ld569 = load i64, ptr %mem196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld569, ptr %slot136, align 8
  %v570 = load i64, ptr %slot136, align 8
  store i64 %v570, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld571 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot137, align 8
  %v572 = load i64, ptr %slot15, align 8
  store i64 %v572, ptr %slot138, align 8
  %v573 = load i64, ptr %slot137, align 8
  %v574 = load i64, ptr %slot138, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i64 %v573, ptr %p575, align 8, !alias.scope !3, !noalias !4
  %ld576 = load i64, ptr %mem210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot139, align 8
  %ld577 = load i64, ptr %mem212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot140, align 8
  %v578 = load i64, ptr %slot139, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i64, ptr %p579, align 8, !alias.scope !6, !noalias !7
  store i64 %ld580, ptr %slot141, align 8
  %v581 = load i64, ptr %slot140, align 8
  %v582 = load i64, ptr %slot141, align 8
  %cmp583 = icmp ult i64 %v581, %v582
  %cv584 = zext i1 %cmp583 to i64
  store i64 %cv584, ptr %slot142, align 8
  %v585 = load i64, ptr %slot142, align 8
  %cond586 = icmp ne i64 %v585, 0
  br i1 %cond586, label %bb_positive54, label %bb_i54
bb_positive54:
  %v587 = load i64, ptr %slot139, align 8
  %op588 = add i64 %v587, 32
  store i64 %op588, ptr %slot143, align 8
  %v589 = load i64, ptr %slot143, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !6, !noalias !7
  store i64 %ld591, ptr %slot144, align 8
  %v592 = load i64, ptr %slot140, align 8
  %op593 = mul i64 %v592, 8
  store i64 %op593, ptr %slot145, align 8
  %v594 = load i64, ptr %slot144, align 8
  %v595 = load i64, ptr %slot145, align 8
  %op596 = add i64 %v594, %v595
  store i64 %op596, ptr %slot146, align 8
  %v597 = load i64, ptr %slot144, align 8
  %p598 = inttoptr i64 %v597 to ptr
  %v599 = load i64, ptr %slot145, align 8
  %egep600 = getelementptr i8, ptr %p598, i64 %v599
  %ld601 = load i64, ptr %egep600, align 8, !alias.scope !12, !noalias !13
  store i64 %ld601, ptr %slot147, align 8
  %v602 = load i64, ptr %slot147, align 8
  store i64 %v602, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i65
bb_i54:
  %ld603 = load i64, ptr %mem212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld603, ptr %slot148, align 8
  %v604 = load i64, ptr %slot148, align 8
  store i64 %v604, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 0, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld605 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld605, ptr %slot149, align 8
  %ld606 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld606, ptr %slot150, align 8
  %v607 = load i64, ptr %slot150, align 8
  %v608 = load i64, ptr %slot149, align 8
  %cmp609 = icmp slt i64 %v607, %v608
  %cv610 = zext i1 %cmp609 to i64
  store i64 %cv610, ptr %slot151, align 8
  %v611 = load i64, ptr %slot151, align 8
  store i64 %v611, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld612 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot152, align 8
  %v613 = load i64, ptr %slot152, align 8
  %cond614 = icmp ne i64 %v613, 0
  br i1 %cond614, label %bb_next140, label %bb_i63
bb_next140:
  %ld615 = load i64, ptr %mem210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld615, ptr %slot153, align 8
  %v616 = load i64, ptr %slot153, align 8
  %op617 = add i64 %v616, 0
  store i64 %op617, ptr %slot154, align 8
  %v618 = load i64, ptr %slot154, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %ld620 = load i64, ptr %p619, align 8, !alias.scope !6, !noalias !7
  store i64 %ld620, ptr %slot155, align 8
  %v621 = load i64, ptr %slot155, align 8
  store i64 %v621, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld622 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot156, align 8
  %v623 = load i64, ptr %slot156, align 8
  %cmp624 = icmp ugt i64 %v623, 9223372036854775807
  %cv625 = zext i1 %cmp624 to i64
  store i64 %cv625, ptr %slot157, align 8
  %v626 = load i64, ptr %slot157, align 8
  %cond627 = icmp ne i64 %v626, 0
  br i1 %cond627, label %bb_cast_overflow145, label %bb_cast_ok145
bb_cast_overflow145:
  %v628 = load i64, ptr %slot1, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %v630 = load i64, ptr %slot156, align 8
  call void @myl_qbe_fail_cast(ptr %p629, i64 %v630, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok145:
  %v631 = load i64, ptr %slot156, align 8
  store i64 %v631, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld632 = load i64, ptr %mem212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot158, align 8
  %v633 = load i64, ptr %slot158, align 8
  store i64 %v633, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld634 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld634, ptr %slot159, align 8
  %ld635 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld635, ptr %slot160, align 8
  %v636 = load i64, ptr %slot160, align 8
  %v637 = load i64, ptr %slot159, align 8
  %ovpair639 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v636, i64 %v637)
  %op638 = extractvalue { i64, i1 } %ovpair639, 0
  %ov640 = extractvalue { i64, i1 } %ovpair639, 1
  store i64 %op638, ptr %slot161, align 8
  %v641 = load i64, ptr %slot160, align 8
  %v642 = load i64, ptr %slot161, align 8
  %op643 = xor i64 %v641, %v642
  store i64 %op643, ptr %slot162, align 8
  %v644 = load i64, ptr %slot159, align 8
  %v645 = load i64, ptr %slot161, align 8
  %op646 = xor i64 %v644, %v645
  store i64 %op646, ptr %slot163, align 8
  %v647 = load i64, ptr %slot162, align 8
  %v648 = load i64, ptr %slot163, align 8
  %op649 = and i64 %v647, %v648
  store i64 %op649, ptr %slot164, align 8
  %cv650 = zext i1 %ov640 to i64
  store i64 %cv650, ptr %slot165, align 8
  %v651 = load i64, ptr %slot165, align 8
  %cond652 = icmp ne i64 %v651, 0
  br i1 %cond652, label %bb_overflow149, label %bb_checked149
bb_overflow149:
  %v653 = load i64, ptr %slot1, align 8
  %p654 = inttoptr i64 %v653 to ptr
  %v655 = load i64, ptr %slot160, align 8
  %v656 = load i64, ptr %slot159, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p654, i64 0, i64 %v655, i64 %v656, i64 64) nomerge, !dbg !128
  unreachable
bb_checked149:
  %v657 = load i64, ptr %slot161, align 8
  store i64 %v657, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld658 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld658, ptr %slot166, align 8
  %v659 = load i64, ptr %slot15, align 8
  store i64 %v659, ptr %slot167, align 8
  %v660 = load i64, ptr %slot166, align 8
  %v661 = load i64, ptr %slot167, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  br label %bb_i63
bb_i63:
  %ld663 = load i64, ptr %mem212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld663, ptr %slot168, align 8
  %v664 = load i64, ptr %slot168, align 8
  store i64 %v664, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld665 = load i64, ptr %mem210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot169, align 8
  %ld666 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld666, ptr %slot170, align 8
  %v667 = load i64, ptr %slot169, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !6, !noalias !7
  store i64 %ld669, ptr %slot171, align 8
  %v670 = load i64, ptr %slot170, align 8
  %v671 = load i64, ptr %slot171, align 8
  %cmp672 = icmp ult i64 %v670, %v671
  %cv673 = zext i1 %cmp672 to i64
  store i64 %cv673, ptr %slot172, align 8
  %v674 = load i64, ptr %slot172, align 8
  %cond675 = icmp ne i64 %v674, 0
  br i1 %cond675, label %bb_success162, label %bb_failed162
bb_failed162:
  %v676 = load i64, ptr %slot1, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %v678 = load i64, ptr %slot170, align 8
  %v679 = load i64, ptr %slot171, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p677, i64 %v678, i64 %v679) nomerge, !dbg !130
  unreachable
bb_success162:
  %v680 = load i64, ptr %slot169, align 8
  %op681 = add i64 %v680, 32
  store i64 %op681, ptr %slot173, align 8
  %v682 = load i64, ptr %slot173, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !6, !noalias !7
  store i64 %ld684, ptr %slot174, align 8
  %v685 = load i64, ptr %slot170, align 8
  %op686 = mul i64 %v685, 8
  store i64 %op686, ptr %slot175, align 8
  %v687 = load i64, ptr %slot174, align 8
  %v688 = load i64, ptr %slot175, align 8
  %op689 = add i64 %v687, %v688
  store i64 %op689, ptr %slot176, align 8
  %v690 = load i64, ptr %slot174, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %v692 = load i64, ptr %slot175, align 8
  %egep693 = getelementptr i8, ptr %p691, i64 %v692
  %ld694 = load i64, ptr %egep693, align 8, !alias.scope !12, !noalias !13
  store i64 %ld694, ptr %slot177, align 8
  %v695 = load i64, ptr %slot177, align 8
  store i64 %v695, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i65
bb_i65:
  %ld696 = load i64, ptr %mem194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot178, align 8
  %v697 = load i64, ptr %slot178, align 8
  store i64 %v697, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld698 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld698, ptr %slot179, align 8
  %ld699 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot180, align 8
  %v700 = load i64, ptr %slot180, align 8
  %v701 = load i64, ptr %slot179, align 8
  %cmp702 = icmp eq i64 %v700, %v701
  %cv703 = zext i1 %cmp702 to i64
  store i64 %cv703, ptr %slot181, align 8
  %v704 = load i64, ptr %slot181, align 8
  store i64 %v704, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i69
bb_i68:
  store i64 0, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i69
bb_i69:
  %ld705 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld705, ptr %slot182, align 8
  %v706 = load i64, ptr %slot182, align 8
  %cond707 = icmp ne i64 %v706, 0
  br i1 %cond707, label %bb_next173, label %bb_i74
bb_next173:
  %ld708 = load i64, ptr %mem196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot183, align 8
  %v709 = load i64, ptr %slot183, align 8
  store i64 %v709, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 1, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  %ld710 = load i64, ptr %mem216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld710, ptr %slot184, align 8
  %ld711 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld711, ptr %slot185, align 8
  %v712 = load i64, ptr %slot185, align 8
  %v713 = load i64, ptr %slot184, align 8
  %ovpair715 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v712, i64 %v713)
  %op714 = extractvalue { i64, i1 } %ovpair715, 0
  %ov716 = extractvalue { i64, i1 } %ovpair715, 1
  store i64 %op714, ptr %slot186, align 8
  %cv717 = zext i1 %ov716 to i64
  store i64 %cv717, ptr %slot187, align 8
  %v718 = load i64, ptr %slot187, align 8
  %cond719 = icmp ne i64 %v718, 0
  br i1 %cond719, label %bb_overflow176, label %bb_checked176
bb_overflow176:
  %v720 = load i64, ptr %slot1, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %v722 = load i64, ptr %slot185, align 8
  %v723 = load i64, ptr %slot184, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p721, i64 0, i64 %v722, i64 %v723, i64 64) nomerge, !dbg !132
  unreachable
bb_checked176:
  %v724 = load i64, ptr %slot186, align 8
  store i64 %v724, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld725 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld725, ptr %slot188, align 8
  %v726 = load i64, ptr %slot188, align 8
  ret i64 %v726
bb_i74:
  store i64 0, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  %ld727 = load i64, ptr %mem214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld727, ptr %slot189, align 8
  %v728 = load i64, ptr %slot189, align 8
  ret i64 %v728
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8340dc055bec62af6bc5ec8a63347300a765d35db6c5abfa9c31d85a59222d78", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8340dc055bec62af6bc5ec8a63347300a765d35db6c5abfa9c31d85a59222d78", linkageName: "myl_f_8340dc055bec62af6bc5ec8a63347300a765d35db6c5abfa9c31d85a59222d78", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9868431987859880425, i64 0, !"myl_f_8340dc055bec62af6bc5ec8a63347300a765d35db6c5abfa9c31d85a59222d78"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!110 = !DILocation(line: 6, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!112 = !DILocation(line: 14, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!116 = !DILocation(line: 27, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!118 = !DILocation(line: 29, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!120 = !DILocation(line: 32, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!122 = !DILocation(line: 38, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!124 = !DILocation(line: 48, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!126 = !DILocation(line: 60, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!128 = !DILocation(line: 62, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!130 = !DILocation(line: 65, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!132 = !DILocation(line: 73, column: 0, scope: !133)
