target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i32, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v175 = load i64, ptr %slot1, align 8
  %op176 = add i64 %v175, 32
  store i64 %op176, ptr %slot3, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot4, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot5, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot6, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot7, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot8, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot9, align 8
  %mem189 = alloca i8, i64 16, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot10, align 8
  %mem191 = alloca i8, i64 16, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot11, align 8
  %mem193 = alloca i8, i64 8, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot13, align 8
  %mem197 = alloca i8, i64 8, align 8
  %mem199 = alloca i8, i64 8, align 8
  %mem201 = alloca i8, i64 16, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot16, align 8
  store i64 0, ptr %mem195, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot2, align 8
  store i64 %v203, ptr %mem193, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot1, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %call206 = call ptr @myl_qbe_heap(ptr %p205) nomerge, !dbg !110
  %calladdr207 = ptrtoint ptr %call206 to i64
  store i64 %calladdr207, ptr %slot17, align 8
  %v208 = load i64, ptr %slot1, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %call210 = call i64 @myl_qbe_region_mark(ptr %p209) nomerge, !dbg !110
  store i64 %call210, ptr %slot18, align 8
  store i32 0, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem181, align 4, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 2, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %ld211 = load i64, ptr %mem193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld211, ptr %slot19, align 8
  %v212 = load i64, ptr %slot19, align 8
  store i64 %v212, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld213 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot20, align 8
  %v214 = load i64, ptr %slot20, align 8
  store i64 %v214, ptr %mem187, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot9, align 8
  store i64 %v215, ptr %slot21, align 8
  store i32 0, ptr %slot22, align 8
  %ld216 = load i32, ptr %mem181, align 4, !alias.scope !3, !noalias !4
  store i32 %ld216, ptr %slot23, align 8
  %v217 = load i32, ptr %slot23, align 8
  %op218 = and i32 %v217, 24
  store i32 %op218, ptr %slot23, align 8
  %v219 = load i32, ptr %slot23, align 8
  %cmp220 = icmp eq i32 %v219, 0
  %cv221 = zext i1 %cmp220 to i32
  store i32 %cv221, ptr %slot24, align 8
  %v222 = load i32, ptr %slot22, align 8
  %v223 = load i32, ptr %slot24, align 8
  %op224 = and i32 %v222, %v223
  store i32 %op224, ptr %slot25, align 8
  %v225 = load i32, ptr %slot25, align 8
  %cv226 = zext i32 %v225 to i64
  %cond227 = icmp ne i64 %cv226, 0
  br i1 %cond227, label %bb_rcprivateown11, label %bb_rcprivateloan11
bb_rcprivateown11:
  %v228 = load i64, ptr %slot10, align 8
  store i64 %v228, ptr %slot26, align 8
  %v229 = load i64, ptr %slot18, align 8
  store i64 %v229, ptr %slot27, align 8
  %v230 = load i64, ptr %slot21, align 8
  %v231 = load i64, ptr %slot26, align 8
  %op232 = sub i64 %v230, %v231
  store i64 %op232, ptr %slot28, align 8
  %v233 = load i64, ptr %slot26, align 8
  %v234 = load i64, ptr %slot21, align 8
  %op235 = sub i64 %v233, %v234
  store i64 %op235, ptr %slot29, align 8
  %v236 = load i64, ptr %slot28, align 8
  %cmp237 = icmp ult i64 %v236, 8
  %cv238 = zext i1 %cmp237 to i32
  store i32 %cv238, ptr %slot30, align 8
  %v239 = load i64, ptr %slot29, align 8
  %cmp240 = icmp ult i64 %v239, 8
  %cv241 = zext i1 %cmp240 to i32
  store i32 %cv241, ptr %slot31, align 8
  %v242 = load i32, ptr %slot30, align 8
  %v243 = load i32, ptr %slot31, align 8
  %op244 = or i32 %v242, %v243
  store i32 %op244, ptr %slot32, align 8
  %v245 = load i32, ptr %slot32, align 8
  %cv246 = zext i32 %v245 to i64
  %cond247 = icmp ne i64 %cv246, 0
  br i1 %cond247, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v248 = load i64, ptr %slot21, align 8
  %p250 = inttoptr i64 %v248 to ptr
  %gep251 = getelementptr i8, ptr %p250, i64 0
  %op249 = ptrtoint ptr %gep251 to i64
  store i64 %op249, ptr %slot33, align 8
  %v252 = load i64, ptr %slot33, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot34, align 8
  %v255 = load i64, ptr %slot34, align 8
  %cmp256 = icmp ne i64 %v255, 0
  %cv257 = zext i1 %cmp256 to i32
  store i32 %cv257, ptr %slot35, align 8
  %v258 = load i32, ptr %slot35, align 8
  %cv259 = zext i32 %v258 to i64
  %cond260 = icmp ne i64 %cv259, 0
  br i1 %cond260, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v261 = load i64, ptr %slot34, align 8
  %op262 = sub i64 %v261, 16
  store i64 %op262, ptr %slot36, align 8
  %v263 = load i64, ptr %slot34, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %rgep265 = getelementptr i8, ptr %p264, i64 -16
  %ld266 = load i64, ptr %rgep265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld266, ptr %slot37, align 8
  %v267 = load i64, ptr %slot37, align 8
  %op268 = and i64 %v267, 5764607523034234881
  store i64 %op268, ptr %slot38, align 8
  %v269 = load i64, ptr %slot38, align 8
  %cmp270 = icmp ne i64 %v269, 0
  %cv271 = zext i1 %cmp270 to i32
  store i32 %cv271, ptr %slot39, align 8
  %v272 = load i32, ptr %slot39, align 8
  %cv273 = zext i32 %v272 to i64
  %cond274 = icmp ne i64 %cv273, 0
  br i1 %cond274, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v275 = load i64, ptr %slot21, align 8
  %v276 = load i64, ptr %slot26, align 8
  %p277 = inttoptr i64 %v275 to ptr
  %p278 = inttoptr i64 %v276 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p278, ptr %p277, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot21, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i64 0, ptr %p280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %v281 = load i64, ptr %slot17, align 8
  %v282 = load i64, ptr %slot26, align 8
  %v283 = load i64, ptr %slot21, align 8
  %v284 = load i64, ptr %slot27, align 8
  %cv285 = trunc i64 %v284 to i32
  %call286 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v281, i64 %v282, i64 %v283, i32 %cv285) nomerge, !dbg !112
  store i32 %call286, ptr %slot40, align 8
  %v287 = load i32, ptr %slot40, align 8
  %cv288 = zext i32 %v287 to i64
  %cond289 = icmp ne i64 %cv288, 0
  br i1 %cond289, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v290 = load i64, ptr %slot17, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %call292 = call i32 @myl_rc_take_failure(ptr %p291) nomerge, !dbg !112
  store i32 %call292, ptr %slot41, align 8
  %v293 = load i64, ptr %slot1, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %v295 = load i32, ptr %slot41, align 8
  %call296 = call i32 @myl_qbe_rc_status(ptr %p294, i32 %v295) nomerge, !dbg !112
  store i32 %call296, ptr %slot42, align 8
  br label %bb_failure
bb_rcsuccess29:
  br label %bb_rcmoved14
bb_rcmoved14:
  store i32 2, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 1, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateloan11:
  %v297 = load i64, ptr %slot10, align 8
  store i64 %v297, ptr %slot43, align 8
  %v298 = load i64, ptr %slot21, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %ld300 = load i64, ptr %p299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld300, ptr %slot44, align 8
  %v301 = load i64, ptr %slot44, align 8
  %cmp302 = icmp ne i64 %v301, 0
  %cv303 = zext i1 %cmp302 to i32
  store i32 %cv303, ptr %slot45, align 8
  %v304 = load i32, ptr %slot45, align 8
  %cv305 = zext i32 %v304 to i64
  %cond306 = icmp ne i64 %cv305, 0
  br i1 %cond306, label %bb_rcgnn37, label %bb_rcgstore37
bb_rcgnn37:
  %v307 = load i64, ptr %slot44, align 8
  %op308 = sub i64 %v307, 16
  store i64 %op308, ptr %slot46, align 8
  %v309 = load i64, ptr %slot44, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %rgep311 = getelementptr i8, ptr %p310, i64 -16
  %ld312 = load i64, ptr %rgep311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld312, ptr %slot47, align 8
  %v313 = load i64, ptr %slot47, align 8
  %op314 = and i64 %v313, 4611686018427387906
  store i64 %op314, ptr %slot48, align 8
  %v315 = load i64, ptr %slot48, align 8
  %cmp316 = icmp ne i64 %v315, 0
  %cv317 = zext i1 %cmp316 to i32
  store i32 %cv317, ptr %slot49, align 8
  %v318 = load i32, ptr %slot49, align 8
  %cv319 = zext i32 %v318 to i64
  %cond320 = icmp ne i64 %cv319, 0
  br i1 %cond320, label %bb_rcgstore37, label %bb_rcginc37
bb_rcginc37:
  %v321 = load i64, ptr %slot44, align 8
  %op322 = sub i64 %v321, 24
  store i64 %op322, ptr %slot50, align 8
  %v323 = load i64, ptr %slot44, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %rgep325 = getelementptr i8, ptr %p324, i64 -24
  %ld326 = load i64, ptr %rgep325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld326, ptr %slot51, align 8
  %v327 = load i64, ptr %slot51, align 8
  %op328 = add i64 %v327, 1
  store i64 %op328, ptr %slot52, align 8
  %v329 = load i64, ptr %slot52, align 8
  %cmp330 = icmp eq i64 %v329, 0
  %cv331 = zext i1 %cmp330 to i32
  store i32 %cv331, ptr %slot53, align 8
  %v332 = load i32, ptr %slot53, align 8
  %cv333 = zext i32 %v332 to i64
  %cond334 = icmp ne i64 %cv333, 0
  br i1 %cond334, label %bb_rcglimit37, label %bb_rcgcapacity37
bb_rcglimit37:
  %v335 = load i64, ptr %slot1, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %call337 = call i32 @myl_qbe_rc_status(ptr %p336, i32 2) nomerge, !dbg !112
  store i32 %call337, ptr %slot54, align 8
  br label %bb_failure
bb_rcgcapacity37:
  %v338 = load i64, ptr %slot52, align 8
  %v339 = load i64, ptr %slot44, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %rgep341 = getelementptr i8, ptr %p340, i64 -24
  store i64 %v338, ptr %rgep341, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore37
bb_rcgstore37:
  %v342 = load i64, ptr %slot44, align 8
  %v343 = load i64, ptr %slot43, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 %v342, ptr %p344, align 8, !alias.scope !3, !noalias !4
  store i32 2, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 16, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 1, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared11
bb_rcprivateprepared11:
  %ld345 = load i32, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld345, ptr %slot55, align 8
  %v346 = load i32, ptr %slot55, align 8
  %cv347 = zext i32 %v346 to i64
  %cond348 = icmp ne i64 %cv347, 0
  br i1 %cond348, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  store i32 0, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot13, align 8
  store i64 %v349, ptr %slot56, align 8
  %ld350 = load i32, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld350, ptr %slot57, align 8
  %v351 = load i32, ptr %slot57, align 8
  %op352 = and i32 %v351, 28
  store i32 %op352, ptr %slot58, align 8
  %v353 = load i32, ptr %slot58, align 8
  %cv354 = zext i32 %v353 to i64
  %cond355 = icmp ne i64 %cv354, 0
  br i1 %cond355, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v356 = load i64, ptr %slot17, align 8
  store i64 %v356, ptr %slot59, align 8
  %v357 = load i64, ptr %slot56, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot60, align 8
  %v360 = load i64, ptr %slot60, align 8
  %cmp361 = icmp ne i64 %v360, 0
  %cv362 = zext i1 %cmp361 to i32
  store i32 %cv362, ptr %slot61, align 8
  %v363 = load i32, ptr %slot61, align 8
  %cv364 = zext i32 %v363 to i64
  %cond365 = icmp ne i64 %cv364, 0
  br i1 %cond365, label %bb_rcgnn107, label %bb_rcgdone107
bb_rcgnn107:
  %v366 = load i64, ptr %slot60, align 8
  %op367 = sub i64 %v366, 16
  store i64 %op367, ptr %slot62, align 8
  %v368 = load i64, ptr %slot60, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %rgep370 = getelementptr i8, ptr %p369, i64 -16
  %ld371 = load i64, ptr %rgep370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld371, ptr %slot63, align 8
  %v372 = load i64, ptr %slot63, align 8
  %op373 = and i64 %v372, 4611686018427387906
  store i64 %op373, ptr %slot64, align 8
  %v374 = load i64, ptr %slot64, align 8
  %cmp375 = icmp ne i64 %v374, 0
  %cv376 = zext i1 %cmp375 to i32
  store i32 %cv376, ptr %slot65, align 8
  %v377 = load i32, ptr %slot65, align 8
  %cv378 = zext i32 %v377 to i64
  %cond379 = icmp ne i64 %cv378, 0
  br i1 %cond379, label %bb_rcgclear107, label %bb_rcgcounted107
bb_rcgcounted107:
  %v380 = load i64, ptr %slot60, align 8
  %op381 = sub i64 %v380, 24
  store i64 %op381, ptr %slot66, align 8
  %v382 = load i64, ptr %slot60, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %rgep384 = getelementptr i8, ptr %p383, i64 -24
  %ld385 = load i64, ptr %rgep384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld385, ptr %slot67, align 8
  %v386 = load i64, ptr %slot67, align 8
  %op387 = sub i64 %v386, 1
  store i64 %op387, ptr %slot68, align 8
  %v388 = load i64, ptr %slot68, align 8
  %cmp389 = icmp eq i64 %v388, 0
  %cv390 = zext i1 %cmp389 to i32
  store i32 %cv390, ptr %slot69, align 8
  %v391 = load i32, ptr %slot69, align 8
  %cv392 = zext i32 %v391 to i64
  %cond393 = icmp ne i64 %cv392, 0
  br i1 %cond393, label %bb_rcglast107, label %bb_rcgdec107
bb_rcglast107:
  %v394 = load i64, ptr %slot60, align 8
  %op395 = sub i64 %v394, 32
  store i64 %op395, ptr %slot70, align 8
  %v396 = load i64, ptr %slot60, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %rgep398 = getelementptr i8, ptr %p397, i64 -32
  %ld399 = load i64, ptr %rgep398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld399, ptr %slot71, align 8
  %v400 = load i64, ptr %slot71, align 8
  %cmp401 = icmp ne i64 %v400, 0
  %cv402 = zext i1 %cmp401 to i32
  store i32 %cv402, ptr %slot72, align 8
  %v403 = load i32, ptr %slot72, align 8
  %cv404 = zext i32 %v403 to i64
  %cond405 = icmp ne i64 %cv404, 0
  br i1 %cond405, label %bb_rcgdec107, label %bb_rcgslow107
bb_rcgslow107:
  %v406 = load i64, ptr %slot59, align 8
  %v407 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v406, i64 %v407) nomerge, !dbg !112
  br label %bb_rcgdone107
bb_rcgdec107:
  %v408 = load i64, ptr %slot68, align 8
  %v409 = load i64, ptr %slot60, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %rgep411 = getelementptr i8, ptr %p410, i64 -24
  store i64 %v408, ptr %rgep411, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear107
bb_rcgclear107:
  %v412 = load i64, ptr %slot56, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 0, ptr %p413, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone107
bb_rcgdone107:
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v414 = load i64, ptr %slot17, align 8
  store i64 %v414, ptr %slot73, align 8
  %v415 = load i64, ptr %slot56, align 8
  %p416 = inttoptr i64 %v415 to ptr
  %ld417 = load i64, ptr %p416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld417, ptr %slot74, align 8
  %v418 = load i64, ptr %slot74, align 8
  %cmp419 = icmp ne i64 %v418, 0
  %cv420 = zext i1 %cmp419 to i32
  store i32 %cv420, ptr %slot75, align 8
  %v421 = load i32, ptr %slot75, align 8
  %cv422 = zext i32 %v421 to i64
  %cond423 = icmp ne i64 %cv422, 0
  br i1 %cond423, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v424 = load i64, ptr %slot74, align 8
  %op425 = sub i64 %v424, 16
  store i64 %op425, ptr %slot76, align 8
  %v426 = load i64, ptr %slot74, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %rgep428 = getelementptr i8, ptr %p427, i64 -16
  %ld429 = load i64, ptr %rgep428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld429, ptr %slot77, align 8
  %v430 = load i64, ptr %slot77, align 8
  %op431 = and i64 %v430, 4611686018427387906
  store i64 %op431, ptr %slot78, align 8
  %v432 = load i64, ptr %slot78, align 8
  %cmp433 = icmp ne i64 %v432, 0
  %cv434 = zext i1 %cmp433 to i32
  store i32 %cv434, ptr %slot79, align 8
  %v435 = load i32, ptr %slot79, align 8
  %cv436 = zext i32 %v435 to i64
  %cond437 = icmp ne i64 %cv436, 0
  br i1 %cond437, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v438 = load i64, ptr %slot74, align 8
  %op439 = sub i64 %v438, 32
  store i64 %op439, ptr %slot80, align 8
  %v440 = load i64, ptr %slot74, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %rgep442 = getelementptr i8, ptr %p441, i64 -32
  %ld443 = load i64, ptr %rgep442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld443, ptr %slot81, align 8
  %v444 = load i64, ptr %slot81, align 8
  %op445 = sub i64 %v444, 1
  store i64 %op445, ptr %slot82, align 8
  %v446 = load i64, ptr %slot82, align 8
  %cmp447 = icmp eq i64 %v446, 0
  %cv448 = zext i1 %cmp447 to i32
  store i32 %cv448, ptr %slot83, align 8
  %v449 = load i32, ptr %slot83, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v452 = load i64, ptr %slot74, align 8
  %op453 = sub i64 %v452, 24
  store i64 %op453, ptr %slot84, align 8
  %v454 = load i64, ptr %slot74, align 8
  %p455 = inttoptr i64 %v454 to ptr
  %rgep456 = getelementptr i8, ptr %p455, i64 -24
  %ld457 = load i64, ptr %rgep456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld457, ptr %slot85, align 8
  %v458 = load i64, ptr %slot85, align 8
  %cmp459 = icmp ne i64 %v458, 0
  %cv460 = zext i1 %cmp459 to i32
  store i32 %cv460, ptr %slot86, align 8
  %v461 = load i32, ptr %slot86, align 8
  %cv462 = zext i32 %v461 to i64
  %cond463 = icmp ne i64 %cv462, 0
  br i1 %cond463, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v464 = load i64, ptr %slot73, align 8
  %v465 = load i64, ptr %slot56, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v464, i64 %v465) nomerge, !dbg !112
  br label %bb_rcgdone122
bb_rcgdec122:
  %v466 = load i64, ptr %slot82, align 8
  %v467 = load i64, ptr %slot74, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %rgep469 = getelementptr i8, ptr %p468, i64 -32
  store i64 %v466, ptr %rgep469, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v470 = load i64, ptr %slot56, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i64 0, ptr %p471, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v472 = load i64, ptr %slot13, align 8
  store i64 %v472, ptr %slot87, align 8
  %v473 = load i64, ptr %slot10, align 8
  store i64 %v473, ptr %slot88, align 8
  %v474 = load i64, ptr %slot88, align 8
  %v475 = load i64, ptr %slot87, align 8
  %p476 = inttoptr i64 %v474 to ptr
  %p477 = inttoptr i64 %v475 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p477, ptr %p476, i64 8, i1 false), !alias.scope !3, !noalias !4
  store i32 0, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  store i32 2, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  %ld478 = load i32, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld478, ptr %slot89, align 8
  %v479 = load i32, ptr %slot89, align 8
  store i32 %v479, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  store i32 1, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  %ld480 = load i64, ptr %mem195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot90, align 8
  %ld481 = load i64, ptr %mem195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld481, ptr %slot91, align 8
  %v482 = load i64, ptr %slot91, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %call484 = call ptr @myl_native_text_payload(ptr %p483) nomerge, !dbg !114
  %calladdr485 = ptrtoint ptr %call484 to i64
  store i64 %calladdr485, ptr %slot92, align 8
  %v486 = load i64, ptr %slot91, align 8
  %op487 = add i64 %v486, 8
  store i64 %op487, ptr %slot93, align 8
  %v488 = load i64, ptr %slot93, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %ld490 = load i64, ptr %p489, align 8
  store i64 %ld490, ptr %slot94, align 8
  %v491 = load i64, ptr %slot92, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %v493 = load i64, ptr %slot94, align 8
  %v494 = load i64, ptr %slot11, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %call496 = call i32 @myl_native_bytes_number_parse(ptr %p492, i64 %v493, i32 0, ptr %p495) nomerge, !dbg !114
  store i32 %call496, ptr %slot95, align 8
  %v497 = load i64, ptr %slot11, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i64, ptr %p498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld499, ptr %slot96, align 8
  %v500 = load i64, ptr %slot16, align 8
  store i64 %v500, ptr %slot97, align 8
  %v501 = load i64, ptr %slot97, align 8
  %p503 = inttoptr i64 %v501 to ptr
  %gep504 = getelementptr i8, ptr %p503, i64 8
  %op502 = ptrtoint ptr %gep504 to i64
  store i64 %op502, ptr %slot98, align 8
  %v505 = load i32, ptr %slot95, align 8
  %cv506 = zext i32 %v505 to i64
  %cond507 = icmp ne i64 %cv506, 0
  br i1 %cond507, label %bb_some143, label %bb_none143
bb_some143:
  %v508 = load i64, ptr %slot97, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i32 1, ptr %p509, align 4, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot96, align 8
  %v511 = load i64, ptr %slot98, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i64 %v510, ptr %p512, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_none143:
  %v513 = load i64, ptr %slot97, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i32 0, ptr %p514, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed143
bb_parsed143:
  %v515 = load i64, ptr %slot97, align 8
  store i64 %v515, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld516 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld516, ptr %slot99, align 8
  %v517 = load i64, ptr %slot99, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i32, ptr %p518, align 4, !alias.scope !3, !noalias !4
  %ext520 = zext i32 %ld519 to i64
  store i64 %ext520, ptr %slot100, align 8
  %v521 = load i64, ptr %slot100, align 8
  %cmp522 = icmp eq i64 %v521, 0
  %cv523 = zext i1 %cmp522 to i64
  store i64 %cv523, ptr %slot101, align 8
  %v524 = load i64, ptr %slot101, align 8
  %cond525 = icmp ne i64 %v524, 0
  br i1 %cond525, label %bb_rcarm146, label %bb_rcarmnext146
bb_rcarm146:
  br label %bb_i6
bb_rcarmnext146:
  %v526 = load i64, ptr %slot100, align 8
  %cmp527 = icmp eq i64 %v526, 1
  %cv528 = zext i1 %cmp527 to i64
  store i64 %cv528, ptr %slot102, align 8
  %v529 = load i64, ptr %slot102, align 8
  %cond530 = icmp ne i64 %v529, 0
  br i1 %cond530, label %bb_rcarm147, label %bb_rcarmnext147
bb_rcarm147:
  %v531 = load i64, ptr %slot10, align 8
  store i64 %v531, ptr %slot103, align 8
  %v532 = load i64, ptr %slot99, align 8
  %op533 = add i64 %v532, 8
  store i64 %op533, ptr %slot104, align 8
  %v534 = load i64, ptr %slot18, align 8
  store i64 %v534, ptr %slot105, align 8
  %v535 = load i64, ptr %slot104, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot106, align 8
  %v538 = load i64, ptr %slot106, align 8
  %v539 = load i64, ptr %slot103, align 8
  %p540 = inttoptr i64 %v539 to ptr
  store i64 %v538, ptr %p540, align 8, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem185, align 4, !alias.scope !3, !noalias !4
  store i32 1, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  %v541 = load i64, ptr %slot103, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot107, align 8
  %v544 = load i64, ptr %slot107, align 8
  store i64 %v544, ptr %mem197, align 8, !alias.scope !3, !noalias !4
  store i32 0, ptr %mem183, align 4, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rcarmnext147:
  br label %bb_failure
bb_i4:
  %ld545 = load i64, ptr %mem197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld545, ptr %slot108, align 8
  %v546 = load i64, ptr %slot108, align 8
  store i64 %v546, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld547 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot109, align 8
  %ld548 = load i32, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld548, ptr %slot110, align 8
  %v549 = load i32, ptr %slot110, align 8
  %cv550 = zext i32 %v549 to i64
  %cond551 = icmp ne i64 %cv550, 0
  br i1 %cond551, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  store i32 0, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot13, align 8
  store i64 %v552, ptr %slot111, align 8
  %ld553 = load i32, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld553, ptr %slot112, align 8
  %v554 = load i32, ptr %slot112, align 8
  %op555 = and i32 %v554, 28
  store i32 %op555, ptr %slot113, align 8
  %v556 = load i32, ptr %slot113, align 8
  %cv557 = zext i32 %v556 to i64
  %cond558 = icmp ne i64 %cv557, 0
  br i1 %cond558, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v559 = load i64, ptr %slot17, align 8
  store i64 %v559, ptr %slot114, align 8
  %v560 = load i64, ptr %slot111, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot115, align 8
  %v563 = load i64, ptr %slot115, align 8
  %cmp564 = icmp ne i64 %v563, 0
  %cv565 = zext i1 %cmp564 to i32
  store i32 %cv565, ptr %slot116, align 8
  %v566 = load i32, ptr %slot116, align 8
  %cv567 = zext i32 %v566 to i64
  %cond568 = icmp ne i64 %cv567, 0
  br i1 %cond568, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v569 = load i64, ptr %slot115, align 8
  %op570 = sub i64 %v569, 16
  store i64 %op570, ptr %slot117, align 8
  %v571 = load i64, ptr %slot115, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %rgep573 = getelementptr i8, ptr %p572, i64 -16
  %ld574 = load i64, ptr %rgep573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld574, ptr %slot118, align 8
  %v575 = load i64, ptr %slot118, align 8
  %op576 = and i64 %v575, 4611686018427387906
  store i64 %op576, ptr %slot119, align 8
  %v577 = load i64, ptr %slot119, align 8
  %cmp578 = icmp ne i64 %v577, 0
  %cv579 = zext i1 %cmp578 to i32
  store i32 %cv579, ptr %slot120, align 8
  %v580 = load i32, ptr %slot120, align 8
  %cv581 = zext i32 %v580 to i64
  %cond582 = icmp ne i64 %cv581, 0
  br i1 %cond582, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v583 = load i64, ptr %slot115, align 8
  %op584 = sub i64 %v583, 24
  store i64 %op584, ptr %slot121, align 8
  %v585 = load i64, ptr %slot115, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %rgep587 = getelementptr i8, ptr %p586, i64 -24
  %ld588 = load i64, ptr %rgep587, align 8, !alias.scope !9, !noalias !10
  store i64 %ld588, ptr %slot122, align 8
  %v589 = load i64, ptr %slot122, align 8
  %op590 = sub i64 %v589, 1
  store i64 %op590, ptr %slot123, align 8
  %v591 = load i64, ptr %slot123, align 8
  %cmp592 = icmp eq i64 %v591, 0
  %cv593 = zext i1 %cmp592 to i32
  store i32 %cv593, ptr %slot124, align 8
  %v594 = load i32, ptr %slot124, align 8
  %cv595 = zext i32 %v594 to i64
  %cond596 = icmp ne i64 %cv595, 0
  br i1 %cond596, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v597 = load i64, ptr %slot115, align 8
  %op598 = sub i64 %v597, 32
  store i64 %op598, ptr %slot125, align 8
  %v599 = load i64, ptr %slot115, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %rgep601 = getelementptr i8, ptr %p600, i64 -32
  %ld602 = load i64, ptr %rgep601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld602, ptr %slot126, align 8
  %v603 = load i64, ptr %slot126, align 8
  %cmp604 = icmp ne i64 %v603, 0
  %cv605 = zext i1 %cmp604 to i32
  store i32 %cv605, ptr %slot127, align 8
  %v606 = load i32, ptr %slot127, align 8
  %cv607 = zext i32 %v606 to i64
  %cond608 = icmp ne i64 %cv607, 0
  br i1 %cond608, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v609 = load i64, ptr %slot114, align 8
  %v610 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v609, i64 %v610) nomerge, !dbg !116
  br label %bb_rcgdone179
bb_rcgdec179:
  %v611 = load i64, ptr %slot123, align 8
  %v612 = load i64, ptr %slot115, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %rgep614 = getelementptr i8, ptr %p613, i64 -24
  store i64 %v611, ptr %rgep614, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v615 = load i64, ptr %slot111, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i64 0, ptr %p616, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v617 = load i64, ptr %slot17, align 8
  store i64 %v617, ptr %slot128, align 8
  %v618 = load i64, ptr %slot111, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %ld620 = load i64, ptr %p619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld620, ptr %slot129, align 8
  %v621 = load i64, ptr %slot129, align 8
  %cmp622 = icmp ne i64 %v621, 0
  %cv623 = zext i1 %cmp622 to i32
  store i32 %cv623, ptr %slot130, align 8
  %v624 = load i32, ptr %slot130, align 8
  %cv625 = zext i32 %v624 to i64
  %cond626 = icmp ne i64 %cv625, 0
  br i1 %cond626, label %bb_rcgnn194, label %bb_rcgdone194
bb_rcgnn194:
  %v627 = load i64, ptr %slot129, align 8
  %op628 = sub i64 %v627, 16
  store i64 %op628, ptr %slot131, align 8
  %v629 = load i64, ptr %slot129, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %rgep631 = getelementptr i8, ptr %p630, i64 -16
  %ld632 = load i64, ptr %rgep631, align 8, !alias.scope !9, !noalias !10
  store i64 %ld632, ptr %slot132, align 8
  %v633 = load i64, ptr %slot132, align 8
  %op634 = and i64 %v633, 4611686018427387906
  store i64 %op634, ptr %slot133, align 8
  %v635 = load i64, ptr %slot133, align 8
  %cmp636 = icmp ne i64 %v635, 0
  %cv637 = zext i1 %cmp636 to i32
  store i32 %cv637, ptr %slot134, align 8
  %v638 = load i32, ptr %slot134, align 8
  %cv639 = zext i32 %v638 to i64
  %cond640 = icmp ne i64 %cv639, 0
  br i1 %cond640, label %bb_rcgclear194, label %bb_rcgcounted194
bb_rcgcounted194:
  %v641 = load i64, ptr %slot129, align 8
  %op642 = sub i64 %v641, 32
  store i64 %op642, ptr %slot135, align 8
  %v643 = load i64, ptr %slot129, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %rgep645 = getelementptr i8, ptr %p644, i64 -32
  %ld646 = load i64, ptr %rgep645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld646, ptr %slot136, align 8
  %v647 = load i64, ptr %slot136, align 8
  %op648 = sub i64 %v647, 1
  store i64 %op648, ptr %slot137, align 8
  %v649 = load i64, ptr %slot137, align 8
  %cmp650 = icmp eq i64 %v649, 0
  %cv651 = zext i1 %cmp650 to i32
  store i32 %cv651, ptr %slot138, align 8
  %v652 = load i32, ptr %slot138, align 8
  %cv653 = zext i32 %v652 to i64
  %cond654 = icmp ne i64 %cv653, 0
  br i1 %cond654, label %bb_rcglast194, label %bb_rcgdec194
bb_rcglast194:
  %v655 = load i64, ptr %slot129, align 8
  %op656 = sub i64 %v655, 24
  store i64 %op656, ptr %slot139, align 8
  %v657 = load i64, ptr %slot129, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %rgep659 = getelementptr i8, ptr %p658, i64 -24
  %ld660 = load i64, ptr %rgep659, align 8, !alias.scope !9, !noalias !10
  store i64 %ld660, ptr %slot140, align 8
  %v661 = load i64, ptr %slot140, align 8
  %cmp662 = icmp ne i64 %v661, 0
  %cv663 = zext i1 %cmp662 to i32
  store i32 %cv663, ptr %slot141, align 8
  %v664 = load i32, ptr %slot141, align 8
  %cv665 = zext i32 %v664 to i64
  %cond666 = icmp ne i64 %cv665, 0
  br i1 %cond666, label %bb_rcgdec194, label %bb_rcgslow194
bb_rcgslow194:
  %v667 = load i64, ptr %slot128, align 8
  %v668 = load i64, ptr %slot111, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v667, i64 %v668) nomerge, !dbg !116
  br label %bb_rcgdone194
bb_rcgdec194:
  %v669 = load i64, ptr %slot137, align 8
  %v670 = load i64, ptr %slot129, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %rgep672 = getelementptr i8, ptr %p671, i64 -32
  store i64 %v669, ptr %rgep672, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear194
bb_rcgclear194:
  %v673 = load i64, ptr %slot111, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i64 0, ptr %p674, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone194
bb_rcgdone194:
  br label %bb_rcslotdone163
bb_rcslotdone163:
  %v675 = load i64, ptr %slot109, align 8
  ret i64 %v675
bb_i6:
  store i64 0, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  %ld676 = load i64, ptr %mem199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot142, align 8
  %ld677 = load i32, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld677, ptr %slot143, align 8
  %v678 = load i32, ptr %slot143, align 8
  %cv679 = zext i32 %v678 to i64
  %cond680 = icmp ne i64 %cv679, 0
  br i1 %cond680, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  store i32 0, ptr %mem177, align 4, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot13, align 8
  store i64 %v681, ptr %slot144, align 8
  %ld682 = load i32, ptr %mem179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld682, ptr %slot145, align 8
  %v683 = load i32, ptr %slot145, align 8
  %op684 = and i32 %v683, 28
  store i32 %op684, ptr %slot146, align 8
  %v685 = load i32, ptr %slot146, align 8
  %cv686 = zext i32 %v685 to i64
  %cond687 = icmp ne i64 %cv686, 0
  br i1 %cond687, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v688 = load i64, ptr %slot17, align 8
  store i64 %v688, ptr %slot147, align 8
  %v689 = load i64, ptr %slot144, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot148, align 8
  %v692 = load i64, ptr %slot148, align 8
  %cmp693 = icmp ne i64 %v692, 0
  %cv694 = zext i1 %cmp693 to i32
  store i32 %cv694, ptr %slot149, align 8
  %v695 = load i32, ptr %slot149, align 8
  %cv696 = zext i32 %v695 to i64
  %cond697 = icmp ne i64 %cv696, 0
  br i1 %cond697, label %bb_rcgnn257, label %bb_rcgdone257
bb_rcgnn257:
  %v698 = load i64, ptr %slot148, align 8
  %op699 = sub i64 %v698, 16
  store i64 %op699, ptr %slot150, align 8
  %v700 = load i64, ptr %slot148, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %rgep702 = getelementptr i8, ptr %p701, i64 -16
  %ld703 = load i64, ptr %rgep702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld703, ptr %slot151, align 8
  %v704 = load i64, ptr %slot151, align 8
  %op705 = and i64 %v704, 4611686018427387906
  store i64 %op705, ptr %slot152, align 8
  %v706 = load i64, ptr %slot152, align 8
  %cmp707 = icmp ne i64 %v706, 0
  %cv708 = zext i1 %cmp707 to i32
  store i32 %cv708, ptr %slot153, align 8
  %v709 = load i32, ptr %slot153, align 8
  %cv710 = zext i32 %v709 to i64
  %cond711 = icmp ne i64 %cv710, 0
  br i1 %cond711, label %bb_rcgclear257, label %bb_rcgcounted257
bb_rcgcounted257:
  %v712 = load i64, ptr %slot148, align 8
  %op713 = sub i64 %v712, 24
  store i64 %op713, ptr %slot154, align 8
  %v714 = load i64, ptr %slot148, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %rgep716 = getelementptr i8, ptr %p715, i64 -24
  %ld717 = load i64, ptr %rgep716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld717, ptr %slot155, align 8
  %v718 = load i64, ptr %slot155, align 8
  %op719 = sub i64 %v718, 1
  store i64 %op719, ptr %slot156, align 8
  %v720 = load i64, ptr %slot156, align 8
  %cmp721 = icmp eq i64 %v720, 0
  %cv722 = zext i1 %cmp721 to i32
  store i32 %cv722, ptr %slot157, align 8
  %v723 = load i32, ptr %slot157, align 8
  %cv724 = zext i32 %v723 to i64
  %cond725 = icmp ne i64 %cv724, 0
  br i1 %cond725, label %bb_rcglast257, label %bb_rcgdec257
bb_rcglast257:
  %v726 = load i64, ptr %slot148, align 8
  %op727 = sub i64 %v726, 32
  store i64 %op727, ptr %slot158, align 8
  %v728 = load i64, ptr %slot148, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %rgep730 = getelementptr i8, ptr %p729, i64 -32
  %ld731 = load i64, ptr %rgep730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld731, ptr %slot159, align 8
  %v732 = load i64, ptr %slot159, align 8
  %cmp733 = icmp ne i64 %v732, 0
  %cv734 = zext i1 %cmp733 to i32
  store i32 %cv734, ptr %slot160, align 8
  %v735 = load i32, ptr %slot160, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcgdec257, label %bb_rcgslow257
bb_rcgslow257:
  %v738 = load i64, ptr %slot147, align 8
  %v739 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v738, i64 %v739) nomerge, !dbg !118
  br label %bb_rcgdone257
bb_rcgdec257:
  %v740 = load i64, ptr %slot156, align 8
  %v741 = load i64, ptr %slot148, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %rgep743 = getelementptr i8, ptr %p742, i64 -24
  store i64 %v740, ptr %rgep743, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear257
bb_rcgclear257:
  %v744 = load i64, ptr %slot144, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 0, ptr %p745, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone257
bb_rcgdone257:
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v746 = load i64, ptr %slot17, align 8
  store i64 %v746, ptr %slot161, align 8
  %v747 = load i64, ptr %slot144, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i64, ptr %p748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld749, ptr %slot162, align 8
  %v750 = load i64, ptr %slot162, align 8
  %cmp751 = icmp ne i64 %v750, 0
  %cv752 = zext i1 %cmp751 to i32
  store i32 %cv752, ptr %slot163, align 8
  %v753 = load i32, ptr %slot163, align 8
  %cv754 = zext i32 %v753 to i64
  %cond755 = icmp ne i64 %cv754, 0
  br i1 %cond755, label %bb_rcgnn272, label %bb_rcgdone272
bb_rcgnn272:
  %v756 = load i64, ptr %slot162, align 8
  %op757 = sub i64 %v756, 16
  store i64 %op757, ptr %slot164, align 8
  %v758 = load i64, ptr %slot162, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %rgep760 = getelementptr i8, ptr %p759, i64 -16
  %ld761 = load i64, ptr %rgep760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld761, ptr %slot165, align 8
  %v762 = load i64, ptr %slot165, align 8
  %op763 = and i64 %v762, 4611686018427387906
  store i64 %op763, ptr %slot166, align 8
  %v764 = load i64, ptr %slot166, align 8
  %cmp765 = icmp ne i64 %v764, 0
  %cv766 = zext i1 %cmp765 to i32
  store i32 %cv766, ptr %slot167, align 8
  %v767 = load i32, ptr %slot167, align 8
  %cv768 = zext i32 %v767 to i64
  %cond769 = icmp ne i64 %cv768, 0
  br i1 %cond769, label %bb_rcgclear272, label %bb_rcgcounted272
bb_rcgcounted272:
  %v770 = load i64, ptr %slot162, align 8
  %op771 = sub i64 %v770, 32
  store i64 %op771, ptr %slot168, align 8
  %v772 = load i64, ptr %slot162, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %rgep774 = getelementptr i8, ptr %p773, i64 -32
  %ld775 = load i64, ptr %rgep774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld775, ptr %slot169, align 8
  %v776 = load i64, ptr %slot169, align 8
  %op777 = sub i64 %v776, 1
  store i64 %op777, ptr %slot170, align 8
  %v778 = load i64, ptr %slot170, align 8
  %cmp779 = icmp eq i64 %v778, 0
  %cv780 = zext i1 %cmp779 to i32
  store i32 %cv780, ptr %slot171, align 8
  %v781 = load i32, ptr %slot171, align 8
  %cv782 = zext i32 %v781 to i64
  %cond783 = icmp ne i64 %cv782, 0
  br i1 %cond783, label %bb_rcglast272, label %bb_rcgdec272
bb_rcglast272:
  %v784 = load i64, ptr %slot162, align 8
  %op785 = sub i64 %v784, 24
  store i64 %op785, ptr %slot172, align 8
  %v786 = load i64, ptr %slot162, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %rgep788 = getelementptr i8, ptr %p787, i64 -24
  %ld789 = load i64, ptr %rgep788, align 8, !alias.scope !9, !noalias !10
  store i64 %ld789, ptr %slot173, align 8
  %v790 = load i64, ptr %slot173, align 8
  %cmp791 = icmp ne i64 %v790, 0
  %cv792 = zext i1 %cmp791 to i32
  store i32 %cv792, ptr %slot174, align 8
  %v793 = load i32, ptr %slot174, align 8
  %cv794 = zext i32 %v793 to i64
  %cond795 = icmp ne i64 %cv794, 0
  br i1 %cond795, label %bb_rcgdec272, label %bb_rcgslow272
bb_rcgslow272:
  %v796 = load i64, ptr %slot161, align 8
  %v797 = load i64, ptr %slot144, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v796, i64 %v797) nomerge, !dbg !118
  br label %bb_rcgdone272
bb_rcgdec272:
  %v798 = load i64, ptr %slot170, align 8
  %v799 = load i64, ptr %slot162, align 8
  %p800 = inttoptr i64 %v799 to ptr
  %rgep801 = getelementptr i8, ptr %p800, i64 -32
  store i64 %v798, ptr %rgep801, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear272
bb_rcgclear272:
  %v802 = load i64, ptr %slot144, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i64 0, ptr %p803, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone272
bb_rcgdone272:
  br label %bb_rcslotdone241
bb_rcslotdone241:
  %v804 = load i64, ptr %slot142, align 8
  ret i64 %v804
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_text_payload(ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", linkageName: "myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3519549293126700163, i64 0, !"myl_f_b09f29efbbc619dfba8ae868481552f0edb3b268eea9cb9716361714c70d0deb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
