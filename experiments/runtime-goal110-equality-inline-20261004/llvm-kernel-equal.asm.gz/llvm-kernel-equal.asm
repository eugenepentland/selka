000000000104ea60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104ea60:	push   %rbp
 104ea61:	push   %r15
 104ea63:	push   %r14
 104ea65:	push   %r13
 104ea67:	push   %r12
 104ea69:	push   %rbx
 104ea6a:	sub    $0x258,%rsp
 104ea71:	mov    %r8,0x18(%rsp)
 104ea76:	mov    %rcx,0x20(%rsp)
 104ea7b:	mov    %rdi,%r14
 104ea7e:	cmp    %rsp,0x40(%rdi)
 104ea82:	ja     105143a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29da>
 104ea88:	mov    %rdx,%r15
 104ea8b:	mov    %rsi,%rbx
 104ea8e:	movabs $0x4000000000000002,%r12
 104ea98:	movq   $0x0,0xa0(%rsp)
 104eaa4:	movq   $0x0,0x98(%rsp)
 104eab0:	lea    0x258(%r14),%rax
 104eab7:	mov    %rax,0x10(%rsp)
 104eabc:	mov    0x2c8(%r14),%ebp
 104eac3:	movq   $0x10b97e0,0x40(%rsp)
 104eacc:	movq   $0x10b97e0,0x70(%rsp)
 104ead5:	mov    $0x10b97e0,%esi
 104eada:	mov    %rbx,%rdi
 104eadd:	call   1091d50 <myl_native_text_equal>
 104eae2:	test   %r12,0x6ace7(%rip)        # 10b97d0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104eae9:	mov    %r14,0x8(%rsp)
 104eaee:	jne    104eb11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb1>
 104eaf0:	mov    0x6acc9(%rip),%rcx        # 10b97c0 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104eaf7:	dec    %rcx
 104eafa:	jne    104eb0a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaa>
 104eafc:	cmpq   $0x0,0x6acc4(%rip)        # 10b97c8 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104eb04:	je     104f0d8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x678>
 104eb0a:	mov    %rcx,0x6acaf(%rip)        # 10b97c0 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104eb11:	movq   $0x0,0xc8(%rsp)
 104eb1d:	test   %eax,%eax
 104eb1f:	mov    %r15,0x30(%rsp)
 104eb24:	je     104f115 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b5>
 104eb2a:	xor    %ebp,%ebp
 104eb2c:	movabs $0x89705f3112a28fe5,%r15
 104eb36:	movabs $0xffffffffffffff0,%r12
 104eb40:	vpxor  %xmm11,%xmm11,%xmm11
 104eb45:	vmovd  -0x4d1ad(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104eb4d:	vmovd  -0x4d165(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104eb55:	vmovd  -0x4d1dd(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104eb5d:	vmovd  -0x4d245(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104eb65:	xor    %ebx,%ebx
 104eb67:	movabs $0x4000000000000002,%rdi
 104eb71:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb80:	mov    0x18(%rsp),%rdx
 104eb85:	add    %rbx,%rdx
 104eb88:	jo     1051387 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2927>
 104eb8e:	mov    0x30(%rsp),%rax
 104eb93:	mov    (%rax),%rsi
 104eb96:	mov    -0x10(%rsi),%rax
 104eb9a:	test   %rdi,%rax
 104eb9d:	jne    104ebb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x150>
 104eb9f:	mov    -0x18(%rsi),%rcx
 104eba3:	inc    %rcx
 104eba6:	je     104f08f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x62f>
 104ebac:	mov    %rcx,-0x18(%rsi)
 104ebb0:	movzbl %dl,%r8d
 104ebb4:	mov    (%rsi),%rdi
 104ebb7:	lea    -0x10(%rdi),%r9
 104ebbb:	cmp    %r12,%r9
 104ebbe:	ja     104ec00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a0>
 104ebc0:	mov    0x20(%rsi),%rcx
 104ebc4:	movabs $0x80808080808080,%r10
 104ebce:	cmp    %r10,%rdi
 104ebd1:	ja     104ec30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0>
 104ebd3:	vmovd  %edx,%xmm0
 104ebd7:	vpbroadcastb %xmm0,%xmm0
 104ebdc:	mov    %r9d,%r8d
 104ebdf:	not    %r8d
 104ebe2:	test   $0x30,%r8b
 104ebe6:	jne    104ed69 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x309>
 104ebec:	vpxor  %xmm1,%xmm1,%xmm1
 104ebf0:	jmp    104edc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x360>
 104ebf5:	data16 cs nopw 0x0(%rax,%rax,1)
 104ec00:	test   %rdi,%rdi
 104ec03:	jle    104ed61 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x301>
 104ec09:	mov    0x20(%rsi),%rcx
 104ec0d:	cmp    $0x8,%rdi
 104ec11:	jae    104ec30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0>
 104ec13:	mov    $0x1,%r10d
 104ec19:	xor    %r9d,%r9d
 104ec1c:	xor    %edx,%edx
 104ec1e:	xor    %r14d,%r14d
 104ec21:	jmp    104ecd7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x277>
 104ec26:	cs nopw 0x0(%rax,%rax,1)
 104ec30:	mov    %rdi,%rdx
 104ec33:	and    $0xfffffffffffffff8,%rdx
 104ec37:	vmovq  %r8,%xmm0
 104ec3c:	vpbroadcastq %xmm0,%ymm3
 104ec41:	vpxor  %xmm2,%xmm2,%xmm2
 104ec45:	xor    %r9d,%r9d
 104ec48:	vpxor  %xmm4,%xmm4,%xmm4
 104ec4c:	vpxor  %xmm0,%xmm0,%xmm0
 104ec50:	vpxor  %xmm1,%xmm1,%xmm1
 104ec54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ec60:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104ec66:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104ec6d:	vpxor  %ymm5,%ymm3,%ymm5
 104ec71:	vpxor  %ymm6,%ymm3,%ymm6
 104ec75:	vpaddq %ymm2,%ymm5,%ymm2
 104ec79:	vpaddq %ymm4,%ymm6,%ymm4
 104ec7d:	vpaddq %ymm0,%ymm5,%ymm0
 104ec81:	vpaddq %ymm1,%ymm6,%ymm1
 104ec85:	add    $0x8,%r9
 104ec89:	cmp    %r9,%rdx
 104ec8c:	jne    104ec60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x200>
 104ec8e:	vpaddq %ymm2,%ymm4,%ymm2
 104ec92:	vextracti128 $0x1,%ymm2,%xmm3
 104ec98:	vpaddq %xmm3,%xmm2,%xmm2
 104ec9c:	vpshufd $0xee,%xmm2,%xmm3
 104eca1:	vpaddq %xmm3,%xmm2,%xmm2
 104eca5:	vmovq  %xmm2,%r9
 104ecaa:	vpaddq %ymm0,%ymm1,%ymm0
 104ecae:	vextracti128 $0x1,%ymm0,%xmm1
 104ecb4:	vpaddq %xmm1,%xmm0,%xmm0
 104ecb8:	vpshufd $0xee,%xmm0,%xmm1
 104ecbd:	vpaddq %xmm1,%xmm0,%xmm0
 104ecc1:	vmovq  %xmm0,%r14
 104ecc6:	cmp    %rdx,%rdi
 104ecc9:	jne    104ecd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x270>
 104eccb:	mov    %rdi,%rcx
 104ecce:	jmp    104ed0d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ad>
 104ecd0:	mov    %rdx,%r10
 104ecd3:	or     $0x1,%r10
 104ecd7:	add    %rdx,%rcx
 104ecda:	mov    %rdi,%r11
 104ecdd:	sub    %rdx,%r11
 104ece0:	xor    %edx,%edx
 104ece2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ecf0:	movzbl (%rcx,%rdx,1),%r13d
 104ecf5:	xor    %r8,%r13
 104ecf8:	add    %r13,%r9
 104ecfb:	add    %r13,%r14
 104ecfe:	inc    %rdx
 104ed01:	cmp    %rdx,%r11
 104ed04:	jne    104ecf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ed06:	lea    (%r10,%rdx,1),%rcx
 104ed0a:	dec    %rcx
 104ed0d:	mov    $0xffffffff,%edx
 104ed12:	cmp    %rdx,%rcx
 104ed15:	setb   %cl
 104ed18:	test   %r9,%r9
 104ed1b:	setns  %dl
 104ed1e:	test   %dl,%cl
 104ed20:	jne    104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed26:	mov    0x20(%rsi),%r9
 104ed2a:	xor    %r10d,%r10d
 104ed2d:	xor    %edx,%edx
 104ed2f:	xor    %r14d,%r14d
 104ed32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed40:	movzbl (%r9,%r10,1),%ecx
 104ed45:	xor    %r8,%rcx
 104ed48:	add    %rcx,%r14
 104ed4b:	jo     1051378 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2918>
 104ed51:	inc    %r10
 104ed54:	mov    %r14,%rdx
 104ed57:	cmp    %r10,%rdi
 104ed5a:	jne    104ed40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e0>
 104ed5c:	jmp    104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed61:	xor    %r14d,%r14d
 104ed64:	jmp    104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed69:	mov    %r9d,%r8d
 104ed6c:	shr    $0x4,%r8d
 104ed70:	inc    %r8d
 104ed73:	and    $0x3,%r8d
 104ed77:	vpxor  %xmm1,%xmm1,%xmm1
 104ed7b:	mov    %r8,%r10
 104ed7e:	mov    %rcx,%r11
 104ed81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed90:	vpxor  (%r11),%xmm0,%xmm2
 104ed95:	vpsadbw %xmm2,%xmm11,%xmm2
 104ed99:	vpaddq %xmm1,%xmm2,%xmm1
 104ed9d:	add    $0x10,%r11
 104eda1:	dec    %r10
 104eda4:	jne    104ed90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x330>
 104eda6:	shl    $0x4,%r8d
 104edaa:	add    %r8,%rcx
 104edad:	sub    %r8,%rdi
 104edb0:	cmp    $0x30,%r9
 104edb4:	jb     104ee01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a1>
 104edb6:	cs nopw 0x0(%rax,%rax,1)
 104edc0:	vpxor  (%rcx),%xmm0,%xmm2
 104edc4:	vpsadbw %xmm2,%xmm11,%xmm2
 104edc8:	vpaddq %xmm1,%xmm2,%xmm1
 104edcc:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104edd1:	vpsadbw %xmm2,%xmm11,%xmm2
 104edd5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104edda:	vpsadbw %xmm3,%xmm11,%xmm3
 104edde:	vpaddq %xmm2,%xmm3,%xmm2
 104ede2:	vpaddq %xmm1,%xmm2,%xmm1
 104ede6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104edeb:	vpsadbw %xmm2,%xmm11,%xmm2
 104edef:	vpaddq %xmm1,%xmm2,%xmm1
 104edf3:	add    $0x40,%rcx
 104edf7:	add    $0xffffffffffffffc0,%rdi
 104edfb:	cmp    $0xf,%rdi
 104edff:	ja     104edc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x360>
 104ee01:	vpshufd $0xee,%xmm1,%xmm0
 104ee06:	vpaddq %xmm0,%xmm1,%xmm0
 104ee0a:	vmovq  %xmm0,%r14
 104ee0f:	test   %rdi,%rdi
 104ee12:	je     104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ee18:	mov    %rdi,%r11
 104ee1b:	and    $0x3,%r11
 104ee1f:	je     104ee5d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3fd>
 104ee21:	xor    %r8d,%r8d
 104ee24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ee30:	movzbl (%rcx,%r8,1),%r9d
 104ee35:	xor    %dl,%r9b
 104ee38:	movzbl %r9b,%r9d
 104ee3c:	add    %r9,%r14
 104ee3f:	inc    %r8
 104ee42:	cmp    %r8,%r11
 104ee45:	jne    104ee30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3d0>
 104ee47:	mov    %rdi,%r8
 104ee4a:	and    $0xfffffffffffffffc,%r8
 104ee4e:	lea    (%rcx,%r11,1),%r9
 104ee52:	cmp    $0x4,%rdi
 104ee56:	jae    104ee6d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x40d>
 104ee58:	jmp    104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ee5d:	mov    %rcx,%r9
 104ee60:	mov    %rdi,%r8
 104ee63:	cmp    $0x4,%rdi
 104ee67:	jb     104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ee6d:	lea    -0x4(%r8),%rdi
 104ee71:	cmp    $0x1c,%rdi
 104ee75:	jb     104ef8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x52b>
 104ee7b:	shr    $0x2,%rdi
 104ee7f:	inc    %rdi
 104ee82:	mov    %rdi,%r10
 104ee85:	and    $0xfffffffffffffff8,%r10
 104ee89:	lea    0x0(,%r10,4),%r13
 104ee91:	lea    (%r9,%r10,4),%r9
 104ee95:	sub    %r13,%r8
 104ee98:	vmovq  %r14,%xmm1
 104ee9d:	vmovd  %edx,%xmm0
 104eea1:	vpbroadcastb %xmm0,%xmm0
 104eea6:	add    %r11,%rcx
 104eea9:	add    $0x10,%rcx
 104eead:	vpxor  %xmm2,%xmm2,%xmm2
 104eeb1:	xor    %r11d,%r11d
 104eeb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eec0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104eec7:	vmovdqu (%rcx,%r11,4),%xmm4
 104eecd:	vpshufb %xmm12,%xmm3,%xmm5
 104eed2:	vpshufb %xmm13,%xmm3,%xmm6
 104eed7:	vpshufb %xmm14,%xmm3,%xmm7
 104eedc:	vpshufb %xmm15,%xmm3,%xmm3
 104eee1:	vpshufb %xmm12,%xmm4,%xmm8
 104eee6:	vpshufb %xmm13,%xmm4,%xmm9
 104eeeb:	vpshufb %xmm14,%xmm4,%xmm10
 104eef0:	vpshufb %xmm15,%xmm4,%xmm4
 104eef5:	vpxor  %xmm0,%xmm5,%xmm5
 104eef9:	vpxor  %xmm0,%xmm8,%xmm8
 104eefd:	vpmovzxbq %xmm5,%ymm5
 104ef02:	vpaddq %ymm5,%ymm1,%ymm1
 104ef06:	vpmovzxbq %xmm8,%ymm5
 104ef0b:	vpaddq %ymm5,%ymm2,%ymm2
 104ef0f:	vpxor  %xmm0,%xmm6,%xmm5
 104ef13:	vpxor  %xmm0,%xmm9,%xmm6
 104ef17:	vpmovzxbq %xmm5,%ymm5
 104ef1c:	vpmovzxbq %xmm6,%ymm6
 104ef21:	vpxor  %xmm0,%xmm7,%xmm7
 104ef25:	vpxor  %xmm0,%xmm10,%xmm8
 104ef29:	vpmovzxbq %xmm7,%ymm7
 104ef2e:	vpaddq %ymm7,%ymm5,%ymm5
 104ef32:	vpaddq %ymm5,%ymm1,%ymm1
 104ef36:	vpmovzxbq %xmm8,%ymm5
 104ef3b:	vpaddq %ymm5,%ymm6,%ymm5
 104ef3f:	vpaddq %ymm5,%ymm2,%ymm2
 104ef43:	vpxor  %xmm0,%xmm3,%xmm3
 104ef47:	vpxor  %xmm0,%xmm4,%xmm4
 104ef4b:	vpmovzxbq %xmm3,%ymm3
 104ef50:	vpaddq %ymm3,%ymm1,%ymm1
 104ef54:	vpmovzxbq %xmm4,%ymm3
 104ef59:	vpaddq %ymm3,%ymm2,%ymm2
 104ef5d:	add    $0x8,%r11
 104ef61:	cmp    %r11,%r10
 104ef64:	jne    104eec0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x460>
 104ef6a:	vpaddq %ymm1,%ymm2,%ymm0
 104ef6e:	vextracti128 $0x1,%ymm0,%xmm1
 104ef74:	vpaddq %xmm1,%xmm0,%xmm0
 104ef78:	vpshufd $0xee,%xmm0,%xmm1
 104ef7d:	vpaddq %xmm1,%xmm0,%xmm0
 104ef81:	vmovq  %xmm0,%r14
 104ef86:	cmp    %r10,%rdi
 104ef89:	je     104efd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ef8b:	vmovd  %edx,%xmm0
 104ef8f:	vpbroadcastb %xmm0,%xmm0
 104ef94:	xor    %ecx,%ecx
 104ef96:	cs nopw 0x0(%rax,%rax,1)
 104efa0:	vmovd  (%r9,%rcx,1),%xmm1
 104efa6:	vpxor  %xmm0,%xmm1,%xmm1
 104efaa:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104efb0:	vpsadbw %xmm1,%xmm11,%xmm1
 104efb4:	vmovq  %xmm1,%rdx
 104efb9:	add    %rdx,%r14
 104efbc:	add    $0x4,%rcx
 104efc0:	cmp    %rcx,%r8
 104efc3:	jne    104efa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x540>
 104efc5:	data16 cs nopw 0x0(%rax,%rax,1)
 104efd0:	movabs $0x4000000000000002,%rdi
 104efda:	test   %rdi,%rax
 104efdd:	jne    104eff3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104efdf:	mov    -0x18(%rsi),%rax
 104efe3:	dec    %rax
 104efe6:	jne    104efef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x58f>
 104efe8:	cmpq   $0x0,-0x20(%rsi)
 104efed:	je     104f043 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5e3>
 104efef:	mov    %rax,-0x18(%rsi)
 104eff3:	mov    %rbp,%rcx
 104eff6:	add    %r14,%rcx
 104eff9:	jo     105139e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293e>
 104efff:	mov    %rcx,%rax
 104f002:	imul   %r15
 104f005:	add    %rcx,%rdx
 104f008:	mov    %rdx,%rax
 104f00b:	shr    $0x3f,%rax
 104f00f:	sar    $0x1d,%rdx
 104f013:	add    %rax,%rdx
 104f016:	imul   $0x3b9aca07,%rdx,%rax
 104f01d:	sub    %rax,%rcx
 104f020:	mov    %rcx,%rbp
 104f023:	sar    $0x3f,%rbp
 104f027:	and    $0x3b9aca07,%ebp
 104f02d:	add    %rcx,%rbp
 104f030:	inc    %rbx
 104f033:	cmp    0x20(%rsp),%rbx
 104f038:	jne    104eb80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x120>
 104f03e:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f043:	mov    0x10(%rsp),%r13
 104f048:	mov    %r13,%rdi
 104f04b:	vzeroupper
 104f04e:	call   1099df0 <myl_rc_hold_edge_release>
 104f053:	mov    %r13,%rdi
 104f056:	call   109ce10 <myl_rc_drain>
 104f05b:	vmovd  -0x4d743(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104f063:	vmovd  -0x4d6eb(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104f06b:	vmovd  -0x4d683(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104f073:	vmovd  -0x4d6db(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104f07b:	vpxor  %xmm11,%xmm11,%xmm11
 104f080:	movabs $0x4000000000000002,%rdi
 104f08a:	jmp    104eff3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104f08f:	mov    $0x1007dbf,%esi
 104f094:	mov    0x8(%rsp),%rdi
 104f099:	vzeroupper
 104f09c:	call   108a70e <fail>
 104f0a1:	vmovd  -0x4d789(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104f0a9:	vmovd  -0x4d731(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104f0b1:	vmovd  -0x4d6c9(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104f0b9:	vmovd  -0x4d721(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104f0c1:	vpxor  %xmm11,%xmm11,%xmm11
 104f0c6:	movabs $0x4000000000000002,%rdi
 104f0d0:	xor    %r14d,%r14d
 104f0d3:	jmp    104eff3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104f0d8:	mov    $0x10b97e0,%esi
 104f0dd:	mov    0x10(%rsp),%r14
 104f0e2:	mov    %r14,%rdi
 104f0e5:	mov    %ebp,%r12d
 104f0e8:	mov    %eax,%ebp
 104f0ea:	call   1099c90 <myl_rc_edge_release>
 104f0ef:	movq   $0x0,0xc8(%rsp)
 104f0fb:	mov    %r14,%rdi
 104f0fe:	call   109ce10 <myl_rc_drain>
 104f103:	mov    %ebp,%eax
 104f105:	mov    %r12d,%ebp
 104f108:	test   %eax,%eax
 104f10a:	mov    %r15,0x30(%rsp)
 104f10f:	jne    104eb2a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xca>
 104f115:	movq   $0x10b92f0,0x40(%rsp)
 104f11e:	movq   $0x10b92f0,0x70(%rsp)
 104f127:	movq   $0x10b92f0,0xc8(%rsp)
 104f133:	mov    $0x10b92f0,%esi
 104f138:	mov    %rbx,%rdi
 104f13b:	call   1091d50 <myl_native_text_equal>
 104f140:	movabs $0x4000000000000002,%rcx
 104f14a:	test   %rcx,0x6a18f(%rip)        # 10b92e0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f151:	jne    104f174 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x714>
 104f153:	mov    0x6a176(%rip),%rcx        # 10b92d0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f15a:	dec    %rcx
 104f15d:	jne    104f16d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x70d>
 104f15f:	cmpq   $0x0,0x6a171(%rip)        # 10b92d8 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104f167:	je     104f289 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x829>
 104f16d:	mov    %rcx,0x6a15c(%rip)        # 10b92d0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f174:	test   %eax,%eax
 104f176:	je     104f2ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x84d>
 104f17c:	mov    0x8(%r15),%rax
 104f180:	mov    0x18(%rsp),%rsi
 104f185:	and    $0x3,%esi
 104f188:	mov    (%rax),%rdx
 104f18b:	cmp    %rdx,%rsi
 104f18e:	jae    10513d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2972>
 104f194:	mov    0x10(%r15),%rcx
 104f198:	mov    (%rcx),%rdx
 104f19b:	cmp    %rdx,%rsi
 104f19e:	jae    10513dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x297c>
 104f1a4:	mov    0x20(%rax),%rax
 104f1a8:	shl    $0x3,%esi
 104f1ab:	mov    (%rax,%rsi,1),%rdi
 104f1af:	mov    0x20(%rcx),%rax
 104f1b3:	mov    (%rax,%rsi,1),%rsi
 104f1b7:	call   1091d50 <myl_native_text_equal>
 104f1bc:	mov    %eax,%ebp
 104f1be:	cmpq   $0x1,0x20(%rsp)
 104f1c4:	je     104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f1ca:	mov    $0x1,%ebx
 104f1cf:	movabs $0x89705f3112a28fe5,%r14
 104f1d9:	nopl   0x0(%rax)
 104f1e0:	mov    0x18(%rsp),%rsi
 104f1e5:	add    %rbx,%rsi
 104f1e8:	jo     10513e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2986>
 104f1ee:	mov    0x30(%rsp),%rcx
 104f1f3:	mov    0x8(%rcx),%rax
 104f1f7:	and    $0x3,%esi
 104f1fa:	mov    (%rax),%rdx
 104f1fd:	cmp    %rdx,%rsi
 104f200:	jae    10513d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2972>
 104f206:	mov    0x10(%rcx),%rcx
 104f20a:	mov    (%rcx),%rdx
 104f20d:	cmp    %rdx,%rsi
 104f210:	jae    10513dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x297c>
 104f216:	mov    0x20(%rax),%rax
 104f21a:	shl    $0x3,%esi
 104f21d:	mov    (%rax,%rsi,1),%rdi
 104f221:	mov    0x20(%rcx),%rax
 104f225:	mov    (%rax,%rsi,1),%rsi
 104f229:	call   1091d50 <myl_native_text_equal>
 104f22e:	mov    %eax,%eax
 104f230:	add    %rax,%rbp
 104f233:	mov    %rbp,%rax
 104f236:	imul   %r14
 104f239:	add    %rbp,%rdx
 104f23c:	mov    %rdx,%rax
 104f23f:	shr    $0x3f,%rax
 104f243:	sar    $0x1d,%rdx
 104f247:	add    %rax,%rdx
 104f24a:	imul   $0x3b9aca07,%rdx,%rax
 104f251:	sub    %rax,%rbp
 104f254:	mov    %rbp,%rax
 104f257:	sar    $0x3f,%rax
 104f25b:	and    $0x3b9aca07,%eax
 104f260:	add    %rax,%rbp
 104f263:	inc    %rbx
 104f266:	cmp    %rbx,0x20(%rsp)
 104f26b:	jne    104f1e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x780>
 104f271:	mov    %rbp,%rax
 104f274:	add    $0x258,%rsp
 104f27b:	pop    %rbx
 104f27c:	pop    %r12
 104f27e:	pop    %r13
 104f280:	pop    %r14
 104f282:	pop    %r15
 104f284:	pop    %rbp
 104f285:	vzeroupper
 104f288:	ret
 104f289:	lea    0xc8(%rsp),%rsi
 104f291:	mov    0x10(%rsp),%rdi
 104f296:	mov    %ebp,%r14d
 104f299:	mov    %eax,%ebp
 104f29b:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f2a0:	mov    %ebp,%eax
 104f2a2:	mov    %r14d,%ebp
 104f2a5:	test   %eax,%eax
 104f2a7:	jne    104f17c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x71c>
 104f2ad:	movq   $0x10b9140,0x70(%rsp)
 104f2b6:	movq   $0x10b9140,0xc8(%rsp)
 104f2c2:	mov    $0x10b9140,%esi
 104f2c7:	mov    %rbx,%rdi
 104f2ca:	call   1091d50 <myl_native_text_equal>
 104f2cf:	movabs $0x4000000000000002,%rdi
 104f2d9:	test   %rdi,0x69e50(%rip)        # 10b9130 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f2e0:	jne    104f303 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8a3>
 104f2e2:	mov    0x69e37(%rip),%rcx        # 10b9120 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f2e9:	dec    %rcx
 104f2ec:	jne    104f2fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x89c>
 104f2ee:	cmpq   $0x0,0x69e32(%rip)        # 10b9128 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f2f6:	je     104f4d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa73>
 104f2fc:	mov    %rcx,0x69e1d(%rip)        # 10b9120 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f303:	test   %eax,%eax
 104f305:	je     104f501 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaa1>
 104f30b:	xor    %ebp,%ebp
 104f30d:	movabs $0x89705f3112a28fe5,%r13
 104f317:	xor    %ebx,%ebx
 104f319:	nopl   0x0(%rax)
 104f320:	mov    0x18(%rsp),%rsi
 104f325:	add    %rbx,%rsi
 104f328:	jo     10513fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x299a>
 104f32e:	mov    0x30(%rsp),%rcx
 104f333:	mov    0x8(%rcx),%rax
 104f337:	cmpq   $0x0,(%rax)
 104f33b:	je     105140e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ae>
 104f341:	mov    0x20(%rax),%rax
 104f345:	mov    (%rax),%r14
 104f348:	test   %r14,%r14
 104f34b:	je     104f364 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x904>
 104f34d:	test   %rdi,-0x10(%r14)
 104f351:	jne    104f364 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x904>
 104f353:	mov    -0x18(%r14),%rax
 104f357:	inc    %rax
 104f35a:	je     1050ace <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x206e>
 104f360:	mov    %rax,-0x18(%r14)
 104f364:	mov    %r14,0x70(%rsp)
 104f369:	mov    0x10(%rcx),%rax
 104f36d:	and    $0x3,%esi
 104f370:	mov    (%rax),%rdx
 104f373:	cmp    %rdx,%rsi
 104f376:	jae    105141c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29bc>
 104f37c:	mov    0x20(%rax),%rax
 104f380:	mov    (%rax,%rsi,8),%rax
 104f384:	mov    (%rax),%rcx
 104f387:	test   %rcx,%rcx
 104f38a:	je     104f3c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x960>
 104f38c:	mov    $0xffffffffffffffff,%r15
 104f393:	cmp    (%r14),%rcx
 104f396:	ja     104f420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f39c:	mov    0x10(%r14),%r12d
 104f3a0:	test   $0x4,%r12b
 104f3a4:	jne    104f3c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x965>
 104f3a6:	lea    0x18(%r14),%rdi
 104f3aa:	testb  $0x4,0x10(%rax)
 104f3ae:	je     104f3db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x97b>
 104f3b0:	mov    0x18(%rax),%rcx
 104f3b4:	mov    0x14(%rax),%edx
 104f3b7:	add    %rcx,%rdx
 104f3ba:	add    $0x18,%rdx
 104f3be:	jmp    104f3df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x97f>
 104f3c0:	xor    %r15d,%r15d
 104f3c3:	jmp    104f420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f3c5:	mov    0x18(%r14),%rcx
 104f3c9:	mov    0x14(%r14),%edx
 104f3cd:	lea    (%rcx,%rdx,1),%rdi
 104f3d1:	add    $0x18,%rdi
 104f3d5:	testb  $0x4,0x10(%rax)
 104f3d9:	jne    104f3b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x950>
 104f3db:	lea    0x18(%rax),%rdx
 104f3df:	mov    0x8(%r14),%rsi
 104f3e3:	mov    0x8(%rax),%rcx
 104f3e7:	call   1091ea0 <myl_native_octets_find>
 104f3ec:	cmp    $0xffffffffffffffff,%rax
 104f3f0:	movabs $0x4000000000000002,%rdi
 104f3fa:	je     104f420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f3fc:	test   $0x1,%r12b
 104f400:	jne    104f417 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9b7>
 104f402:	mov    %r14,%rdi
 104f405:	mov    %rax,%rsi
 104f408:	call   108f7f0 <index_walk>
 104f40d:	movabs $0x4000000000000002,%rdi
 104f417:	mov    %rax,%r15
 104f41a:	nopw   0x0(%rax,%rax,1)
 104f420:	mov    %r15,%r12
 104f423:	inc    %r12
 104f426:	jo     1051426 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29c6>
 104f42c:	test   %r14,%r14
 104f42f:	je     104f44b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9eb>
 104f431:	test   %rdi,-0x10(%r14)
 104f435:	jne    104f44b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9eb>
 104f437:	mov    -0x18(%r14),%rax
 104f43b:	dec    %rax
 104f43e:	jne    104f447 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9e7>
 104f440:	cmpq   $0x0,-0x20(%r14)
 104f445:	je     104f497 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa37>
 104f447:	mov    %rax,-0x18(%r14)
 104f44b:	mov    %rbp,%rcx
 104f44e:	add    %r12,%rcx
 104f451:	jo     104f4c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa61>
 104f453:	mov    %rcx,%rax
 104f456:	imul   %r13
 104f459:	add    %rcx,%rdx
 104f45c:	mov    %rdx,%rax
 104f45f:	shr    $0x3f,%rax
 104f463:	sar    $0x1d,%rdx
 104f467:	add    %rax,%rdx
 104f46a:	imul   $0x3b9aca07,%rdx,%rax
 104f471:	sub    %rax,%rcx
 104f474:	mov    %rcx,%rbp
 104f477:	sar    $0x3f,%rbp
 104f47b:	and    $0x3b9aca07,%ebp
 104f481:	add    %rcx,%rbp
 104f484:	inc    %rbx
 104f487:	cmp    %rbx,0x20(%rsp)
 104f48c:	jne    104f320 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8c0>
 104f492:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f497:	mov    0x10(%rsp),%r15
 104f49c:	mov    %r15,%rdi
 104f49f:	mov    %r14,%rsi
 104f4a2:	call   1099df0 <myl_rc_hold_edge_release>
 104f4a7:	mov    %r15,%rdi
 104f4aa:	call   109ce10 <myl_rc_drain>
 104f4af:	movabs $0x4000000000000002,%rdi
 104f4b9:	mov    %rbp,%rcx
 104f4bc:	add    %r12,%rcx
 104f4bf:	jno    104f453 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f3>
 104f4c1:	mov    0x8(%rsp),%rdi
 104f4c6:	xor    %esi,%esi
 104f4c8:	mov    %rbp,%rdx
 104f4cb:	mov    %r12,%rcx
 104f4ce:	call   108b120 <myl_qbe_fail_overflow_op>
 104f4d3:	lea    0xc8(%rsp),%rsi
 104f4db:	mov    0x10(%rsp),%rdi
 104f4e0:	mov    %ebp,%r14d
 104f4e3:	mov    %eax,%ebp
 104f4e5:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f4ea:	movabs $0x4000000000000002,%rdi
 104f4f4:	mov    %ebp,%eax
 104f4f6:	mov    %r14d,%ebp
 104f4f9:	test   %eax,%eax
 104f4fb:	jne    104f30b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ab>
 104f501:	movq   $0x10b8dc8,0x40(%rsp)
 104f50a:	movq   $0x10b8dc8,0x70(%rsp)
 104f513:	movq   $0x10b8dc8,0xc8(%rsp)
 104f51f:	mov    $0x10b8dc8,%esi
 104f524:	mov    %rbx,%rdi
 104f527:	call   1091d50 <myl_native_text_equal>
 104f52c:	movabs $0x4000000000000002,%rcx
 104f536:	test   %rcx,0x6987b(%rip)        # 10b8db8 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f53d:	jne    104f560 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb00>
 104f53f:	mov    0x69862(%rip),%rcx        # 10b8da8 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f546:	dec    %rcx
 104f549:	jne    104f559 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaf9>
 104f54b:	cmpq   $0x0,0x6985d(%rip)        # 10b8db0 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f553:	je     10506ec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c8c>
 104f559:	mov    %rcx,0x69848(%rip)        # 10b8da8 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f560:	test   %eax,%eax
 104f562:	je     1050710 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cb0>
 104f568:	mov    %ebp,0x2c(%rsp)
 104f56c:	movabs $0x5000000000000000,%rdi
 104f576:	lea    0x40(%rsp),%rdx
 104f57b:	lea    0x70(%rsp),%rsi
 104f580:	mov    %rsi,%rax
 104f583:	sub    %rdx,%rax
 104f586:	sub    %rsi,%rdx
 104f589:	cmovb  %rax,%rdx
 104f58d:	mov    %rdx,0x120(%rsp)
 104f595:	lea    0x68(%rsp),%rdx
 104f59a:	lea    0x60(%rsp),%rcx
 104f59f:	mov    %rcx,%rax
 104f5a2:	sub    %rdx,%rax
 104f5a5:	sub    %rcx,%rdx
 104f5a8:	cmovb  %rax,%rdx
 104f5ac:	mov    %rdx,0x178(%rsp)
 104f5b4:	xor    %ecx,%ecx
 104f5b6:	lea    0x1(%rdi),%rax
 104f5ba:	mov    %rax,0xf0(%rsp)
 104f5c2:	vpbroadcastd -0x48447(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f5cb:	vpbroadcastd -0x48450(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f5d4:	vpbroadcastq -0x484c5(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f5dd:	vmovdqu %ymm0,0x1f0(%rsp)
 104f5e6:	xor    %ebp,%ebp
 104f5e8:	vmovdqa %xmm9,0x50(%rsp)
 104f5ee:	vmovdqu %ymm10,0x100(%rsp)
 104f5f7:	nopw   0x0(%rax,%rax,1)
 104f600:	mov    0x18(%rsp),%rsi
 104f605:	add    %rcx,%rsi
 104f608:	jo     105144f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ef>
 104f60e:	mov    %rcx,0x190(%rsp)
 104f616:	mov    0x30(%rsp),%rax
 104f61b:	mov    0x8(%rax),%rax
 104f61f:	and    $0x1,%esi
 104f622:	mov    (%rax),%rdx
 104f625:	cmp    %rdx,%rsi
 104f628:	jae    1051442 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29e2>
 104f62e:	mov    0x20(%rax),%rax
 104f632:	mov    (%rax,%rsi,8),%rbx
 104f636:	test   %rsi,%rsi
 104f639:	jne    104f6e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc80>
 104f63f:	movq   $0x10b9ae0,0x70(%rsp)
 104f648:	movq   $0x10b9ae0,0xc8(%rsp)
 104f654:	movq   $0x10b9ae0,0x40(%rsp)
 104f65d:	mov    0x6a46c(%rip),%rax        # 10b9ad0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f664:	test   %rax,0xf0(%rsp)
 104f66c:	je     104f775 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd15>
 104f672:	cmpq   $0x0,0x120(%rsp)
 104f67b:	setne  %cl
 104f67e:	movabs $0x5000000000000000,%rdx
 104f688:	test   %rdx,%rax
 104f68b:	sete   %dl
 104f68e:	mov    $0x10b9ae0,%eax
 104f693:	test   %cl,%dl
 104f695:	jne    104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd10>
 104f69b:	mov    $0x1030c78,%esi
 104f6a0:	mov    0x10(%rsp),%rdi
 104f6a5:	lea    0x70(%rsp),%rdx
 104f6aa:	lea    0x40(%rsp),%rcx
 104f6af:	mov    0x2c(%rsp),%r8d
 104f6b4:	vzeroupper
 104f6b7:	call   10a6230 <myl_rc_native_take>
 104f6bc:	vmovdqu 0x100(%rsp),%ymm10
 104f6c5:	vmovdqa 0x50(%rsp),%xmm9
 104f6cb:	test   %eax,%eax
 104f6cd:	jne    104f77e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1e>
 104f6d3:	jmp    1050684 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c24>
 104f6d8:	nopl   0x0(%rax,%rax,1)
 104f6e0:	movq   $0x10b8e50,0x70(%rsp)
 104f6e9:	movq   $0x10b8e50,0xc8(%rsp)
 104f6f5:	movq   $0x10b8e50,0x40(%rsp)
 104f6fe:	mov    0x6973b(%rip),%rax        # 10b8e40 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f705:	test   %rax,0xf0(%rsp)
 104f70d:	je     104f775 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd15>
 104f70f:	cmpq   $0x0,0x120(%rsp)
 104f718:	setne  %cl
 104f71b:	movabs $0x5000000000000000,%rdx
 104f725:	test   %rdx,%rax
 104f728:	sete   %dl
 104f72b:	mov    $0x10b8e50,%eax
 104f730:	test   %cl,%dl
 104f732:	jne    104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd10>
 104f734:	mov    $0x1030c78,%esi
 104f739:	mov    0x10(%rsp),%rdi
 104f73e:	lea    0x70(%rsp),%rdx
 104f743:	lea    0x40(%rsp),%rcx
 104f748:	mov    0x2c(%rsp),%r8d
 104f74d:	vzeroupper
 104f750:	call   10a6230 <myl_rc_native_take>
 104f755:	vmovdqu 0x100(%rsp),%ymm10
 104f75e:	vmovdqa 0x50(%rsp),%xmm9
 104f764:	test   %eax,%eax
 104f766:	jne    104f77e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1e>
 104f768:	jmp    10506b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c58>
 104f76d:	nopl   (%rax)
 104f770:	mov    %rax,0x70(%rsp)
 104f775:	movq   $0x0,0x40(%rsp)
 104f77e:	mov    0x70(%rsp),%rdx
 104f783:	movq   $0x0,0x250(%rsp)
 104f78f:	movq   $0x0,0x230(%rsp)
 104f79b:	mov    0x8(%rsp),%rax
 104f7a0:	cmp    %rsp,0x40(%rax)
 104f7a4:	ja     1051463 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a03>
 104f7aa:	cmpq   $0x0,(%rdx)
 104f7ae:	je     1051470 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a10>
 104f7b4:	mov    0x8(%rsp),%rax
 104f7b9:	mov    0x2c8(%rax),%eax
 104f7bf:	mov    %rbx,0xc0(%rsp)
 104f7c7:	mov    %rdx,0x130(%rsp)
 104f7cf:	testb  $0x4,0x10(%rbx)
 104f7d3:	mov    %eax,0xfc(%rsp)
 104f7da:	jne    104f800 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 104f7dc:	lea    0x18(%rbx),%r14
 104f7e0:	testb  $0x4,0x10(%rdx)
 104f7e4:	je     104f815 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb5>
 104f7e6:	mov    0x18(%rdx),%rax
 104f7ea:	mov    0x14(%rdx),%ecx
 104f7ed:	lea    (%rax,%rcx,1),%r12
 104f7f1:	add    $0x18,%r12
 104f7f5:	jmp    104f819 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb9>
 104f7f7:	nopw   0x0(%rax,%rax,1)
 104f800:	mov    0x18(%rbx),%rax
 104f804:	mov    0x14(%rbx),%ecx
 104f807:	lea    (%rax,%rcx,1),%r14
 104f80b:	add    $0x18,%r14
 104f80f:	testb  $0x4,0x10(%rdx)
 104f813:	jne    104f7e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd86>
 104f815:	lea    0x18(%rdx),%r12
 104f819:	mov    0x8(%rdx),%rcx
 104f81d:	mov    0x8(%rbx),%r15
 104f821:	lea    -0x1(%rcx),%rax
 104f825:	cmp    %r15,%rax
 104f828:	mov    %rcx,0x38(%rsp)
 104f82d:	mov    %rdx,0x188(%rsp)
 104f835:	jae    104fa30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfd0>
 104f83b:	cmp    $0x1,%rcx
 104f83f:	jne    104fa40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfe0>
 104f845:	mov    %rcx,%r13
 104f848:	movzbl (%r12),%eax
 104f84d:	vmovd  %eax,%xmm0
 104f851:	vpbroadcastb %xmm0,%xmm0
 104f856:	lea    0x18(%r14),%rcx
 104f85a:	xor    %ebx,%ebx
 104f85c:	xor    %edx,%edx
 104f85e:	mov    $0x10000,%r11d
 104f864:	jmp    104f882 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe22>
 104f866:	cs nopw 0x0(%rax,%rax,1)
 104f870:	mov    %r9d,%edi
 104f873:	add    %rdi,%rbx
 104f876:	add    %rsi,%rdx
 104f879:	cmp    %r15,%rdx
 104f87c:	jae    104fa8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104f882:	mov    %r15,%rsi
 104f885:	sub    %rdx,%rsi
 104f888:	cmp    $0x10000,%rsi
 104f88f:	cmovae %r11,%rsi
 104f893:	mov    %r15,%r8
 104f896:	sub    %rdx,%r8
 104f899:	jne    104f8b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe50>
 104f89b:	xor    %edi,%edi
 104f89d:	add    %rdi,%rbx
 104f8a0:	add    %rsi,%rdx
 104f8a3:	cmp    %r15,%rdx
 104f8a6:	jb     104f882 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe22>
 104f8a8:	jmp    104fa8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104f8ad:	nopl   (%rax)
 104f8b0:	lea    (%r14,%rdx,1),%rdi
 104f8b4:	cmp    $0x3,%r8
 104f8b8:	ja     104f8d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f8ba:	xor    %r8d,%r8d
 104f8bd:	xor    %r9d,%r9d
 104f8c0:	jmp    104fa10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104f8c5:	data16 cs nopw 0x0(%rax,%rax,1)
 104f8d0:	cmp    $0x20,%r8
 104f8d4:	jae    104f8e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe81>
 104f8d6:	xor    %r8d,%r8d
 104f8d9:	xor    %r9d,%r9d
 104f8dc:	jmp    104f9b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf54>
 104f8e1:	mov    %esi,%r8d
 104f8e4:	and    $0x1ffe0,%r8d
 104f8eb:	lea    (%rcx,%rdx,1),%r9
 104f8ef:	vpxor  %xmm1,%xmm1,%xmm1
 104f8f3:	xor    %r10d,%r10d
 104f8f6:	vpxor  %xmm2,%xmm2,%xmm2
 104f8fa:	vpxor  %xmm3,%xmm3,%xmm3
 104f8fe:	vpxor  %xmm4,%xmm4,%xmm4
 104f902:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f910:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104f917:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104f91e:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104f925:	vmovq  (%r9,%r10,1),%xmm8
 104f92b:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104f92f:	vpmovzxbd %xmm5,%ymm5
 104f934:	vpand  %ymm5,%ymm10,%ymm5
 104f938:	vpaddd %ymm5,%ymm1,%ymm1
 104f93c:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104f940:	vpmovzxbd %xmm5,%ymm5
 104f945:	vpand  %ymm5,%ymm10,%ymm5
 104f949:	vpaddd %ymm5,%ymm2,%ymm2
 104f94d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104f951:	vpmovzxbd %xmm5,%ymm5
 104f956:	vpand  %ymm5,%ymm10,%ymm5
 104f95a:	vpaddd %ymm5,%ymm3,%ymm3
 104f95e:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104f962:	vpmovzxbd %xmm5,%ymm5
 104f967:	vpand  %ymm5,%ymm10,%ymm5
 104f96b:	vpaddd %ymm5,%ymm4,%ymm4
 104f96f:	add    $0x20,%r10
 104f973:	cmp    %r10,%r8
 104f976:	jne    104f910 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeb0>
 104f978:	vpaddd %ymm1,%ymm2,%ymm1
 104f97c:	vpaddd %ymm1,%ymm3,%ymm1
 104f980:	vpaddd %ymm1,%ymm4,%ymm1
 104f984:	vextracti128 $0x1,%ymm1,%xmm2
 104f98a:	vpaddd %xmm2,%xmm1,%xmm1
 104f98e:	vpshufd $0xee,%xmm1,%xmm2
 104f993:	vpaddd %xmm2,%xmm1,%xmm1
 104f997:	vpshufd $0x55,%xmm1,%xmm2
 104f99c:	vpaddd %xmm2,%xmm1,%xmm1
 104f9a0:	vmovd  %xmm1,%r9d
 104f9a5:	cmp    %r8,%rsi
 104f9a8:	je     104f870 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104f9ae:	test   $0x1c,%sil
 104f9b2:	je     104fa10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104f9b4:	mov    %r8,%r10
 104f9b7:	mov    %esi,%r8d
 104f9ba:	and    $0x1fffc,%r8d
 104f9c1:	vmovd  %r9d,%xmm1
 104f9c6:	cs nopw 0x0(%rax,%rax,1)
 104f9d0:	vmovd  (%rdi,%r10,1),%xmm2
 104f9d6:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104f9da:	vpmovzxbd %xmm2,%xmm2
 104f9df:	vpand  %xmm2,%xmm9,%xmm2
 104f9e3:	vpaddd %xmm2,%xmm1,%xmm1
 104f9e7:	add    $0x4,%r10
 104f9eb:	cmp    %r10,%r8
 104f9ee:	jne    104f9d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf70>
 104f9f0:	vpshufd $0xee,%xmm1,%xmm2
 104f9f5:	vpaddd %xmm2,%xmm1,%xmm1
 104f9f9:	vpshufd $0x55,%xmm1,%xmm2
 104f9fe:	vpaddd %xmm2,%xmm1,%xmm1
 104fa02:	vmovd  %xmm1,%r9d
 104fa07:	jmp    104fa21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfc1>
 104fa09:	nopl   0x0(%rax)
 104fa10:	xor    %r10d,%r10d
 104fa13:	cmp    %al,(%rdi,%r8,1)
 104fa17:	sete   %r10b
 104fa1b:	add    %r10d,%r9d
 104fa1e:	inc    %r8
 104fa21:	cmp    %r8,%rsi
 104fa24:	jne    104fa10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104fa26:	jmp    104f870 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104fa2b:	nopl   0x0(%rax,%rax,1)
 104fa30:	mov    %rcx,%r13
 104fa33:	xor    %ebx,%ebx
 104fa35:	jmp    104fa8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104fa37:	nopw   0x0(%rax,%rax,1)
 104fa40:	mov    %r14,%rdi
 104fa43:	mov    %r15,%rsi
 104fa46:	mov    %r12,%rdx
 104fa49:	vzeroupper
 104fa4c:	call   1091ea0 <myl_native_octets_find>
 104fa51:	xor    %ebx,%ebx
 104fa53:	xor    %r13d,%r13d
 104fa56:	cmp    $0xffffffffffffffff,%rax
 104fa5a:	je     104fa86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1026>
 104fa5c:	nopl   0x0(%rax)
 104fa60:	mov    0x38(%rsp),%rcx
 104fa65:	add    %rcx,%r13
 104fa68:	add    %rax,%r13
 104fa6b:	inc    %rbx
 104fa6e:	lea    (%r14,%r13,1),%rdi
 104fa72:	mov    %r15,%rsi
 104fa75:	sub    %r13,%rsi
 104fa78:	mov    %r12,%rdx
 104fa7b:	call   1091ea0 <myl_native_octets_find>
 104fa80:	cmp    $0xffffffffffffffff,%rax
 104fa84:	jne    104fa60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1000>
 104fa86:	mov    0x38(%rsp),%r13
 104fa8b:	inc    %rbx
 104fa8e:	mov    0x8(%rsp),%r14
 104fa93:	mov    0x268(%r14),%rax
 104fa9a:	mov    %rax,0x1a8(%rsp)
 104faa2:	lea    0xc0(%rsp),%rax
 104faaa:	mov    %rax,0x1b0(%rsp)
 104fab2:	movq   $0x1031628,0x1b8(%rsp)
 104fabe:	lea    0x1a8(%rsp),%rax
 104fac6:	mov    %rax,0x158(%rsp)
 104face:	lea    0x130(%rsp),%rax
 104fad6:	mov    %rax,0x160(%rsp)
 104fade:	movq   $0x1031628,0x168(%rsp)
 104faea:	lea    0x158(%rsp),%rax
 104faf2:	mov    %rax,0x268(%r14)
 104faf9:	mov    $0x1031628,%esi
 104fafe:	mov    0x10(%rsp),%rdi
 104fb03:	mov    %rbx,%rdx
 104fb06:	vzeroupper
 104fb09:	call   108de90 <myl_native_list_new>
 104fb0e:	mov    %rax,%rsi
 104fb11:	mov    %rax,0xb8(%rsp)
 104fb19:	mov    0x268(%r14),%rax
 104fb20:	mov    %rax,0x138(%rsp)
 104fb28:	lea    0xb8(%rsp),%rax
 104fb30:	mov    %rax,0x140(%rsp)
 104fb38:	movq   $0x1031628,0x148(%rsp)
 104fb44:	lea    0x138(%rsp),%rax
 104fb4c:	mov    %rax,0x268(%r14)
 104fb53:	test   %rsi,%rsi
 104fb56:	je     1050070 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1610>
 104fb5c:	mov    0xc0(%rsp),%r14
 104fb64:	mov    0x10(%r14),%ecx
 104fb68:	lea    0x18(%r14),%rax
 104fb6c:	mov    %rax,0xb0(%rsp)
 104fb74:	mov    %ecx,0xac(%rsp)
 104fb7b:	test   $0x4,%cl
 104fb7e:	movabs $0x4000000000000002,%rdi
 104fb88:	vmovdqa -0x4e160(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fb90:	vmovdqu 0x1f0(%rsp),%ymm9
 104fb99:	vmovdqa -0x4e171(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fba1:	je     104fbba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x115a>
 104fba3:	mov    0x18(%r14),%rcx
 104fba7:	mov    0x14(%r14),%edx
 104fbab:	add    %rdx,%rcx
 104fbae:	add    $0x18,%rcx
 104fbb2:	mov    %rcx,0xb0(%rsp)
 104fbba:	mov    0x130(%rsp),%rcx
 104fbc2:	testb  $0x4,0x10(%rcx)
 104fbc6:	jne    104fbf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1190>
 104fbc8:	add    $0x18,%rcx
 104fbcc:	mov    %rcx,0x128(%rsp)
 104fbd4:	mov    %r14,%rcx
 104fbd7:	testb  $0x4,0xac(%rsp)
 104fbdf:	jne    104fc16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b6>
 104fbe1:	jmp    104fc19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b9>
 104fbe3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fbf0:	mov    %rcx,%rdx
 104fbf3:	mov    0x18(%rcx),%rcx
 104fbf7:	mov    0x14(%rdx),%edx
 104fbfa:	add    %rdx,%rcx
 104fbfd:	add    $0x18,%rcx
 104fc01:	mov    %rcx,0x128(%rsp)
 104fc09:	mov    %r14,%rcx
 104fc0c:	testb  $0x4,0xac(%rsp)
 104fc14:	je     104fc19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b9>
 104fc16:	mov    (%rax),%rcx
 104fc19:	mov    0x8(%rcx),%rcx
 104fc1d:	shr    $0x2,%rcx
 104fc21:	cmp    $0xa,%rcx
 104fc25:	mov    $0x9,%eax
 104fc2a:	cmovb  %rax,%rcx
 104fc2e:	mov    %rcx,0x1a0(%rsp)
 104fc36:	mov    0xb0(%rsp),%rax
 104fc3e:	add    $0xc,%rax
 104fc42:	mov    %rax,0x180(%rsp)
 104fc4a:	xor    %r8d,%r8d
 104fc4d:	mov    %r13,%rcx
 104fc50:	cmp    $0x1,%rbx
 104fc54:	je     104fd10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12b0>
 104fc5a:	nopw   0x0(%rax,%rax,1)
 104fc60:	test   %rbx,%rbx
 104fc63:	mov    0xb0(%rsp),%r13
 104fc6b:	je     1050122 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 104fc71:	lea    (%r8,%r13,1),%rdi
 104fc75:	mov    0x8(%r14),%r15
 104fc79:	mov    %r15,%rsi
 104fc7c:	sub    %r8,%rsi
 104fc7f:	mov    0x128(%rsp),%rdx
 104fc87:	mov    %r8,%r12
 104fc8a:	vzeroupper
 104fc8d:	call   1091ea0 <myl_native_octets_find>
 104fc92:	mov    %r12,%r8
 104fc95:	vmovdqa -0x4e26d(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fc9d:	vmovdqu 0x1f0(%rsp),%ymm9
 104fca6:	vmovdqa -0x4e27e(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fcae:	add    %rax,%r12
 104fcb1:	cmp    $0xffffffffffffffff,%rax
 104fcb5:	cmove  %r15,%r12
 104fcb9:	mov    %r12,%r15
 104fcbc:	sub    %r8,%r15
 104fcbf:	cmp    0x1a0(%rsp),%r15
 104fcc7:	jb     104fd2c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12cc>
 104fcc9:	mov    0x10(%rsp),%rdi
 104fcce:	mov    %r14,%rsi
 104fcd1:	mov    %r8,%rdx
 104fcd4:	mov    %r15,%rcx
 104fcd7:	mov    $0xffffffffffffffff,%r8
 104fcde:	vzeroupper
 104fce1:	call   1090750 <long_piece>
 104fce6:	mov    %rax,%r13
 104fce9:	test   %rax,%rax
 104fcec:	movabs $0x4000000000000002,%rdi
 104fcf6:	jne    104fff0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fcfc:	jmp    1050081 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104fd01:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fd10:	mov    0x8(%r14),%r12
 104fd14:	mov    0xb0(%rsp),%r13
 104fd1c:	mov    %r12,%r15
 104fd1f:	sub    %r8,%r15
 104fd22:	cmp    0x1a0(%rsp),%r15
 104fd2a:	jae    104fcc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1269>
 104fd2c:	lea    (%r8,%r13,1),%rsi
 104fd30:	testb  $0x1,0xac(%rsp)
 104fd38:	movabs $0x101010101010101,%rdi
 104fd42:	jne    104ff1f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14bf>
 104fd48:	cmp    $0x8,%r15
 104fd4c:	jae    104fd60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1300>
 104fd4e:	xor    %ecx,%ecx
 104fd50:	xor    %eax,%eax
 104fd52:	jmp    104fda6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1346>
 104fd54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fd60:	xor    %edx,%edx
 104fd62:	xor    %ecx,%ecx
 104fd64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fd70:	mov    (%rsi,%rdx,1),%rax
 104fd74:	mov    %rax,%r9
 104fd77:	not    %r9
 104fd7a:	add    %r9,%r9
 104fd7d:	and    %rax,%r9
 104fd80:	shr    $0x7,%r9
 104fd84:	and    %rdi,%r9
 104fd87:	imul   %rdi,%r9
 104fd8b:	shr    $0x38,%r9
 104fd8f:	sub    %r9,%rcx
 104fd92:	add    $0x8,%rcx
 104fd96:	lea    0x8(%rdx),%rax
 104fd9a:	add    $0x10,%rdx
 104fd9e:	cmp    %r15,%rdx
 104fda1:	mov    %rax,%rdx
 104fda4:	jbe    104fd70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1310>
 104fda6:	cmp    %r15,%rax
 104fda9:	jae    104ff16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104fdaf:	lea    (%rax,%r8,1),%rdi
 104fdb3:	mov    %r12,%rdx
 104fdb6:	sub    %rdi,%rdx
 104fdb9:	cmp    $0x3,%rdx
 104fdbd:	jbe    104fef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1491>
 104fdc3:	cmp    $0x10,%rdx
 104fdc7:	jae    104fdd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1371>
 104fdc9:	xor    %r9d,%r9d
 104fdcc:	jmp    104fe9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x143e>
 104fdd1:	mov    %rdx,%r9
 104fdd4:	and    $0xfffffffffffffff0,%r9
 104fdd8:	vmovq  %rcx,%xmm0
 104fddd:	add    0x180(%rsp),%rdi
 104fde5:	vpxor  %xmm1,%xmm1,%xmm1
 104fde9:	xor    %ecx,%ecx
 104fdeb:	vpxor  %xmm2,%xmm2,%xmm2
 104fdef:	vpxor  %xmm3,%xmm3,%xmm3
 104fdf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fe00:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 104fe06:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 104fe0c:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 104fe12:	vmovd  (%rdi,%rcx,1),%xmm7
 104fe17:	vpcmpgtb %xmm10,%xmm4,%xmm4
 104fe1c:	vpmovzxbq %xmm4,%ymm4
 104fe21:	vpand  %ymm4,%ymm9,%ymm4
 104fe25:	vpaddq %ymm4,%ymm0,%ymm0
 104fe29:	vpcmpgtb %xmm10,%xmm5,%xmm4
 104fe2e:	vpmovzxbq %xmm4,%ymm4
 104fe33:	vpand  %ymm4,%ymm9,%ymm4
 104fe37:	vpaddq %ymm4,%ymm1,%ymm1
 104fe3b:	vpcmpgtb %xmm10,%xmm6,%xmm4
 104fe40:	vpmovzxbq %xmm4,%ymm4
 104fe45:	vpand  %ymm4,%ymm9,%ymm4
 104fe49:	vpaddq %ymm4,%ymm2,%ymm2
 104fe4d:	vpcmpgtb %xmm10,%xmm7,%xmm4
 104fe52:	vpmovzxbq %xmm4,%ymm4
 104fe57:	vpand  %ymm4,%ymm9,%ymm4
 104fe5b:	vpaddq %ymm4,%ymm3,%ymm3
 104fe5f:	add    $0x10,%rcx
 104fe63:	cmp    %rcx,%r9
 104fe66:	jne    104fe00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13a0>
 104fe68:	vpaddq %ymm0,%ymm1,%ymm0
 104fe6c:	vpaddq %ymm0,%ymm2,%ymm0
 104fe70:	vpaddq %ymm0,%ymm3,%ymm0
 104fe74:	vextracti128 $0x1,%ymm0,%xmm1
 104fe7a:	vpaddq %xmm1,%xmm0,%xmm0
 104fe7e:	vpshufd $0xee,%xmm0,%xmm1
 104fe83:	vpaddq %xmm1,%xmm0,%xmm0
 104fe87:	vmovq  %xmm0,%rcx
 104fe8c:	cmp    %r9,%rdx
 104fe8f:	je     104ff16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104fe95:	test   $0xc,%dl
 104fe98:	je     105005e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15fe>
 104fe9e:	mov    %rdx,%rdi
 104fea1:	and    $0xfffffffffffffffc,%rdi
 104fea5:	vmovq  %rcx,%xmm0
 104feaa:	lea    (%rsi,%rax,1),%rcx
 104feae:	xchg   %ax,%ax
 104feb0:	vmovd  (%rcx,%r9,1),%xmm1
 104feb6:	vpcmpgtb %xmm8,%xmm1,%xmm1
 104febb:	vpmovzxbq %xmm1,%ymm1
 104fec0:	vpand  %ymm1,%ymm9,%ymm1
 104fec4:	vpaddq %ymm1,%ymm0,%ymm0
 104fec8:	add    $0x4,%r9
 104fecc:	cmp    %r9,%rdi
 104fecf:	jne    104feb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1450>
 104fed1:	vextracti128 $0x1,%ymm0,%xmm1
 104fed7:	vpaddq %xmm1,%xmm0,%xmm0
 104fedb:	vpshufd $0xee,%xmm0,%xmm1
 104fee0:	vpaddq %xmm1,%xmm0,%xmm0
 104fee4:	vmovq  %xmm0,%rcx
 104fee9:	cmp    %rdi,%rdx
 104feec:	je     104ff16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104feee:	add    %rdi,%rax
 104fef1:	add    %r8,%rax
 104fef4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ff00:	xor    %edx,%edx
 104ff02:	cmpb   $0xc0,0x0(%r13,%rax,1)
 104ff08:	setge  %dl
 104ff0b:	add    %rdx,%rcx
 104ff0e:	inc    %rax
 104ff11:	cmp    %rax,%r12
 104ff14:	jne    104ff00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14a0>
 104ff16:	cmp    %r15,%rcx
 104ff19:	jne    104ffc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1560>
 104ff1f:	mov    0x8(%rsp),%rax
 104ff24:	cmpq   $0x0,0x1860(%rax)
 104ff2c:	je     1050070 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1610>
 104ff32:	mov    %rsi,0x198(%rsp)
 104ff3a:	mov    %r8,%r14
 104ff3d:	lea    0x18(%r15),%rsi
 104ff41:	mov    0x2c8(%rax),%edx
 104ff47:	mov    0x10(%rsp),%rdi
 104ff4c:	xor    %ecx,%ecx
 104ff4e:	vzeroupper
 104ff51:	call   10a59d0 <raw_bytes>
 104ff56:	test   %rax,%rax
 104ff59:	movabs $0x4000000000000002,%rdi
 104ff63:	je     1050081 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104ff69:	mov    %rax,%r13
 104ff6c:	movq   $0x0,(%rax)
 104ff73:	mov    %r15,0x8(%rax)
 104ff77:	movq   $0x0,0x10(%rax)
 104ff7f:	cmp    %r14,%r12
 104ff82:	je     104ffa5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1545>
 104ff84:	mov    %r13,%rdi
 104ff87:	add    $0x18,%rdi
 104ff8b:	mov    0x198(%rsp),%rsi
 104ff93:	mov    %r15,%rdx
 104ff96:	call   10ab440 <memcpy@plt>
 104ff9b:	movabs $0x4000000000000002,%rdi
 104ffa5:	mov    %r15,0x0(%r13)
 104ffa9:	movl   $0x1,0x10(%r13)
 104ffb1:	jmp    104fff0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104ffb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ffc0:	mov    0x10(%rsp),%rdi
 104ffc5:	mov    %r15,%rdx
 104ffc8:	vzeroupper
 104ffcb:	call   108f6b0 <build_wide>
 104ffd0:	mov    %rax,%r13
 104ffd3:	test   %rax,%rax
 104ffd6:	movabs $0x4000000000000002,%rdi
 104ffe0:	je     1050081 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104ffe6:	cs nopw 0x0(%rax,%rax,1)
 104fff0:	mov    0xb8(%rsp),%rax
 104fff8:	mov    (%rax),%rcx
 104fffb:	mov    0x20(%rax),%rdx
 104ffff:	lea    0x1(%rcx),%rsi
 1050003:	mov    %rsi,(%rax)
 1050006:	mov    %r13,(%rdx,%rcx,8)
 105000a:	mov    0xb8(%rsp),%rsi
 1050012:	incq   0x10(%rsi)
 1050016:	mov    0xc0(%rsp),%r14
 105001e:	cmp    0x8(%r14),%r12
 1050022:	je     1050122 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 1050028:	mov    0x38(%rsp),%rcx
 105002d:	add    %rcx,%r12
 1050030:	dec    %rbx
 1050033:	mov    %r12,%r8
 1050036:	vmovdqa -0x4e60e(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105003e:	vmovdqu 0x1f0(%rsp),%ymm9
 1050047:	vmovdqa -0x4e61f(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105004f:	cmp    $0x1,%rbx
 1050053:	jne    104fc60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1200>
 1050059:	jmp    104fd10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12b0>
 105005e:	add    %r9,%rax
 1050061:	jmp    104fef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1491>
 1050066:	cs nopw 0x0(%rax,%rax,1)
 1050070:	xor    %esi,%esi
 1050072:	movabs $0x4000000000000002,%rdi
 105007c:	jmp    1050122 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 1050081:	mov    0x8(%rsp),%rax
 1050086:	cmpq   $0x0,0x1860(%rax)
 105008e:	je     1050120 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c0>
 1050094:	mov    0xb8(%rsp),%rbx
 105009c:	mov    0x18(%rbx),%rax
 10500a0:	cmpw   $0x1,0x30(%rax)
 10500a5:	jne    1051368 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2908>
 10500ab:	mov    (%rbx),%rax
 10500ae:	test   %rax,%rax
 10500b1:	je     1050109 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a9>
 10500b3:	mov    0xc0(%rsp),%r14
 10500bb:	mov    0x20(%rbx),%r15
 10500bf:	xor    %r12d,%r12d
 10500c2:	jmp    10500d8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1678>
 10500c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10500d0:	inc    %r12
 10500d3:	cmp    %rax,%r12
 10500d6:	jae    1050109 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a9>
 10500d8:	mov    (%r15,%r12,8),%rsi
 10500dc:	test   %rsi,%rsi
 10500df:	je     10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500e1:	cmp    %r14,%rsi
 10500e4:	je     10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500e6:	lea    -0x2(%rdi),%rcx
 10500ea:	test   %rcx,-0x10(%rsi)
 10500ee:	je     10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500f0:	mov    0x10(%rsp),%rdi
 10500f5:	call   109de50 <myl_rc_construction_abort>
 10500fa:	movabs $0x4000000000000002,%rdi
 1050104:	mov    (%rbx),%rax
 1050107:	jmp    10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 1050109:	mov    0x10(%rsp),%rdi
 105010e:	mov    %rbx,%rsi
 1050111:	call   109de50 <myl_rc_construction_abort>
 1050116:	movabs $0x4000000000000002,%rdi
 1050120:	xor    %esi,%esi
 1050122:	mov    0x8(%rsp),%rax
 1050127:	mov    0x268(%rax),%rax
 105012e:	lea    0x138(%rsp),%rcx
 1050136:	cmp    %rcx,%rax
 1050139:	je     1050160 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1700>
 105013b:	lea    0x158(%rsp),%rcx
 1050143:	cmp    %rcx,%rax
 1050146:	je     1050181 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1721>
 1050148:	lea    0x1a8(%rsp),%rcx
 1050150:	cmp    %rcx,%rax
 1050153:	je     10501a2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1742>
 1050155:	test   %rsi,%rsi
 1050158:	jne    10501bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x175f>
 105015a:	jmp    105147d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1d>
 105015f:	nop
 1050160:	mov    0x138(%rsp),%rax
 1050168:	mov    0x8(%rsp),%rcx
 105016d:	mov    %rax,0x268(%rcx)
 1050174:	lea    0x158(%rsp),%rcx
 105017c:	cmp    %rcx,%rax
 105017f:	jne    1050148 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16e8>
 1050181:	mov    0x158(%rsp),%rax
 1050189:	mov    0x8(%rsp),%rcx
 105018e:	mov    %rax,0x268(%rcx)
 1050195:	lea    0x1a8(%rsp),%rcx
 105019d:	cmp    %rcx,%rax
 10501a0:	jne    1050155 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16f5>
 10501a2:	mov    0x1a8(%rsp),%rax
 10501aa:	mov    0x8(%rsp),%rcx
 10501af:	mov    %rax,0x268(%rcx)
 10501b6:	test   %rsi,%rsi
 10501b9:	je     105147d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1d>
 10501bf:	mov    %rsi,0x60(%rsp)
 10501c4:	mov    %rsi,0x68(%rsp)
 10501c9:	mov    -0x10(%rsi),%rax
 10501cd:	test   %rax,0xf0(%rsp)
 10501d5:	je     10501f6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1796>
 10501d7:	movabs $0x5000000000000000,%rcx
 10501e1:	test   %rcx,%rax
 10501e4:	jne    1050210 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17b0>
 10501e6:	cmpq   $0x0,0x178(%rsp)
 10501ef:	je     1050210 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17b0>
 10501f1:	mov    %rsi,0x60(%rsp)
 10501f6:	movq   $0x0,0x68(%rsp)
 10501ff:	mov    (%rsi),%r14
 1050202:	test   %r14,%r14
 1050205:	jns    1050257 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17f7>
 1050207:	jmp    105148a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a2a>
 105020c:	nopl   0x0(%rax)
 1050210:	mov    $0x100ba48,%esi
 1050215:	mov    0x10(%rsp),%rdi
 105021a:	lea    0x60(%rsp),%rdx
 105021f:	lea    0x68(%rsp),%rcx
 1050224:	mov    0xfc(%rsp),%r8d
 105022c:	vzeroupper
 105022f:	call   10a6230 <myl_rc_native_take>
 1050234:	test   %eax,%eax
 1050236:	je     1050459 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19f9>
 105023c:	mov    0x60(%rsp),%rsi
 1050241:	movabs $0x4000000000000002,%rdi
 105024b:	mov    (%rsi),%r14
 105024e:	test   %r14,%r14
 1050251:	js     105148a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a2a>
 1050257:	imul   $0x7,%r14,%r12
 105025b:	vmovdqa 0x50(%rsp),%xmm9
 1050261:	vmovdqu 0x100(%rsp),%ymm10
 105026a:	jo     105149a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a3a>
 1050270:	test   %rsi,%rsi
 1050273:	je     105027f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x181f>
 1050275:	test   %rdi,-0x10(%rsi)
 1050279:	je     105038d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x192d>
 105027f:	mov    %rsi,0x60(%rsp)
 1050284:	test   %r14,%r14
 1050287:	mov    %rsi,0x38(%rsp)
 105028c:	je     10503b1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1951>
 1050292:	xor    %r15d,%r15d
 1050295:	data16 cs nopw 0x0(%rax,%rax,1)
 10502a0:	mov    0x20(%rsi),%rax
 10502a4:	mov    (%rax,%r15,8),%r13
 10502a8:	mov    %r13,0x68(%rsp)
 10502ad:	test   %r13,%r13
 10502b0:	je     10502c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1869>
 10502b2:	test   %rdi,-0x10(%r13)
 10502b6:	jne    10502c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1869>
 10502b8:	mov    -0x18(%r13),%rax
 10502bc:	inc    %rax
 10502bf:	je     1050542 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ae2>
 10502c5:	mov    %rax,-0x18(%r13)
 10502c9:	mov    %r13,0x60(%rsp)
 10502ce:	movq   $0x0,0x68(%rsp)
 10502d7:	mov    0x8(%rsp),%rdi
 10502dc:	mov    %r13,%rsi
 10502df:	vzeroupper
 10502e2:	call   10741d0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10502e7:	mov    %r12,%rbx
 10502ea:	add    %rax,%rbx
 10502ed:	jo     10513b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2953>
 10502f3:	test   %r13,%r13
 10502f6:	movabs $0x4000000000000002,%rdi
 1050300:	vmovdqa 0x50(%rsp),%xmm9
 1050306:	vmovdqu 0x100(%rsp),%ymm10
 105030f:	mov    0x38(%rsp),%rsi
 1050314:	je     1050330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 1050316:	test   %rdi,-0x10(%r13)
 105031a:	jne    1050330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 105031c:	mov    -0x18(%r13),%rax
 1050320:	dec    %rax
 1050323:	jne    105032c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18cc>
 1050325:	cmpq   $0x0,-0x20(%r13)
 105032a:	je     105034a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18ea>
 105032c:	mov    %rax,-0x18(%r13)
 1050330:	cmp    %r14,(%rsi)
 1050333:	jne    10513c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2965>
 1050339:	inc    %r15
 105033c:	mov    %rbx,%r12
 105033f:	cmp    %r15,%r14
 1050342:	jne    10502a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1840>
 1050348:	jmp    10503b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1954>
 105034a:	mov    0x10(%rsp),%r12
 105034f:	mov    %r12,%rdi
 1050352:	mov    %r13,%rsi
 1050355:	vzeroupper
 1050358:	call   1099df0 <myl_rc_hold_edge_release>
 105035d:	mov    %r12,%rdi
 1050360:	call   109ce10 <myl_rc_drain>
 1050365:	mov    0x38(%rsp),%rsi
 105036a:	vmovdqu 0x100(%rsp),%ymm10
 1050373:	vmovdqa 0x50(%rsp),%xmm9
 1050379:	movabs $0x4000000000000002,%rdi
 1050383:	cmp    %r14,(%rsi)
 1050386:	je     1050339 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d9>
 1050388:	jmp    10513c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2965>
 105038d:	mov    -0x18(%rsi),%rax
 1050391:	inc    %rax
 1050394:	je     1050542 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ae2>
 105039a:	mov    %rax,-0x18(%rsi)
 105039e:	mov    %rsi,0x60(%rsp)
 10503a3:	test   %r14,%r14
 10503a6:	mov    %rsi,0x38(%rsp)
 10503ab:	jne    1050292 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1832>
 10503b1:	mov    %r12,%rbx
 10503b4:	mov    0x230(%rsp),%eax
 10503bb:	or     0x250(%rsp),%eax
 10503c2:	je     105040b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19ab>
 10503c4:	mov    0x8(%rsp),%rax
 10503c9:	mov    0x1860(%rax),%rax
 10503d0:	test   %rax,%rax
 10503d3:	je     10503de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x197e>
 10503d5:	mov    0xf8(%rax),%rsi
 10503dc:	jmp    10503e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 10503de:	xor    %esi,%esi
 10503e0:	mov    0x10(%rsp),%rdi
 10503e5:	vzeroupper
 10503e8:	call   10a0440 <myl_rc_scope_unwind>
 10503ed:	movabs $0x4000000000000002,%rdi
 10503f7:	vmovdqa 0x50(%rsp),%xmm9
 10503fd:	vmovdqu 0x100(%rsp),%ymm10
 1050406:	mov    0x38(%rsp),%rsi
 105040b:	test   %rsi,%rsi
 105040e:	je     10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050414:	test   %rdi,-0x10(%rsi)
 1050418:	jne    1050432 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19d2>
 105041a:	mov    -0x18(%rsi),%rax
 105041e:	dec    %rax
 1050421:	jne    105042e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19ce>
 1050423:	cmpq   $0x0,-0x20(%rsi)
 1050428:	je     10504c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a65>
 105042e:	mov    %rax,-0x18(%rsi)
 1050432:	test   %rdi,-0x10(%rsi)
 1050436:	jne    10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 105043c:	mov    -0x20(%rsi),%rax
 1050440:	dec    %rax
 1050443:	jne    1050450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19f0>
 1050445:	cmpq   $0x0,-0x18(%rsi)
 105044a:	je     105050f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1aaf>
 1050450:	mov    %rax,-0x20(%rsi)
 1050454:	jmp    10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050459:	mov    0x8(%rsp),%rax
 105045e:	mov    0x1860(%rax),%rax
 1050465:	test   %rax,%rax
 1050468:	movabs $0x4000000000000002,%rdi
 1050472:	vmovdqa 0x50(%rsp),%xmm9
 1050478:	vmovdqu 0x100(%rsp),%ymm10
 1050481:	je     1051370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050487:	mov    0x124(%rax),%ebx
 105048d:	movl   $0x0,0x124(%rax)
 1050497:	test   %rbx,%rbx
 105049a:	je     10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 10504a0:	cmp    $0x1,%ebx
 10504a3:	jne    1050571 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b11>
 10504a9:	mov    $0x1007df2,%esi
 10504ae:	mov    0x8(%rsp),%rax
 10504b3:	cmpl   $0x0,0x2c4(%rax)
 10504ba:	je     105057a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b1a>
 10504c0:	jmp    1050582 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b22>
 10504c5:	mov    0x10(%rsp),%r14
 10504ca:	mov    %r14,%rdi
 10504cd:	mov    0x38(%rsp),%rsi
 10504d2:	vzeroupper
 10504d5:	call   1099df0 <myl_rc_hold_edge_release>
 10504da:	mov    %r14,%rdi
 10504dd:	call   109ce10 <myl_rc_drain>
 10504e2:	mov    0x38(%rsp),%rsi
 10504e7:	vmovdqu 0x100(%rsp),%ymm10
 10504f0:	vmovdqa 0x50(%rsp),%xmm9
 10504f6:	movabs $0x4000000000000002,%rdi
 1050500:	test   %rdi,-0x10(%rsi)
 1050504:	jne    10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 105050a:	jmp    105043c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19dc>
 105050f:	mov    0x10(%rsp),%r14
 1050514:	mov    %r14,%rdi
 1050517:	vzeroupper
 105051a:	call   1099c90 <myl_rc_edge_release>
 105051f:	mov    %r14,%rdi
 1050522:	call   109ce10 <myl_rc_drain>
 1050527:	vmovdqu 0x100(%rsp),%ymm10
 1050530:	vmovdqa 0x50(%rsp),%xmm9
 1050536:	movabs $0x4000000000000002,%rdi
 1050540:	jmp    10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050542:	mov    $0x1007dbf,%esi
 1050547:	mov    0x8(%rsp),%rdi
 105054c:	vzeroupper
 105054f:	call   108a70e <fail>
 1050554:	vmovdqu 0x100(%rsp),%ymm10
 105055d:	vmovdqa 0x50(%rsp),%xmm9
 1050563:	movabs $0x4000000000000002,%rdi
 105056d:	xor    %ebx,%ebx
 105056f:	jmp    10505b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050571:	cmp    $0x4,%ebx
 1050574:	jae    1051368 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2908>
 105057a:	mov    0x10315e0(,%rbx,8),%rsi
 1050582:	mov    0x8(%rsp),%rdi
 1050587:	vzeroupper
 105058a:	call   108a70e <fail>
 105058f:	xor    %ebx,%ebx
 1050591:	movabs $0x4000000000000002,%rdi
 105059b:	vmovdqa 0x50(%rsp),%xmm9
 10505a1:	vmovdqu 0x100(%rsp),%ymm10
 10505aa:	nopw   0x0(%rax,%rax,1)
 10505b0:	mov    0x188(%rsp),%rcx
 10505b8:	test   %rcx,%rcx
 10505bb:	je     10505d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b77>
 10505bd:	test   %rdi,-0x10(%rcx)
 10505c1:	jne    10505d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b77>
 10505c3:	mov    -0x20(%rcx),%rax
 10505c7:	dec    %rax
 10505ca:	jne    10505d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b73>
 10505cc:	cmpq   $0x0,-0x18(%rcx)
 10505d1:	je     1050639 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd9>
 10505d3:	mov    %rax,-0x20(%rcx)
 10505d7:	mov    %rbp,%rcx
 10505da:	add    %rbx,%rcx
 10505dd:	jo     105066f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0f>
 10505e3:	mov    %rcx,%rax
 10505e6:	movabs $0x89705f3112a28fe5,%rdx
 10505f0:	imul   %rdx
 10505f3:	add    %rcx,%rdx
 10505f6:	mov    %rdx,%rax
 10505f9:	shr    $0x3f,%rax
 10505fd:	sar    $0x1d,%rdx
 1050601:	add    %rax,%rdx
 1050604:	imul   $0x3b9aca07,%rdx,%rax
 105060b:	sub    %rax,%rcx
 105060e:	mov    %rcx,%rbp
 1050611:	sar    $0x3f,%rbp
 1050615:	and    $0x3b9aca07,%ebp
 105061b:	add    %rcx,%rbp
 105061e:	mov    0x190(%rsp),%rcx
 1050626:	inc    %rcx
 1050629:	cmp    0x20(%rsp),%rcx
 105062e:	jne    104f600 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xba0>
 1050634:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050639:	mov    0x10(%rsp),%r14
 105063e:	mov    %rcx,%rsi
 1050641:	mov    %r14,%rdi
 1050644:	vzeroupper
 1050647:	call   1099c90 <myl_rc_edge_release>
 105064c:	mov    %r14,%rdi
 105064f:	call   109ce10 <myl_rc_drain>
 1050654:	vmovdqu 0x100(%rsp),%ymm10
 105065d:	vmovdqa 0x50(%rsp),%xmm9
 1050663:	mov    %rbp,%rcx
 1050666:	add    %rbx,%rcx
 1050669:	jno    10505e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b83>
 105066f:	mov    0x8(%rsp),%rdi
 1050674:	xor    %esi,%esi
 1050676:	mov    %rbp,%rdx
 1050679:	mov    %rbx,%rcx
 105067c:	vzeroupper
 105067f:	call   108b120 <myl_qbe_fail_overflow_op>
 1050684:	mov    0x8(%rsp),%rdi
 1050689:	mov    0x1860(%rdi),%rax
 1050690:	test   %rax,%rax
 1050693:	je     1051370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050699:	mov    0x124(%rax),%esi
 105069f:	movl   $0x0,0x124(%rax)
 10506a9:	vzeroupper
 10506ac:	call   1089eb0 <myl_qbe_rc_status>
 10506b1:	xor    %ebp,%ebp
 10506b3:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10506b8:	mov    0x8(%rsp),%rdi
 10506bd:	mov    0x1860(%rdi),%rax
 10506c4:	test   %rax,%rax
 10506c7:	je     1051370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 10506cd:	mov    0x124(%rax),%esi
 10506d3:	movl   $0x0,0x124(%rax)
 10506dd:	vzeroupper
 10506e0:	call   1089eb0 <myl_qbe_rc_status>
 10506e5:	xor    %ebp,%ebp
 10506e7:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10506ec:	lea    0xc8(%rsp),%rsi
 10506f4:	mov    0x10(%rsp),%rdi
 10506f9:	mov    %ebp,%r14d
 10506fc:	mov    %eax,%ebp
 10506fe:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050703:	mov    %ebp,%eax
 1050705:	mov    %r14d,%ebp
 1050708:	test   %eax,%eax
 105070a:	jne    104f568 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb08>
 1050710:	movq   $0x10b8c90,0x70(%rsp)
 1050719:	movq   $0x10b8c90,0xc8(%rsp)
 1050725:	mov    $0x10b8c90,%esi
 105072a:	mov    %rbx,%rdi
 105072d:	call   1091d50 <myl_native_text_equal>
 1050732:	movabs $0x4000000000000002,%rsi
 105073c:	test   %rsi,0x6853d(%rip)        # 10b8c80 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050743:	jne    1050766 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d06>
 1050745:	mov    0x68524(%rip),%rcx        # 10b8c70 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 105074c:	dec    %rcx
 105074f:	jne    105075f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cff>
 1050751:	cmpq   $0x0,0x6851f(%rip)        # 10b8c78 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050759:	je     1050b46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20e6>
 105075f:	mov    %rcx,0x6850a(%rip)        # 10b8c70 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050766:	test   %eax,%eax
 1050768:	je     1050b74 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2114>
 105076e:	mov    %ebp,0x2c(%rsp)
 1050772:	lea    0x48(%rsp),%r14
 1050777:	lea    0x70(%rsp),%rcx
 105077c:	mov    %rcx,%rax
 105077f:	sub    %r14,%rax
 1050782:	sub    %rcx,%r14
 1050785:	cmovb  %rax,%r14
 1050789:	movabs $0x5000000000000000,%rax
 1050793:	xor    %r15d,%r15d
 1050796:	inc    %rax
 1050799:	mov    %rax,0x50(%rsp)
 105079e:	xor    %ebp,%ebp
 10507a0:	mov    0x18(%rsp),%rax
 10507a5:	add    %r15,%rax
 10507a8:	jo     10514d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a70>
 10507ae:	test   $0x1,%al
 10507b0:	jne    1050827 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc7>
 10507b2:	movq   $0x10b9ae0,0x70(%rsp)
 10507bb:	movq   $0x10b9ae0,0x1c8(%rsp)
 10507c7:	movq   $0x10b9ae0,0x48(%rsp)
 10507d0:	mov    0x692f9(%rip),%rax        # 10b9ad0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 10507d7:	test   %rax,0x50(%rsp)
 10507dc:	je     10508d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e75>
 10507e2:	test   %r14,%r14
 10507e5:	sete   %cl
 10507e8:	movabs $0x5000000000000000,%rdx
 10507f2:	test   %rdx,%rax
 10507f5:	setne  %al
 10507f8:	or     %cl,%al
 10507fa:	je     10508dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e7d>
 1050800:	mov    $0x1030c78,%esi
 1050805:	mov    0x10(%rsp),%rdi
 105080a:	lea    0x70(%rsp),%rdx
 105080f:	lea    0x48(%rsp),%rcx
 1050814:	mov    0x2c(%rsp),%r8d
 1050819:	call   10a6230 <myl_rc_native_take>
 105081e:	test   %eax,%eax
 1050820:	jne    1050897 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e37>
 1050822:	jmp    1050ae4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2084>
 1050827:	movq   $0x10b8e50,0x70(%rsp)
 1050830:	movq   $0x10b8e50,0x1c8(%rsp)
 105083c:	movq   $0x10b8e50,0x48(%rsp)
 1050845:	mov    0x685f4(%rip),%rax        # 10b8e40 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 105084c:	test   %rax,0x50(%rsp)
 1050851:	je     10508f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e97>
 1050857:	test   %r14,%r14
 105085a:	sete   %cl
 105085d:	movabs $0x5000000000000000,%rdx
 1050867:	test   %rdx,%rax
 105086a:	setne  %al
 105086d:	or     %cl,%al
 105086f:	je     10508ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e8e>
 1050871:	mov    $0x1030c78,%esi
 1050876:	mov    0x10(%rsp),%rdi
 105087b:	lea    0x70(%rsp),%rdx
 1050880:	lea    0x48(%rsp),%rcx
 1050885:	mov    0x2c(%rsp),%r8d
 105088a:	call   10a6230 <myl_rc_native_take>
 105088f:	test   %eax,%eax
 1050891:	je     1050b15 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20b5>
 1050897:	mov    0x70(%rsp),%r12
 105089c:	mov    %r12,0xa0(%rsp)
 10508a4:	mov    %r12,0x48(%rsp)
 10508a9:	test   %r12,%r12
 10508ac:	movabs $0x4000000000000002,%rsi
 10508b6:	jne    105090a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1eaa>
 10508b8:	movq   $0x0,0x70(%rsp)
 10508c1:	movq   $0x0,0x98(%rsp)
 10508cd:	xor    %r12d,%r12d
 10508d0:	jmp    1050967 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f07>
 10508d5:	mov    $0x10b9ae0,%r12d
 10508db:	jmp    10508fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9d>
 10508dd:	movq   $0x10b9ae0,0x70(%rsp)
 10508e6:	mov    $0x10b9ae0,%r12d
 10508ec:	jmp    10508fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9d>
 10508ee:	movq   $0x10b8e50,0x70(%rsp)
 10508f7:	mov    $0x10b8e50,%r12d
 10508fd:	mov    %r12,0xa0(%rsp)
 1050905:	mov    %r12,0x48(%rsp)
 105090a:	test   %rsi,-0x10(%r12)
 105090f:	je     1050920 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ec0>
 1050911:	mov    %r12,0x70(%rsp)
 1050916:	mov    %r12,0x98(%rsp)
 105091e:	jmp    105095b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1efb>
 1050920:	mov    -0x18(%r12),%rax
 1050925:	inc    %rax
 1050928:	je     1050ace <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x206e>
 105092e:	mov    %rax,-0x18(%r12)
 1050933:	mov    %r12,0x70(%rsp)
 1050938:	mov    %r12,0x98(%rsp)
 1050940:	mov    -0x20(%r12),%rax
 1050945:	dec    %rax
 1050948:	jne    1050956 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ef6>
 105094a:	cmpq   $0x0,-0x18(%r12)
 1050950:	je     1050a96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2036>
 1050956:	mov    %rax,-0x20(%r12)
 105095b:	movq   $0x0,0xa0(%rsp)
 1050967:	mov    0x30(%rsp),%rax
 105096c:	mov    0x20(%rax),%rdx
 1050970:	mov    0x10(%rsp),%rdi
 1050975:	mov    %r12,%rsi
 1050978:	call   10921b0 <myl_native_text_join>
 105097d:	test   %rax,%rax
 1050980:	je     10514b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a54>
 1050986:	mov    %rax,%rbx
 1050989:	mov    %rax,0x48(%rsp)
 105098e:	mov    %rax,0x70(%rsp)
 1050993:	mov    %rax,0x1c8(%rsp)
 105099b:	mov    0x8(%rsp),%rdi
 10509a0:	mov    %rax,%rsi
 10509a3:	call   10741d0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10509a8:	mov    %rax,%r13
 10509ab:	movabs $0x4000000000000002,%rsi
 10509b5:	test   %rsi,-0x10(%rbx)
 10509b9:	jne    10509d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f73>
 10509bb:	mov    -0x20(%rbx),%rax
 10509bf:	dec    %rax
 10509c2:	jne    10509cf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f6f>
 10509c4:	cmpq   $0x0,-0x18(%rbx)
 10509c9:	je     1050a6c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x200c>
 10509cf:	mov    %rax,-0x20(%rbx)
 10509d3:	movq   $0x0,0x1c8(%rsp)
 10509df:	test   %r12,%r12
 10509e2:	je     1050a12 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 10509e4:	test   %rsi,-0x10(%r12)
 10509e9:	jne    1050a06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa6>
 10509eb:	mov    -0x18(%r12),%rax
 10509f0:	dec    %rax
 10509f3:	jne    1050a01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa1>
 10509f5:	cmpq   $0x0,-0x20(%r12)
 10509fb:	je     1050aad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x204d>
 1050a01:	mov    %rax,-0x18(%r12)
 1050a06:	movq   $0x0,0x98(%rsp)
 1050a12:	mov    %rbp,%rcx
 1050a15:	add    %r13,%rcx
 1050a18:	jo     10514be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a5e>
 1050a1e:	mov    %rcx,%rax
 1050a21:	movabs $0x89705f3112a28fe5,%rdx
 1050a2b:	imul   %rdx
 1050a2e:	add    %rcx,%rdx
 1050a31:	mov    %rdx,%rax
 1050a34:	shr    $0x3f,%rax
 1050a38:	sar    $0x1d,%rdx
 1050a3c:	add    %rax,%rdx
 1050a3f:	imul   $0x3b9aca07,%rdx,%rax
 1050a46:	sub    %rax,%rcx
 1050a49:	mov    %rcx,%rbp
 1050a4c:	sar    $0x3f,%rbp
 1050a50:	and    $0x3b9aca07,%ebp
 1050a56:	add    %rcx,%rbp
 1050a59:	inc    %r15
 1050a5c:	cmp    %r15,0x20(%rsp)
 1050a61:	jne    10507a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d40>
 1050a67:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050a6c:	mov    0x10(%rsp),%rdi
 1050a71:	lea    0x1c8(%rsp),%rsi
 1050a79:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a7e:	movabs $0x4000000000000002,%rsi
 1050a88:	test   %r12,%r12
 1050a8b:	jne    10509e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f84>
 1050a91:	jmp    1050a12 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 1050a96:	mov    0x10(%rsp),%rdi
 1050a9b:	lea    0xa0(%rsp),%rsi
 1050aa3:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050aa8:	jmp    1050967 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f07>
 1050aad:	mov    0x10(%rsp),%rdi
 1050ab2:	lea    0x98(%rsp),%rsi
 1050aba:	call   1086150 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050abf:	movabs $0x4000000000000002,%rsi
 1050ac9:	jmp    1050a12 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 1050ace:	mov    $0x1007dbf,%esi
 1050ad3:	mov    0x8(%rsp),%rdi
 1050ad8:	call   108a70e <fail>
 1050add:	xor    %ebp,%ebp
 1050adf:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050ae4:	mov    0x8(%rsp),%rdi
 1050ae9:	mov    0x1860(%rdi),%rax
 1050af0:	test   %rax,%rax
 1050af3:	je     1051370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050af9:	mov    0x124(%rax),%esi
 1050aff:	movl   $0x0,0x124(%rax)
 1050b09:	call   1089eb0 <myl_qbe_rc_status>
 1050b0e:	xor    %ebp,%ebp
 1050b10:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050b15:	mov    0x8(%rsp),%rdi
 1050b1a:	mov    0x1860(%rdi),%rax
 1050b21:	test   %rax,%rax
 1050b24:	je     1051370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050b2a:	mov    0x124(%rax),%esi
 1050b30:	movl   $0x0,0x124(%rax)
 1050b3a:	call   1089eb0 <myl_qbe_rc_status>
 1050b3f:	xor    %ebp,%ebp
 1050b41:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050b46:	lea    0xc8(%rsp),%rsi
 1050b4e:	mov    0x10(%rsp),%rdi
 1050b53:	mov    %ebp,%r14d
 1050b56:	mov    %eax,%ebp
 1050b58:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050b5d:	movabs $0x4000000000000002,%rsi
 1050b67:	mov    %ebp,%eax
 1050b69:	mov    %r14d,%ebp
 1050b6c:	test   %eax,%eax
 1050b6e:	jne    105076e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0e>
 1050b74:	movq   $0x10b8b30,0x40(%rsp)
 1050b7d:	movq   $0x10b8b30,0x70(%rsp)
 1050b86:	movq   $0x10b8b30,0xc8(%rsp)
 1050b92:	mov    $0x10b8b30,%esi
 1050b97:	mov    %rbx,%rdi
 1050b9a:	call   1091d50 <myl_native_text_equal>
 1050b9f:	movabs $0x4000000000000002,%r8
 1050ba9:	test   %r8,0x67f70(%rip)        # 10b8b20 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 1050bb0:	jne    1050bd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2173>
 1050bb2:	mov    0x67f57(%rip),%rcx        # 10b8b10 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050bb9:	dec    %rcx
 1050bbc:	jne    1050bcc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x216c>
 1050bbe:	cmpq   $0x0,0x67f52(%rip)        # 10b8b18 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 1050bc6:	je     1050e04 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23a4>
 1050bcc:	mov    %rcx,0x67f3d(%rip)        # 10b8b10 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050bd3:	movq   $0x0,0xc8(%rsp)
 1050bdf:	test   %eax,%eax
 1050be1:	je     1050e2c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23cc>
 1050be7:	xor    %ebx,%ebx
 1050be9:	lea    0x1a8(%rsp),%r14
 1050bf1:	lea    0x138(%rsp),%r15
 1050bf9:	movabs $0x89705f3112a28fe5,%r13
 1050c03:	xor    %ebp,%ebp
 1050c05:	mov    0x18(%rsp),%rax
 1050c0a:	add    %rbx,%rax
 1050c0d:	jo     10514e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a84>
 1050c13:	mov    0x30(%rsp),%rcx
 1050c18:	mov    0x8(%rcx),%rdi
 1050c1c:	mov    (%rdi),%rcx
 1050c1f:	test   %rcx,%rcx
 1050c22:	js     10514f8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a98>
 1050c28:	je     1051505 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aa5>
 1050c2e:	mov    %rax,%rdx
 1050c31:	or     %rcx,%rdx
 1050c34:	shr    $0x20,%rdx
 1050c38:	je     1050c41 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e1>
 1050c3a:	cqto
 1050c3c:	idiv   %rcx
 1050c3f:	jmp    1050c45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e5>
 1050c41:	xor    %edx,%edx
 1050c43:	div    %ecx
 1050c45:	mov    %rdx,%rax
 1050c48:	sar    $0x3f,%rax
 1050c4c:	and    %rcx,%rax
 1050c4f:	add    %rdx,%rax
 1050c52:	mov    %rax,%rsi
 1050c55:	sar    $0x3f,%rsi
 1050c59:	and    %rcx,%rsi
 1050c5c:	add    %rax,%rsi
 1050c5f:	cmp    %rcx,%rsi
 1050c62:	jae    1051512 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ab2>
 1050c68:	mov    0x20(%rdi),%rax
 1050c6c:	mov    (%rax,%rsi,8),%rax
 1050c70:	test   %rax,%rax
 1050c73:	je     1050ca6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2246>
 1050c75:	mov    %rax,%rdi
 1050c78:	test   %r8,-0x10(%rax)
 1050c7c:	jne    1050c92 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2232>
 1050c7e:	mov    -0x18(%rax),%rcx
 1050c82:	inc    %rcx
 1050c85:	je     1050dca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236a>
 1050c8b:	mov    %rcx,-0x18(%rax)
 1050c8f:	mov    %rax,%rdi
 1050c92:	mov    %rax,0x138(%rsp)
 1050c9a:	testb  $0x4,0x10(%rdi)
 1050c9e:	jne    1050cb6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2256>
 1050ca0:	add    $0x18,%rdi
 1050ca4:	jmp    1050cc5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2265>
 1050ca6:	xor    %edi,%edi
 1050ca8:	mov    %rax,0x138(%rsp)
 1050cb0:	testb  $0x4,0x10(%rdi)
 1050cb4:	je     1050ca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2240>
 1050cb6:	mov    0x18(%rdi),%rcx
 1050cba:	mov    0x14(%rdi),%edx
 1050cbd:	lea    (%rcx,%rdx,1),%rdi
 1050cc1:	add    $0x18,%rdi
 1050cc5:	mov    0x8(%rax),%rsi
 1050cc9:	xor    %edx,%edx
 1050ccb:	mov    %r14,%rcx
 1050cce:	call   104a550 <myl_native_bytes_number_parse>
 1050cd3:	test   %eax,%eax
 1050cd5:	je     1050d38 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22d8>
 1050cd7:	mov    0x1a8(%rsp),%r12
 1050cdf:	movl   $0x1,0x158(%rsp)
 1050cea:	mov    %r12,0x160(%rsp)
 1050cf2:	mov    0x138(%rsp),%rax
 1050cfa:	test   %rax,%rax
 1050cfd:	movabs $0x4000000000000002,%r8
 1050d07:	je     1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d09:	test   %r8,-0x10(%rax)
 1050d0d:	jne    1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d0f:	mov    -0x18(%rax),%rcx
 1050d13:	dec    %rcx
 1050d16:	jne    1050d76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050d18:	cmpq   $0x0,-0x20(%rax)
 1050d1d:	jne    1050d76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050d1f:	mov    0x10(%rsp),%rdi
 1050d24:	mov    %r15,%rsi
 1050d27:	call   1086150 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050d2c:	movabs $0x4000000000000002,%r8
 1050d36:	jmp    1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d38:	movl   $0x0,0x158(%rsp)
 1050d43:	mov    0x138(%rsp),%rax
 1050d4b:	mov    $0x61,%r12d
 1050d51:	test   %rax,%rax
 1050d54:	movabs $0x4000000000000002,%r8
 1050d5e:	je     1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d60:	test   %r8,-0x10(%rax)
 1050d64:	jne    1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d66:	mov    -0x18(%rax),%rcx
 1050d6a:	dec    %rcx
 1050d6d:	jne    1050d76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050d6f:	cmpq   $0x0,-0x20(%rax)
 1050d74:	je     1050de8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2388>
 1050d76:	mov    %rcx,-0x18(%rax)
 1050d7a:	mov    %rbp,%rcx
 1050d7d:	add    %r12,%rcx
 1050d80:	jo     105151f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2abf>
 1050d86:	mov    %rcx,%rax
 1050d89:	imul   %r13
 1050d8c:	add    %rcx,%rdx
 1050d8f:	mov    %rdx,%rax
 1050d92:	shr    $0x3f,%rax
 1050d96:	sar    $0x1d,%rdx
 1050d9a:	add    %rax,%rdx
 1050d9d:	imul   $0x3b9aca07,%rdx,%rax
 1050da4:	sub    %rax,%rcx
 1050da7:	mov    %rcx,%rbp
 1050daa:	sar    $0x3f,%rbp
 1050dae:	and    $0x3b9aca07,%ebp
 1050db4:	add    %rcx,%rbp
 1050db7:	inc    %rbx
 1050dba:	cmp    %rbx,0x20(%rsp)
 1050dbf:	jne    1050c05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a5>
 1050dc5:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050dca:	mov    $0x1007dbf,%esi
 1050dcf:	mov    0x8(%rsp),%rdi
 1050dd4:	call   108a70e <fail>
 1050dd9:	movabs $0x4000000000000002,%r8
 1050de3:	xor    %r12d,%r12d
 1050de6:	jmp    1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050de8:	mov    0x10(%rsp),%rdi
 1050ded:	mov    %r15,%rsi
 1050df0:	call   1086150 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050df5:	movabs $0x4000000000000002,%r8
 1050dff:	jmp    1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050e04:	lea    0xc8(%rsp),%rsi
 1050e0c:	mov    0x10(%rsp),%rdi
 1050e11:	mov    %eax,%ebp
 1050e13:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050e18:	movabs $0x4000000000000002,%r8
 1050e22:	mov    %ebp,%eax
 1050e24:	test   %eax,%eax
 1050e26:	jne    1050be7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2187>
 1050e2c:	movq   $0x10b9038,0x70(%rsp)
 1050e35:	movq   $0x10b9038,0xc8(%rsp)
 1050e41:	mov    $0x10b9038,%esi
 1050e46:	mov    %rbx,%rdi
 1050e49:	call   1091d50 <myl_native_text_equal>
 1050e4e:	movabs $0x4000000000000002,%rcx
 1050e58:	test   %rcx,0x681c9(%rip)        # 10b9028 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1050e5f:	jne    1050e82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2422>
 1050e61:	mov    0x681b0(%rip),%rcx        # 10b9018 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050e68:	dec    %rcx
 1050e6b:	jne    1050e7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x241b>
 1050e6d:	cmpq   $0x0,0x681ab(%rip)        # 10b9020 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 1050e75:	je     1050fe9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2589>
 1050e7b:	mov    %rcx,0x68196(%rip)        # 10b9018 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050e82:	test   %eax,%eax
 1050e84:	je     1051007 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25a7>
 1050e8a:	xor    %ebx,%ebx
 1050e8c:	lea    0x1c8(%rsp),%r14
 1050e94:	movabs $0x89705f3112a28fe5,%r12
 1050e9e:	xor    %ebp,%ebp
 1050ea0:	mov    0x18(%rsp),%rax
 1050ea5:	add    %rbx,%rax
 1050ea8:	jo     1051531 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ad1>
 1050eae:	mov    0x30(%rsp),%rcx
 1050eb3:	mov    0x18(%rcx),%rdi
 1050eb7:	mov    (%rdi),%rcx
 1050eba:	test   %rcx,%rcx
 1050ebd:	js     1051545 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ae5>
 1050ec3:	je     1051552 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2af2>
 1050ec9:	mov    %rax,%rdx
 1050ecc:	or     %rcx,%rdx
 1050ecf:	shr    $0x20,%rdx
 1050ed3:	je     1050edc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x247c>
 1050ed5:	cqto
 1050ed7:	idiv   %rcx
 1050eda:	jmp    1050ee0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2480>
 1050edc:	xor    %edx,%edx
 1050ede:	div    %ecx
 1050ee0:	mov    %rdx,%rsi
 1050ee3:	sar    $0x3f,%rsi
 1050ee7:	and    %rcx,%rsi
 1050eea:	add    %rdx,%rsi
 1050eed:	cmp    %rcx,%rsi
 1050ef0:	jb     1050f08 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24a8>
 1050ef2:	mov    %rsi,%rax
 1050ef5:	sar    $0x3f,%rax
 1050ef9:	and    %rcx,%rax
 1050efc:	add    %rax,%rsi
 1050eff:	cmp    %rcx,%rsi
 1050f02:	jae    1051569 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b09>
 1050f08:	mov    0x20(%rdi),%rax
 1050f0c:	mov    (%rax,%rsi,8),%rsi
 1050f10:	mov    0x10(%rsp),%rdi
 1050f15:	call   104c080 <myl_native_text_integer>
 1050f1a:	test   %rax,%rax
 1050f1d:	je     105155f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aff>
 1050f23:	mov    %rax,%r15
 1050f26:	mov    %rax,0x70(%rsp)
 1050f2b:	mov    %rax,0x1c8(%rsp)
 1050f33:	mov    0x8(%rsp),%rdi
 1050f38:	mov    %rax,%rsi
 1050f3b:	call   10741d0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050f40:	movabs $0x4000000000000002,%rcx
 1050f4a:	test   %rcx,-0x10(%r15)
 1050f4e:	jne    1050f64 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2504>
 1050f50:	mov    -0x20(%r15),%rcx
 1050f54:	dec    %rcx
 1050f57:	jne    1050f60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2500>
 1050f59:	cmpq   $0x0,-0x18(%r15)
 1050f5e:	je     1050fbc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255c>
 1050f60:	mov    %rcx,-0x20(%r15)
 1050f64:	movq   $0x0,0x1c8(%rsp)
 1050f70:	mov    %rbp,%rcx
 1050f73:	add    %rax,%rcx
 1050f76:	jo     1050fd7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2577>
 1050f78:	mov    %rcx,%rax
 1050f7b:	imul   %r12
 1050f7e:	add    %rcx,%rdx
 1050f81:	mov    %rdx,%rax
 1050f84:	shr    $0x3f,%rax
 1050f88:	sar    $0x1d,%rdx
 1050f8c:	add    %rax,%rdx
 1050f8f:	imul   $0x3b9aca07,%rdx,%rax
 1050f96:	sub    %rax,%rcx
 1050f99:	mov    %rcx,%rbp
 1050f9c:	sar    $0x3f,%rbp
 1050fa0:	and    $0x3b9aca07,%ebp
 1050fa6:	add    %rcx,%rbp
 1050fa9:	inc    %rbx
 1050fac:	cmp    %rbx,0x20(%rsp)
 1050fb1:	jne    1050ea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2440>
 1050fb7:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050fbc:	mov    0x10(%rsp),%rdi
 1050fc1:	mov    %r14,%rsi
 1050fc4:	mov    %rax,%r15
 1050fc7:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050fcc:	mov    %r15,%rax
 1050fcf:	mov    %rbp,%rcx
 1050fd2:	add    %rax,%rcx
 1050fd5:	jno    1050f78 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2518>
 1050fd7:	mov    0x8(%rsp),%rdi
 1050fdc:	xor    %esi,%esi
 1050fde:	mov    %rbp,%rdx
 1050fe1:	mov    %rax,%rcx
 1050fe4:	call   108b120 <myl_qbe_fail_overflow_op>
 1050fe9:	lea    0xc8(%rsp),%rsi
 1050ff1:	mov    0x10(%rsp),%rdi
 1050ff6:	mov    %eax,%ebp
 1050ff8:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050ffd:	mov    %ebp,%eax
 1050fff:	test   %eax,%eax
 1051001:	jne    1050e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x242a>
 1051007:	movq   $0x10b9450,0x70(%rsp)
 1051010:	movq   $0x10b9450,0xc8(%rsp)
 105101c:	mov    $0x10b9450,%esi
 1051021:	mov    %rbx,%rdi
 1051024:	call   1091d50 <myl_native_text_equal>
 1051029:	movabs $0x4000000000000002,%rcx
 1051033:	test   %rcx,0x68406(%rip)        # 10b9440 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 105103a:	jne    105105d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25fd>
 105103c:	mov    0x683ed(%rip),%rcx        # 10b9430 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051043:	dec    %rcx
 1051046:	jne    1051056 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25f6>
 1051048:	cmpq   $0x0,0x683e8(%rip)        # 10b9438 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 1051050:	je     10510f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2697>
 1051056:	mov    %rcx,0x683d3(%rip)        # 10b9430 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 105105d:	test   %eax,%eax
 105105f:	je     1051115 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26b5>
 1051065:	xor    %ebx,%ebx
 1051067:	movabs $0x89705f3112a28fe5,%r14
 1051071:	xor    %ebp,%ebp
 1051073:	mov    0x18(%rsp),%rsi
 1051078:	add    %rbx,%rsi
 105107b:	jo     1051576 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b16>
 1051081:	mov    0x30(%rsp),%rax
 1051086:	mov    0x8(%rax),%rax
 105108a:	and    $0x1,%esi
 105108d:	mov    (%rax),%rdx
 1051090:	cmp    %rdx,%rsi
 1051093:	jae    105158a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b2a>
 1051099:	mov    0x20(%rax),%rax
 105109d:	mov    (%rax,%rsi,8),%rsi
 10510a1:	mov    0x8(%rsp),%rdi
 10510a6:	call   1068600 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 10510ab:	mov    %rbp,%rcx
 10510ae:	add    %rax,%rcx
 10510b1:	jo     1051594 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b34>
 10510b7:	mov    %rcx,%rax
 10510ba:	imul   %r14
 10510bd:	add    %rcx,%rdx
 10510c0:	mov    %rdx,%rax
 10510c3:	shr    $0x3f,%rax
 10510c7:	sar    $0x1d,%rdx
 10510cb:	add    %rax,%rdx
 10510ce:	imul   $0x3b9aca07,%rdx,%rax
 10510d5:	sub    %rax,%rcx
 10510d8:	mov    %rcx,%rbp
 10510db:	sar    $0x3f,%rbp
 10510df:	and    $0x3b9aca07,%ebp
 10510e5:	add    %rcx,%rbp
 10510e8:	inc    %rbx
 10510eb:	cmp    %rbx,0x20(%rsp)
 10510f0:	jne    1051073 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2613>
 10510f2:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10510f7:	lea    0xc8(%rsp),%rsi
 10510ff:	mov    0x10(%rsp),%rdi
 1051104:	mov    %eax,%ebp
 1051106:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105110b:	mov    %ebp,%eax
 105110d:	test   %eax,%eax
 105110f:	jne    1051065 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2605>
 1051115:	movq   $0x10b88e8,0x70(%rsp)
 105111e:	movq   $0x10b88e8,0xc8(%rsp)
 105112a:	mov    $0x10b88e8,%esi
 105112f:	mov    %rbx,%rdi
 1051132:	call   1091d50 <myl_native_text_equal>
 1051137:	movabs $0x4000000000000002,%rdx
 1051141:	test   %rdx,0x67790(%rip)        # 10b88d8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051148:	jne    105116b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x270b>
 105114a:	mov    0x67777(%rip),%rcx        # 10b88c8 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051151:	dec    %rcx
 1051154:	jne    1051164 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2704>
 1051156:	cmpq   $0x0,0x67772(%rip)        # 10b88d0 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 105115e:	je     10511ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x279f>
 1051164:	mov    %rcx,0x6775d(%rip)        # 10b88c8 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105116b:	test   %eax,%eax
 105116d:	je     1051227 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27c7>
 1051173:	xor    %ebx,%ebx
 1051175:	movabs $0x89705f3112a28fe5,%r14
 105117f:	xor    %ebp,%ebp
 1051181:	mov    0x18(%rsp),%rax
 1051186:	add    %rbx,%rax
 1051189:	jo     10515a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b46>
 105118f:	mov    0x30(%rsp),%rax
 1051194:	mov    0x8(%rax),%rax
 1051198:	cmpq   $0x0,(%rax)
 105119c:	je     10515ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b5a>
 10511a2:	mov    0x20(%rax),%rax
 10511a6:	mov    (%rax),%rsi
 10511a9:	mov    0x8(%rsp),%rdi
 10511ae:	call   106fb80 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 10511b3:	mov    %rbp,%rcx
 10511b6:	add    %rax,%rcx
 10511b9:	jo     10515c8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b68>
 10511bf:	mov    %rcx,%rax
 10511c2:	imul   %r14
 10511c5:	add    %rcx,%rdx
 10511c8:	mov    %rdx,%rax
 10511cb:	shr    $0x3f,%rax
 10511cf:	sar    $0x1d,%rdx
 10511d3:	add    %rax,%rdx
 10511d6:	imul   $0x3b9aca07,%rdx,%rax
 10511dd:	sub    %rax,%rcx
 10511e0:	mov    %rcx,%rbp
 10511e3:	sar    $0x3f,%rbp
 10511e7:	and    $0x3b9aca07,%ebp
 10511ed:	add    %rcx,%rbp
 10511f0:	inc    %rbx
 10511f3:	cmp    %rbx,0x20(%rsp)
 10511f8:	jne    1051181 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 10511fa:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10511ff:	lea    0xc8(%rsp),%rsi
 1051207:	mov    0x10(%rsp),%rdi
 105120c:	mov    %eax,%ebp
 105120e:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051213:	movabs $0x4000000000000002,%rdx
 105121d:	mov    %ebp,%eax
 105121f:	test   %eax,%eax
 1051221:	jne    1051173 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2713>
 1051227:	movq   $0x10b89b8,0x70(%rsp)
 1051230:	movq   $0x10b89b8,0xc8(%rsp)
 105123c:	mov    $0x10b89b8,%esi
 1051241:	mov    %rbx,%rdi
 1051244:	mov    %rdx,%rbx
 1051247:	call   1091d50 <myl_native_text_equal>
 105124c:	test   %rbx,0x67755(%rip)        # 10b89a8 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051253:	jne    105127a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x281a>
 1051255:	mov    %eax,%ebx
 1051257:	mov    0x6773a(%rip),%rax        # 10b8998 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 105125e:	dec    %rax
 1051261:	jne    1051271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2811>
 1051263:	cmpq   $0x0,0x67735(%rip)        # 10b89a0 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 105126b:	je     1051351 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f1>
 1051271:	mov    %rax,0x67720(%rip)        # 10b8998 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051278:	mov    %ebx,%eax
 105127a:	test   %eax,%eax
 105127c:	je     105134a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ea>
 1051282:	xor    %ebx,%ebx
 1051284:	movabs $0x7878787878787879,%r14
 105128e:	movabs $0x89705f3112a28fe5,%r15
 1051298:	xor    %ebp,%ebp
 105129a:	mov    0x18(%rsp),%rcx
 105129f:	add    %rbx,%rcx
 10512a2:	jo     10515da <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b7a>
 10512a8:	mov    0x30(%rsp),%rax
 10512ad:	mov    0x8(%rax),%rax
 10512b1:	cmpq   $0x0,(%rax)
 10512b5:	je     10515ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b8e>
 10512bb:	mov    0x20(%rax),%rax
 10512bf:	mov    (%rax),%rsi
 10512c2:	mov    %rcx,%rax
 10512c5:	imul   %r14
 10512c8:	mov    %rdx,%rax
 10512cb:	shr    $0x3f,%rax
 10512cf:	sar    $0x3,%rdx
 10512d3:	add    %rax,%rdx
 10512d6:	mov    %rdx,%rax
 10512d9:	shl    $0x4,%rax
 10512dd:	add    %rdx,%rax
 10512e0:	sub    %rax,%rcx
 10512e3:	mov    %rcx,%rdx
 10512e6:	sar    $0x3f,%rdx
 10512ea:	and    $0x11,%edx
 10512ed:	add    %rcx,%rdx
 10512f0:	mov    0x8(%rsp),%rdi
 10512f5:	call   1057dc0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 10512fa:	mov    %rbp,%rcx
 10512fd:	add    %rax,%rcx
 1051300:	jo     10515fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b9c>
 1051306:	mov    %rcx,%rax
 1051309:	imul   %r15
 105130c:	add    %rcx,%rdx
 105130f:	mov    %rdx,%rax
 1051312:	shr    $0x3f,%rax
 1051316:	sar    $0x1d,%rdx
 105131a:	add    %rax,%rdx
 105131d:	imul   $0x3b9aca07,%rdx,%rax
 1051324:	sub    %rax,%rcx
 1051327:	mov    %rcx,%rbp
 105132a:	sar    $0x3f,%rbp
 105132e:	and    $0x3b9aca07,%ebp
 1051334:	add    %rcx,%rbp
 1051337:	inc    %rbx
 105133a:	cmp    %rbx,0x20(%rsp)
 105133f:	jne    105129a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283a>
 1051345:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 105134a:	xor    %ebp,%ebp
 105134c:	jmp    104f271 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1051351:	lea    0xc8(%rsp),%rsi
 1051359:	mov    0x10(%rsp),%rdi
 105135e:	call   10861c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051363:	jmp    1051278 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2818>
 1051368:	vzeroupper
 105136b:	call   10ab460 <abort@plt>
 1051370:	vzeroupper
 1051373:	call   10997e7 <myl_rc_invariant_failed>
 1051378:	mov    0x8(%rsp),%rdi
 105137d:	xor    %esi,%esi
 105137f:	vzeroupper
 1051382:	call   108b120 <myl_qbe_fail_overflow_op>
 1051387:	mov    0x8(%rsp),%rdi
 105138c:	xor    %esi,%esi
 105138e:	mov    0x18(%rsp),%rdx
 1051393:	mov    %rbx,%rcx
 1051396:	vzeroupper
 1051399:	call   108b120 <myl_qbe_fail_overflow_op>
 105139e:	mov    0x8(%rsp),%rdi
 10513a3:	xor    %esi,%esi
 10513a5:	mov    %rbp,%rdx
 10513a8:	mov    %r14,%rcx
 10513ab:	vzeroupper
 10513ae:	call   108b120 <myl_qbe_fail_overflow_op>
 10513b3:	mov    0x8(%rsp),%rdi
 10513b8:	xor    %esi,%esi
 10513ba:	mov    %r12,%rdx
 10513bd:	mov    %rax,%rcx
 10513c0:	call   108b120 <myl_qbe_fail_overflow_op>
 10513c5:	mov    0x8(%rsp),%rdi
 10513ca:	vzeroupper
 10513cd:	call   108aed0 <myl_qbe_fail_iteration>
 10513d2:	mov    0x8(%rsp),%rdi
 10513d7:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 10513dc:	mov    0x8(%rsp),%rdi
 10513e1:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 10513e6:	mov    0x8(%rsp),%rdi
 10513eb:	xor    %esi,%esi
 10513ed:	mov    0x18(%rsp),%rdx
 10513f2:	mov    %rbx,%rcx
 10513f5:	call   108b120 <myl_qbe_fail_overflow_op>
 10513fa:	mov    0x8(%rsp),%rdi
 10513ff:	xor    %esi,%esi
 1051401:	mov    0x18(%rsp),%rdx
 1051406:	mov    %rbx,%rcx
 1051409:	call   108b120 <myl_qbe_fail_overflow_op>
 105140e:	mov    0x8(%rsp),%rdi
 1051413:	xor    %esi,%esi
 1051415:	xor    %edx,%edx
 1051417:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 105141c:	mov    0x8(%rsp),%rdi
 1051421:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 1051426:	mov    $0x1,%ecx
 105142b:	mov    0x8(%rsp),%rdi
 1051430:	xor    %esi,%esi
 1051432:	mov    %r15,%rdx
 1051435:	call   108b120 <myl_qbe_fail_overflow_op>
 105143a:	mov    %r14,%rdi
 105143d:	call   108b1e0 <myl_qbe_fail_frame>
 1051442:	mov    0x8(%rsp),%rdi
 1051447:	vzeroupper
 105144a:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 105144f:	mov    0x8(%rsp),%rdi
 1051454:	xor    %esi,%esi
 1051456:	mov    0x18(%rsp),%rdx
 105145b:	vzeroupper
 105145e:	call   108b120 <myl_qbe_fail_overflow_op>
 1051463:	mov    0x8(%rsp),%rdi
 1051468:	vzeroupper
 105146b:	call   108b1e0 <myl_qbe_fail_frame>
 1051470:	mov    0x8(%rsp),%rdi
 1051475:	vzeroupper
 1051478:	call   108aec0 <myl_qbe_fail_empty_separator>
 105147d:	mov    0x8(%rsp),%rdi
 1051482:	vzeroupper
 1051485:	call   108add0 <myl_qbe_fail_allocation>
 105148a:	mov    0x8(%rsp),%rdi
 105148f:	mov    %r14,%rsi
 1051492:	vzeroupper
 1051495:	call   108b180 <myl_qbe_fail_cast>
 105149a:	mov    $0x2,%esi
 105149f:	mov    $0x7,%ecx
 10514a4:	mov    0x8(%rsp),%rdi
 10514a9:	mov    %r14,%rdx
 10514ac:	vzeroupper
 10514af:	call   108b120 <myl_qbe_fail_overflow_op>
 10514b4:	mov    0x8(%rsp),%rdi
 10514b9:	call   108add0 <myl_qbe_fail_allocation>
 10514be:	mov    0x8(%rsp),%rdi
 10514c3:	xor    %esi,%esi
 10514c5:	mov    %rbp,%rdx
 10514c8:	mov    %r13,%rcx
 10514cb:	call   108b120 <myl_qbe_fail_overflow_op>
 10514d0:	mov    0x8(%rsp),%rdi
 10514d5:	xor    %esi,%esi
 10514d7:	mov    0x18(%rsp),%rdx
 10514dc:	mov    %r15,%rcx
 10514df:	call   108b120 <myl_qbe_fail_overflow_op>
 10514e4:	mov    0x8(%rsp),%rdi
 10514e9:	xor    %esi,%esi
 10514eb:	mov    0x18(%rsp),%rdx
 10514f0:	mov    %rbx,%rcx
 10514f3:	call   108b120 <myl_qbe_fail_overflow_op>
 10514f8:	mov    0x8(%rsp),%rdi
 10514fd:	mov    %rcx,%rsi
 1051500:	call   108b180 <myl_qbe_fail_cast>
 1051505:	mov    0x8(%rsp),%rdi
 105150a:	mov    %rax,%rsi
 105150d:	call   108b0d0 <myl_qbe_fail_division>
 1051512:	mov    0x8(%rsp),%rdi
 1051517:	mov    %rcx,%rdx
 105151a:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 105151f:	mov    0x8(%rsp),%rdi
 1051524:	xor    %esi,%esi
 1051526:	mov    %rbp,%rdx
 1051529:	mov    %r12,%rcx
 105152c:	call   108b120 <myl_qbe_fail_overflow_op>
 1051531:	mov    0x8(%rsp),%rdi
 1051536:	xor    %esi,%esi
 1051538:	mov    0x18(%rsp),%rdx
 105153d:	mov    %rbx,%rcx
 1051540:	call   108b120 <myl_qbe_fail_overflow_op>
 1051545:	mov    0x8(%rsp),%rdi
 105154a:	mov    %rcx,%rsi
 105154d:	call   108b180 <myl_qbe_fail_cast>
 1051552:	mov    0x8(%rsp),%rdi
 1051557:	mov    %rax,%rsi
 105155a:	call   108b0d0 <myl_qbe_fail_division>
 105155f:	mov    0x8(%rsp),%rdi
 1051564:	call   108add0 <myl_qbe_fail_allocation>
 1051569:	mov    0x8(%rsp),%rdi
 105156e:	mov    %rcx,%rdx
 1051571:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 1051576:	mov    0x8(%rsp),%rdi
 105157b:	xor    %esi,%esi
 105157d:	mov    0x18(%rsp),%rdx
 1051582:	mov    %rbx,%rcx
 1051585:	call   108b120 <myl_qbe_fail_overflow_op>
 105158a:	mov    0x8(%rsp),%rdi
 105158f:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 1051594:	mov    0x8(%rsp),%rdi
 1051599:	xor    %esi,%esi
 105159b:	mov    %rbp,%rdx
 105159e:	mov    %rax,%rcx
 10515a1:	call   108b120 <myl_qbe_fail_overflow_op>
 10515a6:	mov    0x8(%rsp),%rdi
 10515ab:	xor    %esi,%esi
 10515ad:	mov    0x18(%rsp),%rdx
 10515b2:	mov    %rbx,%rcx
 10515b5:	call   108b120 <myl_qbe_fail_overflow_op>
 10515ba:	mov    0x8(%rsp),%rdi
 10515bf:	xor    %esi,%esi
 10515c1:	xor    %edx,%edx
 10515c3:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 10515c8:	mov    0x8(%rsp),%rdi
 10515cd:	xor    %esi,%esi
 10515cf:	mov    %rbp,%rdx
 10515d2:	mov    %rax,%rcx
 10515d5:	call   108b120 <myl_qbe_fail_overflow_op>
 10515da:	mov    0x8(%rsp),%rdi
 10515df:	xor    %esi,%esi
 10515e1:	mov    0x18(%rsp),%rdx
 10515e6:	mov    %rbx,%rcx
 10515e9:	call   108b120 <myl_qbe_fail_overflow_op>
 10515ee:	mov    0x8(%rsp),%rdi
 10515f3:	xor    %esi,%esi
 10515f5:	xor    %edx,%edx
 10515f7:	call   108b010 <myl_qbe_fail_normalized_index_bounds>
 10515fc:	mov    0x8(%rsp),%rdi
 1051601:	xor    %esi,%esi
 1051603:	mov    %rbp,%rdx
 1051606:	mov    %rax,%rcx
 1051609:	call   108b120 <myl_qbe_fail_overflow_op>
 105160e:	int3
 105160f:	int3


0000000001091d50 <myl_native_text_equal>:
 1091d50:	mov    $0x1,%eax
 1091d55:	cmp    %rsi,%rdi
 1091d58:	je     1091e51 <myl_native_text_equal+0x101>
 1091d5e:	test   %rdi,%rdi
 1091d61:	sete   %cl
 1091d64:	test   %rsi,%rsi
 1091d67:	sete   %dl
 1091d6a:	xor    %eax,%eax
 1091d6c:	or     %cl,%dl
 1091d6e:	jne    1091e51 <myl_native_text_equal+0x101>
 1091d74:	mov    0x8(%rdi),%rdx
 1091d78:	cmp    0x8(%rsi),%rdx
 1091d7c:	jne    1091e51 <myl_native_text_equal+0x101>
 1091d82:	mov    $0x1,%eax
 1091d87:	test   %rdx,%rdx
 1091d8a:	je     1091e51 <myl_native_text_equal+0x101>
 1091d90:	testb  $0x4,0x10(%rdi)
 1091d94:	jne    1091dd6 <myl_native_text_equal+0x86>
 1091d96:	add    $0x18,%rdi
 1091d9a:	testb  $0x4,0x10(%rsi)
 1091d9e:	je     1091deb <myl_native_text_equal+0x9b>
 1091da0:	mov    0x18(%rsi),%rax
 1091da4:	mov    0x14(%rsi),%ecx
 1091da7:	lea    (%rax,%rcx,1),%rsi
 1091dab:	add    $0x18,%rsi
 1091daf:	cmp    $0x10,%rdx
 1091db3:	jbe    1091df5 <myl_native_text_equal+0xa5>
 1091db5:	cmp    $0x100,%rdx
 1091dbc:	ja     1091e60 <equal_large_octets>
 1091dc2:	push   %rbp
 1091dc3:	mov    %rsp,%rbp
 1091dc6:	call   10ab480 <bcmp@plt>
 1091dcb:	mov    %eax,%ecx
 1091dcd:	xor    %eax,%eax
 1091dcf:	test   %ecx,%ecx
 1091dd1:	sete   %al
 1091dd4:	pop    %rbp
 1091dd5:	ret
 1091dd6:	mov    0x18(%rdi),%rax
 1091dda:	mov    0x14(%rdi),%ecx
 1091ddd:	lea    (%rax,%rcx,1),%rdi
 1091de1:	add    $0x18,%rdi
 1091de5:	testb  $0x4,0x10(%rsi)
 1091de9:	jne    1091da0 <myl_native_text_equal+0x50>
 1091deb:	add    $0x18,%rsi
 1091def:	cmp    $0x10,%rdx
 1091df3:	ja     1091db5 <myl_native_text_equal+0x65>
 1091df5:	cmp    $0x8,%rdx
 1091df9:	jb     1091e12 <myl_native_text_equal+0xc2>
 1091dfb:	mov    (%rdi),%rcx
 1091dfe:	mov    -0x8(%rdi,%rdx,1),%rdi
 1091e03:	xor    (%rsi),%rcx
 1091e06:	xor    -0x8(%rsi,%rdx,1),%rdi
 1091e0b:	xor    %eax,%eax
 1091e0d:	or     %rcx,%rdi
 1091e10:	jmp    1091e4e <myl_native_text_equal+0xfe>
 1091e12:	cmp    $0x4,%rdx
 1091e16:	jb     1091e2a <myl_native_text_equal+0xda>
 1091e18:	mov    (%rdi),%ecx
 1091e1a:	mov    -0x4(%rdi,%rdx,1),%edi
 1091e1e:	xor    (%rsi),%ecx
 1091e20:	xor    -0x4(%rsi,%rdx,1),%edi
 1091e24:	xor    %eax,%eax
 1091e26:	or     %ecx,%edi
 1091e28:	jmp    1091e4e <myl_native_text_equal+0xfe>
 1091e2a:	cmp    $0x1,%rdx
 1091e2e:	jne    1091e39 <myl_native_text_equal+0xe9>
 1091e30:	movzbl (%rdi),%ecx
 1091e33:	xor    %eax,%eax
 1091e35:	cmp    (%rsi),%cl
 1091e37:	jmp    1091e4e <myl_native_text_equal+0xfe>
 1091e39:	movzwl (%rdi),%ecx
 1091e3c:	movzwl -0x2(%rdi,%rdx,1),%edi
 1091e41:	xor    (%rsi),%cx
 1091e44:	xor    -0x2(%rsi,%rdx,1),%di
 1091e49:	xor    %eax,%eax
 1091e4b:	or     %cx,%di
 1091e4e:	sete   %al
 1091e51:	ret
 1091e52:	int3
 1091e53:	int3
 1091e54:	int3
 1091e55:	int3
 1091e56:	int3
 1091e57:	int3
 1091e58:	int3
 1091e59:	int3
 1091e5a:	int3
 1091e5b:	int3
 1091e5c:	int3
 1091e5d:	int3
 1091e5e:	int3
 1091e5f:	int3


0000000001091e60 <equal_large_octets>:
 1091e60:	mov    (%rdi),%rcx
 1091e63:	xor    %eax,%eax
 1091e65:	cmp    (%rsi),%rcx
 1091e68:	jne    1091e95 <equal_large_octets+0x35>
 1091e6a:	mov    -0x8(%rsi,%rdx,1),%rcx
 1091e6f:	cmp    %rcx,-0x8(%rdi,%rdx,1)
 1091e74:	jne    1091e95 <equal_large_octets+0x35>
 1091e76:	push   %rbp
 1091e77:	mov    %rsp,%rbp
 1091e7a:	add    $0x8,%rdi
 1091e7e:	add    $0x8,%rsi
 1091e82:	add    $0xfffffffffffffff0,%rdx
 1091e86:	call   10ab480 <bcmp@plt>
 1091e8b:	mov    %eax,%ecx
 1091e8d:	xor    %eax,%eax
 1091e8f:	test   %ecx,%ecx
 1091e91:	sete   %al
 1091e94:	pop    %rbp
 1091e95:	ret
 1091e96:	int3
 1091e97:	int3
 1091e98:	int3
 1091e99:	int3
 1091e9a:	int3
 1091e9b:	int3
 1091e9c:	int3
 1091e9d:	int3
 1091e9e:	int3
 1091e9f:	int3

