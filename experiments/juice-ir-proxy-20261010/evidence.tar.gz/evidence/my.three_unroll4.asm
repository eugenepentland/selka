
.tmp/juice-ir/kernels:     file format elf64-x86-64


Disassembly of section .text:

000000000103bee0 <my.three_unroll4>:
 103bee0:	48 89 f0             	mov    rax,rsi
 103bee3:	48 85 ff             	test   rdi,rdi
 103bee6:	0f 84 cc 01 00 00    	je     103c0b8 <my.three_unroll4+0x1d8>
 103beec:	48 83 ff 01          	cmp    rdi,0x1
 103bef0:	0f 84 4a 01 00 00    	je     103c040 <my.three_unroll4+0x160>
 103bef6:	48 b9 fe ff ff ff ff 	movabs rcx,0x7ffffffffffffffe
 103befd:	ff ff 7f 
 103bf00:	48 21 f9             	and    rcx,rdi
 103bf03:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103bf0a:	0f 1f 84 00 00 00 00 
 103bf11:	00 
 103bf12:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103bf19:	0f 1f 84 00 00 00 00 
 103bf20:	00 
 103bf21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103bf28:	0f 1f 84 00 00 00 00 
 103bf2f:	00 
 103bf30:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103bf37:	0f 1f 84 00 00 00 00 
 103bf3e:	00 
 103bf3f:	90                   	nop
 103bf40:	48 89 c2             	mov    rdx,rax
 103bf43:	48 c1 e2 0d          	shl    rdx,0xd
 103bf47:	48 31 c2             	xor    rdx,rax
 103bf4a:	48 89 d0             	mov    rax,rdx
 103bf4d:	48 c1 f8 07          	sar    rax,0x7
 103bf51:	48 31 d0             	xor    rax,rdx
 103bf54:	48 89 c2             	mov    rdx,rax
 103bf57:	48 c1 e2 11          	shl    rdx,0x11
 103bf5b:	48 31 c2             	xor    rdx,rax
 103bf5e:	48 89 d0             	mov    rax,rdx
 103bf61:	48 c1 e0 0d          	shl    rax,0xd
 103bf65:	48 31 d0             	xor    rax,rdx
 103bf68:	48 89 c2             	mov    rdx,rax
 103bf6b:	48 c1 fa 07          	sar    rdx,0x7
 103bf6f:	48 31 c2             	xor    rdx,rax
 103bf72:	48 89 d0             	mov    rax,rdx
 103bf75:	48 c1 e0 11          	shl    rax,0x11
 103bf79:	48 31 d0             	xor    rax,rdx
 103bf7c:	48 89 c2             	mov    rdx,rax
 103bf7f:	48 c1 e2 0d          	shl    rdx,0xd
 103bf83:	48 31 c2             	xor    rdx,rax
 103bf86:	48 89 d0             	mov    rax,rdx
 103bf89:	48 c1 f8 07          	sar    rax,0x7
 103bf8d:	48 31 d0             	xor    rax,rdx
 103bf90:	48 89 c2             	mov    rdx,rax
 103bf93:	48 c1 e2 11          	shl    rdx,0x11
 103bf97:	48 31 c2             	xor    rdx,rax
 103bf9a:	48 89 d0             	mov    rax,rdx
 103bf9d:	48 c1 e0 0d          	shl    rax,0xd
 103bfa1:	48 31 d0             	xor    rax,rdx
 103bfa4:	48 89 c2             	mov    rdx,rax
 103bfa7:	48 c1 fa 07          	sar    rdx,0x7
 103bfab:	48 31 c2             	xor    rdx,rax
 103bfae:	48 89 d0             	mov    rax,rdx
 103bfb1:	48 c1 e0 11          	shl    rax,0x11
 103bfb5:	48 31 d0             	xor    rax,rdx
 103bfb8:	48 89 c2             	mov    rdx,rax
 103bfbb:	48 c1 e2 0d          	shl    rdx,0xd
 103bfbf:	48 31 c2             	xor    rdx,rax
 103bfc2:	48 89 d0             	mov    rax,rdx
 103bfc5:	48 c1 f8 07          	sar    rax,0x7
 103bfc9:	48 31 d0             	xor    rax,rdx
 103bfcc:	48 89 c2             	mov    rdx,rax
 103bfcf:	48 c1 e2 11          	shl    rdx,0x11
 103bfd3:	48 31 c2             	xor    rdx,rax
 103bfd6:	48 89 d0             	mov    rax,rdx
 103bfd9:	48 c1 e0 0d          	shl    rax,0xd
 103bfdd:	48 31 d0             	xor    rax,rdx
 103bfe0:	48 89 c2             	mov    rdx,rax
 103bfe3:	48 c1 fa 07          	sar    rdx,0x7
 103bfe7:	48 31 c2             	xor    rdx,rax
 103bfea:	48 89 d0             	mov    rax,rdx
 103bfed:	48 c1 e0 11          	shl    rax,0x11
 103bff1:	48 31 d0             	xor    rax,rdx
 103bff4:	48 89 c2             	mov    rdx,rax
 103bff7:	48 c1 e2 0d          	shl    rdx,0xd
 103bffb:	48 31 c2             	xor    rdx,rax
 103bffe:	48 89 d0             	mov    rax,rdx
 103c001:	48 c1 f8 07          	sar    rax,0x7
 103c005:	48 31 d0             	xor    rax,rdx
 103c008:	48 89 c2             	mov    rdx,rax
 103c00b:	48 c1 e2 11          	shl    rdx,0x11
 103c00f:	48 31 c2             	xor    rdx,rax
 103c012:	48 89 d0             	mov    rax,rdx
 103c015:	48 c1 e0 0d          	shl    rax,0xd
 103c019:	48 31 d0             	xor    rax,rdx
 103c01c:	48 89 c2             	mov    rdx,rax
 103c01f:	48 c1 fa 07          	sar    rdx,0x7
 103c023:	48 31 c2             	xor    rdx,rax
 103c026:	48 89 d0             	mov    rax,rdx
 103c029:	48 c1 e0 11          	shl    rax,0x11
 103c02d:	48 31 d0             	xor    rax,rdx
 103c030:	48 83 c1 fe          	add    rcx,0xfffffffffffffffe
 103c034:	0f 85 06 ff ff ff    	jne    103bf40 <my.three_unroll4+0x60>
 103c03a:	40 f6 c7 01          	test   dil,0x1
 103c03e:	74 78                	je     103c0b8 <my.three_unroll4+0x1d8>
 103c040:	48 89 c1             	mov    rcx,rax
 103c043:	48 c1 e1 0d          	shl    rcx,0xd
 103c047:	48 31 c1             	xor    rcx,rax
 103c04a:	48 89 c8             	mov    rax,rcx
 103c04d:	48 c1 f8 07          	sar    rax,0x7
 103c051:	48 31 c8             	xor    rax,rcx
 103c054:	48 89 c1             	mov    rcx,rax
 103c057:	48 c1 e1 11          	shl    rcx,0x11
 103c05b:	48 31 c1             	xor    rcx,rax
 103c05e:	48 89 c8             	mov    rax,rcx
 103c061:	48 c1 e0 0d          	shl    rax,0xd
 103c065:	48 31 c8             	xor    rax,rcx
 103c068:	48 89 c1             	mov    rcx,rax
 103c06b:	48 c1 f9 07          	sar    rcx,0x7
 103c06f:	48 31 c1             	xor    rcx,rax
 103c072:	48 89 c8             	mov    rax,rcx
 103c075:	48 c1 e0 11          	shl    rax,0x11
 103c079:	48 31 c8             	xor    rax,rcx
 103c07c:	48 89 c1             	mov    rcx,rax
 103c07f:	48 c1 e1 0d          	shl    rcx,0xd
 103c083:	48 31 c1             	xor    rcx,rax
 103c086:	48 89 c8             	mov    rax,rcx
 103c089:	48 c1 f8 07          	sar    rax,0x7
 103c08d:	48 31 c8             	xor    rax,rcx
 103c090:	48 89 c1             	mov    rcx,rax
 103c093:	48 c1 e1 11          	shl    rcx,0x11
 103c097:	48 31 c1             	xor    rcx,rax
 103c09a:	48 89 c8             	mov    rax,rcx
 103c09d:	48 c1 e0 0d          	shl    rax,0xd
 103c0a1:	48 31 c8             	xor    rax,rcx
 103c0a4:	48 89 c1             	mov    rcx,rax
 103c0a7:	48 c1 f9 07          	sar    rcx,0x7
 103c0ab:	48 31 c1             	xor    rcx,rax
 103c0ae:	48 89 c8             	mov    rax,rcx
 103c0b1:	48 c1 e0 11          	shl    rax,0x11
 103c0b5:	48 31 c8             	xor    rax,rcx
 103c0b8:	c3                   	ret

Disassembly of section .plt:
