
.tmp/juice-ir/kernels:     file format elf64-x86-64


Disassembly of section .text:

000000000103ca80 <my.lanes4_fused>:
 103ca80:	c4 e1 f9 6e c6       	vmovq  xmm0,rsi
 103ca85:	c4 e2 79 59 c8       	vpbroadcastq xmm1,xmm0
 103ca8a:	c5 f1 ef 05 8e 77 fc 	vpxor  xmm0,xmm1,XMMWORD PTR [rip+0xfffffffffffc778e]        # 1004220 <core_run_timed_out.message+0x150>
 103ca91:	ff 
 103ca92:	48 85 ff             	test   rdi,rdi
 103ca95:	0f 84 c6 01 00 00    	je     103cc61 <my.lanes4_fused+0x1e1>
 103ca9b:	c5 f1 ef 0d 4d 77 fc 	vpxor  xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffc774d]        # 10041f0 <core_run_timed_out.message+0x120>
 103caa2:	ff 
 103caa3:	89 f8                	mov    eax,edi
 103caa5:	83 e0 03             	and    eax,0x3
 103caa8:	48 83 ff 04          	cmp    rdi,0x4
 103caac:	0f 82 4e 01 00 00    	jb     103cc00 <my.lanes4_fused+0x180>
 103cab2:	48 b9 fc ff ff ff ff 	movabs rcx,0x7ffffffffffffffc
 103cab9:	ff ff 7f 
 103cabc:	48 21 cf             	and    rdi,rcx
 103cabf:	90                   	nop
 103cac0:	c5 e9 73 f1 0d       	vpsllq xmm2,xmm1,0xd
 103cac5:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cac9:	c5 e9 72 e1 07       	vpsrad xmm2,xmm1,0x7
 103cace:	c5 e1 73 d1 07       	vpsrlq xmm3,xmm1,0x7
 103cad3:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cad9:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cadd:	c5 e9 73 f1 11       	vpsllq xmm2,xmm1,0x11
 103cae2:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cae6:	c5 e9 73 f0 0d       	vpsllq xmm2,xmm0,0xd
 103caeb:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103caef:	c5 e9 72 e0 07       	vpsrad xmm2,xmm0,0x7
 103caf4:	c5 e1 73 d0 07       	vpsrlq xmm3,xmm0,0x7
 103caf9:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103caff:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb03:	c5 e9 73 f0 11       	vpsllq xmm2,xmm0,0x11
 103cb08:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb0c:	c5 e9 73 f1 0d       	vpsllq xmm2,xmm1,0xd
 103cb11:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb15:	c5 e9 72 e1 07       	vpsrad xmm2,xmm1,0x7
 103cb1a:	c5 e1 73 d1 07       	vpsrlq xmm3,xmm1,0x7
 103cb1f:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cb25:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb29:	c5 e9 73 f1 11       	vpsllq xmm2,xmm1,0x11
 103cb2e:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb32:	c5 e9 73 f0 0d       	vpsllq xmm2,xmm0,0xd
 103cb37:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb3b:	c5 e9 72 e0 07       	vpsrad xmm2,xmm0,0x7
 103cb40:	c5 e1 73 d0 07       	vpsrlq xmm3,xmm0,0x7
 103cb45:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cb4b:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb4f:	c5 e9 73 f0 11       	vpsllq xmm2,xmm0,0x11
 103cb54:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb58:	c5 e9 73 f1 0d       	vpsllq xmm2,xmm1,0xd
 103cb5d:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb61:	c5 e9 72 e1 07       	vpsrad xmm2,xmm1,0x7
 103cb66:	c5 e1 73 d1 07       	vpsrlq xmm3,xmm1,0x7
 103cb6b:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cb71:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb75:	c5 e9 73 f1 11       	vpsllq xmm2,xmm1,0x11
 103cb7a:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cb7e:	c5 e9 73 f0 0d       	vpsllq xmm2,xmm0,0xd
 103cb83:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb87:	c5 e9 72 e0 07       	vpsrad xmm2,xmm0,0x7
 103cb8c:	c5 e1 73 d0 07       	vpsrlq xmm3,xmm0,0x7
 103cb91:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cb97:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cb9b:	c5 e9 73 f0 11       	vpsllq xmm2,xmm0,0x11
 103cba0:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cba4:	c5 e9 73 f1 0d       	vpsllq xmm2,xmm1,0xd
 103cba9:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cbad:	c5 e9 72 e1 07       	vpsrad xmm2,xmm1,0x7
 103cbb2:	c5 e1 73 d1 07       	vpsrlq xmm3,xmm1,0x7
 103cbb7:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cbbd:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cbc1:	c5 e9 73 f1 11       	vpsllq xmm2,xmm1,0x11
 103cbc6:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cbca:	c5 e9 73 f0 0d       	vpsllq xmm2,xmm0,0xd
 103cbcf:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cbd3:	c5 e9 72 e0 07       	vpsrad xmm2,xmm0,0x7
 103cbd8:	c5 e1 73 d0 07       	vpsrlq xmm3,xmm0,0x7
 103cbdd:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cbe3:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cbe7:	c5 e9 73 f0 11       	vpsllq xmm2,xmm0,0x11
 103cbec:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cbf0:	48 83 c7 fc          	add    rdi,0xfffffffffffffffc
 103cbf4:	0f 85 c6 fe ff ff    	jne    103cac0 <my.lanes4_fused+0x40>
 103cbfa:	48 85 c0             	test   rax,rax
 103cbfd:	74 52                	je     103cc51 <my.lanes4_fused+0x1d1>
 103cbff:	90                   	nop
 103cc00:	c5 e9 73 f1 0d       	vpsllq xmm2,xmm1,0xd
 103cc05:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cc09:	c5 e9 72 e1 07       	vpsrad xmm2,xmm1,0x7
 103cc0e:	c5 e1 73 d1 07       	vpsrlq xmm3,xmm1,0x7
 103cc13:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cc19:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cc1d:	c5 e9 73 f1 11       	vpsllq xmm2,xmm1,0x11
 103cc22:	c5 e9 ef c9          	vpxor  xmm1,xmm2,xmm1
 103cc26:	c5 e9 73 f0 0d       	vpsllq xmm2,xmm0,0xd
 103cc2b:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cc2f:	c5 e9 72 e0 07       	vpsrad xmm2,xmm0,0x7
 103cc34:	c5 e1 73 d0 07       	vpsrlq xmm3,xmm0,0x7
 103cc39:	c4 e3 61 02 d2 0a    	vpblendd xmm2,xmm3,xmm2,0xa
 103cc3f:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cc43:	c5 e9 73 f0 11       	vpsllq xmm2,xmm0,0x11
 103cc48:	c5 e9 ef c0          	vpxor  xmm0,xmm2,xmm0
 103cc4c:	48 ff c8             	dec    rax
 103cc4f:	75 af                	jne    103cc00 <my.lanes4_fused+0x180>
 103cc51:	c5 f9 70 d1 ee       	vpshufd xmm2,xmm1,0xee
 103cc56:	c5 f1 ef ca          	vpxor  xmm1,xmm1,xmm2
 103cc5a:	c4 e1 f9 7e c8       	vmovq  rax,xmm1
 103cc5f:	eb 05                	jmp    103cc66 <my.lanes4_fused+0x1e6>
 103cc61:	b8 01 00 00 00       	mov    eax,0x1
 103cc66:	c4 e1 f9 7e c1       	vmovq  rcx,xmm0
 103cc6b:	48 31 c1             	xor    rcx,rax
 103cc6e:	c4 e3 f9 16 c0 01    	vpextrq rax,xmm0,0x1
 103cc74:	48 31 c8             	xor    rax,rcx
 103cc77:	c3                   	ret

Disassembly of section .plt:
