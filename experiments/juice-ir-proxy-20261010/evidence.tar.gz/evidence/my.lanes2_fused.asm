
.tmp/juice-ir/kernels:     file format elf64-x86-64


Disassembly of section .text:

000000000103c370 <my.lanes2_fused>:
 103c370:	48 85 ff             	test   rdi,rdi
 103c373:	0f 84 41 01 00 00    	je     103c4ba <my.lanes2_fused+0x14a>
 103c379:	c4 e1 f9 6e c6       	vmovq  xmm0,rsi
 103c37e:	c4 e2 79 59 c0       	vpbroadcastq xmm0,xmm0
 103c383:	c5 f9 ef 05 65 7e fc 	vpxor  xmm0,xmm0,XMMWORD PTR [rip+0xfffffffffffc7e65]        # 10041f0 <core_run_timed_out.message+0x120>
 103c38a:	ff 
 103c38b:	89 f8                	mov    eax,edi
 103c38d:	83 e0 03             	and    eax,0x3
 103c390:	48 83 ff 04          	cmp    rdi,0x4
 103c394:	0f 82 e6 00 00 00    	jb     103c480 <my.lanes2_fused+0x110>
 103c39a:	48 b9 fc ff ff ff ff 	movabs rcx,0x7ffffffffffffffc
 103c3a1:	ff ff 7f 
 103c3a4:	48 21 cf             	and    rdi,rcx
 103c3a7:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103c3ae:	0f 1f 84 00 00 00 00 
 103c3b5:	00 
 103c3b6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
 103c3bd:	00 00 00 
 103c3c0:	c5 f1 73 f0 0d       	vpsllq xmm1,xmm0,0xd
 103c3c5:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c3c9:	c5 f1 72 e0 07       	vpsrad xmm1,xmm0,0x7
 103c3ce:	c5 e9 73 d0 07       	vpsrlq xmm2,xmm0,0x7
 103c3d3:	c4 e3 69 02 c9 0a    	vpblendd xmm1,xmm2,xmm1,0xa
 103c3d9:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c3dd:	c5 f1 73 f0 11       	vpsllq xmm1,xmm0,0x11
 103c3e2:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c3e6:	c5 f1 73 f0 0d       	vpsllq xmm1,xmm0,0xd
 103c3eb:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c3ef:	c5 f1 72 e0 07       	vpsrad xmm1,xmm0,0x7
 103c3f4:	c5 e9 73 d0 07       	vpsrlq xmm2,xmm0,0x7
 103c3f9:	c4 e3 69 02 c9 0a    	vpblendd xmm1,xmm2,xmm1,0xa
 103c3ff:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c403:	c5 f1 73 f0 11       	vpsllq xmm1,xmm0,0x11
 103c408:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c40c:	c5 f1 73 f0 0d       	vpsllq xmm1,xmm0,0xd
 103c411:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c415:	c5 f1 72 e0 07       	vpsrad xmm1,xmm0,0x7
 103c41a:	c5 e9 73 d0 07       	vpsrlq xmm2,xmm0,0x7
 103c41f:	c4 e3 69 02 c9 0a    	vpblendd xmm1,xmm2,xmm1,0xa
 103c425:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c429:	c5 f1 73 f0 11       	vpsllq xmm1,xmm0,0x11
 103c42e:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c432:	c5 f1 73 f0 0d       	vpsllq xmm1,xmm0,0xd
 103c437:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c43b:	c5 f1 72 e0 07       	vpsrad xmm1,xmm0,0x7
 103c440:	c5 e9 73 d0 07       	vpsrlq xmm2,xmm0,0x7
 103c445:	c4 e3 69 02 c9 0a    	vpblendd xmm1,xmm2,xmm1,0xa
 103c44b:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c44f:	c5 f1 73 f0 11       	vpsllq xmm1,xmm0,0x11
 103c454:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c458:	48 83 c7 fc          	add    rdi,0xfffffffffffffffc
 103c45c:	0f 85 5e ff ff ff    	jne    103c3c0 <my.lanes2_fused+0x50>
 103c462:	48 85 c0             	test   rax,rax
 103c465:	74 44                	je     103c4ab <my.lanes2_fused+0x13b>
 103c467:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103c46e:	0f 1f 84 00 00 00 00 
 103c475:	00 
 103c476:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
 103c47d:	00 00 00 
 103c480:	c5 f1 73 f0 0d       	vpsllq xmm1,xmm0,0xd
 103c485:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c489:	c5 f1 72 e0 07       	vpsrad xmm1,xmm0,0x7
 103c48e:	c5 e9 73 d0 07       	vpsrlq xmm2,xmm0,0x7
 103c493:	c4 e3 69 02 c9 0a    	vpblendd xmm1,xmm2,xmm1,0xa
 103c499:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c49d:	c5 f1 73 f0 11       	vpsllq xmm1,xmm0,0x11
 103c4a2:	c5 f1 ef c0          	vpxor  xmm0,xmm1,xmm0
 103c4a6:	48 ff c8             	dec    rax
 103c4a9:	75 d5                	jne    103c480 <my.lanes2_fused+0x110>
 103c4ab:	c5 f9 70 c8 ee       	vpshufd xmm1,xmm0,0xee
 103c4b0:	c5 f9 ef c1          	vpxor  xmm0,xmm0,xmm1
 103c4b4:	c4 e1 f9 7e c0       	vmovq  rax,xmm0
 103c4b9:	c3                   	ret
 103c4ba:	b8 01 00 00 00       	mov    eax,0x1
 103c4bf:	c3                   	ret

Disassembly of section .plt:
