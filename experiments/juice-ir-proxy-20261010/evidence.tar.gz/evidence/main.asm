
.tmp/juice-ir/kernels:     file format elf64-x86-64


Disassembly of section .text:

000000000103cc80 <main>:
 103cc80:	55                   	push   rbp
 103cc81:	41 57                	push   r15
 103cc83:	41 56                	push   r14
 103cc85:	41 55                	push   r13
 103cc87:	41 54                	push   r12
 103cc89:	53                   	push   rbx
 103cc8a:	50                   	push   rax
 103cc8b:	48 89 f3             	mov    rbx,rsi
 103cc8e:	89 fd                	mov    ebp,edi
 103cc90:	e8 eb 37 ff ff       	call   1030480 <myl_core_start>
 103cc95:	89 ef                	mov    edi,ebp
 103cc97:	48 89 de             	mov    rsi,rbx
 103cc9a:	e8 a1 f5 fc ff       	call   100c240 <myl_core_args>
 103cc9f:	48 89 c3             	mov    rbx,rax
 103cca2:	e8 19 9a fe ff       	call   10266c0 <myl_core_host_grant>
 103cca7:	bd 02 00 00 00       	mov    ebp,0x2
 103ccac:	48 83 7b 08 03       	cmp    QWORD PTR [rbx+0x8],0x3
 103ccb1:	0f 85 b3 08 00 00    	jne    103d56a <main+0x8ea>
 103ccb7:	49 89 c6             	mov    r14,rax
 103ccba:	48 8b 7b 20          	mov    rdi,QWORD PTR [rbx+0x20]
 103ccbe:	e8 0d f0 ff ff       	call   103bcd0 <my.parse_number>
 103ccc3:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
 103ccc7:	48 83 fa 01          	cmp    rdx,0x1
 103cccb:	0f 86 b7 08 00 00    	jbe    103d588 <main+0x908>
 103ccd1:	49 89 c7             	mov    r15,rax
 103ccd4:	48 8b 7b 28          	mov    rdi,QWORD PTR [rbx+0x28]
 103ccd8:	e8 f3 ef ff ff       	call   103bcd0 <my.parse_number>
 103ccdd:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
 103cce1:	48 83 fa 02          	cmp    rdx,0x2
 103cce5:	0f 86 ae 08 00 00    	jbe    103d599 <main+0x919>
 103cceb:	49 89 c4             	mov    r12,rax
 103ccee:	48 8b 7b 30          	mov    rdi,QWORD PTR [rbx+0x30]
 103ccf2:	e8 d9 ef ff ff       	call   103bcd0 <my.parse_number>
 103ccf7:	49 89 c5             	mov    r13,rax
 103ccfa:	4c 89 e0             	mov    rax,r12
 103ccfd:	4c 09 e8             	or     rax,r13
 103cd00:	0f 88 64 08 00 00    	js     103d56a <main+0x8ea>
 103cd06:	48 8d 3d 13 21 00 00 	lea    rdi,[rip+0x2113]        # 103ee20 <core_io_file_error.verbs+0xb0>
 103cd0d:	e8 ae 03 fd ff       	call   100d0c0 <myl_core_io_at>
 103cd12:	4c 89 f7             	mov    rdi,r14
 103cd15:	e8 66 9a fe ff       	call   1026780 <myl_core_host_check>
 103cd1a:	e8 a1 08 00 00       	call   103d5c0 <runtime_bench_now>
 103cd1f:	49 83 ff 0c          	cmp    r15,0xc
 103cd23:	0f 87 41 08 00 00    	ja     103d56a <main+0x8ea>
 103cd29:	48 8d 15 90 8b fc ff 	lea    rdx,[rip+0xfffffffffffc8b90]        # 10058c0 <core_number_pairs+0xe0>
 103cd30:	4a 63 0c ba          	movsxd rcx,DWORD PTR [rdx+r15*4]
 103cd34:	48 01 d1             	add    rcx,rdx
 103cd37:	ff e1                	jmp    rcx
 103cd39:	4d 85 e4             	test   r12,r12
 103cd3c:	0f 84 30 06 00 00    	je     103d372 <main+0x6f2>
 103cd42:	44 89 e6             	mov    esi,r12d
 103cd45:	83 e6 07             	and    esi,0x7
 103cd48:	49 89 c7             	mov    r15,rax
 103cd4b:	49 83 fc 08          	cmp    r12,0x8
 103cd4f:	0f 82 eb 00 00 00    	jb     103ce40 <main+0x1c0>
 103cd55:	48 b9 f8 ff ff ff ff 	movabs rcx,0x7ffffffffffffff8
 103cd5c:	ff ff 7f 
 103cd5f:	49 21 cc             	and    r12,rcx
 103cd62:	4c 89 e9             	mov    rcx,r13
 103cd65:	48 c1 e1 0d          	shl    rcx,0xd
 103cd69:	4c 31 e9             	xor    rcx,r13
 103cd6c:	48 89 ca             	mov    rdx,rcx
 103cd6f:	48 c1 fa 07          	sar    rdx,0x7
 103cd73:	48 31 ca             	xor    rdx,rcx
 103cd76:	48 89 d1             	mov    rcx,rdx
 103cd79:	48 c1 e1 0d          	shl    rcx,0xd
 103cd7d:	48 31 d1             	xor    rcx,rdx
 103cd80:	48 89 ca             	mov    rdx,rcx
 103cd83:	48 c1 fa 07          	sar    rdx,0x7
 103cd87:	48 31 ca             	xor    rdx,rcx
 103cd8a:	48 89 d1             	mov    rcx,rdx
 103cd8d:	48 c1 e1 0d          	shl    rcx,0xd
 103cd91:	48 31 d1             	xor    rcx,rdx
 103cd94:	48 89 ca             	mov    rdx,rcx
 103cd97:	48 c1 fa 07          	sar    rdx,0x7
 103cd9b:	48 31 ca             	xor    rdx,rcx
 103cd9e:	48 89 d1             	mov    rcx,rdx
 103cda1:	48 c1 e1 0d          	shl    rcx,0xd
 103cda5:	48 31 d1             	xor    rcx,rdx
 103cda8:	48 89 ca             	mov    rdx,rcx
 103cdab:	48 c1 fa 07          	sar    rdx,0x7
 103cdaf:	48 31 ca             	xor    rdx,rcx
 103cdb2:	48 89 d1             	mov    rcx,rdx
 103cdb5:	48 c1 e1 0d          	shl    rcx,0xd
 103cdb9:	48 31 d1             	xor    rcx,rdx
 103cdbc:	48 89 ca             	mov    rdx,rcx
 103cdbf:	48 c1 fa 07          	sar    rdx,0x7
 103cdc3:	48 31 ca             	xor    rdx,rcx
 103cdc6:	48 89 d1             	mov    rcx,rdx
 103cdc9:	48 c1 e1 0d          	shl    rcx,0xd
 103cdcd:	48 31 d1             	xor    rcx,rdx
 103cdd0:	48 89 ca             	mov    rdx,rcx
 103cdd3:	48 c1 fa 07          	sar    rdx,0x7
 103cdd7:	48 31 ca             	xor    rdx,rcx
 103cdda:	48 89 d1             	mov    rcx,rdx
 103cddd:	48 c1 e1 0d          	shl    rcx,0xd
 103cde1:	48 31 d1             	xor    rcx,rdx
 103cde4:	48 89 ca             	mov    rdx,rcx
 103cde7:	48 c1 fa 07          	sar    rdx,0x7
 103cdeb:	48 31 ca             	xor    rdx,rcx
 103cdee:	48 89 d1             	mov    rcx,rdx
 103cdf1:	48 c1 e1 0d          	shl    rcx,0xd
 103cdf5:	48 31 d1             	xor    rcx,rdx
 103cdf8:	49 89 cd             	mov    r13,rcx
 103cdfb:	49 c1 fd 07          	sar    r13,0x7
 103cdff:	49 31 cd             	xor    r13,rcx
 103ce02:	49 83 c4 f8          	add    r12,0xfffffffffffffff8
 103ce06:	0f 85 56 ff ff ff    	jne    103cd62 <main+0xe2>
 103ce0c:	48 85 f6             	test   rsi,rsi
 103ce0f:	0f 84 04 07 00 00    	je     103d519 <main+0x899>
 103ce15:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103ce1c:	0f 1f 84 00 00 00 00 
 103ce23:	00 
 103ce24:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103ce2b:	0f 1f 84 00 00 00 00 
 103ce32:	00 
 103ce33:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103ce3a:	84 00 00 00 00 00 
 103ce40:	4c 89 e9             	mov    rcx,r13
 103ce43:	48 c1 e1 0d          	shl    rcx,0xd
 103ce47:	4c 31 e9             	xor    rcx,r13
 103ce4a:	49 89 cd             	mov    r13,rcx
 103ce4d:	49 c1 fd 07          	sar    r13,0x7
 103ce51:	49 31 cd             	xor    r13,rcx
 103ce54:	48 ff ce             	dec    rsi
 103ce57:	75 e7                	jne    103ce40 <main+0x1c0>
 103ce59:	e9 bb 06 00 00       	jmp    103d519 <main+0x899>
 103ce5e:	49 89 c7             	mov    r15,rax
 103ce61:	4d 85 e4             	test   r12,r12
 103ce64:	0f 84 af 06 00 00    	je     103d519 <main+0x899>
 103ce6a:	4d 85 ed             	test   r13,r13
 103ce6d:	0f 84 a6 06 00 00    	je     103d519 <main+0x899>
 103ce73:	b8 01 00 00 00       	mov    eax,0x1
 103ce78:	4c 89 e9             	mov    rcx,r13
 103ce7b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
 103ce80:	48 89 ca             	mov    rdx,rcx
 103ce83:	48 c1 e2 0d          	shl    rdx,0xd
 103ce87:	49 89 d5             	mov    r13,rdx
 103ce8a:	49 31 cd             	xor    r13,rcx
 103ce8d:	4c 39 e0             	cmp    rax,r12
 103ce90:	0f 83 83 06 00 00    	jae    103d519 <main+0x899>
 103ce96:	48 ff c0             	inc    rax
 103ce99:	48 39 ca             	cmp    rdx,rcx
 103ce9c:	4c 89 e9             	mov    rcx,r13
 103ce9f:	75 df                	jne    103ce80 <main+0x200>
 103cea1:	e9 73 06 00 00       	jmp    103d519 <main+0x899>
 103cea6:	4d 85 e4             	test   r12,r12
 103cea9:	0f 84 c3 04 00 00    	je     103d372 <main+0x6f2>
 103ceaf:	49 8d 4c 24 ff       	lea    rcx,[r12-0x1]
 103ceb4:	44 89 e6             	mov    esi,r12d
 103ceb7:	83 e6 07             	and    esi,0x7
 103ceba:	49 89 c7             	mov    r15,rax
 103cebd:	48 83 f9 07          	cmp    rcx,0x7
 103cec1:	0f 82 39 01 00 00    	jb     103d000 <main+0x380>
 103cec7:	48 b9 f8 ff ff ff ff 	movabs rcx,0x7ffffffffffffff8
 103cece:	ff ff 7f 
 103ced1:	49 21 cc             	and    r12,rcx
 103ced4:	4c 89 e9             	mov    rcx,r13
 103ced7:	48 c1 e1 0d          	shl    rcx,0xd
 103cedb:	4c 31 e9             	xor    rcx,r13
 103cede:	48 89 ca             	mov    rdx,rcx
 103cee1:	48 c1 fa 07          	sar    rdx,0x7
 103cee5:	48 31 ca             	xor    rdx,rcx
 103cee8:	48 89 d1             	mov    rcx,rdx
 103ceeb:	48 c1 e1 11          	shl    rcx,0x11
 103ceef:	48 31 d1             	xor    rcx,rdx
 103cef2:	48 89 ca             	mov    rdx,rcx
 103cef5:	48 c1 e2 0d          	shl    rdx,0xd
 103cef9:	48 31 ca             	xor    rdx,rcx
 103cefc:	48 89 d1             	mov    rcx,rdx
 103ceff:	48 c1 f9 07          	sar    rcx,0x7
 103cf03:	48 31 d1             	xor    rcx,rdx
 103cf06:	48 89 ca             	mov    rdx,rcx
 103cf09:	48 c1 e2 11          	shl    rdx,0x11
 103cf0d:	48 31 ca             	xor    rdx,rcx
 103cf10:	48 89 d1             	mov    rcx,rdx
 103cf13:	48 c1 e1 0d          	shl    rcx,0xd
 103cf17:	48 31 d1             	xor    rcx,rdx
 103cf1a:	48 89 ca             	mov    rdx,rcx
 103cf1d:	48 c1 fa 07          	sar    rdx,0x7
 103cf21:	48 31 ca             	xor    rdx,rcx
 103cf24:	48 89 d1             	mov    rcx,rdx
 103cf27:	48 c1 e1 11          	shl    rcx,0x11
 103cf2b:	48 31 d1             	xor    rcx,rdx
 103cf2e:	48 89 ca             	mov    rdx,rcx
 103cf31:	48 c1 e2 0d          	shl    rdx,0xd
 103cf35:	48 31 ca             	xor    rdx,rcx
 103cf38:	48 89 d1             	mov    rcx,rdx
 103cf3b:	48 c1 f9 07          	sar    rcx,0x7
 103cf3f:	48 31 d1             	xor    rcx,rdx
 103cf42:	48 89 ca             	mov    rdx,rcx
 103cf45:	48 c1 e2 11          	shl    rdx,0x11
 103cf49:	48 31 ca             	xor    rdx,rcx
 103cf4c:	48 89 d1             	mov    rcx,rdx
 103cf4f:	48 c1 e1 0d          	shl    rcx,0xd
 103cf53:	48 31 d1             	xor    rcx,rdx
 103cf56:	48 89 ca             	mov    rdx,rcx
 103cf59:	48 c1 fa 07          	sar    rdx,0x7
 103cf5d:	48 31 ca             	xor    rdx,rcx
 103cf60:	48 89 d1             	mov    rcx,rdx
 103cf63:	48 c1 e1 11          	shl    rcx,0x11
 103cf67:	48 31 d1             	xor    rcx,rdx
 103cf6a:	48 89 ca             	mov    rdx,rcx
 103cf6d:	48 c1 e2 0d          	shl    rdx,0xd
 103cf71:	48 31 ca             	xor    rdx,rcx
 103cf74:	48 89 d1             	mov    rcx,rdx
 103cf77:	48 c1 f9 07          	sar    rcx,0x7
 103cf7b:	48 31 d1             	xor    rcx,rdx
 103cf7e:	48 89 ca             	mov    rdx,rcx
 103cf81:	48 c1 e2 11          	shl    rdx,0x11
 103cf85:	48 31 ca             	xor    rdx,rcx
 103cf88:	48 89 d1             	mov    rcx,rdx
 103cf8b:	48 c1 e1 0d          	shl    rcx,0xd
 103cf8f:	48 31 d1             	xor    rcx,rdx
 103cf92:	48 89 ca             	mov    rdx,rcx
 103cf95:	48 c1 fa 07          	sar    rdx,0x7
 103cf99:	48 31 ca             	xor    rdx,rcx
 103cf9c:	48 89 d1             	mov    rcx,rdx
 103cf9f:	48 c1 e1 11          	shl    rcx,0x11
 103cfa3:	48 31 d1             	xor    rcx,rdx
 103cfa6:	48 89 ca             	mov    rdx,rcx
 103cfa9:	48 c1 e2 0d          	shl    rdx,0xd
 103cfad:	48 31 ca             	xor    rdx,rcx
 103cfb0:	48 89 d1             	mov    rcx,rdx
 103cfb3:	48 c1 f9 07          	sar    rcx,0x7
 103cfb7:	48 31 d1             	xor    rcx,rdx
 103cfba:	49 89 cd             	mov    r13,rcx
 103cfbd:	49 c1 e5 11          	shl    r13,0x11
 103cfc1:	49 31 cd             	xor    r13,rcx
 103cfc4:	49 83 c4 f8          	add    r12,0xfffffffffffffff8
 103cfc8:	0f 85 06 ff ff ff    	jne    103ced4 <main+0x254>
 103cfce:	48 85 f6             	test   rsi,rsi
 103cfd1:	0f 84 42 05 00 00    	je     103d519 <main+0x899>
 103cfd7:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103cfde:	0f 1f 84 00 00 00 00 
 103cfe5:	00 
 103cfe6:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103cfed:	0f 1f 84 00 00 00 00 
 103cff4:	00 
 103cff5:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
 103cffc:	00 00 00 00 
 103d000:	4c 89 e9             	mov    rcx,r13
 103d003:	48 c1 e1 0d          	shl    rcx,0xd
 103d007:	4c 31 e9             	xor    rcx,r13
 103d00a:	48 89 ca             	mov    rdx,rcx
 103d00d:	48 c1 fa 07          	sar    rdx,0x7
 103d011:	48 31 ca             	xor    rdx,rcx
 103d014:	49 89 d5             	mov    r13,rdx
 103d017:	49 c1 e5 11          	shl    r13,0x11
 103d01b:	49 31 d5             	xor    r13,rdx
 103d01e:	48 ff ce             	dec    rsi
 103d021:	75 dd                	jne    103d000 <main+0x380>
 103d023:	e9 f1 04 00 00       	jmp    103d519 <main+0x899>
 103d028:	49 89 c7             	mov    r15,rax
 103d02b:	4d 85 e4             	test   r12,r12
 103d02e:	0f 84 e5 04 00 00    	je     103d519 <main+0x899>
 103d034:	31 c0                	xor    eax,eax
 103d036:	eb 14                	jmp    103d04c <main+0x3cc>
 103d038:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
 103d03f:	00 
 103d040:	48 ff c0             	inc    rax
 103d043:	4c 39 e0             	cmp    rax,r12
 103d046:	0f 84 cd 04 00 00    	je     103d519 <main+0x899>
 103d04c:	48 85 c0             	test   rax,rax
 103d04f:	74 ef                	je     103d040 <main+0x3c0>
 103d051:	48 83 f8 08          	cmp    rax,0x8
 103d055:	72 5b                	jb     103d0b2 <main+0x432>
 103d057:	48 89 c1             	mov    rcx,rax
 103d05a:	48 83 e1 f8          	and    rcx,0xfffffffffffffff8
 103d05e:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d065:	0f 1f 84 00 00 00 00 
 103d06c:	00 
 103d06d:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d074:	0f 1f 84 00 00 00 00 
 103d07b:	00 
 103d07c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
 103d080:	4c 89 ea             	mov    rdx,r13
 103d083:	48 c1 e2 34          	shl    rdx,0x34
 103d087:	4c 89 ee             	mov    rsi,r13
 103d08a:	48 c1 e6 0d          	shl    rsi,0xd
 103d08e:	48 31 d6             	xor    rsi,rdx
 103d091:	4c 31 ee             	xor    rsi,r13
 103d094:	48 89 f2             	mov    rdx,rsi
 103d097:	48 c1 e2 1a          	shl    rdx,0x1a
 103d09b:	48 31 f2             	xor    rdx,rsi
 103d09e:	49 89 d5             	mov    r13,rdx
 103d0a1:	49 c1 e5 0d          	shl    r13,0xd
 103d0a5:	49 31 d5             	xor    r13,rdx
 103d0a8:	48 83 c1 f8          	add    rcx,0xfffffffffffffff8
 103d0ac:	75 d2                	jne    103d080 <main+0x400>
 103d0ae:	a8 07                	test   al,0x7
 103d0b0:	74 8e                	je     103d040 <main+0x3c0>
 103d0b2:	89 c1                	mov    ecx,eax
 103d0b4:	83 e1 07             	and    ecx,0x7
 103d0b7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
 103d0be:	00 00 
 103d0c0:	4c 89 ea             	mov    rdx,r13
 103d0c3:	48 c1 e2 0d          	shl    rdx,0xd
 103d0c7:	49 31 d5             	xor    r13,rdx
 103d0ca:	48 ff c9             	dec    rcx
 103d0cd:	75 f1                	jne    103d0c0 <main+0x440>
 103d0cf:	e9 6c ff ff ff       	jmp    103d040 <main+0x3c0>
 103d0d4:	49 89 c7             	mov    r15,rax
 103d0d7:	4c 89 e7             	mov    rdi,r12
 103d0da:	4c 89 ee             	mov    rsi,r13
 103d0dd:	e8 9e f9 ff ff       	call   103ca80 <my.lanes4_fused>
 103d0e2:	49 89 c5             	mov    r13,rax
 103d0e5:	e9 2f 04 00 00       	jmp    103d519 <main+0x899>
 103d0ea:	4d 85 e4             	test   r12,r12
 103d0ed:	0f 84 7f 02 00 00    	je     103d372 <main+0x6f2>
 103d0f3:	49 8d 4c 24 ff       	lea    rcx,[r12-0x1]
 103d0f8:	44 89 e6             	mov    esi,r12d
 103d0fb:	83 e6 07             	and    esi,0x7
 103d0fe:	49 89 c7             	mov    r15,rax
 103d101:	48 83 f9 07          	cmp    rcx,0x7
 103d105:	72 79                	jb     103d180 <main+0x500>
 103d107:	48 b9 f8 ff ff ff ff 	movabs rcx,0x7ffffffffffffff8
 103d10e:	ff ff 7f 
 103d111:	49 21 cc             	and    r12,rcx
 103d114:	4c 89 e9             	mov    rcx,r13
 103d117:	48 c1 e1 34          	shl    rcx,0x34
 103d11b:	4c 89 ea             	mov    rdx,r13
 103d11e:	48 c1 e2 0d          	shl    rdx,0xd
 103d122:	48 31 ca             	xor    rdx,rcx
 103d125:	4c 31 ea             	xor    rdx,r13
 103d128:	48 89 d1             	mov    rcx,rdx
 103d12b:	48 c1 e1 1a          	shl    rcx,0x1a
 103d12f:	48 31 d1             	xor    rcx,rdx
 103d132:	49 89 cd             	mov    r13,rcx
 103d135:	49 c1 e5 0d          	shl    r13,0xd
 103d139:	49 31 cd             	xor    r13,rcx
 103d13c:	49 83 c4 f8          	add    r12,0xfffffffffffffff8
 103d140:	75 d2                	jne    103d114 <main+0x494>
 103d142:	48 85 f6             	test   rsi,rsi
 103d145:	0f 84 ce 03 00 00    	je     103d519 <main+0x899>
 103d14b:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d152:	0f 1f 84 00 00 00 00 
 103d159:	00 
 103d15a:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d161:	0f 1f 84 00 00 00 00 
 103d168:	00 
 103d169:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d170:	0f 1f 84 00 00 00 00 
 103d177:	00 
 103d178:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
 103d17f:	00 
 103d180:	4c 89 e9             	mov    rcx,r13
 103d183:	48 c1 e1 0d          	shl    rcx,0xd
 103d187:	49 31 cd             	xor    r13,rcx
 103d18a:	48 ff ce             	dec    rsi
 103d18d:	75 f1                	jne    103d180 <main+0x500>
 103d18f:	e9 85 03 00 00       	jmp    103d519 <main+0x899>
 103d194:	4d 85 e4             	test   r12,r12
 103d197:	0f 84 d5 01 00 00    	je     103d372 <main+0x6f2>
 103d19d:	49 8d 4c 24 ff       	lea    rcx,[r12-0x1]
 103d1a2:	44 89 e6             	mov    esi,r12d
 103d1a5:	83 e6 07             	and    esi,0x7
 103d1a8:	49 89 c7             	mov    r15,rax
 103d1ab:	48 83 f9 07          	cmp    rcx,0x7
 103d1af:	72 4f                	jb     103d200 <main+0x580>
 103d1b1:	48 b9 f8 ff ff ff ff 	movabs rcx,0x7ffffffffffffff8
 103d1b8:	ff ff 7f 
 103d1bb:	49 21 cc             	and    r12,rcx
 103d1be:	4c 89 e9             	mov    rcx,r13
 103d1c1:	48 c1 e1 34          	shl    rcx,0x34
 103d1c5:	4c 89 ea             	mov    rdx,r13
 103d1c8:	48 c1 e2 1a          	shl    rdx,0x1a
 103d1cc:	48 31 ca             	xor    rdx,rcx
 103d1cf:	4c 31 ea             	xor    rdx,r13
 103d1d2:	49 89 d5             	mov    r13,rdx
 103d1d5:	49 c1 e5 1a          	shl    r13,0x1a
 103d1d9:	49 31 d5             	xor    r13,rdx
 103d1dc:	49 83 c4 f8          	add    r12,0xfffffffffffffff8
 103d1e0:	75 dc                	jne    103d1be <main+0x53e>
 103d1e2:	48 85 f6             	test   rsi,rsi
 103d1e5:	0f 84 2e 03 00 00    	je     103d519 <main+0x899>
 103d1eb:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d1f2:	0f 1f 84 00 00 00 00 
 103d1f9:	00 
 103d1fa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
 103d200:	4c 89 e9             	mov    rcx,r13
 103d203:	48 c1 e1 1a          	shl    rcx,0x1a
 103d207:	49 31 cd             	xor    r13,rcx
 103d20a:	48 ff ce             	dec    rsi
 103d20d:	75 f1                	jne    103d200 <main+0x580>
 103d20f:	e9 05 03 00 00       	jmp    103d519 <main+0x899>
 103d214:	49 89 c7             	mov    r15,rax
 103d217:	4c 89 e7             	mov    rdi,r12
 103d21a:	4c 89 ee             	mov    rsi,r13
 103d21d:	e8 4e f1 ff ff       	call   103c370 <my.lanes2_fused>
 103d222:	49 89 c5             	mov    r13,rax
 103d225:	e9 ef 02 00 00       	jmp    103d519 <main+0x899>
 103d22a:	4d 85 e4             	test   r12,r12
 103d22d:	0f 84 3f 01 00 00    	je     103d372 <main+0x6f2>
 103d233:	44 89 e6             	mov    esi,r12d
 103d236:	83 e6 03             	and    esi,0x3
 103d239:	49 89 c7             	mov    r15,rax
 103d23c:	49 83 fc 04          	cmp    r12,0x4
 103d240:	0f 82 fa 00 00 00    	jb     103d340 <main+0x6c0>
 103d246:	48 b9 f8 ff ff ff ff 	movabs rcx,0x7ffffffffffffff8
 103d24d:	ff ff 7f 
 103d250:	48 83 c9 04          	or     rcx,0x4
 103d254:	49 21 cc             	and    r12,rcx
 103d257:	4c 89 e9             	mov    rcx,r13
 103d25a:	48 c1 e1 0d          	shl    rcx,0xd
 103d25e:	4c 31 e9             	xor    rcx,r13
 103d261:	48 89 ca             	mov    rdx,rcx
 103d264:	48 c1 fa 07          	sar    rdx,0x7
 103d268:	48 31 ca             	xor    rdx,rcx
 103d26b:	48 89 d1             	mov    rcx,rdx
 103d26e:	48 c1 e1 11          	shl    rcx,0x11
 103d272:	48 31 d1             	xor    rcx,rdx
 103d275:	48 89 ca             	mov    rdx,rcx
 103d278:	48 c1 fa 0b          	sar    rdx,0xb
 103d27c:	48 31 ca             	xor    rdx,rcx
 103d27f:	48 89 d1             	mov    rcx,rdx
 103d282:	48 c1 e1 0d          	shl    rcx,0xd
 103d286:	48 31 d1             	xor    rcx,rdx
 103d289:	48 89 ca             	mov    rdx,rcx
 103d28c:	48 c1 fa 07          	sar    rdx,0x7
 103d290:	48 31 ca             	xor    rdx,rcx
 103d293:	48 89 d1             	mov    rcx,rdx
 103d296:	48 c1 e1 11          	shl    rcx,0x11
 103d29a:	48 31 d1             	xor    rcx,rdx
 103d29d:	48 89 ca             	mov    rdx,rcx
 103d2a0:	48 c1 fa 0b          	sar    rdx,0xb
 103d2a4:	48 31 ca             	xor    rdx,rcx
 103d2a7:	48 89 d1             	mov    rcx,rdx
 103d2aa:	48 c1 e1 0d          	shl    rcx,0xd
 103d2ae:	48 31 d1             	xor    rcx,rdx
 103d2b1:	48 89 ca             	mov    rdx,rcx
 103d2b4:	48 c1 fa 07          	sar    rdx,0x7
 103d2b8:	48 31 ca             	xor    rdx,rcx
 103d2bb:	48 89 d1             	mov    rcx,rdx
 103d2be:	48 c1 e1 11          	shl    rcx,0x11
 103d2c2:	48 31 d1             	xor    rcx,rdx
 103d2c5:	48 89 ca             	mov    rdx,rcx
 103d2c8:	48 c1 fa 0b          	sar    rdx,0xb
 103d2cc:	48 31 ca             	xor    rdx,rcx
 103d2cf:	48 89 d1             	mov    rcx,rdx
 103d2d2:	48 c1 e1 0d          	shl    rcx,0xd
 103d2d6:	48 31 d1             	xor    rcx,rdx
 103d2d9:	48 89 ca             	mov    rdx,rcx
 103d2dc:	48 c1 fa 07          	sar    rdx,0x7
 103d2e0:	48 31 ca             	xor    rdx,rcx
 103d2e3:	48 89 d1             	mov    rcx,rdx
 103d2e6:	48 c1 e1 11          	shl    rcx,0x11
 103d2ea:	48 31 d1             	xor    rcx,rdx
 103d2ed:	49 89 cd             	mov    r13,rcx
 103d2f0:	49 c1 fd 0b          	sar    r13,0xb
 103d2f4:	49 31 cd             	xor    r13,rcx
 103d2f7:	49 83 c4 fc          	add    r12,0xfffffffffffffffc
 103d2fb:	0f 85 56 ff ff ff    	jne    103d257 <main+0x5d7>
 103d301:	48 85 f6             	test   rsi,rsi
 103d304:	0f 84 0f 02 00 00    	je     103d519 <main+0x899>
 103d30a:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d311:	0f 1f 84 00 00 00 00 
 103d318:	00 
 103d319:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d320:	0f 1f 84 00 00 00 00 
 103d327:	00 
 103d328:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d32f:	0f 1f 84 00 00 00 00 
 103d336:	00 
 103d337:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
 103d33e:	00 00 
 103d340:	4c 89 e9             	mov    rcx,r13
 103d343:	48 c1 e1 0d          	shl    rcx,0xd
 103d347:	4c 31 e9             	xor    rcx,r13
 103d34a:	48 89 ca             	mov    rdx,rcx
 103d34d:	48 c1 fa 07          	sar    rdx,0x7
 103d351:	48 31 ca             	xor    rdx,rcx
 103d354:	48 89 d1             	mov    rcx,rdx
 103d357:	48 c1 e1 11          	shl    rcx,0x11
 103d35b:	48 31 d1             	xor    rcx,rdx
 103d35e:	49 89 cd             	mov    r13,rcx
 103d361:	49 c1 fd 0b          	sar    r13,0xb
 103d365:	49 31 cd             	xor    r13,rcx
 103d368:	48 ff ce             	dec    rsi
 103d36b:	75 d3                	jne    103d340 <main+0x6c0>
 103d36d:	e9 a7 01 00 00       	jmp    103d519 <main+0x899>
 103d372:	49 89 c7             	mov    r15,rax
 103d375:	e9 9f 01 00 00       	jmp    103d519 <main+0x899>
 103d37a:	49 89 c7             	mov    r15,rax
 103d37d:	4c 89 e7             	mov    rdi,r12
 103d380:	4c 89 ee             	mov    rsi,r13
 103d383:	e8 58 eb ff ff       	call   103bee0 <my.three_unroll4>
 103d388:	49 89 c5             	mov    r13,rax
 103d38b:	e9 89 01 00 00       	jmp    103d519 <main+0x899>
 103d390:	49 89 c7             	mov    r15,rax
 103d393:	4c 89 e7             	mov    rdi,r12
 103d396:	4c 89 ee             	mov    rsi,r13
 103d399:	e8 22 ed ff ff       	call   103c0c0 <my.lanes2_separate>
 103d39e:	49 89 c5             	mov    r13,rax
 103d3a1:	e9 73 01 00 00       	jmp    103d519 <main+0x899>
 103d3a6:	49 89 c7             	mov    r15,rax
 103d3a9:	4d 85 e4             	test   r12,r12
 103d3ac:	0f 84 67 01 00 00    	je     103d519 <main+0x899>
 103d3b2:	31 c0                	xor    eax,eax
 103d3b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d3bb:	00 00 00 00 00 
 103d3c0:	b9 20 00 00 00       	mov    ecx,0x20
 103d3c5:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d3cc:	0f 1f 84 00 00 00 00 
 103d3d3:	00 
 103d3d4:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d3db:	0f 1f 84 00 00 00 00 
 103d3e2:	00 
 103d3e3:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d3ea:	0f 1f 84 00 00 00 00 
 103d3f1:	00 
 103d3f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d3f9:	1f 84 00 00 00 00 00 
 103d400:	4c 89 ea             	mov    rdx,r13
 103d403:	48 c1 e2 0d          	shl    rdx,0xd
 103d407:	4c 31 ea             	xor    rdx,r13
 103d40a:	48 89 d6             	mov    rsi,rdx
 103d40d:	48 c1 fe 07          	sar    rsi,0x7
 103d411:	48 31 d6             	xor    rsi,rdx
 103d414:	48 89 f2             	mov    rdx,rsi
 103d417:	48 c1 e2 11          	shl    rdx,0x11
 103d41b:	48 31 f2             	xor    rdx,rsi
 103d41e:	48 89 d6             	mov    rsi,rdx
 103d421:	48 c1 e6 0d          	shl    rsi,0xd
 103d425:	48 31 d6             	xor    rsi,rdx
 103d428:	48 89 f2             	mov    rdx,rsi
 103d42b:	48 c1 fa 07          	sar    rdx,0x7
 103d42f:	48 31 f2             	xor    rdx,rsi
 103d432:	48 89 d6             	mov    rsi,rdx
 103d435:	48 c1 e6 11          	shl    rsi,0x11
 103d439:	48 31 d6             	xor    rsi,rdx
 103d43c:	48 89 f2             	mov    rdx,rsi
 103d43f:	48 c1 e2 0d          	shl    rdx,0xd
 103d443:	48 31 f2             	xor    rdx,rsi
 103d446:	48 89 d6             	mov    rsi,rdx
 103d449:	48 c1 fe 07          	sar    rsi,0x7
 103d44d:	48 31 d6             	xor    rsi,rdx
 103d450:	48 89 f2             	mov    rdx,rsi
 103d453:	48 c1 e2 11          	shl    rdx,0x11
 103d457:	48 31 f2             	xor    rdx,rsi
 103d45a:	48 89 d6             	mov    rsi,rdx
 103d45d:	48 c1 e6 0d          	shl    rsi,0xd
 103d461:	48 31 d6             	xor    rsi,rdx
 103d464:	48 89 f2             	mov    rdx,rsi
 103d467:	48 c1 fa 07          	sar    rdx,0x7
 103d46b:	48 31 f2             	xor    rdx,rsi
 103d46e:	48 89 d6             	mov    rsi,rdx
 103d471:	48 c1 e6 11          	shl    rsi,0x11
 103d475:	48 31 d6             	xor    rsi,rdx
 103d478:	48 89 f2             	mov    rdx,rsi
 103d47b:	48 c1 e2 0d          	shl    rdx,0xd
 103d47f:	48 31 f2             	xor    rdx,rsi
 103d482:	48 89 d6             	mov    rsi,rdx
 103d485:	48 c1 fe 07          	sar    rsi,0x7
 103d489:	48 31 d6             	xor    rsi,rdx
 103d48c:	48 89 f2             	mov    rdx,rsi
 103d48f:	48 c1 e2 11          	shl    rdx,0x11
 103d493:	48 31 f2             	xor    rdx,rsi
 103d496:	48 89 d6             	mov    rsi,rdx
 103d499:	48 c1 e6 0d          	shl    rsi,0xd
 103d49d:	48 31 d6             	xor    rsi,rdx
 103d4a0:	48 89 f2             	mov    rdx,rsi
 103d4a3:	48 c1 fa 07          	sar    rdx,0x7
 103d4a7:	48 31 f2             	xor    rdx,rsi
 103d4aa:	48 89 d6             	mov    rsi,rdx
 103d4ad:	48 c1 e6 11          	shl    rsi,0x11
 103d4b1:	48 31 d6             	xor    rsi,rdx
 103d4b4:	48 89 f2             	mov    rdx,rsi
 103d4b7:	48 c1 e2 0d          	shl    rdx,0xd
 103d4bb:	48 31 f2             	xor    rdx,rsi
 103d4be:	48 89 d6             	mov    rsi,rdx
 103d4c1:	48 c1 fe 07          	sar    rsi,0x7
 103d4c5:	48 31 d6             	xor    rsi,rdx
 103d4c8:	48 89 f2             	mov    rdx,rsi
 103d4cb:	48 c1 e2 11          	shl    rdx,0x11
 103d4cf:	48 31 f2             	xor    rdx,rsi
 103d4d2:	48 89 d6             	mov    rsi,rdx
 103d4d5:	48 c1 e6 0d          	shl    rsi,0xd
 103d4d9:	48 31 d6             	xor    rsi,rdx
 103d4dc:	48 89 f2             	mov    rdx,rsi
 103d4df:	48 c1 fa 07          	sar    rdx,0x7
 103d4e3:	48 31 f2             	xor    rdx,rsi
 103d4e6:	49 89 d5             	mov    r13,rdx
 103d4e9:	49 c1 e5 11          	shl    r13,0x11
 103d4ed:	49 31 d5             	xor    r13,rdx
 103d4f0:	48 83 c1 f8          	add    rcx,0xfffffffffffffff8
 103d4f4:	0f 85 06 ff ff ff    	jne    103d400 <main+0x780>
 103d4fa:	48 ff c0             	inc    rax
 103d4fd:	4c 39 e0             	cmp    rax,r12
 103d500:	0f 85 ba fe ff ff    	jne    103d3c0 <main+0x740>
 103d506:	eb 11                	jmp    103d519 <main+0x899>
 103d508:	49 89 c7             	mov    r15,rax
 103d50b:	4c 89 e7             	mov    rdi,r12
 103d50e:	4c 89 ee             	mov    rsi,r13
 103d511:	e8 aa ef ff ff       	call   103c4c0 <my.lanes4_separate>
 103d516:	49 89 c5             	mov    r13,rax
 103d519:	48 8d 3d 30 19 00 00 	lea    rdi,[rip+0x1930]        # 103ee50 <core_io_file_error.verbs+0xe0>
 103d520:	e8 9b fb fc ff       	call   100d0c0 <myl_core_io_at>
 103d525:	4c 89 f7             	mov    rdi,r14
 103d528:	e8 53 92 fe ff       	call   1026780 <myl_core_host_check>
 103d52d:	e8 8e 00 00 00       	call   103d5c0 <runtime_bench_now>
 103d532:	49 89 c6             	mov    r14,rax
 103d535:	4d 29 fe             	sub    r14,r15
 103d538:	70 70                	jo     103d5aa <main+0x92a>
 103d53a:	bf 01 00 00 00       	mov    edi,0x1
 103d53f:	4c 89 ee             	mov    rsi,r13
 103d542:	e8 79 06 fd ff       	call   100dbc0 <myl_core_print_i64>
 103d547:	bf 01 00 00 00       	mov    edi,0x1
 103d54c:	e8 6f d9 fc ff       	call   100aec0 <myl_core_print_sep>
 103d551:	bf 01 00 00 00       	mov    edi,0x1
 103d556:	4c 89 f6             	mov    rsi,r14
 103d559:	e8 62 06 fd ff       	call   100dbc0 <myl_core_print_i64>
 103d55e:	bf 01 00 00 00       	mov    edi,0x1
 103d563:	e8 98 d9 fc ff       	call   100af00 <myl_core_print_end>
 103d568:	31 ed                	xor    ebp,ebp
 103d56a:	48 89 df             	mov    rdi,rbx
 103d56d:	e8 4e ec fc ff       	call   100c1c0 <myl_core_release>
 103d572:	48 89 ef             	mov    rdi,rbp
 103d575:	48 83 c4 08          	add    rsp,0x8
 103d579:	5b                   	pop    rbx
 103d57a:	41 5c                	pop    r12
 103d57c:	41 5d                	pop    r13
 103d57e:	41 5e                	pop    r14
 103d580:	41 5f                	pop    r15
 103d582:	5d                   	pop    rbp
 103d583:	e9 78 fb fc ff       	jmp    100d100 <myl_core_exit>
 103d588:	48 8d 3d 31 18 00 00 	lea    rdi,[rip+0x1831]        # 103edc0 <core_io_file_error.verbs+0x50>
 103d58f:	be 01 00 00 00       	mov    esi,0x1
 103d594:	e8 a7 f0 fc ff       	call   100c640 <myl_core_trap>
 103d599:	48 8d 3d 50 18 00 00 	lea    rdi,[rip+0x1850]        # 103edf0 <core_io_file_error.verbs+0x80>
 103d5a0:	be 02 00 00 00       	mov    esi,0x2
 103d5a5:	e8 96 f0 fc ff       	call   100c640 <myl_core_trap>
 103d5aa:	4c 89 fa             	mov    rdx,r15
 103d5ad:	48 8d 3d cc 18 00 00 	lea    rdi,[rip+0x18cc]        # 103ee80 <core_io_file_error.verbs+0x110>
 103d5b4:	48 89 c6             	mov    rsi,rax
 103d5b7:	e8 84 f0 fc ff       	call   100c640 <myl_core_trap>

Disassembly of section .plt:
