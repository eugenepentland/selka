/* Trusted host adapters behind a native executable's capability options. These
   run in the program's own process: they are an authority boundary for guest
   source, never a sandbox against a compromised host. */
#define _POSIX_C_SOURCE 200809L
#include "qbe_grants.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/* One requested directory grant, borrowed from the options for the process lifetime. */
typedef struct { const char *path; int writable; } MylangRequest;
/* Parsed authority options from `MYLANG_OPTIONS`. Without `--restrict` every capability is granted
   and the `--allow-*` flags narrow nothing; `--allow-random=SEED` still pins the
   entropy seed, because it selects a stream rather than withholding one. */
typedef struct {
    MylangScoped scoped;
    MylangRequest directories[MYLANG_SCOPED_ROOTS];
    size_t count;
    int clock, entropy, environment, restricted, host;
    const char *names;
    uint64_t state;
} MylangGrants;
/* Whether the command line granted the `Host` authority a foreign call needs.
   Set once per process by provision() before any entry grant is queried. */
static int host_authority = 0;
static MylangClockResult clock_now(void *context) {
    (void)context;
    MylangClockResult result = {MYLANG_PROVIDER_FAILED, 0};
    struct timespec now;
    if (clock_gettime(CLOCK_REALTIME, &now)) return result;
    if (now.tv_sec > (INT64_MAX - now.tv_nsec) / 1000000000) return result;
    result.status = MYLANG_PROVIDER_OK;
    result.value = (int64_t)now.tv_sec * 1000000000 + now.tv_nsec;
    return result;
}
/* A reproducible SplitMix64 stream, seeded by the grant or by the wall clock.
   This is a deterministic generator, not a cryptographic entropy source, and it
   is not the VM's stream: a seeded run reproduces only on the same backend. */
static MylangRandomResult random_u64(void *context) {
    uint64_t *state = context;
    *state += UINT64_C(0x9e3779b97f4a7c15);
    uint64_t value = *state;
    value = (value ^ (value >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
    value = (value ^ (value >> 27)) * UINT64_C(0x94d049bb133111eb);
    MylangRandomResult result = {MYLANG_PROVIDER_OK, value ^ (value >> 31)};
    return result;
}
/* An empty allowlist grants every name the process already holds. */
static int allowed(const char *names, const char *name, size_t length) {
    if (!*names) return 1;
    for (const char *cursor = names; *cursor;) {
        const char *comma = strchr(cursor, ',');
        size_t width = comma ? (size_t)(comma - cursor) : strlen(cursor);
        if (width == length && !memcmp(cursor, name, length)) return 1;
        if (!comma) break;
        cursor = comma + 1;
    }
    return 0;
}
static MylangEnvironmentResult environment_get(void *context, const uint8_t *name, size_t name_length, uint8_t *output, size_t capacity) {
    MylangEnvironmentResult result = {MYLANG_PROVIDER_OK, 0, 0};
    char frame[256];
    if (name_length >= sizeof frame) { result.status = MYLANG_PROVIDER_DENIED; return result; }
    memcpy(frame, name, name_length);
    frame[name_length] = 0;
    if (!allowed(context, frame, name_length)) { result.status = MYLANG_PROVIDER_DENIED; return result; }
    const char *value = getenv(frame);
    if (!value) return result;
    size_t width = strlen(value);
    if (width > capacity) { result.status = MYLANG_PROVIDER_NO_CAPACITY; return result; }
    memcpy(output, value, width);
    result.present = 1;
    result.length = width;
    return result;
}
/* Match a flag that may stand alone or carry a value, rejecting a repeat. */
static const char *optional(const char *argument, const char *flag, int *seen) {
    size_t width = strlen(flag);
    if (strncmp(argument, flag, width)) return NULL;
    if (!argument[width]) return *seen ? NULL : "";
    if (argument[width] != '=' || !argument[width + 1] || *seen) return NULL;
    return argument + width + 1;
}
static int directory(MylangGrants *grants, const char *path, int writable) {
    if (!*path || grants->count == MYLANG_SCOPED_ROOTS) return 0;
    for (size_t i = 0; i < grants->count; ++i) {
        if (!strcmp(grants->directories[i].path, path) && grants->directories[i].writable == writable) return 0;
    }
    grants->directories[grants->count++] = (MylangRequest){path, writable};
    return 1;
}
/* Consume one recognized authority option; zero rejects the command line. */
static int accept(MylangGrants *grants, const char *argument, int *matched) {
    *matched = 1;
    if (!strcmp(argument, "--restrict")) return !grants->restricted && (grants->restricted = 1);
    if (!strncmp(argument, "--allow-read=", 13)) return directory(grants, argument + 13, 0);
    if (!strncmp(argument, "--allow-write=", 14)) return directory(grants, argument + 14, 1);
    if (!strncmp(argument, "--allow-endpoint=", 17)) return mylang_scoped_endpoint(&grants->scoped, argument + 17);
    if (!strcmp(argument, "--allow-clock")) return !grants->clock && (grants->clock = 1);
    if (!strcmp(argument, "--allow-host")) return !grants->host && (grants->host = 1);
    const char *seed = optional(argument, "--allow-random", &grants->entropy);
    if (seed) {
        grants->entropy = 1;
        if (*seed) grants->state = strtoull(seed, NULL, 10);
        return 1;
    }
    const char *names = optional(argument, "--allow-env", &grants->environment);
    if (names) {
        grants->environment = 1;
        grants->names = names;
        return 1;
    }
    if (!strcmp(argument, "--allow-all")) {
        if (grants->clock || grants->host || grants->entropy || grants->environment || grants->count || grants->scoped.endpoint_count) return 0;
        grants->clock = grants->entropy = grants->environment = grants->host = 1;
        grants->names = "";
        return directory(grants, ".", 1) && mylang_scoped_endpoint(&grants->scoped, "*");
    }
    *matched = !strncmp(argument, "--allow-", 8) || !strncmp(argument, "--restrict", 10);
    return !*matched;
}
/* Open every root the command line asks for. The default mode opens nothing but
   the working directory, which resolves relative paths against it and lets
   absolute paths name themselves. */
static int roots(MylangGrants *grants) {
    if (!grants->restricted) return mylang_scoped_working_directory(&grants->scoped);
    for (size_t i = 0; i < grants->count; ++i) {
        if (!mylang_scoped_grant(&grants->scoped, grants->directories[i].path, grants->directories[i].writable)) return 0;
    }
    return 1;
}
static int writable(const MylangGrants *grants) {
    if (!grants->restricted) return 1;
    for (size_t i = 0; i < grants->count; ++i) if (grants->directories[i].writable) return 1;
    return 0;
}
/* The entry shim asks for the `Host` authority a foreign call needs. Without
   `--restrict` it is granted like every other capability; under `--restrict`
   only `--allow-host` provides it. */
uint64_t myl_qbe_grant_host_checked(void *context, const char *flag) {
    if (!host_authority) { myl_qbe_fail_missing_capability(context, flag); return 0; }
    return UINT64_MAX - 5;
}
/* Apply the granted authority. A linked native provider is the program's whole
   authority unless `--restrict` is given; with no provider linked the command
   line decides, granting every capability by default. Write authority always
   implies read authority, so a default or write grant is never narrower than a
   read grant. */
static int provision(MylangGrants *grants, MylangNativeProviders *providers, int linked) {
    (void)mylang_host_charge;
    host_authority = !grants->restricted || grants->host;
    if (linked && !grants->restricted) return 1;
    if (!roots(grants)) return 0;
    int open = !grants->restricted;
    const MylangResourceProvider absent = {0};
    providers->filesystem = grants->scoped.count ? mylang_scoped_provider(&grants->scoped, writable(grants) ? 7u : 5u) : absent;
    providers->network = grants->scoped.endpoint_count ? mylang_scoped_network_provider(&grants->scoped, 7u) : absent;
    providers->clock_now = open || grants->clock ? clock_now : NULL;
    providers->random_context = NULL;
    providers->random_u64 = NULL;
    if (open || grants->entropy) {
        if (!grants->entropy) grants->state = (uint64_t)clock_now(NULL).value;
        providers->random_context = &grants->state;
        providers->random_u64 = random_u64;
    }
    providers->environment_context = NULL;
    providers->environment_get = NULL;
    if (open || grants->environment) {
        providers->environment_context = (void *)(uintptr_t)grants->names;
        providers->environment_get = environment_get;
    }
    return 1;
}
/* Split `text` in place into whitespace-separated options. A double-quoted
   stretch keeps its whitespace, and inside it a backslash takes the next
   character literally, so any option can be spelled. Returns the option count,
   or -1 for an unterminated quote. */
static int split_options(char *text, char **options) {
    int count = 0;
    char *read = text, *write = text;
    while (*read) {
        while (*read == ' ' || *read == '\t' || *read == '\n' || *read == '\r') ++read;
        if (!*read) break;
        options[count++] = write;
        int quoted = 0;
        for (; *read && (quoted || !(*read == ' ' || *read == '\t' || *read == '\n' || *read == '\r')); ++read) {
            if (*read == '"') { quoted = !quoted; continue; }
            if (quoted && *read == '\\' && read[1]) ++read;
            *write++ = *read;
        }
        if (quoted) return -1;
        if (*read) ++read;
        *write++ = 0;
    }
    return count;
}
/* Read every runtime option from `MYLANG_OPTIONS` into the grants and the
   controls. Returns 0 after reporting an option that is unknown, malformed or
   not a usable grant. */
static int read_options(MylangGrants *grants, MylQbeControls *controls, char **storage) {
    const char *value = getenv(MYLANG_OPTIONS_VARIABLE);
    *storage = NULL;
    if (!value || !*value) return 1;
    size_t length = strlen(value);
    char *text = malloc(length + 1);
    char **options = calloc(length / 2 + 1, sizeof *options);
    *storage = text;
    if (!text || !options) { free(options); fputs("OutOfMemory: QBE runtime failure\n", stderr); return 0; }
    memcpy(text, value, length + 1);
    int count = split_options(text, options);
    if (count < 0) fputs("mylang: " MYLANG_OPTIONS_VARIABLE " has an unterminated quote\n", stderr);
    for (int i = 0; i < count; ++i) {
        int matched = 0;
        int usable = accept(grants, options[i], &matched);
        if (matched && !usable) {
            fprintf(stderr, "mylang: the option %s is not a usable capability grant\n", options[i]);
            count = -1;
        } else if (!matched && !myl_qbe_control(controls, options[i])) {
            fprintf(stderr, "mylang: " MYLANG_OPTIONS_VARIABLE " names %s, which is not a runtime option\n", options[i]);
            count = -1;
        }
        if (count < 0) break;
    }
    free(options);
    return count >= 0;
}
int mylang_qbe_run_grants(uint64_t (*entry)(void *), int argc, char **argv, const MylangNativeProviders *base) {
    MylangGrants grants = {0};
    mylang_scoped_init(&grants.scoped);
    grants.names = "";
    MylQbeControls controls = {0};
    char *storage;
    if (!read_options(&grants, &controls, &storage)) {
        free(storage);
        return 2;
    }
    MylangNativeProviders providers = base ? *base : (MylangNativeProviders){0};
    int status = 2;
    /* Every argument after the program name is the guest's, `--` included. */
    if (provision(&grants, &providers, base != NULL)) status = mylang_qbe_run_process(entry, &controls, argc > 0 ? argc - 1 : 0, argc > 0 ? argv + 1 : argv, &providers);
    else fputs("mylang: a requested directory grant could not be opened\n", stderr);
    mylang_scoped_close(&grants.scoped);
    free(storage);
    return status;
}
