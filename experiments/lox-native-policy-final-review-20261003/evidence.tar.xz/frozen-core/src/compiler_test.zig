//! Semantic fixtures exercise public pipeline behavior and allocation ownership.
const std = @import("std");
const language = @import("compiler.zig");
const native = @import("native_execute.zig");
const testing = std.testing;

fn result(expression: []const u8, expected: i64) !void {
    const text = try std.fmt.allocPrint(testing.allocator, "def main() -> i64:\n    return {s}\n", .{expression});
    defer testing.allocator.free(text);
    var compilation = try language.Compilation.init(testing.allocator, "test.my", text);
    defer compilation.deinit();
    const outcome = try native.run(&compilation);
    try testing.expectEqual(expected, outcome.value);
}

// spec: CORE-2
test "overflow traps at the responsible operator without folding during check" {
    // The reported column is the one-based offset of the responsible operator,
    // which sits at `len("    return ")` plus its index inside the expression.
    const cases = [_]struct { expression: []const u8, column: u64 }{
        .{ .expression = "9223372036854775807 + 1", .column = 32 },
        .{ .expression = "3037000500 * 3037000500", .column = 23 },
        .{ .expression = "(0 - 9223372036854775807) - 2", .column = 38 },
    };
    for (cases) |case| {
        const text = try std.fmt.allocPrint(testing.allocator, "def main() -> i64:\n    return {s}\n", .{case.expression});
        defer testing.allocator.free(text);
        var compilation = try language.Compilation.init(testing.allocator, "trap.my", text);
        defer compilation.deinit();
        try compilation.check();
        try testing.expect(compilation.code == null);
        const outcome = try native.run(&compilation);
        try testing.expectEqualStrings("R_OVERFLOW", outcome.trap.code);
        try testing.expectEqual(@as(u64, 2), outcome.trap.line);
        try testing.expectEqual(case.column, outcome.trap.column);
    }
}

// spec: CORE-3
test "malformed source and range errors are normal located diagnostics" {
    const cases = [_]struct { text: []const u8, code: []const u8 }{
        .{ .text = "", .code = "E_MAIN" },
        .{ .text = "def main() -> i64:\n    return 1 + \n", .code = "E_EXPRESSION" },
        .{ .text = "def main() -> i64:\n    x = 41 return x + 1\n", .code = "E_SYNTAX" },
        .{ .text =
        \\def main() -> i64:
        \\    return 9223372036854775808
        , .code = "E_INTEGER_RANGE" },
        .{ .text =
        \\def main() -> i64:
        \\    return 999999999999999999999999999999999999999
        , .code = "E_INTEGER_RANGE" },
        .{ .text =
        \\def helper() -> i64:
        \\    return 1
        , .code = "E_MAIN" },
        .{ .text =
        \\def main() -> bool:
        \\    return 1
        , .code = "E_TYPE" },
        .{ .text = "def main() -> i64:\n    return $\n", .code = "E_TOKEN" },
    };
    for (cases) |case| {
        var compilation = try language.Compilation.init(testing.allocator, "bad.my", case.text);
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        try testing.expect(compilation.program == null and compilation.code == null);
        try testing.expectEqualStrings(case.code, compilation.diagnostics.items[0].code);
        try testing.expect(compilation.diagnostics.items[0].span.end <= case.text.len);
    }
}

// spec-case: CHECK-LIBRARY-2
test "a unit without main checks as a library and retains no executable program" {
    var library = try language.Compilation.init(testing.allocator, "lib.my", "public def add(a: int, b: int) -> int:\n    return a + b\n\ndef mainly() -> int:\n    return 1\n");
    defer library.deinit();
    try library.parse();
    try testing.expect(!library.declaresMain());
    try library.checkLibrary();
    try testing.expect(library.program == null and library.diagnostics.items.len == 0);

    var broken = try language.Compilation.init(testing.allocator, "broken.my", "public def value() -> int:\n    return False\n");
    defer broken.deinit();
    try broken.parse();
    try testing.expectError(error.SourceError, broken.checkLibrary());
    try testing.expectEqualStrings("E_TYPE", broken.diagnostics.items[0].code);

    var entry = try language.Compilation.init(testing.allocator, "entry.my", "def main(count: int) -> int:\n    return count\n");
    defer entry.deinit();
    try entry.parse();
    try testing.expect(entry.declaresMain());
    try testing.expectError(error.SourceError, entry.check());
    try testing.expectEqualStrings("E_MAIN", entry.diagnostics.items[0].code);
}

test "source is owned and CRLF diagnostics locate operators and EOF" {
    const bytes = try testing.allocator.dupe(u8, "# comment\r\ndef main() -> i64:\r\n    return 9223372036854775807 + 1\r\n");
    var compilation = try language.Compilation.init(testing.allocator, "crlf.my", bytes);
    testing.allocator.free(bytes);
    defer compilation.deinit();
    const outcome = try native.run(&compilation);
    try testing.expectEqual(@as(u64, 3), outcome.trap.line);
    try testing.expectEqual(@as(u64, 32), outcome.trap.column);
    try testing.expect(std.mem.indexOf(u8, outcome.stderr, "crlf.my:3:32: error[R_OVERFLOW]") != null);
    try testing.expect(std.mem.indexOfScalar(u8, outcome.stderr, '\r') == null);
    try testing.expectEqual(@as(usize, 4), compilation.src.locate(compilation.src.bytes.len).line);
}

test "bytecode dump is deterministic and multiplication precedes addition" {
    var compilation = try language.Compilation.init(testing.allocator, "test.my",
        \\def main() -> i64:
        \\    return 1 + 2 * 3
    );
    defer compilation.deinit();
    const first = try compilation.dump(testing.allocator);
    defer testing.allocator.free(first);
    const second = try compilation.dump(testing.allocator);
    defer testing.allocator.free(second);
    try testing.expectEqualStrings(first, second);
    try testing.expect(std.mem.indexOf(u8, first, "MUL_I64_CHECKED").? < std.mem.indexOf(u8, first, "ADD_I64_CHECKED").?);
}

test "parser rejects excessive nesting without a host stack overflow" {
    var text: std.Io.Writer.Allocating = .init(testing.allocator);
    defer text.deinit();
    try text.writer.writeAll("def main() -> i64:\n    return ");
    try text.writer.splatByteAll('(', 300);
    try text.writer.writeByte('1');
    try text.writer.splatByteAll(')', 300);
    try text.writer.writeAll("\n");
    var compilation = try language.Compilation.init(testing.allocator, "deep.my", text.written());
    defer compilation.deinit();
    try testing.expectError(error.SourceError, compilation.check());
    try testing.expectEqualStrings("E_NESTING_LIMIT", compilation.diagnostics.items[0].code);
}

fn allocationScenario(allocator: std.mem.Allocator) !void {
    var compilation = try language.Compilation.init(allocator, "test.my",
        \\def main() -> i64:
        \\    return (1 + 2) * 3
    );
    defer compilation.deinit();
    try compilation.emit();
    try testing.expect(compilation.code != null);
    const text = try compilation.dump(allocator);
    defer allocator.free(text);
}

test "request allocation failures release all owned storage" {
    try testing.checkAllAllocationFailures(testing.allocator, allocationScenario, .{});
}

test "invalid internal bytecode is not a guest trap" {
    const program: language.bytecode.Program = .{ .functions = &.{.{
        .id = @fromBackingInt(@intCast(0)),
        .name = "main",
        .scope = .{
            .instructions = &.{.{ .span = .{ .start = 0, .end = 0 }, .op = .ret }},
        },
    }} };
    try testing.expectError(error.InternalError, language.bytecode.validate(testing.allocator, program));
}

fn programResult(text: []const u8, expected: i64) !void {
    var compilation = try language.Compilation.init(testing.allocator, "program.my", text);
    defer compilation.deinit();
    try testing.expectEqual(expected, (try native.run(&compilation)).value);
}

test "unary arithmetic and directly negated minimum literal" {
    try result("-3 * 2 + 10", 4);
    try result("--8", 8);
    try result("-9223372036854775808", std.math.minInt(i64));
    try result("-((9223372036854775808))", std.math.minInt(i64));
    try result("-9_223_372_036_854_775_808", std.math.minInt(i64));
    var compilation = try language.Compilation.init(testing.allocator, "neg.my",
        \\def main() -> i64:
        \\    return --9223372036854775808
    );
    defer compilation.deinit();
    const outcome = try native.run(&compilation);
    try testing.expectEqualStrings("R_OVERFLOW", outcome.trap.code);
    try testing.expectEqual(@as(u64, 2), outcome.trap.line);
    try testing.expectEqual(@as(u64, 12), outcome.trap.column);
}

test "scope types immutability and structural return diagnostics" {
    const cases = [_]struct { body: []const u8, code: []const u8 }{
        .{ .body = "main = 1\n    return main", .code = "E_SHADOWING" },
        .{ .body = "x = x\n    return x", .code = "E_UNKNOWN_NAME" },
        .{ .body = "x: bool = 1\n    return 0", .code = "E_TYPE" },
        .{ .body = "x = True\n    x = 1\n    return 0", .code = "E_TYPE" },
        .{ .body = "return True + 1", .code = "E_TYPE" },
        .{ .body = "b = True < False\n    return 0", .code = "E_TYPE" },
        .{ .body = "b = True == 1\n    return 0", .code = "E_TYPE" },
        .{ .body = "return not 1", .code = "E_TYPE" },
        .{ .body = "return -True", .code = "E_TYPE" },
        .{ .body = "return True", .code = "E_TYPE" },
        .{ .body = "x = 1", .code = "E_MISSING_RETURN" },
        .{ .body = "return 1\n    return 2", .code = "E_UNREACHABLE" },
        .{ .body = "return -(9223372036854775808 + 0)", .code = "E_INTEGER_RANGE" },
        .{ .body = "return -9223372036854775809", .code = "E_INTEGER_RANGE" },
        .{ .body = "bool = 1\n    return 0", .code = "E_EXPRESSION" },
    };
    for (cases) |case| {
        const text = try std.fmt.allocPrint(testing.allocator,
            \\def main() -> i64:
            \\    {s}
        , .{case.body});
        defer testing.allocator.free(text);
        var compilation = try language.Compilation.init(testing.allocator, "bad.my", text);
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        try testing.expectEqualStrings(case.code, compilation.diagnostics.items[0].code);
    }
}

test "binding warnings distinguish writes from reads across function-scoped blocks" {
    const text =
        \\def main() -> i64:
        \\    unused = 1
        \\    write_only = 2
        \\    write_only = 3
        \\    if True:
        \\        branch_only = 4
        \\    if True:
        \\        used = 5
        \\        return used
        \\    return 0
    ;
    var compilation = try language.Compilation.init(testing.allocator, "warnings.my", text);
    defer compilation.deinit();
    try testing.expectEqual(@as(i64, 5), (try native.run(&compilation)).value);
    const warnings = compilation.diagnostics.items;
    try testing.expectEqual(@as(usize, 3), warnings.len);
    try testing.expectEqualStrings("W_UNUSED_BINDING", warnings[0].code);
    try testing.expectEqualStrings("W_UNUSED_BINDING", warnings[1].code);
    try testing.expectEqualStrings("unused", compilation.src.text(warnings[0].span));
    try testing.expectEqualStrings("write_only", compilation.src.text(warnings[1].span));
    // A binding assigned only inside a branch and never read still warns, and its
    // span points at the assignment that introduced it.
    try testing.expectEqualStrings("branch_only", compilation.src.text(warnings[2].span));
    try testing.expectEqual(std.mem.indexOf(u8, text, "branch_only = 4").?, warnings[2].span.start);
    for (warnings) |warning| try testing.expectEqual(language.diagnostic.Severity.warning, warning.severity);
    try compilation.check();
    try testing.expectEqual(@as(usize, 3), compilation.diagnostics.items.len);
}

fn localAllocationScenario(allocator: std.mem.Allocator) !void {
    var compilation = try language.Compilation.init(allocator, "locals.my",
        \\def main() -> i64:
        \\    x = 3
        \\    y = 5
        \\    x = x * y
        \\    unused = False
        \\    return x
    );
    defer compilation.deinit();
    try compilation.emit();
    try testing.expect(compilation.diagnostics.items.len != 0);
    for (compilation.diagnostics.items) |diagnostic| {
        const text = try diagnostic.render(allocator, compilation.src);
        defer allocator.free(text);
    }
}

test "allocation failure during scope checking warning rendering and locals execution releases storage" {
    var no_resize = testing.FailingAllocator.init(testing.allocator, .{ .resize_fail_index = 0 });
    try testing.checkAllAllocationFailures(no_resize.allocator(), localAllocationScenario, .{});
}

/// Write `def main` returning a left-associative chain of `terms` added ones.
fn additions(text: *std.Io.Writer.Allocating, terms: usize) !void {
    try text.writer.writeAll("def main() -> i64:\n    return 1");
    for (1..terms) |_| try text.writer.writeAll(" + 1");
    try text.writer.writeAll("\n");
}

test "long left-associative expressions do not recursively traverse host stacks" {
    var deep: std.Io.Writer.Allocating = .init(testing.allocator);
    defer deep.deinit();
    try additions(&deep, 4096);
    var compilation = try language.Compilation.init(testing.allocator, "long.my", deep.written());
    defer compilation.deinit();
    // Parsing, checking and lowering 4,096 operands stay iterative; a shorter
    // chain then proves the same lowering still evaluates from the left.
    try compilation.emit();
    try testing.expectEqual(@as(usize, 1), compilation.code.?.functions.len);
    var shorter: std.Io.Writer.Allocating = .init(testing.allocator);
    defer shorter.deinit();
    try additions(&shorter, 1024);
    try programResult(shorter.written(), 1024);
}

fn booleanResult(expression: []const u8, expected: bool) !void {
    const text = try std.fmt.allocPrint(testing.allocator, "def main() -> i64:\n    if {s}:\n        return 1\n    else:\n        return 0\n", .{expression});
    defer testing.allocator.free(text);
    try programResult(text, if (expected) 1 else 0);
}

test "instruction limit is checked before the next dispatch" {
    var compilation = try language.Compilation.init(testing.allocator, "budget.my",
        \\def main() -> i64:
        \\    return 1
    );
    defer compilation.deinit();
    try testing.expectEqualStrings("R_STEP_LIMIT", (try native.runWithOptions(&compilation, .{ .max_steps = 1 })).trap.code);
    try testing.expectEqual(@as(i64, 1), (try native.runWithOptions(&compilation, .{ .max_steps = 2 })).value);
    try testing.expectEqualStrings("InvalidBudget", (try native.runWithOptions(&compilation, .{ .max_steps = 0 })).trap.code);
    var infinite = try language.Compilation.init(testing.allocator, "loop.my",
        \\def main() -> i64:
        \\    while True:
        \\        pass
        \\    return 0
    );
    defer infinite.deinit();
    const outcome = try native.runWithOptions(&infinite, .{ .max_steps = 123 });
    try testing.expectEqualStrings("R_STEP_LIMIT", outcome.trap.code);
    try testing.expectEqualStrings("loop.my", outcome.trap.path);
    try testing.expect(outcome.trap.line != 0);
}

fn flowAllocationScenario(allocator: std.mem.Allocator) !void {
    var compilation = try language.Compilation.init(allocator, "flow.my",
        \\def main() -> i64:
        \\    i = 0
        \\    while i < 5:
        \\        if remtrunc(i, 2) == 0:
        \\            _ = True or divtrunc(1, 0) == 0
        \\        i += 1
        \\    return i
    );
    defer compilation.deinit();
    try compilation.emit();
    try testing.expectEqual(@as(usize, 1), compilation.code.?.functions.len);
}

test "allocation failures during label patching and control-flow validation release storage" {
    try testing.checkAllAllocationFailures(testing.allocator, flowAllocationScenario, .{});
}

test "function signatures entry points and all uncalled bodies are checked" {
    try programResult(
        \\def f(n: i64) -> i64:
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return f(42)
    , 42);
    const cases = [_]struct { text: []const u8, code: []const u8 }{
        .{ .text =
        \\def main() -> i64:
        \\    return 1
        \\
        \\
        \\def main() -> i64:
        \\    return 2
        , .code = "E_DUPLICATE_FUNCTION" },
        .{ .text =
        \\def f() -> i64:
        \\    return 1
        \\
        \\
        \\def f() -> bool:
        \\    return True
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_DUPLICATE_FUNCTION" },
        .{ .text =
        \\def main(n: i64) -> i64:
        \\    return n
        , .code = "E_MAIN" },
        .{ .text =
        \\def main() -> i64:
        \\    return missing()
        , .code = "E_UNKNOWN_FUNCTION" },
        .{ .text =
        \\def main() -> i64:
        \\    f = 1
        \\    return f()
        , .code = "E_CALLBACK_TYPE" },
        .{ .text =
        \\def f(n: i64) -> i64:
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return f()
        , .code = "E_ARITY" },
        .{ .text =
        \\def f(n: i64) -> i64:
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return f(1, 2)
        , .code = "E_ARITY" },
        .{ .text =
        \\def f(n: i64) -> i64:
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return f(True)
        , .code = "E_TYPE" },
        .{ .text =
        \\def f(n: i64, n: bool) -> bool:
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_DUPLICATE_PARAMETER" },
        .{ .text =
        \\def f(main: i64) -> i64:
        \\    return main
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_SHADOWING" },
        .{ .text =
        \\def f(n: i64) -> i64:
        \\    n: i64 = 2
        \\    return n
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_SHADOWING" },
        .{ .text =
        \\def main() -> i64:
        \\    f = 2
        \\    return f
        \\
        \\
        \\def f() -> i64:
        \\    return 0
        , .code = "E_SHADOWING" },
        .{ .text =
        \\def f() -> bool:
        \\    return 1
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_TYPE" },
        .{ .text =
        \\def f() -> bool:
        \\    pass
        \\
        \\
        \\def main() -> i64:
        \\    return 0
        , .code = "E_MISSING_RETURN" },
        .{ .text =
        \\def main() -> i64:
        \\    return 0
        \\
        \\
        \\def f() -> i64:
        \\    return unknown
        , .code = "E_UNKNOWN_NAME" },
        .{ .text =
        \\def main() -> i64:
        \\    f()
        \\    return 0
        \\
        \\
        \\def f() -> i64:
        \\    return 1
        , .code = "E_EXPLICIT_DISCARD_REQUIRED" },
        .{ .text =
        \\def main() -> i64:
        \\    return main(1)
        , .code = "E_ARITY" },
    };
    for (cases) |case| {
        var compilation = try language.Compilation.init(testing.allocator, "functions.my", case.text);
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        try testing.expectEqualStrings(case.code, compilation.diagnostics.items[0].code);
    }
}

test "parameter warnings remain separate between functions and are deferred until full success" {
    var compilation = try language.Compilation.init(testing.allocator, "warnings.my",
        \\def f(x: i64) -> i64:
        \\    return 0
        \\
        \\
        \\def g(x: i64) -> i64:
        \\    return x
        \\
        \\
        \\def main() -> i64:
        \\    return 7
    );
    defer compilation.deinit();
    try compilation.check();
    try testing.expectEqual(@as(usize, 1), compilation.diagnostics.items.len);
    try testing.expectEqualStrings("W_UNUSED_BINDING", compilation.diagnostics.items[0].code);
    try testing.expectEqual(@as(usize, 6), compilation.diagnostics.items[0].span.start);
    var invalid = try language.Compilation.init(testing.allocator, "bad.my",
        \\def f(x: i64) -> i64:
        \\    return 0
        \\
        \\
        \\def main() -> i64:
        \\    return False
    );
    defer invalid.deinit();
    try testing.expectError(error.SourceError, invalid.check());
    try testing.expectEqual(@as(usize, 1), invalid.diagnostics.items.len);
    try testing.expectEqualStrings("E_TYPE", invalid.diagnostics.items[0].code);
}

test "frame limits count main and guest recursion never consumes the host call stack" {
    var compilation = try language.Compilation.init(testing.allocator, "frames.my",
        \\def main() -> i64:
        \\    return main()
    );
    defer compilation.deinit();
    try testing.expectEqualStrings("InvalidBudget", (try native.runWithOptions(&compilation, .{ .max_frames = 0 })).trap.code);
    const one = try native.runWithOptions(&compilation, .{ .max_frames = 1 });
    try testing.expectEqualStrings("R_FRAME_LIMIT", one.trap.code);
    try testing.expectEqual(@as(usize, 1), one.trap.frames.len);
    // Twenty thousand guest frames never reach the host stack; the runtime
    // reports the innermost sixteen of them and omits the rest.
    const deep = try native.runWithOptions(&compilation, .{ .max_frames = 20_000 });
    try testing.expectEqualStrings("R_FRAME_LIMIT", deep.trap.code);
    try testing.expectEqual(@as(usize, 16), deep.trap.frames.len);
    const step = try native.runWithOptions(&compilation, .{ .max_steps = 2 });
    try testing.expectEqualStrings("R_STEP_LIMIT", step.trap.code);
    try testing.expectEqual(@as(usize, 3), step.trap.frames.len);
}

test "call traces locate guest operators and callers and argument traps evaluate left to right" {
    const text =
        \\def main() -> i64:
        \\    return outer()
        \\
        \\
        \\def outer() -> i64:
        \\    return inner()
        \\
        \\
        \\def inner() -> i64:
        \\    return divtrunc(1, 0)
    ;
    var compilation = try language.Compilation.init(testing.allocator, "trace.my", text);
    defer compilation.deinit();
    const outcome = try native.run(&compilation);
    try testing.expectEqualStrings("R_DIVISION_BY_ZERO", outcome.trap.code);
    try testing.expectEqual(@as(usize, 3), outcome.trap.frames.len);
    for ([_][]const u8{ "inner", "outer", "main" }, 0..) |name, i| {
        try testing.expectEqualStrings(name, outcome.trap.frames[i].function);
        try testing.expectEqual(@as(u64, 10 - 4 * i), outcome.trap.frames[i].line);
    }
    try testing.expect(std.mem.indexOf(u8, outcome.stderr, "in outer at trace.my:6:") != null);
    var order = try language.Compilation.init(testing.allocator, "order.my",
        \\def f(a: i64, b: i64) -> i64:
        \\    return a + b
        \\
        \\
        \\def main() -> i64:
        \\    return f(divtrunc(1, 0), 9223372036854775807 + 1)
    );
    defer order.deinit();
    try testing.expectEqualStrings("R_DIVISION_BY_ZERO", (try native.run(&order)).trap.code);
}

fn callAllocationScenario(allocator: std.mem.Allocator) !void {
    var compilation = try language.Compilation.init(allocator, "calls.my",
        \\def f(n: i64) -> i64:
        \\    if n == 0:
        \\        return divtrunc(1, 0)
        \\    return 1 + f(n - 1)
        \\
        \\
        \\def main() -> i64:
        \\    return f(50)
    );
    defer compilation.deinit();
    try compilation.emit();
    const dumped = try compilation.dump(allocator);
    defer allocator.free(dumped);
    try testing.expect(dumped.len != 0);
}

test "allocation failures in signature collection and call emission release storage" {
    var no_resize = testing.FailingAllocator.init(testing.allocator, .{ .resize_fail_index = 0 });
    try testing.checkAllAllocationFailures(no_resize.allocator(), callAllocationScenario, .{});
}

test "malformed syntax smoke corpus keeps diagnostics inside owned source" {
    const seed =
        \\def main() -> i64:
        \\    x = 3
        \\    while x > 0:
        \\        x -= 1
        \\    return x
    ;
    for (0..seed.len) |end| {
        var compilation = try language.Compilation.init(testing.allocator, "prefix.my", seed[0..end]);
        defer compilation.deinit();
        compilation.check() catch |err| {
            try testing.expectEqual(error.SourceError, err);
            const diag = compilation.diagnostics.items[0];
            try testing.expect(diag.span.start <= diag.span.end and diag.span.end <= end);
        };
    }
}
test "mutated syntax smoke corpus keeps diagnostics inside owned source" {
    const seed =
        \\def main() -> i64:
        \\    x = 3
        \\    while x > 0:
        \\        x -= 1
        \\    return x
    ;
    const bytes = [_]u8{ 0, 0xff, '\n', ')', '}', ',', ';', '!', '=', '/', '&', '|' };
    for (0..bytes.len * seed.len) |case| {
        const byte = bytes[case / seed.len];
        const at = case % seed.len;
        var mutated: [seed.len]u8 = seed.*;
        mutated[at] = byte;
        var compilation = try language.Compilation.init(testing.allocator, "mutated.my", &mutated);
        defer compilation.deinit();
        compilation.check() catch |err| {
            try testing.expectEqual(error.SourceError, err);
            const diag = compilation.diagnostics.items[0];
            try testing.expect(diag.span.start <= diag.span.end and diag.span.end <= mutated.len);
        };
    }
}

test "all recursive syntax forms obey the parser nesting budget" {
    for ([_][]const u8{ "-", "id(", "{" }) |opening| {
        var text: std.Io.Writer.Allocating = .init(testing.allocator);
        defer text.deinit();
        try text.writer.writeAll("def main() -> i64:\n    return ");
        for (0..300) |_| try text.writer.writeAll(opening);
        // Rejection occurs at the resource boundary before trailing syntax matters.
        try text.writer.writeAll("1");
        var compilation = try language.Compilation.init(testing.allocator, "nesting.my", text.written());
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        try testing.expectEqualStrings("E_NESTING_LIMIT", compilation.diagnostics.items[0].code);
    }
}

test "emission validation rejects invalid references jumps and inconsistent joins" {
    const bc = language.bytecode;
    const span: language.source.Span = .{ .start = 0, .end = 0 };
    const variants = [_][]const bc.Instruction{
        &.{.{ .span = span, .op = .{ .jump = 1 } }},
        &.{.{ .span = span, .op = .{ .call = @fromBackingInt(1) } }},
        &.{.{ .span = span, .op = .{ .load_local = @fromBackingInt(0) } }},
        &.{ .{ .span = span, .op = .{ .push_bool = true } }, .{ .span = span, .op = .{ .jump_if_false = 3 } }, .{ .span = span, .op = .{ .push_i64 = 1 } }, .{ .span = span, .op = .{ .jump = 3 } } },
    };
    for (variants) |instructions| {
        const program: bc.Program = .{ .functions = &.{.{
            .id = @fromBackingInt(0),
            .name = "main",
            .scope = .{
                .instructions = instructions,
            },
        }} };
        try testing.expectError(error.InternalError, language.bytecode.validate(testing.allocator, program));
    }
}

fn rejectedAllocationScenario(allocator: std.mem.Allocator) !void {
    var compilation = try language.Compilation.init(allocator, "rejected.my",
        \\def main() -> i64:
        \\    return 0
        \\
        \\
        \\def main() -> i64:
        \\    return 1
    );
    defer compilation.deinit();
    compilation.check() catch |err| switch (err) {
        error.SourceError => {
            const text = try compilation.diagnostics.items[0].render(allocator, compilation.src);
            defer allocator.free(text);
            return;
        },
        else => return err,
    };
    return error.ExpectedSourceError;
}

test "allocation failures while producing source errors remain host failures and release storage" {
    try testing.checkAllAllocationFailures(testing.allocator, rejectedAllocationScenario, .{});
}

test "all comparisons boolean operations and logical precedence have observable results" {
    try booleanResult("1 < 2", true);
    try booleanResult("2 < 2", false);
    try booleanResult("2 <= 2", true);
    try booleanResult("3 > 2", true);
    try booleanResult("2 >= 2", true);
    try booleanResult("2 >= 3", false);
    try booleanResult("2 == 2", true);
    try booleanResult("2 != 2", false);
    try booleanResult("True == False", false);
    try booleanResult("True != False", true);
    try booleanResult("not False", true);
    try booleanResult("not True", false);
    try booleanResult("False or True and False", false);
    try booleanResult("True or False and False", true);
    try booleanResult("1 + 2 * 3 == 7 and 4 >= 3", true);
    const operands = [_][]const u8{ "False", "True" };
    for (0..4) |pair| {
        const a = pair / 2;
        const b = pair % 2;
        const left = operands[a];
        const right = operands[b];
        const conjunction = try std.fmt.allocPrint(testing.allocator, "{s} and {s}", .{ left, right });
        defer testing.allocator.free(conjunction);
        const disjunction = try std.fmt.allocPrint(testing.allocator, "{s} or {s}", .{ left, right });
        defer testing.allocator.free(disjunction);
        try booleanResult(conjunction, a == 1 and b == 1);
        try booleanResult(disjunction, a == 1 or b == 1);
    }
}

test "short circuit skips traps while an explicit drop retains evaluation" {
    try booleanResult("False and (divtrunc(1, 0) == 0)", false);
    try booleanResult("True or (divtrunc(1, 0) == 0)", true);
    try programResult(
        \\def main() -> i64:
        \\    _ = False and divtrunc(1, 0) == 0
        \\    _ = True or divtrunc(1, 0) == 0
        \\    _ = 1 + 2
        \\    return 7
    , 7);
    try programResult(
        \\def main() -> i64:
        \\    flag = False
        \\    flag = True and not flag
        \\    if flag:
        \\        return 4
        \\    else:
        \\        return 9
    , 4);
    const cases = [_]struct { expression: []const u8, code: []const u8 }{
        .{ .expression = "True and (divtrunc(1, 0) == 0)", .code = "R_DIVISION_BY_ZERO" },
        .{ .expression = "False or (divtrunc(1, 0) == 0)", .code = "R_DIVISION_BY_ZERO" },
        .{ .expression = "divtrunc(1, 0)", .code = "R_DIVISION_BY_ZERO" },
        .{ .expression = "remtrunc(1, 0)", .code = "R_DIVISION_BY_ZERO" },
        .{ .expression = "divtrunc(-9223372036854775808, -1)", .code = "R_OVERFLOW" },
        .{ .expression = "(9223372036854775807 + 1) + divtrunc(1, 0)", .code = "R_OVERFLOW" },
        .{ .expression = "divtrunc(1, 0) + (9223372036854775807 + 1)", .code = "R_DIVISION_BY_ZERO" },
    };
    for (cases) |case| {
        const text = try std.fmt.allocPrint(testing.allocator, "def main() -> i64:\n    _ = {s}\n    return 0\n", .{case.expression});
        defer testing.allocator.free(text);
        var compilation = try language.Compilation.init(testing.allocator, "trap.my", text);
        defer compilation.deinit();
        try compilation.check();
        try testing.expectEqualStrings(case.code, (try native.run(&compilation)).trap.code);
    }
}

test "control flow requires boolean conditions and conservative complete returns" {
    const cases = [_]struct { body: []const u8, code: []const u8 }{
        .{ .body = "if 1:\n        return 1\n    else:\n        return 0", .code = "E_TYPE" },
        .{ .body = "while 0:\n        pass\n    return 0", .code = "E_TYPE" },
        .{ .body = "if True:\n        return 1", .code = "E_MISSING_RETURN" },
        .{ .body = "while True:\n        break", .code = "E_MISSING_RETURN" },
        .{ .body = "if True:\n        return 1\n    else:\n        return 2\n    return 3", .code = "E_UNREACHABLE" },
        .{ .body = "if True:\n        return 1\n    else:\n        return True", .code = "E_TYPE" },
        .{ .body = "_ = False and unknown\n    return 0", .code = "E_UNKNOWN_NAME" },
        .{ .body = "_ = 1 and True\n    return 0", .code = "E_TYPE" },
        .{ .body = "x = True\n    x += False\n    return 0", .code = "E_TYPE" },
        .{ .body = "1 + 2\n    return 0", .code = "E_EXPLICIT_DISCARD_REQUIRED" },
        .{ .body = "if True:\n        local = 1\n    return local", .code = "E_UNBOUND" },
    };
    for (cases) |case| {
        const text = try std.fmt.allocPrint(testing.allocator,
            \\def main() -> i64:
            \\    {s}
        , .{case.body});
        defer testing.allocator.free(text);
        var compilation = try language.Compilation.init(testing.allocator, "bad.my", text);
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        try testing.expectEqualStrings(case.code, compilation.diagnostics.items[0].code);
    }
}

test "explicit drops and compound assignment count as reads and skipped branches count syntactically" {
    const text =
        \\def main() -> i64:
        \\    x = 1
        \\    _ = x
        \\    y = 0
        \\    y += 1
        \\    z = 0
        \\    if False:
        \\        z = 1
        \\    _ = z
        \\    return 0
    ;
    var compilation = try language.Compilation.init(testing.allocator, "warnings.my", text);
    defer compilation.deinit();
    try compilation.check();
    try testing.expectEqual(@as(usize, 0), compilation.diagnostics.items.len);
}

test "runtime storage remains bounded across many calls and loop declarations" {
    var compilation = try language.Compilation.init(testing.allocator, "bounded.my",
        \\def f(n: i64) -> i64:
        \\    local = n + 1
        \\    return local
        \\
        \\
        \\def main() -> i64:
        \\    n = 0
        \\    while n < 100000:
        \\        local = 1 + f(n)
        \\        _ = local
        \\        n += 1
        \\    return n
    );
    defer compilation.deinit();
    // Two live frames are all this program ever needs. Retaining an abandoned
    // frame, local or value for any of the 100,000 iterations would exceed the
    // budget long before the loop finished.
    const outcome = try native.runWithOptions(&compilation, .{ .max_frames = 2 });
    try testing.expectEqual(@as(i64, 100000), outcome.value);
    try testing.expectEqualStrings("", outcome.stdout);
}

test "located source diagnostics include EOF explicit drops and previous declarations" {
    for ([_][]const u8{ "\n", "\r\n" }) |newline| {
        const text = try std.fmt.allocPrint(testing.allocator, "def main() -> i64:{s}    return 1 + {s}", .{ newline, newline });
        defer testing.allocator.free(text);
        var compilation = try language.Compilation.init(testing.allocator, "eof.my", text);
        defer compilation.deinit();
        try testing.expectError(error.SourceError, compilation.check());
        const diag = compilation.diagnostics.items[0];
        try testing.expectEqual(text.len, diag.span.start);
        try testing.expectEqual(text.len, diag.span.end);
        try testing.expectEqual(@as(usize, 3), compilation.src.locate(diag.span.start).line);
        try testing.expectEqual(@as(usize, 1), compilation.src.locate(diag.span.start).column);
    }
    var duplicate = try language.Compilation.init(testing.allocator, "duplicate.my",
        \\def main() -> i64:
        \\    return 1
        \\
        \\
        \\def main() -> i64:
        \\    return 2
    );
    defer duplicate.deinit();
    try testing.expectError(error.SourceError, duplicate.check());
    const diag = duplicate.diagnostics.items[0];
    try testing.expectEqualStrings("main", duplicate.src.text(diag.span));
    try testing.expectEqual(@as(usize, 4), diag.related.?.span.start);
    const rendered = try diag.render(testing.allocator, duplicate.src);
    defer testing.allocator.free(rendered);
    try testing.expect(std.mem.indexOf(u8, rendered, "note: duplicate.my:1:5: previous function declaration") != null);
    var discard = try language.Compilation.init(testing.allocator, "ignored.my",
        \\def main() -> i64:
        \\    1 + 2
        \\    return 7
    );
    defer discard.deinit();
    try testing.expectError(error.SourceError, discard.check());
    try testing.expectEqualStrings("E_EXPLICIT_DISCARD_REQUIRED", discard.diagnostics.items[0].code);
    try testing.expectEqualStrings("1 + 2", discard.src.text(discard.diagnostics.items[0].span));
}
// spec: GC-PACING-1
test "the pausing collector reclaims garbage and still enforces the byte budget" {
    var reclaiming = try language.Compilation.init(testing.allocator, "pacing.my",
        \\def main() -> i64:
        \\    n = 0
        \\    while n < 50000:
        \\        garbage = [n, n + 1, n + 2, n + 3]
        \\        n += 1
        \\    return n
    );
    defer reclaiming.deinit();
    // Every list is unreachable and the loop allocates several times the ceiling;
    // only collection keeps the run inside the budget.
    const reclaimed = try native.runWithOptions(&reclaiming, .{ .max_memory = 1 << 20 });
    try testing.expectEqual(@as(i64, 50000), reclaimed.value);
    var bounded = try language.Compilation.init(testing.allocator, "pacing.my",
        \\def main() -> i64:
        \\    values: list[i64] = []
        \\    n = 0
        \\    while n < 400000:
        \\        values.append(n)
        \\        n += 1
        \\    return len(values)
    );
    defer bounded.deinit();
    // A live list that outgrows the ceiling still traps, so the budget binds on
    // every allocation and not only when a collection would have run.
    const refused = try native.runWithOptions(&bounded, .{ .max_memory = 1 << 20 });
    try testing.expectEqualStrings("R_MEMORY_BUDGET", refused.trap.code);
}

// spec: CLASS-WRITE-1
test "a class field write mutates the receiver in place without copying it" {
    const legacy = @import("test_support.zig").LegacySharing.enter();
    defer legacy.restore();
    const source =
        \\class Box:
        \\    n: int
        \\
        \\
        \\def bump(b: mut Box, v: int):
        \\    b.n = v
        \\
        \\
        \\def main() -> int:
        \\    box = Box(n=1)
        \\    bump(mut box, 5)
        \\    return box.n
    ;
    var compilation = try language.Compilation.init(testing.allocator, "class_write.my", source);
    defer compilation.deinit();
    try compilation.emit();
    var writes: usize = 0;
    for (compilation.code.?.functions) |function| {
        if (!std.mem.eql(u8, function.name, "bump")) continue;
        for (function.scope.instructions) |instruction| switch (instruction.op) {
            .update_record => writes += 1,
            else => {},
        };
    }
    // One in-place update and nothing else: no copied receiver, so the body stays
    // a handful of instructions rather than the eleven a copy-and-refresh costs.
    try testing.expectEqual(@as(usize, 1), writes);
    const outcome = try native.run(&compilation);
    try testing.expectEqual(@as(i64, 5), outcome.value);
}

/// A program of `count` small functions, each a loop over a list, called from `main`.
fn loopFunctions(allocator: std.mem.Allocator, count: usize) ![]u8 {
    var text: std.Io.Writer.Allocating = .init(allocator);
    defer text.deinit();
    for (0..count) |index| try text.writer.print("def f{d}(n: int) -> int:\n    xs: list[int] = []\n    for k in range(n):\n        if k % 3 == 0:\n            xs.append(k * {d})\n    return len(xs)\n\n\n", .{ index, index });
    try text.writer.writeAll("def main() -> int:\n    total = 0\n");
    for (0..count) |index| try text.writer.print("    total += f{d}(4)\n", .{index});
    try text.writer.writeAll("    return total\n");
    return text.toOwnedSlice();
}
/// Bytes lowering reserved in its output arena when its scratch draws from
/// `scratch` (null: from the output itself), and the lowered program's size.
fn loweredBytes(program: @import("typed.zig").Program, scratch: ?std.mem.Allocator) !struct { bytes: usize, instructions: usize } {
    const lower = @import("lower.zig");
    var counting = testing.FailingAllocator.init(testing.allocator, .{});
    var output = std.heap.ArenaAllocator.init(counting.allocator());
    defer output.deinit();
    const lowered = try lower.lowerWith(.{ .output = output.allocator(), .scratch = scratch orelse output.allocator() }, program, false);
    var instructions: usize = 0;
    for (lowered.functions) |function| instructions += function.scope.instructions.len;
    return .{ .bytes = counting.allocated_bytes, .instructions = instructions };
}
// spec: LOWER-EXACT-1
test "lowering keeps only each function's exact instructions in its output" {
    const text = try loopFunctions(testing.allocator, 200);
    defer testing.allocator.free(text);
    var compilation = try language.Compilation.init(testing.allocator, "lowering.my", text);
    defer compilation.deinit();
    try compilation.check();
    const inside = try loweredBytes(compilation.program.?, null);
    const apart = try loweredBytes(compilation.program.?, testing.allocator);
    try testing.expectEqual(inside.instructions, apart.instructions);
    // The emitter's lists and the validation tables were most of the output.
    try testing.expect(apart.bytes * 2 < inside.bytes);
}

const Modules = struct {
    fn read(_: ?*anyopaque, allocator: std.mem.Allocator, path: []const u8, _: usize) language.project.ReadError![]u8 {
        if (std.mem.eql(u8, path, "main.my")) return allocator.dupe(u8,
            \\module main
            \\import helper
            \\
            \\
            \\def main() -> int:
            \\    return helper.twice(20) + 2
        );
        if (std.mem.eql(u8, path, "helper.my")) return allocator.dupe(u8,
            \\module helper
            \\
            \\
            \\public def twice(n: int) -> int:
            \\    xs: list[int] = [n, n]
            \\    return xs[0] + xs[1]
        );
        return error.NotFound;
    }
};
/// The QBE a checked project emits, with its merged syntax released first or not.
fn emittedAfterCheck(release: bool) ![]u8 {
    var project = language.project.Project.init(testing.allocator);
    defer project.deinit();
    try project.load(.{ .context = null, .read = Modules.read }, "main", .{});
    var index = try language.interfaces.build(&project);
    var compilation = try language.project_compile.Compilation.init(&index);
    try compilation.check();
    if (release) compilation.releaseSyntax();
    try testing.expectEqual(!release, compilation.syntax.nodes.items.len != 0);
    return compilation.emitQbe(testing.allocator);
}
// spec: SYNTAX-RELEASE-1
test "a checked project lowers and emits the same program after its merged syntax is released" {
    const kept = try emittedAfterCheck(false);
    defer testing.allocator.free(kept);
    const released = try emittedAfterCheck(true);
    defer testing.allocator.free(released);
    try testing.expectEqualStrings(kept, released);
}
