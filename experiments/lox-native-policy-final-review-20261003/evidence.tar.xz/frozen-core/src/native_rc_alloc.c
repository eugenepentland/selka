#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#define _GNU_SOURCE
#include "native_rc_alloc.h"
#include "native_rc_internal.h"
#include "native_rc_values.h"
#include "native_arena.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

/* Slab addresses recover their metadata with one mask. Large reservations put
 * their metadata before (not inside) the frozen 32-byte RC object prefix.
 *
 * RC-ALLOC-CACHE-1: free slots live on per-class lists in the heap
 * (`heap->rc_cache.free`), which retirement pushes and every allocation,
 * including generated code's inline path, pops. A slab's own `free` list and
 * bump range hold the slots no class list holds; `live` counts the slots that
 * are allocated, queued for death or on a class list. A class list refills
 * from one slab at a time (its whole free list, or a run of bump slots), and
 * returns its slots to their slabs only when the budget refuses a reservation,
 * when fresh pool memory is needed while many bytes sit on the lists, or at
 * teardown, so empty slabs are still found and released. */
#define RC_SLAB_BYTES MYL_RC_SLAB_BYTES
#define RC_SLAB_CLASSES MYL_RC_CACHE_CLASSES
typedef struct rc_slab rc_slab;
typedef struct { rc_slab *previous, *next; } rc_slab_links;
struct rc_slab {
    myl_rc_slab_class class;
    rc_slab_links all, available;
    size_t used, live, capacity;
    void *free;
};
/* A refill threads at most this many bump bytes onto a class list at once. */
#define RC_REFILL_BYTES ((size_t)4096)
/* Listed bytes that make a fresh pool reservation return every listed slot to
 * its slab first: at least RC_TRIM_BYTES and a quarter of the reservation. */
#define RC_TRIM_BYTES ((size_t)1 << 20)
/* RC-LARGE-MAP-1: a large extent of at least RC_MAP_BYTES has an anonymous
 * mapping of its own, unmapped as soon as the extent is released. glibc would
 * raise its own mapping threshold to the largest block freed so far and then
 * keep freed blocks of that size resident in its heap. Smaller large extents
 * stay with calloc. `mapped` is the mapping's length, 0 for a calloc block. */
#define RC_MAP_BYTES ((size_t)128 << 10)
#define RC_MAP_PAGE ((size_t)4096)
typedef struct rc_large rc_large;
struct rc_large {
    rc_large *previous, *next;
    size_t charge, extent;
    size_t mapped, spare;
};
typedef struct {
    rc_slab *all, *available;
} rc_class;
/* Size classes for extents up to the largest stride, one byte per 16-byte step. */
#define RC_CLASS_STEPS (8192 / 16 + 1)
/* Slabs are carved from 2 MiB anonymous mappings, independent of malloc's
 * heap layout, so peak residency depends only on slab use. A freed slab keeps
 * its address range on the spare list; only the first RC_SPARE_RESIDENT stay
 * resident, the rest return their pages to the host. Mappings are released at
 * heap destruction. Slab budget charges are unchanged. */
#define RC_POOL_BYTES ((size_t)2 << 20)
#define RC_SPARE_RESIDENT 16
typedef struct rc_spare { struct rc_spare *next; } rc_spare;
/* The first RC_POOL_INLINE mappings are recorded inside the (charged) storage
 * record; a larger heap records the rest in a charged overflow array. */
#define RC_POOL_INLINE 64
typedef struct {
    unsigned char *next, *end;
    void *inline_mappings[RC_POOL_INLINE];
    void **overflow;
    size_t count, capacity;
    rc_spare *spare;
    size_t spare_count;
} rc_pools;
typedef struct {
    rc_class classes[RC_SLAB_CLASSES];
    rc_large *large;
    size_t reserved;
    struct { const myl_native_type *type; size_t index; } single;
    rc_pools pools;
} rc_storage;
static const size_t strides[RC_SLAB_CLASSES] = {
    16,32,48,64,80,96,112,128,160,192,224,256,320,384,448,512,
    640,768,896,1024,1280,1536,1792,2048,2560,3072,3584,4096,
    5120,6144,7168,8192
};
/* RC-CLASS-TABLE-1: the size class of every 16-byte step, one byte per step,
 * as a constant table: entry n is the least class whose stride holds n*16
 * bytes, exactly class_search(n * 16). Startup builds nothing, and no heap
 * carries a copy. */
static const unsigned char class_of[RC_CLASS_STEPS] = {
    0,0,1,2,3,4,5,6,7,8,8,9,9,10,10,11,11,12,12,12,12,13,13,13,13,14,14,14,14,15,15,15,
    15,16,16,16,16,16,16,16,16,17,17,17,17,17,17,17,17,18,18,18,18,18,18,18,18,19,19,19,19,19,19,19,
    19,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,
    21,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,
    23,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,
    24,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,
    25,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,
    26,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,
    27,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,
    28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,
    28,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,
    29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,
    29,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,
    30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,
    30,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,
    31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,
    31
};
#define RC_SLAB_OFFSET ((sizeof(rc_slab) + 15) & ~(size_t)15)
_Static_assert(RC_SLAB_OFFSET == 80, "cached capacity fits the existing aligned slab metadata extent");
_Static_assert(offsetof(rc_slab, class) == 0, "a slab starts with its class words");
_Static_assert((sizeof(rc_large) + MYL_RC_PREFIX_BYTES) % _Alignof(max_align_t) == 0, "large allocator metadata preserves alignment");
_Static_assert(sizeof(myl_rc_object) == MYL_RC_PREFIX_BYTES, "RC prefix ABI");
_Static_assert(offsetof(myl_rc_object, common) == 16, "common header ABI");
const myl_native_type myl_rc_pointer_leaf = {
    .size = sizeof(void *), .alignment = _Alignof(void *), .kind = MYL_NATIVE_POINTER, .rc_id = MYL_RC_ID_POINTER_LEAF
};
const myl_native_type myl_rc_octet_leaf = {.size = 1, .alignment = 1, .kind = MYL_NATIVE_PLAIN, .rc_id = MYL_RC_ID_OCTET_LEAF};
const myl_native_type myl_rc_word_leaf = {.size = 8, .alignment = 8, .kind = MYL_NATIVE_PLAIN, .rc_id = MYL_RC_ID_WORD_LEAF};
static const myl_native_type raw_type = {
    .size=1, .alignment=1, .kind=MYL_NATIVE_PLAIN, .trace_mode=MYL_NATIVE_TRACE_NONE,
    .rc_id=MYL_RC_ID_RAW
};
static const myl_rc_shape raw_shape = {.size=1,.kind=MYL_RC_SHAPE_NONE};
static const myl_rc_descriptor raw_descriptor = {.type=&raw_type,.shape=&raw_shape};
static const myl_rc_module raw_module = {
    .abi=MYL_RC_ABI_VERSION,.descriptors=&raw_descriptor,.descriptor_count=1
};
static rc_storage *storage_of(const myl_native_heap *heap) {
    myl_rc_invariant(heap && heap->rc);
    return heap->rc->allocator.context;
}
static int budget(myl_native_heap *heap, size_t bytes) {
    if (bytes>SIZE_MAX-heap->bytes || (heap->limit && (heap->bytes > heap->limit || bytes > heap->limit - heap->bytes))) {
        heap->exhausted=1;
        return 0;
    }
    return 1;
}
static void charge(myl_native_heap *heap, size_t bytes) {
    heap->bytes+=bytes;
    storage_of(heap)->reserved+=bytes;
}
static void discharge(myl_native_heap *heap, size_t bytes) {
    assert(heap->bytes>=bytes && storage_of(heap)->reserved>=bytes);
    heap->bytes-=bytes;
    storage_of(heap)->reserved-=bytes;
}
static void available_add(rc_class *class, rc_slab *slab) {
    slab->available=(rc_slab_links){.next=class->available};
    if (class->available) class->available->available.previous=slab;
    class->available=slab;
}
static void available_remove(rc_class *class, rc_slab *slab) {
    if (slab->available.previous) slab->available.previous->available.next=slab->available.next;
    else class->available=slab->available.next;
    if (slab->available.next) slab->available.next->available.previous=slab->available.previous;
    slab->available=(rc_slab_links){0};
}
static int slab_full(const rc_slab *slab) {
    return !slab->free && slab->used == slab->capacity;
}
/* One 64 KiB-aligned slab range: a spare first, else the current mapping. */
static void *range_take(myl_native_heap *heap) {
    rc_pools *pools=&storage_of(heap)->pools;
    if (pools->spare) {
        rc_spare *spare=pools->spare;
        pools->spare=spare->next;
        --pools->spare_count;
        return spare;
    }
    if (pools->next==pools->end) {
        if (pools->count>=RC_POOL_INLINE && pools->count-RC_POOL_INLINE==pools->capacity) {
            size_t capacity=pools->capacity?pools->capacity*2:RC_POOL_INLINE, bytes=capacity*sizeof(void *);
            if (!budget(heap,bytes-pools->capacity*sizeof(void *))) return NULL;
            void **grown=realloc(pools->overflow,bytes);
            if (!grown) return NULL;
            charge(heap,bytes-pools->capacity*sizeof(void *));
            pools->overflow=grown;
            pools->capacity=capacity;
        }
        unsigned char *raw=mmap(NULL,RC_POOL_BYTES+RC_SLAB_BYTES,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
        if (raw==MAP_FAILED) return NULL;
        unsigned char *start=(unsigned char *)(((uintptr_t)raw+RC_SLAB_BYTES-1)&~(uintptr_t)(RC_SLAB_BYTES-1));
        if (start!=raw) munmap(raw,(size_t)(start-raw));
        if (start+RC_POOL_BYTES!=raw+RC_POOL_BYTES+RC_SLAB_BYTES)
            munmap(start+RC_POOL_BYTES,(size_t)(raw+RC_POOL_BYTES+RC_SLAB_BYTES-(start+RC_POOL_BYTES)));
        if (pools->count<RC_POOL_INLINE) pools->inline_mappings[pools->count]=start;
        else pools->overflow[pools->count-RC_POOL_INLINE]=start;
        ++pools->count;
        pools->next=start;
        pools->end=start+RC_POOL_BYTES;
    }
    void *range=pools->next;
    pools->next+=RC_SLAB_BYTES;
    return range;
}
static void range_give(myl_native_heap *heap, void *range) {
    rc_pools *pools=&storage_of(heap)->pools;
    if (pools->spare_count>=RC_SPARE_RESIDENT)
        (void)madvise((unsigned char *)range+4096,RC_SLAB_BYTES-4096,MADV_DONTNEED);
    rc_spare *spare=range;
    spare->next=pools->spare;
    pools->spare=spare;
    ++pools->spare_count;
}
/* A slab is on its class's available list exactly while it has a free slot
 * or bump room of its own. */
static void slab_free(myl_native_heap *heap, rc_slab *slab) {
    rc_class *class=&storage_of(heap)->classes[slab->class.index];
    assert(!slab->live);
    if (!slab_full(slab)) available_remove(class,slab);
    if (slab->all.previous) slab->all.previous->all.next=slab->all.next;
    else class->all=slab->all.next;
    if (slab->all.next) slab->all.next->all.previous=slab->all.previous;
    discharge(heap,RC_SLAB_BYTES);
    range_give(heap,slab);
}
/* Return every slot on one class list to its slab, releasing each slab the
 * return empties. Only a return empties a slab: a slab's own free slots never
 * count as live, and a fresh slab is refilled from at once. */
static void cache_return(myl_native_heap *heap, size_t index) {
    rc_class *class=&storage_of(heap)->classes[index];
    myl_rc_object *object=heap->rc_cache.free[index];
    heap->rc_cache.free[index]=NULL;
    while (object) {
        myl_rc_object *next=(myl_rc_object *)object->retired_link;
        rc_slab *slab=(rc_slab *)((uintptr_t)object&~(uintptr_t)(RC_SLAB_BYTES-1));
        if (slab_full(slab)) available_add(class,slab);
        memcpy(object,&slab->free,sizeof slab->free);
        slab->free=object;
        assert(slab->live);
        if (!--slab->live) slab_free(heap,slab);
        object=next;
    }
}
/* Return every listed slot to its slab and release the slabs that empties;
 * the cost is the listed slots, bounded by the bytes retired since the last
 * trim. */
static void trim_empty(myl_native_heap *heap) {
    for (size_t i=0;i<RC_SLAB_CLASSES;i++) cache_return(heap,i);
    heap->rc_cache.pushed=0;
}
static int reserve(myl_native_heap *heap, size_t bytes) {
    if (bytes<=SIZE_MAX-heap->bytes && (!heap->limit || (heap->bytes<=heap->limit && bytes<=heap->limit-heap->bytes))) return 1;
    trim_empty(heap);
    return budget(heap,bytes);
}
static rc_slab *slab_new(myl_native_heap *heap, size_t index) {
    rc_pools *pools=&storage_of(heap)->pools;
    /* Fresh pool memory while many listed bytes wait: give them back first,
     * so a slab another class emptied is reused before new pages are touched. */
    if (!pools->spare && heap->rc_cache.pushed>=RC_TRIM_BYTES && heap->rc_cache.pushed>=storage_of(heap)->reserved/4)
        trim_empty(heap);
    if (!reserve(heap,RC_SLAB_BYTES)) return NULL;
    rc_slab *slab=range_take(heap);
    if (!slab) { trim_empty(heap); slab=range_take(heap); }
    if (!slab) return NULL;
    memset(slab,0,sizeof *slab);
    slab->class.stride=strides[index];
    slab->class.index=index;
    slab->capacity=(RC_SLAB_BYTES-RC_SLAB_OFFSET)/slab->class.stride;
    rc_class *class=&storage_of(heap)->classes[index];
    slab->all.next=class->all;
    if (class->all) class->all->all.previous=slab;
    class->all=slab;
    available_add(class,slab);
    charge(heap,RC_SLAB_BYTES);
    return slab;
}
static size_t class_search(size_t extent) {
    size_t low=0, high=RC_SLAB_CLASSES;
    while (low<high) {
        size_t middle=low+(high-low)/2;
        if (strides[middle]<extent) low=middle+1;
        else high=middle;
    }
    return low;
}
/* One table load for every slab-sized extent; larger extents are LARGE. */
static size_t class_for(const rc_storage *storage, size_t extent) {
    (void)storage;
    return extent<=strides[RC_SLAB_CLASSES-1]?class_of[(extent+15)/16]:RC_SLAB_CLASSES;
}
/* An empty class list takes one slab's slots: its whole free list, or else a
 * run of bump slots threaded in address order, each marked free. */
static __attribute__((noinline)) myl_rc_object *slab_refill(myl_native_heap *heap, size_t index) {
    rc_class *class=&storage_of(heap)->classes[index];
    rc_slab *slab=class->available;
    if (!slab) slab=slab_new(heap,index);
    if (!slab) return NULL;
    myl_rc_object *head;
    if (slab->free) {
        head=slab->free;
        slab->free=NULL;
        slab->live=slab->used;
    } else {
        size_t stride=slab->class.stride, room=slab->capacity-slab->used;
        size_t run=RC_REFILL_BYTES/stride;
        if (!run) run=1;
        if (run>room) run=room;
        unsigned char *first=(unsigned char *)slab+RC_SLAB_OFFSET+stride*slab->used;
        head=(myl_rc_object *)first;
        for (size_t i=0;i<run;i++) {
            myl_rc_object *slot=(myl_rc_object *)(first+i*stride);
            slot->retired_link=i+1<run?(uintptr_t)(first+(i+1)*stride):0;
            slot->common.mark=MYL_RC_RETIRED_MARK;
        }
        slab->used+=run;
        slab->live+=run;
    }
    if (slab_full(slab)) available_remove(class,slab);
    heap->rc_cache.free[index]=(void *)head->retired_link;
    return head;
}
/* One free slot of a slab class: pop its class list, refilling it when empty. */
static inline __attribute__((always_inline)) myl_rc_object *slab_take(myl_native_heap *heap, size_t index) {
    myl_rc_object *object=heap->rc_cache.free[index];
    if (!object) return slab_refill(heap,index);
    heap->rc_cache.free[index]=(void *)object->retired_link;
    return object;
}
/* One zeroed large block of `bytes`: its own mapping from RC_MAP_BYTES up. */
static __attribute__((noinline)) rc_large *large_block(size_t bytes) {
    if (bytes<RC_MAP_BYTES) return calloc(1,bytes);
    if (bytes>SIZE_MAX-RC_MAP_PAGE) return NULL;
    size_t length=(bytes+RC_MAP_PAGE-1)&~(RC_MAP_PAGE-1);
    void *mapping=mmap(NULL,length,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if (mapping==MAP_FAILED) return NULL;
    rc_large *large=mapping;
    large->mapped=length;
    return large;
}
static __attribute__((noinline)) void large_release(rc_large *large) {
    if (large->mapped) munmap(large,large->mapped);
    else free(large);
}
/* Grow a block to `bytes`, of which the first `previous` are in use. A mapping
 * grows in place or moves with mremap, and a calloc block that reaches
 * RC_MAP_BYTES moves into a mapping; the new tail of a mapping is zero. */
static __attribute__((noinline)) rc_large *large_grow(rc_large *large, size_t previous, size_t bytes) {
    if (!large->mapped && bytes<RC_MAP_BYTES) return realloc(large,bytes);
    if (!large->mapped) {
        rc_large *moved=large_block(bytes);
        if (!moved) return NULL;
        size_t length=moved->mapped;
        memcpy(moved,large,previous);
        moved->mapped=length;
        free(large);
        return moved;
    }
    if (bytes>SIZE_MAX-RC_MAP_PAGE) return NULL;
    size_t length=(bytes+RC_MAP_PAGE-1)&~(RC_MAP_PAGE-1);
    if (length<=large->mapped) return large;
    void *moved=mremap(large,large->mapped,length,MREMAP_MAYMOVE);
    if (moved==MAP_FAILED) return NULL;
    ((rc_large *)moved)->mapped=length;
    return moved;
}
static myl_rc_object *large_take(myl_native_heap *heap, size_t extent) {
    if (extent>SIZE_MAX-sizeof(rc_large)) return NULL;
    size_t bytes=sizeof(rc_large)+extent;
    if (!reserve(heap,bytes)) return NULL;
    rc_large *large=large_block(bytes);
    if (!large) { trim_empty(heap); large=large_block(bytes); }
    if (!large) return NULL;
    rc_storage *storage=storage_of(heap);
    *large=(rc_large){.next=storage->large,.charge=bytes,.extent=extent,.mapped=large->mapped};
    if (large->next) large->next->previous=large;
    storage->large=large;
    charge(heap,bytes);
    return (myl_rc_object *)(large+1);
}
/* The 32-byte prefix and slot stride preserve 16-byte payload alignment.
 * A short payload may clear its padding up to the next complete vector. */
typedef unsigned char rc_zero_unit __attribute__((vector_size(16), aligned(16), may_alias));
static inline void zero_payload(unsigned char *payload, size_t bytes) {
    rc_zero_unit *unit=(rc_zero_unit *)payload;
    const rc_zero_unit zero={0};
    switch ((bytes+15)/16) {
        case 8: unit[7]=zero; /* fall through */
        case 7: unit[6]=zero; /* fall through */
        case 6: unit[5]=zero; /* fall through */
        case 5: unit[4]=zero; /* fall through */
        case 4: unit[3]=zero; /* fall through */
        case 3: unit[2]=zero; /* fall through */
        case 2: unit[1]=zero; /* fall through */
        case 1: unit[0]=zero; /* fall through */
        case 0: return;
        default: memset(payload,0,bytes); return;
    }
}
/* Write the prefix of a fresh allocation. Only the payload needs zero bytes
 * (large extents arrive zeroed; slab callers zero first), and bytes past the
 * payload in a slab slot are never read. */
static void *initialize(myl_native_heap *heap, myl_rc_object *object,
                        const myl_native_type *element, size_t count, uintptr_t flags) {
    object->owners=1;
    object->holds=0;
    object->common=(myl_native_object){.mark=((uintptr_t)count<<MYL_NATIVE_OBJECT_COUNT_SHIFT)|flags,
        .element=element};
    heap->objects_live++;
    heap->allocations++;
    return object+1;
}
static myl_rc_status allocate(myl_native_heap *heap, const myl_rc_alloc_request *request, void **out) {
    *out=NULL;
    if (request->region) {
        *out=myl_native_arena_alloc(heap,request->element,request->count,request->region);
        return *out?MYL_RC_OK:MYL_RC_ALLOCATION_REFUSED;
    }
    if (!request->element || request->element->alignment>16 ||
        request->count>MYL_NATIVE_OBJECT_COUNT_MAX ||
        (request->element->size && request->count>(SIZE_MAX-MYL_RC_PREFIX_BYTES)/request->element->size))
        return MYL_RC_ALLOCATION_REFUSED;
    size_t extent=MYL_RC_PREFIX_BYTES+request->count*request->element->size;
    size_t index=class_for(storage_of(heap),extent);
    myl_rc_object *object=index<RC_SLAB_CLASSES?slab_take(heap,index):large_take(heap,extent);
    if (!object) return MYL_RC_ALLOCATION_REFUSED;
    if (index<RC_SLAB_CLASSES) zero_payload((unsigned char *)(object+1),extent-MYL_RC_PREFIX_BYTES);
    *out=initialize(heap,object,request->element,request->count,
        index==RC_SLAB_CLASSES?MYL_NATIVE_OBJECT_LARGE:0);
    return MYL_RC_OK;
}
/* The descriptor/type contract is immutable for the heap's lifetime. This
 * single-type cache stores only a completed registration and size-class proof,
 * never a slab address; trim, retirement and reentrant metadata registration
 * therefore cannot invalidate it. All other requests retain the generic hook. */
void *myl_rc_storage_alloc(myl_native_heap *heap, const myl_native_type *element, size_t count, unsigned region) {
    myl_rc_invariant(heap && heap->rc && element);
    if (!region && count==1 && heap->rc->allocator.hooks.allocate==allocate) {
        rc_storage *storage=storage_of(heap);
        size_t index;
        if (storage->single.type==element) index=storage->single.index;
        else {
            /* The binding carries its type's class; the one-entry cache then
             * follows the most recent type. */
            myl_rc_binding *binding=(myl_rc_binding *)myl_rc_binding_find(heap,element);
            if (binding && binding->alloc_class) index=binding->alloc_class-1;
            else {
                if (!myl_rc_native_shape(heap,element)) return NULL;
                if (element->alignment>16 || element->size>strides[RC_SLAB_CLASSES-1]-MYL_RC_PREFIX_BYTES)
                    goto registered;
                index=class_for(storage,MYL_RC_PREFIX_BYTES+element->size);
                binding=(myl_rc_binding *)myl_rc_binding_find(heap,element);
                binding->alloc_class=(unsigned)index+1;
            }
            storage->single.type=element;
            storage->single.index=index;
        }
        myl_rc_object *object=slab_take(heap,index);
        if (!object) { myl_rc_record_failure(heap,MYL_RC_ALLOCATION_REFUSED); return NULL; }
        zero_payload((unsigned char *)(object+1),element->size);
        void *payload=initialize(heap,object,element,1,0);
        MYL_RC_STAT(heap,MYL_RC_STAT_HEAP_ALLOCATE);
        return payload;
    }
    if (heap->rc->plain!=element && !myl_rc_native_shape(heap,element)) return NULL;
    /* RC-ALLOC-CACHE-1: a registered slab-sized run of elements (a text's or
     * list backing's octets, say) takes its class's free list directly. */
    if (!region && count>1 && element->size && element->alignment<=16 && heap->rc->allocator.hooks.allocate==allocate &&
        count<=(strides[RC_SLAB_CLASSES-1]-MYL_RC_PREFIX_BYTES)/element->size) {
        size_t bytes=count*element->size;
        myl_rc_object *object=slab_take(heap,class_for(storage_of(heap),MYL_RC_PREFIX_BYTES+bytes));
        if (!object) { myl_rc_record_failure(heap,MYL_RC_ALLOCATION_REFUSED); return NULL; }
        zero_payload((unsigned char *)(object+1),bytes);
        void *payload=initialize(heap,object,element,count,0);
        MYL_RC_STAT(heap,MYL_RC_STAT_HEAP_ALLOCATE);
        return payload;
    }
registered:;
    myl_rc_alloc_request request={element,count,region};
    void *result=NULL;
    myl_rc_status status=myl_rc_new(heap,&request,&result);
    if (status!=MYL_RC_OK) myl_rc_record_failure(heap,status);
    return result;
}
/* Saturation disables weak absence caching permanently; it never wraps back
 * to a cached epoch that could name a previous allocation at the same address. */
static void reuse_epoch(myl_native_heap *heap) {
    if (heap->collections!=SIZE_MAX) heap->collections++;
}
/* The retire hook: a slab slot goes on its class list; a large extent is freed. */
void myl_rc_storage_retire(myl_native_heap *heap, void *payload) {
    myl_rc_object *object=(myl_rc_object *)payload-1;
    assert(object->common.mark&MYL_RC_OBJECT_DYING);
    if (!(object->common.mark&MYL_NATIVE_OBJECT_LARGE)) { myl_rc_cache_push(heap,object); return; }
    reuse_epoch(heap);
    assert(heap->objects_live);
    heap->objects_live--;
    rc_large *large=(rc_large *)object-1;
    if (large->previous) large->previous->next=large->next;
    else storage_of(heap)->large=large->next;
    if (large->next) large->next->previous=large->previous;
    discharge(heap,large->charge);
    large_release(large);
}
/* Give every listed slot back to its slab's live count, emptying the lists,
 * before the slabs themselves are released wholesale. */
static void cache_discard(myl_native_heap *heap) {
    for (size_t i=0;i<RC_SLAB_CLASSES;i++) {
        for (myl_rc_object *object=heap->rc_cache.free[i];object;object=(myl_rc_object *)object->retired_link) {
            rc_slab *slab=(rc_slab *)((uintptr_t)object&~(uintptr_t)(RC_SLAB_BYTES-1));
            assert(slab->live);
            slab->live--;
        }
        heap->rc_cache.free[i]=NULL;
    }
    heap->rc_cache.pushed=0;
}
static void destroy(myl_native_heap *heap) {
    rc_storage *storage=storage_of(heap);
    assert(!storage->large);
    cache_discard(heap);
    for (size_t i=0;i<RC_SLAB_CLASSES;i++) {
        while (storage->classes[i].all) slab_free(heap,storage->classes[i].all);
    }
    for (size_t i=0;i<storage->pools.count;i++)
        munmap(i<RC_POOL_INLINE?storage->pools.inline_mappings[i]:storage->pools.overflow[i-RC_POOL_INLINE],RC_POOL_BYTES);
    discharge(heap,storage->pools.capacity*sizeof(void *));
    free(storage->pools.overflow);
    assert(storage->reserved==sizeof *storage);
    discharge(heap,sizeof *storage);
    free(storage);
}
static void teardown(myl_native_heap *);
static const myl_rc_allocator allocator={allocate,myl_rc_storage_retire,destroy,teardown};
/* The storage walks behind the public teardown API. The allocator's own
 * teardown hook calls them directly: reaching it proves the storage is this
 * allocator's even while a fault-injection probe wraps the allocate hook. */
static void visit_extents(myl_native_heap *heap, myl_rc_extent_visitor visit, void *context) {
    rc_storage *storage=storage_of(heap);
    for (size_t i=0;i<RC_SLAB_CLASSES;i++)
        for (rc_slab *slab=storage->classes[i].all;slab;slab=slab->all.next) {
            unsigned char *slot=(unsigned char *)slab+RC_SLAB_OFFSET;
            for (size_t used=slab->used;used;--used,slot+=slab->class.stride) {
                myl_rc_object *object=(myl_rc_object *)slot;
                if (object->common.mark!=MYL_RC_RETIRED_MARK) visit(heap,object+1,context);
            }
        }
    for (rc_large *large=storage->large;large;large=large->next)
        visit(heap,(myl_rc_object *)(large+1)+1,context);
}
void myl_rc_storage_visit(myl_native_heap *heap, myl_rc_extent_visitor visit, void *context) {
    myl_rc_invariant(heap && heap->rc && heap->rc->allocator.hooks.allocate==allocate && visit);
    visit_extents(heap,visit,context);
}
static void release_extents(myl_native_heap *heap) {
    myl_rc_invariant(!heap->rc->dead.active && !heap->rc->walk.depth);
    rc_storage *storage=storage_of(heap);
    cache_discard(heap);
    size_t released=0;
    while (storage->large) {
        rc_large *large=storage->large;
        storage->large=large->next;
        discharge(heap,large->charge);
        large_release(large);
        ++released;
    }
    for (size_t i=0;i<RC_SLAB_CLASSES;i++)
        while (storage->classes[i].all) {
            rc_slab *slab=storage->classes[i].all;
            released+=slab->live;
            slab->live=0;
            slab_free(heap,slab);
        }
    myl_rc_invariant(heap->objects_live>=released &&
        storage->reserved==sizeof *storage+storage->pools.capacity*sizeof(void *));
    heap->objects_live-=released;
    heap->rc->dead.head=NULL;
    reuse_epoch(heap);
}
void myl_rc_storage_release_all(myl_native_heap *heap) {
    myl_rc_invariant(heap && heap->rc && heap->rc->allocator.hooks.allocate==allocate);
    release_extents(heap);
}
#if defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING
/* A counting build retires each remaining object during trap teardown and
 * releases its outstanding owners and holds, so a trapping run balances. A
 * dying object's counts were already released when it was queued. */
static void teardown_count(myl_native_heap *heap, void *payload, void *context) {
    (void)context;
    const myl_rc_object *object=(const myl_rc_object *)payload-1;
    MYL_RC_STAT(heap,MYL_RC_STAT_RETIRE);
    if (object->common.mark&MYL_RC_OBJECT_DYING) return;
    MYL_RC_STAT_MANY(heap,MYL_RC_STAT_OWNER_RELEASE,object->owners);
    MYL_RC_STAT_MANY(heap,MYL_RC_STAT_HOLD_RELEASE,object->holds);
}
#endif
/* Trap teardown (see myl_rc_allocator.teardown): every slab, pool range and
 * large extent goes back at once; nothing is walked, finalized or drained. */
static void teardown(myl_native_heap *heap) {
#if defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING
    visit_extents(heap,teardown_count,NULL);
#endif
    release_extents(heap);
}
myl_rc_status myl_rc_storage_init(myl_native_heap *heap) {
    if (!budget(heap,sizeof(rc_storage))) return MYL_RC_ALLOCATION_REFUSED;
    rc_storage *storage=calloc(1,sizeof *storage);
    if (!storage) return MYL_RC_ALLOCATION_REFUSED;
    heap->bytes+=sizeof *storage;
    storage->reserved=sizeof *storage;
    if (MYL_RC_CHECKED) {
        static int verified;
        if (!verified) {
            for (size_t step=0;step<RC_CLASS_STEPS;step++) myl_rc_invariant(class_of[step]==class_search(step*16));
            verified=1;
        }
    }
    myl_rc_status status=myl_rc_heap_init(heap,&allocator,storage);
    if (status!=MYL_RC_OK) { heap->bytes-=sizeof *storage; free(storage); return status; }
    status=myl_rc_module_register(heap,&raw_module);
    if (status!=MYL_RC_OK) myl_rc_heap_destroy(heap);
    return status;
}
/* Raw bytes are registered at initialization and own no edges, so a slab-sized
 * heap request needs none of myl_rc_new's metadata or region admission. A
 * block (zero == 0) leaves its payload unwritten: its caller writes every octet
 * it reads (GC-NOZERO-1). Everything else takes the generic hook. */
static void *raw_bytes(myl_native_heap *heap, size_t bytes, unsigned region, int zero) {
    myl_rc_invariant(heap && heap->rc);
    if (!region && heap->rc->allocator.hooks.allocate==allocate && bytes<=strides[RC_SLAB_CLASSES-1]-MYL_RC_PREFIX_BYTES) {
        myl_rc_object *object=slab_take(heap,class_for(storage_of(heap),MYL_RC_PREFIX_BYTES+bytes));
        if (!object) { myl_rc_record_failure(heap,MYL_RC_ALLOCATION_REFUSED); return NULL; }
        if (zero) zero_payload((unsigned char *)(object+1),bytes);
        void *payload=initialize(heap,object,&raw_type,bytes,0);
        MYL_RC_STAT(heap,MYL_RC_STAT_HEAP_ALLOCATE);
        return payload;
    }
    void *result=NULL;
    myl_rc_alloc_request request={&raw_type,bytes,region};
    myl_rc_status status=myl_rc_new(heap,&request,&result);
    if (status!=MYL_RC_OK) myl_rc_record_failure(heap,status);
    return result;
}
void *myl_rc_storage_bytes(myl_native_heap *heap, size_t bytes, unsigned region) {
    return raw_bytes(heap,bytes,region,1);
}
void *myl_rc_storage_block(myl_native_heap *heap, size_t bytes, unsigned region) {
    return raw_bytes(heap,bytes,region,0);
}
static void *storage_extend(myl_native_heap *heap, void *payload, size_t count, int zero);
void *myl_rc_storage_extend(myl_native_heap *heap, void *payload, size_t count) {
    return storage_extend(heap,payload,count,1);
}
/* RC-OPAQUE-EXTEND-1: the caller proved no release or drop ever walks the
 * block's bytes as owning slots (a plain element with an empty flat plan), so
 * the new capacity is left unwritten, exactly as the collector's opaque
 * extension: every element is written before a reader can reach it. */
void *myl_rc_storage_extend_opaque(myl_native_heap *heap, void *payload, size_t count) {
    return storage_extend(heap,payload,count,0);
}
static void *storage_extend(myl_native_heap *heap, void *payload, size_t count, int zero) {
    if (!payload) return NULL;
    myl_native_object *common=(myl_native_object *)payload-1;
    if (common->mark&(MYL_NATIVE_OBJECT_IMMORTAL|MYL_NATIVE_OBJECT_ARENA|MYL_RC_OBJECT_DYING)) return NULL;
    myl_rc_object *object=(myl_rc_object *)payload-1;
    if (!(common->mark&MYL_NATIVE_OBJECT_LARGE) || object->owners!=1 || object->holds ||
        (common->mark&MYL_NATIVE_OBJECT_PINNED) || count>MYL_NATIVE_OBJECT_COUNT_MAX ||
        !common->element->size || count>(SIZE_MAX-MYL_RC_PREFIX_BYTES-sizeof(rc_large))/common->element->size)
        return NULL;
    rc_large *large=(rc_large *)object-1;
    size_t extent=MYL_RC_PREFIX_BYTES+count*common->element->size;
    if (extent<=large->extent) return NULL;
    size_t bytes=sizeof *large+extent, growth=bytes-large->charge;
    if (!reserve(heap,growth)) return NULL;
    size_t previous=large->charge;
    rc_large *grown=large_grow(large,previous,bytes);
    if (!grown) return NULL;
    if (zero && !grown->mapped) memset((unsigned char *)grown+previous,0,growth);
    if (grown->previous) grown->previous->next=grown;
    else storage_of(heap)->large=grown;
    if (grown->next) grown->next->previous=grown;
    grown->charge=bytes;
    grown->extent=extent;
    object=(myl_rc_object *)(grown+1);
    object->common.mark=(object->common.mark&~MYL_NATIVE_OBJECT_COUNT_BITS)|((uintptr_t)count<<MYL_NATIVE_OBJECT_COUNT_SHIFT);
    charge(heap,growth);
    reuse_epoch(heap);
    return object+1;
}
size_t myl_rc_storage_reserved(const myl_native_heap *heap) {
    return storage_of(heap)->reserved;
}
