//! Checked instruction model independent of validation and effect inference.
const external_resources = @import("external_resources.zig");
const std = @import("std");
const Span = @import("source.zig").Span;
const typed = @import("typed.zig");
const external_capabilities = @import("external_capabilities.zig");
/// Signed scalar ordering and equality predicates.
pub const Predicate = enum { eq, ne, lt, le, gt, ge };
/// Equality predicates for boolean and nominal identity values.
pub const Equality = enum { eq, ne };
/// Destination and optional payload local for one variant case.
pub const SwitchArm = struct { target: usize, slot: ?typed.LocalId };
/// Which inlined callee one spliced instruction came from. `callee` is the
/// directly spliced function, `callee_pc` its local program counter and
/// `call_position` the pc in the function that owns the instruction whose
/// location entry is the call site. The emitter groups consecutive instructions
/// sharing a callee and call site into one inline-frame record.
pub const InlineOrigin = struct { callee: typed.FunctionId, callee_pc: usize, call_position: usize };
/// An element read or replace: the receiver type, and whether a fixed array
/// first counts a negative index back from its end (`PY-ARRAY-NEGATIVE-1`).
/// Managed receivers normalize their own indices and ignore `from_end`.
pub const Access = struct { ty: typed.Type, from_end: bool = false };
/// Source-located operation in the checked instruction stream.
pub const Instruction = struct {
    span: Span,
    op: union(enum) {
        try_result: struct { input: typed.Type, output: typed.Type, error_target: usize },
        push_i64: i64,
        push_bool: bool,
        push_unit,
        push_integer: struct { ty: typed.Type, value: i128 },
        cast_integer: typed.Type,
        wrap_domain: typed.Type,
        make_variant: struct { ty: typed.Type, tag: usize },
        switch_variant: struct { ty: typed.Type, arms: []const SwitchArm, borrowed: bool = false },
        cmp_domain: struct { ty: typed.Type, predicate: Equality },
        cmp_enum: struct { ty: typed.Type, predicate: Equality },
        unwrap_domain: typed.Type,
        neg_integer: typed.Type,
        binary_integer: struct { ty: typed.Type, op: typed.BinaryOp },
        /// A `str`/`bytes` literal whose every element is a constant carries its
        /// whole content as `payload` (UTF-8 octets for `str`, raw octets for
        /// `bytes`) and has `fields == 0`: it pops nothing, so a literal is one
        /// instruction and one stack slot however long it is (`LITERAL-PAYLOAD-1`).
        /// `blob` instead names the embedded file (`EMBED-1`) that is the whole
        /// payload of a `bytes`/`str` record; such a record also pops no operands.
        make_record: struct { ty: typed.Type, fields: usize, order: []const usize = &.{}, payload: []const u8 = &.{}, blob: ?*const typed.Blob = null },
        update_record: struct { ty: typed.Type, indices: []const usize },
        get_field: usize,
        get_index: Access,
        replace_index: Access,
        array_length: typed.Type,
        begin_arena: typed.LocalId,
        end_arena: typed.LocalId,
        arena_escape: typed.Type,
        buffer_operation: struct { kind: @import("buffer_operations.zig").Kind, owner: typed.LocalId, output: typed.Type },
        complete_resource: typed.Type,
        acquire_resource: struct { output: typed.Type, request: typed.Type },
        resource_io: struct { kind: external_resources.IoKind, owner: typed.LocalId, output: typed.Type, input: ?typed.Type },
        restrict_resource: struct { permissions: external_resources.Permissions, ty: typed.Type },
        dir_resource: struct { output: typed.Type, path: typed.Type },
        host_resource: struct { output: typed.Type, name: typed.Type },
        environment_get: struct { output: typed.Type, name: typed.Type },
        environment_only: struct { output: typed.Type, names: typed.Type },
        environment_names: struct { output: typed.Type },
        external_read: struct { kind: external_capabilities.Kind, output: typed.Type },
        /// Pops `kind.operands()` words and pushes a stand-in capability or a status.
        stand_in: external_capabilities.StandIn,
        acquire_buffer: typed.Type,
        print: Print,
        stream_write: StreamWrite,
        file_access: FileAccess,
        file_method: FileMethod,
        move_local: typed.LocalId,
        drop_local: typed.LocalId,
        load_local: typed.LocalId,
        /// Push the address of a local's own storage rather than its value: the
        /// argument a `mut` fixed-array parameter receives, which the callee
        /// writes the caller's array through.
        ref_local: typed.LocalId,
        store_local: typed.LocalId,
        add_i64_checked,
        sub_i64_checked,
        mul_i64_checked,
        div_i64_checked,
        rem_i64_checked,
        neg_i64_checked,
        unary_float: typed.UnaryOp,
        cmp_i64: Predicate,
        cmp_bool: Equality,
        not_bool,
        /// The trap kind is explicit; user messages cannot select a contract code.
        assert_true: struct { message: []const u8, kind: typed.AssertionKind = .statement },
        pop,
        acknowledge: typed.Type,
        jump: usize,
        jump_if_false: usize,
        function_value: struct { ty: typed.Type, function: typed.FunctionId },
        invoke: typed.Type,
        call: typed.FunctionId,
        ret,
        /// VALUE-SEMANTICS-2: the top operand moves to a second home under
        /// value semantics. The native emitter makes it an independent copy
        /// unless the ownership analysis proves the transfer a move or a borrow
        /// (`ownership_values.zig`). Never emitted with the switch off.
        value_copy: ValueCopy,
    },
    /// Set exactly on an instruction spliced from an inlined callee, so the
    /// native emitter can rebuild the callee's frames for a trap trace.
    inline_origin: ?InlineOrigin = null,
};
/// Which transfer a value-semantics copy stands for. `assign` stores into a
/// named local, `store` into a field, element, dictionary value or payload,
/// `ret` returns, `payload` rebinds a match arm's payload: the ownership
/// analysis may prove any of these a move or a borrow. `argument` is a
/// read-only argument a `mut` argument of the same call could reach, and
/// `children` copies the elements of a fresh shallow copy: both always copy.
pub const CopySite = enum(u8) { assign, store, ret, payload, argument, children };
/// One value-semantics copy of an operand of type `ty`.
pub const ValueCopy = struct { ty: typed.Type, site: CopySite };
/// Whole-path file helper; operands are the capability, the path and any input.
pub const FileAccess = struct { kind: @import("file_operations.zig").Access, mode: u8, text: bool, operands: usize, output: typed.Type, shapes: typed.FileShapes };
/// Method on an open handle held in a local slot, with one optional operand.
pub const FileMethod = struct { kind: @import("file_operations.zig").Method, owner: typed.LocalId, text: bool, argument: bool, output: typed.Type, shapes: typed.FileShapes };
/// Static argument types and whether explicit `sep=`/`end=` operands follow them.
/// `stream` puts the receiver value at the stack bottom; `debug` writes to stderr.
pub const Print = struct { sink: typed.Sink = .stdout, types: []const typed.Type, separator: bool, terminator: bool, stream: bool = false, debug: bool = false };
/// `stream.write(text)`: a stream value and text operand are on the stack.
pub const StreamWrite = struct { stream: typed.Type, text: typed.Type };
/// Checked function signature, locals, and instruction body.
/// Finalized caller-visible facts of a physical body supplied by another module.
pub const Physical = struct { stable: []const bool = &.{}, unknown: bool = false };
/// Checked function signature, locals, instructions and optional imported facts.
pub const Function = struct {
    physical: ?*const Physical = null,
    policy: typed.FunctionPolicy = .{},
    signature: typed.FunctionSignature = .{},
    scope: FunctionScope,
    id: typed.FunctionId,
    name: []const u8,
};
/// Lowered instructions and the checked lexical local table they address.
pub const FunctionScope = struct {
    locals: []const typed.Local = &.{},
    instructions: []const Instruction,
};
/// Complete instruction program and its nominal type metadata.
pub const Program = struct { functions: []const Function, main: typed.FunctionId = @fromBackingInt(0), records: []const typed.Record = &.{} };
/// The value a stand-in operation pushes: the capability it builds, or the
/// `int` status of moving a simulated clock.
pub fn standInOutput(kind: external_capabilities.StandIn) typed.Type {
    return switch (kind) {
        .clock => .clock_cap,
        .entropy => .random_cap,
        .filesystem => .filesystem_cap,
        .network => .network_cap,
        .environment => .environment_cap,
        .advance => .i64,
    };
}
/// Count stack-passed value arguments.
pub fn valueParameterCount(function: Function) usize {
    return function.signature.parameter_count;
}
