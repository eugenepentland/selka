//! Region allocation of ordinary managed objects: `with arena() as name:` scopes,
//! dynamic allocation redirection, the store barrier, copy-out through `escape`,
//! bulk release accounting, and the static escape rejections.
const std = @import("std");
const t = std.testing;
const language = @import("compiler.zig");
const native = @import("native_execute.zig");
const values = @import("runtime_values.zig");

const list_type: values.Type = @fromBackingInt(@intCast(32));
const record_type: values.Type = @fromBackingInt(@intCast(33));
const module = "arena-managed.my";

fn run(text: []const u8, stress: bool) !native.Run {
    var compilation = try language.Compilation.init(t.allocator, module, text);
    defer compilation.deinit();
    return native.runWithOptions(&compilation, .{ .gc_stress = stress }) catch |err| {
        if (err != error.OutOfMemory) @import("diagnostics_test.zig").report(compilation.diagnostics.items);
        return err;
    };
}

fn value(text: []const u8) !i64 {
    const outcome = try run(text, false);
    try t.expectEqualStrings("", outcome.trap.code);
    return outcome.value;
}

fn reject(text: []const u8, code: []const u8) !void {
    var compilation = try language.Compilation.init(t.allocator, module, text);
    defer compilation.deinit();
    try t.expectError(error.SourceError, compilation.check());
    try t.expectEqualStrings(code, compilation.diagnostics.items[0].code);
}

const build =
    \\def build(limit: int) -> list[int]:
    \\    items: list[int] = []
    \\    for index in range(limit):
    \\        items.append(index)
    \\    return items
    \\
;

// spec-case: ARENA-MANAGED-1
test "ARENA-MANAGED-1 nested arenas redirect helper allocation and release each scope in bulk" {
    const source = build ++
        \\def main() -> int:
        \\    total = 0
        \\    with arena() as outer:
        \\        first = build(3)
        \\        with arena() as inner:
        \\            second = build(4)
        \\            total = total + len(second)
        \\        total = total + len(first)
        \\    return total
    ;
    try t.expectEqual(@as(i64, 7), try value(source));
}

// spec-case: ARENA-MANAGED-1
test "ARENA-MANAGED-1 an anonymous arena scope still bulk releases its allocations" {
    const source = build ++
        \\def main() -> int:
        \\    total = 0
        \\    with arena():
        \\        total = len(build(5))
        \\    return total
    ;
    try t.expectEqual(@as(i64, 5), try value(source));
}

// spec-case: ARENA-MANAGED-2
test "ARENA-MANAGED-2 escape copies a shared subgraph once into the enclosing region" {
    const source =
        \\def main() -> int:
        \\    kept: list[list[int]] = []
        \\    with arena() as scratch:
        \\        shared: list[int] = [7]
        \\        holder: list[list[int]] = [shared, shared]
        \\        kept = scratch.escape(holder)
        \\    return len(kept) * 10 + kept[0][0] + kept[1][0]
    ;
    try t.expectEqual(@as(i64, 34), try value(source));
}

// spec-case: ARENA-MANAGED-2
test "ARENA-MANAGED-2 escape preserves a cycle through a record field" {
    const legacy = @import("test_support.zig").LegacySharing.enter();
    defer legacy.restore();
    const source =
        \\record Node:
        \\    value: int
        \\    links: list[Node]
        \\
        \\def main() -> int:
        \\    kept: list[Node] = []
        \\    with arena() as scratch:
        \\        nodes: list[Node] = []
        \\        nodes.append(Node(value=5, links=nodes))
        \\        kept = scratch.escape(nodes)
        \\    return kept[0].value + len(kept[0].links)
    ;
    const outcome = try run(source, true);
    try t.expectEqual(@as(i64, 6), outcome.value);
}

// spec-case: ARENA-MANAGED-2
test "ARENA-MANAGED-2 an escaped copy may be returned from the outermost arena scope" {
    const source = build ++
        \\def solve(limit: int) -> list[int]:
        \\    with arena() as scratch:
        \\        working = build(limit)
        \\        return scratch.escape(working)
        \\
        \\def main() -> int:
        \\    kept = solve(6)
        \\    return len(kept) * 10 + kept[5]
    ;
    try t.expectEqual(@as(i64, 65), try value(source));
}

// spec-case: ARENA-MANAGED-2
test "ARENA-MANAGED-2 escape shares objects that already live in the enclosing region" {
    const legacy = @import("test_support.zig").LegacySharing.enter();
    defer legacy.restore();
    const source =
        \\def main() -> int:
        \\    older: list[int] = [4]
        \\    kept: list[list[int]] = []
        \\    with arena() as scratch:
        \\        holder: list[list[int]] = [older]
        \\        kept = scratch.escape(holder)
        \\    older.append(5)
        \\    return len(kept[0]) * 10 + kept[0][1]
    ;
    try t.expectEqual(@as(i64, 25), try value(source));
}

// spec: ARENA-MANAGED-3
test "ARENA-MANAGED-3 the store barrier traps when a helper stores arena storage outward" {
    const source =
        \\def stash(outer: mut list[list[int]], inner: list[int]) -> None:
        \\    outer.append(inner)
        \\
        \\def main() -> int:
        \\    keeper: list[list[int]] = []
        \\    with arena() as scratch:
        \\        temp: list[int] = [1]
        \\        stash(mut keeper, temp)
        \\    return len(keeper)
    ;
    const outcome = try run(source, false);
    try t.expectEqualStrings("R_ARENA_ESCAPE", outcome.trap.code);
}

// spec-case: ARENA-MANAGED-3
test "ARENA-MANAGED-3 the store barrier covers dictionary values written through a helper" {
    const source =
        \\def stash(outer: mut dict[int, list[int]], inner: list[int]) -> None:
        \\    outer[1] = inner
        \\
        \\def main() -> int:
        \\    keeper: dict[int, list[int]] = {}
        \\    with arena() as scratch:
        \\        stash(mut keeper, [3])
        \\    return 0
    ;
    const outcome = try run(source, false);
    try t.expectEqualStrings("R_ARENA_ESCAPE", outcome.trap.code);
}

// spec: ARENA-MANAGED-4
test "ARENA-MANAGED-4 static rejections name the escaping expression the arena and the binding" {
    const legacy = @import("test_support.zig").LegacySharing.enter();
    defer legacy.restore();
    try reject(
        \\def main() -> int:
        \\    keeper: list[int] = []
        \\    with arena() as scratch:
        \\        keeper = [1, 2]
        \\    return len(keeper)
    , "E_ARENA_ESCAPE");
    try reject(
        \\def solve() -> list[int]:
        \\    with arena() as scratch:
        \\        return [1, 2]
        \\
        \\def main() -> int:
        \\    return len(solve())
    , "E_ARENA_ESCAPE");
    try reject(
        \\def main() -> int:
        \\    keeper: list[list[int]] = []
        \\    with arena() as scratch:
        \\        keeper.append([1])
        \\    return 0
    , "E_ARENA_ESCAPE");
    try reject(
        \\def main() -> int:
        \\    keeper: list[list[int]] = [[0]]
        \\    with arena() as scratch:
        \\        keeper[0] = [1]
        \\    return 0
    , "E_ARENA_ESCAPE");
    try reject(
        \\def main() -> int:
        \\    counts: dict[int, list[int]] = {}
        \\    with arena() as scratch:
        \\        counts[1] = [1]
        \\    return 0
    , "E_ARENA_ESCAPE");
    try reject(
        \\class Box:
        \\    items: list[int]
        \\
        \\def main() -> int:
        \\    box = Box(items=[])
        \\    with arena() as scratch:
        \\        box.items = [1]
        \\    return 0
    , "E_ARENA_ESCAPE");
}

// spec-case: ARENA-MANAGED-4
test "ARENA-MANAGED-4 an arena binding is opaque and cannot be stored passed or renamed" {
    try reject(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        alias = scratch
        \\    return 0
    , "E_ARENA_BINDING");
    try reject(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        scratch.reset()
        \\    return 0
    , "E_ARENA_BINDING");
    try reject(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        scratch = 1
        \\    return 0
    , "E_SHADOWING");
    try reject(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        with arena() as inner:
        \\            keep = scratch.escape([1])
        \\    return 0
    , "E_ARENA_ESCAPE");
}

// spec-case: ARENA-MANAGED-4
test "ARENA-MANAGED-4 the escape rejection renders complete JSON provenance" {
    const source =
        \\def main() -> int:
        \\    keeper: list[int] = []
        \\    with arena() as scratch:
        \\        keeper = [1, 2]
        \\    return len(keeper)
    ;
    var compilation = try language.Compilation.init(t.allocator, module, source);
    defer compilation.deinit();
    try t.expectError(error.SourceError, compilation.check());
    const json = try language.diagnostic_output.render(t.allocator, compilation.diagnostics.items[0], compilation.src, .json);
    defer t.allocator.free(json);
    var parsed = try std.json.parseFromSlice(std.json.Value, t.allocator, json, .{});
    defer parsed.deinit();
    const data = parsed.value.object.get("diagnostic").?;
    try t.expectEqualStrings("E_ARENA_ESCAPE", data.object.get("code").?.string);
    try t.expectEqualStrings(
        "`[1, 2]` is assigned to `keeper`, which outlives arena `scratch`; assign `scratch.escape(...)` instead",
        data.object.get("message").?.string,
    );
    const notes = data.object.get("notes").?.array.items;
    try t.expectEqual(@as(usize, 2), notes.len);
    try t.expectEqualStrings("arena scope opened here", notes[0].object.get("message").?.string);
    try t.expectEqualStrings("value declared here", notes[1].object.get("message").?.string);
}

// spec-case: ARENA-MANAGED-5
test "ARENA-MANAGED-5 result propagation out of an arena releases its storage in bulk" {
    const source =
        \\def risky(flag: int) -> Result[int, int]:
        \\    if flag == 0:
        \\        return Err(7)
        \\    return Ok(flag)
        \\
        \\def solve(flag: int) -> Result[int, int]:
        \\    with arena() as scratch:
        \\        items: list[int] = [1, 2, 3]
        \\        checked = risky(flag)?
        \\        return Ok(checked + len(items))
        \\
        \\def main() -> int:
        \\    match solve(0):
        \\        case Ok(found):
        \\            return found
        \\        case Err(code):
        \\            return code
    ;
    try t.expectEqual(@as(i64, 7), try value(source));
}

// spec-case: ARENA-MANAGED-5
test "ARENA-MANAGED-5 a trap inside an arena releases its storage before execution teardown" {
    const source =
        \\def divide(left: int, right: int) -> int:
        \\    return left // right
        \\
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        items: list[int] = [1, 2]
        \\        return divide(len(items), 0)
    ;
    const outcome = try run(source, false);
    try t.expectEqualStrings("R_DIVISION_BY_ZERO", outcome.trap.code);
}

// spec-case: ARENA-MANAGED-5
test "ARENA-MANAGED-5 break and continue out of an arena close the scope exactly once" {
    const source = build ++
        \\def main() -> int:
        \\    total = 0
        \\    for round in range(4):
        \\        with arena() as scratch:
        \\            total = total + len(build(2))
        \\            if round == 0:
        \\                continue
        \\            if round == 2:
        \\                break
        \\    return total
    ;
    try t.expectEqual(@as(i64, 6), try value(source));
}

// spec-case: ARENA-MANAGED-6
test "ARENA-MANAGED-6 stress collection inside an arena preserves its values until bulk release" {
    const source =
        \\def waste() -> int:
        \\    temp: list[int] = [1, 2, 3]
        \\    return len(temp)
        \\
        \\def main() -> int:
        \\    total = 0
        \\    with arena() as scratch:
        \\        total = waste()
        \\        total = total + waste()
        \\    return total
    ;
    const outcome = try run(source, true);
    try t.expectEqual(@as(i64, 6), outcome.value);
}

fn escapeScenario(allocator: std.mem.Allocator) !void {
    const source =
        \\record Node:
        \\    value: int
        \\    links: list[Node]
        \\
        \\def grow(count: int) -> list[Node]:
        \\    nodes: list[Node] = []
        \\    for index in range(count):
        \\        nodes.append(Node(value=index, links=nodes))
        \\    return nodes
        \\
        \\def main() -> int:
        \\    kept: list[Node] = []
        \\    with arena() as scratch:
        \\        kept = scratch.escape(grow(4))
        \\    return len(kept) + kept[3].value
    ;
    var compilation = try language.Compilation.init(allocator, module, source);
    defer compilation.deinit();
    const outcome = try native.run(&compilation);
    try t.expectEqual(@as(i64, 7), outcome.value);
}

// spec: ARENA-MANAGED-7
test "ARENA-MANAGED-7 arena scopes and escape copies unwind on every allocation failure" {
    try escapeScenario(t.allocator);
    var stable = t.FailingAllocator.init(t.allocator, .{ .resize_fail_index = 0 });
    try t.checkAllAllocationFailures(stable.allocator(), escapeScenario, .{});
}

// spec: ARENA-MANAGED-8
test "ARENA-MANAGED-8 the native backend lowers arena scopes, the barrier and escape" {
    const source =
        \\def stash(outer: mut list[list[int]], inner: list[int]) -> None:
        \\    outer.append(inner)
        \\
        \\def main() -> int:
        \\    kept: list[int] = []
        \\    with arena() as scratch:
        \\        inner: list[int] = [7]
        \\        holder: list[list[int]] = [inner, inner]
        \\        stash(mut holder, inner)
        \\        kept = scratch.escape(holder[0])
        \\    return kept[0]
    ;
    var qbe = try language.Compilation.init(t.allocator, module, source);
    defer qbe.deinit();
    const manifest = try qbe.emitQbe(t.allocator);
    defer t.allocator.free(manifest);
    for ([_][]const u8{ "myl_qbe_region_begin", "myl_qbe_region_end", "myl_qbe_region_escape", "myl_qbe_region_check", "myl_qbe_region_retains", "myl_qbe_region_restore" }) |symbol| {
        try t.expect(std.mem.indexOf(u8, manifest, symbol) != null);
    }
}

// spec-case: ARENA-MANAGED-8
test "ARENA-MANAGED-8 an arena-free program emits neither the barrier nor depth bookkeeping" {
    // RC-DEFAULT-1: reads the tracing collector's lowering, not the RC default's.
    const collector_runtime = language.runtime_mode.pinCollector();
    defer language.runtime_mode.set(collector_runtime);
    var qbe = try language.Compilation.init(t.allocator, module,
        \\def main() -> int:
        \\    values: list[list[int]] = []
        \\    values.append([1, 2])
        \\    return len(values)
    );
    defer qbe.deinit();
    const manifest = try qbe.emitQbe(t.allocator);
    defer t.allocator.free(manifest);
    try t.expect(std.mem.indexOf(u8, manifest, "myl_qbe_region_check") == null);
    try t.expect(std.mem.indexOf(u8, manifest, "myl_qbe_region_mark") == null);
}

// spec-case: ARENA-MANAGED-8
test "ARENA-MANAGED-8 only a function that opens an arena records and restores its depth" {
    const Unit = struct { name: []const u8, il: []const u8 };
    const Manifest = struct { functions: []Unit };
    var qbe = try language.Compilation.init(t.allocator, module,
        \\def helper(value: int) -> int:
        \\    return value + 1
        \\
        \\def main() -> int:
        \\    total = 0
        \\    with arena():
        \\        total = helper(6)
        \\    return total
    );
    defer qbe.deinit();
    const encoded = try qbe.emitQbe(t.allocator);
    defer t.allocator.free(encoded);
    var parsed = try std.json.parseFromSlice(Manifest, t.allocator, encoded, .{ .allocate = .alloc_always, .ignore_unknown_fields = true });
    defer parsed.deinit();
    var helper: ?[]const u8 = null;
    var main: ?[]const u8 = null;
    for (parsed.value.functions) |unit| {
        if (std.mem.eql(u8, unit.name, "helper")) helper = unit.il;
        if (std.mem.eql(u8, unit.name, "main")) main = unit.il;
    }
    try t.expect(std.mem.indexOf(u8, helper.?, "myl_qbe_region_mark") == null);
    try t.expect(std.mem.indexOf(u8, helper.?, "myl_qbe_region_restore") == null);
    try t.expect(std.mem.indexOf(u8, main.?, "myl_qbe_region_mark") != null);
    try t.expect(std.mem.indexOf(u8, main.?, "myl_qbe_region_restore") != null);
}

test "arena source formatting preserves the with statement" {
    const source =
        \\def main() -> int:
        \\    total = 0
        \\    with arena() as scratch:
        \\        items: list[int] = [1, 2]
        \\        total = len(items)
        \\    return total
        \\
    ;
    var compilation = try language.Compilation.init(t.allocator, module, source);
    defer compilation.deinit();
    const formatted = try compilation.format(t.allocator);
    defer t.allocator.free(formatted);
    try t.expectEqualStrings(source, formatted);
}

// spec-case: ARENA-MANAGED-6
test "ARENA-MANAGED-6 noalloc still rejects arena allocation while entering a scope is free" {
    try reject(
        \\def grow() -> int:
        \\    items: list[int] = []
        \\    items.append(1)
        \\    return len(items)
        \\
        \\def constrained() -> int noalloc:
        \\    with arena() as scratch:
        \\        return grow()
        \\
        \\def main() -> int:
        \\    return constrained()
    , "E_EFFECT_BOUND");
    const source =
        \\def empty() -> int noalloc:
        \\    with arena() as scratch:
        \\        return 7
        \\
        \\def main() -> int:
        \\    return empty()
    ;
    try t.expectEqual(@as(i64, 7), try value(source));
}

// spec: ARENA-MANAGED-9
test "ARENA-MANAGED-9 a managed binding first assigned inside an arena is confined once the block ends" {
    // Function scoping keeps `data` in scope after the block, but reading a managed
    // value that lived in the released region is a static escape, not a dangling read.
    try reject(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        data = [1, 2, 3]
        \\    return len(data)
    , "E_ARENA_ESCAPE");
    // A scalar first assigned inside the arena carries no reference and reads freely.
    try t.expectEqual(@as(i64, 4), try value(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        found = 4
        \\    return found
    ));
    // Reassigning the name after the block re-homes it and clears the confinement.
    try t.expectEqual(@as(i64, 2), try value(
        \\def main() -> int:
        \\    with arena() as scratch:
        \\        data = [1, 2, 3]
        \\    data = [9, 9]
        \\    return len(data)
    ));
}

// spec-case: ARENA-MANAGED-10
test "ARENA-MANAGED-10 repeated arena scopes reuse a retained chunk inside a small budget" {
    var looping = try language.Compilation.init(t.allocator, module,
        \\def fold(seed: int) -> int:
        \\    values: list[int] = []
        \\    for index in range(16):
        \\        values.append(seed + index)
        \\    total = 0
        \\    for item in values:
        \\        total += item
        \\    return total
        \\
        \\def main() -> int:
        \\    matched = 0
        \\    for round in range(20000):
        \\        with arena():
        \\            if fold(round) == 16 * round + 120:
        \\                matched += 1
        \\    return matched
    );
    defer looping.deinit();
    // Twenty thousand scopes under a 1 MiB ceiling. A reused chunk is charged
    // exactly as a fresh reservation would be, so the budget neither traps nor
    // drifts however many scopes the loop opens and closes.
    const reused = try native.runWithOptions(&looping, .{ .max_memory = 1 << 20 });
    try t.expectEqualStrings("", reused.trap.code);
    try t.expectEqual(@as(i64, 20000), reused.value);
    var bounded = try language.Compilation.init(t.allocator, module,
        \\def main() -> int:
        \\    kept = 0
        \\    with arena():
        \\        values: list[int] = []
        \\        n = 0
        \\        while n < 400000:
        \\            values.append(n)
        \\            n += 1
        \\        kept = len(values)
        \\    return kept
    );
    defer bounded.deinit();
    // A live arena that outgrows the ceiling still names the budget: retained
    // chunks are not spendable budget, only host bytes the runtime can give back.
    const refused = try native.runWithOptions(&bounded, .{ .max_memory = 1 << 20 });
    try t.expectEqualStrings("R_MEMORY_BUDGET", refused.trap.code);
}

// spec-case: ARENA-MANAGED-10
test "ARENA-MANAGED-10 a chunk reused after an escape copy keeps the escaped value" {
    const source =
        \\def build(width: int) -> list[int]:
        \\    items: list[int] = []
        \\    for index in range(width):
        \\        items.append(index * index)
        \\    return items
        \\
        \\def main() -> int:
        \\    kept: list[int] = []
        \\    with arena() as scratch:
        \\        built = build(6)
        \\        kept = scratch.escape(built)
        \\    churn = 0
        \\    for round in range(500):
        \\        with arena():
        \\            churn += len(build(8))
        \\    return kept[5] + churn
    ;
    // The escaped copy lives in the enclosing region; the five hundred scopes
    // that follow reuse the chunk the escaping scope released.
    try t.expectEqual(@as(i64, 4025), try value(source));
    const stressed = try run(source, true);
    try t.expectEqual(@as(i64, 4025), stressed.value);
}

// spec-case: ARENA-MANAGED-11
test "ARENA-MANAGED-11 the header barrier traps a younger store after the arena spans many chunks" {
    const fill =
        \\def stash(outer: mut list[list[int]], inner: list[int]) -> None:
        \\    outer.append(inner)
        \\
        \\def fill(count: int) -> list[list[int]]:
        \\    rows: list[list[int]] = []
        \\    for index in range(count):
        \\        rows.append([index])
        \\    return rows
        \\
    ;
    // Thousands of small lists put the outer arena's container and the value
    // stored into it in different chunks; each depth comes from its header.
    const into_older_arena = try run(fill ++
        \\def main() -> int:
        \\    kept = 0
        \\    with arena():
        \\        keeper = fill(3000)
        \\        with arena():
        \\            stash(mut keeper, [1])
        \\        kept = len(keeper)
        \\    return kept
    , false);
    try t.expectEqualStrings("R_ARENA_ESCAPE", into_older_arena.trap.code);
    const into_collected = try run(fill ++
        \\def main() -> int:
        \\    keeper: list[list[int]] = []
        \\    with arena():
        \\        rows = fill(3000)
        \\        stash(mut keeper, rows[2999])
        \\    return len(keeper)
    , false);
    try t.expectEqualStrings("R_ARENA_ESCAPE", into_collected.trap.code);
    // At the same scale an arena container accepts its own arena's values, and
    // a younger container accepts older ones.
    try t.expectEqual(@as(i64, 3004), try value(fill ++
        \\def main() -> int:
        \\    kept = 0
        \\    with arena():
        \\        keeper = fill(3000)
        \\        stash(mut keeper, [7])
        \\        with arena():
        \\            younger = fill(2)
        \\            stash(mut younger, keeper[2999])
        \\            kept = len(younger)
        \\        kept = kept + len(keeper)
        \\    return kept
    ));
}

const stash_text =
    \\def stash(outer: mut list[str], value: str) -> None:
    \\    outer.append(value)
    \\
    \\def text() -> str:
    \\    return "".join(["row " + str(i) + "," for i in range(40)])
    \\
;

/// The trap code of storing `piece`, a piece of an outer text made inside an
/// arena, into an outer list through a helper, under collection stress.
fn storeOutward(piece: []const u8) ![]const u8 {
    const source = try std.fmt.allocPrint(t.allocator, stash_text ++
        \\def main() -> int:
        \\    keeper: list[str] = []
        \\    source = text()
        \\    with arena() as scratch:
        \\        stash(mut keeper, {s})
        \\    return len(keeper)
    , .{piece});
    defer t.allocator.free(source);
    return (try run(source, true)).trap.code;
}

// spec-case: TEXT-VIEW-2
test "TEXT-VIEW-2 a piece made inside an arena traps when a helper stores it outward, as a copy did" {
    // A long slice of an outer text is a view allocated in the arena; the whole
    // outer text answered as a piece inside the arena is one too, and a short
    // split piece is an arena copy.
    try t.expectEqualStrings("R_ARENA_ESCAPE", try storeOutward("source[4:200]"));
    try t.expectEqualStrings("R_ARENA_ESCAPE", try storeOutward("source[0:len(source)]"));
    try t.expectEqualStrings("R_ARENA_ESCAPE", try storeOutward("source.strip()"));
    try t.expectEqualStrings("R_ARENA_ESCAPE", try storeOutward("source.split(\",\")[3]"));
    // `escape` hands the same pieces out as text of their own octets.
    try t.expectEqual(@as(i64, 196 + 270 + 5), try value(stash_text ++
        \\def main() -> int:
        \\    keeper: list[str] = []
        \\    source = text()
        \\    with arena() as scratch:
        \\        keeper = scratch.escape([source[4:200], source.strip(), source.split(",")[3]])
        \\    return len(keeper[0]) + len(keeper[1]) + len(keeper[2])
    ));
}
