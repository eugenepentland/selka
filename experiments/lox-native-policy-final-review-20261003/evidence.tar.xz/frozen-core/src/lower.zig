//! Iterative lowering with symbolic labels preserves stack shape and source evaluation order.
/// Failures returned by lower; callers must handle these boundary errors.
pub const LowerError = error{
    InternalError,
    OutOfMemory,
};

const std = @import("std");
const typed = @import("typed.zig");
const bc = @import("bytecode.zig");
const value_semantics = @import("value_semantics.zig");
const evaluation_order = @import("value_semantics_order.zig");
const Span = @import("source.zig").Span;
const Label = enum(usize) { _ };
const Work = union(enum) {
    expression: typed.NodeId,
    statement: typed.StatementId,
    instruction: bc.Instruction,
    mark: Label,
    jump: struct { target: Label, conditional: bool = false, span: Span },
    propagate: struct { input: typed.Type, output: typed.Type, target: Label, span: Span },
    dispatch: struct { ty: typed.Type, targets: []const Label, slots: []const ?typed.LocalId, span: Span, borrowed: bool },
};
const Fixup = struct { instruction: usize, label: Label, arm: ?usize = null, propagation: bool = false };
const Emitter = struct {
    allocator: std.mem.Allocator,
    /// LOWER-EXACT-1: where the emitter's work stack, labels, fixups, loop
    /// table and instruction list grow. Only the finished instructions are
    /// copied into `allocator`, at their exact length, so an arena output keeps
    /// no abandoned growth buffers (two to three times the code, before).
    scratch: std.mem.Allocator,
    program: typed.Program,
    /// A `--mode ReleaseFast` build drops `debug` nodes in lowering; Debug builds
    /// and `run`/`test` keep them.
    drop_debug: bool = false,
    loops: std.AutoHashMapUnmanaged(usize, struct { start: Label, end: Label }) = .empty,
    code: std.ArrayList(bc.Instruction) = .empty,
    work: std.ArrayList(Work) = .empty,
    labels: std.ArrayList(?usize) = .empty,
    fixups: std.ArrayList(Fixup) = .empty,
    /// VALUE-SEMANTICS-2: this function's lowering facts under value
    /// semantics, or null with the switch off (no copy is ever placed).
    values: ?*const value_semantics.Facts = null,
    /// VALUE-SEMANTICS-14: the lent operands and read receivers a later
    /// operand of the same expression may write, which lowering copies when
    /// they are read; null with value semantics off.
    snapshots: ?*const evaluation_order.Snapshots = null,
    /// Hidden locals lowering adds after the checked ones: boxed match
    /// payloads and dictionary receivers that a nested write can replace.
    extra_locals: std.ArrayList(typed.Local) = .empty,
    /// How many locals the checked function declares; `extra_locals` follow.
    declared_locals: usize = 0,

    fn push(self: *Emitter, task: Work) !void {
        try self.work.append(self.scratch, task);
    }
    fn label(self: *Emitter) !Label {
        const id: Label = @fromBackingInt(self.labels.items.len);
        try self.labels.append(self.scratch, null);
        return id;
    }
    fn instruction(self: *Emitter, span: Span, op: @FieldType(bc.Instruction, "op")) !void {
        try self.push(.{ .instruction = .{ .span = span, .op = op } });
    }
    fn emitCall(self: *Emitter, span: Span, call: @FieldType(@FieldType(typed.Node, "data"), "call")) !void {
        if (call.evaluation) |evaluation| for (evaluation.cleanup) |slot| try self.instruction(span, .{ .drop_local = slot });
        try self.instruction(span, .{ .call = call.function });
        const callee = self.program.functions[@backingInt(call.function)];
        const writable = try self.writableArguments(call.arguments, callee.signature.declared_mutates);
        var i = call.arguments.len;
        while (i > 0) {
            i -= 1;
            // A `mut` fixed array (or, under value semantics, record) crosses
            // as the caller's own variable, which the checker proved the
            // argument names.
            if (referencePosition(self.program, callee, i)) {
                const argument = self.program.nodes[@backingInt(call.arguments[i])];
                if (argument.data != .local) return error.InternalError;
                try self.instruction(argument.span, .{ .ref_local = argument.data.local });
            } else if (declaredMutable(callee.signature.declared_mutates, i)) {
                try self.mutableArgument(call.arguments[i]);
            } else try self.readOnlyArgument(call.arguments[i], writable);
        }
        if (call.evaluation) |evaluation| try self.push(.{ .statement = evaluation.body });
    }
    /// Whether parameter `position` of `callee` is a `mut` fixed array (or,
    /// under value semantics, record), which receives the address of the
    /// caller's variable instead of a copy.
    fn referencePosition(program: typed.Program, callee: typed.Function, position: usize) bool {
        if (position >= callee.signature.parameter_count) return false;
        for (callee.signature.declared_mutates) |declared| if (declared == position)
            return typed.referenceMut(program.records, callee.scope.locals[position].ty);
        return false;
    }
    /// Whether `position` is one of a callee's declared `mut` positions: its
    /// argument is the caller's own value, never a value-semantics copy.
    fn declaredMutable(positions: []const u16, position: usize) bool {
        for (positions) |declared| if (declared == position) return true;
        return false;
    }
    /// A nested mutable argument is a writing place, not an owned read result.
    fn mutableArgument(self: *Emitter, id: typed.NodeId) !void {
        const node = self.program.nodes[@backingInt(id)];
        if (self.values != null and node.data != .local) {
            const owner = try self.hiddenLocal(node.ty, node.span, "<mut-argument>");
            try self.instruction(node.span, .{ .load_local = owner });
            try self.instruction(node.span, .{ .store_local = owner });
        }
        try self.push(.{ .expression = id });
    }
    /// The arguments bound to `mut` positions, which the callee may write
    /// while it reads the others; empty with value semantics off.
    fn writableArguments(self: *Emitter, arguments: []const typed.NodeId, positions: []const u16) ![]const typed.NodeId {
        if (self.values == null) return &.{};
        var chosen: std.ArrayList(typed.NodeId) = .empty;
        for (positions) |position| if (position < arguments.len) try chosen.append(self.scratch, arguments[position]);
        return chosen.items;
    }
    /// VALUE-SEMANTICS-5: a read-only argument is lent, since the callee
    /// cannot write it, unless a `mut` argument of the same call could reach
    /// it: then it is a real copy taken before the call.
    fn readOnlyArgument(self: *Emitter, id: typed.NodeId, writable: []const typed.NodeId) !void {
        const values = self.values orelse return self.push(.{ .expression = id });
        // An operand VALUE-SEMANTICS-14 snapshots is already a copy of its own.
        if (self.snapshot(id)) return self.push(.{ .expression = id });
        if (writable.len == 0 or !value_semantics.argumentConflicts(values, id, writable)) return self.push(.{ .expression = id });
        try self.copyAfter(id, .argument);
        try self.push(.{ .expression = id });
    }
    /// VALUE-SEMANTICS-2: push `id` as a value moving to a second home
    /// (`target` names the local it is stored into). Under value semantics a
    /// `value_copy` follows it unless the value is fresh; the ownership
    /// analysis later leaves out every copy that is a move or a borrow.
    fn transfer(self: *Emitter, id: typed.NodeId, site: bc.CopySite, target: ?typed.LocalId) !void {
        if (self.values) |values| {
            const ty = self.program.nodes[@backingInt(id)].ty;
            if (value_semantics.needsCopy(self.program.records, ty) and values.classify(id, target) == .place) try self.copyAfter(id, site);
        }
        try self.push(.{ .expression = id });
    }
    /// Whether `id` is a lent operand a later operand of the same expression
    /// may write, so it is copied when read (VALUE-SEMANTICS-14).
    fn snapshot(self: *const Emitter, id: typed.NodeId) bool {
        const found = self.snapshots orelse return false;
        return found.operand(id);
    }
    /// VALUE-SEMANTICS-14: a read-only collection operation whose arguments
    /// may write its receiver reads a copy of the receiver taken before them.
    /// Returns the local the operation reads: that copy, or its own owner.
    fn capturedReceiver(self: *Emitter, id: typed.NodeId, owner: typed.LocalId) !typed.LocalId {
        const found = self.snapshots orelse return owner;
        if (!found.receiver(id)) return owner;
        const node = self.program.nodes[@backingInt(id)];
        const ty = self.values.?.function.scope.locals[@backingInt(owner)].ty;
        return self.hiddenLocal(ty, node.span, "<receiver>");
    }
    /// Queue the one `value_copy` of `id`'s value, to run after it.
    fn copyAfter(self: *Emitter, id: typed.NodeId, site: bc.CopySite) !void {
        const node = self.program.nodes[@backingInt(id)];
        try self.instruction(node.span, .{ .value_copy = .{ .ty = node.ty, .site = site } });
    }
    /// Under value semantics, a shallow copy, slice or concatenation of a
    /// collection whose elements hold collections copies those elements too,
    /// so the fresh result shares nothing. Queued before the operation itself.
    fn childrenCopy(self: *Emitter, id: typed.NodeId) !void {
        if (self.values == null) return;
        const node = self.program.nodes[@backingInt(id)];
        if (!value_semantics.childrenNeedCopy(self.program.records, node.ty)) return;
        try self.instruction(node.span, .{ .value_copy = .{ .ty = node.ty, .site = .children } });
    }
    /// Values evaluate in source order, then `sep=` and finally `end=`. A stream
    /// receiver evaluates first and sits at the stack bottom. A dropped `debug`
    /// node emits nothing at all, so its arguments are not evaluated either.
    fn emitPrint(self: *Emitter, span: Span, output: @FieldType(@FieldType(typed.Node, "data"), "print")) !void {
        if (output.debug and self.drop_debug) {
            // The node still produces its unit value, but no operand is
            // evaluated and no byte reaches the stream.
            try self.instruction(span, .push_unit);
            return;
        }
        const types = try self.allocator.alloc(typed.Type, output.arguments.len);
        for (output.arguments, types) |argument, *ty| ty.* = self.program.nodes[@backingInt(argument)].ty;
        try self.instruction(span, .{ .print = .{
            .sink = output.sink,
            .types = types,
            .separator = output.separator != null,
            .terminator = output.terminator != null,
            .stream = output.stream != null,
            .debug = output.debug,
        } });
        if (output.terminator) |value| try self.push(.{ .expression = value });
        if (output.separator) |value| try self.push(.{ .expression = value });
        var index = output.arguments.len;
        while (index > 0) {
            index -= 1;
            try self.push(.{ .expression = output.arguments[index] });
        }
        if (output.stream) |stream| try self.push(.{ .expression = stream });
    }
    /// `stream.write(text)`: push the text, then the stream receiver above it.
    fn emitStreamWrite(self: *Emitter, span: Span, write: @FieldType(@FieldType(typed.Node, "data"), "stream_write")) !void {
        try self.instruction(span, .{ .stream_write = .{
            .stream = self.program.nodes[@backingInt(write.stream)].ty,
            .text = self.program.nodes[@backingInt(write.text)].ty,
        } });
        try self.push(.{ .expression = write.text });
        try self.push(.{ .expression = write.stream });
    }
    fn emitLoopExit(self: *Emitter, stmt: typed.Statement, exit: @FieldType(@FieldType(typed.Statement, "data"), "loop_exit")) !void {
        const target = self.loops.get(exit.target) orelse return error.InternalError;
        try self.push(.{ .jump = .{ .target = if (exit.continuing) target.start else target.end, .span = stmt.span } });
        for (exit.arenas) |slot| try self.instruction(stmt.span, .{ .end_arena = slot });
        for (stmt.owned_cleanup) |slot| try self.instruction(stmt.span, .{ .drop_local = slot });
    }
    /// One statement form, two resource kinds: a managed region or an open file.
    fn emitWithScope(self: *Emitter, span: Span, scope: @FieldType(@FieldType(typed.Statement, "data"), "with_scope")) !void {
        const terminates = self.program.statements[@backingInt(scope.body)].terminates;
        if (scope.resource) |value| {
            if (!terminates) try self.instruction(span, .{ .drop_local = scope.slot });
            try self.push(.{ .statement = scope.body });
            try self.instruction(span, .{ .store_local = scope.slot });
            try self.push(.{ .expression = value });
            return;
        }
        if (!terminates) try self.instruction(span, .{ .end_arena = scope.slot });
        try self.push(.{ .statement = scope.body });
        try self.instruction(span, .{ .begin_arena = scope.slot });
    }
    /// A valued assert renders its message to standard error only when the
    /// condition is false, then traps through the same `assert_true` op a
    /// static-message assert uses. The status message stays empty, so the trap
    /// record is the bare `R_ASSERT` and the printed line names the values.
    fn emitValuedAssert(self: *Emitter, span: Span, check: @FieldType(@FieldType(typed.Statement, "data"), "assertion"), message: typed.NodeId) !void {
        const condition_span = self.program.nodes[@backingInt(check.condition)].span;
        const fail = try self.label();
        const done = try self.label();
        const types = try self.allocator.alloc(typed.Type, 1);
        types[0] = self.program.nodes[@backingInt(message)].ty;
        try self.push(.{ .mark = done });
        try self.instruction(condition_span, .{ .assert_true = .{ .message = "" } });
        try self.instruction(condition_span, .{ .push_bool = false });
        try self.instruction(span, .pop);
        try self.instruction(span, .{ .print = .{ .sink = .stderr, .types = types, .separator = false, .terminator = false, .stream = false, .debug = true } });
        try self.push(.{ .expression = message });
        try self.push(.{ .mark = fail });
        try self.push(.{ .jump = .{ .target = done, .span = span } });
        try self.push(.{ .jump = .{ .target = fail, .conditional = true, .span = condition_span } });
        try self.push(.{ .expression = check.condition });
    }
    fn emitStatement(self: *Emitter, id: typed.StatementId) !void {
        const stmt = self.program.statements[@backingInt(id)];
        switch (stmt.data) {
            .with_scope => |scope| try self.emitWithScope(stmt.span, scope),
            .block => |children| {
                for (stmt.owned_cleanup) |slot| try self.instruction(stmt.span, .{ .drop_local = slot });
                var i = children.len;
                while (i > 0) {
                    i -= 1;
                    try self.push(.{ .statement = children[i] });
                }
            },
            .ret => |value| {
                try self.instruction(stmt.span, .ret);
                try self.transfer(value, .ret, null);
            },
            .assertion => |check| {
                if (check.message_value) |message| {
                    try self.emitValuedAssert(stmt.span, check, message);
                    return;
                }
                try self.instruction(self.program.nodes[@backingInt(check.condition)].span, .{ .assert_true = .{ .message = check.message, .kind = check.kind } });
                try self.push(.{ .expression = check.condition });
            },
            // `_ = expr` releases a result-bearing value, which settles its obligation.
            .discard => |value| {
                const value_type = self.program.nodes[@backingInt(value)].ty;
                const handled = typed.requiresHandling(value_type, self.program.records);
                try self.instruction(stmt.span, if (handled) .{ .acknowledge = value_type } else .pop);
                try self.push(.{ .expression = value });
            },
            .initialize, .assign => |store| {
                try self.instruction(stmt.span, .{ .store_local = store.slot });
                // A compiler temporary is a path to the value it holds, never a
                // second home, so only a store into a named local transfers.
                if (self.values != null and self.values.?.namedStore(store.slot))
                    try self.transfer(store.value, .assign, store.slot)
                else
                    try self.push(.{ .expression = store.value });
            },
            .match => |match| {
                const end = try self.label();
                const targets = try self.allocator.alloc(Label, match.arms.len);
                const slots = try self.allocator.alloc(?typed.LocalId, match.arms.len);
                try self.push(.{ .mark = end });
                var i = match.arms.len;
                const matched = self.program.nodes[@backingInt(match.value)].ty;
                while (i > 0) {
                    i -= 1;
                    const arm = match.arms[i];
                    targets[arm.tag] = try self.label();
                    slots[arm.tag] = arm.slot;
                    if (!self.program.statements[@backingInt(arm.body)].terminates) try self.push(.{ .jump = .{ .target = end, .span = stmt.span } });
                    try self.push(.{ .statement = arm.body });
                    if (!match.borrowed) if (arm.slot) |slot| try self.payloadCopy(stmt.span, match.value, slot);
                    const case = self.variantCase(matched, arm.tag);
                    if (case.boxed) if (arm.slot) |slot| {
                        // The arm's box lands in a hidden local; the binding the
                        // arm names receives the value inside it.
                        const box = try self.hiddenLocal(case.payload.?, stmt.span, "<box>");
                        slots[arm.tag] = box;
                        try self.instruction(stmt.span, .{ .store_local = slot });
                        try self.unboxValue(stmt.span);
                        try self.instruction(stmt.span, .{ .load_local = box });
                    };
                    try self.push(.{ .mark = targets[arm.tag] });
                }
                try self.push(.{ .dispatch = .{ .ty = self.program.nodes[@backingInt(match.value)].ty, .targets = targets, .slots = slots, .span = stmt.span, .borrowed = match.borrowed } });
                if (match.borrowed) {
                    const node = self.program.nodes[@backingInt(match.value)];
                    if (node.data != .local) return error.InternalError;
                    try self.instruction(node.span, .{ .load_local = node.data.local });
                } else try self.push(.{ .expression = match.value });
            },
            .branch => |branch| {
                const otherwise = try self.label();
                const end = try self.label();
                try self.push(.{ .mark = end });
                if (branch.else_body) |body| try self.push(.{ .statement = body });
                try self.push(.{ .mark = otherwise });
                if (branch.else_body != null and !self.program.statements[@backingInt(branch.then_body)].terminates)
                    try self.push(.{ .jump = .{ .target = end, .span = stmt.span } });
                try self.push(.{ .statement = branch.then_body });
                try self.push(.{ .jump = .{ .target = otherwise, .conditional = true, .span = self.program.nodes[@backingInt(branch.condition)].span } });
                try self.push(.{ .expression = branch.condition });
            },
            .loop_exit => |exit| try self.emitLoopExit(stmt, exit),
            .loop => |loop| {
                const start = try self.label();
                const end = try self.label();
                const next = if (loop.step != null) try self.label() else start;
                try self.loops.put(self.scratch, loop.id, .{ .start = next, .end = end });
                try self.push(.{ .mark = end });
                if (loop.step) |step| {
                    try self.push(.{ .jump = .{ .target = start, .span = stmt.span } });
                    try self.push(.{ .statement = step });
                    try self.push(.{ .mark = next });
                } else if (!self.program.statements[@backingInt(loop.body)].terminates)
                    try self.push(.{ .jump = .{ .target = start, .span = stmt.span } });
                try self.push(.{ .statement = loop.body });
                // A loop the checker proved never exits emits no conditional exit, so what
                // follows it stays unreachable instead of falling out of the function.
                if (!stmt.terminates) {
                    try self.push(.{ .jump = .{ .target = end, .conditional = true, .span = self.program.nodes[@backingInt(loop.condition)].span } });
                    try self.push(.{ .expression = loop.condition });
                }
                try self.push(.{ .mark = start });
            },
        }
    }
    /// VALUE-SEMANTICS-2: a named match binding of a payload another name
    /// holds is rebound, at the top of its arm, to a copy of that payload
    /// unless the ownership analysis proves the binding a move or a borrow.
    fn payloadCopy(self: *Emitter, span: Span, scrutinee: typed.NodeId, slot: typed.LocalId) !void {
        const values = self.values orelse return;
        if (!values.namedStore(slot)) return;
        const ty = values.function.scope.locals[@backingInt(slot)].ty;
        if (!value_semantics.needsCopy(self.program.records, ty)) return;
        if (values.classify(scrutinee, null) == .fresh) return;
        const handled = typed.moveOnly(ty, self.program.records) or typed.requiresHandling(ty, self.program.records);
        // Pushed in reverse: the arm reloads its binding, copies it and
        // stores the copy back before its body runs.
        try self.instruction(span, .{ .store_local = slot });
        try self.instruction(span, .{ .value_copy = .{ .ty = ty, .site = .payload } });
        try self.instruction(span, if (handled) .{ .move_local = slot } else .{ .load_local = slot });
    }
    /// LITERAL-PAYLOAD-1: the content of a `str`/`bytes` literal whose every
    /// element is a constant, or null for any other array. Such a literal is one
    /// instruction carrying its octets, not one push per element.
    fn literalPayload(self: *Emitter, node: typed.Node, values: []const typed.NodeId) !?[]const u8 {
        if (!node.ty.isAggregate() or node.ty.recordIndex() >= self.program.records.len) return null;
        const schema = self.program.records[node.ty.recordIndex()];
        const text = schema.managed and schema.collection.kind == .string;
        const octets = typed.isByteString(schema) and schema.shape.buffer == .u8;
        if (schema.managed and schema.collection.kind == .list and !schema.collection.box)
            return @import("constant_list.zig").payload(self.allocator, self.program.records, self.program.nodes, values, schema.shape.buffer.?);
        if (!text and !octets) return null;
        const content = try @import("constant_literal.zig").payload(self.allocator, self.program.nodes, values, text);
        return content;
    }
    fn emitExpression(self: *Emitter, id: typed.NodeId) !void {
        const node = self.program.nodes[@backingInt(id)];
        switch (node.data) {
            .block_value => |block| {
                try self.push(.{ .expression = block.value });
                try self.push(.{ .statement = block.body });
            },
            .propagate => |propagate| {
                const failure = try self.label();
                const success = try self.label();
                // A boxed `Some` or `Ok` payload arrives as its box.
                if (self.propagatedBox(self.program.nodes[@backingInt(propagate.value)].ty)) try self.unboxValue(node.span);
                try self.push(.{ .mark = success });
                try self.instruction(node.span, .ret);
                try self.push(.{ .mark = failure });
                try self.push(.{ .jump = .{ .target = success, .span = node.span } });
                try self.push(.{ .propagate = .{ .input = self.program.nodes[@backingInt(propagate.value)].ty, .output = propagate.output, .target = failure, .span = node.span } });
                try self.push(.{ .expression = propagate.value });
            },
            .variant => try self.emitVariant(node),
            // An embedded file is one static object, not a record of per-byte constants (`EMBED-1`).
            .blob => |file| {
                const blob = try self.allocator.create(typed.Blob);
                blob.* = file;
                try self.instruction(node.span, .{ .make_record = .{ .ty = node.ty, .fields = 0, .blob = blob } });
            },
            .array => |values| {
                if (try self.literalPayload(node, values)) |octets| {
                    try self.instruction(node.span, .{ .make_record = .{ .ty = node.ty, .fields = 0, .payload = octets } });
                    return;
                }
                try self.instruction(node.span, .{ .make_record = .{ .ty = node.ty, .fields = values.len } });
                var i = values.len;
                while (i > 0) {
                    i -= 1;
                    try self.transfer(values[i], .store, null);
                }
            },
            .index => |access| {
                try self.instruction(node.span, .{ .get_index = .{ .ty = self.program.nodes[@backingInt(access.base)].ty, .from_end = access.from_end } });
                try self.indexKey(access.base, access.index, node.ty);
                try self.indexReceiver(access.base);
            },
            .replace => |replace| {
                try self.instruction(node.span, .{ .replace_index = .{ .ty = node.ty, .from_end = replace.from_end } });
                try self.transfer(replace.value, .store, null);
                try self.push(.{ .expression = replace.index });
                try self.push(.{ .expression = replace.base });
            },
            .length => |base| {
                try self.instruction(node.span, .{ .array_length = self.program.nodes[@backingInt(base)].ty });
                try self.push(.{ .expression = base });
            },
            .record => |fields| {
                const order = try self.allocator.alloc(usize, fields.len);
                for (fields, order) |field, *index| index.* = field.index;
                try self.instruction(node.span, .{ .make_record = .{ .ty = node.ty, .fields = fields.len, .order = order } });
                try self.pushFields(fields, node.ty);
            },
            .update => |update| {
                const indices = try self.allocator.alloc(usize, update.fields.len);
                for (update.fields, indices) |field, *index| index.* = field.index;
                try self.instruction(node.span, .{ .update_record = .{ .ty = node.ty, .indices = indices } });
                try self.pushFields(update.fields, node.ty);
                try self.push(.{ .expression = update.base });
            },
            .field => |field| {
                const owner = self.program.nodes[@backingInt(field.base)].ty;
                if (self.program.records[owner.recordIndex()].fields[field.index].boxed) try self.unboxValue(node.span);
                try self.instruction(node.span, .{ .get_field = field.index });
                try self.push(.{ .expression = field.base });
            },
            .integer => |value| try self.instruction(node.span, if (node.ty == .i64) .{ .push_i64 = @intCast(value) } else .{ .push_integer = .{ .ty = node.ty, .value = value } }),
            .wrap => |value| {
                try self.instruction(node.span, .{ .wrap_domain = node.ty });
                try self.push(.{ .expression = value });
            },
            .unwrap => |value| {
                try self.instruction(node.span, .{ .unwrap_domain = self.program.nodes[@backingInt(value)].ty });
                try self.push(.{ .expression = value });
            },
            .cast => |value| {
                try self.instruction(node.span, .{ .cast_integer = node.ty });
                try self.push(.{ .expression = value });
            },
            .boolean => |value| try self.instruction(node.span, .{ .push_bool = value }),
            .unit => try self.instruction(node.span, .push_unit),
            .buffer_operation => |operation| try self.emitBufferOperation(id, operation),
            .arena_escape => |value| {
                try self.instruction(node.span, .{ .arena_escape = node.ty });
                try self.push(.{ .expression = value });
            },
            .restrict_resource => |restrict| {
                try self.instruction(node.span, .{ .restrict_resource = .{ .permissions = restrict.permissions, .ty = node.ty } });
                try self.push(.{ .expression = restrict.value });
            },
            .dir_resource => |dir| {
                try self.instruction(node.span, .{ .dir_resource = .{ .output = node.ty, .path = self.program.nodes[@backingInt(dir.path)].ty } });
                try self.push(.{ .expression = dir.path });
                try self.push(.{ .expression = dir.capability });
            },
            .host_resource => |host| {
                try self.instruction(node.span, .{ .host_resource = .{ .output = node.ty, .name = self.program.nodes[@backingInt(host.name)].ty } });
                try self.push(.{ .expression = host.name });
                try self.push(.{ .expression = host.capability });
            },
            .resource_io => |io| {
                try self.instruction(node.span, .{ .resource_io = .{ .kind = io.kind, .owner = io.owner, .output = node.ty, .input = if (io.value) |value| self.program.nodes[@backingInt(value)].ty else null } });
                if (io.value) |value| try self.push(.{ .expression = value });
            },
            .environment_get => |get| {
                try self.instruction(node.span, .{ .environment_get = .{ .output = node.ty, .name = self.program.nodes[@backingInt(get.name)].ty } });
                try self.push(.{ .expression = get.name });
                try self.push(.{ .expression = get.capability });
            },
            .environment_only => |only| {
                try self.instruction(node.span, .{ .environment_only = .{ .output = node.ty, .names = self.program.nodes[@backingInt(only.names)].ty } });
                try self.push(.{ .expression = only.names });
                try self.push(.{ .expression = only.capability });
            },
            .environment_names => |capability| {
                try self.instruction(node.span, .{ .environment_names = .{ .output = node.ty } });
                try self.push(.{ .expression = capability });
            },
            .complete_resource => |value| {
                try self.instruction(node.span, .{ .complete_resource = node.ty });
                try self.push(.{ .expression = value });
            },
            .acquire_resource => |acquire| {
                try self.instruction(node.span, .{ .acquire_resource = .{ .output = node.ty, .request = self.program.nodes[@backingInt(acquire.request)].ty } });
                try self.push(.{ .expression = acquire.request });
                try self.push(.{ .expression = acquire.capability });
            },
            .external_read => |read| {
                try self.instruction(node.span, .{ .external_read = .{ .kind = read.kind, .output = node.ty } });
                try self.push(.{ .expression = read.capability });
            },
            .stand_in => |stand| {
                try self.instruction(node.span, .{ .stand_in = stand.kind });
                if (stand.second) |second| try self.push(.{ .expression = second });
                try self.push(.{ .expression = stand.first });
            },
            .acquire_buffer => |acquire| {
                try self.instruction(node.span, .{ .acquire_buffer = node.ty });
                try self.push(.{ .expression = acquire.capacity });
            },
            .print => |output| try self.emitPrint(node.span, output),
            .stream_write => |write| try self.emitStreamWrite(node.span, write),
            .file_access => |call| {
                try self.instruction(node.span, .{ .file_access = .{
                    .kind = call.kind,
                    .mode = call.mode,
                    .text = call.text,
                    .operands = call.arguments.len,
                    .output = node.ty,
                    .shapes = call.shapes,
                } });
                var index = call.arguments.len;
                while (index > 0) {
                    index -= 1;
                    try self.push(.{ .expression = call.arguments[index] });
                }
            },
            .file_method => |call| {
                try self.instruction(node.span, .{ .file_method = .{
                    .kind = call.kind,
                    .owner = call.owner,
                    .text = call.text,
                    .argument = call.argument != null,
                    .output = node.ty,
                    .shapes = call.shapes,
                } });
                if (call.argument) |value| try self.push(.{ .expression = value });
            },
            .local => |slot| try self.instruction(node.span, if (typed.moveOnly(node.ty, self.program.records) or typed.requiresHandling(node.ty, self.program.records)) .{ .move_local = slot } else .{ .load_local = slot }),
            .function_value => |target| try self.instruction(node.span, .{ .function_value = .{ .ty = node.ty, .function = target } }),
            .invoke => |call| {
                const callee_type = self.program.nodes[@backingInt(call.callee)].ty;
                try self.instruction(node.span, .{ .invoke = callee_type });
                const positions: []const u16 = if (self.program.records[callee_type.recordIndex()].contract.callback) |signature| signature.mutates else &.{};
                const writable = try self.writableArguments(call.arguments, positions);
                var i = call.arguments.len;
                while (i > 0) {
                    i -= 1;
                    if (declaredMutable(positions, i)) try self.mutableArgument(call.arguments[i]) else try self.readOnlyArgument(call.arguments[i], writable);
                }
                try self.push(.{ .expression = call.callee });
            },
            .call => |call| try self.emitCall(node.span, call),
            .unary => |u| {
                try self.instruction(u.op_span, if (u.op != .neg and u.op != .not) .{ .unary_float = u.op } else if (u.op == .not) .not_bool else if (node.ty == .i64) .neg_i64_checked else .{ .neg_integer = node.ty });
                try self.push(.{ .expression = u.operand });
            },
            .binary => |b| {
                if (b.op == .logical_and or b.op == .logical_or) {
                    const alternate = try self.label();
                    const end = try self.label();
                    try self.push(.{ .mark = end });
                    if (b.op == .logical_and) try self.instruction(b.op_span, .{ .push_bool = false }) else try self.push(.{ .expression = b.right });
                    try self.push(.{ .mark = alternate });
                    try self.push(.{ .jump = .{ .target = end, .span = b.op_span } });
                    if (b.op == .logical_and) try self.push(.{ .expression = b.right }) else try self.instruction(b.op_span, .{ .push_bool = true });
                    try self.push(.{ .jump = .{ .target = alternate, .conditional = true, .span = b.op_span } });
                    try self.push(.{ .expression = b.left });
                } else {
                    try self.childrenCopy(id);
                    try self.push(.{ .instruction = binaryInstruction(b, self.program.nodes, self.program.records) });
                    try self.push(.{ .expression = b.right });
                    try self.push(.{ .expression = b.left });
                }
            },
        }
    }
    /// A collection operation on its owner local: the arguments evaluate in
    /// order, a stored one as a transfer, then the operation runs.
    fn emitBufferOperation(self: *Emitter, id: typed.NodeId, operation: @FieldType(@FieldType(typed.Node, "data"), "buffer_operation")) !void {
        const node = self.program.nodes[@backingInt(id)];
        if (value_semantics.shallowResult(operation.kind)) try self.childrenCopy(id);
        const receiver = try self.capturedReceiver(id, operation.owner);
        try self.instruction(node.span, .{ .buffer_operation = .{ .kind = operation.kind, .owner = receiver, .output = node.ty } });
        const stored = self.storedArgument(operation);
        var i = operation.arguments.len;
        while (i > 0) {
            i -= 1;
            if (stored == i) try self.transfer(operation.arguments[i], .store, null) else try self.push(.{ .expression = operation.arguments[i] });
        }
        if (receiver == operation.owner) return;
        // VALUE-SEMANTICS-14: the captured receiver is copied before the
        // arguments evaluate.
        const ty = self.values.?.function.scope.locals[@backingInt(operation.owner)].ty;
        try self.instruction(node.span, .{ .store_local = receiver });
        try self.instruction(node.span, .{ .value_copy = .{ .ty = ty, .site = .argument } });
        try self.instruction(node.span, .{ .load_local = operation.owner });
    }
    // A variant receives its independent payload before a recursive edge boxes it.
    fn emitVariant(self: *Emitter, node: typed.Node) !void {
        const variant = node.data.variant;
        try self.instruction(node.span, .{ .make_variant = .{ .ty = node.ty, .tag = variant.tag } });
        const case = self.variantCase(node.ty, variant.tag);
        if (case.boxed) try self.boxValue(node.span, case.payload.?);
        if (variant.value) |value| try self.transfer(value, .store, null);
    }
    /// Push field values in reverse; each is a store into the record, except
    /// that a live dictionary view lends its mapping.
    fn pushFields(self: *Emitter, fields: []const typed.FieldInit, record: typed.Type) !void {
        const lent = value_semantics.isLiveView(self.program.records, record);
        const schema = self.program.records[record.recordIndex()];
        var i = fields.len;
        while (i > 0) {
            i -= 1;
            const field = schema.fields[fields[i].index];
            if (field.boxed) try self.boxValue(self.program.nodes[@backingInt(fields[i].value)].span, field.ty);
            if (lent) try self.push(.{ .expression = fields[i].value }) else try self.transfer(fields[i].value, .store, null);
        }
    }
    /// The argument of a collection operation that the collection stores or
    /// hands back (`value_semantics.storedArgument`), or null. An in-place
    /// keyed sort names its own receiver as the source, which is no store.
    fn storedArgument(self: *Emitter, operation: @FieldType(@FieldType(typed.Node, "data"), "buffer_operation")) ?usize {
        const values = self.values orelse return null;
        const owner = values.function.scope.locals[@backingInt(operation.owner)].ty;
        const index = value_semantics.storedArgument(self.program.records, owner, operation.kind) orelse return null;
        if (index >= operation.arguments.len) return null;
        if (operation.kind == .sort_keyed) switch (self.program.nodes[@backingInt(operation.arguments[index])].data) {
            .local => |slot| if (slot == operation.owner) return null,
            else => {},
        };
        return index;
    }
    /// RECURSIVE-VALUES-2: wrap the value on top of the stack in a fresh box of
    /// type `box`. The box is a one-field managed record, so building it is
    /// an ordinary managed construction the collector and arenas already know.
    fn boxValue(self: *Emitter, span: Span, box: typed.Type) !void {
        try self.instruction(span, .{ .make_record = .{ .ty = box, .fields = 1 } });
    }
    /// Replace the box on top of the stack with the value it holds.
    fn unboxValue(self: *Emitter, span: Span) !void {
        try self.instruction(span, .{ .get_field = 0 });
    }
    /// The payload case `tag` of union `ty`, as the physical catalog lays it out.
    fn variantCase(self: *Emitter, ty: typed.Type, tag: usize) typed.Variant {
        return self.program.records[ty.recordIndex()].shape.variants.?.cases[tag];
    }
    /// Whether `?` on a value of `ty` hands on a boxed payload: an `Option`'s
    /// `Some` or a `Result`'s `Ok` case.
    fn propagatedBox(self: *Emitter, ty: typed.Type) bool {
        if (@import("prelude.zig").optionShape(ty, self.program.records)) |shape| return self.variantCase(ty, shape.some).boxed;
        const shape = typed.resultShape(ty, self.program.records) orelse return false;
        return self.variantCase(ty, shape.ok_tag).boxed;
    }
    /// COW-NESTED-1: give every dictionary read a local owner, so a later
    /// nested write can make that dictionary unique and publish its copy
    /// back into the collection or field it came from. The receiver still
    /// evaluates once, before the key; read-only paths need no COW checks.
    fn indexReceiver(self: *Emitter, id: typed.NodeId) !void {
        const node = self.program.nodes[@backingInt(id)];
        if (self.values != null and node.data != .local and node.ty.isAggregate() and
            self.program.records[node.ty.recordIndex()].collection.kind == .dictionary)
        {
            const owner = try self.hiddenLocal(node.ty, node.span, "<index-owner>");
            try self.instruction(node.span, .{ .load_local = owner });
            try self.instruction(node.span, .{ .store_local = owner });
        }
        try self.push(.{ .expression = id });
    }
    /// A dictionary key can be needed again after later array indices have
    /// overwritten its operand slot. Keep its value without rerunning it.
    fn indexKey(self: *Emitter, base: typed.NodeId, key: typed.NodeId, output: typed.Type) !void {
        const ty = self.program.nodes[@backingInt(base)].ty;
        const inline_result = output.isAggregate() and !self.program.records[output.recordIndex()].managed;
        if (self.values != null and ty.isAggregate() and self.program.records[ty.recordIndex()].collection.kind == .dictionary and inline_result) {
            const node = self.program.nodes[@backingInt(key)];
            const slot = try self.hiddenLocal(node.ty, node.span, "<index-key>");
            try self.instruction(node.span, .{ .load_local = slot });
            try self.instruction(node.span, .{ .store_local = slot });
        }
        try self.push(.{ .expression = key });
    }
    /// A hidden local for an intermediate value lowering must name.
    fn hiddenLocal(self: *Emitter, ty: typed.Type, span: Span, name: []const u8) !typed.LocalId {
        const id: typed.LocalId = @fromBackingInt(self.declared_locals + self.extra_locals.items.len);
        try self.extra_locals.append(self.scratch, .{ .name = name, .declaration = span, .ty = ty, .mutable = true, .usage = .{ .reads = 1, .temporary = true } });
        return id;
    }
    fn finish(self: *Emitter, body: typed.StatementId) ![]const bc.Instruction {
        defer self.work.deinit(self.scratch);
        defer self.labels.deinit(self.scratch);
        defer self.fixups.deinit(self.scratch);
        defer self.code.deinit(self.scratch);
        try self.push(.{ .statement = body });
        while (self.work.pop()) |task| switch (task) {
            .instruction => |inst| try self.code.append(self.scratch, inst),
            .statement => |id| try self.emitStatement(id),
            .expression => |id| {
                // Pushed first, so it runs once the whole operand is evaluated.
                if (self.snapshot(id)) try self.copyAfter(id, .argument);
                try self.emitExpression(id);
            },
            .propagate => |propagate| {
                try self.fixups.append(self.scratch, .{ .instruction = self.code.items.len, .label = propagate.target, .propagation = true });
                try self.code.append(self.scratch, .{ .span = propagate.span, .op = .{ .try_result = .{ .input = propagate.input, .output = propagate.output, .error_target = 0 } } });
            },
            .dispatch => |dispatch| {
                const arms = try self.allocator.alloc(bc.SwitchArm, dispatch.targets.len);
                for (dispatch.targets, dispatch.slots, arms, 0..) |target, slot, *arm, i| {
                    arm.* = .{ .target = 0, .slot = slot };
                    try self.fixups.append(self.scratch, .{ .instruction = self.code.items.len, .label = target, .arm = i });
                }
                try self.code.append(self.scratch, .{ .span = dispatch.span, .op = .{ .switch_variant = .{ .ty = dispatch.ty, .arms = arms, .borrowed = dispatch.borrowed } } });
            },
            .mark => |id| self.labels.items[@backingInt(id)] = self.code.items.len,
            .jump => |jump| {
                try self.fixups.append(self.scratch, .{ .instruction = self.code.items.len, .label = jump.target });
                try self.code.append(self.scratch, .{ .span = jump.span, .op = if (jump.conditional) .{ .jump_if_false = 0 } else .{ .jump = 0 } });
            },
        };
        for (self.fixups.items) |fixup| {
            const target = self.labels.items[@backingInt(fixup.label)] orelse return error.InternalError;
            const inst = &self.code.items[fixup.instruction];
            // Dispatch arms were allocated by this emitter and are not shared yet.
            if (fixup.propagation) {
                inst.op.try_result.error_target = target;
            } else if (fixup.arm) |arm| {
                @constCast(inst.op.switch_variant.arms)[arm].target = target;
            } else if (inst.op == .jump) {
                inst.op.jump = target;
            } else {
                inst.op.jump_if_false = target;
            }
        }
        return self.allocator.dupe(bc.Instruction, self.code.items);
    }
};
fn binaryInstruction(binary: anytype, nodes: []const typed.Node, records: []const typed.Record) bc.Instruction {
    const operand_type = nodes[@backingInt(binary.left)].ty;
    if (operand_type.isAggregate() and records[operand_type.recordIndex()].managed) return .{ .span = binary.op_span, .op = .{ .binary_integer = .{ .ty = operand_type, .op = binary.op } } };
    if (operand_type.isAggregate() and records[operand_type.recordIndex()].shape.domain != null) return .{ .span = binary.op_span, .op = .{ .cmp_domain = .{ .ty = operand_type, .predicate = if (binary.op == .eq) .eq else .ne } } };
    // A payload-free enum compares its tag; a record, fixed array, union, Result or
    // Option compares structurally through the shared native equality runtime.
    if (operand_type.isAggregate() and records[operand_type.recordIndex()].isEnum()) return .{ .span = binary.op_span, .op = .{ .cmp_enum = .{ .ty = operand_type, .predicate = if (binary.op == .eq) .eq else .ne } } };
    if (operand_type.isAggregate()) return .{ .span = binary.op_span, .op = .{ .binary_integer = .{ .ty = operand_type, .op = binary.op } } };
    if (operand_type.isInteger() and operand_type != .i64)
        return .{ .span = binary.op_span, .op = .{ .binary_integer = .{ .ty = operand_type, .op = binary.op } } };
    return .{ .span = binary.op_span, .op = switch (binary.op) {
        .add => .add_i64_checked,
        .sub => .sub_i64_checked,
        .mul => .mul_i64_checked,
        .div => .div_i64_checked,
        .rem => .rem_i64_checked,
        .floor_div,
        .floor_rem,
        .f64_add,
        .f64_sub,
        .f64_mul,
        .f64_div,
        .f64_eq,
        .f64_lt,
        .f64_le,
        .bit_and,
        .bit_or,
        .bit_xor,
        .shift_left,
        .shift_right,
        .wrapping_add,
        .wrapping_sub,
        .wrapping_mul,
        .saturating_add,
        .saturating_sub,
        .saturating_mul,
        => .{ .binary_integer = .{ .ty = operand_type, .op = binary.op } },
        .eq, .ne => if (nodes[@backingInt(binary.left)].ty == .bool)
            .{ .cmp_bool = if (binary.op == .eq) .eq else .ne }
        else
            .{ .cmp_i64 = if (binary.op == .eq) .eq else .ne },
        .lt, .le, .gt, .ge => .{ .cmp_i64 = std.meta.stringToEnum(bc.Predicate, @tagName(binary.op)).? },
        .logical_and, .logical_or => unreachable,
    } };
}
/// Allocate and validate bytecode lowered from the checked typed program.
pub fn lower(allocator: std.mem.Allocator, program: typed.Program) LowerError!bc.Program {
    return lowerWith(.{ .output = allocator, .scratch = allocator }, program, false);
}

/// Lower with an explicit `debug` policy: a ReleaseFast build drops the nodes.
pub fn lowerWith(allocators: Allocators, checked: typed.Program, drop_debug: bool) LowerError!bc.Program {
    const allocator = allocators.output;
    const program = try physical(allocator, checked);
    var scratch = std.heap.ArenaAllocator.init(allocators.scratch);
    defer scratch.deinit();
    const functions = try allocator.alloc(bc.Function, program.functions.len);
    for (program.functions, 0..) |function, index| {
        defer _ = scratch.reset(.free_all);
        functions[index] = try lowerFunction(.{ .output = allocator, .scratch = scratch.allocator() }, program, function, true, drop_debug);
    }
    const result: bc.Program = .{ .functions = functions, .main = program.main, .records = program.records };
    // Validation's tables are temporary too.
    try bc.validate(scratch.allocator(), result);
    return result;
}

/// Allocate a selective bytecode program. Selected functions carry lowered
/// instructions; every other entry keeps its checked policy, signature and
/// locals so callers can resolve callee ABIs without lowering that body. The
/// selection mask is caller-owned and must remain live through validation.
pub fn lowerSelected(allocator: std.mem.Allocator, program: typed.Program, selected: []const bool) LowerError!bc.Program {
    return lowerSelectedWith(.{ .output = allocator, .scratch = allocator }, program, selected, false);
}

/// Selective lowering with an explicit `debug` policy.
pub fn lowerSelectedWith(allocators: Allocators, checked: typed.Program, selected: []const bool, drop_debug: bool) LowerError!bc.Program {
    if (selected.len != checked.functions.len) return error.InternalError;
    const allocator = allocators.output;
    const program = try physical(allocator, checked);
    var scratch = std.heap.ArenaAllocator.init(allocators.scratch);
    defer scratch.deinit();
    const functions = try allocator.alloc(bc.Function, program.functions.len);
    for (program.functions, 0..) |function, index| {
        defer _ = scratch.reset(.free_all);
        functions[index] = try lowerFunction(.{ .output = allocator, .scratch = scratch.allocator() }, program, function, selected[index], drop_debug);
    }
    const result: bc.Program = .{ .functions = functions, .main = program.main, .records = program.records };
    bc.validateSelected(scratch.allocator(), result, selected) catch |err| return if (err == error.OutOfMemory) error.OutOfMemory else error.InternalError;
    return result;
}

/// The checked program against the physical catalog (RECURSIVE-VALUES-2):
/// identical unless some schema boxes a recursive field, in which case boxed
/// fields and cases name their box records and those records are appended.
fn physical(allocator: std.mem.Allocator, checked: typed.Program) std.mem.Allocator.Error!typed.Program {
    var program = checked;
    program.records = try @import("recursive_boxes.zig").physical(allocator, checked.records);
    return program;
}

/// LOWER-EXACT-1: the allocator the lowered program lives in, and a freeing
/// allocator the per-function scratch arena draws from, which holds every
/// emitter list and validation table and is reset after each function.
pub const Allocators = struct { output: std.mem.Allocator, scratch: std.mem.Allocator };

fn lowerFunction(allocators: Allocators, program: typed.Program, function: typed.Function, with_body: bool, drop_debug: bool) LowerError!bc.Function {
    var emitter: Emitter = .{ .allocator = allocators.output, .scratch = allocators.scratch, .program = program, .drop_debug = drop_debug, .declared_locals = function.scope.locals.len };
    defer emitter.loops.deinit(allocators.scratch);
    var facts: value_semantics.Facts = undefined;
    var snapshots: evaluation_order.Snapshots = undefined;
    if (value_semantics.enabled() and with_body and function.policy.host == null) {
        facts = try value_semantics.Facts.collect(allocators.scratch, program, function);
        emitter.values = &facts;
        snapshots = try evaluation_order.find(allocators.scratch, &facts);
        emitter.snapshots = &snapshots;
    }
    defer emitter.extra_locals.deinit(allocators.scratch);
    const instructions = if (with_body and function.policy.host == null) try emitter.finish(function.scope.body) else &.{};
    // Hidden locals follow the checked ones, so every checked slot keeps its id.
    const locals = if (emitter.extra_locals.items.len == 0) function.scope.locals else try std.mem.concat(allocators.output, typed.Local, &.{ function.scope.locals, emitter.extra_locals.items });
    return .{
        .policy = .{
            .host = function.policy.host,
            .c_abi = function.policy.c_abi,
            .effect_bound = function.policy.effect_bound,
            .effects = function.policy.effects,
            .owner = function.policy.owner,
            .restricted = function.policy.restricted,
            .conversion = function.policy.conversion,
        },
        .signature = .{
            .parameter_count = function.signature.parameter_count,
            .return_type = function.signature.return_type,
            .mutates = function.signature.mutates,
            .return_origin = function.signature.return_origin,
            .declared_mutates = function.signature.declared_mutates,
            .inferred = function.signature.inferred,
        },
        .scope = .{
            .locals = locals,
            .instructions = instructions,
        },
        .id = function.id,
        .name = function.name,
    };
}
