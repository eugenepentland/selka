from pathlib import Path
import subprocess,os,json,hashlib
w=Path(__file__).resolve().parent
script=w/'native/validation-inputs/instantiation.tree.smoke.lox'
control=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-lox-parity-vm-20261003/.tmp-lox-ast-carrier-20261003/build-fixed-qbe-gc/qbe-gc')
env={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};env['MYLANG_OPTIONS']='--gc-stress'
report={'scope':'Exact prior timed-out native GC stress instantiation smoke isolated afterunit/public finish; correctness only','input_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'runs':[]}
for name,binary in [('candidate',w/'native-policy-complete-gc-qbe'),('control',control)]:
 args=[str(binary),'--engine=tree','--stats',str(script)]
 try:
  result=subprocess.run(args,env=env,capture_output=True,timeout=240);row={'name':name,'argv':args,'status':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode(),'timeout':False}
 except subprocess.TimeoutExpired as e:row={'name':name,'argv':args,'status':None,'stdout':(e.stdout or b'').decode(),'stderr':(e.stderr or b'').decode(),'timeout':True}
 row['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();report['runs'].append(row);(w/'native-timeout-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
if not any(r['timeout'] for r in report['runs']):
 assert {k:report['runs'][0][k] for k in ['status','stdout','stderr']}=={k:report['runs'][1][k] for k in ['status','stdout','stderr']}
 print('isolated candidate/control streams exact')
else:print('timeout retained; no full cell pass claim')
