define ptr @myl_core_values_copy_box(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 align 64 {
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.core_copy_stack, align 8
  %9 = alloca ptr, align 8
  store ptr %1, ptr %7, align 8, !tbaa !38
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #75
  %10 = getelementptr inbounds nuw i8, ptr %8, i64 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1552) %10, i8 0, i64 1552, i1 false)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 24
  store ptr %11, ptr %8, align 8, !tbaa !740
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 16
  store i64 64, ptr %12, align 8, !tbaa !742
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #75
  store ptr null, ptr %9, align 8, !tbaa !38
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %14 = load i32, ptr %13, align 4, !tbaa !706
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %567, label %16

16:                                               ; preds = %2
  store ptr %0, ptr %11, align 8, !tbaa !700
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 32
  store ptr %7, ptr %17, align 8, !tbaa !111
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 40
  store ptr %9, ptr %18, align 8, !tbaa !111
  %19 = getelementptr inbounds nuw i8, ptr %8, i64 8
  br label %20

20:                                               ; preds = %16, %560
  %21 = phi i64 [ %561, %560 ], [ 1, %16 ]
  %22 = load ptr, ptr %8, align 8, !tbaa !740
  %23 = add i64 %21, -1
  store i64 %23, ptr %19, align 8, !tbaa !743
  %24 = getelementptr inbounds nuw %struct.core_copy_work, ptr %22, i64 %23
  %25 = load ptr, ptr %24, align 8, !tbaa !700
  %26 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %27 = load ptr, ptr %26, align 8, !tbaa !111
  %28 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %29 = load ptr, ptr %28, align 8, !tbaa !111
  %30 = getelementptr inbounds nuw i8, ptr %25, i64 4
  %31 = load i32, ptr %30, align 4, !tbaa !706
  %32 = zext i32 %31 to i64
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %29, ptr align 1 %27, i64 %32, i1 false)
  %33 = load i32, ptr %25, align 8, !tbaa !702
  switch i32 %33, label %559 [
    i32 0, label %560
    i32 1, label %560
    i32 2, label %560
    i32 3, label %41
    i32 4, label %34
    i32 5, label %165
    i32 6, label %231
    i32 7, label %231
    i32 9, label %231
    i32 8, label %488
    i32 10, label %554
  ]

34:                                               ; preds = %20
  %35 = getelementptr inbounds nuw i8, ptr %25, i64 8
  %36 = load i32, ptr %35, align 8, !tbaa !705
  %37 = icmp eq i32 %36, 0
  br i1 %37, label %560, label %38

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %40 = getelementptr inbounds nuw i8, ptr %25, i64 24
  br label %106

41:                                               ; preds = %20
  %42 = load ptr, ptr %27, align 1
  %43 = icmp eq ptr %42, null
  br i1 %43, label %560, label %44

44:                                               ; preds = %41
  %45 = load i32, ptr %42, align 8, !tbaa !33
  %46 = and i32 %45, 255
  %47 = icmp eq i32 %46, 5
  br i1 %47, label %48, label %61

48:                                               ; preds = %44
  %49 = getelementptr inbounds nuw i8, ptr %42, i64 16
  %50 = load i64, ptr %49, align 8, !tbaa !32
  %51 = icmp slt i64 %50, 0
  br i1 %51, label %52, label %53

52:                                               ; preds = %48
  call fastcc void @out_of_memory()
  unreachable

53:                                               ; preds = %48
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #75
  %54 = call fastcc noundef ptr @block_alloc(i32 noundef 5, i64 noundef %50, ptr noundef %6)
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 16
  store i64 %50, ptr %55, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #75
  %56 = getelementptr inbounds nuw i8, ptr %42, i64 8
  %57 = load i64, ptr %56, align 8, !tbaa !28
  %58 = getelementptr inbounds nuw i8, ptr %54, i64 8
  store i64 %57, ptr %58, align 8, !tbaa !28
  %59 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %60 = getelementptr inbounds nuw i8, ptr %42, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %59, ptr nonnull readonly align 1 %60, i64 %57, i1 false)
  br label %104

61:                                               ; preds = %44
  %62 = getelementptr inbounds nuw i8, ptr %42, i64 8
  %63 = load i64, ptr %62, align 8, !tbaa !28
  %64 = icmp sgt i64 %63, -1
  br i1 %64, label %66, label %65

65:                                               ; preds = %61
  call fastcc void @out_of_memory()
  unreachable

66:                                               ; preds = %61
  %67 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %68 = add nuw i64 %63, 1
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #75
  %69 = call fastcc ptr @block_alloc(i32 noundef 1, i64 noundef %68, ptr noundef %5)
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 16
  store i64 %63, ptr %70, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #75
  %71 = getelementptr inbounds nuw i8, ptr %69, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %71, ptr nonnull readonly align 1 %67, i64 %63, i1 false)
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 %63
  store i8 0, ptr %72, align 1, !tbaa !39
  %73 = getelementptr inbounds nuw i8, ptr %69, i64 8
  store i64 %63, ptr %73, align 8, !tbaa !28
  %74 = load i32, ptr %69, align 8, !tbaa !33
  %75 = and i32 %74, -7937
  store i32 %75, ptr %69, align 8, !tbaa !33
  %76 = getelementptr inbounds nuw i8, ptr %69, i64 24
  store i64 0, ptr %76, align 8, !tbaa !35
  br label %77

77:                                               ; preds = %83, %66
  %78 = phi i64 [ 0, %66 ], [ %79, %83 ]
  %79 = add i64 %78, 8
  %80 = icmp ugt i64 %79, %63
  br i1 %80, label %81, label %83

81:                                               ; preds = %77
  %82 = icmp ult i64 %78, %63
  br i1 %82, label %91, label %96

83:                                               ; preds = %77
  %84 = getelementptr inbounds nuw i8, ptr %71, i64 %78
  %85 = load i64, ptr %84, align 1
  %86 = and i64 %85, -9187201950435737472
  %87 = icmp eq i64 %86, 0
  br i1 %87, label %77, label %98, !llvm.loop !106

88:                                               ; preds = %91
  %89 = add i64 %92, 1
  %90 = icmp eq i64 %89, %63
  br i1 %90, label %96, label %91, !llvm.loop !107

91:                                               ; preds = %81, %88
  %92 = phi i64 [ %89, %88 ], [ %78, %81 ]
  %93 = getelementptr inbounds nuw i8, ptr %71, i64 %92
  %94 = load i8, ptr %93, align 1, !tbaa !39
  %95 = icmp sgt i8 %94, -1
  br i1 %95, label %88, label %98

96:                                               ; preds = %88, %81
  %97 = or disjoint i32 %75, 256
  store i32 %97, ptr %69, align 8, !tbaa !33
  br label %98

98:                                               ; preds = %83, %91, %96
  %99 = phi i32 [ %75, %91 ], [ %97, %96 ], [ %75, %83 ]
  %100 = and i32 %99, -256
  %101 = load i32, ptr %42, align 8, !tbaa !33
  %102 = and i32 %101, 255
  %103 = or disjoint i32 %102, %100
  store i32 %103, ptr %69, align 8, !tbaa !33
  br label %104

104:                                              ; preds = %98, %53
  %105 = phi ptr [ %54, %53 ], [ %69, %98 ]
  store ptr %105, ptr %29, align 1
  br label %560

106:                                              ; preds = %38, %159
  %107 = phi i32 [ %36, %38 ], [ %160, %159 ]
  %108 = phi i32 [ %36, %38 ], [ %161, %159 ]
  %109 = phi i64 [ 0, %38 ], [ %162, %159 ]
  %110 = load ptr, ptr %39, align 8, !tbaa !707
  %111 = getelementptr inbounds nuw ptr, ptr %110, i64 %109
  %112 = load ptr, ptr %111, align 8, !tbaa !700
  %113 = load ptr, ptr %40, align 8, !tbaa !708
  %114 = getelementptr inbounds nuw i32, ptr %113, i64 %109
  %115 = load i32, ptr %114, align 4, !tbaa !6
  %116 = zext i32 %115 to i64
  %117 = getelementptr inbounds nuw i8, ptr %27, i64 %116
  %118 = getelementptr inbounds nuw i8, ptr %29, i64 %116
  %119 = load i32, ptr %112, align 8, !tbaa !702
  %120 = icmp ult i32 %119, 3
  br i1 %120, label %159, label %121

121:                                              ; preds = %106
  %122 = getelementptr inbounds nuw i8, ptr %112, i64 4
  %123 = load i32, ptr %122, align 4, !tbaa !706
  %124 = icmp eq i32 %123, 0
  br i1 %124, label %159, label %125

125:                                              ; preds = %121
  %126 = load i64, ptr %19, align 8, !tbaa !743
  %127 = load i64, ptr %12, align 8, !tbaa !742
  %128 = icmp eq i64 %126, %127
  br i1 %128, label %131, label %129

129:                                              ; preds = %125
  %130 = load ptr, ptr %8, align 8, !tbaa !740
  br label %151

131:                                              ; preds = %125
  %132 = shl i64 %126, 1
  %133 = icmp slt i64 %126, 0
  %134 = icmp ugt i64 %132, 768614336404564650
  %135 = or i1 %133, %134
  br i1 %135, label %136, label %137

136:                                              ; preds = %131
  call fastcc void @out_of_memory()
  unreachable

137:                                              ; preds = %131
  %138 = mul i64 %126, 48
  %139 = call noalias ptr @malloc(i64 noundef %138) #81
  %140 = icmp eq ptr %139, null
  br i1 %140, label %141, label %142

141:                                              ; preds = %137
  call fastcc void @out_of_memory()
  unreachable

142:                                              ; preds = %137
  %143 = load ptr, ptr %8, align 8, !tbaa !740
  %144 = mul i64 %126, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %139, ptr align 8 %143, i64 %144, i1 false)
  %145 = icmp eq ptr %143, %11
  br i1 %145, label %148, label %146

146:                                              ; preds = %142
  call void @free(ptr noundef %143) #75
  %147 = load i64, ptr %19, align 8, !tbaa !743
  br label %148

148:                                              ; preds = %146, %142
  %149 = phi i64 [ %147, %146 ], [ %126, %142 ]
  store ptr %139, ptr %8, align 8, !tbaa !740
  store i64 %132, ptr %12, align 8, !tbaa !742
  %150 = load i32, ptr %35, align 8, !tbaa !705
  br label %151

151:                                              ; preds = %148, %129
  %152 = phi i32 [ %107, %129 ], [ %150, %148 ]
  %153 = phi i64 [ %126, %129 ], [ %149, %148 ]
  %154 = phi ptr [ %130, %129 ], [ %139, %148 ]
  %155 = add i64 %153, 1
  store i64 %155, ptr %19, align 8, !tbaa !743
  %156 = getelementptr inbounds nuw %struct.core_copy_work, ptr %154, i64 %153
  store ptr %112, ptr %156, align 8, !tbaa !700
  %157 = getelementptr inbounds nuw i8, ptr %156, i64 8
  store ptr %117, ptr %157, align 8, !tbaa !111
  %158 = getelementptr inbounds nuw i8, ptr %156, i64 16
  store ptr %118, ptr %158, align 8, !tbaa !111
  br label %159

159:                                              ; preds = %151, %121, %106
  %160 = phi i32 [ %152, %151 ], [ %107, %121 ], [ %107, %106 ]
  %161 = phi i32 [ %152, %151 ], [ %108, %121 ], [ %108, %106 ]
  %162 = add nuw nsw i64 %109, 1
  %163 = zext i32 %161 to i64
  %164 = icmp samesign ult i64 %162, %163
  br i1 %164, label %106, label %560, !llvm.loop !744

165:                                              ; preds = %20
  %166 = getelementptr inbounds nuw i8, ptr %25, i64 12
  %167 = load i32, ptr %166, align 4, !tbaa !710
  %168 = icmp eq i32 %167, 0
  br i1 %168, label %176, label %169

169:                                              ; preds = %165
  %170 = load ptr, ptr %27, align 1
  %171 = icmp eq ptr %170, null
  %172 = sub i32 2, %167
  %173 = add i32 %167, -1
  %174 = select i1 %171, i32 %173, i32 %172
  %175 = zext i32 %174 to i64
  br label %178

176:                                              ; preds = %165
  %177 = load i64, ptr %27, align 1
  br label %178

178:                                              ; preds = %169, %176
  %179 = phi i64 [ %175, %169 ], [ %177, %176 ]
  %180 = getelementptr inbounds nuw i8, ptr %25, i64 8
  %181 = load i32, ptr %180, align 8, !tbaa !705
  %182 = zext i32 %181 to i64
  %183 = icmp ult i64 %179, %182
  br i1 %183, label %185, label %184

184:                                              ; preds = %178
  call void @abort() #79
  unreachable

185:                                              ; preds = %178
  %186 = select i1 %168, i64 8, i64 0
  %187 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %188 = load ptr, ptr %187, align 8, !tbaa !707
  %189 = getelementptr inbounds nuw ptr, ptr %188, i64 %179
  %190 = load ptr, ptr %189, align 8, !tbaa !700
  %191 = getelementptr inbounds nuw i8, ptr %27, i64 %186
  %192 = getelementptr inbounds nuw i8, ptr %29, i64 %186
  %193 = load i32, ptr %190, align 8, !tbaa !702
  %194 = icmp ult i32 %193, 3
  br i1 %194, label %560, label %195

195:                                              ; preds = %185
  %196 = getelementptr inbounds nuw i8, ptr %190, i64 4
  %197 = load i32, ptr %196, align 4, !tbaa !706
  %198 = icmp eq i32 %197, 0
  br i1 %198, label %560, label %199

199:                                              ; preds = %195
  %200 = load i64, ptr %19, align 8, !tbaa !743
  %201 = load i64, ptr %12, align 8, !tbaa !742
  %202 = icmp eq i64 %200, %201
  br i1 %202, label %205, label %203

203:                                              ; preds = %199
  %204 = load ptr, ptr %8, align 8, !tbaa !740
  br label %224

205:                                              ; preds = %199
  %206 = shl i64 %200, 1
  %207 = icmp slt i64 %200, 0
  %208 = icmp ugt i64 %206, 768614336404564650
  %209 = or i1 %207, %208
  br i1 %209, label %210, label %211

210:                                              ; preds = %205
  call fastcc void @out_of_memory()
  unreachable

211:                                              ; preds = %205
  %212 = mul i64 %200, 48
  %213 = call noalias ptr @malloc(i64 noundef %212) #81
  %214 = icmp eq ptr %213, null
  br i1 %214, label %215, label %216

215:                                              ; preds = %211
  call fastcc void @out_of_memory()
  unreachable

216:                                              ; preds = %211
  %217 = load ptr, ptr %8, align 8, !tbaa !740
  %218 = mul i64 %200, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %213, ptr align 8 %217, i64 %218, i1 false)
  %219 = icmp eq ptr %217, %11
  br i1 %219, label %222, label %220

220:                                              ; preds = %216
  call void @free(ptr noundef %217) #75
  %221 = load i64, ptr %19, align 8, !tbaa !743
  br label %222

222:                                              ; preds = %220, %216
  %223 = phi i64 [ %221, %220 ], [ %200, %216 ]
  store ptr %213, ptr %8, align 8, !tbaa !740
  store i64 %206, ptr %12, align 8, !tbaa !742
  br label %224

224:                                              ; preds = %222, %203
  %225 = phi i64 [ %200, %203 ], [ %223, %222 ]
  %226 = phi ptr [ %204, %203 ], [ %213, %222 ]
  %227 = add i64 %225, 1
  store i64 %227, ptr %19, align 8, !tbaa !743
  %228 = getelementptr inbounds nuw %struct.core_copy_work, ptr %226, i64 %225
  store ptr %190, ptr %228, align 8, !tbaa !700
  %229 = getelementptr inbounds nuw i8, ptr %228, i64 8
  store ptr %191, ptr %229, align 8, !tbaa !111
  %230 = getelementptr inbounds nuw i8, ptr %228, i64 16
  store ptr %192, ptr %230, align 8, !tbaa !111
  br label %560

231:                                              ; preds = %20, %20, %20
  %232 = load ptr, ptr %27, align 1
  %233 = icmp eq ptr %232, null
  br i1 %233, label %560, label %234

234:                                              ; preds = %231
  %235 = icmp eq i32 %33, 9
  br i1 %235, label %236, label %388

236:                                              ; preds = %234
  %237 = call fastcc ptr @core_dict_copy_storage(ptr noundef nonnull %232)
  %238 = getelementptr inbounds nuw i8, ptr %232, i64 24
  %239 = load i64, ptr %238, align 8, !tbaa !35
  %240 = inttoptr i64 %239 to ptr
  %241 = getelementptr inbounds nuw i8, ptr %240, i64 32
  %242 = load i64, ptr %241, align 8, !tbaa !95
  %243 = icmp eq i64 %242, 0
  br i1 %243, label %486, label %244

244:                                              ; preds = %236
  %245 = getelementptr inbounds nuw i8, ptr %240, i64 24
  %246 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %247 = getelementptr inbounds nuw i8, ptr %232, i64 32
  %248 = getelementptr inbounds nuw i8, ptr %237, i64 32
  %249 = getelementptr inbounds nuw i8, ptr %237, i64 24
  br label %250

250:                                              ; preds = %384, %244
  %251 = phi i64 [ %242, %244 ], [ %385, %384 ]
  %252 = phi i64 [ 0, %244 ], [ %386, %384 ]
  %253 = load ptr, ptr %245, align 8, !tbaa !96
  %254 = icmp eq ptr %253, null
  br i1 %254, label %265, label %255

255:                                              ; preds = %250
  %256 = lshr i64 %252, 3
  %257 = getelementptr inbounds nuw i8, ptr %253, i64 %256
  %258 = load i8, ptr %257, align 1, !tbaa !39
  %259 = zext i8 %258 to i32
  %260 = trunc i64 %252 to i32
  %261 = and i32 %260, 7
  %262 = shl nuw nsw i32 1, %261
  %263 = and i32 %262, %259
  %264 = icmp eq i32 %263, 0
  br i1 %264, label %265, label %384

265:                                              ; preds = %255, %250
  %266 = load ptr, ptr %246, align 8, !tbaa !707
  %267 = load ptr, ptr %266, align 8, !tbaa !700
  %268 = load i64, ptr %238, align 8, !tbaa !35
  %269 = inttoptr i64 %268 to ptr
  %270 = load ptr, ptr %269, align 8, !tbaa !89
  %271 = load i32, ptr %270, align 8, !tbaa !97
  %272 = zext i32 %271 to i64
  %273 = mul i64 %252, %272
  %274 = getelementptr inbounds nuw i8, ptr %247, i64 %273
  %275 = load i64, ptr %249, align 8, !tbaa !35
  %276 = inttoptr i64 %275 to ptr
  %277 = load ptr, ptr %276, align 8, !tbaa !89
  %278 = load i32, ptr %277, align 8, !tbaa !97
  %279 = zext i32 %278 to i64
  %280 = mul i64 %252, %279
  %281 = getelementptr inbounds nuw i8, ptr %248, i64 %280
  %282 = getelementptr inbounds nuw i8, ptr %267, i64 4
  %283 = load i32, ptr %282, align 4, !tbaa !706
  %284 = icmp eq i32 %283, 0
  br i1 %284, label %333, label %285

285:                                              ; preds = %265
  %286 = load i64, ptr %19, align 8, !tbaa !743
  %287 = load i64, ptr %12, align 8, !tbaa !742
  %288 = icmp eq i64 %286, %287
  br i1 %288, label %291, label %289

289:                                              ; preds = %285
  %290 = load ptr, ptr %8, align 8, !tbaa !740
  br label %323

291:                                              ; preds = %285
  %292 = shl i64 %286, 1
  %293 = icmp slt i64 %286, 0
  %294 = icmp ugt i64 %292, 768614336404564650
  %295 = or i1 %293, %294
  br i1 %295, label %296, label %297

296:                                              ; preds = %291
  call fastcc void @out_of_memory()
  unreachable

297:                                              ; preds = %291
  %298 = mul i64 %286, 48
  %299 = call noalias ptr @malloc(i64 noundef %298) #81
  %300 = icmp eq ptr %299, null
  br i1 %300, label %301, label %302

301:                                              ; preds = %297
  call fastcc void @out_of_memory()
  unreachable

302:                                              ; preds = %297
  %303 = load ptr, ptr %8, align 8, !tbaa !740
  %304 = mul i64 %286, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %299, ptr align 8 %303, i64 %304, i1 false)
  %305 = icmp eq ptr %303, %11
  br i1 %305, label %308, label %306

306:                                              ; preds = %302
  call void @free(ptr noundef %303) #75
  %307 = load i64, ptr %19, align 8, !tbaa !743
  br label %308

308:                                              ; preds = %306, %302
  %309 = phi i64 [ %307, %306 ], [ %286, %302 ]
  store ptr %299, ptr %8, align 8, !tbaa !740
  store i64 %292, ptr %12, align 8, !tbaa !742
  %310 = load ptr, ptr %246, align 8, !tbaa !707
  %311 = load i64, ptr %238, align 8, !tbaa !35
  %312 = inttoptr i64 %311 to ptr
  %313 = load ptr, ptr %312, align 8, !tbaa !89
  %314 = load i32, ptr %313, align 8, !tbaa !97
  %315 = load i64, ptr %249, align 8, !tbaa !35
  %316 = inttoptr i64 %315 to ptr
  %317 = load ptr, ptr %316, align 8, !tbaa !89
  %318 = load i32, ptr %317, align 8, !tbaa !97
  %319 = zext i32 %314 to i64
  %320 = mul i64 %252, %319
  %321 = zext i32 %318 to i64
  %322 = mul i64 %252, %321
  br label %323

323:                                              ; preds = %308, %289
  %324 = phi i64 [ %322, %308 ], [ %280, %289 ]
  %325 = phi i64 [ %320, %308 ], [ %273, %289 ]
  %326 = phi ptr [ %310, %308 ], [ %266, %289 ]
  %327 = phi i64 [ %309, %308 ], [ %286, %289 ]
  %328 = phi ptr [ %299, %308 ], [ %290, %289 ]
  %329 = add i64 %327, 1
  store i64 %329, ptr %19, align 8, !tbaa !743
  %330 = getelementptr inbounds nuw %struct.core_copy_work, ptr %328, i64 %327
  store ptr %267, ptr %330, align 8, !tbaa !700
  %331 = getelementptr inbounds nuw i8, ptr %330, i64 8
  store ptr %274, ptr %331, align 8, !tbaa !111
  %332 = getelementptr inbounds nuw i8, ptr %330, i64 16
  store ptr %281, ptr %332, align 8, !tbaa !111
  br label %333

333:                                              ; preds = %265, %323
  %334 = phi i64 [ %280, %265 ], [ %324, %323 ]
  %335 = phi i64 [ %273, %265 ], [ %325, %323 ]
  %336 = phi ptr [ %266, %265 ], [ %326, %323 ]
  %337 = getelementptr inbounds nuw i8, ptr %336, i64 8
  %338 = load ptr, ptr %337, align 8, !tbaa !700
  %339 = getelementptr inbounds nuw i8, ptr %247, i64 %335
  %340 = load ptr, ptr %240, align 8, !tbaa !89
  %341 = getelementptr inbounds nuw i8, ptr %340, i64 4
  %342 = load i32, ptr %341, align 4, !tbaa !314
  %343 = zext i32 %342 to i64
  %344 = getelementptr inbounds nuw i8, ptr %339, i64 %343
  %345 = getelementptr inbounds nuw i8, ptr %248, i64 %334
  %346 = getelementptr inbounds nuw i8, ptr %345, i64 %343
  %347 = getelementptr inbounds nuw i8, ptr %338, i64 4
  %348 = load i32, ptr %347, align 4, !tbaa !706
  %349 = icmp eq i32 %348, 0
  br i1 %349, label %382, label %350

350:                                              ; preds = %333
  %351 = load i64, ptr %19, align 8, !tbaa !743
  %352 = load i64, ptr %12, align 8, !tbaa !742
  %353 = icmp eq i64 %351, %352
  br i1 %353, label %356, label %354

354:                                              ; preds = %350
  %355 = load ptr, ptr %8, align 8, !tbaa !740
  br label %375

356:                                              ; preds = %350
  %357 = shl i64 %351, 1
  %358 = icmp slt i64 %351, 0
  %359 = icmp ugt i64 %357, 768614336404564650
  %360 = or i1 %358, %359
  br i1 %360, label %361, label %362

361:                                              ; preds = %356
  call fastcc void @out_of_memory()
  unreachable

362:                                              ; preds = %356
  %363 = mul i64 %351, 48
  %364 = call noalias ptr @malloc(i64 noundef %363) #81
  %365 = icmp eq ptr %364, null
  br i1 %365, label %366, label %367

366:                                              ; preds = %362
  call fastcc void @out_of_memory()
  unreachable

367:                                              ; preds = %362
  %368 = load ptr, ptr %8, align 8, !tbaa !740
  %369 = mul i64 %351, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %364, ptr align 8 %368, i64 %369, i1 false)
  %370 = icmp eq ptr %368, %11
  br i1 %370, label %373, label %371

371:                                              ; preds = %367
  call void @free(ptr noundef %368) #75
  %372 = load i64, ptr %19, align 8, !tbaa !743
  br label %373

373:                                              ; preds = %371, %367
  %374 = phi i64 [ %372, %371 ], [ %351, %367 ]
  store ptr %364, ptr %8, align 8, !tbaa !740
  store i64 %357, ptr %12, align 8, !tbaa !742
  br label %375

375:                                              ; preds = %373, %354
  %376 = phi i64 [ %351, %354 ], [ %374, %373 ]
  %377 = phi ptr [ %355, %354 ], [ %364, %373 ]
  %378 = add i64 %376, 1
  store i64 %378, ptr %19, align 8, !tbaa !743
  %379 = getelementptr inbounds nuw %struct.core_copy_work, ptr %377, i64 %376
  store ptr %338, ptr %379, align 8, !tbaa !700
  %380 = getelementptr inbounds nuw i8, ptr %379, i64 8
  store ptr %344, ptr %380, align 8, !tbaa !111
  %381 = getelementptr inbounds nuw i8, ptr %379, i64 16
  store ptr %346, ptr %381, align 8, !tbaa !111
  br label %382

382:                                              ; preds = %333, %375
  %383 = load i64, ptr %241, align 8, !tbaa !95
  br label %384

384:                                              ; preds = %382, %255
  %385 = phi i64 [ %251, %255 ], [ %383, %382 ]
  %386 = add nuw i64 %252, 1
  %387 = icmp ult i64 %386, %385
  br i1 %387, label %250, label %486, !llvm.loop !745

388:                                              ; preds = %234
  %389 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %390 = load ptr, ptr %389, align 8, !tbaa !707
  %391 = load ptr, ptr %390, align 8, !tbaa !700
  %392 = icmp eq i32 %33, 6
  br i1 %392, label %393, label %405

393:                                              ; preds = %388
  %394 = getelementptr inbounds nuw i8, ptr %391, i64 4
  %395 = load i32, ptr %394, align 4, !tbaa !706
  %396 = zext i32 %395 to i64
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #75
  %397 = call fastcc ptr @block_alloc(i32 noundef 2, i64 noundef %396, ptr noundef %4)
  %398 = getelementptr inbounds nuw i8, ptr %397, i64 16
  store i64 %396, ptr %398, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #75
  %399 = getelementptr inbounds nuw i8, ptr %397, i64 8
  store i64 %396, ptr %399, align 8, !tbaa !28
  %400 = getelementptr inbounds nuw i8, ptr %232, i64 24
  %401 = load i64, ptr %400, align 8, !tbaa !35
  %402 = getelementptr inbounds nuw i8, ptr %397, i64 24
  store i64 %401, ptr %402, align 8, !tbaa !35
  %403 = getelementptr inbounds nuw i8, ptr %232, i64 8
  %404 = load i64, ptr %403, align 8, !tbaa !28
  store i64 %404, ptr %399, align 8, !tbaa !28
  br label %437

405:                                              ; preds = %388
  %406 = getelementptr inbounds nuw i8, ptr %232, i64 8
  %407 = load i64, ptr %406, align 8, !tbaa !28
  %408 = getelementptr inbounds nuw i8, ptr %391, i64 4
  %409 = load i32, ptr %408, align 4, !tbaa !706
  %410 = zext i32 %409 to i64
  %411 = icmp sgt i64 %407, -1
  br i1 %411, label %413, label %412

412:                                              ; preds = %405
  call fastcc void @out_of_memory()
  unreachable

413:                                              ; preds = %405
  %414 = icmp eq i32 %409, 0
  br i1 %414, label %424, label %415

415:                                              ; preds = %413
  %416 = udiv i64 -64, %410
  %417 = icmp ugt i64 %407, %416
  br i1 %417, label %418, label %419

418:                                              ; preds = %415
  call fastcc void @out_of_memory()
  unreachable

419:                                              ; preds = %415
  %420 = mul i64 %407, %410
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #75
  %421 = call fastcc ptr @block_alloc(i32 noundef 0, i64 noundef %420, ptr noundef %3)
  %422 = load i64, ptr %3, align 8, !tbaa !31
  %423 = udiv i64 %422, %410
  br label %427

424:                                              ; preds = %413
  %425 = mul nuw nsw i64 %407, %410
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #75
  %426 = call fastcc ptr @block_alloc(i32 noundef 0, i64 noundef %425, ptr noundef %3)
  br label %427

427:                                              ; preds = %424, %419
  %428 = phi ptr [ %421, %419 ], [ %426, %424 ]
  %429 = phi i64 [ %423, %419 ], [ %407, %424 ]
  %430 = getelementptr inbounds nuw i8, ptr %428, i64 16
  store i64 %429, ptr %430, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #75
  %431 = getelementptr inbounds nuw i8, ptr %232, i64 24
  %432 = load i64, ptr %431, align 8, !tbaa !35
  %433 = getelementptr inbounds nuw i8, ptr %428, i64 24
  store i64 %432, ptr %433, align 8, !tbaa !35
  %434 = load i64, ptr %406, align 8, !tbaa !28
  %435 = getelementptr inbounds nuw i8, ptr %428, i64 8
  store i64 %434, ptr %435, align 8, !tbaa !28
  %436 = icmp eq i64 %407, 0
  br i1 %436, label %486, label %437

437:                                              ; preds = %427, %393
  %438 = phi ptr [ %397, %393 ], [ %428, %427 ]
  %439 = phi i64 [ 1, %393 ], [ %407, %427 ]
  %440 = getelementptr inbounds nuw i8, ptr %232, i64 32
  %441 = getelementptr inbounds nuw i8, ptr %391, i64 4
  %442 = getelementptr inbounds nuw i8, ptr %438, i64 32
  br label %443

443:                                              ; preds = %483, %437
  %444 = phi i64 [ 0, %437 ], [ %484, %483 ]
  %445 = load i32, ptr %441, align 4, !tbaa !706
  %446 = zext i32 %445 to i64
  %447 = mul i64 %444, %446
  %448 = getelementptr inbounds nuw i8, ptr %440, i64 %447
  %449 = getelementptr inbounds nuw i8, ptr %442, i64 %447
  %450 = icmp eq i32 %445, 0
  br i1 %450, label %483, label %451

451:                                              ; preds = %443
  %452 = load i64, ptr %19, align 8, !tbaa !743
  %453 = load i64, ptr %12, align 8, !tbaa !742
  %454 = icmp eq i64 %452, %453
  br i1 %454, label %457, label %455

455:                                              ; preds = %451
  %456 = load ptr, ptr %8, align 8, !tbaa !740
  br label %476

457:                                              ; preds = %451
  %458 = shl i64 %452, 1
  %459 = icmp slt i64 %452, 0
  %460 = icmp ugt i64 %458, 768614336404564650
  %461 = or i1 %459, %460
  br i1 %461, label %462, label %463

462:                                              ; preds = %457
  call fastcc void @out_of_memory()
  unreachable

463:                                              ; preds = %457
  %464 = mul i64 %452, 48
  %465 = call noalias ptr @malloc(i64 noundef %464) #81
  %466 = icmp eq ptr %465, null
  br i1 %466, label %467, label %468

467:                                              ; preds = %463
  call fastcc void @out_of_memory()
  unreachable

468:                                              ; preds = %463
  %469 = load ptr, ptr %8, align 8, !tbaa !740
  %470 = mul i64 %452, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %465, ptr align 8 %469, i64 %470, i1 false)
  %471 = icmp eq ptr %469, %11
  br i1 %471, label %474, label %472

472:                                              ; preds = %468
  call void @free(ptr noundef %469) #75
  %473 = load i64, ptr %19, align 8, !tbaa !743
  br label %474

474:                                              ; preds = %472, %468
  %475 = phi i64 [ %473, %472 ], [ %452, %468 ]
  store ptr %465, ptr %8, align 8, !tbaa !740
  store i64 %458, ptr %12, align 8, !tbaa !742
  br label %476

476:                                              ; preds = %474, %455
  %477 = phi i64 [ %452, %455 ], [ %475, %474 ]
  %478 = phi ptr [ %456, %455 ], [ %465, %474 ]
  %479 = add i64 %477, 1
  store i64 %479, ptr %19, align 8, !tbaa !743
  %480 = getelementptr inbounds nuw %struct.core_copy_work, ptr %478, i64 %477
  store ptr %391, ptr %480, align 8, !tbaa !700
  %481 = getelementptr inbounds nuw i8, ptr %480, i64 8
  store ptr %448, ptr %481, align 8, !tbaa !111
  %482 = getelementptr inbounds nuw i8, ptr %480, i64 16
  store ptr %449, ptr %482, align 8, !tbaa !111
  br label %483

483:                                              ; preds = %443, %476
  %484 = add nuw nsw i64 %444, 1
  %485 = icmp eq i64 %484, %439
  br i1 %485, label %486, label %443, !llvm.loop !746

486:                                              ; preds = %483, %384, %236, %427
  %487 = phi ptr [ %237, %236 ], [ %428, %427 ], [ %237, %384 ], [ %438, %483 ]
  store ptr %487, ptr %29, align 1
  br label %560

488:                                              ; preds = %20
  %489 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %490 = load ptr, ptr %489, align 8, !tbaa !707
  %491 = load ptr, ptr %490, align 8, !tbaa !700
  %492 = load i32, ptr %491, align 8, !tbaa !702
  %493 = icmp ult i32 %492, 3
  br i1 %493, label %560, label %494

494:                                              ; preds = %488
  %495 = getelementptr inbounds nuw i8, ptr %25, i64 8
  %496 = load i32, ptr %495, align 8, !tbaa !705
  %497 = icmp eq i32 %496, 0
  br i1 %497, label %560, label %498

498:                                              ; preds = %494, %548
  %499 = phi i32 [ %549, %548 ], [ %496, %494 ]
  %500 = phi i32 [ %550, %548 ], [ %496, %494 ]
  %501 = phi i64 [ %551, %548 ], [ 0, %494 ]
  %502 = load ptr, ptr %489, align 8, !tbaa !707
  %503 = load ptr, ptr %502, align 8, !tbaa !700
  %504 = getelementptr inbounds nuw i8, ptr %503, i64 4
  %505 = load i32, ptr %504, align 4, !tbaa !706
  %506 = zext i32 %505 to i64
  %507 = mul nuw i64 %501, %506
  %508 = getelementptr inbounds nuw i8, ptr %27, i64 %507
  %509 = getelementptr inbounds nuw i8, ptr %29, i64 %507
  %510 = load i32, ptr %503, align 8, !tbaa !702
  %511 = icmp ult i32 %510, 3
  %512 = icmp eq i32 %505, 0
  %513 = select i1 %511, i1 true, i1 %512
  br i1 %513, label %548, label %514

514:                                              ; preds = %498
  %515 = load i64, ptr %19, align 8, !tbaa !743
  %516 = load i64, ptr %12, align 8, !tbaa !742
  %517 = icmp eq i64 %515, %516
  br i1 %517, label %520, label %518

518:                                              ; preds = %514
  %519 = load ptr, ptr %8, align 8, !tbaa !740
  br label %540

520:                                              ; preds = %514
  %521 = shl i64 %515, 1
  %522 = icmp slt i64 %515, 0
  %523 = icmp ugt i64 %521, 768614336404564650
  %524 = or i1 %522, %523
  br i1 %524, label %525, label %526

525:                                              ; preds = %520
  call fastcc void @out_of_memory()
  unreachable

526:                                              ; preds = %520
  %527 = mul i64 %515, 48
  %528 = call noalias ptr @malloc(i64 noundef %527) #81
  %529 = icmp eq ptr %528, null
  br i1 %529, label %530, label %531

530:                                              ; preds = %526
  call fastcc void @out_of_memory()
  unreachable

531:                                              ; preds = %526
  %532 = load ptr, ptr %8, align 8, !tbaa !740
  %533 = mul i64 %515, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %528, ptr align 8 %532, i64 %533, i1 false)
  %534 = icmp eq ptr %532, %11
  br i1 %534, label %537, label %535

535:                                              ; preds = %531
  call void @free(ptr noundef %532) #75
  %536 = load i64, ptr %19, align 8, !tbaa !743
  br label %537

537:                                              ; preds = %535, %531
  %538 = phi i64 [ %536, %535 ], [ %515, %531 ]
  store ptr %528, ptr %8, align 8, !tbaa !740
  store i64 %521, ptr %12, align 8, !tbaa !742
  %539 = load i32, ptr %495, align 8, !tbaa !705
  br label %540

540:                                              ; preds = %537, %518
  %541 = phi i32 [ %499, %518 ], [ %539, %537 ]
  %542 = phi i64 [ %515, %518 ], [ %538, %537 ]
  %543 = phi ptr [ %519, %518 ], [ %528, %537 ]
  %544 = add i64 %542, 1
  store i64 %544, ptr %19, align 8, !tbaa !743
  %545 = getelementptr inbounds nuw %struct.core_copy_work, ptr %543, i64 %542
  store ptr %503, ptr %545, align 8, !tbaa !700
  %546 = getelementptr inbounds nuw i8, ptr %545, i64 8
  store ptr %508, ptr %546, align 8, !tbaa !111
  %547 = getelementptr inbounds nuw i8, ptr %545, i64 16
  store ptr %509, ptr %547, align 8, !tbaa !111
  br label %548

548:                                              ; preds = %540, %498
  %549 = phi i32 [ %541, %540 ], [ %499, %498 ]
  %550 = phi i32 [ %541, %540 ], [ %500, %498 ]
  %551 = add nuw nsw i64 %501, 1
  %552 = zext i32 %550 to i64
  %553 = icmp samesign ult i64 %551, %552
  br i1 %553, label %498, label %560, !llvm.loop !747

554:                                              ; preds = %20
  %555 = getelementptr inbounds nuw i8, ptr %25, i64 12
  %556 = load i32, ptr %555, align 4, !tbaa !710
  %557 = icmp eq i32 %556, 1
  br i1 %557, label %560, label %558

558:                                              ; preds = %554
  call void @abort() #79
  unreachable

559:                                              ; preds = %20
  call void @abort() #79
  unreachable

560:                                              ; preds = %548, %159, %494, %34, %185, %195, %224, %486, %231, %104, %41, %554, %488, %20, %20, %20
  %561 = load i64, ptr %19, align 8, !tbaa !743
  %562 = icmp eq i64 %561, 0
  br i1 %562, label %563, label %20, !llvm.loop !748

563:                                              ; preds = %560
  %564 = load ptr, ptr %8, align 8, !tbaa !740
  %565 = icmp eq ptr %564, %11
  br i1 %565, label %567, label %566

566:                                              ; preds = %563
  call void @free(ptr noundef %564) #75
  br label %567

567:                                              ; preds = %2, %566, %563
  %568 = load ptr, ptr %9, align 8, !tbaa !38
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #75
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #75
  ret ptr %568
}
