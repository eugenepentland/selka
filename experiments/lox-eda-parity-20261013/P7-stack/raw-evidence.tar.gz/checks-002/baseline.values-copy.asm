
/home/epentland/ai/canopy/mylang-lox-runtime-stack-20261013-p7/.tmp/lox-eda-parity/P7-stack/baseline/release.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000029380 <myl_core_values_copy_box>:
   29380:	55                   	push   %rbp
   29381:	48 89 e5             	mov    %rsp,%rbp
   29384:	41 57                	push   %r15
   29386:	41 56                	push   %r14
   29388:	41 55                	push   %r13
   2938a:	41 54                	push   %r12
   2938c:	53                   	push   %rbx
   2938d:	48 81 ec 88 06 00 00 	sub    $0x688,%rsp
   29394:	48 89 fb             	mov    %rdi,%rbx
   29397:	48 89 b5 68 ff ff ff 	mov    %rsi,-0x98(%rbp)
   2939e:	48 8d bd 58 f9 ff ff 	lea    -0x6a8(%rbp),%rdi
   293a5:	ba 10 06 00 00       	mov    $0x610,%edx
   293aa:	31 f6                	xor    %esi,%esi
   293ac:	e8 00 00 00 00       	call   293b1 <myl_core_values_copy_box+0x31>
			293ad: R_X86_64_PLT32	memset-0x4
   293b1:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   293b8:	48 89 85 50 f9 ff ff 	mov    %rax,-0x6b0(%rbp)
   293bf:	48 c7 85 60 f9 ff ff 	movq   $0x40,-0x6a0(%rbp)
   293c6:	40 00 00 00 
   293ca:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
   293d1:	00 00 00 00 
   293d5:	83 7b 04 00          	cmpl   $0x0,0x4(%rbx)
   293d9:	0f 84 b2 0a 00 00    	je     29e91 <myl_core_values_copy_box+0xb11>
   293df:	48 89 9d 68 f9 ff ff 	mov    %rbx,-0x698(%rbp)
   293e6:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
   293ed:	48 89 85 70 f9 ff ff 	mov    %rax,-0x690(%rbp)
   293f4:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
   293fb:	48 89 85 78 f9 ff ff 	mov    %rax,-0x688(%rbp)
   29402:	b8 01 00 00 00       	mov    $0x1,%eax
   29407:	eb 17                	jmp    29420 <myl_core_values_copy_box+0xa0>
   29409:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   2940d:	4c 89 08             	mov    %r9,(%rax)
   29410:	48 8b 85 58 f9 ff ff 	mov    -0x6a8(%rbp),%rax
   29417:	48 85 c0             	test   %rax,%rax
   2941a:	0f 84 59 0a 00 00    	je     29e79 <myl_core_values_copy_box+0xaf9>
   29420:	48 8b 8d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rcx
   29427:	48 ff c8             	dec    %rax
   2942a:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   29431:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   29435:	48 8b 1c c1          	mov    (%rcx,%rax,8),%rbx
   29439:	48 8b 74 c1 08       	mov    0x8(%rcx,%rax,8),%rsi
   2943e:	48 8b 7c c1 10       	mov    0x10(%rcx,%rax,8),%rdi
   29443:	8b 53 04             	mov    0x4(%rbx),%edx
   29446:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
   2944a:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
   2944e:	e8 00 00 00 00       	call   29453 <myl_core_values_copy_box+0xd3>
			2944f: R_X86_64_PLT32	memcpy-0x4
   29453:	8b 03                	mov    (%rbx),%eax
   29455:	48 83 f8 0a          	cmp    $0xa,%rax
   29459:	0f 87 50 0a 00 00    	ja     29eaf <myl_core_values_copy_box+0xb2f>
   2945f:	49 89 d8             	mov    %rbx,%r8
   29462:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 29469 <myl_core_values_copy_box+0xe9>
			29465: R_X86_64_PC32	.rodata+0x270
   29469:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
   2946d:	48 01 d1             	add    %rdx,%rcx
   29470:	ff e1                	jmp    *%rcx
   29472:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   29476:	48 8b 39             	mov    (%rcx),%rdi
   29479:	48 85 ff             	test   %rdi,%rdi
   2947c:	74 92                	je     29410 <myl_core_values_copy_box+0x90>
   2947e:	83 f8 09             	cmp    $0x9,%eax
   29481:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
   29485:	0f 85 ec 05 00 00    	jne    29a77 <myl_core_values_copy_box+0x6f7>
   2948b:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   2948f:	e8 ec fe fd ff       	call   9380 <core_dict_copy_storage>
   29494:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29498:	49 89 c1             	mov    %rax,%r9
   2949b:	4d 8b 50 18          	mov    0x18(%r8),%r10
   2949f:	49 8b 42 20          	mov    0x20(%r10),%rax
   294a3:	48 85 c0             	test   %rax,%rax
   294a6:	0f 84 5d ff ff ff    	je     29409 <myl_core_values_copy_box+0x89>
   294ac:	4d 8d 58 20          	lea    0x20(%r8),%r11
   294b0:	4c 89 c9             	mov    %r9,%rcx
   294b3:	48 83 c1 20          	add    $0x20,%rcx
   294b7:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
   294bb:	45 31 ff             	xor    %r15d,%r15d
   294be:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   294c2:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
   294c6:	4c 89 55 80          	mov    %r10,-0x80(%rbp)
   294ca:	4c 89 5d 88          	mov    %r11,-0x78(%rbp)
   294ce:	eb 42                	jmp    29512 <myl_core_values_copy_box+0x192>
   294d0:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   294d7:	4d 01 dc             	add    %r11,%r12
   294da:	49 01 dc             	add    %rbx,%r12
   294dd:	48 03 5d c0          	add    -0x40(%rbp),%rbx
   294e1:	48 01 f3             	add    %rsi,%rbx
   294e4:	49 8d 46 01          	lea    0x1(%r14),%rax
   294e8:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   294ef:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
   294f3:	49 89 4c c5 00       	mov    %rcx,0x0(%r13,%rax,8)
   294f8:	4d 89 64 c5 08       	mov    %r12,0x8(%r13,%rax,8)
   294fd:	49 89 5c c5 10       	mov    %rbx,0x10(%r13,%rax,8)
   29502:	49 8b 42 20          	mov    0x20(%r10),%rax
   29506:	49 ff c7             	inc    %r15
   29509:	49 39 c7             	cmp    %rax,%r15
   2950c:	0f 83 f7 fe ff ff    	jae    29409 <myl_core_values_copy_box+0x89>
   29512:	49 8b 4a 18          	mov    0x18(%r10),%rcx
   29516:	48 85 c9             	test   %rcx,%rcx
   29519:	74 16                	je     29531 <myl_core_values_copy_box+0x1b1>
   2951b:	4c 89 fa             	mov    %r15,%rdx
   2951e:	48 c1 ea 03          	shr    $0x3,%rdx
   29522:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
   29526:	44 89 fa             	mov    %r15d,%edx
   29529:	83 e2 07             	and    $0x7,%edx
   2952c:	0f a3 d1             	bt     %edx,%ecx
   2952f:	72 d5                	jb     29506 <myl_core_values_copy_box+0x186>
   29531:	48 8b 47 10          	mov    0x10(%rdi),%rax
   29535:	48 8b 10             	mov    (%rax),%rdx
   29538:	49 8b 48 18          	mov    0x18(%r8),%rcx
   2953c:	48 8b 09             	mov    (%rcx),%rcx
   2953f:	44 8b 21             	mov    (%rcx),%r12d
   29542:	4d 0f af e7          	imul   %r15,%r12
   29546:	49 8b 49 18          	mov    0x18(%r9),%rcx
   2954a:	48 8b 09             	mov    (%rcx),%rcx
   2954d:	8b 31                	mov    (%rcx),%esi
   2954f:	49 0f af f7          	imul   %r15,%rsi
   29553:	83 7a 04 00          	cmpl   $0x0,0x4(%rdx)
   29557:	0f 84 1e 01 00 00    	je     2967b <myl_core_values_copy_box+0x2fb>
   2955d:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   29564:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   2956b:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
   2956f:	0f 85 c7 00 00 00    	jne    2963c <myl_core_values_copy_box+0x2bc>
   29575:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
   29579:	48 85 db             	test   %rbx,%rbx
   2957c:	0f 88 28 09 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29582:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   29586:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   2958d:	aa aa 0a 
   29590:	48 39 c1             	cmp    %rax,%rcx
   29593:	0f 87 11 09 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   29599:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
   2959d:	48 89 d8             	mov    %rbx,%rax
   295a0:	48 c1 e0 04          	shl    $0x4,%rax
   295a4:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   295a8:	e8 00 00 00 00       	call   295ad <myl_core_values_copy_box+0x22d>
			295a9: R_X86_64_PLT32	malloc-0x4
   295ad:	48 85 c0             	test   %rax,%rax
   295b0:	0f 84 f4 08 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   295b6:	49 89 c5             	mov    %rax,%r13
   295b9:	4c 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r14
   295c0:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   295c7:	00 
   295c8:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   295cc:	4c 89 ef             	mov    %r13,%rdi
   295cf:	4c 89 f6             	mov    %r14,%rsi
   295d2:	e8 00 00 00 00       	call   295d7 <myl_core_values_copy_box+0x257>
			295d3: R_X86_64_PLT32	memcpy-0x4
   295d7:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   295de:	49 39 c6             	cmp    %rax,%r14
   295e1:	74 0f                	je     295f2 <myl_core_values_copy_box+0x272>
   295e3:	4c 89 f7             	mov    %r14,%rdi
   295e6:	e8 00 00 00 00       	call   295eb <myl_core_values_copy_box+0x26b>
			295e7: R_X86_64_PLT32	free-0x4
   295eb:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   295f2:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   295f9:	48 8b 45 90          	mov    -0x70(%rbp),%rax
   295fd:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29604:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   29608:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2960c:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29610:	49 8b 48 18          	mov    0x18(%r8),%rcx
   29614:	48 8b 09             	mov    (%rcx),%rcx
   29617:	8b 09                	mov    (%rcx),%ecx
   29619:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   2961d:	49 8b 51 18          	mov    0x18(%r9),%rdx
   29621:	48 8b 12             	mov    (%rdx),%rdx
   29624:	8b 12                	mov    (%rdx),%edx
   29626:	49 0f af cf          	imul   %r15,%rcx
   2962a:	49 0f af d7          	imul   %r15,%rdx
   2962e:	4c 8b 55 80          	mov    -0x80(%rbp),%r10
   29632:	4c 8b 5d 88          	mov    -0x78(%rbp),%r11
   29636:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
   2963a:	eb 0d                	jmp    29649 <myl_core_values_copy_box+0x2c9>
   2963c:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   29643:	48 89 f2             	mov    %rsi,%rdx
   29646:	4c 89 e1             	mov    %r12,%rcx
   29649:	4d 01 dc             	add    %r11,%r12
   2964c:	48 03 75 c0          	add    -0x40(%rbp),%rsi
   29650:	49 89 f6             	mov    %rsi,%r14
   29653:	48 8d 73 01          	lea    0x1(%rbx),%rsi
   29657:	48 89 b5 58 f9 ff ff 	mov    %rsi,-0x6a8(%rbp)
   2965e:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
   29662:	48 8b 5d a0          	mov    -0x60(%rbp),%rbx
   29666:	49 89 5c f5 00       	mov    %rbx,0x0(%r13,%rsi,8)
   2966b:	4d 89 64 f5 08       	mov    %r12,0x8(%r13,%rsi,8)
   29670:	4d 89 74 f5 10       	mov    %r14,0x10(%r13,%rsi,8)
   29675:	48 89 d6             	mov    %rdx,%rsi
   29678:	49 89 cc             	mov    %rcx,%r12
   2967b:	48 8b 48 08          	mov    0x8(%rax),%rcx
   2967f:	83 79 04 00          	cmpl   $0x0,0x4(%rcx)
   29683:	0f 84 79 fe ff ff    	je     29502 <myl_core_values_copy_box+0x182>
   29689:	49 8b 02             	mov    (%r10),%rax
   2968c:	8b 58 04             	mov    0x4(%rax),%ebx
   2968f:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29696:	4c 3b b5 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r14
   2969d:	0f 85 2d fe ff ff    	jne    294d0 <myl_core_values_copy_box+0x150>
   296a3:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
   296a7:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
   296ab:	4d 85 f6             	test   %r14,%r14
   296ae:	0f 88 f6 07 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   296b4:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
   296b8:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   296bf:	aa aa 0a 
   296c2:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
   296c6:	48 39 c1             	cmp    %rax,%rcx
   296c9:	0f 87 db 07 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   296cf:	4c 89 f0             	mov    %r14,%rax
   296d2:	48 c1 e0 04          	shl    $0x4,%rax
   296d6:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   296da:	e8 00 00 00 00       	call   296df <myl_core_values_copy_box+0x35f>
			296db: R_X86_64_PLT32	malloc-0x4
   296df:	48 85 c0             	test   %rax,%rax
   296e2:	0f 84 c2 07 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   296e8:	49 89 c5             	mov    %rax,%r13
   296eb:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   296f2:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
   296f9:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
   29700:	00 
   29701:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29705:	4c 89 ef             	mov    %r13,%rdi
   29708:	e8 00 00 00 00       	call   2970d <myl_core_values_copy_box+0x38d>
			29709: R_X86_64_PLT32	memcpy-0x4
   2970d:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
   29714:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   2971b:	48 39 c7             	cmp    %rax,%rdi
   2971e:	74 0c                	je     2972c <myl_core_values_copy_box+0x3ac>
   29720:	e8 00 00 00 00       	call   29725 <myl_core_values_copy_box+0x3a5>
			29721: R_X86_64_PLT32	free-0x4
   29725:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   2972c:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   29733:	48 8b 45 90          	mov    -0x70(%rbp),%rax
   29737:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   2973e:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   29742:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29746:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   2974a:	4c 8b 55 80          	mov    -0x80(%rbp),%r10
   2974e:	4c 8b 5d 88          	mov    -0x78(%rbp),%r11
   29752:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
   29756:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
   2975a:	e9 78 fd ff ff       	jmp    294d7 <myl_core_values_copy_box+0x157>
   2975f:	49 8b 40 10          	mov    0x10(%r8),%rax
   29763:	48 8b 00             	mov    (%rax),%rax
   29766:	83 38 03             	cmpl   $0x3,(%rax)
   29769:	0f 82 a1 fc ff ff    	jb     29410 <myl_core_values_copy_box+0x90>
   2976f:	41 8b 40 08          	mov    0x8(%r8),%eax
   29773:	85 c0                	test   %eax,%eax
   29775:	0f 84 95 fc ff ff    	je     29410 <myl_core_values_copy_box+0x90>
   2977b:	45 31 f6             	xor    %r14d,%r14d
   2977e:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   29782:	e9 7d 00 00 00       	jmp    29804 <myl_core_values_copy_box+0x484>
   29787:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2978e:	0f 1f 84 00 00 00 00 
   29795:	00 
   29796:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2979d:	0f 1f 84 00 00 00 00 
   297a4:	00 
   297a5:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   297ac:	0f 1f 84 00 00 00 00 
   297b3:	00 
   297b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   297bb:	00 00 00 00 00 
   297c0:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   297c7:	44 89 f9             	mov    %r15d,%ecx
   297ca:	49 0f af ce          	imul   %r14,%rcx
   297ce:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   297d2:	48 01 ca             	add    %rcx,%rdx
   297d5:	48 03 4d b0          	add    -0x50(%rbp),%rcx
   297d9:	48 8d 73 01          	lea    0x1(%rbx),%rsi
   297dd:	48 89 b5 58 f9 ff ff 	mov    %rsi,-0x6a8(%rbp)
   297e4:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
   297e8:	4d 89 2c f4          	mov    %r13,(%r12,%rsi,8)
   297ec:	49 89 54 f4 08       	mov    %rdx,0x8(%r12,%rsi,8)
   297f1:	49 89 4c f4 10       	mov    %rcx,0x10(%r12,%rsi,8)
   297f6:	49 ff c6             	inc    %r14
   297f9:	89 c1                	mov    %eax,%ecx
   297fb:	49 39 ce             	cmp    %rcx,%r14
   297fe:	0f 83 0c fc ff ff    	jae    29410 <myl_core_values_copy_box+0x90>
   29804:	49 8b 48 10          	mov    0x10(%r8),%rcx
   29808:	4c 8b 29             	mov    (%rcx),%r13
   2980b:	45 8b 7d 04          	mov    0x4(%r13),%r15d
   2980f:	41 83 7d 00 03       	cmpl   $0x3,0x0(%r13)
   29814:	0f 92 c1             	setb   %cl
   29817:	45 85 ff             	test   %r15d,%r15d
   2981a:	0f 94 c2             	sete   %dl
   2981d:	08 ca                	or     %cl,%dl
   2981f:	75 d5                	jne    297f6 <myl_core_values_copy_box+0x476>
   29821:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   29828:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   2982f:	75 8f                	jne    297c0 <myl_core_values_copy_box+0x440>
   29831:	48 85 db             	test   %rbx,%rbx
   29834:	0f 88 70 06 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   2983a:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   2983e:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29845:	aa aa 0a 
   29848:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
   2984c:	48 39 c1             	cmp    %rax,%rcx
   2984f:	0f 87 55 06 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   29855:	48 89 d8             	mov    %rbx,%rax
   29858:	48 c1 e0 04          	shl    $0x4,%rax
   2985c:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29860:	e8 00 00 00 00       	call   29865 <myl_core_values_copy_box+0x4e5>
			29861: R_X86_64_PLT32	malloc-0x4
   29865:	48 85 c0             	test   %rax,%rax
   29868:	0f 84 3c 06 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   2986e:	49 89 c4             	mov    %rax,%r12
   29871:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   29878:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
   2987c:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   29883:	00 
   29884:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29888:	4c 89 e7             	mov    %r12,%rdi
   2988b:	e8 00 00 00 00       	call   29890 <myl_core_values_copy_box+0x510>
			2988c: R_X86_64_PLT32	memcpy-0x4
   29890:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
   29894:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   2989b:	48 39 c7             	cmp    %rax,%rdi
   2989e:	74 0c                	je     298ac <myl_core_values_copy_box+0x52c>
   298a0:	e8 00 00 00 00       	call   298a5 <myl_core_values_copy_box+0x525>
			298a1: R_X86_64_PLT32	free-0x4
   298a5:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   298ac:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   298b3:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
   298b7:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   298be:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   298c2:	41 8b 40 08          	mov    0x8(%r8),%eax
   298c6:	e9 fc fe ff ff       	jmp    297c7 <myl_core_values_copy_box+0x447>
   298cb:	41 83 78 0c 01       	cmpl   $0x1,0xc(%r8)
   298d0:	0f 84 3a fb ff ff    	je     29410 <myl_core_values_copy_box+0x90>
   298d6:	e9 d4 05 00 00       	jmp    29eaf <myl_core_values_copy_box+0xb2f>
   298db:	41 8b 40 0c          	mov    0xc(%r8),%eax
   298df:	85 c0                	test   %eax,%eax
   298e1:	0f 84 44 02 00 00    	je     29b2b <myl_core_values_copy_box+0x7ab>
   298e7:	ba 02 00 00 00       	mov    $0x2,%edx
   298ec:	29 c2                	sub    %eax,%edx
   298ee:	8d 48 ff             	lea    -0x1(%rax),%ecx
   298f1:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   298f5:	48 83 3e 00          	cmpq   $0x0,(%rsi)
   298f9:	0f 45 ca             	cmovne %edx,%ecx
   298fc:	e9 31 02 00 00       	jmp    29b32 <myl_core_values_copy_box+0x7b2>
   29901:	41 8b 40 08          	mov    0x8(%r8),%eax
   29905:	85 c0                	test   %eax,%eax
   29907:	0f 84 03 fb ff ff    	je     29410 <myl_core_values_copy_box+0x90>
   2990d:	45 31 f6             	xor    %r14d,%r14d
   29910:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   29914:	eb 3d                	jmp    29953 <myl_core_values_copy_box+0x5d3>
   29916:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   2991d:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   29921:	4c 01 f9             	add    %r15,%rcx
   29924:	4c 03 7d b0          	add    -0x50(%rbp),%r15
   29928:	48 8d 53 01          	lea    0x1(%rbx),%rdx
   2992c:	48 89 95 58 f9 ff ff 	mov    %rdx,-0x6a8(%rbp)
   29933:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
   29937:	4d 89 2c d4          	mov    %r13,(%r12,%rdx,8)
   2993b:	49 89 4c d4 08       	mov    %rcx,0x8(%r12,%rdx,8)
   29940:	4d 89 7c d4 10       	mov    %r15,0x10(%r12,%rdx,8)
   29945:	49 ff c6             	inc    %r14
   29948:	89 c1                	mov    %eax,%ecx
   2994a:	49 39 ce             	cmp    %rcx,%r14
   2994d:	0f 83 bd fa ff ff    	jae    29410 <myl_core_values_copy_box+0x90>
   29953:	49 8b 48 10          	mov    0x10(%r8),%rcx
   29957:	4e 8b 2c f1          	mov    (%rcx,%r14,8),%r13
   2995b:	41 83 7d 00 03       	cmpl   $0x3,0x0(%r13)
   29960:	72 e3                	jb     29945 <myl_core_values_copy_box+0x5c5>
   29962:	41 83 7d 04 00       	cmpl   $0x0,0x4(%r13)
   29967:	74 dc                	je     29945 <myl_core_values_copy_box+0x5c5>
   29969:	49 8b 48 18          	mov    0x18(%r8),%rcx
   2996d:	46 8b 3c b1          	mov    (%rcx,%r14,4),%r15d
   29971:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   29978:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   2997f:	75 95                	jne    29916 <myl_core_values_copy_box+0x596>
   29981:	48 85 db             	test   %rbx,%rbx
   29984:	0f 88 20 05 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   2998a:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   2998e:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29995:	aa aa 0a 
   29998:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
   2999c:	48 39 c1             	cmp    %rax,%rcx
   2999f:	0f 87 05 05 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   299a5:	48 89 d8             	mov    %rbx,%rax
   299a8:	48 c1 e0 04          	shl    $0x4,%rax
   299ac:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   299b0:	e8 00 00 00 00       	call   299b5 <myl_core_values_copy_box+0x635>
			299b1: R_X86_64_PLT32	malloc-0x4
   299b5:	48 85 c0             	test   %rax,%rax
   299b8:	0f 84 ec 04 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   299be:	49 89 c4             	mov    %rax,%r12
   299c1:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   299c8:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
   299cc:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   299d3:	00 
   299d4:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   299d8:	4c 89 e7             	mov    %r12,%rdi
   299db:	e8 00 00 00 00       	call   299e0 <myl_core_values_copy_box+0x660>
			299dc: R_X86_64_PLT32	memcpy-0x4
   299e0:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
   299e4:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   299eb:	48 39 c7             	cmp    %rax,%rdi
   299ee:	74 0c                	je     299fc <myl_core_values_copy_box+0x67c>
   299f0:	e8 00 00 00 00       	call   299f5 <myl_core_values_copy_box+0x675>
			299f1: R_X86_64_PLT32	free-0x4
   299f5:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   299fc:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   29a03:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
   29a07:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29a0e:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   29a12:	41 8b 40 08          	mov    0x8(%r8),%eax
   29a16:	e9 02 ff ff ff       	jmp    2991d <myl_core_values_copy_box+0x59d>
   29a1b:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
   29a1f:	4c 8b 38             	mov    (%rax),%r15
   29a22:	4d 85 ff             	test   %r15,%r15
   29a25:	0f 84 e5 f9 ff ff    	je     29410 <myl_core_values_copy_box+0x90>
   29a2b:	41 80 3f 05          	cmpb   $0x5,(%r15)
   29a2f:	0f 85 da 01 00 00    	jne    29c0f <myl_core_values_copy_box+0x88f>
   29a35:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   29a39:	48 85 db             	test   %rbx,%rbx
   29a3c:	0f 88 68 04 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29a42:	bf 05 00 00 00       	mov    $0x5,%edi
   29a47:	48 89 de             	mov    %rbx,%rsi
   29a4a:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29a4e:	e8 2d 42 00 00       	call   2dc80 <block_alloc>
   29a53:	49 89 c4             	mov    %rax,%r12
   29a56:	48 89 58 10          	mov    %rbx,0x10(%rax)
   29a5a:	49 8b 57 08          	mov    0x8(%r15),%rdx
   29a5e:	48 89 50 08          	mov    %rdx,0x8(%rax)
   29a62:	48 8d 78 20          	lea    0x20(%rax),%rdi
   29a66:	49 83 c7 20          	add    $0x20,%r15
   29a6a:	4c 89 fe             	mov    %r15,%rsi
   29a6d:	e8 00 00 00 00       	call   29a72 <myl_core_values_copy_box+0x6f2>
			29a6e: R_X86_64_PLT32	memcpy-0x4
   29a72:	e9 67 02 00 00       	jmp    29cde <myl_core_values_copy_box+0x95e>
   29a77:	49 8b 48 10          	mov    0x10(%r8),%rcx
   29a7b:	48 8b 19             	mov    (%rcx),%rbx
   29a7e:	83 f8 06             	cmp    $0x6,%eax
   29a81:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
   29a85:	75 45                	jne    29acc <myl_core_values_copy_box+0x74c>
   29a87:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
   29a8b:	8b 58 04             	mov    0x4(%rax),%ebx
   29a8e:	bf 02 00 00 00       	mov    $0x2,%edi
   29a93:	48 89 de             	mov    %rbx,%rsi
   29a96:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29a9a:	e8 e1 41 00 00       	call   2dc80 <block_alloc>
   29a9f:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29aa3:	49 89 c1             	mov    %rax,%r9
   29aa6:	48 89 58 10          	mov    %rbx,0x10(%rax)
   29aaa:	48 89 58 08          	mov    %rbx,0x8(%rax)
   29aae:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
   29ab2:	48 8b 42 18          	mov    0x18(%rdx),%rax
   29ab6:	49 89 41 18          	mov    %rax,0x18(%r9)
   29aba:	48 8b 42 08          	mov    0x8(%rdx),%rax
   29abe:	49 89 41 08          	mov    %rax,0x8(%r9)
   29ac2:	be 01 00 00 00       	mov    $0x1,%esi
   29ac7:	e9 85 02 00 00       	jmp    29d51 <myl_core_values_copy_box+0x9d1>
   29acc:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   29ad0:	48 85 f6             	test   %rsi,%rsi
   29ad3:	0f 88 d1 03 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29ad9:	44 8b 6b 04          	mov    0x4(%rbx),%r13d
   29add:	4d 85 ed             	test   %r13,%r13
   29ae0:	0f 84 af 01 00 00    	je     29c95 <myl_core_values_copy_box+0x915>
   29ae6:	48 c7 c0 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rax
   29aed:	31 d2                	xor    %edx,%edx
   29aef:	49 f7 f5             	div    %r13
   29af2:	48 39 c6             	cmp    %rax,%rsi
   29af5:	0f 87 af 03 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   29afb:	49 89 f6             	mov    %rsi,%r14
   29afe:	49 0f af f5          	imul   %r13,%rsi
   29b02:	31 ff                	xor    %edi,%edi
   29b04:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29b08:	e8 73 41 00 00       	call   2dc80 <block_alloc>
   29b0d:	49 89 c1             	mov    %rax,%r9
   29b10:	48 8b 45 98          	mov    -0x68(%rbp),%rax
   29b14:	48 89 c1             	mov    %rax,%rcx
   29b17:	48 c1 e9 20          	shr    $0x20,%rcx
   29b1b:	0f 84 07 02 00 00    	je     29d28 <myl_core_values_copy_box+0x9a8>
   29b21:	31 d2                	xor    %edx,%edx
   29b23:	49 f7 f5             	div    %r13
   29b26:	e9 02 02 00 00       	jmp    29d2d <myl_core_values_copy_box+0x9ad>
   29b2b:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   29b2f:	48 8b 09             	mov    (%rcx),%rcx
   29b32:	41 8b 50 08          	mov    0x8(%r8),%edx
   29b36:	48 39 d1             	cmp    %rdx,%rcx
   29b39:	0f 83 70 03 00 00    	jae    29eaf <myl_core_values_copy_box+0xb2f>
   29b3f:	45 31 ed             	xor    %r13d,%r13d
   29b42:	85 c0                	test   %eax,%eax
   29b44:	0f 94 c2             	sete   %dl
   29b47:	49 8b 40 10          	mov    0x10(%r8),%rax
   29b4b:	4c 8b 34 c8          	mov    (%rax,%rcx,8),%r14
   29b4f:	41 83 3e 03          	cmpl   $0x3,(%r14)
   29b53:	0f 82 b7 f8 ff ff    	jb     29410 <myl_core_values_copy_box+0x90>
   29b59:	41 83 7e 04 00       	cmpl   $0x0,0x4(%r14)
   29b5e:	0f 84 ac f8 ff ff    	je     29410 <myl_core_values_copy_box+0x90>
   29b64:	4c 8b bd 58 f9 ff ff 	mov    -0x6a8(%rbp),%r15
   29b6b:	4c 3b bd 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r15
   29b72:	0f 85 72 01 00 00    	jne    29cea <myl_core_values_copy_box+0x96a>
   29b78:	4d 85 ff             	test   %r15,%r15
   29b7b:	0f 88 29 03 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29b81:	4b 8d 0c 3f          	lea    (%r15,%r15,1),%rcx
   29b85:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29b8c:	aa aa 0a 
   29b8f:	48 39 c1             	cmp    %rax,%rcx
   29b92:	0f 87 12 03 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   29b98:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   29b9c:	88 55 b8             	mov    %dl,-0x48(%rbp)
   29b9f:	4c 89 f8             	mov    %r15,%rax
   29ba2:	48 c1 e0 04          	shl    $0x4,%rax
   29ba6:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29baa:	e8 00 00 00 00       	call   29baf <myl_core_values_copy_box+0x82f>
			29bab: R_X86_64_PLT32	malloc-0x4
   29baf:	48 85 c0             	test   %rax,%rax
   29bb2:	0f 84 f2 02 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   29bb8:	49 89 c4             	mov    %rax,%r12
   29bbb:	48 8b 9d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rbx
   29bc2:	4a 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%rax
   29bc9:	00 
   29bca:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29bce:	4c 89 e7             	mov    %r12,%rdi
   29bd1:	48 89 de             	mov    %rbx,%rsi
   29bd4:	e8 00 00 00 00       	call   29bd9 <myl_core_values_copy_box+0x859>
			29bd5: R_X86_64_PLT32	memcpy-0x4
   29bd9:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29be0:	48 39 c3             	cmp    %rax,%rbx
   29be3:	74 0f                	je     29bf4 <myl_core_values_copy_box+0x874>
   29be5:	48 89 df             	mov    %rbx,%rdi
   29be8:	e8 00 00 00 00       	call   29bed <myl_core_values_copy_box+0x86d>
			29be9: R_X86_64_PLT32	free-0x4
   29bed:	4c 8b bd 58 f9 ff ff 	mov    -0x6a8(%rbp),%r15
   29bf4:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   29bfb:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   29bff:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29c06:	0f b6 55 b8          	movzbl -0x48(%rbp),%edx
   29c0a:	e9 e2 00 00 00       	jmp    29cf1 <myl_core_values_copy_box+0x971>
   29c0f:	4d 8b 6f 08          	mov    0x8(%r15),%r13
   29c13:	4d 85 ed             	test   %r13,%r13
   29c16:	0f 88 8e 02 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29c1c:	4d 8d 77 20          	lea    0x20(%r15),%r14
   29c20:	49 8d 75 01          	lea    0x1(%r13),%rsi
   29c24:	bf 01 00 00 00       	mov    $0x1,%edi
   29c29:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29c2d:	e8 4e 40 00 00       	call   2dc80 <block_alloc>
   29c32:	49 89 c4             	mov    %rax,%r12
   29c35:	4c 89 68 10          	mov    %r13,0x10(%rax)
   29c39:	48 8d 58 20          	lea    0x20(%rax),%rbx
   29c3d:	48 89 df             	mov    %rbx,%rdi
   29c40:	4c 89 f6             	mov    %r14,%rsi
   29c43:	4c 89 ea             	mov    %r13,%rdx
   29c46:	e8 00 00 00 00       	call   29c4b <myl_core_values_copy_box+0x8cb>
			29c47: R_X86_64_PLT32	memcpy-0x4
   29c4b:	43 c6 44 2c 20 00    	movb   $0x0,0x20(%r12,%r13,1)
   29c51:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
   29c56:	41 8b 04 24          	mov    (%r12),%eax
   29c5a:	b9 ff e0 ff ff       	mov    $0xffffe0ff,%ecx
   29c5f:	21 c8                	and    %ecx,%eax
   29c61:	41 89 04 24          	mov    %eax,(%r12)
   29c65:	49 c7 44 24 18 00 00 	movq   $0x0,0x18(%r12)
   29c6c:	00 00 
   29c6e:	31 c9                	xor    %ecx,%ecx
   29c70:	48 be 80 80 80 80 80 	movabs $0x8080808080808080,%rsi
   29c77:	80 80 80 
   29c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   29c80:	48 8d 51 08          	lea    0x8(%rcx),%rdx
   29c84:	4c 39 ea             	cmp    %r13,%rdx
   29c87:	77 30                	ja     29cb9 <myl_core_values_copy_box+0x939>
   29c89:	49 85 74 0c 20       	test   %rsi,0x20(%r12,%rcx,1)
   29c8e:	48 89 d1             	mov    %rdx,%rcx
   29c91:	74 ed                	je     29c80 <myl_core_values_copy_box+0x900>
   29c93:	eb 42                	jmp    29cd7 <myl_core_values_copy_box+0x957>
   29c95:	4c 0f af ee          	imul   %rsi,%r13
   29c99:	31 ff                	xor    %edi,%edi
   29c9b:	49 89 f6             	mov    %rsi,%r14
   29c9e:	4c 89 ee             	mov    %r13,%rsi
   29ca1:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29ca5:	e8 d6 3f 00 00       	call   2dc80 <block_alloc>
   29caa:	4c 89 f6             	mov    %r14,%rsi
   29cad:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29cb1:	49 89 c1             	mov    %rax,%r9
   29cb4:	4c 89 f0             	mov    %r14,%rax
   29cb7:	eb 7b                	jmp    29d34 <myl_core_values_copy_box+0x9b4>
   29cb9:	4c 39 e9             	cmp    %r13,%rcx
   29cbc:	73 10                	jae    29cce <myl_core_values_copy_box+0x94e>
   29cbe:	66 90                	xchg   %ax,%ax
   29cc0:	80 3c 0b 00          	cmpb   $0x0,(%rbx,%rcx,1)
   29cc4:	78 11                	js     29cd7 <myl_core_values_copy_box+0x957>
   29cc6:	48 ff c1             	inc    %rcx
   29cc9:	49 39 cd             	cmp    %rcx,%r13
   29ccc:	75 f2                	jne    29cc0 <myl_core_values_copy_box+0x940>
   29cce:	0d 00 01 00 00       	or     $0x100,%eax
   29cd3:	41 89 04 24          	mov    %eax,(%r12)
   29cd7:	41 8a 07             	mov    (%r15),%al
   29cda:	41 89 04 24          	mov    %eax,(%r12)
   29cde:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   29ce2:	4c 89 20             	mov    %r12,(%rax)
   29ce5:	e9 26 f7 ff ff       	jmp    29410 <myl_core_values_copy_box+0x90>
   29cea:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   29cf1:	41 88 d5             	mov    %dl,%r13b
   29cf4:	41 c1 e5 03          	shl    $0x3,%r13d
   29cf8:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29cfc:	4c 01 ea             	add    %r13,%rdx
   29cff:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
   29d03:	4c 01 e9             	add    %r13,%rcx
   29d06:	49 8d 47 01          	lea    0x1(%r15),%rax
   29d0a:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   29d11:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
   29d15:	4d 89 34 c4          	mov    %r14,(%r12,%rax,8)
   29d19:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
   29d1e:	49 89 4c c4 10       	mov    %rcx,0x10(%r12,%rax,8)
   29d23:	e9 e8 f6 ff ff       	jmp    29410 <myl_core_values_copy_box+0x90>
   29d28:	31 d2                	xor    %edx,%edx
   29d2a:	41 f7 f5             	div    %r13d
   29d2d:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29d31:	4c 89 f6             	mov    %r14,%rsi
   29d34:	49 89 41 10          	mov    %rax,0x10(%r9)
   29d38:	48 8b 42 18          	mov    0x18(%rdx),%rax
   29d3c:	49 89 41 18          	mov    %rax,0x18(%r9)
   29d40:	48 8b 42 08          	mov    0x8(%rdx),%rax
   29d44:	49 89 41 08          	mov    %rax,0x8(%r9)
   29d48:	48 85 f6             	test   %rsi,%rsi
   29d4b:	0f 84 b8 f6 ff ff    	je     29409 <myl_core_values_copy_box+0x89>
   29d51:	48 83 c2 20          	add    $0x20,%rdx
   29d55:	49 8d 79 20          	lea    0x20(%r9),%rdi
   29d59:	45 31 e4             	xor    %r12d,%r12d
   29d5c:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
   29d60:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
   29d64:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
   29d68:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
   29d6c:	eb 4e                	jmp    29dbc <myl_core_values_copy_box+0xa3c>
   29d6e:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   29d75:	0f 1f 84 00 00 00 00 
   29d7c:	00 
   29d7d:	0f 1f 00             	nopl   (%rax)
   29d80:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   29d87:	4d 0f af fc          	imul   %r12,%r15
   29d8b:	4a 8d 04 3a          	lea    (%rdx,%r15,1),%rax
   29d8f:	49 01 ff             	add    %rdi,%r15
   29d92:	49 8d 4e 01          	lea    0x1(%r14),%rcx
   29d96:	48 89 8d 58 f9 ff ff 	mov    %rcx,-0x6a8(%rbp)
   29d9d:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
   29da1:	49 89 5c cd 00       	mov    %rbx,0x0(%r13,%rcx,8)
   29da6:	49 89 44 cd 08       	mov    %rax,0x8(%r13,%rcx,8)
   29dab:	4d 89 7c cd 10       	mov    %r15,0x10(%r13,%rcx,8)
   29db0:	49 ff c4             	inc    %r12
   29db3:	4c 39 e6             	cmp    %r12,%rsi
   29db6:	0f 84 4d f6 ff ff    	je     29409 <myl_core_values_copy_box+0x89>
   29dbc:	44 8b 7b 04          	mov    0x4(%rbx),%r15d
   29dc0:	4d 85 ff             	test   %r15,%r15
   29dc3:	74 eb                	je     29db0 <myl_core_values_copy_box+0xa30>
   29dc5:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29dcc:	4c 3b b5 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r14
   29dd3:	75 ab                	jne    29d80 <myl_core_values_copy_box+0xa00>
   29dd5:	4d 85 f6             	test   %r14,%r14
   29dd8:	0f 88 cc 00 00 00    	js     29eaa <myl_core_values_copy_box+0xb2a>
   29dde:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
   29de2:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29de9:	aa aa 0a 
   29dec:	48 39 c1             	cmp    %rax,%rcx
   29def:	0f 87 b5 00 00 00    	ja     29eaa <myl_core_values_copy_box+0xb2a>
   29df5:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   29df9:	4c 89 f0             	mov    %r14,%rax
   29dfc:	48 c1 e0 04          	shl    $0x4,%rax
   29e00:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29e04:	e8 00 00 00 00       	call   29e09 <myl_core_values_copy_box+0xa89>
			29e05: R_X86_64_PLT32	malloc-0x4
   29e09:	48 85 c0             	test   %rax,%rax
   29e0c:	0f 84 98 00 00 00    	je     29eaa <myl_core_values_copy_box+0xb2a>
   29e12:	49 89 c5             	mov    %rax,%r13
   29e15:	48 8b 9d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rbx
   29e1c:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
   29e23:	00 
   29e24:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29e28:	4c 89 ef             	mov    %r13,%rdi
   29e2b:	48 89 de             	mov    %rbx,%rsi
   29e2e:	e8 00 00 00 00       	call   29e33 <myl_core_values_copy_box+0xab3>
			29e2f: R_X86_64_PLT32	memcpy-0x4
   29e33:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29e3a:	48 39 c3             	cmp    %rax,%rbx
   29e3d:	74 0f                	je     29e4e <myl_core_values_copy_box+0xace>
   29e3f:	48 89 df             	mov    %rbx,%rdi
   29e42:	e8 00 00 00 00       	call   29e47 <myl_core_values_copy_box+0xac7>
			29e43: R_X86_64_PLT32	free-0x4
   29e47:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29e4e:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   29e55:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   29e59:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29e60:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29e64:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   29e68:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
   29e6c:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
   29e70:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
   29e74:	e9 0e ff ff ff       	jmp    29d87 <myl_core_values_copy_box+0xa07>
   29e79:	48 8b bd 50 f9 ff ff 	mov    -0x6b0(%rbp),%rdi
   29e80:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29e87:	48 39 c7             	cmp    %rax,%rdi
   29e8a:	74 05                	je     29e91 <myl_core_values_copy_box+0xb11>
   29e8c:	e8 00 00 00 00       	call   29e91 <myl_core_values_copy_box+0xb11>
			29e8d: R_X86_64_PLT32	free-0x4
   29e91:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
   29e98:	48 81 c4 88 06 00 00 	add    $0x688,%rsp
   29e9f:	5b                   	pop    %rbx
   29ea0:	41 5c                	pop    %r12
   29ea2:	41 5d                	pop    %r13
   29ea4:	41 5e                	pop    %r14
   29ea6:	41 5f                	pop    %r15
   29ea8:	5d                   	pop    %rbp
   29ea9:	c3                   	ret
   29eaa:	e8 11 75 fd ff       	call   13c0 <out_of_memory>
   29eaf:	e8 00 00 00 00       	call   29eb4 <myl_core_values_copy_box+0xb34>
			29eb0: R_X86_64_PLT32	abort-0x4

Disassembly of section .text.unlikely.:
