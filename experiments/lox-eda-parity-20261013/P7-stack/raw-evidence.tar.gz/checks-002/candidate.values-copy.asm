
/home/epentland/ai/canopy/mylang-lox-runtime-stack-20261013-p7/.tmp/lox-eda-parity/P7-stack/candidate/release.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000029380 <myl_core_values_copy_box>:
   29380:	55                   	push   %rbp
   29381:	48 89 e5             	mov    %rsp,%rbp
   29384:	41 57                	push   %r15
   29386:	41 56                	push   %r14
   29388:	41 55                	push   %r13
   2938a:	41 54                	push   %r12
   2938c:	53                   	push   %rbx
   2938d:	48 81 ec 88 06 00 00 	sub    $0x688,%rsp
   29394:	48 89 b5 68 ff ff ff 	mov    %rsi,-0x98(%rbp)
   2939b:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   293a2:	48 89 85 50 f9 ff ff 	mov    %rax,-0x6b0(%rbp)
   293a9:	48 c7 85 60 f9 ff ff 	movq   $0x40,-0x6a0(%rbp)
   293b0:	40 00 00 00 
   293b4:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
   293bb:	00 00 00 00 
   293bf:	83 7f 04 00          	cmpl   $0x0,0x4(%rdi)
   293c3:	0f 84 88 0a 00 00    	je     29e51 <myl_core_values_copy_box+0xad1>
   293c9:	48 89 bd 68 f9 ff ff 	mov    %rdi,-0x698(%rbp)
   293d0:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
   293d7:	48 89 85 70 f9 ff ff 	mov    %rax,-0x690(%rbp)
   293de:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
   293e5:	48 89 85 78 f9 ff ff 	mov    %rax,-0x688(%rbp)
   293ec:	b8 01 00 00 00       	mov    $0x1,%eax
   293f1:	eb 1d                	jmp    29410 <myl_core_values_copy_box+0x90>
   293f3:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   293f7:	4c 89 08             	mov    %r9,(%rax)
   293fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   29400:	48 8b 85 58 f9 ff ff 	mov    -0x6a8(%rbp),%rax
   29407:	48 85 c0             	test   %rax,%rax
   2940a:	0f 84 29 0a 00 00    	je     29e39 <myl_core_values_copy_box+0xab9>
   29410:	48 8b 8d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rcx
   29417:	48 ff c8             	dec    %rax
   2941a:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   29421:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   29425:	48 8b 1c c1          	mov    (%rcx,%rax,8),%rbx
   29429:	48 8b 74 c1 08       	mov    0x8(%rcx,%rax,8),%rsi
   2942e:	48 8b 7c c1 10       	mov    0x10(%rcx,%rax,8),%rdi
   29433:	8b 53 04             	mov    0x4(%rbx),%edx
   29436:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
   2943a:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
   2943e:	e8 00 00 00 00       	call   29443 <myl_core_values_copy_box+0xc3>
			2943f: R_X86_64_PLT32	memcpy-0x4
   29443:	8b 03                	mov    (%rbx),%eax
   29445:	48 83 f8 0a          	cmp    $0xa,%rax
   29449:	0f 87 20 0a 00 00    	ja     29e6f <myl_core_values_copy_box+0xaef>
   2944f:	49 89 d8             	mov    %rbx,%r8
   29452:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 29459 <myl_core_values_copy_box+0xd9>
			29455: R_X86_64_PC32	.rodata+0x270
   29459:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
   2945d:	48 01 d1             	add    %rdx,%rcx
   29460:	ff e1                	jmp    *%rcx
   29462:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   29466:	48 8b 39             	mov    (%rcx),%rdi
   29469:	48 85 ff             	test   %rdi,%rdi
   2946c:	74 92                	je     29400 <myl_core_values_copy_box+0x80>
   2946e:	83 f8 09             	cmp    $0x9,%eax
   29471:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
   29475:	0f 85 bc 05 00 00    	jne    29a37 <myl_core_values_copy_box+0x6b7>
   2947b:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   2947f:	e8 fc fe fd ff       	call   9380 <core_dict_copy_storage>
   29484:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29488:	49 89 c1             	mov    %rax,%r9
   2948b:	4d 8b 50 18          	mov    0x18(%r8),%r10
   2948f:	49 8b 42 20          	mov    0x20(%r10),%rax
   29493:	48 85 c0             	test   %rax,%rax
   29496:	0f 84 57 ff ff ff    	je     293f3 <myl_core_values_copy_box+0x73>
   2949c:	4d 8d 58 20          	lea    0x20(%r8),%r11
   294a0:	4c 89 c9             	mov    %r9,%rcx
   294a3:	48 83 c1 20          	add    $0x20,%rcx
   294a7:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
   294ab:	45 31 ff             	xor    %r15d,%r15d
   294ae:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   294b2:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
   294b6:	4c 89 55 80          	mov    %r10,-0x80(%rbp)
   294ba:	4c 89 5d 88          	mov    %r11,-0x78(%rbp)
   294be:	eb 42                	jmp    29502 <myl_core_values_copy_box+0x182>
   294c0:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   294c7:	4d 01 dc             	add    %r11,%r12
   294ca:	49 01 dc             	add    %rbx,%r12
   294cd:	48 03 5d c0          	add    -0x40(%rbp),%rbx
   294d1:	48 01 f3             	add    %rsi,%rbx
   294d4:	49 8d 46 01          	lea    0x1(%r14),%rax
   294d8:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   294df:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
   294e3:	49 89 4c c5 00       	mov    %rcx,0x0(%r13,%rax,8)
   294e8:	4d 89 64 c5 08       	mov    %r12,0x8(%r13,%rax,8)
   294ed:	49 89 5c c5 10       	mov    %rbx,0x10(%r13,%rax,8)
   294f2:	49 8b 42 20          	mov    0x20(%r10),%rax
   294f6:	49 ff c7             	inc    %r15
   294f9:	49 39 c7             	cmp    %rax,%r15
   294fc:	0f 83 f1 fe ff ff    	jae    293f3 <myl_core_values_copy_box+0x73>
   29502:	49 8b 4a 18          	mov    0x18(%r10),%rcx
   29506:	48 85 c9             	test   %rcx,%rcx
   29509:	74 16                	je     29521 <myl_core_values_copy_box+0x1a1>
   2950b:	4c 89 fa             	mov    %r15,%rdx
   2950e:	48 c1 ea 03          	shr    $0x3,%rdx
   29512:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
   29516:	44 89 fa             	mov    %r15d,%edx
   29519:	83 e2 07             	and    $0x7,%edx
   2951c:	0f a3 d1             	bt     %edx,%ecx
   2951f:	72 d5                	jb     294f6 <myl_core_values_copy_box+0x176>
   29521:	48 8b 47 10          	mov    0x10(%rdi),%rax
   29525:	48 8b 10             	mov    (%rax),%rdx
   29528:	49 8b 48 18          	mov    0x18(%r8),%rcx
   2952c:	48 8b 09             	mov    (%rcx),%rcx
   2952f:	44 8b 21             	mov    (%rcx),%r12d
   29532:	4d 0f af e7          	imul   %r15,%r12
   29536:	49 8b 49 18          	mov    0x18(%r9),%rcx
   2953a:	48 8b 09             	mov    (%rcx),%rcx
   2953d:	8b 31                	mov    (%rcx),%esi
   2953f:	49 0f af f7          	imul   %r15,%rsi
   29543:	83 7a 04 00          	cmpl   $0x0,0x4(%rdx)
   29547:	0f 84 1e 01 00 00    	je     2966b <myl_core_values_copy_box+0x2eb>
   2954d:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   29554:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   2955b:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
   2955f:	0f 85 c7 00 00 00    	jne    2962c <myl_core_values_copy_box+0x2ac>
   29565:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
   29569:	48 85 db             	test   %rbx,%rbx
   2956c:	0f 88 f8 08 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29572:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   29576:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   2957d:	aa aa 0a 
   29580:	48 39 c1             	cmp    %rax,%rcx
   29583:	0f 87 e1 08 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29589:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
   2958d:	48 89 d8             	mov    %rbx,%rax
   29590:	48 c1 e0 04          	shl    $0x4,%rax
   29594:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29598:	e8 00 00 00 00       	call   2959d <myl_core_values_copy_box+0x21d>
			29599: R_X86_64_PLT32	malloc-0x4
   2959d:	48 85 c0             	test   %rax,%rax
   295a0:	0f 84 c4 08 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   295a6:	49 89 c5             	mov    %rax,%r13
   295a9:	4c 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r14
   295b0:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   295b7:	00 
   295b8:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   295bc:	4c 89 ef             	mov    %r13,%rdi
   295bf:	4c 89 f6             	mov    %r14,%rsi
   295c2:	e8 00 00 00 00       	call   295c7 <myl_core_values_copy_box+0x247>
			295c3: R_X86_64_PLT32	memcpy-0x4
   295c7:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   295ce:	49 39 c6             	cmp    %rax,%r14
   295d1:	74 0f                	je     295e2 <myl_core_values_copy_box+0x262>
   295d3:	4c 89 f7             	mov    %r14,%rdi
   295d6:	e8 00 00 00 00       	call   295db <myl_core_values_copy_box+0x25b>
			295d7: R_X86_64_PLT32	free-0x4
   295db:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   295e2:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   295e9:	48 8b 45 90          	mov    -0x70(%rbp),%rax
   295ed:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   295f4:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   295f8:	48 8b 47 10          	mov    0x10(%rdi),%rax
   295fc:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29600:	49 8b 48 18          	mov    0x18(%r8),%rcx
   29604:	48 8b 09             	mov    (%rcx),%rcx
   29607:	8b 09                	mov    (%rcx),%ecx
   29609:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   2960d:	49 8b 51 18          	mov    0x18(%r9),%rdx
   29611:	48 8b 12             	mov    (%rdx),%rdx
   29614:	8b 12                	mov    (%rdx),%edx
   29616:	49 0f af cf          	imul   %r15,%rcx
   2961a:	49 0f af d7          	imul   %r15,%rdx
   2961e:	4c 8b 55 80          	mov    -0x80(%rbp),%r10
   29622:	4c 8b 5d 88          	mov    -0x78(%rbp),%r11
   29626:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
   2962a:	eb 0d                	jmp    29639 <myl_core_values_copy_box+0x2b9>
   2962c:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   29633:	48 89 f2             	mov    %rsi,%rdx
   29636:	4c 89 e1             	mov    %r12,%rcx
   29639:	4d 01 dc             	add    %r11,%r12
   2963c:	48 03 75 c0          	add    -0x40(%rbp),%rsi
   29640:	49 89 f6             	mov    %rsi,%r14
   29643:	48 8d 73 01          	lea    0x1(%rbx),%rsi
   29647:	48 89 b5 58 f9 ff ff 	mov    %rsi,-0x6a8(%rbp)
   2964e:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
   29652:	48 8b 5d a0          	mov    -0x60(%rbp),%rbx
   29656:	49 89 5c f5 00       	mov    %rbx,0x0(%r13,%rsi,8)
   2965b:	4d 89 64 f5 08       	mov    %r12,0x8(%r13,%rsi,8)
   29660:	4d 89 74 f5 10       	mov    %r14,0x10(%r13,%rsi,8)
   29665:	48 89 d6             	mov    %rdx,%rsi
   29668:	49 89 cc             	mov    %rcx,%r12
   2966b:	48 8b 48 08          	mov    0x8(%rax),%rcx
   2966f:	83 79 04 00          	cmpl   $0x0,0x4(%rcx)
   29673:	0f 84 79 fe ff ff    	je     294f2 <myl_core_values_copy_box+0x172>
   29679:	49 8b 02             	mov    (%r10),%rax
   2967c:	8b 58 04             	mov    0x4(%rax),%ebx
   2967f:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29686:	4c 3b b5 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r14
   2968d:	0f 85 2d fe ff ff    	jne    294c0 <myl_core_values_copy_box+0x140>
   29693:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
   29697:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
   2969b:	4d 85 f6             	test   %r14,%r14
   2969e:	0f 88 c6 07 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   296a4:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
   296a8:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   296af:	aa aa 0a 
   296b2:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
   296b6:	48 39 c1             	cmp    %rax,%rcx
   296b9:	0f 87 ab 07 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   296bf:	4c 89 f0             	mov    %r14,%rax
   296c2:	48 c1 e0 04          	shl    $0x4,%rax
   296c6:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   296ca:	e8 00 00 00 00       	call   296cf <myl_core_values_copy_box+0x34f>
			296cb: R_X86_64_PLT32	malloc-0x4
   296cf:	48 85 c0             	test   %rax,%rax
   296d2:	0f 84 92 07 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   296d8:	49 89 c5             	mov    %rax,%r13
   296db:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   296e2:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
   296e9:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
   296f0:	00 
   296f1:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   296f5:	4c 89 ef             	mov    %r13,%rdi
   296f8:	e8 00 00 00 00       	call   296fd <myl_core_values_copy_box+0x37d>
			296f9: R_X86_64_PLT32	memcpy-0x4
   296fd:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
   29704:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   2970b:	48 39 c7             	cmp    %rax,%rdi
   2970e:	74 0c                	je     2971c <myl_core_values_copy_box+0x39c>
   29710:	e8 00 00 00 00       	call   29715 <myl_core_values_copy_box+0x395>
			29711: R_X86_64_PLT32	free-0x4
   29715:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   2971c:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   29723:	48 8b 45 90          	mov    -0x70(%rbp),%rax
   29727:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   2972e:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
   29732:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
   29736:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   2973a:	4c 8b 55 80          	mov    -0x80(%rbp),%r10
   2973e:	4c 8b 5d 88          	mov    -0x78(%rbp),%r11
   29742:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
   29746:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
   2974a:	e9 78 fd ff ff       	jmp    294c7 <myl_core_values_copy_box+0x147>
   2974f:	49 8b 40 10          	mov    0x10(%r8),%rax
   29753:	48 8b 00             	mov    (%rax),%rax
   29756:	83 38 03             	cmpl   $0x3,(%rax)
   29759:	0f 82 a1 fc ff ff    	jb     29400 <myl_core_values_copy_box+0x80>
   2975f:	41 8b 40 08          	mov    0x8(%r8),%eax
   29763:	85 c0                	test   %eax,%eax
   29765:	0f 84 95 fc ff ff    	je     29400 <myl_core_values_copy_box+0x80>
   2976b:	45 31 f6             	xor    %r14d,%r14d
   2976e:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   29772:	eb 50                	jmp    297c4 <myl_core_values_copy_box+0x444>
   29774:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2977b:	00 00 00 00 00 
   29780:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   29787:	44 89 f9             	mov    %r15d,%ecx
   2978a:	49 0f af ce          	imul   %r14,%rcx
   2978e:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29792:	48 01 ca             	add    %rcx,%rdx
   29795:	48 03 4d b0          	add    -0x50(%rbp),%rcx
   29799:	48 8d 73 01          	lea    0x1(%rbx),%rsi
   2979d:	48 89 b5 58 f9 ff ff 	mov    %rsi,-0x6a8(%rbp)
   297a4:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
   297a8:	4d 89 2c f4          	mov    %r13,(%r12,%rsi,8)
   297ac:	49 89 54 f4 08       	mov    %rdx,0x8(%r12,%rsi,8)
   297b1:	49 89 4c f4 10       	mov    %rcx,0x10(%r12,%rsi,8)
   297b6:	49 ff c6             	inc    %r14
   297b9:	89 c1                	mov    %eax,%ecx
   297bb:	49 39 ce             	cmp    %rcx,%r14
   297be:	0f 83 3c fc ff ff    	jae    29400 <myl_core_values_copy_box+0x80>
   297c4:	49 8b 48 10          	mov    0x10(%r8),%rcx
   297c8:	4c 8b 29             	mov    (%rcx),%r13
   297cb:	45 8b 7d 04          	mov    0x4(%r13),%r15d
   297cf:	41 83 7d 00 03       	cmpl   $0x3,0x0(%r13)
   297d4:	0f 92 c1             	setb   %cl
   297d7:	45 85 ff             	test   %r15d,%r15d
   297da:	0f 94 c2             	sete   %dl
   297dd:	08 ca                	or     %cl,%dl
   297df:	75 d5                	jne    297b6 <myl_core_values_copy_box+0x436>
   297e1:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   297e8:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   297ef:	75 8f                	jne    29780 <myl_core_values_copy_box+0x400>
   297f1:	48 85 db             	test   %rbx,%rbx
   297f4:	0f 88 70 06 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   297fa:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   297fe:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29805:	aa aa 0a 
   29808:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
   2980c:	48 39 c1             	cmp    %rax,%rcx
   2980f:	0f 87 55 06 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29815:	48 89 d8             	mov    %rbx,%rax
   29818:	48 c1 e0 04          	shl    $0x4,%rax
   2981c:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29820:	e8 00 00 00 00       	call   29825 <myl_core_values_copy_box+0x4a5>
			29821: R_X86_64_PLT32	malloc-0x4
   29825:	48 85 c0             	test   %rax,%rax
   29828:	0f 84 3c 06 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   2982e:	49 89 c4             	mov    %rax,%r12
   29831:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   29838:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
   2983c:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   29843:	00 
   29844:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29848:	4c 89 e7             	mov    %r12,%rdi
   2984b:	e8 00 00 00 00       	call   29850 <myl_core_values_copy_box+0x4d0>
			2984c: R_X86_64_PLT32	memcpy-0x4
   29850:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
   29854:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   2985b:	48 39 c7             	cmp    %rax,%rdi
   2985e:	74 0c                	je     2986c <myl_core_values_copy_box+0x4ec>
   29860:	e8 00 00 00 00       	call   29865 <myl_core_values_copy_box+0x4e5>
			29861: R_X86_64_PLT32	free-0x4
   29865:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   2986c:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   29873:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
   29877:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   2987e:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   29882:	41 8b 40 08          	mov    0x8(%r8),%eax
   29886:	e9 fc fe ff ff       	jmp    29787 <myl_core_values_copy_box+0x407>
   2988b:	41 83 78 0c 01       	cmpl   $0x1,0xc(%r8)
   29890:	0f 84 6a fb ff ff    	je     29400 <myl_core_values_copy_box+0x80>
   29896:	e9 d4 05 00 00       	jmp    29e6f <myl_core_values_copy_box+0xaef>
   2989b:	41 8b 40 0c          	mov    0xc(%r8),%eax
   2989f:	85 c0                	test   %eax,%eax
   298a1:	0f 84 44 02 00 00    	je     29aeb <myl_core_values_copy_box+0x76b>
   298a7:	ba 02 00 00 00       	mov    $0x2,%edx
   298ac:	29 c2                	sub    %eax,%edx
   298ae:	8d 48 ff             	lea    -0x1(%rax),%ecx
   298b1:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
   298b5:	48 83 3e 00          	cmpq   $0x0,(%rsi)
   298b9:	0f 45 ca             	cmovne %edx,%ecx
   298bc:	e9 31 02 00 00       	jmp    29af2 <myl_core_values_copy_box+0x772>
   298c1:	41 8b 40 08          	mov    0x8(%r8),%eax
   298c5:	85 c0                	test   %eax,%eax
   298c7:	0f 84 33 fb ff ff    	je     29400 <myl_core_values_copy_box+0x80>
   298cd:	45 31 f6             	xor    %r14d,%r14d
   298d0:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
   298d4:	eb 3d                	jmp    29913 <myl_core_values_copy_box+0x593>
   298d6:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   298dd:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   298e1:	4c 01 f9             	add    %r15,%rcx
   298e4:	4c 03 7d b0          	add    -0x50(%rbp),%r15
   298e8:	48 8d 53 01          	lea    0x1(%rbx),%rdx
   298ec:	48 89 95 58 f9 ff ff 	mov    %rdx,-0x6a8(%rbp)
   298f3:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
   298f7:	4d 89 2c d4          	mov    %r13,(%r12,%rdx,8)
   298fb:	49 89 4c d4 08       	mov    %rcx,0x8(%r12,%rdx,8)
   29900:	4d 89 7c d4 10       	mov    %r15,0x10(%r12,%rdx,8)
   29905:	49 ff c6             	inc    %r14
   29908:	89 c1                	mov    %eax,%ecx
   2990a:	49 39 ce             	cmp    %rcx,%r14
   2990d:	0f 83 ed fa ff ff    	jae    29400 <myl_core_values_copy_box+0x80>
   29913:	49 8b 48 10          	mov    0x10(%r8),%rcx
   29917:	4e 8b 2c f1          	mov    (%rcx,%r14,8),%r13
   2991b:	41 83 7d 00 03       	cmpl   $0x3,0x0(%r13)
   29920:	72 e3                	jb     29905 <myl_core_values_copy_box+0x585>
   29922:	41 83 7d 04 00       	cmpl   $0x0,0x4(%r13)
   29927:	74 dc                	je     29905 <myl_core_values_copy_box+0x585>
   29929:	49 8b 48 18          	mov    0x18(%r8),%rcx
   2992d:	46 8b 3c b1          	mov    (%rcx,%r14,4),%r15d
   29931:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   29938:	48 3b 9d 60 f9 ff ff 	cmp    -0x6a0(%rbp),%rbx
   2993f:	75 95                	jne    298d6 <myl_core_values_copy_box+0x556>
   29941:	48 85 db             	test   %rbx,%rbx
   29944:	0f 88 20 05 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   2994a:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   2994e:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29955:	aa aa 0a 
   29958:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
   2995c:	48 39 c1             	cmp    %rax,%rcx
   2995f:	0f 87 05 05 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29965:	48 89 d8             	mov    %rbx,%rax
   29968:	48 c1 e0 04          	shl    $0x4,%rax
   2996c:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29970:	e8 00 00 00 00       	call   29975 <myl_core_values_copy_box+0x5f5>
			29971: R_X86_64_PLT32	malloc-0x4
   29975:	48 85 c0             	test   %rax,%rax
   29978:	0f 84 ec 04 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   2997e:	49 89 c4             	mov    %rax,%r12
   29981:	48 8b b5 50 f9 ff ff 	mov    -0x6b0(%rbp),%rsi
   29988:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
   2998c:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
   29993:	00 
   29994:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29998:	4c 89 e7             	mov    %r12,%rdi
   2999b:	e8 00 00 00 00       	call   299a0 <myl_core_values_copy_box+0x620>
			2999c: R_X86_64_PLT32	memcpy-0x4
   299a0:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
   299a4:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   299ab:	48 39 c7             	cmp    %rax,%rdi
   299ae:	74 0c                	je     299bc <myl_core_values_copy_box+0x63c>
   299b0:	e8 00 00 00 00       	call   299b5 <myl_core_values_copy_box+0x635>
			299b1: R_X86_64_PLT32	free-0x4
   299b5:	48 8b 9d 58 f9 ff ff 	mov    -0x6a8(%rbp),%rbx
   299bc:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   299c3:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
   299c7:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   299ce:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
   299d2:	41 8b 40 08          	mov    0x8(%r8),%eax
   299d6:	e9 02 ff ff ff       	jmp    298dd <myl_core_values_copy_box+0x55d>
   299db:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
   299df:	4c 8b 38             	mov    (%rax),%r15
   299e2:	4d 85 ff             	test   %r15,%r15
   299e5:	0f 84 15 fa ff ff    	je     29400 <myl_core_values_copy_box+0x80>
   299eb:	41 80 3f 05          	cmpb   $0x5,(%r15)
   299ef:	0f 85 da 01 00 00    	jne    29bcf <myl_core_values_copy_box+0x84f>
   299f5:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   299f9:	48 85 db             	test   %rbx,%rbx
   299fc:	0f 88 68 04 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29a02:	bf 05 00 00 00       	mov    $0x5,%edi
   29a07:	48 89 de             	mov    %rbx,%rsi
   29a0a:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29a0e:	e8 2d 42 00 00       	call   2dc40 <block_alloc>
   29a13:	49 89 c4             	mov    %rax,%r12
   29a16:	48 89 58 10          	mov    %rbx,0x10(%rax)
   29a1a:	49 8b 57 08          	mov    0x8(%r15),%rdx
   29a1e:	48 89 50 08          	mov    %rdx,0x8(%rax)
   29a22:	48 8d 78 20          	lea    0x20(%rax),%rdi
   29a26:	49 83 c7 20          	add    $0x20,%r15
   29a2a:	4c 89 fe             	mov    %r15,%rsi
   29a2d:	e8 00 00 00 00       	call   29a32 <myl_core_values_copy_box+0x6b2>
			29a2e: R_X86_64_PLT32	memcpy-0x4
   29a32:	e9 67 02 00 00       	jmp    29c9e <myl_core_values_copy_box+0x91e>
   29a37:	49 8b 48 10          	mov    0x10(%r8),%rcx
   29a3b:	48 8b 19             	mov    (%rcx),%rbx
   29a3e:	83 f8 06             	cmp    $0x6,%eax
   29a41:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
   29a45:	75 45                	jne    29a8c <myl_core_values_copy_box+0x70c>
   29a47:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
   29a4b:	8b 58 04             	mov    0x4(%rax),%ebx
   29a4e:	bf 02 00 00 00       	mov    $0x2,%edi
   29a53:	48 89 de             	mov    %rbx,%rsi
   29a56:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29a5a:	e8 e1 41 00 00       	call   2dc40 <block_alloc>
   29a5f:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29a63:	49 89 c1             	mov    %rax,%r9
   29a66:	48 89 58 10          	mov    %rbx,0x10(%rax)
   29a6a:	48 89 58 08          	mov    %rbx,0x8(%rax)
   29a6e:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
   29a72:	48 8b 42 18          	mov    0x18(%rdx),%rax
   29a76:	49 89 41 18          	mov    %rax,0x18(%r9)
   29a7a:	48 8b 42 08          	mov    0x8(%rdx),%rax
   29a7e:	49 89 41 08          	mov    %rax,0x8(%r9)
   29a82:	be 01 00 00 00       	mov    $0x1,%esi
   29a87:	e9 85 02 00 00       	jmp    29d11 <myl_core_values_copy_box+0x991>
   29a8c:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   29a90:	48 85 f6             	test   %rsi,%rsi
   29a93:	0f 88 d1 03 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29a99:	44 8b 6b 04          	mov    0x4(%rbx),%r13d
   29a9d:	4d 85 ed             	test   %r13,%r13
   29aa0:	0f 84 af 01 00 00    	je     29c55 <myl_core_values_copy_box+0x8d5>
   29aa6:	48 c7 c0 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rax
   29aad:	31 d2                	xor    %edx,%edx
   29aaf:	49 f7 f5             	div    %r13
   29ab2:	48 39 c6             	cmp    %rax,%rsi
   29ab5:	0f 87 af 03 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29abb:	49 89 f6             	mov    %rsi,%r14
   29abe:	49 0f af f5          	imul   %r13,%rsi
   29ac2:	31 ff                	xor    %edi,%edi
   29ac4:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29ac8:	e8 73 41 00 00       	call   2dc40 <block_alloc>
   29acd:	49 89 c1             	mov    %rax,%r9
   29ad0:	48 8b 45 98          	mov    -0x68(%rbp),%rax
   29ad4:	48 89 c1             	mov    %rax,%rcx
   29ad7:	48 c1 e9 20          	shr    $0x20,%rcx
   29adb:	0f 84 07 02 00 00    	je     29ce8 <myl_core_values_copy_box+0x968>
   29ae1:	31 d2                	xor    %edx,%edx
   29ae3:	49 f7 f5             	div    %r13
   29ae6:	e9 02 02 00 00       	jmp    29ced <myl_core_values_copy_box+0x96d>
   29aeb:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
   29aef:	48 8b 09             	mov    (%rcx),%rcx
   29af2:	41 8b 50 08          	mov    0x8(%r8),%edx
   29af6:	48 39 d1             	cmp    %rdx,%rcx
   29af9:	0f 83 70 03 00 00    	jae    29e6f <myl_core_values_copy_box+0xaef>
   29aff:	45 31 ed             	xor    %r13d,%r13d
   29b02:	85 c0                	test   %eax,%eax
   29b04:	0f 94 c2             	sete   %dl
   29b07:	49 8b 40 10          	mov    0x10(%r8),%rax
   29b0b:	4c 8b 34 c8          	mov    (%rax,%rcx,8),%r14
   29b0f:	41 83 3e 03          	cmpl   $0x3,(%r14)
   29b13:	0f 82 e7 f8 ff ff    	jb     29400 <myl_core_values_copy_box+0x80>
   29b19:	41 83 7e 04 00       	cmpl   $0x0,0x4(%r14)
   29b1e:	0f 84 dc f8 ff ff    	je     29400 <myl_core_values_copy_box+0x80>
   29b24:	4c 8b bd 58 f9 ff ff 	mov    -0x6a8(%rbp),%r15
   29b2b:	4c 3b bd 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r15
   29b32:	0f 85 72 01 00 00    	jne    29caa <myl_core_values_copy_box+0x92a>
   29b38:	4d 85 ff             	test   %r15,%r15
   29b3b:	0f 88 29 03 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29b41:	4b 8d 0c 3f          	lea    (%r15,%r15,1),%rcx
   29b45:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29b4c:	aa aa 0a 
   29b4f:	48 39 c1             	cmp    %rax,%rcx
   29b52:	0f 87 12 03 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29b58:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   29b5c:	88 55 b8             	mov    %dl,-0x48(%rbp)
   29b5f:	4c 89 f8             	mov    %r15,%rax
   29b62:	48 c1 e0 04          	shl    $0x4,%rax
   29b66:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29b6a:	e8 00 00 00 00       	call   29b6f <myl_core_values_copy_box+0x7ef>
			29b6b: R_X86_64_PLT32	malloc-0x4
   29b6f:	48 85 c0             	test   %rax,%rax
   29b72:	0f 84 f2 02 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   29b78:	49 89 c4             	mov    %rax,%r12
   29b7b:	48 8b 9d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rbx
   29b82:	4a 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%rax
   29b89:	00 
   29b8a:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29b8e:	4c 89 e7             	mov    %r12,%rdi
   29b91:	48 89 de             	mov    %rbx,%rsi
   29b94:	e8 00 00 00 00       	call   29b99 <myl_core_values_copy_box+0x819>
			29b95: R_X86_64_PLT32	memcpy-0x4
   29b99:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29ba0:	48 39 c3             	cmp    %rax,%rbx
   29ba3:	74 0f                	je     29bb4 <myl_core_values_copy_box+0x834>
   29ba5:	48 89 df             	mov    %rbx,%rdi
   29ba8:	e8 00 00 00 00       	call   29bad <myl_core_values_copy_box+0x82d>
			29ba9: R_X86_64_PLT32	free-0x4
   29bad:	4c 8b bd 58 f9 ff ff 	mov    -0x6a8(%rbp),%r15
   29bb4:	4c 89 a5 50 f9 ff ff 	mov    %r12,-0x6b0(%rbp)
   29bbb:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   29bbf:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29bc6:	0f b6 55 b8          	movzbl -0x48(%rbp),%edx
   29bca:	e9 e2 00 00 00       	jmp    29cb1 <myl_core_values_copy_box+0x931>
   29bcf:	4d 8b 6f 08          	mov    0x8(%r15),%r13
   29bd3:	4d 85 ed             	test   %r13,%r13
   29bd6:	0f 88 8e 02 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29bdc:	4d 8d 77 20          	lea    0x20(%r15),%r14
   29be0:	49 8d 75 01          	lea    0x1(%r13),%rsi
   29be4:	bf 01 00 00 00       	mov    $0x1,%edi
   29be9:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29bed:	e8 4e 40 00 00       	call   2dc40 <block_alloc>
   29bf2:	49 89 c4             	mov    %rax,%r12
   29bf5:	4c 89 68 10          	mov    %r13,0x10(%rax)
   29bf9:	48 8d 58 20          	lea    0x20(%rax),%rbx
   29bfd:	48 89 df             	mov    %rbx,%rdi
   29c00:	4c 89 f6             	mov    %r14,%rsi
   29c03:	4c 89 ea             	mov    %r13,%rdx
   29c06:	e8 00 00 00 00       	call   29c0b <myl_core_values_copy_box+0x88b>
			29c07: R_X86_64_PLT32	memcpy-0x4
   29c0b:	43 c6 44 2c 20 00    	movb   $0x0,0x20(%r12,%r13,1)
   29c11:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
   29c16:	41 8b 04 24          	mov    (%r12),%eax
   29c1a:	b9 ff e0 ff ff       	mov    $0xffffe0ff,%ecx
   29c1f:	21 c8                	and    %ecx,%eax
   29c21:	41 89 04 24          	mov    %eax,(%r12)
   29c25:	49 c7 44 24 18 00 00 	movq   $0x0,0x18(%r12)
   29c2c:	00 00 
   29c2e:	31 c9                	xor    %ecx,%ecx
   29c30:	48 be 80 80 80 80 80 	movabs $0x8080808080808080,%rsi
   29c37:	80 80 80 
   29c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   29c40:	48 8d 51 08          	lea    0x8(%rcx),%rdx
   29c44:	4c 39 ea             	cmp    %r13,%rdx
   29c47:	77 30                	ja     29c79 <myl_core_values_copy_box+0x8f9>
   29c49:	49 85 74 0c 20       	test   %rsi,0x20(%r12,%rcx,1)
   29c4e:	48 89 d1             	mov    %rdx,%rcx
   29c51:	74 ed                	je     29c40 <myl_core_values_copy_box+0x8c0>
   29c53:	eb 42                	jmp    29c97 <myl_core_values_copy_box+0x917>
   29c55:	4c 0f af ee          	imul   %rsi,%r13
   29c59:	31 ff                	xor    %edi,%edi
   29c5b:	49 89 f6             	mov    %rsi,%r14
   29c5e:	4c 89 ee             	mov    %r13,%rsi
   29c61:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
   29c65:	e8 d6 3f 00 00       	call   2dc40 <block_alloc>
   29c6a:	4c 89 f6             	mov    %r14,%rsi
   29c6d:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29c71:	49 89 c1             	mov    %rax,%r9
   29c74:	4c 89 f0             	mov    %r14,%rax
   29c77:	eb 7b                	jmp    29cf4 <myl_core_values_copy_box+0x974>
   29c79:	4c 39 e9             	cmp    %r13,%rcx
   29c7c:	73 10                	jae    29c8e <myl_core_values_copy_box+0x90e>
   29c7e:	66 90                	xchg   %ax,%ax
   29c80:	80 3c 0b 00          	cmpb   $0x0,(%rbx,%rcx,1)
   29c84:	78 11                	js     29c97 <myl_core_values_copy_box+0x917>
   29c86:	48 ff c1             	inc    %rcx
   29c89:	49 39 cd             	cmp    %rcx,%r13
   29c8c:	75 f2                	jne    29c80 <myl_core_values_copy_box+0x900>
   29c8e:	0d 00 01 00 00       	or     $0x100,%eax
   29c93:	41 89 04 24          	mov    %eax,(%r12)
   29c97:	41 8a 07             	mov    (%r15),%al
   29c9a:	41 89 04 24          	mov    %eax,(%r12)
   29c9e:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   29ca2:	4c 89 20             	mov    %r12,(%rax)
   29ca5:	e9 56 f7 ff ff       	jmp    29400 <myl_core_values_copy_box+0x80>
   29caa:	4c 8b a5 50 f9 ff ff 	mov    -0x6b0(%rbp),%r12
   29cb1:	41 88 d5             	mov    %dl,%r13b
   29cb4:	41 c1 e5 03          	shl    $0x3,%r13d
   29cb8:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29cbc:	4c 01 ea             	add    %r13,%rdx
   29cbf:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
   29cc3:	4c 01 e9             	add    %r13,%rcx
   29cc6:	49 8d 47 01          	lea    0x1(%r15),%rax
   29cca:	48 89 85 58 f9 ff ff 	mov    %rax,-0x6a8(%rbp)
   29cd1:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
   29cd5:	4d 89 34 c4          	mov    %r14,(%r12,%rax,8)
   29cd9:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
   29cde:	49 89 4c c4 10       	mov    %rcx,0x10(%r12,%rax,8)
   29ce3:	e9 18 f7 ff ff       	jmp    29400 <myl_core_values_copy_box+0x80>
   29ce8:	31 d2                	xor    %edx,%edx
   29cea:	41 f7 f5             	div    %r13d
   29ced:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29cf1:	4c 89 f6             	mov    %r14,%rsi
   29cf4:	49 89 41 10          	mov    %rax,0x10(%r9)
   29cf8:	48 8b 42 18          	mov    0x18(%rdx),%rax
   29cfc:	49 89 41 18          	mov    %rax,0x18(%r9)
   29d00:	48 8b 42 08          	mov    0x8(%rdx),%rax
   29d04:	49 89 41 08          	mov    %rax,0x8(%r9)
   29d08:	48 85 f6             	test   %rsi,%rsi
   29d0b:	0f 84 e2 f6 ff ff    	je     293f3 <myl_core_values_copy_box+0x73>
   29d11:	48 83 c2 20          	add    $0x20,%rdx
   29d15:	49 8d 79 20          	lea    0x20(%r9),%rdi
   29d19:	45 31 e4             	xor    %r12d,%r12d
   29d1c:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
   29d20:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
   29d24:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
   29d28:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
   29d2c:	eb 4e                	jmp    29d7c <myl_core_values_copy_box+0x9fc>
   29d2e:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   29d35:	0f 1f 84 00 00 00 00 
   29d3c:	00 
   29d3d:	0f 1f 00             	nopl   (%rax)
   29d40:	4c 8b ad 50 f9 ff ff 	mov    -0x6b0(%rbp),%r13
   29d47:	4d 0f af fc          	imul   %r12,%r15
   29d4b:	4a 8d 04 3a          	lea    (%rdx,%r15,1),%rax
   29d4f:	49 01 ff             	add    %rdi,%r15
   29d52:	49 8d 4e 01          	lea    0x1(%r14),%rcx
   29d56:	48 89 8d 58 f9 ff ff 	mov    %rcx,-0x6a8(%rbp)
   29d5d:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
   29d61:	49 89 5c cd 00       	mov    %rbx,0x0(%r13,%rcx,8)
   29d66:	49 89 44 cd 08       	mov    %rax,0x8(%r13,%rcx,8)
   29d6b:	4d 89 7c cd 10       	mov    %r15,0x10(%r13,%rcx,8)
   29d70:	49 ff c4             	inc    %r12
   29d73:	4c 39 e6             	cmp    %r12,%rsi
   29d76:	0f 84 77 f6 ff ff    	je     293f3 <myl_core_values_copy_box+0x73>
   29d7c:	44 8b 7b 04          	mov    0x4(%rbx),%r15d
   29d80:	4d 85 ff             	test   %r15,%r15
   29d83:	74 eb                	je     29d70 <myl_core_values_copy_box+0x9f0>
   29d85:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29d8c:	4c 3b b5 60 f9 ff ff 	cmp    -0x6a0(%rbp),%r14
   29d93:	75 ab                	jne    29d40 <myl_core_values_copy_box+0x9c0>
   29d95:	4d 85 f6             	test   %r14,%r14
   29d98:	0f 88 cc 00 00 00    	js     29e6a <myl_core_values_copy_box+0xaea>
   29d9e:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
   29da2:	48 b8 aa aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaa,%rax
   29da9:	aa aa 0a 
   29dac:	48 39 c1             	cmp    %rax,%rcx
   29daf:	0f 87 b5 00 00 00    	ja     29e6a <myl_core_values_copy_box+0xaea>
   29db5:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
   29db9:	4c 89 f0             	mov    %r14,%rax
   29dbc:	48 c1 e0 04          	shl    $0x4,%rax
   29dc0:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   29dc4:	e8 00 00 00 00       	call   29dc9 <myl_core_values_copy_box+0xa49>
			29dc5: R_X86_64_PLT32	malloc-0x4
   29dc9:	48 85 c0             	test   %rax,%rax
   29dcc:	0f 84 98 00 00 00    	je     29e6a <myl_core_values_copy_box+0xaea>
   29dd2:	49 89 c5             	mov    %rax,%r13
   29dd5:	48 8b 9d 50 f9 ff ff 	mov    -0x6b0(%rbp),%rbx
   29ddc:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
   29de3:	00 
   29de4:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   29de8:	4c 89 ef             	mov    %r13,%rdi
   29deb:	48 89 de             	mov    %rbx,%rsi
   29dee:	e8 00 00 00 00       	call   29df3 <myl_core_values_copy_box+0xa73>
			29def: R_X86_64_PLT32	memcpy-0x4
   29df3:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29dfa:	48 39 c3             	cmp    %rax,%rbx
   29dfd:	74 0f                	je     29e0e <myl_core_values_copy_box+0xa8e>
   29dff:	48 89 df             	mov    %rbx,%rdi
   29e02:	e8 00 00 00 00       	call   29e07 <myl_core_values_copy_box+0xa87>
			29e03: R_X86_64_PLT32	free-0x4
   29e07:	4c 8b b5 58 f9 ff ff 	mov    -0x6a8(%rbp),%r14
   29e0e:	4c 89 ad 50 f9 ff ff 	mov    %r13,-0x6b0(%rbp)
   29e15:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   29e19:	48 89 85 60 f9 ff ff 	mov    %rax,-0x6a0(%rbp)
   29e20:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
   29e24:	4c 8b 4d b8          	mov    -0x48(%rbp),%r9
   29e28:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
   29e2c:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
   29e30:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
   29e34:	e9 0e ff ff ff       	jmp    29d47 <myl_core_values_copy_box+0x9c7>
   29e39:	48 8b bd 50 f9 ff ff 	mov    -0x6b0(%rbp),%rdi
   29e40:	48 8d 85 68 f9 ff ff 	lea    -0x698(%rbp),%rax
   29e47:	48 39 c7             	cmp    %rax,%rdi
   29e4a:	74 05                	je     29e51 <myl_core_values_copy_box+0xad1>
   29e4c:	e8 00 00 00 00       	call   29e51 <myl_core_values_copy_box+0xad1>
			29e4d: R_X86_64_PLT32	free-0x4
   29e51:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
   29e58:	48 81 c4 88 06 00 00 	add    $0x688,%rsp
   29e5f:	5b                   	pop    %rbx
   29e60:	41 5c                	pop    %r12
   29e62:	41 5d                	pop    %r13
   29e64:	41 5e                	pop    %r14
   29e66:	41 5f                	pop    %r15
   29e68:	5d                   	pop    %rbp
   29e69:	c3                   	ret
   29e6a:	e8 51 75 fd ff       	call   13c0 <out_of_memory>
   29e6f:	e8 00 00 00 00       	call   29e74 <myl_core_values_copy_box+0xaf4>
			29e70: R_X86_64_PLT32	abort-0x4

Disassembly of section .text.unlikely.:
