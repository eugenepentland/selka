define ptr @myl_core_values_copy_box(ptr noundef %0, ptr noundef %1) local_unnamed_addr #0 align 64 {
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.core_copy_stack, align 8
  %9 = alloca ptr, align 8
  store ptr %1, ptr %7, align 8, !tbaa !38
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #75
  %10 = getelementptr inbounds nuw i8, ptr %8, i64 24
  store ptr %10, ptr %8, align 8, !tbaa !740
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 16
  store i64 64, ptr %12, align 8, !tbaa !742
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #75
  store ptr null, ptr %9, align 8, !tbaa !38
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %14 = load i32, ptr %13, align 4, !tbaa !706
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %566, label %16

16:                                               ; preds = %2
  store ptr %0, ptr %10, align 8, !tbaa !700
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 32
  store ptr %7, ptr %17, align 8, !tbaa !111
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 40
  store ptr %9, ptr %18, align 8, !tbaa !111
  br label %19

19:                                               ; preds = %16, %559
  %20 = phi i64 [ %560, %559 ], [ 1, %16 ]
  %21 = load ptr, ptr %8, align 8, !tbaa !740
  %22 = add i64 %20, -1
  store i64 %22, ptr %11, align 8, !tbaa !743
  %23 = getelementptr inbounds nuw %struct.core_copy_work, ptr %21, i64 %22
  %24 = load ptr, ptr %23, align 8, !tbaa !700
  %25 = getelementptr inbounds nuw i8, ptr %23, i64 8
  %26 = load ptr, ptr %25, align 8, !tbaa !111
  %27 = getelementptr inbounds nuw i8, ptr %23, i64 16
  %28 = load ptr, ptr %27, align 8, !tbaa !111
  %29 = getelementptr inbounds nuw i8, ptr %24, i64 4
  %30 = load i32, ptr %29, align 4, !tbaa !706
  %31 = zext i32 %30 to i64
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %28, ptr align 1 %26, i64 %31, i1 false)
  %32 = load i32, ptr %24, align 8, !tbaa !702
  switch i32 %32, label %558 [
    i32 0, label %559
    i32 1, label %559
    i32 2, label %559
    i32 3, label %40
    i32 4, label %33
    i32 5, label %164
    i32 6, label %230
    i32 7, label %230
    i32 9, label %230
    i32 8, label %487
    i32 10, label %553
  ]

33:                                               ; preds = %19
  %34 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %35 = load i32, ptr %34, align 8, !tbaa !705
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %559, label %37

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %39 = getelementptr inbounds nuw i8, ptr %24, i64 24
  br label %105

40:                                               ; preds = %19
  %41 = load ptr, ptr %26, align 1
  %42 = icmp eq ptr %41, null
  br i1 %42, label %559, label %43

43:                                               ; preds = %40
  %44 = load i32, ptr %41, align 8, !tbaa !33
  %45 = and i32 %44, 255
  %46 = icmp eq i32 %45, 5
  br i1 %46, label %47, label %60

47:                                               ; preds = %43
  %48 = getelementptr inbounds nuw i8, ptr %41, i64 16
  %49 = load i64, ptr %48, align 8, !tbaa !32
  %50 = icmp slt i64 %49, 0
  br i1 %50, label %51, label %52

51:                                               ; preds = %47
  call fastcc void @out_of_memory()
  unreachable

52:                                               ; preds = %47
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #75
  %53 = call fastcc noundef ptr @block_alloc(i32 noundef 5, i64 noundef %49, ptr noundef %6)
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 16
  store i64 %49, ptr %54, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #75
  %55 = getelementptr inbounds nuw i8, ptr %41, i64 8
  %56 = load i64, ptr %55, align 8, !tbaa !28
  %57 = getelementptr inbounds nuw i8, ptr %53, i64 8
  store i64 %56, ptr %57, align 8, !tbaa !28
  %58 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %59 = getelementptr inbounds nuw i8, ptr %41, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %58, ptr nonnull readonly align 1 %59, i64 %56, i1 false)
  br label %103

60:                                               ; preds = %43
  %61 = getelementptr inbounds nuw i8, ptr %41, i64 8
  %62 = load i64, ptr %61, align 8, !tbaa !28
  %63 = icmp sgt i64 %62, -1
  br i1 %63, label %65, label %64

64:                                               ; preds = %60
  call fastcc void @out_of_memory()
  unreachable

65:                                               ; preds = %60
  %66 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %67 = add nuw i64 %62, 1
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #75
  %68 = call fastcc ptr @block_alloc(i32 noundef 1, i64 noundef %67, ptr noundef %5)
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 16
  store i64 %62, ptr %69, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #75
  %70 = getelementptr inbounds nuw i8, ptr %68, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %70, ptr nonnull readonly align 1 %66, i64 %62, i1 false)
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 %62
  store i8 0, ptr %71, align 1, !tbaa !39
  %72 = getelementptr inbounds nuw i8, ptr %68, i64 8
  store i64 %62, ptr %72, align 8, !tbaa !28
  %73 = load i32, ptr %68, align 8, !tbaa !33
  %74 = and i32 %73, -7937
  store i32 %74, ptr %68, align 8, !tbaa !33
  %75 = getelementptr inbounds nuw i8, ptr %68, i64 24
  store i64 0, ptr %75, align 8, !tbaa !35
  br label %76

76:                                               ; preds = %82, %65
  %77 = phi i64 [ 0, %65 ], [ %78, %82 ]
  %78 = add i64 %77, 8
  %79 = icmp ugt i64 %78, %62
  br i1 %79, label %80, label %82

80:                                               ; preds = %76
  %81 = icmp ult i64 %77, %62
  br i1 %81, label %90, label %95

82:                                               ; preds = %76
  %83 = getelementptr inbounds nuw i8, ptr %70, i64 %77
  %84 = load i64, ptr %83, align 1
  %85 = and i64 %84, -9187201950435737472
  %86 = icmp eq i64 %85, 0
  br i1 %86, label %76, label %97, !llvm.loop !106

87:                                               ; preds = %90
  %88 = add i64 %91, 1
  %89 = icmp eq i64 %88, %62
  br i1 %89, label %95, label %90, !llvm.loop !107

90:                                               ; preds = %80, %87
  %91 = phi i64 [ %88, %87 ], [ %77, %80 ]
  %92 = getelementptr inbounds nuw i8, ptr %70, i64 %91
  %93 = load i8, ptr %92, align 1, !tbaa !39
  %94 = icmp sgt i8 %93, -1
  br i1 %94, label %87, label %97

95:                                               ; preds = %87, %80
  %96 = or disjoint i32 %74, 256
  store i32 %96, ptr %68, align 8, !tbaa !33
  br label %97

97:                                               ; preds = %82, %90, %95
  %98 = phi i32 [ %74, %90 ], [ %96, %95 ], [ %74, %82 ]
  %99 = and i32 %98, -256
  %100 = load i32, ptr %41, align 8, !tbaa !33
  %101 = and i32 %100, 255
  %102 = or disjoint i32 %101, %99
  store i32 %102, ptr %68, align 8, !tbaa !33
  br label %103

103:                                              ; preds = %97, %52
  %104 = phi ptr [ %53, %52 ], [ %68, %97 ]
  store ptr %104, ptr %28, align 1
  br label %559

105:                                              ; preds = %37, %158
  %106 = phi i32 [ %35, %37 ], [ %159, %158 ]
  %107 = phi i32 [ %35, %37 ], [ %160, %158 ]
  %108 = phi i64 [ 0, %37 ], [ %161, %158 ]
  %109 = load ptr, ptr %38, align 8, !tbaa !707
  %110 = getelementptr inbounds nuw ptr, ptr %109, i64 %108
  %111 = load ptr, ptr %110, align 8, !tbaa !700
  %112 = load ptr, ptr %39, align 8, !tbaa !708
  %113 = getelementptr inbounds nuw i32, ptr %112, i64 %108
  %114 = load i32, ptr %113, align 4, !tbaa !6
  %115 = zext i32 %114 to i64
  %116 = getelementptr inbounds nuw i8, ptr %26, i64 %115
  %117 = getelementptr inbounds nuw i8, ptr %28, i64 %115
  %118 = load i32, ptr %111, align 8, !tbaa !702
  %119 = icmp ult i32 %118, 3
  br i1 %119, label %158, label %120

120:                                              ; preds = %105
  %121 = getelementptr inbounds nuw i8, ptr %111, i64 4
  %122 = load i32, ptr %121, align 4, !tbaa !706
  %123 = icmp eq i32 %122, 0
  br i1 %123, label %158, label %124

124:                                              ; preds = %120
  %125 = load i64, ptr %11, align 8, !tbaa !743
  %126 = load i64, ptr %12, align 8, !tbaa !742
  %127 = icmp eq i64 %125, %126
  br i1 %127, label %130, label %128

128:                                              ; preds = %124
  %129 = load ptr, ptr %8, align 8, !tbaa !740
  br label %150

130:                                              ; preds = %124
  %131 = shl i64 %125, 1
  %132 = icmp slt i64 %125, 0
  %133 = icmp ugt i64 %131, 768614336404564650
  %134 = or i1 %132, %133
  br i1 %134, label %135, label %136

135:                                              ; preds = %130
  call fastcc void @out_of_memory()
  unreachable

136:                                              ; preds = %130
  %137 = mul i64 %125, 48
  %138 = call noalias ptr @malloc(i64 noundef %137) #81
  %139 = icmp eq ptr %138, null
  br i1 %139, label %140, label %141

140:                                              ; preds = %136
  call fastcc void @out_of_memory()
  unreachable

141:                                              ; preds = %136
  %142 = load ptr, ptr %8, align 8, !tbaa !740
  %143 = mul i64 %125, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %138, ptr align 8 %142, i64 %143, i1 false)
  %144 = icmp eq ptr %142, %10
  br i1 %144, label %147, label %145

145:                                              ; preds = %141
  call void @free(ptr noundef %142) #75
  %146 = load i64, ptr %11, align 8, !tbaa !743
  br label %147

147:                                              ; preds = %145, %141
  %148 = phi i64 [ %146, %145 ], [ %125, %141 ]
  store ptr %138, ptr %8, align 8, !tbaa !740
  store i64 %131, ptr %12, align 8, !tbaa !742
  %149 = load i32, ptr %34, align 8, !tbaa !705
  br label %150

150:                                              ; preds = %147, %128
  %151 = phi i32 [ %106, %128 ], [ %149, %147 ]
  %152 = phi i64 [ %125, %128 ], [ %148, %147 ]
  %153 = phi ptr [ %129, %128 ], [ %138, %147 ]
  %154 = add i64 %152, 1
  store i64 %154, ptr %11, align 8, !tbaa !743
  %155 = getelementptr inbounds nuw %struct.core_copy_work, ptr %153, i64 %152
  store ptr %111, ptr %155, align 8, !tbaa !700
  %156 = getelementptr inbounds nuw i8, ptr %155, i64 8
  store ptr %116, ptr %156, align 8, !tbaa !111
  %157 = getelementptr inbounds nuw i8, ptr %155, i64 16
  store ptr %117, ptr %157, align 8, !tbaa !111
  br label %158

158:                                              ; preds = %150, %120, %105
  %159 = phi i32 [ %151, %150 ], [ %106, %120 ], [ %106, %105 ]
  %160 = phi i32 [ %151, %150 ], [ %107, %120 ], [ %107, %105 ]
  %161 = add nuw nsw i64 %108, 1
  %162 = zext i32 %160 to i64
  %163 = icmp samesign ult i64 %161, %162
  br i1 %163, label %105, label %559, !llvm.loop !744

164:                                              ; preds = %19
  %165 = getelementptr inbounds nuw i8, ptr %24, i64 12
  %166 = load i32, ptr %165, align 4, !tbaa !710
  %167 = icmp eq i32 %166, 0
  br i1 %167, label %175, label %168

168:                                              ; preds = %164
  %169 = load ptr, ptr %26, align 1
  %170 = icmp eq ptr %169, null
  %171 = sub i32 2, %166
  %172 = add i32 %166, -1
  %173 = select i1 %170, i32 %172, i32 %171
  %174 = zext i32 %173 to i64
  br label %177

175:                                              ; preds = %164
  %176 = load i64, ptr %26, align 1
  br label %177

177:                                              ; preds = %168, %175
  %178 = phi i64 [ %174, %168 ], [ %176, %175 ]
  %179 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %180 = load i32, ptr %179, align 8, !tbaa !705
  %181 = zext i32 %180 to i64
  %182 = icmp ult i64 %178, %181
  br i1 %182, label %184, label %183

183:                                              ; preds = %177
  call void @abort() #79
  unreachable

184:                                              ; preds = %177
  %185 = select i1 %167, i64 8, i64 0
  %186 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %187 = load ptr, ptr %186, align 8, !tbaa !707
  %188 = getelementptr inbounds nuw ptr, ptr %187, i64 %178
  %189 = load ptr, ptr %188, align 8, !tbaa !700
  %190 = getelementptr inbounds nuw i8, ptr %26, i64 %185
  %191 = getelementptr inbounds nuw i8, ptr %28, i64 %185
  %192 = load i32, ptr %189, align 8, !tbaa !702
  %193 = icmp ult i32 %192, 3
  br i1 %193, label %559, label %194

194:                                              ; preds = %184
  %195 = getelementptr inbounds nuw i8, ptr %189, i64 4
  %196 = load i32, ptr %195, align 4, !tbaa !706
  %197 = icmp eq i32 %196, 0
  br i1 %197, label %559, label %198

198:                                              ; preds = %194
  %199 = load i64, ptr %11, align 8, !tbaa !743
  %200 = load i64, ptr %12, align 8, !tbaa !742
  %201 = icmp eq i64 %199, %200
  br i1 %201, label %204, label %202

202:                                              ; preds = %198
  %203 = load ptr, ptr %8, align 8, !tbaa !740
  br label %223

204:                                              ; preds = %198
  %205 = shl i64 %199, 1
  %206 = icmp slt i64 %199, 0
  %207 = icmp ugt i64 %205, 768614336404564650
  %208 = or i1 %206, %207
  br i1 %208, label %209, label %210

209:                                              ; preds = %204
  call fastcc void @out_of_memory()
  unreachable

210:                                              ; preds = %204
  %211 = mul i64 %199, 48
  %212 = call noalias ptr @malloc(i64 noundef %211) #81
  %213 = icmp eq ptr %212, null
  br i1 %213, label %214, label %215

214:                                              ; preds = %210
  call fastcc void @out_of_memory()
  unreachable

215:                                              ; preds = %210
  %216 = load ptr, ptr %8, align 8, !tbaa !740
  %217 = mul i64 %199, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %212, ptr align 8 %216, i64 %217, i1 false)
  %218 = icmp eq ptr %216, %10
  br i1 %218, label %221, label %219

219:                                              ; preds = %215
  call void @free(ptr noundef %216) #75
  %220 = load i64, ptr %11, align 8, !tbaa !743
  br label %221

221:                                              ; preds = %219, %215
  %222 = phi i64 [ %220, %219 ], [ %199, %215 ]
  store ptr %212, ptr %8, align 8, !tbaa !740
  store i64 %205, ptr %12, align 8, !tbaa !742
  br label %223

223:                                              ; preds = %221, %202
  %224 = phi i64 [ %199, %202 ], [ %222, %221 ]
  %225 = phi ptr [ %203, %202 ], [ %212, %221 ]
  %226 = add i64 %224, 1
  store i64 %226, ptr %11, align 8, !tbaa !743
  %227 = getelementptr inbounds nuw %struct.core_copy_work, ptr %225, i64 %224
  store ptr %189, ptr %227, align 8, !tbaa !700
  %228 = getelementptr inbounds nuw i8, ptr %227, i64 8
  store ptr %190, ptr %228, align 8, !tbaa !111
  %229 = getelementptr inbounds nuw i8, ptr %227, i64 16
  store ptr %191, ptr %229, align 8, !tbaa !111
  br label %559

230:                                              ; preds = %19, %19, %19
  %231 = load ptr, ptr %26, align 1
  %232 = icmp eq ptr %231, null
  br i1 %232, label %559, label %233

233:                                              ; preds = %230
  %234 = icmp eq i32 %32, 9
  br i1 %234, label %235, label %387

235:                                              ; preds = %233
  %236 = call fastcc ptr @core_dict_copy_storage(ptr noundef nonnull %231)
  %237 = getelementptr inbounds nuw i8, ptr %231, i64 24
  %238 = load i64, ptr %237, align 8, !tbaa !35
  %239 = inttoptr i64 %238 to ptr
  %240 = getelementptr inbounds nuw i8, ptr %239, i64 32
  %241 = load i64, ptr %240, align 8, !tbaa !95
  %242 = icmp eq i64 %241, 0
  br i1 %242, label %485, label %243

243:                                              ; preds = %235
  %244 = getelementptr inbounds nuw i8, ptr %239, i64 24
  %245 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %246 = getelementptr inbounds nuw i8, ptr %231, i64 32
  %247 = getelementptr inbounds nuw i8, ptr %236, i64 32
  %248 = getelementptr inbounds nuw i8, ptr %236, i64 24
  br label %249

249:                                              ; preds = %383, %243
  %250 = phi i64 [ %241, %243 ], [ %384, %383 ]
  %251 = phi i64 [ 0, %243 ], [ %385, %383 ]
  %252 = load ptr, ptr %244, align 8, !tbaa !96
  %253 = icmp eq ptr %252, null
  br i1 %253, label %264, label %254

254:                                              ; preds = %249
  %255 = lshr i64 %251, 3
  %256 = getelementptr inbounds nuw i8, ptr %252, i64 %255
  %257 = load i8, ptr %256, align 1, !tbaa !39
  %258 = zext i8 %257 to i32
  %259 = trunc i64 %251 to i32
  %260 = and i32 %259, 7
  %261 = shl nuw nsw i32 1, %260
  %262 = and i32 %261, %258
  %263 = icmp eq i32 %262, 0
  br i1 %263, label %264, label %383

264:                                              ; preds = %254, %249
  %265 = load ptr, ptr %245, align 8, !tbaa !707
  %266 = load ptr, ptr %265, align 8, !tbaa !700
  %267 = load i64, ptr %237, align 8, !tbaa !35
  %268 = inttoptr i64 %267 to ptr
  %269 = load ptr, ptr %268, align 8, !tbaa !89
  %270 = load i32, ptr %269, align 8, !tbaa !97
  %271 = zext i32 %270 to i64
  %272 = mul i64 %251, %271
  %273 = getelementptr inbounds nuw i8, ptr %246, i64 %272
  %274 = load i64, ptr %248, align 8, !tbaa !35
  %275 = inttoptr i64 %274 to ptr
  %276 = load ptr, ptr %275, align 8, !tbaa !89
  %277 = load i32, ptr %276, align 8, !tbaa !97
  %278 = zext i32 %277 to i64
  %279 = mul i64 %251, %278
  %280 = getelementptr inbounds nuw i8, ptr %247, i64 %279
  %281 = getelementptr inbounds nuw i8, ptr %266, i64 4
  %282 = load i32, ptr %281, align 4, !tbaa !706
  %283 = icmp eq i32 %282, 0
  br i1 %283, label %332, label %284

284:                                              ; preds = %264
  %285 = load i64, ptr %11, align 8, !tbaa !743
  %286 = load i64, ptr %12, align 8, !tbaa !742
  %287 = icmp eq i64 %285, %286
  br i1 %287, label %290, label %288

288:                                              ; preds = %284
  %289 = load ptr, ptr %8, align 8, !tbaa !740
  br label %322

290:                                              ; preds = %284
  %291 = shl i64 %285, 1
  %292 = icmp slt i64 %285, 0
  %293 = icmp ugt i64 %291, 768614336404564650
  %294 = or i1 %292, %293
  br i1 %294, label %295, label %296

295:                                              ; preds = %290
  call fastcc void @out_of_memory()
  unreachable

296:                                              ; preds = %290
  %297 = mul i64 %285, 48
  %298 = call noalias ptr @malloc(i64 noundef %297) #81
  %299 = icmp eq ptr %298, null
  br i1 %299, label %300, label %301

300:                                              ; preds = %296
  call fastcc void @out_of_memory()
  unreachable

301:                                              ; preds = %296
  %302 = load ptr, ptr %8, align 8, !tbaa !740
  %303 = mul i64 %285, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %298, ptr align 8 %302, i64 %303, i1 false)
  %304 = icmp eq ptr %302, %10
  br i1 %304, label %307, label %305

305:                                              ; preds = %301
  call void @free(ptr noundef %302) #75
  %306 = load i64, ptr %11, align 8, !tbaa !743
  br label %307

307:                                              ; preds = %305, %301
  %308 = phi i64 [ %306, %305 ], [ %285, %301 ]
  store ptr %298, ptr %8, align 8, !tbaa !740
  store i64 %291, ptr %12, align 8, !tbaa !742
  %309 = load ptr, ptr %245, align 8, !tbaa !707
  %310 = load i64, ptr %237, align 8, !tbaa !35
  %311 = inttoptr i64 %310 to ptr
  %312 = load ptr, ptr %311, align 8, !tbaa !89
  %313 = load i32, ptr %312, align 8, !tbaa !97
  %314 = load i64, ptr %248, align 8, !tbaa !35
  %315 = inttoptr i64 %314 to ptr
  %316 = load ptr, ptr %315, align 8, !tbaa !89
  %317 = load i32, ptr %316, align 8, !tbaa !97
  %318 = zext i32 %313 to i64
  %319 = mul i64 %251, %318
  %320 = zext i32 %317 to i64
  %321 = mul i64 %251, %320
  br label %322

322:                                              ; preds = %307, %288
  %323 = phi i64 [ %321, %307 ], [ %279, %288 ]
  %324 = phi i64 [ %319, %307 ], [ %272, %288 ]
  %325 = phi ptr [ %309, %307 ], [ %265, %288 ]
  %326 = phi i64 [ %308, %307 ], [ %285, %288 ]
  %327 = phi ptr [ %298, %307 ], [ %289, %288 ]
  %328 = add i64 %326, 1
  store i64 %328, ptr %11, align 8, !tbaa !743
  %329 = getelementptr inbounds nuw %struct.core_copy_work, ptr %327, i64 %326
  store ptr %266, ptr %329, align 8, !tbaa !700
  %330 = getelementptr inbounds nuw i8, ptr %329, i64 8
  store ptr %273, ptr %330, align 8, !tbaa !111
  %331 = getelementptr inbounds nuw i8, ptr %329, i64 16
  store ptr %280, ptr %331, align 8, !tbaa !111
  br label %332

332:                                              ; preds = %264, %322
  %333 = phi i64 [ %279, %264 ], [ %323, %322 ]
  %334 = phi i64 [ %272, %264 ], [ %324, %322 ]
  %335 = phi ptr [ %265, %264 ], [ %325, %322 ]
  %336 = getelementptr inbounds nuw i8, ptr %335, i64 8
  %337 = load ptr, ptr %336, align 8, !tbaa !700
  %338 = getelementptr inbounds nuw i8, ptr %246, i64 %334
  %339 = load ptr, ptr %239, align 8, !tbaa !89
  %340 = getelementptr inbounds nuw i8, ptr %339, i64 4
  %341 = load i32, ptr %340, align 4, !tbaa !314
  %342 = zext i32 %341 to i64
  %343 = getelementptr inbounds nuw i8, ptr %338, i64 %342
  %344 = getelementptr inbounds nuw i8, ptr %247, i64 %333
  %345 = getelementptr inbounds nuw i8, ptr %344, i64 %342
  %346 = getelementptr inbounds nuw i8, ptr %337, i64 4
  %347 = load i32, ptr %346, align 4, !tbaa !706
  %348 = icmp eq i32 %347, 0
  br i1 %348, label %381, label %349

349:                                              ; preds = %332
  %350 = load i64, ptr %11, align 8, !tbaa !743
  %351 = load i64, ptr %12, align 8, !tbaa !742
  %352 = icmp eq i64 %350, %351
  br i1 %352, label %355, label %353

353:                                              ; preds = %349
  %354 = load ptr, ptr %8, align 8, !tbaa !740
  br label %374

355:                                              ; preds = %349
  %356 = shl i64 %350, 1
  %357 = icmp slt i64 %350, 0
  %358 = icmp ugt i64 %356, 768614336404564650
  %359 = or i1 %357, %358
  br i1 %359, label %360, label %361

360:                                              ; preds = %355
  call fastcc void @out_of_memory()
  unreachable

361:                                              ; preds = %355
  %362 = mul i64 %350, 48
  %363 = call noalias ptr @malloc(i64 noundef %362) #81
  %364 = icmp eq ptr %363, null
  br i1 %364, label %365, label %366

365:                                              ; preds = %361
  call fastcc void @out_of_memory()
  unreachable

366:                                              ; preds = %361
  %367 = load ptr, ptr %8, align 8, !tbaa !740
  %368 = mul i64 %350, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %363, ptr align 8 %367, i64 %368, i1 false)
  %369 = icmp eq ptr %367, %10
  br i1 %369, label %372, label %370

370:                                              ; preds = %366
  call void @free(ptr noundef %367) #75
  %371 = load i64, ptr %11, align 8, !tbaa !743
  br label %372

372:                                              ; preds = %370, %366
  %373 = phi i64 [ %371, %370 ], [ %350, %366 ]
  store ptr %363, ptr %8, align 8, !tbaa !740
  store i64 %356, ptr %12, align 8, !tbaa !742
  br label %374

374:                                              ; preds = %372, %353
  %375 = phi i64 [ %350, %353 ], [ %373, %372 ]
  %376 = phi ptr [ %354, %353 ], [ %363, %372 ]
  %377 = add i64 %375, 1
  store i64 %377, ptr %11, align 8, !tbaa !743
  %378 = getelementptr inbounds nuw %struct.core_copy_work, ptr %376, i64 %375
  store ptr %337, ptr %378, align 8, !tbaa !700
  %379 = getelementptr inbounds nuw i8, ptr %378, i64 8
  store ptr %343, ptr %379, align 8, !tbaa !111
  %380 = getelementptr inbounds nuw i8, ptr %378, i64 16
  store ptr %345, ptr %380, align 8, !tbaa !111
  br label %381

381:                                              ; preds = %332, %374
  %382 = load i64, ptr %240, align 8, !tbaa !95
  br label %383

383:                                              ; preds = %381, %254
  %384 = phi i64 [ %250, %254 ], [ %382, %381 ]
  %385 = add nuw i64 %251, 1
  %386 = icmp ult i64 %385, %384
  br i1 %386, label %249, label %485, !llvm.loop !745

387:                                              ; preds = %233
  %388 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %389 = load ptr, ptr %388, align 8, !tbaa !707
  %390 = load ptr, ptr %389, align 8, !tbaa !700
  %391 = icmp eq i32 %32, 6
  br i1 %391, label %392, label %404

392:                                              ; preds = %387
  %393 = getelementptr inbounds nuw i8, ptr %390, i64 4
  %394 = load i32, ptr %393, align 4, !tbaa !706
  %395 = zext i32 %394 to i64
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #75
  %396 = call fastcc ptr @block_alloc(i32 noundef 2, i64 noundef %395, ptr noundef %4)
  %397 = getelementptr inbounds nuw i8, ptr %396, i64 16
  store i64 %395, ptr %397, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #75
  %398 = getelementptr inbounds nuw i8, ptr %396, i64 8
  store i64 %395, ptr %398, align 8, !tbaa !28
  %399 = getelementptr inbounds nuw i8, ptr %231, i64 24
  %400 = load i64, ptr %399, align 8, !tbaa !35
  %401 = getelementptr inbounds nuw i8, ptr %396, i64 24
  store i64 %400, ptr %401, align 8, !tbaa !35
  %402 = getelementptr inbounds nuw i8, ptr %231, i64 8
  %403 = load i64, ptr %402, align 8, !tbaa !28
  store i64 %403, ptr %398, align 8, !tbaa !28
  br label %436

404:                                              ; preds = %387
  %405 = getelementptr inbounds nuw i8, ptr %231, i64 8
  %406 = load i64, ptr %405, align 8, !tbaa !28
  %407 = getelementptr inbounds nuw i8, ptr %390, i64 4
  %408 = load i32, ptr %407, align 4, !tbaa !706
  %409 = zext i32 %408 to i64
  %410 = icmp sgt i64 %406, -1
  br i1 %410, label %412, label %411

411:                                              ; preds = %404
  call fastcc void @out_of_memory()
  unreachable

412:                                              ; preds = %404
  %413 = icmp eq i32 %408, 0
  br i1 %413, label %423, label %414

414:                                              ; preds = %412
  %415 = udiv i64 -64, %409
  %416 = icmp ugt i64 %406, %415
  br i1 %416, label %417, label %418

417:                                              ; preds = %414
  call fastcc void @out_of_memory()
  unreachable

418:                                              ; preds = %414
  %419 = mul i64 %406, %409
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #75
  %420 = call fastcc ptr @block_alloc(i32 noundef 0, i64 noundef %419, ptr noundef %3)
  %421 = load i64, ptr %3, align 8, !tbaa !31
  %422 = udiv i64 %421, %409
  br label %426

423:                                              ; preds = %412
  %424 = mul nuw nsw i64 %406, %409
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #75
  %425 = call fastcc ptr @block_alloc(i32 noundef 0, i64 noundef %424, ptr noundef %3)
  br label %426

426:                                              ; preds = %423, %418
  %427 = phi ptr [ %420, %418 ], [ %425, %423 ]
  %428 = phi i64 [ %422, %418 ], [ %406, %423 ]
  %429 = getelementptr inbounds nuw i8, ptr %427, i64 16
  store i64 %428, ptr %429, align 8, !tbaa !32
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #75
  %430 = getelementptr inbounds nuw i8, ptr %231, i64 24
  %431 = load i64, ptr %430, align 8, !tbaa !35
  %432 = getelementptr inbounds nuw i8, ptr %427, i64 24
  store i64 %431, ptr %432, align 8, !tbaa !35
  %433 = load i64, ptr %405, align 8, !tbaa !28
  %434 = getelementptr inbounds nuw i8, ptr %427, i64 8
  store i64 %433, ptr %434, align 8, !tbaa !28
  %435 = icmp eq i64 %406, 0
  br i1 %435, label %485, label %436

436:                                              ; preds = %426, %392
  %437 = phi ptr [ %396, %392 ], [ %427, %426 ]
  %438 = phi i64 [ 1, %392 ], [ %406, %426 ]
  %439 = getelementptr inbounds nuw i8, ptr %231, i64 32
  %440 = getelementptr inbounds nuw i8, ptr %390, i64 4
  %441 = getelementptr inbounds nuw i8, ptr %437, i64 32
  br label %442

442:                                              ; preds = %482, %436
  %443 = phi i64 [ 0, %436 ], [ %483, %482 ]
  %444 = load i32, ptr %440, align 4, !tbaa !706
  %445 = zext i32 %444 to i64
  %446 = mul i64 %443, %445
  %447 = getelementptr inbounds nuw i8, ptr %439, i64 %446
  %448 = getelementptr inbounds nuw i8, ptr %441, i64 %446
  %449 = icmp eq i32 %444, 0
  br i1 %449, label %482, label %450

450:                                              ; preds = %442
  %451 = load i64, ptr %11, align 8, !tbaa !743
  %452 = load i64, ptr %12, align 8, !tbaa !742
  %453 = icmp eq i64 %451, %452
  br i1 %453, label %456, label %454

454:                                              ; preds = %450
  %455 = load ptr, ptr %8, align 8, !tbaa !740
  br label %475

456:                                              ; preds = %450
  %457 = shl i64 %451, 1
  %458 = icmp slt i64 %451, 0
  %459 = icmp ugt i64 %457, 768614336404564650
  %460 = or i1 %458, %459
  br i1 %460, label %461, label %462

461:                                              ; preds = %456
  call fastcc void @out_of_memory()
  unreachable

462:                                              ; preds = %456
  %463 = mul i64 %451, 48
  %464 = call noalias ptr @malloc(i64 noundef %463) #81
  %465 = icmp eq ptr %464, null
  br i1 %465, label %466, label %467

466:                                              ; preds = %462
  call fastcc void @out_of_memory()
  unreachable

467:                                              ; preds = %462
  %468 = load ptr, ptr %8, align 8, !tbaa !740
  %469 = mul i64 %451, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %464, ptr align 8 %468, i64 %469, i1 false)
  %470 = icmp eq ptr %468, %10
  br i1 %470, label %473, label %471

471:                                              ; preds = %467
  call void @free(ptr noundef %468) #75
  %472 = load i64, ptr %11, align 8, !tbaa !743
  br label %473

473:                                              ; preds = %471, %467
  %474 = phi i64 [ %472, %471 ], [ %451, %467 ]
  store ptr %464, ptr %8, align 8, !tbaa !740
  store i64 %457, ptr %12, align 8, !tbaa !742
  br label %475

475:                                              ; preds = %473, %454
  %476 = phi i64 [ %451, %454 ], [ %474, %473 ]
  %477 = phi ptr [ %455, %454 ], [ %464, %473 ]
  %478 = add i64 %476, 1
  store i64 %478, ptr %11, align 8, !tbaa !743
  %479 = getelementptr inbounds nuw %struct.core_copy_work, ptr %477, i64 %476
  store ptr %390, ptr %479, align 8, !tbaa !700
  %480 = getelementptr inbounds nuw i8, ptr %479, i64 8
  store ptr %447, ptr %480, align 8, !tbaa !111
  %481 = getelementptr inbounds nuw i8, ptr %479, i64 16
  store ptr %448, ptr %481, align 8, !tbaa !111
  br label %482

482:                                              ; preds = %442, %475
  %483 = add nuw nsw i64 %443, 1
  %484 = icmp eq i64 %483, %438
  br i1 %484, label %485, label %442, !llvm.loop !746

485:                                              ; preds = %482, %383, %235, %426
  %486 = phi ptr [ %236, %235 ], [ %427, %426 ], [ %236, %383 ], [ %437, %482 ]
  store ptr %486, ptr %28, align 1
  br label %559

487:                                              ; preds = %19
  %488 = getelementptr inbounds nuw i8, ptr %24, i64 16
  %489 = load ptr, ptr %488, align 8, !tbaa !707
  %490 = load ptr, ptr %489, align 8, !tbaa !700
  %491 = load i32, ptr %490, align 8, !tbaa !702
  %492 = icmp ult i32 %491, 3
  br i1 %492, label %559, label %493

493:                                              ; preds = %487
  %494 = getelementptr inbounds nuw i8, ptr %24, i64 8
  %495 = load i32, ptr %494, align 8, !tbaa !705
  %496 = icmp eq i32 %495, 0
  br i1 %496, label %559, label %497

497:                                              ; preds = %493, %547
  %498 = phi i32 [ %548, %547 ], [ %495, %493 ]
  %499 = phi i32 [ %549, %547 ], [ %495, %493 ]
  %500 = phi i64 [ %550, %547 ], [ 0, %493 ]
  %501 = load ptr, ptr %488, align 8, !tbaa !707
  %502 = load ptr, ptr %501, align 8, !tbaa !700
  %503 = getelementptr inbounds nuw i8, ptr %502, i64 4
  %504 = load i32, ptr %503, align 4, !tbaa !706
  %505 = zext i32 %504 to i64
  %506 = mul nuw i64 %500, %505
  %507 = getelementptr inbounds nuw i8, ptr %26, i64 %506
  %508 = getelementptr inbounds nuw i8, ptr %28, i64 %506
  %509 = load i32, ptr %502, align 8, !tbaa !702
  %510 = icmp ult i32 %509, 3
  %511 = icmp eq i32 %504, 0
  %512 = select i1 %510, i1 true, i1 %511
  br i1 %512, label %547, label %513

513:                                              ; preds = %497
  %514 = load i64, ptr %11, align 8, !tbaa !743
  %515 = load i64, ptr %12, align 8, !tbaa !742
  %516 = icmp eq i64 %514, %515
  br i1 %516, label %519, label %517

517:                                              ; preds = %513
  %518 = load ptr, ptr %8, align 8, !tbaa !740
  br label %539

519:                                              ; preds = %513
  %520 = shl i64 %514, 1
  %521 = icmp slt i64 %514, 0
  %522 = icmp ugt i64 %520, 768614336404564650
  %523 = or i1 %521, %522
  br i1 %523, label %524, label %525

524:                                              ; preds = %519
  call fastcc void @out_of_memory()
  unreachable

525:                                              ; preds = %519
  %526 = mul i64 %514, 48
  %527 = call noalias ptr @malloc(i64 noundef %526) #81
  %528 = icmp eq ptr %527, null
  br i1 %528, label %529, label %530

529:                                              ; preds = %525
  call fastcc void @out_of_memory()
  unreachable

530:                                              ; preds = %525
  %531 = load ptr, ptr %8, align 8, !tbaa !740
  %532 = mul i64 %514, 24
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %527, ptr align 8 %531, i64 %532, i1 false)
  %533 = icmp eq ptr %531, %10
  br i1 %533, label %536, label %534

534:                                              ; preds = %530
  call void @free(ptr noundef %531) #75
  %535 = load i64, ptr %11, align 8, !tbaa !743
  br label %536

536:                                              ; preds = %534, %530
  %537 = phi i64 [ %535, %534 ], [ %514, %530 ]
  store ptr %527, ptr %8, align 8, !tbaa !740
  store i64 %520, ptr %12, align 8, !tbaa !742
  %538 = load i32, ptr %494, align 8, !tbaa !705
  br label %539

539:                                              ; preds = %536, %517
  %540 = phi i32 [ %498, %517 ], [ %538, %536 ]
  %541 = phi i64 [ %514, %517 ], [ %537, %536 ]
  %542 = phi ptr [ %518, %517 ], [ %527, %536 ]
  %543 = add i64 %541, 1
  store i64 %543, ptr %11, align 8, !tbaa !743
  %544 = getelementptr inbounds nuw %struct.core_copy_work, ptr %542, i64 %541
  store ptr %502, ptr %544, align 8, !tbaa !700
  %545 = getelementptr inbounds nuw i8, ptr %544, i64 8
  store ptr %507, ptr %545, align 8, !tbaa !111
  %546 = getelementptr inbounds nuw i8, ptr %544, i64 16
  store ptr %508, ptr %546, align 8, !tbaa !111
  br label %547

547:                                              ; preds = %539, %497
  %548 = phi i32 [ %540, %539 ], [ %498, %497 ]
  %549 = phi i32 [ %540, %539 ], [ %499, %497 ]
  %550 = add nuw nsw i64 %500, 1
  %551 = zext i32 %549 to i64
  %552 = icmp samesign ult i64 %550, %551
  br i1 %552, label %497, label %559, !llvm.loop !747

553:                                              ; preds = %19
  %554 = getelementptr inbounds nuw i8, ptr %24, i64 12
  %555 = load i32, ptr %554, align 4, !tbaa !710
  %556 = icmp eq i32 %555, 1
  br i1 %556, label %559, label %557

557:                                              ; preds = %553
  call void @abort() #79
  unreachable

558:                                              ; preds = %19
  call void @abort() #79
  unreachable

559:                                              ; preds = %547, %158, %493, %33, %184, %194, %223, %485, %230, %103, %40, %553, %487, %19, %19, %19
  %560 = load i64, ptr %11, align 8, !tbaa !743
  %561 = icmp eq i64 %560, 0
  br i1 %561, label %562, label %19, !llvm.loop !748

562:                                              ; preds = %559
  %563 = load ptr, ptr %8, align 8, !tbaa !740
  %564 = icmp eq ptr %563, %10
  br i1 %564, label %566, label %565

565:                                              ; preds = %562
  call void @free(ptr noundef %563) #75
  br label %566

566:                                              ; preds = %2, %565, %562
  %567 = load ptr, ptr %9, align 8, !tbaa !38
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #75
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #75
  ret ptr %567
}
