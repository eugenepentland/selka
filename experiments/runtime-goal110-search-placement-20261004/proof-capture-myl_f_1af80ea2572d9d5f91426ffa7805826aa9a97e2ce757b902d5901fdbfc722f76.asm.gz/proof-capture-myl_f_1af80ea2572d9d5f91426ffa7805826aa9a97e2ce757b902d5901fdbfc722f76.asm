
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-search-placement/capture/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104e7d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e7d0:	push   %rbp
 104e7d1:	push   %r15
 104e7d3:	push   %r14
 104e7d5:	push   %r13
 104e7d7:	push   %r12
 104e7d9:	push   %rbx
 104e7da:	sub    $0x258,%rsp
 104e7e1:	mov    %r8,0x8(%rsp)
 104e7e6:	mov    %rcx,0x28(%rsp)
 104e7eb:	mov    %rdi,%rbp
 104e7ee:	cmp    %rsp,0x40(%rdi)
 104e7f2:	ja     1051db1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35e1>
 104e7f8:	mov    %rdx,%r15
 104e7fb:	movq   $0x0,0xa8(%rsp)
 104e807:	movq   $0x0,0xa0(%rsp)
 104e813:	mov    0x2c8(%rbp),%eax
 104e819:	mov    %eax,0x44(%rsp)
 104e81d:	movq   $0x10bb640,0x38(%rsp)
 104e826:	movq   $0x10bb640,0x70(%rsp)
 104e82f:	cmp    $0x10bb640,%rsi
 104e836:	jne    104e83f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e838:	xor    %ebx,%ebx
 104e83a:	jmp    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e83f:	mov    $0x1,%bl
 104e841:	test   %rsi,%rsi
 104e844:	je     104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e84a:	mov    0x8(%rsi),%rdx
 104e84e:	cmp    0x6cdf3(%rip),%rdx        # 10bb648 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e855:	jne    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e85b:	test   %rdx,%rdx
 104e85e:	je     104e838 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x68>
 104e860:	testb  $0x4,0x10(%rsi)
 104e864:	jne    104e86c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c>
 104e866:	lea    0x18(%rsi),%rdi
 104e86a:	jmp    104e87b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xab>
 104e86c:	mov    0x18(%rsi),%rax
 104e870:	mov    0x14(%rsi),%ecx
 104e873:	lea    (%rax,%rcx,1),%rdi
 104e877:	add    $0x18,%rdi
 104e87b:	testb  $0x4,0x6cdce(%rip)        # 10bb650 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e882:	mov    0x6cdcf(%rip),%rax        # 10bb658 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e889:	mov    0x6cdc5(%rip),%ecx        # 10bb654 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e88f:	lea    0x18(%rax,%rcx,1),%rcx
 104e894:	mov    $0x10bb658,%eax
 104e899:	cmovne %rcx,%rax
 104e89d:	cmp    $0x10,%rdx
 104e8a1:	ja     104e8be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xee>
 104e8a3:	cmp    $0x8,%rdx
 104e8a7:	jb     104e8d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x109>
 104e8a9:	mov    (%rdi),%rcx
 104e8ac:	mov    -0x8(%rdi,%rdx,1),%rdi
 104e8b1:	xor    (%rax),%rcx
 104e8b4:	xor    -0x8(%rax,%rdx,1),%rdi
 104e8b9:	or     %rcx,%rdi
 104e8bc:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e8be:	mov    %rsi,%r14
 104e8c1:	mov    %rax,%rsi
 104e8c4:	cmp    $0x100,%rdx
 104e8cb:	ja     104e8ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11f>
 104e8cd:	call   10ad2e0 <bcmp@plt>
 104e8d2:	test   %eax,%eax
 104e8d4:	setne  %bl
 104e8d7:	jmp    104e8f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x129>
 104e8d9:	cmp    $0x4,%rdx
 104e8dd:	jb     104e8fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e>
 104e8df:	mov    (%rdi),%ecx
 104e8e1:	mov    -0x4(%rdi,%rdx,1),%edi
 104e8e5:	xor    (%rax),%ecx
 104e8e7:	xor    -0x4(%rax,%rdx,1),%edi
 104e8eb:	or     %ecx,%edi
 104e8ed:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e8ef:	call   1093420 <equal_large_octets>
 104e8f4:	test   %eax,%eax
 104e8f6:	sete   %bl
 104e8f9:	mov    %r14,%rsi
 104e8fc:	jmp    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e8fe:	cmp    $0x1,%rdx
 104e902:	jne    104e90b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13b>
 104e904:	movzbl (%rdi),%ecx
 104e907:	cmp    (%rax),%cl
 104e909:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e90b:	movzwl (%rdi),%ecx
 104e90e:	movzwl -0x2(%rdi,%rdx,1),%edi
 104e913:	xor    (%rax),%cx
 104e916:	xor    -0x2(%rax,%rdx,1),%di
 104e91b:	or     %cx,%di
 104e91e:	sete   %bl
 104e921:	xor    $0x1,%bl
 104e924:	lea    0x258(%rbp),%rax
 104e92b:	mov    %rax,0x18(%rsp)
 104e930:	movabs $0x4000000000000002,%r13
 104e93a:	test   %r13,0x6ccef(%rip)        # 10bb630 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e941:	jne    104e964 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x194>
 104e943:	mov    0x6ccd6(%rip),%rax        # 10bb620 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e94a:	dec    %rax
 104e94d:	jne    104e95d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d>
 104e94f:	cmpq   $0x0,0x6ccd1(%rip)        # 10bb628 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e957:	je     104e9e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x214>
 104e95d:	mov    %rax,0x6ccbc(%rip)        # 10bb620 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e964:	movq   $0x0,0xc8(%rsp)
 104e970:	test   %bl,%bl
 104e972:	mov    %rbp,0x10(%rsp)
 104e977:	mov    %r15,0x30(%rsp)
 104e97c:	je     104ea24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x254>
 104e982:	movq   $0x10bb150,0x38(%rsp)
 104e98b:	movq   $0x10bb150,0x70(%rsp)
 104e994:	movq   $0x10bb150,0xc8(%rsp)
 104e9a0:	cmp    $0x10bb150,%rsi
 104e9a7:	jne    104e9b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e0>
 104e9a9:	xor    %ebx,%ebx
 104e9ab:	jmp    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9b0:	mov    $0x1,%bl
 104e9b2:	test   %rsi,%rsi
 104e9b5:	je     104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9bb:	mov    0x8(%rsi),%rdx
 104e9bf:	cmp    0x6c792(%rip),%rdx        # 10bb158 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104e9c6:	jne    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9cc:	test   %rdx,%rdx
 104e9cf:	je     104e9a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d9>
 104e9d1:	testb  $0x4,0x10(%rsi)
 104e9d5:	jne    104ef96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7c6>
 104e9db:	lea    0x18(%rsi),%rdi
 104e9df:	jmp    104efa5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d5>
 104e9e4:	mov    %rsi,%r14
 104e9e7:	mov    $0x10bb640,%esi
 104e9ec:	lea    0x258(%rbp),%r12
 104e9f3:	mov    %r12,%rdi
 104e9f6:	call   109baf0 <myl_rc_edge_release>
 104e9fb:	movq   $0x0,0xc8(%rsp)
 104ea07:	mov    %r12,%rdi
 104ea0a:	call   109ec70 <myl_rc_drain>
 104ea0f:	mov    %r14,%rsi
 104ea12:	test   %bl,%bl
 104ea14:	mov    %rbp,0x10(%rsp)
 104ea19:	mov    %r15,0x30(%rsp)
 104ea1e:	jne    104e982 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b2>
 104ea24:	xor    %eax,%eax
 104ea26:	movabs $0x89705f3112a28fe5,%r15
 104ea30:	vpxor  %xmm11,%xmm11,%xmm11
 104ea35:	vmovd  -0x4d09d(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ea3d:	vmovd  -0x4d055(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ea45:	vmovd  -0x4d0cd(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ea4d:	vmovd  -0x4d135(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ea55:	xor    %r14d,%r14d
 104ea58:	nopl   0x0(%rax,%rax,1)
 104ea60:	mov    0x8(%rsp),%rdx
 104ea65:	add    %r14,%rdx
 104ea68:	jo     1051cb2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34e2>
 104ea6e:	mov    %rax,%r12
 104ea71:	mov    0x30(%rsp),%rax
 104ea76:	mov    (%rax),%rsi
 104ea79:	mov    -0x10(%rsi),%rax
 104ea7d:	movabs $0x4000000000000002,%r13
 104ea87:	test   %r13,%rax
 104ea8a:	jne    104ea9d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd>
 104ea8c:	mov    -0x18(%rsi),%rcx
 104ea90:	inc    %rcx
 104ea93:	je     104ef5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x78a>
 104ea99:	mov    %rcx,-0x18(%rsi)
 104ea9d:	movzbl %dl,%r8d
 104eaa1:	mov    (%rsi),%rdi
 104eaa4:	lea    -0x10(%rdi),%r9
 104eaa8:	movabs $0xffffffffffffff0,%rcx
 104eab2:	cmp    %rcx,%r9
 104eab5:	ja     104eaf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x320>
 104eab7:	mov    0x20(%rsi),%rcx
 104eabb:	movabs $0x80808080808080,%r10
 104eac5:	cmp    %r10,%rdi
 104eac8:	ja     104eb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104eaca:	vmovd  %edx,%xmm0
 104eace:	vpbroadcastb %xmm0,%xmm0
 104ead3:	mov    %r9d,%r8d
 104ead6:	not    %r8d
 104ead9:	test   $0x30,%r8b
 104eadd:	jne    104ec58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x488>
 104eae3:	vpxor  %xmm1,%xmm1,%xmm1
 104eae7:	jmp    104eca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104eaec:	nopl   0x0(%rax)
 104eaf0:	test   %rdi,%rdi
 104eaf3:	jle    104ec51 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x481>
 104eaf9:	mov    0x20(%rsi),%rcx
 104eafd:	cmp    $0x8,%rdi
 104eb01:	jae    104eb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104eb03:	mov    $0x1,%r10d
 104eb09:	xor    %r9d,%r9d
 104eb0c:	xor    %edx,%edx
 104eb0e:	xor    %ebx,%ebx
 104eb10:	jmp    104ebc7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f7>
 104eb15:	data16 cs nopw 0x0(%rax,%rax,1)
 104eb20:	mov    %rdi,%rdx
 104eb23:	and    $0xfffffffffffffff8,%rdx
 104eb27:	vmovq  %r8,%xmm0
 104eb2c:	vpbroadcastq %xmm0,%ymm3
 104eb31:	vpxor  %xmm2,%xmm2,%xmm2
 104eb35:	xor    %r9d,%r9d
 104eb38:	vpxor  %xmm4,%xmm4,%xmm4
 104eb3c:	vpxor  %xmm0,%xmm0,%xmm0
 104eb40:	vpxor  %xmm1,%xmm1,%xmm1
 104eb44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb50:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104eb56:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104eb5d:	vpxor  %ymm5,%ymm3,%ymm5
 104eb61:	vpxor  %ymm6,%ymm3,%ymm6
 104eb65:	vpaddq %ymm2,%ymm5,%ymm2
 104eb69:	vpaddq %ymm4,%ymm6,%ymm4
 104eb6d:	vpaddq %ymm0,%ymm5,%ymm0
 104eb71:	vpaddq %ymm1,%ymm6,%ymm1
 104eb75:	add    $0x8,%r9
 104eb79:	cmp    %r9,%rdx
 104eb7c:	jne    104eb50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x380>
 104eb7e:	vpaddq %ymm2,%ymm4,%ymm2
 104eb82:	vextracti128 $0x1,%ymm2,%xmm3
 104eb88:	vpaddq %xmm3,%xmm2,%xmm2
 104eb8c:	vpshufd $0xee,%xmm2,%xmm3
 104eb91:	vpaddq %xmm3,%xmm2,%xmm2
 104eb95:	vmovq  %xmm2,%r9
 104eb9a:	vpaddq %ymm0,%ymm1,%ymm0
 104eb9e:	vextracti128 $0x1,%ymm0,%xmm1
 104eba4:	vpaddq %xmm1,%xmm0,%xmm0
 104eba8:	vpshufd $0xee,%xmm0,%xmm1
 104ebad:	vpaddq %xmm1,%xmm0,%xmm0
 104ebb1:	vmovq  %xmm0,%rbx
 104ebb6:	cmp    %rdx,%rdi
 104ebb9:	jne    104ebc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f0>
 104ebbb:	mov    %rdi,%rcx
 104ebbe:	jmp    104ec01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x431>
 104ebc0:	mov    %rdx,%r10
 104ebc3:	or     $0x1,%r10
 104ebc7:	add    %rdx,%rcx
 104ebca:	mov    %rdi,%r11
 104ebcd:	sub    %rdx,%r11
 104ebd0:	xor    %edx,%edx
 104ebd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ebe0:	movzbl (%rcx,%rdx,1),%ebp
 104ebe4:	xor    %r8,%rbp
 104ebe7:	add    %rbp,%r9
 104ebea:	add    %rbp,%rbx
 104ebed:	inc    %rdx
 104ebf0:	cmp    %rdx,%r11
 104ebf3:	jne    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x410>
 104ebf5:	lea    (%r10,%rdx,1),%rcx
 104ebf9:	dec    %rcx
 104ebfc:	mov    0x10(%rsp),%rbp
 104ec01:	mov    $0xffffffff,%edx
 104ec06:	cmp    %rdx,%rcx
 104ec09:	setb   %cl
 104ec0c:	test   %r9,%r9
 104ec0f:	setns  %dl
 104ec12:	test   %dl,%cl
 104ec14:	jne    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec1a:	mov    0x20(%rsi),%r9
 104ec1e:	xor    %r10d,%r10d
 104ec21:	xor    %edx,%edx
 104ec23:	xor    %ebx,%ebx
 104ec25:	data16 cs nopw 0x0(%rax,%rax,1)
 104ec30:	movzbl (%r9,%r10,1),%ecx
 104ec35:	xor    %r8,%rcx
 104ec38:	add    %rcx,%rbx
 104ec3b:	jo     1051c86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34b6>
 104ec41:	inc    %r10
 104ec44:	mov    %rbx,%rdx
 104ec47:	cmp    %r10,%rdi
 104ec4a:	jne    104ec30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x460>
 104ec4c:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec51:	xor    %ebx,%ebx
 104ec53:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec58:	mov    %r9d,%r8d
 104ec5b:	shr    $0x4,%r8d
 104ec5f:	inc    %r8d
 104ec62:	and    $0x3,%r8d
 104ec66:	vpxor  %xmm1,%xmm1,%xmm1
 104ec6a:	mov    %r8,%r10
 104ec6d:	mov    %rcx,%r11
 104ec70:	vpxor  (%r11),%xmm0,%xmm2
 104ec75:	vpsadbw %xmm2,%xmm11,%xmm2
 104ec79:	vpaddq %xmm1,%xmm2,%xmm1
 104ec7d:	add    $0x10,%r11
 104ec81:	dec    %r10
 104ec84:	jne    104ec70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4a0>
 104ec86:	shl    $0x4,%r8d
 104ec8a:	add    %r8,%rcx
 104ec8d:	sub    %r8,%rdi
 104ec90:	cmp    $0x30,%r9
 104ec94:	jb     104ece1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x511>
 104ec96:	cs nopw 0x0(%rax,%rax,1)
 104eca0:	vpxor  (%rcx),%xmm0,%xmm2
 104eca4:	vpsadbw %xmm2,%xmm11,%xmm2
 104eca8:	vpaddq %xmm1,%xmm2,%xmm1
 104ecac:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104ecb1:	vpsadbw %xmm2,%xmm11,%xmm2
 104ecb5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104ecba:	vpsadbw %xmm3,%xmm11,%xmm3
 104ecbe:	vpaddq %xmm2,%xmm3,%xmm2
 104ecc2:	vpaddq %xmm1,%xmm2,%xmm1
 104ecc6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104eccb:	vpsadbw %xmm2,%xmm11,%xmm2
 104eccf:	vpaddq %xmm1,%xmm2,%xmm1
 104ecd3:	add    $0x40,%rcx
 104ecd7:	add    $0xffffffffffffffc0,%rdi
 104ecdb:	cmp    $0xf,%rdi
 104ecdf:	ja     104eca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104ece1:	vpshufd $0xee,%xmm1,%xmm0
 104ece6:	vpaddq %xmm0,%xmm1,%xmm0
 104ecea:	vmovq  %xmm0,%rbx
 104ecef:	test   %rdi,%rdi
 104ecf2:	je     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ecf8:	mov    %rdi,%r11
 104ecfb:	and    $0x3,%r11
 104ecff:	je     104ed3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x56d>
 104ed01:	xor    %r8d,%r8d
 104ed04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed10:	movzbl (%rcx,%r8,1),%r9d
 104ed15:	xor    %dl,%r9b
 104ed18:	movzbl %r9b,%r9d
 104ed1c:	add    %r9,%rbx
 104ed1f:	inc    %r8
 104ed22:	cmp    %r8,%r11
 104ed25:	jne    104ed10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x540>
 104ed27:	mov    %rdi,%r8
 104ed2a:	and    $0xfffffffffffffffc,%r8
 104ed2e:	lea    (%rcx,%r11,1),%r9
 104ed32:	cmp    $0x4,%rdi
 104ed36:	jae    104ed4d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x57d>
 104ed38:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ed3d:	mov    %rcx,%r9
 104ed40:	mov    %rdi,%r8
 104ed43:	cmp    $0x4,%rdi
 104ed47:	jb     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ed4d:	lea    -0x4(%r8),%rdi
 104ed51:	cmp    $0x1c,%rdi
 104ed55:	jb     104ee70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6a0>
 104ed5b:	shr    $0x2,%rdi
 104ed5f:	inc    %rdi
 104ed62:	mov    %rdi,%r10
 104ed65:	and    $0xfffffffffffffff8,%r10
 104ed69:	lea    0x0(,%r10,4),%rbp
 104ed71:	lea    (%r9,%r10,4),%r9
 104ed75:	sub    %rbp,%r8
 104ed78:	vmovq  %rbx,%xmm1
 104ed7d:	vmovd  %edx,%xmm0
 104ed81:	vpbroadcastb %xmm0,%xmm0
 104ed86:	add    %r11,%rcx
 104ed89:	add    $0x10,%rcx
 104ed8d:	vpxor  %xmm2,%xmm2,%xmm2
 104ed91:	xor    %r11d,%r11d
 104ed94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eda0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104eda7:	vmovdqu (%rcx,%r11,4),%xmm4
 104edad:	vpshufb %xmm12,%xmm3,%xmm5
 104edb2:	vpshufb %xmm13,%xmm3,%xmm6
 104edb7:	vpshufb %xmm14,%xmm3,%xmm7
 104edbc:	vpshufb %xmm15,%xmm3,%xmm3
 104edc1:	vpshufb %xmm12,%xmm4,%xmm8
 104edc6:	vpshufb %xmm13,%xmm4,%xmm9
 104edcb:	vpshufb %xmm14,%xmm4,%xmm10
 104edd0:	vpshufb %xmm15,%xmm4,%xmm4
 104edd5:	vpxor  %xmm0,%xmm5,%xmm5
 104edd9:	vpxor  %xmm0,%xmm8,%xmm8
 104eddd:	vpmovzxbq %xmm5,%ymm5
 104ede2:	vpaddq %ymm5,%ymm1,%ymm1
 104ede6:	vpmovzxbq %xmm8,%ymm5
 104edeb:	vpaddq %ymm5,%ymm2,%ymm2
 104edef:	vpxor  %xmm0,%xmm6,%xmm5
 104edf3:	vpxor  %xmm0,%xmm9,%xmm6
 104edf7:	vpmovzxbq %xmm5,%ymm5
 104edfc:	vpmovzxbq %xmm6,%ymm6
 104ee01:	vpxor  %xmm0,%xmm7,%xmm7
 104ee05:	vpxor  %xmm0,%xmm10,%xmm8
 104ee09:	vpmovzxbq %xmm7,%ymm7
 104ee0e:	vpaddq %ymm7,%ymm5,%ymm5
 104ee12:	vpaddq %ymm5,%ymm1,%ymm1
 104ee16:	vpmovzxbq %xmm8,%ymm5
 104ee1b:	vpaddq %ymm5,%ymm6,%ymm5
 104ee1f:	vpaddq %ymm5,%ymm2,%ymm2
 104ee23:	vpxor  %xmm0,%xmm3,%xmm3
 104ee27:	vpxor  %xmm0,%xmm4,%xmm4
 104ee2b:	vpmovzxbq %xmm3,%ymm3
 104ee30:	vpaddq %ymm3,%ymm1,%ymm1
 104ee34:	vpmovzxbq %xmm4,%ymm3
 104ee39:	vpaddq %ymm3,%ymm2,%ymm2
 104ee3d:	add    $0x8,%r11
 104ee41:	cmp    %r11,%r10
 104ee44:	jne    104eda0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5d0>
 104ee4a:	vpaddq %ymm1,%ymm2,%ymm0
 104ee4e:	vextracti128 $0x1,%ymm0,%xmm1
 104ee54:	vpaddq %xmm1,%xmm0,%xmm0
 104ee58:	vpshufd $0xee,%xmm0,%xmm1
 104ee5d:	vpaddq %xmm1,%xmm0,%xmm0
 104ee61:	vmovq  %xmm0,%rbx
 104ee66:	cmp    %r10,%rdi
 104ee69:	mov    0x10(%rsp),%rbp
 104ee6e:	je     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ee70:	vmovd  %edx,%xmm0
 104ee74:	vpbroadcastb %xmm0,%xmm0
 104ee79:	xor    %ecx,%ecx
 104ee7b:	nopl   0x0(%rax,%rax,1)
 104ee80:	vmovd  (%r9,%rcx,1),%xmm1
 104ee86:	vpxor  %xmm0,%xmm1,%xmm1
 104ee8a:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ee90:	vpsadbw %xmm1,%xmm11,%xmm1
 104ee94:	vmovq  %xmm1,%rdx
 104ee99:	add    %rdx,%rbx
 104ee9c:	add    $0x4,%rcx
 104eea0:	cmp    %rcx,%r8
 104eea3:	jne    104ee80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b0>
 104eea5:	data16 cs nopw 0x0(%rax,%rax,1)
 104eeb0:	test   %r13,%rax
 104eeb3:	jne    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104eeb5:	mov    -0x18(%rsi),%rax
 104eeb9:	dec    %rax
 104eebc:	jne    104eec5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f5>
 104eebe:	cmpq   $0x0,-0x20(%rsi)
 104eec3:	je     104ef18 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x748>
 104eec5:	mov    %rax,-0x18(%rsi)
 104eec9:	mov    %r12,%rcx
 104eecc:	add    %rbx,%rcx
 104eecf:	jo     1051cc7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f7>
 104eed5:	mov    %rcx,%rax
 104eed8:	imul   %r15
 104eedb:	add    %rcx,%rdx
 104eede:	mov    %rdx,%rax
 104eee1:	shr    $0x3f,%rax
 104eee5:	sar    $0x1d,%rdx
 104eee9:	add    %rax,%rdx
 104eeec:	imul   $0x3b9aca07,%rdx,%rax
 104eef3:	sub    %rax,%rcx
 104eef6:	mov    %rcx,%rax
 104eef9:	sar    $0x3f,%rax
 104eefd:	and    $0x3b9aca07,%eax
 104ef02:	add    %rcx,%rax
 104ef05:	inc    %r14
 104ef08:	cmp    0x28(%rsp),%r14
 104ef0d:	jne    104ea60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ef13:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104ef18:	mov    0x18(%rsp),%r13
 104ef1d:	mov    %r13,%rdi
 104ef20:	vzeroupper
 104ef23:	call   109bc50 <myl_rc_hold_edge_release>
 104ef28:	mov    %r13,%rdi
 104ef2b:	call   109ec70 <myl_rc_drain>
 104ef30:	vmovd  -0x4d618(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef38:	vmovd  -0x4d5c0(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef40:	vmovd  -0x4d558(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef48:	vmovd  -0x4d5b0(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef50:	vpxor  %xmm11,%xmm11,%xmm11
 104ef55:	jmp    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104ef5a:	mov    $0x1007dbf,%esi
 104ef5f:	mov    %rbp,%rdi
 104ef62:	vzeroupper
 104ef65:	call   108bdde <fail>
 104ef6a:	vmovd  -0x4d652(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef72:	vmovd  -0x4d5fa(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef7a:	vmovd  -0x4d592(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef82:	vmovd  -0x4d5ea(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef8a:	vpxor  %xmm11,%xmm11,%xmm11
 104ef8f:	xor    %ebx,%ebx
 104ef91:	jmp    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104ef96:	mov    0x18(%rsi),%rax
 104ef9a:	mov    0x14(%rsi),%ecx
 104ef9d:	lea    (%rax,%rcx,1),%rdi
 104efa1:	add    $0x18,%rdi
 104efa5:	testb  $0x4,0x6c1b4(%rip)        # 10bb160 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104efac:	mov    0x6c1b5(%rip),%rax        # 10bb168 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104efb3:	mov    0x6c1ab(%rip),%ecx        # 10bb164 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104efb9:	lea    0x18(%rax,%rcx,1),%rcx
 104efbe:	mov    $0x10bb168,%eax
 104efc3:	cmovne %rcx,%rax
 104efc7:	cmp    $0x10,%rdx
 104efcb:	ja     104efe8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x818>
 104efcd:	cmp    $0x8,%rdx
 104efd1:	jb     104f003 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x833>
 104efd3:	mov    (%rdi),%rcx
 104efd6:	mov    -0x8(%rdi,%rdx,1),%rdi
 104efdb:	xor    (%rax),%rcx
 104efde:	xor    -0x8(%rax,%rdx,1),%rdi
 104efe3:	or     %rcx,%rdi
 104efe6:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104efe8:	mov    %rsi,%r14
 104efeb:	mov    %rax,%rsi
 104efee:	cmp    $0x100,%rdx
 104eff5:	ja     104f019 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x849>
 104eff7:	call   10ad2e0 <bcmp@plt>
 104effc:	test   %eax,%eax
 104effe:	setne  %bl
 104f001:	jmp    104f023 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x853>
 104f003:	cmp    $0x4,%rdx
 104f007:	jb     104f028 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x858>
 104f009:	mov    (%rdi),%ecx
 104f00b:	mov    -0x4(%rdi,%rdx,1),%edi
 104f00f:	xor    (%rax),%ecx
 104f011:	xor    -0x4(%rax,%rdx,1),%edi
 104f015:	or     %ecx,%edi
 104f017:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104f019:	call   1093420 <equal_large_octets>
 104f01e:	test   %eax,%eax
 104f020:	sete   %bl
 104f023:	mov    %r14,%rsi
 104f026:	jmp    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104f028:	cmp    $0x1,%rdx
 104f02c:	jne    104f035 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x865>
 104f02e:	movzbl (%rdi),%ecx
 104f031:	cmp    (%rax),%cl
 104f033:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104f035:	movzwl (%rdi),%ecx
 104f038:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f03d:	xor    (%rax),%cx
 104f040:	xor    -0x2(%rax,%rdx,1),%di
 104f045:	or     %cx,%di
 104f048:	sete   %bl
 104f04b:	xor    $0x1,%bl
 104f04e:	test   %r13,0x6c0eb(%rip)        # 10bb140 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f055:	je     104f084 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8b4>
 104f057:	test   %bl,%bl
 104f059:	je     104f0a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104f05b:	movq   $0x10bafa0,0x70(%rsp)
 104f064:	movq   $0x10bafa0,0xc8(%rsp)
 104f070:	cmp    $0x10bafa0,%rsi
 104f077:	jne    104f111 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x941>
 104f07d:	xor    %ebx,%ebx
 104f07f:	jmp    104f4b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce6>
 104f084:	mov    0x6c0a5(%rip),%rax        # 10bb130 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f08b:	dec    %rax
 104f08e:	jne    104f09e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ce>
 104f090:	cmpq   $0x0,0x6c0a0(%rip)        # 10bb138 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104f098:	je     104f325 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb55>
 104f09e:	mov    %rax,0x6c08b(%rip)        # 10bb130 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f0a5:	test   %bl,%bl
 104f0a7:	jne    104f05b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104f0a9:	mov    0x8(%r15),%rax
 104f0ad:	mov    0x8(%rsp),%rsi
 104f0b2:	and    $0x3,%esi
 104f0b5:	mov    (%rax),%rdx
 104f0b8:	cmp    %rdx,%rsi
 104f0bb:	jae    1051cda <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350a>
 104f0c1:	mov    0x10(%r15),%rcx
 104f0c5:	mov    (%rcx),%rdx
 104f0c8:	cmp    %rdx,%rsi
 104f0cb:	jae    1051ce4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3514>
 104f0d1:	mov    0x20(%rax),%rax
 104f0d5:	shl    $0x3,%esi
 104f0d8:	mov    (%rax,%rsi,1),%rdi
 104f0dc:	mov    0x20(%rcx),%rax
 104f0e0:	mov    (%rax,%rsi,1),%rsi
 104f0e4:	mov    $0x1,%eax
 104f0e9:	cmp    %rsi,%rdi
 104f0ec:	jne    104f149 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x979>
 104f0ee:	mov    %eax,%eax
 104f0f0:	cmpq   $0x1,0x28(%rsp)
 104f0f6:	jne    104f17c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9ac>
 104f0fc:	add    $0x258,%rsp
 104f103:	pop    %rbx
 104f104:	pop    %r12
 104f106:	pop    %r13
 104f108:	pop    %r14
 104f10a:	pop    %r15
 104f10c:	pop    %rbp
 104f10d:	vzeroupper
 104f110:	ret
 104f111:	mov    $0x1,%bl
 104f113:	test   %rsi,%rsi
 104f116:	je     104f4b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce6>
 104f11c:	mov    0x8(%rsi),%rdx
 104f120:	cmp    0x6be81(%rip),%rdx        # 10bafa8 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104f127:	jne    104f4b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce6>
 104f12d:	test   %rdx,%rdx
 104f130:	je     104f07d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ad>
 104f136:	testb  $0x4,0x10(%rsi)
 104f13a:	jne    104f34f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb7f>
 104f140:	lea    0x18(%rsi),%rdi
 104f144:	jmp    104f35e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb8e>
 104f149:	xor    %eax,%eax
 104f14b:	test   %rdi,%rdi
 104f14e:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f150:	test   %rsi,%rsi
 104f153:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f155:	mov    0x8(%rdi),%rdx
 104f159:	cmp    0x8(%rsi),%rdx
 104f15d:	jne    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f15f:	mov    $0x1,%eax
 104f164:	test   %rdx,%rdx
 104f167:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f169:	testb  $0x4,0x10(%rdi)
 104f16d:	jne    104f3ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbfa>
 104f173:	add    $0x18,%rdi
 104f177:	jmp    104f3d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc09>
 104f17c:	mov    $0x1,%ebx
 104f181:	jmp    104f1c4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f4>
 104f183:	call   1093420 <equal_large_octets>
 104f188:	nopl   0x0(%rax,%rax,1)
 104f190:	add    %eax,%r14d
 104f193:	imul   $0x12e0be63,%r14,%rax
 104f19a:	shr    $0x20,%rax
 104f19e:	mov    %r14d,%ecx
 104f1a1:	sub    %eax,%ecx
 104f1a3:	shr    $1,%ecx
 104f1a5:	add    %eax,%ecx
 104f1a7:	shr    $0x1d,%ecx
 104f1aa:	imul   $0x3b9aca07,%ecx,%eax
 104f1b0:	sub    %eax,%r14d
 104f1b3:	mov    %r14,%rax
 104f1b6:	inc    %rbx
 104f1b9:	cmp    %rbx,0x28(%rsp)
 104f1be:	je     104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f1c4:	mov    0x8(%rsp),%rsi
 104f1c9:	add    %rbx,%rsi
 104f1cc:	jo     1051cee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x351e>
 104f1d2:	mov    %rax,%r14
 104f1d5:	mov    0x30(%rsp),%rcx
 104f1da:	mov    0x8(%rcx),%rax
 104f1de:	and    $0x3,%esi
 104f1e1:	mov    (%rax),%rdx
 104f1e4:	cmp    %rdx,%rsi
 104f1e7:	jae    1051cda <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350a>
 104f1ed:	mov    0x10(%rcx),%rcx
 104f1f1:	mov    (%rcx),%rdx
 104f1f4:	cmp    %rdx,%rsi
 104f1f7:	jae    1051ce4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3514>
 104f1fd:	mov    0x20(%rax),%rax
 104f201:	shl    $0x3,%esi
 104f204:	mov    (%rax,%rsi,1),%rdi
 104f208:	mov    0x20(%rcx),%rax
 104f20c:	mov    (%rax,%rsi,1),%rsi
 104f210:	mov    $0x1,%eax
 104f215:	cmp    %rsi,%rdi
 104f218:	je     104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f21e:	xor    %eax,%eax
 104f220:	test   %rdi,%rdi
 104f223:	je     104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f229:	test   %rsi,%rsi
 104f22c:	je     104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f232:	mov    0x8(%rdi),%rdx
 104f236:	cmp    0x8(%rsi),%rdx
 104f23a:	jne    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f240:	mov    $0x1,%eax
 104f245:	test   %rdx,%rdx
 104f248:	je     104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f24e:	testb  $0x4,0x10(%rdi)
 104f252:	jne    104f293 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xac3>
 104f254:	add    $0x18,%rdi
 104f258:	testb  $0x4,0x10(%rsi)
 104f25c:	je     104f2a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xad8>
 104f25e:	mov    0x18(%rsi),%rax
 104f262:	mov    0x14(%rsi),%ecx
 104f265:	lea    (%rax,%rcx,1),%rsi
 104f269:	add    $0x18,%rsi
 104f26d:	cmp    $0x10,%rdx
 104f271:	jbe    104f2b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xae2>
 104f273:	cmp    $0x100,%rdx
 104f27a:	ja     104f183 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9b3>
 104f280:	call   10ad2e0 <bcmp@plt>
 104f285:	mov    %eax,%ecx
 104f287:	xor    %eax,%eax
 104f289:	test   %ecx,%ecx
 104f28b:	sete   %al
 104f28e:	jmp    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f293:	mov    0x18(%rdi),%rax
 104f297:	mov    0x14(%rdi),%ecx
 104f29a:	lea    (%rax,%rcx,1),%rdi
 104f29e:	add    $0x18,%rdi
 104f2a2:	testb  $0x4,0x10(%rsi)
 104f2a6:	jne    104f25e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa8e>
 104f2a8:	add    $0x18,%rsi
 104f2ac:	cmp    $0x10,%rdx
 104f2b0:	ja     104f273 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaa3>
 104f2b2:	cmp    $0x8,%rdx
 104f2b6:	jb     104f2d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb05>
 104f2b8:	mov    (%rdi),%rcx
 104f2bb:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f2c0:	xor    (%rsi),%rcx
 104f2c3:	xor    -0x8(%rsi,%rdx,1),%rdi
 104f2c8:	xor    %eax,%eax
 104f2ca:	or     %rcx,%rdi
 104f2cd:	sete   %al
 104f2d0:	jmp    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f2d5:	cmp    $0x4,%rdx
 104f2d9:	jb     104f2f3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb23>
 104f2db:	mov    (%rdi),%ecx
 104f2dd:	mov    -0x4(%rdi,%rdx,1),%edi
 104f2e1:	xor    (%rsi),%ecx
 104f2e3:	xor    -0x4(%rsi,%rdx,1),%edi
 104f2e7:	xor    %eax,%eax
 104f2e9:	or     %ecx,%edi
 104f2eb:	sete   %al
 104f2ee:	jmp    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f2f3:	cmp    $0x1,%rdx
 104f2f7:	jne    104f308 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb38>
 104f2f9:	movzbl (%rdi),%ecx
 104f2fc:	xor    %eax,%eax
 104f2fe:	cmp    (%rsi),%cl
 104f300:	sete   %al
 104f303:	jmp    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f308:	movzwl (%rdi),%ecx
 104f30b:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f310:	xor    (%rsi),%cx
 104f313:	xor    -0x2(%rsi,%rdx,1),%di
 104f318:	xor    %eax,%eax
 104f31a:	or     %cx,%di
 104f31d:	sete   %al
 104f320:	jmp    104f190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f325:	lea    0xc8(%rsp),%rax
 104f32d:	lea    0x258(%rbp),%rdi
 104f334:	mov    %rsi,%r14
 104f337:	mov    %rax,%rsi
 104f33a:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f33f:	mov    %r14,%rsi
 104f342:	test   %bl,%bl
 104f344:	jne    104f05b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104f34a:	jmp    104f0a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104f34f:	mov    0x18(%rsi),%rax
 104f353:	mov    0x14(%rsi),%ecx
 104f356:	lea    (%rax,%rcx,1),%rdi
 104f35a:	add    $0x18,%rdi
 104f35e:	testb  $0x4,0x6bc4b(%rip)        # 10bafb0 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104f365:	mov    0x6bc4c(%rip),%rax        # 10bafb8 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104f36c:	mov    0x6bc42(%rip),%ecx        # 10bafb4 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104f372:	lea    0x18(%rax,%rcx,1),%rcx
 104f377:	mov    $0x10bafb8,%eax
 104f37c:	cmovne %rcx,%rax
 104f380:	cmp    $0x10,%rdx
 104f384:	ja     104f3a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbd8>
 104f386:	cmp    $0x8,%rdx
 104f38a:	jb     104f434 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc64>
 104f390:	mov    (%rdi),%rcx
 104f393:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f398:	xor    (%rax),%rcx
 104f39b:	xor    -0x8(%rax,%rdx,1),%rdi
 104f3a0:	or     %rcx,%rdi
 104f3a3:	jmp    104f4b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce0>
 104f3a8:	mov    %rsi,%r14
 104f3ab:	mov    %rax,%rsi
 104f3ae:	cmp    $0x100,%rdx
 104f3b5:	ja     104f44a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc7a>
 104f3bb:	call   10ad2e0 <bcmp@plt>
 104f3c0:	test   %eax,%eax
 104f3c2:	setne  %bl
 104f3c5:	jmp    104f454 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc84>
 104f3ca:	mov    0x18(%rdi),%rax
 104f3ce:	mov    0x14(%rdi),%ecx
 104f3d1:	lea    (%rax,%rcx,1),%rdi
 104f3d5:	add    $0x18,%rdi
 104f3d9:	testb  $0x4,0x10(%rsi)
 104f3dd:	jne    104f3e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc15>
 104f3df:	add    $0x18,%rsi
 104f3e3:	jmp    104f3f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc24>
 104f3e5:	mov    0x18(%rsi),%rax
 104f3e9:	mov    0x14(%rsi),%ecx
 104f3ec:	lea    (%rax,%rcx,1),%rsi
 104f3f0:	add    $0x18,%rsi
 104f3f4:	cmp    $0x11,%rdx
 104f3f8:	jae    104f418 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc48>
 104f3fa:	cmp    $0x7,%rdx
 104f3fe:	jbe    104f459 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc89>
 104f400:	mov    (%rdi),%rax
 104f403:	mov    -0x8(%rdi,%rdx,1),%rcx
 104f408:	xor    (%rsi),%rax
 104f40b:	xor    -0x8(%rsi,%rdx,1),%rcx
 104f410:	or     %rax,%rcx
 104f413:	jmp    104f80c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x103c>
 104f418:	cmp    $0x101,%rdx
 104f41f:	jae    104f472 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xca2>
 104f421:	call   10ad2e0 <bcmp@plt>
 104f426:	mov    %eax,%ecx
 104f428:	xor    %eax,%eax
 104f42a:	test   %ecx,%ecx
 104f42c:	sete   %al
 104f42f:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f434:	cmp    $0x4,%rdx
 104f438:	jb     104f47c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcac>
 104f43a:	mov    (%rdi),%ecx
 104f43c:	mov    -0x4(%rdi,%rdx,1),%edi
 104f440:	xor    (%rax),%ecx
 104f442:	xor    -0x4(%rax,%rdx,1),%edi
 104f446:	or     %ecx,%edi
 104f448:	jmp    104f4b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce0>
 104f44a:	call   1093420 <equal_large_octets>
 104f44f:	test   %eax,%eax
 104f451:	sete   %bl
 104f454:	mov    %r14,%rsi
 104f457:	jmp    104f4b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce6>
 104f459:	cmp    $0x3,%rdx
 104f45d:	jbe    104f489 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcb9>
 104f45f:	mov    (%rdi),%eax
 104f461:	mov    -0x4(%rdi,%rdx,1),%ecx
 104f465:	xor    (%rsi),%eax
 104f467:	xor    -0x4(%rsi,%rdx,1),%ecx
 104f46b:	or     %eax,%ecx
 104f46d:	jmp    104f80c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x103c>
 104f472:	call   1093420 <equal_large_octets>
 104f477:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f47c:	cmp    $0x1,%rdx
 104f480:	jne    104f49d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xccd>
 104f482:	movzbl (%rdi),%ecx
 104f485:	cmp    (%rax),%cl
 104f487:	jmp    104f4b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xce0>
 104f489:	cmp    $0x1,%rdx
 104f48d:	jne    104f7f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1029>
 104f493:	movzbl (%rdi),%eax
 104f496:	cmp    (%rsi),%al
 104f498:	jmp    104f80c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x103c>
 104f49d:	movzwl (%rdi),%ecx
 104f4a0:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f4a5:	xor    (%rax),%cx
 104f4a8:	xor    -0x2(%rax,%rdx,1),%di
 104f4ad:	or     %cx,%di
 104f4b0:	sete   %bl
 104f4b3:	xor    $0x1,%bl
 104f4b6:	test   %r13,0x6bad3(%rip)        # 10baf90 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f4bd:	je     104f4f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd25>
 104f4bf:	test   %bl,%bl
 104f4c1:	je     104f51a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4a>
 104f4c3:	movq   $0x10bac28,0x38(%rsp)
 104f4cc:	movq   $0x10bac28,0x70(%rsp)
 104f4d5:	movq   $0x10bac28,0xc8(%rsp)
 104f4e1:	cmp    $0x10bac28,%rsi
 104f4e8:	jne    104f6ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf2f>
 104f4ee:	xor    %ebx,%ebx
 104f4f0:	jmp    104f830 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1060>
 104f4f5:	mov    0x6ba84(%rip),%rax        # 10baf80 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f4fc:	dec    %rax
 104f4ff:	jne    104f50f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd3f>
 104f501:	cmpq   $0x0,0x6ba7f(%rip)        # 10baf88 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f509:	je     104f730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf60>
 104f50f:	mov    %rax,0x6ba6a(%rip)        # 10baf80 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f516:	test   %bl,%bl
 104f518:	jne    104f4c3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf3>
 104f51a:	xor    %eax,%eax
 104f51c:	movabs $0x89705f3112a28fe5,%rdi
 104f526:	xor    %ebx,%ebx
 104f528:	nopl   0x0(%rax,%rax,1)
 104f530:	mov    0x8(%rsp),%rsi
 104f535:	add    %rbx,%rsi
 104f538:	jo     1051d00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3530>
 104f53e:	mov    %rax,%r13
 104f541:	mov    0x30(%rsp),%rcx
 104f546:	mov    0x8(%rcx),%rax
 104f54a:	cmpq   $0x0,(%rax)
 104f54e:	je     1051d12 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3542>
 104f554:	mov    0x20(%rax),%rax
 104f558:	mov    (%rax),%r14
 104f55b:	test   %r14,%r14
 104f55e:	je     104f581 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb1>
 104f560:	movabs $0x4000000000000002,%rax
 104f56a:	test   %rax,-0x10(%r14)
 104f56e:	jne    104f581 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb1>
 104f570:	mov    -0x18(%r14),%rax
 104f574:	inc    %rax
 104f577:	je     1050ff9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2829>
 104f57d:	mov    %rax,-0x18(%r14)
 104f581:	mov    %r14,0x70(%rsp)
 104f586:	mov    0x10(%rcx),%rax
 104f58a:	and    $0x3,%esi
 104f58d:	mov    (%rax),%rdx
 104f590:	cmp    %rdx,%rsi
 104f593:	jae    1051d1e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x354e>
 104f599:	mov    0x20(%rax),%rax
 104f59d:	mov    (%rax,%rsi,8),%rax
 104f5a1:	mov    (%rax),%rcx
 104f5a4:	test   %rcx,%rcx
 104f5a7:	je     104f5e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104f5a9:	mov    $0xffffffffffffffff,%r15
 104f5b0:	cmp    (%r14),%rcx
 104f5b3:	ja     104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f5b9:	mov    0x10(%r14),%ebp
 104f5bd:	test   $0x4,%bpl
 104f5c1:	jne    104f5e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe15>
 104f5c3:	lea    0x18(%r14),%rdi
 104f5c7:	testb  $0x4,0x10(%rax)
 104f5cb:	je     104f5fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe2b>
 104f5cd:	mov    0x18(%rax),%rcx
 104f5d1:	mov    0x14(%rax),%edx
 104f5d4:	add    %rcx,%rdx
 104f5d7:	add    $0x18,%rdx
 104f5db:	jmp    104f5ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe2f>
 104f5dd:	nopl   (%rax)
 104f5e0:	xor    %r15d,%r15d
 104f5e3:	jmp    104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f5e5:	mov    0x18(%r14),%rcx
 104f5e9:	mov    0x14(%r14),%edx
 104f5ed:	lea    (%rcx,%rdx,1),%rdi
 104f5f1:	add    $0x18,%rdi
 104f5f5:	testb  $0x4,0x10(%rax)
 104f5f9:	jne    104f5cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdfd>
 104f5fb:	lea    0x18(%rax),%rdx
 104f5ff:	mov    0x8(%r14),%rsi
 104f603:	mov    0x8(%rax),%rcx
 104f607:	call   1093480 <myl_native_octets_find>
 104f60c:	cmp    $0xffffffffffffffff,%rax
 104f610:	movabs $0x89705f3112a28fe5,%rdi
 104f61a:	je     104f640 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f61c:	test   $0x1,%bpl
 104f620:	jne    104f637 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe67>
 104f622:	mov    %r14,%rdi
 104f625:	mov    %rax,%rsi
 104f628:	call   1090ec0 <index_walk>
 104f62d:	movabs $0x89705f3112a28fe5,%rdi
 104f637:	mov    %rax,%r15
 104f63a:	nopw   0x0(%rax,%rax,1)
 104f640:	mov    %r15,%r12
 104f643:	inc    %r12
 104f646:	jo     1051d26 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3556>
 104f64c:	test   %r14,%r14
 104f64f:	mov    0x10(%rsp),%rbp
 104f654:	je     104f67a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeaa>
 104f656:	movabs $0x4000000000000002,%rax
 104f660:	test   %rax,-0x10(%r14)
 104f664:	jne    104f67a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeaa>
 104f666:	mov    -0x18(%r14),%rax
 104f66a:	dec    %rax
 104f66d:	jne    104f676 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xea6>
 104f66f:	cmpq   $0x0,-0x20(%r14)
 104f674:	je     104f6c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xef5>
 104f676:	mov    %rax,-0x18(%r14)
 104f67a:	mov    %r13,%rcx
 104f67d:	add    %r12,%rcx
 104f680:	jo     104f6ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf1f>
 104f682:	mov    %rcx,%rax
 104f685:	imul   %rdi
 104f688:	add    %rcx,%rdx
 104f68b:	mov    %rdx,%rax
 104f68e:	shr    $0x3f,%rax
 104f692:	sar    $0x1d,%rdx
 104f696:	add    %rax,%rdx
 104f699:	imul   $0x3b9aca07,%rdx,%rax
 104f6a0:	sub    %rax,%rcx
 104f6a3:	mov    %rcx,%rax
 104f6a6:	sar    $0x3f,%rax
 104f6aa:	and    $0x3b9aca07,%eax
 104f6af:	add    %rcx,%rax
 104f6b2:	inc    %rbx
 104f6b5:	cmp    %rbx,0x28(%rsp)
 104f6ba:	jne    104f530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd60>
 104f6c0:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f6c5:	mov    0x18(%rsp),%r15
 104f6ca:	mov    %r15,%rdi
 104f6cd:	mov    %r14,%rsi
 104f6d0:	call   109bc50 <myl_rc_hold_edge_release>
 104f6d5:	mov    %r15,%rdi
 104f6d8:	call   109ec70 <myl_rc_drain>
 104f6dd:	movabs $0x89705f3112a28fe5,%rdi
 104f6e7:	mov    %r13,%rcx
 104f6ea:	add    %r12,%rcx
 104f6ed:	jno    104f682 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeb2>
 104f6ef:	mov    %rbp,%rdi
 104f6f2:	xor    %esi,%esi
 104f6f4:	mov    %r13,%rdx
 104f6f7:	mov    %r12,%rcx
 104f6fa:	call   108c7f0 <myl_qbe_fail_overflow_op>
 104f6ff:	mov    $0x1,%bl
 104f701:	test   %rsi,%rsi
 104f704:	je     104f830 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1060>
 104f70a:	mov    0x8(%rsi),%rdx
 104f70e:	cmp    0x6b51b(%rip),%rdx        # 10bac30 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f715:	jne    104f830 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1060>
 104f71b:	test   %rdx,%rdx
 104f71e:	je     104f4ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1e>
 104f724:	testb  $0x4,0x10(%rsi)
 104f728:	jne    104f75a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf8a>
 104f72a:	lea    0x18(%rsi),%rdi
 104f72e:	jmp    104f769 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf99>
 104f730:	lea    0xc8(%rsp),%rax
 104f738:	lea    0x258(%rbp),%rdi
 104f73f:	mov    %rsi,%r14
 104f742:	mov    %rax,%rsi
 104f745:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f74a:	mov    %r14,%rsi
 104f74d:	test   %bl,%bl
 104f74f:	jne    104f4c3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf3>
 104f755:	jmp    104f51a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4a>
 104f75a:	mov    0x18(%rsi),%rax
 104f75e:	mov    0x14(%rsi),%ecx
 104f761:	lea    (%rax,%rcx,1),%rdi
 104f765:	add    $0x18,%rdi
 104f769:	testb  $0x4,0x6b4c8(%rip)        # 10bac38 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f770:	mov    0x6b4c9(%rip),%rax        # 10bac40 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f777:	mov    0x6b4bf(%rip),%ecx        # 10bac3c <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f77d:	lea    0x18(%rax,%rcx,1),%rcx
 104f782:	mov    $0x10bac40,%eax
 104f787:	cmovne %rcx,%rax
 104f78b:	cmp    $0x10,%rdx
 104f78f:	ja     104f7ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfdc>
 104f791:	cmp    $0x8,%rdx
 104f795:	jb     104f7c7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xff7>
 104f797:	mov    (%rdi),%rcx
 104f79a:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f79f:	xor    (%rax),%rcx
 104f7a2:	xor    -0x8(%rax,%rdx,1),%rdi
 104f7a7:	or     %rcx,%rdi
 104f7aa:	jmp    104f82a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105a>
 104f7ac:	mov    %rsi,%r14
 104f7af:	mov    %rax,%rsi
 104f7b2:	cmp    $0x100,%rdx
 104f7b9:	ja     104f7dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x100d>
 104f7bb:	call   10ad2e0 <bcmp@plt>
 104f7c0:	test   %eax,%eax
 104f7c2:	setne  %bl
 104f7c5:	jmp    104f7e7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1017>
 104f7c7:	cmp    $0x4,%rdx
 104f7cb:	jb     104f7ec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x101c>
 104f7cd:	mov    (%rdi),%ecx
 104f7cf:	mov    -0x4(%rdi,%rdx,1),%edi
 104f7d3:	xor    (%rax),%ecx
 104f7d5:	xor    -0x4(%rax,%rdx,1),%edi
 104f7d9:	or     %ecx,%edi
 104f7db:	jmp    104f82a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105a>
 104f7dd:	call   1093420 <equal_large_octets>
 104f7e2:	test   %eax,%eax
 104f7e4:	sete   %bl
 104f7e7:	mov    %r14,%rsi
 104f7ea:	jmp    104f830 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1060>
 104f7ec:	cmp    $0x1,%rdx
 104f7f0:	jne    104f817 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1047>
 104f7f2:	movzbl (%rdi),%ecx
 104f7f5:	cmp    (%rax),%cl
 104f7f7:	jmp    104f82a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105a>
 104f7f9:	movzwl (%rdi),%eax
 104f7fc:	movzwl -0x2(%rdi,%rdx,1),%ecx
 104f801:	xor    (%rsi),%ax
 104f804:	xor    -0x2(%rsi,%rdx,1),%cx
 104f809:	or     %ax,%cx
 104f80c:	sete   %al
 104f80f:	movzbl %al,%eax
 104f812:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f817:	movzwl (%rdi),%ecx
 104f81a:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f81f:	xor    (%rax),%cx
 104f822:	xor    -0x2(%rax,%rdx,1),%di
 104f827:	or     %cx,%di
 104f82a:	sete   %bl
 104f82d:	xor    $0x1,%bl
 104f830:	test   %r13,0x6b3e1(%rip)        # 10bac18 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f837:	je     104f866 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1096>
 104f839:	test   %bl,%bl
 104f83b:	je     104f88b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10bb>
 104f83d:	movq   $0x10baaf0,0x70(%rsp)
 104f846:	movq   $0x10baaf0,0xc8(%rsp)
 104f852:	cmp    $0x10baaf0,%rsi
 104f859:	jne    1050979 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a9>
 104f85f:	xor    %ebx,%ebx
 104f861:	jmp    1050af7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2327>
 104f866:	mov    0x6b39b(%rip),%rax        # 10bac08 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f86d:	dec    %rax
 104f870:	jne    104f880 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b0>
 104f872:	cmpq   $0x0,0x6b396(%rip)        # 10bac10 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f87a:	je     1050a15 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2245>
 104f880:	mov    %rax,0x6b381(%rip)        # 10bac08 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f887:	test   %bl,%bl
 104f889:	jne    104f83d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x106d>
 104f88b:	movabs $0x5000000000000000,%rcx
 104f895:	movabs $0x101010101010101,%r15
 104f89f:	lea    0x38(%rsp),%rdx
 104f8a4:	lea    0x70(%rsp),%rsi
 104f8a9:	mov    %rsi,%rax
 104f8ac:	sub    %rdx,%rax
 104f8af:	sub    %rsi,%rdx
 104f8b2:	cmovb  %rax,%rdx
 104f8b6:	mov    %rdx,0x128(%rsp)
 104f8be:	lea    0x68(%rsp),%rdx
 104f8c3:	lea    0x60(%rsp),%rsi
 104f8c8:	mov    %rsi,%rax
 104f8cb:	sub    %rdx,%rax
 104f8ce:	sub    %rsi,%rdx
 104f8d1:	cmovb  %rax,%rdx
 104f8d5:	mov    %rdx,0x180(%rsp)
 104f8dd:	xor    %r12d,%r12d
 104f8e0:	lea    0x1(%rcx),%rax
 104f8e4:	mov    %rax,0x110(%rsp)
 104f8ec:	vpbroadcastd -0x48771(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f8f5:	vpbroadcastd -0x4877a(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f8fe:	vpbroadcastq -0x487ef(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f907:	vmovdqu %ymm0,0x1f0(%rsp)
 104f910:	xor    %eax,%eax
 104f912:	vmovdqa %xmm9,0x50(%rsp)
 104f918:	vmovdqu %ymm10,0xf0(%rsp)
 104f921:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f930:	mov    %rax,0x20(%rsp)
 104f935:	mov    0x8(%rsp),%rsi
 104f93a:	add    %r12,%rsi
 104f93d:	jo     1051d45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3575>
 104f943:	mov    0x30(%rsp),%rax
 104f948:	mov    0x8(%rax),%rax
 104f94c:	and    $0x1,%esi
 104f94f:	mov    (%rax),%rdx
 104f952:	cmp    %rdx,%rsi
 104f955:	jae    1051d3a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x356a>
 104f95b:	mov    0x20(%rax),%rax
 104f95f:	mov    (%rax,%rsi,8),%r14
 104f963:	test   %rsi,%rsi
 104f966:	jne    104fa10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1240>
 104f96c:	movq   $0x10bb940,0x70(%rsp)
 104f975:	movq   $0x10bb940,0xc8(%rsp)
 104f981:	movq   $0x10bb940,0x38(%rsp)
 104f98a:	mov    0x6bf9f(%rip),%rax        # 10bb930 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f991:	test   %rax,0x110(%rsp)
 104f999:	je     104faa5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12d5>
 104f99f:	cmpq   $0x0,0x128(%rsp)
 104f9a8:	setne  %cl
 104f9ab:	movabs $0x5000000000000000,%rdx
 104f9b5:	test   %rdx,%rax
 104f9b8:	sete   %dl
 104f9bb:	mov    $0x10bb940,%eax
 104f9c0:	test   %cl,%dl
 104f9c2:	jne    104faa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12d0>
 104f9c8:	mov    $0x1030c78,%esi
 104f9cd:	mov    0x18(%rsp),%rdi
 104f9d2:	lea    0x70(%rsp),%rdx
 104f9d7:	lea    0x38(%rsp),%rcx
 104f9dc:	mov    0x44(%rsp),%r8d
 104f9e1:	vzeroupper
 104f9e4:	call   10a8090 <myl_rc_native_take>
 104f9e9:	vmovdqu 0xf0(%rsp),%ymm10
 104f9f2:	vmovdqa 0x50(%rsp),%xmm9
 104f9f8:	test   %eax,%eax
 104f9fa:	jne    104faae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12de>
 104fa00:	jmp    10509b1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e1>
 104fa05:	data16 cs nopw 0x0(%rax,%rax,1)
 104fa10:	movq   $0x10bacb0,0x70(%rsp)
 104fa19:	movq   $0x10bacb0,0xc8(%rsp)
 104fa25:	movq   $0x10bacb0,0x38(%rsp)
 104fa2e:	mov    0x6b26b(%rip),%rax        # 10baca0 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104fa35:	test   %rax,0x110(%rsp)
 104fa3d:	je     104faa5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12d5>
 104fa3f:	cmpq   $0x0,0x128(%rsp)
 104fa48:	setne  %cl
 104fa4b:	movabs $0x5000000000000000,%rdx
 104fa55:	test   %rdx,%rax
 104fa58:	sete   %dl
 104fa5b:	mov    $0x10bacb0,%eax
 104fa60:	test   %cl,%dl
 104fa62:	jne    104faa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12d0>
 104fa64:	mov    $0x1030c78,%esi
 104fa69:	mov    0x18(%rsp),%rdi
 104fa6e:	lea    0x70(%rsp),%rdx
 104fa73:	lea    0x38(%rsp),%rcx
 104fa78:	mov    0x44(%rsp),%r8d
 104fa7d:	vzeroupper
 104fa80:	call   10a8090 <myl_rc_native_take>
 104fa85:	vmovdqu 0xf0(%rsp),%ymm10
 104fa8e:	vmovdqa 0x50(%rsp),%xmm9
 104fa94:	test   %eax,%eax
 104fa96:	jne    104faae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12de>
 104fa98:	jmp    10509e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 104fa9d:	nopl   (%rax)
 104faa0:	mov    %rax,0x70(%rsp)
 104faa5:	movq   $0x0,0x38(%rsp)
 104faae:	mov    0x70(%rsp),%rdx
 104fab3:	movq   $0x0,0x250(%rsp)
 104fabf:	movq   $0x0,0x230(%rsp)
 104facb:	cmp    %rsp,0x40(%rbp)
 104facf:	ja     1051d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x358a>
 104fad5:	cmpq   $0x0,(%rdx)
 104fad9:	je     1051d65 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3595>
 104fadf:	mov    0x2c8(%rbp),%esi
 104fae5:	mov    %r14,0xc0(%rsp)
 104faed:	mov    %rdx,0x138(%rsp)
 104faf5:	testb  $0x4,0x10(%r14)
 104fafa:	jne    104fb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1350>
 104fafc:	lea    0x18(%r14),%rbx
 104fb00:	mov    %r12,0x198(%rsp)
 104fb08:	testb  $0x4,0x10(%rdx)
 104fb0c:	je     104fb3e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x136e>
 104fb0e:	mov    0x18(%rdx),%rax
 104fb12:	mov    0x14(%rdx),%ecx
 104fb15:	lea    (%rax,%rcx,1),%r13
 104fb19:	add    $0x18,%r13
 104fb1d:	jmp    104fb42 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1372>
 104fb1f:	nop
 104fb20:	mov    0x18(%r14),%rax
 104fb24:	mov    0x14(%r14),%ecx
 104fb28:	lea    (%rax,%rcx,1),%rbx
 104fb2c:	add    $0x18,%rbx
 104fb30:	mov    %r12,0x198(%rsp)
 104fb38:	testb  $0x4,0x10(%rdx)
 104fb3c:	jne    104fb0e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x133e>
 104fb3e:	lea    0x18(%rdx),%r13
 104fb42:	mov    0x8(%rdx),%rcx
 104fb46:	mov    0x8(%r14),%r14
 104fb4a:	lea    -0x1(%rcx),%rax
 104fb4e:	cmp    %r14,%rax
 104fb51:	mov    %rcx,0x118(%rsp)
 104fb59:	mov    %rdx,0x190(%rsp)
 104fb61:	mov    %esi,0x124(%rsp)
 104fb68:	jae    104fd60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fb6e:	cmp    $0x1,%rcx
 104fb72:	jne    104fd70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15a0>
 104fb78:	movzbl 0x0(%r13),%eax
 104fb7d:	vmovd  %eax,%xmm0
 104fb81:	vpbroadcastb %xmm0,%xmm0
 104fb86:	lea    0x18(%rbx),%rcx
 104fb8a:	xor    %r12d,%r12d
 104fb8d:	xor    %edx,%edx
 104fb8f:	mov    $0x10000,%r11d
 104fb95:	jmp    104fbb2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13e2>
 104fb97:	nopw   0x0(%rax,%rax,1)
 104fba0:	mov    %r9d,%edi
 104fba3:	add    %rdi,%r12
 104fba6:	add    %rsi,%rdx
 104fba9:	cmp    %r14,%rdx
 104fbac:	jae    104fdc3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15f3>
 104fbb2:	mov    %r14,%rsi
 104fbb5:	sub    %rdx,%rsi
 104fbb8:	cmp    $0x10000,%rsi
 104fbbf:	cmovae %r11,%rsi
 104fbc3:	mov    %r14,%r8
 104fbc6:	sub    %rdx,%r8
 104fbc9:	jne    104fbe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1410>
 104fbcb:	xor    %edi,%edi
 104fbcd:	add    %rdi,%r12
 104fbd0:	add    %rsi,%rdx
 104fbd3:	cmp    %r14,%rdx
 104fbd6:	jb     104fbb2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13e2>
 104fbd8:	jmp    104fdc3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15f3>
 104fbdd:	nopl   (%rax)
 104fbe0:	lea    (%rbx,%rdx,1),%rdi
 104fbe4:	cmp    $0x3,%r8
 104fbe8:	ja     104fc00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1430>
 104fbea:	xor    %r8d,%r8d
 104fbed:	xor    %r9d,%r9d
 104fbf0:	jmp    104fd40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1570>
 104fbf5:	data16 cs nopw 0x0(%rax,%rax,1)
 104fc00:	cmp    $0x20,%r8
 104fc04:	jae    104fc11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1441>
 104fc06:	xor    %r8d,%r8d
 104fc09:	xor    %r9d,%r9d
 104fc0c:	jmp    104fce4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1514>
 104fc11:	mov    %esi,%r8d
 104fc14:	and    $0x1ffe0,%r8d
 104fc1b:	lea    (%rcx,%rdx,1),%r9
 104fc1f:	vpxor  %xmm1,%xmm1,%xmm1
 104fc23:	xor    %r10d,%r10d
 104fc26:	vpxor  %xmm2,%xmm2,%xmm2
 104fc2a:	vpxor  %xmm3,%xmm3,%xmm3
 104fc2e:	vpxor  %xmm4,%xmm4,%xmm4
 104fc32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fc40:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fc47:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fc4e:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fc55:	vmovq  (%r9,%r10,1),%xmm8
 104fc5b:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104fc5f:	vpmovzxbd %xmm5,%ymm5
 104fc64:	vpand  %ymm5,%ymm10,%ymm5
 104fc68:	vpaddd %ymm5,%ymm1,%ymm1
 104fc6c:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104fc70:	vpmovzxbd %xmm5,%ymm5
 104fc75:	vpand  %ymm5,%ymm10,%ymm5
 104fc79:	vpaddd %ymm5,%ymm2,%ymm2
 104fc7d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104fc81:	vpmovzxbd %xmm5,%ymm5
 104fc86:	vpand  %ymm5,%ymm10,%ymm5
 104fc8a:	vpaddd %ymm5,%ymm3,%ymm3
 104fc8e:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104fc92:	vpmovzxbd %xmm5,%ymm5
 104fc97:	vpand  %ymm5,%ymm10,%ymm5
 104fc9b:	vpaddd %ymm5,%ymm4,%ymm4
 104fc9f:	add    $0x20,%r10
 104fca3:	cmp    %r10,%r8
 104fca6:	jne    104fc40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1470>
 104fca8:	vpaddd %ymm1,%ymm2,%ymm1
 104fcac:	vpaddd %ymm1,%ymm3,%ymm1
 104fcb0:	vpaddd %ymm1,%ymm4,%ymm1
 104fcb4:	vextracti128 $0x1,%ymm1,%xmm2
 104fcba:	vpaddd %xmm2,%xmm1,%xmm1
 104fcbe:	vpshufd $0xee,%xmm1,%xmm2
 104fcc3:	vpaddd %xmm2,%xmm1,%xmm1
 104fcc7:	vpshufd $0x55,%xmm1,%xmm2
 104fccc:	vpaddd %xmm2,%xmm1,%xmm1
 104fcd0:	vmovd  %xmm1,%r9d
 104fcd5:	cmp    %r8,%rsi
 104fcd8:	je     104fba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13d0>
 104fcde:	test   $0x1c,%sil
 104fce2:	je     104fd40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1570>
 104fce4:	mov    %r8,%r10
 104fce7:	mov    %esi,%r8d
 104fcea:	and    $0x1fffc,%r8d
 104fcf1:	vmovd  %r9d,%xmm1
 104fcf6:	cs nopw 0x0(%rax,%rax,1)
 104fd00:	vmovd  (%rdi,%r10,1),%xmm2
 104fd06:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104fd0a:	vpmovzxbd %xmm2,%xmm2
 104fd0f:	vpand  %xmm2,%xmm9,%xmm2
 104fd13:	vpaddd %xmm2,%xmm1,%xmm1
 104fd17:	add    $0x4,%r10
 104fd1b:	cmp    %r10,%r8
 104fd1e:	jne    104fd00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1530>
 104fd20:	vpshufd $0xee,%xmm1,%xmm2
 104fd25:	vpaddd %xmm2,%xmm1,%xmm1
 104fd29:	vpshufd $0x55,%xmm1,%xmm2
 104fd2e:	vpaddd %xmm2,%xmm1,%xmm1
 104fd32:	vmovd  %xmm1,%r9d
 104fd37:	jmp    104fd51 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1581>
 104fd39:	nopl   0x0(%rax)
 104fd40:	xor    %r10d,%r10d
 104fd43:	cmp    %al,(%rdi,%r8,1)
 104fd47:	sete   %r10b
 104fd4b:	add    %r10d,%r9d
 104fd4e:	inc    %r8
 104fd51:	cmp    %r8,%rsi
 104fd54:	jne    104fd40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1570>
 104fd56:	jmp    104fba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13d0>
 104fd5b:	nopl   0x0(%rax,%rax,1)
 104fd60:	xor    %r12d,%r12d
 104fd63:	jmp    104fdc3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15f3>
 104fd65:	data16 cs nopw 0x0(%rax,%rax,1)
 104fd70:	mov    %rbx,%rdi
 104fd73:	mov    %r14,%rsi
 104fd76:	mov    %r13,%rdx
 104fd79:	vzeroupper
 104fd7c:	call   1093480 <myl_native_octets_find>
 104fd81:	xor    %r12d,%r12d
 104fd84:	xor    %r15d,%r15d
 104fd87:	cmp    $0xffffffffffffffff,%rax
 104fd8b:	je     104fdb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15e9>
 104fd8d:	nopl   (%rax)
 104fd90:	mov    0x118(%rsp),%rcx
 104fd98:	add    %rcx,%r15
 104fd9b:	add    %rax,%r15
 104fd9e:	inc    %r12
 104fda1:	lea    (%rbx,%r15,1),%rdi
 104fda5:	mov    %r14,%rsi
 104fda8:	sub    %r15,%rsi
 104fdab:	mov    %r13,%rdx
 104fdae:	call   1093480 <myl_native_octets_find>
 104fdb3:	cmp    $0xffffffffffffffff,%rax
 104fdb7:	jne    104fd90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15c0>
 104fdb9:	movabs $0x101010101010101,%r15
 104fdc3:	inc    %r12
 104fdc6:	mov    0x10(%rsp),%r14
 104fdcb:	mov    0x268(%r14),%rax
 104fdd2:	mov    %rax,0x1a8(%rsp)
 104fdda:	lea    0xc0(%rsp),%rax
 104fde2:	mov    %rax,0x1b0(%rsp)
 104fdea:	movq   $0x1031628,0x1b8(%rsp)
 104fdf6:	lea    0x1a8(%rsp),%rax
 104fdfe:	mov    %rax,0x160(%rsp)
 104fe06:	lea    0x138(%rsp),%rax
 104fe0e:	mov    %rax,0x168(%rsp)
 104fe16:	movq   $0x1031628,0x170(%rsp)
 104fe22:	lea    0x160(%rsp),%rax
 104fe2a:	mov    %rax,0x268(%r14)
 104fe31:	mov    $0x1031628,%esi
 104fe36:	mov    0x18(%rsp),%rdi
 104fe3b:	mov    %r12,%rdx
 104fe3e:	vzeroupper
 104fe41:	call   108f560 <myl_native_list_new>
 104fe46:	mov    %rax,%rbx
 104fe49:	mov    %rax,0xb8(%rsp)
 104fe51:	mov    0x268(%r14),%rax
 104fe58:	mov    %rax,0x140(%rsp)
 104fe60:	lea    0xb8(%rsp),%rax
 104fe68:	mov    %rax,0x148(%rsp)
 104fe70:	movq   $0x1031628,0x150(%rsp)
 104fe7c:	lea    0x140(%rsp),%rax
 104fe84:	mov    %rax,0x268(%r14)
 104fe8b:	test   %rbx,%rbx
 104fe8e:	je     10503dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0c>
 104fe94:	mov    0xc0(%rsp),%r13
 104fe9c:	mov    0x10(%r13),%ecx
 104fea0:	lea    0x18(%r13),%rax
 104fea4:	mov    %rax,0x98(%rsp)
 104feac:	mov    %ecx,0xb4(%rsp)
 104feb3:	test   $0x4,%cl
 104feb6:	vmovdqa -0x4e48e(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104febe:	vmovdqu 0x1f0(%rsp),%ymm9
 104fec7:	vmovdqa -0x4e49f(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fecf:	je     104fee8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1718>
 104fed1:	mov    0x18(%r13),%rcx
 104fed5:	mov    0x14(%r13),%edx
 104fed9:	add    %rdx,%rcx
 104fedc:	add    $0x18,%rcx
 104fee0:	mov    %rcx,0x98(%rsp)
 104fee8:	mov    0x138(%rsp),%rcx
 104fef0:	testb  $0x4,0x10(%rcx)
 104fef4:	jne    104ff20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1750>
 104fef6:	add    $0x18,%rcx
 104fefa:	mov    %rcx,0x130(%rsp)
 104ff02:	mov    %r13,%rcx
 104ff05:	testb  $0x4,0xb4(%rsp)
 104ff0d:	jne    104ff46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1776>
 104ff0f:	jmp    104ff49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1779>
 104ff11:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ff20:	mov    %rcx,%rdx
 104ff23:	mov    0x18(%rcx),%rcx
 104ff27:	mov    0x14(%rdx),%edx
 104ff2a:	add    %rdx,%rcx
 104ff2d:	add    $0x18,%rcx
 104ff31:	mov    %rcx,0x130(%rsp)
 104ff39:	mov    %r13,%rcx
 104ff3c:	testb  $0x4,0xb4(%rsp)
 104ff44:	je     104ff49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1779>
 104ff46:	mov    (%rax),%rcx
 104ff49:	mov    0x8(%rcx),%rcx
 104ff4d:	shr    $0x2,%rcx
 104ff51:	cmp    $0xa,%rcx
 104ff55:	mov    $0x9,%eax
 104ff5a:	cmovb  %rax,%rcx
 104ff5e:	mov    %rcx,0x1a0(%rsp)
 104ff66:	mov    0x98(%rsp),%rax
 104ff6e:	add    $0xc,%rax
 104ff72:	mov    %rax,0x188(%rsp)
 104ff7a:	xor    %ebp,%ebp
 104ff7c:	mov    0x118(%rsp),%rcx
 104ff84:	cmp    $0x1,%r12
 104ff88:	je     1050030 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1860>
 104ff8e:	xchg   %ax,%ax
 104ff90:	test   %r12,%r12
 104ff93:	je     10503de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0e>
 104ff99:	mov    0x98(%rsp),%rax
 104ffa1:	lea    (%rax,%rbp,1),%rdi
 104ffa5:	mov    0x8(%r13),%rbx
 104ffa9:	mov    %rbx,%rsi
 104ffac:	sub    %rbp,%rsi
 104ffaf:	mov    0x130(%rsp),%rdx
 104ffb7:	vzeroupper
 104ffba:	call   1093480 <myl_native_octets_find>
 104ffbf:	vmovdqa -0x4e597(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104ffc7:	vmovdqu 0x1f0(%rsp),%ymm9
 104ffd0:	vmovdqa -0x4e5a8(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104ffd8:	lea    (%rax,%rbp,1),%r14
 104ffdc:	cmp    $0xffffffffffffffff,%rax
 104ffe0:	cmove  %rbx,%r14
 104ffe4:	mov    %r14,%rbx
 104ffe7:	sub    %rbp,%rbx
 104ffea:	cmp    0x1a0(%rsp),%rbx
 104fff2:	jb     1050044 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1874>
 104fff4:	mov    0x18(%rsp),%rdi
 104fff9:	mov    %r13,%rsi
 104fffc:	mov    %rbp,%rdx
 104ffff:	mov    %rbx,%rcx
 1050002:	mov    $0xffffffffffffffff,%r8
 1050009:	vzeroupper
 105000c:	call   1091e20 <long_piece>
 1050011:	mov    %rax,%r15
 1050014:	test   %rax,%rax
 1050017:	jne    10502c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 105001d:	jmp    1050350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b80>
 1050022:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050030:	mov    0x8(%r13),%r14
 1050034:	mov    %r14,%rbx
 1050037:	sub    %rbp,%rbx
 105003a:	cmp    0x1a0(%rsp),%rbx
 1050042:	jae    104fff4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1824>
 1050044:	mov    0x98(%rsp),%rax
 105004c:	lea    (%rax,%rbp,1),%r13
 1050050:	testb  $0x1,0xb4(%rsp)
 1050058:	jne    105022a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a5a>
 105005e:	cmp    $0x8,%rbx
 1050062:	jae    1050070 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18a0>
 1050064:	xor    %ecx,%ecx
 1050066:	xor    %eax,%eax
 1050068:	jmp    10500b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18e7>
 105006a:	nopw   0x0(%rax,%rax,1)
 1050070:	xor    %edx,%edx
 1050072:	xor    %ecx,%ecx
 1050074:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050080:	mov    0x0(%r13,%rdx,1),%rax
 1050085:	mov    %rax,%rsi
 1050088:	not    %rsi
 105008b:	add    %rsi,%rsi
 105008e:	and    %rax,%rsi
 1050091:	shr    $0x7,%rsi
 1050095:	and    %r15,%rsi
 1050098:	imul   %r15,%rsi
 105009c:	shr    $0x38,%rsi
 10500a0:	sub    %rsi,%rcx
 10500a3:	add    $0x8,%rcx
 10500a7:	lea    0x8(%rdx),%rax
 10500ab:	add    $0x10,%rdx
 10500af:	cmp    %rbx,%rdx
 10500b2:	mov    %rax,%rdx
 10500b5:	jbe    1050080 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18b0>
 10500b7:	cmp    %rbx,%rax
 10500ba:	jae    1050225 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a55>
 10500c0:	lea    (%rax,%rbp,1),%rdi
 10500c4:	mov    %r14,%rdx
 10500c7:	sub    %rdi,%rdx
 10500ca:	cmp    $0x3,%rdx
 10500ce:	mov    0x98(%rsp),%r8
 10500d6:	jbe    1050200 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a30>
 10500dc:	cmp    $0x10,%rdx
 10500e0:	jae    10500e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1919>
 10500e2:	xor    %esi,%esi
 10500e4:	jmp    10501ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19de>
 10500e9:	mov    %rdx,%rsi
 10500ec:	and    $0xfffffffffffffff0,%rsi
 10500f0:	vmovq  %rcx,%xmm0
 10500f5:	add    0x188(%rsp),%rdi
 10500fd:	vpxor  %xmm1,%xmm1,%xmm1
 1050101:	xor    %ecx,%ecx
 1050103:	vpxor  %xmm2,%xmm2,%xmm2
 1050107:	vpxor  %xmm3,%xmm3,%xmm3
 105010b:	nopl   0x0(%rax,%rax,1)
 1050110:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 1050116:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 105011c:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 1050122:	vmovd  (%rdi,%rcx,1),%xmm7
 1050127:	vpcmpgtb %xmm10,%xmm4,%xmm4
 105012c:	vpmovzxbq %xmm4,%ymm4
 1050131:	vpand  %ymm4,%ymm9,%ymm4
 1050135:	vpaddq %ymm4,%ymm0,%ymm0
 1050139:	vpcmpgtb %xmm10,%xmm5,%xmm4
 105013e:	vpmovzxbq %xmm4,%ymm4
 1050143:	vpand  %ymm4,%ymm9,%ymm4
 1050147:	vpaddq %ymm4,%ymm1,%ymm1
 105014b:	vpcmpgtb %xmm10,%xmm6,%xmm4
 1050150:	vpmovzxbq %xmm4,%ymm4
 1050155:	vpand  %ymm4,%ymm9,%ymm4
 1050159:	vpaddq %ymm4,%ymm2,%ymm2
 105015d:	vpcmpgtb %xmm10,%xmm7,%xmm4
 1050162:	vpmovzxbq %xmm4,%ymm4
 1050167:	vpand  %ymm4,%ymm9,%ymm4
 105016b:	vpaddq %ymm4,%ymm3,%ymm3
 105016f:	add    $0x10,%rcx
 1050173:	cmp    %rcx,%rsi
 1050176:	jne    1050110 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1940>
 1050178:	vpaddq %ymm0,%ymm1,%ymm0
 105017c:	vpaddq %ymm0,%ymm2,%ymm0
 1050180:	vpaddq %ymm0,%ymm3,%ymm0
 1050184:	vextracti128 $0x1,%ymm0,%xmm1
 105018a:	vpaddq %xmm1,%xmm0,%xmm0
 105018e:	vpshufd $0xee,%xmm0,%xmm1
 1050193:	vpaddq %xmm1,%xmm0,%xmm0
 1050197:	vmovq  %xmm0,%rcx
 105019c:	cmp    %rsi,%rdx
 105019f:	je     1050225 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a55>
 10501a5:	test   $0xc,%dl
 10501a8:	je     105033b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b6b>
 10501ae:	mov    %rdx,%rdi
 10501b1:	and    $0xfffffffffffffffc,%rdi
 10501b5:	vmovq  %rcx,%xmm0
 10501ba:	lea    (%rax,%r13,1),%rcx
 10501be:	xchg   %ax,%ax
 10501c0:	vmovd  (%rcx,%rsi,1),%xmm1
 10501c5:	vpcmpgtb %xmm8,%xmm1,%xmm1
 10501ca:	vpmovzxbq %xmm1,%ymm1
 10501cf:	vpand  %ymm1,%ymm9,%ymm1
 10501d3:	vpaddq %ymm1,%ymm0,%ymm0
 10501d7:	add    $0x4,%rsi
 10501db:	cmp    %rsi,%rdi
 10501de:	jne    10501c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19f0>
 10501e0:	vextracti128 $0x1,%ymm0,%xmm1
 10501e6:	vpaddq %xmm1,%xmm0,%xmm0
 10501ea:	vpshufd $0xee,%xmm0,%xmm1
 10501ef:	vpaddq %xmm1,%xmm0,%xmm0
 10501f3:	vmovq  %xmm0,%rcx
 10501f8:	cmp    %rdi,%rdx
 10501fb:	je     1050225 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a55>
 10501fd:	add    %rdi,%rax
 1050200:	add    %rbp,%rax
 1050203:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050210:	xor    %edx,%edx
 1050212:	cmpb   $0xc0,(%r8,%rax,1)
 1050217:	setge  %dl
 105021a:	add    %rdx,%rcx
 105021d:	inc    %rax
 1050220:	cmp    %rax,%r14
 1050223:	jne    1050210 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a40>
 1050225:	cmp    %rbx,%rcx
 1050228:	jne    10502a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ad0>
 105022a:	mov    0x10(%rsp),%rax
 105022f:	cmpq   $0x0,0x1860(%rax)
 1050237:	je     10503dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0c>
 105023d:	lea    0x18(%rbx),%rsi
 1050241:	mov    0x2c8(%rax),%edx
 1050247:	mov    0x18(%rsp),%rdi
 105024c:	xor    %ecx,%ecx
 105024e:	vzeroupper
 1050251:	call   10a7830 <raw_bytes>
 1050256:	test   %rax,%rax
 1050259:	je     1050350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b80>
 105025f:	mov    %rax,%r15
 1050262:	movq   $0x0,(%rax)
 1050269:	mov    %rbx,0x8(%rax)
 105026d:	movq   $0x0,0x10(%rax)
 1050275:	cmp    %rbp,%r14
 1050278:	je     105028c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1abc>
 105027a:	mov    %r15,%rdi
 105027d:	add    $0x18,%rdi
 1050281:	mov    %r13,%rsi
 1050284:	mov    %rbx,%rdx
 1050287:	call   10ad2a0 <memcpy@plt>
 105028c:	mov    %rbx,(%r15)
 105028f:	movl   $0x1,0x10(%r15)
 1050297:	jmp    10502c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 1050299:	nopl   0x0(%rax)
 10502a0:	mov    0x18(%rsp),%rdi
 10502a5:	mov    %r13,%rsi
 10502a8:	mov    %rbx,%rdx
 10502ab:	vzeroupper
 10502ae:	call   1090d80 <build_wide>
 10502b3:	mov    %rax,%r15
 10502b6:	test   %rax,%rax
 10502b9:	je     1050350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b80>
 10502bf:	nop
 10502c0:	mov    0xb8(%rsp),%rax
 10502c8:	mov    (%rax),%rcx
 10502cb:	mov    0x20(%rax),%rdx
 10502cf:	lea    0x1(%rcx),%rsi
 10502d3:	mov    %rsi,(%rax)
 10502d6:	mov    %r15,(%rdx,%rcx,8)
 10502da:	mov    0xb8(%rsp),%rbx
 10502e2:	incq   0x10(%rbx)
 10502e6:	mov    0xc0(%rsp),%r13
 10502ee:	cmp    0x8(%r13),%r14
 10502f2:	je     10503de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0e>
 10502f8:	mov    0x118(%rsp),%rcx
 1050300:	add    %rcx,%r14
 1050303:	dec    %r12
 1050306:	mov    %r14,%rbp
 1050309:	movabs $0x101010101010101,%r15
 1050313:	vmovdqa -0x4e8eb(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105031b:	vmovdqu 0x1f0(%rsp),%ymm9
 1050324:	vmovdqa -0x4e8fc(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105032c:	cmp    $0x1,%r12
 1050330:	jne    104ff90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17c0>
 1050336:	jmp    1050030 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1860>
 105033b:	add    %rsi,%rax
 105033e:	jmp    1050200 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a30>
 1050343:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050350:	mov    0x10(%rsp),%rax
 1050355:	cmpq   $0x0,0x1860(%rax)
 105035d:	movabs $0x4000000000000002,%r13
 1050367:	je     10503dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0c>
 1050369:	mov    0xb8(%rsp),%rbx
 1050371:	mov    0x18(%rbx),%rax
 1050375:	cmpw   $0x1,0x30(%rax)
 105037a:	jne    1051c76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34a6>
 1050380:	mov    (%rbx),%rax
 1050383:	test   %rax,%rax
 1050386:	je     10503cf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bff>
 1050388:	mov    0xc0(%rsp),%r14
 1050390:	mov    0x20(%rbx),%r15
 1050394:	xor    %r12d,%r12d
 1050397:	jmp    10503a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd8>
 1050399:	nopl   0x0(%rax)
 10503a0:	inc    %r12
 10503a3:	cmp    %rax,%r12
 10503a6:	jae    10503cf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bff>
 10503a8:	mov    (%r15,%r12,8),%rsi
 10503ac:	test   %rsi,%rsi
 10503af:	je     10503a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd0>
 10503b1:	cmp    %r14,%rsi
 10503b4:	je     10503a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd0>
 10503b6:	lea    -0x2(%r13),%rcx
 10503ba:	test   %rcx,-0x10(%rsi)
 10503be:	je     10503a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd0>
 10503c0:	mov    0x18(%rsp),%rdi
 10503c5:	call   109fcb0 <myl_rc_construction_abort>
 10503ca:	mov    (%rbx),%rax
 10503cd:	jmp    10503a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd0>
 10503cf:	mov    0x18(%rsp),%rdi
 10503d4:	mov    %rbx,%rsi
 10503d7:	call   109fcb0 <myl_rc_construction_abort>
 10503dc:	xor    %ebx,%ebx
 10503de:	mov    0x10(%rsp),%rbp
 10503e3:	mov    0x268(%rbp),%rax
 10503ea:	lea    0x140(%rsp),%rcx
 10503f2:	cmp    %rcx,%rax
 10503f5:	je     1050430 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c60>
 10503f7:	lea    0x160(%rsp),%rcx
 10503ff:	cmp    %rcx,%rax
 1050402:	je     105044c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c7c>
 1050404:	lea    0x1a8(%rsp),%rcx
 105040c:	cmp    %rcx,%rax
 105040f:	je     1050468 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c98>
 1050411:	test   %rbx,%rbx
 1050414:	movabs $0x4000000000000002,%r13
 105041e:	jne    105048a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cba>
 1050420:	jmp    1051d70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35a0>
 1050425:	data16 cs nopw 0x0(%rax,%rax,1)
 1050430:	mov    0x140(%rsp),%rax
 1050438:	mov    %rax,0x268(%rbp)
 105043f:	lea    0x160(%rsp),%rcx
 1050447:	cmp    %rcx,%rax
 105044a:	jne    1050404 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c34>
 105044c:	mov    0x160(%rsp),%rax
 1050454:	mov    %rax,0x268(%rbp)
 105045b:	lea    0x1a8(%rsp),%rcx
 1050463:	cmp    %rcx,%rax
 1050466:	jne    1050411 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c41>
 1050468:	mov    0x1a8(%rsp),%rax
 1050470:	mov    %rax,0x268(%rbp)
 1050477:	test   %rbx,%rbx
 105047a:	movabs $0x4000000000000002,%r13
 1050484:	je     1051d70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35a0>
 105048a:	mov    %rbx,0x60(%rsp)
 105048f:	mov    %rbx,0x68(%rsp)
 1050494:	mov    -0x10(%rbx),%rax
 1050498:	test   %rax,0x110(%rsp)
 10504a0:	je     10504c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf1>
 10504a2:	movabs $0x5000000000000000,%rcx
 10504ac:	test   %rcx,%rax
 10504af:	jne    10504e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d10>
 10504b1:	cmpq   $0x0,0x180(%rsp)
 10504ba:	je     10504e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d10>
 10504bc:	mov    %rbx,0x60(%rsp)
 10504c1:	movq   $0x0,0x68(%rsp)
 10504ca:	mov    (%rbx),%r15
 10504cd:	test   %r15,%r15
 10504d0:	jns    105051d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d4d>
 10504d2:	jmp    1051d8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35bb>
 10504d7:	nopw   0x0(%rax,%rax,1)
 10504e0:	mov    $0x100ba48,%esi
 10504e5:	mov    0x18(%rsp),%rdi
 10504ea:	lea    0x60(%rsp),%rdx
 10504ef:	lea    0x68(%rsp),%rcx
 10504f4:	mov    0x124(%rsp),%r8d
 10504fc:	vzeroupper
 10504ff:	call   10a8090 <myl_rc_native_take>
 1050504:	test   %eax,%eax
 1050506:	je     10507c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ff1>
 105050c:	mov    0x60(%rsp),%rbx
 1050511:	mov    (%rbx),%r15
 1050514:	test   %r15,%r15
 1050517:	js     1051d8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35bb>
 105051d:	imul   $0x7,%r15,%r12
 1050521:	vmovdqa 0x50(%rsp),%xmm9
 1050527:	vmovdqu 0xf0(%rsp),%ymm10
 1050530:	jo     1051d99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35c9>
 1050536:	test   %rbx,%rbx
 1050539:	je     1050545 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d75>
 105053b:	test   %r13,-0x10(%rbx)
 105053f:	je     1050650 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e80>
 1050545:	mov    %rbx,0x60(%rsp)
 105054a:	test   %r15,%r15
 105054d:	je     105066f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9f>
 1050553:	xor    %ebp,%ebp
 1050555:	data16 cs nopw 0x0(%rax,%rax,1)
 1050560:	mov    0x20(%rbx),%rax
 1050564:	mov    (%rax,%rbp,8),%r13
 1050568:	mov    %r13,0x68(%rsp)
 105056d:	test   %r13,%r13
 1050570:	je     1050593 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc3>
 1050572:	movabs $0x4000000000000002,%rax
 105057c:	test   %rax,-0x10(%r13)
 1050580:	jne    1050593 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc3>
 1050582:	mov    -0x18(%r13),%rax
 1050586:	inc    %rax
 1050589:	je     10508fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x212b>
 105058f:	mov    %rax,-0x18(%r13)
 1050593:	mov    %r13,0x60(%rsp)
 1050598:	movq   $0x0,0x68(%rsp)
 10505a1:	mov    0x10(%rsp),%rdi
 10505a6:	mov    %r13,%rsi
 10505a9:	vzeroupper
 10505ac:	call   1074e10 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10505b1:	mov    %r12,%r14
 10505b4:	add    %rax,%r14
 10505b7:	jo     1051c93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34c3>
 10505bd:	test   %r13,%r13
 10505c0:	vmovdqa 0x50(%rsp),%xmm9
 10505c6:	vmovdqu 0xf0(%rsp),%ymm10
 10505cf:	je     10505f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e25>
 10505d1:	movabs $0x4000000000000002,%rax
 10505db:	test   %rax,-0x10(%r13)
 10505df:	jne    10505f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e25>
 10505e1:	mov    -0x18(%r13),%rax
 10505e5:	dec    %rax
 10505e8:	jne    10505f1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e21>
 10505ea:	cmpq   $0x0,-0x20(%r13)
 10505ef:	je     105060f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e3f>
 10505f1:	mov    %rax,-0x18(%r13)
 10505f5:	cmp    %r15,(%rbx)
 10505f8:	jne    1051ca5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34d5>
 10505fe:	inc    %rbp
 1050601:	mov    %r14,%r12
 1050604:	cmp    %rbp,%r15
 1050607:	jne    1050560 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d90>
 105060d:	jmp    1050672 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ea2>
 105060f:	mov    0x18(%rsp),%r12
 1050614:	mov    %r12,%rdi
 1050617:	mov    %r13,%rsi
 105061a:	vzeroupper
 105061d:	call   109bc50 <myl_rc_hold_edge_release>
 1050622:	mov    %r12,%rdi
 1050625:	call   109ec70 <myl_rc_drain>
 105062a:	vmovdqu 0xf0(%rsp),%ymm10
 1050633:	vmovdqa 0x50(%rsp),%xmm9
 1050639:	cmp    %r15,(%rbx)
 105063c:	je     10505fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e2e>
 105063e:	jmp    1051ca5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34d5>
 1050643:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050650:	mov    -0x18(%rbx),%rax
 1050654:	inc    %rax
 1050657:	je     10508d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2107>
 105065d:	mov    %rax,-0x18(%rbx)
 1050661:	mov    %rbx,0x60(%rsp)
 1050666:	test   %r15,%r15
 1050669:	jne    1050553 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d83>
 105066f:	mov    %r12,%r14
 1050672:	mov    0x230(%rsp),%eax
 1050679:	or     0x250(%rsp),%eax
 1050680:	mov    0x10(%rsp),%rbp
 1050685:	movabs $0x4000000000000002,%r13
 105068f:	movabs $0x101010101010101,%r15
 1050699:	je     10506ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1efe>
 105069b:	mov    0x1860(%rbp),%rax
 10506a2:	test   %rax,%rax
 10506a5:	je     10506b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee0>
 10506a7:	mov    0xf8(%rax),%rsi
 10506ae:	jmp    10506b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee2>
 10506b0:	xor    %esi,%esi
 10506b2:	mov    0x18(%rsp),%rdi
 10506b7:	vzeroupper
 10506ba:	call   10a22a0 <myl_rc_scope_unwind>
 10506bf:	vmovdqa 0x50(%rsp),%xmm9
 10506c5:	vmovdqu 0xf0(%rsp),%ymm10
 10506ce:	test   %rbx,%rbx
 10506d1:	je     105072b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f5b>
 10506d3:	test   %r13,-0x10(%rbx)
 10506d7:	mov    0x20(%rsp),%rdx
 10506dc:	je     10506f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f20>
 10506de:	test   %r13,-0x10(%rbx)
 10506e2:	jne    1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 10506e4:	jmp    1050713 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f43>
 10506e6:	cs nopw 0x0(%rax,%rax,1)
 10506f0:	mov    -0x18(%rbx),%rax
 10506f4:	dec    %rax
 10506f7:	jne    1050704 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f34>
 10506f9:	cmpq   $0x0,-0x20(%rbx)
 10506fe:	je     1050856 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2086>
 1050704:	mov    %rax,-0x18(%rbx)
 1050708:	mov    0x20(%rsp),%rdx
 105070d:	test   %r13,-0x10(%rbx)
 1050711:	jne    1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 1050713:	mov    -0x20(%rbx),%rax
 1050717:	dec    %rax
 105071a:	jne    1050727 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f57>
 105071c:	cmpq   $0x0,-0x18(%rbx)
 1050721:	je     105089e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20ce>
 1050727:	mov    %rax,-0x20(%rbx)
 105072b:	mov    0x20(%rsp),%rdx
 1050730:	mov    0x190(%rsp),%rsi
 1050738:	test   %rsi,%rsi
 105073b:	je     1050760 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f90>
 105073d:	test   %r13,-0x10(%rsi)
 1050741:	jne    1050760 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f90>
 1050743:	mov    -0x20(%rsi),%rax
 1050747:	dec    %rax
 105074a:	jne    1050757 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f87>
 105074c:	cmpq   $0x0,-0x18(%rsi)
 1050751:	je     105082a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x205a>
 1050757:	mov    %rax,-0x20(%rsi)
 105075b:	mov    0x20(%rsp),%rdx
 1050760:	mov    %rdx,%rcx
 1050763:	add    %r14,%rcx
 1050766:	jo     1051d7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35ab>
 105076c:	mov    %rcx,%rax
 105076f:	movabs $0x89705f3112a28fe5,%rdx
 1050779:	imul   %rdx
 105077c:	add    %rcx,%rdx
 105077f:	mov    %rdx,%rax
 1050782:	shr    $0x3f,%rax
 1050786:	sar    $0x1d,%rdx
 105078a:	add    %rax,%rdx
 105078d:	imul   $0x3b9aca07,%rdx,%rax
 1050794:	sub    %rax,%rcx
 1050797:	mov    %rcx,%rax
 105079a:	sar    $0x3f,%rax
 105079e:	and    $0x3b9aca07,%eax
 10507a3:	add    %rcx,%rax
 10507a6:	mov    0x198(%rsp),%r12
 10507ae:	inc    %r12
 10507b1:	cmp    0x28(%rsp),%r12
 10507b6:	jne    104f930 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1160>
 10507bc:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 10507c1:	mov    0x1860(%rbp),%rax
 10507c8:	test   %rax,%rax
 10507cb:	vmovdqa 0x50(%rsp),%xmm9
 10507d1:	vmovdqu 0xf0(%rsp),%ymm10
 10507da:	je     1051c7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ae>
 10507e0:	mov    0x124(%rax),%r14d
 10507e7:	movl   $0x0,0x124(%rax)
 10507f1:	test   %r14,%r14
 10507f4:	mov    0x20(%rsp),%rdx
 10507f9:	movabs $0x101010101010101,%r15
 1050803:	je     1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 1050809:	cmp    $0x1,%r14d
 105080d:	jne    1050940 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2170>
 1050813:	mov    $0x1007df2,%esi
 1050818:	cmpl   $0x0,0x2c4(%rbp)
 105081f:	je     105094a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x217a>
 1050825:	jmp    1050952 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2182>
 105082a:	mov    0x18(%rsp),%rbx
 105082f:	mov    %rbx,%rdi
 1050832:	vzeroupper
 1050835:	call   109baf0 <myl_rc_edge_release>
 105083a:	mov    %rbx,%rdi
 105083d:	call   109ec70 <myl_rc_drain>
 1050842:	vmovdqu 0xf0(%rsp),%ymm10
 105084b:	vmovdqa 0x50(%rsp),%xmm9
 1050851:	jmp    105075b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f8b>
 1050856:	mov    0x18(%rsp),%r15
 105085b:	mov    %r15,%rdi
 105085e:	mov    %rbx,%rsi
 1050861:	vzeroupper
 1050864:	call   109bc50 <myl_rc_hold_edge_release>
 1050869:	mov    %r15,%rdi
 105086c:	movabs $0x101010101010101,%r15
 1050876:	call   109ec70 <myl_rc_drain>
 105087b:	vmovdqu 0xf0(%rsp),%ymm10
 1050884:	vmovdqa 0x50(%rsp),%xmm9
 105088a:	mov    0x20(%rsp),%rdx
 105088f:	test   %r13,-0x10(%rbx)
 1050893:	jne    1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 1050899:	jmp    1050713 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f43>
 105089e:	mov    0x18(%rsp),%r15
 10508a3:	mov    %r15,%rdi
 10508a6:	mov    %rbx,%rsi
 10508a9:	vzeroupper
 10508ac:	call   109baf0 <myl_rc_edge_release>
 10508b1:	mov    %r15,%rdi
 10508b4:	movabs $0x101010101010101,%r15
 10508be:	call   109ec70 <myl_rc_drain>
 10508c3:	vmovdqu 0xf0(%rsp),%ymm10
 10508cc:	vmovdqa 0x50(%rsp),%xmm9
 10508d2:	jmp    105072b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f5b>
 10508d7:	mov    $0x1007dbf,%esi
 10508dc:	mov    %rbp,%rdi
 10508df:	vzeroupper
 10508e2:	call   108bdde <fail>
 10508e7:	vmovdqu 0xf0(%rsp),%ymm10
 10508f0:	vmovdqa 0x50(%rsp),%xmm9
 10508f6:	xor    %r14d,%r14d
 10508f9:	jmp    105092c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x215c>
 10508fb:	mov    $0x1007dbf,%esi
 1050900:	mov    0x10(%rsp),%rbp
 1050905:	mov    %rbp,%rdi
 1050908:	vzeroupper
 105090b:	call   108bdde <fail>
 1050910:	vmovdqu 0xf0(%rsp),%ymm10
 1050919:	vmovdqa 0x50(%rsp),%xmm9
 105091f:	xor    %r14d,%r14d
 1050922:	movabs $0x4000000000000002,%r13
 105092c:	mov    0x20(%rsp),%rdx
 1050931:	movabs $0x101010101010101,%r15
 105093b:	jmp    1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 1050940:	cmp    $0x4,%r14d
 1050944:	jae    1051c76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34a6>
 105094a:	mov    0x10315e0(,%r14,8),%rsi
 1050952:	mov    %rbp,%rdi
 1050955:	vzeroupper
 1050958:	call   108bdde <fail>
 105095d:	xor    %r14d,%r14d
 1050960:	mov    0x20(%rsp),%rdx
 1050965:	vmovdqa 0x50(%rsp),%xmm9
 105096b:	vmovdqu 0xf0(%rsp),%ymm10
 1050974:	jmp    1050730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f60>
 1050979:	mov    $0x1,%bl
 105097b:	test   %rsi,%rsi
 105097e:	je     1050af7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2327>
 1050984:	mov    0x8(%rsi),%rdx
 1050988:	cmp    0x6a169(%rip),%rdx        # 10baaf8 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x18>
 105098f:	jne    1050af7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2327>
 1050995:	test   %rdx,%rdx
 1050998:	je     104f85f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108f>
 105099e:	testb  $0x4,0x10(%rsi)
 10509a2:	jne    1050a3f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x226f>
 10509a8:	lea    0x18(%rsi),%rdi
 10509ac:	jmp    1050a4e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x227e>
 10509b1:	mov    0x1860(%rbp),%rax
 10509b8:	test   %rax,%rax
 10509bb:	je     1051c7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ae>
 10509c1:	mov    0x124(%rax),%esi
 10509c7:	movl   $0x0,0x124(%rax)
 10509d1:	mov    %rbp,%rdi
 10509d4:	vzeroupper
 10509d7:	call   108b580 <myl_qbe_rc_status>
 10509dc:	xor    %eax,%eax
 10509de:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 10509e3:	mov    0x1860(%rbp),%rax
 10509ea:	test   %rax,%rax
 10509ed:	je     1051c7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ae>
 10509f3:	mov    0x124(%rax),%esi
 10509f9:	movl   $0x0,0x124(%rax)
 1050a03:	mov    %rbp,%rdi
 1050a06:	vzeroupper
 1050a09:	call   108b580 <myl_qbe_rc_status>
 1050a0e:	xor    %eax,%eax
 1050a10:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050a15:	lea    0xc8(%rsp),%rax
 1050a1d:	lea    0x258(%rbp),%rdi
 1050a24:	mov    %rsi,%r14
 1050a27:	mov    %rax,%rsi
 1050a2a:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a2f:	mov    %r14,%rsi
 1050a32:	test   %bl,%bl
 1050a34:	jne    104f83d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x106d>
 1050a3a:	jmp    104f88b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10bb>
 1050a3f:	mov    0x18(%rsi),%rax
 1050a43:	mov    0x14(%rsi),%ecx
 1050a46:	lea    (%rax,%rcx,1),%rdi
 1050a4a:	add    $0x18,%rdi
 1050a4e:	testb  $0x4,0x6a0ab(%rip)        # 10bab00 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x20>
 1050a55:	mov    0x6a0ac(%rip),%rax        # 10bab08 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x28>
 1050a5c:	mov    0x6a0a2(%rip),%ecx        # 10bab04 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x24>
 1050a62:	lea    0x18(%rax,%rcx,1),%rcx
 1050a67:	mov    $0x10bab08,%eax
 1050a6c:	cmovne %rcx,%rax
 1050a70:	cmp    $0x10,%rdx
 1050a74:	ja     1050a91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22c1>
 1050a76:	cmp    $0x8,%rdx
 1050a7a:	jb     1050aac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22dc>
 1050a7c:	mov    (%rdi),%rcx
 1050a7f:	mov    -0x8(%rdi,%rdx,1),%rdi
 1050a84:	xor    (%rax),%rcx
 1050a87:	xor    -0x8(%rax,%rdx,1),%rdi
 1050a8c:	or     %rcx,%rdi
 1050a8f:	jmp    1050af1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2321>
 1050a91:	mov    %rsi,%r14
 1050a94:	mov    %rax,%rsi
 1050a97:	cmp    $0x100,%rdx
 1050a9e:	ja     1050ac2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22f2>
 1050aa0:	call   10ad2e0 <bcmp@plt>
 1050aa5:	test   %eax,%eax
 1050aa7:	setne  %bl
 1050aaa:	jmp    1050acc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22fc>
 1050aac:	cmp    $0x4,%rdx
 1050ab0:	jb     1050ad1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2301>
 1050ab2:	mov    (%rdi),%ecx
 1050ab4:	mov    -0x4(%rdi,%rdx,1),%edi
 1050ab8:	xor    (%rax),%ecx
 1050aba:	xor    -0x4(%rax,%rdx,1),%edi
 1050abe:	or     %ecx,%edi
 1050ac0:	jmp    1050af1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2321>
 1050ac2:	call   1093420 <equal_large_octets>
 1050ac7:	test   %eax,%eax
 1050ac9:	sete   %bl
 1050acc:	mov    %r14,%rsi
 1050acf:	jmp    1050af7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2327>
 1050ad1:	cmp    $0x1,%rdx
 1050ad5:	jne    1050ade <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x230e>
 1050ad7:	movzbl (%rdi),%ecx
 1050ada:	cmp    (%rax),%cl
 1050adc:	jmp    1050af1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2321>
 1050ade:	movzwl (%rdi),%ecx
 1050ae1:	movzwl -0x2(%rdi,%rdx,1),%edi
 1050ae6:	xor    (%rax),%cx
 1050ae9:	xor    -0x2(%rax,%rdx,1),%di
 1050aee:	or     %cx,%di
 1050af1:	sete   %bl
 1050af4:	xor    $0x1,%bl
 1050af7:	test   %r13,0x69fe2(%rip)        # 10baae0 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050afe:	jne    1050b1d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x234d>
 1050b00:	mov    0x69fc9(%rip),%rax        # 10baad0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050b07:	dec    %rax
 1050b0a:	jne    1050b16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2346>
 1050b0c:	cmpq   $0x0,0x69fc4(%rip)        # 10baad8 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050b14:	je     1050b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23b7>
 1050b16:	mov    %rax,0x69fb3(%rip)        # 10baad0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050b1d:	test   %bl,%bl
 1050b1f:	je     1050bac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23dc>
 1050b25:	movq   $0x10ba990,0x38(%rsp)
 1050b2e:	movq   $0x10ba990,0x70(%rsp)
 1050b37:	movq   $0x10ba990,0xc8(%rsp)
 1050b43:	cmp    $0x10ba990,%rsi
 1050b4a:	jne    1050b53 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2383>
 1050b4c:	xor    %ebx,%ebx
 1050b4e:	jmp    10510c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f5>
 1050b53:	mov    $0x1,%bl
 1050b55:	test   %rsi,%rsi
 1050b58:	je     10510c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f5>
 1050b5e:	mov    0x8(%rsi),%rdx
 1050b62:	cmp    0x69e2f(%rip),%rdx        # 10ba998 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x18>
 1050b69:	jne    10510c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f5>
 1050b6f:	test   %rdx,%rdx
 1050b72:	je     1050b4c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x237c>
 1050b74:	testb  $0x4,0x10(%rsi)
 1050b78:	jne    105100d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283d>
 1050b7e:	lea    0x18(%rsi),%rdi
 1050b82:	jmp    105101c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x284c>
 1050b87:	lea    0xc8(%rsp),%rax
 1050b8f:	lea    0x258(%rbp),%rdi
 1050b96:	mov    %rsi,%r14
 1050b99:	mov    %rax,%rsi
 1050b9c:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050ba1:	mov    %r14,%rsi
 1050ba4:	test   %bl,%bl
 1050ba6:	jne    1050b25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2355>
 1050bac:	lea    0x48(%rsp),%rcx
 1050bb1:	lea    0x70(%rsp),%rdx
 1050bb6:	mov    %rdx,%rax
 1050bb9:	sub    %rcx,%rax
 1050bbc:	sub    %rdx,%rcx
 1050bbf:	cmovb  %rax,%rcx
 1050bc3:	mov    %rcx,0xf0(%rsp)
 1050bcb:	movabs $0x5000000000000000,%rax
 1050bd5:	xor    %r15d,%r15d
 1050bd8:	inc    %rax
 1050bdb:	mov    %rax,0x50(%rsp)
 1050be0:	xor    %eax,%eax
 1050be2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050bf0:	mov    %rax,%r14
 1050bf3:	mov    0x8(%rsp),%rax
 1050bf8:	add    %r15,%rax
 1050bfb:	jo     1051dd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3601>
 1050c01:	test   $0x1,%al
 1050c03:	jne    1050ca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24d0>
 1050c09:	movq   $0x10bb940,0x70(%rsp)
 1050c12:	movq   $0x10bb940,0x1c8(%rsp)
 1050c1e:	movq   $0x10bb940,0x48(%rsp)
 1050c27:	mov    0x6ad02(%rip),%rax        # 10bb930 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 1050c2e:	test   %rax,0x50(%rsp)
 1050c33:	movabs $0x4000000000000002,%rbx
 1050c3d:	je     1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x258a>
 1050c43:	cmpq   $0x0,0xf0(%rsp)
 1050c4c:	sete   %cl
 1050c4f:	movabs $0x5000000000000000,%rdx
 1050c59:	test   %rdx,%rax
 1050c5c:	setne  %al
 1050c5f:	or     %cl,%al
 1050c61:	je     1050d76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25a6>
 1050c67:	mov    $0x1030c78,%esi
 1050c6c:	lea    0x258(%rbp),%rdi
 1050c73:	lea    0x70(%rsp),%rdx
 1050c78:	lea    0x48(%rsp),%rcx
 1050c7d:	mov    0x44(%rsp),%r8d
 1050c82:	call   10a8090 <myl_rc_native_take>
 1050c87:	test   %eax,%eax
 1050c89:	jne    1050d26 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2556>
 1050c8f:	jmp    1050f9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27cb>
 1050c94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050ca0:	movq   $0x10bacb0,0x70(%rsp)
 1050ca9:	movq   $0x10bacb0,0x1c8(%rsp)
 1050cb5:	movq   $0x10bacb0,0x48(%rsp)
 1050cbe:	mov    0x69fdb(%rip),%rax        # 10baca0 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 1050cc5:	test   %rax,0x50(%rsp)
 1050cca:	movabs $0x4000000000000002,%rbx
 1050cd4:	je     1050da4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25d4>
 1050cda:	cmpq   $0x0,0xf0(%rsp)
 1050ce3:	sete   %cl
 1050ce6:	movabs $0x5000000000000000,%rdx
 1050cf0:	test   %rdx,%rax
 1050cf3:	setne  %al
 1050cf6:	or     %cl,%al
 1050cf8:	je     1050d9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25cb>
 1050cfe:	mov    $0x1030c78,%esi
 1050d03:	lea    0x258(%rbp),%rdi
 1050d0a:	lea    0x70(%rsp),%rdx
 1050d0f:	lea    0x48(%rsp),%rcx
 1050d14:	mov    0x44(%rsp),%r8d
 1050d19:	call   10a8090 <myl_rc_native_take>
 1050d1e:	test   %eax,%eax
 1050d20:	je     1050fca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27fa>
 1050d26:	mov    0x70(%rsp),%r12
 1050d2b:	mov    %r12,0xa8(%rsp)
 1050d33:	mov    %r12,0x48(%rsp)
 1050d38:	test   %r12,%r12
 1050d3b:	je     1050f2a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x275a>
 1050d41:	test   %rbx,-0x10(%r12)
 1050d46:	je     1050dbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25ee>
 1050d48:	mov    %r12,0x70(%rsp)
 1050d4d:	mov    %r12,0xa0(%rsp)
 1050d55:	jmp    1050df9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2629>
 1050d5a:	mov    $0x10bb940,%r12d
 1050d60:	mov    %r12,0xa8(%rsp)
 1050d68:	mov    %r12,0x48(%rsp)
 1050d6d:	test   %rbx,-0x10(%r12)
 1050d72:	jne    1050d48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2578>
 1050d74:	jmp    1050dbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25ee>
 1050d76:	movq   $0x10bb940,0x70(%rsp)
 1050d7f:	mov    $0x10bb940,%r12d
 1050d85:	mov    %r12,0xa8(%rsp)
 1050d8d:	mov    %r12,0x48(%rsp)
 1050d92:	test   %rbx,-0x10(%r12)
 1050d97:	jne    1050d48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2578>
 1050d99:	jmp    1050dbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25ee>
 1050d9b:	movq   $0x10bacb0,0x70(%rsp)
 1050da4:	mov    $0x10bacb0,%r12d
 1050daa:	mov    %r12,0xa8(%rsp)
 1050db2:	mov    %r12,0x48(%rsp)
 1050db7:	test   %rbx,-0x10(%r12)
 1050dbc:	jne    1050d48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2578>
 1050dbe:	mov    -0x18(%r12),%rax
 1050dc3:	inc    %rax
 1050dc6:	je     1050ff9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2829>
 1050dcc:	mov    %rax,-0x18(%r12)
 1050dd1:	mov    %r12,0x70(%rsp)
 1050dd6:	mov    %r12,0xa0(%rsp)
 1050dde:	mov    -0x20(%r12),%rax
 1050de3:	dec    %rax
 1050de6:	jne    1050df4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2624>
 1050de8:	cmpq   $0x0,-0x18(%r12)
 1050dee:	je     1050f69 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2799>
 1050df4:	mov    %rax,-0x20(%r12)
 1050df9:	movq   $0x0,0xa8(%rsp)
 1050e05:	mov    0x30(%rsp),%rax
 1050e0a:	mov    0x20(%rax),%rdx
 1050e0e:	lea    0x258(%rbp),%rdi
 1050e15:	mov    %r12,%rsi
 1050e18:	call   1093790 <myl_native_text_join>
 1050e1d:	test   %rax,%rax
 1050e20:	je     1051db9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35e9>
 1050e26:	mov    %rax,%rbx
 1050e29:	mov    %rax,0x48(%rsp)
 1050e2e:	mov    %rax,0x70(%rsp)
 1050e33:	mov    %rax,0x1c8(%rsp)
 1050e3b:	mov    %rbp,%rdi
 1050e3e:	mov    %rax,%rsi
 1050e41:	call   1074e10 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050e46:	mov    %rax,%r13
 1050e49:	movabs $0x4000000000000002,%rax
 1050e53:	test   %rax,-0x10(%rbx)
 1050e57:	je     1050e70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26a0>
 1050e59:	movq   $0x0,0x1c8(%rsp)
 1050e65:	test   %r12,%r12
 1050e68:	jne    1050e99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 1050e6a:	jmp    1050ed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2701>
 1050e6c:	nopl   0x0(%rax)
 1050e70:	mov    -0x20(%rbx),%rax
 1050e74:	dec    %rax
 1050e77:	jne    1050e84 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26b4>
 1050e79:	cmpq   $0x0,-0x18(%rbx)
 1050e7e:	je     1050f47 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2777>
 1050e84:	mov    %rax,-0x20(%rbx)
 1050e88:	movq   $0x0,0x1c8(%rsp)
 1050e94:	test   %r12,%r12
 1050e97:	je     1050ed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2701>
 1050e99:	movabs $0x4000000000000002,%rax
 1050ea3:	test   %rax,-0x10(%r12)
 1050ea8:	jne    1050ec5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26f5>
 1050eaa:	mov    -0x18(%r12),%rax
 1050eaf:	dec    %rax
 1050eb2:	jne    1050ec0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26f0>
 1050eb4:	cmpq   $0x0,-0x20(%r12)
 1050eba:	je     1050f82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27b2>
 1050ec0:	mov    %rax,-0x18(%r12)
 1050ec5:	movq   $0x0,0xa0(%rsp)
 1050ed1:	mov    %r14,%rcx
 1050ed4:	add    %r13,%rcx
 1050ed7:	jo     1051dc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35f1>
 1050edd:	mov    %rcx,%rax
 1050ee0:	movabs $0x89705f3112a28fe5,%rdx
 1050eea:	imul   %rdx
 1050eed:	add    %rcx,%rdx
 1050ef0:	mov    %rdx,%rax
 1050ef3:	shr    $0x3f,%rax
 1050ef7:	sar    $0x1d,%rdx
 1050efb:	add    %rax,%rdx
 1050efe:	imul   $0x3b9aca07,%rdx,%rax
 1050f05:	sub    %rax,%rcx
 1050f08:	mov    %rcx,%rax
 1050f0b:	sar    $0x3f,%rax
 1050f0f:	and    $0x3b9aca07,%eax
 1050f14:	add    %rcx,%rax
 1050f17:	inc    %r15
 1050f1a:	cmp    %r15,0x28(%rsp)
 1050f1f:	jne    1050bf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2420>
 1050f25:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050f2a:	movq   $0x0,0x70(%rsp)
 1050f33:	movq   $0x0,0xa0(%rsp)
 1050f3f:	xor    %r12d,%r12d
 1050f42:	jmp    1050e05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2635>
 1050f47:	lea    0x258(%rbp),%rdi
 1050f4e:	lea    0x1c8(%rsp),%rsi
 1050f56:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f5b:	test   %r12,%r12
 1050f5e:	jne    1050e99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 1050f64:	jmp    1050ed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2701>
 1050f69:	lea    0x258(%rbp),%rdi
 1050f70:	lea    0xa8(%rsp),%rsi
 1050f78:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f7d:	jmp    1050e05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2635>
 1050f82:	lea    0x258(%rbp),%rdi
 1050f89:	lea    0xa0(%rsp),%rsi
 1050f91:	call   1087820 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050f96:	jmp    1050ed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2701>
 1050f9b:	mov    0x1860(%rbp),%rax
 1050fa2:	test   %rax,%rax
 1050fa5:	je     1051c7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ae>
 1050fab:	mov    0x124(%rax),%esi
 1050fb1:	movl   $0x0,0x124(%rax)
 1050fbb:	mov    %rbp,%rdi
 1050fbe:	call   108b580 <myl_qbe_rc_status>
 1050fc3:	xor    %eax,%eax
 1050fc5:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050fca:	mov    0x1860(%rbp),%rax
 1050fd1:	test   %rax,%rax
 1050fd4:	je     1051c7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ae>
 1050fda:	mov    0x124(%rax),%esi
 1050fe0:	movl   $0x0,0x124(%rax)
 1050fea:	mov    %rbp,%rdi
 1050fed:	call   108b580 <myl_qbe_rc_status>
 1050ff2:	xor    %eax,%eax
 1050ff4:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050ff9:	mov    $0x1007dbf,%esi
 1050ffe:	mov    %rbp,%rdi
 1051001:	call   108bdde <fail>
 1051006:	xor    %eax,%eax
 1051008:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105100d:	mov    0x18(%rsi),%rax
 1051011:	mov    0x14(%rsi),%ecx
 1051014:	lea    (%rax,%rcx,1),%rdi
 1051018:	add    $0x18,%rdi
 105101c:	testb  $0x4,0x6997d(%rip)        # 10ba9a0 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x20>
 1051023:	mov    0x6997e(%rip),%rax        # 10ba9a8 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x28>
 105102a:	mov    0x69974(%rip),%ecx        # 10ba9a4 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x24>
 1051030:	lea    0x18(%rax,%rcx,1),%rcx
 1051035:	mov    $0x10ba9a8,%eax
 105103a:	cmovne %rcx,%rax
 105103e:	cmp    $0x10,%rdx
 1051042:	ja     105105f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x288f>
 1051044:	cmp    $0x8,%rdx
 1051048:	jb     105107a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28aa>
 105104a:	mov    (%rdi),%rcx
 105104d:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051052:	xor    (%rax),%rcx
 1051055:	xor    -0x8(%rax,%rdx,1),%rdi
 105105a:	or     %rcx,%rdi
 105105d:	jmp    10510bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ef>
 105105f:	mov    %rsi,%r14
 1051062:	mov    %rax,%rsi
 1051065:	cmp    $0x100,%rdx
 105106c:	ja     1051090 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28c0>
 105106e:	call   10ad2e0 <bcmp@plt>
 1051073:	test   %eax,%eax
 1051075:	setne  %bl
 1051078:	jmp    105109a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ca>
 105107a:	cmp    $0x4,%rdx
 105107e:	jb     105109f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28cf>
 1051080:	mov    (%rdi),%ecx
 1051082:	mov    -0x4(%rdi,%rdx,1),%edi
 1051086:	xor    (%rax),%ecx
 1051088:	xor    -0x4(%rax,%rdx,1),%edi
 105108c:	or     %ecx,%edi
 105108e:	jmp    10510bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ef>
 1051090:	call   1093420 <equal_large_octets>
 1051095:	test   %eax,%eax
 1051097:	sete   %bl
 105109a:	mov    %r14,%rsi
 105109d:	jmp    10510c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f5>
 105109f:	cmp    $0x1,%rdx
 10510a3:	jne    10510ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28dc>
 10510a5:	movzbl (%rdi),%ecx
 10510a8:	cmp    (%rax),%cl
 10510aa:	jmp    10510bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ef>
 10510ac:	movzwl (%rdi),%ecx
 10510af:	movzwl -0x2(%rdi,%rdx,1),%edi
 10510b4:	xor    (%rax),%cx
 10510b7:	xor    -0x2(%rax,%rdx,1),%di
 10510bc:	or     %cx,%di
 10510bf:	sete   %bl
 10510c2:	xor    $0x1,%bl
 10510c5:	test   %r13,0x698b4(%rip)        # 10ba980 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 10510cc:	jne    10510eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x291b>
 10510ce:	mov    0x6989b(%rip),%rax        # 10ba970 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10510d5:	dec    %rax
 10510d8:	jne    10510e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2914>
 10510da:	cmpq   $0x0,0x69896(%rip)        # 10ba978 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 10510e2:	je     1051154 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2984>
 10510e4:	mov    %rax,0x69885(%rip)        # 10ba970 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10510eb:	movq   $0x0,0xc8(%rsp)
 10510f7:	test   %bl,%bl
 10510f9:	je     1051175 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29a5>
 10510fb:	movq   $0x10bae98,0x70(%rsp)
 1051104:	movq   $0x10bae98,0xc8(%rsp)
 1051110:	cmp    $0x10bae98,%rsi
 1051117:	jne    1051120 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2950>
 1051119:	xor    %ebx,%ebx
 105111b:	jmp    105146c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9c>
 1051120:	mov    $0x1,%bl
 1051122:	test   %rsi,%rsi
 1051125:	je     105146c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9c>
 105112b:	mov    0x8(%rsi),%rdx
 105112f:	cmp    0x69d6a(%rip),%rdx        # 10baea0 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x18>
 1051136:	jne    105146c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9c>
 105113c:	test   %rdx,%rdx
 105113f:	je     1051119 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2949>
 1051141:	testb  $0x4,0x10(%rsi)
 1051145:	jne    10513b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2be4>
 105114b:	lea    0x18(%rsi),%rdi
 105114f:	jmp    10513c3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bf3>
 1051154:	lea    0xc8(%rsp),%rax
 105115c:	lea    0x258(%rbp),%rdi
 1051163:	mov    %rsi,%r14
 1051166:	mov    %rax,%rsi
 1051169:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105116e:	mov    %r14,%rsi
 1051171:	test   %bl,%bl
 1051173:	jne    10510fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x292b>
 1051175:	xor    %ebx,%ebx
 1051177:	lea    0x1a8(%rsp),%r14
 105117f:	movabs $0x89705f3112a28fe5,%r13
 1051189:	xor    %eax,%eax
 105118b:	nopl   0x0(%rax,%rax,1)
 1051190:	mov    %rax,%r15
 1051193:	mov    0x8(%rsp),%rax
 1051198:	add    %rbx,%rax
 105119b:	jo     1051de3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3613>
 10511a1:	mov    0x30(%rsp),%rcx
 10511a6:	mov    0x8(%rcx),%rdi
 10511aa:	mov    (%rdi),%rcx
 10511ad:	test   %rcx,%rcx
 10511b0:	js     1051df5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3625>
 10511b6:	je     1051e00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3630>
 10511bc:	mov    %rax,%rdx
 10511bf:	or     %rcx,%rdx
 10511c2:	shr    $0x20,%rdx
 10511c6:	je     10511cf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ff>
 10511c8:	cqto
 10511ca:	idiv   %rcx
 10511cd:	jmp    10511d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a03>
 10511cf:	xor    %edx,%edx
 10511d1:	div    %ecx
 10511d3:	mov    %rdx,%rax
 10511d6:	sar    $0x3f,%rax
 10511da:	and    %rcx,%rax
 10511dd:	add    %rdx,%rax
 10511e0:	mov    %rax,%rsi
 10511e3:	sar    $0x3f,%rsi
 10511e7:	and    %rcx,%rsi
 10511ea:	add    %rax,%rsi
 10511ed:	cmp    %rcx,%rsi
 10511f0:	jae    1051e0b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x363b>
 10511f6:	mov    0x20(%rdi),%rax
 10511fa:	mov    (%rax,%rsi,8),%rax
 10511fe:	test   %rax,%rax
 1051201:	je     105122e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a5e>
 1051203:	mov    %rax,%rdi
 1051206:	movabs $0x4000000000000002,%rcx
 1051210:	test   %rcx,-0x10(%rax)
 1051214:	je     105135f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b8f>
 105121a:	mov    %rax,0x140(%rsp)
 1051222:	testb  $0x4,0x10(%rdi)
 1051226:	jne    105123e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a6e>
 1051228:	add    $0x18,%rdi
 105122c:	jmp    105124d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a7d>
 105122e:	xor    %edi,%edi
 1051230:	mov    %rax,0x140(%rsp)
 1051238:	testb  $0x4,0x10(%rdi)
 105123c:	je     1051228 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a58>
 105123e:	mov    0x18(%rdi),%rcx
 1051242:	mov    0x14(%rdi),%edx
 1051245:	lea    (%rcx,%rdx,1),%rdi
 1051249:	add    $0x18,%rdi
 105124d:	mov    0x8(%rax),%rsi
 1051251:	xor    %edx,%edx
 1051253:	mov    %r14,%rcx
 1051256:	call   104a290 <myl_native_bytes_number_parse>
 105125b:	test   %eax,%eax
 105125d:	je     10512c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2af1>
 105125f:	mov    0x1a8(%rsp),%r12
 1051267:	movl   $0x1,0x160(%rsp)
 1051272:	mov    %r12,0x168(%rsp)
 105127a:	mov    0x140(%rsp),%rax
 1051282:	test   %rax,%rax
 1051285:	je     1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 105128b:	movabs $0x4000000000000002,%rcx
 1051295:	test   %rcx,-0x10(%rax)
 1051299:	jne    1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 105129b:	mov    -0x18(%rax),%rcx
 105129f:	dec    %rcx
 10512a2:	jne    1051303 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b33>
 10512a4:	cmpq   $0x0,-0x20(%rax)
 10512a9:	jne    1051303 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b33>
 10512ab:	lea    0x258(%rbp),%rdi
 10512b2:	lea    0x140(%rsp),%rsi
 10512ba:	call   1087820 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10512bf:	jmp    1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 10512c1:	movl   $0x0,0x160(%rsp)
 10512cc:	mov    0x140(%rsp),%rax
 10512d4:	mov    $0x61,%r12d
 10512da:	test   %rax,%rax
 10512dd:	je     1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 10512df:	movabs $0x4000000000000002,%rcx
 10512e9:	test   %rcx,-0x10(%rax)
 10512ed:	jne    1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 10512ef:	mov    -0x18(%rax),%rcx
 10512f3:	dec    %rcx
 10512f6:	jne    1051303 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b33>
 10512f8:	cmpq   $0x0,-0x20(%rax)
 10512fd:	je     105139b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bcb>
 1051303:	mov    %rcx,-0x18(%rax)
 1051307:	nopw   0x0(%rax,%rax,1)
 1051310:	mov    %r15,%rcx
 1051313:	add    %r12,%rcx
 1051316:	jo     1051e16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3646>
 105131c:	mov    %rcx,%rax
 105131f:	imul   %r13
 1051322:	add    %rcx,%rdx
 1051325:	mov    %rdx,%rax
 1051328:	shr    $0x3f,%rax
 105132c:	sar    $0x1d,%rdx
 1051330:	add    %rax,%rdx
 1051333:	imul   $0x3b9aca07,%rdx,%rax
 105133a:	sub    %rax,%rcx
 105133d:	mov    %rcx,%rax
 1051340:	sar    $0x3f,%rax
 1051344:	and    $0x3b9aca07,%eax
 1051349:	add    %rcx,%rax
 105134c:	inc    %rbx
 105134f:	cmp    %rbx,0x28(%rsp)
 1051354:	jne    1051190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29c0>
 105135a:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105135f:	mov    -0x18(%rax),%rcx
 1051363:	inc    %rcx
 1051366:	je     1051386 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bb6>
 1051368:	mov    %rcx,-0x18(%rax)
 105136c:	mov    %rax,%rdi
 105136f:	mov    %rax,0x140(%rsp)
 1051377:	testb  $0x4,0x10(%rdi)
 105137b:	jne    105123e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a6e>
 1051381:	jmp    1051228 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a58>
 1051386:	mov    $0x1007dbf,%esi
 105138b:	mov    %rbp,%rdi
 105138e:	call   108bdde <fail>
 1051393:	xor    %r12d,%r12d
 1051396:	jmp    1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 105139b:	lea    0x258(%rbp),%rdi
 10513a2:	lea    0x140(%rsp),%rsi
 10513aa:	call   1087820 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10513af:	jmp    1051310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b40>
 10513b4:	mov    0x18(%rsi),%rax
 10513b8:	mov    0x14(%rsi),%ecx
 10513bb:	lea    (%rax,%rcx,1),%rdi
 10513bf:	add    $0x18,%rdi
 10513c3:	testb  $0x4,0x69ade(%rip)        # 10baea8 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x20>
 10513ca:	mov    0x69adf(%rip),%rax        # 10baeb0 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x28>
 10513d1:	mov    0x69ad5(%rip),%ecx        # 10baeac <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x24>
 10513d7:	lea    0x18(%rax,%rcx,1),%rcx
 10513dc:	mov    $0x10baeb0,%eax
 10513e1:	cmovne %rcx,%rax
 10513e5:	cmp    $0x10,%rdx
 10513e9:	ja     1051406 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c36>
 10513eb:	cmp    $0x8,%rdx
 10513ef:	jb     1051421 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c51>
 10513f1:	mov    (%rdi),%rcx
 10513f4:	mov    -0x8(%rdi,%rdx,1),%rdi
 10513f9:	xor    (%rax),%rcx
 10513fc:	xor    -0x8(%rax,%rdx,1),%rdi
 1051401:	or     %rcx,%rdi
 1051404:	jmp    1051466 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c96>
 1051406:	mov    %rsi,%r14
 1051409:	mov    %rax,%rsi
 105140c:	cmp    $0x100,%rdx
 1051413:	ja     1051437 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c67>
 1051415:	call   10ad2e0 <bcmp@plt>
 105141a:	test   %eax,%eax
 105141c:	setne  %bl
 105141f:	jmp    1051441 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c71>
 1051421:	cmp    $0x4,%rdx
 1051425:	jb     1051446 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c76>
 1051427:	mov    (%rdi),%ecx
 1051429:	mov    -0x4(%rdi,%rdx,1),%edi
 105142d:	xor    (%rax),%ecx
 105142f:	xor    -0x4(%rax,%rdx,1),%edi
 1051433:	or     %ecx,%edi
 1051435:	jmp    1051466 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c96>
 1051437:	call   1093420 <equal_large_octets>
 105143c:	test   %eax,%eax
 105143e:	sete   %bl
 1051441:	mov    %r14,%rsi
 1051444:	jmp    105146c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9c>
 1051446:	cmp    $0x1,%rdx
 105144a:	jne    1051453 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c83>
 105144c:	movzbl (%rdi),%ecx
 105144f:	cmp    (%rax),%cl
 1051451:	jmp    1051466 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c96>
 1051453:	movzwl (%rdi),%ecx
 1051456:	movzwl -0x2(%rdi,%rdx,1),%edi
 105145b:	xor    (%rax),%cx
 105145e:	xor    -0x2(%rax,%rdx,1),%di
 1051463:	or     %cx,%di
 1051466:	sete   %bl
 1051469:	xor    $0x1,%bl
 105146c:	test   %r13,0x69a15(%rip)        # 10bae88 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1051473:	jne    1051492 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc2>
 1051475:	mov    0x699fc(%rip),%rax        # 10bae78 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 105147c:	dec    %rax
 105147f:	jne    105148b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbb>
 1051481:	cmpq   $0x0,0x699f7(%rip)        # 10bae80 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 1051489:	je     10514ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d1f>
 105148b:	mov    %rax,0x699e6(%rip)        # 10bae78 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1051492:	test   %bl,%bl
 1051494:	je     1051510 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d40>
 1051496:	movq   $0x10bb2b0,0x70(%rsp)
 105149f:	movq   $0x10bb2b0,0xc8(%rsp)
 10514ab:	cmp    $0x10bb2b0,%rsi
 10514b2:	jne    10514bb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ceb>
 10514b4:	xor    %ebx,%ebx
 10514b6:	jmp    105172e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f5e>
 10514bb:	mov    $0x1,%bl
 10514bd:	test   %rsi,%rsi
 10514c0:	je     105172e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f5e>
 10514c6:	mov    0x8(%rsi),%rdx
 10514ca:	cmp    0x69de7(%rip),%rdx        # 10bb2b8 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x18>
 10514d1:	jne    105172e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f5e>
 10514d7:	test   %rdx,%rdx
 10514da:	je     10514b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce4>
 10514dc:	testb  $0x4,0x10(%rsi)
 10514e0:	jne    1051676 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ea6>
 10514e6:	lea    0x18(%rsi),%rdi
 10514ea:	jmp    1051685 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2eb5>
 10514ef:	lea    0xc8(%rsp),%rax
 10514f7:	lea    0x258(%rbp),%rdi
 10514fe:	mov    %rsi,%r14
 1051501:	mov    %rax,%rsi
 1051504:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051509:	mov    %r14,%rsi
 105150c:	test   %bl,%bl
 105150e:	jne    1051496 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc6>
 1051510:	xor    %ebx,%ebx
 1051512:	movabs $0x89705f3112a28fe5,%r12
 105151c:	xor    %eax,%eax
 105151e:	movabs $0x4000000000000002,%r13
 1051528:	nopl   0x0(%rax,%rax,1)
 1051530:	mov    %rax,%r14
 1051533:	mov    0x8(%rsp),%rax
 1051538:	add    %rbx,%rax
 105153b:	jo     1051e26 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3656>
 1051541:	mov    0x30(%rsp),%rcx
 1051546:	mov    0x18(%rcx),%rdi
 105154a:	mov    (%rdi),%rcx
 105154d:	test   %rcx,%rcx
 1051550:	js     1051e38 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3668>
 1051556:	je     1051e43 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3673>
 105155c:	mov    %rax,%rdx
 105155f:	or     %rcx,%rdx
 1051562:	shr    $0x20,%rdx
 1051566:	je     105156f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d9f>
 1051568:	cqto
 105156a:	idiv   %rcx
 105156d:	jmp    1051573 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2da3>
 105156f:	xor    %edx,%edx
 1051571:	div    %ecx
 1051573:	mov    %rdx,%rsi
 1051576:	sar    $0x3f,%rsi
 105157a:	and    %rcx,%rsi
 105157d:	add    %rdx,%rsi
 1051580:	cmp    %rcx,%rsi
 1051583:	jb     105159b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dcb>
 1051585:	mov    %rsi,%rax
 1051588:	sar    $0x3f,%rax
 105158c:	and    %rcx,%rax
 105158f:	add    %rax,%rsi
 1051592:	cmp    %rcx,%rsi
 1051595:	jae    1051e56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3686>
 105159b:	mov    0x20(%rdi),%rax
 105159f:	mov    (%rax,%rsi,8),%rsi
 10515a3:	lea    0x258(%rbp),%rdi
 10515aa:	call   104bdf0 <myl_native_text_integer>
 10515af:	test   %rax,%rax
 10515b2:	je     1051e4e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x367e>
 10515b8:	mov    %rax,%r15
 10515bb:	mov    %rax,0x70(%rsp)
 10515c0:	mov    %rax,0x1c8(%rsp)
 10515c8:	mov    %rbp,%rdi
 10515cb:	mov    %rax,%rsi
 10515ce:	call   1074e10 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10515d3:	test   %r13,-0x10(%r15)
 10515d7:	jne    10515ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e1d>
 10515d9:	mov    -0x20(%r15),%rcx
 10515dd:	dec    %rcx
 10515e0:	jne    10515e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e19>
 10515e2:	cmpq   $0x0,-0x18(%r15)
 10515e7:	je     1051644 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e74>
 10515e9:	mov    %rcx,-0x20(%r15)
 10515ed:	movq   $0x0,0x1c8(%rsp)
 10515f9:	mov    %r14,%rcx
 10515fc:	add    %rax,%rcx
 10515ff:	jo     1051666 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e96>
 1051601:	mov    %rcx,%rax
 1051604:	imul   %r12
 1051607:	add    %rcx,%rdx
 105160a:	mov    %rdx,%rax
 105160d:	shr    $0x3f,%rax
 1051611:	sar    $0x1d,%rdx
 1051615:	add    %rax,%rdx
 1051618:	imul   $0x3b9aca07,%rdx,%rax
 105161f:	sub    %rax,%rcx
 1051622:	mov    %rcx,%rax
 1051625:	sar    $0x3f,%rax
 1051629:	and    $0x3b9aca07,%eax
 105162e:	add    %rcx,%rax
 1051631:	inc    %rbx
 1051634:	cmp    %rbx,0x28(%rsp)
 1051639:	jne    1051530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d60>
 105163f:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051644:	lea    0x258(%rbp),%rdi
 105164b:	lea    0x1c8(%rsp),%rsi
 1051653:	mov    %rax,%r15
 1051656:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105165b:	mov    %r15,%rax
 105165e:	mov    %r14,%rcx
 1051661:	add    %rax,%rcx
 1051664:	jno    1051601 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e31>
 1051666:	mov    %rbp,%rdi
 1051669:	xor    %esi,%esi
 105166b:	mov    %r14,%rdx
 105166e:	mov    %rax,%rcx
 1051671:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051676:	mov    0x18(%rsi),%rax
 105167a:	mov    0x14(%rsi),%ecx
 105167d:	lea    (%rax,%rcx,1),%rdi
 1051681:	add    $0x18,%rdi
 1051685:	testb  $0x4,0x69c34(%rip)        # 10bb2c0 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x20>
 105168c:	mov    0x69c35(%rip),%rax        # 10bb2c8 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x28>
 1051693:	mov    0x69c2b(%rip),%ecx        # 10bb2c4 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x24>
 1051699:	lea    0x18(%rax,%rcx,1),%rcx
 105169e:	mov    $0x10bb2c8,%eax
 10516a3:	cmovne %rcx,%rax
 10516a7:	cmp    $0x10,%rdx
 10516ab:	ja     10516c8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ef8>
 10516ad:	cmp    $0x8,%rdx
 10516b1:	jb     10516e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f13>
 10516b3:	mov    (%rdi),%rcx
 10516b6:	mov    -0x8(%rdi,%rdx,1),%rdi
 10516bb:	xor    (%rax),%rcx
 10516be:	xor    -0x8(%rax,%rdx,1),%rdi
 10516c3:	or     %rcx,%rdi
 10516c6:	jmp    1051728 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f58>
 10516c8:	mov    %rsi,%r14
 10516cb:	mov    %rax,%rsi
 10516ce:	cmp    $0x100,%rdx
 10516d5:	ja     10516f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f29>
 10516d7:	call   10ad2e0 <bcmp@plt>
 10516dc:	test   %eax,%eax
 10516de:	setne  %bl
 10516e1:	jmp    1051703 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f33>
 10516e3:	cmp    $0x4,%rdx
 10516e7:	jb     1051708 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f38>
 10516e9:	mov    (%rdi),%ecx
 10516eb:	mov    -0x4(%rdi,%rdx,1),%edi
 10516ef:	xor    (%rax),%ecx
 10516f1:	xor    -0x4(%rax,%rdx,1),%edi
 10516f5:	or     %ecx,%edi
 10516f7:	jmp    1051728 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f58>
 10516f9:	call   1093420 <equal_large_octets>
 10516fe:	test   %eax,%eax
 1051700:	sete   %bl
 1051703:	mov    %r14,%rsi
 1051706:	jmp    105172e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f5e>
 1051708:	cmp    $0x1,%rdx
 105170c:	jne    1051715 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f45>
 105170e:	movzbl (%rdi),%ecx
 1051711:	cmp    (%rax),%cl
 1051713:	jmp    1051728 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f58>
 1051715:	movzwl (%rdi),%ecx
 1051718:	movzwl -0x2(%rdi,%rdx,1),%edi
 105171d:	xor    (%rax),%cx
 1051720:	xor    -0x2(%rax,%rdx,1),%di
 1051725:	or     %cx,%di
 1051728:	sete   %bl
 105172b:	xor    $0x1,%bl
 105172e:	test   %r13,0x69b6b(%rip)        # 10bb2a0 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1051735:	jne    1051754 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f84>
 1051737:	mov    0x69b52(%rip),%rax        # 10bb290 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 105173e:	dec    %rax
 1051741:	jne    105174d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7d>
 1051743:	cmpq   $0x0,0x69b4d(%rip)        # 10bb298 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 105174b:	je     10517c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ff2>
 105174d:	mov    %rax,0x69b3c(%rip)        # 10bb290 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051754:	test   %bl,%bl
 1051756:	je     10517e7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3017>
 105175c:	movq   $0x10ba748,0x70(%rsp)
 1051765:	movq   $0x10ba748,0xc8(%rsp)
 1051771:	cmp    $0x10ba748,%rsi
 1051778:	jne    105178e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fbe>
 105177a:	xor    %ebx,%ebx
 105177c:	test   %r13,0x68fb5(%rip)        # 10ba738 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051783:	jne    1051946 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3176>
 1051789:	jmp    1051925 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3155>
 105178e:	mov    $0x1,%bl
 1051790:	test   %rsi,%rsi
 1051793:	je     105191c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x314c>
 1051799:	mov    0x8(%rsi),%rdx
 105179d:	cmp    0x68fac(%rip),%rdx        # 10ba750 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x18>
 10517a4:	jne    105191c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x314c>
 10517aa:	test   %rdx,%rdx
 10517ad:	je     105177a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2faa>
 10517af:	testb  $0x4,0x10(%rsi)
 10517b3:	jne    1051879 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30a9>
 10517b9:	lea    0x18(%rsi),%rdi
 10517bd:	jmp    1051888 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30b8>
 10517c2:	lea    0xc8(%rsp),%rax
 10517ca:	lea    0x258(%rbp),%rdi
 10517d1:	mov    %rsi,%r14
 10517d4:	mov    %rax,%rsi
 10517d7:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10517dc:	mov    %r14,%rsi
 10517df:	test   %bl,%bl
 10517e1:	jne    105175c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f8c>
 10517e7:	xor    %ebx,%ebx
 10517e9:	movabs $0x89705f3112a28fe5,%r14
 10517f3:	xor    %eax,%eax
 10517f5:	mov    0x8(%rsp),%rsi
 10517fa:	add    %rbx,%rsi
 10517fd:	jo     1051e61 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3691>
 1051803:	mov    %rax,%r15
 1051806:	mov    0x30(%rsp),%rax
 105180b:	mov    0x8(%rax),%rax
 105180f:	and    $0x1,%esi
 1051812:	mov    (%rax),%rdx
 1051815:	cmp    %rdx,%rsi
 1051818:	jae    1051e73 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36a3>
 105181e:	mov    0x20(%rax),%rax
 1051822:	mov    (%rax,%rsi,8),%rsi
 1051826:	mov    %rbp,%rdi
 1051829:	call   106b570 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 105182e:	mov    %r15,%rcx
 1051831:	add    %rax,%rcx
 1051834:	jo     1051e7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ab>
 105183a:	mov    %rcx,%rax
 105183d:	imul   %r14
 1051840:	add    %rcx,%rdx
 1051843:	mov    %rdx,%rax
 1051846:	shr    $0x3f,%rax
 105184a:	sar    $0x1d,%rdx
 105184e:	add    %rax,%rdx
 1051851:	imul   $0x3b9aca07,%rdx,%rax
 1051858:	sub    %rax,%rcx
 105185b:	mov    %rcx,%rax
 105185e:	sar    $0x3f,%rax
 1051862:	and    $0x3b9aca07,%eax
 1051867:	add    %rcx,%rax
 105186a:	inc    %rbx
 105186d:	cmp    %rbx,0x28(%rsp)
 1051872:	jne    10517f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3025>
 1051874:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051879:	mov    0x18(%rsi),%rax
 105187d:	mov    0x14(%rsi),%ecx
 1051880:	lea    (%rax,%rcx,1),%rdi
 1051884:	add    $0x18,%rdi
 1051888:	testb  $0x4,0x68ec9(%rip)        # 10ba758 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x20>
 105188f:	mov    0x68eca(%rip),%rax        # 10ba760 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x28>
 1051896:	mov    0x68ec0(%rip),%ecx        # 10ba75c <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x24>
 105189c:	lea    0x18(%rax,%rcx,1),%rcx
 10518a1:	mov    $0x10ba760,%eax
 10518a6:	cmovne %rcx,%rax
 10518aa:	cmp    $0x10,%rdx
 10518ae:	ja     10518cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30fb>
 10518b0:	cmp    $0x8,%rdx
 10518b4:	jb     10518e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3116>
 10518b6:	mov    (%rdi),%rcx
 10518b9:	mov    -0x8(%rdi,%rdx,1),%rdi
 10518be:	xor    (%rax),%rcx
 10518c1:	xor    -0x8(%rax,%rdx,1),%rdi
 10518c6:	or     %rcx,%rdi
 10518c9:	jmp    10518fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x312e>
 10518cb:	mov    %rsi,%r14
 10518ce:	mov    %rax,%rsi
 10518d1:	cmp    $0x100,%rdx
 10518d8:	ja     105190f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x313f>
 10518da:	call   10ad2e0 <bcmp@plt>
 10518df:	test   %eax,%eax
 10518e1:	setne  %bl
 10518e4:	jmp    1051919 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3149>
 10518e6:	cmp    $0x4,%rdx
 10518ea:	jb     1051ac9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32f9>
 10518f0:	mov    (%rdi),%ecx
 10518f2:	mov    -0x4(%rdi,%rdx,1),%edi
 10518f6:	xor    (%rax),%ecx
 10518f8:	xor    -0x4(%rax,%rdx,1),%edi
 10518fc:	or     %ecx,%edi
 10518fe:	sete   %bl
 1051901:	xor    $0x1,%bl
 1051904:	test   %r13,0x68e2d(%rip)        # 10ba738 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 105190b:	jne    1051946 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3176>
 105190d:	jmp    1051925 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3155>
 105190f:	call   1093420 <equal_large_octets>
 1051914:	test   %eax,%eax
 1051916:	sete   %bl
 1051919:	mov    %r14,%rsi
 105191c:	test   %r13,0x68e15(%rip)        # 10ba738 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051923:	jne    1051946 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3176>
 1051925:	mov    0x68dfc(%rip),%rax        # 10ba728 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105192c:	dec    %rax
 105192f:	jne    105193f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x316f>
 1051931:	cmpq   $0x0,0x68df7(%rip)        # 10ba730 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 1051939:	je     1051a30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3260>
 105193f:	mov    %rax,0x68de2(%rip)        # 10ba728 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051946:	test   %bl,%bl
 1051948:	je     1051973 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31a3>
 105194a:	movq   $0x10ba818,0x70(%rsp)
 1051953:	movq   $0x10ba818,0xc8(%rsp)
 105195f:	cmp    $0x10ba818,%rsi
 1051966:	jne    10519ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x322f>
 105196c:	xor    %ebx,%ebx
 105196e:	jmp    1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051973:	xor    %ebx,%ebx
 1051975:	movabs $0x89705f3112a28fe5,%r14
 105197f:	xor    %eax,%eax
 1051981:	mov    %rax,%r15
 1051984:	mov    0x8(%rsp),%rax
 1051989:	add    %rbx,%rax
 105198c:	jo     1051e8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36bb>
 1051992:	mov    0x30(%rsp),%rax
 1051997:	mov    0x8(%rax),%rax
 105199b:	cmpq   $0x0,(%rax)
 105199f:	je     1051e9d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36cd>
 10519a5:	mov    0x20(%rax),%rax
 10519a9:	mov    (%rax),%rsi
 10519ac:	mov    %rbp,%rdi
 10519af:	call   1072af0 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 10519b4:	mov    %r15,%rcx
 10519b7:	add    %rax,%rcx
 10519ba:	jo     1051ea9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36d9>
 10519c0:	mov    %rcx,%rax
 10519c3:	imul   %r14
 10519c6:	add    %rcx,%rdx
 10519c9:	mov    %rdx,%rax
 10519cc:	shr    $0x3f,%rax
 10519d0:	sar    $0x1d,%rdx
 10519d4:	add    %rax,%rdx
 10519d7:	imul   $0x3b9aca07,%rdx,%rax
 10519de:	sub    %rax,%rcx
 10519e1:	mov    %rcx,%rax
 10519e4:	sar    $0x3f,%rax
 10519e8:	and    $0x3b9aca07,%eax
 10519ed:	add    %rcx,%rax
 10519f0:	inc    %rbx
 10519f3:	cmp    %rbx,0x28(%rsp)
 10519f8:	jne    1051981 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31b1>
 10519fa:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 10519ff:	mov    $0x1,%bl
 1051a01:	test   %rsi,%rsi
 1051a04:	je     1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051a0a:	mov    0x8(%rsi),%rdx
 1051a0e:	cmp    0x68e0b(%rip),%rdx        # 10ba820 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x18>
 1051a15:	jne    1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051a1b:	test   %rdx,%rdx
 1051a1e:	je     105196c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x319c>
 1051a24:	testb  $0x4,0x10(%rsi)
 1051a28:	jne    1051a50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3280>
 1051a2a:	add    $0x18,%rsi
 1051a2e:	jmp    1051a5f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x328f>
 1051a30:	lea    0xc8(%rsp),%rax
 1051a38:	mov    0x18(%rsp),%rdi
 1051a3d:	mov    %rsi,%r14
 1051a40:	mov    %rax,%rsi
 1051a43:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051a48:	mov    %r14,%rsi
 1051a4b:	jmp    1051946 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3176>
 1051a50:	mov    0x18(%rsi),%rax
 1051a54:	mov    0x14(%rsi),%ecx
 1051a57:	lea    (%rax,%rcx,1),%rsi
 1051a5b:	add    $0x18,%rsi
 1051a5f:	testb  $0x4,0x68dc2(%rip)        # 10ba828 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x20>
 1051a66:	mov    0x68dc3(%rip),%rax        # 10ba830 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x28>
 1051a6d:	mov    0x68db9(%rip),%ecx        # 10ba82c <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x24>
 1051a73:	lea    0x18(%rax,%rcx,1),%rcx
 1051a78:	mov    $0x10ba830,%eax
 1051a7d:	cmovne %rcx,%rax
 1051a81:	cmp    $0x10,%rdx
 1051a85:	ja     1051aab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32db>
 1051a87:	cmp    $0x8,%rdx
 1051a8b:	jb     1051ad6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3306>
 1051a8d:	mov    (%rsi),%rcx
 1051a90:	mov    -0x8(%rsi,%rdx,1),%rsi
 1051a95:	xor    (%rax),%rcx
 1051a98:	xor    -0x8(%rax,%rdx,1),%rsi
 1051a9d:	or     %rcx,%rsi
 1051aa0:	sete   %bl
 1051aa3:	xor    $0x1,%bl
 1051aa6:	jmp    1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051aab:	mov    %rsi,%rdi
 1051aae:	mov    %rax,%rsi
 1051ab1:	cmp    $0x100,%rdx
 1051ab8:	ja     1051aec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x331c>
 1051aba:	call   10ad2e0 <bcmp@plt>
 1051abf:	test   %eax,%eax
 1051ac1:	setne  %bl
 1051ac4:	jmp    1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051ac9:	cmp    $0x1,%rdx
 1051acd:	jne    1051af8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3328>
 1051acf:	movzbl (%rdi),%ecx
 1051ad2:	cmp    (%rax),%cl
 1051ad4:	jmp    1051b0b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x333b>
 1051ad6:	cmp    $0x4,%rdx
 1051ada:	jb     1051b32 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3362>
 1051adc:	mov    (%rsi),%ecx
 1051ade:	mov    -0x4(%rsi,%rdx,1),%esi
 1051ae2:	xor    (%rax),%ecx
 1051ae4:	xor    -0x4(%rax,%rdx,1),%esi
 1051ae8:	or     %ecx,%esi
 1051aea:	jmp    1051b52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3382>
 1051aec:	call   1093420 <equal_large_octets>
 1051af1:	test   %eax,%eax
 1051af3:	sete   %bl
 1051af6:	jmp    1051b67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3397>
 1051af8:	movzwl (%rdi),%ecx
 1051afb:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051b00:	xor    (%rax),%cx
 1051b03:	xor    -0x2(%rax,%rdx,1),%di
 1051b08:	or     %cx,%di
 1051b0b:	sete   %bl
 1051b0e:	xor    $0x1,%bl
 1051b11:	mov    0x10(%rsp),%rbp
 1051b16:	movabs $0x4000000000000002,%r13
 1051b20:	test   %r13,0x68c11(%rip)        # 10ba738 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051b27:	jne    1051946 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3176>
 1051b2d:	jmp    1051925 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3155>
 1051b32:	cmp    $0x1,%rdx
 1051b36:	jne    1051b3f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x336f>
 1051b38:	movzbl (%rsi),%ecx
 1051b3b:	cmp    (%rax),%cl
 1051b3d:	jmp    1051b52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3382>
 1051b3f:	movzwl (%rsi),%ecx
 1051b42:	movzwl -0x2(%rsi,%rdx,1),%esi
 1051b47:	xor    (%rax),%cx
 1051b4a:	xor    -0x2(%rax,%rdx,1),%si
 1051b4f:	or     %cx,%si
 1051b52:	sete   %bl
 1051b55:	xor    $0x1,%bl
 1051b58:	mov    0x10(%rsp),%rbp
 1051b5d:	movabs $0x4000000000000002,%r13
 1051b67:	test   %r13,0x68c9a(%rip)        # 10ba808 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051b6e:	jne    1051b8d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33bd>
 1051b70:	mov    0x68c81(%rip),%rax        # 10ba7f8 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051b77:	dec    %rax
 1051b7a:	jne    1051b86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b6>
 1051b7c:	cmpq   $0x0,0x68c7c(%rip)        # 10ba800 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 1051b84:	je     1051b98 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33c8>
 1051b86:	mov    %rax,0x68c6b(%rip)        # 10ba7f8 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051b8d:	test   %bl,%bl
 1051b8f:	je     1051bae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33de>
 1051b91:	xor    %eax,%eax
 1051b93:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051b98:	lea    0xc8(%rsp),%rsi
 1051ba0:	mov    0x18(%rsp),%rdi
 1051ba5:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051baa:	test   %bl,%bl
 1051bac:	jne    1051b91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33c1>
 1051bae:	xor    %ebx,%ebx
 1051bb0:	movabs $0x7878787878787879,%r14
 1051bba:	movabs $0x89705f3112a28fe5,%r15
 1051bc4:	xor    %eax,%eax
 1051bc6:	mov    0x8(%rsp),%rcx
 1051bcb:	add    %rbx,%rcx
 1051bce:	jo     1051eb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36e9>
 1051bd4:	mov    %rax,%r12
 1051bd7:	mov    0x30(%rsp),%rax
 1051bdc:	mov    0x8(%rax),%rax
 1051be0:	cmpq   $0x0,(%rax)
 1051be4:	je     1051ecb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36fb>
 1051bea:	mov    0x20(%rax),%rax
 1051bee:	mov    (%rax),%rsi
 1051bf1:	mov    %rcx,%rax
 1051bf4:	imul   %r14
 1051bf7:	mov    %rdx,%rax
 1051bfa:	shr    $0x3f,%rax
 1051bfe:	sar    $0x3,%rdx
 1051c02:	add    %rax,%rdx
 1051c05:	mov    %rdx,%rax
 1051c08:	shl    $0x4,%rax
 1051c0c:	add    %rdx,%rax
 1051c0f:	sub    %rax,%rcx
 1051c12:	mov    %rcx,%rdx
 1051c15:	sar    $0x3f,%rdx
 1051c19:	and    $0x11,%edx
 1051c1c:	add    %rcx,%rdx
 1051c1f:	mov    %rbp,%rdi
 1051c22:	call   10586a0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 1051c27:	mov    %r12,%rcx
 1051c2a:	add    %rax,%rcx
 1051c2d:	jo     1051ed7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3707>
 1051c33:	mov    %rcx,%rax
 1051c36:	imul   %r15
 1051c39:	add    %rcx,%rdx
 1051c3c:	mov    %rdx,%rax
 1051c3f:	shr    $0x3f,%rax
 1051c43:	sar    $0x1d,%rdx
 1051c47:	add    %rax,%rdx
 1051c4a:	imul   $0x3b9aca07,%rdx,%rax
 1051c51:	sub    %rax,%rcx
 1051c54:	mov    %rcx,%rax
 1051c57:	sar    $0x3f,%rax
 1051c5b:	and    $0x3b9aca07,%eax
 1051c60:	add    %rcx,%rax
 1051c63:	inc    %rbx
 1051c66:	cmp    %rbx,0x28(%rsp)
 1051c6b:	jne    1051bc6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33f6>
 1051c71:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051c76:	vzeroupper
 1051c79:	call   10ad2c0 <abort@plt>
 1051c7e:	vzeroupper
 1051c81:	call   109b647 <myl_rc_invariant_failed>
 1051c86:	mov    %rbp,%rdi
 1051c89:	xor    %esi,%esi
 1051c8b:	vzeroupper
 1051c8e:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051c93:	mov    0x10(%rsp),%rdi
 1051c98:	xor    %esi,%esi
 1051c9a:	mov    %r12,%rdx
 1051c9d:	mov    %rax,%rcx
 1051ca0:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051ca5:	mov    0x10(%rsp),%rdi
 1051caa:	vzeroupper
 1051cad:	call   108c5a0 <myl_qbe_fail_iteration>
 1051cb2:	mov    %rbp,%rdi
 1051cb5:	xor    %esi,%esi
 1051cb7:	mov    0x8(%rsp),%rdx
 1051cbc:	mov    %r14,%rcx
 1051cbf:	vzeroupper
 1051cc2:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051cc7:	mov    %rbp,%rdi
 1051cca:	xor    %esi,%esi
 1051ccc:	mov    %r12,%rdx
 1051ccf:	mov    %rbx,%rcx
 1051cd2:	vzeroupper
 1051cd5:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051cda:	mov    0x10(%rsp),%rdi
 1051cdf:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051ce4:	mov    0x10(%rsp),%rdi
 1051ce9:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051cee:	mov    %rbp,%rdi
 1051cf1:	xor    %esi,%esi
 1051cf3:	mov    0x8(%rsp),%rdx
 1051cf8:	mov    %rbx,%rcx
 1051cfb:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051d00:	mov    %rbp,%rdi
 1051d03:	xor    %esi,%esi
 1051d05:	mov    0x8(%rsp),%rdx
 1051d0a:	mov    %rbx,%rcx
 1051d0d:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051d12:	mov    %rbp,%rdi
 1051d15:	xor    %esi,%esi
 1051d17:	xor    %edx,%edx
 1051d19:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051d1e:	mov    %rbp,%rdi
 1051d21:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051d26:	mov    $0x1,%ecx
 1051d2b:	mov    0x10(%rsp),%rdi
 1051d30:	xor    %esi,%esi
 1051d32:	mov    %r15,%rdx
 1051d35:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051d3a:	mov    %rbp,%rdi
 1051d3d:	vzeroupper
 1051d40:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051d45:	mov    %rbp,%rdi
 1051d48:	xor    %esi,%esi
 1051d4a:	mov    0x8(%rsp),%rdx
 1051d4f:	mov    %r12,%rcx
 1051d52:	vzeroupper
 1051d55:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051d5a:	mov    %rbp,%rdi
 1051d5d:	vzeroupper
 1051d60:	call   108c8b0 <myl_qbe_fail_frame>
 1051d65:	mov    %rbp,%rdi
 1051d68:	vzeroupper
 1051d6b:	call   108c590 <myl_qbe_fail_empty_separator>
 1051d70:	mov    %rbp,%rdi
 1051d73:	vzeroupper
 1051d76:	call   108c4a0 <myl_qbe_fail_allocation>
 1051d7b:	mov    %rbp,%rdi
 1051d7e:	xor    %esi,%esi
 1051d80:	mov    %r14,%rcx
 1051d83:	vzeroupper
 1051d86:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051d8b:	mov    %rbp,%rdi
 1051d8e:	mov    %r15,%rsi
 1051d91:	vzeroupper
 1051d94:	call   108c850 <myl_qbe_fail_cast>
 1051d99:	mov    $0x2,%esi
 1051d9e:	mov    $0x7,%ecx
 1051da3:	mov    %rbp,%rdi
 1051da6:	mov    %r15,%rdx
 1051da9:	vzeroupper
 1051dac:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051db1:	mov    %rbp,%rdi
 1051db4:	call   108c8b0 <myl_qbe_fail_frame>
 1051db9:	mov    %rbp,%rdi
 1051dbc:	call   108c4a0 <myl_qbe_fail_allocation>
 1051dc1:	mov    %rbp,%rdi
 1051dc4:	xor    %esi,%esi
 1051dc6:	mov    %r14,%rdx
 1051dc9:	mov    %r13,%rcx
 1051dcc:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051dd1:	mov    %rbp,%rdi
 1051dd4:	xor    %esi,%esi
 1051dd6:	mov    0x8(%rsp),%rdx
 1051ddb:	mov    %r15,%rcx
 1051dde:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051de3:	mov    %rbp,%rdi
 1051de6:	xor    %esi,%esi
 1051de8:	mov    0x8(%rsp),%rdx
 1051ded:	mov    %rbx,%rcx
 1051df0:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051df5:	mov    %rbp,%rdi
 1051df8:	mov    %rcx,%rsi
 1051dfb:	call   108c850 <myl_qbe_fail_cast>
 1051e00:	mov    %rbp,%rdi
 1051e03:	mov    %rax,%rsi
 1051e06:	call   108c7a0 <myl_qbe_fail_division>
 1051e0b:	mov    %rbp,%rdi
 1051e0e:	mov    %rcx,%rdx
 1051e11:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051e16:	mov    %rbp,%rdi
 1051e19:	xor    %esi,%esi
 1051e1b:	mov    %r15,%rdx
 1051e1e:	mov    %r12,%rcx
 1051e21:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051e26:	mov    %rbp,%rdi
 1051e29:	xor    %esi,%esi
 1051e2b:	mov    0x8(%rsp),%rdx
 1051e30:	mov    %rbx,%rcx
 1051e33:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051e38:	mov    %rbp,%rdi
 1051e3b:	mov    %rcx,%rsi
 1051e3e:	call   108c850 <myl_qbe_fail_cast>
 1051e43:	mov    %rbp,%rdi
 1051e46:	mov    %rax,%rsi
 1051e49:	call   108c7a0 <myl_qbe_fail_division>
 1051e4e:	mov    %rbp,%rdi
 1051e51:	call   108c4a0 <myl_qbe_fail_allocation>
 1051e56:	mov    %rbp,%rdi
 1051e59:	mov    %rcx,%rdx
 1051e5c:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051e61:	mov    %rbp,%rdi
 1051e64:	xor    %esi,%esi
 1051e66:	mov    0x8(%rsp),%rdx
 1051e6b:	mov    %rbx,%rcx
 1051e6e:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051e73:	mov    %rbp,%rdi
 1051e76:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051e7b:	mov    %r15,%rdx
 1051e7e:	mov    %rbp,%rdi
 1051e81:	xor    %esi,%esi
 1051e83:	mov    %rax,%rcx
 1051e86:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051e8b:	mov    %rbp,%rdi
 1051e8e:	xor    %esi,%esi
 1051e90:	mov    0x8(%rsp),%rdx
 1051e95:	mov    %rbx,%rcx
 1051e98:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051e9d:	mov    %rbp,%rdi
 1051ea0:	xor    %esi,%esi
 1051ea2:	xor    %edx,%edx
 1051ea4:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051ea9:	mov    %r15,%rdx
 1051eac:	mov    %rbp,%rdi
 1051eaf:	xor    %esi,%esi
 1051eb1:	mov    %rax,%rcx
 1051eb4:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051eb9:	mov    %rbp,%rdi
 1051ebc:	xor    %esi,%esi
 1051ebe:	mov    0x8(%rsp),%rdx
 1051ec3:	mov    %rbx,%rcx
 1051ec6:	call   108c7f0 <myl_qbe_fail_overflow_op>
 1051ecb:	mov    %rbp,%rdi
 1051ece:	xor    %esi,%esi
 1051ed0:	xor    %edx,%edx
 1051ed2:	call   108c6e0 <myl_qbe_fail_normalized_index_bounds>
 1051ed7:	mov    %r12,%rdx
 1051eda:	mov    %rbp,%rdi
 1051edd:	xor    %esi,%esi
 1051edf:	mov    %rax,%rcx
 1051ee2:	call   108c7f0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
