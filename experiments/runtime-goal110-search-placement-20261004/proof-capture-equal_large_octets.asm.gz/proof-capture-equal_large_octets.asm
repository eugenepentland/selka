
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-search-placement/capture/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093420 <equal_large_octets>:
 1093420:	mov    (%rdi),%rcx
 1093423:	xor    %eax,%eax
 1093425:	cmp    (%rsi),%rcx
 1093428:	jne    1093455 <equal_large_octets+0x35>
 109342a:	mov    -0x8(%rsi,%rdx,1),%rcx
 109342f:	cmp    %rcx,-0x8(%rdi,%rdx,1)
 1093434:	jne    1093455 <equal_large_octets+0x35>
 1093436:	push   %rbp
 1093437:	mov    %rsp,%rbp
 109343a:	add    $0x8,%rdi
 109343e:	add    $0x8,%rsi
 1093442:	add    $0xfffffffffffffff0,%rdx
 1093446:	call   10ad2e0 <bcmp@plt>
 109344b:	mov    %eax,%ecx
 109344d:	xor    %eax,%eax
 109344f:	test   %ecx,%ecx
 1093451:	sete   %al
 1093454:	pop    %rbp
 1093455:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
