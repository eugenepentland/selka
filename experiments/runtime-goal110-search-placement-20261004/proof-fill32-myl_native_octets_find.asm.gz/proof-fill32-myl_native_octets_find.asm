
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-search-placement/fill32/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093480 <myl_native_octets_find>:
 1093480:	test   %rcx,%rcx
 1093483:	je     10934da <myl_native_octets_find+0x5a>
 1093485:	push   %rbp
 1093486:	mov    %rsp,%rbp
 1093489:	push   %r15
 109348b:	push   %r14
 109348d:	push   %r13
 109348f:	push   %r12
 1093491:	push   %rbx
 1093492:	sub    $0x18,%rsp
 1093496:	mov    $0xffffffffffffffff,%rax
 109349d:	mov    %rsi,%r14
 10934a0:	sub    %rcx,%r14
 10934a3:	jb     1093745 <myl_native_octets_find+0x2c5>
 10934a9:	mov    %rsi,%rbx
 10934ac:	cmp    $0x1,%rcx
 10934b0:	jne    10934dd <myl_native_octets_find+0x5d>
 10934b2:	movzbl (%rdx),%esi
 10934b5:	mov    %rdi,%r14
 10934b8:	mov    %rbx,%rdx
 10934bb:	call   10ad4c0 <memchr@plt>
 10934c0:	mov    %rax,%rcx
 10934c3:	mov    %rax,%rdx
 10934c6:	sub    %r14,%rdx
 10934c9:	xor    %eax,%eax
 10934cb:	cmp    $0x1,%rcx
 10934cf:	sbb    %rax,%rax
 10934d2:	or     %rdx,%rax
 10934d5:	jmp    1093745 <myl_native_octets_find+0x2c5>
 10934da:	xor    %eax,%eax
 10934dc:	ret
 10934dd:	mov    %rcx,-0x30(%rbp)
 10934e1:	mov    %rdx,%r15
 10934e4:	movzbl (%rdx),%r12d
 10934e8:	lea    0x1(%r14),%rdx
 10934ec:	mov    %rdi,%r13
 10934ef:	mov    %r12d,%esi
 10934f2:	call   10ad4c0 <memchr@plt>
 10934f7:	test   %rax,%rax
 10934fa:	je     109373e <myl_native_octets_find+0x2be>
 1093500:	mov    %r13,%rcx
 1093503:	lea    (%r14,%r13,1),%r10
 1093507:	lea    (%r14,%r13,1),%r11
 109350b:	inc    %r11
 109350e:	lea    0x1(%rax),%rdi
 1093512:	mov    $0x1,%edx
 1093517:	mov    -0x30(%rbp),%rsi
 109351b:	mov    %r15,%r8
 109351e:	xchg   %ax,%ax
 1093520:	movzbl (%rax,%rdx,1),%r9d
 1093525:	cmp    (%r8,%rdx,1),%r9b
 1093529:	jne    109353b <myl_native_octets_find+0xbb>
 109352b:	inc    %rdx
 109352e:	cmp    %rdx,%rsi
 1093531:	jne    1093520 <myl_native_octets_find+0xa0>
 1093533:	sub    %rcx,%rax
 1093536:	jmp    1093745 <myl_native_octets_find+0x2c5>
 109353b:	cmp    %r10,%rax
 109353e:	je     109373e <myl_native_octets_find+0x2be>
 1093544:	mov    %r10,-0x38(%rbp)
 1093548:	mov    %r11,%r14
 109354b:	mov    %r11,%rdx
 109354e:	sub    %rdi,%rdx
 1093551:	mov    %r12d,%esi
 1093554:	call   10ad4c0 <memchr@plt>
 1093559:	test   %rax,%rax
 109355c:	je     109373e <myl_native_octets_find+0x2be>
 1093562:	lea    0x1(%rax),%rdi
 1093566:	mov    $0x1,%edx
 109356b:	mov    %r13,%rcx
 109356e:	mov    -0x30(%rbp),%rsi
 1093572:	mov    %r15,%r8
 1093575:	mov    -0x38(%rbp),%r10
 1093579:	mov    %r14,%r11
 109357c:	nopl   0x0(%rax)
 1093580:	movzbl (%rax,%rdx,1),%r9d
 1093585:	cmp    (%r8,%rdx,1),%r9b
 1093589:	jne    1093595 <myl_native_octets_find+0x115>
 109358b:	inc    %rdx
 109358e:	cmp    %rdx,%rsi
 1093591:	jne    1093580 <myl_native_octets_find+0x100>
 1093593:	jmp    1093533 <myl_native_octets_find+0xb3>
 1093595:	cmp    %r10,%rax
 1093598:	je     109373e <myl_native_octets_find+0x2be>
 109359e:	mov    %r11,%rdx
 10935a1:	sub    %rdi,%rdx
 10935a4:	mov    %r12d,%esi
 10935a7:	call   10ad4c0 <memchr@plt>
 10935ac:	test   %rax,%rax
 10935af:	je     109373e <myl_native_octets_find+0x2be>
 10935b5:	lea    0x1(%rax),%rdi
 10935b9:	mov    $0x1,%edx
 10935be:	mov    %r13,%rcx
 10935c1:	mov    -0x30(%rbp),%rsi
 10935c5:	mov    %r15,%r8
 10935c8:	mov    -0x38(%rbp),%r10
 10935cc:	mov    %r14,%r11
 10935cf:	movzbl (%rax,%rdx,1),%r9d
 10935d4:	cmp    (%r8,%rdx,1),%r9b
 10935d8:	jne    10935e7 <myl_native_octets_find+0x167>
 10935da:	inc    %rdx
 10935dd:	cmp    %rdx,%rsi
 10935e0:	jne    10935cf <myl_native_octets_find+0x14f>
 10935e2:	jmp    1093533 <myl_native_octets_find+0xb3>
 10935e7:	cmp    %r10,%rax
 10935ea:	je     109373e <myl_native_octets_find+0x2be>
 10935f0:	mov    %r11,%rdx
 10935f3:	sub    %rdi,%rdx
 10935f6:	mov    %r12d,%esi
 10935f9:	call   10ad4c0 <memchr@plt>
 10935fe:	test   %rax,%rax
 1093601:	je     109373e <myl_native_octets_find+0x2be>
 1093607:	lea    0x1(%rax),%rdi
 109360b:	mov    $0x1,%edx
 1093610:	mov    %r13,%rcx
 1093613:	mov    -0x30(%rbp),%rsi
 1093617:	mov    %r15,%r8
 109361a:	mov    -0x38(%rbp),%r10
 109361e:	mov    %r14,%r11
 1093621:	movzbl (%rax,%rdx,1),%r9d
 1093626:	cmp    (%r8,%rdx,1),%r9b
 109362a:	jne    1093639 <myl_native_octets_find+0x1b9>
 109362c:	inc    %rdx
 109362f:	cmp    %rdx,%rsi
 1093632:	jne    1093621 <myl_native_octets_find+0x1a1>
 1093634:	jmp    1093533 <myl_native_octets_find+0xb3>
 1093639:	cmp    %r10,%rax
 109363c:	je     109373e <myl_native_octets_find+0x2be>
 1093642:	mov    %r11,%rdx
 1093645:	sub    %rdi,%rdx
 1093648:	mov    %r12d,%esi
 109364b:	call   10ad4c0 <memchr@plt>
 1093650:	test   %rax,%rax
 1093653:	je     109373e <myl_native_octets_find+0x2be>
 1093659:	lea    0x1(%rax),%rdi
 109365d:	mov    $0x1,%ecx
 1093662:	mov    -0x30(%rbp),%rdx
 1093666:	mov    %r15,%rsi
 1093669:	movzbl (%rax,%rcx,1),%r8d
 109366e:	cmp    (%rsi,%rcx,1),%r8b
 1093672:	jne    1093684 <myl_native_octets_find+0x204>
 1093674:	inc    %rcx
 1093677:	cmp    %rcx,%rdx
 109367a:	jne    1093669 <myl_native_octets_find+0x1e9>
 109367c:	mov    %r13,%rcx
 109367f:	jmp    1093533 <myl_native_octets_find+0xb3>
 1093684:	cmp    -0x38(%rbp),%rax
 1093688:	je     109373e <myl_native_octets_find+0x2be>
 109368e:	mov    %r14,%rdx
 1093691:	sub    %rdi,%rdx
 1093694:	mov    %r12d,%esi
 1093697:	call   10ad4c0 <memchr@plt>
 109369c:	test   %rax,%rax
 109369f:	je     109373e <myl_native_octets_find+0x2be>
 10936a5:	lea    0x1(%rax),%rdi
 10936a9:	mov    $0x1,%ecx
 10936ae:	mov    -0x30(%rbp),%rdx
 10936b2:	mov    %r15,%rsi
 10936b5:	movzbl (%rax,%rcx,1),%r8d
 10936ba:	cmp    (%rsi,%rcx,1),%r8b
 10936be:	jne    10936ca <myl_native_octets_find+0x24a>
 10936c0:	inc    %rcx
 10936c3:	cmp    %rcx,%rdx
 10936c6:	jne    10936b5 <myl_native_octets_find+0x235>
 10936c8:	jmp    109367c <myl_native_octets_find+0x1fc>
 10936ca:	cmp    -0x38(%rbp),%rax
 10936ce:	je     109373e <myl_native_octets_find+0x2be>
 10936d0:	mov    %r14,%rdx
 10936d3:	sub    %rdi,%rdx
 10936d6:	mov    %r12d,%esi
 10936d9:	call   10ad4c0 <memchr@plt>
 10936de:	test   %rax,%rax
 10936e1:	je     109373e <myl_native_octets_find+0x2be>
 10936e3:	lea    0x1(%rax),%rdi
 10936e7:	mov    $0x1,%ecx
 10936ec:	movzbl (%rax,%rcx,1),%edx
 10936f0:	cmp    (%r15,%rcx,1),%dl
 10936f4:	jne    1093704 <myl_native_octets_find+0x284>
 10936f6:	inc    %rcx
 10936f9:	cmp    %rcx,-0x30(%rbp)
 10936fd:	jne    10936ec <myl_native_octets_find+0x26c>
 10936ff:	jmp    109367c <myl_native_octets_find+0x1fc>
 1093704:	cmp    -0x38(%rbp),%rax
 1093708:	je     109373e <myl_native_octets_find+0x2be>
 109370a:	sub    %rdi,%r14
 109370d:	mov    %r12d,%esi
 1093710:	mov    %r14,%rdx
 1093713:	call   10ad4c0 <memchr@plt>
 1093718:	test   %rax,%rax
 109371b:	je     109373e <myl_native_octets_find+0x2be>
 109371d:	lea    0x1(%rax),%rdi
 1093721:	mov    $0x1,%ecx
 1093726:	movzbl (%rax,%rcx,1),%edx
 109372a:	cmp    (%r15,%rcx,1),%dl
 109372e:	jne    1093754 <myl_native_octets_find+0x2d4>
 1093730:	inc    %rcx
 1093733:	cmp    %rcx,-0x30(%rbp)
 1093737:	jne    1093726 <myl_native_octets_find+0x2a6>
 1093739:	jmp    109367c <myl_native_octets_find+0x1fc>
 109373e:	mov    $0xffffffffffffffff,%rax
 1093745:	add    $0x18,%rsp
 1093749:	pop    %rbx
 109374a:	pop    %r12
 109374c:	pop    %r13
 109374e:	pop    %r14
 1093750:	pop    %r15
 1093752:	pop    %rbp
 1093753:	ret
 1093754:	cmp    -0x38(%rbp),%rax
 1093758:	mov    $0xffffffffffffffff,%rax
 109375f:	je     1093745 <myl_native_octets_find+0x2c5>
 1093761:	add    %r13,%rbx
 1093764:	sub    %rdi,%rbx
 1093767:	mov    %rbx,%rsi
 109376a:	mov    %r15,%rdx
 109376d:	mov    -0x30(%rbp),%rcx
 1093771:	call   10ad4d0 <memmem@plt>
 1093776:	mov    %rax,%rcx
 1093779:	mov    %rax,%rdx
 109377c:	sub    %r13,%rdx
 109377f:	jmp    10934c9 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
